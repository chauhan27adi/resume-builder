
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,undefined4 param_3)

{
  int *piVar1;
  undefined2 uVar2;
  short sVar3;
  undefined auVar4 [16];
  undefined4 uVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  short *psVar10;
  ulonglong *puVar11;
  ulonglong *puVar12;
  ulonglong *puVar13;
  undefined8 uVar14;
  short *psVar15;
  ulonglong uVar16;
  uint uVar17;
  longlong lVar18;
  ulonglong uVar19;
  ulonglong uVar20;
  longlong lVar21;
  ulonglong *puVar22;
  longlong unaff_GS_OFFSET;
  bool bVar23;
  undefined auStack_1d8 [32];
  undefined8 uStack_1b8;
  undefined8 uStack_1b0;
  int iStack_1a8;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined4 uStack_18c;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  int iStack_168;
  int iStack_164;
  longlong lStack_160;
  int iStack_158;
  int iStack_150;
  int iStack_14c;
  longlong lStack_148;
  undefined4 uStack_140;
  undefined8 uStack_138;
  longlong alStack_128 [12];
  longlong lStack_c8;
  undefined2 uStack_c0;
  undefined8 uStack_b8;
  undefined4 uStack_b0;
  undefined auStack_a8 [16];
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  longlong lStack_68;
  uint uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_138 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_1d8;
  uVar2 = *(undefined2 *)(param_1 + 8);
  puVar22 = (ulonglong *)0x0;
  uStack_178 = param_3;
  if ((DAT_ & 8) == 0) {
    iStack_158 = 0;
  }
  else {
    iStack_158 = 1;
    iStack_168 = (*_DAT_)();
    iStack_164 = 0x23;
    lStack_160 = func_0x(uVar2);
  }
  if (*(longlong *)(param_1 + 0x80) == 0) {
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1c3d7d8,0x1c17b40,0xc02);
  }
  if (param_2 == (longlong *)0x0) {
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1c3d7b0,0x1c17b40,0xc03);
  }
  if (*(longlong *)(param_1 + 0x70) == 0) {
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1c3d2e8,0x1c17b40,0xc04);
  }
  *(undefined2 *)(*(longlong *)(param_1 + 0x80) + 0x30) = 0;
  *(undefined2 *)(*(longlong *)(param_1 + 0x80) + 0x170) = 0;
  *(undefined2 *)(*(longlong *)(param_1 + 0x80) + 0x280) = 0;
  *(undefined2 *)(*(longlong *)(param_1 + 0x80) + 0x500) = 0;
  *(undefined2 *)(*(longlong *)(param_1 + 0x80) + 0x710) = 0;
  psVar15 = (short *)(*(longlong *)(param_1 + 0x80) + 0xb80);
  lVar18 = 4;
  lVar21 = 0x18e0948 - (longlong)psVar15;
  do {
    if ((lVar18 == -0x7ffffffa) || (sVar3 = *(short *)(lVar21 + (longlong)psVar15), sVar3 == 0))
    break;
    *psVar15 = sVar3;
    psVar15 = psVar15 + 1;
    lVar18 = lVar18 + -1;
  } while (lVar18 != 0);
  psVar10 = psVar15 + -1;
  if (lVar18 != 0) {
    psVar10 = psVar15;
  }
  *psVar10 = 0;
  if (lVar18 == 0) {
    iStack_1a8 = -0x7ff8ff86;
    uStack_1b0 = CONCAT44(uStack_1b0._4_4_,0xc0f);
    uStack_1b8 = 0x1a8ac60;
    (*_DAT_)(4,7,0x10,1);
  }
  uVar5 = func_0x(*(longlong *)(param_1 + 0x80) + 0xb80);
  *(undefined4 *)(*(longlong *)(param_1 + 0x80) + 0x20) = uVar5;
  uStack_198 = 0;
  puVar12 = puVar22;
  puVar11 = puVar22;
  if (((*param_2 == 0) || (param_2[0xc] == 0)) || (*(int *)(param_2 + 0xd) == 0)) {
LAB_:
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1c3d1ac,0x1c17b40,0xc16);
  }
  else {
    uVar6 = func_0x(param_2,0x1888910,&uStack_198);
    if (((param_2[0xc] != 0) && (uVar6 - 1 < 0xfffffffe)) &&
       (puVar11 = (ulonglong *)0x0, *(uint *)(param_2 + 0xd) != 0)) {
      do {
        puVar11 = (ulonglong *)((longlong)puVar12 * 0x58 + param_2[0xc]);
        if (*puVar11 == (ulonglong)uVar6) {
          if (puVar11 != (ulonglong *)0x0) goto LAB_;
          break;
        }
        uVar17 = (int)puVar12 + 1;
        puVar12 = (ulonglong *)(ulonglong)uVar17;
        puVar11 = (ulonglong *)0x0;
      } while (uVar17 < *(uint *)(param_2 + 0xd));
    }
    uStack_1b8 = CONCAT44(uStack_1b8._4_4_,*(undefined4 *)(param_2 + 3));
    (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
    puVar12 = *(ulonglong **)(*param_2 + puVar11[2]);
    puVar11 = (ulonglong *)(puVar11[1] + *param_2);
    if (puVar11 == (ulonglong *)0x0) goto LAB_;
  }
  func_0x(*(undefined8 *)(param_1 + 0x80),puVar11,puVar12);
  uStack_194 = 0;
  puVar11 = puVar22;
  if (((*param_2 == 0) || (param_2[0xc] == 0)) || (*(int *)(param_2 + 0xd) == 0)) {
LAB_:
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1c3d1ac,0x1c17b40,0xc1a);
  }
  else {
    uVar6 = func_0x(param_2,0x19eb9c0,&uStack_194);
    if (((param_2[0xc] != 0) && (uVar6 - 1 < 0xfffffffe)) &&
       (puVar11 = (ulonglong *)0x0, *(uint *)(param_2 + 0xd) != 0)) {
      puVar12 = puVar22;
      do {
        puVar11 = (ulonglong *)((longlong)puVar12 * 0x58 + param_2[0xc]);
        if (*puVar11 == (ulonglong)uVar6) {
          if (puVar11 != (ulonglong *)0x0) goto LAB_;
          break;
        }
        uVar17 = (int)puVar12 + 1;
        puVar12 = (ulonglong *)(ulonglong)uVar17;
        puVar11 = (ulonglong *)0x0;
      } while (uVar17 < *(uint *)(param_2 + 0xd));
    }
    uStack_1b8 = CONCAT44(uStack_1b8._4_4_,*(undefined4 *)(param_2 + 3));
    (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
    puVar12 = *(ulonglong **)(*param_2 + puVar11[2]);
    puVar11 = (ulonglong *)(puVar11[1] + *param_2);
    if (puVar11 == (ulonglong *)0x0) goto LAB_;
  }
  func_0x(*(longlong *)(param_1 + 0x80) + 4,puVar11,puVar12);
  uStack_190 = 0;
  puVar11 = puVar22;
  if (((*param_2 == 0) || (param_2[0xc] == 0)) || (*(int *)(param_2 + 0xd) == 0)) {
LAB_:
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1c3d1ac,0x1c17b40,0xc1e);
  }
  else {
    uVar6 = func_0x(param_2,0x1824da8,&uStack_190);
    if (((param_2[0xc] != 0) && (uVar6 - 1 < 0xfffffffe)) &&
       (puVar11 = (ulonglong *)0x0, *(uint *)(param_2 + 0xd) != 0)) {
      puVar12 = puVar22;
      do {
        puVar11 = (ulonglong *)((longlong)puVar12 * 0x58 + param_2[0xc]);
        if (*puVar11 == (ulonglong)uVar6) {
          if (puVar11 != (ulonglong *)0x0) goto LAB_;
          break;
        }
        uVar17 = (int)puVar12 + 1;
        puVar12 = (ulonglong *)(ulonglong)uVar17;
        puVar11 = (ulonglong *)0x0;
      } while (uVar17 < *(uint *)(param_2 + 0xd));
    }
    uStack_1b8 = CONCAT44(uStack_1b8._4_4_,*(undefined4 *)(param_2 + 3));
    (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
    puVar12 = *(ulonglong **)(*param_2 + puVar11[2]);
    puVar11 = (ulonglong *)(puVar11[1] + *param_2);
    if (puVar11 == (ulonglong *)0x0) goto LAB_;
  }
  func_0x(*(longlong *)(param_1 + 0x80) + 8,puVar11,puVar12);
  uStack_18c = 0;
  puVar11 = puVar22;
  if (((*param_2 == 0) || (param_2[0xc] == 0)) || (*(int *)(param_2 + 0xd) == 0)) {
LAB_:
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1c3d1ac,0x1c17b40,0xc22);
  }
  else {
    uVar6 = func_0x(param_2,0x1a85648,&uStack_18c);
    if (((param_2[0xc] != 0) && (uVar6 - 1 < 0xfffffffe)) &&
       (puVar11 = (ulonglong *)0x0, *(uint *)(param_2 + 0xd) != 0)) {
      puVar12 = puVar22;
      do {
        puVar11 = (ulonglong *)((longlong)puVar12 * 0x58 + param_2[0xc]);
        if (*puVar11 == (ulonglong)uVar6) {
          if (puVar11 != (ulonglong *)0x0) goto LAB_;
          break;
        }
        uVar17 = (int)puVar12 + 1;
        puVar12 = (ulonglong *)(ulonglong)uVar17;
        puVar11 = (ulonglong *)0x0;
      } while (uVar17 < *(uint *)(param_2 + 0xd));
    }
    uStack_1b8 = CONCAT44(uStack_1b8._4_4_,*(undefined4 *)(param_2 + 3));
    (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
    puVar12 = *(ulonglong **)(*param_2 + puVar11[2]);
    puVar11 = (ulonglong *)(puVar11[1] + *param_2);
    if (puVar11 == (ulonglong *)0x0) goto LAB_;
  }
  func_0x(*(longlong *)(param_1 + 0x80) + 0xc,puVar11,puVar12);
  uStack_188 = 0;
  puVar11 = puVar22;
  if (((*param_2 == 0) || (param_2[0xc] == 0)) || (*(int *)(param_2 + 0xd) == 0)) {
LAB_:
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1c3d1ac,0x1c17b40,0xc26);
  }
  else {
    uVar6 = func_0x(param_2,0x1823e30,&uStack_188);
    if (((param_2[0xc] != 0) && (uVar6 - 1 < 0xfffffffe)) &&
       (puVar11 = (ulonglong *)0x0, *(uint *)(param_2 + 0xd) != 0)) {
      puVar12 = puVar22;
      do {
        puVar11 = (ulonglong *)((longlong)puVar12 * 0x58 + param_2[0xc]);
        if (*puVar11 == (ulonglong)uVar6) {
          if (puVar11 != (ulonglong *)0x0) goto LAB_;
          break;
        }
        uVar17 = (int)puVar12 + 1;
        puVar12 = (ulonglong *)(ulonglong)uVar17;
        puVar11 = (ulonglong *)0x0;
      } while (uVar17 < *(uint *)(param_2 + 0xd));
    }
    uStack_1b8 = CONCAT44(uStack_1b8._4_4_,*(undefined4 *)(param_2 + 3));
    (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
    puVar12 = *(ulonglong **)(*param_2 + puVar11[2]);
    puVar11 = (ulonglong *)(puVar11[1] + *param_2);
    if (puVar11 == (ulonglong *)0x0) goto LAB_;
  }
  func_0x(*(longlong *)(param_1 + 0x80) + 0x10,puVar11,puVar12);
  uStack_184 = 0;
  puVar11 = puVar22;
  if (((*param_2 == 0) || (param_2[0xc] == 0)) || (*(int *)(param_2 + 0xd) == 0)) {
LAB_:
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1c3d1ac,0x1c17b40,0xc2a);
  }
  else {
    uVar6 = func_0x(param_2,0x1829fc0,&uStack_184);
    if (((param_2[0xc] != 0) && (uVar6 - 1 < 0xfffffffe)) &&
       (puVar11 = (ulonglong *)0x0, *(uint *)(param_2 + 0xd) != 0)) {
      puVar12 = puVar22;
      do {
        puVar11 = (ulonglong *)((longlong)puVar12 * 0x58 + param_2[0xc]);
        if (*puVar11 == (ulonglong)uVar6) {
          if (puVar11 != (ulonglong *)0x0) goto LAB_;
          break;
        }
        uVar17 = (int)puVar12 + 1;
        puVar12 = (ulonglong *)(ulonglong)uVar17;
        puVar11 = (ulonglong *)0x0;
      } while (uVar17 < *(uint *)(param_2 + 0xd));
    }
    uStack_1b8 = CONCAT44(uStack_1b8._4_4_,*(undefined4 *)(param_2 + 3));
    (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
    puVar12 = *(ulonglong **)(*param_2 + puVar11[2]);
    puVar11 = (ulonglong *)(puVar11[1] + *param_2);
    if (puVar11 == (ulonglong *)0x0) goto LAB_;
  }
  func_0x(*(longlong *)(param_1 + 0x80) + 0x11,puVar11,puVar12);
  lVar18 = *(longlong *)(param_1 + 0x80) + 0x30;
  if (lVar18 == 0) {
    uStack_1b8 = 0;
    (*_DAT_)((int)*(longlong *)(param_1 + 0x80) + 0x31,0x1c3d7a8,0x1c17b40,0xcc8);
  }
  uStack_180 = 0;
  if (((*param_2 == 0) || (param_2[0xc] == 0)) || (*(int *)(param_2 + 0xd) == 0)) {
LAB_:
    uVar20 = 0;
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1c3d770,0x1c17b40,0xc32);
  }
  else {
    uVar6 = func_0x(param_2,0x1a8ae18,&uStack_180);
    puVar12 = puVar22;
    if (((param_2[0xc] != 0) && (uVar6 - 1 < 0xfffffffe)) &&
       (puVar12 = (ulonglong *)0x0, *(uint *)(param_2 + 0xd) != 0)) {
      puVar11 = puVar22;
      do {
        puVar12 = (ulonglong *)((longlong)puVar11 * 0x58 + param_2[0xc]);
        if (*puVar12 == (ulonglong)uVar6) {
          if (puVar12 != (ulonglong *)0x0) goto LAB_;
          break;
        }
        uVar17 = (int)puVar11 + 1;
        puVar11 = (ulonglong *)(ulonglong)uVar17;
        puVar12 = (ulonglong *)0x0;
      } while (uVar17 < *(uint *)(param_2 + 0xd));
    }
    uStack_1b8 = CONCAT44(uStack_1b8._4_4_,*(undefined4 *)(param_2 + 3));
    (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
    lVar21 = *param_2;
    uVar20 = *(ulonglong *)(lVar21 + puVar12[2]);
    iVar7 = *(int *)(lVar21 + puVar12[3]);
    uVar16 = puVar12[1];
    if (0x102 < uVar20) {
      uStack_1b8 = 0;
      (*_DAT_)(1,0x1c3d7c0,0x1c17b40,0xcd1);
    }
    if (((uVar16 + lVar21 == 0) || (uVar20 == 0)) || (iVar7 == 3)) goto LAB_;
    if (uVar20 < 0x103) {
      func_0x(lVar18,uVar16 + lVar21,uVar20);
    }
  }
  puVar12 = (ulonglong *)0x0;
  *(undefined2 *)(*(longlong *)(param_1 + 0x80) + 0x30 + (uVar20 & 0xfffffffffffffffe)) = 0;
  lVar18 = *(longlong *)(param_1 + 0x80) + 0x170;
  if (lVar18 == 0) {
    uStack_1b8 = 0;
    (*_DAT_)((int)*(longlong *)(param_1 + 0x80) + 0x171,0x1c3d7a8,0x1c17b40,0xcc8);
  }
  uStack_17c = 0;
  if (((*param_2 == 0) || (param_2[0xc] == 0)) || (*(int *)(param_2 + 0xd) == 0)) {
LAB_:
    uVar16 = 0;
  }
  else {
    uVar6 = func_0x(param_2,0x1a8ae30,&uStack_17c);
    if (((param_2[0xc] != 0) && (uVar6 - 1 < 0xfffffffe)) && (*(uint *)(param_2 + 0xd) != 0)) {
      puVar11 = puVar12;
      do {
        puVar13 = (ulonglong *)((longlong)puVar11 * 0x58 + param_2[0xc]);
        if (*puVar13 == (ulonglong)uVar6) {
          puVar12 = puVar13;
          if (puVar13 != (ulonglong *)0x0) goto LAB_;
          break;
        }
        uVar17 = (int)puVar11 + 1;
        puVar11 = (ulonglong *)(ulonglong)uVar17;
      } while (uVar17 < *(uint *)(param_2 + 0xd));
    }
    uStack_1b8 = CONCAT44(uStack_1b8._4_4_,*(undefined4 *)(param_2 + 3));
    (*_DAT_)(0xbb,0x38,0x10,0xd);
    puVar13 = puVar12;
LAB_:
    lVar21 = *param_2;
    uVar16 = *(ulonglong *)(lVar21 + puVar13[2]);
    iVar7 = *(int *)(lVar21 + puVar13[3]);
    uVar20 = puVar13[1];
    if (0x102 < uVar16) {
      uStack_1b8 = 0;
      (*_DAT_)(1,0x1c3d7c0,0x1c17b40,0xcd1);
    }
    if (((uVar20 + lVar21 == 0) || (uVar16 == 0)) || (iVar7 == 3)) goto LAB_;
    if (uVar16 < 0x103) {
      func_0x(lVar18,uVar20 + lVar21,uVar16);
    }
  }
  uVar20 = 0;
  *(undefined2 *)(*(longlong *)(param_1 + 0x80) + 0x170 + (uVar16 & 0xfffffffffffffffe)) = 0;
  if ((*(longlong *)(param_1 + 0x68) != 0) &&
     (puVar22 = *(ulonglong **)(*(longlong *)(param_1 + 0x68) + 0x70), puVar22 != (ulonglong *)0x0))
  {
LAB_:
    if ((*(int *)((longlong)puVar22 + 4) != (*(int **)(param_1 + 0x80))[2]) ||
       (*(int *)puVar22 != **(int **)(param_1 + 0x80))) goto LAB_;
    uVar6 = *(uint *)(puVar22 + 4);
    uVar14 = (*_DAT_)();
    uStack_1b0 = puVar22[3];
    uStack_1b8 = (ulonglong)(uVar6 >> 1);
    iVar7 = func_0x(*(longlong *)(param_1 + 0x80) + 0x280,0x101,0x18e1dc8,uVar14);
    if (iVar7 < 0) {
      uStack_1b0 = CONCAT44(uStack_1b0._4_4_,0xc40);
      uStack_1b8 = 0x1a8ac60;
      iStack_1a8 = iVar7;
      (*_DAT_)(4,7,0x10,1);
    }
    uVar6 = *(uint *)(puVar22 + 6);
    uVar14 = (*_DAT_)();
    uStack_1b0 = puVar22[5];
    uStack_1b8 = (ulonglong)(uVar6 >> 1);
    iVar7 = func_0x(*(longlong *)(param_1 + 0x80) + 0x500,0x101,0x18e1dc8,uVar14);
    if (iVar7 < 0) {
      uStack_1b0 = CONCAT44(uStack_1b0._4_4_,0xc43);
      uStack_1b8 = 0x1a8ac60;
      iStack_1a8 = iVar7;
      (*_DAT_)(4,7,0x10,1);
    }
    uVar6 = *(uint *)(puVar22 + 8);
    uVar14 = (*_DAT_)();
    uStack_1b0 = puVar22[7];
    uStack_1b8 = (ulonglong)(uVar6 >> 1);
    iVar7 = func_0x(*(longlong *)(param_1 + 0x80) + 0x710,0x101,0x18e1dc8,uVar14);
    if (iVar7 < 0) {
      uStack_1b0 = CONCAT44(uStack_1b0._4_4_,0xc46);
      uStack_1b8 = 0x1a8ac60;
      iStack_1a8 = iVar7;
      (*_DAT_)(4,7,0x10,1);
    }
    *(int *)(*(longlong *)(param_1 + 0x80) + 0x24) = *(int *)(puVar22 + 1);
    auVar4 = ZEXT816(4) * ZEXT416(*(uint *)(*(longlong *)(param_1 + 0x80) + 0x24));
    uVar14 = auVar4._0_8_;
    if (auVar4._8_8_ != 0) {
      uVar14 = 0xffffffffffffffff;
    }
    uStack_1b0 = CONCAT71(uStack_1b0._1_7_,6);
    uStack_1b8 = CONCAT44(uStack_1b8._4_4_,0xc49);
    uVar14 = (*_DAT_)(uVar14,_DAT_,1,0x1a8ac60);
    *(undefined8 *)(*(longlong *)(param_1 + 0x80) + 0x28) = uVar14;
    uStack_1b8 = 0;
    func_0x(*(undefined2 *)(param_1 + 8),0x1f,
                    (ulonglong)*(uint *)(*(longlong *)(param_1 + 0x80) + 0x24) << 2,1);
    lVar18 = *(longlong *)(param_1 + 0x80);
    if (*(longlong *)(lVar18 + 0x28) == 0) {
      uStack_1b8 = 0;
      (*_DAT_)(1,0x1c3d790,0x1c17b40,0xc4a);
      lVar18 = *(longlong *)(param_1 + 0x80);
    }
    uVar19 = uVar20;
    if (*(int *)(lVar18 + 0x24) != 0) {
      do {
        *(undefined4 *)(uVar19 * 4 + *(longlong *)(lVar18 + 0x28)) =
             *(undefined4 *)(uVar19 * 4 + puVar22[2]);
        uVar6 = (int)uVar19 + 1;
        lVar18 = *(longlong *)(param_1 + 0x80);
        uVar19 = (ulonglong)uVar6;
      } while (uVar6 < *(uint *)(lVar18 + 0x24));
    }
    lVar18 = *(longlong *)(param_1 + 0x68);
    uStack_1b8 = lVar18 + 0x1c;
    uStack_1b0 = CONCAT62(uStack_1b0._2_6_,*(undefined2 *)(lVar18 + 0x80));
    func_0x(param_1,8,lVar18 + 4,lVar18 + 0x10);
  }
LAB_:
  if ((*(longlong *)(param_1 + 0x68) == 0) || (puVar22 == (ulonglong *)0x0)) {
    iVar7 = func_0x(*(undefined4 **)(param_1 + 0x80),**(undefined4 **)(param_1 + 0x80),
                            param_2);
    if (iVar7 == 0) {
      uStack_1b8 = CONCAT44(uStack_1b8._4_4_,*(undefined4 *)(param_1 + 0xc));
      (*_DAT_)(0xbb,0x38,0x10,4);
    }
    else {
      uStack_1b0 = uStack_1b0 & 0xffffffffffff0000;
      uStack_1b8 = 0;
      func_0x(param_1,4,0);
    }
  }
  uVar5 = func_0x(*(longlong *)(param_1 + 0x80) + 0x280);
  *(undefined4 *)(*(longlong *)(param_1 + 0x80) + 0x14) = uVar5;
  uVar5 = func_0x(*(longlong *)(param_1 + 0x80) + 0x500);
  *(undefined4 *)(*(longlong *)(param_1 + 0x80) + 0x18) = uVar5;
  uVar5 = func_0x(*(longlong *)(param_1 + 0x80) + 0x710);
  *(undefined4 *)(*(longlong *)(param_1 + 0x80) + 0x1c) = uVar5;
  func_0x(param_1);
  uStack_b8 = (**(code **)(**(longlong **)
                             (*(longlong *)
                               ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8)) + 0x90) + 0x1b0))();
  uStack_c0 = *(undefined2 *)(param_1 + 8);
  lStack_c8 = 0;
  uStack_b0 = uStack_178;
  auStack_a8 = ZEXT816(0);
  auStack_98 = ZEXT816(0);
  auStack_88 = ZEXT816(0);
  auStack_78 = ZEXT816(0);
  lStack_68 = 0;
  uStack_60 = 0;
  uStack_58 = 0;
  uStack_50 = 0;
  iVar7 = func_0x(&lStack_c8,3,1);
  if (iVar7 == 0) {
    uStack_1b8 = 0x1a85178;
    (*_DAT_)(0xbc,0x3a,0x10,8);
  }
  uStack_1b0 = CONCAT44(uStack_1b0._4_4_,0x10);
  uStack_1b8 = CONCAT44(uStack_1b8._4_4_,4);
  func_0x(&lStack_c8,0x1a85648,*(longlong *)(param_1 + 0x80) + 0xc,0);
  uStack_1b0 = lStack_c8;
  uStack_1b8 = uStack_58;
  (**(code **)(*(longlong *)auStack_a8._8_8_ + 0x18))(auStack_a8._8_8_,0,1);
  uStack_174 = 0;
  uVar19 = uVar20;
  if (((lStack_c8 != 0) && (lStack_68 != 0)) && (uStack_60 != 0)) {
    uVar6 = func_0x(&lStack_c8,0x1a8add0,&uStack_174);
    if (((lStack_68 != 0) && (uVar6 - 1 < 0xfffffffe)) && (uStack_60 != 0)) {
      uVar16 = uVar20;
      do {
        if (*(ulonglong *)(uVar16 * 0x58 + lStack_68) == (ulonglong)uVar6) {
          uVar19 = uVar16 * 0x58 + lStack_68;
          if (uVar19 != 0) goto LAB_;
          break;
        }
        uVar17 = (int)uVar16 + 1;
        uVar16 = (ulonglong)uVar17;
      } while (uVar17 < uStack_60);
    }
    uStack_1b8 = CONCAT44(uStack_1b8._4_4_,uStack_b0);
    (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
    uVar16 = *(ulonglong *)(lStack_c8 + *(longlong *)(uVar19 + 0x10));
    uVar19 = *(longlong *)(uVar19 + 8) + lStack_c8;
  }
  func_0x(*(longlong *)(param_1 + 0x80) + 0xec8,uVar19,uVar16);
  lVar18 = *(longlong *)(param_1 + 0x80);
  if (*(int *)(lVar18 + 0xec8) == 0) {
    uStack_170 = 0;
    uVar19 = uVar20;
    if (((lStack_c8 != 0) && (lStack_68 != 0)) && (uStack_60 != 0)) {
      uVar6 = func_0x(&lStack_c8,0x1a8adf8,&uStack_170);
      if (((lStack_68 != 0) && (uVar6 - 1 < 0xfffffffe)) && (uStack_60 != 0)) {
        uVar16 = uVar20;
        do {
          if (*(ulonglong *)(uVar16 * 0x58 + lStack_68) == (ulonglong)uVar6) {
            uVar19 = uVar16 * 0x58 + lStack_68;
            if (uVar19 != 0) goto LAB_;
            break;
          }
          uVar17 = (int)uVar16 + 1;
          uVar16 = (ulonglong)uVar17;
        } while (uVar17 < uStack_60);
      }
      uStack_1b8 = CONCAT44(uStack_1b8._4_4_,uStack_b0);
      (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
      uVar16 = *(ulonglong *)(lStack_c8 + *(longlong *)(uVar19 + 0x10));
      lVar18 = *(longlong *)(param_1 + 0x80);
      uVar19 = *(longlong *)(uVar19 + 8) + lStack_c8;
    }
    func_0x(lVar18 + 0xec8,uVar19,uVar16);
  }
  uStack_16c = 0;
  if (((lStack_c8 != 0) && (lStack_68 != 0)) && (uStack_60 != 0)) {
    uVar6 = func_0x(&lStack_c8,0x19e0858,&uStack_16c);
    if (((lStack_68 != 0) && (uVar6 - 1 < 0xfffffffe)) && (uStack_60 != 0)) {
      uVar16 = uVar20;
      do {
        if (*(ulonglong *)(uVar16 * 0x58 + lStack_68) == (ulonglong)uVar6) {
          uVar20 = uVar16 * 0x58 + lStack_68;
          if (uVar20 != 0) goto LAB_;
          break;
        }
        uVar17 = (int)uVar16 + 1;
        uVar16 = (ulonglong)uVar17;
      } while (uVar17 < uStack_60);
    }
    uStack_1b8 = CONCAT44(uStack_1b8._4_4_,uStack_b0);
    (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
    uVar16 = *(ulonglong *)(lStack_c8 + *(longlong *)(uVar20 + 0x10));
    uVar20 = *(longlong *)(uVar20 + 8) + lStack_c8;
  }
  func_0x(*(longlong *)(param_1 + 0x80) + 0xed8,uVar20,uVar16);
  lVar18 = *(longlong *)(param_1 + 0x80);
  if ((*(byte *)(lVar18 + 0x11) & 8) != 0) goto LAB_;
  *(undefined4 *)(lVar18 + 0xedc) =
       *(undefined4 *)(*(longlong *)(*(longlong *)(param_1 + 0x70) + 8) + 0x240);
  lVar18 = *(longlong *)(param_1 + 0x80);
  if ((*(int *)(lVar18 + 0xedc) != 0) && (((byte)*(undefined4 *)(lVar18 + 0xed8) & 9) == 9)) {
    uVar6 = 1;
    lVar21 = *(longlong *)(param_1 + 0x70);
    if (*(int *)(*(longlong *)(lVar21 + 8) + 0x230) != 0) {
      do {
        iVar7 = *(int *)(*(longlong *)(*(longlong *)(lVar21 + 8) + 0x238) + 0x20 +
                        (ulonglong)(uVar6 - 1) * 0x30);
        if (iVar7 == 0x8000003) {
          *(uint *)(lVar18 + 0xee0) = uVar6;
        }
        else if (iVar7 == 0x8000008) {
          *(uint *)(lVar18 + 0xee4) = uVar6;
        }
        lVar18 = *(longlong *)(param_1 + 0x80);
        if ((*(int *)(lVar18 + 0xee0) != 0) && (*(int *)(lVar18 + 0xee4) != 0)) break;
        uVar6 = uVar6 + 1;
        lVar21 = *(longlong *)(param_1 + 0x70);
      } while (uVar6 <= *(uint *)(*(longlong *)(lVar21 + 8) + 0x230));
    }
  }
  if (*(int *)(lVar18 + 0xee0) == 0) {
    *(undefined4 *)(lVar18 + 0xee0) = 0xffffffff;
    lVar18 = *(longlong *)(param_1 + 0x80);
  }
  if (*(int *)(lVar18 + 0xee4) == 0) {
    *(undefined4 *)(lVar18 + 0xee4) = 0xffffffff;
  }
  if (*(longlong *)(*(longlong *)(param_1 + 0x70) + 8) == 0) {
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1c3d780,0x1c17b40,0xca6);
  }
  uVar2 = *(undefined2 *)(param_1 + 8);
  bVar23 = (DAT_ & 8) != 0;
  if (bVar23) {
    uStack_140 = 1;
    iVar8 = (*_DAT_)();
    iVar7 = 0x27;
    iStack_14c = 0x27;
    iStack_150 = iVar8;
    lStack_148 = func_0x(uVar2);
  }
  else {
    uStack_140 = 0;
    iVar7 = iStack_14c;
    iVar8 = iStack_150;
  }
  lVar18 = lStack_148;
  if (*(longlong *)(param_1 + 0x80) == 0) {
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1c3d7d8,0x1c17b40,0xd34);
  }
  lVar21 = *(longlong *)(param_1 + 0x70);
  if (*(longlong *)(lVar21 + 8) == 0) {
    uStack_1b8 = 0;
    (*_DAT_)(1,0x1c3d780,0x1c17b40,0xd35);
    lVar21 = *(longlong *)(param_1 + 0x70);
  }
  uStack_1b0 = 0;
  uStack_1b8 = 0;
  func_0x(alStack_128,*(undefined8 *)(param_1 + 0x80),*(undefined8 *)(lVar21 + 8),0);
  iVar9 = (*(undefined4 **)(param_1 + 0x80))[5];
  if ((iVar9 == 0) || (iVar9 == 1)) {
LAB_:
    iVar9 = func_0x(alStack_128);
    if (iVar9 == 0) {
      uStack_1b8 = 0;
      (*_DAT_)(1,0x1c3d810,0x1c17b40,0xd4e);
    }
  }
  else if (iVar9 == 2) {
    iVar9 = func_0x(alStack_128);
    if (iVar9 == 0) {
      uStack_1b8 = 0;
      (*_DAT_)(1,0x1c3d7e8,0x1c17b40,0xd3f);
    }
  }
  else if (iVar9 == 3) {
    iVar9 = func_0x(alStack_128);
    if (iVar9 == 0) {
      uStack_1b8 = 0;
      (*_DAT_)(1,0x1c3d7e8,0x1c17b40,0xd45);
    }
    *(undefined4 *)(*(longlong *)(alStack_128[0] + 0x138) + 0xc) = 0;
  }
  else {
    if (iVar9 == 6) goto LAB_;
    uStack_1b8 = CONCAT44(uStack_1b8._4_4_,**(undefined4 **)(param_1 + 0x80));
    func_0x(0x4948,0x10,1,0x1a8adb0);
  }
  if ((bVar23) && (lVar18 != 0)) {
    iVar9 = (*_DAT_)();
    piVar1 = (int *)(lVar18 + 8 + (longlong)iVar7 * 4);
    *piVar1 = *piVar1 + (iVar9 - iVar8);
  }
  func_0x(param_1);
  lVar18 = *(longlong *)(param_1 + 0x80);
LAB_:
  if ((*(int *)(lVar18 + 0xedc) != 0) && (((byte)*(undefined4 *)(lVar18 + 0xed8) & 9) == 9)) {
    func_0x(lVar18 + 0xb80,lVar18 + 0x710,0x202);
    *(undefined4 *)(*(longlong *)(param_1 + 0x80) + 0x20) =
         *(undefined4 *)(*(longlong *)(param_1 + 0x80) + 0x1c);
  }
  func_0x(&lStack_c8);
  lVar18 = lStack_160;
  if ((iStack_158 != 0) && (lStack_160 != 0)) {
    iVar7 = (*_DAT_)();
    piVar1 = (int *)(lVar18 + 8 + (longlong)iStack_164 * 4);
    *piVar1 = *piVar1 + (iVar7 - iStack_168);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_1d8);
  return;
LAB_:
  puVar22 = (ulonglong *)puVar22[9];
  if (puVar22 == (ulonglong *)0x0) goto LAB_;
  goto LAB_;
}

