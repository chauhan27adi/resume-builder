
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint *param_2,undefined8 *param_3,undefined *param_4)

{
  ushort *puVar1;
  uint *puVar2;
  longlong *plVar3;
  bool bVar4;
  bool bVar5;
  short *psVar6;
  byte bVar7;
  char cVar8;
  ushort uVar9;
  ushort uVar10;
  ushort uVar11;
  int iVar12;
  short *psVar13;
  longlong lVar14;
  undefined8 uVar15;
  longlong lVar16;
  short sVar17;
  uint uVar18;
  ulonglong uVar19;
  uint uVar20;
  undefined8 *puVar21;
  ushort *puVar22;
  ulonglong uVar23;
  ulonglong uVar24;
  undefined8 *puVar25;
  undefined8 *puVar26;
  byte *pbVar27;
  longlong lVar28;
  uint uVar29;
  ushort *puVar30;
  uint *puVar31;
  undefined auStack_f8 [32];
  uint *puStack_d8;
  undefined4 uStack_d0;
  uint *puStack_c8;
  uint uStack_c0;
  uint auStack_b8 [2];
  short *psStack_b0;
  uint uStack_a8;
  uint uStack_a4;
  ushort *puStack_a0;
  undefined8 *puStack_98;
  undefined *puStack_90;
  undefined auStack_88 [8];
  undefined auStack_80 [8];
  longlong lStack_78;
  uint *puStack_70;
  undefined auStack_68 [8];
  uint auStack_60 [2];
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_f8;
  puVar25 = (undefined8 *)0x0;
  uVar10 = 0;
  bVar5 = true;
  puStack_98 = param_3;
  puStack_90 = param_4;
  lStack_78 = param_1;
  puStack_70 = param_2;
  if ((*(longlong *)(param_1 + 0x280) == 0) ||
     (*(int *)(**(longlong **)(*(longlong *)(*(longlong *)(param_1 + 0x280) + 8) + 0x160) + 0x1c) ==
      0)) {
    puStack_d8 = (uint *)0x0;
    (*_DAT_)(1,0xbae638,0xb584a8,0x3ca);
  }
  psVar13 = (short *)(***(code ***)**(undefined8 **)(param_2 + 4))();
  if (*(char *)(param_2 + 6) != '\0') {
    *param_2 = *param_2 | ~*(uint *)(*(longlong *)(param_2 + 2) + 0x268) & 0x40;
    puVar2 = (uint *)(*(longlong *)(param_2 + 2) + 0x268);
    *puVar2 = *puVar2 | 0x40;
  }
  puVar1 = (ushort *)(psVar13 + 1);
  puVar2 = *(uint **)(param_1 + 0x310);
  bVar7 = *(byte *)(puVar2 + 8);
  psStack_b0 = psVar13;
  if (*psVar13 == 0) {
    uVar18 = *puVar2;
    if ((uVar18 & 0xc0000000) == 0x80000000) {
      iVar12 = func_0x(puVar1);
      if (iVar12 == 0) {
LAB_:
        auStack_b8[0] = 0;
        puVar21 = puVar25;
        puVar31 = param_2;
      }
      else {
        puVar21 = (undefined8 *)func_0x(psVar13 + 0x15,puVar2,auStack_b8,auStack_88);
        puVar31 = param_2;
      }
    }
    else {
      puVar31 = puStack_70;
      if (((bVar7 & 2) != 0) || ((*(byte *)((longlong)puVar2 + 6) & 0x10) != 0)) {
        pbVar27 = *(byte **)(psVar13 + 4);
        bVar4 = bVar5;
        if ((*pbVar27 & 0x10) == 0) {
          uVar11 = uVar10;
          if ((1 << (*pbVar27 & 0xe) & 0x1105U) != 0) goto LAB_;
LAB_:
          if ((bVar7 & 2) != 0) goto LAB_;
        }
        else {
          uVar20 = *(uint *)(psVar13 + 8);
          if ((int)uVar20 <= (int)uVar18) {
LAB_:
            bVar4 = false;
            uVar11 = ~(*(ushort *)((longlong)puVar2 + 6) >> 4) & 1;
            goto LAB_;
          }
          if ((uint)*(ushort *)(pbVar27 + uVar20) < (uint)*(ushort *)(puVar2 + 1))
          goto LAB_;
          if ((bVar7 & 2) == 0) goto LAB_;
          uVar29 = *(ushort *)(puVar2 + 1) - 1;
          uVar11 = pbVar27[(ulonglong)(uVar29 >> 3) + (ulonglong)uVar20 + 2] >> ((byte)uVar29 & 7) &
                   1;
LAB_:
          if (uVar11 != 0) {
            auStack_b8[0] = 0;
            puVar21 = (undefined8 *)0x0;
            goto LAB_;
          }
        }
        if ((!bVar4) && ((*(byte *)((longlong)puVar2 + 6) & 0x10) != 0)) {
          puVar21 = (undefined8 *)(*(uint **)(puVar2 + 2) + 1);
          auStack_b8[0] = **(uint **)(puVar2 + 2);
          goto LAB_;
        }
      }
LAB_:
      if ((int)uVar18 < 0) {
        if (*(int *)(psVar13 + 2) == 0) {
          pbVar27 = *(byte **)(psVar13 + 4);
          uVar18 = *(uint *)(psVar13 + 8);
          uVar19 = (ulonglong)uVar18;
          *puVar1 = 0;
          *(uint *)(psVar13 + 10) = uVar18;
          bVar7 = *pbVar27;
          if ((bVar7 & 0x10) != 0) {
            uVar18 = uVar18 + 2 + (*(ushort *)(pbVar27 + uVar19) + 7 >> 3);
            uVar19 = (ulonglong)uVar18;
            *(uint *)(psVar13 + 10) = uVar18;
            bVar7 = *pbVar27;
          }
          if ((bVar7 & 0x20) == 0) {
            *(int *)(psVar13 + 2) = (int)uVar19;
            psVar13[0xe] = 0;
            *(int *)(psVar13 + 0xc) = (int)uVar19;
          }
          else {
            puVar30 = (ushort *)(pbVar27 + uVar19);
            uVar11 = *puVar30;
            psVar13[0xe] = uVar11;
            puStack_a0 = puVar30;
            if (uVar11 == 0) {
              cVar8 = func_0x(0x10e0c90);
              if (((cVar8 != '\0') && (lVar14 = func_0x(), lVar14 != 0)) &&
                 (*(char *)(lVar14 + 0x499) != '\0')) {
                cVar8 = func_0x(0x10e0c90);
                if (cVar8 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  puStack_d8 = (uint *)0x0;
                  (*_DAT_)(1,0x9d069c,0xaf0788,0x80f);
                }
              }
              func_0x(*(undefined8 *)(psVar13 + 4),3);
              uVar19 = (ulonglong)*(uint *)(psVar13 + 10);
              uVar11 = psVar13[0xe];
            }
            uVar18 = (int)uVar19 + (uVar11 + 1) * 2;
            *(uint *)(psVar13 + 0xc) = uVar18;
            if (0x1f9e < uVar18) {
              cVar8 = func_0x(0x10e0c90);
              if (((cVar8 != '\0') && (lVar14 = func_0x(), lVar14 != 0)) &&
                 (*(char *)(lVar14 + 0x499) != '\0')) {
                cVar8 = func_0x(0x10e0c90);
                if (cVar8 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_d8 = (uint *)0x0;
                  (*_DAT_)(1,0x9d069c,0xaf0788,0x816);
                }
              }
              func_0x(*(undefined8 *)(psVar13 + 4),4);
              uVar11 = psVar13[0xe];
              uVar18 = *(uint *)(psVar13 + 0xc);
            }
            uVar19 = (ulonglong)uVar11;
            uVar11 = puVar30[uVar19];
            *(uint *)(psVar13 + 2) = uVar11 & 0x7fff;
            if ((uVar11 & 0x7fff) < uVar18) {
              cVar8 = func_0x(0x10e0c90);
              if (((cVar8 != '\0') && (lVar14 = func_0x(), lVar14 != 0)) &&
                 (*(char *)(lVar14 + 0x499) != '\0')) {
                cVar8 = func_0x(0x10e0c90);
                if (cVar8 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_d8 = (uint *)0x0;
                  (*_DAT_)(1,0x9d069c,0xaf0788,0x81d);
                }
              }
              func_0x(*(undefined8 *)(psVar13 + 4),4);
              uVar18 = *(uint *)(psVar13 + 0xc);
              uVar19 = (ulonglong)(ushort)psVar13[0xe];
            }
            puVar22 = puVar30;
            puVar21 = puVar25;
            if ((short)uVar19 != 0) {
              do {
                puVar30 = puVar30 + 1;
                uVar20 = *puVar30 & 0x7fff;
                if ((uVar20 < uVar18) || (*(uint *)(psVar13 + 2) < uVar20)) {
                  cVar8 = func_0x(0x10e0c90);
                  if ((cVar8 != '\0') &&
                     ((lVar14 = func_0x(), lVar14 != 0 &&
                      (*(char *)(lVar14 + 0x499) != '\0')))) {
                    cVar8 = func_0x(0x10e0c90);
                    if (cVar8 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      puStack_d8 = (uint *)0x0;
                      (*_DAT_)(1,0x9d069c,0xaf0788,0x82a);
                    }
                  }
                  func_0x(*(undefined8 *)(psVar13 + 4),4);
                }
                uVar19 = (ulonglong)(ushort)psVar13[0xe];
                uVar29 = (int)puVar21 + 1;
                puVar22 = puStack_a0;
                puVar21 = (undefined8 *)(ulonglong)uVar29;
                uVar18 = uVar20;
              } while ((int)uVar29 < (int)(uint)(ushort)psVar13[0xe]);
            }
            puVar30 = puStack_a0;
            if ((short)puVar22[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
              pbVar27 = *(byte **)(psVar13 + 4);
              do {
                uVar18 = *(ushort *)(pbVar27 + uVar19 * 2 + (ulonglong)*(uint *)(psVar13 + 10)) &
                         0x7fff;
                if ((int)uVar19 == 1) {
                  uVar20 = *(uint *)(psVar13 + 0xc);
                  uVar29 = uVar20;
LAB_:
                  if ((uVar18 < uVar20) || (*(uint *)(psVar13 + 2) < uVar18)) goto LAB_;
                }
                else {
                  uVar29 = *(uint *)(psVar13 + 0xc);
                  uVar20 = *(ushort *)
                            (pbVar27 + uVar19 * 2 + ((ulonglong)*(uint *)(psVar13 + 10) - 2)) &
                           0x7fff;
                  if (uVar29 <= uVar20) goto LAB_;
LAB_:
                  func_0x(pbVar27,7);
                  uVar29 = *(uint *)(psVar13 + 0xc);
                }
                if ((uVar20 < uVar29) || (*(uint *)(psVar13 + 2) < uVar20)) goto LAB_;
                pbVar27 = *(byte **)(psVar13 + 4);
                if (*(ushort *)(pbVar27 + uVar20) == 5) {
                  *puVar1 = *puVar1 | 2;
                  psVar13[0xe] = psVar13[0xe] + -1;
                  uVar24 = (ulonglong)(uVar20 & 0xffff);
                  psVar13[0x15] = (short)uVar20;
                  uVar19 = *(ulonglong *)(psVar13 + 4);
                  uVar11 = psVar13[0x16] & 0xc7ffU;
                  if ((*(ushort *)(uVar24 + 2 + uVar19) >> 0xe & 1) != 0) {
                    uVar11 = *(ushort *)(uVar24 + 2 + uVar19) & 0x3800 | psVar13[0x16] & 0xc7ffU;
                  }
                  psVar13[0x16] = uVar11;
                  uVar9 = (uVar11 ^ *(ushort *)(uVar24 + 2 + uVar19)) & 0x7ff ^ uVar11;
                  psVar13[0x16] = uVar9;
                  uVar23 = (ulonglong)((uVar9 & 0x7ff) * 2) + 4 + uVar19 + (uVar11 >> 0xb & 7) * 2 +
                           uVar24;
                  if (uVar23 < uVar24 + uVar19) {
                    func_0x(uVar24 + uVar19,0x19);
                    uVar9 = psVar13[0x16];
                    uVar24 = (ulonglong)(ushort)psVar13[0x15];
                    uVar19 = (ulonglong)*(uint *)(psVar13 + 4);
                  }
                  if (uVar18 - uVar20 <
                      (((uVar9 & 0x7ff) * 2 - (int)uVar24) - (int)uVar19) + (int)uVar23) {
                    func_0x(uVar24 + *(longlong *)(psVar13 + 4),0x19);
                    uVar9 = psVar13[0x16];
                  }
                  if (((uVar9 & 0x3800) != 0) &&
                     (puVar30 = (ushort *)
                                (*(longlong *)(psVar13 + 4) + 4 + (ulonglong)(ushort)psVar13[0x15]),
                     puVar21 = puVar25, (uVar9 & 0x3800) != 0)) {
                    do {
                      if ((uVar9 & 0x7ff) < (*puVar30 & 0x7ff)) {
                        func_0x((ulonglong)(ushort)psVar13[0x15] +
                                        *(longlong *)(psVar13 + 4),0x1a);
                        uVar9 = psVar13[0x16];
                      }
                      uVar18 = (int)puVar21 + 1;
                      puVar21 = (undefined8 *)(ulonglong)uVar18;
                      puVar30 = puVar30 + 1;
                    } while ((int)uVar18 < (int)(uVar9 >> 0xb & 7));
                  }
                  goto LAB_;
                }
                if (*(ushort *)(pbVar27 + uVar20) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar11 = psVar13[0xe] - 1;
                psVar13[0xe] = uVar11;
                if (uVar11 == 0) goto LAB_;
                uVar19 = (ulonglong)uVar11;
              } while ((short)puVar30[(ulonglong)(uVar11 - 1) + 1] < 0);
              uVar19 = (ulonglong)*(uint *)(psVar13 + 2);
            }
            else {
LAB_:
              pbVar27 = *(byte **)(psVar13 + 4);
              uVar19 = (ulonglong)*(uint *)(psVar13 + 2);
            }
          }
          if ((*pbVar27 & 0x40) == 0) {
            *(undefined4 *)(psVar13 + 0x13) = 0;
          }
          else {
            *(int *)(psVar13 + 0x13) = (int)uVar19;
            *(int *)(psVar13 + 2) = (int)uVar19 + 0xe;
            uVar15 = func_0x(puVar1);
            func_0x(uVar15,auStack_80);
            iVar12 = func_0x(auStack_80);
            *(int *)(psVar13 + 2) = *(int *)(psVar13 + 2) + iVar12;
            uVar19 = (ulonglong)*(uint *)(psVar13 + 2);
          }
          iVar12 = (int)uVar19;
          if ((*(ulonglong *)(psVar13 + 0xf) != 0) &&
             (*(ulonglong *)(psVar13 + 0xf) < uVar19 + *(longlong *)(psVar13 + 4))) {
            cVar8 = func_0x(0x10e0c90);
            if ((cVar8 != '\0') &&
               ((lVar14 = func_0x(), lVar14 != 0 &&
                (*(char *)(lVar14 + 0x499) != '\0')))) {
              cVar8 = func_0x(0x10e0c90);
              if (cVar8 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                puStack_d8 = (uint *)0x0;
                (*_DAT_)(1,0x9d069c,0xaf0788,0x886);
              }
            }
            func_0x(*(undefined8 *)(psVar13 + 4),0x12);
            iVar12 = *(int *)(psVar13 + 2);
          }
          if (0x3f3b < iVar12 - 1U) {
            cVar8 = func_0x(0x10e0c90);
            if (((cVar8 != '\0') && (lVar14 = func_0x(), lVar14 != 0)) &&
               (*(char *)(lVar14 + 0x499) != '\0')) {
              cVar8 = func_0x(0x10e0c90);
              if (cVar8 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                puStack_d8 = (uint *)0x0;
                (*_DAT_)(1,0x9d069c,0xaf0788,0x88b);
              }
            }
            func_0x(*(undefined8 *)(psVar13 + 4),5);
          }
        }
LAB_:
        sVar17 = -*(short *)puVar2;
        puVar31 = puStack_70;
        param_1 = lStack_78;
        if ((*(byte *)((longlong)puVar2 + 6) & 0x10) != 0) {
          bVar7 = **(byte **)(psVar13 + 4);
          if ((bVar7 & 0x10) == 0) {
            if ((1 << (bVar7 & 0xe) & 0x1105U) != 0) {
LAB_:
              puVar21 = (undefined8 *)(*(uint **)(puVar2 + 2) + 1);
              auStack_b8[0] = **(uint **)(puVar2 + 2);
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(psVar13 + 8) <= (int)*puVar2) ||
                  (*(ushort *)(*(byte **)(psVar13 + 4) + *(uint *)(psVar13 + 8)) <
                   *(ushort *)(puVar2 + 1))) goto LAB_;
        }
        lVar14 = (longlong)sVar17;
        if ((uint)(ushort)psVar13[0xe] < (uint)(int)sVar17) {
          auStack_b8[0] = 0;
          puVar21 = *(undefined8 **)(psVar13 + 4);
        }
        else {
          lVar28 = *(longlong *)(psVar13 + 4);
          lVar16 = (ulonglong)*(uint *)(psVar13 + 10) + lVar28;
          if (sVar17 == 1) {
            uVar20 = *(ushort *)(lVar16 + lVar14 * 2) & 0x7fff;
            uVar18 = *(uint *)(psStack_b0 + 0xc);
LAB_:
            if ((uVar20 < uVar18) || (*(uint *)(psVar13 + 2) < uVar20)) goto LAB_;
          }
          else {
            uVar18 = *(ushort *)(lVar16 + -2 + lVar14 * 2) & 0x7fff;
            uVar20 = *(ushort *)(lVar16 + lVar14 * 2) & 0x7fff;
            lVar28 = *(longlong *)(psVar13 + 4);
            if (*(uint *)(psStack_b0 + 0xc) <= uVar18) goto LAB_;
LAB_:
            func_0x(lVar28,7);
          }
          puVar21 = (undefined8 *)((ulonglong)uVar18 + *(longlong *)(psVar13 + 4));
          puVar31 = puStack_70;
          param_1 = lStack_78;
          auStack_b8[0] = uVar20 - uVar18;
        }
      }
      else {
        uVar11 = *(ushort *)((longlong)puVar2 + 6);
        if ((uVar11 & 8) == 0) {
          uVar20 = (uint)*(ushort *)(puVar2 + 0xe);
          if ((uVar11 & 0x10) != 0) {
            bVar7 = **(byte **)(psVar13 + 4);
            if ((bVar7 & 0x10) == 0) {
              if ((1 << (bVar7 & 0xe) & 0x1105U) != 0) {
LAB_:
                auStack_b8[0] = **(uint **)(puVar2 + 2);
                puVar21 = (undefined8 *)(*(uint **)(puVar2 + 2) + 1);
                if ((uVar20 != 0) && (auStack_b8[0] != uVar20)) {
                  puStack_d8 = (uint *)0x0;
                  (*_DAT_)(1,0xb7eae0,0xb7d448,0x381);
                  puVar31 = puStack_70;
                }
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(psVar13 + 8) <= (int)uVar18) ||
                    (*(ushort *)(*(byte **)(psVar13 + 4) + *(uint *)(psVar13 + 8)) <
                     *(ushort *)(puVar2 + 1))) goto LAB_;
          }
          puVar21 = (undefined8 *)((longlong)(int)*puVar2 + *(longlong *)(psVar13 + 4));
          auStack_b8[0] = uVar20;
        }
        else {
          puVar21 = (undefined8 *)0x755330;
          auStack_b8[0] = 1;
          if ((*(byte *)(*(longlong *)(psVar13 + 4) + (longlong)(int)uVar18) &
              (byte)(1 << ((byte)uVar11 & 7))) == 0) {
            puVar21 = (undefined8 *)0x755331;
          }
        }
      }
    }
  }
  else {
    puStack_d8 = &uStack_a8;
    uStack_a8 = 0;
    puVar21 = (undefined8 *)func_0x(puVar1,puVar2);
    puVar31 = param_2;
    if ((((*psStack_b0 != 0) &&
         (plVar3 = *(longlong **)(psStack_b0 + 8), puVar31 = param_2, plVar3 != (longlong *)0x0)) &&
        (puVar31 = param_2, *plVar3 != 0)) &&
       ((puVar31 = param_2, (*(byte *)((longlong)puVar2 + 6) & 8) == 0 &&
        (puVar31 = param_2, (uStack_a8 & 1) == 0)))) {
      if ((puVar21 == (undefined8 *)0x0) || (puVar21 == (undefined8 *)0x755330)) goto LAB_;
      uStack_c0 = uStack_a8;
      puStack_c8 = auStack_b8;
      puStack_d8 = auStack_60;
      uStack_d0 = 8;
      puVar21 = (undefined8 *)func_0x(plVar3,puVar2,puVar21,auStack_b8[0]);
      puVar31 = param_2;
    }
  }
LAB_:
  psVar6 = psStack_b0;
  if ((auStack_b8[0] == 0) || (puVar21 == (undefined8 *)0x0)) {
    if (*(longlong *)(puVar31 + 4) != 0) {
      *(uint *)(*(longlong *)(puVar31 + 2) + 0x268) =
           *(uint *)(*(longlong *)(puVar31 + 2) + 0x268) & ~*puVar31;
      (**(code **)(***(longlong ***)(puVar31 + 4) + 8))();
      *(undefined8 *)(puVar31 + 4) = 0;
    }
    uVar19 = *(ulonglong *)(*(longlong *)(param_1 + 0x280) + 0x14);
    puStack_d8 = (uint *)(((uVar19 >> 0x20 & 0xffff) << 0x20 | uVar19 & 0xffffffff) << 0x10);
    (*_DAT_)(0xdf,0xd,0x10,6);
    goto LAB_;
  }
  *puStack_98 = *puVar21;
  puVar21 = *(undefined8 **)(param_1 + 0x318);
  bVar7 = *(byte *)(puVar21 + 4);
  puStack_98 = puVar21;
  if (*psStack_b0 == 0) {
    uVar20 = *(uint *)puVar21;
    if ((uVar20 & 0xc0000000) == 0x80000000) {
      iVar12 = func_0x(puVar1);
      if (iVar12 != 0) {
        puVar26 = (undefined8 *)func_0x(psVar13 + 0x15,puVar21,auStack_b8,&puStack_a0);
        uVar18 = auStack_b8[0];
        goto LAB_;
      }
LAB_:
      auStack_b8[0] = 0;
      puVar26 = (undefined8 *)0x0;
      uVar18 = auStack_b8[0];
    }
    else {
      if (((bVar7 & 2) != 0) || ((*(byte *)((longlong)puVar21 + 6) & 0x10) != 0)) {
        pbVar27 = *(byte **)(psVar13 + 4);
        if ((*pbVar27 & 0x10) == 0) {
          if ((1 << (*pbVar27 & 0xe) & 0x1105U) != 0) goto LAB_;
LAB_:
          if ((bVar7 & 2) != 0) goto LAB_;
        }
        else {
          uVar18 = *(uint *)(psVar13 + 8);
          if ((int)uVar18 <= (int)uVar20) {
LAB_:
            uVar10 = ~(*(ushort *)((longlong)puVar21 + 6) >> 4) & 1;
            bVar5 = false;
            goto LAB_;
          }
          if ((uint)*(ushort *)(pbVar27 + uVar18) < (uint)*(ushort *)((longlong)puVar21 + 4))
          goto LAB_;
          if ((bVar7 & 2) == 0) goto LAB_;
          uVar29 = *(ushort *)((longlong)puVar21 + 4) - 1;
          uVar10 = pbVar27[(ulonglong)(uVar29 >> 3) + (ulonglong)uVar18 + 2] >> ((byte)uVar29 & 7) &
                   1;
LAB_:
          if (uVar10 != 0) goto LAB_;
        }
        if ((!bVar5) && ((*(byte *)((longlong)puVar21 + 6) & 0x10) != 0)) {
          puVar26 = (undefined8 *)((uint *)puVar21[1] + 1);
          uVar18 = *(uint *)puVar21[1];
          goto LAB_;
        }
      }
LAB_:
      if ((int)uVar20 < 0) {
        if (*(int *)(psVar13 + 2) == 0) {
          pbVar27 = *(byte **)(psVar13 + 4);
          uVar18 = *(uint *)(psVar13 + 8);
          uVar19 = (ulonglong)uVar18;
          *puVar1 = 0;
          *(uint *)(psVar13 + 10) = uVar18;
          bVar7 = *pbVar27;
          if ((bVar7 & 0x10) != 0) {
            uVar18 = uVar18 + 2 + (*(ushort *)(pbVar27 + uVar19) + 7 >> 3);
            uVar19 = (ulonglong)uVar18;
            *(uint *)(psVar13 + 10) = uVar18;
            bVar7 = *pbVar27;
          }
          if ((bVar7 & 0x20) == 0) {
            *(int *)(psVar13 + 2) = (int)uVar19;
            psVar13[0xe] = 0;
            *(int *)(psVar13 + 0xc) = (int)uVar19;
          }
          else {
            puVar30 = (ushort *)(pbVar27 + uVar19);
            uVar10 = *puVar30;
            psVar13[0xe] = uVar10;
            if (uVar10 == 0) {
              cVar8 = func_0x(0x10e0c90);
              if (((cVar8 != '\0') && (lVar14 = func_0x(), lVar14 != 0)) &&
                 (*(char *)(lVar14 + 0x499) != '\0')) {
                cVar8 = func_0x(0x10e0c90);
                if (cVar8 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  puStack_d8 = (uint *)0x0;
                  (*_DAT_)(1,0x9d069c,0xaf0788,0x80f);
                }
              }
              func_0x(*(undefined8 *)(psVar13 + 4),3);
              uVar19 = (ulonglong)*(uint *)(psVar13 + 10);
              uVar10 = psVar13[0xe];
            }
            uVar18 = (int)uVar19 + (uVar10 + 1) * 2;
            *(uint *)(psVar13 + 0xc) = uVar18;
            if (0x1f9e < uVar18) {
              cVar8 = func_0x(0x10e0c90);
              if (((cVar8 != '\0') && (lVar14 = func_0x(), lVar14 != 0)) &&
                 (*(char *)(lVar14 + 0x499) != '\0')) {
                cVar8 = func_0x(0x10e0c90);
                if (cVar8 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_d8 = (uint *)0x0;
                  (*_DAT_)(1,0x9d069c,0xaf0788,0x816);
                }
              }
              func_0x(*(undefined8 *)(psVar13 + 4),4);
              uVar10 = psVar13[0xe];
              uVar18 = *(uint *)(psVar13 + 0xc);
            }
            uVar19 = (ulonglong)uVar10;
            uVar10 = puVar30[uVar19];
            *(uint *)(psVar13 + 2) = uVar10 & 0x7fff;
            if ((uVar10 & 0x7fff) < uVar18) {
              cVar8 = func_0x(0x10e0c90);
              if (((cVar8 != '\0') && (lVar14 = func_0x(), lVar14 != 0)) &&
                 (*(char *)(lVar14 + 0x499) != '\0')) {
                cVar8 = func_0x(0x10e0c90);
                if (cVar8 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_d8 = (uint *)0x0;
                  (*_DAT_)(1,0x9d069c,0xaf0788,0x81d);
                }
              }
              func_0x(*(undefined8 *)(psVar13 + 4),4);
              uVar18 = *(uint *)(psVar13 + 0xc);
              uVar19 = (ulonglong)(ushort)psVar13[0xe];
            }
            puVar26 = puVar25;
            puVar22 = puVar30;
            if ((short)uVar19 != 0) {
              do {
                uVar20 = puVar22[1] & 0x7fff;
                if ((uVar20 < uVar18) || (*(uint *)(psVar13 + 2) < uVar20)) {
                  cVar8 = func_0x(0x10e0c90);
                  if ((cVar8 != '\0') &&
                     ((lVar14 = func_0x(), lVar14 != 0 &&
                      (*(char *)(lVar14 + 0x499) != '\0')))) {
                    cVar8 = func_0x(0x10e0c90);
                    if (cVar8 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      puStack_d8 = (uint *)0x0;
                      (*_DAT_)(1,0x9d069c,0xaf0788,0x82a);
                    }
                  }
                  func_0x(*(undefined8 *)(psVar13 + 4),4);
                }
                uVar19 = (ulonglong)(ushort)psVar13[0xe];
                uVar29 = (int)puVar26 + 1;
                puVar26 = (undefined8 *)(ulonglong)uVar29;
                puVar21 = puStack_98;
                puVar22 = puVar22 + 1;
                uVar18 = uVar20;
              } while ((int)uVar29 < (int)(uint)(ushort)psVar13[0xe]);
            }
            if ((short)puVar30[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
              pbVar27 = *(byte **)(psVar13 + 4);
              do {
                uVar18 = *(ushort *)(pbVar27 + uVar19 * 2 + (ulonglong)*(uint *)(psVar13 + 10)) &
                         0x7fff;
                if ((int)uVar19 == 1) {
                  uVar20 = *(uint *)(psVar13 + 0xc);
                  uVar29 = uVar20;
LAB_:
                  if ((uVar18 < uVar20) || (*(uint *)(psVar13 + 2) < uVar18)) goto LAB_;
                }
                else {
                  uVar29 = *(uint *)(psVar13 + 0xc);
                  uVar20 = *(ushort *)
                            (pbVar27 + uVar19 * 2 + ((ulonglong)*(uint *)(psVar13 + 10) - 2)) &
                           0x7fff;
                  if (uVar29 <= uVar20) goto LAB_;
LAB_:
                  func_0x(pbVar27,7);
                  uVar29 = *(uint *)(psVar13 + 0xc);
                }
                if ((uVar20 < uVar29) || (*(uint *)(psVar13 + 2) < uVar20)) goto LAB_;
                pbVar27 = *(byte **)(psVar13 + 4);
                if (*(ushort *)(pbVar27 + uVar20) == 5) {
                  *puVar1 = *puVar1 | 2;
                  psVar13[0xe] = psVar13[0xe] + -1;
                  uVar19 = *(ulonglong *)(psVar13 + 4);
                  uVar24 = (ulonglong)(uVar20 & 0xffff);
                  psVar13[0x15] = (short)uVar20;
                  uVar10 = psVar13[0x16] & 0xc7ffU;
                  if ((*(ushort *)(uVar24 + 2 + uVar19) >> 0xe & 1) != 0) {
                    uVar10 = *(ushort *)(uVar24 + 2 + uVar19) & 0x3800 | psVar13[0x16] & 0xc7ffU;
                  }
                  psVar13[0x16] = uVar10;
                  uVar23 = (ulonglong)(ushort)psVar13[0x15];
                  uVar11 = (uVar10 ^ *(ushort *)(uVar24 + 2 + uVar19)) & 0x7ff ^ uVar10;
                  psVar13[0x16] = uVar11;
                  uVar24 = (ulonglong)((uVar11 & 0x7ff) * 2) + 4 + uVar19 + (uVar10 >> 0xb & 7) * 2
                           + uVar23;
                  if (uVar24 < uVar23 + uVar19) {
                    func_0x(uVar23 + uVar19,0x19);
                    uVar11 = psVar13[0x16];
                    uVar23 = (ulonglong)(ushort)psVar13[0x15];
                    uVar19 = (ulonglong)*(uint *)(psVar13 + 4);
                  }
                  if (uVar18 - uVar20 <
                      (((uVar11 & 0x7ff) * 2 - (int)uVar23) - (int)uVar19) + (int)uVar24) {
                    func_0x(uVar23 + *(longlong *)(psVar13 + 4),0x19);
                    uVar11 = psVar13[0x16];
                  }
                  if (((uVar11 & 0x3800) != 0) &&
                     (puVar30 = (ushort *)
                                (*(longlong *)(psVar13 + 4) + 4 + (ulonglong)(ushort)psVar13[0x15]),
                     (uVar11 & 0x3800) != 0)) {
                    do {
                      if ((uVar11 & 0x7ff) < (*puVar30 & 0x7ff)) {
                        func_0x((ulonglong)(ushort)psVar13[0x15] +
                                        *(longlong *)(psVar13 + 4),0x1a);
                        uVar11 = psVar13[0x16];
                      }
                      uVar18 = (int)puVar25 + 1;
                      puVar25 = (undefined8 *)(ulonglong)uVar18;
                      puVar30 = puVar30 + 1;
                    } while ((int)uVar18 < (int)(uVar11 >> 0xb & 7));
                  }
                  goto LAB_;
                }
                if (*(ushort *)(pbVar27 + uVar20) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar10 = psVar13[0xe] - 1;
                psVar13[0xe] = uVar10;
                if (uVar10 == 0) goto LAB_;
                uVar19 = (ulonglong)uVar10;
              } while ((short)puVar30[(ulonglong)(uVar10 - 1) + 1] < 0);
              uVar19 = (ulonglong)*(uint *)(psVar13 + 2);
            }
            else {
LAB_:
              pbVar27 = *(byte **)(psVar13 + 4);
              uVar19 = (ulonglong)*(uint *)(psVar13 + 2);
            }
          }
          if ((*pbVar27 & 0x40) == 0) {
            *(undefined4 *)(psVar13 + 0x13) = 0;
          }
          else {
            *(int *)(psVar13 + 0x13) = (int)uVar19;
            *(int *)(psVar13 + 2) = (int)uVar19 + 0xe;
            uVar15 = func_0x(puVar1);
            func_0x(uVar15,auStack_68);
            iVar12 = func_0x(auStack_68);
            *(int *)(psVar13 + 2) = *(int *)(psVar13 + 2) + iVar12;
            uVar19 = (ulonglong)*(uint *)(psVar13 + 2);
          }
          iVar12 = (int)uVar19;
          if ((*(ulonglong *)(psVar13 + 0xf) != 0) &&
             (*(ulonglong *)(psVar13 + 0xf) < uVar19 + *(longlong *)(psVar13 + 4))) {
            cVar8 = func_0x(0x10e0c90);
            if ((cVar8 != '\0') &&
               ((lVar14 = func_0x(), lVar14 != 0 &&
                (*(char *)(lVar14 + 0x499) != '\0')))) {
              cVar8 = func_0x(0x10e0c90);
              if (cVar8 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                puStack_d8 = (uint *)0x0;
                (*_DAT_)(1,0x9d069c,0xaf0788,0x886);
              }
            }
            func_0x(*(undefined8 *)(psVar13 + 4),0x12);
            iVar12 = *(int *)(psVar13 + 2);
          }
          if (0x3f3b < iVar12 - 1U) {
            cVar8 = func_0x(0x10e0c90);
            if (((cVar8 != '\0') && (lVar14 = func_0x(), lVar14 != 0)) &&
               (*(char *)(lVar14 + 0x499) != '\0')) {
              cVar8 = func_0x(0x10e0c90);
              if (cVar8 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                puStack_d8 = (uint *)0x0;
                (*_DAT_)(1,0x9d069c,0xaf0788,0x88b);
              }
            }
            func_0x(*(undefined8 *)(psVar13 + 4),5);
          }
        }
LAB_:
        sVar17 = -*(short *)puVar21;
        if ((*(byte *)((longlong)puVar21 + 6) & 0x10) != 0) {
          bVar7 = **(byte **)(psVar13 + 4);
          if ((bVar7 & 0x10) == 0) {
            if ((1 << (bVar7 & 0xe) & 0x1105U) != 0) {
LAB_:
              puVar26 = (undefined8 *)((uint *)puVar21[1] + 1);
              uVar18 = *(uint *)puVar21[1];
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(psVar13 + 8) <= (int)*(uint *)puVar21) ||
                  (*(ushort *)(*(byte **)(psVar13 + 4) + *(uint *)(psVar13 + 8)) <
                   *(ushort *)((longlong)puVar21 + 4))) goto LAB_;
        }
        lVar14 = (longlong)sVar17;
        if ((uint)(ushort)psVar13[0xe] < (uint)(int)sVar17) {
          auStack_b8[0] = 0;
          puVar26 = *(undefined8 **)(psVar13 + 4);
          uVar18 = auStack_b8[0];
        }
        else {
          lVar28 = *(longlong *)(psVar13 + 4);
          lVar16 = (ulonglong)*(uint *)(psVar13 + 10) + lVar28;
          if (sVar17 == 1) {
            uVar20 = *(ushort *)(lVar16 + lVar14 * 2) & 0x7fff;
            uVar18 = *(uint *)(psStack_b0 + 0xc);
LAB_:
            if ((uVar20 < uVar18) || (*(uint *)(psVar13 + 2) < uVar20)) goto LAB_;
          }
          else {
            uVar18 = *(ushort *)(lVar16 + -2 + lVar14 * 2) & 0x7fff;
            uVar20 = *(ushort *)(lVar16 + lVar14 * 2) & 0x7fff;
            lVar28 = *(longlong *)(psVar13 + 4);
            if (*(uint *)(psStack_b0 + 0xc) <= uVar18) goto LAB_;
LAB_:
            func_0x(lVar28,7);
          }
          puVar26 = (undefined8 *)((ulonglong)uVar18 + *(longlong *)(psVar13 + 4));
          uVar18 = uVar20 - uVar18;
        }
      }
      else {
        uVar10 = *(ushort *)((longlong)puVar21 + 6);
        if ((uVar10 & 8) == 0) {
          uVar29 = (uint)*(ushort *)(puVar21 + 7);
          if ((uVar10 & 0x10) != 0) {
            bVar7 = **(byte **)(psVar13 + 4);
            if ((bVar7 & 0x10) == 0) {
              if ((1 << (bVar7 & 0xe) & 0x1105U) != 0) {
LAB_:
                uVar18 = *(uint *)puVar21[1];
                puVar26 = (undefined8 *)((uint *)puVar21[1] + 1);
                if ((uVar29 != 0) && (uVar18 != uVar29)) {
                  puStack_d8 = (uint *)0x0;
                  (*_DAT_)(1,0xb7eae0,0xb7d448,0x381);
                }
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(psVar13 + 8) <= (int)uVar20) ||
                    (*(ushort *)(*(byte **)(psVar13 + 4) + *(uint *)(psVar13 + 8)) <
                     *(ushort *)((longlong)puVar21 + 4))) goto LAB_;
          }
          puVar26 = (undefined8 *)((longlong)(int)*(uint *)puVar21 + *(longlong *)(psVar13 + 4));
          uVar18 = uVar29;
        }
        else {
          puVar26 = (undefined8 *)0x755330;
          auStack_b8[0] = 1;
          uVar18 = auStack_b8[0];
          if ((*(byte *)(*(longlong *)(psVar13 + 4) + (longlong)(int)uVar20) &
              (byte)(1 << ((byte)uVar10 & 7))) == 0) {
            puVar26 = (undefined8 *)0x755331;
          }
        }
      }
    }
  }
  else {
    puStack_d8 = &uStack_a4;
    uStack_a4 = 0;
    puVar26 = (undefined8 *)func_0x(puVar1,puVar21,bVar7,auStack_b8);
    uVar18 = auStack_b8[0];
    if ((((*psVar6 != 0) && (plVar3 = *(longlong **)(psVar6 + 8), plVar3 != (longlong *)0x0)) &&
        (*plVar3 != 0)) && (((*(byte *)((longlong)puVar21 + 6) & 8) == 0 && ((uStack_a4 & 1) == 0)))
       ) {
      if ((puVar26 == (undefined8 *)0x0) || (puVar26 == (undefined8 *)0x755330)) {
        auStack_b8[0] = 0;
        puVar26 = puVar25;
        uVar18 = auStack_b8[0];
      }
      else {
        uStack_c0 = uStack_a4;
        puStack_c8 = auStack_b8;
        puStack_d8 = auStack_60;
        uStack_d0 = 8;
        puVar26 = (undefined8 *)func_0x(plVar3,puVar21,puVar26,auStack_b8[0]);
        uVar18 = auStack_b8[0];
      }
    }
  }
LAB_:
  auStack_b8[0] = uVar18;
  if ((auStack_b8[0] == 0) || (puVar26 == (undefined8 *)0x0)) {
    *puStack_90 = 0;
  }
  else {
    *puStack_90 = *(char *)puVar26 == '1';
  }
LAB_:
  func_0x(uStack_58 ^ (ulonglong)auStack_f8);
  return;
}

