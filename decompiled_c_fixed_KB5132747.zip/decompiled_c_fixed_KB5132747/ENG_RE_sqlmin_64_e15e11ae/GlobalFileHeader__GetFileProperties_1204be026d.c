
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,char param_2,uint param_3,undefined8 param_4)

{
  byte *pbVar1;
  byte *pbVar2;
  byte bVar3;
  undefined2 uVar4;
  undefined8 uVar5;
  code *pcVar6;
  longlong lVar7;
  longlong *plVar8;
  ushort *puVar9;
  uint **ppuVar10;
  char cVar11;
  byte bVar12;
  ushort uVar13;
  int iVar14;
  undefined4 uVar15;
  uint uVar16;
  int iVar17;
  uint uVar18;
  longlong lVar19;
  longlong *plVar20;
  byte **ppbVar21;
  byte **ppbVar22;
  longlong lVar23;
  uint *puVar24;
  short *psVar25;
  undefined8 uVar26;
  longlong lVar27;
  undefined8 *puVar28;
  short sVar29;
  uint uVar30;
  ulonglong uVar31;
  undefined *puVar32;
  uint uVar33;
  uint uVar34;
  undefined *puVar35;
  ulonglong uVar36;
  uint uVar37;
  ulonglong uVar38;
  ulonglong uVar39;
  byte **ppbVar40;
  ushort *puVar41;
  longlong unaff_GS_OFFSET;
  undefined auStackX_8 [4];
  uint auStackX_c [3];
  uint auStackX_18 [2];
  undefined8 uStackX_20;
  ushort uStack_5288;
  uint uStack_5284;
  uint uStack_5280;
  uint uStack_527c;
  undefined8 uStack_5278;
  ushort uStack_5270;
  undefined8 uStack_5268;
  undefined8 uStack_5260;
  ushort uStack_5258;
  undefined8 uStack_5250;
  undefined2 uStack_5248;
  undefined8 uStack_5240;
  undefined2 uStack_5238;
  undefined auStack_5230 [4];
  undefined4 uStack_522c;
  undefined4 uStack_5228;
  undefined2 uStack_5224;
  undefined4 uStack_5220;
  undefined2 uStack_521c;
  undefined8 uStack_5218;
  undefined2 uStack_5210;
  undefined4 uStack_5208;
  undefined2 uStack_5204;
  undefined4 uStack_5200;
  undefined2 uStack_51fc;
  undefined4 uStack_51f8;
  undefined2 uStack_51f4;
  undefined8 uStack_51f0;
  undefined2 uStack_51e8;
  undefined8 uStack_51e0;
  ushort uStack_51d8;
  undefined auStack_51d0 [4];
  undefined auStack_51cc [4];
  undefined auStack_51c8 [4];
  undefined auStack_51c4 [4];
  undefined auStack_51c0 [4];
  undefined auStack_51bc [4];
  undefined auStack_51b8 [4];
  undefined auStack_51b4 [4];
  undefined auStack_51b0 [8];
  uint uStack_51a8;
  undefined8 uStack_51a4;
  undefined8 uStack_5190;
  undefined8 uStack_5188;
  undefined8 uStack_5180;
  undefined8 uStack_5178;
  undefined8 uStack_5170;
  undefined auStack_5168 [8];
  undefined4 uStack_5160;
  undefined4 uStack_5158;
  uint **ppuStack_5150;
  undefined *puStack_5148;
  undefined8 uStack_5140;
  uint *puStack_5138;
  undefined4 uStack_5130;
  undefined4 uStack_512c;
  longlong lStack_5128;
  undefined4 uStack_5120;
  undefined4 uStack_511c;
  longlong lStack_5118;
  undefined4 uStack_5110;
  undefined4 uStack_510c;
  short *psStack_5108;
  int iStack_5100;
  undefined4 uStack_50fc;
  short *psStack_50f8;
  int iStack_50f0;
  undefined4 uStack_50ec;
  undefined8 uStack_50e8;
  undefined4 uStack_50e0;
  undefined4 uStack_50dc;
  undefined auStack_50d8 [448];
  undefined8 uStack_4f18;
  undefined8 uStack_4f10;
  uint uStack_4f08;
  undefined2 uStack_4f04;
  undefined4 uStack_4f02;
  undefined uStack_4efe;
  undefined uStack_4efd;
  short sStack_4168;
  ushort uStack_4166;
  uint uStack_4164;
  byte **ppbStack_4160;
  undefined8 uStack_4158;
  undefined4 uStack_4150;
  ushort uStack_414c;
  undefined2 uStack_414a;
  undefined6 uStack_4148;
  undefined2 uStack_4142;
  undefined2 uStack_4140;
  ushort uStack_413e;
  ushort uStack_413c;
  undefined2 uStack_413a;
  undefined4 uStack_4138;
  undefined4 uStack_4134;
  undefined auStack_4130 [16];
  undefined auStack_4120 [8];
  undefined8 uStack_4118;
  undefined8 uStack_4110;
  undefined6 uStack_4108;
  undefined2 uStack_4102;
  undefined6 uStack_4100;
  undefined2 uStack_40fa;
  undefined8 uStack_40f8;
  undefined auStack_40f0 [16];
  undefined auStack_40e0 [16];
  undefined auStack_40d0 [16];
  undefined8 uStack_40c0;
  undefined auStack_40b8 [4096];
  short asStack_30b8 [24];
  short asStack_3088 [2071];
  undefined auStack_2059 [8193];
  ulonglong uStack_58;
  undefined8 uStack_48;
  
  uStack_48 = 0x100028;
  auStackX_18[0] = param_3;
  uStackX_20 = param_4;
  lVar19 = func_0x();
  lVar19 = -lVar19;
  uStack_5170 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar19);
  sStack_4168 = -1;
  ppbVar40 = (byte **)0x0;
  ppbStack_4160 = (byte **)0x0;
  uStack_4164 = 0;
  uStack_414a = 0;
  uStack_4148 = 0;
  uStack_4140 = 0;
  uStack_413e = 0;
  uStack_413c = 0;
  uStack_413a = 0;
  uStack_4158 = (byte **)0x0;
  uStack_4134 = 0xffffffff;
  *(undefined8 *)(&stack0x00000000 + lVar19) = 0;
  auStackX_8[lVar19] = 0;
  uVar33 = *(uint *)((longlong)auStackX_c + lVar19);
  *(uint *)((longlong)auStackX_c + lVar19) = uVar33 & 0xffff0000;
  *(uint *)((longlong)auStackX_c + lVar19) = uVar33 & 0xff000000;
  *(undefined4 *)((longlong)auStackX_c + lVar19) = 0;
  *(undefined4 *)((longlong)&uStackX_20 + lVar19) = 0;
  *(undefined2 *)((longlong)&uStackX_20 + lVar19 + 4) = 0;
  puVar41 = (ushort *)((longlong)&uStackX_20 + lVar19 + 6);
  *puVar41 = *puVar41 & 0xffe0;
  *(undefined8 *)(&stack0x00000028 + lVar19) = 0;
  lVar23 = *param_1;
  uVar4 = *(undefined2 *)(lVar23 + 0x20);
  *(undefined4 *)(&stack0x00000030 + lVar19) = 0;
  *(undefined2 *)(&stack0x00000034 + lVar19) = uVar4;
  if (param_2 == '\0') {
    lVar23 = param_1[1];
    uStack_51a4 = 0;
    ppbVar22 = ppbVar40;
    if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
      lVar27 = *(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                );
      if ((lVar27 != 0) && (lVar27 = **(longlong **)(lVar27 + 0x38), lVar27 != 0)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x10023a;
        iVar14 = (*_DAT_)(lVar27,0x337);
        if (iVar14 != 0) goto LAB_;
      }
      lVar27 = *(longlong *)
                ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
      if (lVar27 != 0) {
        ppbVar22 = *(byte ***)(lVar27 + 0x60);
      }
    }
LAB_:
    lVar27 = *(longlong *)(lVar23 + 0x728);
    do {
      uStack_5280 = 0;
      lVar7 = *(longlong *)(&stack0x00000000 + lVar19);
      if (lVar7 != 0) {
        iVar14 = (int)*(short *)((longlong)auStackX_c + lVar19);
        if (((*(ushort *)(lVar7 + 0x62) & 0x400) == 0) || (iVar14 < 3)) {
          plVar20 = *(longlong **)(&stack0x00000000 + lVar19);
          if (((byte)*(undefined2 *)(lVar7 + 0x62) >> 3 & 1) != 0) {
            if (iVar14 == 3) {
              iVar14 = 4;
            }
            else if (iVar14 < 2) goto LAB_;
            if ((((*(uint *)(*(longlong *)(&stack0x00000000 + lVar19) + 100) & 8) != 0) &&
                (lVar7 = *(longlong *)(*(longlong *)(&stack0x00000000 + lVar19) + 0x90), lVar7 != 0)
                ) && (*(longlong *)(lVar7 + 0x758) != 0)) {
              uVar5 = *(undefined8 *)(lVar7 + 0x758);
              *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100314;
              func_0x(uVar5,*(undefined8 *)(&stack0x00000000 + lVar19),iVar14);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar20 + 100) & 8) != 0)) &&
             ((2 < iVar14 &&
              (((*(uint *)((longlong)plVar20 + 100) & 0xc0000000) != 0x40000000 &&
               (lVar7 = *plVar20, lVar7 != 0)))))) {
            *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100355;
            iVar17 = (*_DAT_)(lVar7,0x2000,2,auStack_51d0);
            if (iVar17 != 0) {
              LOCK();
              *(uint *)((longlong)plVar20 + 100) = *(uint *)((longlong)plVar20 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar20 + 100) = *(uint *)((longlong)plVar20 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100377;
          func_0x(plVar20 + 0x13,iVar14);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100396;
            func_0x(plVar20,0,iVar14);
          }
          *(uint *)((longlong)auStackX_c + lVar19) =
               *(uint *)((longlong)auStackX_c + lVar19) & 0xffff0000;
          *(undefined8 *)(&stack0x00000000 + lVar19) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1002af;
          func_0x((longlong)&stack0x00000000 + lVar19);
        }
      }
      if (*(longlong *)(lVar23 + 0x728) != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1003c8;
        func_0x((longlong)&stack0x00000000 + lVar19,&stack0x00000030 + lVar19,lVar23);
        lVar7 = *(longlong *)(&stack0x00000000 + lVar19);
        if (lVar7 != 0) {
          iVar14 = (int)*(short *)((longlong)auStackX_c + lVar19);
          if (((*(ushort *)(lVar7 + 0x62) & 0x400) == 0) || (iVar14 < 3)) {
            plVar20 = *(longlong **)(&stack0x00000000 + lVar19);
            if (((byte)*(undefined2 *)(lVar7 + 0x62) >> 3 & 1) != 0) {
              if (iVar14 == 3) {
                iVar14 = 4;
              }
              else if (iVar14 < 2) goto LAB_;
              if ((((*(uint *)(*(longlong *)(&stack0x00000000 + lVar19) + 100) & 8) != 0) &&
                  (lVar7 = *(longlong *)(*(longlong *)(&stack0x00000000 + lVar19) + 0x90),
                  lVar7 != 0)) && (*(longlong *)(lVar7 + 0x758) != 0)) {
                uVar5 = *(undefined8 *)(lVar7 + 0x758);
                *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100458;
                func_0x(uVar5,*(undefined8 *)(&stack0x00000000 + lVar19),iVar14);
              }
            }
LAB_:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar20 + 100) & 8) != 0)) &&
               ((2 < iVar14 &&
                (((*(uint *)((longlong)plVar20 + 100) & 0xc0000000) != 0x40000000 &&
                 (lVar7 = *plVar20, lVar7 != 0)))))) {
              *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100499;
              iVar17 = (*_DAT_)(lVar7,0x2000,2,auStack_51cc);
              if (iVar17 != 0) {
                LOCK();
                *(uint *)((longlong)plVar20 + 100) = *(uint *)((longlong)plVar20 + 100) & 0x3fffffff
                ;
                UNLOCK();
                LOCK();
                *(uint *)((longlong)plVar20 + 100) = *(uint *)((longlong)plVar20 + 100) | 0x40000000
                ;
                UNLOCK();
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1004bb;
            func_0x(plVar20 + 0x13,iVar14);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1004da;
              func_0x(plVar20,0,iVar14);
            }
            *(uint *)((longlong)auStackX_c + lVar19) =
                 *(uint *)((longlong)auStackX_c + lVar19) & 0xffff0000;
            *(undefined8 *)(&stack0x00000000 + lVar19) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1003f3;
            func_0x((longlong)&stack0x00000000 + lVar19);
          }
        }
      }
      *(uint **)(&stack0xffffffffffffffe8 + lVar19) = &uStack_51a8;
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar19) = 2;
      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100511;
      ppbVar21 = (byte **)func_0x
                                    (_DAT_,lVar23,&stack0x00000030 + lVar19,&uStack_5280);
      *(byte ***)(&stack0x00000000 + lVar19) = ppbVar21;
      uVar33 = *(uint *)((longlong)auStackX_c + lVar19) & 0xffff0002 | 2;
      *(uint *)((longlong)auStackX_c + lVar19) = uVar33;
      if (ppbVar22 != (byte **)0x0) {
        if (ppbVar22[(ulonglong)(*(uint *)(ppbVar22 + 0xa0) & 0xf) + 0xa1] != *ppbVar21) {
          ppbVar22[(ulonglong)(*(uint *)(ppbVar22 + 0xa0) & 0xf) + 0xa1] = *ppbVar21;
          ppbVar22[0xa0] = ppbVar22[0xa0] + 1;
          uVar33 = *(uint *)((longlong)auStackX_c + lVar19);
        }
      }
      uVar33 = (uStack_5280 >> 3 & 1) << 0x18 | uVar33 & 0xffffff;
      *(uint *)((longlong)auStackX_c + lVar19) = uVar33;
      *(uint *)((longlong)auStackX_c + lVar19 + 4) =
           uStack_5280 >> 4 & 1 | *(uint *)((longlong)auStackX_c + lVar19 + 4) & 0xffffff00;
      if (((lVar27 != 0) && (ppbVar22 != (byte **)0x0)) &&
         (ppbVar22 == *(byte ***)(lVar23 + 0x1c38))) {
        *(longlong *)(lVar27 + 0x5b28) = *(longlong *)(lVar27 + 0x5b28) + 1;
        if ((int)uStack_51a4 != 0) {
          *(longlong *)(lVar27 + 0x5b30) = *(longlong *)(lVar27 + 0x5b30) + 1;
          *(longlong *)(lVar27 + 0x5b38) = *(longlong *)(lVar27 + 0x5b38) + (ulonglong)uStack_51a8;
          if (0xffffff < uVar33) {
            *(longlong *)(lVar27 + 0x5b40) = *(longlong *)(lVar27 + 0x5b40) + 1;
            *(longlong *)(lVar27 + 0x5b48) = *(longlong *)(lVar27 + 0x5b48) + (ulonglong)uStack_51a8
            ;
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1005d7;
      cVar11 = func_0x(lVar23);
      if (((cVar11 == '\0') || (*(char *)(lVar23 + 0x2050) == '\0')) ||
         ((*(int *)(&stack0x00000030 + lVar19) == 0 ||
          ((*(int *)(&stack0x00000030 + lVar19) == 9 && (*(short *)(&stack0x00000034 + lVar19) == 1)
           ))))) goto LAB_;
      lVar7 = **(longlong **)(&stack0x00000000 + lVar19);
      if (*(short *)(lVar7 + 0x24) == 0) {
LAB_:
        uStack_5260 = *(undefined8 *)(lVar7 + 0x28);
        uStack_5258 = *(ushort *)(lVar7 + 0x30);
      }
      else {
        cVar11 = *(char *)(lVar7 + 1);
        if (cVar11 == '\v') {
          if (*(int *)(lVar7 + 0x18) != 99) {
LAB_:
            if (cVar11 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar11 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar7 + 0x18) != 99) goto LAB_;
        }
        uStack_5228 = *(undefined4 *)(lVar7 + 0x20);
        uStack_5224 = *(undefined2 *)(lVar7 + 0x24);
        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x10064d;
        cVar11 = func_0x(&uStack_5228);
        if (cVar11 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x10065d;
        func_0x(lVar7,&uStack_5260);
      }
      uVar33 = *(uint *)(lVar23 + 0x2108);
      do {
        uVar16 = uVar33 & 0xfffffffe;
        *(undefined8 *)(&stack0x00000038 + lVar19) = *(undefined8 *)(lVar23 + 0x20fc);
        uVar15 = *(undefined4 *)(lVar23 + 0x2104);
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc0 + lVar19) =
             *(undefined4 *)(&stack0xffffffffffffffc0 + lVar19);
        UNLOCK();
        uVar33 = *(uint *)(lVar23 + 0x2108);
      } while (uVar16 != uVar33);
      if ((uint)uStack_5260 <= *(uint *)(&stack0x00000038 + lVar19)) {
        if (*(uint *)(&stack0x00000038 + lVar19) != (uint)uStack_5260) goto LAB_;
        uVar33 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000038 + lVar19) >> 0x20);
        if ((uStack_5260._4_4_ <= uVar33) &&
           ((uVar33 != uStack_5260._4_4_ ||
            (uStack_5288 = (ushort)uVar15, uStack_5258 <= uStack_5288)))) goto LAB_;
      }
      if ((*(char *)(lVar23 + 0x6ac8) == '\0') &&
         (*(longlong *)
           (*(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8) + 0x60) != *(longlong *)(lVar23 + 0x2120))) {
        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x10071d;
        cVar11 = func_0x(lVar23);
        if (cVar11 != '\0') goto LAB_;
        uVar33 = *(uint *)(lVar23 + 0x2108);
        do {
          uVar16 = uVar33 & 0xfffffffe;
          uStack_51e0 = *(undefined8 *)(lVar23 + 0x20fc);
          *(undefined8 *)(&stack0x00000038 + lVar19) = uStack_51e0;
          uVar15 = *(undefined4 *)(lVar23 + 0x2104);
          LOCK();
          *(undefined4 *)(&stack0xffffffffffffffc0 + lVar19) =
               *(undefined4 *)(&stack0xffffffffffffffc0 + lVar19);
          UNLOCK();
          uVar33 = *(uint *)(lVar23 + 0x2108);
        } while (uVar16 != uVar33);
        uStack_5288 = (ushort)uVar15;
        uStack_51d8 = uStack_5288;
        lVar27 = **(longlong **)(&stack0x00000000 + lVar19);
        if (*(short *)(lVar27 + 0x24) == 0) {
LAB_:
          uStack_5278 = *(undefined8 *)(lVar27 + 0x28);
          uStack_5270 = *(ushort *)(lVar27 + 0x30);
        }
        else {
          cVar11 = *(char *)(lVar27 + 1);
          if (cVar11 == '\v') {
            if (*(int *)(lVar27 + 0x18) != 99) {
LAB_:
              if (cVar11 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar11 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar27 + 0x18) != 99) goto LAB_;
          }
          uStack_5200 = *(undefined4 *)(lVar27 + 0x20);
          uStack_51fc = *(undefined2 *)(lVar27 + 0x24);
          *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1009ce;
          cVar11 = func_0x(&uStack_5200);
          if (cVar11 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1009de;
          func_0x(lVar27,&uStack_5278);
        }
        if ((*(uint *)(&stack0x00000038 + lVar19) < (uint)uStack_5278) ||
           ((*(uint *)(&stack0x00000038 + lVar19) == (uint)uStack_5278 &&
            ((uVar33 = (uint)((ulonglong)uStack_5278 >> 0x20),
             *(uint *)(&stack0x0000003c + lVar19) < uVar33 ||
             ((*(uint *)(&stack0x0000003c + lVar19) == uVar33 && (uStack_5288 < uStack_5270))))))))
        {
          lVar27 = *(longlong *)(lVar23 + 0x6b0);
          *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100a3e;
          func_0x(&uStack_5278,asStack_30b8,auStack_5230);
          *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100a52;
          func_0x(&uStack_51e0,asStack_3088,auStack_5230);
          if ((_DAT_ & 0x10000) != 0) {
            uStack_5160 = 0x60000;
            uStack_5158 = 0;
            ppuStack_5150 = &puStack_5138;
            puStack_5148 = auStack_50d8;
            uStack_4f18 = 0;
            uStack_5140 = 0;
            uStack_4f10 = 0;
            puStack_5138 = &uStack_4f08;
            uStack_5130 = 0x34;
            uStack_512c = 5;
            lStack_5128 = 0x12dc688;
            uStack_5120 = 0x10;
            uStack_511c = 5;
            lStack_5118 = 0x12dc688;
            uStack_5110 = 0x10;
            uStack_510c = 6;
            psStack_5108 = (short *)0x0;
            iStack_5100 = 0;
            uStack_50fc = 7;
            psStack_50f8 = (short *)0x0;
            iStack_50f0 = 0;
            uStack_50ec = 8;
            uStack_50e8 = 0;
            uStack_50e0 = 0;
            uStack_50dc = 9;
            uStack_4f08 = (uint)*(ushort *)(lVar23 + 0x6b8);
            uStack_4f04 = *(undefined2 *)(&stack0x00000034 + lVar19);
            uStack_4f02 = *(undefined4 *)(&stack0x00000030 + lVar19);
            uStack_4efe = 0xff;
            uStack_4efd = *(undefined *)(**(longlong **)(&stack0x00000000 + lVar19) + 1);
            lStack_5128 = lVar27 + 0x254;
            lStack_5118 = lVar27 + 0x244;
            lVar23 = -1;
            do {
              lVar23 = lVar23 + 1;
            } while (asStack_30b8[lVar23] != 0);
            psStack_5108 = asStack_30b8;
            iStack_5100 = (int)lVar23 * 2;
            lVar23 = -1;
            do {
              lVar23 = lVar23 + 1;
            } while (asStack_3088[lVar23] != 0);
            iStack_50f0 = (int)lVar23 * 2;
            psStack_50f8 = asStack_3088;
            uStack_522c = 0;
            pcVar6 = *(code **)(_DAT_ + 0x10);
            *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100c15;
            puVar24 = (uint *)(*pcVar6)(lVar27,&uStack_522c);
            ppuVar10 = ppuStack_5150;
            uVar33 = 0;
            if (puVar24 != (uint *)0x0) {
              lVar23 = -1;
              do {
                lVar23 = lVar23 + 1;
              } while (*(short *)((longlong)puVar24 + lVar23 * 2) != 0);
              uVar33 = (int)lVar23 * 2;
            }
            ppuStack_5150[10] = puVar24;
            *(uint *)(ppuVar10 + 0xb) = uVar33;
            *(undefined4 *)((longlong)ppuVar10 + 0x5c) = 9;
            *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100c52;
            func_0x(auStack_5168);
          }
        }
LAB_:
        uVar31 = **(ulonglong **)(&stack0x00000000 + lVar19);
        goto LAB_;
      }
LAB_:
      if (*(longlong *)
           (*(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8) + 0x60) == *(longlong *)(lVar23 + 0x2120)) goto LAB_;
      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100761;
      cVar11 = func_0x(lVar23);
      if (cVar11 != '\0') goto LAB_;
      if (ppbVar22 == (byte **)0x0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100773;
        ppbVar22 = (byte **)func_0x();
      }
      plVar20 = *(longlong **)(&stack0x00000000 + lVar19);
      lVar7 = *plVar20;
      if (*(short *)(lVar7 + 0x24) == 0) {
LAB_:
        uStack_5218 = *(undefined8 *)(lVar7 + 0x28);
        uStack_5210 = *(undefined2 *)(lVar7 + 0x30);
      }
      else {
        cVar11 = *(char *)(lVar7 + 1);
        if (cVar11 == '\v') {
          if (*(int *)(lVar7 + 0x18) != 99) {
LAB_:
            if (cVar11 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar11 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar7 + 0x18) != 99) goto LAB_;
        }
        uStack_51f8 = *(undefined4 *)(lVar7 + 0x20);
        uStack_51f4 = *(undefined2 *)(lVar7 + 0x24);
        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1007ba;
        cVar11 = func_0x(&uStack_51f8);
        if (cVar11 == '\0') {
          plVar20 = *(longlong **)(&stack0x00000000 + lVar19);
          goto LAB_;
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1007ca;
        func_0x(lVar7,&uStack_5218);
        plVar20 = *(longlong **)(&stack0x00000000 + lVar19);
      }
      if (plVar20 != (longlong *)0x0) {
        iVar14 = (int)*(short *)((longlong)auStackX_c + lVar19);
        if (((*(ushort *)((longlong)plVar20 + 0x62) & 0x400) == 0) || (iVar14 < 3)) {
          plVar8 = *(longlong **)(&stack0x00000000 + lVar19);
          if (((byte)*(undefined2 *)((longlong)plVar20 + 0x62) >> 3 & 1) != 0) {
            if (iVar14 == 3) {
              iVar14 = 4;
            }
            else if (iVar14 < 2) goto LAB_;
            if ((((*(uint *)(*(longlong *)(&stack0x00000000 + lVar19) + 100) & 8) != 0) &&
                (lVar7 = *(longlong *)(*(longlong *)(&stack0x00000000 + lVar19) + 0x90), lVar7 != 0)
                ) && (*(longlong *)(lVar7 + 0x758) != 0)) {
              uVar5 = *(undefined8 *)(lVar7 + 0x758);
              *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100878;
              func_0x(uVar5,*(undefined8 *)(&stack0x00000000 + lVar19),iVar14);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar8 + 100) & 8) != 0)) &&
             ((2 < iVar14 &&
              (((*(uint *)((longlong)plVar8 + 100) & 0xc0000000) != 0x40000000 &&
               (lVar7 = *plVar8, lVar7 != 0)))))) {
            *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1008b9;
            iVar17 = (*_DAT_)(lVar7,0x2000,2,auStack_51c8);
            if (iVar17 != 0) {
              LOCK();
              *(uint *)((longlong)plVar8 + 100) = *(uint *)((longlong)plVar8 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar8 + 100) = *(uint *)((longlong)plVar8 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1008db;
          func_0x(plVar8 + 0x13,iVar14);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1008fa;
            func_0x(plVar8,0,iVar14);
          }
          *(uint *)((longlong)auStackX_c + lVar19) =
               *(uint *)((longlong)auStackX_c + lVar19) & 0xffff0000;
          *(undefined8 *)(&stack0x00000000 + lVar19) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100813;
          func_0x((longlong)&stack0x00000000 + lVar19);
        }
      }
      uStack_51f0 = uStack_5218;
      uStack_51e8 = uStack_5210;
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar19) = 0;
      uVar5 = *(undefined8 *)(lVar23 + 0x728);
      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x10093c;
      func_0x(uVar5,&uStack_51f0,4);
    } while( true );
  }
  uVar31 = (ulonglong)auStack_2059 & 0xfffffffffffff000;
  uStack_5284 = 0;
  uStack_5190 = 0;
  uStack_5188 = 0;
  uStack_5178 = 0;
  uStack_5180 = 0;
  uVar5 = *(undefined8 *)(lVar23 + 0x18);
  *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100118;
  plVar20 = (longlong *)func_0x(uVar5);
  if (plVar20 == (longlong *)0x0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100165;
    (*_DAT_)(0x32);
LAB_:
    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x10016b;
    uVar15 = (*_DAT_)();
    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100180;
    (*_DAT_)(uVar15,auStack_40b8,0,0);
    lVar23 = *param_1;
    puVar32 = auStack_40b8;
    puVar35 = auStack_5168;
    for (lVar27 = 0x1000; lVar27 != 0; lVar27 = lVar27 + -1) {
      *puVar35 = *puVar32;
      puVar32 = puVar32 + 1;
      puVar35 = puVar35 + 1;
    }
    *(longlong *)(&stack0xfffffffffffffff8 + lVar19) = lVar23 + 0x940;
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar19) = 0;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar19) = 0x331c;
    *(undefined **)(&stack0xffffffffffffffe0 + lVar19) = auStack_5168;
    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1001d3;
    (*_DAT_)(8,0x17,0x18,0x13);
  }
  else {
    lVar23 = *plVar20;
    *(undefined8 **)(&stack0xffffffffffffffe8 + lVar19) = &uStack_5190;
    *(uint **)(&stack0xffffffffffffffe0 + lVar19) = &uStack_5284;
    pcVar6 = *(code **)(lVar23 + 0xd8);
    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100147;
    iVar14 = (*pcVar6)(plVar20,uVar5,uVar31,0x2000);
    if ((iVar14 == 0) || (uStack_5284 < 0x2000)) goto LAB_;
  }
LAB_:
  if (*(short *)(uVar31 + 0x24) == 0) {
LAB_:
    uStack_5250 = *(undefined8 *)(uVar31 + 0x28);
    uStack_5248 = *(undefined2 *)(uVar31 + 0x30);
  }
  else {
    cVar11 = *(char *)(uVar31 + 1);
    if (cVar11 == '\v') {
      if (*(int *)(uVar31 + 0x18) != 99) {
LAB_:
        if (cVar11 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar11 != '\b') goto LAB_;
LAB_:
      if (*(int *)(uVar31 + 0x18) != 99) goto LAB_;
    }
    uStack_5208 = *(undefined4 *)(uVar31 + 0x20);
    uStack_5204 = *(undefined2 *)(uVar31 + 0x24);
    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100c9f;
    cVar11 = func_0x(&uStack_5208);
    if (cVar11 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100caf;
    func_0x(uVar31,&uStack_5250);
  }
  lVar23 = *param_1;
  *(undefined4 *)(lVar23 + 0x70) = (undefined4)uStack_5250;
  *(int *)(lVar23 + 0x74) = (int)((ulonglong)uStack_5250 >> 0x20);
  *(undefined2 *)(lVar23 + 0x78) = uStack_5248;
  uStack_4134 = 0;
  uVar33 = 1;
  uVar16 = 0;
  ppbVar22 = ppbVar40;
  if (*(char *)(uVar31 + 2) < '\0') {
    pbVar1 = (byte *)(uVar31 + 0x60);
    if ((sStack_4168 == 0) || (ppbVar22 = uStack_4158, uStack_4158 == (byte **)0x0)) {
      uStack_4108 = 0;
      uStack_40fa = 0;
      auStack_40e0 = ZEXT816(0);
      auStack_4130 = ZEXT816(0);
      stack0xffffffffffffbee2 = SUB1614(ZEXT816(0),2);
      auStack_4120._0_2_ = 0xffff;
      uStack_4118 = 0;
      uStack_4102 = 0;
      uStack_4100 = 0;
      uStack_40f8 = 0;
      uStack_4110 = 0;
      auStack_40f0 = ZEXT816(0);
      auStack_40d0._0_12_ = ZEXT812(0);
      auStack_40d0._12_4_ = 0;
      uStack_40c0 = 0;
      ppbVar22 = (byte **)auStack_4130;
    }
    if (*(short *)(uVar31 + 0x24) == 0) {
LAB_:
      uStack_5240 = *(undefined8 *)(uVar31 + 0x28);
      uStack_5238 = *(undefined2 *)(uVar31 + 0x30);
    }
    else {
      cVar11 = *(char *)(uVar31 + 1);
      if (cVar11 == '\v') {
        if (*(int *)(uVar31 + 0x18) != 99) {
LAB_:
          if (cVar11 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar11 != '\b') goto LAB_;
LAB_:
        if (*(int *)(uVar31 + 0x18) != 99) goto LAB_;
      }
      uStack_5220 = *(undefined4 *)(uVar31 + 0x20);
      uStack_521c = *(undefined2 *)(uVar31 + 0x24);
      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100dff;
      uVar33 = 1;
      cVar11 = func_0x(&uStack_5220);
      if (cVar11 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x100e0f;
      func_0x(uVar31,&uStack_5240);
    }
    *ppbVar22 = pbVar1;
    *(undefined4 *)(ppbVar22 + 0xc) = (undefined4)uStack_5240;
    *(int *)((longlong)ppbVar22 + 100) = (int)((ulonglong)uStack_5240 >> 0x20);
    *(undefined2 *)(ppbVar22 + 0xd) = uStack_5238;
    *(undefined4 *)((longlong)ppbVar22 + 0x6c) = *(undefined4 *)(uVar31 + 0x20);
    *(undefined2 *)(ppbVar22 + 0xe) = *(undefined2 *)(uVar31 + 0x24);
    *(undefined2 *)((longlong)ppbVar22 + 0x72) = 0;
    uStack_5268 = (undefined8 *)
                  CONCAT44(uStack_5268._4_4_,*(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x11aa190));
    uVar39 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x11aa194);
    *(undefined2 *)(ppbVar22 + 2) = 0xffff;
    ppbVar22[3] = (byte *)0x0;
    *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar22 + 0x2e) = 0;
    ppbVar22[7] = (byte *)0x0;
    ppbVar22[4] = (byte *)0x0;
    ppbVar22[9] = (byte *)0x0;
    ppbVar22[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar22 + 0xb) = 0;
    if ((**ppbVar22 & 2) != 0) {
      pbVar2 = pbVar1 + uVar39;
      if ((*pbVar2 & (byte)uVar33) == 0) {
        *(undefined2 *)(ppbVar22 + 2) = 0;
        ppbVar22[3] = pbVar2;
        *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar22 + 0x36) = 0;
        uVar18 = uVar16;
        switch(*pbVar2 & 0xe) {
        default:
          uVar18 = (uint)*(ushort *)(pbVar2 + 2);
          if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101084;
            func_0x(pbVar2,6);
          }
          break;
        case 4:
          uVar18 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar18 = uVar33;
        }
        *(uint *)(ppbVar22 + 4) = uVar18;
        *(undefined8 *)((longlong)ppbVar22 + 0x2e) = 0;
      }
      else {
        *(short *)(ppbVar22 + 2) = (short)uVar33;
        ppbVar22[3] = pbVar2;
        bVar3 = *pbVar2;
        switch(bVar3 & 0x1c) {
        default:
          if ((char)pbVar2[1] < '\0') {
            uVar13 = *(ushort *)(pbVar2 + 1);
            *(ushort *)((longlong)ppbVar22 + 0x12) = uVar13;
            sVar29 = 3;
            uVar13 = (uVar13 & 0x7f) << 8 | uVar13 >> 8;
          }
          else {
            sVar29 = 2;
            uVar13 = (ushort)pbVar2[1];
          }
          *(ushort *)((longlong)ppbVar22 + 0x12) = uVar13;
          *(short *)(ppbVar22 + 5) = sVar29;
          uVar13 = *(ushort *)((longlong)ppbVar22 + 0x12);
          *(short *)((longlong)ppbVar22 + 0x2c) = (short)(uVar13 + 1 >> 1) + sVar29;
          if (uVar13 < 0x1f) {
            *(undefined2 *)((longlong)ppbVar22 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
            *(undefined4 *)(ppbVar22 + 8) = 0;
            ppbVar22[7] = (byte *)0x0;
            ppbVar22[4] = (byte *)0x0;
          }
          else {
            iVar14 = uVar13 - 1;
            *(short *)((longlong)ppbVar22 + 0x2a) =
                 ((short)(iVar14 / 0x1e) + (short)(iVar14 >> 0x1f)) -
                 (short)((longlong)iVar14 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
            *(undefined4 *)(ppbVar22 + 8) = 0;
            ppbVar22[7] = (byte *)0x0;
            ppbVar22[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar3 & 0x1c) != 4) || (uVar18 = uVar33, (bVar3 & 2) == 0)) {
            uVar18 = 0;
          }
          uVar34 = uVar33;
          uVar30 = uVar16;
          if (uVar18 != 0) {
            *(undefined4 *)(ppbVar22 + 8) = 0;
            uVar34 = 0xf;
            uVar30 = uVar33;
          }
          ppbVar22[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar22 + 0x12) = 0;
          ppbVar22[6] = (byte *)0x0;
          ppbVar22[4] = (byte *)0x0;
          ppbVar22[7] = (byte *)0x0;
          ppbVar22[3] = pbVar2;
          *(uint *)((longlong)ppbVar22 + 0x14) = uVar34;
          *(uint *)(ppbVar22 + 8) = uVar30;
          ppbVar22[7] = (byte *)0x0;
          ppbVar22[4] = (byte *)0x0;
          break;
        case 8:
          ppbVar22[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar22 + 0x12) = 0;
          ppbVar22[6] = (byte *)0x0;
          ppbVar22[4] = (byte *)0x0;
          ppbVar22[7] = (byte *)0x0;
          ppbVar22[3] = pbVar2;
          *(undefined4 *)((longlong)ppbVar22 + 0x14) = 9;
          *(undefined4 *)(ppbVar22 + 8) = 0;
          ppbVar22[7] = (byte *)0x0;
          ppbVar22[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar22 & 4) != 0) {
      if (uStack_5268._2_2_ != 0) {
        uVar39 = (ulonglong)*(ushort *)(uVar31 + 0x61 + (longlong)uStack_5268._2_2_ * 2);
      }
      psVar25 = (short *)(pbVar1 + uVar39);
      ppbVar22[9] = (byte *)psVar25;
      sVar29 = *psVar25;
      ppbVar22[10] = (byte *)(psVar25 + 1);
      *(short *)(ppbVar22 + 0xb) = (sVar29 + 1) * 2;
    }
    pbVar1 = ppbVar22[1];
    if (pbVar1 != (byte *)0x0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x10111d;
      func_0x(pbVar1,ppbVar22);
    }
  }
  uVar39 = (ulonglong)*(ushort *)(uVar31 + 0xe);
  ppbStack_4160 = (byte **)(*(ushort *)(uVar31 + 0x1ffe) + uVar31);
  if ((*(byte *)ppbStack_4160 & 1) == 0) {
    sStack_4168 = 0;
    uStack_4164 = 0;
    uStack_4142 = 0;
    uStack_4140 = 0;
    switch(*(byte *)ppbStack_4160 & 0xe) {
    default:
      uVar39 = (ulonglong)*(ushort *)((longlong)ppbStack_4160 + 2);
      if (0x1f9d < *(ushort *)((longlong)ppbStack_4160 + 2) - 1) {
        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101345;
        func_0x(ppbStack_4160,6);
      }
      break;
    case 4:
      uVar39 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar39 = 1;
    }
    uStack_4158 = (byte **)CONCAT44(uStack_4158._4_4_,(int)uVar39);
    uStack_414a = (undefined2)(uVar31 + 0x2000);
    uStack_4148 = (undefined6)(uVar31 + 0x2000 >> 0x10);
  }
  else {
    sStack_4168 = 1;
    bVar3 = *(byte *)ppbStack_4160;
    switch(bVar3 & 0x1c) {
    default:
      if ((char)*(byte *)((longlong)ppbStack_4160 + 1) < '\0') {
        uStack_4166 = (*(ushort *)((longlong)ppbStack_4160 + 1) & 0x7f) << 8 |
                      *(ushort *)((longlong)ppbStack_4160 + 1) >> 8;
        sVar29 = 3;
        uStack_4150._0_2_ = 3;
      }
      else {
        uStack_4166 = (ushort)*(byte *)((longlong)ppbStack_4160 + 1);
        uStack_4150._0_2_ = 2;
        sVar29 = 2;
      }
      uStack_414c = (short)(uStack_4166 + 1 >> 1) + sVar29;
      if (uStack_4166 < 0x1f) {
        uStack_4150._2_2_ = 0;
        uStack_4164 = 0;
        uStack_4138 = 0;
      }
      else {
        iVar14 = uStack_4166 - 1;
        uStack_4150._2_2_ =
             ((short)(iVar14 / 0x1e) + (short)(iVar14 >> 0x1f)) -
             (short)((longlong)iVar14 * 0x88888889 >> 0x3f);
        uStack_4164 = 0;
        uStack_4138 = 0;
      }
      break;
    case 4:
      if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
        uStack_4150._0_2_ = 0;
        uStack_4150._2_2_ = 0;
        uStack_414c = 0;
        uStack_414a = 0;
        uStack_4166 = 0;
        uStack_4148 = 0;
        uStack_4142 = 0;
        uStack_4164 = 0xf;
        uStack_4138 = 1;
      }
      else {
        uStack_4150._0_2_ = 0;
        uStack_4150._2_2_ = 0;
        uStack_414c = 0;
        uStack_414a = 0;
        uStack_4166 = 0;
        uStack_4148 = 0;
        uStack_4142 = 0;
        uStack_4164 = 1;
        uStack_4138 = 0;
      }
      break;
    case 8:
      uStack_4150._0_2_ = 0;
      uStack_4150._2_2_ = 0;
      uStack_414c = 0;
      uStack_414a = 0;
      uStack_4166 = 0;
      uStack_4148 = 0;
      uStack_4142 = 0;
      uStack_4164 = 9;
      uStack_4138 = 0;
    }
    lVar23 = uVar31 + 0x2000;
    uStack_4140 = (undefined2)lVar23;
    uStack_413e = (ushort)((ulonglong)lVar23 >> 0x10);
    uStack_413c = (ushort)((ulonglong)lVar23 >> 0x20);
    uStack_413a = (undefined2)((ulonglong)lVar23 >> 0x30);
    uStack_4158 = ppbVar22;
    uVar39 = (ulonglong)ppbVar22 & 0xffffffff;
  }
  puVar28 = &uStackX_20;
  uStack_5268 = puVar28;
  if (auStackX_18[0] != 0) {
    while( true ) {
      uVar34 = (uint)uVar39;
      auStackX_18[0] = auStackX_18[0] - 1;
      uVar33 = *(uint *)puVar28;
      uVar5 = puVar28[1];
      uStack_5268 = puVar28 + 3;
      uVar18 = *(uint *)(puVar28 + 2);
      if (0x3b < (int)uVar33) break;
      uVar37 = -uVar33;
      *(uint *)((longlong)&uStackX_20 + lVar19) = uVar37;
      *(short *)((longlong)&uStackX_20 + lVar19 + 4) = (short)uVar33;
      uVar30 = uVar33;
      if ((uVar37 & 0xc0000000) == 0x80000000) {
        *(undefined2 *)((longlong)&uStackX_20 + lVar19 + 4) = 0;
        uVar30 = 0;
      }
      *(ushort *)((longlong)&uStackX_20 + lVar19 + 6) =
           *(ushort *)((longlong)&uStackX_20 + lVar19 + 6) & 0xffe0;
      *(undefined8 *)(&stack0x00000028 + lVar19) = 0;
      if (sStack_4168 == 0) {
        if ((uVar37 & 0xc0000000) == 0x80000000) {
          *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101d7a;
          iVar14 = func_0x(&uStack_4166);
          if (iVar14 == 0) {
code_r0x00101e2a:
            ppbVar22 = (byte **)0x0;
            *(undefined4 *)((longlong)auStackX_18 + lVar19) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101d9c;
            ppbVar22 = (byte **)func_0x(&uStack_413e,(longlong)&uStackX_20 + lVar19,
                                                (longlong)auStackX_18 + lVar19,auStack_51c4);
          }
        }
        else {
          bVar3 = *(byte *)ppbStack_4160;
          if ((bVar3 & 0x10) == 0) {
            if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) {
              bVar12 = 0xff;
              uVar30 = uVar16;
              goto code_r0x001014d5;
            }
code_r0x00101518:
            if ((int)uVar33 < 1) {
              bVar12 = *(byte *)((longlong)&uStackX_20 + lVar19 + 6);
              if ((bVar12 & 8) == 0) {
                if ((bVar12 & 0x10) == 0) {
code_r0x0010155b:
                  ppbVar22 = (byte **)((longlong)(int)uVar37 + (longlong)ppbStack_4160);
                  *(undefined4 *)((longlong)auStackX_18 + lVar19) = 0;
                }
                else {
                  if ((bVar3 & 0x10) == 0) {
                    if ((1 << (bVar3 & 0xe) & 0x1105U) == 0) goto code_r0x0010155b;
                  }
                  else if (((int)uVar37 < (int)uVar34) &&
                          (*(ushort *)((longlong)&uStackX_20 + lVar19 + 4) <=
                           *(ushort *)(uVar39 + (longlong)ppbStack_4160))) goto code_r0x0010155b;
code_r0x001014fb:
                  ppbVar22 = (byte **)0x4;
                  *(undefined4 *)((longlong)auStackX_18 + lVar19) =
                       **(undefined4 **)(&stack0x00000028 + lVar19);
                }
              }
              else {
                ppbVar22 = (byte **)0x1134fe0;
                if ((*(byte *)((longlong)(int)uVar37 + (longlong)ppbStack_4160) &
                    (byte)(1 << (*(byte *)((longlong)&uStackX_20 + lVar19 + 6) & 7))) == 0) {
                  ppbVar22 = (byte **)0x1134fe1;
                }
                *(undefined4 *)((longlong)auStackX_18 + lVar19) = 1;
              }
            }
            else {
              ppbVar22 = ppbStack_4160;
              if (uStack_4164 == 0) {
                uStack_4166 = 0;
                uVar33 = uVar34;
                if ((*(byte *)ppbStack_4160 & 0x10) != 0) {
                  uVar33 = uVar34 + 2 + (*(ushort *)((longlong)ppbStack_4160 + uVar39) + 7 >> 3);
                }
                uStack_4158 = (byte **)CONCAT44(uVar33,(uint)uStack_4158);
                if ((*(byte *)ppbStack_4160 & 0x20) == 0) {
                  uStack_4164 = uVar33;
                  uStack_414c = 0;
                  uStack_4150._0_2_ = (undefined2)uVar33;
                  uStack_4150._2_2_ = (short)(uVar33 >> 0x10);
                }
                else {
                  puVar41 = (ushort *)((ulonglong)uVar33 + (longlong)ppbStack_4160);
                  uStack_414c = *puVar41;
                  if (*puVar41 == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101611;
                    cVar11 = func_0x(0x1ac0940);
                    if (cVar11 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x10161a;
                      cVar11 = func_0x();
                      if (cVar11 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x10162a;
                        cVar11 = func_0x(0x1ac0940);
                        if (cVar11 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101646;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar19) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101669;
                          (*pcRam000000000102e4c0)(1,0x13b034c,0x14d0438,0x80f);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x10167a;
                    func_0x(ppbStack_4160,3);
                  }
                  uVar33 = uStack_4158._4_4_ + (uStack_414c + 1) * 2;
                  uStack_4150._0_2_ = (undefined2)uVar33;
                  uStack_4150._2_2_ = (short)(uVar33 >> 0x10);
                  uStack_4150 = uVar33;
                  if (0x1f9e < uVar33) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1016ad;
                    cVar11 = func_0x(0x1ac0940);
                    if (cVar11 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1016b6;
                      cVar11 = func_0x();
                      if (cVar11 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1016c6;
                        cVar11 = func_0x(0x1ac0940);
                        if (cVar11 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1016e2;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar19) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101705;
                          (*pcRam000000000102e4c0)(1,0x13b034c,0x14d0438,0x816);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101716;
                    func_0x(ppbStack_4160,4);
                  }
                  uStack_4164 = puVar41[uStack_414c] & 0x7fff;
                  if ((puVar41[uStack_414c] & 0x7fff) < uStack_4150) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101749;
                    cVar11 = func_0x(0x1ac0940);
                    if (cVar11 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101752;
                      cVar11 = func_0x();
                      if (cVar11 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101762;
                        cVar11 = func_0x(0x1ac0940);
                        if (cVar11 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x10177e;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar19) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1017a1;
                          (*pcRam000000000102e4c0)(1,0x13b034c,0x14d0438,0x81d);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1017b2;
                    func_0x(ppbStack_4160,4);
                  }
                  ppbVar21 = ppbVar40;
                  ppbVar22 = ppbStack_4160;
                  puVar9 = puVar41;
                  uVar33 = uStack_4150;
                  if (uStack_414c != 0) {
                    do {
                      uVar34 = puVar9[1] & 0x7fff;
                      if ((uVar34 < uStack_4150) || (uStack_4164 < uVar34)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101801;
                        uStack_4150 = uVar33;
                        cVar11 = func_0x(0x1ac0940);
                        if (cVar11 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x10180a;
                          cVar11 = func_0x();
                          if (cVar11 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x10181a;
                            cVar11 = func_0x(0x1ac0940);
                            if (cVar11 == '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101836;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar19) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x10185c;
                              (*pcRam000000000102e4c0)(1,0x13b034c,0x14d0438,0x82a);
                            }
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x10186d;
                        func_0x(ppbStack_4160,4);
                        ppbVar22 = ppbStack_4160;
                        uVar33 = uStack_4150;
                      }
                      uVar30 = (int)ppbVar21 + 1;
                      ppbVar21 = (byte **)(ulonglong)uVar30;
                      uStack_4150 = uVar34;
                      puVar9 = puVar9 + 1;
                    } while ((int)uVar30 < (int)(uint)uStack_414c);
                  }
                  while ((short)puVar41[(ulonglong)(uStack_414c - 1) + 1] < 0) {
                    uVar34 = uVar33;
                    if (uStack_414c != 1) {
                      uVar34 = *(ushort *)
                                ((longlong)ppbVar22 +
                                (ulonglong)uStack_414c * 2 + (((ulonglong)uStack_4158 >> 0x20) - 2))
                               & 0x7fff;
                    }
                    uVar30 = *(ushort *)
                              ((longlong)ppbVar22 +
                              (ulonglong)uStack_414c * 2 + ((ulonglong)uStack_4158 >> 0x20)) &
                             0x7fff;
                    if (((uVar34 < uVar33) || (uVar30 < uVar34)) || (uStack_4164 < uVar30)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1018f3;
                      uStack_4150 = uVar33;
                      func_0x(ppbVar22,7);
                      ppbVar22 = ppbStack_4160;
                      uVar33 = uStack_4150;
                    }
                    uStack_4150 = uVar33;
                    if ((uVar34 < uVar33) || (uStack_4164 < uVar34)) goto code_r0x00101c71;
                    if (*(ushort *)((longlong)ppbVar22 + (ulonglong)uVar34) == 5) {
                      uStack_4166 = uStack_4166 | 2;
                      uStack_414c = uStack_414c - 1;
                      uVar39 = (ulonglong)(uVar34 & 0xffff);
                      uStack_413e = (ushort)uVar34;
                      uVar31 = uVar39 + (longlong)ppbVar22;
                      if ((*(ushort *)(uVar31 + 2) & 0x4000) == 0) {
                        uVar13 = uStack_413c & 0xc7ff;
                      }
                      else {
                        uVar13 = uStack_413c ^ (*(ushort *)(uVar31 + 2) ^ uStack_413c) & 0x3800;
                      }
                      uStack_413c = (uVar13 ^ *(ushort *)(uVar31 + 2)) & 0x7ff ^ uVar13;
                      uVar38 = (ulonglong)uStack_413c;
                      uVar36 = (longlong)ppbVar22 +
                               uVar39 + (uVar38 & 0x7ff) * 2 +
                                        (ulonglong)((uVar13 >> 0xb & 7) * 2) + 4;
                      if (uVar36 < uVar31) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1019ef;
                        func_0x(uVar31,0x19);
                        uVar38 = (ulonglong)uStack_413c;
                        uVar39 = (ulonglong)uStack_413e;
                        ppbVar22 = ppbStack_4160;
                      }
                      uVar33 = uStack_4150;
                      if (uVar30 - uVar34 <
                          (((uStack_413c & 0x7ff) * 2 - (int)uVar39) - (int)ppbStack_4160) +
                          (int)uVar36) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101a33;
                        func_0x(uVar39 + (longlong)ppbVar22,0x19);
                        uVar38 = (ulonglong)uStack_413c;
                        uVar39 = (ulonglong)uStack_413e;
                        ppbVar22 = ppbStack_4160;
                        uVar33 = uStack_4150;
                      }
                      if (((uVar38 & 0x3800) != 0) &&
                         (puVar41 = (ushort *)((longlong)ppbVar22 + uVar39 + 4), ppbVar21 = ppbVar40
                         , (uVar38 & 0x3800) != 0)) {
                        do {
                          if (((ushort)uVar38 & 0x7ff) < (*puVar41 & 0x7ff)) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101a93;
                            uStack_4150 = uVar33;
                            func_0x(uVar39 + (longlong)ppbVar22,0x1a);
                            uVar38 = (ulonglong)uStack_413c;
                            uVar39 = (ulonglong)uStack_413e;
                            ppbVar22 = ppbStack_4160;
                            uVar33 = uStack_4150;
                          }
                          uVar34 = (int)ppbVar21 + 1;
                          ppbVar21 = (byte **)(ulonglong)uVar34;
                          puVar41 = puVar41 + 1;
                        } while ((int)uVar34 < (int)((uStack_413c & 0x3800) >> 0xb));
                      }
                      break;
                    }
                    if (*(ushort *)((longlong)ppbVar22 + (ulonglong)uVar34) < 0x400) break;
                    uStack_4166 = uStack_4166 | 1;
                    uStack_414c = uStack_414c - 1;
                    if (uStack_414c == 0) break;
                  }
                  uVar34 = (uint)uStack_4158;
                }
                if ((*(byte *)ppbVar22 & 0x40) == 0) {
                  uStack_4142 = 0;
                  uStack_4140 = 0;
                }
                else {
                  uStack_4142 = (undefined2)uStack_4164;
                  uStack_4140 = (undefined2)(uStack_4164 >> 0x10);
                  uStack_4164 = uStack_4164 + 0xe;
                  *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101b07;
                  uStack_4150 = uVar33;
                  uVar26 = func_0x(&uStack_4166);
                  *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101b13;
                  func_0x(uVar26,auStack_51b0);
                  *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101b1c;
                  iVar14 = func_0x(auStack_51b0);
                  uStack_4164 = uStack_4164 + iVar14;
                  ppbVar22 = ppbStack_4160;
                  uVar34 = (uint)uStack_4158;
                  uVar33 = uStack_4150;
                }
                uStack_4150 = uVar33;
                if ((CONCAT62(uStack_4148,uStack_414a) != 0) &&
                   (CONCAT62(uStack_4148,uStack_414a) < (ulonglong)uStack_4164 + (longlong)ppbVar22)
                   ) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101b66;
                  cVar11 = func_0x(0x1ac0940);
                  if (cVar11 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101b6f;
                    cVar11 = func_0x();
                    if (cVar11 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101b7f;
                      cVar11 = func_0x(0x1ac0940);
                      if (cVar11 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101b9b;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar19) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101bc1;
                        (*pcRam000000000102e4c0)(1,0x13b034c,0x14d0438,0x886);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101bd2;
                  func_0x(ppbStack_4160,0x12);
                  ppbVar22 = ppbStack_4160;
                  uVar34 = (uint)uStack_4158;
                }
                if (0x3f3b < uStack_4164 - 1) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101bfe;
                  cVar11 = func_0x(0x1ac0940);
                  if (cVar11 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101c07;
                    cVar11 = func_0x();
                    if (cVar11 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101c17;
                      cVar11 = func_0x(0x1ac0940);
                      if (cVar11 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101c33;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar19) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101c59;
                        (*pcRam000000000102e4c0)(1,0x13b034c,0x14d0438,0x88b);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101c6a;
                  func_0x(ppbStack_4160,5);
                  ppbVar22 = ppbStack_4160;
code_r0x00101c71:
                  uVar34 = (uint)uStack_4158;
                }
              }
              sVar29 = -*(short *)((longlong)&uStackX_20 + lVar19);
              if ((*(byte *)((longlong)&uStackX_20 + lVar19 + 6) & 0x10) != 0) {
                if ((*(byte *)ppbVar22 & 0x10) == 0) {
                  if ((1 << (*(byte *)ppbVar22 & 0xe) & 0x1105U) != 0) {
code_r0x00101cdd:
                    ppbVar22 = (byte **)(*(undefined4 **)(&stack0x00000028 + lVar19) + 1);
                    *(undefined4 *)((longlong)auStackX_18 + lVar19) =
                         **(undefined4 **)(&stack0x00000028 + lVar19);
                    goto code_r0x00101e32;
                  }
                }
                else if (((int)uVar34 <= *(int *)((longlong)&uStackX_20 + lVar19)) ||
                        (*(ushort *)((ulonglong)uVar34 + (longlong)ppbVar22) <
                         *(ushort *)((longlong)&uStackX_20 + lVar19 + 4))) goto code_r0x00101cdd;
              }
              if ((uint)uStack_414c < (uint)(int)sVar29) {
                *(undefined4 *)((longlong)auStackX_18 + lVar19) = 0;
              }
              else {
                ppbVar21 = ppbVar22;
                uVar33 = uStack_4150;
                if (sVar29 != 1) {
                  ppbVar21 = ppbStack_4160;
                  uVar33 = *(ushort *)
                            ((longlong)ppbVar22 +
                            (longlong)sVar29 * 2 + (((ulonglong)uStack_4158 >> 0x20) - 2)) & 0x7fff;
                }
                uVar34 = *(ushort *)
                          ((longlong)ppbVar22 +
                          (longlong)sVar29 * 2 + ((ulonglong)uStack_4158 >> 0x20)) & 0x7fff;
                if (((uVar33 < uStack_4150) || (uVar34 < uVar33)) || (uStack_4164 < uVar34)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101d38;
                  func_0x(ppbVar21,7);
                  ppbVar21 = ppbStack_4160;
                }
                ppbVar22 = (byte **)((ulonglong)uVar33 + (longlong)ppbVar21);
                *(uint *)((longlong)auStackX_18 + lVar19) = uVar34 - uVar33;
              }
            }
          }
          else {
            if ((int)uVar37 < (int)uVar34) {
              if ((uint)*(ushort *)(uVar39 + (longlong)ppbStack_4160) < (uVar30 & 0xffff)) {
                bVar12 = 0xff;
                uVar30 = 0;
              }
              else {
                uVar30 = (uVar30 & 0xffff) - 1;
                bVar12 = *(byte *)((longlong)ppbStack_4160 + uVar39 + (ulonglong)(uVar30 >> 3) + 2)
                         >> ((byte)uVar30 & 7);
                uVar30 = 1;
              }
            }
            else {
              bVar12 = 0xff;
              uVar30 = 0;
            }
code_r0x001014d5:
            if ((bVar12 & 1) == 0) {
              if ((uVar30 != 0) || ((*(byte *)((longlong)&uStackX_20 + lVar19 + 6) & 0x10) == 0))
              goto code_r0x00101518;
              goto code_r0x001014fb;
            }
            *(undefined4 *)((longlong)auStackX_18 + lVar19) = 0;
            ppbVar22 = ppbVar40;
          }
        }
      }
      else {
        uStack_527c = 0;
        *(uint **)(&stack0xffffffffffffffe0 + lVar19) = &uStack_527c;
        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101dc7;
        ppbVar22 = (byte **)func_0x(&uStack_4166,(longlong)&uStackX_20 + lVar19,uVar37,
                                            (longlong)auStackX_18 + lVar19);
        if ((((sStack_4168 != 0) && (uStack_4158 != (byte **)0x0)) && (*uStack_4158 != (byte *)0x0))
           && (((*(byte *)((longlong)&uStackX_20 + lVar19 + 6) & 8) == 0 && ((uStack_527c & 1) == 0)
               ))) {
          if ((ppbVar22 == (byte **)0x0) || (ppbVar22 == (byte **)0x1134fe0)) goto code_r0x00101e2a;
          *(uint *)(&stack0xfffffffffffffff8 + lVar19) = uStack_527c;
          *(longlong *)(&stack0xfffffffffffffff0 + lVar19) = (longlong)auStackX_18 + lVar19;
          *(undefined4 *)(&stack0xffffffffffffffe8 + lVar19) = 0;
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar19) = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101e25;
          ppbVar22 = (byte **)func_0x
                                        (uStack_4158,(longlong)&uStackX_20 + lVar19,ppbVar22,
                                         *(undefined4 *)((longlong)auStackX_18 + lVar19));
        }
      }
code_r0x00101e32:
      if (ppbVar22 == (byte **)0x0) {
        lVar23 = *(longlong *)(&stack0x00000000 + lVar19);
        if (lVar23 == 0) goto code_r0x001022d6;
        iVar14 = (int)*(short *)((longlong)auStackX_c + lVar19);
        if (((*(ushort *)(lVar23 + 0x62) >> 10 & 1) != 0) && (2 < iVar14)) goto code_r0x00101fce;
        plVar20 = *(longlong **)(&stack0x00000000 + lVar19);
        if (((byte)*(undefined2 *)(lVar23 + 0x62) >> 3 & 1) != 0) {
          if (iVar14 == 3) {
            iVar14 = 4;
          }
          else if (iVar14 < 2) goto code_r0x00102043;
          if ((((*(uint *)(*(longlong *)(&stack0x00000000 + lVar19) + 100) & 8) != 0) &&
              (lVar23 = *(longlong *)(*(longlong *)(&stack0x00000000 + lVar19) + 0x90), lVar23 != 0)
              ) && (*(longlong *)(lVar23 + 0x758) != 0)) {
            uVar5 = *(undefined8 *)(lVar23 + 0x758);
            *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x102043;
            func_0x(uVar5,*(undefined8 *)(&stack0x00000000 + lVar19),iVar14);
          }
        }
code_r0x00102043:
        if ((((DAT_ & 0x80) == 0) || ((*(uint *)((longlong)plVar20 + 100) & 8) == 0)) ||
           ((iVar14 < 3 ||
            (((*(uint *)((longlong)plVar20 + 100) & 0xc0000000) == 0x40000000 ||
             (lVar23 = *plVar20, lVar23 == 0)))))) goto code_r0x00102168;
        puVar32 = auStack_51bc;
        goto code_r0x00102143;
      }
      if (uVar18 < *(uint *)((longlong)auStackX_18 + lVar19)) {
        lVar23 = *(longlong *)(&stack0x00000000 + lVar19);
        if (lVar23 != 0) {
          iVar14 = (int)*(short *)((longlong)auStackX_c + lVar19);
          if (((*(ushort *)(lVar23 + 0x62) >> 10 & 1) == 0) || (iVar14 < 3)) {
            plVar20 = *(longlong **)(&stack0x00000000 + lVar19);
            if (((byte)*(undefined2 *)(lVar23 + 0x62) >> 3 & 1) != 0) {
              if (iVar14 == 3) {
                iVar14 = 4;
              }
              else if (iVar14 < 2) goto code_r0x00101f11;
              if ((((*(uint *)(*(longlong *)(&stack0x00000000 + lVar19) + 100) & 8) != 0) &&
                  (lVar23 = *(longlong *)(*(longlong *)(&stack0x00000000 + lVar19) + 0x90),
                  lVar23 != 0)) && (*(longlong *)(lVar23 + 0x758) != 0)) {
                uVar5 = *(undefined8 *)(lVar23 + 0x758);
                *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101f11;
                func_0x(uVar5,*(undefined8 *)(&stack0x00000000 + lVar19),iVar14);
              }
            }
code_r0x00101f11:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar20 + 100) & 8) != 0)) &&
               ((2 < iVar14 &&
                (((*(uint *)((longlong)plVar20 + 100) & 0xc0000000) != 0x40000000 &&
                 (lVar23 = *plVar20, lVar23 != 0)))))) {
              *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101f52;
              iVar17 = (*_DAT_)(lVar23,0x2000,2,auStack_51c0);
              if (iVar17 != 0) {
                LOCK();
                *(uint *)((longlong)plVar20 + 100) = *(uint *)((longlong)plVar20 + 100) & 0x3fffffff
                ;
                UNLOCK();
                LOCK();
                *(uint *)((longlong)plVar20 + 100) = *(uint *)((longlong)plVar20 + 100) | 0x40000000
                ;
                UNLOCK();
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101f74;
            func_0x(plVar20 + 0x13,iVar14);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101f93;
              func_0x(plVar20,0,iVar14);
            }
            *(uint *)((longlong)auStackX_c + lVar19) =
                 *(uint *)((longlong)auStackX_c + lVar19) & 0xffff0000;
            *(undefined8 *)(&stack0x00000000 + lVar19) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101ea6;
            func_0x((longlong)&stack0x00000000 + lVar19);
          }
        }
        goto code_r0x001022d6;
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101e55;
      func_0x
                (uVar5,(longlong)(int)uVar18,ppbVar22,
                 *(undefined4 *)((longlong)auStackX_18 + lVar19));
      if (auStackX_18[0] == 0) goto code_r0x001021ad;
      uVar39 = (ulonglong)uStack_4158 & 0xffffffff;
      puVar28 = uStack_5268;
    }
    lVar23 = *(longlong *)(&stack0x00000000 + lVar19);
    if (lVar23 == 0) goto code_r0x001022d6;
    iVar14 = (int)*(short *)((longlong)auStackX_c + lVar19);
    if (((*(ushort *)(lVar23 + 0x62) >> 10 & 1) != 0) && (2 < iVar14)) {
code_r0x00101fce:
      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x101fd8;
      func_0x((longlong)&stack0x00000000 + lVar19);
      goto code_r0x001022d6;
    }
    plVar20 = *(longlong **)(&stack0x00000000 + lVar19);
    if (((byte)*(undefined2 *)(lVar23 + 0x62) >> 3 & 1) != 0) {
      if (iVar14 == 3) {
        iVar14 = 4;
      }
      else if (iVar14 < 2) goto code_r0x00102113;
      if ((((*(uint *)(*(longlong *)(&stack0x00000000 + lVar19) + 100) & 8) != 0) &&
          (lVar23 = *(longlong *)(*(longlong *)(&stack0x00000000 + lVar19) + 0x90), lVar23 != 0)) &&
         (*(longlong *)(lVar23 + 0x758) != 0)) {
        uVar5 = *(undefined8 *)(lVar23 + 0x758);
        *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x102113;
        func_0x(uVar5,*(undefined8 *)(&stack0x00000000 + lVar19),iVar14);
      }
    }
code_r0x00102113:
    if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar20 + 100) & 8) != 0)) &&
       ((2 < iVar14 &&
        (((*(uint *)((longlong)plVar20 + 100) & 0xc0000000) != 0x40000000 &&
         (lVar23 = *plVar20, lVar23 != 0)))))) {
      puVar32 = auStack_51b8;
code_r0x00102143:
      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x102154;
      iVar17 = (*_DAT_)(lVar23,0x2000,2,puVar32);
      if (iVar17 != 0) {
        LOCK();
        *(uint *)((longlong)plVar20 + 100) = *(uint *)((longlong)plVar20 + 100) & 0x3fffffff;
        UNLOCK();
        LOCK();
        *(uint *)((longlong)plVar20 + 100) = *(uint *)((longlong)plVar20 + 100) | 0x40000000;
        UNLOCK();
      }
    }
code_r0x00102168:
    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x102176;
    func_0x(plVar20 + 0x13,iVar14);
    if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x102195;
      func_0x(plVar20,0,iVar14);
    }
    *(undefined8 *)(&stack0x00000000 + lVar19) = 0;
    *(uint *)((longlong)auStackX_c + lVar19) = *(uint *)((longlong)auStackX_c + lVar19) & 0xffff0000
    ;
    goto code_r0x001022d6;
  }
code_r0x001021ad:
  auStackX_18[0] = auStackX_18[0] - 1;
  lVar23 = *(longlong *)(&stack0x00000000 + lVar19);
  if (lVar23 == 0) goto code_r0x001022d6;
  iVar14 = (int)*(short *)((longlong)auStackX_c + lVar19);
  if (((*(ushort *)(lVar23 + 0x62) >> 10 & 1) != 0) && (2 < iVar14)) {
    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1021e2;
    func_0x((longlong)&stack0x00000000 + lVar19);
    goto code_r0x001022d6;
  }
  plVar20 = *(longlong **)(&stack0x00000000 + lVar19);
  if (((byte)*(undefined2 *)(lVar23 + 0x62) >> 3 & 1) != 0) {
    if (iVar14 == 3) {
      iVar14 = 4;
    }
    else if (iVar14 < 2) goto code_r0x00102247;
    if ((((*(uint *)(*(longlong *)(&stack0x00000000 + lVar19) + 100) & 8) != 0) &&
        (lVar23 = *(longlong *)(*(longlong *)(&stack0x00000000 + lVar19) + 0x90), lVar23 != 0)) &&
       (*(longlong *)(lVar23 + 0x758) != 0)) {
      uVar5 = *(undefined8 *)(lVar23 + 0x758);
      *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x102247;
      func_0x(uVar5,*(undefined8 *)(&stack0x00000000 + lVar19),iVar14);
    }
  }
code_r0x00102247:
  if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar20 + 100) & 8) != 0)) &&
     ((2 < iVar14 &&
      (((*(uint *)((longlong)plVar20 + 100) & 0xc0000000) != 0x40000000 &&
       (lVar23 = *plVar20, lVar23 != 0)))))) {
    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x102288;
    iVar17 = (*_DAT_)(lVar23,0x2000,2,auStack_51b4);
    if (iVar17 != 0) {
      LOCK();
      *(uint *)((longlong)plVar20 + 100) = *(uint *)((longlong)plVar20 + 100) & 0x3fffffff;
      UNLOCK();
      LOCK();
      *(uint *)((longlong)plVar20 + 100) = *(uint *)((longlong)plVar20 + 100) | 0x40000000;
      UNLOCK();
    }
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1022aa;
  func_0x(plVar20 + 0x13,iVar14);
  if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
    *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1022c9;
    func_0x(plVar20,0,iVar14);
  }
  *(uint *)((longlong)auStackX_c + lVar19) = *(uint *)((longlong)auStackX_c + lVar19) & 0xffff0000;
  *(undefined8 *)(&stack0x00000000 + lVar19) = 0;
code_r0x001022d6:
  *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1022e0;
  func_0x((longlong)&stack0x00000000 + lVar19);
  *(undefined8 *)((longlong)&uStack_48 + lVar19) = 0x1022f2;
  func_0x(uStack_58 ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar19));
  return;
}

