
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2)

{
  byte *pbVar1;
  byte bVar2;
  ushort uVar3;
  short sVar4;
  uint uVar5;
  char cVar6;
  longlong lVar7;
  short *psVar8;
  code *UNRECOVERED_JUMPTABLE_00;
  uint uVar9;
  undefined8 unaff_RBX;
  byte **ppbVar10;
  ulonglong uVar11;
  undefined4 uStackX_8;
  undefined4 uStack_1778;
  undefined2 uStack_1774;
  undefined8 uStack_1690;
  undefined8 uStack_1670;
  undefined8 uStack_1510;
  undefined2 uStack_1508;
  undefined4 uStack_1500;
  undefined2 uStack_14fc;
  ushort uStack_14fa;
  undefined8 uStack_14f8;
  short sStack_1490;
  undefined4 uStack_148c;
  byte *pbStack_1488;
  byte **ppbStack_1480;
  undefined8 uStack_1472;
  undefined2 uStack_146a;
  undefined2 uStack_1468;
  undefined6 uStack_1466;
  undefined4 uStack_145c;
  undefined auStack_1458 [16];
  undefined auStack_1448 [8];
  undefined8 uStack_1440;
  undefined8 uStack_1438;
  undefined6 uStack_1430;
  undefined2 uStack_142a;
  undefined6 uStack_1428;
  undefined2 uStack_1422;
  undefined8 uStack_1420;
  undefined auStack_1418 [16];
  undefined auStack_1408 [16];
  undefined auStack_13f8 [16];
  undefined8 uStack_13e8;
  undefined auStack_11c8 [4480];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar7 = func_0x();
  lVar7 = -lVar7;
  uStack_1670 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00001aa8 + lVar7) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar7);
  sStack_1490 = -1;
  pbStack_1488 = (byte *)0x0;
  uStack_148c = 0;
  uStack_1472 = 0;
  uStack_1468 = 0;
  uStack_1466 = 0;
  ppbStack_1480 = (byte **)0x0;
  uStack_145c = 0xffffffff;
  *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100097;
  uStack_1690 = param_2;
  (*_DAT_)(auStack_11c8);
  uStack_1500 = 0;
  uStack_14fc = 0;
  uStack_14fa = uStack_14fa & 0xffe0;
  uStack_14f8 = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1000d1;
  (*_DAT_)(auStack_11c8,param_2,0x1404fb0);
  uVar3 = *(ushort *)(param_1 + 0x16);
  uVar9 = (uint)uVar3;
  if ((*(byte *)(param_1 + 4) & 8) != 0) {
    uVar11 = (ulonglong)(uint)uVar3;
    if (uVar3 == 0) goto LAB_;
    psVar8 = (short *)(param_1 + 0x1ffe);
    do {
      uVar5 = uVar9 - 1;
      if (*psVar8 != 0) {
        uVar5 = uVar9;
      }
      uVar9 = uVar5;
      psVar8 = psVar8 + -1;
      uVar11 = uVar11 - 1;
    } while (uVar11 != 0);
  }
  if ((int)uVar9 < 1) {
LAB_:
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100114;
    (*_DAT_)(param_2);
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100124;
    (*_DAT_)(param_2,0x1404f90);
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10012d;
    (*_DAT_)(param_2);
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10013b;
    (*_DAT_)(auStack_11c8);
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x11aaa0;
    func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar7));
    return;
  }
  uStack_145c = 0;
  if (-1 < *(char *)(param_1 + 2)) goto LAB_;
  pbVar1 = (byte *)(param_1 + 0x60);
  if ((sStack_1490 == 0) || (ppbVar10 = ppbStack_1480, ppbStack_1480 == (byte **)0x0)) {
    uStack_1430 = 0;
    uStack_1422 = 0;
    auStack_1408 = ZEXT816(0);
    auStack_1458 = ZEXT816(0);
    stack0xffffffffffffebba = SUB1614(ZEXT816(0),2);
    auStack_1448._0_2_ = 0xffff;
    uStack_1440 = 0;
    uStack_142a = 0;
    uStack_1428 = 0;
    uStack_1420 = 0;
    uStack_1438 = 0;
    auStack_1418 = ZEXT816(0);
    auStack_13f8._0_12_ = ZEXT812(0);
    auStack_13f8._12_4_ = 0;
    uStack_13e8 = 0;
    ppbVar10 = (byte **)auStack_1458;
  }
  if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
    uStack_1510 = *(undefined8 *)(param_1 + 0x28);
    uStack_1508 = *(undefined2 *)(param_1 + 0x30);
  }
  else {
    cVar6 = *(char *)(param_1 + 1);
    if (cVar6 == '\v') {
      if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
        if (cVar6 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar6 != '\b') goto LAB_;
LAB_:
      if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
    }
    uStack_1778 = *(undefined4 *)(param_1 + 0x20);
    uStack_1774 = *(undefined2 *)(param_1 + 0x24);
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100289;
    cVar6 = func_0x(&uStack_1778);
    if (cVar6 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10029c;
    func_0x(param_1,&uStack_1510);
  }
  *ppbVar10 = pbVar1;
  *(undefined4 *)(ppbVar10 + 0xc) = (undefined4)uStack_1510;
  *(int *)((longlong)ppbVar10 + 100) = (int)((ulonglong)uStack_1510 >> 0x20);
  *(undefined2 *)(ppbVar10 + 0xd) = uStack_1508;
  *(undefined4 *)((longlong)ppbVar10 + 0x6c) = *(undefined4 *)(param_1 + 0x20);
  *(undefined2 *)(ppbVar10 + 0xe) = *(undefined2 *)(param_1 + 0x24);
  *(undefined2 *)((longlong)ppbVar10 + 0x72) = 0;
  bVar2 = *pbVar1;
  *(undefined4 *)((longlong)&uStackX_8 + lVar7) = *(undefined4 *)((ulonglong)bVar2 * 6 + 0x11cd020);
  uVar11 = (ulonglong)*(short *)((ulonglong)bVar2 * 6 + 0x11cd024);
  *(undefined2 *)(ppbVar10 + 2) = 0xffff;
  ppbVar10[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar10 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar10 + 0x2e) = 0;
  ppbVar10[7] = (byte *)0x0;
  ppbVar10[4] = (byte *)0x0;
  ppbVar10[9] = (byte *)0x0;
  ppbVar10[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar10 + 0xb) = 0;
  if ((**ppbVar10 & 2) != 0) {
    pbVar1 = pbVar1 + uVar11;
    if ((*pbVar1 & 1) == 0) {
      *(undefined2 *)(ppbVar10 + 2) = 0;
      ppbVar10[3] = pbVar1;
      *(undefined4 *)((longlong)ppbVar10 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbVar10 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100565 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x11e560) - 0x13cbdf0))()
      ;
      return;
    }
    *(undefined2 *)(ppbVar10 + 2) = 1;
    ppbVar10[3] = pbVar1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x11e540) * 4 +
                           0x11e530) - 0x13cbdf0);
                    /* WARNING: Could not emulate address calculation at 0x00100373 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbVar10 & 4) != 0) {
    sVar4 = *(short *)((longlong)&uStackX_8 + lVar7 + 2);
    if (sVar4 != 0) {
      uVar11 = (ulonglong)*(ushort *)(param_1 + 0x61 + (longlong)sVar4 * 2);
    }
    psVar8 = (short *)(pbVar1 + uVar11);
    ppbVar10[9] = (byte *)psVar8;
    sVar4 = *psVar8;
    ppbVar10[10] = (byte *)(psVar8 + 1);
    *(short *)(ppbVar10 + 0xb) = (sVar4 + 1) * 2;
  }
  pbVar1 = ppbVar10[1];
  if (pbVar1 != (byte *)0x0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10061f;
    func_0x(pbVar1,ppbVar10);
  }
LAB_:
  pbStack_1488 = (byte *)((ulonglong)*(ushort *)(param_1 + 0x1ffe) + param_1);
  if ((*pbStack_1488 & 1) == 0) {
    sStack_1490 = 0;
    uStack_148c = 0;
    uStack_146a = 0;
    uStack_1468 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001008c2 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_1488 & 0xe) * 4 + 0x11e5cc) - 0x13cbdf0
              ))(0x114e740);
    return;
  }
  sStack_1490 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_1488 & 0x1c) + 0x11e5ac) * 4
                         + 0x11e59c) - 0x13cbdf0);
                    /* WARNING: Could not emulate address calculation at 0x00100675 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

