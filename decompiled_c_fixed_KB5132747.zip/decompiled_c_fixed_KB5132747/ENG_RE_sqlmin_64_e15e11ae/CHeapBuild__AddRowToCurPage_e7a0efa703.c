
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong param_1,short *param_2)

{
  ushort *puVar1;
  char cVar2;
  ushort uVar3;
  ushort uVar4;
  longlong lVar5;
  undefined8 uVar6;
  ulonglong *puVar7;
  byte bVar8;
  uint uVar9;
  uint uVar10;
  ulonglong uVar11;
  int iVar12;
  uint uVar13;
  uint uVar14;
  ulonglong uVar15;
  byte *pbVar16;
  ulonglong uVar17;
  ushort *puVar18;
  undefined auStackX_10 [8];
  
  uVar9 = *(uint *)(param_2 + 2);
  iVar12 = 0;
  if (*param_2 == 0) {
    if (uVar9 == 0) {
      pbVar16 = *(byte **)(param_2 + 4);
      param_2[1] = 0;
      uVar9 = *(uint *)(param_2 + 8);
      uVar11 = (ulonglong)uVar9;
      *(uint *)(param_2 + 10) = uVar9;
      bVar8 = *pbVar16;
      if ((bVar8 & 0x10) != 0) {
        uVar9 = uVar9 + 2 + (*(ushort *)(pbVar16 + uVar11) + 7 >> 3);
        uVar11 = (ulonglong)uVar9;
        *(uint *)(param_2 + 10) = uVar9;
        bVar8 = *pbVar16;
      }
      if ((bVar8 & 0x20) == 0) {
        *(int *)(param_2 + 2) = (int)uVar11;
        param_2[0xe] = 0;
        *(int *)(param_2 + 0xc) = (int)uVar11;
      }
      else {
        puVar18 = (ushort *)(pbVar16 + uVar11);
        uVar3 = *puVar18;
        param_2[0xe] = uVar3;
        if (uVar3 == 0) {
          cVar2 = func_0x(0x19a5940);
          if (((cVar2 != '\0') && (lVar5 = func_0x(), lVar5 != 0)) &&
             (*(char *)(lVar5 + 0x499) != '\0')) {
            cVar2 = func_0x(0x19a5940);
            if (cVar2 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0x129534c,0x13b5438,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),3);
          uVar11 = (ulonglong)*(uint *)(param_2 + 10);
          uVar3 = param_2[0xe];
        }
        uVar9 = (int)uVar11 + (uVar3 + 1) * 2;
        *(uint *)(param_2 + 0xc) = uVar9;
        if (0x1f9e < uVar9) {
          cVar2 = func_0x(0x19a5940);
          if (((cVar2 != '\0') && (lVar5 = func_0x(), lVar5 != 0)) &&
             (*(char *)(lVar5 + 0x499) != '\0')) {
            cVar2 = func_0x(0x19a5940);
            if (cVar2 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x129534c,0x13b5438,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar3 = param_2[0xe];
          uVar9 = *(uint *)(param_2 + 0xc);
        }
        uVar11 = (ulonglong)uVar3;
        uVar3 = puVar18[uVar11];
        *(uint *)(param_2 + 2) = uVar3 & 0x7fff;
        if ((uVar3 & 0x7fff) < uVar9) {
          cVar2 = func_0x(0x19a5940);
          if (((cVar2 != '\0') && (lVar5 = func_0x(), lVar5 != 0)) &&
             (*(char *)(lVar5 + 0x499) != '\0')) {
            cVar2 = func_0x(0x19a5940);
            if (cVar2 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x129534c,0x13b5438,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar9 = *(uint *)(param_2 + 0xc);
          uVar11 = (ulonglong)(ushort)param_2[0xe];
        }
        puVar1 = puVar18;
        if ((short)uVar11 != 0) {
          do {
            uVar14 = puVar1[1] & 0x7fff;
            if ((uVar14 < uVar9) || (*(uint *)(param_2 + 2) < uVar14)) {
              cVar2 = func_0x(0x19a5940);
              if ((cVar2 != '\0') &&
                 ((lVar5 = func_0x(), lVar5 != 0 &&
                  (*(char *)(lVar5 + 0x499) != '\0')))) {
                cVar2 = func_0x(0x19a5940);
                if (cVar2 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x129534c,0x13b5438,0x82a,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
            }
            uVar11 = (ulonglong)(ushort)param_2[0xe];
            iVar12 = iVar12 + 1;
            puVar1 = puVar1 + 1;
            uVar9 = uVar14;
          } while (iVar12 < (int)(uint)(ushort)param_2[0xe]);
        }
        if ((short)puVar18[(ulonglong)((int)uVar11 - 1) + 1] < 0) {
          pbVar16 = *(byte **)(param_2 + 4);
          do {
            uVar14 = *(ushort *)(pbVar16 + uVar11 * 2 + (ulonglong)*(uint *)(param_2 + 10)) & 0x7fff
            ;
            if ((int)uVar11 == 1) {
              uVar10 = *(uint *)(param_2 + 0xc);
              uVar15 = (ulonglong)uVar10;
LAB_:
              if ((uVar14 < (uint)uVar15) || (uVar9 = *(uint *)(param_2 + 2), uVar9 < uVar14))
              goto LAB_;
            }
            else {
              uVar10 = *(uint *)(param_2 + 0xc);
              uVar15 = (ulonglong)
                       (*(ushort *)(pbVar16 + uVar11 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2))
                       & 0x7fff);
              if (uVar10 <= (*(ushort *)
                              (pbVar16 + uVar11 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) &
                            0x7fff)) goto LAB_;
LAB_:
              func_0x(pbVar16,7);
              uVar10 = *(uint *)(param_2 + 0xc);
              uVar9 = *(uint *)(param_2 + 2);
            }
            uVar13 = (uint)uVar15;
            if ((uVar13 < uVar10) || (uVar9 < uVar13)) goto LAB_;
            pbVar16 = *(byte **)(param_2 + 4);
            if (*(ushort *)(pbVar16 + uVar15) == 5) {
              param_2[1] = param_2[1] | 2;
              param_2[0xe] = param_2[0xe] + -1;
              uVar17 = uVar15 & 0xffff;
              param_2[0x15] = (short)uVar15;
              uVar11 = *(ulonglong *)(param_2 + 4);
              uVar3 = param_2[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar17 + 2 + uVar11) >> 0xe & 1) != 0) {
                uVar3 = *(ushort *)(uVar17 + 2 + uVar11) & 0x3800 | param_2[0x16] & 0xc7ffU;
              }
              param_2[0x16] = uVar3;
              uVar4 = (uVar3 ^ *(ushort *)(uVar17 + 2 + uVar11)) & 0x7ff ^ uVar3;
              param_2[0x16] = uVar4;
              uVar15 = (ulonglong)((uVar4 & 0x7ff) * 2) + 4 + uVar11 + (uVar3 >> 0xb & 7) * 2 +
                       uVar17;
              if (uVar15 < uVar17 + uVar11) {
                func_0x(uVar17 + uVar11,0x19);
                uVar4 = param_2[0x16];
                uVar17 = (ulonglong)(ushort)param_2[0x15];
                uVar11 = (ulonglong)*(uint *)(param_2 + 4);
              }
              if (uVar14 - uVar13 <
                  (((uVar4 & 0x7ff) * 2 - (int)uVar17) - (int)uVar11) + (int)uVar15) {
                func_0x(uVar17 + *(longlong *)(param_2 + 4),0x19);
                uVar4 = param_2[0x16];
              }
              if ((uVar4 & 0x3800) != 0) {
                puVar18 = (ushort *)
                          (*(longlong *)(param_2 + 4) + (ulonglong)(ushort)param_2[0x15] + 4);
                iVar12 = 0;
                if ((uVar4 & 0x3800) != 0) {
                  do {
                    if ((uVar4 & 0x7ff) < (*puVar18 & 0x7ff)) {
                      func_0x((ulonglong)(ushort)param_2[0x15] + *(longlong *)(param_2 + 4),
                                      0x1a);
                      uVar4 = param_2[0x16];
                    }
                    iVar12 = iVar12 + 1;
                    puVar18 = puVar18 + 1;
                  } while (iVar12 < (int)(uVar4 >> 0xb & 7));
                }
              }
              goto LAB_;
            }
            if (*(ushort *)(pbVar16 + uVar15) < 0x400) goto LAB_;
            param_2[1] = param_2[1] | 1;
            uVar3 = param_2[0xe] - 1;
            param_2[0xe] = uVar3;
            if (uVar3 == 0) goto LAB_;
            uVar11 = (ulonglong)uVar3;
          } while ((short)puVar18[(ulonglong)(uVar3 - 1) + 1] < 0);
          uVar11 = (ulonglong)*(uint *)(param_2 + 2);
        }
        else {
LAB_:
          pbVar16 = *(byte **)(param_2 + 4);
          uVar11 = (ulonglong)*(uint *)(param_2 + 2);
        }
      }
      if ((*pbVar16 & 0x40) == 0) {
        *(undefined4 *)(param_2 + 0x13) = 0;
      }
      else {
        *(int *)(param_2 + 0x13) = (int)uVar11;
        *(int *)(param_2 + 2) = (int)uVar11 + 0xe;
        uVar6 = func_0x(param_2 + 1);
        func_0x(uVar6,auStackX_10);
        iVar12 = func_0x(auStackX_10);
        *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar12;
        uVar11 = (ulonglong)*(uint *)(param_2 + 2);
      }
      if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
         (*(ulonglong *)(param_2 + 0xf) < uVar11 + *(longlong *)(param_2 + 4))) {
        cVar2 = func_0x(0x19a5940);
        if ((cVar2 != '\0') &&
           ((lVar5 = func_0x(), lVar5 != 0 && (*(char *)(lVar5 + 0x499) != '\0'))))
        {
          cVar2 = func_0x(0x19a5940);
          if (cVar2 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0x129534c,0x13b5438,0x886,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),0x12);
        uVar11 = (ulonglong)*(uint *)(param_2 + 2);
      }
      uVar9 = (uint)uVar11;
      if ((uVar9 == 0) || (0x3f3c < uVar9)) {
        cVar2 = func_0x(0x19a5940);
        if ((cVar2 != '\0') &&
           ((lVar5 = func_0x(), lVar5 != 0 && (*(char *)(lVar5 + 0x499) != '\0'))))
        {
          cVar2 = func_0x(0x19a5940);
          if (cVar2 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0x129534c,0x13b5438,0x88b,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),5);
        uVar9 = *(uint *)(param_2 + 2);
      }
    }
LAB_:
    uVar14 = uVar9;
    if ((uVar9 < 9) &&
       (((**(byte **)(param_2 + 4) & 0xe) == 0 || ((**(byte **)(param_2 + 4) & 0xe) == 0xc)))) {
      uVar14 = 9;
    }
  }
  else {
    if (uVar9 == 0) {
      func_0x(param_2 + 1);
      uVar9 = *(uint *)(param_2 + 2);
    }
    uVar14 = uVar9;
    if ((uVar9 < 9) &&
       (((**(byte **)(param_2 + 4) & 0x1c) == 0 || ((**(byte **)(param_2 + 4) & 0x1c) == 0xc)))) {
      uVar14 = 9;
    }
  }
  uVar13 = 0;
  uVar3 = *(ushort *)(*(longlong *)(param_1 + 0x250) + 0x1c);
  uVar10 = uVar3 - 2;
  if (uVar3 < 3) {
    uVar10 = uVar13;
  }
  uVar3 = (ushort)((1 << ((byte)*(undefined2 *)(*(longlong *)(param_1 + 0x250) + 4) & 2)) + -1);
  if (uVar10 < (ushort)((short)uVar14 + uVar3 & ~uVar3)) {
    return 0xffffffff;
  }
  if (*param_2 == 0) {
    if (uVar9 == 0) {
      pbVar16 = *(byte **)(param_2 + 4);
      uVar9 = *(uint *)(param_2 + 8);
      uVar11 = (ulonglong)uVar9;
      param_2[1] = 0;
      *(uint *)(param_2 + 10) = uVar9;
      bVar8 = *pbVar16;
      if ((bVar8 & 0x10) != 0) {
        uVar9 = uVar9 + 2 + (*(ushort *)(pbVar16 + uVar11) + 7 >> 3);
        uVar11 = (ulonglong)uVar9;
        *(uint *)(param_2 + 10) = uVar9;
        bVar8 = *pbVar16;
      }
      if ((bVar8 & 0x20) == 0) {
        *(int *)(param_2 + 2) = (int)uVar11;
        param_2[0xe] = 0;
        *(int *)(param_2 + 0xc) = (int)uVar11;
      }
      else {
        puVar18 = (ushort *)(pbVar16 + uVar11);
        uVar3 = *puVar18;
        param_2[0xe] = uVar3;
        if (uVar3 == 0) {
          cVar2 = func_0x(0x19a5940);
          if (((cVar2 != '\0') && (lVar5 = func_0x(), lVar5 != 0)) &&
             (*(char *)(lVar5 + 0x499) != '\0')) {
            cVar2 = func_0x(0x19a5940);
            if (cVar2 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0x129534c,0x13b5438,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),3);
          uVar11 = (ulonglong)*(uint *)(param_2 + 10);
          uVar3 = param_2[0xe];
        }
        uVar9 = (int)uVar11 + (uVar3 + 1) * 2;
        *(uint *)(param_2 + 0xc) = uVar9;
        if (0x1f9e < uVar9) {
          cVar2 = func_0x(0x19a5940);
          if (((cVar2 != '\0') && (lVar5 = func_0x(), lVar5 != 0)) &&
             (*(char *)(lVar5 + 0x499) != '\0')) {
            cVar2 = func_0x(0x19a5940);
            if (cVar2 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x129534c,0x13b5438,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar3 = param_2[0xe];
          uVar9 = *(uint *)(param_2 + 0xc);
        }
        uVar11 = (ulonglong)uVar3;
        uVar3 = puVar18[uVar11];
        *(uint *)(param_2 + 2) = uVar3 & 0x7fff;
        if ((uVar3 & 0x7fff) < uVar9) {
          cVar2 = func_0x(0x19a5940);
          if (((cVar2 != '\0') && (lVar5 = func_0x(), lVar5 != 0)) &&
             (*(char *)(lVar5 + 0x499) != '\0')) {
            cVar2 = func_0x(0x19a5940);
            if (cVar2 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x129534c,0x13b5438,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar9 = *(uint *)(param_2 + 0xc);
          uVar11 = (ulonglong)(ushort)param_2[0xe];
        }
        puVar1 = puVar18;
        if ((short)uVar11 != 0) {
          do {
            uVar14 = puVar1[1] & 0x7fff;
            if ((uVar14 < uVar9) || (*(uint *)(param_2 + 2) < uVar14)) {
              cVar2 = func_0x(0x19a5940);
              if ((cVar2 != '\0') &&
                 ((lVar5 = func_0x(), lVar5 != 0 &&
                  (*(char *)(lVar5 + 0x499) != '\0')))) {
                cVar2 = func_0x(0x19a5940);
                if (cVar2 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x129534c,0x13b5438,0x82a,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
            }
            uVar11 = (ulonglong)(ushort)param_2[0xe];
            uVar13 = uVar13 + 1;
            puVar1 = puVar1 + 1;
            uVar9 = uVar14;
          } while ((int)uVar13 < (int)(uint)(ushort)param_2[0xe]);
        }
        if ((short)puVar18[(ulonglong)((int)uVar11 - 1) + 1] < 0) {
          pbVar16 = *(byte **)(param_2 + 4);
          do {
            uVar14 = *(ushort *)(pbVar16 + uVar11 * 2 + (ulonglong)*(uint *)(param_2 + 10)) & 0x7fff
            ;
            if ((int)uVar11 == 1) {
              uVar10 = *(uint *)(param_2 + 0xc);
              uVar15 = (ulonglong)uVar10;
LAB_:
              if ((uVar14 < (uint)uVar15) || (uVar9 = *(uint *)(param_2 + 2), uVar9 < uVar14))
              goto LAB_;
            }
            else {
              uVar10 = *(uint *)(param_2 + 0xc);
              uVar15 = (ulonglong)
                       (*(ushort *)(pbVar16 + uVar11 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2))
                       & 0x7fff);
              if (uVar10 <= (*(ushort *)
                              (pbVar16 + uVar11 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) &
                            0x7fff)) goto LAB_;
LAB_:
              func_0x(pbVar16,7);
              uVar10 = *(uint *)(param_2 + 0xc);
              uVar9 = *(uint *)(param_2 + 2);
            }
            uVar13 = (uint)uVar15;
            if ((uVar13 < uVar10) || (uVar9 < uVar13)) goto LAB_;
            pbVar16 = *(byte **)(param_2 + 4);
            if (*(ushort *)(pbVar16 + uVar15) == 5) {
              param_2[1] = param_2[1] | 2;
              param_2[0xe] = param_2[0xe] + -1;
              uVar17 = uVar15 & 0xffff;
              param_2[0x15] = (short)uVar15;
              uVar11 = *(ulonglong *)(param_2 + 4);
              uVar3 = param_2[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar17 + 2 + uVar11) >> 0xe & 1) != 0) {
                uVar3 = *(ushort *)(uVar17 + 2 + uVar11) & 0x3800 | param_2[0x16] & 0xc7ffU;
              }
              param_2[0x16] = uVar3;
              uVar4 = (uVar3 ^ *(ushort *)(uVar17 + 2 + uVar11)) & 0x7ff ^ uVar3;
              param_2[0x16] = uVar4;
              uVar15 = uVar11 + 4 +
                       (ulonglong)((uVar4 & 0x7ff) * 2) + uVar17 + (uVar3 >> 0xb & 7) * 2;
              if (uVar15 < uVar17 + uVar11) {
                func_0x(uVar17 + uVar11,0x19);
                uVar4 = param_2[0x16];
                uVar17 = (ulonglong)(ushort)param_2[0x15];
                uVar11 = (ulonglong)*(uint *)(param_2 + 4);
              }
              if (uVar14 - uVar13 <
                  (((uVar4 & 0x7ff) * 2 - (int)uVar17) - (int)uVar11) + (int)uVar15) {
                func_0x(uVar17 + *(longlong *)(param_2 + 4),0x19);
                uVar4 = param_2[0x16];
              }
              if ((uVar4 & 0x3800) != 0) {
                puVar18 = (ushort *)
                          (*(longlong *)(param_2 + 4) + (ulonglong)(ushort)param_2[0x15] + 4);
                iVar12 = 0;
                if ((uVar4 & 0x3800) != 0) {
                  do {
                    if ((uVar4 & 0x7ff) < (*puVar18 & 0x7ff)) {
                      func_0x((ulonglong)(ushort)param_2[0x15] + *(longlong *)(param_2 + 4),
                                      0x1a);
                      uVar4 = param_2[0x16];
                    }
                    iVar12 = iVar12 + 1;
                    puVar18 = puVar18 + 1;
                  } while (iVar12 < (int)(uVar4 >> 0xb & 7));
                }
              }
              goto LAB_;
            }
            if (*(ushort *)(pbVar16 + uVar15) < 0x400) goto LAB_;
            param_2[1] = param_2[1] | 1;
            uVar3 = param_2[0xe] - 1;
            param_2[0xe] = uVar3;
            if (uVar3 == 0) goto LAB_;
            uVar11 = (ulonglong)uVar3;
          } while ((short)puVar18[(ulonglong)(uVar3 - 1) + 1] < 0);
          uVar11 = (ulonglong)*(uint *)(param_2 + 2);
        }
        else {
LAB_:
          pbVar16 = *(byte **)(param_2 + 4);
          uVar11 = (ulonglong)*(uint *)(param_2 + 2);
        }
      }
      iVar12 = 0;
      if ((*pbVar16 & 0x40) == 0) {
        *(undefined4 *)(param_2 + 0x13) = 0;
      }
      else {
        *(int *)(param_2 + 0x13) = (int)uVar11;
        *(int *)(param_2 + 2) = (int)uVar11 + 0xe;
        puVar7 = (ulonglong *)func_0x(param_2 + 1);
        uVar4 = (ushort)(*puVar7 >> 0x30);
        uVar3 = uVar4;
        if ((((uint)(int)(short)uVar4 >> 1 ^ (int)(short)uVar4) & 0x2000) != 0) {
          uVar3 = uVar4 & 0xdfff;
          if ((uVar4 >> 0xe & 1) != 0) {
            uVar3 = uVar4 | 0x2000;
          }
        }
        if (uVar3 == 0xfffc) {
          iVar12 = (int)((*puVar7 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar12;
        uVar11 = (ulonglong)*(uint *)(param_2 + 2);
      }
      if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
         (*(ulonglong *)(param_2 + 0xf) < uVar11 + *(longlong *)(param_2 + 4))) {
        cVar2 = func_0x(0x19a5940);
        if ((cVar2 != '\0') &&
           ((lVar5 = func_0x(), lVar5 != 0 && (*(char *)(lVar5 + 0x499) != '\0'))))
        {
          cVar2 = func_0x(0x19a5940);
          if (cVar2 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0x129534c,0x13b5438,0x886,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),0x12);
        uVar11 = (ulonglong)*(uint *)(param_2 + 2);
      }
      uVar9 = (uint)uVar11;
      if ((uVar9 == 0) || (0x3f3c < uVar9)) {
        cVar2 = func_0x(0x19a5940);
        if ((cVar2 != '\0') &&
           ((lVar5 = func_0x(), lVar5 != 0 && (*(char *)(lVar5 + 0x499) != '\0'))))
        {
          cVar2 = func_0x(0x19a5940);
          if (cVar2 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0x129534c,0x13b5438,0x88b,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),5);
        uVar9 = *(uint *)(param_2 + 2);
      }
    }
LAB_:
    if (uVar9 < 9) {
      bVar8 = **(byte **)(param_2 + 4) & 0xe;
joined_r0x00100ead:
      uVar14 = 9;
      if ((bVar8 == 0) || (bVar8 == 0xc)) goto LAB_;
    }
  }
  else {
    if (uVar9 == 0) {
      func_0x(param_2 + 1);
      uVar9 = *(uint *)(param_2 + 2);
    }
    if (uVar9 < 9) {
      bVar8 = **(byte **)(param_2 + 4) & 0x1c;
      goto joined_r0x00100ead;
    }
  }
  uVar14 = uVar9;
LAB_:
  uVar6 = func_0x
                    (*(undefined8 *)(param_1 + 0x250),*(undefined8 *)(param_2 + 4),uVar14);
  return uVar6;
}

