
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4)

{
  short *psVar1;
  byte *pbVar2;
  uint *puVar3;
  byte bVar4;
  longlong *plVar5;
  ushort *puVar6;
  bool bVar7;
  char cVar8;
  ushort uVar9;
  int iVar10;
  int iVar11;
  longlong lVar12;
  longlong lVar13;
  undefined8 uVar14;
  ulonglong uVar15;
  uint uVar16;
  ulonglong uVar17;
  uint uVar18;
  undefined8 unaff_RBX;
  uint *puVar19;
  undefined *puVar20;
  uint uVar21;
  uint *puVar22;
  short sVar23;
  ushort uVar24;
  uint *puVar25;
  ulonglong uVar26;
  ushort *puVar27;
  byte *pbVar28;
  uint auStackX_8 [2];
  short sStackX_10;
  ushort uStackX_12;
  uint uStackX_14;
  uint *puStackX_18;
  undefined8 uStackX_20;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  puVar20 = &stack0xffffffffffffffc8 + lVar12;
  puVar3 = (uint *)((longlong)auStackX_8 + lVar12);
  *(undefined8 *)(&stack0x000000c0 + lVar12) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000041a0 + lVar12) = unaff_RBX;
  *(ulonglong *)(&stack0x00004138 + lVar12) = _DAT_ ^ (ulonglong)puVar3;
  *(undefined4 *)(&stack0x00000060 + lVar12) = param_4;
  *(undefined8 *)(&stack0x00000088 + lVar12) = param_2;
  *(undefined2 *)((longlong)&sStackX_10 + lVar12) = 0xffff;
  uVar26 = 0;
  *(undefined8 *)((longlong)&puStackX_18 + lVar12) = 0;
  *(undefined4 *)((longlong)&sStackX_10 + lVar12 + 4) = 0;
  *(undefined8 *)(&stack0x0000002e + lVar12) = 0;
  *(undefined8 *)(&stack0x00000038 + lVar12) = 0;
  *(undefined8 *)((longlong)&uStackX_20 + lVar12) = 0;
  *puVar3 = 0;
  *(undefined8 *)(&stack0x00000068 + lVar12) = 0;
  *(undefined4 *)(&stack0x00000050 + lVar12) = 0;
  lVar13 = *(longlong *)(param_1 + 8);
  uVar17 = 0x1f9e;
  if (*(int *)(lVar13 + 0x100) == 2) {
    if ((*(byte *)(lVar13 + 0x42) & 4) == 0) {
      uVar26 = (ulonglong)*(uint *)(lVar13 + 0xb0);
      if (0x1f9e < *(uint *)(lVar13 + 0xb0)) {
        uVar26 = 0x1f9e;
      }
    }
    else {
      uVar26 = 0x1f9e;
    }
    *(int *)(&stack0x00000050 + lVar12) = (int)uVar26;
    uVar15 = uVar26 + 0xf;
    if (uVar15 <= uVar26) {
      uVar15 = 0xffffffffffffff0;
    }
    uVar15 = uVar15 & 0xfffffffffffffff0;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1000d4;
    func_0x();
    puVar20 = &stack0xffffffffffffffc8 + -uVar15 + lVar12;
    *(ulonglong *)(&stack0x00000068 + lVar12) = (longlong)auStackX_8 + -uVar15 + lVar12;
  }
  *(undefined4 *)(puVar20 + 0x20) = 1;
  *(undefined8 *)(puVar20 + -8) = 0x1000fe;
  func_0x(param_3,&stack0x00002198 + lVar12,uVar17 & 0xffffffff,
                  (longlong)&sStackX_10 + lVar12);
  *(longlong *)(&stack0x00000090 + lVar12) = param_1;
  *(undefined4 *)(&stack0x00000098 + lVar12) = 9;
  *(undefined8 *)(&stack0x000000a8 + lVar12) = 0;
  *(undefined4 *)(&stack0x000000a0 + lVar12) = 0;
  *(undefined4 *)(&stack0x000000b8 + lVar12) = 0;
  plVar5 = *(longlong **)(*(longlong *)(param_1 + 8) + 0x160);
  *(longlong *)(&stack0x000000b0 + lVar12) = (longlong)&sStackX_10 + lVar12;
  lVar13 = *plVar5;
  *(int *)(&stack0x0000009c + lVar12) = *(int *)(lVar13 + 0x10) - *(int *)(lVar13 + 0x18);
  *(undefined8 *)(puVar20 + -8) = 0x100157;
  iVar10 = func_0x(&stack0x00000090 + lVar12,&stack0x00000058 + lVar12);
joined_r0x00100159:
  if (iVar10 == 0) {
    uVar26 = *(ulonglong *)(&stack0x00004138 + lVar12);
    *(undefined8 *)(puVar20 + -8) = 0x100e18;
    func_0x(uVar26 ^ (ulonglong)puVar3);
    return;
  }
  puVar19 = (uint *)0x1601910;
  puVar25 = *(uint **)(&stack0x00000058 + lVar12);
  uVar9 = *(ushort *)(puVar25 + 1);
  *(ushort *)(&stack0x0000004c + lVar12) = uVar9;
  bVar4 = *(byte *)(puVar25 + 8);
  puVar22 = puVar25 + 0xe;
  *(uint **)(&stack0x00000080 + lVar12) = puVar22;
  uVar16 = (uint)*(ushort *)puVar22;
  if (*(short *)((longlong)&sStackX_10 + lVar12) == 0) {
    uVar18 = *puVar25;
    if ((uVar18 & 0xc0000000) == 0x80000000) {
      *(undefined8 *)(puVar20 + -8) = 0x100ac1;
      iVar10 = func_0x((longlong)&sStackX_10 + lVar12 + 2);
      if (iVar10 == 0) {
        *puVar3 = 0;
        puVar19 = (uint *)0x0;
      }
      else {
        *(undefined8 *)(puVar20 + -8) = 0x100ad9;
        puVar19 = (uint *)func_0x(&stack0x0000003a + lVar12,puVar25,puVar3,
                                          &stack0x00000070 + lVar12);
      }
      goto LAB_;
    }
    uVar21 = *(uint *)((longlong)&uStackX_20 + lVar12);
    uVar26 = (ulonglong)uVar21;
    puVar22 = *(uint **)((longlong)&puStackX_18 + lVar12);
    if (((bVar4 & 2) != 0) || ((*(byte *)((longlong)puVar25 + 6) & 0x10) != 0)) {
      if ((*(byte *)puVar22 & 0x10) == 0) {
        if ((1 << (*(byte *)puVar22 & 0xe) & 0x1105U) == 0) {
          uVar24 = 0;
          bVar7 = true;
        }
        else {
LAB_:
          uVar24 = ~(*(ushort *)((longlong)puVar25 + 6) >> 4) & 1;
          bVar7 = false;
        }
        if ((bVar4 & 2) != 0) goto LAB_;
      }
      else {
        if (((int)uVar21 <= (int)uVar18) || (*(ushort *)(uVar26 + (longlong)puVar22) < uVar9))
        goto LAB_;
        if ((bVar4 & 2) == 0) goto LAB_;
        uVar24 = *(byte *)((longlong)puVar22 + uVar26 + (ulonglong)(uVar9 - 1 >> 3) + 2) >>
                 ((byte)(uVar9 - 1) & 7) & 1;
        bVar7 = true;
LAB_:
        if (uVar24 != 0) {
          *puVar3 = 0;
          puVar19 = (uint *)0x0;
          puVar22 = *(uint **)(&stack0x00000080 + lVar12);
          goto LAB_;
        }
      }
      if ((!bVar7) && ((*(byte *)((longlong)puVar25 + 6) & 0x10) != 0)) {
        puVar19 = *(uint **)(puVar25 + 2) + 1;
        *puVar3 = **(uint **)(puVar25 + 2);
        puVar22 = *(uint **)(&stack0x00000080 + lVar12);
        goto LAB_;
      }
    }
LAB_:
    if ((int)uVar18 < 0) {
      uVar16 = *(uint *)((longlong)&sStackX_10 + lVar12 + 4);
      puVar19 = puVar22;
      if (uVar16 == 0) {
        iVar10 = 0;
        *(undefined2 *)((longlong)&sStackX_10 + lVar12 + 2) = 0;
        *(uint *)((longlong)&uStackX_20 + lVar12 + 4) = uVar21;
        if ((*(byte *)puVar22 & 0x10) != 0) {
          *(uint *)((longlong)&uStackX_20 + lVar12 + 4) =
               uVar21 + 2 + (*(ushort *)(uVar26 + (longlong)puVar22) + 7 >> 3);
        }
        if ((*(byte *)puVar22 & 0x20) == 0) {
          uVar16 = *(uint *)((longlong)&uStackX_20 + lVar12 + 4);
          uVar17 = (ulonglong)uVar16;
          *(uint *)((longlong)&sStackX_10 + lVar12 + 4) = uVar16;
          *(undefined2 *)(&stack0x0000002c + lVar12) = 0;
          *(uint *)(&stack0x00000028 + lVar12) = uVar16;
        }
        else {
          puVar27 = (ushort *)
                    ((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar12 + 4) + (longlong)puVar22);
          uVar9 = *puVar27;
          *(ushort *)(&stack0x0000002c + lVar12) = uVar9;
          if (uVar9 == 0) {
            *(undefined8 *)(puVar20 + -8) = 0x1003a0;
            cVar8 = func_0x(0x1f8d270);
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar20 + -8) = 0x1003a9;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)(puVar20 + -8) = 0x1003c2;
                cVar8 = func_0x(0x1f8d270);
                if (cVar8 == '\0') {
                  *(undefined8 *)(puVar20 + -8) = 0x1003de;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar20 + 0x20) = 0;
                  *(undefined8 *)(puVar20 + -8) = 0x100404;
                  (*_DAT_)(1,0x187cc7c,0x199cd68,0x80f);
                }
              }
            }
            uVar14 = *(undefined8 *)((longlong)&puStackX_18 + lVar12);
            *(undefined8 *)(puVar20 + -8) = 0x100412;
            func_0x(uVar14,3);
            puVar22 = *(uint **)((longlong)&puStackX_18 + lVar12);
          }
          uVar16 = *(int *)((longlong)&uStackX_20 + lVar12 + 4) +
                   (*(ushort *)(&stack0x0000002c + lVar12) + 1) * 2;
          *(uint *)(&stack0x00000028 + lVar12) = uVar16;
          if (0x1f9e < uVar16) {
            *(undefined8 *)(puVar20 + -8) = 0x10043d;
            cVar8 = func_0x(0x1f8d270);
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar20 + -8) = 0x100446;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)(puVar20 + -8) = 0x10045f;
                cVar8 = func_0x(0x1f8d270);
                if (cVar8 == '\0') {
                  *(undefined8 *)(puVar20 + -8) = 0x10047b;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar20 + 0x20) = 0;
                  *(undefined8 *)(puVar20 + -8) = 0x1004a1;
                  (*_DAT_)(1,0x187cc7c,0x199cd68,0x816);
                }
              }
            }
            uVar14 = *(undefined8 *)((longlong)&puStackX_18 + lVar12);
            *(undefined8 *)(puVar20 + -8) = 0x1004af;
            func_0x(uVar14,4);
            puVar22 = *(uint **)((longlong)&puStackX_18 + lVar12);
          }
          uVar16 = puVar27[*(ushort *)(&stack0x0000002c + lVar12)] & 0x7fff;
          *(uint *)((longlong)&sStackX_10 + lVar12 + 4) = uVar16;
          if (uVar16 < *(uint *)(&stack0x00000028 + lVar12)) {
            *(undefined8 *)(puVar20 + -8) = 0x1004dd;
            cVar8 = func_0x(0x1f8d270);
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar20 + -8) = 0x1004e6;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)(puVar20 + -8) = 0x1004ff;
                cVar8 = func_0x(0x1f8d270);
                if (cVar8 == '\0') {
                  *(undefined8 *)(puVar20 + -8) = 0x10051b;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar20 + 0x20) = 0;
                  *(undefined8 *)(puVar20 + -8) = 0x100541;
                  (*_DAT_)(1,0x187cc7c,0x199cd68,0x81d);
                }
              }
            }
            uVar14 = *(undefined8 *)((longlong)&puStackX_18 + lVar12);
            *(undefined8 *)(puVar20 + -8) = 0x10054f;
            func_0x(uVar14,4);
            puVar22 = *(uint **)((longlong)&puStackX_18 + lVar12);
            uVar16 = *(uint *)((longlong)&sStackX_10 + lVar12 + 4);
          }
          uVar17 = (ulonglong)uVar16;
          uVar16 = *(uint *)(&stack0x00000028 + lVar12);
          puVar6 = puVar27;
          if (*(short *)(&stack0x0000002c + lVar12) != 0) {
            do {
              uVar18 = puVar6[1] & 0x7fff;
              if ((uVar18 < uVar16) || ((uint)uVar17 < uVar18)) {
                *(undefined8 *)(puVar20 + -8) = 0x100592;
                cVar8 = func_0x(0x1f8d270);
                if (cVar8 != '\0') {
                  *(undefined8 *)(puVar20 + -8) = 0x10059b;
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar20 + -8) = 0x1005b5;
                    cVar8 = func_0x(0x1f8d270);
                    if (cVar8 == '\0') {
                      *(undefined8 *)(puVar20 + -8) = 0x1005d1;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar20 + 0x20) = 0;
                      *(undefined8 *)(puVar20 + -8) = 0x1005f7;
                      (*_DAT_)(1,0x187cc7c,0x199cd68,0x82a);
                    }
                  }
                }
                uVar14 = *(undefined8 *)((longlong)&puStackX_18 + lVar12);
                *(undefined8 *)(puVar20 + -8) = 0x100605;
                func_0x(uVar14,4);
                puVar22 = *(uint **)((longlong)&puStackX_18 + lVar12);
                uVar17 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar12 + 4);
              }
              iVar10 = iVar10 + 1;
              uVar16 = uVar18;
              puVar6 = puVar6 + 1;
            } while (iVar10 < (int)(uint)*(ushort *)(&stack0x0000002c + lVar12));
            puVar25 = *(uint **)(&stack0x00000058 + lVar12);
          }
          while( true ) {
            uVar9 = *(ushort *)(&stack0x0000002c + lVar12);
            if (-1 < (short)puVar27[(ulonglong)(uVar9 - 1) + 1]) break;
            uVar16 = *(uint *)((longlong)&uStackX_20 + lVar12 + 4);
            if (uVar9 == 1) {
              uVar18 = *(uint *)(&stack0x00000028 + lVar12);
            }
            else {
              uVar18 = *(ushort *)
                        ((longlong)puVar22 + (ulonglong)uVar9 * 2 + ((ulonglong)uVar16 - 2)) &
                       0x7fff;
            }
            uVar16 = *(ushort *)((longlong)puVar22 + (ulonglong)uVar9 * 2 + (ulonglong)uVar16) &
                     0x7fff;
            if (((uVar18 < *(uint *)(&stack0x00000028 + lVar12)) || (uVar16 < uVar18)) ||
               ((uint)uVar17 < uVar16)) {
              *(undefined8 *)(puVar20 + -8) = 0x100684;
              func_0x(puVar22,7);
              puVar22 = *(uint **)((longlong)&puStackX_18 + lVar12);
              uVar17 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar12 + 4);
            }
            if ((uVar18 < *(uint *)(&stack0x00000028 + lVar12)) || ((uint)uVar17 < uVar18))
            goto LAB_;
            uVar9 = *(ushort *)((ulonglong)uVar18 + (longlong)puVar22);
            if (uVar9 == 5) {
              puVar27 = (ushort *)((longlong)&sStackX_10 + lVar12 + 2);
              *puVar27 = *puVar27 | 2;
              *(short *)(&stack0x0000002c + lVar12) = *(short *)(&stack0x0000002c + lVar12) + -1;
              uVar26 = (ulonglong)uVar18 & 0xffff;
              *(short *)(&stack0x0000003a + lVar12) = (short)uVar18;
              pbVar2 = (byte *)(uVar26 + (longlong)puVar22);
              uVar9 = *(ushort *)(&stack0x0000003c + lVar12);
              if ((*(ushort *)(pbVar2 + 2) & 0x4000) == 0) {
                uVar9 = uVar9 & 0xc7ff;
              }
              else {
                uVar9 = uVar9 ^ (*(ushort *)(pbVar2 + 2) ^ uVar9) & 0x3800;
              }
              *(ushort *)(&stack0x0000003c + lVar12) = uVar9;
              uVar24 = (uVar9 ^ *(ushort *)(pbVar2 + 2)) & 0x7ff ^ uVar9;
              *(ushort *)(&stack0x0000003c + lVar12) = uVar24;
              pbVar28 = (byte *)((longlong)puVar22 +
                                uVar26 + ((ulonglong)uVar24 & 0x7ff) * 2 +
                                         (ulonglong)((uVar9 >> 0xb & 7) * 2) + 4);
              if (pbVar28 < pbVar2) {
                *(undefined8 *)(puVar20 + -8) = 0x100760;
                func_0x(pbVar2,0x19);
                uVar24 = *(ushort *)(&stack0x0000003c + lVar12);
                uVar26 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar12);
                puVar22 = *(uint **)((longlong)&puStackX_18 + lVar12);
                uVar17 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar12 + 4);
              }
              if (uVar16 - uVar18 <
                  (((*(uint *)(&stack0x0000003c + lVar12) & 0x7ff) * 2 - (int)uVar26) -
                  *(int *)((longlong)&puStackX_18 + lVar12)) + (int)pbVar28) {
                *(undefined8 *)(puVar20 + -8) = 0x10079c;
                func_0x((byte *)(uVar26 + (longlong)puVar22),0x19);
                uVar24 = *(ushort *)(&stack0x0000003c + lVar12);
                uVar26 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar12);
                puVar22 = *(uint **)((longlong)&puStackX_18 + lVar12);
                uVar17 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar12 + 4);
              }
              if ((uVar24 & 0x3800) != 0) {
                puVar27 = (ushort *)((longlong)puVar22 + uVar26 + 4);
                iVar10 = 0;
                if ((uVar24 & 0x3800) != 0) goto LAB_;
              }
              break;
            }
            if (uVar9 < 0x400) break;
            puVar6 = (ushort *)((longlong)&sStackX_10 + lVar12 + 2);
            *puVar6 = *puVar6 | 1;
            psVar1 = (short *)(&stack0x0000002c + lVar12);
            *psVar1 = *psVar1 + -1;
            if (*psVar1 == 0) break;
          }
          uVar26 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar12);
        }
        goto LAB_;
      }
      goto LAB_;
    }
    uVar24 = *(ushort *)((longlong)puVar25 + 6);
    if ((uVar24 & 8) != 0) {
      bVar4 = *(byte *)((longlong)(int)uVar18 + (longlong)puVar22);
      *puVar3 = 1;
      if ((bVar4 & (byte)(1 << ((byte)uVar24 & 7))) == 0) {
        puVar19 = (uint *)0x1601911;
      }
      puVar22 = *(uint **)(&stack0x00000080 + lVar12);
      goto LAB_;
    }
    if ((uVar24 & 0x10) == 0) {
LAB_:
      *puVar3 = uVar16;
      puVar19 = (uint *)((longlong)(int)*puVar25 + (longlong)puVar22);
      puVar22 = *(uint **)(&stack0x00000080 + lVar12);
      goto LAB_;
    }
    if ((*(byte *)puVar22 & 0x10) == 0) {
      if ((1 << (*(byte *)puVar22 & 0xe) & 0x1105U) == 0) goto LAB_;
    }
    else if (((int)uVar18 < (int)uVar21) && (uVar9 <= *(ushort *)(uVar26 + (longlong)puVar22)))
    goto LAB_;
    puVar19 = *(uint **)(puVar25 + 2) + 1;
    uVar18 = **(uint **)(puVar25 + 2);
    if ((uVar16 != 0) && (uVar18 != uVar16)) {
      *(undefined8 *)(puVar20 + 0x20) = 0;
      *(undefined8 *)(puVar20 + -8) = 0x100307;
      (*_DAT_)(1,0x1a2b0c0,0x1a29a28,0x381);
      *puVar3 = uVar18;
      puVar22 = *(uint **)(&stack0x00000080 + lVar12);
      goto LAB_;
    }
    goto LAB_;
  }
  *(undefined4 *)(&stack0x00000054 + lVar12) = 0;
  *(undefined **)(puVar20 + 0x20) = &stack0x00000054 + lVar12;
  *(undefined8 *)(puVar20 + -8) = 0x100b0b;
  puVar19 = (uint *)func_0x((longlong)&sStackX_10 + lVar12 + 2,puVar25);
  if ((((*(short *)((longlong)&sStackX_10 + lVar12) != 0) &&
       (plVar5 = *(longlong **)((longlong)&uStackX_20 + lVar12), plVar5 != (longlong *)0x0)) &&
      (*plVar5 != 0)) &&
     (((*(byte *)((longlong)puVar25 + 6) & 8) == 0 &&
      ((*(uint *)(&stack0x00000054 + lVar12) & 1) == 0)))) {
    if ((puVar19 == (uint *)0x0) || (puVar19 == (uint *)0x1601910)) {
      *puVar3 = 0;
      puVar19 = (uint *)0x0;
    }
    else {
      *(uint *)(puVar20 + 0x38) = *(uint *)(&stack0x00000054 + lVar12);
      *(uint **)(puVar20 + 0x30) = puVar3;
      *(int *)(puVar20 + 0x28) = (int)uVar26;
      *(undefined8 *)(puVar20 + 0x20) = *(undefined8 *)(&stack0x00000068 + lVar12);
      uVar16 = *puVar3;
      *(undefined8 *)(puVar20 + -8) = 0x100b6c;
      puVar19 = (uint *)func_0x(plVar5,puVar25,puVar19,uVar16);
    }
  }
  goto LAB_;
LAB_:
  do {
    if ((uVar24 & 0x7ff) < (*puVar27 & 0x7ff)) {
      *(undefined8 *)(puVar20 + -8) = 0x100812;
      func_0x((byte *)(uVar26 + (longlong)puVar22),0x1a);
      uVar24 = *(ushort *)(&stack0x0000003c + lVar12);
      uVar26 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar12);
      puVar22 = *(uint **)((longlong)&puStackX_18 + lVar12);
    }
    iVar10 = iVar10 + 1;
    puVar27 = puVar27 + 1;
  } while (iVar10 < (int)(*(uint *)(&stack0x0000003c + lVar12) >> 0xb & 7));
  uVar26 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar12);
  uVar17 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar12 + 4);
LAB_:
  if ((*(byte *)puVar22 & 0x40) == 0) {
    *(undefined4 *)(&stack0x00000036 + lVar12) = 0;
  }
  else {
    *(int *)(&stack0x00000036 + lVar12) = (int)uVar17;
    *(int *)((longlong)&sStackX_10 + lVar12 + 4) = (int)uVar17 + 0xe;
    *(undefined8 *)(puVar20 + -8) = 0x10086d;
    uVar14 = func_0x((longlong)&sStackX_10 + lVar12 + 2);
    *(undefined8 *)(puVar20 + -8) = 0x100879;
    func_0x(uVar14,&stack0x00000078 + lVar12);
    *(undefined8 *)(puVar20 + -8) = 0x100882;
    iVar10 = func_0x(&stack0x00000078 + lVar12);
    uVar16 = *(int *)((longlong)&sStackX_10 + lVar12 + 4) + iVar10;
    uVar17 = (ulonglong)uVar16;
    *(uint *)((longlong)&sStackX_10 + lVar12 + 4) = uVar16;
    uVar26 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar12);
    puVar22 = *(uint **)((longlong)&puStackX_18 + lVar12);
  }
  if ((*(byte **)(&stack0x0000002e + lVar12) != (byte *)0x0) &&
     (*(byte **)(&stack0x0000002e + lVar12) < (byte *)(uVar17 + (longlong)puVar22))) {
    *(undefined8 *)(puVar20 + -8) = 0x1008c1;
    cVar8 = func_0x(0x1f8d270);
    if (cVar8 != '\0') {
      *(undefined8 *)(puVar20 + -8) = 0x1008ca;
      lVar13 = func_0x();
      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
        *(undefined8 *)(puVar20 + -8) = 0x1008e4;
        cVar8 = func_0x(0x1f8d270);
        if (cVar8 == '\0') {
          *(undefined8 *)(puVar20 + -8) = 0x100900;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(puVar20 + 0x20) = 0;
          *(undefined8 *)(puVar20 + -8) = 0x100926;
          (*_DAT_)(1,0x187cc7c,0x199cd68,0x886);
        }
      }
    }
    uVar14 = *(undefined8 *)((longlong)&puStackX_18 + lVar12);
    *(undefined8 *)(puVar20 + -8) = 0x100934;
    func_0x(uVar14,0x12);
    uVar26 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar12);
    puVar22 = *(uint **)((longlong)&puStackX_18 + lVar12);
    uVar17 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar12 + 4);
  }
  uVar16 = (uint)uVar17;
  puVar19 = puVar22;
  if (0x3f3b < uVar16 - 1) {
    *(undefined8 *)(puVar20 + -8) = 0x10095a;
    cVar8 = func_0x(0x1f8d270);
    if (cVar8 != '\0') {
      *(undefined8 *)(puVar20 + -8) = 0x100963;
      lVar13 = func_0x();
      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
        *(undefined8 *)(puVar20 + -8) = 0x10097d;
        cVar8 = func_0x(0x1f8d270);
        if (cVar8 == '\0') {
          *(undefined8 *)(puVar20 + -8) = 0x100999;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)(puVar20 + 0x20) = 0;
          *(undefined8 *)(puVar20 + -8) = 0x1009bf;
          (*_DAT_)(1,0x187cc7c,0x199cd68,0x88b);
        }
      }
    }
    uVar14 = *(undefined8 *)((longlong)&puStackX_18 + lVar12);
    *(undefined8 *)(puVar20 + -8) = 0x1009cd;
    func_0x(uVar14,5);
    puVar22 = *(uint **)((longlong)&puStackX_18 + lVar12);
    uVar17 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar12 + 4);
LAB_:
    uVar16 = (uint)uVar17;
    uVar26 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar12);
    puVar19 = puVar22;
  }
LAB_:
  sVar23 = -*(short *)puVar25;
  if ((*(byte *)((longlong)puVar25 + 6) & 0x10) != 0) {
    if ((*(byte *)puVar19 & 0x10) == 0) {
      if ((1 << (*(byte *)puVar19 & 0xe) & 0x1105U) != 0) {
LAB_:
        puVar19 = *(uint **)(puVar25 + 2) + 1;
        *puVar3 = **(uint **)(puVar25 + 2);
        puVar22 = *(uint **)(&stack0x00000080 + lVar12);
        goto LAB_;
      }
    }
    else if (((int)uVar26 <= (int)*puVar25) ||
            (*(ushort *)(uVar26 + (longlong)puVar19) < *(ushort *)(puVar25 + 1))) goto LAB_;
  }
  if ((uint)*(ushort *)(&stack0x0000002c + lVar12) < (uint)(int)sVar23) {
    uVar18 = 0;
LAB_:
    *puVar3 = uVar18;
    puVar22 = *(uint **)(&stack0x00000080 + lVar12);
  }
  else {
    uVar18 = *(uint *)((longlong)&uStackX_20 + lVar12 + 4);
    if (sVar23 == 1) {
      uVar21 = *(uint *)(&stack0x00000028 + lVar12);
      puVar22 = puVar19;
    }
    else {
      uVar21 = *(ushort *)((longlong)puVar19 + (longlong)sVar23 * 2 + ((ulonglong)uVar18 - 2)) &
               0x7fff;
      puVar22 = *(uint **)((longlong)&puStackX_18 + lVar12);
      uVar16 = *(uint *)((longlong)&sStackX_10 + lVar12 + 4);
      puVar25 = *(uint **)(&stack0x00000058 + lVar12);
    }
    uVar18 = *(ushort *)((longlong)puVar19 + (longlong)sVar23 * 2 + (ulonglong)uVar18) & 0x7fff;
    if (((uVar21 < *(uint *)(&stack0x00000028 + lVar12)) || (uVar18 < uVar21)) || (uVar16 < uVar18))
    {
      *(undefined8 *)(puVar20 + -8) = 0x100a8e;
      func_0x(puVar22,7);
      puVar22 = *(uint **)((longlong)&puStackX_18 + lVar12);
    }
    puVar19 = (uint *)((ulonglong)uVar21 + (longlong)puVar22);
    *puVar3 = uVar18 - uVar21;
    puVar22 = *(uint **)(&stack0x00000080 + lVar12);
  }
LAB_:
  if ((puVar19 != (uint *)0x0) &&
     ((iVar10 = *(int *)(&stack0x00000060 + lVar12), iVar10 != 2 ||
      ((*(ushort *)puVar22 != 0xffff &&
       (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(puVar25 + 0xd) + 0x1601f30) + 0x1fb8fc8)
        == '\0')))))) {
    *(undefined8 *)(puVar20 + -8) = 0x100c04;
    iVar11 = func_0x((longlong)&sStackX_10 + lVar12,puVar25);
    if (iVar11 == 0) {
      for (uVar16 = *puVar3; uVar16 != 0; uVar16 = uVar16 - 1) {
      }
    }
    else if ((iVar10 == 1) ||
            ((*(ushort *)puVar22 != 0xffff &&
             (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(puVar25 + 0xd) + 0x1601f30) +
                       0x1fb8fc8) == '\0')))) {
      if ((*puVar3 < 0x30) || (*(short *)puVar19 != 3)) {
        bVar7 = false;
      }
      else {
        bVar7 = true;
      }
      if (bVar7) {
        *(undefined8 *)(&stack0x000000f0 + lVar12) = 0;
        *(undefined8 *)(&stack0x000000c8 + lVar12) = 3;
        *(undefined4 *)(&stack0x000000d0 + lVar12) = _DAT_;
        *(undefined4 *)(&stack0x000000d4 + lVar12) = uRam0000000001601d54;
        *(undefined4 *)(&stack0x000000d8 + lVar12) = uRam0000000001601d58;
        *(undefined4 *)(&stack0x000000dc + lVar12) = uRam0000000001601d5c;
        *(undefined2 *)(&stack0x000000ea + lVar12) = 0x100;
        *(undefined4 *)(&stack0x000000e4 + lVar12) = _DAT_;
        *(undefined2 *)(&stack0x000000e8 + lVar12) = _DAT_;
        *(undefined4 *)(&stack0x000000e0 + lVar12) = 0;
        *(undefined4 *)(&stack0x000000ec + lVar12) = 0;
        *(undefined8 *)(puVar20 + -8) = 0x100cfb;
        func_0x(&stack0x000000c8 + lVar12,0x30,puVar19);
        *(undefined4 *)(&stack0x00000048 + lVar12) = *(undefined4 *)(&stack0x000000e0 + lVar12);
      }
      else {
        *(undefined8 *)(puVar20 + -8) = 0x100d19;
        func_0x(&stack0x000000f8 + lVar12,&stack0x00000200 + lVar12);
        *(undefined8 *)(&stack0x000000f8 + lVar12) = 0x16178a8;
        *(undefined4 *)(puVar20 + 0x28) = 0x10000;
        *(uint *)(puVar20 + 0x20) = *puVar25;
        uVar16 = *puVar3;
        uVar14 = *(undefined8 *)(&stack0x00000088 + lVar12);
        *(undefined8 *)(puVar20 + -8) = 0x100d52;
        func_0x(&stack0x000000f8 + lVar12,uVar14,puVar19,uVar16);
        *(undefined4 *)(&stack0x00000048 + lVar12) = *(undefined4 *)(&stack0x0000012c + lVar12);
        *(undefined8 *)(puVar20 + -8) = 0x100d67;
        func_0x(&stack0x000000f8 + lVar12);
        *(undefined8 *)(puVar20 + -8) = 0x100d74;
        func_0x(&stack0x000000f8 + lVar12);
      }
    }
  }
  *(undefined8 *)(puVar20 + -8) = 0x100df3;
  iVar10 = func_0x(&stack0x00000090 + lVar12,&stack0x00000058 + lVar12);
  uVar26 = (ulonglong)*(uint *)(&stack0x00000050 + lVar12);
  goto joined_r0x00100159;
}

