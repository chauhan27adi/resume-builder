
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1,undefined4 param_2,int param_3,undefined2 *param_4,
                 undefined8 param_5)

{
  char cVar1;
  ushort uVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  byte bVar7;
  byte bVar8;
  byte bVar9;
  
  *(undefined4 *)(param_1 + 0x24) = param_2;
  *(undefined2 *)(param_1 + 0x38) = *param_4;
  *(undefined *)(param_1 + 0x35) = *(undefined *)(param_4 + 1);
  *(undefined *)(param_1 + 0x36) = *(undefined *)((longlong)param_4 + 3);
  *(undefined4 *)(param_1 + 0x54) = *(undefined4 *)(param_4 + 2);
  *(undefined *)(param_1 + 0x34) = *(undefined *)(param_4 + 5);
  uVar2 = param_4[4];
  *(ushort *)(param_1 + 0x28) = uVar2;
  uVar3 = *(uint *)(param_4 + 0xc);
  *(uint *)(param_1 + 0x2c) = uVar3;
  *(undefined4 *)(param_1 + 0x30) = *(undefined4 *)(param_4 + 0xe);
  if (0x41 < uVar2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (0x41 < uVar3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (0x41 < *(uint *)(param_1 + 0x30)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(byte *)(param_1 + 0x20) =
       (*(char *)((longlong)param_4 + 0xb) << 6 ^ *(byte *)(param_1 + 0x20)) & 0x7f ^
       *(char *)((longlong)param_4 + 0xb) << 6;
  *(byte *)(param_1 + 0x21) =
       *(byte *)(param_1 + 0x21) ^
       (*(byte *)((longlong)param_4 + 0xb) >> 2 ^ *(byte *)(param_1 + 0x21)) & 1;
  bVar7 = *(byte *)(param_1 + 0x22);
  bVar8 = (*(byte *)((longlong)param_4 + 0xb) >> 2 ^ *(byte *)(param_1 + 0x21)) & 2 ^
          *(byte *)(param_1 + 0x21);
  *(byte *)(param_1 + 0x21) = bVar8;
  bVar9 = 0;
  if (param_3 == 0xfffc) {
    bVar9 = 0x80;
  }
  *(byte *)(param_1 + 0x22) = param_3 == 0xffff | bVar7 & 0x7e | bVar9;
  bVar9 = param_3 == 0xffff | bVar7 & 6 | bVar9;
  bVar8 = (*(byte *)((longlong)param_4 + 0xb) >> 2 ^ bVar8) & 4 ^ bVar8;
  *(byte *)(param_1 + 0x21) = bVar8;
  bVar8 = (*(byte *)((longlong)param_4 + 0xb) >> 2 ^ bVar8) & 8 ^ bVar8;
  *(byte *)(param_1 + 0x21) = bVar8;
  bVar8 = (*(char *)((longlong)param_4 + 0xb) * '\x02' ^ bVar8) & 0x7f ^
          *(char *)((longlong)param_4 + 0xb) * '\x02';
  *(byte *)(param_1 + 0x21) = bVar8;
  bVar8 = bVar8 & 0x8f;
  bVar7 = *(byte *)(param_4 + 0x1d);
  *(byte *)(param_1 + 0x22) = bVar9;
  *(byte *)(param_1 + 0x23) =
       *(byte *)(param_1 + 0x23) ^ (bVar7 >> 4 ^ *(byte *)(param_1 + 0x23)) & 1;
  *(byte *)(param_1 + 0x21) = bVar8;
  *(undefined2 *)(param_1 + 0x3a) = 0;
  bVar9 = (*(byte *)(param_4 + 0x1d) >> 2 ^ bVar9) & 2 ^ bVar9;
  *(byte *)(param_1 + 0x22) = bVar9;
  *(byte *)(param_1 + 0x22) = (*(byte *)(param_4 + 0x1d) >> 3 ^ bVar9) & 4 ^ bVar9;
  if (-1 < (char)bVar8) {
    func_0x
              (param_1,(int)(short)param_4[6],param_4[9],*(byte *)(param_4 + 10) & 7,
               *(char *)(param_4 + 5) == 'h');
    func_0x(param_1,*(byte *)((longlong)param_4 + 0xb) >> 7,param_5);
    func_0x
              (param_1 + 0x10,(int)(short)param_4[7],param_4[8],*(byte *)(param_4 + 10) >> 3 & 7,
               *(char *)(param_4 + 5) == 'h');
    cVar1 = *(char *)((longlong)param_4 + 0xb);
    *(undefined (*) [16])(param_1 + 0x160) = ZEXT816(0);
    *(byte *)(param_1 + 0x20) =
         *(short *)(param_1 + 0x14) != 0 |
         -(*(short *)(param_1 + 4) != 0) & 2U |
         ((cVar1 << 6 ^ *(byte *)(param_1 + 0x20)) & 0x40 ^ *(byte *)(param_1 + 0x20)) & 0xfc;
    *(undefined8 *)(param_1 + 0x100) = 0;
    *(undefined (*) [16])(param_1 + 0x170) = ZEXT816(0);
    if ((*(byte *)(param_1 + 0x21) & 8) == 0) {
      *(int *)(param_1 + 0x3c) = param_3;
      bVar9 = (*(char *)(param_4 + 0x1d) << 2 ^ *(byte *)(param_1 + 0x20)) & 4 ^
              *(byte *)(param_1 + 0x20);
      *(byte *)(param_1 + 0x20) = bVar9;
      bVar9 = bVar9 ^ (*(char *)(param_4 + 0x1d) << 2 ^ bVar9) & 8;
      *(byte *)(param_1 + 0x20) = bVar9;
      bVar7 = *(byte *)(param_4 + 0x1d) >> 2 & 1;
      *(byte *)(param_1 + 0x20) = bVar7 << 4 | bVar9 & 0xef;
      if (bVar7 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(undefined2 *)(param_1 + 0x50) = param_4[0x1c];
      uVar4 = *(undefined4 *)(param_4 + 0x16);
      uVar5 = *(undefined4 *)(param_4 + 0x18);
      uVar6 = *(undefined4 *)(param_4 + 0x1a);
      *(undefined4 *)(param_1 + 0x40) = *(undefined4 *)(param_4 + 0x14);
      *(undefined4 *)(param_1 + 0x44) = uVar4;
      *(undefined4 *)(param_1 + 0x48) = uVar5;
      *(undefined4 *)(param_1 + 0x4c) = uVar6;
      *(undefined8 *)(param_1 + 0x158) = *(undefined8 *)(param_4 + 0x10);
    }
    *(undefined4 *)(param_1 + 0x58) = *(undefined4 *)(param_4 + 0x1e);
    *(undefined4 *)(param_1 + 0x5c) = *(undefined4 *)(param_4 + 0x20);
    *(undefined4 *)(param_1 + 0x60) = *(undefined4 *)(param_4 + 0x22);
    *(undefined8 *)(param_1 + 0x68) = *(undefined8 *)(param_4 + 0x24);
    *(undefined *)(param_1 + 0x70) = *(undefined *)(param_4 + 0x28);
    *(undefined *)(param_1 + 0x71) = *(undefined *)((longlong)param_4 + 0x51);
    *(undefined *)(param_1 + 0x72) = *(undefined *)(param_4 + 0x29);
    *(undefined4 *)(param_1 + 0x74) = *(undefined4 *)(param_4 + 0x2a);
    *(undefined2 *)(param_1 + 0x78) = param_4[0x2c];
    *(undefined *)(param_1 + 0x7a) = *(undefined *)(param_4 + 0x2d);
    *(undefined *)(param_1 + 0x7b) = *(undefined *)((longlong)param_4 + 0x5b);
    *(undefined4 *)(param_1 + 0x7c) = *(undefined4 *)(param_4 + 0x2e);
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

