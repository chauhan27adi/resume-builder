
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,longlong param_2,undefined4 param_3,undefined8 *param_4,
                 longlong *param_5,undefined8 *param_6,int *param_7,undefined param_8,
                 undefined8 param_9,longlong param_10,undefined8 param_11,undefined8 param_12)

{
  byte *pbVar1;
  ushort *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int *piVar10;
  char cVar11;
  short sVar12;
  int iVar13;
  undefined8 uVar14;
  longlong *plVar15;
  longlong lVar16;
  longlong lVar17;
  ulonglong *puVar18;
  ushort uVar19;
  short *psVar20;
  undefined *puVar21;
  byte *pbVar22;
  uint uVar23;
  longlong *plVar24;
  ulonglong uVar25;
  byte *pbVar26;
  ulonglong uVar27;
  ushort uVar28;
  uint uVar29;
  longlong *plVar30;
  ulonglong uVar31;
  uint uVar32;
  ushort *puVar33;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_280;
  undefined auStack_278 [32];
  undefined8 uStack_258;
  undefined *puStack_250;
  undefined8 uStack_248;
  undefined8 *puStack_240;
  uint uStack_238;
  longlong lStack_230;
  undefined8 uStack_228;
  undefined8 uStack_220;
  undefined8 uStack_218;
  longlong *plStack_210;
  undefined8 uStack_208;
  undefined uStack_200;
  undefined auStack_1ff [7];
  short *psStack_1f8;
  longlong lStack_1f0;
  undefined4 uStack_1e8;
  undefined8 uStack_1e0;
  undefined8 uStack_1d8;
  int *piStack_1d0;
  longlong lStack_1c8;
  undefined8 uStack_1c0;
  undefined8 uStack_1b8;
  undefined auStack_1a8 [96];
  short sStack_148;
  ushort uStack_146;
  uint uStack_144;
  byte *pbStack_140;
  undefined8 uStack_138;
  uint uStack_130;
  ushort uStack_12c;
  byte *pbStack_12a;
  undefined2 uStack_122;
  undefined2 uStack_120;
  ushort uStack_11e;
  ushort uStack_11c;
  undefined2 uStack_11a;
  undefined4 uStack_114;
  short sStack_98;
  ushort uStack_96;
  uint uStack_94;
  longlong *plStack_90;
  longlong *plStack_88;
  uint uStack_80;
  ushort uStack_7c;
  undefined8 uStack_7a;
  undefined2 uStack_72;
  undefined2 uStack_70;
  ushort uStack_6e;
  ushort uStack_6c;
  undefined2 uStack_6a;
  longlong *plStack_60;
  undefined4 uStack_58;
  ulonglong uStack_50;
  
  uStack_1b8 = 0xfffffffffffffffe;
  uStack_50 = _DAT_ ^ (ulonglong)&uStack_218;
  plStack_210 = param_5;
  piStack_1d0 = param_7;
  uStack_1c0 = param_9;
  lStack_1f0 = param_10;
  uStack_1d8 = param_11;
  uStack_1e0 = param_12;
  sStack_148 = -1;
  plVar15 = (longlong *)0x0;
  pbStack_140 = (byte *)0x0;
  uVar29 = 0;
  uStack_144 = 0;
  pbStack_12a = (byte *)0x0;
  uStack_120 = 0;
  uStack_11e = 0;
  uStack_11c = 0;
  uStack_11a = 0;
  uStack_138 = (longlong *)0x0;
  uStack_114 = 0xffffffff;
  sStack_98 = -1;
  plStack_90 = (longlong *)0x0;
  uStack_94 = 0;
  uStack_7a = 0;
  uStack_70 = 0;
  uStack_6e = 0;
  uStack_6c = 0;
  uStack_6a = 0;
  plStack_88 = (longlong *)0x0;
  plStack_60 = (longlong *)0x0;
  uStack_58 = 0;
  uStack_208 = param_4;
  psStack_1f8 = param_1;
  uStack_1e8 = param_3;
  lStack_1c8 = param_2;
  if (*param_1 == 0) {
    uStack_280 = 0x10010f;
    func_0x(param_1 + 1);
  }
  else {
    uStack_280 = 0x10011a;
    func_0x(param_1 + 1,&uStack_218);
  }
  uVar19 = uStack_218._6_2_;
  if ((((uint)(int)(short)uStack_218._6_2_ >> 1 ^ (int)(short)uStack_218._6_2_) & 0x2000) != 0) {
    uVar19 = uStack_218._6_2_ & 0xdfff;
    if ((uStack_218._6_2_ >> 0xe & 1) != 0) {
      uVar19 = uStack_218._6_2_ | 0x2000;
    }
  }
  if (uVar19 == 0xfffc) {
    if (*param_1 == 0) {
      uStack_280 = 0x10016e;
      func_0x();
    }
    else {
      uStack_280 = 0x100175;
      func_0x(param_1 + 1,&uStack_218);
    }
    uStack_280 = 0x10017e;
    sVar12 = func_0x(&uStack_218);
    if (sVar12 == 3) goto LAB_;
    lVar16 = param_4[0x1a];
    if (*(short *)param_6 == 0) {
      uStack_280 = 0x1001a6;
      func_0x();
    }
    else {
      uStack_280 = 0x1001ad;
      func_0x((longlong)param_6 + 2,&uStack_218);
    }
    *piStack_1d0 = 1;
    plVar24 = plVar15;
    if (param_10 == 0) {
      lVar17 = param_4[0x1a];
      uStack_280 = 0x1001d3;
      cVar11 = (**(code **)*param_4)(param_4);
      param_10 = lStack_1f0;
      if (cVar11 != '\0') goto LAB_;
      uVar23 = *(uint *)(plStack_210 + 2);
      if ((uVar23 & 8) == 0) {
        if (plStack_210[1] == 0) {
          if ((uVar23 & 0x10) == 0) {
            if (-1 < (char)uVar23) goto LAB_;
            goto LAB_;
          }
          plVar24 = *(longlong **)(*plStack_210 + 0x38);
        }
        else {
          plVar24 = *(longlong **)(plStack_210[1] + 0x38);
        }
      }
      else {
LAB_:
        plVar24 = (longlong *)(lVar17 + 0xa8);
      }
      if (plVar24 == (longlong *)0x0) goto LAB_;
    }
    else {
LAB_:
      if ((*(char *)(param_4[6] + 0x1cde) == '\0') && (puVar21 = auStack_278, param_10 == 0))
      goto LAB_;
    }
    uStack_220 = uStack_1e0;
    uStack_228 = uStack_1d8;
    lStack_230 = lStack_1f0;
    puStack_240 = param_6;
    uStack_248 = CONCAT71(uStack_248._1_7_,param_8);
    puStack_250 = &uStack_200;
    uStack_258 = auStack_1ff;
    uStack_280 = 0x100280;
    cVar11 = func_0x(param_4,plStack_210,plVar24,&uStack_218);
    if (cVar11 != '\0') {
      puVar21 = auStack_278;
      if (((lVar16 == 0) || (puVar21 = auStack_278, *(char *)(lVar16 + 0x34) == '\0')) ||
         (puVar21 = auStack_278, *(longlong *)(lVar16 + 0x40) == 0)) goto LAB_;
      if ((DAT_ & 8) == 0) {
        lVar17 = *(longlong *)
                  ((ulonglong)*_DAT_ +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
        puVar21 = auStack_278;
        if ((lVar17 == 0) ||
           (lVar17 = **(longlong **)(lVar17 + 0x38), puVar21 = auStack_278, lVar17 == 0))
        goto LAB_;
        uStack_280 = 0x1002f3;
        iVar13 = (*_DAT_)(lVar17,0xf73);
        puVar21 = auStack_278;
        if (iVar13 == 0) goto LAB_;
      }
      uVar23 = uVar29;
      if (plVar24 != (longlong *)0x0) {
        uVar23 = *(uint *)(plVar24 + 4);
      }
      uVar19 = *(ushort *)(param_4[6] + 0x6b8);
      uVar25 = (ulonglong)uStack_218 & 0xffffffffffff;
      if (*(short *)param_6 == 0) {
        uStack_280 = 0x100336;
        func_0x();
      }
      else {
        uStack_280 = 0x10033d;
        func_0x((longlong)param_6 + 2,&uStack_208);
      }
      uVar28 = uStack_208._6_2_;
      if ((((uint)(int)(short)uStack_208._6_2_ >> 1 ^ (int)(short)uStack_208._6_2_) & 0x2000) != 0)
      {
        uVar28 = uStack_208._6_2_ & 0xdfff;
        if ((uStack_208._6_2_ >> 0xe & 1) != 0) {
          uVar28 = uStack_208._6_2_ | 0x2000;
        }
      }
      if (uVar28 == 0xfffc) {
        uVar29 = (uint)(uStack_208._4_2_ >> 5);
      }
      puStack_240 = *(undefined8 **)(lVar16 + 0x40);
      uStack_248 = *(undefined8 *)(lVar16 + 0xf8);
      puStack_250 = (undefined *)plStack_210[5];
      uStack_258 = (undefined *)CONCAT44(uStack_258._4_4_,(uint)uVar19);
      uStack_280 = 0x1003cb;
      uStack_238 = uVar23;
      func_0x(0xf6f040,0xf6f510,uVar29 + 0xe,uVar25);
      uStack_280 = 0x1003d5;
      (*_DAT_)(auStack_1a8);
      uStack_280 = 0x1003dc;
      uVar14 = (*_DAT_)();
      uStack_280 = 0x1003ed;
      lStack_1c8 = (*_DAT_)(uVar14,0,0x6c0);
      if (lStack_1c8 != 0) {
        uStack_280 = 0x100400;
        plVar15 = (longlong *)func_0x(lStack_1c8,0);
      }
      if (plVar15 != (longlong *)0x0) {
        uStack_280 = 0x100415;
        iVar13 = (*_DAT_)(auStack_1a8,plVar15);
        if (iVar13 == 0) {
          uStack_280 = 0x100426;
          (**(code **)*plVar15)(plVar15,1);
        }
      }
      uStack_280 = 0x100432;
      func_0x(param_6,auStack_1a8);
      uStack_280 = 0x10043d;
      (*_DAT_)(auStack_1a8);
      puVar21 = auStack_278;
      goto LAB_;
    }
    uStack_280 = 0x100452;
    func_0x(&sStack_148,psStack_1f8);
    pbVar22 = pbStack_140;
    uVar25 = (ulonglong)pbStack_140 & 0xffffffffffffe000;
    param_5 = plStack_210;
    param_1 = psStack_1f8;
    if ((-1 < *(char *)(uVar25 + 2)) || (plStack_60 != (longlong *)0x0)) goto LAB_;
    uStack_280 = 0x100483;
    lVar16 = func_0x();
    lVar16 = -lVar16;
    puVar21 = auStack_278 + lVar16;
    plVar24 = (longlong *)((longlong)&uStack_218 + lVar16);
    uStack_218 = plVar24;
    plStack_60 = plVar24;
    uStack_58 = 0x1f9e;
    param_6[1] = 0;
    *param_6 = 0xffff;
    param_6[3] = 0;
    param_6[4] = 0;
    param_6[2] = 0;
    *(undefined4 *)(param_6 + 6) = 0;
    param_6[5] = 0;
    if (*(char *)(uVar25 + 2) < '\0') {
      sStack_98 = sStack_148;
      if (sStack_148 == 0) {
        uVar29 = uStack_144;
        if (uStack_144 == 0) {
          uStack_146 = 0;
          uVar25 = (ulonglong)uStack_138 & 0xffffffff;
          uVar29 = (uint)uStack_138;
          if ((*pbVar22 & 0x10) != 0) {
            uVar29 = (uint)uStack_138 + 2 + (*(ushort *)(pbVar22 + uVar25) + 7 >> 3);
            uVar25 = (ulonglong)uVar29;
          }
          uStack_138 = (longlong *)CONCAT44(uVar29,(uint)uStack_138);
          uStack_130 = (uint)uVar25;
          if ((*pbVar22 & 0x20) == 0) {
            uStack_12c = 0;
            uStack_144 = uStack_130;
          }
          else {
            puVar33 = (ushort *)(pbVar22 + uVar25);
            uStack_12c = *puVar33;
            if (uStack_12c == 0) {
              *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x10055d;
              cVar11 = func_0x(0x15dca40);
              if (cVar11 != '\0') {
                *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100566;
                lVar17 = func_0x();
                if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                  *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x10057f;
                  cVar11 = func_0x(0x15dca40);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x10059b;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_258 + lVar16) = 0;
                    *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1005c1;
                    (*_DAT_)(1,0xecc44c,0xfec538,0x80f);
                  }
                }
              }
              pbVar22 = pbStack_140;
              *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1005d2;
              func_0x(pbVar22,3);
              pbVar22 = pbStack_140;
            }
            uStack_130 = uStack_138._4_4_ + (uStack_12c + 1) * 2;
            if (0x1f9e < uStack_130) {
              *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100609;
              cVar11 = func_0x(0x15dca40);
              if (cVar11 != '\0') {
                *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100612;
                lVar17 = func_0x();
                if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                  *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x10062b;
                  cVar11 = func_0x(0x15dca40);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100647;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_258 + lVar16) = 0;
                    *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x10066d;
                    (*_DAT_)(1,0xecc44c,0xfec538,0x816);
                  }
                }
              }
              pbVar22 = pbStack_140;
              *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x10067e;
              func_0x(pbVar22,4);
              pbVar22 = pbStack_140;
            }
            uStack_144 = puVar33[uStack_12c] & 0x7fff;
            if (uStack_144 < uStack_130) {
              *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1006b9;
              cVar11 = func_0x(0x15dca40);
              if (cVar11 != '\0') {
                *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1006c2;
                lVar17 = func_0x();
                if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                  *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1006db;
                  cVar11 = func_0x(0x15dca40);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1006f7;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_258 + lVar16) = 0;
                    *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x10071d;
                    (*_DAT_)(1,0xecc44c,0xfec538,0x81d);
                  }
                }
              }
              pbVar22 = pbStack_140;
              *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x10072e;
              func_0x(pbVar22,4);
              pbVar22 = pbStack_140;
            }
            uVar25 = (ulonglong)uStack_144;
            plVar24 = plVar15;
            uVar29 = uStack_130;
            puVar2 = puVar33;
            if (uStack_12c != 0) {
              do {
                uVar23 = puVar2[1] & 0x7fff;
                if ((uVar23 < uVar29) || ((uint)uVar25 < uVar23)) {
                  *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100783;
                  cVar11 = func_0x(0x15dca40);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x10078c;
                    lVar17 = func_0x();
                    if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                      *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1007a5;
                      cVar11 = func_0x(0x15dca40);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1007c1;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_258 + lVar16) = 0;
                        *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1007e7;
                        (*_DAT_)(1,0xecc44c,0xfec538,0x82a);
                      }
                    }
                  }
                  pbVar22 = pbStack_140;
                  *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1007f8;
                  func_0x(pbVar22,4);
                  uVar25 = (ulonglong)uStack_144;
                  pbVar22 = pbStack_140;
                }
                uVar32 = (int)plVar24 + 1;
                plVar24 = (longlong *)(ulonglong)uVar32;
                uVar29 = uVar23;
                puVar2 = puVar2 + 1;
              } while ((int)uVar32 < (int)(uint)uStack_12c);
            }
            while ((short)puVar33[(ulonglong)(uStack_12c - 1) + 1] < 0) {
              uVar29 = uStack_130;
              if (uStack_12c != 1) {
                uVar29 = *(ushort *)
                          (pbVar22 +
                          (ulonglong)uStack_12c * 2 + (((ulonglong)uStack_138 >> 0x20) - 2)) &
                         0x7fff;
              }
              uVar23 = *(ushort *)
                        (pbVar22 + (ulonglong)uStack_12c * 2 + ((ulonglong)uStack_138 >> 0x20)) &
                       0x7fff;
              if (((uVar29 < uStack_130) || (uVar23 < uVar29)) || ((uint)uVar25 < uVar23)) {
                *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100892;
                func_0x(pbVar22,7);
                uVar25 = (ulonglong)uStack_144;
                pbVar22 = pbStack_140;
              }
              if ((uVar29 < uStack_130) || ((uint)uVar25 < uVar29)) goto LAB_;
              if (*(ushort *)(pbVar22 + uVar29) == 5) {
                uStack_146 = uStack_146 | 2;
                uStack_12c = uStack_12c - 1;
                uVar31 = (ulonglong)(uVar29 & 0xffff);
                uStack_11e = (ushort)uVar29;
                pbVar1 = pbVar22 + uVar31;
                if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
                  uVar19 = uStack_11c & 0xc7ff;
                }
                else {
                  uVar19 = uStack_11c ^ (*(ushort *)(pbVar1 + 2) ^ uStack_11c) & 0x3800;
                }
                uStack_11c = (uVar19 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar19;
                pbVar26 = pbVar22 + uVar31 + (ulonglong)((uStack_11c & 0x7ff) * 2) + 4 +
                                             (ulonglong)((uVar19 >> 0xb & 7) * 2);
                if (pbVar26 < pbVar1) {
                  *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100999;
                  func_0x(pbVar1,0x19);
                  uVar31 = (ulonglong)uStack_11e;
                  uVar25 = (ulonglong)uStack_144;
                  pbVar22 = pbStack_140;
                }
                if (uVar23 - uVar29 <
                    (((uStack_11c & 0x7ff) * 2 - (int)uVar31) - (int)pbStack_140) + (int)pbVar26) {
                  *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x1009e6;
                  func_0x(pbVar22 + uVar31,0x19);
                  uVar31 = (ulonglong)uStack_11e;
                  uVar25 = (ulonglong)uStack_144;
                  pbVar22 = pbStack_140;
                }
                if (((uStack_11c & 0x3800) != 0) &&
                   (puVar33 = (ushort *)(pbVar22 + uVar31 + 4), plVar24 = plVar15,
                   uVar19 = uStack_11c, (uStack_11c & 0x3800) != 0)) {
                  do {
                    if ((uVar19 & 0x7ff) < (*puVar33 & 0x7ff)) {
                      *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100a55;
                      func_0x(pbVar22 + uVar31,0x1a);
                      uVar31 = (ulonglong)uStack_11e;
                      pbVar22 = pbStack_140;
                      uVar19 = uStack_11c;
                    }
                    uVar29 = (int)plVar24 + 1;
                    plVar24 = (longlong *)(ulonglong)uVar29;
                    puVar33 = puVar33 + 1;
                  } while ((int)uVar29 < (int)((uStack_11c & 0x3800) >> 0xb));
                  uVar25 = (ulonglong)uStack_144;
                }
                break;
              }
              if (*(ushort *)(pbVar22 + uVar29) < 0x400) break;
              uStack_146 = uStack_146 | 1;
              uStack_12c = uStack_12c - 1;
              if (uStack_12c == 0) break;
            }
          }
          if ((*pbVar22 & 0x40) == 0) {
            uStack_122 = 0;
            uStack_120 = 0;
          }
          else {
            uStack_122 = (undefined2)uVar25;
            uStack_120 = (undefined2)(uVar25 >> 0x10);
            uStack_144 = (int)uVar25 + 0xe;
            *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100ac9;
            puVar18 = (ulonglong *)func_0x(&uStack_146);
            iVar13 = 0;
            uVar28 = (ushort)(*puVar18 >> 0x30);
            uVar19 = uVar28;
            if ((((uint)(int)(short)uVar28 >> 1 ^ (int)(short)uVar28) & 0x2000) != 0) {
              uVar19 = uVar28 & 0xdfff;
              if ((uVar28 >> 0xe & 1) != 0) {
                uVar19 = uVar28 | 0x2000;
              }
            }
            if (uVar19 == 0xfffc) {
              iVar13 = (int)((*puVar18 >> 0x20 & 0xffff) >> 5);
            }
            uStack_144 = uStack_144 + iVar13;
            uVar25 = (ulonglong)uStack_144;
            pbVar22 = pbStack_140;
          }
          if ((pbStack_12a != (byte *)0x0) && (pbStack_12a < pbVar22 + uVar25)) {
            *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100b6f;
            cVar11 = func_0x(0x15dca40);
            if (cVar11 != '\0') {
              *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100b78;
              lVar17 = func_0x();
              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100b91;
                cVar11 = func_0x(0x15dca40);
                if (cVar11 == '\0') {
                  *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100bad;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)((longlong)&uStack_258 + lVar16) = 0;
                  *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100bd3;
                  (*_DAT_)(1,0xecc44c,0xfec538,0x886);
                }
              }
            }
            pbVar22 = pbStack_140;
            *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100be4;
            func_0x(pbVar22,0x12);
            uVar25 = (ulonglong)uStack_144;
            pbVar22 = pbStack_140;
          }
          if (0x3f3b < (int)uVar25 - 1U) {
            *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100c0d;
            cVar11 = func_0x(0x15dca40);
            if (cVar11 != '\0') {
              *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100c16;
              lVar17 = func_0x();
              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100c2f;
                cVar11 = func_0x(0x15dca40);
                if (cVar11 == '\0') {
                  *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100c4b;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)((longlong)&uStack_258 + lVar16) = 0;
                  *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100c71;
                  (*_DAT_)(1,0xecc44c,0xfec538,0x88b);
                }
              }
            }
            pbVar22 = pbStack_140;
            *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100c82;
            func_0x(pbVar22,5);
            uVar25 = (ulonglong)uStack_144;
            pbVar22 = pbStack_140;
          }
LAB_:
          uVar29 = (uint)uVar25;
        }
        plVar24 = uStack_218;
        uVar23 = uVar29;
        if ((uVar29 < 9) && (((*pbVar22 & 0xe) == 0 || ((*pbVar22 & 0xe) == 0xc)))) {
          uVar23 = 9;
        }
        uStack_96 = uStack_146;
        uStack_7c = uStack_12c;
        plStack_88 = uStack_138;
        uStack_80 = uStack_130;
        uStack_72 = uStack_122;
        uStack_70 = uStack_120;
        uStack_94 = uVar29;
        *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100d15;
        func_0x(plVar24,0x1f9e,pbVar22,uVar23);
        plVar24 = uStack_218;
        plStack_90 = uStack_218;
        *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100d2c;
        iVar13 = func_0x(&uStack_96);
        plVar30 = plStack_90;
        param_4 = uStack_208;
        if (iVar13 != 0) {
          puVar33 = (ushort *)(((ulonglong)plStack_88 >> 0x20) + (longlong)plStack_90);
          uVar29 = *puVar33 - 1;
          if ((uStack_96 & 1) == 0) {
            uVar29 = (uint)*puVar33;
          }
          uVar23 = uStack_80;
          if (uVar29 != 1) {
            uVar23 = puVar33[(longlong)(int)uVar29 + -1] & 0x7fff;
          }
          uVar29 = puVar33[(int)uVar29] & 0x7fff;
          if (((uVar23 < uStack_80) || (uVar29 < uVar23)) || (uStack_94 < uVar29)) {
            *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100d9b;
            func_0x(plVar30,7);
          }
          uVar31 = (ulonglong)(uVar23 & 0xffff);
          uStack_6e = (ushort)uVar23;
          uVar25 = (longlong)plStack_90 + uVar31;
          if ((*(ushort *)(uVar25 + 2) >> 0xe & 1) == 0) {
            uVar19 = uStack_6c & 0xc7ff;
          }
          else {
            uVar19 = uStack_6c ^ (uStack_6c ^ *(ushort *)(uVar25 + 2)) & 0x3800;
          }
          uStack_6c = (uVar19 ^ *(ushort *)(uVar25 + 2)) & 0x7ff ^ uVar19;
          uVar27 = (longlong)plStack_90 +
                   uVar31 + (ulonglong)((uStack_6c & 0x7ff) * 2) + 4 +
                            (ulonglong)((uVar19 >> 0xb & 7) * 2);
          if (uVar27 < uVar25) {
            *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100e41;
            func_0x(uVar25,0x19);
            uVar31 = (ulonglong)uStack_6e;
          }
          if (uVar29 - uVar23 <
              (((uStack_6c & 0x7ff) * 2 - (int)uVar31) - (int)plStack_90) + (int)uVar27) {
            lVar17 = uVar31 + (longlong)plStack_90;
            *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100e86;
            func_0x(lVar17,0x19);
            uVar31 = (ulonglong)uStack_6e;
          }
          param_4 = uStack_208;
          if (((uStack_6c & 0x3800) != 0) &&
             (puVar33 = (ushort *)((longlong)plStack_90 + uVar31 + 4), plVar30 = plStack_90,
             uVar19 = uStack_6c, (uStack_6c & 0x3800) != 0)) {
            do {
              if ((uVar19 & 0x7ff) < (*puVar33 & 0x7ff)) {
                *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100ee5;
                func_0x(uVar31 + (longlong)plVar30,0x1a);
                uVar31 = (ulonglong)uStack_6e;
                plVar30 = plStack_90;
                uVar19 = uStack_6c;
              }
              uVar29 = (int)plVar15 + 1;
              plVar15 = (longlong *)(ulonglong)uVar29;
              puVar33 = puVar33 + 1;
              param_4 = uStack_208;
            } while ((int)uVar29 < (int)((uStack_6c & 0x3800) >> 0xb));
          }
        }
      }
      else if ((uStack_138 == (longlong *)0x0) || (*uStack_138 == 0)) {
        *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100fb1;
        func_0x(&uStack_96,plVar24,0x1f9e,&uStack_146);
        plStack_88 = uStack_138;
        if (sStack_148 == 0) {
          plStack_88 = plVar15;
        }
        plVar24 = uStack_218;
      }
      else {
        *(undefined8 *)(auStack_278 + lVar16 + -8) = 0x100f8f;
        func_0x(&sStack_98,plVar24,0x1f9e,&sStack_148);
        plVar24 = uStack_218;
      }
      psVar20 = &sStack_98;
    }
    else {
      psVar20 = &sStack_148;
    }
    sVar12 = *psVar20;
    *(short *)param_6 = sVar12;
    uVar3 = *(undefined4 *)(psVar20 + 3);
    uVar4 = *(undefined4 *)(psVar20 + 5);
    uVar5 = *(undefined4 *)(psVar20 + 7);
    uVar6 = *(undefined4 *)(psVar20 + 9);
    uVar7 = *(undefined4 *)(psVar20 + 0xb);
    uVar8 = *(undefined4 *)(psVar20 + 0xd);
    uVar9 = *(undefined4 *)(psVar20 + 0xf);
    param_5 = plStack_210;
    param_1 = psStack_1f8;
    plVar15 = plVar24;
    if (sVar12 == 0) {
      *(undefined4 *)((longlong)param_6 + 2) = *(undefined4 *)(psVar20 + 1);
      *(undefined4 *)((longlong)param_6 + 6) = uVar3;
      *(undefined4 *)((longlong)param_6 + 10) = uVar4;
      *(undefined4 *)((longlong)param_6 + 0xe) = uVar5;
      *(undefined4 *)((longlong)param_6 + 0x12) = uVar6;
      *(undefined4 *)((longlong)param_6 + 0x16) = uVar7;
      *(undefined4 *)((longlong)param_6 + 0x1a) = uVar8;
      *(undefined4 *)((longlong)param_6 + 0x1e) = uVar9;
      *(undefined8 *)((longlong)param_6 + 0x22) = *(undefined8 *)(psVar20 + 0x11);
      *(undefined4 *)((longlong)param_6 + 0x2a) = *(undefined4 *)(psVar20 + 0x15);
      puVar21 = auStack_278 + lVar16;
    }
    else {
      *(undefined4 *)((longlong)param_6 + 2) = *(undefined4 *)(psVar20 + 1);
      *(undefined4 *)((longlong)param_6 + 6) = uVar3;
      *(undefined4 *)((longlong)param_6 + 10) = uVar4;
      *(undefined4 *)((longlong)param_6 + 0xe) = uVar5;
      *(undefined4 *)((longlong)param_6 + 0x12) = uVar6;
      *(undefined4 *)((longlong)param_6 + 0x16) = uVar7;
      *(undefined4 *)((longlong)param_6 + 0x1a) = uVar8;
      *(undefined4 *)((longlong)param_6 + 0x1e) = uVar9;
      uVar3 = *(undefined4 *)(psVar20 + 0x13);
      uVar4 = *(undefined4 *)(psVar20 + 0x15);
      uVar5 = *(undefined4 *)(psVar20 + 0x17);
      *(undefined4 *)((longlong)param_6 + 0x22) = *(undefined4 *)(psVar20 + 0x11);
      *(undefined4 *)((longlong)param_6 + 0x26) = uVar3;
      *(undefined4 *)((longlong)param_6 + 0x2a) = uVar4;
      *(undefined4 *)((longlong)param_6 + 0x2e) = uVar5;
      *(short *)((longlong)param_6 + 0x32) = psVar20[0x19];
      param_6[2] = param_6[2];
    }
  }
  else {
LAB_:
    puVar21 = auStack_278;
  }
  *(undefined8 *)(puVar21 + 0x58) = uStack_1e0;
  puVar21[0x50] = 0;
  *(undefined8 *)(puVar21 + 0x48) = uStack_1d8;
  *(longlong *)(puVar21 + 0x40) = lStack_1f0;
  *(undefined8 *)(puVar21 + 0x38) = uStack_1c0;
  puVar21[0x30] = param_8;
  piVar10 = piStack_1d0;
  *(int **)(puVar21 + 0x28) = piStack_1d0;
  *(undefined8 **)(puVar21 + 0x20) = param_6;
  lVar16 = lStack_1c8;
  uVar3 = uStack_1e8;
  *(undefined8 *)(puVar21 + -8) = 0x10105b;
  func_0x(lVar16,uVar3,param_4,param_5);
  if ((plVar15 != (longlong *)0x0) && (2 < *piVar10 - 2U)) {
    param_6[1] = 0;
    *param_6 = 0xffff;
    param_6[3] = 0;
    param_6[4] = 0;
    param_6[2] = 0;
    *(undefined4 *)(param_6 + 6) = 0;
    param_6[5] = 0;
    *(undefined8 *)(puVar21 + -8) = 0x101094;
    func_0x(param_6,param_1);
  }
LAB_:
  uVar25 = uStack_50 ^ (ulonglong)&uStack_218;
  *(undefined8 *)(puVar21 + -8) = 0x1010a3;
  func_0x(uVar25);
  return;
}

