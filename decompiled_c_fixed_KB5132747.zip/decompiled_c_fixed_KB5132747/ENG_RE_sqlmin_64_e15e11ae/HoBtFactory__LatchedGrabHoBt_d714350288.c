
/* WARNING: Control flow encountered bad instruction data */

undefined8 FUN_(longlong param_1,undefined8 *param_2,longlong param_3)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong lStackX_8;
  int iStack_38;
  
  uVar1 = (ulonglong)*(ushort *)((longlong)param_2 + 4);
  if ((uVar1 != 0) && ((uVar1 & *(longlong *)(param_1 + 0x30) - 1U) == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar1 = *(longlong *)(param_1 + 0x30) - 1U &
          uVar1 * *(longlong *)(param_1 + 0x38) + (longlong)*(int *)param_2;
  plVar3 = (longlong *)(uVar1 * 0x10 + *(longlong *)(param_1 + 0x20));
  if (param_3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar2 = (uVar1 % *(ulonglong *)(param_1 + 0x10)) * 0x20 + *(longlong *)(param_1 + 8);
  iStack_38 = func_0x(lVar2,2,0xffffffff,0,0,0,0,0,0);
  if (*(char *)(param_1 + 0x28) == '\0') {
    for (lStackX_8 = *plVar3; lStackX_8 != 0; lStackX_8 = *(longlong *)(lStackX_8 + 0x98)) {
      if (*(int *)(lStackX_8 + 0x84) == (int)*param_2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    func_0x(lVar2,2);
    iStack_38 = 0;
    if (*(char *)(param_1 + 0x28) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  else if (plVar3[1] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iStack_38 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  return 0;
}

