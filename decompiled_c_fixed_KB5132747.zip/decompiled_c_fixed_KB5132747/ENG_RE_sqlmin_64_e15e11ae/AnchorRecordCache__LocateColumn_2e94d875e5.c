
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint * FUN_(longlong *param_1,uint *param_2,uint *param_3)

{
  ushort *puVar1;
  longlong lVar2;
  longlong *plVar3;
  bool bVar4;
  bool bVar5;
  byte bVar6;
  char cVar7;
  ushort uVar8;
  ushort uVar9;
  int iVar10;
  longlong lVar11;
  undefined8 uVar12;
  longlong lVar13;
  short sVar14;
  uint uVar15;
  ulonglong uVar16;
  uint uVar17;
  uint uVar18;
  ushort *puVar19;
  ushort *puVar20;
  ulonglong uVar21;
  uint *puVar22;
  longlong lVar23;
  byte *pbVar24;
  ulonglong uVar25;
  uint uVar26;
  uint *puVar27;
  ushort *puStackX_20;
  undefined auStack_48 [8];
  undefined auStack_40 [8];
  
  uVar8 = *(ushort *)(param_2 + 1);
  uVar17 = uVar8 - 1;
  puVar22 = param_3;
  if (((ushort)uVar17 < *(ushort *)(param_1 + 1)) &&
     (puVar22 = (uint *)(ulonglong)(uVar17 & 0xffff),
     (*(byte *)(param_1[3] + (ulonglong)((uVar17 & 0xffff) >> 3)) >> ((byte)uVar17 & 7) & 1) != 0))
  {
    *param_3 = (uint)*(ushort *)(param_1[2] + 8 + (longlong)puVar22 * 10);
    return *(uint **)((longlong)puVar22 * 10 + param_1[2]);
  }
  lVar2 = *param_1;
  puVar1 = (ushort *)(lVar2 + 0x12);
  if (*(short *)(lVar2 + 0x10) != 0) {
    puStackX_20 = (ushort *)((ulonglong)puStackX_20 & 0xffffffff00000000);
    puVar22 = (uint *)func_0x(puVar1,param_2,puVar22,param_3,&puStackX_20);
    if ((((*(short *)(lVar2 + 0x10) != 0) &&
         (plVar3 = *(longlong **)(lVar2 + 0x20), plVar3 != (longlong *)0x0)) && (*plVar3 != 0)) &&
       (((*(byte *)((longlong)param_2 + 6) & 8) == 0 && (((ulonglong)puStackX_20 & 1) == 0)))) {
      if ((puVar22 == (uint *)0x0) || (puVar22 == (uint *)0x16ede50)) {
        *param_3 = 0;
        puVar22 = (uint *)0x0;
      }
      else {
        puVar22 = (uint *)func_0x(plVar3,param_2,puVar22,*param_3,0,0,param_3,
                                          puStackX_20._0_4_);
      }
    }
    goto LAB_;
  }
  uVar15 = *param_2;
  if ((uVar15 & 0xc0000000) == 0x80000000) {
    iVar10 = func_0x(puVar1);
    if (iVar10 == 0) {
      *param_3 = 0;
      puVar22 = (uint *)0x0;
    }
    else {
      puVar22 = (uint *)func_0x(lVar2 + 0x3a,param_2,param_3,auStack_48);
    }
    goto LAB_;
  }
  pbVar24 = *(byte **)(lVar2 + 0x18);
  puVar22 = (uint *)0x0;
  bVar6 = *pbVar24;
  bVar4 = true;
  bVar5 = false;
  if ((bVar6 & 0x10) == 0) {
    if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
      uVar9 = ~(*(ushort *)((longlong)param_2 + 6) >> 4);
      bVar4 = bVar5;
      goto LAB_;
    }
  }
  else {
    uVar18 = *(uint *)(lVar2 + 0x20);
    if ((int)uVar15 < (int)uVar18) {
      if (*(ushort *)(pbVar24 + uVar18) < uVar8) {
        uVar9 = ~(*(ushort *)((longlong)param_2 + 6) >> 4);
        bVar4 = bVar5;
      }
      else {
        uVar9 = (ushort)(pbVar24[(ulonglong)(uVar8 - 1 >> 3) + (ulonglong)uVar18 + 2] >>
                        ((byte)(uVar8 - 1) & 7));
      }
    }
    else {
      uVar9 = ~(*(ushort *)((longlong)param_2 + 6) >> 4);
      bVar4 = bVar5;
    }
LAB_:
    if ((uVar9 & 1) != 0) {
      *param_3 = 0;
      goto LAB_;
    }
    if ((!bVar4) && ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0)) {
      puVar22 = *(uint **)(param_2 + 2);
      *param_3 = *puVar22;
      puVar22 = puVar22 + 1;
      goto LAB_;
    }
  }
  if (-1 < (int)uVar15) {
    uVar9 = *(ushort *)((longlong)param_2 + 6);
    if ((uVar9 & 8) != 0) {
      bVar6 = pbVar24[(int)uVar15];
      *param_3 = 1;
      puVar22 = (uint *)0x16ede50;
      if ((bVar6 & (byte)(1 << ((byte)uVar9 & 7))) == 0) {
        puVar22 = (uint *)0x16ede51;
      }
      goto LAB_;
    }
    if ((uVar9 & 0x10) != 0) {
      if ((bVar6 & 0x10) == 0) {
        if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
          puVar22 = *(uint **)(param_2 + 2);
          *param_3 = *puVar22;
          puVar22 = puVar22 + 1;
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(lVar2 + 0x20) <= (int)uVar15) ||
              (*(ushort *)(pbVar24 + *(uint *)(lVar2 + 0x20)) < uVar8)) goto LAB_;
    }
    *param_3 = 0;
    puVar22 = (uint *)((longlong)(int)*param_2 + *(longlong *)(lVar2 + 0x18));
    goto LAB_;
  }
  if (*(int *)(lVar2 + 0x14) == 0) {
    uVar15 = *(uint *)(lVar2 + 0x20);
    uVar16 = (ulonglong)uVar15;
    *(uint *)(lVar2 + 0x24) = uVar15;
    *puVar1 = 0;
    bVar6 = *pbVar24;
    if ((bVar6 & 0x10) != 0) {
      uVar15 = uVar15 + 2 + (*(ushort *)(pbVar24 + uVar16) + 7 >> 3);
      uVar16 = (ulonglong)uVar15;
      *(uint *)(lVar2 + 0x24) = uVar15;
      bVar6 = *pbVar24;
    }
    if ((bVar6 & 0x20) == 0) {
      *(int *)(lVar2 + 0x14) = (int)uVar16;
      *(undefined2 *)(lVar2 + 0x2c) = 0;
      *(int *)(lVar2 + 0x28) = (int)uVar16;
    }
    else {
      puVar19 = (ushort *)(pbVar24 + uVar16);
      uVar8 = *puVar19;
      *(ushort *)(lVar2 + 0x2c) = uVar8;
      puStackX_20 = puVar19;
      if (uVar8 == 0) {
        cVar7 = func_0x(0x20797b0);
        if (((cVar7 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
           (*(char *)(lVar11 + 0x499) != '\0')) {
          cVar7 = func_0x(0x20797b0);
          if (cVar7 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x19691bc,0x1a892a8,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(lVar2 + 0x18),3);
        uVar16 = (ulonglong)*(uint *)(lVar2 + 0x24);
        uVar8 = *(ushort *)(lVar2 + 0x2c);
      }
      uVar15 = (int)uVar16 + (uVar8 + 1) * 2;
      *(uint *)(lVar2 + 0x28) = uVar15;
      if (0x1f9e < uVar15) {
        cVar7 = func_0x(0x20797b0);
        if (((cVar7 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
           (*(char *)(lVar11 + 0x499) != '\0')) {
          cVar7 = func_0x(0x20797b0);
          if (cVar7 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x19691bc,0x1a892a8,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(lVar2 + 0x18),4);
        uVar8 = *(ushort *)(lVar2 + 0x2c);
        uVar15 = *(uint *)(lVar2 + 0x28);
      }
      uVar16 = (ulonglong)uVar8;
      uVar8 = puVar19[uVar16];
      *(uint *)(lVar2 + 0x14) = uVar8 & 0x7fff;
      if ((uVar8 & 0x7fff) < uVar15) {
        cVar7 = func_0x(0x20797b0);
        if (((cVar7 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
           (*(char *)(lVar11 + 0x499) != '\0')) {
          cVar7 = func_0x(0x20797b0);
          if (cVar7 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x19691bc,0x1a892a8,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(lVar2 + 0x18),4);
        uVar15 = *(uint *)(lVar2 + 0x28);
        uVar16 = (ulonglong)*(ushort *)(lVar2 + 0x2c);
      }
      puVar20 = puVar19;
      puVar27 = puVar22;
      if ((short)uVar16 != 0) {
        do {
          puVar19 = puVar19 + 1;
          uVar18 = *puVar19 & 0x7fff;
          if ((uVar18 < uVar15) || (*(uint *)(lVar2 + 0x14) < uVar18)) {
            cVar7 = func_0x(0x20797b0);
            if ((cVar7 != '\0') &&
               ((lVar11 = func_0x(), lVar11 != 0 &&
                (*(char *)(lVar11 + 0x499) != '\0')))) {
              cVar7 = func_0x(0x20797b0);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x19691bc,0x1a892a8,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(lVar2 + 0x18),4);
          }
          uVar16 = (ulonglong)*(ushort *)(lVar2 + 0x2c);
          uVar26 = (int)puVar27 + 1;
          puVar20 = puStackX_20;
          puVar27 = (uint *)(ulonglong)uVar26;
          uVar15 = uVar18;
        } while ((int)uVar26 < (int)(uint)*(ushort *)(lVar2 + 0x2c));
      }
      puVar19 = puStackX_20;
      if ((short)puVar20[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
        pbVar24 = *(byte **)(lVar2 + 0x18);
        do {
          uVar15 = *(ushort *)(pbVar24 + uVar16 * 2 + (ulonglong)*(uint *)(lVar2 + 0x24)) & 0x7fff;
          if ((int)uVar16 == 1) {
            uVar18 = *(uint *)(lVar2 + 0x28);
            uVar26 = uVar18;
LAB_:
            if ((uVar15 < uVar18) || (*(uint *)(lVar2 + 0x14) < uVar15)) goto LAB_;
          }
          else {
            uVar26 = *(uint *)(lVar2 + 0x28);
            uVar18 = *(ushort *)(pbVar24 + uVar16 * 2 + ((ulonglong)*(uint *)(lVar2 + 0x24) - 2)) &
                     0x7fff;
            if (uVar26 <= uVar18) goto LAB_;
LAB_:
            func_0x(pbVar24,7);
            uVar26 = *(uint *)(lVar2 + 0x28);
          }
          if ((uVar18 < uVar26) || (*(uint *)(lVar2 + 0x14) < uVar18)) goto LAB_;
          pbVar24 = *(byte **)(lVar2 + 0x18);
          if (*(ushort *)(pbVar24 + uVar18) == 5) {
            *puVar1 = *puVar1 | 2;
            *(short *)(lVar2 + 0x2c) = *(short *)(lVar2 + 0x2c) + -1;
            uVar8 = *(ushort *)(lVar2 + 0x3c) & 0xc7ff;
            uVar25 = (ulonglong)(uVar18 & 0xffff);
            *(short *)(lVar2 + 0x3a) = (short)uVar18;
            uVar16 = *(ulonglong *)(lVar2 + 0x18);
            if ((*(ushort *)(uVar25 + 2 + uVar16) >> 0xe & 1) != 0) {
              uVar8 = *(ushort *)(uVar25 + 2 + uVar16) & 0x3800 | uVar8;
            }
            *(ushort *)(lVar2 + 0x3c) = uVar8;
            uVar9 = (uVar8 ^ *(ushort *)(uVar25 + 2 + uVar16)) & 0x7ff ^ uVar8;
            *(ushort *)(lVar2 + 0x3c) = uVar9;
            uVar21 = (ulonglong)((uVar9 & 0x7ff) * 2) + 4 + uVar16 + (uVar8 >> 0xb & 7) * 2 + uVar25
            ;
            if (uVar21 < uVar25 + uVar16) {
              func_0x(uVar25 + uVar16,0x19);
              uVar9 = *(ushort *)(lVar2 + 0x3c);
              uVar25 = (ulonglong)*(ushort *)(lVar2 + 0x3a);
              uVar16 = (ulonglong)*(uint *)(lVar2 + 0x18);
            }
            if (uVar15 - uVar18 < (((uVar9 & 0x7ff) * 2 - (int)uVar25) - (int)uVar16) + (int)uVar21)
            {
              func_0x(uVar25 + *(longlong *)(lVar2 + 0x18),0x19);
              uVar9 = *(ushort *)(lVar2 + 0x3c);
            }
            if (((uVar9 & 0x3800) != 0) &&
               (puVar19 = (ushort *)
                          (*(longlong *)(lVar2 + 0x18) + 4 + (ulonglong)*(ushort *)(lVar2 + 0x3a)),
               (uVar9 & 0x3800) != 0)) {
              do {
                if ((uVar9 & 0x7ff) < (*puVar19 & 0x7ff)) {
                  func_0x((ulonglong)*(ushort *)(lVar2 + 0x3a) + *(longlong *)(lVar2 + 0x18)
                                  ,0x1a);
                  uVar9 = *(ushort *)(lVar2 + 0x3c);
                }
                uVar15 = (int)puVar22 + 1;
                puVar22 = (uint *)(ulonglong)uVar15;
                puVar19 = puVar19 + 1;
              } while ((int)uVar15 < (int)(uVar9 >> 0xb & 7));
            }
            goto LAB_;
          }
          if (*(ushort *)(pbVar24 + uVar18) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar8 = *(short *)(lVar2 + 0x2c) - 1;
          *(ushort *)(lVar2 + 0x2c) = uVar8;
          if (uVar8 == 0) goto LAB_;
          uVar16 = (ulonglong)uVar8;
        } while ((short)puVar19[(ulonglong)(uVar8 - 1) + 1] < 0);
        uVar16 = (ulonglong)*(uint *)(lVar2 + 0x14);
      }
      else {
LAB_:
        pbVar24 = *(byte **)(lVar2 + 0x18);
        uVar16 = (ulonglong)*(uint *)(lVar2 + 0x14);
      }
    }
    if ((*pbVar24 & 0x40) == 0) {
      *(undefined4 *)(lVar2 + 0x36) = 0;
    }
    else {
      *(int *)(lVar2 + 0x36) = (int)uVar16;
      *(int *)(lVar2 + 0x14) = (int)uVar16 + 0xe;
      uVar12 = func_0x(puVar1);
      func_0x(uVar12,auStack_40);
      iVar10 = func_0x(auStack_40);
      *(int *)(lVar2 + 0x14) = *(int *)(lVar2 + 0x14) + iVar10;
      uVar16 = (ulonglong)*(uint *)(lVar2 + 0x14);
    }
    iVar10 = (int)uVar16;
    if ((*(ulonglong *)(lVar2 + 0x2e) != 0) &&
       (*(ulonglong *)(lVar2 + 0x2e) < uVar16 + *(longlong *)(lVar2 + 0x18))) {
      cVar7 = func_0x(0x20797b0);
      if ((cVar7 != '\0') &&
         ((lVar11 = func_0x(), lVar11 != 0 && (*(char *)(lVar11 + 0x499) != '\0'))))
      {
        cVar7 = func_0x(0x20797b0);
        if (cVar7 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x19691bc,0x1a892a8,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(lVar2 + 0x18),0x12);
      iVar10 = *(int *)(lVar2 + 0x14);
    }
    if (0x3f3b < iVar10 - 1U) {
      cVar7 = func_0x(0x20797b0);
      if (((cVar7 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
         (*(char *)(lVar11 + 0x499) != '\0')) {
        cVar7 = func_0x(0x20797b0);
        if (cVar7 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x19691bc,0x1a892a8,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(lVar2 + 0x18),5);
    }
  }
LAB_:
  sVar14 = -*(short *)param_2;
  if ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0) {
    bVar6 = **(byte **)(lVar2 + 0x18);
    if ((bVar6 & 0x10) == 0) {
      if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
        puVar22 = *(uint **)(param_2 + 2);
        uVar17 = uVar17 & 0xffff;
        *param_3 = *puVar22;
        puVar22 = puVar22 + 1;
        goto LAB_;
      }
    }
    else if (((int)*(uint *)(lVar2 + 0x20) <= (int)*param_2) ||
            (*(ushort *)(*(byte **)(lVar2 + 0x18) + *(uint *)(lVar2 + 0x20)) <
             *(ushort *)(param_2 + 1))) goto LAB_;
  }
  lVar11 = (longlong)sVar14;
  if ((uint)*(ushort *)(lVar2 + 0x2c) < (uint)(int)sVar14) {
    uVar17 = uVar17 & 0xffff;
    *param_3 = 0;
    puVar22 = *(uint **)(lVar2 + 0x18);
    goto LAB_;
  }
  lVar23 = *(longlong *)(lVar2 + 0x18);
  lVar13 = (ulonglong)*(uint *)(lVar2 + 0x24) + lVar23;
  if (sVar14 == 1) {
    uVar15 = *(uint *)(lVar2 + 0x28);
    uVar18 = *(ushort *)(lVar13 + lVar11 * 2) & 0x7fff;
LAB_:
    if ((uVar18 < uVar15) || (*(uint *)(lVar2 + 0x14) < uVar18)) goto LAB_;
  }
  else {
    uVar15 = *(ushort *)(lVar13 + -2 + lVar11 * 2) & 0x7fff;
    lVar23 = *(longlong *)(lVar2 + 0x18);
    uVar18 = *(ushort *)(lVar13 + lVar11 * 2) & 0x7fff;
    if (*(uint *)(lVar2 + 0x28) <= uVar15) goto LAB_;
LAB_:
    func_0x(lVar23,7);
  }
  uVar17 = uVar17 & 0xffff;
  *param_3 = uVar18 - uVar15;
  puVar22 = (uint *)((ulonglong)uVar15 + *(longlong *)(lVar2 + 0x18));
LAB_:
  if ((ushort)uVar17 < *(ushort *)(param_1 + 1)) {
    lVar2 = (ulonglong)(uVar17 & 0xffff) * 10;
    *(uint **)(lVar2 + param_1[2]) = puVar22;
    *(undefined2 *)(param_1[2] + 8 + lVar2) = *(undefined2 *)param_3;
    pbVar24 = (byte *)((ulonglong)((uVar17 & 0xffff) >> 3) + param_1[3]);
    *pbVar24 = *pbVar24 | (byte)(1 << (uVar17 & 7));
  }
  return puVar22;
}

