
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2)

{
  short *psVar1;
  longlong lVar2;
  ulonglong uVar3;
  uint *puVar4;
  code *UNRECOVERED_JUMPTABLE_00;
  int iVar5;
  ulonglong uVar6;
  longlong lVar7;
  longlong unaff_GS_OFFSET;
  undefined auStack_708 [32];
  undefined8 uStack_6e8;
  undefined8 uStack_6e0;
  ushort uStack_6c8;
  undefined auStack_6c6 [2];
  undefined4 uStack_6c4;
  byte *pbStack_6c0;
  undefined8 uStack_6b8;
  undefined8 uStack_6aa;
  undefined2 uStack_6a2;
  undefined2 uStack_6a0;
  undefined6 uStack_69e;
  undefined2 uStack_690;
  undefined4 uStack_68c;
  byte *pbStack_688;
  undefined8 uStack_680;
  undefined8 uStack_672;
  undefined2 uStack_66a;
  undefined2 uStack_668;
  undefined6 uStack_666;
  uint uStack_658;
  int iStack_64c;
  uint uStack_640;
  longlong lStack_638;
  byte *pbStack_630;
  undefined4 uStack_628;
  longlong lStack_608;
  longlong lStack_600;
  longlong lStack_5f8;
  undefined8 uStack_5c8;
  longlong lStack_5c0;
  undefined8 uStack_4e0;
  undefined8 uStack_498;
  undefined *puStack_490;
  byte *pbStack_488;
  undefined *puStack_480;
  undefined auStack_478 [1088];
  ulonglong uStack_38;
  
  uStack_4e0 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_708;
  uVar3 = 0;
  pbStack_630 = (byte *)0x0;
  lStack_638 = param_2;
  lStack_608 = param_1;
  lStack_600 = param_1;
  lStack_5f8 = param_2;
  lStack_5c0 = param_1;
  if (param_2 != 0) {
    uStack_658 = 0;
    if ((ulonglong)*(ushort *)(param_1 + 0x16) != 0) {
      psVar1 = (short *)(param_1 + 0x1ffe);
      uVar6 = uVar3;
      do {
        iVar5 = (int)uVar6;
        if (*psVar1 != 0) goto LAB_;
        uStack_658 = iVar5 + 1;
        uVar6 = (ulonglong)uStack_658;
        uVar3 = uVar3 + 1;
        psVar1 = psVar1 + -1;
      } while ((longlong)uVar3 < (longlong)(ulonglong)*(ushort *)(param_1 + 0x16));
    }
    iVar5 = -1;
    uStack_658 = 0xffffffff;
LAB_:
    lVar7 = -0x144b920;
    uVar3 = 0xfff;
    iStack_64c = iVar5;
    if (iVar5 != -1) {
      uStack_628 = 0;
      lVar2 = func_0x();
      if (lVar2 != 0) {
        lVar2 = func_0x();
        puVar4 = (uint *)(lVar2 + 0x18);
        if (lVar2 == 0) {
          puVar4 = (uint *)0x4;
        }
        if ((*puVar4 >> 1 & 1) != 0) {
          pbStack_688 = (byte *)((ulonglong)
                                 *(ushort *)(param_1 + ((uVar3 & 0xffffffff) - (longlong)iVar5) * 2)
                                + param_1);
          uStack_68c = 0;
          uStack_672 = 0;
          uStack_668 = 0;
          uStack_666 = 0;
          uStack_680 = 0;
          pbStack_630 = pbStack_688;
          if ((*pbStack_688 & 1) == 0) {
            uStack_690 = 0;
            uStack_66a = 0;
            uStack_668 = 0;
                    /* WARNING: Could not recover jumptable at 0x001003a6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)
                       *(uint *)(lVar7 + 0x154d60c + (longlong)(int)(*pbStack_688 & 0xe) * 4) +
                      lVar7))();
            return;
          }
          uStack_690 = 1;
          UNRECOVERED_JUMPTABLE_00 =
               (code *)((ulonglong)
                        *(uint *)(lVar7 + 0x154d5dc +
                                 (ulonglong)
                                 *(byte *)(lVar7 + 0x154d5ec + (longlong)(int)(*pbStack_688 & 0x1c))
                                 * 4) + lVar7);
                    /* WARNING: Could not recover jumptable at 0x001001b5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
          return;
        }
      }
      uStack_6e0 = 0;
      uStack_6e8 = _DAT_;
      func_0x(auStack_478,0,0,0);
      uStack_498 = _DAT_;
      lVar2 = (ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar7 = *(longlong *)(lVar2 + 0x100);
      if (lVar7 == 0) {
        (*_DAT_)(0);
        lVar7 = *(longlong *)(lVar2 + 0x100);
      }
      uStack_5c8 = *(undefined8 *)(lVar7 + 0xc88);
      *(undefined8 *)(lVar7 + 0xc88) = _DAT_;
      pbStack_6c0 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - (longlong)iVar5) * 2) +
                            param_1);
      uStack_6c4 = 0;
      uStack_6aa = 0;
      uStack_6a0 = 0;
      uStack_69e = 0;
      uStack_6b8 = 0;
      uStack_6c8 = (ushort)(*pbStack_6c0 & 1);
      puStack_490 = auStack_6c6;
      pbStack_630 = pbStack_6c0;
      if ((*pbStack_6c0 & 1) != 0) {
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)
                                *(byte *)((longlong)(int)(*pbStack_6c0 & 0x1c) + 0x101d74) * 4 +
                               0x101d64) - 0x144b920);
        puStack_480 = puStack_490;
                    /* WARNING: Could not emulate address calculation at 0x00100e1a */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbStack_6c0,pbStack_6c0,pbStack_6c0);
        return;
      }
      uStack_640 = (uint)*(ushort *)(param_1 + 0xe);
      uStack_6c4 = 0;
      uStack_6a2 = 0;
      uStack_6a0 = 0;
      pbStack_488 = pbStack_6c0;
                    /* WARNING: Could not emulate address calculation at 0x00100d6d */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_6c0 & 0xe) * 4 + 0x101d28) -
                0x144b920))();
      return;
    }
    (*_DAT_)(param_2);
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_708);
  return;
}

