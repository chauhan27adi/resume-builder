
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong *param_1)

{
  short sVar1;
  int iVar2;
  longlong lVar3;
  longlong lVar4;
  ulonglong uVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong unaff_retaddr;
  int iStack_18;
  
  lVar6 = 0;
  *(undefined4 *)((longlong)param_1 + (ulonglong)(*(uint *)(param_1 + 0x46) & 0x3f) * 4 + 0x130) = 7
  ;
  uVar5 = (ulonglong)*(byte *)(param_1 + 0x347);
  param_1[0x46] = param_1[0x46] + 1;
  plVar7 = param_1 + uVar5 * 3;
  lVar3 = func_0x();
  plVar7[0x47] = lVar3;
  param_1[uVar5 * 3 + 0x48] = unaff_retaddr;
  plVar7[0x49] = 0x298;
  param_1[0x347] = param_1[0x347] + 1;
  func_0x(param_1);
  if (param_1[0x355] == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar2 = *(int *)(param_1[0x355] + 0x3cc);
  if (iVar2 == 3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar2 != 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar4 = (**(code **)(*param_1 + 0x20))(param_1);
  lVar3 = *(longlong *)(lVar4 + 4);
  sVar1 = *(short *)(lVar4 + 0xc);
  iStack_18 = (int)lVar3;
  if (((0 < iStack_18) && (iVar2 = (int)((ulonglong)lVar3 >> 0x20), 0 < iVar2)) && (sVar1 != 0)) {
    if ((*(int *)(param_1 + 3) != iStack_18) || (*(int *)((longlong)param_1 + 0x1c) != iVar2)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    param_1[3] = lVar3;
    *(short *)(param_1 + 4) = sVar1;
    lVar3 = func_0x(param_1 + 7,sVar1);
    param_1[5] = lVar3;
    if (3 < *(ushort *)param_1[7]) {
      lVar6 = *(longlong *)((ushort *)param_1[7] + 0x10);
    }
    param_1[6] = lVar6;
    if (param_1[0x355] != 0) {
      (**(code **)(*param_1 + 0x20))(param_1);
      return;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

