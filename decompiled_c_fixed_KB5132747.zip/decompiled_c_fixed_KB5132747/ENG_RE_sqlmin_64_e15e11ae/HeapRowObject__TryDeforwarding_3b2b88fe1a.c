
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 param_2,undefined8 param_3)

{
  byte *pbVar1;
  byte *pbVar2;
  undefined8 *puVar3;
  code *pcVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  char cVar14;
  char cVar15;
  undefined2 uVar16;
  ushort uVar17;
  longlong lVar18;
  short *psVar19;
  longlong lVar20;
  longlong lVar21;
  undefined8 uVar22;
  longlong *plVar23;
  longlong lVar24;
  ulonglong *puVar25;
  undefined4 *puVar26;
  byte bVar27;
  ushort uVar28;
  int iVar29;
  byte *pbVar30;
  undefined4 *puVar31;
  undefined4 uVar32;
  uint uVar33;
  undefined8 unaff_RBX;
  ulonglong uVar34;
  byte **ppbVar35;
  undefined *puVar36;
  short sVar37;
  int iVar38;
  byte *pbVar39;
  undefined4 *puVar40;
  uint uVar41;
  undefined2 *puVar42;
  uint uVar43;
  ulonglong uVar44;
  ushort *puVar45;
  uint uVar46;
  ushort *puVar47;
  ulonglong uVar48;
  undefined8 uStackX_8;
  undefined2 auStackX_10 [4];
  undefined4 uStackX_18;
  ushort auStackX_1c [2];
  short sStackX_20;
  undefined2 uStackX_22;
  uint uStackX_24;
  undefined8 uStack_100;
  undefined auStack_f8 [48];
  undefined auStack_c8 [16];
  undefined2 auStack_b8 [2];
  undefined4 uStack_b4;
  undefined8 uStack_b0;
  undefined8 uStack_a8;
  undefined8 uStack_9a;
  undefined8 uStack_90;
  undefined auStack_88 [8];
  undefined8 uStack_80;
  undefined auStack_78 [16];
  undefined8 uStack_68;
  undefined4 auStack_60 [2];
  undefined8 uStack_58;
  undefined2 auStack_48 [2];
  undefined4 uStack_44;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar18 = func_0x();
  lVar18 = -lVar18;
  pbVar2 = &stack0xfffffffffffffff8 + lVar18;
  *(undefined8 *)(&stack0x000023e0 + lVar18) = unaff_RBX;
  *(ulonglong *)(&stack0x00002378 + lVar18) = _DAT_ ^ (ulonglong)pbVar2;
  *(longlong *)(&stack0x00000078 + lVar18) = param_1;
  *(undefined2 *)(&stack0x000002c8 + lVar18) = 0xffff;
  *(undefined4 *)(&stack0x00000058 + lVar18) = param_2;
  *(undefined8 *)(&stack0x000002d0 + lVar18) = 0;
  pbVar30 = (byte *)(param_1 + 0x530);
  *(undefined4 *)(&stack0x000002cc + lVar18) = 0;
  *(undefined8 *)(&stack0x000002e6 + lVar18) = 0;
  *(undefined8 *)(&stack0x000002f0 + lVar18) = 0;
  bVar27 = *pbVar30;
  *(undefined8 *)(&stack0x000002d8 + lVar18) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar18) = 0;
  *(undefined4 *)((longlong)&uStackX_18 + lVar18 + 0xc) = 0;
  *(undefined8 *)(&stack0x0000003e + lVar18) = 0;
  *(undefined8 *)(&stack0x00000048 + lVar18) = 0;
  *(undefined8 *)(&stack0x00000030 + lVar18) = 0;
  *(undefined4 *)(&stack0x00000388 + lVar18) = 0;
  *(undefined2 *)(&stack0x0000038c + lVar18) = 0;
  *(undefined8 *)(&stack0x00000390 + lVar18) = 0;
  *(undefined2 *)(&stack0x00000398 + lVar18) = 0;
  *(undefined4 *)(&stack0x0000039a + lVar18) = 0;
  *(undefined2 *)(&stack0x0000039e + lVar18) = 0;
  *(undefined8 *)(&stack0x000003a0 + lVar18) = 0;
  *(undefined4 *)(&stack0x000003b8 + lVar18) = 0;
  *(undefined2 *)(&stack0x000003bc + lVar18) = 0;
  *(undefined8 *)(&stack0x000003c0 + lVar18) = 0;
  *(undefined2 *)(&stack0x000003c8 + lVar18) = 0;
  *(undefined4 *)(&stack0x000003ca + lVar18) = 0;
  *(undefined2 *)(&stack0x000003ce + lVar18) = 0;
  *(undefined8 *)(&stack0x000003d0 + lVar18) = 0;
  lVar21 = *(longlong *)(param_1 + 0x28);
  *(undefined (*) [16])(&stack0x000000a0 + lVar18) = ZEXT816(0);
  *(undefined8 *)(&stack0x00000098 + lVar18) = param_3;
  *(byte **)(&stack0x00000088 + lVar18) = pbVar30;
  lVar21 = *(longlong *)(lVar21 + 8);
  *(longlong *)(&stack0x00000070 + lVar18) = lVar21;
  *pbVar2 = bVar27;
  *(longlong *)(&stack0x00000090 + lVar18) = lVar21 + 0x28;
  puVar36 = &stack0xffffffffffffffc8 + lVar18;
  if ((DAT_ & 4) != 0) goto LAB_;
  *(longlong *)(&stack0x00000080 + lVar18) = param_1 + 0x30;
  *pbVar30 = bVar27 & 0xfb | 1;
  *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10014a;
  func_0x(param_1 + 0x30);
  lVar21 = param_1 + 0x2b0;
  *(longlong *)(&stack0x00000068 + lVar18) = lVar21;
  *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10015d;
  func_0x(lVar21);
  if (*(longlong *)(param_1 + 0x2d8) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10016e;
    func_0x(lVar21,0);
  }
  lVar20 = *(longlong *)(param_1 + 0x508);
  iVar38 = *(int *)(param_1 + 0x2d0);
  *(int *)(&stack0x000002fc + lVar18) = iVar38;
  *(undefined4 *)((longlong)&uStackX_18 + lVar18 + -0x14) = 9;
  if (*(char *)(lVar20 + 2) < '\0') {
    pbVar30 = (byte *)(lVar20 + 0x60);
    if ((*(short *)(&stack0x000002c8 + lVar18) == 0) ||
       (ppbVar35 = *(byte ***)(&stack0x000002d8 + lVar18), ppbVar35 == (byte **)0x0)) {
      ppbVar35 = (byte **)(&stack0x00000300 + lVar18);
      *(undefined8 *)(&stack0x00000370 + lVar18) = 0;
      *(undefined (*) [16])(&stack0x00000310 + lVar18) = ZEXT816(0);
      *(undefined8 *)(&stack0x00000318 + lVar18) = 0;
      *(undefined (*) [16])(&stack0x00000320 + lVar18) = ZEXT816(0);
      *(undefined2 *)(&stack0x00000310 + lVar18) = 0xffff;
      *(undefined (*) [16])(&stack0x00000330 + lVar18) = ZEXT816(0);
      *(undefined4 *)(&stack0x00000314 + lVar18) = 0;
      *(undefined (*) [16])(&stack0x00000360 + lVar18) = ZEXT816(0);
      *(undefined8 *)(&stack0x0000032e + lVar18) = 0;
      *(undefined (*) [16])(&stack0x00000340 + lVar18) = ZEXT816(0);
      *(undefined8 *)(&stack0x00000338 + lVar18) = 0;
      *(undefined8 *)(&stack0x00000320 + lVar18) = 0;
      *(undefined8 *)(&stack0x00000348 + lVar18) = 0;
      *(undefined8 *)(&stack0x00000360 + lVar18) = 0;
      *(undefined4 *)(&stack0x00000368 + lVar18) = 0;
      *(undefined2 *)(&stack0x00000372 + lVar18) = 0;
      *(undefined (*) [16])(&stack0x00000350 + lVar18) = ZEXT816(0);
      *(undefined (*) [16])(&stack0x00000300 + lVar18) = ZEXT816(0);
    }
    if (*(short *)(lVar20 + 0x24) == 0) {
LAB_:
      uVar16 = *(undefined2 *)(lVar20 + 0x30);
      *(undefined8 *)((longlong)&uStackX_8 + lVar18) = *(undefined8 *)(lVar20 + 0x28);
      *(undefined2 *)((longlong)auStackX_10 + lVar18) = uVar16;
    }
    else {
      cVar14 = *(char *)(lVar20 + 1);
      if (cVar14 == '\v') {
        if (*(int *)(lVar20 + 0x18) != 99) {
LAB_:
          if (cVar14 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar14 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar20 + 0x18) != 99) goto LAB_;
      }
      *(undefined4 *)(&stack0xfffffffffffffffc + lVar18) = *(undefined4 *)(lVar20 + 0x20);
      *(undefined2 *)((longlong)&uStackX_18 + lVar18 + -0x18) = *(undefined2 *)(lVar20 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10029c;
      cVar14 = func_0x(&stack0xfffffffffffffffc + lVar18);
      if (cVar14 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1002ac;
      func_0x(lVar20,(longlong)&uStackX_8 + lVar18);
      uVar16 = *(undefined2 *)((longlong)auStackX_10 + lVar18);
    }
    uVar32 = *(undefined4 *)((longlong)&uStackX_8 + lVar18);
    *ppbVar35 = pbVar30;
    *(undefined4 *)(ppbVar35 + 0xc) = uVar32;
    uVar22 = *(undefined8 *)((longlong)&uStackX_8 + lVar18);
    *(undefined2 *)(ppbVar35 + 0xd) = uVar16;
    *(int *)((longlong)ppbVar35 + 100) = (int)((ulonglong)uVar22 >> 0x20);
    *(undefined4 *)((longlong)ppbVar35 + 0x6c) = *(undefined4 *)(lVar20 + 0x20);
    *(undefined2 *)(ppbVar35 + 0xe) = *(undefined2 *)(lVar20 + 0x24);
    *(undefined2 *)((longlong)ppbVar35 + 0x72) = 0;
    uVar32 = *(undefined4 *)((ulonglong)*pbVar30 * 6 + 0x16a51e0);
    uVar44 = (ulonglong)*(short *)((ulonglong)*pbVar30 * 6 + 0x16a51e4);
    *(undefined2 *)(ppbVar35 + 2) = 0xffff;
    ppbVar35[3] = (byte *)0x0;
    uVar43 = 0;
    *(undefined4 *)((longlong)ppbVar35 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar35 + 0x2e) = 0;
    ppbVar35[7] = (byte *)0x0;
    ppbVar35[4] = (byte *)0x0;
    ppbVar35[9] = (byte *)0x0;
    ppbVar35[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar35 + 0xb) = 0;
    *(undefined4 *)((longlong)&uStackX_18 + lVar18) = uVar32;
    if ((**ppbVar35 & 2) != 0) {
      pbVar1 = pbVar30 + uVar44;
      if ((pbVar30[uVar44] & 1) == 0) {
        *(undefined2 *)(ppbVar35 + 2) = 0;
        ppbVar35[3] = pbVar1;
        *(undefined4 *)((longlong)ppbVar35 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar35 + 0x36) = 0;
        switch(*pbVar1 & 0xe) {
        default:
          uVar43 = (uint)*(ushort *)(pbVar1 + 2);
          if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100549;
            func_0x(pbVar1,6);
          }
          break;
        case 4:
          uVar43 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar43 = 1;
        }
        *(uint *)(ppbVar35 + 4) = uVar43;
        *(undefined8 *)((longlong)ppbVar35 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar35 + 2) = 1;
        ppbVar35[3] = pbVar1;
        bVar27 = *pbVar1;
        switch(bVar27 & 0x1c) {
        default:
          if ((char)pbVar1[1] < '\0') {
            uVar28 = *(ushort *)(pbVar1 + 1);
            sVar37 = 3;
            *(ushort *)((longlong)ppbVar35 + 0x12) = uVar28;
            uVar28 = (uVar28 & 0x7f) << 8 | uVar28 >> 8;
          }
          else {
            sVar37 = 2;
            uVar28 = (ushort)pbVar1[1];
          }
          *(ushort *)((longlong)ppbVar35 + 0x12) = uVar28;
          *(short *)(ppbVar35 + 5) = sVar37;
          uVar28 = *(ushort *)((longlong)ppbVar35 + 0x12);
          *(short *)((longlong)ppbVar35 + 0x2c) = (short)(uVar28 + 1 >> 1) + sVar37;
          if (uVar28 < 0x1f) {
            *(undefined2 *)((longlong)ppbVar35 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar35 + 0x14) = 0;
            *(undefined4 *)(ppbVar35 + 8) = 0;
            ppbVar35[7] = (byte *)0x0;
            ppbVar35[4] = (byte *)0x0;
          }
          else {
            iVar29 = uVar28 - 1;
            *(short *)((longlong)ppbVar35 + 0x2a) =
                 ((short)(iVar29 / 0x1e) + (short)(iVar29 >> 0x1f)) -
                 (short)((longlong)iVar29 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar35 + 0x14) = 0;
            *(undefined4 *)(ppbVar35 + 8) = 0;
            ppbVar35[7] = (byte *)0x0;
            ppbVar35[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar27 & 0x1c) == 4) && ((bVar27 & 2) != 0)) {
            *(undefined4 *)(ppbVar35 + 8) = 0;
            uVar43 = 1;
            uVar32 = 0xf;
          }
          else {
            uVar32 = 1;
          }
          *(undefined4 *)(ppbVar35 + 8) = 0;
          ppbVar35[3] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar35 + 0x14) = 0;
          *(undefined2 *)(ppbVar35 + 5) = 0;
          *(undefined2 *)((longlong)ppbVar35 + 0x12) = 0;
          *(undefined8 *)((longlong)ppbVar35 + 0x2a) = 0;
          *(undefined4 *)((longlong)ppbVar35 + 0x32) = 0;
          *(undefined2 *)((longlong)ppbVar35 + 0x36) = 0;
          ppbVar35[4] = (byte *)0x0;
          ppbVar35[7] = (byte *)0x0;
          ppbVar35[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar35 + 0x14) = uVar32;
          *(uint *)(ppbVar35 + 8) = uVar43;
          ppbVar35[7] = (byte *)0x0;
          ppbVar35[4] = (byte *)0x0;
          break;
        case 8:
          ppbVar35[7] = (byte *)0x0;
          ppbVar35[7] = (byte *)0x0;
          ppbVar35[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar35 + 0x12) = 0;
          ppbVar35[6] = (byte *)0x0;
          ppbVar35[4] = (byte *)0x0;
          ppbVar35[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar35 + 0x14) = 9;
          *(undefined4 *)(ppbVar35 + 8) = 0;
          ppbVar35[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar35 & 4) != 0) {
      sVar37 = *(short *)((longlong)&uStackX_18 + lVar18 + 2);
      if (sVar37 != 0) {
        uVar44 = (ulonglong)*(ushort *)(lVar20 + 0x61 + (longlong)sVar37 * 2);
      }
      psVar19 = (short *)(pbVar30 + uVar44);
      ppbVar35[9] = (byte *)psVar19;
      sVar37 = *psVar19;
      ppbVar35[10] = (byte *)(psVar19 + 1);
      *(short *)(ppbVar35 + 0xb) = (sVar37 + 1) * 2;
    }
    pbVar30 = ppbVar35[1];
    if (pbVar30 != (byte *)0x0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1005e8;
      func_0x(pbVar30,ppbVar35);
    }
    lVar21 = *(longlong *)(&stack0x00000068 + lVar18);
  }
  else {
    ppbVar35 = (byte **)0x0;
  }
  uVar44 = 0;
  uVar34 = (ulonglong)*(ushort *)(lVar20 + 0xe);
  pbVar30 = (byte *)((ulonglong)*(ushort *)(lVar20 + (0xfff - (longlong)iVar38) * 2) + lVar20);
  bVar27 = *pbVar30;
  *(byte **)(&stack0x000002d0 + lVar18) = pbVar30;
  if ((bVar27 & 1) == 0) {
    *(undefined2 *)(&stack0x000002c8 + lVar18) = 0;
    *(undefined4 *)(&stack0x000002cc + lVar18) = 0;
    *(undefined4 *)(&stack0x000002ee + lVar18) = 0;
    switch(*pbVar30 & 0xe) {
    default:
      uVar34 = (ulonglong)*(ushort *)(pbVar30 + 2);
      uVar44 = 0;
      if (0x1f9d < *(ushort *)(pbVar30 + 2) - 1) {
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100856;
        func_0x(pbVar30,6);
        pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
        uVar44 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
      }
      break;
    case 4:
      uVar34 = 9;
      uVar44 = 0;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar34 = 1;
    }
    *(int *)(&stack0x000002d8 + lVar18) = (int)uVar34;
    ppbVar35 = *(byte ***)(&stack0x000002d8 + lVar18);
    *(longlong *)(&stack0x000002e6 + lVar18) = lVar20 + 0x2000;
  }
  else {
    *(undefined2 *)(&stack0x000002c8 + lVar18) = 1;
    bVar27 = *pbVar30;
    switch(bVar27 & 0x1c) {
    default:
      if ((char)pbVar30[1] < '\0') {
        uVar28 = (*(ushort *)(pbVar30 + 1) & 0x7f) << 8 | *(ushort *)(pbVar30 + 1) >> 8;
        uVar16 = 3;
        sVar37 = 3;
        *(ushort *)(&stack0x000002ca + lVar18) = uVar28;
      }
      else {
        uVar28 = (ushort)pbVar30[1];
        *(ushort *)(&stack0x000002ca + lVar18) = uVar28;
        uVar16 = 2;
        sVar37 = 2;
      }
      *(undefined2 *)(&stack0x000002e0 + lVar18) = uVar16;
      *(ushort *)(&stack0x000002e4 + lVar18) = ((ushort)(uVar28 + 1) >> 1) + sVar37;
      if (uVar28 < 0x1f) {
        *(undefined2 *)(&stack0x000002e2 + lVar18) = 0;
        *(undefined4 *)(&stack0x000002cc + lVar18) = 0;
        *(undefined4 *)(&stack0x000002f8 + lVar18) = 0;
      }
      else {
        iVar38 = uVar28 - 1;
        *(undefined4 *)(&stack0x000002cc + lVar18) = 0;
        *(undefined4 *)(&stack0x000002f8 + lVar18) = 0;
        *(short *)(&stack0x000002e2 + lVar18) =
             ((short)(iVar38 / 0x1e) + (short)(iVar38 >> 0x1f)) -
             (short)((longlong)iVar38 * 0x88888889 >> 0x3f);
      }
      break;
    case 4:
      if (((bVar27 & 0x1c) == 4) && ((bVar27 & 2) != 0)) {
        uVar44 = 0xf;
        *(undefined8 *)(&stack0x000002e0 + lVar18) = 0;
        *(undefined4 *)(&stack0x000002cc + lVar18) = 0xf;
        *(undefined2 *)(&stack0x000002ca + lVar18) = 0;
        *(undefined8 *)(&stack0x000002e8 + lVar18) = 0;
        *(undefined4 *)(&stack0x000002f8 + lVar18) = 1;
      }
      else {
        *(undefined8 *)(&stack0x000002e0 + lVar18) = 0;
        uVar44 = 1;
        *(undefined2 *)(&stack0x000002ca + lVar18) = 0;
        *(undefined8 *)(&stack0x000002e8 + lVar18) = 0;
        *(undefined4 *)(&stack0x000002cc + lVar18) = 1;
        *(undefined4 *)(&stack0x000002f8 + lVar18) = 0;
      }
      break;
    case 8:
      *(undefined8 *)(&stack0x000002e0 + lVar18) = 0;
      uVar44 = 9;
      *(undefined2 *)(&stack0x000002ca + lVar18) = 0;
      *(undefined8 *)(&stack0x000002e8 + lVar18) = 0;
      *(undefined4 *)(&stack0x000002cc + lVar18) = 9;
      *(undefined4 *)(&stack0x000002f8 + lVar18) = 0;
    }
    *(byte ***)(&stack0x000002d8 + lVar18) = ppbVar35;
    *(longlong *)(&stack0x000002f0 + lVar18) = lVar20 + 0x2000;
    uVar34 = (ulonglong)ppbVar35 & 0xffffffff;
  }
  sVar37 = *(short *)(&stack0x000002c8 + lVar18);
  *(short *)((longlong)&uStackX_18 + lVar18 + 8) = sVar37;
  if (sVar37 == 0) {
    if ((int)uVar44 == 0) {
      *(undefined2 *)(&stack0x000002ca + lVar18) = 0;
      *(int *)(&stack0x000002dc + lVar18) = (int)uVar34;
      uVar44 = uVar34;
      if ((*pbVar30 & 0x10) != 0) {
        uVar43 = (int)uVar34 + 2 + (*(ushort *)(pbVar30 + uVar34) + 7 >> 3);
        uVar44 = (ulonglong)uVar43;
        *(uint *)(&stack0x000002dc + lVar18) = uVar43;
      }
      if ((*pbVar30 & 0x20) == 0) {
        *(int *)(&stack0x000002cc + lVar18) = (int)uVar44;
        *(undefined2 *)(&stack0x000002e4 + lVar18) = 0;
        *(int *)(&stack0x000002e0 + lVar18) = (int)uVar44;
      }
      else {
        puVar47 = (ushort *)(pbVar30 + uVar44);
        uVar28 = *puVar47;
        *(ushort *)(&stack0x000002e4 + lVar18) = uVar28;
        if (uVar28 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100941;
          cVar14 = func_0x(0x1fbb990);
          if (cVar14 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10094a;
            lVar20 = func_0x();
            if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100964;
              cVar14 = func_0x(0x1fbb990);
              if (cVar14 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100980;
                (*pcRam0000000001529518)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1009a6;
                (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x80f);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1009b7;
          func_0x(*(undefined8 *)(&stack0x000002d0 + lVar18),3);
          pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
        }
        uVar43 = *(int *)(&stack0x000002dc + lVar18) +
                 (*(ushort *)(&stack0x000002e4 + lVar18) + 1) * 2;
        *(uint *)(&stack0x000002e0 + lVar18) = uVar43;
        if (0x1f9e < uVar43) {
          *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1009ee;
          cVar14 = func_0x(0x1fbb990);
          if (cVar14 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1009f7;
            lVar20 = func_0x();
            if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100a11;
              cVar14 = func_0x(0x1fbb990);
              if (cVar14 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100a2d;
                (*pcRam0000000001529518)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100a53;
                (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x816);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100a64;
          func_0x(*(undefined8 *)(&stack0x000002d0 + lVar18),4);
          pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
        }
        uVar43 = puVar47[*(ushort *)(&stack0x000002e4 + lVar18)] & 0x7fff;
        *(uint *)(&stack0x000002cc + lVar18) = uVar43;
        if (uVar43 < *(uint *)(&stack0x000002e0 + lVar18)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100a9e;
          cVar14 = func_0x(0x1fbb990);
          if (cVar14 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100aa7;
            lVar20 = func_0x();
            if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100ac1;
              cVar14 = func_0x(0x1fbb990);
              if (cVar14 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100add;
                (*pcRam0000000001529518)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100b03;
                (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x81d);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100b14;
          func_0x(*(undefined8 *)(&stack0x000002d0 + lVar18),4);
          pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
          uVar43 = *(uint *)(&stack0x000002cc + lVar18);
        }
        uVar44 = (ulonglong)uVar43;
        uVar43 = *(uint *)(&stack0x000002e0 + lVar18);
        iVar38 = 0;
        puVar45 = puVar47;
        if (*(short *)(&stack0x000002e4 + lVar18) != 0) {
          do {
            uVar33 = puVar45[1] & 0x7fff;
            if ((uVar33 < uVar43) || ((uint)uVar44 < uVar33)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100b62;
              cVar14 = func_0x(0x1fbb990);
              if (cVar14 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100b6b;
                lVar21 = func_0x();
                if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100b85;
                  cVar14 = func_0x(0x1fbb990);
                  if (cVar14 == '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100ba1;
                    (*pcRam0000000001529518)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100bc5;
                    (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x82a);
                  }
                }
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100bd6;
              func_0x(*(undefined8 *)(&stack0x000002d0 + lVar18),4);
              pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
              uVar44 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
            }
            iVar38 = iVar38 + 1;
            uVar43 = uVar33;
            puVar45 = puVar45 + 1;
          } while (iVar38 < (int)(uint)*(ushort *)(&stack0x000002e4 + lVar18));
          lVar21 = *(longlong *)(&stack0x00000068 + lVar18);
        }
        while( true ) {
          uVar28 = *(ushort *)(&stack0x000002e4 + lVar18);
          if (-1 < (short)puVar47[(ulonglong)(uVar28 - 1) + 1]) break;
          if (uVar28 == 1) {
            uVar43 = *(uint *)(&stack0x000002e0 + lVar18);
          }
          else {
            uVar43 = *(ushort *)
                      (pbVar30 +
                      (longlong)(int)(uint)uVar28 * 2 +
                      ((ulonglong)*(uint *)(&stack0x000002dc + lVar18) - 2)) & 0x7fff;
          }
          uVar33 = *(ushort *)
                    (pbVar30 +
                    (ulonglong)uVar28 * 2 + (ulonglong)*(uint *)(&stack0x000002dc + lVar18)) &
                   0x7fff;
          if (((uVar43 < *(uint *)(&stack0x000002e0 + lVar18)) || (uVar33 < uVar43)) ||
             ((uint)uVar44 < uVar33)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100c67;
            func_0x(pbVar30,7);
            pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
            uVar44 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
          }
          if ((uVar43 < *(uint *)(&stack0x000002e0 + lVar18)) || ((uint)uVar44 < uVar43))
          goto code_r0x0010106f;
          if (*(ushort *)(pbVar30 + uVar43) == 5) {
            *(ushort *)(&stack0x000002ca + lVar18) = *(ushort *)(&stack0x000002ca + lVar18) | 2;
            *(short *)(&stack0x000002e4 + lVar18) = *(short *)(&stack0x000002e4 + lVar18) + -1;
            uVar28 = *(ushort *)(&stack0x000002f4 + lVar18);
            uVar34 = (ulonglong)uVar43 & 0xffff;
            pbVar1 = pbVar30 + uVar34;
            *(short *)(&stack0x000002f2 + lVar18) = (short)uVar43;
            if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
              uVar28 = uVar28 & 0xc7ff;
            }
            else {
              uVar28 = uVar28 ^ (uVar28 ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
            }
            *(ushort *)(&stack0x000002f4 + lVar18) = uVar28;
            uVar17 = (uVar28 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar28;
            *(ushort *)(&stack0x000002f4 + lVar18) = uVar17;
            pbVar39 = pbVar30 + (ulonglong)((uVar17 & 0x7ff) * 2) + 4 +
                                uVar34 + (uVar28 >> 0xb & 7) * 2;
            if (pbVar39 < pbVar1) {
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100d6b;
              func_0x(pbVar1,0x19);
              uVar17 = *(ushort *)(&stack0x000002f4 + lVar18);
              pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
              uVar44 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
              uVar34 = (ulonglong)*(ushort *)(&stack0x000002f2 + lVar18);
            }
            if (uVar33 - uVar43 <
                (((*(uint *)(&stack0x000002f4 + lVar18) & 0x7ff) * 2 - (int)uVar34) -
                *(int *)(&stack0x000002d0 + lVar18)) + (int)pbVar39) {
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100db8;
              func_0x(pbVar30 + uVar34,0x19);
              uVar17 = *(ushort *)(&stack0x000002f4 + lVar18);
              pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
              uVar44 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
              uVar34 = (ulonglong)*(ushort *)(&stack0x000002f2 + lVar18);
            }
            if ((uVar17 & 0x3800) != 0) {
              puVar47 = (ushort *)(pbVar30 + uVar34 + 4);
              iVar38 = 0;
              if ((uVar17 & 0x3800) != 0) {
                do {
                  if ((uVar17 & 0x7ff) < (*puVar47 & 0x7ff)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100e34;
                    func_0x(pbVar30 + uVar34,0x1a);
                    uVar17 = *(ushort *)(&stack0x000002f4 + lVar18);
                    pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
                    uVar34 = (ulonglong)*(ushort *)(&stack0x000002f2 + lVar18);
                  }
                  iVar38 = iVar38 + 1;
                  puVar47 = puVar47 + 1;
                } while (iVar38 < (int)(*(uint *)(&stack0x000002f4 + lVar18) >> 0xb & 7));
                uVar44 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
              }
            }
            break;
          }
          if (*(ushort *)(pbVar30 + uVar43) < 0x400) break;
          *(ushort *)(&stack0x000002ca + lVar18) = *(ushort *)(&stack0x000002ca + lVar18) | 1;
          psVar19 = (short *)(&stack0x000002e4 + lVar18);
          *psVar19 = *psVar19 + -1;
          if (*psVar19 == 0) break;
        }
      }
      if ((*pbVar30 & 0x40) == 0) {
        *(undefined4 *)(&stack0x000002ee + lVar18) = 0;
      }
      else {
        *(int *)(&stack0x000002ee + lVar18) = (int)uVar44;
        *(int *)(&stack0x000002cc + lVar18) = (int)uVar44 + 0xe;
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100eb5;
        uVar22 = func_0x(&stack0x000002ca + lVar18);
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100ec1;
        func_0x(uVar22,&stack0x00000060 + lVar18);
        uVar28 = *(ushort *)(&stack0x00000066 + lVar18);
        uVar43 = 0;
        uVar17 = uVar28;
        if ((((uint)(int)(short)uVar28 >> 1 ^ (int)(short)uVar28) & 0x2000) != 0) {
          uVar17 = uVar28 & 0xdfff;
          if ((uVar28 & 0x4000) != 0) {
            uVar17 = uVar28 | 0x2000;
          }
        }
        if (uVar17 == 0xfffc) {
          uVar43 = (uint)(*(ushort *)(&stack0x00000064 + lVar18) >> 5);
        }
        pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
        uVar44 = (ulonglong)(*(int *)(&stack0x000002cc + lVar18) + uVar43);
        *(uint *)(&stack0x000002cc + lVar18) = *(int *)(&stack0x000002cc + lVar18) + uVar43;
      }
      if ((*(byte **)(&stack0x000002e6 + lVar18) != (byte *)0x0) &&
         (*(byte **)(&stack0x000002e6 + lVar18) < pbVar30 + uVar44)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100f50;
        cVar14 = func_0x(0x1fbb990);
        if (cVar14 != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100f59;
          lVar20 = func_0x();
          if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100f73;
            cVar14 = func_0x(0x1fbb990);
            if (cVar14 == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100f8f;
              (*pcRam0000000001529518)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100fb3;
              (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x886);
            }
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100fc4;
        func_0x(*(undefined8 *)(&stack0x000002d0 + lVar18),0x12);
        pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
        uVar44 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
      }
      if (0x3f3b < (int)uVar44 - 1U) {
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100fed;
        cVar14 = func_0x(0x1fbb990);
        if (cVar14 != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100ff6;
          lVar20 = func_0x();
          if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x101010;
            cVar14 = func_0x(0x1fbb990);
            if (cVar14 == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10102c;
              (*pcRam0000000001529518)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x101050;
              (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x88b);
            }
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x101061;
        func_0x(*(undefined8 *)(&stack0x000002d0 + lVar18),5);
        pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
        uVar44 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
      }
    }
code_r0x0010106f:
    uVar33 = (uint)uVar44;
    uVar43 = uVar33;
    if ((uVar33 < 9) && (((*pbVar30 & 0xe) == 0 || ((*pbVar30 & 0xe) == 0xc)))) {
      uVar43 = 9;
    }
    *(undefined4 *)(&stack0x00000030 + lVar18) = *(undefined4 *)(&stack0x000002d8 + lVar18);
    *(undefined2 *)((longlong)&uStackX_18 + lVar18 + 10) =
         *(undefined2 *)(&stack0x000002ca + lVar18);
    *(undefined2 *)(&stack0x0000003c + lVar18) = *(undefined2 *)(&stack0x000002e4 + lVar18);
    *(undefined4 *)(&stack0x00000034 + lVar18) = *(undefined4 *)(&stack0x000002dc + lVar18);
    uVar32 = *(undefined4 *)(&stack0x000002e0 + lVar18);
    *(uint *)((longlong)&uStackX_18 + lVar18 + 0xc) = uVar33;
    *(undefined4 *)(&stack0x00000038 + lVar18) = uVar32;
    *(undefined4 *)(&stack0x00000046 + lVar18) = *(undefined4 *)(&stack0x000002ee + lVar18);
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1010e0;
    func_0x(&stack0x000003d8 + lVar18,0x1f9e,pbVar30,uVar43);
    *(undefined **)(&stack0x00000028 + lVar18) = &stack0x000003d8 + lVar18;
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1010f4;
    iVar38 = func_0x((longlong)&uStackX_18 + lVar18 + 10);
    pbVar30 = *(byte **)(&stack0x00000028 + lVar18);
    if (iVar38 != 0) {
      puVar47 = (ushort *)(pbVar30 + *(uint *)(&stack0x00000034 + lVar18));
      uVar43 = *puVar47 - 1;
      if ((*(byte *)((longlong)&uStackX_18 + lVar18 + 10) & 1) == 0) {
        uVar43 = (uint)*puVar47;
      }
      uVar33 = *(uint *)(&stack0x00000038 + lVar18);
      if (uVar43 != 1) {
        uVar33 = puVar47[(longlong)(int)uVar43 + -1] & 0x7fff;
      }
      uVar43 = puVar47[(int)uVar43] & 0x7fff;
      if (((uVar33 < *(uint *)(&stack0x00000038 + lVar18)) || (uVar43 < uVar33)) ||
         (*(uint *)((longlong)&uStackX_18 + lVar18 + 0xc) < uVar43)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x101154;
        func_0x(pbVar30,7);
        pbVar30 = *(byte **)(&stack0x00000028 + lVar18);
      }
      uVar28 = *(ushort *)(&stack0x0000004c + lVar18);
      uVar44 = (ulonglong)(uVar33 & 0xffff);
      pbVar1 = pbVar30 + uVar44;
      *(short *)(&stack0x0000004a + lVar18) = (short)uVar33;
      if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
        uVar28 = uVar28 & 0xc7ff;
      }
      else {
        uVar28 = uVar28 ^ (uVar28 ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
      }
      *(ushort *)(&stack0x0000004c + lVar18) = uVar28;
      uVar17 = (uVar28 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar28;
      *(ushort *)(&stack0x0000004c + lVar18) = uVar17;
      pbVar39 = pbVar30 + (ulonglong)((uVar17 & 0x7ff) * 2) + 4 + uVar44 + (uVar28 >> 0xb & 7) * 2;
      if (pbVar39 < pbVar1) {
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1011e8;
        func_0x(pbVar1,0x19);
        uVar17 = *(ushort *)(&stack0x0000004c + lVar18);
        uVar44 = (ulonglong)*(ushort *)(&stack0x0000004a + lVar18);
        pbVar30 = *(byte **)(&stack0x00000028 + lVar18);
      }
      if (uVar43 - uVar33 <
          (((*(uint *)(&stack0x0000004c + lVar18) & 0x7ff) * 2 - (int)uVar44) -
          *(int *)(&stack0x00000028 + lVar18)) + (int)pbVar39) {
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10121e;
        func_0x(pbVar30 + uVar44,0x19);
        uVar17 = *(ushort *)(&stack0x0000004c + lVar18);
        uVar44 = (ulonglong)*(ushort *)(&stack0x0000004a + lVar18);
        pbVar30 = *(byte **)(&stack0x00000028 + lVar18);
      }
      if ((uVar17 & 0x3800) != 0) {
        puVar47 = (ushort *)(pbVar30 + uVar44 + 4);
        iVar38 = 0;
        if ((uVar17 & 0x3800) != 0) {
          do {
            if ((uVar17 & 0x7ff) < (*puVar47 & 0x7ff)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x101285;
              func_0x(pbVar30 + uVar44);
              uVar17 = *(ushort *)(&stack0x0000004c + lVar18);
              uVar44 = (ulonglong)*(ushort *)(&stack0x0000004a + lVar18);
              pbVar30 = *(byte **)(&stack0x00000028 + lVar18);
            }
            iVar38 = iVar38 + 1;
            puVar47 = puVar47 + 1;
          } while (iVar38 < (int)(*(uint *)(&stack0x0000004c + lVar18) >> 0xb & 7));
        }
      }
    }
  }
  else if ((ppbVar35 == (byte **)0x0) || (*ppbVar35 == (byte *)0x0)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10130e;
    func_0x((longlong)&uStackX_18 + lVar18 + 10,&stack0x000003d8 + lVar18,0x1f9e,
                    &stack0x000002ca + lVar18);
    uVar22 = *(undefined8 *)(&stack0x000002d8 + lVar18);
    pbVar30 = *(byte **)(&stack0x00000028 + lVar18);
    if (*(short *)(&stack0x000002c8 + lVar18) == 0) {
      uVar22 = 0;
    }
    *(undefined8 *)(&stack0x00000030 + lVar18) = uVar22;
  }
  else {
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1012eb;
    func_0x((longlong)&uStackX_18 + lVar18 + 8,&stack0x000003d8 + lVar18,0x1f9e,
                    &stack0x000002c8 + lVar18);
    pbVar30 = *(byte **)(&stack0x00000028 + lVar18);
  }
  sVar37 = *(short *)((longlong)&uStackX_18 + lVar18 + 8);
  if (sVar37 == 0) {
    bVar27 = *pbVar30 >> 6;
  }
  else {
    bVar27 = *pbVar30 >> 1;
  }
  if ((bVar27 & 1) != 0) {
    if (sVar37 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10134b;
      func_0x();
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x101352;
      func_0x((longlong)&uStackX_18 + lVar18 + 10,(longlong)&uStackX_18 + lVar18);
    }
    uVar28 = *(ushort *)((longlong)&uStackX_18 + lVar18 + 6);
    uVar17 = uVar28;
    if (((((uint)(int)(short)uVar28 >> 1 ^ (int)(short)uVar28) & 0x2000) != 0) &&
       (uVar17 = uVar28 & 0xdfff, (uVar28 & 0x4000) != 0)) {
      uVar17 = uVar28 | 0x2000;
    }
    if ((uVar17 == 0xfffc) &&
       (puVar36 = &stack0xffffffffffffffc8 + lVar18,
       0x1f < *(ushort *)((longlong)&uStackX_18 + lVar18 + 4))) goto LAB_;
  }
  if (*(longlong *)(lVar21 + 0x28) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1013a1;
    func_0x(lVar21);
  }
  if (*(int *)(lVar21 + 0x240) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1013b6;
    func_0x(lVar21);
  }
  if (iRam0000000001fbf978 != 0) {
    plVar23 = *(longlong **)(lVar21 + 0xd0);
    puVar3 = *(undefined8 **)(*(longlong *)(lVar21 + 8) + 8);
    iVar38 = *(int *)(plVar23 + 2);
    cVar14 = *(char *)(puVar3[6] + 0x1cde);
    pcVar4 = *(code **)*puVar3;
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1013ef;
    cVar15 = (*pcVar4)(puVar3);
    if (cVar15 == '\0') {
      if (cVar14 == '\0') {
        if (iVar38 << 0x1f < 0) {
          if ((*(byte *)(plVar23 + 2) & 0x40) == 0) goto code_r0x00101431;
          lVar20 = puVar3[0x1a];
          if (((lVar20 != 0) && (*(char *)(lVar20 + 0x34) != '\0')) &&
             (*(longlong *)(lVar20 + 0x40) != 0)) {
            LOCK();
            lVar24 = *(longlong *)(lVar20 + 0x128);
            if (lVar24 == 0) {
              *(longlong *)(lVar20 + 0x128) = 0;
              lVar24 = 0;
            }
            UNLOCK();
            if (*(longlong *)(*plVar23 + 0x28) != lVar24) goto code_r0x00101431;
          }
        }
      }
      else {
code_r0x00101431:
        lVar20 = *(longlong *)(*(longlong *)(*(longlong *)(lVar21 + 8) + 8) + 0x30);
        if (*(int *)(lVar21 + 0x244) == 0) {
          if (*(int *)(*(longlong *)(lVar20 + 0x6b0) + 0x5ec) == 1) {
            lVar20 = lVar20 + 0x18;
            goto code_r0x0010146a;
          }
        }
        else if (*(int *)(*(longlong *)(lVar20 + 0x6b0) + 0x5ec) == 1) {
          lVar20 = lVar20 + 0x28;
code_r0x0010146a:
          *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10146f;
          plVar23 = (longlong *)func_0x(lVar20);
          *plVar23 = *plVar23 + 1;
        }
      }
    }
  }
  bVar27 = **(byte **)(lVar21 + 0xe0) >> 1;
  if (*(short *)(lVar21 + 0xd8) == 0) {
    bVar27 = **(byte **)(lVar21 + 0xe0) >> 6;
  }
  if ((bVar27 & 1) != 0) {
    uVar32 = *(undefined4 *)(lVar21 + 0x20);
    uVar22 = **(undefined8 **)(lVar21 + 0x28);
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1014b3;
    func_0x(&stack0x00000378 + lVar18,uVar22,uVar32);
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1014bb;
  func_0x(lVar21);
  if (*(short *)((longlong)&uStackX_18 + lVar18 + 8) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1014cb;
    func_0x();
  }
  else {
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1014d2;
    func_0x((longlong)&uStackX_18 + lVar18 + 10);
  }
  lVar21 = *(longlong *)(&stack0x00000080 + lVar18);
  *(longlong *)(&stack0x000000a0 + lVar18) = (longlong)&uStackX_18 + lVar18 + 8;
  if (*(longlong *)(lVar21 + 0x28) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1014f5;
    func_0x(lVar21,0);
  }
  lVar20 = *(longlong *)(lVar21 + 600);
  iVar38 = *(int *)(lVar21 + 0x20);
  *(int *)(&stack0x000002fc + lVar18) = iVar38;
  if (*(char *)(lVar20 + 2) < '\0') {
    pbVar30 = (byte *)(lVar20 + 0x60);
    if ((*(short *)(&stack0x000002c8 + lVar18) == 0) ||
       (ppbVar35 = *(byte ***)(&stack0x000002d8 + lVar18), ppbVar35 == (byte **)0x0)) {
      ppbVar35 = (byte **)(&stack0x00000300 + lVar18);
      *(undefined8 *)(&stack0x00000370 + lVar18) = 0;
      *(undefined (*) [16])(&stack0x00000310 + lVar18) = ZEXT816(0);
      *(undefined8 *)(&stack0x00000318 + lVar18) = 0;
      *(undefined (*) [16])(&stack0x00000320 + lVar18) = ZEXT816(0);
      *(undefined2 *)(&stack0x00000310 + lVar18) = 0xffff;
      *(undefined (*) [16])(&stack0x00000330 + lVar18) = ZEXT816(0);
      *(undefined4 *)(&stack0x00000314 + lVar18) = 0;
      *(undefined (*) [16])(&stack0x00000360 + lVar18) = ZEXT816(0);
      *(undefined8 *)(&stack0x0000032e + lVar18) = 0;
      *(undefined (*) [16])(&stack0x00000340 + lVar18) = ZEXT816(0);
      *(undefined8 *)(&stack0x00000338 + lVar18) = 0;
      *(undefined8 *)(&stack0x00000320 + lVar18) = 0;
      *(undefined8 *)(&stack0x00000348 + lVar18) = 0;
      *(undefined8 *)(&stack0x00000360 + lVar18) = 0;
      *(undefined4 *)(&stack0x00000368 + lVar18) = 0;
      *(undefined2 *)(&stack0x00000372 + lVar18) = 0;
      *(undefined (*) [16])(&stack0x00000350 + lVar18) = ZEXT816(0);
      *(undefined (*) [16])(&stack0x00000300 + lVar18) = ZEXT816(0);
    }
    if (*(short *)(lVar20 + 0x24) == 0) {
code_r0x00101622:
      uVar16 = *(undefined2 *)(lVar20 + 0x30);
      *(undefined8 *)((longlong)&uStackX_8 + lVar18) = *(undefined8 *)(lVar20 + 0x28);
    }
    else {
      cVar14 = *(char *)(lVar20 + 1);
      if (cVar14 == '\v') {
        if (*(int *)(lVar20 + 0x18) != 99) {
code_r0x001015ea:
          if (cVar14 != '\t') goto code_r0x00101622;
          goto code_r0x001015ee;
        }
      }
      else {
        if (cVar14 != '\b') goto code_r0x001015ea;
code_r0x001015ee:
        if (*(int *)(lVar20 + 0x18) != 99) goto code_r0x00101622;
      }
      *(undefined4 *)(&stack0xfffffffffffffffc + lVar18) = *(undefined4 *)(lVar20 + 0x20);
      *(undefined2 *)((longlong)&uStackX_18 + lVar18 + -0x18) = *(undefined2 *)(lVar20 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10160b;
      cVar14 = func_0x(&stack0xfffffffffffffffc + lVar18);
      if (cVar14 == '\0') goto code_r0x00101622;
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10161b;
      func_0x(lVar20,(longlong)&uStackX_8 + lVar18);
      uVar16 = *(undefined2 *)((longlong)auStackX_10 + lVar18);
    }
    uVar32 = *(undefined4 *)((longlong)&uStackX_8 + lVar18);
    *ppbVar35 = pbVar30;
    *(undefined4 *)(ppbVar35 + 0xc) = uVar32;
    uVar22 = *(undefined8 *)((longlong)&uStackX_8 + lVar18);
    *(undefined2 *)(ppbVar35 + 0xd) = uVar16;
    *(int *)((longlong)ppbVar35 + 100) = (int)((ulonglong)uVar22 >> 0x20);
    *(undefined4 *)((longlong)ppbVar35 + 0x6c) = *(undefined4 *)(lVar20 + 0x20);
    *(undefined2 *)(ppbVar35 + 0xe) = *(undefined2 *)(lVar20 + 0x24);
    *(undefined2 *)((longlong)ppbVar35 + 0x72) = 0;
    uVar32 = *(undefined4 *)((ulonglong)*pbVar30 * 6 + 0x16a51e0);
    uVar44 = (ulonglong)*(short *)((ulonglong)*pbVar30 * 6 + 0x16a51e4);
    *(undefined2 *)(ppbVar35 + 2) = 0xffff;
    ppbVar35[3] = (byte *)0x0;
    uVar43 = 0;
    *(undefined4 *)((longlong)ppbVar35 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar35 + 0x2e) = 0;
    ppbVar35[7] = (byte *)0x0;
    ppbVar35[4] = (byte *)0x0;
    ppbVar35[9] = (byte *)0x0;
    ppbVar35[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar35 + 0xb) = 0;
    *(undefined4 *)(&stack0xfffffffffffffffc + lVar18) = uVar32;
    if ((**ppbVar35 & 2) != 0) {
      pbVar1 = pbVar30 + uVar44;
      if ((pbVar30[uVar44] & 1) == 0) {
        *(undefined2 *)(ppbVar35 + 2) = 0;
        ppbVar35[3] = pbVar1;
        *(undefined4 *)((longlong)ppbVar35 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar35 + 0x36) = 0;
        switch(*pbVar1 & 0xe) {
        default:
          uVar43 = (uint)*(ushort *)(pbVar1 + 2);
          if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x101898;
            func_0x(pbVar1,6);
          }
          break;
        case 4:
          uVar43 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar43 = 1;
        }
        *(uint *)(ppbVar35 + 4) = uVar43;
        *(undefined8 *)((longlong)ppbVar35 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar35 + 2) = 1;
        ppbVar35[3] = pbVar1;
        bVar27 = *pbVar1;
        switch(bVar27 & 0x1c) {
        default:
          if ((char)pbVar1[1] < '\0') {
            uVar28 = *(ushort *)(pbVar1 + 1);
            sVar37 = 3;
            *(ushort *)((longlong)ppbVar35 + 0x12) = uVar28;
            uVar28 = (uVar28 & 0x7f) << 8 | uVar28 >> 8;
          }
          else {
            sVar37 = 2;
            uVar28 = (ushort)pbVar1[1];
          }
          *(ushort *)((longlong)ppbVar35 + 0x12) = uVar28;
          *(short *)(ppbVar35 + 5) = sVar37;
          uVar28 = *(ushort *)((longlong)ppbVar35 + 0x12);
          *(short *)((longlong)ppbVar35 + 0x2c) = (short)(uVar28 + 1 >> 1) + sVar37;
          if (uVar28 < 0x1f) {
            *(undefined2 *)((longlong)ppbVar35 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar35 + 0x14) = 0;
            *(undefined4 *)(ppbVar35 + 8) = 0;
            ppbVar35[7] = (byte *)0x0;
            ppbVar35[4] = (byte *)0x0;
          }
          else {
            iVar29 = uVar28 - 1;
            *(short *)((longlong)ppbVar35 + 0x2a) =
                 ((short)(iVar29 / 0x1e) + (short)(iVar29 >> 0x1f)) -
                 (short)((longlong)iVar29 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar35 + 0x14) = 0;
            *(undefined4 *)(ppbVar35 + 8) = 0;
            ppbVar35[7] = (byte *)0x0;
            ppbVar35[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar27 & 0x1c) != 4) || (uVar33 = 1, (bVar27 & 2) == 0)) {
            uVar33 = uVar43;
          }
          if (uVar33 == 0) {
            uVar32 = 1;
          }
          else {
            *(undefined4 *)(ppbVar35 + 8) = 0;
            uVar32 = 0xf;
          }
          ppbVar35[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar35 + 0x12) = 0;
          ppbVar35[6] = (byte *)0x0;
          ppbVar35[4] = (byte *)0x0;
          ppbVar35[7] = (byte *)0x0;
          ppbVar35[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar35 + 0x14) = uVar32;
          *(uint *)(ppbVar35 + 8) = (uint)(uVar33 != 0);
          ppbVar35[7] = (byte *)0x0;
          ppbVar35[4] = (byte *)0x0;
          break;
        case 8:
          ppbVar35[7] = (byte *)0x0;
          ppbVar35[7] = (byte *)0x0;
          ppbVar35[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar35 + 0x12) = 0;
          ppbVar35[6] = (byte *)0x0;
          ppbVar35[4] = (byte *)0x0;
          ppbVar35[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar35 + 0x14) = 9;
          *(undefined4 *)(ppbVar35 + 8) = 0;
          ppbVar35[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar35 & 4) != 0) {
      if (*(short *)(&stack0xfffffffffffffffe + lVar18) != 0) {
        uVar44 = (ulonglong)
                 *(ushort *)
                  (lVar20 + 0x61 + (longlong)*(short *)(&stack0xfffffffffffffffe + lVar18) * 2);
      }
      psVar19 = (short *)(pbVar30 + uVar44);
      ppbVar35[9] = (byte *)psVar19;
      sVar37 = *psVar19;
      ppbVar35[10] = (byte *)(psVar19 + 1);
      *(short *)(ppbVar35 + 0xb) = (sVar37 + 1) * 2;
    }
    pbVar30 = ppbVar35[1];
    if (pbVar30 != (byte *)0x0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x101927;
      func_0x(pbVar30,ppbVar35);
    }
  }
  else {
    ppbVar35 = (byte **)0x0;
  }
  uVar43 = (uint)*(ushort *)(lVar20 + 0xe);
  pbVar30 = (byte *)((ulonglong)*(ushort *)(lVar20 + (0xfff - (longlong)iVar38) * 2) + lVar20);
  bVar27 = *pbVar30;
  *(byte **)(&stack0x000002d0 + lVar18) = pbVar30;
  if ((bVar27 & 1) == 0) {
    *(undefined2 *)(&stack0x000002c8 + lVar18) = 0;
    *(undefined4 *)(&stack0x000002cc + lVar18) = 0;
    *(undefined4 *)(&stack0x000002ee + lVar18) = 0;
    switch(*pbVar30 & 0xe) {
    default:
      uVar43 = (uint)*(ushort *)(pbVar30 + 2);
      if (0x1f9d < *(ushort *)(pbVar30 + 2) - 1) {
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x101bcd;
        func_0x(pbVar30,6);
      }
      break;
    case 4:
      uVar43 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar43 = 1;
    }
    *(uint *)(&stack0x000002d8 + lVar18) = uVar43;
    *(longlong *)(&stack0x000002e6 + lVar18) = lVar20 + 0x2000;
  }
  else {
    *(undefined2 *)(&stack0x000002c8 + lVar18) = 1;
    bVar27 = *pbVar30;
    switch(bVar27 & 0x1c) {
    default:
      if ((char)pbVar30[1] < '\0') {
        uVar28 = (*(ushort *)(pbVar30 + 1) & 0x7f) << 8 | *(ushort *)(pbVar30 + 1) >> 8;
        uVar16 = 3;
        sVar37 = 3;
        *(ushort *)(&stack0x000002ca + lVar18) = uVar28;
      }
      else {
        uVar28 = (ushort)pbVar30[1];
        *(ushort *)(&stack0x000002ca + lVar18) = uVar28;
        uVar16 = 2;
        sVar37 = 2;
      }
      *(undefined2 *)(&stack0x000002e0 + lVar18) = uVar16;
      *(ushort *)(&stack0x000002e4 + lVar18) = ((ushort)(uVar28 + 1) >> 1) + sVar37;
      if (uVar28 < 0x1f) {
        *(undefined2 *)(&stack0x000002e2 + lVar18) = 0;
        *(longlong *)(&stack0x000002f0 + lVar18) = lVar20 + 0x2000;
        *(undefined4 *)(&stack0x000002cc + lVar18) = 0;
        *(undefined4 *)(&stack0x000002f8 + lVar18) = 0;
        *(byte ***)(&stack0x000002d8 + lVar18) = ppbVar35;
      }
      else {
        iVar38 = uVar28 - 1;
        *(undefined4 *)(&stack0x000002cc + lVar18) = 0;
        *(undefined4 *)(&stack0x000002f8 + lVar18) = 0;
        *(byte ***)(&stack0x000002d8 + lVar18) = ppbVar35;
        *(longlong *)(&stack0x000002f0 + lVar18) = lVar20 + 0x2000;
        *(short *)(&stack0x000002e2 + lVar18) =
             ((short)(iVar38 / 0x1e) + (short)(iVar38 >> 0x1f)) -
             (short)((longlong)iVar38 * 0x88888889 >> 0x3f);
      }
      break;
    case 4:
      if (((bVar27 & 0x1c) == 4) && ((bVar27 & 2) != 0)) {
        *(undefined8 *)(&stack0x000002e0 + lVar18) = 0;
        *(longlong *)(&stack0x000002f0 + lVar18) = lVar20 + 0x2000;
        *(undefined2 *)(&stack0x000002ca + lVar18) = 0;
        *(undefined8 *)(&stack0x000002e8 + lVar18) = 0;
        *(undefined4 *)(&stack0x000002cc + lVar18) = 0xf;
        *(undefined4 *)(&stack0x000002f8 + lVar18) = 1;
        *(byte ***)(&stack0x000002d8 + lVar18) = ppbVar35;
      }
      else {
        *(undefined8 *)(&stack0x000002e0 + lVar18) = 0;
        *(longlong *)(&stack0x000002f0 + lVar18) = lVar20 + 0x2000;
        *(undefined2 *)(&stack0x000002ca + lVar18) = 0;
        *(undefined8 *)(&stack0x000002e8 + lVar18) = 0;
        *(undefined4 *)(&stack0x000002cc + lVar18) = 1;
        *(undefined4 *)(&stack0x000002f8 + lVar18) = 0;
        *(byte ***)(&stack0x000002d8 + lVar18) = ppbVar35;
      }
      break;
    case 8:
      *(undefined8 *)(&stack0x000002e0 + lVar18) = 0;
      *(longlong *)(&stack0x000002f0 + lVar18) = lVar20 + 0x2000;
      *(undefined2 *)(&stack0x000002ca + lVar18) = 0;
      *(undefined8 *)(&stack0x000002e8 + lVar18) = 0;
      *(undefined4 *)(&stack0x000002cc + lVar18) = 9;
      *(undefined4 *)(&stack0x000002f8 + lVar18) = 0;
      *(byte ***)(&stack0x000002d8 + lVar18) = ppbVar35;
    }
  }
  uVar22 = 0;
  lVar21 = *(longlong *)(*(longlong *)(&stack0x00000078 + lVar18) + 0x288);
  *(longlong *)(&stack0x00000060 + lVar18) = lVar21;
  puVar36 = &stack0xffffffffffffffc8 + lVar18;
  if (*(char *)(lVar21 + 2) < '\0') {
    puVar42 = (undefined2 *)((longlong)auStack_48 + lVar18);
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0;
    *puVar42 = 0xffff;
    *(undefined4 *)((longlong)&uStack_44 + lVar18) = 0;
    *(undefined8 *)(&stack0xffffffffffffffd6 + lVar18) = 0;
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar18) = 0;
    *(undefined8 *)(&stack0xffffffffffffffc8 + lVar18) = 0;
    *(undefined8 *)((longlong)&uStack_80 + lVar18) = 0x101c7c;
    lVar20 = func_0x();
    lVar20 = -lVar20;
    puVar36 = auStack_f8 + lVar20 + lVar18;
    *(undefined (*) [16])(auStack_c8 + lVar20 + lVar18) = ZEXT816(0);
    *(undefined (*) [16])((longlong)auStack_b8 + lVar20 + lVar18) = ZEXT816(0);
    *(undefined (*) [16])((longlong)&uStack_a8 + lVar20 + lVar18) = ZEXT816(0);
    *(undefined (*) [16])((longlong)&uStack_9a + lVar20 + lVar18 + 2) = ZEXT816(0);
    *(undefined (*) [16])(auStack_88 + lVar20 + lVar18) = ZEXT816(0);
    *(undefined (*) [16])(auStack_78 + lVar20 + lVar18) = ZEXT816(0);
    *(undefined (*) [16])((longlong)&uStack_68 + lVar20 + lVar18) = ZEXT816(0);
    *(undefined8 *)((longlong)&uStack_58 + lVar20 + lVar18) = 0;
    *(undefined2 *)((longlong)auStack_b8 + lVar20 + lVar18) = 0xffff;
    *(undefined8 *)((longlong)&uStack_b0 + lVar20 + lVar18) = uVar22;
    *(int *)((longlong)&uStack_b4 + lVar20 + lVar18) = (int)uVar22;
    *(undefined8 *)((longlong)&uStack_9a + lVar20 + lVar18) = uVar22;
    *(undefined8 *)((longlong)&uStack_90 + lVar20 + lVar18) = uVar22;
    *(undefined8 *)((longlong)&uStack_a8 + lVar20 + lVar18) = uVar22;
    *(undefined8 *)((longlong)&uStack_80 + lVar20 + lVar18) = uVar22;
    *(undefined8 *)((longlong)&uStack_68 + lVar20 + lVar18) = 0;
    *(undefined4 *)((longlong)auStack_60 + lVar20 + lVar18) = 0;
    *(short *)((longlong)&uStack_58 + lVar20 + lVar18 + 2) = (short)uVar22;
    *(longlong *)(&stack0x000000b0 + lVar18) = (longlong)auStack_48 + lVar20 + lVar18;
    *(undefined (**) [16])(&stack0x000000c0 + lVar18) =
         (undefined (*) [16])(auStack_c8 + lVar20 + lVar18);
    *(undefined2 **)(&stack0x000000a8 + lVar18) = puVar42;
    *(undefined4 *)(&stack0x000000b8 + lVar18) = 0x239e;
    *(undefined8 *)((longlong)&uStack_100 + lVar20 + lVar18) = 0x101d0b;
    func_0x(&stack0x000000a0 + lVar18,lVar21);
  }
  pcVar4 = *(code **)(**(longlong **)(&stack0x00000070 + lVar18) + 0x58);
  *(undefined8 *)(puVar36 + -8) = 0x101d15;
  cVar14 = (*pcVar4)();
  iVar38 = 0;
  uVar32 = 0;
  psVar19 = *(short **)(&stack0x000000a8 + lVar18);
  if (cVar14 != '\0') {
    uVar32 = 0x80;
  }
  cVar14 = *(char *)(lVar21 + 2);
  *(undefined4 *)(&stack0xfffffffffffffffc + lVar18) = uVar32;
  if (-1 < cVar14) {
    psVar19 = *(short **)(&stack0x000000a0 + lVar18);
  }
  uVar43 = *(uint *)(psVar19 + 2);
  puVar47 = (ushort *)(psVar19 + 1);
  if (*psVar19 == 0) {
    if (uVar43 == 0) {
      pbVar30 = *(byte **)(psVar19 + 4);
      uVar43 = *(uint *)(psVar19 + 8);
      uVar44 = (ulonglong)uVar43;
      *puVar47 = 0;
      *(uint *)(psVar19 + 10) = uVar43;
      bVar27 = *pbVar30;
      if ((bVar27 & 0x10) != 0) {
        uVar43 = uVar43 + 2 + (*(ushort *)(pbVar30 + uVar44) + 7 >> 3);
        uVar44 = (ulonglong)uVar43;
        *(uint *)(psVar19 + 10) = uVar43;
        bVar27 = *pbVar30;
      }
      iVar29 = (int)uVar44;
      if ((bVar27 & 0x20) == 0) {
        *(int *)(psVar19 + 2) = iVar29;
        psVar19[0xe] = 0;
        *(int *)(psVar19 + 0xc) = iVar29;
      }
      else {
        puVar45 = (ushort *)(pbVar30 + uVar44);
        *(ushort **)(&stack0x00000078 + lVar18) = puVar45;
        uVar28 = *puVar45;
        psVar19[0xe] = uVar28;
        if (uVar28 == 0) {
          *(undefined8 *)(puVar36 + -8) = 0x101db4;
          cVar14 = func_0x(0x1fbb990);
          if (cVar14 != '\0') {
            *(undefined8 *)(puVar36 + -8) = 0x101dbd;
            lVar20 = func_0x();
            if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
              *(undefined8 *)(puVar36 + -8) = 0x101dd7;
              cVar14 = func_0x(0x1fbb990);
              if (cVar14 == '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x101df3;
                (*pcRam0000000001529518)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(puVar36 + 0x20) = 0;
                *(undefined8 *)(puVar36 + -8) = 0x101e16;
                (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x80f);
              }
            }
          }
          uVar22 = *(undefined8 *)(psVar19 + 4);
          *(undefined8 *)(puVar36 + -8) = 0x101e24;
          func_0x(uVar22,3);
          uVar28 = psVar19[0xe];
          iVar29 = *(int *)(psVar19 + 10);
        }
        uVar33 = (uint)uVar28;
        uVar43 = iVar29 + (uVar33 + 1) * 2;
        *(uint *)(psVar19 + 0xc) = uVar43;
        if (0x1f9e < uVar43) {
          *(undefined8 *)(puVar36 + -8) = 0x101e50;
          cVar14 = func_0x(0x1fbb990);
          if (cVar14 != '\0') {
            *(undefined8 *)(puVar36 + -8) = 0x101e59;
            lVar20 = func_0x();
            if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
              *(undefined8 *)(puVar36 + -8) = 0x101e73;
              cVar14 = func_0x(0x1fbb990);
              if (cVar14 == '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x101e8f;
                (*pcRam0000000001529518)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar36 + 0x20) = 0;
                *(undefined8 *)(puVar36 + -8) = 0x101eb2;
                (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x816);
              }
            }
          }
          uVar22 = *(undefined8 *)(psVar19 + 4);
          *(undefined8 *)(puVar36 + -8) = 0x101ec0;
          func_0x(uVar22,4);
          uVar33 = (uint)(ushort)psVar19[0xe];
          uVar43 = *(uint *)(psVar19 + 0xc);
        }
        uVar46 = puVar45[uVar33] & 0x7fff;
        *(uint *)(psVar19 + 2) = uVar46;
        if (uVar46 < uVar43) {
          *(undefined8 *)(puVar36 + -8) = 0x101eef;
          cVar14 = func_0x(0x1fbb990);
          if (cVar14 != '\0') {
            *(undefined8 *)(puVar36 + -8) = 0x101ef8;
            lVar20 = func_0x();
            if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
              *(undefined8 *)(puVar36 + -8) = 0x101f12;
              cVar14 = func_0x(0x1fbb990);
              if (cVar14 == '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x101f2e;
                (*pcRam0000000001529518)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar36 + 0x20) = 0;
                *(undefined8 *)(puVar36 + -8) = 0x101f51;
                (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x81d);
              }
            }
          }
          uVar22 = *(undefined8 *)(psVar19 + 4);
          *(undefined8 *)(puVar36 + -8) = 0x101f5f;
          func_0x(uVar22,4);
          uVar43 = *(uint *)(psVar19 + 0xc);
          uVar33 = (uint)(ushort)psVar19[0xe];
          uVar46 = *(uint *)(psVar19 + 2);
        }
        if ((short)uVar33 != 0) {
          do {
            puVar45 = puVar45 + 1;
            uVar46 = *puVar45 & 0x7fff;
            if ((uVar46 < uVar43) || (*(uint *)(psVar19 + 2) < uVar46)) {
              *(undefined8 *)(puVar36 + -8) = 0x101f9f;
              cVar14 = func_0x(0x1fbb990);
              if (cVar14 != '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x101fa8;
                lVar21 = func_0x();
                if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar36 + -8) = 0x101fc2;
                  cVar14 = func_0x(0x1fbb990);
                  if (cVar14 == '\0') {
                    *(undefined8 *)(puVar36 + -8) = 0x101fde;
                    (*pcRam0000000001529518)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar36 + 0x20) = 0;
                    *(undefined8 *)(puVar36 + -8) = 0x102002;
                    (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x82a);
                  }
                }
              }
              uVar22 = *(undefined8 *)(psVar19 + 4);
              *(undefined8 *)(puVar36 + -8) = 0x102010;
              func_0x(uVar22,4);
            }
            uVar33 = (uint)(ushort)psVar19[0xe];
            iVar38 = iVar38 + 1;
            uVar43 = uVar46;
          } while (iVar38 < (int)uVar33);
          uVar46 = *(uint *)(psVar19 + 2);
          puVar45 = *(ushort **)(&stack0x00000078 + lVar18);
          lVar21 = *(longlong *)(&stack0x00000060 + lVar18);
        }
        uVar44 = (ulonglong)uVar46;
        if ((short)puVar45[(ulonglong)(uVar33 - 1) + 1] < 0) {
code_r0x00102050:
          lVar20 = *(longlong *)(psVar19 + 4);
          lVar24 = (ulonglong)*(uint *)(psVar19 + 10) + lVar20;
          uVar46 = *(ushort *)(lVar24 + (ulonglong)uVar33 * 2) & 0x7fff;
          if (uVar33 == 1) {
            uVar33 = *(uint *)(psVar19 + 0xc);
            uVar41 = uVar33;
code_r0x00102085:
            if ((uVar46 < uVar33) || (uVar43 = *(uint *)(psVar19 + 2), uVar43 < uVar46))
            goto code_r0x00102092;
          }
          else {
            uVar41 = *(uint *)(psVar19 + 0xc);
            uVar33 = *(ushort *)(lVar24 + -2 + (ulonglong)uVar33 * 2) & 0x7fff;
            if (uVar41 <= uVar33) goto code_r0x00102085;
code_r0x00102092:
            *(undefined8 *)(puVar36 + -8) = 0x10209f;
            func_0x(lVar20,7);
            uVar41 = *(uint *)(psVar19 + 0xc);
            uVar43 = *(uint *)(psVar19 + 2);
          }
          uVar44 = (ulonglong)uVar43;
          if ((uVar33 < uVar41) || (uVar43 < uVar33)) goto code_r0x00102429;
          if (*(ushort *)((ulonglong)uVar33 + *(longlong *)(psVar19 + 4)) == 5) {
            *puVar47 = *puVar47 | 2;
            psVar19[0xe] = psVar19[0xe] + -1;
            uVar34 = (ulonglong)(uVar33 & 0xffff);
            uVar44 = uVar34 + *(longlong *)(psVar19 + 4);
            psVar19[0x15] = (short)uVar33;
            uVar28 = psVar19[0x16] & 0xc7ffU;
            if ((*(ushort *)(uVar44 + 2) >> 0xe & 1) != 0) {
              uVar28 = *(ushort *)(uVar44 + 2) & 0x3800 | psVar19[0x16] & 0xc7ffU;
            }
            psVar19[0x16] = uVar28;
            uVar17 = (uVar28 ^ *(ushort *)(uVar44 + 2)) & 0x7ff ^ uVar28;
            psVar19[0x16] = uVar17;
            uVar48 = *(longlong *)(psVar19 + 4) + 4 +
                     (ulonglong)((uVar17 & 0x7ff) * 2) + uVar34 + (uVar28 >> 0xb & 7) * 2;
            if (uVar48 < uVar44) {
              *(undefined8 *)(puVar36 + -8) = 0x1021a2;
              func_0x(uVar44,0x19);
              uVar17 = psVar19[0x16];
              uVar34 = (ulonglong)(ushort)psVar19[0x15];
            }
            uVar43 = (uint)uVar17;
            if (uVar46 - uVar33 <
                (((uVar43 & 0x7ff) * 2 - (int)uVar34) - *(int *)(psVar19 + 4)) + (int)uVar48) {
              lVar20 = *(longlong *)(psVar19 + 4);
              *(undefined8 *)(puVar36 + -8) = 0x1021d7;
              func_0x(uVar34 + lVar20,0x19);
              uVar43 = (uint)(ushort)psVar19[0x16];
            }
            if ((uVar43 & 0x3800) != 0) {
              puVar45 = (ushort *)
                        (*(longlong *)(psVar19 + 4) + (ulonglong)(ushort)psVar19[0x15] + 4);
              iVar38 = 0;
              if ((uVar43 & 0x3800) != 0) {
                do {
                  if (((ushort)uVar43 & 0x7ff) < (*puVar45 & 0x7ff)) {
                    uVar28 = psVar19[0x15];
                    lVar20 = *(longlong *)(psVar19 + 4);
                    *(undefined8 *)(puVar36 + -8) = 0x102237;
                    func_0x((ulonglong)uVar28 + lVar20,0x1a);
                    uVar43 = (uint)(ushort)psVar19[0x16];
                  }
                  iVar38 = iVar38 + 1;
                  puVar45 = puVar45 + 1;
                } while (iVar38 < (int)(uVar43 >> 0xb & 7));
              }
            }
            uVar44 = (ulonglong)*(uint *)(psVar19 + 2);
            pbVar30 = *(byte **)(psVar19 + 4);
            goto code_r0x00102274;
          }
          if (0x3ff < *(ushort *)((ulonglong)uVar33 + *(longlong *)(psVar19 + 4)))
          goto code_r0x001020d3;
        }
code_r0x001020fa:
        pbVar30 = *(byte **)(psVar19 + 4);
      }
code_r0x00102274:
      iVar38 = 0;
      if ((*pbVar30 & 0x40) == 0) {
        *(undefined4 *)(psVar19 + 0x13) = 0;
      }
      else {
        *(int *)(psVar19 + 0x13) = *(int *)(psVar19 + 2);
        *(int *)(psVar19 + 2) = *(int *)(psVar19 + 2) + 0xe;
        *(undefined8 *)(puVar36 + -8) = 0x10228d;
        puVar25 = (ulonglong *)func_0x(puVar47);
        uVar17 = (ushort)(*puVar25 >> 0x30);
        uVar28 = uVar17;
        if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
          uVar28 = uVar17 & 0xdfff;
          if ((uVar17 >> 0xe & 1) != 0) {
            uVar28 = uVar17 | 0x2000;
          }
        }
        if (uVar28 == 0xfffc) {
          iVar38 = (int)((*puVar25 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(psVar19 + 2) = *(int *)(psVar19 + 2) + iVar38;
        uVar44 = (ulonglong)*(uint *)(psVar19 + 2);
      }
      if ((*(ulonglong *)(psVar19 + 0xf) != 0) &&
         (*(ulonglong *)(psVar19 + 0xf) < uVar44 + *(longlong *)(psVar19 + 4))) {
        *(undefined8 *)(puVar36 + -8) = 0x10231d;
        cVar14 = func_0x(0x1fbb990);
        if (cVar14 != '\0') {
          *(undefined8 *)(puVar36 + -8) = 0x102326;
          lVar20 = func_0x();
          if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
            *(undefined8 *)(puVar36 + -8) = 0x102340;
            cVar14 = func_0x(0x1fbb990);
            if (cVar14 == '\0') {
              *(undefined8 *)(puVar36 + -8) = 0x10235c;
              (*pcRam0000000001529518)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(puVar36 + 0x20) = 0;
              *(undefined8 *)(puVar36 + -8) = 0x102382;
              (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x886);
            }
          }
        }
        uVar22 = *(undefined8 *)(psVar19 + 4);
        *(undefined8 *)(puVar36 + -8) = 0x102390;
        func_0x(uVar22,0x12);
        uVar44 = (ulonglong)*(uint *)(psVar19 + 2);
      }
      uVar43 = (uint)uVar44;
      if ((uVar43 == 0) || (0x3f3c < uVar43)) {
        *(undefined8 *)(puVar36 + -8) = 0x1023b2;
        cVar14 = func_0x(0x1fbb990);
        if (cVar14 != '\0') {
          *(undefined8 *)(puVar36 + -8) = 0x1023bb;
          lVar20 = func_0x();
          if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
            *(undefined8 *)(puVar36 + -8) = 0x1023d5;
            cVar14 = func_0x(0x1fbb990);
            if (cVar14 == '\0') {
              *(undefined8 *)(puVar36 + -8) = 0x1023f1;
              (*pcRam0000000001529518)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(puVar36 + 0x20) = 0;
              *(undefined8 *)(puVar36 + -8) = 0x102417;
              (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x88b);
            }
          }
        }
        uVar22 = *(undefined8 *)(psVar19 + 4);
        *(undefined8 *)(puVar36 + -8) = 0x102425;
        func_0x(uVar22,5);
        uVar43 = *(uint *)(psVar19 + 2);
      }
    }
code_r0x00102429:
    if (uVar43 < 9) {
      bVar27 = **(byte **)(psVar19 + 4) & 0xe;
joined_r0x00102461:
      if ((bVar27 == 0) || (bVar27 == 0xc)) {
        uVar43 = 9;
      }
    }
  }
  else {
    if (uVar43 == 0) {
      *(undefined8 *)(puVar36 + -8) = 0x10244d;
      func_0x(puVar47);
      uVar43 = *(uint *)(psVar19 + 2);
    }
    if (uVar43 < 9) {
      bVar27 = **(byte **)(psVar19 + 4) & 0x1c;
      goto joined_r0x00102461;
    }
  }
  iVar38 = (1 << ((byte)*(undefined2 *)(lVar21 + 4) & 2)) + -1;
  *(int *)((longlong)&uStackX_18 + lVar18) = iVar38;
  if (*(short *)(&stack0x000002c8 + lVar18) == 0) {
    uVar44 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
    pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
    if (*(uint *)(&stack0x000002cc + lVar18) == 0) {
      uVar33 = *(uint *)(&stack0x000002d8 + lVar18);
      uVar44 = (ulonglong)uVar33;
      *(uint *)(&stack0x000002dc + lVar18) = uVar33;
      *(undefined2 *)(&stack0x000002ca + lVar18) = 0;
      if ((*pbVar30 & 0x10) != 0) {
        uVar33 = uVar33 + 2 + (*(ushort *)(pbVar30 + uVar44) + 7 >> 3);
        uVar44 = (ulonglong)uVar33;
        *(uint *)(&stack0x000002dc + lVar18) = uVar33;
      }
      if ((*pbVar30 & 0x20) == 0) {
        *(int *)(&stack0x000002cc + lVar18) = (int)uVar44;
        *(undefined2 *)(&stack0x000002e4 + lVar18) = 0;
        *(int *)(&stack0x000002e0 + lVar18) = (int)uVar44;
      }
      else {
        puVar47 = (ushort *)(pbVar30 + uVar44);
        uVar28 = *puVar47;
        *(ushort *)(&stack0x000002e4 + lVar18) = uVar28;
        if (uVar28 == 0) {
          *(undefined8 *)(puVar36 + -8) = 0x102512;
          cVar14 = func_0x(0x1fbb990);
          if (cVar14 != '\0') {
            *(undefined8 *)(puVar36 + -8) = 0x10251b;
            lVar20 = func_0x();
            if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
              *(undefined8 *)(puVar36 + -8) = 0x102535;
              cVar14 = func_0x(0x1fbb990);
              if (cVar14 == '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x102551;
                (*pcRam0000000001529518)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(puVar36 + 0x20) = 0;
                *(undefined8 *)(puVar36 + -8) = 0x102576;
                (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x80f);
              }
            }
          }
          uVar22 = *(undefined8 *)(&stack0x000002d0 + lVar18);
          *(undefined8 *)(puVar36 + -8) = 0x102587;
          func_0x(uVar22,3);
          uVar28 = *(ushort *)(&stack0x000002e4 + lVar18);
          pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
        }
        uVar33 = *(int *)(&stack0x000002dc + lVar18) + 2 + (uint)uVar28 * 2;
        *(uint *)(&stack0x000002e0 + lVar18) = uVar33;
        if (0x1f9e < uVar33) {
          *(undefined8 *)(puVar36 + -8) = 0x1025c6;
          cVar14 = func_0x(0x1fbb990);
          if (cVar14 != '\0') {
            *(undefined8 *)(puVar36 + -8) = 0x1025cf;
            lVar20 = func_0x();
            if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
              *(undefined8 *)(puVar36 + -8) = 0x1025e9;
              cVar14 = func_0x(0x1fbb990);
              if (cVar14 == '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x102605;
                (*pcRam0000000001529518)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar36 + 0x20) = 0;
                *(undefined8 *)(puVar36 + -8) = 0x10262a;
                (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x816);
              }
            }
          }
          uVar22 = *(undefined8 *)(&stack0x000002d0 + lVar18);
          *(undefined8 *)(puVar36 + -8) = 0x10263b;
          func_0x(uVar22,4);
          uVar28 = *(ushort *)(&stack0x000002e4 + lVar18);
          uVar33 = *(uint *)(&stack0x000002e0 + lVar18);
          pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
        }
        uVar34 = (ulonglong)uVar28;
        uVar46 = puVar47[uVar34] & 0x7fff;
        *(uint *)(&stack0x000002cc + lVar18) = uVar46;
        if (uVar46 < uVar33) {
          *(undefined8 *)(puVar36 + -8) = 0x10267b;
          cVar14 = func_0x(0x1fbb990);
          if (cVar14 != '\0') {
            *(undefined8 *)(puVar36 + -8) = 0x102684;
            lVar20 = func_0x();
            if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
              *(undefined8 *)(puVar36 + -8) = 0x10269e;
              cVar14 = func_0x(0x1fbb990);
              if (cVar14 == '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x1026ba;
                (*pcRam0000000001529518)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar36 + 0x20) = 0;
                *(undefined8 *)(puVar36 + -8) = 0x1026df;
                (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x81d);
              }
            }
          }
          uVar22 = *(undefined8 *)(&stack0x000002d0 + lVar18);
          *(undefined8 *)(puVar36 + -8) = 0x1026f0;
          func_0x(uVar22,4);
          uVar34 = (ulonglong)*(ushort *)(&stack0x000002e4 + lVar18);
          uVar33 = *(uint *)(&stack0x000002e0 + lVar18);
          pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
          uVar46 = *(uint *)(&stack0x000002cc + lVar18);
        }
        uVar44 = (ulonglong)uVar46;
        iVar29 = 0;
        puVar45 = puVar47;
        if ((short)uVar34 != 0) {
          do {
            uVar46 = puVar45[1] & 0x7fff;
            if ((uVar46 < uVar33) || ((uint)uVar44 < uVar46)) {
              *(undefined8 *)(puVar36 + -8) = 0x102753;
              cVar14 = func_0x(0x1fbb990);
              if (cVar14 != '\0') {
                *(undefined8 *)(puVar36 + -8) = 0x10275c;
                lVar21 = func_0x();
                if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar36 + -8) = 0x102776;
                  cVar14 = func_0x(0x1fbb990);
                  if (cVar14 == '\0') {
                    *(undefined8 *)(puVar36 + -8) = 0x102792;
                    (*pcRam0000000001529518)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar36 + 0x20) = 0;
                    *(undefined8 *)(puVar36 + -8) = 0x1027b6;
                    (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x82a);
                  }
                }
              }
              uVar22 = *(undefined8 *)(&stack0x000002d0 + lVar18);
              *(undefined8 *)(puVar36 + -8) = 0x1027c7;
              func_0x(uVar22,4);
              uVar34 = (ulonglong)*(ushort *)(&stack0x000002e4 + lVar18);
              pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
              uVar44 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
            }
            iVar29 = iVar29 + 1;
            puVar45 = puVar45 + 1;
            uVar33 = uVar46;
          } while (iVar29 < (int)uVar34);
          uVar33 = *(uint *)(&stack0x000002e0 + lVar18);
          iVar38 = *(int *)((longlong)&uStackX_18 + lVar18);
          lVar21 = *(longlong *)(&stack0x00000060 + lVar18);
        }
        while( true ) {
          sVar37 = (short)uVar34;
          iVar29 = (int)uVar34;
          if (-1 < (short)puVar47[(ulonglong)(iVar29 - 1) + 1]) break;
          uVar46 = uVar33;
          if (iVar29 != 1) {
            uVar46 = *(ushort *)
                      (pbVar30 +
                      (longlong)iVar29 * 2 + ((ulonglong)*(uint *)(&stack0x000002dc + lVar18) - 2))
                     & 0x7fff;
          }
          uVar41 = *(ushort *)
                    (pbVar30 + uVar34 * 2 + (ulonglong)*(uint *)(&stack0x000002dc + lVar18)) &
                   0x7fff;
          if (((uVar46 < uVar33) || (uVar41 < uVar46)) || ((uint)uVar44 < uVar41)) {
            *(undefined8 *)(puVar36 + -8) = 0x10286d;
            func_0x(pbVar30,7);
            sVar37 = *(short *)(&stack0x000002e4 + lVar18);
            uVar33 = *(uint *)(&stack0x000002e0 + lVar18);
            pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
            uVar44 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
          }
          if ((uVar46 < uVar33) || ((uint)uVar44 < uVar46)) goto code_r0x00102c89;
          if (*(ushort *)(pbVar30 + uVar46) == 5) {
            *(ushort *)(&stack0x000002ca + lVar18) = *(ushort *)(&stack0x000002ca + lVar18) | 2;
            uVar28 = *(ushort *)(&stack0x000002f4 + lVar18);
            uVar34 = (ulonglong)(uVar46 & 0xffff);
            pbVar1 = pbVar30 + uVar34;
            *(short *)(&stack0x000002e4 + lVar18) = sVar37 + -1;
            *(short *)(&stack0x000002f2 + lVar18) = (short)uVar46;
            if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
              uVar28 = uVar28 & 0xc7ff;
            }
            else {
              uVar28 = uVar28 ^ (*(ushort *)(pbVar1 + 2) ^ uVar28) & 0x3800;
            }
            *(ushort *)(&stack0x000002f4 + lVar18) = uVar28;
            uVar17 = (uVar28 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar28;
            *(ushort *)(&stack0x000002f4 + lVar18) = uVar17;
            pbVar39 = pbVar30 + uVar34 + (ulonglong)((uVar17 & 0x7ff) * 2) + 4 +
                                         (ulonglong)((uVar28 >> 0xb & 7) * 2);
            if (pbVar39 < pbVar1) {
              *(undefined8 *)(puVar36 + -8) = 0x102a19;
              func_0x(pbVar1,0x19);
              uVar17 = *(ushort *)(&stack0x000002f4 + lVar18);
              pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
              uVar44 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
              uVar34 = (ulonglong)*(ushort *)(&stack0x000002f2 + lVar18);
            }
            if (uVar41 - uVar46 <
                (((*(uint *)(&stack0x000002f4 + lVar18) & 0x7ff) * 2 - (int)uVar34) -
                *(int *)(&stack0x000002d0 + lVar18)) + (int)pbVar39) {
              *(undefined8 *)(puVar36 + -8) = 0x102a67;
              func_0x(pbVar30 + uVar34,0x19);
              uVar17 = *(ushort *)(&stack0x000002f4 + lVar18);
              pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
              uVar44 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
              uVar34 = (ulonglong)*(ushort *)(&stack0x000002f2 + lVar18);
            }
            iVar29 = 0;
            if (((uVar17 & 0x3800) != 0) &&
               (puVar47 = (ushort *)(pbVar30 + uVar34 + 4), (uVar17 & 0x3800) != 0)) {
              do {
                if ((uVar17 & 0x7ff) < (*puVar47 & 0x7ff)) {
                  *(undefined8 *)(puVar36 + -8) = 0x102ae2;
                  func_0x(pbVar30 + uVar34,0x1a);
                  uVar17 = *(ushort *)(&stack0x000002f4 + lVar18);
                  pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
                  uVar34 = (ulonglong)*(ushort *)(&stack0x000002f2 + lVar18);
                }
                iVar29 = iVar29 + 1;
                puVar47 = puVar47 + 1;
              } while (iVar29 < (int)(*(uint *)(&stack0x000002f4 + lVar18) >> 0xb & 7));
              uVar44 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
            }
            break;
          }
          if (*(ushort *)(pbVar30 + uVar46) < 0x400) break;
          *(ushort *)(&stack0x000002ca + lVar18) = *(ushort *)(&stack0x000002ca + lVar18) | 1;
          uVar28 = sVar37 - 1;
          uVar34 = (ulonglong)uVar28;
          *(ushort *)(&stack0x000002e4 + lVar18) = uVar28;
          if (uVar28 == 0) break;
        }
      }
      iVar29 = 0;
      if ((*pbVar30 & 0x40) == 0) {
        *(undefined4 *)(&stack0x000002ee + lVar18) = 0;
      }
      else {
        *(int *)(&stack0x000002ee + lVar18) = (int)uVar44;
        *(int *)(&stack0x000002cc + lVar18) = (int)uVar44 + 0xe;
        *(undefined8 *)(puVar36 + -8) = 0x102900;
        puVar25 = (ulonglong *)func_0x(&stack0x000002ca + lVar18);
        uVar17 = (ushort)(*puVar25 >> 0x30);
        uVar28 = uVar17;
        if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
          uVar28 = uVar17 & 0xdfff;
          if ((uVar17 >> 0xe & 1) != 0) {
            uVar28 = uVar17 | 0x2000;
          }
        }
        if (uVar28 == 0xfffc) {
          iVar29 = (int)((*puVar25 >> 0x20 & 0xffff) >> 5);
        }
        pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
        uVar44 = (ulonglong)(uint)(*(int *)(&stack0x000002cc + lVar18) + iVar29);
        *(int *)(&stack0x000002cc + lVar18) = *(int *)(&stack0x000002cc + lVar18) + iVar29;
      }
      if ((*(byte **)(&stack0x000002e6 + lVar18) != (byte *)0x0) &&
         (*(byte **)(&stack0x000002e6 + lVar18) < pbVar30 + uVar44)) {
        *(undefined8 *)(puVar36 + -8) = 0x102b6c;
        cVar14 = func_0x(0x1fbb990);
        if (cVar14 != '\0') {
          *(undefined8 *)(puVar36 + -8) = 0x102b75;
          lVar20 = func_0x();
          if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
            *(undefined8 *)(puVar36 + -8) = 0x102b8f;
            cVar14 = func_0x(0x1fbb990);
            if (cVar14 == '\0') {
              *(undefined8 *)(puVar36 + -8) = 0x102bab;
              (*pcRam0000000001529518)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(puVar36 + 0x20) = 0;
              *(undefined8 *)(puVar36 + -8) = 0x102bce;
              (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x886);
            }
          }
        }
        uVar22 = *(undefined8 *)(&stack0x000002d0 + lVar18);
        *(undefined8 *)(puVar36 + -8) = 0x102bdf;
        func_0x(uVar22,0x12);
        pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
        uVar44 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
      }
      if (0x3f3b < (int)uVar44 - 1U) {
        *(undefined8 *)(puVar36 + -8) = 0x102c08;
        cVar14 = func_0x(0x1fbb990);
        if (cVar14 != '\0') {
          *(undefined8 *)(puVar36 + -8) = 0x102c11;
          lVar20 = func_0x();
          if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
            *(undefined8 *)(puVar36 + -8) = 0x102c2b;
            cVar14 = func_0x(0x1fbb990);
            if (cVar14 == '\0') {
              *(undefined8 *)(puVar36 + -8) = 0x102c47;
              (*pcRam0000000001529518)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(puVar36 + 0x20) = 0;
              *(undefined8 *)(puVar36 + -8) = 0x102c6a;
              (*pcRam0000000001529510)(1,0x18ab39c,0x19cb488,0x88b);
            }
          }
        }
        uVar22 = *(undefined8 *)(&stack0x000002d0 + lVar18);
        *(undefined8 *)(puVar36 + -8) = 0x102c7b;
        func_0x(uVar22,5);
        pbVar30 = *(byte **)(&stack0x000002d0 + lVar18);
        uVar44 = (ulonglong)*(uint *)(&stack0x000002cc + lVar18);
      }
    }
code_r0x00102c89:
    if ((8 < (uint)uVar44) || (((*pbVar30 & 0xe) != 0 && ((*pbVar30 & 0xe) != 0xc)))) {
      *(uint *)((longlong)&uStackX_18 + lVar18 + -0x14) = (uint)uVar44;
    }
  }
  else {
    uVar33 = *(uint *)(&stack0x000002cc + lVar18);
    if (uVar33 == 0) {
      *(undefined8 *)(puVar36 + -8) = 0x102cbc;
      func_0x(&stack0x000002ca + lVar18);
      uVar33 = *(uint *)(&stack0x000002cc + lVar18);
    }
    if ((uVar33 < 9) &&
       (((**(byte **)(&stack0x000002d0 + lVar18) & 0x1c) == 0 ||
        ((**(byte **)(&stack0x000002d0 + lVar18) & 0x1c) == 0xc)))) {
      *(undefined4 *)((longlong)&uStackX_18 + lVar18 + -0x14) = 9;
    }
    else {
      *(uint *)((longlong)&uStackX_18 + lVar18 + -0x14) = uVar33;
    }
  }
  sVar37 = 1 << ((byte)*(undefined2 *)(lVar21 + 4) & 2);
  iVar38 = (iVar38 + uVar43 & 0xffff & (uint)(ushort)~(ushort)iVar38) -
           (uint)(ushort)((short)*(undefined4 *)((longlong)&uStackX_18 + lVar18 + -0x14) + -1 +
                          sVar37 & -sVar37);
  if (iVar38 < 0) {
code_r0x00102d6d:
    lVar21 = *(longlong *)(&stack0x00000070 + lVar18);
    *(undefined8 *)(puVar36 + -8) = 0x102d80;
    func_0x(&stack0x00000378 + lVar18,lVar21);
    puVar40 = *(undefined4 **)(&stack0x00000088 + lVar18);
    lVar20 = 2;
    puVar26 = puVar40;
    puVar31 = (undefined4 *)(&stack0x000000c8 + lVar18);
    do {
      uVar32 = puVar26[1];
      uVar6 = puVar26[2];
      uVar7 = puVar26[3];
      uVar8 = puVar26[4];
      uVar9 = puVar26[5];
      uVar10 = puVar26[6];
      uVar11 = puVar26[7];
      *puVar31 = *puVar26;
      puVar31[1] = uVar32;
      puVar31[2] = uVar6;
      puVar31[3] = uVar7;
      uVar32 = puVar26[8];
      uVar6 = puVar26[9];
      uVar7 = puVar26[10];
      uVar12 = puVar26[0xb];
      puVar31[4] = uVar8;
      puVar31[5] = uVar9;
      puVar31[6] = uVar10;
      puVar31[7] = uVar11;
      uVar8 = puVar26[0xc];
      uVar9 = puVar26[0xd];
      uVar10 = puVar26[0xe];
      uVar11 = puVar26[0xf];
      puVar31[8] = uVar32;
      puVar31[9] = uVar6;
      puVar31[10] = uVar7;
      puVar31[0xb] = uVar12;
      uVar32 = puVar26[0x10];
      uVar6 = puVar26[0x11];
      uVar7 = puVar26[0x12];
      uVar12 = puVar26[0x13];
      puVar31[0xc] = uVar8;
      puVar31[0xd] = uVar9;
      puVar31[0xe] = uVar10;
      puVar31[0xf] = uVar11;
      uVar9 = puVar26[0x14];
      uVar10 = puVar26[0x15];
      uVar11 = puVar26[0x16];
      uVar13 = puVar26[0x17];
      puVar31[0x10] = uVar32;
      puVar31[0x11] = uVar6;
      puVar31[0x12] = uVar7;
      puVar31[0x13] = uVar12;
      uVar32 = puVar26[0x18];
      uVar6 = puVar26[0x19];
      uVar7 = puVar26[0x1a];
      uVar8 = puVar26[0x1b];
      puVar31[0x14] = uVar9;
      puVar31[0x15] = uVar10;
      puVar31[0x16] = uVar11;
      puVar31[0x17] = uVar13;
      uVar9 = puVar26[0x1c];
      uVar10 = puVar26[0x1d];
      uVar11 = puVar26[0x1e];
      uVar12 = puVar26[0x1f];
      puVar26 = puVar26 + 0x20;
      puVar31[0x18] = uVar32;
      puVar31[0x19] = uVar6;
      puVar31[0x1a] = uVar7;
      puVar31[0x1b] = uVar8;
      puVar31[0x1c] = uVar9;
      puVar31[0x1d] = uVar10;
      puVar31[0x1e] = uVar11;
      puVar31[0x1f] = uVar12;
      lVar20 = lVar20 + -1;
      puVar31 = puVar31 + 0x20;
    } while (lVar20 != 0);
    uVar22 = *(undefined8 *)(&stack0x00000080 + lVar18);
    *(undefined8 *)(puVar36 + 0x20) = *(undefined8 *)(&stack0x00000098 + lVar18);
    *(undefined8 *)(puVar36 + -8) = 0x102e1b;
    func_0x(uVar22,&stack0x000000a0 + lVar18,&stack0x000000c8 + lVar18);
    uVar32 = *(undefined4 *)(&stack0x00000058 + lVar18);
    *(undefined8 *)(puVar36 + -8) = 0x102e2d;
    func_0x(uVar22,uVar32,&stack0x000003a8 + lVar18);
    *(undefined8 *)(puVar36 + -8) = 0x102e35;
    func_0x(uVar22);
    lVar20 = 2;
    puVar26 = puVar40;
    puVar31 = (undefined4 *)(&stack0x000001c8 + lVar18);
    do {
      uVar32 = puVar26[1];
      uVar6 = puVar26[2];
      uVar7 = puVar26[3];
      uVar8 = puVar26[4];
      uVar9 = puVar26[5];
      uVar10 = puVar26[6];
      uVar11 = puVar26[7];
      *puVar31 = *puVar26;
      puVar31[1] = uVar32;
      puVar31[2] = uVar6;
      puVar31[3] = uVar7;
      uVar32 = puVar26[8];
      uVar6 = puVar26[9];
      uVar7 = puVar26[10];
      uVar12 = puVar26[0xb];
      puVar31[4] = uVar8;
      puVar31[5] = uVar9;
      puVar31[6] = uVar10;
      puVar31[7] = uVar11;
      uVar8 = puVar26[0xc];
      uVar9 = puVar26[0xd];
      uVar10 = puVar26[0xe];
      uVar11 = puVar26[0xf];
      puVar31[8] = uVar32;
      puVar31[9] = uVar6;
      puVar31[10] = uVar7;
      puVar31[0xb] = uVar12;
      uVar32 = puVar26[0x10];
      uVar6 = puVar26[0x11];
      uVar7 = puVar26[0x12];
      uVar12 = puVar26[0x13];
      puVar31[0xc] = uVar8;
      puVar31[0xd] = uVar9;
      puVar31[0xe] = uVar10;
      puVar31[0xf] = uVar11;
      uVar9 = puVar26[0x14];
      uVar10 = puVar26[0x15];
      uVar11 = puVar26[0x16];
      uVar13 = puVar26[0x17];
      puVar31[0x10] = uVar32;
      puVar31[0x11] = uVar6;
      puVar31[0x12] = uVar7;
      puVar31[0x13] = uVar12;
      uVar32 = puVar26[0x18];
      uVar6 = puVar26[0x19];
      uVar7 = puVar26[0x1a];
      uVar8 = puVar26[0x1b];
      puVar31[0x14] = uVar9;
      puVar31[0x15] = uVar10;
      puVar31[0x16] = uVar11;
      puVar31[0x17] = uVar13;
      uVar9 = puVar26[0x1c];
      uVar10 = puVar26[0x1d];
      uVar11 = puVar26[0x1e];
      uVar12 = puVar26[0x1f];
      puVar26 = puVar26 + 0x20;
      puVar31[0x18] = uVar32;
      puVar31[0x19] = uVar6;
      puVar31[0x1a] = uVar7;
      puVar31[0x1b] = uVar8;
      puVar31[0x1c] = uVar9;
      puVar31[0x1d] = uVar10;
      puVar31[0x1e] = uVar11;
      puVar31[0x1f] = uVar12;
      lVar20 = lVar20 + -1;
      puVar31 = puVar31 + 0x20;
    } while (lVar20 != 0);
    plVar23 = *(longlong **)(&stack0x00000068 + lVar18);
    *(undefined8 *)(puVar36 + 0x20) = 0;
    *(undefined8 *)(puVar36 + -8) = 0x102eaa;
    func_0x(plVar23,0,&stack0x000001c8 + lVar18,0);
    *(undefined8 *)(puVar36 + -8) = 0x102eb9;
    func_0x(&stack0x000003a8 + lVar18,lVar21);
    *(undefined8 *)(puVar36 + -8) = 0x102ec6;
    func_0x(plVar23,0,0);
    if ((plVar23[2] != CONCAT44(uRam0000000001fe743c,uRam0000000001fe7438)) ||
       (plVar23[3] != CONCAT44(uRam0000000001fe7444,uRam0000000001fe7440))) {
      if ((*(byte *)(plVar23 + 0xe) & 2) != 0) {
        *(undefined8 *)(puVar36 + -8) = 0x102ef3;
        iVar38 = func_0x(plVar23 + 0xf);
        if (iVar38 != 0) {
          *(longlong *)(*plVar23 + 0x30) = *(longlong *)(*plVar23 + 0x30) + -1;
        }
      }
      *(undefined *)(plVar23 + 0xe) = 0;
      *(undefined4 *)((longlong)plVar23 + 0x6c) = 0;
      *(undefined4 *)(plVar23 + 0x11) = 0;
      if ((*(byte *)(plVar23 + 0x14) & 2) != 0) {
        *(undefined8 *)(puVar36 + -8) = 0x102f22;
        iVar38 = func_0x(plVar23 + 0x15);
        if (iVar38 != 0) {
          *(longlong *)(*plVar23 + 0x30) = *(longlong *)(*plVar23 + 0x30) + -1;
        }
      }
      *(undefined *)(plVar23 + 0x14) = 0;
      *(undefined4 *)((longlong)plVar23 + 0x9c) = 0;
      *(undefined4 *)(plVar23 + 0x17) = 0;
      if (plVar23[5] != 0) {
        *(undefined *)((longlong)plVar23 + 0x36) = 0;
        plVar23[5] = 0;
        *(undefined2 *)((longlong)plVar23 + 0x34) = 0;
        *(undefined4 *)(plVar23[2] + 0x48) = 0;
      }
      uVar22 = *(undefined8 *)*plVar23;
      *(undefined8 *)(puVar36 + -8) = 0x102f6c;
      func_0x(uVar22,plVar23 + 2);
      uVar8 = uRam0000000001fe7444;
      uVar7 = uRam0000000001fe7440;
      uVar6 = uRam0000000001fe743c;
      uVar32 = uRam0000000001fe7438;
      *(undefined4 *)(plVar23 + 0x4e) = 0xffffffff;
      *(undefined4 *)(plVar23 + 4) = 0xffffffff;
      *(undefined4 *)(plVar23 + 2) = uVar32;
      *(undefined4 *)((longlong)plVar23 + 0x14) = uVar6;
      *(undefined4 *)(plVar23 + 3) = uVar7;
      *(undefined4 *)((longlong)plVar23 + 0x1c) = uVar8;
      *(undefined4 *)(plVar23 + 0x48) = 0;
      plVar23[0x4b] = 0;
      plVar23[0x4a] = 0;
      plVar23[0x4c] = 0;
      *(undefined2 *)((longlong)plVar23 + 0x274) = 0xffff;
      *(undefined8 *)((longlong)plVar23 + 0x276) = 0;
      *(undefined4 *)(plVar23 + 0x18) = 2;
    }
  }
  else {
    piVar5 = *(int **)(&stack0x00000090 + lVar18);
    if (piVar5 == (int *)0x0) {
      uVar43 = (uint)*(ushort *)(lVar21 + 0x1c);
    }
    else {
      uVar43 = (uint)*(ushort *)(lVar21 + 0x26);
      if (((*(short *)(piVar5 + 1) == *(short *)(lVar21 + 0x38)) &&
          (*piVar5 == *(int *)(lVar21 + 0x34))) &&
         (*(int *)(&stack0xfffffffffffffffc + lVar18) == 0)) {
        uVar43 = (uint)*(ushort *)(lVar21 + 0x26) - (uint)*(ushort *)(lVar21 + 0x32);
      }
      if (uVar43 < *(ushort *)(lVar21 + 0x1c)) {
        uVar43 = *(ushort *)(lVar21 + 0x1c) - uVar43;
      }
      else {
        uVar43 = 0;
      }
    }
    if (iVar38 <= (int)uVar43) goto code_r0x00102d6d;
    puVar40 = *(undefined4 **)(&stack0x00000088 + lVar18);
    lVar21 = *(longlong *)(&stack0x00000070 + lVar18);
  }
  bVar27 = (*pbVar2 ^ *(byte *)puVar40) & 4 ^ *(byte *)puVar40;
  *(byte *)puVar40 = (bVar27 ^ *pbVar2) & 1 ^ bVar27;
  plVar23 = (longlong *)(*(longlong *)(lVar21 + 0x30) + 0x198);
  *plVar23 = *plVar23 + 1;
LAB_:
  uVar44 = *(ulonglong *)(&stack0x00002378 + lVar18);
  *(undefined8 *)(puVar36 + -8) = 0x102ffc;
  func_0x(uVar44 ^ (ulonglong)pbVar2);
  return;
code_r0x001020d3:
  *puVar47 = *puVar47 | 1;
  uVar28 = psVar19[0xe] - 1;
  psVar19[0xe] = uVar28;
  if ((uVar28 == 0) || (uVar33 = (uint)uVar28, -1 < (short)puVar45[(ulonglong)(uVar28 - 1) + 1]))
  goto code_r0x001020fa;
  goto code_r0x00102050;
}

