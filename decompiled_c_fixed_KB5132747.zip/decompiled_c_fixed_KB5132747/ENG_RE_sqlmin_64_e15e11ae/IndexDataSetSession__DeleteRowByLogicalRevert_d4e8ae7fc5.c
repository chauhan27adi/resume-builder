
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,byte *param_2)

{
  byte bVar1;
  longlong lVar2;
  code *UNRECOVERED_JUMPTABLE;
  undefined in_stack_00000048;
  undefined auStack_1fd8 [8096];
  ulonglong uStack_38;
  undefined8 uStack_30;
  
  uStack_30 = 0x10002a;
  lVar2 = func_0x();
  lVar2 = -lVar2;
  uStack_38 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffd8 + lVar2);
  (&stack0x00000038)[lVar2] = in_stack_00000048;
  *(undefined8 *)((longlong)&uStack_30 + lVar2) = 0x1000a6;
  func_0x(auStack_1fd8,0,0x1f9e);
  bVar1 = *param_2;
  if ((bVar1 & 1) != 0) {
    UNRECOVERED_JUMPTABLE =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(bVar1 & 0x1c) + 0x1019b0) * 4 +
                           0x1019a0) - 0xf6d0a0);
                    /* WARNING: Could not emulate address calculation at 0x00100113 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
    return;
  }
  lVar2 = (longlong)(int)(bVar1 & 0xe);
                    /* WARNING: Could not emulate address calculation at 0x00100259 */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((ulonglong)*(uint *)(lVar2 * 4 + 0x1019d0) - 0xf6d0a0))
            (lVar2,0xffffffffff092f60,0x15ad490,2);
  return;
}

