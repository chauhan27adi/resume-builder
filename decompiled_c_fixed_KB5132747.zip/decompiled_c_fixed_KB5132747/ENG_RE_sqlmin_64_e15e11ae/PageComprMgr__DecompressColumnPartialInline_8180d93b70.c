
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint * FUN_(byte **param_1,undefined (*param_2) [16],uint *param_3,uint param_4,
                   uint *param_5,uint param_6,uint *param_7,uint param_8)

{
  ushort *puVar1;
  longlong *plVar2;
  ushort *puVar3;
  bool bVar4;
  byte bVar5;
  char cVar6;
  ushort uVar7;
  int iVar8;
  longlong lVar9;
  undefined8 uVar10;
  ulonglong uVar11;
  uint *puVar12;
  uint uVar13;
  byte *pbVar14;
  ushort uVar15;
  short sVar16;
  byte *pbVar17;
  uint *puVar18;
  ushort *puVar19;
  uint uVar20;
  uint uVar21;
  uint *puVar22;
  uint auStackX_10 [2];
  undefined auStackX_18 [16];
  undefined auStack_58 [8];
  undefined auStack_50 [6];
  byte bStack_4a;
  uint *puStack_48;
  
  puVar12 = (uint *)0x0;
  bVar4 = false;
  if ((param_8 & 4) == 0) {
    *param_7 = param_4;
    puVar22 = param_3;
  }
  else {
    bVar5 = *(byte *)param_3;
    puVar1 = (ushort *)param_1[10];
    if (bVar5 == 0) {
      *param_7 = (uint)*puVar1 - (uint)*(ushort *)(param_1 + 0xb);
      uVar15 = *(ushort *)(param_1 + 0xb);
    }
    else {
      *param_7 = (uint)puVar1[bVar5] - (uint)puVar1[(ulonglong)bVar5 - 1];
      uVar15 = *(ushort *)(param_1[10] + (ulonglong)bVar5 * 2 + -2);
    }
    puVar22 = (uint *)(param_1[9] + uVar15);
  }
  puVar18 = puVar12;
  if (((*param_2)[6] & 0x10) != 0) {
    puVar18 = (uint *)(*(longlong *)(*param_2 + 8) + 4);
  }
  if ((param_3 == puVar18) || ((**param_1 & 2) == 0)) {
    return puVar22;
  }
  _auStack_50 = *param_2;
  uVar15 = SUB162(_auStack_50,6);
  if ((SUB168(_auStack_50,0) >> 0x30 & 0x10) != 0) {
    uVar15 = uVar15 & 0xffef;
    _auStack_50 = SUB168(_auStack_50,0) & 0xffefffffffffffff;
    puStack_48 = (uint *)0x0;
  }
  if (param_1[1] != (byte *)0x0) {
    puVar18 = (uint *)func_0x(param_1[1] + 0x18,auStack_50,&param_8);
    goto LAB_;
  }
  puVar1 = (ushort *)((longlong)param_1 + 0x12);
  if (*(short *)(param_1 + 2) != 0) {
    auStackX_10[0] = 0;
    puVar18 = (uint *)func_0x(puVar1,auStack_50,uVar15,&param_8,auStackX_10);
    if ((((*(short *)(param_1 + 2) != 0) &&
         (plVar2 = (longlong *)param_1[4], plVar2 != (longlong *)0x0)) && (*plVar2 != 0)) &&
       (((_auStack_50 & (undefined  [16])0x8000000000000) == (undefined  [16])0x0 &&
        ((auStackX_10[0] & 1) == 0)))) {
      if ((puVar18 == (uint *)0x0) || (puVar18 == (uint *)0x16ed360)) {
        param_8 = 0;
        puVar18 = puVar12;
      }
      else {
        puVar18 = (uint *)FUN_(plVar2,auStack_50,puVar18,param_8,0,0,&param_8,auStackX_10[0]
                                      );
      }
    }
    goto LAB_;
  }
  if ((auStack_50._0_4_ & 0xc0000000) == 0x80000000) {
    iVar8 = func_0x(puVar1);
    if (iVar8 == 0) {
      param_8 = 0;
      puVar18 = (uint *)0x0;
    }
    else {
      puVar18 = (uint *)func_0x((longlong)param_1 + 0x3a,auStack_50,&param_8,auStackX_18);
    }
    goto LAB_;
  }
  pbVar17 = param_1[3];
  bVar5 = *pbVar17;
  if ((bVar5 & 0x10) == 0) {
    if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
      uVar15 = ~(uVar15 >> 4);
      goto LAB_;
    }
  }
  else {
    uVar21 = *(uint *)(param_1 + 4);
    if ((int)auStack_50._0_4_ < (int)uVar21) {
      if ((uint)*(ushort *)(pbVar17 + uVar21) < (uint)(ushort)auStack_50._4_2_) {
        uVar15 = ~(uVar15 >> 4);
      }
      else {
        uVar13 = (ushort)auStack_50._4_2_ - 1;
        bVar4 = true;
        uVar15 = (ushort)(pbVar17[(ulonglong)(uVar13 >> 3) + (ulonglong)uVar21 + 2] >>
                         ((byte)uVar13 & 7));
      }
    }
    else {
      uVar15 = ~(uVar15 >> 4);
    }
LAB_:
    if ((uVar15 & 1) != 0) {
      param_8 = 0;
      puVar18 = puVar12;
      goto LAB_;
    }
    if ((!bVar4) && ((_auStack_50 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0)) {
      param_8 = *puStack_48;
      puVar18 = puStack_48 + 1;
      goto LAB_;
    }
  }
  if (-1 < (int)auStack_50._0_4_) {
    if ((_auStack_50 & (undefined  [16])0x8000000000000) != (undefined  [16])0x0) {
      param_8 = 1;
      puVar18 = (uint *)0x16ed360;
      if ((pbVar17[(int)auStack_50._0_4_] & (byte)(1 << (bStack_4a & 7))) == 0) {
        puVar18 = (uint *)0x16ed361;
      }
      goto LAB_;
    }
    if ((_auStack_50 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0) {
      if ((bVar5 & 0x10) == 0) {
        if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) goto LAB_;
      }
      else {
        if ((int)*(uint *)(param_1 + 4) <= (int)auStack_50._0_4_) goto LAB_;
        if (*(ushort *)(pbVar17 + *(uint *)(param_1 + 4)) < (ushort)auStack_50._4_2_) {
          param_8 = *puStack_48;
          puVar18 = puStack_48 + 1;
          goto LAB_;
        }
      }
    }
    param_8 = 0;
    puVar18 = (uint *)(pbVar17 + (int)auStack_50._0_4_);
    goto LAB_;
  }
  if (*(int *)((longlong)param_1 + 0x14) == 0) {
    uVar21 = *(uint *)(param_1 + 4);
    uVar11 = (ulonglong)uVar21;
    *(uint *)((longlong)param_1 + 0x24) = uVar21;
    *puVar1 = 0;
    bVar5 = *pbVar17;
    if ((bVar5 & 0x10) != 0) {
      uVar21 = uVar21 + 2 + (*(ushort *)(pbVar17 + uVar11) + 7 >> 3);
      uVar11 = (ulonglong)uVar21;
      *(uint *)((longlong)param_1 + 0x24) = uVar21;
      bVar5 = *pbVar17;
    }
    if ((bVar5 & 0x20) == 0) {
      *(int *)((longlong)param_1 + 0x14) = (int)uVar11;
      *(undefined2 *)((longlong)param_1 + 0x2c) = 0;
      *(int *)(param_1 + 5) = (int)uVar11;
    }
    else {
      puVar19 = (ushort *)(pbVar17 + uVar11);
      uVar15 = *puVar19;
      *(ushort *)((longlong)param_1 + 0x2c) = uVar15;
      if (uVar15 == 0) {
        cVar6 = func_0x(0x2078cc0);
        if (((cVar6 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar6 = func_0x(0x2078cc0);
          if (cVar6 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x19686cc,0x1a887b8,0x80f,0);
          }
        }
        func_0x(param_1[3],3);
        uVar15 = *(ushort *)((longlong)param_1 + 0x2c);
        uVar11 = (ulonglong)*(uint *)((longlong)param_1 + 0x24);
      }
      uVar21 = (int)uVar11 + (uVar15 + 1) * 2;
      *(uint *)(param_1 + 5) = uVar21;
      if (0x1f9e < uVar21) {
        cVar6 = func_0x(0x2078cc0);
        if (((cVar6 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar6 = func_0x(0x2078cc0);
          if (cVar6 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x19686cc,0x1a887b8,0x816,0);
          }
        }
        func_0x(param_1[3],4);
        uVar15 = *(ushort *)((longlong)param_1 + 0x2c);
        uVar21 = *(uint *)(param_1 + 5);
      }
      uVar11 = (ulonglong)uVar15;
      uVar15 = puVar19[uVar11];
      *(uint *)((longlong)param_1 + 0x14) = uVar15 & 0x7fff;
      if ((uVar15 & 0x7fff) < uVar21) {
        cVar6 = func_0x(0x2078cc0);
        if (((cVar6 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar6 = func_0x(0x2078cc0);
          if (cVar6 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x19686cc,0x1a887b8,0x81d,0);
          }
        }
        func_0x(param_1[3],4);
        uVar21 = *(uint *)(param_1 + 5);
        uVar11 = (ulonglong)*(ushort *)((longlong)param_1 + 0x2c);
      }
      puVar3 = puVar19;
      if ((short)uVar11 != 0) {
        do {
          uVar13 = puVar3[1] & 0x7fff;
          if ((uVar13 < uVar21) || (*(uint *)((longlong)param_1 + 0x14) < uVar13)) {
            cVar6 = func_0x(0x2078cc0);
            if ((cVar6 != '\0') &&
               ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')
                ))) {
              cVar6 = func_0x(0x2078cc0);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x19686cc,0x1a887b8,0x82a,0);
              }
            }
            func_0x(param_1[3],4);
          }
          uVar11 = (ulonglong)*(ushort *)((longlong)param_1 + 0x2c);
          uVar20 = (int)puVar12 + 1;
          puVar12 = (uint *)(ulonglong)uVar20;
          puVar3 = puVar3 + 1;
          uVar21 = uVar13;
        } while ((int)uVar20 < (int)(uint)*(ushort *)((longlong)param_1 + 0x2c));
      }
      if ((short)puVar19[(ulonglong)((int)uVar11 - 1) + 1] < 0) {
        pbVar17 = param_1[3];
        do {
          uVar21 = *(ushort *)
                    (pbVar17 + uVar11 * 2 + (ulonglong)*(uint *)((longlong)param_1 + 0x24)) & 0x7fff
          ;
          if ((int)uVar11 == 1) {
            uVar13 = *(uint *)(param_1 + 5);
            uVar20 = uVar13;
LAB_:
            if ((uVar21 < uVar13) || (*(uint *)((longlong)param_1 + 0x14) < uVar21))
            goto LAB_;
          }
          else {
            uVar20 = *(uint *)(param_1 + 5);
            uVar13 = *(ushort *)
                      (pbVar17 + uVar11 * 2 + ((ulonglong)*(uint *)((longlong)param_1 + 0x24) - 2))
                     & 0x7fff;
            if (uVar20 <= uVar13) goto LAB_;
LAB_:
            func_0x(pbVar17,7);
            uVar20 = *(uint *)(param_1 + 5);
          }
          if ((uVar13 < uVar20) || (*(uint *)((longlong)param_1 + 0x14) < uVar13))
          goto LAB_;
          pbVar17 = param_1[3];
          if (*(ushort *)(pbVar17 + uVar13) == 5) {
            *puVar1 = *puVar1 | 2;
            *(short *)((longlong)param_1 + 0x2c) = *(short *)((longlong)param_1 + 0x2c) + -1;
            uVar15 = *(ushort *)((longlong)param_1 + 0x3c) & 0xc7ff;
            uVar11 = (ulonglong)(uVar13 & 0xffff);
            *(short *)((longlong)param_1 + 0x3a) = (short)uVar13;
            pbVar17 = param_1[3];
            if ((*(ushort *)(pbVar17 + uVar11 + 2) >> 0xe & 1) != 0) {
              uVar15 = *(ushort *)(pbVar17 + uVar11 + 2) & 0x3800 | uVar15;
            }
            *(ushort *)((longlong)param_1 + 0x3c) = uVar15;
            uVar7 = (uVar15 ^ *(ushort *)(pbVar17 + uVar11 + 2)) & 0x7ff ^ uVar15;
            *(ushort *)((longlong)param_1 + 0x3c) = uVar7;
            pbVar14 = pbVar17 + uVar11 + (ulonglong)((uVar7 & 0x7ff) * 2) + 4 +
                                         (ulonglong)((uVar15 >> 0xb & 7) * 2);
            if (pbVar14 < pbVar17 + uVar11) {
              func_0x(pbVar17 + uVar11,0x19);
              uVar7 = *(ushort *)((longlong)param_1 + 0x3c);
              uVar11 = (ulonglong)*(ushort *)((longlong)param_1 + 0x3a);
              pbVar17 = (byte *)(ulonglong)*(uint *)(param_1 + 3);
            }
            if (uVar21 - uVar13 <
                (((uVar7 & 0x7ff) * 2 - (int)uVar11) - (int)pbVar17) + (int)pbVar14) {
              func_0x(param_1[3] + uVar11,0x19);
              uVar7 = *(ushort *)((longlong)param_1 + 0x3c);
            }
            if ((uVar7 & 0x3800) != 0) {
              puVar19 = (ushort *)
                        (param_1[3] + (ulonglong)*(ushort *)((longlong)param_1 + 0x3a) + 4);
              iVar8 = 0;
              if ((uVar7 & 0x3800) != 0) {
                do {
                  if ((uVar7 & 0x7ff) < (*puVar19 & 0x7ff)) {
                    func_0x(param_1[3] + *(ushort *)((longlong)param_1 + 0x3a),0x1a);
                    uVar7 = *(ushort *)((longlong)param_1 + 0x3c);
                  }
                  iVar8 = iVar8 + 1;
                  puVar19 = puVar19 + 1;
                } while (iVar8 < (int)(uVar7 >> 0xb & 7));
              }
            }
            goto LAB_;
          }
          if (*(ushort *)(pbVar17 + uVar13) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar15 = *(short *)((longlong)param_1 + 0x2c) - 1;
          *(ushort *)((longlong)param_1 + 0x2c) = uVar15;
          if (uVar15 == 0) goto LAB_;
          uVar11 = (ulonglong)uVar15;
        } while ((short)puVar19[(ulonglong)(uVar15 - 1) + 1] < 0);
        uVar11 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
      }
      else {
LAB_:
        pbVar17 = param_1[3];
        uVar11 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
      }
    }
    if ((*pbVar17 & 0x40) == 0) {
      *(undefined4 *)((longlong)param_1 + 0x36) = 0;
    }
    else {
      *(int *)((longlong)param_1 + 0x36) = (int)uVar11;
      *(int *)((longlong)param_1 + 0x14) = (int)uVar11 + 0xe;
      uVar10 = func_0x(puVar1);
      func_0x(uVar10,auStack_58);
      iVar8 = func_0x(auStack_58);
      *(int *)((longlong)param_1 + 0x14) = *(int *)((longlong)param_1 + 0x14) + iVar8;
      uVar11 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
    }
    iVar8 = (int)uVar11;
    if ((*(byte **)((longlong)param_1 + 0x2e) != (byte *)0x0) &&
       (*(byte **)((longlong)param_1 + 0x2e) < param_1[3] + uVar11)) {
      cVar6 = func_0x(0x2078cc0);
      if ((cVar6 != '\0') &&
         ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')))) {
        cVar6 = func_0x(0x2078cc0);
        if (cVar6 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x19686cc,0x1a887b8,0x886,0);
        }
      }
      func_0x(param_1[3],0x12);
      iVar8 = *(int *)((longlong)param_1 + 0x14);
    }
    if (0x3f3b < iVar8 - 1U) {
      cVar6 = func_0x(0x2078cc0);
      if (((cVar6 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
         (*(char *)(lVar9 + 0x499) != '\0')) {
        cVar6 = func_0x(0x2078cc0);
        if (cVar6 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x19686cc,0x1a887b8,0x88b,0);
        }
      }
      func_0x(param_1[3],5);
    }
  }
LAB_:
  sVar16 = -auStack_50._0_2_;
  if ((_auStack_50 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0) {
    bVar5 = *param_1[3];
    if ((bVar5 & 0x10) == 0) {
      if ((1 << (bVar5 & 0xe) & 0x1105U) == 0) goto LAB_;
    }
    else if (((int)auStack_50._0_4_ < (int)*(uint *)(param_1 + 4)) &&
            ((ushort)auStack_50._4_2_ <= *(ushort *)(param_1[3] + *(uint *)(param_1 + 4))))
    goto LAB_;
LAB_:
    param_8 = *puStack_48;
    puVar18 = puStack_48 + 1;
    goto LAB_;
  }
LAB_:
  puVar18 = (uint *)param_1[3];
  lVar9 = (longlong)sVar16;
  if ((uint)*(ushort *)((longlong)param_1 + 0x2c) < (uint)(int)sVar16) {
    param_8 = 0;
    goto LAB_;
  }
  uVar21 = *(uint *)((longlong)param_1 + 0x24);
  if (sVar16 == 1) {
    uVar13 = *(uint *)(param_1 + 5);
    uVar21 = *(ushort *)((longlong)puVar18 + lVar9 * 2 + (ulonglong)uVar21) & 0x7fff;
LAB_:
    if ((uVar21 < uVar13) || (*(uint *)((longlong)param_1 + 0x14) < uVar21)) goto LAB_;
  }
  else {
    puVar1 = (ushort *)((longlong)puVar18 + lVar9 * 2 + (ulonglong)uVar21);
    uVar13 = *(ushort *)((longlong)puVar18 + lVar9 * 2 + ((ulonglong)uVar21 - 2)) & 0x7fff;
    puVar18 = (uint *)param_1[3];
    uVar21 = *puVar1 & 0x7fff;
    if (*(uint *)(param_1 + 5) <= uVar13) goto LAB_;
LAB_:
    func_0x(puVar18,7);
    puVar18 = (uint *)param_1[3];
  }
  param_8 = uVar21 - uVar13;
  puVar18 = (uint *)((longlong)puVar18 + (ulonglong)uVar13);
LAB_:
  if (puVar18 != (uint *)0x0) {
    uVar21 = *param_7;
    if (uVar21 == 0) {
      *param_7 = param_8;
      puVar22 = puVar18;
    }
    else {
      if ((char)*(byte *)puVar22 < '\0') {
        uVar21 = uVar21 - 2;
        uVar11 = (ulonglong)((*(ushort *)puVar22 & 0x7f) << 8 | (uint)(*(ushort *)puVar22 >> 8));
        puVar22 = (uint *)((longlong)puVar22 + 2);
      }
      else {
        uVar21 = uVar21 - 1;
        uVar11 = (ulonglong)*(byte *)puVar22;
        puVar22 = (uint *)((longlong)puVar22 + 1);
      }
      uVar13 = (uint)uVar11;
      if (uVar13 == 0) {
        *param_7 = uVar21;
      }
      else {
        *param_7 = uVar21 + uVar13;
        if (param_6 < uVar21 + uVar13) {
          (*_DAT_)(1,0x1b16b38,0x1b16b58,0x687,0);
        }
        func_0x(param_5,param_6,puVar18,uVar11);
        if (param_6 < uVar13) {
          (*_DAT_)(1,0x1b16b90,0x1b16b58,0x68b,0);
        }
        func_0x
                  ((byte *)((longlong)param_5 + uVar11),param_6 - uVar13,puVar22,uVar21);
        puVar22 = param_5;
      }
    }
  }
  return puVar22;
}

