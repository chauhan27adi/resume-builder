
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,char param_2,uint *param_3)

{
  longlong *plVar1;
  longlong lVar2;
  
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 8) + 0x488);
  if (param_3[2] == 0) {
    if (((lVar2 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
      if (*(longlong *)(lVar2 + 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      LOCK();
      plVar1 = (longlong *)(*(longlong *)(lVar2 + 0x18) + 0xe0);
      *plVar1 = *plVar1 + 1;
      UNLOCK();
    }
    if (*param_3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (param_2 == '\x02') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  else {
    if (((lVar2 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
      if (*(longlong *)(lVar2 + 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      LOCK();
      plVar1 = (longlong *)(*(longlong *)(lVar2 + 0x18) + 0xf0);
      *plVar1 = *plVar1 + 1;
      UNLOCK();
    }
    if ((((ulonglong)*param_3 != 0) &&
        (lVar2 = *(longlong *)(*(longlong *)(param_1 + 8) + 0x488), lVar2 != 0)) &&
       ((*_DAT_ != '\0' && ((DAT_ & 2) == 0)))) {
      if (*(longlong *)(lVar2 + 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      LOCK();
      plVar1 = (longlong *)(*(longlong *)(lVar2 + 0x18) + 0xf8);
      *plVar1 = *plVar1 + (ulonglong)*param_3;
      UNLOCK();
    }
    if (param_2 == '\x02') {
      lVar2 = *(longlong *)(*(longlong *)(param_1 + 8) + 0x488);
      if (((lVar2 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
        if (*(longlong *)(lVar2 + 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        LOCK();
        plVar1 = (longlong *)(*(longlong *)(lVar2 + 0x18) + 0x110);
        *plVar1 = *plVar1 + 1;
        UNLOCK();
      }
      if (((((ulonglong)*param_3 != 0) &&
           (lVar2 = *(longlong *)(*(longlong *)(param_1 + 8) + 0x488), lVar2 != 0)) &&
          (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
        if (*(longlong *)(lVar2 + 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        LOCK();
        plVar1 = (longlong *)(*(longlong *)(lVar2 + 0x18) + 0x118);
        *plVar1 = *plVar1 + (ulonglong)*param_3;
        UNLOCK();
      }
    }
  }
  return;
}

