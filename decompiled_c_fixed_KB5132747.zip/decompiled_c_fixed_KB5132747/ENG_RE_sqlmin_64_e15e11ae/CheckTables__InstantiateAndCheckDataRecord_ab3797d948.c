
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_(undefined8 param_1,longlong param_2)

{
  short *psVar1;
  short sVar2;
  byte bVar3;
  ushort *puVar4;
  byte bVar5;
  char cVar6;
  ushort uVar7;
  ushort uVar8;
  uint uVar9;
  longlong lVar10;
  undefined8 uVar11;
  ulonglong *puVar12;
  uint uVar13;
  byte bVar14;
  int iVar15;
  byte *pbVar16;
  ushort *puVar17;
  uint uVar18;
  uint uVar19;
  ulonglong uVar20;
  uint uVar21;
  ulonglong uVar22;
  ulonglong uVar23;
  int iVar24;
  ushort *puVar25;
  bool bVar26;
  undefined8 uStackX_10;
  undefined auStackX_18 [8];
  ulonglong in_stack_ffffffffffffff48;
  undefined4 uVar27;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined2 uStack_90;
  undefined2 uStack_8e;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined2 uStack_80;
  undefined2 uStack_7e;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined2 uStack_70;
  undefined2 uStack_6e;
  longlong lStack_68;
  undefined4 uStack_60;
  int iStack_5c;
  undefined4 uStack_58;
  undefined8 uStack_50;
  short *psStack_48;
  undefined4 uStack_40;
  
  psVar1 = (short *)(param_2 + 0xa0);
  iVar15 = 0;
  uVar9 = 0;
  uVar21 = 0;
  pbVar16 = *(byte **)(param_2 + 0xa8);
  sVar2 = *psVar1;
  if (sVar2 == 0) {
    if (((*pbVar16 & 0xe) == 2) && ((pbVar16[1] & 1) != 0)) {
      return 0;
    }
  }
  else if ((*pbVar16 & 0x1c) == 0x14) {
    return 0;
  }
  if ((*(byte *)(param_2 + 0x10) & 0x80) != 0) {
    uVar9 = func_0x();
    return uVar9;
  }
  bVar5 = *pbVar16;
  bVar14 = bVar5 & 0xe;
  bVar3 = bVar14;
  if (sVar2 != 0) {
    bVar3 = bVar5 & 0x1c;
  }
  uVar18 = 0;
  if (bVar3 == 0) {
LAB_:
    lVar10 = *(longlong *)(param_2 + 0x98);
    lStack_68 = 0;
    uStackX_10 = 0;
    iVar15 = func_0x(psVar1);
    if ((iVar15 < 1) || (iVar15 = func_0x(param_1,lVar10,param_2), iVar15 != 0)) {
      iVar15 = func_0x(param_2);
      if (iVar15 == 0) {
        lStack_68 = *(longlong *)(lVar10 + 0x80);
        uStack_60 = 9;
        uStack_50 = 0;
        uStack_58 = 0;
        uStack_40 = 0;
        lVar10 = **(longlong **)(*(longlong *)(lStack_68 + 8) + 0x160);
        iStack_5c = *(int *)(lVar10 + 0x10) - *(int *)(lVar10 + 0x18);
        psStack_48 = psVar1;
        iVar15 = func_0x(&lStack_68,&uStackX_10);
        do {
          if (iVar15 == 0) {
            return uVar18;
          }
          in_stack_ffffffffffffff48 = in_stack_ffffffffffffff48 & 0xffffffff00000000;
          uVar9 = func_0x(param_1,param_2 + 0x18,param_2,uStackX_10,
                                  in_stack_ffffffffffffff48);
          uVar18 = uVar18 | uVar9;
          if (uVar18 != 0) {
            if ((uVar18 & 8) == 0) {
              return uVar18;
            }
            func_0x(0x7f);
            uVar18 = uVar18 - 8;
            if (uVar18 != 0) {
              return uVar18;
            }
          }
          iVar15 = func_0x(&lStack_68,&uStackX_10);
        } while( true );
      }
      uStack_78 = *(undefined4 *)(param_2 + 0x154);
      uVar11 = 0xe74a60;
      uStack_74 = *(undefined4 *)(param_2 + 0x158);
      uStack_70 = *(undefined2 *)(param_2 + 0x15c);
      uStack_6e = *(undefined2 *)(param_2 + 0x15e);
      if (iVar15 == 2) {
        uVar11 = 0xe74970;
      }
      func_0x(&uStack_78,*(undefined4 *)(param_2 + 0xd4),param_2 + 0x60,uVar11,0x15,0,0);
      func_0x(param_1,2,param_2 + 0x60);
    }
    return 4;
  }
  uVar19 = (uint)bVar5;
  if (sVar2 == 0) {
    if (bVar14 == 2) goto LAB_;
    bVar26 = bVar14 == 4;
  }
  else {
    if (((uVar19 & 0x1c) - 0x10 & 0xfffffffb) == 0) goto LAB_;
    bVar26 = (bVar5 & 0x1c) == 8;
  }
  if ((bVar26) && (*(short *)(param_2 + 0x7a) != 2)) {
    return 0;
  }
  if (sVar2 == 0) {
    if (bVar14 == 2) {
      uVar13 = (uint)((pbVar16[1] & 1) != 0);
    }
    else {
      uVar13 = uVar9;
      if (((bVar14 - 10 & 0xf9) == 0) && (bVar14 != 0x10)) {
        uVar13 = 1;
      }
    }
  }
  else {
    uVar13 = (uint)(((uVar19 & 0x1c) - 4 & 0xffffffe7) == 0);
  }
  if (uVar13 != 0) {
    if (sVar2 == 0) {
      if ((1 << (bVar5 & 0xe) & 0x440U) == 0) {
LAB_:
        if (*(short *)(param_2 + 0x7a) == 2) {
          return 0;
        }
        if ((*(int *)(*(longlong *)(param_2 + 0x98) + 0x328) - 2U & 0xfffffffd) == 0) {
          return 0;
        }
      }
    }
    else if (((uVar19 & 0x1c) - 0x18 & 0xfffffffb) != 0) goto LAB_;
  }
  if (sVar2 != 0) {
    if (((bVar5 & 0x1c) == 4) && ((bVar5 & 2) != 0)) goto LAB_;
LAB_:
    uVar18 = (uint)(((bVar5 & 0x1c) - 4 & 0xffffffe7) == 0);
    goto LAB_;
  }
  if (bVar14 == 0xe) {
LAB_:
    if (*(short *)(param_2 + 0x7a) == 1) {
      if (sVar2 == 0) {
        iVar24 = *(int *)(param_2 + 0xb0);
      }
      else if ((uVar19 & 0x1c) == 4) {
        iVar24 = 1;
      }
      else if ((uVar19 & 0x1c) == 0x10) {
        iVar24 = 9;
      }
      else {
        iVar24 = (uint)*(ushort *)(param_2 + 0xbc) + (uint)*(ushort *)(param_2 + 0xba);
      }
      if (iVar24 == 1) {
        return 0;
      }
      if (sVar2 == 0) {
        uVar21 = *(uint *)(param_2 + 0xa4);
        puVar17 = (ushort *)(param_2 + 0xa2);
        uStackX_10 = CONCAT44(uStackX_10._4_4_,*(undefined4 *)(param_2 + 0xb0));
        if (uVar21 == 0) {
          pbVar16 = *(byte **)(param_2 + 0xa8);
          uVar21 = *(uint *)(param_2 + 0xb0);
          uVar22 = (ulonglong)uVar21;
          *puVar17 = 0;
          *(uint *)(param_2 + 0xb4) = uVar21;
          bVar5 = *pbVar16;
          if ((bVar5 & 0x10) != 0) {
            uVar21 = uVar21 + 2 + (*(ushort *)(pbVar16 + uVar22) + 7 >> 3);
            uVar22 = (ulonglong)uVar21;
            *(uint *)(param_2 + 0xb4) = uVar21;
            bVar5 = *pbVar16;
          }
          if ((bVar5 & 0x20) == 0) {
            *(int *)(param_2 + 0xa4) = (int)uVar22;
            *(undefined2 *)(param_2 + 0xbc) = 0;
            *(int *)(param_2 + 0xb8) = (int)uVar22;
          }
          else {
            puVar25 = (ushort *)(pbVar16 + uVar22);
            uVar7 = *puVar25;
            *(ushort *)(param_2 + 0xbc) = uVar7;
            if (uVar7 == 0) {
              cVar6 = func_0x(0x14a3950);
              if (((cVar6 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
                 (*(char *)(lVar10 + 0x499) != '\0')) {
                cVar6 = func_0x(0x14a3950);
                if (cVar6 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  in_stack_ffffffffffffff48 = 0;
                  (*_DAT_)(1,0xd9335c,0xeb3448,0x80f,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 0xa8),3);
              uVar22 = (ulonglong)*(uint *)(param_2 + 0xb4);
              pbVar16 = *(byte **)(param_2 + 0xa8);
              uVar7 = *(ushort *)(param_2 + 0xbc);
            }
            uVar21 = (int)uVar22 + (uVar7 + 1) * 2;
            *(uint *)(param_2 + 0xb8) = uVar21;
            if (0x1f9e < uVar21) {
              cVar6 = func_0x(0x14a3950);
              if (((cVar6 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
                 (*(char *)(lVar10 + 0x499) != '\0')) {
                cVar6 = func_0x(0x14a3950);
                if (cVar6 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  in_stack_ffffffffffffff48 = 0;
                  (*_DAT_)(1,0xd9335c,0xeb3448,0x816,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 0xa8),4);
              uVar7 = *(ushort *)(param_2 + 0xbc);
              pbVar16 = *(byte **)(param_2 + 0xa8);
              uVar21 = *(uint *)(param_2 + 0xb8);
            }
            uVar22 = (ulonglong)uVar7;
            uVar7 = puVar25[uVar22];
            *(uint *)(param_2 + 0xa4) = uVar7 & 0x7fff;
            if ((uVar7 & 0x7fff) < uVar21) {
              cVar6 = func_0x(0x14a3950);
              if (((cVar6 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
                 (*(char *)(lVar10 + 0x499) != '\0')) {
                cVar6 = func_0x(0x14a3950);
                if (cVar6 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  in_stack_ffffffffffffff48 = 0;
                  (*_DAT_)(1,0xd9335c,0xeb3448,0x81d,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 0xa8),4);
              uVar21 = *(uint *)(param_2 + 0xb8);
              uVar22 = (ulonglong)*(ushort *)(param_2 + 0xbc);
              pbVar16 = *(byte **)(param_2 + 0xa8);
            }
            puVar4 = puVar25;
            iVar24 = iVar15;
            if ((short)uVar22 != 0) {
              do {
                uVar18 = puVar4[1] & 0x7fff;
                if ((uVar18 < uVar21) || (*(uint *)(param_2 + 0xa4) < uVar18)) {
                  cVar6 = func_0x(0x14a3950);
                  if ((cVar6 != '\0') &&
                     ((lVar10 = func_0x(), lVar10 != 0 &&
                      (*(char *)(lVar10 + 0x499) != '\0')))) {
                    cVar6 = func_0x(0x14a3950);
                    if (cVar6 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      in_stack_ffffffffffffff48 = 0;
                      (*_DAT_)(1,0xd9335c,0xeb3448,0x82a,0);
                    }
                  }
                  func_0x(*(undefined8 *)(param_2 + 0xa8),4);
                }
                uVar22 = (ulonglong)*(ushort *)(param_2 + 0xbc);
                iVar24 = iVar24 + 1;
                puVar4 = puVar4 + 1;
                uVar21 = uVar18;
              } while (iVar24 < (int)(uint)*(ushort *)(param_2 + 0xbc));
              pbVar16 = *(byte **)(param_2 + 0xa8);
            }
            if ((short)puVar25[(ulonglong)((int)uVar22 - 1) + 1] < 0) {
              do {
                uVar18 = *(ushort *)(pbVar16 + uVar22 * 2 + (ulonglong)*(uint *)(param_2 + 0xb4)) &
                         0x7fff;
                if ((int)uVar22 == 1) {
                  uVar19 = *(uint *)(param_2 + 0xb8);
                  uVar13 = uVar19;
LAB_:
                  if ((uVar18 < uVar19) || (uVar21 = *(uint *)(param_2 + 0xa4), uVar21 < uVar18))
                  goto LAB_;
                }
                else {
                  uVar13 = *(uint *)(param_2 + 0xb8);
                  uVar19 = *(ushort *)
                            (pbVar16 + uVar22 * 2 + ((ulonglong)*(uint *)(param_2 + 0xb4) - 2)) &
                           0x7fff;
                  if (uVar13 <= uVar19) goto LAB_;
LAB_:
                  func_0x(pbVar16,7);
                  uVar13 = *(uint *)(param_2 + 0xb8);
                  uVar21 = *(uint *)(param_2 + 0xa4);
                  pbVar16 = *(byte **)(param_2 + 0xa8);
                }
                if ((uVar19 < uVar13) || (uVar21 < uVar19)) goto LAB_;
                if (*(ushort *)(pbVar16 + uVar19) == 5) {
                  *puVar17 = *puVar17 | 2;
                  *(short *)(param_2 + 0xbc) = *(short *)(param_2 + 0xbc) + -1;
                  uVar7 = *(ushort *)(param_2 + 0xcc) & 0xc7ff;
                  uVar20 = (ulonglong)(uVar19 & 0xffff);
                  *(short *)(param_2 + 0xca) = (short)uVar19;
                  uVar22 = *(ulonglong *)(param_2 + 0xa8);
                  if ((*(ushort *)(uVar20 + 2 + uVar22) >> 0xe & 1) != 0) {
                    uVar7 = *(ushort *)(uVar20 + 2 + uVar22) & 0x3800 | uVar7;
                  }
                  *(ushort *)(param_2 + 0xcc) = uVar7;
                  uVar23 = (ulonglong)*(ushort *)(param_2 + 0xca);
                  uVar8 = (uVar7 ^ *(ushort *)(uVar20 + 2 + uVar22)) & 0x7ff ^ uVar7;
                  *(ushort *)(param_2 + 0xcc) = uVar8;
                  uVar20 = uVar23 + 4 +
                           (ulonglong)((uVar8 & 0x7ff) * 2) + uVar22 + (uVar7 >> 0xb & 7) * 2;
                  if (uVar20 < uVar23 + uVar22) {
                    func_0x(uVar23 + uVar22,0x19);
                    uVar8 = *(ushort *)(param_2 + 0xcc);
                    uVar23 = (ulonglong)*(ushort *)(param_2 + 0xca);
                    uVar22 = (ulonglong)*(uint *)(param_2 + 0xa8);
                  }
                  if (uVar18 - uVar19 <
                      (((uVar8 & 0x7ff) * 2 - (int)uVar23) - (int)uVar22) + (int)uVar20) {
                    func_0x(uVar23 + *(longlong *)(param_2 + 0xa8),0x19);
                    uVar8 = *(ushort *)(param_2 + 0xcc);
                  }
                  if (((uVar8 & 0x3800) != 0) &&
                     (puVar25 = (ushort *)
                                (*(longlong *)(param_2 + 0xa8) + 4 +
                                (ulonglong)*(ushort *)(param_2 + 0xca)), iVar24 = iVar15,
                     (uVar8 & 0x3800) != 0)) {
                    do {
                      if ((uVar8 & 0x7ff) < (*puVar25 & 0x7ff)) {
                        func_0x((ulonglong)*(ushort *)(param_2 + 0xca) +
                                        *(longlong *)(param_2 + 0xa8),0x1a);
                        uVar8 = *(ushort *)(param_2 + 0xcc);
                      }
                      iVar24 = iVar24 + 1;
                      puVar25 = puVar25 + 1;
                    } while (iVar24 < (int)(uVar8 >> 0xb & 7));
                  }
                  pbVar16 = *(byte **)(param_2 + 0xa8);
                  goto LAB_;
                }
                if (*(ushort *)(pbVar16 + uVar19) < 0x400) goto LAB_;
                *puVar17 = *puVar17 | 1;
                uVar7 = *(short *)(param_2 + 0xbc) - 1;
                *(ushort *)(param_2 + 0xbc) = uVar7;
                if (uVar7 == 0) goto LAB_;
                uVar22 = (ulonglong)uVar7;
              } while ((short)puVar25[(ulonglong)(uVar7 - 1) + 1] < 0);
              uVar22 = (ulonglong)*(uint *)(param_2 + 0xa4);
            }
            else {
LAB_:
              uVar22 = (ulonglong)*(uint *)(param_2 + 0xa4);
            }
          }
          if ((*pbVar16 & 0x40) == 0) {
            *(undefined4 *)(param_2 + 0xc6) = 0;
          }
          else {
            *(int *)(param_2 + 0xc6) = (int)uVar22;
            *(int *)(param_2 + 0xa4) = (int)uVar22 + 0xe;
            uVar11 = func_0x(puVar17);
            func_0x(uVar11,auStackX_18);
            iVar24 = func_0x(auStackX_18);
            *(int *)(param_2 + 0xa4) = *(int *)(param_2 + 0xa4) + iVar24;
            uVar22 = (ulonglong)*(uint *)(param_2 + 0xa4);
            pbVar16 = *(byte **)(param_2 + 0xa8);
          }
          uVar21 = (uint)uVar22;
          if ((*(byte **)(param_2 + 0xbe) != (byte *)0x0) &&
             (*(byte **)(param_2 + 0xbe) < pbVar16 + uVar22)) {
            cVar6 = func_0x(0x14a3950);
            if ((cVar6 != '\0') &&
               ((lVar10 = func_0x(), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              cVar6 = func_0x(0x14a3950);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                in_stack_ffffffffffffff48 = 0;
                (*_DAT_)(1,0xd9335c,0xeb3448,0x886,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 0xa8),0x12);
            uVar21 = *(uint *)(param_2 + 0xa4);
          }
          if ((uVar21 == 0) || (0x3f3c < uVar21)) {
            cVar6 = func_0x(0x14a3950);
            if ((cVar6 != '\0') &&
               ((lVar10 = func_0x(), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              cVar6 = func_0x(0x14a3950);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                in_stack_ffffffffffffff48 = 0;
                (*_DAT_)(1,0xd9335c,0xeb3448,0x88b,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 0xa8),5);
            uVar21 = *(uint *)(param_2 + 0xa4);
          }
        }
LAB_:
        if (uVar21 < 9) {
          pbVar16 = *(byte **)(param_2 + 0xa8);
          bVar5 = *pbVar16;
          if (((bVar5 & 0xe) != 0) && ((bVar5 & 0xe) != 0xc)) goto LAB_;
          uVar18 = 9;
        }
        else {
LAB_:
          pbVar16 = *(byte **)(param_2 + 0xa8);
          bVar5 = *pbVar16;
          uVar18 = uVar21;
        }
        if ((bVar5 & 0x40) != 0) {
          uVar18 = *(uint *)(param_2 + 0xc6);
        }
      }
      else {
        if ((uVar19 & 0x1c) == 4) {
          uStackX_10 = CONCAT44(uStackX_10._4_4_,1);
        }
        else if ((uVar19 & 0x1c) == 0x10) {
          uStackX_10 = CONCAT44(uStackX_10._4_4_,9);
        }
        else {
          uStackX_10 = CONCAT44(uStackX_10._4_4_,
                                (uint)*(ushort *)(param_2 + 0xbc) +
                                (uint)*(ushort *)(param_2 + 0xba));
        }
        uVar21 = *(uint *)(param_2 + 0xa4);
        if (uVar21 == 0) {
          func_0x(param_2 + 0xa2);
          uVar21 = *(uint *)(param_2 + 0xa4);
          if (uVar21 == 0) {
            func_0x(param_2 + 0xa2);
            uVar21 = *(uint *)(param_2 + 0xa4);
          }
        }
        if (uVar21 < 9) {
          pbVar16 = *(byte **)(param_2 + 0xa8);
          bVar5 = *pbVar16;
          if (((bVar5 & 0x1c) != 0) && ((bVar5 & 0x1c) != 0xc)) goto LAB_;
          uVar18 = 9;
        }
        else {
LAB_:
          pbVar16 = *(byte **)(param_2 + 0xa8);
          bVar5 = *pbVar16;
          uVar18 = uVar21;
        }
        if ((bVar5 & 2) != 0) {
          uVar18 = *(uint *)(param_2 + 0xd0);
        }
      }
      uVar27 = (undefined4)(in_stack_ffffffffffffff48 >> 0x20);
      puVar17 = (ushort *)(param_2 + 0xa2);
      if ((uint)uStackX_10 == uVar18) {
        return 0;
      }
      if (*(short *)(param_2 + 0xa0) != 0) {
        if (uVar21 == 0) {
          func_0x(puVar17);
          uVar21 = *(uint *)(param_2 + 0xa4);
          pbVar16 = *(byte **)(param_2 + 0xa8);
          if (uVar21 == 0) {
            func_0x(puVar17);
            pbVar16 = *(byte **)(param_2 + 0xa8);
            uVar21 = *(uint *)(param_2 + 0xa4);
          }
        }
        if ((uVar21 < 9) && (((*pbVar16 & 0x1c) == 0 || ((*pbVar16 & 0x1c) == 0xc)))) {
          uVar21 = 9;
        }
        if ((*pbVar16 & 2) != 0) {
          uVar21 = *(uint *)(param_2 + 0xd0);
        }
        goto LAB_;
      }
      if (uVar21 == 0) {
        uVar21 = *(uint *)(param_2 + 0xb0);
        uVar22 = (ulonglong)uVar21;
        *(uint *)(param_2 + 0xb4) = uVar21;
        *puVar17 = 0;
        if ((*pbVar16 & 0x10) != 0) {
          uVar21 = uVar21 + 2 + (*(ushort *)(pbVar16 + uVar22) + 7 >> 3);
          uVar22 = (ulonglong)uVar21;
          *(uint *)(param_2 + 0xb4) = uVar21;
        }
        if ((*pbVar16 & 0x20) == 0) {
          *(int *)(param_2 + 0xa4) = (int)uVar22;
          *(undefined2 *)(param_2 + 0xbc) = 0;
          *(int *)(param_2 + 0xb8) = (int)uVar22;
        }
        else {
          puVar25 = (ushort *)(pbVar16 + uVar22);
          uVar7 = *puVar25;
          *(ushort *)(param_2 + 0xbc) = uVar7;
          if (uVar7 == 0) {
            cVar6 = func_0x(0x14a3950);
            if (((cVar6 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
               (*(char *)(lVar10 + 0x499) != '\0')) {
              cVar6 = func_0x(0x14a3950);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                in_stack_ffffffffffffff48 = 0;
                (*_DAT_)(1,0xd9335c,0xeb3448,0x80f,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 0xa8),3);
            uVar22 = (ulonglong)*(uint *)(param_2 + 0xb4);
            pbVar16 = *(byte **)(param_2 + 0xa8);
            uVar7 = *(ushort *)(param_2 + 0xbc);
          }
          uVar21 = (int)uVar22 + (uVar7 + 1) * 2;
          *(uint *)(param_2 + 0xb8) = uVar21;
          if (0x1f9e < uVar21) {
            cVar6 = func_0x(0x14a3950);
            if (((cVar6 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
               (*(char *)(lVar10 + 0x499) != '\0')) {
              cVar6 = func_0x(0x14a3950);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                in_stack_ffffffffffffff48 = 0;
                (*_DAT_)(1,0xd9335c,0xeb3448,0x816,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 0xa8),4);
            uVar7 = *(ushort *)(param_2 + 0xbc);
            pbVar16 = *(byte **)(param_2 + 0xa8);
            uVar21 = *(uint *)(param_2 + 0xb8);
          }
          uVar22 = (ulonglong)uVar7;
          uVar7 = puVar25[uVar22];
          *(uint *)(param_2 + 0xa4) = uVar7 & 0x7fff;
          if ((uVar7 & 0x7fff) < uVar21) {
            cVar6 = func_0x(0x14a3950);
            if (((cVar6 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
               (*(char *)(lVar10 + 0x499) != '\0')) {
              cVar6 = func_0x(0x14a3950);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                in_stack_ffffffffffffff48 = 0;
                (*_DAT_)(1,0xd9335c,0xeb3448,0x81d,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 0xa8),4);
            uVar21 = *(uint *)(param_2 + 0xb8);
            uVar22 = (ulonglong)*(ushort *)(param_2 + 0xbc);
            pbVar16 = *(byte **)(param_2 + 0xa8);
          }
          puVar4 = puVar25;
          iVar24 = iVar15;
          if ((short)uVar22 != 0) {
            do {
              uVar18 = puVar4[1] & 0x7fff;
              if ((uVar18 < uVar21) || (*(uint *)(param_2 + 0xa4) < uVar18)) {
                cVar6 = func_0x(0x14a3950);
                if ((cVar6 != '\0') &&
                   ((lVar10 = func_0x(), lVar10 != 0 &&
                    (*(char *)(lVar10 + 0x499) != '\0')))) {
                  cVar6 = func_0x(0x14a3950);
                  if (cVar6 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    in_stack_ffffffffffffff48 = 0;
                    (*_DAT_)(1,0xd9335c,0xeb3448,0x82a,0);
                  }
                }
                func_0x(*(undefined8 *)(param_2 + 0xa8),4);
              }
              uVar22 = (ulonglong)*(ushort *)(param_2 + 0xbc);
              iVar24 = iVar24 + 1;
              puVar4 = puVar4 + 1;
              uVar21 = uVar18;
            } while (iVar24 < (int)(uint)*(ushort *)(param_2 + 0xbc));
            pbVar16 = *(byte **)(param_2 + 0xa8);
          }
          uVar27 = (undefined4)(in_stack_ffffffffffffff48 >> 0x20);
          if ((short)puVar25[(ulonglong)((int)uVar22 - 1) + 1] < 0) {
            do {
              uVar18 = *(ushort *)(pbVar16 + uVar22 * 2 + (ulonglong)*(uint *)(param_2 + 0xb4)) &
                       0x7fff;
              if ((int)uVar22 == 1) {
                uVar19 = *(uint *)(param_2 + 0xb8);
                uVar13 = uVar19;
LAB_:
                if ((uVar18 < uVar19) || (uVar21 = *(uint *)(param_2 + 0xa4), uVar21 < uVar18))
                goto LAB_;
              }
              else {
                uVar13 = *(uint *)(param_2 + 0xb8);
                uVar19 = *(ushort *)
                          (pbVar16 + uVar22 * 2 + ((ulonglong)*(uint *)(param_2 + 0xb4) - 2)) &
                         0x7fff;
                if (uVar13 <= uVar19) goto LAB_;
LAB_:
                func_0x(pbVar16,7);
                uVar13 = *(uint *)(param_2 + 0xb8);
                uVar21 = *(uint *)(param_2 + 0xa4);
                pbVar16 = *(byte **)(param_2 + 0xa8);
              }
              uVar27 = (undefined4)(in_stack_ffffffffffffff48 >> 0x20);
              if ((uVar19 < uVar13) || (uVar21 < uVar19)) goto LAB_;
              if (*(ushort *)(pbVar16 + uVar19) == 5) {
                *puVar17 = *puVar17 | 2;
                *(short *)(param_2 + 0xbc) = *(short *)(param_2 + 0xbc) + -1;
                uVar7 = *(ushort *)(param_2 + 0xcc) & 0xc7ff;
                uVar20 = (ulonglong)(uVar19 & 0xffff);
                *(short *)(param_2 + 0xca) = (short)uVar19;
                uVar22 = *(ulonglong *)(param_2 + 0xa8);
                if ((*(ushort *)(uVar20 + 2 + uVar22) >> 0xe & 1) != 0) {
                  uVar7 = *(ushort *)(uVar20 + 2 + uVar22) & 0x3800 | uVar7;
                }
                *(ushort *)(param_2 + 0xcc) = uVar7;
                uVar23 = (ulonglong)*(ushort *)(param_2 + 0xca);
                uVar8 = (uVar7 ^ *(ushort *)(uVar20 + 2 + uVar22)) & 0x7ff ^ uVar7;
                *(ushort *)(param_2 + 0xcc) = uVar8;
                uVar20 = (ulonglong)((uVar8 & 0x7ff) * 2) + 4 + uVar23 + (uVar7 >> 0xb & 7) * 2 +
                         uVar22;
                if (uVar20 < uVar23 + uVar22) {
                  func_0x(uVar23 + uVar22,0x19);
                  uVar8 = *(ushort *)(param_2 + 0xcc);
                  uVar23 = (ulonglong)*(ushort *)(param_2 + 0xca);
                  uVar22 = (ulonglong)*(uint *)(param_2 + 0xa8);
                }
                if (uVar18 - uVar19 <
                    (((uVar8 & 0x7ff) * 2 - (int)uVar23) - (int)uVar22) + (int)uVar20) {
                  func_0x(uVar23 + *(longlong *)(param_2 + 0xa8),0x19);
                  uVar8 = *(ushort *)(param_2 + 0xcc);
                }
                uVar27 = (undefined4)(in_stack_ffffffffffffff48 >> 0x20);
                if (((uVar8 & 0x3800) != 0) &&
                   (puVar25 = (ushort *)
                              (*(longlong *)(param_2 + 0xa8) + 4 +
                              (ulonglong)*(ushort *)(param_2 + 0xca)), (uVar8 & 0x3800) != 0)) {
                  do {
                    if ((uVar8 & 0x7ff) < (*puVar25 & 0x7ff)) {
                      func_0x((ulonglong)*(ushort *)(param_2 + 0xca) +
                                      *(longlong *)(param_2 + 0xa8),0x1a);
                      uVar8 = *(ushort *)(param_2 + 0xcc);
                    }
                    uVar27 = (undefined4)(in_stack_ffffffffffffff48 >> 0x20);
                    iVar15 = iVar15 + 1;
                    puVar25 = puVar25 + 1;
                  } while (iVar15 < (int)(uVar8 >> 0xb & 7));
                }
                pbVar16 = *(byte **)(param_2 + 0xa8);
                goto LAB_;
              }
              if (*(ushort *)(pbVar16 + uVar19) < 0x400) goto LAB_;
              *puVar17 = *puVar17 | 1;
              uVar7 = *(short *)(param_2 + 0xbc) - 1;
              *(ushort *)(param_2 + 0xbc) = uVar7;
              if (uVar7 == 0) goto LAB_;
              uVar22 = (ulonglong)uVar7;
            } while ((short)puVar25[(ulonglong)(uVar7 - 1) + 1] < 0);
            uVar22 = (ulonglong)*(uint *)(param_2 + 0xa4);
          }
          else {
LAB_:
            uVar22 = (ulonglong)*(uint *)(param_2 + 0xa4);
          }
        }
        if ((*pbVar16 & 0x40) == 0) {
          *(undefined4 *)(param_2 + 0xc6) = 0;
        }
        else {
          *(int *)(param_2 + 0xc6) = (int)uVar22;
          *(int *)(param_2 + 0xa4) = (int)uVar22 + 0xe;
          puVar12 = (ulonglong *)func_0x(puVar17);
          uVar8 = (ushort)(*puVar12 >> 0x30);
          uVar7 = uVar8;
          if ((((uint)(int)(short)uVar8 >> 1 ^ (int)(short)uVar8) & 0x2000) != 0) {
            uVar7 = uVar8 & 0xdfff;
            if ((uVar8 >> 0xe & 1) != 0) {
              uVar7 = uVar8 | 0x2000;
            }
          }
          if (uVar7 == 0xfffc) {
            uVar9 = (uint)((*puVar12 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(param_2 + 0xa4) = *(int *)(param_2 + 0xa4) + uVar9;
          uVar22 = (ulonglong)*(uint *)(param_2 + 0xa4);
          pbVar16 = *(byte **)(param_2 + 0xa8);
        }
        uVar21 = (uint)uVar22;
        if ((*(byte **)(param_2 + 0xbe) != (byte *)0x0) &&
           (*(byte **)(param_2 + 0xbe) < pbVar16 + uVar22)) {
          cVar6 = func_0x(0x14a3950);
          if ((cVar6 != '\0') &&
             ((lVar10 = func_0x(), lVar10 != 0 &&
              (*(char *)(lVar10 + 0x499) != '\0')))) {
            cVar6 = func_0x(0x14a3950);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uVar27 = 0;
              (*_DAT_)(1,0xd9335c,0xeb3448,0x886,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 0xa8),0x12);
          uVar21 = *(uint *)(param_2 + 0xa4);
          pbVar16 = *(byte **)(param_2 + 0xa8);
        }
        if ((uVar21 == 0) || (0x3f3c < uVar21)) {
          cVar6 = func_0x(0x14a3950);
          if ((cVar6 != '\0') &&
             ((lVar10 = func_0x(), lVar10 != 0 &&
              (*(char *)(lVar10 + 0x499) != '\0')))) {
            cVar6 = func_0x(0x14a3950);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              uVar27 = 0;
              (*_DAT_)(1,0xd9335c,0xeb3448,0x88b,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 0xa8),5);
          uVar21 = *(uint *)(param_2 + 0xa4);
          pbVar16 = *(byte **)(param_2 + 0xa8);
        }
      }
LAB_:
      if (uVar21 < 9) {
        bVar5 = *pbVar16;
        if (((bVar5 & 0xe) != 0) && ((bVar5 & 0xe) != 0xc)) goto LAB_;
        uVar21 = 9;
      }
      else {
LAB_:
        bVar5 = *pbVar16;
      }
      if ((bVar5 & 0x40) != 0) {
        uVar21 = *(uint *)(param_2 + 0xc6);
      }
LAB_:
      if (*(short *)(param_2 + 0xa0) == 0) {
        iVar15 = *(int *)(param_2 + 0xb0);
      }
      else if ((*pbVar16 & 0x1c) == 4) {
        iVar15 = 1;
      }
      else if ((*pbVar16 & 0x1c) == 0x10) {
        iVar15 = 9;
      }
      else {
        iVar15 = (uint)*(ushort *)(param_2 + 0xbc) + (uint)*(ushort *)(param_2 + 0xba);
      }
      uStack_98 = *(undefined4 *)(param_2 + 0x154);
      uStack_94 = *(undefined4 *)(param_2 + 0x158);
      uStack_90 = *(undefined2 *)(param_2 + 0x15c);
      uStack_8e = *(undefined2 *)(param_2 + 0x15e);
      func_0x(&uStack_98,*(undefined4 *)(param_2 + 0xd4),param_2 + 0x60,0xe74aa0,
                      CONCAT44(uVar27,0x14),iVar15,uVar21);
      func_0x(param_1,2,param_2 + 0x60);
      return 4;
    }
    if (sVar2 != 0) goto LAB_;
  }
  if (bVar14 == 2) {
    uVar18 = (uint)((pbVar16[1] & 1) != 0);
  }
  else if (((bVar14 - 10 & 0xf9) == 0) && (bVar14 != 0x10)) {
    uVar18 = 1;
  }
LAB_:
  if ((uVar18 == 0) || (*(short *)(param_2 + 0x7a) != 1)) {
    uStack_88 = *(undefined4 *)(param_2 + 0x154);
    uStack_84 = *(undefined4 *)(param_2 + 0x158);
    uStack_80 = *(undefined2 *)(param_2 + 0x15c);
    uStack_7e = *(undefined2 *)(param_2 + 0x15e);
    func_0x(&uStack_88,*(undefined4 *)(param_2 + 0xd4),param_2 + 0x60,0xe749a0,3,0,0);
    func_0x(param_1,2,param_2 + 0x60);
    uVar21 = 0x14;
  }
  return uVar21;
}

