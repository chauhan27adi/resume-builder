
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00f78306) */
/* WARNING: Removing unreachable block (ram,0x00f76234) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5,int param_6)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong lVar5;
  int *piVar6;
  longlong lVar7;
  ulonglong uVar8;
  ushort *puVar9;
  undefined4 *puVar10;
  uint *puVar11;
  uint uVar12;
  undefined4 *puVar13;
  ushort *puVar14;
  uint uVar15;
  undefined8 *puVar16;
  ulonglong uVar17;
  undefined2 uStack_e48;
  undefined auStack_e46 [2];
  uint uStack_e44;
  byte *pbStack_e40;
  undefined8 uStack_e38;
  uint uStack_e30;
  ushort uStack_e2c;
  undefined8 uStack_e2a;
  undefined8 uStack_e20;
  byte bStack_e10;
  char acStack_e0f [3];
  uint uStack_e0c;
  int *piStack_e08;
  longlong lStack_e00;
  ushort *puStack_df8;
  longlong lStack_de8;
  longlong lStack_de0;
  undefined4 auStack_dd8 [3];
  uint uStack_dcc;
  uint uStack_dc8;
  int iStack_dc4;
  longlong lStack_db8;
  undefined4 uStack_da8;
  undefined2 uStack_da4;
  undefined2 uStack_da2;
  longlong lStack_da0;
  longlong lStack_d98;
  int *piStack_d90;
  uint uStack_d88;
  undefined4 uStack_d84;
  ushort *puStack_d80;
  undefined8 uStack_d78;
  undefined8 uStack_d70;
  undefined4 uStack_d68;
  undefined8 uStack_d40;
  undefined4 uStack_d38;
  uint uStack_d34;
  undefined4 uStack_d30;
  undefined4 uStack_d2c;
  undefined4 uStack_d28;
  uint uStack_d24;
  undefined8 uStack_d20;
  uint uStack_d18;
  undefined4 uStack_d14;
  longlong *plStack_cf0;
  undefined8 uStack_ce8;
  undefined8 uStack_cd8;
  longlong lStack_cd0;
  longlong **pplStack_cc8;
  undefined auStack_c98 [16];
  undefined auStack_aa8 [2656];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)&uStack_e48;
  lStack_da0 = **(longlong **)(param_1 + 8);
  uStack_ce8 = param_5;
  lVar2 = *(longlong *)(lStack_da0 + 8);
  if (*(char *)(lVar2 + 0x106) < '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar12 = *(uint *)(**(longlong **)(lVar2 + 0x160) + 0x1c);
  uStack_da8 = *(undefined4 *)(lVar2 + 0x3c0);
  lStack_cd0 = (ulonglong)*(uint6 *)(lStack_da0 + 0x14) << 0x10;
  uStack_da4 = *(undefined2 *)(lVar2 + 0x3c4);
  uStack_da2 = 0;
  plStack_cf0 = *(longlong **)(lStack_da0 + 8);
  puStack_df8 = (ushort *)param_4;
  lStack_de0 = param_1;
  uStack_cd8 = param_2;
  if (*(int *)(param_1 + 0x40) != 0) {
    (**(code **)(*plStack_cf0 + 0xa0))(plStack_cf0,param_2,param_5);
    lVar2 = *(longlong *)(*(longlong *)(lStack_da0 + 8) + 0x488);
    if (((lVar2 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
      if (*(longlong *)(lVar2 + 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      LOCK();
      plVar1 = (longlong *)(*(longlong *)(lVar2 + 0x18) + 0x20);
      *plVar1 = *plVar1 + 1;
      UNLOCK();
    }
    func_0x(uStack_48 ^ (ulonglong)&uStack_e48);
    return;
  }
  pbStack_e40 = (byte *)0x0;
  uStack_e44 = 0;
  uStack_e2a = 0;
  uStack_e20 = 0;
  uStack_e38 = 0;
  func_0x(auStack_aa8,0,0xa58);
  lVar3 = *(longlong *)(param_1 + 0x138);
  auStack_c98 = ZEXT816(0);
  uStack_d84 = 0;
  iStack_dc4 = *(int *)(param_1 + 0x30) + 1;
  if (param_6 != 0) {
    iStack_dc4 = *(int *)(param_1 + 0x30);
  }
  if (lVar3 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((short)uVar12 != *(short *)(lVar3 + 0x62)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(ushort *)(lVar3 + 0x60) != 0) &&
     (puVar13 = *(undefined4 **)(lVar3 + 0x70), puVar13 != (undefined4 *)0x0)) {
    uVar17 = (ulonglong)*(ushort *)(lVar3 + 0x60);
    uVar8 = uVar17;
    puVar10 = puVar13;
    do {
      *(ushort *)((longlong)puVar10 + 6) = *(ushort *)((longlong)puVar10 + 6) & 0xffe0;
      *(undefined *)(puVar10 + 0x10) = 0;
      puVar10[0x10] = puVar10[0x10] & 0xffffe0ff;
      *(undefined *)(puVar10 + 0x10) = 0x1c;
      puVar10[0x10] = puVar10[0x10] & 0xffc01fff;
      *puVar10 = 0;
      *(undefined2 *)(puVar10 + 1) = 0;
      *(undefined8 *)(puVar10 + 2) = 0;
      *(undefined8 *)(puVar10 + 10) = 0;
      *(undefined8 *)(puVar10 + 0xc) = 0;
      puVar10[0xe] = 0xffffffff;
      *(undefined2 *)(puVar10 + 4) = 0xffff;
      *(undefined8 *)(puVar10 + 0x12) = 0;
      puVar10 = puVar10 + 0x14;
      uVar8 = uVar8 - 1;
    } while (uVar8 != 0);
    puVar16 = (undefined8 *)(puVar13 + 0x12);
    do {
      *puVar16 = puVar10;
      func_0x(puVar13);
      puVar13 = puVar13 + 0x14;
      puVar16 = puVar16 + 10;
      puVar10 = puVar10 + 0xc;
      uVar17 = uVar17 - 1;
    } while (uVar17 != 0);
    param_4 = puStack_df8;
    param_1 = lStack_de0;
    if ((*(longlong *)(lVar3 + 0xe8) != 0) && (uVar8 = 0, *(short *)(lVar3 + 0x60) != 0)) {
      do {
        uVar15 = (int)uVar8 + 1;
        *(ulonglong *)(*(longlong *)(lVar3 + 0xe8) + uVar8 * 8) =
             uVar8 * 0x50 + *(longlong *)(lVar3 + 0x70);
        uVar8 = (ulonglong)uVar15;
      } while (uVar15 < *(ushort *)(lVar3 + 0x60));
    }
  }
  lVar7 = lStack_da0;
  lVar3 = *(longlong *)(lStack_da0 + 8);
  if ((*(byte *)(lVar3 + 0x42) & 4) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar15 = *(uint *)(lVar3 + 0xb4);
  if (0xa58 < *(uint *)(lVar3 + 0xb4)) {
    uVar15 = 0xa58;
  }
  uVar15 = *(int *)(**(longlong **)(lVar3 + 0x160) + 0x1c) + uVar15;
  uVar12 = uVar15 + (uVar12 & 0xffff) * 9;
  if (uVar12 < uVar15) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong *)(param_1 + 0x140) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(uint *)(param_1 + 0x148) < uVar12) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  func_0x(lStack_da0,param_4,*(undefined8 *)(param_1 + 0x138),auStack_dd8,
                  *(longlong *)(param_1 + 0x140),*(uint *)(param_1 + 0x148));
  lVar3 = *(longlong *)(param_1 + 0x138);
  pplStack_cc8 = (longlong **)(param_1 + 0x18);
  uStack_d2c = 0;
  uStack_d28 = 2;
  uStack_d78 = 0;
  lStack_db8 = **pplStack_cc8;
  uStack_d38 = *(undefined4 *)(lVar3 + 0x3c);
  uStack_d34 = (uint)*(ushort *)(lStack_db8 + 0xe);
  uStack_d30 = auStack_dd8[0];
  uStack_d24 = (uint)*(ushort *)(lVar3 + 0x62);
  uVar4 = *(undefined8 *)(lVar3 + 0x70);
  *(undefined4 *)(lVar3 + 0x10) = uStack_d38;
  *(uint *)(lVar3 + 0x14) = uStack_d34;
  *(undefined4 *)(lVar3 + 0x18) = auStack_dd8[0];
  *(undefined4 *)(lVar3 + 0x1c) = 0;
  uStack_d20._0_4_ = (undefined4)uVar4;
  uStack_d20._4_4_ = (undefined4)((ulonglong)uVar4 >> 0x20);
  uStack_d40 = 0;
  *(undefined4 *)(lVar3 + 0x20) = 2;
  *(uint *)(lVar3 + 0x24) = uStack_d24;
  *(undefined4 *)(lVar3 + 0x28) = (undefined4)uStack_d20;
  *(undefined4 *)(lVar3 + 0x2c) = uStack_d20._4_4_;
  *(ulonglong *)(lVar3 + 0x30) = CONCAT44(uStack_d14,uStack_d18) & 0xfffffffffffffffe;
  lVar3 = *(longlong *)(param_1 + 0x138);
  puStack_df8 = *(ushort **)(param_1 + 0x140);
  piStack_e08 = *(int **)(lVar3 + 0x70);
  uStack_d88 = (uint)*(ushort *)(lVar3 + 0x62);
  lVar5 = **(longlong **)(*(longlong *)(lVar7 + 8) + 0x160);
  uStack_d84 = 0x10;
  uStack_d70 = *(undefined8 *)(lVar5 + 0xa8);
  uStack_d68 = *(undefined4 *)(lVar5 + 0xb0);
  if ((*(ushort *)(lVar3 + 0x38) & 0x400) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  bStack_e10 = *(byte *)(*(longlong *)(lVar7 + 8) + 0x42) & 4;
  if (*(int *)(lVar2 + 0x100) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar14 = (ushort *)0x0;
  uStack_e48 = 0;
  lStack_de8 = 0;
  uVar12 = -*(int *)(lVar3 + 0x10);
  uStack_dc8 = uVar12;
  lStack_d98 = lVar3;
  piStack_d90 = piStack_e08;
  puStack_d80 = puStack_df8;
  uStack_d20 = uVar4;
  uStack_d18 = uStack_d18 & 0xfffffffe;
  func_0x(auStack_e46,auStack_aa8,puStack_df8,*(int *)(lVar3 + 0x14) + -1,
                  *(undefined4 *)(lVar3 + 0x18),6);
  if (uVar12 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_dcc = (uint)*(ushort *)(lVar3 + 0x62);
  lStack_e00 = 0;
  uStack_e0c = 0;
  if (uStack_dcc != 0) {
    do {
      piVar6 = piStack_e08;
      uVar12 = 0x8000;
      func_0x(&lStack_d98,piStack_e08,acStack_e0f);
      if (acStack_e0f[0] == '\x03') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(short *)(piVar6 + 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      func_0x(&lStack_d98,piVar6,&lStack_e00);
      if ((*(char *)(piVar6 + 0x10) != '\x01') && (*(char *)(piVar6 + 0x10) != '\x02')) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (((uint)piVar6[0x10] >> 8 & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((uVar12 & piVar6[0x10]) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      puVar9 = puStack_df8;
      if ((*(byte *)(*(longlong *)(piVar6 + 0x12) + 0x2a) & 0x10) != 0) {
        puVar9 = puVar14;
      }
      uVar12 = *(uint *)((longlong)puVar9 + *(longlong *)(*(longlong *)(piVar6 + 0x12) + 0x18));
      uVar15 = (uint)*(ushort *)(piVar6 + 0xf);
      if (uVar12 < uVar15) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (uVar12 >= uVar15 && uVar12 != uVar15) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((lStack_e00 != 0) && (uVar12 != 0)) {
        func_0x(pbStack_e40 + *piVar6,lStack_e00,uVar12);
      }
      piStack_e08 = piVar6 + 0x14;
      uStack_e0c = uStack_e0c + 1;
      uVar12 = uStack_dc8;
    } while (uStack_e0c < uStack_dcc);
  }
  if (uVar12 != 0) {
    uVar8 = (ulonglong)uVar12;
    if (*(int *)((ulonglong)(uVar12 - 1) * 0x20 + 8 + lStack_de8) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uStack_e2c = (ushort)uVar12;
    uStack_e44 = uStack_e38._4_4_ + 2 + uVar12 * 2;
    *pbStack_e40 = *pbStack_e40 | 0x20;
    if (uStack_e44 < 0xa59) {
      puVar14 = (ushort *)(pbStack_e40 + uStack_e38._4_4_);
      *puVar14 = uStack_e2c;
    }
    if (uVar12 != 0) {
      puVar11 = (uint *)(lStack_de8 + 0xc);
      uStack_e30 = uStack_e44;
      do {
        puVar14 = puVar14 + 1;
        uVar12 = puVar11[-1];
        uVar17 = (ulonglong)uStack_e44;
        uStack_e44 = uStack_e44 + uVar12;
        if (uStack_e44 < 0xa59) {
          *puVar14 = (ushort)((*puVar11 & 1) << 0xf) | (ushort)uStack_e44 & 0x7fff;
          func_0x(pbStack_e40 + uVar17,uVar12,*(undefined8 *)(puVar11 + -3),uVar12);
        }
        puVar11 = puVar11 + 8;
        uVar8 = uVar8 - 1;
      } while (uVar8 != 0);
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

