
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,longlong param_3,longlong param_4)

{
  ushort *puVar1;
  ulonglong uVar2;
  short sVar3;
  undefined4 uVar4;
  ushort *puVar5;
  undefined auVar6 [14];
  undefined auVar7 [14];
  undefined auVar8 [14];
  undefined auVar9 [14];
  undefined auVar10 [14];
  undefined auVar11 [14];
  undefined auVar12 [14];
  undefined auVar13 [14];
  undefined auVar14 [14];
  undefined auVar15 [14];
  uint6 uVar16;
  undefined auVar17 [14];
  undefined auVar18 [14];
  undefined auVar19 [14];
  undefined auVar20 [14];
  undefined auVar21 [14];
  byte bVar22;
  char cVar23;
  undefined2 uVar24;
  ushort uVar25;
  ushort uVar26;
  longlong lVar27;
  undefined8 uVar28;
  ulonglong *puVar29;
  int *piVar30;
  byte *pbVar31;
  longlong lVar32;
  uint uVar33;
  uint uVar34;
  int iVar35;
  ulonglong uVar36;
  int iVar37;
  uint uVar38;
  uint uVar39;
  ulonglong uVar40;
  ulonglong uVar41;
  ulonglong uVar42;
  short *psVar43;
  ulonglong uVar44;
  ushort *puVar45;
  undefined *puVar46;
  undefined8 *puVar47;
  undefined2 uVar49;
  int iVar48;
  int iVar50;
  int aiStackX_20 [2];
  ushort *puStack_68;
  longlong alStack_60 [4];
  
  uVar24 = func_0x(param_4);
  iVar37 = 0;
  puVar1 = (ushort *)(param_4 + 2);
  iVar35 = 0;
  aiStackX_20[0] = 0;
  if (*(int *)(param_4 + 4) == 0) {
    pbVar31 = *(byte **)(param_4 + 8);
    uVar33 = *(uint *)(param_4 + 0x10);
    uVar42 = (ulonglong)uVar33;
    *puVar1 = 0;
    *(uint *)(param_4 + 0x14) = uVar33;
    bVar22 = *pbVar31;
    if ((bVar22 & 0x10) != 0) {
      uVar33 = uVar33 + 2 + (*(ushort *)(pbVar31 + uVar42) + 7 >> 3);
      uVar42 = (ulonglong)uVar33;
      *(uint *)(param_4 + 0x14) = uVar33;
      bVar22 = *pbVar31;
    }
    if ((bVar22 & 0x20) == 0) {
      *(int *)(param_4 + 4) = (int)uVar42;
      *(undefined2 *)(param_4 + 0x1c) = 0;
      *(int *)(param_4 + 0x18) = (int)uVar42;
    }
    else {
      puVar45 = (ushort *)(pbVar31 + uVar42);
      uVar25 = *puVar45;
      *(ushort *)(param_4 + 0x1c) = uVar25;
      if (uVar25 == 0) {
        cVar23 = func_0x(0x11b57a0);
        if (((cVar23 != '\0') && (lVar27 = func_0x(), lVar27 != 0)) &&
           (*(char *)(lVar27 + 0x499) != '\0')) {
          cVar23 = func_0x(0x11b57a0);
          if (cVar23 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0xaa51ac,0xbc5298,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),3);
        uVar42 = (ulonglong)*(uint *)(param_4 + 0x14);
        pbVar31 = *(byte **)(param_4 + 8);
        uVar25 = *(ushort *)(param_4 + 0x1c);
      }
      uVar33 = (int)uVar42 + (uVar25 + 1) * 2;
      *(uint *)(param_4 + 0x18) = uVar33;
      if (0x1f9e < uVar33) {
        cVar23 = func_0x(0x11b57a0);
        if (((cVar23 != '\0') && (lVar27 = func_0x(), lVar27 != 0)) &&
           (*(char *)(lVar27 + 0x499) != '\0')) {
          cVar23 = func_0x(0x11b57a0);
          if (cVar23 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xaa51ac,0xbc5298,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),4);
        uVar25 = *(ushort *)(param_4 + 0x1c);
        pbVar31 = *(byte **)(param_4 + 8);
        uVar33 = *(uint *)(param_4 + 0x18);
      }
      uVar36 = (ulonglong)uVar25;
      uVar34 = puVar45[uVar36] & 0x7fff;
      *(uint *)(param_4 + 4) = uVar34;
      if (uVar34 < uVar33) {
        cVar23 = func_0x(0x11b57a0);
        if (((cVar23 != '\0') && (lVar27 = func_0x(), lVar27 != 0)) &&
           (*(char *)(lVar27 + 0x499) != '\0')) {
          cVar23 = func_0x(0x11b57a0);
          if (cVar23 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xaa51ac,0xbc5298,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),4);
        uVar33 = *(uint *)(param_4 + 0x18);
        uVar36 = (ulonglong)*(ushort *)(param_4 + 0x1c);
        pbVar31 = *(byte **)(param_4 + 8);
        uVar34 = *(uint *)(param_4 + 4);
      }
      puVar5 = puVar45;
      if ((short)uVar36 != 0) {
        do {
          uVar39 = puVar5[1] & 0x7fff;
          if ((uVar39 < uVar33) || (uVar34 = *(uint *)(param_4 + 4), uVar34 < uVar39)) {
            cVar23 = func_0x(0x11b57a0);
            if ((cVar23 != '\0') &&
               ((lVar27 = func_0x(), lVar27 != 0 &&
                (*(char *)(lVar27 + 0x499) != '\0')))) {
              cVar23 = func_0x(0x11b57a0);
              if (cVar23 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0xaa51ac,0xbc5298,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_4 + 8),4);
            uVar34 = *(uint *)(param_4 + 4);
          }
          uVar36 = (ulonglong)*(ushort *)(param_4 + 0x1c);
          iVar37 = iVar37 + 1;
          uVar33 = uVar39;
          puVar5 = puVar5 + 1;
        } while (iVar37 < (int)(uint)*(ushort *)(param_4 + 0x1c));
        pbVar31 = *(byte **)(param_4 + 8);
      }
      uVar42 = (ulonglong)uVar34;
      if ((short)puVar45[(ulonglong)((int)uVar36 - 1) + 1] < 0) {
LAB_:
        uVar33 = *(ushort *)(pbVar31 + uVar36 * 2 + (ulonglong)*(uint *)(param_4 + 0x14)) & 0x7fff;
        if ((int)uVar36 == 1) {
          uVar34 = *(uint *)(param_4 + 0x18);
          uVar40 = (ulonglong)uVar34;
LAB_:
          if ((uVar33 < (uint)uVar40) || (uVar39 = *(uint *)(param_4 + 4), uVar39 < uVar33))
          goto LAB_;
        }
        else {
          uVar34 = *(uint *)(param_4 + 0x18);
          uVar40 = (ulonglong)
                   (*(ushort *)(pbVar31 + uVar36 * 2 + ((ulonglong)*(uint *)(param_4 + 0x14) - 2)) &
                   0x7fff);
          if (uVar34 <= (*(ushort *)
                          (pbVar31 + uVar36 * 2 + ((ulonglong)*(uint *)(param_4 + 0x14) - 2)) &
                        0x7fff)) goto LAB_;
LAB_:
          func_0x(pbVar31,7);
          uVar39 = *(uint *)(param_4 + 4);
          uVar34 = *(uint *)(param_4 + 0x18);
          pbVar31 = *(byte **)(param_4 + 8);
        }
        uVar42 = (ulonglong)uVar39;
        uVar38 = (uint)uVar40;
        if ((uVar34 <= uVar38) && (uVar38 <= uVar39)) {
          if (*(ushort *)(pbVar31 + uVar40) == 5) {
            *puVar1 = *puVar1 | 2;
            *(short *)(param_4 + 0x1c) = *(short *)(param_4 + 0x1c) + -1;
            uVar25 = *(ushort *)(param_4 + 0x2c) & 0xc7ff;
            uVar36 = uVar40 & 0xffff;
            *(short *)(param_4 + 0x2a) = (short)uVar40;
            uVar42 = *(ulonglong *)(param_4 + 8);
            if ((*(ushort *)(uVar36 + 2 + uVar42) >> 0xe & 1) != 0) {
              uVar25 = *(ushort *)(uVar36 + 2 + uVar42) & 0x3800 | uVar25;
            }
            *(ushort *)(param_4 + 0x2c) = uVar25;
            uVar26 = (uVar25 ^ *(ushort *)(uVar36 + 2 + uVar42)) & 0x7ff ^ uVar25;
            *(ushort *)(param_4 + 0x2c) = uVar26;
            uVar41 = (ulonglong)((uVar26 & 0x7ff) * 2) + 4 + uVar42 + (uVar25 >> 0xb & 7) * 2 +
                     uVar36;
            uVar40 = uVar42;
            if (uVar41 < uVar36 + uVar42) {
              func_0x(uVar36 + uVar42,0x19);
              uVar26 = *(ushort *)(param_4 + 0x2c);
              uVar36 = (ulonglong)*(ushort *)(param_4 + 0x2a);
              uVar40 = (ulonglong)*(uint *)(param_4 + 8);
              uVar42 = *(ulonglong *)(param_4 + 8);
            }
            if (uVar33 - uVar38 < (((uVar26 & 0x7ff) * 2 - (int)uVar36) - (int)uVar40) + (int)uVar41
               ) {
              func_0x(uVar36 + uVar42,0x19);
              uVar26 = *(ushort *)(param_4 + 0x2c);
              uVar36 = (ulonglong)*(ushort *)(param_4 + 0x2a);
              uVar42 = *(ulonglong *)(param_4 + 8);
            }
            if ((uVar26 & 0x3800) != 0) {
              puVar45 = (ushort *)(uVar42 + 4 + uVar36);
              iVar37 = 0;
              if ((uVar26 & 0x3800) != 0) {
                do {
                  if ((uVar26 & 0x7ff) < (*puVar45 & 0x7ff)) {
                    func_0x((ulonglong)*(ushort *)(param_4 + 0x2a) +
                                    *(longlong *)(param_4 + 8),0x1a);
                    uVar26 = *(ushort *)(param_4 + 0x2c);
                  }
                  iVar37 = iVar37 + 1;
                  puVar45 = puVar45 + 1;
                } while (iVar37 < (int)(uVar26 >> 0xb & 7));
              }
            }
            pbVar31 = *(byte **)(param_4 + 8);
            uVar42 = (ulonglong)*(uint *)(param_4 + 4);
          }
          else if (0x3ff < *(ushort *)(pbVar31 + uVar40)) goto code_r0x001003eb;
          goto LAB_;
        }
        goto LAB_;
      }
    }
LAB_:
    if ((*pbVar31 & 0x40) == 0) {
      *(undefined4 *)(param_4 + 0x26) = 0;
    }
    else {
      *(int *)(param_4 + 0x26) = (int)uVar42;
      *(int *)(param_4 + 4) = (int)uVar42 + 0xe;
      uVar28 = func_0x(puVar1);
      func_0x(uVar28,alStack_60);
      iVar37 = func_0x(alStack_60);
      *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + iVar37;
      uVar42 = (ulonglong)*(uint *)(param_4 + 4);
      pbVar31 = *(byte **)(param_4 + 8);
    }
    if ((*(byte **)(param_4 + 0x1e) != (byte *)0x0) &&
       (*(byte **)(param_4 + 0x1e) < pbVar31 + uVar42)) {
      cVar23 = func_0x(0x11b57a0);
      if ((cVar23 != '\0') &&
         ((lVar27 = func_0x(), lVar27 != 0 && (*(char *)(lVar27 + 0x499) != '\0'))))
      {
        cVar23 = func_0x(0x11b57a0);
        if (cVar23 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0xaa51ac,0xbc5298,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(param_4 + 8),0x12);
      uVar42 = (ulonglong)*(uint *)(param_4 + 4);
    }
    if (0x3f3b < (int)uVar42 - 1U) {
      cVar23 = func_0x(0x11b57a0);
      if (((cVar23 != '\0') && (lVar27 = func_0x(), lVar27 != 0)) &&
         (*(char *)(lVar27 + 0x499) != '\0')) {
        cVar23 = func_0x(0x11b57a0);
        if (cVar23 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0xaa51ac,0xbc5298,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(param_4 + 8),5);
    }
  }
LAB_:
  iVar37 = func_0x(puVar1);
  if (iVar37 != 0) {
    uVar25 = *(ushort *)(param_4 + 0x2c);
    iVar35 = *(int *)(param_4 + 4) - (uint)*(ushort *)(param_4 + 0x2a);
    uVar33 = (uint)uVar25;
    iVar37 = iVar35 + -10;
    if ((*(byte *)puVar1 & 1) == 0) {
      iVar37 = iVar35;
    }
    if ((**(byte **)(param_4 + 8) & 0x40) != 0) {
      lVar27 = func_0x(puVar1,aiStackX_20);
      uVar34 = 0;
      uVar25 = *(ushort *)(lVar27 + 6);
      uVar26 = uVar25;
      if ((((uint)(int)(short)uVar25 >> 1 ^ (int)(short)uVar25) & 0x2000) != 0) {
        uVar26 = uVar25 & 0xdfff;
        if ((uVar25 >> 0xe & 1) != 0) {
          uVar26 = uVar25 | 0x2000;
        }
      }
      if (uVar26 == 0xfffc) {
        uVar34 = (uint)(*(ushort *)(lVar27 + 4) >> 5);
      }
      uVar25 = *(ushort *)(param_4 + 0x2c);
      iVar37 = (iVar37 - uVar34) + -0xe;
    }
    iVar35 = (uVar33 & 0x7ff) * 4 + -4 + iVar37 + ((uVar25 >> 0xb & 7) + (uVar25 & 0x7ff)) * -2;
    aiStackX_20[0] = iVar35;
  }
  lVar27 = *(longlong *)(param_2 + 0x48);
  if ((uint)*(ushort *)(lVar27 + 0x20) < iVar35 + 0x17U) {
    (*_DAT_)(1,0xc81bf0,0xc81bc0,0x4cd,0);
    lVar27 = *(longlong *)(param_2 + 0x48);
  }
  if (((*(uint *)(param_2 + 0x40) & 0x48000) == 0x48000) && ((*(byte *)(param_3 + 0x14) & 8) != 0))
  {
    puVar47 = *(undefined8 **)
               (*(longlong *)(param_3 + 0x40) + (ulonglong)*(uint *)(param_2 + 0x38) * 8);
  }
  else {
    if ((*(byte *)(lVar27 + 0x2a) & 0x10) == 0) {
      lVar27 = *(longlong *)(param_3 + 0x18);
    }
    else {
      lVar27 = *(longlong *)(param_3 + 0x20);
    }
    puVar47 = (undefined8 *)(*(longlong *)(param_2 + 0x28) + lVar27);
    if ((*(uint *)(param_2 + 0x40) >> 0xb & 1) != 0) {
      puVar47 = (undefined8 *)*puVar47;
    }
  }
  *(undefined4 *)((longlong)puVar47 + -4) = 3;
  uVar42 = 0;
  iVar37 = 0;
  if (*(int *)(param_4 + 4) == 0) {
    pbVar31 = *(byte **)(param_4 + 8);
    uVar33 = *(uint *)(param_4 + 0x10);
    uVar36 = (ulonglong)uVar33;
    *puVar1 = 0;
    *(uint *)(param_4 + 0x14) = uVar33;
    bVar22 = *pbVar31;
    if ((bVar22 & 0x10) != 0) {
      uVar33 = uVar33 + 2 + (*(ushort *)(pbVar31 + uVar36) + 7 >> 3);
      uVar36 = (ulonglong)uVar33;
      *(uint *)(param_4 + 0x14) = uVar33;
      bVar22 = *pbVar31;
    }
    if ((bVar22 & 0x20) == 0) {
      *(int *)(param_4 + 4) = (int)uVar36;
      *(undefined2 *)(param_4 + 0x1c) = 0;
      *(int *)(param_4 + 0x18) = (int)uVar36;
    }
    else {
      puVar45 = (ushort *)(pbVar31 + uVar36);
      uVar25 = *puVar45;
      *(ushort *)(param_4 + 0x1c) = uVar25;
      if (uVar25 == 0) {
        cVar23 = func_0x(0x11b57a0);
        if (((cVar23 != '\0') && (lVar27 = func_0x(), lVar27 != 0)) &&
           (*(char *)(lVar27 + 0x499) != '\0')) {
          cVar23 = func_0x(0x11b57a0);
          if (cVar23 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0xaa51ac,0xbc5298,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),3);
        uVar36 = (ulonglong)*(uint *)(param_4 + 0x14);
        pbVar31 = *(byte **)(param_4 + 8);
        uVar25 = *(ushort *)(param_4 + 0x1c);
      }
      uVar33 = (int)uVar36 + (uVar25 + 1) * 2;
      *(uint *)(param_4 + 0x18) = uVar33;
      if (0x1f9e < uVar33) {
        cVar23 = func_0x(0x11b57a0);
        if (((cVar23 != '\0') && (lVar27 = func_0x(), lVar27 != 0)) &&
           (*(char *)(lVar27 + 0x499) != '\0')) {
          cVar23 = func_0x(0x11b57a0);
          if (cVar23 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xaa51ac,0xbc5298,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),4);
        uVar25 = *(ushort *)(param_4 + 0x1c);
        pbVar31 = *(byte **)(param_4 + 8);
        uVar33 = *(uint *)(param_4 + 0x18);
      }
      uVar40 = (ulonglong)uVar25;
      uVar34 = puVar45[uVar40] & 0x7fff;
      *(uint *)(param_4 + 4) = uVar34;
      if (uVar34 < uVar33) {
        cVar23 = func_0x(0x11b57a0);
        if (((cVar23 != '\0') && (lVar27 = func_0x(), lVar27 != 0)) &&
           (*(char *)(lVar27 + 0x499) != '\0')) {
          cVar23 = func_0x(0x11b57a0);
          if (cVar23 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xaa51ac,0xbc5298,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),4);
        uVar33 = *(uint *)(param_4 + 0x18);
        uVar40 = (ulonglong)*(ushort *)(param_4 + 0x1c);
        pbVar31 = *(byte **)(param_4 + 8);
        uVar34 = *(uint *)(param_4 + 4);
      }
      uVar36 = uVar42;
      puVar5 = puVar45;
      if ((short)uVar40 != 0) {
        do {
          uVar39 = puVar5[1] & 0x7fff;
          if ((uVar39 < uVar33) || (uVar34 = *(uint *)(param_4 + 4), uVar34 < uVar39)) {
            cVar23 = func_0x(0x11b57a0);
            if ((cVar23 != '\0') &&
               ((lVar27 = func_0x(), lVar27 != 0 &&
                (*(char *)(lVar27 + 0x499) != '\0')))) {
              cVar23 = func_0x(0x11b57a0);
              if (cVar23 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0xaa51ac,0xbc5298,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_4 + 8),4);
            uVar34 = *(uint *)(param_4 + 4);
          }
          uVar40 = (ulonglong)*(ushort *)(param_4 + 0x1c);
          uVar38 = (int)uVar36 + 1;
          uVar36 = (ulonglong)uVar38;
          uVar33 = uVar39;
          puVar5 = puVar5 + 1;
        } while ((int)uVar38 < (int)(uint)*(ushort *)(param_4 + 0x1c));
        pbVar31 = *(byte **)(param_4 + 8);
      }
      uVar36 = (ulonglong)uVar34;
      if ((short)puVar45[(ulonglong)((int)uVar40 - 1) + 1] < 0) {
LAB_:
        uVar33 = *(ushort *)(pbVar31 + uVar40 * 2 + (ulonglong)*(uint *)(param_4 + 0x14)) & 0x7fff;
        if ((int)uVar40 == 1) {
          uVar34 = *(uint *)(param_4 + 0x18);
          uVar39 = uVar34;
LAB_:
          if ((uVar33 < uVar34) || (uVar38 = *(uint *)(param_4 + 4), uVar38 < uVar33))
          goto LAB_;
        }
        else {
          uVar39 = *(uint *)(param_4 + 0x18);
          uVar34 = *(ushort *)(pbVar31 + uVar40 * 2 + ((ulonglong)*(uint *)(param_4 + 0x14) - 2)) &
                   0x7fff;
          if (uVar39 <= uVar34) goto LAB_;
LAB_:
          func_0x(pbVar31,7);
          uVar38 = *(uint *)(param_4 + 4);
          uVar39 = *(uint *)(param_4 + 0x18);
          pbVar31 = *(byte **)(param_4 + 8);
        }
        uVar36 = (ulonglong)uVar38;
        if ((uVar39 <= uVar34) && (uVar34 <= uVar38)) {
          if (*(ushort *)(pbVar31 + uVar34) == 5) {
            *puVar1 = *puVar1 | 2;
            *(short *)(param_4 + 0x1c) = *(short *)(param_4 + 0x1c) + -1;
            uVar36 = *(ulonglong *)(param_4 + 8);
            uVar25 = *(ushort *)(param_4 + 0x2c) & 0xc7ff;
            uVar40 = (ulonglong)(uVar34 & 0xffff);
            *(short *)(param_4 + 0x2a) = (short)uVar34;
            if ((*(ushort *)(uVar40 + 2 + uVar36) & 0x4000) != 0) {
              uVar25 = *(ushort *)(uVar40 + 2 + uVar36) & 0x3800 | uVar25;
            }
            *(ushort *)(param_4 + 0x2c) = uVar25;
            uVar44 = (ulonglong)*(ushort *)(param_4 + 0x2a);
            uVar26 = (uVar25 ^ *(ushort *)(uVar40 + 2 + uVar36)) & 0x7ff ^ uVar25;
            *(ushort *)(param_4 + 0x2c) = uVar26;
            uVar41 = uVar36 + 4 +
                     (ulonglong)((uVar26 & 0x7ff) * 2) + uVar44 + (uVar25 >> 0xb & 7) * 2;
            uVar40 = uVar36;
            if (uVar41 < uVar44 + uVar36) {
              func_0x(uVar44 + uVar36,0x19);
              uVar26 = *(ushort *)(param_4 + 0x2c);
              uVar44 = (ulonglong)*(ushort *)(param_4 + 0x2a);
              uVar40 = (ulonglong)*(uint *)(param_4 + 8);
              uVar36 = *(ulonglong *)(param_4 + 8);
            }
            if (uVar33 - uVar34 < (((uVar26 & 0x7ff) * 2 - (int)uVar44) - (int)uVar40) + (int)uVar41
               ) {
              func_0x(uVar44 + uVar36,0x19);
              uVar26 = *(ushort *)(param_4 + 0x2c);
              uVar44 = (ulonglong)*(ushort *)(param_4 + 0x2a);
              uVar36 = *(ulonglong *)(param_4 + 8);
            }
            if (((uVar26 & 0x3800) != 0) &&
               (puVar45 = (ushort *)(uVar36 + 4 + uVar44), uVar36 = uVar42, (uVar26 & 0x3800) != 0))
            {
              do {
                if ((uVar26 & 0x7ff) < (*puVar45 & 0x7ff)) {
                  func_0x((ulonglong)*(ushort *)(param_4 + 0x2a) +
                                  *(longlong *)(param_4 + 8),0x1a);
                  uVar26 = *(ushort *)(param_4 + 0x2c);
                }
                uVar33 = (int)uVar36 + 1;
                puVar45 = puVar45 + 1;
                uVar36 = (ulonglong)uVar33;
              } while ((int)uVar33 < (int)(uVar26 >> 0xb & 7));
            }
            pbVar31 = *(byte **)(param_4 + 8);
            uVar36 = (ulonglong)*(uint *)(param_4 + 4);
          }
          else if (0x3ff < *(ushort *)(pbVar31 + uVar34)) goto code_r0x00100c0b;
          goto LAB_;
        }
        goto LAB_;
      }
    }
LAB_:
    if ((*pbVar31 & 0x40) == 0) {
      *(undefined4 *)(param_4 + 0x26) = 0;
    }
    else {
      *(int *)(param_4 + 0x26) = (int)uVar36;
      *(int *)(param_4 + 4) = (int)uVar36 + 0xe;
      puVar29 = (ulonglong *)func_0x(puVar1);
      uVar36 = *puVar29;
      uVar26 = (ushort)(uVar36 >> 0x30);
      uVar25 = uVar26;
      if ((((uint)(int)(short)uVar26 >> 1 ^ (int)(short)uVar26) & 0x2000) != 0) {
        uVar25 = uVar26 & 0xdfff;
        if ((uVar36 & 0x4000000000000000) != 0) {
          uVar25 = uVar26 | 0x2000;
        }
      }
      if (uVar25 == 0xfffc) {
        iVar37 = (int)((uVar36 >> 0x20 & 0xffff) >> 5);
      }
      *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + iVar37;
      uVar36 = (ulonglong)*(uint *)(param_4 + 4);
      pbVar31 = *(byte **)(param_4 + 8);
    }
    if ((*(byte **)(param_4 + 0x1e) != (byte *)0x0) &&
       (*(byte **)(param_4 + 0x1e) < pbVar31 + uVar36)) {
      cVar23 = func_0x(0x11b57a0);
      if ((cVar23 != '\0') &&
         ((lVar27 = func_0x(), lVar27 != 0 && (*(char *)(lVar27 + 0x499) != '\0'))))
      {
        cVar23 = func_0x(0x11b57a0);
        if (cVar23 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0xaa51ac,0xbc5298,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(param_4 + 8),0x12);
      uVar36 = (ulonglong)*(uint *)(param_4 + 4);
    }
    if (0x3f3b < (int)uVar36 - 1U) {
      cVar23 = func_0x(0x11b57a0);
      if (((cVar23 != '\0') && (lVar27 = func_0x(), lVar27 != 0)) &&
         (*(char *)(lVar27 + 0x499) != '\0')) {
        cVar23 = func_0x(0x11b57a0);
        if (cVar23 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0xaa51ac,0xbc5298,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(param_4 + 8),5);
    }
  }
LAB_:
  uVar41 = (ulonglong)*(ushort *)(param_4 + 0x2c);
  alStack_60[0] = *(longlong *)(param_4 + 8) + (ulonglong)*(ushort *)(param_4 + 0x2a);
  puStack_68 = (ushort *)(alStack_60[0] + 4);
  lVar27 = *(longlong *)(param_4 + 8) + 4 +
           (ulonglong)((*(ushort *)(param_4 + 0x2c) >> 0xb & 7) * 2) +
           (ulonglong)*(ushort *)(param_4 + 0x2a);
  uVar36 = uVar42;
  uVar40 = uVar42;
  do {
    uVar34 = (uint)uVar41;
    uVar33 = uVar34;
    if ((uVar41 & 0x3800) == 0) {
      uVar25 = *(ushort *)((ulonglong)*(ushort *)(param_4 + 0x2a) + 2 + *(longlong *)(param_4 + 8));
    }
    else {
      if ((int)((uint)(uVar41 >> 0xb) & 7) <= (int)uVar36) {
        func_0x(alStack_60[0],0x1b);
        uVar33 = (uint)*(ushort *)(param_4 + 0x2c);
      }
      uVar25 = *puStack_68;
      uVar34 = (uint)uVar25;
    }
    uVar25 = uVar25 >> 0xb;
    uVar41 = (ulonglong)(uVar34 & 0x7ff);
    iVar37 = (uVar34 & 0x7ff) - 1;
    uVar34 = CONCAT22(uVar25,uVar25) & 0x70007;
    if ((int)(uVar33 & 0x7ff) <= iVar37) {
      func_0x(alStack_60[0],0x1a);
    }
    iVar35 = (int)uVar40;
    uVar33 = (iVar37 - iVar35) + 1;
    if ((iVar35 <= iVar37) && (0xf < uVar33)) {
      if (((undefined *)(lVar27 + (uVar41 - 1) * 2) <
           (undefined *)((longlong)puVar47 + (longlong)iVar35 * 4 + 0x17)) ||
         ((undefined *)((longlong)puVar47 + uVar41 * 4 + 0x13) <
          (undefined *)(lVar27 + (longlong)iVar35 * 2))) {
        uVar33 = uVar33 & 0x8000000f;
        if ((int)uVar33 < 0) {
          uVar33 = (uVar33 - 1 | 0xfffffff0) + 1;
        }
        uVar49 = (undefined2)(uVar34 >> 0x10);
        auVar6._12_2_ = uVar49;
        auVar6._0_12_ = ZEXT812(0);
        uVar16 = CONCAT42(auVar6._10_4_,(short)uVar34);
        auVar21._6_8_ = 0;
        auVar21._0_6_ = uVar16;
        auVar15._6_8_ = SUB148(auVar21 << 0x40,6);
        auVar15._0_6_ = CONCAT24(uVar49,CONCAT22(uVar25,uVar25)) & 0xffff00070007;
        iVar35 = uVar34 * 0x10000;
        iVar48 = auVar15._4_4_;
        iVar50 = (int)uVar16;
        uVar34 = auVar6._10_4_ >> 0x10;
        piVar30 = (int *)((longlong)puVar47 + uVar42 * 4 + 0x37);
        puVar29 = (ulonglong *)(lVar27 + 0x10 + uVar42 * 2);
        do {
          uVar44 = puVar29[-2];
          uVar2 = puVar29[-1];
          uVar40 = (ulonglong)((int)uVar40 + 0x10);
          auVar7._8_4_ = 0;
          auVar7._0_8_ = uVar44;
          auVar7._12_2_ = (short)(uVar44 >> 0x30);
          auVar11._8_2_ = (short)(uVar44 >> 0x20);
          auVar11._0_8_ = uVar44;
          auVar11._10_4_ = auVar7._10_4_;
          auVar17._6_8_ = 0;
          auVar17._0_6_ = auVar11._8_6_;
          uVar42 = uVar42 + 0x10;
          auVar8._8_4_ = 0;
          auVar8._0_8_ = uVar2;
          auVar8._12_2_ = (short)(uVar2 >> 0x30);
          auVar12._8_2_ = (short)(uVar2 >> 0x20);
          auVar12._0_8_ = uVar2;
          auVar12._10_4_ = auVar8._10_4_;
          auVar18._6_8_ = 0;
          auVar18._0_6_ = auVar12._8_6_;
          piVar30[-8] = (uint)(ushort)uVar44 + iVar35;
          piVar30[-7] = (int)CONCAT82(SUB148(auVar17 << 0x40,6),(short)(uVar44 >> 0x10)) + iVar48;
          piVar30[-6] = auVar11._8_4_ + iVar50;
          piVar30[-5] = (auVar7._10_4_ >> 0x10) + uVar34;
          uVar44 = *puVar29;
          auVar9._8_4_ = 0;
          auVar9._0_8_ = uVar44;
          auVar9._12_2_ = (short)(uVar44 >> 0x30);
          auVar13._8_2_ = (short)(uVar44 >> 0x20);
          auVar13._0_8_ = uVar44;
          auVar13._10_4_ = auVar9._10_4_;
          auVar19._6_8_ = 0;
          auVar19._0_6_ = auVar13._8_6_;
          piVar30[-4] = (uint)(ushort)uVar2 + iVar35;
          piVar30[-3] = (int)CONCAT82(SUB148(auVar18 << 0x40,6),(short)(uVar2 >> 0x10)) + iVar48;
          piVar30[-2] = auVar12._8_4_ + iVar50;
          piVar30[-1] = (auVar8._10_4_ >> 0x10) + uVar34;
          uVar2 = puVar29[1];
          auVar10._8_4_ = 0;
          auVar10._0_8_ = uVar2;
          auVar10._12_2_ = (short)(uVar2 >> 0x30);
          auVar14._8_2_ = (short)(uVar2 >> 0x20);
          auVar14._0_8_ = uVar2;
          auVar14._10_4_ = auVar10._10_4_;
          auVar20._6_8_ = 0;
          auVar20._0_6_ = auVar14._8_6_;
          *piVar30 = (uint)(ushort)uVar44 + iVar35;
          piVar30[1] = (int)CONCAT82(SUB148(auVar19 << 0x40,6),(short)(uVar44 >> 0x10)) + iVar48;
          piVar30[2] = auVar13._8_4_ + iVar50;
          piVar30[3] = (auVar9._10_4_ >> 0x10) + uVar34;
          piVar30[4] = (uint)(ushort)uVar2 + iVar35;
          piVar30[5] = (int)CONCAT82(SUB148(auVar20 << 0x40,6),(short)(uVar2 >> 0x10)) + iVar48;
          piVar30[6] = auVar14._8_4_ + iVar50;
          piVar30[7] = (auVar10._10_4_ >> 0x10) + uVar34;
          piVar30 = piVar30 + 0x10;
          puVar29 = puVar29 + 4;
        } while ((longlong)uVar42 <= (longlong)(int)(iVar37 - uVar33));
      }
    }
    lVar32 = uVar41 - 1;
    if ((longlong)uVar42 <= lVar32) {
      uVar40 = (ulonglong)(uint)((int)uVar40 + 1 + ((int)lVar32 - (int)uVar42));
      do {
        *(uint *)((longlong)puVar47 + uVar42 * 4 + 0x17) =
             (uint)*(ushort *)(lVar27 + uVar42 * 2) + (uint)(uVar25 & 7) * 0x10000;
        uVar42 = uVar42 + 1;
      } while ((longlong)uVar42 <= lVar32);
    }
    uVar25 = *(ushort *)(param_4 + 0x2c);
    uVar41 = (ulonglong)uVar25;
    puStack_68 = puStack_68 + 1;
    uVar36 = (ulonglong)((int)uVar36 + 1);
  } while ((int)uVar40 < (int)(uVar25 & 0x7ff));
  puVar46 = (undefined *)((uVar41 & 0x7ff) * 4 + 0x17 + (longlong)puVar47);
  iVar35 = *(int *)(param_4 + 4) - (uint)*(ushort *)(param_4 + 0x2a);
  psVar43 = (short *)(*(longlong *)(param_4 + 8) + 4 +
                     (ulonglong)((uVar25 >> 0xb & 7) * 2) + (ulonglong)((uVar25 & 0x7ff) * 2) +
                     (ulonglong)*(ushort *)(param_4 + 0x2a));
  iVar37 = iVar35 + -10;
  if ((*(byte *)puVar1 & 1) == 0) {
    iVar37 = iVar35;
  }
  if ((**(byte **)(param_4 + 8) & 0x40) != 0) {
    lVar27 = func_0x(puVar1,&puStack_68);
    uVar33 = 0;
    uVar25 = *(ushort *)(lVar27 + 6);
    uVar26 = uVar25;
    if ((((uint)(int)(short)uVar25 >> 1 ^ (int)(short)uVar25) & 0x2000) != 0) {
      uVar26 = uVar25 & 0xdfff;
      if ((uVar25 >> 0xe & 1) != 0) {
        uVar26 = uVar25 | 0x2000;
      }
    }
    if (uVar26 == 0xfffc) {
      uVar33 = (uint)(*(ushort *)(lVar27 + 4) >> 5);
    }
    iVar37 = (iVar37 - uVar33) + -0xe;
  }
  lVar27 = alStack_60[0];
  func_0x(puVar46,psVar43,((int)alStack_60[0] - (int)psVar43) + iVar37);
  uVar25 = *(ushort *)(param_4 + 0x2c);
  uVar33 = 0;
  sVar3 = *(short *)(param_4 + 0x2a);
  uVar4 = *(undefined4 *)(param_4 + 8);
  if ((uVar25 & 0x7ff) != 0) {
    do {
      puVar1 = (ushort *)(puVar46 + (ulonglong)uVar33 * 2);
      uVar33 = uVar33 + 1;
      *puVar1 = *puVar1 ^ (*psVar43 -
                           ((((uVar25 >> 0xb & 7) + 2 + (uVar25 & 0x7ff) * 2) * 2 - (short)lVar27) +
                            sVar3 + (short)uVar4) ^ *puVar1) & 0x7fff;
      psVar43 = psVar43 + 1;
    } while ((int)uVar33 < (int)(*(ushort *)(param_4 + 0x2c) & 0x7ff));
  }
  uVar28 = *(undefined8 *)(param_1 + 0x28);
  uVar49 = *(undefined2 *)(param_1 + 0x30);
  uVar4 = *(undefined4 *)(param_1 + 0x20);
  *(undefined2 *)((longlong)puVar47 + 1) = 0;
  *(undefined8 *)((longlong)puVar47 + 0xd) = uVar28;
  *(undefined2 *)((longlong)puVar47 + 5) = uVar24;
  *(short *)((longlong)puVar47 + 3) = (short)aiStackX_20[0];
  *(undefined2 *)((longlong)puVar47 + 7) = 0xffff;
  *(undefined *)puVar47 = 1;
  *(undefined2 *)((longlong)puVar47 + 0x15) = uVar49;
  *(undefined4 *)((longlong)puVar47 + 9) = uVar4;
  if ((*(byte *)(*(longlong *)(param_2 + 0x48) + 0x2a) & 0x10) == 0) {
    lVar27 = *(longlong *)(param_3 + 0x18);
  }
  else {
    lVar27 = *(longlong *)(param_3 + 0x20);
  }
  *(ulonglong *)(lVar27 + *(longlong *)(*(longlong *)(param_2 + 0x48) + 0x18)) =
       (ulonglong)(ushort)((short)aiStackX_20[0] + 0x17);
  return;
code_r0x001003eb:
  *puVar1 = *puVar1 | 1;
  uVar25 = *(short *)(param_4 + 0x1c) - 1;
  *(ushort *)(param_4 + 0x1c) = uVar25;
  if ((uVar25 == 0) ||
     (uVar36 = (ulonglong)uVar25, -1 < (short)puVar45[(ulonglong)(uVar25 - 1) + 1]))
  goto LAB_;
  goto LAB_;
code_r0x00100c0b:
  *puVar1 = *puVar1 | 1;
  uVar25 = *(short *)(param_4 + 0x1c) - 1;
  *(ushort *)(param_4 + 0x1c) = uVar25;
  if ((uVar25 == 0) ||
     (uVar40 = (ulonglong)uVar25, -1 < (short)puVar45[(ulonglong)(uVar25 - 1) + 1]))
  goto LAB_;
  goto LAB_;
}

