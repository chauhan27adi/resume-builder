
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,undefined4 param_2,uint *param_3,undefined4 *param_4)

{
  ushort *puVar1;
  byte **ppbVar2;
  byte bVar3;
  char cVar4;
  ushort uVar5;
  ushort uVar6;
  int iVar7;
  longlong lVar8;
  longlong lVar9;
  undefined8 uVar10;
  short sVar11;
  uint uVar12;
  ulonglong uVar13;
  uint uVar14;
  short *psVar15;
  uint uVar16;
  ushort *puVar17;
  ushort *puVar18;
  ulonglong uVar19;
  byte *pbVar20;
  ulonglong uVar21;
  int iVar22;
  short *psStackX_8;
  int aiStackX_10 [2];
  ushort *puStackX_18;
  undefined4 *puStackX_20;
  undefined auStack_58 [4];
  undefined auStack_54 [4];
  undefined auStack_50 [16];
  
  sVar11 = *(short *)(param_3 + 1);
  iVar7 = 0;
  *(undefined4 *)((longlong)param_4 + 6) = 0;
  *param_4 = param_2;
  aiStackX_10[0] = 0;
  psStackX_8 = param_1;
  puStackX_20 = param_4;
  if (*param_1 != 0) {
    if (*param_1 != 1) {
      (*_DAT_)(1,0xb77fe0,0xb7e3d8,0x362,0x771c50);
      return;
    }
    psStackX_8 = (short *)((ulonglong)param_1 & 0xffffffff00000000);
    puStackX_20 = (undefined4 *)((ulonglong)param_4 & 0xffffffff00000000);
    func_0x(param_1 + 1,param_3,param_3,aiStackX_10,&psStackX_8);
    *(undefined2 *)(param_4 + 1) = (undefined2)aiStackX_10[0];
    if (((ulonglong)psStackX_8 & 1) != 0) {
      *(ushort *)((longlong)param_4 + 6) = *(ushort *)((longlong)param_4 + 6) | 1;
    }
    if (((ulonglong)psStackX_8 & 0x10) != 0) {
      *(ushort *)((longlong)param_4 + 6) = *(ushort *)((longlong)param_4 + 6) | 2;
    }
    if (((ulonglong)psStackX_8 & 4) != 0) {
      *(ushort *)((longlong)param_4 + 6) = *(ushort *)((longlong)param_4 + 6) | 4;
    }
    if (*param_1 == 0) {
      return;
    }
    ppbVar2 = *(byte ***)(param_1 + 8);
    if (ppbVar2 == (byte **)0x0) {
      return;
    }
    if ((**ppbVar2 & 2) == 0) {
      return;
    }
    lVar8 = func_0x(ppbVar2,param_3,&puStackX_20);
    if (lVar8 == 0) {
      return;
    }
    *(undefined2 *)(param_4 + 2) = puStackX_20._0_2_;
    return;
  }
  uVar12 = *param_3;
  puVar1 = (ushort *)(param_1 + 1);
  if ((uVar12 & 0xc0000000) == 0x80000000) {
    iVar22 = func_0x(puVar1);
    iVar7 = 0;
    if (iVar22 != 0) {
      func_0x(param_1 + 0x15,param_3,aiStackX_10,auStack_58);
      iVar7 = aiStackX_10[0];
    }
  }
  else {
    uVar5 = 1;
    if ((sVar11 != 0) || ((*(byte *)((longlong)param_3 + 6) & 0x10) != 0)) {
      pbVar20 = *(byte **)(param_1 + 4);
      if ((*pbVar20 & 0x10) == 0) {
        uVar5 = 1;
        uVar6 = 0;
        if ((1 << (*pbVar20 & 0xe) & 0x1105U) != 0) goto LAB_;
LAB_:
        if (sVar11 != 0) goto LAB_;
      }
      else {
        uVar16 = *(uint *)(param_1 + 8);
        if ((int)uVar16 <= (int)uVar12) {
LAB_:
          uVar6 = ~(*(ushort *)((longlong)param_3 + 6) >> 4) & 1;
          uVar5 = 0;
          goto LAB_;
        }
        if ((uint)*(ushort *)(pbVar20 + uVar16) < (uint)*(ushort *)(param_3 + 1)) goto LAB_;
        if (sVar11 == 0) goto LAB_;
        uVar14 = *(ushort *)(param_3 + 1) - 1;
        uVar6 = pbVar20[(ulonglong)uVar16 + (ulonglong)(uVar14 >> 3) + 2] >> ((byte)uVar14 & 7) & 1;
LAB_:
        if (uVar6 != 0) goto LAB_;
      }
      if ((uVar5 == 0) && ((*(byte *)((longlong)param_3 + 6) & 0x10) != 0)) {
        iVar7 = **(int **)(param_3 + 2);
        goto LAB_;
      }
    }
LAB_:
    if ((int)uVar12 < 0) {
      if (*(int *)(param_1 + 2) == 0) {
        pbVar20 = *(byte **)(param_1 + 4);
        uVar12 = *(uint *)(param_1 + 8);
        uVar13 = (ulonglong)uVar12;
        *puVar1 = 0;
        *(uint *)(param_1 + 10) = uVar12;
        bVar3 = *pbVar20;
        if ((bVar3 & 0x10) != 0) {
          uVar12 = uVar12 + 2 + (*(ushort *)(pbVar20 + uVar13) + 7 >> 3);
          uVar13 = (ulonglong)uVar12;
          *(uint *)(param_1 + 10) = uVar12;
          bVar3 = *pbVar20;
        }
        psVar15 = param_1;
        if ((bVar3 & 0x20) == 0) {
          *(int *)(param_1 + 2) = (int)uVar13;
          param_1[0xe] = 0;
          *(int *)(param_1 + 0xc) = (int)uVar13;
        }
        else {
          puVar17 = (ushort *)(pbVar20 + uVar13);
          uVar5 = *puVar17;
          param_1[0xe] = uVar5;
          puStackX_18 = puVar17;
          if (uVar5 == 0) {
            cVar4 = func_0x(0x1106ce0);
            if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
               (*(char *)(lVar8 + 0x499) != '\0')) {
              cVar4 = func_0x(0x1106ce0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0x9f66ec,0xb167d8,0x80f,0);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),3);
            uVar13 = (ulonglong)*(uint *)(param_1 + 10);
            uVar5 = param_1[0xe];
          }
          uVar12 = (int)uVar13 + (uVar5 + 1) * 2;
          *(uint *)(param_1 + 0xc) = uVar12;
          if (0x1f9e < uVar12) {
            cVar4 = func_0x(0x1106ce0);
            if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
               (*(char *)(lVar8 + 0x499) != '\0')) {
              cVar4 = func_0x(0x1106ce0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x9f66ec,0xb167d8,0x816,0);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),4);
            uVar5 = param_1[0xe];
            uVar12 = *(uint *)(param_1 + 0xc);
          }
          uVar13 = (ulonglong)uVar5;
          uVar5 = puVar17[uVar13];
          *(uint *)(param_1 + 2) = uVar5 & 0x7fff;
          if ((uVar5 & 0x7fff) < uVar12) {
            cVar4 = func_0x(0x1106ce0);
            if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
               (*(char *)(lVar8 + 0x499) != '\0')) {
              cVar4 = func_0x(0x1106ce0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x9f66ec,0xb167d8,0x81d,0);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),4);
            uVar12 = *(uint *)(param_1 + 0xc);
            uVar13 = (ulonglong)(ushort)param_1[0xe];
          }
          puVar18 = puVar17;
          iVar22 = iVar7;
          if ((short)uVar13 != 0) {
            do {
              puVar17 = puVar17 + 1;
              uVar16 = *puVar17 & 0x7fff;
              if ((uVar16 < uVar12) || (*(uint *)(param_1 + 2) < uVar16)) {
                cVar4 = func_0x(0x1106ce0);
                if ((cVar4 != '\0') &&
                   ((lVar8 = func_0x(), lVar8 != 0 &&
                    (*(char *)(lVar8 + 0x499) != '\0')))) {
                  cVar4 = func_0x(0x1106ce0);
                  if (cVar4 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    (*_DAT_)(1,0x9f66ec,0xb167d8,0x82a,0);
                  }
                }
                func_0x(*(undefined8 *)(param_1 + 4),4);
              }
              uVar13 = (ulonglong)(ushort)param_1[0xe];
              iVar22 = iVar22 + 1;
              psVar15 = psStackX_8;
              puVar18 = puStackX_18;
              param_4 = puStackX_20;
              uVar12 = uVar16;
            } while (iVar22 < (int)(uint)(ushort)param_1[0xe]);
          }
          puVar17 = puStackX_18;
          if ((short)puVar18[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
            lVar8 = *(longlong *)(param_1 + 4);
LAB_:
            lVar9 = (ulonglong)*(uint *)(param_1 + 10) + lVar8;
            if ((int)uVar13 == 1) {
              uVar12 = *(uint *)(param_1 + 0xc);
              uVar14 = *(ushort *)(lVar9 + uVar13 * 2) & 0x7fff;
              uVar16 = uVar12;
LAB_:
              if ((uVar14 < uVar12) || (*(uint *)(param_1 + 2) < uVar14)) goto LAB_;
            }
            else {
              uVar16 = *(uint *)(psVar15 + 0xc);
              uVar14 = *(ushort *)(lVar9 + uVar13 * 2) & 0x7fff;
              uVar12 = *(ushort *)(lVar9 + -2 + uVar13 * 2) & 0x7fff;
              if (uVar16 <= uVar12) goto LAB_;
LAB_:
              func_0x(lVar8,7);
              uVar16 = *(uint *)(psStackX_8 + 0xc);
            }
            if ((uVar12 < uVar16) || (*(uint *)(param_1 + 2) < uVar12)) goto LAB_;
            lVar8 = *(longlong *)(param_1 + 4);
            if (*(ushort *)(lVar8 + (ulonglong)uVar12) == 5) {
              *puVar1 = *puVar1 | 2;
              param_1[0xe] = param_1[0xe] + -1;
              uVar21 = (ulonglong)(uVar12 & 0xffff);
              uVar6 = param_1[0x16] & 0xc7ff;
              param_1[0x15] = (short)uVar12;
              uVar13 = *(ulonglong *)(param_1 + 4);
              uVar5 = *(ushort *)(uVar13 + 2 + uVar21);
              if ((uVar5 >> 0xe & 1) != 0) {
                uVar6 = uVar5 & 0x3800 | uVar6;
              }
              param_1[0x16] = uVar6;
              uVar5 = (uVar6 ^ *(ushort *)(uVar21 + 2 + uVar13)) & 0x7ff ^ uVar6;
              param_1[0x16] = uVar5;
              uVar19 = (ulonglong)((uVar5 & 0x7ff) * 2) + 4 + uVar13 + (uVar6 >> 0xb & 7) * 2 +
                       uVar21;
              if (uVar19 < uVar21 + uVar13) {
                func_0x(uVar21 + uVar13,0x19);
                uVar5 = param_1[0x16];
                uVar21 = (ulonglong)(ushort)param_1[0x15];
                uVar13 = (ulonglong)*(uint *)(param_1 + 4);
              }
              if (uVar14 - uVar12 <
                  (((uVar5 & 0x7ff) * 2 - (int)uVar21) - (int)uVar13) + (int)uVar19) {
                func_0x(uVar21 + *(longlong *)(param_1 + 4),0x19);
                uVar5 = param_1[0x16];
              }
              psVar15 = psStackX_8;
              if ((uVar5 & 0x3800) != 0) {
                iVar22 = 0;
                puVar17 = (ushort *)
                          (*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]);
                if ((uVar5 & 0x3800) != 0) {
                  do {
                    if ((uVar5 & 0x7ff) < (*puVar17 & 0x7ff)) {
                      func_0x((ulonglong)(ushort)param_1[0x15] + *(longlong *)(param_1 + 4),
                                      0x1a);
                      uVar5 = param_1[0x16];
                    }
                    iVar22 = iVar22 + 1;
                    puVar17 = puVar17 + 1;
                  } while (iVar22 < (int)(uVar5 >> 0xb & 7));
                }
                pbVar20 = *(byte **)(psStackX_8 + 4);
                uVar13 = (ulonglong)*(uint *)(psStackX_8 + 2);
                psVar15 = psStackX_8;
                goto LAB_;
              }
            }
            else {
              psVar15 = psStackX_8;
              if (0x3ff < *(ushort *)(lVar8 + (ulonglong)uVar12)) goto code_r0x00100668;
            }
          }
LAB_:
          pbVar20 = *(byte **)(psVar15 + 4);
          uVar13 = (ulonglong)*(uint *)(psVar15 + 2);
        }
LAB_:
        if ((*pbVar20 & 0x40) == 0) {
          *(undefined4 *)(param_1 + 0x13) = 0;
        }
        else {
          *(int *)(param_1 + 0x13) = (int)uVar13;
          *(int *)(param_1 + 2) = (int)uVar13 + 0xe;
          uVar10 = func_0x(puVar1);
          func_0x(uVar10,auStack_50);
          iVar22 = func_0x(auStack_50);
          *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar22;
          uVar13 = (ulonglong)*(uint *)(param_1 + 2);
        }
        iVar22 = (int)uVar13;
        if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
           (*(ulonglong *)(param_1 + 0xf) < uVar13 + *(longlong *)(param_1 + 4))) {
          cVar4 = func_0x(0x1106ce0);
          if ((cVar4 != '\0') &&
             ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')))
             ) {
            cVar4 = func_0x(0x1106ce0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              (*_DAT_)(1,0x9f66ec,0xb167d8,0x886,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),0x12);
          iVar22 = *(int *)(psVar15 + 2);
        }
        if (0x3f3b < iVar22 - 1U) {
          cVar4 = func_0x(0x1106ce0);
          if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar4 = func_0x(0x1106ce0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              (*_DAT_)(1,0x9f66ec,0xb167d8,0x88b,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),5);
        }
      }
LAB_:
      sVar11 = -*(short *)param_3;
      if ((*(byte *)((longlong)param_3 + 6) & 0x10) == 0) {
LAB_:
        if ((uint)(int)sVar11 <= (uint)(ushort)param_1[0xe]) {
          lVar8 = (ulonglong)*(uint *)(param_1 + 10) + *(longlong *)(param_1 + 4);
          uVar12 = *(ushort *)(lVar8 + (longlong)sVar11 * 2) & 0x7fff;
          if (sVar11 == 1) {
            uVar16 = *(uint *)(param_1 + 0xc);
LAB_:
            if ((uVar12 < uVar16) || (*(uint *)(param_1 + 2) < uVar12)) goto LAB_;
          }
          else {
            uVar16 = *(ushort *)(lVar8 + -2 + (longlong)sVar11 * 2) & 0x7fff;
            if (*(uint *)(psStackX_8 + 0xc) <= uVar16) goto LAB_;
LAB_:
            func_0x(*(longlong *)(param_1 + 4),7);
          }
          iVar7 = uVar12 - uVar16;
        }
      }
      else {
        bVar3 = **(byte **)(param_1 + 4);
        if ((bVar3 & 0x10) == 0) {
          if ((1 << (bVar3 & 0xe) & 0x1105U) == 0) goto LAB_;
        }
        else if (((int)*param_3 < (int)*(uint *)(param_1 + 8)) &&
                (*(ushort *)(param_3 + 1) <=
                 *(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)))) goto LAB_;
        iVar7 = **(int **)(param_3 + 2);
      }
    }
    else if ((*(ushort *)((longlong)param_3 + 6) & 8) == 0) {
      if ((*(ushort *)((longlong)param_3 + 6) & 0x10) != 0) {
        bVar3 = **(byte **)(param_1 + 4);
        if ((bVar3 & 0x10) == 0) {
          if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) {
LAB_:
            iVar7 = **(int **)(param_3 + 2);
            if (iVar7 != 0x1f9e) {
              (*_DAT_)(1,0xba4b30,0xba3498,0x381,0);
            }
            goto LAB_;
          }
        }
        else if (((int)*(uint *)(param_1 + 8) <= (int)uVar12) ||
                (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) <
                 *(ushort *)(param_3 + 1))) goto LAB_;
      }
      iVar7 = 0x1f9e;
    }
    else {
      iVar7 = 1;
    }
  }
LAB_:
  *(short *)(param_4 + 1) = (short)iVar7;
  uVar12 = *param_3;
  puStackX_18 = (ushort *)((ulonglong)puStackX_18 & 0xffffffff00000000);
  if ((uVar12 & 0xc0000000) == 0x80000000) {
    iVar7 = func_0x(puVar1);
    if (iVar7 == 0) goto LAB_;
    func_0x(param_1 + 0x15,param_3,auStack_54,&puStackX_18);
    if ((int)puStackX_18 == 0) goto LAB_;
  }
  else {
    if (((-1 < (int)uVar12) || ((**(byte **)(param_1 + 4) & 0x20) == 0)) ||
       (iVar7 = func_0x(puVar1), iVar7 < (int)-uVar12)) goto LAB_;
    if (((uint)*(ushort *)((ulonglong)*(uint *)(param_1 + 10) + *(longlong *)(param_1 + 4)) <=
         ~uVar12) ||
       (-1 < (short)((ushort *)((ulonglong)*(uint *)(param_1 + 10) + *(longlong *)(param_1 + 4)))
                    [(ulonglong)~uVar12 + 1])) goto LAB_;
  }
  *(ushort *)((longlong)param_4 + 6) = *(ushort *)((longlong)param_4 + 6) | 1;
LAB_:
  if ((*param_3 & 0xc0000000) == 0x80000000) {
    *(ushort *)((longlong)param_4 + 6) = *(ushort *)((longlong)param_4 + 6) | 2;
  }
  return;
code_r0x00100668:
  *puVar1 = *puVar1 | 1;
  uVar5 = param_1[0xe] - 1;
  param_1[0xe] = uVar5;
  if ((uVar5 == 0) || (uVar13 = (ulonglong)uVar5, -1 < (short)puVar17[(ulonglong)(uVar5 - 1) + 1]))
  goto LAB_;
  goto LAB_;
}

