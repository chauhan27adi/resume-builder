
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2,longlong *param_3,int *param_4)

{
  undefined4 uVar1;
  code *pcVar2;
  longlong *plVar3;
  undefined7 uVar4;
  ushort *puVar5;
  byte bVar6;
  char cVar7;
  ushort uVar8;
  ushort uVar9;
  int iVar10;
  longlong lVar11;
  undefined8 uVar12;
  longlong lVar13;
  uint *puVar14;
  byte bVar15;
  undefined uVar16;
  uint uVar17;
  ulonglong uVar18;
  ulonglong uVar19;
  uint uVar20;
  byte *pbVar21;
  undefined *puVar22;
  uint *puVar23;
  uint uVar24;
  uint uVar25;
  uint uVar26;
  uint *puVar27;
  short sVar28;
  longlong lVar29;
  ulonglong uVar30;
  short *psVar31;
  short *psVar32;
  ushort *puVar33;
  ushort *puVar34;
  undefined auStack_bb8 [64];
  uint uStack_b78;
  uint uStack_b74;
  uint *puStack_b70;
  uint uStack_b68;
  undefined4 uStack_b64;
  uint uStack_b60;
  uint uStack_b5c;
  longlong *plStack_b58;
  longlong lStack_b50;
  int *piStack_b48;
  uint auStack_b40 [2];
  longlong lStack_b38;
  undefined auStack_b28 [8];
  undefined auStack_b20 [8];
  short *psStack_b18;
  undefined auStack_b10 [8];
  uint auStack_b08 [4];
  uint auStack_af8 [16];
  uint auStack_ab8 [664];
  ulonglong uStack_58;
  
  puVar22 = auStack_bb8;
  uStack_58 = _DAT_ ^ (ulonglong)&uStack_b78;
  puVar14 = (uint *)0x0;
  lVar11 = *(longlong *)(param_1[3] + 8);
  uStack_b64 = 0;
  lStack_b38 = 0;
  puVar23 = puVar14;
  plStack_b58 = param_1;
  lStack_b50 = param_2;
  piStack_b48 = param_4;
  if (*(int *)(lVar11 + 0x100) == 2) {
    if ((*(byte *)(lVar11 + 0x42) & 4) == 0) {
      uVar19 = (ulonglong)*(uint *)(lVar11 + 0xb0);
      if (0x1f9e < *(uint *)(lVar11 + 0xb0)) {
        uVar19 = 0x1f9e;
      }
    }
    else {
      uVar19 = 0x1f9e;
    }
    uStack_b64 = (undefined4)uVar19;
    uVar18 = uVar19 + 0xf;
    if (uVar18 <= uVar19) {
      uVar18 = 0xffffffffffffff0;
    }
    uVar18 = uVar18 & 0xfffffffffffffff0;
    func_0x();
    puVar22 = auStack_bb8 + -uVar18;
    lStack_b38 = (longlong)&uStack_b78 + -uVar18;
  }
  if ((undefined8 *)param_1[2] != (undefined8 *)0x0) {
    pcVar2 = **(code ***)(undefined8 *)param_1[2];
    *(undefined8 *)(puVar22 + -8) = 0x1000bc;
    lVar11 = (*pcVar2)();
    param_1[1] = lVar11;
    puVar23 = (uint *)0x0;
  }
  psVar31 = (short *)param_1[1];
  if ((*(byte *)(param_2 + 0x14) & 0x10) == 0) {
    uVar19 = (ulonglong)puVar23 & 0xffffffff;
  }
  else {
    uVar19 = (ulonglong)*(uint *)(param_2 + 0x10);
  }
  uVar24 = (uint)uVar19;
  uStack_b74 = uVar24;
  psStack_b18 = psVar31;
  if (param_3 == (longlong *)0x0) {
LAB_:
    *piStack_b48 = (int)puVar23;
    puStack_b70 = *(uint **)(param_2 + 8);
    if (uVar24 == 0) goto LAB_;
  }
  else {
    uVar1 = *(undefined4 *)(param_3 + 1);
    lVar11 = *param_3;
    *(undefined8 *)(puVar22 + -8) = 0x1000f5;
    func_0x(lVar11,0,uVar1);
    uVar25 = uStack_b74;
    lVar11 = *(longlong *)(param_2 + 8);
    puVar23 = (uint *)0x0;
    puVar27 = puVar23;
    if (uVar24 == 0) goto LAB_;
    do {
      if ((*(char *)(lVar11 + 0x40) == '\x03') || (*(char *)(lVar11 + 0x40) == '\x04')) {
        *(undefined8 *)(puVar22 + -8) = 0x100129;
        iVar10 = func_0x(psVar31,lVar11);
        if (iVar10 != 0) {
          pbVar21 = (byte *)(((ulonglong)puVar23 >> 3) + *param_3);
          *pbVar21 = *pbVar21 | (byte)(1 << ((uint)puVar27 & 7));
        }
      }
      uVar24 = (uint)puVar27 + 1;
      puVar23 = (uint *)((longlong)puVar23 + 1);
      lVar11 = lVar11 + 0x50;
      puVar27 = (uint *)(ulonglong)uVar24;
    } while (uVar24 < uVar25);
    puVar23 = (uint *)0x0;
    uVar19 = (ulonglong)uStack_b74;
    *piStack_b48 = 0;
    puStack_b70 = *(uint **)(lStack_b50 + 8);
    param_2 = lStack_b50;
  }
  uStack_b68 = (uint)puVar23;
  uVar18 = (ulonglong)puVar23 & 0xffffffff;
  do {
    plVar3 = plStack_b58;
    puVar27 = puStack_b70;
    uVar25 = (uint)uVar18;
    uVar24 = puStack_b70[0x10];
    if ((uVar24 >> 0xb & 1) != 0) {
      *piStack_b48 = 1;
      uVar24 = (uint)*(byte *)(puStack_b70 + 0x10);
    }
    uVar26 = (uint)puVar23;
    uVar8 = (ushort)puVar23;
    uVar4 = (undefined7)((ulonglong)puVar23 >> 8);
    psVar32 = psVar31;
    switch((char)uVar24) {
    case '\0':
      goto code_r0x00101f85;
    case '\x01':
      if (*psVar31 == 0) {
        pbVar21 = *(byte **)(psVar31 + 4);
        if ((*pbVar21 & 0x10) == 0) {
          uVar24 = uVar26;
          if ((1 << (*pbVar21 & 0xe) & 0x1105U) != 0) {
code_r0x00100224:
            uVar24 = ~(uint)(*(ushort *)((longlong)puStack_b70 + 6) >> 4) & 1;
          }
        }
        else {
          uVar24 = *(uint *)(psVar31 + 8);
          if ((int)*puStack_b70 < (int)uVar24) {
            if ((uint)*(ushort *)(pbVar21 + uVar24) < (uint)*(ushort *)(puStack_b70 + 1))
            goto code_r0x00100224;
            uVar20 = *(ushort *)(puStack_b70 + 1) - 1;
            uVar24 = pbVar21[(ulonglong)uVar24 + (ulonglong)(uVar20 >> 3) + 2] >> ((byte)uVar20 & 7)
                     & 1;
          }
          else {
            uVar24 = ~(uint)(*(ushort *)((longlong)puStack_b70 + 6) >> 4) & 1;
          }
        }
      }
      else {
        uVar8 = *(ushort *)(puStack_b70 + 1);
        if ((ushort)psVar31[1] < uVar8) {
          uVar24 = ~(uint)(*(ushort *)((longlong)puStack_b70 + 6) >> 4) & 1;
        }
        else {
          bVar6 = *(byte *)((longlong)((int)(uVar8 - 1) / 2) + (ulonglong)(ushort)psVar31[0xc] +
                           *(longlong *)(psVar31 + 4));
          bVar15 = bVar6 >> 4;
          if ((uVar8 & 1) != 0) {
            bVar15 = bVar6 & 0xf;
          }
          uVar24 = (uint)CONCAT71(uVar4,bVar15 == 0);
        }
      }
      puVar14 = puVar23;
      if (uVar24 == 0) goto code_r0x001002b3;
      break;
    case '\x02':
code_r0x001002b3:
      uVar24 = (uint)*(ushort *)(puStack_b70 + 0xf);
      if ((*(byte *)((longlong)puStack_b70 + 6) & 0x10) != 0) {
        bVar6 = **(byte **)(psVar31 + 4);
        if ((bVar6 & 0x10) == 0) {
          if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
code_r0x00100301:
            uVar26 = **(uint **)(puStack_b70 + 2);
            puVar14 = *(uint **)(puStack_b70 + 2) + 1;
            if ((uVar24 != 0) && (uVar26 != uVar24)) {
              *(uint **)(puVar22 + 0x20) = puVar23;
              *(undefined8 *)(puVar22 + -8) = 0x100339;
              (*_DAT_)(1,0xbafcb0,0xbae618);
            }
            break;
          }
        }
        else if (((int)*(uint *)(psVar31 + 8) <= (int)*puStack_b70) ||
                (*(ushort *)(*(byte **)(psVar31 + 4) + *(uint *)(psVar31 + 8)) <
                 *(ushort *)(puStack_b70 + 1))) goto code_r0x00100301;
      }
      puVar14 = (uint *)((longlong)(int)*puStack_b70 + *(longlong *)(psVar31 + 4));
      uVar26 = uVar24;
      break;
    case '\x03':
      if (*psVar31 == 0) {
        pbVar21 = *(byte **)(psVar31 + 4);
        if ((*pbVar21 & 0x10) == 0) {
          uVar24 = uVar26;
          if ((1 << (*pbVar21 & 0xe) & 0x1105U) != 0) {
code_r0x00100398:
            uVar24 = ~(uint)(*(ushort *)((longlong)puStack_b70 + 6) >> 4) & 1;
          }
        }
        else {
          uVar24 = *(uint *)(psVar31 + 8);
          if ((int)*puStack_b70 < (int)uVar24) {
            if ((uint)*(ushort *)(pbVar21 + uVar24) < (uint)*(ushort *)(puStack_b70 + 1))
            goto code_r0x00100398;
            uVar20 = *(ushort *)(puStack_b70 + 1) - 1;
            uVar24 = pbVar21[(ulonglong)uVar24 + (ulonglong)(uVar20 >> 3) + 2] >> ((byte)uVar20 & 7)
                     & 1;
          }
          else {
            uVar24 = ~(uint)(*(ushort *)((longlong)puStack_b70 + 6) >> 4) & 1;
          }
        }
      }
      else {
        uVar9 = *(ushort *)(puStack_b70 + 1);
        if ((ushort)psVar31[1] < uVar9) {
          uVar24 = ~(uint)(*(ushort *)((longlong)puStack_b70 + 6) >> 4) & 1;
        }
        else {
          bVar6 = *(byte *)((longlong)((int)(uVar9 - 1) / 2) + (ulonglong)(ushort)psVar31[0xc] +
                           *(longlong *)(psVar31 + 4));
          bVar15 = bVar6 >> 4;
          if ((uVar9 & 1) != 0) {
            bVar15 = bVar6 & 0xf;
          }
          uVar24 = (uint)CONCAT71(uVar4,bVar15 == 0);
        }
      }
      puVar14 = puVar23;
      if (uVar24 == 0) goto code_r0x00100427;
      break;
    case '\x04':
code_r0x00100427:
      if (*psVar31 == 0) {
        if (*(int *)(psVar31 + 2) == 0) {
          pbVar21 = *(byte **)(psVar31 + 4);
          uVar24 = *(uint *)(psVar31 + 8);
          uVar19 = (ulonglong)uVar24;
          psVar31[1] = uVar8;
          *(uint *)(psVar31 + 10) = uVar24;
          bVar6 = *pbVar21;
          if ((bVar6 & 0x10) != 0) {
            uVar24 = uVar24 + 2 + (*(ushort *)(pbVar21 + uVar19) + 7 >> 3);
            uVar19 = (ulonglong)uVar24;
            *(uint *)(psVar31 + 10) = uVar24;
            bVar6 = *pbVar21;
          }
          if ((bVar6 & 0x20) == 0) {
            *(int *)(psVar31 + 2) = (int)uVar19;
            psVar31[0xe] = uVar8;
            *(int *)(psVar31 + 0xc) = (int)uVar19;
          }
          else {
            puVar33 = (ushort *)(pbVar21 + uVar19);
            uVar8 = *puVar33;
            psVar31[0xe] = uVar8;
            if (uVar8 == 0) {
              *(undefined8 *)(puVar22 + -8) = 0x10049b;
              cVar7 = func_0x(0x1111e60);
              if (cVar7 != '\0') {
                *(undefined8 *)(puVar22 + -8) = 0x1004a4;
                lVar11 = func_0x();
                if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar22 + -8) = 0x1004be;
                  cVar7 = func_0x(0x1111e60);
                  if (cVar7 == '\0') {
                    *(undefined8 *)(puVar22 + -8) = 0x1004da;
                    (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                  }
                  else {
                    *(undefined8 *)(puVar22 + 0x20) = 0;
                    *(undefined8 *)(puVar22 + -8) = 0x100519;
                    (*_DAT_)(1,0xa0186c,0xb21958);
                  }
                }
              }
              uVar12 = *(undefined8 *)(psVar31 + 4);
              *(undefined8 *)(puVar22 + -8) = 0x1004ea;
              func_0x(uVar12,3);
              uVar19 = (ulonglong)*(uint *)(psVar31 + 10);
              uVar8 = psVar31[0xe];
            }
            uVar24 = (int)uVar19 + (uint)uVar8 * 2 + 2;
            *(uint *)(psVar31 + 0xc) = uVar24;
            if (0x1f9e < uVar24) {
              *(undefined8 *)(puVar22 + -8) = 0x100545;
              cVar7 = func_0x(0x1111e60);
              if (cVar7 != '\0') {
                *(undefined8 *)(puVar22 + -8) = 0x10054e;
                lVar11 = func_0x();
                if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar22 + -8) = 0x100568;
                  cVar7 = func_0x(0x1111e60);
                  if (cVar7 == '\0') {
                    *(undefined8 *)(puVar22 + -8) = 0x100584;
                    (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                  }
                  else {
                    *(undefined8 *)(puVar22 + 0x20) = 0;
                    *(undefined8 *)(puVar22 + -8) = 0x1005aa;
                    (*_DAT_)(1,0xa0186c,0xb21958);
                  }
                }
              }
              uVar12 = *(undefined8 *)(psVar31 + 4);
              *(undefined8 *)(puVar22 + -8) = 0x1005b8;
              func_0x(uVar12,4);
              uVar8 = psVar31[0xe];
              uVar24 = *(uint *)(psVar31 + 0xc);
            }
            uVar19 = (ulonglong)uVar8;
            uVar8 = puVar33[uVar19];
            *(uint *)(psVar31 + 2) = uVar8 & 0x7fff;
            if ((uVar8 & 0x7fff) < uVar24) {
              *(undefined8 *)(puVar22 + -8) = 0x1005e8;
              cVar7 = func_0x(0x1111e60);
              if (cVar7 != '\0') {
                *(undefined8 *)(puVar22 + -8) = 0x1005f1;
                lVar11 = func_0x();
                if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar22 + -8) = 0x10060b;
                  cVar7 = func_0x(0x1111e60);
                  if (cVar7 == '\0') {
                    *(undefined8 *)(puVar22 + -8) = 0x100627;
                    (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                  }
                  else {
                    *(undefined8 *)(puVar22 + 0x20) = 0;
                    *(undefined8 *)(puVar22 + -8) = 0x10064d;
                    (*_DAT_)(1,0xa0186c,0xb21958);
                  }
                }
              }
              uVar12 = *(undefined8 *)(psVar31 + 4);
              *(undefined8 *)(puVar22 + -8) = 0x10065b;
              func_0x(uVar12,4);
              uVar24 = *(uint *)(psVar31 + 0xc);
              uVar19 = (ulonglong)(ushort)psVar31[0xe];
            }
            iVar10 = 0;
            puVar34 = puVar33;
            if ((short)uVar19 != 0) {
              do {
                uVar25 = puVar34[1] & 0x7fff;
                if ((uVar25 < uVar24) || (*(uint *)(psVar31 + 2) < uVar25)) {
                  *(undefined8 *)(puVar22 + -8) = 0x1006a0;
                  cVar7 = func_0x(0x1111e60);
                  if (cVar7 != '\0') {
                    *(undefined8 *)(puVar22 + -8) = 0x1006a9;
                    lVar11 = func_0x();
                    if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar22 + -8) = 0x1006c3;
                      cVar7 = func_0x(0x1111e60);
                      if (cVar7 == '\0') {
                        *(undefined8 *)(puVar22 + -8) = 0x1006df;
                        (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                      }
                      else {
                        *(undefined8 *)(puVar22 + 0x20) = 0;
                        *(undefined8 *)(puVar22 + -8) = 0x100705;
                        (*_DAT_)(1,0xa0186c,0xb21958);
                      }
                    }
                  }
                  uVar12 = *(undefined8 *)(psVar31 + 4);
                  *(undefined8 *)(puVar22 + -8) = 0x100713;
                  func_0x(uVar12,4);
                }
                uVar19 = (ulonglong)(ushort)psVar31[0xe];
                iVar10 = iVar10 + 1;
                puVar34 = puVar34 + 1;
                uVar24 = uVar25;
              } while (iVar10 < (int)(uint)(ushort)psVar31[0xe]);
            }
            if ((short)puVar33[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
              pbVar21 = *(byte **)(psVar31 + 4);
              do {
                uVar24 = *(ushort *)(pbVar21 + uVar19 * 2 + (ulonglong)*(uint *)(psVar31 + 10)) &
                         0x7fff;
                if ((int)uVar19 == 1) {
                  uVar25 = *(uint *)(psVar31 + 0xc);
                  uVar26 = uVar25;
code_r0x00100774:
                  if ((uVar24 < uVar25) || (*(uint *)(psVar31 + 2) < uVar24)) goto code_r0x0010077e;
                }
                else {
                  uVar26 = *(uint *)(psVar31 + 0xc);
                  uVar25 = *(ushort *)
                            (pbVar21 + uVar19 * 2 + ((ulonglong)*(uint *)(psVar31 + 10) - 2)) &
                           0x7fff;
                  if (uVar26 <= uVar25) goto code_r0x00100774;
code_r0x0010077e:
                  *(undefined8 *)(puVar22 + -8) = 0x10078b;
                  func_0x(pbVar21,7);
                  uVar26 = *(uint *)(psVar31 + 0xc);
                }
                puVar27 = puStack_b70;
                if ((uVar25 < uVar26) || (*(uint *)(psVar31 + 2) < uVar25)) goto code_r0x00100b09;
                pbVar21 = *(byte **)(psVar31 + 4);
                if (*(ushort *)(pbVar21 + uVar25) == 5) {
                  psVar31[1] = psVar31[1] | 2;
                  psVar31[0xe] = psVar31[0xe] + -1;
                  uVar9 = psVar31[0x16] & 0xc7ff;
                  psVar31[0x15] = (short)uVar25;
                  uVar19 = *(ulonglong *)(psVar31 + 4);
                  uVar8 = *(ushort *)((ulonglong)(uVar25 & 0xffff) + 2 + uVar19);
                  if ((uVar8 >> 0xe & 1) != 0) {
                    uVar9 = uVar8 & 0x3800 | uVar9;
                  }
                  psVar31[0x16] = uVar9;
                  uVar30 = (ulonglong)(ushort)psVar31[0x15];
                  uVar8 = (uVar9 ^ *(ushort *)((ulonglong)(uVar25 & 0xffff) + 2 + uVar19)) & 0x7ff ^
                          uVar9;
                  psVar31[0x16] = uVar8;
                  uVar18 = (ulonglong)((uVar8 & 0x7ff) * 2) + 4 + uVar19 + (uVar9 >> 0xb & 7) * 2 +
                           uVar30;
                  if (uVar18 < uVar30 + uVar19) {
                    *(undefined8 *)(puVar22 + -8) = 0x1008ac;
                    func_0x(uVar30 + uVar19,0x19);
                    uVar8 = psVar31[0x16];
                    uVar30 = (ulonglong)(ushort)psVar31[0x15];
                    uVar19 = (ulonglong)*(uint *)(psVar31 + 4);
                  }
                  if (uVar24 - uVar25 <
                      (((uVar8 & 0x7ff) * 2 - (int)uVar30) - (int)uVar19) + (int)uVar18) {
                    lVar11 = *(longlong *)(psVar31 + 4);
                    *(undefined8 *)(puVar22 + -8) = 0x1008e4;
                    func_0x(uVar30 + lVar11,0x19);
                    uVar8 = psVar31[0x16];
                  }
                  iVar10 = 0;
                  if (((uVar8 & 0x3800) != 0) &&
                     (puVar33 = (ushort *)
                                (*(longlong *)(psVar31 + 4) + 4 + (ulonglong)(ushort)psVar31[0x15]),
                     (uVar8 & 0x3800) != 0)) {
                    do {
                      if ((uVar8 & 0x7ff) < (*puVar33 & 0x7ff)) {
                        uVar8 = psVar31[0x15];
                        lVar11 = *(longlong *)(psVar31 + 4);
                        *(undefined8 *)(puVar22 + -8) = 0x100948;
                        func_0x((ulonglong)uVar8 + lVar11,0x1a);
                        uVar8 = psVar31[0x16];
                      }
                      iVar10 = iVar10 + 1;
                      puVar33 = puVar33 + 1;
                    } while (iVar10 < (int)(uVar8 >> 0xb & 7));
                  }
                  goto code_r0x00100967;
                }
                if (*(ushort *)(pbVar21 + uVar25) < 0x400) goto code_r0x00100967;
                psVar31[1] = psVar31[1] | 1;
                uVar8 = psVar31[0xe] - 1;
                psVar31[0xe] = uVar8;
                if (uVar8 == 0) goto code_r0x00100967;
                uVar19 = (ulonglong)uVar8;
              } while ((short)puVar33[(ulonglong)(uVar8 - 1) + 1] < 0);
              uVar19 = (ulonglong)*(uint *)(psVar31 + 2);
              puVar23 = (uint *)0x0;
            }
            else {
code_r0x00100967:
              puVar23 = (uint *)0x0;
              pbVar21 = *(byte **)(psVar31 + 4);
              uVar19 = (ulonglong)*(uint *)(psVar31 + 2);
            }
          }
          puVar27 = puStack_b70;
          if ((*pbVar21 & 0x40) == 0) {
            *(int *)(psVar31 + 0x13) = (int)puVar23;
          }
          else {
            *(int *)(psVar31 + 0x13) = (int)uVar19;
            *(int *)(psVar31 + 2) = (int)uVar19 + 0xe;
            *(undefined8 *)(puVar22 + -8) = 0x10099c;
            uVar12 = func_0x(psVar31 + 1);
            *(undefined8 *)(puVar22 + -8) = 0x1009a8;
            func_0x(uVar12,auStack_b28);
            *(undefined8 *)(puVar22 + -8) = 0x1009b1;
            iVar10 = func_0x(auStack_b28);
            *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + iVar10;
            uVar19 = (ulonglong)*(uint *)(psVar31 + 2);
          }
          iVar10 = (int)uVar19;
          if ((*(ulonglong *)(psVar31 + 0xf) != 0) &&
             (*(ulonglong *)(psVar31 + 0xf) < uVar19 + *(longlong *)(psVar31 + 4))) {
            *(undefined8 *)(puVar22 + -8) = 0x1009eb;
            cVar7 = func_0x(0x1111e60);
            if (cVar7 != '\0') {
              *(undefined8 *)(puVar22 + -8) = 0x1009f4;
              lVar11 = func_0x();
              if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                *(undefined8 *)(puVar22 + -8) = 0x100a0e;
                cVar7 = func_0x(0x1111e60);
                if (cVar7 == '\0') {
                  *(undefined8 *)(puVar22 + -8) = 0x100a2a;
                  (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(puVar22 + 0x20) = 0;
                  *(undefined8 *)(puVar22 + -8) = 0x100a64;
                  (*_DAT_)(1,0xa0186c,0xb21958);
                }
              }
            }
            uVar12 = *(undefined8 *)(psVar31 + 4);
            *(undefined8 *)(puVar22 + -8) = 0x100a3a;
            func_0x(uVar12,0x12);
            iVar10 = *(int *)(psVar31 + 2);
          }
          if (0x3f3b < iVar10 - 1U) {
            *(undefined8 *)(puVar22 + -8) = 0x100a82;
            cVar7 = func_0x(0x1111e60);
            if (cVar7 != '\0') {
              *(undefined8 *)(puVar22 + -8) = 0x100a8b;
              lVar11 = func_0x();
              if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                *(undefined8 *)(puVar22 + -8) = 0x100aa5;
                cVar7 = func_0x(0x1111e60);
                if (cVar7 == '\0') {
                  *(undefined8 *)(puVar22 + -8) = 0x100ac1;
                  (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                  uVar12 = *(undefined8 *)(psVar31 + 4);
                  *(undefined8 *)(puVar22 + -8) = 0x100acf;
                  func_0x(uVar12,5);
                  goto code_r0x00100b09;
                }
                *(undefined8 *)(puVar22 + 0x20) = 0;
                *(undefined8 *)(puVar22 + -8) = 0x100af5;
                (*_DAT_)(1,0xa0186c,0xb21958);
              }
            }
            uVar12 = *(undefined8 *)(psVar31 + 4);
            *(undefined8 *)(puVar22 + -8) = 0x100b03;
            func_0x(uVar12,5);
          }
code_r0x00100b09:
          puVar23 = (uint *)0x0;
        }
        sVar28 = -*(short *)puVar27;
        param_2 = lStack_b50;
        uVar25 = uStack_b68;
        if ((*(byte *)((longlong)puVar27 + 6) & 0x10) != 0) {
          bVar6 = **(byte **)(psVar31 + 4);
          if ((bVar6 & 0x10) == 0) {
            if ((1 << (bVar6 & 0xe) & 0x1105U) == 0) goto code_r0x00100b39;
code_r0x00100b7e:
            uStack_b78 = **(uint **)(puVar27 + 2);
            puVar14 = *(uint **)(puVar27 + 2) + 1;
            goto code_r0x00100c90;
          }
          if (((int)*(uint *)(psVar31 + 8) <= (int)*puVar27) ||
             (*(ushort *)(*(byte **)(psVar31 + 4) + *(uint *)(psVar31 + 8)) <
              *(ushort *)(puVar27 + 1))) goto code_r0x00100b7e;
        }
code_r0x00100b39:
        lVar11 = (longlong)sVar28;
        if ((uint)(ushort)psVar31[0xe] < (uint)(int)sVar28) {
          uStack_b78 = (uint)puVar23;
          puVar14 = *(uint **)(psVar31 + 4);
        }
        else {
          lVar29 = *(longlong *)(psVar31 + 4);
          lVar13 = (ulonglong)*(uint *)(psVar31 + 10) + lVar29;
          if (sVar28 == 1) {
            uVar24 = *(uint *)(psVar31 + 0xc);
            uVar25 = *(ushort *)(lVar13 + lVar11 * 2) & 0x7fff;
code_r0x00100bba:
            if ((uVar25 < uVar24) || (*(uint *)(psVar31 + 2) < uVar25)) goto code_r0x00100bc4;
          }
          else {
            uVar24 = *(ushort *)(lVar13 + -2 + lVar11 * 2) & 0x7fff;
            lVar29 = *(longlong *)(psVar31 + 4);
            uVar25 = *(ushort *)(lVar13 + lVar11 * 2) & 0x7fff;
            if (*(uint *)(psVar31 + 0xc) <= uVar24) goto code_r0x00100bba;
code_r0x00100bc4:
            *(undefined8 *)(puVar22 + -8) = 0x100bd1;
            func_0x(lVar29,7);
          }
          uStack_b78 = uVar25 - uVar24;
          puVar14 = (uint *)((ulonglong)uVar24 + *(longlong *)(psVar31 + 4));
          puVar27 = puStack_b70;
          param_2 = lStack_b50;
          uVar25 = uStack_b68;
        }
      }
      else {
        uStack_b60 = uVar26;
        *(uint **)(puVar22 + 0x20) = &uStack_b60;
        *(undefined8 *)(puVar22 + -8) = 0x100c20;
        puVar14 = (uint *)func_0x(psVar31 + 1,puVar27);
        if ((((*psVar31 == 0) || (plVar3 = *(longlong **)(psVar31 + 8), plVar3 == (longlong *)0x0))
            || (*plVar3 == 0)) ||
           (((*(byte *)((longlong)puVar27 + 6) & 8) != 0 || ((uStack_b60 & 1) != 0)))) {
code_r0x00100c87:
          if (puVar14 != (uint *)0x0) goto code_r0x00100c90;
        }
        else {
          if ((puVar14 != (uint *)0x0) && (puVar14 != (uint *)0x786500)) {
            *(uint *)(puVar22 + 0x38) = uStack_b60;
            *(uint **)(puVar22 + 0x30) = &uStack_b78;
            *(undefined4 *)(puVar22 + 0x28) = uStack_b64;
            *(longlong *)(puVar22 + 0x20) = lStack_b38;
            *(undefined8 *)(puVar22 + -8) = 0x100c84;
            puVar14 = (uint *)func_0x(plVar3,puVar27,puVar14);
            goto code_r0x00100c87;
          }
          uStack_b78 = 0;
        }
        puVar14 = *(uint **)(psVar31 + 4);
      }
code_r0x00100c90:
      uVar26 = uStack_b78;
      if ((uStack_b78 == 0) && ((puVar27[0x10] & 0x2000) != 0)) {
        uStack_b78 = 4;
        puVar14 = (uint *)0x7e9c24;
        uVar26 = uStack_b78;
      }
      break;
    case '\x05':
      puVar14 = *(uint **)(psVar31 + 4);
      if (*psVar31 == 0) {
        uVar26 = *(uint *)(psVar31 + 2);
        puVar33 = (ushort *)(psVar31 + 1);
        if (uVar26 == 0) {
          pbVar21 = *(byte **)(psVar31 + 4);
          uVar24 = *(uint *)(psVar31 + 8);
          uVar19 = (ulonglong)uVar24;
          *puVar33 = uVar8;
          *(uint *)(psVar31 + 10) = uVar24;
          bVar6 = *pbVar21;
          if ((bVar6 & 0x10) != 0) {
            uVar24 = uVar24 + 2 + (*(ushort *)(pbVar21 + uVar19) + 7 >> 3);
            uVar19 = (ulonglong)uVar24;
            *(uint *)(psVar31 + 10) = uVar24;
            bVar6 = *pbVar21;
          }
          if ((bVar6 & 0x20) == 0) {
            *(int *)(psVar31 + 2) = (int)uVar19;
            psVar31[0xe] = uVar8;
            *(int *)(psVar31 + 0xc) = (int)uVar19;
          }
          else {
            puVar34 = (ushort *)(pbVar21 + uVar19);
            uVar8 = *puVar34;
            psVar31[0xe] = uVar8;
            if (uVar8 == 0) {
              *(undefined8 *)(puVar22 + -8) = 0x1017b6;
              cVar7 = func_0x(0x1111e60);
              if (cVar7 != '\0') {
                *(undefined8 *)(puVar22 + -8) = 0x1017bf;
                lVar11 = func_0x();
                if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar22 + -8) = 0x1017d9;
                  cVar7 = func_0x(0x1111e60);
                  if (cVar7 == '\0') {
                    *(undefined8 *)(puVar22 + -8) = 0x1017f5;
                    (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                  }
                  else {
                    *(undefined8 *)(puVar22 + 0x20) = 0;
                    *(undefined8 *)(puVar22 + -8) = 0x101833;
                    (*_DAT_)(1,0xa0186c,0xb21958);
                  }
                }
              }
              uVar12 = *(undefined8 *)(psVar31 + 4);
              *(undefined8 *)(puVar22 + -8) = 0x101805;
              func_0x(uVar12,3);
              uVar19 = (ulonglong)*(uint *)(psVar31 + 10);
              uVar8 = psVar31[0xe];
            }
            uVar24 = (int)uVar19 + (uint)uVar8 * 2 + 2;
            *(uint *)(psVar31 + 0xc) = uVar24;
            if (0x1f9e < uVar24) {
              *(undefined8 *)(puVar22 + -8) = 0x10185f;
              cVar7 = func_0x(0x1111e60);
              if (cVar7 != '\0') {
                *(undefined8 *)(puVar22 + -8) = 0x101868;
                lVar11 = func_0x();
                if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar22 + -8) = 0x101882;
                  cVar7 = func_0x(0x1111e60);
                  if (cVar7 == '\0') {
                    *(undefined8 *)(puVar22 + -8) = 0x10189e;
                    (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                  }
                  else {
                    *(undefined8 *)(puVar22 + 0x20) = 0;
                    *(undefined8 *)(puVar22 + -8) = 0x1018c4;
                    (*_DAT_)(1,0xa0186c,0xb21958);
                  }
                }
              }
              uVar12 = *(undefined8 *)(psVar31 + 4);
              *(undefined8 *)(puVar22 + -8) = 0x1018d2;
              func_0x(uVar12,4);
              uVar8 = psVar31[0xe];
              uVar24 = *(uint *)(psVar31 + 0xc);
            }
            uVar19 = (ulonglong)uVar8;
            uVar8 = puVar34[uVar19];
            *(uint *)(psVar31 + 2) = uVar8 & 0x7fff;
            if ((uVar8 & 0x7fff) < uVar24) {
              *(undefined8 *)(puVar22 + -8) = 0x101901;
              cVar7 = func_0x(0x1111e60);
              if (cVar7 != '\0') {
                *(undefined8 *)(puVar22 + -8) = 0x10190a;
                lVar11 = func_0x();
                if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar22 + -8) = 0x101924;
                  cVar7 = func_0x(0x1111e60);
                  if (cVar7 == '\0') {
                    *(undefined8 *)(puVar22 + -8) = 0x101940;
                    (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                  }
                  else {
                    *(undefined8 *)(puVar22 + 0x20) = 0;
                    *(undefined8 *)(puVar22 + -8) = 0x101966;
                    (*_DAT_)(1,0xa0186c,0xb21958);
                  }
                }
              }
              uVar12 = *(undefined8 *)(psVar31 + 4);
              *(undefined8 *)(puVar22 + -8) = 0x101974;
              func_0x(uVar12,4);
              uVar24 = *(uint *)(psVar31 + 0xc);
              uVar19 = (ulonglong)(ushort)psVar31[0xe];
            }
            iVar10 = 0;
            puVar5 = puVar34;
            if ((short)uVar19 != 0) {
              do {
                uVar25 = puVar5[1] & 0x7fff;
                if ((uVar25 < uVar24) || (*(uint *)(psVar31 + 2) < uVar25)) {
                  *(undefined8 *)(puVar22 + -8) = 0x1019b1;
                  cVar7 = func_0x(0x1111e60);
                  if (cVar7 != '\0') {
                    *(undefined8 *)(puVar22 + -8) = 0x1019ba;
                    lVar11 = func_0x();
                    if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar22 + -8) = 0x1019d4;
                      cVar7 = func_0x(0x1111e60);
                      if (cVar7 == '\0') {
                        *(undefined8 *)(puVar22 + -8) = 0x1019f0;
                        (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                      }
                      else {
                        *(undefined8 *)(puVar22 + 0x20) = 0;
                        *(undefined8 *)(puVar22 + -8) = 0x101a16;
                        (*_DAT_)(1,0xa0186c,0xb21958);
                      }
                    }
                  }
                  uVar12 = *(undefined8 *)(psVar31 + 4);
                  *(undefined8 *)(puVar22 + -8) = 0x101a24;
                  func_0x(uVar12,4);
                }
                uVar19 = (ulonglong)(ushort)psVar31[0xe];
                iVar10 = iVar10 + 1;
                psVar32 = psStack_b18;
                puVar5 = puVar5 + 1;
                uVar24 = uVar25;
              } while (iVar10 < (int)(uint)(ushort)psVar31[0xe]);
            }
            if ((short)puVar34[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
              uVar18 = *(ulonglong *)(psVar31 + 4);
              do {
                uVar24 = *(ushort *)(*(uint *)(psVar31 + 10) + uVar18 + uVar19 * 2) & 0x7fff;
                if ((int)uVar19 == 1) {
                  uVar25 = *(uint *)(psVar31 + 0xc);
                  uVar20 = uVar25;
code_r0x00101a92:
                  if ((uVar24 < uVar25) || (uVar26 = *(uint *)(psVar31 + 2), uVar26 < uVar24))
                  goto code_r0x00101a9d;
                }
                else {
                  uVar20 = *(uint *)(psVar32 + 0xc);
                  uVar25 = *(ushort *)(*(uint *)(psVar31 + 10) + uVar18 + -2 + uVar19 * 2) & 0x7fff;
                  if (uVar20 <= uVar25) goto code_r0x00101a92;
code_r0x00101a9d:
                  *(undefined8 *)(puVar22 + -8) = 0x101aaa;
                  func_0x(uVar18,7);
                  uVar20 = *(uint *)(psVar32 + 0xc);
                  uVar26 = *(uint *)(psVar32 + 2);
                }
                if ((uVar25 < uVar20) || (uVar26 < uVar25)) goto code_r0x00101dfc;
                uVar18 = *(ulonglong *)(psVar31 + 4);
                if (*(ushort *)(uVar25 + uVar18) == 5) {
                  *puVar33 = *puVar33 | 2;
                  psVar31[0xe] = psVar31[0xe] + -1;
                  psVar31[0x15] = (short)uVar25;
                  uVar8 = *(ushort *)((ulonglong)(uVar25 & 0xffff) + 2 + uVar18);
                  uVar9 = psVar31[0x16] & 0xc7ff;
                  if ((uVar8 >> 0xe & 1) != 0) {
                    uVar9 = uVar8 & 0x3800 | uVar9;
                  }
                  psVar31[0x16] = uVar9;
                  uVar30 = (ulonglong)(ushort)psVar31[0x15];
                  uVar8 = (uVar9 ^ *(ushort *)((ulonglong)(uVar25 & 0xffff) + 2 + uVar18)) & 0x7ff ^
                          uVar9;
                  psVar31[0x16] = uVar8;
                  uVar19 = (ulonglong)((uVar8 & 0x7ff) * 2) + 4 + uVar18 + (uVar9 >> 0xb & 7) * 2 +
                           uVar30;
                  if (uVar19 < uVar30 + uVar18) {
                    *(undefined8 *)(puVar22 + -8) = 0x101bc0;
                    func_0x(uVar30 + uVar18,0x19);
                    uVar8 = psVar31[0x16];
                    uVar30 = (ulonglong)(ushort)psVar31[0x15];
                    uVar18 = (ulonglong)*(uint *)(psVar31 + 4);
                  }
                  if (uVar24 - uVar25 <
                      (((uVar8 & 0x7ff) * 2 - (int)uVar30) - (int)uVar18) + (int)uVar19) {
                    lVar11 = *(longlong *)(psVar31 + 4);
                    *(undefined8 *)(puVar22 + -8) = 0x101bf8;
                    func_0x(uVar30 + lVar11,0x19);
                    uVar8 = psVar31[0x16];
                  }
                  iVar10 = 0;
                  if (((uVar8 & 0x3800) != 0) &&
                     (puVar34 = (ushort *)
                                (*(longlong *)(psVar31 + 4) + 4 + (ulonglong)(ushort)psVar31[0x15]),
                     (uVar8 & 0x3800) != 0)) {
                    do {
                      if ((uVar8 & 0x7ff) < (*puVar34 & 0x7ff)) {
                        uVar8 = psVar31[0x15];
                        lVar11 = *(longlong *)(psVar31 + 4);
                        *(undefined8 *)(puVar22 + -8) = 0x101c57;
                        func_0x((ulonglong)uVar8 + lVar11,0x1a);
                        uVar8 = psVar31[0x16];
                      }
                      iVar10 = iVar10 + 1;
                      puVar34 = puVar34 + 1;
                    } while (iVar10 < (int)(uVar8 >> 0xb & 7));
                  }
                  goto code_r0x00101c75;
                }
                if (*(ushort *)(uVar25 + uVar18) < 0x400) goto code_r0x00101c75;
                *puVar33 = *puVar33 | 1;
                uVar8 = psVar31[0xe] - 1;
                psVar31[0xe] = uVar8;
                if (uVar8 == 0) goto code_r0x00101c75;
                uVar19 = (ulonglong)uVar8;
              } while ((short)puVar34[(ulonglong)(uVar8 - 1) + 1] < 0);
              pbVar21 = *(byte **)(psVar32 + 4);
              puVar23 = (uint *)0x0;
              uVar19 = (ulonglong)*(uint *)(psVar32 + 2);
            }
            else {
code_r0x00101c75:
              puVar23 = (uint *)0x0;
              pbVar21 = *(byte **)(psVar32 + 4);
              uVar19 = (ulonglong)*(uint *)(psVar32 + 2);
            }
          }
          if ((*pbVar21 & 0x40) == 0) {
            *(int *)(psVar31 + 0x13) = (int)puVar23;
          }
          else {
            *(int *)(psVar31 + 0x13) = (int)uVar19;
            *(int *)(psVar31 + 2) = (int)uVar19 + 0xe;
            *(undefined8 *)(puVar22 + -8) = 0x101ca4;
            uVar12 = func_0x(puVar33);
            *(undefined8 *)(puVar22 + -8) = 0x101cb0;
            func_0x(uVar12,auStack_b10);
            *(undefined8 *)(puVar22 + -8) = 0x101cb9;
            iVar10 = func_0x(auStack_b10);
            *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + iVar10;
            uVar19 = (ulonglong)*(uint *)(psVar31 + 2);
          }
          uVar26 = (uint)uVar19;
          if ((*(ulonglong *)(psVar31 + 0xf) != 0) &&
             (*(ulonglong *)(psVar31 + 0xf) < uVar19 + *(longlong *)(psVar31 + 4))) {
            *(undefined8 *)(puVar22 + -8) = 0x101cf2;
            cVar7 = func_0x(0x1111e60);
            if (cVar7 != '\0') {
              *(undefined8 *)(puVar22 + -8) = 0x101cfb;
              lVar11 = func_0x();
              if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                *(undefined8 *)(puVar22 + -8) = 0x101d15;
                cVar7 = func_0x(0x1111e60);
                if (cVar7 == '\0') {
                  *(undefined8 *)(puVar22 + -8) = 0x101d31;
                  (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(puVar22 + 0x20) = 0;
                  *(undefined8 *)(puVar22 + -8) = 0x101d57;
                  (*_DAT_)(1,0xa0186c,0xb21958);
                }
              }
            }
            uVar12 = *(undefined8 *)(psVar31 + 4);
            *(undefined8 *)(puVar22 + -8) = 0x101d65;
            func_0x(uVar12,0x12);
            uVar26 = *(uint *)(psVar32 + 2);
          }
          if ((uVar26 == 0) || (0x3f3c < uVar26)) {
            *(undefined8 *)(puVar22 + -8) = 0x101d85;
            cVar7 = func_0x(0x1111e60);
            if (cVar7 != '\0') {
              *(undefined8 *)(puVar22 + -8) = 0x101d8e;
              lVar11 = func_0x();
              if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                *(undefined8 *)(puVar22 + -8) = 0x101da8;
                cVar7 = func_0x(0x1111e60);
                if (cVar7 == '\0') {
                  *(undefined8 *)(puVar22 + -8) = 0x101dc4;
                  (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(puVar22 + 0x20) = 0;
                  *(undefined8 *)(puVar22 + -8) = 0x101dea;
                  (*_DAT_)(1,0xa0186c,0xb21958);
                }
              }
            }
            uVar12 = *(undefined8 *)(psVar31 + 4);
            *(undefined8 *)(puVar22 + -8) = 0x101df8;
            func_0x(uVar12,5);
            uVar26 = *(uint *)(psVar32 + 2);
          }
        }
code_r0x00101dfc:
        puVar27 = puStack_b70;
        param_2 = lStack_b50;
        uVar25 = uStack_b68;
        if ((uVar26 < 9) &&
           (((**(byte **)(psVar31 + 4) & 0xe) == 0 || ((**(byte **)(psVar31 + 4) & 0xe) == 0xc)))) {
          uVar26 = 9;
        }
      }
      else {
        uVar26 = *(uint *)(psVar31 + 2);
        if (uVar26 == 0) {
          *(undefined8 *)(puVar22 + -8) = 0x101e3c;
          func_0x(psVar31 + 1);
          uVar26 = *(uint *)(psVar31 + 2);
        }
        if ((uVar26 < 9) &&
           (((**(byte **)(psVar31 + 4) & 0x1c) == 0 || ((**(byte **)(psVar31 + 4) & 0x1c) == 0xc))))
        {
          uVar26 = 9;
        }
      }
      break;
    case '\x06':
      pcVar2 = *(code **)*plStack_b58;
      *(undefined8 *)(puVar22 + -8) = 0x101e7d;
      (*pcVar2)(plVar3,auStack_b08,8);
      puVar14 = auStack_b08;
      uVar26 = uStack_b78;
      break;
    case '\a':
      pcVar2 = *(code **)(*plStack_b58 + 8);
      *(undefined8 *)(puVar22 + -8) = 0x101ea4;
      (*pcVar2)(plVar3,auStack_af8,0x40);
      puVar14 = auStack_af8;
      uVar26 = uStack_b78;
      break;
    case '\b':
      iVar10 = puStack_b70[0x10] << 0xc;
      if (*psVar31 == 0) {
        uVar24 = *puStack_b70;
        if ((uVar24 & 0xc0000000) == 0x80000000) {
          *(undefined8 *)(puVar22 + -8) = 0x10167e;
          iVar10 = func_0x(psVar31 + 1);
          if (iVar10 == 0) {
code_r0x00100daf:
            uStack_b78 = 0;
            puVar14 = (uint *)0x0;
            uVar26 = uStack_b78;
          }
          else {
            *(undefined8 *)(puVar22 + -8) = 0x10169a;
            puVar14 = (uint *)func_0x(psVar31 + 0x15,puVar27,&uStack_b78);
            uVar26 = uStack_b78;
          }
        }
        else {
          if ((iVar10 < 0) || ((*(byte *)((longlong)puStack_b70 + 6) & 0x10) != 0)) {
            pbVar21 = *(byte **)(psVar31 + 4);
            if ((*pbVar21 & 0x10) == 0) {
              if ((1 << (*pbVar21 & 0xe) & 0x1105U) == 0) {
                uVar20 = uVar26;
                uVar26 = 1;
              }
              else {
code_r0x00100d35:
                uVar20 = ~(uint)(*(ushort *)((longlong)puStack_b70 + 6) >> 4) & 1;
              }
code_r0x00100d65:
              if (iVar10 < 0) {
code_r0x00100dab:
                if (uVar20 != 0) goto code_r0x00100daf;
              }
              if ((uVar26 == 0) && ((*(byte *)((longlong)puStack_b70 + 6) & 0x10) != 0)) {
                puVar14 = *(uint **)(puStack_b70 + 2) + 1;
                uVar26 = **(uint **)(puStack_b70 + 2);
                break;
              }
            }
            else {
              uVar20 = *(uint *)(psVar31 + 8);
              if ((int)uVar20 <= (int)uVar24) goto code_r0x00100d35;
              if ((uint)*(ushort *)(pbVar21 + uVar20) < (uint)*(ushort *)(puStack_b70 + 1)) {
                uVar20 = ~(uint)(*(ushort *)((longlong)puStack_b70 + 6) >> 4) & 1;
                uVar26 = 0;
                goto code_r0x00100d65;
              }
              if (iVar10 < 0) {
                uVar17 = *(ushort *)(puStack_b70 + 1) - 1;
                uVar26 = 1;
                uVar20 = pbVar21[(ulonglong)(uVar17 >> 3) + (ulonglong)uVar20 + 2] >>
                         ((byte)uVar17 & 7) & 1;
                goto code_r0x00100dab;
              }
            }
            puVar23 = (uint *)0x0;
          }
          if ((int)uVar24 < 0) {
            if (*(int *)(psVar31 + 2) == 0) {
              pbVar21 = *(byte **)(psVar31 + 4);
              uVar24 = *(uint *)(psVar31 + 8);
              uVar19 = (ulonglong)uVar24;
              psVar31[1] = (short)puVar23;
              *(uint *)(psVar31 + 10) = uVar24;
              bVar6 = *pbVar21;
              if ((bVar6 & 0x10) != 0) {
                uVar24 = uVar24 + 2 + (*(ushort *)(pbVar21 + uVar19) + 7 >> 3);
                uVar19 = (ulonglong)uVar24;
                *(uint *)(psVar31 + 10) = uVar24;
                bVar6 = *pbVar21;
              }
              if ((bVar6 & 0x20) == 0) {
                *(int *)(psVar31 + 2) = (int)uVar19;
                psVar31[0xe] = (short)puVar23;
                *(int *)(psVar31 + 0xc) = (int)uVar19;
              }
              else {
                puVar33 = (ushort *)(pbVar21 + uVar19);
                uVar8 = *puVar33;
                psVar31[0xe] = uVar8;
                if (uVar8 == 0) {
                  *(undefined8 *)(puVar22 + -8) = 0x100f05;
                  cVar7 = func_0x(0x1111e60);
                  if (cVar7 != '\0') {
                    *(undefined8 *)(puVar22 + -8) = 0x100f0e;
                    lVar11 = func_0x();
                    if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar22 + -8) = 0x100f28;
                      cVar7 = func_0x(0x1111e60);
                      if (cVar7 == '\0') {
                        *(undefined8 *)(puVar22 + -8) = 0x100f44;
                        (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                      }
                      else {
                        *(undefined8 *)(puVar22 + 0x20) = 0;
                        *(undefined8 *)(puVar22 + -8) = 0x100f83;
                        (*_DAT_)(1,0xa0186c,0xb21958);
                      }
                    }
                  }
                  uVar12 = *(undefined8 *)(psVar31 + 4);
                  *(undefined8 *)(puVar22 + -8) = 0x100f54;
                  func_0x(uVar12,3);
                  uVar19 = (ulonglong)*(uint *)(psVar31 + 10);
                  uVar8 = psVar31[0xe];
                }
                uVar24 = (int)uVar19 + (uint)uVar8 * 2 + 2;
                *(uint *)(psVar31 + 0xc) = uVar24;
                if (0x1f9e < uVar24) {
                  *(undefined8 *)(puVar22 + -8) = 0x100faf;
                  cVar7 = func_0x(0x1111e60);
                  if (cVar7 != '\0') {
                    *(undefined8 *)(puVar22 + -8) = 0x100fb8;
                    lVar11 = func_0x();
                    if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar22 + -8) = 0x100fd2;
                      cVar7 = func_0x(0x1111e60);
                      if (cVar7 == '\0') {
                        *(undefined8 *)(puVar22 + -8) = 0x100fee;
                        (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                      }
                      else {
                        *(undefined8 *)(puVar22 + 0x20) = 0;
                        *(undefined8 *)(puVar22 + -8) = 0x101014;
                        (*_DAT_)(1,0xa0186c,0xb21958);
                      }
                    }
                  }
                  uVar12 = *(undefined8 *)(psVar31 + 4);
                  *(undefined8 *)(puVar22 + -8) = 0x101022;
                  func_0x(uVar12,4);
                  uVar8 = psVar31[0xe];
                  uVar24 = *(uint *)(psVar31 + 0xc);
                }
                uVar19 = (ulonglong)uVar8;
                uVar8 = puVar33[uVar19];
                *(uint *)(psVar31 + 2) = uVar8 & 0x7fff;
                if ((uVar8 & 0x7fff) < uVar24) {
                  *(undefined8 *)(puVar22 + -8) = 0x101052;
                  cVar7 = func_0x(0x1111e60);
                  if (cVar7 != '\0') {
                    *(undefined8 *)(puVar22 + -8) = 0x10105b;
                    lVar11 = func_0x();
                    if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar22 + -8) = 0x101075;
                      cVar7 = func_0x(0x1111e60);
                      if (cVar7 == '\0') {
                        *(undefined8 *)(puVar22 + -8) = 0x101091;
                        (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                      }
                      else {
                        *(undefined8 *)(puVar22 + 0x20) = 0;
                        *(undefined8 *)(puVar22 + -8) = 0x1010b7;
                        (*_DAT_)(1,0xa0186c,0xb21958);
                      }
                    }
                  }
                  uVar12 = *(undefined8 *)(psVar31 + 4);
                  *(undefined8 *)(puVar22 + -8) = 0x1010c5;
                  func_0x(uVar12,4);
                  uVar24 = *(uint *)(psVar31 + 0xc);
                  uVar19 = (ulonglong)(ushort)psVar31[0xe];
                }
                iVar10 = 0;
                puVar34 = puVar33;
                if ((short)uVar19 != 0) {
                  do {
                    uVar25 = puVar34[1] & 0x7fff;
                    if ((uVar25 < uVar24) || (*(uint *)(psVar31 + 2) < uVar25)) {
                      *(undefined8 *)(puVar22 + -8) = 0x101102;
                      cVar7 = func_0x(0x1111e60);
                      if (cVar7 != '\0') {
                        *(undefined8 *)(puVar22 + -8) = 0x10110b;
                        lVar11 = func_0x();
                        if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar22 + -8) = 0x101125;
                          cVar7 = func_0x(0x1111e60);
                          if (cVar7 == '\0') {
                            *(undefined8 *)(puVar22 + -8) = 0x101141;
                            (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar22 + 0x20) = 0;
                            *(undefined8 *)(puVar22 + -8) = 0x101167;
                            (*_DAT_)(1,0xa0186c,0xb21958);
                          }
                        }
                      }
                      uVar12 = *(undefined8 *)(psVar31 + 4);
                      *(undefined8 *)(puVar22 + -8) = 0x101175;
                      func_0x(uVar12,4);
                    }
                    uVar19 = (ulonglong)(ushort)psVar31[0xe];
                    iVar10 = iVar10 + 1;
                    puVar34 = puVar34 + 1;
                    uVar24 = uVar25;
                  } while (iVar10 < (int)(uint)(ushort)psVar31[0xe]);
                }
                if ((short)puVar33[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
                  pbVar21 = *(byte **)(psVar31 + 4);
                  do {
                    uVar24 = *(ushort *)(pbVar21 + uVar19 * 2 + (ulonglong)*(uint *)(psVar31 + 10))
                             & 0x7fff;
                    if ((int)uVar19 == 1) {
                      uVar25 = *(uint *)(psVar31 + 0xc);
                      uVar26 = uVar25;
code_r0x001011e4:
                      if ((uVar24 < uVar25) || (*(uint *)(psVar31 + 2) < uVar24))
                      goto code_r0x001011ee;
                    }
                    else {
                      uVar26 = *(uint *)(psVar31 + 0xc);
                      uVar25 = *(ushort *)
                                (pbVar21 + uVar19 * 2 + ((ulonglong)*(uint *)(psVar31 + 10) - 2)) &
                               0x7fff;
                      if (uVar26 <= uVar25) goto code_r0x001011e4;
code_r0x001011ee:
                      *(undefined8 *)(puVar22 + -8) = 0x1011fb;
                      func_0x(pbVar21,7);
                      uVar26 = *(uint *)(psVar31 + 0xc);
                    }
                    puVar27 = puStack_b70;
                    if ((uVar25 < uVar26) || (*(uint *)(psVar31 + 2) < uVar25))
                    goto code_r0x0010157e;
                    pbVar21 = *(byte **)(psVar31 + 4);
                    if (*(ushort *)(pbVar21 + uVar25) == 5) {
                      psVar31[1] = psVar31[1] | 2;
                      psVar31[0xe] = psVar31[0xe] + -1;
                      uVar9 = psVar31[0x16] & 0xc7ff;
                      psVar31[0x15] = (short)uVar25;
                      uVar19 = *(ulonglong *)(psVar31 + 4);
                      uVar8 = *(ushort *)((ulonglong)(uVar25 & 0xffff) + 2 + uVar19);
                      if ((uVar8 >> 0xe & 1) != 0) {
                        uVar9 = uVar8 & 0x3800 | uVar9;
                      }
                      psVar31[0x16] = uVar9;
                      uVar30 = (ulonglong)(ushort)psVar31[0x15];
                      uVar8 = (uVar9 ^ *(ushort *)((ulonglong)(uVar25 & 0xffff) + 2 + uVar19)) &
                              0x7ff ^ uVar9;
                      psVar31[0x16] = uVar8;
                      uVar18 = (ulonglong)((uVar8 & 0x7ff) * 2) + 4 +
                               uVar30 + (uVar9 >> 0xb & 7) * 2 + uVar19;
                      if (uVar18 < uVar30 + uVar19) {
                        *(undefined8 *)(puVar22 + -8) = 0x10131c;
                        func_0x(uVar30 + uVar19,0x19);
                        uVar8 = psVar31[0x16];
                        uVar30 = (ulonglong)(ushort)psVar31[0x15];
                        uVar19 = (ulonglong)*(uint *)(psVar31 + 4);
                      }
                      if (uVar24 - uVar25 <
                          (((uVar8 & 0x7ff) * 2 - (int)uVar30) - (int)uVar19) + (int)uVar18) {
                        lVar11 = *(longlong *)(psVar31 + 4);
                        *(undefined8 *)(puVar22 + -8) = 0x101354;
                        func_0x(uVar30 + lVar11,0x19);
                        uVar8 = psVar31[0x16];
                      }
                      iVar10 = 0;
                      if (((uVar8 & 0x3800) != 0) &&
                         (puVar33 = (ushort *)
                                    (*(longlong *)(psVar31 + 4) + 4 +
                                    (ulonglong)(ushort)psVar31[0x15]), (uVar8 & 0x3800) != 0)) {
                        do {
                          if ((uVar8 & 0x7ff) < (*puVar33 & 0x7ff)) {
                            uVar8 = psVar31[0x15];
                            lVar11 = *(longlong *)(psVar31 + 4);
                            *(undefined8 *)(puVar22 + -8) = 0x1013b8;
                            func_0x((ulonglong)uVar8 + lVar11,0x1a);
                            uVar8 = psVar31[0x16];
                          }
                          iVar10 = iVar10 + 1;
                          puVar33 = puVar33 + 1;
                        } while (iVar10 < (int)(uVar8 >> 0xb & 7));
                      }
                      goto code_r0x001013d7;
                    }
                    if (*(ushort *)(pbVar21 + uVar25) < 0x400) goto code_r0x001013d7;
                    psVar31[1] = psVar31[1] | 1;
                    uVar8 = psVar31[0xe] - 1;
                    psVar31[0xe] = uVar8;
                    if (uVar8 == 0) goto code_r0x001013d7;
                    uVar19 = (ulonglong)uVar8;
                  } while ((short)puVar33[(ulonglong)(uVar8 - 1) + 1] < 0);
                  uVar19 = (ulonglong)*(uint *)(psVar31 + 2);
                  puVar23 = (uint *)0x0;
                }
                else {
code_r0x001013d7:
                  puVar23 = (uint *)0x0;
                  pbVar21 = *(byte **)(psVar31 + 4);
                  uVar19 = (ulonglong)*(uint *)(psVar31 + 2);
                }
              }
              puVar27 = puStack_b70;
              if ((*pbVar21 & 0x40) == 0) {
                *(int *)(psVar31 + 0x13) = (int)puVar23;
              }
              else {
                *(int *)(psVar31 + 0x13) = (int)uVar19;
                *(int *)(psVar31 + 2) = (int)uVar19 + 0xe;
                *(undefined8 *)(puVar22 + -8) = 0x10140c;
                uVar12 = func_0x(psVar31 + 1);
                *(undefined8 *)(puVar22 + -8) = 0x101418;
                func_0x(uVar12,auStack_b20);
                *(undefined8 *)(puVar22 + -8) = 0x101421;
                iVar10 = func_0x(auStack_b20);
                *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + iVar10;
                uVar19 = (ulonglong)*(uint *)(psVar31 + 2);
              }
              iVar10 = (int)uVar19;
              if ((*(ulonglong *)(psVar31 + 0xf) != 0) &&
                 (*(ulonglong *)(psVar31 + 0xf) < uVar19 + *(longlong *)(psVar31 + 4))) {
                *(undefined8 *)(puVar22 + -8) = 0x10145b;
                cVar7 = func_0x(0x1111e60);
                if (cVar7 != '\0') {
                  *(undefined8 *)(puVar22 + -8) = 0x101464;
                  lVar11 = func_0x();
                  if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar22 + -8) = 0x10147e;
                    cVar7 = func_0x(0x1111e60);
                    if (cVar7 == '\0') {
                      *(undefined8 *)(puVar22 + -8) = 0x10149a;
                      (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                    }
                    else {
                      *(undefined8 *)(puVar22 + 0x20) = 0;
                      *(undefined8 *)(puVar22 + -8) = 0x1014c0;
                      (*_DAT_)(1,0xa0186c,0xb21958);
                    }
                  }
                }
                uVar12 = *(undefined8 *)(psVar31 + 4);
                *(undefined8 *)(puVar22 + -8) = 0x1014ce;
                func_0x(uVar12,0x12);
                iVar10 = *(int *)(psVar31 + 2);
              }
              if (0x3f3b < iVar10 - 1U) {
                *(undefined8 *)(puVar22 + -8) = 0x1014ec;
                cVar7 = func_0x(0x1111e60);
                if (cVar7 != '\0') {
                  *(undefined8 *)(puVar22 + -8) = 0x1014f5;
                  lVar11 = func_0x();
                  if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar22 + -8) = 0x10150f;
                    cVar7 = func_0x(0x1111e60);
                    if (cVar7 != '\0') {
                      *(undefined8 *)(puVar22 + 0x20) = 0;
                      *(undefined8 *)(puVar22 + -8) = 0x101565;
                      (*_DAT_)(1,0xa0186c,0xb21958);
                      uVar12 = *(undefined8 *)(psVar31 + 4);
                      *(undefined8 *)(puVar22 + -8) = 0x101573;
                      func_0x(uVar12,5);
                      goto code_r0x0010157e;
                    }
                    *(undefined8 *)(puVar22 + -8) = 0x10152b;
                    (*pcRam000000000067f9e8)(0x22,0x44,0x15);
                  }
                }
                uVar12 = *(undefined8 *)(psVar31 + 4);
                *(undefined8 *)(puVar22 + -8) = 0x10153c;
                func_0x(uVar12,5);
              }
            }
code_r0x0010157e:
            sVar28 = -*(short *)puVar27;
            param_2 = lStack_b50;
            uVar25 = uStack_b68;
            if ((*(byte *)((longlong)puVar27 + 6) & 0x10) != 0) {
              bVar6 = **(byte **)(psVar31 + 4);
              if ((bVar6 & 0x10) == 0) {
                if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
code_r0x001015f0:
                  puVar14 = *(uint **)(puVar27 + 2) + 1;
                  uVar26 = **(uint **)(puVar27 + 2);
                  break;
                }
              }
              else if (((int)*(uint *)(psVar31 + 8) <= (int)*puVar27) ||
                      (*(ushort *)(*(byte **)(psVar31 + 4) + *(uint *)(psVar31 + 8)) <
                       *(ushort *)(puVar27 + 1))) goto code_r0x001015f0;
            }
            lVar11 = (longlong)sVar28;
            if ((uint)(ushort)psVar31[0xe] < (uint)(int)sVar28) {
              uStack_b78 = 0;
              puVar14 = *(uint **)(psVar31 + 4);
              uVar26 = uStack_b78;
            }
            else {
              lVar29 = *(longlong *)(psVar31 + 4);
              lVar13 = (ulonglong)*(uint *)(psVar31 + 10) + lVar29;
              if (sVar28 == 1) {
                uVar24 = *(uint *)(psVar31 + 0xc);
                uVar26 = *(ushort *)(lVar13 + lVar11 * 2) & 0x7fff;
code_r0x0010162c:
                if ((uVar26 < uVar24) || (*(uint *)(psVar31 + 2) < uVar26)) goto code_r0x00101636;
              }
              else {
                uVar24 = *(ushort *)(lVar13 + -2 + lVar11 * 2) & 0x7fff;
                lVar29 = *(longlong *)(psVar31 + 4);
                uVar26 = *(ushort *)(lVar13 + lVar11 * 2) & 0x7fff;
                if (*(uint *)(psVar31 + 0xc) <= uVar24) goto code_r0x0010162c;
code_r0x00101636:
                *(undefined8 *)(puVar22 + -8) = 0x101643;
                func_0x(lVar29,7);
              }
              puVar27 = puStack_b70;
              puVar14 = (uint *)((ulonglong)uVar24 + *(longlong *)(psVar31 + 4));
              param_2 = lStack_b50;
              uVar25 = uStack_b68;
              uVar26 = uVar26 - uVar24;
            }
          }
          else {
            uVar8 = *(ushort *)((longlong)puStack_b70 + 6);
            if ((uVar8 & 8) == 0) {
              uVar20 = (uint)*(ushort *)(puStack_b70 + 0xf);
              if ((uVar8 & 0x10) == 0) {
code_r0x00100df9:
                puVar14 = (uint *)((longlong)(int)*puStack_b70 + *(longlong *)(psVar31 + 4));
                uVar26 = uVar20;
              }
              else {
                bVar6 = **(byte **)(psVar31 + 4);
                if ((bVar6 & 0x10) == 0) {
                  if ((1 << (bVar6 & 0xe) & 0x1105U) == 0) goto code_r0x00100df9;
                }
                else if (((int)uVar24 < (int)*(uint *)(psVar31 + 8)) &&
                        (*(ushort *)(puStack_b70 + 1) <=
                         *(ushort *)(*(byte **)(psVar31 + 4) + *(uint *)(psVar31 + 8))))
                goto code_r0x00100df9;
                uVar26 = **(uint **)(puStack_b70 + 2);
                puVar14 = *(uint **)(puStack_b70 + 2) + 1;
                if ((uVar20 != 0) && (uVar26 != uVar20)) {
                  *(uint **)(puVar22 + 0x20) = puVar23;
                  *(undefined8 *)(puVar22 + -8) = 0x100e5e;
                  (*_DAT_)(1,0xbafcb0,0xbae618);
                }
              }
            }
            else {
              uStack_b78 = 1;
              puVar14 = (uint *)0x786500;
              uVar26 = uStack_b78;
              if ((*(byte *)((longlong)(int)uVar24 + *(longlong *)(psVar31 + 4)) &
                  (byte)(1 << ((byte)uVar8 & 7))) == 0) {
                puVar14 = (uint *)0x786501;
              }
            }
          }
        }
      }
      else {
        uStack_b5c = uVar26;
        *(uint **)(puVar22 + 0x20) = &uStack_b5c;
        *(undefined8 *)(puVar22 + -8) = 0x1016bf;
        puVar14 = (uint *)func_0x(psVar31 + 1,puVar27);
        uVar26 = uStack_b78;
        if ((((*psVar31 != 0) && (plVar3 = *(longlong **)(psVar31 + 8), plVar3 != (longlong *)0x0))
            && (*plVar3 != 0)) &&
           (((*(byte *)((longlong)puVar27 + 6) & 8) == 0 && ((uStack_b5c & 1) == 0)))) {
          if ((puVar14 == (uint *)0x0) || (puVar14 == (uint *)0x786500)) goto code_r0x00100daf;
          *(uint *)(puVar22 + 0x38) = uStack_b5c;
          *(uint **)(puVar22 + 0x30) = &uStack_b78;
          *(undefined4 *)(puVar22 + 0x28) = 0;
          *(undefined8 *)(puVar22 + 0x20) = 0;
          *(undefined8 *)(puVar22 + -8) = 0x101733;
          puVar14 = (uint *)func_0x(plVar3,puVar27,puVar14);
          uVar26 = uStack_b78;
        }
      }
      break;
    case '\t':
    case '\n':
      pcVar2 = *(code **)(*plStack_b58 + 0x10);
      *(undefined8 *)(puVar22 + -8) = 0x101eba;
      auStack_b40[0] = (*pcVar2)(plVar3);
      uStack_b78 = 4;
      puVar14 = auStack_b40;
      uVar26 = uStack_b78;
      break;
    default:
      *(undefined8 *)(puVar22 + 0x20) = 0x77cdd0;
      *(undefined8 *)(puVar22 + -8) = 0x101f12;
      (*_DAT_)(1,0xb83160,0xb89548);
      uVar26 = uStack_b78;
      break;
    case '\x19':
      pcVar2 = *(code **)(*plStack_b58 + 0x20);
      *(undefined8 *)(puVar22 + -8) = 0x101ee5;
      (*pcVar2)(plVar3,auStack_ab8,0xa59);
      puVar14 = auStack_ab8;
      uVar26 = uStack_b78;
    }
    uStack_b78 = uVar26;
    uVar24 = puVar27[0x10];
    if ((uVar24 >> 10 & 1) != 0) {
      if ((*(byte *)(*(longlong *)(puVar27 + 0x12) + 0x2a) & 0x10) == 0) {
        lVar11 = *(longlong *)(param_2 + 0x18);
      }
      else {
        lVar11 = *(longlong *)(param_2 + 0x20);
      }
      uVar16 = 0;
      if (puVar14 == (uint *)0x0) {
        uVar16 = 3;
      }
      *(undefined *)(lVar11 + *(longlong *)(puVar27 + 0xc)) = uVar16;
      uVar24 = puVar27[0x10];
    }
    if ((uVar24 >> 9 & 1) != 0) {
      *(uint *)(puVar22 + 0x20) = uStack_b78;
      *(undefined8 *)(puVar22 + -8) = 0x101f6a;
      func_0x(param_2);
    }
    puVar23 = (uint *)0x0;
    uVar19 = (ulonglong)uStack_b74;
code_r0x00101f85:
    uStack_b68 = uVar25 + 1;
    uVar18 = (ulonglong)uStack_b68;
    puStack_b70 = puVar27 + 0x14;
    psVar31 = psVar32;
  } while (uStack_b68 < (uint)uVar19);
LAB_:
  if (((longlong *)plStack_b58[2] != (longlong *)0x0) && (*piStack_b48 == 0)) {
    pcVar2 = *(code **)(*(longlong *)plStack_b58[2] + 8);
    *(undefined8 *)(puVar22 + -8) = 0x101fb9;
    (*pcVar2)();
  }
  uVar19 = uStack_58 ^ (ulonglong)&uStack_b78;
  *(undefined8 *)(puVar22 + -8) = 0x101fc8;
  func_0x(uVar19);
  return;
}

