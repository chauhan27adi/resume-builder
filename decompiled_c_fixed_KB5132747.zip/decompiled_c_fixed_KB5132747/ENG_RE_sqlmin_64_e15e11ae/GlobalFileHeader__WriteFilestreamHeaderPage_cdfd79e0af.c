
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,char param_2,undefined4 param_3,undefined4 param_4,
                 undefined2 param_5,undefined *param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined8 param_10,undefined4 param_11,undefined8 param_12,
                 undefined8 param_13,undefined8 param_14,undefined8 param_15,undefined8 param_16,
                 undefined4 param_17,undefined8 param_18,undefined8 param_19,undefined8 param_20,
                 undefined8 param_21,undefined8 param_22,undefined8 param_23,undefined8 param_24,
                 undefined8 param_25,undefined8 param_26,undefined8 param_27,undefined8 param_28,
                 undefined8 param_29,undefined8 param_30,undefined8 param_31,undefined8 param_32)

{
  byte *pbVar1;
  ushort *puVar2;
  char cVar3;
  byte bVar4;
  ushort uVar5;
  int iVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong *plVar9;
  ulonglong uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  ulonglong uVar14;
  byte *pbVar15;
  byte *pbVar16;
  ulonglong uVar17;
  ulonglong uVar18;
  ushort *puVar19;
  uint uVar20;
  int iVar21;
  undefined auStack_dd8 [32];
  undefined8 uStack_db8;
  undefined *puStack_db0;
  undefined4 uStack_da8;
  undefined4 uStack_da0;
  undefined4 uStack_d98;
  undefined8 uStack_d90;
  undefined4 uStack_d88;
  undefined8 uStack_d80;
  undefined8 uStack_d78;
  undefined8 uStack_d70;
  undefined8 uStack_d68;
  undefined8 uStack_d60;
  undefined4 uStack_d58;
  undefined8 uStack_d50;
  undefined8 uStack_d48;
  undefined8 uStack_d40;
  undefined8 uStack_d38;
  undefined8 uStack_d30;
  undefined8 uStack_d28;
  undefined8 uStack_d20;
  undefined8 uStack_d18;
  undefined8 uStack_d10;
  undefined8 uStack_d08;
  undefined8 uStack_d00;
  undefined8 uStack_cf8;
  undefined8 uStack_cf0;
  undefined8 uStack_ce8;
  char cStack_cd8;
  short sStack_cd0;
  ushort uStack_cce;
  uint uStack_ccc;
  byte *pbStack_cc8;
  undefined8 uStack_cc0;
  uint uStack_cb8;
  ushort uStack_cb4;
  byte *pbStack_cb2;
  undefined2 uStack_caa;
  undefined2 uStack_ca8;
  ushort uStack_ca6;
  ushort uStack_ca4;
  undefined2 uStack_ca2;
  undefined4 uStack_c98;
  undefined4 uStack_c94;
  undefined4 auStack_c90 [2];
  undefined *puStack_c88;
  undefined8 uStack_c80;
  undefined8 uStack_c78;
  undefined8 uStack_c70;
  undefined8 uStack_c68;
  undefined8 uStack_c60;
  undefined8 uStack_c58;
  undefined8 uStack_c50;
  undefined auStack_c48 [16];
  undefined auStack_c38 [16];
  undefined4 uStack_c28;
  uint uStack_c24;
  byte abStack_c20 [1528];
  undefined auStack_628 [1504];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_dd8;
  puStack_c88 = param_6;
  uStack_c58 = param_12;
  uStack_c60 = param_13;
  uStack_c68 = param_14;
  uStack_c70 = param_15;
  uStack_c78 = param_16;
  uStack_ce8 = param_32;
  uStack_c80 = param_18;
  sStack_cd0 = -1;
  uStack_cf0 = param_31;
  uStack_cf8 = param_30;
  uStack_d00 = param_29;
  uStack_d08 = param_28;
  uStack_d10 = param_26;
  uStack_d18 = param_25;
  uStack_d20 = param_24;
  uStack_d28 = param_23;
  uStack_d30 = param_22;
  uStack_d38 = param_21;
  uStack_d40 = param_20;
  uStack_d48 = param_19;
  pbStack_cc8 = (byte *)0x0;
  uStack_ccc = 0;
  pbStack_cb2 = (byte *)0x0;
  uStack_ca8 = 0;
  uStack_ca6 = 0;
  uStack_ca4 = 0;
  uStack_ca2 = 0;
  uStack_cc0 = 0;
  auStack_c90[0] = 0;
  uStack_d50 = param_18;
  uStack_d58 = param_17;
  uStack_d60 = param_16;
  uStack_d68 = param_15;
  uStack_d70 = param_14;
  uStack_d78 = param_13;
  uStack_d80 = param_12;
  uStack_d88 = param_11;
  uStack_d90 = param_10;
  uStack_d98 = param_9;
  uStack_da0 = param_8;
  uStack_da8 = param_7;
  auStack_c48 = ZEXT816(0);
  auStack_c38 = ZEXT816(0);
  puStack_db0 = param_6;
  uStack_db8 = (undefined4 *)CONCAT62(uStack_db8._2_6_,param_5);
  cStack_cd8 = param_2;
  uStack_c98 = param_4;
  uStack_c94 = param_3;
  uStack_c50 = param_1;
  func_0x(&sStack_cd0,auStack_628,param_3,param_4);
  if (sStack_cd0 == 0) {
    pbVar16 = pbStack_cc8;
    uVar11 = uStack_ccc;
    if (uStack_ccc == 0) {
      uVar10 = uStack_cc0 & 0xffffffff;
      iVar6 = 0;
      uStack_cce = 0;
      uVar11 = (uint)uStack_cc0;
      if ((*pbStack_cc8 & 0x10) != 0) {
        uVar11 = (uint)uStack_cc0 + 2 + (*(ushort *)(pbStack_cc8 + uVar10) + 7 >> 3);
        uVar10 = (ulonglong)uVar11;
      }
      uStack_cc0 = CONCAT44(uVar11,(uint)uStack_cc0);
      uStack_cb8 = (uint)uVar10;
      if ((*pbStack_cc8 & 0x20) == 0) {
        uStack_cb4 = 0;
        uStack_ccc = uStack_cb8;
      }
      else {
        puVar19 = (ushort *)(pbStack_cc8 + uVar10);
        uStack_cb4 = *puVar19;
        if (uStack_cb4 == 0) {
          cVar3 = func_0x(0x1ab0310);
          if (((cVar3 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
             (*(char *)(lVar7 + 0x499) != '\0')) {
            cVar3 = func_0x(0x1ab0310);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_db8 = (undefined4 *)0x0;
              (*_DAT_)(1,0x139fd1c,0x14bfe08,0x80f);
            }
          }
          func_0x(pbStack_cc8,3);
        }
        uStack_cb8 = uStack_cc0._4_4_ + 2 + (uint)uStack_cb4 * 2;
        if (0x1f9e < uStack_cb8) {
          cVar3 = func_0x(0x1ab0310);
          if (((cVar3 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
             (*(char *)(lVar7 + 0x499) != '\0')) {
            cVar3 = func_0x(0x1ab0310);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_db8 = (undefined4 *)0x0;
              (*_DAT_)(1,0x139fd1c,0x14bfe08,0x816);
            }
          }
          func_0x(pbStack_cc8,4);
        }
        uVar17 = (ulonglong)uStack_cb4;
        uStack_ccc = puVar19[uVar17] & 0x7fff;
        if (uStack_ccc < uStack_cb8) {
          cVar3 = func_0x(0x1ab0310);
          if (((cVar3 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
             (*(char *)(lVar7 + 0x499) != '\0')) {
            cVar3 = func_0x(0x1ab0310);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_db8 = (undefined4 *)0x0;
              (*_DAT_)(1,0x139fd1c,0x14bfe08,0x81d);
            }
          }
          func_0x(pbStack_cc8,4);
          uVar17 = (ulonglong)uStack_cb4;
        }
        uVar10 = (ulonglong)uStack_ccc;
        pbVar16 = pbStack_cc8;
        puVar2 = puVar19;
        iVar21 = iVar6;
        uVar11 = uStack_cb8;
        uVar12 = uStack_cb8;
        if ((short)uVar17 != 0) {
          do {
            uVar12 = puVar2[1] & 0x7fff;
            if ((uVar12 < uVar11) || ((uint)uVar10 < uVar12)) {
              cVar3 = func_0x(0x1ab0310);
              if ((cVar3 != '\0') &&
                 ((lVar7 = func_0x(), lVar7 != 0 &&
                  (*(char *)(lVar7 + 0x499) != '\0')))) {
                cVar3 = func_0x(0x1ab0310);
                if (cVar3 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_db8 = (undefined4 *)0x0;
                  (*_DAT_)(1,0x139fd1c,0x14bfe08,0x82a);
                }
              }
              func_0x(pbStack_cc8,4);
              uVar17 = (ulonglong)uStack_cb4;
              uVar10 = (ulonglong)uStack_ccc;
              pbVar16 = pbStack_cc8;
            }
            iVar21 = iVar21 + 1;
            puVar2 = puVar2 + 1;
            uVar11 = uVar12;
            uVar12 = uStack_cb8;
          } while (iVar21 < (int)uVar17);
        }
        while ((short)puVar19[(ulonglong)((int)uVar17 - 1) + 1] < 0) {
          if ((int)uVar17 == 1) {
            uVar14 = 1;
            uVar13 = uVar12;
          }
          else {
            uVar13 = *(ushort *)(pbVar16 + uVar17 * 2 + ((uStack_cc0 >> 0x20) - 2)) & 0x7fff;
            uVar14 = uVar17;
          }
          uVar20 = *(ushort *)(pbVar16 + uVar14 * 2 + (uStack_cc0 >> 0x20)) & 0x7fff;
          if (((uVar13 < uVar12) || (uVar20 < uVar13)) || ((uint)uVar10 < uVar20)) {
            func_0x(pbVar16,7);
            uVar17 = (ulonglong)uStack_cb4;
            uVar10 = (ulonglong)uStack_ccc;
            pbVar16 = pbStack_cc8;
            uVar12 = uStack_cb8;
          }
          uVar11 = (uint)uVar10;
          if ((uVar13 < uVar12) || (uVar11 < uVar13)) goto LAB_;
          if (*(ushort *)(pbVar16 + uVar13) == 5) {
            uStack_cce = uStack_cce | 2;
            uStack_cb4 = (short)uVar17 - 1;
            uVar17 = (ulonglong)(uVar13 & 0xffff);
            pbVar1 = pbVar16 + uVar17;
            uStack_ca6 = (ushort)uVar13;
            if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
              uVar5 = uStack_ca4 & 0xc7ff;
            }
            else {
              uVar5 = uStack_ca4 ^ (*(ushort *)(pbVar1 + 2) ^ uStack_ca4) & 0x3800;
            }
            uStack_ca4 = (uVar5 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar5;
            uVar18 = (ulonglong)uStack_ca4;
            uVar14 = uVar18 & 0x7ff;
            lVar7 = (ulonglong)((uVar5 >> 0xb & 7) * 2) + 4 + uVar17;
            pbVar15 = pbVar16;
            if (pbVar16 + lVar7 + uVar14 * 2 < pbVar1) {
              func_0x(pbVar1,0x19);
              uVar18 = (ulonglong)uStack_ca4;
              uVar17 = (ulonglong)uStack_ca6;
              uVar10 = (ulonglong)uStack_ccc;
              pbVar15 = pbStack_cc8;
            }
            if (uVar20 - uVar13 <
                (((uStack_ca4 & 0x7ff) * 2 - (int)uVar17) - (int)pbStack_cc8) +
                (int)(pbVar16 + lVar7 + uVar14 * 2)) {
              func_0x(pbVar15 + uVar17,0x19);
              uVar18 = (ulonglong)uStack_ca4;
              uVar17 = (ulonglong)uStack_ca6;
              uVar10 = (ulonglong)uStack_ccc;
              pbVar15 = pbStack_cc8;
            }
            pbVar16 = pbVar15;
            if (((uVar18 & 0x3800) != 0) &&
               (puVar19 = (ushort *)(pbVar15 + uVar17 + 4), (uVar18 & 0x3800) != 0)) {
              do {
                if (((ushort)uVar18 & 0x7ff) < (*puVar19 & 0x7ff)) {
                  func_0x(pbVar15 + uVar17,0x1a);
                  uVar18 = (ulonglong)uStack_ca4;
                  uVar17 = (ulonglong)uStack_ca6;
                  pbVar15 = pbStack_cc8;
                }
                iVar6 = iVar6 + 1;
                puVar19 = puVar19 + 1;
              } while (iVar6 < (int)((uStack_ca4 & 0x3800) >> 0xb));
              uVar10 = (ulonglong)uStack_ccc;
              pbVar16 = pbVar15;
            }
            break;
          }
          if (*(ushort *)(pbVar16 + uVar13) < 0x400) break;
          uStack_cce = uStack_cce | 1;
          uStack_cb4 = (short)uVar17 - 1;
          uVar17 = (ulonglong)uStack_cb4;
          if (uStack_cb4 == 0) break;
        }
      }
      if ((*pbVar16 & 0x40) == 0) {
        uStack_caa = 0;
        uStack_ca8 = 0;
      }
      else {
        uStack_caa = (undefined2)uVar10;
        uStack_ca8 = (undefined2)(uVar10 >> 0x10);
        uStack_ccc = (int)uVar10 + 0xe;
        uVar8 = func_0x(&uStack_cce);
        func_0x(uVar8,&puStack_c88);
        iVar6 = func_0x(&puStack_c88);
        uStack_ccc = uStack_ccc + iVar6;
        uVar10 = (ulonglong)uStack_ccc;
        pbVar16 = pbStack_cc8;
      }
      uVar11 = (uint)uVar10;
      if ((pbStack_cb2 != (byte *)0x0) && (pbStack_cb2 < pbVar16 + uVar10)) {
        cVar3 = func_0x(0x1ab0310);
        if ((cVar3 != '\0') &&
           ((lVar7 = func_0x(), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0'))))
        {
          cVar3 = func_0x(0x1ab0310);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_db8 = (undefined4 *)0x0;
            (*_DAT_)(1,0x139fd1c,0x14bfe08,0x886);
          }
        }
        func_0x(pbStack_cc8,0x12);
        pbVar16 = pbStack_cc8;
        uVar11 = uStack_ccc;
      }
      if (0x3f3b < uVar11 - 1) {
        cVar3 = func_0x(0x1ab0310);
        if (((cVar3 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
           (*(char *)(lVar7 + 0x499) != '\0')) {
          cVar3 = func_0x(0x1ab0310);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_db8 = (undefined4 *)0x0;
            (*_DAT_)(1,0x139fd1c,0x14bfe08,0x88b);
          }
        }
        func_0x(pbStack_cc8,5);
        pbVar16 = pbStack_cc8;
        uVar11 = uStack_ccc;
      }
    }
LAB_:
    if (uVar11 < 9) {
      bVar4 = *pbVar16 & 0xe;
joined_r0x0010090a:
      if ((bVar4 == 0) || (bVar4 == 0xc)) {
        uVar11 = 9;
      }
    }
  }
  else {
    if (uStack_ccc == 0) {
      func_0x(&uStack_cce);
    }
    pbVar16 = pbStack_cc8;
    uVar11 = uStack_ccc;
    if (uStack_ccc < 9) {
      bVar4 = *pbStack_cc8 & 0x1c;
      goto joined_r0x0010090a;
    }
  }
  func_0x(&uStack_c24,0,0x5fc);
  iVar6 = 0x600;
  uStack_c28 = 4;
  if (cStack_cd8 == '\0') {
    iVar6 = uVar11 + 8;
  }
  func_0x(abStack_c20,0x5f8,pbVar16,uVar11);
  uVar8 = uStack_c50;
  uVar10 = 0xffffffff;
  uStack_c24 = 0xffffffff;
  uVar17 = (ulonglong)(iVar6 - 8U);
  pbVar16 = abStack_c20;
  if (iVar6 - 8U != 0) {
    do {
      bVar4 = *pbVar16;
      pbVar16 = pbVar16 + 1;
      uStack_c24 = (uint)uVar10 >> 8 ^ *(uint *)(((uVar10 ^ bVar4) & 0xff) * 4 + 0x113c6d0);
      uVar10 = (ulonglong)uStack_c24;
      uVar17 = uVar17 - 1;
    } while (uVar17 != 0);
  }
  plVar9 = (longlong *)func_0x(uStack_c50);
  if (plVar9 != (longlong *)0x0) {
    iVar21 = (**(code **)(*plVar9 + 0xc0))(plVar9,uVar8,iVar6);
    if (iVar21 == 0) goto LAB_;
    plVar9 = (longlong *)func_0x(uVar8);
    if (plVar9 != (longlong *)0x0) {
      puStack_db0 = auStack_c48;
      uStack_db8 = auStack_c90;
      iVar6 = (**(code **)(*plVar9 + 0xe0))(plVar9,uVar8,&uStack_c28,iVar6);
      if (iVar6 == 0) goto LAB_;
      plVar9 = (longlong *)func_0x(uVar8);
      if (plVar9 != (longlong *)0x0) {
        (**(code **)(*plVar9 + 200))(plVar9,uVar8);
        goto LAB_;
      }
    }
  }
  (*_DAT_)(0x32);
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_dd8);
  return;
}

