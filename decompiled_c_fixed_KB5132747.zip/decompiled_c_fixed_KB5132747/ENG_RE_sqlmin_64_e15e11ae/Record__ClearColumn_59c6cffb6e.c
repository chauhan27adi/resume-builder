
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,uint *param_2)

{
  ushort *puVar1;
  short *psVar2;
  byte bVar3;
  char cVar4;
  ushort uVar5;
  ushort uVar6;
  short sVar7;
  int iVar8;
  undefined4 uVar9;
  longlong lVar10;
  undefined8 uVar11;
  ushort **ppuVar12;
  ulonglong uVar13;
  byte *pbVar14;
  uint uVar15;
  ulonglong uVar16;
  uint uVar17;
  uint uVar18;
  ushort *puVar19;
  ushort *puVar20;
  uint uVar21;
  int iVar22;
  ulonglong uVar23;
  undefined auStack_1a8 [32];
  uint *puStack_188;
  undefined8 uStack_180;
  uint auStack_178 [2];
  ushort *puStack_170;
  undefined8 uStack_168;
  ushort *puStack_160;
  uint *puStack_158;
  undefined auStack_150 [16];
  undefined auStack_140 [24];
  undefined auStack_128 [224];
  ulonglong uStack_48;
  
  cVar4 = DAT_;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_1a8;
  puVar1 = (ushort *)(param_1 + 1);
  uStack_168 = param_1;
  puStack_158 = param_2;
  if (*param_1 != 0) {
    func_0x(puVar1);
    goto LAB_;
  }
  uVar15 = *param_2;
  if (-1 < (int)uVar15) {
    uVar18 = (uint)*(ushort *)((longlong)param_2 + 6);
    if ((*(ushort *)((longlong)param_2 + 6) & 8) == 0) {
      if (*(int *)(param_1 + 2) == 0) {
        pbVar14 = *(byte **)(param_1 + 4);
        iVar8 = 0;
        uVar15 = *(uint *)(param_1 + 8);
        uVar13 = (ulonglong)uVar15;
        *puVar1 = 0;
        *(uint *)(param_1 + 10) = uVar15;
        bVar3 = *pbVar14;
        if ((bVar3 & 0x10) != 0) {
          uVar15 = uVar15 + 2 + (*(ushort *)(pbVar14 + uVar13) + 7 >> 3);
          uVar13 = (ulonglong)uVar15;
          *(uint *)(param_1 + 10) = uVar15;
          bVar3 = *pbVar14;
        }
        if ((bVar3 & 0x20) == 0) {
          *(int *)(param_1 + 2) = (int)uVar13;
          param_1[0xe] = 0;
          *(int *)(param_1 + 0xc) = (int)uVar13;
        }
        else {
          puVar19 = (ushort *)(pbVar14 + uVar13);
          uVar5 = *puVar19;
          param_1[0xe] = uVar5;
          puStack_170 = puVar19;
          if (uVar5 == 0) {
            cVar4 = func_0x(0x1106180);
            if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
               (*(char *)(lVar10 + 0x499) != '\0')) {
              cVar4 = func_0x(0x1106180);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                puStack_188 = (uint *)0x0;
                (*_DAT_)(1,0x9f5b8c,0xb15c78,0x80f);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),3);
            uVar13 = (ulonglong)*(uint *)(param_1 + 10);
            uVar5 = param_1[0xe];
          }
          uVar15 = (int)uVar13 + (uVar5 + 1) * 2;
          *(uint *)(param_1 + 0xc) = uVar15;
          if (0x1f9e < uVar15) {
            cVar4 = func_0x(0x1106180);
            if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
               (*(char *)(lVar10 + 0x499) != '\0')) {
              cVar4 = func_0x(0x1106180);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                puStack_188 = (uint *)0x0;
                (*_DAT_)(1,0x9f5b8c,0xb15c78,0x816);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),4);
            uVar5 = param_1[0xe];
            uVar15 = *(uint *)(param_1 + 0xc);
          }
          uVar13 = (ulonglong)uVar5;
          uVar5 = puVar19[uVar13];
          *(uint *)(param_1 + 2) = uVar5 & 0x7fff;
          if ((uVar5 & 0x7fff) < uVar15) {
            cVar4 = func_0x(0x1106180);
            if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
               (*(char *)(lVar10 + 0x499) != '\0')) {
              cVar4 = func_0x(0x1106180);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                puStack_188 = (uint *)0x0;
                (*_DAT_)(1,0x9f5b8c,0xb15c78,0x81d);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),4);
            uVar15 = *(uint *)(param_1 + 0xc);
            uVar13 = (ulonglong)(ushort)param_1[0xe];
          }
          puVar20 = puVar19;
          iVar22 = iVar8;
          if ((short)uVar13 != 0) {
            do {
              puVar19 = puVar19 + 1;
              uVar18 = *puVar19 & 0x7fff;
              if ((uVar18 < uVar15) || (*(uint *)(param_1 + 2) < uVar18)) {
                cVar4 = func_0x(0x1106180);
                if ((cVar4 != '\0') &&
                   ((lVar10 = func_0x(), lVar10 != 0 &&
                    (*(char *)(lVar10 + 0x499) != '\0')))) {
                  cVar4 = func_0x(0x1106180);
                  if (cVar4 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    puStack_188 = (uint *)0x0;
                    (*_DAT_)(1,0x9f5b8c,0xb15c78,0x82a);
                  }
                }
                func_0x(*(undefined8 *)(param_1 + 4),4);
              }
              uVar13 = (ulonglong)(ushort)param_1[0xe];
              iVar22 = iVar22 + 1;
              puVar20 = puStack_170;
              uVar15 = uVar18;
            } while (iVar22 < (int)(uint)(ushort)param_1[0xe]);
          }
          puVar19 = puStack_170;
          if ((short)puVar20[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
            pbVar14 = *(byte **)(param_1 + 4);
            do {
              uVar15 = *(ushort *)(pbVar14 + uVar13 * 2 + (ulonglong)*(uint *)(param_1 + 10)) &
                       0x7fff;
              if ((int)uVar13 == 1) {
                uVar18 = *(uint *)(param_1 + 0xc);
                uVar17 = uVar18;
LAB_:
                if ((uVar15 < uVar18) || (*(uint *)(param_1 + 2) < uVar15)) goto LAB_;
              }
              else {
                uVar17 = *(uint *)(param_1 + 0xc);
                uVar18 = *(ushort *)
                          (pbVar14 + uVar13 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2)) & 0x7fff
                ;
                if (uVar17 <= uVar18) goto LAB_;
LAB_:
                func_0x(pbVar14,7);
                uVar17 = *(uint *)(param_1 + 0xc);
              }
              if ((uVar18 < uVar17) || (*(uint *)(param_1 + 2) < uVar18)) goto LAB_;
              pbVar14 = *(byte **)(param_1 + 4);
              if (*(ushort *)(pbVar14 + uVar18) == 5) {
                *puVar1 = *puVar1 | 2;
                param_1[0xe] = param_1[0xe] + -1;
                uVar16 = (ulonglong)(uVar18 & 0xffff);
                param_1[0x15] = (short)uVar18;
                uVar13 = *(ulonglong *)(param_1 + 4);
                uVar5 = param_1[0x16] & 0xc7ffU;
                if ((*(ushort *)(uVar16 + 2 + uVar13) >> 0xe & 1) != 0) {
                  uVar5 = *(ushort *)(uVar16 + 2 + uVar13) & 0x3800 | param_1[0x16] & 0xc7ffU;
                }
                param_1[0x16] = uVar5;
                uVar6 = (uVar5 ^ *(ushort *)(uVar16 + 2 + uVar13)) & 0x7ff ^ uVar5;
                param_1[0x16] = uVar6;
                uVar23 = uVar13 + 4 +
                         (ulonglong)((uVar6 & 0x7ff) * 2) + uVar16 + (uVar5 >> 0xb & 7) * 2;
                if (uVar23 < uVar16 + uVar13) {
                  func_0x(uVar16 + uVar13,0x19);
                  uVar6 = param_1[0x16];
                  uVar16 = (ulonglong)(ushort)param_1[0x15];
                  uVar13 = (ulonglong)*(uint *)(param_1 + 4);
                }
                if (uVar15 - uVar18 <
                    (((uVar6 & 0x7ff) * 2 - (int)uVar16) - (int)uVar13) + (int)uVar23) {
                  func_0x(uVar16 + *(longlong *)(param_1 + 4),0x19);
                  uVar6 = param_1[0x16];
                }
                if (((uVar6 & 0x3800) != 0) &&
                   (puVar19 = (ushort *)
                              (*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]),
                   (uVar6 & 0x3800) != 0)) {
                  do {
                    if ((uVar6 & 0x7ff) < (*puVar19 & 0x7ff)) {
                      func_0x((ulonglong)(ushort)param_1[0x15] + *(longlong *)(param_1 + 4),
                                      0x1a);
                      uVar6 = param_1[0x16];
                    }
                    iVar8 = iVar8 + 1;
                    puVar19 = puVar19 + 1;
                  } while (iVar8 < (int)(uVar6 >> 0xb & 7));
                }
                goto LAB_;
              }
              if (*(ushort *)(pbVar14 + uVar18) < 0x400) goto LAB_;
              *puVar1 = *puVar1 | 1;
              uVar5 = param_1[0xe] - 1;
              param_1[0xe] = uVar5;
              if (uVar5 == 0) goto LAB_;
              uVar13 = (ulonglong)uVar5;
            } while ((short)puVar19[(ulonglong)(uVar5 - 1) + 1] < 0);
            uVar13 = (ulonglong)*(uint *)(param_1 + 2);
          }
          else {
LAB_:
            pbVar14 = *(byte **)(param_1 + 4);
            uVar13 = (ulonglong)*(uint *)(param_1 + 2);
          }
        }
        if ((*pbVar14 & 0x40) == 0) {
          *(undefined4 *)(param_1 + 0x13) = 0;
        }
        else {
          *(int *)(param_1 + 0x13) = (int)uVar13;
          *(int *)(param_1 + 2) = (int)uVar13 + 0xe;
          uVar11 = func_0x(puVar1);
          func_0x(uVar11,&puStack_170);
          iVar8 = func_0x(&puStack_170);
          *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar8;
          uVar13 = (ulonglong)*(uint *)(param_1 + 2);
        }
        iVar8 = (int)uVar13;
        if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
           (*(ulonglong *)(param_1 + 0xf) < uVar13 + *(longlong *)(param_1 + 4))) {
          cVar4 = func_0x(0x1106180);
          if ((cVar4 != '\0') &&
             ((lVar10 = func_0x(), lVar10 != 0 &&
              (*(char *)(lVar10 + 0x499) != '\0')))) {
            cVar4 = func_0x(0x1106180);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              puStack_188 = (uint *)0x0;
              (*_DAT_)(1,0x9f5b8c,0xb15c78,0x886);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),0x12);
          iVar8 = *(int *)(param_1 + 2);
        }
        if (0x3f3b < iVar8 - 1U) {
          cVar4 = func_0x(0x1106180);
          if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
             (*(char *)(lVar10 + 0x499) != '\0')) {
            cVar4 = func_0x(0x1106180);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              puStack_188 = (uint *)0x0;
              (*_DAT_)(1,0x9f5b8c,0xb15c78,0x88b);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),5);
        }
      }
LAB_:
      uVar15 = *puStack_158;
      if (*(uint *)(param_1 + 8) < uVar15) {
        func_0x(puVar1,0,uVar15 - *(uint *)(param_1 + 8),0);
        if ((1 << (**(byte **)(param_1 + 4) & 0xe) & 0x1105U) != 0) {
          *(short *)(*(byte **)(param_1 + 4) + 2) = (short)uVar15;
        }
        *(uint *)(param_1 + 8) = uVar15;
      }
    }
    else {
      uVar17 = uVar15 + 1;
      if (*(uint *)(param_1 + 8) < uVar17) {
        func_0x(puVar1,0,uVar17 - *(uint *)(param_1 + 8),0);
        if ((1 << (**(byte **)(param_1 + 4) & 0xe) & 0x1105U) != 0) {
          *(short *)(*(byte **)(param_1 + 4) + 2) = (short)uVar17;
        }
        *(uint *)(param_1 + 8) = uVar17;
        uVar18 = (uint)*(byte *)((longlong)param_2 + 6);
      }
      bVar3 = *(byte *)(*(longlong *)(param_1 + 4) + (longlong)(int)uVar15);
      if (cVar4 == '\0') {
        bVar3 = bVar3 & ~(byte)(1 << (uVar18 & 7));
      }
      else {
        bVar3 = bVar3 | (byte)(1 << (uVar18 & 7));
      }
      *(byte *)(*(longlong *)(param_1 + 4) + (longlong)(int)uVar15) = bVar3;
    }
    goto LAB_;
  }
  if ((uVar15 & 0xc0000000) == 0x80000000) {
    func_0x(auStack_128);
    uVar13 = 0;
    iVar8 = 0;
    auStack_178[0] = 0;
    if (*(int *)(param_1 + 2) == 0) {
      pbVar14 = *(byte **)(param_1 + 4);
      uVar15 = *(uint *)(param_1 + 8);
      uVar16 = (ulonglong)uVar15;
      *puVar1 = 0;
      *(uint *)(param_1 + 10) = uVar15;
      bVar3 = *pbVar14;
      if ((bVar3 & 0x10) != 0) {
        uVar15 = uVar15 + 2 + (*(ushort *)(pbVar14 + uVar16) + 7 >> 3);
        uVar16 = (ulonglong)uVar15;
        *(uint *)(param_1 + 10) = uVar15;
        bVar3 = *pbVar14;
      }
      if ((bVar3 & 0x20) == 0) {
        *(int *)(param_1 + 2) = (int)uVar16;
        param_1[0xe] = 0;
        *(int *)(param_1 + 0xc) = (int)uVar16;
      }
      else {
        puVar19 = (ushort *)(pbVar14 + uVar16);
        uVar5 = *puVar19;
        param_1[0xe] = uVar5;
        puStack_160 = puVar19;
        if (uVar5 == 0) {
          cVar4 = func_0x(0x1106180);
          if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
             (*(char *)(lVar10 + 0x499) != '\0')) {
            cVar4 = func_0x(0x1106180);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              puStack_188 = (uint *)0x0;
              (*_DAT_)(1,0x9f5b8c,0xb15c78,0x80f);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),3);
          uVar16 = (ulonglong)*(uint *)(param_1 + 10);
          uVar5 = param_1[0xe];
        }
        uVar15 = (int)uVar16 + (uVar5 + 1) * 2;
        *(uint *)(param_1 + 0xc) = uVar15;
        if (0x1f9e < uVar15) {
          cVar4 = func_0x(0x1106180);
          if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
             (*(char *)(lVar10 + 0x499) != '\0')) {
            cVar4 = func_0x(0x1106180);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_188 = (uint *)0x0;
              (*_DAT_)(1,0x9f5b8c,0xb15c78,0x816);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar5 = param_1[0xe];
          uVar15 = *(uint *)(param_1 + 0xc);
        }
        uVar16 = (ulonglong)uVar5;
        uVar5 = puVar19[uVar16];
        *(uint *)(param_1 + 2) = uVar5 & 0x7fff;
        if ((uVar5 & 0x7fff) < uVar15) {
          cVar4 = func_0x(0x1106180);
          if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
             (*(char *)(lVar10 + 0x499) != '\0')) {
            cVar4 = func_0x(0x1106180);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_188 = (uint *)0x0;
              (*_DAT_)(1,0x9f5b8c,0xb15c78,0x81d);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar15 = *(uint *)(param_1 + 0xc);
          uVar16 = (ulonglong)(ushort)param_1[0xe];
        }
        puVar20 = puVar19;
        uVar23 = uVar13;
        if ((short)uVar16 != 0) {
          do {
            puVar19 = puVar19 + 1;
            uVar18 = *puVar19 & 0x7fff;
            if ((uVar18 < uVar15) || (*(uint *)(param_1 + 2) < uVar18)) {
              cVar4 = func_0x(0x1106180);
              if ((cVar4 != '\0') &&
                 ((lVar10 = func_0x(), lVar10 != 0 &&
                  (*(char *)(lVar10 + 0x499) != '\0')))) {
                cVar4 = func_0x(0x1106180);
                if (cVar4 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_188 = (uint *)0x0;
                  (*_DAT_)(1,0x9f5b8c,0xb15c78,0x82a);
                }
              }
              func_0x(*(undefined8 *)(param_1 + 4),4);
            }
            uVar16 = (ulonglong)(ushort)param_1[0xe];
            uVar17 = (int)uVar23 + 1;
            puVar20 = puStack_160;
            uVar23 = (ulonglong)uVar17;
            uVar15 = uVar18;
          } while ((int)uVar17 < (int)(uint)(ushort)param_1[0xe]);
        }
        puVar19 = puStack_160;
        if ((short)puVar20[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
          pbVar14 = *(byte **)(param_1 + 4);
          do {
            uVar15 = *(ushort *)(pbVar14 + uVar16 * 2 + (ulonglong)*(uint *)(param_1 + 10)) & 0x7fff
            ;
            if ((int)uVar16 == 1) {
              uVar18 = *(uint *)(param_1 + 0xc);
              uVar17 = uVar18;
LAB_:
              if ((uVar15 < uVar18) || (*(uint *)(param_1 + 2) < uVar15)) goto LAB_;
            }
            else {
              uVar17 = *(uint *)(param_1 + 0xc);
              uVar18 = *(ushort *)(pbVar14 + uVar16 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2))
                       & 0x7fff;
              if (uVar17 <= uVar18) goto LAB_;
LAB_:
              func_0x(pbVar14,7);
              uVar17 = *(uint *)(param_1 + 0xc);
            }
            if ((uVar18 < uVar17) || (*(uint *)(param_1 + 2) < uVar18)) goto LAB_;
            pbVar14 = *(byte **)(param_1 + 4);
            if (*(ushort *)(pbVar14 + uVar18) == 5) {
              *puVar1 = *puVar1 | 2;
              param_1[0xe] = param_1[0xe] + -1;
              uVar23 = (ulonglong)(uVar18 & 0xffff);
              param_1[0x15] = (short)uVar18;
              uVar16 = *(ulonglong *)(param_1 + 4);
              uVar5 = param_1[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar23 + 2 + uVar16) >> 0xe & 1) != 0) {
                uVar5 = *(ushort *)(uVar23 + 2 + uVar16) & 0x3800 | param_1[0x16] & 0xc7ffU;
              }
              param_1[0x16] = uVar5;
              uVar6 = (uVar5 ^ *(ushort *)(uVar23 + 2 + uVar16)) & 0x7ff ^ uVar5;
              param_1[0x16] = uVar6;
              puStack_160 = (ushort *)
                            (uVar16 + 4 +
                            (ulonglong)((uVar6 & 0x7ff) * 2) + uVar23 + (uVar5 >> 0xb & 7) * 2);
              if (puStack_160 < (ushort *)(uVar23 + uVar16)) {
                func_0x((ushort *)(uVar23 + uVar16),0x19);
                uVar6 = param_1[0x16];
                uVar23 = (ulonglong)(ushort)param_1[0x15];
                uVar16 = (ulonglong)*(uint *)(param_1 + 4);
              }
              if (uVar15 - uVar18 <
                  (((uVar6 & 0x7ff) * 2 - (int)uVar23) - (int)uVar16) + (int)puStack_160) {
                func_0x(uVar23 + *(longlong *)(param_1 + 4),0x19);
                uVar6 = param_1[0x16];
              }
              if (((uVar6 & 0x3800) != 0) &&
                 (puVar19 = (ushort *)
                            (*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]),
                 uVar16 = uVar13, (uVar6 & 0x3800) != 0)) {
                do {
                  if ((uVar6 & 0x7ff) < (*puVar19 & 0x7ff)) {
                    func_0x((ulonglong)(ushort)param_1[0x15] + *(longlong *)(param_1 + 4),
                                    0x1a);
                    uVar6 = param_1[0x16];
                  }
                  uVar15 = (int)uVar16 + 1;
                  puVar19 = puVar19 + 1;
                  uVar16 = (ulonglong)uVar15;
                } while ((int)uVar15 < (int)(uVar6 >> 0xb & 7));
              }
              goto LAB_;
            }
            if (*(ushort *)(pbVar14 + uVar18) < 0x400) goto LAB_;
            *puVar1 = *puVar1 | 1;
            uVar5 = param_1[0xe] - 1;
            param_1[0xe] = uVar5;
            if (uVar5 == 0) goto LAB_;
            uVar16 = (ulonglong)uVar5;
          } while ((short)puVar19[(ulonglong)(uVar5 - 1) + 1] < 0);
          uVar16 = (ulonglong)*(uint *)(param_1 + 2);
        }
        else {
LAB_:
          pbVar14 = *(byte **)(param_1 + 4);
          uVar16 = (ulonglong)*(uint *)(param_1 + 2);
        }
      }
      if ((*pbVar14 & 0x40) == 0) {
        *(undefined4 *)(param_1 + 0x13) = 0;
      }
      else {
        *(int *)(param_1 + 0x13) = (int)uVar16;
        *(int *)(param_1 + 2) = (int)uVar16 + 0xe;
        uVar11 = func_0x(puVar1);
        func_0x(uVar11,&puStack_160);
        iVar22 = func_0x(&puStack_160);
        *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar22;
        uVar16 = (ulonglong)*(uint *)(param_1 + 2);
      }
      iVar22 = (int)uVar16;
      if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
         (*(ulonglong *)(param_1 + 0xf) < uVar16 + *(longlong *)(param_1 + 4))) {
        cVar4 = func_0x(0x1106180);
        if ((cVar4 != '\0') &&
           ((lVar10 = func_0x(), lVar10 != 0 && (*(char *)(lVar10 + 0x499) != '\0'))
           )) {
          cVar4 = func_0x(0x1106180);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            puStack_188 = (uint *)0x0;
            (*_DAT_)(1,0x9f5b8c,0xb15c78,0x886);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),0x12);
        iVar22 = *(int *)(param_1 + 2);
      }
      if (0x3f3b < iVar22 - 1U) {
        cVar4 = func_0x(0x1106180);
        if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
           (*(char *)(lVar10 + 0x499) != '\0')) {
          cVar4 = func_0x(0x1106180);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            puStack_188 = (uint *)0x0;
            (*_DAT_)(1,0x9f5b8c,0xb15c78,0x88b);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),5);
      }
    }
LAB_:
    iVar22 = func_0x(puVar1);
    if (iVar22 == 0) goto LAB_;
    uVar15 = **(byte **)(param_1 + 4) >> 6 & 1;
    if ((**(byte **)(param_1 + 4) >> 6 & 1) != 0) {
      func_0x(puVar1,auStack_128);
    }
    if ((*(byte *)puVar1 & 1) != 0) {
      ppuVar12 = (ushort **)func_0x(puVar1,0x400,auStack_178);
      puStack_170 = *ppuVar12;
    }
    pbVar14 = *(byte **)(param_1 + 4);
    if ((*pbVar14 & 0x20) == 0) {
      func_0x(puVar1);
      pbVar14 = *(byte **)(param_1 + 4);
    }
    puStack_160 = (ushort *)(pbVar14 + *(uint *)(param_1 + 10));
    iVar22 = func_0x(puVar1);
    lVar10 = *(longlong *)(param_1 + 4);
    uVar5 = param_1[0xe];
    uVar16 = (ulonglong)uVar5;
    puVar19 = (ushort *)(lVar10 + (ulonglong)*(uint *)(param_1 + 10));
    uVar18 = (uint)uVar5;
    if (iVar22 == 0) {
      uVar17 = *(uint *)(param_1 + 10) + (uVar5 + 1) * 2;
      if (*puVar19 != 0) {
        do {
          uVar21 = (int)uVar13 + 1;
          puVar19[(uVar13 & 0xffff) + 1] =
               puVar19[(uVar13 & 0xffff) + 1] ^
               (puVar19[uVar13 + 1] + 2 ^ puVar19[(uVar13 & 0xffff) + 1]) & 0x7fff;
          uVar13 = (ulonglong)uVar21;
        } while (uVar21 < *puVar19);
        lVar10 = *(longlong *)(param_1 + 4);
      }
      lVar10 = (ulonglong)uVar17 + lVar10;
      func_0x(lVar10 + 2,lVar10,*(int *)(param_1 + 2) - uVar17);
      *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 2;
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + 2;
      uVar6 = (ushort)*(undefined4 *)(param_1 + 0xc);
      if (uVar18 != 0) {
        uVar6 = puVar19[(ulonglong)(uVar5 - 1) + 1] & 0x7fff;
      }
      if (uVar18 < uVar5 + 1) {
        do {
          uVar13 = uVar16 & 0xffff;
          uVar18 = (int)uVar16 + 1;
          uVar16 = (ulonglong)uVar18;
          puVar19[uVar13 + 1] = uVar6 & 0x7fff;
        } while (uVar18 < uVar5 + 1);
      }
      *puVar19 = *puVar19 + 1;
      func_0x(puVar1);
      uVar5 = puStack_160[(ulonglong)(ushort)param_1[0xe] + 1];
      func_0x(auStack_140);
      uStack_180 = (undefined8 *)((ulonglong)uStack_180._4_4_ << 0x20);
      puStack_188 = puStack_158;
      func_0x(auStack_150,0,0,0);
      uStack_180 = &uStack_168;
      puStack_188 = (uint *)auStack_150;
      func_0x(param_1 + 0x15,uVar5 & 0x7fff,0x1f9e,1);
      iVar22 = (int)uStack_168;
    }
    else {
      uVar17 = puVar19[uVar16 + 1] & 0x7fff;
      if (uVar18 == 0) {
        uVar18 = *(uint *)(uStack_168 + 0xc);
LAB_:
        if ((uVar17 < uVar18) || (*(uint *)(param_1 + 2) < uVar17)) goto LAB_;
      }
      else {
        uVar18 = puVar19[uVar16] & 0x7fff;
        if (*(uint *)(uStack_168 + 0xc) <= uVar18) goto LAB_;
LAB_:
        func_0x(lVar10,7);
      }
      iVar8 = uVar17 - uVar18;
      iVar22 = func_0x(param_1 + 0x15,puStack_158,0,0);
    }
    iVar8 = (iVar22 - iVar8) + *(int *)(param_1 + 2);
    *(int *)(param_1 + 2) = iVar8;
    if ((*(byte *)puVar1 & 1) != 0) {
      puStack_160[(ulonglong)(ushort)param_1[0xe] + 2] = (ushort)iVar8 | 0x8000;
      iVar8 = (*(int *)(param_1 + 2) - auStack_178[0]) + -2;
    }
    puStack_160[(ulonglong)(ushort)param_1[0xe] + 1] = (ushort)iVar8 | 0x8000;
    if (iVar22 == 0) {
      func_0x(puVar1,(ushort)param_1[0xe] + 1);
      if ((**(byte **)(param_1 + 4) & 0x20) != 0) {
        param_1[0xe] = param_1[0xe] + 1;
        *puVar1 = *puVar1 & 0xfffd;
        func_0x(param_1 + 0x15);
      }
    }
    else {
      *puVar1 = *puVar1 | 2;
      sVar7 = func_0x(puVar1,&uStack_168);
      param_1[0x15] = sVar7;
    }
    if ((*(byte *)puVar1 & 1) != 0) {
      func_0x(puVar1,0x400,auStack_178[0],&puStack_170);
    }
  }
  else {
    if (*(int *)(param_1 + 2) == 0) {
      pbVar14 = *(byte **)(param_1 + 4);
      iVar8 = 0;
      uVar15 = *(uint *)(param_1 + 8);
      uVar13 = (ulonglong)uVar15;
      *puVar1 = 0;
      *(uint *)(param_1 + 10) = uVar15;
      bVar3 = *pbVar14;
      if ((bVar3 & 0x10) != 0) {
        uVar15 = uVar15 + 2 + (*(ushort *)(pbVar14 + uVar13) + 7 >> 3);
        uVar13 = (ulonglong)uVar15;
        *(uint *)(param_1 + 10) = uVar15;
        bVar3 = *pbVar14;
      }
      if ((bVar3 & 0x20) == 0) {
        *(int *)(param_1 + 2) = (int)uVar13;
        param_1[0xe] = 0;
        *(int *)(param_1 + 0xc) = (int)uVar13;
      }
      else {
        puVar19 = (ushort *)(pbVar14 + uVar13);
        uVar5 = *puVar19;
        param_1[0xe] = uVar5;
        puStack_170 = puVar19;
        if (uVar5 == 0) {
          cVar4 = func_0x(0x1106180);
          if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
             (*(char *)(lVar10 + 0x499) != '\0')) {
            cVar4 = func_0x(0x1106180);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              puStack_188 = (uint *)0x0;
              (*_DAT_)(1,0x9f5b8c,0xb15c78,0x80f);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),3);
          uVar13 = (ulonglong)*(uint *)(param_1 + 10);
          uVar5 = param_1[0xe];
        }
        uVar15 = (int)uVar13 + (uVar5 + 1) * 2;
        *(uint *)(param_1 + 0xc) = uVar15;
        if (0x1f9e < uVar15) {
          cVar4 = func_0x(0x1106180);
          if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
             (*(char *)(lVar10 + 0x499) != '\0')) {
            cVar4 = func_0x(0x1106180);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_188 = (uint *)0x0;
              (*_DAT_)(1,0x9f5b8c,0xb15c78,0x816);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar5 = param_1[0xe];
          uVar15 = *(uint *)(param_1 + 0xc);
        }
        uVar13 = (ulonglong)uVar5;
        uVar5 = puVar19[uVar13];
        *(uint *)(param_1 + 2) = uVar5 & 0x7fff;
        if ((uVar5 & 0x7fff) < uVar15) {
          cVar4 = func_0x(0x1106180);
          if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
             (*(char *)(lVar10 + 0x499) != '\0')) {
            cVar4 = func_0x(0x1106180);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_188 = (uint *)0x0;
              (*_DAT_)(1,0x9f5b8c,0xb15c78,0x81d);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar15 = *(uint *)(param_1 + 0xc);
          uVar13 = (ulonglong)(ushort)param_1[0xe];
        }
        puVar20 = puVar19;
        iVar22 = iVar8;
        if ((short)uVar13 != 0) {
          do {
            puVar19 = puVar19 + 1;
            uVar18 = *puVar19 & 0x7fff;
            if ((uVar18 < uVar15) || (*(uint *)(param_1 + 2) < uVar18)) {
              cVar4 = func_0x(0x1106180);
              if ((cVar4 != '\0') &&
                 ((lVar10 = func_0x(), lVar10 != 0 &&
                  (*(char *)(lVar10 + 0x499) != '\0')))) {
                cVar4 = func_0x(0x1106180);
                if (cVar4 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_188 = (uint *)0x0;
                  (*_DAT_)(1,0x9f5b8c,0xb15c78,0x82a);
                }
              }
              func_0x(*(undefined8 *)(param_1 + 4),4);
            }
            uVar13 = (ulonglong)(ushort)param_1[0xe];
            iVar22 = iVar22 + 1;
            puVar20 = puStack_170;
            uVar15 = uVar18;
          } while (iVar22 < (int)(uint)(ushort)param_1[0xe]);
        }
        puVar19 = puStack_170;
        if ((short)puVar20[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
          pbVar14 = *(byte **)(param_1 + 4);
          do {
            uVar15 = *(ushort *)(pbVar14 + uVar13 * 2 + (ulonglong)*(uint *)(param_1 + 10)) & 0x7fff
            ;
            if ((int)uVar13 == 1) {
              uVar18 = *(uint *)(param_1 + 0xc);
              uVar17 = uVar18;
LAB_:
              if ((uVar15 < uVar18) || (*(uint *)(param_1 + 2) < uVar15)) goto LAB_;
            }
            else {
              uVar17 = *(uint *)(param_1 + 0xc);
              uVar18 = *(ushort *)(pbVar14 + uVar13 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2))
                       & 0x7fff;
              if (uVar17 <= uVar18) goto LAB_;
LAB_:
              func_0x(pbVar14,7);
              uVar17 = *(uint *)(param_1 + 0xc);
            }
            if ((uVar18 < uVar17) || (*(uint *)(param_1 + 2) < uVar18)) goto LAB_;
            pbVar14 = *(byte **)(param_1 + 4);
            if (*(ushort *)(pbVar14 + uVar18) == 5) {
              *puVar1 = *puVar1 | 2;
              param_1[0xe] = param_1[0xe] + -1;
              uVar16 = (ulonglong)(uVar18 & 0xffff);
              param_1[0x15] = (short)uVar18;
              uVar13 = *(ulonglong *)(param_1 + 4);
              uVar5 = param_1[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar16 + 2 + uVar13) >> 0xe & 1) != 0) {
                uVar5 = *(ushort *)(uVar16 + 2 + uVar13) & 0x3800 | param_1[0x16] & 0xc7ffU;
              }
              param_1[0x16] = uVar5;
              uVar6 = (uVar5 ^ *(ushort *)(uVar16 + 2 + uVar13)) & 0x7ff ^ uVar5;
              param_1[0x16] = uVar6;
              puStack_170 = (ushort *)
                            (uVar13 + 4 +
                            (ulonglong)((uVar6 & 0x7ff) * 2) + uVar16 + (uVar5 >> 0xb & 7) * 2);
              if (puStack_170 < (ushort *)(uVar16 + uVar13)) {
                func_0x((ushort *)(uVar16 + uVar13),0x19);
                uVar6 = param_1[0x16];
                uVar16 = (ulonglong)(ushort)param_1[0x15];
                uVar13 = (ulonglong)*(uint *)(param_1 + 4);
              }
              if (uVar15 - uVar18 <
                  (((uVar6 & 0x7ff) * 2 - (int)uVar16) - (int)uVar13) + (int)puStack_170) {
                func_0x(uVar16 + *(longlong *)(param_1 + 4),0x19);
                uVar6 = param_1[0x16];
              }
              if (((uVar6 & 0x3800) != 0) &&
                 (puVar19 = (ushort *)
                            (*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]),
                 (uVar6 & 0x3800) != 0)) {
                do {
                  if ((uVar6 & 0x7ff) < (*puVar19 & 0x7ff)) {
                    func_0x((ulonglong)(ushort)param_1[0x15] + *(longlong *)(param_1 + 4),
                                    0x1a);
                    uVar6 = param_1[0x16];
                  }
                  iVar8 = iVar8 + 1;
                  puVar19 = puVar19 + 1;
                } while (iVar8 < (int)(uVar6 >> 0xb & 7));
              }
              goto LAB_;
            }
            if (*(ushort *)(pbVar14 + uVar18) < 0x400) goto LAB_;
            *puVar1 = *puVar1 | 1;
            uVar5 = param_1[0xe] - 1;
            param_1[0xe] = uVar5;
            if (uVar5 == 0) goto LAB_;
            uVar13 = (ulonglong)uVar5;
          } while ((short)puVar19[(ulonglong)(uVar5 - 1) + 1] < 0);
          uVar13 = (ulonglong)*(uint *)(param_1 + 2);
        }
        else {
LAB_:
          pbVar14 = *(byte **)(param_1 + 4);
          uVar13 = (ulonglong)*(uint *)(param_1 + 2);
        }
      }
      if ((*pbVar14 & 0x40) == 0) {
        *(undefined4 *)(param_1 + 0x13) = 0;
      }
      else {
        *(int *)(param_1 + 0x13) = (int)uVar13;
        *(int *)(param_1 + 2) = (int)uVar13 + 0xe;
        uVar11 = func_0x(puVar1);
        func_0x(uVar11,&puStack_170);
        iVar8 = func_0x(&puStack_170);
        *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar8;
        uVar13 = (ulonglong)*(uint *)(param_1 + 2);
      }
      iVar8 = (int)uVar13;
      if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
         (*(ulonglong *)(param_1 + 0xf) < uVar13 + *(longlong *)(param_1 + 4))) {
        cVar4 = func_0x(0x1106180);
        if ((cVar4 != '\0') &&
           ((lVar10 = func_0x(), lVar10 != 0 && (*(char *)(lVar10 + 0x499) != '\0'))
           )) {
          cVar4 = func_0x(0x1106180);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            puStack_188 = (uint *)0x0;
            (*_DAT_)(1,0x9f5b8c,0xb15c78,0x886);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),0x12);
        iVar8 = *(int *)(param_1 + 2);
      }
      if (0x3f3b < iVar8 - 1U) {
        cVar4 = func_0x(0x1106180);
        if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
           (*(char *)(lVar10 + 0x499) != '\0')) {
          cVar4 = func_0x(0x1106180);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            puStack_188 = (uint *)0x0;
            (*_DAT_)(1,0x9f5b8c,0xb15c78,0x88b);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),5);
      }
    }
LAB_:
    psVar2 = uStack_168;
    uVar18 = -*puStack_158;
    if ((ushort)param_1[0xe] < uVar18) goto LAB_;
    func_0x(auStack_128);
    pbVar14 = *(byte **)(param_1 + 4);
    uVar15 = *pbVar14 >> 6 & 1;
    auStack_178[0] = uVar15;
    if ((*pbVar14 >> 6 & 1) != 0) {
      func_0x(puVar1,auStack_128);
      pbVar14 = *(byte **)(param_1 + 4);
    }
    if (uVar18 <= (ushort)param_1[0xe]) {
      uVar15 = *(ushort *)(pbVar14 + (longlong)(int)uVar18 * 2 + (ulonglong)*(uint *)(param_1 + 10))
               & 0x7fff;
      uStack_168 = (short *)(CONCAT44(uStack_168._4_4_,
                                      (uint)*(ushort *)
                                             (pbVar14 +
                                             (longlong)(int)uVar18 * 2 +
                                             (ulonglong)*(uint *)(param_1 + 10))) &
                            0xffffffff00007fff);
      if (uVar18 == 1) {
        uVar13 = (ulonglong)*(uint *)(psVar2 + 0xc);
LAB_:
        if ((uVar15 < (uint)uVar13) || (*(uint *)(param_1 + 2) < uVar15)) goto LAB_;
      }
      else {
        uVar13 = (ulonglong)
                 (*(ushort *)
                   (pbVar14 + (longlong)(int)uVar18 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2))
                 & 0x7fff);
        if (*(uint *)(psVar2 + 0xc) <=
            (*(ushort *)
              (pbVar14 + (longlong)(int)uVar18 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2)) &
            0x7fff)) goto LAB_;
LAB_:
        func_0x(pbVar14,7);
      }
      iVar8 = uVar15 - (int)uVar13;
      uVar15 = auStack_178[0];
      if (iVar8 != 0) {
        puVar19 = (ushort *)((ulonglong)*(uint *)(param_1 + 10) + *(longlong *)(param_1 + 4));
        lVar10 = *(longlong *)(param_1 + 4);
        uVar9 = func_0x
                          (*(undefined4 *)(param_1 + 2),(ulonglong)uStack_168 & 0xffffffff);
        func_0x(lVar10 + uVar13,iVar8 + lVar10 + uVar13,uVar9);
        uVar15 = uVar18 - 1;
        if ((int)uVar15 < (int)(uint)*puVar19) {
          do {
            uVar13 = (ulonglong)uVar15;
            lVar10 = (longlong)(int)uVar15;
            uVar15 = uVar15 + 1;
            puVar19[(uVar13 & 0xffff) + 1] =
                 puVar19[(uVar13 & 0xffff) + 1] ^
                 (puVar19[lVar10 + 1] - (short)iVar8 ^ puVar19[(uVar13 & 0xffff) + 1]) & 0x7fff;
          } while ((int)uVar15 < (int)(uint)*puVar19);
        }
        *(int *)(param_1 + 2) = *(int *)(param_1 + 2) - iVar8;
        iVar8 = func_0x(puVar1);
        uVar15 = auStack_178[0];
        if (iVar8 != 0) {
          sVar7 = func_0x(puVar1,&uStack_168);
          param_1[0x15] = sVar7;
          uVar15 = auStack_178[0];
        }
      }
    }
    if (uVar18 == (ushort)param_1[0xe]) {
      func_0x(puVar1,uVar18,1);
    }
  }
  if (uVar15 != 0) {
    func_0x(puVar1,auStack_128);
  }
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_1a8);
  return;
}

