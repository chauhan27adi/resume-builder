
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2,undefined8 param_3,longlong **param_4,
                 longlong *param_5)

{
  ushort *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  longlong *plVar4;
  char cVar5;
  byte bVar6;
  ushort uVar7;
  ushort uVar8;
  int iVar9;
  longlong lVar10;
  undefined4 *puVar11;
  longlong *plVar12;
  short *psVar13;
  undefined8 uVar14;
  longlong lVar15;
  longlong lVar16;
  undefined4 uVar17;
  byte *pbVar18;
  code *UNRECOVERED_JUMPTABLE;
  ulonglong uVar19;
  uint uVar20;
  uint uVar21;
  undefined *puVar22;
  longlong *plVar23;
  short sVar24;
  uint uVar25;
  uint *puVar26;
  ulonglong uVar27;
  byte *pbVar28;
  ulonglong uVar29;
  uint uVar30;
  uint *puVar31;
  uint *puVar32;
  ushort *puVar33;
  ushort *puVar34;
  longlong *plVar35;
  bool bVar36;
  undefined8 uStack_3a0;
  undefined auStack_398 [32];
  undefined8 uStack_378;
  undefined4 uStack_370;
  longlong lStack_368;
  longlong lStack_360;
  uint auStack_358 [8];
  undefined4 uStack_338;
  uint uStack_334;
  undefined4 uStack_330;
  undefined8 uStack_328;
  uint auStack_320 [2];
  longlong *plStack_318;
  undefined4 uStack_300;
  longlong lStack_2f8;
  longlong lStack_2f0;
  longlong *plStack_2e8;
  ushort *puStack_2e0;
  longlong *plStack_2d8;
  undefined8 uStack_2c8;
  longlong *plStack_2c0;
  int iStack_2ac;
  int aiStack_2a8 [19];
  int iStack_25c;
  int iStack_258;
  uint uStack_254;
  int iStack_250;
  uint uStack_24c;
  int iStack_248;
  int aiStack_23c [5];
  undefined4 uStack_228;
  undefined2 uStack_224;
  undefined2 uStack_222;
  undefined auStack_1dc [4];
  undefined auStack_1d8 [4];
  undefined auStack_1d4 [4];
  undefined8 uStack_1d0;
  undefined8 uStack_1c8;
  longlong *plStack_1a8;
  undefined8 uStack_1a0;
  undefined auStack_198 [8];
  undefined auStack_190 [328];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_358;
  plStack_318 = param_5;
  uVar14 = *(undefined8 *)param_1[0x5c];
  if (*_DAT_ != '\0') {
    uStack_3a0 = 0x100066;
    lVar10 = func_0x(0x1ed4db0);
    *(longlong *)(lVar10 + 0x48) = *(longlong *)(lVar10 + 0x48) + 1;
  }
  lVar10 = *(longlong *)(param_2 + 8);
  if (((*(uint *)(lVar10 + 0x40) & 0x48000) == 0x48000) && ((*(byte *)(param_2 + 0x14) & 8) != 0)) {
    uStack_2c8 = *(undefined8 **)
                  (*(longlong *)(param_2 + 0x40) + (ulonglong)*(uint *)(lVar10 + 0x38) * 8);
  }
  else {
    if ((*(byte *)(*(longlong *)(lVar10 + 0x48) + 0x2a) & 0x10) == 0) {
      lVar16 = *(longlong *)(param_2 + 0x18);
    }
    else {
      lVar16 = *(longlong *)(param_2 + 0x20);
    }
    uStack_2c8 = (undefined8 *)(*(longlong *)(lVar10 + 0x28) + lVar16);
    if ((*(uint *)(lVar10 + 0x40) >> 0xb & 1) != 0) {
      uStack_2c8 = (undefined8 *)*uStack_2c8;
    }
  }
  if (uStack_2c8 == (undefined8 *)0x0) {
    uStack_3a0 = 0x1000d7;
    puVar11 = (undefined4 *)(*_DAT_)();
    *puVar11 = 0x16;
    uStack_3a0 = 0x1000e3;
    (*_DAT_)();
  }
  else {
    uStack_2c8 = (undefined8 *)*uStack_2c8;
  }
  uStack_378 = (longlong **)0x0;
  if (*(int *)(param_1 + 0x39) == 0) {
    if ((param_1[0x2b] != 0) || (uVar17 = 0, param_1[0x2c] != 0)) {
      uVar17 = 1;
    }
    if ((*(byte *)((longlong)param_5 + 0x14) & 0x10) != 0) {
      uStack_378 = (longlong **)*param_5;
    }
    if (*(int *)(param_1 + 0x37) == 0) {
      if (uStack_378 == (longlong **)0x0) {
        bVar36 = param_1[0x38] == -1;
      }
      else {
        bVar36 = *(longlong *)((longlong)uStack_378 + 0xe0) == param_1[0x38];
      }
      if (bVar36) goto LAB_;
    }
    lStack_360 = param_1[0x2f];
    lStack_368 = param_1[0x2e];
    uStack_3a0 = 0x100185;
    uStack_370 = uVar17;
    func_0x((longlong)param_1 + 0x1d4,uVar14,param_1[0x21]);
    *(undefined4 *)(param_1 + 0x37) = 0;
  }
  else {
    *(undefined4 *)((longlong)param_1 + 0x1d4) = 1;
  }
LAB_:
  uStack_228 = (undefined4)uStack_2c8;
  uStack_224 = uStack_2c8._4_2_;
  uStack_222 = uStack_2c8._6_2_;
  uStack_3a0 = 0x1001d2;
  uStack_378 = param_4;
  func_0x(param_1,&uStack_228,0,*(undefined4 *)((longlong)param_1 + 0x1d4));
  plVar23 = *param_4;
  if (plVar23 == (longlong *)0x0) {
    puVar22 = auStack_398;
    if (*(char *)(param_1[0x21] + 99) == '\x04') {
      uStack_3a0 = 0x1076a4;
      func_0x(0x17ce4b0,uStack_2c8._4_2_,(ulonglong)uStack_2c8 & 0xffffffff,
                      (int)uStack_2c8._6_2_);
      puVar22 = auStack_398;
    }
    goto LAB_;
  }
  if (*(longlong *)(param_1[0x3c] + 0x58) != 0) {
    plVar23 = (longlong *)(*(longlong *)(param_1[0x3c] + 0x58) + 0x58);
    *plVar23 = *plVar23 + 1;
    plVar23 = *param_4;
  }
  uStack_3a0 = 0x100202;
  plStack_2c0 = (longlong *)func_0x(plVar23,1,0);
  plStack_2d8 = (longlong *)param_1[0x2f];
  plVar35 = param_1 + 0x32;
  lVar10 = param_1[0x2b];
  puVar2 = (undefined8 *)param_1[0x2d];
  plVar12 = (longlong *)param_1[0x2c];
  puStack_2e0 = (ushort *)param_1[0x2e];
  if ((lVar10 != 0) || (puVar2 != (undefined8 *)0x0)) {
    param_1[0x36] = (longlong)plStack_2c0;
    param_1[0x35] = (longlong)plVar23;
    plStack_1a8 = plVar35;
    if (lVar10 == 0) {
LAB_:
      if (puVar2 != (undefined8 *)0x0) {
        uStack_3a0 = 0x100297;
        cVar5 = (**(code **)*puVar2)(puVar2,plVar35);
        if (cVar5 == '\0') goto LAB_;
      }
      goto LAB_;
    }
    uStack_3a0 = 0x100271;
    (**(code **)(lVar10 + 8))(&plStack_1a8,lVar10,param_1 + 0x158);
    if ((*(char *)(param_1 + 0x158) != '\x03') && (*(char *)(param_1 + 0x159) != '\0'))
    goto LAB_;
LAB_:
    uStack_3a0 = 0x10030b;
    func_0x(*param_4);
    uStack_3a0 = 0x100317;
    (**(code **)(*param_1 + 0x20))(param_1,*param_4);
    *param_4 = (longlong *)0x0;
    puVar22 = auStack_398;
    goto LAB_;
  }
LAB_:
  plVar4 = plStack_2c0;
  if (plVar12 != (longlong *)0x0) {
    plVar3 = *(longlong **)plVar12[1];
    param_1[0x36] = (longlong)plStack_2c0;
    param_1[0x35] = (longlong)plVar23;
    uStack_3a0 = 0x1002c7;
    (**(code **)(*plVar3 + 0x20))(plVar3,plVar35,&uStack_1a0);
    uStack_3a0 = 0x1002d8;
    iVar9 = (**(code **)(*plVar12 + 8))(plVar12,uStack_1a0);
    if (iVar9 == 0) goto LAB_;
  }
  if (puStack_2e0 != (ushort *)0x0) {
    param_1[0x36] = (longlong)plVar4;
    param_1[0x35] = (longlong)plVar23;
    uStack_3a0 = 0x1002ff;
    iVar9 = func_0x(plVar35,puStack_2e0,plStack_2d8);
    if (iVar9 == 0) goto LAB_;
  }
  plVar35 = plStack_318;
  if ((*(byte *)((longlong)plStack_318 + 0x14) & 0x10) == 0) {
    uStack_3a0 = 0x107673;
    (**(code **)(*plVar23 + 8))(plVar23);
    puVar22 = auStack_398;
    goto LAB_;
  }
  plVar23 = *param_4;
  lVar10 = *plStack_318;
  plVar12 = plVar23;
  if ((*(uint *)(param_1 + 0x5d) & 0x800) == 0) {
    plVar12 = (longlong *)0x0;
  }
  plStack_2c0 = plVar23;
  if ((plVar12 != (longlong *)0x0) && (*(char *)(plVar12 + 199) != '\0')) {
    lVar16 = plVar12[200];
    lVar15 = plStack_318[3];
    uVar14 = *(undefined8 *)(lVar10 + 0x100);
    if (lVar16 == 0) {
      uStack_378 = (longlong **)0x0;
      uStack_3a0 = 0x10039a;
      (*_DAT_)(1,0x19741b0,0x19489f8,0x3b);
    }
    uStack_3a0 = 0x1003a8;
    func_0x(lVar16,uVar14,lVar15);
    puVar22 = auStack_398;
    goto LAB_;
  }
  if ((*(short *)(lVar10 + 0x3a) != 0) || (*(int *)(lVar10 + 0x50) != 0)) {
    uStack_3a0 = 0x107636;
    func_0x(param_1,plVar23,plStack_318,aiStack_23c);
    puVar22 = auStack_398;
    if ((aiStack_23c[0] != 1) && (puVar22 = auStack_398, *(longlong *)(param_1[0x21] + 0x70) != 0))
    {
      uStack_3a0 = 0x107651;
      iVar9 = func_0x();
      puVar22 = auStack_398;
      if (iVar9 != 0) {
        uStack_3a0 = 0x107668;
        func_0x(plVar23,*(undefined8 *)(param_1[0x21] + 0x70));
        puVar22 = auStack_398;
      }
    }
    goto LAB_;
  }
  uStack_3a0 = 0x1003d4;
  psVar13 = (short *)func_0x(plVar23,1,0);
  lVar10 = *plVar35;
  plStack_2e8 = param_1 + 0x22;
  plVar23 = param_1 + 0x14c;
  uStack_328 = psVar13;
  plStack_2d8 = plVar23;
  if ((*(byte *)(lVar10 + 0x30) & 1) == 0) {
LAB_:
    if (plStack_2c0 == (longlong *)0x0) {
      param_1[0x14d] = (longlong)psVar13;
      param_1[0x14e] = 0;
    }
    else {
      param_1[0x14d] = 0;
      param_1[0x14e] = (longlong)plStack_2c0;
      uStack_3a0 = 0x1018af;
      lVar16 = (**(code **)*plStack_2c0)();
      param_1[0x14d] = lVar16;
    }
    uVar19 = 0;
    if (*uStack_328 == 0) {
      *uStack_328 = 0;
      puVar22 = auStack_398;
      if ((*(byte *)((longlong)plVar35 + 0x14) & 0x10) != 0) {
        uVar30 = *(uint *)(plVar35 + 2);
        lVar10 = plVar35[1];
        uStack_334 = 0;
        puVar22 = auStack_398;
        auStack_358[0] = uVar30;
        lStack_2f8 = lVar10;
        if (uVar30 != 0) {
          do {
            lStack_2f8 = lVar10;
            if (*(byte *)(lVar10 + 0x40) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(lVar10 + 0x40) * 4 + 0x1076d0) -
                           0xfdaf60);
                    /* WARNING: Could not emulate address calculation at 0x0010191f */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,0);
              return;
            }
            uVar20 = *(uint *)(lVar10 + 0x40);
            if ((uVar20 >> 10 & 1) != 0) {
              if ((*(byte *)(*(longlong *)(lVar10 + 0x48) + 0x2a) & 0x10) == 0) {
                lVar16 = plStack_318[3];
              }
              else {
                lVar16 = plStack_318[4];
              }
              *(undefined *)(lVar16 + *(longlong *)(lVar10 + 0x30)) = 3;
              uVar20 = *(uint *)(lVar10 + 0x40);
            }
            if ((uVar20 >> 9 & 1) != 0) {
              uStack_378 = (longlong **)CONCAT44(uStack_378._4_4_,uStack_330);
              uStack_3a0 = 0x104162;
              func_0x(plStack_318,plStack_2e8,lVar10,0);
            }
            uStack_334 = (int)uVar19 + 1;
            uVar19 = (ulonglong)uStack_334;
            lVar10 = lVar10 + 0x50;
            puVar22 = auStack_398;
            plVar23 = plStack_2d8;
            lStack_2f8 = lVar10;
          } while (uStack_334 < uVar30);
        }
      }
    }
    else if (*(int *)(plStack_2e8[1] + 0x100) == 2) {
      uStack_334 = *(uint *)(lVar10 + 0x34);
      uVar27 = (ulonglong)uStack_334 + 0xf;
      if (uVar27 <= uStack_334) {
        uVar27 = 0xffffffffffffff0;
      }
      uVar27 = uVar27 & 0xfffffffffffffff0;
      uStack_3a0 = 0x104b30;
      func_0x();
      lStack_2f0 = param_1[0x14d];
      lVar10 = -uVar27;
      puStack_2e0 = (ushort *)((longlong)auStack_358 + lVar10);
      puVar22 = auStack_398 + lVar10;
      if ((*(byte *)((longlong)plVar35 + 0x14) & 0x10) != 0) {
        lVar16 = plVar35[1];
        auStack_358[0] = (uint)uVar19;
        uVar27 = uVar19 & 0xffffffff;
        uStack_328 = (short *)CONCAT44(uStack_328._4_4_,*(int *)(plVar35 + 2));
        puVar22 = auStack_398 + lVar10;
        plVar23 = plStack_2d8;
        lStack_2f8 = lVar16;
        if (*(int *)(plVar35 + 2) != 0) {
          do {
            lStack_2f8 = lVar16;
            if (*(byte *)(lVar16 + 0x40) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(lVar16 + 0x40) * 4 + 0x107a20) -
                           0xfdaf60);
                    /* WARNING: Could not emulate address calculation at 0x00104b8e */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
              return;
            }
            *(undefined8 *)(auStack_398 + lVar10 + -8) = 0x1075cb;
            iVar9 = func_0x(lVar16);
            plVar23 = plStack_318;
            if (iVar9 != 0) {
              uVar17 = 0;
              if (uVar19 == 0) {
                uVar17 = 3;
              }
              *(undefined8 *)(auStack_398 + lVar10 + -8) = 0x1075ed;
              func_0x(plVar23,lVar16,uVar17);
            }
            *(undefined8 *)(auStack_398 + lVar10 + -8) = 0x1075fb;
            iVar9 = func_0x(lVar16);
            plVar35 = plStack_2e8;
            if (iVar9 != 0) {
              *(undefined4 *)((longlong)&uStack_378 + lVar10) = uStack_338;
              *(undefined8 *)(auStack_398 + lVar10 + -8) = 0x10761c;
              func_0x(plVar23,plVar35,lVar16,uVar19);
            }
            auStack_358[0] = (int)uVar27 + 1;
            uVar27 = (ulonglong)auStack_358[0];
            lVar16 = lVar16 + 0x50;
            puVar22 = auStack_398 + lVar10;
            plVar23 = plStack_2d8;
            lStack_2f8 = lVar16;
          } while (auStack_358[0] < (uint)uStack_328);
        }
      }
    }
    else {
      if (*uStack_328 == -1) {
        *uStack_328 = 1;
      }
      puVar22 = auStack_398;
      plVar23 = plStack_2d8;
      if ((*(byte *)((longlong)plVar35 + 0x14) & 0x10) != 0) {
        uVar30 = *(uint *)(plVar35 + 2);
        lVar10 = plStack_318[1];
        puVar22 = auStack_398;
        if (uVar30 != 0) {
          do {
            if (*(byte *)(lVar10 + 0x40) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(lVar10 + 0x40) * 4 + 0x107878) -
                           0xfdaf60);
                    /* WARNING: Could not emulate address calculation at 0x001041fe */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,0);
              return;
            }
            uVar20 = *(uint *)(lVar10 + 0x40);
            if ((uVar20 >> 10 & 1) != 0) {
              if ((*(byte *)(*(longlong *)(lVar10 + 0x48) + 0x2a) & 0x10) == 0) {
                lVar16 = plStack_318[3];
              }
              else {
                lVar16 = plStack_318[4];
              }
              *(undefined *)(lVar16 + *(longlong *)(lVar10 + 0x30)) = 3;
              uVar20 = *(uint *)(lVar10 + 0x40);
            }
            if ((uVar20 >> 9 & 1) != 0) {
              uStack_378 = (longlong **)CONCAT44(uStack_378._4_4_,uStack_300);
              uStack_3a0 = 0x104ae6;
              func_0x(plStack_318,plStack_2e8,lVar10,0);
            }
            uVar20 = (int)uVar19 + 1;
            uVar19 = (ulonglong)uVar20;
            lVar10 = lVar10 + 0x50;
            puVar22 = auStack_398;
          } while (uVar20 < uVar30);
        }
      }
    }
    plVar35 = plStack_2c0;
    if (plStack_2c0 != (longlong *)0x0) {
      UNRECOVERED_JUMPTABLE = *(code **)(*(longlong *)plVar23[2] + 8);
      *(undefined8 *)(puVar22 + -8) = 0x1072ed;
      (*UNRECOVERED_JUMPTABLE)();
      UNRECOVERED_JUMPTABLE = *(code **)(*plVar35 + 8);
      *(undefined8 *)(puVar22 + -8) = 0x1072f6;
      (*UNRECOVERED_JUMPTABLE)(plVar35);
      goto LAB_;
    }
  }
  else {
    puVar26 = (uint *)0x0;
    puVar1 = (ushort *)(psVar13 + 1);
    uVar30 = 0;
    if (*psVar13 == 0) {
      if ((**(byte **)(psVar13 + 4) & 0x10) != 0) {
        uVar30 = (uint)*(ushort *)(*(byte **)(psVar13 + 4) + *(uint *)(psVar13 + 8));
      }
    }
    else {
      uVar30 = (uint)*puVar1;
    }
    if (uVar30 < *(uint *)(lVar10 + 0x18)) goto LAB_;
    *psVar13 = 0;
    puVar31 = (uint *)plVar35[1];
    auStack_358[0] = 0;
    uStack_334 = (uint)*(ushort *)(*plVar35 + 0x62);
    puVar22 = auStack_398;
    puVar32 = puVar26;
    if (uStack_334 != 0) {
      do {
        uVar30 = (uint)puVar32;
        cVar5 = *(char *)(puVar31 + 0x10);
        if (cVar5 == '\x01') {
          if ((*(byte *)((longlong)puVar31 + 6) & 0x10) == 0) {
            uVar20 = *(byte *)((ulonglong)(*(ushort *)(puVar31 + 1) - 1 >> 3) +
                               (ulonglong)*(uint *)(psVar13 + 8) + 2 + *(longlong *)(psVar13 + 4))
                     >> ((byte)(*(ushort *)(puVar31 + 1) - 1) & 7) & 1;
          }
          else {
            uStack_378 = (longlong **)&uStack_1c8;
            uStack_3a0 = 0x10169d;
            func_0x(puVar1,puVar31,1,&uStack_24c);
            uVar20 = uStack_24c;
          }
          if (uVar20 == 0) goto LAB_;
LAB_:
          if ((*(byte *)(*(longlong *)(puVar31 + 0x12) + 0x2a) & 0x10) == 0) {
            *(undefined *)(plVar35[3] + *(longlong *)(puVar31 + 0xc)) = 3;
          }
          else {
            *(undefined *)(plVar35[4] + *(longlong *)(puVar31 + 0xc)) = 3;
          }
        }
        else {
          if (cVar5 == '\x02') {
LAB_:
            uVar8 = *(ushort *)(puVar31 + 0xf);
            if ((*(byte *)((longlong)puVar31 + 6) & 0x10) == 0) {
LAB_:
              puVar26 = (uint *)((longlong)(int)*puVar31 + *(longlong *)(psVar13 + 4));
              uVar20 = (uint)uVar8;
            }
            else {
              uStack_378 = (longlong **)&iStack_248;
              uStack_3a0 = 0x101734;
              func_0x(puVar1,puVar31,0,(longlong)&uStack_1c8 + 4);
              if (iStack_248 != 0) goto LAB_;
              uVar20 = **(uint **)(puVar31 + 2);
              puVar26 = *(uint **)(puVar31 + 2) + 1;
              if ((uVar8 != 0) && (uVar20 != uVar8)) {
                uStack_378 = (longlong **)0x0;
                uStack_3a0 = 0x101776;
                (*_DAT_)(1,0x19724b0,0x1970e18,0x381);
              }
            }
            auStack_320[0] = uVar20;
            if ((*(byte *)(*(longlong *)(puVar31 + 0x12) + 0x2a) & 0x10) == 0) {
LAB_:
              lVar10 = plVar35[3];
            }
            else {
              lVar10 = plVar35[4];
            }
LAB_:
            *(undefined *)(lVar10 + *(longlong *)(puVar31 + 0xc)) = 0;
          }
          else {
            if (cVar5 == '\x03') {
              if ((*(byte *)((longlong)puVar31 + 6) & 0x10) == 0) {
                uVar20 = *(byte *)((ulonglong)(*(ushort *)(puVar31 + 1) - 1 >> 3) +
                                   (ulonglong)*(uint *)(psVar13 + 8) + 2 +
                                  *(longlong *)(psVar13 + 4)) >>
                         ((byte)(*(ushort *)(puVar31 + 1) - 1) & 7) & 1;
              }
              else {
                uStack_378 = (longlong **)&uStack_1d0;
                uStack_3a0 = 0x100e34;
                func_0x(puVar1,puVar31,1,&uStack_254);
                uVar20 = uStack_254;
              }
              if (uVar20 != 0) goto LAB_;
            }
            else if (cVar5 != '\x04') {
              if (cVar5 == '\b') {
                uVar8 = *(ushort *)(puVar31 + 0xf);
                iVar9 = puVar31[0x10] << 0xc;
                if ((*puVar31 & 0xc0000000) == 0x80000000) {
                  uStack_3a0 = 0x100d96;
                  iVar9 = func_0x(puVar1);
                  if (iVar9 != 0) {
                    uStack_3a0 = 0x100db1;
                    puVar26 = (uint *)func_0x(psVar13 + 0x15,puVar31,auStack_320,auStack_1d4
                                                     );
                    uVar20 = auStack_320[0];
                    goto LAB_;
                  }
                  auStack_320[0] = 0;
                  puVar26 = (uint *)0x0;
                  uVar8 = *(ushort *)(*(longlong *)(puVar31 + 0x12) + 0x2a);
LAB_:
                  if ((uVar8 & 0x10) == 0) {
                    *(undefined *)(plVar35[3] + *(longlong *)(puVar31 + 0xc)) = 3;
                  }
                  else {
                    *(undefined *)(plVar35[4] + *(longlong *)(puVar31 + 0xc)) = 3;
                  }
                  goto LAB_;
                }
                if ((iVar9 < 0) || ((*(byte *)((longlong)puVar31 + 6) & 0x10) != 0)) {
                  uStack_378 = (longlong **)&iStack_2ac;
                  uStack_3a0 = 0x10052e;
                  func_0x(puVar1,puVar31,iVar9 < 0,aiStack_2a8);
                  if ((iVar9 < 0) && (aiStack_2a8[0] != 0)) {
                    puVar26 = (uint *)0x0;
                    auStack_320[0] = 0;
                    uVar20 = auStack_320[0];
                    goto LAB_;
                  }
                }
                else {
                  aiStack_2a8[0] = 0;
                  iStack_2ac = 1;
                }
                if ((iStack_2ac == 0) && ((*(byte *)((longlong)puVar31 + 6) & 0x10) != 0)) {
                  puVar26 = *(uint **)(puVar31 + 2) + 1;
                  uVar20 = **(uint **)(puVar31 + 2);
                }
                else if ((int)*puVar31 < 0) {
                  if (*(int *)(psVar13 + 2) == 0) {
                    *puVar1 = 0;
                    uVar20 = *(uint *)(psVar13 + 8);
                    uVar19 = (ulonglong)uVar20;
                    *(uint *)(psVar13 + 10) = uVar20;
                    pbVar28 = *(byte **)(psVar13 + 4);
                    bVar6 = *pbVar28;
                    if ((bVar6 & 0x10) != 0) {
                      uVar20 = uVar20 + (*(ushort *)(pbVar28 + uVar19) + 7 >> 3) + 2;
                      uVar19 = (ulonglong)uVar20;
                      *(uint *)(psVar13 + 10) = uVar20;
                      bVar6 = *pbVar28;
                    }
                    if ((bVar6 & 0x20) == 0) {
                      *(int *)(psVar13 + 2) = (int)uVar19;
                      psVar13[0xe] = 0;
                      *(uint *)(psVar13 + 0xc) = uVar20;
                    }
                    else {
                      puVar33 = (ushort *)(pbVar28 + uVar19);
                      uVar8 = *puVar33;
                      psVar13[0xe] = uVar8;
                      puStack_2e0 = puVar33;
                      if (uVar8 == 0) {
                        uStack_3a0 = 0x100684;
                        cVar5 = func_0x(0x1ed4660);
                        if (cVar5 != '\0') {
                          uStack_3a0 = 0x10068d;
                          lVar10 = func_0x();
                          if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                            uStack_3a0 = 0x1006a7;
                            cVar5 = func_0x(0x1ed4660);
                            if (cVar5 == '\0') {
                              uStack_3a0 = 0x1006c3;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              uStack_378 = (longlong **)0x0;
                              uStack_3a0 = 0x1006e8;
                              (*_DAT_)(1,0x17c406c,0x18e4158,0x80f);
                            }
                          }
                        }
                        uStack_3a0 = 0x1006f6;
                        func_0x(*(undefined8 *)(psVar13 + 4),3);
                        uVar8 = psVar13[0xe];
                        uVar20 = *(uint *)(psVar13 + 10);
                      }
                      uVar20 = uVar20 + (uVar8 + 1) * 2;
                      *(uint *)(psVar13 + 0xc) = uVar20;
                      if (0x1f9e < uVar20) {
                        uStack_3a0 = 0x100725;
                        cVar5 = func_0x(0x1ed4660);
                        if (cVar5 != '\0') {
                          uStack_3a0 = 0x10072e;
                          lVar10 = func_0x();
                          if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                            uStack_3a0 = 0x100748;
                            cVar5 = func_0x(0x1ed4660);
                            if (cVar5 == '\0') {
                              uStack_3a0 = 0x100764;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              uStack_378 = (longlong **)0x0;
                              uStack_3a0 = 0x100789;
                              (*_DAT_)(1,0x17c406c,0x18e4158,0x816);
                            }
                          }
                        }
                        uStack_3a0 = 0x100797;
                        func_0x(*(undefined8 *)(psVar13 + 4),4);
                        uVar8 = psVar13[0xe];
                        uVar20 = *(uint *)(psVar13 + 0xc);
                      }
                      uVar19 = (ulonglong)uVar8;
                      uVar8 = puVar33[uVar19];
                      *(uint *)(psVar13 + 2) = uVar8 & 0x7fff;
                      if ((uVar8 & 0x7fff) < uVar20) {
                        uStack_3a0 = 0x1007c5;
                        cVar5 = func_0x(0x1ed4660);
                        if (cVar5 != '\0') {
                          uStack_3a0 = 0x1007ce;
                          lVar10 = func_0x();
                          if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                            uStack_3a0 = 0x1007e8;
                            cVar5 = func_0x(0x1ed4660);
                            if (cVar5 == '\0') {
                              uStack_3a0 = 0x100804;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              uStack_378 = (longlong **)0x0;
                              uStack_3a0 = 0x100829;
                              (*_DAT_)(1,0x17c406c,0x18e4158,0x81d);
                            }
                          }
                        }
                        uStack_3a0 = 0x100837;
                        func_0x(*(undefined8 *)(psVar13 + 4),4);
                        uVar20 = *(uint *)(psVar13 + 0xc);
                        uVar19 = (ulonglong)(ushort)psVar13[0xe];
                      }
                      iVar9 = 0;
                      puVar34 = puVar33;
                      if ((short)uVar19 != 0) {
                        do {
                          puVar33 = puVar33 + 1;
                          uVar25 = *puVar33 & 0x7fff;
                          if ((uVar25 < uVar20) || (*(uint *)(psVar13 + 2) < uVar25)) {
                            uStack_3a0 = 0x10087f;
                            cVar5 = func_0x(0x1ed4660);
                            if (cVar5 != '\0') {
                              uStack_3a0 = 0x100888;
                              lVar10 = func_0x();
                              if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                                uStack_3a0 = 0x1008a2;
                                cVar5 = func_0x(0x1ed4660);
                                if (cVar5 == '\0') {
                                  uStack_3a0 = 0x1008be;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  uStack_378 = (longlong **)0x0;
                                  uStack_3a0 = 0x1008e2;
                                  (*_DAT_)(1,0x17c406c,0x18e4158,0x82a);
                                }
                              }
                            }
                            uStack_3a0 = 0x1008f0;
                            func_0x(*(undefined8 *)(psVar13 + 4),4);
                          }
                          uVar19 = (ulonglong)(ushort)psVar13[0xe];
                          iVar9 = iVar9 + 1;
                          puVar34 = puStack_2e0;
                          uVar30 = auStack_358[0];
                          uVar20 = uVar25;
                        } while (iVar9 < (int)(uint)(ushort)psVar13[0xe]);
                      }
                      if ((short)puVar34[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
                        do {
                          lVar10 = (ulonglong)*(uint *)(psVar13 + 10) + *(longlong *)(psVar13 + 4);
                          uVar20 = *(ushort *)(lVar10 + uVar19 * 2) & 0x7fff;
                          if ((int)uVar19 == 1) {
                            uVar25 = *(uint *)(psVar13 + 0xc);
                            uVar21 = uVar25;
LAB_:
                            if ((uVar20 < uVar25) || (*(uint *)(psVar13 + 2) < uVar20))
                            goto LAB_;
                          }
                          else {
                            uVar21 = *(uint *)(psVar13 + 0xc);
                            uVar25 = *(ushort *)(lVar10 + -2 + uVar19 * 2) & 0x7fff;
                            if (uVar21 <= uVar25) goto LAB_;
LAB_:
                            uStack_3a0 = 0x10096c;
                            func_0x(*(longlong *)(psVar13 + 4),7);
                            uVar21 = *(uint *)(psVar13 + 0xc);
                          }
                          if ((uVar25 < uVar21) || (*(uint *)(psVar13 + 2) < uVar25))
                          goto LAB_;
                          if (*(ushort *)((ulonglong)uVar25 + *(longlong *)(psVar13 + 4)) == 5) {
                            *puVar1 = *puVar1 | 2;
                            psVar13[0xe] = psVar13[0xe] + -1;
                            psVar13[0x15] = (short)uVar25;
                            uVar19 = *(ulonglong *)(psVar13 + 4);
                            uVar7 = psVar13[0x16] & 0xc7ff;
                            uVar8 = *(ushort *)((ulonglong)(uVar25 & 0xffff) + 2 + uVar19);
                            if ((uVar8 >> 0xe & 1) != 0) {
                              uVar7 = uVar8 & 0x3800 | uVar7;
                            }
                            psVar13[0x16] = uVar7;
                            uVar8 = (uVar7 ^ *(ushort *)((ulonglong)(uVar25 & 0xffff) + 2 + uVar19))
                                    & 0x7ff ^ uVar7;
                            psVar13[0x16] = uVar8;
                            uVar29 = (ulonglong)(ushort)psVar13[0x15];
                            uVar27 = (ulonglong)((uVar8 & 0x7ff) * 2) + 4 +
                                     uVar19 + (uVar7 >> 0xb & 7) * 2 + uVar29;
                            if (uVar27 < uVar29 + uVar19) {
                              uStack_3a0 = 0x100a7e;
                              func_0x(uVar29 + uVar19,0x19);
                              uVar8 = psVar13[0x16];
                              uVar29 = (ulonglong)(ushort)psVar13[0x15];
                              uVar19 = (ulonglong)*(uint *)(psVar13 + 4);
                            }
                            if (uVar20 - uVar25 <
                                (((uVar8 & 0x7ff) * 2 - (int)uVar29) - (int)uVar19) + (int)uVar27) {
                              uStack_3a0 = 0x100ab6;
                              func_0x(uVar29 + *(longlong *)(psVar13 + 4),0x19);
                              uVar8 = psVar13[0x16];
                            }
                            iVar9 = 0;
                            if (((uVar8 & 0x3800) != 0) &&
                               (puVar33 = (ushort *)
                                          (*(longlong *)(psVar13 + 4) + 4 +
                                          (ulonglong)(ushort)psVar13[0x15]), (uVar8 & 0x3800) != 0))
                            {
                              do {
                                if ((uVar8 & 0x7ff) < (*puVar33 & 0x7ff)) {
                                  uStack_3a0 = 0x100b17;
                                  func_0x((ulonglong)(ushort)psVar13[0x15] +
                                                  *(longlong *)(psVar13 + 4),0x1a);
                                  uVar8 = psVar13[0x16];
                                }
                                iVar9 = iVar9 + 1;
                                puVar33 = puVar33 + 1;
                              } while (iVar9 < (int)(uVar8 >> 0xb & 7));
                            }
                            goto LAB_;
                          }
                          if (*(ushort *)((ulonglong)uVar25 + *(longlong *)(psVar13 + 4)) < 0x400)
                          goto LAB_;
                          *puVar1 = *puVar1 | 1;
                          uVar8 = psVar13[0xe] - 1;
                          psVar13[0xe] = uVar8;
                          if (uVar8 == 0) goto LAB_;
                          uVar19 = (ulonglong)uVar8;
                        } while ((short)puVar34[(ulonglong)(uVar8 - 1) + 1] < 0);
                        pbVar28 = *(byte **)(psVar13 + 4);
                      }
                      else {
LAB_:
                        pbVar28 = *(byte **)(psVar13 + 4);
                      }
                    }
                    if ((*pbVar28 & 0x40) == 0) {
                      *(undefined4 *)(psVar13 + 0x13) = 0;
                    }
                    else {
                      *(int *)(psVar13 + 0x13) = *(int *)(psVar13 + 2);
                      *(int *)(psVar13 + 2) = *(int *)(psVar13 + 2) + 0xe;
                      uStack_3a0 = 0x100b65;
                      uVar14 = func_0x(puVar1);
                      uStack_3a0 = 0x100b74;
                      func_0x(uVar14,auStack_198);
                      uStack_3a0 = 0x100b80;
                      iVar9 = func_0x(auStack_198);
                      *(int *)(psVar13 + 2) = *(int *)(psVar13 + 2) + iVar9;
                    }
                    uVar20 = *(uint *)(psVar13 + 2);
                    if ((*(ulonglong *)(psVar13 + 0xf) != 0) &&
                       (*(ulonglong *)(psVar13 + 0xf) <
                        (ulonglong)uVar20 + *(longlong *)(psVar13 + 4))) {
                      uStack_3a0 = 0x100bb4;
                      cVar5 = func_0x(0x1ed4660);
                      if (cVar5 != '\0') {
                        uStack_3a0 = 0x100bbd;
                        lVar10 = func_0x();
                        if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                          uStack_3a0 = 0x100bd7;
                          cVar5 = func_0x(0x1ed4660);
                          if (cVar5 == '\0') {
                            uStack_3a0 = 0x100bf3;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            uStack_378 = (longlong **)0x0;
                            uStack_3a0 = 0x100c18;
                            (*_DAT_)(1,0x17c406c,0x18e4158,0x886);
                          }
                        }
                      }
                      uStack_3a0 = 0x100c26;
                      func_0x(*(undefined8 *)(psVar13 + 4),0x12);
                      uVar20 = *(uint *)(psVar13 + 2);
                    }
                    if (0x3f3b < uVar20 - 1) {
                      uStack_3a0 = 0x100c3f;
                      cVar5 = func_0x(0x1ed4660);
                      if (cVar5 != '\0') {
                        uStack_3a0 = 0x100c48;
                        lVar10 = func_0x();
                        if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                          uStack_3a0 = 0x100c62;
                          cVar5 = func_0x(0x1ed4660);
                          if (cVar5 == '\0') {
                            uStack_3a0 = 0x100c7e;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            uStack_378 = (longlong **)0x0;
                            uStack_3a0 = 0x100ca3;
                            (*_DAT_)(1,0x17c406c,0x18e4158,0x88b);
                          }
                        }
                      }
                      uStack_3a0 = 0x100cb1;
                      func_0x(*(undefined8 *)(psVar13 + 4),5);
                    }
                  }
LAB_:
                  sVar24 = -*(short *)puVar31;
                  if ((*(byte *)((longlong)puVar31 + 6) & 0x10) != 0) {
                    uStack_378 = (longlong **)&iStack_258;
                    uStack_3a0 = 0x100ce2;
                    func_0x(puVar1,puVar31,0,auStack_1d8);
                    if (iStack_258 == 0) {
                      puVar26 = *(uint **)(puVar31 + 2) + 1;
                      plVar35 = plStack_318;
                      uVar20 = **(uint **)(puVar31 + 2);
                      goto LAB_;
                    }
                  }
                  lVar10 = (longlong)sVar24;
                  if ((uint)(ushort)psVar13[0xe] < (uint)(int)sVar24) {
                    auStack_320[0] = 0;
                    puVar26 = *(uint **)(psVar13 + 4);
                    plVar35 = plStack_318;
                    uVar20 = auStack_320[0];
                  }
                  else {
                    lVar16 = *(longlong *)(psVar13 + 4);
                    lVar15 = (ulonglong)*(uint *)(psVar13 + 10) + lVar16;
                    if (sVar24 == 1) {
                      uVar25 = *(ushort *)(lVar15 + lVar10 * 2) & 0x7fff;
                      uVar20 = *(uint *)(uStack_328 + 0xc);
LAB_:
                      if ((uVar25 < uVar20) || (*(uint *)(psVar13 + 2) < uVar25)) goto LAB_;
                    }
                    else {
                      uVar20 = *(ushort *)(lVar15 + -2 + lVar10 * 2) & 0x7fff;
                      uVar25 = *(ushort *)(lVar15 + lVar10 * 2) & 0x7fff;
                      lVar16 = *(longlong *)(psVar13 + 4);
                      if (*(uint *)(uStack_328 + 0xc) <= uVar20) goto LAB_;
LAB_:
                      uStack_3a0 = 0x100d6e;
                      func_0x(lVar16,7);
                    }
                    puVar26 = (uint *)((ulonglong)uVar20 + *(longlong *)(psVar13 + 4));
                    plVar35 = plStack_318;
                    uVar20 = uVar25 - uVar20;
                  }
                }
                else if ((*(ushort *)((longlong)puVar31 + 6) & 8) == 0) {
                  if ((*(ushort *)((longlong)puVar31 + 6) & 0x10) != 0) {
                    uStack_378 = (longlong **)&iStack_25c;
                    uStack_3a0 = 0x1005ab;
                    func_0x(puVar1,puVar31,0,auStack_1dc);
                    if (iStack_25c == 0) {
                      uVar20 = **(uint **)(puVar31 + 2);
                      puVar26 = *(uint **)(puVar31 + 2) + 1;
                      if ((uVar8 != 0) && (uVar20 != uVar8)) {
                        uStack_378 = (longlong **)0x0;
                        uStack_3a0 = 0x1005ed;
                        (*_DAT_)(1,0x19724b0,0x1970e18,0x381);
                      }
                      goto LAB_;
                    }
                  }
                  puVar26 = (uint *)((longlong)(int)*puVar31 + *(longlong *)(psVar13 + 4));
                  uVar20 = (uint)uVar8;
                }
                else {
                  uStack_3a0 = 0x100615;
                  puVar26 = (uint *)func_0x(puVar1,puVar31);
                  uVar20 = auStack_320[0];
                }
LAB_:
                auStack_320[0] = uVar20;
                uVar8 = *(ushort *)(*(longlong *)(puVar31 + 0x12) + 0x2a);
                if (puVar26 == (uint *)0x0) goto LAB_;
                if ((uVar8 & 0x10) == 0) goto LAB_;
                lVar10 = plVar35[4];
                goto LAB_;
              }
              uStack_378 = (longlong **)0x153f5d0;
              uStack_3a0 = 0x1004c0;
              (*_DAT_)(1,0x1945960,0x1972328,0x27d);
              goto LAB_;
            }
            if (*(int *)(psVar13 + 2) == 0) {
              *puVar1 = 0;
              uVar20 = *(uint *)(psVar13 + 8);
              uVar19 = (ulonglong)uVar20;
              *(uint *)(psVar13 + 10) = uVar20;
              pbVar28 = *(byte **)(psVar13 + 4);
              bVar6 = *pbVar28;
              pbVar18 = pbVar28;
              if ((bVar6 & 0x10) != 0) {
                uVar20 = uVar20 + (*(ushort *)(pbVar28 + uVar19) + 7 >> 3) + 2;
                uVar19 = (ulonglong)uVar20;
                *(uint *)(psVar13 + 10) = uVar20;
                bVar6 = *pbVar28;
                pbVar18 = *(byte **)(psVar13 + 4);
              }
              if ((bVar6 & 0x20) == 0) {
                *(int *)(psVar13 + 2) = (int)uVar19;
                psVar13[0xe] = 0;
                *(uint *)(psVar13 + 0xc) = uVar20;
              }
              else {
                puVar33 = (ushort *)(pbVar28 + uVar19);
                uVar8 = *puVar33;
                psVar13[0xe] = uVar8;
                puStack_2e0 = puVar33;
                if (uVar8 == 0) {
                  uStack_3a0 = 0x100ee7;
                  cVar5 = func_0x(0x1ed4660);
                  if (cVar5 != '\0') {
                    uStack_3a0 = 0x100ef0;
                    lVar10 = func_0x();
                    if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                      uStack_3a0 = 0x100f0a;
                      cVar5 = func_0x(0x1ed4660);
                      if (cVar5 == '\0') {
                        uStack_3a0 = 0x100f26;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        uStack_378 = (longlong **)0x0;
                        uStack_3a0 = 0x100f4b;
                        (*_DAT_)(1,0x17c406c,0x18e4158,0x80f);
                      }
                    }
                  }
                  uStack_3a0 = 0x100f57;
                  func_0x(*(undefined8 *)(psVar13 + 4),3);
                  uVar8 = psVar13[0xe];
                  uVar20 = *(uint *)(psVar13 + 10);
                }
                uVar20 = uVar20 + (uVar8 + 1) * 2;
                *(uint *)(psVar13 + 0xc) = uVar20;
                if (0x1f9e < uVar20) {
                  uStack_3a0 = 0x100f87;
                  cVar5 = func_0x(0x1ed4660);
                  if (cVar5 != '\0') {
                    uStack_3a0 = 0x100f90;
                    lVar10 = func_0x();
                    if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                      uStack_3a0 = 0x100faa;
                      cVar5 = func_0x(0x1ed4660);
                      if (cVar5 == '\0') {
                        uStack_3a0 = 0x100fc6;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        uStack_378 = (longlong **)0x0;
                        uStack_3a0 = 0x100feb;
                        (*_DAT_)(1,0x17c406c,0x18e4158,0x816);
                      }
                    }
                  }
                  uStack_3a0 = 0x100ff9;
                  func_0x(*(undefined8 *)(psVar13 + 4),4);
                  uVar8 = psVar13[0xe];
                  uVar20 = *(uint *)(psVar13 + 0xc);
                }
                uVar19 = (ulonglong)uVar8;
                uVar8 = puVar33[uVar19];
                *(uint *)(psVar13 + 2) = uVar8 & 0x7fff;
                if ((uVar8 & 0x7fff) < uVar20) {
                  uStack_3a0 = 0x101027;
                  cVar5 = func_0x(0x1ed4660);
                  if (cVar5 != '\0') {
                    uStack_3a0 = 0x101030;
                    lVar10 = func_0x();
                    if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                      uStack_3a0 = 0x10104a;
                      cVar5 = func_0x(0x1ed4660);
                      if (cVar5 == '\0') {
                        uStack_3a0 = 0x101066;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        uStack_378 = (longlong **)0x0;
                        uStack_3a0 = 0x10108b;
                        (*_DAT_)(1,0x17c406c,0x18e4158,0x81d);
                      }
                    }
                  }
                  uStack_3a0 = 0x101099;
                  func_0x(*(undefined8 *)(psVar13 + 4),4);
                  uVar20 = *(uint *)(psVar13 + 0xc);
                  uVar19 = (ulonglong)(ushort)psVar13[0xe];
                }
                iVar9 = 0;
                puVar34 = puVar33;
                if ((short)uVar19 != 0) {
                  do {
                    puVar33 = puVar33 + 1;
                    uVar25 = *puVar33 & 0x7fff;
                    if ((uVar25 < uVar20) || (*(uint *)(psVar13 + 2) < uVar25)) {
                      uStack_3a0 = 0x1010df;
                      cVar5 = func_0x(0x1ed4660);
                      if (cVar5 != '\0') {
                        uStack_3a0 = 0x1010e8;
                        lVar10 = func_0x();
                        if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                          uStack_3a0 = 0x101102;
                          cVar5 = func_0x(0x1ed4660);
                          if (cVar5 == '\0') {
                            uStack_3a0 = 0x10111e;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            uStack_378 = (longlong **)0x0;
                            uStack_3a0 = 0x101142;
                            (*_DAT_)(1,0x17c406c,0x18e4158,0x82a);
                          }
                        }
                      }
                      uStack_3a0 = 0x101150;
                      func_0x(*(undefined8 *)(psVar13 + 4),4);
                    }
                    uVar19 = (ulonglong)(ushort)psVar13[0xe];
                    iVar9 = iVar9 + 1;
                    puVar34 = puStack_2e0;
                    uVar30 = auStack_358[0];
                    uVar20 = uVar25;
                  } while (iVar9 < (int)(uint)(ushort)psVar13[0xe]);
                }
                if ((short)puVar34[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
                  do {
                    lVar10 = *(longlong *)(psVar13 + 4);
                    uVar20 = *(ushort *)((ulonglong)*(uint *)(psVar13 + 10) + lVar10 + uVar19 * 2) &
                             0x7fff;
                    if ((int)uVar19 == 1) {
                      uVar25 = *(uint *)(psVar13 + 0xc);
                      uVar21 = uVar25;
LAB_:
                      if ((uVar20 < uVar25) || (*(uint *)(psVar13 + 2) < uVar20)) goto LAB_;
                    }
                    else {
                      uVar21 = *(uint *)(psVar13 + 0xc);
                      uVar25 = *(ushort *)
                                ((ulonglong)*(uint *)(psVar13 + 10) + lVar10 + -2 + uVar19 * 2) &
                               0x7fff;
                      if (uVar21 <= uVar25) goto LAB_;
LAB_:
                      uStack_3a0 = 0x1011cc;
                      func_0x(lVar10,7);
                      uVar21 = *(uint *)(psVar13 + 0xc);
                      lVar10 = *(longlong *)(psVar13 + 4);
                    }
                    if ((uVar25 < uVar21) || (*(uint *)(psVar13 + 2) < uVar25)) goto LAB_;
                    if (*(ushort *)((ulonglong)uVar25 + lVar10) == 5) {
                      *puVar1 = *puVar1 | 2;
                      psVar13[0xe] = psVar13[0xe] + -1;
                      psVar13[0x15] = (short)uVar25;
                      uVar19 = *(ulonglong *)(psVar13 + 4);
                      uVar7 = psVar13[0x16] & 0xc7ff;
                      uVar8 = *(ushort *)((ulonglong)(uVar25 & 0xffff) + 2 + uVar19);
                      if ((uVar8 >> 0xe & 1) != 0) {
                        uVar7 = uVar8 & 0x3800 | uVar7;
                      }
                      psVar13[0x16] = uVar7;
                      uVar8 = (uVar7 ^ *(ushort *)((ulonglong)(uVar25 & 0xffff) + 2 + uVar19)) &
                              0x7ff ^ uVar7;
                      psVar13[0x16] = uVar8;
                      uVar29 = (ulonglong)(ushort)psVar13[0x15];
                      uVar27 = (ulonglong)((uVar8 & 0x7ff) * 2) + 4 +
                               uVar29 + (uVar7 >> 0xb & 7) * 2 + uVar19;
                      if (uVar27 < uVar29 + uVar19) {
                        uStack_3a0 = 0x1012df;
                        func_0x(uVar29 + uVar19,0x19);
                        uVar8 = psVar13[0x16];
                        uVar29 = (ulonglong)(ushort)psVar13[0x15];
                        uVar19 = (ulonglong)*(uint *)(psVar13 + 4);
                      }
                      if (uVar20 - uVar25 <
                          (((uVar8 & 0x7ff) * 2 - (int)uVar29) - (int)uVar19) + (int)uVar27) {
                        uStack_3a0 = 0x101317;
                        func_0x(uVar29 + *(longlong *)(psVar13 + 4),0x19);
                        uVar8 = psVar13[0x16];
                      }
                      iVar9 = 0;
                      if (((uVar8 & 0x3800) != 0) &&
                         (puVar33 = (ushort *)
                                    (*(longlong *)(psVar13 + 4) + 4 +
                                    (ulonglong)(ushort)psVar13[0x15]), (uVar8 & 0x3800) != 0)) {
                        do {
                          if ((uVar8 & 0x7ff) < (*puVar33 & 0x7ff)) {
                            uStack_3a0 = 0x101377;
                            func_0x((ulonglong)(ushort)psVar13[0x15] +
                                            *(longlong *)(psVar13 + 4),0x1a);
                            uVar8 = psVar13[0x16];
                          }
                          iVar9 = iVar9 + 1;
                          puVar33 = puVar33 + 1;
                        } while (iVar9 < (int)(uVar8 >> 0xb & 7));
                      }
                      goto LAB_;
                    }
                    if (*(ushort *)((ulonglong)uVar25 + lVar10) < 0x400) goto LAB_;
                    *puVar1 = *puVar1 | 1;
                    uVar8 = psVar13[0xe] - 1;
                    psVar13[0xe] = uVar8;
                    if (uVar8 == 0) goto LAB_;
                    uVar19 = (ulonglong)uVar8;
                  } while ((short)puVar34[(ulonglong)(uVar8 - 1) + 1] < 0);
                  pbVar18 = *(byte **)(psVar13 + 4);
                }
                else {
LAB_:
                  pbVar18 = *(byte **)(psVar13 + 4);
                }
              }
              if ((*pbVar18 & 0x40) == 0) {
                *(undefined4 *)(psVar13 + 0x13) = 0;
              }
              else {
                *(int *)(psVar13 + 0x13) = *(int *)(psVar13 + 2);
                *(int *)(psVar13 + 2) = *(int *)(psVar13 + 2) + 0xe;
                uStack_3a0 = 0x1013c5;
                uVar14 = func_0x(puVar1);
                uStack_3a0 = 0x1013d4;
                func_0x(uVar14,auStack_190);
                uStack_3a0 = 0x1013e0;
                iVar9 = func_0x(auStack_190);
                *(int *)(psVar13 + 2) = *(int *)(psVar13 + 2) + iVar9;
                pbVar18 = *(byte **)(psVar13 + 4);
              }
              uVar20 = *(uint *)(psVar13 + 2);
              if ((*(byte **)(psVar13 + 0xf) != (byte *)0x0) &&
                 (*(byte **)(psVar13 + 0xf) < pbVar18 + uVar20)) {
                uStack_3a0 = 0x101417;
                cVar5 = func_0x(0x1ed4660);
                if (cVar5 != '\0') {
                  uStack_3a0 = 0x101420;
                  lVar10 = func_0x();
                  if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                    uStack_3a0 = 0x10143a;
                    cVar5 = func_0x(0x1ed4660);
                    if (cVar5 == '\0') {
                      uStack_3a0 = 0x101456;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      uStack_378 = (longlong **)0x0;
                      uStack_3a0 = 0x10147b;
                      (*_DAT_)(1,0x17c406c,0x18e4158,0x886);
                    }
                  }
                }
                uStack_3a0 = 0x101489;
                func_0x(*(undefined8 *)(psVar13 + 4),0x12);
                uVar20 = *(uint *)(psVar13 + 2);
              }
              if (0x3f3b < uVar20 - 1) {
                uStack_3a0 = 0x1014a2;
                cVar5 = func_0x(0x1ed4660);
                if (cVar5 != '\0') {
                  uStack_3a0 = 0x1014ab;
                  lVar10 = func_0x();
                  if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                    uStack_3a0 = 0x1014c5;
                    cVar5 = func_0x(0x1ed4660);
                    if (cVar5 == '\0') {
                      uStack_3a0 = 0x1014e1;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      uStack_378 = (longlong **)0x0;
                      uStack_3a0 = 0x101506;
                      (*_DAT_)(1,0x17c406c,0x18e4158,0x88b);
                    }
                  }
                }
                uStack_3a0 = 0x101514;
                func_0x(*(undefined8 *)(psVar13 + 4),5);
              }
            }
LAB_:
            sVar24 = -*(short *)puVar31;
            if ((*(byte *)((longlong)puVar31 + 6) & 0x10) == 0) {
LAB_:
              lVar10 = (longlong)sVar24;
              if ((uint)(ushort)psVar13[0xe] < (uint)(int)sVar24) {
                auStack_320[0] = 0;
                puVar26 = *(uint **)(psVar13 + 4);
              }
              else {
                lVar16 = *(longlong *)(psVar13 + 4);
                lVar15 = (ulonglong)*(uint *)(psVar13 + 10) + lVar16;
                if (sVar24 == 1) {
                  uVar20 = *(ushort *)(lVar15 + lVar10 * 2) & 0x7fff;
                  uVar19 = (ulonglong)*(uint *)(uStack_328 + 0xc);
LAB_:
                  if ((uVar20 < (uint)uVar19) || (*(uint *)(psVar13 + 2) < uVar20))
                  goto LAB_;
                }
                else {
                  uVar25 = *(ushort *)(lVar15 + -2 + lVar10 * 2) & 0x7fff;
                  uVar19 = (ulonglong)uVar25;
                  uVar20 = *(ushort *)(lVar15 + lVar10 * 2) & 0x7fff;
                  lVar16 = *(longlong *)(psVar13 + 4);
                  if (*(uint *)(uStack_328 + 0xc) <= uVar25) goto LAB_;
LAB_:
                  uStack_3a0 = 0x1015cd;
                  func_0x(lVar16,7);
                }
                auStack_320[0] = uVar20 - (int)uVar19;
                puVar26 = (uint *)(uVar19 + *(longlong *)(psVar13 + 4));
              }
            }
            else {
              uStack_378 = (longlong **)&iStack_250;
              uStack_3a0 = 0x101545;
              func_0x(puVar1,puVar31,0,(longlong)&uStack_1d0 + 4);
              if (iStack_250 != 0) goto LAB_;
              auStack_320[0] = **(uint **)(puVar31 + 2);
              puVar26 = *(uint **)(puVar31 + 2) + 1;
            }
            plVar35 = plStack_318;
            if (((puVar31[0x10] & 0x2000) != 0) && (auStack_320[0] == 0)) {
              auStack_320[0] = 4;
              puVar26 = (uint *)0x156ac34;
            }
            if ((*(byte *)(*(longlong *)(puVar31 + 0x12) + 0x2a) & 0x10) == 0) {
              lVar10 = plStack_318[3];
            }
            else {
              lVar10 = plStack_318[4];
            }
            *(undefined *)(lVar10 + *(longlong *)(puVar31 + 0xc)) = 0;
            if ((1 << (**(byte **)(psVar13 + 4) & 0xe) & 0x440U) != 0) {
              uStack_3a0 = 0x101642;
              iVar9 = func_0x(puVar31);
              if (iVar9 != 0) goto LAB_;
            }
            if (*(ushort *)(puVar31 + 0xf) < auStack_320[0]) {
              uStack_3a0 = 0x10166f;
              (*_DAT_)(6,0x52,0x16,0x91);
            }
          }
LAB_:
          uVar19 = (ulonglong)auStack_320[0];
          lVar10 = *(longlong *)(puVar31 + 0x12);
          if ((puVar31[0x10] & 0x800) == 0) {
            if ((*(byte *)(lVar10 + 0x2a) & 0x10) == 0) {
              lVar10 = plVar35[3];
            }
            else {
              lVar10 = plVar35[4];
            }
            uStack_3a0 = 0x1017db;
            func_0x(lVar10 + *(longlong *)(puVar31 + 10),puVar26);
          }
          else {
            uVar8 = *(ushort *)(lVar10 + 0x2a) & 0x10;
            if (*(int *)(lVar10 + 0x10) == 10) {
              if (uVar8 == 0) {
                lVar10 = plVar35[3];
              }
              else {
                lVar10 = plVar35[4];
              }
              *(uint **)(lVar10 + *(longlong *)(puVar31 + 10)) = puVar26;
            }
            else {
              if (uVar8 == 0) {
                lVar10 = plVar35[3];
              }
              else {
                lVar10 = plVar35[4];
              }
              uStack_3a0 = 0x101811;
              func_0x(*(undefined8 *)(*(longlong *)(puVar31 + 10) + lVar10),puVar26)
              ;
            }
          }
          if ((puVar31[0x10] & 0x100) != 0) {
            if ((*(byte *)(*(longlong *)(puVar31 + 0x12) + 0x2a) & 0x10) == 0) {
              lVar10 = plVar35[3];
            }
            else {
              lVar10 = plVar35[4];
            }
            *(ulonglong *)(lVar10 + *(longlong *)(*(longlong *)(puVar31 + 0x12) + 0x18)) = uVar19;
          }
        }
LAB_:
        auStack_358[0] = uVar30 + 1;
        puVar31 = puVar31 + 0x14;
        puVar22 = auStack_398;
        puVar32 = (uint *)(ulonglong)auStack_358[0];
      } while (auStack_358[0] < uStack_334);
    }
  }
  plVar23 = plStack_2c0;
  UNRECOVERED_JUMPTABLE = *(code **)(*plStack_2c0 + 8);
  *(undefined8 *)(puVar22 + -8) = 0x101891;
  (*UNRECOVERED_JUMPTABLE)(plVar23);
LAB_:
  uVar19 = uStack_48 ^ (ulonglong)auStack_358;
  *(undefined8 *)(puVar22 + -8) = 0x1076b3;
  func_0x(uVar19);
  return;
}

