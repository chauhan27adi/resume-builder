
/* WARNING: Removing unreachable block (ram,0x00101620) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,short *param_3,int param_4,undefined8 param_5,
                 undefined4 param_6)

{
  byte *pbVar1;
  byte bVar2;
  short sVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong lVar7;
  ushort *puVar8;
  undefined auVar9 [16];
  ushort uVar10;
  ushort uVar11;
  undefined4 uVar12;
  int iVar13;
  int iVar14;
  longlong lVar15;
  ulonglong *puVar16;
  longlong *plVar17;
  short *psVar18;
  uint uVar19;
  uint uVar20;
  code *UNRECOVERED_JUMPTABLE_00;
  short sVar21;
  ushort *puVar22;
  longlong *plVar23;
  byte **ppbVar24;
  uint uVar25;
  byte *pbVar26;
  byte *pbVar27;
  ulonglong uVar28;
  ushort *puVar29;
  ulonglong uVar30;
  ulonglong uVar31;
  uint uVar32;
  longlong *plVar33;
  ulonglong uVar34;
  char cVar35;
  short sStack_1b8;
  ushort uStack_1b6;
  uint uStack_1b4;
  byte *pbStack_1b0;
  undefined8 uStack_1a8;
  uint uStack_1a0;
  ushort uStack_19c;
  byte *pbStack_19a;
  undefined2 uStack_192;
  undefined2 uStack_190;
  ushort uStack_18e;
  ushort uStack_18c;
  undefined2 uStack_18a;
  undefined2 uStack_180;
  uint uStack_17c;
  byte *pbStack_178;
  undefined8 uStack_170;
  undefined8 uStack_162;
  undefined2 uStack_15a;
  undefined2 uStack_158;
  undefined6 uStack_156;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined2 uStack_140;
  int iStack_138;
  ushort *puStack_130;
  undefined2 uStack_128;
  uint uStack_120;
  undefined8 uStack_118;
  longlong lStack_110;
  undefined4 uStack_108;
  longlong lStack_100;
  undefined2 uStack_f0;
  undefined4 uStack_ec;
  byte *pbStack_e8;
  undefined8 uStack_e0;
  undefined8 uStack_d2;
  undefined2 uStack_ca;
  undefined2 uStack_c8;
  undefined6 uStack_c6;
  int iStack_bc;
  undefined auStack_b8 [16];
  undefined auStack_a8 [8];
  undefined8 uStack_a0;
  undefined8 uStack_98;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined6 uStack_88;
  undefined2 uStack_82;
  undefined2 uStack_80;
  undefined6 uStack_7e;
  undefined8 uStack_78;
  short *psStack_70;
  short *psStack_68;
  short sStack_60;
  undefined6 uStack_5e;
  undefined auStack_58 [10];
  undefined auStack_4e [6];
  undefined8 uStack_48;
  ulonglong uStack_40;
  
  uStack_40 = _DAT_ ^ (ulonglong)&sStack_1b8;
  plVar23 = (longlong *)0x0;
  uVar25 = 0;
  uVar4 = *(undefined8 *)(param_2 + 8);
  sVar3 = *(short *)(param_2 + 0x18);
  uStack_118 = param_5;
  uVar20 = 0;
  sStack_1b8 = -1;
  pbStack_1b0 = (byte *)0x0;
  uStack_1b4 = 0;
  pbStack_19a = (byte *)0x0;
  uStack_190 = 0;
  uStack_18e = 0;
  uStack_18c = 0;
  uStack_18a = 0;
  uStack_1a8 = (longlong *)0x0;
  uStack_108 = 2;
  uStack_120 = 9;
  uStack_148 = 0xf;
  uStack_144 = param_4;
  lStack_110 = param_1;
  lStack_100 = param_2;
  if (*(int *)(param_1 + 0xf84) != 0) {
    if ((*(byte *)(param_2 + 0x1e) & 1) == 0) {
      *(undefined4 *)(param_1 + 0xf80) = 0;
      uVar19 = uVar20;
    }
    else {
      uVar19 = *(int *)(param_1 + 0xf80) + 1;
      *(uint *)(param_1 + 0xf80) = uVar19;
      if (uVar19 != 0) goto LAB_;
    }
    if ((*(byte *)(*(longlong *)(param_1 + 0x28) + 0x108) & 8) != 0) {
LAB_:
      uStack_17c = 0;
      uStack_162 = 0;
      uStack_158 = 0;
      uStack_156 = 0;
      uStack_170 = 0;
      if (uVar19 == 0x7fffffff) {
        (*_DAT_)(6,0x42,0x10,1,(ulonglong)*(uint6 *)(param_1 + 0x34) << 0x10);
        plVar23 = (longlong *)(ulonglong)uStack_17c;
      }
      pbStack_178 = *(byte **)(param_2 + 8);
      if ((*pbStack_178 & 1) == 0) {
        uStack_180 = 0;
        uStack_15a = 0;
        uStack_158 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001002d4 */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_178 & 0xe) * 4 + 0x103b74) -
                  0x14dbae0))
                  (0xfffffffffeb24520,(longlong)(int)(*pbStack_178 & 0xe),pbStack_178,plVar23);
        return;
      }
      uStack_180 = 1;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_178 & 0x1c) + 0x103b54)
                              * 4 + 0x103b44) - 0x14dbae0);
                    /* WARNING: Could not emulate address calculation at 0x00100172 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
  }
  if (*(int *)(param_1 + 0xf98) != 0) {
    pbStack_1b0 = *(byte **)(param_2 + 8);
    if ((*pbStack_1b0 & 1) == 0) {
      sStack_1b8 = 0;
      uStack_1b4 = 0;
      uStack_192 = 0;
      uStack_190 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001015b8 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_1b0 & 0xe) * 4 + 0x103be0) -
                0x14dbae0))(9);
      return;
    }
    sStack_1b8 = 1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_1b0 & 0x1c) + 0x103bc0) *
                            4 + 0x103bb0) - 0x14dbae0);
                    /* WARNING: Could not emulate address calculation at 0x001013f9 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  lVar15 = *(longlong *)(param_1 + 0xdf0);
  iStack_138 = -1;
  plVar17 = plVar23;
  if (lVar15 != 0) {
    uVar32 = 0x2000 - *(int *)(param_1 + 0xb38);
    sVar21 = 1 << ((byte)*(undefined2 *)(lVar15 + 4) & 2);
    uVar19 = (uint)(ushort)(sVar21 + -1 + sVar3 & -sVar21);
    if (uVar19 <= uVar32) {
      uVar19 = uVar32;
    }
    if (2 < *(ushort *)(lVar15 + 0x1c)) {
      uVar25 = *(ushort *)(lVar15 + 0x1c) - 2;
    }
    plVar17 = (longlong *)0x0;
    if (uVar19 <= uVar25) {
      iStack_138 = func_0x(lVar15,uVar4,sVar3);
      plVar17 = (longlong *)(ulonglong)uStack_1b4;
    }
  }
  iVar14 = iStack_138;
  if (iStack_138 == -1) {
    lVar15 = *(longlong *)(param_1 + 0xdf0);
    if (lVar15 != 0) {
      *(ushort *)(lVar15 + 4) = *(ushort *)(lVar15 + 4) | 4;
      if (*(ushort *)(lVar15 + 0x16) != 0) {
        puVar22 = (ushort *)(lVar15 + 0x1ffe);
        plVar17 = plVar23;
        do {
          if ((*puVar22 != 0) &&
             ((bVar2 = *(byte *)((ulonglong)*puVar22 + lVar15), (bVar2 & 1) != 0 ||
              ((bVar2 & 0x20) != 0)))) {
            *(ushort *)(lVar15 + 4) = *(ushort *)(lVar15 + 4) & 0xfffb;
            break;
          }
          uVar25 = (int)plVar17 + 1;
          plVar17 = (longlong *)(ulonglong)uVar25;
          puVar22 = puVar22 + -1;
        } while ((int)uVar25 < (int)(uint)*(ushort *)(lVar15 + 0x16));
      }
    }
    *(longlong *)(param_1 + 0xe28) = *(longlong *)(param_1 + 0xe28) + 1;
    lVar15 = func_0x(param_1 + 0xb50,0);
    *(longlong *)(param_1 + 0xdf0) = lVar15;
    if ((DAT_ != '\0') || ((DAT_ & 0x80) != 0)) {
      plVar17 = *(longlong **)(param_1 + 0xb78);
      if (*plVar17 != lVar15) {
        (*_DAT_)(1,0x147eba0,0x1448af0,0x39b,0);
      }
      LOCK();
      puVar22 = (ushort *)((longlong)plVar17 + 0x62);
      *puVar22 = *puVar22 | 0x800;
      UNLOCK();
    }
    if (*(int *)(param_1 + 0xf98) != 0) {
      *(undefined8 *)(param_1 + 0x1000) = 0;
      *(undefined2 *)(param_1 + 0x1008) = 0;
      *(undefined8 *)(param_1 + 0x100c) = 1;
      puVar5 = *(undefined8 **)(param_1 + 0xfa8);
      *(undefined8 *)(param_1 + 4000) = 0;
      if (puVar5 != (undefined8 *)0x0) {
        puVar6 = (undefined8 *)puVar5[1];
        if (puVar6 != (undefined8 *)0x0) {
          *puVar6 = 0;
          *(undefined4 *)(puVar6 + 0x481) = 0;
        }
        puVar5[3] = 0;
        *(undefined2 *)(puVar5 + 4) = 0;
        *puVar5 = 0;
        *(undefined4 *)(puVar5 + 0x14b) = 0;
      }
    }
    lVar15 = *(longlong *)(param_1 + 0x60);
    if ((*(int *)(lVar15 + 0xc) == 0) && (*(short *)(lVar15 + 0x10) == 0)) {
      lVar7 = *(longlong *)(param_1 + 0xdf0);
      *(undefined4 *)(lVar15 + 0xc) = *(undefined4 *)(lVar7 + 0x20);
      *(undefined2 *)(lVar15 + 0x10) = *(undefined2 *)(lVar7 + 0x24);
      *(undefined2 *)(lVar15 + 0x12) = 0;
      *(undefined4 *)(param_1 + 0x98) = *(undefined4 *)(*(longlong *)(param_1 + 0xdf0) + 0x20);
      *(undefined2 *)(param_1 + 0x9c) = *(undefined2 *)(*(longlong *)(param_1 + 0xdf0) + 0x24);
    }
    lVar15 = *(longlong *)(param_1 + 0xdf0);
    iStack_138 = -1;
    if (lVar15 != 0) {
      uVar19 = 0x2000 - *(int *)(param_1 + 0xb38);
      sVar21 = 1 << ((byte)*(undefined2 *)(lVar15 + 4) & 2);
      uVar25 = (uint)(ushort)(sVar21 + -1 + sVar3 & -sVar21);
      if (uVar25 <= uVar19) {
        uVar25 = uVar19;
      }
      uVar19 = uVar20;
      if (2 < *(ushort *)(lVar15 + 0x1c)) {
        uVar19 = *(ushort *)(lVar15 + 0x1c) - 2;
      }
      if (uVar25 <= uVar19) {
        iStack_138 = func_0x(lVar15,uVar4,sVar3);
        lVar15 = *(longlong *)(param_1 + 0xdf0);
      }
    }
    iVar14 = iStack_138;
    if ((*(int *)(lVar15 + 0x20) != *(int *)(param_1 + 0x98)) ||
       (*(short *)(lVar15 + 0x24) != *(short *)(param_1 + 0x9c))) {
      uVar12 = func_0x(param_1,lVar15,param_1 + 0xdc,0xa58);
      *(undefined4 *)(param_1 + 0xd8) = uVar12;
      lVar15 = param_1 + 0xa0;
      lVar7 = *(longlong *)(param_1 + 0xa8);
      cVar35 = *(short *)(*(longlong *)(param_1 + 0x28) + 0x3c4) != 1;
      if (lVar7 == 0) {
LAB_:
        func_0x(param_1,lVar15,cVar35);
      }
      else {
        iVar13 = func_0x(param_1,lVar7,cVar35,lVar7);
        lVar15 = lVar7;
        while (iVar13 != 0) {
          if (cVar35 == -1) {
            (*_DAT_)(6,0x56,0x10,2,(ulonglong)*(uint6 *)(param_1 + 0x34) << 0x10);
          }
          lVar7 = *(longlong *)(lVar15 + 8);
          cVar35 = cVar35 + '\x01';
          if (lVar7 == 0) goto LAB_;
          iVar13 = func_0x(param_1,lVar7,cVar35,lVar7);
          lVar15 = lVar7;
        }
      }
    }
    plVar17 = (longlong *)(ulonglong)uStack_1b4;
  }
  if (uStack_144 != 0) {
    if (*(int *)(param_1 + 0xf98) != 0) {
      *param_3 = sStack_1b8;
      if (sStack_1b8 != 0) {
        if ((uStack_1a8 == (longlong *)0x0) || (*uStack_1a8 == 0)) {
          func_0x(param_3 + 1,uStack_118,param_6,&uStack_1b6);
          plVar17 = uStack_1a8;
          if (sStack_1b8 == 0) {
            plVar17 = plVar23;
          }
          *(longlong **)(param_3 + 8) = plVar17;
        }
        else {
          func_0x(param_3,uStack_118,param_6,&sStack_1b8);
        }
        goto LAB_;
      }
      puVar22 = (ushort *)(param_3 + 1);
      pbVar26 = pbStack_1b0;
      puStack_130 = puVar22;
      if ((int)plVar17 == 0) {
        plVar17 = (longlong *)((ulonglong)uStack_1a8 & 0xffffffff);
        uStack_1b6 = 0;
        uVar25 = (uint)uStack_1a8;
        if ((*pbStack_1b0 & 0x10) != 0) {
          uVar25 = (uint)uStack_1a8 + 2 +
                   (*(ushort *)((longlong)plVar17 + (longlong)pbStack_1b0) + 7 >> 3);
          plVar17 = (longlong *)(ulonglong)uVar25;
        }
        uStack_1a8 = (longlong *)CONCAT44(uVar25,(uint)uStack_1a8);
        uStack_1a0 = (uint)plVar17;
        if ((*pbStack_1b0 & 0x20) == 0) {
          uStack_19c = 0;
          uStack_1b4 = uStack_1a0;
        }
        else {
          puVar29 = (ushort *)((longlong)plVar17 + (longlong)pbStack_1b0);
          uStack_19c = *puVar29;
          if (uStack_19c == 0) {
            cVar35 = func_0x(0x19d3ae0);
            if (((cVar35 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
               (*(char *)(lVar15 + 0x499) != '\0')) {
              cVar35 = func_0x(0x19d3ae0);
              if (cVar35 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0x12c34ec,0x13e35d8,0x80f,0);
              }
            }
            func_0x(pbStack_1b0,3);
          }
          uStack_1a0 = uStack_1a8._4_4_ + (uStack_19c + 1) * 2;
          if (0x1f9e < uStack_1a0) {
            cVar35 = func_0x(0x19d3ae0);
            if (((cVar35 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
               (*(char *)(lVar15 + 0x499) != '\0')) {
              cVar35 = func_0x(0x19d3ae0);
              if (cVar35 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x12c34ec,0x13e35d8,0x816,0);
              }
            }
            func_0x(pbStack_1b0,4);
          }
          uStack_1b4 = puVar29[uStack_19c] & 0x7fff;
          if (uStack_1b4 < uStack_1a0) {
            cVar35 = func_0x(0x19d3ae0);
            if (((cVar35 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
               (*(char *)(lVar15 + 0x499) != '\0')) {
              cVar35 = func_0x(0x19d3ae0);
              if (cVar35 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x12c34ec,0x13e35d8,0x81d,0);
              }
            }
            func_0x(pbStack_1b0,4);
          }
          plVar17 = (longlong *)(ulonglong)uStack_1b4;
          pbVar26 = pbStack_1b0;
          plVar33 = plVar23;
          uVar25 = uStack_1a0;
          puVar8 = puVar29;
          if (uStack_19c != 0) {
            do {
              uVar19 = puVar8[1] & 0x7fff;
              if ((uVar19 < uVar25) || ((uint)plVar17 < uVar19)) {
                cVar35 = func_0x(0x19d3ae0);
                if ((cVar35 != '\0') &&
                   ((lVar15 = func_0x(), lVar15 != 0 &&
                    (*(char *)(lVar15 + 0x499) != '\0')))) {
                  cVar35 = func_0x(0x19d3ae0);
                  if (cVar35 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    (*_DAT_)(1,0x12c34ec,0x13e35d8,0x82a,0);
                  }
                }
                func_0x(pbStack_1b0,4);
                plVar17 = (longlong *)(ulonglong)uStack_1b4;
                pbVar26 = pbStack_1b0;
              }
              uVar32 = (int)plVar33 + 1;
              plVar33 = (longlong *)(ulonglong)uVar32;
              uVar25 = uVar19;
              puVar8 = puVar8 + 1;
              puVar22 = puStack_130;
            } while ((int)uVar32 < (int)(uint)uStack_19c);
          }
          while ((short)puVar29[(ulonglong)(uStack_19c - 1) + 1] < 0) {
            uVar25 = uStack_1a0;
            if (uStack_19c != 1) {
              uVar25 = *(ushort *)
                        (pbVar26 + (ulonglong)uStack_19c * 2 + (((ulonglong)uStack_1a8 >> 0x20) - 2)
                        ) & 0x7fff;
            }
            uVar19 = *(ushort *)
                      (pbVar26 + (ulonglong)uStack_19c * 2 + ((ulonglong)uStack_1a8 >> 0x20)) &
                     0x7fff;
            if (((uVar25 < uStack_1a0) || (uVar19 < uVar25)) || ((uint)plVar17 < uVar19)) {
              func_0x(pbVar26,7);
              plVar17 = (longlong *)(ulonglong)uStack_1b4;
              pbVar26 = pbStack_1b0;
            }
            if ((uVar25 < uStack_1a0) || ((uint)plVar17 < uVar25)) goto LAB_;
            if (*(ushort *)(pbVar26 + uVar25) == 5) {
              uStack_19c = uStack_19c - 1;
              uStack_1b6 = uStack_1b6 | 2;
              uVar31 = (ulonglong)(uVar25 & 0xffff);
              pbVar1 = pbVar26 + uVar31;
              uStack_18e = (ushort)uVar25;
              if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
                uVar10 = uStack_18c & 0xc7ff;
              }
              else {
                uVar10 = uStack_18c ^ (*(ushort *)(pbVar1 + 2) ^ uStack_18c) & 0x3800;
              }
              uStack_18c = (uVar10 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar10;
              lVar15 = uVar31 + (ulonglong)((uStack_18c & 0x7ff) * 2) + 4 +
                                (ulonglong)((uVar10 >> 0xb & 7) * 2);
              pbVar27 = pbVar26;
              if (pbVar26 + lVar15 < pbVar1) {
                func_0x(pbVar1,0x19);
                uVar31 = (ulonglong)uStack_18e;
                plVar17 = (longlong *)(ulonglong)uStack_1b4;
                pbVar27 = pbStack_1b0;
              }
              if (uVar19 - uVar25 <
                  (((uStack_18c & 0x7ff) * 2 - (int)uVar31) - (int)pbStack_1b0) +
                  (int)(pbVar26 + lVar15)) {
                func_0x(pbVar27 + uVar31,0x19);
                uVar31 = (ulonglong)uStack_18e;
                plVar17 = (longlong *)(ulonglong)uStack_1b4;
                pbVar27 = pbStack_1b0;
              }
              pbVar26 = pbVar27;
              if (((uStack_18c & 0x3800) != 0) &&
                 (puVar29 = (ushort *)(pbVar27 + uVar31 + 4), plVar33 = plVar23, uVar10 = uStack_18c
                 , (uStack_18c & 0x3800) != 0)) {
                do {
                  if ((uVar10 & 0x7ff) < (*puVar29 & 0x7ff)) {
                    func_0x(pbVar27 + uVar31,0x1a);
                    uVar31 = (ulonglong)uStack_18e;
                    pbVar27 = pbStack_1b0;
                    uVar10 = uStack_18c;
                  }
                  uVar25 = (int)plVar33 + 1;
                  puVar29 = puVar29 + 1;
                  plVar33 = (longlong *)(ulonglong)uVar25;
                } while ((int)uVar25 < (int)((uStack_18c & 0x3800) >> 0xb));
                plVar17 = (longlong *)(ulonglong)uStack_1b4;
                pbVar26 = pbVar27;
              }
              break;
            }
            if (*(ushort *)(pbVar26 + uVar25) < 0x400) break;
            uStack_1b6 = uStack_1b6 | 1;
            uStack_19c = uStack_19c - 1;
            if (uStack_19c == 0) break;
          }
        }
        if ((*pbVar26 & 0x40) == 0) {
          uStack_192 = 0;
          uStack_190 = 0;
        }
        else {
          uStack_192 = SUB82(plVar17,0);
          uStack_190 = (undefined2)((ulonglong)plVar17 >> 0x10);
          uStack_1b4 = (int)plVar17 + 0xe;
          puVar16 = (ulonglong *)func_0x(&uStack_1b6);
          uVar11 = (ushort)(*puVar16 >> 0x30);
          uVar10 = uVar11;
          if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
            uVar10 = uVar11 & 0xdfff;
            if ((uVar11 >> 0xe & 1) != 0) {
              uVar10 = uVar11 | 0x2000;
            }
          }
          if (uVar10 == 0xfffc) {
            uVar20 = (uint)((*puVar16 >> 0x20 & 0xffff) >> 5);
          }
          uStack_1b4 = uStack_1b4 + uVar20;
          plVar17 = (longlong *)(ulonglong)uStack_1b4;
          pbVar26 = pbStack_1b0;
        }
        if ((pbStack_19a != (byte *)0x0) &&
           (pbStack_19a < (byte *)((longlong)plVar17 + (longlong)pbVar26))) {
          cVar35 = func_0x(0x19d3ae0);
          if ((cVar35 != '\0') &&
             ((lVar15 = func_0x(), lVar15 != 0 &&
              (*(char *)(lVar15 + 0x499) != '\0')))) {
            cVar35 = func_0x(0x19d3ae0);
            if (cVar35 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              (*_DAT_)(1,0x12c34ec,0x13e35d8,0x886,0);
            }
          }
          func_0x(pbStack_1b0,0x12);
          plVar17 = (longlong *)(ulonglong)uStack_1b4;
          pbVar26 = pbStack_1b0;
        }
        if (0x3f3b < (int)plVar17 - 1U) {
          cVar35 = func_0x(0x19d3ae0);
          if (((cVar35 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
             (*(char *)(lVar15 + 0x499) != '\0')) {
            cVar35 = func_0x(0x19d3ae0);
            if (cVar35 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              (*_DAT_)(1,0x12c34ec,0x13e35d8,0x88b,0);
            }
          }
          func_0x(pbStack_1b0,5);
          plVar17 = (longlong *)(ulonglong)uStack_1b4;
          pbVar26 = pbStack_1b0;
        }
      }
LAB_:
      uVar4 = uStack_118;
      uVar20 = (uint)plVar17;
      if ((8 < uVar20) || (((*pbVar26 & 0xe) != 0 && ((*pbVar26 & 0xe) != 0xc)))) {
        uStack_120 = uVar20;
      }
      *(uint *)(puVar22 + 7) = (uint)uStack_1a8;
      *puVar22 = uStack_1b6;
      puVar22[0xd] = uStack_19c;
      *(int *)(puVar22 + 9) = uStack_1a8._4_4_;
      *(uint *)(puVar22 + 0xb) = uStack_1a0;
      *(uint *)(puVar22 + 1) = uVar20;
      *(uint *)(puVar22 + 0x12) = CONCAT22(uStack_190,uStack_192);
      func_0x(uStack_118,param_6,pbVar26,uStack_120);
      *(undefined8 *)(puVar22 + 3) = uVar4;
      iVar14 = func_0x(puVar22);
      if (iVar14 == 0) goto LAB_;
      puVar29 = (ushort *)((ulonglong)*(uint *)(puVar22 + 9) + *(longlong *)(puVar22 + 3));
      uVar20 = *puVar29 - 1;
      if ((*(byte *)puVar22 & 1) == 0) {
        uVar20 = (uint)*puVar29;
      }
      uVar25 = puVar29[(int)uVar20] & 0x7fff;
      if (uVar20 == 1) {
        uVar20 = *(uint *)(puVar22 + 0xb);
LAB_:
        if ((uVar25 < uVar20) || (*(uint *)(puVar22 + 1) < uVar25)) goto LAB_;
      }
      else {
        uVar20 = puVar29[(longlong)(int)uVar20 + -1] & 0x7fff;
        if (*(uint *)(puVar22 + 0xb) <= uVar20) goto LAB_;
LAB_:
        func_0x(*(longlong *)(puVar22 + 3),7);
      }
      uVar34 = *(ulonglong *)(puVar22 + 3);
      uVar28 = (ulonglong)(uVar20 & 0xffff);
      uVar10 = puVar22[0x15] & 0xc7ff;
      uVar31 = uVar28 + uVar34;
      puVar22[0x14] = (ushort)uVar20;
      if ((*(ushort *)(uVar31 + 2) >> 0xe & 1) != 0) {
        uVar10 = *(ushort *)(uVar31 + 2) & 0x3800 | uVar10;
      }
      puVar22[0x15] = uVar10;
      uVar11 = (uVar10 ^ *(ushort *)(uVar31 + 2)) & 0x7ff ^ uVar10;
      puVar22[0x15] = uVar11;
      uVar30 = (ulonglong)((uVar11 & 0x7ff) * 2) + 4 + uVar34 + (uVar10 >> 0xb & 7) * 2 + uVar28;
      if (uVar30 < uVar31) {
        func_0x(uVar31,0x19);
        uVar11 = puVar22[0x15];
        uVar28 = (ulonglong)puVar22[0x14];
        uVar34 = (ulonglong)*(uint *)(puVar22 + 3);
      }
      if (uVar25 - uVar20 < (((uVar11 & 0x7ff) * 2 - (int)uVar28) - (int)uVar34) + (int)uVar30) {
        func_0x(uVar28 + *(longlong *)(puVar22 + 3),0x19);
        uVar11 = puVar22[0x15];
      }
      if (((uVar11 & 0x3800) != 0) &&
         (puVar29 = (ushort *)(*(longlong *)(puVar22 + 3) + 4 + (ulonglong)puVar22[0x14]),
         (uVar11 & 0x3800) != 0)) {
        do {
          if ((uVar11 & 0x7ff) < (*puVar29 & 0x7ff)) {
            func_0x((ulonglong)puVar22[0x14] + *(longlong *)(puVar22 + 3),0x1a);
            uVar11 = puVar22[0x15];
          }
          uVar20 = (int)plVar23 + 1;
          plVar23 = (longlong *)(ulonglong)uVar20;
          puVar29 = puVar29 + 1;
        } while ((int)uVar20 < (int)(uVar11 >> 0xb & 7));
      }
LAB_:
      plVar23 = *(longlong **)(lStack_110 + 0x68);
      if (plVar23 != (longlong *)0x0) {
        *plVar23 = *plVar23 + 1;
      }
      func_0x(uStack_40 ^ (ulonglong)&sStack_1b8);
      return;
    }
    lVar15 = *(longlong *)(param_1 + 0xdf0);
    uStack_f0 = 0xffff;
    pbStack_e8 = (byte *)0x0;
    uStack_ec = 0;
    uStack_d2 = 0;
    uStack_c8 = 0;
    uStack_c6 = 0;
    uStack_e0 = 0;
    iStack_bc = iVar14;
    if (-1 < *(char *)(lVar15 + 2)) goto LAB_;
    pbVar26 = (byte *)(lVar15 + 0x60);
    stack0xffffffffffffff5a = SUB1614(ZEXT816(0),2);
    auStack_a8._0_2_ = 0xffff;
    uStack_90 = 0;
    uStack_82 = 0;
    uStack_a0 = 0;
    uStack_78 = 0;
    uStack_8a = 0;
    uStack_88 = 0;
    uStack_80 = 0;
    uStack_7e = 0;
    uStack_98 = 0;
    psStack_70 = (short *)0x0;
    _auStack_58 = ZEXT812(0);
    auStack_4e._2_4_ = 0;
    uStack_48 = 0;
    psStack_68 = (short *)0x0;
    sStack_60 = 0;
    uStack_5e = 0;
    auStack_b8 = ZEXT816(0);
    lVar7 = 0;
    if (*(short *)(lVar15 + 0x24) == 0) {
LAB_:
      auStack_b8._8_8_ = lVar7;
      puStack_130 = *(ushort **)(lVar15 + 0x28);
      uStack_128 = *(undefined2 *)(lVar15 + 0x30);
    }
    else {
      cVar35 = *(char *)(lVar15 + 1);
      if (cVar35 == '\v') {
        if (*(int *)(lVar15 + 0x18) != 99) {
LAB_:
          if (cVar35 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar35 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar15 + 0x18) != 99) goto LAB_;
      }
      uStack_144 = *(undefined4 *)(lVar15 + 0x20);
      uStack_140 = *(undefined2 *)(lVar15 + 0x24);
      cVar35 = func_0x(&uStack_144);
      lVar7 = auStack_b8._8_8_;
      if (cVar35 == '\0') goto LAB_;
      func_0x(lVar15,&puStack_130);
    }
    auStack_b8._0_8_ = pbVar26;
    auStack_58._8_2_ = uStack_128;
    auStack_58._0_8_ = puStack_130;
    auStack_4e._2_4_ = *(undefined4 *)(lVar15 + 0x20);
    auStack_a8._0_2_ = 0xffff;
    auStack_a8 = (undefined  [8])((ulonglong)auStack_a8 & 0xffffffff);
    uStack_a0 = 0;
    uStack_8a = 0;
    uStack_88 = 0;
    uStack_144 = *(int *)((ulonglong)*pbVar26 * 6 + 0x10bd330);
    uVar31 = (ulonglong)*(short *)((ulonglong)*pbVar26 * 6 + 0x10bd334);
    uStack_80 = 0;
    uStack_7e = 0;
    uStack_98 = 0;
    psStack_70 = (short *)0x0;
    psStack_68 = (short *)0x0;
    sStack_60 = 0;
    if ((*pbVar26 & 2) != 0) {
      pbVar1 = pbVar26 + uVar31;
      uStack_a0 = pbVar1;
      if ((pbVar26[uVar31] & 1) == 0) {
        auVar9._14_2_ = 0;
        auVar9._0_14_ = stack0xffffffffffffff5a;
        _auStack_a8 = auVar9 << 0x10;
        uStack_82 = 0;
        uStack_80 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101d7d */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x103c4c) - 0x14dbae0))
                  ();
        return;
      }
      auStack_a8._0_2_ = 1;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x103c2c) * 4 +
                             0x103c1c) - 0x14dbae0);
                    /* WARNING: Could not emulate address calculation at 0x00101bcc */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
    if ((*pbVar26 & 4) != 0) {
      uStack_144._2_2_ = (short)((uint)uStack_144 >> 0x10);
      if (uStack_144._2_2_ != 0) {
        uVar31 = (ulonglong)*(ushort *)(lVar15 + 0x61 + (longlong)uStack_144._2_2_ * 2);
      }
      psStack_70 = (short *)(pbVar26 + uVar31);
      psStack_68 = psStack_70 + 1;
      sStack_60 = (*psStack_70 + 1) * 2;
    }
    if (auStack_b8._8_8_ != 0) {
      func_0x(auStack_b8._8_8_,auStack_b8);
    }
LAB_:
    pbStack_e8 = (byte *)((ulonglong)*(ushort *)(lVar15 + (0xfff - (longlong)iStack_138) * 2) +
                         lVar15);
    if ((*pbStack_e8 & 1) == 0) {
      uStack_f0 = 0;
      uStack_ec = 0;
      uStack_ca = 0;
      uStack_c8 = 0;
      uStack_148 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010206b */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_e8 & 0xe) * 4 + 0x103cb8) - 0x14dbae0
                ))();
      return;
    }
    uStack_f0 = 1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_e8 & 0x1c) + 0x103c98) * 4
                           + 0x103c88) - 0x14dbae0);
                    /* WARNING: Could not emulate address calculation at 0x00101e9c */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  lVar15 = *(longlong *)(param_1 + 0xdf0);
  *(int *)(param_3 + 0x1a) = iVar14;
  if (-1 < *(char *)(lVar15 + 2)) goto LAB_;
  pbVar26 = (byte *)(lVar15 + 0x60);
  if ((*param_3 == 0) || (ppbVar24 = *(byte ***)(param_3 + 8), ppbVar24 == (byte **)0x0)) {
    ppbVar24 = (byte **)(param_3 + 0x1c);
    *(undefined (*) [16])(param_3 + 0x20) = ZEXT816(0);
    *(undefined (*) [16])(param_3 + 0x28) = ZEXT816(0);
    *(undefined (*) [16])(param_3 + 0x30) = ZEXT816(0);
    *(undefined (*) [16])(param_3 + 0x38) = ZEXT816(0);
    *(undefined (*) [16])(param_3 + 0x40) = ZEXT816(0);
    *(undefined (*) [16])(param_3 + 0x48) = ZEXT816(0);
    *(undefined (*) [16])(param_3 + 0x50) = ZEXT816(0);
    *ppbVar24 = (byte *)0x0;
    *(undefined8 *)(param_3 + 0x20) = 0;
    param_3[0x24] = -1;
    *(undefined8 *)(param_3 + 0x28) = 0;
    *(undefined4 *)(param_3 + 0x26) = 0;
    *(undefined8 *)(param_3 + 0x33) = 0;
    *(undefined8 *)(param_3 + 0x38) = 0;
    *(undefined8 *)(param_3 + 0x2c) = 0;
    *(undefined8 *)(param_3 + 0x40) = 0;
    *(undefined8 *)(param_3 + 0x4c) = 0;
    *(undefined4 *)(param_3 + 0x50) = 0;
    param_3[0x55] = 0;
  }
  if (*(short *)(lVar15 + 0x24) == 0) {
LAB_:
    puStack_130 = *(ushort **)(lVar15 + 0x28);
    uStack_128 = *(undefined2 *)(lVar15 + 0x30);
  }
  else {
    cVar35 = *(char *)(lVar15 + 1);
    if (cVar35 == '\v') {
      if (*(int *)(lVar15 + 0x18) != 99) {
LAB_:
        if (cVar35 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar35 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar15 + 0x18) != 99) goto LAB_;
    }
    uStack_144 = *(undefined4 *)(lVar15 + 0x20);
    uStack_140 = *(undefined2 *)(lVar15 + 0x24);
    cVar35 = func_0x(&uStack_144);
    if (cVar35 == '\0') goto LAB_;
    func_0x(lVar15,&puStack_130);
  }
  *ppbVar24 = pbVar26;
  *(undefined4 *)(ppbVar24 + 0xc) = puStack_130._0_4_;
  *(undefined2 *)(ppbVar24 + 0xd) = uStack_128;
  *(int *)((longlong)ppbVar24 + 100) = (int)((ulonglong)puStack_130 >> 0x20);
  *(undefined4 *)((longlong)ppbVar24 + 0x6c) = *(undefined4 *)(lVar15 + 0x20);
  *(undefined2 *)(ppbVar24 + 0xe) = *(undefined2 *)(lVar15 + 0x24);
  *(undefined2 *)((longlong)ppbVar24 + 0x72) = 0;
  uStack_144 = *(int *)((ulonglong)*pbVar26 * 6 + 0x10bd330);
  uVar31 = (ulonglong)*(short *)((ulonglong)*pbVar26 * 6 + 0x10bd334);
  *(undefined2 *)(ppbVar24 + 2) = 0xffff;
  ppbVar24[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
  ppbVar24[7] = (byte *)0x0;
  ppbVar24[4] = (byte *)0x0;
  ppbVar24[9] = (byte *)0x0;
  ppbVar24[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar24 + 0xb) = 0;
  if ((**ppbVar24 & 2) != 0) {
    pbVar1 = pbVar26 + uVar31;
    if ((pbVar26[uVar31] & 1) == 0) {
      *(undefined2 *)(ppbVar24 + 2) = 0;
      ppbVar24[3] = pbVar1;
      *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbVar24 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001037d7 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x103d24) - 0x14dbae0))()
      ;
      return;
    }
    *(undefined2 *)(ppbVar24 + 2) = 1;
    ppbVar24[3] = pbVar1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x103d04) * 4 +
                           0x103cf4) - 0x14dbae0);
                    /* WARNING: Could not emulate address calculation at 0x00103657 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbVar24 & 4) != 0) {
    uStack_144._2_2_ = (short)((uint)uStack_144 >> 0x10);
    if (uStack_144._2_2_ != 0) {
      uVar31 = (ulonglong)*(ushort *)(lVar15 + 0x61 + (longlong)uStack_144._2_2_ * 2);
    }
    psVar18 = (short *)(pbVar26 + uVar31);
    ppbVar24[9] = (byte *)psVar18;
    sVar3 = *psVar18;
    ppbVar24[10] = (byte *)(psVar18 + 1);
    *(short *)(ppbVar24 + 0xb) = (sVar3 + 1) * 2;
  }
  if (ppbVar24[1] != (byte *)0x0) {
    func_0x(ppbVar24[1],ppbVar24);
  }
LAB_:
  pbVar26 = (byte *)((ulonglong)*(ushort *)(lVar15 + (0xfff - (longlong)iStack_138) * 2) + lVar15);
  if ((*pbVar26 & 1) == 0) {
    *param_3 = 0;
    *(byte **)(param_3 + 4) = pbVar26;
    *(undefined4 *)(param_3 + 2) = 0;
    *(undefined4 *)(param_3 + 0x13) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00103a92 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar26 & 0xe) * 4 + 0x103d90) - 0x14dbae0))();
    return;
  }
  *param_3 = 1;
  *(byte **)(param_3 + 4) = pbVar26;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar26 & 0x1c) + 0x103d70) * 4 +
                         0x103d60) - 0x14dbae0);
                    /* WARNING: Could not emulate address calculation at 0x001038d7 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

