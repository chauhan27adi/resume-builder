
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(undefined8 param_1,longlong param_2)

{
  ushort uVar1;
  undefined2 uVar2;
  uint uVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong lVar6;
  char cVar7;
  byte bVar8;
  int iVar9;
  undefined2 *puVar10;
  uint *puVar11;
  undefined8 uVar12;
  ushort *puVar13;
  
  (*_DAT_)(param_2 + 0x290,param_2 + 0x508);
  func_0x(*(undefined8 *)(param_2 + 0x278));
  if (*(longlong *)(param_2 + 200) != 0) {
    puVar13 = (ushort *)(*(longlong *)(param_2 + 200) + 0x62);
    *(ushort **)(param_2 + 0x420) = puVar13;
    uVar1 = *puVar13;
    *(ushort *)(param_2 + 0x1a0) = uVar1;
    if (((uVar1 >> 10 & 1) == 0) || (*(short *)(param_2 + 0xd4) < 3)) {
      *(int *)(param_2 + 0x80) = (int)*(short *)(param_2 + 0xd4);
      *(undefined8 *)(param_2 + 0x128) = *(undefined8 *)(param_2 + 200);
      *(ushort **)(param_2 + 0x428) = puVar13;
      uVar1 = *puVar13;
      *(ushort *)(param_2 + 0x148) = uVar1;
      if (((byte)uVar1 >> 3 & 1) != 0) {
        if (*(int *)(param_2 + 0x80) == 3) {
          *(undefined4 *)(param_2 + 0x80) = 4;
        }
        else if (*(int *)(param_2 + 0x80) < 2) goto LAB_;
        puVar11 = (uint *)(*(longlong *)(param_2 + 200) + 100);
        *(uint **)(param_2 + 0x430) = puVar11;
        uVar3 = *puVar11;
        *(uint *)(param_2 + 0x218) = uVar3;
        if ((((uVar3 & 8) != 0) &&
            (lVar6 = *(longlong *)(*(longlong *)(param_2 + 200) + 0x90), lVar6 != 0)) &&
           (*(longlong *)(param_2 + 0x438) = lVar6, *(longlong *)(lVar6 + 0x758) != 0)) {
          func_0x
                    (*(undefined8 *)(lVar6 + 0x758),*(undefined8 *)(param_2 + 200),
                     *(undefined4 *)(param_2 + 0x80));
        }
      }
LAB_:
      *(undefined4 *)(param_2 + 0x220) = 0x32f;
      cVar7 = DAT_ >> 7;
      *(char *)(param_2 + 0x120) = -cVar7;
      if (-cVar7 != '\0') {
        puVar11 = (uint *)(*(longlong *)(param_2 + 0x128) + 100);
        *(uint **)(param_2 + 0x440) = puVar11;
        uVar3 = *puVar11;
        *(uint *)(param_2 + 0x228) = uVar3;
        if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0x80))) {
          *(uint **)(param_2 + 0x448) = puVar11;
          uVar3 = *puVar11;
          *(uint *)(param_2 + 0x230) = uVar3;
          if (((uVar3 & 0xc0000000) != 0x40000000) &&
             (lVar6 = **(longlong **)(param_2 + 0x128), lVar6 != 0)) {
            *(undefined4 *)(param_2 + 0x238) = 2;
            iVar9 = (*_DAT_)(lVar6,0x2000,2,param_2 + 0x23c);
            if (iVar9 != 0) {
              LOCK();
              *puVar11 = *puVar11 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar11 = *puVar11 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar6 = *(longlong *)(param_2 + 0x128);
      uVar4 = *(undefined4 *)(param_2 + 0x80);
      func_0x(lVar6 + 0x98,uVar4);
      if (_DAT_ != 0) {
        *(undefined4 *)(param_2 + 0x240) = 0xe79;
        bVar8 = DAT_ >> 1;
        *(byte *)(param_2 + 0xfd) = bVar8;
        if ((bVar8 & 1) != 0) {
          func_0x(lVar6,0,uVar4);
        }
      }
      *(uint *)(param_2 + 0xd4) = *(uint *)(param_2 + 0xd4) & 0xffff0000;
      *(undefined8 *)(param_2 + 200) = 0;
    }
    else {
      func_0x(param_2 + 200);
    }
  }
  plVar5 = *(longlong **)(param_2 + 0x280);
  if (*plVar5 == 0) goto LAB_;
  puVar13 = (ushort *)(*plVar5 + 0x62);
  *(ushort **)(param_2 + 0x450) = puVar13;
  uVar1 = *puVar13;
  *(ushort *)(param_2 + 0x140) = uVar1;
  if (((uVar1 >> 10 & 1) != 0) && (2 < *(short *)((longlong)plVar5 + 0xc))) {
    func_0x(plVar5);
    goto LAB_;
  }
  *(int *)(param_2 + 0x78) = (int)*(short *)((longlong)plVar5 + 0xc);
  lVar6 = *plVar5;
  *(longlong *)(param_2 + 0xe8) = lVar6;
  puVar10 = (undefined2 *)(lVar6 + 0x62);
  *(undefined2 **)(param_2 + 0x458) = puVar10;
  uVar2 = *puVar10;
  *(undefined2 *)(param_2 + 0x138) = uVar2;
  if (((byte)uVar2 >> 3 & 1) != 0) {
    if (*(int *)(param_2 + 0x78) == 3) {
      *(undefined4 *)(param_2 + 0x78) = 4;
    }
    else if (*(int *)(param_2 + 0x78) < 2) goto LAB_;
    puVar11 = (uint *)(*(longlong *)(param_2 + 0xe8) + 100);
    *(uint **)(param_2 + 0x460) = puVar11;
    uVar3 = *puVar11;
    *(uint *)(param_2 + 0x248) = uVar3;
    if ((((uVar3 & 8) != 0) &&
        (lVar6 = *(longlong *)(*(longlong *)(param_2 + 0xe8) + 0x90), lVar6 != 0)) &&
       (*(longlong *)(param_2 + 0x468) = lVar6, *(longlong *)(lVar6 + 0x758) != 0)) {
      func_0x
                (*(undefined8 *)(lVar6 + 0x758),*(undefined8 *)(param_2 + 0xe8),
                 *(undefined4 *)(param_2 + 0x78));
    }
  }
LAB_:
  cVar7 = DAT_ >> 7;
  *(char *)(param_2 + 0xfe) = -cVar7;
  if (-cVar7 != '\0') {
    puVar11 = (uint *)(*(longlong *)(param_2 + 0xe8) + 100);
    *(uint **)(param_2 + 0x470) = puVar11;
    uVar3 = *puVar11;
    *(uint *)(param_2 + 0x250) = uVar3;
    if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0x78))) {
      *(uint **)(param_2 + 0x478) = puVar11;
      uVar3 = *puVar11;
      *(uint *)(param_2 + 600) = uVar3;
      if (((uVar3 & 0xc0000000) != 0x40000000) && (**(longlong **)(param_2 + 0xe8) != 0)) {
        iVar9 = (*_DAT_)(**(longlong **)(param_2 + 0xe8),0x2000,2,param_2 + 0x260);
        if (iVar9 != 0) {
          LOCK();
          *puVar11 = *puVar11 & 0x3fffffff;
          UNLOCK();
          LOCK();
          *puVar11 = *puVar11 | 0x40000000;
          UNLOCK();
        }
      }
    }
  }
  lVar6 = *(longlong *)(param_2 + 0xe8);
  uVar4 = *(undefined4 *)(param_2 + 0x78);
  func_0x(lVar6 + 0x98,uVar4);
  if ((_DAT_ != 0) && ((DAT_ >> 1 & 1) != 0)) {
    func_0x(lVar6,0,uVar4);
  }
  *(uint *)((longlong)plVar5 + 0xc) = *(uint *)((longlong)plVar5 + 0xc) & 0xffff0000;
  *plVar5 = 0;
LAB_:
  uVar12 = (*_DAT_)(param_2 + 0x290);
  (*_DAT_)(uVar12);
  (*_DAT_)(param_2 + 0x290);
  return 0xfffffffffdf8a2ff;
}

