
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong **param_3,undefined8 param_4)

{
  longlong *plVar1;
  byte *pbVar2;
  longlong lVar3;
  int iVar4;
  byte **ppbVar5;
  undefined8 uVar6;
  ulonglong uVar7;
  longlong lVar8;
  code *UNRECOVERED_JUMPTABLE_00;
  undefined4 *puVar9;
  longlong lVar10;
  uint uVar11;
  longlong unaff_GS_OFFSET;
  undefined auStack_1c8 [32];
  undefined4 *puStack_1a8;
  undefined4 uStack_1a0;
  short sStack_184;
  undefined4 uStack_180;
  undefined2 uStack_17c;
  int *piStack_168;
  undefined4 uStack_160;
  ushort *puStack_158;
  longlong **pplStack_150;
  longlong lStack_148;
  undefined8 uStack_140;
  undefined8 uStack_128;
  undefined2 uStack_120;
  undefined4 uStack_11c;
  byte *pbStack_118;
  undefined8 uStack_110;
  undefined8 uStack_102;
  undefined2 uStack_fa;
  undefined2 uStack_f8;
  undefined6 uStack_f6;
  int iStack_ec;
  undefined auStack_e8 [16];
  undefined auStack_d8 [16];
  undefined auStack_c8 [16];
  undefined auStack_b8 [16];
  undefined auStack_a8 [16];
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined8 uStack_78;
  undefined auStack_70 [24];
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_1c8;
  pplStack_150 = param_3;
  lStack_148 = param_1;
  uStack_140 = param_2;
  uStack_128 = param_4;
  iVar4 = func_0x();
  uVar11 = 0;
  if (iVar4 == 0) {
    puStack_1a8 = (undefined4 *)0x0;
    (*_DAT_)(1,0x1b5d8c8,0x1b33ed8,900);
  }
  if (*(int *)(param_3 + 5) == 0) {
    iStack_ec = *(int *)(param_3 + 3);
    lVar3 = **param_3;
    piStack_168 = (int *)(*(longlong *)(**(longlong **)(param_1 + 8) + 8) + 0x210);
    puStack_158 = (ushort *)(lVar3 + (0xfff - (longlong)iStack_ec) * 2);
    if ((*(byte *)((ulonglong)*puStack_158 + lVar3) & 1) != 0) {
      uStack_120 = 0xffff;
      pbStack_118 = (byte *)0x0;
      uStack_11c = 0;
      uStack_102 = 0;
      uStack_f8 = 0;
      uStack_f6 = 0;
      uStack_110 = 0;
      if (*(char *)(lVar3 + 2) < '\0') {
        auStack_e8 = ZEXT816(0);
        uStack_78 = 0;
        auStack_d8 = ZEXT816(0);
        auStack_c8 = ZEXT816(0);
        auStack_b8 = ZEXT816(0);
        auStack_a8 = ZEXT816(0);
        auStack_98 = ZEXT816(0);
        auStack_88 = ZEXT816(0);
        ppbVar5 = (byte **)func_0x(auStack_e8);
        uVar6 = func_0x(lVar3,auStack_70,0,0);
        if ((byte *)(lVar3 + 0x60) == *ppbVar5) {
          func_0x(uVar6,ppbVar5 + 0xc);
        }
        *ppbVar5 = (byte *)(lVar3 + 0x60);
        func_0x(ppbVar5 + 0xc,uVar6);
        func_0x((longlong)ppbVar5 + 0x6c,lVar3 + 0x20);
        lVar8 = lVar3 + 0x60;
        uStack_160 = *(undefined4 *)((ulonglong)*(byte *)(lVar3 + 0x60) * 6 + 0x17a9470);
        sStack_184 = *(short *)((ulonglong)*(byte *)(lVar3 + 0x60) * 6 + 0x17a9474);
        *(undefined2 *)(ppbVar5 + 2) = 0xffff;
        ppbVar5[3] = (byte *)0x0;
        *(undefined4 *)((longlong)ppbVar5 + 0x14) = 0;
        *(undefined8 *)((longlong)ppbVar5 + 0x2e) = 0;
        ppbVar5[7] = (byte *)0x0;
        ppbVar5[4] = (byte *)0x0;
        ppbVar5[9] = (byte *)0x0;
        ppbVar5[10] = (byte *)0x0;
        *(undefined2 *)(ppbVar5 + 0xb) = 0;
        if ((**ppbVar5 & 2) != 0) {
          pbVar2 = (byte *)(sStack_184 + lVar8);
          if ((*(byte *)(lVar8 + sStack_184) & 1) == 0) {
            *(undefined2 *)(ppbVar5 + 2) = 0;
            ppbVar5[3] = pbVar2;
            *(undefined4 *)((longlong)ppbVar5 + 0x14) = 0;
            *(undefined4 *)((longlong)ppbVar5 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001003c5 */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar2 & 0xe) * 4 + 0x1010f8) -
                      0xdef9a0))();
            return;
          }
          *(undefined2 *)(ppbVar5 + 2) = 1;
          ppbVar5[3] = pbVar2;
          UNRECOVERED_JUMPTABLE_00 =
               (code *)((ulonglong)
                        *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar2 & 0x1c) + 0x1010d8) *
                                  4 + 0x1010c8) - 0xdef9a0);
                    /* WARNING: Could not emulate address calculation at 0x00100247 */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
          return;
        }
        if ((**ppbVar5 & 4) != 0) {
          uStack_160._2_2_ = (short)((uint)uStack_160 >> 0x10);
          if (uStack_160._2_2_ == 0) {
            uVar7 = (ulonglong)sStack_184;
          }
          else {
            uVar7 = (ulonglong)*(ushort *)(lVar3 + 0x61 + (longlong)uStack_160._2_2_ * 2);
          }
          func_0x(ppbVar5 + 9,lVar8 + uVar7);
        }
        if (ppbVar5[1] != (byte *)0x0) {
          func_0x(ppbVar5[1],ppbVar5);
        }
      }
      pbStack_118 = (byte *)((ulonglong)*puStack_158 + lVar3);
      if ((*pbStack_118 & 1) == 0) {
        uStack_120 = 0;
        uStack_11c = 0;
        uStack_fa = 0;
        uStack_f8 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010061f */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_118 & 0xe) * 4 + 0x101164) -
                  0xdef9a0))
                  (0x172ab90,(longlong)(int)(*pbStack_118 & 0xe),0xffffffffff210660,pbStack_118);
        return;
      }
      uStack_120 = 1;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_118 & 0x1c) + 0x101144)
                              * 4 + 0x101134) - 0xdef9a0);
                    /* WARNING: Could not emulate address calculation at 0x001004d3 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
    puVar9 = (undefined4 *)((byte *)((ulonglong)*puStack_158 + lVar3) + *piStack_168);
    uStack_180 = *puVar9;
    uStack_17c = *(undefined2 *)(puVar9 + 1);
  }
  else {
    uStack_180 = *(undefined4 *)((longlong)param_3 + 0x34);
    uStack_17c = *(undefined2 *)(param_3 + 7);
  }
  func_0x(param_1,param_2,2);
  puStack_1a8 = &uStack_180;
  uStack_1a0 = 2;
  iVar4 = func_0x(param_1,param_2,param_3,uStack_128);
  if ((((iVar4 != 0) &&
       (lVar3 = *(longlong *)(*(longlong *)(**(longlong **)(param_1 + 8) + 8) + 0x488), lVar3 != 0))
      && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
    if (*(longlong *)(lVar3 + 0x20) != 0) {
      lVar10 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar8 = *(longlong *)(lVar10 + 0x100);
      if (lVar8 == 0) {
        (*_DAT_)(0);
        lVar8 = *(longlong *)(lVar10 + 0x100);
      }
      if (*(longlong *)(lVar8 + 0x260) != 0) {
        uVar11 = *(uint *)(*(longlong *)(lVar8 + 0x260) + 0xe68);
      }
      if (uVar11 < *(uint *)(_DAT_ + 8)) {
        lVar3 = *(longlong *)(*(longlong *)(lVar3 + 0x20) + (ulonglong)uVar11 * 8);
        *(longlong *)(lVar3 + 0x30) = *(longlong *)(lVar3 + 0x30) + 1;
        goto LAB_;
      }
    }
    LOCK();
    plVar1 = (longlong *)(*(longlong *)(lVar3 + 0x18) + 0x30);
    *plVar1 = *plVar1 + 1;
    UNLOCK();
  }
LAB_:
  func_0x(uStack_58 ^ (ulonglong)auStack_1c8);
  return;
}

