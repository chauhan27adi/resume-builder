
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_(short *param_1,longlong param_2,uint param_3,int *param_4,uint *param_5)

{
  ushort *puVar1;
  byte bVar2;
  char cVar3;
  ushort uVar4;
  uint uVar5;
  int iVar6;
  uint *puVar7;
  longlong lVar8;
  undefined8 uVar9;
  int *piVar10;
  ulonglong uVar11;
  undefined8 *puVar12;
  longlong lVar13;
  short sVar14;
  ulonglong uVar15;
  byte *pbVar16;
  uint uVar17;
  ulonglong uVar18;
  ulonglong uVar19;
  ushort *puVar20;
  uint uVar21;
  ushort uVar22;
  uint uVar23;
  ushort *puVar24;
  ushort *puStackX_8;
  uint uStackX_18;
  ushort *puStack_58;
  undefined8 uStack_50;
  uint uStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  
  uVar19 = 0;
  puVar1 = (ushort *)(param_1 + 1);
  uVar21 = 0;
  uStack_48 = 0;
  uStack_44 = (uint)(uStack_44._2_2_ & 0xffe0) << 0x10;
  piStack_40 = (int *)0x0;
  *param_5 = 0;
  *param_4 = 0;
  if (*param_1 == 0) {
    uVar5 = func_0x(puVar1);
  }
  else {
    uVar5 = (uint)*puVar1;
  }
  if ((int)uVar5 <= (int)param_3) {
    param_3 = param_3 - uVar5;
    iVar6 = func_0x(param_1);
    if (iVar6 <= (int)param_3) {
      (*_DAT_)(0x19,0,0x19,0);
      return (int *)0x0;
    }
    if (*(int *)(param_1 + 2) == 0) {
      pbVar16 = *(byte **)(param_1 + 4);
      uVar21 = *(uint *)(param_1 + 8);
      uVar15 = (ulonglong)uVar21;
      *puVar1 = 0;
      *(uint *)(param_1 + 10) = uVar21;
      bVar2 = *pbVar16;
      if ((bVar2 & 0x10) != 0) {
        uVar21 = uVar21 + 2 + (*(ushort *)(pbVar16 + uVar15) + 7 >> 3);
        uVar15 = (ulonglong)uVar21;
        *(uint *)(param_1 + 10) = uVar21;
        bVar2 = *pbVar16;
      }
      if ((bVar2 & 0x20) == 0) {
        *(int *)(param_1 + 2) = (int)uVar15;
        param_1[0xe] = 0;
        *(int *)(param_1 + 0xc) = (int)uVar15;
      }
      else {
        puVar24 = (ushort *)(pbVar16 + uVar15);
        uVar22 = *puVar24;
        param_1[0xe] = uVar22;
        puStackX_8 = puVar24;
        if (uVar22 == 0) {
          cVar3 = func_0x(0x145fb40);
          if (((cVar3 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar3 = func_0x(0x145fb40);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0xd4f54c,0xe6f638,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),3);
          uVar22 = param_1[0xe];
          uVar15 = (ulonglong)*(uint *)(param_1 + 10);
        }
        uVar21 = (int)uVar15 + (uVar22 + 1) * 2;
        *(uint *)(param_1 + 0xc) = uVar21;
        if (0x1f9e < uVar21) {
          cVar3 = func_0x(0x145fb40);
          if (((cVar3 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar3 = func_0x(0x145fb40);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xd4f54c,0xe6f638,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar22 = param_1[0xe];
          uVar21 = *(uint *)(param_1 + 0xc);
        }
        uVar15 = (ulonglong)uVar22;
        uVar22 = puVar24[uVar15];
        *(uint *)(param_1 + 2) = uVar22 & 0x7fff;
        if ((uVar22 & 0x7fff) < uVar21) {
          cVar3 = func_0x(0x145fb40);
          if (((cVar3 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar3 = func_0x(0x145fb40);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xd4f54c,0xe6f638,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar21 = *(uint *)(param_1 + 0xc);
          uVar15 = (ulonglong)(ushort)param_1[0xe];
        }
        uStackX_18 = 0;
        uVar11 = uVar19;
        puVar20 = puVar24;
        if ((short)uVar15 != 0) {
          do {
            puVar24 = puVar24 + 1;
            uVar5 = *puVar24 & 0x7fff;
            if ((uVar5 < uVar21) || (uVar21 = (uint)uVar11, *(uint *)(param_1 + 2) < uVar5)) {
              cVar3 = func_0x(0x145fb40);
              if ((cVar3 != '\0') &&
                 ((lVar8 = func_0x(), lVar8 != 0 &&
                  (*(char *)(lVar8 + 0x499) != '\0')))) {
                cVar3 = func_0x(0x145fb40);
                if (cVar3 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0xd4f54c,0xe6f638,0x82a,0);
                }
              }
              func_0x(*(undefined8 *)(param_1 + 4),4);
              uVar21 = uStackX_18;
            }
            uVar15 = (ulonglong)(ushort)param_1[0xe];
            uStackX_18 = uVar21 + 1;
            uVar11 = (ulonglong)uStackX_18;
            puVar20 = puStackX_8;
            uVar21 = uVar5;
          } while ((int)uStackX_18 < (int)(uint)(ushort)param_1[0xe]);
        }
        if ((short)puVar20[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
          pbVar16 = *(byte **)(param_1 + 4);
          do {
            uVar21 = *(ushort *)(pbVar16 + uVar15 * 2 + (ulonglong)*(uint *)(param_1 + 10)) & 0x7fff
            ;
            if ((int)uVar15 == 1) {
              uVar5 = *(uint *)(param_1 + 0xc);
              uVar17 = uVar5;
LAB_:
              if ((uVar21 < uVar5) || (*(uint *)(param_1 + 2) < uVar21)) goto LAB_;
            }
            else {
              uVar17 = *(uint *)(param_1 + 0xc);
              uVar5 = *(ushort *)(pbVar16 + uVar15 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2)) &
                      0x7fff;
              if (uVar17 <= uVar5) goto LAB_;
LAB_:
              func_0x(pbVar16,7);
              uVar17 = *(uint *)(param_1 + 0xc);
            }
            if ((uVar5 < uVar17) || (*(uint *)(param_1 + 2) < uVar5)) goto LAB_;
            pbVar16 = *(byte **)(param_1 + 4);
            if (*(ushort *)(pbVar16 + uVar5) == 5) {
              *puVar1 = *puVar1 | 2;
              param_1[0xe] = param_1[0xe] + -1;
              uVar15 = *(ulonglong *)(param_1 + 4);
              uVar11 = (ulonglong)(uVar5 & 0xffff);
              puStackX_8 = (ushort *)(uVar11 + uVar15);
              param_1[0x15] = (short)uVar5;
              uVar22 = param_1[0x16] & 0xc7ffU;
              if ((puStackX_8[1] & 0x4000) != 0) {
                uVar22 = puStackX_8[1] & 0x3800 | param_1[0x16] & 0xc7ffU;
              }
              param_1[0x16] = uVar22;
              uVar4 = (uVar22 ^ puStackX_8[1]) & 0x7ff ^ uVar22;
              param_1[0x16] = uVar4;
              puStack_58 = (ushort *)
                           (uVar15 + 4 + (ulonglong)((uVar22 >> 0xb & 7) * 2) +
                            (ulonglong)((uVar4 & 0x7ff) * 2) + uVar11);
              if (puStack_58 < puStackX_8) {
                func_0x(puStackX_8,0x19);
                uVar4 = param_1[0x16];
                uVar11 = (ulonglong)(ushort)param_1[0x15];
                uVar15 = (ulonglong)*(uint *)(param_1 + 4);
              }
              if (uVar21 - uVar5 <
                  (((uVar4 & 0x7ff) * 2 - (int)uVar11) - (int)uVar15) + (int)puStack_58) {
                func_0x(uVar11 + *(longlong *)(param_1 + 4),0x19);
                uVar4 = param_1[0x16];
              }
              if (((uVar4 & 0x3800) != 0) &&
                 (puVar24 = (ushort *)
                            (*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]),
                 (uVar4 & 0x3800) != 0)) {
                do {
                  if ((uVar4 & 0x7ff) < (*puVar24 & 0x7ff)) {
                    func_0x((ulonglong)(ushort)param_1[0x15] + *(longlong *)(param_1 + 4),
                                    0x1a);
                    uVar4 = param_1[0x16];
                  }
                  uVar21 = (int)uVar19 + 1;
                  uVar19 = (ulonglong)uVar21;
                  puVar24 = puVar24 + 1;
                } while ((int)uVar21 < (int)(uVar4 >> 0xb & 7));
              }
              goto LAB_;
            }
            if (*(ushort *)(pbVar16 + uVar5) < 0x400) goto LAB_;
            *puVar1 = *puVar1 | 1;
            uVar22 = param_1[0xe] - 1;
            param_1[0xe] = uVar22;
            if (uVar22 == 0) goto LAB_;
            uVar15 = (ulonglong)uVar22;
          } while ((short)puStackX_8[(ulonglong)(uVar22 - 1) + 1] < 0);
          uVar15 = (ulonglong)*(uint *)(param_1 + 2);
        }
        else {
LAB_:
          pbVar16 = *(byte **)(param_1 + 4);
          uVar15 = (ulonglong)*(uint *)(param_1 + 2);
        }
      }
      if ((*pbVar16 & 0x40) == 0) {
        *(undefined4 *)(param_1 + 0x13) = 0;
      }
      else {
        *(int *)(param_1 + 0x13) = (int)uVar15;
        *(int *)(param_1 + 2) = (int)uVar15 + 0xe;
        puVar12 = (undefined8 *)func_0x(puVar1);
        uStack_50 = *puVar12;
        iVar6 = func_0x(&uStack_50);
        *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar6;
        uVar15 = (ulonglong)*(uint *)(param_1 + 2);
      }
      iVar6 = (int)uVar15;
      if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
         (*(ulonglong *)(param_1 + 0xf) < uVar15 + *(longlong *)(param_1 + 4))) {
        cVar3 = func_0x(0x145fb40);
        if ((cVar3 != '\0') &&
           ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0'))))
        {
          cVar3 = func_0x(0x145fb40);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0xd4f54c,0xe6f638,0x886,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),0x12);
        iVar6 = *(int *)(param_1 + 2);
      }
      if (0x3f3b < iVar6 - 1U) {
        cVar3 = func_0x(0x145fb40);
        if (((cVar3 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar3 = func_0x(0x145fb40);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0xd4f54c,0xe6f638,0x88b,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),5);
      }
    }
LAB_:
    iVar6 = func_0x(puVar1);
    if (iVar6 == 0) {
      iVar6 = func_0x(puVar1);
      if (iVar6 != 0) {
        return (int *)0x0;
      }
      (*_DAT_)(1,0xf0b268,0xefc2f8,0xd7a,0);
      return (int *)0x0;
    }
    if ((-1 < (int)param_3) && ((int)param_3 < (int)((ushort)param_1[0x16] & 0x7ff))) {
      lVar8 = *(longlong *)(param_1 + 4);
      uVar22 = param_1[0x15];
      uVar5 = (ushort)param_1[0x16] >> 0xb & 7;
      uVar21 = ((ushort)param_1[0x16] & 0x7ff) * 2;
      lVar13 = (ulonglong)(uVar5 * 2) + lVar8 + (ulonglong)uVar21 + (ulonglong)uVar22;
      if (param_3 == 0) {
        uVar21 = (uVar5 + uVar21) * 2 + 4;
      }
      else {
        uVar21 = *(ushort *)(lVar13 + 2 + (longlong)(int)param_3 * 2) & 0x7fff;
      }
      *param_4 = (*(ushort *)(lVar13 + 4 + (longlong)(int)param_3 * 2) & 0x7fff) - uVar21;
      *param_5 = (uint)(*(ushort *)(lVar13 + 4 + (ulonglong)param_3 * 2) >> 0xf);
      return (int *)((ulonglong)uVar21 + lVar8 + (ulonglong)uVar22);
    }
    (*_DAT_)(1,0xf0b238,0xf0b200,0x41a,0);
    return (int *)0x0;
  }
  uVar5 = ~param_3;
  if ((int)param_3 < 0) {
LAB_:
    func_0x(param_2,uVar5,&uStack_48);
  }
  else {
    if ((uVar5 & 0xc0000000) == 0x80000000) {
      puVar7 = (uint *)func_0x
                                 (**(undefined8 **)(*(longlong *)(param_2 + 8) + 0x160),
                                  uVar5 & 0x1fffffff);
    }
    else {
      puVar7 = (uint *)func_0x(*(undefined8 *)(*(longlong *)(param_2 + 8) + 0x160));
    }
    if (puVar7 == (uint *)0x0) goto LAB_;
    uStack_48 = *puVar7;
    uStack_44 = puVar7[1];
    piStack_40 = *(int **)(puVar7 + 2);
  }
  iVar6 = func_0x(param_1,&uStack_48);
  if (iVar6 == 0) {
    return (int *)0x0;
  }
  *param_5 = 1;
  if (*param_1 != 0) {
    piVar10 = (int *)func_0x(puVar1,&uStack_48);
    if (*param_1 == 0) {
      return piVar10;
    }
    if (*(longlong *)(param_1 + 8) == 0) {
      return piVar10;
    }
    if (**(longlong **)(param_1 + 8) == 0) {
      return piVar10;
    }
    if ((uStack_44 & 0x80000) != 0) {
      return piVar10;
    }
    if (*param_1 != 0) {
      uVar19 = *(ulonglong *)(param_1 + 8);
    }
    if ((piVar10 != (int *)0x0) && (piVar10 != (int *)0xad41e0)) {
      piVar10 = (int *)func_0x(uVar19,&uStack_48,piVar10,*param_4,0,0,param_4,0);
      return piVar10;
    }
    *param_4 = 0;
    return (int *)0x0;
  }
  if ((uStack_48 & 0xc0000000) == 0x80000000) {
    iVar6 = func_0x(puVar1);
    if (iVar6 != 0) {
      piVar10 = (int *)func_0x(param_1 + 0x15,&uStack_48,param_4,&puStackX_8);
      return piVar10;
    }
    *param_4 = 0;
    return (int *)0x0;
  }
  uVar22 = uStack_44._2_2_ >> 4 & 1;
  if (uVar22 != 0) {
    bVar2 = **(byte **)(param_1 + 4);
    if ((bVar2 & 0x10) == 0) {
      if ((1 << (bVar2 & 0xe) & 0x1105U) != 0) {
LAB_:
        *param_4 = *piStack_40;
        return piStack_40 + 1;
      }
    }
    else if (((int)*(uint *)(param_1 + 8) <= (int)uStack_48) ||
            (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) < (ushort)uStack_44))
    goto LAB_;
  }
  if (-1 < (int)uStack_48) {
    if ((uStack_44 & 0x80000) != 0) {
      bVar2 = *(byte *)((longlong)(int)uStack_48 + *(longlong *)(param_1 + 4));
      *param_4 = 1;
      if ((bVar2 & (byte)(1 << (uStack_44._2_1_ & 7))) != 0) {
        return (int *)0xad41e0;
      }
      return (int *)0xad41e1;
    }
    if (uVar22 != 0) {
      bVar2 = **(byte **)(param_1 + 4);
      if ((bVar2 & 0x10) == 0) {
        if ((1 << (bVar2 & 0xe) & 0x1105U) != 0) {
LAB_:
          iVar6 = *piStack_40;
          piVar10 = piStack_40 + 1;
          if (iVar6 != 0x1f9e) {
            (*_DAT_)(1,0xefd990,0xefc2f8,0x381,0);
          }
          *param_4 = iVar6;
          return piVar10;
        }
      }
      else if (((int)*(uint *)(param_1 + 8) <= (int)uStack_48) ||
              (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) < (ushort)uStack_44))
      goto LAB_;
    }
    *param_4 = 0x1f9e;
    return (int *)((longlong)(int)uStack_48 + *(longlong *)(param_1 + 4));
  }
  if (*(int *)(param_1 + 2) == 0) {
    pbVar16 = *(byte **)(param_1 + 4);
    uVar5 = *(uint *)(param_1 + 8);
    uVar15 = (ulonglong)uVar5;
    *puVar1 = 0;
    *(uint *)(param_1 + 10) = uVar5;
    bVar2 = *pbVar16;
    if ((bVar2 & 0x10) != 0) {
      uVar5 = uVar5 + 2 + (*(ushort *)(pbVar16 + uVar15) + 7 >> 3);
      uVar15 = (ulonglong)uVar5;
      *(uint *)(param_1 + 10) = uVar5;
      bVar2 = *pbVar16;
    }
    if ((bVar2 & 0x20) == 0) {
      *(int *)(param_1 + 2) = (int)uVar15;
      param_1[0xe] = 0;
      *(int *)(param_1 + 0xc) = (int)uVar15;
    }
    else {
      puVar24 = (ushort *)(pbVar16 + uVar15);
      uVar22 = *puVar24;
      param_1[0xe] = uVar22;
      if (uVar22 == 0) {
        cVar3 = func_0x(0x145fb40);
        if (((cVar3 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar3 = func_0x(0x145fb40);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0xd4f54c,0xe6f638,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),3);
        uVar22 = param_1[0xe];
        uVar15 = (ulonglong)*(uint *)(param_1 + 10);
      }
      uVar5 = (int)uVar15 + (uint)uVar22 * 2 + 2;
      *(uint *)(param_1 + 0xc) = uVar5;
      if (0x1f9e < uVar5) {
        cVar3 = func_0x(0x145fb40);
        if (((cVar3 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar3 = func_0x(0x145fb40);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xd4f54c,0xe6f638,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar22 = param_1[0xe];
        uVar5 = *(uint *)(param_1 + 0xc);
      }
      uVar15 = (ulonglong)uVar22;
      uVar22 = puVar24[uVar15];
      *(uint *)(param_1 + 2) = uVar22 & 0x7fff;
      if ((uVar22 & 0x7fff) < uVar5) {
        cVar3 = func_0x(0x145fb40);
        if (((cVar3 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar3 = func_0x(0x145fb40);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xd4f54c,0xe6f638,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar5 = *(uint *)(param_1 + 0xc);
        uVar15 = (ulonglong)(ushort)param_1[0xe];
      }
      uVar11 = uVar19;
      puVar20 = puVar24;
      if ((short)uVar15 != 0) {
        do {
          uVar17 = puVar20[1] & 0x7fff;
          if ((uVar17 < uVar5) || (*(uint *)(param_1 + 2) < uVar17)) {
            cVar3 = func_0x(0x145fb40);
            if ((cVar3 != '\0') &&
               ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')
                ))) {
              cVar3 = func_0x(0x145fb40);
              if (cVar3 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0xd4f54c,0xe6f638,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),4);
          }
          uVar15 = (ulonglong)(ushort)param_1[0xe];
          uVar23 = (int)uVar11 + 1;
          uVar11 = (ulonglong)uVar23;
          puVar20 = puVar20 + 1;
          uVar5 = uVar17;
        } while ((int)uVar23 < (int)(uint)(ushort)param_1[0xe]);
      }
      if ((short)puVar24[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
        lVar8 = *(longlong *)(param_1 + 4);
        do {
          uVar5 = *(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar8 + uVar15 * 2) & 0x7fff;
          if ((int)uVar15 == 1) {
            uVar17 = *(uint *)(param_1 + 0xc);
            uVar23 = uVar17;
LAB_:
            if ((uVar5 < uVar17) || (*(uint *)(param_1 + 2) < uVar5)) goto LAB_;
          }
          else {
            uVar23 = *(uint *)(param_1 + 0xc);
            uVar17 = *(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar8 + -2 + uVar15 * 2) &
                     0x7fff;
            if (uVar23 <= uVar17) goto LAB_;
LAB_:
            func_0x(lVar8,7);
            uVar23 = *(uint *)(param_1 + 0xc);
          }
          if ((uVar17 < uVar23) || (*(uint *)(param_1 + 2) < uVar17)) goto LAB_;
          lVar8 = *(longlong *)(param_1 + 4);
          if (*(ushort *)((ulonglong)uVar17 + lVar8) == 5) {
            *puVar1 = *puVar1 | 2;
            param_1[0xe] = param_1[0xe] + -1;
            uVar11 = (ulonglong)(uVar17 & 0xffff);
            param_1[0x15] = (short)uVar17;
            uVar15 = *(ulonglong *)(param_1 + 4);
            uVar22 = param_1[0x16] & 0xc7ffU;
            if ((*(ushort *)(uVar11 + 2 + uVar15) >> 0xe & 1) != 0) {
              uVar22 = *(ushort *)(uVar11 + 2 + uVar15) & 0x3800 | param_1[0x16] & 0xc7ffU;
            }
            param_1[0x16] = uVar22;
            uVar4 = (uVar22 ^ *(ushort *)(uVar11 + 2 + uVar15)) & 0x7ff ^ uVar22;
            param_1[0x16] = uVar4;
            uVar18 = (ulonglong)((uVar4 & 0x7ff) * 2) + 4 + uVar15 + (uVar22 >> 0xb & 7) * 2 +
                     uVar11;
            if (uVar18 < uVar11 + uVar15) {
              func_0x(uVar11 + uVar15,0x19);
              uVar4 = param_1[0x16];
              uVar11 = (ulonglong)(ushort)param_1[0x15];
              uVar15 = (ulonglong)*(uint *)(param_1 + 4);
            }
            if (uVar5 - uVar17 < (((uVar4 & 0x7ff) * 2 - (int)uVar11) - (int)uVar15) + (int)uVar18)
            {
              func_0x(uVar11 + *(longlong *)(param_1 + 4),0x19);
              uVar4 = param_1[0x16];
            }
            if (((uVar4 & 0x3800) != 0) &&
               (puVar24 = (ushort *)
                          (*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]),
               (uVar4 & 0x3800) != 0)) {
              do {
                if ((uVar4 & 0x7ff) < (*puVar24 & 0x7ff)) {
                  func_0x((ulonglong)(ushort)param_1[0x15] + *(longlong *)(param_1 + 4),0x1a
                                 );
                  uVar4 = param_1[0x16];
                }
                uVar5 = (int)uVar19 + 1;
                uVar19 = (ulonglong)uVar5;
                puVar24 = puVar24 + 1;
              } while ((int)uVar5 < (int)(uVar4 >> 0xb & 7));
            }
            break;
          }
          if (*(ushort *)((ulonglong)uVar17 + lVar8) < 0x400) break;
          *puVar1 = *puVar1 | 1;
          uVar22 = param_1[0xe] - 1;
          param_1[0xe] = uVar22;
          if ((uVar22 == 0) ||
             (uVar15 = (ulonglong)uVar22, -1 < (short)puVar24[(ulonglong)(uVar22 - 1) + 1])) break;
        } while( true );
      }
    }
    if ((**(byte **)(param_1 + 4) & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x13) = 0;
    }
    else {
      *(int *)(param_1 + 0x13) = *(int *)(param_1 + 2);
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + 0xe;
      uVar9 = func_0x(puVar1);
      func_0x(uVar9,&puStack_58);
      iVar6 = func_0x(&puStack_58);
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar6;
    }
    if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
       (*(ulonglong *)(param_1 + 0xf) <
        (ulonglong)*(uint *)(param_1 + 2) + *(longlong *)(param_1 + 4))) {
      cVar3 = func_0x(0x145fb40);
      if ((cVar3 != '\0') &&
         ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')))) {
        cVar3 = func_0x(0x145fb40);
        if (cVar3 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0xd4f54c,0xe6f638,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),0x12);
    }
    if (0x3f3b < *(int *)(param_1 + 2) - 1U) {
      cVar3 = func_0x(0x145fb40);
      if (((cVar3 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
         (*(char *)(lVar8 + 0x499) != '\0')) {
        cVar3 = func_0x(0x145fb40);
        if (cVar3 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0xd4f54c,0xe6f638,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),5);
    }
  }
LAB_:
  sVar14 = -(short)uStack_48;
  if ((uStack_44 & 0x100000) != 0) {
    if ((**(byte **)(param_1 + 4) & 0x10) == 0) {
      if ((1 << (**(byte **)(param_1 + 4) & 0xe) & 0x1105U) != 0) goto LAB_;
    }
    else {
      if (*(int *)(param_1 + 8) <= (int)uStack_48) {
LAB_:
        *param_4 = *piStack_40;
        return piStack_40 + 1;
      }
      if ((**(byte **)(param_1 + 4) & 0x10) != 0) {
        uVar21 = (uint)*(ushort *)((ulonglong)*(uint *)(param_1 + 8) + *(longlong *)(param_1 + 4));
      }
      if (uVar21 < (uStack_44 & 0xffff)) goto LAB_;
    }
  }
  if ((uint)(ushort)param_1[0xe] < (uint)(int)sVar14) {
    *param_4 = 0;
    return *(int **)(param_1 + 4);
  }
  uVar21 = *(ushort *)
            ((ulonglong)*(uint *)(param_1 + 10) + *(longlong *)(param_1 + 4) + (longlong)sVar14 * 2)
           & 0x7fff;
  if (sVar14 == 1) {
    uVar19 = (ulonglong)*(uint *)(param_1 + 0xc);
LAB_:
    if (((uint)uVar19 <= uVar21) && (uVar21 <= *(uint *)(param_1 + 2))) goto LAB_;
  }
  else {
    uVar5 = *(ushort *)
             ((ulonglong)*(uint *)(param_1 + 10) + *(longlong *)(param_1 + 4) + -2 +
             (longlong)sVar14 * 2) & 0x7fff;
    uVar19 = (ulonglong)uVar5;
    if (*(uint *)(param_1 + 0xc) <= uVar5) goto LAB_;
  }
  func_0x(*(undefined8 *)(param_1 + 4),7);
LAB_:
  *param_4 = uVar21 - (int)uVar19;
  return (int *)(uVar19 + *(longlong *)(param_1 + 4));
}

