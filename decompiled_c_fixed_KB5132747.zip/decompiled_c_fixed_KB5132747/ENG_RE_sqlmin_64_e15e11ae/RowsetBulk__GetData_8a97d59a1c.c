
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  undefined2 *puVar1;
  byte bVar2;
  byte *pbVar3;
  longlong lVar4;
  code *UNRECOVERED_JUMPTABLE;
  undefined8 unaff_RBX;
  undefined2 auStackX_8 [2];
  undefined4 uStackX_c;
  byte *apbStackX_10 [3];
  
  lVar4 = func_0x();
  lVar4 = -lVar4;
  puVar1 = (undefined2 *)((longlong)auStackX_8 + lVar4);
  *(undefined8 *)(&stack0x000002c8 + lVar4) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002450 + lVar4) = unaff_RBX;
  *(ulonglong *)(&stack0x000023f8 + lVar4) = _DAT_ ^ (ulonglong)puVar1;
  *(longlong *)(&stack0x00000090 + lVar4) = param_1;
  *(undefined4 *)((longlong)&uStackX_c + lVar4) = 0;
  *(undefined8 *)((longlong)apbStackX_10 + lVar4 + 0x16) = 0;
  *(undefined8 *)(&stack0x00000030 + lVar4) = 0;
  *(undefined8 *)((longlong)apbStackX_10 + lVar4 + 8) = 0;
  *(undefined4 *)(&stack0x000000ac + lVar4) = 0;
  *(undefined8 *)(&stack0x000000c0 + lVar4) = 0;
  *(undefined4 *)(&stack0x000000c8 + lVar4) = 0;
  pbVar3 = *(byte **)(param_1 + 0x238);
  bVar2 = *pbVar3;
  *(byte **)((longlong)apbStackX_10 + lVar4) = pbVar3;
  if ((bVar2 & 1) != 0) {
    *puVar1 = 1;
    UNRECOVERED_JUMPTABLE =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x107288) * 4 +
                           0x107278) - 0x1d06f30);
                    /* WARNING: Could not emulate address calculation at 0x001000c2 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
    return;
  }
  *puVar1 = 0;
  *(undefined4 *)(&stack0x0000002e + lVar4) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100216 */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x1072a8) - 0x1d06f30))();
  return;
}

