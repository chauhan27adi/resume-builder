
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,uint param_3,uint param_4)

{
  byte *pbVar1;
  undefined auVar2 [16];
  undefined2 uVar3;
  char cVar4;
  uint uVar5;
  undefined8 uVar6;
  longlong lVar7;
  ushort uVar8;
  byte bVar9;
  short sVar10;
  byte *pbVar11;
  undefined *puVar12;
  uint uVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  uint uVar16;
  ulonglong uVar17;
  ulonglong uVar18;
  ushort *puVar19;
  uint uVar20;
  uint uVar21;
  ulonglong uVar22;
  byte *pbVar23;
  int iVar24;
  bool bVar25;
  undefined8 uStack_120;
  undefined auStack_118 [32];
  uint *puStack_f8;
  undefined8 uStack_f0;
  uint uStack_e8;
  uint uStack_e0;
  short sStack_d8;
  ushort uStack_d6;
  uint uStack_d4;
  byte *pbStack_d0;
  undefined8 uStack_c8;
  undefined4 uStack_c0;
  ushort uStack_bc;
  undefined2 uStack_ba;
  undefined6 uStack_b8;
  undefined2 uStack_b2;
  undefined2 uStack_b0;
  ushort uStack_ae;
  ushort uStack_ac;
  undefined2 uStack_aa;
  undefined4 uStack_a8;
  short sStack_a0;
  uint uStack_98;
  undefined2 uStack_94;
  uint uStack_88;
  int iStack_84;
  uint uStack_80;
  uint uStack_7c;
  undefined4 uStack_78;
  undefined2 uStack_74;
  longlong lStack_68;
  ulonglong uStack_60;
  ushort *puStack_58;
  undefined auStack_50 [8];
  longlong lStack_48;
  ulonglong uStack_40;
  longlong lStack_38;
  ulonglong uStack_30;
  
  puVar12 = auStack_118;
  uStack_30 = _DAT_ ^ (ulonglong)&sStack_d8;
  uVar18 = (ulonglong)(int)param_3;
  uVar21 = 0;
  uStack_88 = 0;
  sStack_a0 = 0;
  iStack_84 = param_2;
  uStack_80 = param_3;
  uStack_7c = param_4;
  lStack_48 = param_1;
  if (*(ushort *)(param_1 + 0x1c) < param_4) {
    uStack_98 = *(uint *)(param_1 + 0x20);
    uStack_94 = *(undefined2 *)(param_1 + 0x24);
    uStack_f0 = 0x1371820;
    puStack_f8 = &uStack_98;
    uStack_120 = 0x1000b5;
    uStack_e8 = (uint)*(ushort *)(param_1 + 0x1c);
    uStack_e0 = param_4;
    (*_DAT_)(0xb,0x1b,0x16,0x6d);
  }
  if (param_2 == 0) {
    auVar2._8_8_ = 0;
    auVar2._0_8_ = uVar18;
    uVar6 = SUB168(auVar2 * ZEXT816(2),0);
    if (SUB168(auVar2 * ZEXT816(2),8) != 0) {
      uVar6 = 0xffffffffffffffff;
      uStack_120 = 0x1000f3;
      func_0x(0x80070216,2,uVar18);
    }
    uStack_120 = 0x10010f;
    lVar7 = func_0x();
    lVar7 = -lVar7;
    puVar12 = auStack_118 + lVar7;
    uVar8 = *(ushort *)(param_1 + 0x16);
    *(undefined8 *)(auStack_118 + lVar7 + -8) = 0x100144;
    func_0x
              ((longlong)&sStack_d8 + lVar7,uVar6,
               param_1 + ((longlong)(int)((1 - (uint)uVar8) - param_3) + 0xfff) * 2,uVar18 * 2);
    uVar8 = *(ushort *)(param_1 + 0x16);
    *(undefined8 *)(auStack_118 + lVar7 + -8) = 0x10017c;
    func_0x
              (param_1 + ((longlong)(int)((1 - (uint)uVar8) - param_3) + 0xfff) * 2,
               param_1 + (0x1000 - (longlong)(int)(uint)uVar8) * 2,(uint)uVar8 * 2);
    *(undefined8 *)(auStack_118 + lVar7 + -8) = 0x1001a0;
    func_0x
              (param_1 + ((longlong)(int)(1 - param_3) + 0xfff) * 2,
               (longlong)(int)(1 - param_3) * 2 + 0x3ffe,(longlong)&sStack_d8 + lVar7,uVar18 * 2);
    param_2 = iStack_84;
  }
  sVar10 = 0;
  uVar22 = 0;
  sStack_d8 = -1;
  pbStack_d0 = (byte *)0x0;
  uStack_d4 = 0;
  uStack_ba = 0;
  uStack_b8 = 0;
  uStack_b0 = 0;
  uStack_ae = 0;
  uStack_ac = 0;
  uStack_aa = 0;
  uStack_c8 = 0;
  uStack_98 = 0;
  if (0 < (int)param_3) {
    lStack_38 = (longlong)param_2;
    uStack_60 = param_1 + 0x2000;
    if (param_1 == 0) {
      uStack_60 = uVar22;
    }
    lStack_68 = 0;
    do {
      uVar17 = uStack_60;
      uVar14 = 0;
      uVar20 = (uint)uVar22;
      uVar22 = (ulonglong)*(ushort *)(param_1 + 0xe);
      uStack_40 = (ulonglong)*(ushort *)(param_1 + ((0xfff - lStack_38) - lStack_68) * 2);
      pbVar23 = (byte *)(param_1 + uStack_40);
      uVar21 = 0;
      uStack_b0 = (undefined2)uStack_60;
      uVar3 = uStack_b0;
      pbStack_d0 = pbVar23;
      if ((*(byte *)(param_1 + uStack_40) & 1) == 0) {
        sStack_d8 = 0;
        uVar15 = 0;
        uStack_d4 = 0;
        uStack_b2 = 0;
        uStack_b0 = 0;
        switch(*pbVar23 & 0xe) {
        default:
          uVar22 = (ulonglong)*(ushort *)(pbVar23 + 2);
          uVar14 = uVar15;
          if (0x1f9d < *(ushort *)(pbVar23 + 2) - 1) {
            *(undefined8 *)(puVar12 + -8) = 0x10044e;
            func_0x(pbVar23,6);
            uVar14 = (ulonglong)uStack_d4;
          }
          break;
        case 4:
          uVar22 = 9;
          uVar14 = uVar15;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar22 = 1;
          uVar14 = uVar15;
        }
        uVar21 = (uint)uVar22;
        uStack_b8 = (undefined6)(uVar17 >> 0x10);
        uStack_c8 = CONCAT44(uStack_c8._4_4_,uVar21);
        uStack_ba = uVar3;
        uVar16 = uStack_c0;
      }
      else {
        sStack_d8 = 1;
        bVar9 = *pbVar23;
        uStack_ae = (ushort)(uStack_60 >> 0x10);
        uStack_ac = (ushort)(uStack_60 >> 0x20);
        uStack_aa = (undefined2)(uStack_60 >> 0x30);
        switch(bVar9 & 0x1c) {
        default:
          if ((char)pbVar23[1] < '\0') {
            sVar10 = 3;
            uStack_c0._0_2_ = 3;
            uStack_d6 = (*(ushort *)(pbVar23 + 1) & 0x7f) << 8 | *(ushort *)(pbVar23 + 1) >> 8;
          }
          else {
            uStack_d6 = (ushort)pbVar23[1];
            sVar10 = 2;
            uStack_c0._0_2_ = 2;
          }
          uStack_bc = (short)(uStack_d6 + 1 >> 1) + sVar10;
          if (uStack_d6 < 0x1f) {
            uStack_d4 = 0;
            uStack_a8 = 0;
            uStack_c8 = 0;
            uVar22 = uVar14;
            uVar16 = (uint)(ushort)uStack_c0;
          }
          else {
            iVar24 = uStack_d6 - 1;
            uStack_d4 = 0;
            uStack_a8 = 0;
            uVar14 = 0;
            uStack_c8 = 0;
            uVar22 = 0;
            uVar16 = CONCAT22(((short)(iVar24 / 0x1e) + (short)(iVar24 >> 0x1f)) -
                              (short)((longlong)iVar24 * 0x88888889 >> 0x3f),(ushort)uStack_c0);
          }
          break;
        case 4:
          uVar21 = 0;
          if (((bVar9 & 0x1c) == 4) && ((bVar9 & 2) != 0)) {
            uVar14 = 0xf;
            uStack_bc = 0;
            uStack_ba = 0;
            uStack_d4 = 0xf;
            uVar22 = 0;
            uStack_d6 = 0;
            uStack_b8 = 0;
            uStack_b2 = 0;
            uStack_a8 = 1;
            uStack_c8 = 0;
            uVar16 = 0;
          }
          else {
            uStack_bc = 0;
            uStack_ba = 0;
            uVar14 = 1;
            uStack_d6 = 0;
            uVar22 = 0;
            uStack_b8 = 0;
            uStack_b2 = 0;
            uStack_d4 = 1;
            uStack_a8 = 0;
            uStack_c8 = 0;
            uVar16 = 0;
          }
          break;
        case 8:
          uVar14 = 9;
          uStack_bc = 0;
          uStack_ba = 0;
          uStack_d4 = 9;
          uVar22 = 0;
          uStack_d6 = 0;
          uStack_b8 = 0;
          uStack_b2 = 0;
          uStack_a8 = 0;
          uStack_c8 = 0;
          uVar16 = 0;
        }
      }
      uVar5 = 0;
      uVar13 = (uint)uVar14;
      uStack_c0 = uVar16;
      if (sStack_d8 == 0) {
        pbVar23 = pbStack_d0;
        if (uVar13 == 0) {
          uStack_d6 = 0;
          uVar20 = (uint)uVar22;
          if ((*pbStack_d0 & 0x10) != 0) {
            if ((*pbStack_d0 & 0x10) != 0) {
              uVar5 = (uint)*(ushort *)(pbStack_d0 + uVar21);
            }
            uVar20 = uVar20 + 2 + (uVar5 + 7 >> 3);
            uVar22 = (ulonglong)uVar20;
          }
          uStack_c8 = CONCAT44(uVar20,(int)uStack_c8);
          uStack_c0 = (uint)uVar22;
          if ((*pbStack_d0 & 0x20) == 0) {
            uStack_bc = 0;
            uStack_d4 = uStack_c0;
          }
          else {
            puVar19 = (ushort *)(pbStack_d0 + uVar22);
            uStack_bc = *puVar19;
            uVar18 = uVar22;
            puStack_58 = puVar19;
            if (uStack_bc == 0) {
              uStack_c0 = uVar16;
              *(undefined8 *)(puVar12 + -8) = 0x10051b;
              cVar4 = func_0x(0x1a4a120);
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar12 + -8) = 0x100524;
                lVar7 = func_0x();
                if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar12 + -8) = 0x10053e;
                  cVar4 = func_0x(0x1a4a120);
                  if (cVar4 == '\0') {
                    *(undefined8 *)(puVar12 + -8) = 0x10055a;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar12 + 0x20) = 0;
                    *(undefined8 *)(puVar12 + -8) = 0x100584;
                    (*_DAT_)(1,0x1339b2c,0x1459c18,0x80f);
                  }
                }
              }
              pbVar23 = pbStack_d0;
              *(undefined8 *)(puVar12 + -8) = 0x100592;
              func_0x(pbVar23,3);
              uVar18 = uStack_c8 >> 0x20;
            }
            uStack_c0 = (uint)uStack_bc * 2 + 2 + (int)uVar18;
            if (0x1f9e < uStack_c0) {
              *(undefined8 *)(puVar12 + -8) = 0x1005cb;
              cVar4 = func_0x(0x1a4a120);
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar12 + -8) = 0x1005d4;
                lVar7 = func_0x();
                if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar12 + -8) = 0x1005ee;
                  cVar4 = func_0x(0x1a4a120);
                  if (cVar4 == '\0') {
                    *(undefined8 *)(puVar12 + -8) = 0x10060a;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar12 + 0x20) = 0;
                    *(undefined8 *)(puVar12 + -8) = 0x100634;
                    (*_DAT_)(1,0x1339b2c,0x1459c18,0x816);
                  }
                }
              }
              pbVar23 = pbStack_d0;
              *(undefined8 *)(puVar12 + -8) = 0x100642;
              func_0x(pbVar23,4);
              uVar18 = uStack_c8 >> 0x20;
            }
            uVar17 = (ulonglong)uStack_bc;
            uStack_d4 = puVar19[uVar17] & 0x7fff;
            if (uStack_d4 < uStack_c0) {
              *(undefined8 *)(puVar12 + -8) = 0x10067a;
              cVar4 = func_0x(0x1a4a120);
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar12 + -8) = 0x100683;
                lVar7 = func_0x();
                if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar12 + -8) = 0x10069d;
                  cVar4 = func_0x(0x1a4a120);
                  if (cVar4 == '\0') {
                    *(undefined8 *)(puVar12 + -8) = 0x1006b9;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar12 + 0x20) = 0;
                    *(undefined8 *)(puVar12 + -8) = 0x1006e3;
                    (*_DAT_)(1,0x1339b2c,0x1459c18,0x81d);
                  }
                }
              }
              pbVar23 = pbStack_d0;
              *(undefined8 *)(puVar12 + -8) = 0x1006f1;
              func_0x(pbVar23,4);
              uVar17 = (ulonglong)uStack_bc;
              uVar18 = uStack_c8 >> 0x20;
            }
            uVar22 = (ulonglong)uStack_d4;
            iVar24 = 0;
            pbVar23 = pbStack_d0;
            uVar21 = uStack_c0;
            if ((short)uVar17 != 0) {
              do {
                puVar19 = puVar19 + 1;
                uVar20 = *puVar19 & 0x7fff;
                if ((uVar20 < uStack_c0) || ((uint)uVar22 < uVar20)) {
                  uStack_c0 = uVar21;
                  *(undefined8 *)(puVar12 + -8) = 0x100742;
                  cVar4 = func_0x(0x1a4a120);
                  if (cVar4 != '\0') {
                    *(undefined8 *)(puVar12 + -8) = 0x10074b;
                    lVar7 = func_0x();
                    if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar12 + -8) = 0x100765;
                      cVar4 = func_0x(0x1a4a120);
                      if (cVar4 == '\0') {
                        *(undefined8 *)(puVar12 + -8) = 0x100781;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar12 + 0x20) = 0;
                        *(undefined8 *)(puVar12 + -8) = 0x1007a7;
                        (*_DAT_)(1,0x1339b2c,0x1459c18,0x82a);
                      }
                    }
                  }
                  pbVar23 = pbStack_d0;
                  *(undefined8 *)(puVar12 + -8) = 0x1007b5;
                  func_0x(pbVar23,4);
                  uVar17 = (ulonglong)uStack_bc;
                  uVar22 = (ulonglong)uStack_d4;
                  pbVar23 = pbStack_d0;
                  uVar21 = uStack_c0;
                }
                iVar24 = iVar24 + 1;
                uStack_c0 = uVar20;
              } while (iVar24 < (int)uVar17);
              uVar18 = uStack_c8 >> 0x20;
              uStack_c0 = uVar21;
              puVar19 = puStack_58;
            }
            while ((short)puVar19[(ulonglong)((int)uVar17 - 1) + 1] < 0) {
              if ((int)uVar17 == 1) {
                uVar14 = 1;
                uVar20 = uVar21;
              }
              else {
                uVar20 = *(ushort *)(pbVar23 + uVar17 * 2 + (uVar18 - 2)) & 0x7fff;
                uVar14 = uVar17;
              }
              uVar16 = *(ushort *)(pbVar23 + uVar14 * 2 + uVar18) & 0x7fff;
              if (((uVar20 < uVar21) || (uVar16 < uVar20)) || ((uint)uVar22 < uVar16)) {
                *(undefined8 *)(puVar12 + -8) = 0x100849;
                func_0x(pbVar23,7);
                uVar17 = (ulonglong)uStack_bc;
                uVar18 = uStack_c8 >> 0x20;
                uVar22 = (ulonglong)uStack_d4;
                pbVar23 = pbStack_d0;
                uVar21 = uStack_c0;
              }
              uVar13 = (uint)uVar22;
              if ((uVar20 < uVar21) || (uVar13 < uVar20)) goto code_r0x00100b98;
              if (*(ushort *)(pbVar23 + uVar20) == 5) {
                uStack_d6 = uStack_d6 | 2;
                uStack_bc = (short)uVar17 - 1;
                uVar18 = (ulonglong)(uVar20 & 0xffff);
                pbVar1 = pbVar23 + uVar18;
                uStack_ae = (ushort)uVar20;
                if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                  uVar8 = uStack_ac & 0xc7ff;
                }
                else {
                  uVar8 = uStack_ac ^ (uStack_ac ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
                }
                uStack_ac = (uVar8 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar8;
                uVar17 = (ulonglong)uStack_ac;
                pbVar11 = pbVar23 + (ulonglong)((uVar8 >> 0xb & 7) * 2) + 4 + uVar18 +
                                    (uVar17 & 0x7ff) * 2;
                if (pbVar11 < pbVar1) {
                  *(undefined8 *)(puVar12 + -8) = 0x100941;
                  func_0x(pbVar1,0x19);
                  uVar17 = (ulonglong)uStack_ac;
                  uVar18 = (ulonglong)uStack_ae;
                  uVar22 = (ulonglong)uStack_d4;
                  pbVar23 = pbStack_d0;
                }
                if (uVar16 - uVar20 <
                    (((uStack_ac & 0x7ff) * 2 - (int)uVar18) - (int)pbStack_d0) + (int)pbVar11) {
                  *(undefined8 *)(puVar12 + -8) = 0x10097a;
                  func_0x(pbVar23 + uVar18,0x19);
                  uVar17 = (ulonglong)uStack_ac;
                  uVar18 = (ulonglong)uStack_ae;
                  uVar22 = (ulonglong)uStack_d4;
                  pbVar23 = pbStack_d0;
                }
                iVar24 = 0;
                if (((uVar17 & 0x3800) != 0) &&
                   (puVar19 = (ushort *)(pbVar23 + uVar18 + 4), (uVar17 & 0x3800) != 0)) {
                  do {
                    if (((ushort)uVar17 & 0x7ff) < (*puVar19 & 0x7ff)) {
                      *(undefined8 *)(puVar12 + -8) = 0x1009e5;
                      func_0x(pbVar23 + uVar18,0x1a);
                      uVar17 = (ulonglong)uStack_ac;
                      uVar18 = (ulonglong)uStack_ae;
                      pbVar23 = pbStack_d0;
                    }
                    iVar24 = iVar24 + 1;
                    puVar19 = puVar19 + 1;
                  } while (iVar24 < (int)((uStack_ac & 0x3800) >> 0xb));
                  uVar22 = (ulonglong)uStack_d4;
                }
                break;
              }
              if (*(ushort *)(pbVar23 + uVar20) < 0x400) break;
              uStack_d6 = uStack_d6 | 1;
              uStack_bc = (short)uVar17 - 1;
              uVar17 = (ulonglong)uStack_bc;
              if (uStack_bc == 0) break;
            }
          }
          if ((*pbVar23 & 0x40) == 0) {
            uStack_b2 = 0;
            uStack_b0 = 0;
          }
          else {
            uStack_b2 = (undefined2)uVar22;
            uStack_b0 = (undefined2)(uVar22 >> 0x10);
            uStack_d4 = (int)uVar22 + 0xe;
            *(undefined8 *)(puVar12 + -8) = 0x100a36;
            uVar6 = func_0x(&uStack_d6);
            *(undefined8 *)(puVar12 + -8) = 0x100a45;
            func_0x(uVar6,auStack_50);
            *(undefined8 *)(puVar12 + -8) = 0x100a51;
            iVar24 = func_0x(auStack_50);
            uStack_d4 = uStack_d4 + iVar24;
            uVar22 = (ulonglong)uStack_d4;
            pbVar23 = pbStack_d0;
          }
          uVar13 = (uint)uVar22;
          if (((byte *)CONCAT62(uStack_b8,uStack_ba) != (byte *)0x0) &&
             ((byte *)CONCAT62(uStack_b8,uStack_ba) < pbVar23 + uVar22)) {
            *(undefined8 *)(puVar12 + -8) = 0x100a8a;
            cVar4 = func_0x(0x1a4a120);
            if (cVar4 != '\0') {
              *(undefined8 *)(puVar12 + -8) = 0x100a93;
              lVar7 = func_0x();
              if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                *(undefined8 *)(puVar12 + -8) = 0x100aad;
                cVar4 = func_0x(0x1a4a120);
                if (cVar4 == '\0') {
                  *(undefined8 *)(puVar12 + -8) = 0x100ac9;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar12 + 0x20) = 0;
                  *(undefined8 *)(puVar12 + -8) = 0x100aef;
                  (*_DAT_)(1,0x1339b2c,0x1459c18,0x886);
                }
              }
            }
            pbVar23 = pbStack_d0;
            *(undefined8 *)(puVar12 + -8) = 0x100afd;
            func_0x(pbVar23,0x12);
            pbVar23 = pbStack_d0;
            uVar13 = uStack_d4;
          }
          if (0x3f3b < uVar13 - 1) {
            *(undefined8 *)(puVar12 + -8) = 0x100b1e;
            cVar4 = func_0x(0x1a4a120);
            if (cVar4 != '\0') {
              *(undefined8 *)(puVar12 + -8) = 0x100b27;
              lVar7 = func_0x();
              if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                *(undefined8 *)(puVar12 + -8) = 0x100b41;
                cVar4 = func_0x(0x1a4a120);
                if (cVar4 == '\0') {
                  *(undefined8 *)(puVar12 + -8) = 0x100b5d;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar12 + 0x20) = 0;
                  *(undefined8 *)(puVar12 + -8) = 0x100b83;
                  (*_DAT_)(1,0x1339b2c,0x1459c18,0x88b);
                }
              }
            }
            pbVar23 = pbStack_d0;
            *(undefined8 *)(puVar12 + -8) = 0x100b91;
            func_0x(pbVar23,5);
            pbVar23 = pbStack_d0;
            uVar13 = uStack_d4;
          }
        }
code_r0x00100b98:
        if ((uVar13 < 9) && (((*pbVar23 & 0xe) == 0 || ((*pbVar23 & 0xe) == 0xc)))) {
          uVar13 = 9;
        }
        uVar18 = (ulonglong)uStack_80;
        param_1 = lStack_48;
        uVar20 = uStack_98;
      }
      else {
        if (uVar13 == 0) {
          *(undefined8 *)(puVar12 + -8) = 0x100bcb;
          func_0x(&uStack_d6);
          uVar13 = uStack_d4;
        }
        pbVar23 = pbStack_d0;
        if ((uVar13 < 9) && (((*pbStack_d0 & 0x1c) == 0 || ((*pbStack_d0 & 0x1c) == 0xc)))) {
          uVar13 = 9;
        }
      }
      param_3 = (uint)uVar18;
      sVar10 = 1 << ((byte)*(undefined2 *)(param_1 + 4) & 2);
      uVar21 = uStack_88 + 2 + (uint)(ushort)((short)uVar13 + -1 + sVar10 & -sVar10);
      if (sStack_d8 == 0) {
        bVar9 = *pbVar23 & 0xe;
        bVar25 = false;
        if (bVar9 == 2) {
          bVar25 = false;
          if ((pbVar23[1] & 1) != 0) {
            bVar25 = true;
          }
        }
        else if (((bVar9 - 10 & 0xf9) == 0) && (bVar9 != 0x10)) {
          bVar25 = true;
        }
      }
      else {
        bVar25 = ((*pbVar23 & 0x1c) - 4 & 0xffffffe7) == 0;
      }
      sVar10 = sStack_a0 + 1;
      if (!bVar25) {
        sVar10 = sStack_a0;
      }
      sStack_a0 = sVar10;
      uStack_88 = uVar21;
      if ((short)uStack_40 == 0) {
        uStack_78 = *(undefined4 *)(param_1 + 0x20);
        uStack_74 = *(undefined2 *)(param_1 + 0x24);
        iVar24 = iStack_84 + uVar20;
        *(undefined4 *)(puVar12 + 0x38) = 0;
        *(int *)(puVar12 + 0x30) = iVar24;
        *(undefined8 *)(puVar12 + 0x28) = 0x1371800;
        *(undefined4 **)(puVar12 + 0x20) = &uStack_78;
        *(undefined8 *)(puVar12 + -8) = 0x100cd8;
        (*_DAT_)(0xb,0x18,0x16,100);
      }
      if (uVar13 == 0) {
        *(undefined8 *)(puVar12 + 0x20) = 0;
        *(undefined8 *)(puVar12 + -8) = 0x100d04;
        (*_DAT_)(1,0x14f3ea8,0x14bf038,0x1632);
      }
      lStack_68 = lStack_68 + 1;
      uStack_98 = uVar20 + 1;
      uVar22 = (ulonglong)uStack_98;
      param_4 = uStack_7c;
    } while ((int)uStack_98 < (int)param_3);
  }
  if (uVar21 != param_4) {
    *(undefined8 *)(puVar12 + 0x20) = 0;
    *(undefined8 *)(puVar12 + -8) = 0x100d69;
    (*_DAT_)(1,0x14f3eb8,0x14bf038,0x1634);
  }
  *(short *)(param_1 + 0x16) = *(short *)(param_1 + 0x16) + (short)param_3;
  *(short *)(param_1 + 0x1c) = *(short *)(param_1 + 0x1c) - (short)param_4;
  *(short *)(param_1 + 0x3a) = *(short *)(param_1 + 0x3a) + sVar10;
  if (*(char *)(param_1 + 2) < '\0') {
    if ((int)(uint)*(ushort *)(param_1 + 0x61) < (int)(0xffff - (param_3 & 0xffff))) {
      *(ushort *)(param_1 + 0x61) = *(ushort *)(param_1 + 0x61) + (short)param_3;
    }
    else {
      *(undefined2 *)(param_1 + 0x61) = 0xffff;
    }
  }
  uVar18 = uStack_30 ^ (ulonglong)&sStack_d8;
  *(undefined8 *)(puVar12 + -8) = 0x100db6;
  func_0x(uVar18);
  return;
}

