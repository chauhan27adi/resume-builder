
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,longlong param_2,undefined8 param_3,int param_4,
                 undefined8 param_5,undefined8 param_6)

{
  byte *pbVar1;
  byte *pbVar2;
  longlong lVar3;
  longlong lVar4;
  undefined auVar5 [16];
  char cVar6;
  longlong lVar7;
  code *UNRECOVERED_JUMPTABLE_00;
  ulonglong uVar8;
  undefined8 auStack_3f0 [13];
  undefined auStack_388 [8];
  longlong lStack_380;
  undefined4 uStack_378;
  undefined2 uStack_370;
  undefined4 uStack_36c;
  undefined8 uStack_368;
  undefined8 uStack_360;
  undefined8 uStack_352;
  undefined8 uStack_348;
  undefined uStack_338;
  undefined8 uStack_330;
  int iStack_328;
  undefined4 uStack_300;
  undefined2 uStack_2fc;
  undefined8 uStack_2d8;
  undefined2 uStack_2d0;
  undefined *puStack_2a8;
  longlong **pplStack_2a0;
  undefined8 uStack_298;
  undefined8 uStack_288;
  longlong lStack_280;
  undefined auStack_278 [16];
  undefined2 uStack_248;
  undefined4 uStack_244;
  byte *pbStack_240;
  undefined8 uStack_238;
  undefined8 uStack_22a;
  undefined2 uStack_222;
  undefined2 uStack_220;
  undefined6 uStack_21e;
  int iStack_214;
  undefined auStack_210 [16];
  undefined auStack_200 [2];
  undefined auStack_1fe [14];
  undefined8 uStack_1f0;
  undefined6 uStack_1e8;
  undefined2 uStack_1e2;
  undefined6 uStack_1e0;
  undefined2 uStack_1da;
  undefined2 uStack_1d8;
  undefined6 uStack_1d6;
  undefined8 uStack_1d0;
  short *psStack_1c8;
  short *psStack_1c0;
  short sStack_1b8;
  undefined6 uStack_1b6;
  undefined auStack_1b0 [10];
  undefined auStack_1a6 [6];
  undefined8 uStack_1a0;
  undefined2 uStack_198;
  undefined4 uStack_194;
  undefined8 uStack_190;
  undefined8 uStack_188;
  undefined8 uStack_17a;
  undefined8 uStack_170;
  undefined8 uStack_160;
  undefined4 uStack_158;
  undefined8 uStack_138;
  undefined4 uStack_130;
  undefined2 uStack_12c;
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_388;
  uStack_298 = param_6;
  lVar3 = **param_1;
  lStack_280 = (ulonglong)*(uint6 *)(param_2 + 0x14) << 0x10;
  uStack_248 = 0xffff;
  uStack_138 = 0;
  uStack_370 = 0xffff;
  uStack_330 = 0;
  uStack_130 = 0;
  uStack_12c = 0;
  uStack_368 = 0;
  uStack_36c = 0;
  uStack_352 = 0;
  uStack_348 = 0;
  uStack_360 = 0;
  auStack_278 = ZEXT816(0);
  auStack_388[0] = 0;
  uStack_338 = 0;
  auStack_3f0[0] = 0x1000c9;
  lStack_380 = param_2;
  iStack_328 = param_4;
  pplStack_2a0 = param_1;
  uStack_288 = param_3;
  iStack_214 = param_4;
  lVar7 = func_0x();
  lVar7 = -lVar7;
  pbStack_240 = (byte *)0x0;
  uStack_244 = 0;
  puStack_2a8 = auStack_388 + lVar7;
  uStack_22a = 0;
  uStack_220 = 0;
  uStack_21e = 0;
  uStack_238 = 0;
  uStack_190 = 0;
  uStack_194 = 0;
  uStack_17a = 0;
  uStack_170 = 0;
  uStack_188 = 0;
  uStack_160 = 0;
  uStack_158 = 0;
  uStack_330 = CONCAT44(uStack_330._4_4_,9);
  uStack_198 = uStack_248;
  if (-1 < *(char *)(lVar3 + 2)) goto LAB_;
  pbVar1 = (byte *)(lVar3 + 0x60);
  uStack_1e8 = 0;
  auStack_1fe = SUB1614(ZEXT816(0),2);
  auStack_200 = (undefined  [2])uStack_248;
  uStack_1da = 0;
  auStack_1fe._6_8_ = 0;
  uStack_1d0 = 0;
  uStack_1e2 = 0;
  uStack_1e0 = 0;
  uStack_1d8 = 0;
  uStack_1d6 = 0;
  uStack_1f0 = 0;
  psStack_1c8 = (short *)0x0;
  _auStack_1b0 = ZEXT812(0);
  auStack_1a6._2_4_ = 0;
  uStack_1a0 = 0;
  psStack_1c0 = (short *)0x0;
  sStack_1b8 = 0;
  uStack_1b6 = 0;
  auStack_210 = ZEXT816(0);
  lVar4 = 0;
  if (*(short *)(lVar3 + 0x24) == 0) {
LAB_:
    auStack_210._8_8_ = lVar4;
    uStack_2d8 = *(undefined8 *)(lVar3 + 0x28);
    uStack_2d0 = *(undefined2 *)(lVar3 + 0x30);
  }
  else {
    cVar6 = *(char *)(lVar3 + 1);
    if (cVar6 == '\v') {
      if (*(int *)(lVar3 + 0x18) != 99) {
LAB_:
        if (cVar6 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar6 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar3 + 0x18) != 99) goto LAB_;
    }
    uStack_300 = *(undefined4 *)(lVar3 + 0x20);
    uStack_2fc = *(undefined2 *)(lVar3 + 0x24);
    *(undefined8 *)((longlong)auStack_3f0 + lVar7) = 0x100246;
    cVar6 = func_0x(&uStack_300,0x1685fa0);
    lVar4 = auStack_210._8_8_;
    if (cVar6 == '\0') goto LAB_;
    *(undefined8 *)((longlong)auStack_3f0 + lVar7) = 0x100259;
    func_0x(lVar3,&uStack_2d8);
  }
  lVar4 = auStack_210._8_8_;
  auStack_210._0_8_ = pbVar1;
  auStack_1b0._8_2_ = uStack_2d0;
  auStack_1b0._0_8_ = uStack_2d8;
  auStack_1a6._2_4_ = *(undefined4 *)(lVar3 + 0x20);
  uStack_1e2 = 0;
  uStack_1e0 = 0;
  uStack_1d8 = 0;
  uStack_1d6 = 0;
  uStack_378 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x1704880);
  uVar8 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x1704884);
  auStack_1fe._6_8_ = 0;
  auStack_1fe._0_6_ = (uint6)(_auStack_200 >> 0x10) & 0xffff;
  auStack_200 = (undefined  [2])0xffff;
  uStack_1f0 = 0;
  psStack_1c8 = (short *)0x0;
  psStack_1c0 = (short *)0x0;
  sStack_1b8 = 0;
  if ((*pbVar1 & 2) != 0) {
    pbVar2 = pbVar1 + uVar8;
    auStack_1fe._6_8_ = pbVar2;
    if ((pbVar1[uVar8] & 1) == 0) {
      auVar5._14_2_ = 0;
      auVar5._0_14_ = auStack_1fe;
      _auStack_200 = auVar5 << 0x10;
      uStack_1da = 0;
      uStack_1d8 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100516 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar2 & 0xe) * 4 + 0x103178) - 0xe94590))();
      return;
    }
    auStack_200 = (undefined  [2])0x1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar2 & 0x1c) + 0x103158) * 4 +
                           0x103148) - 0xe94590);
                    /* WARNING: Could not emulate address calculation at 0x0010035e */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((*pbVar1 & 4) != 0) {
    uStack_378._2_2_ = (short)((uint)uStack_378 >> 0x10);
    if (uStack_378._2_2_ != 0) {
      uVar8 = (ulonglong)*(ushort *)(lVar3 + 0x61 + (longlong)uStack_378._2_2_ * 2);
    }
    psStack_1c8 = (short *)(pbVar1 + uVar8);
    psStack_1c0 = psStack_1c8 + 1;
    sStack_1b8 = (*psStack_1c8 + 1) * 2;
  }
  if (auStack_210._8_8_ != 0) {
    *(undefined8 *)((longlong)auStack_3f0 + lVar7) = 0x1005ed;
    func_0x(lVar4,auStack_210);
  }
LAB_:
  pbStack_240 = (byte *)((ulonglong)*(ushort *)(lVar3 + (0xfff - (longlong)iStack_328) * 2) + lVar3)
  ;
  if ((*pbStack_240 & 1) == 0) {
    uStack_248 = 0;
    uStack_244 = 0;
    uStack_222 = 0;
    uStack_220 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010086e */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_240 & 0xe) * 4 + 0x1031e4) - 0xe94590))
              ((longlong)(int)(*pbStack_240 & 0xe),0x1685fa0,pbStack_240,9);
    return;
  }
  uStack_248 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_240 & 0x1c) + 0x1031c4) * 4
                         + 0x1031b4) - 0xe94590);
                    /* WARNING: Could not emulate address calculation at 0x0010064f */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

