
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(undefined8 param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  ushort *puVar2;
  byte bVar3;
  char cVar4;
  ushort uVar5;
  int iVar6;
  longlong lVar7;
  undefined8 uVar8;
  uint uVar9;
  undefined4 uVar10;
  ulonglong uVar11;
  uint uVar12;
  uint uVar13;
  ulonglong uVar14;
  ushort uVar15;
  ushort uVar16;
  byte *pbVar17;
  ulonglong uVar18;
  ulonglong uVar19;
  int iVar20;
  ushort *puVar21;
  uint uStackX_20;
  uint uStack_78;
  ulonglong uStack_70;
  longlong lStack_68;
  undefined auStack_60 [8];
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined2 uStack_50;
  undefined2 uStack_4e;
  
  uStack_78 = 0xffffffff;
  iVar20 = 0;
  uStack_70 = 0;
  iVar6 = func_0x(param_3 + 0xa0);
  if (0 < iVar6) {
    lStack_68 = 0;
    do {
      uVar19 = 0;
      if (*(int *)(param_3 + 0xa4) == 0) {
        pbVar17 = *(byte **)(param_3 + 0xa8);
        uVar9 = *(uint *)(param_3 + 0xb0);
        uVar11 = (ulonglong)uVar9;
        *(undefined2 *)(param_3 + 0xa2) = 0;
        *(uint *)(param_3 + 0xb4) = uVar9;
        bVar3 = *pbVar17;
        if ((bVar3 & 0x10) != 0) {
          uVar9 = uVar9 + 2 + (*(ushort *)(pbVar17 + uVar11) + 7 >> 3);
          uVar11 = (ulonglong)uVar9;
          *(uint *)(param_3 + 0xb4) = uVar9;
          bVar3 = *pbVar17;
        }
        if ((bVar3 & 0x20) == 0) {
          *(int *)(param_3 + 0xa4) = (int)uVar11;
          *(undefined2 *)(param_3 + 0xbc) = 0;
          *(int *)(param_3 + 0xb8) = (int)uVar11;
        }
        else {
          puVar21 = (ushort *)(pbVar17 + uVar11);
          uVar5 = *puVar21;
          *(ushort *)(param_3 + 0xbc) = uVar5;
          if (uVar5 == 0) {
            cVar4 = func_0x(0x149c210);
            if (((cVar4 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
               (*(char *)(lVar7 + 0x499) != '\0')) {
              cVar4 = func_0x(0x149c210);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0xd8bc1c,0xeabd08,0x80f,0);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 0xa8),3);
            uVar11 = (ulonglong)*(uint *)(param_3 + 0xb4);
            uVar5 = *(ushort *)(param_3 + 0xbc);
          }
          uVar9 = (int)uVar11 + (uVar5 + 1) * 2;
          *(uint *)(param_3 + 0xb8) = uVar9;
          if (0x1f9e < uVar9) {
            cVar4 = func_0x(0x149c210);
            if (((cVar4 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
               (*(char *)(lVar7 + 0x499) != '\0')) {
              cVar4 = func_0x(0x149c210);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0xd8bc1c,0xeabd08,0x816,0);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 0xa8),4);
            uVar5 = *(ushort *)(param_3 + 0xbc);
            uVar9 = *(uint *)(param_3 + 0xb8);
          }
          uVar11 = (ulonglong)uVar5;
          uVar5 = puVar21[uVar11];
          *(uint *)(param_3 + 0xa4) = uVar5 & 0x7fff;
          if ((uVar5 & 0x7fff) < uVar9) {
            cVar4 = func_0x(0x149c210);
            if (((cVar4 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
               (*(char *)(lVar7 + 0x499) != '\0')) {
              cVar4 = func_0x(0x149c210);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0xd8bc1c,0xeabd08,0x81d,0);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 0xa8),4);
            uVar9 = *(uint *)(param_3 + 0xb8);
            uVar11 = (ulonglong)*(ushort *)(param_3 + 0xbc);
          }
          uVar14 = uVar19;
          puVar2 = puVar21;
          if ((short)uVar11 != 0) {
            do {
              uVar13 = puVar2[1] & 0x7fff;
              if ((uVar13 < uVar9) || (*(uint *)(param_3 + 0xa4) < uVar13)) {
                cVar4 = func_0x(0x149c210);
                if ((cVar4 != '\0') &&
                   ((lVar7 = func_0x(), lVar7 != 0 &&
                    (*(char *)(lVar7 + 0x499) != '\0')))) {
                  cVar4 = func_0x(0x149c210);
                  if (cVar4 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    (*_DAT_)(1,0xd8bc1c,0xeabd08,0x82a,0);
                  }
                }
                func_0x(*(undefined8 *)(param_3 + 0xa8),4);
              }
              uVar11 = (ulonglong)*(ushort *)(param_3 + 0xbc);
              uVar12 = (int)uVar14 + 1;
              uVar14 = (ulonglong)uVar12;
              puVar2 = puVar2 + 1;
              uVar9 = uVar13;
            } while ((int)uVar12 < (int)(uint)*(ushort *)(param_3 + 0xbc));
          }
          if ((short)puVar21[(ulonglong)((int)uVar11 - 1) + 1] < 0) {
            pbVar17 = *(byte **)(param_3 + 0xa8);
            do {
              uVar9 = *(ushort *)(pbVar17 + uVar11 * 2 + (ulonglong)*(uint *)(param_3 + 0xb4)) &
                      0x7fff;
              if ((int)uVar11 == 1) {
                uVar13 = *(uint *)(param_3 + 0xb8);
                uVar14 = (ulonglong)uVar13;
LAB_:
                if ((uVar9 < (uint)uVar14) || (*(uint *)(param_3 + 0xa4) < uVar9))
                goto LAB_;
              }
              else {
                uVar13 = *(uint *)(param_3 + 0xb8);
                uVar14 = (ulonglong)
                         (*(ushort *)
                           (pbVar17 + uVar11 * 2 + ((ulonglong)*(uint *)(param_3 + 0xb4) - 2)) &
                         0x7fff);
                if (uVar13 <= (*(ushort *)
                                (pbVar17 + uVar11 * 2 + ((ulonglong)*(uint *)(param_3 + 0xb4) - 2))
                              & 0x7fff)) goto LAB_;
LAB_:
                func_0x(pbVar17,7);
                uVar13 = *(uint *)(param_3 + 0xb8);
              }
              uVar12 = (uint)uVar14;
              if ((uVar12 < uVar13) || (*(uint *)(param_3 + 0xa4) < uVar12)) goto LAB_;
              pbVar17 = *(byte **)(param_3 + 0xa8);
              if (*(ushort *)(pbVar17 + uVar14) == 5) {
                *(ushort *)(param_3 + 0xa2) = *(ushort *)(param_3 + 0xa2) | 2;
                *(short *)(param_3 + 0xbc) = *(short *)(param_3 + 0xbc) + -1;
                uVar5 = *(ushort *)(param_3 + 0xcc) & 0xc7ff;
                uVar18 = uVar14 & 0xffff;
                *(short *)(param_3 + 0xca) = (short)uVar14;
                uVar11 = *(ulonglong *)(param_3 + 0xa8);
                if ((*(ushort *)(uVar18 + 2 + uVar11) >> 0xe & 1) != 0) {
                  uVar5 = *(ushort *)(uVar18 + 2 + uVar11) & 0x3800 | uVar5;
                }
                *(ushort *)(param_3 + 0xcc) = uVar5;
                uVar16 = (uVar5 ^ *(ushort *)(uVar18 + 2 + uVar11)) & 0x7ff ^ uVar5;
                *(ushort *)(param_3 + 0xcc) = uVar16;
                uVar14 = uVar11 + 4 +
                         (ulonglong)((uVar16 & 0x7ff) * 2) + uVar18 + (uVar5 >> 0xb & 7) * 2;
                if (uVar14 < uVar18 + uVar11) {
                  func_0x(uVar18 + uVar11,0x19);
                  uVar16 = *(ushort *)(param_3 + 0xcc);
                  uVar18 = (ulonglong)*(ushort *)(param_3 + 0xca);
                  uVar11 = (ulonglong)*(uint *)(param_3 + 0xa8);
                }
                if (uVar9 - uVar12 <
                    (((uVar16 & 0x7ff) * 2 - (int)uVar18) - (int)uVar11) + (int)uVar14) {
                  func_0x(uVar18 + *(longlong *)(param_3 + 0xa8),0x19);
                  uVar16 = *(ushort *)(param_3 + 0xcc);
                }
                if ((uVar16 & 0x3800) != 0) {
                  puVar21 = (ushort *)
                            (*(longlong *)(param_3 + 0xa8) +
                            (ulonglong)*(ushort *)(param_3 + 0xca) + 4);
                  iVar6 = 0;
                  if ((uVar16 & 0x3800) != 0) {
                    do {
                      if ((uVar16 & 0x7ff) < (*puVar21 & 0x7ff)) {
                        func_0x((ulonglong)*(ushort *)(param_3 + 0xca) +
                                        *(longlong *)(param_3 + 0xa8),0x1a);
                        uVar16 = *(ushort *)(param_3 + 0xcc);
                      }
                      iVar6 = iVar6 + 1;
                      puVar21 = puVar21 + 1;
                    } while (iVar6 < (int)(uVar16 >> 0xb & 7));
                  }
                }
                goto LAB_;
              }
              if (*(ushort *)(pbVar17 + uVar14) < 0x400) goto LAB_;
              *(ushort *)(param_3 + 0xa2) = *(ushort *)(param_3 + 0xa2) | 1;
              uVar5 = *(short *)(param_3 + 0xbc) - 1;
              *(ushort *)(param_3 + 0xbc) = uVar5;
              if (uVar5 == 0) goto LAB_;
              uVar11 = (ulonglong)uVar5;
            } while ((short)puVar21[(ulonglong)(uVar5 - 1) + 1] < 0);
            uVar11 = (ulonglong)*(uint *)(param_3 + 0xa4);
          }
          else {
LAB_:
            pbVar17 = *(byte **)(param_3 + 0xa8);
            uVar11 = (ulonglong)*(uint *)(param_3 + 0xa4);
          }
        }
        if ((*pbVar17 & 0x40) == 0) {
          *(undefined4 *)(param_3 + 0xc6) = 0;
        }
        else {
          *(int *)(param_3 + 0xc6) = (int)uVar11;
          *(int *)(param_3 + 0xa4) = (int)uVar11 + 0xe;
          uVar8 = func_0x(param_3 + 0xa2);
          func_0x(uVar8,auStack_60);
          iVar6 = func_0x(auStack_60);
          *(int *)(param_3 + 0xa4) = *(int *)(param_3 + 0xa4) + iVar6;
          uVar11 = (ulonglong)*(uint *)(param_3 + 0xa4);
        }
        iVar6 = (int)uVar11;
        if ((*(ulonglong *)(param_3 + 0xbe) != 0) &&
           (*(ulonglong *)(param_3 + 0xbe) < uVar11 + *(longlong *)(param_3 + 0xa8))) {
          cVar4 = func_0x(0x149c210);
          if ((cVar4 != '\0') &&
             ((lVar7 = func_0x(), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0')))
             ) {
            cVar4 = func_0x(0x149c210);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              (*_DAT_)(1,0xd8bc1c,0xeabd08,0x886,0);
            }
          }
          func_0x(*(undefined8 *)(param_3 + 0xa8));
          iVar6 = *(int *)(param_3 + 0xa4);
        }
        if (0x3f3b < iVar6 - 1U) {
          cVar4 = func_0x(0x149c210);
          if (((cVar4 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
             (*(char *)(lVar7 + 0x499) != '\0')) {
            cVar4 = func_0x(0x149c210);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              (*_DAT_)(1,0xd8bc1c,0xeabd08,0x88b,0);
            }
          }
          func_0x(*(undefined8 *)(param_3 + 0xa8));
        }
      }
LAB_:
      iVar6 = func_0x(param_3 + 0xa2);
      uStackX_20 = uStack_78;
      if (iVar6 == 0) {
        iVar6 = func_0x(param_3 + 0xa2);
        if (iVar6 == 0) {
          (*_DAT_)(1,0xf47938,0xf389c8,0xd7a,0);
        }
      }
      else {
        uVar19 = 0;
        if (-1 < lStack_68) {
          uVar5 = *(ushort *)(param_3 + 0xcc);
          if (iVar20 < (int)(uVar5 & 0x7ff)) {
            uVar11 = (ulonglong)*(ushort *)(param_3 + 0xca);
            lVar1 = *(longlong *)(param_3 + 0xa8);
            uVar16 = 0;
            lVar7 = lVar1 + uVar11;
            if ((uVar5 & 0x3800) == 0) {
              uVar15 = *(ushort *)(lVar7 + 2);
LAB_:
              uVar16 = uVar15 >> 0xb & 7;
            }
            else if ((uVar5 >> 0xb & 7) != 0) {
              do {
                if (uVar19 == 0) {
                  uVar9 = 0;
                }
                else {
                  uVar9 = *(ushort *)(lVar7 + 2 + uVar19 * 2) & 0x7ff;
                }
                if (((int)uVar9 <= iVar20) &&
                   (uVar15 = *(ushort *)(lVar7 + 4 + uVar19 * 2),
                   iVar20 <= (int)((uVar15 & 0x7ff) - 1))) goto LAB_;
                uVar19 = uVar19 + 1;
              } while ((longlong)uVar19 < (longlong)(ulonglong)(uVar5 >> 0xb & 7));
            }
            uVar13 = uVar5 >> 0xb & 7;
            uVar19 = (ulonglong)(uVar13 * 2);
            uStackX_20 = (uint)*(ushort *)(uVar19 + (lStack_68 + 2) * 2 + lVar1 + uVar11) +
                         (uint)uVar16 * 0x10000;
            uVar9 = (uVar5 & 0x7ff) * 2;
            if (lStack_68 == 0) {
              uVar19 = (ulonglong)((uVar9 + uVar13) * 2 + 4) + lVar7;
            }
            else {
              uVar19 = (ulonglong)
                       (*(ushort *)(uVar19 + uVar9 + (lStack_68 + 1) * 2 + lVar1 + uVar11) & 0x7fff)
                       + lVar7;
            }
            goto LAB_;
          }
        }
        (*_DAT_)(1,0xf47908,0xf478d0,0x41a,0);
      }
LAB_:
      uVar11 = (ulonglong)uStackX_20;
      lVar7 = func_0x
                        (**(undefined8 **)(*(longlong *)(*(longlong *)(param_2 + 0x80) + 8) + 0x160)
                        );
      if (lVar7 == 0) {
        uVar8 = 0xe6d4a0;
        uVar10 = 0x16;
LAB_:
        uStack_70 = 0;
code_r0x00100947:
        uStack_58 = *(undefined4 *)(param_3 + 0x154);
        uStack_54 = *(undefined4 *)(param_3 + 0x158);
        uStack_50 = *(undefined2 *)(param_3 + 0x15c);
        uStack_4e = *(undefined2 *)(param_3 + 0x15e);
        func_0x(&uStack_58,*(undefined4 *)(param_3 + 0xd4),param_3 + 0x60,uVar8,uVar10,
                        uVar11,uStack_70);
        func_0x(param_1,2,param_3 + 0x60);
        return 0;
      }
      if (-1 < *(char *)(lVar7 + 0x21)) {
        uVar8 = 0xe6d400;
        uVar10 = 0x17;
        goto LAB_;
      }
      if (lStack_68 != 0) {
        if (uStackX_20 <= uStack_78) {
          uVar8 = 0xe6d430;
          uVar10 = 0x18;
          uStack_70 = uVar11;
          uVar11 = (ulonglong)uStack_78;
          goto code_r0x00100947;
        }
        if (uVar19 < uStack_70) {
          uVar8 = 0xe6d4d0;
          uVar10 = 0x19;
          uVar11 = uVar19;
          goto code_r0x00100947;
        }
      }
      lStack_68 = lStack_68 + 1;
      uStack_78 = uStackX_20;
      iVar20 = iVar20 + 1;
      iVar6 = func_0x(param_3 + 0xa0);
      uStack_70 = uVar19;
    } while (iVar20 < iVar6);
  }
  return 1;
}

