
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x001003c8) */
/* WARNING: Removing unreachable block (ram,0x01ced860) */
/* WARNING: Removing unreachable block (ram,0xffffffffffffcaa2) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4)

{
  uint *puVar1;
  byte bVar2;
  char cVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  undefined *puVar7;
  short *psVar8;
  byte *pbVar9;
  undefined8 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  uint uVar13;
  uint uVar14;
  longlong lVar15;
  int iVar16;
  undefined8 unaff_RBX;
  uint *puVar17;
  longlong lVar18;
  undefined *puVar19;
  ushort *puVar20;
  short *psVar21;
  uint uVar22;
  ulonglong uVar23;
  undefined4 *puVar24;
  short *psVar25;
  longlong lVar26;
  ushort uVar27;
  short *psVar28;
  undefined8 *puVar29;
  int aiStackX_8 [4];
  ulonglong auStackX_18 [2];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar15 = func_0x();
  lVar15 = -lVar15;
  puVar19 = &stack0xffffffffffffffc8 + lVar15;
  puVar1 = (uint *)(&stack0xfffffffffffffff8 + lVar15);
  *(undefined8 *)(&stack0x00000180 + lVar15) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000021a0 + lVar15) = unaff_RBX;
  *(ulonglong *)(&stack0x00002148 + lVar15) = _DAT_ ^ (ulonglong)puVar1;
  *(undefined4 *)(&stack0x00000090 + lVar15) = param_4;
  *(undefined8 *)(&stack0x00000128 + lVar15) = param_3;
  *(undefined4 *)((longlong)auStackX_18 + lVar15) = param_2;
  *(undefined8 *)(&stack0x000000c0 + lVar15) = param_1;
  *(undefined4 *)(&stack0x00000038 + lVar15) = *(undefined4 *)(&stack0x000021c0 + lVar15);
  iVar16 = *(int *)(&stack0x000021b8 + lVar15);
  psVar25 = *(short **)(&stack0x000021d0 + lVar15);
  *(short **)(&stack0x00000088 + lVar15) = psVar25;
  lVar26 = *(longlong *)(&stack0x000021d8 + lVar15);
  *(longlong *)(&stack0x00000140 + lVar15) = lVar26;
  *(undefined8 *)(&stack0x00000080 + lVar15) = *(undefined8 *)(&stack0x000021e0 + lVar15);
  *(undefined8 *)(&stack0x00000130 + lVar15) = *(undefined8 *)(&stack0x000021e8 + lVar15);
  *(undefined8 *)(&stack0x000000d8 + lVar15) = *(undefined8 *)(&stack0x000021f8 + lVar15);
  *(undefined8 *)(&stack0x000000a0 + lVar15) = *(undefined8 *)(&stack0x00002200 + lVar15);
  *(undefined8 *)(&stack0x00000048 + lVar15) = *(undefined8 *)(&stack0x00002208 + lVar15);
  *(undefined8 *)((longlong)auStackX_18 + lVar15 + -0x18) =
       *(undefined8 *)(&stack0x00002210 + lVar15);
  *(undefined8 *)(&stack0x000000a8 + lVar15) = *(undefined8 *)(&stack0x00002218 + lVar15);
  *(undefined8 *)(&stack0x00000098 + lVar15) = *(undefined8 *)(&stack0x00002230 + lVar15);
  *(undefined8 *)(&stack0x000000e0 + lVar15) = *(undefined8 *)(&stack0x00002238 + lVar15);
  *(undefined8 *)(&stack0x00000110 + lVar15) = *(undefined8 *)(&stack0x00002248 + lVar15);
  puVar24 = *(undefined4 **)(&stack0x00002250 + lVar15);
  *(undefined4 **)(&stack0x00000108 + lVar15) = puVar24;
  puVar17 = *(uint **)(&stack0x00002258 + lVar15);
  *(uint **)(&stack0x000000d0 + lVar15) = puVar17;
  *(undefined8 *)(&stack0x00000138 + lVar15) = *(undefined8 *)(&stack0x00002268 + lVar15);
  *(undefined8 *)(&stack0x00000120 + lVar15) = *(undefined8 *)(&stack0x00002270 + lVar15);
  *(undefined8 *)(&stack0x00000118 + lVar15) = *(undefined8 *)(&stack0x00002278 + lVar15);
  *(undefined8 *)((longlong)auStackX_18 + lVar15 + 8) = 0;
  *(undefined8 *)(&stack0x00000030 + lVar15) = 0;
  *(undefined2 *)(&stack0x00000148 + lVar15) = 0xffff;
  *(undefined8 *)(&stack0x00000150 + lVar15) = 0;
  *(undefined4 *)(&stack0x0000014c + lVar15) = 0;
  *(undefined8 *)(&stack0x00000166 + lVar15) = 0;
  *(undefined8 *)(&stack0x00000170 + lVar15) = 0;
  *(undefined8 *)(&stack0x00000158 + lVar15) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10019e;
  func_0x(&stack0x000001a8 + lVar15,0,0x1f9e);
  *(undefined4 *)(&stack0x00000044 + lVar15) = 0;
  *(undefined4 *)((longlong)aiStackX_8 + lVar15) = 1;
  *(undefined8 *)(&stack0x000000c8 + lVar15) = 0;
  *(undefined4 *)(&stack0x00000050 + lVar15) = 0;
  *puVar24 = 0;
  if (lVar26 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)(&stack0x00000100 + lVar15) = 0;
  *(undefined8 *)(&stack0x000000e8 + lVar15) = 0;
  *(short **)(&stack0x00000058 + lVar15) = psVar25 + 1;
  if (*psVar25 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1001f7;
  uVar13 = func_0x(psVar25 + 1);
  uVar14 = uVar13;
  if (uVar13 <= (uint)-iVar16) {
    uVar14 = -iVar16;
  }
  bVar2 = **(byte **)(psVar25 + 4);
  if (*psVar25 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(uint *)((longlong)aiStackX_8 + lVar15 + 4) = uVar14;
  if ((1 << (bVar2 & 0xe) & 0x1105U) != 0) {
    *(undefined8 *)(&stack0x000000c8 + lVar15) =
         *(undefined8 *)(*(longlong *)(&stack0x00000080 + lVar15) + 0x28);
    iVar16 = *(int *)(*(longlong *)(&stack0x00000080 + lVar15) + 0x30);
    *(int *)(&stack0x00000050 + lVar15) = iVar16;
    *(uint *)((longlong)aiStackX_8 + lVar15 + 4) = uVar14;
    if (iVar16 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100259;
  uVar14 = func_0x(psVar25);
  *(uint *)((longlong)aiStackX_8 + lVar15 + 8) = uVar14;
  *(uint *)(&stack0x0000003c + lVar15) = uVar14;
  *puVar1 = *(int *)(&stack0x00000090 + lVar15) + uVar14;
  *(undefined4 *)(&stack0x00000040 + lVar15) = 9;
  if (puVar17 == (uint *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar22 = *(uint *)(psVar25 + 2);
  if (*psVar25 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (uVar22 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (uVar22 < 9) {
    if ((**(byte **)(psVar25 + 4) & 0xe) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar22 = 9;
  }
  puVar7 = *(undefined **)(&stack0x000000a8 + lVar15);
  psVar25 = *(short **)(&stack0x00000088 + lVar15);
  *puVar17 = uVar22;
  puVar17[1] = uVar13;
  puVar17[2] = uVar14;
  *(undefined8 *)(puVar17 + 3) = 0;
  if (*psVar25 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(short **)(&stack0x00000070 + lVar15) = psVar25;
  psVar8 = *(short **)((longlong)auStackX_18 + lVar15 + -0x18);
  *psVar8 = 0;
  *(short **)(&stack0x00000068 + lVar15) = psVar25 + 1;
  psVar21 = psVar8 + 1;
  *(short **)(&stack0x00000078 + lVar15) = psVar21;
  *(undefined **)(psVar8 + 4) = puVar7;
  *(undefined4 *)(psVar8 + 8) = *(undefined4 *)(&stack0x000021c8 + lVar15);
  psVar8[0xe] = 0;
  *psVar21 = 0;
  *(undefined4 *)(psVar8 + 0x13) = 0;
  if ((**(byte **)(psVar25 + 4) & 0xe) == 6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar7 = 0;
  *(undefined *)(*(longlong *)(psVar8 + 4) + 1) = 0;
  *(short *)(*(longlong *)(psVar8 + 4) + 2) = (short)*(undefined4 *)(psVar8 + 8);
  uVar14 = *(uint *)(psVar25 + 8);
  if (*(uint *)(psVar8 + 8) <= uVar14) {
    uVar14 = *(uint *)(psVar8 + 8);
  }
  lVar26 = *(longlong *)(psVar25 + 4);
  lVar18 = *(longlong *)(psVar8 + 4);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100382;
  func_0x(lVar18 + 4,lVar26 + 4,uVar14 - 4);
  uVar14 = *(uint *)(&stack0x00000038 + lVar15);
  if (uVar14 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  **(byte **)(psVar8 + 4) = **(byte **)(psVar8 + 4) | 0x10;
  uVar13 = *(uint *)(psVar8 + 8);
  iVar16 = uVar13 + 2 + (uVar14 + 7 >> 3);
  *(int *)(psVar8 + 10) = iVar16;
  pbVar9 = *(byte **)(psVar25 + 4);
  if ((*pbVar9 & 0x10) == 0) {
    *(short *)(*(longlong *)(psVar8 + 4) + (ulonglong)uVar13) = (short)uVar14;
    uVar27 = 1;
    uVar13 = 1;
    if (uVar14 != 0) {
      do {
        uVar23 = (ulonglong)(uVar13 - 1 >> 3);
        *(byte *)(uVar23 + 2 + (longlong)*(int *)(psVar8 + 8) + *(longlong *)(psVar8 + 4)) =
             *(byte *)(uVar23 + 2 + (longlong)*(int *)(psVar8 + 8) + *(longlong *)(psVar8 + 4)) |
             (byte)(1 << (uVar13 - 1 & 7));
        uVar27 = uVar27 + 1;
        uVar13 = (uint)uVar27;
      } while (uVar13 <= uVar14);
    }
    psVar28 = *(short **)((longlong)auStackX_18 + lVar15 + -0x18);
    *(undefined4 *)(psVar8 + 0xc) = *(undefined4 *)(psVar8 + 10);
    *(undefined4 *)(psVar8 + 2) = *(undefined4 *)(psVar8 + 10);
  }
  else {
    if (*(ushort *)(pbVar9 + *(uint *)(psVar25 + 8)) != uVar14) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar14 = *(uint *)(psVar25 + 8);
    lVar26 = *(longlong *)(psVar8 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10044e;
    func_0x(lVar26 + (ulonglong)uVar13,pbVar9 + uVar14,iVar16 - uVar13);
    *(undefined4 *)(psVar8 + 0xc) = *(undefined4 *)(psVar8 + 10);
    *(undefined4 *)(psVar8 + 2) = *(undefined4 *)(psVar8 + 10);
    psVar28 = psVar8;
  }
  uVar14 = *(uint *)(psVar8 + 2);
  if (*psVar28 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (uVar14 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (uVar14 < 9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  psVar28 = *(short **)(&stack0x00000070 + lVar15);
  **(uint **)(&stack0x00000098 + lVar15) = uVar14;
  **(undefined4 **)(&stack0x000000e0 + lVar15) = 0;
  uVar14 = *(uint *)((longlong)aiStackX_8 + lVar15 + 4);
  if (uVar14 != 0) {
    uVar23 = (ulonglong)uVar14 * 0x20;
    if (uVar23 + 0xf <= uVar23) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1004d6;
    func_0x();
    lVar26 = -uVar23;
    puVar19 = &stack0xffffffffffffffc8 + lVar26 + lVar15;
    puVar7 = &stack0xfffffffffffffff8 + lVar26 + lVar15;
    *(undefined **)((longlong)auStackX_18 + lVar15 + 8) = puVar7;
    *(undefined8 *)((longlong)&uStack_40 + lVar26 + lVar15) = 0x1004f3;
    func_0x(puVar7,0,uVar14 << 5);
    if (*psVar28 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(psVar25 + 2) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar14 = *(uint *)((longlong)aiStackX_8 + lVar15 + 4);
    uVar13 = (uint)(ushort)psVar25[0xe];
    if (uVar14 <= (ushort)psVar25[0xe]) {
      uVar13 = uVar14;
    }
    *(uint *)(&stack0x00000060 + lVar15) = uVar13;
    if (uVar13 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar26 + lVar15) = 0x100537;
    func_0x(puVar7,0,uVar14 * 0x20);
  }
  if (*puVar1 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)((longlong)aiStackX_8 + lVar15 + 4) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar29 = *(undefined8 **)(&stack0x000000a0 + lVar15);
  if (puVar29 != (undefined8 *)0x0) {
    uVar4 = *(undefined4 *)(puVar29 + 1);
    uVar10 = *puVar29;
    *(undefined8 *)(puVar19 + -8) = 0x10057f;
    func_0x(uVar10,0,uVar4);
  }
  psVar25 = *(short **)((longlong)auStackX_18 + lVar15 + -0x18);
  if (*(int *)(&stack0x00002240 + lVar15) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  **(undefined4 **)(&stack0x00000048 + lVar15) = 0;
  if (*(longlong *)(&stack0x000000c8 + lVar15) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar13 = 0;
  *puVar1 = 0;
  uVar14 = *(uint *)((longlong)auStackX_18 + lVar15);
  if (uVar14 != 0) {
    lVar26 = *(longlong *)(&stack0x00000128 + lVar15) + 0x38;
    *(longlong *)(&stack0x00000058 + lVar15) = lVar26;
    uVar23 = (ulonglong)uVar14;
    *(ulonglong *)((longlong)auStackX_18 + lVar15) = (ulonglong)uVar14;
    do {
      if (*(char *)(lVar26 + 8) != '\0') {
        iVar16 = *(int *)(lVar26 + -0x38);
        if (iVar16 < 1) {
          if ((-1 < iVar16) || ((*(ushort *)(*(longlong *)(lVar26 + 0x10) + 0xc) & 0x400) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          lVar18 = (ulonglong)uVar13 * 0x40 +
                   *(longlong *)(*(longlong *)(&stack0x000000d8 + lVar15) + 8);
          uVar14 = *(uint *)(lVar18 + 8);
          if ((*(ushort *)(lVar18 + 0xc) != 0) &&
             ((uint)*(ushort *)(lVar18 + 0xc) <= *(uint *)(&stack0x00000038 + lVar15))) {
            if ((*(byte *)(lVar18 + 0x18) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            if (*psVar25 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            uVar22 = *(ushort *)(lVar18 + 0xc) - 1;
            uVar23 = (ulonglong)(uVar22 >> 3);
            *(byte *)((longlong)*(int *)(psVar25 + 8) + *(longlong *)(psVar25 + 4) + 2 + uVar23) =
                 *(byte *)((longlong)*(int *)(psVar25 + 8) + *(longlong *)(psVar25 + 4) + 2 + uVar23
                          ) & ~(byte)(1 << (uVar22 & 7));
          }
          puVar24 = (undefined4 *)
                    ((longlong)(int)~uVar14 * 0x20 +
                    *(longlong *)((longlong)auStackX_18 + lVar15 + 8));
          if ((*(byte *)(puVar24 + 3) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((*(int *)(&stack0x00000044 + lVar15) == 0) &&
             (*(uint *)(lVar18 + 0x28) <= (uint)puVar24[2])) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *(undefined4 *)(&stack0x00000044 + lVar15) = 1;
          uVar4 = *(undefined4 *)(lVar18 + 0x24);
          uVar11 = *(undefined4 *)(lVar18 + 0x28);
          uVar12 = *(undefined4 *)(lVar18 + 0x2c);
          *puVar24 = *(undefined4 *)(lVar18 + 0x20);
          puVar24[1] = uVar4;
          puVar24[2] = uVar11;
          puVar24[3] = uVar12;
          uVar4 = *(undefined4 *)(lVar18 + 0x34);
          uVar11 = *(undefined4 *)(lVar18 + 0x38);
          uVar12 = *(undefined4 *)(lVar18 + 0x3c);
          puVar24[4] = *(undefined4 *)(lVar18 + 0x30);
          puVar24[5] = uVar4;
          puVar24[6] = uVar11;
          puVar24[7] = uVar12;
          uVar13 = uVar13 + 1;
          *puVar1 = uVar13;
        }
        else {
          uVar14 = *(uint *)(lVar26 + 8);
          if ((uVar14 >> 10 & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((*(byte *)(*(longlong *)(lVar26 + 0x10) + 0x2a) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          cVar3 = *(char *)(*(longlong *)(*(longlong *)(&stack0x00000080 + lVar15) + 0x18) +
                           *(longlong *)(lVar26 + -8));
          if (cVar3 == '\x03') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((uVar14 & 0x8000) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((uVar14 >> 8 & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((*(byte *)(*(longlong *)(lVar26 + 0x10) + 0x2a) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          uVar13 = *(uint *)(*(longlong *)(*(longlong *)(&stack0x00000080 + lVar15) + 0x18) +
                            *(longlong *)(*(longlong *)(lVar26 + 0x10) + 0x18));
          if ((uVar14 & 0x48000) == 0x48000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((*(byte *)(*(longlong *)(lVar26 + 0x10) + 0x2a) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          puVar29 = (undefined8 *)
                    (*(longlong *)(lVar26 + -0x10) +
                    *(longlong *)(*(longlong *)(&stack0x00000080 + lVar15) + 0x18));
          if ((uVar14 >> 0xb & 1) != 0) {
            puVar29 = (undefined8 *)*puVar29;
          }
          uVar27 = *(ushort *)(lVar26 + -0x34);
          if ((uVar27 != 0) && ((uint)uVar27 <= *(uint *)(&stack0x00000038 + lVar15))) {
            psVar25 = *(short **)((longlong)auStackX_18 + lVar15 + -0x18);
            if (cVar3 == '\x03') {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            if (*psVar25 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            uVar23 = (ulonglong)(uVar27 - 1 >> 3);
            *(byte *)(uVar23 + 2 + *(longlong *)(psVar25 + 4) + (longlong)*(int *)(psVar25 + 8)) =
                 *(byte *)(uVar23 + 2 + *(longlong *)(psVar25 + 4) + (longlong)*(int *)(psVar25 + 8)
                          ) & ~(byte)(1 << (uVar27 - 1 & 7));
          }
          if (puVar29 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (*(char *)(lVar26 + 8) != '\x01') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          uVar27 = *(ushort *)(lVar26 + 4);
          if (uVar27 < uVar13) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          iVar16 = *(int *)(lVar26 + -0x38);
          lVar26 = *(longlong *)(*(longlong *)((longlong)auStackX_18 + lVar15 + -0x18) + 8);
          if (uVar13 != 0) {
            *(undefined8 *)(puVar19 + -8) = 0x100754;
            func_0x(iVar16 + lVar26,puVar29,uVar13);
          }
          if (uVar27 != uVar13) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          lVar26 = *(longlong *)(&stack0x00000058 + lVar15);
          psVar25 = *(short **)((longlong)auStackX_18 + lVar15 + -0x18);
          uVar13 = *puVar1;
        }
        uVar23 = *(ulonglong *)((longlong)auStackX_18 + lVar15);
      }
      lVar26 = lVar26 + 0x50;
      *(longlong *)(&stack0x00000058 + lVar15) = lVar26;
      uVar23 = uVar23 - 1;
      *(ulonglong *)((longlong)auStackX_18 + lVar15) = uVar23;
    } while (uVar23 != 0);
  }
  puVar20 = (ushort *)0x0;
  if (*(longlong *)(&stack0x00000130 + lVar15) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar14 = *(uint *)(&stack0x00002228 + lVar15);
  uVar13 = *(uint *)((longlong)aiStackX_8 + lVar15 + 4);
  psVar25 = *(short **)((longlong)auStackX_18 + lVar15 + -0x18);
  if (uVar13 != 0) {
    if (*psVar25 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar26 = *(longlong *)((longlong)auStackX_18 + lVar15 + 8);
    uVar23 = (ulonglong)uVar13;
    if (*(int *)((ulonglong)(uVar13 - 1) * 0x20 + 8 + lVar26) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    psVar25[0xe] = (ushort)uVar13;
    iVar16 = *(int *)(psVar25 + 10) + 2 + uVar13 * 2;
    *(int *)(psVar25 + 0xc) = iVar16;
    *(int *)(psVar25 + 2) = iVar16;
    **(byte **)(psVar25 + 4) = **(byte **)(psVar25 + 4) | 0x20;
    uVar22 = *(uint *)(psVar25 + 2);
    if (uVar22 <= uVar14) {
      puVar20 = (ushort *)((ulonglong)*(uint *)(psVar25 + 10) + *(longlong *)(psVar25 + 4));
      *puVar20 = (ushort)uVar13;
      uVar22 = *(uint *)(psVar8 + 2);
    }
    uVar5 = *(uint *)(&stack0x00002220 + lVar15);
    if (uVar13 != 0) {
      puVar17 = (uint *)(lVar26 + 0xc);
      do {
        puVar20 = puVar20 + 1;
        uVar13 = *(uint *)(psVar25 + 2);
        lVar26 = *(longlong *)(psVar25 + 4);
        uVar6 = puVar17[-1];
        uVar22 = uVar13 + uVar6;
        *(uint *)(psVar25 + 2) = uVar22;
        if ((uVar22 <= uVar14) && (uVar22 <= uVar5)) {
          *puVar20 = (ushort)((*puVar17 & 1) << 0xf) | (ushort)uVar22 & 0x7fff;
          uVar10 = *(undefined8 *)(puVar17 + -3);
          *(undefined8 *)(puVar19 + -8) = 0x100892;
          func_0x((ulonglong)uVar13 + lVar26,uVar6,uVar10,uVar6);
          psVar25 = *(short **)((longlong)auStackX_18 + lVar15 + -0x18);
          uVar22 = *(uint *)(psVar25 + 2);
        }
        puVar17 = puVar17 + 8;
        uVar23 = uVar23 - 1;
      } while (uVar23 != 0);
      psVar21 = psVar25 + 1;
    }
    **(uint **)(&stack0x00000098 + lVar15) = uVar22;
    uVar13 = *(uint *)(psVar25 + 2);
    if ((uVar14 < uVar13) || (*(undefined4 *)((longlong)aiStackX_8 + lVar15) = 1, uVar5 < uVar13)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  if (*(int *)(&stack0x0000003c + lVar15) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)((longlong)aiStackX_8 + lVar15) != 0) {
    if (**(short **)((longlong)auStackX_18 + lVar15 + -0x18) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar14 = *(uint *)(psVar21 + 1);
    if (uVar14 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (uVar14 < 9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(uint *)(&stack0x00000040 + lVar15) = uVar14;
    **(undefined4 **)(&stack0x00000098 + lVar15) = *(undefined4 *)(&stack0x00000040 + lVar15);
  }
  if (*(longlong *)(&stack0x00000140 + lVar15) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((((*(byte *)(**(longlong **)(&stack0x00000080 + lVar15) + 0x5c) & 0x20) != 0) &&
      (*(int *)(&stack0x00000044 + lVar15) != 0)) &&
     ((lVar26 = *(longlong *)(*(longlong *)(*(longlong *)(&stack0x000000c0 + lVar15) + 0x18) + 8),
      *(int *)(lVar26 + 0xbc) < 0x7fffffff || (*(int *)(lVar26 + 0xc4) < 0x7fffffff)))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong *)(&stack0x000000e8 + lVar15) == 0) {
    uVar23 = *(ulonglong *)(&stack0x00002148 + lVar15);
    *(undefined8 *)(puVar19 + -8) = 0x100998;
    func_0x(uVar23 ^ (ulonglong)puVar1);
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

