
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong param_1,undefined8 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  undefined8 uVar6;
  longlong unaff_GS_OFFSET;
  
  uVar4 = *(int *)(param_1 + 0x8c) + 1U & 0xf;
  *(uint *)(param_1 + 0x8c) = uVar4;
  if (uVar4 == 0) {
    func_0x(0x83);
  }
  lVar1 = *(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
           0x100);
  if (lVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(uint *)(*(longlong *)(lVar1 + 600) + 0xbc) & 4) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar5 = *(int *)(param_1 + 0x78);
  uVar6 = param_2;
  if (iVar5 == 0) {
LAB_:
    uVar6 = 0;
  }
  else if (iVar5 == 2) {
    if (*(char *)(param_1 + 0x99) == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(param_1 + 0x84) == 0) {
      plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x40) + 8);
      (**(code **)(*plVar2 + 0xb0))(plVar2,param_2);
    }
    *(undefined4 *)(param_1 + 0x84) = 0x40ec6;
  }
  else if (iVar5 != 3) {
    if (iVar5 == 4) goto LAB_;
    goto LAB_;
  }
  while( true ) {
    iVar5 = (**(code **)(***(longlong ***)(param_1 + 0x40) + 0x98))
                      (**(longlong ***)(param_1 + 0x40),param_2,uVar6);
    *(int *)(param_1 + 0x80) = iVar5;
    if (iVar5 == 0x40ec6) break;
    if (iVar5 == 0x4ffff) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    func_0x(param_1,param_2,1);
    plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x40) + 8);
    iVar5 = (**(code **)(*plVar2 + 0x98))(plVar2,param_2,0);
    *(int *)(param_1 + 0x84) = iVar5;
    if (((iVar5 == 0x40ec6) && (*(char *)(param_1 + 0x7c) != '\0')) &&
       (cVar3 = func_0x(param_1,param_2), cVar3 != '\0')) break;
    uVar6 = param_2;
    if (*(int *)(param_1 + 0x84) != 0x40ec6) {
      *(undefined4 *)(param_1 + 0x88) = 0;
      *(undefined4 *)(param_1 + 0x78) = 2;
      return 0;
    }
  }
LAB_:
  *(undefined4 *)(param_1 + 0x78) = 4;
  return 0x40ec6;
}

