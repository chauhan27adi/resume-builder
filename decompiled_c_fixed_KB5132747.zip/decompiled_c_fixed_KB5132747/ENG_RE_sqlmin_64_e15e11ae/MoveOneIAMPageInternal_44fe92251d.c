
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(int *param_1,undefined8 param_2,int *param_3,ulonglong *param_4,undefined4 param_5
                 ,longlong param_6,longlong **param_7,longlong **param_8)

{
  byte *pbVar1;
  longlong lVar2;
  ulonglong *puVar3;
  int *piVar4;
  char cVar5;
  short sVar6;
  int iVar7;
  int iVar8;
  longlong lVar9;
  short *psVar10;
  short sVar11;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong *plVar12;
  byte **ppbVar13;
  ulonglong uVar14;
  undefined auStack_2d8 [32];
  undefined8 uStack_2b8;
  int *piStack_2b0;
  ulonglong *puStack_2a8;
  undefined4 *puStack_298;
  undefined4 uStack_290;
  undefined8 uStack_288;
  longlong **pplStack_280;
  undefined4 uStack_248;
  undefined2 uStack_244;
  undefined4 uStack_240;
  undefined4 uStack_238;
  int iStack_234;
  short sStack_230;
  int iStack_22c;
  short sStack_228;
  ulonglong *puStack_1f0;
  longlong **pplStack_1e8;
  ulonglong uStack_1e0;
  int *piStack_1d8;
  undefined8 uStack_1c8;
  undefined2 uStack_1c0;
  undefined4 uStack_1a8;
  undefined4 uStack_1a4;
  undefined2 uStack_1a0;
  int iStack_19c;
  short sStack_198;
  int iStack_194;
  short sStack_190;
  undefined4 uStack_18c;
  undefined2 uStack_188;
  ulonglong uStack_170;
  int iStack_168;
  undefined2 uStack_164;
  undefined2 uStack_162;
  longlong **pplStack_140;
  int *piStack_138;
  undefined auStack_128 [4];
  undefined auStack_124 [12];
  undefined auStack_118 [16];
  longlong lStack_108;
  undefined8 uStack_100;
  short sStack_f8;
  undefined4 uStack_f4;
  byte *pbStack_f0;
  byte **ppbStack_e8;
  undefined8 uStack_da;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  undefined6 uStack_ce;
  undefined4 uStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [8];
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined6 uStack_98;
  undefined2 uStack_92;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined8 uStack_88;
  undefined auStack_80 [16];
  undefined auStack_70 [16];
  undefined auStack_60 [16];
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_100 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_2d8;
  lStack_108 = param_6;
  pplStack_1e8 = param_7;
  pplStack_140 = param_8;
  sStack_f8 = -1;
  pbStack_f0 = (byte *)0x0;
  uStack_f4 = 0;
  uStack_da = 0;
  uStack_d0 = 0;
  uStack_ce = 0;
  ppbStack_e8 = (byte **)0x0;
  uVar14 = param_4[6];
  uStack_1a8 = 0;
  uStack_1e0 = 0;
  if (param_6 != 0) {
    uStack_1e0 = *(ulonglong *)(param_6 + 0x14) & 0xffffffffffff;
  }
  puStack_1f0 = param_4;
  piStack_1d8 = param_1;
  uStack_170 = uVar14;
  piStack_138 = param_3;
  lVar9 = func_0x(*(undefined8 *)(uVar14 + 0x6a0),*(undefined2 *)(param_3 + 1),0);
  func_0x(param_7,param_3,2,uVar14);
  plVar12 = *param_7;
  lVar2 = *plVar12;
  uStack_1a4 = *(undefined4 *)((ulonglong)*(ushort *)(lVar2 + 0x1ffe) + 0x28 + lVar2);
  uStack_1a0 = *(undefined2 *)((ulonglong)*(ushort *)(lVar2 + 0x1ffe) + 0x2c + lVar2);
  if (*param_1 == *(int *)(lVar2 + 0x18)) {
    sVar11 = 0;
    if (*(short *)(param_1 + 1) != 1) {
      sVar11 = *(short *)(param_1 + 1);
    }
    sVar6 = 0;
    if (*(short *)(lVar2 + 6) != 1) {
      sVar6 = *(short *)(lVar2 + 6);
    }
    if (sVar11 == sVar6) {
      if (((*(ushort *)((longlong)plVar12 + 0x62) & 0x400) == 0) ||
         (*(short *)((longlong)param_7 + 0xc) < 3)) {
        iVar7 = (int)*(short *)((longlong)param_7 + 0xc);
        plVar12 = *param_7;
        if ((((byte)*(undefined2 *)((longlong)plVar12 + 0x62) >> 3 & 1) != 0) &&
           ((((iVar8 = 4, iVar7 == 3 || (iVar8 = iVar7, 1 < iVar7)) &&
             (iVar7 = iVar8, (*(uint *)((longlong)plVar12 + 100) & 8) != 0)) &&
            ((lVar2 = plVar12[0x12], lVar2 != 0 && (*(longlong *)(lVar2 + 0x758) != 0)))))) {
          func_0x(*(undefined8 *)(lVar2 + 0x758),plVar12,iVar7);
        }
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar12 + 100) & 8) != 0)) &&
           ((2 < iVar7 &&
            ((((*(uint *)((longlong)plVar12 + 100) & 0xc0000000) != 0x40000000 && (*plVar12 != 0))
             && (iVar8 = (*_DAT_)(*plVar12,0x2000,2,auStack_128), iVar8 != 0)))))) {
          LOCK();
          *(uint *)((longlong)plVar12 + 100) = *(uint *)((longlong)plVar12 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar12 + 100) = *(uint *)((longlong)plVar12 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(plVar12 + 0x13,iVar7);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(plVar12,0,iVar7);
        }
        *(undefined2 *)((longlong)param_7 + 0xc) = 0;
        *param_7 = (longlong *)0x0;
        param_1 = piStack_1d8;
      }
      else {
        func_0x(param_7);
      }
      puVar3 = puStack_1f0;
      iStack_168 = *param_1;
      uStack_164 = *(undefined2 *)(param_1 + 1);
      uStack_162 = 0;
      pplStack_280 = param_8;
      uStack_288 = 0;
      uStack_290 = 1;
      puStack_298 = &uStack_1a4;
      puStack_2a8 = &uStack_1e0;
      piStack_2b0 = &iStack_168;
      uStack_2b8 = (int *)CONCAT62(uStack_2b8._2_6_,*(undefined2 *)(lVar9 + 0x84));
      iVar7 = func_0x(puStack_1f0,puStack_1f0,param_5,0);
      if (iVar7 == 0) goto LAB_;
      plVar12 = *param_8;
      uStack_248 = *(undefined4 *)(plVar12 + 0xe);
      uStack_244 = *(undefined2 *)((longlong)plVar12 + 0x74);
      if (plVar12 != (longlong *)0x0) {
        if (((*(ushort *)((longlong)plVar12 + 0x62) & 0x400) == 0) ||
           (*(short *)((longlong)param_8 + 0xc) < 3)) {
          iVar7 = (int)*(short *)((longlong)param_8 + 0xc);
          plVar12 = *param_8;
          if (((((byte)*(undefined2 *)((longlong)plVar12 + 0x62) >> 3 & 1) != 0) &&
              (((iVar8 = 4, iVar7 == 3 || (iVar8 = iVar7, 1 < iVar7)) &&
               (iVar7 = iVar8, (*(uint *)((longlong)plVar12 + 100) & 8) != 0)))) &&
             ((lVar2 = plVar12[0x12], lVar2 != 0 && (*(longlong *)(lVar2 + 0x758) != 0)))) {
            func_0x(*(undefined8 *)(lVar2 + 0x758),plVar12,iVar7);
          }
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar12 + 100) & 8) != 0)) &&
             ((2 < iVar7 &&
              ((((*(uint *)((longlong)plVar12 + 100) & 0xc0000000) != 0x40000000 && (*plVar12 != 0))
               && (iVar8 = (*_DAT_)(*plVar12,0x2000,2,auStack_124), iVar8 != 0)))))) {
            LOCK();
            *(uint *)((longlong)plVar12 + 100) = *(uint *)((longlong)plVar12 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar12 + 100) = *(uint *)((longlong)plVar12 + 100) | 0x40000000;
            UNLOCK();
          }
          func_0x(plVar12 + 0x13,iVar7);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            func_0x(plVar12,0,iVar7);
          }
          *(undefined2 *)((longlong)param_8 + 0xc) = 0;
          *param_8 = (longlong *)0x0;
        }
        else {
          func_0x(param_8);
        }
      }
      piVar4 = piStack_138;
      uVar14 = uStack_170;
      func_0x(param_7,piStack_138,4,uStack_170);
      if ((*piVar4 != *(int *)(**param_7 + 0x20)) ||
         (*(short *)(piVar4 + 1) != *(short *)(**param_7 + 0x24))) {
        uStack_2b8 = (int *)0x0;
        (*_DAT_)(1,0x1761c60,0x1731fe0,0x7e4);
      }
      func_0x(param_8,&uStack_248,4,uVar14);
      piVar4 = piStack_1d8;
      plVar12 = *param_7;
      iStack_234 = *(int *)(*plVar12 + 8);
      sStack_230 = *(short *)(*plVar12 + 0xc);
      if ((iStack_234 != 0) || (sStack_230 != 0)) {
        puStack_2a8 = puVar3;
        piStack_2b0 = (int *)((ulonglong)piStack_2b0 & 0xffffffff00000000);
        uStack_2b8 = &iStack_19c;
        iStack_19c = iStack_234;
        sStack_198 = sStack_230;
        func_0x(param_8,piStack_1d8,8);
        plVar12 = *param_7;
      }
      iStack_22c = *(int *)(*plVar12 + 0x10);
      sStack_228 = *(short *)(*plVar12 + 0x14);
      if ((iStack_22c != 0) || (sStack_228 != 0)) {
        puStack_2a8 = puVar3;
        piStack_2b0 = (int *)((ulonglong)piStack_2b0 & 0xffffffff00000000);
        uStack_2b8 = &iStack_194;
        iStack_194 = iStack_22c;
        sStack_190 = sStack_228;
        func_0x(param_8,piVar4,0x10);
        plVar12 = *param_7;
      }
      lVar2 = *plVar12;
      uStack_c4 = 0;
      uStack_238 = 9;
      if (-1 < *(char *)(lVar2 + 2)) goto LAB_;
      pbVar1 = (byte *)(lVar2 + 0x60);
      if ((sStack_f8 == 0) || (ppbVar13 = ppbStack_e8, ppbStack_e8 == (byte **)0x0)) {
        uStack_98 = 0;
        uStack_8a = 0;
        auStack_70 = ZEXT816(0);
        auStack_c0 = ZEXT816(0);
        stack0xffffffffffffff52 = SUB1614(ZEXT816(0),2);
        auStack_b0._0_2_ = 0xffff;
        uStack_a8 = 0;
        uStack_92 = 0;
        uStack_90 = 0;
        uStack_88 = 0;
        uStack_a0 = 0;
        auStack_80 = ZEXT816(0);
        auStack_60._0_12_ = ZEXT812(0);
        auStack_60._12_4_ = 0;
        uStack_50 = 0;
        ppbVar13 = (byte **)auStack_c0;
      }
      if (*(short *)(lVar2 + 0x24) == 0) {
LAB_:
        uStack_1c8 = *(undefined8 *)(lVar2 + 0x28);
        uStack_1c0 = *(undefined2 *)(lVar2 + 0x30);
      }
      else {
        cVar5 = *(char *)(lVar2 + 1);
        if (cVar5 == '\v') {
          if (*(int *)(lVar2 + 0x18) != 99) {
LAB_:
            if (cVar5 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar5 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar2 + 0x18) != 99) goto LAB_;
        }
        uStack_18c = *(undefined4 *)(lVar2 + 0x20);
        uStack_188 = *(undefined2 *)(lVar2 + 0x24);
        cVar5 = func_0x(&uStack_18c,0x1328600,0x1328600);
        if (cVar5 == '\0') goto LAB_;
        func_0x(lVar2,&uStack_1c8);
      }
      *ppbVar13 = pbVar1;
      *(undefined4 *)(ppbVar13 + 0xc) = (undefined4)uStack_1c8;
      *(int *)((longlong)ppbVar13 + 100) = (int)((ulonglong)uStack_1c8 >> 0x20);
      *(undefined2 *)(ppbVar13 + 0xd) = uStack_1c0;
      *(undefined4 *)((longlong)ppbVar13 + 0x6c) = *(undefined4 *)(lVar2 + 0x20);
      *(undefined2 *)(ppbVar13 + 0xe) = *(undefined2 *)(lVar2 + 0x24);
      *(undefined2 *)((longlong)ppbVar13 + 0x72) = 0;
      uStack_240 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x13a6ee0);
      uVar14 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x13a6ee4);
      *(undefined2 *)(ppbVar13 + 2) = 0xffff;
      ppbVar13[3] = (byte *)0x0;
      *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
      *(undefined8 *)((longlong)ppbVar13 + 0x2e) = 0;
      ppbVar13[7] = (byte *)0x0;
      ppbVar13[4] = (byte *)0x0;
      ppbVar13[9] = (byte *)0x0;
      ppbVar13[10] = (byte *)0x0;
      *(undefined2 *)(ppbVar13 + 0xb) = 0;
      if ((**ppbVar13 & 2) != 0) {
        pbVar1 = pbVar1 + uVar14;
        if ((*pbVar1 & 1) == 0) {
          *(undefined2 *)(ppbVar13 + 2) = 0;
          ppbVar13[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
          *(undefined4 *)((longlong)ppbVar13 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010087d */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x103990) - 0x11f1f30
                    ))();
          return;
        }
        *(undefined2 *)(ppbVar13 + 2) = 1;
        ppbVar13[3] = pbVar1;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x103970) * 4
                               + 0x103960) - 0x11f1f30);
                    /* WARNING: Could not emulate address calculation at 0x001006f8 */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
        return;
      }
      if ((**ppbVar13 & 4) != 0) {
        uStack_240._2_2_ = (short)((uint)uStack_240 >> 0x10);
        if (uStack_240._2_2_ != 0) {
          uVar14 = (ulonglong)*(ushort *)(lVar2 + 0x61 + (longlong)uStack_240._2_2_ * 2);
        }
        psVar10 = (short *)(pbVar1 + uVar14);
        ppbVar13[9] = (byte *)psVar10;
        sVar11 = *psVar10;
        ppbVar13[10] = (byte *)(psVar10 + 1);
        *(short *)(ppbVar13 + 0xb) = (sVar11 + 1) * 2;
      }
      if (ppbVar13[1] != (byte *)0x0) {
        func_0x(ppbVar13[1],ppbVar13);
      }
LAB_:
      pbStack_f0 = (byte *)((ulonglong)*(ushort *)(lVar2 + 0x1ffe) + lVar2);
      if ((*pbStack_f0 & 1) == 0) {
        sStack_f8 = 0;
        uStack_f4 = 0;
        uStack_d2 = 0;
        uStack_d0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100b52 */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_f0 & 0xe) * 4 + 0x1039fc) -
                  0x11f1f30))((longlong)(int)(*pbStack_f0 & 0xe),0x1328600,0,pbStack_f0);
        return;
      }
      sStack_f8 = 1;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_f0 & 0x1c) + 0x1039dc) *
                              4 + 0x1039cc) - 0x11f1f30);
                    /* WARNING: Could not emulate address calculation at 0x0010099b */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbStack_f0,0x1328600);
      return;
    }
  }
  if (((*(ushort *)((longlong)plVar12 + 0x62) >> 10 & 1) != 0) &&
     (2 < *(short *)((longlong)param_7 + 0xc))) {
    func_0x(param_7);
    goto LAB_;
  }
  iVar7 = (int)*(short *)((longlong)param_7 + 0xc);
  plVar12 = *param_7;
  if (((byte)*(undefined2 *)((longlong)plVar12 + 0x62) >> 3 & 1) != 0) {
    if (iVar7 == 3) {
      iVar7 = 4;
    }
    else if (iVar7 < 2) goto LAB_;
    if ((((*(uint *)((longlong)plVar12 + 100) & 8) != 0) && (lVar2 = plVar12[0x12], lVar2 != 0)) &&
       (*(longlong *)(lVar2 + 0x758) != 0)) {
      func_0x(*(undefined8 *)(lVar2 + 0x758),plVar12,iVar7);
    }
  }
LAB_:
  if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar12 + 100) & 8) != 0)) &&
      ((2 < iVar7 &&
       (((*(uint *)((longlong)plVar12 + 100) & 0xc0000000) != 0x40000000 && (*plVar12 != 0)))))) &&
     (iVar8 = (*_DAT_)(*plVar12,0x2000,2,auStack_118), iVar8 != 0)) {
    LOCK();
    *(uint *)((longlong)plVar12 + 100) = *(uint *)((longlong)plVar12 + 100) & 0x3fffffff;
    UNLOCK();
    LOCK();
    *(uint *)((longlong)plVar12 + 100) = *(uint *)((longlong)plVar12 + 100) | 0x40000000;
    UNLOCK();
  }
  func_0x(plVar12 + 0x13,iVar7);
  if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
    func_0x(plVar12,0,iVar7);
  }
  *(undefined2 *)((longlong)param_7 + 0xc) = 0;
  *param_7 = (longlong *)0x0;
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_2d8);
  return;
}

