
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong *param_2,undefined8 param_3)

{
  byte *pbVar1;
  undefined4 *puVar2;
  code *pcVar3;
  ushort *puVar4;
  char cVar5;
  byte bVar6;
  ushort uVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  longlong lVar11;
  longlong lVar12;
  undefined8 uVar13;
  int *piVar14;
  longlong *plVar15;
  ulonglong uVar16;
  uint uVar17;
  uint uVar18;
  undefined8 unaff_RBX;
  longlong lVar19;
  byte *pbVar20;
  uint uVar21;
  int *piVar22;
  int *piVar23;
  int *piVar24;
  short sVar25;
  ulonglong uVar26;
  ushort *puVar27;
  longlong lVar28;
  int aiStackX_8 [2];
  int iStackX_10;
  ushort uStackX_14;
  ushort uStackX_16;
  int *piStackX_18;
  longlong *plStackX_20;
  undefined8 uStack_4158;
  undefined4 auStack_4150 [2];
  longlong lStack_4148;
  undefined auStack_4140 [8];
  undefined auStack_4138 [8];
  undefined auStack_4130 [8];
  undefined auStack_4128 [8];
  undefined auStack_4120 [8];
  undefined auStack_4118 [8];
  undefined auStack_4110 [8];
  undefined8 uStack_4108;
  short sStack_4100;
  ushort uStack_40fe;
  uint uStack_40fc;
  int *piStack_40f8;
  undefined8 uStack_40f0;
  uint uStack_40e8;
  ushort uStack_40e4;
  byte *pbStack_40e2;
  undefined2 uStack_40da;
  undefined2 uStack_40d8;
  ushort uStack_40d6;
  ushort uStack_40d4;
  undefined2 uStack_40d2;
  undefined4 uStack_40cc;
  undefined auStack_4048 [8191];
  undefined auStack_2049 [8193];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  uStack_4108 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000041a8 + lVar11) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar11);
  *(longlong **)((longlong)&plStackX_20 + lVar11) = param_2;
  lVar28 = -1;
  lStack_4148 = -1;
  lVar19 = *param_2;
  lVar12 = -1;
  do {
    lVar12 = lVar12 + 1;
  } while (*(short *)(lVar19 + lVar12 * 2) != 0);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10007e;
  cVar5 = func_0x(lVar19,lVar12 * 2,&lStack_4148,auStack_4150);
  if (cVar5 == '\0') {
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100093;
    func_0x(param_3,1);
    lVar12 = *param_2;
    lVar19 = -1;
    do {
      lVar19 = lVar19 + 1;
    } while (*(short *)(lVar12 + lVar19 * 2) != 0);
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1000c3;
    uVar13 = (*_DAT_)(auStack_4150[0],auStack_4048,0,0);
    *(longlong *)(&stack0xfffffffffffffff8 + lVar11) = lVar12;
    *(int *)(&stack0xfffffffffffffff0 + lVar11) = (int)lVar19 * 2;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = uVar13;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1000e7;
    (*_DAT_)(0x33,0x17,0x10,0x14);
  }
  sStack_4100 = -1;
  piVar22 = (int *)0x0;
  piStack_40f8 = (int *)0x0;
  iVar10 = 0;
  uStack_40fc = 0;
  pbStack_40e2 = (byte *)0x0;
  uStack_40d8 = 0;
  uStack_40d6 = 0;
  uStack_40d4 = 0;
  uStack_40d2 = 0;
  uStack_40f0 = (longlong *)0x0;
  uStack_40cc = 0xffffffff;
  puVar27 = (ushort *)((longlong)&uStackX_14 + lVar11 + 2);
  *puVar27 = *puVar27 & 0xffe0;
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10012c;
  iVar8 = func_0x(&lStack_4148,(ulonglong)auStack_2049 & 0xfffffffffffff000,&sStack_4100);
  if (iVar8 == 0) {
    lVar12 = *param_2;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100145;
    func_0x(param_3,0x1c,lVar12,0x1423da8);
  }
  *(undefined4 *)((longlong)&iStackX_10 + lVar11) = 0xfffffffc;
  *(undefined2 *)((longlong)&uStackX_14 + lVar11) = 4;
  *(ushort *)((longlong)&uStackX_14 + lVar11 + 2) =
       *(ushort *)((longlong)&uStackX_14 + lVar11 + 2) & 0xffe0;
  *(undefined8 *)((longlong)&uStackX_14 + lVar11 + 4) = 0;
  iVar8 = 0;
  uStack_4158 = param_3;
  if (sStack_4100 == 0) {
    piVar24 = piStack_40f8;
    if ((*(byte *)piStack_40f8 & 0x10) == 0) {
      if ((1 << (*(byte *)piStack_40f8 & 0xe) & 0x1105U) != 0) {
        bVar6 = 0xff;
        iVar9 = iVar10;
        goto LAB_;
      }
LAB_:
      if (uStack_40fc == 0) {
        uStack_40fe = 0;
        uVar16 = (ulonglong)uStack_40f0 & 0xffffffff;
        uVar17 = (uint)uStack_40f0;
        if ((*(byte *)piStack_40f8 & 0x10) != 0) {
          uVar17 = (uint)uStack_40f0 + 2 + (*(ushort *)((longlong)piStack_40f8 + uVar16) + 7 >> 3);
          uVar16 = (ulonglong)uVar17;
        }
        uStack_40f0 = (longlong *)CONCAT44(uVar17,(uint)uStack_40f0);
        uStack_40e8 = (uint)uVar16;
        if ((*(byte *)piStack_40f8 & 0x20) == 0) {
          uStack_40e4 = 0;
          uStack_40fc = uStack_40e8;
        }
        else {
          puVar27 = (ushort *)(uVar16 + (longlong)piStack_40f8);
          uStack_40e4 = *puVar27;
          if (uStack_40e4 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10027a;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100283;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10029d;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1002b9;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1002dd;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x80f);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1002e8;
            func_0x(piStack_40f8,3);
          }
          uStack_40e8 = uStack_40f0._4_4_ + (uStack_40e4 + 1) * 2;
          if (0x1f9e < uStack_40e8) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10030f;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100318;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100332;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10034e;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100372;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x816);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10037d;
            func_0x(piStack_40f8,4);
          }
          uStack_40fc = puVar27[uStack_40e4] & 0x7fff;
          if (uStack_40fc < uStack_40e8) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1003a4;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1003ad;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1003c7;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1003e3;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100407;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x81d);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100412;
            func_0x(piStack_40f8,4);
          }
          piVar14 = piVar22;
          piVar24 = piStack_40f8;
          uVar17 = uStack_40e8;
          puVar4 = puVar27;
          if (uStack_40e4 != 0) {
            do {
              uVar18 = puVar4[1] & 0x7fff;
              if ((uVar18 < uVar17) || (uStack_40fc < uVar18)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100452;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10045b;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100475;
                    cVar5 = func_0x(0x1b04090);
                    if (cVar5 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100491;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1004b5;
                      (*_DAT_)(1,0x13f3a9c,0x1513b88,0x82a);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1004c3;
                func_0x(piStack_40f8,4);
                piVar24 = piStack_40f8;
              }
              uVar21 = (int)piVar14 + 1;
              piVar14 = (int *)(ulonglong)uVar21;
              uVar17 = uVar18;
              puVar4 = puVar4 + 1;
            } while ((int)uVar21 < (int)(uint)uStack_40e4);
          }
          while (uVar16 = (ulonglong)uStack_40e4,
                (short)puVar27[(ulonglong)(uStack_40e4 - 1) + 1] < 0) {
            if (uStack_40e4 == 1) {
              uVar16 = 1;
              uVar17 = uStack_40e8;
            }
            else {
              uVar17 = *(ushort *)
                        ((longlong)piVar24 + uVar16 * 2 + (((ulonglong)uStack_40f0 >> 0x20) - 2)) &
                       0x7fff;
            }
            uVar18 = *(ushort *)((longlong)piVar24 + uVar16 * 2 + ((ulonglong)uStack_40f0 >> 0x20))
                     & 0x7fff;
            if (((uVar17 < uStack_40e8) || (uVar18 < uVar17)) || (uStack_40fc < uVar18)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100539;
              func_0x(piVar24,7);
              piVar24 = piStack_40f8;
            }
            if ((uVar17 < uStack_40e8) || (uStack_40fc < uVar17)) goto LAB_;
            if (*(ushort *)((ulonglong)uVar17 + (longlong)piVar24) == 5) {
              uStack_40fe = uStack_40fe | 2;
              uStack_40e4 = uStack_40e4 - 1;
              uVar16 = (ulonglong)(uVar17 & 0xffff);
              uStack_40d6 = (ushort)uVar17;
              pbVar1 = (byte *)((longlong)piVar24 + uVar16);
              if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                uVar7 = uStack_40d4 & 0xc7ff;
              }
              else {
                uVar7 = uStack_40d4 ^ (*(ushort *)(pbVar1 + 2) ^ uStack_40d4) & 0x3800;
              }
              uStack_40d4 = (uVar7 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar7;
              uVar26 = (ulonglong)uStack_40d4;
              pbVar20 = (byte *)((longlong)piVar24 +
                                uVar16 + (uVar26 & 0x7ff) * 2 +
                                         (ulonglong)((uVar7 >> 0xb & 7) * 2) + 4);
              if (pbVar20 < pbVar1) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100614;
                func_0x(pbVar1,0x19);
                uVar26 = (ulonglong)uStack_40d4;
                uVar16 = (ulonglong)uStack_40d6;
                piVar24 = piStack_40f8;
              }
              if (uVar18 - uVar17 <
                  (((uStack_40d4 & 0x7ff) * 2 - (int)uVar16) - (int)piStack_40f8) + (int)pbVar20) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100649;
                func_0x((byte *)(uVar16 + (longlong)piVar24),0x19);
                uVar26 = (ulonglong)uStack_40d4;
                uVar16 = (ulonglong)uStack_40d6;
                piVar24 = piStack_40f8;
              }
              if (((uVar26 & 0x3800) != 0) &&
                 (puVar27 = (ushort *)((longlong)piVar24 + uVar16 + 4), piVar14 = piVar22,
                 (uVar26 & 0x3800) != 0)) {
                do {
                  if (((ushort)uVar26 & 0x7ff) < (*puVar27 & 0x7ff)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1006a3;
                    func_0x((byte *)(uVar16 + (longlong)piVar24),0x1a);
                    uVar26 = (ulonglong)uStack_40d4;
                    uVar16 = (ulonglong)uStack_40d6;
                    piVar24 = piStack_40f8;
                  }
                  uVar17 = (int)piVar14 + 1;
                  piVar14 = (int *)(ulonglong)uVar17;
                  puVar27 = puVar27 + 1;
                } while ((int)uVar17 < (int)((uStack_40d4 & 0x3800) >> 0xb));
              }
              break;
            }
            if (*(ushort *)((ulonglong)uVar17 + (longlong)piVar24) < 0x400) break;
            uStack_40fe = uStack_40fe | 1;
            uStack_40e4 = uStack_40e4 - 1;
            if (uStack_40e4 == 0) break;
          }
        }
        if ((*(byte *)piVar24 & 0x40) == 0) {
          uStack_40da = 0;
          uStack_40d8 = 0;
        }
        else {
          uStack_40da = (undefined2)uStack_40fc;
          uStack_40d8 = (undefined2)(uStack_40fc >> 0x10);
          uStack_40fc = uStack_40fc + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1006ea;
          uVar13 = func_0x(&uStack_40fe);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1006f6;
          func_0x(uVar13,auStack_4140);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1006ff;
          iVar9 = func_0x(auStack_4140);
          uStack_40fc = uStack_40fc + iVar9;
          piVar24 = piStack_40f8;
        }
        if ((pbStack_40e2 != (byte *)0x0) &&
           (pbStack_40e2 < (byte *)((ulonglong)uStack_40fc + (longlong)piVar24))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100734;
          cVar5 = func_0x(0x1b04090);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10073d;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100757;
              cVar5 = func_0x(0x1b04090);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100773;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100797;
                (*_DAT_)(1,0x13f3a9c,0x1513b88,0x886);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1007a5;
          func_0x(piStack_40f8,0x12);
          piVar24 = piStack_40f8;
        }
        if (0x3f3b < uStack_40fc - 1) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1007c5;
          cVar5 = func_0x(0x1b04090);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1007ce;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1007e8;
              cVar5 = func_0x(0x1b04090);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100804;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100828;
                (*_DAT_)(1,0x13f3a9c,0x1513b88,0x88b);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100836;
          func_0x(piStack_40f8,5);
          piVar24 = piStack_40f8;
        }
      }
LAB_:
      sVar25 = -*(short *)((longlong)&iStackX_10 + lVar11);
      if ((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 0x10) == 0) {
LAB_:
        piVar14 = piVar24;
        if ((uint)(int)sVar25 <= (uint)uStack_40e4) {
          uVar17 = uStack_40e8;
          if (sVar25 != 1) {
            piVar14 = piStack_40f8;
            uVar17 = *(ushort *)
                      ((longlong)piVar24 +
                      (longlong)sVar25 * 2 + (((ulonglong)uStack_40f0 >> 0x20) - 2)) & 0x7fff;
          }
          uVar18 = *(ushort *)
                    ((longlong)piVar24 + (longlong)sVar25 * 2 + ((ulonglong)uStack_40f0 >> 0x20)) &
                   0x7fff;
          if (((uVar17 < uStack_40e8) || (uVar18 < uVar17)) ||
             (piVar24 = piVar14, uStack_40fc < uVar18)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1008df;
            func_0x(piVar14,7);
            piVar24 = piStack_40f8;
          }
          iVar10 = uVar18 - uVar17;
          piVar14 = (int *)((ulonglong)uVar17 + (longlong)piVar24);
        }
      }
      else {
        if ((*(byte *)piVar24 & 0x10) == 0) {
          if ((1 << (*(byte *)piVar24 & 0xe) & 0x1105U) == 0) goto LAB_;
        }
        else if ((*(int *)((longlong)&iStackX_10 + lVar11) < (int)(uint)uStack_40f0) &&
                (*(ushort *)((longlong)&uStackX_14 + lVar11) <=
                 *(ushort *)(((ulonglong)uStack_40f0 & 0xffffffff) + (longlong)piVar24)))
        goto LAB_;
        piVar14 = *(int **)((longlong)&uStackX_14 + lVar11 + 4);
        iVar10 = *piVar14;
        piVar14 = piVar14 + 1;
      }
      param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
      *(int *)((longlong)aiStackX_8 + lVar11) = iVar10;
    }
    else {
      iVar9 = iVar8;
      if ((int)(uint)uStack_40f0 < -3) {
        bVar6 = 0xff;
      }
      else if (*(ushort *)(((ulonglong)uStack_40f0 & 0xffffffff) + (longlong)piStack_40f8) < 4) {
        bVar6 = 0xff;
      }
      else {
        bVar6 = *(byte *)(((ulonglong)uStack_40f0 & 0xffffffff) + 2 + (longlong)piStack_40f8) >> 3;
        iVar9 = 1;
      }
LAB_:
      if ((bVar6 & 1) == 0) {
        if ((iVar9 != 0) || ((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 0x10) == 0))
        goto LAB_;
        piVar14 = (int *)0x4;
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) =
             **(undefined4 **)((longlong)&uStackX_14 + lVar11 + 4);
      }
      else {
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        piVar14 = piVar22;
      }
    }
  }
  else {
    *(undefined4 *)(&stack0x00000028 + lVar11) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = &stack0x00000028 + lVar11;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10092b;
    piVar14 = (int *)func_0x(&uStack_40fe,(longlong)&iStackX_10 + lVar11);
    plVar15 = uStack_40f0;
    piVar24 = piStack_40f8;
    if ((((sStack_4100 != 0) && (uStack_40f0 != (longlong *)0x0)) && (*uStack_40f0 != 0)) &&
       (((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 8) == 0 &&
        ((*(uint *)(&stack0x00000028 + lVar11) & 1) == 0)))) {
      if ((piVar14 == (int *)0x0) || (piVar14 == (int *)0x1178730)) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        piVar14 = (int *)0x0;
      }
      else {
        *(uint *)((longlong)&plStackX_20 + lVar11 + -0x20) = *(uint *)(&stack0x00000028 + lVar11);
        *(longlong *)(&stack0xfffffffffffffff8 + lVar11) = (longlong)aiStackX_8 + lVar11;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10098e;
        piVar14 = (int *)func_0x
                                   (plVar15,(longlong)&iStackX_10 + lVar11,piVar14,
                                    *(undefined4 *)((longlong)aiStackX_8 + lVar11));
        piVar24 = piStack_40f8;
      }
    }
  }
  if ((piVar14 == (int *)0x0) || (*(int *)((longlong)aiStackX_8 + lVar11) != 2)) {
    lVar12 = *param_2;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1009c2;
    func_0x(param_3,0x15,lVar12,0x1416b98);
    piVar24 = piStack_40f8;
  }
  *(short *)((longlong)param_2 + 10) = *(short *)piVar14;
  *(undefined4 *)((longlong)&iStackX_10 + lVar11) = 0xfffffffd;
  *(undefined2 *)((longlong)&uStackX_14 + lVar11) = 3;
  *(ushort *)((longlong)&uStackX_14 + lVar11 + 2) =
       *(ushort *)((longlong)&uStackX_14 + lVar11 + 2) & 0xffe0;
  *(undefined8 *)((longlong)&uStackX_14 + lVar11 + 4) = 0;
  iVar10 = 0;
  if (sStack_4100 == 0) {
    iVar9 = iVar10;
    if ((*(byte *)piVar24 & 0x10) == 0) {
      if ((1 << (*(byte *)piVar24 & 0xe) & 0x1105U) != 0) {
        bVar6 = 0xff;
        goto LAB_;
      }
LAB_:
      if (uStack_40fc == 0) {
        uStack_40fe = 0;
        uVar16 = (ulonglong)uStack_40f0 & 0xffffffff;
        uVar17 = (uint)uStack_40f0;
        if ((*(byte *)piVar24 & 0x10) != 0) {
          uVar17 = (uint)uStack_40f0 + 2 + (*(ushort *)((longlong)piVar24 + uVar16) + 7 >> 3);
          uVar16 = (ulonglong)uVar17;
        }
        uStack_40f0 = (longlong *)CONCAT44(uVar17,(uint)uStack_40f0);
        if ((*(byte *)piVar24 & 0x20) == 0) {
          uStack_40e4 = 0;
          uStack_40fc = (uint)uVar16;
          uStack_40e8 = (uint)uVar16;
        }
        else {
          puVar27 = (ushort *)(uVar16 + (longlong)piVar24);
          uStack_40e4 = *puVar27;
          if (uStack_40e4 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100af0;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100af9;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b13;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b2f;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b53;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x80f);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b5e;
            func_0x(piStack_40f8,3);
            piVar24 = piStack_40f8;
          }
          uStack_40e8 = uStack_40f0._4_4_ + (uStack_40e4 + 1) * 2;
          if (0x1f9e < uStack_40e8) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b85;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b8e;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100ba8;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100bc4;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100be8;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x816);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100bf3;
            func_0x(piStack_40f8,4);
            piVar24 = piStack_40f8;
          }
          uStack_40fc = puVar27[uStack_40e4] & 0x7fff;
          if (uStack_40fc < uStack_40e8) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c1a;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c23;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c3d;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c59;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c7d;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x81d);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c88;
            func_0x(piStack_40f8,4);
            piVar24 = piStack_40f8;
          }
          piVar14 = piVar22;
          uVar17 = uStack_40e8;
          puVar4 = puVar27;
          if (uStack_40e4 != 0) {
            do {
              uVar18 = puVar4[1] & 0x7fff;
              if ((uVar18 < uVar17) || (uStack_40fc < uVar18)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100cc3;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100ccc;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100ce6;
                    cVar5 = func_0x(0x1b04090);
                    if (cVar5 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d02;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d26;
                      (*_DAT_)(1,0x13f3a9c,0x1513b88,0x82a);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d34;
                func_0x(piStack_40f8,4);
                piVar24 = piStack_40f8;
              }
              uVar21 = (int)piVar14 + 1;
              piVar14 = (int *)(ulonglong)uVar21;
              uVar17 = uVar18;
              puVar4 = puVar4 + 1;
            } while ((int)uVar21 < (int)(uint)uStack_40e4);
          }
          while (uVar16 = (ulonglong)uStack_40e4,
                (short)puVar27[(ulonglong)(uStack_40e4 - 1) + 1] < 0) {
            if (uStack_40e4 == 1) {
              uVar16 = 1;
              uVar17 = uStack_40e8;
            }
            else {
              uVar17 = *(ushort *)
                        ((longlong)piVar24 + uVar16 * 2 + (((ulonglong)uStack_40f0 >> 0x20) - 2)) &
                       0x7fff;
            }
            uVar18 = *(ushort *)((longlong)piVar24 + uVar16 * 2 + ((ulonglong)uStack_40f0 >> 0x20))
                     & 0x7fff;
            if (((uVar17 < uStack_40e8) || (uVar18 < uVar17)) || (uStack_40fc < uVar18)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100daa;
              func_0x(piVar24,7);
              piVar24 = piStack_40f8;
            }
            if ((uVar17 < uStack_40e8) || (uStack_40fc < uVar17)) goto LAB_;
            if (*(ushort *)((ulonglong)uVar17 + (longlong)piVar24) == 5) {
              uStack_40fe = uStack_40fe | 2;
              uStack_40e4 = uStack_40e4 - 1;
              uVar16 = (ulonglong)(uVar17 & 0xffff);
              uStack_40d6 = (ushort)uVar17;
              pbVar1 = (byte *)((longlong)piVar24 + uVar16);
              if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                uVar7 = uStack_40d4 & 0xc7ff;
              }
              else {
                uVar7 = uStack_40d4 ^ (uStack_40d4 ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
              }
              uStack_40d4 = (uVar7 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar7;
              uVar26 = (ulonglong)uStack_40d4;
              pbVar20 = (byte *)((longlong)piVar24 +
                                uVar16 + (uVar26 & 0x7ff) * 2 +
                                         (ulonglong)((uVar7 >> 0xb & 7) * 2) + 4);
              if (pbVar20 < pbVar1) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e88;
                func_0x(pbVar1,0x19);
                uVar26 = (ulonglong)uStack_40d4;
                uVar16 = (ulonglong)uStack_40d6;
                piVar24 = piStack_40f8;
              }
              if (uVar18 - uVar17 <
                  (((uStack_40d4 & 0x7ff) * 2 - (int)uVar16) - (int)piStack_40f8) + (int)pbVar20) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100ebd;
                func_0x((byte *)(uVar16 + (longlong)piVar24),0x19);
                uVar26 = (ulonglong)uStack_40d4;
                uVar16 = (ulonglong)uStack_40d6;
                piVar24 = piStack_40f8;
              }
              if (((uVar26 & 0x3800) != 0) &&
                 (puVar27 = (ushort *)((longlong)piVar24 + uVar16 + 4), piVar14 = piVar22,
                 (uVar26 & 0x3800) != 0)) {
                do {
                  if (((ushort)uVar26 & 0x7ff) < (*puVar27 & 0x7ff)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100f13;
                    func_0x((byte *)(uVar16 + (longlong)piVar24),0x1a);
                    uVar26 = (ulonglong)uStack_40d4;
                    uVar16 = (ulonglong)uStack_40d6;
                    piVar24 = piStack_40f8;
                  }
                  uVar17 = (int)piVar14 + 1;
                  piVar14 = (int *)(ulonglong)uVar17;
                  puVar27 = puVar27 + 1;
                } while ((int)uVar17 < (int)((uStack_40d4 & 0x3800) >> 0xb));
              }
              break;
            }
            if (*(ushort *)((ulonglong)uVar17 + (longlong)piVar24) < 0x400) break;
            uStack_40fe = uStack_40fe | 1;
            uStack_40e4 = uStack_40e4 - 1;
            if (uStack_40e4 == 0) break;
          }
        }
        if ((*(byte *)piVar24 & 0x40) == 0) {
          uStack_40da = 0;
          uStack_40d8 = 0;
        }
        else {
          uStack_40da = (undefined2)uStack_40fc;
          uStack_40d8 = (undefined2)(uStack_40fc >> 0x10);
          uStack_40fc = uStack_40fc + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100f5a;
          uVar13 = func_0x(&uStack_40fe);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100f66;
          func_0x(uVar13,auStack_4138);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100f6f;
          iVar9 = func_0x(auStack_4138);
          uStack_40fc = uStack_40fc + iVar9;
          piVar24 = piStack_40f8;
        }
        if ((pbStack_40e2 != (byte *)0x0) &&
           (pbStack_40e2 < (byte *)((ulonglong)uStack_40fc + (longlong)piVar24))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100fa4;
          cVar5 = func_0x(0x1b04090);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100fad;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100fc7;
              cVar5 = func_0x(0x1b04090);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100fe3;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101007;
                (*_DAT_)(1,0x13f3a9c,0x1513b88,0x886);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101015;
          func_0x(piStack_40f8,0x12);
          piVar24 = piStack_40f8;
        }
        if (0x3f3b < uStack_40fc - 1) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101035;
          cVar5 = func_0x(0x1b04090);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10103e;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101058;
              cVar5 = func_0x(0x1b04090);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101074;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101098;
                (*_DAT_)(1,0x13f3a9c,0x1513b88,0x88b);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1010a6;
          func_0x(piStack_40f8,5);
          piVar24 = piStack_40f8;
        }
      }
LAB_:
      sVar25 = -*(short *)((longlong)&iStackX_10 + lVar11);
      if ((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 0x10) != 0) {
        if ((*(byte *)piVar24 & 0x10) == 0) {
          if ((1 << (*(byte *)piVar24 & 0xe) & 0x1105U) != 0) {
LAB_:
            puVar2 = *(undefined4 **)((longlong)&uStackX_14 + lVar11 + 4);
            piVar14 = puVar2 + 1;
            param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
            *(undefined4 *)((longlong)aiStackX_8 + lVar11) = *puVar2;
            goto LAB_;
          }
        }
        else if (((int)(uint)uStack_40f0 <= *(int *)((longlong)&iStackX_10 + lVar11)) ||
                (*(ushort *)(((ulonglong)uStack_40f0 & 0xffffffff) + (longlong)piVar24) <
                 *(ushort *)((longlong)&uStackX_14 + lVar11))) goto LAB_;
      }
      if ((uint)uStack_40e4 < (uint)(int)sVar25) {
        param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        piVar14 = piVar24;
      }
      else {
        piVar23 = piVar24;
        uVar17 = uStack_40e8;
        if (sVar25 != 1) {
          piVar23 = piStack_40f8;
          uVar17 = *(ushort *)
                    ((longlong)piVar24 +
                    (longlong)sVar25 * 2 + (((ulonglong)uStack_40f0 >> 0x20) - 2)) & 0x7fff;
        }
        uVar18 = *(ushort *)
                  ((longlong)piVar24 + (longlong)sVar25 * 2 + ((ulonglong)uStack_40f0 >> 0x20)) &
                 0x7fff;
        if (((uVar17 < uStack_40e8) || (uVar18 < uVar17)) || (uStack_40fc < uVar18)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101161;
          func_0x(piVar23,7);
          piVar23 = piStack_40f8;
        }
        param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
        *(uint *)((longlong)aiStackX_8 + lVar11) = uVar18 - uVar17;
        piVar14 = (int *)((ulonglong)uVar17 + (longlong)piVar23);
        piVar24 = piVar23;
      }
    }
    else {
      if ((int)(uint)uStack_40f0 < -2) {
        bVar6 = 0xff;
      }
      else if (*(ushort *)(((ulonglong)uStack_40f0 & 0xffffffff) + (longlong)piVar24) < 3) {
        bVar6 = 0xff;
      }
      else {
        bVar6 = *(byte *)(((ulonglong)uStack_40f0 & 0xffffffff) + 2 + (longlong)piVar24) >> 2;
        iVar9 = 1;
      }
LAB_:
      if ((bVar6 & 1) == 0) {
        if ((iVar9 != 0) || ((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 0x10) == 0))
        goto LAB_;
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) =
             **(undefined4 **)((longlong)&uStackX_14 + lVar11 + 4);
        piVar14 = (int *)0x4;
      }
      else {
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        piVar14 = piVar22;
      }
    }
  }
  else {
    *(undefined4 *)(&stack0x0000002c + lVar11) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = &stack0x0000002c + lVar11;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1011bd;
    piVar14 = (int *)func_0x(&uStack_40fe,(longlong)&iStackX_10 + lVar11,piVar24,
                                     (longlong)aiStackX_8 + lVar11);
    plVar15 = uStack_40f0;
    piVar24 = piStack_40f8;
    if (((sStack_4100 != 0) && (uStack_40f0 != (longlong *)0x0)) &&
       ((*uStack_40f0 != 0 &&
        (((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 8) == 0 &&
         ((*(uint *)(&stack0x0000002c + lVar11) & 1) == 0)))))) {
      if ((piVar14 == (int *)0x0) || (piVar14 == (int *)0x1178730)) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        piVar14 = (int *)0x0;
      }
      else {
        *(uint *)((longlong)&plStackX_20 + lVar11 + -0x20) = *(uint *)(&stack0x0000002c + lVar11);
        *(longlong *)(&stack0xfffffffffffffff8 + lVar11) = (longlong)aiStackX_8 + lVar11;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101220;
        piVar14 = (int *)func_0x
                                   (plVar15,(longlong)&iStackX_10 + lVar11,piVar14,
                                    *(undefined4 *)((longlong)aiStackX_8 + lVar11));
        piVar24 = piStack_40f8;
      }
    }
  }
LAB_:
  if ((piVar14 == (int *)0x0) || (*(int *)((longlong)aiStackX_8 + lVar11) != 2)) {
    lVar12 = *param_2;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101258;
    func_0x(uStack_4158,0x16,lVar12,0x1416a80);
    piVar24 = piStack_40f8;
  }
  if (*(short *)(param_2 + 1) != *(short *)piVar14) {
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101276;
    func_0x(uStack_4158,1);
    do {
      lVar28 = lVar28 + 1;
    } while (*(short *)(*param_2 + lVar28 * 2) != 0);
    *(longlong *)(&stack0xfffffffffffffff0 + lVar11) = *param_2;
    *(int *)(&stack0xffffffffffffffe8 + lVar11) = (int)lVar28 * 2;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1012ad;
    (*_DAT_)(0x33,0x47,0x10,0x16);
    piVar24 = piStack_40f8;
  }
  *(undefined4 *)((longlong)&iStackX_10 + lVar11) = 0xfffffffb;
  *(undefined2 *)((longlong)&uStackX_14 + lVar11) = 5;
  *(ushort *)((longlong)&uStackX_14 + lVar11 + 2) =
       *(ushort *)((longlong)&uStackX_14 + lVar11 + 2) & 0xffe0;
  *(undefined8 *)((longlong)&uStackX_14 + lVar11 + 4) = 0;
  if (sStack_4100 == 0) {
    iVar9 = iVar10;
    if ((*(byte *)piVar24 & 0x10) == 0) {
      if ((1 << (*(byte *)piVar24 & 0xe) & 0x1105U) != 0) {
        bVar6 = 0xff;
        goto LAB_;
      }
LAB_:
      if (uStack_40fc == 0) {
        uStack_40fe = 0;
        uVar16 = (ulonglong)uStack_40f0 & 0xffffffff;
        uVar17 = (uint)uStack_40f0;
        if ((*(byte *)piVar24 & 0x10) != 0) {
          uVar17 = (uint)uStack_40f0 + 2 + (*(ushort *)((longlong)piVar24 + uVar16) + 7 >> 3);
          uVar16 = (ulonglong)uVar17;
        }
        uStack_40f0 = (longlong *)CONCAT44(uVar17,(uint)uStack_40f0);
        if ((*(byte *)piVar24 & 0x20) == 0) {
          uStack_40e4 = 0;
          uStack_40fc = (uint)uVar16;
          uStack_40e8 = (uint)uVar16;
        }
        else {
          puVar27 = (ushort *)(uVar16 + (longlong)piVar24);
          uStack_40e4 = *puVar27;
          if (uStack_40e4 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1013d2;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1013db;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1013f5;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101411;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101435;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x80f);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101443;
            func_0x(piStack_40f8,3);
            piVar24 = piStack_40f8;
          }
          uStack_40e8 = uStack_40f0._4_4_ + (uStack_40e4 + 1) * 2;
          if (0x1f9e < uStack_40e8) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10146e;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101477;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101491;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1014ad;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1014d1;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x816);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1014df;
            func_0x(piStack_40f8,4);
            piVar24 = piStack_40f8;
          }
          uStack_40fc = puVar27[uStack_40e4] & 0x7fff;
          if (uStack_40fc < uStack_40e8) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10150a;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101513;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10152d;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101549;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10156d;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x81d);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10157b;
            func_0x(piStack_40f8,4);
            piVar24 = piStack_40f8;
          }
          piVar14 = piVar22;
          uVar17 = uStack_40e8;
          puVar4 = puVar27;
          if (uStack_40e4 != 0) {
            do {
              uVar18 = puVar4[1] & 0x7fff;
              if ((uVar18 < uVar17) || (uStack_40fc < uVar18)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1015c2;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1015cb;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1015e5;
                    cVar5 = func_0x(0x1b04090);
                    if (cVar5 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101601;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101625;
                      (*_DAT_)(1,0x13f3a9c,0x1513b88,0x82a);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101633;
                func_0x(piStack_40f8,4);
                piVar24 = piStack_40f8;
              }
              uVar21 = (int)piVar14 + 1;
              piVar14 = (int *)(ulonglong)uVar21;
              uVar17 = uVar18;
              puVar4 = puVar4 + 1;
            } while ((int)uVar21 < (int)(uint)uStack_40e4);
          }
          while (uVar16 = (ulonglong)uStack_40e4,
                (short)puVar27[(ulonglong)(uStack_40e4 - 1) + 1] < 0) {
            if (uStack_40e4 == 1) {
              uVar16 = 1;
              uVar17 = uStack_40e8;
            }
            else {
              uVar17 = *(ushort *)
                        ((longlong)piVar24 + uVar16 * 2 + (((ulonglong)uStack_40f0 >> 0x20) - 2)) &
                       0x7fff;
            }
            uVar18 = *(ushort *)((longlong)piVar24 + uVar16 * 2 + ((ulonglong)uStack_40f0 >> 0x20))
                     & 0x7fff;
            if (((uVar17 < uStack_40e8) || (uVar18 < uVar17)) || (uStack_40fc < uVar18)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1016a9;
              func_0x(piVar24,7);
              piVar24 = piStack_40f8;
            }
            if ((uVar17 < uStack_40e8) || (uStack_40fc < uVar17)) goto LAB_;
            if (*(ushort *)((ulonglong)uVar17 + (longlong)piVar24) == 5) {
              uStack_40fe = uStack_40fe | 2;
              uStack_40e4 = uStack_40e4 - 1;
              uVar16 = (ulonglong)(uVar17 & 0xffff);
              uStack_40d6 = (ushort)uVar17;
              pbVar1 = (byte *)((longlong)piVar24 + uVar16);
              if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                uVar7 = uStack_40d4 & 0xc7ff;
              }
              else {
                uVar7 = uStack_40d4 ^ (*(ushort *)(pbVar1 + 2) ^ uStack_40d4) & 0x3800;
              }
              uStack_40d4 = (uVar7 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar7;
              uVar26 = (ulonglong)uStack_40d4;
              pbVar20 = (byte *)((ulonglong)((uVar7 >> 0xb & 7) * 2) + 4 + uVar16 +
                                 (uVar26 & 0x7ff) * 2 + (longlong)piVar24);
              if (pbVar20 < pbVar1) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101784;
                func_0x(pbVar1,0x19);
                uVar26 = (ulonglong)uStack_40d4;
                uVar16 = (ulonglong)uStack_40d6;
                piVar24 = piStack_40f8;
              }
              if (uVar18 - uVar17 <
                  (((uStack_40d4 & 0x7ff) * 2 - (int)uVar16) - (int)piStack_40f8) + (int)pbVar20) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1017b9;
                func_0x((byte *)(uVar16 + (longlong)piVar24),0x19);
                uVar26 = (ulonglong)uStack_40d4;
                uVar16 = (ulonglong)uStack_40d6;
                piVar24 = piStack_40f8;
              }
              if (((uVar26 & 0x3800) != 0) &&
                 (puVar27 = (ushort *)((longlong)piVar24 + uVar16 + 4), piVar14 = piVar22,
                 (uVar26 & 0x3800) != 0)) {
                do {
                  if (((ushort)uVar26 & 0x7ff) < (*puVar27 & 0x7ff)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101813;
                    func_0x((byte *)(uVar16 + (longlong)piVar24),0x1a);
                    uVar26 = (ulonglong)uStack_40d4;
                    uVar16 = (ulonglong)uStack_40d6;
                    piVar24 = piStack_40f8;
                  }
                  uVar17 = (int)piVar14 + 1;
                  piVar14 = (int *)(ulonglong)uVar17;
                  puVar27 = puVar27 + 1;
                } while ((int)uVar17 < (int)((uStack_40d4 & 0x3800) >> 0xb));
              }
              break;
            }
            if (*(ushort *)((ulonglong)uVar17 + (longlong)piVar24) < 0x400) break;
            uStack_40fe = uStack_40fe | 1;
            uStack_40e4 = uStack_40e4 - 1;
            if (uStack_40e4 == 0) break;
          }
        }
        if ((*(byte *)piVar24 & 0x40) == 0) {
          uStack_40da = 0;
          uStack_40d8 = 0;
        }
        else {
          uStack_40da = (undefined2)uStack_40fc;
          uStack_40d8 = (undefined2)(uStack_40fc >> 0x10);
          uStack_40fc = uStack_40fc + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10185f;
          uVar13 = func_0x(&uStack_40fe);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10186b;
          func_0x(uVar13,auStack_4130);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101874;
          iVar9 = func_0x(auStack_4130);
          uStack_40fc = uStack_40fc + iVar9;
          piVar24 = piStack_40f8;
        }
        if ((pbStack_40e2 != (byte *)0x0) &&
           (pbStack_40e2 < (byte *)((ulonglong)uStack_40fc + (longlong)piVar24))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1018a9;
          cVar5 = func_0x(0x1b04090);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1018b2;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1018cc;
              cVar5 = func_0x(0x1b04090);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1018e8;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10190c;
                (*_DAT_)(1,0x13f3a9c,0x1513b88,0x886);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10191a;
          func_0x(piStack_40f8,0x12);
          piVar24 = piStack_40f8;
        }
        if (0x3f3b < uStack_40fc - 1) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101936;
          cVar5 = func_0x(0x1b04090);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10193f;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101959;
              cVar5 = func_0x(0x1b04090);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101975;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101999;
                (*_DAT_)(1,0x13f3a9c,0x1513b88,0x88b);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1019a4;
          func_0x(piStack_40f8,5);
          piVar24 = piStack_40f8;
        }
      }
LAB_:
      sVar25 = -*(short *)((longlong)&iStackX_10 + lVar11);
      if ((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 0x10) != 0) {
        if ((*(byte *)piVar24 & 0x10) == 0) {
          if ((1 << (*(byte *)piVar24 & 0xe) & 0x1105U) != 0) {
LAB_:
            puVar2 = *(undefined4 **)((longlong)&uStackX_14 + lVar11 + 4);
            piVar14 = puVar2 + 1;
            param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
            *(undefined4 *)((longlong)aiStackX_8 + lVar11) = *puVar2;
            goto LAB_;
          }
        }
        else if (((int)(uint)uStack_40f0 <= *(int *)((longlong)&iStackX_10 + lVar11)) ||
                (*(ushort *)(((ulonglong)uStack_40f0 & 0xffffffff) + (longlong)piVar24) <
                 *(ushort *)((longlong)&uStackX_14 + lVar11))) goto LAB_;
      }
      if ((uint)uStack_40e4 < (uint)(int)sVar25) {
        param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        piVar14 = piVar24;
      }
      else {
        piVar23 = piVar24;
        uVar17 = uStack_40e8;
        if (sVar25 != 1) {
          piVar23 = piStack_40f8;
          uVar17 = *(ushort *)
                    ((longlong)piVar24 +
                    (longlong)sVar25 * 2 + (((ulonglong)uStack_40f0 >> 0x20) - 2)) & 0x7fff;
        }
        uVar18 = *(ushort *)
                  ((longlong)piVar24 + (longlong)sVar25 * 2 + ((ulonglong)uStack_40f0 >> 0x20)) &
                 0x7fff;
        if (((uVar17 < uStack_40e8) || (uVar18 < uVar17)) || (uStack_40fc < uVar18)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101a5f;
          func_0x(piVar23,7);
          piVar23 = piStack_40f8;
        }
        param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
        *(uint *)((longlong)aiStackX_8 + lVar11) = uVar18 - uVar17;
        piVar14 = (int *)((ulonglong)uVar17 + (longlong)piVar23);
        piVar24 = piVar23;
      }
    }
    else {
      if ((int)(uint)uStack_40f0 < -4) {
        bVar6 = 0xff;
      }
      else if (*(ushort *)(((ulonglong)uStack_40f0 & 0xffffffff) + (longlong)piVar24) < 5) {
        bVar6 = 0xff;
      }
      else {
        bVar6 = *(byte *)(((ulonglong)uStack_40f0 & 0xffffffff) + 2 + (longlong)piVar24) >> 4;
        iVar9 = 1;
      }
LAB_:
      if ((bVar6 & 1) == 0) {
        if ((iVar9 != 0) || ((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 0x10) == 0))
        goto LAB_;
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) =
             **(undefined4 **)((longlong)&uStackX_14 + lVar11 + 4);
        piVar14 = (int *)0x4;
      }
      else {
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        piVar14 = piVar22;
      }
    }
  }
  else {
    *(undefined4 *)(&stack0x00000030 + lVar11) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = &stack0x00000030 + lVar11;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101abb;
    piVar14 = (int *)func_0x(&uStack_40fe,(longlong)&iStackX_10 + lVar11,piVar24,
                                     (longlong)aiStackX_8 + lVar11);
    plVar15 = uStack_40f0;
    piVar24 = piStack_40f8;
    if (((sStack_4100 != 0) && (uStack_40f0 != (longlong *)0x0)) &&
       ((*uStack_40f0 != 0 &&
        (((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 8) == 0 &&
         ((*(uint *)(&stack0x00000030 + lVar11) & 1) == 0)))))) {
      if ((piVar14 == (int *)0x0) || (piVar14 == (int *)0x1178730)) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        piVar14 = (int *)0x0;
      }
      else {
        *(uint *)((longlong)&plStackX_20 + lVar11 + -0x20) = *(uint *)(&stack0x00000030 + lVar11);
        *(longlong *)(&stack0xfffffffffffffff8 + lVar11) = (longlong)aiStackX_8 + lVar11;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101b1e;
        piVar14 = (int *)func_0x
                                   (plVar15,(longlong)&iStackX_10 + lVar11,piVar14,
                                    *(undefined4 *)((longlong)aiStackX_8 + lVar11));
        piVar24 = piStack_40f8;
      }
    }
  }
LAB_:
  if ((piVar14 == (int *)0x0) || (*(int *)((longlong)aiStackX_8 + lVar11) != 4)) {
    lVar12 = *param_2;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101b56;
    func_0x(uStack_4158,0x17,lVar12,0x1416db0);
    piVar24 = piStack_40f8;
  }
  *(int *)((longlong)param_2 + 0xc) = *piVar14;
  *(undefined4 *)((longlong)&iStackX_10 + lVar11) = 0xfffffffa;
  *(undefined2 *)((longlong)&uStackX_14 + lVar11) = 6;
  *(ushort *)((longlong)&uStackX_14 + lVar11 + 2) =
       *(ushort *)((longlong)&uStackX_14 + lVar11 + 2) & 0xffe0;
  *(undefined8 *)((longlong)&uStackX_14 + lVar11 + 4) = 0;
  if (sStack_4100 == 0) {
    iVar9 = iVar10;
    if ((*(byte *)piVar24 & 0x10) == 0) {
      if ((1 << (*(byte *)piVar24 & 0xe) & 0x1105U) != 0) {
        bVar6 = 0xff;
        goto LAB_;
      }
LAB_:
      if (uStack_40fc == 0) {
        uStack_40fe = 0;
        uVar16 = (ulonglong)uStack_40f0 & 0xffffffff;
        uVar17 = (uint)uStack_40f0;
        if ((*(byte *)piVar24 & 0x10) != 0) {
          uVar17 = (uint)uStack_40f0 + 2 + (*(ushort *)((longlong)piVar24 + uVar16) + 7 >> 3);
          uVar16 = (ulonglong)uVar17;
        }
        uStack_40f0 = (longlong *)CONCAT44(uVar17,(uint)uStack_40f0);
        if ((*(byte *)piVar24 & 0x20) == 0) {
          uStack_40e4 = 0;
          uStack_40fc = (uint)uVar16;
          uStack_40e8 = (uint)uVar16;
        }
        else {
          puVar27 = (ushort *)(uVar16 + (longlong)piVar24);
          uStack_40e4 = *puVar27;
          if (uStack_40e4 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101c87;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101c90;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101caa;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101cc6;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101cea;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x80f);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101cf8;
            func_0x(piStack_40f8,3);
            piVar24 = piStack_40f8;
          }
          uStack_40e8 = uStack_40f0._4_4_ + (uStack_40e4 + 1) * 2;
          if (0x1f9e < uStack_40e8) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101d23;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101d2c;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101d46;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101d62;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101d86;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x816);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101d94;
            func_0x(piStack_40f8,4);
            piVar24 = piStack_40f8;
          }
          uStack_40fc = puVar27[uStack_40e4] & 0x7fff;
          if (uStack_40fc < uStack_40e8) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101dbf;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101dc8;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101de2;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101dfe;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101e22;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x81d);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101e30;
            func_0x(piStack_40f8,4);
            piVar24 = piStack_40f8;
          }
          piVar14 = piVar22;
          uVar17 = uStack_40e8;
          puVar4 = puVar27;
          if (uStack_40e4 != 0) {
            do {
              uVar18 = puVar4[1] & 0x7fff;
              if ((uVar18 < uVar17) || (uStack_40fc < uVar18)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101e72;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101e7b;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101e95;
                    cVar5 = func_0x(0x1b04090);
                    if (cVar5 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101eb1;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101ed5;
                      (*_DAT_)(1,0x13f3a9c,0x1513b88,0x82a);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101ee3;
                func_0x(piStack_40f8,4);
                piVar24 = piStack_40f8;
              }
              uVar21 = (int)piVar14 + 1;
              piVar14 = (int *)(ulonglong)uVar21;
              uVar17 = uVar18;
              puVar4 = puVar4 + 1;
            } while ((int)uVar21 < (int)(uint)uStack_40e4);
          }
          while (uVar16 = (ulonglong)uStack_40e4,
                (short)puVar27[(ulonglong)(uStack_40e4 - 1) + 1] < 0) {
            if (uStack_40e4 == 1) {
              uVar16 = 1;
              uVar17 = uStack_40e8;
            }
            else {
              uVar17 = *(ushort *)
                        ((longlong)piVar24 + uVar16 * 2 + (((ulonglong)uStack_40f0 >> 0x20) - 2)) &
                       0x7fff;
            }
            uVar18 = *(ushort *)((longlong)piVar24 + uVar16 * 2 + ((ulonglong)uStack_40f0 >> 0x20))
                     & 0x7fff;
            if (((uVar17 < uStack_40e8) || (uVar18 < uVar17)) || (uStack_40fc < uVar18)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101f59;
              func_0x(piVar24,7);
              piVar24 = piStack_40f8;
            }
            if ((uVar17 < uStack_40e8) || (uStack_40fc < uVar17)) goto LAB_;
            if (*(ushort *)((ulonglong)uVar17 + (longlong)piVar24) == 5) {
              uStack_40fe = uStack_40fe | 2;
              uStack_40e4 = uStack_40e4 - 1;
              uVar16 = (ulonglong)(uVar17 & 0xffff);
              uStack_40d6 = (ushort)uVar17;
              pbVar1 = (byte *)((longlong)piVar24 + uVar16);
              if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                uVar7 = uStack_40d4 & 0xc7ff;
              }
              else {
                uVar7 = uStack_40d4 ^ (*(ushort *)(pbVar1 + 2) ^ uStack_40d4) & 0x3800;
              }
              uStack_40d4 = (uVar7 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar7;
              uVar26 = (ulonglong)uStack_40d4;
              pbVar20 = (byte *)((longlong)piVar24 +
                                uVar16 + (uVar26 & 0x7ff) * 2 +
                                         (ulonglong)((uVar7 >> 0xb & 7) * 2) + 4);
              if (pbVar20 < pbVar1) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102034;
                func_0x(pbVar1,0x19);
                uVar26 = (ulonglong)uStack_40d4;
                uVar16 = (ulonglong)uStack_40d6;
                piVar24 = piStack_40f8;
              }
              if (uVar18 - uVar17 <
                  (((uStack_40d4 & 0x7ff) * 2 - (int)uVar16) - (int)piStack_40f8) + (int)pbVar20) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102069;
                func_0x((byte *)(uVar16 + (longlong)piVar24),0x19);
                uVar26 = (ulonglong)uStack_40d4;
                uVar16 = (ulonglong)uStack_40d6;
                piVar24 = piStack_40f8;
              }
              if (((uVar26 & 0x3800) != 0) &&
                 (puVar27 = (ushort *)((longlong)piVar24 + uVar16 + 4), piVar14 = piVar22,
                 (uVar26 & 0x3800) != 0)) {
                do {
                  if (((ushort)uVar26 & 0x7ff) < (*puVar27 & 0x7ff)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1020c3;
                    func_0x((byte *)(uVar16 + (longlong)piVar24),0x1a);
                    uVar26 = (ulonglong)uStack_40d4;
                    uVar16 = (ulonglong)uStack_40d6;
                    piVar24 = piStack_40f8;
                  }
                  uVar17 = (int)piVar14 + 1;
                  piVar14 = (int *)(ulonglong)uVar17;
                  puVar27 = puVar27 + 1;
                } while ((int)uVar17 < (int)((uStack_40d4 & 0x3800) >> 0xb));
              }
              break;
            }
            if (*(ushort *)((ulonglong)uVar17 + (longlong)piVar24) < 0x400) break;
            uStack_40fe = uStack_40fe | 1;
            uStack_40e4 = uStack_40e4 - 1;
            if (uStack_40e4 == 0) break;
          }
        }
        if ((*(byte *)piVar24 & 0x40) == 0) {
          uStack_40da = 0;
          uStack_40d8 = 0;
        }
        else {
          uStack_40da = (undefined2)uStack_40fc;
          uStack_40d8 = (undefined2)(uStack_40fc >> 0x10);
          uStack_40fc = uStack_40fc + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10210a;
          uVar13 = func_0x(&uStack_40fe);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102116;
          func_0x(uVar13,auStack_4128);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10211f;
          iVar9 = func_0x(auStack_4128);
          uStack_40fc = uStack_40fc + iVar9;
          piVar24 = piStack_40f8;
        }
        if ((pbStack_40e2 != (byte *)0x0) &&
           (pbStack_40e2 < (byte *)((ulonglong)uStack_40fc + (longlong)piVar24))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102154;
          cVar5 = func_0x(0x1b04090);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10215d;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102177;
              cVar5 = func_0x(0x1b04090);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102193;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1021b7;
                (*_DAT_)(1,0x13f3a9c,0x1513b88,0x886);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1021c5;
          func_0x(piStack_40f8,0x12);
          piVar24 = piStack_40f8;
        }
        if (0x3f3b < uStack_40fc - 1) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1021e5;
          cVar5 = func_0x(0x1b04090);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1021ee;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102208;
              cVar5 = func_0x(0x1b04090);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102224;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102248;
                (*_DAT_)(1,0x13f3a9c,0x1513b88,0x88b);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102256;
          func_0x(piStack_40f8,5);
          piVar24 = piStack_40f8;
        }
      }
LAB_:
      sVar25 = -*(short *)((longlong)&iStackX_10 + lVar11);
      if ((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 0x10) != 0) {
        if ((*(byte *)piVar24 & 0x10) == 0) {
          if ((1 << (*(byte *)piVar24 & 0xe) & 0x1105U) != 0) {
LAB_:
            puVar2 = *(undefined4 **)((longlong)&uStackX_14 + lVar11 + 4);
            piVar14 = puVar2 + 1;
            param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
            *(undefined4 *)((longlong)aiStackX_8 + lVar11) = *puVar2;
            goto LAB_;
          }
        }
        else if (((int)(uint)uStack_40f0 <= *(int *)((longlong)&iStackX_10 + lVar11)) ||
                (*(ushort *)(((ulonglong)uStack_40f0 & 0xffffffff) + (longlong)piVar24) <
                 *(ushort *)((longlong)&uStackX_14 + lVar11))) goto LAB_;
      }
      if ((uint)uStack_40e4 < (uint)(int)sVar25) {
        param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        piVar14 = piVar24;
      }
      else {
        piVar23 = piVar24;
        uVar17 = uStack_40e8;
        if (sVar25 != 1) {
          piVar23 = piStack_40f8;
          uVar17 = *(ushort *)
                    ((longlong)piVar24 +
                    (longlong)sVar25 * 2 + (((ulonglong)uStack_40f0 >> 0x20) - 2)) & 0x7fff;
        }
        uVar18 = *(ushort *)
                  ((longlong)piVar24 + (longlong)sVar25 * 2 + ((ulonglong)uStack_40f0 >> 0x20)) &
                 0x7fff;
        if (((uVar17 < uStack_40e8) || (uVar18 < uVar17)) || (uStack_40fc < uVar18)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102311;
          func_0x(piVar23,7);
          piVar23 = piStack_40f8;
        }
        param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
        *(uint *)((longlong)aiStackX_8 + lVar11) = uVar18 - uVar17;
        piVar14 = (int *)((ulonglong)uVar17 + (longlong)piVar23);
        piVar24 = piVar23;
      }
    }
    else {
      if ((int)(uint)uStack_40f0 < -5) {
        bVar6 = 0xff;
      }
      else if (*(ushort *)(((ulonglong)uStack_40f0 & 0xffffffff) + (longlong)piVar24) < 6) {
        bVar6 = 0xff;
      }
      else {
        bVar6 = *(byte *)(((ulonglong)uStack_40f0 & 0xffffffff) + 2 + (longlong)piVar24) >> 5;
        iVar9 = 1;
      }
LAB_:
      if ((bVar6 & 1) == 0) {
        if ((iVar9 != 0) || ((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 0x10) == 0))
        goto LAB_;
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) =
             **(undefined4 **)((longlong)&uStackX_14 + lVar11 + 4);
        piVar14 = (int *)0x4;
      }
      else {
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        piVar14 = piVar22;
      }
    }
  }
  else {
    *(undefined4 *)(&stack0x00000034 + lVar11) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = &stack0x00000034 + lVar11;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10236d;
    piVar14 = (int *)func_0x(&uStack_40fe,(longlong)&iStackX_10 + lVar11,piVar24,
                                     (longlong)aiStackX_8 + lVar11);
    plVar15 = uStack_40f0;
    piVar24 = piStack_40f8;
    if (((sStack_4100 != 0) && (uStack_40f0 != (longlong *)0x0)) &&
       ((*uStack_40f0 != 0 &&
        (((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 8) == 0 &&
         ((*(uint *)(&stack0x00000034 + lVar11) & 1) == 0)))))) {
      if ((piVar14 == (int *)0x0) || (piVar14 == (int *)0x1178730)) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        piVar14 = (int *)0x0;
      }
      else {
        *(uint *)((longlong)&plStackX_20 + lVar11 + -0x20) = *(uint *)(&stack0x00000034 + lVar11);
        *(longlong *)(&stack0xfffffffffffffff8 + lVar11) = (longlong)aiStackX_8 + lVar11;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1023d0;
        piVar14 = (int *)func_0x
                                   (plVar15,(longlong)&iStackX_10 + lVar11,piVar14,
                                    *(undefined4 *)((longlong)aiStackX_8 + lVar11));
        piVar24 = piStack_40f8;
      }
    }
  }
LAB_:
  if ((piVar14 == (int *)0x0) || (*(int *)((longlong)aiStackX_8 + lVar11) != 4)) {
    lVar12 = *param_2;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102404;
    func_0x(uStack_4158,0x18,lVar12,0x1416d28);
    piVar24 = piStack_40f8;
  }
  *(int *)(param_2 + 2) = *piVar14;
  *(undefined4 *)((longlong)&iStackX_10 + lVar11) = 0xfffffff9;
  *(undefined2 *)((longlong)&uStackX_14 + lVar11) = 7;
  *(ushort *)((longlong)&uStackX_14 + lVar11 + 2) =
       *(ushort *)((longlong)&uStackX_14 + lVar11 + 2) & 0xffe0;
  *(undefined8 *)((longlong)&uStackX_14 + lVar11 + 4) = 0;
  if (sStack_4100 == 0) {
    iVar9 = iVar10;
    if ((*(byte *)piVar24 & 0x10) == 0) {
      if ((1 << (*(byte *)piVar24 & 0xe) & 0x1105U) != 0) {
        bVar6 = 0xff;
        goto LAB_;
      }
LAB_:
      if (uStack_40fc == 0) {
        uStack_40fe = 0;
        uVar16 = (ulonglong)uStack_40f0 & 0xffffffff;
        uVar17 = (uint)uStack_40f0;
        if ((*(byte *)piVar24 & 0x10) != 0) {
          uVar17 = (uint)uStack_40f0 + 2 + (*(ushort *)((longlong)piVar24 + uVar16) + 7 >> 3);
          uVar16 = (ulonglong)uVar17;
        }
        uStack_40f0 = (longlong *)CONCAT44(uVar17,(uint)uStack_40f0);
        if ((*(byte *)piVar24 & 0x20) == 0) {
          uStack_40e4 = 0;
          uStack_40fc = (uint)uVar16;
          uStack_40e8 = (uint)uVar16;
        }
        else {
          puVar27 = (ushort *)(uVar16 + (longlong)piVar24);
          uStack_40e4 = *puVar27;
          if (uStack_40e4 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102530;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102539;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102553;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10256f;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102593;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x80f);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1025a1;
            func_0x(piStack_40f8,3);
            piVar24 = piStack_40f8;
          }
          uStack_40e8 = uStack_40f0._4_4_ + (uStack_40e4 + 1) * 2;
          if (0x1f9e < uStack_40e8) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1025cc;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1025d5;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1025ef;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10260b;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10262f;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x816);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10263d;
            func_0x(piStack_40f8,4);
            piVar24 = piStack_40f8;
          }
          uStack_40fc = puVar27[uStack_40e4] & 0x7fff;
          if (uStack_40fc < uStack_40e8) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102668;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102671;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10268b;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1026a7;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1026cb;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x81d);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1026d9;
            func_0x(piStack_40f8,4);
            piVar24 = piStack_40f8;
          }
          piVar14 = piVar22;
          uVar17 = uStack_40e8;
          puVar4 = puVar27;
          if (uStack_40e4 != 0) {
            do {
              uVar18 = puVar4[1] & 0x7fff;
              if ((uVar18 < uVar17) || (uStack_40fc < uVar18)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102714;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10271d;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102737;
                    cVar5 = func_0x(0x1b04090);
                    if (cVar5 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102753;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102777;
                      (*_DAT_)(1,0x13f3a9c,0x1513b88,0x82a);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102785;
                func_0x(piStack_40f8,4);
                piVar24 = piStack_40f8;
              }
              uVar21 = (int)piVar14 + 1;
              piVar14 = (int *)(ulonglong)uVar21;
              uVar17 = uVar18;
              puVar4 = puVar4 + 1;
            } while ((int)uVar21 < (int)(uint)uStack_40e4);
          }
          while (uVar16 = (ulonglong)uStack_40e4,
                (short)puVar27[(ulonglong)(uStack_40e4 - 1) + 1] < 0) {
            if (uStack_40e4 == 1) {
              uVar16 = 1;
              uVar17 = uStack_40e8;
            }
            else {
              uVar17 = *(ushort *)
                        ((longlong)piVar24 + uVar16 * 2 + (((ulonglong)uStack_40f0 >> 0x20) - 2)) &
                       0x7fff;
            }
            uVar18 = *(ushort *)((longlong)piVar24 + uVar16 * 2 + ((ulonglong)uStack_40f0 >> 0x20))
                     & 0x7fff;
            if (((uVar17 < uStack_40e8) || (uVar18 < uVar17)) || (uStack_40fc < uVar18)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1027fb;
              func_0x(piVar24,7);
              piVar24 = piStack_40f8;
            }
            if ((uVar17 < uStack_40e8) || (uStack_40fc < uVar17)) goto LAB_;
            if (*(ushort *)((ulonglong)uVar17 + (longlong)piVar24) == 5) {
              uStack_40fe = uStack_40fe | 2;
              uStack_40e4 = uStack_40e4 - 1;
              uVar16 = (ulonglong)(uVar17 & 0xffff);
              uStack_40d6 = (ushort)uVar17;
              pbVar1 = (byte *)((longlong)piVar24 + uVar16);
              if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                uVar7 = uStack_40d4 & 0xc7ff;
              }
              else {
                uVar7 = uStack_40d4 ^ (*(ushort *)(pbVar1 + 2) ^ uStack_40d4) & 0x3800;
              }
              uStack_40d4 = (uVar7 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar7;
              uVar26 = (ulonglong)uStack_40d4;
              pbVar20 = (byte *)((ulonglong)((uVar7 >> 0xb & 7) * 2) + 4 + uVar16 +
                                 (uVar26 & 0x7ff) * 2 + (longlong)piVar24);
              if (pbVar20 < pbVar1) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1028d6;
                func_0x(pbVar1,0x19);
                uVar26 = (ulonglong)uStack_40d4;
                uVar16 = (ulonglong)uStack_40d6;
                piVar24 = piStack_40f8;
              }
              if (uVar18 - uVar17 <
                  (((uStack_40d4 & 0x7ff) * 2 - (int)uVar16) - (int)piStack_40f8) + (int)pbVar20) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10290b;
                func_0x((byte *)(uVar16 + (longlong)piVar24),0x19);
                uVar26 = (ulonglong)uStack_40d4;
                uVar16 = (ulonglong)uStack_40d6;
                piVar24 = piStack_40f8;
              }
              if (((uVar26 & 0x3800) != 0) &&
                 (puVar27 = (ushort *)((longlong)piVar24 + uVar16 + 4), piVar14 = piVar22,
                 (uVar26 & 0x3800) != 0)) {
                do {
                  if (((ushort)uVar26 & 0x7ff) < (*puVar27 & 0x7ff)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102963;
                    func_0x((byte *)(uVar16 + (longlong)piVar24),0x1a);
                    uVar26 = (ulonglong)uStack_40d4;
                    uVar16 = (ulonglong)uStack_40d6;
                    piVar24 = piStack_40f8;
                  }
                  uVar17 = (int)piVar14 + 1;
                  piVar14 = (int *)(ulonglong)uVar17;
                  puVar27 = puVar27 + 1;
                } while ((int)uVar17 < (int)((uStack_40d4 & 0x3800) >> 0xb));
              }
              break;
            }
            if (*(ushort *)((ulonglong)uVar17 + (longlong)piVar24) < 0x400) break;
            uStack_40fe = uStack_40fe | 1;
            uStack_40e4 = uStack_40e4 - 1;
            if (uStack_40e4 == 0) break;
          }
        }
        if ((*(byte *)piVar24 & 0x40) == 0) {
          uStack_40da = 0;
          uStack_40d8 = 0;
        }
        else {
          uStack_40da = (undefined2)uStack_40fc;
          uStack_40d8 = (undefined2)(uStack_40fc >> 0x10);
          uStack_40fc = uStack_40fc + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1029aa;
          uVar13 = func_0x(&uStack_40fe);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1029b6;
          func_0x(uVar13,auStack_4120);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1029bf;
          iVar9 = func_0x(auStack_4120);
          uStack_40fc = uStack_40fc + iVar9;
          piVar24 = piStack_40f8;
        }
        if ((pbStack_40e2 != (byte *)0x0) &&
           (pbStack_40e2 < (byte *)((ulonglong)uStack_40fc + (longlong)piVar24))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1029f4;
          cVar5 = func_0x(0x1b04090);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1029fd;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102a17;
              cVar5 = func_0x(0x1b04090);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102a33;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102a57;
                (*_DAT_)(1,0x13f3a9c,0x1513b88,0x886);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102a65;
          func_0x(piStack_40f8,0x12);
          piVar24 = piStack_40f8;
        }
        if (0x3f3b < uStack_40fc - 1) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102a85;
          cVar5 = func_0x(0x1b04090);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102a8e;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102aa8;
              cVar5 = func_0x(0x1b04090);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102ac4;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102ae8;
                (*_DAT_)(1,0x13f3a9c,0x1513b88,0x88b);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102af6;
          func_0x(piStack_40f8,5);
          piVar24 = piStack_40f8;
        }
      }
LAB_:
      sVar25 = -*(short *)((longlong)&iStackX_10 + lVar11);
      if ((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 0x10) != 0) {
        if ((*(byte *)piVar24 & 0x10) == 0) {
          if ((1 << (*(byte *)piVar24 & 0xe) & 0x1105U) != 0) {
LAB_:
            puVar2 = *(undefined4 **)((longlong)&uStackX_14 + lVar11 + 4);
            piVar14 = puVar2 + 1;
            param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
            *(undefined4 *)((longlong)aiStackX_8 + lVar11) = *puVar2;
            goto LAB_;
          }
        }
        else if (((int)(uint)uStack_40f0 <= *(int *)((longlong)&iStackX_10 + lVar11)) ||
                (*(ushort *)(((ulonglong)uStack_40f0 & 0xffffffff) + (longlong)piVar24) <
                 *(ushort *)((longlong)&uStackX_14 + lVar11))) goto LAB_;
      }
      if ((uint)uStack_40e4 < (uint)(int)sVar25) {
        param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        piVar14 = piVar24;
      }
      else {
        piVar23 = piVar24;
        uVar17 = uStack_40e8;
        if (sVar25 != 1) {
          piVar23 = piStack_40f8;
          uVar17 = *(ushort *)
                    ((longlong)piVar24 +
                    (longlong)sVar25 * 2 + (((ulonglong)uStack_40f0 >> 0x20) - 2)) & 0x7fff;
        }
        uVar18 = *(ushort *)
                  ((longlong)piVar24 + (longlong)sVar25 * 2 + ((ulonglong)uStack_40f0 >> 0x20)) &
                 0x7fff;
        if (((uVar17 < uStack_40e8) || (uVar18 < uVar17)) || (uStack_40fc < uVar18)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102bb5;
          func_0x(piVar23,7);
          piVar23 = piStack_40f8;
        }
        param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
        *(uint *)((longlong)aiStackX_8 + lVar11) = uVar18 - uVar17;
        piVar14 = (int *)((ulonglong)uVar17 + (longlong)piVar23);
        piVar24 = piVar23;
      }
    }
    else {
      if ((int)(uint)uStack_40f0 < -6) {
        bVar6 = 0xff;
      }
      else if (*(ushort *)(((ulonglong)uStack_40f0 & 0xffffffff) + (longlong)piVar24) < 7) {
        bVar6 = 0xff;
      }
      else {
        bVar6 = *(byte *)(((ulonglong)uStack_40f0 & 0xffffffff) + 2 + (longlong)piVar24) >> 6;
        iVar9 = 1;
      }
LAB_:
      if ((bVar6 & 1) == 0) {
        if ((iVar9 != 0) || ((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 0x10) == 0))
        goto LAB_;
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) =
             **(undefined4 **)((longlong)&uStackX_14 + lVar11 + 4);
        piVar14 = (int *)0x4;
      }
      else {
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        piVar14 = piVar22;
      }
    }
  }
  else {
    *(undefined4 *)(&stack0x00000038 + lVar11) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = &stack0x00000038 + lVar11;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102c11;
    piVar14 = (int *)func_0x(&uStack_40fe,(longlong)&iStackX_10 + lVar11,piVar24,
                                     (longlong)aiStackX_8 + lVar11);
    plVar15 = uStack_40f0;
    piVar24 = piStack_40f8;
    if (((sStack_4100 != 0) && (uStack_40f0 != (longlong *)0x0)) &&
       ((*uStack_40f0 != 0 &&
        (((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 8) == 0 &&
         ((*(uint *)(&stack0x00000038 + lVar11) & 1) == 0)))))) {
      if ((piVar14 == (int *)0x0) || (piVar14 == (int *)0x1178730)) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        piVar14 = (int *)0x0;
      }
      else {
        *(uint *)((longlong)&plStackX_20 + lVar11 + -0x20) = *(uint *)(&stack0x00000038 + lVar11);
        *(longlong *)(&stack0xfffffffffffffff8 + lVar11) = (longlong)aiStackX_8 + lVar11;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102c74;
        piVar14 = (int *)func_0x
                                   (plVar15,(longlong)&iStackX_10 + lVar11,piVar14,
                                    *(undefined4 *)((longlong)aiStackX_8 + lVar11));
        piVar24 = piStack_40f8;
      }
    }
  }
LAB_:
  if ((piVar14 == (int *)0x0) || (*(int *)((longlong)aiStackX_8 + lVar11) != 4)) {
    lVar12 = *param_2;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102ca8;
    func_0x(uStack_4158,0x19,lVar12,0x1416ea8);
    piVar24 = piStack_40f8;
  }
  *(int *)((longlong)param_2 + 0x14) = *piVar14;
  *(undefined4 *)((longlong)&iStackX_10 + lVar11) = 0xfffffff8;
  *(undefined2 *)((longlong)&uStackX_14 + lVar11) = 8;
  *(ushort *)((longlong)&uStackX_14 + lVar11 + 2) =
       *(ushort *)((longlong)&uStackX_14 + lVar11 + 2) & 0xffe0;
  *(undefined8 *)((longlong)&uStackX_14 + lVar11 + 4) = 0;
  if (sStack_4100 == 0) {
    iVar9 = iVar10;
    if ((*(byte *)piVar24 & 0x10) == 0) {
      if ((1 << (*(byte *)piVar24 & 0xe) & 0x1105U) != 0) {
        bVar6 = 1;
        goto LAB_;
      }
LAB_:
      if (uStack_40fc == 0) {
        uStack_40fe = 0;
        uVar16 = (ulonglong)uStack_40f0 & 0xffffffff;
        uVar17 = (uint)uStack_40f0;
        if ((*(byte *)piVar24 & 0x10) != 0) {
          uVar17 = (uint)uStack_40f0 + 2 + (*(ushort *)((longlong)piVar24 + uVar16) + 7 >> 3);
          uVar16 = (ulonglong)uVar17;
        }
        uStack_40f0 = (longlong *)CONCAT44(uVar17,(uint)uStack_40f0);
        if ((*(byte *)piVar24 & 0x20) == 0) {
          uStack_40e4 = 0;
          uStack_40fc = (uint)uVar16;
          uStack_40e8 = (uint)uVar16;
        }
        else {
          puVar27 = (ushort *)(uVar16 + (longlong)piVar24);
          uStack_40e4 = *puVar27;
          if (uStack_40e4 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102dd9;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102de2;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102dfc;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102e18;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102e3c;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x80f);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102e4a;
            func_0x(piStack_40f8,3);
            piVar24 = piStack_40f8;
          }
          uStack_40e8 = uStack_40f0._4_4_ + (uStack_40e4 + 1) * 2;
          if (0x1f9e < uStack_40e8) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102e75;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102e7e;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102e98;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102eb4;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102ed8;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x816);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102ee6;
            func_0x(piStack_40f8,4);
            piVar24 = piStack_40f8;
          }
          uStack_40fc = puVar27[uStack_40e4] & 0x7fff;
          if (uStack_40fc < uStack_40e8) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102f11;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102f1a;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102f34;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102f50;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102f74;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x81d);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102f82;
            func_0x(piStack_40f8,4);
            piVar24 = piStack_40f8;
          }
          piVar14 = piVar22;
          uVar17 = uStack_40e8;
          puVar4 = puVar27;
          if (uStack_40e4 != 0) {
            do {
              uVar18 = puVar4[1] & 0x7fff;
              if ((uVar18 < uVar17) || (uStack_40fc < uVar18)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102fc2;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102fcb;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102fe5;
                    cVar5 = func_0x(0x1b04090);
                    if (cVar5 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103001;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103025;
                      (*_DAT_)(1,0x13f3a9c,0x1513b88,0x82a);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103033;
                func_0x(piStack_40f8,4);
                piVar24 = piStack_40f8;
              }
              uVar21 = (int)piVar14 + 1;
              piVar14 = (int *)(ulonglong)uVar21;
              uVar17 = uVar18;
              puVar4 = puVar4 + 1;
            } while ((int)uVar21 < (int)(uint)uStack_40e4);
          }
          while (uVar16 = (ulonglong)uStack_40e4,
                (short)puVar27[(ulonglong)(uStack_40e4 - 1) + 1] < 0) {
            if (uStack_40e4 == 1) {
              uVar16 = 1;
              uVar17 = uStack_40e8;
            }
            else {
              uVar17 = *(ushort *)
                        ((longlong)piVar24 + uVar16 * 2 + (((ulonglong)uStack_40f0 >> 0x20) - 2)) &
                       0x7fff;
            }
            uVar18 = *(ushort *)((longlong)piVar24 + uVar16 * 2 + ((ulonglong)uStack_40f0 >> 0x20))
                     & 0x7fff;
            if (((uVar17 < uStack_40e8) || (uVar18 < uVar17)) || (uStack_40fc < uVar18)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1030a9;
              func_0x(piVar24,7);
              piVar24 = piStack_40f8;
            }
            if ((uVar17 < uStack_40e8) || (uStack_40fc < uVar17)) goto LAB_;
            if (*(ushort *)((ulonglong)uVar17 + (longlong)piVar24) == 5) {
              uStack_40fe = uStack_40fe | 2;
              uStack_40e4 = uStack_40e4 - 1;
              uVar16 = (ulonglong)(uVar17 & 0xffff);
              uStack_40d6 = (ushort)uVar17;
              pbVar1 = (byte *)((longlong)piVar24 + uVar16);
              if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                uVar7 = uStack_40d4 & 0xc7ff;
              }
              else {
                uVar7 = uStack_40d4 ^ (*(ushort *)(pbVar1 + 2) ^ uStack_40d4) & 0x3800;
              }
              uStack_40d4 = (uVar7 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar7;
              uVar26 = (ulonglong)uStack_40d4;
              pbVar20 = (byte *)((ulonglong)((uVar7 >> 0xb & 7) * 2) + 4 + uVar16 +
                                 (uVar26 & 0x7ff) * 2 + (longlong)piVar24);
              if (pbVar20 < pbVar1) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103184;
                func_0x(pbVar1,0x19);
                uVar26 = (ulonglong)uStack_40d4;
                uVar16 = (ulonglong)uStack_40d6;
                piVar24 = piStack_40f8;
              }
              if (uVar18 - uVar17 <
                  (((uStack_40d4 & 0x7ff) * 2 - (int)uVar16) - (int)piStack_40f8) + (int)pbVar20) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1031b9;
                func_0x((byte *)(uVar16 + (longlong)piVar24),0x19);
                uVar26 = (ulonglong)uStack_40d4;
                uVar16 = (ulonglong)uStack_40d6;
                piVar24 = piStack_40f8;
              }
              if (((uVar26 & 0x3800) != 0) &&
                 (puVar27 = (ushort *)((longlong)piVar24 + uVar16 + 4), piVar14 = piVar22,
                 (uVar26 & 0x3800) != 0)) {
                do {
                  if (((ushort)uVar26 & 0x7ff) < (*puVar27 & 0x7ff)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103213;
                    func_0x((byte *)(uVar16 + (longlong)piVar24),0x1a);
                    uVar26 = (ulonglong)uStack_40d4;
                    uVar16 = (ulonglong)uStack_40d6;
                    piVar24 = piStack_40f8;
                  }
                  uVar17 = (int)piVar14 + 1;
                  piVar14 = (int *)(ulonglong)uVar17;
                  puVar27 = puVar27 + 1;
                } while ((int)uVar17 < (int)((uStack_40d4 & 0x3800) >> 0xb));
              }
              break;
            }
            if (*(ushort *)((ulonglong)uVar17 + (longlong)piVar24) < 0x400) break;
            uStack_40fe = uStack_40fe | 1;
            uStack_40e4 = uStack_40e4 - 1;
            if (uStack_40e4 == 0) break;
          }
        }
        if ((*(byte *)piVar24 & 0x40) == 0) {
          uStack_40da = 0;
          uStack_40d8 = 0;
        }
        else {
          uStack_40da = (undefined2)uStack_40fc;
          uStack_40d8 = (undefined2)(uStack_40fc >> 0x10);
          uStack_40fc = uStack_40fc + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10325a;
          uVar13 = func_0x(&uStack_40fe);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103266;
          func_0x(uVar13,auStack_4118);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10326f;
          iVar9 = func_0x(auStack_4118);
          uStack_40fc = uStack_40fc + iVar9;
          piVar24 = piStack_40f8;
        }
        if ((pbStack_40e2 != (byte *)0x0) &&
           (pbStack_40e2 < (byte *)((ulonglong)uStack_40fc + (longlong)piVar24))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1032a4;
          cVar5 = func_0x(0x1b04090);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1032ad;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1032c7;
              cVar5 = func_0x(0x1b04090);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1032e3;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103307;
                (*_DAT_)(1,0x13f3a9c,0x1513b88,0x886);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103315;
          func_0x(piStack_40f8,0x12);
          piVar24 = piStack_40f8;
        }
        if (0x3f3b < uStack_40fc - 1) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103335;
          cVar5 = func_0x(0x1b04090);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10333e;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103358;
              cVar5 = func_0x(0x1b04090);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103374;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103398;
                (*_DAT_)(1,0x13f3a9c,0x1513b88,0x88b);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1033a6;
          func_0x(piStack_40f8,5);
          piVar24 = piStack_40f8;
        }
      }
LAB_:
      sVar25 = -*(short *)((longlong)&iStackX_10 + lVar11);
      if ((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 0x10) != 0) {
        if ((*(byte *)piVar24 & 0x10) == 0) {
          if ((1 << (*(byte *)piVar24 & 0xe) & 0x1105U) != 0) {
LAB_:
            puVar2 = *(undefined4 **)((longlong)&uStackX_14 + lVar11 + 4);
            piVar14 = puVar2 + 1;
            param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
            *(undefined4 *)((longlong)aiStackX_8 + lVar11) = *puVar2;
            goto LAB_;
          }
        }
        else if (((int)(uint)uStack_40f0 <= *(int *)((longlong)&iStackX_10 + lVar11)) ||
                (*(ushort *)(((ulonglong)uStack_40f0 & 0xffffffff) + (longlong)piVar24) <
                 *(ushort *)((longlong)&uStackX_14 + lVar11))) goto LAB_;
      }
      if ((uint)uStack_40e4 < (uint)(int)sVar25) {
        param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        piVar14 = piVar24;
      }
      else {
        piVar23 = piVar24;
        uVar17 = uStack_40e8;
        if (sVar25 != 1) {
          piVar23 = piStack_40f8;
          uVar17 = *(ushort *)
                    ((longlong)piVar24 +
                    (longlong)sVar25 * 2 + (((ulonglong)uStack_40f0 >> 0x20) - 2)) & 0x7fff;
        }
        uVar18 = *(ushort *)
                  ((longlong)piVar24 + (longlong)sVar25 * 2 + ((ulonglong)uStack_40f0 >> 0x20)) &
                 0x7fff;
        if (((uVar17 < uStack_40e8) || (uVar18 < uVar17)) || (uStack_40fc < uVar18)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103461;
          func_0x(piVar23,7);
          piVar23 = piStack_40f8;
        }
        param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
        *(uint *)((longlong)aiStackX_8 + lVar11) = uVar18 - uVar17;
        piVar14 = (int *)((ulonglong)uVar17 + (longlong)piVar23);
        piVar24 = piVar23;
      }
    }
    else {
      if ((int)(uint)uStack_40f0 < -7) {
        bVar6 = 1;
      }
      else if (*(ushort *)(((ulonglong)uStack_40f0 & 0xffffffff) + (longlong)piVar24) < 8) {
        bVar6 = 1;
      }
      else {
        bVar6 = *(byte *)(((ulonglong)uStack_40f0 & 0xffffffff) + 2 + (longlong)piVar24) >> 7;
        iVar9 = 1;
      }
LAB_:
      if (bVar6 == 0) {
        if ((iVar9 != 0) || ((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 0x10) == 0))
        goto LAB_;
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) =
             **(undefined4 **)((longlong)&uStackX_14 + lVar11 + 4);
        piVar14 = (int *)0x4;
      }
      else {
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        piVar14 = piVar22;
      }
    }
  }
  else {
    *(undefined4 *)(&stack0x0000003c + lVar11) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = &stack0x0000003c + lVar11;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1034bd;
    piVar14 = (int *)func_0x(&uStack_40fe,(longlong)&iStackX_10 + lVar11,piVar24,
                                     (longlong)aiStackX_8 + lVar11);
    plVar15 = uStack_40f0;
    piVar24 = piStack_40f8;
    if (((sStack_4100 != 0) && (uStack_40f0 != (longlong *)0x0)) &&
       ((*uStack_40f0 != 0 &&
        (((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 8) == 0 &&
         ((*(uint *)(&stack0x0000003c + lVar11) & 1) == 0)))))) {
      if ((piVar14 == (int *)0x0) || (piVar14 == (int *)0x1178730)) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        piVar14 = (int *)0x0;
      }
      else {
        *(uint *)((longlong)&plStackX_20 + lVar11 + -0x20) = *(uint *)(&stack0x0000003c + lVar11);
        *(longlong *)(&stack0xfffffffffffffff8 + lVar11) = (longlong)aiStackX_8 + lVar11;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103520;
        piVar14 = (int *)func_0x
                                   (plVar15,(longlong)&iStackX_10 + lVar11,piVar14,
                                    *(undefined4 *)((longlong)aiStackX_8 + lVar11));
        piVar24 = piStack_40f8;
      }
    }
  }
LAB_:
  if ((piVar14 == (int *)0x0) || (*(int *)((longlong)aiStackX_8 + lVar11) != 4)) {
    lVar12 = *param_2;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103554;
    func_0x(uStack_4158,0x1a,lVar12,0x1416e28);
    piVar24 = piStack_40f8;
  }
  *(int *)((longlong)param_2 + 0x1c) = *piVar14;
  *(undefined4 *)((longlong)&iStackX_10 + lVar11) = 0xfffffff2;
  *(undefined2 *)((longlong)&uStackX_14 + lVar11) = 0xe;
  *(ushort *)((longlong)&uStackX_14 + lVar11 + 2) =
       *(ushort *)((longlong)&uStackX_14 + lVar11 + 2) & 0xffe0;
  *(undefined8 *)((longlong)&uStackX_14 + lVar11 + 4) = 0;
  if (sStack_4100 != 0) {
    *(undefined4 *)(&stack0x00000040 + lVar11) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = &stack0x00000040 + lVar11;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103d53;
    piVar14 = (int *)func_0x(&uStack_40fe,(longlong)&iStackX_10 + lVar11,piVar24,
                                     (longlong)aiStackX_8 + lVar11);
    plVar15 = uStack_40f0;
    if (((sStack_4100 != 0) && (uStack_40f0 != (longlong *)0x0)) &&
       ((*uStack_40f0 != 0 &&
        (((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 8) == 0 &&
         ((*(uint *)(&stack0x00000040 + lVar11) & 1) == 0)))))) {
      if ((piVar14 == (int *)0x0) || (piVar14 == (int *)0x1178730)) {
        *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
        goto LAB_;
      }
      *(uint *)((longlong)&plStackX_20 + lVar11 + -0x20) = *(uint *)(&stack0x00000040 + lVar11);
      *(longlong *)(&stack0xfffffffffffffff8 + lVar11) = (longlong)aiStackX_8 + lVar11;
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0;
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103dbb;
      piVar14 = (int *)func_0x
                                 (plVar15,(longlong)&iStackX_10 + lVar11,piVar14,
                                  *(undefined4 *)((longlong)aiStackX_8 + lVar11));
    }
    iVar8 = *(int *)((longlong)aiStackX_8 + lVar11);
    piVar22 = piVar14;
    goto LAB_;
  }
  iVar8 = iVar10;
  if ((*(byte *)piVar24 & 0x10) == 0) {
    if ((1 << (*(byte *)piVar24 & 0xe) & 0x1105U) != 0) {
      bVar6 = 0xff;
      goto LAB_;
    }
  }
  else {
    if ((int)(uint)uStack_40f0 < -0xd) {
      bVar6 = 0xff;
    }
    else if (*(ushort *)((longlong)piVar24 + ((ulonglong)uStack_40f0 & 0xffffffff)) < 0xe) {
      bVar6 = 0xff;
    }
    else {
      bVar6 = *(byte *)((longlong)piVar24 + ((ulonglong)uStack_40f0 & 0xffffffff) + 3) >> 5;
      iVar10 = 1;
    }
LAB_:
    if ((bVar6 & 1) != 0) {
      *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
      goto LAB_;
    }
    if ((iVar10 == 0) && ((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 0x10) != 0)) {
      iVar8 = **(int **)((longlong)&uStackX_14 + lVar11 + 4);
      *(int *)((longlong)aiStackX_8 + lVar11) = iVar8;
      piVar22 = (int *)0x4;
      goto LAB_;
    }
  }
  if (uStack_40fc == 0) {
    uStack_40fe = 0;
    uVar16 = (ulonglong)uStack_40f0 & 0xffffffff;
    uVar17 = (uint)uStack_40f0;
    if ((*(byte *)piVar24 & 0x10) != 0) {
      uVar17 = (uint)uStack_40f0 + 2 + (*(ushort *)((longlong)piVar24 + uVar16) + 7 >> 3);
      uVar16 = (ulonglong)uVar17;
    }
    uStack_40f0 = (longlong *)CONCAT44(uVar17,(uint)uStack_40f0);
    if ((*(byte *)piVar24 & 0x20) == 0) {
      uStack_40e4 = 0;
      uStack_40fc = (uint)uVar16;
      uStack_40e8 = (uint)uVar16;
    }
    else {
      puVar27 = (ushort *)(uVar16 + (longlong)piVar24);
      uStack_40e4 = *puVar27;
      if (uStack_40e4 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10367c;
        cVar5 = func_0x(0x1b04090);
        if (cVar5 != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103685;
          lVar12 = func_0x();
          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10369f;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1036bb;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1036df;
              (*_DAT_)(1,0x13f3a9c,0x1513b88,0x80f);
            }
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1036ed;
        func_0x(piStack_40f8,3);
        piVar24 = piStack_40f8;
      }
      uStack_40e8 = uStack_40f0._4_4_ + (uStack_40e4 + 1) * 2;
      if (0x1f9e < uStack_40e8) {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103718;
        cVar5 = func_0x(0x1b04090);
        if (cVar5 != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103721;
          lVar12 = func_0x();
          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10373b;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103757;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10377b;
              (*_DAT_)(1,0x13f3a9c,0x1513b88,0x816);
            }
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103789;
        func_0x(piStack_40f8,4);
        piVar24 = piStack_40f8;
      }
      uStack_40fc = puVar27[uStack_40e4] & 0x7fff;
      if (uStack_40fc < uStack_40e8) {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1037b4;
        cVar5 = func_0x(0x1b04090);
        if (cVar5 != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1037bd;
          lVar12 = func_0x();
          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1037d7;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1037f3;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103817;
              (*_DAT_)(1,0x13f3a9c,0x1513b88,0x81d);
            }
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103825;
        func_0x(piStack_40f8,4);
        piVar24 = piStack_40f8;
      }
      piVar14 = piVar22;
      uVar17 = uStack_40e8;
      puVar4 = puVar27;
      if (uStack_40e4 != 0) {
        do {
          uVar18 = puVar4[1] & 0x7fff;
          if ((uVar18 < uVar17) || (uStack_40fc < uVar18)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103862;
            cVar5 = func_0x(0x1b04090);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10386b;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103885;
                cVar5 = func_0x(0x1b04090);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1038a1;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1038c5;
                  (*_DAT_)(1,0x13f3a9c,0x1513b88,0x82a);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1038d3;
            func_0x(piStack_40f8,4);
            piVar24 = piStack_40f8;
          }
          uVar21 = (int)piVar14 + 1;
          piVar14 = (int *)(ulonglong)uVar21;
          uVar17 = uVar18;
          puVar4 = puVar4 + 1;
        } while ((int)uVar21 < (int)(uint)uStack_40e4);
      }
      while (uVar16 = (ulonglong)uStack_40e4, (short)puVar27[(ulonglong)(uStack_40e4 - 1) + 1] < 0)
      {
        if (uStack_40e4 == 1) {
          uVar16 = 1;
          uVar17 = uStack_40e8;
        }
        else {
          uVar17 = *(ushort *)
                    ((longlong)piVar24 + uVar16 * 2 + (((ulonglong)uStack_40f0 >> 0x20) - 2)) &
                   0x7fff;
        }
        uVar18 = *(ushort *)((longlong)piVar24 + uVar16 * 2 + ((ulonglong)uStack_40f0 >> 0x20)) &
                 0x7fff;
        if (((uVar17 < uStack_40e8) || (uVar18 < uVar17)) || (uStack_40fc < uVar18)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103949;
          func_0x(piVar24,7);
          piVar24 = piStack_40f8;
        }
        if ((uVar17 < uStack_40e8) || (uStack_40fc < uVar17)) goto LAB_;
        if (*(ushort *)((ulonglong)uVar17 + (longlong)piVar24) == 5) {
          uStack_40fe = uStack_40fe | 2;
          uStack_40e4 = uStack_40e4 - 1;
          uVar16 = (ulonglong)(uVar17 & 0xffff);
          uStack_40d6 = (ushort)uVar17;
          pbVar1 = (byte *)((longlong)piVar24 + uVar16);
          if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
            uVar7 = uStack_40d4 & 0xc7ff;
          }
          else {
            uVar7 = uStack_40d4 ^ (*(ushort *)(pbVar1 + 2) ^ uStack_40d4) & 0x3800;
          }
          uStack_40d4 = (uVar7 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar7;
          uVar26 = (ulonglong)uStack_40d4;
          pbVar20 = (byte *)((ulonglong)((uVar7 >> 0xb & 7) * 2) + 4 + uVar16 + (uVar26 & 0x7ff) * 2
                            + (longlong)piVar24);
          if (pbVar20 < pbVar1) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103a24;
            func_0x(pbVar1,0x19);
            uVar26 = (ulonglong)uStack_40d4;
            uVar16 = (ulonglong)uStack_40d6;
            piVar24 = piStack_40f8;
          }
          if (uVar18 - uVar17 <
              (((uStack_40d4 & 0x7ff) * 2 - (int)uVar16) - (int)piStack_40f8) + (int)pbVar20) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103a59;
            func_0x((byte *)(uVar16 + (longlong)piVar24),0x19);
            uVar26 = (ulonglong)uStack_40d4;
            uVar16 = (ulonglong)uStack_40d6;
            piVar24 = piStack_40f8;
          }
          if (((uVar26 & 0x3800) != 0) &&
             (puVar27 = (ushort *)((longlong)piVar24 + uVar16 + 4), (uVar26 & 0x3800) != 0)) {
            do {
              if (((ushort)uVar26 & 0x7ff) < (*puVar27 & 0x7ff)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103ab3;
                func_0x((byte *)(uVar16 + (longlong)piVar24),0x1a);
                uVar26 = (ulonglong)uStack_40d4;
                uVar16 = (ulonglong)uStack_40d6;
                piVar24 = piStack_40f8;
              }
              uVar17 = (int)piVar22 + 1;
              piVar22 = (int *)(ulonglong)uVar17;
              puVar27 = puVar27 + 1;
            } while ((int)uVar17 < (int)((uStack_40d4 & 0x3800) >> 0xb));
          }
          break;
        }
        if (*(ushort *)((ulonglong)uVar17 + (longlong)piVar24) < 0x400) break;
        uStack_40fe = uStack_40fe | 1;
        uStack_40e4 = uStack_40e4 - 1;
        if (uStack_40e4 == 0) break;
      }
    }
    if ((*(byte *)piVar24 & 0x40) == 0) {
      uStack_40da = 0;
      uStack_40d8 = 0;
    }
    else {
      uStack_40da = (undefined2)uStack_40fc;
      uStack_40d8 = (undefined2)(uStack_40fc >> 0x10);
      uStack_40fc = uStack_40fc + 0xe;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103afa;
      uVar13 = func_0x(&uStack_40fe);
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103b06;
      func_0x(uVar13,auStack_4110);
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103b0f;
      iVar10 = func_0x(auStack_4110);
      uStack_40fc = uStack_40fc + iVar10;
      piVar24 = piStack_40f8;
    }
    if ((pbStack_40e2 != (byte *)0x0) &&
       (pbStack_40e2 < (byte *)((ulonglong)uStack_40fc + (longlong)piVar24))) {
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103b44;
      cVar5 = func_0x(0x1b04090);
      if (cVar5 != '\0') {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103b4d;
        lVar12 = func_0x();
        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103b67;
          cVar5 = func_0x(0x1b04090);
          if (cVar5 == '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103b83;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103ba7;
            (*_DAT_)(1,0x13f3a9c,0x1513b88,0x886);
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103bb5;
      func_0x(piStack_40f8,0x12);
      piVar24 = piStack_40f8;
    }
    if (0x3f3b < uStack_40fc - 1) {
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103bd5;
      cVar5 = func_0x(0x1b04090);
      if (cVar5 != '\0') {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103bde;
        lVar12 = func_0x();
        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103bf8;
          cVar5 = func_0x(0x1b04090);
          if (cVar5 == '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103c14;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103c38;
            (*_DAT_)(1,0x13f3a9c,0x1513b88,0x88b);
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103c46;
      func_0x(piStack_40f8,5);
      piVar24 = piStack_40f8;
    }
  }
LAB_:
  sVar25 = -*(short *)((longlong)&iStackX_10 + lVar11);
  if ((*(byte *)((longlong)&uStackX_14 + lVar11 + 2) & 0x10) != 0) {
    if ((*(byte *)piVar24 & 0x10) == 0) {
      if ((1 << (*(byte *)piVar24 & 0xe) & 0x1105U) != 0) {
LAB_:
        piVar22 = *(int **)((longlong)&uStackX_14 + lVar11 + 4);
        iVar8 = *piVar22;
        param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
        *(int *)((longlong)aiStackX_8 + lVar11) = iVar8;
        piVar22 = piVar22 + 1;
        goto LAB_;
      }
    }
    else if (((int)(uint)uStack_40f0 <= *(int *)((longlong)&iStackX_10 + lVar11)) ||
            (*(ushort *)(((ulonglong)uStack_40f0 & 0xffffffff) + (longlong)piVar24) <
             *(ushort *)((longlong)&uStackX_14 + lVar11))) goto LAB_;
  }
  if ((uint)uStack_40e4 < (uint)(int)sVar25) {
    param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
    *(undefined4 *)((longlong)aiStackX_8 + lVar11) = 0;
    piVar22 = piVar24;
  }
  else {
    piVar22 = piVar24;
    uVar17 = uStack_40e8;
    if (sVar25 != 1) {
      piVar22 = piStack_40f8;
      uVar17 = *(ushort *)
                ((longlong)piVar24 + (longlong)sVar25 * 2 + (((ulonglong)uStack_40f0 >> 0x20) - 2))
               & 0x7fff;
    }
    uVar18 = *(ushort *)
              ((longlong)piVar24 + (longlong)sVar25 * 2 + ((ulonglong)uStack_40f0 >> 0x20)) & 0x7fff
    ;
    if (((uVar17 < uStack_40e8) || (uVar18 < uVar17)) || (uStack_40fc < uVar18)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103cfe;
      func_0x(piVar22,7);
      piVar22 = piStack_40f8;
    }
    param_2 = *(longlong **)((longlong)&plStackX_20 + lVar11);
    *(uint *)((longlong)aiStackX_8 + lVar11) = uVar18 - uVar17;
    piVar22 = (int *)((ulonglong)uVar17 + (longlong)piVar22);
    iVar8 = uVar18 - uVar17;
  }
LAB_:
  if (iVar8 != 0) {
    if ((piVar22 == (int *)0x0) || (iVar8 != 4)) {
      lVar12 = *param_2;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103de7;
      func_0x(uStack_4158,0x1b,lVar12,0x14184b8);
    }
    *(int *)(param_2 + 3) = *piVar22;
  }
  lVar12 = lStack_4148;
  if (lStack_4148 != -1) {
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103e00;
    plVar15 = (longlong *)func_0x(lStack_4148);
    if (plVar15 == (longlong *)0x0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103e2e;
      (*_DAT_)(0x32);
    }
    else {
      pcVar3 = *(code **)(*plVar15 + 0xd0);
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103e15;
      (*pcVar3)(plVar15,lVar12);
    }
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103e3d;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar11));
  return;
}

