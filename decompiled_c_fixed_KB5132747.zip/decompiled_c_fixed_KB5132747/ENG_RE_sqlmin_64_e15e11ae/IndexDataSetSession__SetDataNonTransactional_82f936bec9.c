
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,longlong *param_3,longlong param_4)

{
  uint *puVar1;
  code *pcVar2;
  byte bVar3;
  char cVar4;
  short sVar5;
  ushort uVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  undefined8 uVar10;
  ulonglong *puVar11;
  ulonglong uVar12;
  longlong lVar13;
  longlong lVar14;
  uint uVar15;
  ulonglong uVar16;
  undefined *puVar17;
  longlong lVar18;
  undefined8 unaff_RBX;
  undefined *puVar19;
  longlong *plVar20;
  uint uVar21;
  uint uVar22;
  uint uVar23;
  ulonglong uVar24;
  byte *pbVar25;
  undefined8 *puVar26;
  ushort uVar27;
  int iVar28;
  undefined8 *puVar29;
  ushort *puVar30;
  int iVar31;
  undefined *puVar32;
  ulonglong uVar33;
  longlong lStackX_8;
  undefined8 uStackX_10;
  uint uStackX_18;
  undefined2 uStackX_1c;
  undefined8 uStackX_1e;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar7 = func_0x();
  lVar7 = -lVar7;
  puVar19 = &stack0xffffffffffffffc8 + lVar7;
  puVar1 = (uint *)(&stack0xfffffffffffffff8 + lVar7);
  *(undefined8 *)(&stack0x000000c8 + lVar7) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002100 + lVar7) = unaff_RBX;
  *(ulonglong *)(&stack0x00002098 + lVar7) = _DAT_ ^ (ulonglong)puVar1;
  *(longlong *)(&stack0x00000038 + lVar7) = param_4;
  *(longlong *)(&stack0x00000048 + lVar7) = param_2;
  puVar32 = (undefined *)0x0;
  *(undefined8 *)(&stack0x000000e8 + lVar7) = 0;
  *(undefined (*) [16])(&stack0x000000d8 + lVar7) = ZEXT816(0);
  *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10007e;
  func_0x(&stack0x000000f8 + lVar7,0,0x1f9e);
  *(undefined8 *)((longlong)&lStackX_8 + lVar7) = 0;
  *(undefined4 *)((longlong)&uStackX_1c + lVar7 + -0x18) = 0;
  *(undefined8 *)((longlong)&uStackX_1c + lVar7 + 2) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar7) = 0;
  *(undefined8 *)((longlong)&uStackX_10 + lVar7) = 0;
  *puVar1 = 0;
  *(undefined4 *)(&stack0x0000007c + lVar7) = 0;
  *(undefined8 *)(&stack0x00000090 + lVar7) = 0;
  *(undefined4 *)(&stack0x00000098 + lVar7) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1000bb;
  func_0x(&stack0x00000060 + lVar7,param_1,2);
  if (*(int *)(param_1 + 0x150) != 0) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0x19d3298;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1000ef;
    (*_DAT_)(1,0x19d3270,0x19a71d0,0x25c6);
  }
  if ((*(byte *)(*(longlong *)(param_1 + 0x18) + 0x218) & 2) != 0) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100120;
    (*_DAT_)(1,0x19d33f8,0x19a71d0,0x25c9);
  }
  if (*(int *)(*(longlong *)(param_1 + 0x118) + 0x100) == 2) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar7) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100154;
    (*_DAT_)(1,0x19d33d0,0x19a71d0,0x25ce);
  }
  if (param_3 == (longlong *)0x0) {
    *(undefined8 *)(&stack0x00000040 + lVar7) = *(undefined8 *)(&stack0x00000088 + lVar7);
    *(undefined8 *)(&stack0x00000038 + lVar7) = *(undefined8 *)(&stack0x00000080 + lVar7);
    param_3 = *(longlong **)(&stack0x00000068 + lVar7);
    puVar19 = &stack0xffffffffffffffc8 + lVar7;
  }
  else {
    puVar26 = (undefined8 *)(param_1 + 0x110);
    if ((*(int *)(param_1 + 0x138) == *(int *)(param_3 + 1)) &&
       (*param_3 == (ulonglong)*(uint6 *)(param_1 + 0x124) * 0x10000)) {
      pcVar2 = *(code **)*puVar26;
      *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10018d;
      sVar5 = (*pcVar2)(puVar26);
      if (*(short *)((longlong)param_3 + 0xc) != sVar5) goto LAB_;
      if (param_3[0x15] != 0) {
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar7) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar7);
        UNLOCK();
      }
    }
    else {
LAB_:
      *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x1001b0;
      func_0x(param_3);
    }
    uVar6 = *(ushort *)(param_3 + 7);
    uVar27 = *(ushort *)((longlong)param_3 + 0x62);
    uVar15 = (uint)uVar27;
    if ((uVar6 & 0x400) == 0) {
      *(longlong *)(&stack0x00000038 + lVar7) = param_4;
      *(undefined8 *)(&stack0x00000040 + lVar7) = 0;
      *puVar1 = 0x10;
      puVar19 = &stack0xffffffffffffffc8 + lVar7;
    }
    else {
      if (uVar27 == 0) {
        puVar17 = (undefined *)0x0;
        uVar21 = 0;
        uVar15 = uVar21;
      }
      else {
        uVar21 = (uint)uVar27 * 8;
        *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x10020d;
        lVar8 = func_0x();
        lVar8 = -lVar8;
        puVar32 = &stack0xfffffffffffffff8 + lVar8 + lVar7;
        *(undefined8 *)((longlong)&uStack_40 + lVar8 + lVar7) = 0x10022a;
        lVar9 = func_0x();
        lVar9 = -lVar9;
        puVar19 = &stack0xffffffffffffffc8 + lVar9 + lVar8 + lVar7;
        puVar17 = &stack0xfffffffffffffff8 + lVar9 + lVar8 + lVar7;
        uVar27 = *(ushort *)(param_3 + 0xb);
        uVar16 = (ulonglong)*(uint *)((longlong)param_3 + 0x54);
        if ((*(uint *)((longlong)param_3 + 0x54) < 0x1f9f) ||
           (uVar16 = (ulonglong)uVar27, 0x1f9d < uVar27)) {
          if ((int)uVar16 != 0) goto LAB_;
        }
        else {
          uVar16 = 0x1f9e;
LAB_:
          *(undefined2 **)(&stack0x000000b8 + lVar7) = (undefined2 *)(param_1 + 0x268);
          *(longlong *)(param_1 + 0x280) = *(longlong *)(param_1 + 0x278);
          *(ushort *)(param_1 + 0x26a) = -(ushort)(*(longlong *)(param_1 + 0x278) != 0) & 8000;
          *(undefined2 *)(param_1 + 0x268) = 0;
          *(undefined8 *)(param_1 + 0x270) = 0;
          *(undefined4 *)(param_1 + 0x26c) = 0;
          uVar12 = uVar16 + 0xf;
          if (uVar12 <= uVar16) {
            uVar12 = 0xffffffffffffff0;
          }
          uVar12 = uVar12 & 0xfffffffffffffff0;
          *(undefined8 *)((longlong)&uStack_40 + lVar9 + lVar8 + lVar7) = 0x1002a4;
          func_0x();
          puVar19 = &stack0xffffffffffffffc8 + -uVar12 + lVar9 + lVar8 + lVar7;
          *(undefined **)(param_1 + 0x270) =
               &stack0xfffffffffffffff8 + -uVar12 + lVar9 + lVar8 + lVar7;
          *(ushort *)(param_1 + 0x26c) = (short)uVar16 - uVar27;
          *(ushort *)(param_1 + 0x26e) = uVar27;
          uVar15 = (uint)*(ushort *)((longlong)param_3 + 0x62);
          uVar6 = *(ushort *)(param_3 + 7);
        }
        param_2 = *(longlong *)(&stack0x00000048 + lVar7);
      }
      *(longlong **)(&stack0x00000068 + lVar7) = param_3;
      *(uint *)(&stack0x00000078 + lVar7) = uVar15 & 0xffff;
      *(longlong *)(&stack0x00000080 + lVar7) = param_4;
      *(undefined8 *)(&stack0x00000040 + lVar7) = 0;
      *(undefined8 *)(&stack0x00000088 + lVar7) = 0;
      *(undefined8 *)(&stack0x000000c0 + lVar7) = 0;
      *(longlong *)(&stack0x00000070 + lVar7) = param_3[0xe];
      if (puVar26 != (undefined8 *)0x0) {
        lVar8 = **(longlong **)(*(longlong *)(param_1 + 0x118) + 0x160);
        *(undefined8 *)(&stack0x00000090 + lVar7) = *(undefined8 *)(lVar8 + 0xa8);
        *(undefined4 *)(&stack0x00000098 + lVar7) = *(undefined4 *)(lVar8 + 0xb0);
      }
      *puVar1 = 0x10;
      if (((uVar6 & 0x400) != 0) && (param_4 != 0)) {
        *puVar1 = 0x14;
        *(undefined **)(&stack0x000000a0 + lVar7) = puVar32;
        *(uint *)(&stack0x000000b0 + lVar7) = uVar21;
        *(undefined **)(&stack0x000000a8 + lVar7) = puVar17;
        *(uint *)(&stack0x000000b4 + lVar7) = uVar21;
        if (puVar32 != (undefined *)0x0) {
          *(undefined4 *)(&stack0x0000007c + lVar7) = 0x16;
          *(undefined8 *)(puVar19 + -8) = 0x100390;
          func_0x(&stack0x00000068 + lVar7);
          *puVar1 = 0x1e;
        }
      }
    }
  }
  iVar31 = 0;
  if ((*(byte *)(param_3 + 7) & 0x10) != 0) {
    *(undefined8 *)(puVar19 + 0x20) = 0x19d33b0;
    *(undefined8 *)(puVar19 + -8) = 0x1003cd;
    (*_DAT_)(1,0x19d3370,0x19a71d0,0x25db);
  }
  *(undefined8 *)(puVar19 + -8) = 0x1003dc;
  func_0x(param_2,&stack0x000000d0 + lVar7);
  *(uint *)(param_2 + 0x10) = *(uint *)(param_2 + 0x10) & 0xfffffeff;
  if (((*(byte *)(param_2 + 0x10) & 0x80) == 0) && ((*(byte *)(param_2 + 0x34) & 1) != 0)) {
    puVar26 = (undefined8 *)(param_2 + 0x48);
  }
  else {
    *(undefined8 *)(puVar19 + -8) = 0x10041b;
    puVar26 = (undefined8 *)func_0x(param_2,1);
  }
  if (*(short *)puVar26 != 0) {
    if (*(int *)((longlong)puVar26 + 4) == 0) {
      *(undefined8 *)(puVar19 + -8) = 0x100af5;
      func_0x((longlong)puVar26 + 2);
    }
    goto LAB_;
  }
  if (*(int *)((longlong)puVar26 + 4) != 0) goto LAB_;
  *(undefined2 *)((longlong)puVar26 + 2) = 0;
  uVar15 = *(uint *)(puVar26 + 2);
  uVar16 = (ulonglong)uVar15;
  *(uint *)((longlong)puVar26 + 0x14) = uVar15;
  pbVar25 = (byte *)puVar26[1];
  bVar3 = *pbVar25;
  if ((bVar3 & 0x10) != 0) {
    uVar15 = uVar15 + 2 + (*(ushort *)(pbVar25 + uVar16) + 7 >> 3);
    uVar16 = (ulonglong)uVar15;
    *(uint *)((longlong)puVar26 + 0x14) = uVar15;
    bVar3 = *pbVar25;
  }
  if ((bVar3 & 0x20) == 0) {
    *(int *)((longlong)puVar26 + 4) = (int)uVar16;
    *(undefined2 *)((longlong)puVar26 + 0x1c) = 0;
    *(int *)(puVar26 + 3) = (int)uVar16;
  }
  else {
    puVar30 = (ushort *)(pbVar25 + uVar16);
    *(ushort **)(&stack0x00000058 + lVar7) = puVar30;
    uVar6 = *puVar30;
    *(ushort *)((longlong)puVar26 + 0x1c) = uVar6;
    if (uVar6 == 0) {
      *(undefined8 *)(puVar19 + -8) = 0x100496;
      cVar4 = func_0x(0x1f32e50);
      if (cVar4 != '\0') {
        *(undefined8 *)(puVar19 + -8) = 0x10049f;
        lVar8 = func_0x();
        if ((lVar8 != 0) && (*(char *)(lVar8 + 0x499) != '\0')) {
          *(undefined8 *)(puVar19 + -8) = 0x1004b9;
          cVar4 = func_0x(0x1f32e50);
          if (cVar4 == '\0') {
            *(undefined8 *)(puVar19 + -8) = 0x1004d5;
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            *(undefined8 *)(puVar19 + 0x20) = 0;
            *(undefined8 *)(puVar19 + -8) = 0x1004fb;
            (*_DAT_)(1,0x182285c,0x1942948,0x80f);
          }
        }
      }
      uVar10 = puVar26[1];
      *(undefined8 *)(puVar19 + -8) = 0x100509;
      func_0x(uVar10,3);
      uVar16 = (ulonglong)*(uint *)((longlong)puVar26 + 0x14);
      uVar6 = *(ushort *)((longlong)puVar26 + 0x1c);
    }
    uVar15 = (int)uVar16 + (uVar6 + 1) * 2;
    *(uint *)(puVar26 + 3) = uVar15;
    if (0x1f9e < uVar15) {
      *(undefined8 *)(puVar19 + -8) = 0x10053b;
      cVar4 = func_0x(0x1f32e50);
      if (cVar4 != '\0') {
        *(undefined8 *)(puVar19 + -8) = 0x100544;
        lVar8 = func_0x();
        if ((lVar8 != 0) && (*(char *)(lVar8 + 0x499) != '\0')) {
          *(undefined8 *)(puVar19 + -8) = 0x10055e;
          cVar4 = func_0x(0x1f32e50);
          if (cVar4 == '\0') {
            *(undefined8 *)(puVar19 + -8) = 0x10057a;
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            *(undefined8 *)(puVar19 + 0x20) = 0;
            *(undefined8 *)(puVar19 + -8) = 0x1005a0;
            (*_DAT_)(1,0x182285c,0x1942948,0x816);
          }
        }
      }
      uVar10 = puVar26[1];
      *(undefined8 *)(puVar19 + -8) = 0x1005ae;
      func_0x(uVar10,4);
      uVar6 = *(ushort *)((longlong)puVar26 + 0x1c);
      uVar15 = *(uint *)(puVar26 + 3);
    }
    uVar16 = (ulonglong)uVar6;
    uVar6 = puVar30[uVar16];
    *(uint *)((longlong)puVar26 + 4) = uVar6 & 0x7fff;
    if ((uVar6 & 0x7fff) < uVar15) {
      *(undefined8 *)(puVar19 + -8) = 0x1005df;
      cVar4 = func_0x(0x1f32e50);
      if (cVar4 != '\0') {
        *(undefined8 *)(puVar19 + -8) = 0x1005e8;
        lVar8 = func_0x();
        if ((lVar8 != 0) && (*(char *)(lVar8 + 0x499) != '\0')) {
          *(undefined8 *)(puVar19 + -8) = 0x100602;
          cVar4 = func_0x(0x1f32e50);
          if (cVar4 == '\0') {
            *(undefined8 *)(puVar19 + -8) = 0x10061e;
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            *(undefined8 *)(puVar19 + 0x20) = 0;
            *(undefined8 *)(puVar19 + -8) = 0x100644;
            (*_DAT_)(1,0x182285c,0x1942948,0x81d);
          }
        }
      }
      uVar10 = puVar26[1];
      *(undefined8 *)(puVar19 + -8) = 0x100652;
      func_0x(uVar10,4);
      uVar15 = *(uint *)(puVar26 + 3);
      uVar16 = (ulonglong)*(ushort *)((longlong)puVar26 + 0x1c);
    }
    if ((short)uVar16 != 0) {
      do {
        puVar30 = puVar30 + 1;
        uVar21 = *puVar30 & 0x7fff;
        if ((uVar21 < uVar15) || (*(uint *)((longlong)puVar26 + 4) < uVar21)) {
          *(undefined8 *)(puVar19 + -8) = 0x100690;
          cVar4 = func_0x(0x1f32e50);
          if (cVar4 != '\0') {
            *(undefined8 *)(puVar19 + -8) = 0x100699;
            lVar8 = func_0x();
            if ((lVar8 != 0) && (*(char *)(lVar8 + 0x499) != '\0')) {
              *(undefined8 *)(puVar19 + -8) = 0x1006b3;
              cVar4 = func_0x(0x1f32e50);
              if (cVar4 == '\0') {
                *(undefined8 *)(puVar19 + -8) = 0x1006cf;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar19 + 0x20) = 0;
                *(undefined8 *)(puVar19 + -8) = 0x1006f5;
                (*_DAT_)(1,0x182285c,0x1942948,0x82a);
              }
            }
          }
          uVar10 = puVar26[1];
          *(undefined8 *)(puVar19 + -8) = 0x100703;
          func_0x(uVar10,4);
        }
        iVar31 = iVar31 + 1;
        uVar16 = (ulonglong)*(ushort *)((longlong)puVar26 + 0x1c);
        uVar15 = uVar21;
      } while (iVar31 < (int)(uint)*(ushort *)((longlong)puVar26 + 0x1c));
      puVar30 = *(ushort **)(&stack0x00000058 + lVar7);
    }
    if ((short)puVar30[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
      lVar8 = puVar26[1];
      do {
        lVar9 = (ulonglong)*(uint *)((longlong)puVar26 + 0x14) + lVar8;
        uVar15 = *(ushort *)(lVar9 + uVar16 * 2) & 0x7fff;
        if ((int)uVar16 == 1) {
          uVar21 = *(uint *)(puVar26 + 3);
          uVar16 = (ulonglong)uVar21;
LAB_:
          if ((uVar15 < (uint)uVar16) ||
             (uVar22 = *(uint *)((longlong)puVar26 + 4), uVar22 < uVar15)) goto LAB_;
        }
        else {
          uVar22 = *(ushort *)(lVar9 + -2 + uVar16 * 2) & 0x7fff;
          uVar16 = (ulonglong)uVar22;
          uVar21 = *(uint *)(puVar26 + 3);
          if (uVar21 <= uVar22) goto LAB_;
LAB_:
          *(undefined8 *)(puVar19 + -8) = 0x10078e;
          func_0x(lVar8,7);
          uVar21 = *(uint *)(puVar26 + 3);
          uVar22 = *(uint *)((longlong)puVar26 + 4);
        }
        uVar23 = (uint)uVar16;
        if ((uVar23 < uVar21) || (uVar22 < uVar23)) goto LAB_;
        lVar8 = puVar26[1];
        if (*(ushort *)(lVar8 + uVar16) == 5) {
          *(ushort *)((longlong)puVar26 + 2) = *(ushort *)((longlong)puVar26 + 2) | 2;
          *(short *)((longlong)puVar26 + 0x1c) = *(short *)((longlong)puVar26 + 0x1c) + -1;
          uVar12 = uVar16 & 0xffff;
          *(short *)((longlong)puVar26 + 0x2a) = (short)uVar16;
          uVar6 = *(ushort *)((longlong)puVar26 + 0x2c) & 0xc7ff;
          if ((*(ushort *)(lVar8 + 2 + uVar12) >> 0xe & 1) != 0) {
            uVar6 = *(ushort *)(lVar8 + 2 + uVar12) & 0x3800 | uVar6;
          }
          *(ushort *)((longlong)puVar26 + 0x2c) = uVar6;
          uVar27 = (uVar6 ^ *(ushort *)(lVar8 + 2 + uVar12)) & 0x7ff ^ uVar6;
          *(ushort *)((longlong)puVar26 + 0x2c) = uVar27;
          uVar16 = puVar26[1];
          uVar24 = (ulonglong)((uVar27 & 0x7ff) * 2) + 4 + uVar16 + (uVar6 >> 0xb & 7) * 2 + uVar12;
          if (uVar24 < uVar16 + uVar12) {
            *(undefined8 *)(puVar19 + -8) = 0x10089a;
            func_0x(uVar16 + uVar12,0x19);
            uVar27 = *(ushort *)((longlong)puVar26 + 0x2c);
            uVar12 = (ulonglong)*(ushort *)((longlong)puVar26 + 0x2a);
            uVar16 = (ulonglong)*(uint *)(puVar26 + 1);
          }
          if (uVar15 - uVar23 < (((uVar27 & 0x7ff) * 2 - (int)uVar12) - (int)uVar16) + (int)uVar24)
          {
            lVar8 = puVar26[1];
            *(undefined8 *)(puVar19 + -8) = 0x1008d2;
            func_0x(uVar12 + lVar8,0x19);
            uVar27 = *(ushort *)((longlong)puVar26 + 0x2c);
          }
          iVar31 = 0;
          if (((uVar27 & 0x3800) != 0) &&
             (puVar30 = (ushort *)
                        (puVar26[1] + 4 + (ulonglong)*(ushort *)((longlong)puVar26 + 0x2a)),
             (uVar27 & 0x3800) != 0)) goto LAB_;
          break;
        }
        if (*(ushort *)(lVar8 + uVar16) < 0x400) break;
        *(ushort *)((longlong)puVar26 + 2) = *(ushort *)((longlong)puVar26 + 2) | 1;
        uVar6 = *(short *)((longlong)puVar26 + 0x1c) - 1;
        *(ushort *)((longlong)puVar26 + 0x1c) = uVar6;
        if ((uVar6 == 0) ||
           (uVar16 = (ulonglong)uVar6, -1 < (short)puVar30[(ulonglong)(uVar6 - 1) + 1])) break;
      } while( true );
    }
    uVar16 = (ulonglong)*(uint *)((longlong)puVar26 + 4);
  }
  goto LAB_;
LAB_:
  do {
    if ((uVar27 & 0x7ff) < (*puVar30 & 0x7ff)) {
      uVar6 = *(ushort *)((longlong)puVar26 + 0x2a);
      lVar8 = puVar26[1];
      *(undefined8 *)(puVar19 + -8) = 0x100938;
      func_0x((ulonglong)uVar6 + lVar8,0x1a);
      uVar27 = *(ushort *)((longlong)puVar26 + 0x2c);
    }
    iVar31 = iVar31 + 1;
    puVar30 = puVar30 + 1;
  } while (iVar31 < (int)(uVar27 >> 0xb & 7));
  uVar16 = (ulonglong)*(uint *)((longlong)puVar26 + 4);
LAB_:
  if ((*(byte *)puVar26[1] & 0x40) == 0) {
    *(undefined4 *)((longlong)puVar26 + 0x26) = 0;
  }
  else {
    *(int *)((longlong)puVar26 + 0x26) = (int)uVar16;
    *(int *)((longlong)puVar26 + 4) = (int)uVar16 + 0xe;
    *(undefined8 *)(puVar19 + -8) = 0x100984;
    uVar10 = func_0x((longlong)puVar26 + 2);
    *(undefined8 *)(puVar19 + -8) = 0x100990;
    func_0x(uVar10,&stack0x00000050 + lVar7);
    *(undefined8 *)(puVar19 + -8) = 0x100999;
    iVar31 = func_0x(&stack0x00000050 + lVar7);
    *(int *)((longlong)puVar26 + 4) = *(int *)((longlong)puVar26 + 4) + iVar31;
    uVar16 = (ulonglong)*(uint *)((longlong)puVar26 + 4);
  }
  iVar31 = (int)uVar16;
  if ((*(ulonglong *)((longlong)puVar26 + 0x1e) != 0) &&
     (*(ulonglong *)((longlong)puVar26 + 0x1e) < uVar16 + puVar26[1])) {
    *(undefined8 *)(puVar19 + -8) = 0x1009d1;
    cVar4 = func_0x(0x1f32e50);
    if (cVar4 != '\0') {
      *(undefined8 *)(puVar19 + -8) = 0x1009da;
      lVar8 = func_0x();
      if ((lVar8 != 0) && (*(char *)(lVar8 + 0x499) != '\0')) {
        *(undefined8 *)(puVar19 + -8) = 0x1009f4;
        cVar4 = func_0x(0x1f32e50);
        if (cVar4 == '\0') {
          *(undefined8 *)(puVar19 + -8) = 0x100a10;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(puVar19 + 0x20) = 0;
          *(undefined8 *)(puVar19 + -8) = 0x100a36;
          (*_DAT_)(1,0x182285c,0x1942948,0x886);
        }
      }
    }
    uVar10 = puVar26[1];
    *(undefined8 *)(puVar19 + -8) = 0x100a44;
    func_0x(uVar10,0x12);
    iVar31 = *(int *)((longlong)puVar26 + 4);
  }
  if (0x3f3b < iVar31 - 1U) {
    *(undefined8 *)(puVar19 + -8) = 0x100a62;
    cVar4 = func_0x(0x1f32e50);
    if (cVar4 != '\0') {
      *(undefined8 *)(puVar19 + -8) = 0x100a6b;
      lVar8 = func_0x();
      if ((lVar8 != 0) && (*(char *)(lVar8 + 0x499) != '\0')) {
        *(undefined8 *)(puVar19 + -8) = 0x100a85;
        cVar4 = func_0x(0x1f32e50);
        if (cVar4 == '\0') {
          *(undefined8 *)(puVar19 + -8) = 0x100aa1;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
          uVar10 = puVar26[1];
          *(undefined8 *)(puVar19 + -8) = 0x100aaf;
          func_0x(uVar10,5);
          goto LAB_;
        }
        *(undefined8 *)(puVar19 + 0x20) = 0;
        *(undefined8 *)(puVar19 + -8) = 0x100ad5;
        (*_DAT_)(1,0x182285c,0x1942948,0x88b);
      }
    }
    uVar10 = puVar26[1];
    *(undefined8 *)(puVar19 + -8) = 0x100ae3;
    func_0x(uVar10,5);
  }
LAB_:
  sVar5 = *(short *)puVar26;
  *(short *)((longlong)&uStackX_1c + lVar7 + -0x1c) = sVar5;
  if (sVar5 == 0) {
    uVar15 = *(uint *)((longlong)puVar26 + 4);
    if (uVar15 == 0) {
      iVar31 = 0;
      *(undefined2 *)((longlong)puVar26 + 2) = 0;
      uVar15 = *(uint *)(puVar26 + 2);
      uVar16 = (ulonglong)uVar15;
      *(uint *)((longlong)puVar26 + 0x14) = uVar15;
      pbVar25 = (byte *)puVar26[1];
      bVar3 = *pbVar25;
      if ((bVar3 & 0x10) != 0) {
        uVar15 = uVar15 + 2 + (*(ushort *)(pbVar25 + uVar16) + 7 >> 3);
        uVar16 = (ulonglong)uVar15;
        *(uint *)((longlong)puVar26 + 0x14) = uVar15;
        bVar3 = *pbVar25;
      }
      iVar28 = (int)uVar16;
      if ((bVar3 & 0x20) == 0) {
        *(int *)((longlong)puVar26 + 4) = iVar28;
        *(undefined2 *)((longlong)puVar26 + 0x1c) = 0;
        *(int *)(puVar26 + 3) = iVar28;
      }
      else {
        puVar30 = (ushort *)(pbVar25 + uVar16);
        *(ushort **)(&stack0x00000050 + lVar7) = puVar30;
        uVar6 = *puVar30;
        *(ushort *)((longlong)puVar26 + 0x1c) = uVar6;
        if (uVar6 == 0) {
          *(undefined8 *)(puVar19 + -8) = 0x100b78;
          cVar4 = func_0x(0x1f32e50);
          if (cVar4 != '\0') {
            *(undefined8 *)(puVar19 + -8) = 0x100b81;
            lVar8 = func_0x();
            if ((lVar8 != 0) && (*(char *)(lVar8 + 0x499) != '\0')) {
              *(undefined8 *)(puVar19 + -8) = 0x100b9b;
              cVar4 = func_0x(0x1f32e50);
              if (cVar4 == '\0') {
                *(undefined8 *)(puVar19 + -8) = 0x100bb7;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(puVar19 + 0x20) = 0;
                *(undefined8 *)(puVar19 + -8) = 0x100bdd;
                (*_DAT_)(1,0x182285c,0x1942948,0x80f);
              }
            }
          }
          uVar10 = puVar26[1];
          *(undefined8 *)(puVar19 + -8) = 0x100beb;
          func_0x(uVar10,3);
          iVar28 = *(int *)((longlong)puVar26 + 0x14);
          pbVar25 = (byte *)puVar26[1];
          uVar6 = *(ushort *)((longlong)puVar26 + 0x1c);
        }
        uVar15 = iVar28 + (uVar6 + 1) * 2;
        *(uint *)(puVar26 + 3) = uVar15;
        if (0x1f9e < uVar15) {
          *(undefined8 *)(puVar19 + -8) = 0x100c20;
          cVar4 = func_0x(0x1f32e50);
          if (cVar4 != '\0') {
            *(undefined8 *)(puVar19 + -8) = 0x100c29;
            lVar8 = func_0x();
            if ((lVar8 != 0) && (*(char *)(lVar8 + 0x499) != '\0')) {
              *(undefined8 *)(puVar19 + -8) = 0x100c43;
              cVar4 = func_0x(0x1f32e50);
              if (cVar4 == '\0') {
                *(undefined8 *)(puVar19 + -8) = 0x100c5f;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar19 + 0x20) = 0;
                *(undefined8 *)(puVar19 + -8) = 0x100c85;
                (*_DAT_)(1,0x182285c,0x1942948,0x816);
              }
            }
          }
          uVar10 = puVar26[1];
          *(undefined8 *)(puVar19 + -8) = 0x100c93;
          func_0x(uVar10,4);
          uVar6 = *(ushort *)((longlong)puVar26 + 0x1c);
          pbVar25 = (byte *)puVar26[1];
          uVar15 = *(uint *)(puVar26 + 3);
        }
        uVar16 = (ulonglong)uVar6;
        uVar6 = puVar30[uVar16];
        *(uint *)((longlong)puVar26 + 4) = uVar6 & 0x7fff;
        if ((uVar6 & 0x7fff) < uVar15) {
          *(undefined8 *)(puVar19 + -8) = 0x100cc7;
          cVar4 = func_0x(0x1f32e50);
          if (cVar4 != '\0') {
            *(undefined8 *)(puVar19 + -8) = 0x100cd0;
            lVar8 = func_0x();
            if ((lVar8 != 0) && (*(char *)(lVar8 + 0x499) != '\0')) {
              *(undefined8 *)(puVar19 + -8) = 0x100cea;
              cVar4 = func_0x(0x1f32e50);
              if (cVar4 == '\0') {
                *(undefined8 *)(puVar19 + -8) = 0x100d06;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar19 + 0x20) = 0;
                *(undefined8 *)(puVar19 + -8) = 0x100d2c;
                (*_DAT_)(1,0x182285c,0x1942948,0x81d);
              }
            }
          }
          uVar10 = puVar26[1];
          *(undefined8 *)(puVar19 + -8) = 0x100d3a;
          func_0x(uVar10,4);
          uVar15 = *(uint *)(puVar26 + 3);
          uVar16 = (ulonglong)*(ushort *)((longlong)puVar26 + 0x1c);
          pbVar25 = (byte *)puVar26[1];
        }
        if ((short)uVar16 != 0) {
          do {
            puVar30 = puVar30 + 1;
            uVar21 = *puVar30 & 0x7fff;
            if ((uVar21 < uVar15) || (*(uint *)((longlong)puVar26 + 4) < uVar21)) {
              *(undefined8 *)(puVar19 + -8) = 0x100d80;
              cVar4 = func_0x(0x1f32e50);
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar19 + -8) = 0x100d89;
                lVar8 = func_0x();
                if ((lVar8 != 0) && (*(char *)(lVar8 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar19 + -8) = 0x100da3;
                  cVar4 = func_0x(0x1f32e50);
                  if (cVar4 == '\0') {
                    *(undefined8 *)(puVar19 + -8) = 0x100dbf;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar19 + 0x20) = 0;
                    *(undefined8 *)(puVar19 + -8) = 0x100de5;
                    (*_DAT_)(1,0x182285c,0x1942948,0x82a);
                  }
                }
              }
              uVar10 = puVar26[1];
              *(undefined8 *)(puVar19 + -8) = 0x100df3;
              func_0x(uVar10,4);
            }
            iVar31 = iVar31 + 1;
            uVar16 = (ulonglong)*(ushort *)((longlong)puVar26 + 0x1c);
            uVar15 = uVar21;
          } while (iVar31 < (int)(uint)*(ushort *)((longlong)puVar26 + 0x1c));
          pbVar25 = (byte *)puVar26[1];
          puVar30 = *(ushort **)(&stack0x00000050 + lVar7);
        }
        uVar12 = uVar16;
        if ((short)puVar30[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
          do {
            sVar5 = (short)uVar16;
            uVar21 = *(ushort *)
                      (pbVar25 + uVar12 * 2 + (ulonglong)*(uint *)((longlong)puVar26 + 0x14)) &
                     0x7fff;
            if ((int)uVar12 == 1) {
              uVar22 = *(uint *)(puVar26 + 3);
              uVar16 = (ulonglong)uVar22;
LAB_:
              if ((uVar21 < (uint)uVar16) ||
                 (uVar15 = *(uint *)((longlong)puVar26 + 4), uVar15 < uVar21)) goto LAB_;
            }
            else {
              uVar16 = (ulonglong)
                       (*(ushort *)
                         (pbVar25 +
                         uVar12 * 2 + ((ulonglong)*(uint *)((longlong)puVar26 + 0x14) - 2)) & 0x7fff
                       );
              uVar22 = *(uint *)(puVar26 + 3);
              if (uVar22 <= (*(ushort *)
                              (pbVar25 +
                              uVar12 * 2 + ((ulonglong)*(uint *)((longlong)puVar26 + 0x14) - 2)) &
                            0x7fff)) goto LAB_;
LAB_:
              *(undefined8 *)(puVar19 + -8) = 0x100e83;
              func_0x(pbVar25,7);
              uVar22 = *(uint *)(puVar26 + 3);
              uVar15 = *(uint *)((longlong)puVar26 + 4);
              pbVar25 = (byte *)puVar26[1];
              sVar5 = *(short *)((longlong)puVar26 + 0x1c);
            }
            uVar23 = (uint)uVar16;
            if ((uVar23 < uVar22) || (uVar15 < uVar23)) goto LAB_;
            if (*(ushort *)(pbVar25 + uVar16) == 5) {
              *(ushort *)((longlong)puVar26 + 2) = *(ushort *)((longlong)puVar26 + 2) | 2;
              *(short *)((longlong)puVar26 + 0x1c) = sVar5 + -1;
              uVar24 = uVar16 & 0xffff;
              *(short *)((longlong)puVar26 + 0x2a) = (short)uVar16;
              uVar12 = puVar26[1];
              uVar16 = uVar24 + uVar12;
              uVar6 = *(ushort *)((longlong)puVar26 + 0x2c) & 0xc7ff;
              if ((*(ushort *)(uVar16 + 2) >> 0xe & 1) != 0) {
                uVar6 = *(ushort *)(uVar16 + 2) & 0x3800 | uVar6;
              }
              *(ushort *)((longlong)puVar26 + 0x2c) = uVar6;
              uVar27 = (uVar6 ^ *(ushort *)(uVar16 + 2)) & 0x7ff ^ uVar6;
              *(ushort *)((longlong)puVar26 + 0x2c) = uVar27;
              uVar33 = (ulonglong)((uVar27 & 0x7ff) * 2) + 4 + (uVar6 >> 0xb & 7) * 2 + uVar24 +
                       uVar12;
              if (uVar33 < uVar16) {
                *(undefined8 *)(puVar19 + -8) = 0x100fa1;
                func_0x(uVar16,0x19);
                uVar27 = *(ushort *)((longlong)puVar26 + 0x2c);
                uVar24 = (ulonglong)*(ushort *)((longlong)puVar26 + 0x2a);
                uVar12 = (ulonglong)*(uint *)(puVar26 + 1);
              }
              if (uVar21 - uVar23 <
                  (((uVar27 & 0x7ff) * 2 - (int)uVar24) - (int)uVar12) + (int)uVar33) {
                lVar8 = puVar26[1];
                *(undefined8 *)(puVar19 + -8) = 0x100fdd;
                func_0x(uVar24 + lVar8,0x19);
                uVar27 = *(ushort *)((longlong)puVar26 + 0x2c);
              }
              if ((uVar27 & 0x3800) != 0) {
                puVar30 = (ushort *)
                          (puVar26[1] + (ulonglong)*(ushort *)((longlong)puVar26 + 0x2a) + 4);
                iVar31 = 0;
                if ((uVar27 & 0x3800) != 0) {
                  do {
                    if ((uVar27 & 0x7ff) < (*puVar30 & 0x7ff)) {
                      uVar6 = *(ushort *)((longlong)puVar26 + 0x2a);
                      lVar8 = puVar26[1];
                      *(undefined8 *)(puVar19 + -8) = 0x101047;
                      func_0x((ulonglong)uVar6 + lVar8,0x1a);
                      uVar27 = *(ushort *)((longlong)puVar26 + 0x2c);
                    }
                    iVar31 = iVar31 + 1;
                    puVar30 = puVar30 + 1;
                  } while (iVar31 < (int)(uVar27 >> 0xb & 7));
                }
              }
              pbVar25 = (byte *)puVar26[1];
              goto LAB_;
            }
            if (*(ushort *)(pbVar25 + uVar16) < 0x400) goto LAB_;
            *(ushort *)((longlong)puVar26 + 2) = *(ushort *)((longlong)puVar26 + 2) | 1;
            uVar6 = sVar5 - 1;
            *(ushort *)((longlong)puVar26 + 0x1c) = uVar6;
            if (uVar6 == 0) goto LAB_;
            uVar16 = (ulonglong)uVar6;
            uVar12 = (ulonglong)(uint)uVar6;
          } while ((short)puVar30[(ulonglong)(uVar6 - 1) + 1] < 0);
          uVar16 = (ulonglong)*(uint *)((longlong)puVar26 + 4);
        }
        else {
LAB_:
          uVar16 = (ulonglong)*(uint *)((longlong)puVar26 + 4);
        }
      }
      iVar31 = 0;
      if ((*pbVar25 & 0x40) == 0) {
        *(undefined4 *)((longlong)puVar26 + 0x26) = 0;
      }
      else {
        *(int *)((longlong)puVar26 + 0x26) = *(int *)((longlong)puVar26 + 4);
        *(int *)((longlong)puVar26 + 4) = *(int *)((longlong)puVar26 + 4) + 0xe;
        *(undefined8 *)(puVar19 + -8) = 0x1010a2;
        puVar11 = (ulonglong *)func_0x((longlong)puVar26 + 2);
        uVar27 = (ushort)(*puVar11 >> 0x30);
        uVar6 = uVar27;
        if ((((uint)(int)(short)uVar27 >> 1 ^ (int)(short)uVar27) & 0x2000) != 0) {
          uVar6 = uVar27 & 0xdfff;
          if ((uVar27 >> 0xe & 1) != 0) {
            uVar6 = uVar27 | 0x2000;
          }
        }
        if (uVar6 == 0xfffc) {
          iVar31 = (int)((*puVar11 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)((longlong)puVar26 + 4) = *(int *)((longlong)puVar26 + 4) + iVar31;
        uVar16 = (ulonglong)*(uint *)((longlong)puVar26 + 4);
        pbVar25 = (byte *)puVar26[1];
      }
      uVar15 = (uint)uVar16;
      if ((*(byte **)((longlong)puVar26 + 0x1e) != (byte *)0x0) &&
         (*(byte **)((longlong)puVar26 + 0x1e) < pbVar25 + uVar16)) {
        *(undefined8 *)(puVar19 + -8) = 0x101133;
        cVar4 = func_0x(0x1f32e50);
        if (cVar4 != '\0') {
          *(undefined8 *)(puVar19 + -8) = 0x10113c;
          lVar8 = func_0x();
          if ((lVar8 != 0) && (*(char *)(lVar8 + 0x499) != '\0')) {
            *(undefined8 *)(puVar19 + -8) = 0x101156;
            cVar4 = func_0x(0x1f32e50);
            if (cVar4 == '\0') {
              *(undefined8 *)(puVar19 + -8) = 0x101172;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(puVar19 + 0x20) = 0;
              *(undefined8 *)(puVar19 + -8) = 0x101198;
              (*_DAT_)(1,0x182285c,0x1942948,0x886);
            }
          }
        }
        uVar10 = puVar26[1];
        *(undefined8 *)(puVar19 + -8) = 0x1011a6;
        func_0x(uVar10,0x12);
        uVar15 = *(uint *)((longlong)puVar26 + 4);
      }
      if ((uVar15 == 0) || (0x3f3c < uVar15)) {
        *(undefined8 *)(puVar19 + -8) = 0x1011c6;
        cVar4 = func_0x(0x1f32e50);
        if (cVar4 != '\0') {
          *(undefined8 *)(puVar19 + -8) = 0x1011cf;
          lVar8 = func_0x();
          if ((lVar8 != 0) && (*(char *)(lVar8 + 0x499) != '\0')) {
            *(undefined8 *)(puVar19 + -8) = 0x1011e9;
            cVar4 = func_0x(0x1f32e50);
            if (cVar4 == '\0') {
              *(undefined8 *)(puVar19 + -8) = 0x101205;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(puVar19 + 0x20) = 0;
              *(undefined8 *)(puVar19 + -8) = 0x10122b;
              (*_DAT_)(1,0x182285c,0x1942948,0x88b);
            }
          }
        }
        uVar10 = puVar26[1];
        *(undefined8 *)(puVar19 + -8) = 0x101239;
        func_0x(uVar10,5);
        uVar15 = *(uint *)((longlong)puVar26 + 4);
      }
    }
LAB_:
    if ((uVar15 < 9) && (((*(byte *)puVar26[1] & 0xe) == 0 || ((*(byte *)puVar26[1] & 0xe) == 0xc)))
       ) {
      uVar15 = 9;
    }
    *(undefined4 *)((longlong)&uStackX_10 + lVar7) = *(undefined4 *)(puVar26 + 2);
    *(undefined2 *)((longlong)&uStackX_1c + lVar7 + -0x1a) = *(undefined2 *)((longlong)puVar26 + 2);
    *(undefined4 *)((longlong)&uStackX_1c + lVar7 + -0x18) = *(undefined4 *)((longlong)puVar26 + 4);
    *(undefined2 *)((longlong)&uStackX_1c + lVar7) = *(undefined2 *)((longlong)puVar26 + 0x1c);
    *(undefined4 *)((longlong)&uStackX_10 + lVar7 + 4) = *(undefined4 *)((longlong)puVar26 + 0x14);
    *(undefined4 *)((longlong)&uStackX_18 + lVar7) = *(undefined4 *)(puVar26 + 3);
    *(undefined4 *)(&stack0x00000026 + lVar7) = *(undefined4 *)((longlong)puVar26 + 0x26);
    uVar10 = puVar26[1];
    *(undefined8 *)(puVar19 + -8) = 0x1012a5;
    func_0x(&stack0x000000f8 + lVar7,0x1f9e,uVar10,uVar15);
    *(undefined **)((longlong)&lStackX_8 + lVar7) = &stack0x000000f8 + lVar7;
    *(undefined8 *)(puVar19 + -8) = 0x1012b9;
    iVar31 = func_0x((longlong)&uStackX_1c + lVar7 + -0x1a);
    if (iVar31 != 0) {
      lVar8 = *(longlong *)((longlong)&lStackX_8 + lVar7);
      puVar30 = (ushort *)((ulonglong)*(uint *)((longlong)&uStackX_10 + lVar7 + 4) + lVar8);
      uVar15 = *puVar30 - 1;
      if ((*(byte *)((longlong)&uStackX_1c + lVar7 + -0x1a) & 1) == 0) {
        uVar15 = (uint)*puVar30;
      }
      uVar21 = *(uint *)((longlong)&uStackX_18 + lVar7);
      if (uVar15 != 1) {
        uVar21 = puVar30[(longlong)(int)uVar15 + -1] & 0x7fff;
      }
      uVar15 = puVar30[(int)uVar15] & 0x7fff;
      if (((uVar21 < *(uint *)((longlong)&uStackX_18 + lVar7)) || (uVar15 < uVar21)) ||
         (*(uint *)((longlong)&uStackX_1c + lVar7 + -0x18) < uVar15)) {
        *(undefined8 *)(puVar19 + -8) = 0x101319;
        func_0x(lVar8,7);
        lVar8 = *(longlong *)((longlong)&lStackX_8 + lVar7);
      }
      uVar12 = (ulonglong)(uVar21 & 0xffff);
      *(short *)(&stack0x0000002a + lVar7) = (short)uVar21;
      uVar16 = lVar8 + uVar12;
      uVar6 = *(ushort *)(&stack0x0000002c + lVar7);
      if ((*(ushort *)(uVar16 + 2) & 0x4000) == 0) {
        uVar6 = uVar6 & 0xc7ff;
      }
      else {
        uVar6 = uVar6 ^ (uVar6 ^ *(ushort *)(uVar16 + 2)) & 0x3800;
      }
      *(ushort *)(&stack0x0000002c + lVar7) = uVar6;
      uVar27 = (uVar6 ^ *(ushort *)(uVar16 + 2)) & 0x7ff ^ uVar6;
      uVar24 = (ulonglong)uVar27;
      *(ushort *)(&stack0x0000002c + lVar7) = uVar27;
      uVar33 = (ulonglong)((uVar6 >> 0xb & 7) * 2) + 4 + uVar12 + (uVar24 & 0x7ff) * 2 + lVar8;
      if (uVar33 < uVar16) {
        *(undefined8 *)(puVar19 + -8) = 0x1013ae;
        func_0x(uVar16,0x19);
        uVar24 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar7);
        uVar12 = (ulonglong)*(ushort *)(&stack0x0000002a + lVar7);
        lVar8 = *(longlong *)((longlong)&lStackX_8 + lVar7);
      }
      if (uVar15 - uVar21 <
          (((*(uint *)(&stack0x0000002c + lVar7) & 0x7ff) * 2 - (int)uVar12) -
          *(int *)((longlong)&lStackX_8 + lVar7)) + (int)uVar33) {
        *(undefined8 *)(puVar19 + -8) = 0x1013e5;
        func_0x(uVar12 + lVar8,0x19);
        uVar24 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar7);
        uVar12 = (ulonglong)*(ushort *)(&stack0x0000002a + lVar7);
        lVar8 = *(longlong *)((longlong)&lStackX_8 + lVar7);
      }
      if ((uVar24 & 0x3800) != 0) {
        puVar30 = (ushort *)(lVar8 + 4 + uVar12);
        iVar31 = 0;
        if ((uVar24 & 0x3800) != 0) {
          do {
            if (((ushort)uVar24 & 0x7ff) < (*puVar30 & 0x7ff)) {
              *(undefined8 *)(puVar19 + -8) = 0x101446;
              func_0x(uVar12 + lVar8,0x1a);
              uVar24 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar7);
              uVar12 = (ulonglong)*(ushort *)(&stack0x0000002a + lVar7);
              lVar8 = *(longlong *)((longlong)&lStackX_8 + lVar7);
            }
            iVar31 = iVar31 + 1;
            puVar30 = puVar30 + 1;
          } while (iVar31 < (int)(*(uint *)(&stack0x0000002c + lVar7) >> 0xb & 7));
        }
      }
    }
  }
  else if (((*(short *)puVar26 == 0) || ((longlong *)puVar26[2] == (longlong *)0x0)) ||
          (*(longlong *)puVar26[2] == 0)) {
    *(undefined8 *)(puVar19 + -8) = 0x1014b4;
    func_0x((longlong)&uStackX_1c + lVar7 + -0x1a,&stack0x000000f8 + lVar7,0x1f9e,
                    (longlong)puVar26 + 2);
    if (*(short *)puVar26 == 0) {
      uVar10 = 0;
    }
    else {
      uVar10 = puVar26[2];
    }
    *(undefined8 *)((longlong)&uStackX_10 + lVar7) = uVar10;
  }
  else {
    *(undefined8 *)(puVar19 + -8) = 0x101498;
    func_0x((longlong)&uStackX_1c + lVar7 + -0x1c,&stack0x000000f8 + lVar7,0x1f9e,puVar26);
  }
  plVar20 = *(longlong **)(&stack0x00000048 + lVar7);
  pcVar2 = *(code **)(*plVar20 + 8);
  *(undefined8 *)(puVar19 + -8) = 0x1014d4;
  (*pcVar2)();
  puVar26[1] = 0;
  *puVar26 = 0xffff;
  puVar26[3] = 0;
  puVar26[4] = 0;
  puVar26[2] = 0;
  *(undefined4 *)(puVar26 + 6) = 0;
  puVar26[5] = 0;
  uVar6 = 0;
  if (*(short *)((longlong)param_3 + 0x62) != 0) {
    do {
      lVar18 = (ulonglong)uVar6 * 0x50 + param_3[0xe];
      uVar15 = *(uint *)(lVar18 + 0x40);
      lVar8 = *(longlong *)(&stack0x00000038 + lVar7);
      lVar9 = *(longlong *)(&stack0x00000040 + lVar7);
      if ((uVar15 >> 10 & 1) == 0) {
LAB_:
        if (((uVar15 >> 0xf & 1) == 0) || ((*puVar1 & 8) == 0)) {
          lVar13 = *(longlong *)(lVar18 + 0x48);
          if ((uVar15 >> 8 & 1) == 0) {
            puVar29 = (undefined8 *)(ulonglong)*(ushort *)(lVar13 + 2);
          }
          else {
            lVar14 = lVar8;
            if ((*(byte *)(lVar13 + 0x2a) & 0x10) != 0) {
              lVar14 = lVar9;
            }
            puVar29 = (undefined8 *)(ulonglong)*(uint *)(lVar14 + *(longlong *)(lVar13 + 0x18));
          }
        }
        else {
          puVar29 = (undefined8 *)
                    (ulonglong)
                    *(uint *)(*(longlong *)(&stack0x000000a0 + lVar7) +
                             (ulonglong)*(uint *)(lVar18 + 0x38) * 8);
        }
        if (((uVar15 & 0x48000) == 0x48000) && ((*puVar1 & 8) != 0)) {
          puVar26 = *(undefined8 **)
                     (*(longlong *)(&stack0x000000a8 + lVar7) +
                     (ulonglong)*(uint *)(lVar18 + 0x38) * 8);
        }
        else {
          if ((*(byte *)(*(longlong *)(lVar18 + 0x48) + 0x2a) & 0x10) != 0) {
            lVar8 = lVar9;
          }
          puVar26 = (undefined8 *)(lVar8 + *(longlong *)(lVar18 + 0x28));
          if ((uVar15 >> 0xb & 1) != 0) {
            puVar26 = (undefined8 *)*puVar26;
          }
        }
      }
      else {
        lVar13 = lVar8;
        if ((*(byte *)(*(longlong *)(lVar18 + 0x48) + 0x2a) & 0x10) != 0) {
          lVar13 = lVar9;
        }
        puVar26 = (undefined8 *)0x0;
        puVar29 = (undefined8 *)0x0;
        if (*(char *)(lVar13 + *(longlong *)(lVar18 + 0x30)) != '\x03') goto LAB_;
      }
      *(undefined8 *)(puVar19 + -8) = 0x1015e7;
      func_0x((longlong)&uStackX_1c + lVar7 + -0x1c,lVar18,puVar26,puVar29);
      uVar6 = uVar6 + 1;
    } while (uVar6 < *(ushort *)((longlong)param_3 + 0x62));
    plVar20 = *(longlong **)(&stack0x00000048 + lVar7);
  }
  *(undefined8 *)(puVar19 + -8) = 0x10160c;
  func_0x(plVar20,(longlong)&uStackX_1c + lVar7 + -0x1c,&stack0x000000d0 + lVar7);
  plVar20 = *(longlong **)(&stack0x00000060 + lVar7);
  if (plVar20 != (longlong *)0x0) {
    pcVar2 = *(code **)(*plVar20 + 0xd0);
    *(undefined8 *)(puVar19 + -8) = 0x101621;
    (*pcVar2)(plVar20,0);
  }
  uVar16 = *(ulonglong *)(&stack0x00002098 + lVar7);
  *(undefined8 *)(puVar19 + -8) = 0x101630;
  func_0x(uVar16 ^ (ulonglong)puVar1);
  return;
}

