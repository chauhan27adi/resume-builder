
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint *param_2,short *param_3)

{
  uint *puVar1;
  ushort *puVar2;
  byte *pbVar3;
  longlong *plVar4;
  ushort *puVar5;
  bool bVar6;
  byte bVar7;
  char cVar8;
  ushort uVar9;
  ushort uVar10;
  int iVar11;
  uint uVar12;
  longlong lVar13;
  longlong lVar14;
  undefined8 uVar15;
  uint uVar16;
  ulonglong uVar17;
  short sVar18;
  undefined8 unaff_RBX;
  undefined *puVar19;
  uint *puVar20;
  uint uVar22;
  ushort *puVar23;
  short *psVar24;
  uint uVar25;
  ulonglong uVar26;
  uint uStackX_18;
  uint auStackX_1c [3];
  undefined8 uStack_40;
  ulonglong uVar21;
  
  uStack_40 = 0x100016;
  lVar13 = func_0x();
  lVar13 = -lVar13;
  puVar19 = &stack0xffffffffffffffc8 + lVar13;
  puVar1 = (uint *)((longlong)&uStackX_18 + lVar13);
  *(undefined8 *)(&stack0x00000040 + lVar13) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000040f0 + lVar13) = unaff_RBX;
  *(ulonglong *)(&stack0x00004088 + lVar13) = _DAT_ ^ (ulonglong)puVar1;
  *(short **)(&stack0x00000028 + lVar13) = param_3;
  *(longlong *)(&stack0x00000038 + lVar13) = param_1;
  lVar14 = *(longlong *)(param_1 + 0x58);
  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100060;
  func_0x(&stack0x00000048 + lVar13,&stack0x00000150 + lVar13);
  *(undefined8 *)(&stack0x00000048 + lVar13) = 0x849748;
  *(undefined4 *)((longlong)auStackX_1c + lVar13 + 4) = 0x80000;
  uVar21 = 0;
  bVar6 = false;
  puVar20 = (uint *)0x0;
  uVar22 = 0;
  lVar14 = *(longlong *)(lVar14 + 8);
  uVar26 = uVar21;
  uVar12 = uVar22;
  if (*(int *)(lVar14 + 0x100) == 2) {
    if ((*(byte *)(lVar14 + 0x42) & 4) == 0) {
      uVar26 = (ulonglong)*(uint *)(lVar14 + 0xb0);
      if (0x1f9e < *(uint *)(lVar14 + 0xb0)) {
        uVar26 = 0x1f9e;
      }
    }
    else {
      uVar26 = 0x1f9e;
    }
    uVar12 = (uint)uVar26;
    uVar17 = uVar26 + 0xf;
    if (uVar17 <= uVar26) {
      uVar17 = 0xffffffffffffff0;
    }
    uVar17 = uVar17 & 0xfffffffffffffff0;
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1000c2;
    func_0x();
    puVar19 = &stack0xffffffffffffffc8 + -uVar17 + lVar13;
    uVar26 = (longlong)&uStackX_18 + -uVar17 + lVar13;
  }
  bVar7 = *(byte *)(param_2 + 8);
  uVar25 = (uint)*(ushort *)(param_2 + 0xe);
  puVar2 = (ushort *)(param_3 + 1);
  psVar24 = param_3;
  if (*param_3 == 0) {
    uVar12 = *param_2;
    if ((uVar12 & 0xc0000000) == 0x80000000) {
      *(undefined8 *)(puVar19 + -8) = 0x100a11;
      iVar11 = func_0x(puVar2);
      if (iVar11 != 0) {
        *(undefined8 *)(puVar19 + -8) = 0x100a29;
        puVar20 = (uint *)func_0x(param_3 + 0x15,param_2,puVar1,&stack0x00000028 + lVar13);
        goto LAB_;
      }
      uVar12 = 0;
      *puVar1 = 0;
    }
    else {
      if (((bVar7 & 2) != 0) || ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0)) {
        pbVar3 = *(byte **)(param_3 + 4);
        if ((*pbVar3 & 0x10) == 0) {
          if ((1 << (*pbVar3 & 0xe) & 0x1105U) != 0) goto LAB_;
          bVar6 = true;
LAB_:
          if ((bVar7 & 2) != 0) goto LAB_;
        }
        else {
          uVar22 = *(uint *)(param_3 + 8);
          if ((int)uVar22 <= (int)uVar12) {
LAB_:
            uVar22 = ~(uint)(*(ushort *)((longlong)param_2 + 6) >> 4) & 1;
            goto LAB_;
          }
          if ((uint)*(ushort *)(pbVar3 + uVar22) < (uint)*(ushort *)(param_2 + 1))
          goto LAB_;
          if ((bVar7 & 2) == 0) goto LAB_;
          uVar16 = *(ushort *)(param_2 + 1) - 1;
          uVar22 = pbVar3[(ulonglong)(uVar16 >> 3) + (ulonglong)uVar22 + 2] >> ((byte)uVar16 & 7) &
                   1;
          bVar6 = true;
LAB_:
          if (uVar22 != 0) {
            uVar12 = 0;
            *puVar1 = 0;
            goto LAB_;
          }
        }
        if ((!bVar6) && ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0)) {
          puVar20 = *(uint **)(param_2 + 2) + 1;
          uVar12 = **(uint **)(param_2 + 2);
          *puVar1 = uVar12;
          goto LAB_;
        }
      }
LAB_:
      if ((int)uVar12 < 0) {
        if (*(int *)(param_3 + 2) == 0) {
          *puVar2 = 0;
          uVar12 = *(uint *)(param_3 + 8);
          uVar26 = (ulonglong)uVar12;
          *(uint *)(param_3 + 10) = uVar12;
          pbVar3 = *(byte **)(param_3 + 4);
          bVar7 = *pbVar3;
          if ((bVar7 & 0x10) != 0) {
            uVar12 = uVar12 + 2 + (*(ushort *)(pbVar3 + uVar26) + 7 >> 3);
            uVar26 = (ulonglong)uVar12;
            *(uint *)(param_3 + 10) = uVar12;
            bVar7 = *pbVar3;
          }
          if ((bVar7 & 0x20) == 0) {
            *(int *)(param_3 + 2) = (int)uVar26;
            param_3[0xe] = 0;
            *(int *)(param_3 + 0xc) = (int)uVar26;
          }
          else {
            puVar23 = (ushort *)(pbVar3 + uVar26);
            uVar9 = *puVar23;
            param_3[0xe] = uVar9;
            if (uVar9 == 0) {
              *(undefined8 *)(puVar19 + -8) = 0x1002fa;
              cVar8 = func_0x(0x11bf110);
              if (cVar8 != '\0') {
                *(undefined8 *)(puVar19 + -8) = 0x100303;
                lVar14 = func_0x();
                if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar19 + -8) = 0x10031d;
                  cVar8 = func_0x(0x11bf110);
                  if (cVar8 == '\0') {
                    *(undefined8 *)(puVar19 + -8) = 0x100339;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar19 + 0x20) = 0;
                    *(undefined8 *)(puVar19 + -8) = 0x10035f;
                    (*_DAT_)(1,0xaaeb1c,0xbcec08,0x80f);
                  }
                }
              }
              uVar15 = *(undefined8 *)(param_3 + 4);
              *(undefined8 *)(puVar19 + -8) = 0x10036d;
              func_0x(uVar15,3);
              uVar9 = param_3[0xe];
              uVar26 = (ulonglong)*(uint *)(param_3 + 10);
            }
            uVar12 = (int)uVar26 + (uVar9 + 1) * 2;
            *(uint *)(param_3 + 0xc) = uVar12;
            if (0x1f9e < uVar12) {
              *(undefined8 *)(puVar19 + -8) = 0x10039d;
              cVar8 = func_0x(0x11bf110);
              if (cVar8 != '\0') {
                *(undefined8 *)(puVar19 + -8) = 0x1003a6;
                lVar14 = func_0x();
                if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar19 + -8) = 0x1003c0;
                  cVar8 = func_0x(0x11bf110);
                  if (cVar8 == '\0') {
                    *(undefined8 *)(puVar19 + -8) = 0x1003dc;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar19 + 0x20) = 0;
                    *(undefined8 *)(puVar19 + -8) = 0x100402;
                    (*_DAT_)(1,0xaaeb1c,0xbcec08,0x816);
                  }
                }
              }
              uVar15 = *(undefined8 *)(param_3 + 4);
              *(undefined8 *)(puVar19 + -8) = 0x100410;
              func_0x(uVar15,4);
              uVar9 = param_3[0xe];
              uVar12 = *(uint *)(param_3 + 0xc);
            }
            uVar26 = (ulonglong)uVar9;
            uVar9 = puVar23[uVar26];
            *(uint *)(param_3 + 2) = uVar9 & 0x7fff;
            if ((uVar9 & 0x7fff) < uVar12) {
              *(undefined8 *)(puVar19 + -8) = 0x10043e;
              cVar8 = func_0x(0x11bf110);
              if (cVar8 != '\0') {
                *(undefined8 *)(puVar19 + -8) = 0x100447;
                lVar14 = func_0x();
                if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar19 + -8) = 0x100461;
                  cVar8 = func_0x(0x11bf110);
                  if (cVar8 == '\0') {
                    *(undefined8 *)(puVar19 + -8) = 0x10047d;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar19 + 0x20) = 0;
                    *(undefined8 *)(puVar19 + -8) = 0x1004a3;
                    (*_DAT_)(1,0xaaeb1c,0xbcec08,0x81d);
                  }
                }
              }
              uVar15 = *(undefined8 *)(param_3 + 4);
              *(undefined8 *)(puVar19 + -8) = 0x1004b1;
              func_0x(uVar15,4);
              uVar12 = *(uint *)(param_3 + 0xc);
              uVar26 = (ulonglong)(ushort)param_3[0xe];
            }
            puVar5 = puVar23;
            if ((short)uVar26 != 0) {
              do {
                uVar22 = puVar5[1] & 0x7fff;
                if ((uVar22 < uVar12) || (*(uint *)(param_3 + 2) < uVar22)) {
                  *(undefined8 *)(puVar19 + -8) = 0x1004ef;
                  cVar8 = func_0x(0x11bf110);
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar19 + -8) = 0x1004f8;
                    lVar14 = func_0x();
                    if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar19 + -8) = 0x100512;
                      cVar8 = func_0x(0x11bf110);
                      if (cVar8 == '\0') {
                        *(undefined8 *)(puVar19 + -8) = 0x10052e;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar19 + 0x20) = 0;
                        *(undefined8 *)(puVar19 + -8) = 0x100554;
                        (*_DAT_)(1,0xaaeb1c,0xbcec08,0x82a);
                      }
                    }
                  }
                  uVar15 = *(undefined8 *)(param_3 + 4);
                  *(undefined8 *)(puVar19 + -8) = 0x100562;
                  func_0x(uVar15,4);
                }
                uVar25 = (int)uVar21 + 1;
                uVar21 = (ulonglong)uVar25;
                uVar26 = (ulonglong)(ushort)param_3[0xe];
                puVar5 = puVar5 + 1;
                uVar12 = uVar22;
              } while ((int)uVar25 < (int)(uint)(ushort)param_3[0xe]);
              psVar24 = *(short **)(&stack0x00000028 + lVar13);
            }
            if ((short)puVar23[(ulonglong)((int)uVar26 - 1) + 1] < 0) {
              lVar14 = *(longlong *)(param_3 + 4);
              do {
                uVar12 = *(ushort *)((ulonglong)*(uint *)(param_3 + 10) + lVar14 + uVar26 * 2) &
                         0x7fff;
                if ((int)uVar26 == 1) {
                  uVar22 = *(uint *)(param_3 + 0xc);
                  uVar25 = uVar22;
LAB_:
                  if ((uVar12 < uVar22) || (*(uint *)(param_3 + 2) < uVar12)) goto LAB_;
                }
                else {
                  uVar22 = *(ushort *)
                            ((ulonglong)*(uint *)(param_3 + 10) + lVar14 + -2 + uVar26 * 2) & 0x7fff
                  ;
                  uVar25 = *(uint *)(param_3 + 0xc);
                  if (uVar25 <= uVar22) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar19 + -8) = 0x1005e7;
                  func_0x(lVar14,7);
                  uVar25 = *(uint *)(param_3 + 0xc);
                }
                if ((uVar22 < uVar25) || (*(uint *)(param_3 + 2) < uVar22)) goto LAB_;
                lVar14 = *(longlong *)(param_3 + 4);
                if (*(ushort *)((ulonglong)uVar22 + lVar14) == 5) {
                  *puVar2 = *puVar2 | 2;
                  param_3[0xe] = param_3[0xe] + -1;
                  uVar26 = (ulonglong)(uVar22 & 0xffff);
                  param_3[0x15] = (short)uVar22;
                  uVar9 = param_3[0x16] & 0xc7ffU;
                  if ((*(ushort *)(uVar26 + 2 + lVar14) >> 0xe & 1) != 0) {
                    uVar9 = *(ushort *)(uVar26 + 2 + lVar14) & 0x3800 | param_3[0x16] & 0xc7ffU;
                  }
                  param_3[0x16] = uVar9;
                  uVar10 = (uVar9 ^ *(ushort *)(uVar26 + 2 + lVar14)) & 0x7ff ^ uVar9;
                  param_3[0x16] = uVar10;
                  uVar21 = *(ulonglong *)(param_3 + 4);
                  uVar17 = (ulonglong)((uVar10 & 0x7ff) * 2) + 4 + uVar21 + (uVar9 >> 0xb & 7) * 2 +
                           uVar26;
                  if (uVar17 < uVar26 + uVar21) {
                    *(undefined8 *)(puVar19 + -8) = 0x1006f0;
                    func_0x(uVar26 + uVar21,0x19);
                    uVar10 = param_3[0x16];
                    uVar26 = (ulonglong)(ushort)param_3[0x15];
                    uVar21 = (ulonglong)*(uint *)(param_3 + 4);
                  }
                  if (uVar12 - uVar22 <
                      (((uVar10 & 0x7ff) * 2 - (int)uVar26) - (int)uVar21) + (int)uVar17) {
                    lVar14 = *(longlong *)(param_3 + 4);
                    *(undefined8 *)(puVar19 + -8) = 0x100728;
                    func_0x(uVar26 + lVar14,0x19);
                    uVar10 = param_3[0x16];
                  }
                  if ((uVar10 & 0x3800) != 0) {
                    puVar23 = (ushort *)
                              (*(longlong *)(param_3 + 4) + (ulonglong)(ushort)param_3[0x15] + 4);
                    iVar11 = 0;
                    if ((uVar10 & 0x3800) != 0) {
                      do {
                        if ((uVar10 & 0x7ff) < (*puVar23 & 0x7ff)) {
                          uVar9 = param_3[0x15];
                          lVar14 = *(longlong *)(param_3 + 4);
                          *(undefined8 *)(puVar19 + -8) = 0x100787;
                          func_0x((ulonglong)uVar9 + lVar14,0x1a);
                          uVar10 = param_3[0x16];
                        }
                        iVar11 = iVar11 + 1;
                        puVar23 = puVar23 + 1;
                      } while (iVar11 < (int)(uVar10 >> 0xb & 7));
                    }
                  }
                  goto LAB_;
                }
                if (*(ushort *)((ulonglong)uVar22 + lVar14) < 0x400) goto LAB_;
                *puVar2 = *puVar2 | 1;
                uVar9 = param_3[0xe] - 1;
                param_3[0xe] = uVar9;
                if (uVar9 == 0) goto LAB_;
                uVar26 = (ulonglong)uVar9;
              } while ((short)puVar23[(ulonglong)(uVar9 - 1) + 1] < 0);
              uVar26 = (ulonglong)*(uint *)(param_3 + 2);
            }
            else {
LAB_:
              uVar26 = (ulonglong)*(uint *)(param_3 + 2);
            }
          }
          if ((**(byte **)(param_3 + 4) & 0x40) == 0) {
            *(undefined4 *)(param_3 + 0x13) = 0;
          }
          else {
            *(int *)(param_3 + 0x13) = (int)uVar26;
            *(int *)(param_3 + 2) = (int)uVar26 + 0xe;
            *(undefined8 *)(puVar19 + -8) = 0x1007d6;
            uVar15 = func_0x(puVar2);
            *(undefined8 *)(puVar19 + -8) = 0x1007e2;
            func_0x(uVar15,&stack0x00000030 + lVar13);
            *(undefined8 *)(puVar19 + -8) = 0x1007eb;
            iVar11 = func_0x(&stack0x00000030 + lVar13);
            *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + iVar11;
            uVar26 = (ulonglong)*(uint *)(param_3 + 2);
          }
          iVar11 = (int)uVar26;
          if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
             (*(ulonglong *)(param_3 + 0xf) < uVar26 + *(longlong *)(param_3 + 4))) {
            *(undefined8 *)(puVar19 + -8) = 0x100823;
            cVar8 = func_0x(0x11bf110);
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar19 + -8) = 0x10082c;
              lVar14 = func_0x();
              if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                *(undefined8 *)(puVar19 + -8) = 0x100846;
                cVar8 = func_0x(0x11bf110);
                if (cVar8 == '\0') {
                  *(undefined8 *)(puVar19 + -8) = 0x100862;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar19 + 0x20) = 0;
                  *(undefined8 *)(puVar19 + -8) = 0x100888;
                  (*_DAT_)(1,0xaaeb1c,0xbcec08,0x886);
                }
              }
            }
            uVar15 = *(undefined8 *)(param_3 + 4);
            *(undefined8 *)(puVar19 + -8) = 0x100896;
            func_0x(uVar15,0x12);
            iVar11 = *(int *)(param_3 + 2);
          }
          if (0x3f3b < iVar11 - 1U) {
            *(undefined8 *)(puVar19 + -8) = 0x1008af;
            cVar8 = func_0x(0x11bf110);
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar19 + -8) = 0x1008b8;
              lVar14 = func_0x();
              if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                *(undefined8 *)(puVar19 + -8) = 0x1008d2;
                cVar8 = func_0x(0x11bf110);
                if (cVar8 == '\0') {
                  *(undefined8 *)(puVar19 + -8) = 0x1008ee;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar19 + 0x20) = 0;
                  *(undefined8 *)(puVar19 + -8) = 0x100914;
                  (*_DAT_)(1,0xaaeb1c,0xbcec08,0x88b);
                }
              }
            }
            uVar15 = *(undefined8 *)(param_3 + 4);
            *(undefined8 *)(puVar19 + -8) = 0x100920;
            func_0x(uVar15,5);
          }
        }
LAB_:
        sVar18 = -*(short *)param_2;
        if ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0) {
          bVar7 = **(byte **)(param_3 + 4);
          if ((bVar7 & 0x10) == 0) {
            if ((1 << (bVar7 & 0xe) & 0x1105U) != 0) {
LAB_:
              puVar20 = *(uint **)(param_2 + 2) + 1;
              uVar12 = **(uint **)(param_2 + 2);
              *puVar1 = uVar12;
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(param_3 + 8) <= (int)*param_2) ||
                  (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) <
                   *(ushort *)(param_2 + 1))) goto LAB_;
        }
        lVar14 = (longlong)sVar18;
        puVar20 = *(uint **)(param_3 + 4);
        if ((uint)(ushort)param_3[0xe] < (uint)(int)sVar18) {
          uVar12 = 0;
LAB_:
          *puVar1 = uVar12;
        }
        else {
          uVar12 = *(uint *)(param_3 + 10);
          if (sVar18 == 1) {
            uVar22 = *(uint *)(param_3 + 0xc);
            uVar12 = *(ushort *)((longlong)puVar20 + lVar14 * 2 + (ulonglong)uVar12) & 0x7fff;
LAB_:
            if ((uVar12 < uVar22) || (*(uint *)(param_3 + 2) < uVar12)) goto LAB_;
          }
          else {
            uVar22 = *(ushort *)((longlong)puVar20 + lVar14 * 2 + ((ulonglong)uVar12 - 2)) & 0x7fff;
            uVar12 = *(ushort *)((longlong)puVar20 + lVar14 * 2 + (ulonglong)uVar12) & 0x7fff;
            puVar20 = *(uint **)(param_3 + 4);
            if (*(uint *)(param_3 + 0xc) <= uVar22) goto LAB_;
LAB_:
            *(undefined8 *)(puVar19 + -8) = 0x1009e4;
            func_0x(puVar20,7);
            puVar20 = *(uint **)(param_3 + 4);
          }
          puVar20 = (uint *)((longlong)puVar20 + (ulonglong)uVar22);
          uVar12 = uVar12 - uVar22;
          *puVar1 = uVar12;
        }
      }
      else {
        uVar9 = *(ushort *)((longlong)param_2 + 6);
        if ((uVar9 & 8) == 0) {
          if ((uVar9 & 0x10) != 0) {
            bVar7 = **(byte **)(param_3 + 4);
            if ((bVar7 & 0x10) == 0) {
              if ((1 << (bVar7 & 0xe) & 0x1105U) != 0) {
LAB_:
                puVar20 = *(uint **)(param_2 + 2) + 1;
                uVar12 = **(uint **)(param_2 + 2);
                if ((uVar25 != 0) && (uVar12 != uVar25)) {
                  *(undefined8 *)(puVar19 + 0x20) = 0;
                  *(undefined8 *)(puVar19 + -8) = 0x100258;
                  (*_DAT_)(1,0xc5cf60,0xc5b8c8,0x381);
                  *puVar1 = uVar12;
                  goto LAB_;
                }
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(param_3 + 8) <= (int)uVar12) ||
                    (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) <
                     *(ushort *)(param_2 + 1))) goto LAB_;
          }
          puVar20 = (uint *)((longlong)(int)uVar12 + *(longlong *)(param_3 + 4));
          *puVar1 = uVar25;
          uVar12 = uVar25;
        }
        else {
          puVar20 = (uint *)0x8337b0;
          if ((*(byte *)((longlong)(int)uVar12 + *(longlong *)(param_3 + 4)) &
              (byte)(1 << ((byte)uVar9 & 7))) == 0) {
            puVar20 = (uint *)0x8337b1;
          }
          uVar12 = 1;
          *puVar1 = 1;
        }
      }
    }
  }
  else {
    *(undefined4 *)((longlong)auStackX_1c + lVar13) = 0;
    *(longlong *)(puVar19 + 0x20) = (longlong)auStackX_1c + lVar13;
    *(undefined8 *)(puVar19 + -8) = 0x100a6f;
    puVar20 = (uint *)func_0x(puVar2,param_2);
    if ((((*param_3 != 0) && (plVar4 = *(longlong **)(param_3 + 8), plVar4 != (longlong *)0x0)) &&
        (*plVar4 != 0)) &&
       (((*(byte *)((longlong)param_2 + 6) & 8) == 0 &&
        ((*(uint *)((longlong)auStackX_1c + lVar13) & 1) == 0)))) {
      if ((puVar20 == (uint *)0x0) || (puVar20 == (uint *)0x8337b0)) {
        puVar20 = (uint *)0x0;
        uVar12 = 0;
        *puVar1 = 0;
        goto LAB_;
      }
      *(uint *)(puVar19 + 0x38) = *(uint *)((longlong)auStackX_1c + lVar13);
      *(uint **)(puVar19 + 0x30) = puVar1;
      *(uint *)(puVar19 + 0x28) = uVar12;
      *(ulonglong *)(puVar19 + 0x20) = uVar26;
      uVar12 = *puVar1;
      *(undefined8 *)(puVar19 + -8) = 0x100ac9;
      puVar20 = (uint *)func_0x(plVar4,param_2,puVar20,uVar12);
    }
LAB_:
    uVar12 = *puVar1;
  }
LAB_:
  uVar9 = *(ushort *)(param_2 + 0x14);
  if (uVar9 < 0x11) {
    if ((puVar20 == (uint *)0x0) || ((uVar12 == 0x10 && (*(short *)puVar20 == 0))))
    goto LAB_;
  }
  else if (uVar12 <= uVar9) goto LAB_;
  uVar22 = (uint)uVar9;
  if (uVar9 < uVar12) {
    uVar22 = uVar12;
  }
  uVar26 = (ulonglong)uVar22;
  *(undefined8 *)(puVar19 + -8) = 0x100b0a;
  iVar11 = func_0x(psVar24,param_2);
  if (iVar11 == 0) {
    *(undefined4 *)((longlong)auStackX_1c + lVar13 + 4) = 0x80200;
    uVar26 = (ulonglong)uVar22;
    if (uVar22 < 0x18) {
      uVar26 = 0x18;
    }
  }
  uVar12 = *param_2;
  *(undefined4 *)(&stack0x000000d0 + lVar13) = 0;
  *(undefined2 *)(&stack0x000000d4 + lVar13) = 0;
  uVar22 = *puVar1;
  *(undefined4 *)(puVar19 + 0x40) = 0;
  *(ulonglong *)(puVar19 + 0x38) = uVar26;
  *(undefined4 *)(puVar19 + 0x30) = 2;
  *(undefined4 *)(puVar19 + 0x28) = *(undefined4 *)((longlong)auStackX_1c + lVar13 + 4);
  *(uint *)(puVar19 + 0x20) = uVar12;
  uVar15 = *(undefined8 *)(&stack0x00000038 + lVar13);
  *(undefined8 *)(puVar19 + -8) = 0x100b66;
  func_0x(&stack0x00000048 + lVar13,uVar15,puVar20,uVar22);
  uVar9 = *(ushort *)((longlong)param_2 + 0x3a);
  uVar26 = (ulonglong)uVar9;
  if (uVar9 == 0x10) {
    *(uint *)(&stack0x00000084 + lVar13) = *(uint *)(&stack0x00000084 + lVar13) & 0xfffff7ff;
    *(undefined8 *)(&stack0x00000140 + lVar13) = 0;
    *(undefined4 *)(&stack0x00000110 + lVar13) = 1;
    *(undefined4 *)(&stack0x00000114 + lVar13) = 0x1f68;
    *(undefined4 *)(&stack0x00000118 + lVar13) = 0x1f5;
LAB_:
    *(undefined4 *)(&stack0x00000120 + lVar13) = 0x40;
    *(undefined4 *)(&stack0x0000011c + lVar13) = 5;
  }
  else {
    *(ulonglong *)(&stack0x00000140 + lVar13) = uVar26;
    bVar7 = *(byte *)(*(longlong *)(&stack0x00000058 + lVar13) + 0x79);
    *(undefined4 *)(&stack0x00000110 + lVar13) = 1;
    *(undefined4 *)(&stack0x00000114 + lVar13) = 0x1f68;
    *(undefined4 *)(&stack0x00000118 + lVar13) = 0x1f5;
    if (uVar9 == 0) goto LAB_;
    if ((bVar7 & 8) == 0) {
      uVar22 = (uint)((uVar26 - 0xc) / 0xc);
      uVar12 = 5;
      if (uVar22 < 5) {
        uVar12 = uVar22;
      }
      *(uint *)(&stack0x0000011c + lVar13) = uVar12;
      *(uint *)(&stack0x00000120 + lVar13) = (uint)uVar9;
    }
    else {
      uVar22 = (uint)((uVar26 - 0xc) / 0xc);
      uVar12 = 0x1f5;
      if (uVar22 < 0x1f5) {
        uVar12 = uVar22;
      }
      *(uint *)(&stack0x0000011c + lVar13) = uVar12;
      *(undefined4 *)(&stack0x00000120 + lVar13) = *(undefined4 *)(&stack0x00000140 + lVar13);
    }
  }
  *(undefined8 *)(puVar19 + -8) = 0x100bb9;
  func_0x(&stack0x00000048 + lVar13);
  if ((((*(uint *)(&stack0x00000084 + lVar13) & 0x800) == 0) ||
      (*(int *)(&stack0x00000068 + lVar13) != 0)) || (*(short *)(&stack0x0000006c + lVar13) != 0)) {
    uVar12 = 0x10;
  }
  else {
    lVar14 = *(longlong *)(&stack0x00000098 + lVar13);
    if ((*(byte *)(lVar14 + 0xc) & 0xf) == 0) {
      uVar12 = (uint)*(ushort *)(lVar14 + 0xe);
    }
    else {
      uVar12 = (*(ushort *)(lVar14 + 0x10) + 1) * 0xc;
    }
  }
  if (&stack0x00004086 + lVar13 <= &stack0x000020e8 + (ulonglong)uVar12 + lVar13) {
    *(undefined8 *)(puVar19 + 0x20) = 0;
    *(undefined8 *)(puVar19 + -8) = 0x100cdc;
    (*_DAT_)(1,0xc8b690,0xc36710,0x1f7a);
  }
  *(undefined8 *)(puVar19 + -8) = 0x100cee;
  func_0x(&stack0x00000048 + lVar13,uVar12,&stack0x000020e8 + lVar13);
  *(undefined8 *)(puVar19 + -8) = 0x100cf7;
  func_0x(&stack0x00000048 + lVar13);
  *(undefined8 *)(puVar19 + -8) = 0x100d0c;
  func_0x(psVar24,param_2,&stack0x000020e8 + lVar13,uVar12);
  if (*psVar24 == 0) {
    *(undefined8 *)(puVar19 + -8) = 0x100d25;
    func_0x(puVar2,param_2,1);
  }
  else {
    if (*(int *)(param_3 + 2) == 0) {
      *(undefined8 *)(puVar19 + -8) = 0x100d35;
      func_0x(puVar2);
    }
    if (*(ushort *)(param_2 + 1) <= *puVar2) {
      uVar9 = param_3[0xf];
      lVar14 = *(longlong *)(param_3 + 4);
      *(undefined8 *)(puVar19 + -8) = 0x100d52;
      uVar12 = func_0x(puVar2);
      puVar2 = (ushort *)(lVar14 + (ulonglong)uVar9 + 3 + (ulonglong)uVar12 * 2);
      *puVar2 = *puVar2 | 0x8000;
    }
  }
LAB_:
  *(undefined8 *)(puVar19 + -8) = 0x100d6b;
  func_0x(&stack0x00000048 + lVar13);
  uVar26 = *(ulonglong *)(&stack0x00004088 + lVar13);
  *(undefined8 *)(puVar19 + -8) = 0x100d7a;
  func_0x(uVar26 ^ (ulonglong)puVar1);
  return;
}

