
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2)

{
  ushort *puVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  longlong *plVar4;
  ushort *puVar5;
  byte bVar6;
  char cVar7;
  ushort uVar8;
  ushort uVar9;
  int iVar10;
  longlong lVar11;
  longlong lVar12;
  undefined8 uVar13;
  short sVar14;
  uint uVar15;
  ulonglong uVar16;
  undefined8 unaff_RBX;
  int *piVar17;
  uint uVar18;
  int *piVar19;
  ulonglong uVar20;
  byte *pbVar21;
  ulonglong uVar22;
  uint uVar23;
  undefined8 unaff_R12;
  undefined8 unaff_R13;
  ushort *puVar24;
  int iVar25;
  undefined8 unaff_R15;
  undefined4 auStackX_8 [2];
  longlong lStackX_10;
  uint auStackX_18 [2];
  int aiStackX_20 [2];
  ulonglong uStack_38;
  undefined8 uStack_28;
  
  uStack_28 = 0x100018;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  uStack_38 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffe0 + lVar11);
  uVar2 = *(undefined2 *)(param_1 + 0x110);
  sVar14 = *(short *)(param_1 + 0x112);
  *(longlong *)(&stack0x00000048 + lVar11) = param_1;
  piVar17 = (int *)0x0;
  *(undefined8 *)(&stack0x00002030 + lVar11) = unaff_RBX;
  *(undefined4 *)((longlong)aiStackX_20 + lVar11 + -0x20) = 0;
  *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100063;
  func_0x(&stack0x00000028 + lVar11,(int)sVar14,uVar2,0);
  puVar1 = (ushort *)(param_2 + 1);
  if (*param_2 != 0) {
    *(undefined4 *)(&stack0x00000038 + lVar11) = 0;
    *(undefined **)((longlong)aiStackX_20 + lVar11 + -0x20) = &stack0x00000038 + lVar11;
    *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100a3f;
    piVar19 = (int *)func_0x(puVar1,&stack0x00000028 + lVar11);
    if ((((*param_2 != 0) && (plVar4 = *(longlong **)(param_2 + 8), plVar4 != (longlong *)0x0)) &&
        (*plVar4 != 0)) &&
       ((((&stack0x0000002e)[lVar11] & 8) == 0 && ((*(uint *)(&stack0x00000038 + lVar11) & 1) == 0))
       )) {
      if ((piVar19 == (int *)0x0) || (piVar19 == (int *)0xa66030)) {
        *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        piVar19 = piVar17;
      }
      else {
        *(uint *)((longlong)auStackX_18 + lVar11) = *(uint *)(&stack0x00000038 + lVar11);
        *(longlong *)((longlong)&lStackX_10 + lVar11) = (longlong)aiStackX_20 + lVar11;
        *(undefined4 *)((longlong)auStackX_8 + lVar11) = 0x1f9e;
        *(undefined **)((longlong)aiStackX_20 + lVar11 + -0x20) = &stack0x00000050 + lVar11;
        *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100aa6;
        piVar19 = (int *)func_0x
                                   (plVar4,&stack0x00000028 + lVar11,piVar19,
                                    *(undefined4 *)((longlong)aiStackX_20 + lVar11));
      }
    }
    goto LAB_;
  }
  if ((*(uint *)(&stack0x00000028 + lVar11) & 0xc0000000) == 0x80000000) {
    *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1009f0;
    iVar10 = func_0x(puVar1);
    if (iVar10 == 0) {
      *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
      piVar19 = (int *)0x0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100a0c;
      piVar19 = (int *)func_0x(param_2 + 0x15,&stack0x00000028 + lVar11,
                                       (longlong)aiStackX_20 + lVar11,&stack0x0000003c + lVar11);
    }
    goto LAB_;
  }
  pbVar21 = *(byte **)(param_2 + 4);
  *(undefined8 *)(&stack0x00002000 + lVar11) = unaff_R15;
  iVar25 = 1;
  bVar6 = *pbVar21;
  iVar10 = 0;
  if ((bVar6 & 0x10) == 0) {
    if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
      uVar8 = ~(*(ushort *)(&stack0x0000002e + lVar11) >> 4);
      iVar25 = iVar10;
      goto LAB_;
    }
LAB_:
    if (-1 < *(int *)(&stack0x00000028 + lVar11)) {
      if ((*(ushort *)(&stack0x0000002e + lVar11) & 8) != 0) {
        piVar19 = (int *)0xa66030;
        param_1 = *(longlong *)(&stack0x00000048 + lVar11);
        bVar6 = pbVar21[*(int *)(&stack0x00000028 + lVar11)];
        *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 1;
        if ((bVar6 & (byte)(1 << ((&stack0x0000002e)[lVar11] & 7))) == 0) {
          piVar19 = (int *)0xa66031;
        }
        goto LAB_;
      }
      if ((*(ushort *)(&stack0x0000002e + lVar11) & 0x10) != 0) {
        if ((bVar6 & 0x10) == 0) {
          if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
            iVar10 = **(int **)(&stack0x00000030 + lVar11);
            piVar17 = *(int **)(&stack0x00000030 + lVar11) + 1;
            if (iVar10 != 0x1f9e) {
              *(undefined8 *)((longlong)aiStackX_20 + lVar11 + -0x20) = 0;
              *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100215;
              (*_DAT_)(1,0xe8f7e0,0xe8e148,0x381);
              *(int *)((longlong)aiStackX_20 + lVar11) = iVar10;
              param_1 = *(longlong *)(&stack0x00000048 + lVar11);
              piVar19 = piVar17;
              goto LAB_;
            }
            goto LAB_;
          }
        }
        else if (((int)*(uint *)(param_2 + 8) <= *(int *)(&stack0x00000028 + lVar11)) ||
                (*(ushort *)(pbVar21 + *(uint *)(param_2 + 8)) <
                 *(ushort *)(&stack0x0000002c + lVar11))) goto LAB_;
      }
      *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0x1f9e;
      param_1 = *(longlong *)(&stack0x00000048 + lVar11);
      piVar19 = (int *)(pbVar21 + *(int *)(&stack0x00000028 + lVar11));
      goto LAB_;
    }
    if (*(int *)(param_2 + 2) == 0) {
      uVar15 = *(uint *)(param_2 + 8);
      uVar16 = (ulonglong)uVar15;
      *(uint *)(param_2 + 10) = uVar15;
      *puVar1 = 0;
      bVar6 = *pbVar21;
      if ((bVar6 & 0x10) != 0) {
        uVar15 = uVar15 + 2 + (*(ushort *)(pbVar21 + uVar16) + 7 >> 3);
        uVar16 = (ulonglong)uVar15;
        *(uint *)(param_2 + 10) = uVar15;
        bVar6 = *pbVar21;
      }
      *(undefined8 *)(&stack0x00002040 + lVar11) = unaff_R12;
      *(undefined8 *)(&stack0x00002048 + lVar11) = unaff_R13;
      if ((bVar6 & 0x20) == 0) {
        *(int *)(param_2 + 2) = (int)uVar16;
        param_2[0xe] = 0;
        *(int *)(param_2 + 0xc) = (int)uVar16;
      }
      else {
        puVar24 = (ushort *)(pbVar21 + uVar16);
        uVar8 = *puVar24;
        param_2[0xe] = uVar8;
        if (uVar8 == 0) {
          *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1002de;
          cVar7 = func_0x(0x13f1990);
          if (cVar7 != '\0') {
            *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1002e7;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100301;
              cVar7 = func_0x(0x13f1990);
              if (cVar7 == '\0') {
                *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x10031d;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)((longlong)aiStackX_20 + lVar11 + -0x20) = 0;
                *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100341;
                (*_DAT_)(1,0xce139c,0xe01488,0x80f);
              }
            }
          }
          uVar13 = *(undefined8 *)(param_2 + 4);
          *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x10034f;
          func_0x(uVar13,3);
          uVar16 = (ulonglong)*(uint *)(param_2 + 10);
          uVar8 = param_2[0xe];
        }
        uVar15 = (int)uVar16 + (uVar8 + 1) * 2;
        *(uint *)(param_2 + 0xc) = uVar15;
        if (0x1f9e < uVar15) {
          *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x10037f;
          cVar7 = func_0x(0x13f1990);
          if (cVar7 != '\0') {
            *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100388;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1003a2;
              cVar7 = func_0x(0x13f1990);
              if (cVar7 == '\0') {
                *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1003be;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)((longlong)aiStackX_20 + lVar11 + -0x20) = 0;
                *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1003e2;
                (*_DAT_)(1,0xce139c,0xe01488,0x816);
              }
            }
          }
          uVar13 = *(undefined8 *)(param_2 + 4);
          *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1003f0;
          func_0x(uVar13,4);
          uVar8 = param_2[0xe];
          uVar15 = *(uint *)(param_2 + 0xc);
        }
        uVar16 = (ulonglong)uVar8;
        uVar8 = puVar24[uVar16];
        *(uint *)(param_2 + 2) = uVar8 & 0x7fff;
        if ((uVar8 & 0x7fff) < uVar15) {
          *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100421;
          cVar7 = func_0x(0x13f1990);
          if (cVar7 != '\0') {
            *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x10042a;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100444;
              cVar7 = func_0x(0x13f1990);
              if (cVar7 == '\0') {
                *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100460;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)((longlong)aiStackX_20 + lVar11 + -0x20) = 0;
                *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100484;
                (*_DAT_)(1,0xce139c,0xe01488,0x81d);
              }
            }
          }
          uVar13 = *(undefined8 *)(param_2 + 4);
          *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100492;
          func_0x(uVar13,4);
          uVar15 = *(uint *)(param_2 + 0xc);
          uVar16 = (ulonglong)(ushort)param_2[0xe];
        }
        piVar19 = piVar17;
        puVar5 = puVar24;
        if ((short)uVar16 != 0) {
          do {
            uVar18 = puVar5[1] & 0x7fff;
            if ((uVar18 < uVar15) || (*(uint *)(param_2 + 2) < uVar18)) {
              *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1004cf;
              cVar7 = func_0x(0x13f1990);
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1004d8;
                lVar12 = func_0x();
                if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1004f2;
                  cVar7 = func_0x(0x13f1990);
                  if (cVar7 == '\0') {
                    *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x10050e;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)((longlong)aiStackX_20 + lVar11 + -0x20) = 0;
                    *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100532;
                    (*_DAT_)(1,0xce139c,0xe01488,0x82a);
                  }
                }
              }
              uVar13 = *(undefined8 *)(param_2 + 4);
              *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100540;
              func_0x(uVar13,4);
            }
            uVar16 = (ulonglong)(ushort)param_2[0xe];
            uVar23 = (int)piVar19 + 1;
            piVar19 = (int *)(ulonglong)uVar23;
            puVar5 = puVar5 + 1;
            uVar15 = uVar18;
          } while ((int)uVar23 < (int)(uint)(ushort)param_2[0xe]);
        }
        if ((short)puVar24[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
          pbVar21 = *(byte **)(param_2 + 4);
          do {
            uVar15 = *(ushort *)(pbVar21 + uVar16 * 2 + (ulonglong)*(uint *)(param_2 + 10)) & 0x7fff
            ;
            if ((int)uVar16 == 1) {
              uVar18 = *(uint *)(param_2 + 0xc);
              uVar23 = uVar18;
LAB_:
              if ((uVar15 < uVar18) || (*(uint *)(param_2 + 2) < uVar15)) goto LAB_;
            }
            else {
              uVar23 = *(uint *)(param_2 + 0xc);
              uVar18 = *(ushort *)(pbVar21 + uVar16 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2))
                       & 0x7fff;
              if (uVar23 <= uVar18) goto LAB_;
LAB_:
              *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1005c8;
              func_0x(pbVar21,7);
              uVar23 = *(uint *)(param_2 + 0xc);
            }
            if ((uVar18 < uVar23) || (*(uint *)(param_2 + 2) < uVar18)) goto LAB_;
            pbVar21 = *(byte **)(param_2 + 4);
            if (*(ushort *)(pbVar21 + uVar18) == 5) {
              *puVar1 = *puVar1 | 2;
              param_2[0xe] = param_2[0xe] + -1;
              uVar22 = (ulonglong)(uVar18 & 0xffff);
              param_2[0x15] = (short)uVar18;
              uVar16 = *(ulonglong *)(param_2 + 4);
              uVar8 = param_2[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar22 + 2 + uVar16) >> 0xe & 1) != 0) {
                uVar8 = *(ushort *)(uVar22 + 2 + uVar16) & 0x3800 | param_2[0x16] & 0xc7ffU;
              }
              param_2[0x16] = uVar8;
              uVar9 = (uVar8 ^ *(ushort *)(uVar22 + 2 + uVar16)) & 0x7ff ^ uVar8;
              param_2[0x16] = uVar9;
              uVar20 = (ulonglong)((uVar9 & 0x7ff) * 2) + 4 + uVar16 + (uVar8 >> 0xb & 7) * 2 +
                       uVar22;
              if (uVar20 < uVar22 + uVar16) {
                *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1006cd;
                func_0x(uVar22 + uVar16,0x19);
                uVar9 = param_2[0x16];
                uVar22 = (ulonglong)(ushort)param_2[0x15];
                uVar16 = (ulonglong)*(uint *)(param_2 + 4);
              }
              if (uVar15 - uVar18 <
                  (((uVar9 & 0x7ff) * 2 - (int)uVar22) - (int)uVar16) + (int)uVar20) {
                lVar12 = *(longlong *)(param_2 + 4);
                *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100705;
                func_0x(uVar22 + lVar12,0x19);
                uVar9 = param_2[0x16];
              }
              if (((uVar9 & 0x3800) != 0) &&
                 (puVar24 = (ushort *)
                            (*(longlong *)(param_2 + 4) + 4 + (ulonglong)(ushort)param_2[0x15]),
                 (uVar9 & 0x3800) != 0)) {
                do {
                  if ((uVar9 & 0x7ff) < (*puVar24 & 0x7ff)) {
                    uVar8 = param_2[0x15];
                    lVar12 = *(longlong *)(param_2 + 4);
                    *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100757;
                    func_0x((ulonglong)uVar8 + lVar12,0x1a);
                    uVar9 = param_2[0x16];
                  }
                  uVar15 = (int)piVar17 + 1;
                  piVar17 = (int *)(ulonglong)uVar15;
                  puVar24 = puVar24 + 1;
                } while ((int)uVar15 < (int)(uVar9 >> 0xb & 7));
              }
              goto LAB_;
            }
            if (*(ushort *)(pbVar21 + uVar18) < 0x400) goto LAB_;
            *puVar1 = *puVar1 | 1;
            uVar8 = param_2[0xe] - 1;
            param_2[0xe] = uVar8;
            if (uVar8 == 0) goto LAB_;
            uVar16 = (ulonglong)uVar8;
          } while ((short)puVar24[(ulonglong)(uVar8 - 1) + 1] < 0);
          uVar16 = (ulonglong)*(uint *)(param_2 + 2);
        }
        else {
LAB_:
          pbVar21 = *(byte **)(param_2 + 4);
          uVar16 = (ulonglong)*(uint *)(param_2 + 2);
        }
      }
      if ((*pbVar21 & 0x40) == 0) {
        *(undefined4 *)(param_2 + 0x13) = 0;
      }
      else {
        *(int *)(param_2 + 0x13) = (int)uVar16;
        *(int *)(param_2 + 2) = (int)uVar16 + 0xe;
        *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x10079d;
        uVar13 = func_0x(puVar1);
        *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1007aa;
        func_0x(uVar13,&stack0x00000040 + lVar11);
        *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1007b4;
        iVar25 = func_0x(&stack0x00000040 + lVar11);
        *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar25;
        uVar16 = (ulonglong)*(uint *)(param_2 + 2);
      }
      iVar25 = (int)uVar16;
      if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
         (*(ulonglong *)(param_2 + 0xf) < uVar16 + *(longlong *)(param_2 + 4))) {
        *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1007ea;
        cVar7 = func_0x(0x13f1990);
        if (cVar7 != '\0') {
          *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1007f3;
          lVar12 = func_0x();
          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x10080d;
            cVar7 = func_0x(0x13f1990);
            if (cVar7 == '\0') {
              *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100829;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)((longlong)aiStackX_20 + lVar11 + -0x20) = 0;
              *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x10084d;
              (*_DAT_)(1,0xce139c,0xe01488,0x886);
            }
          }
        }
        uVar13 = *(undefined8 *)(param_2 + 4);
        *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x10085b;
        func_0x(uVar13,0x12);
        iVar25 = *(int *)(param_2 + 2);
      }
      if (0x3f3b < iVar25 - 1U) {
        *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100874;
        cVar7 = func_0x(0x13f1990);
        if (cVar7 != '\0') {
          *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x10087d;
          lVar12 = func_0x();
          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100897;
            cVar7 = func_0x(0x13f1990);
            if (cVar7 == '\0') {
              *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1008b3;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)((longlong)aiStackX_20 + lVar11 + -0x20) = 0;
              *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1008d7;
              (*_DAT_)(1,0xce139c,0xe01488,0x88b);
            }
          }
        }
        uVar13 = *(undefined8 *)(param_2 + 4);
        *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1008e5;
        func_0x(uVar13,5);
      }
    }
LAB_:
    sVar14 = -*(short *)(&stack0x00000028 + lVar11);
    if (((&stack0x0000002e)[lVar11] & 0x10) != 0) {
      bVar6 = **(byte **)(param_2 + 4);
      if ((bVar6 & 0x10) == 0) {
        if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) =
               **(undefined4 **)(&stack0x00000030 + lVar11);
          param_1 = *(longlong *)(&stack0x00000048 + lVar11);
          piVar19 = *(undefined4 **)(&stack0x00000030 + lVar11) + 1;
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(param_2 + 8) <= *(int *)(&stack0x00000028 + lVar11)) ||
              (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
               *(ushort *)(&stack0x0000002c + lVar11))) goto LAB_;
    }
    piVar17 = *(int **)(param_2 + 4);
    lVar12 = (longlong)sVar14;
    if ((uint)(int)sVar14 <= (uint)(ushort)param_2[0xe]) {
      uVar15 = *(uint *)(param_2 + 10);
      if (sVar14 == 1) {
        uVar18 = *(uint *)(param_2 + 0xc);
        uVar15 = *(ushort *)((longlong)piVar17 + lVar12 * 2 + (ulonglong)uVar15) & 0x7fff;
LAB_:
        if ((uVar15 < uVar18) || (*(uint *)(param_2 + 2) < uVar15)) goto LAB_;
      }
      else {
        puVar1 = (ushort *)((longlong)piVar17 + lVar12 * 2 + (ulonglong)uVar15);
        uVar18 = *(ushort *)((longlong)piVar17 + lVar12 * 2 + ((ulonglong)uVar15 - 2)) & 0x7fff;
        piVar17 = *(int **)(param_2 + 4);
        uVar15 = *puVar1 & 0x7fff;
        if (*(uint *)(param_2 + 0xc) <= uVar18) goto LAB_;
LAB_:
        *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x1009c4;
        func_0x(piVar17,7);
        piVar17 = *(int **)(param_2 + 4);
      }
      *(uint *)((longlong)aiStackX_20 + lVar11) = uVar15 - uVar18;
      param_1 = *(longlong *)(&stack0x00000048 + lVar11);
      piVar19 = (int *)((longlong)piVar17 + (ulonglong)uVar18);
      goto LAB_;
    }
  }
  else {
    uVar15 = *(uint *)(param_2 + 8);
    if (*(int *)(&stack0x00000028 + lVar11) < (int)uVar15) {
      if ((uint)*(ushort *)(pbVar21 + uVar15) < (uint)*(ushort *)(&stack0x0000002c + lVar11)) {
        uVar8 = ~(*(ushort *)(&stack0x0000002e + lVar11) >> 4);
        iVar25 = iVar10;
      }
      else {
        uVar18 = *(ushort *)(&stack0x0000002c + lVar11) - 1;
        uVar8 = (ushort)(pbVar21[(ulonglong)uVar15 + (ulonglong)(uVar18 >> 3) + 2] >>
                        ((byte)uVar18 & 7));
      }
    }
    else {
      uVar8 = ~(*(ushort *)(&stack0x0000002e + lVar11) >> 4);
      iVar25 = iVar10;
    }
LAB_:
    if ((uVar8 & 1) == 0) {
      if ((iVar25 == 0) && (((&stack0x0000002e)[lVar11] & 0x10) != 0)) {
        *(undefined4 *)((longlong)aiStackX_20 + lVar11) =
             **(undefined4 **)(&stack0x00000030 + lVar11);
        param_1 = *(longlong *)(&stack0x00000048 + lVar11);
        piVar19 = *(undefined4 **)(&stack0x00000030 + lVar11) + 1;
        goto LAB_;
      }
      goto LAB_;
    }
  }
LAB_:
  *(int *)((longlong)aiStackX_20 + lVar11) = iVar10;
  param_1 = *(longlong *)(&stack0x00000048 + lVar11);
  piVar19 = piVar17;
LAB_:
  if (piVar19 != (int *)0x0) {
    uVar3 = *(undefined4 *)(param_1 + 0x114);
    *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100ada;
    func_0x(piVar19,param_1 + 0x118,uVar3);
  }
  *(undefined8 *)((longlong)&uStack_28 + lVar11) = 0x100af2;
  func_0x(uStack_38 ^ (ulonglong)(&stack0xffffffffffffffe0 + lVar11));
  return;
}

