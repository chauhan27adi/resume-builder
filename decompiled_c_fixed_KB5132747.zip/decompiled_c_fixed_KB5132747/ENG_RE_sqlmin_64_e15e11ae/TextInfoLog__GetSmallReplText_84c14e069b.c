
longlong FUN_(longlong param_1,longlong param_2,longlong param_3,undefined4 *param_4)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  code *UNRECOVERED_JUMPTABLE;
  undefined8 uVar4;
  undefined auStackX_10 [24];
  undefined auStack_98 [16];
  uint uStack_88;
  short sStack_84;
  ushort uStack_82;
  undefined8 uStack_80;
  undefined2 uStack_78;
  undefined4 uStack_74;
  byte *pbStack_70;
  undefined8 uStack_68;
  undefined8 uStack_5a;
  undefined2 uStack_52;
  undefined2 uStack_50;
  undefined6 uStack_4e;
  
  lVar3 = 0;
  uStack_88 = *(uint *)(param_1 + 0x30);
  uStack_82 = uStack_82 & 0xffe0;
  uStack_74 = 0;
  uStack_5a = 0;
  uStack_50 = 0;
  uStack_4e = 0;
  uStack_68 = 0;
  uStack_80 = 0;
  if (param_2 == 0) {
    if ((int)uStack_88 < 0) {
      if ((uStack_88 & 0xc0000000) == 0x80000000) {
        sStack_84 = 0;
      }
      else {
        sStack_84 = -(short)uStack_88;
      }
    }
    else {
      uStack_88 = uStack_88 | 0xa0000000;
      sStack_84 = 0;
    }
    pbStack_70 = (byte *)func_0x(param_3 + 0x3e,0,auStack_98);
    if ((*pbStack_70 & 1) != 0) {
      uStack_78 = 1;
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_70 & 0x1c) + 0x100c30) *
                              4 + 0x100c20) - 0x125ab50);
                    /* WARNING: Could not emulate address calculation at 0x001000e7 */
                    /* WARNING: Treating indirect jump as call */
      lVar3 = (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
      return lVar3;
    }
    uStack_78 = 0;
    uStack_52 = 0;
    uStack_50 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100237 */
                    /* WARNING: Treating indirect jump as call */
    lVar3 = (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_70 & 0xe) * 4 + 0x100c50) -
                      0x125ab50))
                      ((longlong)(int)(*pbStack_70 & 0xe),0xfffffffffeda54b0,pbStack_70,pbStack_70);
    return lVar3;
  }
  cVar1 = *(char *)(param_2 + 0x16);
  if (cVar1 == '\x04') {
    uVar4 = 1;
LAB_:
    lVar3 = func_0x(param_2 + 0x3e,uVar4,auStackX_10);
  }
  else if ((cVar1 == '\x02') || (cVar1 == '\x03')) {
    uVar4 = 0;
    goto LAB_;
  }
  if ((*(char *)(param_2 + 0x16) - 2U & 0xfd) == 0) {
    uVar2 = *(undefined4 *)(param_1 + 0x50);
  }
  else {
    if (*(char *)(param_2 + 0x16) != '\x03') goto LAB_;
    uVar2 = *(undefined4 *)(param_1 + 0x48);
  }
  *param_4 = uVar2;
LAB_:
  if ((*(byte *)(lVar3 + 0xc) & 0xf) == 8) {
    lVar3 = 0;
  }
  else {
    lVar3 = *(longlong *)(param_1 + 0x40) + 0x14 + lVar3;
  }
  return lVar3;
}

