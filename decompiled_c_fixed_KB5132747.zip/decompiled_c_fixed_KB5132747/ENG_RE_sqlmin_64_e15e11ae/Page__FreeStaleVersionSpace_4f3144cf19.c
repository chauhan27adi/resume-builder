
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,longlong param_3,longlong param_4,uint param_5,
                 longlong *param_6,longlong *param_7)

{
  byte *pbVar1;
  byte bVar2;
  ushort *puVar3;
  char cVar4;
  short sVar5;
  uint uVar6;
  longlong lVar7;
  ulonglong *puVar8;
  ulonglong uVar9;
  ushort uVar10;
  ushort uVar11;
  ushort uVar12;
  uint uVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  byte *pbVar16;
  byte *pbVar17;
  uint uVar18;
  ulonglong uVar19;
  uint uVar20;
  int iVar21;
  byte bVar22;
  ushort *puVar23;
  undefined auStack_1d8 [32];
  undefined8 uStack_1b8;
  short sStack_1a8;
  ushort uStack_1a6;
  uint uStack_1a4;
  byte *pbStack_1a0;
  undefined8 uStack_198;
  undefined4 uStack_190;
  ushort uStack_18c;
  undefined2 uStack_18a;
  undefined6 uStack_188;
  undefined2 uStack_182;
  undefined2 uStack_180;
  ushort uStack_17e;
  ushort uStack_17c;
  undefined2 uStack_17a;
  undefined4 uStack_178;
  uint uStack_170;
  uint uStack_16c;
  uint uStack_168;
  ulonglong uStack_160;
  longlong lStack_158;
  longlong *plStack_150;
  longlong lStack_148;
  undefined auStack_140 [8];
  longlong *plStack_138;
  longlong lStack_130;
  longlong lStack_128;
  undefined8 uStack_118;
  undefined4 uStack_110;
  undefined2 uStack_10c;
  ulonglong uStack_38;
  
  uVar20 = CONCAT22(uStack_190._2_2_,(undefined2)uStack_190);
  uStack_38 = _DAT_ ^ (ulonglong)auStack_1d8;
  uVar14 = 0;
  plStack_138 = param_6;
  iVar21 = 0;
  *param_6 = 0;
  uStack_118 = 0;
  *param_7 = 0;
  plStack_150 = param_7;
  uVar13 = (uint)*(ushort *)(param_1 + 0x16);
  if ((int)(param_5 * 8) <= (int)(uint)*(ushort *)(param_1 + 0x16)) {
    uVar13 = param_5 * 8;
  }
  sStack_1a8 = -1;
  pbStack_1a0 = (byte *)0x0;
  uStack_1a4 = 0;
  uStack_18a = 0;
  uStack_188 = 0;
  uStack_180 = 0;
  uStack_17e = 0;
  uStack_17c = 0;
  uStack_17a = 0;
  uStack_198 = 0;
  uStack_110 = 0;
  uStack_10c = 0;
  uStack_160 = (ulonglong)uVar13;
  uStack_168 = 0;
  uVar19 = uVar14;
  lStack_158 = param_4;
  lStack_148 = param_2;
  lStack_130 = param_1;
  lStack_128 = param_3;
  if (0 < (int)uVar13) {
    do {
      uVar13 = (uint)uVar19;
      uVar10 = *(ushort *)(param_1 + (0xfff - uVar19) * 2);
      uStack_170 = (uint)uVar14 + 1;
      if (uVar10 == 0) {
        uStack_170 = (uint)uVar14;
      }
      uVar14 = (ulonglong)uStack_170;
      bVar22 = (byte)uVar19;
      if ((((lStack_148 != 0) && ((*(byte *)(lStack_148 + (uVar19 >> 3)) >> (bVar22 & 7) & 1) != 0))
          || ((param_3 != 0 && ((*(byte *)((uVar19 >> 3) + param_3) >> (bVar22 & 7) & 1) != 0)))) ||
         ((param_4 != 0 && ((*(byte *)((uVar19 >> 3) + param_4) >> (bVar22 & 7) & 1) != 0)))) {
        bVar22 = bVar22 & 7;
        uVar14 = uVar19 >> 3;
        uVar6 = (uint)*(ushort *)(param_1 + 0xe);
        pbStack_1a0 = (byte *)((ulonglong)uVar10 + param_1);
        if ((*pbStack_1a0 & 1) == 0) {
          sStack_1a8 = 0;
          uStack_1a4 = 0;
          uStack_182 = 0;
          uStack_180 = 0;
          switch(*pbStack_1a0 & 0xe) {
          default:
            uVar6 = (uint)*(ushort *)(pbStack_1a0 + 2);
            if (0x1f9d < *(ushort *)(pbStack_1a0 + 2) - 1) {
              uStack_190 = uVar20;
              func_0x(pbStack_1a0,6);
              uVar20 = uStack_190;
            }
            break;
          case 4:
            uVar6 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar6 = 1;
          }
          uStack_198 = CONCAT44(uStack_198._4_4_,uVar6);
          lVar7 = param_1 + 0x2000;
          if (param_1 == 0) {
            lVar7 = 0;
          }
          uStack_18a = (undefined2)lVar7;
          uStack_188 = (undefined6)((ulonglong)lVar7 >> 0x10);
        }
        else {
          sStack_1a8 = 1;
          bVar2 = *pbStack_1a0;
          switch(bVar2 & 0x1c) {
          default:
            if ((char)pbStack_1a0[1] < '\0') {
              sVar5 = 3;
              uStack_190._0_2_ = 3;
              uStack_1a6 = (*(ushort *)(pbStack_1a0 + 1) & 0x7f) << 8 |
                           *(ushort *)(pbStack_1a0 + 1) >> 8;
            }
            else {
              uStack_1a6 = (ushort)pbStack_1a0[1];
              sVar5 = 2;
              uStack_190._0_2_ = 2;
            }
            uStack_18c = (short)(uStack_1a6 + 1 >> 1) + sVar5;
            if (uStack_1a6 < 0x1f) {
              uStack_190._2_2_ = 0;
              uStack_1a4 = 0;
              uStack_178 = 0;
            }
            else {
              iVar21 = uStack_1a6 - 1;
              uStack_1a4 = 0;
              uStack_178 = 0;
              uStack_190._2_2_ =
                   ((short)(iVar21 / 0x1e) + (short)(iVar21 >> 0x1f)) -
                   (short)((longlong)iVar21 * 0x88888889 >> 0x3f);
            }
            break;
          case 4:
            if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
              uStack_190._0_2_ = 0;
              uStack_190._2_2_ = 0;
              uStack_18c = 0;
              uStack_18a = 0;
              uStack_1a6 = 0;
              uStack_188 = 0;
              uStack_182 = 0;
              uStack_1a4 = 0xf;
              uStack_178 = 1;
            }
            else {
              uStack_190._0_2_ = 0;
              uStack_190._2_2_ = 0;
              uStack_18c = 0;
              uStack_18a = 0;
              uStack_1a6 = 0;
              uStack_188 = 0;
              uStack_182 = 0;
              uStack_1a4 = 1;
              uStack_178 = 0;
            }
            break;
          case 8:
            uStack_190._0_2_ = 0;
            uStack_190._2_2_ = 0;
            uStack_18c = 0;
            uStack_18a = 0;
            uStack_1a6 = 0;
            uStack_188 = 0;
            uStack_182 = 0;
            uStack_1a4 = 9;
            uStack_178 = 0;
          }
          uVar20 = CONCAT22(uStack_190._2_2_,(undefined2)uStack_190);
          uStack_198 = 0;
          lVar7 = param_1 + 0x2000;
          if (param_1 == 0) {
            lVar7 = 0;
          }
          uStack_180 = (undefined2)lVar7;
          uStack_17e = (ushort)((ulonglong)lVar7 >> 0x10);
          uStack_17c = (ushort)((ulonglong)lVar7 >> 0x20);
          uStack_17a = (undefined2)((ulonglong)lVar7 >> 0x30);
        }
        uStack_190 = uVar20;
        if (sStack_1a8 == 0) {
          uVar6 = func_0x(&uStack_1a6);
        }
        else {
          uVar6 = uStack_1a4;
          if (uStack_1a4 == 0) {
            func_0x(&uStack_1a6);
            uVar6 = uStack_1a4;
          }
        }
        uStack_16c = uVar6;
        if (sStack_1a8 == 0) {
          func_0x();
          uVar20 = uStack_190;
        }
        else {
          func_0x(&uStack_1a6,auStack_140);
          uVar20 = uStack_190;
        }
        if ((lStack_158 == 0) || ((*(byte *)(uVar14 + lStack_158) >> bVar22 & 1) == 0)) {
          uStack_190 = uVar20;
          if ((param_3 == 0) || ((*(byte *)(uVar14 + param_3) >> bVar22 & 1) == 0)) {
            if ((lStack_148 == 0) || ((*(byte *)(lStack_148 + uVar14) >> bVar22 & 1) == 0)) {
              uStack_1b8 = 0;
              (*_DAT_)(1,0x14fcc30,0x14c7c98,0xd6a);
            }
          }
          else {
            func_0x(&sStack_1a8,(byte)(*(char *)(param_1 + 1) - 3U) < 2);
            *plStack_138 = *plStack_138 + 1;
            *(short *)(param_1 + 0x3a) = *(short *)(param_1 + 0x3a) + -1;
          }
          if (sStack_1a8 == 0) {
            func_0x();
          }
          else {
            func_0x(&uStack_1a6,&uStack_118);
          }
          uVar10 = (short)(1 << ((byte)*(undefined2 *)(param_1 + 4) & 2)) - 1;
          uVar20 = uStack_190;
          if (sStack_1a8 == 0) {
            pbVar16 = pbStack_1a0;
            uVar6 = uStack_1a4;
            if (uStack_1a4 == 0) {
              uVar14 = uStack_198 & 0xffffffff;
              iVar21 = 0;
              uStack_1a6 = 0;
              uVar20 = (uint)uStack_198;
              if ((*pbStack_1a0 & 0x10) != 0) {
                uVar20 = (uint)uStack_198 + 2 + (*(ushort *)(pbStack_1a0 + uVar14) + 7 >> 3);
                uVar14 = (ulonglong)uVar20;
              }
              uStack_198 = CONCAT44(uVar20,(uint)uStack_198);
              uVar20 = (uint)uVar14;
              if ((*pbStack_1a0 & 0x20) == 0) {
                uStack_18c = 0;
                uStack_1a4 = uVar20;
              }
              else {
                puVar23 = (ushort *)(pbStack_1a0 + uVar14);
                uStack_18c = *puVar23;
                uVar19 = uVar14;
                if (uStack_18c == 0) {
                  cVar4 = func_0x(0x1a52d80);
                  if (cVar4 != '\0') {
                    lVar7 = func_0x();
                    if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                      cVar4 = func_0x(0x1a52d80);
                      if (cVar4 == '\0') {
                        (*pcRam0000000000fc0908)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        uStack_1b8 = 0;
                        (*_DAT_)(1,0x134278c,0x1462878,0x80f);
                      }
                    }
                  }
                  func_0x(pbStack_1a0,3);
                  uVar19 = uStack_198 >> 0x20;
                }
                uStack_190 = (int)uVar19 + (uStack_18c + 1) * 2;
                if (0x1f9e < uStack_190) {
                  cVar4 = func_0x(0x1a52d80);
                  if (cVar4 != '\0') {
                    lVar7 = func_0x();
                    if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                      cVar4 = func_0x(0x1a52d80);
                      if (cVar4 == '\0') {
                        (*pcRam0000000000fc0908)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        uStack_1b8 = 0;
                        (*_DAT_)(1,0x134278c,0x1462878,0x816);
                      }
                    }
                  }
                  func_0x(pbStack_1a0,4);
                  uVar19 = uStack_198 >> 0x20;
                }
                uVar15 = (ulonglong)uStack_18c;
                uStack_1a4 = puVar23[uVar15] & 0x7fff;
                if (uStack_1a4 < uStack_190) {
                  cVar4 = func_0x(0x1a52d80);
                  if (cVar4 != '\0') {
                    lVar7 = func_0x();
                    if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                      cVar4 = func_0x(0x1a52d80);
                      if (cVar4 == '\0') {
                        (*pcRam0000000000fc0908)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        uStack_1b8 = 0;
                        (*_DAT_)(1,0x134278c,0x1462878,0x81d);
                      }
                    }
                  }
                  func_0x(pbStack_1a0,4);
                  uVar15 = (ulonglong)uStack_18c;
                  uVar19 = uStack_198 >> 0x20;
                }
                uVar14 = (ulonglong)uStack_1a4;
                pbVar16 = pbStack_1a0;
                uVar13 = uStack_190;
                puVar3 = puVar23;
                uVar20 = uStack_190;
                if ((short)uVar15 != 0) {
                  do {
                    uVar20 = puVar3[1] & 0x7fff;
                    if ((uVar20 < uStack_190) || ((uint)uVar14 < uVar20)) {
                      uStack_190 = uVar13;
                      cVar4 = func_0x(0x1a52d80);
                      if (cVar4 != '\0') {
                        lVar7 = func_0x();
                        if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                          cVar4 = func_0x(0x1a52d80);
                          if (cVar4 == '\0') {
                            (*pcRam0000000000fc0908)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            uStack_1b8 = 0;
                            (*_DAT_)(1,0x134278c,0x1462878,0x82a);
                          }
                        }
                      }
                      func_0x(pbStack_1a0,4);
                      uVar15 = (ulonglong)uStack_18c;
                      uVar14 = (ulonglong)uStack_1a4;
                      pbVar16 = pbStack_1a0;
                      uVar13 = uStack_190;
                    }
                    iVar21 = iVar21 + 1;
                    uStack_190 = uVar20;
                    puVar3 = puVar3 + 1;
                  } while (iVar21 < (int)uVar15);
                  uVar19 = uStack_198 >> 0x20;
                  uVar20 = uVar13;
                  param_1 = lStack_130;
                }
                while ((short)puVar23[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
                  if ((int)uVar15 == 1) {
                    uVar9 = 1;
                    uVar6 = uVar13;
                  }
                  else {
                    uVar6 = *(ushort *)(pbVar16 + uVar15 * 2 + (uVar19 - 2)) & 0x7fff;
                    uVar9 = uVar15;
                  }
                  uVar18 = *(ushort *)(pbVar16 + uVar9 * 2 + uVar19) & 0x7fff;
                  if (((uVar6 < uVar13) || (uVar18 < uVar6)) ||
                     (uStack_190 = uVar13, (uint)uVar14 < uVar18)) {
                    uStack_190 = uVar20;
                    func_0x(pbVar16,7);
                    uVar15 = (ulonglong)uStack_18c;
                    uVar19 = uStack_198 >> 0x20;
                    uVar14 = (ulonglong)uStack_1a4;
                    pbVar16 = pbStack_1a0;
                    uVar20 = uStack_190;
                  }
                  if ((uVar6 < uStack_190) || ((uint)uVar14 < uVar6)) goto code_r0x00100c8b;
                  if (*(ushort *)(pbVar16 + uVar6) == 5) {
                    uStack_1a6 = uStack_1a6 | 2;
                    uStack_18c = (short)uVar15 - 1;
                    uVar19 = (ulonglong)(uVar6 & 0xffff);
                    pbVar1 = pbVar16 + uVar19;
                    uStack_17e = (ushort)uVar6;
                    if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                      uVar12 = uStack_17c & 0xc7ff;
                    }
                    else {
                      uVar12 = uStack_17c ^ (*(ushort *)(pbVar1 + 2) ^ uStack_17c) & 0x3800;
                    }
                    uStack_17c = (uVar12 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar12;
                    uVar9 = (ulonglong)uStack_17c;
                    uVar15 = uVar9 & 0x7ff;
                    lVar7 = (ulonglong)((uVar12 >> 0xb & 7) * 2) + 4 + uVar19;
                    pbVar17 = pbVar16;
                    uStack_190 = uVar20;
                    if (pbVar16 + lVar7 + uVar15 * 2 < pbVar1) {
                      func_0x(pbVar1,0x19);
                      uVar9 = (ulonglong)uStack_17c;
                      uVar19 = (ulonglong)uStack_17e;
                      uVar14 = (ulonglong)uStack_1a4;
                      pbVar17 = pbStack_1a0;
                    }
                    uVar20 = uStack_190;
                    if (uVar18 - uVar6 <
                        (((uStack_17c & 0x7ff) * 2 - (int)uVar19) - (int)pbStack_1a0) +
                        (int)(pbVar16 + lVar7 + uVar15 * 2)) {
                      func_0x(pbVar17 + uVar19,0x19);
                      uVar9 = (ulonglong)uStack_17c;
                      uVar19 = (ulonglong)uStack_17e;
                      uVar14 = (ulonglong)uStack_1a4;
                      pbVar17 = pbStack_1a0;
                      uVar20 = uStack_190;
                    }
                    iVar21 = 0;
                    pbVar16 = pbVar17;
                    if (((uVar9 & 0x3800) != 0) &&
                       (puVar23 = (ushort *)(pbVar17 + uVar19 + 4), (uVar9 & 0x3800) != 0)) {
                      do {
                        if (((ushort)uVar9 & 0x7ff) < (*puVar23 & 0x7ff)) {
                          uStack_190 = uVar20;
                          func_0x(pbVar17 + uVar19,0x1a);
                          uVar9 = (ulonglong)uStack_17c;
                          uVar19 = (ulonglong)uStack_17e;
                          pbVar17 = pbStack_1a0;
                          uVar20 = uStack_190;
                        }
                        iVar21 = iVar21 + 1;
                        puVar23 = puVar23 + 1;
                      } while (iVar21 < (int)((uStack_17c & 0x3800) >> 0xb));
                      uVar14 = (ulonglong)uStack_1a4;
                      pbVar16 = pbVar17;
                    }
                    break;
                  }
                  if (*(ushort *)(pbVar16 + uVar6) < 0x400) break;
                  uStack_1a6 = uStack_1a6 | 1;
                  uStack_18c = (short)uVar15 - 1;
                  uVar15 = (ulonglong)uStack_18c;
                  uVar13 = uStack_190;
                  if (uStack_18c == 0) break;
                }
              }
              iVar21 = 0;
              if ((*pbVar16 & 0x40) == 0) {
                uStack_182 = 0;
                uStack_180 = 0;
              }
              else {
                uStack_182 = (undefined2)uVar14;
                uStack_180 = (undefined2)(uVar14 >> 0x10);
                uStack_1a4 = (int)uVar14 + 0xe;
                uStack_190 = uVar20;
                puVar8 = (ulonglong *)func_0x(&uStack_1a6);
                uVar11 = (ushort)(*puVar8 >> 0x30);
                uVar12 = uVar11;
                if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
                  uVar12 = uVar11 & 0xdfff;
                  if ((uVar11 >> 0xe & 1) != 0) {
                    uVar12 = uVar11 | 0x2000;
                  }
                }
                if (uVar12 == 0xfffc) {
                  iVar21 = (int)((*puVar8 >> 0x20 & 0xffff) >> 5);
                }
                uStack_1a4 = uStack_1a4 + iVar21;
                uVar14 = (ulonglong)uStack_1a4;
                pbVar16 = pbStack_1a0;
                uVar20 = uStack_190;
              }
              uStack_190 = uVar20;
              if (((byte *)CONCAT62(uStack_188,uStack_18a) != (byte *)0x0) &&
                 ((byte *)CONCAT62(uStack_188,uStack_18a) < pbVar16 + uVar14)) {
                cVar4 = func_0x(0x1a52d80);
                if (cVar4 != '\0') {
                  lVar7 = func_0x();
                  if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                    cVar4 = func_0x(0x1a52d80);
                    if (cVar4 == '\0') {
                      (*pcRam0000000000fc0908)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      uStack_1b8 = 0;
                      (*_DAT_)(1,0x134278c,0x1462878,0x886);
                    }
                  }
                }
                func_0x(pbStack_1a0,0x12);
                uVar14 = (ulonglong)uStack_1a4;
                pbVar16 = pbStack_1a0;
              }
              uVar20 = uStack_190;
              if ((int)uVar14 - 1U < 0x3f3c) {
code_r0x00100c8b:
                uVar6 = (uint)uVar14;
              }
              else {
                cVar4 = func_0x(0x1a52d80);
                if (cVar4 != '\0') {
                  lVar7 = func_0x();
                  if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                    cVar4 = func_0x(0x1a52d80);
                    if (cVar4 == '\0') {
                      (*pcRam0000000000fc0908)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      uStack_1b8 = 0;
                      (*_DAT_)(1,0x134278c,0x1462878,0x88b);
                    }
                  }
                }
                func_0x(pbStack_1a0,5);
                pbVar16 = pbStack_1a0;
                uVar6 = uStack_1a4;
                uVar20 = uStack_190;
              }
            }
            uVar13 = uStack_168;
            if ((uVar6 < 9) && (((*pbVar16 & 0xe) == 0 || ((*pbVar16 & 0xe) == 0xc)))) {
              uVar6 = 9;
            }
          }
          else {
            if (uStack_1a4 == 0) {
              func_0x(&uStack_1a6);
              uVar20 = uStack_190;
            }
            uVar6 = uStack_1a4;
            if ((uStack_1a4 < 9) && (((*pbStack_1a0 & 0x1c) == 0 || ((*pbStack_1a0 & 0x1c) == 0xc)))
               ) {
              uVar6 = 9;
            }
          }
          uVar12 = (1 << ((byte)*(undefined2 *)(param_1 + 4) & 2)) - 1;
          uVar10 = (uVar10 + (short)uStack_16c & ~uVar10) - ((short)uVar6 + uVar12 & ~uVar12);
          param_3 = lStack_128;
        }
        else {
          uVar10 = (1 << ((byte)*(undefined2 *)(param_1 + 4) & 2)) - 1;
          *(undefined2 *)(param_1 + (0xfff - uVar19) * 2) = 0;
          uVar10 = (short)uVar6 + uVar10 & ~uVar10;
          *plStack_150 = *plStack_150 + 1;
        }
        *(short *)(param_1 + 0x1c) = *(short *)(param_1 + 0x1c) + uVar10;
        uVar14 = (ulonglong)uStack_170;
        param_4 = lStack_158;
        param_7 = plStack_150;
      }
      iVar21 = (int)uVar14;
      uStack_168 = uVar13 + 1;
      uVar19 = (ulonglong)uStack_168;
    } while ((int)uStack_168 < (int)uStack_160);
    uStack_170 = iVar21;
    if (0 < *param_7) {
      uVar13 = (uint)*(ushort *)(param_1 + 0x16);
      while (uVar13 = uVar13 - 1, uStack_170 = iVar21, -1 < (int)uVar13) {
        if (*(short *)(param_1 + (0xfff - (longlong)(int)uVar13) * 2) == 0) {
          uVar10 = *(ushort *)(param_1 + 0x16);
          uStack_190 = uVar20;
          func_0x
                    (param_1 + (0x1001 - (ulonglong)uVar10) * 2,
                     param_1 + (0x1000 - (longlong)(int)(uint)uVar10) * 2,(uVar10 - uVar13) * 2 + -2
                    );
          *(short *)(param_1 + 0x16) = *(short *)(param_1 + 0x16) + -1;
          *(short *)(param_1 + 0x1c) = *(short *)(param_1 + 0x1c) + 2;
          iVar21 = uStack_170;
          uVar20 = uStack_190;
        }
      }
    }
  }
  uStack_190 = uVar20;
  if (param_5 < iVar21 + 7U >> 3) {
    uStack_1b8 = 0;
    (*_DAT_)(1,0x14fca88,0x14c7c98,0xdad);
  }
  func_0x(param_1,0xffffffff);
  func_0x(uStack_38 ^ (ulonglong)auStack_1d8);
  return;
}

