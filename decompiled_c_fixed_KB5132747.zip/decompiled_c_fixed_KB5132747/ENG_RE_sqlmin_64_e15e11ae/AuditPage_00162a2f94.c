
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(byte *param_1,int param_2,uint param_3)

{
  byte *pbVar1;
  char cVar2;
  byte bVar3;
  short sVar4;
  ushort uVar5;
  int iVar6;
  undefined4 uVar7;
  uint uVar8;
  uint uVar9;
  short *psVar10;
  longlong lVar11;
  ushort uVar12;
  undefined8 uVar13;
  ulonglong uVar14;
  uint uVar15;
  byte **ppbVar16;
  ulonglong uVar17;
  ushort uVar18;
  byte *pbVar19;
  uint uVar20;
  byte **ppbVar21;
  int iVar22;
  ushort *puVar23;
  uint uVar24;
  byte *pbVar25;
  longlong unaff_GS_OFFSET;
  undefined auStack_198 [32];
  undefined8 uStack_178;
  uint uStack_170;
  int iStack_168;
  uint uStack_164;
  undefined8 uStack_160;
  int iStack_158;
  short sStack_154;
  int iStack_152;
  short sStack_14e;
  undefined8 uStack_148;
  undefined2 uStack_140;
  uint uStack_138;
  undefined4 uStack_134;
  undefined2 uStack_130;
  undefined auStack_12c [12];
  longlong lStack_120;
  undefined4 uStack_118;
  byte *pbStack_110;
  ushort *puStack_108;
  undefined auStack_100 [8];
  short sStack_f8;
  ushort uStack_f6;
  uint uStack_f4;
  byte *pbStack_f0;
  undefined8 uStack_e8;
  undefined4 uStack_e0;
  ushort uStack_dc;
  undefined2 uStack_da;
  undefined6 uStack_d8;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  ushort uStack_ce;
  ushort uStack_cc;
  undefined2 uStack_ca;
  undefined4 uStack_c8;
  int iStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [8];
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined6 uStack_98;
  undefined2 uStack_92;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined8 uStack_88;
  undefined auStack_80 [16];
  undefined auStack_70 [16];
  undefined auStack_60 [16];
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_198;
  iVar22 = 0;
  pbStack_f0 = (byte *)0x0;
  uStack_f4 = 0;
  uStack_da = 0;
  uStack_d8 = 0;
  uStack_d0 = 0;
  uStack_ce = 0;
  uStack_cc = 0;
  uStack_ca = 0;
  uStack_e8 = (byte **)0x0;
  sStack_f8 = -1;
  iStack_c4 = -1;
  uStack_138 = param_3;
  pbStack_110 = param_1;
  if ((*param_1 != 1) && (iVar22 = 1, param_3 == 2)) {
    uStack_170 = 1;
    uStack_178 = CONCAT44(uStack_178._4_4_,(uint)*param_1);
    func_0x(0x22eb,param_1,0x13650f0,5);
  }
  bVar3 = param_1[1];
  if ((0x65 < (byte)(bVar3 - 1)) &&
     (((bVar3 != 0xff || (param_2 != 2)) && (iVar22 = iVar22 + 1, param_3 == 2)))) {
    uStack_170 = (uint)bVar3;
    uStack_178 = CONCAT44(uStack_178._4_4_,uStack_170);
    func_0x(0x22eb,param_1,0x1364fc0,6);
  }
  if ((char)param_1[2] < '\0') {
    if ((6 < param_1[0x60]) && (iVar22 = iVar22 + 1, param_3 == 2)) {
      uStack_170 = 0xffffffff;
      uStack_178 = CONCAT44(uStack_178._4_4_,0xffffffff);
      func_0x(0x22eb,param_1,0x13652b0,0x35);
    }
    if (iVar22 != 0) {
      if (((DAT_ & 0x40) != 0) ||
         (((lVar11 = *(longlong *)
                      ((ulonglong)*_DAT_ +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
           lVar11 != 0 && (lVar11 = **(longlong **)(lVar11 + 0x38), lVar11 != 0)) &&
          (iVar6 = (*_DAT_)(lVar11,0x279e), iVar6 != 0)))) {
        func_0x(0x1365250,0x1365148,iVar22);
      }
      uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0);
      goto LAB_;
    }
    iVar22 = 0;
    if (*(short *)((ulonglong)param_1[0x60] * 6 + 0x1126d34) == -1) {
      if (param_3 == 2) {
        uStack_170 = 0xffffffff;
        uStack_178 = CONCAT44(uStack_178._4_4_,0xffffffff);
        func_0x(0x22eb,param_1,0x13651d0,0x32);
      }
      if (((DAT_ & 0x40) != 0) ||
         (((lVar11 = *(longlong *)
                      ((ulonglong)*_DAT_ +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
           lVar11 != 0 && (lVar11 = **(longlong **)(lVar11 + 0x38), lVar11 != 0)) &&
          (iVar22 = (*_DAT_)(lVar11,0x279e), iVar22 != 0)))) {
        func_0x(0x1365160,0x1365148,1);
      }
      uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0);
      goto LAB_;
    }
  }
  uVar5 = 0x60;
  if ((char)param_1[2] < '\0') {
    sVar4 = func_0x(param_1 + 0x60);
    uVar5 = sVar4 + 0x60;
  }
  uVar12 = *(ushort *)(param_1 + 0x1e);
  if (((uVar12 < uVar5) ||
      ((0x1000 - (ulonglong)*(ushort *)(param_1 + 0x16)) * 2 < (ulonglong)uVar12)) &&
     (iVar22 = iVar22 + 1, param_3 == 2)) {
    uStack_170 = (0x1000 - (uint)*(ushort *)(param_1 + 0x16)) * 2;
    uStack_178 = CONCAT44(uStack_178._4_4_,(uint)uVar12);
    func_0x(0x22eb,param_1,0x1365440,7);
  }
  if ((char)param_1[2] < '\0') {
    sVar4 = func_0x(param_1 + 0x60);
    uVar5 = sVar4 + 0x60;
  }
  else {
    uVar5 = 0x60;
  }
  uVar12 = *(ushort *)(param_1 + 0x1c);
  if (((int)(0x2000 - (uint)uVar5) < (int)(uint)uVar12) && (iVar22 = iVar22 + 1, param_3 == 2)) {
    if ((char)param_1[2] < '\0') {
      sVar4 = func_0x(param_1 + 0x60);
      uVar12 = *(ushort *)(param_1 + 0x1c);
      uVar5 = sVar4 + 0x60;
    }
    else {
      uVar5 = 0x60;
    }
    uStack_170 = 0x2000 - uVar5;
    uStack_178 = CONCAT44(uStack_178._4_4_,(uint)uVar12);
    func_0x(0x22eb,param_1,0x13653c0,8);
  }
  if ((((uint)*(ushort *)(param_1 + 0x1e) & (1 << ((byte)*(undefined2 *)(param_1 + 4) & 2)) - 1U) !=
       0) && (iVar22 = iVar22 + 1, param_3 == 2)) {
    func_0x(param_1,0x1365370,9);
  }
  uVar5 = *(ushort *)(param_1 + 0x16);
  if (((0xfcf < uVar5) && (iVar22 = iVar22 + 1, param_3 != 0)) && (param_3 == 2)) {
    uStack_170 = 0xfd0;
    uStack_178 = CONCAT44(uStack_178._4_4_,(uint)uVar5);
    func_0x(0x22eb,param_1,0x1365338,10);
    uVar5 = *(ushort *)(param_1 + 0x16);
  }
  if (((uVar5 < *(ushort *)(param_1 + 0x3a)) && (iVar22 = iVar22 + 1, param_3 != 0)) &&
     (param_3 == 2)) {
    uStack_170 = (uint)uVar5;
    uStack_178 = CONCAT44(uStack_178._4_4_,(uint)*(ushort *)(param_1 + 0x3a));
    func_0x(0x22eb,param_1,0x1365730,0xb);
    uVar5 = *(ushort *)(param_1 + 0x16);
  }
  if (uVar5 != 0) {
    if ((char)param_1[2] < '\0') {
      sVar4 = func_0x(param_1 + 0x60);
      uVar5 = sVar4 + 0x60;
    }
    else {
      uVar5 = 0x60;
    }
    uVar12 = *(ushort *)(param_1 + 0x1ffe);
    if (((uVar12 < uVar5) && (uVar12 != 0)) &&
       ((iVar22 = iVar22 + 1, param_3 != 0 && (param_3 == 2)))) {
      if ((char)param_1[2] < '\0') {
        sVar4 = func_0x(param_1 + 0x60);
        uVar12 = *(ushort *)(param_1 + 0x1ffe);
        uVar5 = sVar4 + 0x60;
      }
      else {
        uVar5 = 0x60;
      }
      uStack_170 = (uint)uVar5;
      uStack_178 = CONCAT44(uStack_178._4_4_,(uint)uVar12);
      func_0x(0x22eb,param_1,0x1365640,0x33);
      uVar12 = *(ushort *)(param_1 + 0x1ffe);
    }
    if ((0x1fff < uVar12) && (iVar22 = iVar22 + 1, param_3 == 2)) {
      uStack_170 = 0x2000;
      uStack_178 = CONCAT44(uStack_178._4_4_,(uint)uVar12);
      func_0x(0x22eb,param_1,0x13655e0,0x34);
    }
  }
  if (((*(short *)(param_1 + 0xc) == 0) && (*(int *)(param_1 + 8) != 0)) &&
     (iVar22 = iVar22 + 1, param_3 == 2)) {
    uStack_170 = 0;
    uStack_178 = CONCAT44(uStack_178._4_4_,*(int *)(param_1 + 8));
    func_0x(0x22eb,param_1,0x1365590,0x36);
  }
  if (((*(short *)(param_1 + 0x14) == 0) && (*(int *)(param_1 + 0x10) != 0)) &&
     (iVar22 = iVar22 + 1, param_3 == 2)) {
    uStack_170 = 0;
    uStack_178 = CONCAT44(uStack_178._4_4_,*(int *)(param_1 + 0x10));
    func_0x(0x22eb,param_1,0x1365910,0x38);
  }
  if (((*(short *)(param_1 + 0x24) == 0) && (*(int *)(param_1 + 0x20) != 0)) &&
     (iVar22 = iVar22 + 1, param_3 == 2)) {
    uStack_170 = 0;
    uStack_178 = CONCAT44(uStack_178._4_4_,*(int *)(param_1 + 0x20));
    func_0x(0x22eb,param_1,0x13658c0,0x3a);
  }
  if (iVar22 == 0) {
    uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0);
    if (param_2 == 2) goto LAB_;
    if ((char)param_1[2] < '\0') {
      uVar7 = func_0x(param_1 + 0x60);
      bVar3 = param_1[1];
      if (((1 < (byte)(bVar3 - 1)) && (bVar3 != 0x13)) && (iVar22 = 1, param_3 == 2)) {
        uStack_170 = (uint)bVar3;
        uStack_178 = CONCAT44(uStack_178._4_4_,(uint)param_1[2]);
        func_0x(0x22eb,param_1,0x1365780,0x2d);
        iVar22 = 1;
      }
      if ((0x1fa0 < (ushort)uVar7) && (iVar22 = iVar22 + 1, param_3 == 2)) {
        uStack_170 = 0x1fa0;
        uStack_178 = CONCAT44(uStack_178._4_4_,uVar7) & 0xffffffff0000ffff;
        func_0x(0x22eb,param_1,0x1365aa0,0x2f);
      }
    }
    bVar3 = param_1[1];
    switch(bVar3) {
    case 1:
      if ((param_1[3] != 0) && (iVar22 = iVar22 + 1, param_3 == 2)) {
        uStack_170 = 0;
        uStack_178 = CONCAT44(uStack_178._4_4_,(uint)param_1[3]);
        func_0x(0x22eb,param_1,0x1365a78,0xd);
      }
      break;
    case 2:
    case 3:
    case 6:
    case 7:
    case 0xd:
    case 0xe:
    case 0x13:
    case 0x14:
    case 0x66:
    case 0xff:
      break;
    case 4:
      if (((1 < *(ushort *)(param_1 + 0x16)) || (bVar3 != 4)) && (iVar22 = iVar22 + 1, param_3 == 2)
         ) {
        uStack_170 = 1;
        uStack_178 = CONCAT44(uStack_178._4_4_,(uint)*(ushort *)(param_1 + 0x16));
        func_0x(0x22eb,param_1,0x1365a00,0x2a);
      }
      break;
    default:
      iVar22 = iVar22 + 1;
      if (param_3 == 2) {
        func_0x(0,param_1,5,bVar3);
      }
      break;
    case 8:
    case 9:
    case 0x10:
    case 0x11:
      if (param_2 == 1) {
        func_0x(&uStack_160,bVar3,param_1 + 0x20,8);
        uVar5 = uStack_160._4_2_;
        uVar15 = (uint)uStack_160;
        if ((((*(int *)(param_1 + 0x18) != 99) || (*(short *)(param_1 + 6) != 0)) ||
            ((*(uint *)(param_1 + 0x20) != (uint)uStack_160 ||
             (*(ushort *)(param_1 + 0x24) != uStack_160._4_2_)))) &&
           (iVar22 = iVar22 + 1, param_3 == 2)) {
          uStack_170 = 99;
          uStack_178 = CONCAT44(uStack_178._4_4_,*(int *)(param_1 + 0x18));
          func_0x(0x22eb,param_1,0x1365960,0x11);
        }
        if (((*(uint *)(param_1 + 0x20) & 0xfffffff8) !=
             ((*(uint *)(param_1 + 0x20) & 0xfffffff8) / 0x7cd00) * 0x7cd00) &&
           (iVar22 = iVar22 + 1, param_3 == 2)) {
          uStack_170 = uVar15;
          uStack_178 = CONCAT44(uStack_178._4_4_,(uint)uVar5);
          func_0x(0x22eb,param_1,0x1365cc0,0x12);
        }
        if ((*(ushort *)(param_1 + 0x16) != 2) && (iVar22 = iVar22 + 1, param_3 == 2)) {
          uStack_178 = CONCAT44(uStack_178._4_4_,(uint)*(ushort *)(param_1 + 0x16));
          uStack_170 = param_3;
          func_0x(0x22eb,param_1,0x1365c90,0x13);
        }
        if (iVar22 == 0) {
          uVar5 = *(ushort *)(param_1 + 0x1ffe);
          iVar6 = 1;
          if (((uVar5 != 0x60) && (iVar22 = iVar6, param_3 != 0)) && (param_3 == 2)) {
            uStack_170 = 0x60;
            uStack_178 = CONCAT44(uStack_178._4_4_,(uint)uVar5);
            func_0x(0x22eb,param_1,0x1365c20,0x14);
            uVar5 = *(ushort *)(param_1 + 0x1ffe);
          }
          sVar4 = 1 << ((byte)*(undefined2 *)(param_1 + 4) & 2);
          uVar12 = sVar4 - 1;
          uVar5 = sVar4 + 0x5d + uVar5;
          uVar18 = uVar12 + *(short *)(param_1 + 0x1ffc);
          uVar12 = ~uVar12;
          if (((uVar18 & uVar12) != (uVar12 & uVar5)) && (iVar22 = iVar22 + 1, param_3 == 2)) {
            uStack_170 = (uint)(uVar5 & uVar12);
            uStack_178 = CONCAT44(uStack_178._4_4_,(uint)(uVar12 & uVar18));
            func_0x(0x22eb,param_1,0x1365b00,0x15);
          }
        }
      }
      break;
    case 10:
      if (param_2 == 1) {
        if (((*(ushort *)(param_1 + 0x16) != 2) || (bVar3 != 10)) &&
           (iVar22 = iVar22 + 1, param_3 == 2)) {
          uStack_170 = 2;
          uStack_178 = CONCAT44(uStack_178._4_4_,(uint)*(ushort *)(param_1 + 0x16));
          func_0x(0x22eb,param_1,0x1365f40,0x1b);
        }
        if (iVar22 == 0) {
          uVar5 = *(ushort *)(param_1 + 0x1ffe);
          if ((uVar5 != 0x60) || (uVar12 = 0x60, param_1[1] != 10)) {
            uVar12 = uVar5;
            iVar22 = 1;
            if ((param_3 != 0) && (iVar22 = 1, param_3 == 2)) {
              uStack_178 = CONCAT44(uStack_178._4_4_,(uint)uVar5);
              uStack_170 = 0x60;
              func_0x(0x22eb,param_1,0x1365e90,0x1c);
              uVar12 = *(ushort *)(param_1 + 0x1ffe);
              iVar22 = 1;
            }
          }
          sVar4 = 1 << ((byte)*(undefined2 *)(param_1 + 4) & 2);
          uVar18 = sVar4 - 1;
          uVar5 = ~uVar18;
          uVar18 = uVar18 + *(short *)(param_1 + 0x1ffc) & uVar5;
          uVar5 = sVar4 + 0x5d + uVar12 & uVar5;
          if (((uVar18 != uVar5) || (param_1[1] != 10)) && (iVar22 = iVar22 + 1, param_3 == 2)) {
            uStack_170 = (uint)uVar5;
            uStack_178 = CONCAT44(uStack_178._4_4_,(uint)uVar18);
            func_0x(0x22eb,param_1,0x1365d20,0x1d);
          }
        }
      }
      break;
    case 0xb:
      if (param_2 == 1) {
        uVar5 = *(ushort *)(param_1 + 0x24);
        uVar15 = (*(uint *)(param_1 + 0x20) / 0x1f98) * 0x1f98;
        if (uVar15 == 0) {
          uVar15 = 1;
        }
        if ((((*(int *)(param_1 + 0x18) != 99) || (*(short *)(param_1 + 6) != 0)) || (bVar3 != 0xb))
           && (iVar22 = iVar22 + 1, param_3 == 2)) {
          uStack_170 = 99;
          uStack_178 = CONCAT44(uStack_178._4_4_,*(int *)(param_1 + 0x18));
          func_0x(0x22eb,param_1,0x1366270,0x1e);
        }
        iVar6 = (*(uint *)(param_1 + 0x20) / 0x1f98) * 0x1f98;
        if (iVar6 == 0) {
          iVar6 = 1;
        }
        if ((iVar6 != *(int *)(param_1 + 0x20)) && (iVar22 = iVar22 + 1, param_3 == 2)) {
          uStack_178 = CONCAT44(uStack_178._4_4_,(uint)uVar5);
          uStack_170 = uVar15;
          func_0x(0x22eb,param_1,0x13661d0,0x1f);
        }
        if (((*(ushort *)(param_1 + 0x16) != 1) || (param_1[1] != 0xb)) &&
           (iVar22 = iVar22 + 1, param_3 == 2)) {
          uStack_170 = 1;
          uStack_178 = CONCAT44(uStack_178._4_4_,(uint)*(ushort *)(param_1 + 0x16));
          func_0x(0x22eb,param_1,0x1366160,0x20);
        }
        if (((iVar22 == 0) && ((*(ushort *)(param_1 + 0x1ffe) != 0x60 || (param_1[1] != 0xb)))) &&
           (iVar22 = 1, param_3 == 2)) {
          uStack_170 = 0x60;
          uStack_178 = CONCAT44(uStack_178._4_4_,(uint)*(ushort *)(param_1 + 0x1ffe));
          func_0x(0x22eb,param_1,0x13660b0,0x21);
        }
      }
      break;
    case 0xf:
      if ((((bVar3 != 0xf) || (*(int *)(param_1 + 0x20) != 0)) ||
          (1 < (ushort)(*(short *)(param_1 + 0x16) - 1U))) && (iVar22 = iVar22 + 1, param_3 == 2)) {
        uStack_170 = 1;
        uStack_178 = CONCAT44(uStack_178._4_4_,(uint)*(ushort *)(param_1 + 0x16));
        func_0x(0x22eb,param_1,0x1365fb0,0x28);
      }
      break;
    case 100:
      if ((param_1[2] != 0) && (iVar22 = iVar22 + 1, param_3 == 2)) {
        uStack_170 = 0;
        uStack_178 = CONCAT44(uStack_178._4_4_,(uint)param_1[2]);
        func_0x(0x22eb,param_1,0x13664b8,0x22);
      }
      break;
    case 0x65:
      if ((param_1[2] != 0) && (iVar22 = iVar22 + 1, param_3 == 2)) {
        uStack_170 = 0;
        uStack_178 = CONCAT44(uStack_178._4_4_,(uint)param_1[2]);
        func_0x(0x22eb,param_1,0x13664b8,0x23);
      }
    }
    if (((char)*(ushort *)(param_1 + 4) < '\0') && (iVar22 = iVar22 + 1, param_3 == 2)) {
      uStack_170 = 0x80;
      uStack_178 = CONCAT44(uStack_178._4_4_,(uint)*(ushort *)(param_1 + 4));
      func_0x(0x22eb,param_1,0x1366450,0x29);
    }
    if (iVar22 != 0) {
      if ((DAT_ & 0x40) == 0) {
        lVar11 = *(longlong *)
                  ((ulonglong)*_DAT_ +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
        uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0);
        if ((lVar11 == 0) ||
           (lVar11 = **(longlong **)(lVar11 + 0x38),
           uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0), lVar11 == 0))
        goto LAB_;
        iVar6 = (*_DAT_)(lVar11,0x279e);
        uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0);
        if (iVar6 == 0) goto LAB_;
      }
      uVar13 = 0x13663c0;
      goto LAB_;
    }
    if ((char)param_1[2] < '\0') {
      iVar22 = func_0x(param_3,param_1);
    }
    if (param_2 == 1) {
LAB_:
      if (param_1[1] != 7) {
        iVar6 = func_0x(param_1,param_2,param_3);
        iVar22 = iVar22 + iVar6;
      }
LAB_:
      if (param_2 != 1) goto LAB_;
    }
    else {
      if (param_1[1] == 7) goto LAB_;
      if ((DAT_ & 0x80) != 0) goto LAB_;
      uVar5 = *(ushort *)(param_1 + 0x16);
      uVar15 = 0;
      uStack_164 = 0;
      iStack_168 = 0;
      if (uVar5 != 0) {
        lStack_120 = 0;
        uVar15 = 0;
        do {
          lVar11 = lStack_120;
          if ((*(ushort *)(param_1 + 4) & 0x1000) != 0) {
            uVar8 = (uint)*(ushort *)(param_1 + 0xe) * iStack_168 + 0x60;
            if ((*(ushort *)(param_1 + (0xfff - lStack_120) * 2) != uVar8) &&
               (iVar22 = iVar22 + 1, param_3 == 2)) {
              uStack_178 = CONCAT44(uStack_178._4_4_,
                                    (uint)*(ushort *)(param_1 + (0xfff - lStack_120) * 2));
              uStack_170 = uVar8;
              func_0x(0x22eb,param_1,0x1366320,0x2b);
            }
          }
          ppbVar21 = (byte **)0x0;
          uStack_160 = (ushort *)(param_1 + (0xfff - lVar11) * 2);
          if (*(short *)(param_1 + (0xfff - lVar11) * 2) != 0) {
            iStack_c4 = iStack_168;
            if ((char)param_1[2] < '\0') {
              pbVar19 = param_1 + 0x60;
              if ((sStack_f8 == 0) || (ppbVar21 = uStack_e8, uStack_e8 == (byte **)0x0)) {
                uStack_98 = 0;
                stack0xffffffffffffff52 = SUB1614(ZEXT816(0),2);
                auStack_b0._0_2_ = 0xffff;
                uStack_8a = 0;
                uStack_a8 = 0;
                uStack_92 = 0;
                uStack_90 = 0;
                uStack_88 = 0;
                uStack_a0 = 0;
                auStack_80 = ZEXT816(0);
                auStack_60._0_12_ = ZEXT812(0);
                auStack_60._12_4_ = 0;
                uStack_50 = 0;
                auStack_70 = ZEXT816(0);
                auStack_c0 = ZEXT816(0);
                ppbVar21 = (byte **)auStack_c0;
              }
              if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
                uStack_148 = *(undefined8 *)(param_1 + 0x28);
                uStack_140 = *(undefined2 *)(param_1 + 0x30);
              }
              else {
                bVar3 = param_1[1];
                if (bVar3 == 0xb) {
                  if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
                    if (bVar3 != 9) goto LAB_;
                    goto LAB_;
                  }
                }
                else {
                  if (bVar3 != 8) goto LAB_;
LAB_:
                  if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
                }
                uStack_134 = *(undefined4 *)(param_1 + 0x20);
                uStack_130 = *(undefined2 *)(param_1 + 0x24);
                cVar2 = func_0x(&uStack_134);
                if (cVar2 == '\0') goto LAB_;
                func_0x(param_1,&uStack_148);
              }
              *ppbVar21 = pbVar19;
              *(undefined4 *)(ppbVar21 + 0xc) = (undefined4)uStack_148;
              *(undefined2 *)(ppbVar21 + 0xd) = uStack_140;
              *(int *)((longlong)ppbVar21 + 100) = (int)((ulonglong)uStack_148 >> 0x20);
              *(undefined4 *)((longlong)ppbVar21 + 0x6c) = *(undefined4 *)(param_1 + 0x20);
              *(undefined2 *)(ppbVar21 + 0xe) = *(undefined2 *)(param_1 + 0x24);
              *(undefined2 *)((longlong)ppbVar21 + 0x72) = 0;
              uStack_118 = *(undefined4 *)((ulonglong)*pbVar19 * 6 + 0x1126d30);
              uVar17 = (ulonglong)*(short *)((ulonglong)*pbVar19 * 6 + 0x1126d34);
              *(undefined2 *)(ppbVar21 + 2) = 0xffff;
              ppbVar21[3] = (byte *)0x0;
              uVar15 = 0;
              *(undefined4 *)((longlong)ppbVar21 + 0x14) = 0;
              *(undefined8 *)((longlong)ppbVar21 + 0x2e) = 0;
              ppbVar21[7] = (byte *)0x0;
              ppbVar21[4] = (byte *)0x0;
              ppbVar21[9] = (byte *)0x0;
              ppbVar21[10] = (byte *)0x0;
              *(undefined2 *)(ppbVar21 + 0xb) = 0;
              if ((**ppbVar21 & 2) != 0) {
                pbVar1 = pbVar19 + uVar17;
                if ((pbVar19[uVar17] & 1) == 0) {
                  *(undefined2 *)(ppbVar21 + 2) = 0;
                  ppbVar21[3] = pbVar1;
                  *(undefined4 *)((longlong)ppbVar21 + 0x14) = 0;
                  *(undefined4 *)((longlong)ppbVar21 + 0x36) = 0;
                  switch(*pbVar1 & 0xe) {
                  default:
                    uVar15 = (uint)*(ushort *)(pbVar1 + 2);
                    if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
                      func_0x(pbVar1,6);
                    }
                    break;
                  case 4:
                    uVar15 = 9;
                    break;
                  case 6:
                  case 10:
                    break;
                  case 0xe:
                    uVar15 = 1;
                  }
                  *(uint *)(ppbVar21 + 4) = uVar15;
                  *(undefined8 *)((longlong)ppbVar21 + 0x2e) = 0;
                }
                else {
                  *(undefined2 *)(ppbVar21 + 2) = 1;
                  ppbVar21[3] = pbVar1;
                  bVar3 = *pbVar1;
                  switch(bVar3 & 0x1c) {
                  default:
                    if ((char)pbVar1[1] < '\0') {
                      uVar5 = *(ushort *)(pbVar1 + 1);
                      sVar4 = 3;
                      *(ushort *)((longlong)ppbVar21 + 0x12) = uVar5;
                      uVar5 = (uVar5 & 0x7f) << 8 | uVar5 >> 8;
                    }
                    else {
                      sVar4 = 2;
                      uVar5 = (ushort)pbVar1[1];
                    }
                    *(ushort *)((longlong)ppbVar21 + 0x12) = uVar5;
                    *(short *)(ppbVar21 + 5) = sVar4;
                    uVar5 = *(ushort *)((longlong)ppbVar21 + 0x12);
                    *(short *)((longlong)ppbVar21 + 0x2c) = (short)(uVar5 + 1 >> 1) + sVar4;
                    if (uVar5 < 0x1f) {
                      *(undefined2 *)((longlong)ppbVar21 + 0x2a) = 0;
                      *(undefined4 *)((longlong)ppbVar21 + 0x14) = 0;
                      *(undefined4 *)(ppbVar21 + 8) = 0;
                      ppbVar21[7] = (byte *)0x0;
                      ppbVar21[4] = (byte *)0x0;
                    }
                    else {
                      iVar6 = uVar5 - 1;
                      *(short *)((longlong)ppbVar21 + 0x2a) =
                           ((short)(iVar6 / 0x1e) + (short)(iVar6 >> 0x1f)) -
                           (short)((longlong)iVar6 * 0x88888889 >> 0x3f);
                      *(undefined4 *)((longlong)ppbVar21 + 0x14) = 0;
                      *(undefined4 *)(ppbVar21 + 8) = 0;
                      ppbVar21[7] = (byte *)0x0;
                      ppbVar21[4] = (byte *)0x0;
                    }
                    break;
                  case 4:
                    if (((bVar3 & 0x1c) != 4) || (uVar8 = 1, (bVar3 & 2) == 0)) {
                      uVar8 = uVar15;
                    }
                    if (uVar8 == 0) {
                      uVar7 = 1;
                    }
                    else {
                      *(undefined4 *)(ppbVar21 + 8) = 0;
                      uVar7 = 0xf;
                    }
                    ppbVar21[5] = (byte *)0x0;
                    *(undefined2 *)((longlong)ppbVar21 + 0x12) = 0;
                    ppbVar21[6] = (byte *)0x0;
                    ppbVar21[4] = (byte *)0x0;
                    ppbVar21[7] = (byte *)0x0;
                    ppbVar21[3] = pbVar1;
                    *(undefined4 *)((longlong)ppbVar21 + 0x14) = uVar7;
                    *(uint *)(ppbVar21 + 8) = (uint)(uVar8 != 0);
                    ppbVar21[7] = (byte *)0x0;
                    ppbVar21[4] = (byte *)0x0;
                    break;
                  case 8:
                    ppbVar21[7] = (byte *)0x0;
                    ppbVar21[7] = (byte *)0x0;
                    ppbVar21[5] = (byte *)0x0;
                    *(undefined2 *)((longlong)ppbVar21 + 0x12) = 0;
                    ppbVar21[6] = (byte *)0x0;
                    ppbVar21[4] = (byte *)0x0;
                    ppbVar21[3] = pbVar1;
                    *(undefined4 *)((longlong)ppbVar21 + 0x14) = 9;
                    *(undefined4 *)(ppbVar21 + 8) = 0;
                    ppbVar21[4] = (byte *)0x0;
                  }
                }
              }
              if ((**ppbVar21 & 4) != 0) {
                if (uStack_118._2_2_ != 0) {
                  uVar17 = (ulonglong)*(ushort *)(param_1 + (longlong)uStack_118._2_2_ * 2 + 0x61);
                }
                psVar10 = (short *)(pbVar19 + uVar17);
                ppbVar21[9] = (byte *)psVar10;
                sVar4 = *psVar10;
                ppbVar21[10] = (byte *)(psVar10 + 1);
                *(short *)(ppbVar21 + 0xb) = (sVar4 + 1) * 2;
              }
              uVar15 = uStack_164;
              if (ppbVar21[1] != (byte *)0x0) {
                func_0x(ppbVar21[1],ppbVar21);
                uVar15 = uStack_164;
              }
            }
            uVar17 = 0;
            ppbVar16 = (byte **)(ulonglong)*(ushort *)(param_1 + 0xe);
            pbStack_f0 = param_1 + *uStack_160;
            if ((*pbStack_f0 & 1) == 0) {
              sStack_f8 = 0;
              uStack_f4 = 0;
              uStack_d2 = 0;
              uStack_d0 = 0;
              switch(*pbStack_f0 & 0xe) {
              default:
                ppbVar16 = (byte **)(ulonglong)*(ushort *)(pbStack_f0 + 2);
                if (0x1f9d < *(ushort *)(pbStack_f0 + 2) - 1) {
                  func_0x(pbStack_f0,6);
                  uVar17 = (ulonglong)uStack_f4;
                }
                break;
              case 4:
                ppbVar16 = (byte **)0x9;
                uVar17 = 0;
                break;
              case 6:
              case 10:
                break;
              case 0xe:
                ppbVar16 = (byte **)0x1;
              }
              uVar8 = (uint)ppbVar16;
              uStack_e8 = (byte **)CONCAT44(uStack_e8._4_4_,uVar8);
              uStack_da = SUB82(param_1 + 0x2000,0);
              uStack_d8 = (undefined6)((ulonglong)(param_1 + 0x2000) >> 0x10);
            }
            else {
              sStack_f8 = 1;
              bVar3 = *pbStack_f0;
              switch(bVar3 & 0x1c) {
              default:
                if ((char)pbStack_f0[1] < '\0') {
                  sVar4 = 3;
                  uStack_e0._0_2_ = 3;
                  uStack_f6 = (*(ushort *)(pbStack_f0 + 1) & 0x7f) << 8 |
                              *(ushort *)(pbStack_f0 + 1) >> 8;
                }
                else {
                  uStack_f6 = (ushort)pbStack_f0[1];
                  sVar4 = 2;
                  uStack_e0._0_2_ = 2;
                }
                uStack_dc = (short)(uStack_f6 + 1 >> 1) + sVar4;
                if (uStack_f6 < 0x1f) {
                  uStack_e0._2_2_ = 0;
                  uStack_f4 = 0;
                  uStack_c8 = 0;
                }
                else {
                  iVar6 = uStack_f6 - 1;
                  uStack_f4 = 0;
                  uStack_c8 = 0;
                  uStack_e0._2_2_ =
                       ((short)(iVar6 / 0x1e) + (short)(iVar6 >> 0x1f)) -
                       (short)((longlong)iVar6 * 0x88888889 >> 0x3f);
                }
                break;
              case 4:
                if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
                  uVar17 = 0xf;
                  uStack_e0._0_2_ = 0;
                  uStack_e0._2_2_ = 0;
                  uStack_dc = 0;
                  uStack_da = 0;
                  uStack_f4 = 0xf;
                  uStack_f6 = 0;
                  uStack_d8 = 0;
                  uStack_d2 = 0;
                  uStack_c8 = 1;
                }
                else {
                  uStack_e0._0_2_ = 0;
                  uStack_e0._2_2_ = 0;
                  uStack_dc = 0;
                  uStack_da = 0;
                  uVar17 = 1;
                  uStack_f6 = 0;
                  uStack_d8 = 0;
                  uStack_d2 = 0;
                  uStack_f4 = 1;
                  uStack_c8 = 0;
                }
                break;
              case 8:
                uVar17 = 9;
                uStack_e0._0_2_ = 0;
                uStack_e0._2_2_ = 0;
                uStack_dc = 0;
                uStack_da = 0;
                uStack_f4 = 9;
                uStack_f6 = 0;
                uStack_d8 = 0;
                uStack_d2 = 0;
                uStack_c8 = 0;
              }
              pbVar19 = param_1 + 0x2000;
              uStack_d0 = SUB82(pbVar19,0);
              uStack_ce = (ushort)((ulonglong)pbVar19 >> 0x10);
              uStack_cc = (ushort)((ulonglong)pbVar19 >> 0x20);
              uStack_ca = (undefined2)((ulonglong)pbVar19 >> 0x30);
              uVar8 = (uint)ppbVar21;
              ppbVar16 = ppbVar21;
              uStack_e8 = ppbVar21;
            }
            uVar9 = 0;
            uVar20 = (uint)uVar17;
            uVar24 = uStack_e0;
            if (sStack_f8 == 0) {
              pbVar19 = pbStack_f0;
              if (uVar20 == 0) {
                uStack_f6 = 0;
                uVar15 = (uint)ppbVar16;
                if ((*pbStack_f0 & 0x10) != 0) {
                  if ((*pbStack_f0 & 0x10) != 0) {
                    uVar9 = (uint)*(ushort *)(pbStack_f0 + uVar8);
                  }
                  uVar15 = uVar15 + 2 + (uVar9 + 7 >> 3);
                  ppbVar16 = (byte **)(ulonglong)uVar15;
                }
                uStack_e8 = (byte **)CONCAT44(uVar15,(int)uStack_e8);
                uVar24 = (uint)ppbVar16;
                if ((*pbStack_f0 & 0x20) == 0) {
                  uVar17 = (ulonglong)ppbVar16 & 0xffffffff;
                  uStack_dc = 0;
                  uStack_f4 = uVar24;
                }
                else {
                  puVar23 = (ushort *)(pbStack_f0 + ((ulonglong)ppbVar16 & 0xffffffff));
                  uStack_dc = *puVar23;
                  puStack_108 = puVar23;
                  if (uStack_dc == 0) {
                    cVar2 = func_0x(0x1a3d4e0);
                    if (cVar2 != '\0') {
                      lVar11 = func_0x();
                      if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                        cVar2 = func_0x(0x1a3d4e0);
                        if (cVar2 == '\0') {
                          (*pcRam0000000000fab068)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          uStack_178 = 0;
                          (*pcRam0000000000fab060)(1,0x132ceec,0x144cfd8,0x80f);
                        }
                      }
                    }
                    func_0x(pbStack_f0,3);
                    ppbVar16 = (byte **)((ulonglong)uStack_e8 >> 0x20);
                  }
                  uStack_e0 = (int)ppbVar16 + (uStack_dc + 1) * 2;
                  if (0x1f9e < uStack_e0) {
                    cVar2 = func_0x(0x1a3d4e0);
                    if (cVar2 != '\0') {
                      lVar11 = func_0x();
                      if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                        cVar2 = func_0x(0x1a3d4e0);
                        if (cVar2 == '\0') {
                          (*pcRam0000000000fab068)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_178 = 0;
                          (*pcRam0000000000fab060)(1,0x132ceec,0x144cfd8,0x816);
                        }
                      }
                    }
                    func_0x(pbStack_f0,4);
                    ppbVar16 = (byte **)((ulonglong)uStack_e8 >> 0x20);
                  }
                  uVar14 = (ulonglong)uStack_dc;
                  uStack_f4 = puVar23[uVar14] & 0x7fff;
                  if (uStack_f4 < uStack_e0) {
                    cVar2 = func_0x(0x1a3d4e0);
                    if (cVar2 != '\0') {
                      lVar11 = func_0x();
                      if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                        cVar2 = func_0x(0x1a3d4e0);
                        if (cVar2 == '\0') {
                          (*pcRam0000000000fab068)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_178 = 0;
                          (*pcRam0000000000fab060)(1,0x132ceec,0x144cfd8,0x81d);
                        }
                      }
                    }
                    func_0x(pbStack_f0,4);
                    uVar14 = (ulonglong)uStack_dc;
                    ppbVar16 = (byte **)((ulonglong)uStack_e8 >> 0x20);
                  }
                  uVar17 = (ulonglong)uStack_f4;
                  iVar6 = 0;
                  pbVar19 = pbStack_f0;
                  uVar15 = uStack_e0;
                  uVar24 = uStack_e0;
                  if ((short)uVar14 != 0) {
                    do {
                      puVar23 = puVar23 + 1;
                      uVar8 = *puVar23 & 0x7fff;
                      if ((uVar8 < uVar15) || ((uint)uVar17 < uVar8)) {
                        cVar2 = func_0x(0x1a3d4e0);
                        if (cVar2 != '\0') {
                          lVar11 = func_0x();
                          if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                            cVar2 = func_0x(0x1a3d4e0);
                            if (cVar2 == '\0') {
                              (*pcRam0000000000fab068)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              uStack_178 = 0;
                              (*pcRam0000000000fab060)(1,0x132ceec,0x144cfd8,0x82a);
                            }
                          }
                        }
                        func_0x(pbStack_f0,4);
                        uVar14 = (ulonglong)uStack_dc;
                        uVar17 = (ulonglong)uStack_f4;
                        pbVar19 = pbStack_f0;
                      }
                      iVar6 = iVar6 + 1;
                      uVar15 = uVar8;
                    } while (iVar6 < (int)uVar14);
                    ppbVar16 = (byte **)((ulonglong)uStack_e8 >> 0x20);
                    uVar24 = uStack_e0;
                    puVar23 = puStack_108;
                    param_1 = pbStack_110;
                  }
                  while( true ) {
                    if (-1 < (short)puVar23[(ulonglong)((int)uVar14 - 1) + 1]) break;
                    uVar15 = uStack_e0;
                    if ((int)uVar14 != 1) {
                      uVar15 = *(ushort *)
                                (pbVar19 + uVar14 * 2 + (((ulonglong)ppbVar16 & 0xffffffff) - 2)) &
                               0x7fff;
                    }
                    uVar8 = *(ushort *)(pbVar19 + uVar14 * 2 + ((ulonglong)ppbVar16 & 0xffffffff)) &
                            0x7fff;
                    if (((uVar15 < uStack_e0) || (uVar8 < uVar15)) ||
                       (uVar5 = (ushort)uVar14, (uint)uVar17 < uVar8)) {
                      uStack_e0 = uVar24;
                      func_0x(pbVar19,7);
                      uVar17 = (ulonglong)uStack_f4;
                      ppbVar16 = (byte **)((ulonglong)uStack_e8 >> 0x20);
                      pbVar19 = pbStack_f0;
                      uVar5 = uStack_dc;
                      uVar24 = uStack_e0;
                    }
                    if ((uVar15 < uStack_e0) || ((uint)uVar17 < uVar15)) goto code_r0x00101a9d;
                    if (*(ushort *)(pbVar19 + uVar15) == 5) {
                      uStack_f6 = uStack_f6 | 2;
                      uStack_dc = uVar5 - 1;
                      uVar14 = (ulonglong)(uVar15 & 0xffff);
                      pbVar1 = pbVar19 + uVar14;
                      uStack_ce = (ushort)uVar15;
                      if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                        uVar5 = uStack_cc & 0xc7ff;
                      }
                      else {
                        uVar5 = uStack_cc ^ (uStack_cc ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
                      }
                      uStack_cc = (uVar5 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar5;
                      uVar20 = (uint)uStack_cc;
                      pbVar25 = pbVar19 + uVar14 + ((ulonglong)uVar20 & 0x7ff) * 2 +
                                                   (ulonglong)((uVar5 >> 0xb & 7) * 2) + 4;
                      uStack_e0 = uVar24;
                      if (pbVar25 < pbVar1) {
                        func_0x(pbVar1,0x19);
                        uVar20 = (uint)uStack_cc;
                        uVar17 = (ulonglong)uStack_f4;
                        uVar14 = (ulonglong)uStack_ce;
                        pbVar19 = pbStack_f0;
                      }
                      uVar24 = uStack_e0;
                      if (uVar8 - uVar15 <
                          (((uStack_cc & 0x7ff) * 2 - (int)uVar14) - (int)pbStack_f0) + (int)pbVar25
                         ) {
                        func_0x(pbVar19 + uVar14,0x19);
                        uVar20 = (uint)uStack_cc;
                        uVar17 = (ulonglong)uStack_f4;
                        uVar14 = (ulonglong)uStack_ce;
                        pbVar19 = pbStack_f0;
                        uVar24 = uStack_e0;
                      }
                      if ((uVar20 & 0x3800) != 0) {
                        puVar23 = (ushort *)(pbVar19 + uVar14 + 4);
                        iVar6 = 0;
                        if ((uVar20 & 0x3800) != 0) {
                          do {
                            if (((ushort)uVar20 & 0x7ff) < (*puVar23 & 0x7ff)) {
                              uStack_e0 = uVar24;
                              func_0x(pbVar19 + uVar14,0x1a);
                              uVar20 = (uint)uStack_cc;
                              uVar14 = (ulonglong)uStack_ce;
                              pbVar19 = pbStack_f0;
                              uVar24 = uStack_e0;
                            }
                            iVar6 = iVar6 + 1;
                            puVar23 = puVar23 + 1;
                          } while (iVar6 < (int)((uStack_cc & 0x3800) >> 0xb));
                          uVar17 = (ulonglong)uStack_f4;
                        }
                      }
                      break;
                    }
                    if (*(ushort *)(pbVar19 + uVar15) < 0x400) break;
                    uStack_f6 = uStack_f6 | 1;
                    uStack_dc = uVar5 - 1;
                    uVar14 = (ulonglong)uStack_dc;
                    if (uStack_dc == 0) break;
                  }
                }
                if ((*pbVar19 & 0x40) == 0) {
                  uStack_d2 = 0;
                  uStack_d0 = 0;
                }
                else {
                  uStack_d2 = (undefined2)uVar17;
                  uStack_d0 = (undefined2)(uVar17 >> 0x10);
                  uStack_f4 = (int)uVar17 + 0xe;
                  uStack_e0 = uVar24;
                  uVar13 = func_0x(&uStack_f6);
                  func_0x(uVar13,auStack_100);
                  iVar6 = func_0x(auStack_100);
                  uStack_f4 = uStack_f4 + iVar6;
                  uVar17 = (ulonglong)uStack_f4;
                  pbVar19 = pbStack_f0;
                  uVar24 = uStack_e0;
                }
                uStack_e0 = uVar24;
                if (((byte *)CONCAT62(uStack_d8,uStack_da) != (byte *)0x0) &&
                   ((byte *)CONCAT62(uStack_d8,uStack_da) < pbVar19 + uVar17)) {
                  cVar2 = func_0x(0x1a3d4e0);
                  if (cVar2 != '\0') {
                    lVar11 = func_0x();
                    if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                      cVar2 = func_0x(0x1a3d4e0);
                      if (cVar2 == '\0') {
                        (*pcRam0000000000fab068)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        uStack_178 = 0;
                        (*pcRam0000000000fab060)(1,0x132ceec,0x144cfd8,0x886);
                      }
                    }
                  }
                  func_0x(pbStack_f0,0x12);
                  uVar17 = (ulonglong)uStack_f4;
                  pbVar19 = pbStack_f0;
                }
                uVar24 = uStack_e0;
                if (0x3f3b < (int)uVar17 - 1U) {
                  cVar2 = func_0x(0x1a3d4e0);
                  if (cVar2 != '\0') {
                    lVar11 = func_0x();
                    if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                      cVar2 = func_0x(0x1a3d4e0);
                      if (cVar2 == '\0') {
                        (*pcRam0000000000fab068)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        uStack_178 = 0;
                        (*pcRam0000000000fab060)(1,0x132ceec,0x144cfd8,0x88b);
                      }
                    }
                  }
                  func_0x(pbStack_f0,5);
                  uVar17 = (ulonglong)uStack_f4;
                  pbVar19 = pbStack_f0;
                  uVar24 = uStack_e0;
                }
              }
code_r0x00101a9d:
              uVar20 = (uint)uVar17;
              param_3 = uStack_138;
              if ((uVar20 < 9) && (((*pbVar19 & 0xe) == 0 || ((*pbVar19 & 0xe) == 0xc)))) {
                uVar20 = 9;
              }
            }
            else {
              if (uVar20 == 0) {
                func_0x(&uStack_f6);
                uVar20 = uStack_f4;
                uVar24 = uStack_e0;
              }
              pbVar19 = pbStack_f0;
              uStack_164 = uVar15;
              if ((uVar20 < 9) && (((*pbStack_f0 & 0x1c) == 0 || ((*pbStack_f0 & 0x1c) == 0xc)))) {
                uVar20 = 9;
              }
            }
            sVar4 = 1 << ((byte)*(undefined2 *)(param_1 + 4) & 2);
            uVar15 = uStack_164 + (ushort)((short)uVar20 + -1 + sVar4 & -sVar4);
            uStack_164 = uVar15;
            uStack_e0 = uVar24;
            if (((uint)*(ushort *)(param_1 + 0x1e) < uVar20 + *uStack_160) &&
               (iVar22 = iVar22 + 1, param_3 == 2)) {
              uStack_170 = uVar20 + *uStack_160;
              uStack_178 = CONCAT44(uStack_178._4_4_,(uint)*(ushort *)(param_1 + 0x1e));
              func_0x(0x22eb,param_1,0x1366600,0x25);
              pbVar19 = pbStack_f0;
            }
            lVar11 = func_0x();
            if (lVar11 != 0) {
              lVar11 = func_0x();
              if (*(longlong *)(lVar11 + 0x30) != 0) {
                lVar11 = func_0x();
                uVar8 = *(uint *)(*(longlong *)(lVar11 + 0x30) + 0xc);
                if ((uVar8 < 0xe) && ((0x2640U >> (uVar8 & 0x1f) & 1) != 0)) goto LAB_;
              }
            }
            if (sStack_f8 == 0) {
              bVar3 = *pbVar19 >> 6;
            }
            else {
              bVar3 = *pbVar19 >> 1;
            }
            if ((bVar3 & 1) != 0) {
              if (sStack_f8 == 0) {
                func_0x();
              }
              else {
                func_0x(&uStack_f6,&iStack_158);
              }
              if ((((sStack_154 != 0) || (iStack_158 != 0)) &&
                  ((*(ushort *)(param_1 + 4) & 0x2000) == 0)) && (iVar22 = iVar22 + 1, param_3 == 2)
                 ) {
                if (sStack_f8 == 0) {
                  func_0x();
                }
                else {
                  func_0x(&uStack_f6,auStack_12c);
                }
                if (sStack_f8 == 0) {
                  func_0x();
                }
                else {
                  func_0x(&uStack_f6,&iStack_152);
                }
                if ((sStack_14e == 0) && (iStack_152 == 0)) {
                  uVar7 = 0;
                }
                else {
                  uVar7 = 1;
                }
                bVar3 = func_0x(auStack_12c);
                uStack_170 = (uint)bVar3;
                uStack_178 = CONCAT44(uStack_178._4_4_,uVar7);
                func_0x(0x22eb,param_1,0x13665b0,0x2c);
              }
            }
          }
LAB_:
          iStack_168 = iStack_168 + 1;
          uVar5 = *(ushort *)(param_1 + 0x16);
          lStack_120 = lStack_120 + 1;
        } while (iStack_168 < (int)(uint)uVar5);
      }
      if ((char)param_1[2] < '\0') {
        sVar4 = func_0x(param_1 + 0x60);
        uVar5 = *(ushort *)(param_1 + 0x16);
        uVar12 = sVar4 + 0x60;
      }
      else {
        uVar12 = 0x60;
      }
      uVar8 = ((0x1000 - (uint)uVar5) * 2 - (uint)*(ushort *)(param_1 + 0x1c)) - (uint)uVar12;
      if ((uVar15 != uVar8) && (iVar22 = iVar22 + 1, param_3 == 2)) {
        uStack_178 = CONCAT44(uStack_178._4_4_,uVar15);
        uStack_170 = uVar8;
        func_0x(0x22eb,param_1,0x1366578,0x27);
      }
      if (iVar22 != 0) {
        if ((DAT_ & 0x40) == 0) {
          lVar11 = *(longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
          if ((lVar11 == 0) || (lVar11 = **(longlong **)(lVar11 + 0x38), lVar11 == 0))
          goto LAB_;
          iVar6 = (*_DAT_)(lVar11,0x279e);
          if (iVar6 == 0) goto LAB_;
        }
        uVar13 = 0x13664f0;
        goto LAB_;
      }
LAB_:
      if ((DAT_ & 0x80) == 0) goto LAB_;
    }
    if (iVar22 == 0) goto LAB_;
    if ((DAT_ & 0x40) == 0) {
      lVar11 = *(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                );
      if ((lVar11 == 0) || (lVar11 = **(longlong **)(lVar11 + 0x38), lVar11 == 0))
      goto LAB_;
      iVar6 = (*_DAT_)(lVar11,0x279e);
      if (iVar6 == 0) goto LAB_;
    }
    uVar13 = 0x1365540;
  }
  else {
    if ((DAT_ & 0x40) == 0) {
      lVar11 = *(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                );
      uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0);
      if ((lVar11 == 0) ||
         (lVar11 = **(longlong **)(lVar11 + 0x38),
         uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0), lVar11 == 0))
      goto LAB_;
      iVar6 = (*_DAT_)(lVar11,0x279e);
      if (iVar6 == 0) goto LAB_;
    }
    uVar13 = 0x1365860;
  }
LAB_:
  func_0x(uVar13,0x1365148,iVar22);
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_198);
  return;
}

