
/* WARNING: Control flow encountered bad instruction data */

void FUN_(void)

{
  func_0x();
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

