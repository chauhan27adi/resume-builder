
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 *param_2,ulonglong param_3,longlong *param_4,
                 char param_5,char param_6)

{
  undefined8 *puVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  undefined8 uVar6;
  int iVar7;
  longlong lVar8;
  longlong lVar9;
  longlong **pplVar10;
  code *UNRECOVERED_JUMPTABLE;
  uint uVar11;
  undefined8 *puVar12;
  undefined auStack_118 [32];
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  undefined8 uStack_e8;
  undefined8 uStack_e0;
  uint uStack_d8;
  undefined2 uStack_c8;
  undefined4 uStack_c4;
  byte *pbStack_c0;
  undefined8 uStack_b8;
  undefined8 uStack_aa;
  undefined2 uStack_a2;
  undefined2 uStack_a0;
  undefined6 uStack_9e;
  undefined8 uStack_90;
  longlong *plStack_88;
  uint uStack_80;
  longlong lStack_78;
  longlong lStack_70;
  int iStack_68;
  longlong lStack_60;
  undefined8 uStack_58;
  undefined8 *apuStack_50 [2];
  undefined8 uStack_40;
  ulonglong uStack_38;
  
  uStack_40 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_118;
  lStack_70 = param_1 + 0x40;
  puVar12 = (undefined8 *)0x0;
  iStack_68 = 0;
  lStack_60 = 0;
  uStack_58 = 0;
  uStack_90 = param_3;
  plStack_88 = param_4;
  lStack_78 = param_1;
  apuStack_50[0] = param_2;
  func_0x(&lStack_70,0x40033d);
  lVar8 = lStack_70;
  if (param_6 != '\0') {
    lVar5 = *(longlong *)(*(longlong *)(param_1 + 0x38) + 0x728);
    if ((lVar5 == 0) || (iVar7 = iStack_68, (*(uint *)(lVar5 + 0x24) >> 7 & 1) == 0)) {
      if ((*(char *)(param_1 + 0x79) != '\0') && (param_5 != '\0')) {
        puVar1 = param_2 + 6;
        uStack_90 = (ulonglong)param_2[7] >> 0x10;
        lVar9 = func_0x(param_1,&uStack_90);
        lVar5 = *(longlong *)(lVar9 + 0x60);
        if ((((param_4 == (longlong *)0x0) || ((*(byte *)(param_4 + 0x3c) & 1) == 0)) ||
            (8 < *(uint *)puVar1)) || ((0x124U >> (*(uint *)puVar1 & 0x1f) & 1) == 0)) {
          plStack_88._0_4_ = 0;
          if (lVar5 == 0) {
            uStack_90 = CONCAT26(uStack_90._6_2_,*(undefined6 *)(param_2 + 9));
            func_0x(lVar9,*(undefined4 *)puVar1,&uStack_90,*(undefined8 *)(param_1 + 0x30));
            if (((DAT_ & 0x10) != 0) &&
               (*(char *)(*(longlong *)(param_1 + 0x38) + 0x2050) != '\0')) {
              plStack_88 = (longlong *)0x0;
              uVar11 = 0;
              lVar5 = *(longlong *)(*(longlong *)(param_1 + 0x38) + 0x728);
              if (lVar5 != 0) {
                pplVar10 = (longlong **)func_0x(lVar5,apuStack_50,1);
                plStack_88 = *pplVar10;
                uStack_80 = *(uint *)(pplVar10 + 1);
                uVar11 = uStack_80 & 0xffff;
              }
              uStack_e0 = CONCAT44(uStack_e0._4_4_,uVar11);
              uStack_e8 = CONCAT44(uStack_e8._4_4_,(int)((ulonglong)plStack_88 >> 0x20));
              uStack_f8 = CONCAT44(uStack_f8._4_4_,*(undefined4 *)(param_2 + 9));
              uStack_f0 = plStack_88._0_4_;
              func_0x(0x110db00,param_2[7],*(undefined4 *)puVar1,
                              *(undefined2 *)((longlong)param_2 + 0x4c));
            }
          }
          else {
            lVar9 = lVar5 + 0x5b0;
            uStack_58._4_4_ = 4;
            uStack_d8 = 0;
            uStack_e0 = 0;
            uStack_e8 = 0;
            uStack_f0 = 0;
            uStack_f8 = 0;
            lStack_60 = lVar9;
            uStack_58._0_4_ = func_0x(lVar9,4,0xffffffff);
            func_0x(lVar5,puVar1);
            func_0x(lVar9,4);
            uStack_58 = (ulonglong)uStack_58._4_4_ << 0x20;
            if (((DAT_ & 0x10) != 0) &&
               (*(char *)(*(longlong *)(param_1 + 0x38) + 0x2050) != '\0')) {
              plStack_88 = (longlong *)0x0;
              uVar11 = 0;
              lVar9 = *(longlong *)(*(longlong *)(param_1 + 0x38) + 0x728);
              if (lVar9 != 0) {
                pplVar10 = (longlong **)func_0x(lVar9,apuStack_50,1);
                plStack_88 = *pplVar10;
                uStack_80 = *(uint *)(pplVar10 + 1);
                uVar11 = uStack_80 & 0xffff;
              }
              uStack_f0 = *(undefined4 *)(param_2 + 9);
              uStack_e0 = CONCAT44(uStack_e0._4_4_,(int)((ulonglong)plStack_88 >> 0x20));
              uStack_e8 = CONCAT44(uStack_e8._4_4_,plStack_88._0_4_);
              uStack_f8 = CONCAT44(uStack_f8._4_4_,(uint)*(ushort *)((longlong)param_2 + 0x4c));
              uStack_d8 = uVar11;
              func_0x(0x110dc00,param_2[7],lVar5,*(undefined4 *)puVar1);
            }
          }
        }
        else {
          uStack_90 = CONCAT44(uStack_90._4_4_,0x793);
          plStack_88 = _DAT_;
          uStack_f8 = CONCAT71(uStack_f8._1_7_,5);
          apuStack_50[0] = (undefined8 *)(*_DAT_)(0x58,_DAT_,0x110d640,0x793);
          if (apuStack_50[0] != (undefined8 *)0x0) {
            uVar3 = *(undefined4 *)(param_2 + 9);
            uVar2 = *(undefined2 *)((longlong)param_2 + 0x4c);
            uVar6 = param_2[7];
            lStack_78 = CONCAT26((short)uVar6,(int6)((ulonglong)uVar6 >> 0x10));
            uVar4 = *(undefined4 *)puVar1;
            apuStack_50[0][1] = 0;
            apuStack_50[0][2] = 0;
            apuStack_50[0][3] = 0;
            apuStack_50[0][4] = 0;
            *apuStack_50[0] = 0xdddc78;
            *(undefined2 *)((longlong)apuStack_50[0] + 0x3e) = 0;
            *(undefined4 *)(apuStack_50[0] + 8) = uVar4;
            *(int *)(apuStack_50[0] + 7) = (int)((ulonglong)uVar6 >> 0x10);
            *(short *)((longlong)apuStack_50[0] + 0x3c) = (short)((ulonglong)uVar6 >> 0x30);
            apuStack_50[0][9] = param_4;
            *(undefined4 *)(apuStack_50[0] + 10) = uVar3;
            *(undefined2 *)((longlong)apuStack_50[0] + 0x54) = uVar2;
            *(undefined2 *)((longlong)apuStack_50[0] + 0x56) = 0;
            puVar12 = apuStack_50[0];
          }
          (**(code **)(*param_4 + 0x158))(param_4,puVar12);
        }
      }
      *(undefined8 *)(lVar8 + 0x30) = 0;
      func_0x(lVar8,0);
      iVar7 = iStack_68 + -1;
    }
    for (; iStack_68 = iVar7, iVar7 != 0; iVar7 = iVar7 + -1) {
      *(undefined8 *)(lVar8 + 0x30) = 0;
      func_0x(lVar8,0);
    }
    func_0x(uStack_38 ^ (ulonglong)auStack_118);
    return;
  }
  uStack_c4 = 0;
  uStack_aa = 0;
  uStack_a0 = 0;
  uStack_9e = 0;
  uStack_b8 = 0;
  pbStack_c0 = (byte *)(*(ushort *)
                         (param_3 + (0xfff - (longlong)*(short *)((longlong)param_2 + 0x1e)) * 2) +
                       param_3);
  if ((*pbStack_c0 & 1) == 0) {
    uStack_c8 = 0;
    uStack_a2 = 0;
    uStack_a0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010029a */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_c0 & 0xe) * 4 + 0x100df4) - 0x16fdda0))
              ();
    return;
  }
  uStack_c8 = 1;
  UNRECOVERED_JUMPTABLE =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_c0 & 0x1c) + 0x100dd4) * 4 +
                         0x100dc4) - 0x16fdda0);
                    /* WARNING: Could not emulate address calculation at 0x001000e2 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
  return;
}

