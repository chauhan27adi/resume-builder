
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2)

{
  ushort *puVar1;
  short **ppsVar2;
  undefined4 uVar3;
  code *pcVar4;
  undefined4 *puVar5;
  undefined8 uVar6;
  ushort *puVar7;
  char cVar8;
  byte bVar9;
  short sVar10;
  ushort uVar11;
  int iVar12;
  longlong lVar13;
  longlong **pplVar14;
  longlong lVar15;
  longlong lVar16;
  undefined8 uVar17;
  longlong lVar18;
  int *piVar19;
  longlong lVar20;
  short *psVar21;
  byte bVar22;
  undefined uVar23;
  byte *pbVar24;
  ushort uVar25;
  uint uVar26;
  uint uVar27;
  longlong **pplVar28;
  ulonglong uVar29;
  longlong lVar30;
  undefined8 unaff_RBX;
  uint *puVar31;
  undefined *puVar32;
  undefined *puVar33;
  short *psVar34;
  int iVar35;
  longlong *plVar36;
  uint *puVar37;
  ulonglong uVar38;
  undefined8 *puVar39;
  uint *puVar40;
  byte *pbVar41;
  ulonglong uVar42;
  ulonglong *puVar43;
  uint uVar44;
  uint *puVar45;
  uint uVar46;
  ushort *puVar47;
  undefined4 uVar48;
  short *psStackX_8;
  undefined8 uStackX_10;
  undefined8 uStackX_18;
  undefined8 uStackX_20;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar13 = func_0x();
  lVar13 = -lVar13;
  puVar32 = &stack0xffffffffffffffc8 + lVar13;
  ppsVar2 = (short **)((longlong)&psStackX_8 + lVar13);
  *(undefined8 *)(&stack0x000002a0 + lVar13) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002428 + lVar13) = unaff_RBX;
  *(ulonglong *)(&stack0x000023c8 + lVar13) = _DAT_ ^ (ulonglong)ppsVar2;
  *ppsVar2 = param_2;
  puVar45 = (uint *)0x0;
  uVar44 = 0;
  *(undefined4 *)(&stack0x0000008c + lVar13) = 0;
  *(undefined8 *)(&stack0x000000a0 + lVar13) = 0;
  *(undefined4 *)(&stack0x000000a8 + lVar13) = 0;
  *(undefined8 *)(&stack0x00000178 + lVar13) = 0xb8e110;
  *(undefined (*) [16])(&stack0x00000180 + lVar13) = ZEXT816(0);
  *(undefined8 *)(&stack0x00000190 + lVar13) = 0;
  *(uint *)(&stack0x000001cc + lVar13) = *(uint *)(&stack0x000001cc + lVar13) & 0xfffffff8;
  *(undefined8 *)(&stack0x000001d0 + lVar13) = 0;
  pplVar14 = *(longlong ***)(param_1 + 0x38);
  plVar36 = *pplVar14;
  if (plVar36 == (longlong *)0x0) {
    uVar26 = *(uint *)(&stack0x00000088 + lVar13);
    *(uint *)(&stack0x00000028 + lVar13) = uVar26;
    puVar31 = *(uint **)(&stack0x00000080 + lVar13);
    *(uint **)(&stack0x00000050 + lVar13) = puVar31;
    plVar36 = *(longlong **)(&stack0x00000078 + lVar13);
    puVar37 = puVar45;
  }
  else {
    puVar39 = *(undefined8 **)(*(longlong *)(param_1 + 0x30) + 0x80);
    if ((*(int *)(puVar39 + 5) == *(int *)(plVar36 + 1)) &&
       (*plVar36 == (ulonglong)*(uint6 *)((longlong)puVar39 + 0x14) * 0x10000)) {
      pcVar4 = *(code **)*puVar39;
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1000db;
      sVar10 = (*pcVar4)(puVar39);
      if (*(short *)((longlong)plVar36 + 0xc) != sVar10) goto LAB_;
      if (plVar36[0x15] != 0) {
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar13) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar13);
        UNLOCK();
      }
    }
    else {
LAB_:
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1000fc;
      func_0x(plVar36,puVar39);
    }
    lVar15 = *(longlong *)(param_1 + 0x18);
    pplVar14 = *(longlong ***)(param_1 + 0x38);
    uVar11 = *(ushort *)((longlong)*pplVar14 + 0x62);
    uVar26 = (uint)uVar11;
    *(uint *)(&stack0x00000028 + lVar13) = (uint)uVar11;
    lVar16 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x80);
    uVar25 = *(ushort *)(plVar36 + 7);
    *(longlong **)(&stack0x00000078 + lVar13) = plVar36;
    *(uint *)(&stack0x00000088 + lVar13) = (uint)uVar11;
    *(longlong *)(&stack0x00000090 + lVar13) = lVar15;
    *(undefined8 *)(&stack0x00000098 + lVar13) = 0;
    puVar31 = (uint *)plVar36[0xe];
    *(uint **)(&stack0x00000050 + lVar13) = puVar31;
    *(uint **)(&stack0x00000080 + lVar13) = puVar31;
    if ((uVar25 & 0x400) == 0) {
      if (lVar16 != 0) {
        lVar16 = **(longlong **)(*(longlong *)(lVar16 + 8) + 0x160);
        *(undefined8 *)(&stack0x000000a0 + lVar13) = *(undefined8 *)(lVar16 + 0xa8);
        *(undefined4 *)(&stack0x000000a8 + lVar13) = *(undefined4 *)(lVar16 + 0xb0);
      }
      uVar46 = *(uint *)(&stack0x0000008c + lVar13);
      puVar37 = (uint *)(ulonglong)(uVar46 | 0x10);
      *(uint *)(&stack0x0000008c + lVar13) = uVar46 | 0x10;
      if (((*(ushort *)(plVar36 + 7) & 0x400) != 0) && (lVar15 != 0)) {
        *(undefined8 *)(&stack0x000000b0 + lVar13) = 0;
        *(undefined8 *)(&stack0x000000c0 + lVar13) = 0;
        *(undefined8 *)(&stack0x000000b8 + lVar13) = 0;
        if ((uVar46 & 4) == 0) {
          puVar37 = (uint *)(ulonglong)(uVar46 | 0x12);
          *(uint *)(&stack0x0000008c + lVar13) = uVar46 | 0x12;
        }
      }
    }
    else {
      pplVar28 = pplVar14;
      if (lVar16 != 0) {
        lVar16 = **(longlong **)(*(longlong *)(lVar16 + 8) + 0x160);
        *(undefined8 *)(&stack0x000000a0 + lVar13) = *(undefined8 *)(lVar16 + 0xa8);
        *(undefined4 *)(&stack0x000000a8 + lVar13) = *(undefined4 *)(lVar16 + 0xb0);
        pplVar28 = *(longlong ***)(param_1 + 0x38);
      }
      uVar46 = *(uint *)(&stack0x0000008c + lVar13);
      puVar37 = (uint *)(ulonglong)(uVar46 | 0x10);
      *(uint *)(&stack0x0000008c + lVar13) = uVar46 | 0x10;
      if (((*(ushort *)(plVar36 + 7) & 0x400) != 0) && (lVar15 != 0)) {
        *(undefined8 *)(&stack0x000000b0 + lVar13) = 0;
        *(undefined8 *)(&stack0x000000c0 + lVar13) = 0;
        *(undefined8 *)(&stack0x000000b8 + lVar13) = 0;
        if ((uVar46 & 4) == 0) {
          puVar37 = (uint *)(ulonglong)(uVar46 | 0x12);
          *(uint *)(&stack0x0000008c + lVar13) = uVar46 | 0x12;
          pplVar14 = pplVar28;
        }
      }
    }
    param_2 = *ppsVar2;
  }
  *(undefined8 *)(&stack0x000000d0 + lVar13) = 0x1ff820;
  if ((*(short *)((longlong)*pplVar14 + 0x3a) == 0) && (*(int *)(*pplVar14 + 10) == 0)) {
    lVar15 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x80);
    *(longlong *)(&stack0x00000058 + lVar13) = lVar15;
    if ((*(byte *)(plVar36 + 6) & 1) != 0) {
      puVar1 = (ushort *)(param_2 + 1);
      if (*param_2 == 0) {
        if ((**(byte **)(param_2 + 4) & 0x10) != 0) {
          uVar44 = (uint)*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8));
        }
      }
      else {
        uVar44 = (uint)*puVar1;
      }
      if (*(uint *)(plVar36 + 3) <= uVar44) {
        *param_2 = 0;
        uVar25 = *(ushort *)(*(longlong *)(&stack0x00000078 + lVar13) + 0x62);
        *(uint *)(&stack0x00000060 + lVar13) = (uint)uVar25;
        puVar31 = *(uint **)(&stack0x00000080 + lVar13);
        uVar44 = 0;
        *(undefined4 *)(&stack0x00000028 + lVar13) = 0;
        puVar33 = &stack0xffffffffffffffc8 + lVar13;
        if (uVar25 != 0) {
          do {
            iVar12 = 1;
            puVar37 = (uint *)0x0;
            cVar8 = *(char *)(puVar31 + 0x10);
            if (cVar8 == '\x01') {
              if ((*(byte *)((longlong)puVar31 + 6) & 0x10) == 0) {
                uVar26 = *(byte *)((ulonglong)(*(ushort *)(puVar31 + 1) - 1 >> 3) +
                                   (ulonglong)*(uint *)(param_2 + 8) + 2 +
                                  *(longlong *)(param_2 + 4)) >>
                         ((byte)(*(ushort *)(puVar31 + 1) - 1) & 7) & 1;
              }
              else {
                *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00000228 + lVar13;
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101533;
                func_0x(puVar1,puVar31,1,&stack0x00000164 + lVar13);
                uVar26 = *(uint *)(&stack0x00000164 + lVar13);
              }
              if (uVar26 == 0) goto LAB_;
LAB_:
              lVar15 = *(longlong *)(&stack0x00000090 + lVar13);
              if ((*(byte *)(*(longlong *)(puVar31 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar15 = *(longlong *)(&stack0x00000098 + lVar13);
              }
              *(undefined *)(lVar15 + *(longlong *)(puVar31 + 0xc)) = 3;
              puVar37 = puVar45;
            }
            else {
              if (cVar8 == '\x02') {
LAB_:
                uVar25 = *(ushort *)(puVar31 + 0xf);
                if ((*(byte *)((longlong)puVar31 + 6) & 0x10) == 0) {
LAB_:
                  *(uint *)(&stack0x00000034 + lVar13) = (uint)uVar25;
                  puVar37 = (uint *)((longlong)(int)*puVar31 + *(longlong *)(param_2 + 4));
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x0000015c + lVar13;
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1015c1;
                  func_0x(puVar1,puVar31,0,&stack0x0000022c + lVar13);
                  if (*(int *)(&stack0x0000015c + lVar13) != 0) goto LAB_;
                  puVar37 = *(uint **)(puVar31 + 2) + 1;
                  uVar26 = **(uint **)(puVar31 + 2);
                  if ((uVar25 != 0) && (uVar26 != uVar25)) {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101605;
                    (*_DAT_)(1,0xf96c90,0xf955f8,0x381);
                  }
                  *(uint *)(&stack0x00000034 + lVar13) = uVar26;
                }
                lVar15 = *(longlong *)(&stack0x00000090 + lVar13);
                if ((*(byte *)(*(longlong *)(puVar31 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar15 = *(longlong *)(&stack0x00000098 + lVar13);
                }
                *(undefined *)(lVar15 + *(longlong *)(puVar31 + 0xc)) = 0;
              }
              else {
                if (cVar8 == '\x03') {
                  if ((*(byte *)((longlong)puVar31 + 6) & 0x10) == 0) {
                    uVar26 = *(byte *)((ulonglong)(*(ushort *)(puVar31 + 1) - 1 >> 3) +
                                       (ulonglong)*(uint *)(param_2 + 8) + 2 +
                                      *(longlong *)(param_2 + 4)) >>
                             ((byte)(*(ushort *)(puVar31 + 1) - 1) & 7) & 1;
                  }
                  else {
                    *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00000220 + lVar13;
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100cd2;
                    func_0x(puVar1,puVar31,1,&stack0x0000016c + lVar13);
                    uVar26 = *(uint *)(&stack0x0000016c + lVar13);
                  }
                  if (uVar26 != 0) goto LAB_;
                }
                else if (cVar8 != '\x04') {
                  if (cVar8 == '\b') {
                    iVar35 = puVar31[0x10] << 0xc;
                    uVar25 = *(ushort *)(puVar31 + 0xf);
                    if ((*puVar31 & 0xc0000000) == 0x80000000) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100c30;
                      iVar12 = func_0x(puVar1);
                      if (iVar12 != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100c4b;
                        puVar37 = (uint *)func_0x(param_2 + 0x15,puVar31,
                                                          &stack0x00000034 + lVar13,
                                                          &stack0x0000021c + lVar13);
                        goto LAB_;
                      }
                      *(undefined4 *)(&stack0x00000034 + lVar13) = 0;
                      uVar25 = *(ushort *)(*(longlong *)(puVar31 + 0x12) + 0x2a);
                    }
                    else {
                      if ((iVar35 < 0) || ((*(byte *)((longlong)puVar31 + 6) & 0x10) != 0)) {
                        *(undefined **)(&stack0xffffffffffffffe8 + lVar13) =
                             &stack0x000000dc + lVar13;
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1003cf;
                        func_0x(puVar1,puVar31,iVar35 < 0,&stack0x000000d8 + lVar13)
                        ;
                        if ((iVar35 < 0) && (*(int *)(&stack0x000000d8 + lVar13) != 0)) {
                          *(undefined4 *)(&stack0x00000034 + lVar13) = 0;
                          puVar37 = (uint *)0x0;
                          goto LAB_;
                        }
                        iVar12 = *(int *)(&stack0x000000dc + lVar13);
                      }
                      else {
                        *(undefined4 *)(&stack0x000000d8 + lVar13) = 0;
                        *(undefined4 *)(&stack0x000000dc + lVar13) = 1;
                      }
                      if ((iVar12 == 0) && ((*(byte *)((longlong)puVar31 + 6) & 0x10) != 0)) {
                        puVar5 = *(undefined4 **)(puVar31 + 2);
                        *(undefined4 *)(&stack0x00000034 + lVar13) = *puVar5;
                        puVar37 = puVar5 + 1;
                      }
                      else if ((int)*puVar31 < 0) {
                        if (*(int *)(param_2 + 2) == 0) {
                          *puVar1 = 0;
                          uVar26 = *(uint *)(param_2 + 8);
                          uVar29 = (ulonglong)uVar26;
                          *(uint *)(param_2 + 10) = uVar26;
                          pbVar41 = *(byte **)(param_2 + 4);
                          bVar9 = *pbVar41;
                          if ((bVar9 & 0x10) != 0) {
                            uVar26 = uVar26 + (*(ushort *)(pbVar41 + uVar29) + 7 >> 3) + 2;
                            uVar29 = (ulonglong)uVar26;
                            *(uint *)(param_2 + 10) = uVar26;
                            bVar9 = *pbVar41;
                          }
                          if ((bVar9 & 0x20) == 0) {
                            *(int *)(param_2 + 2) = (int)uVar29;
                            param_2[0xe] = 0;
                            *(uint *)(param_2 + 0xc) = uVar26;
                          }
                          else {
                            puVar47 = (ushort *)(pbVar41 + uVar29);
                            *(ushort **)(&stack0x00000068 + lVar13) = puVar47;
                            uVar25 = *puVar47;
                            param_2[0xe] = uVar25;
                            if (uVar25 == 0) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100524;
                              cVar8 = func_0x(0x14f8e40);
                              if (cVar8 != '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10052d;
                                lVar15 = func_0x();
                                if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100547;
                                  cVar8 = func_0x(0x14f8e40);
                                  if (cVar8 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100563;
                                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100589;
                                    (*_DAT_)(1,0xde884c,0xf08938,0x80f);
                                  }
                                }
                              }
                              uVar17 = *(undefined8 *)(param_2 + 4);
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100597;
                              func_0x(uVar17,3);
                              uVar25 = param_2[0xe];
                              uVar26 = *(uint *)(param_2 + 10);
                            }
                            uVar26 = uVar26 + (uVar25 + 1) * 2;
                            *(uint *)(param_2 + 0xc) = uVar26;
                            if (0x1f9e < uVar26) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1005c6;
                              cVar8 = func_0x(0x14f8e40);
                              if (cVar8 != '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1005cf;
                                lVar15 = func_0x();
                                if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1005e9;
                                  cVar8 = func_0x(0x14f8e40);
                                  if (cVar8 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100605;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10062b;
                                    (*_DAT_)(1,0xde884c,0xf08938,0x816);
                                  }
                                }
                              }
                              uVar17 = *(undefined8 *)(param_2 + 4);
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100639;
                              func_0x(uVar17,4);
                              uVar25 = param_2[0xe];
                              uVar26 = *(uint *)(param_2 + 0xc);
                            }
                            uVar29 = (ulonglong)uVar25;
                            uVar25 = puVar47[uVar29];
                            *(uint *)(param_2 + 2) = uVar25 & 0x7fff;
                            if ((uVar25 & 0x7fff) < uVar26) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100667;
                              cVar8 = func_0x(0x14f8e40);
                              if (cVar8 != '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100670;
                                lVar15 = func_0x();
                                if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10068a;
                                  cVar8 = func_0x(0x14f8e40);
                                  if (cVar8 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1006a6;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1006cc;
                                    (*_DAT_)(1,0xde884c,0xf08938,0x81d);
                                  }
                                }
                              }
                              uVar17 = *(undefined8 *)(param_2 + 4);
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1006da;
                              func_0x(uVar17,4);
                              uVar26 = *(uint *)(param_2 + 0xc);
                              uVar29 = (ulonglong)(ushort)param_2[0xe];
                            }
                            if ((short)uVar29 != 0) {
                              do {
                                puVar47 = puVar47 + 1;
                                uVar44 = *puVar47 & 0x7fff;
                                if ((uVar44 < uVar26) || (*(uint *)(param_2 + 2) < uVar44)) {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10071f;
                                  cVar8 = func_0x(0x14f8e40);
                                  if (cVar8 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100728;
                                    lVar15 = func_0x();
                                    if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100742;
                                      cVar8 = func_0x(0x14f8e40);
                                      if (cVar8 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10075e;
                                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100782;
                                        (*_DAT_)(1,0xde884c,0xf08938,0x82a);
                                      }
                                    }
                                  }
                                  uVar17 = *(undefined8 *)(param_2 + 4);
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100790;
                                  func_0x(uVar17,4);
                                }
                                uVar46 = (int)puVar37 + 1;
                                puVar37 = (uint *)(ulonglong)uVar46;
                                uVar29 = (ulonglong)(ushort)param_2[0xe];
                                uVar26 = uVar44;
                              } while ((int)uVar46 < (int)(uint)(ushort)param_2[0xe]);
                              puVar47 = *(ushort **)(&stack0x00000068 + lVar13);
                              uVar44 = *(uint *)(&stack0x00000028 + lVar13);
                            }
                            if ((short)puVar47[(ulonglong)((int)uVar29 - 1) + 1] < 0) {
                              do {
                                lVar15 = *(longlong *)(param_2 + 4);
                                lVar16 = (ulonglong)*(uint *)(param_2 + 10) + lVar15;
                                uVar26 = *(ushort *)(lVar16 + uVar29 * 2) & 0x7fff;
                                if ((int)uVar29 == 1) {
                                  uVar46 = *(uint *)(param_2 + 0xc);
                                  uVar27 = uVar46;
LAB_:
                                  if ((uVar26 < uVar46) || (*(uint *)(param_2 + 2) < uVar26))
                                  goto LAB_;
                                }
                                else {
                                  uVar46 = *(ushort *)(lVar16 + -2 + uVar29 * 2) & 0x7fff;
                                  uVar27 = *(uint *)(param_2 + 0xc);
                                  if (uVar27 <= uVar46) goto LAB_;
LAB_:
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10080c;
                                  func_0x(lVar15,7);
                                  uVar27 = *(uint *)(param_2 + 0xc);
                                }
                                if ((uVar46 < uVar27) || (*(uint *)(param_2 + 2) < uVar46))
                                goto LAB_;
                                if (*(ushort *)((ulonglong)uVar46 + *(longlong *)(param_2 + 4)) == 5
                                   ) {
                                  *puVar1 = *puVar1 | 2;
                                  param_2[0xe] = param_2[0xe] + -1;
                                  param_2[0x15] = (short)uVar46;
                                  uVar29 = *(ulonglong *)(param_2 + 4);
                                  uVar25 = *(ushort *)((ulonglong)(uVar46 & 0xffff) + 2 + uVar29);
                                  uVar11 = param_2[0x16] & 0xc7ff;
                                  if ((uVar25 >> 0xe & 1) != 0) {
                                    uVar11 = uVar25 & 0x3800 | uVar11;
                                  }
                                  param_2[0x16] = uVar11;
                                  uVar25 = (uVar11 ^ *(ushort *)
                                                      ((ulonglong)(uVar46 & 0xffff) + 2 + uVar29)) &
                                           0x7ff ^ uVar11;
                                  param_2[0x16] = uVar25;
                                  uVar42 = (ulonglong)(ushort)param_2[0x15];
                                  uVar38 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                                           uVar29 + (uVar11 >> 0xb & 7) * 2 + uVar42;
                                  if (uVar38 < uVar42 + uVar29) {
                                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10091d;
                                    func_0x(uVar42 + uVar29,0x19);
                                    uVar25 = param_2[0x16];
                                    uVar42 = (ulonglong)(ushort)param_2[0x15];
                                    uVar29 = (ulonglong)*(uint *)(param_2 + 4);
                                  }
                                  if (uVar26 - uVar46 <
                                      (((uVar25 & 0x7ff) * 2 - (int)uVar42) - (int)uVar29) +
                                      (int)uVar38) {
                                    lVar15 = *(longlong *)(param_2 + 4);
                                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100955;
                                    func_0x(uVar42 + lVar15,0x19);
                                    uVar25 = param_2[0x16];
                                  }
                                  if ((uVar25 & 0x3800) != 0) {
                                    puVar47 = (ushort *)
                                              (*(longlong *)(param_2 + 4) +
                                              (ulonglong)(ushort)param_2[0x15] + 4);
                                    iVar12 = 0;
                                    if ((uVar25 & 0x3800) != 0) {
                                      do {
                                        if ((uVar25 & 0x7ff) < (*puVar47 & 0x7ff)) {
                                          uVar25 = param_2[0x15];
                                          lVar15 = *(longlong *)(param_2 + 4);
                                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1009a7;
                                          func_0x((ulonglong)uVar25 + lVar15,0x1a);
                                          uVar25 = param_2[0x16];
                                        }
                                        iVar12 = iVar12 + 1;
                                        puVar47 = puVar47 + 1;
                                      } while (iVar12 < (int)(uVar25 >> 0xb & 7));
                                    }
                                  }
                                  goto LAB_;
                                }
                                if (*(ushort *)((ulonglong)uVar46 + *(longlong *)(param_2 + 4)) <
                                    0x400) goto LAB_;
                                *puVar1 = *puVar1 | 1;
                                uVar25 = param_2[0xe] - 1;
                                param_2[0xe] = uVar25;
                                if (uVar25 == 0) goto LAB_;
                                uVar29 = (ulonglong)uVar25;
                              } while ((short)puVar47[(ulonglong)(uVar25 - 1) + 1] < 0);
                              pbVar41 = *(byte **)(param_2 + 4);
                            }
                            else {
LAB_:
                              pbVar41 = *(byte **)(param_2 + 4);
                            }
                          }
                          if ((*pbVar41 & 0x40) == 0) {
                            *(undefined4 *)(param_2 + 0x13) = 0;
                          }
                          else {
                            *(int *)(param_2 + 0x13) = *(int *)(param_2 + 2);
                            *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + 0xe;
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1009f2;
                            uVar17 = func_0x(puVar1);
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100a01;
                            func_0x(uVar17,&stack0x00000230 + lVar13);
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100a0d;
                            iVar12 = func_0x(&stack0x00000230 + lVar13);
                            *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar12;
                          }
                          uVar26 = *(uint *)(param_2 + 2);
                          if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
                             (*(ulonglong *)(param_2 + 0xf) <
                              (ulonglong)uVar26 + *(longlong *)(param_2 + 4))) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100a40;
                            cVar8 = func_0x(0x14f8e40);
                            if (cVar8 != '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100a49;
                              lVar15 = func_0x();
                              if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100a63;
                                cVar8 = func_0x(0x14f8e40);
                                if (cVar8 == '\0') {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100a7f;
                                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                                }
                                else {
                                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100aa3;
                                  (*_DAT_)(1,0xde884c,0xf08938,0x886);
                                }
                              }
                            }
                            uVar17 = *(undefined8 *)(param_2 + 4);
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100ab1;
                            func_0x(uVar17,0x12);
                            uVar26 = *(uint *)(param_2 + 2);
                          }
                          if (0x3f3b < uVar26 - 1) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100aca;
                            cVar8 = func_0x(0x14f8e40);
                            if (cVar8 != '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100ad3;
                              lVar15 = func_0x();
                              if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100aed;
                                cVar8 = func_0x(0x14f8e40);
                                if (cVar8 == '\0') {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100b09;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                                }
                                else {
                                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100b2d;
                                  (*_DAT_)(1,0xde884c,0xf08938,0x88b);
                                }
                              }
                            }
                            uVar17 = *(undefined8 *)(param_2 + 4);
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100b3b;
                            func_0x(uVar17,5);
                          }
                        }
LAB_:
                        sVar10 = -*(short *)puVar31;
                        if ((*(byte *)((longlong)puVar31 + 6) & 0x10) != 0) {
                          *(undefined **)(&stack0xffffffffffffffe8 + lVar13) =
                               &stack0x00000108 + lVar13;
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100b6c;
                          func_0x(puVar1,puVar31,0,&stack0x00000218 + lVar13);
                          if (*(int *)(&stack0x00000108 + lVar13) == 0) {
                            puVar5 = *(undefined4 **)(puVar31 + 2);
                            *(undefined4 *)(&stack0x00000034 + lVar13) = *puVar5;
                            puVar37 = puVar5 + 1;
                            goto LAB_;
                          }
                        }
                        lVar15 = (longlong)sVar10;
                        if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar10) {
                          *(undefined4 *)(&stack0x00000034 + lVar13) = 0;
                          puVar37 = *(uint **)(param_2 + 4);
                        }
                        else {
                          lVar16 = *(longlong *)(param_2 + 4);
                          lVar18 = (ulonglong)*(uint *)(param_2 + 10) + lVar16;
                          if (sVar10 == 1) {
                            uVar26 = *(uint *)(*ppsVar2 + 0xc);
                            uVar46 = *(ushort *)(lVar18 + lVar15 * 2) & 0x7fff;
LAB_:
                            if ((uVar46 < uVar26) || (*(uint *)(param_2 + 2) < uVar46))
                            goto LAB_;
                          }
                          else {
                            uVar26 = *(ushort *)(lVar18 + -2 + lVar15 * 2) & 0x7fff;
                            lVar16 = *(longlong *)(param_2 + 4);
                            uVar46 = *(ushort *)(lVar18 + lVar15 * 2) & 0x7fff;
                            if (*(uint *)(*ppsVar2 + 0xc) <= uVar26) goto LAB_;
LAB_:
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100bff;
                            func_0x(lVar16,7);
                            lVar16 = *(longlong *)(param_2 + 4);
                          }
                          *(uint *)(&stack0x00000034 + lVar13) = uVar46 - uVar26;
                          puVar37 = (uint *)((ulonglong)uVar26 + lVar16);
                        }
                      }
                      else if ((*(ushort *)((longlong)puVar31 + 6) & 8) == 0) {
                        if ((*(ushort *)((longlong)puVar31 + 6) & 0x10) != 0) {
                          *(undefined **)(&stack0xffffffffffffffe8 + lVar13) =
                               &stack0x00000170 + lVar13;
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10044a;
                          func_0x(puVar1,puVar31,0,&stack0x00000214 + lVar13);
                          if (*(int *)(&stack0x00000170 + lVar13) == 0) {
                            puVar37 = *(uint **)(puVar31 + 2) + 1;
                            uVar26 = **(uint **)(puVar31 + 2);
                            if ((uVar25 != 0) && (uVar26 != uVar25)) {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10048e;
                              (*_DAT_)(1,0xf96c90,0xf955f8,0x381);
                            }
                            *(uint *)(&stack0x00000034 + lVar13) = uVar26;
                            goto LAB_;
                          }
                        }
                        *(uint *)(&stack0x00000034 + lVar13) = (uint)uVar25;
                        puVar37 = (uint *)((longlong)(int)*puVar31 + *(longlong *)(param_2 + 4));
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1004b6;
                        puVar37 = (uint *)func_0x(puVar1,puVar31);
                      }
LAB_:
                      uVar25 = *(ushort *)(*(longlong *)(puVar31 + 0x12) + 0x2a);
                      if (puVar37 != (uint *)0x0) {
                        lVar15 = *(longlong *)(&stack0x00000090 + lVar13);
                        if ((uVar25 & 0x10) != 0) {
                          lVar15 = *(longlong *)(&stack0x00000098 + lVar13);
                        }
                        *(undefined *)(lVar15 + *(longlong *)(puVar31 + 0xc)) = 0;
                        goto LAB_;
                      }
                    }
                    lVar15 = *(longlong *)(&stack0x00000090 + lVar13);
                    if ((uVar25 & 0x10) != 0) {
                      lVar15 = *(longlong *)(&stack0x00000098 + lVar13);
                    }
                    *(undefined *)(lVar15 + *(longlong *)(puVar31 + 0xc)) = 3;
                    goto LAB_;
                  }
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0xb63db0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100361;
                  (*_DAT_)(1,0xf6a140,0xf96b08,0x27d);
                  puVar37 = puVar45;
                  goto LAB_;
                }
                if (*(int *)(param_2 + 2) == 0) {
                  *puVar1 = 0;
                  uVar26 = *(uint *)(param_2 + 8);
                  uVar29 = (ulonglong)uVar26;
                  *(uint *)(param_2 + 10) = uVar26;
                  pbVar41 = *(byte **)(param_2 + 4);
                  bVar9 = *pbVar41;
                  pbVar24 = pbVar41;
                  if ((bVar9 & 0x10) != 0) {
                    uVar26 = uVar26 + (*(ushort *)(pbVar41 + uVar29) + 7 >> 3) + 2;
                    uVar29 = (ulonglong)uVar26;
                    *(uint *)(param_2 + 10) = uVar26;
                    bVar9 = *pbVar41;
                    pbVar24 = *(byte **)(param_2 + 4);
                  }
                  if ((bVar9 & 0x20) == 0) {
                    *(int *)(param_2 + 2) = (int)uVar29;
                    param_2[0xe] = 0;
                    *(uint *)(param_2 + 0xc) = uVar26;
                  }
                  else {
                    puVar47 = (ushort *)(pbVar41 + uVar29);
                    *(ushort **)(&stack0x00000068 + lVar13) = puVar47;
                    uVar25 = *puVar47;
                    param_2[0xe] = uVar25;
                    if (uVar25 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100d81;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100d8a;
                        lVar15 = func_0x();
                        if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100da4;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100dc0;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100de6;
                            (*_DAT_)(1,0xde884c,0xf08938,0x80f);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(param_2 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100df2;
                      func_0x(uVar17,3);
                      uVar25 = param_2[0xe];
                      uVar26 = *(uint *)(param_2 + 10);
                    }
                    uVar26 = uVar26 + (uVar25 + 1) * 2;
                    *(uint *)(param_2 + 0xc) = uVar26;
                    if (0x1f9e < uVar26) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100e22;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100e2b;
                        lVar15 = func_0x();
                        if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100e45;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100e61;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100e87;
                            (*_DAT_)(1,0xde884c,0xf08938,0x816);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(param_2 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100e95;
                      func_0x(uVar17,4);
                      uVar25 = param_2[0xe];
                      uVar26 = *(uint *)(param_2 + 0xc);
                    }
                    uVar29 = (ulonglong)uVar25;
                    uVar25 = puVar47[uVar29];
                    *(uint *)(param_2 + 2) = uVar25 & 0x7fff;
                    if ((uVar25 & 0x7fff) < uVar26) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100ec3;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100ecc;
                        lVar15 = func_0x();
                        if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100ee6;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100f02;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100f28;
                            (*_DAT_)(1,0xde884c,0xf08938,0x81d);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(param_2 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100f36;
                      func_0x(uVar17,4);
                      uVar26 = *(uint *)(param_2 + 0xc);
                      uVar29 = (ulonglong)(ushort)param_2[0xe];
                    }
                    if ((short)uVar29 != 0) {
                      do {
                        puVar47 = puVar47 + 1;
                        uVar44 = *puVar47 & 0x7fff;
                        if ((uVar44 < uVar26) || (*(uint *)(param_2 + 2) < uVar44)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100f7f;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 != '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100f88;
                            lVar15 = func_0x();
                            if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100fa2;
                              cVar8 = func_0x(0x14f8e40);
                              if (cVar8 == '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100fbe;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100fe2;
                                (*_DAT_)(1,0xde884c,0xf08938,0x82a);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(param_2 + 4);
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100ff0;
                          func_0x(uVar17,4);
                        }
                        uVar46 = (int)puVar37 + 1;
                        puVar37 = (uint *)(ulonglong)uVar46;
                        uVar29 = (ulonglong)(ushort)param_2[0xe];
                        uVar26 = uVar44;
                      } while ((int)uVar46 < (int)(uint)(ushort)param_2[0xe]);
                      puVar47 = *(ushort **)(&stack0x00000068 + lVar13);
                      uVar44 = *(uint *)(&stack0x00000028 + lVar13);
                    }
                    if ((short)puVar47[(ulonglong)((int)uVar29 - 1) + 1] < 0) {
                      do {
                        lVar15 = *(longlong *)(param_2 + 4);
                        uVar26 = *(ushort *)
                                  ((ulonglong)*(uint *)(param_2 + 10) + lVar15 + uVar29 * 2) &
                                 0x7fff;
                        if ((int)uVar29 == 1) {
                          uVar46 = *(uint *)(param_2 + 0xc);
                          uVar27 = uVar46;
LAB_:
                          if ((uVar26 < uVar46) || (*(uint *)(param_2 + 2) < uVar26))
                          goto LAB_;
                        }
                        else {
                          uVar46 = *(ushort *)
                                    ((ulonglong)*(uint *)(param_2 + 10) + lVar15 + -2 + uVar29 * 2)
                                   & 0x7fff;
                          uVar27 = *(uint *)(param_2 + 0xc);
                          if (uVar27 <= uVar46) goto LAB_;
LAB_:
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10106c;
                          func_0x(lVar15,7);
                          uVar27 = *(uint *)(param_2 + 0xc);
                          lVar15 = *(longlong *)(param_2 + 4);
                        }
                        if ((uVar46 < uVar27) || (*(uint *)(param_2 + 2) < uVar46))
                        goto LAB_;
                        if (*(ushort *)((ulonglong)uVar46 + lVar15) == 5) {
                          *puVar1 = *puVar1 | 2;
                          param_2[0xe] = param_2[0xe] + -1;
                          param_2[0x15] = (short)uVar46;
                          uVar29 = *(ulonglong *)(param_2 + 4);
                          uVar25 = *(ushort *)((ulonglong)(uVar46 & 0xffff) + 2 + uVar29);
                          uVar11 = param_2[0x16] & 0xc7ff;
                          if ((uVar25 >> 0xe & 1) != 0) {
                            uVar11 = uVar25 & 0x3800 | uVar11;
                          }
                          param_2[0x16] = uVar11;
                          uVar25 = (uVar11 ^ *(ushort *)((ulonglong)(uVar46 & 0xffff) + 2 + uVar29))
                                   & 0x7ff ^ uVar11;
                          param_2[0x16] = uVar25;
                          uVar42 = (ulonglong)(ushort)param_2[0x15];
                          uVar38 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                                   uVar42 + (uVar11 >> 0xb & 7) * 2 + uVar29;
                          if (uVar38 < uVar42 + uVar29) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10117e;
                            func_0x(uVar42 + uVar29,0x19);
                            uVar25 = param_2[0x16];
                            uVar42 = (ulonglong)(ushort)param_2[0x15];
                            uVar29 = (ulonglong)*(uint *)(param_2 + 4);
                          }
                          if (uVar26 - uVar46 <
                              (((uVar25 & 0x7ff) * 2 - (int)uVar42) - (int)uVar29) + (int)uVar38) {
                            lVar15 = *(longlong *)(param_2 + 4);
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1011b6;
                            func_0x(uVar42 + lVar15,0x19);
                            uVar25 = param_2[0x16];
                          }
                          if ((uVar25 & 0x3800) != 0) {
                            puVar47 = (ushort *)
                                      (*(longlong *)(param_2 + 4) +
                                      (ulonglong)(ushort)param_2[0x15] + 4);
                            iVar12 = 0;
                            if ((uVar25 & 0x3800) != 0) {
                              do {
                                if ((uVar25 & 0x7ff) < (*puVar47 & 0x7ff)) {
                                  uVar25 = param_2[0x15];
                                  lVar15 = *(longlong *)(param_2 + 4);
                                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101208;
                                  func_0x((ulonglong)uVar25 + lVar15,0x1a);
                                  uVar25 = param_2[0x16];
                                }
                                iVar12 = iVar12 + 1;
                                puVar47 = puVar47 + 1;
                              } while (iVar12 < (int)(uVar25 >> 0xb & 7));
                            }
                          }
                          goto LAB_;
                        }
                        if (*(ushort *)((ulonglong)uVar46 + lVar15) < 0x400) goto LAB_;
                        *puVar1 = *puVar1 | 1;
                        uVar25 = param_2[0xe] - 1;
                        param_2[0xe] = uVar25;
                        if (uVar25 == 0) goto LAB_;
                        uVar29 = (ulonglong)uVar25;
                      } while ((short)puVar47[(ulonglong)(uVar25 - 1) + 1] < 0);
                      pbVar24 = *(byte **)(param_2 + 4);
                    }
                    else {
LAB_:
                      pbVar24 = *(byte **)(param_2 + 4);
                    }
                  }
                  if ((*pbVar24 & 0x40) == 0) {
                    *(undefined4 *)(param_2 + 0x13) = 0;
                  }
                  else {
                    *(int *)(param_2 + 0x13) = *(int *)(param_2 + 2);
                    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + 0xe;
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101253;
                    uVar17 = func_0x(puVar1);
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101262;
                    func_0x(uVar17,&stack0x00000238 + lVar13);
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10126e;
                    iVar12 = func_0x(&stack0x00000238 + lVar13);
                    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar12;
                    pbVar24 = *(byte **)(param_2 + 4);
                  }
                  uVar26 = *(uint *)(param_2 + 2);
                  if ((*(byte **)(param_2 + 0xf) != (byte *)0x0) &&
                     (*(byte **)(param_2 + 0xf) < pbVar24 + uVar26)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1012a4;
                    cVar8 = func_0x(0x14f8e40);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1012ad;
                      lVar15 = func_0x();
                      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1012c7;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1012e3;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101307;
                          (*_DAT_)(1,0xde884c,0xf08938,0x886);
                        }
                      }
                    }
                    uVar17 = *(undefined8 *)(param_2 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101315;
                    func_0x(uVar17,0x12);
                    uVar26 = *(uint *)(param_2 + 2);
                  }
                  if (0x3f3b < uVar26 - 1) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10132e;
                    cVar8 = func_0x(0x14f8e40);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101337;
                      lVar15 = func_0x();
                      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101351;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10136d;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101391;
                          (*_DAT_)(1,0xde884c,0xf08938,0x88b);
                        }
                      }
                    }
                    uVar17 = *(undefined8 *)(param_2 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10139f;
                    func_0x(uVar17,5);
                  }
                }
LAB_:
                sVar10 = -*(short *)puVar31;
                if ((*(byte *)((longlong)puVar31 + 6) & 0x10) == 0) {
LAB_:
                  lVar15 = (longlong)sVar10;
                  if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar10) {
                    *(undefined4 *)(&stack0x00000034 + lVar13) = 0;
                    puVar37 = *(uint **)(param_2 + 4);
                    iVar12 = 0;
                  }
                  else {
                    lVar16 = *(longlong *)(param_2 + 4);
                    lVar18 = (ulonglong)*(uint *)(param_2 + 10) + lVar16;
                    if (sVar10 == 1) {
                      uVar29 = (ulonglong)*(uint *)(*ppsVar2 + 0xc);
                      uVar26 = *(ushort *)(lVar18 + lVar15 * 2) & 0x7fff;
LAB_:
                      if ((uVar26 < (uint)uVar29) || (*(uint *)(param_2 + 2) < uVar26))
                      goto LAB_;
                    }
                    else {
                      uVar46 = *(ushort *)(lVar18 + -2 + lVar15 * 2) & 0x7fff;
                      uVar29 = (ulonglong)uVar46;
                      lVar16 = *(longlong *)(param_2 + 4);
                      uVar26 = *(ushort *)(lVar18 + lVar15 * 2) & 0x7fff;
                      if (*(uint *)(*ppsVar2 + 0xc) <= uVar46) goto LAB_;
LAB_:
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10145d;
                      func_0x(lVar16,7);
                      lVar16 = *(longlong *)(param_2 + 4);
                    }
                    iVar12 = uVar26 - (int)uVar29;
                    *(int *)(&stack0x00000034 + lVar13) = iVar12;
                    puVar37 = (uint *)(uVar29 + lVar16);
                  }
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00000168 + lVar13;
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1013d0;
                  func_0x(puVar1,puVar31,0,&stack0x00000224 + lVar13);
                  if (*(int *)(&stack0x00000168 + lVar13) != 0) goto LAB_;
                  piVar19 = *(int **)(puVar31 + 2);
                  iVar12 = *piVar19;
                  *(int *)(&stack0x00000034 + lVar13) = iVar12;
                  puVar37 = (uint *)(piVar19 + 1);
                }
                if (((puVar31[0x10] & 0x2000) != 0) && (iVar12 == 0)) {
                  *(undefined4 *)(&stack0x00000034 + lVar13) = 4;
                  puVar37 = (uint *)0xb8f414;
                }
                lVar15 = *(longlong *)(&stack0x00000090 + lVar13);
                if ((*(byte *)(*(longlong *)(puVar31 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar15 = *(longlong *)(&stack0x00000098 + lVar13);
                }
                *(undefined *)(lVar15 + *(longlong *)(puVar31 + 0xc)) = 0;
                if ((1 << (**(byte **)(param_2 + 4) & 0xe) & 0x440U) != 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1014d8;
                  iVar12 = func_0x(puVar31);
                  if (iVar12 != 0) goto LAB_;
                }
                if ((uint)*(ushort *)(puVar31 + 0xf) < *(uint *)(&stack0x00000034 + lVar13)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101505;
                  (*_DAT_)(6,0x52,0x16,0x91);
                }
              }
LAB_:
              uVar26 = *(uint *)(&stack0x00000034 + lVar13);
              lVar15 = *(longlong *)(puVar31 + 0x12);
              if ((puVar31[0x10] & 0x800) == 0) {
                lVar16 = *(longlong *)(&stack0x00000090 + lVar13);
                if ((*(byte *)(lVar15 + 0x2a) & 0x10) != 0) {
                  lVar16 = *(longlong *)(&stack0x00000098 + lVar13);
                }
                lVar15 = *(longlong *)(puVar31 + 10);
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10166e;
                func_0x(lVar16 + lVar15,puVar37);
              }
              else {
                uVar25 = *(ushort *)(lVar15 + 0x2a) & 0x10;
                if (*(int *)(lVar15 + 0x10) == 10) {
                  lVar15 = *(longlong *)(&stack0x00000090 + lVar13);
                  if (uVar25 != 0) {
                    lVar15 = *(longlong *)(&stack0x00000098 + lVar13);
                  }
                  *(uint **)(lVar15 + *(longlong *)(puVar31 + 10)) = puVar37;
                }
                else {
                  lVar15 = *(longlong *)(&stack0x00000090 + lVar13);
                  if (uVar25 != 0) {
                    lVar15 = *(longlong *)(&stack0x00000098 + lVar13);
                  }
                  uVar17 = *(undefined8 *)(*(longlong *)(puVar31 + 10) + lVar15);
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1016a1;
                  func_0x(uVar17,puVar37);
                }
              }
              if ((puVar31[0x10] & 0x100) != 0) {
                lVar15 = *(longlong *)(&stack0x00000090 + lVar13);
                if ((*(byte *)(*(longlong *)(puVar31 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar15 = *(longlong *)(&stack0x00000098 + lVar13);
                }
                *(ulonglong *)(lVar15 + *(longlong *)(*(longlong *)(puVar31 + 0x12) + 0x18)) =
                     (ulonglong)uVar26;
              }
            }
LAB_:
            uVar44 = uVar44 + 1;
            *(uint *)(&stack0x00000028 + lVar13) = uVar44;
            puVar31 = puVar31 + 0x14;
            puVar33 = &stack0xffffffffffffffc8 + lVar13;
            puVar45 = puVar37;
          } while (uVar44 < *(uint *)(&stack0x00000060 + lVar13));
        }
        goto LAB_;
      }
    }
    *(short **)(&stack0x00000180 + lVar13) = param_2;
    if (*param_2 == 0) {
      *param_2 = 0;
      puVar1 = (ushort *)(param_2 + 1);
      puVar33 = &stack0xffffffffffffffc8 + lVar13;
      if (((&stack0x0000008c)[lVar13] & 0x10) != 0) {
        *(int *)(&stack0x00000060 + lVar13) = *(int *)(&stack0x00000088 + lVar13);
        puVar31 = *(uint **)(&stack0x00000080 + lVar13);
        *(uint **)(&stack0x00000050 + lVar13) = puVar31;
        uVar44 = 0;
        *(undefined4 *)(&stack0x00000028 + lVar13) = 0;
        puVar33 = &stack0xffffffffffffffc8 + lVar13;
        psVar21 = param_2;
        if (*(int *)(&stack0x00000088 + lVar13) != 0) {
LAB_:
          puVar37 = (uint *)0x0;
          switch(*(undefined *)(puVar31 + 0x10)) {
          case 0:
            goto code_r0x00103e3f;
          case 1:
            *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00000260 + lVar13;
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1017ad;
            func_0x(puVar1,puVar31,1,&stack0x00000158 + lVar13);
            if (*(int *)(&stack0x00000158 + lVar13) == 0) goto code_r0x001017c2;
          case 0xd:
          case 0x1b:
            *(undefined4 *)(&stack0x00000030 + lVar13) = 0;
            puVar45 = puVar37;
            break;
          case 2:
code_r0x001017c2:
            uVar25 = *(ushort *)(puVar31 + 0xf);
            if ((*(byte *)((longlong)puVar31 + 6) & 0x10) != 0) {
              *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00000154 + lVar13;
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1017f1;
              func_0x(puVar1,puVar31,0,&stack0x00000290 + lVar13);
              if (*(int *)(&stack0x00000154 + lVar13) == 0) {
                puVar45 = *(uint **)(puVar31 + 2) + 1;
                uVar44 = **(uint **)(puVar31 + 2);
                if ((uVar25 != 0) && (uVar44 != uVar25)) {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101831;
                  (*_DAT_)(1,0xf96c90,0xf955f8,0x381);
                }
                *(uint *)(&stack0x00000030 + lVar13) = uVar44;
                goto code_r0x00103ddb;
              }
            }
            *(uint *)(&stack0x00000030 + lVar13) = (uint)uVar25;
            puVar45 = (uint *)((longlong)(int)*puVar31 + *(longlong *)(param_2 + 4));
            break;
          case 3:
            *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00000294 + lVar13;
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10186f;
            func_0x(puVar1,puVar31,1,&stack0x00000140 + lVar13);
            if (*(int *)(&stack0x00000140 + lVar13) == 0) goto code_r0x00101884;
            *(undefined4 *)(&stack0x00000030 + lVar13) = 0;
            puVar45 = puVar37;
            break;
          case 4:
code_r0x00101884:
            if (*(int *)(param_2 + 2) == 0) {
              *puVar1 = 0;
              uVar44 = *(uint *)(param_2 + 8);
              uVar29 = (ulonglong)uVar44;
              *(uint *)(param_2 + 10) = uVar44;
              pbVar41 = *(byte **)(param_2 + 4);
              bVar9 = *pbVar41;
              pbVar24 = pbVar41;
              if ((bVar9 & 0x10) != 0) {
                uVar44 = uVar44 + (*(ushort *)(pbVar41 + uVar29) + 7 >> 3) + 2;
                uVar29 = (ulonglong)uVar44;
                *(uint *)(param_2 + 10) = uVar44;
                bVar9 = *pbVar41;
                pbVar24 = *(byte **)(param_2 + 4);
              }
              if ((bVar9 & 0x20) == 0) {
                *(int *)(param_2 + 2) = (int)uVar29;
                param_2[0xe] = 0;
                *(uint *)(param_2 + 0xc) = uVar44;
              }
              else {
                puVar47 = (ushort *)(pbVar41 + uVar29);
                uVar25 = *puVar47;
                param_2[0xe] = uVar25;
                if (uVar25 == 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1018f1;
                  cVar8 = func_0x(0x14f8e40);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1018fa;
                    lVar15 = func_0x();
                    if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101914;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101930;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101953;
                        (*_DAT_)(1,0xde884c,0xf08938,0x80f);
                      }
                    }
                  }
                  uVar17 = *(undefined8 *)(param_2 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101961;
                  func_0x(uVar17,3);
                  uVar25 = param_2[0xe];
                  uVar44 = *(uint *)(param_2 + 10);
                }
                uVar44 = uVar44 + (uVar25 + 1) * 2;
                *(uint *)(param_2 + 0xc) = uVar44;
                if (0x1f9e < uVar44) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101990;
                  cVar8 = func_0x(0x14f8e40);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101999;
                    lVar15 = func_0x();
                    if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1019b3;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1019cf;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1019f2;
                        (*_DAT_)(1,0xde884c,0xf08938,0x816);
                      }
                    }
                  }
                  uVar17 = *(undefined8 *)(param_2 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101a00;
                  func_0x(uVar17,4);
                  uVar25 = param_2[0xe];
                  uVar44 = *(uint *)(param_2 + 0xc);
                }
                uVar29 = (ulonglong)uVar25;
                uVar25 = puVar47[uVar29];
                *(uint *)(param_2 + 2) = uVar25 & 0x7fff;
                if ((uVar25 & 0x7fff) < uVar44) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101a2e;
                  cVar8 = func_0x(0x14f8e40);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101a37;
                    lVar15 = func_0x();
                    if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101a51;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101a6d;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101a90;
                        (*_DAT_)(1,0xde884c,0xf08938,0x81d);
                      }
                    }
                  }
                  uVar17 = *(undefined8 *)(param_2 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101a9e;
                  func_0x(uVar17,4);
                  uVar44 = *(uint *)(param_2 + 0xc);
                  uVar29 = (ulonglong)(ushort)param_2[0xe];
                }
                puVar7 = puVar47;
                if ((short)uVar29 != 0) {
                  do {
                    uVar26 = puVar7[1] & 0x7fff;
                    if ((uVar26 < uVar44) || (*(uint *)(param_2 + 2) < uVar26)) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101adf;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101ae8;
                        lVar15 = func_0x();
                        if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101b02;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101b1e;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101b42;
                            (*_DAT_)(1,0xde884c,0xf08938,0x82a);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(param_2 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101b50;
                      func_0x(uVar17,4);
                    }
                    uVar46 = (int)puVar37 + 1;
                    puVar37 = (uint *)(ulonglong)uVar46;
                    uVar29 = (ulonglong)(ushort)param_2[0xe];
                    puVar7 = puVar7 + 1;
                    uVar44 = uVar26;
                  } while ((int)uVar46 < (int)(uint)(ushort)param_2[0xe]);
                  puVar31 = *(uint **)(&stack0x00000050 + lVar13);
                }
                if ((short)puVar47[(ulonglong)((int)uVar29 - 1) + 1] < 0) {
                  do {
                    lVar15 = *(longlong *)(param_2 + 4);
                    psVar21 = *ppsVar2;
                    uVar44 = *(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar15 + uVar29 * 2) &
                             0x7fff;
                    if ((int)uVar29 == 1) {
                      uVar26 = *(uint *)(param_2 + 0xc);
                      uVar46 = uVar26;
code_r0x00101bba:
                      if ((uVar44 < uVar26) || (*(uint *)(param_2 + 2) < uVar44))
                      goto code_r0x00101bc3;
                    }
                    else {
                      uVar26 = *(ushort *)
                                ((ulonglong)*(uint *)(param_2 + 10) + lVar15 + -2 + uVar29 * 2) &
                               0x7fff;
                      uVar46 = *(uint *)(psVar21 + 0xc);
                      if (uVar46 <= uVar26) goto code_r0x00101bba;
code_r0x00101bc3:
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101bd0;
                      func_0x(lVar15,7);
                      uVar46 = *(uint *)(psVar21 + 0xc);
                      lVar15 = *(longlong *)(psVar21 + 4);
                    }
                    if ((uVar26 < uVar46) || (*(uint *)(param_2 + 2) < uVar26))
                    goto code_r0x00101f1c;
                    if (*(ushort *)((ulonglong)uVar26 + lVar15) == 5) {
                      *puVar1 = *puVar1 | 2;
                      param_2[0xe] = param_2[0xe] + -1;
                      param_2[0x15] = (short)uVar26;
                      uVar29 = *(ulonglong *)(param_2 + 4);
                      uVar25 = *(ushort *)((ulonglong)(uVar26 & 0xffff) + 2 + uVar29);
                      uVar11 = param_2[0x16] & 0xc7ff;
                      if ((uVar25 >> 0xe & 1) != 0) {
                        uVar11 = uVar25 & 0x3800 | uVar11;
                      }
                      param_2[0x16] = uVar11;
                      uVar25 = (uVar11 ^ *(ushort *)((ulonglong)(uVar26 & 0xffff) + 2 + uVar29)) &
                               0x7ff ^ uVar11;
                      param_2[0x16] = uVar25;
                      uVar42 = (ulonglong)(ushort)param_2[0x15];
                      uVar38 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                               uVar29 + (uVar11 >> 0xb & 7) * 2 + uVar42;
                      if (uVar38 < uVar42 + uVar29) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101cd7;
                        func_0x(uVar42 + uVar29,0x19);
                        uVar25 = param_2[0x16];
                        uVar42 = (ulonglong)(ushort)param_2[0x15];
                        uVar29 = (ulonglong)*(uint *)(param_2 + 4);
                      }
                      if (uVar44 - uVar26 <
                          (((uVar25 & 0x7ff) * 2 - (int)uVar42) - (int)uVar29) + (int)uVar38) {
                        lVar15 = *(longlong *)(param_2 + 4);
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101d0f;
                        func_0x(uVar42 + lVar15,0x19);
                        uVar25 = param_2[0x16];
                      }
                      iVar12 = 0;
                      if (((uVar25 & 0x3800) != 0) &&
                         (puVar47 = (ushort *)
                                    (*(longlong *)(param_2 + 4) + 4 +
                                    (ulonglong)(ushort)param_2[0x15]), (uVar25 & 0x3800) != 0))
                      goto code_r0x00101d50;
                      break;
                    }
                    if (*(ushort *)((ulonglong)uVar26 + lVar15) < 0x400) break;
                    *puVar1 = *puVar1 | 1;
                    uVar25 = param_2[0xe] - 1;
                    param_2[0xe] = uVar25;
                    if ((uVar25 == 0) ||
                       (uVar29 = (ulonglong)uVar25, -1 < (short)puVar47[(ulonglong)(uVar25 - 1) + 1]
                       )) break;
                  } while( true );
                }
                pbVar24 = *(byte **)(param_2 + 4);
              }
              goto code_r0x00101da3;
            }
            goto code_r0x00101f1c;
          case 5:
            puVar45 = *(uint **)(param_2 + 4);
            uVar44 = *(uint *)(param_2 + 2);
            if (uVar44 == 0) {
              *puVar1 = 0;
              uVar44 = *(uint *)(param_2 + 8);
              uVar29 = (ulonglong)uVar44;
              *(uint *)(param_2 + 10) = uVar44;
              pbVar41 = *(byte **)(param_2 + 4);
              bVar9 = *pbVar41;
              if ((bVar9 & 0x10) != 0) {
                uVar44 = uVar44 + (*(ushort *)(pbVar41 + uVar29) + 7 >> 3) + 2;
                uVar29 = (ulonglong)uVar44;
                *(uint *)(param_2 + 10) = uVar44;
                bVar9 = *pbVar41;
              }
              if ((bVar9 & 0x20) == 0) {
                *(int *)(param_2 + 2) = (int)uVar29;
                param_2[0xe] = 0;
                *(uint *)(param_2 + 0xc) = uVar44;
              }
              else {
                puVar47 = (ushort *)(pbVar41 + uVar29);
                *(ushort **)(&stack0x00000068 + lVar13) = puVar47;
                uVar25 = *puVar47;
                param_2[0xe] = uVar25;
                if (uVar25 == 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102988;
                  cVar8 = func_0x(0x14f8e40);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102991;
                    lVar15 = func_0x();
                    if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1029ab;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1029c7;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1029ea;
                        (*_DAT_)(1,0xde884c,0xf08938,0x80f);
                      }
                    }
                  }
                  uVar17 = *(undefined8 *)(param_2 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1029f8;
                  func_0x(uVar17,3);
                  uVar25 = param_2[0xe];
                  uVar44 = *(uint *)(param_2 + 10);
                }
                uVar44 = uVar44 + (uVar25 + 1) * 2;
                *(uint *)(param_2 + 0xc) = uVar44;
                if (0x1f9e < uVar44) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102a27;
                  cVar8 = func_0x(0x14f8e40);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102a30;
                    lVar15 = func_0x();
                    if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102a4a;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102a66;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102a89;
                        (*_DAT_)(1,0xde884c,0xf08938,0x816);
                      }
                    }
                  }
                  uVar17 = *(undefined8 *)(param_2 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102a97;
                  func_0x(uVar17,4);
                  uVar25 = param_2[0xe];
                  uVar44 = *(uint *)(param_2 + 0xc);
                }
                uVar29 = (ulonglong)uVar25;
                uVar25 = puVar47[uVar29];
                *(uint *)(param_2 + 2) = uVar25 & 0x7fff;
                if ((uVar25 & 0x7fff) < uVar44) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102ac5;
                  cVar8 = func_0x(0x14f8e40);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102ace;
                    lVar15 = func_0x();
                    if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102ae8;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102b04;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102b27;
                        (*_DAT_)(1,0xde884c,0xf08938,0x81d);
                      }
                    }
                  }
                  uVar17 = *(undefined8 *)(param_2 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102b35;
                  func_0x(uVar17,4);
                  uVar44 = *(uint *)(*ppsVar2 + 0xc);
                  uVar29 = (ulonglong)(ushort)param_2[0xe];
                }
                if ((short)uVar29 != 0) {
                  do {
                    puVar47 = puVar47 + 1;
                    uVar26 = *puVar47 & 0x7fff;
                    if ((uVar26 < uVar44) || (*(uint *)(param_2 + 2) < uVar26)) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102b7f;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102b88;
                        lVar15 = func_0x();
                        if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102ba2;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102bbe;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102be2;
                            (*_DAT_)(1,0xde884c,0xf08938,0x82a);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(param_2 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102bf0;
                      func_0x(uVar17,4);
                    }
                    uVar46 = (int)puVar37 + 1;
                    puVar37 = (uint *)(ulonglong)uVar46;
                    uVar29 = (ulonglong)(ushort)param_2[0xe];
                    uVar44 = uVar26;
                  } while ((int)uVar46 < (int)(uint)(ushort)param_2[0xe]);
                  puVar47 = *(ushort **)(&stack0x00000068 + lVar13);
                  puVar31 = *(uint **)(&stack0x00000050 + lVar13);
                }
                psVar21 = *ppsVar2;
                if ((short)puVar47[(ulonglong)((int)uVar29 - 1) + 1] < 0) {
code_r0x00102c30:
                  lVar15 = *(longlong *)(param_2 + 4);
                  lVar16 = (ulonglong)*(uint *)(param_2 + 10) + lVar15;
                  uVar26 = *(ushort *)(lVar16 + uVar29 * 2) & 0x7fff;
                  if ((int)uVar29 == 1) {
                    uVar46 = *(uint *)(param_2 + 0xc);
                    uVar27 = uVar46;
code_r0x00102c66:
                    if ((uVar26 < uVar46) || (uVar44 = *(uint *)(param_2 + 2), uVar44 < uVar26))
                    goto code_r0x00102c71;
                  }
                  else {
                    uVar46 = *(ushort *)(lVar16 + -2 + uVar29 * 2) & 0x7fff;
                    uVar27 = *(uint *)(psVar21 + 0xc);
                    if (uVar27 <= uVar46) goto code_r0x00102c66;
code_r0x00102c71:
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102c7e;
                    func_0x(lVar15,7);
                    psVar21 = *ppsVar2;
                    uVar27 = *(uint *)(psVar21 + 0xc);
                    uVar44 = *(uint *)(psVar21 + 2);
                  }
                  if ((uVar46 < uVar27) || (uVar44 < uVar46)) goto code_r0x00102fdd;
                  if (*(ushort *)((ulonglong)uVar46 + *(longlong *)(param_2 + 4)) == 5) {
                    *puVar1 = *puVar1 | 2;
                    param_2[0xe] = param_2[0xe] + -1;
                    param_2[0x15] = (short)uVar46;
                    uVar29 = *(ulonglong *)(param_2 + 4);
                    uVar25 = *(ushort *)((ulonglong)(uVar46 & 0xffff) + 2 + uVar29);
                    uVar11 = param_2[0x16] & 0xc7ff;
                    if ((uVar25 >> 0xe & 1) != 0) {
                      uVar11 = uVar25 & 0x3800 | uVar11;
                    }
                    param_2[0x16] = uVar11;
                    uVar25 = (uVar11 ^ *(ushort *)((ulonglong)(uVar46 & 0xffff) + 2 + uVar29)) &
                             0x7ff ^ uVar11;
                    param_2[0x16] = uVar25;
                    uVar42 = (ulonglong)(ushort)param_2[0x15];
                    uVar38 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                             uVar42 + (uVar11 >> 0xb & 7) * 2 + uVar29;
                    if (uVar38 < uVar42 + uVar29) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102d90;
                      func_0x(uVar42 + uVar29,0x19);
                      uVar25 = param_2[0x16];
                      uVar42 = (ulonglong)(ushort)param_2[0x15];
                      uVar29 = (ulonglong)*(uint *)(param_2 + 4);
                    }
                    if (uVar26 - uVar46 <
                        (((uVar25 & 0x7ff) * 2 - (int)uVar42) - (int)uVar29) + (int)uVar38) {
                      lVar15 = *(longlong *)(param_2 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102dc8;
                      func_0x(uVar42 + lVar15,0x19);
                      uVar25 = param_2[0x16];
                    }
                    iVar12 = 0;
                    if (((uVar25 & 0x3800) != 0) &&
                       (puVar47 = (ushort *)
                                  (*(longlong *)(param_2 + 4) + 4 + (ulonglong)(ushort)param_2[0x15]
                                  ), (uVar25 & 0x3800) != 0)) {
                      do {
                        if ((uVar25 & 0x7ff) < (*puVar47 & 0x7ff)) {
                          uVar25 = param_2[0x15];
                          lVar15 = *(longlong *)(param_2 + 4);
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102e27;
                          func_0x((ulonglong)uVar25 + lVar15,0x1a);
                          uVar25 = param_2[0x16];
                        }
                        iVar12 = iVar12 + 1;
                        puVar47 = puVar47 + 1;
                      } while (iVar12 < (int)(uVar25 >> 0xb & 7));
                    }
                    psVar21 = *ppsVar2;
                    pbVar41 = *(byte **)(param_2 + 4);
                    goto code_r0x00102e5c;
                  }
                  if (0x3ff < *(ushort *)((ulonglong)uVar46 + *(longlong *)(param_2 + 4)))
                  goto code_r0x00102cb6;
                }
code_r0x00102cdd:
                pbVar41 = *(byte **)(param_2 + 4);
              }
code_r0x00102e5c:
              if ((*pbVar41 & 0x40) == 0) {
                *(undefined4 *)(param_2 + 0x13) = 0;
                uVar44 = *(uint *)(psVar21 + 2);
              }
              else {
                *(int *)(param_2 + 0x13) = *(int *)(param_2 + 2);
                *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + 0xe;
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102e76;
                uVar17 = func_0x(puVar1);
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102e85;
                func_0x(uVar17,&stack0x00000250 + lVar13);
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102e91;
                iVar12 = func_0x(&stack0x00000250 + lVar13);
                *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar12;
                uVar44 = *(uint *)(param_2 + 2);
              }
              if ((*(ulonglong *)(param_2 + 0xf) == 0) ||
                 ((ulonglong)uVar44 + *(longlong *)(param_2 + 4) <= *(ulonglong *)(param_2 + 0xf)))
              {
                psVar21 = *ppsVar2;
              }
              else {
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102ec9;
                cVar8 = func_0x(0x14f8e40);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102ed2;
                  lVar15 = func_0x();
                  if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102eec;
                    cVar8 = func_0x(0x14f8e40);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102f08;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102f2b;
                      (*_DAT_)(1,0xde884c,0xf08938,0x886);
                    }
                  }
                }
                uVar17 = *(undefined8 *)(param_2 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102f39;
                func_0x(uVar17);
                psVar21 = *ppsVar2;
                uVar44 = *(uint *)(psVar21 + 2);
              }
              if ((uVar44 == 0) || (0x3f3c < uVar44)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102f62;
                cVar8 = func_0x(0x14f8e40);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102f6b;
                  lVar15 = func_0x();
                  if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102f85;
                    cVar8 = func_0x(0x14f8e40);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102fa1;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102fc7;
                      (*_DAT_)(1,0xde884c,0xf08938,0x88b);
                    }
                  }
                }
                uVar17 = *(undefined8 *)(param_2 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102fd5;
                func_0x(uVar17);
                uVar44 = *(uint *)(psVar21 + 2);
              }
            }
code_r0x00102fdd:
            if ((uVar44 < 9) &&
               (((**(byte **)(param_2 + 4) & 0xe) == 0 || ((**(byte **)(param_2 + 4) & 0xe) == 0xc))
               )) {
              uVar44 = 9;
            }
            *(uint *)(&stack0x00000030 + lVar13) = uVar44;
            goto code_r0x00103ddb;
          case 6:
          case 7:
          case 9:
          case 10:
          case 0xb:
          case 0xe:
          case 0xf:
          case 0x19:
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103013;
            func_0x(&stack0x00000178 + lVar13,puVar31,&stack0x00000078 + lVar13);
            goto LAB_;
          case 8:
            iVar12 = puVar31[0x10] << 0xc;
            uVar25 = *(ushort *)(puVar31 + 0xf);
            if ((*puVar31 & 0xc0000000) == 0x80000000) {
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1028f2;
              iVar12 = func_0x();
              if (iVar12 == 0) {
code_r0x001020cd:
                *(undefined4 *)(&stack0x00000030 + lVar13) = 0;
                puVar45 = (uint *)0x0;
              }
              else {
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102911;
                puVar45 = (uint *)func_0x(param_2 + 0x15,puVar31,&stack0x00000030 + lVar13,
                                                  &stack0x000001e0 + lVar13);
              }
              goto code_r0x00103ddb;
            }
            if ((iVar12 < 0) || ((*(byte *)((longlong)puVar31 + 6) & 0x10) != 0)) {
              *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x000000e4 + lVar13;
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1020c0;
              func_0x(puVar1,puVar31,iVar12 < 0,&stack0x000000e0 + lVar13);
              if ((iVar12 < 0) && (*(int *)(&stack0x000000e0 + lVar13) != 0)) goto code_r0x001020cd;
              iVar12 = *(int *)(&stack0x000000e4 + lVar13);
            }
            else {
              *(undefined4 *)(&stack0x000000e0 + lVar13) = 0;
              iVar12 = 1;
              *(undefined4 *)(&stack0x000000e4 + lVar13) = 1;
            }
            if ((iVar12 != 0) || ((*(byte *)((longlong)puVar31 + 6) & 0x10) == 0)) {
              if (-1 < (int)*puVar31) {
                if ((*(ushort *)((longlong)puVar31 + 6) & 8) == 0) {
                  if ((*(ushort *)((longlong)puVar31 + 6) & 0x10) != 0) {
                    *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x0000010c + lVar13;
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10212e;
                    func_0x(puVar1,puVar31,0,&stack0x000001d8 + lVar13);
                    if (*(int *)(&stack0x0000010c + lVar13) == 0) {
                      puVar45 = *(uint **)(puVar31 + 2) + 1;
                      uVar44 = **(uint **)(puVar31 + 2);
                      if ((uVar25 != 0) && (uVar44 != uVar25)) {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10216e;
                        (*_DAT_)(1,0xf96c90,0xf955f8,0x381);
                      }
                      *(uint *)(&stack0x00000030 + lVar13) = uVar44;
                      goto code_r0x00103ddb;
                    }
                  }
                  *(uint *)(&stack0x00000030 + lVar13) = (uint)uVar25;
                  puVar45 = (uint *)((longlong)(int)*puVar31 + *(longlong *)(param_2 + 4));
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102195;
                  puVar45 = (uint *)func_0x
                                              (puVar1,puVar31,&stack0x00000030 + lVar13);
                }
                goto code_r0x00103ddb;
              }
              if (*(int *)(param_2 + 2) == 0) {
                *puVar1 = 0;
                uVar44 = *(uint *)(param_2 + 8);
                uVar29 = (ulonglong)uVar44;
                *(uint *)(param_2 + 10) = uVar44;
                pbVar41 = *(byte **)(param_2 + 4);
                bVar9 = *pbVar41;
                if ((bVar9 & 0x10) != 0) {
                  uVar44 = uVar44 + (*(ushort *)(pbVar41 + uVar29) + 7 >> 3) + 2;
                  uVar29 = (ulonglong)uVar44;
                  *(uint *)(param_2 + 10) = uVar44;
                  bVar9 = *pbVar41;
                }
                if ((bVar9 & 0x20) == 0) {
                  *(int *)(param_2 + 2) = (int)uVar29;
                  param_2[0xe] = 0;
                  *(uint *)(param_2 + 0xc) = uVar44;
                }
                else {
                  puVar47 = (ushort *)(pbVar41 + uVar29);
                  uVar25 = *puVar47;
                  param_2[0xe] = uVar25;
                  if (uVar25 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102203;
                    cVar8 = func_0x(0x14f8e40);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10220c;
                      lVar15 = func_0x();
                      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102226;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102242;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102265;
                          (*_DAT_)(1,0xde884c,0xf08938,0x80f);
                        }
                      }
                    }
                    uVar17 = *(undefined8 *)(param_2 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102273;
                    func_0x(uVar17,3);
                    uVar25 = param_2[0xe];
                    uVar44 = *(uint *)(param_2 + 10);
                  }
                  uVar44 = uVar44 + (uVar25 + 1) * 2;
                  *(uint *)(param_2 + 0xc) = uVar44;
                  if (0x1f9e < uVar44) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1022a2;
                    cVar8 = func_0x(0x14f8e40);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1022ab;
                      lVar15 = func_0x();
                      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1022c5;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1022e1;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102304;
                          (*_DAT_)(1,0xde884c,0xf08938,0x816);
                        }
                      }
                    }
                    uVar17 = *(undefined8 *)(param_2 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102312;
                    func_0x(uVar17,4);
                    uVar25 = param_2[0xe];
                    uVar44 = *(uint *)(param_2 + 0xc);
                  }
                  uVar29 = (ulonglong)uVar25;
                  uVar25 = puVar47[uVar29];
                  *(uint *)(param_2 + 2) = uVar25 & 0x7fff;
                  if ((uVar25 & 0x7fff) < uVar44) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102340;
                    cVar8 = func_0x(0x14f8e40);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102349;
                      lVar15 = func_0x();
                      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102363;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10237f;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1023a2;
                          (*_DAT_)(1,0xde884c,0xf08938,0x81d);
                        }
                      }
                    }
                    uVar17 = *(undefined8 *)(param_2 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1023b0;
                    func_0x(uVar17,4);
                    uVar44 = *(uint *)(*ppsVar2 + 0xc);
                    uVar29 = (ulonglong)(ushort)param_2[0xe];
                  }
                  puVar7 = puVar47;
                  if ((short)uVar29 != 0) {
                    do {
                      uVar26 = puVar7[1] & 0x7fff;
                      if ((uVar26 < uVar44) || (*(uint *)(param_2 + 2) < uVar26)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1023f0;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 != '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1023f9;
                          lVar15 = func_0x();
                          if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102413;
                            cVar8 = func_0x(0x14f8e40);
                            if (cVar8 == '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10242f;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102453;
                              (*_DAT_)(1,0xde884c,0xf08938,0x82a);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(param_2 + 4);
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102461;
                        func_0x(uVar17,4);
                      }
                      uVar46 = (int)puVar37 + 1;
                      puVar37 = (uint *)(ulonglong)uVar46;
                      uVar29 = (ulonglong)(ushort)param_2[0xe];
                      puVar7 = puVar7 + 1;
                      uVar44 = uVar26;
                    } while ((int)uVar46 < (int)(uint)(ushort)param_2[0xe]);
                    puVar31 = *(uint **)(&stack0x00000050 + lVar13);
                  }
                  if ((short)puVar47[(ulonglong)((int)uVar29 - 1) + 1] < 0) {
                    do {
                      lVar15 = *(longlong *)(param_2 + 4);
                      lVar16 = (ulonglong)*(uint *)(param_2 + 10) + lVar15;
                      psVar21 = *ppsVar2;
                      uVar44 = *(ushort *)(lVar16 + uVar29 * 2) & 0x7fff;
                      if ((int)uVar29 == 1) {
                        uVar26 = *(uint *)(param_2 + 0xc);
                        uVar46 = uVar26;
code_r0x001024ca:
                        if ((uVar44 < uVar26) || (*(uint *)(param_2 + 2) < uVar44))
                        goto code_r0x001024d3;
                      }
                      else {
                        uVar26 = *(ushort *)(lVar16 + -2 + uVar29 * 2) & 0x7fff;
                        uVar46 = *(uint *)(psVar21 + 0xc);
                        if (uVar46 <= uVar26) goto code_r0x001024ca;
code_r0x001024d3:
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1024e0;
                        func_0x(lVar15,7);
                        uVar46 = *(uint *)(psVar21 + 0xc);
                      }
                      if ((uVar26 < uVar46) || (*(uint *)(param_2 + 2) < uVar26))
                      goto code_r0x00102829;
                      if (*(ushort *)((ulonglong)uVar26 + *(longlong *)(param_2 + 4)) == 5) {
                        *puVar1 = *puVar1 | 2;
                        param_2[0xe] = param_2[0xe] + -1;
                        param_2[0x15] = (short)uVar26;
                        uVar29 = *(ulonglong *)(param_2 + 4);
                        uVar25 = *(ushort *)((ulonglong)(uVar26 & 0xffff) + 2 + uVar29);
                        uVar11 = param_2[0x16] & 0xc7ff;
                        if ((uVar25 >> 0xe & 1) != 0) {
                          uVar11 = uVar25 & 0x3800 | uVar11;
                        }
                        param_2[0x16] = uVar11;
                        uVar25 = (uVar11 ^ *(ushort *)((ulonglong)(uVar26 & 0xffff) + 2 + uVar29)) &
                                 0x7ff ^ uVar11;
                        param_2[0x16] = uVar25;
                        uVar42 = (ulonglong)(ushort)param_2[0x15];
                        uVar38 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                                 uVar42 + (uVar11 >> 0xb & 7) * 2 + uVar29;
                        if (uVar38 < uVar42 + uVar29) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1025e6;
                          func_0x(uVar42 + uVar29,0x19);
                          uVar25 = param_2[0x16];
                          uVar42 = (ulonglong)(ushort)param_2[0x15];
                          uVar29 = (ulonglong)*(uint *)(param_2 + 4);
                        }
                        if (uVar44 - uVar26 <
                            (((uVar25 & 0x7ff) * 2 - (int)uVar42) - (int)uVar29) + (int)uVar38) {
                          lVar15 = *(longlong *)(param_2 + 4);
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10261e;
                          func_0x(uVar42 + lVar15,0x19);
                          uVar25 = param_2[0x16];
                        }
                        iVar12 = 0;
                        if (((uVar25 & 0x3800) != 0) &&
                           (puVar47 = (ushort *)
                                      (*(longlong *)(param_2 + 4) + 4 +
                                      (ulonglong)(ushort)param_2[0x15]), (uVar25 & 0x3800) != 0))
                        goto code_r0x00102660;
                        break;
                      }
                      if (*(ushort *)((ulonglong)uVar26 + *(longlong *)(param_2 + 4)) < 0x400)
                      break;
                      *puVar1 = *puVar1 | 1;
                      uVar25 = param_2[0xe] - 1;
                      param_2[0xe] = uVar25;
                      if ((uVar25 == 0) ||
                         (uVar29 = (ulonglong)uVar25,
                         -1 < (short)puVar47[(ulonglong)(uVar25 - 1) + 1])) break;
                    } while( true );
                  }
                  pbVar41 = *(byte **)(param_2 + 4);
                }
                goto code_r0x001026b3;
              }
              goto code_r0x00102829;
            }
            goto code_r0x00103dc8;
          case 0x10:
            uVar17 = *(undefined8 *)(*(longlong *)(lVar15 + 8) + 0x160);
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10302a;
            piVar19 = (int *)func_0x(uVar17,0);
            *(int **)(&stack0x00000148 + lVar13) = piVar19;
            *(undefined4 *)(&stack0x0000003c + lVar13) = 8;
            iVar12 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000058 + lVar13) + 8) + 0x100);
            if (iVar12 == 2) {
              if (*(int *)(param_2 + 2) == 0) {
                *puVar1 = 0;
                uVar44 = *(uint *)(param_2 + 8);
                uVar29 = (ulonglong)uVar44;
                *(uint *)(param_2 + 10) = uVar44;
                pbVar41 = *(byte **)(param_2 + 4);
                bVar9 = *pbVar41;
                if ((bVar9 & 0x10) != 0) {
                  uVar44 = uVar44 + (*(ushort *)(pbVar41 + uVar29) + 7 >> 3) + 2;
                  uVar29 = (ulonglong)uVar44;
                  *(uint *)(param_2 + 10) = uVar44;
                  bVar9 = *pbVar41;
                }
                if ((bVar9 & 0x20) == 0) {
                  *(int *)(param_2 + 2) = (int)uVar29;
                  param_2[0xe] = 0;
                  *(uint *)(param_2 + 0xc) = uVar44;
                }
                else {
                  puVar47 = (ushort *)(pbVar41 + uVar29);
                  *(ushort **)(&stack0x00000068 + lVar13) = puVar47;
                  uVar25 = *puVar47;
                  param_2[0xe] = uVar25;
                  if (uVar25 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1030bc;
                    cVar8 = func_0x(0x14f8e40);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1030c5;
                      lVar15 = func_0x();
                      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1030df;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1030fb;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10311e;
                          (*_DAT_)(1,0xde884c,0xf08938,0x80f);
                        }
                      }
                    }
                    uVar17 = *(undefined8 *)(param_2 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10312c;
                    func_0x(uVar17,3);
                    uVar25 = param_2[0xe];
                    uVar44 = *(uint *)(param_2 + 10);
                  }
                  uVar44 = uVar44 + (uVar25 + 1) * 2;
                  *(uint *)(param_2 + 0xc) = uVar44;
                  if (0x1f9e < uVar44) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10315b;
                    cVar8 = func_0x(0x14f8e40);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103164;
                      lVar15 = func_0x();
                      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10317e;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10319a;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1031bd;
                          (*_DAT_)(1,0xde884c,0xf08938,0x816);
                        }
                      }
                    }
                    uVar17 = *(undefined8 *)(param_2 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1031cb;
                    func_0x(uVar17,4);
                    uVar25 = param_2[0xe];
                    uVar44 = *(uint *)(param_2 + 0xc);
                  }
                  uVar29 = (ulonglong)uVar25;
                  uVar25 = puVar47[uVar29];
                  *(uint *)(param_2 + 2) = uVar25 & 0x7fff;
                  if ((uVar25 & 0x7fff) < uVar44) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1031f9;
                    cVar8 = func_0x(0x14f8e40);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103202;
                      lVar15 = func_0x();
                      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10321c;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103238;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10325b;
                          (*_DAT_)(1,0xde884c,0xf08938,0x81d);
                        }
                      }
                    }
                    uVar17 = *(undefined8 *)(param_2 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103269;
                    func_0x(uVar17,4);
                    uVar44 = *(uint *)(*ppsVar2 + 0xc);
                    uVar29 = (ulonglong)(ushort)param_2[0xe];
                  }
                  if ((short)uVar29 != 0) {
                    do {
                      puVar47 = puVar47 + 1;
                      uVar26 = *puVar47 & 0x7fff;
                      if ((uVar26 < uVar44) || (*(uint *)(param_2 + 2) < uVar26)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1032af;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 != '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1032b8;
                          lVar15 = func_0x();
                          if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1032d2;
                            cVar8 = func_0x(0x14f8e40);
                            if (cVar8 == '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1032ee;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103312;
                              (*_DAT_)(1,0xde884c,0xf08938,0x82a);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(param_2 + 4);
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103320;
                        func_0x(uVar17,4);
                      }
                      uVar46 = (int)puVar37 + 1;
                      puVar37 = (uint *)(ulonglong)uVar46;
                      uVar29 = (ulonglong)(ushort)param_2[0xe];
                      uVar44 = uVar26;
                    } while ((int)uVar46 < (int)(uint)(ushort)param_2[0xe]);
                    puVar47 = *(ushort **)(&stack0x00000068 + lVar13);
                    piVar19 = *(int **)(&stack0x00000148 + lVar13);
                  }
                  if ((short)puVar47[(ulonglong)((int)uVar29 - 1) + 1] < 0) {
                    do {
                      lVar15 = *(longlong *)(param_2 + 4);
                      lVar16 = (ulonglong)*(uint *)(param_2 + 10) + lVar15;
                      psVar21 = *ppsVar2;
                      uVar44 = *(ushort *)(lVar16 + uVar29 * 2) & 0x7fff;
                      if ((int)uVar29 == 1) {
                        uVar26 = *(uint *)(param_2 + 0xc);
                        uVar46 = uVar26;
code_r0x0010339a:
                        if ((uVar44 < uVar26) || (*(uint *)(param_2 + 2) < uVar44))
                        goto code_r0x001033a3;
                      }
                      else {
                        uVar26 = *(ushort *)(lVar16 + -2 + uVar29 * 2) & 0x7fff;
                        uVar46 = *(uint *)(psVar21 + 0xc);
                        if (uVar46 <= uVar26) goto code_r0x0010339a;
code_r0x001033a3:
                        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1033b0;
                        func_0x(lVar15,7);
                        uVar46 = *(uint *)(psVar21 + 0xc);
                      }
                      if ((uVar26 < uVar46) || (*(uint *)(param_2 + 2) < uVar26))
                      goto code_r0x001036f6;
                      if (*(ushort *)((ulonglong)uVar26 + *(longlong *)(param_2 + 4)) == 5) {
                        *puVar1 = *puVar1 | 2;
                        param_2[0xe] = param_2[0xe] + -1;
                        param_2[0x15] = (short)uVar26;
                        uVar29 = *(ulonglong *)(param_2 + 4);
                        uVar25 = *(ushort *)((ulonglong)(uVar26 & 0xffff) + 2 + uVar29);
                        uVar11 = param_2[0x16] & 0xc7ff;
                        if ((uVar25 >> 0xe & 1) != 0) {
                          uVar11 = uVar25 & 0x3800 | uVar11;
                        }
                        param_2[0x16] = uVar11;
                        uVar25 = (uVar11 ^ *(ushort *)((ulonglong)(uVar26 & 0xffff) + 2 + uVar29)) &
                                 0x7ff ^ uVar11;
                        param_2[0x16] = uVar25;
                        uVar42 = (ulonglong)(ushort)param_2[0x15];
                        uVar38 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                                 uVar42 + (uVar11 >> 0xb & 7) * 2 + uVar29;
                        if (uVar38 < uVar42 + uVar29) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1034b7;
                          func_0x(uVar42 + uVar29,0x19);
                          uVar25 = param_2[0x16];
                          uVar42 = (ulonglong)(ushort)param_2[0x15];
                          uVar29 = (ulonglong)*(uint *)(param_2 + 4);
                        }
                        if (uVar44 - uVar26 <
                            (((uVar25 & 0x7ff) * 2 - (int)uVar42) - (int)uVar29) + (int)uVar38) {
                          lVar15 = *(longlong *)(param_2 + 4);
                          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1034ef;
                          func_0x(uVar42 + lVar15,0x19);
                          uVar25 = param_2[0x16];
                        }
                        iVar12 = 0;
                        if (((uVar25 & 0x3800) != 0) &&
                           (puVar47 = (ushort *)
                                      (*(longlong *)(param_2 + 4) + 4 +
                                      (ulonglong)(ushort)param_2[0x15]), (uVar25 & 0x3800) != 0))
                        goto code_r0x00103530;
                        break;
                      }
                      if (*(ushort *)((ulonglong)uVar26 + *(longlong *)(param_2 + 4)) < 0x400)
                      break;
                      *puVar1 = *puVar1 | 1;
                      uVar25 = param_2[0xe] - 1;
                      param_2[0xe] = uVar25;
                      if ((uVar25 == 0) ||
                         (uVar29 = (ulonglong)uVar25,
                         -1 < (short)puVar47[(ulonglong)(uVar25 - 1) + 1])) break;
                    } while( true );
                  }
                  pbVar41 = *(byte **)(param_2 + 4);
                }
                goto code_r0x00103583;
              }
              goto code_r0x001036f6;
            }
            if (iVar12 == 0) {
              uVar25 = *(ushort *)(*(longlong *)(&stack0x00000050 + lVar13) + 0x3c);
              if ((*(byte *)((longlong)piVar19 + 6) & 0x10) == 0) {
code_r0x00103da7:
                puVar39 = (undefined8 *)((longlong)*piVar19 + *(longlong *)(param_2 + 4));
code_r0x00103daf:
                *(undefined8 *)((longlong)&uStackX_10 + lVar13) = *puVar39;
                puVar31 = *(uint **)(&stack0x00000050 + lVar13);
              }
              else {
                *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00000118 + lVar13;
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103d59;
                func_0x(puVar1,piVar19,0,&stack0x000001e8 + lVar13);
                if (*(int *)(&stack0x00000118 + lVar13) != 0) goto code_r0x00103da7;
                puVar39 = (undefined8 *)(*(uint **)(piVar19 + 2) + 1);
                if ((uVar25 == 0) || (**(uint **)(piVar19 + 2) == (uint)uVar25))
                goto code_r0x00103daf;
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103d97;
                (*_DAT_)(1,0xf96c90,0xf955f8,0x381);
                *(undefined8 *)((longlong)&uStackX_10 + lVar13) = *puVar39;
                puVar31 = *(uint **)(&stack0x00000050 + lVar13);
              }
              goto code_r0x00103a8c;
            }
            puVar31 = *(uint **)(&stack0x00000050 + lVar13);
            goto code_r0x00103a8f;
          }
          goto LAB_;
        }
      }
    }
    else if (*(int *)(*(longlong *)(lVar15 + 8) + 0x100) == 2) {
      uVar38 = (ulonglong)*(uint *)((longlong)plVar36 + 0x34);
      *(uint *)(&stack0x00000148 + lVar13) = *(uint *)((longlong)plVar36 + 0x34);
      uVar29 = uVar38 + 0xf;
      if (uVar29 <= uVar38) {
        uVar29 = 0xffffffffffffff0;
      }
      uVar29 = uVar29 & 0xfffffffffffffff0;
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1047a0;
      func_0x();
      lVar18 = -uVar29;
      lVar16 = (longlong)&psStackX_8 + lVar18 + lVar13;
      *(longlong *)(&stack0x00000068 + lVar13) = lVar16;
      puVar33 = &stack0xffffffffffffffc8 + lVar18 + lVar13;
      if (((ulonglong)puVar37 & 0x10) != 0) {
        *(undefined4 *)(&stack0x00000060 + lVar13) = 0;
        uVar44 = *(uint *)(&stack0x00000028 + lVar13);
        puVar33 = &stack0xffffffffffffffc8 + lVar18 + lVar13;
        if (uVar44 != 0) {
          do {
            puVar37 = (uint *)0x0;
            switch(*(undefined *)(puVar31 + 0x10)) {
            case 0:
              goto code_r0x00107244;
            case 1:
              if (*param_2 == 0) {
                *(undefined **)(&stack0xffffffffffffffe8 + lVar18 + lVar13) =
                     &stack0x000001ec + lVar13;
                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104823;
                func_0x(param_2 + 1,puVar31,1,&stack0x00000128 + lVar13);
                uVar26 = *(uint *)(&stack0x00000128 + lVar13);
                param_2 = *ppsVar2;
              }
              else {
                uVar25 = *(ushort *)(puVar31 + 1);
                if ((ushort)param_2[1] < uVar25) {
                  uVar26 = ~(uint)(*(ushort *)((longlong)puVar31 + 6) >> 4) & 1;
                }
                else {
                  bVar9 = *(byte *)((longlong)((int)(uVar25 - 1) / 2) +
                                    (ulonglong)(ushort)param_2[0xc] + *(longlong *)(param_2 + 4));
                  bVar22 = bVar9 >> 4;
                  if ((uVar25 & 1) != 0) {
                    bVar22 = bVar9 & 0xf;
                  }
                  uVar26 = (uint)(bVar22 == 0);
                }
              }
              if (uVar26 != 0) goto code_r0x001071d2;
            case 2:
              uVar25 = *(ushort *)(puVar31 + 0xf);
              if ((*(byte *)((longlong)puVar31 + 6) & 0x10) != 0) {
                *(undefined **)(&stack0xffffffffffffffe8 + lVar18 + lVar13) =
                     &stack0x0000012c + lVar13;
                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1048bc;
                func_0x(param_2 + 1,puVar31,0,&stack0x000001f0 + lVar13);
                if (*(int *)(&stack0x0000012c + lVar13) == 0) {
                  puVar45 = *(uint **)(puVar31 + 2) + 1;
                  uVar26 = **(uint **)(puVar31 + 2);
                  if ((uVar25 != 0) && (uVar26 != uVar25)) {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1048fb;
                    (*_DAT_)(1,0xf96c90,0xf955f8,0x381);
                  }
                  *(uint *)(&stack0x0000002c + lVar13) = uVar26;
                  break;
                }
              }
              *(uint *)(&stack0x0000002c + lVar13) = (uint)uVar25;
              puVar45 = (uint *)((longlong)(int)*puVar31 + *(longlong *)(param_2 + 4));
              break;
            case 3:
              if (*param_2 == 0) {
                *(undefined **)(&stack0xffffffffffffffe8 + lVar18 + lVar13) =
                     &stack0x000001f4 + lVar13;
                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10493b;
                func_0x(param_2 + 1,puVar31,1,&stack0x00000130 + lVar13);
                uVar26 = *(uint *)(&stack0x00000130 + lVar13);
                param_2 = *ppsVar2;
              }
              else {
                uVar25 = *(ushort *)(puVar31 + 1);
                if ((ushort)param_2[1] < uVar25) {
                  uVar26 = ~(uint)(*(ushort *)((longlong)puVar31 + 6) >> 4) & 1;
                }
                else {
                  bVar9 = *(byte *)((longlong)((int)(uVar25 - 1) / 2) +
                                    (ulonglong)(ushort)param_2[0xc] + *(longlong *)(param_2 + 4));
                  bVar22 = bVar9 >> 4;
                  if ((uVar25 & 1) != 0) {
                    bVar22 = bVar9 & 0xf;
                  }
                  uVar26 = (uint)(bVar22 == 0);
                }
              }
              if (uVar26 == 0) goto code_r0x001049a9;
            case 0xd:
            case 0x1b:
code_r0x001071d2:
              *(undefined4 *)(&stack0x0000002c + lVar13) = 0;
              puVar45 = puVar37;
              break;
            case 4:
code_r0x001049a9:
              puVar1 = (ushort *)(param_2 + 1);
              if (*param_2 == 0) {
                if (*(int *)(param_2 + 2) == 0) {
                  *puVar1 = 0;
                  uVar44 = *(uint *)(param_2 + 8);
                  uVar29 = (ulonglong)uVar44;
                  *(uint *)(param_2 + 10) = uVar44;
                  pbVar41 = *(byte **)(param_2 + 4);
                  bVar9 = *pbVar41;
                  if ((bVar9 & 0x10) != 0) {
                    uVar44 = uVar44 + (*(ushort *)(pbVar41 + uVar29) + 7 >> 3) + 2;
                    uVar29 = (ulonglong)uVar44;
                    *(uint *)(param_2 + 10) = uVar44;
                    bVar9 = *pbVar41;
                  }
                  if ((bVar9 & 0x20) == 0) {
                    *(int *)(param_2 + 2) = (int)uVar29;
                    param_2[0xe] = 0;
                    *(uint *)(param_2 + 0xc) = uVar44;
                  }
                  else {
                    puVar47 = (ushort *)(pbVar41 + uVar29);
                    *(ushort **)(&stack0x00000100 + lVar13) = puVar47;
                    uVar25 = *puVar47;
                    param_2[0xe] = uVar25;
                    if (uVar25 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104a25;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104a2e;
                        lVar15 = func_0x();
                        if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104a48;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104a64;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104a8a;
                            (*_DAT_)(1,0xde884c,0xf08938,0x80f);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(param_2 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104a98;
                      func_0x(uVar17,3);
                      uVar25 = param_2[0xe];
                      uVar44 = *(uint *)(param_2 + 10);
                    }
                    uVar44 = uVar44 + (uVar25 + 1) * 2;
                    *(uint *)(param_2 + 0xc) = uVar44;
                    if (0x1f9e < uVar44) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104ac7;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104ad0;
                        lVar15 = func_0x();
                        if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104aea;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104b06;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104b2c;
                            (*_DAT_)(1,0xde884c,0xf08938,0x816);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(param_2 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104b3a;
                      func_0x(uVar17,4);
                      uVar25 = param_2[0xe];
                      uVar44 = *(uint *)(param_2 + 0xc);
                    }
                    uVar29 = (ulonglong)uVar25;
                    uVar25 = puVar47[uVar29];
                    *(uint *)(param_2 + 2) = uVar25 & 0x7fff;
                    if ((uVar25 & 0x7fff) < uVar44) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104b68;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104b71;
                        lVar15 = func_0x();
                        if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104b8b;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104ba7;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104bcd;
                            (*_DAT_)(1,0xde884c,0xf08938,0x81d);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(param_2 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104bdb;
                      func_0x(uVar17,4);
                      uVar44 = *(uint *)(param_2 + 0xc);
                      uVar29 = (ulonglong)(ushort)param_2[0xe];
                    }
                    puVar45 = puVar37;
                    if ((short)uVar29 != 0) {
                      do {
                        puVar47 = puVar47 + 1;
                        uVar26 = *puVar47 & 0x7fff;
                        if ((uVar26 < uVar44) || (*(uint *)(param_2 + 2) < uVar26)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104c1f;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 != '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104c28;
                            lVar15 = func_0x();
                            if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104c42;
                              cVar8 = func_0x(0x14f8e40);
                              if (cVar8 == '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104c5e;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104c82;
                                (*_DAT_)(1,0xde884c,0xf08938,0x82a);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(param_2 + 4);
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104c90;
                          func_0x(uVar17,4);
                        }
                        uVar46 = (int)puVar45 + 1;
                        uVar29 = (ulonglong)(ushort)param_2[0xe];
                        puVar45 = (uint *)(ulonglong)uVar46;
                        uVar44 = uVar26;
                      } while ((int)uVar46 < (int)(uint)(ushort)param_2[0xe]);
                      puVar47 = *(ushort **)(&stack0x00000100 + lVar13);
                    }
                    if ((short)puVar47[(ulonglong)((int)uVar29 - 1) + 1] < 0) {
                      do {
                        lVar15 = *(longlong *)(param_2 + 4);
                        lVar16 = (ulonglong)*(uint *)(param_2 + 10) + lVar15;
                        uVar44 = *(ushort *)(lVar16 + uVar29 * 2) & 0x7fff;
                        if ((int)uVar29 == 1) {
                          uVar26 = *(uint *)(param_2 + 0xc);
                          uVar46 = uVar26;
code_r0x00104cf5:
                          if ((uVar44 < uVar26) || (*(uint *)(param_2 + 2) < uVar44))
                          goto code_r0x00104cfe;
                        }
                        else {
                          uVar26 = *(ushort *)(lVar16 + -2 + uVar29 * 2) & 0x7fff;
                          uVar46 = *(uint *)(param_2 + 0xc);
                          if (uVar46 <= uVar26) goto code_r0x00104cf5;
code_r0x00104cfe:
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104d0b;
                          func_0x(lVar15,7);
                          uVar46 = *(uint *)(param_2 + 0xc);
                        }
                        if ((uVar26 < uVar46) || (*(uint *)(param_2 + 2) < uVar26)) {
                          puVar31 = *(uint **)(&stack0x00000050 + lVar13);
                          goto code_r0x00105057;
                        }
                        if (*(ushort *)((ulonglong)uVar26 + *(longlong *)(param_2 + 4)) == 5) {
                          *puVar1 = *puVar1 | 2;
                          param_2[0xe] = param_2[0xe] + -1;
                          param_2[0x15] = (short)uVar26;
                          uVar29 = *(ulonglong *)(param_2 + 4);
                          uVar25 = *(ushort *)((ulonglong)(uVar26 & 0xffff) + 2 + uVar29);
                          uVar11 = param_2[0x16] & 0xc7ff;
                          if ((uVar25 >> 0xe & 1) != 0) {
                            uVar11 = uVar25 & 0x3800 | uVar11;
                          }
                          param_2[0x16] = uVar11;
                          uVar25 = (uVar11 ^ *(ushort *)((ulonglong)(uVar26 & 0xffff) + 2 + uVar29))
                                   & 0x7ff ^ uVar11;
                          param_2[0x16] = uVar25;
                          uVar42 = (ulonglong)(ushort)param_2[0x15];
                          uVar38 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                                   uVar42 + (uVar11 >> 0xb & 7) * 2 + uVar29;
                          if (uVar38 < uVar42 + uVar29) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104e1a;
                            func_0x(uVar42 + uVar29,0x19);
                            uVar25 = param_2[0x16];
                            uVar42 = (ulonglong)(ushort)param_2[0x15];
                            uVar29 = (ulonglong)*(uint *)(param_2 + 4);
                          }
                          if (uVar44 - uVar26 <
                              (((uVar25 & 0x7ff) * 2 - (int)uVar42) - (int)uVar29) + (int)uVar38) {
                            lVar15 = *(longlong *)(param_2 + 4);
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104e52;
                            func_0x(uVar42 + lVar15,0x19);
                            uVar25 = param_2[0x16];
                          }
                          if (((uVar25 & 0x3800) != 0) &&
                             (puVar47 = (ushort *)
                                        (*(longlong *)(param_2 + 4) + 4 +
                                        (ulonglong)(ushort)param_2[0x15]), (uVar25 & 0x3800) != 0))
                          {
                            do {
                              if ((uVar25 & 0x7ff) < (*puVar47 & 0x7ff)) {
                                uVar25 = param_2[0x15];
                                lVar15 = *(longlong *)(param_2 + 4);
                                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104ea7;
                                func_0x((ulonglong)uVar25 + lVar15,0x1a);
                                uVar25 = param_2[0x16];
                              }
                              uVar44 = (int)puVar37 + 1;
                              puVar37 = (uint *)(ulonglong)uVar44;
                              puVar47 = puVar47 + 1;
                            } while ((int)uVar44 < (int)(uVar25 >> 0xb & 7));
                          }
                          goto code_r0x00104ec2;
                        }
                        if (*(ushort *)((ulonglong)uVar26 + *(longlong *)(param_2 + 4)) < 0x400)
                        goto code_r0x00104ec2;
                        *puVar1 = *puVar1 | 1;
                        uVar25 = param_2[0xe] - 1;
                        param_2[0xe] = uVar25;
                        if (uVar25 == 0) goto code_r0x00104ec2;
                        uVar29 = (ulonglong)uVar25;
                      } while ((short)puVar47[(ulonglong)(uVar25 - 1) + 1] < 0);
                      pbVar41 = *(byte **)(param_2 + 4);
                      puVar31 = *(uint **)(&stack0x00000050 + lVar13);
                    }
                    else {
code_r0x00104ec2:
                      pbVar41 = *(byte **)(param_2 + 4);
                      puVar31 = *(uint **)(&stack0x00000050 + lVar13);
                    }
                  }
                  if ((*pbVar41 & 0x40) == 0) {
                    *(undefined4 *)(param_2 + 0x13) = 0;
                  }
                  else {
                    *(int *)(param_2 + 0x13) = *(int *)(param_2 + 2);
                    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + 0xe;
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104ef1;
                    uVar17 = func_0x(puVar1);
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104f00;
                    func_0x(uVar17,&stack0x00000268 + lVar13);
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104f0c;
                    iVar12 = func_0x(&stack0x00000268 + lVar13);
                    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar12;
                  }
                  uVar44 = *(uint *)(param_2 + 2);
                  if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
                     (*(ulonglong *)(param_2 + 0xf) < (ulonglong)uVar44 + *(longlong *)(param_2 + 4)
                     )) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104f40;
                    cVar8 = func_0x(0x14f8e40);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104f49;
                      lVar15 = func_0x();
                      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104f63;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104f7f;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104fa5;
                          (*_DAT_)(1,0xde884c,0xf08938,0x886);
                        }
                      }
                    }
                    uVar17 = *(undefined8 *)(param_2 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104fb3;
                    func_0x(uVar17,0x12);
                    uVar44 = *(uint *)(param_2 + 2);
                  }
                  if (0x3f3b < uVar44 - 1) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104fd0;
                    cVar8 = func_0x(0x14f8e40);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104fd9;
                      lVar15 = func_0x();
                      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x104ff3;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10500f;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          uVar17 = *(undefined8 *)(param_2 + 4);
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10501d;
                          func_0x(uVar17,5);
                          goto code_r0x00105057;
                        }
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105043;
                        (*_DAT_)(1,0xde884c,0xf08938,0x88b);
                      }
                    }
                    uVar17 = *(undefined8 *)(param_2 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105051;
                    func_0x(uVar17,5);
                  }
                }
code_r0x00105057:
                sVar10 = -*(short *)puVar31;
                if ((*(byte *)((longlong)puVar31 + 6) & 0x10) != 0) {
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar18 + lVar13) =
                       &stack0x00000134 + lVar13;
                  *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105086;
                  func_0x(puVar1,puVar31,0,&stack0x000001f8 + lVar13);
                  if (*(int *)(&stack0x00000134 + lVar13) == 0) {
                    puVar5 = *(undefined4 **)(puVar31 + 2);
                    *(undefined4 *)(&stack0x0000002c + lVar13) = *puVar5;
                    puVar45 = puVar5 + 1;
                    uVar44 = *(uint *)(&stack0x00000028 + lVar13);
                    psVar21 = *ppsVar2;
                    goto code_r0x001051c6;
                  }
                }
                lVar15 = (longlong)sVar10;
                if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar10) {
                  *(undefined4 *)(&stack0x0000002c + lVar13) = 0;
                  puVar45 = *(uint **)(param_2 + 4);
                  uVar44 = *(uint *)(&stack0x00000028 + lVar13);
                  psVar21 = *ppsVar2;
                }
                else {
                  lVar16 = *(longlong *)(param_2 + 4);
                  lVar20 = (ulonglong)*(uint *)(param_2 + 10) + lVar16;
                  if (sVar10 == 1) {
                    uVar44 = *(uint *)(param_2 + 0xc);
                    uVar26 = *(ushort *)(lVar20 + lVar15 * 2) & 0x7fff;
code_r0x001050ff:
                    if ((uVar26 < uVar44) || (*(uint *)(param_2 + 2) < uVar26))
                    goto code_r0x00105108;
                  }
                  else {
                    uVar44 = *(ushort *)(lVar20 + -2 + lVar15 * 2) & 0x7fff;
                    lVar16 = *(longlong *)(param_2 + 4);
                    uVar26 = *(ushort *)(lVar20 + lVar15 * 2) & 0x7fff;
                    if (*(uint *)(param_2 + 0xc) <= uVar44) goto code_r0x001050ff;
code_r0x00105108:
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105112;
                    func_0x(lVar16,7);
                    lVar16 = *(longlong *)(param_2 + 4);
                  }
                  *(uint *)(&stack0x0000002c + lVar13) = uVar26 - uVar44;
                  puVar45 = (uint *)((ulonglong)uVar44 + lVar16);
                  uVar44 = *(uint *)(&stack0x00000028 + lVar13);
                  psVar21 = *ppsVar2;
                }
              }
              else {
                *(undefined4 *)(&stack0x000000e8 + lVar13) = 0;
                *(undefined **)(&stack0xffffffffffffffe8 + lVar18 + lVar13) =
                     &stack0x000000e8 + lVar13;
                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105168;
                puVar45 = (uint *)func_0x(puVar1,puVar31,1,&stack0x0000002c + lVar13);
                psVar21 = *ppsVar2;
                if ((((*psVar21 != 0) &&
                     (plVar36 = *(longlong **)(psVar21 + 8), plVar36 != (longlong *)0x0)) &&
                    (*plVar36 != 0)) &&
                   (((*(byte *)((longlong)puVar31 + 6) & 8) == 0 &&
                    ((*(uint *)(&stack0x000000e8 + lVar13) & 1) == 0)))) {
                  *(uint *)((longlong)&uStackX_10 + lVar18 + lVar13 + -0x10) =
                       *(uint *)(&stack0x000000e8 + lVar13);
                  *(undefined **)(&stack0xfffffffffffffff8 + lVar18 + lVar13) =
                       &stack0x0000002c + lVar13;
                  *(int *)(&stack0xfffffffffffffff0 + lVar18 + lVar13) = (int)uVar38;
                  *(longlong *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = lVar16;
                  uVar48 = *(undefined4 *)(&stack0x0000002c + lVar13);
                  *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1051ba;
                  puVar45 = (uint *)func_0x(plVar36,puVar31,puVar45,uVar48);
                }
                if (puVar45 == (uint *)0x0) {
                  puVar45 = *(uint **)(psVar21 + 4);
                }
              }
code_r0x001051c6:
              if ((*(int *)(&stack0x0000002c + lVar13) == 0) && ((puVar31[0x10] & 0x2000) != 0)) {
                *(undefined4 *)(&stack0x0000002c + lVar13) = 4;
                puVar45 = (uint *)0xb8f414;
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1051ec;
              iVar12 = func_0x(psVar21);
              if (iVar12 != 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1051f8;
                iVar12 = func_0x(puVar31);
                if (iVar12 != 0) break;
              }
              if ((uint)*(ushort *)(puVar31 + 0xf) < *(uint *)(&stack0x0000002c + lVar13)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105224;
                (*_DAT_)(6,0x52,0x16,0x91);
              }
              break;
            case 5:
              puVar45 = *(uint **)(param_2 + 4);
              if (*param_2 == 0) {
                puVar1 = (ushort *)(param_2 + 1);
                uVar26 = *(uint *)(param_2 + 2);
                if (uVar26 == 0) {
                  *puVar1 = 0;
                  uVar44 = *(uint *)(param_2 + 8);
                  uVar29 = (ulonglong)uVar44;
                  *(uint *)(param_2 + 10) = uVar44;
                  pbVar41 = *(byte **)(param_2 + 4);
                  bVar9 = *pbVar41;
                  if ((bVar9 & 0x10) != 0) {
                    uVar44 = uVar44 + (*(ushort *)(pbVar41 + uVar29) + 7 >> 3) + 2;
                    uVar29 = (ulonglong)uVar44;
                    *(uint *)(param_2 + 10) = uVar44;
                    bVar9 = *pbVar41;
                  }
                  if ((bVar9 & 0x20) == 0) {
                    *(int *)(param_2 + 2) = (int)uVar29;
                    param_2[0xe] = 0;
                    *(uint *)(param_2 + 0xc) = uVar44;
                    psVar21 = param_2;
                  }
                  else {
                    puVar47 = (ushort *)(pbVar41 + uVar29);
                    *(ushort **)(&stack0x00000100 + lVar13) = puVar47;
                    uVar25 = *puVar47;
                    param_2[0xe] = uVar25;
                    if (uVar25 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105c39;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105c42;
                        lVar15 = func_0x();
                        if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105c5c;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105c78;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105c9e;
                            (*_DAT_)(1,0xde884c,0xf08938,0x80f);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(param_2 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105cac;
                      func_0x(uVar17,3);
                      uVar25 = param_2[0xe];
                      uVar44 = *(uint *)(param_2 + 10);
                    }
                    uVar44 = uVar44 + (uVar25 + 1) * 2;
                    *(uint *)(param_2 + 0xc) = uVar44;
                    if (0x1f9e < uVar44) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105cdb;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105ce4;
                        lVar15 = func_0x();
                        if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105cfe;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105d1a;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105d40;
                            (*_DAT_)(1,0xde884c,0xf08938,0x816);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(param_2 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105d4e;
                      func_0x(uVar17,4);
                      uVar25 = param_2[0xe];
                      uVar44 = *(uint *)(param_2 + 0xc);
                    }
                    uVar29 = (ulonglong)uVar25;
                    uVar25 = puVar47[uVar29];
                    *(uint *)(param_2 + 2) = uVar25 & 0x7fff;
                    if ((uVar25 & 0x7fff) < uVar44) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105d7c;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105d85;
                        lVar15 = func_0x();
                        if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105d9f;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105dbb;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105de1;
                            (*_DAT_)(1,0xde884c,0xf08938,0x81d);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(param_2 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105def;
                      func_0x(uVar17,4);
                      uVar44 = *(uint *)(param_2 + 0xc);
                      uVar29 = (ulonglong)(ushort)param_2[0xe];
                    }
                    puVar31 = puVar37;
                    if ((short)uVar29 != 0) {
                      do {
                        puVar47 = puVar47 + 1;
                        uVar26 = *puVar47 & 0x7fff;
                        if ((uVar26 < uVar44) || (*(uint *)(param_2 + 2) < uVar26)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105e2f;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 != '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105e38;
                            lVar15 = func_0x();
                            if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105e52;
                              cVar8 = func_0x(0x14f8e40);
                              if (cVar8 == '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105e6e;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105e92;
                                (*_DAT_)(1,0xde884c,0xf08938,0x82a);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(param_2 + 4);
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105ea0;
                          func_0x(uVar17,4);
                        }
                        uVar46 = (int)puVar31 + 1;
                        uVar29 = (ulonglong)(ushort)param_2[0xe];
                        puVar31 = (uint *)(ulonglong)uVar46;
                        uVar44 = uVar26;
                      } while ((int)uVar46 < (int)(uint)(ushort)param_2[0xe]);
                      puVar47 = *(ushort **)(&stack0x00000100 + lVar13);
                    }
                    psVar21 = *ppsVar2;
                    if ((short)puVar47[(ulonglong)((int)uVar29 - 1) + 1] < 0) {
                      do {
                        lVar15 = *(longlong *)(param_2 + 4);
                        lVar16 = (ulonglong)*(uint *)(param_2 + 10) + lVar15;
                        uVar44 = *(ushort *)(lVar16 + uVar29 * 2) & 0x7fff;
                        if ((int)uVar29 == 1) {
                          uVar46 = *(uint *)(param_2 + 0xc);
                          uVar27 = uVar46;
code_r0x00105f16:
                          if ((uVar44 < uVar46) ||
                             (uVar26 = *(uint *)(param_2 + 2), uVar26 < uVar44))
                          goto code_r0x00105f21;
                        }
                        else {
                          uVar46 = *(ushort *)(lVar16 + -2 + uVar29 * 2) & 0x7fff;
                          uVar27 = *(uint *)(psVar21 + 0xc);
                          if (uVar27 <= uVar46) goto code_r0x00105f16;
code_r0x00105f21:
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105f2e;
                          func_0x(lVar15,7);
                          psVar21 = *ppsVar2;
                          uVar27 = *(uint *)(psVar21 + 0xc);
                          uVar26 = *(uint *)(psVar21 + 2);
                        }
                        if ((uVar46 < uVar27) || (uVar26 < uVar46)) goto code_r0x00106286;
                        if (*(ushort *)((ulonglong)uVar46 + *(longlong *)(param_2 + 4)) == 5) {
                          *puVar1 = *puVar1 | 2;
                          param_2[0xe] = param_2[0xe] + -1;
                          param_2[0x15] = (short)uVar46;
                          uVar29 = *(ulonglong *)(param_2 + 4);
                          uVar25 = *(ushort *)((ulonglong)(uVar46 & 0xffff) + 2 + uVar29);
                          uVar11 = param_2[0x16] & 0xc7ff;
                          if ((uVar25 >> 0xe & 1) != 0) {
                            uVar11 = uVar25 & 0x3800 | uVar11;
                          }
                          param_2[0x16] = uVar11;
                          uVar25 = (uVar11 ^ *(ushort *)((ulonglong)(uVar46 & 0xffff) + 2 + uVar29))
                                   & 0x7ff ^ uVar11;
                          param_2[0x16] = uVar25;
                          uVar42 = (ulonglong)(ushort)param_2[0x15];
                          uVar38 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                                   uVar29 + (uVar11 >> 0xb & 7) * 2 + uVar42;
                          if (uVar38 < uVar42 + uVar29) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106041;
                            func_0x(uVar42 + uVar29,0x19);
                            uVar25 = param_2[0x16];
                            uVar42 = (ulonglong)(ushort)param_2[0x15];
                            uVar29 = (ulonglong)*(uint *)(param_2 + 4);
                          }
                          if (uVar44 - uVar46 <
                              (((uVar25 & 0x7ff) * 2 - (int)uVar42) - (int)uVar29) + (int)uVar38) {
                            lVar15 = *(longlong *)(param_2 + 4);
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106079;
                            func_0x(uVar42 + lVar15,0x19);
                            uVar25 = param_2[0x16];
                          }
                          if (((uVar25 & 0x3800) != 0) &&
                             (puVar47 = (ushort *)
                                        (*(longlong *)(param_2 + 4) + 4 +
                                        (ulonglong)(ushort)param_2[0x15]), (uVar25 & 0x3800) != 0))
                          {
                            do {
                              if ((uVar25 & 0x7ff) < (*puVar47 & 0x7ff)) {
                                uVar25 = param_2[0x15];
                                lVar15 = *(longlong *)(param_2 + 4);
                                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1060d7;
                                func_0x((ulonglong)uVar25 + lVar15,0x1a);
                                uVar25 = param_2[0x16];
                              }
                              uVar44 = (int)puVar37 + 1;
                              puVar37 = (uint *)(ulonglong)uVar44;
                              puVar47 = puVar47 + 1;
                            } while ((int)uVar44 < (int)(uVar25 >> 0xb & 7));
                          }
                          psVar21 = *ppsVar2;
                          goto code_r0x001060f6;
                        }
                        if (*(ushort *)((ulonglong)uVar46 + *(longlong *)(param_2 + 4)) < 0x400)
                        goto code_r0x001060f6;
                        *puVar1 = *puVar1 | 1;
                        uVar25 = param_2[0xe] - 1;
                        param_2[0xe] = uVar25;
                        if (uVar25 == 0) goto code_r0x001060f6;
                        uVar29 = (ulonglong)uVar25;
                      } while ((short)puVar47[(ulonglong)(uVar25 - 1) + 1] < 0);
                      pbVar41 = *(byte **)(param_2 + 4);
                    }
                    else {
code_r0x001060f6:
                      pbVar41 = *(byte **)(param_2 + 4);
                    }
                  }
                  if ((*pbVar41 & 0x40) == 0) {
                    *(undefined4 *)(param_2 + 0x13) = 0;
                    uVar26 = *(uint *)(psVar21 + 2);
                  }
                  else {
                    *(int *)(param_2 + 0x13) = *(int *)(param_2 + 2);
                    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + 0xe;
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106121;
                    uVar17 = func_0x(puVar1);
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106130;
                    func_0x(uVar17,&stack0x00000278 + lVar13);
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10613c;
                    iVar12 = func_0x(&stack0x00000278 + lVar13);
                    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar12;
                    uVar26 = *(uint *)(param_2 + 2);
                  }
                  if ((*(ulonglong *)(param_2 + 0xf) == 0) ||
                     ((ulonglong)uVar26 + *(longlong *)(param_2 + 4) <=
                      *(ulonglong *)(param_2 + 0xf))) {
                    psVar21 = *ppsVar2;
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106174;
                    cVar8 = func_0x(0x14f8e40);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10617d;
                      lVar15 = func_0x();
                      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106197;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1061b3;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1061d9;
                          (*_DAT_)(1,0xde884c,0xf08938,0x886);
                        }
                      }
                    }
                    uVar17 = *(undefined8 *)(param_2 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1061e7;
                    func_0x(uVar17,0x12);
                    psVar21 = *ppsVar2;
                    uVar26 = *(uint *)(psVar21 + 2);
                  }
                  if ((uVar26 == 0) || (0x3f3c < uVar26)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106210;
                    cVar8 = func_0x(0x14f8e40);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106219;
                      lVar15 = func_0x();
                      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106233;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10624f;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106275;
                          (*_DAT_)(1,0xde884c,0xf08938,0x88b);
                        }
                      }
                    }
                    uVar17 = *(undefined8 *)(param_2 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106283;
                    func_0x(uVar17,5);
                    uVar26 = *(uint *)(psVar21 + 2);
                  }
                }
code_r0x00106286:
                if ((uVar26 < 9) &&
                   (((**(byte **)(param_2 + 4) & 0xe) == 0 ||
                    ((**(byte **)(param_2 + 4) & 0xe) == 0xc)))) {
                  uVar26 = 9;
                }
                puVar31 = *(uint **)(&stack0x00000050 + lVar13);
                uVar44 = *(uint *)(&stack0x00000028 + lVar13);
                *(uint *)(&stack0x0000002c + lVar13) = uVar26;
              }
              else {
                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1062ba;
                uVar48 = func_0x(param_2 + 1);
                *(undefined4 *)(&stack0x0000002c + lVar13) = uVar48;
              }
              break;
            case 6:
            case 7:
            case 9:
            case 10:
            case 0xb:
            case 0xe:
            case 0xf:
            case 0x19:
              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1062d7;
              func_0x(&stack0x00000178 + lVar13,puVar31,&stack0x00000078 + lVar13);
              goto code_r0x00107233;
            case 8:
              iVar12 = puVar31[0x10] << 0xc;
              uVar25 = *(ushort *)(puVar31 + 0xf);
              if (*param_2 == 0) {
                puVar1 = (ushort *)(param_2 + 1);
                if ((*puVar31 & 0xc0000000) == 0x80000000) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105aff;
                  iVar12 = func_0x(puVar1);
                  if (iVar12 == 0) goto code_r0x001071d2;
                  *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105b1e;
                  puVar45 = (uint *)func_0x(param_2 + 0x15,puVar31,&stack0x0000002c + lVar13
                                                    ,&stack0x00000204 + lVar13);
                }
                else {
                  if ((iVar12 < 0) || ((*(byte *)((longlong)puVar31 + 6) & 0x10) != 0)) {
                    *(undefined **)(&stack0xffffffffffffffe8 + lVar18 + lVar13) =
                         &stack0x000000f0 + lVar13;
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1052a4;
                    func_0x(puVar1,puVar31,iVar12 < 0,&stack0x000000ec + lVar13);
                    if ((iVar12 < 0) && (*(int *)(&stack0x000000ec + lVar13) != 0))
                    goto code_r0x001071d2;
                    iVar12 = *(int *)(&stack0x000000f0 + lVar13);
                  }
                  else {
                    *(undefined4 *)(&stack0x000000ec + lVar13) = 0;
                    iVar12 = 1;
                    *(undefined4 *)(&stack0x000000f0 + lVar13) = 1;
                  }
                  if ((iVar12 == 0) && ((*(byte *)((longlong)puVar31 + 6) & 0x10) != 0)) {
                    puVar5 = *(undefined4 **)(puVar31 + 2);
                    *(undefined4 *)(&stack0x0000002c + lVar13) = *puVar5;
                    puVar45 = puVar5 + 1;
                  }
                  else if ((int)*puVar31 < 0) {
                    if (*(int *)(param_2 + 2) == 0) {
                      *puVar1 = 0;
                      uVar44 = *(uint *)(param_2 + 8);
                      uVar29 = (ulonglong)uVar44;
                      *(uint *)(param_2 + 10) = uVar44;
                      pbVar41 = *(byte **)(param_2 + 4);
                      bVar9 = *pbVar41;
                      if ((bVar9 & 0x10) != 0) {
                        uVar44 = uVar44 + (*(ushort *)(pbVar41 + uVar29) + 7 >> 3) + 2;
                        uVar29 = (ulonglong)uVar44;
                        *(uint *)(param_2 + 10) = uVar44;
                        bVar9 = *pbVar41;
                      }
                      if ((bVar9 & 0x20) == 0) {
                        *(int *)(param_2 + 2) = (int)uVar29;
                        param_2[0xe] = 0;
                        *(uint *)(param_2 + 0xc) = uVar44;
                      }
                      else {
                        puVar47 = (ushort *)(pbVar41 + uVar29);
                        uVar25 = *puVar47;
                        param_2[0xe] = uVar25;
                        if (uVar25 == 0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1053e9;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 != '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1053f2;
                            lVar15 = func_0x();
                            if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10540c;
                              cVar8 = func_0x(0x14f8e40);
                              if (cVar8 == '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105428;
                                (*_DAT_)(0x22,0x44,0x15,0x3eb);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10544c;
                                (*_DAT_)(1,0xde884c,0xf08938,0x80f);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(param_2 + 4);
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10545a;
                          func_0x(uVar17,3);
                          uVar25 = param_2[0xe];
                          uVar44 = *(uint *)(param_2 + 10);
                        }
                        uVar44 = uVar44 + (uVar25 + 1) * 2;
                        *(uint *)(param_2 + 0xc) = uVar44;
                        if (0x1f9e < uVar44) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105489;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 != '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105492;
                            lVar15 = func_0x();
                            if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1054ac;
                              cVar8 = func_0x(0x14f8e40);
                              if (cVar8 == '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1054c8;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1054ec;
                                (*_DAT_)(1,0xde884c,0xf08938,0x816);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(param_2 + 4);
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1054fa;
                          func_0x(uVar17,4);
                          uVar25 = param_2[0xe];
                          uVar44 = *(uint *)(param_2 + 0xc);
                        }
                        uVar29 = (ulonglong)uVar25;
                        uVar25 = puVar47[uVar29];
                        *(uint *)(param_2 + 2) = uVar25 & 0x7fff;
                        if ((uVar25 & 0x7fff) < uVar44) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105528;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 != '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105531;
                            lVar15 = func_0x();
                            if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10554b;
                              cVar8 = func_0x(0x14f8e40);
                              if (cVar8 == '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105567;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10558b;
                                (*_DAT_)(1,0xde884c,0xf08938,0x81d);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(param_2 + 4);
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105599;
                          func_0x(uVar17,4);
                          uVar44 = *(uint *)(param_2 + 0xc);
                          uVar29 = (ulonglong)(ushort)param_2[0xe];
                        }
                        puVar45 = puVar37;
                        puVar7 = puVar47;
                        if ((short)uVar29 != 0) {
                          do {
                            uVar26 = puVar7[1] & 0x7fff;
                            if ((uVar26 < uVar44) || (*(uint *)(param_2 + 2) < uVar26)) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1055d1;
                              cVar8 = func_0x(0x14f8e40);
                              if (cVar8 != '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1055da;
                                lVar15 = func_0x();
                                if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1055f4
                                  ;
                                  cVar8 = func_0x(0x14f8e40);
                                  if (cVar8 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) =
                                         0x105610;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) =
                                         0x105634;
                                    (*_DAT_)(1,0xde884c,0xf08938,0x82a);
                                  }
                                }
                              }
                              uVar17 = *(undefined8 *)(param_2 + 4);
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105642;
                              func_0x(uVar17,4);
                            }
                            uVar46 = (int)puVar45 + 1;
                            uVar29 = (ulonglong)(ushort)param_2[0xe];
                            puVar45 = (uint *)(ulonglong)uVar46;
                            puVar7 = puVar7 + 1;
                            uVar44 = uVar26;
                          } while ((int)uVar46 < (int)(uint)(ushort)param_2[0xe]);
                        }
                        if ((short)puVar47[(ulonglong)((int)uVar29 - 1) + 1] < 0) {
                          do {
                            lVar15 = *(longlong *)(param_2 + 4);
                            lVar16 = (ulonglong)*(uint *)(param_2 + 10) + lVar15;
                            psVar21 = *ppsVar2;
                            uVar44 = *(ushort *)(lVar16 + uVar29 * 2) & 0x7fff;
                            if ((int)uVar29 == 1) {
                              uVar26 = *(uint *)(param_2 + 0xc);
                              uVar46 = uVar26;
code_r0x001056aa:
                              if ((uVar44 < uVar26) || (*(uint *)(param_2 + 2) < uVar44))
                              goto code_r0x001056b3;
                            }
                            else {
                              uVar26 = *(ushort *)(lVar16 + -2 + uVar29 * 2) & 0x7fff;
                              uVar46 = *(uint *)(psVar21 + 0xc);
                              if (uVar46 <= uVar26) goto code_r0x001056aa;
code_r0x001056b3:
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1056c0;
                              func_0x(lVar15,7);
                              uVar46 = *(uint *)(psVar21 + 0xc);
                            }
                            if ((uVar26 < uVar46) || (*(uint *)(param_2 + 2) < uVar26)) {
                              puVar31 = *(uint **)(&stack0x00000050 + lVar13);
                              goto code_r0x00105a1e;
                            }
                            if (*(ushort *)((ulonglong)uVar26 + *(longlong *)(param_2 + 4)) == 5) {
                              *puVar1 = *puVar1 | 2;
                              param_2[0xe] = param_2[0xe] + -1;
                              param_2[0x15] = (short)uVar26;
                              uVar29 = *(ulonglong *)(param_2 + 4);
                              uVar25 = *(ushort *)((ulonglong)(uVar26 & 0xffff) + 2 + uVar29);
                              uVar11 = param_2[0x16] & 0xc7ff;
                              if ((uVar25 >> 0xe & 1) != 0) {
                                uVar11 = uVar25 & 0x3800 | uVar11;
                              }
                              param_2[0x16] = uVar11;
                              uVar25 = (uVar11 ^ *(ushort *)
                                                  ((ulonglong)(uVar26 & 0xffff) + 2 + uVar29)) &
                                       0x7ff ^ uVar11;
                              param_2[0x16] = uVar25;
                              uVar42 = (ulonglong)(ushort)param_2[0x15];
                              uVar38 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                                       uVar29 + (uVar11 >> 0xb & 7) * 2 + uVar42;
                              if (uVar38 < uVar42 + uVar29) {
                                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1057d0;
                                func_0x(uVar42 + uVar29,0x19);
                                uVar25 = param_2[0x16];
                                uVar42 = (ulonglong)(ushort)param_2[0x15];
                                uVar29 = (ulonglong)*(uint *)(param_2 + 4);
                              }
                              if (uVar44 - uVar26 <
                                  (((uVar25 & 0x7ff) * 2 - (int)uVar42) - (int)uVar29) + (int)uVar38
                                 ) {
                                lVar15 = *(longlong *)(param_2 + 4);
                                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105808;
                                func_0x(uVar42 + lVar15,0x19);
                                uVar25 = param_2[0x16];
                              }
                              if (((uVar25 & 0x3800) != 0) &&
                                 (puVar47 = (ushort *)
                                            (*(longlong *)(param_2 + 4) + 4 +
                                            (ulonglong)(ushort)param_2[0x15]),
                                 (uVar25 & 0x3800) != 0)) {
                                do {
                                  if ((uVar25 & 0x7ff) < (*puVar47 & 0x7ff)) {
                                    uVar25 = param_2[0x15];
                                    lVar15 = *(longlong *)(param_2 + 4);
                                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) =
                                         0x105867;
                                    func_0x((ulonglong)uVar25 + lVar15,0x1a);
                                    uVar25 = param_2[0x16];
                                  }
                                  uVar44 = (int)puVar37 + 1;
                                  puVar37 = (uint *)(ulonglong)uVar44;
                                  puVar47 = puVar47 + 1;
                                } while ((int)uVar44 < (int)(uVar25 >> 0xb & 7));
                              }
                              goto code_r0x00105882;
                            }
                            if (*(ushort *)((ulonglong)uVar26 + *(longlong *)(param_2 + 4)) < 0x400)
                            goto code_r0x00105882;
                            *puVar1 = *puVar1 | 1;
                            uVar25 = param_2[0xe] - 1;
                            param_2[0xe] = uVar25;
                            if (uVar25 == 0) goto code_r0x00105882;
                            uVar29 = (ulonglong)uVar25;
                          } while ((short)puVar47[(ulonglong)(uVar25 - 1) + 1] < 0);
                          pbVar41 = *(byte **)(param_2 + 4);
                          puVar31 = *(uint **)(&stack0x00000050 + lVar13);
                        }
                        else {
code_r0x00105882:
                          pbVar41 = *(byte **)(param_2 + 4);
                          puVar31 = *(uint **)(&stack0x00000050 + lVar13);
                        }
                      }
                      if ((*pbVar41 & 0x40) == 0) {
                        *(undefined4 *)(param_2 + 0x13) = 0;
                        psVar21 = *ppsVar2;
                        uVar44 = *(uint *)(psVar21 + 2);
                      }
                      else {
                        *(int *)(param_2 + 0x13) = *(int *)(param_2 + 2);
                        *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + 0xe;
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1058b1;
                        uVar17 = func_0x(puVar1);
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1058c0;
                        func_0x(uVar17,&stack0x00000270 + lVar13);
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1058cc;
                        iVar12 = func_0x(&stack0x00000270 + lVar13);
                        *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar12;
                        uVar44 = *(uint *)(param_2 + 2);
                        psVar21 = *ppsVar2;
                      }
                      if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
                         (*(ulonglong *)(param_2 + 0xf) <
                          (ulonglong)uVar44 + *(longlong *)(param_2 + 4))) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10590b;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 != '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105914;
                          lVar15 = func_0x();
                          if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10592e;
                            cVar8 = func_0x(0x14f8e40);
                            if (cVar8 == '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10594a;
                              (*_DAT_)(0x22,0x44,0x15,0x3fa);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10596e;
                              (*_DAT_)(1,0xde884c,0xf08938,0x886);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(param_2 + 4);
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10597c;
                        func_0x(uVar17,0x12);
                        uVar44 = *(uint *)(psVar21 + 2);
                      }
                      if (0x3f3b < uVar44 - 1) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105999;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 != '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1059a2;
                          lVar15 = func_0x();
                          if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1059bc;
                            cVar8 = func_0x(0x14f8e40);
                            if (cVar8 == '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1059d8;
                              (*_DAT_)(0x22,0x44,0x15,0x3ed);
                              uVar17 = *(undefined8 *)(param_2 + 4);
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1059e6;
                              func_0x(uVar17,5);
                              goto code_r0x00105a1e;
                            }
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105a0a;
                            (*_DAT_)(1,0xde884c,0xf08938,0x88b);
                          }
                        }
                        uVar17 = *(undefined8 *)(param_2 + 4);
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105a18;
                        func_0x(uVar17,5);
                      }
                    }
code_r0x00105a1e:
                    sVar10 = -*(short *)puVar31;
                    if ((*(byte *)((longlong)puVar31 + 6) & 0x10) != 0) {
                      *(undefined **)(&stack0xffffffffffffffe8 + lVar18 + lVar13) =
                           &stack0x0000013c + lVar13;
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105a4d;
                      func_0x(puVar1,puVar31,0,&stack0x00000200 + lVar13);
                      if (*(int *)(&stack0x0000013c + lVar13) == 0) {
                        puVar5 = *(undefined4 **)(puVar31 + 2);
                        *(undefined4 *)(&stack0x0000002c + lVar13) = *puVar5;
                        puVar45 = puVar5 + 1;
                        uVar44 = *(uint *)(&stack0x00000028 + lVar13);
                        break;
                      }
                    }
                    lVar15 = (longlong)sVar10;
                    if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar10) {
                      *(undefined4 *)(&stack0x0000002c + lVar13) = 0;
                      puVar45 = *(uint **)(param_2 + 4);
                      uVar44 = *(uint *)(&stack0x00000028 + lVar13);
                    }
                    else {
                      lVar16 = *(longlong *)(param_2 + 4);
                      lVar20 = (ulonglong)*(uint *)(param_2 + 10) + lVar16;
                      if (sVar10 == 1) {
                        uVar44 = *(uint *)(param_2 + 0xc);
                        uVar26 = *(ushort *)(lVar20 + lVar15 * 2) & 0x7fff;
code_r0x00105abb:
                        if ((uVar26 < uVar44) || (*(uint *)(param_2 + 2) < uVar26))
                        goto code_r0x00105ac4;
                      }
                      else {
                        uVar44 = *(ushort *)(lVar20 + -2 + lVar15 * 2) & 0x7fff;
                        uVar26 = *(ushort *)(lVar20 + lVar15 * 2) & 0x7fff;
                        lVar16 = *(longlong *)(*ppsVar2 + 4);
                        if (*(uint *)(*ppsVar2 + 0xc) <= uVar44) goto code_r0x00105abb;
code_r0x00105ac4:
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105ad1;
                        func_0x(lVar16,7);
                      }
                      *(uint *)(&stack0x0000002c + lVar13) = uVar26 - uVar44;
                      puVar45 = (uint *)((ulonglong)uVar44 + *(longlong *)(param_2 + 4));
                      uVar44 = *(uint *)(&stack0x00000028 + lVar13);
                    }
                  }
                  else if ((*(ushort *)((longlong)puVar31 + 6) & 8) == 0) {
                    if ((*(ushort *)((longlong)puVar31 + 6) & 0x10) != 0) {
                      *(undefined **)(&stack0xffffffffffffffe8 + lVar18 + lVar13) =
                           &stack0x00000138 + lVar13;
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105316;
                      func_0x(puVar1,puVar31,0,&stack0x000001fc + lVar13);
                      if (*(int *)(&stack0x00000138 + lVar13) == 0) {
                        puVar45 = *(uint **)(puVar31 + 2) + 1;
                        uVar26 = **(uint **)(puVar31 + 2);
                        if ((uVar25 != 0) && (uVar26 != uVar25)) {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105355;
                          (*_DAT_)(1,0xf96c90,0xf955f8,0x381);
                        }
                        *(uint *)(&stack0x0000002c + lVar13) = uVar26;
                        break;
                      }
                    }
                    *(uint *)(&stack0x0000002c + lVar13) = (uint)uVar25;
                    puVar45 = (uint *)((longlong)(int)*puVar31 + *(longlong *)(param_2 + 4));
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10537b;
                    puVar45 = (uint *)func_0x
                                                (puVar1,puVar31,&stack0x0000002c + lVar13);
                  }
                }
              }
              else {
                *(undefined4 *)(&stack0x000000f4 + lVar13) = 0;
                *(undefined **)(&stack0xffffffffffffffe8 + lVar18 + lVar13) =
                     &stack0x000000f4 + lVar13;
                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105b49;
                puVar45 = (uint *)func_0x(param_2 + 1,puVar31,iVar12 < 0,
                                                  &stack0x0000002c + lVar13);
                if ((((**ppsVar2 != 0) &&
                     (plVar36 = *(longlong **)(*ppsVar2 + 8), plVar36 != (longlong *)0x0)) &&
                    (*plVar36 != 0)) &&
                   (((*(byte *)((longlong)puVar31 + 6) & 8) == 0 &&
                    ((*(uint *)(&stack0x000000f4 + lVar13) & 1) == 0)))) {
                  *(uint *)((longlong)&uStackX_10 + lVar18 + lVar13 + -0x10) =
                       *(uint *)(&stack0x000000f4 + lVar13);
                  *(undefined **)(&stack0xfffffffffffffff8 + lVar18 + lVar13) =
                       &stack0x0000002c + lVar13;
                  *(undefined4 *)(&stack0xfffffffffffffff0 + lVar18 + lVar13) = 0;
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                  uVar48 = *(undefined4 *)(&stack0x0000002c + lVar13);
                  *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x105bb0;
                  puVar45 = (uint *)func_0x(plVar36,puVar31,puVar45,uVar48);
                }
              }
              break;
            case 0x10:
              uVar17 = *(undefined8 *)(*(longlong *)(lVar15 + 8) + 0x160);
              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1062ee;
              piVar19 = (int *)func_0x(uVar17,0);
              *(int **)(&stack0x00000280 + lVar13) = piVar19;
              *(undefined4 *)(&stack0x00000044 + lVar13) = 0;
              *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
              iVar12 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000058 + lVar13) + 8) + 0x100)
              ;
              if (iVar12 == 2) {
                psVar21 = *ppsVar2;
                if (*psVar21 == 0) {
                  puVar1 = (ushort *)(psVar21 + 1);
                  if (*(int *)(psVar21 + 2) == 0) {
                    iVar12 = 0;
                    *puVar1 = 0;
                    uVar44 = *(uint *)(psVar21 + 8);
                    uVar29 = (ulonglong)uVar44;
                    *(uint *)(psVar21 + 10) = uVar44;
                    pbVar41 = *(byte **)(psVar21 + 4);
                    bVar9 = *pbVar41;
                    if ((bVar9 & 0x10) != 0) {
                      uVar44 = uVar44 + 2 + (*(ushort *)(pbVar41 + uVar29) + 7 >> 3);
                      uVar29 = (ulonglong)uVar44;
                      *(uint *)(psVar21 + 10) = uVar44;
                      bVar9 = *pbVar41;
                    }
                    psVar34 = psVar21;
                    if ((bVar9 & 0x20) == 0) {
                      *(int *)(psVar21 + 2) = (int)uVar29;
                      psVar21[0xe] = 0;
                      *(uint *)(psVar21 + 0xc) = uVar44;
                    }
                    else {
                      puVar47 = (ushort *)(pbVar41 + uVar29);
                      *(ushort **)(&stack0x00000100 + lVar13) = puVar47;
                      uVar25 = *puVar47;
                      psVar21[0xe] = uVar25;
                      if (uVar25 == 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10639d;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 != '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1063a6;
                          lVar15 = func_0x();
                          if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1063c0;
                            cVar8 = func_0x(0x14f8e40);
                            if (cVar8 == '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1063dc;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106402;
                              (*_DAT_)(1,0xde884c,0xf08938,0x80f);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(psVar21 + 4);
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106410;
                        func_0x(uVar17,3);
                        uVar25 = psVar21[0xe];
                        uVar44 = *(uint *)(psVar21 + 10);
                      }
                      uVar44 = uVar44 + (uVar25 + 1) * 2;
                      *(uint *)(psVar21 + 0xc) = uVar44;
                      if (0x1f9e < uVar44) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10643f;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 != '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106448;
                          lVar15 = func_0x();
                          if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106462;
                            cVar8 = func_0x(0x14f8e40);
                            if (cVar8 == '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10647e;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1064a4;
                              (*_DAT_)(1,0xde884c,0xf08938,0x816);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(psVar21 + 4);
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1064b2;
                        func_0x(uVar17,4);
                        uVar25 = psVar21[0xe];
                        uVar44 = *(uint *)(psVar21 + 0xc);
                      }
                      uVar29 = (ulonglong)uVar25;
                      uVar25 = puVar47[uVar29];
                      *(uint *)(psVar21 + 2) = uVar25 & 0x7fff;
                      if ((uVar25 & 0x7fff) < uVar44) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1064e0;
                        cVar8 = func_0x(0x14f8e40);
                        if (cVar8 != '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1064e9;
                          lVar15 = func_0x();
                          if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106503;
                            cVar8 = func_0x(0x14f8e40);
                            if (cVar8 == '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10651f;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106545;
                              (*_DAT_)(1,0xde884c,0xf08938,0x81d);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(psVar21 + 4);
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106553;
                        func_0x(uVar17,4);
                        uVar44 = *(uint *)(psVar21 + 0xc);
                        uVar29 = (ulonglong)(ushort)psVar21[0xe];
                      }
                      if ((short)uVar29 != 0) {
                        do {
                          puVar47 = puVar47 + 1;
                          uVar26 = *puVar47 & 0x7fff;
                          if ((uVar26 < uVar44) || (*(uint *)(psVar21 + 2) < uVar26)) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10659f;
                            cVar8 = func_0x(0x14f8e40);
                            if (cVar8 != '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1065a8;
                              lVar15 = func_0x();
                              if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1065c2;
                                cVar8 = func_0x(0x14f8e40);
                                if (cVar8 == '\0') {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1065de
                                  ;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                                  *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106602
                                  ;
                                  (*_DAT_)(1,0xde884c,0xf08938,0x82a);
                                }
                              }
                            }
                            uVar17 = *(undefined8 *)(psVar21 + 4);
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106610;
                            func_0x(uVar17,4);
                          }
                          iVar12 = iVar12 + 1;
                          uVar29 = (ulonglong)(ushort)psVar21[0xe];
                          uVar44 = uVar26;
                        } while (iVar12 < (int)(uint)(ushort)psVar21[0xe]);
                        puVar47 = *(ushort **)(&stack0x00000100 + lVar13);
                        piVar19 = *(int **)(&stack0x00000280 + lVar13);
                        psVar34 = *ppsVar2;
                      }
                      if ((short)puVar47[(ulonglong)((int)uVar29 - 1) + 1] < 0) {
                        do {
                          lVar15 = *(longlong *)(psVar21 + 4);
                          lVar16 = (ulonglong)*(uint *)(psVar21 + 10) + lVar15;
                          if ((int)uVar29 == 1) {
                            uVar44 = *(uint *)(psVar21 + 0xc);
                            uVar38 = (ulonglong)uVar44;
                            uVar26 = *(ushort *)(lVar16 + uVar29 * 2) & 0x7fff;
code_r0x0010668f:
                            if ((uVar26 < (uint)uVar38) || (*(uint *)(psVar21 + 2) < uVar26))
                            goto code_r0x00106698;
                          }
                          else {
                            uVar46 = *(ushort *)(lVar16 + -2 + uVar29 * 2) & 0x7fff;
                            uVar38 = (ulonglong)uVar46;
                            uVar44 = *(uint *)(psVar34 + 0xc);
                            uVar26 = *(ushort *)(lVar16 + uVar29 * 2) & 0x7fff;
                            if (uVar44 <= uVar46) goto code_r0x0010668f;
code_r0x00106698:
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1066a5;
                            func_0x(lVar15,7);
                            uVar44 = *(uint *)(*ppsVar2 + 0xc);
                          }
                          uVar46 = (uint)uVar38;
                          if ((uVar46 < uVar44) || (*(uint *)(psVar21 + 2) < uVar46))
                          goto code_r0x001069e2;
                          if (*(ushort *)(uVar38 + *(longlong *)(psVar21 + 4)) == 5) {
                            *puVar1 = *puVar1 | 2;
                            psVar21[0xe] = psVar21[0xe] + -1;
                            psVar21[0x15] = (short)uVar38;
                            uVar29 = *(ulonglong *)(psVar21 + 4);
                            uVar25 = *(ushort *)((uVar38 & 0xffff) + 2 + uVar29);
                            uVar11 = psVar21[0x16] & 0xc7ff;
                            if ((uVar25 >> 0xe & 1) != 0) {
                              uVar11 = uVar25 & 0x3800 | uVar11;
                            }
                            psVar21[0x16] = uVar11;
                            uVar25 = (uVar11 ^ *(ushort *)((uVar38 & 0xffff) + 2 + uVar29)) & 0x7ff
                                     ^ uVar11;
                            psVar21[0x16] = uVar25;
                            uVar42 = (ulonglong)(ushort)psVar21[0x15];
                            uVar38 = uVar29 + 4 +
                                     (ulonglong)((uVar25 & 0x7ff) * 2) +
                                     uVar42 + (uVar11 >> 0xb & 7) * 2;
                            if (uVar38 < uVar42 + uVar29) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1067ba;
                              func_0x(uVar42 + uVar29,0x19);
                              uVar25 = psVar21[0x16];
                              uVar42 = (ulonglong)(ushort)psVar21[0x15];
                              uVar29 = (ulonglong)*(uint *)(psVar21 + 4);
                            }
                            if (uVar26 - uVar46 <
                                (((uVar25 & 0x7ff) * 2 - (int)uVar42) - (int)uVar29) + (int)uVar38)
                            {
                              lVar15 = *(longlong *)(psVar21 + 4);
                              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1067f2;
                              func_0x(uVar42 + lVar15,0x19);
                              uVar25 = psVar21[0x16];
                            }
                            if ((uVar25 & 0x3800) != 0) {
                              puVar47 = (ushort *)
                                        (*(longlong *)(psVar21 + 4) +
                                        (ulonglong)(ushort)psVar21[0x15] + 4);
                              iVar12 = 0;
                              if ((uVar25 & 0x3800) != 0) {
                                do {
                                  if ((uVar25 & 0x7ff) < (*puVar47 & 0x7ff)) {
                                    uVar25 = psVar21[0x15];
                                    lVar15 = *(longlong *)(psVar21 + 4);
                                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) =
                                         0x106847;
                                    func_0x((ulonglong)uVar25 + lVar15,0x1a);
                                    uVar25 = psVar21[0x16];
                                  }
                                  iVar12 = iVar12 + 1;
                                  puVar47 = puVar47 + 1;
                                } while (iVar12 < (int)(uVar25 >> 0xb & 7));
                              }
                            }
                            goto code_r0x00106862;
                          }
                          if (*(ushort *)(uVar38 + *(longlong *)(psVar21 + 4)) < 0x400)
                          goto code_r0x00106862;
                          *puVar1 = *puVar1 | 1;
                          uVar25 = psVar21[0xe] - 1;
                          psVar21[0xe] = uVar25;
                          if (uVar25 == 0) goto code_r0x00106862;
                          uVar29 = (ulonglong)uVar25;
                          psVar34 = *ppsVar2;
                        } while ((short)puVar47[(ulonglong)(uVar25 - 1) + 1] < 0);
                        pbVar41 = *(byte **)(psVar21 + 4);
                      }
                      else {
code_r0x00106862:
                        pbVar41 = *(byte **)(psVar21 + 4);
                        psVar34 = *ppsVar2;
                      }
                    }
                    if ((*pbVar41 & 0x40) == 0) {
                      *(undefined4 *)(psVar21 + 0x13) = 0;
                      uVar44 = *(uint *)(psVar34 + 2);
                    }
                    else {
                      *(int *)(psVar21 + 0x13) = *(int *)(psVar21 + 2);
                      *(int *)(psVar21 + 2) = *(int *)(psVar21 + 2) + 0xe;
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106892;
                      uVar17 = func_0x(puVar1);
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1068a1;
                      func_0x(uVar17,&stack0x00000288 + lVar13);
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1068ad;
                      iVar12 = func_0x(&stack0x00000288 + lVar13);
                      *(int *)(psVar21 + 2) = *(int *)(psVar21 + 2) + iVar12;
                      uVar44 = *(uint *)(psVar21 + 2);
                    }
                    if ((*(ulonglong *)(psVar21 + 0xf) != 0) &&
                       (*(ulonglong *)(psVar21 + 0xf) <
                        (ulonglong)uVar44 + *(longlong *)(psVar21 + 4))) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1068e3;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1068ec;
                        lVar15 = func_0x();
                        if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106906;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106922;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106948;
                            (*_DAT_)(1,0xde884c,0xf08938,0x886);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(psVar21 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106956;
                      func_0x(uVar17,0x12);
                      uVar44 = *(uint *)(psVar34 + 2);
                    }
                    if (0x3f3b < uVar44 - 1) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10696f;
                      cVar8 = func_0x(0x14f8e40);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106978;
                        lVar15 = func_0x();
                        if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106992;
                          cVar8 = func_0x(0x14f8e40);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1069ae;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1069d4;
                            (*_DAT_)(1,0xde884c,0xf08938,0x88b);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(psVar21 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1069e2;
                      func_0x(uVar17,5);
                    }
                  }
code_r0x001069e2:
                  sVar10 = -*(short *)piVar19;
                  if ((*(byte *)((longlong)piVar19 + 6) & 0x10) != 0) {
                    *(undefined **)(&stack0xffffffffffffffe8 + lVar18 + lVar13) =
                         &stack0x00000174 + lVar13;
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106a13;
                    func_0x(puVar1,piVar19,0,&stack0x00000208 + lVar13);
                    if (*(int *)(&stack0x00000174 + lVar13) == 0) {
                      piVar19 = *(int **)(piVar19 + 2);
                      iVar12 = *piVar19;
                      *(int *)(&stack0x00000044 + lVar13) = iVar12;
                      puVar43 = (ulonglong *)(piVar19 + 1);
                      puVar31 = *(uint **)(&stack0x00000050 + lVar13);
                      uVar44 = *(uint *)(&stack0x00000028 + lVar13);
                      goto code_r0x00106b5d;
                    }
                  }
                  lVar15 = (longlong)sVar10;
                  if ((uint)(ushort)psVar21[0xe] < (uint)(int)sVar10) {
                    iVar12 = 0;
                    *(undefined4 *)(&stack0x00000044 + lVar13) = 0;
                    puVar43 = *(ulonglong **)(psVar21 + 4);
                    puVar31 = *(uint **)(&stack0x00000050 + lVar13);
                    uVar44 = *(uint *)(&stack0x00000028 + lVar13);
                  }
                  else {
                    lVar16 = *(longlong *)(psVar21 + 4);
                    lVar20 = (ulonglong)*(uint *)(psVar21 + 10) + lVar16;
                    if (sVar10 == 1) {
                      uVar44 = *(uint *)(psVar21 + 0xc);
                      uVar26 = *(ushort *)(lVar20 + lVar15 * 2) & 0x7fff;
code_r0x00106a88:
                      if ((uVar26 < uVar44) || (*(uint *)(psVar21 + 2) < uVar26))
                      goto code_r0x00106a91;
                    }
                    else {
                      uVar44 = *(ushort *)(lVar20 + -2 + lVar15 * 2) & 0x7fff;
                      uVar26 = *(ushort *)(lVar20 + lVar15 * 2) & 0x7fff;
                      lVar16 = *(longlong *)(*ppsVar2 + 4);
                      if (*(uint *)(*ppsVar2 + 0xc) <= uVar44) goto code_r0x00106a88;
code_r0x00106a91:
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106a9e;
                      func_0x(lVar16,7);
                    }
                    iVar12 = uVar26 - uVar44;
                    *(int *)(&stack0x00000044 + lVar13) = iVar12;
                    puVar43 = (ulonglong *)((ulonglong)uVar44 + *(longlong *)(psVar21 + 4));
                    puVar31 = *(uint **)(&stack0x00000050 + lVar13);
                    uVar44 = *(uint *)(&stack0x00000028 + lVar13);
                  }
                }
                else {
                  *(undefined4 *)(&stack0x000000f8 + lVar13) = 0;
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar18 + lVar13) =
                       &stack0x000000f8 + lVar13;
                  *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106af9;
                  puVar43 = (ulonglong *)
                            func_0x(psVar21 + 1,piVar19,1,&stack0x00000044 + lVar13);
                  psVar21 = *ppsVar2;
                  if ((((*psVar21 != 0) &&
                       (plVar36 = *(longlong **)(psVar21 + 8), plVar36 != (longlong *)0x0)) &&
                      (*plVar36 != 0)) && ((*(byte *)((longlong)piVar19 + 6) & 8) == 0)) {
                    if ((*(uint *)(&stack0x000000f8 + lVar13) & 1) == 0) {
                      *(uint *)((longlong)&uStackX_10 + lVar18 + lVar13 + -0x10) =
                           *(uint *)(&stack0x000000f8 + lVar13);
                      *(undefined **)(&stack0xfffffffffffffff8 + lVar18 + lVar13) =
                           &stack0x00000044 + lVar13;
                      *(int *)(&stack0xfffffffffffffff0 + lVar18 + lVar13) = (int)uVar38;
                      *(longlong *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = lVar16;
                      uVar48 = *(undefined4 *)(&stack0x00000044 + lVar13);
                      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106b4a;
                      puVar43 = (ulonglong *)func_0x(plVar36,piVar19,puVar43,uVar48)
                      ;
                    }
                    psVar21 = *ppsVar2;
                  }
                  iVar12 = *(int *)(&stack0x00000044 + lVar13);
                  if (puVar43 == (ulonglong *)0x0) {
                    puVar43 = *(ulonglong **)(psVar21 + 4);
                  }
                }
code_r0x00106b5d:
                bVar9 = *(byte *)((longlong)puVar31 + 0x45);
                bVar22 = *(byte *)(puVar31 + 0x11);
                switch(*(undefined *)((longlong)puVar31 + 0x3e)) {
                case 0x30:
                  if (iVar12 == 0) {
                    *(undefined *)((longlong)&uStackX_10 + lVar13 + 8) = 0;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 1;
                  }
                  else {
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 8) = *(byte *)puVar43;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 1;
                  }
                  break;
                case 0x34:
                  if (iVar12 == 0) {
                    *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 8) = 0;
code_r0x00106cc0:
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 2;
                  }
                  else if (iVar12 == 1) {
                    *(ushort *)((longlong)&uStackX_10 + lVar13 + 8) = (*(byte *)puVar43 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 8) = *(byte *)puVar43 ^ 0x80;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 2;
                  }
                  else {
                    if (iVar12 != 2) goto code_r0x00106cc0;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 9) = *(byte *)puVar43 ^ 0x80;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 8) = *(byte *)((longlong)puVar43 + 1)
                    ;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 2;
                  }
                  break;
                case 0x38:
                case 0x7a:
                  if (iVar12 == 0) {
                    *(undefined4 *)((longlong)&uStackX_10 + lVar13 + 8) = 0;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 4;
                  }
                  else if (iVar12 == 1) {
                    *(uint *)((longlong)&uStackX_10 + lVar13 + 8) = (*(byte *)puVar43 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 8) = *(byte *)puVar43 ^ 0x80;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 4;
                  }
                  else if (iVar12 == 2) {
                    *(uint *)((longlong)&uStackX_10 + lVar13 + 8) = (*(byte *)puVar43 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 9) = *(byte *)puVar43 ^ 0x80;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 8) = *(byte *)((longlong)puVar43 + 1)
                    ;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 4;
                  }
                  else if (iVar12 == 3) {
                    *(uint *)((longlong)&uStackX_10 + lVar13 + 8) = (*(byte *)puVar43 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 10) = *(byte *)puVar43 ^ 0x80;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 9) = *(byte *)((longlong)puVar43 + 1)
                    ;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 8) = *(byte *)((longlong)puVar43 + 2)
                    ;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 4;
                  }
                  else {
                    if (iVar12 != 4) goto code_r0x00106f64;
                    uVar26 = *(uint *)puVar43;
                    *(uint *)((longlong)&uStackX_10 + lVar13 + 8) =
                         uVar26 >> 0x18 | (uVar26 & 0xff0000) >> 8 | (uVar26 & 0xff00) << 8 |
                         uVar26 << 0x18;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 0xb) = (byte)uVar26 ^ 0x80;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 4;
                  }
                  break;
                case 0x3a:
                  if (iVar12 == 4) {
                    *(uint *)((longlong)&uStackX_10 + lVar13 + 8) = *(uint *)puVar43;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 4;
                  }
                  else {
                    *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 8) = 0;
code_r0x00106e7b:
                    *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 10) = *(undefined2 *)puVar43;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 4;
                  }
                  break;
                case 0x3b:
                  *(undefined4 *)((longlong)&uStackX_10 + lVar13 + 8) = 0;
                  if (iVar12 == 1) {
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 0xb) = *(byte *)puVar43;
code_r0x00106f64:
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 4;
                  }
                  else {
                    if (iVar12 == 2) goto code_r0x00106e7b;
                    if (iVar12 == 3) {
                      *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 9) = *(undefined2 *)puVar43;
                      *(byte *)((longlong)&uStackX_10 + lVar13 + 0xb) =
                           *(byte *)((longlong)puVar43 + 2);
                      *(undefined4 *)(&stack0x00000048 + lVar13) = 4;
                    }
                    else {
                      if (iVar12 != 4) goto code_r0x00106f64;
                      *(uint *)((longlong)&uStackX_10 + lVar13 + 8) = *(uint *)puVar43;
                      *(undefined4 *)(&stack0x00000048 + lVar13) = 4;
                    }
                  }
                  break;
                case 0x3c:
                case 0x3d:
                case 0x7f:
                  switch(iVar12) {
                  case 0:
                    *(undefined8 *)((longlong)&uStackX_10 + lVar13 + 8) = 0;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                    break;
                  case 1:
                    *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 8) =
                         (ulonglong)(*(byte *)puVar43 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 8) = *(byte *)puVar43 ^ 0x80;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                    break;
                  case 2:
                    *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 8) =
                         (ulonglong)(*(byte *)puVar43 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 9) = *(byte *)puVar43 ^ 0x80;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 8) = *(byte *)((longlong)puVar43 + 1)
                    ;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                    break;
                  case 3:
                    *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 8) =
                         (ulonglong)(*(byte *)puVar43 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 10) = *(byte *)puVar43 ^ 0x80;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 9) = *(byte *)((longlong)puVar43 + 1)
                    ;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 8) = *(byte *)((longlong)puVar43 + 2)
                    ;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                    break;
                  case 4:
                    *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 8) =
                         (ulonglong)(*(byte *)puVar43 >> 7) - 1;
                    uVar26 = *(uint *)puVar43;
                    *(uint *)((longlong)&uStackX_10 + lVar13 + 8) =
                         uVar26 >> 0x18 | (uVar26 & 0xff0000) >> 8 | (uVar26 & 0xff00) << 8 |
                         uVar26 << 0x18;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 0xb) = *(byte *)puVar43 ^ 0x80;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                    break;
                  case 5:
                    *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 8) =
                         (ulonglong)(*(byte *)puVar43 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 0xc) = *(byte *)puVar43 ^ 0x80;
                    uVar26 = *(uint *)((longlong)puVar43 + 1);
                    *(uint *)((longlong)&uStackX_10 + lVar13 + 8) =
                         uVar26 >> 0x18 | (uVar26 & 0xff0000) >> 8 | (uVar26 & 0xff00) << 8 |
                         uVar26 << 0x18;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                    break;
                  case 6:
                    *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 8) =
                         (ulonglong)(*(byte *)puVar43 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 0xd) = *(byte *)puVar43 ^ 0x80;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 0xc) =
                         *(byte *)((longlong)puVar43 + 1);
                    uVar26 = *(uint *)((longlong)puVar43 + 2);
                    *(uint *)((longlong)&uStackX_10 + lVar13 + 8) =
                         uVar26 >> 0x18 | (uVar26 & 0xff0000) >> 8 | (uVar26 & 0xff00) << 8 |
                         uVar26 << 0x18;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                    break;
                  case 7:
                    *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 8) =
                         (ulonglong)(*(byte *)puVar43 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 0xe) = *(byte *)puVar43 ^ 0x80;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 0xd) =
                         *(byte *)((longlong)puVar43 + 1);
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 0xc) =
                         *(byte *)((longlong)puVar43 + 2);
                    uVar26 = *(uint *)((longlong)puVar43 + 3);
                    *(uint *)((longlong)&uStackX_10 + lVar13 + 8) =
                         uVar26 >> 0x18 | (uVar26 & 0xff0000) >> 8 | (uVar26 & 0xff00) << 8 |
                         uVar26 << 0x18;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                    break;
                  case 8:
                    uVar29 = *puVar43;
                    *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 8) =
                         uVar29 >> 0x38 | (uVar29 & 0xff000000000000) >> 0x28 |
                         (uVar29 & 0xff0000000000) >> 0x18 | (uVar29 & 0xff00000000) >> 8 |
                         (uVar29 & 0xff000000) << 8 | (uVar29 & 0xff0000) << 0x18 |
                         (uVar29 & 0xff00) << 0x28 | uVar29 << 0x38;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 0xf) = (byte)uVar29 ^ 0x80;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                    break;
                  default:
                    goto code_r0x00107040;
                  }
                  break;
                case 0x3e:
                  *(undefined8 *)((longlong)&uStackX_10 + lVar13 + 8) = 0;
                  switch(iVar12) {
                  case 1:
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 0xf) = *(byte *)puVar43;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                    break;
                  case 2:
                    *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 0xe) = *(undefined2 *)puVar43;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                    break;
                  case 3:
                    *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 0xd) = *(undefined2 *)puVar43;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 0xf) =
                         *(byte *)((longlong)puVar43 + 2);
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                    break;
                  case 4:
                    *(uint *)((longlong)&uStackX_10 + lVar13 + 0xc) = *(uint *)puVar43;
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                    break;
                  case 5:
                    *(uint *)((longlong)&uStackX_10 + lVar13 + 0xb) = *(uint *)puVar43;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 0xf) =
                         *(byte *)((longlong)puVar43 + 4);
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                    break;
                  case 6:
                    *(uint *)((longlong)&uStackX_10 + lVar13 + 10) = *(uint *)puVar43;
                    *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 0xe) =
                         *(undefined2 *)((longlong)puVar43 + 4);
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                    break;
                  case 7:
                    *(uint *)((longlong)&uStackX_10 + lVar13 + 9) = *(uint *)puVar43;
                    *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 0xd) =
                         *(undefined2 *)((longlong)puVar43 + 4);
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 0xf) =
                         *(byte *)((longlong)puVar43 + 6);
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                    break;
                  case 8:
                    *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 8) = *puVar43;
                  default:
code_r0x00107040:
                    *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                  }
                  break;
                case 0x6a:
                case 0x6c:
                  *(undefined **)(&stack0xfffffffffffffff0 + lVar18 + lVar13) =
                       &stack0x00000048 + lVar13;
                  *(longlong *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) =
                       (longlong)&uStackX_10 + lVar13 + 8;
                  *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x107069;
                  cVar8 = (*pcRam0000000000a645d0)(puVar43,iVar12,bVar22 & 0x3f);
                  if (cVar8 == '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x107087;
                    (*_DAT_)(6,0x54,0x16,1);
                  }
                  break;
                case 0xad:
                case 0xaf:
                  (&stack0xffffffffffffffe8)[lVar18 + lVar13] =
                       *(undefined *)((longlong)puVar31 + 0x3e);
                  uVar48 = *(undefined4 *)(&stack0x00000048 + lVar13);
                  uVar3 = *(undefined4 *)(&stack0x00000044 + lVar13);
                  *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106ea9;
                  func_0x(puVar43,uVar3,(longlong)&uStackX_10 + lVar13 + 8,uVar48);
                  break;
                case 0xbd:
                  *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106edf;
                  func_0x
                            (puVar43,iVar12,(longlong)&uStackX_10 + lVar13 + 8,bVar9 & 0x3f);
                  *(undefined4 *)(&stack0x00000048 + lVar13) = 8;
                  break;
                case 0xe7:
                  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) =
                       *(undefined4 *)(&stack0x00000048 + lVar13);
                  *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1070aa;
                  uVar48 = (*pcRam0000000000a645c8)
                                     (&stack0x00000388 + lVar13,puVar43,iVar12,
                                      (longlong)&uStackX_10 + lVar13 + 8);
                  *(undefined4 *)(&stack0x00000048 + lVar13) = uVar48;
                  break;
                case 0xef:
                  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) =
                       *(undefined4 *)(&stack0x00000048 + lVar13);
                  *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x106ecc;
                  (*pcRam0000000000a645d8)
                            (&stack0x00000350 + lVar13,puVar43,iVar12,
                             (longlong)&uStackX_10 + lVar13 + 8);
                }
              }
              else {
                if (iVar12 != 0) goto code_r0x00107145;
                uVar25 = *(ushort *)(puVar31 + 0xf);
                psVar21 = *ppsVar2;
                if ((*(byte *)((longlong)piVar19 + 6) & 0x10) == 0) {
code_r0x00107133:
                  *(uint *)(&stack0x00000044 + lVar13) = (uint)uVar25;
                  puVar39 = (undefined8 *)((longlong)*piVar19 + *(longlong *)(psVar21 + 4));
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar18 + lVar13) =
                       &stack0x00000144 + lVar13;
                  *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x1070eb;
                  func_0x(psVar21 + 1,piVar19,0,&stack0x0000020c + lVar13);
                  if (*(int *)(&stack0x00000144 + lVar13) != 0) goto code_r0x00107133;
                  puVar39 = (undefined8 *)(*(uint **)(piVar19 + 2) + 1);
                  uVar26 = **(uint **)(piVar19 + 2);
                  if ((uVar25 != 0) && (uVar26 != uVar25)) {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10712e;
                    (*_DAT_)(1,0xf96c90,0xf955f8,0x381);
                  }
                  *(uint *)(&stack0x00000044 + lVar13) = uVar26;
                }
                *(undefined8 *)((longlong)&uStackX_10 + lVar13 + 8) = *puVar39;
              }
code_r0x00107145:
              lVar15 = *(longlong *)(&stack0x00000090 + lVar13);
              if ((*(byte *)(*(longlong *)(puVar31 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar15 = *(longlong *)(&stack0x00000098 + lVar13);
              }
              lVar20 = *(longlong *)(puVar31 + 10);
              *(undefined8 *)(lVar20 + lVar15) = *(undefined8 *)((longlong)&uStackX_10 + lVar13 + 8)
              ;
              uVar26 = puVar31[0x10];
              if ((uVar26 >> 8 & 1) != 0) {
                uVar48 = *(undefined4 *)(&stack0x00000048 + lVar13);
                *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x107184;
                func_0x(&stack0x00000078 + lVar13,puVar31,uVar48);
                uVar26 = puVar31[0x10];
              }
              lVar16 = *(longlong *)(&stack0x00000068 + lVar13);
              param_2 = *ppsVar2;
              if ((uVar26 >> 10 & 1) != 0) {
                lVar30 = *(longlong *)(&stack0x00000090 + lVar13);
                if ((*(byte *)(*(longlong *)(puVar31 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar30 = *(longlong *)(&stack0x00000098 + lVar13);
                }
                uVar23 = 0;
                if ((undefined8 *)(lVar20 + lVar15) == (undefined8 *)0x0) {
                  uVar23 = 3;
                }
                *(undefined *)(lVar30 + *(longlong *)(puVar31 + 0xc)) = uVar23;
              }
              goto code_r0x00107244;
            }
            uVar26 = puVar31[0x10];
            if ((uVar26 >> 10 & 1) != 0) {
              lVar15 = *(longlong *)(&stack0x00000090 + lVar13);
              if ((*(byte *)(*(longlong *)(puVar31 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar15 = *(longlong *)(&stack0x00000098 + lVar13);
              }
              uVar23 = 0;
              if (puVar45 == (uint *)0x0) {
                uVar23 = 3;
              }
              *(undefined *)(lVar15 + *(longlong *)(puVar31 + 0xc)) = uVar23;
              uVar26 = puVar31[0x10];
            }
            if ((uVar26 >> 9 & 1) != 0) {
              *(undefined4 *)(&stack0xffffffffffffffe8 + lVar18 + lVar13) =
                   *(undefined4 *)(&stack0x0000002c + lVar13);
              *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10722f;
              func_0x(&stack0x00000078 + lVar13);
            }
            lVar16 = *(longlong *)(&stack0x00000068 + lVar13);
code_r0x00107233:
            param_2 = *ppsVar2;
code_r0x00107244:
            iVar12 = *(int *)(&stack0x00000060 + lVar13);
            *(uint *)(&stack0x00000060 + lVar13) = iVar12 + 1U;
            puVar31 = puVar31 + 0x14;
            *(uint **)(&stack0x00000050 + lVar13) = puVar31;
            uVar38 = (ulonglong)*(uint *)(&stack0x00000148 + lVar13);
            lVar15 = *(longlong *)(&stack0x00000058 + lVar13);
            puVar33 = &stack0xffffffffffffffc8 + lVar18 + lVar13;
          } while (iVar12 + 1U < uVar44);
        }
      }
    }
    else {
      if (*param_2 == -1) {
        *param_2 = 1;
        puVar37 = (uint *)(ulonglong)*(uint *)(&stack0x0000008c + lVar13);
        uVar26 = *(uint *)(&stack0x00000088 + lVar13);
        puVar31 = *(uint **)(&stack0x00000080 + lVar13);
      }
      puVar1 = (ushort *)(param_2 + 1);
      puVar33 = &stack0xffffffffffffffc8 + lVar13;
      if ((((ulonglong)puVar37 & 0x10) != 0) &&
         (puVar37 = puVar45, puVar33 = &stack0xffffffffffffffc8 + lVar13, puVar40 = puVar45,
         uVar26 != 0)) {
        do {
          uVar23 = 0;
          switch(*(undefined *)(puVar31 + 0x10)) {
          case 0:
            goto code_r0x001040a0;
          case 1:
            uVar25 = *(ushort *)(puVar31 + 1);
            if (*puVar1 < uVar25) {
              uVar25 = ~(*(ushort *)((longlong)puVar31 + 6) >> 4) & 1;
            }
            else {
              bVar9 = *(byte *)((longlong)((int)(uVar25 - 1) / 2) + (ulonglong)(ushort)param_2[0xc]
                               + *(longlong *)(param_2 + 4));
              bVar22 = bVar9 >> 4;
              if ((uVar25 & 1) != 0) {
                bVar22 = bVar9 & 0xf;
              }
              uVar25 = (ushort)(bVar22 == 0);
            }
            if (uVar25 == 0) goto code_r0x00103f3f;
          case 0xd:
          case 0x1b:
            *(undefined4 *)(&stack0x0000004c + lVar13) = 0;
            puVar37 = puVar45;
            break;
          case 2:
code_r0x00103f3f:
            puVar37 = (uint *)0x0;
            break;
          case 3:
            uVar25 = *(ushort *)(puVar31 + 1);
            if (*puVar1 < uVar25) {
              uVar25 = ~(*(ushort *)((longlong)puVar31 + 6) >> 4) & 1;
            }
            else {
              bVar9 = *(byte *)((longlong)((int)(uVar25 - 1) / 2) + (ulonglong)(ushort)param_2[0xc]
                               + *(longlong *)(param_2 + 4));
              bVar22 = bVar9 >> 4;
              if ((uVar25 & 1) != 0) {
                bVar22 = bVar9 & 0xf;
              }
              uVar25 = (ushort)(bVar22 == 0);
            }
            if (uVar25 == 0) goto code_r0x00103faa;
            *(undefined4 *)(&stack0x0000004c + lVar13) = 0;
            puVar37 = puVar45;
            break;
          case 4:
code_r0x00103faa:
            *(undefined4 *)(&stack0x0000011c + lVar13) = 0;
            *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x0000011c + lVar13;
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103fcf;
            puVar37 = (uint *)func_0x(puVar1,puVar31,1,&stack0x0000004c + lVar13);
            if (puVar37 == (uint *)0x0) {
              puVar37 = *(uint **)(*ppsVar2 + 4);
            }
            if ((*(int *)(&stack0x0000004c + lVar13) == 0) && ((puVar31[0x10] & 0x2000) != 0)) {
              *(undefined4 *)(&stack0x0000004c + lVar13) = 4;
              puVar37 = (uint *)0xb8f414;
            }
            if (((**(byte **)(*ppsVar2 + 4) & 0x1c) - 0x18 & 0xfffffffb) == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10401a;
              iVar12 = func_0x(puVar31);
              if (iVar12 != 0) break;
            }
            if ((uint)*(ushort *)(puVar31 + 0xf) < *(uint *)(&stack0x0000004c + lVar13)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10403e;
              (*_DAT_)(6,0x52,0x16,0x91);
            }
            break;
          case 5:
            puVar37 = *(uint **)(param_2 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x104103;
            uVar48 = func_0x(puVar1);
            *(undefined4 *)(&stack0x0000004c + lVar13) = uVar48;
            break;
          case 6:
          case 7:
          case 9:
          case 10:
          case 0xb:
          case 0xe:
          case 0xf:
          case 0x19:
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10411e;
            func_0x(&stack0x00000178 + lVar13,puVar31,&stack0x00000078 + lVar13);
            goto LAB_;
          case 8:
            uVar44 = puVar31[0x10];
            *(undefined4 *)(&stack0x00000120 + lVar13) = 0;
            *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00000120 + lVar13;
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1040ef;
            puVar37 = (uint *)func_0x(puVar1,puVar31,(uVar44 & 0x80000) >> 0x13,
                                              &stack0x0000004c + lVar13);
            break;
          case 0x10:
            uVar17 = *(undefined8 *)(*(longlong *)(lVar15 + 8) + 0x160);
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x104135;
            uVar17 = func_0x(uVar17,0);
            *(undefined4 *)(&stack0x00000038 + lVar13) = 0;
            *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
            iVar12 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000058 + lVar13) + 8) + 0x100);
            if (iVar12 == 2) {
              *(undefined4 *)(&stack0x00000124 + lVar13) = 0;
              *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00000124 + lVar13;
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10417d;
              puVar43 = (ulonglong *)func_0x(puVar1,uVar17,1,&stack0x00000038 + lVar13);
              if (puVar43 == (ulonglong *)0x0) {
                puVar43 = *(ulonglong **)(*ppsVar2 + 4);
              }
              bVar9 = *(byte *)((longlong)puVar31 + 0x45);
              bVar22 = *(byte *)(puVar31 + 0x11);
              switch(*(undefined *)((longlong)puVar31 + 0x3e)) {
              case 0x30:
                if (*(int *)(&stack0x00000038 + lVar13) == 0) {
                  *(undefined *)((longlong)&uStackX_10 + lVar13 + 0x10) = 0;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 1;
                }
                else {
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x10) = *(byte *)puVar43;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 1;
                }
                break;
              case 0x34:
                iVar12 = *(int *)(&stack0x00000038 + lVar13);
                if (iVar12 == 0) {
                  *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 0x10) = 0;
code_r0x001042ef:
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 2;
                }
                else if (iVar12 == 1) {
                  *(ushort *)((longlong)&uStackX_10 + lVar13 + 0x10) = (*(byte *)puVar43 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x10) = *(byte *)puVar43 ^ 0x80;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 2;
                }
                else {
                  if (iVar12 != 2) goto code_r0x001042ef;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x11) = *(byte *)puVar43 ^ 0x80;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       *(byte *)((longlong)puVar43 + 1);
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 2;
                }
                break;
              case 0x38:
              case 0x7a:
                iVar12 = *(int *)(&stack0x00000038 + lVar13);
                if (iVar12 == 0) {
                  *(undefined4 *)((longlong)&uStackX_10 + lVar13 + 0x10) = 0;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 4;
                }
                else if (iVar12 == 1) {
                  *(uint *)((longlong)&uStackX_10 + lVar13 + 0x10) = (*(byte *)puVar43 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x10) = *(byte *)puVar43 ^ 0x80;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 4;
                }
                else if (iVar12 == 2) {
                  *(uint *)((longlong)&uStackX_10 + lVar13 + 0x10) = (*(byte *)puVar43 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x11) = *(byte *)puVar43 ^ 0x80;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       *(byte *)((longlong)puVar43 + 1);
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 4;
                }
                else if (iVar12 == 3) {
                  *(uint *)((longlong)&uStackX_10 + lVar13 + 0x10) = (*(byte *)puVar43 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x12) = *(byte *)puVar43 ^ 0x80;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x11) =
                       *(byte *)((longlong)puVar43 + 1);
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       *(byte *)((longlong)puVar43 + 2);
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 4;
                }
                else {
                  if (iVar12 != 4) goto code_r0x0010459f;
                  uVar44 = *(uint *)puVar43;
                  *(uint *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       uVar44 >> 0x18 | (uVar44 & 0xff0000) >> 8 | (uVar44 & 0xff00) << 8 |
                       uVar44 << 0x18;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x13) = (byte)uVar44 ^ 0x80;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 4;
                }
                break;
              case 0x3a:
                if (*(int *)(&stack0x00000038 + lVar13) == 4) {
                  *(uint *)((longlong)&uStackX_10 + lVar13 + 0x10) = *(uint *)puVar43;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 4;
                }
                else {
                  *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 0x10) = 0;
code_r0x001044af:
                  *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 0x12) = *(undefined2 *)puVar43;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 4;
                }
                break;
              case 0x3b:
                *(undefined4 *)((longlong)&uStackX_10 + lVar13 + 0x10) = 0;
                iVar12 = *(int *)(&stack0x00000038 + lVar13);
                if (iVar12 == 1) {
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x13) = *(byte *)puVar43;
code_r0x0010459f:
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 4;
                }
                else {
                  if (iVar12 == 2) goto code_r0x001044af;
                  if (iVar12 == 3) {
                    *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 0x11) = *(undefined2 *)puVar43;
                    *(byte *)((longlong)&uStackX_10 + lVar13 + 0x13) =
                         *(byte *)((longlong)puVar43 + 2);
                    *(undefined4 *)(&stack0x00000040 + lVar13) = 4;
                  }
                  else {
                    if (iVar12 != 4) goto code_r0x0010459f;
                    *(uint *)((longlong)&uStackX_10 + lVar13 + 0x10) = *(uint *)puVar43;
                    *(undefined4 *)(&stack0x00000040 + lVar13) = 4;
                  }
                }
                break;
              case 0x3c:
              case 0x3d:
              case 0x7f:
                switch(*(undefined4 *)(&stack0x00000038 + lVar13)) {
                case 0:
                  *(undefined8 *)((longlong)&uStackX_10 + lVar13 + 0x10) = 0;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                  break;
                case 1:
                  *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       (ulonglong)(*(byte *)puVar43 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x10) = *(byte *)puVar43 ^ 0x80;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                  break;
                case 2:
                  *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       (ulonglong)(*(byte *)puVar43 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x11) = *(byte *)puVar43 ^ 0x80;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       *(byte *)((longlong)puVar43 + 1);
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                  break;
                case 3:
                  *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       (ulonglong)(*(byte *)puVar43 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x12) = *(byte *)puVar43 ^ 0x80;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x11) =
                       *(byte *)((longlong)puVar43 + 1);
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       *(byte *)((longlong)puVar43 + 2);
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                  break;
                case 4:
                  *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       (ulonglong)(*(byte *)puVar43 >> 7) - 1;
                  uVar44 = *(uint *)puVar43;
                  *(uint *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       uVar44 >> 0x18 | (uVar44 & 0xff0000) >> 8 | (uVar44 & 0xff00) << 8 |
                       uVar44 << 0x18;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x13) = *(byte *)puVar43 ^ 0x80;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                  break;
                case 5:
                  *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       (ulonglong)(*(byte *)puVar43 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x14) = *(byte *)puVar43 ^ 0x80;
                  uVar44 = *(uint *)((longlong)puVar43 + 1);
                  *(uint *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       uVar44 >> 0x18 | (uVar44 & 0xff0000) >> 8 | (uVar44 & 0xff00) << 8 |
                       uVar44 << 0x18;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                  break;
                case 6:
                  *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       (ulonglong)(*(byte *)puVar43 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x15) = *(byte *)puVar43 ^ 0x80;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x14) =
                       *(byte *)((longlong)puVar43 + 1);
                  uVar44 = *(uint *)((longlong)puVar43 + 2);
                  *(uint *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       uVar44 >> 0x18 | (uVar44 & 0xff0000) >> 8 | (uVar44 & 0xff00) << 8 |
                       uVar44 << 0x18;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                  break;
                case 7:
                  *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       (ulonglong)(*(byte *)puVar43 >> 7) - 1;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x16) = *(byte *)puVar43 ^ 0x80;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x15) =
                       *(byte *)((longlong)puVar43 + 1);
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x14) =
                       *(byte *)((longlong)puVar43 + 2);
                  uVar44 = *(uint *)((longlong)puVar43 + 3);
                  *(uint *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       uVar44 >> 0x18 | (uVar44 & 0xff0000) >> 8 | (uVar44 & 0xff00) << 8 |
                       uVar44 << 0x18;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                  break;
                case 8:
                  uVar29 = *puVar43;
                  *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 0x10) =
                       uVar29 >> 0x38 | (uVar29 & 0xff000000000000) >> 0x28 |
                       (uVar29 & 0xff0000000000) >> 0x18 | (uVar29 & 0xff00000000) >> 8 |
                       (uVar29 & 0xff000000) << 8 | (uVar29 & 0xff0000) << 0x18 |
                       (uVar29 & 0xff00) << 0x28 | uVar29 << 0x38;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x17) = (byte)uVar29 ^ 0x80;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                  break;
                default:
                  goto code_r0x0010467a;
                }
                break;
              case 0x3e:
                *(undefined8 *)((longlong)&uStackX_10 + lVar13 + 0x10) = 0;
                switch(*(undefined4 *)(&stack0x00000038 + lVar13)) {
                case 1:
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x17) = *(byte *)puVar43;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                  break;
                case 2:
                  *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 0x16) = *(undefined2 *)puVar43;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                  break;
                case 3:
                  *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 0x15) = *(undefined2 *)puVar43;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x17) =
                       *(byte *)((longlong)puVar43 + 2);
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                  break;
                case 4:
                  *(uint *)((longlong)&uStackX_10 + lVar13 + 0x14) = *(uint *)puVar43;
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                  break;
                case 5:
                  *(uint *)((longlong)&uStackX_10 + lVar13 + 0x13) = *(uint *)puVar43;
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x17) =
                       *(byte *)((longlong)puVar43 + 4);
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                  break;
                case 6:
                  *(uint *)((longlong)&uStackX_10 + lVar13 + 0x12) = *(uint *)puVar43;
                  *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 0x16) =
                       *(undefined2 *)((longlong)puVar43 + 4);
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                  break;
                case 7:
                  *(uint *)((longlong)&uStackX_10 + lVar13 + 0x11) = *(uint *)puVar43;
                  *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 0x15) =
                       *(undefined2 *)((longlong)puVar43 + 4);
                  *(byte *)((longlong)&uStackX_10 + lVar13 + 0x17) =
                       *(byte *)((longlong)puVar43 + 6);
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                  break;
                case 8:
                  *(ulonglong *)((longlong)&uStackX_10 + lVar13 + 0x10) = *puVar43;
                default:
code_r0x0010467a:
                  *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                }
                break;
              case 0x6a:
              case 0x6c:
                *(undefined **)(&stack0xfffffffffffffff0 + lVar13) = &stack0x00000040 + lVar13;
                *(longlong *)(&stack0xffffffffffffffe8 + lVar13) =
                     (longlong)&uStackX_10 + lVar13 + 0x10;
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1046a1;
                cVar8 = (*pcRam0000000000a645d0)
                                  (puVar43,*(undefined4 *)(&stack0x00000038 + lVar13),bVar22 & 0x3f)
                ;
                if (cVar8 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1046bb;
                  (*_DAT_)(6,0x54,0x16,1);
                }
                break;
              case 0xad:
              case 0xaf:
                (&stack0xffffffffffffffe8)[lVar13] = *(undefined *)((longlong)puVar31 + 0x3e);
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1044dd;
                func_0x
                          (puVar43,*(undefined4 *)(&stack0x00000038 + lVar13),
                           (longlong)&uStackX_10 + lVar13 + 0x10,
                           *(undefined4 *)(&stack0x00000040 + lVar13));
                break;
              case 0xbd:
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x104515;
                func_0x
                          (puVar43,*(undefined4 *)(&stack0x00000038 + lVar13),
                           (longlong)&uStackX_10 + lVar13 + 0x10,bVar9 & 0x3f);
                *(undefined4 *)(&stack0x00000040 + lVar13) = 8;
                break;
              case 0xe7:
                *(undefined4 *)(&stack0xffffffffffffffe8 + lVar13) =
                     *(undefined4 *)(&stack0x00000040 + lVar13);
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1046dc;
                uVar48 = (*pcRam0000000000a645c8)
                                   (&stack0x00000318 + lVar13,puVar43,
                                    *(undefined4 *)(&stack0x00000038 + lVar13),
                                    (longlong)&uStackX_10 + lVar13 + 0x10);
                *(undefined4 *)(&stack0x00000040 + lVar13) = uVar48;
                break;
              case 0xef:
                *(undefined4 *)(&stack0xffffffffffffffe8 + lVar13) =
                     *(undefined4 *)(&stack0x00000040 + lVar13);
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x104501;
                (*pcRam0000000000a645d8)
                          (&stack0x000002e0 + lVar13,puVar43,
                           *(undefined4 *)(&stack0x00000038 + lVar13),
                           (longlong)&uStackX_10 + lVar13 + 0x10);
              }
            }
            else if (iVar12 == 0) {
              *(longlong *)((longlong)&uStackX_10 + lVar13 + 0x10) = _DAT_;
            }
            lVar16 = *(longlong *)(&stack0x00000090 + lVar13);
            if ((*(byte *)(*(longlong *)(puVar31 + 0x12) + 0x2a) & 0x10) != 0) {
              lVar16 = *(longlong *)(&stack0x00000098 + lVar13);
            }
            lVar18 = *(longlong *)(puVar31 + 10);
            *(undefined8 *)(lVar18 + lVar16) =
                 *(undefined8 *)((longlong)&uStackX_10 + lVar13 + 0x10);
            uVar44 = puVar31[0x10];
            if ((uVar44 >> 8 & 1) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x104730;
              func_0x
                        (&stack0x00000078 + lVar13,puVar31,
                         *(undefined4 *)(&stack0x00000040 + lVar13));
              uVar44 = puVar31[0x10];
            }
            lVar15 = *(longlong *)(&stack0x00000058 + lVar13);
            if ((uVar44 >> 10 & 1) != 0) {
              lVar20 = *(longlong *)(&stack0x00000090 + lVar13);
              if ((*(byte *)(*(longlong *)(puVar31 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar20 = *(longlong *)(&stack0x00000098 + lVar13);
              }
              if ((undefined8 *)(lVar18 + lVar16) == (undefined8 *)0x0) {
                uVar23 = 3;
              }
              *(undefined *)(lVar20 + *(longlong *)(puVar31 + 0xc)) = uVar23;
            }
            goto code_r0x001040a0;
          }
          uVar44 = puVar31[0x10];
          if ((uVar44 >> 10 & 1) != 0) {
            lVar15 = *(longlong *)(&stack0x00000090 + lVar13);
            if ((*(byte *)(*(longlong *)(puVar31 + 0x12) + 0x2a) & 0x10) != 0) {
              lVar15 = *(longlong *)(&stack0x00000098 + lVar13);
            }
            if (puVar37 == (uint *)0x0) {
              uVar23 = 3;
            }
            *(undefined *)(lVar15 + *(longlong *)(puVar31 + 0xc)) = uVar23;
            uVar44 = puVar31[0x10];
          }
          if ((uVar44 >> 9 & 1) != 0) {
            *(undefined4 *)(&stack0xffffffffffffffe8 + lVar13) =
                 *(undefined4 *)(&stack0x0000004c + lVar13);
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x104096;
            func_0x(&stack0x00000078 + lVar13);
          }
LAB_:
          lVar15 = *(longlong *)(&stack0x00000058 + lVar13);
code_r0x001040a0:
          uVar44 = (int)puVar40 + 1;
          puVar31 = puVar31 + 0x14;
          param_2 = *ppsVar2;
          puVar33 = &stack0xffffffffffffffc8 + lVar13;
          puVar40 = (uint *)(ulonglong)uVar44;
        } while (uVar44 < uVar26);
      }
    }
  }
  else {
    lVar15 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x80);
    *(longlong *)(&stack0x00000198 + lVar13) = *(longlong *)(param_1 + 0x30) + 0x128;
    *(undefined **)(&stack0x000001a0 + lVar13) = &stack0x00000178 + lVar13;
    *(undefined4 *)(&stack0x000001a8 + lVar13) = 1;
    *(undefined4 *)(&stack0x000001ac + lVar13) = 1;
    *(longlong *)(&stack0x000001b0 + lVar13) = lVar15;
    lVar15 = *(longlong *)(lVar15 + 8);
    lVar16 = lVar15;
    if (*(longlong *)(lVar15 + 0x478) != 0) {
      lVar16 = *(longlong *)(lVar15 + 0x478);
    }
    if ((*(short *)(lVar16 + 0x440) == 0) && (*(short *)(lVar15 + 0xce) == 0)) {
      uVar44 = *(uint *)(&stack0x000001cc + lVar13);
    }
    else {
      uVar44 = *(uint *)(&stack0x000001cc + lVar13) | 1;
      *(uint *)(&stack0x000001cc + lVar13) = uVar44;
    }
    lVar15 = *(longlong *)(&stack0x000001b0 + lVar13);
    if ((0x1f7c < *(uint *)(*(longlong *)(lVar15 + 8) + 0xb0)) &&
       ((*(byte *)(*(longlong *)(lVar15 + 8) + 0x106) & 4) == 0)) {
      uVar44 = uVar44 | 2;
      *(uint *)(&stack0x000001cc + lVar13) = uVar44;
    }
    *(undefined4 *)(&stack0x000001b8 + lVar13) =
         *(undefined4 *)(*(longlong *)(lVar15 + 0x20) + 0x664);
    *(ulonglong *)(&stack0x000001c0 + lVar13) = (ulonglong)*(uint6 *)(lVar15 + 0x14) << 0x10;
    *(undefined2 *)(&stack0x000001c8 + lVar13) =
         *(undefined2 *)(*(longlong *)(lVar15 + 0x20) + 0x660);
    *(uint *)(&stack0x000001cc + lVar13) = uVar44 | 4;
    *(undefined8 *)(&stack0x000003f8 + lVar13) = 0;
    *(undefined8 *)(&stack0x00000400 + lVar13) = 0;
    *(undefined4 *)(&stack0x00000408 + lVar13) = 0;
    *(undefined8 *)(&stack0x00000410 + lVar13) = 0;
    *(undefined4 *)(&stack0x00000418 + lVar13) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x107397;
    func_0x(&stack0x0000041c + lVar13,0,0x1f9e);
    *(short **)(&stack0x00000180 + lVar13) = *ppsVar2;
    *(undefined8 *)(&stack0x00000188 + lVar13) = 0;
    lVar15 = *(longlong *)(&stack0x00000078 + lVar13);
    puVar31 = puVar45;
    if ((*(byte *)(lVar15 + 0x38) & 8) != 0) {
      puVar31 = (uint *)(&stack0x000003f8 + lVar13);
      uVar25 = *(ushort *)(lVar15 + 0x62);
      *(uint *)(&stack0x000003f8 + lVar13) = (uint)uVar25;
      *(undefined4 *)(&stack0x00000418 + lVar13) = 0x1f9e;
      *(undefined **)(&stack0x00000410 + lVar13) = &stack0x0000041c + lVar13;
      uVar38 = (ulonglong)(uint)uVar25 * 0x40;
      uVar29 = uVar38 + 0xf;
      if (uVar29 <= uVar38) {
        uVar29 = 0xffffffffffffff0;
      }
      uVar29 = uVar29 & 0xfffffffffffffff0;
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x107406;
      func_0x();
      lVar18 = -uVar29;
      puVar32 = &stack0xffffffffffffffc8 + lVar18 + lVar13;
      lVar16 = (longlong)&psStackX_8 + lVar18 + lVar13;
      *(longlong *)(&stack0x00000400 + lVar13) = lVar16;
      *(undefined8 *)((longlong)&uStack_40 + lVar18 + lVar13) = 0x10741c;
      func_0x(lVar16,0);
    }
    *(undefined8 *)(puVar32 + 0x28) = 0;
    *(undefined **)(puVar32 + 0x20) = &stack0x00000150 + lVar13;
    *(undefined8 *)(puVar32 + -8) = 0x107447;
    uVar48 = func_0x
                       (&stack0x00000198 + lVar13,&stack0x00000078 + lVar13,puVar31,
                        &stack0x00000210 + lVar13);
    if (*(int *)(&stack0x00000150 + lVar13) == 2) {
      pcVar4 = *(code **)(_DAT_ + 0x10);
      *(undefined8 *)(puVar32 + -8) = 0x10745d;
      uVar48 = (*pcVar4)(0);
    }
    if ((*(byte *)(lVar15 + 0x38) & 8) != 0) {
      *(undefined **)(puVar32 + 0x28) = &stack0x00000078 + lVar13;
      *(undefined8 *)(puVar32 + 0x20) = 0;
      *(undefined8 *)(puVar32 + -8) = 0x10747e;
      func_0x(uVar48,0,0,puVar31);
    }
    lVar15 = *(longlong *)(&stack0x00000400 + lVar13);
    if ((lVar15 != 0) &&
       (uVar44 = *(uint *)(&stack0x000003f8 + lVar13), puVar31 = puVar45, uVar44 != 0)) {
      do {
        lVar16 = (longlong)puVar31 * 0x40;
        if ((*(byte *)(lVar15 + 0x18 + lVar16) & 4) != 0) {
          uVar17 = *(undefined8 *)(lVar15 + 0x20 + lVar16);
          *(undefined8 *)(puVar32 + -8) = 0x1074b8;
          (*_DAT_)(uVar17);
          pbVar41 = (byte *)(*(longlong *)(&stack0x00000400 + lVar13) + 0x18 + lVar16);
          *pbVar41 = *pbVar41 & 0xfb;
          lVar15 = *(longlong *)(&stack0x00000400 + lVar13);
          uVar44 = *(uint *)(&stack0x000003f8 + lVar13);
        }
        uVar26 = (int)puVar31 + 1;
        puVar31 = (uint *)(ulonglong)uVar26;
      } while (uVar26 < uVar44);
    }
    lVar15 = *(longlong *)(*(longlong *)(param_1 + 0x38) + 0x28);
    puVar33 = puVar32;
    if (lVar15 != 0) {
      puVar31 = puVar45;
      if (*(int *)(*(longlong *)(param_1 + 0x18) + *(longlong *)(lVar15 + 0x30)) != 3) {
        puVar31 = (uint *)(*(longlong *)(lVar15 + 0x28) + *(longlong *)(param_1 + 0x18));
      }
      *(undefined8 *)(puVar32 + -8) = 0x107503;
      lVar15 = func_0x();
      if (lVar15 != 0) {
        *(undefined8 *)(puVar32 + -8) = 0x10750d;
        lVar15 = func_0x();
        uVar17 = *(undefined8 *)(param_1 + 0x30);
        uVar6 = *(undefined8 *)(lVar15 + 0x110);
        *(undefined8 *)(puVar32 + -8) = 0x10751d;
        lVar15 = func_0x(uVar6,uVar17);
        if (lVar15 != 0) {
          puVar45 = *(uint **)(lVar15 + 8);
        }
      }
      uVar17 = *(undefined8 *)(param_1 + 0x40);
      *(undefined8 *)(puVar32 + -8) = 0x107539;
      func_0x(param_1 + 0x48,uVar17,puVar31,puVar45);
    }
  }
LAB_:
  uVar29 = *(ulonglong *)(&stack0x000023c8 + lVar13);
  *(undefined8 *)(puVar33 + -8) = 0x107548;
  func_0x(uVar29 ^ (ulonglong)ppsVar2);
  return;
code_r0x00103530:
  do {
    if ((uVar25 & 0x7ff) < (*puVar47 & 0x7ff)) {
      uVar25 = param_2[0x15];
      lVar15 = *(longlong *)(param_2 + 4);
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103557;
      func_0x((ulonglong)uVar25 + lVar15,0x1a);
      uVar25 = param_2[0x16];
    }
    iVar12 = iVar12 + 1;
    puVar47 = puVar47 + 1;
  } while (iVar12 < (int)(uVar25 >> 0xb & 7));
  pbVar41 = *(byte **)(param_2 + 4);
code_r0x00103583:
  if ((*pbVar41 & 0x40) == 0) {
    *(undefined4 *)(param_2 + 0x13) = 0;
    psVar21 = *ppsVar2;
    uVar44 = *(uint *)(psVar21 + 2);
  }
  else {
    *(int *)(param_2 + 0x13) = *(int *)(param_2 + 2);
    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + 0xe;
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10359d;
    uVar17 = func_0x(puVar1);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1035ac;
    func_0x(uVar17,&stack0x00000258 + lVar13);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1035b8;
    iVar12 = func_0x(&stack0x00000258 + lVar13);
    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar12;
    uVar44 = *(uint *)(param_2 + 2);
    psVar21 = *ppsVar2;
  }
  if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
     (*(ulonglong *)(param_2 + 0xf) < (ulonglong)uVar44 + *(longlong *)(param_2 + 4))) {
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1035f7;
    cVar8 = func_0x(0x14f8e40);
    if (cVar8 != '\0') {
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103600;
      lVar15 = func_0x();
      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10361a;
        cVar8 = func_0x(0x14f8e40);
        if (cVar8 == '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103636;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10365c;
          (*_DAT_)(1,0xde884c,0xf08938,0x886);
        }
      }
    }
    uVar17 = *(undefined8 *)(param_2 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10366a;
    func_0x(uVar17,0x12);
    uVar44 = *(uint *)(psVar21 + 2);
  }
  if (0x3f3b < uVar44 - 1) {
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103683;
    cVar8 = func_0x(0x14f8e40);
    if (cVar8 != '\0') {
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10368c;
      lVar15 = func_0x();
      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1036a6;
        cVar8 = func_0x(0x14f8e40);
        if (cVar8 == '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1036c2;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1036e8;
          (*_DAT_)(1,0xde884c,0xf08938,0x88b);
        }
      }
    }
    uVar17 = *(undefined8 *)(param_2 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1036f6;
    func_0x(uVar17,5);
  }
code_r0x001036f6:
  sVar10 = -*(short *)piVar19;
  if ((*(byte *)((longlong)piVar19 + 6) & 0x10) == 0) {
code_r0x00103743:
    lVar15 = (longlong)sVar10;
    if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar10) {
      iVar12 = 0;
      puVar43 = *(ulonglong **)(param_2 + 4);
    }
    else {
      lVar16 = *(longlong *)(param_2 + 4);
      lVar18 = (ulonglong)*(uint *)(param_2 + 10) + lVar16;
      psVar21 = *ppsVar2;
      if (sVar10 == 1) {
        uVar44 = *(uint *)(param_2 + 0xc);
        uVar26 = *(ushort *)(lVar18 + lVar15 * 2) & 0x7fff;
code_r0x00103796:
        if ((uVar26 < uVar44) || (*(uint *)(param_2 + 2) < uVar26)) goto code_r0x0010379f;
      }
      else {
        uVar44 = *(ushort *)(lVar18 + -2 + lVar15 * 2) & 0x7fff;
        uVar26 = *(ushort *)(lVar18 + lVar15 * 2) & 0x7fff;
        lVar16 = *(longlong *)(psVar21 + 4);
        if (*(uint *)(psVar21 + 0xc) <= uVar44) goto code_r0x00103796;
code_r0x0010379f:
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1037a9;
        func_0x(lVar16,7);
        lVar16 = *(longlong *)(psVar21 + 4);
      }
      iVar12 = uVar26 - uVar44;
      puVar43 = (ulonglong *)((ulonglong)uVar44 + lVar16);
    }
  }
  else {
    *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00000114 + lVar13;
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103727;
    func_0x(puVar1,piVar19,0,&stack0x000001e4 + lVar13);
    if (*(int *)(&stack0x00000114 + lVar13) != 0) goto code_r0x00103743;
    iVar12 = **(int **)(piVar19 + 2);
    puVar43 = (ulonglong *)(*(int **)(piVar19 + 2) + 1);
  }
  puVar31 = *(uint **)(&stack0x00000050 + lVar13);
  bVar9 = *(byte *)((longlong)puVar31 + 0x45);
  bVar22 = *(byte *)(puVar31 + 0x11);
  switch(*(undefined *)((longlong)puVar31 + 0x3e)) {
  case 0x30:
    if (iVar12 == 0) {
      *(undefined *)((longlong)&uStackX_10 + lVar13) = 0;
      *(undefined4 *)(&stack0x0000003c + lVar13) = 1;
    }
    else {
      *(byte *)((longlong)&uStackX_10 + lVar13) = *(byte *)puVar43;
      *(undefined4 *)(&stack0x0000003c + lVar13) = 1;
    }
    break;
  case 0x34:
    if (iVar12 == 0) {
      *(undefined2 *)((longlong)&uStackX_10 + lVar13) = 0;
code_r0x00103930:
      *(undefined4 *)(&stack0x0000003c + lVar13) = 2;
    }
    else if (iVar12 == 1) {
      *(ushort *)((longlong)&uStackX_10 + lVar13) = (*(byte *)puVar43 >> 7) - 1;
      *(byte *)((longlong)&uStackX_10 + lVar13) = *(byte *)puVar43 ^ 0x80;
      *(undefined4 *)(&stack0x0000003c + lVar13) = 2;
    }
    else {
      if (iVar12 != 2) goto code_r0x00103930;
      *(byte *)((longlong)&uStackX_10 + lVar13 + 1) = *(byte *)puVar43 ^ 0x80;
      *(byte *)((longlong)&uStackX_10 + lVar13) = *(byte *)((longlong)puVar43 + 1);
      *(undefined4 *)(&stack0x0000003c + lVar13) = 2;
    }
    break;
  case 0x38:
  case 0x7a:
    if (iVar12 == 0) {
      *(undefined4 *)((longlong)&uStackX_10 + lVar13) = 0;
      *(undefined4 *)(&stack0x0000003c + lVar13) = 4;
    }
    else if (iVar12 == 1) {
      *(uint *)((longlong)&uStackX_10 + lVar13) = (*(byte *)puVar43 >> 7) - 1;
      *(byte *)((longlong)&uStackX_10 + lVar13) = *(byte *)puVar43 ^ 0x80;
      *(undefined4 *)(&stack0x0000003c + lVar13) = 4;
    }
    else if (iVar12 == 2) {
      *(uint *)((longlong)&uStackX_10 + lVar13) = (*(byte *)puVar43 >> 7) - 1;
      *(byte *)((longlong)&uStackX_10 + lVar13 + 1) = *(byte *)puVar43 ^ 0x80;
      *(byte *)((longlong)&uStackX_10 + lVar13) = *(byte *)((longlong)puVar43 + 1);
      *(undefined4 *)(&stack0x0000003c + lVar13) = 4;
    }
    else if (iVar12 == 3) {
      *(uint *)((longlong)&uStackX_10 + lVar13) = (*(byte *)puVar43 >> 7) - 1;
      *(byte *)((longlong)&uStackX_10 + lVar13 + 2) = *(byte *)puVar43 ^ 0x80;
      *(byte *)((longlong)&uStackX_10 + lVar13 + 1) = *(byte *)((longlong)puVar43 + 1);
      *(byte *)((longlong)&uStackX_10 + lVar13) = *(byte *)((longlong)puVar43 + 2);
      *(undefined4 *)(&stack0x0000003c + lVar13) = 4;
    }
    else {
      if (iVar12 != 4) goto code_r0x00103c16;
      uVar44 = *(uint *)puVar43;
      *(uint *)((longlong)&uStackX_10 + lVar13) =
           uVar44 >> 0x18 | (uVar44 & 0xff0000) >> 8 | (uVar44 & 0xff00) << 8 | uVar44 << 0x18;
      *(byte *)((longlong)&uStackX_10 + lVar13 + 3) = (byte)uVar44 ^ 0x80;
      *(undefined4 *)(&stack0x0000003c + lVar13) = 4;
    }
    break;
  case 0x3a:
    if (iVar12 == 4) {
      *(uint *)((longlong)&uStackX_10 + lVar13) = *(uint *)puVar43;
      *(undefined4 *)(&stack0x0000003c + lVar13) = 4;
    }
    else {
      *(undefined2 *)((longlong)&uStackX_10 + lVar13) = 0;
code_r0x00103b35:
      *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 2) = *(undefined2 *)puVar43;
      *(undefined4 *)(&stack0x0000003c + lVar13) = 4;
    }
    break;
  case 0x3b:
    *(undefined4 *)((longlong)&uStackX_10 + lVar13) = 0;
    if (iVar12 == 1) {
      *(byte *)((longlong)&uStackX_10 + lVar13 + 3) = *(byte *)puVar43;
code_r0x00103c16:
      *(undefined4 *)(&stack0x0000003c + lVar13) = 4;
    }
    else {
      if (iVar12 == 2) goto code_r0x00103b35;
      if (iVar12 == 3) {
        *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 1) = *(undefined2 *)puVar43;
        *(byte *)((longlong)&uStackX_10 + lVar13 + 3) = *(byte *)((longlong)puVar43 + 2);
        *(undefined4 *)(&stack0x0000003c + lVar13) = 4;
      }
      else {
        if (iVar12 != 4) goto code_r0x00103c16;
        *(uint *)((longlong)&uStackX_10 + lVar13) = *(uint *)puVar43;
        *(undefined4 *)(&stack0x0000003c + lVar13) = 4;
      }
    }
    break;
  case 0x3c:
  case 0x3d:
  case 0x7f:
    switch(iVar12) {
    case 0:
      *(undefined8 *)((longlong)&uStackX_10 + lVar13) = 0;
      break;
    case 1:
      *(ulonglong *)((longlong)&uStackX_10 + lVar13) = (ulonglong)(*(byte *)puVar43 >> 7) - 1;
      *(byte *)((longlong)&uStackX_10 + lVar13) = *(byte *)puVar43 ^ 0x80;
      break;
    case 2:
      *(ulonglong *)((longlong)&uStackX_10 + lVar13) = (ulonglong)(*(byte *)puVar43 >> 7) - 1;
      *(byte *)((longlong)&uStackX_10 + lVar13 + 1) = *(byte *)puVar43 ^ 0x80;
      *(byte *)((longlong)&uStackX_10 + lVar13) = *(byte *)((longlong)puVar43 + 1);
      break;
    case 3:
      *(ulonglong *)((longlong)&uStackX_10 + lVar13) = (ulonglong)(*(byte *)puVar43 >> 7) - 1;
      *(byte *)((longlong)&uStackX_10 + lVar13 + 2) = *(byte *)puVar43 ^ 0x80;
      *(byte *)((longlong)&uStackX_10 + lVar13 + 1) = *(byte *)((longlong)puVar43 + 1);
      *(byte *)((longlong)&uStackX_10 + lVar13) = *(byte *)((longlong)puVar43 + 2);
      break;
    case 4:
      *(ulonglong *)((longlong)&uStackX_10 + lVar13) = (ulonglong)(*(byte *)puVar43 >> 7) - 1;
      uVar44 = *(uint *)puVar43;
      *(uint *)((longlong)&uStackX_10 + lVar13) =
           uVar44 >> 0x18 | (uVar44 & 0xff0000) >> 8 | (uVar44 & 0xff00) << 8 | uVar44 << 0x18;
      *(byte *)((longlong)&uStackX_10 + lVar13 + 3) = *(byte *)puVar43 ^ 0x80;
      break;
    case 5:
      *(ulonglong *)((longlong)&uStackX_10 + lVar13) = (ulonglong)(*(byte *)puVar43 >> 7) - 1;
      *(byte *)((longlong)&uStackX_10 + lVar13 + 4) = *(byte *)puVar43 ^ 0x80;
      uVar44 = *(uint *)((longlong)puVar43 + 1);
      *(uint *)((longlong)&uStackX_10 + lVar13) =
           uVar44 >> 0x18 | (uVar44 & 0xff0000) >> 8 | (uVar44 & 0xff00) << 8 | uVar44 << 0x18;
      break;
    case 6:
      *(ulonglong *)((longlong)&uStackX_10 + lVar13) = (ulonglong)(*(byte *)puVar43 >> 7) - 1;
      *(byte *)((longlong)&uStackX_10 + lVar13 + 5) = *(byte *)puVar43 ^ 0x80;
      *(byte *)((longlong)&uStackX_10 + lVar13 + 4) = *(byte *)((longlong)puVar43 + 1);
      uVar44 = *(uint *)((longlong)puVar43 + 2);
      *(uint *)((longlong)&uStackX_10 + lVar13) =
           uVar44 >> 0x18 | (uVar44 & 0xff0000) >> 8 | (uVar44 & 0xff00) << 8 | uVar44 << 0x18;
      break;
    case 7:
      *(ulonglong *)((longlong)&uStackX_10 + lVar13) = (ulonglong)(*(byte *)puVar43 >> 7) - 1;
      *(byte *)((longlong)&uStackX_10 + lVar13 + 6) = *(byte *)puVar43 ^ 0x80;
      *(byte *)((longlong)&uStackX_10 + lVar13 + 5) = *(byte *)((longlong)puVar43 + 1);
      *(byte *)((longlong)&uStackX_10 + lVar13 + 4) = *(byte *)((longlong)puVar43 + 2);
      uVar44 = *(uint *)((longlong)puVar43 + 3);
      *(uint *)((longlong)&uStackX_10 + lVar13) =
           uVar44 >> 0x18 | (uVar44 & 0xff0000) >> 8 | (uVar44 & 0xff00) << 8 | uVar44 << 0x18;
      break;
    case 8:
      uVar29 = *puVar43;
      *(ulonglong *)((longlong)&uStackX_10 + lVar13) =
           uVar29 >> 0x38 | (uVar29 & 0xff000000000000) >> 0x28 | (uVar29 & 0xff0000000000) >> 0x18
           | (uVar29 & 0xff00000000) >> 8 | (uVar29 & 0xff000000) << 8 | (uVar29 & 0xff0000) << 0x18
           | (uVar29 & 0xff00) << 0x28 | uVar29 << 0x38;
      bVar9 = (byte)uVar29 ^ 0x80;
      goto code_r0x00103a82;
    }
    goto code_r0x00103a85;
  case 0x3e:
    *(undefined8 *)((longlong)&uStackX_10 + lVar13) = 0;
    switch(iVar12) {
    case 1:
      bVar9 = *(byte *)puVar43;
      goto code_r0x00103a82;
    case 2:
      *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 6) = *(undefined2 *)puVar43;
      break;
    case 3:
      *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 5) = *(undefined2 *)puVar43;
      bVar9 = *(byte *)((longlong)puVar43 + 2);
      goto code_r0x00103a82;
    case 4:
      *(uint *)((longlong)&uStackX_10 + lVar13 + 4) = *(uint *)puVar43;
      break;
    case 5:
      *(uint *)((longlong)&uStackX_10 + lVar13 + 3) = *(uint *)puVar43;
      bVar9 = *(byte *)((longlong)puVar43 + 4);
      goto code_r0x00103a82;
    case 6:
      *(uint *)((longlong)&uStackX_10 + lVar13 + 2) = *(uint *)puVar43;
      *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 6) = *(undefined2 *)((longlong)puVar43 + 4);
      break;
    case 7:
      *(uint *)((longlong)&uStackX_10 + lVar13 + 1) = *(uint *)puVar43;
      *(undefined2 *)((longlong)&uStackX_10 + lVar13 + 5) = *(undefined2 *)((longlong)puVar43 + 4);
      bVar9 = *(byte *)((longlong)puVar43 + 6);
code_r0x00103a82:
      *(byte *)((longlong)&uStackX_10 + lVar13 + 7) = bVar9;
      break;
    case 8:
      *(ulonglong *)((longlong)&uStackX_10 + lVar13) = *puVar43;
    }
code_r0x00103a85:
    *(undefined4 *)(&stack0x0000003c + lVar13) = 8;
    break;
  case 0x6a:
  case 0x6c:
    *(undefined **)(&stack0xfffffffffffffff0 + lVar13) = &stack0x0000003c + lVar13;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar13) = (longlong)&uStackX_10 + lVar13;
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103cd7;
    cVar8 = (*pcRam0000000000a645d0)(puVar43,iVar12,bVar22 & 0x3f);
    if (cVar8 == '\0') {
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103cf5;
      (*_DAT_)(6,0x54,0x16,1);
    }
    break;
  case 0xad:
  case 0xaf:
    (&stack0xffffffffffffffe8)[lVar13] = *(undefined *)((longlong)puVar31 + 0x3e);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103b62;
    func_0x
              (puVar43,iVar12,(longlong)&uStackX_10 + lVar13,
               *(undefined4 *)(&stack0x0000003c + lVar13));
    break;
  case 0xbd:
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103b98;
    func_0x(puVar43,iVar12,(longlong)&uStackX_10 + lVar13,bVar9 & 0x3f);
    goto code_r0x00103a85;
  case 0xe7:
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar13) = *(undefined4 *)(&stack0x0000003c + lVar13);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103d18;
    uVar48 = (*pcRam0000000000a645c8)
                       (&stack0x000002a8 + lVar13,puVar43,iVar12,(longlong)&uStackX_10 + lVar13);
    *(undefined4 *)(&stack0x0000003c + lVar13) = uVar48;
    break;
  case 0xef:
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar13) = *(undefined4 *)(&stack0x0000003c + lVar13);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103b85;
    (*pcRam0000000000a645d8)
              (&stack0x000003c0 + lVar13,puVar43,iVar12,(longlong)&uStackX_10 + lVar13);
  }
code_r0x00103a8c:
  uVar44 = *(uint *)(&stack0x00000028 + lVar13);
code_r0x00103a8f:
  uVar23 = 0;
  lVar16 = *(longlong *)(&stack0x00000090 + lVar13);
  if ((*(byte *)(*(longlong *)(puVar31 + 0x12) + 0x2a) & 0x10) != 0) {
    lVar16 = *(longlong *)(&stack0x00000098 + lVar13);
  }
  lVar18 = *(longlong *)(puVar31 + 10);
  *(undefined8 *)(lVar18 + lVar16) = *(undefined8 *)((longlong)&uStackX_10 + lVar13);
  uVar26 = puVar31[0x10];
  if ((uVar26 >> 8 & 1) != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103ad1;
    func_0x
              (&stack0x00000078 + lVar13,puVar31,*(undefined4 *)(&stack0x0000003c + lVar13));
    uVar26 = puVar31[0x10];
  }
  lVar15 = *(longlong *)(&stack0x00000058 + lVar13);
  psVar21 = *ppsVar2;
  if ((uVar26 >> 10 & 1) != 0) {
    lVar20 = *(longlong *)(&stack0x00000090 + lVar13);
    if ((*(byte *)(*(longlong *)(puVar31 + 0x12) + 0x2a) & 0x10) != 0) {
      lVar20 = *(longlong *)(&stack0x00000098 + lVar13);
    }
    if ((undefined8 *)(lVar18 + lVar16) == (undefined8 *)0x0) {
      uVar23 = 3;
    }
    *(undefined *)(lVar20 + *(longlong *)(puVar31 + 0xc)) = uVar23;
  }
code_r0x00103e3f:
  uVar44 = uVar44 + 1;
  *(uint *)(&stack0x00000028 + lVar13) = uVar44;
  puVar31 = puVar31 + 0x14;
  *(uint **)(&stack0x00000050 + lVar13) = puVar31;
  puVar33 = &stack0xffffffffffffffc8 + lVar13;
  if (*(uint *)(&stack0x00000060 + lVar13) <= uVar44) goto LAB_;
  goto LAB_;
code_r0x00102660:
  do {
    if ((uVar25 & 0x7ff) < (*puVar47 & 0x7ff)) {
      uVar25 = param_2[0x15];
      lVar15 = *(longlong *)(param_2 + 4);
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102687;
      func_0x((ulonglong)uVar25 + lVar15,0x1a);
      uVar25 = param_2[0x16];
    }
    iVar12 = iVar12 + 1;
    puVar47 = puVar47 + 1;
  } while (iVar12 < (int)(uVar25 >> 0xb & 7));
  pbVar41 = *(byte **)(param_2 + 4);
code_r0x001026b3:
  if ((*pbVar41 & 0x40) == 0) {
    *(undefined4 *)(param_2 + 0x13) = 0;
    psVar21 = *ppsVar2;
    uVar44 = *(uint *)(psVar21 + 2);
  }
  else {
    *(int *)(param_2 + 0x13) = *(int *)(param_2 + 2);
    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + 0xe;
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1026cd;
    uVar17 = func_0x(puVar1);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1026dc;
    func_0x(uVar17,&stack0x00000248 + lVar13);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1026e8;
    iVar12 = func_0x(&stack0x00000248 + lVar13);
    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar12;
    uVar44 = *(uint *)(param_2 + 2);
    psVar21 = *ppsVar2;
  }
  if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
     (*(ulonglong *)(param_2 + 0xf) < (ulonglong)uVar44 + *(longlong *)(param_2 + 4))) {
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102727;
    cVar8 = func_0x(0x14f8e40);
    if (cVar8 != '\0') {
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102730;
      lVar15 = func_0x();
      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10274a;
        cVar8 = func_0x(0x14f8e40);
        if (cVar8 == '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102766;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10278c;
          (*_DAT_)(1,0xde884c,0xf08938,0x886);
        }
      }
    }
    uVar17 = *(undefined8 *)(param_2 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10279a;
    func_0x(uVar17);
    uVar44 = *(uint *)(psVar21 + 2);
  }
  if (0x3f3b < uVar44 - 1) {
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1027b3;
    cVar8 = func_0x(0x14f8e40);
    if (cVar8 != '\0') {
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1027bc;
      lVar15 = func_0x();
      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1027d6;
        cVar8 = func_0x(0x14f8e40);
        if (cVar8 == '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1027f2;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102818;
          (*_DAT_)(1,0xde884c,0xf08938,0x88b);
        }
      }
    }
    uVar17 = *(undefined8 *)(param_2 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102826;
    func_0x(uVar17);
  }
code_r0x00102829:
  sVar10 = -*(short *)puVar31;
  if ((*(byte *)((longlong)puVar31 + 6) & 0x10) == 0) {
code_r0x00102867:
    lVar15 = (longlong)sVar10;
    if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar10) {
      *(undefined4 *)(&stack0x00000030 + lVar13) = 0;
      puVar45 = *(uint **)(param_2 + 4);
    }
    else {
      lVar16 = (ulonglong)*(uint *)(param_2 + 10) + *(longlong *)(param_2 + 4);
      if (sVar10 == 1) {
        uVar44 = *(uint *)(param_2 + 0xc);
        uVar26 = *(ushort *)(lVar16 + lVar15 * 2) & 0x7fff;
code_r0x001028b6:
        if ((uVar26 < uVar44) || (*(uint *)(param_2 + 2) < uVar26)) goto code_r0x001028bf;
      }
      else {
        uVar44 = *(ushort *)(lVar16 + -2 + lVar15 * 2) & 0x7fff;
        uVar26 = *(ushort *)(lVar16 + lVar15 * 2) & 0x7fff;
        if (*(uint *)(*ppsVar2 + 0xc) <= uVar44) goto code_r0x001028b6;
code_r0x001028bf:
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1028cc;
        func_0x();
      }
      *(uint *)(&stack0x00000030 + lVar13) = uVar26 - uVar44;
      puVar45 = (uint *)((ulonglong)uVar44 + *(longlong *)(param_2 + 4));
    }
  }
  else {
    *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00000110 + lVar13;
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10285a;
    func_0x(puVar1,puVar31,0,&stack0x000001dc + lVar13);
    if (*(int *)(&stack0x00000110 + lVar13) != 0) goto code_r0x00102867;
code_r0x00103dc8:
    puVar5 = *(undefined4 **)(puVar31 + 2);
    *(undefined4 *)(&stack0x00000030 + lVar13) = *puVar5;
    puVar45 = puVar5 + 1;
  }
  goto code_r0x00103ddb;
code_r0x00102cb6:
  *puVar1 = *puVar1 | 1;
  uVar25 = param_2[0xe] - 1;
  param_2[0xe] = uVar25;
  if ((uVar25 == 0) ||
     (uVar29 = (ulonglong)uVar25, -1 < (short)puVar47[(ulonglong)(uVar25 - 1) + 1]))
  goto code_r0x00102cdd;
  goto code_r0x00102c30;
code_r0x00101d50:
  do {
    if ((uVar25 & 0x7ff) < (*puVar47 & 0x7ff)) {
      uVar25 = param_2[0x15];
      lVar15 = *(longlong *)(param_2 + 4);
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101d77;
      func_0x((ulonglong)uVar25 + lVar15,0x1a);
      uVar25 = param_2[0x16];
    }
    iVar12 = iVar12 + 1;
    puVar47 = puVar47 + 1;
  } while (iVar12 < (int)(uVar25 >> 0xb & 7));
  pbVar24 = *(byte **)(param_2 + 4);
code_r0x00101da3:
  if ((*pbVar24 & 0x40) == 0) {
    *(undefined4 *)(param_2 + 0x13) = 0;
    psVar21 = *ppsVar2;
    uVar44 = *(uint *)(psVar21 + 2);
  }
  else {
    *(int *)(param_2 + 0x13) = *(int *)(param_2 + 2);
    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + 0xe;
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101dbd;
    uVar17 = func_0x(puVar1);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101dcc;
    func_0x(uVar17,&stack0x00000240 + lVar13);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101dd8;
    iVar12 = func_0x(&stack0x00000240 + lVar13);
    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar12;
    uVar44 = *(uint *)(param_2 + 2);
    pbVar24 = *(byte **)(param_2 + 4);
    psVar21 = *ppsVar2;
  }
  if ((*(byte **)(param_2 + 0xf) != (byte *)0x0) && (*(byte **)(param_2 + 0xf) < pbVar24 + uVar44))
  {
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101e1a;
    cVar8 = func_0x(0x14f8e40);
    if (cVar8 != '\0') {
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101e23;
      lVar15 = func_0x();
      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101e3d;
        cVar8 = func_0x(0x14f8e40);
        if (cVar8 == '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101e59;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101e7f;
          (*_DAT_)(1,0xde884c,0xf08938,0x886);
        }
      }
    }
    uVar17 = *(undefined8 *)(param_2 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101e8d;
    func_0x(uVar17);
    uVar44 = *(uint *)(psVar21 + 2);
  }
  if (0x3f3b < uVar44 - 1) {
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101ea6;
    cVar8 = func_0x(0x14f8e40);
    if (cVar8 != '\0') {
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101eaf;
      lVar15 = func_0x();
      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101ec9;
        cVar8 = func_0x(0x14f8e40);
        if (cVar8 == '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101ee5;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101f0b;
          (*_DAT_)(1,0xde884c,0xf08938,0x88b);
        }
      }
    }
    uVar17 = *(undefined8 *)(param_2 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101f19;
    func_0x(uVar17);
  }
code_r0x00101f1c:
  sVar10 = -*(short *)puVar31;
  if ((*(byte *)((longlong)puVar31 + 6) & 0x10) == 0) {
code_r0x00101f66:
    lVar15 = (longlong)sVar10;
    if ((uint)(int)sVar10 <= (uint)(ushort)param_2[0xe]) {
      lVar16 = *(longlong *)(param_2 + 4);
      lVar18 = (ulonglong)*(uint *)(param_2 + 10) + lVar16;
      if (sVar10 == 1) {
        uVar44 = *(uint *)(param_2 + 0xc);
        uVar26 = *(ushort *)(lVar18 + lVar15 * 2) & 0x7fff;
code_r0x00101fb5:
        if ((uVar26 < uVar44) || (*(uint *)(param_2 + 2) < uVar26)) goto code_r0x00101fbe;
      }
      else {
        uVar44 = *(ushort *)(lVar18 + -2 + lVar15 * 2) & 0x7fff;
        uVar26 = *(ushort *)(lVar18 + lVar15 * 2) & 0x7fff;
        lVar16 = *(longlong *)(*ppsVar2 + 4);
        if (*(uint *)(*ppsVar2 + 0xc) <= uVar44) goto code_r0x00101fb5;
code_r0x00101fbe:
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101fcb;
        func_0x(lVar16);
      }
      iVar12 = uVar26 - uVar44;
      *(int *)(&stack0x00000030 + lVar13) = iVar12;
      puVar45 = (uint *)((ulonglong)uVar44 + *(longlong *)(param_2 + 4));
      goto code_r0x00101fd7;
    }
    *(undefined4 *)(&stack0x00000030 + lVar13) = 0;
    puVar45 = *(uint **)(param_2 + 4);
code_r0x00101fe5:
    if ((puVar31[0x10] & 0x2000) != 0) {
      *(undefined4 *)(&stack0x00000030 + lVar13) = 4;
      puVar45 = (uint *)0xb8f414;
    }
  }
  else {
    *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00000160 + lVar13;
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101f4d;
    func_0x(puVar1,puVar31,0,&stack0x00000298 + lVar13);
    if (*(int *)(&stack0x00000160 + lVar13) != 0) goto code_r0x00101f66;
    piVar19 = *(int **)(puVar31 + 2);
    iVar12 = *piVar19;
    *(int *)(&stack0x00000030 + lVar13) = iVar12;
    puVar45 = (uint *)(piVar19 + 1);
code_r0x00101fd7:
    if (iVar12 == 0) goto code_r0x00101fe5;
  }
  if ((1 << (**(byte **)(param_2 + 4) & 0xe) & 0x440U) != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102020;
    iVar12 = func_0x();
    if (iVar12 != 0) goto code_r0x00103ddb;
  }
  if ((uint)*(ushort *)(puVar31 + 0xf) < *(uint *)(&stack0x00000030 + lVar13)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10204d;
    (*_DAT_)(6,0x52,0x16,0x91);
  }
code_r0x00103ddb:
  uVar44 = *(uint *)(&stack0x00000028 + lVar13);
LAB_:
  uVar26 = puVar31[0x10];
  if ((uVar26 >> 10 & 1) != 0) {
    lVar15 = *(longlong *)(&stack0x00000090 + lVar13);
    if ((*(byte *)(*(longlong *)(puVar31 + 0x12) + 0x2a) & 0x10) != 0) {
      lVar15 = *(longlong *)(&stack0x00000098 + lVar13);
    }
    uVar23 = 0;
    if (puVar45 == (uint *)0x0) {
      uVar23 = 3;
    }
    *(undefined *)(lVar15 + *(longlong *)(puVar31 + 0xc)) = uVar23;
    uVar26 = puVar31[0x10];
  }
  if ((uVar26 >> 9 & 1) != 0) {
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar13) = *(undefined4 *)(&stack0x00000030 + lVar13);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x103e37;
    func_0x();
  }
LAB_:
  lVar15 = *(longlong *)(&stack0x00000058 + lVar13);
  psVar21 = *ppsVar2;
  goto code_r0x00103e3f;
}

