
/* WARNING: Control flow encountered bad instruction data */

undefined8 FUN_(longlong param_1,int param_2,int param_3)

{
  undefined8 uVar1;
  longlong lVar2;
  byte *pbVar3;
  
  if ((longlong)(param_3 + param_2) <= (longlong)param_2) {
    return 0;
  }
  pbVar3 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - (longlong)param_2) * 2) + param_1);
  if ((*pbVar3 & 1) == 0) {
    lVar2 = (longlong)(int)(*pbVar3 & 0xe);
                    /* WARNING: Could not emulate address calculation at 0x001000c9 */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (*(code *)((ulonglong)*(uint *)(lVar2 * 4 + 0xfffb8) + 0x839b0))(0xffffffff,lVar2,0);
    return uVar1;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

