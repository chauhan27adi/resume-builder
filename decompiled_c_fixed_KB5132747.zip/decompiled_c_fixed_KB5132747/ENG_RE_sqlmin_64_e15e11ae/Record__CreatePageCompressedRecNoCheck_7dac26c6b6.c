
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,undefined8 param_2,ulonglong param_3,short *param_4)

{
  ushort *puVar1;
  uint *puVar2;
  uint *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong lVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  byte bVar11;
  char cVar12;
  ushort uVar13;
  longlong lVar14;
  longlong lVar15;
  undefined8 uVar16;
  undefined8 *puVar17;
  undefined4 *puVar18;
  byte bVar19;
  uint uVar20;
  ulonglong uVar21;
  byte *pbVar22;
  uint uVar23;
  uint uVar24;
  ushort *puVar25;
  byte **ppbVar26;
  uint uVar27;
  undefined *puVar28;
  ushort uVar29;
  uint uVar30;
  ushort *puVar31;
  undefined8 *puVar32;
  undefined8 *puVar33;
  int iVar34;
  short sVar35;
  ushort uVar36;
  ulonglong uVar37;
  ulonglong uVar38;
  ulonglong uVar39;
  undefined8 *puVar40;
  int iVar41;
  undefined8 *puVar42;
  undefined8 uStackX_8;
  short asStackX_10 [2];
  uint auStackX_14 [3];
  undefined8 uStackX_20;
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar14 = func_0x();
  lVar14 = -lVar14;
  puVar28 = &stack0xffffffffffffffc0 + lVar14;
  puVar3 = (uint *)((longlong)&uStackX_20 + lVar14 + -0x20);
  *(ulonglong *)(&stack0x00002430 + lVar14) = _DAT_ ^ (ulonglong)puVar3;
  pbVar22 = *(byte **)(param_4 + 4);
  puVar25 = (ushort *)(param_4 + 1);
  uVar16 = *(undefined8 *)(&stack0x000024b0 + lVar14);
  *(short **)(&stack0x00000030 + lVar14) = param_1;
  *(short **)(&stack0x00000088 + lVar14) = param_4;
  bVar11 = *pbVar22;
  *(int *)((longlong)auStackX_14 + lVar14 + 4) = (int)param_3;
  *(undefined8 *)((longlong)&uStackX_8 + lVar14) = param_2;
  *(undefined8 *)((longlong)&uStackX_20 + lVar14) = uVar16;
  if ((((bVar11 & 0x1c) - 4 & 0xffffffeb) == 0) && ((bVar11 & 0x1c) != 0x18)) {
    sVar35 = *param_4;
    *param_1 = sVar35;
    if (sVar35 != 0) {
      if (((*param_4 == 0) || (*(longlong **)(param_4 + 8) == (longlong *)0x0)) ||
         (**(longlong **)(param_4 + 8) == 0)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100a39;
        func_0x(param_1 + 1);
        *(undefined8 *)(param_1 + 8) = uVar16;
      }
      else {
        *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100a24;
        func_0x(param_1);
        *(undefined8 *)(param_1 + 8) = uVar16;
        puVar28 = &stack0xffffffffffffffc0 + lVar14;
      }
      goto LAB_;
    }
    uVar23 = *(uint *)(param_4 + 2);
    puVar1 = (ushort *)(param_1 + 1);
    iVar34 = 0;
    if (uVar23 == 0) {
      pbVar22 = *(byte **)(param_4 + 4);
      uVar23 = *(uint *)(param_4 + 8);
      uVar21 = (ulonglong)uVar23;
      *puVar25 = 0;
      *(uint *)(param_4 + 10) = uVar23;
      bVar11 = *pbVar22;
      if ((bVar11 & 0x10) != 0) {
        uVar23 = uVar23 + 2 + (*(ushort *)(pbVar22 + uVar21) + 7 >> 3);
        uVar21 = (ulonglong)uVar23;
        *(uint *)(param_4 + 10) = uVar23;
        bVar11 = *pbVar22;
      }
      uVar27 = 0;
      if ((bVar11 & 0x20) == 0) {
        *(int *)(param_4 + 2) = (int)uVar21;
        param_4[0xe] = 0;
        *(int *)(param_4 + 0xc) = (int)uVar21;
      }
      else {
        puVar31 = (ushort *)(pbVar22 + uVar21);
        *(ushort **)(&stack0x00000038 + lVar14) = puVar31;
        uVar36 = *puVar31;
        param_4[0xe] = uVar36;
        if (uVar36 == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100104;
          cVar12 = func_0x(0x1108e10);
          if (cVar12 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10010d;
            lVar15 = func_0x();
            if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100127;
              cVar12 = func_0x(0x1108e10);
              if (cVar12 == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100142;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar14) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100166;
                (*_DAT_)(1,0x9f881c,0xb18908,0x80f);
              }
            }
          }
          uVar16 = *(undefined8 *)(param_4 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100174;
          func_0x(uVar16,3);
          uVar36 = param_4[0xe];
          uVar21 = (ulonglong)*(uint *)(param_4 + 10);
          pbVar22 = *(byte **)(param_4 + 4);
        }
        uVar23 = (int)uVar21 + (uVar36 + 1) * 2;
        *(uint *)(param_4 + 0xc) = uVar23;
        if (0x1f9e < uVar23) {
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1001a7;
          cVar12 = func_0x(0x1108e10);
          if (cVar12 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1001b0;
            lVar15 = func_0x();
            if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1001ca;
              cVar12 = func_0x(0x1108e10);
              if (cVar12 == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1001e6;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar14) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10020a;
                (*_DAT_)(1,0x9f881c,0xb18908,0x816);
              }
            }
          }
          uVar16 = *(undefined8 *)(param_4 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100218;
          func_0x(uVar16,4);
          uVar36 = param_4[0xe];
          uVar23 = *(uint *)(param_4 + 0xc);
          pbVar22 = *(byte **)(param_4 + 4);
        }
        uVar37 = (ulonglong)uVar36;
        uVar24 = puVar31[uVar37] & 0x7fff;
        *(uint *)(param_4 + 2) = uVar24;
        if (uVar24 < uVar23) {
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10024d;
          cVar12 = func_0x(0x1108e10);
          if (cVar12 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100256;
            lVar15 = func_0x();
            if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100270;
              cVar12 = func_0x(0x1108e10);
              if (cVar12 == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10028c;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar14) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1002b0;
                (*_DAT_)(1,0x9f881c,0xb18908,0x81d);
              }
            }
          }
          uVar16 = *(undefined8 *)(param_4 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1002be;
          func_0x(uVar16,4);
          uVar23 = *(uint *)(param_4 + 0xc);
          uVar37 = (ulonglong)(ushort)param_4[0xe];
          uVar24 = *(uint *)(param_4 + 2);
          pbVar22 = *(byte **)(param_4 + 4);
        }
        iVar41 = iVar34;
        if ((short)uVar37 != 0) {
          do {
            puVar31 = puVar31 + 1;
            uVar24 = *puVar31 & 0x7fff;
            if ((uVar24 < uVar23) || (*(uint *)(param_4 + 2) < uVar24)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10030f;
              cVar12 = func_0x(0x1108e10);
              if (cVar12 != '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100318;
                lVar15 = func_0x();
                if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100332;
                  cVar12 = func_0x(0x1108e10);
                  if (cVar12 == '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10034e;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar14) = 0;
                    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100374;
                    (*_DAT_)(1,0x9f881c,0xb18908,0x82a);
                  }
                }
              }
              uVar16 = *(undefined8 *)(param_4 + 4);
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100382;
              func_0x(uVar16,4);
            }
            uVar37 = (ulonglong)(ushort)param_4[0xe];
            iVar41 = iVar41 + 1;
            uVar23 = uVar24;
          } while (iVar41 < (int)(uint)(ushort)param_4[0xe]);
          pbVar22 = *(byte **)(param_4 + 4);
          uVar24 = *(uint *)(param_4 + 2);
          puVar31 = *(ushort **)(&stack0x00000038 + lVar14);
        }
        uVar21 = (ulonglong)uVar24;
        if ((short)puVar31[(ulonglong)((int)uVar37 - 1) + 1] < 0) {
          lVar15 = *(longlong *)(&stack0x00000038 + lVar14);
          uVar38 = uVar37;
LAB_:
          sVar35 = (short)uVar37;
          uVar24 = *(ushort *)(pbVar22 + uVar38 * 2 + (ulonglong)*(uint *)(param_4 + 10)) & 0x7fff;
          if ((int)uVar38 == 1) {
            uVar30 = *(uint *)(param_4 + 0xc);
            uVar20 = uVar30;
LAB_:
            if ((uVar24 < uVar30) || (uVar23 = *(uint *)(param_4 + 2), uVar23 < uVar24))
            goto LAB_;
          }
          else {
            uVar20 = *(uint *)(param_4 + 0xc);
            uVar30 = *(ushort *)(pbVar22 + uVar38 * 2 + ((ulonglong)*(uint *)(param_4 + 10) - 2)) &
                     0x7fff;
            if (uVar20 <= uVar30) goto LAB_;
LAB_:
            *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100414;
            func_0x(pbVar22,7);
            uVar20 = *(uint *)(param_4 + 0xc);
            uVar23 = *(uint *)(param_4 + 2);
            pbVar22 = *(byte **)(param_4 + 4);
            sVar35 = param_4[0xe];
          }
          uVar21 = (ulonglong)uVar23;
          if ((uVar20 <= uVar30) && (uVar30 <= uVar23)) {
            if (*(ushort *)(pbVar22 + uVar30) == 5) {
              *puVar25 = *puVar25 | 2;
              param_4[0xe] = sVar35 + -1;
              uVar37 = *(ulonglong *)(param_4 + 4);
              uVar38 = (ulonglong)(uVar30 & 0xffff);
              uVar21 = uVar38 + uVar37;
              param_4[0x15] = (short)uVar30;
              uVar36 = param_4[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar21 + 2) & 0x4000) != 0) {
                uVar36 = *(ushort *)(uVar21 + 2) & 0x3800 | param_4[0x16] & 0xc7ffU;
              }
              param_4[0x16] = uVar36;
              uVar13 = (uVar36 ^ *(ushort *)(uVar21 + 2)) & 0x7ff ^ uVar36;
              param_4[0x16] = uVar13;
              uVar39 = uVar37 + 4 +
                       (ulonglong)((uVar13 & 0x7ff) * 2) + uVar38 + (uVar36 >> 0xb & 7) * 2;
              if (uVar39 < uVar21) {
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10053a;
                func_0x(uVar21,0x19);
                uVar13 = param_4[0x16];
                uVar38 = (ulonglong)(ushort)param_4[0x15];
                uVar37 = (ulonglong)*(uint *)(param_4 + 4);
              }
              if (uVar24 - uVar30 <
                  (((uVar13 & 0x7ff) * 2 - (int)uVar38) - (int)uVar37) + (int)uVar39) {
                lVar15 = *(longlong *)(param_4 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100578;
                func_0x(uVar38 + lVar15,0x19);
                uVar13 = param_4[0x16];
              }
              if (((uVar13 & 0x3800) != 0) &&
                 (puVar31 = (ushort *)
                            (*(longlong *)(param_4 + 4) + 4 + (ulonglong)(ushort)param_4[0x15]),
                 iVar41 = iVar34, (uVar13 & 0x3800) != 0)) {
                do {
                  if ((uVar13 & 0x7ff) < (*puVar31 & 0x7ff)) {
                    uVar36 = param_4[0x15];
                    lVar15 = *(longlong *)(param_4 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1005d6;
                    func_0x((ulonglong)uVar36 + lVar15,0x1a);
                    uVar13 = param_4[0x16];
                  }
                  iVar41 = iVar41 + 1;
                  puVar31 = puVar31 + 1;
                } while (iVar41 < (int)(uVar13 >> 0xb & 7));
              }
              pbVar22 = *(byte **)(param_4 + 4);
              uVar21 = (ulonglong)*(uint *)(param_4 + 2);
            }
            else if (0x3ff < *(ushort *)(pbVar22 + uVar30)) {
              *puVar25 = *puVar25 | 1;
              uVar36 = sVar35 - 1;
              param_4[0xe] = uVar36;
              if (uVar36 != 0) goto code_r0x0010046e;
            }
            goto LAB_;
          }
          goto LAB_;
        }
      }
LAB_:
      if ((*pbVar22 & 0x40) == 0) {
        *(undefined4 *)(param_4 + 0x13) = 0;
      }
      else {
        *(int *)(param_4 + 0x13) = *(int *)(param_4 + 2);
        *(int *)(param_4 + 2) = *(int *)(param_4 + 2) + 0xe;
        *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100636;
        uVar16 = func_0x(puVar25);
        *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100642;
        func_0x(uVar16,&stack0x00000028 + lVar14);
        uVar36 = *(ushort *)(&stack0x0000002e + lVar14);
        uVar13 = uVar36;
        if ((((uint)(int)(short)uVar36 >> 1 ^ (int)(short)uVar36) & 0x2000) != 0) {
          uVar13 = uVar36 & 0xdfff;
          if ((uVar36 & 0x4000) != 0) {
            uVar13 = uVar36 | 0x2000;
          }
        }
        if (uVar13 == 0xfffc) {
          uVar27 = (uint)(*(ushort *)(&stack0x0000002c + lVar14) >> 5);
        }
        *(uint *)(param_4 + 2) = *(int *)(param_4 + 2) + uVar27;
        uVar21 = (ulonglong)*(uint *)(param_4 + 2);
        pbVar22 = *(byte **)(param_4 + 4);
      }
      if ((*(byte **)(param_4 + 0xf) != (byte *)0x0) &&
         (*(byte **)(param_4 + 0xf) < pbVar22 + uVar21)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1006c2;
        cVar12 = func_0x(0x1108e10);
        if (cVar12 != '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1006cb;
          lVar15 = func_0x();
          if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1006e5;
            cVar12 = func_0x(0x1108e10);
            if (cVar12 == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100701;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar14) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100725;
              (*_DAT_)(1,0x9f881c,0xb18908,0x886);
            }
          }
        }
        uVar16 = *(undefined8 *)(param_4 + 4);
        *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100733;
        func_0x(uVar16,0x12);
        uVar21 = (ulonglong)*(uint *)(param_4 + 2);
      }
      uVar23 = (uint)uVar21;
      if ((uVar23 == 0) || (0x3f3c < uVar23)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100754;
        cVar12 = func_0x(0x1108e10);
        if (cVar12 != '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10075d;
          lVar15 = func_0x();
          if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100777;
            cVar12 = func_0x(0x1108e10);
            if (cVar12 == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100793;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar14) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1007b7;
              (*_DAT_)(1,0x9f881c,0xb18908,0x88b);
            }
          }
        }
        uVar16 = *(undefined8 *)(param_4 + 4);
        *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1007c5;
        func_0x(uVar16,5);
        uVar23 = *(uint *)(param_4 + 2);
      }
LAB_:
      uVar16 = *(undefined8 *)((longlong)&uStackX_20 + lVar14);
      param_2 = *(undefined8 *)((longlong)&uStackX_8 + lVar14);
      param_3 = (ulonglong)*(uint *)((longlong)auStackX_14 + lVar14 + 4);
    }
    if ((uVar23 < 9) &&
       (((**(byte **)(param_4 + 4) & 0xe) == 0 || ((**(byte **)(param_4 + 4) & 0xe) == 0xc)))) {
      uVar23 = 9;
    }
    *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_4 + 8);
    *puVar1 = *puVar25;
    *(undefined4 *)(param_1 + 2) = *(undefined4 *)(param_4 + 2);
    param_1[0xe] = param_4[0xe];
    *(undefined4 *)(param_1 + 10) = *(undefined4 *)(param_4 + 10);
    *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_4 + 0xc);
    *(undefined4 *)(param_1 + 0x13) = *(undefined4 *)(param_4 + 0x13);
    uVar6 = *(undefined8 *)(param_4 + 4);
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100836;
    func_0x(param_2,param_3 & 0xffffffff,uVar6,uVar23);
    *(undefined8 *)(param_1 + 4) = *(undefined8 *)((longlong)&uStackX_8 + lVar14);
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100846;
    iVar41 = func_0x(puVar1);
    if (iVar41 == 0) {
      *(undefined8 *)(*(longlong *)(&stack0x00000030 + lVar14) + 0x10) = uVar16;
      puVar28 = &stack0xffffffffffffffc0 + lVar14;
      goto LAB_;
    }
    lVar15 = *(longlong *)(param_1 + 4);
    puVar25 = (ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar15);
    uVar23 = *puVar25 - 1;
    if ((*(byte *)puVar1 & 1) == 0) {
      uVar23 = (uint)*puVar25;
    }
    uVar27 = puVar25[(int)uVar23] & 0x7fff;
    if (uVar23 == 1) {
      uVar23 = *(uint *)(param_1 + 0xc);
LAB_:
      if ((uVar27 < uVar23) || (*(uint *)(param_1 + 2) < uVar27)) goto LAB_;
    }
    else {
      uVar23 = puVar25[(longlong)(int)uVar23 + -1] & 0x7fff;
      if (*(uint *)(param_1 + 0xc) <= uVar23) goto LAB_;
LAB_:
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1008a6;
      func_0x(lVar15,7);
    }
    uVar37 = *(ulonglong *)(param_1 + 4);
    uVar38 = (ulonglong)(uVar23 & 0xffff);
    uVar36 = param_1[0x16] & 0xc7ff;
    uVar21 = uVar38 + uVar37;
    param_1[0x15] = (short)uVar23;
    if ((*(ushort *)(uVar21 + 2) >> 0xe & 1) != 0) {
      uVar36 = *(ushort *)(uVar21 + 2) & 0x3800 | uVar36;
    }
    param_1[0x16] = uVar36;
    uVar13 = (uVar36 ^ *(ushort *)(uVar21 + 2)) & 0x7ff ^ uVar36;
    param_1[0x16] = uVar13;
    uVar39 = (ulonglong)((uVar13 & 0x7ff) * 2) + 4 + uVar37 + (uVar36 >> 0xb & 7) * 2 + uVar38;
    if (uVar39 < uVar21) {
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10093d;
      func_0x(uVar21,0x19);
      uVar13 = param_1[0x16];
      uVar38 = (ulonglong)(ushort)param_1[0x15];
      uVar37 = (ulonglong)*(uint *)(param_1 + 4);
    }
    if (uVar27 - uVar23 < (((uVar13 & 0x7ff) * 2 - (int)uVar38) - (int)uVar37) + (int)uVar39) {
      lVar15 = *(longlong *)(param_1 + 4);
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100976;
      func_0x(uVar38 + lVar15,0x19);
      uVar13 = param_1[0x16];
    }
    puVar28 = &stack0xffffffffffffffc0 + lVar14;
    if (((uVar13 & 0x3800) != 0) &&
       (puVar25 = (ushort *)(*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]),
       puVar28 = &stack0xffffffffffffffc0 + lVar14, (uVar13 & 0x3800) != 0)) {
      do {
        if ((uVar13 & 0x7ff) < (*puVar25 & 0x7ff)) {
          uVar36 = param_1[0x15];
          lVar15 = *(longlong *)(param_1 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1009d8;
          func_0x((ulonglong)uVar36 + lVar15,0x1a);
          uVar13 = param_1[0x16];
        }
        iVar34 = iVar34 + 1;
        puVar25 = puVar25 + 1;
        puVar28 = &stack0xffffffffffffffc0 + lVar14;
      } while (iVar34 < (int)(uVar13 >> 0xb & 7));
    }
  }
  else {
    puVar33 = (undefined8 *)0x0;
    *param_1 = 1;
    uVar36 = *puVar25;
    uVar23 = (uint)uVar36;
    *(uint *)(&stack0x0000006c + lVar14) = (uint)uVar36;
    uVar21 = (ulonglong)uVar36 * 0x20 + 0xf;
    if (uVar21 <= (ulonglong)uVar36 * 0x20) {
      uVar21 = 0xffffffffffffff0;
    }
    uVar21 = uVar21 & 0xfffffffffffffff0;
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100a77;
    func_0x();
    lVar15 = -uVar21;
    puVar28 = (undefined *)((longlong)&uStackX_20 + lVar15 + lVar14 + -0x20);
    *(longlong *)(&stack0x00000038 + lVar14) = (longlong)&uStackX_20 + lVar15 + lVar14 + -0x20;
    *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100a94;
    func_0x((longlong)&uStackX_20 + lVar15 + lVar14 + -0x20,0,uVar23 << 5);
    uVar16 = *(undefined8 *)((longlong)&uStackX_8 + lVar14);
    uVar36 = *puVar25;
    *(ulonglong *)(&stack0x00000048 + lVar14) =
         (ulonglong)(ushort)param_4[0xe] + (ulonglong)(ushort)param_4[0xd] +
         *(longlong *)(param_4 + 4);
    *(undefined2 *)((longlong)asStackX_10 + lVar14) = 0;
    *(short **)(&stack0x00000080 + lVar14) = param_1 + 1;
    *(uint *)(&stack0xffffffffffffffe0 + lVar15 + lVar14) = (uint)uVar36;
    *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100acc;
    func_0x(param_1 + 1,uVar16);
    uVar36 = *(ushort *)(&stack0x0000005e + lVar14);
    if (*(int *)(param_4 + 2) == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100ae5;
      func_0x(puVar25);
    }
    puVar40 = (undefined8 *)(&stack0x00000090 + lVar14);
    *(ushort *)(&stack0x00000050 + lVar14) = *puVar25;
    uVar13 = 0;
    *(undefined4 *)(&stack0x00000058 + lVar14) = 0;
    *(undefined8 *)(&stack0x00000060 + lVar14) = 0;
    *(ushort *)(&stack0x0000005e + lVar14) = uVar36 & 0xffe0;
    puVar42 = puVar33;
    while (uVar13 != *(ushort *)(&stack0x00000050 + lVar14)) {
      uVar13 = uVar13 + 1;
      *(ushort *)(&stack0x00000052 + lVar14) = uVar13;
      *(int *)(&stack0x00000058 + lVar14) = (int)(short)(*(short *)(&stack0x00000058 + lVar14) + -1)
      ;
      *(ushort *)(&stack0x0000005c + lVar14) = uVar13;
      *(undefined4 *)((longlong)&uStackX_20 + lVar14 + -0x1c) = 0;
      puVar17 = puVar33;
      if (*puVar25 < uVar13) {
code_r0x00100b4f:
        *puVar3 = 0;
        puVar32 = puVar33;
      }
      else {
        uVar13 = *(ushort *)(&stack0x00000052 + lVar14);
        bVar11 = *(byte *)((longlong)((int)(uVar13 - 1) / 2) + (ulonglong)(ushort)param_4[0xc] +
                          *(longlong *)(param_4 + 4));
        bVar19 = bVar11 >> 4;
        if (((&stack0x00000052)[lVar14] & 1) != 0) {
          bVar19 = bVar11 & 0xf;
        }
        switch(bVar19) {
        case 0:
          goto code_r0x00100b4f;
        case 1:
          puVar32 = (undefined8 *)0x0;
          *puVar3 = 0;
          puVar17 = (undefined8 *)0x1348d66;
          break;
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 9:
          puVar17 = *(undefined8 **)(&stack0x00000048 + lVar14);
          uVar36 = *(ushort *)((ulonglong)bVar19 * 4 + 0x821c50);
          puVar32 = (undefined8 *)(ulonglong)uVar36;
          *puVar3 = (uint)uVar36;
          *(byte **)(&stack0x00000048 + lVar14) = (byte *)((longlong)puVar17 + (longlong)puVar32);
          break;
        case 10:
          if (*(int *)(param_4 + 2) == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100bd0;
            func_0x(puVar25);
          }
          sVar35 = *(short *)((longlong)asStackX_10 + lVar14);
          *(short *)((longlong)asStackX_10 + lVar14) = sVar35 + 1;
          *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100bed;
          puVar17 = (undefined8 *)func_0x(puVar25,sVar35,puVar3,&stack0x00000068 + lVar14);
          puVar32 = (undefined8 *)(ulonglong)*puVar3;
          if (*(int *)(&stack0x00000068 + lVar14) != 0) {
            *(undefined4 *)((longlong)&uStackX_20 + lVar14 + -0x1c) = 1;
          }
          break;
        case 0xb:
          puVar32 = (undefined8 *)0x0;
          *puVar3 = 0;
          *(undefined4 *)((longlong)&uStackX_20 + lVar14 + -0x1c) = 2;
          puVar17 = (undefined8 *)0x77d4b0;
          break;
        case 0xc:
          puVar17 = *(undefined8 **)(&stack0x00000048 + lVar14);
          puVar32 = (undefined8 *)0x1;
          *puVar3 = 1;
          *(undefined4 *)((longlong)&uStackX_20 + lVar14 + -0x1c) = 4;
          *(byte **)(&stack0x00000048 + lVar14) = (byte *)((longlong)puVar17 + 1);
          break;
        default:
          puVar32 = (undefined8 *)0x0;
          *puVar3 = 0;
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar15 + lVar14) = 0x773d80;
          *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100c84;
          (*_DAT_)(1,0xb7a110,0xb80530,0x11f9);
        }
      }
      *(ushort *)((longlong)asStackX_10 + lVar14 + 2) = uVar13 - 1;
      uVar23 = *(uint *)((longlong)&uStackX_20 + lVar14 + -0x1c) & 1;
      *(uint *)(&stack0x00000028 + lVar14) = uVar23;
      uVar27 = (uint)puVar32;
      if (uVar23 == 0) {
        puVar2 = (uint *)((longlong)&uStackX_20 + lVar14 + -0x1c);
        *puVar2 = *puVar2 & 0xfffffffb;
        if ((puVar17 == (undefined8 *)0x0) || (puVar17 == (undefined8 *)0x77d4b0)) {
          *(undefined4 *)((longlong)auStackX_14 + lVar14) = 0;
        }
        else {
          *(longlong *)(&stack0xfffffffffffffff8 + lVar15 + lVar14) =
               (longlong)&uStackX_20 + lVar14 + -0x1c;
          *(longlong *)(&stack0xfffffffffffffff0 + lVar15 + lVar14) = (longlong)auStackX_14 + lVar14
          ;
          uVar16 = *(undefined8 *)((longlong)&uStackX_20 + lVar14);
          *(int *)(&stack0xffffffffffffffe8 + lVar15 + lVar14) = 0x239e - (int)puVar42;
          *(undefined8 **)(&stack0xffffffffffffffe0 + lVar15 + lVar14) = puVar40;
          *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100ce6;
          puVar17 = (undefined8 *)
                    func_0x(uVar16,&stack0x00000058 + lVar14,puVar17,puVar32);
          if (puVar17 != (undefined8 *)0x0) {
            uVar23 = *(uint *)(&stack0x00000028 + lVar14);
            if (puVar17 == puVar40) {
              uVar27 = *(uint *)((longlong)auStackX_14 + lVar14);
              puVar42 = (undefined8 *)(ulonglong)((int)puVar42 + uVar27);
              puVar40 = (undefined8 *)((longlong)puVar40 + (ulonglong)uVar27);
            }
            else {
              uVar27 = *(uint *)((longlong)auStackX_14 + lVar14);
            }
            goto LAB_;
          }
        }
        puVar28 = *(undefined **)(&stack0x00000038 + lVar14);
        *(uint *)(puVar28 + (ulonglong)*(ushort *)((longlong)asStackX_10 + lVar14 + 2) * 0x20 + 0xc)
             = *(uint *)(puVar28 +
                        (ulonglong)*(ushort *)((longlong)asStackX_10 + lVar14 + 2) * 0x20 + 0xc) | 2
        ;
      }
      else {
        *(uint *)((longlong)auStackX_14 + lVar14) = uVar27;
LAB_:
        uVar24 = *(uint *)((longlong)&uStackX_20 + lVar14 + -0x1c);
        uVar4 = *(undefined4 *)(&stack0x00000058 + lVar14);
        uVar5 = *(undefined4 *)(&stack0x0000005c + lVar14);
        uVar9 = *(undefined4 *)(&stack0x00000060 + lVar14);
        uVar10 = *(undefined4 *)(&stack0x00000064 + lVar14);
        ppbVar26 = (byte **)((ulonglong)*(ushort *)((longlong)asStackX_10 + lVar14 + 2) * 0x20 +
                            *(longlong *)(&stack0x00000038 + lVar14));
        *ppbVar26 = (byte *)puVar17;
        puVar28 = *(undefined **)(&stack0x00000038 + lVar14);
        *(uint *)(ppbVar26 + 1) = uVar27;
        *(uint *)((longlong)ppbVar26 + 0xc) =
             (uVar24 >> 2 & 1) << 2 | *(uint *)((longlong)ppbVar26 + 0xc) & 0xfffffff0 |
             uVar23 & 0xfffffff1;
        *(undefined4 *)(ppbVar26 + 2) = uVar4;
        *(undefined4 *)((longlong)ppbVar26 + 0x14) = uVar5;
        *(undefined4 *)(ppbVar26 + 3) = uVar9;
        *(undefined4 *)((longlong)ppbVar26 + 0x1c) = uVar10;
      }
    }
    uVar4 = *(undefined4 *)((longlong)auStackX_14 + lVar14 + 4);
    lVar7 = *(longlong *)(&stack0x00000080 + lVar14);
    uVar5 = *(undefined4 *)(&stack0x0000006c + lVar14);
    *(undefined **)(&stack0xffffffffffffffe8 + lVar15 + lVar14) = &stack0x00000078 + lVar14;
    *(undefined **)(&stack0xffffffffffffffe0 + lVar15 + lVar14) = puVar28;
    *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100d8c;
    func_0x(lVar7,uVar4,uVar4,uVar5);
    pbVar22 = *(byte **)(param_4 + 4);
    if (((*pbVar22 & 0x1c) - 0x10 & 0xfffffffb) == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100da8;
      puVar40 = (undefined8 *)func_0x(puVar25);
      if (puVar40 == (undefined8 *)0x0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100dc1;
        (*_DAT_)(6,0x55,0x10,3);
        *(undefined8 *)(&stack0x00000070 + lVar14) = 0;
        *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100dcd;
        puVar18 = (undefined4 *)(*_DAT_)();
        *puVar18 = 0x16;
        *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100dd9;
        (*_DAT_)();
      }
      else {
        *(undefined8 *)(&stack0x00000070 + lVar14) = *puVar40;
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100dee;
      func_0x(lVar7,&stack0x00000070 + lVar14);
      pbVar22 = *(byte **)(param_4 + 4);
    }
    lVar8 = *(longlong *)(&stack0x00000088 + lVar14);
    if ((*pbVar22 & 2) != 0) {
      if (*(int *)(param_4 + 2) == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100e0f;
        func_0x(puVar25);
      }
      *(undefined8 *)((longlong)&uStackX_8 + lVar14) = 0;
      uVar13 = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100e22;
      func_0x(puVar25);
      uVar36 = 0;
      if (((**(byte **)(param_4 + 4) & 2) != 0) &&
         (puVar40 = (undefined8 *)(*(byte **)(param_4 + 4) + *(uint *)(param_4 + 0x18)), uVar36 = 0,
         puVar40 != (undefined8 *)0x0)) {
        uVar16 = *puVar40;
        *(int *)((longlong)&uStackX_8 + lVar14) = (int)uVar16;
        uVar13 = (ushort)((ulonglong)uVar16 >> 0x30);
        *(ushort *)((longlong)asStackX_10 + lVar14 + -2) = uVar13;
        uVar36 = (ushort)((ulonglong)uVar16 >> 0x20);
        *(ushort *)((longlong)asStackX_10 + lVar14 + -4) = uVar36;
      }
      if (*(int *)(param_4 + 2) == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100e5a;
        func_0x(puVar25);
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100e62;
      func_0x(puVar25);
      if (((**(byte **)(param_4 + 4) & 2) == 0) ||
         (pbVar22 = *(byte **)(param_4 + 4) + *(uint *)(param_4 + 0x18), pbVar22 == (byte *)0x0)) {
        *(undefined4 *)(&stack0x00000040 + lVar14) = 0;
        *(undefined2 *)(&stack0x00000044 + lVar14) = 0;
      }
      else {
        *(undefined4 *)(&stack0x00000040 + lVar14) = *(undefined4 *)(pbVar22 + 8);
        *(undefined2 *)(&stack0x00000044 + lVar14) = *(undefined2 *)(pbVar22 + 0xc);
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100e96;
      func_0x(lVar7,&stack0x00000040 + lVar14);
      uVar29 = uVar13;
      if ((((uint)(int)(short)uVar13 >> 1 ^ (int)(short)uVar13) & 0x2000) != 0) {
        uVar29 = uVar13 & 0xdfff;
        if ((uVar13 >> 0xe & 1) != 0) {
          uVar29 = uVar13 | 0x2000;
        }
      }
      if ((uVar29 == 0xfffc) && (0x1f < uVar36)) {
        pbVar22 = *(byte **)(param_4 + 4);
        if ((*pbVar22 & 2) != 0) {
          if (*(int *)(param_4 + 2) == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100ef1;
            func_0x(puVar25);
            pbVar22 = *(byte **)(lVar8 + 8);
          }
          puVar33 = (undefined8 *)(pbVar22 + (ulonglong)*(uint *)(param_4 + 0x18) + 0xe);
        }
        if (*(int *)(lVar7 + 2) == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100f13;
          func_0x(lVar7);
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100f1b;
        func_0x(lVar7);
        pbVar22 = *(byte **)(lVar7 + 6);
        if ((*pbVar22 & 2) == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100f48;
          func_0x(0,(longlong)&uStackX_8 + lVar14,puVar33);
        }
        else {
          uVar23 = *(uint *)(lVar7 + 0x2e);
          *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100f37;
          func_0x(pbVar22 + uVar23,(longlong)&uStackX_8 + lVar14,puVar33);
        }
      }
      else {
        if (*(int *)(lVar7 + 2) == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100f58;
          func_0x(lVar7);
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100f60;
        func_0x(lVar7);
        if ((**(byte **)(lVar7 + 6) & 2) != 0) {
          puVar33 = (undefined8 *)(*(byte **)(lVar7 + 6) + *(uint *)(lVar7 + 0x2e));
        }
        *puVar33 = *(undefined8 *)((longlong)&uStackX_8 + lVar14);
      }
      *(undefined4 *)(lVar7 + 2) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100f88;
      func_0x(lVar7);
    }
    puVar28 = &stack0xffffffffffffffc0 + lVar15 + lVar14;
    if (((**(byte **)(param_4 + 4) & 0x1c) - 4 & 0xffffffe7) == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar15 + lVar14) = 0x100fa5;
      func_0x(lVar7);
      puVar28 = &stack0xffffffffffffffc0 + lVar15 + lVar14;
    }
  }
  *(undefined8 *)(*(longlong *)(&stack0x00000030 + lVar14) + 0x10) =
       *(undefined8 *)((longlong)&uStackX_20 + lVar14);
LAB_:
  uVar21 = *(ulonglong *)(&stack0x00002430 + lVar14);
  *(undefined8 *)(puVar28 + -8) = 0x100fc0;
  func_0x(uVar21 ^ (ulonglong)puVar3);
  return;
code_r0x0010046e:
  uVar37 = (ulonglong)uVar36;
  uVar38 = (ulonglong)(uint)uVar36;
  if (-1 < *(short *)(lVar15 + 2 + (ulonglong)(uVar36 - 1) * 2)) goto LAB_;
  goto LAB_;
}

