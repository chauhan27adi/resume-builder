
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2,uint *param_3,undefined8 *param_4,
                 undefined8 param_5)

{
  byte bVar1;
  code *pcVar2;
  uint *puVar3;
  undefined8 *puVar4;
  char cVar5;
  undefined2 uVar6;
  undefined4 uVar7;
  int iVar8;
  uint uVar9;
  int iVar10;
  longlong lVar11;
  longlong *plVar12;
  longlong *plVar13;
  undefined8 uVar14;
  longlong lVar15;
  longlong lVar16;
  undefined8 uVar17;
  ulonglong uVar18;
  uint uVar19;
  uint uVar21;
  longlong lVar22;
  ulonglong uVar23;
  undefined4 *puVar24;
  undefined *puVar25;
  uint uVar26;
  undefined4 uVar27;
  undefined8 uVar28;
  uint unaff_R13D;
  longlong unaff_GS_OFFSET;
  uint uStackX_10;
  uint auStackX_14 [2];
  undefined4 uStackX_1c;
  longlong lStackX_20;
  longlong lStack_2230;
  undefined8 *puStack_2228;
  undefined4 uStack_2218;
  undefined8 uStack_2210;
  undefined8 uStack_2208;
  undefined4 uStack_2200;
  undefined8 uStack_21f8;
  undefined uStack_21f0;
  longlong lStack_21e8;
  longlong lStack_21e0;
  longlong lStack_21d8;
  longlong *plStack_21d0;
  undefined auStack_21c8 [16];
  byte bStack_21b8;
  longlong lStack_21a8;
  undefined8 auStack_21a0 [2];
  undefined8 uStack_2190;
  undefined4 uStack_2188;
  undefined4 uStack_2178;
  undefined uStack_2170;
  undefined4 uStack_2168;
  undefined8 uStack_2158;
  undefined4 uStack_2150;
  byte bStack_214c;
  undefined8 *puStack_2148;
  longlong lStack_2140;
  uint uStack_2138;
  longlong lStack_2130;
  uint uStack_2128;
  longlong lStack_2120;
  undefined8 uStack_2118;
  undefined8 *puStack_2110;
  undefined8 *puStack_2108;
  undefined uStack_2100;
  byte bStack_20ff;
  undefined auStack_20e0 [40];
  undefined auStack_20b8 [176];
  undefined8 uStack_2008;
  undefined auStack_1ff8 [8096];
  ulonglong uStack_58;
  undefined8 uStack_48;
  ulonglong uVar20;
  
  uStack_48 = 0x10001f;
  lVar11 = func_0x();
  uVar17 = param_5;
  lVar11 = -lVar11;
  uStack_2118 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar11);
  *(uint **)(&stack0x00000030 + lVar11) = param_3;
  lVar15 = param_1[0xe];
  *(longlong *)((longlong)&lStackX_20 + lVar11) = lVar15;
  uVar18 = 0;
  lStack_21e0 = 0;
  *(uint *)((longlong)auStackX_14 + lVar11) = unaff_R13D & 0xffffff00;
  puStack_2148 = param_4;
  if ((DAT_ != '\0') &&
     (*(longlong *)(*(longlong *)(*(longlong *)(param_1[0x65] + 0x30) + 0x6b0) + 0x14c8) != 0)) {
    lVar15 = param_1[0xf];
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1000a9;
    lStack_21e0 = func_0x(lVar15,1);
    lVar22 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar15 = *(longlong *)(lVar22 + 0x100);
    if (lVar15 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1000e2;
      (*_DAT_)();
      lVar15 = *(longlong *)(lVar22 + 0x100);
    }
    uVar14 = *(undefined8 *)(param_1[0x65] + 0x290);
    uVar28 = *(undefined8 *)(lVar15 + 1000);
    pcVar2 = *_DAT_;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100115;
    plVar12 = (longlong *)(*pcVar2)(uVar28,uVar14,0x1260110,0xb66);
    lVar15 = *plVar12;
    pcVar2 = *(code **)(*(longlong *)param_1[0xd] + 8);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10012a;
    uVar6 = (*pcVar2)();
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    pcVar2 = *(code **)(lVar15 + 0x38);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100141;
    plVar13 = (longlong *)(*pcVar2)(plVar12,uVar6,0,0);
    lVar15 = *plVar13;
    pcVar2 = *(code **)(*(longlong *)param_1[0xd] + 0x10);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100152;
    uVar7 = (*pcVar2)();
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar11) = 0;
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0;
    (&stack0xffffffffffffffe8)[lVar11] = 1;
    (&stack0xffffffffffffffe0)[lVar11] = 0;
    pcVar2 = *(code **)(lVar15 + 0x78);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100172;
    plVar13 = (longlong *)(*pcVar2)(plVar13,uVar7,1,0);
    pcVar2 = *(code **)(*plVar13 + 0x78);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10017b;
    plVar13 = (longlong *)(*pcVar2)(plVar13);
    pcVar2 = *(code **)(*plVar13 + 0x3f8);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100187;
    iVar8 = (*pcVar2)(plVar13);
    *(uint *)((longlong)auStackX_14 + lVar11) = (uint)(iVar8 == 2);
    pcVar2 = *(code **)*plVar12;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1001a6;
    (*pcVar2)(plVar12);
    param_3 = *(uint **)(&stack0x00000030 + lVar11);
    lVar15 = *(longlong *)((longlong)&lStackX_20 + lVar11);
  }
  *(undefined *)(param_1 + 0x45) = 1;
  *(undefined8 *)((longlong)&param_5 + lVar11) = 0;
  lVar22 = **(longlong **)(*(longlong *)(lVar15 + 8) + 0x160);
  uVar19 = *(uint *)(lVar22 + 0x10);
  uVar23 = uVar18;
  if (uVar19 != 0) {
    uVar21 = *(uint *)(lVar22 + 100);
    uVar20 = uVar18;
    do {
      uVar26 = (uint)uVar20;
      if ((uVar21 == 0xffffffff) || (uVar9 = uVar26 + 1, uVar26 < uVar21)) {
        uVar9 = uVar26;
      }
      uVar23 = uVar18;
      if (uVar9 < uVar19) {
        puVar3 = *(uint **)(lVar22 + 8);
        if (uVar9 < *puVar3) {
          uVar23 = ((ulonglong)uVar9 % (ulonglong)puVar3[9]) * 0x1c0 +
                   *(longlong *)
                    (*(longlong *)(puVar3 + 4) + ((ulonglong)uVar9 / (ulonglong)puVar3[9]) * 8);
        }
        else {
          uVar23 = ((ulonglong)(uVar9 - *puVar3) % (ulonglong)puVar3[0x11]) * 0x1c0 +
                   *(longlong *)
                    (*(longlong *)(puVar3 + 0xc) +
                    ((ulonglong)(uVar9 - *puVar3) / (ulonglong)puVar3[0x11]) * 8);
        }
      }
      *(ulonglong *)((longlong)&param_5 + lVar11) = uVar23;
    } while (((((*(byte *)(uVar23 + 0x21) & 2) != 0) || ((*(byte *)(uVar23 + 0x20) & 0x10) != 0)) ||
             (500000 < *(uint *)(uVar23 + 0x3c))) &&
            (uVar20 = (ulonglong)(uVar26 + 1), uVar26 + 1 < uVar19));
    lVar15 = *(longlong *)((longlong)&lStackX_20 + lVar11);
  }
  if (*(char *)(param_3 + 0x17) == '\0') {
    *(undefined4 *)((longlong)&uStackX_10 + lVar11) = 0;
    uVar20 = uVar18;
    if (*param_3 != 0) {
      lVar22 = *(longlong *)(param_3 + 2);
      while( true ) {
        lVar16 = uVar20 * 0x118;
        if ((*(longlong *)(lVar16 + 0x20 + lVar22) != 0) ||
           (*(longlong *)(lVar16 + 0xd8 + lVar22) != 0)) break;
        if ((*(char *)(lVar16 + 4 + lVar22) == -0x43) ||
           (uVar19 = (int)uVar20 + 1, uVar20 = (ulonglong)uVar19, *param_3 <= uVar19)) break;
      }
      *(int *)((longlong)&uStackX_10 + lVar11) = (int)uVar20;
    }
    *(undefined *)(param_3 + 0x17) = 1;
    param_3[0x18] = (uint)uVar20;
  }
  else {
    uVar20 = (ulonglong)param_3[0x18];
    *(uint *)((longlong)&uStackX_10 + lVar11) = param_3[0x18];
  }
  plStack_21d0 = (longlong *)0x0;
  lStack_21d8 = 0;
  *(undefined2 *)(&stack0x00000039 + lVar11) = 0;
  (&stack0x0000003b)[lVar11] = 0;
  (&stack0x00000038)[lVar11] = 0;
  *(undefined4 *)(&stack0x0000003c + lVar11) = 0;
  uVar19 = *param_3;
  *(uint *)((longlong)auStackX_14 + lVar11 + 4) = uVar19;
  if ((uint)uVar20 < uVar19) {
    puVar24 = (undefined4 *)(*(longlong *)(param_3 + 2) + uVar20 * 0x118);
    plStack_21d0 = *(longlong **)(puVar24 + 8);
    lStack_21d8 = uVar20 * 0x50 + *(longlong *)(param_2 + 8);
    uVar7 = *puVar24;
    uVar14 = *(undefined8 *)(*(longlong *)(lVar15 + 8) + 0x160);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100338;
    uVar14 = func_0x(uVar14,uVar7);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100345;
    func_0x(uVar14,&stack0x00000038 + lVar11);
  }
  bStack_21b8 = bStack_21b8 & 0xfe;
  lStack_2140 = param_1[0xf];
  auStack_21c8._8_8_ = *(undefined8 *)((longlong)&lStackX_20 + lVar11);
  auStack_21c8._0_8_ = lStack_2140;
  lStack_21a8 = 0;
  auStack_21a0[0] = 0xf9a910;
  uStack_2190 = 0;
  uStack_2188 = 0;
  uStack_2178 = 0xffffffff;
  uStack_2168 = 0x80000000;
  uStack_2170 = 0;
  uStack_2158 = 0;
  uStack_2150 = 0;
  bStack_214c = bStack_214c & 0xfc;
  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1003c6;
  func_0x(auStack_20b8);
  *(undefined4 *)((longlong)&uStackX_1c + lVar11) = 0xbac;
  lVar22 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar15 = *(longlong *)(lVar22 + 0x100);
  if (lVar15 == 0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100402;
    (*_DAT_)(0);
    lVar15 = *(longlong *)(lVar22 + 0x100);
  }
  uVar14 = *(undefined8 *)(lVar15 + 1000);
  (&stack0xffffffffffffffe0)[lVar11] = 5;
  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100431;
  puStack_2228 = (undefined8 *)(*_DAT_)(0x20,uVar14,0x1260110,0xbac);
  puStack_2110 = puStack_2228;
  if (puStack_2228 == (undefined8 *)0x0) {
    puStack_2228 = (undefined8 *)0x0;
  }
  else {
    lVar22 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar15 = *(longlong *)(lVar22 + 0x100);
    if (lVar15 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100477;
      (*_DAT_)(0);
      lVar15 = *(longlong *)(lVar22 + 0x100);
    }
    lVar22 = param_1[0xf];
    *puStack_2228 = *(undefined8 *)(lVar15 + 1000);
    puStack_2228[1] = lVar22;
    puStack_2228[2] = 0;
    *(undefined *)(puStack_2228 + 3) = 1;
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1004b9;
  puStack_2108 = puStack_2228;
  func_0x(puStack_2228,uVar17);
  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1004c6;
  cVar5 = func_0x(auStack_21c8);
  if (cVar5 != '\0') {
    uVar19 = *(uint *)((longlong)auStackX_14 + lVar11 + 4);
    lStack_2230 = param_2;
    do {
      if ((DAT_ == '\0') ||
         (*(longlong *)(*(longlong *)(*(longlong *)(param_1[0x65] + 0x30) + 0x6b0) + 0x14c8) == 0))
      {
LAB_:
        uVar7 = *(undefined4 *)(lStack_21a8 + 0x20);
        uStack_21f0 = 0;
        lStack_21e8 = 0;
        uStack_21f8 = 0;
        plVar12 = *(longlong **)(*(longlong *)((longlong)&lStackX_20 + lVar11) + 8);
        uVar27 = *(undefined4 *)(uVar23 + 0x24);
        pcVar2 = *(code **)(*plVar12 + 0x168);
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1005c6;
        (*pcVar2)(plVar12,uVar27,uVar7,&uStack_21f8);
        lVar15 = lStack_21d8;
        if (lStack_21e8 == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100dcb;
          (*_DAT_)(0x4f,0x25,0x10,4);
          uStack_2128 = 0;
          lVar22 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          lVar15 = *(longlong *)(lVar22 + 0x100);
          if (lVar15 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100e05;
            (*_DAT_)(0);
            lVar15 = *(longlong *)(lVar22 + 0x100);
          }
          uVar19 = *(uint *)(lVar15 + 0x268) & 1 ^ 1;
          *(uint *)(lVar15 + 0x268) = *(uint *)(lVar15 + 0x268) | 1;
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100e39;
          uStack_2128 = uVar19;
          lStack_2120 = lVar15;
          func_0x(&uStack_21f8);
          *(uint *)(lVar15 + 0x268) = *(uint *)(lVar15 + 0x268) & ~uVar19;
          goto LAB_;
        }
        if ((uint)uVar20 < uVar19) {
          uVar20 = uVar18;
          if (*(int *)(lStack_21e8 + 0x38) != 0) {
            do {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1007d4;
              func_0x(auStack_1ff8,0,0x1f9e);
              bVar1 = *(byte *)(lVar15 + 0x3e);
              uVar23 = (ulonglong)bVar1;
              if (plStack_21d0 == (longlong *)0x0) {
                if (bVar1 == 0xbd) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1008d4;
                  func_0x(&uStack_2100,uVar23);
                  bStack_20ff = bStack_20ff | 1;
                  uVar6 = *(undefined2 *)(*(longlong *)(param_1[0xf] + 0x30) + 0x6b8);
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) =
                       *(undefined8 *)(param_1[0xf] + 0x290);
                  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100906;
                  func_0x(0,0,uVar6,&uStack_2210);
                  uStack_2218 = CONCAT22(uStack_2218._2_2_,0xbd00);
                  puVar25 = &uStack_2100;
                }
                else {
                  uStack_2218 = 3;
                  uStack_2210 = 0;
                  uStack_2208 = 0;
                  uStack_2200 = 0;
                  lVar22 = *(longlong *)
                            ((ulonglong)*(uint *)(*(longlong *)(&stack0x00000030 + lVar11) + 0x60) *
                             0x118 + 0xd8 +
                            *(longlong *)(*(longlong *)(&stack0x00000030 + lVar11) + 8));
                  pcVar2 = *(code **)(lVar22 + 8);
                  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10094f;
                  (*pcVar2)(0,lVar22,&uStack_2218);
                  puVar25 = &stack0x00000038 + lVar11;
                }
LAB_:
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100968;
                uVar19 = (*_DAT_)(&uStack_2218,auStack_1ff8,puVar25,0);
              }
              else {
                pcVar2 = *(code **)(*plStack_21d0 + 0x20);
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1007f3;
                cVar5 = (*pcVar2)(plStack_21d0,&uStack_2218,0);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100801;
                  uVar17 = (*_DAT_)(uVar23);
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = uVar17;
                  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100820;
                  func_0x(0x1fb3,0x10,4,0x11972d8);
                  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100838;
                  (*_DAT_)(0x24,2,0x19,0xfa);
                }
                if (*(char *)((ulonglong)*(byte *)(uVar23 + 0xfa4720) + 0xfa59a0) == '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1008b2;
                  func_0x(auStack_20e0,uVar23);
                  puVar25 = auStack_20e0;
                  goto LAB_;
                }
                bVar1 = *(byte *)((uStack_2210 >> 8 & 0xff) + 0xfbfd17);
                uVar19 = (uint)bVar1;
                if (*(ushort *)(lVar15 + 0x3c) < uVar19) {
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10088a;
                  (*_DAT_)(1,0x13acd60,0x13a1250,0x171f);
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10089d;
                func_0x(auStack_1ff8,(longlong)&uStack_2210 + 3,bVar1);
              }
              *(uint *)(&stack0xffffffffffffffe0 + lVar11) = uVar19;
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100981;
              func_0x(lStack_2230);
              lVar22 = param_1[0x15];
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100995;
              iVar8 = func_0x(lVar22,lStack_2230,1);
              if (iVar8 == -0x3efffffd) {
                uVar14 = 0x20;
                uVar17 = 0xe0;
                uVar7 = 0x10;
LAB_:
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100a09;
                (*_DAT_)(uVar17,uVar14,uVar7);
LAB_:
                lVar16 = (ulonglong)*_DAT_ +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
                lVar22 = *(longlong *)(lVar16 + 0x100);
                if (lVar22 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100a3c;
                  (*_DAT_)(0);
                  lVar22 = *(longlong *)(lVar16 + 0x100);
                }
                if ((*(uint *)(*(longlong *)(lVar22 + 600) + 0xbc) & 4) != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100a59;
                  iVar10 = func_0x();
                  if (iVar10 != 0) goto LAB_;
                  lVar22 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            );
                  if ((lVar22 != 0) && (*(char *)(*(longlong *)(lVar22 + 0x38) + 8) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100a93;
                    iVar10 = func_0x();
                    if (iVar10 == 0) goto LAB_;
                  }
                }
                *(int *)(&stack0xffffffffffffffe8 + lVar11) = iVar8;
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0x13cbb20;
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100ac7;
                (*_DAT_)(1,0x13cbb50,0x13cbb78);
              }
              else {
                if (iVar8 == -0x3effffdf) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1009f0;
                  func_0x(0x7a);
                  goto LAB_;
                }
                if (iVar8 == -0x3effffde) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1009e7;
                  func_0x(0x91);
                  goto LAB_;
                }
                if (iVar8 == -0x3effffdd) {
                  uVar7 = 0x19;
                  uVar14 = 1;
                  uVar17 = 0x24;
                  goto LAB_;
                }
                if (iVar8 == -0x3efcffff) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1009c1;
                  func_0x(0x80);
                  goto LAB_;
                }
                if (iVar8 < 0) goto LAB_;
              }
LAB_:
              uVar19 = (int)uVar20 + 1;
              uVar20 = (ulonglong)uVar19;
            } while (uVar19 < *(uint *)(lStack_21e8 + 0x38));
            uVar23 = *(ulonglong *)((longlong)&param_5 + lVar11);
            uVar19 = *(uint *)((longlong)auStackX_14 + lVar11 + 4);
          }
          param_3 = *(uint **)(&stack0x00000030 + lVar11);
        }
        else {
          uVar7 = *(undefined4 *)(lStack_21e8 + 0x38);
          lVar15 = param_1[0x15];
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1005f1;
          iVar8 = func_0x(lVar15,lStack_2230,uVar7);
          if (iVar8 == -0x3effffdc) {
            puVar4 = *(undefined8 **)(*(longlong *)(param_3 + 2) + 0xe8);
            *(undefined8 *)((longlong)&lStackX_20 + lVar11 + -0x20) = 0x1260150;
            *(undefined8 *)(&stack0xfffffffffffffff8 + lVar11) = *puStack_2148;
            *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = *(undefined4 *)(puStack_2148 + 1);
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = *puVar4;
            *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined4 *)(puVar4 + 1);
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10064c;
            (*_DAT_)(5,0xf,0x10,4);
          }
          else {
            if (iVar8 == -0x3efffffd) {
              uVar14 = 0x20;
              uVar17 = 0xe0;
              uVar27 = 1;
              uVar7 = 0x10;
LAB_:
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1006cc;
              (*_DAT_)(uVar17,uVar14,uVar7,uVar27);
            }
            else if (iVar8 == -0x3effffdf) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1006b2;
              func_0x(0x7a);
            }
            else if (iVar8 == -0x3effffde) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1006a9;
              func_0x(0x91);
            }
            else {
              if (iVar8 == -0x3effffdd) {
                uVar14 = 1;
                uVar17 = 0x24;
                uVar27 = 0x2f;
                uVar7 = 0x19;
                goto LAB_;
              }
              if (iVar8 == -0x3efcffff) {
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100684;
                func_0x(0x80);
              }
              else if (-1 < iVar8) goto LAB_;
            }
            lVar22 = (ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
            lVar15 = *(longlong *)(lVar22 + 0x100);
            if (lVar15 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1006ff;
              (*_DAT_)(0);
              lVar15 = *(longlong *)(lVar22 + 0x100);
            }
            if ((*(uint *)(*(longlong *)(lVar15 + 600) + 0xbc) & 4) != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10071c;
              iVar10 = func_0x();
              if (iVar10 != 0) goto LAB_;
              lVar15 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
              if ((lVar15 != 0) && (*(char *)(*(longlong *)(lVar15 + 0x38) + 8) != '\0')) {
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100756;
                iVar10 = func_0x();
                if (iVar10 == 0) goto LAB_;
              }
            }
            *(int *)(&stack0xffffffffffffffe8 + lVar11) = iVar8;
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0x13cbb20;
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100797;
            (*_DAT_)(1,0x13cbb50,0x13cbb78,0x25d);
          }
        }
LAB_:
        uVar7 = *(undefined4 *)(lStack_21e8 + 0x54);
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100af7;
        func_0x(param_1,uVar7);
        lVar15 = param_1[0x15];
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100b04;
        iVar8 = func_0x(lVar15);
        if (iVar8 == -0x3efffffd) {
          uVar28 = 1;
          uVar14 = 0x20;
          uVar17 = 0xe0;
          uVar7 = 0x10;
LAB_:
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100b77;
          (*_DAT_)(uVar17,uVar14,uVar7,uVar28);
LAB_:
          lVar22 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          lVar15 = *(longlong *)(lVar22 + 0x100);
          if (lVar15 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100baa;
            (*_DAT_)(0);
            lVar15 = *(longlong *)(lVar22 + 0x100);
          }
          if ((*(uint *)(*(longlong *)(lVar15 + 600) + 0xbc) & 4) != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100bc7;
            iVar10 = func_0x();
            if (iVar10 != 0) goto LAB_;
            lVar15 = *(longlong *)
                      ((ulonglong)*_DAT_ +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
            if ((lVar15 != 0) && (*(char *)(*(longlong *)(lVar15 + 0x38) + 8) != '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100c01;
              iVar10 = func_0x();
              if (iVar10 == 0) goto LAB_;
            }
          }
          *(int *)(&stack0xffffffffffffffe8 + lVar11) = iVar8;
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0x13cbb20;
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100c37;
          (*_DAT_)(1,0x13cbb50,0x13cbb78,0x25d);
        }
        else {
          if (iVar8 == -0x3effffdf) {
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100b5e;
            func_0x(0x7a);
            goto LAB_;
          }
          if (iVar8 == -0x3effffde) {
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100b55;
            func_0x(0x91);
            goto LAB_;
          }
          if (iVar8 == -0x3effffdd) {
            uVar28 = 0x2f;
            uVar7 = 0x19;
            uVar14 = 1;
            uVar17 = 0x24;
            goto LAB_;
          }
          if (iVar8 == -0x3efcffff) {
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100b30;
            func_0x(0x80);
            goto LAB_;
          }
          if (iVar8 < 0) goto LAB_;
        }
LAB_:
        uStack_2138 = 0;
        lVar22 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        lVar15 = *(longlong *)(lVar22 + 0x100);
        if (lVar15 == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100c71;
          (*_DAT_)(0);
          lVar15 = *(longlong *)(lVar22 + 0x100);
        }
        uVar21 = *(uint *)(lVar15 + 0x268) & 1 ^ 1;
        *(uint *)(lVar15 + 0x268) = *(uint *)(lVar15 + 0x268) | 1;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100ca5;
        uStack_2138 = uVar21;
        lStack_2130 = lVar15;
        func_0x(&uStack_21f8);
        *(uint *)(lVar15 + 0x268) = *(uint *)(lVar15 + 0x268) & ~uVar21;
        uVar20 = (ulonglong)*(uint *)((longlong)&uStackX_10 + lVar11);
      }
      else {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100515;
        func_0x(auStack_20b8,lStack_21a8 + 0x28);
        lVar15 = lStack_21e0;
        *(undefined4 *)((longlong)&uStackX_1c + lVar11) = *(undefined4 *)(lStack_21a8 + 0x20);
        if (*(longlong *)(lStack_21e0 + 0x18) != 0) {
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10054f;
          (*_DAT_)(1,0x13f4670,0x13a6460,0x7ed);
        }
        *(longlong *)(&stack0xffffffffffffffe0 + lVar11) = (longlong)&uStackX_1c + lVar11;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100572;
        cVar5 = func_0x
                          (lVar15,lVar15 + 0x50,auStack_20b8,
                           *(undefined *)((longlong)auStackX_14 + lVar11));
        if (cVar5 != '\0') {
          lVar15 = param_1[0x65];
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100590;
          cVar5 = func_0x(&lStack_21a8,lVar15,
                                  *(undefined8 *)((longlong)&lStackX_20 + lVar11));
          if (cVar5 != '\0') goto LAB_;
        }
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100cbf;
      cVar5 = func_0x(auStack_21c8);
    } while (cVar5 != '\0');
  }
  lVar15 = *param_1;
  (&stack0xffffffffffffffe8)[lVar11] = 0;
  (&stack0xffffffffffffffe0)[lVar11] = 0;
  pcVar2 = *(code **)(lVar15 + 0x18);
  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100ce7;
  (*pcVar2)(param_1,0,0,0xffffffffffffffff);
  if ((longlong *)param_1[0xd] != (longlong *)0x0) {
    pcVar2 = *(code **)(*(longlong *)param_1[0xd] + 0xc0);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100cfa;
    cVar5 = (*pcVar2)();
    if (cVar5 != '\0') {
      pcVar2 = *(code **)(*(longlong *)param_1[0xd] + 0x80);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100d0c;
      (*pcVar2)();
    }
  }
  if ((param_1[0x13] != 0) && (*(longlong *)(param_1[0x13] + 0x18) != 0)) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100d27;
    func_0x();
  }
LAB_:
  if (puStack_2228 != (undefined8 *)0x0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100d39;
    func_0x(puStack_2228);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100d47;
    (*_DAT_)(puStack_2228,0x20);
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100d5a;
  (*_DAT_)(uStack_2008,0x98);
  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100d64;
  func_0x(&lStack_21a8);
  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100d6e;
  func_0x(auStack_21a0);
  if (lStack_21a8 != 0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100d7f;
    func_0x(lStack_21a8,0);
  }
  if (lStack_2140 != 0) {
    auStack_21c8 = ZEXT816(0);
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100da1;
  func_0x(uStack_58 ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar11));
  return;
}

