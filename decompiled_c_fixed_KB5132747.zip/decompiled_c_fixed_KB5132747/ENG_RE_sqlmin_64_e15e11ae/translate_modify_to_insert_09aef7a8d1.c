
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined2 *param_2)

{
  uint uVar1;
  int iVar2;
  byte *pbVar3;
  undefined8 uVar4;
  ushort uVar5;
  byte bVar6;
  undefined **ppuVar7;
  longlong lVar8;
  longlong lVar9;
  uint *puVar10;
  longlong lVar11;
  bool bVar12;
  undefined auStack_178 [32];
  undefined8 uStack_158;
  undefined uStack_150;
  int aiStack_148 [2];
  uint auStack_140 [4];
  undefined *apuStack_130 [5];
  undefined auStack_108 [2];
  undefined2 uStack_106;
  undefined8 uStack_104;
  undefined2 uStack_fc;
  ushort uStack_fa;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined2 uStack_ec;
  undefined2 uStack_ea;
  undefined4 uStack_e8;
  undefined8 uStack_e4;
  undefined2 uStack_dc;
  undefined2 uStack_da;
  undefined8 uStack_d8;
  undefined2 uStack_ca;
  undefined2 uStack_c8;
  undefined4 uStack_c6;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_178;
  lVar8 = 0;
  if (*(char *)(param_1 + 0x16) != '\x04') {
    uStack_158 = 0;
    (*_DAT_)(1,0x1c8cae8,0x1c67138,0x17b);
  }
  aiStack_148[0] = 0;
  pbVar3 = (byte *)func_0x(param_1 + 0x3e,0,aiStack_148);
  if (aiStack_148[0] != 0) {
    bVar6 = *pbVar3;
    if ((bVar6 & 1) == 0) {
      switch(bVar6 & 0xe) {
      default:
        if (0x1f9d < (ushort)(*(short *)(pbVar3 + 2) - 1U)) {
          func_0x(pbVar3,6);
        }
        break;
      case 4:
      case 6:
      case 10:
      case 0xe:
        break;
      }
      bVar6 = *pbVar3 & 0xe;
      if (bVar6 == 2) {
        bVar12 = (pbVar3[1] & 1) != 0;
      }
      else {
        bVar12 = false;
        if (((bVar6 - 10 & 0xf9) == 0) && (bVar6 != 0x10)) {
          bVar12 = true;
        }
      }
    }
    else {
      switch(bVar6 & 0x1c) {
      case 4:
      }
      bVar12 = ((bVar6 & 0x1c) - 4 & 0xffffffe7) == 0;
    }
    if ((bVar12) || ((*(byte *)(param_1 + 0xe) & 0x80) == 0)) {
      apuStack_130[1] = (undefined *)func_0x(param_1 + 0x3e,1,aiStack_148);
      iVar2 = aiStack_148[0];
      uStack_e8 = *(undefined4 *)(param_1 + 0x20);
      uStack_dc = *(undefined2 *)(param_1 + 0x2c);
      uStack_e4 = *(undefined8 *)(param_1 + 0x24);
      uStack_ea = *(undefined2 *)(param_1 + 0x1e);
      uStack_d8 = *(undefined8 *)(param_1 + 0x30);
      uStack_ca = 3;
      uStack_da = *(undefined2 *)(param_1 + 0x2e);
      uStack_106 = 0x3e;
      apuStack_130[0] = auStack_108;
      uStack_f0 = *(undefined4 *)(param_1 + 0x18);
      uStack_ec = *(undefined2 *)(param_1 + 0x1c);
      uStack_fa = uStack_fa | 6;
      uVar5 = *(ushort *)(param_1 + 0xe);
      uStack_f8 = 0;
      uStack_f4 = 0x2020000;
      auStack_140[1] = aiStack_148[0];
      uStack_c8 = (undefined2)aiStack_148[0];
      uStack_c6 = 0;
      auStack_140[0] = 0x46;
      if ((uVar5 >> 9 & 1) != 0) {
        uStack_158 = 0;
        (*_DAT_)(1,0x1c8cb08,0x1c67138,0x1cc);
        uVar5 = *(ushort *)(param_1 + 0xe);
      }
      if ((char)uVar5 < '\0') {
        uStack_fa = uStack_fa | 0x80;
      }
      if ((uVar5 & 8) != 0) {
        uStack_fa = uStack_fa | 8;
      }
      if ((uVar5 & 1) != 0) {
        uStack_fa = uStack_fa | 1;
      }
      if ((uVar5 & 0x10) != 0) {
        uStack_fa = uStack_fa | 0x10;
      }
      uStack_fc = *(undefined2 *)(param_1 + 0xc);
      uStack_104 = *(undefined8 *)(param_1 + 4);
      uStack_f8 = *(undefined4 *)(param_1 + 0x10);
      uStack_f4 = CONCAT22(uStack_f4._2_2_,*(undefined2 *)(param_1 + 0x14));
      lVar9 = (longlong)(int)((iVar2 + 3U & 0xfffffffc) + 0x48);
      uStack_150 = 6;
      uStack_158 = CONCAT44(uStack_158._4_4_,0x1fea);
      uVar4 = (*pcRam00000000017610d0)(lVar9,uRam00000000021f7030,1,0x1ad48f8);
      *(undefined8 *)(param_2 + 4) = uVar4;
      uStack_158 = 0;
      func_0x(*param_2,0x34,lVar9,1);
      if (*(longlong *)(param_2 + 4) == 0) {
        func_0x(0x4943,0x10,0x14);
      }
      else {
        ppuVar7 = apuStack_130;
        lVar11 = 2;
        puVar10 = auStack_140;
        do {
          uVar1 = *puVar10;
          func_0x(*(longlong *)(param_2 + 4) + lVar8,lVar9 - lVar8,*ppuVar7,uVar1);
          puVar10 = puVar10 + 1;
          lVar8 = lVar8 + ((ulonglong)uVar1 + 3 & 0xfffffffffffffffc);
          ppuVar7 = ppuVar7 + 1;
          lVar11 = lVar11 + -1;
        } while (lVar11 != 0);
      }
    }
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_178);
  return;
}

