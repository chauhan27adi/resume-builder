
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined *param_1,undefined2 param_2,longlong param_3,longlong param_4)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  longlong lVar7;
  undefined4 *puVar8;
  uint uVar9;
  undefined4 *puVar10;
  undefined4 *puVar12;
  undefined4 *puVar13;
  longlong lVar14;
  ulonglong uVar15;
  longlong unaff_GS_OFFSET;
  bool bVar16;
  undefined auStack_318 [32];
  undefined8 uStack_2f8;
  undefined8 uStack_2f0;
  undefined8 uStack_2e8;
  undefined8 uStack_2e0;
  undefined4 uStack_2d8;
  undefined8 uStack_2c8;
  undefined8 uStack_2c0;
  undefined2 uStack_2b8;
  undefined uStack_2b0;
  undefined uStack_2af;
  undefined uStack_2ae;
  undefined uStack_2ad;
  undefined uStack_2ac;
  undefined uStack_2ab;
  undefined uStack_2aa;
  undefined uStack_2a9;
  undefined2 uStack_2a8;
  undefined8 uStack_2a0;
  int iStack_298;
  undefined4 uStack_294;
  undefined8 uStack_290;
  undefined4 uStack_288;
  undefined auStack_280 [16];
  undefined4 uStack_270;
  undefined4 uStack_26c;
  int iStack_268;
  int iStack_264;
  longlong lStack_260;
  int iStack_258;
  undefined8 uStack_250;
  longlong *plStack_248;
  undefined4 uStack_240;
  longlong *plStack_238;
  undefined uStack_230;
  longlong lStack_228;
  undefined auStack_218 [16];
  undefined auStack_208 [16];
  undefined auStack_1f8 [16];
  undefined auStack_1e8 [16];
  undefined auStack_1d8 [16];
  undefined8 uStack_1c8;
  undefined8 uStack_1b8;
  undefined auStack_1a8 [16];
  undefined auStack_198 [16];
  undefined auStack_188 [16];
  longlong lStack_178;
  undefined2 uStack_170;
  undefined8 uStack_168;
  int iStack_160;
  undefined auStack_158 [16];
  undefined auStack_148 [16];
  undefined auStack_138 [16];
  undefined auStack_128 [16];
  longlong lStack_118;
  uint uStack_110;
  undefined8 uStack_108;
  undefined8 uStack_100;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  undefined8 uStack_e8;
  undefined8 uStack_e0;
  undefined2 uStack_d8;
  undefined2 uStack_d6;
  undefined8 uStack_d0;
  undefined2 uStack_be;
  undefined auStack_b8 [16];
  undefined4 uStack_a8;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined2 uStack_94;
  undefined8 *puStack_90;
  undefined2 uStack_88;
  undefined8 uStack_84;
  undefined8 uStack_78;
  uint uStack_70;
  undefined2 uStack_6c;
  undefined uStack_68;
  undefined uStack_67;
  undefined uStack_66;
  undefined uStack_65;
  undefined uStack_64;
  undefined uStack_63;
  undefined uStack_62;
  undefined uStack_61;
  undefined uStack_60;
  undefined uStack_5f;
  undefined uStack_58;
  undefined uStack_57;
  undefined uStack_56;
  undefined uStack_55;
  undefined uStack_54;
  undefined uStack_53;
  undefined uStack_52;
  undefined uStack_51;
  undefined uStack_50;
  undefined uStack_4f;
  ulonglong uStack_48;
  undefined4 *puVar11;
  
  uStack_1b8 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_318;
  iStack_298 = 1;
  puVar13 = (undefined4 *)0x0;
  uStack_2c8 = param_1;
  lStack_228 = param_3;
  if ((DAT_ & 8) == 0) {
    iStack_258 = 0;
  }
  else {
    iStack_258 = 1;
    iStack_268 = (*_DAT_)();
    iStack_264 = 6;
    lStack_260 = func_0x(param_2);
  }
  lVar7 = (**(code **)(_DAT_ + 0x20))(param_2);
  uStack_2a0 = lVar7;
  if (((param_3 == 0) && ((*(uint *)(lVar7 + 0x278) & 0x400) == 0)) && ((DAT_ & 2) == 0)) {
    uVar15 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
    if (*(int *)(lVar7 + 0x1500) == 0) {
      LOCK();
      bVar16 = *(ulonglong *)(lVar7 + 0x1500) == 0;
      if (bVar16) {
        *(ulonglong *)(lVar7 + 0x1500) = uVar15;
      }
      UNLOCK();
      if (!bVar16) goto LAB_;
    }
    else {
LAB_:
      puVar11 = puVar13;
      puVar12 = puVar13;
      if (((byte)*_DAT_ & 0x84) == 0x84) {
        lVar14 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        if ((lVar14 != 0) && (*(longlong *)(lVar14 + 0x110) == lVar14)) {
          puVar11 = *(undefined4 **)(lVar14 + 0x100);
        }
        if ((puVar11 != (undefined4 *)0x0) && (puVar12 = _DAT_, *_DAT_ != 0)) {
          (*_DAT_)(&uStack_270);
          puVar12 = (undefined4 *)CONCAT44(uStack_26c,uStack_270);
        }
      }
      if (*(char *)(_DAT_ + 199) < '\0') {
        func_0x(lVar7 + 0x1500,puVar11,uVar15);
      }
      else {
        func_0x(lVar7 + 0x1500,uVar15);
      }
      if (puVar11 != (undefined4 *)0x0) {
        puVar10 = _DAT_;
        if (*_DAT_ != 0) {
          (*_DAT_)(&iStack_298);
          puVar10 = (undefined4 *)CONCAT44(uStack_294,iStack_298);
        }
        puVar8 = puVar13;
        if (puVar12 <= puVar10) {
          puVar8 = (undefined4 *)((longlong)puVar10 - (longlong)puVar12);
        }
        *(longlong *)(puVar11 + 0x31e) = *(longlong *)(puVar11 + 0x31e) + (longlong)puVar8;
      }
    }
    lVar7 = uStack_2a0;
    uStack_2c0 = *(undefined8 *)(uStack_2a0 + 0x9c8);
    uStack_2b8 = *(undefined2 *)(uStack_2a0 + 0x9d0);
    if ((*_DAT_ != '\0') && (iVar3 = (*_DAT_)(), iVar3 == (iVar3 / 5) * 5)) {
      func_0x();
    }
    *(undefined8 *)(lVar7 + 0x1500) = 0;
    iStack_298 = func_0x(&uStack_2c0,param_2);
    param_1 = uStack_2c8;
    if (iStack_298 == 0) goto LAB_;
  }
  uStack_290 = 0;
  uStack_288 = 1;
  auStack_280._0_8_ =
       *(longlong **)
        (*(longlong *)
          ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
        0x90);
  auStack_280._8_8_ = 0;
  cVar2 = (**(code **)(*(longlong *)auStack_280._0_8_ + 0x1d0))();
  if (cVar2 == '\0') {
    uStack_2d8 = 0;
    uStack_2e0 = 0;
    uStack_2e8 = uStack_2e8 & 0xffffffffffffff00;
    uStack_2f0 = (undefined8 *)CONCAT44(uStack_2f0._4_4_,2);
    uStack_2f8 = CONCAT44(uStack_2f8._4_4_,1);
    (**(code **)(*(longlong *)auStack_280._0_8_ + 8))(auStack_280._0_8_,0x1ad1a50,0x1c);
    uStack_290 = CONCAT44(uStack_290._4_4_,2);
  }
  else {
    (**(code **)(*(longlong *)auStack_280._0_8_ + 0xe8))
              (auStack_280._0_8_,1,1,(longlong)&uStack_290 + 4);
    uStack_288 = 1;
    uStack_290 = CONCAT44(uStack_290._4_4_,4);
  }
  uStack_240 = 1;
  plStack_238 = (longlong *)0x0;
  uStack_230 = 0;
  uStack_250 = 0x187b7b0;
  plStack_248 = *(longlong **)(*(longlong *)(uStack_2a0 + 0x1210) + 0x6c8);
  plStack_238 = (longlong *)(**(code **)(*plStack_248 + 0x80))(plStack_248,1,plStack_248,0);
  uStack_2e8 = CONCAT44(uStack_2e8._4_4_,2);
  uStack_2f0 = (undefined8 *)CONCAT44(uStack_2f0._4_4_,0x14);
  uStack_2f8 = 0x1ad4988;
  (**(code **)(*plStack_238 + 8))(plStack_238,0,4);
  uStack_68 = param_1[3];
  uStack_67 = param_1[2];
  uStack_66 = param_1[1];
  uStack_65 = *param_1;
  uStack_64 = param_1[7];
  uStack_63 = param_1[6];
  uStack_62 = param_1[5];
  uStack_61 = param_1[4];
  uStack_60 = param_1[9];
  uStack_5f = param_1[8];
  if (param_4 != 0) {
    *(undefined8 *)(param_4 + 0x2c) = *(undefined8 *)(param_4 + 0x20);
    *(undefined4 *)(param_4 + 0x34) = *(undefined4 *)(param_4 + 0x28);
    uVar4 = (*_DAT_)();
    *(undefined4 *)(param_4 + 0x108) = uVar4;
  }
  iVar3 = func_0x(param_2,0x1ad1a50);
  if (iVar3 == 0) {
    func_0x(0x4977,0x10,1,0x1ad1a50);
    func_0x(&uStack_290,0);
  }
  else {
    uStack_168 = (**(code **)(*(longlong *)auStack_280._0_8_ + 0x1b0))();
    lStack_178 = 0;
    auStack_158 = ZEXT816(0);
    auStack_148 = ZEXT816(0);
    auStack_138 = ZEXT816(0);
    auStack_128 = ZEXT816(0);
    lStack_118 = 0;
    uStack_110 = 0;
    uStack_108 = 0;
    uStack_100 = 0;
    uStack_170 = param_2;
    iStack_160 = iVar3;
    iVar3 = func_0x(&lStack_178,3,1);
    if (iVar3 == 0) {
      func_0x(0x49aa,0x10,5,0x1ad1a50);
      iVar3 = 0;
    }
    else {
      uStack_2c8 = (undefined *)CONCAT44(uStack_2c8._4_4_,10);
      auStack_188._0_4_ = func_0x(&lStack_178,0x1ad1a70,&uStack_2c8);
      auStack_1a8 = ZEXT816(0);
      auStack_198 = ZEXT816(0);
      auStack_188._4_12_ = SUB1612(ZEXT816(0),4);
      uStack_1c8 = 0;
      auStack_1d8._8_8_ = 0;
      auStack_1d8._0_8_ = (ulonglong)uStack_2c8 & 0xffffffff;
      auStack_1d8 = auStack_1d8 << 0x40;
      auStack_208 = ZEXT816(0);
      auStack_218 = ZEXT416((uint)auStack_188._0_4_);
      auStack_1e8._0_12_ = ZEXT412(1) << 0x40;
      auStack_1e8._12_4_ = 0;
      auStack_1f8._8_8_ = 0;
      auStack_1f8._0_8_ = auStack_1a8;
      uStack_2e8 = 0;
      uStack_2f0 = &uStack_100;
      uStack_2f8 = 0;
      (**(code **)(*(longlong *)auStack_148._8_8_ + 0x20))(auStack_148._8_8_,2,1,auStack_218);
      uStack_2e8 = uStack_2e8 & 0xffffffff00000000;
      uStack_2f0 = (undefined8 *)0x0;
      uStack_2f8 = 0;
      (**(code **)(*(longlong *)auStack_138._8_8_ + 0x28))
                (auStack_138._8_8_,uStack_100,1,&uStack_68);
      uStack_2f0 = (undefined8 *)lStack_178;
      uStack_2f8 = uStack_108;
      iVar5 = (**(code **)(*(longlong *)auStack_158._8_8_ + 0x18))(auStack_158._8_8_,0,1);
      iVar3 = 0;
      if (iVar5 == 0) {
        uStack_2a0 = CONCAT44(uStack_2a0._4_4_,1);
        puVar11 = puVar13;
        do {
          uStack_2c8 = (undefined *)((ulonglong)uStack_2c8 & 0xffffffff00000000);
          puVar12 = puVar13;
          if (((lStack_178 != 0) && (lStack_118 != 0)) && (uStack_110 != 0)) {
            uVar6 = func_0x(&lStack_178,0x186d5f0,&uStack_2c8);
            if (((lStack_118 != 0) && (uVar6 - 1 < 0xfffffffe)) &&
               (puVar12 = (undefined4 *)0x0, uStack_110 != 0)) {
              puVar11 = puVar13;
              do {
                if (*(ulonglong *)(lStack_118 + (longlong)puVar11 * 0x58) == (ulonglong)uVar6) {
                  puVar12 = (undefined4 *)(lStack_118 + (longlong)puVar11 * 0x58);
                  if (puVar12 != (undefined4 *)0x0) goto LAB_;
                  break;
                }
                uVar9 = (int)puVar11 + 1;
                puVar11 = (undefined4 *)(ulonglong)uVar9;
              } while (uVar9 < uStack_110);
            }
            uStack_2f8 = CONCAT44(uStack_2f8._4_4_,iStack_160);
            (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
            puVar11 = *(undefined4 **)(lStack_178 + *(longlong *)(puVar12 + 4));
            puVar12 = (undefined4 *)(*(longlong *)(puVar12 + 2) + lStack_178);
          }
          uStack_270 = *puVar12;
          uStack_2c8 = (undefined *)((ulonglong)uStack_2c8 & 0xffffffff00000000);
          puVar12 = puVar13;
          if (((lStack_178 != 0) && (lStack_118 != 0)) && (uStack_110 != 0)) {
            uVar6 = func_0x(&lStack_178,0x1ad1a70,&uStack_2c8);
            if (((lStack_118 != 0) && (uVar6 - 1 < 0xfffffffe)) &&
               (puVar12 = (undefined4 *)0x0, uStack_110 != 0)) {
              puVar11 = puVar13;
              do {
                if (*(ulonglong *)(lStack_118 + (longlong)puVar11 * 0x58) == (ulonglong)uVar6) {
                  puVar12 = (undefined4 *)(lStack_118 + (longlong)puVar11 * 0x58);
                  if (puVar12 != (undefined4 *)0x0) goto LAB_;
                  break;
                }
                uVar9 = (int)puVar11 + 1;
                puVar11 = (undefined4 *)(ulonglong)uVar9;
              } while (uVar9 < uStack_110);
            }
            uStack_2f8 = CONCAT44(uStack_2f8._4_4_,iStack_160);
            (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
            puVar11 = *(undefined4 **)(lStack_178 + *(longlong *)(puVar12 + 4));
            puVar12 = (undefined4 *)(*(longlong *)(puVar12 + 2) + lStack_178);
          }
          uVar6 = uStack_110;
          lVar14 = lStack_118;
          lVar7 = lStack_178;
          if (puVar11 < (undefined4 *)0xb) {
            func_0x(&uStack_68,puVar12,puVar11);
          }
          uStack_2c8 = (undefined *)((ulonglong)uStack_2c8 & 0xffffffff00000000);
          puVar12 = puVar13;
          if (((lVar7 != 0) && (lVar14 != 0)) && (uVar6 != 0)) {
            uVar6 = func_0x(&lStack_178,0x1ad1a40,&uStack_2c8);
            if (((lStack_118 != 0) && (uVar6 - 1 < 0xfffffffe)) &&
               (puVar12 = (undefined4 *)0x0, uStack_110 != 0)) {
              puVar11 = puVar13;
              do {
                if (*(ulonglong *)(lStack_118 + (longlong)puVar11 * 0x58) == (ulonglong)uVar6) {
                  puVar12 = (undefined4 *)(lStack_118 + (longlong)puVar11 * 0x58);
                  if (puVar12 != (undefined4 *)0x0) goto LAB_;
                  break;
                }
                uVar9 = (int)puVar11 + 1;
                puVar11 = (undefined4 *)(ulonglong)uVar9;
              } while (uVar9 < uStack_110);
            }
            uStack_2f8 = CONCAT44(uStack_2f8._4_4_,iStack_160);
            (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
            puVar11 = *(undefined4 **)(lStack_178 + *(longlong *)(puVar12 + 4));
            puVar12 = (undefined4 *)(*(longlong *)(puVar12 + 2) + lStack_178);
            lVar14 = lStack_118;
            lVar7 = lStack_178;
            uVar6 = uStack_110;
          }
          if (puVar11 < (undefined4 *)0xb) {
            func_0x(&uStack_58,puVar12,puVar11);
          }
          uStack_2c8 = (undefined *)((ulonglong)uStack_2c8 & 0xffffffff00000000);
          puVar12 = puVar13;
          if (((lVar7 != 0) && (lVar14 != 0)) && (uVar6 != 0)) {
            uVar6 = func_0x(&lStack_178,0x1ad1a18,&uStack_2c8);
            if (((lStack_118 != 0) && (uVar6 - 1 < 0xfffffffe)) &&
               (puVar12 = (undefined4 *)0x0, uStack_110 != 0)) {
              puVar11 = puVar13;
              do {
                if (*(ulonglong *)((longlong)puVar11 * 0x58 + lStack_118) == (ulonglong)uVar6) {
                  puVar12 = (undefined4 *)(lStack_118 + (longlong)puVar11 * 0x58);
                  if (puVar12 != (undefined4 *)0x0) goto LAB_;
                  break;
                }
                uVar9 = (int)puVar11 + 1;
                puVar11 = (undefined4 *)(ulonglong)uVar9;
              } while (uVar9 < uStack_110);
            }
            uStack_2f8 = CONCAT44(uStack_2f8._4_4_,iStack_160);
            (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
            puVar11 = *(undefined4 **)(lStack_178 + *(longlong *)(puVar12 + 4));
            puVar12 = (undefined4 *)(*(longlong *)(puVar12 + 2) + lStack_178);
          }
          uStack_88 = *(undefined2 *)puVar12;
          uStack_2c0 = CONCAT35(CONCAT21(CONCAT11(uStack_64,uStack_63),uStack_62),
                                CONCAT14(uStack_61,
                                         CONCAT31(CONCAT21(CONCAT11(uStack_68,uStack_67),uStack_66),
                                                  uStack_65)));
          uStack_2b8 = CONCAT11(uStack_60,uStack_5f);
          uStack_2ad = uStack_58;
          uStack_2ae = uStack_57;
          uStack_2af = uStack_56;
          uStack_2b0 = uStack_55;
          uStack_2a9 = uStack_54;
          uStack_2aa = uStack_53;
          uStack_2ab = uStack_52;
          uStack_2ac = uStack_51;
          uStack_2a8 = CONCAT11(uStack_50,uStack_4f);
          uStack_f8 = 0;
          uStack_f0 = 0;
          uStack_e8 = 0;
          uStack_e0 = uStack_2c0;
          uStack_d8 = uStack_2b8;
          uStack_d6 = 0;
          uStack_d0 = 0;
          uStack_be = 0;
          auStack_b8 = ZEXT816(0);
          uStack_a8 = uStack_270;
          uStack_a0 = 0;
          uStack_98 = 0;
          uStack_94 = 0;
          puStack_90 = &uStack_250;
          uStack_84 = 0;
          uStack_78 = 0;
          uStack_6c = *(undefined2 *)
                       (*(longlong *)
                         (*(longlong *)
                           ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
                         + 0x50) + 8);
          uStack_70 = DAT_ >> 1 & 1;
          func_0x(&uStack_f8,lStack_228);
          if (param_4 != 0) {
            *(uint *)(param_4 + 0x2c) =
                 CONCAT13(uStack_2ad,CONCAT12(uStack_2ae,CONCAT11(uStack_2af,uStack_2b0)));
            *(uint *)(param_4 + 0x30) =
                 CONCAT13(uStack_2a9,CONCAT12(uStack_2aa,CONCAT11(uStack_2ab,uStack_2ac)));
            *(undefined2 *)(param_4 + 0x34) = uStack_2a8;
            *(int *)(param_4 + 0x80) = *(int *)(param_4 + 0x80) + 1;
            if ((_DAT_ != 0) &&
               (iVar3 = *(int *)(param_4 + 0x108), iVar5 = (*_DAT_)(),
               _DAT_ <= (uint)(iVar5 - iVar3))) {
              func_0x(param_4,2);
              uVar4 = (*_DAT_)();
              *(undefined4 *)(param_4 + 0x108) = uVar4;
            }
          }
          func_0x(&uStack_f8);
          uStack_2f0 = (undefined8 *)lStack_178;
          uStack_2f8 = uStack_108;
          iVar3 = (**(code **)(*(longlong *)auStack_158._8_8_ + 0x18))(auStack_158._8_8_,0);
        } while (iVar3 == 0);
        iVar3 = (int)uStack_2a0;
      }
    }
    func_0x(&lStack_178);
    func_0x(&uStack_290,0);
    if (iVar3 != 0) {
      func_0x(0xffff);
    }
  }
  uStack_250 = 0x187b7b0;
  if (plStack_238 != (longlong *)0x0) {
    (**(code **)*plStack_238)(plStack_238,1);
    plStack_238 = (longlong *)0x0;
  }
  if ((int)uStack_290 != 0) {
    func_0x(&uStack_290,0);
  }
LAB_:
  lVar7 = lStack_260;
  if ((iStack_258 != 0) && (lStack_260 != 0)) {
    iVar3 = (*_DAT_)();
    piVar1 = (int *)(lVar7 + 8 + (longlong)iStack_264 * 4);
    *piVar1 = *piVar1 + (iVar3 - iStack_268);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_318);
  return;
}

