
/* WARNING: Removing unreachable block (ram,0x00100108) */
/* WARNING: Removing unreachable block (ram,0x00100137) */
/* WARNING: Removing unreachable block (ram,0x0010013f) */
/* WARNING: Removing unreachable block (ram,0x0010010d) */
/* WARNING: Removing unreachable block (ram,0x0010014c) */
/* WARNING: Removing unreachable block (ram,0x00100162) */
/* WARNING: Removing unreachable block (ram,0x00100186) */
/* WARNING: Removing unreachable block (ram,0x0010018a) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

byte * FUN_(short *param_1,uint param_2,uint param_3,undefined4 param_4)

{
  ushort *puVar1;
  longlong *plVar2;
  ushort *puVar3;
  byte bVar4;
  char cVar5;
  ushort uVar6;
  ushort uVar7;
  int iVar8;
  longlong lVar9;
  undefined8 uVar10;
  byte *pbVar11;
  byte *pbVar12;
  byte *pbVar13;
  short sVar14;
  uint uVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  uint uVar18;
  ulonglong uVar19;
  uint uVar20;
  ushort *puVar21;
  undefined auStackX_8 [8];
  undefined auStackX_10 [8];
  uint auStackX_18 [2];
  undefined4 auStackX_20 [2];
  uint uStack_58;
  ushort uStack_54;
  ushort uStack_52;
  longlong lStack_50;
  
  uStack_58 = -param_2;
  uStack_54 = (ushort)param_2;
  uVar18 = uStack_58 & 0xc0000000;
  uStack_52 = uStack_52 & 0xffe0;
  pbVar11 = (byte *)0x0;
  uVar15 = param_2;
  if (uVar18 == 0x80000000) {
    uStack_54 = 0;
    uVar15 = 0;
  }
  lStack_50 = 0;
  puVar1 = (ushort *)(param_1 + 1);
  auStackX_20[0] = param_4;
  if (*param_1 != 0) {
    auStackX_18[0] = 0;
    pbVar12 = (byte *)func_0x(puVar1,&uStack_58,uVar18,auStackX_20,auStackX_18);
    pbVar13 = pbVar12;
    if ((((((*param_1 != 0) && (plVar2 = *(longlong **)(param_1 + 8), plVar2 != (longlong *)0x0)) &&
          (*plVar2 != 0)) && (((uStack_52 & 8) == 0 && ((auStackX_18[0] & 1) == 0)))) &&
        (pbVar13 = pbVar11, pbVar12 != (byte *)0x0)) && (pbVar12 != (byte *)0x11ae9b0)) {
      pbVar11 = (byte *)func_0x
                                  (plVar2,&uStack_58,pbVar12,auStackX_20[0],0,0,auStackX_20,
                                   auStackX_18[0]);
      return pbVar11;
    }
    return pbVar13;
  }
  auStackX_18[0] = param_3;
  if (uVar18 == 0x80000000) {
    iVar8 = func_0x(puVar1);
    if (iVar8 != 0) {
      pbVar11 = (byte *)func_0x(param_1 + 0x15,&uStack_58,auStackX_20,auStackX_10);
      return pbVar11;
    }
    return (byte *)0x0;
  }
  pbVar13 = *(byte **)(param_1 + 4);
  if ((*pbVar13 & 0x10) == 0) {
    uVar15 = 1 << (*pbVar13 & 0xe) & 0x1105;
  }
  else {
    uVar18 = *(uint *)(param_1 + 8);
    if ((int)uVar18 <= (int)uStack_58) {
      return (byte *)0x0;
    }
    if ((uint)*(ushort *)(pbVar13 + uVar18) < (uVar15 & 0xffff)) {
      return (byte *)0x0;
    }
    uVar15 = (uVar15 & 0xffff) - 1;
    uVar15 = pbVar13[(ulonglong)uVar18 + (ulonglong)(uVar15 >> 3) + 2] >> ((byte)uVar15 & 7) & 1;
  }
  if (uVar15 != 0) {
    return (byte *)0x0;
  }
  if ((int)param_2 < 1) {
    return pbVar13 + (int)uStack_58;
  }
  if (*(int *)(param_1 + 2) == 0) {
    uVar15 = *(uint *)(param_1 + 8);
    uVar16 = (ulonglong)uVar15;
    *(uint *)(param_1 + 10) = uVar15;
    *puVar1 = 0;
    bVar4 = *pbVar13;
    if ((bVar4 & 0x10) != 0) {
      uVar15 = uVar15 + 2 + (*(ushort *)(pbVar13 + uVar16) + 7 >> 3);
      uVar16 = (ulonglong)uVar15;
      *(uint *)(param_1 + 10) = uVar15;
      bVar4 = *pbVar13;
    }
    if ((bVar4 & 0x20) == 0) {
      *(int *)(param_1 + 2) = (int)uVar16;
      param_1[0xe] = 0;
      *(int *)(param_1 + 0xc) = (int)uVar16;
    }
    else {
      puVar21 = (ushort *)(pbVar13 + uVar16);
      uVar6 = *puVar21;
      param_1[0xe] = uVar6;
      if (uVar6 == 0) {
        cVar5 = func_0x(0x1b3a310);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x1b3a310);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x1429d1c,0x1549e08,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),3);
        uVar16 = (ulonglong)*(uint *)(param_1 + 10);
        uVar6 = param_1[0xe];
      }
      uVar15 = (int)uVar16 + (uVar6 + 1) * 2;
      *(uint *)(param_1 + 0xc) = uVar15;
      if (0x1f9e < uVar15) {
        cVar5 = func_0x(0x1b3a310);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x1b3a310);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x1429d1c,0x1549e08,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar6 = param_1[0xe];
        uVar15 = *(uint *)(param_1 + 0xc);
      }
      uVar16 = (ulonglong)uVar6;
      uVar6 = puVar21[uVar16];
      *(uint *)(param_1 + 2) = uVar6 & 0x7fff;
      if ((uVar6 & 0x7fff) < uVar15) {
        cVar5 = func_0x(0x1b3a310);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x1b3a310);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x1429d1c,0x1549e08,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar15 = *(uint *)(param_1 + 0xc);
        uVar16 = (ulonglong)(ushort)param_1[0xe];
      }
      puVar3 = puVar21;
      if ((short)uVar16 != 0) {
        do {
          uVar18 = puVar3[1] & 0x7fff;
          if ((uVar18 < uVar15) || (*(uint *)(param_1 + 2) < uVar18)) {
            cVar5 = func_0x(0x1b3a310);
            if ((cVar5 != '\0') &&
               ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')
                ))) {
              cVar5 = func_0x(0x1b3a310);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x1429d1c,0x1549e08,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),4);
          }
          uVar16 = (ulonglong)(ushort)param_1[0xe];
          uVar20 = (int)pbVar11 + 1;
          pbVar11 = (byte *)(ulonglong)uVar20;
          puVar3 = puVar3 + 1;
          uVar15 = uVar18;
        } while ((int)uVar20 < (int)(uint)(ushort)param_1[0xe]);
      }
      iVar8 = 0;
      if ((short)puVar21[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
        pbVar13 = *(byte **)(param_1 + 4);
        do {
          uVar15 = *(ushort *)(pbVar13 + uVar16 * 2 + (ulonglong)*(uint *)(param_1 + 10)) & 0x7fff;
          if ((int)uVar16 == 1) {
            uVar18 = *(uint *)(param_1 + 0xc);
            uVar20 = uVar18;
LAB_:
            if ((uVar15 < uVar18) || (*(uint *)(param_1 + 2) < uVar15)) goto LAB_;
          }
          else {
            uVar20 = *(uint *)(param_1 + 0xc);
            uVar18 = *(ushort *)(pbVar13 + uVar16 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2)) &
                     0x7fff;
            if (uVar20 <= uVar18) goto LAB_;
LAB_:
            func_0x(pbVar13,7);
            uVar20 = *(uint *)(param_1 + 0xc);
          }
          if ((uVar18 < uVar20) || (*(uint *)(param_1 + 2) < uVar18)) goto LAB_;
          pbVar13 = *(byte **)(param_1 + 4);
          if (*(ushort *)(pbVar13 + uVar18) == 5) {
            *puVar1 = *puVar1 | 2;
            param_1[0xe] = param_1[0xe] + -1;
            uVar19 = (ulonglong)(uVar18 & 0xffff);
            param_1[0x15] = (short)uVar18;
            uVar16 = *(ulonglong *)(param_1 + 4);
            uVar6 = param_1[0x16] & 0xc7ffU;
            if ((*(ushort *)(uVar19 + 2 + uVar16) >> 0xe & 1) != 0) {
              uVar6 = *(ushort *)(uVar19 + 2 + uVar16) & 0x3800 | param_1[0x16] & 0xc7ffU;
            }
            param_1[0x16] = uVar6;
            uVar7 = (uVar6 ^ *(ushort *)(uVar19 + 2 + uVar16)) & 0x7ff ^ uVar6;
            param_1[0x16] = uVar7;
            uVar17 = uVar16 + 4 + (ulonglong)((uVar7 & 0x7ff) * 2) + uVar19 + (uVar6 >> 0xb & 7) * 2
            ;
            if (uVar17 < uVar19 + uVar16) {
              func_0x(uVar19 + uVar16,0x19);
              uVar7 = param_1[0x16];
              uVar19 = (ulonglong)(ushort)param_1[0x15];
              uVar16 = (ulonglong)*(uint *)(param_1 + 4);
            }
            if (uVar15 - uVar18 < (((uVar7 & 0x7ff) * 2 - (int)uVar19) - (int)uVar16) + (int)uVar17)
            {
              func_0x(uVar19 + *(longlong *)(param_1 + 4),0x19);
              uVar7 = param_1[0x16];
            }
            if (((uVar7 & 0x3800) != 0) &&
               (puVar21 = (ushort *)
                          (*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]),
               (uVar7 & 0x3800) != 0)) {
              do {
                if ((uVar7 & 0x7ff) < (*puVar21 & 0x7ff)) {
                  func_0x((ulonglong)(ushort)param_1[0x15] + *(longlong *)(param_1 + 4),0x1a
                                 );
                  uVar7 = param_1[0x16];
                }
                iVar8 = iVar8 + 1;
                puVar21 = puVar21 + 1;
              } while (iVar8 < (int)(uVar7 >> 0xb & 7));
            }
            goto LAB_;
          }
          if (*(ushort *)(pbVar13 + uVar18) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar6 = param_1[0xe] - 1;
          param_1[0xe] = uVar6;
          if (uVar6 == 0) goto LAB_;
          uVar16 = (ulonglong)uVar6;
        } while ((short)puVar21[(ulonglong)(uVar6 - 1) + 1] < 0);
        uVar16 = (ulonglong)*(uint *)(param_1 + 2);
      }
      else {
LAB_:
        pbVar13 = *(byte **)(param_1 + 4);
        uVar16 = (ulonglong)*(uint *)(param_1 + 2);
      }
    }
    if ((*pbVar13 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x13) = 0;
    }
    else {
      *(int *)(param_1 + 0x13) = (int)uVar16;
      *(int *)(param_1 + 2) = (int)uVar16 + 0xe;
      uVar10 = func_0x(puVar1);
      func_0x(uVar10,auStackX_8);
      iVar8 = func_0x(auStackX_8);
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar8;
      uVar16 = (ulonglong)*(uint *)(param_1 + 2);
    }
    iVar8 = (int)uVar16;
    if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
       (*(ulonglong *)(param_1 + 0xf) < uVar16 + *(longlong *)(param_1 + 4))) {
      cVar5 = func_0x(0x1b3a310);
      if ((cVar5 != '\0') &&
         ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')))) {
        cVar5 = func_0x(0x1b3a310);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x1429d1c,0x1549e08,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),0x12);
      iVar8 = *(int *)(param_1 + 2);
    }
    if (0x3f3b < iVar8 - 1U) {
      cVar5 = func_0x(0x1b3a310);
      if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
         (*(char *)(lVar9 + 0x499) != '\0')) {
        cVar5 = func_0x(0x1b3a310);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x1429d1c,0x1549e08,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),5);
    }
  }
LAB_:
  sVar14 = -(short)uStack_58;
  if ((uStack_52 & 0x10) != 0) {
    bVar4 = **(byte **)(param_1 + 4);
    if ((bVar4 & 0x10) == 0) {
      if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
        return (byte *)(lStack_50 + 4);
      }
    }
    else if (((int)*(uint *)(param_1 + 8) <= (int)uStack_58) ||
            (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) < uStack_54))
    goto LAB_;
  }
  pbVar11 = *(byte **)(param_1 + 4);
  lVar9 = (longlong)sVar14;
  if ((uint)(ushort)param_1[0xe] < (uint)(int)sVar14) {
    return pbVar11;
  }
  uVar15 = *(uint *)(param_1 + 10);
  if (sVar14 == 1) {
    uVar6 = *(ushort *)(pbVar11 + lVar9 * 2 + (ulonglong)uVar15);
    uVar15 = *(uint *)(param_1 + 0xc);
LAB_:
    if ((uVar15 <= (uVar6 & 0x7fff)) && ((uVar6 & 0x7fff) <= *(uint *)(param_1 + 2)))
    goto LAB_;
  }
  else {
    uVar6 = *(ushort *)(pbVar11 + lVar9 * 2 + (ulonglong)uVar15);
    uVar15 = *(ushort *)(pbVar11 + lVar9 * 2 + ((ulonglong)uVar15 - 2)) & 0x7fff;
    pbVar11 = *(byte **)(param_1 + 4);
    if (*(uint *)(param_1 + 0xc) <= uVar15) goto LAB_;
  }
  func_0x(pbVar11,7);
  pbVar11 = *(byte **)(param_1 + 4);
LAB_:
  return pbVar11 + uVar15;
}

