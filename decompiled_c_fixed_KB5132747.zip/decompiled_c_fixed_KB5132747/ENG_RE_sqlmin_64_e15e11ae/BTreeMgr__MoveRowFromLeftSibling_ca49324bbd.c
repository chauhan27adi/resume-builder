
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong **param_2,undefined8 param_3,undefined4 param_4)

{
  byte **ppbVar1;
  undefined uVar2;
  undefined2 uVar3;
  longlong **pplVar4;
  code *pcVar5;
  longlong lVar6;
  byte *pbVar7;
  undefined8 uVar8;
  char cVar9;
  byte bVar10;
  short sVar11;
  undefined2 uVar12;
  int iVar13;
  int iVar14;
  longlong lVar15;
  ushort *puVar16;
  longlong *plVar17;
  undefined2 *puVar18;
  ulonglong uVar19;
  undefined8 uVar20;
  ulonglong uVar21;
  short *psVar22;
  ushort uVar23;
  uint uVar24;
  longlong lVar25;
  longlong lVar26;
  undefined4 *puVar27;
  uint uVar28;
  longlong *plVar29;
  int *piVar30;
  undefined8 *puVar31;
  ushort *puVar32;
  uint *puVar33;
  byte **ppbVar34;
  longlong *plVar35;
  byte *pbVar36;
  ushort uVar37;
  byte **ppbVar38;
  longlong unaff_GS_OFFSET;
  undefined4 uVar39;
  undefined4 uVar40;
  undefined8 uStackX_8;
  undefined8 uStackX_10;
  undefined8 uStackX_18;
  undefined4 auStackX_20 [2];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar15 = func_0x();
  lVar15 = -lVar15;
  *(undefined8 *)(&stack0x00001cd0 + lVar15) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00003348 + lVar15) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar15);
  *(undefined4 *)(&stack0x00000454 + lVar15) = param_4;
  *(undefined8 *)(&stack0x00000920 + lVar15) = param_3;
  *(longlong ***)(&stack0x00000a68 + lVar15) = param_2;
  *(longlong *)(&stack0x00000448 + lVar15) = param_1;
  pplVar4 = *(longlong ***)(&stack0x000033c0 + lVar15);
  *(longlong ***)(&stack0x00000a70 + lVar15) = pplVar4;
  *(longlong *)(&stack0x00000d90 + lVar15) = param_1;
  *(longlong ***)(&stack0x00000da0 + lVar15) = param_2;
  *(undefined8 *)(&stack0x00000d88 + lVar15) = *(undefined8 *)(&stack0x000033b8 + lVar15);
  *(longlong ***)(&stack0x00000d98 + lVar15) = pplVar4;
  *(undefined8 *)(&stack0x00000038 + lVar15) = 0;
  (&stack0x00000040)[lVar15] = 0;
  uVar24 = *(uint *)(&stack0x00000044 + lVar15);
  *(uint *)(&stack0x00000044 + lVar15) = uVar24 & 0xffff0000;
  *(uint *)(&stack0x00000044 + lVar15) = uVar24 & 0xff000000;
  *(undefined4 *)(&stack0x00000044 + lVar15) = 0;
  *(undefined2 *)(&stack0x00002710 + lVar15) = 0xffff;
  *(undefined8 *)(&stack0x00002718 + lVar15) = 0;
  *(undefined4 *)(&stack0x00002714 + lVar15) = 0;
  *(undefined8 *)(&stack0x0000272e + lVar15) = 0;
  *(undefined8 *)(&stack0x00002738 + lVar15) = 0;
  *(undefined8 *)(&stack0x00002720 + lVar15) = 0;
  *(undefined4 *)(&stack0x00002744 + lVar15) = 0xffffffff;
  *(undefined (*) [16])(&stack0x00002680 + lVar15) = ZEXT816(0);
  *(undefined8 *)(&stack0x00000058 + lVar15) = 0;
  (&stack0x00000060)[lVar15] = 0;
  uVar24 = *(uint *)(&stack0x00000064 + lVar15);
  *(uint *)(&stack0x00000064 + lVar15) = uVar24 & 0xffff0000;
  *(uint *)(&stack0x00000064 + lVar15) = uVar24 & 0xff000000;
  *(undefined4 *)(&stack0x00000064 + lVar15) = 0;
  plVar29 = *param_2;
  lVar25 = *plVar29;
  *(undefined4 *)(&stack0x0000009c + lVar15) = *(undefined4 *)(lVar25 + 8);
  *(undefined2 *)(&stack0x000000a0 + lVar15) = *(undefined2 *)(lVar25 + 0xc);
  *(undefined4 *)(&stack0x00000180 + lVar15) = *(undefined4 *)(plVar29 + 0xe);
  *(undefined2 *)(&stack0x00000184 + lVar15) = *(undefined2 *)((longlong)plVar29 + 0x74);
  puVar31 = (undefined8 *)**(longlong **)(param_1 + 8);
  *(ulonglong *)(&stack0x00000a60 + lVar15) =
       (ulonglong)*(uint6 *)((longlong)puVar31 + 0x14) << 0x10;
  lVar25 = puVar31[1];
  *(undefined4 *)(&stack0x00000188 + lVar15) = *(undefined4 *)(lVar25 + 0x3c0);
  *(undefined2 *)(&stack0x0000018c + lVar15) = *(undefined2 *)(lVar25 + 0x3c4);
  *(undefined2 *)(&stack0x0000018e + lVar15) = 0;
  uVar39 = 2;
  if (*(int *)(param_1 + 0xfc) == 3) {
    uVar39 = 0;
  }
  *(undefined4 *)(&stack0x00000f30 + lVar15) = 0;
  *(undefined8 *)(&stack0x00000ef8 + lVar15) = 0;
  *(undefined8 **)(&stack0x00000f00 + lVar15) = puVar31;
  pcVar5 = *(code **)*puVar31;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1001e7;
  sVar11 = (*pcVar5)(puVar31);
  if (sVar11 == 2) {
    uVar39 = 2;
  }
  *(undefined4 *)(&stack0x00000f34 + lVar15) = uVar39;
  (&stack0x00000053)[lVar15] = 1;
  if ((*(int *)(&stack0x0000009c + lVar15) == 0) && (*(short *)(&stack0x000000a0 + lVar15) == 0)) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100233;
    (*_DAT_)(1,0x1b33ac0,0x1b0a498,0x13cb);
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100243;
  func_0x(param_1,0x198e490);
  *(undefined8 *)(&stack0x00000ef8 + lVar15) = *(undefined8 *)(param_1 + 0x110);
  if (*param_2 != (longlong *)0x0) {
    puVar16 = (ushort *)((longlong)*param_2 + 0x62);
    *(ushort **)(&stack0x00001cd8 + lVar15) = puVar16;
    uVar23 = *puVar16;
    *(ushort *)(&stack0x000001b0 + lVar15) = uVar23;
    if (((uVar23 & 0x400) == 0) || (*(short *)((longlong)param_2 + 0xc) < 3)) {
      *(int *)(&stack0x00000168 + lVar15) = (int)*(short *)((longlong)param_2 + 0xc);
      plVar29 = *param_2;
      *(longlong **)(&stack0x00000398 + lVar15) = plVar29;
      puVar18 = (undefined2 *)((longlong)plVar29 + 0x62);
      *(undefined2 **)(&stack0x00001ce0 + lVar15) = puVar18;
      uVar12 = *puVar18;
      *(undefined2 *)(&stack0x000001b8 + lVar15) = uVar12;
      if (((byte)uVar12 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x00000168 + lVar15) == 3) {
          *(undefined4 *)(&stack0x00000168 + lVar15) = 4;
        }
        else if (*(int *)(&stack0x00000168 + lVar15) < 2) goto LAB_;
        *(uint **)(&stack0x00001ce8 + lVar15) =
             (uint *)(*(longlong *)(&stack0x00000398 + lVar15) + 100);
        uVar24 = *(uint *)(*(longlong *)(&stack0x00000398 + lVar15) + 100);
        *(uint *)(&stack0x000007f8 + lVar15) = uVar24;
        if ((((uVar24 & 8) != 0) &&
            (lVar25 = *(longlong *)(*(longlong *)(&stack0x00000398 + lVar15) + 0x90), lVar25 != 0))
           && (*(longlong *)(&stack0x00001cf0 + lVar15) = lVar25, *(longlong *)(lVar25 + 0x758) != 0
              )) {
          uVar20 = *(undefined8 *)(lVar25 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10035a;
          func_0x
                    (uVar20,*(undefined8 *)(&stack0x00000398 + lVar15),
                     *(undefined4 *)(&stack0x00000168 + lVar15));
        }
      }
LAB_:
      (&stack0x00000308)[lVar15] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar33 = (uint *)(*(longlong *)(&stack0x00000398 + lVar15) + 100);
        *(uint **)(&stack0x00001cf8 + lVar15) = puVar33;
        uVar24 = *puVar33;
        *(uint *)(&stack0x00000800 + lVar15) = uVar24;
        if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x00000168 + lVar15))) {
          *(uint **)(&stack0x00001d00 + lVar15) = puVar33;
          uVar24 = *puVar33;
          *(uint *)(&stack0x00000808 + lVar15) = uVar24;
          if (((uVar24 & 0xc0000000) != 0x40000000) &&
             (lVar25 = **(longlong **)(&stack0x00000398 + lVar15), lVar25 != 0)) {
            *(undefined4 *)(&stack0x00000e04 + lVar15) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1003e9;
            iVar13 = (*_DAT_)(lVar25,0x2000,2,&stack0x00000e08 + lVar15);
            if (iVar13 != 0) {
              LOCK();
              *puVar33 = *puVar33 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar33 = *puVar33 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar25 = *(longlong *)(&stack0x00000398 + lVar15);
      uVar39 = *(undefined4 *)(&stack0x00000168 + lVar15);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100418;
      func_0x(lVar25 + 0x98,uVar39);
      if ((_DAT_ != 0) &&
         ((&stack0x00000309)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100442;
        func_0x(lVar25,0,uVar39);
      }
      *(uint *)((longlong)param_2 + 0xc) = *(uint *)((longlong)param_2 + 0xc) & 0xffff0000;
      *param_2 = (longlong *)0x0;
      param_1 = *(longlong *)(&stack0x00000448 + lVar15);
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100293;
      func_0x(param_2);
    }
  }
  if (*pplVar4 == (longlong *)0x0) {
    plVar29 = *(longlong **)(param_1 + 8);
    *(longlong **)(&stack0x00000a48 + lVar15) = plVar29;
    *(undefined8 *)(&stack0x000008d0 + lVar15) = *(undefined8 *)(param_1 + 0x10);
    *(undefined4 *)(&stack0x000005f8 + lVar15) = 0;
    *(undefined4 *)(&stack0x000005fc + lVar15) = 0;
    *(undefined2 *)(&stack0x00000600 + lVar15) = 0;
    lVar25 = *plVar29;
    *(longlong *)(&stack0x00000cd8 + lVar15) = lVar25;
    *(undefined4 *)(&stack0x00000e9c + lVar15) = 0;
    *(undefined4 *)(&stack0x00000ea0 + lVar15) = 0;
    lVar26 = *(longlong *)(lVar25 + 0x20);
    *(longlong *)(&stack0x00000080 + lVar15) = lVar26;
    *(uint6 **)(&stack0x00001d08 + lVar15) = (uint6 *)(lVar25 + 0x14);
    lVar25 = (ulonglong)*(uint6 *)(lVar25 + 0x14) * 0x10000;
    *(longlong *)(&stack0x00001d10 + lVar15) = lVar25;
    if ((*(longlong *)(lVar26 + 2000) == lVar25) &&
       (*(longlong *)(lVar26 + 2000) - 1U < 0xfffffffffffffffe)) {
      (&stack0x00000088)[lVar15] = 1;
      goto LAB_;
    }
    (&stack0x00000088)[lVar15] = 0;
    if ((*(longlong *)(lVar26 + 0x7d8) == lVar25) &&
       (*(longlong *)(lVar26 + 0x7d8) - 1U < 0xfffffffffffffffe)) {
      (&stack0x00000089)[lVar15] = 1;
      goto LAB_;
    }
    (&stack0x00000089)[lVar15] = 0;
    lVar25 = *(longlong *)(unaff_GS_OFFSET + 0x58);
    *(longlong *)(&stack0x00001d18 + lVar15) = lVar25;
    lVar26 = (ulonglong)*_DAT_ + *(longlong *)(lVar25 + (ulonglong)*_DAT_ * 8);
    *(longlong *)(&stack0x00001d20 + lVar15) = lVar26;
    lVar25 = *(longlong *)(lVar26 + 0x100);
    *(longlong *)(&stack0x00000c98 + lVar15) = lVar25;
    puVar33 = _DAT_;
    if (lVar25 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10059a;
      puVar33 = (uint *)(*_DAT_)(0);
      lVar25 = *(longlong *)(lVar26 + 0x100);
      *(longlong *)(&stack0x00000c98 + lVar15) = lVar25;
    }
    *(longlong *)(&stack0x00001d28 + lVar15) = lVar25;
    uVar21 = rdtsc();
    uVar19 = CONCAT44((int)((ulonglong)puVar33 >> 0x20),(int)uVar21) | uVar21 & 0xffffffff00000000;
    *(ulonglong *)(&stack0x00001d30 + lVar15) = uVar19;
    uVar21 = *(ulonglong *)(lVar25 + 0x340);
    if ((uVar21 < uVar19) ||
       ((uVar21 != 0x7fffffffffffffff &&
        (*(ulonglong *)(*(longlong *)(lVar25 + 0x260) + 0xdf0) < uVar21 - uVar19)))) {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100663;
      iVar13 = func_0x(0,0x20c1cc8);
      *(int *)(&stack0x00000450 + lVar15) = iVar13;
      if (iVar13 == 2) {
LAB_:
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100676;
        func_0x(0x7c);
      }
    }
    else {
      lVar25 = *(longlong *)(lVar25 + 600);
      *(longlong *)(&stack0x00000ca0 + lVar15) = lVar25;
      puVar33 = (uint *)(lVar25 + 0xbc);
      *(uint **)(&stack0x00001d38 + lVar15) = puVar33;
      if ((*puVar33 & 4) != 0) {
        lVar25 = *(longlong *)(*(longlong *)(&stack0x00000ca0 + lVar15) + 0x98);
        *(longlong *)(&stack0x00001d40 + lVar15) = lVar25;
        if (((*(byte *)(lVar25 + 0x268) & 1) == 0) && ((*(uint *)(lVar25 + 800) & 0x180) == 0)) {
          *(undefined4 *)(&stack0x00000450 + lVar15) = 2;
          goto LAB_;
        }
      }
      *(undefined4 *)(&stack0x00000450 + lVar15) = 0;
    }
    lVar26 = *(longlong *)(&stack0x00000080 + lVar15);
LAB_:
    *(undefined4 *)(&stack0x00000ac0 + lVar15) = 0;
    *(undefined4 *)(&stack0x00000ac4 + lVar15) = 0;
    *(undefined2 *)(&stack0x00000ac8 + lVar15) = 0;
    (&stack0x0000008c)[lVar15] = 0;
    (&stack0x00000050)[lVar15] = 0xff;
    do {
      uVar20 = 0;
      *(undefined **)(&stack0x00000a38 + lVar15) = &stack0x00000e98 + lVar15;
      *(undefined4 *)(&stack0x0000263c + lVar15) = 0;
      *(undefined4 *)(&stack0x00002640 + lVar15) = 0;
      cVar9 = *_DAT_;
      (&stack0x0000030a)[lVar15] = cVar9;
      if ((cVar9 != '\0') &&
         ((&stack0x00000340)[lVar15] = DAT_ >> 7, -1 < (char)DAT_)) {
        *(undefined4 *)(&stack0x00000810 + lVar15) = 0;
        lVar25 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00001d48 + lVar15) = lVar25;
        plVar29 = (longlong *)
                  ((ulonglong)*_DAT_ + *(longlong *)(lVar25 + (ulonglong)*_DAT_ * 8)
                  );
        *(longlong **)(&stack0x00001d50 + lVar15) = plVar29;
        lVar25 = *plVar29;
        *(longlong *)(&stack0x00001d58 + lVar15) = lVar25;
        if (lVar25 == 0) {
LAB_:
          *(undefined8 *)(&stack0x00000ca8 + lVar15) = 0;
        }
        else {
          lVar25 = **(longlong **)(lVar25 + 0x38);
          *(longlong *)(&stack0x00001d60 + lVar15) = lVar25;
          if (lVar25 == 0) goto LAB_;
          *(longlong *)(&stack0x00000ca8 + lVar15) = lVar25;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100775;
          iVar13 = (*_DAT_)(lVar25,0x337);
          *(int *)(&stack0x00000810 + lVar15) = iVar13;
          if (iVar13 != 0) {
            lVar26 = *(longlong *)(&stack0x00000080 + lVar15);
            goto LAB_;
          }
        }
        lVar25 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00001d68 + lVar15) = lVar25;
        lVar25 = (ulonglong)*_DAT_ + *(longlong *)(lVar25 + (ulonglong)*_DAT_ * 8);
        *(longlong *)(&stack0x00001d70 + lVar15) = lVar25;
        lVar25 = *(longlong *)(lVar25 + 8);
        *(longlong *)(&stack0x00001d78 + lVar15) = lVar25;
        lVar26 = *(longlong *)(&stack0x00000080 + lVar15);
        if (lVar25 != 0) {
          uVar20 = *(undefined8 *)(lVar25 + 0x60);
        }
      }
LAB_:
      *(undefined8 *)(&stack0x00000498 + lVar15) = uVar20;
      plVar29 = (longlong *)(lVar26 + 0x728);
      *(longlong *)(&stack0x00000cb0 + lVar15) = *plVar29;
LAB_:
      *(undefined4 *)(&stack0x0000030c + lVar15) = 0;
      if (*pplVar4 != (longlong *)0x0) {
        puVar16 = (ushort *)((longlong)*pplVar4 + 0x62);
        *(ushort **)(&stack0x00001d80 + lVar15) = puVar16;
        uVar23 = *puVar16;
        *(ushort *)(&stack0x000001c0 + lVar15) = uVar23;
        if (((uVar23 & 0x400) == 0) || (*(short *)((longlong)pplVar4 + 0xc) < 3)) {
          *(int *)(&stack0x00000170 + lVar15) = (int)*(short *)((longlong)pplVar4 + 0xc);
          plVar17 = *pplVar4;
          *(longlong **)(&stack0x000003a0 + lVar15) = plVar17;
          puVar18 = (undefined2 *)((longlong)plVar17 + 0x62);
          *(undefined2 **)(&stack0x00001d88 + lVar15) = puVar18;
          uVar12 = *puVar18;
          *(undefined2 *)(&stack0x000001c8 + lVar15) = uVar12;
          if (((byte)uVar12 >> 3 & 1) != 0) {
            if (*(int *)(&stack0x00000170 + lVar15) == 3) {
              *(undefined4 *)(&stack0x00000170 + lVar15) = 4;
            }
            else if (*(int *)(&stack0x00000170 + lVar15) < 2) goto LAB_;
            *(uint **)(&stack0x00001d90 + lVar15) =
                 (uint *)(*(longlong *)(&stack0x000003a0 + lVar15) + 100);
            uVar24 = *(uint *)(*(longlong *)(&stack0x000003a0 + lVar15) + 100);
            *(uint *)(&stack0x00000818 + lVar15) = uVar24;
            if ((((uVar24 & 8) != 0) &&
                (lVar25 = *(longlong *)(*(longlong *)(&stack0x000003a0 + lVar15) + 0x90),
                lVar25 != 0)) &&
               (*(longlong *)(&stack0x00001d98 + lVar15) = lVar25,
               *(longlong *)(lVar25 + 0x758) != 0)) {
              uVar20 = *(undefined8 *)(lVar25 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100914;
              func_0x
                        (uVar20,*(undefined8 *)(&stack0x000003a0 + lVar15),
                         *(undefined4 *)(&stack0x00000170 + lVar15));
            }
          }
LAB_:
          (&stack0x00000341)[lVar15] = DAT_ >> 7;
          if ((char)DAT_ < '\0') {
            puVar33 = (uint *)(*(longlong *)(&stack0x000003a0 + lVar15) + 100);
            *(uint **)(&stack0x00001da0 + lVar15) = puVar33;
            uVar24 = *puVar33;
            *(uint *)(&stack0x00000820 + lVar15) = uVar24;
            if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x00000170 + lVar15))) {
              *(uint **)(&stack0x00001da8 + lVar15) = puVar33;
              uVar24 = *puVar33;
              *(uint *)(&stack0x00000828 + lVar15) = uVar24;
              if (((uVar24 & 0xc0000000) != 0x40000000) &&
                 (lVar25 = **(longlong **)(&stack0x000003a0 + lVar15), lVar25 != 0)) {
                *(undefined4 *)(&stack0x00000e0c + lVar15) = 2;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1009a7;
                iVar13 = (*_DAT_)(lVar25,0x2000,2,&stack0x00000e10 + lVar15);
                if (iVar13 != 0) {
                  LOCK();
                  *puVar33 = *puVar33 & 0x3fffffff;
                  UNLOCK();
                  LOCK();
                  *puVar33 = *puVar33 | 0x40000000;
                  UNLOCK();
                }
              }
            }
          }
          lVar25 = *(longlong *)(&stack0x000003a0 + lVar15);
          uVar39 = *(undefined4 *)(&stack0x00000170 + lVar15);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1009d6;
          func_0x(lVar25 + 0x98,uVar39);
          if ((_DAT_ != 0) &&
             ((&stack0x00000350)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100a00;
            func_0x(lVar25,0,uVar39);
          }
          *(uint *)((longlong)pplVar4 + 0xc) = *(uint *)((longlong)pplVar4 + 0xc) & 0xffff0000;
          *pplVar4 = (longlong *)0x0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1007f1;
          func_0x(pplVar4);
        }
        lVar26 = *(longlong *)(&stack0x00000080 + lVar15);
      }
      if (*plVar29 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100a33;
        func_0x(pplVar4,&stack0x0000009c + lVar15,lVar26);
        if (*pplVar4 != (longlong *)0x0) {
          puVar16 = (ushort *)((longlong)*pplVar4 + 0x62);
          *(ushort **)(&stack0x00001db0 + lVar15) = puVar16;
          uVar23 = *puVar16;
          *(ushort *)(&stack0x000001d0 + lVar15) = uVar23;
          if (((uVar23 & 0x400) == 0) || (*(short *)((longlong)pplVar4 + 0xc) < 3)) {
            *(int *)(&stack0x00000118 + lVar15) = (int)*(short *)((longlong)pplVar4 + 0xc);
            plVar17 = *pplVar4;
            *(longlong **)(&stack0x000003a8 + lVar15) = plVar17;
            puVar18 = (undefined2 *)((longlong)plVar17 + 0x62);
            *(undefined2 **)(&stack0x00001db8 + lVar15) = puVar18;
            uVar12 = *puVar18;
            *(undefined2 *)(&stack0x000002c8 + lVar15) = uVar12;
            if (((byte)uVar12 >> 3 & 1) != 0) {
              if (*(int *)(&stack0x00000118 + lVar15) == 3) {
                *(undefined4 *)(&stack0x00000118 + lVar15) = 4;
              }
              else if (*(int *)(&stack0x00000118 + lVar15) < 2) goto LAB_;
              *(uint **)(&stack0x00001dc0 + lVar15) =
                   (uint *)(*(longlong *)(&stack0x000003a8 + lVar15) + 100);
              uVar24 = *(uint *)(*(longlong *)(&stack0x000003a8 + lVar15) + 100);
              *(uint *)(&stack0x00000830 + lVar15) = uVar24;
              if ((((uVar24 & 8) != 0) &&
                  (lVar25 = *(longlong *)(*(longlong *)(&stack0x000003a8 + lVar15) + 0x90),
                  lVar25 != 0)) &&
                 (*(longlong *)(&stack0x00001dc8 + lVar15) = lVar25,
                 *(longlong *)(lVar25 + 0x758) != 0)) {
                uVar20 = *(undefined8 *)(lVar25 + 0x758);
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100b33;
                func_0x
                          (uVar20,*(undefined8 *)(&stack0x000003a8 + lVar15),
                           *(undefined4 *)(&stack0x00000118 + lVar15));
              }
            }
LAB_:
            (&stack0x00000351)[lVar15] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
              puVar33 = (uint *)(*(longlong *)(&stack0x000003a8 + lVar15) + 100);
              *(uint **)(&stack0x00001dd0 + lVar15) = puVar33;
              uVar24 = *puVar33;
              *(uint *)(&stack0x00000838 + lVar15) = uVar24;
              if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x00000118 + lVar15))) {
                *(uint **)(&stack0x00001dd8 + lVar15) = puVar33;
                uVar24 = *puVar33;
                *(uint *)(&stack0x00000840 + lVar15) = uVar24;
                if (((uVar24 & 0xc0000000) != 0x40000000) &&
                   (lVar25 = **(longlong **)(&stack0x000003a8 + lVar15), lVar25 != 0)) {
                  *(undefined4 *)(&stack0x00000e14 + lVar15) = 2;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100bc6;
                  iVar13 = (*_DAT_)(lVar25,0x2000,2,&stack0x00000e18 + lVar15);
                  if (iVar13 != 0) {
                    LOCK();
                    *puVar33 = *puVar33 & 0x3fffffff;
                    UNLOCK();
                    LOCK();
                    *puVar33 = *puVar33 | 0x40000000;
                    UNLOCK();
                  }
                }
              }
            }
            lVar25 = *(longlong *)(&stack0x000003a8 + lVar15);
            uVar39 = *(undefined4 *)(&stack0x00000118 + lVar15);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100bf5;
            func_0x(lVar25 + 0x98,uVar39);
            if ((_DAT_ != 0) &&
               ((&stack0x00000352)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100c1f;
              func_0x(lVar25,0,uVar39);
            }
            *(uint *)((longlong)pplVar4 + 0xc) = *(uint *)((longlong)pplVar4 + 0xc) & 0xffff0000;
            *pplVar4 = (longlong *)0x0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100a6d;
            func_0x(pplVar4);
          }
          lVar26 = *(longlong *)(&stack0x00000080 + lVar15);
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100c45;
      func_0x(lVar26,&stack0x0000009c + lVar15);
      *(undefined8 *)(&stack0xfffffffffffffff0 + lVar15) =
           *(undefined8 *)(&stack0x00000a38 + lVar15);
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 4;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100c79;
      plVar17 = (longlong *)
                func_0x
                          (_DAT_,lVar26,&stack0x0000009c + lVar15,&stack0x0000030c + lVar15)
      ;
      *pplVar4 = plVar17;
      uVar24 = *(uint *)((longlong)pplVar4 + 0xc) & 0xffff0004 | 4;
      *(uint *)((longlong)pplVar4 + 0xc) = uVar24;
      if (*(longlong *)(&stack0x00000498 + lVar15) != 0) {
        lVar25 = *plVar17;
        *(longlong *)(&stack0x00001de0 + lVar15) = lVar25;
        plVar35 = (longlong *)(*(longlong *)(&stack0x00000498 + lVar15) + 0x500);
        *(longlong **)(&stack0x00001de8 + lVar15) = plVar35;
        plVar17 = plVar35 + (ulonglong)(*(uint *)plVar35 & 0xf) + 1;
        *(longlong **)(&stack0x00001df0 + lVar15) = plVar17;
        if (*plVar17 != lVar25) {
          *plVar17 = lVar25;
          *plVar35 = *plVar35 + 1;
          uVar24 = *(uint *)((longlong)pplVar4 + 0xc);
        }
      }
      uVar28 = *(uint *)(&stack0x0000030c + lVar15) >> 3 & 1;
      *(uint *)((longlong)pplVar4 + 0xc) = uVar28 << 0x18 | uVar24 & 0xffffff;
      *(uint *)(pplVar4 + 2) =
           *(uint *)(&stack0x0000030c + lVar15) >> 4 & 1 | *(uint *)(pplVar4 + 2) & 0xffffff00;
      lVar25 = *(longlong *)(&stack0x00000cb0 + lVar15);
      if (((lVar25 != 0) && (*(longlong *)(&stack0x00000498 + lVar15) != 0)) &&
         (*(longlong *)(&stack0x00000498 + lVar15) == *(longlong *)(lVar26 + 0x1c38))) {
        *(uint *)(&stack0x00000e20 + lVar15) = uVar28;
        *(longlong *)(&stack0x00001df8 + lVar15) = lVar25 + 0x59b8;
        *(longlong *)(lVar25 + 0x5b28) = *(longlong *)(lVar25 + 0x5b28) + 1;
        puVar33 = *(uint **)(&stack0x00000a38 + lVar15);
        if (puVar33[1] != 0) {
          *(longlong *)(lVar25 + 0x5b30) = *(longlong *)(lVar25 + 0x5b30) + 1;
          *(longlong *)(lVar25 + 0x5b38) = *(longlong *)(lVar25 + 0x5b38) + (ulonglong)*puVar33;
          if (uVar28 != 0) {
            *(longlong *)(lVar25 + 0x5b40) = *(longlong *)(lVar25 + 0x5b40) + 1;
            *(longlong *)(lVar25 + 0x5b48) = *(longlong *)(lVar25 + 0x5b48) + (ulonglong)*puVar33;
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100d92;
      cVar9 = func_0x(lVar26);
      if ((cVar9 == '\0') || (*(char *)(lVar26 + 0x2050) == '\0')) goto LAB_;
      if (*(int *)(&stack0x0000009c + lVar15) == 0) {
LAB_:
        (&stack0x0000008e)[lVar15] = 1;
        goto LAB_;
      }
      *(undefined4 *)(&stack0x00000a80 + lVar15) = 9;
      *(undefined2 *)(&stack0x00000a84 + lVar15) = 1;
      if ((*(int *)(&stack0x0000009c + lVar15) == 9) && (*(short *)(&stack0x000000a0 + lVar15) == 1)
         ) goto LAB_;
      (&stack0x0000008e)[lVar15] = 0;
      lVar25 = **pplVar4;
      *(longlong *)(&stack0x00001e00 + lVar15) = lVar25;
      (&stack0x0000008a)[lVar15] = 0;
      if (*(short *)(lVar25 + 0x24) == 0) {
LAB_:
        *(undefined8 *)(&stack0x00000508 + lVar15) = *(undefined8 *)(lVar25 + 0x28);
        *(undefined2 *)(&stack0x00000510 + lVar15) = *(undefined2 *)(lVar25 + 0x30);
      }
      else {
        cVar9 = *(char *)(lVar25 + 1);
        if ((((cVar9 == '\v') || (cVar9 == '\b')) || (cVar9 == '\t')) &&
           (*(int *)(lVar25 + 0x18) == 99)) {
          *(undefined **)(&stack0x00001e08 + lVar15) = &stack0x00000598 + lVar15;
          *(undefined4 **)(&stack0x00001e10 + lVar15) = (undefined4 *)(lVar25 + 0x20);
          *(undefined4 *)(&stack0x00000598 + lVar15) = *(undefined4 *)(lVar25 + 0x20);
          *(undefined2 *)(&stack0x0000059c + lVar15) = *(undefined2 *)(lVar25 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100e5e;
          cVar9 = func_0x(&stack0x00000598 + lVar15);
          if (cVar9 == '\0') goto LAB_;
          cVar9 = '\x01';
        }
        else {
LAB_:
          cVar9 = '\0';
        }
        (&stack0x0000008a)[lVar15] = cVar9;
        if (cVar9 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100e83;
        func_0x(lVar25,&stack0x00000508 + lVar15);
      }
      *(undefined **)(&stack0x00001e18 + lVar15) = &stack0x00000508 + lVar15;
      *(longlong *)(&stack0x00000cb8 + lVar15) = lVar26 + 0x20fc;
      *(undefined4 *)(&stack0x00000458 + lVar15) = 0;
      *(undefined4 *)(&stack0x0000045c + lVar15) = 0;
      *(undefined2 *)(&stack0x00000460 + lVar15) = 0;
      *(undefined2 *)(&stack0x00000462 + lVar15) = 0;
      puVar33 = (uint *)(lVar26 + 0x2108);
      *(uint **)(&stack0x00001e20 + lVar15) = puVar33;
      uVar24 = *puVar33;
      *(uint *)(&stack0x00000480 + lVar15) = uVar24;
      *(uint **)(&stack0x00000cc0 + lVar15) = puVar33;
      do {
        *(uint *)(&stack0x00000848 + lVar15) = uVar24 & 0xfffffffe;
        *(undefined8 *)(&stack0x00000458 + lVar15) = **(undefined8 **)(&stack0x00000cb8 + lVar15);
        *(undefined4 *)(&stack0x00000460 + lVar15) =
             *(undefined4 *)(*(undefined8 **)(&stack0x00000cb8 + lVar15) + 1);
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15);
        UNLOCK();
        uVar24 = **(uint **)(&stack0x00000cc0 + lVar15);
        *(uint *)(&stack0x00000480 + lVar15) = uVar24;
      } while (*(uint *)(&stack0x00000848 + lVar15) != uVar24);
      if ((*(uint *)(&stack0x00000508 + lVar15) <= *(uint *)(&stack0x00000458 + lVar15)) &&
         ((*(uint *)(&stack0x00000458 + lVar15) != *(uint *)(&stack0x00000508 + lVar15) ||
          ((uVar24 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000458 + lVar15) >> 0x20),
           *(uint *)(&stack0x0000050c + lVar15) <= uVar24 &&
           ((uVar24 != *(uint *)(&stack0x0000050c + lVar15) ||
            (*(ushort *)(&stack0x00000510 + lVar15) <= *(ushort *)(&stack0x00000460 + lVar15))))))))
         ) goto LAB_;
      if (*(char *)(*(longlong *)(&stack0x00000080 + lVar15) + 0x6ac8) != '\0') {
LAB_:
        if ((&stack0x0000008c)[lVar15] != '\0') goto LAB_;
        lVar25 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00001080 + lVar15) = lVar25;
        lVar25 = (ulonglong)*_DAT_ + *(longlong *)(lVar25 + (ulonglong)*_DAT_ * 8);
        *(longlong *)(&stack0x00001088 + lVar15) = lVar25;
        lVar25 = *(longlong *)(lVar25 + 8);
        *(longlong *)(&stack0x00001090 + lVar15) = lVar25;
        lVar25 = *(longlong *)(lVar25 + 0x60);
        *(longlong *)(&stack0x00001098 + lVar15) = lVar25;
        lVar26 = *(longlong *)(&stack0x00000080 + lVar15);
        if (lVar25 == *(longlong *)(lVar26 + 0x2120)) goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1016a0;
        cVar9 = func_0x(lVar26);
        if (cVar9 != '\0') goto LAB_;
        if (*(longlong *)(&stack0x00000498 + lVar15) == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1016b8;
          uVar20 = func_0x();
          *(undefined8 *)(&stack0x00000498 + lVar15) = uVar20;
        }
        *(undefined **)(&stack0x000010a0 + lVar15) = &stack0x00000528 + lVar15;
        lVar25 = **pplVar4;
        *(longlong *)(&stack0x000010a8 + lVar15) = lVar25;
        (&stack0x0000008d)[lVar15] = 0;
        if (*(short *)(lVar25 + 0x24) == 0) {
LAB_:
          uVar20 = *(undefined8 *)(lVar25 + 0x28);
          uVar39 = (undefined4)uVar20;
          uVar40 = (undefined4)((ulonglong)uVar20 >> 0x20);
          *(undefined8 *)(&stack0x00000528 + lVar15) = uVar20;
          uVar12 = *(undefined2 *)(lVar25 + 0x30);
          *(undefined2 *)(&stack0x00000530 + lVar15) = uVar12;
        }
        else {
          cVar9 = *(char *)(lVar25 + 1);
          if (((cVar9 == '\v') && (*(int *)(lVar25 + 0x18) == 99)) ||
             (((cVar9 == '\b' || (cVar9 == '\t')) && (*(int *)(lVar25 + 0x18) == 99)))) {
            *(undefined **)(&stack0x000010b0 + lVar15) = &stack0x00000560 + lVar15;
            *(undefined4 **)(&stack0x000010b8 + lVar15) = (undefined4 *)(lVar25 + 0x20);
            *(undefined4 *)(&stack0x00000560 + lVar15) = *(undefined4 *)(lVar25 + 0x20);
            *(undefined2 *)(&stack0x00000564 + lVar15) = *(undefined2 *)(lVar25 + 0x24);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101750;
            cVar9 = func_0x(&stack0x00000560 + lVar15);
            if (cVar9 == '\0') goto LAB_;
            cVar9 = '\x01';
          }
          else {
LAB_:
            cVar9 = '\0';
          }
          (&stack0x0000008d)[lVar15] = cVar9;
          if (cVar9 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101775;
          func_0x(lVar25,&stack0x00000528 + lVar15);
          uVar12 = *(undefined2 *)(&stack0x00000530 + lVar15);
          uVar39 = (undefined4)*(undefined8 *)(&stack0x00000528 + lVar15);
          uVar40 = (undefined4)((ulonglong)*(undefined8 *)(&stack0x00000528 + lVar15) >> 0x20);
        }
        *(undefined **)(&stack0x000010c0 + lVar15) = &stack0x00000528 + lVar15;
        *(ulonglong *)(&stack0x00000628 + lVar15) = CONCAT44(uVar40,uVar39);
        *(undefined2 *)(&stack0x00000630 + lVar15) = uVar12;
        *(undefined2 *)(&stack0x00000632 + lVar15) = 0;
        if (*pplVar4 != (longlong *)0x0) {
          puVar16 = (ushort *)((longlong)*pplVar4 + 0x62);
          *(ushort **)(&stack0x000010c8 + lVar15) = puVar16;
          uVar23 = *puVar16;
          *(ushort *)(&stack0x000001d8 + lVar15) = uVar23;
          if (((uVar23 & 0x400) == 0) || (*(short *)((longlong)pplVar4 + 0xc) < 3)) {
            *(int *)(&stack0x000000a8 + lVar15) = (int)*(short *)((longlong)pplVar4 + 0xc);
            plVar17 = *pplVar4;
            *(longlong **)(&stack0x000003b0 + lVar15) = plVar17;
            puVar18 = (undefined2 *)((longlong)plVar17 + 0x62);
            *(undefined2 **)(&stack0x000010d0 + lVar15) = puVar18;
            uVar12 = *puVar18;
            *(undefined2 *)(&stack0x000001e0 + lVar15) = uVar12;
            if (((byte)uVar12 >> 3 & 1) != 0) {
              if (*(int *)(&stack0x000000a8 + lVar15) == 3) {
                *(undefined4 *)(&stack0x000000a8 + lVar15) = 4;
              }
              else if (*(int *)(&stack0x000000a8 + lVar15) < 2) goto LAB_;
              *(uint **)(&stack0x000010d8 + lVar15) =
                   (uint *)(*(longlong *)(&stack0x000003b0 + lVar15) + 100);
              uVar24 = *(uint *)(*(longlong *)(&stack0x000003b0 + lVar15) + 100);
              *(uint *)(&stack0x00000858 + lVar15) = uVar24;
              if ((((uVar24 & 8) != 0) &&
                  (lVar25 = *(longlong *)(*(longlong *)(&stack0x000003b0 + lVar15) + 0x90),
                  lVar25 != 0)) &&
                 (*(longlong *)(&stack0x000010e0 + lVar15) = lVar25,
                 *(longlong *)(lVar25 + 0x758) != 0)) {
                uVar20 = *(undefined8 *)(lVar25 + 0x758);
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1018d1;
                func_0x
                          (uVar20,*(undefined8 *)(&stack0x000003b0 + lVar15),
                           *(undefined4 *)(&stack0x000000a8 + lVar15));
              }
            }
LAB_:
            (&stack0x00000353)[lVar15] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
              puVar33 = (uint *)(*(longlong *)(&stack0x000003b0 + lVar15) + 100);
              *(uint **)(&stack0x000010e8 + lVar15) = puVar33;
              uVar24 = *puVar33;
              *(uint *)(&stack0x00000860 + lVar15) = uVar24;
              if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x000000a8 + lVar15))) {
                *(uint **)(&stack0x000010f0 + lVar15) = puVar33;
                uVar24 = *puVar33;
                *(uint *)(&stack0x00000868 + lVar15) = uVar24;
                if (((uVar24 & 0xc0000000) != 0x40000000) &&
                   (lVar25 = **(longlong **)(&stack0x000003b0 + lVar15), lVar25 != 0)) {
                  *(undefined4 *)(&stack0x00000e34 + lVar15) = 2;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101964;
                  iVar13 = (*_DAT_)(lVar25,0x2000,2,&stack0x00000e40 + lVar15);
                  if (iVar13 != 0) {
                    LOCK();
                    *puVar33 = *puVar33 & 0x3fffffff;
                    UNLOCK();
                    LOCK();
                    *puVar33 = *puVar33 | 0x40000000;
                    UNLOCK();
                  }
                }
              }
            }
            lVar25 = *(longlong *)(&stack0x000003b0 + lVar15);
            uVar39 = *(undefined4 *)(&stack0x000000a8 + lVar15);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101993;
            func_0x(lVar25 + 0x98,uVar39);
            if ((_DAT_ != 0) &&
               ((&stack0x00000354)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1019bd;
              func_0x(lVar25,0,uVar39);
            }
            *(uint *)((longlong)pplVar4 + 0xc) = *(uint *)((longlong)pplVar4 + 0xc) & 0xffff0000;
            *pplVar4 = (longlong *)0x0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10180c;
            func_0x(pplVar4);
          }
          uVar39 = (undefined4)*(undefined8 *)(&stack0x00000628 + lVar15);
          uVar40 = (undefined4)((ulonglong)*(undefined8 *)(&stack0x00000628 + lVar15) >> 0x20);
          uVar12 = *(undefined2 *)(&stack0x00000630 + lVar15);
          lVar26 = *(longlong *)(&stack0x00000080 + lVar15);
        }
        *(undefined **)(&stack0x000010f8 + lVar15) = &stack0x00000ae0 + lVar15;
        *(ulonglong *)(&stack0x00000ae0 + lVar15) = CONCAT44(uVar40,uVar39);
        *(undefined2 *)(&stack0x00000ae8 + lVar15) = uVar12;
        *(undefined **)(&stack0x00001100 + lVar15) = &stack0x00000a00 + lVar15;
        *(ulonglong *)(&stack0x00000a00 + lVar15) = CONCAT44(uVar40,uVar39);
        *(undefined2 *)(&stack0x00000a08 + lVar15) = uVar12;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
        lVar25 = *plVar29;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101a47;
        func_0x(lVar25,&stack0x00000a00 + lVar15,4);
        goto LAB_;
      }
      lVar25 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      *(longlong *)(&stack0x00001e28 + lVar15) = lVar25;
      lVar25 = (ulonglong)*_DAT_ + *(longlong *)(lVar25 + (ulonglong)*_DAT_ * 8);
      *(longlong *)(&stack0x00001e30 + lVar15) = lVar25;
      lVar25 = *(longlong *)(lVar25 + 8);
      *(longlong *)(&stack0x00001e38 + lVar15) = lVar25;
      lVar25 = *(longlong *)(lVar25 + 0x60);
      *(longlong *)(&stack0x00001e40 + lVar15) = lVar25;
      if (lVar25 == *(longlong *)(*(longlong *)(&stack0x00000080 + lVar15) + 0x2120))
      goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10100a;
      cVar9 = func_0x(*(longlong *)(&stack0x00000080 + lVar15));
      if (cVar9 != '\0') goto LAB_;
      *(longlong *)(&stack0x00000a40 + lVar15) = lVar26 + 0x20fc;
      *(undefined4 *)(&stack0x00000424 + lVar15) = 0;
      *(undefined4 *)(&stack0x00000428 + lVar15) = 0;
      *(undefined2 *)(&stack0x0000042c + lVar15) = 0;
      *(undefined2 *)(&stack0x0000042e + lVar15) = 0;
      *(uint **)(&stack0x00001e48 + lVar15) = puVar33;
      uVar24 = *puVar33;
      *(uint *)(&stack0x0000047c + lVar15) = uVar24;
      puVar31 = *(undefined8 **)(&stack0x00000a40 + lVar15);
      *(longlong *)(&stack0x00000cc8 + lVar15) = (longlong)puVar31 + 0xc;
      while( true ) {
        *(uint *)(&stack0x0000084c + lVar15) = uVar24 & 0xfffffffe;
        *(undefined8 *)(&stack0x00000424 + lVar15) = *puVar31;
        *(undefined4 *)(&stack0x0000042c + lVar15) = *(undefined4 *)(puVar31 + 1);
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15);
        UNLOCK();
        uVar24 = **(uint **)(&stack0x00000cc8 + lVar15);
        *(uint *)(&stack0x0000047c + lVar15) = uVar24;
        if (*(uint *)(&stack0x0000084c + lVar15) == uVar24) break;
        puVar31 = *(undefined8 **)(&stack0x00000a40 + lVar15);
      }
      *(undefined8 *)(&stack0x00000ad0 + lVar15) = *(undefined8 *)(&stack0x00000424 + lVar15);
      uVar23 = *(ushort *)(&stack0x0000042c + lVar15);
      *(ushort *)(&stack0x00000ad8 + lVar15) = uVar23;
      lVar25 = **pplVar4;
      *(longlong *)(&stack0x00001e50 + lVar15) = lVar25;
      (&stack0x0000008b)[lVar15] = 0;
      if (*(short *)(lVar25 + 0x24) == 0) {
LAB_:
        *(undefined8 *)(&stack0x00000518 + lVar15) = *(undefined8 *)(lVar25 + 0x28);
        uVar37 = *(ushort *)(lVar25 + 0x30);
        *(ushort *)(&stack0x00000520 + lVar15) = uVar37;
      }
      else {
        cVar9 = *(char *)(lVar25 + 1);
        if ((((cVar9 == '\v') || (cVar9 == '\b')) || (cVar9 == '\t')) &&
           (*(int *)(lVar25 + 0x18) == 99)) {
          *(undefined **)(&stack0x00000fe8 + lVar15) = &stack0x00000558 + lVar15;
          *(undefined4 **)(&stack0x00000ff0 + lVar15) = (undefined4 *)(lVar25 + 0x20);
          *(undefined4 *)(&stack0x00000558 + lVar15) = *(undefined4 *)(lVar25 + 0x20);
          *(undefined2 *)(&stack0x0000055c + lVar15) = *(undefined2 *)(lVar25 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101143;
          cVar9 = func_0x(&stack0x00000558 + lVar15);
          if (cVar9 == '\0') goto LAB_;
          cVar9 = '\x01';
        }
        else {
LAB_:
          cVar9 = '\0';
        }
        (&stack0x0000008b)[lVar15] = cVar9;
        if (cVar9 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101168;
        func_0x(lVar25,&stack0x00000518 + lVar15);
        uVar37 = *(ushort *)(&stack0x00000520 + lVar15);
      }
      if ((*(uint *)(&stack0x00000424 + lVar15) < *(uint *)(&stack0x00000518 + lVar15)) ||
         ((*(uint *)(&stack0x00000424 + lVar15) == *(uint *)(&stack0x00000518 + lVar15) &&
          ((uVar24 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000518 + lVar15) >> 0x20),
           *(uint *)(&stack0x00000428 + lVar15) < uVar24 ||
           ((*(uint *)(&stack0x00000428 + lVar15) == uVar24 && (uVar23 < uVar37)))))))) {
        lVar25 = *(longlong *)(&stack0x00000080 + lVar15);
        lVar26 = *(longlong *)(lVar25 + 0x6b0);
        *(longlong *)(&stack0x00000ff8 + lVar15) = lVar26;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1011ff;
        func_0x(&stack0x00000518 + lVar15,&stack0x000027c0 + lVar15,
                        &stack0x00000850 + lVar15);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10121c;
        func_0x(&stack0x00000ad0 + lVar15,&stack0x000027f0 + lVar15,
                        &stack0x00000850 + lVar15);
        *(undefined4 *)(&stack0x00000cd0 + lVar15) = 0x1d;
        *(undefined4 *)(&stack0x00000cd4 + lVar15) = 0x10000;
        if ((_DAT_ & 0x10000) != 0) {
          *(undefined2 *)(&stack0x00000748 + lVar15) = 6;
          *(undefined **)(&stack0x00001000 + lVar15) = &stack0x00001e60 + lVar15;
          *(undefined2 *)(&stack0x00001e60 + lVar15) = 0;
          *(undefined2 *)(&stack0x00001e62 + lVar15) = 6;
          *(undefined4 *)(&stack0x00001e68 + lVar15) = 0;
          *(undefined **)(&stack0x00001e70 + lVar15) = &stack0x00001e88 + lVar15;
          *(undefined **)(&stack0x00001e78 + lVar15) = &stack0x00001ee8 + lVar15;
          *(undefined4 *)(&stack0x000020a8 + lVar15) = 0;
          *(undefined4 *)(&stack0x000020ac + lVar15) = 0;
          *(undefined8 *)(&stack0x00001e80 + lVar15) = 0;
          *(undefined8 *)(&stack0x000020b0 + lVar15) = 0;
          *(undefined **)(&stack0x00001008 + lVar15) = &stack0x00001e88 + lVar15;
          *(undefined **)(&stack0x00001e88 + lVar15) = &stack0x000020b8 + lVar15;
          *(undefined4 *)(&stack0x00001e90 + lVar15) = 0x34;
          *(undefined2 *)(&stack0x00001e94 + lVar15) = 5;
          *(undefined2 *)(&stack0x00001e96 + lVar15) = 0;
          *(undefined **)(&stack0x00001010 + lVar15) = &stack0x00001e98 + lVar15;
          *(undefined8 *)(&stack0x00001e98 + lVar15) = 0x18b1f28;
          *(undefined4 *)(&stack0x00001ea0 + lVar15) = 0x10;
          *(undefined2 *)(&stack0x00001ea4 + lVar15) = 5;
          *(undefined2 *)(&stack0x00001ea6 + lVar15) = 0;
          *(undefined **)(&stack0x00001018 + lVar15) = &stack0x00001ea8 + lVar15;
          *(undefined8 *)(&stack0x00001ea8 + lVar15) = 0x18b1f28;
          *(undefined4 *)(&stack0x00001eb0 + lVar15) = 0x10;
          *(undefined2 *)(&stack0x00001eb4 + lVar15) = 6;
          *(undefined2 *)(&stack0x00001eb6 + lVar15) = 0;
          *(undefined **)(&stack0x00001020 + lVar15) = &stack0x00001eb8 + lVar15;
          *(undefined8 *)(&stack0x00001eb8 + lVar15) = 0;
          *(undefined4 *)(&stack0x00001ec0 + lVar15) = 0;
          *(undefined2 *)(&stack0x00001ec4 + lVar15) = 7;
          *(undefined2 *)(&stack0x00001ec6 + lVar15) = 0;
          *(undefined **)(&stack0x00001028 + lVar15) = &stack0x00001ec8 + lVar15;
          *(undefined8 *)(&stack0x00001ec8 + lVar15) = 0;
          *(undefined4 *)(&stack0x00001ed0 + lVar15) = 0;
          *(undefined2 *)(&stack0x00001ed4 + lVar15) = 8;
          *(undefined2 *)(&stack0x00001ed6 + lVar15) = 0;
          *(undefined **)(&stack0x00001030 + lVar15) = &stack0x00001ed8 + lVar15;
          *(undefined8 *)(&stack0x00001ed8 + lVar15) = 0;
          *(undefined4 *)(&stack0x00001ee0 + lVar15) = 0;
          *(undefined2 *)(&stack0x00001ee4 + lVar15) = 9;
          *(undefined2 *)(&stack0x00001ee6 + lVar15) = 0;
          *(uint *)(&stack0x000020b8 + lVar15) = (uint)*(ushort *)(lVar25 + 0x6b8);
          *(undefined2 *)(&stack0x000020bc + lVar15) = *(undefined2 *)(&stack0x000000a0 + lVar15);
          *(undefined4 *)(&stack0x000020be + lVar15) = *(undefined4 *)(&stack0x0000009c + lVar15);
          (&stack0x000020c2)[lVar15] = (&stack0x00000050)[lVar15];
          lVar25 = **pplVar4;
          *(longlong *)(&stack0x00001038 + lVar15) = lVar25;
          (&stack0x000020c3)[lVar15] = *(undefined *)(lVar25 + 1);
          *(undefined **)(&stack0x00001040 + lVar15) = &stack0x00001e98 + lVar15;
          *(longlong *)(&stack0x00001e98 + lVar15) = lVar26 + 0x254;
          *(undefined4 *)(&stack0x00001ea0 + lVar15) = 0x10;
          *(undefined2 *)(&stack0x00001ea4 + lVar15) = 5;
          *(undefined2 *)(&stack0x00001ea6 + lVar15) = 0;
          *(undefined **)(&stack0x00001048 + lVar15) = &stack0x00001ea8 + lVar15;
          *(longlong *)(&stack0x00001ea8 + lVar15) = lVar26 + 0x244;
          *(undefined4 *)(&stack0x00001eb0 + lVar15) = 0x10;
          *(undefined2 *)(&stack0x00001eb4 + lVar15) = 6;
          *(undefined2 *)(&stack0x00001eb6 + lVar15) = 0;
          *(undefined **)(&stack0x00001050 + lVar15) = &stack0x000027c0 + lVar15;
          lVar25 = -1;
          do {
            lVar25 = lVar25 + 1;
          } while (*(short *)(&stack0x000027c0 + lVar25 * 2 + lVar15) != 0);
          iVar13 = (int)lVar25 * 2;
          *(int *)(&stack0x00000e28 + lVar15) = iVar13;
          *(undefined **)(&stack0x00001058 + lVar15) = &stack0x00001eb8 + lVar15;
          *(undefined **)(&stack0x00001eb8 + lVar15) = &stack0x000027c0 + lVar15;
          *(int *)(&stack0x00001ec0 + lVar15) = iVar13;
          *(undefined2 *)(&stack0x00001ec4 + lVar15) = 7;
          *(undefined2 *)(&stack0x00001ec6 + lVar15) = 0;
          *(undefined **)(&stack0x00001060 + lVar15) = &stack0x000027f0 + lVar15;
          lVar25 = -1;
          do {
            lVar25 = lVar25 + 1;
          } while (*(short *)(&stack0x000027f0 + lVar25 * 2 + lVar15) != 0);
          iVar13 = (int)lVar25 * 2;
          *(int *)(&stack0x00000e2c + lVar15) = iVar13;
          *(undefined **)(&stack0x00001068 + lVar15) = &stack0x00001ec8 + lVar15;
          *(undefined **)(&stack0x00001ec8 + lVar15) = &stack0x000027f0 + lVar15;
          *(int *)(&stack0x00001ed0 + lVar15) = iVar13;
          *(undefined2 *)(&stack0x00001ed4 + lVar15) = 8;
          *(undefined2 *)(&stack0x00001ed6 + lVar15) = 0;
          *(undefined4 *)(&stack0x00000854 + lVar15) = 0;
          pcVar5 = *(code **)(_DAT_ + 0x10);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1015ce;
          lVar25 = (*pcVar5)(lVar26,&stack0x00000854 + lVar15);
          *(longlong *)(&stack0x00001070 + lVar15) = lVar25;
          if (lVar25 == 0) {
            iVar13 = 0;
          }
          else {
            lVar26 = -1;
            do {
              lVar26 = lVar26 + 1;
            } while (*(short *)(lVar25 + lVar26 * 2) != 0);
            iVar13 = (int)lVar26 * 2;
          }
          *(int *)(&stack0x00000e30 + lVar15) = iVar13;
          lVar26 = *(longlong *)(&stack0x00001e70 + lVar15);
          *(longlong **)(&stack0x00001078 + lVar15) = (longlong *)(lVar26 + 0x50);
          *(longlong *)(lVar26 + 0x50) = lVar25;
          *(int *)(lVar26 + 0x58) = iVar13;
          *(undefined2 *)(lVar26 + 0x5c) = 9;
          *(undefined2 *)(lVar26 + 0x5e) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101629;
          func_0x(&stack0x00001e58 + lVar15);
        }
      }
LAB_:
      if ((1 < *(short *)((longlong)pplVar4 + 0xc)) && ((&stack0x00000050)[lVar15] != -1)) {
        lVar25 = **pplVar4;
        *(longlong *)(&stack0x00001108 + lVar15) = lVar25;
        if (*(char *)(lVar25 + 1) != (&stack0x00000050)[lVar15]) {
          if (*(longlong *)(&stack0x00000498 + lVar15) != 0) {
            *(longlong *)(&stack0x00001110 + lVar15) = lVar25;
            *(longlong *)(*(longlong *)(&stack0x00000498 + lVar15) + 0x588) = lVar25;
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101ab6;
          lVar25 = func_0x();
          if (lVar25 == 0) {
LAB_:
            *(undefined4 *)(&stack0x00000870 + lVar15) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101ac0;
            lVar25 = func_0x();
            if (*(longlong *)(lVar25 + 0x30) == 0) goto LAB_;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101acc;
            lVar25 = func_0x();
            uVar24 = *(uint *)(*(longlong *)(lVar25 + 0x30) + 0xc);
            *(uint *)(&stack0x00000b70 + lVar15) = uVar24;
            if ((0xd < uVar24) || (iVar13 = 1, (0x2640U >> (uVar24 & 0x1f) & 1) == 0)) {
              iVar13 = 0;
            }
            *(int *)(&stack0x00000870 + lVar15) = iVar13;
            if (iVar13 != 0) goto LAB_;
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101b0d;
          func_0x(0,8);
        }
      }
LAB_:
      *(undefined4 *)(&stack0x00000af0 + lVar15) = 0;
      *(undefined4 *)(&stack0x00000af4 + lVar15) = 0;
      *(undefined2 *)(&stack0x00000af8 + lVar15) = 0;
      if (((*(short *)(&stack0x00000600 + lVar15) == 0) &&
          (*(int *)(&stack0x000005f8 + lVar15) == 0)) && (*(int *)(&stack0x000005fc + lVar15) == 0))
      {
LAB_:
        lVar25 = *(longlong *)(&stack0x000008d0 + lVar15);
        *(int *)(lVar25 + 4) = *(int *)(lVar25 + 4) + 1;
        if (*(longlong *)(lVar25 + 0x58) != 0) {
          piVar30 = (int *)(*(longlong *)(lVar25 + 0x58) + 4);
          *piVar30 = *piVar30 + 1;
        }
        if ((*(uint *)((longlong)pplVar4 + 0xc) & 0xff000000) != 0) {
          *(int *)(*(longlong *)(&stack0x000008d0 + lVar15) + 8) =
               *(int *)(*(longlong *)(&stack0x000008d0 + lVar15) + 8) + 1;
          if (*(longlong *)(lVar25 + 0x58) != 0) {
            piVar30 = (int *)(*(longlong *)(lVar25 + 0x58) + 8);
            *piVar30 = *piVar30 + 1;
          }
          if (*(char *)(pplVar4 + 2) != '\0') {
            *(int *)(*(longlong *)(&stack0x000008d0 + lVar15) + 0xc) =
                 *(int *)(*(longlong *)(&stack0x000008d0 + lVar15) + 0xc) + 1;
            if (*(longlong *)(lVar25 + 0x58) != 0) {
              piVar30 = (int *)(*(longlong *)(lVar25 + 0x58) + 0xc);
              *piVar30 = *piVar30 + 1;
            }
          }
        }
        if (*(int *)(&stack0x00000e9c + lVar15) != 0) {
          lVar25 = **pplVar4;
          *(longlong *)(&stack0x00001150 + lVar15) = lVar25;
          uVar2 = *(undefined *)(lVar25 + 1);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101e24;
          func_0x
                    (*(undefined8 *)(&stack0x00000cd8 + lVar15),uVar2,&stack0x00000e98 + lVar15,
                     0xffffffff);
        }
        (&stack0x00000357)[lVar15] = 0;
        (&stack0x00000358)[lVar15] = 1;
        *(undefined4 *)(&stack0x000004a0 + lVar15) = 0;
        *(undefined2 *)(&stack0x000004a4 + lVar15) = 0;
        *(undefined2 *)(&stack0x000004a6 + lVar15) = 0;
        lVar25 = **(longlong **)(&stack0x00000a48 + lVar15);
        *(longlong *)(&stack0x00000ce0 + lVar15) = lVar25;
        plVar29 = *pplVar4;
        lVar26 = *plVar29;
        *(longlong *)(&stack0x00001158 + lVar15) = lVar26;
        lVar6 = *(longlong *)(lVar25 + 8);
        piVar30 = (int *)(lVar6 + 0x3c0);
        *(int **)(&stack0x00001160 + lVar15) = piVar30;
        *(undefined4 *)(&stack0x00000890 + lVar15) = 0;
        if (*(int *)(lVar26 + 0x18) == *piVar30) {
          uVar23 = *(ushort *)(lVar6 + 0x3c4);
          if ((*(ushort *)(lVar26 + 6) != uVar23) && (1 < (uVar23 | *(ushort *)(lVar26 + 6))))
          goto LAB_;
          *(undefined4 *)(&stack0x00000890 + lVar15) = 1;
        }
        else {
LAB_:
          *(longlong *)(&stack0x00001168 + lVar15) = lVar26;
          *(undefined4 *)(&stack0x000005c8 + lVar15) = 0;
          *(undefined2 *)(&stack0x000005cc + lVar15) = 0;
          *(undefined2 *)(&stack0x000005ce + lVar15) = 0;
          uVar39 = *(undefined4 *)(lVar26 + 0x18);
          *(undefined4 *)(&stack0x000005c8 + lVar15) = uVar39;
          uVar12 = *(undefined2 *)(lVar26 + 6);
          *(undefined2 *)(&stack0x000005cc + lVar15) = uVar12;
          *(undefined4 *)(&stack0x000004a0 + lVar15) = uVar39;
          *(undefined2 *)(&stack0x000004a4 + lVar15) = uVar12;
          *(undefined2 *)(&stack0x000004a6 + lVar15) = 0;
          puVar18 = (undefined2 *)((longlong)plVar29 + 0x62);
          *(undefined2 **)(&stack0x00001170 + lVar15) = puVar18;
          *(undefined2 *)(&stack0x000001f8 + lVar15) = *puVar18;
          if (((*(ushort *)(&stack0x000001f8 + lVar15) & 0x400) == 0) ||
             (*(short *)((longlong)pplVar4 + 0xc) < 3)) {
            *(int *)(&stack0x000000b8 + lVar15) = (int)*(short *)((longlong)pplVar4 + 0xc);
            plVar29 = *pplVar4;
            *(longlong **)(&stack0x000003c0 + lVar15) = plVar29;
            puVar18 = (undefined2 *)((longlong)plVar29 + 0x62);
            *(undefined2 **)(&stack0x00001178 + lVar15) = puVar18;
            uVar3 = *puVar18;
            *(undefined2 *)(&stack0x00000200 + lVar15) = uVar3;
            if (((byte)uVar3 >> 3 & 1) != 0) {
              if (*(int *)(&stack0x000000b8 + lVar15) == 3) {
                *(undefined4 *)(&stack0x000000b8 + lVar15) = 4;
              }
              else if (*(int *)(&stack0x000000b8 + lVar15) < 2) goto LAB_;
              *(uint **)(&stack0x00001180 + lVar15) =
                   (uint *)(*(longlong *)(&stack0x000003c0 + lVar15) + 100);
              uVar24 = *(uint *)(*(longlong *)(&stack0x000003c0 + lVar15) + 100);
              *(uint *)(&stack0x00000898 + lVar15) = uVar24;
              if ((((uVar24 & 8) != 0) &&
                  (lVar26 = *(longlong *)(*(longlong *)(&stack0x000003c0 + lVar15) + 0x90),
                  lVar26 != 0)) &&
                 (*(longlong *)(&stack0x00001188 + lVar15) = lVar26,
                 *(longlong *)(lVar26 + 0x758) != 0)) {
                uVar20 = *(undefined8 *)(lVar26 + 0x758);
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102002;
                func_0x
                          (uVar20,*(undefined8 *)(&stack0x000003c0 + lVar15),
                           *(undefined4 *)(&stack0x000000b8 + lVar15));
              }
            }
LAB_:
            (&stack0x00000359)[lVar15] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
              puVar33 = (uint *)(*(longlong *)(&stack0x000003c0 + lVar15) + 100);
              *(uint **)(&stack0x00001190 + lVar15) = puVar33;
              uVar24 = *puVar33;
              *(uint *)(&stack0x000008a0 + lVar15) = uVar24;
              if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x000000b8 + lVar15))) {
                *(uint **)(&stack0x00001198 + lVar15) = puVar33;
                uVar24 = *puVar33;
                *(uint *)(&stack0x000008a8 + lVar15) = uVar24;
                if (((uVar24 & 0xc0000000) != 0x40000000) &&
                   (lVar26 = **(longlong **)(&stack0x000003c0 + lVar15), lVar26 != 0)) {
                  *(undefined4 *)(&stack0x00000b7c + lVar15) = 2;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102097;
                  iVar13 = (*_DAT_)(lVar26,0x2000,2,&stack0x00000b80 + lVar15);
                  if (iVar13 != 0) {
                    LOCK();
                    *puVar33 = *puVar33 & 0x3fffffff;
                    UNLOCK();
                    LOCK();
                    *puVar33 = *puVar33 | 0x40000000;
                    UNLOCK();
                  }
                }
              }
            }
            lVar26 = *(longlong *)(&stack0x000003c0 + lVar15);
            uVar40 = *(undefined4 *)(&stack0x000000b8 + lVar15);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1020c6;
            func_0x(lVar26 + 0x98,uVar40);
            if ((_DAT_ != 0) &&
               ((&stack0x0000035a)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1020f0;
              func_0x(lVar26,0,uVar40);
            }
            *(uint *)((longlong)pplVar4 + 0xc) = *(uint *)((longlong)pplVar4 + 0xc) & 0xffff0000;
            *pplVar4 = (longlong *)0x0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101f3c;
            func_0x(pplVar4);
          }
          *(undefined **)(&stack0x000011a0 + lVar15) = &stack0x000005b8 + lVar15;
          *(undefined **)(&stack0x000011a8 + lVar15) = &stack0x000005f0 + lVar15;
          lVar25 = *(longlong *)(lVar25 + 8);
          puVar27 = (undefined4 *)(lVar25 + 0x3c0);
          *(undefined4 **)(&stack0x000011b0 + lVar15) = puVar27;
          *(undefined4 *)(&stack0x000005b8 + lVar15) = *puVar27;
          *(undefined2 *)(&stack0x000005bc + lVar15) = *(undefined2 *)(lVar25 + 0x3c4);
          *(undefined2 *)(&stack0x000005be + lVar15) = 0;
          *(undefined4 *)(&stack0x000005f0 + lVar15) = uVar39;
          *(undefined2 *)(&stack0x000005f4 + lVar15) = uVar12;
          *(undefined2 *)(&stack0x000005f6 + lVar15) = 0;
          pcVar5 = *(code **)**(undefined8 **)(&stack0x00000ce0 + lVar15);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102173;
          uVar12 = (*pcVar5)();
          *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) =
               *(undefined4 *)(*(longlong *)(&stack0x00000a48 + lVar15) + 0x10);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1021a3;
          func_0x(&stack0x0000009c + lVar15,&stack0x000005f0 + lVar15,uVar12,
                          &stack0x000005b8 + lVar15);
        }
        goto LAB_;
      }
      plVar29 = *pplVar4;
      lVar25 = *plVar29;
      *(longlong *)(&stack0x00001118 + lVar15) = lVar25;
      if ((*(byte *)(lVar25 + 4) & 1) == 0) goto LAB_;
      puVar16 = (ushort *)((longlong)plVar29 + 0x62);
      *(ushort **)(&stack0x00001120 + lVar15) = puVar16;
      uVar23 = *puVar16;
      *(ushort *)(&stack0x000001e8 + lVar15) = uVar23;
      if (((uVar23 & 0x400) == 0) || (*(short *)((longlong)pplVar4 + 0xc) < 3)) {
        *(int *)(&stack0x000000b0 + lVar15) = (int)*(short *)((longlong)pplVar4 + 0xc);
        plVar29 = *pplVar4;
        *(longlong **)(&stack0x000003b8 + lVar15) = plVar29;
        puVar18 = (undefined2 *)((longlong)plVar29 + 0x62);
        *(undefined2 **)(&stack0x00001128 + lVar15) = puVar18;
        uVar12 = *puVar18;
        *(undefined2 *)(&stack0x000001f0 + lVar15) = uVar12;
        if (((byte)uVar12 >> 3 & 1) != 0) {
          if (*(int *)(&stack0x000000b0 + lVar15) == 3) {
            *(undefined4 *)(&stack0x000000b0 + lVar15) = 4;
          }
          else if (*(int *)(&stack0x000000b0 + lVar15) < 2) goto LAB_;
          *(uint **)(&stack0x00001130 + lVar15) =
               (uint *)(*(longlong *)(&stack0x000003b8 + lVar15) + 100);
          uVar24 = *(uint *)(*(longlong *)(&stack0x000003b8 + lVar15) + 100);
          *(uint *)(&stack0x00000878 + lVar15) = uVar24;
          if ((((uVar24 & 8) != 0) &&
              (lVar25 = *(longlong *)(*(longlong *)(&stack0x000003b8 + lVar15) + 0x90), lVar25 != 0)
              ) && (*(longlong *)(&stack0x00001138 + lVar15) = lVar25,
                   *(longlong *)(lVar25 + 0x758) != 0)) {
            uVar20 = *(undefined8 *)(lVar25 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101c52;
            func_0x
                      (uVar20,*(undefined8 *)(&stack0x000003b8 + lVar15),
                       *(undefined4 *)(&stack0x000000b0 + lVar15));
          }
        }
LAB_:
        (&stack0x00000355)[lVar15] = DAT_ >> 7;
        if ((char)DAT_ < '\0') {
          puVar33 = (uint *)(*(longlong *)(&stack0x000003b8 + lVar15) + 100);
          *(uint **)(&stack0x00001140 + lVar15) = puVar33;
          uVar24 = *puVar33;
          *(uint *)(&stack0x00000880 + lVar15) = uVar24;
          if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x000000b0 + lVar15))) {
            *(uint **)(&stack0x00001148 + lVar15) = puVar33;
            uVar24 = *puVar33;
            *(uint *)(&stack0x00000888 + lVar15) = uVar24;
            if (((uVar24 & 0xc0000000) != 0x40000000) &&
               (lVar25 = **(longlong **)(&stack0x000003b8 + lVar15), lVar25 != 0)) {
              *(undefined4 *)(&stack0x00000b74 + lVar15) = 2;
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101ce5;
              iVar13 = (*_DAT_)(lVar25,0x2000,2,&stack0x00000b78 + lVar15);
              if (iVar13 != 0) {
                LOCK();
                *puVar33 = *puVar33 & 0x3fffffff;
                UNLOCK();
                LOCK();
                *puVar33 = *puVar33 | 0x40000000;
                UNLOCK();
              }
            }
          }
        }
        lVar25 = *(longlong *)(&stack0x000003b8 + lVar15);
        uVar39 = *(undefined4 *)(&stack0x000000b0 + lVar15);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101d14;
        func_0x(lVar25 + 0x98,uVar39);
        if ((_DAT_ != 0) &&
           ((&stack0x00000356)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101d3e;
          func_0x(lVar25,0,uVar39);
        }
        *(uint *)((longlong)pplVar4 + 0xc) = *(uint *)((longlong)pplVar4 + 0xc) & 0xffff0000;
        *pplVar4 = (longlong *)0x0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101b8c;
        func_0x(pplVar4);
      }
      *(undefined4 *)(&stack0x00000f70 + lVar15) = 0x400060;
      *(undefined8 *)(&stack0x00000f78 + lVar15) = 0;
      *(undefined8 *)(&stack0x00000f88 + lVar15) = 0;
      *(undefined8 *)(&stack0x00000f80 + lVar15) = 0;
      *(undefined8 *)(&stack0x00000f90 + lVar15) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101d89;
      func_0x(10,&stack0x00000f70 + lVar15);
      lVar26 = *(longlong *)(&stack0x00000080 + lVar15);
    } while( true );
  }
  (&stack0x00000053)[lVar15] = 0;
LAB_:
  plVar29 = *(longlong **)(*(longlong *)(&stack0x00000448 + lVar15) + 8);
  *(longlong **)(&stack0x00000a20 + lVar15) = plVar29;
  *(undefined8 *)(&stack0x000008d8 + lVar15) =
       *(undefined8 *)(*(longlong *)(&stack0x00000448 + lVar15) + 0x10);
  *(undefined4 *)(&stack0x00000608 + lVar15) = 0;
  *(undefined4 *)(&stack0x0000060c + lVar15) = 0;
  *(undefined2 *)(&stack0x00000610 + lVar15) = 0;
  lVar25 = *plVar29;
  *(longlong *)(&stack0x00000d28 + lVar15) = lVar25;
  *(undefined4 *)(&stack0x00000eb4 + lVar15) = 0;
  *(undefined4 *)(&stack0x00000eb8 + lVar15) = 0;
  lVar26 = *(longlong *)(lVar25 + 0x20);
  *(longlong *)(&stack0x00000070 + lVar15) = lVar26;
  *(uint6 **)(&stack0x000011b8 + lVar15) = (uint6 *)(lVar25 + 0x14);
  lVar25 = (ulonglong)*(uint6 *)(lVar25 + 0x14) * 0x10000;
  *(longlong *)(&stack0x000011c0 + lVar15) = lVar25;
  if ((*(longlong *)(lVar26 + 2000) == lVar25) &&
     (*(longlong *)(lVar26 + 2000) - 1U < 0xfffffffffffffffe)) {
    (&stack0x0000008f)[lVar15] = 1;
    goto LAB_;
  }
  (&stack0x0000008f)[lVar15] = 0;
  if ((*(longlong *)(lVar26 + 0x7d8) == lVar25) &&
     (*(longlong *)(lVar26 + 0x7d8) - 1U < 0xfffffffffffffffe)) {
    (&stack0x00000090)[lVar15] = 1;
    goto LAB_;
  }
  (&stack0x00000090)[lVar15] = 0;
  lVar25 = *(longlong *)(unaff_GS_OFFSET + 0x58);
  *(longlong *)(&stack0x000011c8 + lVar15) = lVar25;
  lVar26 = (ulonglong)*_DAT_ + *(longlong *)(lVar25 + (ulonglong)*_DAT_ * 8);
  *(longlong *)(&stack0x000011d0 + lVar15) = lVar26;
  lVar25 = *(longlong *)(lVar26 + 0x100);
  *(longlong *)(&stack0x00000ce8 + lVar15) = lVar25;
  puVar33 = _DAT_;
  if (lVar25 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1022d0;
    puVar33 = (uint *)(*_DAT_)();
    lVar25 = *(longlong *)(lVar26 + 0x100);
    *(longlong *)(&stack0x00000ce8 + lVar15) = lVar25;
  }
  *(longlong *)(&stack0x000011d8 + lVar15) = lVar25;
  uVar21 = rdtsc();
  uVar19 = CONCAT44((int)((ulonglong)puVar33 >> 0x20),(int)uVar21) | uVar21 & 0xffffffff00000000;
  *(ulonglong *)(&stack0x000011e0 + lVar15) = uVar19;
  uVar21 = *(ulonglong *)(lVar25 + 0x340);
  if ((uVar21 < uVar19) ||
     ((uVar21 != 0x7fffffffffffffff &&
      (*(ulonglong *)(*(longlong *)(lVar25 + 0x260) + 0xdf0) < uVar21 - uVar19)))) {
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10238f;
    iVar13 = func_0x(0,0x20c1cc8);
    *(int *)(&stack0x0000043c + lVar15) = iVar13;
    if (iVar13 == 2) {
LAB_:
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1023a2;
      func_0x(0x7c);
    }
  }
  else {
    lVar25 = *(longlong *)(lVar25 + 600);
    *(longlong *)(&stack0x00000cf0 + lVar15) = lVar25;
    puVar33 = (uint *)(lVar25 + 0xbc);
    *(uint **)(&stack0x000011e8 + lVar15) = puVar33;
    if ((*puVar33 & 4) != 0) {
      lVar25 = *(longlong *)(*(longlong *)(&stack0x00000cf0 + lVar15) + 0x98);
      *(longlong *)(&stack0x000011f0 + lVar15) = lVar25;
      if (((*(byte *)(lVar25 + 0x268) & 1) == 0) && ((*(uint *)(lVar25 + 800) & 0x180) == 0)) {
        *(undefined4 *)(&stack0x0000043c + lVar15) = 2;
        goto LAB_;
      }
    }
    *(undefined4 *)(&stack0x0000043c + lVar15) = 0;
  }
  lVar26 = *(longlong *)(&stack0x00000070 + lVar15);
LAB_:
  *(undefined4 *)(&stack0x00000b00 + lVar15) = 0;
  *(undefined4 *)(&stack0x00000b04 + lVar15) = 0;
  *(undefined2 *)(&stack0x00000b08 + lVar15) = 0;
  (&stack0x0000009a)[lVar15] = 0;
  (&stack0x00000051)[lVar15] = 0xff;
  do {
    uVar20 = 0;
    *(undefined **)(&stack0x00000a50 + lVar15) = &stack0x00000eb0 + lVar15;
    *(undefined4 *)(&stack0x00002654 + lVar15) = 0;
    *(undefined4 *)(&stack0x00002658 + lVar15) = 0;
    cVar9 = *_DAT_;
    (&stack0x0000035b)[lVar15] = cVar9;
    if ((cVar9 != '\0') && ((&stack0x0000035c)[lVar15] = DAT_ >> 7, -1 < (char)DAT_)
       ) {
      *(undefined4 *)(&stack0x000008b0 + lVar15) = 0;
      lVar25 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      *(longlong *)(&stack0x000011f8 + lVar15) = lVar25;
      plVar29 = (longlong *)
                ((ulonglong)*_DAT_ + *(longlong *)(lVar25 + (ulonglong)*_DAT_ * 8));
      *(longlong **)(&stack0x00001200 + lVar15) = plVar29;
      lVar25 = *plVar29;
      *(longlong *)(&stack0x00001208 + lVar15) = lVar25;
      if (lVar25 == 0) {
LAB_:
        *(undefined8 *)(&stack0x00000cf8 + lVar15) = 0;
      }
      else {
        lVar25 = **(longlong **)(lVar25 + 0x38);
        *(longlong *)(&stack0x00001210 + lVar15) = lVar25;
        if (lVar25 == 0) goto LAB_;
        *(longlong *)(&stack0x00000cf8 + lVar15) = lVar25;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1024a5;
        iVar13 = (*_DAT_)(lVar25,0x337);
        *(int *)(&stack0x000008b0 + lVar15) = iVar13;
        if (iVar13 != 0) {
          lVar26 = *(longlong *)(&stack0x00000070 + lVar15);
          goto LAB_;
        }
      }
      lVar25 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      *(longlong *)(&stack0x00001218 + lVar15) = lVar25;
      lVar25 = (ulonglong)*_DAT_ + *(longlong *)(lVar25 + (ulonglong)*_DAT_ * 8);
      *(longlong *)(&stack0x00001220 + lVar15) = lVar25;
      lVar25 = *(longlong *)(lVar25 + 8);
      *(longlong *)(&stack0x00001228 + lVar15) = lVar25;
      lVar26 = *(longlong *)(&stack0x00000070 + lVar15);
      if (lVar25 != 0) {
        uVar20 = *(undefined8 *)(lVar25 + 0x60);
      }
    }
LAB_:
    *(undefined8 *)(&stack0x000004a8 + lVar15) = uVar20;
    plVar29 = (longlong *)(lVar26 + 0x728);
    *(longlong *)(&stack0x00000d00 + lVar15) = *plVar29;
LAB_:
    *(undefined4 *)(&stack0x00000310 + lVar15) = 0;
    if (*param_2 != (longlong *)0x0) {
      puVar16 = (ushort *)((longlong)*param_2 + 0x62);
      *(ushort **)(&stack0x00001230 + lVar15) = puVar16;
      uVar23 = *puVar16;
      *(ushort *)(&stack0x00000208 + lVar15) = uVar23;
      if (((uVar23 & 0x400) == 0) || (*(short *)((longlong)param_2 + 0xc) < 3)) {
        *(int *)(&stack0x000000c0 + lVar15) = (int)*(short *)((longlong)param_2 + 0xc);
        plVar17 = *param_2;
        *(longlong **)(&stack0x000003c8 + lVar15) = plVar17;
        puVar18 = (undefined2 *)((longlong)plVar17 + 0x62);
        *(undefined2 **)(&stack0x00001238 + lVar15) = puVar18;
        uVar12 = *puVar18;
        *(undefined2 *)(&stack0x00000210 + lVar15) = uVar12;
        if (((byte)uVar12 >> 3 & 1) != 0) {
          if (*(int *)(&stack0x000000c0 + lVar15) == 3) {
            *(undefined4 *)(&stack0x000000c0 + lVar15) = 4;
          }
          else if (*(int *)(&stack0x000000c0 + lVar15) < 2) goto LAB_;
          *(uint **)(&stack0x00001240 + lVar15) =
               (uint *)(*(longlong *)(&stack0x000003c8 + lVar15) + 100);
          uVar24 = *(uint *)(*(longlong *)(&stack0x000003c8 + lVar15) + 100);
          *(uint *)(&stack0x000008b8 + lVar15) = uVar24;
          if ((((uVar24 & 8) != 0) &&
              (lVar25 = *(longlong *)(*(longlong *)(&stack0x000003c8 + lVar15) + 0x90), lVar25 != 0)
              ) && (*(longlong *)(&stack0x00001248 + lVar15) = lVar25,
                   *(longlong *)(lVar25 + 0x758) != 0)) {
            uVar20 = *(undefined8 *)(lVar25 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102646;
            func_0x
                      (uVar20,*(undefined8 *)(&stack0x000003c8 + lVar15),
                       *(undefined4 *)(&stack0x000000c0 + lVar15));
          }
        }
LAB_:
        (&stack0x0000035d)[lVar15] = DAT_ >> 7;
        if ((char)DAT_ < '\0') {
          puVar33 = (uint *)(*(longlong *)(&stack0x000003c8 + lVar15) + 100);
          *(uint **)(&stack0x00001250 + lVar15) = puVar33;
          uVar24 = *puVar33;
          *(uint *)(&stack0x000008c0 + lVar15) = uVar24;
          if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x000000c0 + lVar15))) {
            *(uint **)(&stack0x00001258 + lVar15) = puVar33;
            uVar24 = *puVar33;
            *(uint *)(&stack0x000008c8 + lVar15) = uVar24;
            if (((uVar24 & 0xc0000000) != 0x40000000) &&
               (lVar25 = **(longlong **)(&stack0x000003c8 + lVar15), lVar25 != 0)) {
              *(undefined4 *)(&stack0x00000b84 + lVar15) = 2;
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1026d9;
              iVar13 = (*_DAT_)(lVar25,0x2000,2,&stack0x00000b88 + lVar15);
              if (iVar13 != 0) {
                LOCK();
                *puVar33 = *puVar33 & 0x3fffffff;
                UNLOCK();
                LOCK();
                *puVar33 = *puVar33 | 0x40000000;
                UNLOCK();
              }
            }
          }
        }
        lVar25 = *(longlong *)(&stack0x000003c8 + lVar15);
        uVar39 = *(undefined4 *)(&stack0x000000c0 + lVar15);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102708;
        func_0x(lVar25 + 0x98,uVar39);
        if ((_DAT_ != 0) &&
           ((&stack0x0000035e)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102732;
          func_0x(lVar25,0,uVar39);
        }
        *(uint *)((longlong)param_2 + 0xc) = *(uint *)((longlong)param_2 + 0xc) & 0xffff0000;
        *param_2 = (longlong *)0x0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102522;
        func_0x(param_2);
      }
      lVar26 = *(longlong *)(&stack0x00000070 + lVar15);
    }
    if (*plVar29 != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102766;
      func_0x(param_2,&stack0x00000180 + lVar15,lVar26);
      if (*param_2 != (longlong *)0x0) {
        puVar16 = (ushort *)((longlong)*param_2 + 0x62);
        *(ushort **)(&stack0x00001260 + lVar15) = puVar16;
        uVar23 = *puVar16;
        *(ushort *)(&stack0x00000218 + lVar15) = uVar23;
        if (((uVar23 & 0x400) == 0) || (*(short *)((longlong)param_2 + 0xc) < 3)) {
          *(int *)(&stack0x000000c8 + lVar15) = (int)*(short *)((longlong)param_2 + 0xc);
          plVar17 = *param_2;
          *(longlong **)(&stack0x000003d0 + lVar15) = plVar17;
          puVar18 = (undefined2 *)((longlong)plVar17 + 0x62);
          *(undefined2 **)(&stack0x00001268 + lVar15) = puVar18;
          uVar12 = *puVar18;
          *(undefined2 *)(&stack0x00000220 + lVar15) = uVar12;
          if (((byte)uVar12 >> 3 & 1) != 0) {
            if (*(int *)(&stack0x000000c8 + lVar15) == 3) {
              *(undefined4 *)(&stack0x000000c8 + lVar15) = 4;
            }
            else if (*(int *)(&stack0x000000c8 + lVar15) < 2) goto LAB_;
            *(uint **)(&stack0x00001270 + lVar15) =
                 (uint *)(*(longlong *)(&stack0x000003d0 + lVar15) + 100);
            uVar24 = *(uint *)(*(longlong *)(&stack0x000003d0 + lVar15) + 100);
            *(uint *)(&stack0x00000938 + lVar15) = uVar24;
            if ((((uVar24 & 8) != 0) &&
                (lVar25 = *(longlong *)(*(longlong *)(&stack0x000003d0 + lVar15) + 0x90),
                lVar25 != 0)) &&
               (*(longlong *)(&stack0x00001278 + lVar15) = lVar25,
               *(longlong *)(lVar25 + 0x758) != 0)) {
              uVar20 = *(undefined8 *)(lVar25 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102868;
              func_0x
                        (uVar20,*(undefined8 *)(&stack0x000003d0 + lVar15),
                         *(undefined4 *)(&stack0x000000c8 + lVar15));
            }
          }
LAB_:
          (&stack0x0000035f)[lVar15] = DAT_ >> 7;
          if ((char)DAT_ < '\0') {
            puVar33 = (uint *)(*(longlong *)(&stack0x000003d0 + lVar15) + 100);
            *(uint **)(&stack0x00001280 + lVar15) = puVar33;
            uVar24 = *puVar33;
            *(uint *)(&stack0x00000940 + lVar15) = uVar24;
            if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x000000c8 + lVar15))) {
              *(uint **)(&stack0x00001288 + lVar15) = puVar33;
              uVar24 = *puVar33;
              *(uint *)(&stack0x00000948 + lVar15) = uVar24;
              if (((uVar24 & 0xc0000000) != 0x40000000) &&
                 (lVar25 = **(longlong **)(&stack0x000003d0 + lVar15), lVar25 != 0)) {
                *(undefined4 *)(&stack0x00000b8c + lVar15) = 2;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1028fb;
                iVar13 = (*_DAT_)(lVar25,0x2000,2,&stack0x00000b90 + lVar15);
                if (iVar13 != 0) {
                  LOCK();
                  *puVar33 = *puVar33 & 0x3fffffff;
                  UNLOCK();
                  LOCK();
                  *puVar33 = *puVar33 | 0x40000000;
                  UNLOCK();
                }
              }
            }
          }
          lVar25 = *(longlong *)(&stack0x000003d0 + lVar15);
          uVar39 = *(undefined4 *)(&stack0x000000c8 + lVar15);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10292a;
          func_0x(lVar25 + 0x98,uVar39);
          if ((_DAT_ != 0) &&
             ((&stack0x00000360)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102954;
            func_0x(lVar25,0,uVar39);
          }
          *(uint *)((longlong)param_2 + 0xc) = *(uint *)((longlong)param_2 + 0xc) & 0xffff0000;
          *param_2 = (longlong *)0x0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1027a1;
          func_0x(param_2);
        }
        lVar26 = *(longlong *)(&stack0x00000070 + lVar15);
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10297b;
    func_0x(lVar26,&stack0x00000180 + lVar15);
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar15) = *(undefined8 *)(&stack0x00000a50 + lVar15);
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 4;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1029af;
    plVar17 = (longlong *)
              func_0x
                        (_DAT_,lVar26,&stack0x00000180 + lVar15,&stack0x00000310 + lVar15);
    *param_2 = plVar17;
    uVar24 = *(uint *)((longlong)param_2 + 0xc) & 0xffff0004 | 4;
    *(uint *)((longlong)param_2 + 0xc) = uVar24;
    if (*(longlong *)(&stack0x000004a8 + lVar15) != 0) {
      lVar25 = **param_2;
      *(longlong *)(&stack0x00001290 + lVar15) = lVar25;
      plVar35 = (longlong *)(*(longlong *)(&stack0x000004a8 + lVar15) + 0x500);
      *(longlong **)(&stack0x00001298 + lVar15) = plVar35;
      plVar17 = plVar35 + (ulonglong)(*(uint *)plVar35 & 0xf) + 1;
      *(longlong **)(&stack0x000012a0 + lVar15) = plVar17;
      if (*plVar17 != lVar25) {
        *plVar17 = lVar25;
        *plVar35 = *plVar35 + 1;
        uVar24 = *(uint *)((longlong)param_2 + 0xc);
      }
    }
    uVar28 = *(uint *)(&stack0x00000310 + lVar15) >> 3 & 1;
    *(uint *)((longlong)param_2 + 0xc) = uVar28 << 0x18 | uVar24 & 0xffffff;
    *(uint *)(param_2 + 2) =
         *(uint *)(&stack0x00000310 + lVar15) >> 4 & 1 | *(uint *)(param_2 + 2) & 0xffffff00;
    lVar25 = *(longlong *)(&stack0x00000d00 + lVar15);
    if (((lVar25 != 0) && (*(longlong *)(&stack0x000004a8 + lVar15) != 0)) &&
       (*(longlong *)(&stack0x000004a8 + lVar15) == *(longlong *)(lVar26 + 0x1c38))) {
      *(uint *)(&stack0x00000b98 + lVar15) = uVar28;
      *(longlong *)(&stack0x000012a8 + lVar15) = lVar25 + 0x59b8;
      *(longlong *)(lVar25 + 0x5b28) = *(longlong *)(lVar25 + 0x5b28) + 1;
      puVar33 = *(uint **)(&stack0x00000a50 + lVar15);
      if (puVar33[1] != 0) {
        *(longlong *)(lVar25 + 0x5b30) = *(longlong *)(lVar25 + 0x5b30) + 1;
        *(longlong *)(lVar25 + 0x5b38) = *(longlong *)(lVar25 + 0x5b38) + (ulonglong)*puVar33;
        if (uVar28 != 0) {
          *(longlong *)(lVar25 + 0x5b40) = *(longlong *)(lVar25 + 0x5b40) + 1;
          *(longlong *)(lVar25 + 0x5b48) = *(longlong *)(lVar25 + 0x5b48) + (ulonglong)*puVar33;
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102ad2;
    cVar9 = func_0x(lVar26);
    if ((cVar9 == '\0') || (*(char *)(lVar26 + 0x2050) == '\0')) goto LAB_;
    if (*(int *)(&stack0x00000180 + lVar15) == 0) {
LAB_:
      (&stack0x000000a7)[lVar15] = 1;
      goto LAB_;
    }
    *(undefined4 *)(&stack0x00000a86 + lVar15) = 9;
    *(undefined2 *)(&stack0x00000a8a + lVar15) = 1;
    if ((*(int *)(&stack0x00000180 + lVar15) == 9) && (*(short *)(&stack0x00000184 + lVar15) == 1))
    goto LAB_;
    (&stack0x000000a7)[lVar15] = 0;
    lVar25 = **param_2;
    *(longlong *)(&stack0x000012b0 + lVar15) = lVar25;
    (&stack0x00000091)[lVar15] = 0;
    if (*(short *)(lVar25 + 0x24) == 0) {
LAB_:
      *(undefined8 *)(&stack0x00000538 + lVar15) = *(undefined8 *)(lVar25 + 0x28);
      *(undefined2 *)(&stack0x00000540 + lVar15) = *(undefined2 *)(lVar25 + 0x30);
    }
    else {
      cVar9 = *(char *)(lVar25 + 1);
      if ((((cVar9 == '\v') || (cVar9 == '\b')) || (cVar9 == '\t')) &&
         (*(int *)(lVar25 + 0x18) == 99)) {
        *(undefined **)(&stack0x000012b8 + lVar15) = &stack0x00000568 + lVar15;
        *(undefined4 **)(&stack0x000012c0 + lVar15) = (undefined4 *)(lVar25 + 0x20);
        *(undefined4 *)(&stack0x00000568 + lVar15) = *(undefined4 *)(lVar25 + 0x20);
        *(undefined2 *)(&stack0x0000056c + lVar15) = *(undefined2 *)(lVar25 + 0x24);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102b9b;
        cVar9 = func_0x(&stack0x00000568 + lVar15);
        if (cVar9 == '\0') goto LAB_;
        cVar9 = '\x01';
      }
      else {
LAB_:
        cVar9 = '\0';
      }
      (&stack0x00000091)[lVar15] = cVar9;
      if (cVar9 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102bc0;
      func_0x(lVar25,&stack0x00000538 + lVar15);
    }
    *(undefined **)(&stack0x000012c8 + lVar15) = &stack0x00000538 + lVar15;
    *(longlong *)(&stack0x00000d08 + lVar15) = lVar26 + 0x20fc;
    *(undefined4 *)(&stack0x00000464 + lVar15) = 0;
    *(undefined4 *)(&stack0x00000468 + lVar15) = 0;
    *(undefined2 *)(&stack0x0000046c + lVar15) = 0;
    *(undefined2 *)(&stack0x0000046e + lVar15) = 0;
    puVar33 = (uint *)(lVar26 + 0x2108);
    *(uint **)(&stack0x000012d0 + lVar15) = puVar33;
    uVar24 = *puVar33;
    *(uint *)(&stack0x00000440 + lVar15) = uVar24;
    *(uint **)(&stack0x00000d10 + lVar15) = puVar33;
    do {
      *(uint *)(&stack0x00000950 + lVar15) = uVar24 & 0xfffffffe;
      *(undefined8 *)(&stack0x00000464 + lVar15) = **(undefined8 **)(&stack0x00000d08 + lVar15);
      *(undefined4 *)(&stack0x0000046c + lVar15) =
           *(undefined4 *)(*(undefined8 **)(&stack0x00000d08 + lVar15) + 1);
      LOCK();
      *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15) =
           *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15);
      UNLOCK();
      uVar24 = **(uint **)(&stack0x00000d10 + lVar15);
      *(uint *)(&stack0x00000440 + lVar15) = uVar24;
    } while (*(uint *)(&stack0x00000950 + lVar15) != uVar24);
    if ((*(uint *)(&stack0x00000538 + lVar15) <= *(uint *)(&stack0x00000464 + lVar15)) &&
       ((*(uint *)(&stack0x00000464 + lVar15) != *(uint *)(&stack0x00000538 + lVar15) ||
        ((uVar24 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000464 + lVar15) >> 0x20),
         *(uint *)(&stack0x0000053c + lVar15) <= uVar24 &&
         ((uVar24 != *(uint *)(&stack0x0000053c + lVar15) ||
          (*(ushort *)(&stack0x00000540 + lVar15) <= *(ushort *)(&stack0x0000046c + lVar15)))))))))
    goto LAB_;
    if (*(char *)(*(longlong *)(&stack0x00000070 + lVar15) + 0x6ac8) != '\0') {
LAB_:
      if ((&stack0x0000009a)[lVar15] != '\0') goto LAB_;
      lVar25 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      *(longlong *)(&stack0x000013a0 + lVar15) = lVar25;
      lVar25 = (ulonglong)*_DAT_ + *(longlong *)(lVar25 + (ulonglong)*_DAT_ * 8);
      *(longlong *)(&stack0x000013a8 + lVar15) = lVar25;
      lVar25 = *(longlong *)(lVar25 + 8);
      *(longlong *)(&stack0x000013b0 + lVar15) = lVar25;
      lVar25 = *(longlong *)(lVar25 + 0x60);
      *(longlong *)(&stack0x000013b8 + lVar15) = lVar25;
      lVar26 = *(longlong *)(&stack0x00000070 + lVar15);
      if (lVar25 == *(longlong *)(lVar26 + 0x2120)) goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1033cd;
      cVar9 = func_0x(lVar26);
      if (cVar9 != '\0') goto LAB_;
      if (*(longlong *)(&stack0x000004a8 + lVar15) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1033e5;
        uVar20 = func_0x();
        *(undefined8 *)(&stack0x000004a8 + lVar15) = uVar20;
      }
      *(undefined **)(&stack0x000013c0 + lVar15) = &stack0x000004c8 + lVar15;
      lVar25 = **param_2;
      *(longlong *)(&stack0x000013c8 + lVar15) = lVar25;
      (&stack0x00000099)[lVar15] = 0;
      if (*(short *)(lVar25 + 0x24) == 0) {
LAB_:
        uVar20 = *(undefined8 *)(lVar25 + 0x28);
        uVar39 = (undefined4)uVar20;
        uVar40 = (undefined4)((ulonglong)uVar20 >> 0x20);
        *(undefined8 *)(&stack0x000004c8 + lVar15) = uVar20;
        uVar12 = *(undefined2 *)(lVar25 + 0x30);
        *(undefined2 *)(&stack0x000004d0 + lVar15) = uVar12;
      }
      else {
        cVar9 = *(char *)(lVar25 + 1);
        if (((cVar9 == '\v') && (*(int *)(lVar25 + 0x18) == 99)) ||
           (((cVar9 == '\b' || (cVar9 == '\t')) && (*(int *)(lVar25 + 0x18) == 99)))) {
          *(undefined **)(&stack0x000013d0 + lVar15) = &stack0x00000578 + lVar15;
          *(undefined4 **)(&stack0x000013d8 + lVar15) = (undefined4 *)(lVar25 + 0x20);
          *(undefined4 *)(&stack0x00000578 + lVar15) = *(undefined4 *)(lVar25 + 0x20);
          *(undefined2 *)(&stack0x0000057c + lVar15) = *(undefined2 *)(lVar25 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10347d;
          cVar9 = func_0x(&stack0x00000578 + lVar15);
          if (cVar9 == '\0') goto LAB_;
          cVar9 = '\x01';
        }
        else {
LAB_:
          cVar9 = '\0';
        }
        (&stack0x00000099)[lVar15] = cVar9;
        if (cVar9 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1034a2;
        func_0x(lVar25,&stack0x000004c8 + lVar15);
        uVar12 = *(undefined2 *)(&stack0x000004d0 + lVar15);
        uVar39 = (undefined4)*(undefined8 *)(&stack0x000004c8 + lVar15);
        uVar40 = (undefined4)((ulonglong)*(undefined8 *)(&stack0x000004c8 + lVar15) >> 0x20);
      }
      *(undefined **)(&stack0x000013e0 + lVar15) = &stack0x000004c8 + lVar15;
      *(ulonglong *)(&stack0x00000634 + lVar15) = CONCAT44(uVar40,uVar39);
      *(undefined2 *)(&stack0x0000063c + lVar15) = uVar12;
      *(undefined2 *)(&stack0x0000063e + lVar15) = 0;
      if (*param_2 != (longlong *)0x0) {
        puVar16 = (ushort *)((longlong)*param_2 + 0x62);
        *(ushort **)(&stack0x000013e8 + lVar15) = puVar16;
        uVar23 = *puVar16;
        *(ushort *)(&stack0x00000228 + lVar15) = uVar23;
        if (((uVar23 & 0x400) == 0) || (*(short *)((longlong)param_2 + 0xc) < 3)) {
          *(int *)(&stack0x000000d0 + lVar15) = (int)*(short *)((longlong)param_2 + 0xc);
          plVar17 = *param_2;
          *(longlong **)(&stack0x000003d8 + lVar15) = plVar17;
          puVar18 = (undefined2 *)((longlong)plVar17 + 0x62);
          *(undefined2 **)(&stack0x000013f0 + lVar15) = puVar18;
          uVar12 = *puVar18;
          *(undefined2 *)(&stack0x00000230 + lVar15) = uVar12;
          if (((byte)uVar12 >> 3 & 1) != 0) {
            if (*(int *)(&stack0x000000d0 + lVar15) == 3) {
              *(undefined4 *)(&stack0x000000d0 + lVar15) = 4;
            }
            else if (*(int *)(&stack0x000000d0 + lVar15) < 2) goto LAB_;
            *(uint **)(&stack0x000013f8 + lVar15) =
                 (uint *)(*(longlong *)(&stack0x000003d8 + lVar15) + 100);
            uVar24 = *(uint *)(*(longlong *)(&stack0x000003d8 + lVar15) + 100);
            *(uint *)(&stack0x00000960 + lVar15) = uVar24;
            if ((((uVar24 & 8) != 0) &&
                (lVar25 = *(longlong *)(*(longlong *)(&stack0x000003d8 + lVar15) + 0x90),
                lVar25 != 0)) &&
               (*(longlong *)(&stack0x00001400 + lVar15) = lVar25,
               *(longlong *)(lVar25 + 0x758) != 0)) {
              uVar20 = *(undefined8 *)(lVar25 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103600;
              func_0x
                        (uVar20,*(undefined8 *)(&stack0x000003d8 + lVar15),
                         *(undefined4 *)(&stack0x000000d0 + lVar15));
            }
          }
LAB_:
          (&stack0x00000361)[lVar15] = DAT_ >> 7;
          if ((char)DAT_ < '\0') {
            puVar33 = (uint *)(*(longlong *)(&stack0x000003d8 + lVar15) + 100);
            *(uint **)(&stack0x00001408 + lVar15) = puVar33;
            uVar24 = *puVar33;
            *(uint *)(&stack0x00000968 + lVar15) = uVar24;
            if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x000000d0 + lVar15))) {
              *(uint **)(&stack0x00001410 + lVar15) = puVar33;
              uVar24 = *puVar33;
              *(uint *)(&stack0x00000970 + lVar15) = uVar24;
              if (((uVar24 & 0xc0000000) != 0x40000000) &&
                 (lVar25 = **(longlong **)(&stack0x000003d8 + lVar15), lVar25 != 0)) {
                *(undefined4 *)(&stack0x00000bac + lVar15) = 2;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103693;
                iVar13 = (*_DAT_)(lVar25,0x2000,2,&stack0x00000bb0 + lVar15);
                if (iVar13 != 0) {
                  LOCK();
                  *puVar33 = *puVar33 & 0x3fffffff;
                  UNLOCK();
                  LOCK();
                  *puVar33 = *puVar33 | 0x40000000;
                  UNLOCK();
                }
              }
            }
          }
          lVar25 = *(longlong *)(&stack0x000003d8 + lVar15);
          uVar39 = *(undefined4 *)(&stack0x000000d0 + lVar15);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1036c2;
          func_0x(lVar25 + 0x98,uVar39);
          if ((_DAT_ != 0) &&
             ((&stack0x00000362)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1036ec;
            func_0x(lVar25,0,uVar39);
          }
          *(uint *)((longlong)param_2 + 0xc) = *(uint *)((longlong)param_2 + 0xc) & 0xffff0000;
          *param_2 = (longlong *)0x0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10353a;
          func_0x(param_2);
        }
        uVar39 = (undefined4)*(undefined8 *)(&stack0x00000634 + lVar15);
        uVar40 = (undefined4)((ulonglong)*(undefined8 *)(&stack0x00000634 + lVar15) >> 0x20);
        uVar12 = *(undefined2 *)(&stack0x0000063c + lVar15);
        lVar26 = *(longlong *)(&stack0x00000070 + lVar15);
      }
      *(undefined **)(&stack0x00001418 + lVar15) = &stack0x00000b20 + lVar15;
      *(ulonglong *)(&stack0x00000b20 + lVar15) = CONCAT44(uVar40,uVar39);
      *(undefined2 *)(&stack0x00000b28 + lVar15) = uVar12;
      *(undefined **)(&stack0x00001420 + lVar15) = &stack0x000009f0 + lVar15;
      *(ulonglong *)(&stack0x000009f0 + lVar15) = CONCAT44(uVar40,uVar39);
      *(undefined2 *)(&stack0x000009f8 + lVar15) = uVar12;
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
      lVar25 = *plVar29;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103777;
      func_0x(lVar25,&stack0x000009f0 + lVar15,4);
      goto LAB_;
    }
    lVar25 = *(longlong *)(unaff_GS_OFFSET + 0x58);
    *(longlong *)(&stack0x000012d8 + lVar15) = lVar25;
    lVar25 = (ulonglong)*_DAT_ + *(longlong *)(lVar25 + (ulonglong)*_DAT_ * 8);
    *(longlong *)(&stack0x000012e0 + lVar15) = lVar25;
    lVar25 = *(longlong *)(lVar25 + 8);
    *(longlong *)(&stack0x000012e8 + lVar15) = lVar25;
    lVar25 = *(longlong *)(lVar25 + 0x60);
    *(longlong *)(&stack0x000012f0 + lVar15) = lVar25;
    if (lVar25 == *(longlong *)(*(longlong *)(&stack0x00000070 + lVar15) + 0x2120))
    goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102d4a;
    cVar9 = func_0x(*(longlong *)(&stack0x00000070 + lVar15));
    if (cVar9 != '\0') goto LAB_;
    *(longlong *)(&stack0x00000a58 + lVar15) = lVar26 + 0x20fc;
    iVar13 = 0;
    *(undefined4 *)(&stack0x00000430 + lVar15) = 0;
    *(undefined4 *)(&stack0x00000434 + lVar15) = 0;
    *(undefined2 *)(&stack0x00000438 + lVar15) = 0;
    *(undefined2 *)(&stack0x0000043a + lVar15) = 0;
    *(uint **)(&stack0x000012f8 + lVar15) = puVar33;
    uVar24 = *puVar33;
    *(uint *)(&stack0x00000484 + lVar15) = uVar24;
    puVar31 = *(undefined8 **)(&stack0x00000a58 + lVar15);
    *(longlong *)(&stack0x00000d18 + lVar15) = (longlong)puVar31 + 0xc;
    while( true ) {
      *(uint *)(&stack0x00000954 + lVar15) = uVar24 & 0xfffffffe;
      *(undefined8 *)(&stack0x00000430 + lVar15) = *puVar31;
      *(undefined4 *)(&stack0x00000438 + lVar15) = *(undefined4 *)(puVar31 + 1);
      LOCK();
      *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15) =
           *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15);
      UNLOCK();
      uVar24 = **(uint **)(&stack0x00000d18 + lVar15);
      *(uint *)(&stack0x00000484 + lVar15) = uVar24;
      if (*(uint *)(&stack0x00000954 + lVar15) == uVar24) break;
      puVar31 = *(undefined8 **)(&stack0x00000a58 + lVar15);
    }
    *(undefined8 *)(&stack0x00000b10 + lVar15) = *(undefined8 *)(&stack0x00000430 + lVar15);
    uVar23 = *(ushort *)(&stack0x00000438 + lVar15);
    *(ushort *)(&stack0x00000b18 + lVar15) = uVar23;
    lVar25 = **param_2;
    *(longlong *)(&stack0x00001300 + lVar15) = lVar25;
    (&stack0x000000a4)[lVar15] = 0;
    if (*(short *)(lVar25 + 0x24) == 0) {
LAB_:
      *(undefined8 *)(&stack0x00000548 + lVar15) = *(undefined8 *)(lVar25 + 0x28);
      uVar37 = *(ushort *)(lVar25 + 0x30);
      *(ushort *)(&stack0x00000550 + lVar15) = uVar37;
    }
    else {
      cVar9 = *(char *)(lVar25 + 1);
      if ((((cVar9 == '\v') || (cVar9 == '\b')) || (cVar9 == '\t')) &&
         (*(int *)(lVar25 + 0x18) == 99)) {
        *(undefined **)(&stack0x00001308 + lVar15) = &stack0x00000570 + lVar15;
        *(undefined4 **)(&stack0x00001310 + lVar15) = (undefined4 *)(lVar25 + 0x20);
        *(undefined4 *)(&stack0x00000570 + lVar15) = *(undefined4 *)(lVar25 + 0x20);
        *(undefined2 *)(&stack0x00000574 + lVar15) = *(undefined2 *)(lVar25 + 0x24);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102e83;
        cVar9 = func_0x(&stack0x00000570 + lVar15);
        if (cVar9 == '\0') goto LAB_;
        cVar9 = '\x01';
      }
      else {
LAB_:
        cVar9 = '\0';
      }
      (&stack0x000000a4)[lVar15] = cVar9;
      if (cVar9 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102ea8;
      func_0x(lVar25,&stack0x00000548 + lVar15);
      uVar37 = *(ushort *)(&stack0x00000550 + lVar15);
    }
    if ((*(uint *)(&stack0x00000430 + lVar15) < *(uint *)(&stack0x00000548 + lVar15)) ||
       ((*(uint *)(&stack0x00000430 + lVar15) == *(uint *)(&stack0x00000548 + lVar15) &&
        ((uVar24 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000548 + lVar15) >> 0x20),
         *(uint *)(&stack0x00000434 + lVar15) < uVar24 ||
         ((*(uint *)(&stack0x00000434 + lVar15) == uVar24 && (uVar23 < uVar37)))))))) {
      lVar25 = *(longlong *)(&stack0x00000070 + lVar15);
      lVar26 = *(longlong *)(lVar25 + 0x6b0);
      *(longlong *)(&stack0x00001318 + lVar15) = lVar26;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102f3f;
      func_0x(&stack0x00000548 + lVar15,&stack0x00002820 + lVar15,&stack0x00000958 + lVar15)
      ;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102f5c;
      func_0x(&stack0x00000b10 + lVar15,&stack0x00002850 + lVar15,&stack0x00000958 + lVar15)
      ;
      *(undefined4 *)(&stack0x00000d20 + lVar15) = 0x1d;
      *(undefined4 *)(&stack0x00000d24 + lVar15) = 0x10000;
      if ((_DAT_ & 0x10000) != 0) {
        *(undefined2 *)(&stack0x00000750 + lVar15) = 6;
        *(undefined **)(&stack0x00001320 + lVar15) = &stack0x00002100 + lVar15;
        *(undefined2 *)(&stack0x00002100 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002102 + lVar15) = 6;
        *(undefined4 *)(&stack0x00002108 + lVar15) = 0;
        *(undefined **)(&stack0x00002110 + lVar15) = &stack0x00002128 + lVar15;
        *(undefined **)(&stack0x00002118 + lVar15) = &stack0x00002188 + lVar15;
        *(undefined4 *)(&stack0x00002348 + lVar15) = 0;
        *(undefined4 *)(&stack0x0000234c + lVar15) = 0;
        *(undefined8 *)(&stack0x00002120 + lVar15) = 0;
        *(undefined8 *)(&stack0x00002350 + lVar15) = 0;
        *(undefined **)(&stack0x00001328 + lVar15) = &stack0x00002128 + lVar15;
        *(undefined **)(&stack0x00002128 + lVar15) = &stack0x00002358 + lVar15;
        *(undefined4 *)(&stack0x00002130 + lVar15) = 0x34;
        *(undefined2 *)(&stack0x00002134 + lVar15) = 5;
        *(undefined2 *)(&stack0x00002136 + lVar15) = 0;
        *(undefined **)(&stack0x00001330 + lVar15) = &stack0x00002138 + lVar15;
        *(undefined8 *)(&stack0x00002138 + lVar15) = 0x18b1f28;
        *(undefined4 *)(&stack0x00002140 + lVar15) = 0x10;
        *(undefined2 *)(&stack0x00002144 + lVar15) = 5;
        *(undefined2 *)(&stack0x00002146 + lVar15) = 0;
        *(undefined **)(&stack0x00001338 + lVar15) = &stack0x00002148 + lVar15;
        *(undefined8 *)(&stack0x00002148 + lVar15) = 0x18b1f28;
        *(undefined4 *)(&stack0x00002150 + lVar15) = 0x10;
        *(undefined2 *)(&stack0x00002154 + lVar15) = 6;
        *(undefined2 *)(&stack0x00002156 + lVar15) = 0;
        *(undefined **)(&stack0x00001340 + lVar15) = &stack0x00002158 + lVar15;
        *(undefined8 *)(&stack0x00002158 + lVar15) = 0;
        *(undefined4 *)(&stack0x00002160 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002164 + lVar15) = 7;
        *(undefined2 *)(&stack0x00002166 + lVar15) = 0;
        *(undefined **)(&stack0x00001348 + lVar15) = &stack0x00002168 + lVar15;
        *(undefined8 *)(&stack0x00002168 + lVar15) = 0;
        *(undefined4 *)(&stack0x00002170 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002174 + lVar15) = 8;
        *(undefined2 *)(&stack0x00002176 + lVar15) = 0;
        *(undefined **)(&stack0x00001350 + lVar15) = &stack0x00002178 + lVar15;
        *(undefined8 *)(&stack0x00002178 + lVar15) = 0;
        *(undefined4 *)(&stack0x00002180 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002184 + lVar15) = 9;
        *(undefined2 *)(&stack0x00002186 + lVar15) = 0;
        *(uint *)(&stack0x00002358 + lVar15) = (uint)*(ushort *)(lVar25 + 0x6b8);
        *(undefined2 *)(&stack0x0000235c + lVar15) = *(undefined2 *)(&stack0x00000184 + lVar15);
        *(undefined4 *)(&stack0x0000235e + lVar15) = *(undefined4 *)(&stack0x00000180 + lVar15);
        (&stack0x00002362)[lVar15] = (&stack0x00000051)[lVar15];
        lVar25 = **param_2;
        *(longlong *)(&stack0x00001358 + lVar15) = lVar25;
        (&stack0x00002363)[lVar15] = *(undefined *)(lVar25 + 1);
        *(undefined **)(&stack0x00001360 + lVar15) = &stack0x00002138 + lVar15;
        *(longlong *)(&stack0x00002138 + lVar15) = lVar26 + 0x254;
        *(undefined4 *)(&stack0x00002140 + lVar15) = 0x10;
        *(undefined2 *)(&stack0x00002144 + lVar15) = 5;
        *(undefined2 *)(&stack0x00002146 + lVar15) = 0;
        *(undefined **)(&stack0x00001368 + lVar15) = &stack0x00002148 + lVar15;
        *(longlong *)(&stack0x00002148 + lVar15) = lVar26 + 0x244;
        *(undefined4 *)(&stack0x00002150 + lVar15) = 0x10;
        *(undefined2 *)(&stack0x00002154 + lVar15) = 6;
        *(undefined2 *)(&stack0x00002156 + lVar15) = 0;
        *(undefined **)(&stack0x00001370 + lVar15) = &stack0x00002820 + lVar15;
        lVar25 = -1;
        do {
          lVar25 = lVar25 + 1;
        } while (*(short *)(&stack0x00002820 + lVar25 * 2 + lVar15) != 0);
        iVar14 = (int)lVar25 * 2;
        *(int *)(&stack0x00000ba0 + lVar15) = iVar14;
        *(undefined **)(&stack0x00001378 + lVar15) = &stack0x00002158 + lVar15;
        *(undefined **)(&stack0x00002158 + lVar15) = &stack0x00002820 + lVar15;
        *(int *)(&stack0x00002160 + lVar15) = iVar14;
        *(undefined2 *)(&stack0x00002164 + lVar15) = 7;
        *(undefined2 *)(&stack0x00002166 + lVar15) = 0;
        *(undefined **)(&stack0x00001380 + lVar15) = &stack0x00002850 + lVar15;
        lVar25 = -1;
        do {
          lVar25 = lVar25 + 1;
        } while (*(short *)(&stack0x00002850 + lVar25 * 2 + lVar15) != 0);
        iVar14 = (int)lVar25 * 2;
        *(int *)(&stack0x00000ba4 + lVar15) = iVar14;
        *(undefined **)(&stack0x00001388 + lVar15) = &stack0x00002168 + lVar15;
        *(undefined **)(&stack0x00002168 + lVar15) = &stack0x00002850 + lVar15;
        *(int *)(&stack0x00002170 + lVar15) = iVar14;
        *(undefined2 *)(&stack0x00002174 + lVar15) = 8;
        *(undefined2 *)(&stack0x00002176 + lVar15) = 0;
        *(undefined4 *)(&stack0x0000095c + lVar15) = 0;
        pcVar5 = *(code **)(_DAT_ + 0x10);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1032f9;
        lVar25 = (*pcVar5)(lVar26,&stack0x0000095c + lVar15);
        *(longlong *)(&stack0x00001390 + lVar15) = lVar25;
        if (lVar25 != 0) {
          lVar26 = -1;
          do {
            lVar26 = lVar26 + 1;
          } while (*(short *)(lVar25 + lVar26 * 2) != 0);
          iVar13 = (int)lVar26 * 2;
        }
        *(int *)(&stack0x00000ba8 + lVar15) = iVar13;
        lVar26 = *(longlong *)(&stack0x00002110 + lVar15);
        *(longlong **)(&stack0x00001398 + lVar15) = (longlong *)(lVar26 + 0x50);
        *(longlong *)(lVar26 + 0x50) = lVar25;
        *(int *)(lVar26 + 0x58) = iVar13;
        *(undefined2 *)(lVar26 + 0x5c) = 9;
        *(undefined2 *)(lVar26 + 0x5e) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103356;
        func_0x(&stack0x000020f8 + lVar15);
      }
    }
LAB_:
    if ((1 < *(short *)((longlong)param_2 + 0xc)) && ((&stack0x00000051)[lVar15] != -1)) {
      lVar25 = **param_2;
      *(longlong *)(&stack0x00001428 + lVar15) = lVar25;
      if (*(char *)(lVar25 + 1) != (&stack0x00000051)[lVar15]) {
        if (*(longlong *)(&stack0x000004a8 + lVar15) != 0) {
          *(longlong *)(&stack0x00001430 + lVar15) = lVar25;
          *(longlong *)(*(longlong *)(&stack0x000004a8 + lVar15) + 0x588) = lVar25;
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1037dc;
        lVar25 = func_0x();
        if (lVar25 == 0) {
LAB_:
          *(undefined4 *)(&stack0x00000978 + lVar15) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1037e6;
          lVar25 = func_0x();
          if (*(longlong *)(lVar25 + 0x30) == 0) goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1037f2;
          lVar25 = func_0x();
          uVar24 = *(uint *)(*(longlong *)(lVar25 + 0x30) + 0xc);
          *(uint *)(&stack0x00000bb4 + lVar15) = uVar24;
          if ((uVar24 < 0xe) && ((0x2640U >> (uVar24 & 0x1f) & 1) != 0)) {
            iVar13 = 1;
          }
          else {
            iVar13 = 0;
          }
          *(int *)(&stack0x00000978 + lVar15) = iVar13;
          if (iVar13 != 0) goto LAB_;
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103837;
        func_0x(0,8);
      }
    }
LAB_:
    *(undefined4 *)(&stack0x00000b30 + lVar15) = 0;
    *(undefined4 *)(&stack0x00000b34 + lVar15) = 0;
    *(undefined2 *)(&stack0x00000b38 + lVar15) = 0;
    if (((*(short *)(&stack0x00000610 + lVar15) == 0) && (*(int *)(&stack0x00000608 + lVar15) == 0))
       && (*(int *)(&stack0x0000060c + lVar15) == 0)) goto LAB_;
    plVar29 = *param_2;
    lVar25 = *plVar29;
    *(longlong *)(&stack0x00001438 + lVar15) = lVar25;
    if ((*(byte *)(lVar25 + 4) & 1) == 0) goto LAB_;
    puVar16 = (ushort *)((longlong)plVar29 + 0x62);
    *(ushort **)(&stack0x00001440 + lVar15) = puVar16;
    uVar23 = *puVar16;
    *(ushort *)(&stack0x00000238 + lVar15) = uVar23;
    if (((uVar23 & 0x400) == 0) || (*(short *)((longlong)param_2 + 0xc) < 3)) {
      *(int *)(&stack0x000000d8 + lVar15) = (int)*(short *)((longlong)param_2 + 0xc);
      plVar29 = *param_2;
      *(longlong **)(&stack0x000003e0 + lVar15) = plVar29;
      puVar18 = (undefined2 *)((longlong)plVar29 + 0x62);
      *(undefined2 **)(&stack0x00001448 + lVar15) = puVar18;
      uVar12 = *puVar18;
      *(undefined2 *)(&stack0x00000240 + lVar15) = uVar12;
      if (((byte)uVar12 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x000000d8 + lVar15) == 3) {
          *(undefined4 *)(&stack0x000000d8 + lVar15) = 4;
        }
        else if (*(int *)(&stack0x000000d8 + lVar15) < 2) goto LAB_;
        *(uint **)(&stack0x00001450 + lVar15) =
             (uint *)(*(longlong *)(&stack0x000003e0 + lVar15) + 100);
        uVar24 = *(uint *)(*(longlong *)(&stack0x000003e0 + lVar15) + 100);
        *(uint *)(&stack0x00000980 + lVar15) = uVar24;
        if ((((uVar24 & 8) != 0) &&
            (lVar25 = *(longlong *)(*(longlong *)(&stack0x000003e0 + lVar15) + 0x90), lVar25 != 0))
           && (*(longlong *)(&stack0x00001458 + lVar15) = lVar25, *(longlong *)(lVar25 + 0x758) != 0
              )) {
          uVar20 = *(undefined8 *)(lVar25 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10397c;
          func_0x
                    (uVar20,*(undefined8 *)(&stack0x000003e0 + lVar15),
                     *(undefined4 *)(&stack0x000000d8 + lVar15));
        }
      }
LAB_:
      (&stack0x00000363)[lVar15] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar33 = (uint *)(*(longlong *)(&stack0x000003e0 + lVar15) + 100);
        *(uint **)(&stack0x00001460 + lVar15) = puVar33;
        uVar24 = *puVar33;
        *(uint *)(&stack0x00000988 + lVar15) = uVar24;
        if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x000000d8 + lVar15))) {
          *(uint **)(&stack0x00001468 + lVar15) = puVar33;
          uVar24 = *puVar33;
          *(uint *)(&stack0x00000990 + lVar15) = uVar24;
          if (((uVar24 & 0xc0000000) != 0x40000000) &&
             (lVar25 = **(longlong **)(&stack0x000003e0 + lVar15), lVar25 != 0)) {
            *(undefined4 *)(&stack0x00000bb8 + lVar15) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103a0f;
            iVar13 = (*_DAT_)(lVar25,0x2000,2,&stack0x00000bbc + lVar15);
            if (iVar13 != 0) {
              LOCK();
              *puVar33 = *puVar33 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar33 = *puVar33 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar25 = *(longlong *)(&stack0x000003e0 + lVar15);
      uVar39 = *(undefined4 *)(&stack0x000000d8 + lVar15);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103a3e;
      func_0x(lVar25 + 0x98,uVar39);
      if ((_DAT_ != 0) &&
         ((&stack0x00000364)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103a68;
        func_0x(lVar25,0,uVar39);
      }
      *(uint *)((longlong)param_2 + 0xc) = *(uint *)((longlong)param_2 + 0xc) & 0xffff0000;
      *param_2 = (longlong *)0x0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1038b6;
      func_0x(param_2);
    }
    *(undefined4 *)(&stack0x00000f98 + lVar15) = 0x400060;
    *(undefined8 *)(&stack0x00000fa0 + lVar15) = 0;
    *(undefined8 *)(&stack0x00000fb0 + lVar15) = 0;
    *(undefined8 *)(&stack0x00000fa8 + lVar15) = 0;
    *(undefined8 *)(&stack0x00000fb8 + lVar15) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103ab4;
    func_0x(10,&stack0x00000f98 + lVar15);
    lVar26 = *(longlong *)(&stack0x00000070 + lVar15);
  } while( true );
LAB_:
  lVar25 = *(longlong *)(&stack0x00000900 + lVar15);
  *(int *)(lVar25 + 4) = *(int *)(lVar25 + 4) + 1;
  if (*(longlong *)(lVar25 + 0x58) != 0) {
    piVar30 = (int *)(*(longlong *)(lVar25 + 0x58) + 4);
    *piVar30 = *piVar30 + 1;
  }
  if ((*(uint *)(&stack0x00000044 + lVar15) & 0xff000000) != 0) {
    *(int *)(*(longlong *)(&stack0x00000900 + lVar15) + 8) =
         *(int *)(*(longlong *)(&stack0x00000900 + lVar15) + 8) + 1;
    if (*(longlong *)(lVar25 + 0x58) != 0) {
      piVar30 = (int *)(*(longlong *)(lVar25 + 0x58) + 8);
      *piVar30 = *piVar30 + 1;
    }
    if ((&stack0x00000048)[lVar15] != '\0') {
      *(int *)(*(longlong *)(&stack0x00000900 + lVar15) + 0xc) =
           *(int *)(*(longlong *)(&stack0x00000900 + lVar15) + 0xc) + 1;
      if (*(longlong *)(lVar25 + 0x58) != 0) {
        piVar30 = (int *)(*(longlong *)(lVar25 + 0x58) + 0xc);
        *piVar30 = *piVar30 + 1;
      }
    }
  }
  if (*(int *)(&stack0x00000ecc + lVar15) != 0) {
    lVar25 = **(longlong **)(&stack0x00000038 + lVar15);
    *(longlong *)(&stack0x000017b8 + lVar15) = lVar25;
    uVar2 = *(undefined *)(lVar25 + 1);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105919;
    func_0x
              (*(undefined8 *)(&stack0x00000d78 + lVar15),uVar2,&stack0x00000ec8 + lVar15,0xffffffff
              );
  }
  (&stack0x00000196)[lVar15] = 0;
  (&stack0x00000197)[lVar15] = 1;
  *(undefined4 *)(&stack0x000004c0 + lVar15) = 0;
  *(undefined2 *)(&stack0x000004c4 + lVar15) = 0;
  *(undefined2 *)(&stack0x000004c6 + lVar15) = 0;
  lVar25 = **(longlong **)(&stack0x00000a78 + lVar15);
  *(longlong *)(&stack0x00000d80 + lVar15) = lVar25;
  lVar26 = **(longlong **)(&stack0x00000038 + lVar15);
  *(longlong *)(&stack0x000017c0 + lVar15) = lVar26;
  lVar6 = *(longlong *)(lVar25 + 8);
  piVar30 = (int *)(lVar6 + 0x3c0);
  *(int **)(&stack0x000017c8 + lVar15) = piVar30;
  *(undefined4 *)(&stack0x00000698 + lVar15) = 0;
  if (*(int *)(lVar26 + 0x18) == *piVar30) {
    uVar23 = *(ushort *)(lVar6 + 0x3c4);
    if ((*(ushort *)(lVar26 + 6) != uVar23) && (1 < (uVar23 | *(ushort *)(lVar26 + 6))))
    goto LAB_;
    *(undefined4 *)(&stack0x00000698 + lVar15) = 1;
  }
  else {
LAB_:
    *(longlong *)(&stack0x000017d0 + lVar15) = lVar26;
    *(undefined4 *)(&stack0x000005b0 + lVar15) = 0;
    *(undefined2 *)(&stack0x000005b4 + lVar15) = 0;
    *(undefined2 *)(&stack0x000005b6 + lVar15) = 0;
    uVar39 = *(undefined4 *)(lVar26 + 0x18);
    *(undefined4 *)(&stack0x000005b0 + lVar15) = uVar39;
    uVar12 = *(undefined2 *)(lVar26 + 6);
    *(undefined2 *)(&stack0x000005b4 + lVar15) = uVar12;
    *(undefined4 *)(&stack0x000004c0 + lVar15) = uVar39;
    *(undefined2 *)(&stack0x000004c4 + lVar15) = uVar12;
    *(undefined2 *)(&stack0x000004c6 + lVar15) = 0;
    puVar18 = (undefined2 *)((longlong)*(longlong **)(&stack0x00000038 + lVar15) + 0x62);
    *(undefined2 **)(&stack0x000017d8 + lVar15) = puVar18;
    *(undefined2 *)(&stack0x00000298 + lVar15) = *puVar18;
    if (((*(ushort *)(&stack0x00000298 + lVar15) & 0x400) == 0) ||
       (*(short *)(&stack0x00000044 + lVar15) < 3)) {
      *(int *)(&stack0x00000108 + lVar15) = (int)*(short *)(&stack0x00000044 + lVar15);
      *(undefined8 *)(&stack0x00000908 + lVar15) = *(undefined8 *)(&stack0x00000038 + lVar15);
      *(undefined2 **)(&stack0x000017e0 + lVar15) = puVar18;
      uVar3 = *puVar18;
      *(undefined2 *)(&stack0x000002a0 + lVar15) = uVar3;
      if (((byte)uVar3 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x00000108 + lVar15) == 3) {
          *(undefined4 *)(&stack0x00000108 + lVar15) = 4;
        }
        else if (*(int *)(&stack0x00000108 + lVar15) < 2) goto LAB_;
        *(uint **)(&stack0x000017e8 + lVar15) =
             (uint *)(*(longlong *)(&stack0x00000038 + lVar15) + 100);
        uVar24 = *(uint *)(*(longlong *)(&stack0x00000038 + lVar15) + 100);
        *(uint *)(&stack0x000006a0 + lVar15) = uVar24;
        if ((((uVar24 & 8) != 0) &&
            (lVar26 = *(longlong *)(*(longlong *)(&stack0x00000038 + lVar15) + 0x90), lVar26 != 0))
           && (*(longlong *)(&stack0x000017f0 + lVar15) = lVar26, *(longlong *)(lVar26 + 0x758) != 0
              )) {
          uVar20 = *(undefined8 *)(lVar26 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105ae4;
          func_0x
                    (uVar20,*(undefined8 *)(&stack0x00000038 + lVar15),
                     *(undefined4 *)(&stack0x00000108 + lVar15));
        }
      }
LAB_:
      (&stack0x00000198)[lVar15] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar33 = (uint *)(*(longlong *)(&stack0x00000908 + lVar15) + 100);
        *(uint **)(&stack0x000017f8 + lVar15) = puVar33;
        uVar24 = *puVar33;
        *(uint *)(&stack0x000006a8 + lVar15) = uVar24;
        if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x00000108 + lVar15))) {
          *(uint **)(&stack0x00001800 + lVar15) = puVar33;
          uVar24 = *puVar33;
          *(uint *)(&stack0x000006b0 + lVar15) = uVar24;
          if (((uVar24 & 0xc0000000) != 0x40000000) &&
             (lVar26 = **(longlong **)(&stack0x00000908 + lVar15), lVar26 != 0)) {
            *(undefined4 *)(&stack0x00000c00 + lVar15) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105b79;
            iVar13 = (*_DAT_)(lVar26,0x2000,2,&stack0x00000c04 + lVar15);
            if (iVar13 != 0) {
              LOCK();
              *puVar33 = *puVar33 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar33 = *puVar33 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar26 = *(longlong *)(&stack0x00000908 + lVar15);
      uVar40 = *(undefined4 *)(&stack0x00000108 + lVar15);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105ba8;
      func_0x(lVar26 + 0x98,uVar40);
      if ((_DAT_ != 0) &&
         ((&stack0x00000199)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105bd2;
        func_0x(lVar26,0,uVar40);
      }
      *(uint *)(&stack0x00000044 + lVar15) = *(uint *)(&stack0x00000044 + lVar15) & 0xffff0000;
      *(undefined8 *)(&stack0x00000038 + lVar15) = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105a33;
      func_0x(&stack0x00000038 + lVar15);
    }
    *(undefined **)(&stack0x00001808 + lVar15) = &stack0x000005c0 + lVar15;
    *(undefined **)(&stack0x00001810 + lVar15) = &stack0x000005d0 + lVar15;
    lVar25 = *(longlong *)(lVar25 + 8);
    puVar27 = (undefined4 *)(lVar25 + 0x3c0);
    *(undefined4 **)(&stack0x00001818 + lVar15) = puVar27;
    *(undefined4 *)(&stack0x000005c0 + lVar15) = *puVar27;
    *(undefined2 *)(&stack0x000005c4 + lVar15) = *(undefined2 *)(lVar25 + 0x3c4);
    *(undefined2 *)(&stack0x000005c6 + lVar15) = 0;
    *(undefined4 *)(&stack0x000005d0 + lVar15) = uVar39;
    *(undefined2 *)(&stack0x000005d4 + lVar15) = uVar12;
    *(undefined2 *)(&stack0x000005d6 + lVar15) = 0;
    pcVar5 = *(code **)**(undefined8 **)(&stack0x00000d80 + lVar15);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105c57;
    uVar12 = (*pcVar5)();
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) =
         *(undefined4 *)(*(longlong *)(&stack0x00000a78 + lVar15) + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105c87;
    func_0x(&stack0x00000178 + lVar15,&stack0x000005d0 + lVar15,uVar12,
                    &stack0x000005c0 + lVar15);
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105c99;
  func_0x(&stack0x00000ef8 + lVar15,&stack0x00000038 + lVar15);
  lVar25 = **param_2;
  goto LAB_;
LAB_:
  lVar25 = *(longlong *)(&stack0x000008d8 + lVar15);
  *(int *)(lVar25 + 4) = *(int *)(lVar25 + 4) + 1;
  if (*(longlong *)(lVar25 + 0x58) != 0) {
    piVar30 = (int *)(*(longlong *)(lVar25 + 0x58) + 4);
    *piVar30 = *piVar30 + 1;
  }
  if ((*(uint *)((longlong)param_2 + 0xc) & 0xff000000) != 0) {
    *(int *)(*(longlong *)(&stack0x000008d8 + lVar15) + 8) =
         *(int *)(*(longlong *)(&stack0x000008d8 + lVar15) + 8) + 1;
    if (*(longlong *)(lVar25 + 0x58) != 0) {
      piVar30 = (int *)(*(longlong *)(lVar25 + 0x58) + 8);
      *piVar30 = *piVar30 + 1;
    }
    if (*(char *)(param_2 + 2) != '\0') {
      *(int *)(*(longlong *)(&stack0x000008d8 + lVar15) + 0xc) =
           *(int *)(*(longlong *)(&stack0x000008d8 + lVar15) + 0xc) + 1;
      if (*(longlong *)(lVar25 + 0x58) != 0) {
        piVar30 = (int *)(*(longlong *)(lVar25 + 0x58) + 0xc);
        *piVar30 = *piVar30 + 1;
      }
    }
  }
  if (*(int *)(&stack0x00000eb4 + lVar15) != 0) {
    lVar25 = **param_2;
    *(longlong *)(&stack0x00001470 + lVar15) = lVar25;
    uVar2 = *(undefined *)(lVar25 + 1);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103b4f;
    func_0x
              (*(undefined8 *)(&stack0x00000d28 + lVar15),uVar2,&stack0x00000eb0 + lVar15,0xffffffff
              );
  }
  (&stack0x00000365)[lVar15] = 0;
  (&stack0x00000366)[lVar15] = 1;
  *(undefined4 *)(&stack0x000004b0 + lVar15) = 0;
  *(undefined2 *)(&stack0x000004b4 + lVar15) = 0;
  *(undefined2 *)(&stack0x000004b6 + lVar15) = 0;
  lVar25 = **(longlong **)(&stack0x00000a20 + lVar15);
  *(longlong *)(&stack0x00000d30 + lVar15) = lVar25;
  plVar29 = *param_2;
  lVar26 = *plVar29;
  *(longlong *)(&stack0x00001478 + lVar15) = lVar26;
  lVar6 = *(longlong *)(lVar25 + 8);
  piVar30 = (int *)(lVar6 + 0x3c0);
  *(int **)(&stack0x00001480 + lVar15) = piVar30;
  *(undefined4 *)(&stack0x00000998 + lVar15) = 0;
  if (*(int *)(lVar26 + 0x18) == *piVar30) {
    uVar23 = *(ushort *)(lVar6 + 0x3c4);
    if ((*(ushort *)(lVar26 + 6) != uVar23) && (1 < (uVar23 | *(ushort *)(lVar26 + 6))))
    goto LAB_;
    *(undefined4 *)(&stack0x00000998 + lVar15) = 1;
  }
  else {
LAB_:
    *(longlong *)(&stack0x00001488 + lVar15) = lVar26;
    *(undefined4 *)(&stack0x000005d8 + lVar15) = 0;
    *(undefined2 *)(&stack0x000005dc + lVar15) = 0;
    *(undefined2 *)(&stack0x000005de + lVar15) = 0;
    uVar39 = *(undefined4 *)(lVar26 + 0x18);
    *(undefined4 *)(&stack0x000005d8 + lVar15) = uVar39;
    uVar12 = *(undefined2 *)(lVar26 + 6);
    *(undefined2 *)(&stack0x000005dc + lVar15) = uVar12;
    *(undefined4 *)(&stack0x000004b0 + lVar15) = uVar39;
    *(undefined2 *)(&stack0x000004b4 + lVar15) = uVar12;
    *(undefined2 *)(&stack0x000004b6 + lVar15) = 0;
    puVar18 = (undefined2 *)((longlong)plVar29 + 0x62);
    *(undefined2 **)(&stack0x00001490 + lVar15) = puVar18;
    *(undefined2 *)(&stack0x00000248 + lVar15) = *puVar18;
    if (((*(ushort *)(&stack0x00000248 + lVar15) & 0x400) == 0) ||
       (*(short *)((longlong)param_2 + 0xc) < 3)) {
      *(int *)(&stack0x000000e0 + lVar15) = (int)*(short *)((longlong)param_2 + 0xc);
      plVar29 = *param_2;
      *(longlong **)(&stack0x000003e8 + lVar15) = plVar29;
      puVar18 = (undefined2 *)((longlong)plVar29 + 0x62);
      *(undefined2 **)(&stack0x00001498 + lVar15) = puVar18;
      uVar3 = *puVar18;
      *(undefined2 *)(&stack0x00000250 + lVar15) = uVar3;
      if (((byte)uVar3 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x000000e0 + lVar15) == 3) {
          *(undefined4 *)(&stack0x000000e0 + lVar15) = 4;
        }
        else if (*(int *)(&stack0x000000e0 + lVar15) < 2) goto LAB_;
        *(uint **)(&stack0x000014a0 + lVar15) =
             (uint *)(*(longlong *)(&stack0x000003e8 + lVar15) + 100);
        uVar24 = *(uint *)(*(longlong *)(&stack0x000003e8 + lVar15) + 100);
        *(uint *)(&stack0x000009a0 + lVar15) = uVar24;
        if ((((uVar24 & 8) != 0) &&
            (lVar26 = *(longlong *)(*(longlong *)(&stack0x000003e8 + lVar15) + 0x90), lVar26 != 0))
           && (*(longlong *)(&stack0x000014a8 + lVar15) = lVar26, *(longlong *)(lVar26 + 0x758) != 0
              )) {
          uVar20 = *(undefined8 *)(lVar26 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103d31;
          func_0x
                    (uVar20,*(undefined8 *)(&stack0x000003e8 + lVar15),
                     *(undefined4 *)(&stack0x000000e0 + lVar15));
        }
      }
LAB_:
      (&stack0x00000367)[lVar15] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar33 = (uint *)(*(longlong *)(&stack0x000003e8 + lVar15) + 100);
        *(uint **)(&stack0x000014b0 + lVar15) = puVar33;
        uVar24 = *puVar33;
        *(uint *)(&stack0x000009a8 + lVar15) = uVar24;
        if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x000000e0 + lVar15))) {
          *(uint **)(&stack0x000014b8 + lVar15) = puVar33;
          uVar24 = *puVar33;
          *(uint *)(&stack0x000009b0 + lVar15) = uVar24;
          if (((uVar24 & 0xc0000000) != 0x40000000) &&
             (lVar26 = **(longlong **)(&stack0x000003e8 + lVar15), lVar26 != 0)) {
            *(undefined4 *)(&stack0x00000bc0 + lVar15) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103dc6;
            iVar13 = (*_DAT_)(lVar26,0x2000,2,&stack0x00000bc4 + lVar15);
            if (iVar13 != 0) {
              LOCK();
              *puVar33 = *puVar33 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar33 = *puVar33 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar26 = *(longlong *)(&stack0x000003e8 + lVar15);
      uVar40 = *(undefined4 *)(&stack0x000000e0 + lVar15);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103df5;
      func_0x(lVar26 + 0x98,uVar40);
      if ((_DAT_ != 0) &&
         ((&stack0x00000368)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103e1f;
        func_0x(lVar26,0,uVar40);
      }
      *(uint *)((longlong)param_2 + 0xc) = *(uint *)((longlong)param_2 + 0xc) & 0xffff0000;
      *param_2 = (longlong *)0x0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103c6b;
      func_0x(param_2);
    }
    *(undefined **)(&stack0x000014c0 + lVar15) = &stack0x000005e0 + lVar15;
    *(undefined **)(&stack0x000014c8 + lVar15) = &stack0x000005e8 + lVar15;
    lVar25 = *(longlong *)(lVar25 + 8);
    puVar27 = (undefined4 *)(lVar25 + 0x3c0);
    *(undefined4 **)(&stack0x000014d0 + lVar15) = puVar27;
    *(undefined4 *)(&stack0x000005e0 + lVar15) = *puVar27;
    *(undefined2 *)(&stack0x000005e4 + lVar15) = *(undefined2 *)(lVar25 + 0x3c4);
    *(undefined2 *)(&stack0x000005e6 + lVar15) = 0;
    *(undefined4 *)(&stack0x000005e8 + lVar15) = uVar39;
    *(undefined2 *)(&stack0x000005ec + lVar15) = uVar12;
    *(undefined2 *)(&stack0x000005ee + lVar15) = 0;
    pcVar5 = *(code **)**(undefined8 **)(&stack0x00000d30 + lVar15);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103ea3;
    uVar12 = (*pcVar5)();
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) =
         *(undefined4 *)(*(longlong *)(&stack0x00000a20 + lVar15) + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103ed3;
    func_0x(&stack0x00000180 + lVar15,&stack0x000005e8 + lVar15,uVar12,
                    &stack0x000005e0 + lVar15);
  }
  ppbVar34 = (byte **)0x0;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103eee;
  func_0x(&stack0x00000ef8 + lVar15,*(undefined8 *)(&stack0x00000920 + lVar15));
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103efe;
  func_0x(&stack0x00000ef8 + lVar15,pplVar4);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103f0e;
  func_0x(&stack0x00000ef8 + lVar15,param_2);
  lVar25 = **pplVar4;
  *(longlong *)(&stack0x000014d8 + lVar15) = lVar25;
  if (*(short *)(lVar25 + 0x16) != 1) {
    *(undefined2 *)(&stack0x00000f38 + lVar15) = 0xffff;
    *(undefined8 *)(&stack0x00000f40 + lVar15) = 0;
    *(undefined4 *)(&stack0x00000f3c + lVar15) = 0;
    *(undefined8 *)(&stack0x00000f56 + lVar15) = 0;
    *(undefined8 *)(&stack0x00000f60 + lVar15) = 0;
    *(undefined8 *)(&stack0x00000f48 + lVar15) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106e74;
    func_0x(&stack0x000028e8 + lVar15,0,0xa58);
    *(undefined (*) [16])(&stack0x000026d0 + lVar15) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x000026a8 + lVar15) = ZEXT816(0);
    lVar25 = **pplVar4;
    *(longlong *)(&stack0x000019d8 + lVar15) = lVar25;
    iVar13 = *(ushort *)(lVar25 + 0x16) - 1;
    *(int *)(&stack0x00000338 + lVar15) = iVar13;
    *(int *)(&stack0x00000c44 + lVar15) = iVar13;
    *(longlong *)(&stack0x000019e0 + lVar15) = lVar25;
    *(int *)(&stack0x00002744 + lVar15) = iVar13;
    if (-1 < *(char *)(lVar25 + 2)) {
      *(undefined8 *)(&stack0x00000918 + lVar15) = 0;
      ppbVar38 = ppbVar34;
      goto LAB_;
    }
    if (*(short *)(&stack0x00002710 + lVar15) == 0) {
      *(undefined8 *)(&stack0x00000918 + lVar15) = 0;
LAB_:
      *(undefined **)(&stack0x000019e8 + lVar15) = &stack0x00002748 + lVar15;
      *(undefined (*) [16])(&stack0x00002748 + lVar15) = ZEXT816(0);
      *(undefined (*) [16])(&stack0x00002758 + lVar15) = ZEXT816(0);
      *(undefined (*) [16])(&stack0x00002768 + lVar15) = ZEXT816(0);
      *(undefined (*) [16])(&stack0x00002778 + lVar15) = ZEXT816(0);
      *(undefined (*) [16])(&stack0x00002788 + lVar15) = ZEXT816(0);
      *(undefined (*) [16])(&stack0x00002798 + lVar15) = ZEXT816(0);
      *(undefined (*) [16])(&stack0x000027a8 + lVar15) = ZEXT816(0);
      *(undefined8 *)(&stack0x000027b8 + lVar15) = 0;
      *(undefined **)(&stack0x000019f0 + lVar15) = &stack0x00002748 + lVar15;
      *(undefined (*) [16])(&stack0x00002748 + lVar15) = ZEXT816(0);
      *(undefined **)(&stack0x000019f8 + lVar15) = &stack0x00002758 + lVar15;
      *(undefined2 *)(&stack0x00002758 + lVar15) = 0xffff;
      *(undefined8 *)(&stack0x00002760 + lVar15) = 0;
      *(undefined4 *)(&stack0x0000275c + lVar15) = 0;
      *(undefined8 *)(&stack0x00002776 + lVar15) = 0;
      *(undefined8 *)(&stack0x00002780 + lVar15) = 0;
      *(undefined8 *)(&stack0x00002768 + lVar15) = 0;
      *(undefined **)(&stack0x00001a00 + lVar15) = &stack0x00002790 + lVar15;
      *(undefined8 *)(&stack0x00002790 + lVar15) = 0;
      *(undefined **)(&stack0x00001a08 + lVar15) = &stack0x000027a8 + lVar15;
      *(undefined4 *)(&stack0x000027a8 + lVar15) = 0;
      *(undefined4 *)(&stack0x000027ac + lVar15) = 0;
      *(undefined2 *)(&stack0x000027b0 + lVar15) = 0;
      *(undefined2 *)(&stack0x000027b2 + lVar15) = 0;
      *(undefined **)(&stack0x00001a10 + lVar15) = &stack0x000027b4 + lVar15;
      *(undefined2 *)(&stack0x000027ba + lVar15) = 0;
      ppbVar38 = (byte **)(&stack0x00002748 + lVar15);
      *(byte ***)(&stack0x00000918 + lVar15) = ppbVar38;
    }
    else {
      ppbVar38 = *(byte ***)(&stack0x00002720 + lVar15);
      *(byte ***)(&stack0x00000918 + lVar15) = ppbVar38;
      if (ppbVar38 == (byte **)0x0) goto LAB_;
    }
    (&stack0x00000098)[lVar15] = 0;
    if (*(short *)(lVar25 + 0x24) == 0) {
LAB_:
      *(undefined8 *)(&stack0x00000380 + lVar15) = *(undefined8 *)(lVar25 + 0x28);
      sVar11 = *(short *)(lVar25 + 0x30);
      *(short *)(&stack0x00000388 + lVar15) = sVar11;
    }
    else {
      cVar9 = *(char *)(lVar25 + 1);
      if ((((cVar9 == '\v') || (cVar9 == '\b')) || (cVar9 == '\t')) &&
         (*(int *)(lVar25 + 0x18) == 99)) {
        *(undefined **)(&stack0x00001a18 + lVar15) = &stack0x000005a0 + lVar15;
        *(undefined4 **)(&stack0x00001a20 + lVar15) = (undefined4 *)(lVar25 + 0x20);
        *(undefined4 *)(&stack0x000005a0 + lVar15) = *(undefined4 *)(lVar25 + 0x20);
        *(undefined2 *)(&stack0x000005a4 + lVar15) = *(undefined2 *)(lVar25 + 0x24);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1070a0;
        cVar9 = func_0x(&stack0x000005a0 + lVar15);
        if (cVar9 == '\0') goto LAB_;
        cVar9 = '\x01';
      }
      else {
LAB_:
        cVar9 = '\0';
      }
      (&stack0x00000098)[lVar15] = cVar9;
      if (cVar9 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1070c5;
      func_0x(lVar25,&stack0x00000380 + lVar15);
      sVar11 = *(short *)(&stack0x00000388 + lVar15);
    }
    *(undefined **)(&stack0x00001a28 + lVar15) = &stack0x00000380 + lVar15;
    *(undefined4 **)(&stack0x00001a30 + lVar15) = (undefined4 *)(lVar25 + 0x20);
    pbVar36 = (byte *)(lVar25 + 0x60);
    *(byte **)(&stack0x00001a38 + lVar15) = pbVar36;
    *(byte ***)(&stack0x00001a40 + lVar15) = ppbVar38;
    if (pbVar36 == *ppbVar38) {
      *(byte ***)(&stack0x00001a48 + lVar15) = ppbVar38 + 0xc;
      if (((sVar11 == *(short *)(ppbVar38 + 0xd)) &&
          (*(int *)(&stack0x00000380 + lVar15) == *(int *)(ppbVar38 + 0xc))) &&
         (*(int *)(&stack0x00000384 + lVar15) == *(int *)((longlong)ppbVar38 + 100))) {
        *(longlong *)(&stack0x00001a50 + lVar15) = (longlong)ppbVar38 + 0x6c;
      }
    }
    *ppbVar38 = pbVar36;
    *(byte ***)(&stack0x00001a58 + lVar15) = ppbVar38 + 0xc;
    uVar12 = *(undefined2 *)(&stack0x00000388 + lVar15);
    *(undefined2 *)(&stack0x00000780 + lVar15) = uVar12;
    uVar39 = *(undefined4 *)(&stack0x00000384 + lVar15);
    *(undefined4 *)(&stack0x00000c48 + lVar15) = uVar39;
    *(undefined4 *)(&stack0x00000c50 + lVar15) = *(undefined4 *)(&stack0x00000380 + lVar15);
    *(undefined4 *)(ppbVar38 + 0xc) = *(undefined4 *)(&stack0x00000380 + lVar15);
    *(undefined4 *)((longlong)ppbVar38 + 100) = uVar39;
    *(undefined2 *)(ppbVar38 + 0xd) = uVar12;
    *(undefined4 **)(&stack0x00001a60 + lVar15) = (undefined4 *)((longlong)ppbVar38 + 0x6c);
    *(undefined4 *)((longlong)ppbVar38 + 0x6c) = *(undefined4 *)(lVar25 + 0x20);
    *(undefined2 *)(ppbVar38 + 0xe) = *(undefined2 *)(lVar25 + 0x24);
    *(undefined2 *)((longlong)ppbVar38 + 0x72) = 0;
    uVar21 = (ulonglong)*pbVar36;
    *(ushort *)(&stack0x00000788 + lVar15) = (ushort)*pbVar36;
    *(undefined4 *)(&stack0x00000a98 + lVar15) = *(undefined4 *)(uVar21 * 6 + 0x177fa30);
    *(undefined2 *)(&stack0x00000a9c + lVar15) = *(undefined2 *)(uVar21 * 6 + 0x177fa34);
    *(undefined4 *)(&stack0x000007b0 + lVar15) = *(undefined4 *)(uVar21 * 6 + 0x177fa30);
    sVar11 = *(short *)(uVar21 * 6 + 0x177fa34);
    *(short *)(&stack0x00000054 + lVar15) = sVar11;
    *(short *)(&stack0x000007b4 + lVar15) = sVar11;
    *(longlong *)(&stack0x00001a68 + lVar15) = lVar25 + 99;
    ppbVar1 = ppbVar38 + 2;
    *(byte ***)(&stack0x00001a70 + lVar15) = ppbVar1;
    *(undefined2 *)ppbVar1 = 0xffff;
    ppbVar38[3] = (byte *)0x0;
    *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar38 + 0x2e) = 0;
    ppbVar38[7] = (byte *)0x0;
    ppbVar38[4] = (byte *)0x0;
    *(byte ***)(&stack0x00001a78 + lVar15) = ppbVar38 + 9;
    ppbVar38[9] = (byte *)0x0;
    ppbVar38[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar38 + 0xb) = 0;
    if ((**ppbVar38 & 2) == 0) goto code_r0x001075ce;
    pbVar36 = pbVar36 + sVar11;
    *(byte **)(&stack0x00001a80 + lVar15) = pbVar36;
    *(byte ***)(&stack0x00001a88 + lVar15) = ppbVar1;
    bVar10 = *pbVar36 & 1;
    *(ushort *)(&stack0x00000790 + lVar15) = (ushort)bVar10;
    *(ushort *)ppbVar1 = (ushort)bVar10;
    puVar16 = (ushort *)((longlong)ppbVar38 + 0x12);
    if (bVar10 != 0) {
      *(ushort **)(&stack0x00001aa0 + lVar15) = puVar16;
      ppbVar38[3] = pbVar36;
      bVar10 = *pbVar36;
      switch(bVar10 & 0x1c) {
      default:
        puVar32 = (ushort *)(pbVar36 + 1);
        *(ushort **)(&stack0x00001aa8 + lVar15) = puVar32;
        if ((char)*(byte *)puVar32 < '\0') {
          uVar23 = *puVar32;
          *puVar16 = uVar23;
          *puVar16 = (uVar23 & 0x7f) << 8 | uVar23 >> 8;
          *(undefined2 *)(ppbVar38 + 5) = 3;
          sVar11 = 3;
        }
        else {
          *puVar16 = (ushort)*(byte *)puVar32;
          *(undefined2 *)(ppbVar38 + 5) = 2;
          sVar11 = 2;
        }
        *(short *)((longlong)ppbVar38 + 0x2c) = (short)(*puVar16 + 1 >> 1) + sVar11;
        if (*puVar16 < 0x1f) {
          *(undefined2 *)((longlong)ppbVar38 + 0x2a) = 0;
          *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
          *(undefined4 *)(ppbVar38 + 8) = 0;
        }
        else {
          iVar13 = *puVar16 - 1;
          *(short *)((longlong)ppbVar38 + 0x2a) =
               ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
               (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
          *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
          *(undefined4 *)(ppbVar38 + 8) = 0;
        }
        break;
      case 4:
        *(byte **)(&stack0x00001ab8 + lVar15) = pbVar36;
        *(byte **)(&stack0x00001ac0 + lVar15) = pbVar36;
        if (((bVar10 & 0x1c) == 4) && ((bVar10 & 2) != 0)) {
          ppbVar38[3] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
          *(undefined2 *)(ppbVar38 + 5) = 0;
          *puVar16 = 0;
          *(undefined2 *)((longlong)ppbVar38 + 0x2a) = 0;
          *(undefined2 *)((longlong)ppbVar38 + 0x2c) = 0;
          *(undefined2 *)((longlong)ppbVar38 + 0x2e) = 0;
          *(undefined2 *)(ppbVar38 + 6) = 0;
          *(undefined2 *)((longlong)ppbVar38 + 0x32) = 0;
          *(undefined2 *)((longlong)ppbVar38 + 0x34) = 0;
          *(undefined2 *)((longlong)ppbVar38 + 0x36) = 0;
          ppbVar38[4] = (byte *)0x0;
          *(undefined4 *)(ppbVar38 + 8) = 0;
          ppbVar38[7] = (byte *)0x0;
          ppbVar38[3] = pbVar36;
          *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0xf;
          *(undefined4 *)(ppbVar38 + 8) = 0;
          *(undefined4 *)(ppbVar38 + 8) = 1;
        }
        else {
          ppbVar38[3] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
          *(undefined2 *)(ppbVar38 + 5) = 0;
          *puVar16 = 0;
          *(undefined2 *)((longlong)ppbVar38 + 0x2a) = 0;
          *(undefined2 *)((longlong)ppbVar38 + 0x2c) = 0;
          *(undefined2 *)((longlong)ppbVar38 + 0x2e) = 0;
          *(undefined2 *)(ppbVar38 + 6) = 0;
          *(undefined2 *)((longlong)ppbVar38 + 0x32) = 0;
          *(undefined2 *)((longlong)ppbVar38 + 0x34) = 0;
          *(undefined2 *)((longlong)ppbVar38 + 0x36) = 0;
          ppbVar38[4] = (byte *)0x0;
          *(undefined4 *)(ppbVar38 + 8) = 0;
          ppbVar38[7] = (byte *)0x0;
          ppbVar38[3] = pbVar36;
          *(undefined4 *)((longlong)ppbVar38 + 0x14) = 1;
          *(undefined4 *)(ppbVar38 + 8) = 0;
        }
        break;
      case 8:
        *(byte **)(&stack0x00001ab0 + lVar15) = pbVar36;
        ppbVar38[3] = (byte *)0x0;
        *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
        *(undefined2 *)(ppbVar38 + 5) = 0;
        *puVar16 = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x2a) = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x2c) = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x2e) = 0;
        *(undefined2 *)(ppbVar38 + 6) = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x32) = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x34) = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x36) = 0;
        ppbVar38[4] = (byte *)0x0;
        *(undefined4 *)(ppbVar38 + 8) = 0;
        ppbVar38[7] = (byte *)0x0;
        ppbVar38[3] = pbVar36;
        *(undefined4 *)((longlong)ppbVar38 + 0x14) = 9;
        *(undefined4 *)(ppbVar38 + 8) = 0;
      }
      ppbVar38[7] = (byte *)0x0;
      ppbVar38[4] = (byte *)0x0;
      sVar11 = *(short *)(&stack0x00000054 + lVar15);
      goto code_r0x001075ce;
    }
    *(undefined4 *)(&stack0x00000328 + lVar15) = 0;
    *(ushort **)(&stack0x00001a90 + lVar15) = puVar16;
    ppbVar38[3] = pbVar36;
    *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
    *(undefined4 *)((longlong)ppbVar38 + 0x36) = 0;
    pbVar7 = ppbVar38[3];
    *(byte **)(&stack0x00001a98 + lVar15) = pbVar7;
    switch(*pbVar7 & 0xe) {
    default:
      uVar23 = *(ushort *)(pbVar36 + 2);
      ppbVar34 = (byte **)(ulonglong)uVar23;
      *(uint *)(&stack0x00000328 + lVar15) = (uint)uVar23;
      if (0x1f9d < uVar23 - 1) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x107306;
        func_0x(pbVar7,6);
      }
      break;
    case 4:
      ppbVar34 = (byte **)0x9;
      goto code_r0x00107311;
    case 6:
    case 10:
      break;
    case 0xe:
      ppbVar34 = (byte **)0x1;
code_r0x00107311:
      *(int *)(&stack0x00000328 + lVar15) = (int)ppbVar34;
    }
    *(int *)(ppbVar38 + 4) = (int)ppbVar34;
    *(undefined8 *)((longlong)ppbVar38 + 0x2e) = 0;
    sVar11 = *(short *)(&stack0x00000054 + lVar15);
code_r0x001075ce:
    if ((**ppbVar38 & 4) != 0) {
      if (*(short *)(&stack0x000007b2 + lVar15) == 0) {
        uVar21 = (ulonglong)sVar11;
      }
      else {
        uVar21 = (ulonglong)
                 *(ushort *)(lVar25 + 0x61 + (longlong)*(short *)(&stack0x000007b2 + lVar15) * 2);
      }
      psVar22 = (short *)(uVar21 + lVar25 + 0x60);
      *(short **)(&stack0x00001ac8 + lVar15) = psVar22;
      *(byte ***)(&stack0x00001ad0 + lVar15) = ppbVar38 + 9;
      ppbVar38[9] = (byte *)psVar22;
      sVar11 = *psVar22;
      *(short *)(&stack0x00000794 + lVar15) = sVar11;
      ppbVar38[10] = (byte *)(psVar22 + 1);
      *(short *)(ppbVar38 + 0xb) = (sVar11 + 1) * 2;
    }
    pbVar36 = ppbVar38[1];
    if (pbVar36 != (byte *)0x0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x107635;
      func_0x(pbVar36,ppbVar38);
    }
LAB_:
    sVar11 = 3;
    uVar23 = *(ushort *)(lVar25 + 0xe);
    uVar24 = (uint)uVar23;
    *(uint *)(&stack0x00000c58 + lVar15) = (uint)uVar23;
    pbVar36 = (byte *)((ulonglong)
                       *(ushort *)
                        (lVar25 + (0xfff - (longlong)*(int *)(&stack0x00000338 + lVar15)) * 2) +
                      lVar25);
    *(byte **)(&stack0x00001ad8 + lVar15) = pbVar36;
    bVar10 = *pbVar36 & 1;
    *(ushort *)(&stack0x00000798 + lVar15) = (ushort)bVar10;
    *(ushort *)(&stack0x00002710 + lVar15) = (ushort)bVar10;
    if (bVar10 == 0) {
      *(uint *)(&stack0x00000330 + lVar15) = (uint)uVar23;
      *(undefined **)(&stack0x00001ae0 + lVar15) = &stack0x00002712 + lVar15;
      *(byte **)(&stack0x00002718 + lVar15) = pbVar36;
      *(undefined4 *)(&stack0x00002714 + lVar15) = 0;
      *(undefined4 *)(&stack0x00002736 + lVar15) = 0;
      *(byte **)(&stack0x00001ae8 + lVar15) = pbVar36;
      switch(*pbVar36 & 0xe) {
      default:
        uVar23 = *(ushort *)(pbVar36 + 2);
        uVar24 = (uint)uVar23;
        *(uint *)(&stack0x00000330 + lVar15) = (uint)uVar23;
        if (0x1f9d < uVar23 - 1) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1076f0;
          func_0x(pbVar36,6);
        }
        break;
      case 4:
        uVar24 = 9;
        *(undefined4 *)(&stack0x00000330 + lVar15) = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar24 = 1;
        *(undefined4 *)(&stack0x00000330 + lVar15) = 1;
      }
      *(uint *)(&stack0x00002720 + lVar15) = uVar24;
      *(longlong *)(&stack0x0000272e + lVar15) = lVar25 + 0x2000;
    }
    else {
      *(undefined **)(&stack0x00001af0 + lVar15) = &stack0x00002712 + lVar15;
      *(byte **)(&stack0x00002718 + lVar15) = pbVar36;
      bVar10 = *pbVar36;
      switch(bVar10 & 0x1c) {
      default:
        puVar16 = (ushort *)(pbVar36 + 1);
        *(ushort **)(&stack0x00001af8 + lVar15) = puVar16;
        if ((char)*(byte *)puVar16 < '\0') {
          uVar23 = *puVar16;
          *(ushort *)(&stack0x00002712 + lVar15) = uVar23;
          uVar23 = (uVar23 & 0x7f) << 8 | uVar23 >> 8;
          *(ushort *)(&stack0x00002712 + lVar15) = uVar23;
          *(undefined2 *)(&stack0x00002728 + lVar15) = 3;
        }
        else {
          uVar23 = (ushort)*(byte *)puVar16;
          *(ushort *)(&stack0x00002712 + lVar15) = uVar23;
          *(undefined2 *)(&stack0x00002728 + lVar15) = 2;
          sVar11 = 2;
        }
        *(short *)(&stack0x0000272c + lVar15) = (short)(uVar23 + 1 >> 1) + sVar11;
        if (uVar23 < 0x1f) {
          *(undefined2 *)(&stack0x0000272a + lVar15) = 0;
          *(undefined4 *)(&stack0x00002714 + lVar15) = 0;
          *(undefined4 *)(&stack0x00002740 + lVar15) = 0;
        }
        else {
          iVar13 = uVar23 - 1;
          *(short *)(&stack0x0000272a + lVar15) =
               ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
               (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
          *(undefined4 *)(&stack0x00002714 + lVar15) = 0;
          *(undefined4 *)(&stack0x00002740 + lVar15) = 0;
        }
        break;
      case 4:
        *(byte **)(&stack0x00001b08 + lVar15) = pbVar36;
        *(byte **)(&stack0x00001b10 + lVar15) = pbVar36;
        if (((bVar10 & 0x1c) == 4) && ((bVar10 & 2) != 0)) {
          *(undefined8 *)(&stack0x00002718 + lVar15) = 0;
          *(undefined4 *)(&stack0x00002714 + lVar15) = 0;
          *(undefined2 *)(&stack0x00002728 + lVar15) = 0;
          *(undefined2 *)(&stack0x00002712 + lVar15) = 0;
          *(undefined2 *)(&stack0x0000272a + lVar15) = 0;
          *(undefined2 *)(&stack0x0000272c + lVar15) = 0;
          *(undefined2 *)(&stack0x0000272e + lVar15) = 0;
          *(undefined2 *)(&stack0x00002730 + lVar15) = 0;
          *(undefined2 *)(&stack0x00002732 + lVar15) = 0;
          *(undefined2 *)(&stack0x00002734 + lVar15) = 0;
          *(undefined2 *)(&stack0x00002736 + lVar15) = 0;
          *(undefined8 *)(&stack0x00002720 + lVar15) = 0;
          *(undefined4 *)(&stack0x00002740 + lVar15) = 0;
          *(undefined8 *)(&stack0x00002738 + lVar15) = 0;
          *(byte **)(&stack0x00002718 + lVar15) = pbVar36;
          *(undefined4 *)(&stack0x00002714 + lVar15) = 0xf;
          *(undefined4 *)(&stack0x00002740 + lVar15) = 0;
          *(undefined4 *)(&stack0x00002740 + lVar15) = 1;
        }
        else {
          *(undefined8 *)(&stack0x00002718 + lVar15) = 0;
          *(undefined4 *)(&stack0x00002714 + lVar15) = 0;
          *(undefined2 *)(&stack0x00002728 + lVar15) = 0;
          *(undefined2 *)(&stack0x00002712 + lVar15) = 0;
          *(undefined2 *)(&stack0x0000272a + lVar15) = 0;
          *(undefined2 *)(&stack0x0000272c + lVar15) = 0;
          *(undefined2 *)(&stack0x0000272e + lVar15) = 0;
          *(undefined2 *)(&stack0x00002730 + lVar15) = 0;
          *(undefined2 *)(&stack0x00002732 + lVar15) = 0;
          *(undefined2 *)(&stack0x00002734 + lVar15) = 0;
          *(undefined2 *)(&stack0x00002736 + lVar15) = 0;
          *(undefined8 *)(&stack0x00002720 + lVar15) = 0;
          *(undefined4 *)(&stack0x00002740 + lVar15) = 0;
          *(undefined8 *)(&stack0x00002738 + lVar15) = 0;
          *(byte **)(&stack0x00002718 + lVar15) = pbVar36;
          *(undefined4 *)(&stack0x00002714 + lVar15) = 1;
          *(undefined4 *)(&stack0x00002740 + lVar15) = 0;
        }
        break;
      case 8:
        *(byte **)(&stack0x00001b00 + lVar15) = pbVar36;
        *(undefined8 *)(&stack0x00002718 + lVar15) = 0;
        *(undefined4 *)(&stack0x00002714 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002728 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002712 + lVar15) = 0;
        *(undefined2 *)(&stack0x0000272a + lVar15) = 0;
        *(undefined2 *)(&stack0x0000272c + lVar15) = 0;
        *(undefined2 *)(&stack0x0000272e + lVar15) = 0;
        *(undefined2 *)(&stack0x00002730 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002732 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002734 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002736 + lVar15) = 0;
        *(undefined8 *)(&stack0x00002720 + lVar15) = 0;
        *(undefined4 *)(&stack0x00002740 + lVar15) = 0;
        *(undefined8 *)(&stack0x00002738 + lVar15) = 0;
        *(byte **)(&stack0x00002718 + lVar15) = pbVar36;
        *(undefined4 *)(&stack0x00002714 + lVar15) = 9;
        *(undefined4 *)(&stack0x00002740 + lVar15) = 0;
      }
      *(longlong *)(&stack0x00002738 + lVar15) = lVar25 + 0x2000;
      *(byte ***)(&stack0x00002720 + lVar15) = ppbVar38;
    }
    *(undefined **)(&stack0x000026a8 + lVar15) = &stack0x00002710 + lVar15;
    lVar25 = *(longlong *)(&stack0x00000448 + lVar15);
    uVar20 = *(undefined8 *)(lVar25 + 0x110);
    *(undefined8 *)(&stack0x00001b18 + lVar15) = uVar20;
    uVar39 = *(undefined4 *)(lVar25 + 0x100);
    *(undefined4 *)(&stack0x00000c60 + lVar15) = uVar39;
    *(undefined4 *)((longlong)auStackX_20 + lVar15) = 0;
    *(undefined4 *)((longlong)&uStackX_18 + lVar15) = 0;
    *(undefined8 *)((longlong)&uStackX_10 + lVar15) = 0;
    *(undefined8 *)((longlong)&uStackX_8 + lVar15) = uVar20;
    *(undefined4 *)((longlong)auStackX_20 + lVar15 + -0x20) = 0;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = uVar39;
    *(undefined **)(&stack0xfffffffffffffff0 + lVar15) = &stack0x000026a8 + lVar15;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 1;
    uVar20 = *(undefined8 *)(&stack0x00000a60 + lVar15);
    plVar17 = *(longlong **)(&stack0x00000a68 + lVar15);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x107af4;
    func_0x(plVar17,uVar20,&stack0x00000188 + lVar15,0);
    uVar8 = *(undefined8 *)(lVar25 + 0x110);
    *(undefined8 *)(&stack0x00001b20 + lVar15) = uVar8;
    uVar39 = *(undefined4 *)(lVar25 + 0x100);
    *(undefined4 *)(&stack0x00000c68 + lVar15) = uVar39;
    *(undefined8 *)(&stack0x00000028 + lVar15) = 0;
    *(undefined4 *)((longlong)auStackX_20 + lVar15) = 0;
    *(undefined8 *)((longlong)&uStackX_18 + lVar15) = 0;
    *(undefined4 *)((longlong)&uStackX_10 + lVar15) = 0;
    *(undefined8 *)((longlong)&uStackX_8 + lVar15) = 0;
    *(undefined8 *)((longlong)auStackX_20 + lVar15 + -0x20) = uVar8;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = 0;
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar15) = uVar39;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 1;
    plVar29 = *(longlong **)(&stack0x00000a70 + lVar15);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x107b5d;
    func_0x
              (plVar29,uVar20,&stack0x00000188 + lVar15,*(undefined4 *)(&stack0x00000338 + lVar15));
    *(undefined4 *)(&stack0x000007b8 + lVar15) = 0;
    *(undefined2 *)(&stack0x000007bc + lVar15) = 0;
    uVar8 = *(undefined8 *)*plVar17;
    *(undefined8 *)(&stack0x00001b28 + lVar15) = uVar8;
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar15) = 0xa58;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar15) = &stack0x000028e8 + lVar15;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x107ba7;
    func_0x(lVar25,uVar8,&stack0x000007b8 + lVar15,&stack0x00000f38 + lVar15);
    *(undefined **)(&stack0x000026d0 + lVar15) = &stack0x00000f38 + lVar15;
    uVar8 = *(undefined8 *)(lVar25 + 0x110);
    *(undefined8 *)(&stack0x00001b30 + lVar15) = uVar8;
    uVar39 = *(undefined4 *)(lVar25 + 0x100);
    *(undefined4 *)(&stack0x00000338 + lVar15) = uVar39;
    *(undefined8 *)(&stack0x00000028 + lVar15) = 0;
    *(undefined4 *)((longlong)auStackX_20 + lVar15) = 0;
    *(undefined8 *)((longlong)&uStackX_18 + lVar15) = 0;
    *(undefined4 *)((longlong)&uStackX_10 + lVar15) = 0;
    *(undefined8 *)((longlong)&uStackX_8 + lVar15) = 0;
    *(undefined8 *)((longlong)auStackX_20 + lVar15 + -0x20) = uVar8;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = 0;
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar15) = uVar39;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 1;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x107c1d;
    func_0x
              (*(undefined8 *)(&stack0x00000920 + lVar15),uVar20,&stack0x00000188 + lVar15,
               *(undefined4 *)(&stack0x00000454 + lVar15));
    uVar8 = *(undefined8 *)(lVar25 + 0x110);
    *(undefined8 *)(&stack0x00001b38 + lVar15) = uVar8;
    uVar39 = *(undefined4 *)(lVar25 + 0x100);
    *(undefined4 *)(&stack0x00000c70 + lVar15) = uVar39;
    *(undefined4 *)((longlong)auStackX_20 + lVar15) = 0;
    *(undefined4 *)((longlong)&uStackX_18 + lVar15) = 0;
    *(undefined8 *)((longlong)&uStackX_10 + lVar15) = 0;
    *(undefined8 *)((longlong)&uStackX_8 + lVar15) = uVar8;
    *(undefined4 *)((longlong)auStackX_20 + lVar15 + -0x20) = 0;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = uVar39;
    *(undefined **)(&stack0xfffffffffffffff0 + lVar15) = &stack0x000026d0 + lVar15;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 1;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x107c88;
    func_0x
              (*(undefined8 *)(&stack0x00000920 + lVar15),uVar20,&stack0x00000188 + lVar15,
               *(undefined4 *)(&stack0x00000454 + lVar15));
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x107c95;
    func_0x(&stack0x00000ef8 + lVar15);
    if (*(longlong *)(&stack0x00000058 + lVar15) != 0) {
      puVar18 = (undefined2 *)(*(longlong *)(&stack0x00000058 + lVar15) + 0x62);
      *(undefined2 **)(&stack0x00001b40 + lVar15) = puVar18;
      *(undefined2 *)(&stack0x00000348 + lVar15) = *puVar18;
      if (((*(ushort *)(&stack0x00000348 + lVar15) & 0x400) == 0) ||
         (*(short *)(&stack0x00000064 + lVar15) < 3)) {
        *(int *)(&stack0x00000120 + lVar15) = (int)*(short *)(&stack0x00000064 + lVar15);
        *(undefined8 *)(&stack0x00001b48 + lVar15) = *(undefined8 *)(&stack0x00000058 + lVar15);
        *(undefined2 **)(&stack0x00001b50 + lVar15) = puVar18;
        uVar12 = *puVar18;
        *(undefined2 *)(&stack0x000002d0 + lVar15) = uVar12;
        if (((byte)uVar12 >> 3 & 1) != 0) {
          if (*(int *)(&stack0x00000120 + lVar15) == 3) {
            *(undefined4 *)(&stack0x00000120 + lVar15) = 4;
          }
          else if (*(int *)(&stack0x00000120 + lVar15) < 2) goto code_r0x00107e3c;
          *(uint **)(&stack0x00001b58 + lVar15) =
               (uint *)(*(longlong *)(&stack0x00000058 + lVar15) + 100);
          uVar24 = *(uint *)(*(longlong *)(&stack0x00000058 + lVar15) + 100);
          *(uint *)(&stack0x000006e8 + lVar15) = uVar24;
          if ((((uVar24 & 8) != 0) &&
              (lVar26 = *(longlong *)(*(longlong *)(&stack0x00000058 + lVar15) + 0x90), lVar26 != 0)
              ) && (*(longlong *)(&stack0x00001b60 + lVar15) = lVar26,
                   *(longlong *)(lVar26 + 0x758) != 0)) {
            uVar20 = *(undefined8 *)(lVar26 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x107e3c;
            func_0x
                      (uVar20,*(undefined8 *)(&stack0x00000058 + lVar15),
                       *(undefined4 *)(&stack0x00000120 + lVar15));
          }
        }
code_r0x00107e3c:
        (&stack0x0000019e)[lVar15] = DAT_ >> 7;
        if ((char)DAT_ < '\0') {
          puVar33 = (uint *)(*(longlong *)(&stack0x00000058 + lVar15) + 100);
          *(uint **)(&stack0x00001b68 + lVar15) = puVar33;
          uVar24 = *puVar33;
          *(uint *)(&stack0x000006f0 + lVar15) = uVar24;
          if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x00000120 + lVar15))) {
            *(uint **)(&stack0x00001b70 + lVar15) = puVar33;
            uVar24 = *puVar33;
            *(uint *)(&stack0x000006f8 + lVar15) = uVar24;
            if (((uVar24 & 0xc0000000) != 0x40000000) &&
               (lVar26 = **(longlong **)(&stack0x00000058 + lVar15), lVar26 != 0)) {
              *(undefined4 *)(&stack0x00000c78 + lVar15) = 2;
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x107ecf;
              iVar13 = (*_DAT_)(lVar26,0x2000,2,&stack0x00000c7c + lVar15);
              if (iVar13 != 0) {
                LOCK();
                *puVar33 = *puVar33 & 0x3fffffff;
                UNLOCK();
                LOCK();
                *puVar33 = *puVar33 | 0x40000000;
                UNLOCK();
              }
            }
          }
        }
        lVar26 = *(longlong *)(&stack0x00000058 + lVar15);
        uVar39 = *(undefined4 *)(&stack0x00000120 + lVar15);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x107efe;
        func_0x(lVar26 + 0x98,uVar39);
        if ((_DAT_ != 0) &&
           ((&stack0x0000019f)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x107f29;
          func_0x(lVar26,0,uVar39);
        }
        *(uint *)(&stack0x00000064 + lVar15) = *(uint *)(&stack0x00000064 + lVar15) & 0xffff0000;
        *(undefined8 *)(&stack0x00000058 + lVar15) = 0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x107ceb;
        func_0x(&stack0x00000058 + lVar15);
      }
    }
    *(longlong *)(&stack0x00000058 + lVar15) = *plVar17;
    *(uint *)(&stack0x00000064 + lVar15) =
         *(uint *)(&stack0x00000064 + lVar15) & 0xffff0000 |
         (uint)*(ushort *)((longlong)plVar17 + 0xc);
    *plVar17 = 0;
    *(uint *)((longlong)plVar17 + 0xc) = *(uint *)((longlong)plVar17 + 0xc) & 0xffff0000;
    goto code_r0x00107d1c;
  }
  *(undefined4 *)(&stack0x00000a8c + lVar15) = 0;
  *(undefined2 *)(&stack0x00000a90 + lVar15) = 0;
  lVar25 = **param_2;
  *(longlong *)(&stack0x000014e0 + lVar15) = lVar25;
  piVar30 = (int *)(lVar25 + 0x10);
  *(int **)(&stack0x000014e8 + lVar15) = piVar30;
  iVar13 = *piVar30;
  *(int *)(&stack0x00000a92 + lVar15) = iVar13;
  sVar11 = *(short *)(lVar25 + 0x14);
  *(short *)(&stack0x00000a96 + lVar15) = sVar11;
  if ((iVar13 != 0) || (sVar11 != 0)) {
    *(longlong *)(&stack0x000014f0 + lVar15) = lVar25;
    *(int **)(&stack0x000014f8 + lVar15) = piVar30;
    *(int *)(&stack0x00000178 + lVar15) = iVar13;
    *(undefined2 *)(&stack0x0000017c + lVar15) = *(undefined2 *)(lVar25 + 0x14);
    plVar29 = *(longlong **)(*(longlong *)(&stack0x00000448 + lVar15) + 8);
    *(longlong **)(&stack0x00000a78 + lVar15) = plVar29;
    *(undefined8 *)(&stack0x00000900 + lVar15) =
         *(undefined8 *)(*(longlong *)(&stack0x00000448 + lVar15) + 0x10);
    *(undefined4 *)(&stack0x00000618 + lVar15) = 0;
    *(undefined4 *)(&stack0x0000061c + lVar15) = 0;
    *(undefined2 *)(&stack0x00000620 + lVar15) = 0;
    lVar25 = *plVar29;
    *(longlong *)(&stack0x00000d78 + lVar15) = lVar25;
    *(undefined4 *)(&stack0x00000ecc + lVar15) = 0;
    *(undefined4 *)(&stack0x00000ed0 + lVar15) = 0;
    lVar26 = *(longlong *)(lVar25 + 0x20);
    *(longlong *)(&stack0x00000078 + lVar15) = lVar26;
    *(uint6 **)(&stack0x00001500 + lVar15) = (uint6 *)(lVar25 + 0x14);
    lVar25 = (ulonglong)*(uint6 *)(lVar25 + 0x14) * 0x10000;
    *(longlong *)(&stack0x00001508 + lVar15) = lVar25;
    if ((*(longlong *)(lVar26 + 2000) == lVar25) &&
       (*(longlong *)(lVar26 + 2000) - 1U < 0xfffffffffffffffe)) {
      (&stack0x000000a5)[lVar15] = 1;
    }
    else {
      (&stack0x000000a5)[lVar15] = 0;
      if ((*(longlong *)(lVar26 + 0x7d8) == lVar25) &&
         (*(longlong *)(lVar26 + 0x7d8) - 1U < 0xfffffffffffffffe)) {
        (&stack0x000000a6)[lVar15] = 1;
      }
      else {
        (&stack0x000000a6)[lVar15] = 0;
        lVar25 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00001510 + lVar15) = lVar25;
        lVar26 = (ulonglong)*_DAT_ + *(longlong *)(lVar25 + (ulonglong)*_DAT_ * 8);
        *(longlong *)(&stack0x00001518 + lVar15) = lVar26;
        lVar25 = *(longlong *)(lVar26 + 0x100);
        *(longlong *)(&stack0x00000d38 + lVar15) = lVar25;
        puVar33 = _DAT_;
        if (lVar25 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1040b4;
          puVar33 = (uint *)(*_DAT_)();
          lVar25 = *(longlong *)(lVar26 + 0x100);
          *(longlong *)(&stack0x00000d38 + lVar15) = lVar25;
        }
        *(longlong *)(&stack0x00001520 + lVar15) = lVar25;
        uVar21 = rdtsc();
        uVar19 = CONCAT44((int)((ulonglong)puVar33 >> 0x20),(int)uVar21) |
                 uVar21 & 0xffffffff00000000;
        *(ulonglong *)(&stack0x00001528 + lVar15) = uVar19;
        uVar21 = *(ulonglong *)(lVar25 + 0x340);
        if ((uVar21 < uVar19) ||
           ((uVar21 != 0x7fffffffffffffff &&
            (*(ulonglong *)(*(longlong *)(lVar25 + 0x260) + 0xdf0) < uVar21 - uVar19)))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104181;
          iVar13 = func_0x(0,0x20c1cc8);
          *(int *)(&stack0x00000488 + lVar15) = iVar13;
          if (iVar13 == 2) {
LAB_:
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104194;
            func_0x(0x7c);
          }
        }
        else {
          lVar25 = *(longlong *)(lVar25 + 600);
          *(longlong *)(&stack0x00000d40 + lVar15) = lVar25;
          puVar33 = (uint *)(lVar25 + 0xbc);
          *(uint **)(&stack0x00001530 + lVar15) = puVar33;
          if ((*puVar33 & 4) != 0) {
            lVar25 = *(longlong *)(*(longlong *)(&stack0x00000d40 + lVar15) + 0x98);
            *(longlong *)(&stack0x00001538 + lVar15) = lVar25;
            if (((*(byte *)(lVar25 + 0x268) & 1) == 0) && ((*(uint *)(lVar25 + 800) & 0x180) == 0))
            {
              *(undefined4 *)(&stack0x00000488 + lVar15) = 2;
              goto LAB_;
            }
          }
          *(undefined4 *)(&stack0x00000488 + lVar15) = 0;
        }
        lVar26 = *(longlong *)(&stack0x00000078 + lVar15);
      }
    }
    *(undefined4 *)(&stack0x00000b40 + lVar15) = 0;
    *(undefined4 *)(&stack0x00000b44 + lVar15) = 0;
    *(undefined2 *)(&stack0x00000b48 + lVar15) = 0;
    (&stack0x00000094)[lVar15] = 0;
    (&stack0x00000052)[lVar15] = 0xff;
    do {
      uVar20 = 0;
      *(undefined **)(&stack0x00000a28 + lVar15) = &stack0x00000ec8 + lVar15;
      *(undefined4 *)(&stack0x0000266c + lVar15) = 0;
      *(undefined4 *)(&stack0x00002670 + lVar15) = 0;
      cVar9 = *_DAT_;
      (&stack0x00000369)[lVar15] = cVar9;
      if ((cVar9 != '\0') &&
         ((&stack0x0000036a)[lVar15] = DAT_ >> 7, -1 < (char)DAT_)) {
        *(undefined4 *)(&stack0x000009b8 + lVar15) = 0;
        lVar25 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00001540 + lVar15) = lVar25;
        plVar29 = (longlong *)
                  ((ulonglong)*_DAT_ + *(longlong *)(lVar25 + (ulonglong)*_DAT_ * 8)
                  );
        *(longlong **)(&stack0x00001548 + lVar15) = plVar29;
        lVar25 = *plVar29;
        *(longlong *)(&stack0x00001550 + lVar15) = lVar25;
        if (lVar25 == 0) {
LAB_:
          *(undefined8 *)(&stack0x00000d48 + lVar15) = 0;
        }
        else {
          lVar25 = **(longlong **)(lVar25 + 0x38);
          *(longlong *)(&stack0x00001558 + lVar15) = lVar25;
          if (lVar25 == 0) goto LAB_;
          *(longlong *)(&stack0x00000d48 + lVar15) = lVar25;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104295;
          iVar13 = (*_DAT_)(lVar25,0x337);
          *(int *)(&stack0x000009b8 + lVar15) = iVar13;
          if (iVar13 != 0) {
            lVar26 = *(longlong *)(&stack0x00000078 + lVar15);
            goto LAB_;
          }
        }
        lVar25 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00001560 + lVar15) = lVar25;
        lVar25 = (ulonglong)*_DAT_ + *(longlong *)(lVar25 + (ulonglong)*_DAT_ * 8);
        *(longlong *)(&stack0x00001568 + lVar15) = lVar25;
        lVar25 = *(longlong *)(lVar25 + 8);
        *(longlong *)(&stack0x00001570 + lVar15) = lVar25;
        lVar26 = *(longlong *)(&stack0x00000078 + lVar15);
        if (lVar25 != 0) {
          uVar20 = *(undefined8 *)(lVar25 + 0x60);
        }
      }
LAB_:
      *(undefined8 *)(&stack0x000004b8 + lVar15) = uVar20;
      plVar29 = (longlong *)(lVar26 + 0x728);
      *(longlong *)(&stack0x00000d50 + lVar15) = *plVar29;
LAB_:
      *(undefined4 *)(&stack0x0000048c + lVar15) = 0;
      if (*(longlong *)(&stack0x00000038 + lVar15) != 0) {
        puVar18 = (undefined2 *)(*(longlong *)(&stack0x00000038 + lVar15) + 0x62);
        *(undefined2 **)(&stack0x00001578 + lVar15) = puVar18;
        *(undefined2 *)(&stack0x00000258 + lVar15) = *puVar18;
        if (((*(ushort *)(&stack0x00000258 + lVar15) & 0x400) == 0) ||
           (*(short *)(&stack0x00000044 + lVar15) < 3)) {
          *(int *)(&stack0x000000e8 + lVar15) = (int)*(short *)(&stack0x00000044 + lVar15);
          *(undefined8 *)(&stack0x000008e0 + lVar15) = *(undefined8 *)(&stack0x00000038 + lVar15);
          *(undefined2 **)(&stack0x00001580 + lVar15) = puVar18;
          uVar12 = *puVar18;
          *(undefined2 *)(&stack0x00000260 + lVar15) = uVar12;
          if (((byte)uVar12 >> 3 & 1) != 0) {
            if (*(int *)(&stack0x000000e8 + lVar15) == 3) {
              *(undefined4 *)(&stack0x000000e8 + lVar15) = 4;
            }
            else if (*(int *)(&stack0x000000e8 + lVar15) < 2) goto LAB_;
            *(uint **)(&stack0x00001588 + lVar15) =
                 (uint *)(*(longlong *)(&stack0x00000038 + lVar15) + 100);
            uVar24 = *(uint *)(*(longlong *)(&stack0x00000038 + lVar15) + 100);
            *(uint *)(&stack0x000009c0 + lVar15) = uVar24;
            if ((((uVar24 & 8) != 0) &&
                (lVar25 = *(longlong *)(*(longlong *)(&stack0x00000038 + lVar15) + 0x90),
                lVar25 != 0)) &&
               (*(longlong *)(&stack0x00001590 + lVar15) = lVar25,
               *(longlong *)(lVar25 + 0x758) != 0)) {
              uVar20 = *(undefined8 *)(lVar25 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10442b;
              func_0x
                        (uVar20,*(undefined8 *)(&stack0x00000038 + lVar15),
                         *(undefined4 *)(&stack0x000000e8 + lVar15));
            }
          }
LAB_:
          (&stack0x0000036b)[lVar15] = DAT_ >> 7;
          if ((char)DAT_ < '\0') {
            puVar33 = (uint *)(*(longlong *)(&stack0x000008e0 + lVar15) + 100);
            *(uint **)(&stack0x00001598 + lVar15) = puVar33;
            uVar24 = *puVar33;
            *(uint *)(&stack0x000009c8 + lVar15) = uVar24;
            if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x000000e8 + lVar15))) {
              *(uint **)(&stack0x000015a0 + lVar15) = puVar33;
              uVar24 = *puVar33;
              *(uint *)(&stack0x000009d0 + lVar15) = uVar24;
              if (((uVar24 & 0xc0000000) != 0x40000000) &&
                 (lVar25 = **(longlong **)(&stack0x000008e0 + lVar15), lVar25 != 0)) {
                *(undefined4 *)(&stack0x00000bc8 + lVar15) = 2;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1044be;
                iVar13 = (*_DAT_)(lVar25,0x2000,2,&stack0x00000bcc + lVar15);
                if (iVar13 != 0) {
                  LOCK();
                  *puVar33 = *puVar33 & 0x3fffffff;
                  UNLOCK();
                  LOCK();
                  *puVar33 = *puVar33 | 0x40000000;
                  UNLOCK();
                }
              }
            }
          }
          lVar25 = *(longlong *)(&stack0x000008e0 + lVar15);
          uVar39 = *(undefined4 *)(&stack0x000000e8 + lVar15);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1044ed;
          func_0x(lVar25 + 0x98,uVar39);
          if ((_DAT_ != 0) &&
             ((&stack0x00000390)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104517;
            func_0x(lVar25,0,uVar39);
          }
          *(uint *)(&stack0x00000044 + lVar15) = *(uint *)(&stack0x00000044 + lVar15) & 0xffff0000;
          *(undefined8 *)(&stack0x00000038 + lVar15) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10431c;
          func_0x(&stack0x00000038 + lVar15);
        }
        lVar26 = *(longlong *)(&stack0x00000078 + lVar15);
      }
      if (*plVar29 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10454d;
        func_0x(&stack0x00000038 + lVar15,&stack0x00000178 + lVar15,lVar26);
        if (*(longlong *)(&stack0x00000038 + lVar15) != 0) {
          puVar18 = (undefined2 *)(*(longlong *)(&stack0x00000038 + lVar15) + 0x62);
          *(undefined2 **)(&stack0x000015a8 + lVar15) = puVar18;
          *(undefined2 *)(&stack0x00000268 + lVar15) = *puVar18;
          if (((*(ushort *)(&stack0x00000268 + lVar15) & 0x400) == 0) ||
             (*(short *)(&stack0x00000044 + lVar15) < 3)) {
            *(int *)(&stack0x000000f0 + lVar15) = (int)*(short *)(&stack0x00000044 + lVar15);
            *(undefined8 *)(&stack0x000008e8 + lVar15) = *(undefined8 *)(&stack0x00000038 + lVar15);
            *(undefined2 **)(&stack0x000015b0 + lVar15) = puVar18;
            uVar12 = *puVar18;
            *(undefined2 *)(&stack0x00000270 + lVar15) = uVar12;
            if (((byte)uVar12 >> 3 & 1) != 0) {
              if (*(int *)(&stack0x000000f0 + lVar15) == 3) {
                *(undefined4 *)(&stack0x000000f0 + lVar15) = 4;
              }
              else if (*(int *)(&stack0x000000f0 + lVar15) < 2) goto LAB_;
              *(uint **)(&stack0x000015b8 + lVar15) =
                   (uint *)(*(longlong *)(&stack0x00000038 + lVar15) + 100);
              uVar24 = *(uint *)(*(longlong *)(&stack0x00000038 + lVar15) + 100);
              *(uint *)(&stack0x000009d8 + lVar15) = uVar24;
              if ((((uVar24 & 8) != 0) &&
                  (lVar25 = *(longlong *)(*(longlong *)(&stack0x00000038 + lVar15) + 0x90),
                  lVar25 != 0)) &&
                 (*(longlong *)(&stack0x000015c0 + lVar15) = lVar25,
                 *(longlong *)(lVar25 + 0x758) != 0)) {
                uVar20 = *(undefined8 *)(lVar25 + 0x758);
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104644;
                func_0x
                          (uVar20,*(undefined8 *)(&stack0x00000038 + lVar15),
                           *(undefined4 *)(&stack0x000000f0 + lVar15));
              }
            }
LAB_:
            (&stack0x00000190)[lVar15] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
              puVar33 = (uint *)(*(longlong *)(&stack0x000008e8 + lVar15) + 100);
              *(uint **)(&stack0x000015c8 + lVar15) = puVar33;
              uVar24 = *puVar33;
              *(uint *)(&stack0x000009e0 + lVar15) = uVar24;
              if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x000000f0 + lVar15))) {
                *(uint **)(&stack0x000015d0 + lVar15) = puVar33;
                uVar24 = *puVar33;
                *(uint *)(&stack0x000009e8 + lVar15) = uVar24;
                if (((uVar24 & 0xc0000000) != 0x40000000) &&
                   (lVar25 = **(longlong **)(&stack0x000008e8 + lVar15), lVar25 != 0)) {
                  *(undefined4 *)(&stack0x00000bd0 + lVar15) = 2;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1046d7;
                  iVar13 = (*_DAT_)(lVar25,0x2000,2,&stack0x00000bd4 + lVar15);
                  if (iVar13 != 0) {
                    LOCK();
                    *puVar33 = *puVar33 & 0x3fffffff;
                    UNLOCK();
                    LOCK();
                    *puVar33 = *puVar33 | 0x40000000;
                    UNLOCK();
                  }
                }
              }
            }
            lVar25 = *(longlong *)(&stack0x000008e8 + lVar15);
            uVar39 = *(undefined4 *)(&stack0x000000f0 + lVar15);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104706;
            func_0x(lVar25 + 0x98,uVar39);
            if ((_DAT_ != 0) &&
               ((&stack0x00000191)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104730;
              func_0x(lVar25,0,uVar39);
            }
            *(uint *)(&stack0x00000044 + lVar15) = *(uint *)(&stack0x00000044 + lVar15) & 0xffff0000
            ;
            *(undefined8 *)(&stack0x00000038 + lVar15) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104592;
            func_0x(&stack0x00000038 + lVar15);
          }
          lVar26 = *(longlong *)(&stack0x00000078 + lVar15);
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104757;
      func_0x(lVar26,&stack0x00000178 + lVar15);
      *(undefined8 *)(&stack0xfffffffffffffff0 + lVar15) =
           *(undefined8 *)(&stack0x00000a28 + lVar15);
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 4;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10478b;
      plVar17 = (longlong *)func_0x(_DAT_,lVar26,&stack0x00000178 + lVar15);
      *(longlong **)(&stack0x00000038 + lVar15) = plVar17;
      uVar24 = *(uint *)(&stack0x00000044 + lVar15) & 0xffff0004 | 4;
      *(uint *)(&stack0x00000044 + lVar15) = uVar24;
      if (*(longlong *)(&stack0x000004b8 + lVar15) != 0) {
        lVar25 = *plVar17;
        *(longlong *)(&stack0x000015d8 + lVar15) = lVar25;
        plVar35 = (longlong *)(*(longlong *)(&stack0x000004b8 + lVar15) + 0x500);
        *(longlong **)(&stack0x000015e0 + lVar15) = plVar35;
        plVar17 = plVar35 + (ulonglong)(*(uint *)plVar35 & 0xf) + 1;
        *(longlong **)(&stack0x000015e8 + lVar15) = plVar17;
        if (*plVar17 != lVar25) {
          *plVar17 = lVar25;
          *plVar35 = *plVar35 + 1;
          uVar24 = *(uint *)(&stack0x00000044 + lVar15);
        }
      }
      uVar28 = *(uint *)(&stack0x0000048c + lVar15) >> 3 & 1;
      *(uint *)(&stack0x00000044 + lVar15) = uVar28 << 0x18 | uVar24 & 0xffffff;
      *(uint *)(&stack0x00000048 + lVar15) =
           *(uint *)(&stack0x0000048c + lVar15) >> 4 & 1 |
           *(uint *)(&stack0x00000048 + lVar15) & 0xffffff00;
      lVar25 = *(longlong *)(&stack0x00000d50 + lVar15);
      if (((lVar25 != 0) && (*(longlong *)(&stack0x000004b8 + lVar15) != 0)) &&
         (*(longlong *)(&stack0x000004b8 + lVar15) == *(longlong *)(lVar26 + 0x1c38))) {
        *(uint *)(&stack0x00000bd8 + lVar15) = uVar28;
        *(longlong *)(&stack0x000015f0 + lVar15) = lVar25 + 0x59b8;
        *(longlong *)(lVar25 + 0x5b28) = *(longlong *)(lVar25 + 0x5b28) + 1;
        puVar33 = *(uint **)(&stack0x00000a28 + lVar15);
        if (puVar33[1] != 0) {
          *(longlong *)(lVar25 + 0x5b30) = *(longlong *)(lVar25 + 0x5b30) + 1;
          *(longlong *)(lVar25 + 0x5b38) = *(longlong *)(lVar25 + 0x5b38) + (ulonglong)*puVar33;
          if (uVar28 != 0) {
            *(longlong *)(lVar25 + 0x5b40) = *(longlong *)(lVar25 + 0x5b40) + 1;
            *(longlong *)(lVar25 + 0x5b48) = *(longlong *)(lVar25 + 0x5b48) + (ulonglong)*puVar33;
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1048ad;
      cVar9 = func_0x(lVar26);
      if ((cVar9 == '\0') || (*(char *)(lVar26 + 0x2050) == '\0')) goto LAB_;
      if (*(int *)(&stack0x00000178 + lVar15) != 0) {
        *(undefined4 *)(&stack0x00000aa4 + lVar15) = 9;
        *(undefined2 *)(&stack0x00000aa8 + lVar15) = 1;
        if ((*(int *)(&stack0x00000178 + lVar15) == 9) &&
           (*(short *)(&stack0x0000017c + lVar15) == 1)) goto LAB_;
        (&stack0x00000096)[lVar15] = 0;
        lVar25 = **(longlong **)(&stack0x00000038 + lVar15);
        *(longlong *)(&stack0x000015f8 + lVar15) = lVar25;
        (&stack0x00000092)[lVar15] = 0;
        if (*(short *)(lVar25 + 0x24) == 0) {
LAB_:
          *(undefined8 *)(&stack0x000004f8 + lVar15) = *(undefined8 *)(lVar25 + 0x28);
          *(undefined2 *)(&stack0x00000500 + lVar15) = *(undefined2 *)(lVar25 + 0x30);
        }
        else {
          cVar9 = *(char *)(lVar25 + 1);
          if ((((cVar9 == '\v') || (cVar9 == '\b')) || (cVar9 == '\t')) &&
             (*(int *)(lVar25 + 0x18) == 99)) {
            *(undefined **)(&stack0x00001600 + lVar15) = &stack0x00000590 + lVar15;
            *(undefined4 **)(&stack0x00001608 + lVar15) = (undefined4 *)(lVar25 + 0x20);
            *(undefined4 *)(&stack0x00000590 + lVar15) = *(undefined4 *)(lVar25 + 0x20);
            *(undefined2 *)(&stack0x00000594 + lVar15) = *(undefined2 *)(lVar25 + 0x24);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104975;
            cVar9 = func_0x(&stack0x00000590 + lVar15);
            if (cVar9 == '\0') goto LAB_;
            cVar9 = '\x01';
          }
          else {
LAB_:
            cVar9 = '\0';
          }
          (&stack0x00000092)[lVar15] = cVar9;
          if (cVar9 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10499a;
          func_0x(lVar25,&stack0x000004f8 + lVar15);
        }
        *(undefined **)(&stack0x00001610 + lVar15) = &stack0x000004f8 + lVar15;
        *(longlong *)(&stack0x00000d58 + lVar15) = lVar26 + 0x20fc;
        *(undefined4 *)(&stack0x00000470 + lVar15) = 0;
        *(undefined4 *)(&stack0x00000474 + lVar15) = 0;
        *(undefined2 *)(&stack0x00000478 + lVar15) = 0;
        *(undefined2 *)(&stack0x0000047a + lVar15) = 0;
        puVar33 = (uint *)(lVar26 + 0x2108);
        *(uint **)(&stack0x00001618 + lVar15) = puVar33;
        uVar24 = *puVar33;
        *(uint *)(&stack0x00000490 + lVar15) = uVar24;
        *(uint **)(&stack0x00000d60 + lVar15) = puVar33;
        do {
          *(uint *)(&stack0x0000064c + lVar15) = uVar24 & 0xfffffffe;
          *(undefined8 *)(&stack0x00000470 + lVar15) = **(undefined8 **)(&stack0x00000d58 + lVar15);
          *(undefined4 *)(&stack0x00000478 + lVar15) =
               *(undefined4 *)(*(undefined8 **)(&stack0x00000d58 + lVar15) + 1);
          LOCK();
          *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15) =
               *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15);
          UNLOCK();
          uVar24 = **(uint **)(&stack0x00000d60 + lVar15);
          *(uint *)(&stack0x00000490 + lVar15) = uVar24;
        } while (*(uint *)(&stack0x0000064c + lVar15) != uVar24);
        if ((*(uint *)(&stack0x000004f8 + lVar15) <= *(uint *)(&stack0x00000470 + lVar15)) &&
           ((*(uint *)(&stack0x00000470 + lVar15) != *(uint *)(&stack0x000004f8 + lVar15) ||
            ((uVar24 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000470 + lVar15) >> 0x20),
             *(uint *)(&stack0x000004fc + lVar15) <= uVar24 &&
             ((uVar24 != *(uint *)(&stack0x000004fc + lVar15) ||
              (*(ushort *)(&stack0x00000500 + lVar15) <= *(ushort *)(&stack0x00000478 + lVar15))))))
            ))) goto LAB_;
        if (*(char *)(*(longlong *)(&stack0x00000078 + lVar15) + 0x6ac8) == '\0') {
          lVar25 = *(longlong *)(unaff_GS_OFFSET + 0x58);
          *(longlong *)(&stack0x00001620 + lVar15) = lVar25;
          lVar25 = (ulonglong)*_DAT_ + *(longlong *)(lVar25 + (ulonglong)*_DAT_ * 8)
          ;
          *(longlong *)(&stack0x00001628 + lVar15) = lVar25;
          lVar25 = *(longlong *)(lVar25 + 8);
          *(longlong *)(&stack0x00001630 + lVar15) = lVar25;
          lVar25 = *(longlong *)(lVar25 + 0x60);
          *(longlong *)(&stack0x00001638 + lVar15) = lVar25;
          if (lVar25 != *(longlong *)(*(longlong *)(&stack0x00000078 + lVar15) + 0x2120)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104b2a;
            cVar9 = func_0x(*(longlong *)(&stack0x00000078 + lVar15));
            if (cVar9 == '\0') {
              *(longlong *)(&stack0x00000a30 + lVar15) = lVar26 + 0x20fc;
              iVar13 = 0;
              *(undefined4 *)(&stack0x00000418 + lVar15) = 0;
              *(undefined4 *)(&stack0x0000041c + lVar15) = 0;
              *(undefined2 *)(&stack0x00000420 + lVar15) = 0;
              *(undefined2 *)(&stack0x00000422 + lVar15) = 0;
              *(uint **)(&stack0x00001640 + lVar15) = puVar33;
              uVar24 = *puVar33;
              *(uint *)(&stack0x00000494 + lVar15) = uVar24;
              puVar31 = *(undefined8 **)(&stack0x00000a30 + lVar15);
              *(longlong *)(&stack0x00000d68 + lVar15) = (longlong)puVar31 + 0xc;
              while( true ) {
                *(uint *)(&stack0x00000650 + lVar15) = uVar24 & 0xfffffffe;
                *(undefined8 *)(&stack0x00000418 + lVar15) = *puVar31;
                *(undefined4 *)(&stack0x00000420 + lVar15) = *(undefined4 *)(puVar31 + 1);
                LOCK();
                *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15) =
                     *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15);
                UNLOCK();
                uVar24 = **(uint **)(&stack0x00000d68 + lVar15);
                *(uint *)(&stack0x00000494 + lVar15) = uVar24;
                if (*(uint *)(&stack0x00000650 + lVar15) == uVar24) break;
                puVar31 = *(undefined8 **)(&stack0x00000a30 + lVar15);
              }
              *(undefined8 *)(&stack0x00000b50 + lVar15) =
                   *(undefined8 *)(&stack0x00000418 + lVar15);
              uVar23 = *(ushort *)(&stack0x00000420 + lVar15);
              *(ushort *)(&stack0x00000b58 + lVar15) = uVar23;
              lVar25 = **(longlong **)(&stack0x00000038 + lVar15);
              *(longlong *)(&stack0x00001648 + lVar15) = lVar25;
              (&stack0x00000093)[lVar15] = 0;
              if (*(short *)(lVar25 + 0x24) == 0) {
LAB_:
                *(undefined8 *)(&stack0x000004e8 + lVar15) = *(undefined8 *)(lVar25 + 0x28);
                uVar37 = *(ushort *)(lVar25 + 0x30);
                *(ushort *)(&stack0x000004f0 + lVar15) = uVar37;
              }
              else {
                cVar9 = *(char *)(lVar25 + 1);
                if ((((cVar9 == '\v') || (cVar9 == '\b')) || (cVar9 == '\t')) &&
                   (*(int *)(lVar25 + 0x18) == 99)) {
                  *(undefined **)(&stack0x00001650 + lVar15) = &stack0x00000580 + lVar15;
                  *(undefined4 **)(&stack0x00001658 + lVar15) = (undefined4 *)(lVar25 + 0x20);
                  *(undefined4 *)(&stack0x00000580 + lVar15) = *(undefined4 *)(lVar25 + 0x20);
                  *(undefined2 *)(&stack0x00000584 + lVar15) = *(undefined2 *)(lVar25 + 0x24);
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104c65;
                  cVar9 = func_0x(&stack0x00000580 + lVar15);
                  if (cVar9 == '\0') goto LAB_;
                  cVar9 = '\x01';
                }
                else {
LAB_:
                  cVar9 = '\0';
                }
                (&stack0x00000093)[lVar15] = cVar9;
                if (cVar9 == '\0') goto LAB_;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104c8a;
                func_0x(lVar25,&stack0x000004e8 + lVar15);
                uVar37 = *(ushort *)(&stack0x000004f0 + lVar15);
              }
              if ((*(uint *)(&stack0x00000418 + lVar15) < *(uint *)(&stack0x000004e8 + lVar15)) ||
                 ((*(uint *)(&stack0x00000418 + lVar15) == *(uint *)(&stack0x000004e8 + lVar15) &&
                  ((uVar24 = (uint)((ulonglong)*(undefined8 *)(&stack0x000004e8 + lVar15) >> 0x20),
                   *(uint *)(&stack0x0000041c + lVar15) < uVar24 ||
                   ((*(uint *)(&stack0x0000041c + lVar15) == uVar24 && (uVar23 < uVar37)))))))) {
                lVar25 = *(longlong *)(&stack0x00000078 + lVar15);
                lVar26 = *(longlong *)(lVar25 + 0x6b0);
                *(longlong *)(&stack0x00001660 + lVar15) = lVar26;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104d21;
                func_0x(&stack0x000004e8 + lVar15,&stack0x00002880 + lVar15,
                                &stack0x00000654 + lVar15);
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104d3e;
                func_0x(&stack0x00000b50 + lVar15,&stack0x000028b0 + lVar15,
                                &stack0x00000654 + lVar15);
                *(undefined4 *)(&stack0x00000d70 + lVar15) = 0x1d;
                *(undefined4 *)(&stack0x00000d74 + lVar15) = 0x10000;
                if ((_DAT_ & 0x10000) != 0) {
                  *(undefined2 *)(&stack0x00000758 + lVar15) = 6;
                  *(undefined **)(&stack0x00001668 + lVar15) = &stack0x000023a0 + lVar15;
                  *(undefined2 *)(&stack0x000023a0 + lVar15) = 0;
                  *(undefined2 *)(&stack0x000023a2 + lVar15) = 6;
                  *(undefined4 *)(&stack0x000023a8 + lVar15) = 0;
                  *(undefined **)(&stack0x000023b0 + lVar15) = &stack0x000023c8 + lVar15;
                  *(undefined **)(&stack0x000023b8 + lVar15) = &stack0x00002428 + lVar15;
                  *(undefined4 *)(&stack0x000025e8 + lVar15) = 0;
                  *(undefined4 *)(&stack0x000025ec + lVar15) = 0;
                  *(undefined8 *)(&stack0x000023c0 + lVar15) = 0;
                  *(undefined8 *)(&stack0x000025f0 + lVar15) = 0;
                  *(undefined **)(&stack0x00001670 + lVar15) = &stack0x000023c8 + lVar15;
                  *(undefined **)(&stack0x000023c8 + lVar15) = &stack0x000025f8 + lVar15;
                  *(undefined4 *)(&stack0x000023d0 + lVar15) = 0x34;
                  *(undefined2 *)(&stack0x000023d4 + lVar15) = 5;
                  *(undefined2 *)(&stack0x000023d6 + lVar15) = 0;
                  *(undefined **)(&stack0x00001678 + lVar15) = &stack0x000023d8 + lVar15;
                  *(undefined8 *)(&stack0x000023d8 + lVar15) = 0x18b1f28;
                  *(undefined4 *)(&stack0x000023e0 + lVar15) = 0x10;
                  *(undefined2 *)(&stack0x000023e4 + lVar15) = 5;
                  *(undefined2 *)(&stack0x000023e6 + lVar15) = 0;
                  *(undefined **)(&stack0x00001680 + lVar15) = &stack0x000023e8 + lVar15;
                  *(undefined8 *)(&stack0x000023e8 + lVar15) = 0x18b1f28;
                  *(undefined4 *)(&stack0x000023f0 + lVar15) = 0x10;
                  *(undefined2 *)(&stack0x000023f4 + lVar15) = 6;
                  *(undefined2 *)(&stack0x000023f6 + lVar15) = 0;
                  *(undefined **)(&stack0x00001688 + lVar15) = &stack0x000023f8 + lVar15;
                  *(undefined8 *)(&stack0x000023f8 + lVar15) = 0;
                  *(undefined4 *)(&stack0x00002400 + lVar15) = 0;
                  *(undefined2 *)(&stack0x00002404 + lVar15) = 7;
                  *(undefined2 *)(&stack0x00002406 + lVar15) = 0;
                  *(undefined **)(&stack0x00001690 + lVar15) = &stack0x00002408 + lVar15;
                  *(undefined8 *)(&stack0x00002408 + lVar15) = 0;
                  *(undefined4 *)(&stack0x00002410 + lVar15) = 0;
                  *(undefined2 *)(&stack0x00002414 + lVar15) = 8;
                  *(undefined2 *)(&stack0x00002416 + lVar15) = 0;
                  *(undefined **)(&stack0x00001698 + lVar15) = &stack0x00002418 + lVar15;
                  *(undefined8 *)(&stack0x00002418 + lVar15) = 0;
                  *(undefined4 *)(&stack0x00002420 + lVar15) = 0;
                  *(undefined2 *)(&stack0x00002424 + lVar15) = 9;
                  *(undefined2 *)(&stack0x00002426 + lVar15) = 0;
                  *(uint *)(&stack0x000025f8 + lVar15) = (uint)*(ushort *)(lVar25 + 0x6b8);
                  *(undefined2 *)(&stack0x000025fc + lVar15) =
                       *(undefined2 *)(&stack0x0000017c + lVar15);
                  *(undefined4 *)(&stack0x000025fe + lVar15) =
                       *(undefined4 *)(&stack0x00000178 + lVar15);
                  (&stack0x00002602)[lVar15] = (&stack0x00000052)[lVar15];
                  lVar25 = **(longlong **)(&stack0x00000038 + lVar15);
                  *(longlong *)(&stack0x000016a0 + lVar15) = lVar25;
                  (&stack0x00002603)[lVar15] = *(undefined *)(lVar25 + 1);
                  *(undefined **)(&stack0x000016a8 + lVar15) = &stack0x000023d8 + lVar15;
                  *(longlong *)(&stack0x000023d8 + lVar15) = lVar26 + 0x254;
                  *(undefined4 *)(&stack0x000023e0 + lVar15) = 0x10;
                  *(undefined2 *)(&stack0x000023e4 + lVar15) = 5;
                  *(undefined2 *)(&stack0x000023e6 + lVar15) = 0;
                  *(undefined **)(&stack0x000016b0 + lVar15) = &stack0x000023e8 + lVar15;
                  *(longlong *)(&stack0x000023e8 + lVar15) = lVar26 + 0x244;
                  *(undefined4 *)(&stack0x000023f0 + lVar15) = 0x10;
                  *(undefined2 *)(&stack0x000023f4 + lVar15) = 6;
                  *(undefined2 *)(&stack0x000023f6 + lVar15) = 0;
                  *(undefined **)(&stack0x000016b8 + lVar15) = &stack0x00002880 + lVar15;
                  lVar25 = -1;
                  do {
                    lVar25 = lVar25 + 1;
                  } while (*(short *)(&stack0x00002880 + lVar25 * 2 + lVar15) != 0);
                  iVar14 = (int)lVar25 * 2;
                  *(int *)(&stack0x00000be0 + lVar15) = iVar14;
                  *(undefined **)(&stack0x000016c0 + lVar15) = &stack0x000023f8 + lVar15;
                  *(undefined **)(&stack0x000023f8 + lVar15) = &stack0x00002880 + lVar15;
                  *(int *)(&stack0x00002400 + lVar15) = iVar14;
                  *(undefined2 *)(&stack0x00002404 + lVar15) = 7;
                  *(undefined2 *)(&stack0x00002406 + lVar15) = 0;
                  *(undefined **)(&stack0x000016c8 + lVar15) = &stack0x000028b0 + lVar15;
                  lVar25 = -1;
                  do {
                    lVar25 = lVar25 + 1;
                  } while (*(short *)(&stack0x000028b0 + lVar25 * 2 + lVar15) != 0);
                  iVar14 = (int)lVar25 * 2;
                  *(int *)(&stack0x00000be4 + lVar15) = iVar14;
                  *(undefined **)(&stack0x000016d0 + lVar15) = &stack0x00002408 + lVar15;
                  *(undefined **)(&stack0x00002408 + lVar15) = &stack0x000028b0 + lVar15;
                  *(int *)(&stack0x00002410 + lVar15) = iVar14;
                  *(undefined2 *)(&stack0x00002414 + lVar15) = 8;
                  *(undefined2 *)(&stack0x00002416 + lVar15) = 0;
                  *(undefined4 *)(&stack0x00000658 + lVar15) = 0;
                  pcVar5 = *(code **)(_DAT_ + 0x10);
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1050d9;
                  lVar25 = (*pcVar5)(lVar26,&stack0x00000658 + lVar15);
                  *(longlong *)(&stack0x000016d8 + lVar15) = lVar25;
                  if (lVar25 != 0) {
                    lVar26 = -1;
                    do {
                      lVar26 = lVar26 + 1;
                    } while (*(short *)(lVar25 + lVar26 * 2) != 0);
                    iVar13 = (int)lVar26 * 2;
                  }
                  *(int *)(&stack0x00000be8 + lVar15) = iVar13;
                  lVar26 = *(longlong *)(&stack0x000023b0 + lVar15);
                  *(longlong **)(&stack0x000016e0 + lVar15) = (longlong *)(lVar26 + 0x50);
                  *(longlong *)(lVar26 + 0x50) = lVar25;
                  *(int *)(lVar26 + 0x58) = iVar13;
                  *(undefined2 *)(lVar26 + 0x5c) = 9;
                  *(undefined2 *)(lVar26 + 0x5e) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105136;
                  func_0x(&stack0x00002398 + lVar15);
                }
              }
              goto LAB_;
            }
          }
        }
        if ((&stack0x00000094)[lVar15] != '\0') goto LAB_;
        lVar25 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x000016e8 + lVar15) = lVar25;
        lVar25 = (ulonglong)*_DAT_ + *(longlong *)(lVar25 + (ulonglong)*_DAT_ * 8);
        *(longlong *)(&stack0x000016f0 + lVar15) = lVar25;
        lVar25 = *(longlong *)(lVar25 + 8);
        *(longlong *)(&stack0x000016f8 + lVar15) = lVar25;
        lVar25 = *(longlong *)(lVar25 + 0x60);
        *(longlong *)(&stack0x00001700 + lVar15) = lVar25;
        lVar26 = *(longlong *)(&stack0x00000078 + lVar15);
        if (lVar25 == *(longlong *)(lVar26 + 0x2120)) goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1051b0;
        cVar9 = func_0x(lVar26);
        if (cVar9 != '\0') goto LAB_;
        if (*(longlong *)(&stack0x000004b8 + lVar15) == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1051c8;
          uVar20 = func_0x();
          *(undefined8 *)(&stack0x000004b8 + lVar15) = uVar20;
        }
        *(undefined **)(&stack0x00001708 + lVar15) = &stack0x000004d8 + lVar15;
        lVar25 = **(longlong **)(&stack0x00000038 + lVar15);
        *(longlong *)(&stack0x00001710 + lVar15) = lVar25;
        (&stack0x00000095)[lVar15] = 0;
        if (*(short *)(lVar25 + 0x24) == 0) {
LAB_:
          uVar20 = *(undefined8 *)(lVar25 + 0x28);
          uVar39 = (undefined4)uVar20;
          uVar40 = (undefined4)((ulonglong)uVar20 >> 0x20);
          *(undefined8 *)(&stack0x000004d8 + lVar15) = uVar20;
          uVar12 = *(undefined2 *)(lVar25 + 0x30);
          *(undefined2 *)(&stack0x000004e0 + lVar15) = uVar12;
        }
        else {
          cVar9 = *(char *)(lVar25 + 1);
          if ((((cVar9 == '\v') || (cVar9 == '\b')) || (cVar9 == '\t')) &&
             (*(int *)(lVar25 + 0x18) == 99)) {
            *(undefined **)(&stack0x00001718 + lVar15) = &stack0x000005a8 + lVar15;
            *(undefined4 **)(&stack0x00001720 + lVar15) = (undefined4 *)(lVar25 + 0x20);
            *(undefined4 *)(&stack0x000005a8 + lVar15) = *(undefined4 *)(lVar25 + 0x20);
            *(undefined2 *)(&stack0x000005ac + lVar15) = *(undefined2 *)(lVar25 + 0x24);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10525b;
            cVar9 = func_0x(&stack0x000005a8 + lVar15);
            if (cVar9 == '\0') goto LAB_;
            cVar9 = '\x01';
          }
          else {
LAB_:
            cVar9 = '\0';
          }
          (&stack0x00000095)[lVar15] = cVar9;
          if (cVar9 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105280;
          func_0x(lVar25,&stack0x000004d8 + lVar15);
          uVar12 = *(undefined2 *)(&stack0x000004e0 + lVar15);
          uVar39 = (undefined4)*(undefined8 *)(&stack0x000004d8 + lVar15);
          uVar40 = (undefined4)((ulonglong)*(undefined8 *)(&stack0x000004d8 + lVar15) >> 0x20);
        }
        *(undefined **)(&stack0x00001728 + lVar15) = &stack0x000004d8 + lVar15;
        *(ulonglong *)(&stack0x00000640 + lVar15) = CONCAT44(uVar40,uVar39);
        *(undefined2 *)(&stack0x00000648 + lVar15) = uVar12;
        *(undefined2 *)(&stack0x0000064a + lVar15) = 0;
        if (*(longlong *)(&stack0x00000038 + lVar15) != 0) {
          puVar18 = (undefined2 *)(*(longlong *)(&stack0x00000038 + lVar15) + 0x62);
          *(undefined2 **)(&stack0x00001730 + lVar15) = puVar18;
          *(undefined2 *)(&stack0x00000278 + lVar15) = *puVar18;
          if (((*(ushort *)(&stack0x00000278 + lVar15) & 0x400) == 0) ||
             (*(short *)(&stack0x00000044 + lVar15) < 3)) {
            *(int *)(&stack0x000000f8 + lVar15) = (int)*(short *)(&stack0x00000044 + lVar15);
            *(undefined8 *)(&stack0x000008f0 + lVar15) = *(undefined8 *)(&stack0x00000038 + lVar15);
            *(undefined2 **)(&stack0x00001738 + lVar15) = puVar18;
            uVar12 = *puVar18;
            *(undefined2 *)(&stack0x00000280 + lVar15) = uVar12;
            if (((byte)uVar12 >> 3 & 1) != 0) {
              if (*(int *)(&stack0x000000f8 + lVar15) == 3) {
                *(undefined4 *)(&stack0x000000f8 + lVar15) = 4;
              }
              else if (*(int *)(&stack0x000000f8 + lVar15) < 2) goto LAB_;
              *(uint **)(&stack0x00001740 + lVar15) =
                   (uint *)(*(longlong *)(&stack0x00000038 + lVar15) + 100);
              uVar24 = *(uint *)(*(longlong *)(&stack0x00000038 + lVar15) + 100);
              *(uint *)(&stack0x00000660 + lVar15) = uVar24;
              if ((((uVar24 & 8) != 0) &&
                  (lVar25 = *(longlong *)(*(longlong *)(&stack0x00000038 + lVar15) + 0x90),
                  lVar25 != 0)) &&
                 (*(longlong *)(&stack0x00001748 + lVar15) = lVar25,
                 *(longlong *)(lVar25 + 0x758) != 0)) {
                uVar20 = *(undefined8 *)(lVar25 + 0x758);
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1053d3;
                func_0x
                          (uVar20,*(undefined8 *)(&stack0x00000038 + lVar15),
                           *(undefined4 *)(&stack0x000000f8 + lVar15));
              }
            }
LAB_:
            (&stack0x00000192)[lVar15] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
              puVar33 = (uint *)(*(longlong *)(&stack0x000008f0 + lVar15) + 100);
              *(uint **)(&stack0x00001750 + lVar15) = puVar33;
              uVar24 = *puVar33;
              *(uint *)(&stack0x00000668 + lVar15) = uVar24;
              if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x000000f8 + lVar15))) {
                *(uint **)(&stack0x00001758 + lVar15) = puVar33;
                uVar24 = *puVar33;
                *(uint *)(&stack0x00000670 + lVar15) = uVar24;
                if (((uVar24 & 0xc0000000) != 0x40000000) &&
                   (lVar25 = **(longlong **)(&stack0x000008f0 + lVar15), lVar25 != 0)) {
                  *(undefined4 *)(&stack0x00000bec + lVar15) = 2;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105466;
                  iVar13 = (*_DAT_)(lVar25,0x2000,2,&stack0x00000bf0 + lVar15);
                  if (iVar13 != 0) {
                    LOCK();
                    *puVar33 = *puVar33 & 0x3fffffff;
                    UNLOCK();
                    LOCK();
                    *puVar33 = *puVar33 | 0x40000000;
                    UNLOCK();
                  }
                }
              }
            }
            lVar25 = *(longlong *)(&stack0x000008f0 + lVar15);
            uVar39 = *(undefined4 *)(&stack0x000000f8 + lVar15);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105495;
            func_0x(lVar25 + 0x98,uVar39);
            if ((_DAT_ != 0) &&
               ((&stack0x00000193)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1054bf;
              func_0x(lVar25,0,uVar39);
            }
            *(uint *)(&stack0x00000044 + lVar15) = *(uint *)(&stack0x00000044 + lVar15) & 0xffff0000
            ;
            *(undefined8 *)(&stack0x00000038 + lVar15) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105322;
            func_0x(&stack0x00000038 + lVar15);
          }
          uVar39 = (undefined4)*(undefined8 *)(&stack0x00000640 + lVar15);
          uVar40 = (undefined4)((ulonglong)*(undefined8 *)(&stack0x00000640 + lVar15) >> 0x20);
          uVar12 = *(undefined2 *)(&stack0x00000648 + lVar15);
          lVar26 = *(longlong *)(&stack0x00000078 + lVar15);
        }
        *(undefined **)(&stack0x00001760 + lVar15) = &stack0x00000ab0 + lVar15;
        *(ulonglong *)(&stack0x00000ab0 + lVar15) = CONCAT44(uVar40,uVar39);
        *(undefined2 *)(&stack0x00000ab8 + lVar15) = uVar12;
        *(undefined **)(&stack0x00001768 + lVar15) = &stack0x00000a10 + lVar15;
        *(ulonglong *)(&stack0x00000a10 + lVar15) = CONCAT44(uVar40,uVar39);
        *(undefined2 *)(&stack0x00000a18 + lVar15) = uVar12;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
        lVar25 = *plVar29;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10554a;
        func_0x(lVar25,&stack0x00000a10 + lVar15,4);
        goto LAB_;
      }
LAB_:
      (&stack0x00000096)[lVar15] = 1;
LAB_:
      iVar13 = 0;
      if ((1 < *(short *)(&stack0x00000044 + lVar15)) && ((&stack0x00000052)[lVar15] != -1)) {
        lVar25 = **(longlong **)(&stack0x00000038 + lVar15);
        *(longlong *)(&stack0x00001770 + lVar15) = lVar25;
        if (*(char *)(lVar25 + 1) != (&stack0x00000052)[lVar15]) {
          if (*(longlong *)(&stack0x000004b8 + lVar15) != 0) {
            *(longlong *)(&stack0x00001778 + lVar15) = lVar25;
            *(longlong *)(*(longlong *)(&stack0x000004b8 + lVar15) + 0x588) = lVar25;
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1055b2;
          lVar25 = func_0x();
          if (lVar25 == 0) {
LAB_:
            *(int *)(&stack0x00000678 + lVar15) = iVar13;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1055bc;
            lVar25 = func_0x();
            if (*(longlong *)(lVar25 + 0x30) == 0) goto LAB_;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1055c8;
            lVar25 = func_0x();
            uVar24 = *(uint *)(*(longlong *)(lVar25 + 0x30) + 0xc);
            *(uint *)(&stack0x00000bf4 + lVar15) = uVar24;
            if ((0xd < uVar24) || (iVar14 = 1, (0x2640U >> (uVar24 & 0x1f) & 1) == 0)) {
              iVar14 = iVar13;
            }
            *(int *)(&stack0x00000678 + lVar15) = iVar14;
            if (iVar14 != 0) goto LAB_;
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105609;
          func_0x(0,8);
        }
      }
LAB_:
      *(undefined4 *)(&stack0x00000b60 + lVar15) = 0;
      *(undefined4 *)(&stack0x00000b64 + lVar15) = 0;
      *(undefined2 *)(&stack0x00000b68 + lVar15) = 0;
      if (((*(short *)(&stack0x00000620 + lVar15) == 0) &&
          (*(int *)(&stack0x00000618 + lVar15) == 0)) && (*(int *)(&stack0x0000061c + lVar15) == 0))
      goto LAB_;
      lVar25 = **(longlong **)(&stack0x00000038 + lVar15);
      *(longlong *)(&stack0x00001780 + lVar15) = lVar25;
      if ((*(byte *)(lVar25 + 4) & 1) == 0) goto LAB_;
      puVar18 = (undefined2 *)((longlong)*(longlong **)(&stack0x00000038 + lVar15) + 0x62);
      *(undefined2 **)(&stack0x00001788 + lVar15) = puVar18;
      *(undefined2 *)(&stack0x00000288 + lVar15) = *puVar18;
      if (((*(ushort *)(&stack0x00000288 + lVar15) & 0x400) == 0) ||
         (*(short *)(&stack0x00000044 + lVar15) < 3)) {
        *(int *)(&stack0x00000100 + lVar15) = (int)*(short *)(&stack0x00000044 + lVar15);
        *(undefined8 *)(&stack0x000008f8 + lVar15) = *(undefined8 *)(&stack0x00000038 + lVar15);
        *(undefined2 **)(&stack0x00001790 + lVar15) = puVar18;
        uVar12 = *puVar18;
        *(undefined2 *)(&stack0x00000290 + lVar15) = uVar12;
        if (((byte)uVar12 >> 3 & 1) != 0) {
          if (*(int *)(&stack0x00000100 + lVar15) == 3) {
            *(undefined4 *)(&stack0x00000100 + lVar15) = 4;
          }
          else if (*(int *)(&stack0x00000100 + lVar15) < 2) goto LAB_;
          *(uint **)(&stack0x00001798 + lVar15) =
               (uint *)(*(longlong *)(&stack0x00000038 + lVar15) + 100);
          uVar24 = *(uint *)(*(longlong *)(&stack0x00000038 + lVar15) + 100);
          *(uint *)(&stack0x00000680 + lVar15) = uVar24;
          if ((((uVar24 & 8) != 0) &&
              (lVar25 = *(longlong *)(*(longlong *)(&stack0x00000038 + lVar15) + 0x90), lVar25 != 0)
              ) && (*(longlong *)(&stack0x000017a0 + lVar15) = lVar25,
                   *(longlong *)(lVar25 + 0x758) != 0)) {
            uVar20 = *(undefined8 *)(lVar25 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105743;
            func_0x
                      (uVar20,*(undefined8 *)(&stack0x00000038 + lVar15),
                       *(undefined4 *)(&stack0x00000100 + lVar15));
          }
        }
LAB_:
        (&stack0x00000194)[lVar15] = DAT_ >> 7;
        if ((char)DAT_ < '\0') {
          puVar33 = (uint *)(*(longlong *)(&stack0x000008f8 + lVar15) + 100);
          *(uint **)(&stack0x000017a8 + lVar15) = puVar33;
          uVar24 = *puVar33;
          *(uint *)(&stack0x00000688 + lVar15) = uVar24;
          if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x00000100 + lVar15))) {
            *(uint **)(&stack0x000017b0 + lVar15) = puVar33;
            uVar24 = *puVar33;
            *(uint *)(&stack0x00000690 + lVar15) = uVar24;
            if (((uVar24 & 0xc0000000) != 0x40000000) &&
               (lVar25 = **(longlong **)(&stack0x000008f8 + lVar15), lVar25 != 0)) {
              *(undefined4 *)(&stack0x00000bf8 + lVar15) = 2;
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1057d6;
              iVar13 = (*_DAT_)(lVar25,0x2000,2,&stack0x00000bfc + lVar15);
              if (iVar13 != 0) {
                LOCK();
                *puVar33 = *puVar33 & 0x3fffffff;
                UNLOCK();
                LOCK();
                *puVar33 = *puVar33 | 0x40000000;
                UNLOCK();
              }
            }
          }
        }
        lVar25 = *(longlong *)(&stack0x000008f8 + lVar15);
        uVar39 = *(undefined4 *)(&stack0x00000100 + lVar15);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105805;
        func_0x(lVar25 + 0x98,uVar39);
        if ((_DAT_ != 0) &&
           ((&stack0x00000195)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10582f;
          func_0x(lVar25,0,uVar39);
        }
        *(uint *)(&stack0x00000044 + lVar15) = *(uint *)(&stack0x00000044 + lVar15) & 0xffff0000;
        *(undefined8 *)(&stack0x00000038 + lVar15) = 0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105692;
        func_0x(&stack0x00000038 + lVar15);
      }
      *(undefined4 *)(&stack0x00000fc0 + lVar15) = 0x400060;
      *(undefined8 *)(&stack0x00000fc8 + lVar15) = 0;
      *(undefined8 *)(&stack0x00000fd8 + lVar15) = 0;
      *(undefined8 *)(&stack0x00000fd0 + lVar15) = 0;
      *(undefined8 *)(&stack0x00000fe0 + lVar15) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10587b;
      func_0x(10,&stack0x00000fc0 + lVar15);
      lVar26 = *(longlong *)(&stack0x00000078 + lVar15);
    } while( true );
  }
LAB_:
  ppbVar34 = (byte **)0x0;
  *(longlong *)(&stack0x00001820 + lVar15) = lVar25;
  *(undefined4 *)(&stack0x00002744 + lVar15) = 0;
  if (-1 < *(char *)(lVar25 + 2)) {
    *(undefined8 *)(&stack0x00000910 + lVar15) = 0;
    ppbVar38 = ppbVar34;
    goto LAB_;
  }
  if (*(short *)(&stack0x00002710 + lVar15) == 0) {
    *(undefined8 *)(&stack0x00000910 + lVar15) = 0;
LAB_:
    *(undefined **)(&stack0x00001828 + lVar15) = &stack0x00002748 + lVar15;
    *(undefined (*) [16])(&stack0x00002748 + lVar15) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00002758 + lVar15) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00002768 + lVar15) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00002778 + lVar15) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00002788 + lVar15) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00002798 + lVar15) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x000027a8 + lVar15) = ZEXT816(0);
    *(undefined8 *)(&stack0x000027b8 + lVar15) = 0;
    *(undefined **)(&stack0x00001830 + lVar15) = &stack0x00002748 + lVar15;
    *(undefined (*) [16])(&stack0x00002748 + lVar15) = ZEXT816(0);
    *(undefined **)(&stack0x00001838 + lVar15) = &stack0x00002758 + lVar15;
    *(undefined2 *)(&stack0x00002758 + lVar15) = 0xffff;
    *(undefined8 *)(&stack0x00002760 + lVar15) = 0;
    *(undefined4 *)(&stack0x0000275c + lVar15) = 0;
    *(undefined8 *)(&stack0x00002776 + lVar15) = 0;
    *(undefined8 *)(&stack0x00002780 + lVar15) = 0;
    *(undefined8 *)(&stack0x00002768 + lVar15) = 0;
    *(undefined **)(&stack0x00001840 + lVar15) = &stack0x00002790 + lVar15;
    *(undefined8 *)(&stack0x00002790 + lVar15) = 0;
    *(undefined **)(&stack0x00001848 + lVar15) = &stack0x000027a8 + lVar15;
    *(undefined4 *)(&stack0x000027a8 + lVar15) = 0;
    *(undefined4 *)(&stack0x000027ac + lVar15) = 0;
    *(undefined2 *)(&stack0x000027b0 + lVar15) = 0;
    *(undefined2 *)(&stack0x000027b2 + lVar15) = 0;
    *(undefined **)(&stack0x00001850 + lVar15) = &stack0x000027b4 + lVar15;
    *(undefined2 *)(&stack0x000027ba + lVar15) = 0;
    ppbVar38 = (byte **)(&stack0x00002748 + lVar15);
    *(byte ***)(&stack0x00000910 + lVar15) = ppbVar38;
  }
  else {
    ppbVar38 = *(byte ***)(&stack0x00002720 + lVar15);
    *(byte ***)(&stack0x00000910 + lVar15) = ppbVar38;
    if (ppbVar38 == (byte **)0x0) goto LAB_;
  }
  (&stack0x00000097)[lVar15] = 0;
  if (*(short *)(lVar25 + 0x24) == 0) {
LAB_:
    *(undefined8 *)(&stack0x00000370 + lVar15) = *(undefined8 *)(lVar25 + 0x28);
    sVar11 = *(short *)(lVar25 + 0x30);
    *(short *)(&stack0x00000378 + lVar15) = sVar11;
  }
  else {
    cVar9 = *(char *)(lVar25 + 1);
    if ((((cVar9 == '\v') || (cVar9 == '\b')) || (cVar9 == '\t')) && (*(int *)(lVar25 + 0x18) == 99)
       ) {
      *(undefined **)(&stack0x00001858 + lVar15) = &stack0x00000588 + lVar15;
      *(undefined4 **)(&stack0x00001860 + lVar15) = (undefined4 *)(lVar25 + 0x20);
      *(undefined4 *)(&stack0x00000588 + lVar15) = *(undefined4 *)(lVar25 + 0x20);
      *(undefined2 *)(&stack0x0000058c + lVar15) = *(undefined2 *)(lVar25 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105ea3;
      cVar9 = func_0x(&stack0x00000588 + lVar15);
      if (cVar9 == '\0') goto LAB_;
      cVar9 = '\x01';
    }
    else {
LAB_:
      cVar9 = '\0';
    }
    (&stack0x00000097)[lVar15] = cVar9;
    if (cVar9 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105ec8;
    func_0x(lVar25,&stack0x00000370 + lVar15);
    sVar11 = *(short *)(&stack0x00000378 + lVar15);
  }
  *(undefined **)(&stack0x00001868 + lVar15) = &stack0x00000370 + lVar15;
  *(undefined4 **)(&stack0x00001870 + lVar15) = (undefined4 *)(lVar25 + 0x20);
  pbVar36 = (byte *)(lVar25 + 0x60);
  *(byte **)(&stack0x00001878 + lVar15) = pbVar36;
  *(byte ***)(&stack0x00001880 + lVar15) = ppbVar38;
  if (pbVar36 == *ppbVar38) {
    *(byte ***)(&stack0x00001888 + lVar15) = ppbVar38 + 0xc;
    if (((sVar11 == *(short *)(ppbVar38 + 0xd)) &&
        (*(int *)(&stack0x00000370 + lVar15) == *(int *)(ppbVar38 + 0xc))) &&
       (*(int *)(&stack0x00000374 + lVar15) == *(int *)((longlong)ppbVar38 + 100))) {
      *(longlong *)(&stack0x00001890 + lVar15) = (longlong)ppbVar38 + 0x6c;
    }
  }
  *ppbVar38 = pbVar36;
  *(byte ***)(&stack0x00001898 + lVar15) = ppbVar38 + 0xc;
  uVar12 = *(undefined2 *)(&stack0x00000378 + lVar15);
  *(undefined2 *)(&stack0x00000760 + lVar15) = uVar12;
  uVar39 = *(undefined4 *)(&stack0x00000374 + lVar15);
  *(undefined4 *)(&stack0x00000c08 + lVar15) = uVar39;
  *(undefined4 *)(&stack0x00000c10 + lVar15) = *(undefined4 *)(&stack0x00000370 + lVar15);
  *(undefined4 *)(ppbVar38 + 0xc) = *(undefined4 *)(&stack0x00000370 + lVar15);
  *(undefined4 *)((longlong)ppbVar38 + 100) = uVar39;
  *(undefined2 *)(ppbVar38 + 0xd) = uVar12;
  *(undefined4 **)(&stack0x000018a0 + lVar15) = (undefined4 *)((longlong)ppbVar38 + 0x6c);
  *(undefined4 *)((longlong)ppbVar38 + 0x6c) = *(undefined4 *)(lVar25 + 0x20);
  *(undefined2 *)(ppbVar38 + 0xe) = *(undefined2 *)(lVar25 + 0x24);
  *(undefined2 *)((longlong)ppbVar38 + 0x72) = 0;
  uVar21 = (ulonglong)*pbVar36;
  *(ushort *)(&stack0x00000768 + lVar15) = (ushort)*pbVar36;
  *(undefined4 *)(&stack0x00000a9e + lVar15) = *(undefined4 *)(uVar21 * 6 + 0x177fa30);
  *(undefined2 *)(&stack0x00000aa2 + lVar15) = *(undefined2 *)(uVar21 * 6 + 0x177fa34);
  *(undefined4 *)(&stack0x000007a8 + lVar15) = *(undefined4 *)(uVar21 * 6 + 0x177fa30);
  sVar11 = *(short *)(uVar21 * 6 + 0x177fa34);
  *(short *)(&stack0x00000054 + lVar15) = sVar11;
  *(short *)(&stack0x000007ac + lVar15) = sVar11;
  *(longlong *)(&stack0x000018a8 + lVar15) = lVar25 + 99;
  ppbVar1 = ppbVar38 + 2;
  *(byte ***)(&stack0x000018b0 + lVar15) = ppbVar1;
  *(undefined2 *)ppbVar1 = 0xffff;
  ppbVar38[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar38 + 0x2e) = 0;
  ppbVar38[7] = (byte *)0x0;
  ppbVar38[4] = (byte *)0x0;
  *(byte ***)(&stack0x000018b8 + lVar15) = ppbVar38 + 9;
  ppbVar38[9] = (byte *)0x0;
  ppbVar38[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar38 + 0xb) = 0;
  if ((**ppbVar38 & 2) == 0) goto code_r0x001063d1;
  pbVar36 = pbVar36 + sVar11;
  *(byte **)(&stack0x000018c0 + lVar15) = pbVar36;
  *(byte ***)(&stack0x000018c8 + lVar15) = ppbVar1;
  bVar10 = *pbVar36 & 1;
  *(ushort *)(&stack0x00000770 + lVar15) = (ushort)bVar10;
  *(ushort *)ppbVar1 = (ushort)bVar10;
  puVar16 = (ushort *)((longlong)ppbVar38 + 0x12);
  if (bVar10 != 0) {
    *(ushort **)(&stack0x000018e0 + lVar15) = puVar16;
    ppbVar38[3] = pbVar36;
    bVar10 = *pbVar36;
    switch(bVar10 & 0x1c) {
    default:
      puVar32 = (ushort *)(pbVar36 + 1);
      *(ushort **)(&stack0x000018e8 + lVar15) = puVar32;
      if ((char)*(byte *)puVar32 < '\0') {
        uVar23 = *puVar32;
        *puVar16 = uVar23;
        *puVar16 = (uVar23 & 0x7f) << 8 | uVar23 >> 8;
        *(undefined2 *)(ppbVar38 + 5) = 3;
        sVar11 = 3;
      }
      else {
        *puVar16 = (ushort)*(byte *)puVar32;
        *(undefined2 *)(ppbVar38 + 5) = 2;
        sVar11 = 2;
      }
      *(short *)((longlong)ppbVar38 + 0x2c) = (short)(*puVar16 + 1 >> 1) + sVar11;
      if (*puVar16 < 0x1f) {
        *(undefined2 *)((longlong)ppbVar38 + 0x2a) = 0;
        *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
        *(undefined4 *)(ppbVar38 + 8) = 0;
      }
      else {
        iVar13 = *puVar16 - 1;
        *(short *)((longlong)ppbVar38 + 0x2a) =
             ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
             (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
        *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
        *(undefined4 *)(ppbVar38 + 8) = 0;
      }
      break;
    case 4:
      *(byte **)(&stack0x000018f8 + lVar15) = pbVar36;
      *(byte **)(&stack0x00001900 + lVar15) = pbVar36;
      if (((bVar10 & 0x1c) == 4) && ((bVar10 & 2) != 0)) {
        ppbVar38[3] = (byte *)0x0;
        *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
        *(undefined2 *)(ppbVar38 + 5) = 0;
        *puVar16 = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x2a) = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x2c) = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x2e) = 0;
        *(undefined2 *)(ppbVar38 + 6) = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x32) = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x34) = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x36) = 0;
        ppbVar38[4] = (byte *)0x0;
        *(undefined4 *)(ppbVar38 + 8) = 0;
        ppbVar38[7] = (byte *)0x0;
        ppbVar38[3] = pbVar36;
        *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0xf;
        *(undefined4 *)(ppbVar38 + 8) = 0;
        *(undefined4 *)(ppbVar38 + 8) = 1;
      }
      else {
        ppbVar38[3] = (byte *)0x0;
        *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
        *(undefined2 *)(ppbVar38 + 5) = 0;
        *puVar16 = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x2a) = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x2c) = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x2e) = 0;
        *(undefined2 *)(ppbVar38 + 6) = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x32) = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x34) = 0;
        *(undefined2 *)((longlong)ppbVar38 + 0x36) = 0;
        ppbVar38[4] = (byte *)0x0;
        *(undefined4 *)(ppbVar38 + 8) = 0;
        ppbVar38[7] = (byte *)0x0;
        ppbVar38[3] = pbVar36;
        *(undefined4 *)((longlong)ppbVar38 + 0x14) = 1;
        *(undefined4 *)(ppbVar38 + 8) = 0;
      }
      break;
    case 8:
      *(byte **)(&stack0x000018f0 + lVar15) = pbVar36;
      ppbVar38[3] = (byte *)0x0;
      *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
      *(undefined2 *)(ppbVar38 + 5) = 0;
      *puVar16 = 0;
      *(undefined2 *)((longlong)ppbVar38 + 0x2a) = 0;
      *(undefined2 *)((longlong)ppbVar38 + 0x2c) = 0;
      *(undefined2 *)((longlong)ppbVar38 + 0x2e) = 0;
      *(undefined2 *)(ppbVar38 + 6) = 0;
      *(undefined2 *)((longlong)ppbVar38 + 0x32) = 0;
      *(undefined2 *)((longlong)ppbVar38 + 0x34) = 0;
      *(undefined2 *)((longlong)ppbVar38 + 0x36) = 0;
      ppbVar38[4] = (byte *)0x0;
      *(undefined4 *)(ppbVar38 + 8) = 0;
      ppbVar38[7] = (byte *)0x0;
      ppbVar38[3] = pbVar36;
      *(undefined4 *)((longlong)ppbVar38 + 0x14) = 9;
      *(undefined4 *)(ppbVar38 + 8) = 0;
    }
    ppbVar38[7] = (byte *)0x0;
    ppbVar38[4] = (byte *)0x0;
    sVar11 = *(short *)(&stack0x00000054 + lVar15);
    goto code_r0x001063d1;
  }
  *(undefined4 *)(&stack0x00000318 + lVar15) = 0;
  *(ushort **)(&stack0x000018d0 + lVar15) = puVar16;
  ppbVar38[3] = pbVar36;
  *(undefined4 *)((longlong)ppbVar38 + 0x14) = 0;
  *(undefined4 *)((longlong)ppbVar38 + 0x36) = 0;
  pbVar7 = ppbVar38[3];
  *(byte **)(&stack0x000018d8 + lVar15) = pbVar7;
  switch(*pbVar7 & 0xe) {
  default:
    uVar23 = *(ushort *)(pbVar36 + 2);
    ppbVar34 = (byte **)(ulonglong)uVar23;
    *(uint *)(&stack0x00000318 + lVar15) = (uint)uVar23;
    if (0x1f9d < uVar23 - 1) {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106109;
      func_0x(pbVar7,6);
    }
    break;
  case 4:
    ppbVar34 = (byte **)0x9;
    goto code_r0x00106114;
  case 6:
  case 10:
    break;
  case 0xe:
    ppbVar34 = (byte **)0x1;
code_r0x00106114:
    *(int *)(&stack0x00000318 + lVar15) = (int)ppbVar34;
  }
  *(int *)(ppbVar38 + 4) = (int)ppbVar34;
  *(undefined8 *)((longlong)ppbVar38 + 0x2e) = 0;
  sVar11 = *(short *)(&stack0x00000054 + lVar15);
code_r0x001063d1:
  if ((**ppbVar38 & 4) != 0) {
    if (*(short *)(&stack0x000007aa + lVar15) == 0) {
      uVar21 = (ulonglong)sVar11;
    }
    else {
      uVar21 = (ulonglong)
               *(ushort *)(lVar25 + 0x61 + (longlong)*(short *)(&stack0x000007aa + lVar15) * 2);
    }
    psVar22 = (short *)(uVar21 + lVar25 + 0x60);
    *(short **)(&stack0x00001908 + lVar15) = psVar22;
    *(byte ***)(&stack0x00001910 + lVar15) = ppbVar38 + 9;
    ppbVar38[9] = (byte *)psVar22;
    sVar11 = *psVar22;
    *(short *)(&stack0x00000774 + lVar15) = sVar11;
    ppbVar38[10] = (byte *)(psVar22 + 1);
    *(short *)(ppbVar38 + 0xb) = (sVar11 + 1) * 2;
  }
  pbVar36 = ppbVar38[1];
  if (pbVar36 != (byte *)0x0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106438;
    func_0x(pbVar36,ppbVar38);
  }
LAB_:
  sVar11 = 3;
  uVar23 = *(ushort *)(lVar25 + 0xe);
  uVar24 = (uint)uVar23;
  *(uint *)(&stack0x00000c18 + lVar15) = (uint)uVar23;
  pbVar36 = (byte *)((ulonglong)*(ushort *)(lVar25 + 0x1ffe) + lVar25);
  *(byte **)(&stack0x00001918 + lVar15) = pbVar36;
  bVar10 = *pbVar36 & 1;
  *(ushort *)(&stack0x00000778 + lVar15) = (ushort)bVar10;
  *(ushort *)(&stack0x00002710 + lVar15) = (ushort)bVar10;
  if (bVar10 == 0) {
    *(uint *)(&stack0x00000320 + lVar15) = (uint)uVar23;
    *(undefined **)(&stack0x00001920 + lVar15) = &stack0x00002712 + lVar15;
    *(byte **)(&stack0x00002718 + lVar15) = pbVar36;
    *(undefined4 *)(&stack0x00002714 + lVar15) = 0;
    *(undefined4 *)(&stack0x00002736 + lVar15) = 0;
    *(byte **)(&stack0x00001928 + lVar15) = pbVar36;
    switch(*pbVar36 & 0xe) {
    default:
      uVar23 = *(ushort *)(pbVar36 + 2);
      uVar24 = (uint)uVar23;
      *(uint *)(&stack0x00000320 + lVar15) = (uint)uVar23;
      if (0x1f9d < uVar23 - 1) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1064e6;
        func_0x(pbVar36,6);
      }
      break;
    case 4:
      uVar24 = 9;
      *(undefined4 *)(&stack0x00000320 + lVar15) = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar24 = 1;
      *(undefined4 *)(&stack0x00000320 + lVar15) = 1;
    }
    *(uint *)(&stack0x00002720 + lVar15) = uVar24;
    *(longlong *)(&stack0x0000272e + lVar15) = lVar25 + 0x2000;
  }
  else {
    *(undefined **)(&stack0x00001930 + lVar15) = &stack0x00002712 + lVar15;
    *(byte **)(&stack0x00002718 + lVar15) = pbVar36;
    bVar10 = *pbVar36;
    switch(bVar10 & 0x1c) {
    default:
      puVar16 = (ushort *)(pbVar36 + 1);
      *(ushort **)(&stack0x00001938 + lVar15) = puVar16;
      if ((char)*(byte *)puVar16 < '\0') {
        uVar23 = *puVar16;
        *(ushort *)(&stack0x00002712 + lVar15) = uVar23;
        uVar23 = (uVar23 & 0x7f) << 8 | uVar23 >> 8;
        *(ushort *)(&stack0x00002712 + lVar15) = uVar23;
        *(undefined2 *)(&stack0x00002728 + lVar15) = 3;
      }
      else {
        uVar23 = (ushort)*(byte *)puVar16;
        *(ushort *)(&stack0x00002712 + lVar15) = uVar23;
        *(undefined2 *)(&stack0x00002728 + lVar15) = 2;
        sVar11 = 2;
      }
      *(short *)(&stack0x0000272c + lVar15) = (short)(uVar23 + 1 >> 1) + sVar11;
      if (uVar23 < 0x1f) {
        *(undefined2 *)(&stack0x0000272a + lVar15) = 0;
        *(undefined4 *)(&stack0x00002714 + lVar15) = 0;
        *(undefined4 *)(&stack0x00002740 + lVar15) = 0;
      }
      else {
        iVar13 = uVar23 - 1;
        *(short *)(&stack0x0000272a + lVar15) =
             ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
             (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
        *(undefined4 *)(&stack0x00002714 + lVar15) = 0;
        *(undefined4 *)(&stack0x00002740 + lVar15) = 0;
      }
      break;
    case 4:
      *(byte **)(&stack0x00001948 + lVar15) = pbVar36;
      *(byte **)(&stack0x00001950 + lVar15) = pbVar36;
      if (((bVar10 & 0x1c) == 4) && ((bVar10 & 2) != 0)) {
        *(undefined8 *)(&stack0x00002718 + lVar15) = 0;
        *(undefined4 *)(&stack0x00002714 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002728 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002712 + lVar15) = 0;
        *(undefined2 *)(&stack0x0000272a + lVar15) = 0;
        *(undefined2 *)(&stack0x0000272c + lVar15) = 0;
        *(undefined2 *)(&stack0x0000272e + lVar15) = 0;
        *(undefined2 *)(&stack0x00002730 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002732 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002734 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002736 + lVar15) = 0;
        *(undefined8 *)(&stack0x00002720 + lVar15) = 0;
        *(undefined4 *)(&stack0x00002740 + lVar15) = 0;
        *(undefined8 *)(&stack0x00002738 + lVar15) = 0;
        *(byte **)(&stack0x00002718 + lVar15) = pbVar36;
        *(undefined4 *)(&stack0x00002714 + lVar15) = 0xf;
        *(undefined4 *)(&stack0x00002740 + lVar15) = 0;
        *(undefined4 *)(&stack0x00002740 + lVar15) = 1;
      }
      else {
        *(undefined8 *)(&stack0x00002718 + lVar15) = 0;
        *(undefined4 *)(&stack0x00002714 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002728 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002712 + lVar15) = 0;
        *(undefined2 *)(&stack0x0000272a + lVar15) = 0;
        *(undefined2 *)(&stack0x0000272c + lVar15) = 0;
        *(undefined2 *)(&stack0x0000272e + lVar15) = 0;
        *(undefined2 *)(&stack0x00002730 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002732 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002734 + lVar15) = 0;
        *(undefined2 *)(&stack0x00002736 + lVar15) = 0;
        *(undefined8 *)(&stack0x00002720 + lVar15) = 0;
        *(undefined4 *)(&stack0x00002740 + lVar15) = 0;
        *(undefined8 *)(&stack0x00002738 + lVar15) = 0;
        *(byte **)(&stack0x00002718 + lVar15) = pbVar36;
        *(undefined4 *)(&stack0x00002714 + lVar15) = 1;
        *(undefined4 *)(&stack0x00002740 + lVar15) = 0;
      }
      break;
    case 8:
      *(byte **)(&stack0x00001940 + lVar15) = pbVar36;
      *(undefined8 *)(&stack0x00002718 + lVar15) = 0;
      *(undefined4 *)(&stack0x00002714 + lVar15) = 0;
      *(undefined2 *)(&stack0x00002728 + lVar15) = 0;
      *(undefined2 *)(&stack0x00002712 + lVar15) = 0;
      *(undefined2 *)(&stack0x0000272a + lVar15) = 0;
      *(undefined2 *)(&stack0x0000272c + lVar15) = 0;
      *(undefined2 *)(&stack0x0000272e + lVar15) = 0;
      *(undefined2 *)(&stack0x00002730 + lVar15) = 0;
      *(undefined2 *)(&stack0x00002732 + lVar15) = 0;
      *(undefined2 *)(&stack0x00002734 + lVar15) = 0;
      *(undefined2 *)(&stack0x00002736 + lVar15) = 0;
      *(undefined8 *)(&stack0x00002720 + lVar15) = 0;
      *(undefined4 *)(&stack0x00002740 + lVar15) = 0;
      *(undefined8 *)(&stack0x00002738 + lVar15) = 0;
      *(byte **)(&stack0x00002718 + lVar15) = pbVar36;
      *(undefined4 *)(&stack0x00002714 + lVar15) = 9;
      *(undefined4 *)(&stack0x00002740 + lVar15) = 0;
    }
    *(longlong *)(&stack0x00002738 + lVar15) = lVar25 + 0x2000;
    *(byte ***)(&stack0x00002720 + lVar15) = ppbVar38;
  }
  *(undefined **)(&stack0x00002680 + lVar15) = &stack0x00002710 + lVar15;
  lVar25 = *(longlong *)(&stack0x00000448 + lVar15);
  uVar20 = *(undefined8 *)(lVar25 + 0x110);
  *(undefined8 *)(&stack0x00001958 + lVar15) = uVar20;
  uVar39 = *(undefined4 *)(lVar25 + 0x100);
  *(undefined4 *)(&stack0x00000c20 + lVar15) = uVar39;
  *(undefined4 *)((longlong)auStackX_20 + lVar15) = 0;
  *(undefined4 *)((longlong)&uStackX_18 + lVar15) = 0;
  *(undefined8 *)((longlong)&uStackX_10 + lVar15) = 0;
  *(undefined8 *)((longlong)&uStackX_8 + lVar15) = uVar20;
  *(undefined4 *)((longlong)auStackX_20 + lVar15 + -0x20) = 0;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = uVar39;
  *(undefined **)(&stack0xfffffffffffffff0 + lVar15) = &stack0x00002680 + lVar15;
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 1;
  uVar20 = *(undefined8 *)(&stack0x00000a60 + lVar15);
  plVar29 = *(longlong **)(&stack0x00000a70 + lVar15);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1068ea;
  func_0x(plVar29,uVar20,&stack0x00000188 + lVar15,1);
  uVar8 = *(undefined8 *)(lVar25 + 0x110);
  *(undefined8 *)(&stack0x00001960 + lVar15) = uVar8;
  uVar39 = *(undefined4 *)(lVar25 + 0x100);
  *(undefined4 *)(&stack0x00000c28 + lVar15) = uVar39;
  *(undefined8 *)(&stack0x00000028 + lVar15) = 0;
  *(undefined4 *)((longlong)auStackX_20 + lVar15) = 0;
  *(undefined8 *)((longlong)&uStackX_18 + lVar15) = 0;
  *(undefined4 *)((longlong)&uStackX_10 + lVar15) = 0;
  *(undefined8 *)((longlong)&uStackX_8 + lVar15) = 0;
  *(undefined8 *)((longlong)auStackX_20 + lVar15 + -0x20) = uVar8;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = 0;
  *(undefined4 *)(&stack0xfffffffffffffff0 + lVar15) = uVar39;
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 1;
  plVar17 = *(longlong **)(&stack0x00000a68 + lVar15);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10694e;
  func_0x(plVar17,uVar20,&stack0x00000188 + lVar15,0);
  uVar8 = *(undefined8 *)(lVar25 + 0x110);
  *(undefined8 *)(&stack0x00001968 + lVar15) = uVar8;
  uVar39 = *(undefined4 *)(lVar25 + 0x100);
  *(undefined4 *)(&stack0x00000c30 + lVar15) = uVar39;
  *(undefined8 *)(&stack0x00000028 + lVar15) = 0;
  *(undefined4 *)((longlong)auStackX_20 + lVar15) = 0;
  *(undefined8 *)((longlong)&uStackX_18 + lVar15) = 0;
  *(undefined4 *)((longlong)&uStackX_10 + lVar15) = 0;
  *(undefined8 *)((longlong)&uStackX_8 + lVar15) = 0;
  *(undefined8 *)((longlong)auStackX_20 + lVar15 + -0x20) = uVar8;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = 0;
  *(undefined4 *)(&stack0xfffffffffffffff0 + lVar15) = uVar39;
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 1;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1069b4;
  func_0x
            (*(undefined8 *)(&stack0x00000920 + lVar15),uVar20,&stack0x00000188 + lVar15,
             *(undefined4 *)(&stack0x00000454 + lVar15));
  *(undefined **)(&stack0xffffffffffffffe8 + lVar15) = &stack0x00000ef8 + lVar15;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1069d4;
  func_0x(lVar25,plVar17,plVar29,&stack0x00000038 + lVar15);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1069e1;
  func_0x(&stack0x00000ef8 + lVar15);
  if (*plVar17 != 0) {
    puVar16 = (ushort *)(*plVar17 + 0x62);
    *(ushort **)(&stack0x00001970 + lVar15) = puVar16;
    uVar23 = *puVar16;
    *(ushort *)(&stack0x000002a8 + lVar15) = uVar23;
    if (((uVar23 & 0x400) == 0) || (*(short *)((longlong)plVar17 + 0xc) < 3)) {
      *(int *)(&stack0x00000110 + lVar15) = (int)*(short *)((longlong)plVar17 + 0xc);
      lVar26 = *plVar17;
      *(longlong *)(&stack0x000003f0 + lVar15) = lVar26;
      puVar18 = (undefined2 *)(lVar26 + 0x62);
      *(undefined2 **)(&stack0x00001978 + lVar15) = puVar18;
      uVar12 = *puVar18;
      *(undefined2 *)(&stack0x000002b0 + lVar15) = uVar12;
      if (((byte)uVar12 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x00000110 + lVar15) == 3) {
          *(undefined4 *)(&stack0x00000110 + lVar15) = 4;
        }
        else if (*(int *)(&stack0x00000110 + lVar15) < 2) goto code_r0x00106ae2;
        *(uint **)(&stack0x00001980 + lVar15) =
             (uint *)(*(longlong *)(&stack0x000003f0 + lVar15) + 100);
        uVar24 = *(uint *)(*(longlong *)(&stack0x000003f0 + lVar15) + 100);
        *(uint *)(&stack0x000006b8 + lVar15) = uVar24;
        if ((((uVar24 & 8) != 0) &&
            (lVar26 = *(longlong *)(*(longlong *)(&stack0x000003f0 + lVar15) + 0x90), lVar26 != 0))
           && (*(longlong *)(&stack0x00001988 + lVar15) = lVar26, *(longlong *)(lVar26 + 0x758) != 0
              )) {
          uVar20 = *(undefined8 *)(lVar26 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106ae2;
          func_0x
                    (uVar20,*(undefined8 *)(&stack0x000003f0 + lVar15),
                     *(undefined4 *)(&stack0x00000110 + lVar15));
        }
      }
code_r0x00106ae2:
      (&stack0x0000019a)[lVar15] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar33 = (uint *)(*(longlong *)(&stack0x000003f0 + lVar15) + 100);
        *(uint **)(&stack0x00001990 + lVar15) = puVar33;
        uVar24 = *puVar33;
        *(uint *)(&stack0x000006c0 + lVar15) = uVar24;
        if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x00000110 + lVar15))) {
          *(uint **)(&stack0x00001998 + lVar15) = puVar33;
          uVar24 = *puVar33;
          *(uint *)(&stack0x000006c8 + lVar15) = uVar24;
          if (((uVar24 & 0xc0000000) != 0x40000000) &&
             (lVar26 = **(longlong **)(&stack0x000003f0 + lVar15), lVar26 != 0)) {
            *(undefined4 *)(&stack0x00000c80 + lVar15) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106b75;
            iVar13 = (*_DAT_)(lVar26,0x2000,2,&stack0x00000c38 + lVar15);
            if (iVar13 != 0) {
              LOCK();
              *puVar33 = *puVar33 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar33 = *puVar33 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar26 = *(longlong *)(&stack0x000003f0 + lVar15);
      uVar39 = *(undefined4 *)(&stack0x00000110 + lVar15);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106ba4;
      func_0x(lVar26 + 0x98,uVar39);
      if ((_DAT_ != 0) &&
         ((&stack0x0000019b)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106bcf;
        func_0x(lVar26,0,uVar39);
      }
      *(uint *)((longlong)plVar17 + 0xc) = *(uint *)((longlong)plVar17 + 0xc) & 0xffff0000;
      *plVar17 = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106a1d;
      func_0x(plVar17);
    }
  }
  if (*(longlong *)(&stack0x00000058 + lVar15) != 0) {
    puVar18 = (undefined2 *)(*(longlong *)(&stack0x00000058 + lVar15) + 0x62);
    *(undefined2 **)(&stack0x000019a0 + lVar15) = puVar18;
    *(undefined2 *)(&stack0x000002b8 + lVar15) = *puVar18;
    if (((*(ushort *)(&stack0x000002b8 + lVar15) & 0x400) == 0) ||
       (*(short *)(&stack0x00000064 + lVar15) < 3)) {
      *(int *)(&stack0x00000150 + lVar15) = (int)*(short *)(&stack0x00000064 + lVar15);
      *(undefined8 *)(&stack0x000019a8 + lVar15) = *(undefined8 *)(&stack0x00000058 + lVar15);
      *(undefined2 **)(&stack0x000019b0 + lVar15) = puVar18;
      uVar12 = *puVar18;
      *(undefined2 *)(&stack0x000002c0 + lVar15) = uVar12;
      if (((byte)uVar12 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x00000150 + lVar15) == 3) {
          *(undefined4 *)(&stack0x00000150 + lVar15) = 4;
        }
        else if (*(int *)(&stack0x00000150 + lVar15) < 2) goto code_r0x00106cf0;
        *(uint **)(&stack0x000019b8 + lVar15) =
             (uint *)(*(longlong *)(&stack0x00000058 + lVar15) + 100);
        uVar24 = *(uint *)(*(longlong *)(&stack0x00000058 + lVar15) + 100);
        *(uint *)(&stack0x000006d0 + lVar15) = uVar24;
        if ((((uVar24 & 8) != 0) &&
            (lVar26 = *(longlong *)(*(longlong *)(&stack0x00000058 + lVar15) + 0x90), lVar26 != 0))
           && (*(longlong *)(&stack0x000019c0 + lVar15) = lVar26, *(longlong *)(lVar26 + 0x758) != 0
              )) {
          uVar20 = *(undefined8 *)(lVar26 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106cf0;
          func_0x
                    (uVar20,*(undefined8 *)(&stack0x00000058 + lVar15),
                     *(undefined4 *)(&stack0x00000150 + lVar15));
        }
      }
code_r0x00106cf0:
      (&stack0x0000019c)[lVar15] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar33 = (uint *)(*(longlong *)(&stack0x00000058 + lVar15) + 100);
        *(uint **)(&stack0x000019c8 + lVar15) = puVar33;
        uVar24 = *puVar33;
        *(uint *)(&stack0x000006d8 + lVar15) = uVar24;
        if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x00000150 + lVar15))) {
          *(uint **)(&stack0x000019d0 + lVar15) = puVar33;
          uVar24 = *puVar33;
          *(uint *)(&stack0x000006e0 + lVar15) = uVar24;
          if (((uVar24 & 0xc0000000) != 0x40000000) &&
             (lVar26 = **(longlong **)(&stack0x00000058 + lVar15), lVar26 != 0)) {
            *(undefined4 *)(&stack0x00000c3c + lVar15) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106d83;
            iVar13 = (*_DAT_)(lVar26,0x2000,2,&stack0x00000c40 + lVar15);
            if (iVar13 != 0) {
              LOCK();
              *puVar33 = *puVar33 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar33 = *puVar33 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar26 = *(longlong *)(&stack0x00000058 + lVar15);
      uVar39 = *(undefined4 *)(&stack0x00000150 + lVar15);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106db2;
      func_0x(lVar26 + 0x98,uVar39);
      if ((_DAT_ != 0) &&
         ((&stack0x0000019d)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106ddd;
        func_0x(lVar26,0,uVar39);
      }
      *(uint *)(&stack0x00000064 + lVar15) = *(uint *)(&stack0x00000064 + lVar15) & 0xffff0000;
      *(undefined8 *)(&stack0x00000058 + lVar15) = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106c2d;
      func_0x(&stack0x00000058 + lVar15);
    }
  }
  *(longlong *)(&stack0x00000058 + lVar15) = *plVar29;
  *(uint *)(&stack0x00000064 + lVar15) =
       *(uint *)(&stack0x00000064 + lVar15) & 0xffff0000 |
       (uint)*(ushort *)((longlong)plVar29 + 0xc);
  *plVar29 = 0;
  *(uint *)((longlong)plVar29 + 0xc) = *(uint *)((longlong)plVar29 + 0xc) & 0xffff0000;
code_r0x00107d1c:
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x107d24;
  func_0x(lVar25);
  if (((&stack0x00000053)[lVar15] != '\0') && (*plVar29 != 0)) {
    puVar16 = (ushort *)(*plVar29 + 0x62);
    *(ushort **)(&stack0x00001b78 + lVar15) = puVar16;
    uVar23 = *puVar16;
    *(ushort *)(&stack0x000002d8 + lVar15) = uVar23;
    if (((uVar23 & 0x400) == 0) || (*(short *)((longlong)plVar29 + 0xc) < 3)) {
      *(int *)(&stack0x00000128 + lVar15) = (int)*(short *)((longlong)plVar29 + 0xc);
      lVar25 = *plVar29;
      *(longlong *)(&stack0x000003f8 + lVar15) = lVar25;
      puVar18 = (undefined2 *)(lVar25 + 0x62);
      *(undefined2 **)(&stack0x00001b80 + lVar15) = puVar18;
      uVar12 = *puVar18;
      *(undefined2 *)(&stack0x000002e0 + lVar15) = uVar12;
      if (((byte)uVar12 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x00000128 + lVar15) == 3) {
          *(undefined4 *)(&stack0x00000128 + lVar15) = 4;
        }
        else if (*(int *)(&stack0x00000128 + lVar15) < 2) goto code_r0x00108003;
        *(uint **)(&stack0x00001b88 + lVar15) =
             (uint *)(*(longlong *)(&stack0x000003f8 + lVar15) + 100);
        uVar24 = *(uint *)(*(longlong *)(&stack0x000003f8 + lVar15) + 100);
        *(uint *)(&stack0x00000700 + lVar15) = uVar24;
        if ((((uVar24 & 8) != 0) &&
            (lVar25 = *(longlong *)(*(longlong *)(&stack0x000003f8 + lVar15) + 0x90), lVar25 != 0))
           && (*(longlong *)(&stack0x00001b90 + lVar15) = lVar25, *(longlong *)(lVar25 + 0x758) != 0
              )) {
          uVar20 = *(undefined8 *)(lVar25 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x108003;
          func_0x
                    (uVar20,*(undefined8 *)(&stack0x000003f8 + lVar15),
                     *(undefined4 *)(&stack0x00000128 + lVar15));
        }
      }
code_r0x00108003:
      (&stack0x000001a0)[lVar15] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar33 = (uint *)(*(longlong *)(&stack0x000003f8 + lVar15) + 100);
        *(uint **)(&stack0x00001b98 + lVar15) = puVar33;
        uVar24 = *puVar33;
        *(uint *)(&stack0x00000708 + lVar15) = uVar24;
        if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x00000128 + lVar15))) {
          *(uint **)(&stack0x00001ba0 + lVar15) = puVar33;
          uVar24 = *puVar33;
          *(uint *)(&stack0x00000710 + lVar15) = uVar24;
          if (((uVar24 & 0xc0000000) != 0x40000000) &&
             (lVar25 = **(longlong **)(&stack0x000003f8 + lVar15), lVar25 != 0)) {
            *(undefined4 *)(&stack0x00000da8 + lVar15) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x108096;
            iVar13 = (*_DAT_)(lVar25,0x2000,2,&stack0x00000dac + lVar15);
            if (iVar13 != 0) {
              LOCK();
              *puVar33 = *puVar33 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar33 = *puVar33 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar25 = *(longlong *)(&stack0x000003f8 + lVar15);
      uVar39 = *(undefined4 *)(&stack0x00000128 + lVar15);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1080c5;
      func_0x(lVar25 + 0x98,uVar39);
      if ((_DAT_ != 0) &&
         ((&stack0x000001a1)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1080ef;
        func_0x(lVar25,0,uVar39);
      }
      *(uint *)((longlong)plVar29 + 0xc) = *(uint *)((longlong)plVar29 + 0xc) & 0xffff0000;
      *plVar29 = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x107d79;
      func_0x(plVar29);
    }
  }
  if (*(longlong *)(&stack0x00000038 + lVar15) != 0) {
    puVar18 = (undefined2 *)(*(longlong *)(&stack0x00000038 + lVar15) + 0x62);
    *(undefined2 **)(&stack0x00001ba8 + lVar15) = puVar18;
    *(undefined2 *)(&stack0x000002e8 + lVar15) = *puVar18;
    if (((*(ushort *)(&stack0x000002e8 + lVar15) & 0x400) == 0) ||
       (*(short *)(&stack0x00000044 + lVar15) < 3)) {
      *(int *)(&stack0x00000130 + lVar15) = (int)*(short *)(&stack0x00000044 + lVar15);
      *(undefined8 *)(&stack0x00000928 + lVar15) = *(undefined8 *)(&stack0x00000038 + lVar15);
      *(undefined2 **)(&stack0x00001bb0 + lVar15) = puVar18;
      uVar12 = *puVar18;
      *(undefined2 *)(&stack0x000002f0 + lVar15) = uVar12;
      if (((byte)uVar12 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x00000130 + lVar15) == 3) {
          *(undefined4 *)(&stack0x00000130 + lVar15) = 4;
        }
        else if (*(int *)(&stack0x00000130 + lVar15) < 2) goto code_r0x001081f3;
        *(uint **)(&stack0x00001bb8 + lVar15) =
             (uint *)(*(longlong *)(&stack0x00000038 + lVar15) + 100);
        uVar24 = *(uint *)(*(longlong *)(&stack0x00000038 + lVar15) + 100);
        *(uint *)(&stack0x00000718 + lVar15) = uVar24;
        if ((((uVar24 & 8) != 0) &&
            (lVar25 = *(longlong *)(*(longlong *)(&stack0x00000038 + lVar15) + 0x90), lVar25 != 0))
           && (*(longlong *)(&stack0x00001bc0 + lVar15) = lVar25, *(longlong *)(lVar25 + 0x758) != 0
              )) {
          uVar20 = *(undefined8 *)(lVar25 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1081f3;
          func_0x
                    (uVar20,*(undefined8 *)(&stack0x00000038 + lVar15),
                     *(undefined4 *)(&stack0x00000130 + lVar15));
        }
      }
code_r0x001081f3:
      (&stack0x000001a2)[lVar15] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar33 = (uint *)(*(longlong *)(&stack0x00000928 + lVar15) + 100);
        *(uint **)(&stack0x00001bc8 + lVar15) = puVar33;
        uVar24 = *puVar33;
        *(uint *)(&stack0x00000720 + lVar15) = uVar24;
        if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x00000130 + lVar15))) {
          *(uint **)(&stack0x00001bd0 + lVar15) = puVar33;
          uVar24 = *puVar33;
          *(uint *)(&stack0x00000728 + lVar15) = uVar24;
          if (((uVar24 & 0xc0000000) != 0x40000000) &&
             (lVar25 = **(longlong **)(&stack0x00000928 + lVar15), lVar25 != 0)) {
            *(undefined4 *)(&stack0x00000db0 + lVar15) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x108286;
            iVar13 = (*_DAT_)(lVar25,0x2000,2,&stack0x00000db4 + lVar15);
            if (iVar13 != 0) {
              LOCK();
              *puVar33 = *puVar33 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar33 = *puVar33 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar25 = *(longlong *)(&stack0x00000928 + lVar15);
      uVar39 = *(undefined4 *)(&stack0x00000130 + lVar15);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1082b5;
      func_0x(lVar25 + 0x98,uVar39);
      if ((_DAT_ != 0) &&
         ((&stack0x000001a3)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1082df;
        func_0x(lVar25,0,uVar39);
      }
      *(uint *)(&stack0x00000044 + lVar15) = *(uint *)(&stack0x00000044 + lVar15) & 0xffff0000;
      *(undefined8 *)(&stack0x00000038 + lVar15) = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x108141;
      func_0x(&stack0x00000038 + lVar15);
    }
  }
  **(undefined4 **)(&stack0x00000d88 + lVar15) = 1;
  if (*plVar17 == 0) goto code_r0x001084ed;
  puVar16 = (ushort *)(*plVar17 + 0x62);
  *(ushort **)(&stack0x00001bd8 + lVar15) = puVar16;
  uVar23 = *puVar16;
  *(ushort *)(&stack0x000002f8 + lVar15) = uVar23;
  if (((uVar23 & 0x400) != 0) && (2 < *(short *)((longlong)plVar17 + 0xc))) {
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x108331;
    func_0x(plVar17);
    goto code_r0x001084ed;
  }
  *(int *)(&stack0x00000138 + lVar15) = (int)*(short *)((longlong)plVar17 + 0xc);
  lVar25 = *plVar17;
  *(longlong *)(&stack0x00000400 + lVar15) = lVar25;
  puVar18 = (undefined2 *)(lVar25 + 0x62);
  *(undefined2 **)(&stack0x00001be0 + lVar15) = puVar18;
  uVar12 = *puVar18;
  *(undefined2 *)(&stack0x00000300 + lVar15) = uVar12;
  if (((byte)uVar12 >> 3 & 1) != 0) {
    if (*(int *)(&stack0x00000138 + lVar15) == 3) {
      *(undefined4 *)(&stack0x00000138 + lVar15) = 4;
    }
    else if (*(int *)(&stack0x00000138 + lVar15) < 2) goto code_r0x001083f5;
    *(uint **)(&stack0x00001be8 + lVar15) = (uint *)(*(longlong *)(&stack0x00000400 + lVar15) + 100)
    ;
    uVar24 = *(uint *)(*(longlong *)(&stack0x00000400 + lVar15) + 100);
    *(uint *)(&stack0x00000730 + lVar15) = uVar24;
    if ((((uVar24 & 8) != 0) &&
        (lVar25 = *(longlong *)(*(longlong *)(&stack0x00000400 + lVar15) + 0x90), lVar25 != 0)) &&
       (*(longlong *)(&stack0x00001bf0 + lVar15) = lVar25, *(longlong *)(lVar25 + 0x758) != 0)) {
      uVar20 = *(undefined8 *)(lVar25 + 0x758);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1083f5;
      func_0x
                (uVar20,*(undefined8 *)(&stack0x00000400 + lVar15),
                 *(undefined4 *)(&stack0x00000138 + lVar15));
    }
  }
code_r0x001083f5:
  (&stack0x000001a4)[lVar15] = DAT_ >> 7;
  if ((char)DAT_ < '\0') {
    puVar33 = (uint *)(*(longlong *)(&stack0x00000400 + lVar15) + 100);
    *(uint **)(&stack0x00001bf8 + lVar15) = puVar33;
    uVar24 = *puVar33;
    *(uint *)(&stack0x00000738 + lVar15) = uVar24;
    if (((uVar24 & 8) != 0) && (2 < *(int *)(&stack0x00000138 + lVar15))) {
      *(uint **)(&stack0x00001c00 + lVar15) = puVar33;
      uVar24 = *puVar33;
      *(uint *)(&stack0x00000740 + lVar15) = uVar24;
      if (((uVar24 & 0xc0000000) != 0x40000000) &&
         (lVar25 = **(longlong **)(&stack0x00000400 + lVar15), lVar25 != 0)) {
        *(undefined4 *)(&stack0x00000db8 + lVar15) = 2;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x108488;
        iVar13 = (*_DAT_)(lVar25,0x2000,2,&stack0x00000dbc + lVar15);
        if (iVar13 != 0) {
          LOCK();
          *puVar33 = *puVar33 & 0x3fffffff;
          UNLOCK();
          LOCK();
          *puVar33 = *puVar33 | 0x40000000;
          UNLOCK();
        }
      }
    }
  }
  lVar25 = *(longlong *)(&stack0x00000400 + lVar15);
  uVar39 = *(undefined4 *)(&stack0x00000138 + lVar15);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1084b7;
  func_0x(lVar25 + 0x98,uVar39);
  if ((_DAT_ != 0) &&
     ((&stack0x000001a5)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1084e1;
    func_0x(lVar25,0,uVar39);
  }
  *(uint *)((longlong)plVar17 + 0xc) = *(uint *)((longlong)plVar17 + 0xc) & 0xffff0000;
  *plVar17 = 0;
code_r0x001084ed:
  *plVar17 = *(longlong *)(&stack0x00000058 + lVar15);
  *(uint *)((longlong)plVar17 + 0xc) = *(uint *)((longlong)plVar17 + 0xc) & 0xffff0000;
  *(uint *)((longlong)plVar17 + 0xc) =
       *(uint *)((longlong)plVar17 + 0xc) | (uint)*(ushort *)(&stack0x00000064 + lVar15);
  *(undefined8 *)(&stack0x00000058 + lVar15) = 0;
  *(uint *)(&stack0x00000064 + lVar15) = *(uint *)(&stack0x00000064 + lVar15) & 0xffff0000;
  lVar26 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar25 = *(longlong *)(lVar26 + 0x100);
  if (lVar25 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10854e;
    (*_DAT_)();
    lVar25 = *(longlong *)(lVar26 + 0x100);
  }
  if (*(int *)(lVar25 + 0x22c) != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x108564;
    (*pcRam0000000001603cc0)();
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x108572;
  func_0x(&stack0x00000058 + lVar15);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10857d;
  func_0x(&stack0x00000038 + lVar15);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10858d;
  func_0x
            (*(ulonglong *)(&stack0x00003348 + lVar15) ^
             (ulonglong)(&stack0xffffffffffffffc8 + lVar15));
  return;
}

