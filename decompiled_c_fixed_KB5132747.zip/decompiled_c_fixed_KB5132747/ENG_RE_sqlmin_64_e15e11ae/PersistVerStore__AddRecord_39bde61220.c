
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1,longlong *param_2,undefined8 param_3,short *param_4,
                 undefined8 *param_5,ulonglong param_6,undefined8 param_7,undefined8 param_8,
                 undefined4 *param_9)

{
  ushort *puVar1;
  short sVar2;
  byte *pbVar3;
  bool bVar4;
  ushort *puVar5;
  char cVar6;
  byte bVar7;
  ushort uVar8;
  ushort uVar9;
  int iVar10;
  undefined4 uVar11;
  longlong *plVar12;
  undefined8 uVar13;
  longlong *plVar14;
  uint uVar15;
  uint uVar16;
  undefined4 uVar17;
  longlong lVar18;
  longlong lVar19;
  uint uVar20;
  uint uVar21;
  undefined2 uVar22;
  uint uVar23;
  ulonglong uVar24;
  ushort *puVar25;
  undefined8 uVar26;
  longlong unaff_GS_OFFSET;
  undefined8 uVar27;
  ulonglong uVar28;
  undefined8 in_stack_fffffffffffffaf8;
  undefined8 in_stack_fffffffffffffb00;
  undefined4 uVar29;
  undefined8 in_stack_fffffffffffffb08;
  undefined4 uVar30;
  ulonglong uStack_4d8;
  int iStack_4d0;
  undefined8 uStack_4c8;
  undefined8 uStack_4c0;
  undefined8 uStack_4b8;
  uint uStack_4b0;
  ushort uStack_4aa;
  uint uStack_4a8;
  ulonglong *puStack_4a0;
  int iStack_498;
  short sStack_494;
  undefined8 *puStack_490;
  int iStack_488;
  int iStack_480;
  int iStack_478;
  short sStack_474;
  longlong *plStack_468;
  undefined8 uStack_460;
  longlong lStack_458;
  longlong lStack_450;
  undefined8 uStack_448;
  int iStack_440;
  undefined4 uStack_43c;
  int iStack_438;
  undefined4 uStack_434;
  undefined4 uStack_430;
  undefined4 uStack_428;
  int iStack_424;
  undefined4 uStack_420;
  undefined auStack_418 [8];
  longlong lStack_410;
  longlong lStack_408;
  longlong lStack_400;
  undefined4 uStack_3f8;
  undefined4 uStack_3f4;
  longlong lStack_3f0;
  char cStack_3e8;
  undefined4 uStack_3b8;
  undefined8 uStack_3b0;
  undefined8 uStack_3a8;
  undefined8 uStack_3a0;
  undefined8 uStack_398;
  longlong lStack_390;
  undefined4 *puStack_388;
  longlong lStack_380;
  longlong lStack_378;
  undefined8 uStack_370;
  longlong lStack_368;
  longlong *plStack_360;
  longlong *plStack_358;
  longlong lStack_350;
  longlong lStack_348;
  longlong lStack_340;
  undefined8 uStack_338;
  longlong lStack_330;
  uint *puStack_328;
  undefined2 *puStack_320;
  uint **ppuStack_318;
  longlong lStack_308;
  undefined8 uStack_300;
  longlong lStack_2f8;
  longlong *plStack_2f0;
  longlong *plStack_2e8;
  longlong lStack_2e0;
  longlong lStack_2d8;
  undefined auStack_2d0 [40];
  undefined auStack_2a8 [8];
  undefined2 uStack_2a0;
  undefined2 uStack_29e;
  undefined4 uStack_298;
  uint **ppuStack_290;
  undefined *puStack_288;
  undefined8 uStack_280;
  uint *puStack_278;
  undefined4 uStack_270;
  undefined2 uStack_26c;
  undefined2 uStack_26a;
  undefined auStack_268 [528];
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  uint auStack_48 [4];
  
  uStack_338 = 0xfffffffffffffffe;
  if ((*(byte *)(param_2 + 0x43) & 4) == 0) {
    plVar12 = param_2 + 5;
  }
  else {
    lVar19 = (**(code **)(*param_2 + 0x1e8))(param_2);
    plVar12 = (longlong *)(lVar19 + 0x28);
  }
  iStack_4d0 = *(int *)plVar12;
  sVar2 = *(short *)((longlong)plVar12 + 4);
  puVar1 = (ushort *)(param_4 + 1);
  if (*param_4 == 0) {
    func_0x();
  }
  else {
    func_0x(puVar1,&iStack_498);
  }
  uStack_3b8 = 0x400514;
  plVar12 = (longlong *)0x0;
  uVar11 = 0;
  uVar17 = 0;
  uStack_3b0 = 0;
  uStack_3a0 = 0;
  uStack_3a8 = 0;
  uStack_398 = 0;
  puStack_490 = param_1 + 0xd;
  iStack_488 = 0;
  uStack_4b8 = (ulonglong)uStack_4b8._4_4_ << 0x20;
  iVar10 = func_0x(puStack_490,1,0xffffffff);
  if (iVar10 == 0) {
    iStack_488 = 1;
  }
  else if (iVar10 == 2) {
    func_0x(0xfb);
  }
  else {
    (*_DAT_)(1,0x111dc08,0x10d6648,0x7f9,0);
  }
  if (((*param_4 != 0) && (*(longlong **)(param_4 + 8) != (longlong *)0x0)) &&
     (**(longlong **)(param_4 + 8) != 0)) {
    (*_DAT_)(1,0x111dbe8,0x10d6648,0x7ff,0);
  }
  lVar19 = *(longlong *)
            ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            8);
  if (lVar19 == 0) {
    lStack_450 = 0;
LAB_:
    lStack_458 = 0;
  }
  else {
    lStack_450 = *(longlong *)(lVar19 + 0x60);
    if (lStack_450 == 0) goto LAB_;
    lStack_458 = *(longlong *)(lStack_450 + 0x4d8);
    if (lStack_458 != 0) {
      *(undefined8 *)(lStack_450 + 0x4d8) = 0;
    }
  }
  if ((*(char *)((longlong)param_1 + 0x134) == '\0') &&
     (cVar6 = func_0x(param_1), cVar6 == '\0')) {
    *(undefined *)((longlong)param_1 + 0x134) = 1;
  }
  uVar30 = (undefined4)((ulonglong)in_stack_fffffffffffffb08 >> 0x20);
  uVar20 = (uint)((ulonglong)in_stack_fffffffffffffaf8 >> 0x20);
  uVar29 = (undefined4)((ulonglong)in_stack_fffffffffffffb00 >> 0x20);
  if ((*(char *)((longlong)param_1 + 0x13c) == '\0') ||
     (bVar4 = true, *(char *)((longlong)param_1 + 0x134) == '\0')) {
    bVar4 = false;
  }
  lVar19 = param_2[0x1a];
  uStack_4d8 = param_6;
  if (param_6 == 0) {
    if (((lVar19 == 0) || (*(char *)(lVar19 + 0x34) == '\0')) || (*(longlong *)(lVar19 + 0x40) == 0)
       ) {
      uStack_4d8 = 0;
    }
    else {
      LOCK();
      plVar14 = (longlong *)(lVar19 + 0x128);
      lVar19 = *plVar14;
      *plVar14 = *plVar14 + 1;
      UNLOCK();
      uStack_4d8 = lVar19 + 1;
    }
    puStack_4a0 = *(ulonglong **)(param_4 + 4);
    uVar15 = *(uint *)(param_4 + 2);
    uVar24 = (ulonglong)uVar15;
    if (*param_4 == 0) {
      uVar17 = 0;
      if (uVar15 == 0) {
        *puVar1 = 0;
        uVar15 = *(uint *)(param_4 + 8);
        uVar24 = (ulonglong)uVar15;
        *(uint *)(param_4 + 10) = uVar15;
        pbVar3 = *(byte **)(param_4 + 4);
        bVar7 = *pbVar3;
        if ((bVar7 & 0x10) != 0) {
          uVar15 = uVar15 + 2 + (*(ushort *)(pbVar3 + uVar24) + 7 >> 3);
          uVar24 = (ulonglong)uVar15;
          *(uint *)(param_4 + 10) = uVar15;
          bVar7 = *pbVar3;
        }
        if ((bVar7 & 0x20) == 0) {
          *(int *)(param_4 + 2) = (int)uVar24;
          param_4[0xe] = 0;
          *(int *)(param_4 + 0xc) = (int)uVar24;
        }
        else {
          puVar25 = (ushort *)(pbVar3 + uVar24);
          uVar8 = *puVar25;
          param_4[0xe] = uVar8;
          uStack_4c0 = puVar25;
          if (uVar8 == 0) {
            cVar6 = func_0x(0x165ff40);
            if ((cVar6 != '\0') && (cVar6 = func_0x(), cVar6 != '\0')) {
              cVar6 = func_0x(0x165ff40);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15);
              }
              else {
                (*_DAT_)(1,0xf4f94c,0x106fa38,0x80f,0);
              }
            }
            func_0x(*(undefined8 *)(param_4 + 4),3);
            uVar8 = param_4[0xe];
            uVar24 = (ulonglong)*(uint *)(param_4 + 10);
          }
          uVar15 = (uint)uVar8;
          uVar20 = (int)uVar24 + (uVar15 + 1) * 2;
          *(uint *)(param_4 + 0xc) = uVar20;
          if (0x1f9e < uVar20) {
            cVar6 = func_0x(0x165ff40);
            if ((cVar6 != '\0') && (cVar6 = func_0x(), cVar6 != '\0')) {
              cVar6 = func_0x(0x165ff40);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15);
              }
              else {
                (*_DAT_)(1,0xf4f94c,0x106fa38,0x816,0);
              }
            }
            func_0x(*(undefined8 *)(param_4 + 4),4);
            uVar15 = (uint)(ushort)param_4[0xe];
            uVar20 = *(uint *)(param_4 + 0xc);
          }
          uVar16 = puVar25[uVar15] & 0x7fff;
          *(uint *)(param_4 + 2) = uVar16;
          if (uVar16 < uVar20) {
            cVar6 = func_0x(0x165ff40);
            if ((cVar6 != '\0') && (cVar6 = func_0x(), cVar6 != '\0')) {
              cVar6 = func_0x(0x165ff40);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15);
              }
              else {
                (*_DAT_)(1,0xf4f94c,0x106fa38,0x81d,0);
              }
            }
            func_0x(*(undefined8 *)(param_4 + 4),4);
            uVar20 = *(uint *)(param_4 + 0xc);
            uVar15 = (uint)(ushort)param_4[0xe];
            uVar16 = *(uint *)(param_4 + 2);
          }
          plVar14 = plVar12;
          uVar17 = 0;
          if ((short)uVar15 != 0) {
            do {
              puVar25 = puVar25 + 1;
              uVar23 = *puVar25 & 0x7fff;
              if ((uVar23 < uVar20) || (uVar16 = *(uint *)(param_4 + 2), uVar16 < uVar23)) {
                cVar6 = func_0x(0x165ff40);
                if ((cVar6 != '\0') && (cVar6 = func_0x(), cVar6 != '\0')) {
                  cVar6 = func_0x(0x165ff40);
                  if (cVar6 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15);
                  }
                  else {
                    (*_DAT_)(1,0xf4f94c,0x106fa38,0x82a,0);
                  }
                }
                func_0x(*(undefined8 *)(param_4 + 4),4);
                uVar16 = *(uint *)(param_4 + 2);
              }
              uVar21 = (int)plVar14 + 1;
              uVar15 = (uint)(ushort)param_4[0xe];
              plVar14 = (longlong *)(ulonglong)uVar21;
              uVar20 = uVar23;
            } while ((int)uVar21 < (int)uVar15);
            puVar25 = uStack_4c0;
            uVar17 = (int)uStack_4b8;
          }
          puVar5 = uStack_4c0;
          uVar30 = (undefined4)((ulonglong)in_stack_fffffffffffffb08 >> 0x20);
          uVar20 = (uint)((ulonglong)in_stack_fffffffffffffaf8 >> 0x20);
          uVar29 = (undefined4)((ulonglong)in_stack_fffffffffffffb00 >> 0x20);
          uVar24 = (ulonglong)uVar16;
          if ((short)puVar25[(ulonglong)(uVar15 - 1) + 1] < 0) {
            lVar19 = *(longlong *)(param_4 + 4);
LAB_:
            uVar16 = *(ushort *)
                      ((ulonglong)*(uint *)(param_4 + 10) + lVar19 + (ulonglong)uVar15 * 2) & 0x7fff
            ;
            if (uVar15 == 1) {
              uVar15 = *(uint *)(param_4 + 0xc);
              uVar23 = uVar15;
LAB_:
              if ((uVar16 < uVar15) || (uVar21 = *(uint *)(param_4 + 2), uVar21 < uVar16))
              goto LAB_;
            }
            else {
              uVar15 = *(ushort *)
                        ((ulonglong)*(uint *)(param_4 + 10) + lVar19 + -2 + (ulonglong)uVar15 * 2) &
                       0x7fff;
              uVar23 = *(uint *)(param_4 + 0xc);
              if (uVar23 <= uVar15) goto LAB_;
LAB_:
              func_0x(lVar19,7);
              uVar23 = *(uint *)(param_4 + 0xc);
              uVar21 = *(uint *)(param_4 + 2);
            }
            uVar30 = (undefined4)((ulonglong)in_stack_fffffffffffffb08 >> 0x20);
            uVar20 = (uint)((ulonglong)in_stack_fffffffffffffaf8 >> 0x20);
            uVar29 = (undefined4)((ulonglong)in_stack_fffffffffffffb00 >> 0x20);
            uVar24 = (ulonglong)uVar21;
            if ((uVar23 <= uVar15) && (uVar15 <= uVar21)) {
              lVar19 = *(longlong *)(param_4 + 4);
              if (*(ushort *)((ulonglong)uVar15 + lVar19) == 5) {
                *puVar1 = *puVar1 | 2;
                param_4[0xe] = param_4[0xe] + -1;
                uVar24 = (ulonglong)(uVar15 & 0xffff);
                param_4[0x15] = (short)uVar15;
                uVar8 = *(ushort *)(uVar24 + 2 + lVar19);
                uVar9 = param_4[0x16] & 0xc7ff;
                if ((uVar8 & 0x4000) != 0) {
                  uVar9 = uVar8 & 0x3800 | uVar9;
                }
                param_4[0x16] = uVar9;
                uVar8 = (uVar9 ^ *(ushort *)(uVar24 + 2 + lVar19)) & 0x7ff ^ uVar9;
                param_4[0x16] = uVar8;
                uVar28 = *(ulonglong *)(param_4 + 4);
                uStack_4b8 = uVar28 + (uVar9 >> 0xb & 7) * 2 + (ulonglong)((uVar8 & 0x7ff) * 2) + 4
                             + uVar24;
                if (uStack_4b8 < uVar24 + uVar28) {
                  func_0x(uVar24 + uVar28,0x19);
                  uVar8 = param_4[0x16];
                  uVar24 = (ulonglong)(ushort)param_4[0x15];
                  uVar28 = (ulonglong)*(uint *)(param_4 + 4);
                }
                if (uVar16 - uVar15 <
                    (((uVar8 & 0x7ff) * 2 - (int)uVar24) - (int)uVar28) + (int)uStack_4b8) {
                  func_0x(uVar24 + *(longlong *)(param_4 + 4),0x19);
                  uVar8 = param_4[0x16];
                }
                uVar30 = (undefined4)((ulonglong)in_stack_fffffffffffffb08 >> 0x20);
                uVar20 = (uint)((ulonglong)in_stack_fffffffffffffaf8 >> 0x20);
                uVar29 = (undefined4)((ulonglong)in_stack_fffffffffffffb00 >> 0x20);
                if (((uVar8 & 0x3800) != 0) &&
                   (puVar25 = (ushort *)
                              (*(longlong *)(param_4 + 4) + 4 + (ulonglong)(ushort)param_4[0x15]),
                   plVar14 = plVar12, (uVar8 & 0x3800) != 0)) {
                  do {
                    if ((uVar8 & 0x7ff) < (*puVar25 & 0x7ff)) {
                      func_0x((ulonglong)(ushort)param_4[0x15] + *(longlong *)(param_4 + 4),
                                      0x1a);
                      uVar8 = param_4[0x16];
                    }
                    uVar30 = (undefined4)((ulonglong)in_stack_fffffffffffffb08 >> 0x20);
                    uVar20 = (uint)((ulonglong)in_stack_fffffffffffffaf8 >> 0x20);
                    uVar29 = (undefined4)((ulonglong)in_stack_fffffffffffffb00 >> 0x20);
                    uVar15 = (int)plVar14 + 1;
                    puVar25 = puVar25 + 1;
                    plVar14 = (longlong *)(ulonglong)uVar15;
                  } while ((int)uVar15 < (int)(uVar8 >> 0xb & 7));
                }
                uVar24 = (ulonglong)*(uint *)(param_4 + 2);
              }
              else if (0x3ff < *(ushort *)((ulonglong)uVar15 + lVar19)) goto code_r0x0010061b;
              goto LAB_;
            }
            goto LAB_;
          }
        }
LAB_:
        if ((**(byte **)(param_4 + 4) & 0x40) == 0) {
          *(undefined4 *)(param_4 + 0x13) = 0;
        }
        else {
          *(int *)(param_4 + 0x13) = (int)uVar24;
          *(int *)(param_4 + 2) = (int)uVar24 + 0xe;
          uVar13 = func_0x(puVar1);
          func_0x(uVar13,auStack_418);
          iVar10 = func_0x(auStack_418);
          *(int *)(param_4 + 2) = *(int *)(param_4 + 2) + iVar10;
          uVar24 = (ulonglong)*(uint *)(param_4 + 2);
        }
        if ((*(ulonglong *)(param_4 + 0xf) != 0) &&
           (*(ulonglong *)(param_4 + 0xf) < uVar24 + *(longlong *)(param_4 + 4))) {
          cVar6 = func_0x(0x165ff40);
          if ((cVar6 != '\0') && (cVar6 = func_0x(), cVar6 != '\0')) {
            cVar6 = func_0x(0x165ff40);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15);
            }
            else {
              (*_DAT_)(1,0xf4f94c,0x106fa38,0x886,0);
            }
          }
          func_0x(*(undefined8 *)(param_4 + 4),0x12);
          uVar24 = (ulonglong)*(uint *)(param_4 + 2);
        }
        if (((uint)uVar24 == 0) || (0x3f3c < (uint)uVar24)) {
          cVar6 = func_0x(0x165ff40);
          if ((cVar6 != '\0') && (cVar6 = func_0x(), cVar6 != '\0')) {
            cVar6 = func_0x(0x165ff40);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15);
            }
            else {
              (*_DAT_)(1,0xf4f94c,0x106fa38,0x88b,0);
            }
          }
          func_0x(*(undefined8 *)(param_4 + 4),5);
          uVar24 = (ulonglong)*(uint *)(param_4 + 2);
        }
      }
LAB_:
      if (((uint)uVar24 < 9) &&
         (((**(byte **)(param_4 + 4) & 0xe) == 0 || ((**(byte **)(param_4 + 4) & 0xe) == 0xc)))) {
        uVar24 = 9;
      }
    }
    else {
      if (uVar15 == 0) {
        func_0x(puVar1);
        uVar24 = (ulonglong)*(uint *)(param_4 + 2);
      }
      uVar17 = uVar11;
      if (((uint)uVar24 < 9) &&
         (((**(byte **)(param_4 + 4) & 0x1c) == 0 || ((**(byte **)(param_4 + 4) & 0x1c) == 0xc)))) {
        uVar24 = 9;
      }
    }
    uVar8 = 9;
    uVar24 = uVar24 & 0xffff;
    uStack_4b8 = CONCAT44(uStack_4b8._4_4_,(int)uVar24);
    if (*param_4 == 0) {
      uVar15 = *(uint *)(param_4 + 8);
      uStack_4c0 = (ushort *)CONCAT44(uStack_4c0._4_4_,uVar15);
      func_0x(puVar1,&uStack_4b0);
    }
    else {
      if ((**(byte **)(param_4 + 4) & 0x1c) == 4) {
        uVar8 = 1;
      }
      else if ((**(byte **)(param_4 + 4) & 0x1c) != 0x10) {
        uVar8 = param_4[0xe] + param_4[0xd];
      }
      uVar15 = (uint)uVar8;
      uStack_4c0 = (ushort *)CONCAT44(uStack_4c0._4_4_,uVar15);
      func_0x(puVar1,&uStack_4b0);
    }
    uVar22 = (undefined2)uVar15;
    if ((sVar2 == sStack_494) && (iStack_4d0 == iStack_498)) {
      uVar16 = (uint)(int)(short)uStack_4aa >> 0xe & 1;
      uVar15 = (uint)(int)(short)uStack_4aa >> 0xd & 1;
      uVar8 = uStack_4aa;
      if (uVar15 != uVar16) {
        if ((uStack_4aa & 0x4000) == 0) {
          uVar8 = uStack_4aa & 0xdfff;
        }
        else {
          uVar8 = uStack_4aa | 0x2000;
        }
      }
      if (uVar8 != 0xfffc) {
        if ((uStack_4b0 & 0x80000000) != 0) {
          uVar8 = uStack_4aa;
          if (uVar15 != uVar16) {
            if ((uStack_4aa & 0x4000) == 0) {
              uVar8 = uStack_4aa & 0xdfff;
            }
            else {
              uVar8 = uStack_4aa | 0x2000;
            }
          }
          if (uVar8 == 0xfffc) {
            (*_DAT_)(1,0x10fa6e0,0x10d3e50,0x4ec,0);
          }
          cVar6 = func_0x(&uStack_4b0);
          if (((cVar6 == '\0') && (cVar6 = func_0x(&uStack_4b0), cVar6 == '\0')) &&
             (((uint)(int)(short)uStack_4aa >> 0xc & 1) != 0)) goto LAB_;
        }
        cVar6 = func_0x(param_8);
        if (cVar6 == '\0') {
          uStack_4d8 = uStack_4d8 | 0x2000000000000;
        }
        goto LAB_;
      }
    }
LAB_:
    uStack_4d8 = uStack_4d8 | 0x1000000000000;
  }
  else {
    puStack_4a0 = &uStack_4d8;
    uVar24 = 8;
    uStack_4b8 = CONCAT44(uStack_4b8._4_4_,8);
    uVar22 = 8;
    uStack_4c0 = (ushort *)CONCAT44(uStack_4c0._4_4_,8);
  }
LAB_:
  if (param_5 == (undefined8 *)0x0) {
    uStack_4c8 = 0;
  }
  else {
    uStack_4c8 = *param_5;
    uVar17 = *(undefined4 *)(param_5 + 1);
  }
  cVar6 = (**(code **)(*param_2 + 0x88))(param_2);
  uVar13 = _DAT_;
  if (cVar6 == '\0') {
    uVar13 = _DAT_;
  }
  uVar28 = 0;
  func_0x(auStack_2d0,0xb,0,0,uVar13,0);
  lStack_308 = param_1[2];
  if ((((*(byte *)(*(longlong *)(lStack_308 + 0x6b0) + 0x3c) & 1) != 0) &&
      (*(longlong *)(*(longlong *)(lStack_308 + 0x6b0) + 0x280) == 0)) &&
     (cVar6 = (**(code **)(*param_2 + 0x88))(param_2), cVar6 != '\0')) {
    if ((DAT_ >> 3 & 1) != 0) {
LAB_:
      puStack_388 = param_9;
      *param_9 = 0;
      *(undefined2 *)(param_9 + 1) = 0;
      *(undefined2 *)((longlong)param_9 + 6) = 0xffff;
      func_0x(auStack_2d0);
      if ((lStack_450 != 0) && (lStack_458 != 0)) {
        *(longlong *)(lStack_450 + 0x4d8) = lStack_458;
      }
      if (iStack_488 == 0) {
        return;
      }
      (*_DAT_)(puStack_490);
      return;
    }
    uStack_420 = 0x58;
    lStack_2f8 = *(longlong *)(unaff_GS_OFFSET + 0x58);
    plStack_2f0 = (longlong *)
                  ((ulonglong)*_DAT_ +
                  *(longlong *)(lStack_2f8 + (ulonglong)*_DAT_ * 8));
    lStack_2e0 = *plStack_2f0;
    plStack_2e8 = plStack_2f0;
    lStack_2d8 = lStack_2e0;
    if ((lStack_2e0 == 0) ||
       (lStack_410 = **(longlong **)(lStack_2e0 + 0x38), lStack_390 = lStack_410, lStack_410 == 0))
    {
      lStack_410 = 0;
    }
    else {
      iStack_438 = (*_DAT_)(lStack_410,0x1b23);
      if (iStack_438 != 0) goto LAB_;
    }
  }
  if (bVar4) {
    func_0x(param_1,param_2,param_8,param_3,puStack_4a0,uVar24,uVar22,uStack_4d8,&uStack_4c8
                    ,CONCAT44(uVar29,uVar17),param_7,param_9);
    goto LAB_;
  }
  func_0x(&lStack_3f0);
  uStack_434 = 0x58;
  lStack_380 = *(longlong *)(unaff_GS_OFFSET + 0x58);
  lVar19 = (ulonglong)*_DAT_ + *(longlong *)(lStack_380 + (ulonglong)*_DAT_ * 8);
  lStack_408 = *(longlong *)(lVar19 + 0x100);
  lStack_378 = lVar19;
  if (lStack_408 == 0) {
    (*_DAT_)(0);
    lStack_408 = *(longlong *)(lVar19 + 0x100);
  }
  uVar15 = *(uint *)(*(longlong *)(lStack_408 + 0x260) + 0xe68);
  uVar13 = *(undefined8 *)(param_1[5] + ((ulonglong)uVar15 % (ulonglong)*(uint *)(param_1 + 9)) * 8)
  ;
  iStack_440 = 0;
  uStack_43c = 4;
  uStack_430 = 4;
  uVar11 = 0;
  uStack_4a8 = uVar15;
  uStack_460 = uVar13;
  uStack_448 = uVar13;
  uStack_370 = uVar13;
  iStack_480 = func_0x
                         (uVar13,4,0xffffffff,0,0,uVar28 & 0xffffffff00000000,0,0,
                          (ulonglong)uVar20 << 0x20);
  plVar14 = *(longlong **)(param_1[6] + ((ulonglong)uVar15 % (ulonglong)*(uint *)(param_1 + 9)) * 8)
  ;
  plStack_468 = plVar14;
  iStack_440 = iStack_480;
  if (*plVar14 == 0) {
    if ((DAT_ >> 2 & 1) == 0) {
      uStack_428 = 0x58;
      lStack_368 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      plStack_360 = (longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)(lStack_368 + (ulonglong)*_DAT_ * 8));
      lStack_350 = *plStack_360;
      plStack_358 = plStack_360;
      lStack_348 = lStack_350;
      if ((lStack_350 == 0) ||
         (lStack_400 = **(longlong **)(lStack_350 + 0x38), lStack_340 = lStack_400, lStack_400 == 0)
         ) {
        lStack_400 = 0;
        uVar13 = uStack_460;
      }
      else {
        iStack_424 = (*_DAT_)(lStack_400,0xf8a);
        plVar14 = plStack_468;
        uVar13 = uStack_460;
        if (iStack_424 != 0) goto LAB_;
      }
    }
    else {
LAB_:
      plVar14 = plStack_468;
      uVar26 = 0xf62ef0;
      if (*(char *)((longlong)param_1 + 0x4c) != '\0') {
        uVar26 = 0xec7248;
      }
      uVar27 = param_1[1];
      func_0x(0xfe1140,*(undefined2 *)(param_1[2] + 0x6b8),uVar26,uStack_4a8,uVar27);
      uVar11 = (undefined4)((ulonglong)uVar27 >> 0x20);
    }
    uVar26 = 0xf62ef0;
    uStack_3f8 = 0x1f;
    uStack_3f4 = 0x4000000;
    if ((_DAT_ & 0x4000000) != 0) {
      if (*(char *)((longlong)param_1 + 0x4c) != '\0') {
        uVar26 = 0xec7248;
      }
      func_0x(*(undefined2 *)(param_1[2] + 0x6b8),*(longlong *)(param_1[2] + 0x6b0) + 0x3a8,
                      0xfe1a50,uVar26,CONCAT44(uVar11,uStack_4a8),param_1[1]);
    }
    func_0x(plVar14,*param_1,param_1[0xc],param_1[1],param_1);
  }
  iStack_478 = iStack_4d0;
  sStack_474 = sVar2;
  uVar11 = (**(code **)(*param_2 + 0x50))(param_2);
  func_0x(plVar14,&iStack_478,param_8,uVar11,param_3,puStack_4a0,uStack_4b8 & 0xffff,
                  (ulonglong)uStack_4c0 & 0xffff,uStack_4d8,&uStack_4c8,CONCAT44(uVar30,uVar17),
                  param_9);
  if (iStack_480 != 0) {
    iStack_4d0 = 4;
    uStack_300 = uVar13;
    func_0x(uVar13,4);
    iStack_440 = 0;
  }
  if (cStack_3e8 != '\0') {
    lStack_330 = lStack_3f0;
    puStack_328 = (uint *)(lStack_3f0 + 800);
    *puStack_328 = *puStack_328 | 0x1000000;
  }
LAB_:
  puStack_4a0 = (ulonglong *)0x80000000000001f;
  if ((_DAT_ & 0x8000000) != 0) {
    puStack_320 = &uStack_2a0;
    uStack_2a0 = 0;
    uStack_29e = 1;
    uStack_298 = 0;
    ppuStack_290 = &puStack_278;
    puStack_288 = auStack_268;
    uStack_58 = 0;
    uStack_54 = 0;
    uStack_280 = 0;
    uStack_50 = 0;
    ppuStack_318 = &puStack_278;
    puStack_278 = auStack_48;
    uStack_270 = 4;
    uStack_26c = 0;
    uStack_26a = 0;
    auStack_48[0] = (uint)*(ushort *)(param_1[2] + 0x6b8);
    func_0x(auStack_2a8);
  }
  if (*(char *)((longlong)param_1 + 0x134) == '\0') {
    *(undefined *)((longlong)param_1 + 0x134) = 1;
  }
  func_0x(auStack_2d0);
  lVar18 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar19 = *(longlong *)(lVar18 + 0x100);
  if (lVar19 == 0) {
    (*_DAT_)();
    lVar19 = *(longlong *)(lVar18 + 0x100);
  }
  if (*(int *)(lVar19 + 0x22c) != 0) {
    (*_DAT_)();
  }
  if (*_DAT_ != '\0') {
    if (((*(longlong *)(&DAT_ + (ulonglong)(*(ushort *)(param_1[2] + 0x6b8) >> 8) * 8) != 0)
        && (plVar14 = (longlong *)
                      (*(longlong *)
                        (&DAT_ + (ulonglong)(*(ushort *)(param_1[2] + 0x6b8) >> 8) * 8) +
                       (ulonglong)(*(ushort *)(param_1[2] + 0x6b8) & 0xff) * 8 + 0x2800),
           plVar14 != (longlong *)0x0)) && (*plVar14 != 0)) {
      LOCK();
      *(longlong *)(*plVar14 + 0x2a0) = *(longlong *)(*plVar14 + 0x2a0) + 1;
      UNLOCK();
      if ((DAT_ & 0x20) != 0) {
        if (_DAT_ != 0) {
          plVar12 = (longlong *)(_DAT_ + 0x2800);
        }
        if ((plVar12 != (longlong *)0x0) && (*plVar12 != 0)) {
          LOCK();
          plVar12 = (longlong *)(*plVar12 + 0x2a0);
          *plVar12 = *plVar12 + 1;
          UNLOCK();
        }
      }
    }
  }
  if ((lStack_450 != 0) && (lStack_458 != 0)) {
    *(longlong *)(lStack_450 + 0x4d8) = lStack_458;
  }
  if (iStack_488 != 0) {
    (*_DAT_)(puStack_490);
  }
  return;
code_r0x0010061b:
  *puVar1 = *puVar1 | 1;
  uVar8 = param_4[0xe] - 1;
  param_4[0xe] = uVar8;
  if ((uVar8 == 0) || (uVar15 = (uint)uVar8, -1 < (short)puVar5[(ulonglong)(uVar8 - 1) + 1]))
  goto LAB_;
  goto LAB_;
}

