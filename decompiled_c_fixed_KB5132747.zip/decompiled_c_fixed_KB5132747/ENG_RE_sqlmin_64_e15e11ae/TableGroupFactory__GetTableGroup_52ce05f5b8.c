
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,ulonglong **param_2,ulonglong param_3,undefined8 param_4)

{
  undefined uVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char cVar6;
  uint uVar7;
  ulonglong *puVar8;
  undefined *puVar9;
  longlong lVar10;
  longlong lVar11;
  undefined4 *puVar12;
  ulonglong uVar13;
  uint uVar14;
  ulonglong *puVar16;
  ulonglong *puVar17;
  int iVar18;
  ulonglong uVar19;
  ulonglong uVar20;
  undefined auStack_378 [32];
  undefined8 uStack_358;
  undefined8 uStack_350;
  undefined8 uStack_348;
  undefined8 uStack_340;
  undefined8 uStack_338;
  undefined8 uStack_330;
  undefined8 uStack_328;
  undefined8 uStack_320;
  undefined8 uStack_318;
  undefined8 uStack_308;
  ulonglong *puStack_2f8;
  undefined4 uStack_2f0;
  undefined4 uStack_2ec;
  undefined4 uStack_2e8;
  undefined4 uStack_2e4;
  undefined4 uStack_2e0;
  undefined4 uStack_2dc;
  undefined4 uStack_2d8;
  undefined8 uStack_2c8;
  longlong lStack_2c0;
  undefined auStack_2b8 [16];
  undefined auStack_2a8 [16];
  undefined auStack_298 [16];
  undefined auStack_288 [16];
  undefined auStack_278 [16];
  undefined auStack_268 [16];
  undefined4 uStack_258;
  undefined2 uStack_254;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined4 uStack_240;
  undefined4 uStack_23c;
  undefined4 uStack_238;
  undefined4 uStack_234;
  undefined4 uStack_230;
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined4 uStack_220;
  undefined4 uStack_21c;
  undefined4 uStack_218;
  undefined4 uStack_214;
  undefined4 uStack_210;
  undefined4 uStack_20c;
  undefined8 uStack_208;
  undefined4 uStack_200;
  undefined4 uStack_1f8;
  undefined4 uStack_1f4;
  undefined4 uStack_1f0;
  undefined4 uStack_1ec;
  undefined4 uStack_1e8;
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  undefined4 uStack_1d0;
  undefined4 uStack_1cc;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined4 uStack_1a8;
  undefined4 uStack_1a4;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined4 uStack_18c;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined2 uStack_178;
  short asStack_168 [144];
  ulonglong uStack_48;
  ulonglong *puVar15;
  
  uStack_2c8 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_378;
  puVar17 = (ulonglong *)0x0;
  uStack_320 = 0;
  uStack_328 = uStack_328 & 0xffffffff00000000;
  if ((((DAT_ != '\0') && (uStack_318 = uStack_318 & 0xffffffff00000000, *param_1 != 0)) &&
      (param_1[0xc] != 0)) && (*(int *)(param_1 + 0xd) != 0)) {
    uVar7 = func_0x(param_1,0x1af0090,&uStack_318);
    puVar16 = (ulonglong *)0x0;
    puVar8 = puVar17;
    if (((param_1[0xc] != 0) && (puVar8 = puVar16, uVar7 - 1 < 0xfffffffe)) &&
       (*(uint *)(param_1 + 0xd) != 0)) {
      puVar15 = puVar17;
      do {
        puVar8 = (ulonglong *)((longlong)puVar15 * 0x58 + param_1[0xc]);
        if (*puVar8 == (ulonglong)uVar7) {
          if (puVar8 != (ulonglong *)0x0) goto LAB_;
          break;
        }
        uVar14 = (int)puVar15 + 1;
        puVar15 = (ulonglong *)(ulonglong)uVar14;
        puVar8 = puVar16;
      } while (uVar14 < *(uint *)(param_1 + 0xd));
    }
    uStack_358 = CONCAT44(uStack_358._4_4_,*(undefined4 *)(param_1 + 3));
    (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
    lVar10 = *param_1;
    uStack_320 = *(undefined8 *)(puVar8[2] + lVar10);
    uStack_328 = CONCAT44(uStack_328._4_4_,*(undefined4 *)(lVar10 + puVar8[3]));
    if ((char *)(puVar8[1] + lVar10) != (char *)0x0) {
      cVar6 = *(char *)(puVar8[1] + lVar10);
      if (cVar6 == '\x01') {
        puVar9 = (undefined *)func_0x(param_1,0x1af00b8,&uStack_320,&uStack_328);
        if (puVar9 == (undefined *)0x0) {
          uStack_358 = 0;
          (*_DAT_)(1,0x1cabe30,0x1c85e60,0x256);
        }
        if ((int)uStack_328 == 3) {
          uStack_358 = 0;
          (*_DAT_)(1,0x1cabe40,0x1c85e60,0x25b);
        }
        uVar1 = *puVar9;
        lVar10 = func_0x(param_1,0x1af0030,&uStack_320,&uStack_328);
        if (lVar10 == 0) {
          uStack_358 = 0;
          (*_DAT_)(1,0x1cabe30,0x1c85e60,0x256);
        }
        if ((int)uStack_328 == 3) {
          uStack_358 = 0;
          (*_DAT_)(1,0x1cabe40,0x1c85e60,0x25b);
        }
        iVar18 = 0x800;
        if ((int)uStack_320 < 0x801) {
          iVar18 = (int)uStack_320;
        }
        lVar11 = func_0x(param_1,0x1af0060,&uStack_320,&uStack_328);
        if (lVar11 == 0) {
          uStack_358 = lVar11;
          (*_DAT_)(1,0x1cabe30,0x1c85e60,0x256);
        }
        if ((int)uStack_328 == 3) {
          uStack_358 = 0;
          (*_DAT_)(1,0x1cabe40,0x1c85e60,0x25b);
        }
        uStack_318 = CONCAT44(uStack_318._4_4_,0x3a);
        uStack_308 = (ulonglong *)_DAT_;
        uStack_358._0_1_ = 6;
        uStack_328 = (*_DAT_)(0x20f8,_DAT_,0x1aeffe0,0x3a);
        if (uStack_328 != 0) {
          puStack_2f8 = *param_2;
          uStack_2f0 = *(undefined4 *)(param_2 + 1);
          uStack_2ec = *(undefined4 *)((longlong)param_2 + 0xc);
          uStack_330 = 0;
          uStack_338 = (undefined4 *)CONCAT44(uStack_338._4_4_,(int)uStack_320);
          uStack_348 = CONCAT44(uStack_348._4_4_,iVar18);
          uStack_350 = (ulonglong *)lVar10;
          uStack_340 = (ulonglong **)lVar11;
          uStack_358._0_1_ = uVar1;
          func_0x(uStack_328,param_3,param_4,&puStack_2f8);
        }
        uStack_320 = 0;
        goto LAB_;
      }
      if (cVar6 != '\0') {
        uStack_350 = (ulonglong *)CONCAT71(uStack_350._1_7_,cVar6);
        uStack_358._0_1_ = 0x48;
        uStack_358._1_7_ = 0x1aeff;
        func_0x(param_4,lVar10,0x1886c18,0);
        goto LAB_;
      }
    }
  }
  uStack_308 = (ulonglong *)CONCAT44(uStack_308._4_4_,0x46);
  lStack_2c0 = _DAT_;
  uStack_358._0_1_ = 6;
  puVar8 = (ulonglong *)(*_DAT_)(0x12b8,_DAT_,0x1aeffe0,0x46);
  puStack_2f8 = puVar8;
  if (puVar8 != (ulonglong *)0x0) {
    *puVar8 = 0x1aee5e0;
    puVar8[1] = 0;
    puVar8[2] = 0;
    *(undefined2 *)(puVar8 + 3) = *(undefined2 *)(param_3 + 0x106);
    puVar8[4] = param_3;
    *(undefined4 *)(puVar8 + 5) = 0;
    puVar8[6] = _DAT_;
    uVar3 = *(undefined4 *)((longlong)param_2 + 4);
    uVar4 = *(undefined4 *)(param_2 + 1);
    uVar5 = *(undefined4 *)((longlong)param_2 + 0xc);
    *(undefined4 *)(puVar8 + 7) = *(undefined4 *)param_2;
    *(undefined4 *)((longlong)puVar8 + 0x3c) = uVar3;
    *(undefined4 *)(puVar8 + 8) = uVar4;
    *(undefined4 *)((longlong)puVar8 + 0x44) = uVar5;
    *(undefined2 *)(puVar8 + 9) = 1;
    *(undefined *)((longlong)puVar8 + 0x4a) = 0;
    puVar8[0xb] = 0;
    *(undefined4 *)(puVar8 + 0xc) = 0;
    *(undefined4 *)(puVar8 + 0xd) = 0;
    puVar8[0xe] = 0;
    *(undefined4 *)(puVar8 + 0xf) = 0;
    puVar8[0x10] = 0;
    puVar8[0x13] = 0;
    puVar17 = puVar8 + 0x11;
    puVar8[0x12] = (ulonglong)puVar17;
    *puVar17 = (ulonglong)puVar17;
    *(undefined4 *)(puVar8 + 0x14) = 0;
    puVar8[0x15] = 0;
    puVar8[0x18] = 0;
    puVar17 = puVar8 + 0x16;
    puVar8[0x17] = (ulonglong)puVar17;
    *puVar17 = (ulonglong)puVar17;
    puVar8[0x19] = 0;
    *puVar8 = 0x1af2db8;
    puVar8[0x1b] = 0;
    puVar17 = puVar8 + 0x21f;
    puVar8[0x220] = (ulonglong)puVar17;
    *puVar17 = (ulonglong)puVar17;
    puVar8[0x221] = 0;
    *(undefined4 *)(puVar8 + 0x222) = 1;
    *(undefined4 *)((longlong)puVar8 + 0x1114) = 1;
    puVar8[0x223] = 1;
    puVar8[0x21e] = 0x17f2700;
    puVar8[0x224] = 0;
    *(undefined *)((longlong)puVar8 + 0x12b3) = 0;
    *(undefined2 *)(puVar8 + 0x256) = *(undefined2 *)(puVar8[4] + 0x106);
    puVar8[0x1c] = 0;
    *(undefined *)((longlong)puVar8 + 0x56) = 0;
    uStack_318 = 0;
    *(undefined8 *)((longlong)puVar8 + 0x4c) = 0;
    *(undefined2 *)((longlong)puVar8 + 0x54) = 0;
    *(undefined *)((longlong)puVar8 + 0x12b2) = 0;
    puVar8[0x255] = 0;
    *(undefined2 *)(puVar8 + 0x1d) = 0;
    lVar10 = _DAT_;
    if (_DAT_ == 0) {
      lVar10 = *_DAT_;
    }
    func_0x(puVar8 + 0xb,0x200,lVar10);
    func_0x(puVar8);
    puVar17 = puVar8;
  }
  uStack_308 = puVar17;
  if (DAT_ == '\0') {
    lVar10 = func_0x(param_1,0x1aeffb0,&uStack_320,&uStack_328);
    if (lVar10 == 0) {
      uStack_358._0_1_ = 0;
      uStack_358._1_7_ = 0;
      (*_DAT_)(1,0x1cabe30,0x1c85e60,0x256);
    }
    if ((int)uStack_328 == 3) {
      uStack_358._0_1_ = 0;
      uStack_358._1_7_ = 0;
      (*_DAT_)(1,0x1cabe40,0x1c85e60,0x25b);
    }
    uVar19 = (ulonglong)(int)uStack_320;
    if (uVar19 < 0x65) {
      if (uVar19 != 0) goto LAB_;
    }
    else {
      uStack_358._0_1_ = 0xb0;
      uStack_358._1_7_ = 0x1aeff;
      (*_DAT_)(0xe3,0x28,0x10,3);
LAB_:
      if ((lVar10 == 0) || (0x66 < uVar19)) {
        auStack_2b8 = ZEXT816(0);
        uStack_258 = 0;
        uStack_254 = 0;
        auStack_2a8 = auStack_2b8;
        auStack_298 = auStack_2b8;
        auStack_288 = auStack_2b8;
        auStack_278 = auStack_2b8;
        auStack_268 = auStack_2b8;
        if (lVar10 == 0) {
          puVar12 = (undefined4 *)(*_DAT_)();
          *puVar12 = 0x16;
        }
        else {
          if (uVar19 < 0x67) goto LAB_;
          puVar12 = (undefined4 *)(*_DAT_)();
          *puVar12 = 0x22;
        }
        (*_DAT_)();
      }
      else {
        func_0x(auStack_2b8,lVar10);
      }
    }
LAB_:
    if (0x65 < (uVar19 & 0xfffffffffffffffe)) {
      func_0x();
      pcVar2 = (code *)swi(3);
      (*pcVar2)();
      return;
    }
    *(undefined2 *)(auStack_2b8 + (uVar19 & 0xfffffffffffffffe)) = 0;
    uStack_248 = _DAT_;
    uStack_244 = uRam0000000001af2a84;
    uStack_240 = uRam0000000001af2a88;
    uStack_23c = uRam0000000001af2a8c;
    uStack_238 = _DAT_;
    uStack_234 = uRam0000000001af2a94;
    uStack_230 = uRam0000000001af2a98;
    uStack_22c = uRam0000000001af2a9c;
    uStack_228 = _DAT_;
    uStack_224 = uRam0000000001af2aa4;
    uStack_220 = uRam0000000001af2aa8;
    uStack_21c = uRam0000000001af2aac;
    uStack_218 = _DAT_;
    uStack_214 = uRam0000000001af2ab4;
    uStack_210 = uRam0000000001af2ab8;
    uStack_20c = uRam0000000001af2abc;
    uStack_208 = _DAT_;
    uStack_200 = _DAT_;
    uVar19 = (*_DAT_)(auStack_2b8,&uStack_248);
    uVar20 = 0xffffffffffffffff;
    uVar13 = 0xffffffffffffffff;
    do {
      uVar13 = uVar13 + 1;
    } while (*(short *)(auStack_2b8 + uVar13 * 2) != 0);
    if (uVar19 < uVar13) {
      uStack_358._0_1_ = 0xb0;
      uStack_358._1_7_ = 0x1aeff;
      (*_DAT_)(0xe3,0x28,0x10,4);
    }
    (*_DAT_)(puVar17 + 0x225,0x33,auStack_2b8);
    lVar10 = func_0x(param_1,0x196d380,&uStack_320,&uStack_328);
    if (lVar10 == 0) {
      uStack_358._0_1_ = 0;
      uStack_358._1_7_ = 0;
      (*_DAT_)(1,0x1cabe30,0x1c85e60,0x256);
    }
    if ((int)uStack_328 == 3) {
      uStack_358._0_1_ = 0;
      uStack_358._1_7_ = 0;
      (*_DAT_)(1,0x1cabe40,0x1c85e60,0x25b);
    }
    uVar19 = (ulonglong)(int)uStack_320;
    if (uVar19 < 0x119) {
      if (uVar19 != 0) goto LAB_;
    }
    else {
      uStack_358._0_1_ = 0x80;
      uStack_358._1_7_ = 0x196d3;
      (*_DAT_)(0xe3,0x28,0x10,5);
LAB_:
      if ((lVar10 == 0) || (0x11a < uVar19)) {
        func_0x(asStack_168,0,0x11a);
        if (lVar10 == 0) {
          puVar12 = (undefined4 *)(*_DAT_)();
          *puVar12 = 0x16;
        }
        else {
          if (uVar19 < 0x11b) goto LAB_;
          puVar12 = (undefined4 *)(*_DAT_)();
          *puVar12 = 0x22;
        }
        (*_DAT_)();
      }
      else {
        func_0x(asStack_168,lVar10);
      }
    }
LAB_:
    if (0x119 < (uVar19 & 0xfffffffffffffffe)) {
      func_0x();
      pcVar2 = (code *)swi(3);
      (*pcVar2)();
      return;
    }
    *(undefined2 *)((longlong)asStack_168 + (uVar19 & 0xfffffffffffffffe)) = 0;
    uStack_1f8 = _DAT_;
    uStack_1f4 = uRam0000000001af2ad4;
    uStack_1f0 = uRam0000000001af2ad8;
    uStack_1ec = uRam0000000001af2adc;
    uStack_1e8 = _DAT_;
    uStack_1e4 = uRam0000000001af2ae4;
    uStack_1e0 = uRam0000000001af2ae8;
    uStack_1dc = uRam0000000001af2aec;
    uStack_1d8 = _DAT_;
    uStack_1d4 = uRam0000000001af2af4;
    uStack_1d0 = uRam0000000001af2af8;
    uStack_1cc = uRam0000000001af2afc;
    uStack_1c8 = _DAT_;
    uStack_1c4 = uRam0000000001af2b04;
    uStack_1c0 = uRam0000000001af2b08;
    uStack_1bc = uRam0000000001af2b0c;
    uStack_1b8 = _DAT_;
    uStack_1b4 = uRam0000000001af2b14;
    uStack_1b0 = uRam0000000001af2b18;
    uStack_1ac = uRam0000000001af2b1c;
    uStack_1a8 = _DAT_;
    uStack_1a4 = uRam0000000001af2b24;
    uStack_1a0 = uRam0000000001af2b28;
    uStack_19c = uRam0000000001af2b2c;
    uStack_198 = _DAT_;
    uStack_194 = uRam0000000001af2b34;
    uStack_190 = uRam0000000001af2b38;
    uStack_18c = uRam0000000001af2b3c;
    uStack_188 = _DAT_;
    uStack_184 = uRam0000000001af2b44;
    uStack_180 = uRam0000000001af2b48;
    uStack_17c = uRam0000000001af2b4c;
    uStack_178 = _DAT_;
    uVar19 = (*_DAT_)(asStack_168,&uStack_1f8);
    do {
      uVar20 = uVar20 + 1;
    } while (asStack_168[uVar20] != 0);
    if (uVar19 < uVar20) {
      uStack_358._0_1_ = 0x80;
      uStack_358._1_7_ = 0x196d3;
      (*_DAT_)(0xe3,0x28,0x10,6);
    }
    (*_DAT_)((longlong)puVar17 + 0x118e,0x8d,asStack_168);
  }
  else {
    lVar10 = func_0x(param_1,0x1af0030,&uStack_320,&uStack_328);
    if (lVar10 == 0) {
      uStack_358._0_1_ = 0;
      uStack_358._1_7_ = 0;
      (*_DAT_)(1,0x1cabe30,0x1c85e60,0x256);
    }
    if ((int)uStack_328 == 3) {
      uStack_358._0_1_ = 0;
      uStack_358._1_7_ = 0;
      (*_DAT_)(1,0x1cabe40,0x1c85e60,0x25b);
    }
    iVar18 = 0x800;
    if ((int)uStack_320 < 0x801) {
      iVar18 = (int)uStack_320;
    }
    puVar8 = puVar17 + 0x1d;
    func_0x(puVar8,lVar10,(longlong)iVar18);
    *(undefined2 *)((longlong)puVar17 + (longlong)(iVar18 / 2) * 2 + 0xe8) = 0;
    uStack_330 = 0;
    uStack_338 = (undefined4 *)0x0;
    uStack_340 = (ulonglong **)0x0;
    uStack_348 = 0;
    uStack_350 = (ulonglong *)0x0;
    uStack_358._0_1_ = 0;
    uStack_358._1_7_ = 0;
    cVar6 = func_0x(puVar8,0,0,0);
    if (cVar6 == '\0') {
      uStack_2e8 = _DAT_;
      uStack_2e4 = uRam0000000001c7dc54;
      uStack_2e0 = uRam0000000001c7dc58;
      uStack_2dc = uRam0000000001c7dc5c;
      uStack_2d8 = 0;
      puStack_2f8 = (ulonglong *)puVar17[7];
      uStack_2f0 = *(undefined4 *)(puVar17 + 8);
      uStack_2ec = *(undefined4 *)((longlong)puVar17 + 0x44);
      uStack_338 = &uStack_2e8;
      uStack_340 = &puStack_2f8;
      uStack_348 = 0x1af0018;
      uStack_358 = 0x1aeff88;
      uStack_350 = puVar8;
      func_0x(param_4);
      uStack_338 = (undefined4 *)0x1aefaf0;
      uStack_340 = (ulonglong **)CONCAT44(uStack_340._4_4_,0xc);
      uStack_348 = CONCAT44(uStack_348._4_4_,0x10);
      uStack_350 = (ulonglong *)CONCAT44(uStack_350._4_4_,0x49aa);
      uStack_358._0_1_ = 0;
      uStack_358._1_7_ = 0;
      func_0x(1,param_3,0,0);
    }
    lVar10 = func_0x(param_1,0x1af0060,&uStack_320,&uStack_328);
    if (lVar10 == 0) {
      uStack_358._0_1_ = 0;
      uStack_358._1_7_ = 0;
      (*_DAT_)(1,0x1cabe30,0x1c85e60,0x256);
    }
    if ((int)uStack_328 == 3) {
      uStack_358._0_1_ = 0;
      uStack_358._1_7_ = 0;
      (*_DAT_)(1,0x1cabe40,0x1c85e60,0x25b);
    }
    iVar18 = (int)uStack_320;
    if (0x802 < iVar18 + 1U) {
      uStack_358._0_1_ = 0;
      uStack_358._1_7_ = 0;
      (*_DAT_)(1,0x1cab250,0x1c85d38,0xef);
    }
    *(int *)((longlong)puVar17 + 0x10ec) = iVar18;
    func_0x((longlong)puVar17 + 0x8ea,0x802,lVar10,(longlong)iVar18);
    *(undefined2 *)
     ((longlong)puVar17 +
     ((longlong)*(int *)((longlong)puVar17 + 0x10ec) & 0xfffffffffffffffeU) + 0x8ea) = 0;
  }
  uStack_308 = (ulonglong *)0x0;
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_378);
  return;
}

