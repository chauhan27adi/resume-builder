
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(ushort *param_1,undefined4 *param_2,undefined8 param_3,undefined4 param_4,
                 int param_5)

{
  ushort uVar1;
  byte *pbVar2;
  ushort *puVar3;
  ulonglong uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  byte bVar9;
  char cVar10;
  ushort uVar11;
  longlong lVar12;
  ushort **ppuVar13;
  longlong lVar14;
  undefined8 uVar15;
  ulonglong uVar16;
  byte *pbVar17;
  ulonglong uVar18;
  undefined8 *puVar19;
  ulonglong uVar20;
  ushort uVar21;
  uint uVar22;
  ulonglong uVar23;
  longlong lVar24;
  uint uVar25;
  uint uVar26;
  uint *puVar27;
  ulonglong uVar28;
  longlong lVar29;
  ushort uVar30;
  ushort *puVar31;
  int iVar32;
  undefined8 auStack_100 [5];
  ushort *puStack_d8;
  ulonglong uStack_d0;
  undefined4 auStack_c8 [2];
  undefined8 uStack_c0;
  ushort *puStack_b8;
  ushort *puStack_b0;
  ushort uStack_a8;
  uint uStack_a6;
  ulonglong uStack_a2;
  undefined4 uStack_9a;
  uint uStack_96;
  uint uStack_92;
  ushort uStack_8e;
  undefined4 uStack_84;
  ushort uStack_80;
  ushort uStack_7e;
  longlong lStack_78;
  longlong lStack_70;
  undefined8 uStack_68;
  uint uStack_60;
  undefined4 uStack_5c;
  uint uStack_58;
  uint uStack_54;
  longlong lStack_50;
  ushort *puStack_48;
  undefined4 *puStack_40;
  ulonglong uStack_38;
  
  uStack_38 = _DAT_ ^ (ulonglong)auStack_c8;
  uStack_a6 = *(uint *)(param_1 + -0x13);
  iVar32 = 0;
  auStack_c8[0] = param_4;
  uStack_68 = param_3;
  puStack_48 = param_1;
  puStack_40 = param_2;
  if (uStack_a6 == 0) {
    pbVar17 = *(byte **)(param_1 + -0x11);
    uVar26 = *(uint *)(param_1 + -0xd);
    uVar20 = (ulonglong)uVar26;
    param_1[-0x14] = 0;
    *(uint *)(param_1 + -0xb) = uVar26;
    bVar9 = *pbVar17;
    if ((bVar9 & 0x10) != 0) {
      uVar26 = uVar26 + 2 + (*(ushort *)(pbVar17 + uVar20) + 7 >> 3);
      uVar20 = (ulonglong)uVar26;
      *(uint *)(param_1 + -0xb) = uVar26;
      bVar9 = *pbVar17;
    }
    uStack_a6 = (uint)uVar20;
    if ((bVar9 & 0x20) == 0) {
      *(uint *)(param_1 + -0x13) = uStack_a6;
      param_1[-7] = 0;
      *(uint *)(param_1 + -9) = uStack_a6;
    }
    else {
      puVar31 = (ushort *)(pbVar17 + uVar20);
      uVar21 = *puVar31;
      param_1[-7] = uVar21;
      if (uVar21 == 0) {
        auStack_100[0] = 0x1000bd;
        cVar10 = func_0x(0x10ed4e0);
        if (cVar10 != '\0') {
          auStack_100[0] = 0x1000c6;
          lVar12 = func_0x();
          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
            auStack_100[0] = 0x1000e0;
            cVar10 = func_0x(0x10ed4e0);
            if (cVar10 == '\0') {
              auStack_100[0] = 0x1000fc;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              puStack_d8 = (ushort *)0x0;
              auStack_100[0] = 0x100122;
              (*_DAT_)(1,0x9dceec,0xafcfd8,0x80f);
            }
          }
        }
        auStack_100[0] = 0x100130;
        func_0x(*(undefined8 *)(param_1 + -0x11),3);
        uVar21 = param_1[-7];
        pbVar17 = *(byte **)(param_1 + -0x11);
        uStack_a6 = *(uint *)(param_1 + -0xb);
      }
      uVar26 = uStack_a6 + (uVar21 + 1) * 2;
      *(uint *)(param_1 + -9) = uVar26;
      if (0x1f9e < uVar26) {
        auStack_100[0] = 0x100161;
        cVar10 = func_0x(0x10ed4e0);
        if (cVar10 != '\0') {
          auStack_100[0] = 0x10016a;
          lVar12 = func_0x();
          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
            auStack_100[0] = 0x100184;
            cVar10 = func_0x(0x10ed4e0);
            if (cVar10 == '\0') {
              auStack_100[0] = 0x1001a0;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_d8 = (ushort *)0x0;
              auStack_100[0] = 0x1001c6;
              (*_DAT_)(1,0x9dceec,0xafcfd8,0x816);
            }
          }
        }
        auStack_100[0] = 0x1001d4;
        func_0x(*(undefined8 *)(param_1 + -0x11),4);
        uVar21 = param_1[-7];
        uVar26 = *(uint *)(param_1 + -9);
        pbVar17 = *(byte **)(param_1 + -0x11);
      }
      uVar20 = (ulonglong)uVar21;
      uStack_a6 = puVar31[uVar20] & 0x7fff;
      *(uint *)(param_1 + -0x13) = uStack_a6;
      if (uStack_a6 < uVar26) {
        auStack_100[0] = 0x100207;
        cVar10 = func_0x(0x10ed4e0);
        if (cVar10 != '\0') {
          auStack_100[0] = 0x100210;
          lVar12 = func_0x();
          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
            auStack_100[0] = 0x10022a;
            cVar10 = func_0x(0x10ed4e0);
            if (cVar10 == '\0') {
              auStack_100[0] = 0x100246;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_d8 = (ushort *)0x0;
              auStack_100[0] = 0x10026c;
              (*_DAT_)(1,0x9dceec,0xafcfd8,0x81d);
            }
          }
        }
        auStack_100[0] = 0x10027a;
        func_0x(*(undefined8 *)(param_1 + -0x11),4);
        uVar26 = *(uint *)(param_1 + -9);
        uVar20 = (ulonglong)param_1[-7];
        pbVar17 = *(byte **)(param_1 + -0x11);
        uStack_a6 = *(uint *)(param_1 + -0x13);
      }
      puVar3 = puVar31;
      if ((short)uVar20 != 0) {
        do {
          uVar25 = puVar3[1] & 0x7fff;
          if ((uVar25 < uVar26) || (uStack_a6 = *(uint *)(param_1 + -0x13), uStack_a6 < uVar25)) {
            auStack_100[0] = 0x1002c6;
            cVar10 = func_0x(0x10ed4e0);
            if (cVar10 != '\0') {
              auStack_100[0] = 0x1002cf;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                auStack_100[0] = 0x1002e9;
                cVar10 = func_0x(0x10ed4e0);
                if (cVar10 == '\0') {
                  auStack_100[0] = 0x100305;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_d8 = (ushort *)0x0;
                  auStack_100[0] = 0x10032f;
                  (*_DAT_)(1,0x9dceec,0xafcfd8,0x82a);
                }
              }
            }
            auStack_100[0] = 0x10033d;
            func_0x(*(undefined8 *)(param_1 + -0x11),4);
            uStack_a6 = *(uint *)(param_1 + -0x13);
          }
          uVar20 = (ulonglong)param_1[-7];
          iVar32 = iVar32 + 1;
          uVar26 = uVar25;
          puVar3 = puVar3 + 1;
        } while (iVar32 < (int)(uint)param_1[-7]);
        pbVar17 = *(byte **)(param_1 + -0x11);
      }
      uVar23 = uVar20;
      if ((short)puVar31[(ulonglong)((int)uVar20 - 1) + 1] < 0) {
LAB_:
        uVar21 = (ushort)uVar20;
        uVar26 = *(ushort *)(pbVar17 + uVar23 * 2 + (ulonglong)*(uint *)(param_1 + -0xb)) & 0x7fff;
        if ((int)uVar23 == 1) {
          uVar25 = *(uint *)(param_1 + -9);
          uVar20 = (ulonglong)uVar25;
LAB_:
          if ((uVar26 < (uint)uVar20) ||
             (uStack_a6 = *(uint *)(param_1 + -0x13), uStack_a6 < uVar26)) goto LAB_;
        }
        else {
          uVar25 = *(uint *)(param_1 + -9);
          uVar20 = (ulonglong)
                   (*(ushort *)(pbVar17 + uVar23 * 2 + ((ulonglong)*(uint *)(param_1 + -0xb) - 2)) &
                   0x7fff);
          if (uVar25 <= (*(ushort *)
                          (pbVar17 + uVar23 * 2 + ((ulonglong)*(uint *)(param_1 + -0xb) - 2)) &
                        0x7fff)) goto LAB_;
LAB_:
          auStack_100[0] = 0x1003d6;
          func_0x(pbVar17,7);
          uVar25 = *(uint *)(param_1 + -9);
          pbVar17 = *(byte **)(param_1 + -0x11);
          uVar21 = param_1[-7];
          uStack_a6 = *(uint *)(param_1 + -0x13);
        }
        uVar22 = (uint)uVar20;
        if ((uVar25 <= uVar22) && (uVar22 <= uStack_a6)) {
          if (*(ushort *)(pbVar17 + uVar20) == 5) {
            param_1[-0x14] = param_1[-0x14] | 2;
            param_1[-7] = uVar21 - 1;
            uVar28 = *(ulonglong *)(param_1 + -0x11);
            uVar18 = uVar20 & 0xffff;
            uVar21 = param_1[1] & 0xc7ff;
            uVar23 = uVar28 + uVar18;
            *param_1 = (ushort)uVar20;
            if ((*(ushort *)(uVar23 + 2) >> 0xe & 1) != 0) {
              uVar21 = *(ushort *)(uVar23 + 2) & 0x3800 | uVar21;
            }
            param_1[1] = uVar21;
            uVar11 = (uVar21 ^ *(ushort *)(uVar23 + 2)) & 0x7ff ^ uVar21;
            param_1[1] = uVar11;
            uVar20 = uVar28 + 4 + (ulonglong)((uVar21 >> 0xb & 7) * 2) +
                     (ulonglong)((uVar11 & 0x7ff) * 2) + uVar18;
            if (uVar20 < uVar23) {
              auStack_100[0] = 0x1004eb;
              func_0x(uVar23,0x19);
              uVar11 = param_1[1];
              uVar18 = (ulonglong)*param_1;
              uVar28 = (ulonglong)*(uint *)(param_1 + -0x11);
            }
            if (uVar26 - uVar22 < (((uVar11 & 0x7ff) * 2 - (int)uVar18) - (int)uVar28) + (int)uVar20
               ) {
              auStack_100[0] = 0x100524;
              func_0x(uVar18 + *(longlong *)(param_1 + -0x11),0x19);
              uVar11 = param_1[1];
              uVar18 = (ulonglong)*param_1;
            }
            if ((uVar11 & 0x3800) != 0) {
              puVar31 = (ushort *)(*(longlong *)(param_1 + -0x11) + 4 + uVar18);
              iVar32 = 0;
              if ((uVar11 & 0x3800) != 0) {
                do {
                  if ((uVar11 & 0x7ff) < (*puVar31 & 0x7ff)) {
                    auStack_100[0] = 0x100588;
                    func_0x((ulonglong)*param_1 + *(longlong *)(param_1 + -0x11),0x1a);
                    uVar11 = param_1[1];
                  }
                  iVar32 = iVar32 + 1;
                  puVar31 = puVar31 + 1;
                } while (iVar32 < (int)(uVar11 >> 0xb & 7));
              }
            }
            pbVar17 = *(byte **)(param_1 + -0x11);
            uStack_a6 = *(uint *)(param_1 + -0x13);
          }
          else if (0x3ff < *(ushort *)(pbVar17 + uVar20)) {
            param_1[-0x14] = param_1[-0x14] | 1;
            uVar21 = uVar21 - 1;
            param_1[-7] = uVar21;
            if (uVar21 != 0) goto code_r0x00100429;
          }
          goto LAB_;
        }
        goto LAB_;
      }
    }
LAB_:
    if ((*pbVar17 & 0x40) == 0) {
      *(undefined4 *)(param_1 + -2) = 0;
    }
    else {
      *(uint *)(param_1 + -2) = uStack_a6;
      *(uint *)(param_1 + -0x13) = uStack_a6 + 0xe;
      auStack_100[0] = 0x1005da;
      ppuVar13 = (ushort **)func_0x(param_1 + -0x14);
      puStack_b8 = *ppuVar13;
      auStack_100[0] = 0x1005ea;
      iVar32 = func_0x(&puStack_b8);
      *(int *)(param_1 + -0x13) = *(int *)(param_1 + -0x13) + iVar32;
      uStack_a6 = *(uint *)(param_1 + -0x13);
      pbVar17 = *(byte **)(param_1 + -0x11);
    }
    if ((*(byte **)(param_1 + -6) != (byte *)0x0) &&
       (*(byte **)(param_1 + -6) < pbVar17 + uStack_a6)) {
      auStack_100[0] = 0x100625;
      cVar10 = func_0x(0x10ed4e0);
      if (cVar10 != '\0') {
        auStack_100[0] = 0x10062e;
        lVar12 = func_0x();
        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
          auStack_100[0] = 0x100648;
          cVar10 = func_0x(0x10ed4e0);
          if (cVar10 == '\0') {
            auStack_100[0] = 0x100664;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            puStack_d8 = (ushort *)0x0;
            auStack_100[0] = 0x10068a;
            (*_DAT_)(1,0x9dceec,0xafcfd8,0x886);
          }
        }
      }
      auStack_100[0] = 0x100698;
      func_0x(*(undefined8 *)(param_1 + -0x11),0x12);
      uStack_a6 = *(uint *)(param_1 + -0x13);
    }
    if ((uStack_a6 == 0) || (0x3f3c < uStack_a6)) {
      auStack_100[0] = 0x1006b8;
      cVar10 = func_0x(0x10ed4e0);
      if (cVar10 != '\0') {
        auStack_100[0] = 0x1006c1;
        lVar12 = func_0x();
        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
          auStack_100[0] = 0x1006db;
          cVar10 = func_0x(0x10ed4e0);
          if (cVar10 == '\0') {
            auStack_100[0] = 0x1006f7;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            puStack_d8 = (ushort *)0x0;
            auStack_100[0] = 0x10071d;
            (*_DAT_)(1,0x9dceec,0xafcfd8,0x88b);
          }
        }
      }
      auStack_100[0] = 0x10072b;
      func_0x(*(undefined8 *)(param_1 + -0x11),5);
      uStack_a6 = *(uint *)(param_1 + -0x13);
    }
  }
LAB_:
  uVar26 = 9;
  if (uStack_a6 < 9) {
    pbVar17 = *(byte **)(param_1 + -0x11);
    if (((*pbVar17 & 0xe) == 0) || ((*pbVar17 & 0xe) == 0xc)) goto LAB_;
  }
  pbVar17 = *(byte **)(param_1 + -0x11);
  uVar26 = uStack_a6;
LAB_:
  puStack_b0 = (ushort *)(ulonglong)uVar26;
  auStack_100[0] = 0x10077a;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  uStack_c0 = (longlong)auStack_c8 + lVar12;
  if (uStack_a6 == 0) {
    uVar26 = *(uint *)(param_1 + -0xd);
    uVar20 = (ulonglong)uVar26;
    iVar32 = 0;
    param_1[-0x14] = 0;
    *(uint *)(param_1 + -0xb) = uVar26;
    if ((*pbVar17 & 0x10) != 0) {
      uVar26 = uVar26 + 2 + (*(ushort *)(pbVar17 + uVar20) + 7 >> 3);
      uVar20 = (ulonglong)uVar26;
      *(uint *)(param_1 + -0xb) = uVar26;
    }
    uStack_a6 = (uint)uVar20;
    if ((*pbVar17 & 0x20) == 0) {
      *(uint *)(param_1 + -0x13) = uStack_a6;
      param_1[-7] = 0;
      *(uint *)(param_1 + -9) = uStack_a6;
    }
    else {
      puVar31 = (ushort *)(pbVar17 + uVar20);
      uVar21 = *puVar31;
      param_1[-7] = uVar21;
      puStack_b8 = puVar31;
      if (uVar21 == 0) {
        *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x1007ea;
        cVar10 = func_0x(0x10ed4e0);
        if (cVar10 != '\0') {
          *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x1007f3;
          lVar14 = func_0x();
          if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x10080d;
            cVar10 = func_0x(0x10ed4e0);
            if (cVar10 == '\0') {
              *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100829;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)((longlong)&puStack_d8 + lVar12) = 0;
              *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x10084f;
              (*_DAT_)(1,0x9dceec,0xafcfd8,0x80f);
            }
          }
        }
        uVar15 = *(undefined8 *)(param_1 + -0x11);
        *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x10085d;
        func_0x(uVar15,3);
        uVar21 = param_1[-7];
        pbVar17 = *(byte **)(param_1 + -0x11);
        uStack_a6 = *(uint *)(param_1 + -0xb);
      }
      uVar26 = uStack_a6 + (uVar21 + 1) * 2;
      *(uint *)(param_1 + -9) = uVar26;
      if (0x1f9e < uVar26) {
        *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x10088e;
        cVar10 = func_0x(0x10ed4e0);
        if (cVar10 != '\0') {
          *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100897;
          lVar14 = func_0x();
          if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x1008b1;
            cVar10 = func_0x(0x10ed4e0);
            if (cVar10 == '\0') {
              *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x1008cd;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)((longlong)&puStack_d8 + lVar12) = 0;
              *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x1008f3;
              (*_DAT_)(1,0x9dceec,0xafcfd8,0x816);
            }
          }
        }
        uVar15 = *(undefined8 *)(param_1 + -0x11);
        *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100901;
        func_0x(uVar15,4);
        uVar21 = param_1[-7];
        uVar26 = *(uint *)(param_1 + -9);
        pbVar17 = *(byte **)(param_1 + -0x11);
      }
      uVar20 = (ulonglong)uVar21;
      uStack_a6 = puVar31[uVar20] & 0x7fff;
      *(uint *)(param_1 + -0x13) = uStack_a6;
      if (uStack_a6 < uVar26) {
        *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100934;
        cVar10 = func_0x(0x10ed4e0);
        if (cVar10 != '\0') {
          *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x10093d;
          lVar14 = func_0x();
          if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100957;
            cVar10 = func_0x(0x10ed4e0);
            if (cVar10 == '\0') {
              *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100973;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)((longlong)&puStack_d8 + lVar12) = 0;
              *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100999;
              (*_DAT_)(1,0x9dceec,0xafcfd8,0x81d);
            }
          }
        }
        uVar15 = *(undefined8 *)(param_1 + -0x11);
        *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x1009a7;
        func_0x(uVar15,4);
        uVar26 = *(uint *)(param_1 + -9);
        uVar20 = (ulonglong)param_1[-7];
        pbVar17 = *(byte **)(param_1 + -0x11);
        uStack_a6 = *(uint *)(param_1 + -0x13);
      }
      if ((short)uVar20 != 0) {
        do {
          puVar31 = puVar31 + 1;
          uVar25 = *puVar31 & 0x7fff;
          if ((uVar25 < uVar26) || (uStack_a6 = *(uint *)(param_1 + -0x13), uStack_a6 < uVar25)) {
            *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x1009f6;
            cVar10 = func_0x(0x10ed4e0);
            if (cVar10 != '\0') {
              *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x1009ff;
              lVar14 = func_0x();
              if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100a19;
                cVar10 = func_0x(0x10ed4e0);
                if (cVar10 == '\0') {
                  *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100a35;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)((longlong)&puStack_d8 + lVar12) = 0;
                  *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100a5b;
                  (*_DAT_)(1,0x9dceec,0xafcfd8,0x82a);
                }
              }
            }
            uVar15 = *(undefined8 *)(param_1 + -0x11);
            *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100a69;
            func_0x(uVar15,4);
            uStack_a6 = *(uint *)(param_1 + -0x13);
          }
          uVar20 = (ulonglong)param_1[-7];
          iVar32 = iVar32 + 1;
          uVar26 = uVar25;
        } while (iVar32 < (int)(uint)param_1[-7]);
        pbVar17 = *(byte **)(param_1 + -0x11);
        puVar31 = puStack_b8;
      }
      uVar23 = uVar20;
      if ((short)puVar31[(ulonglong)((int)uVar20 - 1) + 1] < 0) {
LAB_:
        uVar21 = (ushort)uVar20;
        uVar26 = *(ushort *)(pbVar17 + uVar23 * 2 + (ulonglong)*(uint *)(param_1 + -0xb)) & 0x7fff;
        if ((int)uVar23 == 1) {
          uVar25 = *(uint *)(param_1 + -9);
          uVar20 = (ulonglong)uVar25;
LAB_:
          if ((uVar26 < (uint)uVar20) ||
             (uStack_a6 = *(uint *)(param_1 + -0x13), uStack_a6 < uVar26)) goto LAB_;
        }
        else {
          uVar25 = *(uint *)(param_1 + -9);
          uVar20 = (ulonglong)
                   (*(ushort *)(pbVar17 + uVar23 * 2 + ((ulonglong)*(uint *)(param_1 + -0xb) - 2)) &
                   0x7fff);
          if (uVar25 <= (*(ushort *)
                          (pbVar17 + uVar23 * 2 + ((ulonglong)*(uint *)(param_1 + -0xb) - 2)) &
                        0x7fff)) goto LAB_;
LAB_:
          *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100b06;
          func_0x(pbVar17,7);
          uVar25 = *(uint *)(param_1 + -9);
          pbVar17 = *(byte **)(param_1 + -0x11);
          uVar21 = param_1[-7];
          uStack_a6 = *(uint *)(param_1 + -0x13);
        }
        uVar22 = (uint)uVar20;
        if ((uVar25 <= uVar22) && (uVar22 <= uStack_a6)) {
          if (*(ushort *)(pbVar17 + uVar20) == 5) {
            param_1[-0x14] = param_1[-0x14] | 2;
            param_1[-7] = uVar21 - 1;
            uVar28 = *(ulonglong *)(param_1 + -0x11);
            uVar18 = uVar20 & 0xffff;
            uVar21 = param_1[1] & 0xc7ff;
            uVar23 = uVar28 + uVar18;
            *param_1 = (ushort)uVar20;
            if ((*(ushort *)(uVar23 + 2) >> 0xe & 1) != 0) {
              uVar21 = *(ushort *)(uVar23 + 2) & 0x3800 | uVar21;
            }
            param_1[1] = uVar21;
            uVar11 = (uVar21 ^ *(ushort *)(uVar23 + 2)) & 0x7ff ^ uVar21;
            param_1[1] = uVar11;
            uVar20 = uVar28 + 4 + (ulonglong)((uVar21 >> 0xb & 7) * 2) +
                     (ulonglong)((uVar11 & 0x7ff) * 2) + uVar18;
            if (uVar20 < uVar23) {
              *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100c1f;
              func_0x(uVar23,0x19);
              uVar11 = param_1[1];
              uVar18 = (ulonglong)*param_1;
              uVar28 = (ulonglong)*(uint *)(param_1 + -0x11);
            }
            if (uVar26 - uVar22 < (((uVar11 & 0x7ff) * 2 - (int)uVar18) - (int)uVar28) + (int)uVar20
               ) {
              lVar14 = *(longlong *)(param_1 + -0x11);
              *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100c58;
              func_0x(uVar18 + lVar14,0x19);
              uVar11 = param_1[1];
              uVar18 = (ulonglong)*param_1;
            }
            if ((uVar11 & 0x3800) != 0) {
              puVar31 = (ushort *)(*(longlong *)(param_1 + -0x11) + 4 + uVar18);
              iVar32 = 0;
              if ((uVar11 & 0x3800) != 0) {
                do {
                  if ((uVar11 & 0x7ff) < (*puVar31 & 0x7ff)) {
                    uVar21 = *param_1;
                    lVar14 = *(longlong *)(param_1 + -0x11);
                    *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100cb8;
                    func_0x((ulonglong)uVar21 + lVar14,0x1a);
                    uVar11 = param_1[1];
                  }
                  iVar32 = iVar32 + 1;
                  puVar31 = puVar31 + 1;
                } while (iVar32 < (int)(uVar11 >> 0xb & 7));
              }
            }
            pbVar17 = *(byte **)(param_1 + -0x11);
            uStack_a6 = *(uint *)(param_1 + -0x13);
          }
          else if (0x3ff < *(ushort *)(pbVar17 + uVar20)) {
            param_1[-0x14] = param_1[-0x14] | 1;
            uVar21 = uVar21 - 1;
            param_1[-7] = uVar21;
            if (uVar21 != 0) goto code_r0x00100b5d;
          }
          goto LAB_;
        }
        goto LAB_;
      }
    }
LAB_:
    if ((*pbVar17 & 0x40) == 0) {
      *(undefined4 *)(param_1 + -2) = 0;
    }
    else {
      *(uint *)(param_1 + -2) = uStack_a6;
      *(uint *)(param_1 + -0x13) = uStack_a6 + 0xe;
      *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100d0a;
      uVar15 = func_0x(param_1 + -0x14);
      *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100d16;
      func_0x(uVar15,&puStack_b8);
      *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100d1f;
      iVar32 = func_0x(&puStack_b8);
      *(int *)(param_1 + -0x13) = *(int *)(param_1 + -0x13) + iVar32;
      uStack_a6 = *(uint *)(param_1 + -0x13);
      pbVar17 = *(byte **)(param_1 + -0x11);
    }
    pbVar2 = *(byte **)(param_1 + -6);
    if ((pbVar2 != (byte *)0x0) && (pbVar2 < pbVar17 + uStack_a6)) {
      *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100d60;
      cVar10 = func_0x(0x10ed4e0,pbVar2,pbVar17);
      if (cVar10 != '\0') {
        *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100d69;
        lVar14 = func_0x();
        if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
          *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100d83;
          cVar10 = func_0x(0x10ed4e0);
          if (cVar10 == '\0') {
            *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100d9f;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)((longlong)&puStack_d8 + lVar12) = 0;
            *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100dc5;
            (*_DAT_)(1,0x9dceec,0xafcfd8,0x886);
          }
        }
      }
      uVar15 = *(undefined8 *)(param_1 + -0x11);
      *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100dd3;
      func_0x(uVar15,0x12);
      uStack_a6 = *(uint *)(param_1 + -0x13);
    }
    if ((uStack_a6 == 0) || (0x3f3c < uStack_a6)) {
      *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100df7;
      cVar10 = func_0x(0x10ed4e0);
      if (cVar10 != '\0') {
        *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100e00;
        lVar14 = func_0x();
        if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
          *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100e1a;
          cVar10 = func_0x(0x10ed4e0);
          if (cVar10 == '\0') {
            *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100e36;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)((longlong)&puStack_d8 + lVar12) = 0;
            *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100e5c;
            (*_DAT_)(1,0x9dceec,0xafcfd8,0x88b);
          }
        }
      }
      uVar15 = *(undefined8 *)(param_1 + -0x11);
      *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100e6a;
      func_0x(uVar15,5);
      uStack_a6 = *(uint *)(param_1 + -0x13);
    }
  }
LAB_:
  uVar20 = uStack_c0;
  uStack_9a = *(undefined4 *)(param_1 + -0xd);
  uStack_a8 = param_1[-0x14];
  uStack_8e = param_1[-7];
  uStack_96 = *(uint *)(param_1 + -0xb);
  uStack_92 = *(uint *)(param_1 + -9);
  uStack_84 = *(undefined4 *)(param_1 + -2);
  *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100ed2;
  func_0x(uVar20);
  uStack_a2 = uStack_c0;
  *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100ee3;
  iVar32 = func_0x(&uStack_a8);
  uVar20 = uStack_a2;
  if (iVar32 == 0) {
    uVar23 = (ulonglong)uStack_7e;
    uVar28 = (ulonglong)uStack_80;
  }
  else {
    puVar31 = (ushort *)(uStack_96 + uStack_a2);
    uVar26 = *puVar31 - 1;
    if ((uStack_a8 & 1) == 0) {
      uVar26 = (uint)*puVar31;
    }
    uVar25 = uStack_92;
    if (uVar26 != 1) {
      uVar25 = puVar31[(longlong)(int)uVar26 + -1] & 0x7fff;
    }
    uVar26 = puVar31[(int)uVar26] & 0x7fff;
    if (((uVar25 < uStack_92) || (uVar26 < uVar25)) || (uStack_a6 < uVar26)) {
      *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100f43;
      func_0x(uVar20,7);
    }
    uVar28 = (ulonglong)(uVar25 & 0xffff);
    uVar20 = uVar28 + uStack_a2;
    uStack_80 = (ushort)uVar25;
    if ((*(ushort *)(uVar20 + 2) >> 0xe & 1) == 0) {
      uVar21 = uStack_7e & 0xc7ff;
    }
    else {
      uVar21 = uStack_7e ^ (*(ushort *)(uVar20 + 2) ^ uStack_7e) & 0x3800;
    }
    uStack_7e = (uVar21 ^ *(ushort *)(uVar20 + 2)) & 0x7ff ^ uVar21;
    uVar23 = (ulonglong)((uStack_7e & 0x7ff) * 2) + 4 + uStack_a2 + (uVar21 >> 0xb & 7) * 2 + uVar28
    ;
    if (uVar23 < uVar20) {
      *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x100fd8;
      func_0x(uVar20,0x19);
      uVar28 = (ulonglong)uStack_80;
    }
    if (uVar26 - uVar25 < (((uStack_7e & 0x7ff) * 2 - (int)uVar28) - (int)uStack_a2) + (int)uVar23)
    {
      lVar14 = uVar28 + uStack_a2;
      *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x10100f;
      func_0x(lVar14,0x19);
      uVar28 = (ulonglong)uStack_80;
    }
    uVar23 = (ulonglong)uStack_7e;
    uVar20 = uStack_a2;
    if ((uStack_7e & 0x3800) != 0) {
      puVar31 = (ushort *)(uStack_a2 + 4 + uVar28);
      iVar32 = 0;
      if ((uStack_7e & 0x3800) != 0) {
        do {
          if (((ushort)uVar23 & 0x7ff) < (*puVar31 & 0x7ff)) {
            *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x101065;
            func_0x(uVar28 + uVar20,0x1a);
            uVar23 = (ulonglong)uStack_7e;
            uVar28 = (ulonglong)uStack_80;
            uVar20 = uStack_a2;
          }
          iVar32 = iVar32 + 1;
          puVar31 = puVar31 + 1;
        } while (iVar32 < (int)((uint)(uVar23 >> 0xb) & 7));
      }
    }
  }
  uVar25 = (uint)uVar23;
  uVar4 = uVar23 & 0x7ff;
  uVar26 = uVar25 & 0x7ff;
  uVar16 = ((ulonglong)uVar26 + 1) * 0x20;
  uVar18 = uVar16 + 0xf;
  if (uVar18 <= uVar16) {
    uVar18 = 0xffffffffffffff0;
  }
  uVar18 = uVar18 & 0xfffffffffffffff0;
  *(undefined8 *)((longlong)auStack_100 + lVar12) = 0x1010cb;
  func_0x();
  lVar14 = -uVar18;
  puStack_b8 = (ushort *)((longlong)auStack_c8 + lVar14 + lVar12);
  if (uVar4 != 0) {
    uVar22 = uVar25 >> 0xb & 7;
    lStack_70 = uVar20 + uVar28;
    uVar25 = uVar22 * 2;
    lStack_50 = (ulonglong)uVar25 + 4 + uVar20 + uVar28;
    puStack_b0 = (ushort *)(lStack_70 + 4);
    lStack_78 = (ulonglong)uVar25 + uVar26 * 2 + uVar20 + uVar28 + 4;
    uVar25 = (((int)uVar28 + (uVar22 + 2 + uVar26 * 2) * 2) - (int)lStack_70) + (int)uStack_a2;
    iVar32 = 0;
    uStack_c0 = uStack_c0 & 0xffffffff00000000;
    uVar18 = 0;
    lVar24 = 0;
    uVar21 = uStack_5c._2_2_;
    do {
      lVar29 = lStack_70;
      if ((uVar23 & 0x3800) == 0) {
        uVar11 = *(ushort *)(uVar28 + 2 + uVar20);
        uVar22 = (uint)uVar23 & 0xffff;
      }
      else {
        if ((int)((uint)((uVar23 & 0xffff) >> 0xb) & 7) <= iVar32) {
          *(undefined8 *)((longlong)auStack_100 + lVar14 + lVar12) = 0x101186;
          func_0x(lVar29,0x1b);
          uVar23 = (ulonglong)uStack_7e;
          uVar28 = (ulonglong)uStack_80;
          uVar20 = uStack_a2;
          iVar32 = (int)uStack_c0;
        }
        uVar11 = *puStack_b0;
        uVar22 = (uint)uVar11;
      }
      lVar29 = (ulonglong)(uVar22 & 0x7ff) - 1;
      if (lVar24 <= lVar29) {
        puVar31 = (ushort *)(lStack_78 + lVar24 * 2);
        puVar27 = (uint *)(puStack_b8 + lVar24 * 0x10 + 6);
        uVar20 = uVar18;
        uVar30 = uVar21;
        do {
          uVar18 = uVar20;
          uVar21 = uVar30;
          if ((longlong)(ulonglong)uVar26 <= lVar24) break;
          lVar24 = lVar24 + 1;
          uStack_60 = (uint)*(ushort *)((lStack_50 - lStack_78) + (longlong)puVar31) +
                      (uint)(uVar11 >> 0xb & 7) * 0x10000 | 0x80000000;
          uVar1 = *puVar31;
          uVar21 = uVar30 & 0xfff0;
          uVar18 = (ulonglong)((int)uVar20 + 1);
          uStack_5c = (uVar30 & 0xfff0) << 0x10;
          uVar30 = *(ushort *)(lStack_78 + uVar20 * 2);
          *(ulonglong *)(puVar27 + -3) = (ulonglong)uVar25 + lStack_70;
          puVar27[-1] = (uVar1 & 0x7fff) - uVar25;
          *puVar27 = (uint)(uVar30 >> 0xf) | *puVar27 & 0xfffffff0;
          puVar27[1] = uStack_60;
          puVar27[2] = uStack_5c;
          puVar27[3] = uStack_58;
          puVar27[4] = uStack_54;
          puVar27 = puVar27 + 8;
          uVar25 = *puVar31 & 0x7fff;
          puVar31 = puVar31 + 1;
          uVar20 = uVar18;
          uVar30 = uVar21;
        } while (lVar24 <= lVar29);
        uVar23 = (ulonglong)uStack_7e;
        uVar28 = (ulonglong)uStack_80;
        uVar20 = uStack_a2;
        iVar32 = (int)uStack_c0;
      }
      iVar32 = iVar32 + 1;
      puStack_b0 = puStack_b0 + 1;
      uStack_c0 = CONCAT44(uStack_c0._4_4_,iVar32);
      param_1 = puStack_48;
    } while (lVar24 < (longlong)(ulonglong)uVar26);
  }
  uVar15 = uStack_68;
  puVar31 = puStack_b8;
  if ((param_5 < 0) || ((int)((uint)uVar23 & 0x7ff) <= param_5)) {
    puVar19 = (undefined8 *)(puStack_b8 + (uVar23 & 0x7ff) * 0x10);
    *(uint *)((longlong)puVar19 + 0xc) = *(uint *)((longlong)puVar19 + 0xc) & 0xfffffffa;
    *puVar19 = uVar15;
    *(undefined4 *)(puVar19 + 1) = auStack_c8[0];
    uVar5 = *puStack_40;
    uVar6 = puStack_40[1];
    uVar7 = puStack_40[2];
    uVar8 = puStack_40[3];
    *(uint *)((longlong)puVar19 + 0xc) = *(uint *)((longlong)puVar19 + 0xc) & 0xfffffff5;
    *(undefined4 *)(puVar19 + 2) = uVar5;
    *(undefined4 *)((longlong)puVar19 + 0x14) = uVar6;
    *(undefined4 *)(puVar19 + 3) = uVar7;
    *(undefined4 *)((longlong)puVar19 + 0x1c) = uVar8;
    uVar21 = (uStack_7e & 0x7ff) + 1;
  }
  else {
    *(undefined8 *)(puStack_b8 + (longlong)param_5 * 0x10) = uStack_68;
    *(undefined4 *)(puVar31 + (longlong)param_5 * 0x10 + 4) = auStack_c8[0];
    uVar21 = uStack_7e & 0x7ff;
  }
  uVar11 = *param_1;
  *(undefined4 **)((longlong)&puStack_d8 + lVar14 + lVar12 + 8) = auStack_c8;
  *(ushort **)((longlong)&puStack_d8 + lVar14 + lVar12) = puVar31;
  *(undefined8 *)((longlong)auStack_100 + lVar14 + lVar12) = 0x10134e;
  func_0x(param_1,uVar11,0x1f9e,uVar21);
  uVar20 = uStack_38 ^ (ulonglong)auStack_c8;
  *(undefined8 *)((longlong)auStack_100 + lVar14 + lVar12) = 0x101360;
  func_0x(uVar20);
  return;
code_r0x00100429:
  uVar20 = (ulonglong)uVar21;
  uVar23 = (ulonglong)(uint)uVar21;
  if (-1 < (short)puVar31[(ulonglong)(uVar21 - 1) + 1]) goto LAB_;
  goto LAB_;
code_r0x00100b5d:
  uVar20 = (ulonglong)uVar21;
  uVar23 = (ulonglong)(uint)uVar21;
  if (-1 < (short)puVar31[(ulonglong)(uVar21 - 1) + 1]) goto LAB_;
  goto LAB_;
}

