
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1,int param_2)

{
  byte *pbVar1;
  
  pbVar1 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - (longlong)param_2) * 2) + param_1);
  if ((*pbVar1 & 1) == 0) {
                    /* WARNING: Could not emulate address calculation at 0x00100091 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0xfffb0) + 0x63e20))();
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

