
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint param_2,longlong param_3,ushort *param_4,longlong param_5)

{
  int *piVar1;
  uint *puVar2;
  int iVar3;
  uint *puVar4;
  longlong lVar5;
  ushort *puVar6;
  uint uVar7;
  byte bVar8;
  char cVar9;
  ushort uVar10;
  ushort uVar11;
  undefined8 uVar12;
  int **ppiVar13;
  byte *pbVar14;
  ulonglong uVar15;
  int iVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  longlong lVar20;
  ulonglong uVar21;
  ulonglong uVar22;
  ushort *puVar23;
  uint uStack_68;
  longlong lStack_60;
  undefined auStack_58 [8];
  longlong lStack_50;
  longlong lStack_48;
  longlong lStack_40;
  
  lStack_48 = param_5;
  uStack_68 = 0;
  if (param_2 != 0) {
    lStack_60 = 0;
    lStack_50 = param_3;
    lStack_40 = param_1;
    do {
      puVar4 = *(uint **)(lStack_40 + lStack_60 * 8);
      bVar8 = **(byte **)(param_3 + 6);
      if ((bVar8 & 0x10) == 0) {
        if ((1 << (bVar8 & 0xe) & 0x1105U) != 0) {
LAB_:
          uVar17 = *puVar4;
          lVar20 = (longlong)(int)uVar17;
          iVar3 = **(int **)(puVar4 + 2);
          piVar1 = *(int **)(puVar4 + 2) + 1;
          if ((int)uVar17 < 0) {
            ppiVar13 = (int **)((longlong)(int)~uVar17 * 0x20 + param_5);
            *(uint *)((longlong)ppiVar13 + 0xc) = *(uint *)((longlong)ppiVar13 + 0xc) & 0xfffffffa;
            *ppiVar13 = piVar1;
            *(int *)(ppiVar13 + 1) = iVar3;
            uVar17 = *puVar4;
            uVar18 = puVar4[1];
            uVar19 = puVar4[2];
            uVar7 = puVar4[3];
            *(uint *)((longlong)ppiVar13 + 0xc) = *(uint *)((longlong)ppiVar13 + 0xc) & 0xfffffff5;
            *(uint *)(ppiVar13 + 2) = uVar17;
            *(uint *)((longlong)ppiVar13 + 0x14) = uVar18;
            *(uint *)(ppiVar13 + 3) = uVar19;
            *(uint *)((longlong)ppiVar13 + 0x1c) = uVar7;
            puVar2 = (uint *)((longlong)(int)~*puVar4 * 0x20 + 0xc + param_5);
            *puVar2 = *puVar2 | 8;
          }
          else {
            uVar18 = (uint)*(ushort *)((longlong)puVar4 + 6);
            if ((*(ushort *)((longlong)puVar4 + 6) & 8) == 0) {
              if (*(int *)(param_4 + 1) == 0) {
                pbVar14 = *(byte **)(param_4 + 3);
                iVar16 = 0;
                uVar17 = *(uint *)(param_4 + 7);
                uVar15 = (ulonglong)uVar17;
                *param_4 = 0;
                *(uint *)(param_4 + 9) = uVar17;
                bVar8 = *pbVar14;
                if ((bVar8 & 0x10) != 0) {
                  uVar17 = uVar17 + 2 + (*(ushort *)(pbVar14 + uVar15) + 7 >> 3);
                  uVar15 = (ulonglong)uVar17;
                  *(uint *)(param_4 + 9) = uVar17;
                  bVar8 = *pbVar14;
                }
                if ((bVar8 & 0x20) == 0) {
                  *(int *)(param_4 + 1) = (int)uVar15;
                  param_4[0xd] = 0;
                  *(int *)(param_4 + 0xb) = (int)uVar15;
                }
                else {
                  puVar23 = (ushort *)(pbVar14 + uVar15);
                  uVar10 = *puVar23;
                  param_4[0xd] = uVar10;
                  if (uVar10 == 0) {
                    cVar9 = func_0x(0x1ef0e20);
                    if (((cVar9 != '\0') && (lVar20 = func_0x(), lVar20 != 0)) &&
                       (*(char *)(lVar20 + 0x499) != '\0')) {
                      cVar9 = func_0x(0x1ef0e20);
                      if (cVar9 == '\0') {
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        (*_DAT_)(1,0x17e082c,0x1900918,0x80f,0);
                      }
                    }
                    func_0x(*(undefined8 *)(param_4 + 3),3);
                    uVar15 = (ulonglong)*(uint *)(param_4 + 9);
                    pbVar14 = *(byte **)(param_4 + 3);
                    uVar10 = param_4[0xd];
                  }
                  uVar17 = (int)uVar15 + (uVar10 + 1) * 2;
                  *(uint *)(param_4 + 0xb) = uVar17;
                  if (0x1f9e < uVar17) {
                    cVar9 = func_0x(0x1ef0e20);
                    if (((cVar9 != '\0') && (lVar20 = func_0x(), lVar20 != 0)) &&
                       (*(char *)(lVar20 + 0x499) != '\0')) {
                      cVar9 = func_0x(0x1ef0e20);
                      if (cVar9 == '\0') {
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        (*_DAT_)(1,0x17e082c,0x1900918,0x816,0);
                      }
                    }
                    func_0x(*(undefined8 *)(param_4 + 3),4);
                    uVar10 = param_4[0xd];
                    pbVar14 = *(byte **)(param_4 + 3);
                    uVar17 = *(uint *)(param_4 + 0xb);
                  }
                  uVar15 = (ulonglong)uVar10;
                  uVar10 = puVar23[uVar15];
                  *(uint *)(param_4 + 1) = uVar10 & 0x7fff;
                  if ((uVar10 & 0x7fff) < uVar17) {
                    cVar9 = func_0x(0x1ef0e20);
                    if (((cVar9 != '\0') && (lVar20 = func_0x(), lVar20 != 0)) &&
                       (*(char *)(lVar20 + 0x499) != '\0')) {
                      cVar9 = func_0x(0x1ef0e20);
                      if (cVar9 == '\0') {
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        (*_DAT_)(1,0x17e082c,0x1900918,0x81d,0);
                      }
                    }
                    func_0x(*(undefined8 *)(param_4 + 3),4);
                    uVar17 = *(uint *)(param_4 + 0xb);
                    uVar15 = (ulonglong)param_4[0xd];
                    pbVar14 = *(byte **)(param_4 + 3);
                  }
                  puVar6 = puVar23;
                  if ((short)uVar15 != 0) {
                    do {
                      uVar18 = puVar6[1] & 0x7fff;
                      if ((uVar18 < uVar17) || (*(uint *)(param_4 + 1) < uVar18)) {
                        cVar9 = func_0x(0x1ef0e20);
                        if ((cVar9 != '\0') &&
                           ((lVar20 = func_0x(), lVar20 != 0 &&
                            (*(char *)(lVar20 + 0x499) != '\0')))) {
                          cVar9 = func_0x(0x1ef0e20);
                          if (cVar9 == '\0') {
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            (*_DAT_)(1,0x17e082c,0x1900918,0x82a,0);
                          }
                        }
                        func_0x(*(undefined8 *)(param_4 + 3),4);
                      }
                      uVar15 = (ulonglong)param_4[0xd];
                      iVar16 = iVar16 + 1;
                      uVar17 = uVar18;
                      puVar6 = puVar6 + 1;
                    } while (iVar16 < (int)(uint)param_4[0xd]);
                    pbVar14 = *(byte **)(param_4 + 3);
                  }
                  if ((short)puVar23[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
                    do {
                      uVar17 = *(ushort *)(pbVar14 + uVar15 * 2 + (ulonglong)*(uint *)(param_4 + 9))
                               & 0x7fff;
                      if ((int)uVar15 == 1) {
                        uVar18 = *(uint *)(param_4 + 0xb);
                        uVar21 = (ulonglong)uVar18;
LAB_:
                        if ((uVar17 < (uint)uVar21) || (*(uint *)(param_4 + 1) < uVar17))
                        goto LAB_;
                      }
                      else {
                        uVar18 = *(uint *)(param_4 + 0xb);
                        uVar21 = (ulonglong)
                                 (*(ushort *)
                                   (pbVar14 + uVar15 * 2 + ((ulonglong)*(uint *)(param_4 + 9) - 2))
                                 & 0x7fff);
                        if (uVar18 <= (*(ushort *)
                                        (pbVar14 +
                                        uVar15 * 2 + ((ulonglong)*(uint *)(param_4 + 9) - 2)) &
                                      0x7fff)) goto LAB_;
LAB_:
                        func_0x(pbVar14,7);
                        uVar18 = *(uint *)(param_4 + 0xb);
                        pbVar14 = *(byte **)(param_4 + 3);
                      }
                      uVar19 = (uint)uVar21;
                      if ((uVar19 < uVar18) || (*(uint *)(param_4 + 1) < uVar19)) goto LAB_;
                      if (*(ushort *)(pbVar14 + uVar21) == 5) {
                        *param_4 = *param_4 | 2;
                        param_4[0xd] = param_4[0xd] - 1;
                        uVar22 = uVar21 & 0xffff;
                        param_4[0x14] = (ushort)uVar21;
                        uVar15 = *(ulonglong *)(param_4 + 3);
                        uVar10 = param_4[0x15] & 0xc7ff;
                        if ((*(ushort *)(uVar22 + 2 + uVar15) >> 0xe & 1) != 0) {
                          uVar10 = *(ushort *)(uVar22 + 2 + uVar15) & 0x3800 |
                                   param_4[0x15] & 0xc7ff;
                        }
                        param_4[0x15] = uVar10;
                        uVar11 = (uVar10 ^ *(ushort *)(uVar22 + 2 + uVar15)) & 0x7ff ^ uVar10;
                        param_4[0x15] = uVar11;
                        uVar21 = uVar15 + 4 +
                                 (ulonglong)((uVar11 & 0x7ff) * 2) +
                                 uVar22 + (uVar10 >> 0xb & 7) * 2;
                        if (uVar21 < uVar22 + uVar15) {
                          func_0x(uVar22 + uVar15,0x19);
                          uVar11 = param_4[0x15];
                          uVar22 = (ulonglong)param_4[0x14];
                          uVar15 = (ulonglong)*(uint *)(param_4 + 3);
                        }
                        if (uVar17 - uVar19 <
                            (((uVar11 & 0x7ff) * 2 - (int)uVar22) - (int)uVar15) + (int)uVar21) {
                          func_0x(uVar22 + *(longlong *)(param_4 + 3),0x19);
                          uVar11 = param_4[0x15];
                        }
                        if ((uVar11 & 0x3800) != 0) {
                          puVar23 = (ushort *)
                                    (*(longlong *)(param_4 + 3) + (ulonglong)param_4[0x14] + 4);
                          iVar16 = 0;
                          if ((uVar11 & 0x3800) != 0) {
                            do {
                              if ((uVar11 & 0x7ff) < (*puVar23 & 0x7ff)) {
                                func_0x((ulonglong)param_4[0x14] +
                                                *(longlong *)(param_4 + 3),0x1a);
                                uVar11 = param_4[0x15];
                              }
                              iVar16 = iVar16 + 1;
                              puVar23 = puVar23 + 1;
                            } while (iVar16 < (int)(uVar11 >> 0xb & 7));
                          }
                        }
                        pbVar14 = *(byte **)(param_4 + 3);
                        goto LAB_;
                      }
                      if (*(ushort *)(pbVar14 + uVar21) < 0x400) goto LAB_;
                      *param_4 = *param_4 | 1;
                      uVar10 = param_4[0xd] - 1;
                      param_4[0xd] = uVar10;
                      if (uVar10 == 0) goto LAB_;
                      uVar15 = (ulonglong)uVar10;
                    } while ((short)puVar23[(ulonglong)(uVar10 - 1) + 1] < 0);
                    uVar15 = (ulonglong)*(uint *)(param_4 + 1);
                  }
                  else {
LAB_:
                    uVar15 = (ulonglong)*(uint *)(param_4 + 1);
                  }
                }
                if ((*pbVar14 & 0x40) == 0) {
                  *(undefined4 *)(param_4 + 0x12) = 0;
                }
                else {
                  *(int *)(param_4 + 0x12) = (int)uVar15;
                  *(int *)(param_4 + 1) = (int)uVar15 + 0xe;
                  uVar12 = func_0x(param_4);
                  func_0x(uVar12,auStack_58);
                  iVar16 = func_0x(auStack_58);
                  *(int *)(param_4 + 1) = *(int *)(param_4 + 1) + iVar16;
                  uVar15 = (ulonglong)*(uint *)(param_4 + 1);
                  pbVar14 = *(byte **)(param_4 + 3);
                }
                if ((*(byte **)(param_4 + 0xe) != (byte *)0x0) &&
                   (*(byte **)(param_4 + 0xe) < pbVar14 + uVar15)) {
                  cVar9 = func_0x(0x1ef0e20);
                  if ((cVar9 != '\0') &&
                     ((lVar20 = func_0x(), lVar20 != 0 &&
                      (*(char *)(lVar20 + 0x499) != '\0')))) {
                    cVar9 = func_0x(0x1ef0e20);
                    if (cVar9 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      (*_DAT_)(1,0x17e082c,0x1900918,0x886,0);
                    }
                  }
                  func_0x(*(undefined8 *)(param_4 + 3),0x12);
                  uVar15 = (ulonglong)*(uint *)(param_4 + 1);
                }
                if (0x3f3b < (int)uVar15 - 1U) {
                  cVar9 = func_0x(0x1ef0e20);
                  if (((cVar9 != '\0') && (lVar20 = func_0x(), lVar20 != 0)) &&
                     (*(char *)(lVar20 + 0x499) != '\0')) {
                    cVar9 = func_0x(0x1ef0e20);
                    if (cVar9 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      (*_DAT_)(1,0x17e082c,0x1900918,0x88b,0);
                    }
                  }
                  func_0x(*(undefined8 *)(param_4 + 3),5);
                }
              }
LAB_:
              uVar17 = *puVar4 + iVar3;
              if (*(uint *)(param_4 + 7) < uVar17) {
                func_0x(param_4,0,uVar17 - *(uint *)(param_4 + 7),0);
                if ((1 << (**(byte **)(param_4 + 3) & 0xe) & 0x1105U) != 0) {
                  *(short *)(*(byte **)(param_4 + 3) + 2) = (short)uVar17;
                }
                *(uint *)(param_4 + 7) = uVar17;
              }
              if ((piVar1 != (int *)0x0) && (iVar3 != 0)) {
                func_0x
                          ((longlong)(int)*puVar4 + *(longlong *)(param_4 + 3),piVar1,iVar3);
              }
            }
            else {
              uVar17 = uVar17 + 1;
              cVar9 = *(char *)piVar1;
              if (*(uint *)(param_4 + 7) < uVar17) {
                func_0x(param_4,0,uVar17 - *(uint *)(param_4 + 7),0);
                if ((1 << (**(byte **)(param_4 + 3) & 0xe) & 0x1105U) != 0) {
                  *(short *)(*(byte **)(param_4 + 3) + 2) = (short)uVar17;
                }
                *(uint *)(param_4 + 7) = uVar17;
                uVar18 = (uint)*(byte *)((longlong)puVar4 + 6);
              }
              lVar5 = *(longlong *)(param_4 + 3);
              if (cVar9 == '\0') {
                *(byte *)(lVar5 + lVar20) = *(byte *)(lVar5 + lVar20) & ~(byte)(1 << (uVar18 & 7));
              }
              else {
                *(byte *)(lVar5 + lVar20) = *(byte *)(lVar5 + lVar20) | (byte)(1 << (uVar18 & 7));
              }
            }
          }
          lVar20 = (ulonglong)(*(ushort *)(puVar4 + 1) - 1 >> 3) + (longlong)*(int *)(param_4 + 7) +
                   *(longlong *)(param_4 + 3);
          *(byte *)(lVar20 + 2) =
               *(byte *)(lVar20 + 2) & ~(byte)(1 << (*(ushort *)(puVar4 + 1) - 1 & 7));
          param_3 = lStack_50;
          param_5 = lStack_48;
        }
      }
      else if (((int)*(uint *)(param_3 + 0xe) <= (int)*puVar4) ||
              (*(ushort *)(*(byte **)(param_3 + 6) + *(uint *)(param_3 + 0xe)) <
               *(ushort *)(puVar4 + 1))) goto LAB_;
      uStack_68 = uStack_68 + 1;
      lStack_60 = lStack_60 + 1;
    } while (uStack_68 < param_2);
  }
  return;
}

