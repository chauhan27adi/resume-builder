
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined4 param_2,undefined4 *param_3,longlong param_4)

{
  undefined8 *puVar1;
  byte *pbVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong lVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  longlong lVar12;
  longlong lVar13;
  ulonglong uVar14;
  ushort uVar15;
  undefined8 unaff_RBX;
  ulonglong uVar16;
  longlong lVar17;
  longlong lVar18;
  int iVar19;
  longlong unaff_GS_OFFSET;
  undefined4 auStackX_8 [4];
  undefined8 auStackX_18 [2];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  puVar1 = (undefined8 *)((longlong)auStackX_18 + lVar12);
  *puVar1 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002120 + lVar12) = unaff_RBX;
  *(ulonglong *)(&stack0x000020c8 + lVar12) = _DAT_ ^ (ulonglong)puVar1;
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10005a;
  func_0x(&stack0x00000028 + lVar12,&stack0x00000130 + lVar12);
  *(undefined8 *)(&stack0x00000028 + lVar12) = 0x853ef8;
  uVar4 = *param_3;
  *(undefined4 *)(&stack0x000000b0 + lVar12) = 0;
  *(undefined2 *)(&stack0x000000b4 + lVar12) = 0;
  *(undefined4 *)((longlong)auStackX_8 + lVar12) = 0;
  uVar16 = 0x10;
  *(undefined8 *)((longlong)auStackX_18 + lVar12 + -0x18) = 0x10;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar12) = 2;
  *(undefined4 *)(&stack0xfffffffffffffff0 + lVar12) = 8;
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar12) = uVar4;
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1000ad;
  func_0x(&stack0x00000028 + lVar12,param_1,0,0);
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1000b6;
  func_0x(&stack0x00000028 + lVar12);
  if ((((*(uint *)(&stack0x00000064 + lVar12) & 0x800) != 0) &&
      (*(int *)(&stack0x00000048 + lVar12) == 0)) && (*(short *)(&stack0x0000004c + lVar12) == 0)) {
    lVar7 = *(longlong *)(&stack0x00000078 + lVar12);
    if ((*(byte *)(lVar7 + 0xc) & 0xf) == 0) {
      uVar16 = (ulonglong)*(ushort *)(lVar7 + 0xe);
    }
    else {
      uVar15 = (*(short *)(lVar7 + 0x10) + 1) * 0xc;
      uVar16 = (ulonglong)uVar15;
      if (uVar15 == 0x10) goto LAB_;
    }
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100118;
    (*_DAT_)(1,0xc95f60,0xc40ec0,0xe5f);
  }
LAB_:
  uVar14 = uVar16 + 0xf;
  if (uVar14 <= uVar16) {
    uVar14 = 0xffffffffffffff0;
  }
  uVar14 = uVar14 & 0xfffffffffffffff0;
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10013a;
  func_0x();
  lVar9 = -uVar14;
  lVar7 = (longlong)auStackX_18 + lVar9 + lVar12;
  iVar19 = (int)uVar16;
  *(undefined8 *)((longlong)&uStack_40 + lVar9 + lVar12) = 0x100155;
  func_0x(&stack0x00000028 + lVar12,uVar16,lVar7);
  *(undefined8 *)((longlong)&uStack_40 + lVar9 + lVar12) = 0x10015e;
  func_0x(&stack0x00000028 + lVar12);
  lVar18 = (ulonglong)*(uint *)(param_4 + 4) * 0x40;
  pbVar2 = (byte *)(lVar18 + 0x18 + *(longlong *)(param_4 + 8));
  *pbVar2 = *pbVar2 & 0xfb;
  if (*(uint *)(param_4 + 0x20) < (uint)(*(int *)(param_4 + 0x10) + iVar19)) {
    lVar17 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar13 = *(longlong *)(lVar17 + 0x100);
    if (lVar13 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9 + lVar12) = 0x1001b0;
      (*_DAT_)(0);
      lVar13 = *(longlong *)(lVar17 + 0x100);
    }
    (&stack0xffffffffffffffe8)[lVar9 + lVar12] = 5;
    uVar8 = *(undefined8 *)(lVar13 + 1000);
    *(undefined8 *)((longlong)&uStack_40 + lVar9 + lVar12) = 0x1001db;
    lVar13 = (*_DAT_)(0x1f9e,uVar8,0xbd7928,0xda);
    if (lVar13 == 0) {
      lVar13 = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar9 + lVar12) = 0x1001f3;
      func_0x(lVar13,0,0x1f9e);
    }
    *(longlong *)(param_4 + 0x18) = lVar13;
    *(undefined4 *)(param_4 + 0x10) = 0;
    pbVar2 = (byte *)(lVar18 + 0x18 + *(longlong *)(param_4 + 8));
    *pbVar2 = *pbVar2 | 4;
    *(undefined4 *)(param_4 + 0x20) = 0x1f9e;
  }
  uVar4 = param_3[1];
  uVar10 = param_3[2];
  uVar11 = param_3[3];
  puVar3 = (undefined4 *)(lVar18 + 8 + *(longlong *)(param_4 + 8));
  *puVar3 = *param_3;
  puVar3[1] = uVar4;
  puVar3[2] = uVar10;
  puVar3[3] = uVar11;
  *(undefined4 *)(lVar18 + *(longlong *)(param_4 + 8)) = param_2;
  pbVar2 = (byte *)(lVar18 + 0x18 + *(longlong *)(param_4 + 8));
  *pbVar2 = *pbVar2 & 0xfe;
  pbVar2 = (byte *)(lVar18 + 0x18 + *(longlong *)(param_4 + 8));
  *pbVar2 = *pbVar2 & 0xfd;
  lVar18 = *(longlong *)(param_4 + 8) + lVar18;
  *(ulonglong *)(lVar18 + 0x20) =
       (ulonglong)*(uint *)(param_4 + 0x10) + *(longlong *)(param_4 + 0x18);
  *(int *)(lVar18 + 0x28) = iVar19;
  uVar5 = *(uint *)(lVar18 + 0x2c);
  *(uint *)(lVar18 + 0x2c) = uVar5 & 0xfffffffb | 1;
  uVar4 = param_3[1];
  uVar10 = param_3[2];
  uVar11 = param_3[3];
  *(undefined4 *)(lVar18 + 0x30) = *param_3;
  *(undefined4 *)(lVar18 + 0x34) = uVar4;
  *(undefined4 *)(lVar18 + 0x38) = uVar10;
  *(undefined4 *)(lVar18 + 0x3c) = uVar11;
  *(uint *)(lVar18 + 0x2c) = uVar5 & 0xfffffff1 | 1;
  uVar5 = *(uint *)(param_4 + 0x10);
  iVar6 = *(int *)(param_4 + 0x20);
  lVar18 = *(longlong *)(param_4 + 0x18);
  *(undefined8 *)((longlong)&uStack_40 + lVar9 + lVar12) = 0x100282;
  func_0x((ulonglong)uVar5 + lVar18,iVar6 - uVar5,lVar7,uVar16);
  *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + 1;
  *(int *)(param_4 + 0x10) = *(int *)(param_4 + 0x10) + iVar19;
  *(undefined8 *)((longlong)&uStack_40 + lVar9 + lVar12) = 0x100292;
  func_0x(&stack0x00000028 + lVar12);
  uVar16 = *(ulonglong *)(&stack0x000020c8 + lVar12);
  *(undefined8 *)((longlong)&uStack_40 + lVar9 + lVar12) = 0x1002a1;
  func_0x(uVar16 ^ (ulonglong)puVar1);
  return;
}

