
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined8 param_2,undefined8 param_3)

{
  char *pcVar1;
  char cVar2;
  undefined2 uVar3;
  code *pcVar4;
  uint *puVar5;
  uint6 uVar6;
  undefined *puVar7;
  bool bVar8;
  bool bVar9;
  undefined uVar10;
  char cVar11;
  char cVar12;
  ushort uVar13;
  ushort uVar14;
  ushort uVar15;
  int iVar16;
  undefined4 uVar17;
  int iVar18;
  longlong lVar19;
  longlong *plVar20;
  longlong *plVar21;
  longlong lVar22;
  undefined8 *puVar23;
  ulonglong *puVar24;
  ulonglong uVar25;
  longlong lVar26;
  undefined8 uVar27;
  longlong *plVar28;
  longlong lVar29;
  undefined8 uVar30;
  byte bVar31;
  byte *pbVar32;
  short sVar33;
  uint uVar34;
  undefined8 unaff_RBX;
  ushort *puVar35;
  ulonglong uVar36;
  byte *pbVar37;
  byte *pbVar38;
  undefined *puVar39;
  undefined *puVar40;
  char cVar41;
  ulonglong uVar42;
  uint uVar43;
  undefined *puVar44;
  ulonglong uVar45;
  int iVar46;
  short *psVar47;
  byte *pbVar48;
  uint uVar49;
  uint uVar50;
  ushort *puVar51;
  longlong unaff_GS_OFFSET;
  bool bVar52;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar19 = func_0x();
  lVar19 = -lVar19;
  puVar39 = &stack0xffffffffffffffc8 + lVar19;
  pcVar1 = &stack0x00000038 + lVar19;
  *(undefined8 *)(&stack0x000001f0 + lVar19) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000051c0 + lVar19) = unaff_RBX;
  *(ulonglong *)(&stack0x00005158 + lVar19) = _DAT_ ^ (ulonglong)pcVar1;
  *(undefined8 *)(&stack0x00000110 + lVar19) = param_3;
  *(undefined8 *)(&stack0x000000b0 + lVar19) = param_2;
  *(longlong **)(&stack0x000000a8 + lVar19) = param_1;
  lVar22 = *(longlong *)(param_1[5] + 8);
  *(longlong *)(&stack0x000000d0 + lVar19) = lVar22;
  *(undefined8 *)(&stack0x00000168 + lVar19) = *(undefined8 *)(lVar22 + 0x30);
  uVar34 = *(uint *)(param_1 + 2);
  *(uint *)(param_1 + 2) = uVar34 & 0xfffffeff;
  if (((char)(uVar34 & 0xfffffeff) < '\0') || ((*(byte *)((longlong)param_1 + 0x34) & 1) == 0)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10008e;
    plVar20 = (longlong *)func_0x();
  }
  else {
    plVar20 = param_1 + 9;
  }
  *(undefined4 *)(&stack0x000000cc + lVar19) = 0;
  if (*(short *)plVar20 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1000b1;
    func_0x();
  }
  else {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1000b8;
    func_0x((short *)((longlong)plVar20 + 2),&stack0x00000154 + lVar19);
  }
  iVar16 = *(int *)(&stack0x00000154 + lVar19);
  *(int *)(&stack0x000000f8 + lVar19) = iVar16;
  *(int *)(&stack0x00000040 + lVar19) = iVar16;
  sVar33 = *(short *)(&stack0x00000158 + lVar19);
  *(short *)(&stack0x0000011a + lVar19) = sVar33;
  *(short *)(&stack0x00000044 + lVar19) = sVar33;
  *(int *)(&stack0x0000011c + lVar19) = iVar16;
  *(short *)(&stack0x00000120 + lVar19) = sVar33;
  if (*(short *)plVar20 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100100;
    func_0x();
  }
  else {
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100107;
    func_0x((short *)((longlong)plVar20 + 2),&stack0x0000015a + lVar19);
  }
  *(undefined4 *)(&stack0x000000e8 + lVar19) = *(undefined4 *)(&stack0x0000015a + lVar19);
  *(undefined2 *)(&stack0x000000ec + lVar19) = *(undefined2 *)(&stack0x0000015e + lVar19);
  *(undefined2 *)(&stack0x000000ee + lVar19) = *(undefined2 *)(&stack0x00000160 + lVar19);
  bVar31 = *(byte *)plVar20[1] >> 1;
  if (*(short *)plVar20 == 0) {
    bVar31 = *(byte *)plVar20[1] >> 6;
  }
  puVar40 = &stack0xffffffffffffffc8 + lVar19;
  if (((bVar31 & 1) != 0) &&
     ((_DAT_ != sVar33 ||
      (puVar40 = &stack0xffffffffffffffc8 + lVar19, _DAT_ != iVar16)))) {
    lVar26 = *(longlong *)(&stack0x00000168 + lVar19);
    *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100189;
    iVar16 = func_0x(lVar26 + 0x19c8,&stack0x0000011c + lVar19,&stack0x000000e8 + lVar19);
    puVar40 = &stack0xffffffffffffffc8 + lVar19;
    if (iVar16 != 0) {
      *(undefined2 *)(&stack0x00000528 + lVar19) = 0xffff;
      *(undefined8 *)(&stack0x00000530 + lVar19) = 0;
      *(undefined4 *)(&stack0x0000052c + lVar19) = 0;
      *(undefined8 *)(&stack0x00000546 + lVar19) = 0;
      *(undefined8 *)(&stack0x00000550 + lVar19) = 0;
      *(undefined8 *)(&stack0x00000538 + lVar19) = 0;
      *(undefined4 *)(&stack0x0000055c + lVar19) = 0xffffffff;
      *(undefined2 *)(&stack0x000005e8 + lVar19) = 0xffff;
      *(undefined8 *)(&stack0x000005f0 + lVar19) = 0;
      *(undefined4 *)(&stack0x000005ec + lVar19) = 0;
      *(undefined8 *)(&stack0x00000606 + lVar19) = 0;
      *(undefined8 *)(&stack0x00000610 + lVar19) = 0;
      *(undefined8 *)(&stack0x000005f8 + lVar19) = 0;
      *(undefined4 *)(&stack0x0000061c + lVar19) = 0xffffffff;
      *(undefined2 *)(&stack0x00000698 + lVar19) = 0xffff;
      *(undefined8 *)(&stack0x000006a0 + lVar19) = 0;
      *(undefined4 *)(&stack0x0000069c + lVar19) = 0;
      *(undefined8 *)(&stack0x000006b6 + lVar19) = 0;
      *(undefined8 *)(&stack0x000006c0 + lVar19) = 0;
      *(undefined8 *)(&stack0x000006a8 + lVar19) = 0;
      *(undefined8 *)(&stack0x000006d0 + lVar19) = 0;
      *(undefined4 *)(&stack0x000006d8 + lVar19) = 0;
      *(undefined2 *)(&stack0x00000048 + lVar19) = 0xffff;
      *(undefined8 *)(&stack0x00000050 + lVar19) = 0;
      *(undefined4 *)(&stack0x0000004c + lVar19) = 0;
      *(undefined8 *)(&stack0x00000066 + lVar19) = 0;
      *(undefined8 *)(&stack0x00000070 + lVar19) = 0;
      *(undefined8 *)(&stack0x00000058 + lVar19) = 0;
      *(undefined8 *)(&stack0x00000098 + lVar19) = *(undefined8 *)param_1[5];
      *(undefined4 *)(&stack0x0000008c + lVar19) = 0;
      (&stack0x00000090)[lVar19] = 0;
      (&stack0x000000a0)[lVar19] = 0;
      *(undefined8 *)(&stack0x00000190 + lVar19) = 0;
      *(undefined8 *)(&stack0x000005d8 + lVar19) = 0;
      *(undefined4 *)(&stack0x000005e0 + lVar19) = 0;
      *(undefined2 *)(&stack0x000005e4 + lVar19) = 0;
      *pcVar1 = '\0';
      *(undefined2 *)(&stack0x00000700 + lVar19) = 0xffff;
      *(undefined8 *)(&stack0x00000708 + lVar19) = 0;
      *(undefined4 *)(&stack0x00000704 + lVar19) = 0;
      *(undefined8 *)(&stack0x0000071e + lVar19) = 0;
      *(undefined8 *)(&stack0x00000728 + lVar19) = 0;
      *(undefined8 *)(&stack0x00000710 + lVar19) = 0;
      *(undefined4 *)(&stack0x00000734 + lVar19) = 0xffffffff;
      (&stack0x00000080)[lVar19] = 0;
      if (*(char *)(lVar26 + 0x2050) != '\0') {
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1002c8;
        func_0x(0x298,10,2);
        uVar30 = *(undefined8 *)(lVar26 + 0x6b0);
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1002d4;
        func_0x(uVar30);
      }
      *(undefined8 *)(&stack0x00000128 + lVar19) = 0;
      (&stack0x00000092)[lVar19] = 1;
      plVar21 = *(longlong **)(&stack0x00000110 + lVar19);
      if (plVar21 == (longlong *)0x0) {
        (&stack0x00000092)[lVar19] = 0;
        uVar30 = *(undefined8 *)(lVar22 + 0x290);
        plVar21 = *(longlong **)(&stack0x00000128 + lVar19);
        if (plVar21 == (longlong *)0x0) {
          pcVar4 = *(code **)(**_DAT_ + 8);
          *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10031b;
          plVar21 = (longlong *)(*pcVar4)();
          plVar28 = *(longlong **)(&stack0x00000128 + lVar19);
          if ((plVar28 != plVar21) && (plVar28 != (longlong *)0x0)) {
            pcVar4 = *(code **)*plVar28;
            *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100337;
            (*pcVar4)(plVar28,1);
          }
          *(longlong **)(&stack0x00000128 + lVar19) = plVar21;
        }
        lVar22 = *plVar21;
        (&stack0xffffffffffffffe8)[lVar19] = 0;
        pcVar4 = *(code **)(lVar22 + 0x18);
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10035c;
        (*pcVar4)(plVar21,0x189f528,0x36,uVar30);
        pcVar4 = *(code **)(**(longlong **)(&stack0x00000128 + lVar19) + 0x58);
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x10036c;
        plVar21 = (longlong *)(*pcVar4)(*(longlong **)(&stack0x00000128 + lVar19),lVar26);
        *(longlong **)(&stack0x00000110 + lVar19) = plVar21;
        pcVar4 = *(code **)(*plVar21 + 0x348);
        *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100385;
        (*pcVar4)(plVar21,0);
      }
      uVar25 = 0;
      pcVar4 = *(code **)(*plVar21 + 8);
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100390;
      uVar10 = (*pcVar4)(plVar21);
      (&stack0x00000088)[lVar19] = uVar10;
      *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x1003a2;
      func_0x(&stack0x000005e8 + lVar19,plVar20);
      if (((((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) &&
           (*(longlong **)(param_1[3] + 0x30) != (longlong *)0x0)) &&
          (lVar22 = **(longlong **)(param_1[3] + 0x30), lVar22 != 0)) && (lVar22 != param_1[4])) {
        param_1[4] = lVar22;
      }
      pbVar32 = *(byte **)(&stack0x000005f0 + lVar19);
      if ((*(char *)(param_1[4] + 2) < '\0') &&
         (*(char *)(((ulonglong)pbVar32 & 0xffffffffffffe000) + 2) < '\0')) {
        puVar44 = *(undefined **)(&stack0x000006d0 + lVar19);
        *(undefined **)(&stack0x00000108 + lVar19) = puVar44;
        if (puVar44 == (undefined *)0x0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar19) = 0x100414;
          lVar22 = func_0x();
          puVar39 = &stack0xffffffffffffffc8 + -lVar22 + lVar19;
          puVar44 = &stack0x00000038 + -lVar22 + lVar19;
          *(undefined **)(&stack0x000006d0 + lVar19) = puVar44;
          uVar17 = 0x1f9e;
          *(undefined4 *)(&stack0x000006d8 + lVar19) = 0x1f9e;
          goto LAB_;
        }
        uVar17 = *(undefined4 *)(&stack0x000006d8 + lVar19);
        puVar40 = &stack0xffffffffffffffc8 + lVar19;
      }
      else {
        uVar17 = *(undefined4 *)(&stack0x000006d8 + lVar19);
        puVar44 = *(undefined **)(&stack0x000006d0 + lVar19);
LAB_:
        *(undefined **)(&stack0x00000108 + lVar19) = puVar44;
        puVar40 = puVar39;
      }
      *(undefined4 *)(&stack0x00000084 + lVar19) = 9;
      if (*(char *)(((ulonglong)pbVar32 & 0xffffffffffffe000) + 2) < '\0') {
        *(short *)(&stack0x00000698 + lVar19) = *(short *)(&stack0x000005e8 + lVar19);
        if (*(short *)(&stack0x000005e8 + lVar19) == 0) {
          uVar45 = (ulonglong)*(uint *)(&stack0x000005ec + lVar19);
          if (*(uint *)(&stack0x000005ec + lVar19) == 0) {
            *(undefined2 *)(&stack0x000005ea + lVar19) = 0;
            uVar34 = *(uint *)(&stack0x000005f8 + lVar19);
            uVar45 = (ulonglong)uVar34;
            *(uint *)(&stack0x000005fc + lVar19) = uVar34;
            if ((*pbVar32 & 0x10) != 0) {
              uVar34 = uVar34 + 2 + (*(ushort *)(pbVar32 + uVar45) + 7 >> 3);
              uVar45 = (ulonglong)uVar34;
              *(uint *)(&stack0x000005fc + lVar19) = uVar34;
            }
            if ((*pbVar32 & 0x20) == 0) {
              *(int *)(&stack0x000005ec + lVar19) = (int)uVar45;
              *(undefined2 *)(&stack0x00000604 + lVar19) = 0;
              *(int *)(&stack0x00000600 + lVar19) = (int)uVar45;
            }
            else {
              puVar35 = (ushort *)(pbVar32 + uVar45);
              *(ushort **)(&stack0x00000170 + lVar19) = puVar35;
              uVar13 = *puVar35;
              *(ushort *)(&stack0x00000604 + lVar19) = uVar13;
              if (uVar13 == 0) {
                *(undefined8 *)(puVar40 + -8) = 0x10050e;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x100517;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x100531;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x10054d;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x100573;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x80f);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(&stack0x000005f0 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x100584;
                func_0x(uVar30,3);
                pbVar32 = *(byte **)(&stack0x000005f0 + lVar19);
              }
              uVar34 = *(int *)(&stack0x000005fc + lVar19) +
                       (*(ushort *)(&stack0x00000604 + lVar19) + 1) * 2;
              *(uint *)(&stack0x00000600 + lVar19) = uVar34;
              if (0x1f9e < uVar34) {
                *(undefined8 *)(puVar40 + -8) = 0x1005bb;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x1005c4;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x1005de;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x1005fa;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x100620;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x816);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(&stack0x000005f0 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x100631;
                func_0x(uVar30);
                pbVar32 = *(byte **)(&stack0x000005f0 + lVar19);
              }
              uVar34 = puVar35[*(ushort *)(&stack0x00000604 + lVar19)] & 0x7fff;
              *(uint *)(&stack0x000005ec + lVar19) = uVar34;
              if (uVar34 < *(uint *)(&stack0x00000600 + lVar19)) {
                *(undefined8 *)(puVar40 + -8) = 0x10066b;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x100674;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x10068e;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x1006aa;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x1006d0;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x81d);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(&stack0x000005f0 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x1006e1;
                func_0x(uVar30);
                pbVar32 = *(byte **)(&stack0x000005f0 + lVar19);
                uVar34 = *(uint *)(&stack0x000005ec + lVar19);
              }
              uVar45 = (ulonglong)uVar34;
              uVar34 = *(uint *)(&stack0x00000600 + lVar19);
              if (*(short *)(&stack0x00000604 + lVar19) != 0) {
                do {
                  puVar35 = puVar35 + 1;
                  uVar43 = *puVar35 & 0x7fff;
                  if ((uVar43 < uVar34) || ((uint)uVar45 < uVar43)) {
                    *(undefined8 *)(puVar40 + -8) = 0x100732;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 != '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x10073b;
                      lVar22 = func_0x();
                      if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar40 + -8) = 0x100755;
                        cVar11 = func_0x(0x1fa68c0);
                        if (cVar11 == '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x100771;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar40 + 0x20) = 0;
                          *(undefined8 *)(puVar40 + -8) = 0x100795;
                          (*_DAT_)(1,0x18962cc,0x19b63b8,0x82a);
                        }
                      }
                    }
                    uVar30 = *(undefined8 *)(&stack0x000005f0 + lVar19);
                    *(undefined8 *)(puVar40 + -8) = 0x1007a6;
                    func_0x(uVar30,4);
                    pbVar32 = *(byte **)(&stack0x000005f0 + lVar19);
                    uVar45 = (ulonglong)*(uint *)(&stack0x000005ec + lVar19);
                  }
                  uVar49 = (int)uVar25 + 1;
                  uVar25 = (ulonglong)uVar49;
                  uVar34 = uVar43;
                } while ((int)uVar49 < (int)(uint)*(ushort *)(&stack0x00000604 + lVar19));
                puVar35 = *(ushort **)(&stack0x00000170 + lVar19);
                puVar44 = *(undefined **)(&stack0x00000108 + lVar19);
              }
              while( true ) {
                uVar13 = *(ushort *)(&stack0x00000604 + lVar19);
                if (-1 < (short)puVar35[(ulonglong)(uVar13 - 1) + 1]) break;
                if (uVar13 == 1) {
                  uVar34 = *(uint *)(&stack0x00000600 + lVar19);
                }
                else {
                  uVar34 = *(ushort *)
                            (pbVar32 +
                            (ulonglong)uVar13 * 2 +
                            ((ulonglong)*(uint *)(&stack0x000005fc + lVar19) - 2)) & 0x7fff;
                }
                uVar43 = *(ushort *)
                          (pbVar32 +
                          (ulonglong)uVar13 * 2 + (ulonglong)*(uint *)(&stack0x000005fc + lVar19)) &
                         0x7fff;
                if (((uVar34 < *(uint *)(&stack0x00000600 + lVar19)) || (uVar43 < uVar34)) ||
                   ((uint)uVar45 < uVar43)) {
                  *(undefined8 *)(puVar40 + -8) = 0x100840;
                  func_0x(pbVar32,7);
                  pbVar32 = *(byte **)(&stack0x000005f0 + lVar19);
                  uVar45 = (ulonglong)*(uint *)(&stack0x000005ec + lVar19);
                }
                if ((uVar34 < *(uint *)(&stack0x00000600 + lVar19)) || ((uint)uVar45 < uVar34))
                goto LAB_;
                if (*(ushort *)(pbVar32 + uVar34) == 5) {
                  *(ushort *)(&stack0x000005ea + lVar19) =
                       *(ushort *)(&stack0x000005ea + lVar19) | 2;
                  *(short *)(&stack0x00000604 + lVar19) = *(short *)(&stack0x00000604 + lVar19) + -1
                  ;
                  uVar25 = (ulonglong)(uVar34 & 0xffff);
                  *(short *)(&stack0x00000612 + lVar19) = (short)uVar34;
                  pbVar38 = pbVar32 + uVar25;
                  uVar13 = *(ushort *)(&stack0x00000614 + lVar19);
                  if ((*(ushort *)(pbVar38 + 2) >> 0xe & 1) == 0) {
                    uVar13 = uVar13 & 0xc7ff;
                  }
                  else {
                    uVar13 = uVar13 ^ (uVar13 ^ *(ushort *)(pbVar38 + 2)) & 0x3800;
                  }
                  *(ushort *)(&stack0x00000614 + lVar19) = uVar13;
                  uVar14 = (uVar13 ^ *(ushort *)(pbVar38 + 2)) & 0x7ff ^ uVar13;
                  *(ushort *)(&stack0x00000614 + lVar19) = uVar14;
                  pbVar37 = pbVar32 + (ulonglong)((uVar14 & 0x7ff) * 2) + 4 +
                                      uVar25 + (uVar13 >> 0xb & 7) * 2;
                  if (pbVar37 < pbVar38) {
                    *(undefined8 *)(puVar40 + -8) = 0x100940;
                    func_0x(pbVar38,0x19);
                    uVar14 = *(ushort *)(&stack0x00000614 + lVar19);
                    uVar25 = (ulonglong)*(ushort *)(&stack0x00000612 + lVar19);
                    pbVar32 = *(byte **)(&stack0x000005f0 + lVar19);
                    uVar45 = (ulonglong)*(uint *)(&stack0x000005ec + lVar19);
                  }
                  if (uVar43 - uVar34 <
                      (((*(uint *)(&stack0x00000614 + lVar19) & 0x7ff) * 2 - (int)uVar25) -
                      *(int *)(&stack0x000005f0 + lVar19)) + (int)pbVar37) {
                    *(undefined8 *)(puVar40 + -8) = 0x10098c;
                    func_0x(pbVar32 + uVar25,0x19);
                    uVar14 = *(ushort *)(&stack0x00000614 + lVar19);
                    uVar25 = (ulonglong)*(ushort *)(&stack0x00000612 + lVar19);
                    pbVar32 = *(byte **)(&stack0x000005f0 + lVar19);
                    uVar45 = (ulonglong)*(uint *)(&stack0x000005ec + lVar19);
                  }
                  iVar16 = 0;
                  if (((uVar14 & 0x3800) != 0) &&
                     (puVar35 = (ushort *)(pbVar32 + uVar25 + 4), (uVar14 & 0x3800) != 0)) {
                    do {
                      if ((uVar14 & 0x7ff) < (*puVar35 & 0x7ff)) {
                        *(undefined8 *)(puVar40 + -8) = 0x100a05;
                        func_0x(pbVar32 + uVar25,0x1a);
                        uVar14 = *(ushort *)(&stack0x00000614 + lVar19);
                        uVar25 = (ulonglong)*(ushort *)(&stack0x00000612 + lVar19);
                        pbVar32 = *(byte **)(&stack0x000005f0 + lVar19);
                      }
                      iVar16 = iVar16 + 1;
                      puVar35 = puVar35 + 1;
                    } while (iVar16 < (int)(*(uint *)(&stack0x00000614 + lVar19) >> 0xb & 7));
                    uVar45 = (ulonglong)*(uint *)(&stack0x000005ec + lVar19);
                  }
                  break;
                }
                if (*(ushort *)(pbVar32 + uVar34) < 0x400) break;
                *(ushort *)(&stack0x000005ea + lVar19) = *(ushort *)(&stack0x000005ea + lVar19) | 1;
                psVar47 = (short *)(&stack0x00000604 + lVar19);
                *psVar47 = *psVar47 + -1;
                if (*psVar47 == 0) break;
              }
            }
            if ((*pbVar32 & 0x40) == 0) {
              *(undefined4 *)(&stack0x0000060e + lVar19) = 0;
            }
            else {
              *(int *)(&stack0x0000060e + lVar19) = (int)uVar45;
              *(int *)(&stack0x000005ec + lVar19) = (int)uVar45 + 0xe;
              *(undefined8 *)(puVar40 + -8) = 0x100a74;
              puVar23 = (undefined8 *)func_0x(&stack0x000005ea + lVar19);
              *(undefined8 *)(&stack0x000001d0 + lVar19) = *puVar23;
              *(undefined8 *)(puVar40 + -8) = 0x100a8a;
              iVar16 = func_0x(&stack0x000001d0 + lVar19);
              uVar45 = (ulonglong)(uint)(*(int *)(&stack0x000005ec + lVar19) + iVar16);
              *(int *)(&stack0x000005ec + lVar19) = *(int *)(&stack0x000005ec + lVar19) + iVar16;
              pbVar32 = *(byte **)(&stack0x000005f0 + lVar19);
            }
            if ((*(byte **)(&stack0x00000606 + lVar19) != (byte *)0x0) &&
               (*(byte **)(&stack0x00000606 + lVar19) < pbVar32 + uVar45)) {
              *(undefined8 *)(puVar40 + -8) = 0x100ad5;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x100ade;
                lVar22 = func_0x();
                if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x100af8;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x100b14;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x100b3a;
                    (*_DAT_)(1,0x18962cc,0x19b63b8,0x886);
                  }
                }
              }
              uVar30 = *(undefined8 *)(&stack0x000005f0 + lVar19);
              *(undefined8 *)(puVar40 + -8) = 0x100b4b;
              func_0x(uVar30,0x12);
              uVar45 = (ulonglong)*(uint *)(&stack0x000005ec + lVar19);
            }
            if (0x3f3b < (int)uVar45 - 1U) {
              *(undefined8 *)(puVar40 + -8) = 0x100b74;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x100b7d;
                lVar22 = func_0x();
                if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x100b97;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x100bb3;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x100bd9;
                    (*_DAT_)(1,0x18962cc,0x19b63b8,0x88b);
                  }
                }
              }
              uVar30 = *(undefined8 *)(&stack0x000005f0 + lVar19);
              *(undefined8 *)(puVar40 + -8) = 0x100bea;
              func_0x(uVar30,5);
              uVar45 = (ulonglong)*(uint *)(&stack0x000005ec + lVar19);
            }
          }
LAB_:
          *(undefined4 *)(&stack0x000006a8 + lVar19) = *(undefined4 *)(&stack0x000005f8 + lVar19);
          *(undefined2 *)(&stack0x0000069a + lVar19) = *(undefined2 *)(&stack0x000005ea + lVar19);
          *(int *)(&stack0x0000069c + lVar19) = (int)uVar45;
          *(undefined2 *)(&stack0x000006b4 + lVar19) = *(undefined2 *)(&stack0x00000604 + lVar19);
          *(undefined4 *)(&stack0x000006ac + lVar19) = *(undefined4 *)(&stack0x000005fc + lVar19);
          *(undefined4 *)(&stack0x000006b0 + lVar19) = *(undefined4 *)(&stack0x00000600 + lVar19);
          *(undefined4 *)(&stack0x000006be + lVar19) = *(undefined4 *)(&stack0x0000060e + lVar19);
          *(undefined8 *)(puVar40 + -8) = 0x100c72;
          func_0x(puVar44,uVar17);
          *(undefined **)(&stack0x000006a0 + lVar19) = puVar44;
          *(undefined8 *)(puVar40 + -8) = 0x100c85;
          iVar16 = func_0x(&stack0x0000069a + lVar19);
          pbVar32 = *(byte **)(&stack0x000006a0 + lVar19);
          if (iVar16 != 0) {
            puVar35 = (ushort *)(pbVar32 + *(uint *)(&stack0x000006ac + lVar19));
            uVar34 = *puVar35 - 1;
            if (((&stack0x0000069a)[lVar19] & 1) == 0) {
              uVar34 = (uint)*puVar35;
            }
            uVar43 = *(uint *)(&stack0x000006b0 + lVar19);
            if (uVar34 != 1) {
              uVar43 = puVar35[(longlong)(int)uVar34 + -1] & 0x7fff;
            }
            uVar34 = puVar35[(int)uVar34] & 0x7fff;
            if (((uVar43 < *(uint *)(&stack0x000006b0 + lVar19)) || (uVar34 < uVar43)) ||
               (*(uint *)(&stack0x0000069c + lVar19) < uVar34)) {
              *(undefined8 *)(puVar40 + -8) = 0x100cf4;
              func_0x(pbVar32,7);
              pbVar32 = *(byte **)(&stack0x000006a0 + lVar19);
            }
            uVar25 = (ulonglong)(uVar43 & 0xffff);
            *(short *)(&stack0x000006c2 + lVar19) = (short)uVar43;
            pbVar38 = pbVar32 + uVar25;
            uVar13 = *(ushort *)(&stack0x000006c4 + lVar19);
            if ((*(ushort *)(pbVar38 + 2) >> 0xe & 1) == 0) {
              uVar13 = uVar13 & 0xc7ff;
            }
            else {
              uVar13 = uVar13 ^ (uVar13 ^ *(ushort *)(pbVar38 + 2)) & 0x3800;
            }
            *(ushort *)(&stack0x000006c4 + lVar19) = uVar13;
            uVar14 = (uVar13 ^ *(ushort *)(pbVar38 + 2)) & 0x7ff ^ uVar13;
            *(ushort *)(&stack0x000006c4 + lVar19) = uVar14;
            pbVar37 = pbVar32 + uVar25 + (ulonglong)((uVar14 & 0x7ff) * 2) + 4 +
                                         (ulonglong)((uVar13 >> 0xb & 7) * 2);
            if (pbVar37 < pbVar38) {
              *(undefined8 *)(puVar40 + -8) = 0x100d98;
              func_0x(pbVar38,0x19);
              uVar14 = *(ushort *)(&stack0x000006c4 + lVar19);
              uVar25 = (ulonglong)*(ushort *)(&stack0x000006c2 + lVar19);
              pbVar32 = *(byte **)(&stack0x000006a0 + lVar19);
            }
            if (uVar34 - uVar43 <
                (((*(uint *)(&stack0x000006c4 + lVar19) & 0x7ff) * 2 - (int)uVar25) -
                *(int *)(&stack0x000006a0 + lVar19)) + (int)pbVar37) {
              *(undefined8 *)(puVar40 + -8) = 0x100ddd;
              func_0x(pbVar32 + uVar25,0x19);
              uVar14 = *(ushort *)(&stack0x000006c4 + lVar19);
              uVar25 = (ulonglong)*(ushort *)(&stack0x000006c2 + lVar19);
              pbVar32 = *(byte **)(&stack0x000006a0 + lVar19);
            }
            if ((uVar14 & 0x3800) != 0) {
              puVar35 = (ushort *)(pbVar32 + uVar25 + 4);
              iVar16 = 0;
              if ((uVar14 & 0x3800) != 0) {
                do {
                  if ((uVar14 & 0x7ff) < (*puVar35 & 0x7ff)) {
                    *(undefined8 *)(puVar40 + -8) = 0x100e45;
                    func_0x(pbVar32 + uVar25,0x1a);
                    uVar14 = *(ushort *)(&stack0x000006c4 + lVar19);
                    uVar25 = (ulonglong)*(ushort *)(&stack0x000006c2 + lVar19);
                    pbVar32 = *(byte **)(&stack0x000006a0 + lVar19);
                  }
                  iVar16 = iVar16 + 1;
                  puVar35 = puVar35 + 1;
                } while (iVar16 < (int)(*(uint *)(&stack0x000006c4 + lVar19) >> 0xb & 7));
              }
            }
          }
        }
        else {
          if ((*(longlong **)(&stack0x000005f8 + lVar19) == (longlong *)0x0) ||
             (**(longlong **)(&stack0x000005f8 + lVar19) == 0)) {
            *(undefined8 *)(puVar40 + -8) = 0x100eba;
            func_0x(&stack0x0000069a + lVar19,puVar44,uVar17,&stack0x000005ea + lVar19);
            uVar45 = *(ulonglong *)(&stack0x000005f8 + lVar19);
            if (*(short *)(&stack0x000005e8 + lVar19) == 0) {
              uVar45 = uVar25;
            }
            *(ulonglong *)(&stack0x000006a8 + lVar19) = uVar45;
          }
          else {
            *(undefined8 *)(puVar40 + -8) = 0x100e9f;
            func_0x(&stack0x00000698 + lVar19,puVar44,uVar17,&stack0x000005e8 + lVar19);
          }
          pbVar32 = *(byte **)(&stack0x000006a0 + lVar19);
        }
        puVar44 = &stack0x00000698;
        puVar7 = &stack0x0000069a;
      }
      else {
        puVar44 = &stack0x000005e8;
        puVar7 = &stack0x000005ea;
      }
      psVar47 = (short *)(puVar44 + lVar19);
      puVar35 = (ushort *)(puVar7 + lVar19);
      *(short **)(&stack0x00000108 + lVar19) = psVar47;
      sVar33 = *psVar47;
      if (sVar33 == 0) {
        bVar31 = *pbVar32 & 0xe;
        *(undefined4 *)(&stack0x000000c8 + lVar19) = 0;
        if (bVar31 == 2) {
          *(uint *)(&stack0x000000c8 + lVar19) = (uint)((pbVar32[1] & 1) != 0);
        }
        else if (((bVar31 - 10 & 0xf9) == 0) && (bVar31 != 0x10)) {
          *(undefined4 *)(&stack0x000000c8 + lVar19) = 1;
        }
      }
      else {
        *(uint *)(&stack0x000000c8 + lVar19) = (uint)(((*pbVar32 & 0x1c) - 4 & 0xffffffe7) == 0);
      }
      iVar16 = 0;
      *(uint *)(&stack0x00000170 + lVar19) =
           ((uint)(int)*(short *)(&stack0x000000ee + lVar19) >> 1 ^
           (int)*(short *)(&stack0x000000ee + lVar19)) >> 0xd & 1;
      uVar34 = *(uint *)(puVar35 + 1);
      *(uint *)(&stack0x000000d8 + lVar19) = uVar34;
      if (sVar33 == 0) {
        if (uVar34 == 0) {
          *puVar35 = 0;
          uVar34 = *(uint *)(puVar35 + 7);
          uVar25 = (ulonglong)uVar34;
          *(uint *)(puVar35 + 9) = uVar34;
          pbVar32 = *(byte **)(puVar35 + 3);
          bVar31 = *pbVar32;
          if ((bVar31 & 0x10) != 0) {
            uVar34 = uVar34 + (*(ushort *)(pbVar32 + uVar25) + 7 >> 3) + 2;
            uVar25 = (ulonglong)uVar34;
            *(uint *)(puVar35 + 9) = uVar34;
            bVar31 = *pbVar32;
          }
          if ((bVar31 & 0x20) == 0) {
            *(int *)(puVar35 + 1) = (int)uVar25;
            puVar35[0xd] = 0;
            *(uint *)(puVar35 + 0xb) = uVar34;
          }
          else {
            puVar51 = (ushort *)(pbVar32 + uVar25);
            *(ushort **)(&stack0x000000d8 + lVar19) = puVar51;
            uVar13 = *puVar51;
            puVar35[0xd] = uVar13;
            if (uVar13 == 0) {
              *(undefined8 *)(puVar40 + -8) = 0x100ffe;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x101007;
                lVar22 = func_0x();
                if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x101021;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x10103d;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x101063;
                    (*_DAT_)(1,0x18962cc,0x19b63b8,0x80f);
                  }
                }
              }
              uVar30 = *(undefined8 *)(puVar35 + 3);
              *(undefined8 *)(puVar40 + -8) = 0x101071;
              func_0x(uVar30,3);
              uVar13 = puVar35[0xd];
              uVar34 = *(uint *)(puVar35 + 9);
            }
            uVar34 = uVar34 + (uVar13 + 1) * 2;
            *(uint *)(puVar35 + 0xb) = uVar34;
            if (0x1f9e < uVar34) {
              *(undefined8 *)(puVar40 + -8) = 0x1010a3;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x1010ac;
                lVar22 = func_0x();
                if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x1010c6;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x1010e2;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x101108;
                    (*_DAT_)(1,0x18962cc,0x19b63b8,0x816);
                  }
                }
              }
              uVar30 = *(undefined8 *)(puVar35 + 3);
              *(undefined8 *)(puVar40 + -8) = 0x101116;
              func_0x(uVar30,4);
              uVar13 = puVar35[0xd];
              uVar34 = *(uint *)(puVar35 + 0xb);
            }
            uVar25 = (ulonglong)uVar13;
            uVar13 = puVar51[uVar25];
            *(uint *)(puVar35 + 1) = uVar13 & 0x7fff;
            if ((uVar13 & 0x7fff) < uVar34) {
              *(undefined8 *)(puVar40 + -8) = 0x101144;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x10114d;
                lVar22 = func_0x();
                if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x101167;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x101183;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x1011a9;
                    (*_DAT_)(1,0x18962cc,0x19b63b8,0x81d);
                  }
                }
              }
              uVar30 = *(undefined8 *)(puVar35 + 3);
              *(undefined8 *)(puVar40 + -8) = 0x1011b7;
              func_0x(uVar30,4);
              uVar34 = *(uint *)(puVar35 + 0xb);
              uVar25 = (ulonglong)puVar35[0xd];
            }
            if ((short)uVar25 != 0) {
              do {
                puVar51 = puVar51 + 1;
                uVar43 = *puVar51 & 0x7fff;
                if ((uVar43 < uVar34) || (*(uint *)(puVar35 + 1) < uVar43)) {
                  *(undefined8 *)(puVar40 + -8) = 0x1011ff;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x101208;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar40 + -8) = 0x101222;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x10123e;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x101262;
                        (*_DAT_)(1,0x18962cc,0x19b63b8,0x82a);
                      }
                    }
                  }
                  uVar30 = *(undefined8 *)(puVar35 + 3);
                  *(undefined8 *)(puVar40 + -8) = 0x101270;
                  func_0x(uVar30,4);
                }
                iVar16 = iVar16 + 1;
                uVar25 = (ulonglong)puVar35[0xd];
                uVar34 = uVar43;
              } while (iVar16 < (int)(uint)puVar35[0xd]);
              puVar51 = *(ushort **)(&stack0x000000d8 + lVar19);
              psVar47 = *(short **)(&stack0x00000108 + lVar19);
            }
            if ((short)puVar51[(ulonglong)((int)uVar25 - 1) + 1] < 0) {
              lVar22 = *(longlong *)(puVar35 + 3);
              do {
                uVar43 = *(ushort *)((ulonglong)*(uint *)(puVar35 + 9) + lVar22 + uVar25 * 2) &
                         0x7fff;
                if ((int)uVar25 == 1) {
                  uVar49 = *(uint *)(puVar35 + 0xb);
                  uVar25 = (ulonglong)uVar49;
LAB_:
                  if (uVar43 < (uint)uVar25) goto LAB_;
                  uVar34 = *(uint *)(puVar35 + 1);
                  *(uint *)(&stack0x000000d8 + lVar19) = uVar34;
                  if (uVar34 < uVar43) goto LAB_;
                }
                else {
                  uVar34 = *(ushort *)((ulonglong)*(uint *)(puVar35 + 9) + lVar22 + -2 + uVar25 * 2)
                           & 0x7fff;
                  uVar25 = (ulonglong)uVar34;
                  uVar49 = *(uint *)(puVar35 + 0xb);
                  if (uVar49 <= uVar34) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar40 + -8) = 0x101302;
                  func_0x(lVar22,7);
                  uVar49 = *(uint *)(puVar35 + 0xb);
                  uVar34 = *(uint *)(puVar35 + 1);
                  *(uint *)(&stack0x000000d8 + lVar19) = uVar34;
                }
                uVar50 = (uint)uVar25;
                if ((uVar50 < uVar49) || (uVar34 < uVar50)) goto LAB_;
                lVar22 = *(longlong *)(puVar35 + 3);
                if (*(ushort *)(uVar25 + lVar22) == 5) {
                  *puVar35 = *puVar35 | 2;
                  puVar35[0xd] = puVar35[0xd] - 1;
                  uVar45 = uVar25 & 0xffff;
                  puVar35[0x14] = (ushort)uVar25;
                  uVar25 = *(ulonglong *)(puVar35 + 3);
                  uVar13 = puVar35[0x15] & 0xc7ff;
                  if ((*(ushort *)(uVar45 + 2 + uVar25) >> 0xe & 1) != 0) {
                    uVar13 = *(ushort *)(uVar45 + 2 + uVar25) & 0x3800 | puVar35[0x15] & 0xc7ff;
                  }
                  puVar35[0x15] = uVar13;
                  uVar14 = (uVar13 ^ *(ushort *)(uVar45 + 2 + uVar25)) & 0x7ff ^ uVar13;
                  puVar35[0x15] = uVar14;
                  uVar36 = (ulonglong)puVar35[0x14];
                  uVar45 = (ulonglong)((uVar14 & 0x7ff) * 2) + 4 + uVar36 + (uVar13 >> 0xb & 7) * 2
                           + uVar25;
                  if (uVar45 < uVar36 + uVar25) {
                    *(undefined8 *)(puVar40 + -8) = 0x10141b;
                    func_0x(uVar36 + uVar25,0x19);
                    uVar14 = puVar35[0x15];
                    uVar36 = (ulonglong)puVar35[0x14];
                    uVar25 = (ulonglong)*(uint *)(puVar35 + 3);
                  }
                  if (uVar43 - uVar50 <
                      (((uVar14 & 0x7ff) * 2 - (int)uVar36) - (int)uVar25) + (int)uVar45) {
                    lVar22 = *(longlong *)(puVar35 + 3);
                    *(undefined8 *)(puVar40 + -8) = 0x101453;
                    func_0x(uVar36 + lVar22,0x19);
                    uVar14 = puVar35[0x15];
                  }
                  if ((uVar14 & 0x3800) != 0) {
                    puVar51 = (ushort *)(*(longlong *)(puVar35 + 3) + (ulonglong)puVar35[0x14] + 4);
                    iVar16 = 0;
                    if ((uVar14 & 0x3800) != 0) {
                      do {
                        if ((uVar14 & 0x7ff) < (*puVar51 & 0x7ff)) {
                          uVar13 = puVar35[0x14];
                          lVar22 = *(longlong *)(puVar35 + 3);
                          *(undefined8 *)(puVar40 + -8) = 0x1014a7;
                          func_0x((ulonglong)uVar13 + lVar22,0x1a);
                          uVar14 = puVar35[0x15];
                        }
                        iVar16 = iVar16 + 1;
                        puVar51 = puVar51 + 1;
                      } while (iVar16 < (int)(uVar14 >> 0xb & 7));
                    }
                  }
                  goto LAB_;
                }
                if (*(ushort *)(uVar25 + lVar22) < 0x400) goto LAB_;
                *puVar35 = *puVar35 | 1;
                uVar13 = puVar35[0xd] - 1;
                puVar35[0xd] = uVar13;
                if (uVar13 == 0) goto LAB_;
                uVar25 = (ulonglong)uVar13;
              } while ((short)puVar51[(ulonglong)(uVar13 - 1) + 1] < 0);
              pbVar32 = *(byte **)(puVar35 + 3);
            }
            else {
LAB_:
              pbVar32 = *(byte **)(puVar35 + 3);
            }
          }
          if ((*pbVar32 & 0x40) == 0) {
            *(undefined4 *)(puVar35 + 0x12) = 0;
          }
          else {
            *(int *)(puVar35 + 0x12) = *(int *)(puVar35 + 1);
            *(int *)(puVar35 + 1) = *(int *)(puVar35 + 1) + 0xe;
            *(undefined8 *)(puVar40 + -8) = 0x1014ee;
            puVar23 = (undefined8 *)func_0x(puVar35);
            *(undefined8 *)(&stack0x000001e8 + lVar19) = *puVar23;
            *(undefined8 *)(puVar40 + -8) = 0x101504;
            iVar16 = func_0x(&stack0x000001e8 + lVar19);
            *(int *)(puVar35 + 1) = *(int *)(puVar35 + 1) + iVar16;
          }
          uVar34 = *(uint *)(puVar35 + 1);
          uVar25 = *(ulonglong *)(puVar35 + 0xe);
          *(uint *)(&stack0x000000d8 + lVar19) = uVar34;
          if ((uVar25 != 0) &&
             (*(uint *)(&stack0x000000d8 + lVar19) = uVar34,
             uVar25 < (ulonglong)uVar34 + *(longlong *)(puVar35 + 3))) {
            *(undefined8 *)(puVar40 + -8) = 0x101544;
            cVar11 = func_0x(0x1fa68c0);
            if (cVar11 != '\0') {
              *(undefined8 *)(puVar40 + -8) = 0x10154d;
              lVar22 = func_0x();
              if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                *(undefined8 *)(puVar40 + -8) = 0x101567;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 == '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x101583;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar40 + 0x20) = 0;
                  *(undefined8 *)(puVar40 + -8) = 0x1015a9;
                  (*_DAT_)(1,0x18962cc,0x19b63b8,0x886);
                }
              }
            }
            uVar30 = *(undefined8 *)(puVar35 + 3);
            *(undefined8 *)(puVar40 + -8) = 0x1015b7;
            func_0x(uVar30,0x12);
            uVar34 = *(uint *)(puVar35 + 1);
            *(uint *)(&stack0x000000d8 + lVar19) = uVar34;
          }
          if ((uVar34 == 0) || (0x3f3c < uVar34)) {
            *(undefined8 *)(puVar40 + -8) = 0x1015e0;
            cVar11 = func_0x(0x1fa68c0);
            if (cVar11 != '\0') {
              *(undefined8 *)(puVar40 + -8) = 0x1015e9;
              lVar22 = func_0x();
              if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                *(undefined8 *)(puVar40 + -8) = 0x101603;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 == '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x10161f;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar40 + 0x20) = 0;
                  *(undefined8 *)(puVar40 + -8) = 0x101645;
                  (*_DAT_)(1,0x18962cc,0x19b63b8,0x88b);
                }
              }
            }
            uVar30 = *(undefined8 *)(puVar35 + 3);
            *(undefined8 *)(puVar40 + -8) = 0x101653;
            func_0x(uVar30,5);
            uVar34 = *(uint *)(puVar35 + 1);
            *(uint *)(&stack0x000000d8 + lVar19) = uVar34;
          }
        }
LAB_:
        if ((uVar34 < 9) &&
           (((**(byte **)(puVar35 + 3) & 0xe) == 0 || ((**(byte **)(puVar35 + 3) & 0xe) == 0xc)))) {
LAB_:
          *(undefined4 *)(&stack0x000000d8 + lVar19) = 9;
        }
      }
      else {
        if (uVar34 == 0) {
          *(undefined8 *)(puVar40 + -8) = 0x10168a;
          func_0x(puVar35);
          uVar34 = *(uint *)(puVar35 + 1);
        }
        if (uVar34 < 9) {
          bVar31 = **(byte **)(puVar35 + 3);
          if ((bVar31 & 0x1c) == 0) goto LAB_;
          *(undefined4 *)(&stack0x000000d8 + lVar19) = 9;
          if ((bVar31 & 0x1c) == 0xc) goto LAB_;
        }
        *(uint *)(&stack0x000000d8 + lVar19) = uVar34;
      }
LAB_:
      uVar25 = 0;
      *(undefined8 *)(&stack0x000006f0 + lVar19) = 0;
      *(undefined2 *)(&stack0x000006f8 + lVar19) = 0;
      *(undefined8 *)(puVar40 + 0x28) = 0;
      *(undefined **)(puVar40 + 0x20) = &stack0x000001d8 + lVar19;
      uVar30 = *(undefined8 *)(&stack0x00000168 + lVar19);
      *(undefined8 *)(puVar40 + -8) = 0x1016ed;
      uVar17 = func_0x(&stack0x000000e8 + lVar19,uVar30);
      *(undefined4 *)(&stack0x00000108 + lVar19) = uVar17;
      *(undefined **)(puVar40 + 0x28) = &stack0x00000048 + lVar19;
      lVar22 = *(longlong *)(&stack0x00000098 + lVar19);
      *(undefined8 *)(puVar40 + -8) = 0x101715;
      func_0x(lVar22,psVar47,0,&stack0x000007b8 + lVar19);
      if (((&stack0x00000088)[lVar19] == '\0') &&
         (bVar31 = *(byte *)(*(longlong *)(lVar22 + 8) + 0x108) >> 6 & 1,
         (&stack0x00000090)[lVar19] = bVar31, bVar31 != 0)) {
        *(undefined8 *)(puVar40 + -8) = 0x101740;
        uVar10 = func_0x(lVar22,psVar47);
      }
      else {
        uVar10 = (&stack0x00000093)[lVar19];
      }
      (&stack0x00000091)[lVar19] = uVar10;
      lVar22 = *(longlong *)(&stack0x000000a8 + lVar19);
      if (((((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) &&
           (plVar20 = *(longlong **)(*(longlong *)(lVar22 + 0x18) + 0x30),
           plVar20 != (longlong *)0x0)) && (lVar26 = *plVar20, lVar26 != 0)) &&
         (lVar26 != *(longlong *)(lVar22 + 0x20))) {
        *(longlong *)(lVar22 + 0x20) = lVar26;
      }
      lVar26 = *(longlong *)(lVar22 + 0x20);
      if (*(short *)(lVar26 + 0x24) == 0) {
LAB_:
        uVar30 = *(undefined8 *)(lVar26 + 0x28);
        *(undefined8 *)(&stack0x00000180 + lVar19) = uVar30;
        uVar3 = *(undefined2 *)(lVar26 + 0x30);
        *(undefined2 *)(&stack0x000000e0 + lVar19) = uVar3;
        *(undefined2 *)(&stack0x00000188 + lVar19) = uVar3;
      }
      else {
        cVar11 = *(char *)(lVar26 + 1);
        if (cVar11 == '\v') {
          if (*(int *)(lVar26 + 0x18) != 99) {
LAB_:
            if (cVar11 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar11 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar26 + 0x18) != 99) goto LAB_;
        }
        *(undefined4 *)(&stack0x00000178 + lVar19) = *(undefined4 *)(lVar26 + 0x20);
        *(undefined2 *)(&stack0x0000017c + lVar19) = *(undefined2 *)(lVar26 + 0x24);
        *(undefined8 *)(puVar40 + -8) = 0x1017cc;
        cVar11 = func_0x(&stack0x00000178 + lVar19);
        if (cVar11 == '\0') goto LAB_;
        *(undefined8 *)(puVar40 + -8) = 0x1017df;
        func_0x(lVar26,&stack0x00000180 + lVar19);
        *(undefined2 *)(&stack0x000000e0 + lVar19) = *(undefined2 *)(&stack0x00000188 + lVar19);
        uVar30 = *(undefined8 *)(&stack0x00000180 + lVar19);
      }
      *(undefined8 *)(&stack0x000001c0 + lVar19) = uVar30;
      if ((((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) &&
          (plVar20 = *(longlong **)(*(longlong *)(lVar22 + 0x18) + 0x30), plVar20 != (longlong *)0x0
          )) && ((lVar26 = *plVar20, lVar26 != 0 && (lVar26 != *(longlong *)(lVar22 + 0x20))))) {
        *(longlong *)(lVar22 + 0x20) = lVar26;
      }
      uVar13 = *(ushort *)(*(longlong *)(lVar22 + 0x20) + 4) >> 0xd & 1;
      *(ushort *)(&stack0x000000c0 + lVar19) = uVar13;
      if ((*(uint *)(&stack0x000000e8 + lVar19) & 0x80000000) != 0) {
        uVar14 = *(ushort *)(&stack0x000000ee + lVar19);
        uVar15 = uVar14;
        if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
          uVar15 = uVar14 & 0xdfff;
          if ((uVar14 >> 0xe & 1) != 0) {
            uVar15 = uVar14 | 0x2000;
          }
        }
        if (uVar15 == 0xfffc) {
          *(undefined8 *)(puVar40 + 0x20) = 0;
          *(undefined8 *)(puVar40 + -8) = 0x1018e4;
          (*_DAT_)(1,0x1a41060,0x1a1a7d0,0x4ec);
        }
        *(undefined8 *)(puVar40 + -8) = 0x1018f8;
        cVar11 = func_0x(&stack0x000000e8 + lVar19);
        if (cVar11 == '\0') {
          *(undefined8 *)(puVar40 + -8) = 0x101908;
          cVar11 = func_0x(&stack0x000000e8 + lVar19);
          if ((cVar11 == '\0') &&
             (((uint)(int)*(short *)(&stack0x000000ee + lVar19) >> 0xc & 1) != 0))
          goto LAB_;
        }
        sVar33 = *psVar47;
        *(short *)(&stack0x00000700 + lVar19) = sVar33;
        if (sVar33 == 0) {
          uVar34 = *(uint *)(psVar47 + 2);
          if (uVar34 == 0) {
            psVar47[1] = 0;
            uVar34 = *(uint *)(psVar47 + 8);
            uVar45 = (ulonglong)uVar34;
            *(uint *)(psVar47 + 10) = uVar34;
            pbVar32 = *(byte **)(psVar47 + 4);
            bVar31 = *pbVar32;
            pbVar38 = pbVar32;
            if ((bVar31 & 0x10) != 0) {
              uVar34 = uVar34 + (*(ushort *)(pbVar32 + uVar45) + 7 >> 3) + 2;
              uVar45 = (ulonglong)uVar34;
              *(uint *)(psVar47 + 10) = uVar34;
              bVar31 = *pbVar32;
              pbVar38 = *(byte **)(psVar47 + 4);
            }
            if ((bVar31 & 0x20) == 0) {
              *(int *)(psVar47 + 2) = (int)uVar45;
              psVar47[0xe] = 0;
              *(uint *)(psVar47 + 0xc) = uVar34;
            }
            else {
              puVar35 = (ushort *)(pbVar32 + uVar45);
              *(ushort **)(&stack0x000001e0 + lVar19) = puVar35;
              uVar14 = *puVar35;
              psVar47[0xe] = uVar14;
              if (uVar14 == 0) {
                *(undefined8 *)(puVar40 + -8) = 0x1019b9;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x1019c2;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x1019dc;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x1019f8;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x101a1c;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x80f);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(psVar47 + 4);
                *(undefined8 *)(puVar40 + -8) = 0x101a2b;
                func_0x(uVar30,3);
                uVar14 = psVar47[0xe];
                uVar34 = *(uint *)(psVar47 + 10);
              }
              uVar34 = uVar34 + (uVar14 + 1) * 2;
              *(uint *)(psVar47 + 0xc) = uVar34;
              if (0x1f9e < uVar34) {
                *(undefined8 *)(puVar40 + -8) = 0x101a62;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x101a6b;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x101a85;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x101aa1;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x101ac5;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x816);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(psVar47 + 4);
                *(undefined8 *)(puVar40 + -8) = 0x101ad4;
                func_0x(uVar30,4);
                uVar14 = psVar47[0xe];
                uVar34 = *(uint *)(psVar47 + 0xc);
              }
              uVar45 = (ulonglong)uVar14;
              uVar14 = puVar35[uVar45];
              *(uint *)(psVar47 + 2) = uVar14 & 0x7fff;
              if ((uVar14 & 0x7fff) < uVar34) {
                *(undefined8 *)(puVar40 + -8) = 0x101b07;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x101b10;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x101b2a;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x101b46;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x101b6a;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x81d);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(psVar47 + 4);
                *(undefined8 *)(puVar40 + -8) = 0x101b79;
                func_0x(uVar30,4);
                uVar34 = *(uint *)(psVar47 + 0xc);
                uVar45 = (ulonglong)(ushort)psVar47[0xe];
              }
              if ((short)uVar45 != 0) {
                do {
                  puVar35 = puVar35 + 1;
                  uVar43 = *puVar35 & 0x7fff;
                  if ((uVar43 < uVar34) || (*(uint *)(psVar47 + 2) < uVar43)) {
                    *(undefined8 *)(puVar40 + -8) = 0x101bc1;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 != '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x101bca;
                      lVar22 = func_0x();
                      if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar40 + -8) = 0x101be4;
                        cVar11 = func_0x(0x1fa68c0);
                        if (cVar11 == '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x101c00;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar40 + 0x20) = 0;
                          *(undefined8 *)(puVar40 + -8) = 0x101c24;
                          (*_DAT_)(1,0x18962cc,0x19b63b8,0x82a);
                        }
                      }
                    }
                    uVar30 = *(undefined8 *)(psVar47 + 4);
                    *(undefined8 *)(puVar40 + -8) = 0x101c33;
                    func_0x(uVar30,4);
                  }
                  uVar49 = (int)uVar25 + 1;
                  uVar25 = (ulonglong)uVar49;
                  uVar45 = (ulonglong)(ushort)psVar47[0xe];
                  uVar34 = uVar43;
                } while ((int)uVar49 < (int)(uint)(ushort)psVar47[0xe]);
                puVar35 = *(ushort **)(&stack0x000001e0 + lVar19);
                uVar13 = *(ushort *)(&stack0x000000c0 + lVar19);
              }
              if ((short)puVar35[(ulonglong)((int)uVar45 - 1) + 1] < 0) {
                do {
                  lVar22 = *(longlong *)(psVar47 + 4);
                  uVar43 = *(ushort *)((ulonglong)*(uint *)(psVar47 + 10) + lVar22 + uVar45 * 2) &
                           0x7fff;
                  if ((int)uVar45 == 1) {
                    uVar49 = *(uint *)(psVar47 + 0xc);
                    uVar50 = uVar49;
LAB_:
                    if ((uVar43 < uVar49) || (uVar34 = *(uint *)(psVar47 + 2), uVar34 < uVar43))
                    goto LAB_;
                  }
                  else {
                    uVar49 = *(ushort *)
                              ((ulonglong)*(uint *)(psVar47 + 10) + lVar22 + -2 + uVar45 * 2) &
                             0x7fff;
                    uVar50 = *(uint *)(psVar47 + 0xc);
                    if (uVar50 <= uVar49) goto LAB_;
LAB_:
                    *(undefined8 *)(puVar40 + -8) = 0x101cc6;
                    func_0x(lVar22,7);
                    uVar50 = *(uint *)(psVar47 + 0xc);
                    uVar34 = *(uint *)(psVar47 + 2);
                    lVar22 = *(longlong *)(psVar47 + 4);
                  }
                  if ((uVar49 < uVar50) || (uVar34 < uVar49)) goto LAB_;
                  if (*(ushort *)((ulonglong)uVar49 + lVar22) == 5) {
                    psVar47[1] = psVar47[1] | 2;
                    psVar47[0xe] = psVar47[0xe] + -1;
                    uVar45 = (ulonglong)(uVar49 & 0xffff);
                    psVar47[0x15] = (short)uVar49;
                    uVar25 = *(ulonglong *)(psVar47 + 4);
                    uVar14 = psVar47[0x16] & 0xc7ffU;
                    if ((*(ushort *)(uVar45 + 2 + uVar25) >> 0xe & 1) != 0) {
                      uVar14 = *(ushort *)(uVar45 + 2 + uVar25) & 0x3800 | psVar47[0x16] & 0xc7ffU;
                    }
                    psVar47[0x16] = uVar14;
                    uVar15 = (uVar14 ^ *(ushort *)(uVar45 + 2 + uVar25)) & 0x7ff ^ uVar14;
                    psVar47[0x16] = uVar15;
                    uVar36 = (ulonglong)(ushort)psVar47[0x15];
                    uVar45 = (ulonglong)((uVar15 & 0x7ff) * 2) + 4 +
                             uVar36 + (uVar14 >> 0xb & 7) * 2 + uVar25;
                    if (uVar45 < uVar36 + uVar25) {
                      *(undefined8 *)(puVar40 + -8) = 0x101dee;
                      func_0x(uVar36 + uVar25,0x19);
                      uVar15 = psVar47[0x16];
                      uVar36 = (ulonglong)(ushort)psVar47[0x15];
                      uVar25 = (ulonglong)*(uint *)(psVar47 + 4);
                    }
                    if (uVar43 - uVar49 <
                        (((uVar15 & 0x7ff) * 2 - (int)uVar36) - (int)uVar25) + (int)uVar45) {
                      lVar22 = *(longlong *)(psVar47 + 4);
                      *(undefined8 *)(puVar40 + -8) = 0x101e2a;
                      func_0x(uVar36 + lVar22,0x19);
                      uVar15 = psVar47[0x16];
                    }
                    if ((uVar15 & 0x3800) != 0) {
                      puVar35 = (ushort *)
                                (*(longlong *)(psVar47 + 4) + (ulonglong)(ushort)psVar47[0x15] + 4);
                      iVar16 = 0;
                      if ((uVar15 & 0x3800) != 0) goto LAB_;
                    }
                    break;
                  }
                  if (*(ushort *)((ulonglong)uVar49 + lVar22) < 0x400) break;
                  psVar47[1] = psVar47[1] | 1;
                  uVar14 = psVar47[0xe] - 1;
                  psVar47[0xe] = uVar14;
                  if ((uVar14 == 0) ||
                     (uVar45 = (ulonglong)uVar14, -1 < (short)puVar35[(ulonglong)(uVar14 - 1) + 1]))
                  break;
                } while( true );
              }
              pbVar38 = *(byte **)(psVar47 + 4);
            }
            goto LAB_;
          }
          goto LAB_;
        }
        if ((*(longlong **)(psVar47 + 8) == (longlong *)0x0) || (**(longlong **)(psVar47 + 8) == 0))
        {
          *(undefined8 *)(puVar40 + -8) = 0x102393;
          func_0x(&stack0x00000702 + lVar19,&stack0x00001218 + lVar19,0x1f9e,psVar47 + 1);
          if (*psVar47 != 0) {
            uVar25 = *(ulonglong *)(psVar47 + 8);
          }
          *(ulonglong *)(&stack0x00000710 + lVar19) = uVar25;
        }
        else {
          *(undefined8 *)(puVar40 + -8) = 0x102373;
          func_0x(&stack0x00000700 + lVar19,&stack0x00001218 + lVar19,0x1f9e,psVar47);
        }
        goto LAB_;
      }
LAB_:
      psVar47 = (short *)(lVar22 + 0x48);
      puVar44 = (undefined *)(lVar22 + 0x4a);
      goto LAB_;
    }
  }
  goto LAB_;
LAB_:
  do {
    if ((uVar15 & 0x7ff) < (*puVar35 & 0x7ff)) {
      uVar14 = psVar47[0x15];
      lVar22 = *(longlong *)(psVar47 + 4);
      *(undefined8 *)(puVar40 + -8) = 0x101e8b;
      func_0x((ulonglong)uVar14 + lVar22,0x1a);
      uVar15 = psVar47[0x16];
    }
    iVar16 = iVar16 + 1;
    puVar35 = puVar35 + 1;
  } while (iVar16 < (int)(uVar15 >> 0xb & 7));
  pbVar38 = *(byte **)(psVar47 + 4);
LAB_:
  iVar16 = 0;
  if ((*pbVar38 & 0x40) == 0) {
    *(undefined4 *)(psVar47 + 0x13) = 0;
  }
  else {
    *(int *)(psVar47 + 0x13) = *(int *)(psVar47 + 2);
    *(int *)(psVar47 + 2) = *(int *)(psVar47 + 2) + 0xe;
    *(undefined8 *)(puVar40 + -8) = 0x101ef0;
    puVar24 = (ulonglong *)func_0x(psVar47 + 1);
    uVar15 = (ushort)(*puVar24 >> 0x30);
    uVar14 = uVar15;
    if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
      uVar14 = uVar15 & 0xdfff;
      if ((uVar15 >> 0xe & 1) != 0) {
        uVar14 = uVar15 | 0x2000;
      }
    }
    if (uVar14 == 0xfffc) {
      iVar16 = (int)((*puVar24 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)(psVar47 + 2) = *(int *)(psVar47 + 2) + iVar16;
    pbVar38 = *(byte **)(psVar47 + 4);
  }
  uVar34 = *(uint *)(psVar47 + 2);
  if ((*(byte **)(psVar47 + 0xf) != (byte *)0x0) && (*(byte **)(psVar47 + 0xf) < pbVar38 + uVar34))
  {
    *(undefined8 *)(puVar40 + -8) = 0x101f7f;
    cVar11 = func_0x(0x1fa68c0);
    if (cVar11 != '\0') {
      *(undefined8 *)(puVar40 + -8) = 0x101f88;
      lVar22 = func_0x();
      if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
        *(undefined8 *)(puVar40 + -8) = 0x101fa2;
        cVar11 = func_0x(0x1fa68c0);
        if (cVar11 == '\0') {
          *(undefined8 *)(puVar40 + -8) = 0x101fbe;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(puVar40 + 0x20) = 0;
          *(undefined8 *)(puVar40 + -8) = 0x101fe4;
          (*_DAT_)(1,0x18962cc,0x19b63b8,0x886);
        }
      }
    }
    uVar30 = *(undefined8 *)(psVar47 + 4);
    *(undefined8 *)(puVar40 + -8) = 0x101ff3;
    func_0x(uVar30,0x12);
    uVar34 = *(uint *)(psVar47 + 2);
  }
  if ((uVar34 == 0) || (0x3f3c < uVar34)) {
    *(undefined8 *)(puVar40 + -8) = 0x102014;
    cVar11 = func_0x(0x1fa68c0);
    if (cVar11 != '\0') {
      *(undefined8 *)(puVar40 + -8) = 0x10201d;
      lVar22 = func_0x();
      if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
        *(undefined8 *)(puVar40 + -8) = 0x102037;
        cVar11 = func_0x(0x1fa68c0);
        if (cVar11 == '\0') {
          *(undefined8 *)(puVar40 + -8) = 0x102053;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)(puVar40 + 0x20) = 0;
          *(undefined8 *)(puVar40 + -8) = 0x102079;
          (*_DAT_)(1,0x18962cc,0x19b63b8,0x88b);
        }
      }
    }
    uVar30 = *(undefined8 *)(psVar47 + 4);
    *(undefined8 *)(puVar40 + -8) = 0x102088;
    func_0x(uVar30,5);
    uVar34 = *(uint *)(psVar47 + 2);
  }
LAB_:
  iVar16 = 0;
  if (uVar34 < 9) {
    pbVar32 = *(byte **)(psVar47 + 4);
    if (((*pbVar32 & 0xe) != 0) && ((*pbVar32 & 0xe) != 0xc)) goto LAB_;
    uVar34 = 9;
  }
  else {
LAB_:
    pbVar32 = *(byte **)(psVar47 + 4);
  }
  *(undefined4 *)(&stack0x00000710 + lVar19) = *(undefined4 *)(psVar47 + 8);
  *(short *)(&stack0x00000702 + lVar19) = psVar47[1];
  *(undefined4 *)(&stack0x00000704 + lVar19) = *(undefined4 *)(psVar47 + 2);
  *(short *)(&stack0x0000071c + lVar19) = psVar47[0xe];
  *(undefined4 *)(&stack0x00000714 + lVar19) = *(undefined4 *)(psVar47 + 10);
  *(undefined4 *)(&stack0x00000718 + lVar19) = *(undefined4 *)(psVar47 + 0xc);
  *(undefined4 *)(&stack0x00000726 + lVar19) = *(undefined4 *)(psVar47 + 0x13);
  *(undefined8 *)(puVar40 + -8) = 0x102114;
  func_0x(&stack0x00001218 + lVar19,0x1f9e,pbVar32,uVar34);
  *(undefined **)(&stack0x00000708 + lVar19) = &stack0x00001218 + lVar19;
  *(undefined8 *)(puVar40 + -8) = 0x10212e;
  iVar18 = func_0x(&stack0x00000702 + lVar19);
  if (iVar18 != 0) {
    lVar22 = *(longlong *)(&stack0x00000708 + lVar19);
    puVar35 = (ushort *)((ulonglong)*(uint *)(&stack0x00000714 + lVar19) + lVar22);
    uVar34 = *puVar35 - 1;
    if (((&stack0x00000702)[lVar19] & 1) == 0) {
      uVar34 = (uint)*puVar35;
    }
    uVar43 = *(uint *)(&stack0x00000718 + lVar19);
    if (uVar34 != 1) {
      uVar43 = puVar35[(longlong)(int)uVar34 + -1] & 0x7fff;
    }
    uVar34 = puVar35[(int)uVar34] & 0x7fff;
    if (((uVar43 < *(uint *)(&stack0x00000718 + lVar19)) || (uVar34 < uVar43)) ||
       (*(uint *)(&stack0x00000704 + lVar19) < uVar34)) {
      *(undefined8 *)(puVar40 + -8) = 0x10219d;
      func_0x(lVar22,7);
      lVar22 = *(longlong *)(&stack0x00000708 + lVar19);
    }
    uVar45 = (ulonglong)(uVar43 & 0xffff);
    *(short *)(&stack0x0000072a + lVar19) = (short)uVar43;
    uVar25 = uVar45 + lVar22;
    uVar14 = *(ushort *)(&stack0x0000072c + lVar19);
    if ((*(ushort *)(uVar25 + 2) >> 0xe & 1) == 0) {
      uVar14 = uVar14 & 0xc7ff;
    }
    else {
      uVar14 = uVar14 ^ (uVar14 ^ *(ushort *)(uVar25 + 2)) & 0x3800;
    }
    *(ushort *)(&stack0x0000072c + lVar19) = uVar14;
    uVar15 = (uVar14 ^ *(ushort *)(uVar25 + 2)) & 0x7ff ^ uVar14;
    *(ushort *)(&stack0x0000072c + lVar19) = uVar15;
    uVar36 = (ulonglong)((uVar15 & 0x7ff) * 2) + 4 + uVar45 + (uVar14 >> 0xb & 7) * 2 + lVar22;
    if (uVar36 < uVar25) {
      *(undefined8 *)(puVar40 + -8) = 0x102243;
      func_0x(uVar25,0x19);
      uVar15 = *(ushort *)(&stack0x0000072c + lVar19);
      uVar45 = (ulonglong)*(ushort *)(&stack0x0000072a + lVar19);
      lVar22 = *(longlong *)(&stack0x00000708 + lVar19);
    }
    if (uVar34 - uVar43 <
        (((*(uint *)(&stack0x0000072c + lVar19) & 0x7ff) * 2 - (int)uVar45) -
        *(int *)(&stack0x00000708 + lVar19)) + (int)uVar36) {
      *(undefined8 *)(puVar40 + -8) = 0x102288;
      func_0x(uVar45 + lVar22,0x19);
      uVar15 = *(ushort *)(&stack0x0000072c + lVar19);
      uVar45 = (ulonglong)*(ushort *)(&stack0x0000072a + lVar19);
      lVar22 = *(longlong *)(&stack0x00000708 + lVar19);
    }
    if (((uVar15 & 0x3800) != 0) &&
       (puVar35 = (ushort *)(lVar22 + 4 + uVar45), (uVar15 & 0x3800) != 0)) {
      do {
        if ((uVar15 & 0x7ff) < (*puVar35 & 0x7ff)) {
          *(undefined8 *)(puVar40 + -8) = 0x1022e5;
          func_0x(uVar45 + lVar22,0x1a);
          uVar15 = *(ushort *)(&stack0x0000072c + lVar19);
          uVar45 = (ulonglong)*(ushort *)(&stack0x0000072a + lVar19);
          lVar22 = *(longlong *)(&stack0x00000708 + lVar19);
        }
        iVar16 = iVar16 + 1;
        puVar35 = puVar35 + 1;
      } while (iVar16 < (int)(*(uint *)(&stack0x0000072c + lVar19) >> 0xb & 7));
    }
  }
  lVar22 = *(longlong *)(&stack0x000000a8 + lVar19);
LAB_:
  *(undefined8 *)(puVar40 + -8) = 0x10231e;
  func_0x(lVar22);
  if ((*(byte *)(lVar22 + 0x10) & 0x80) == 0) {
    uVar30 = *(undefined8 *)(lVar22 + 0x18);
    *(undefined8 *)(puVar40 + -8) = 0x10232d;
    func_0x(uVar30);
    *(uint *)(lVar22 + 0x10) = *(uint *)(lVar22 + 0x10) | 0x80;
  }
  (&stack0x00000080)[lVar19] = 1;
  psVar47 = (short *)(&stack0x00000700 + lVar19);
  puVar44 = &stack0x00000702 + lVar19;
LAB_:
  *(undefined8 *)(&stack0x000006e0 + lVar19) = 0;
  *(undefined2 *)(&stack0x000006e8 + lVar19) = 0;
  plVar20 = *(longlong **)(*(longlong *)(lVar22 + 0xf8) + 0x18);
  plVar21 = *(longlong **)(&stack0x000000d0 + lVar19);
  lVar22 = plVar21[6];
  cVar11 = *(char *)(lVar22 + 0x1cde);
  if ((*(char *)(lVar22 + 0x2050) != '\0') && ((*(byte *)(plVar20 + 2) & 1) != 0)) {
    pcVar4 = *(code **)(*plVar21 + 0xf0);
    *(undefined8 *)(puVar40 + -8) = 0x102402;
    iVar16 = (*pcVar4)(plVar21);
    if (iVar16 == 0) {
      lVar26 = plVar21[0x49];
    }
    else {
      pcVar4 = *(code **)(*plVar21 + 0x1e8);
      *(undefined8 *)(puVar40 + -8) = 0x102412;
      lVar26 = (*pcVar4)(plVar21);
      lVar26 = *(longlong *)(lVar26 + 0x248);
    }
    if (*(char *)(lVar26 + 0x16) == '\0') {
      *(undefined8 *)(puVar40 + -8) = 0x10243e;
      (*_DAT_)(0x27,0x30,0x10,2);
    }
  }
  *(undefined8 *)(puVar40 + -8) = 0x10244d;
  func_0x(&stack0x00000528 + lVar19,psVar47);
  *(undefined4 *)(&stack0x0000008c + lVar19) = 1;
  if ((char)uVar13 == '\0') {
    if ((DAT_ & 8) == 0) {
      lVar22 = *(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                );
      if ((lVar22 != 0) && (lVar22 = **(longlong **)(lVar22 + 0x38), lVar22 != 0)) {
        *(undefined8 *)(puVar40 + -8) = 0x1028b5;
        iVar16 = (*_DAT_)(lVar22,0xf73);
        if (iVar16 != 0) goto LAB_;
      }
    }
    else {
LAB_:
      if (plVar21[0x1a] == 0) {
        uVar30 = 0;
      }
      else {
        uVar30 = *(undefined8 *)(plVar21[0x1a] + 0x40);
      }
      plVar21 = *(longlong **)(&stack0x000000d0 + lVar19);
      uVar3 = *(undefined2 *)(plVar21[6] + 0x6b8);
      pcVar4 = *(code **)(*(longlong *)plVar21[0x52] + 0x138);
      *(undefined8 *)(puVar40 + -8) = 0x1028f0;
      uVar27 = (*pcVar4)();
      *(undefined8 *)(puVar40 + 0x20) = uVar30;
      lVar22 = plVar20[5];
      *(undefined8 *)(puVar40 + -8) = 0x10290a;
      func_0x(0x189f370,uVar3,lVar22,uVar27);
    }
LAB_:
    if ((DAT_ & 8) == 0) {
      lVar22 = *(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                );
      if ((lVar22 != 0) && (lVar22 = **(longlong **)(lVar22 + 0x38), lVar22 != 0)) {
        *(undefined8 *)(puVar40 + -8) = 0x102966;
        iVar16 = (*_DAT_)(lVar22,0xf73);
        if (iVar16 != 0) goto LAB_;
      }
    }
    else {
LAB_:
      *(undefined8 *)(puVar40 + -8) = 0x10297b;
      (*_DAT_)(&stack0x00000258 + lVar19);
      *(undefined8 *)(puVar40 + -8) = 0x102982;
      uVar30 = (*_DAT_)();
      *(undefined8 *)(puVar40 + -8) = 0x102993;
      lVar22 = (*_DAT_)(uVar30,0,0x6c0);
      *(longlong *)(&stack0x000001d8 + lVar19) = lVar22;
      if (lVar22 == 0) {
        puVar23 = (undefined8 *)0x0;
      }
      else {
        *(undefined8 *)(puVar40 + -8) = 0x1029a9;
        puVar23 = (undefined8 *)func_0x(lVar22,0);
      }
      if (puVar23 != (undefined8 *)0x0) {
        *(undefined8 *)(puVar40 + -8) = 0x1029cc;
        iVar16 = (*_DAT_)(&stack0x00000258 + lVar19,puVar23);
        if (iVar16 == 0) {
          pcVar4 = *(code **)*puVar23;
          *(undefined8 *)(puVar40 + -8) = 0x1029dd;
          (*pcVar4)(puVar23,1);
        }
      }
      *(undefined8 *)(puVar40 + -8) = 0x1029f0;
      func_0x(&stack0x00000528 + lVar19,&stack0x00000258 + lVar19);
      *(undefined8 *)(puVar40 + -8) = 0x1029fe;
      (*_DAT_)(&stack0x00000258 + lVar19);
    }
  }
  else {
    lVar26 = plVar21[6];
    if (*(char *)(lVar26 + 0x1ad8) != '\0') {
LAB_:
      puVar5 = *(uint **)(*(longlong *)(lVar26 + 0x6b0) + 0x2c0);
      uVar34 = *(uint *)(&stack0x000001c0 + lVar19);
      if ((((*(short *)((longlong)puVar5 + 10) == 2) && (uVar34 == 0)) || (*puVar5 < uVar34)) ||
         ((uVar34 == *puVar5 &&
          ((puVar5[1] < *(uint *)(&stack0x000001c4 + lVar19) ||
           ((*(uint *)(&stack0x000001c4 + lVar19) == puVar5[1] &&
            (*(ushort *)(puVar5 + 2) < *(ushort *)(&stack0x000000e0 + lVar19)))))))))
      goto LAB_;
      if (*(char *)(lVar26 + 0x2050) != '\0') {
        if (*psVar47 == 0) {
          *(undefined8 *)(puVar40 + -8) = 0x10250a;
          func_0x();
        }
        else {
          *(undefined8 *)(puVar40 + -8) = 0x102511;
          func_0x(puVar44,&stack0x000001b8 + lVar19);
        }
        *(undefined8 *)(puVar40 + -8) = 0x10251d;
        cVar12 = func_0x(&stack0x000001b8 + lVar19);
        if (cVar12 != '\0') goto LAB_;
      }
      if ((DAT_ & 8) != 0) {
LAB_:
        plVar21 = *(longlong **)(&stack0x000000d0 + lVar19);
        if (plVar21[0x1a] == 0) {
          uVar30 = 0;
        }
        else {
          uVar30 = *(undefined8 *)(plVar21[0x1a] + 0x40);
        }
        uVar3 = *(undefined2 *)(plVar21[6] + 0x6b8);
        pcVar4 = *(code **)(*(longlong *)plVar21[0x52] + 0x138);
        *(undefined8 *)(puVar40 + -8) = 0x1025b3;
        uVar27 = (*pcVar4)();
        *(undefined8 *)(puVar40 + 0x20) = uVar30;
        lVar22 = plVar20[5];
        *(undefined8 *)(puVar40 + -8) = 0x1025cd;
        func_0x(0x189f2c0,uVar3,lVar22,uVar27);
        goto LAB_;
      }
      lVar22 = *(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                );
      if ((lVar22 != 0) && (lVar22 = **(longlong **)(lVar22 + 0x38), lVar22 != 0)) {
        *(undefined8 *)(puVar40 + -8) = 0x102574;
        iVar16 = (*_DAT_)(lVar22,0xf73);
        if (iVar16 != 0) goto LAB_;
      }
LAB_:
      plVar21 = *(longlong **)(&stack0x000000d0 + lVar19);
      goto LAB_;
    }
    if (*psVar47 == 0) {
      *(undefined8 *)(puVar40 + -8) = 0x102481;
      func_0x();
    }
    else {
      *(undefined8 *)(puVar40 + -8) = 0x102488;
      func_0x(puVar44,&stack0x00000198 + lVar19);
    }
    *(undefined8 *)(puVar40 + -8) = 0x102494;
    cVar12 = func_0x(&stack0x00000198 + lVar19);
    if (cVar12 == '\0') goto LAB_;
LAB_:
    if (*(short *)(&stack0x00000528 + lVar19) == 0) {
      bVar31 = **(byte **)(&stack0x00000530 + lVar19) >> 6;
    }
    else {
      bVar31 = **(byte **)(&stack0x00000530 + lVar19) >> 1;
    }
    if ((bVar31 & 1) == 0) goto LAB_;
    if (*(short *)(&stack0x00000528 + lVar19) == 0) {
      *(undefined8 *)(puVar40 + -8) = 0x102615;
      func_0x();
    }
    else {
      *(undefined8 *)(puVar40 + -8) = 0x10261c;
      func_0x(&stack0x0000052a + lVar19,&stack0x00000130 + lVar19);
    }
    if ((*(short *)(&stack0x00000134 + lVar19) == 0) && (*(int *)(&stack0x00000130 + lVar19) == 0))
    goto LAB_;
    plVar21 = *(longlong **)(&stack0x000000d0 + lVar19);
    if ((plVar20 == (longlong *)0x0) || ((*(byte *)(plVar20 + 2) & 0x20) == 0)) {
LAB_:
      *(undefined8 *)(puVar40 + 0x58) = 0;
      if (*psVar47 == 1) {
        *(undefined **)(puVar40 + 0x50) = &stack0x000006e0 + lVar19;
        *(undefined8 *)(puVar40 + 0x48) = 0;
        *(undefined8 *)(puVar40 + 0x40) = 0;
        puVar40[0x38] = 1;
        *(undefined **)(puVar40 + 0x30) = &stack0x0000008c + lVar19;
        *(undefined **)(puVar40 + 0x28) = &stack0x00000528 + lVar19;
        *(longlong **)(puVar40 + 0x20) = plVar20;
        *(undefined8 *)(puVar40 + -8) = 0x10281f;
        func_0x(psVar47,&stack0x000031b8 + lVar19,0x1f9e,plVar21);
      }
      else {
        puVar40[0x50] = 0;
        *(undefined **)(puVar40 + 0x48) = &stack0x000006e0 + lVar19;
        *(undefined8 *)(puVar40 + 0x40) = 0;
        *(undefined8 *)(puVar40 + 0x38) = 0;
        puVar40[0x30] = 1;
        *(undefined **)(puVar40 + 0x28) = &stack0x0000008c + lVar19;
        *(undefined **)(puVar40 + 0x20) = &stack0x00000528 + lVar19;
        *(undefined8 *)(puVar40 + -8) = 0x102869;
        func_0x(&stack0x000031b8 + lVar19,0x1f9e,plVar21,plVar20);
      }
    }
    else {
      plVar28 = plVar21;
      if ((*(byte *)(plVar21 + 0x43) & 4) != 0) {
        pcVar4 = *(code **)(*plVar21 + 0x1e8);
        *(undefined8 *)(puVar40 + -8) = 0x102668;
        plVar28 = (longlong *)(*pcVar4)(plVar21);
      }
      if (*(short *)(&stack0x00000528 + lVar19) == 0) {
        *(undefined8 *)(puVar40 + -8) = 0x102689;
        func_0x();
      }
      else {
        *(undefined8 *)(puVar40 + -8) = 0x102690;
        func_0x(&stack0x0000052a + lVar19);
      }
      if ((*(short *)(&stack0x0000013a + lVar19) != *(short *)((longlong)plVar28 + 0x2c)) ||
         (*(int *)(&stack0x00000136 + lVar19) != *(int *)(plVar28 + 5))) goto LAB_;
      lVar26 = plVar21[0x1a];
      if (cVar11 == '\0') {
LAB_:
        *(undefined8 *)(puVar40 + 0x50) = 0;
        *(undefined **)(puVar40 + 0x48) = &stack0x0000008c + lVar19;
        puVar40[0x40] = 0;
        *(undefined8 *)(puVar40 + 0x38) = 0;
        *(undefined **)(puVar40 + 0x30) = &stack0x00000528 + lVar19;
        *(longlong *)(puVar40 + 0x28) = *plVar20;
        *(undefined4 *)(puVar40 + 0x20) = 0x1f9e;
        uVar30 = *(undefined8 *)(lVar22 + 0x6b0);
        lVar26 = plVar20[4];
        lVar29 = plVar21[0x1a];
        *(undefined8 *)(puVar40 + -8) = 0x102736;
        func_0x(lVar29,lVar26,uVar30,&stack0x000031b8 + lVar19);
        if (cVar11 != '\0') goto LAB_;
      }
      else {
        if (((lVar26 != 0) && (*(char *)(lVar26 + 0x34) != '\0')) &&
           (*(longlong *)(lVar26 + 0x40) != 0)) {
          LOCK();
          lVar29 = *(longlong *)(lVar26 + 0x128);
          if (lVar29 == 0) {
            *(longlong *)(lVar26 + 0x128) = 0;
            lVar29 = 0;
          }
          UNLOCK();
          if (*(longlong *)(*plVar20 + 0x28) != lVar29) goto LAB_;
        }
LAB_:
        if (*(short *)(&stack0x00000528 + lVar19) == 0) {
          *(undefined8 *)(puVar40 + -8) = 0x10275c;
          func_0x();
        }
        else {
          *(undefined8 *)(puVar40 + -8) = 0x102763;
          func_0x(&stack0x0000052a + lVar19,&stack0x000001a0 + lVar19);
        }
        if (*(short *)(&stack0x00000528 + lVar19) == 0) {
          *(undefined8 *)(puVar40 + -8) = 0x102780;
          func_0x();
        }
        else {
          *(undefined8 *)(puVar40 + -8) = 0x102787;
          func_0x(&stack0x0000052a + lVar19,&stack0x0000013c + lVar19);
        }
        *(undefined4 *)(&stack0x0000011c + lVar19) = *(undefined4 *)(&stack0x0000013c + lVar19);
        *(undefined2 *)(&stack0x00000120 + lVar19) = *(undefined2 *)(&stack0x00000140 + lVar19);
        *(undefined8 *)(puVar40 + -8) = 0x1027bb;
        iVar16 = func_0x(lVar22 + 0x19c8,&stack0x0000011c + lVar19,&stack0x000001a0 + lVar19
                                );
        if (iVar16 != 0) goto LAB_;
      }
    }
  }
  cVar11 = (&stack0x00000088)[lVar19];
  if ((cVar11 != '\0') && (*(int *)(&stack0x0000008c + lVar19) == 1)) {
    pcVar4 = *(code **)(**(longlong **)(&stack0x000000a8 + lVar19) + 8);
    *(undefined8 *)(puVar40 + -8) = 0x102a1d;
    (*pcVar4)();
    puVar23 = *(undefined8 **)(&stack0x00000128 + lVar19);
    if (puVar23 != (undefined8 *)0x0) {
      pcVar4 = *(code **)*puVar23;
      *(undefined8 *)(puVar40 + -8) = 0x102a35;
      (*pcVar4)(puVar23,1);
    }
    goto LAB_;
  }
  if ((2 < *(int *)(&stack0x0000008c + lVar19) - 2U) && (*(int *)(&stack0x0000008c + lVar19) != 0))
  {
    *(undefined8 *)(puVar40 + 0x20) = 0;
    *(undefined8 *)(puVar40 + -8) = 0x102a74;
    (*_DAT_)(1,0x1a45ad0,0x1a1ac00,0xc58);
  }
  sVar33 = *(short *)(&stack0x00000528 + lVar19);
  pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
  if (sVar33 == 0) {
    bVar31 = *pbVar32 >> 6;
  }
  else {
    bVar31 = *pbVar32 >> 1;
  }
  if ((bVar31 & 1) != 0) {
    if (sVar33 == 0) {
      *(undefined8 *)(puVar40 + -8) = 0x102aba;
      func_0x();
    }
    else {
      *(undefined8 *)(puVar40 + -8) = 0x102ac1;
      func_0x(&stack0x0000052a + lVar19,&stack0x000000c0 + lVar19);
    }
    sVar33 = *(short *)(&stack0x00000528 + lVar19);
    pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
  }
  if (*(int *)(&stack0x0000008c + lVar19) == 0) {
LAB_:
    bVar52 = true;
  }
  else {
    bVar52 = false;
    if (sVar33 == 0) {
      bVar31 = *pbVar32 & 0xe;
      if (bVar31 == 2) {
        bVar52 = (pbVar32[1] & 1) != 0;
      }
      else if (((bVar31 - 10 & 0xf9) == 0) && (bVar31 != 0x10)) {
        bVar52 = true;
      }
    }
    else {
      bVar52 = ((*pbVar32 & 0x1c) - 4 & 0xffffffe7) == 0;
    }
    if (bVar52) goto LAB_;
    bVar52 = false;
  }
  if (cVar11 == '\0') {
    if (bVar52) {
      if ((&stack0x00000090)[lVar19] != '\0') {
        if (*(int *)(&stack0x0000008c + lVar19) == 0) {
          cVar12 = '\0';
        }
        else {
          uVar30 = *(undefined8 *)(&stack0x00000098 + lVar19);
          *(undefined8 *)(puVar40 + -8) = 0x102b50;
          cVar12 = func_0x(uVar30,&stack0x00000528 + lVar19);
          sVar33 = *(short *)(&stack0x00000528 + lVar19);
        }
        if ((&stack0x00000091)[lVar19] == '\x04') {
          uVar34 = *(uint *)(&stack0x000000a0 + lVar19) & 0xff;
          if (cVar12 == '\0') {
            uVar34 = 1;
          }
          *(uint *)(&stack0x000000a0 + lVar19) = uVar34;
        }
      }
      if (*(int *)(&stack0x0000008c + lVar19) == 0) {
LAB_:
        bVar9 = false;
      }
      else {
        if (sVar33 == 0) {
          *(undefined8 *)(puVar40 + -8) = 0x102b93;
          func_0x();
        }
        else {
          *(undefined8 *)(puVar40 + -8) = 0x102b9a;
          func_0x(&stack0x0000052a + lVar19,&stack0x00000142 + lVar19);
        }
        if ((*(short *)(&stack0x00000146 + lVar19) == 0) &&
           (*(int *)(&stack0x00000142 + lVar19) == 0)) goto LAB_;
        if (*(short *)(&stack0x00000528 + lVar19) == 0) {
          *(undefined8 *)(puVar40 + -8) = 0x102bce;
          func_0x();
        }
        else {
          *(undefined8 *)(puVar40 + -8) = 0x102bd5;
          func_0x(&stack0x0000052a + lVar19,&stack0x000001a8 + lVar19);
        }
        *(undefined8 *)(&stack0x000005d8 + lVar19) = *(undefined8 *)(&stack0x000001a8 + lVar19);
        if (*(short *)(&stack0x00000528 + lVar19) == 0) {
          *(undefined8 *)(puVar40 + -8) = 0x102c00;
          func_0x();
        }
        else {
          *(undefined8 *)(puVar40 + -8) = 0x102c07;
          func_0x(&stack0x0000052a + lVar19,&stack0x00000148 + lVar19);
        }
        *(undefined4 *)(&stack0x000005e0 + lVar19) = *(undefined4 *)(&stack0x00000148 + lVar19);
        *(undefined2 *)(&stack0x000005e4 + lVar19) = *(undefined2 *)(&stack0x0000014c + lVar19);
        bVar9 = true;
        *pcVar1 = '\x01';
      }
      cVar12 = (char)*(undefined4 *)(&stack0x000000a0 + lVar19);
      goto LAB_;
    }
LAB_:
    cVar12 = '\0';
    cVar41 = '\0';
    bVar9 = false;
    bVar8 = false;
    *pcVar1 = '\0';
    lVar22 = *(longlong *)(&stack0x00000098 + lVar19);
    if (*(longlong *)(&stack0x000000b0 + lVar19) == 0) goto LAB_;
    cVar2 = *(char *)(*(longlong *)(&stack0x000000b0 + lVar19) + 3);
    *pcVar1 = '\0';
    if ((cVar2 == '\0') ||
       (lVar26 = *(longlong *)(lVar22 + 8), *pcVar1 = '\0', *(char *)(lVar26 + 0x751) != '\0'))
    goto LAB_;
    *(longlong *)(puVar40 + 0x20) = lVar22;
    lVar26 = *(longlong *)(&stack0x000000a8 + lVar19);
    *(undefined8 *)(puVar40 + -8) = 0x102c8f;
    iVar16 = func_0x(lVar26,cVar2,&stack0x00000528 + lVar19,plVar21);
    if (iVar16 != 0) {
      *(undefined8 *)(puVar40 + 0x20) = 0;
      *(undefined8 *)(puVar40 + -8) = 0x102cb7;
      (*_DAT_)(1,0x1a45ab8,0x1a1ac00,0xccb);
    }
    *pcVar1 = '\0';
  }
  else {
    cVar12 = '\0';
    bVar9 = false;
    *pcVar1 = '\0';
    if (!bVar52) goto LAB_;
LAB_:
    lVar22 = *(longlong *)(&stack0x00000098 + lVar19);
LAB_:
    bVar8 = bVar9;
    cVar41 = cVar12;
    lVar26 = *(longlong *)(&stack0x000000a8 + lVar19);
  }
  if ((&stack0x00000080)[lVar19] == '\0') {
    *(undefined8 *)(puVar40 + -8) = 0x102cd9;
    func_0x(lVar26);
    if ((*(byte *)(lVar26 + 0x10) & 0x80) == 0) {
      uVar30 = *(undefined8 *)(lVar26 + 0x18);
      *(undefined8 *)(puVar40 + -8) = 0x102ce8;
      func_0x(uVar30);
      *(uint *)(lVar26 + 0x10) = *(uint *)(lVar26 + 0x10) | 0x80;
    }
  }
  puVar44 = &stack0x00000528 + lVar19;
  if (*(int *)(&stack0x0000008c + lVar19) == 0) {
    puVar44 = (undefined *)0x0;
  }
  uVar10 = (&stack0x00000170)[lVar19];
  uVar34 = *(uint *)(&stack0x000000c8 + lVar19);
  cVar12 = (char)uVar34;
  *(undefined8 *)(puVar40 + -8) = 0x102d19;
  iVar16 = func_0x(puVar44,uVar34 & 0xff,&stack0x00000040 + lVar19,uVar10);
  *(int *)(&stack0x000000c0 + lVar19) = iVar16;
  if (cVar11 == '\0') {
    if (bVar52) {
      if (cVar41 == '\0') {
        if (cVar12 == '\0') {
LAB_:
          if (bVar8) {
            uVar34 = *(uint *)(&stack0x0000052c + lVar19);
            if (*(short *)(&stack0x00000528 + lVar19) == 0) {
              pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
              *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
              if (uVar34 == 0) {
                iVar18 = 0;
                *(undefined2 *)(&stack0x0000052a + lVar19) = 0;
                uVar34 = *(uint *)(&stack0x00000538 + lVar19);
                uVar25 = (ulonglong)uVar34;
                *(uint *)(&stack0x0000053c + lVar19) = uVar34;
                if ((*pbVar32 & 0x10) != 0) {
                  uVar34 = uVar34 + 2 + (*(ushort *)(pbVar32 + uVar25) + 7 >> 3);
                  uVar25 = (ulonglong)uVar34;
                  *(uint *)(&stack0x0000053c + lVar19) = uVar34;
                }
                if ((*pbVar32 & 0x20) == 0) {
                  *(int *)(&stack0x0000052c + lVar19) = (int)uVar25;
                  *(undefined2 *)(&stack0x00000544 + lVar19) = 0;
                  *(int *)(&stack0x00000540 + lVar19) = (int)uVar25;
                }
                else {
                  puVar35 = (ushort *)(pbVar32 + uVar25);
                  *(ushort **)(&stack0x000000b0 + lVar19) = puVar35;
                  uVar13 = *puVar35;
                  *(ushort *)(&stack0x00000544 + lVar19) = uVar13;
                  if (uVar13 == 0) {
                    *(undefined8 *)(puVar40 + -8) = 0x106863;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 != '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x10686c;
                      lVar22 = func_0x();
                      if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar40 + -8) = 0x106886;
                        cVar11 = func_0x(0x1fa68c0);
                        if (cVar11 == '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x1068a2;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(puVar40 + 0x20) = 0;
                          *(undefined8 *)(puVar40 + -8) = 0x1068c8;
                          (*_DAT_)(1,0x18962cc,0x19b63b8,0x80f);
                        }
                      }
                    }
                    uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                    *(undefined8 *)(puVar40 + -8) = 0x1068d9;
                    func_0x(uVar30,3);
                    uVar13 = *(ushort *)(&stack0x00000544 + lVar19);
                    pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                    *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                  }
                  uVar43 = *(int *)(&stack0x0000053c + lVar19) + 2 + (uint)uVar13 * 2;
                  *(uint *)(&stack0x00000540 + lVar19) = uVar43;
                  if (0x1f9e < uVar43) {
                    *(undefined8 *)(puVar40 + -8) = 0x10691c;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 != '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x106925;
                      lVar22 = func_0x();
                      if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar40 + -8) = 0x10693f;
                        cVar11 = func_0x(0x1fa68c0);
                        if (cVar11 == '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x10695b;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar40 + 0x20) = 0;
                          *(undefined8 *)(puVar40 + -8) = 0x106981;
                          (*_DAT_)(1,0x18962cc,0x19b63b8,0x816);
                        }
                      }
                    }
                    uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                    *(undefined8 *)(puVar40 + -8) = 0x106992;
                    func_0x(uVar30,4);
                    uVar13 = *(ushort *)(&stack0x00000544 + lVar19);
                    uVar43 = *(uint *)(&stack0x00000540 + lVar19);
                    pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                    *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                  }
                  uVar45 = (ulonglong)uVar13;
                  uVar34 = puVar35[uVar45] & 0x7fff;
                  *(uint *)(&stack0x0000052c + lVar19) = uVar34;
                  if (uVar34 < uVar43) {
                    *(undefined8 *)(puVar40 + -8) = 0x1069d4;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 != '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x1069dd;
                      lVar22 = func_0x();
                      if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar40 + -8) = 0x1069f7;
                        cVar11 = func_0x(0x1fa68c0);
                        if (cVar11 == '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x106a13;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar40 + 0x20) = 0;
                          *(undefined8 *)(puVar40 + -8) = 0x106a39;
                          (*_DAT_)(1,0x18962cc,0x19b63b8,0x81d);
                        }
                      }
                    }
                    uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                    *(undefined8 *)(puVar40 + -8) = 0x106a4a;
                    func_0x(uVar30,4);
                    uVar45 = (ulonglong)*(ushort *)(&stack0x00000544 + lVar19);
                    uVar43 = *(uint *)(&stack0x00000540 + lVar19);
                    pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                    *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                    uVar34 = *(uint *)(&stack0x0000052c + lVar19);
                  }
                  uVar25 = (ulonglong)uVar34;
                  if ((short)uVar45 != 0) {
                    do {
                      puVar35 = puVar35 + 1;
                      uVar34 = *puVar35 & 0x7fff;
                      if ((uVar34 < uVar43) || ((uint)uVar25 < uVar34)) {
                        *(undefined8 *)(puVar40 + -8) = 0x106aa2;
                        cVar11 = func_0x(0x1fa68c0);
                        if (cVar11 != '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x106aab;
                          lVar22 = func_0x();
                          if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar40 + -8) = 0x106ac5;
                            cVar11 = func_0x(0x1fa68c0);
                            if (cVar11 == '\0') {
                              *(undefined8 *)(puVar40 + -8) = 0x106ae1;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar40 + 0x20) = 0;
                              *(undefined8 *)(puVar40 + -8) = 0x106b05;
                              (*_DAT_)(1,0x18962cc,0x19b63b8,0x82a);
                            }
                          }
                        }
                        uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                        *(undefined8 *)(puVar40 + -8) = 0x106b16;
                        func_0x(uVar30,4);
                        uVar45 = (ulonglong)*(ushort *)(&stack0x00000544 + lVar19);
                        pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                        uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                      }
                      iVar18 = iVar18 + 1;
                      uVar43 = uVar34;
                    } while (iVar18 < (int)uVar45);
                    *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                    uVar43 = *(uint *)(&stack0x00000540 + lVar19);
                    puVar35 = *(ushort **)(&stack0x000000b0 + lVar19);
                    iVar16 = *(int *)(&stack0x000000c0 + lVar19);
                  }
                  while( true ) {
                    sVar33 = (short)uVar45;
                    if (-1 < (short)puVar35[(ulonglong)((int)uVar45 - 1) + 1]) break;
                    uVar49 = uVar43;
                    if ((int)uVar45 != 1) {
                      uVar49 = *(ushort *)
                                (pbVar32 +
                                uVar45 * 2 + ((ulonglong)*(uint *)(&stack0x0000053c + lVar19) - 2))
                               & 0x7fff;
                    }
                    uVar50 = *(ushort *)
                              (pbVar32 +
                              uVar45 * 2 + (ulonglong)*(uint *)(&stack0x0000053c + lVar19)) & 0x7fff
                    ;
                    if (((uVar49 < uVar43) || (uVar50 < uVar49)) || ((uint)uVar25 < uVar50)) {
                      *(undefined8 *)(puVar40 + -8) = 0x106bba;
                      func_0x(pbVar32,7);
                      sVar33 = *(short *)(&stack0x00000544 + lVar19);
                      uVar43 = *(uint *)(&stack0x00000540 + lVar19);
                      pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                      *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                      uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                    }
                    uVar34 = (uint)uVar25;
                    if ((uVar49 < uVar43) || (uVar34 < uVar49)) goto LAB_;
                    if (*(ushort *)(pbVar32 + uVar49) == 5) {
                      *(ushort *)(&stack0x0000052a + lVar19) =
                           *(ushort *)(&stack0x0000052a + lVar19) | 2;
                      *(short *)(&stack0x00000544 + lVar19) = sVar33 + -1;
                      uVar45 = (ulonglong)(uVar49 & 0xffff);
                      *(short *)(&stack0x00000552 + lVar19) = (short)uVar49;
                      pbVar38 = pbVar32 + uVar45;
                      uVar13 = *(ushort *)(&stack0x00000554 + lVar19);
                      if ((*(ushort *)(pbVar38 + 2) >> 0xe & 1) == 0) {
                        uVar13 = uVar13 & 0xc7ff;
                      }
                      else {
                        uVar13 = uVar13 ^ (*(ushort *)(pbVar38 + 2) ^ uVar13) & 0x3800;
                      }
                      *(ushort *)(&stack0x00000554 + lVar19) = uVar13;
                      uVar14 = (uVar13 ^ *(ushort *)(pbVar38 + 2)) & 0x7ff ^ uVar13;
                      *(ushort *)(&stack0x00000554 + lVar19) = uVar14;
                      pbVar37 = pbVar32 + (ulonglong)((uVar14 & 0x7ff) * 2) + 4 +
                                          uVar45 + (uVar13 >> 0xb & 7) * 2;
                      if (pbVar37 < pbVar38) {
                        *(undefined8 *)(puVar40 + -8) = 0x106d2e;
                        func_0x(pbVar38,0x19);
                        uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                        uVar45 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                        pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                        *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                        uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                      }
                      if (uVar50 - uVar49 <
                          (((*(uint *)(&stack0x00000554 + lVar19) & 0x7ff) * 2 - (int)uVar45) -
                          *(int *)(&stack0x00000530 + lVar19)) + (int)pbVar37) {
                        *(undefined8 *)(puVar40 + -8) = 0x106d7d;
                        func_0x(pbVar32 + uVar45,0x19);
                        uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                        uVar45 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                        pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                        *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                        uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                      }
                      iVar18 = 0;
                      if (((uVar14 & 0x3800) != 0) &&
                         (puVar35 = (ushort *)(pbVar32 + uVar45 + 4), (uVar14 & 0x3800) != 0)) {
                        do {
                          if ((uVar14 & 0x7ff) < (*puVar35 & 0x7ff)) {
                            *(undefined8 *)(puVar40 + -8) = 0x106df5;
                            func_0x(pbVar32 + uVar45,0x1a);
                            uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                            uVar45 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                            pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                          }
                          iVar18 = iVar18 + 1;
                          puVar35 = puVar35 + 1;
                        } while (iVar18 < (int)(*(uint *)(&stack0x00000554 + lVar19) >> 0xb & 7));
                        *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                        uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                      }
                      break;
                    }
                    if (*(ushort *)(pbVar32 + uVar49) < 0x400) break;
                    *(ushort *)(&stack0x0000052a + lVar19) =
                         *(ushort *)(&stack0x0000052a + lVar19) | 1;
                    uVar13 = sVar33 - 1;
                    uVar45 = (ulonglong)uVar13;
                    *(ushort *)(&stack0x00000544 + lVar19) = uVar13;
                    if (uVar13 == 0) break;
                  }
                }
                iVar18 = 0;
                if ((*pbVar32 & 0x40) == 0) {
                  *(undefined4 *)(&stack0x0000054e + lVar19) = 0;
                }
                else {
                  *(int *)(&stack0x0000054e + lVar19) = (int)uVar25;
                  *(int *)(&stack0x0000052c + lVar19) = (int)uVar25 + 0xe;
                  *(undefined8 *)(puVar40 + -8) = 0x106c48;
                  puVar24 = (ulonglong *)func_0x(&stack0x0000052a + lVar19);
                  uVar13 = (ushort)(*puVar24 >> 0x30);
                  if ((((uint)(int)(short)uVar13 >> 1 ^ (int)(short)uVar13) & 0x2000) != 0) {
                    if ((uVar13 >> 0xe & 1) == 0) {
                      uVar13 = uVar13 & 0xdfff;
                    }
                    else {
                      uVar13 = uVar13 | 0x2000;
                    }
                  }
                  if (uVar13 == 0xfffc) {
                    iVar18 = (int)((*puVar24 >> 0x20 & 0xffff) >> 5);
                  }
                  uVar25 = (ulonglong)(uint)(*(int *)(&stack0x0000052c + lVar19) + iVar18);
                  *(int *)(&stack0x0000052c + lVar19) = *(int *)(&stack0x0000052c + lVar19) + iVar18
                  ;
                  pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                  *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                }
                uVar34 = (uint)uVar25;
                if ((*(byte **)(&stack0x00000546 + lVar19) != (byte *)0x0) &&
                   (*(byte **)(&stack0x00000546 + lVar19) < pbVar32 + uVar25)) {
                  *(undefined8 *)(puVar40 + -8) = 0x106eb1;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x106eba;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar40 + -8) = 0x106ed4;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x106ef0;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x106f16;
                        (*_DAT_)(1,0x18962cc,0x19b63b8,0x886);
                      }
                    }
                  }
                  uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x106f27;
                  func_0x(uVar30,0x12);
                  pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                  *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                  uVar34 = *(uint *)(&stack0x0000052c + lVar19);
                }
                if (0x3f3b < uVar34 - 1) {
                  *(undefined8 *)(puVar40 + -8) = 0x106f52;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x106f5b;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar40 + -8) = 0x106f75;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x106f91;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x106fb7;
                        (*_DAT_)(1,0x18962cc,0x19b63b8,0x88b);
                      }
                    }
                  }
                  uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x106fc8;
                  func_0x(uVar30,5);
                  pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                  *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                  uVar34 = *(uint *)(&stack0x0000052c + lVar19);
                }
              }
LAB_:
              if (uVar34 < 9) {
                bVar31 = *pbVar32 & 0xe;
joined_r0x00107017:
                if ((bVar31 == 0) || (bVar31 == 0xc)) {
                  uVar34 = 9;
                }
              }
            }
            else {
              if (uVar34 == 0) {
                *(undefined8 *)(puVar40 + -8) = 0x106ffa;
                func_0x(&stack0x0000052a + lVar19);
                uVar34 = *(uint *)(&stack0x0000052c + lVar19);
              }
              pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
              *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
              if (uVar34 < 9) {
                bVar31 = *pbVar32 & 0x1c;
                goto joined_r0x00107017;
              }
            }
          }
          else {
            pbVar32 = (byte *)0x0;
            uVar34 = 0;
            *(undefined8 *)(&stack0x00000040 + lVar19) = 0;
          }
          iVar18 = 0;
          if (*(short *)(&stack0x00000048 + lVar19) == 0) {
            uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
            pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
            if (*(uint *)(&stack0x0000004c + lVar19) == 0) {
              *(undefined2 *)(&stack0x0000004a + lVar19) = 0;
              uVar43 = *(uint *)(&stack0x00000058 + lVar19);
              uVar25 = (ulonglong)uVar43;
              *(uint *)(&stack0x0000005c + lVar19) = uVar43;
              if ((*pbVar38 & 0x10) != 0) {
                uVar43 = uVar43 + 2 + (*(ushort *)(pbVar38 + uVar25) + 7 >> 3);
                uVar25 = (ulonglong)uVar43;
                *(uint *)(&stack0x0000005c + lVar19) = uVar43;
              }
              if ((*pbVar38 & 0x20) == 0) {
                *(int *)(&stack0x0000004c + lVar19) = (int)uVar25;
                *(undefined2 *)(&stack0x00000064 + lVar19) = 0;
                *(int *)(&stack0x00000060 + lVar19) = (int)uVar25;
              }
              else {
                puVar35 = (ushort *)(pbVar38 + uVar25);
                *(ushort **)(&stack0x000000b0 + lVar19) = puVar35;
                uVar13 = *puVar35;
                *(ushort *)(&stack0x00000064 + lVar19) = uVar13;
                if (uVar13 == 0) {
                  *(undefined8 *)(puVar40 + -8) = 0x1070aa;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x1070b3;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar40 + -8) = 0x1070cd;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x1070e9;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x10710f;
                        (*_DAT_)(1,0x18962cc,0x19b63b8,0x80f);
                      }
                    }
                  }
                  uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x10711d;
                  func_0x(uVar30,3);
                  uVar13 = *(ushort *)(&stack0x00000064 + lVar19);
                  pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                }
                uVar43 = *(int *)(&stack0x0000005c + lVar19) + 2 + (uint)uVar13 * 2;
                *(uint *)(&stack0x00000060 + lVar19) = uVar43;
                if (0x1f9e < uVar43) {
                  *(undefined8 *)(puVar40 + -8) = 0x107150;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x107159;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar40 + -8) = 0x107173;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x10718f;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x1071b5;
                        (*_DAT_)(1,0x18962cc,0x19b63b8,0x816);
                      }
                    }
                  }
                  uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x1071c3;
                  func_0x(uVar30,4);
                  uVar13 = *(ushort *)(&stack0x00000064 + lVar19);
                  uVar43 = *(uint *)(&stack0x00000060 + lVar19);
                  pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                }
                uVar45 = (ulonglong)uVar13;
                uVar49 = puVar35[uVar45] & 0x7fff;
                *(uint *)(&stack0x0000004c + lVar19) = uVar49;
                if (uVar49 < uVar43) {
                  *(undefined8 *)(puVar40 + -8) = 0x1071f8;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x107201;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar40 + -8) = 0x10721b;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x107237;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x10725d;
                        (*_DAT_)(1,0x18962cc,0x19b63b8,0x81d);
                      }
                    }
                  }
                  uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x10726b;
                  func_0x(uVar30,4);
                  uVar45 = (ulonglong)*(ushort *)(&stack0x00000064 + lVar19);
                  uVar43 = *(uint *)(&stack0x00000060 + lVar19);
                  pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                  uVar49 = *(uint *)(&stack0x0000004c + lVar19);
                }
                uVar25 = (ulonglong)uVar49;
                if ((short)uVar45 != 0) {
                  do {
                    puVar35 = puVar35 + 1;
                    uVar49 = *puVar35 & 0x7fff;
                    if ((uVar49 < uVar43) || ((uint)uVar25 < uVar49)) {
                      *(undefined8 *)(puVar40 + -8) = 0x1072b5;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 != '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x1072be;
                        lVar22 = func_0x();
                        if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar40 + -8) = 0x1072d8;
                          cVar11 = func_0x(0x1fa68c0);
                          if (cVar11 == '\0') {
                            *(undefined8 *)(puVar40 + -8) = 0x1072f4;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar40 + 0x20) = 0;
                            *(undefined8 *)(puVar40 + -8) = 0x107318;
                            (*_DAT_)(1,0x18962cc,0x19b63b8,0x82a);
                          }
                        }
                      }
                      uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                      *(undefined8 *)(puVar40 + -8) = 0x107326;
                      func_0x(uVar30,4);
                      uVar45 = (ulonglong)*(ushort *)(&stack0x00000064 + lVar19);
                      pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                      uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                    }
                    iVar18 = iVar18 + 1;
                    uVar43 = uVar49;
                  } while (iVar18 < (int)uVar45);
                  uVar43 = *(uint *)(&stack0x00000060 + lVar19);
                  pbVar32 = *(byte **)(&stack0x00000040 + lVar19);
                  puVar35 = *(ushort **)(&stack0x000000b0 + lVar19);
                }
                while( true ) {
                  sVar33 = (short)uVar45;
                  if (-1 < (short)puVar35[(ulonglong)((int)uVar45 - 1) + 1]) break;
                  uVar49 = uVar43;
                  if ((int)uVar45 != 1) {
                    uVar49 = *(ushort *)
                              (pbVar38 +
                              uVar45 * 2 + ((ulonglong)*(uint *)(&stack0x0000005c + lVar19) - 2)) &
                             0x7fff;
                  }
                  uVar50 = *(ushort *)
                            (pbVar38 + uVar45 * 2 + (ulonglong)*(uint *)(&stack0x0000005c + lVar19))
                           & 0x7fff;
                  if (((uVar49 < uVar43) || (uVar50 < uVar49)) || ((uint)uVar25 < uVar50)) {
                    *(undefined8 *)(puVar40 + -8) = 0x1073ba;
                    func_0x(pbVar38,7);
                    sVar33 = *(short *)(&stack0x00000064 + lVar19);
                    uVar43 = *(uint *)(&stack0x00000060 + lVar19);
                    pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                    uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                  }
                  if ((uVar49 < uVar43) || ((uint)uVar25 < uVar49)) goto LAB_;
                  if (*(ushort *)(pbVar38 + uVar49) == 5) {
                    *(ushort *)(&stack0x0000004a + lVar19) =
                         *(ushort *)(&stack0x0000004a + lVar19) | 2;
                    *(short *)(&stack0x00000064 + lVar19) = sVar33 + -1;
                    uVar45 = (ulonglong)(uVar49 & 0xffff);
                    *(short *)(&stack0x00000072 + lVar19) = (short)uVar49;
                    pbVar37 = pbVar38 + uVar45;
                    uVar13 = *(ushort *)(&stack0x00000074 + lVar19);
                    if ((*(ushort *)(pbVar37 + 2) >> 0xe & 1) == 0) {
                      uVar13 = uVar13 & 0xc7ff;
                    }
                    else {
                      uVar13 = uVar13 ^ (uVar13 ^ *(ushort *)(pbVar37 + 2)) & 0x3800;
                    }
                    *(ushort *)(&stack0x00000074 + lVar19) = uVar13;
                    uVar14 = (uVar13 ^ *(ushort *)(pbVar37 + 2)) & 0x7ff ^ uVar13;
                    *(ushort *)(&stack0x00000074 + lVar19) = uVar14;
                    pbVar48 = pbVar38 + (ulonglong)((uVar14 & 0x7ff) * 2) + 4 +
                                        (uVar13 >> 0xb & 7) * 2 + uVar45;
                    if (pbVar48 < pbVar37) {
                      *(undefined8 *)(puVar40 + -8) = 0x1074ff;
                      func_0x(pbVar37,0x19);
                      uVar14 = *(ushort *)(&stack0x00000074 + lVar19);
                      uVar45 = (ulonglong)*(ushort *)(&stack0x00000072 + lVar19);
                      pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                      uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                    }
                    if (uVar50 - uVar49 <
                        (((*(uint *)(&stack0x00000074 + lVar19) & 0x7ff) * 2 - (int)uVar45) -
                        *(int *)(&stack0x00000050 + lVar19)) + (int)pbVar48) {
                      *(undefined8 *)(puVar40 + -8) = 0x10753b;
                      func_0x(pbVar38 + uVar45,0x19);
                      uVar14 = *(ushort *)(&stack0x00000074 + lVar19);
                      uVar45 = (ulonglong)*(ushort *)(&stack0x00000072 + lVar19);
                      pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                      uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                    }
                    iVar16 = 0;
                    if (((uVar14 & 0x3800) != 0) &&
                       (puVar35 = (ushort *)(pbVar38 + uVar45 + 4), (uVar14 & 0x3800) != 0)) {
                      do {
                        if ((uVar14 & 0x7ff) < (*puVar35 & 0x7ff)) {
                          *(undefined8 *)(puVar40 + -8) = 0x1075a5;
                          func_0x(pbVar38 + uVar45,0x1a);
                          uVar14 = *(ushort *)(&stack0x00000074 + lVar19);
                          uVar45 = (ulonglong)*(ushort *)(&stack0x00000072 + lVar19);
                          pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                        }
                        iVar16 = iVar16 + 1;
                        puVar35 = puVar35 + 1;
                      } while (iVar16 < (int)(*(uint *)(&stack0x00000074 + lVar19) >> 0xb & 7));
                      uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                    }
                    break;
                  }
                  if (*(ushort *)(pbVar38 + uVar49) < 0x400) break;
                  *(ushort *)(&stack0x0000004a + lVar19) =
                       *(ushort *)(&stack0x0000004a + lVar19) | 1;
                  uVar13 = sVar33 - 1;
                  uVar45 = (ulonglong)uVar13;
                  *(ushort *)(&stack0x00000064 + lVar19) = uVar13;
                  if (uVar13 == 0) break;
                }
              }
              iVar16 = 0;
              if ((*pbVar38 & 0x40) == 0) {
                *(undefined4 *)(&stack0x0000006e + lVar19) = 0;
              }
              else {
                *(int *)(&stack0x0000006e + lVar19) = (int)uVar25;
                *(int *)(&stack0x0000004c + lVar19) = (int)uVar25 + 0xe;
                *(undefined8 *)(puVar40 + -8) = 0x107429;
                puVar24 = (ulonglong *)func_0x(&stack0x0000004a + lVar19);
                uVar13 = (ushort)(*puVar24 >> 0x30);
                if ((((uint)(int)(short)uVar13 >> 1 ^ (int)(short)uVar13) & 0x2000) != 0) {
                  if ((uVar13 >> 0xe & 1) == 0) {
                    uVar13 = uVar13 & 0xdfff;
                  }
                  else {
                    uVar13 = uVar13 | 0x2000;
                  }
                }
                if (uVar13 == 0xfffc) {
                  iVar16 = (int)((*puVar24 >> 0x20 & 0xffff) >> 5);
                }
                uVar25 = (ulonglong)(uint)(*(int *)(&stack0x0000004c + lVar19) + iVar16);
                *(int *)(&stack0x0000004c + lVar19) = *(int *)(&stack0x0000004c + lVar19) + iVar16;
                pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
              }
              if ((*(byte **)(&stack0x00000066 + lVar19) != (byte *)0x0) &&
                 (*(byte **)(&stack0x00000066 + lVar19) < pbVar38 + uVar25)) {
                *(undefined8 *)(puVar40 + -8) = 0x10763a;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x107643;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x10765d;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x107679;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x10769f;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x886);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x1076ad;
                func_0x(uVar30,0x12);
                pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
              }
              if (0x3f3b < (int)uVar25 - 1U) {
                *(undefined8 *)(puVar40 + -8) = 0x1076d0;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x1076d9;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x1076f3;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x10770f;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x107735;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x88b);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x107743;
                func_0x(uVar30,5);
                pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
              }
            }
LAB_:
            if ((8 < (uint)uVar25) || (((*pbVar38 & 0xe) != 0 && ((*pbVar38 & 0xe) != 0xc)))) {
              *(uint *)(&stack0x00000084 + lVar19) = (uint)uVar25;
            }
            iVar16 = *(int *)(&stack0x000000c0 + lVar19);
          }
          else {
            uVar43 = *(uint *)(&stack0x0000004c + lVar19);
            if (uVar43 == 0) {
              *(undefined8 *)(puVar40 + -8) = 0x107779;
              func_0x(&stack0x0000004a + lVar19);
              uVar43 = *(uint *)(&stack0x0000004c + lVar19);
            }
            pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
            if ((uVar43 < 9) && (((*pbVar38 & 0x1c) == 0 || ((*pbVar38 & 0x1c) == 0xc)))) {
              *(undefined4 *)(&stack0x00000084 + lVar19) = 9;
            }
            else {
              *(uint *)(&stack0x00000084 + lVar19) = uVar43;
            }
          }
          uVar6 = *(uint6 *)(*(longlong *)(&stack0x00000098 + lVar19) + 0x14);
          lVar22 = *(longlong *)(&stack0x00000110 + lVar19);
          *(undefined8 *)(puVar40 + -8) = 0x1077ca;
          func_0x(lVar22,(ulonglong)uVar6 << 0x10,1);
          puVar44 = &stack0x000005d8 + lVar19;
          if (*pcVar1 == '\0') {
            puVar44 = (undefined *)0x0;
          }
          puVar40[0x40] = iVar16 == 0;
          puVar40[0x38] = (char)*(undefined4 *)(&stack0x000000c8 + lVar19);
          *(uint *)(puVar40 + 0x30) = uVar34;
          *(byte **)(puVar40 + 0x28) = pbVar32;
          *(undefined8 *)(puVar40 + 0x20) = 0;
          uVar17 = *(undefined4 *)(&stack0x00000084 + lVar19);
          uVar30 = *(undefined8 *)(lVar22 + 0x2268);
          *(undefined8 *)(puVar40 + -8) = 0x107814;
          iVar16 = func_0x(uVar30,pbVar38,uVar17,puVar44);
          *(int *)(&stack0x000000cc + lVar19) = iVar16;
        }
        else {
          if (bVar8) {
            uVar34 = *(uint *)(&stack0x0000052c + lVar19);
            if (*(short *)(&stack0x00000528 + lVar19) == 0) {
              pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
              *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
              if (uVar34 == 0) {
                iVar16 = 0;
                *(undefined2 *)(&stack0x0000052a + lVar19) = 0;
                uVar34 = *(uint *)(&stack0x00000538 + lVar19);
                uVar25 = (ulonglong)uVar34;
                *(uint *)(&stack0x0000053c + lVar19) = uVar34;
                if ((*pbVar32 & 0x10) != 0) {
                  uVar34 = uVar34 + 2 + (*(ushort *)(pbVar32 + uVar25) + 7 >> 3);
                  uVar25 = (ulonglong)uVar34;
                  *(uint *)(&stack0x0000053c + lVar19) = uVar34;
                }
                iVar18 = 0;
                if ((*pbVar32 & 0x20) == 0) {
                  *(int *)(&stack0x0000052c + lVar19) = (int)uVar25;
                  *(undefined2 *)(&stack0x00000544 + lVar19) = 0;
                  *(int *)(&stack0x00000540 + lVar19) = (int)uVar25;
                }
                else {
                  puVar35 = (ushort *)(pbVar32 + uVar25);
                  *(ushort **)(&stack0x000000b0 + lVar19) = puVar35;
                  uVar13 = *puVar35;
                  *(ushort *)(&stack0x00000544 + lVar19) = uVar13;
                  if (uVar13 == 0) {
                    *(undefined8 *)(puVar40 + -8) = 0x103e9b;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 != '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x103ea4;
                      lVar22 = func_0x();
                      if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar40 + -8) = 0x103ebe;
                        cVar11 = func_0x(0x1fa68c0);
                        if (cVar11 == '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x103eda;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(puVar40 + 0x20) = 0;
                          *(undefined8 *)(puVar40 + -8) = 0x103f00;
                          (*_DAT_)(1,0x18962cc,0x19b63b8,0x80f);
                        }
                      }
                    }
                    uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                    *(undefined8 *)(puVar40 + -8) = 0x103f11;
                    func_0x(uVar30,3);
                    uVar13 = *(ushort *)(&stack0x00000544 + lVar19);
                    pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                    *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                  }
                  uVar43 = *(int *)(&stack0x0000053c + lVar19) + 2 + (uint)uVar13 * 2;
                  *(uint *)(&stack0x00000540 + lVar19) = uVar43;
                  if (0x1f9e < uVar43) {
                    *(undefined8 *)(puVar40 + -8) = 0x103f54;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 != '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x103f5d;
                      lVar22 = func_0x();
                      if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar40 + -8) = 0x103f77;
                        cVar11 = func_0x(0x1fa68c0);
                        if (cVar11 == '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x103f93;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar40 + 0x20) = 0;
                          *(undefined8 *)(puVar40 + -8) = 0x103fb9;
                          (*_DAT_)(1,0x18962cc,0x19b63b8,0x816);
                        }
                      }
                    }
                    uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                    *(undefined8 *)(puVar40 + -8) = 0x103fca;
                    func_0x(uVar30,4);
                    uVar13 = *(ushort *)(&stack0x00000544 + lVar19);
                    uVar43 = *(uint *)(&stack0x00000540 + lVar19);
                    pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                    *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                  }
                  uVar45 = (ulonglong)uVar13;
                  uVar34 = puVar35[uVar45] & 0x7fff;
                  *(uint *)(&stack0x0000052c + lVar19) = uVar34;
                  if (uVar34 < uVar43) {
                    *(undefined8 *)(puVar40 + -8) = 0x10400c;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 != '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x104015;
                      lVar22 = func_0x();
                      if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar40 + -8) = 0x10402f;
                        cVar11 = func_0x(0x1fa68c0);
                        if (cVar11 == '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x10404b;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar40 + 0x20) = 0;
                          *(undefined8 *)(puVar40 + -8) = 0x104071;
                          (*_DAT_)(1,0x18962cc,0x19b63b8,0x81d);
                        }
                      }
                    }
                    uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                    *(undefined8 *)(puVar40 + -8) = 0x104082;
                    func_0x(uVar30,4);
                    uVar45 = (ulonglong)*(ushort *)(&stack0x00000544 + lVar19);
                    uVar43 = *(uint *)(&stack0x00000540 + lVar19);
                    pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                    *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                    uVar34 = *(uint *)(&stack0x0000052c + lVar19);
                  }
                  uVar25 = (ulonglong)uVar34;
                  iVar46 = iVar16;
                  if ((short)uVar45 != 0) {
                    do {
                      puVar35 = puVar35 + 1;
                      uVar34 = *puVar35 & 0x7fff;
                      if ((uVar34 < uVar43) || ((uint)uVar25 < uVar34)) {
                        *(undefined8 *)(puVar40 + -8) = 0x1040e2;
                        cVar11 = func_0x(0x1fa68c0);
                        if (cVar11 != '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x1040eb;
                          lVar22 = func_0x();
                          if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar40 + -8) = 0x104105;
                            cVar11 = func_0x(0x1fa68c0);
                            if (cVar11 == '\0') {
                              *(undefined8 *)(puVar40 + -8) = 0x104121;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar40 + 0x20) = 0;
                              *(undefined8 *)(puVar40 + -8) = 0x104145;
                              (*_DAT_)(1,0x18962cc,0x19b63b8,0x82a);
                            }
                          }
                        }
                        uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                        *(undefined8 *)(puVar40 + -8) = 0x104156;
                        func_0x(uVar30,4);
                        uVar45 = (ulonglong)*(ushort *)(&stack0x00000544 + lVar19);
                        pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                        uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                      }
                      iVar46 = iVar46 + 1;
                      uVar43 = uVar34;
                    } while (iVar46 < (int)uVar45);
                    *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                    uVar43 = *(uint *)(&stack0x00000540 + lVar19);
                    puVar35 = *(ushort **)(&stack0x000000b0 + lVar19);
                  }
                  while( true ) {
                    sVar33 = (short)uVar45;
                    if (-1 < (short)puVar35[(ulonglong)((int)uVar45 - 1) + 1]) break;
                    uVar49 = uVar43;
                    if ((int)uVar45 != 1) {
                      uVar49 = *(ushort *)
                                (pbVar32 +
                                uVar45 * 2 + ((ulonglong)*(uint *)(&stack0x0000053c + lVar19) - 2))
                               & 0x7fff;
                    }
                    uVar50 = *(ushort *)
                              (pbVar32 +
                              uVar45 * 2 + (ulonglong)*(uint *)(&stack0x0000053c + lVar19)) & 0x7fff
                    ;
                    if (((uVar49 < uVar43) || (uVar50 < uVar49)) || ((uint)uVar25 < uVar50)) {
                      *(undefined8 *)(puVar40 + -8) = 0x1041f9;
                      func_0x(pbVar32,7);
                      sVar33 = *(short *)(&stack0x00000544 + lVar19);
                      uVar43 = *(uint *)(&stack0x00000540 + lVar19);
                      pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                      *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                      uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                    }
                    uVar34 = (uint)uVar25;
                    if ((uVar49 < uVar43) || (uVar34 < uVar49)) goto LAB_;
                    if (*(ushort *)(pbVar32 + uVar49) == 5) {
                      *(ushort *)(&stack0x0000052a + lVar19) =
                           *(ushort *)(&stack0x0000052a + lVar19) | 2;
                      *(short *)(&stack0x00000544 + lVar19) = sVar33 + -1;
                      uVar45 = (ulonglong)(uVar49 & 0xffff);
                      *(short *)(&stack0x00000552 + lVar19) = (short)uVar49;
                      pbVar38 = pbVar32 + uVar45;
                      uVar13 = *(ushort *)(&stack0x00000554 + lVar19);
                      if ((*(ushort *)(pbVar38 + 2) >> 0xe & 1) == 0) {
                        uVar13 = uVar13 & 0xc7ff;
                      }
                      else {
                        uVar13 = uVar13 ^ (*(ushort *)(pbVar38 + 2) ^ uVar13) & 0x3800;
                      }
                      *(ushort *)(&stack0x00000554 + lVar19) = uVar13;
                      uVar14 = (uVar13 ^ *(ushort *)(pbVar38 + 2)) & 0x7ff ^ uVar13;
                      *(ushort *)(&stack0x00000554 + lVar19) = uVar14;
                      pbVar37 = pbVar32 + (ulonglong)((uVar14 & 0x7ff) * 2) + 4 +
                                          uVar45 + (uVar13 >> 0xb & 7) * 2;
                      if (pbVar37 < pbVar38) {
                        *(undefined8 *)(puVar40 + -8) = 0x104312;
                        func_0x(pbVar38,0x19);
                        uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                        uVar45 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                        pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                        *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                        uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                      }
                      if (uVar50 - uVar49 <
                          (((*(uint *)(&stack0x00000554 + lVar19) & 0x7ff) * 2 - (int)uVar45) -
                          *(int *)(&stack0x00000530 + lVar19)) + (int)pbVar37) {
                        *(undefined8 *)(puVar40 + -8) = 0x104361;
                        func_0x(pbVar32 + uVar45,0x19);
                        uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                        uVar45 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                        pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                        *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                        uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                      }
                      if (((uVar14 & 0x3800) != 0) &&
                         (puVar35 = (ushort *)(pbVar32 + uVar45 + 4), (uVar14 & 0x3800) != 0)) {
                        do {
                          if ((uVar14 & 0x7ff) < (*puVar35 & 0x7ff)) {
                            *(undefined8 *)(puVar40 + -8) = 0x1043d5;
                            func_0x(pbVar32 + uVar45,0x1a);
                            uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                            uVar45 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                            pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                          }
                          iVar16 = iVar16 + 1;
                          puVar35 = puVar35 + 1;
                        } while (iVar16 < (int)(*(uint *)(&stack0x00000554 + lVar19) >> 0xb & 7));
                        *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                        uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                      }
                      break;
                    }
                    if (*(ushort *)(pbVar32 + uVar49) < 0x400) break;
                    *(ushort *)(&stack0x0000052a + lVar19) =
                         *(ushort *)(&stack0x0000052a + lVar19) | 1;
                    uVar13 = sVar33 - 1;
                    uVar45 = (ulonglong)uVar13;
                    *(ushort *)(&stack0x00000544 + lVar19) = uVar13;
                    if (uVar13 == 0) break;
                  }
                }
                if ((*pbVar32 & 0x40) == 0) {
                  *(undefined4 *)(&stack0x0000054e + lVar19) = 0;
                }
                else {
                  *(int *)(&stack0x0000054e + lVar19) = (int)uVar25;
                  *(int *)(&stack0x0000052c + lVar19) = (int)uVar25 + 0xe;
                  *(undefined8 *)(puVar40 + -8) = 0x104447;
                  puVar24 = (ulonglong *)func_0x(&stack0x0000052a + lVar19);
                  uVar14 = (ushort)(*puVar24 >> 0x30);
                  uVar13 = uVar14;
                  if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
                    uVar13 = uVar14 & 0xdfff;
                    if ((uVar14 >> 0xe & 1) != 0) {
                      uVar13 = uVar14 | 0x2000;
                    }
                  }
                  if (uVar13 == 0xfffc) {
                    iVar18 = (int)((*puVar24 >> 0x20 & 0xffff) >> 5);
                  }
                  uVar25 = (ulonglong)(uint)(*(int *)(&stack0x0000052c + lVar19) + iVar18);
                  *(int *)(&stack0x0000052c + lVar19) = *(int *)(&stack0x0000052c + lVar19) + iVar18
                  ;
                  pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                  *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                }
                uVar34 = (uint)uVar25;
                if ((*(byte **)(&stack0x00000546 + lVar19) != (byte *)0x0) &&
                   (*(byte **)(&stack0x00000546 + lVar19) < pbVar32 + uVar25)) {
                  *(undefined8 *)(puVar40 + -8) = 0x1044e8;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x1044f1;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar40 + -8) = 0x10450b;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x104527;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x10454d;
                        (*_DAT_)(1,0x18962cc,0x19b63b8,0x886);
                      }
                    }
                  }
                  uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x10455e;
                  func_0x(uVar30,0x12);
                  pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                  *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                  uVar34 = *(uint *)(&stack0x0000052c + lVar19);
                }
                if (0x3f3b < uVar34 - 1) {
                  *(undefined8 *)(puVar40 + -8) = 0x104589;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x104592;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar40 + -8) = 0x1045ac;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x1045c8;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x1045ee;
                        (*_DAT_)(1,0x18962cc,0x19b63b8,0x88b);
                      }
                    }
                  }
                  uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x1045ff;
                  func_0x(uVar30,5);
                  pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                  *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                  uVar34 = *(uint *)(&stack0x0000052c + lVar19);
                }
              }
LAB_:
              if (uVar34 < 9) {
                bVar31 = *pbVar32 & 0xe;
joined_r0x0010464e:
                if ((bVar31 == 0) || (bVar31 == 0xc)) {
                  uVar34 = 9;
                }
              }
            }
            else {
              if (uVar34 == 0) {
                *(undefined8 *)(puVar40 + -8) = 0x104631;
                func_0x(&stack0x0000052a + lVar19);
                uVar34 = *(uint *)(&stack0x0000052c + lVar19);
              }
              pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
              *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
              if (uVar34 < 9) {
                bVar31 = *pbVar32 & 0x1c;
                goto joined_r0x0010464e;
              }
            }
          }
          else {
            pbVar32 = (byte *)0x0;
            uVar34 = 0;
            *(undefined8 *)(&stack0x00000040 + lVar19) = 0;
          }
          iVar16 = 0;
          if (*(short *)(&stack0x00000048 + lVar19) == 0) {
            uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
            pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
            if (*(uint *)(&stack0x0000004c + lVar19) == 0) {
              *(undefined2 *)(&stack0x0000004a + lVar19) = 0;
              uVar43 = *(uint *)(&stack0x00000058 + lVar19);
              uVar25 = (ulonglong)uVar43;
              *(uint *)(&stack0x0000005c + lVar19) = uVar43;
              if ((*pbVar38 & 0x10) != 0) {
                uVar43 = uVar43 + 2 + (*(ushort *)(pbVar38 + uVar25) + 7 >> 3);
                uVar25 = (ulonglong)uVar43;
                *(uint *)(&stack0x0000005c + lVar19) = uVar43;
              }
              if ((*pbVar38 & 0x20) == 0) {
                *(int *)(&stack0x0000004c + lVar19) = (int)uVar25;
                *(undefined2 *)(&stack0x00000064 + lVar19) = 0;
                *(int *)(&stack0x00000060 + lVar19) = (int)uVar25;
              }
              else {
                puVar35 = (ushort *)(pbVar38 + uVar25);
                *(ushort **)(&stack0x000000b0 + lVar19) = puVar35;
                uVar13 = *puVar35;
                *(ushort *)(&stack0x00000064 + lVar19) = uVar13;
                if (uVar13 == 0) {
                  *(undefined8 *)(puVar40 + -8) = 0x1046e1;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x1046ea;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar40 + -8) = 0x104704;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x104720;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x104746;
                        (*_DAT_)(1,0x18962cc,0x19b63b8,0x80f);
                      }
                    }
                  }
                  uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x104754;
                  func_0x(uVar30,3);
                  uVar13 = *(ushort *)(&stack0x00000064 + lVar19);
                  pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                }
                uVar43 = *(int *)(&stack0x0000005c + lVar19) + 2 + (uint)uVar13 * 2;
                *(uint *)(&stack0x00000060 + lVar19) = uVar43;
                if (0x1f9e < uVar43) {
                  *(undefined8 *)(puVar40 + -8) = 0x104787;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x104790;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar40 + -8) = 0x1047aa;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x1047c6;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x1047ec;
                        (*_DAT_)(1,0x18962cc,0x19b63b8,0x816);
                      }
                    }
                  }
                  uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x1047fa;
                  func_0x(uVar30,4);
                  uVar13 = *(ushort *)(&stack0x00000064 + lVar19);
                  uVar43 = *(uint *)(&stack0x00000060 + lVar19);
                  pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                }
                uVar45 = (ulonglong)uVar13;
                uVar49 = puVar35[uVar45] & 0x7fff;
                *(uint *)(&stack0x0000004c + lVar19) = uVar49;
                if (uVar49 < uVar43) {
                  *(undefined8 *)(puVar40 + -8) = 0x10482f;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x104838;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar40 + -8) = 0x104852;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x10486e;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x104894;
                        (*_DAT_)(1,0x18962cc,0x19b63b8,0x81d);
                      }
                    }
                  }
                  uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x1048a2;
                  func_0x(uVar30,4);
                  uVar45 = (ulonglong)*(ushort *)(&stack0x00000064 + lVar19);
                  uVar43 = *(uint *)(&stack0x00000060 + lVar19);
                  pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                  uVar49 = *(uint *)(&stack0x0000004c + lVar19);
                }
                uVar25 = (ulonglong)uVar49;
                if ((short)uVar45 != 0) {
                  do {
                    puVar35 = puVar35 + 1;
                    uVar49 = *puVar35 & 0x7fff;
                    if ((uVar49 < uVar43) || ((uint)uVar25 < uVar49)) {
                      *(undefined8 *)(puVar40 + -8) = 0x1048f4;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 != '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x1048fd;
                        lVar22 = func_0x();
                        if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar40 + -8) = 0x104917;
                          cVar11 = func_0x(0x1fa68c0);
                          if (cVar11 == '\0') {
                            *(undefined8 *)(puVar40 + -8) = 0x104933;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar40 + 0x20) = 0;
                            *(undefined8 *)(puVar40 + -8) = 0x104957;
                            (*_DAT_)(1,0x18962cc,0x19b63b8,0x82a);
                          }
                        }
                      }
                      uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                      *(undefined8 *)(puVar40 + -8) = 0x104965;
                      func_0x(uVar30,4);
                      uVar45 = (ulonglong)*(ushort *)(&stack0x00000064 + lVar19);
                      pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                      uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                    }
                    iVar16 = iVar16 + 1;
                    uVar43 = uVar49;
                  } while (iVar16 < (int)uVar45);
                  uVar43 = *(uint *)(&stack0x00000060 + lVar19);
                  pbVar32 = *(byte **)(&stack0x00000040 + lVar19);
                  puVar35 = *(ushort **)(&stack0x000000b0 + lVar19);
                }
                while( true ) {
                  sVar33 = (short)uVar45;
                  if (-1 < (short)puVar35[(ulonglong)((int)uVar45 - 1) + 1]) break;
                  uVar49 = uVar43;
                  if ((int)uVar45 != 1) {
                    uVar49 = *(ushort *)
                              (pbVar38 +
                              uVar45 * 2 + ((ulonglong)*(uint *)(&stack0x0000005c + lVar19) - 2)) &
                             0x7fff;
                  }
                  uVar50 = *(ushort *)
                            (pbVar38 + uVar45 * 2 + (ulonglong)*(uint *)(&stack0x0000005c + lVar19))
                           & 0x7fff;
                  if (((uVar49 < uVar43) || (uVar50 < uVar49)) || ((uint)uVar25 < uVar50)) {
                    *(undefined8 *)(puVar40 + -8) = 0x1049fa;
                    func_0x(pbVar38,7);
                    sVar33 = *(short *)(&stack0x00000064 + lVar19);
                    uVar43 = *(uint *)(&stack0x00000060 + lVar19);
                    pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                    uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                  }
                  if ((uVar49 < uVar43) || ((uint)uVar25 < uVar49)) goto LAB_;
                  if (*(ushort *)(pbVar38 + uVar49) == 5) {
                    *(ushort *)(&stack0x0000004a + lVar19) =
                         *(ushort *)(&stack0x0000004a + lVar19) | 2;
                    *(short *)(&stack0x00000064 + lVar19) = sVar33 + -1;
                    uVar45 = (ulonglong)(uVar49 & 0xffff);
                    *(short *)(&stack0x00000072 + lVar19) = (short)uVar49;
                    pbVar37 = pbVar38 + uVar45;
                    uVar13 = *(ushort *)(&stack0x00000074 + lVar19);
                    if ((*(ushort *)(pbVar37 + 2) >> 0xe & 1) == 0) {
                      uVar13 = uVar13 & 0xc7ff;
                    }
                    else {
                      uVar13 = uVar13 ^ (uVar13 ^ *(ushort *)(pbVar37 + 2)) & 0x3800;
                    }
                    *(ushort *)(&stack0x00000074 + lVar19) = uVar13;
                    uVar14 = (uVar13 ^ *(ushort *)(pbVar37 + 2)) & 0x7ff ^ uVar13;
                    *(ushort *)(&stack0x00000074 + lVar19) = uVar14;
                    pbVar48 = pbVar38 + (ulonglong)((uVar14 & 0x7ff) * 2) + 4 +
                                        (uVar13 >> 0xb & 7) * 2 + uVar45;
                    if (pbVar48 < pbVar37) {
                      *(undefined8 *)(puVar40 + -8) = 0x104b71;
                      func_0x(pbVar37,0x19);
                      uVar14 = *(ushort *)(&stack0x00000074 + lVar19);
                      uVar45 = (ulonglong)*(ushort *)(&stack0x00000072 + lVar19);
                      pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                      uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                    }
                    if (uVar50 - uVar49 <
                        (((*(uint *)(&stack0x00000074 + lVar19) & 0x7ff) * 2 - (int)uVar45) -
                        *(int *)(&stack0x00000050 + lVar19)) + (int)pbVar48) {
                      *(undefined8 *)(puVar40 + -8) = 0x104bad;
                      func_0x(pbVar38 + uVar45,0x19);
                      uVar14 = *(ushort *)(&stack0x00000074 + lVar19);
                      uVar45 = (ulonglong)*(ushort *)(&stack0x00000072 + lVar19);
                      pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                      uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                    }
                    iVar16 = 0;
                    if (((uVar14 & 0x3800) != 0) &&
                       (puVar35 = (ushort *)(pbVar38 + uVar45 + 4), (uVar14 & 0x3800) != 0)) {
                      do {
                        if ((uVar14 & 0x7ff) < (*puVar35 & 0x7ff)) {
                          *(undefined8 *)(puVar40 + -8) = 0x104c15;
                          func_0x(pbVar38 + uVar45,0x1a);
                          uVar14 = *(ushort *)(&stack0x00000074 + lVar19);
                          uVar45 = (ulonglong)*(ushort *)(&stack0x00000072 + lVar19);
                          pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                        }
                        iVar16 = iVar16 + 1;
                        puVar35 = puVar35 + 1;
                      } while (iVar16 < (int)(*(uint *)(&stack0x00000074 + lVar19) >> 0xb & 7));
                      uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                    }
                    break;
                  }
                  if (*(ushort *)(pbVar38 + uVar49) < 0x400) break;
                  *(ushort *)(&stack0x0000004a + lVar19) =
                       *(ushort *)(&stack0x0000004a + lVar19) | 1;
                  uVar13 = sVar33 - 1;
                  uVar45 = (ulonglong)uVar13;
                  *(ushort *)(&stack0x00000064 + lVar19) = uVar13;
                  if (uVar13 == 0) break;
                }
              }
              iVar16 = 0;
              if ((*pbVar38 & 0x40) == 0) {
                *(undefined4 *)(&stack0x0000006e + lVar19) = 0;
              }
              else {
                *(int *)(&stack0x0000006e + lVar19) = (int)uVar25;
                *(int *)(&stack0x0000004c + lVar19) = (int)uVar25 + 0xe;
                *(undefined8 *)(puVar40 + -8) = 0x104a6d;
                puVar24 = (ulonglong *)func_0x(&stack0x0000004a + lVar19);
                uVar14 = (ushort)(*puVar24 >> 0x30);
                uVar13 = uVar14;
                if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
                  uVar13 = uVar14 & 0xdfff;
                  if ((uVar14 >> 0xe & 1) != 0) {
                    uVar13 = uVar14 | 0x2000;
                  }
                }
                if (uVar13 == 0xfffc) {
                  iVar16 = (int)((*puVar24 >> 0x20 & 0xffff) >> 5);
                }
                uVar25 = (ulonglong)(uint)(*(int *)(&stack0x0000004c + lVar19) + iVar16);
                *(int *)(&stack0x0000004c + lVar19) = *(int *)(&stack0x0000004c + lVar19) + iVar16;
                pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
              }
              if ((*(byte **)(&stack0x00000066 + lVar19) != (byte *)0x0) &&
                 (*(byte **)(&stack0x00000066 + lVar19) < pbVar38 + uVar25)) {
                *(undefined8 *)(puVar40 + -8) = 0x104c7f;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x104c88;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x104ca2;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x104cbe;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x104ce4;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x886);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x104cf2;
                func_0x(uVar30,0x12);
                pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
              }
              if (0x3f3b < (int)uVar25 - 1U) {
                *(undefined8 *)(puVar40 + -8) = 0x104d15;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x104d1e;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x104d38;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x104d54;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x104d7a;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x88b);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x104d88;
                func_0x(uVar30,5);
                pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
              }
            }
LAB_:
            if ((8 < (uint)uVar25) || (((*pbVar38 & 0xe) != 0 && ((*pbVar38 & 0xe) != 0xc)))) {
              *(uint *)(&stack0x00000084 + lVar19) = (uint)uVar25;
            }
          }
          else {
            uVar43 = *(uint *)(&stack0x0000004c + lVar19);
            if (uVar43 == 0) {
              *(undefined8 *)(puVar40 + -8) = 0x104db7;
              func_0x(&stack0x0000004a + lVar19);
              uVar43 = *(uint *)(&stack0x0000004c + lVar19);
            }
            pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
            if ((uVar43 < 9) && (((*pbVar38 & 0x1c) == 0 || ((*pbVar38 & 0x1c) == 0xc)))) {
              *(undefined4 *)(&stack0x00000084 + lVar19) = 9;
            }
            else {
              *(uint *)(&stack0x00000084 + lVar19) = uVar43;
            }
          }
          uVar6 = *(uint6 *)(*(longlong *)(&stack0x00000098 + lVar19) + 0x14);
          lVar22 = *(longlong *)(&stack0x00000110 + lVar19);
          *(undefined8 *)(puVar40 + -8) = 0x104e08;
          func_0x(lVar22,(ulonglong)uVar6 << 0x10,1);
          puVar44 = &stack0x000005d8 + lVar19;
          if (*pcVar1 == '\0') {
            puVar44 = (undefined *)0x0;
          }
          puVar40[0x40] = 0;
          puVar40[0x38] = (char)*(undefined4 *)(&stack0x000000c8 + lVar19);
          *(uint *)(puVar40 + 0x30) = uVar34;
          *(byte **)(puVar40 + 0x28) = pbVar32;
          *(undefined8 *)(puVar40 + 0x20) = 0;
          uVar17 = *(undefined4 *)(&stack0x00000084 + lVar19);
          uVar30 = *(undefined8 *)(lVar22 + 0x2268);
          *(undefined8 *)(puVar40 + -8) = 0x104e4d;
          iVar16 = func_0x(uVar30,pbVar38,uVar17,puVar44);
          *(int *)(&stack0x000000cc + lVar19) = iVar16;
        }
      }
      else {
LAB_:
        (&stack0x00000093)[lVar19] = 0;
        if (bVar8) {
          uVar34 = *(uint *)(&stack0x0000052c + lVar19);
          if (*(short *)(&stack0x00000528 + lVar19) == 0) {
            pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
            *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
            if (uVar34 == 0) {
              iVar18 = 0;
              *(undefined2 *)(&stack0x0000052a + lVar19) = 0;
              uVar34 = *(uint *)(&stack0x00000538 + lVar19);
              uVar25 = (ulonglong)uVar34;
              *(uint *)(&stack0x0000053c + lVar19) = uVar34;
              if ((*pbVar32 & 0x10) != 0) {
                uVar34 = uVar34 + 2 + (*(ushort *)(pbVar32 + uVar25) + 7 >> 3);
                uVar25 = (ulonglong)uVar34;
                *(uint *)(&stack0x0000053c + lVar19) = uVar34;
              }
              if ((*pbVar32 & 0x20) == 0) {
                *(int *)(&stack0x0000052c + lVar19) = (int)uVar25;
                *(undefined2 *)(&stack0x00000544 + lVar19) = 0;
                *(int *)(&stack0x00000540 + lVar19) = (int)uVar25;
              }
              else {
                puVar35 = (ushort *)(pbVar32 + uVar25);
                *(ushort **)(&stack0x000000b0 + lVar19) = puVar35;
                uVar13 = *puVar35;
                *(ushort *)(&stack0x00000544 + lVar19) = uVar13;
                if (uVar13 == 0) {
                  *(undefined8 *)(puVar40 + -8) = 0x104eff;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x104f08;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar40 + -8) = 0x104f22;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x104f3e;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x104f64;
                        (*_DAT_)(1,0x18962cc,0x19b63b8,0x80f);
                      }
                    }
                  }
                  uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x104f75;
                  func_0x(uVar30,3);
                  uVar13 = *(ushort *)(&stack0x00000544 + lVar19);
                  pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                  *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                }
                uVar43 = *(int *)(&stack0x0000053c + lVar19) + 2 + (uint)uVar13 * 2;
                *(uint *)(&stack0x00000540 + lVar19) = uVar43;
                if (0x1f9e < uVar43) {
                  *(undefined8 *)(puVar40 + -8) = 0x104fb8;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x104fc1;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar40 + -8) = 0x104fdb;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x104ff7;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x10501d;
                        (*_DAT_)(1,0x18962cc,0x19b63b8,0x816);
                      }
                    }
                  }
                  uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x10502e;
                  func_0x(uVar30,4);
                  uVar13 = *(ushort *)(&stack0x00000544 + lVar19);
                  uVar43 = *(uint *)(&stack0x00000540 + lVar19);
                  pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                  *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                }
                uVar45 = (ulonglong)uVar13;
                uVar34 = puVar35[uVar45] & 0x7fff;
                *(uint *)(&stack0x0000052c + lVar19) = uVar34;
                if (uVar34 < uVar43) {
                  *(undefined8 *)(puVar40 + -8) = 0x105070;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x105079;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar40 + -8) = 0x105093;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x1050af;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x1050d5;
                        (*_DAT_)(1,0x18962cc,0x19b63b8,0x81d);
                      }
                    }
                  }
                  uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x1050e6;
                  func_0x(uVar30,4);
                  uVar45 = (ulonglong)*(ushort *)(&stack0x00000544 + lVar19);
                  uVar43 = *(uint *)(&stack0x00000540 + lVar19);
                  pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                  *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                  uVar34 = *(uint *)(&stack0x0000052c + lVar19);
                }
                uVar25 = (ulonglong)uVar34;
                if ((short)uVar45 != 0) {
                  do {
                    puVar35 = puVar35 + 1;
                    uVar34 = *puVar35 & 0x7fff;
                    if ((uVar34 < uVar43) || ((uint)uVar25 < uVar34)) {
                      *(undefined8 *)(puVar40 + -8) = 0x105142;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 != '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x10514b;
                        lVar22 = func_0x();
                        if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar40 + -8) = 0x105165;
                          cVar11 = func_0x(0x1fa68c0);
                          if (cVar11 == '\0') {
                            *(undefined8 *)(puVar40 + -8) = 0x105181;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar40 + 0x20) = 0;
                            *(undefined8 *)(puVar40 + -8) = 0x1051a5;
                            (*_DAT_)(1,0x18962cc,0x19b63b8,0x82a);
                          }
                        }
                      }
                      uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                      *(undefined8 *)(puVar40 + -8) = 0x1051b6;
                      func_0x(uVar30,4);
                      uVar45 = (ulonglong)*(ushort *)(&stack0x00000544 + lVar19);
                      pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                      uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                    }
                    iVar18 = iVar18 + 1;
                    uVar43 = uVar34;
                  } while (iVar18 < (int)uVar45);
                  *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                  uVar43 = *(uint *)(&stack0x00000540 + lVar19);
                  puVar35 = *(ushort **)(&stack0x000000b0 + lVar19);
                  iVar16 = *(int *)(&stack0x000000c0 + lVar19);
                }
                while( true ) {
                  sVar33 = (short)uVar45;
                  if (-1 < (short)puVar35[(ulonglong)((int)uVar45 - 1) + 1]) break;
                  uVar49 = uVar43;
                  if ((int)uVar45 != 1) {
                    uVar49 = *(ushort *)
                              (pbVar32 +
                              uVar45 * 2 + ((ulonglong)*(uint *)(&stack0x0000053c + lVar19) - 2)) &
                             0x7fff;
                  }
                  uVar50 = *(ushort *)
                            (pbVar32 + uVar45 * 2 + (ulonglong)*(uint *)(&stack0x0000053c + lVar19))
                           & 0x7fff;
                  if (((uVar49 < uVar43) || (uVar50 < uVar49)) || ((uint)uVar25 < uVar50)) {
                    *(undefined8 *)(puVar40 + -8) = 0x10525a;
                    func_0x(pbVar32,7);
                    sVar33 = *(short *)(&stack0x00000544 + lVar19);
                    uVar43 = *(uint *)(&stack0x00000540 + lVar19);
                    pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                    *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                    uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                  }
                  uVar34 = (uint)uVar25;
                  if ((uVar49 < uVar43) || (uVar34 < uVar49)) goto LAB_;
                  if (*(ushort *)(pbVar32 + uVar49) == 5) {
                    *(ushort *)(&stack0x0000052a + lVar19) =
                         *(ushort *)(&stack0x0000052a + lVar19) | 2;
                    *(short *)(&stack0x00000544 + lVar19) = sVar33 + -1;
                    uVar45 = (ulonglong)(uVar49 & 0xffff);
                    *(short *)(&stack0x00000552 + lVar19) = (short)uVar49;
                    pbVar38 = pbVar32 + uVar45;
                    uVar13 = *(ushort *)(&stack0x00000554 + lVar19);
                    if ((*(ushort *)(pbVar38 + 2) >> 0xe & 1) == 0) {
                      uVar13 = uVar13 & 0xc7ff;
                    }
                    else {
                      uVar13 = uVar13 ^ (uVar13 ^ *(ushort *)(pbVar38 + 2)) & 0x3800;
                    }
                    *(ushort *)(&stack0x00000554 + lVar19) = uVar13;
                    uVar14 = (uVar13 ^ *(ushort *)(pbVar38 + 2)) & 0x7ff ^ uVar13;
                    *(ushort *)(&stack0x00000554 + lVar19) = uVar14;
                    pbVar37 = pbVar32 + uVar45 + (ulonglong)((uVar14 & 0x7ff) * 2) + 4 +
                                                 (ulonglong)((uVar13 >> 0xb & 7) * 2);
                    if (pbVar37 < pbVar38) {
                      *(undefined8 *)(puVar40 + -8) = 0x1053d1;
                      func_0x(pbVar38,0x19);
                      uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                      uVar45 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                      pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                      *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                      uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                    }
                    if (uVar50 - uVar49 <
                        (((*(uint *)(&stack0x00000554 + lVar19) & 0x7ff) * 2 - (int)uVar45) -
                        *(int *)(&stack0x00000530 + lVar19)) + (int)pbVar37) {
                      *(undefined8 *)(puVar40 + -8) = 0x105420;
                      func_0x(pbVar32 + uVar45,0x19);
                      uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                      uVar45 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                      pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                      *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                      uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                    }
                    iVar18 = 0;
                    if (((uVar14 & 0x3800) != 0) &&
                       (puVar35 = (ushort *)(pbVar32 + uVar45 + 4), (uVar14 & 0x3800) != 0)) {
                      do {
                        if ((uVar14 & 0x7ff) < (*puVar35 & 0x7ff)) {
                          *(undefined8 *)(puVar40 + -8) = 0x1054a5;
                          func_0x(pbVar32 + uVar45,0x1a);
                          uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                          uVar45 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                          pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                        }
                        iVar18 = iVar18 + 1;
                        puVar35 = puVar35 + 1;
                      } while (iVar18 < (int)(*(uint *)(&stack0x00000554 + lVar19) >> 0xb & 7));
                      *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                      uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                    }
                    break;
                  }
                  if (*(ushort *)(pbVar32 + uVar49) < 0x400) break;
                  *(ushort *)(&stack0x0000052a + lVar19) =
                       *(ushort *)(&stack0x0000052a + lVar19) | 1;
                  uVar13 = sVar33 - 1;
                  uVar45 = (ulonglong)uVar13;
                  *(ushort *)(&stack0x00000544 + lVar19) = uVar13;
                  if (uVar13 == 0) break;
                }
              }
              iVar18 = 0;
              if ((*pbVar32 & 0x40) == 0) {
                *(undefined4 *)(&stack0x0000054e + lVar19) = 0;
              }
              else {
                *(int *)(&stack0x0000054e + lVar19) = (int)uVar25;
                *(int *)(&stack0x0000052c + lVar19) = (int)uVar25 + 0xe;
                *(undefined8 *)(puVar40 + -8) = 0x1052e8;
                puVar24 = (ulonglong *)func_0x(&stack0x0000052a + lVar19);
                uVar13 = (ushort)(*puVar24 >> 0x30);
                if ((((uint)(int)(short)uVar13 >> 1 ^ (int)(short)uVar13) & 0x2000) != 0) {
                  if ((uVar13 >> 0xe & 1) == 0) {
                    uVar13 = uVar13 & 0xdfff;
                  }
                  else {
                    uVar13 = uVar13 | 0x2000;
                  }
                }
                if (uVar13 == 0xfffc) {
                  iVar18 = (int)((*puVar24 >> 0x20 & 0xffff) >> 5);
                }
                uVar25 = (ulonglong)(uint)(*(int *)(&stack0x0000052c + lVar19) + iVar18);
                *(int *)(&stack0x0000052c + lVar19) = *(int *)(&stack0x0000052c + lVar19) + iVar18;
                pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
              }
              uVar34 = (uint)uVar25;
              if ((*(byte **)(&stack0x00000546 + lVar19) != (byte *)0x0) &&
                 (*(byte **)(&stack0x00000546 + lVar19) < pbVar32 + uVar25)) {
                *(undefined8 *)(puVar40 + -8) = 0x105561;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x10556a;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x105584;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x1055a0;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x1055c6;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x886);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x1055d7;
                func_0x(uVar30,0x12);
                pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                uVar34 = *(uint *)(&stack0x0000052c + lVar19);
              }
              if (0x3f3b < uVar34 - 1) {
                *(undefined8 *)(puVar40 + -8) = 0x105602;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x10560b;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x105625;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x105641;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x105667;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x88b);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x105678;
                func_0x(uVar30,5);
                pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                uVar34 = *(uint *)(&stack0x0000052c + lVar19);
              }
            }
LAB_:
            if (uVar34 < 9) {
              bVar31 = *pbVar32 & 0xe;
joined_r0x001056c7:
              if ((bVar31 == 0) || (bVar31 == 0xc)) {
                uVar34 = 9;
              }
            }
          }
          else {
            if (uVar34 == 0) {
              *(undefined8 *)(puVar40 + -8) = 0x1056aa;
              func_0x(&stack0x0000052a + lVar19);
              uVar34 = *(uint *)(&stack0x0000052c + lVar19);
            }
            pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
            *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
            if (uVar34 < 9) {
              bVar31 = *pbVar32 & 0x1c;
              goto joined_r0x001056c7;
            }
          }
        }
        else {
          pbVar32 = (byte *)0x0;
          uVar34 = 0;
          *(undefined8 *)(&stack0x00000040 + lVar19) = 0;
        }
        iVar18 = 0;
        if (*(short *)(&stack0x00000048 + lVar19) == 0) {
          uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
          pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
          if (*(uint *)(&stack0x0000004c + lVar19) == 0) {
            *(undefined2 *)(&stack0x0000004a + lVar19) = 0;
            uVar43 = *(uint *)(&stack0x00000058 + lVar19);
            uVar25 = (ulonglong)uVar43;
            *(uint *)(&stack0x0000005c + lVar19) = uVar43;
            if ((*pbVar38 & 0x10) != 0) {
              uVar43 = uVar43 + 2 + (*(ushort *)(pbVar38 + uVar25) + 7 >> 3);
              uVar25 = (ulonglong)uVar43;
              *(uint *)(&stack0x0000005c + lVar19) = uVar43;
            }
            if ((*pbVar38 & 0x20) == 0) {
              *(int *)(&stack0x0000004c + lVar19) = (int)uVar25;
              *(undefined2 *)(&stack0x00000064 + lVar19) = 0;
              *(int *)(&stack0x00000060 + lVar19) = (int)uVar25;
            }
            else {
              puVar35 = (ushort *)(pbVar38 + uVar25);
              *(ushort **)(&stack0x000000b0 + lVar19) = puVar35;
              uVar13 = *puVar35;
              *(ushort *)(&stack0x00000064 + lVar19) = uVar13;
              if (uVar13 == 0) {
                *(undefined8 *)(puVar40 + -8) = 0x10575a;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x105763;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x10577d;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x105799;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x1057bf;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x80f);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x1057cd;
                func_0x(uVar30,3);
                uVar13 = *(ushort *)(&stack0x00000064 + lVar19);
                pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
              }
              uVar43 = *(int *)(&stack0x0000005c + lVar19) + 2 + (uint)uVar13 * 2;
              *(uint *)(&stack0x00000060 + lVar19) = uVar43;
              if (0x1f9e < uVar43) {
                *(undefined8 *)(puVar40 + -8) = 0x105800;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x105809;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x105823;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x10583f;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x105865;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x816);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x105873;
                func_0x(uVar30,4);
                uVar13 = *(ushort *)(&stack0x00000064 + lVar19);
                uVar43 = *(uint *)(&stack0x00000060 + lVar19);
                pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
              }
              uVar45 = (ulonglong)uVar13;
              uVar49 = puVar35[uVar45] & 0x7fff;
              *(uint *)(&stack0x0000004c + lVar19) = uVar49;
              if (uVar49 < uVar43) {
                *(undefined8 *)(puVar40 + -8) = 0x1058a8;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x1058b1;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x1058cb;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x1058e7;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x10590d;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x81d);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x10591b;
                func_0x(uVar30,4);
                uVar45 = (ulonglong)*(ushort *)(&stack0x00000064 + lVar19);
                uVar43 = *(uint *)(&stack0x00000060 + lVar19);
                pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                uVar49 = *(uint *)(&stack0x0000004c + lVar19);
              }
              uVar25 = (ulonglong)uVar49;
              if ((short)uVar45 != 0) {
                do {
                  puVar35 = puVar35 + 1;
                  uVar49 = *puVar35 & 0x7fff;
                  if ((uVar49 < uVar43) || ((uint)uVar25 < uVar49)) {
                    *(undefined8 *)(puVar40 + -8) = 0x105965;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 != '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x10596e;
                      lVar22 = func_0x();
                      if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar40 + -8) = 0x105988;
                        cVar11 = func_0x(0x1fa68c0);
                        if (cVar11 == '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x1059a4;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar40 + 0x20) = 0;
                          *(undefined8 *)(puVar40 + -8) = 0x1059c8;
                          (*_DAT_)(1,0x18962cc,0x19b63b8,0x82a);
                        }
                      }
                    }
                    uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                    *(undefined8 *)(puVar40 + -8) = 0x1059d6;
                    func_0x(uVar30,4);
                    uVar45 = (ulonglong)*(ushort *)(&stack0x00000064 + lVar19);
                    pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                    uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                  }
                  iVar18 = iVar18 + 1;
                  uVar43 = uVar49;
                } while (iVar18 < (int)uVar45);
                uVar43 = *(uint *)(&stack0x00000060 + lVar19);
                pbVar32 = *(byte **)(&stack0x00000040 + lVar19);
                puVar35 = *(ushort **)(&stack0x000000b0 + lVar19);
              }
              while( true ) {
                sVar33 = (short)uVar45;
                if (-1 < (short)puVar35[(ulonglong)((int)uVar45 - 1) + 1]) break;
                uVar49 = uVar43;
                if ((int)uVar45 != 1) {
                  uVar49 = *(ushort *)
                            (pbVar38 +
                            uVar45 * 2 + ((ulonglong)*(uint *)(&stack0x0000005c + lVar19) - 2)) &
                           0x7fff;
                }
                uVar50 = *(ushort *)
                          (pbVar38 + uVar45 * 2 + (ulonglong)*(uint *)(&stack0x0000005c + lVar19)) &
                         0x7fff;
                if (((uVar49 < uVar43) || (uVar50 < uVar49)) || ((uint)uVar25 < uVar50)) {
                  *(undefined8 *)(puVar40 + -8) = 0x105a6a;
                  func_0x(pbVar38,7);
                  sVar33 = *(short *)(&stack0x00000064 + lVar19);
                  uVar43 = *(uint *)(&stack0x00000060 + lVar19);
                  pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                  uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                }
                if ((uVar49 < uVar43) || ((uint)uVar25 < uVar49)) goto LAB_;
                if (*(ushort *)(pbVar38 + uVar49) == 5) {
                  *(ushort *)(&stack0x0000004a + lVar19) =
                       *(ushort *)(&stack0x0000004a + lVar19) | 2;
                  *(short *)(&stack0x00000064 + lVar19) = sVar33 + -1;
                  uVar45 = (ulonglong)(uVar49 & 0xffff);
                  *(short *)(&stack0x00000072 + lVar19) = (short)uVar49;
                  pbVar37 = pbVar38 + uVar45;
                  uVar13 = *(ushort *)(&stack0x00000074 + lVar19);
                  if ((*(ushort *)(pbVar37 + 2) >> 0xe & 1) == 0) {
                    uVar13 = uVar13 & 0xc7ff;
                  }
                  else {
                    uVar13 = uVar13 ^ (uVar13 ^ *(ushort *)(pbVar37 + 2)) & 0x3800;
                  }
                  *(ushort *)(&stack0x00000074 + lVar19) = uVar13;
                  uVar14 = (uVar13 ^ *(ushort *)(pbVar37 + 2)) & 0x7ff ^ uVar13;
                  *(ushort *)(&stack0x00000074 + lVar19) = uVar14;
                  pbVar48 = pbVar38 + (ulonglong)((uVar14 & 0x7ff) * 2) + 4 +
                                      (uVar13 >> 0xb & 7) * 2 + uVar45;
                  if (pbVar48 < pbVar37) {
                    *(undefined8 *)(puVar40 + -8) = 0x105baf;
                    func_0x(pbVar37,0x19);
                    uVar14 = *(ushort *)(&stack0x00000074 + lVar19);
                    uVar45 = (ulonglong)*(ushort *)(&stack0x00000072 + lVar19);
                    pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                    uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                  }
                  if (uVar50 - uVar49 <
                      (((*(uint *)(&stack0x00000074 + lVar19) & 0x7ff) * 2 - (int)uVar45) -
                      *(int *)(&stack0x00000050 + lVar19)) + (int)pbVar48) {
                    *(undefined8 *)(puVar40 + -8) = 0x105beb;
                    func_0x(pbVar38 + uVar45,0x19);
                    uVar14 = *(ushort *)(&stack0x00000074 + lVar19);
                    uVar45 = (ulonglong)*(ushort *)(&stack0x00000072 + lVar19);
                    pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                    uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                  }
                  iVar16 = 0;
                  if (((uVar14 & 0x3800) != 0) &&
                     (puVar35 = (ushort *)(pbVar38 + uVar45 + 4), (uVar14 & 0x3800) != 0)) {
                    do {
                      if ((uVar14 & 0x7ff) < (*puVar35 & 0x7ff)) {
                        *(undefined8 *)(puVar40 + -8) = 0x105c55;
                        func_0x(pbVar38 + uVar45,0x1a);
                        uVar14 = *(ushort *)(&stack0x00000074 + lVar19);
                        uVar45 = (ulonglong)*(ushort *)(&stack0x00000072 + lVar19);
                        pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                      }
                      iVar16 = iVar16 + 1;
                      puVar35 = puVar35 + 1;
                    } while (iVar16 < (int)(*(uint *)(&stack0x00000074 + lVar19) >> 0xb & 7));
                    uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                  }
                  break;
                }
                if (*(ushort *)(pbVar38 + uVar49) < 0x400) break;
                *(ushort *)(&stack0x0000004a + lVar19) = *(ushort *)(&stack0x0000004a + lVar19) | 1;
                uVar13 = sVar33 - 1;
                uVar45 = (ulonglong)uVar13;
                *(ushort *)(&stack0x00000064 + lVar19) = uVar13;
                if (uVar13 == 0) break;
              }
            }
            iVar16 = 0;
            if ((*pbVar38 & 0x40) == 0) {
              *(undefined4 *)(&stack0x0000006e + lVar19) = 0;
            }
            else {
              *(int *)(&stack0x0000006e + lVar19) = (int)uVar25;
              *(int *)(&stack0x0000004c + lVar19) = (int)uVar25 + 0xe;
              *(undefined8 *)(puVar40 + -8) = 0x105ad9;
              puVar24 = (ulonglong *)func_0x(&stack0x0000004a + lVar19);
              uVar13 = (ushort)(*puVar24 >> 0x30);
              if ((((uint)(int)(short)uVar13 >> 1 ^ (int)(short)uVar13) & 0x2000) != 0) {
                if ((uVar13 >> 0xe & 1) == 0) {
                  uVar13 = uVar13 & 0xdfff;
                }
                else {
                  uVar13 = uVar13 | 0x2000;
                }
              }
              if (uVar13 == 0xfffc) {
                iVar16 = (int)((*puVar24 >> 0x20 & 0xffff) >> 5);
              }
              uVar25 = (ulonglong)(uint)(*(int *)(&stack0x0000004c + lVar19) + iVar16);
              *(int *)(&stack0x0000004c + lVar19) = *(int *)(&stack0x0000004c + lVar19) + iVar16;
              pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
            }
            if ((*(byte **)(&stack0x00000066 + lVar19) != (byte *)0x0) &&
               (*(byte **)(&stack0x00000066 + lVar19) < pbVar38 + uVar25)) {
              *(undefined8 *)(puVar40 + -8) = 0x105cea;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x105cf3;
                lVar22 = func_0x();
                if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x105d0d;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x105d29;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x105d4f;
                    (*_DAT_)(1,0x18962cc,0x19b63b8,0x886);
                  }
                }
              }
              uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
              *(undefined8 *)(puVar40 + -8) = 0x105d5d;
              func_0x(uVar30,0x12);
              pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
              uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
            }
            if (0x3f3b < (int)uVar25 - 1U) {
              *(undefined8 *)(puVar40 + -8) = 0x105d80;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x105d89;
                lVar22 = func_0x();
                if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x105da3;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x105dbf;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x105de5;
                    (*_DAT_)(1,0x18962cc,0x19b63b8,0x88b);
                  }
                }
              }
              uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
              *(undefined8 *)(puVar40 + -8) = 0x105df3;
              func_0x(uVar30,5);
              pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
              uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
            }
          }
LAB_:
          if ((8 < (uint)uVar25) || (((*pbVar38 & 0xe) != 0 && ((*pbVar38 & 0xe) != 0xc)))) {
            *(uint *)(&stack0x00000084 + lVar19) = (uint)uVar25;
          }
          iVar16 = *(int *)(&stack0x000000c0 + lVar19);
        }
        else {
          uVar43 = *(uint *)(&stack0x0000004c + lVar19);
          if (uVar43 == 0) {
            *(undefined8 *)(puVar40 + -8) = 0x105e29;
            func_0x(&stack0x0000004a + lVar19);
            uVar43 = *(uint *)(&stack0x0000004c + lVar19);
          }
          pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
          if ((uVar43 < 9) && (((*pbVar38 & 0x1c) == 0 || ((*pbVar38 & 0x1c) == 0xc)))) {
            *(undefined4 *)(&stack0x00000084 + lVar19) = 9;
          }
          else {
            *(uint *)(&stack0x00000084 + lVar19) = uVar43;
          }
        }
        uVar6 = *(uint6 *)(*(longlong *)(&stack0x00000098 + lVar19) + 0x14);
        lVar22 = *(longlong *)(&stack0x00000110 + lVar19);
        *(undefined8 *)(puVar40 + -8) = 0x105e7a;
        func_0x(lVar22,(ulonglong)uVar6 << 0x10,1);
        puVar44 = &stack0x000005d8 + lVar19;
        if (*pcVar1 == '\0') {
          puVar44 = (undefined *)0x0;
        }
        puVar40[0x40] = iVar16 == 0;
        puVar40[0x38] = (char)*(undefined4 *)(&stack0x000000c8 + lVar19);
        *(uint *)(puVar40 + 0x30) = uVar34;
        *(byte **)(puVar40 + 0x28) = pbVar32;
        *(undefined **)(puVar40 + 0x20) = &stack0x00000093 + lVar19;
        uVar17 = *(undefined4 *)(&stack0x00000084 + lVar19);
        uVar30 = *(undefined8 *)(lVar22 + 0x2268);
        *(undefined8 *)(puVar40 + -8) = 0x105ec8;
        iVar16 = func_0x(uVar30,pbVar38,uVar17,puVar44);
        *(int *)(&stack0x000000cc + lVar19) = iVar16;
      }
    }
    else {
      if (cVar41 != '\0') goto LAB_;
      if (cVar12 != '\0') {
        sVar33 = *(short *)(&stack0x00000528 + lVar19);
        pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
        if (sVar33 == 0) {
          bVar31 = *pbVar32 & 0xe;
          bVar52 = false;
          if (bVar31 == 2) {
            bVar52 = (pbVar32[1] & 1) != 0;
          }
          else if (((bVar31 - 10 & 0xf9) == 0) && (bVar31 != 0x10)) {
            bVar52 = true;
          }
        }
        else {
          bVar52 = ((*pbVar32 & 0x1c) - 4 & 0xffffffe7) == 0;
        }
        iVar18 = 0;
        if (bVar52) {
          *(undefined8 *)(puVar40 + 0x20) = 0;
          *(undefined8 *)(puVar40 + -8) = 0x105f68;
          (*_DAT_)(1,0x1a45a98,0x1a1ac00,0xd2d);
          pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
          sVar33 = *(short *)(&stack0x00000528 + lVar19);
        }
        if (sVar33 == 0) {
          if (*(int *)(&stack0x0000052c + lVar19) == 0) {
            *(undefined2 *)(&stack0x0000052a + lVar19) = 0;
            uVar34 = *(uint *)(&stack0x00000538 + lVar19);
            uVar25 = (ulonglong)uVar34;
            *(uint *)(&stack0x0000053c + lVar19) = uVar34;
            if ((*pbVar32 & 0x10) != 0) {
              uVar34 = uVar34 + 2 + (*(ushort *)(pbVar32 + uVar25) + 7 >> 3);
              uVar25 = (ulonglong)uVar34;
              *(uint *)(&stack0x0000053c + lVar19) = uVar34;
            }
            if ((*pbVar32 & 0x20) == 0) {
              *(int *)(&stack0x0000052c + lVar19) = (int)uVar25;
              *(undefined2 *)(&stack0x00000544 + lVar19) = 0;
              *(int *)(&stack0x00000540 + lVar19) = (int)uVar25;
            }
            else {
              puVar35 = (ushort *)(pbVar32 + uVar25);
              uVar13 = *puVar35;
              *(ushort *)(&stack0x00000544 + lVar19) = uVar13;
              if (uVar13 == 0) {
                *(undefined8 *)(puVar40 + -8) = 0x105ff8;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x106001;
                  lVar26 = func_0x();
                  if ((lVar26 != 0) && (*(char *)(lVar26 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x10601b;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x106037;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x10605a;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x80f);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x10606b;
                func_0x(uVar30,3);
                uVar13 = *(ushort *)(&stack0x00000544 + lVar19);
                pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
              }
              uVar34 = *(int *)(&stack0x0000053c + lVar19) + 2 + (uint)uVar13 * 2;
              *(uint *)(&stack0x00000540 + lVar19) = uVar34;
              if (0x1f9e < uVar34) {
                *(undefined8 *)(puVar40 + -8) = 0x1060aa;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x1060b3;
                  lVar26 = func_0x();
                  if ((lVar26 != 0) && (*(char *)(lVar26 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x1060cd;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x1060e9;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x10610c;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x816);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x10611d;
                func_0x(uVar30,4);
                uVar13 = *(ushort *)(&stack0x00000544 + lVar19);
                uVar34 = *(uint *)(&stack0x00000540 + lVar19);
                pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
              }
              uVar45 = (ulonglong)uVar13;
              uVar43 = puVar35[uVar45] & 0x7fff;
              *(uint *)(&stack0x0000052c + lVar19) = uVar43;
              if (uVar43 < uVar34) {
                *(undefined8 *)(puVar40 + -8) = 0x10615d;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x106166;
                  lVar26 = func_0x();
                  if ((lVar26 != 0) && (*(char *)(lVar26 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x106180;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x10619c;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x1061bf;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x81d);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x1061d0;
                func_0x(uVar30,4);
                uVar45 = (ulonglong)*(ushort *)(&stack0x00000544 + lVar19);
                uVar34 = *(uint *)(&stack0x00000540 + lVar19);
                pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                uVar43 = *(uint *)(&stack0x0000052c + lVar19);
              }
              uVar25 = (ulonglong)uVar43;
              uVar36 = (ulonglong)uVar34;
              puVar51 = puVar35;
              if ((short)uVar45 != 0) {
                do {
                  uVar34 = puVar51[1] & 0x7fff;
                  if ((uVar34 < (uint)uVar36) || ((uint)uVar25 < uVar34)) {
                    *(undefined8 *)(puVar40 + -8) = 0x106225;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 != '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x10622e;
                      lVar22 = func_0x();
                      if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar40 + -8) = 0x106248;
                        cVar11 = func_0x(0x1fa68c0);
                        if (cVar11 == '\0') {
                          *(undefined8 *)(puVar40 + -8) = 0x106264;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar40 + 0x20) = 0;
                          *(undefined8 *)(puVar40 + -8) = 0x106288;
                          (*_DAT_)(1,0x18962cc,0x19b63b8,0x82a);
                        }
                      }
                    }
                    uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                    *(undefined8 *)(puVar40 + -8) = 0x106299;
                    func_0x(uVar30,4);
                    uVar45 = (ulonglong)*(ushort *)(&stack0x00000544 + lVar19);
                    pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                    uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                  }
                  uVar36 = (ulonglong)uVar34;
                  iVar18 = iVar18 + 1;
                  puVar51 = puVar51 + 1;
                } while (iVar18 < (int)uVar45);
                uVar36 = (ulonglong)*(uint *)(&stack0x00000540 + lVar19);
                iVar16 = *(int *)(&stack0x000000c0 + lVar19);
                lVar22 = *(longlong *)(&stack0x00000098 + lVar19);
              }
              while( true ) {
                sVar33 = (short)uVar45;
                if (-1 < (short)puVar35[(ulonglong)((int)uVar45 - 1) + 1]) break;
                uVar42 = uVar36;
                if ((int)uVar45 != 1) {
                  uVar42 = (ulonglong)
                           (*(ushort *)
                             (pbVar32 +
                             uVar45 * 2 + ((ulonglong)*(uint *)(&stack0x0000053c + lVar19) - 2)) &
                           0x7fff);
                }
                uVar34 = *(ushort *)
                          (pbVar32 + uVar45 * 2 + (ulonglong)*(uint *)(&stack0x0000053c + lVar19)) &
                         0x7fff;
                uVar43 = (uint)uVar42;
                if (((uVar43 < (uint)uVar36) || (uVar34 < uVar43)) || ((uint)uVar25 < uVar34)) {
                  *(undefined8 *)(puVar40 + -8) = 0x10633b;
                  func_0x(pbVar32,7);
                  sVar33 = *(short *)(&stack0x00000544 + lVar19);
                  uVar36 = (ulonglong)*(uint *)(&stack0x00000540 + lVar19);
                  pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                  uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                }
                if ((uVar43 < (uint)uVar36) || ((uint)uVar25 < uVar43)) goto LAB_;
                if (*(ushort *)(pbVar32 + uVar42) == 5) {
                  *(ushort *)(&stack0x0000052a + lVar19) =
                       *(ushort *)(&stack0x0000052a + lVar19) | 2;
                  *(short *)(&stack0x00000544 + lVar19) = sVar33 + -1;
                  uVar45 = uVar42 & 0xffff;
                  *(short *)(&stack0x00000552 + lVar19) = (short)uVar42;
                  pbVar38 = pbVar32 + uVar45;
                  uVar13 = *(ushort *)(&stack0x00000554 + lVar19);
                  if ((*(ushort *)(pbVar38 + 2) >> 0xe & 1) == 0) {
                    uVar13 = uVar13 & 0xc7ff;
                  }
                  else {
                    uVar13 = uVar13 ^ (*(ushort *)(pbVar38 + 2) ^ uVar13) & 0x3800;
                  }
                  *(ushort *)(&stack0x00000554 + lVar19) = uVar13;
                  uVar14 = (uVar13 ^ *(ushort *)(pbVar38 + 2)) & 0x7ff ^ uVar13;
                  *(ushort *)(&stack0x00000554 + lVar19) = uVar14;
                  pbVar37 = pbVar32 + (ulonglong)((uVar14 & 0x7ff) * 2) + 4 +
                                      (uVar13 >> 0xb & 7) * 2 + uVar45;
                  if (pbVar37 < pbVar38) {
                    *(undefined8 *)(puVar40 + -8) = 0x1064ad;
                    func_0x(pbVar38,0x19);
                    uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                    uVar45 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                    pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                    uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                  }
                  if (uVar34 - uVar43 <
                      (((*(uint *)(&stack0x00000554 + lVar19) & 0x7ff) * 2 - (int)uVar45) -
                      *(int *)(&stack0x00000530 + lVar19)) + (int)pbVar37) {
                    *(undefined8 *)(puVar40 + -8) = 0x1064fa;
                    func_0x(pbVar32 + uVar45,0x19);
                    uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                    uVar45 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                    pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                    uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                  }
                  iVar18 = 0;
                  if (((uVar14 & 0x3800) != 0) &&
                     (puVar35 = (ushort *)(pbVar32 + uVar45 + 4), (uVar14 & 0x3800) != 0)) {
                    do {
                      if ((uVar14 & 0x7ff) < (*puVar35 & 0x7ff)) {
                        *(undefined8 *)(puVar40 + -8) = 0x106575;
                        func_0x(pbVar32 + uVar45,0x1a);
                        uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                        uVar45 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                        pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                      }
                      iVar18 = iVar18 + 1;
                      puVar35 = puVar35 + 1;
                    } while (iVar18 < (int)(*(uint *)(&stack0x00000554 + lVar19) >> 0xb & 7));
                    uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                  }
                  break;
                }
                if (*(ushort *)(pbVar32 + uVar42) < 0x400) break;
                *(ushort *)(&stack0x0000052a + lVar19) = *(ushort *)(&stack0x0000052a + lVar19) | 1;
                uVar13 = sVar33 - 1;
                uVar45 = (ulonglong)uVar13;
                *(ushort *)(&stack0x00000544 + lVar19) = uVar13;
                if (uVar13 == 0) break;
              }
            }
            iVar18 = 0;
            if ((*pbVar32 & 0x40) == 0) {
              *(undefined4 *)(&stack0x0000054e + lVar19) = 0;
            }
            else {
              *(int *)(&stack0x0000054e + lVar19) = (int)uVar25;
              *(int *)(&stack0x0000052c + lVar19) = (int)uVar25 + 0xe;
              *(undefined8 *)(puVar40 + -8) = 0x1063c8;
              puVar24 = (ulonglong *)func_0x(&stack0x0000052a + lVar19);
              uVar13 = (ushort)(*puVar24 >> 0x30);
              if ((((uint)(int)(short)uVar13 >> 1 ^ (int)(short)uVar13) & 0x2000) != 0) {
                if ((uVar13 >> 0xe & 1) == 0) {
                  uVar13 = uVar13 & 0xdfff;
                }
                else {
                  uVar13 = uVar13 | 0x2000;
                }
              }
              if (uVar13 == 0xfffc) {
                iVar18 = (int)((*puVar24 >> 0x20 & 0xffff) >> 5);
              }
              uVar25 = (ulonglong)(uint)(*(int *)(&stack0x0000052c + lVar19) + iVar18);
              *(int *)(&stack0x0000052c + lVar19) = *(int *)(&stack0x0000052c + lVar19) + iVar18;
              pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
            }
            if ((*(byte **)(&stack0x00000546 + lVar19) != (byte *)0x0) &&
               (*(byte **)(&stack0x00000546 + lVar19) < pbVar32 + uVar25)) {
              *(undefined8 *)(puVar40 + -8) = 0x10662f;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x106638;
                lVar26 = func_0x();
                if ((lVar26 != 0) && (*(char *)(lVar26 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x106652;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x10666e;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x106694;
                    (*_DAT_)(1,0x18962cc,0x19b63b8,0x886);
                  }
                }
              }
              uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
              *(undefined8 *)(puVar40 + -8) = 0x1066a5;
              func_0x(uVar30,0x12);
              pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
              uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
            }
            if (0x3f3b < (int)uVar25 - 1U) {
              *(undefined8 *)(puVar40 + -8) = 0x1066ce;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x1066d7;
                lVar26 = func_0x();
                if ((lVar26 != 0) && (*(char *)(lVar26 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x1066f1;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x10670d;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                    *(undefined8 *)(puVar40 + -8) = 0x10671e;
                    func_0x(uVar30,5);
                    goto LAB_;
                  }
                  *(undefined8 *)(puVar40 + 0x20) = 0;
                  *(undefined8 *)(puVar40 + -8) = 0x106744;
                  (*_DAT_)(1,0x18962cc,0x19b63b8,0x88b);
                }
              }
              uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
              *(undefined8 *)(puVar40 + -8) = 0x106755;
              func_0x(uVar30,5);
              goto LAB_;
            }
          }
        }
        else if (*(int *)(&stack0x0000052c + lVar19) == 0) {
          *(undefined8 *)(puVar40 + -8) = 0x10676c;
          func_0x(&stack0x0000052a + lVar19);
LAB_:
          pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
        }
LAB_:
        uVar6 = *(uint6 *)(lVar22 + 0x14);
        lVar22 = *(longlong *)(&stack0x00000110 + lVar19);
        *(undefined8 *)(puVar40 + -8) = 0x10679f;
        func_0x(lVar22,(ulonglong)uVar6 << 0x10,1);
        uVar30 = *(undefined8 *)(lVar22 + 0x2268);
        *(undefined8 *)(puVar40 + -8) = 0x1067b6;
        func_0x(uVar30,pbVar32,iVar16 == 0);
        iVar16 = *(int *)(&stack0x000000cc + lVar19);
        goto LAB_;
      }
      if (bVar52) goto LAB_;
      uVar10 = iVar16 == -1;
      (&stack0x00000080)[lVar19] = uVar10;
      if (*(short *)(&stack0x00000528 + lVar19) == 0) {
        bVar31 = **(byte **)(&stack0x00000530 + lVar19) >> 6;
      }
      else {
        bVar31 = **(byte **)(&stack0x00000530 + lVar19) >> 1;
      }
      if ((bVar31 & 1) != 0) {
        if (*(short *)(&stack0x00000528 + lVar19) == 0) {
          *(undefined8 *)(puVar40 + -8) = 0x10786f;
          func_0x();
        }
        else {
          *(undefined8 *)(puVar40 + -8) = 0x107876;
          func_0x(&stack0x0000052a + lVar19,&stack0x0000014e + lVar19);
        }
        uVar17 = *(undefined4 *)(&stack0x0000014e + lVar19);
        uVar3 = *(undefined2 *)(&stack0x00000152 + lVar19);
        if (*(short *)(&stack0x00000528 + lVar19) == 0) {
          *(undefined8 *)(puVar40 + -8) = 0x1078a0;
          func_0x();
        }
        else {
          *(undefined8 *)(puVar40 + -8) = 0x1078a7;
          func_0x(&stack0x0000052a + lVar19,&stack0x000001b0 + lVar19);
        }
        lVar22 = *(longlong *)(*(longlong *)(&stack0x000000d0 + lVar19) + 0x30);
        *(undefined4 *)(&stack0x000000f8 + lVar19) = uVar17;
        *(undefined2 *)(&stack0x000000fc + lVar19) = uVar3;
        puVar40[0x40] = 0;
        puVar40[0x38] = 0;
        puVar40[0x30] = 0;
        puVar40[0x28] = 0;
        puVar40[0x20] = 0;
        uVar30 = *(undefined8 *)(lVar22 + 0x6b0);
        *(undefined8 *)(puVar40 + -8) = 0x1078f9;
        cVar11 = func_0x
                           (uVar30,&stack0x000000f8 + lVar19,&stack0x000001b0 + lVar19,
                            &stack0x00000108 + lVar19);
        if (cVar11 == '\0') {
          if (*(short *)(&stack0x00000528 + lVar19) == 0) {
            *(undefined8 *)(puVar40 + -8) = 0x107917;
            func_0x(&stack0x0000052a + lVar19);
          }
          else if ((**(byte **)(&stack0x00000530 + lVar19) & 2) != 0) {
            if (*(int *)(&stack0x0000052c + lVar19) == 0) {
              *(undefined8 *)(puVar40 + -8) = 0x107a20;
              func_0x(&stack0x0000052a + lVar19);
            }
            **(byte **)(&stack0x00000530 + lVar19) = **(byte **)(&stack0x00000530 + lVar19) & 0xfd;
            *(undefined4 *)(&stack0x0000052c + lVar19) = *(undefined4 *)(&stack0x00000558 + lVar19);
            *(undefined4 *)(&stack0x00000558 + lVar19) = 0;
          }
        }
      }
      iVar18 = 0;
      lVar22 = *(longlong *)(&stack0x00000098 + lVar19);
      iVar16 = *(int *)(*(longlong *)(lVar22 + 8) + 0x100);
      *(undefined8 *)(&stack0x000000b0 + lVar19) = 0;
      *(undefined2 *)(&stack0x000000b8 + lVar19) = 0;
      if (*(short *)(&stack0x00000048 + lVar19) == 0) {
        if (*(int *)(&stack0x0000004c + lVar19) == 0) {
          *(undefined2 *)(&stack0x0000004a + lVar19) = 0;
          uVar34 = *(uint *)(&stack0x00000058 + lVar19);
          uVar25 = (ulonglong)uVar34;
          *(uint *)(&stack0x0000005c + lVar19) = uVar34;
          if ((**(byte **)(&stack0x00000050 + lVar19) & 0x10) != 0) {
            uVar34 = uVar34 + 2 +
                     (*(ushort *)(*(byte **)(&stack0x00000050 + lVar19) + uVar25) + 7 >> 3);
            uVar25 = (ulonglong)uVar34;
            *(uint *)(&stack0x0000005c + lVar19) = uVar34;
          }
          if ((**(byte **)(&stack0x00000050 + lVar19) & 0x20) == 0) {
            *(int *)(&stack0x0000004c + lVar19) = (int)uVar25;
            *(undefined2 *)(&stack0x00000064 + lVar19) = 0;
            *(int *)(&stack0x00000060 + lVar19) = (int)uVar25;
          }
          else {
            puVar35 = (ushort *)(*(byte **)(&stack0x00000050 + lVar19) + uVar25);
            uVar13 = *puVar35;
            *(ushort *)(&stack0x00000064 + lVar19) = uVar13;
            if (uVar13 == 0) {
              *(undefined8 *)(puVar40 + -8) = 0x1079ae;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x1079bb;
                lVar26 = func_0x();
                if ((lVar26 != 0) && (*(char *)(lVar26 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x1079dd;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x1079f9;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x107a67;
                    (*_DAT_)(1,0x18962cc,0x19b63b8,0x80f);
                  }
                }
              }
              uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
              *(undefined8 *)(puVar40 + -8) = 0x107a75;
              func_0x(uVar30,3);
              uVar13 = *(ushort *)(&stack0x00000064 + lVar19);
            }
            uVar34 = *(int *)(&stack0x0000005c + lVar19) + 2 + (uint)uVar13 * 2;
            *(uint *)(&stack0x00000060 + lVar19) = uVar34;
            if (0x1f9e < uVar34) {
              *(undefined8 *)(puVar40 + -8) = 0x107aa4;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x107aad;
                lVar26 = func_0x();
                if ((lVar26 != 0) && (*(char *)(lVar26 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x107ac7;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x107ae3;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x107b09;
                    (*_DAT_)(1,0x18962cc,0x19b63b8,0x816);
                  }
                }
              }
              uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
              *(undefined8 *)(puVar40 + -8) = 0x107b17;
              func_0x(uVar30,4);
              uVar13 = *(ushort *)(&stack0x00000064 + lVar19);
              uVar34 = *(uint *)(&stack0x00000060 + lVar19);
            }
            uVar45 = (ulonglong)uVar13;
            uVar43 = puVar35[uVar45] & 0x7fff;
            *(uint *)(&stack0x0000004c + lVar19) = uVar43;
            if (uVar43 < uVar34) {
              *(undefined8 *)(puVar40 + -8) = 0x107b47;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x107b50;
                lVar26 = func_0x();
                if ((lVar26 != 0) && (*(char *)(lVar26 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x107b6a;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x107b86;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x107bac;
                    (*_DAT_)(1,0x18962cc,0x19b63b8,0x81d);
                  }
                }
              }
              uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
              *(undefined8 *)(puVar40 + -8) = 0x107bba;
              func_0x(uVar30,4);
              uVar45 = (ulonglong)*(ushort *)(&stack0x00000064 + lVar19);
              uVar34 = *(uint *)(&stack0x00000060 + lVar19);
              uVar43 = *(uint *)(&stack0x0000004c + lVar19);
            }
            uVar25 = (ulonglong)uVar43;
            uVar36 = (ulonglong)uVar34;
            puVar51 = puVar35;
            if ((short)uVar45 != 0) {
              do {
                uVar34 = puVar51[1] & 0x7fff;
                if ((uVar34 < (uint)uVar36) || ((uint)uVar25 < uVar34)) {
                  *(undefined8 *)(puVar40 + -8) = 0x107c03;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x107c0c;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar40 + -8) = 0x107c26;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x107c42;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x107c66;
                        (*_DAT_)(1,0x18962cc,0x19b63b8,0x82a);
                      }
                    }
                  }
                  uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x107c74;
                  func_0x(uVar30,4);
                  uVar45 = (ulonglong)*(ushort *)(&stack0x00000064 + lVar19);
                  uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                }
                uVar36 = (ulonglong)uVar34;
                iVar18 = iVar18 + 1;
                puVar51 = puVar51 + 1;
              } while (iVar18 < (int)uVar45);
              uVar36 = (ulonglong)*(uint *)(&stack0x00000060 + lVar19);
              uVar10 = (&stack0x00000080)[lVar19];
              lVar22 = *(longlong *)(&stack0x00000098 + lVar19);
            }
            while( true ) {
              sVar33 = (short)uVar45;
              if (-1 < (short)puVar35[(ulonglong)((int)uVar45 - 1) + 1]) break;
              uVar42 = uVar36;
              if ((int)uVar45 != 1) {
                uVar42 = (ulonglong)
                         (*(ushort *)
                           ((ulonglong)*(uint *)(&stack0x0000005c + lVar19) +
                            *(longlong *)(&stack0x00000050 + lVar19) + -2 + uVar45 * 2) & 0x7fff);
              }
              uVar43 = *(ushort *)
                        ((ulonglong)*(uint *)(&stack0x0000005c + lVar19) +
                         *(longlong *)(&stack0x00000050 + lVar19) + uVar45 * 2) & 0x7fff;
              uVar34 = (uint)uVar42;
              if (((uVar34 < (uint)uVar36) || (uVar43 < uVar34)) || ((uint)uVar25 < uVar43)) {
                uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x107d0a;
                func_0x(uVar30,7);
                sVar33 = *(short *)(&stack0x00000064 + lVar19);
                uVar36 = (ulonglong)*(uint *)(&stack0x00000060 + lVar19);
                uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
              }
              if ((uVar34 < (uint)uVar36) || ((uint)uVar25 < uVar34)) goto LAB_;
              if (*(ushort *)(uVar42 + *(longlong *)(&stack0x00000050 + lVar19)) == 5) {
                *(ushort *)(&stack0x0000004a + lVar19) = *(ushort *)(&stack0x0000004a + lVar19) | 2;
                *(short *)(&stack0x00000064 + lVar19) = sVar33 + -1;
                uVar36 = uVar42 & 0xffff;
                *(short *)(&stack0x00000072 + lVar19) = (short)uVar42;
                uVar45 = *(longlong *)(&stack0x00000050 + lVar19) + uVar36;
                uVar13 = *(ushort *)(&stack0x00000074 + lVar19);
                if ((*(ushort *)(uVar45 + 2) >> 0xe & 1) == 0) {
                  uVar13 = uVar13 & 0xc7ff;
                }
                else {
                  uVar13 = uVar13 ^ (uVar13 ^ *(ushort *)(uVar45 + 2)) & 0x3800;
                }
                *(ushort *)(&stack0x00000074 + lVar19) = uVar13;
                uVar14 = (uVar13 ^ *(ushort *)(uVar45 + 2)) & 0x7ff ^ uVar13;
                *(ushort *)(&stack0x00000074 + lVar19) = uVar14;
                uVar42 = *(longlong *)(&stack0x00000050 + lVar19) + 4 +
                         (ulonglong)((uVar14 & 0x7ff) * 2) + (uVar13 >> 0xb & 7) * 2 + uVar36;
                if (uVar42 < uVar45) {
                  *(undefined8 *)(puVar40 + -8) = 0x107e03;
                  func_0x(uVar45,0x19);
                  uVar14 = *(ushort *)(&stack0x00000074 + lVar19);
                  uVar36 = (ulonglong)*(ushort *)(&stack0x00000072 + lVar19);
                  uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                }
                if (uVar43 - uVar34 <
                    (((*(uint *)(&stack0x00000074 + lVar19) & 0x7ff) * 2 - (int)uVar36) -
                    *(int *)(&stack0x00000050 + lVar19)) + (int)uVar42) {
                  lVar26 = *(longlong *)(&stack0x00000050 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x107e3a;
                  func_0x(uVar36 + lVar26,0x19);
                  uVar14 = *(ushort *)(&stack0x00000074 + lVar19);
                  uVar36 = (ulonglong)*(ushort *)(&stack0x00000072 + lVar19);
                  uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                }
                if ((uVar14 & 0x3800) != 0) {
                  puVar35 = (ushort *)(*(longlong *)(&stack0x00000050 + lVar19) + 4 + uVar36);
                  iVar18 = 0;
                  if ((uVar14 & 0x3800) != 0) {
                    do {
                      if ((uVar14 & 0x7ff) < (*puVar35 & 0x7ff)) {
                        lVar26 = *(longlong *)(&stack0x00000050 + lVar19);
                        *(undefined8 *)(puVar40 + -8) = 0x107ea6;
                        func_0x(uVar36 + lVar26,0x1a);
                        uVar14 = *(ushort *)(&stack0x00000074 + lVar19);
                        uVar36 = (ulonglong)*(ushort *)(&stack0x00000072 + lVar19);
                      }
                      iVar18 = iVar18 + 1;
                      puVar35 = puVar35 + 1;
                    } while (iVar18 < (int)(*(uint *)(&stack0x00000074 + lVar19) >> 0xb & 7));
                    uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
                  }
                }
                break;
              }
              if (*(ushort *)(uVar42 + *(longlong *)(&stack0x00000050 + lVar19)) < 0x400) break;
              *(ushort *)(&stack0x0000004a + lVar19) = *(ushort *)(&stack0x0000004a + lVar19) | 1;
              uVar13 = sVar33 - 1;
              uVar45 = (ulonglong)uVar13;
              *(ushort *)(&stack0x00000064 + lVar19) = uVar13;
              if (uVar13 == 0) break;
            }
          }
          iVar18 = 0;
          if ((**(byte **)(&stack0x00000050 + lVar19) & 0x40) == 0) {
            *(undefined4 *)(&stack0x0000006e + lVar19) = 0;
          }
          else {
            *(int *)(&stack0x0000006e + lVar19) = (int)uVar25;
            *(int *)(&stack0x0000004c + lVar19) = (int)uVar25 + 0xe;
            *(undefined8 *)(puVar40 + -8) = 0x107efc;
            puVar24 = (ulonglong *)func_0x(&stack0x0000004a + lVar19);
            uVar13 = (ushort)(*puVar24 >> 0x30);
            if ((((uint)(int)(short)uVar13 >> 1 ^ (int)(short)uVar13) & 0x2000) != 0) {
              if ((uVar13 >> 0xe & 1) == 0) {
                uVar13 = uVar13 & 0xdfff;
              }
              else {
                uVar13 = uVar13 | 0x2000;
              }
            }
            if (uVar13 == 0xfffc) {
              iVar18 = (int)((*puVar24 >> 0x20 & 0xffff) >> 5);
            }
            uVar25 = (ulonglong)(uint)(*(int *)(&stack0x0000004c + lVar19) + iVar18);
            *(int *)(&stack0x0000004c + lVar19) = *(int *)(&stack0x0000004c + lVar19) + iVar18;
          }
          if ((*(ulonglong *)(&stack0x00000066 + lVar19) != 0) &&
             (*(ulonglong *)(&stack0x00000066 + lVar19) <
              uVar25 + *(longlong *)(&stack0x00000050 + lVar19))) {
            *(undefined8 *)(puVar40 + -8) = 0x107f7e;
            cVar11 = func_0x(0x1fa68c0);
            if (cVar11 != '\0') {
              *(undefined8 *)(puVar40 + -8) = 0x107f87;
              lVar26 = func_0x();
              if ((lVar26 != 0) && (*(char *)(lVar26 + 0x499) != '\0')) {
                *(undefined8 *)(puVar40 + -8) = 0x107fa1;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 == '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x107fbd;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar40 + 0x20) = 0;
                  *(undefined8 *)(puVar40 + -8) = 0x107fe3;
                  (*_DAT_)(1,0x18962cc,0x19b63b8,0x886);
                }
              }
            }
            uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
            *(undefined8 *)(puVar40 + -8) = 0x107ff1;
            func_0x(uVar30,0x12);
            uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
          }
          if (0x3f3b < (int)uVar25 - 1U) {
            *(undefined8 *)(puVar40 + -8) = 0x108010;
            cVar11 = func_0x(0x1fa68c0);
            if (cVar11 != '\0') {
              *(undefined8 *)(puVar40 + -8) = 0x108019;
              lVar26 = func_0x();
              if ((lVar26 != 0) && (*(char *)(lVar26 + 0x499) != '\0')) {
                *(undefined8 *)(puVar40 + -8) = 0x108033;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 == '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x10804f;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x10805d;
                  func_0x(uVar30,5);
                  goto LAB_;
                }
                *(undefined8 *)(puVar40 + 0x20) = 0;
                *(undefined8 *)(puVar40 + -8) = 0x108083;
                (*_DAT_)(1,0x18962cc,0x19b63b8,0x88b);
              }
            }
            uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
            *(undefined8 *)(puVar40 + -8) = 0x108091;
            func_0x(uVar30,5);
          }
        }
      }
      else if (*(int *)(&stack0x0000004c + lVar19) == 0) {
        *(undefined8 *)(puVar40 + -8) = 0x1080a2;
        func_0x(&stack0x0000004a + lVar19);
      }
LAB_:
      iVar18 = 0;
      if (*(short *)(&stack0x00000528 + lVar19) == 0) {
        if (*(int *)(&stack0x0000052c + lVar19) == 0) {
          *(undefined2 *)(&stack0x0000052a + lVar19) = 0;
          uVar34 = *(uint *)(&stack0x00000538 + lVar19);
          *(uint *)(&stack0x0000053c + lVar19) = uVar34;
          if ((**(byte **)(&stack0x00000530 + lVar19) & 0x10) != 0) {
            uVar34 = uVar34 + 2 +
                     (*(ushort *)(*(byte **)(&stack0x00000530 + lVar19) + uVar34) + 7 >> 3);
            *(uint *)(&stack0x0000053c + lVar19) = uVar34;
          }
          if ((**(byte **)(&stack0x00000530 + lVar19) & 0x20) == 0) {
            *(uint *)(&stack0x0000052c + lVar19) = uVar34;
            *(undefined2 *)(&stack0x00000544 + lVar19) = 0;
            *(uint *)(&stack0x00000540 + lVar19) = uVar34;
          }
          else {
            puVar35 = (ushort *)(*(byte **)(&stack0x00000530 + lVar19) + uVar34);
            uVar13 = *puVar35;
            *(ushort *)(&stack0x00000544 + lVar19) = uVar13;
            if (uVar13 == 0) {
              *(undefined8 *)(puVar40 + -8) = 0x108127;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x108130;
                lVar26 = func_0x();
                if ((lVar26 != 0) && (*(char *)(lVar26 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x10814a;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x108166;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x10818c;
                    (*_DAT_)(1,0x18962cc,0x19b63b8,0x80f);
                  }
                }
              }
              uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
              *(undefined8 *)(puVar40 + -8) = 0x10819d;
              func_0x(uVar30,3);
              uVar13 = *(ushort *)(&stack0x00000544 + lVar19);
            }
            uVar34 = *(int *)(&stack0x0000053c + lVar19) + 2 + (uint)uVar13 * 2;
            *(uint *)(&stack0x00000540 + lVar19) = uVar34;
            if (0x1f9e < uVar34) {
              *(undefined8 *)(puVar40 + -8) = 0x1081d5;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x1081de;
                lVar26 = func_0x();
                if ((lVar26 != 0) && (*(char *)(lVar26 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x1081f8;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x108214;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x10823a;
                    (*_DAT_)(1,0x18962cc,0x19b63b8,0x816);
                  }
                }
              }
              uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
              *(undefined8 *)(puVar40 + -8) = 0x10824b;
              func_0x(uVar30,4);
              uVar13 = *(ushort *)(&stack0x00000544 + lVar19);
              uVar34 = *(uint *)(&stack0x00000540 + lVar19);
            }
            uVar25 = (ulonglong)uVar13;
            uVar13 = puVar35[uVar25];
            *(uint *)(&stack0x0000052c + lVar19) = uVar13 & 0x7fff;
            if ((uVar13 & 0x7fff) < uVar34) {
              *(undefined8 *)(puVar40 + -8) = 0x108282;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x10828b;
                lVar26 = func_0x();
                if ((lVar26 != 0) && (*(char *)(lVar26 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x1082a5;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x1082c1;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x1082e7;
                    (*_DAT_)(1,0x18962cc,0x19b63b8,0x81d);
                  }
                }
              }
              uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
              *(undefined8 *)(puVar40 + -8) = 0x1082f8;
              func_0x(uVar30,4);
              uVar25 = (ulonglong)*(ushort *)(&stack0x00000544 + lVar19);
              uVar34 = *(uint *)(&stack0x00000540 + lVar19);
            }
            uVar45 = (ulonglong)uVar34;
            puVar51 = puVar35;
            if ((short)uVar25 != 0) {
              do {
                uVar34 = puVar51[1] & 0x7fff;
                if ((uVar34 < (uint)uVar45) || (*(uint *)(&stack0x0000052c + lVar19) < uVar34)) {
                  *(undefined8 *)(puVar40 + -8) = 0x108346;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x10834f;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar40 + -8) = 0x108369;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x108385;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x1083a9;
                        (*_DAT_)(1,0x18962cc,0x19b63b8,0x82a);
                      }
                    }
                  }
                  uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x1083ba;
                  func_0x(uVar30,4);
                  uVar25 = (ulonglong)*(ushort *)(&stack0x00000544 + lVar19);
                }
                uVar45 = (ulonglong)uVar34;
                iVar18 = iVar18 + 1;
                puVar51 = puVar51 + 1;
              } while (iVar18 < (int)uVar25);
              uVar45 = (ulonglong)*(uint *)(&stack0x00000540 + lVar19);
              uVar10 = (&stack0x00000080)[lVar19];
              lVar22 = *(longlong *)(&stack0x00000098 + lVar19);
            }
            while( true ) {
              sVar33 = (short)uVar25;
              if (-1 < (short)puVar35[(ulonglong)((int)uVar25 - 1) + 1]) break;
              uVar36 = uVar45;
              if ((int)uVar25 != 1) {
                uVar36 = (ulonglong)
                         (*(ushort *)
                           ((ulonglong)*(uint *)(&stack0x0000053c + lVar19) +
                            *(longlong *)(&stack0x00000530 + lVar19) + -2 + uVar25 * 2) & 0x7fff);
              }
              uVar43 = *(ushort *)
                        ((ulonglong)*(uint *)(&stack0x0000053c + lVar19) +
                         *(longlong *)(&stack0x00000530 + lVar19) + uVar25 * 2) & 0x7fff;
              uVar34 = (uint)uVar36;
              if (((uVar34 < (uint)uVar45) || (uVar43 < uVar34)) ||
                 (*(uint *)(&stack0x0000052c + lVar19) < uVar43)) {
                uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x108456;
                func_0x(uVar30,7);
                sVar33 = *(short *)(&stack0x00000544 + lVar19);
                uVar45 = (ulonglong)*(uint *)(&stack0x00000540 + lVar19);
              }
              if ((uVar34 < (uint)uVar45) || (*(uint *)(&stack0x0000052c + lVar19) < uVar34))
              goto LAB_;
              if (*(ushort *)(uVar36 + *(longlong *)(&stack0x00000530 + lVar19)) == 5) {
                *(ushort *)(&stack0x0000052a + lVar19) = *(ushort *)(&stack0x0000052a + lVar19) | 2;
                *(short *)(&stack0x00000544 + lVar19) = sVar33 + -1;
                uVar25 = uVar36 & 0xffff;
                *(short *)(&stack0x00000552 + lVar19) = (short)uVar36;
                uVar45 = *(longlong *)(&stack0x00000530 + lVar19) + uVar25;
                uVar13 = *(ushort *)(&stack0x00000554 + lVar19);
                if ((*(ushort *)(uVar45 + 2) >> 0xe & 1) == 0) {
                  uVar13 = uVar13 & 0xc7ff;
                }
                else {
                  uVar13 = uVar13 ^ (uVar13 ^ *(ushort *)(uVar45 + 2)) & 0x3800;
                }
                *(ushort *)(&stack0x00000554 + lVar19) = uVar13;
                uVar14 = (uVar13 ^ *(ushort *)(uVar45 + 2)) & 0x7ff ^ uVar13;
                *(ushort *)(&stack0x00000554 + lVar19) = uVar14;
                uVar36 = *(longlong *)(&stack0x00000530 + lVar19) + 4 +
                         (ulonglong)((uVar14 & 0x7ff) * 2) + uVar25 + (uVar13 >> 0xb & 7) * 2;
                if (uVar36 < uVar45) {
                  *(undefined8 *)(puVar40 + -8) = 0x108576;
                  func_0x(uVar45,0x19);
                  uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                  uVar25 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                }
                if (uVar43 - uVar34 <
                    (((*(uint *)(&stack0x00000554 + lVar19) & 0x7ff) * 2 - (int)uVar25) -
                    *(int *)(&stack0x00000530 + lVar19)) + (int)uVar36) {
                  lVar26 = *(longlong *)(&stack0x00000530 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x1085b7;
                  func_0x(uVar25 + lVar26,0x19);
                  uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                  uVar25 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                }
                if ((uVar14 & 0x3800) != 0) {
                  puVar35 = (ushort *)(*(longlong *)(&stack0x00000530 + lVar19) + 4 + uVar25);
                  iVar18 = 0;
                  if ((uVar14 & 0x3800) != 0) {
                    do {
                      if ((uVar14 & 0x7ff) < (*puVar35 & 0x7ff)) {
                        lVar26 = *(longlong *)(&stack0x00000530 + lVar19);
                        *(undefined8 *)(puVar40 + -8) = 0x108617;
                        func_0x(uVar25 + lVar26,0x1a);
                        uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                        uVar25 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                      }
                      iVar18 = iVar18 + 1;
                      puVar35 = puVar35 + 1;
                    } while (iVar18 < (int)(*(uint *)(&stack0x00000554 + lVar19) >> 0xb & 7));
                  }
                }
                break;
              }
              if (*(ushort *)(uVar36 + *(longlong *)(&stack0x00000530 + lVar19)) < 0x400) break;
              *(ushort *)(&stack0x0000052a + lVar19) = *(ushort *)(&stack0x0000052a + lVar19) | 1;
              uVar13 = sVar33 - 1;
              uVar25 = (ulonglong)uVar13;
              *(ushort *)(&stack0x00000544 + lVar19) = uVar13;
              if (uVar13 == 0) break;
            }
          }
          iVar18 = 0;
          if ((**(byte **)(&stack0x00000530 + lVar19) & 0x40) == 0) {
            *(undefined4 *)(&stack0x0000054e + lVar19) = 0;
          }
          else {
            *(undefined4 *)(&stack0x0000054e + lVar19) = *(undefined4 *)(&stack0x0000052c + lVar19);
            *(int *)(&stack0x0000052c + lVar19) = *(int *)(&stack0x0000052c + lVar19) + 0xe;
            *(undefined8 *)(puVar40 + -8) = 0x10867f;
            puVar24 = (ulonglong *)func_0x(&stack0x0000052a + lVar19);
            uVar13 = (ushort)(*puVar24 >> 0x30);
            if ((((uint)(int)(short)uVar13 >> 1 ^ (int)(short)uVar13) & 0x2000) != 0) {
              if ((uVar13 >> 0xe & 1) == 0) {
                uVar13 = uVar13 & 0xdfff;
              }
              else {
                uVar13 = uVar13 | 0x2000;
              }
            }
            if (uVar13 == 0xfffc) {
              iVar18 = (int)((*puVar24 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(&stack0x0000052c + lVar19) = *(int *)(&stack0x0000052c + lVar19) + iVar18;
          }
          if ((*(ulonglong *)(&stack0x00000546 + lVar19) != 0) &&
             (*(ulonglong *)(&stack0x00000546 + lVar19) <
              (ulonglong)*(uint *)(&stack0x0000052c + lVar19) +
              *(longlong *)(&stack0x00000530 + lVar19))) {
            *(undefined8 *)(puVar40 + -8) = 0x108709;
            cVar11 = func_0x(0x1fa68c0);
            if (cVar11 != '\0') {
              *(undefined8 *)(puVar40 + -8) = 0x108712;
              lVar26 = func_0x();
              if ((lVar26 != 0) && (*(char *)(lVar26 + 0x499) != '\0')) {
                *(undefined8 *)(puVar40 + -8) = 0x10872c;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 == '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x108748;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar40 + 0x20) = 0;
                  *(undefined8 *)(puVar40 + -8) = 0x10876e;
                  (*_DAT_)(1,0x18962cc,0x19b63b8,0x886);
                }
              }
            }
            uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
            *(undefined8 *)(puVar40 + -8) = 0x10877f;
            func_0x(uVar30,0x12);
          }
          if (0x3f3b < *(int *)(&stack0x0000052c + lVar19) - 1U) {
            *(undefined8 *)(puVar40 + -8) = 0x10879e;
            cVar11 = func_0x(0x1fa68c0);
            if (cVar11 != '\0') {
              *(undefined8 *)(puVar40 + -8) = 0x1087a7;
              lVar26 = func_0x();
              if ((lVar26 != 0) && (*(char *)(lVar26 + 0x499) != '\0')) {
                *(undefined8 *)(puVar40 + -8) = 0x1087c1;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 == '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x1087dd;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar40 + 0x20) = 0;
                  *(undefined8 *)(puVar40 + -8) = 0x108803;
                  (*_DAT_)(1,0x18962cc,0x19b63b8,0x88b);
                }
              }
            }
            uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
            *(undefined8 *)(puVar40 + -8) = 0x108814;
            func_0x(uVar30,5);
          }
        }
LAB_:
        if ((8 < *(uint *)(&stack0x0000052c + lVar19)) ||
           (((**(byte **)(&stack0x00000530 + lVar19) & 0xe) != 0 &&
            ((**(byte **)(&stack0x00000530 + lVar19) & 0xe) != 0xc)))) {
LAB_:
          *(undefined4 *)(&stack0x00000084 + lVar19) = *(undefined4 *)(&stack0x0000052c + lVar19);
        }
      }
      else {
        if (*(int *)(&stack0x0000052c + lVar19) == 0) {
          *(undefined8 *)(puVar40 + -8) = 0x1089a9;
          func_0x(&stack0x0000052a + lVar19);
        }
        if ((8 < *(uint *)(&stack0x0000052c + lVar19)) ||
           (((**(byte **)(&stack0x00000530 + lVar19) & 0x1c) != 0 &&
            ((**(byte **)(&stack0x00000530 + lVar19) & 0x1c) != 0xc)))) goto LAB_;
        *(undefined4 *)(&stack0x00000084 + lVar19) = 9;
      }
      uVar6 = *(uint6 *)(lVar22 + 0x14);
      puVar40[0x60] = 1;
      puVar40[0x58] = uVar10;
      *(uint *)(puVar40 + 0x50) = (uint)(iVar16 == 2);
      *(undefined **)(puVar40 + 0x48) = &stack0x000000b0 + lVar19;
      *(undefined8 *)(puVar40 + 0x38) = *(undefined8 *)(&stack0x00000050 + lVar19);
      *(undefined4 *)(puVar40 + 0x30) = *(undefined4 *)(&stack0x000000d8 + lVar19);
      iVar16 = 0;
      *(undefined4 *)(puVar40 + 0x28) = 0;
      *(undefined4 *)(puVar40 + 0x20) = *(undefined4 *)(&stack0x00000084 + lVar19);
      uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
      uVar27 = *(undefined8 *)(&stack0x00000110 + lVar19);
      *(undefined8 *)(puVar40 + -8) = 0x10889c;
      func_0x(uVar27,(ulonglong)uVar6 << 0x10,0,uVar30);
    }
  }
  else {
    if (*(int *)(&stack0x0000008c + lVar19) == 0) {
      uVar34 = 0;
LAB_:
      pbVar32 = (byte *)0x0;
      *(undefined8 *)(&stack0x00000040 + lVar19) = 0;
    }
    else {
      uVar34 = *(uint *)(&stack0x0000052c + lVar19);
      if (*(short *)(&stack0x00000528 + lVar19) == 0) {
        pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
        *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
        if (uVar34 == 0) {
          iVar18 = 0;
          *(undefined2 *)(&stack0x0000052a + lVar19) = 0;
          uVar34 = *(uint *)(&stack0x00000538 + lVar19);
          uVar25 = (ulonglong)uVar34;
          *(uint *)(&stack0x0000053c + lVar19) = uVar34;
          if ((*pbVar32 & 0x10) != 0) {
            uVar34 = uVar34 + 2 + (*(ushort *)(pbVar32 + uVar25) + 7 >> 3);
            uVar25 = (ulonglong)uVar34;
            *(uint *)(&stack0x0000053c + lVar19) = uVar34;
          }
          if ((*pbVar32 & 0x20) == 0) {
            *(int *)(&stack0x0000052c + lVar19) = (int)uVar25;
            *(undefined2 *)(&stack0x00000544 + lVar19) = 0;
            *(int *)(&stack0x00000540 + lVar19) = (int)uVar25;
          }
          else {
            puVar35 = (ushort *)(pbVar32 + uVar25);
            *(ushort **)(&stack0x000000b0 + lVar19) = puVar35;
            uVar13 = *puVar35;
            *(ushort *)(&stack0x00000544 + lVar19) = uVar13;
            if (uVar13 == 0) {
              *(undefined8 *)(puVar40 + -8) = 0x102dc2;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x102dcb;
                lVar22 = func_0x();
                if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x102de4;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x102e00;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x102e26;
                    (*_DAT_)(1,0x18962cc,0x19b63b8,0x80f);
                  }
                }
              }
              uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
              *(undefined8 *)(puVar40 + -8) = 0x102e37;
              func_0x(uVar30,3);
              uVar13 = *(ushort *)(&stack0x00000544 + lVar19);
              pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
              *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
            }
            uVar34 = *(int *)(&stack0x0000053c + lVar19) + 2 + (uint)uVar13 * 2;
            *(uint *)(&stack0x00000540 + lVar19) = uVar34;
            if (0x1f9e < uVar34) {
              *(undefined8 *)(puVar40 + -8) = 0x102e7a;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x102e83;
                lVar22 = func_0x();
                if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x102e9c;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x102eb8;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x102ede;
                    (*_DAT_)(1,0x18962cc,0x19b63b8,0x816);
                  }
                }
              }
              uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
              *(undefined8 *)(puVar40 + -8) = 0x102eef;
              func_0x(uVar30,4);
              uVar13 = *(ushort *)(&stack0x00000544 + lVar19);
              uVar34 = *(uint *)(&stack0x00000540 + lVar19);
              pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
              *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
            }
            uVar45 = (ulonglong)uVar13;
            uVar43 = puVar35[uVar45] & 0x7fff;
            *(uint *)(&stack0x0000052c + lVar19) = uVar43;
            if (uVar43 < uVar34) {
              *(undefined8 *)(puVar40 + -8) = 0x102f31;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x102f3a;
                lVar22 = func_0x();
                if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar40 + -8) = 0x102f53;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x102f6f;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar40 + 0x20) = 0;
                    *(undefined8 *)(puVar40 + -8) = 0x102f95;
                    (*_DAT_)(1,0x18962cc,0x19b63b8,0x81d);
                  }
                }
              }
              uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
              *(undefined8 *)(puVar40 + -8) = 0x102fa6;
              func_0x(uVar30,4);
              uVar45 = (ulonglong)*(ushort *)(&stack0x00000544 + lVar19);
              uVar34 = *(uint *)(&stack0x00000540 + lVar19);
              pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
              *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
              uVar43 = *(uint *)(&stack0x0000052c + lVar19);
            }
            uVar36 = (ulonglong)uVar34;
            uVar25 = (ulonglong)uVar43;
            if ((short)uVar45 != 0) {
              do {
                puVar35 = puVar35 + 1;
                uVar34 = *puVar35 & 0x7fff;
                if ((uVar34 < (uint)uVar36) || ((uint)uVar25 < uVar34)) {
                  *(undefined8 *)(puVar40 + -8) = 0x103002;
                  cVar11 = func_0x(0x1fa68c0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar40 + -8) = 0x10300b;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar40 + -8) = 0x103025;
                      cVar11 = func_0x(0x1fa68c0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar40 + -8) = 0x103041;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar40 + 0x20) = 0;
                        *(undefined8 *)(puVar40 + -8) = 0x103065;
                        (*_DAT_)(1,0x18962cc,0x19b63b8,0x82a);
                      }
                    }
                  }
                  uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
                  *(undefined8 *)(puVar40 + -8) = 0x103076;
                  func_0x(uVar30,4);
                  uVar45 = (ulonglong)*(ushort *)(&stack0x00000544 + lVar19);
                  pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                  uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                }
                uVar36 = (ulonglong)uVar34;
                iVar18 = iVar18 + 1;
              } while (iVar18 < (int)uVar45);
              *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
              uVar36 = (ulonglong)*(uint *)(&stack0x00000540 + lVar19);
              puVar35 = *(ushort **)(&stack0x000000b0 + lVar19);
              iVar16 = *(int *)(&stack0x000000c0 + lVar19);
            }
            while( true ) {
              sVar33 = (short)uVar45;
              if (-1 < (short)puVar35[(ulonglong)((int)uVar45 - 1) + 1]) break;
              uVar42 = uVar36;
              if ((int)uVar45 != 1) {
                uVar42 = (ulonglong)
                         (*(ushort *)
                           (pbVar32 +
                           uVar45 * 2 + ((ulonglong)*(uint *)(&stack0x0000053c + lVar19) - 2)) &
                         0x7fff);
              }
              uVar49 = *(ushort *)
                        (pbVar32 + uVar45 * 2 + (ulonglong)*(uint *)(&stack0x0000053c + lVar19)) &
                       0x7fff;
              uVar43 = (uint)uVar42;
              if (((uVar43 < (uint)uVar36) || (uVar49 < uVar43)) || ((uint)uVar25 < uVar49)) {
                *(undefined8 *)(puVar40 + -8) = 0x10311a;
                func_0x(pbVar32,7);
                sVar33 = *(short *)(&stack0x00000544 + lVar19);
                uVar36 = (ulonglong)*(uint *)(&stack0x00000540 + lVar19);
                pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
              }
              uVar34 = (uint)uVar25;
              if ((uVar43 < (uint)uVar36) || (uVar34 < uVar43)) goto LAB_;
              if (*(ushort *)(pbVar32 + uVar42) == 5) {
                *(ushort *)(&stack0x0000052a + lVar19) = *(ushort *)(&stack0x0000052a + lVar19) | 2;
                *(short *)(&stack0x00000544 + lVar19) = sVar33 + -1;
                uVar45 = uVar42 & 0xffff;
                *(short *)(&stack0x00000552 + lVar19) = (short)uVar42;
                pbVar38 = pbVar32 + uVar45;
                uVar13 = *(ushort *)(&stack0x00000554 + lVar19);
                if ((*(ushort *)(pbVar38 + 2) >> 0xe & 1) == 0) {
                  uVar13 = uVar13 & 0xc7ff;
                }
                else {
                  uVar13 = uVar13 ^ (uVar13 ^ *(ushort *)(pbVar38 + 2)) & 0x3800;
                }
                *(ushort *)(&stack0x00000554 + lVar19) = uVar13;
                uVar14 = (uVar13 ^ *(ushort *)(pbVar38 + 2)) & 0x7ff ^ uVar13;
                *(ushort *)(&stack0x00000554 + lVar19) = uVar14;
                pbVar37 = pbVar32 + (ulonglong)((uVar14 & 0x7ff) * 2) + 4 +
                                    uVar45 + (uVar13 >> 0xb & 7) * 2;
                if (pbVar37 < pbVar38) {
                  *(undefined8 *)(puVar40 + -8) = 0x103236;
                  func_0x(pbVar38,0x19);
                  uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                  uVar45 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                  pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                  *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                  uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                }
                if (uVar49 - uVar43 <
                    (((*(uint *)(&stack0x00000554 + lVar19) & 0x7ff) * 2 - (int)uVar45) -
                    *(int *)(&stack0x00000530 + lVar19)) + (int)pbVar37) {
                  *(undefined8 *)(puVar40 + -8) = 0x103285;
                  func_0x(pbVar32 + uVar45,0x19);
                  uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                  uVar45 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                  pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                  *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                  uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                }
                if ((uVar14 & 0x3800) != 0) {
                  puVar35 = (ushort *)(pbVar32 + uVar45 + 4);
                  iVar18 = 0;
                  if ((uVar14 & 0x3800) != 0) {
                    do {
                      if ((uVar14 & 0x7ff) < (*puVar35 & 0x7ff)) {
                        *(undefined8 *)(puVar40 + -8) = 0x1032f5;
                        func_0x(pbVar32 + uVar45,0x1a);
                        uVar14 = *(ushort *)(&stack0x00000554 + lVar19);
                        uVar45 = (ulonglong)*(ushort *)(&stack0x00000552 + lVar19);
                        pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
                      }
                      iVar18 = iVar18 + 1;
                      puVar35 = puVar35 + 1;
                    } while (iVar18 < (int)(*(uint *)(&stack0x00000554 + lVar19) >> 0xb & 7));
                    *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
                    uVar25 = (ulonglong)*(uint *)(&stack0x0000052c + lVar19);
                  }
                }
                break;
              }
              if (*(ushort *)(pbVar32 + uVar42) < 0x400) break;
              *(ushort *)(&stack0x0000052a + lVar19) = *(ushort *)(&stack0x0000052a + lVar19) | 1;
              uVar13 = sVar33 - 1;
              uVar45 = (ulonglong)uVar13;
              *(ushort *)(&stack0x00000544 + lVar19) = uVar13;
              if (uVar13 == 0) break;
            }
          }
          iVar18 = 0;
          if ((*pbVar32 & 0x40) == 0) {
            *(undefined4 *)(&stack0x0000054e + lVar19) = 0;
          }
          else {
            *(int *)(&stack0x0000054e + lVar19) = (int)uVar25;
            *(int *)(&stack0x0000052c + lVar19) = (int)uVar25 + 0xe;
            *(undefined8 *)(puVar40 + -8) = 0x103368;
            puVar24 = (ulonglong *)func_0x(&stack0x0000052a + lVar19);
            uVar14 = (ushort)(*puVar24 >> 0x30);
            uVar13 = uVar14;
            if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
              uVar13 = uVar14 & 0xdfff;
              if ((uVar14 >> 0xe & 1) != 0) {
                uVar13 = uVar14 | 0x2000;
              }
            }
            if (uVar13 == 0xfffc) {
              iVar18 = (int)((*puVar24 >> 0x20 & 0xffff) >> 5);
            }
            uVar25 = (ulonglong)(uint)(*(int *)(&stack0x0000052c + lVar19) + iVar18);
            *(int *)(&stack0x0000052c + lVar19) = *(int *)(&stack0x0000052c + lVar19) + iVar18;
            pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
            *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
          }
          uVar34 = (uint)uVar25;
          if ((*(byte **)(&stack0x00000546 + lVar19) != (byte *)0x0) &&
             (*(byte **)(&stack0x00000546 + lVar19) < pbVar32 + uVar25)) {
            *(undefined8 *)(puVar40 + -8) = 0x103408;
            cVar11 = func_0x(0x1fa68c0);
            if (cVar11 != '\0') {
              *(undefined8 *)(puVar40 + -8) = 0x103411;
              lVar22 = func_0x();
              if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                *(undefined8 *)(puVar40 + -8) = 0x10342b;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 == '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x103447;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar40 + 0x20) = 0;
                  *(undefined8 *)(puVar40 + -8) = 0x10346d;
                  (*_DAT_)(1,0x18962cc,0x19b63b8,0x886);
                }
              }
            }
            uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
            *(undefined8 *)(puVar40 + -8) = 0x10347e;
            func_0x(uVar30,0x12);
            pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
            *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
            uVar34 = *(uint *)(&stack0x0000052c + lVar19);
          }
          if (0x3f3b < uVar34 - 1) {
            *(undefined8 *)(puVar40 + -8) = 0x1034a9;
            cVar11 = func_0x(0x1fa68c0);
            if (cVar11 != '\0') {
              *(undefined8 *)(puVar40 + -8) = 0x1034b2;
              lVar22 = func_0x();
              if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                *(undefined8 *)(puVar40 + -8) = 0x1034cc;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 == '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x1034e8;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar40 + 0x20) = 0;
                  *(undefined8 *)(puVar40 + -8) = 0x10350e;
                  (*_DAT_)(1,0x18962cc,0x19b63b8,0x88b);
                }
              }
            }
            uVar30 = *(undefined8 *)(&stack0x00000530 + lVar19);
            *(undefined8 *)(puVar40 + -8) = 0x10351f;
            func_0x(uVar30,5);
            pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
            *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
            uVar34 = *(uint *)(&stack0x0000052c + lVar19);
          }
        }
LAB_:
        if (uVar34 < 9) {
          bVar31 = *pbVar32 & 0xe;
joined_r0x0010356e:
          if ((bVar31 == 0) || (bVar31 == 0xc)) {
            uVar34 = 9;
          }
        }
      }
      else {
        if (uVar34 == 0) {
          *(undefined8 *)(puVar40 + -8) = 0x103551;
          func_0x(&stack0x0000052a + lVar19);
          uVar34 = *(uint *)(&stack0x0000052c + lVar19);
        }
        pbVar32 = *(byte **)(&stack0x00000530 + lVar19);
        *(byte **)(&stack0x00000040 + lVar19) = pbVar32;
        if (uVar34 < 9) {
          bVar31 = *pbVar32 & 0x1c;
          goto joined_r0x0010356e;
        }
      }
      if (*(int *)(&stack0x0000008c + lVar19) == 0) goto LAB_;
    }
    iVar46 = 0;
    lVar22 = *(longlong *)(&stack0x00000098 + lVar19);
    iVar18 = *(int *)(*(longlong *)(lVar22 + 8) + 0x100);
    *(int *)(&stack0x000000a0 + lVar19) = iVar18;
    if (*(short *)(&stack0x00000048 + lVar19) == 0) {
      uVar43 = *(uint *)(&stack0x0000004c + lVar19);
      pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
      if (uVar43 == 0) {
        *(undefined2 *)(&stack0x0000004a + lVar19) = 0;
        uVar43 = *(uint *)(&stack0x00000058 + lVar19);
        uVar25 = (ulonglong)uVar43;
        *(uint *)(&stack0x0000005c + lVar19) = uVar43;
        if ((*pbVar38 & 0x10) != 0) {
          uVar43 = uVar43 + 2 + (*(ushort *)(pbVar38 + uVar25) + 7 >> 3);
          uVar25 = (ulonglong)uVar43;
          *(uint *)(&stack0x0000005c + lVar19) = uVar43;
        }
        if ((*pbVar38 & 0x20) == 0) {
          *(int *)(&stack0x0000004c + lVar19) = (int)uVar25;
          *(undefined2 *)(&stack0x00000064 + lVar19) = 0;
          *(int *)(&stack0x00000060 + lVar19) = (int)uVar25;
        }
        else {
          puVar35 = (ushort *)(pbVar38 + uVar25);
          *(ushort **)(&stack0x000000b0 + lVar19) = puVar35;
          uVar13 = *puVar35;
          *(ushort *)(&stack0x00000064 + lVar19) = uVar13;
          if (uVar13 == 0) {
            *(undefined8 *)(puVar40 + -8) = 0x10361a;
            cVar11 = func_0x(0x1fa68c0);
            if (cVar11 != '\0') {
              *(undefined8 *)(puVar40 + -8) = 0x103623;
              lVar22 = func_0x();
              if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                *(undefined8 *)(puVar40 + -8) = 0x10363d;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 == '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x103659;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar40 + 0x20) = 0;
                  *(undefined8 *)(puVar40 + -8) = 0x10367f;
                  (*_DAT_)(1,0x18962cc,0x19b63b8,0x80f);
                }
              }
            }
            uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
            *(undefined8 *)(puVar40 + -8) = 0x10368d;
            func_0x(uVar30,3);
            uVar13 = *(ushort *)(&stack0x00000064 + lVar19);
            pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
          }
          uVar43 = *(int *)(&stack0x0000005c + lVar19) + 2 + (uint)uVar13 * 2;
          *(uint *)(&stack0x00000060 + lVar19) = uVar43;
          if (0x1f9e < uVar43) {
            *(undefined8 *)(puVar40 + -8) = 0x1036c0;
            cVar11 = func_0x(0x1fa68c0);
            if (cVar11 != '\0') {
              *(undefined8 *)(puVar40 + -8) = 0x1036c9;
              lVar22 = func_0x();
              if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                *(undefined8 *)(puVar40 + -8) = 0x1036e3;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 == '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x1036ff;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar40 + 0x20) = 0;
                  *(undefined8 *)(puVar40 + -8) = 0x103725;
                  (*_DAT_)(1,0x18962cc,0x19b63b8,0x816);
                }
              }
            }
            uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
            *(undefined8 *)(puVar40 + -8) = 0x103733;
            func_0x(uVar30,4);
            uVar13 = *(ushort *)(&stack0x00000064 + lVar19);
            uVar43 = *(uint *)(&stack0x00000060 + lVar19);
            pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
          }
          uVar45 = (ulonglong)uVar13;
          uVar49 = puVar35[uVar45] & 0x7fff;
          *(uint *)(&stack0x0000004c + lVar19) = uVar49;
          if (uVar49 < uVar43) {
            *(undefined8 *)(puVar40 + -8) = 0x103768;
            cVar11 = func_0x(0x1fa68c0);
            if (cVar11 != '\0') {
              *(undefined8 *)(puVar40 + -8) = 0x103771;
              lVar22 = func_0x();
              if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                *(undefined8 *)(puVar40 + -8) = 0x10378b;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 == '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x1037a7;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar40 + 0x20) = 0;
                  *(undefined8 *)(puVar40 + -8) = 0x1037cd;
                  (*_DAT_)(1,0x18962cc,0x19b63b8,0x81d);
                }
              }
            }
            uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
            *(undefined8 *)(puVar40 + -8) = 0x1037db;
            func_0x(uVar30,4);
            uVar45 = (ulonglong)*(ushort *)(&stack0x00000064 + lVar19);
            uVar43 = *(uint *)(&stack0x00000060 + lVar19);
            pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
            uVar49 = *(uint *)(&stack0x0000004c + lVar19);
          }
          uVar25 = (ulonglong)uVar49;
          if ((short)uVar45 != 0) {
            do {
              puVar35 = puVar35 + 1;
              uVar49 = *puVar35 & 0x7fff;
              if ((uVar49 < uVar43) || ((uint)uVar25 < uVar49)) {
                *(undefined8 *)(puVar40 + -8) = 0x103825;
                cVar11 = func_0x(0x1fa68c0);
                if (cVar11 != '\0') {
                  *(undefined8 *)(puVar40 + -8) = 0x10382e;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar40 + -8) = 0x103848;
                    cVar11 = func_0x(0x1fa68c0);
                    if (cVar11 == '\0') {
                      *(undefined8 *)(puVar40 + -8) = 0x103864;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar40 + 0x20) = 0;
                      *(undefined8 *)(puVar40 + -8) = 0x103888;
                      (*_DAT_)(1,0x18962cc,0x19b63b8,0x82a);
                    }
                  }
                }
                uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
                *(undefined8 *)(puVar40 + -8) = 0x103896;
                func_0x(uVar30,4);
                uVar45 = (ulonglong)*(ushort *)(&stack0x00000064 + lVar19);
                pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
              }
              iVar46 = iVar46 + 1;
              uVar43 = uVar49;
            } while (iVar46 < (int)uVar45);
            uVar43 = *(uint *)(&stack0x00000060 + lVar19);
            pbVar32 = *(byte **)(&stack0x00000040 + lVar19);
            puVar35 = *(ushort **)(&stack0x000000b0 + lVar19);
          }
          while( true ) {
            sVar33 = (short)uVar45;
            if (-1 < (short)puVar35[(ulonglong)((int)uVar45 - 1) + 1]) break;
            uVar49 = uVar43;
            if ((int)uVar45 != 1) {
              uVar49 = *(ushort *)
                        (pbVar38 +
                        uVar45 * 2 + ((ulonglong)*(uint *)(&stack0x0000005c + lVar19) - 2)) & 0x7fff
              ;
            }
            uVar50 = *(ushort *)
                      (pbVar38 + uVar45 * 2 + (ulonglong)*(uint *)(&stack0x0000005c + lVar19)) &
                     0x7fff;
            if (((uVar49 < uVar43) || (uVar50 < uVar49)) || ((uint)uVar25 < uVar50)) {
              *(undefined8 *)(puVar40 + -8) = 0x10392a;
              func_0x(pbVar38,7);
              sVar33 = *(short *)(&stack0x00000064 + lVar19);
              uVar43 = *(uint *)(&stack0x00000060 + lVar19);
              pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
              uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
            }
            if ((uVar49 < uVar43) || ((uint)uVar25 < uVar49)) goto LAB_;
            if (*(ushort *)(pbVar38 + uVar49) == 5) {
              *(ushort *)(&stack0x0000004a + lVar19) = *(ushort *)(&stack0x0000004a + lVar19) | 2;
              *(short *)(&stack0x00000064 + lVar19) = sVar33 + -1;
              uVar45 = (ulonglong)(uVar49 & 0xffff);
              *(short *)(&stack0x00000072 + lVar19) = (short)uVar49;
              pbVar37 = pbVar38 + uVar45;
              uVar13 = *(ushort *)(&stack0x00000074 + lVar19);
              if ((*(ushort *)(pbVar37 + 2) >> 0xe & 1) == 0) {
                uVar13 = uVar13 & 0xc7ff;
              }
              else {
                uVar13 = uVar13 ^ (*(ushort *)(pbVar37 + 2) ^ uVar13) & 0x3800;
              }
              *(ushort *)(&stack0x00000074 + lVar19) = uVar13;
              uVar14 = (uVar13 ^ *(ushort *)(pbVar37 + 2)) & 0x7ff ^ uVar13;
              *(ushort *)(&stack0x00000074 + lVar19) = uVar14;
              pbVar48 = pbVar38 + uVar45 + (ulonglong)((uVar14 & 0x7ff) * 2) + 4 +
                                           (ulonglong)((uVar13 >> 0xb & 7) * 2);
              if (pbVar48 < pbVar37) {
                *(undefined8 *)(puVar40 + -8) = 0x103a9e;
                func_0x(pbVar37,0x19);
                uVar14 = *(ushort *)(&stack0x00000074 + lVar19);
                uVar45 = (ulonglong)*(ushort *)(&stack0x00000072 + lVar19);
                pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
              }
              if (uVar50 - uVar49 <
                  (((*(uint *)(&stack0x00000074 + lVar19) & 0x7ff) * 2 - (int)uVar45) -
                  *(int *)(&stack0x00000050 + lVar19)) + (int)pbVar48) {
                *(undefined8 *)(puVar40 + -8) = 0x103ada;
                func_0x(pbVar38 + uVar45,0x19);
                uVar14 = *(ushort *)(&stack0x00000074 + lVar19);
                uVar45 = (ulonglong)*(ushort *)(&stack0x00000072 + lVar19);
                pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
              }
              iVar16 = 0;
              if (((uVar14 & 0x3800) != 0) &&
                 (puVar35 = (ushort *)(pbVar38 + uVar45 + 4), (uVar14 & 0x3800) != 0)) {
                do {
                  if ((uVar14 & 0x7ff) < (*puVar35 & 0x7ff)) {
                    *(undefined8 *)(puVar40 + -8) = 0x103b45;
                    func_0x(pbVar38 + uVar45,0x1a);
                    uVar14 = *(ushort *)(&stack0x00000074 + lVar19);
                    uVar45 = (ulonglong)*(ushort *)(&stack0x00000072 + lVar19);
                    pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
                  }
                  iVar16 = iVar16 + 1;
                  puVar35 = puVar35 + 1;
                } while (iVar16 < (int)(*(uint *)(&stack0x00000074 + lVar19) >> 0xb & 7));
                uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
              }
              break;
            }
            if (*(ushort *)(pbVar38 + uVar49) < 0x400) break;
            *(ushort *)(&stack0x0000004a + lVar19) = *(ushort *)(&stack0x0000004a + lVar19) | 1;
            uVar13 = sVar33 - 1;
            uVar45 = (ulonglong)uVar13;
            *(ushort *)(&stack0x00000064 + lVar19) = uVar13;
            if (uVar13 == 0) break;
          }
        }
        iVar16 = 0;
        if ((*pbVar38 & 0x40) == 0) {
          *(undefined4 *)(&stack0x0000006e + lVar19) = 0;
        }
        else {
          *(int *)(&stack0x0000006e + lVar19) = (int)uVar25;
          *(int *)(&stack0x0000004c + lVar19) = (int)uVar25 + 0xe;
          *(undefined8 *)(puVar40 + -8) = 0x10399d;
          puVar24 = (ulonglong *)func_0x(&stack0x0000004a + lVar19);
          uVar14 = (ushort)(*puVar24 >> 0x30);
          uVar13 = uVar14;
          if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
            uVar13 = uVar14 & 0xdfff;
            if ((uVar14 >> 0xe & 1) != 0) {
              uVar13 = uVar14 | 0x2000;
            }
          }
          if (uVar13 == 0xfffc) {
            iVar16 = (int)((*puVar24 >> 0x20 & 0xffff) >> 5);
          }
          uVar25 = (ulonglong)(uint)(*(int *)(&stack0x0000004c + lVar19) + iVar16);
          *(int *)(&stack0x0000004c + lVar19) = *(int *)(&stack0x0000004c + lVar19) + iVar16;
          pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
        }
        if ((*(byte **)(&stack0x00000066 + lVar19) != (byte *)0x0) &&
           (*(byte **)(&stack0x00000066 + lVar19) < pbVar38 + uVar25)) {
          *(undefined8 *)(puVar40 + -8) = 0x103baf;
          cVar11 = func_0x(0x1fa68c0);
          if (cVar11 != '\0') {
            *(undefined8 *)(puVar40 + -8) = 0x103bb8;
            lVar22 = func_0x();
            if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
              *(undefined8 *)(puVar40 + -8) = 0x103bd2;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 == '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x103bee;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar40 + 0x20) = 0;
                *(undefined8 *)(puVar40 + -8) = 0x103c14;
                (*_DAT_)(1,0x18962cc,0x19b63b8,0x886);
              }
            }
          }
          uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
          *(undefined8 *)(puVar40 + -8) = 0x103c22;
          func_0x(uVar30,0x12);
          pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
          uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
        }
        if (0x3f3b < (int)uVar25 - 1U) {
          *(undefined8 *)(puVar40 + -8) = 0x103c45;
          cVar11 = func_0x(0x1fa68c0);
          if (cVar11 != '\0') {
            *(undefined8 *)(puVar40 + -8) = 0x103c4e;
            lVar22 = func_0x();
            if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
              *(undefined8 *)(puVar40 + -8) = 0x103c68;
              cVar11 = func_0x(0x1fa68c0);
              if (cVar11 == '\0') {
                *(undefined8 *)(puVar40 + -8) = 0x103c84;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar40 + 0x20) = 0;
                *(undefined8 *)(puVar40 + -8) = 0x103caa;
                (*_DAT_)(1,0x18962cc,0x19b63b8,0x88b);
              }
            }
          }
          uVar30 = *(undefined8 *)(&stack0x00000050 + lVar19);
          *(undefined8 *)(puVar40 + -8) = 0x103cb8;
          func_0x(uVar30,5);
          pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
          uVar25 = (ulonglong)*(uint *)(&stack0x0000004c + lVar19);
        }
LAB_:
        uVar43 = (uint)uVar25;
        lVar22 = *(longlong *)(&stack0x00000098 + lVar19);
        iVar18 = *(int *)(&stack0x000000a0 + lVar19);
      }
      if ((8 < uVar43) || (((*pbVar38 & 0xe) != 0 && ((*pbVar38 & 0xe) != 0xc)))) {
        *(uint *)(&stack0x00000084 + lVar19) = uVar43;
      }
      iVar16 = *(int *)(&stack0x000000c0 + lVar19);
    }
    else {
      uVar43 = *(uint *)(&stack0x0000004c + lVar19);
      if (uVar43 == 0) {
        *(undefined8 *)(puVar40 + -8) = 0x103cf6;
        func_0x(&stack0x0000004a + lVar19);
        uVar43 = *(uint *)(&stack0x0000004c + lVar19);
        lVar22 = *(longlong *)(&stack0x00000098 + lVar19);
      }
      pbVar38 = *(byte **)(&stack0x00000050 + lVar19);
      if ((uVar43 < 9) && (((*pbVar38 & 0x1c) == 0 || ((*pbVar38 & 0x1c) == 0xc)))) {
        *(undefined4 *)(&stack0x00000084 + lVar19) = 9;
      }
      else {
        *(uint *)(&stack0x00000084 + lVar19) = uVar43;
      }
    }
    uVar6 = *(uint6 *)(lVar22 + 0x14);
    plVar20 = *(longlong **)(&stack0x00000110 + lVar19);
    pcVar4 = *(code **)(*plVar20 + 8);
    *(undefined8 *)(puVar40 + -8) = 0x103d42;
    cVar11 = (*pcVar4)(plVar20);
    if (cVar11 == '\0') {
      *(undefined8 *)(puVar40 + 0x20) = 0;
      *(undefined8 *)(puVar40 + -8) = 0x103d6a;
      (*_DAT_)(1,0x1a69950,0x1a1d1a0,0xf27);
    }
    *(undefined8 *)(puVar40 + -8) = 0x103d7c;
    func_0x(plVar20,(ulonglong)uVar6 << 0x10,1);
    *(undefined4 *)(&stack0x000000f8 + lVar19) = *(undefined4 *)(&stack0x000000f8 + lVar19);
    *(undefined2 *)(&stack0x000000fc + lVar19) = *(undefined2 *)(&stack0x0000011a + lVar19);
    *(undefined4 *)(puVar40 + 0x40) = *(undefined4 *)(&stack0x00000108 + lVar19);
    *(undefined **)(puVar40 + 0x38) = &stack0x000000f8 + lVar19;
    *(int *)(puVar40 + 0x30) = iVar16;
    puVar40[0x28] = iVar18 == 2;
    *(undefined4 *)(puVar40 + 0x20) = *(undefined4 *)(&stack0x00000084 + lVar19);
    lVar22 = plVar20[0x44d];
    *(undefined8 *)(puVar40 + -8) = 0x103dd9;
    iVar16 = func_0x(lVar22,pbVar32,uVar34,pbVar38);
    *(int *)(&stack0x000000cc + lVar19) = iVar16;
  }
LAB_:
  if ((&stack0x00000092)[lVar19] == '\0') {
    pcVar4 = *(code **)(**(longlong **)(&stack0x00000128 + lVar19) + 0x28);
    *(undefined8 *)(puVar40 + -8) = 0x1088b1;
    (*pcVar4)();
  }
  if (((iVar16 - 1U & 0xfffffffc) != 0) || (iVar16 == 3)) {
    if ((_DAT_ & 0x4000000) != 0) {
      *(undefined4 *)(&stack0x000002c0 + lVar19) = 0x10000;
      *(undefined4 *)(&stack0x000002c8 + lVar19) = 0;
      *(undefined **)(&stack0x000002d0 + lVar19) = &stack0x000002e8 + lVar19;
      *(undefined **)(&stack0x000002d8 + lVar19) = &stack0x000002f8 + lVar19;
      *(undefined8 *)(&stack0x00000508 + lVar19) = 0;
      *(undefined8 *)(&stack0x000002e0 + lVar19) = 0;
      *(undefined8 *)(&stack0x00000510 + lVar19) = 0;
      *(undefined **)(&stack0x000002e8 + lVar19) = &stack0x00000518 + lVar19;
      *(undefined8 *)(&stack0x000002f0 + lVar19) = 8;
      *(undefined2 *)(&stack0x00000518 + lVar19) =
           *(undefined2 *)(*(longlong *)(&stack0x00000168 + lVar19) + 0x6b8);
      *(undefined4 *)(&stack0x0000051a + lVar19) =
           *(undefined4 *)(*(longlong *)(&stack0x000000a8 + lVar19) + 0x100);
      *(undefined2 *)(&stack0x0000051e + lVar19) =
           *(undefined2 *)(*(longlong *)(&stack0x000000a8 + lVar19) + 0x104);
      *(undefined8 *)(puVar40 + -8) = 0x108977;
      func_0x(&stack0x000002b8 + lVar19);
    }
    lVar22 = *(longlong *)(&stack0x00000168 + lVar19);
    plVar20 = (longlong *)(lVar22 + 0x1f0);
    *plVar20 = *plVar20 + 1;
    if ((&stack0x00000088)[lVar19] != '\0') {
      plVar20 = (longlong *)(lVar22 + 0x3d8);
      *plVar20 = *plVar20 + 1;
    }
  }
  puVar23 = *(undefined8 **)(&stack0x00000128 + lVar19);
  if (puVar23 != (undefined8 *)0x0) {
    pcVar4 = *(code **)*puVar23;
    *(undefined8 *)(puVar40 + -8) = 0x1089f7;
    (*pcVar4)(puVar23,1);
  }
  param_1 = *(longlong **)(&stack0x000000a8 + lVar19);
LAB_:
  pcVar4 = *(code **)(*param_1 + 8);
  *(undefined8 *)(puVar40 + -8) = 0x108a05;
  (*pcVar4)(param_1);
LAB_:
  uVar25 = *(ulonglong *)(&stack0x00005158 + lVar19);
  *(undefined8 *)(puVar40 + -8) = 0x108a17;
  func_0x(uVar25 ^ (ulonglong)pcVar1);
  return;
}

