
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 *param_2,longlong *param_3,undefined8 param_4)

{
  int *piVar1;
  short *psVar2;
  undefined4 uVar3;
  code *pcVar4;
  longlong *plVar5;
  ushort *puVar6;
  byte bVar7;
  char cVar8;
  byte bVar9;
  undefined uVar10;
  ushort uVar11;
  undefined2 uVar12;
  ushort uVar13;
  short sVar14;
  int iVar15;
  uint uVar16;
  int iVar17;
  uint uVar18;
  undefined4 uVar19;
  longlong lVar20;
  short *psVar21;
  undefined2 *puVar22;
  undefined8 uVar23;
  longlong lVar24;
  longlong lVar25;
  undefined4 *puVar26;
  byte *pbVar27;
  undefined *puVar28;
  undefined8 *puVar29;
  undefined8 *puVar30;
  longlong **pplVar31;
  undefined8 uVar32;
  undefined8 uVar33;
  undefined8 uVar34;
  undefined8 uVar35;
  uint uVar36;
  longlong lVar37;
  uint uVar38;
  uint uVar39;
  uint uVar40;
  uint uVar41;
  int iVar42;
  ulonglong uVar43;
  byte *pbVar44;
  ushort *puVar45;
  int *piVar46;
  ulonglong uVar47;
  uint *puVar48;
  ulonglong uVar49;
  undefined *puVar50;
  undefined *puVar51;
  byte *pbVar52;
  longlong *plVar53;
  ushort uVar54;
  byte *pbVar55;
  undefined2 *puVar56;
  short *psVar57;
  ulonglong uVar58;
  char *pcVar59;
  ushort *puVar60;
  longlong lVar61;
  bool bVar62;
  short sStackX_10;
  ushort uStackX_12;
  uint uStackX_14;
  byte *pbStackX_18;
  undefined8 uStackX_20;
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar20 = func_0x();
  lVar20 = -lVar20;
  puVar50 = &stack0xffffffffffffffc0 + lVar20;
  puVar51 = &stack0xffffffffffffffc0 + lVar20;
  puVar28 = &stack0xffffffffffffffc0 + lVar20;
  psVar2 = (short *)((longlong)&sStackX_10 + lVar20);
  *(undefined8 *)(&stack0x000002d8 + lVar20) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x000067e0 + lVar20) = _DAT_ ^ (ulonglong)psVar2;
  *(undefined8 *)(&stack0x00000170 + lVar20) = param_4;
  *(longlong **)(&stack0x00000050 + lVar20) = param_3;
  *(undefined8 **)(&stack0x00000100 + lVar20) = param_2;
  *(longlong *)(&stack0x00000168 + lVar20) = param_1;
  lVar25 = *param_3;
  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100075;
  func_0x(&stack0x00000298 + lVar20,param_1,2);
  lVar24 = **(longlong **)(param_1 + 0x2e0);
  *(longlong *)(&stack0x00000090 + lVar20) = lVar24;
  puVar29 = (undefined8 *)0x0;
  uVar36 = 0;
  if (((*(byte *)(*(longlong *)(**(longlong **)(*(uint **)(param_1 + 0x108) + 8) + 8) + 0x107) &
       0x40) == 0) ||
     (uVar40 = **(uint **)(param_1 + 0x108), *(undefined4 *)(&stack0x000000ac + lVar20) = 1,
     (uVar40 & 0x1000000) != 0)) {
    *(undefined4 *)(&stack0x000000ac + lVar20) = 0;
  }
  *psVar2 = -1;
  *(undefined8 *)((longlong)&pbStackX_18 + lVar20) = 0;
  *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = 0;
  *(undefined8 *)(&stack0x0000002e + lVar20) = 0;
  *(undefined8 *)(&stack0x00000038 + lVar20) = 0;
  *(undefined8 *)((longlong)&uStackX_20 + lVar20) = 0;
  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1000f0;
  func_0x(&stack0x000028a0 + lVar20,0);
  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100101;
  iVar15 = func_0x(param_2,*(undefined4 *)(&stack0x000000ac + lVar20));
  if (iVar15 == 0x40f02) {
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100111;
    func_0x(param_2 + 6);
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10011d;
    func_0x(param_2 + 0x56);
    *(undefined4 *)((longlong)param_2 + 0x634) = 1;
    puVar51 = &stack0xffffffffffffffc0 + lVar20;
    if (*(undefined8 **)(&stack0x00000170 + lVar20) != (undefined8 *)0x0) {
      **(undefined8 **)(&stack0x00000170 + lVar20) = 0;
      puVar51 = &stack0xffffffffffffffc0 + lVar20;
    }
    goto LAB_;
  }
  if ((*(byte *)(lVar25 + 0x38) & 2) == 0) {
    *(undefined8 *)(&stack0x00000280 + lVar20) = *(undefined8 *)(*(longlong *)(param_1 + 0x2e0) + 8)
    ;
    lVar25 = *(longlong *)(&stack0x00000168 + lVar20);
    uVar40 = *(uint *)(lVar25 + 0x25c);
    if (((param_2 != (undefined8 *)0x0) && (*(int *)(param_2 + 1) == 1)) &&
       (*(char *)(param_2[5] + 0xb5) != '\0')) {
      *(uint *)((longlong)param_2 + 0x634) = *(uint *)((longlong)param_2 + 0x634) & 0xfffffffe;
    }
    if ((*(byte *)(*param_3 + 0x38) & 0x20) == 0) {
      puVar30 = puVar29;
      if ((param_2 != (undefined8 *)0x0) && (*(int *)(param_2 + 1) == 1)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1001af;
        func_0x(param_2);
        puVar30 = param_2;
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1001be;
      func_0x(&stack0x00000278 + lVar20,puVar30);
      pcVar4 = *(code **)*param_2;
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1001c7;
      psVar21 = (short *)(*pcVar4)(param_2);
      pcVar4 = *(code **)*param_2;
      if (*psVar21 != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1089ae;
        psVar21 = (short *)(*pcVar4)(param_2);
        *(short **)(&stack0x00000070 + lVar20) = psVar21;
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1089bd;
        lVar25 = func_0x(param_3);
        *(longlong *)(&stack0x00000060 + lVar20) = lVar25;
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1089cc;
        iVar15 = func_0x(lVar25);
        if (iVar15 != 0) goto LAB_;
        puVar45 = (ushort *)(psVar21 + 1);
        if (*psVar21 == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1089e5;
          iVar15 = func_0x();
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1089ec;
          iVar15 = func_0x(puVar45);
        }
        if (iVar15 == 0) {
LAB_:
          bVar62 = false;
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1089f8;
          iVar15 = func_0x(psVar21);
          if (iVar15 == 0) goto LAB_;
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108a0b;
          uVar23 = func_0x(psVar21,&stack0x000002b8 + lVar20);
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108a13;
          iVar15 = func_0x(uVar23);
          if (iVar15 == 0) goto LAB_;
          bVar62 = true;
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108a27;
        iVar15 = func_0x(lVar25);
        uVar40 = 0;
        if (iVar15 == 0) {
          if (*psVar21 == 0) {
            iVar15 = *(int *)(psVar21 + 8);
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108a41;
            iVar15 = func_0x(puVar45);
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108a4c;
          iVar42 = func_0x(lVar25 + 0x10);
          if (iVar15 != iVar42) goto LAB_;
          if (*psVar21 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108a62;
            pbVar27 = (byte *)func_0x(puVar45);
            if ((*pbVar27 & 0x10) != 0) {
              uVar36 = (uint)*(ushort *)
                              ((ulonglong)*(uint *)(psVar21 + 8) + *(longlong *)(psVar21 + 4));
            }
          }
          else {
            uVar36 = (uint)*puVar45;
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108a88;
          lVar24 = func_0x(*(undefined8 *)(&stack0x00000090 + lVar20));
          if ((uVar36 != *(ushort *)(lVar24 + 0x2c)) || (bVar62)) goto LAB_;
          sVar14 = *psVar21;
          *psVar2 = sVar14;
          if (sVar14 == 0) {
            uVar36 = *(uint *)(psVar21 + 2);
            if (uVar36 == 0) {
              *puVar45 = 0;
              *(undefined4 *)(psVar21 + 10) = *(undefined4 *)(psVar21 + 8);
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108ad0;
              pbVar27 = (byte *)func_0x(puVar45);
              if ((*pbVar27 & 0x10) != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108add;
                pbVar27 = (byte *)func_0x(puVar45);
                if ((*pbVar27 & 0x10) != 0) {
                  uVar40 = (uint)*(ushort *)
                                  ((ulonglong)*(uint *)(psVar21 + 8) + *(longlong *)(psVar21 + 4));
                }
                *(uint *)(psVar21 + 10) = *(int *)(psVar21 + 10) + (uVar40 + 7 >> 3) + 2;
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108b06;
              pbVar27 = (byte *)func_0x(puVar45);
              if ((*pbVar27 & 0x20) == 0) {
                *(undefined4 *)(psVar21 + 2) = *(undefined4 *)(psVar21 + 10);
                psVar21[0xe] = 0;
                *(undefined4 *)(psVar21 + 0xc) = *(undefined4 *)(psVar21 + 10);
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108b17;
                puVar45 = (ushort *)func_0x(puVar45);
                uVar11 = *puVar45;
                psVar21[0xe] = uVar11;
                if (uVar11 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108b32;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108b3b;
                    cVar8 = func_0x();
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108b4b;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108b67;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108b8b;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)(psVar21 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108b99;
                  func_0x(uVar23,3);
                  uVar11 = psVar21[0xe];
                }
                uVar36 = *(int *)(psVar21 + 10) + 2 + (uint)uVar11 * 2;
                *(uint *)(psVar21 + 0xc) = uVar36;
                if (0x1f9e < uVar36) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108bc0;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108bc9;
                    cVar8 = func_0x();
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108bd9;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108bf5;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108c19;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)(psVar21 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108c27;
                  func_0x(uVar23,4);
                  uVar11 = psVar21[0xe];
                }
                puVar45 = puVar45 + 1;
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108c3d;
                uVar11 = func_0x(puVar45,(ulonglong)uVar11 - 1);
                *(uint *)(psVar21 + 2) = (uint)uVar11;
                uVar36 = *(uint *)(psVar21 + 0xc);
                if (uVar11 < uVar36) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108c58;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108c61;
                    cVar8 = func_0x();
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108c71;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108c8d;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108cb7;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)(psVar21 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108cc5;
                  func_0x(uVar23,4);
                  uVar36 = *(uint *)(psVar21 + 0xc);
                }
                iVar15 = 0;
                uVar11 = psVar21[0xe];
                if (uVar11 != 0) {
                  do {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108ceb;
                    uVar11 = func_0x(puVar45,(longlong)iVar15);
                    bVar62 = uVar11 < uVar36;
                    uVar36 = (uint)uVar11;
                    if ((bVar62) ||
                       (*(uint *)(psVar21 + 2) <= (uint)uVar11 && uVar36 != *(uint *)(psVar21 + 2)))
                    {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108d06;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108d0f;
                        cVar8 = func_0x();
                        if (cVar8 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108d1f;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108d3b;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108d5f;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                          }
                        }
                      }
                      uVar23 = *(undefined8 *)(psVar21 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108d6d;
                      func_0x(uVar23,4);
                    }
                    iVar15 = iVar15 + 1;
                    uVar11 = psVar21[0xe];
                  } while (iVar15 < (int)(uint)uVar11);
                  lVar25 = *(longlong *)(&stack0x00000060 + lVar20);
                }
                puVar60 = (ushort *)(psVar21 + 1);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108d93;
                iVar15 = func_0x(puVar45,uVar11 - 1);
                while (iVar15 != 0) {
                  uVar11 = psVar21[0xe];
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108dac;
                  lVar24 = func_0x(puVar60);
                  if (uVar11 == 1) {
                    uVar40 = *(uint *)(psVar21 + 0xc);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108dc9;
                    uVar54 = func_0x(lVar24 + 2,(ulonglong)uVar11 - 2);
                    uVar40 = (uint)uVar54;
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108dd9;
                  uVar11 = func_0x(lVar24 + 2,(ulonglong)(uint)uVar11 - 1);
                  uVar18 = *(uint *)(psVar21 + 0xc);
                  if (((uVar40 < uVar18) || (uVar11 < uVar40)) ||
                     (uVar36 = *(uint *)(psVar21 + 2), uVar36 <= uVar11 && uVar11 != uVar36)) {
                    uVar23 = *(undefined8 *)(psVar21 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108dff;
                    func_0x(uVar23,7);
                    uVar18 = *(uint *)(psVar21 + 0xc);
                    uVar36 = *(uint *)(psVar21 + 2);
                  }
                  if ((uVar40 < uVar18) || (uVar36 < uVar40)) goto LAB_;
                  if (*(ushort *)((ulonglong)uVar40 + *(longlong *)(psVar21 + 4)) == 5) {
                    *puVar60 = *puVar60 | 2;
                    psVar21[0xe] = psVar21[0xe] + -1;
                    psVar21[0x15] = (short)uVar40;
                    lVar24 = (ulonglong)(uVar40 & 0xffff) + *(longlong *)(psVar21 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108ec7;
                    iVar15 = func_0x(lVar24);
                    if (iVar15 == 0) {
                      psVar21[0x16] = psVar21[0x16] & 0xc7ff;
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108ed3;
                      uVar54 = func_0x(lVar24);
                      psVar21[0x16] = psVar21[0x16] & 0xc7ff;
                      psVar21[0x16] = psVar21[0x16] | (uVar54 & 7) << 0xb;
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108efb;
                    uVar54 = func_0x(lVar24);
                    psVar21[0x16] = psVar21[0x16] ^ (uVar54 ^ psVar21[0x16]) & 0x7ff;
                    uVar13 = psVar21[0x16];
                    uVar43 = *(ulonglong *)(psVar21 + 4);
                    uVar54 = psVar21[0x15];
                    uVar47 = (ulonglong)((uVar13 & 0x7ff) * 2) + 4 +
                             uVar43 + (uVar13 >> 0xb & 7) * 2 + (ulonglong)uVar54;
                    uVar58 = uVar43 + uVar54;
                    if (uVar47 < uVar58) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108f51;
                      func_0x(uVar58,0x19);
                      uVar13 = psVar21[0x16];
                      uVar54 = psVar21[0x15];
                      uVar43 = (ulonglong)*(uint *)(psVar21 + 4);
                    }
                    if (uVar11 - uVar40 <
                        (((uVar13 & 0x7ff) * 2 - (uint)uVar54) - (int)uVar43) + (int)uVar47) {
                      uVar11 = psVar21[0x15];
                      lVar24 = *(longlong *)(psVar21 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108f8d;
                      func_0x((ulonglong)uVar11 + lVar24,0x19);
                      uVar13 = psVar21[0x16];
                    }
                    if ((uVar13 & 0x3800) != 0) {
                      uVar11 = psVar21[0x15];
                      lVar24 = *(longlong *)(psVar21 + 4);
                      iVar15 = 0;
                      if ((uVar13 & 0x3800) != 0) {
                        do {
                          uVar54 = psVar21[0x16];
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108fd0;
                          uVar13 = func_0x((ulonglong)uVar11 + lVar24 + 4,iVar15);
                          if ((uVar54 & 0x7ff) < uVar13) {
                            uVar54 = psVar21[0x15];
                            lVar37 = *(longlong *)(psVar21 + 4);
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108fef;
                            func_0x((ulonglong)uVar54 + lVar37,0x1a);
                            uVar54 = psVar21[0x16];
                          }
                          iVar15 = iVar15 + 1;
                        } while (iVar15 < (int)(uVar54 >> 0xb & 7));
                      }
                    }
                    break;
                  }
                  if (*(ushort *)((ulonglong)uVar40 + *(longlong *)(psVar21 + 4)) < 0x400) break;
                  *puVar60 = *puVar60 | 1;
                  uVar11 = psVar21[0xe] - 1;
                  psVar21[0xe] = uVar11;
                  if (uVar11 == 0) break;
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108e51;
                  iVar15 = func_0x(puVar45,uVar11 - 1);
                }
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108e68;
              iVar15 = func_0x(psVar21 + 1);
              if (iVar15 == 0) {
                *(undefined4 *)(psVar21 + 0x13) = 0;
              }
              else {
                *(int *)(psVar21 + 0x13) = *(int *)(psVar21 + 2);
                *(int *)(psVar21 + 2) = *(int *)(psVar21 + 2) + 0xe;
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108e84;
                uVar23 = func_0x(psVar21 + 1);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108e93;
                func_0x(uVar23,&stack0x00000238 + lVar20);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x108e9f;
                iVar15 = func_0x(&stack0x00000238 + lVar20);
                *(int *)(psVar21 + 2) = *(int *)(psVar21 + 2) + iVar15;
              }
              uVar36 = *(uint *)(psVar21 + 2);
              if ((*(ulonglong *)(psVar21 + 0xf) != 0) &&
                 (*(ulonglong *)(psVar21 + 0xf) < (ulonglong)uVar36 + *(longlong *)(psVar21 + 4))) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109043;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10904c;
                  cVar8 = func_0x();
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10905c;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109078;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10909c;
                      (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
                    }
                  }
                }
                uVar23 = *(undefined8 *)(psVar21 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1090aa;
                func_0x(uVar23,0x12);
                uVar36 = *(uint *)(psVar21 + 2);
              }
              if ((uVar36 == 0) || (0x3f3c < uVar36)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1090c5;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1090ce;
                  cVar8 = func_0x();
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1090de;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1090fa;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10911e;
                      (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
                    }
                  }
                }
                uVar23 = *(undefined8 *)(psVar21 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10912c;
                func_0x(uVar23,5);
                uVar36 = *(uint *)(psVar21 + 2);
              }
            }
LAB_:
            psVar57 = psVar21 + 1;
            if (uVar36 < 9) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109142;
              cVar8 = func_0x(psVar57);
              if ((cVar8 == '\0') || (cVar8 == '\f')) {
                uVar36 = 9;
              }
              else {
                uVar36 = *(uint *)(psVar21 + 2);
              }
            }
            *(undefined4 *)((longlong)&uStackX_20 + lVar20) = *(undefined4 *)(psVar21 + 8);
            *(short *)((longlong)&sStackX_10 + lVar20 + 2) = *psVar57;
            *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = *(undefined4 *)(psVar21 + 2);
            *(short *)(&stack0x0000002c + lVar20) = psVar21[0xe];
            *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) = *(undefined4 *)(psVar21 + 10);
            *(undefined4 *)(&stack0x00000028 + lVar20) = *(undefined4 *)(psVar21 + 0xc);
            *(undefined4 *)(&stack0x00000036 + lVar20) = *(undefined4 *)(psVar21 + 0x13);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10918b;
            uVar23 = func_0x(psVar57);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1091a2;
            func_0x(&stack0x000028a0 + lVar20,0x3f3c,uVar23,uVar36);
            *(undefined **)((longlong)&pbStackX_18 + lVar20) = &stack0x000028a0 + lVar20;
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1091b6;
            iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if (iVar15 != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1091ce;
              uVar11 = func_0x
                                 ((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000140 + lVar20);
              uVar36 = *(uint *)(&stack0x00000140 + lVar20);
              *(ushort *)(&stack0x0000003a + lVar20) = uVar11;
              lVar24 = (ulonglong)uVar11 + *(longlong *)((longlong)&pbStackX_18 + lVar20);
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1091e7;
              iVar15 = func_0x(lVar24);
              if (iVar15 == 0) {
                *(ushort *)(&stack0x0000003c + lVar20) =
                     *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1091f3;
                sVar14 = func_0x(lVar24);
                *(ushort *)(&stack0x0000003c + lVar20) =
                     *(ushort *)(&stack0x0000003c + lVar20) ^
                     (sVar14 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109225;
              uVar54 = func_0x(lVar24);
              uVar11 = *(ushort *)(&stack0x0000003c + lVar20);
              uVar54 = (*(ushort *)(&stack0x0000003c + lVar20) ^ uVar54) & 0x7ff ^ uVar11;
              uVar43 = (ulonglong)uVar54;
              *(ushort *)(&stack0x0000003c + lVar20) = uVar54;
              uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
              lVar24 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
              uVar58 = (uVar11 >> 0xb & 7) * 2 + uVar47 + ((uVar43 & 0x7ff) + 2) * 2 + lVar24;
              if (uVar58 < lVar24 + uVar47) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109278;
                func_0x(lVar24 + uVar47,0x19);
                uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                lVar24 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
              }
              if (uVar36 < (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar47) -
                           *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)uVar58) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1092ae;
                func_0x(uVar47 + lVar24,0x19);
                uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                lVar24 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
              }
              iVar15 = 0;
              if (((uVar43 & 0x3800) != 0) && ((uVar43 & 0x3800) != 0)) {
                do {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1092ec;
                  uVar11 = func_0x(uVar47 + lVar24 + 4,iVar15);
                  if ((*(ushort *)(&stack0x0000003c + lVar20) & 0x7ff) < uVar11) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10930b;
                    func_0x((ulonglong)*(ushort *)(&stack0x0000003a + lVar20) +
                                    *(longlong *)((longlong)&pbStackX_18 + lVar20),0x1a);
                  }
                  iVar15 = iVar15 + 1;
                } while (iVar15 < (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7));
              }
            }
          }
          else {
            if (*psVar21 != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10932d;
              lVar24 = func_0x(puVar45);
              if (lVar24 != 0) {
                if (*psVar21 != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109345;
                  puVar29 = (undefined8 *)func_0x(puVar45);
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10934d;
                iVar15 = func_0x(puVar29);
                if (iVar15 != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10936a;
                  func_0x(psVar2,&stack0x000028a0 + lVar20,0x3f3c,psVar21);
                  goto LAB_;
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109385;
            func_0x((longlong)&sStackX_10 + lVar20 + 2,&stack0x000028a0 + lVar20,0x3f3c,
                            puVar45);
            if (*psVar21 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10939a;
              func_0x((longlong)&sStackX_10 + lVar20 + 2,0);
            }
            else {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1093a4;
              uVar23 = func_0x(puVar45);
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1093b0;
              func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar23);
            }
          }
LAB_:
          if (*psVar2 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1093cb;
            iVar15 = func_0x();
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1093d2;
            iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
          }
          if (iVar15 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1093df;
            func_0x(psVar2);
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1093e7;
          iVar15 = func_0x(lVar25);
          lVar25 = *(longlong *)(&stack0x00000050 + lVar20);
          if (iVar15 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109607;
            uVar23 = func_0x(lVar25);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10960f;
            uVar11 = func_0x(uVar23);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10961a;
            lVar24 = func_0x(lVar25);
            if (uVar11 != 0) {
              uVar58 = (ulonglong)uVar11;
              do {
                (&stack0x00000069)[lVar20] = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10964b;
                func_0x(lVar25,lVar24,&stack0x00000069 + lVar20);
                if ((&stack0x00000069)[lVar20] == '\x03') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109988;
                  iVar15 = func_0x(lVar24);
                  if (iVar15 == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10999f;
                    (*_DAT_)(6,0x51,0x10,1);
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1099a7;
                  uVar12 = func_0x(lVar24);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1099b2;
                  uVar23 = func_0x(lVar24);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1099c4;
                  func_0x(psVar2,uVar23,uVar12,1);
                }
                else {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10965d;
                  uVar23 = func_0x();
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109665;
                  sVar14 = func_0x(uVar23);
                  if (sVar14 != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109672;
                    uVar23 = func_0x(lVar24);
                    if (*psVar2 == 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109685;
                      func_0x();
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10968c;
                      func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar23);
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10969e;
                  func_0x(lVar25,lVar24,&stack0x00000108 + lVar20);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1096a6;
                  iVar15 = func_0x(lVar24);
                  if ((iVar15 == 1) || (iVar15 == 2)) {
                    lVar37 = *(longlong *)(&stack0x00000108 + lVar20);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1097ee;
                    iVar15 = func_0x(lVar24);
                    if (iVar15 == 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1097fa;
                      uVar12 = func_0x();
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109805;
                      uVar23 = func_0x(lVar24);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10980d;
                      iVar15 = func_0x(uVar23);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10981f;
                      func_0x
                                ((longlong)iVar15 + *(longlong *)((longlong)&pbStackX_18 + lVar20),
                                 lVar37,uVar12);
                    }
                    else {
                      iVar42 = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10982b;
                      iVar15 = func_0x(lVar24);
                      if ((iVar15 == 0) || ((*(byte *)(lVar25 + 0x14) & 8) == 0)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109859;
                        iVar15 = func_0x(lVar24);
                        if (iVar15 == 0) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109887;
                          uVar11 = func_0x(lVar24);
                          uVar36 = (uint)uVar11;
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109865;
                          uVar23 = func_0x();
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109873;
                          uVar32 = func_0x(lVar25,lVar24);
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10987e;
                          uVar36 = func_0x(uVar32,uVar23);
                        }
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10983e;
                        uVar36 = func_0x(lVar24);
                        uVar36 = *(uint *)((ulonglong)uVar36 * 8 + *(longlong *)(lVar25 + 0x38));
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109892;
                      uVar11 = func_0x(lVar24);
                      if (uVar36 < uVar11) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1098a1;
                        uVar11 = func_0x(lVar24);
                        iVar42 = uVar11 - uVar36;
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1098ad;
                        uVar11 = func_0x(lVar24);
                        if (uVar11 < uVar36) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1098c9;
                          (*_DAT_)(6,0x5c,0x16,1);
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1098d1;
                      uVar10 = func_0x(lVar24);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1098dd;
                      uVar23 = func_0x(lVar24);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1098e5;
                      iVar15 = func_0x(uVar23);
                      lVar25 = (longlong)iVar15 + *(longlong *)((longlong)&pbStackX_18 + lVar20);
                      if ((lVar37 != 0) && (uVar36 != 0)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109903;
                        func_0x(lVar25,lVar37,uVar36);
                      }
                      if (iVar42 != 0) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109917;
                        func_0x((ulonglong)uVar36 + lVar25,uVar10,iVar42);
                      }
                      lVar25 = *(longlong *)(&stack0x00000050 + lVar20);
                    }
                  }
                  else if ((iVar15 == 3) || (iVar15 == 4)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10971b;
                    iVar15 = func_0x(lVar24);
                    if ((iVar15 == 0) || (**(int **)(&stack0x00000108 + lVar20) != 0)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109738;
                      iVar15 = func_0x(lVar24);
                      if ((iVar15 == 0) || ((*(byte *)(lVar25 + 0x14) & 8) == 0)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109766;
                        iVar15 = func_0x(lVar24);
                        if (iVar15 == 0) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109794;
                          uVar11 = func_0x(lVar24);
                          uVar36 = (uint)uVar11;
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109772;
                          uVar23 = func_0x();
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109780;
                          uVar32 = func_0x(lVar25,lVar24);
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10978b;
                          uVar36 = func_0x(uVar32,uVar23);
                        }
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10974b;
                        uVar36 = func_0x(lVar24);
                        uVar36 = *(uint *)((ulonglong)uVar36 * 8 + *(longlong *)(lVar25 + 0x38));
                      }
                    }
                    else {
                      uVar36 = 0;
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10979f;
                    uVar11 = func_0x(lVar24);
                    if (uVar11 < uVar36) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1097bc;
                      (*_DAT_)(6,0x52,0x16,0x93);
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1097c4;
                    uVar23 = func_0x(lVar24);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1097da;
                    func_0x
                              (psVar2,uVar23,*(undefined8 *)(&stack0x00000108 + lVar20),uVar36);
                  }
                  else if (iVar15 == 8) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1096f8;
                    uVar23 = func_0x(lVar24);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10970e;
                    func_0x
                              (psVar2,uVar23,*(undefined8 *)(&stack0x00000108 + lVar20),1);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0x1525f20;
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1096eb;
                    (*_DAT_)(1,0x192c2b0,0x1958c78,0x380);
                  }
                }
                lVar24 = lVar24 + 0x50;
                uVar58 = uVar58 - 1;
              } while (uVar58 != 0);
            }
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1093fb;
            uVar23 = func_0x(lVar25);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109406;
            uVar11 = func_0x(uVar23);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109411;
            lVar24 = func_0x(uVar23);
            if (uVar11 != 0) {
              uVar58 = (ulonglong)uVar11;
              do {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10942d;
                cVar8 = func_0x(lVar25,lVar24);
                if (cVar8 == '\x03') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1095c3;
                  iVar15 = func_0x(lVar24);
                  if (iVar15 == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1095db;
                    (*_DAT_)(6,0x51,0x10,4);
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1095e3;
                  uVar12 = func_0x(lVar24);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1095ee;
                  uVar23 = func_0x(lVar24);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109600;
                  func_0x(psVar2,uVar23,uVar12,1);
                }
                else {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10943d;
                  uVar23 = func_0x();
                  if (*psVar2 == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109450;
                    func_0x();
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109457;
                    func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar23);
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109469;
                  func_0x(lVar25,lVar24,&stack0x00000240 + lVar20);
                  lVar37 = *(longlong *)(&stack0x00000240 + lVar20);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109478;
                  iVar15 = func_0x(lVar24);
                  if (iVar15 == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109484;
                    uVar12 = func_0x();
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10948f;
                    uVar23 = func_0x(lVar24);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109497;
                    iVar15 = func_0x(uVar23);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1094a9;
                    func_0x
                              ((longlong)iVar15 + *(longlong *)((longlong)&pbStackX_18 + lVar20),
                               lVar37,uVar12);
                  }
                  else {
                    iVar42 = 0;
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1094b5;
                    iVar15 = func_0x(lVar24);
                    if ((iVar15 == 0) || ((*(byte *)(lVar25 + 0x14) & 8) == 0)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1094e3;
                      iVar15 = func_0x(lVar24);
                      if (iVar15 == 0) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109511;
                        uVar11 = func_0x(lVar24);
                        uVar36 = (uint)uVar11;
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1094ef;
                        uVar23 = func_0x();
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1094fd;
                        uVar32 = func_0x(lVar25,lVar24);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109508;
                        uVar36 = func_0x(uVar32,uVar23);
                      }
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1094c8;
                      uVar36 = func_0x(lVar24);
                      uVar36 = *(uint *)((ulonglong)uVar36 * 8 + *(longlong *)(lVar25 + 0x38));
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10951c;
                    uVar11 = func_0x(lVar24);
                    if (uVar36 < uVar11) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10952b;
                      uVar11 = func_0x(lVar24);
                      iVar42 = uVar11 - uVar36;
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109537;
                      uVar11 = func_0x(lVar24);
                      if (uVar11 < uVar36) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109553;
                        (*_DAT_)(6,0x5c,0x16,1);
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10955b;
                    uVar10 = func_0x(lVar24);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109567;
                    uVar23 = func_0x(lVar24);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10956f;
                    iVar15 = func_0x(uVar23);
                    lVar25 = (longlong)iVar15 + *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    if ((lVar37 != 0) && (uVar36 != 0)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10958d;
                      func_0x(lVar25,lVar37,uVar36);
                    }
                    if (iVar42 != 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1095a1;
                      func_0x((ulonglong)uVar36 + lVar25,uVar10,iVar42);
                    }
                    lVar25 = *(longlong *)(&stack0x00000050 + lVar20);
                  }
                }
                lVar24 = lVar24 + 0x50;
                uVar58 = uVar58 - 1;
              } while (uVar58 != 0);
            }
          }
          if (*psVar2 == 0) {
            uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
            if (uVar36 == 0) {
              iVar15 = 0;
              *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
              *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                   *(undefined4 *)((longlong)&uStackX_20 + lVar20);
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109963;
              pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              uVar36 = 0;
              if ((*pbVar27 & 0x10) != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109971;
                pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if ((*pbVar27 & 0x10) != 0) {
                  uVar36 = (uint)*(ushort *)
                                  (*(longlong *)((longlong)&pbStackX_18 + lVar20) +
                                  (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20));
                }
                *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                     (uVar36 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1099e6;
              pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              if ((*pbVar27 & 0x20) == 0) {
                uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
                *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
                *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1099f8;
                puVar45 = (ushort *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                uVar11 = *puVar45;
                *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                if (uVar11 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109a16;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109a1f;
                    cVar8 = func_0x();
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109a2f;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109a4b;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109a71;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109a7f;
                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),3);
                  uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                }
                uVar36 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar11 * 2;
                *(uint *)(&stack0x00000028 + lVar20) = uVar36;
                if (0x1f9e < uVar36) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109aa8;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109ab1;
                    cVar8 = func_0x();
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109ac1;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109add;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109b03;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109b11;
                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                  uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                }
                puVar45 = puVar45 + 1;
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109b29;
                uVar11 = func_0x(puVar45,(ulonglong)uVar11 - 1);
                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar11;
                uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                if (uVar11 < uVar36) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109b42;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109b4b;
                    cVar8 = func_0x();
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109b5b;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109b77;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109b9d;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109bab;
                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                  uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                }
                uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                iVar42 = iVar15;
                if (uVar11 != 0) {
                  do {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109bdb;
                    uVar11 = func_0x(puVar45,(longlong)iVar42);
                    bVar62 = uVar11 < uVar36;
                    uVar36 = (uint)uVar11;
                    if ((bVar62) ||
                       (uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
                       uVar40 <= uVar11 && uVar36 != uVar40)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109bf3;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109bfc;
                        cVar8 = func_0x();
                        if (cVar8 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109c0c;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109c28;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109c4e;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109c5c;
                      func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                    }
                    iVar42 = iVar42 + 1;
                    uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                  } while (iVar42 < (int)(uint)uVar11);
                }
                while( true ) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109c7f;
                  iVar42 = func_0x(puVar45,uVar11 - 1);
                  if (iVar42 == 0) break;
                  uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109c94;
                  lVar25 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if (uVar11 == 1) {
                    uVar40 = *(uint *)(&stack0x00000028 + lVar20);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109cae;
                    uVar54 = func_0x(lVar25 + 2,(ulonglong)uVar11 - 2);
                    uVar40 = (uint)uVar54;
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109cbe;
                  uVar11 = func_0x(lVar25 + 2,(ulonglong)uVar11 - 1);
                  uVar18 = *(uint *)(&stack0x00000028 + lVar20);
                  if (((uVar40 < uVar18) || (uVar11 < uVar40)) ||
                     (uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
                     uVar36 <= uVar11 && uVar11 != uVar36)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109ce1;
                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),7);
                    uVar18 = *(uint *)(&stack0x00000028 + lVar20);
                    uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                  }
                  if ((uVar40 < uVar18) || (uVar36 < uVar40)) goto LAB_;
                  lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                  uVar54 = *(ushort *)(lVar25 + (ulonglong)uVar40);
                  if (uVar54 == 5) {
                    puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                    *puVar45 = *puVar45 | 2;
                    *(short *)(&stack0x0000002c + lVar20) =
                         *(short *)(&stack0x0000002c + lVar20) + -1;
                    *(short *)(&stack0x0000003a + lVar20) = (short)uVar40;
                    lVar25 = (ulonglong)(uVar40 & 0xffff) + lVar25;
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109d4f;
                    iVar42 = func_0x(lVar25);
                    if (iVar42 == 0) {
                      *(ushort *)(&stack0x0000003c + lVar20) =
                           *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109d5b;
                      sVar14 = func_0x(lVar25);
                      *(ushort *)(&stack0x0000003c + lVar20) =
                           *(ushort *)(&stack0x0000003c + lVar20) ^
                           (sVar14 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109d90;
                    uVar13 = func_0x(lVar25);
                    uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                    uVar13 = (*(ushort *)(&stack0x0000003c + lVar20) ^ uVar13) & 0x7ff ^ uVar54;
                    uVar43 = (ulonglong)uVar13;
                    *(ushort *)(&stack0x0000003c + lVar20) = uVar13;
                    uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                    lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    uVar58 = (uVar54 >> 0xb & 7) * 2 + uVar47 + ((uVar43 & 0x7ff) + 2) * 2 + lVar25;
                    if (uVar58 < lVar25 + uVar47) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109de9;
                      func_0x(lVar25 + uVar47,0x19);
                      uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                      uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                      lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    }
                    if (uVar11 - uVar40 <
                        (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar47) -
                        *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)uVar58) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109e1f;
                      func_0x(uVar47 + lVar25,0x19);
                      uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                      uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                      lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    }
                    if (((uVar43 & 0x3800) != 0) && ((uVar43 & 0x3800) != 0)) {
                      do {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109e5b;
                        uVar11 = func_0x(uVar47 + lVar25 + 4,iVar15);
                        if ((*(ushort *)(&stack0x0000003c + lVar20) & 0x7ff) < uVar11) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109e7a;
                          func_0x((ulonglong)*(ushort *)(&stack0x0000003a + lVar20) +
                                          *(longlong *)((longlong)&pbStackX_18 + lVar20),0x1a);
                        }
                        iVar15 = iVar15 + 1;
                      } while (iVar15 < (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7));
                    }
                    break;
                  }
                  if (uVar54 < 0x400) break;
                  puVar60 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                  *puVar60 = *puVar60 | 1;
                  uVar11 = *(short *)(&stack0x0000002c + lVar20) - 1;
                  *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                  if (uVar11 == 0) break;
                }
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109ea2;
              iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
              if (iVar15 == 0) {
                *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
              }
              else {
                iVar15 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                *(int *)(&stack0x00000036 + lVar20) = iVar15;
                *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar15 + 0xe;
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109ebb;
                uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109eca;
                func_0x(uVar23,&stack0x00000248 + lVar20);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109ed6;
                iVar15 = func_0x(&stack0x00000248 + lVar20);
                uVar36 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar15;
                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar36;
              }
              if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
                 (*(ulonglong *)(&stack0x0000002e + lVar20) <
                  (ulonglong)uVar36 + *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109f0b;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109f14;
                  cVar8 = func_0x();
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109f24;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109f40;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109f66;
                      (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109f74;
                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),0x12);
                uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
              }
              if (0x3f3b < uVar36 - 1) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109f8d;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109f96;
                  cVar8 = func_0x();
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109fa6;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109fc2;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109fe8;
                      (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x109ff6;
                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),5);
                uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
              }
            }
LAB_:
            uVar40 = uVar36;
            if (uVar36 < 9) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a007;
              cVar8 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
              if ((cVar8 == '\0') || (cVar8 == '\f')) {
                uVar40 = 9;
                goto LAB_;
              }
              uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
              uVar40 = uVar36;
            }
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a026;
            uVar40 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
LAB_:
            uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
          }
          if (0x3f3c < uVar40) {
            uVar23 = 0xb8;
            puVar28 = &stack0xffffffffffffffc0 + lVar20;
            goto LAB_;
          }
        }
        else {
LAB_:
          *(undefined8 *)(&stack0x00000080 + lVar20) = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a04c;
          lVar25 = func_0x(*(undefined8 *)(&stack0x00000050 + lVar20));
          *(longlong *)(&stack0x00000060 + lVar20) = lVar25;
          *(undefined2 *)(&stack0x000000b8 + lVar20) = 0xffff;
          *(undefined8 *)(&stack0x000000c0 + lVar20) = 0;
          *(undefined4 *)(&stack0x000000bc + lVar20) = 0;
          *(undefined8 *)(&stack0x000000d6 + lVar20) = 0;
          *(undefined8 *)(&stack0x000000e0 + lVar20) = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a089;
          func_0x(&stack0x000000ba + lVar20,0);
          *(undefined8 *)(&stack0x00000110 + lVar20) = 0;
          *(undefined4 *)(&stack0x00000098 + lVar20) = 0;
          psVar57 = psVar21;
          if (*psVar21 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a0af;
            lVar24 = func_0x(puVar45);
            if (lVar24 != 0) {
              puVar30 = puVar29;
              if (*psVar21 != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a0cb;
                puVar30 = (undefined8 *)func_0x(puVar45);
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a0d3;
              iVar15 = func_0x(puVar30);
              if (iVar15 != 0) {
                sVar14 = *psVar21;
                *(short *)(&stack0x000000b8 + lVar20) = sVar14;
                if (sVar14 == 0) {
                  uVar36 = *(uint *)(psVar21 + 2);
                  if (uVar36 == 0) {
                    *puVar45 = 0;
                    *(undefined4 *)(psVar21 + 10) = *(undefined4 *)(psVar21 + 8);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a10b;
                    pbVar27 = (byte *)func_0x(puVar45);
                    if ((*pbVar27 & 0x10) != 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a118;
                      pbVar27 = (byte *)func_0x(puVar45);
                      if ((*pbVar27 & 0x10) != 0) {
                        uVar40 = (uint)*(ushort *)
                                        ((ulonglong)*(uint *)(psVar21 + 8) +
                                        *(longlong *)(psVar21 + 4));
                      }
                      *(uint *)(psVar21 + 10) = *(int *)(psVar21 + 10) + (uVar40 + 7 >> 3) + 2;
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a141;
                    pbVar27 = (byte *)func_0x(puVar45);
                    if ((*pbVar27 & 0x20) == 0) {
                      *(undefined4 *)(psVar21 + 2) = *(undefined4 *)(psVar21 + 10);
                      psVar21[0xe] = 0;
                      *(undefined4 *)(psVar21 + 0xc) = *(undefined4 *)(psVar21 + 10);
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a152;
                      puVar45 = (ushort *)func_0x(puVar45);
                      uVar11 = *puVar45;
                      psVar21[0xe] = uVar11;
                      if (uVar11 == 0) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a16d;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a176;
                          cVar8 = func_0x();
                          if (cVar8 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a186;
                            cVar8 = func_0x(0x1ebafb0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a1a2;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a1c6;
                              (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
                            }
                          }
                        }
                        uVar23 = *(undefined8 *)(psVar21 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a1d4;
                        func_0x(uVar23,3);
                        uVar11 = psVar21[0xe];
                      }
                      uVar36 = *(int *)(psVar21 + 10) + 2 + (uint)uVar11 * 2;
                      *(uint *)(psVar21 + 0xc) = uVar36;
                      if (0x1f9e < uVar36) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a1fb;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a204;
                          cVar8 = func_0x();
                          if (cVar8 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a214;
                            cVar8 = func_0x(0x1ebafb0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a230;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a254;
                              (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
                            }
                          }
                        }
                        uVar23 = *(undefined8 *)(psVar21 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a262;
                        func_0x(uVar23,4);
                        uVar11 = psVar21[0xe];
                      }
                      puVar45 = puVar45 + 1;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a278;
                      uVar11 = func_0x(puVar45,(ulonglong)uVar11 - 1);
                      *(uint *)(psVar21 + 2) = (uint)uVar11;
                      uVar36 = *(uint *)(psVar21 + 0xc);
                      if (uVar11 < uVar36) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a293;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a29c;
                          cVar8 = func_0x();
                          if (cVar8 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a2ac;
                            cVar8 = func_0x(0x1ebafb0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a2c8;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a2f2;
                              (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
                            }
                          }
                        }
                        uVar23 = *(undefined8 *)(psVar21 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a300;
                        func_0x(uVar23,4);
                        uVar36 = *(uint *)(psVar21 + 0xc);
                      }
                      iVar15 = 0;
                      uVar11 = psVar21[0xe];
                      if (uVar11 != 0) {
                        do {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a32b;
                          uVar11 = func_0x(puVar45,(longlong)iVar15);
                          bVar62 = uVar11 < uVar36;
                          uVar36 = (uint)uVar11;
                          if ((bVar62) ||
                             (*(uint *)(psVar21 + 2) <= (uint)uVar11 &&
                              uVar36 != *(uint *)(psVar21 + 2))) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a346;
                            cVar8 = func_0x(0x1ebafb0);
                            if (cVar8 != '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a34f;
                              cVar8 = func_0x();
                              if (cVar8 != '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a35f;
                                cVar8 = func_0x(0x1ebafb0);
                                if (cVar8 == '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a37b;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a39f;
                                  (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                                }
                              }
                            }
                            uVar23 = *(undefined8 *)(psVar21 + 4);
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a3ad;
                            func_0x(uVar23,4);
                          }
                          iVar15 = iVar15 + 1;
                          uVar11 = psVar21[0xe];
                        } while (iVar15 < (int)(uint)uVar11);
                        lVar25 = *(longlong *)(&stack0x00000060 + lVar20);
                      }
                      puVar60 = (ushort *)(psVar21 + 1);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a3d3;
                      iVar15 = func_0x(puVar45,uVar11 - 1);
                      while (iVar15 != 0) {
                        uVar11 = psVar21[0xe];
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a3ec;
                        lVar24 = func_0x(puVar60);
                        if (uVar11 == 1) {
                          uVar40 = *(uint *)(psVar21 + 0xc);
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a409;
                          uVar54 = func_0x(lVar24 + 2,(ulonglong)uVar11 - 2);
                          uVar40 = (uint)uVar54;
                        }
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a419;
                        uVar11 = func_0x(lVar24 + 2,(ulonglong)(uint)uVar11 - 1);
                        uVar18 = *(uint *)(psVar21 + 0xc);
                        if (((uVar40 < uVar18) || (uVar11 < uVar40)) ||
                           (uVar36 = *(uint *)(psVar21 + 2), uVar36 <= uVar11 && uVar11 != uVar36))
                        {
                          uVar23 = *(undefined8 *)(psVar21 + 4);
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a43f;
                          func_0x(uVar23,7);
                          uVar18 = *(uint *)(psVar21 + 0xc);
                          uVar36 = *(uint *)(psVar21 + 2);
                        }
                        if ((uVar40 < uVar18) || (uVar36 < uVar40)) goto LAB_;
                        if (*(ushort *)((ulonglong)uVar40 + *(longlong *)(psVar21 + 4)) == 5) {
                          *puVar60 = *puVar60 | 2;
                          psVar21[0xe] = psVar21[0xe] + -1;
                          psVar21[0x15] = (short)uVar40;
                          lVar24 = (ulonglong)(uVar40 & 0xffff) + *(longlong *)(psVar21 + 4);
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a507;
                          iVar15 = func_0x(lVar24);
                          if (iVar15 == 0) {
                            psVar21[0x16] = psVar21[0x16] & 0xc7ff;
                          }
                          else {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a513;
                            uVar54 = func_0x(lVar24);
                            psVar21[0x16] = psVar21[0x16] & 0xc7ff;
                            psVar21[0x16] = psVar21[0x16] | (uVar54 & 7) << 0xb;
                          }
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a53b;
                          uVar54 = func_0x(lVar24);
                          psVar21[0x16] = psVar21[0x16] ^ (uVar54 ^ psVar21[0x16]) & 0x7ff;
                          uVar13 = psVar21[0x16];
                          uVar43 = *(ulonglong *)(psVar21 + 4);
                          uVar54 = psVar21[0x15];
                          uVar47 = (ulonglong)((uVar13 & 0x7ff) * 2) + 4 +
                                   uVar43 + (uVar13 >> 0xb & 7) * 2 + (ulonglong)uVar54;
                          uVar58 = uVar43 + uVar54;
                          if (uVar47 < uVar58) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a591;
                            func_0x(uVar58,0x19);
                            uVar13 = psVar21[0x16];
                            uVar54 = psVar21[0x15];
                            uVar43 = (ulonglong)*(uint *)(psVar21 + 4);
                          }
                          if (uVar11 - uVar40 <
                              (((uVar13 & 0x7ff) * 2 - (uint)uVar54) - (int)uVar43) + (int)uVar47) {
                            uVar11 = psVar21[0x15];
                            lVar24 = *(longlong *)(psVar21 + 4);
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a5cd;
                            func_0x((ulonglong)uVar11 + lVar24,0x19);
                            uVar13 = psVar21[0x16];
                          }
                          if ((uVar13 & 0x3800) != 0) {
                            uVar11 = psVar21[0x15];
                            lVar24 = *(longlong *)(psVar21 + 4);
                            iVar15 = 0;
                            if ((uVar13 & 0x3800) != 0) {
                              do {
                                uVar54 = psVar21[0x16];
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a610;
                                uVar13 = func_0x
                                                   ((ulonglong)uVar11 + lVar24 + 4,iVar15);
                                if ((uVar54 & 0x7ff) < uVar13) {
                                  uVar54 = psVar21[0x15];
                                  lVar37 = *(longlong *)(psVar21 + 4);
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a62f;
                                  func_0x((ulonglong)uVar54 + lVar37,0x1a);
                                  uVar54 = psVar21[0x16];
                                }
                                iVar15 = iVar15 + 1;
                              } while (iVar15 < (int)(uVar54 >> 0xb & 7));
                            }
                          }
                          break;
                        }
                        if (*(ushort *)((ulonglong)uVar40 + *(longlong *)(psVar21 + 4)) < 0x400)
                        break;
                        *puVar60 = *puVar60 | 1;
                        uVar11 = psVar21[0xe] - 1;
                        psVar21[0xe] = uVar11;
                        if (uVar11 == 0) break;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a491;
                        iVar15 = func_0x(puVar45,uVar11 - 1);
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a4a8;
                    iVar15 = func_0x(psVar21 + 1);
                    if (iVar15 == 0) {
                      *(undefined4 *)(psVar21 + 0x13) = 0;
                    }
                    else {
                      *(int *)(psVar21 + 0x13) = *(int *)(psVar21 + 2);
                      *(int *)(psVar21 + 2) = *(int *)(psVar21 + 2) + 0xe;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a4c4;
                      uVar23 = func_0x(psVar21 + 1);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a4d3;
                      func_0x(uVar23,&stack0x00000250 + lVar20);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a4df;
                      iVar15 = func_0x(&stack0x00000250 + lVar20);
                      *(int *)(psVar21 + 2) = *(int *)(psVar21 + 2) + iVar15;
                    }
                    uVar36 = *(uint *)(psVar21 + 2);
                    if ((*(ulonglong *)(psVar21 + 0xf) != 0) &&
                       (*(ulonglong *)(psVar21 + 0xf) <
                        (ulonglong)uVar36 + *(longlong *)(psVar21 + 4))) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a683;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a68c;
                        cVar8 = func_0x();
                        if (cVar8 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a69c;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a6b8;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a6dc;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
                          }
                        }
                      }
                      uVar23 = *(undefined8 *)(psVar21 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a6ea;
                      func_0x(uVar23,0x12);
                      uVar36 = *(uint *)(psVar21 + 2);
                    }
                    if ((uVar36 == 0) || (0x3f3c < uVar36)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a705;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a70e;
                        cVar8 = func_0x();
                        if (cVar8 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a71e;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a73a;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a75e;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
                          }
                        }
                      }
                      uVar23 = *(undefined8 *)(psVar21 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a76c;
                      func_0x(uVar23,5);
                      uVar36 = *(uint *)(psVar21 + 2);
                    }
                  }
LAB_:
                  psVar57 = psVar21 + 1;
                  if (uVar36 < 9) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a782;
                    cVar8 = func_0x(psVar57);
                    if ((cVar8 == '\0') || (cVar8 == '\f')) {
                      uVar36 = 9;
                    }
                    else {
                      uVar36 = *(uint *)(psVar21 + 2);
                    }
                  }
                  *(undefined4 *)(&stack0x000000c8 + lVar20) = *(undefined4 *)(psVar21 + 8);
                  *(short *)(&stack0x000000ba + lVar20) = *psVar57;
                  *(undefined4 *)(&stack0x000000bc + lVar20) = *(undefined4 *)(psVar21 + 2);
                  *(short *)(&stack0x000000d4 + lVar20) = psVar21[0xe];
                  *(undefined4 *)(&stack0x000000cc + lVar20) = *(undefined4 *)(psVar21 + 10);
                  *(undefined4 *)(&stack0x000000d0 + lVar20) = *(undefined4 *)(psVar21 + 0xc);
                  *(undefined4 *)(&stack0x000000de + lVar20) = *(undefined4 *)(psVar21 + 0x13);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a7e0;
                  uVar23 = func_0x(psVar57);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a7f7;
                  func_0x(&stack0x00000900 + lVar20,0x1f9e,uVar23,uVar36);
                  *(undefined **)(&stack0x000000c0 + lVar20) = &stack0x00000900 + lVar20;
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a811;
                  iVar15 = func_0x(&stack0x000000ba + lVar20);
                  if (iVar15 != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a82c;
                    uVar11 = func_0x
                                       (&stack0x000000ba + lVar20,&stack0x0000012c + lVar20);
                    uVar36 = *(uint *)(&stack0x0000012c + lVar20);
                    *(ushort *)(&stack0x000000e2 + lVar20) = uVar11;
                    lVar24 = (ulonglong)uVar11 + *(longlong *)(&stack0x000000c0 + lVar20);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a84b;
                    iVar15 = func_0x(lVar24);
                    if (iVar15 == 0) {
                      *(ushort *)(&stack0x000000e4 + lVar20) =
                           *(ushort *)(&stack0x000000e4 + lVar20) & 0xc7ff;
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a857;
                      sVar14 = func_0x(lVar24);
                      *(ushort *)(&stack0x000000e4 + lVar20) =
                           *(ushort *)(&stack0x000000e4 + lVar20) ^
                           (sVar14 << 0xb ^ *(ushort *)(&stack0x000000e4 + lVar20)) & 0x3800;
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a895;
                    uVar54 = func_0x(lVar24);
                    uVar11 = *(ushort *)(&stack0x000000e4 + lVar20);
                    uVar54 = (*(ushort *)(&stack0x000000e4 + lVar20) ^ uVar54) & 0x7ff ^ uVar11;
                    uVar43 = (ulonglong)uVar54;
                    *(ushort *)(&stack0x000000e4 + lVar20) = uVar54;
                    uVar47 = (ulonglong)*(ushort *)(&stack0x000000e2 + lVar20);
                    lVar24 = *(longlong *)(&stack0x000000c0 + lVar20);
                    uVar58 = (uVar11 >> 0xb & 7) * 2 + uVar47 + ((uVar43 & 0x7ff) + 2) * 2 + lVar24;
                    if (uVar58 < lVar24 + uVar47) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a8f7;
                      func_0x(lVar24 + uVar47,0x19);
                      uVar43 = (ulonglong)*(ushort *)(&stack0x000000e4 + lVar20);
                      uVar47 = (ulonglong)*(ushort *)(&stack0x000000e2 + lVar20);
                      lVar24 = *(longlong *)(&stack0x000000c0 + lVar20);
                    }
                    if (uVar36 < (((*(uint *)(&stack0x000000e4 + lVar20) & 0x7ff) * 2 - (int)uVar47)
                                 - *(int *)(&stack0x000000c0 + lVar20)) + (int)uVar58) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a93c;
                      func_0x(uVar47 + lVar24,0x19);
                      uVar43 = (ulonglong)*(ushort *)(&stack0x000000e4 + lVar20);
                      uVar47 = (ulonglong)*(ushort *)(&stack0x000000e2 + lVar20);
                      lVar24 = *(longlong *)(&stack0x000000c0 + lVar20);
                    }
                    iVar15 = 0;
                    if (((uVar43 & 0x3800) != 0) && ((uVar43 & 0x3800) != 0)) {
                      do {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a98b;
                        uVar11 = func_0x(uVar47 + lVar24 + 4,iVar15);
                        if ((*(ushort *)(&stack0x000000e4 + lVar20) & 0x7ff) < uVar11) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a9b3;
                          func_0x((ulonglong)*(ushort *)(&stack0x000000e2 + lVar20) +
                                          *(longlong *)(&stack0x000000c0 + lVar20),0x1a);
                        }
                        iVar15 = iVar15 + 1;
                      } while (iVar15 < (int)(*(uint *)(&stack0x000000e4 + lVar20) >> 0xb & 7));
                      psVar57 = (short *)(&stack0x000000b8 + lVar20);
                      goto LAB_;
                    }
                  }
                  psVar57 = (short *)(&stack0x000000b8 + lVar20);
                }
                else {
                  if (*psVar21 != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a9df;
                    lVar24 = func_0x(puVar45);
                    if (lVar24 != 0) {
                      if (*psVar21 != 0) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a9f7;
                        puVar29 = (undefined8 *)func_0x(puVar45);
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10a9ff;
                      iVar15 = func_0x(puVar29);
                      if (iVar15 != 0) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10aa1f;
                        func_0x(&stack0x000000b8 + lVar20,&stack0x00000900 + lVar20,0x1f9e,
                                        psVar21);
                        psVar57 = (short *)(&stack0x000000b8 + lVar20);
                        goto LAB_;
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10aa44;
                  func_0x(&stack0x000000ba + lVar20,&stack0x00000900 + lVar20,0x1f9e,puVar45
                                 );
                  if (*psVar21 == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10aa5c;
                    func_0x(&stack0x000000ba + lVar20,0);
                    psVar57 = (short *)(&stack0x000000b8 + lVar20);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10aa6d;
                    uVar23 = func_0x(puVar45);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10aa7c;
                    func_0x(&stack0x000000ba + lVar20,uVar23);
                    psVar57 = (short *)(&stack0x000000b8 + lVar20);
                  }
                }
              }
            }
          }
LAB_:
          uVar40 = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10aa9d;
          iVar15 = func_0x(lVar25 + 0x10);
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10aaa9;
          uVar36 = func_0x(psVar57);
          if ((uint)-iVar15 < uVar36) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10aab8;
            uVar36 = func_0x(psVar57);
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10aac5;
            iVar15 = func_0x(lVar25 + 0x10);
            uVar36 = -iVar15;
          }
          *(uint *)(&stack0x00000048 + lVar20) = uVar36;
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10aad4;
          iVar15 = func_0x(psVar21);
          if (iVar15 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10aaef;
            cVar8 = func_0x
                              (*(undefined8 *)(&stack0x00000050 + lVar20),&stack0x00000110 + lVar20,
                               &stack0x00000098 + lVar20);
            if (cVar8 != '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10ab08;
              uVar18 = func_0x(*(undefined8 *)(&stack0x00000110 + lVar20),
                                       *(undefined4 *)(&stack0x00000098 + lVar20),psVar21);
              if (uVar36 <= uVar18) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10ab24;
                uVar19 = func_0x(*(undefined8 *)(&stack0x00000110 + lVar20),
                                         *(undefined4 *)(&stack0x00000098 + lVar20),psVar21);
                *(undefined4 *)(&stack0x00000048 + lVar20) = uVar19;
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10ab30;
          uVar36 = func_0x(lVar25 + 0x10);
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10ab3c;
          uVar19 = func_0x(lVar25 + 0x10);
          sVar14 = *psVar57;
          *psVar2 = sVar14;
          puVar45 = (ushort *)(psVar57 + 1);
          if (sVar14 == 0) {
            *(undefined **)((longlong)&pbStackX_18 + lVar20) = &stack0x000028a0 + lVar20;
            *(undefined4 *)((longlong)&uStackX_20 + lVar20) = uVar19;
            *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
            *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
            *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10ab77;
            cVar8 = func_0x(puVar45);
            lVar25 = (longlong)&sStackX_10 + lVar20 + 2;
            if (cVar8 == '\x06') {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10ab84;
              puVar28 = (undefined *)func_0x(lVar25);
              *puVar28 = 6;
              uVar18 = 1;
            }
            else {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10ab93;
              puVar28 = (undefined *)func_0x(lVar25);
              *puVar28 = 0;
              *(undefined *)(*(longlong *)((longlong)&pbStackX_18 + lVar20) + 1) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10abaa;
              func_0x
                        ((longlong)&sStackX_10 + lVar20 + 2,
                         *(undefined4 *)((longlong)&uStackX_20 + lVar20));
              uVar18 = 4;
            }
            uVar41 = *(uint *)(psVar57 + 8);
            if (*(uint *)((longlong)&uStackX_20 + lVar20) <= uVar41) {
              uVar41 = *(uint *)((longlong)&uStackX_20 + lVar20);
            }
            lVar25 = *(longlong *)(psVar57 + 4);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10abd4;
            func_0x
                      (*(longlong *)((longlong)&pbStackX_18 + lVar20) + (ulonglong)uVar18,
                       lVar25 + (ulonglong)uVar18,uVar41 - uVar18);
            if (uVar36 == 0) {
              *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                   *(undefined4 *)((longlong)&uStackX_20 + lVar20);
            }
            else {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10abe6;
              pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              *pbVar27 = *pbVar27 | 0x10;
              *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                   (uVar36 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20) + 2;
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10ac03;
              pbVar27 = (byte *)func_0x(puVar45);
              if ((*pbVar27 & 0x10) == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10acaa;
                func_0x(&stack0x000001a8 + lVar20);
                *(short *)((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                          *(longlong *)((longlong)&pbStackX_18 + lVar20)) = (short)uVar36;
              }
              else {
                lVar25 = *(longlong *)(psVar57 + 4);
                uVar11 = *(ushort *)((ulonglong)*(uint *)(psVar57 + 8) + lVar25);
                uVar40 = (uint)uVar11;
                if (uVar11 == uVar36) {
                  iVar15 = *(int *)((longlong)&uStackX_20 + lVar20 + 4);
                  uVar36 = *(uint *)(psVar57 + 8);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10ac35;
                  func_0x
                            ((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                             *(longlong *)((longlong)&pbStackX_18 + lVar20),
                             (ulonglong)uVar36 + lVar25,
                             iVar15 - *(uint *)((longlong)&uStackX_20 + lVar20));
                  uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
                  *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
                  *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
                  goto LAB_;
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10ac4f;
                func_0x(&stack0x000001a8 + lVar20);
                *(short *)((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                          *(longlong *)((longlong)&pbStackX_18 + lVar20)) = (short)uVar36;
                if (uVar11 != 0) {
                  uVar41 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) -
                           *(uint *)((longlong)&uStackX_20 + lVar20);
                  uVar18 = *(uint *)(psVar57 + 8);
                  uVar38 = *(int *)(psVar57 + 10) - uVar18;
                  if (uVar38 <= uVar41) {
                    uVar41 = uVar38;
                  }
                  lVar25 = *(longlong *)(psVar57 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10ac99;
                  func_0x
                            (*(longlong *)((longlong)&pbStackX_18 + lVar20) +
                             (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) + 2,
                             lVar25 + (ulonglong)uVar18 + 2,uVar41 - 2);
                }
              }
              if (uVar36 < uVar40) {
                uVar40 = uVar36 & 0xffff;
              }
              uVar11 = (short)uVar40 + 1;
              if (uVar11 <= uVar36) {
                do {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10acdf;
                  func_0x(&stack0x000001a8 + lVar20,uVar11);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10acef;
                  func_0x((longlong)&sStackX_10 + lVar20 + 2,&stack0x000001a8 + lVar20);
                  uVar11 = uVar11 + 1;
                } while (uVar11 <= uVar36);
                uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
                *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
                *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
                goto LAB_;
              }
            }
            uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
            *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
            *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
          }
          else {
            *(uint *)(&stack0xffffffffffffffe0 + lVar20) = uVar36;
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10ad34;
            func_0x((longlong)&sStackX_10 + lVar20 + 2,&stack0x000028a0 + lVar20,0x3f3c,
                            puVar45);
          }
LAB_:
          uVar36 = *(uint *)(&stack0x00000048 + lVar20);
          if (uVar36 == 0) {
            lVar25 = *(longlong *)(&stack0x00000080 + lVar20);
            puVar28 = &stack0xffffffffffffffc0 + lVar20;
          }
          else {
            uVar58 = (ulonglong)uVar36 * 0x20 + 0xf;
            if (uVar58 <= (ulonglong)uVar36 * 0x20) {
              uVar58 = 0xffffffffffffff0;
            }
            uVar58 = uVar58 & 0xfffffffffffffff0;
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10ad6a;
            func_0x();
            lVar24 = -uVar58;
            lVar25 = (longlong)&sStackX_10 + lVar24 + lVar20;
            *(longlong *)(&stack0x00000080 + lVar20) = lVar25;
            if (*psVar57 == 0) {
              uVar58 = 0;
              uVar40 = 0;
              if (*(int *)(psVar57 + 2) == 0) {
                *puVar45 = 0;
                *(undefined4 *)(psVar57 + 10) = *(undefined4 *)(psVar57 + 8);
                *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10ada1;
                pbVar27 = (byte *)func_0x(puVar45);
                if ((*pbVar27 & 0x10) != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10adae;
                  pbVar27 = (byte *)func_0x(puVar45);
                  if ((*pbVar27 & 0x10) != 0) {
                    uVar40 = (uint)*(ushort *)
                                    ((ulonglong)*(uint *)(psVar57 + 8) + *(longlong *)(psVar57 + 4))
                    ;
                  }
                  *(uint *)(psVar57 + 10) = *(int *)(psVar57 + 10) + (uVar40 + 7 >> 3) + 2;
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10add7;
                pbVar27 = (byte *)func_0x(puVar45);
                if ((*pbVar27 & 0x20) == 0) {
                  *(undefined4 *)(psVar57 + 2) = *(undefined4 *)(psVar57 + 10);
                  psVar57[0xe] = 0;
                  *(undefined4 *)(psVar57 + 0xc) = *(undefined4 *)(psVar57 + 10);
                }
                else {
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10ade8;
                  puVar60 = (ushort *)func_0x(puVar45);
                  uVar11 = *puVar60;
                  psVar57[0xe] = uVar11;
                  if (uVar11 == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10ae03;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10ae0c;
                      cVar8 = func_0x();
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10ae1c;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10ae38;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar24 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10ae5e;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)(psVar57 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10ae6c;
                    func_0x(uVar23,3);
                    uVar11 = psVar57[0xe];
                  }
                  uVar36 = *(int *)(psVar57 + 10) + (uVar11 + 1) * 2;
                  *(uint *)(psVar57 + 0xc) = uVar36;
                  if (0x1f9e < uVar36) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10ae93;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10ae9c;
                      cVar8 = func_0x();
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10aeac;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10aec8;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar24 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10aeee;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)(psVar57 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10aefc;
                    func_0x(uVar23,4);
                    uVar11 = psVar57[0xe];
                  }
                  puVar60 = puVar60 + 1;
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10af12;
                  uVar11 = func_0x(puVar60,(ulonglong)uVar11 - 1);
                  *(uint *)(psVar57 + 2) = (uint)uVar11;
                  uVar36 = *(uint *)(psVar57 + 0xc);
                  if (uVar11 < uVar36) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10af2d;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10af36;
                      cVar8 = func_0x();
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10af46;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10af62;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar24 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10af88;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)(psVar57 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10af96;
                    func_0x(uVar23,4);
                    uVar36 = *(uint *)(psVar57 + 0xc);
                  }
                  uVar11 = psVar57[0xe];
                  uVar43 = uVar58;
                  if (uVar11 != 0) {
                    do {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10afbb;
                      uVar11 = func_0x(puVar60,(longlong)(int)uVar43);
                      bVar62 = uVar11 < uVar36;
                      uVar36 = (uint)uVar11;
                      if ((bVar62) ||
                         (*(uint *)(psVar57 + 2) <= (uint)uVar11 && uVar36 != *(uint *)(psVar57 + 2)
                         )) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10afd6;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10afdf;
                          cVar8 = func_0x();
                          if (cVar8 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10afef;
                            cVar8 = func_0x(0x1ebafb0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b00b;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar24 + lVar20) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b02e;
                              (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                            }
                          }
                        }
                        uVar23 = *(undefined8 *)(psVar57 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b03c;
                        func_0x(uVar23,4);
                      }
                      uVar40 = (int)uVar43 + 1;
                      uVar11 = psVar57[0xe];
                      uVar43 = (ulonglong)uVar40;
                    } while ((int)uVar40 < (int)(uint)uVar11);
                    psVar21 = *(short **)(&stack0x00000070 + lVar20);
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b05e;
                  iVar15 = func_0x(puVar60,uVar11 - 1);
                  while (iVar15 != 0) {
                    uVar11 = psVar57[0xe];
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b07c;
                    lVar25 = func_0x(puVar45);
                    if (uVar11 == 1) {
                      uVar36 = *(uint *)(psVar57 + 0xc);
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b099;
                      uVar54 = func_0x(lVar25 + 2,(ulonglong)uVar11 - 2);
                      uVar36 = (uint)uVar54;
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b0a9;
                    uVar11 = func_0x(lVar25 + 2,(ulonglong)(uint)uVar11 - 1);
                    uVar40 = *(uint *)(psVar57 + 0xc);
                    if (((uVar36 < uVar40) || (uVar11 < uVar36)) ||
                       (*(uint *)(psVar57 + 2) <= (uint)uVar11 &&
                        (uint)uVar11 != *(uint *)(psVar57 + 2))) {
                      uVar23 = *(undefined8 *)(psVar57 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b0cd;
                      func_0x(uVar23,7);
                      uVar40 = *(uint *)(psVar57 + 0xc);
                    }
                    if ((uVar36 < uVar40) || (*(uint *)(psVar57 + 2) < uVar36)) goto LAB_;
                    if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(psVar57 + 4)) == 5) {
                      *puVar45 = *puVar45 | 2;
                      psVar57[0xe] = psVar57[0xe] + -1;
                      psVar57[0x15] = (short)uVar36;
                      lVar25 = (ulonglong)(uVar36 & 0xffff) + *(longlong *)(psVar57 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b155;
                      iVar15 = func_0x(lVar25);
                      if (iVar15 == 0) {
                        psVar57[0x16] = psVar57[0x16] & 0xc7ff;
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b161;
                        uVar54 = func_0x(lVar25);
                        psVar57[0x16] = psVar57[0x16] & 0xc7ff;
                        psVar57[0x16] = psVar57[0x16] | (uVar54 & 7) << 0xb;
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b189;
                      uVar54 = func_0x(lVar25);
                      psVar57[0x16] = psVar57[0x16] ^ (uVar54 ^ psVar57[0x16]) & 0x7ff;
                      uVar13 = psVar57[0x16];
                      uVar47 = *(ulonglong *)(psVar57 + 4);
                      uVar54 = psVar57[0x15];
                      uVar49 = (ulonglong)((uVar13 & 0x7ff) * 2) + 4 +
                               uVar47 + (uVar13 >> 0xb & 7) * 2 + (ulonglong)uVar54;
                      uVar43 = uVar47 + uVar54;
                      if (uVar49 < uVar43) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b1df;
                        func_0x(uVar43,0x19);
                        uVar13 = psVar57[0x16];
                        uVar54 = psVar57[0x15];
                        uVar47 = (ulonglong)*(uint *)(psVar57 + 4);
                      }
                      if (uVar11 - uVar36 <
                          (((uVar13 & 0x7ff) * 2 - (uint)uVar54) - (int)uVar47) + (int)uVar49) {
                        uVar11 = psVar57[0x15];
                        lVar25 = *(longlong *)(psVar57 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b21b;
                        func_0x((ulonglong)uVar11 + lVar25,0x19);
                        uVar13 = psVar57[0x16];
                      }
                      if (((uVar13 & 0x3800) != 0) &&
                         (uVar11 = psVar57[0x15], lVar25 = *(longlong *)(psVar57 + 4),
                         uVar43 = uVar58, (uVar13 & 0x3800) != 0)) {
                        do {
                          uVar54 = psVar57[0x16];
                          *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b260;
                          uVar13 = func_0x((ulonglong)uVar11 + lVar25 + 4,uVar43);
                          if ((uVar54 & 0x7ff) < uVar13) {
                            uVar54 = psVar57[0x15];
                            lVar37 = *(longlong *)(psVar57 + 4);
                            *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b27f;
                            func_0x((ulonglong)uVar54 + lVar37,0x1a);
                            uVar54 = psVar57[0x16];
                          }
                          uVar36 = (int)uVar43 + 1;
                          uVar43 = (ulonglong)uVar36;
                        } while ((int)uVar36 < (int)(uVar54 >> 0xb & 7));
                      }
                      break;
                    }
                    if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(psVar57 + 4)) < 0x400) break;
                    *puVar45 = *puVar45 | 1;
                    uVar11 = psVar57[0xe] - 1;
                    psVar57[0xe] = uVar11;
                    if (uVar11 == 0) break;
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b125;
                    iVar15 = func_0x(puVar60,uVar11 - 1);
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b2af;
                iVar15 = func_0x(puVar45);
                if (iVar15 == 0) {
                  *(undefined4 *)(psVar57 + 0x13) = 0;
                }
                else {
                  *(int *)(psVar57 + 0x13) = *(int *)(psVar57 + 2);
                  *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + 0xe;
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b2ca;
                  uVar23 = func_0x(puVar45);
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b2d9;
                  func_0x(uVar23,&stack0x00000258 + lVar20);
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b2e5;
                  iVar15 = func_0x(&stack0x00000258 + lVar20);
                  *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + iVar15;
                }
                uVar36 = *(uint *)(psVar57 + 2);
                if ((*(ulonglong *)(psVar57 + 0xf) != 0) &&
                   (*(ulonglong *)(psVar57 + 0xf) < (ulonglong)uVar36 + *(longlong *)(psVar57 + 4)))
                {
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b318;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b321;
                    cVar8 = func_0x();
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b331;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b34d;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar24 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b373;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)(psVar57 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b381;
                  func_0x(uVar23,0x12);
                  uVar36 = *(uint *)(psVar57 + 2);
                }
                if (0x3f3b < uVar36 - 1) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b39d;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b3a6;
                    cVar8 = func_0x();
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b3b6;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b3d2;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar24 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b3f8;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)(psVar57 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b406;
                  func_0x(uVar23,5);
                }
LAB_:
                uVar36 = *(uint *)(&stack0x00000048 + lVar20);
              }
              uVar11 = psVar57[0xe];
              uVar43 = (ulonglong)uVar11;
              *(uint *)(&stack0x00000078 + lVar20) = (uint)uVar11;
              if (uVar11 < uVar36) {
                if (uVar11 != 0) goto code_r0x0010b427;
              }
              else {
                *(uint *)(&stack0x00000078 + lVar20) = uVar36;
code_r0x0010b427:
                *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b42f;
                lVar25 = func_0x(puVar45);
                uVar36 = *(uint *)(psVar57 + 0xc);
                *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b442;
                func_0x(&stack0x000002f8 + lVar20);
                lVar25 = lVar25 + 2;
                *(longlong *)(&stack0x00000060 + lVar20) = lVar25;
                lVar37 = *(longlong *)(&stack0x00000080 + lVar20);
                uVar40 = *(uint *)(&stack0x00000078 + lVar20);
                uVar43 = uVar58;
                do {
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b46b;
                  uVar11 = func_0x(lVar25,uVar58);
                  uVar18 = (uint)uVar11;
                  if ((uVar11 < uVar36) ||
                     (*(uint *)(psVar57 + 2) <= (uint)uVar11 && uVar18 != *(uint *)(psVar57 + 2))) {
                    uVar23 = *(undefined8 *)(psVar57 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b486;
                    func_0x(uVar23,7);
                  }
                  uVar23 = *(undefined8 *)(&stack0x00000060 + lVar20);
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b492;
                  iVar15 = func_0x(uVar23,uVar43);
                  lVar25 = *(longlong *)(psVar57 + 4);
                  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar24 + lVar20) = 0;
                  *(undefined **)(&stack0xffffffffffffffe0 + lVar24 + lVar20) =
                       &stack0x000002f8 + lVar20;
                  *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b4c2;
                  func_0x
                            (lVar37,(ulonglong)uVar36 + lVar25,uVar18 - uVar36,iVar15 != 0);
                  uVar41 = (int)uVar43 + 1;
                  uVar43 = (ulonglong)uVar41;
                  uVar58 = uVar58 + 1;
                  lVar37 = lVar37 + 0x20;
                  lVar25 = *(longlong *)(&stack0x00000060 + lVar20);
                  uVar36 = uVar18;
                } while (uVar41 < uVar40);
                psVar21 = *(short **)(&stack0x00000070 + lVar20);
                uVar43 = (ulonglong)*(uint *)(&stack0x00000078 + lVar20);
                uVar36 = *(uint *)(&stack0x00000048 + lVar20);
              }
              lVar25 = *(longlong *)(&stack0x00000080 + lVar20);
              *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b4ff;
              func_0x(uVar43 * 0x20 + lVar25,0,(uVar36 - (int)uVar43) * 0x20);
              puVar28 = &stack0xffffffffffffffc0 + lVar24 + lVar20;
            }
            else {
              *(undefined8 *)((longlong)&uStack_48 + lVar24 + lVar20) = 0x10b512;
              func_0x(puVar45,lVar25,uVar36);
              puVar28 = &stack0xffffffffffffffc0 + lVar24 + lVar20;
            }
          }
          lVar24 = *(longlong *)(&stack0x00000110 + lVar20);
          if (lVar24 != 0) {
            *(uint *)(puVar28 + 0x28) = uVar36;
            *(longlong *)(puVar28 + 0x20) = lVar25;
            uVar19 = *(undefined4 *)(&stack0x00000098 + lVar20);
            *(undefined8 *)(puVar28 + -8) = 0x10b540;
            func_0x(lVar24,uVar19,psVar21,psVar2);
          }
          uVar23 = *(undefined8 *)(&stack0x00000050 + lVar20);
          *(undefined8 *)(puVar28 + -8) = 0x10b549;
          uVar23 = func_0x(uVar23);
          *(undefined8 *)(puVar28 + -8) = 0x10b551;
          uVar11 = func_0x(uVar23);
          *(undefined8 *)(&stack0x000000b0 + lVar20) = 0;
          uVar23 = *(undefined8 *)(&stack0x00000050 + lVar20);
          *(undefined8 *)(puVar28 + -8) = 0x10b567;
          lVar24 = func_0x(uVar23);
          if (uVar11 != 0) {
            uVar58 = (ulonglong)uVar11;
            lVar37 = *(longlong *)(&stack0x00000050 + lVar20);
            do {
              *(undefined8 *)(puVar28 + -8) = 0x10b588;
              uVar23 = func_0x(lVar24);
              *(undefined8 *)(puVar28 + -8) = 0x10b593;
              iVar15 = func_0x(lVar24);
              *(undefined8 *)(puVar28 + -8) = 0x10b5a5;
              func_0x(lVar37,lVar24,&stack0x00000089 + lVar20);
              if ((&stack0x00000089)[lVar20] == '\x03') {
                *(undefined8 *)(puVar28 + -8) = 0x10b92a;
                iVar42 = func_0x(lVar24);
                if (iVar42 == 0) {
                  *(undefined8 *)(puVar28 + -8) = 0x10b936;
                  iVar42 = func_0x(lVar24);
                  if (iVar42 == 0) {
                    *(undefined8 *)(puVar28 + -8) = 0x10b94e;
                    (*_DAT_)(6,0x51,0x10,3);
                  }
                }
                *(undefined8 *)(puVar28 + -8) = 0x10b960;
                func_0x(psVar2,uVar23,0,0);
                if (iVar15 < 0) {
                  puVar48 = (uint *)((longlong)-iVar15 * 0x20 + -0x14 + lVar25);
                  *puVar48 = *puVar48 | 2;
                }
              }
              else {
                *(undefined8 *)(puVar28 + -8) = 0x10b5b7;
                sVar14 = func_0x(uVar23);
                if (sVar14 != 0) {
                  if (*psVar2 == 0) {
                    *(undefined8 *)(puVar28 + -8) = 0x10b5cf;
                    func_0x();
                  }
                  else {
                    *(undefined8 *)(puVar28 + -8) = 0x10b5d6;
                    func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar23);
                  }
                }
                *(undefined8 *)(puVar28 + -8) = 0x10b5e8;
                func_0x(lVar37,lVar24,&stack0x000000b0 + lVar20);
                *(undefined8 *)(puVar28 + -8) = 0x10b5f0;
                iVar42 = func_0x(lVar24);
                uVar36 = 0;
                if ((iVar42 == 1) || (iVar42 == 2)) {
                  lVar25 = *(longlong *)(&stack0x000000b0 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x10b796;
                  iVar15 = func_0x(lVar24);
                  if (iVar15 == 0) {
                    *(undefined8 *)(puVar28 + -8) = 0x10b7a2;
                    uVar12 = func_0x();
                    *(undefined8 *)(puVar28 + -8) = 0x10b7ad;
                    uVar23 = func_0x(lVar24);
                    *(undefined8 *)(puVar28 + -8) = 0x10b7b5;
                    iVar15 = func_0x(uVar23);
                    lVar37 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x10b7c7;
                    func_0x(iVar15 + lVar37,lVar25,uVar12);
                  }
                  else {
                    *(undefined8 *)(puVar28 + -8) = 0x10b7d4;
                    iVar15 = func_0x(lVar24);
                    if ((iVar15 == 0) || ((*(byte *)(lVar37 + 0x14) & 8) == 0)) {
                      *(undefined8 *)(puVar28 + -8) = 0x10b801;
                      iVar15 = func_0x(lVar24);
                      if (iVar15 == 0) {
                        *(undefined8 *)(puVar28 + -8) = 0x10b830;
                        uVar11 = func_0x(lVar24);
                        uVar36 = (uint)uVar11;
                      }
                      else {
                        *(undefined8 *)(puVar28 + -8) = 0x10b80d;
                        uVar32 = func_0x();
                        uVar23 = *(undefined8 *)(&stack0x00000050 + lVar20);
                        *(undefined8 *)(puVar28 + -8) = 0x10b81c;
                        uVar23 = func_0x(uVar23,lVar24);
                        *(undefined8 *)(puVar28 + -8) = 0x10b827;
                        uVar36 = func_0x(uVar23,uVar32);
                      }
                    }
                    else {
                      *(undefined8 *)(puVar28 + -8) = 0x10b7e6;
                      uVar36 = func_0x(lVar24);
                      uVar36 = *(uint *)((ulonglong)uVar36 * 8 + *(longlong *)(lVar37 + 0x38));
                    }
                    *(undefined8 *)(puVar28 + -8) = 0x10b83b;
                    uVar11 = func_0x(lVar24);
                    if (uVar36 < uVar11) {
                      *(undefined8 *)(puVar28 + -8) = 0x10b84a;
                      uVar11 = func_0x(lVar24);
                      iVar15 = uVar11 - uVar36;
                    }
                    else {
                      *(undefined8 *)(puVar28 + -8) = 0x10b856;
                      uVar11 = func_0x(lVar24);
                      iVar15 = 0;
                      if (uVar11 < uVar36) {
                        *(undefined8 *)(puVar28 + -8) = 0x10b873;
                        (*_DAT_)(6,0x5c,0x16);
                        iVar15 = 0;
                      }
                    }
                    *(undefined8 *)(puVar28 + -8) = 0x10b87b;
                    uVar10 = func_0x(lVar24);
                    *(undefined8 *)(puVar28 + -8) = 0x10b887;
                    uVar23 = func_0x(lVar24);
                    *(undefined8 *)(puVar28 + -8) = 0x10b88f;
                    iVar42 = func_0x(uVar23);
                    lVar37 = (longlong)iVar42 + *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    if ((lVar25 != 0) && (uVar36 != 0)) {
                      *(undefined8 *)(puVar28 + -8) = 0x10b8ad;
                      func_0x(lVar37,lVar25,uVar36);
                    }
                    if (iVar15 != 0) {
                      *(undefined8 *)(puVar28 + -8) = 0x10b8c1;
                      func_0x((ulonglong)uVar36 + lVar37,uVar10,iVar15);
                    }
                  }
                }
                else {
                  if ((iVar42 != 3) && (iVar42 != 4)) {
                    if (iVar42 == 8) {
                      *(undefined8 *)(puVar28 + -8) = 0x10b654;
                      sVar14 = func_0x(psVar2);
                      if (sVar14 == 0) {
                        uVar32 = *(undefined8 *)(&stack0x000000b0 + lVar20);
                        *(undefined8 *)(puVar28 + -8) = 0x10b672;
                        func_0x(psVar2,uVar23,uVar32);
                      }
                      else {
                        *(undefined4 *)(puVar28 + 0x28) = 0;
                        *(undefined8 *)(puVar28 + 0x20) = uVar23;
                        uVar23 = *(undefined8 *)(&stack0x000000b0 + lVar20);
                        *(undefined8 *)(puVar28 + -8) = 0x10b6a6;
                        func_0x((longlong)(-1 - iVar15) * 0x20 + lVar25,uVar23,1);
                      }
                    }
                    else {
                      *(undefined8 *)(puVar28 + 0x20) = 0x1525f20;
                      *(undefined8 *)(puVar28 + -8) = 0x10b646;
                      (*_DAT_)(1,0x192c2b0,0x1958c78);
                    }
                    goto LAB_;
                  }
                  *(undefined8 *)(puVar28 + -8) = 0x10b6b3;
                  iVar42 = func_0x(lVar24);
                  if ((iVar42 == 0) || (**(int **)(&stack0x000000b0 + lVar20) != 0)) {
                    *(undefined8 *)(puVar28 + -8) = 0x10b6d0;
                    iVar42 = func_0x(lVar24);
                    if ((iVar42 == 0) || ((*(byte *)(lVar37 + 0x14) & 8) == 0)) {
                      *(undefined8 *)(puVar28 + -8) = 0x10b6fd;
                      iVar42 = func_0x(lVar24);
                      if (iVar42 == 0) {
                        *(undefined8 *)(puVar28 + -8) = 0x10b72c;
                        uVar11 = func_0x(lVar24);
                        uVar36 = (uint)uVar11;
                      }
                      else {
                        *(undefined8 *)(puVar28 + -8) = 0x10b709;
                        uVar33 = func_0x();
                        uVar32 = *(undefined8 *)(&stack0x00000050 + lVar20);
                        *(undefined8 *)(puVar28 + -8) = 0x10b718;
                        uVar32 = func_0x(uVar32,lVar24);
                        *(undefined8 *)(puVar28 + -8) = 0x10b723;
                        uVar36 = func_0x(uVar32,uVar33);
                      }
                    }
                    else {
                      *(undefined8 *)(puVar28 + -8) = 0x10b6e2;
                      uVar36 = func_0x(lVar24);
                      uVar36 = *(uint *)((ulonglong)uVar36 * 8 + *(longlong *)(lVar37 + 0x38));
                    }
                  }
                  *(undefined8 *)(puVar28 + -8) = 0x10b737;
                  uVar11 = func_0x(lVar24);
                  if (uVar11 < uVar36) {
                    *(undefined8 *)(puVar28 + -8) = 0x10b754;
                    (*_DAT_)(6,0x52,0x16);
                  }
                  *(undefined4 *)(puVar28 + 0x28) = 0;
                  *(undefined8 *)(puVar28 + 0x20) = uVar23;
                  uVar23 = *(undefined8 *)(&stack0x000000b0 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x10b782;
                  func_0x((longlong)(-1 - iVar15) * 0x20 + lVar25,uVar23,uVar36);
                }
                lVar37 = *(longlong *)(&stack0x00000050 + lVar20);
              }
LAB_:
              lVar24 = lVar24 + 0x50;
              uVar58 = uVar58 - 1;
              lVar25 = *(longlong *)(&stack0x00000080 + lVar20);
            } while (uVar58 != 0);
            uVar36 = *(uint *)(&stack0x00000048 + lVar20);
          }
          puVar22 = (undefined2 *)0x0;
          if (uVar36 != 0) {
            lVar25 = *(longlong *)(&stack0x00000080 + lVar20);
            if (*psVar2 == 0) {
LAB_:
              uVar40 = uVar36;
              uVar36 = uVar40 - 1;
              if (*(int *)(lVar25 + 8 + (ulonglong)uVar36 * 0x20) == 0) goto code_r0x0010b914;
              *(short *)(&stack0x0000002c + lVar20) = (short)uVar40;
              iVar15 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + uVar40 * 2;
              *(int *)(&stack0x00000028 + lVar20) = iVar15;
              *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar15;
              *(undefined8 *)(puVar28 + -8) = 0x10b99c;
              pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              *pbVar27 = *pbVar27 | 0x20;
              uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
              if (uVar36 < 0x3f3d) {
                *(undefined8 *)(puVar28 + -8) = 0x10b9b3;
                puVar22 = (undefined2 *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                *puVar22 = (short)uVar40;
                uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
              }
              uVar18 = 0;
              if (uVar40 != 0) {
                puVar48 = (uint *)(lVar25 + 0xc);
                do {
                  uVar58 = (ulonglong)uVar36;
                  lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                  uVar41 = puVar48[-1];
                  uVar36 = uVar36 + uVar41;
                  *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar36;
                  if (uVar36 < 0x3f3d) {
                    uVar38 = *puVar48;
                    *(undefined8 *)(puVar28 + -8) = 0x10b9fe;
                    func_0x(puVar22 + 1,uVar18,uVar36,uVar38 & 1);
                    uVar23 = *(undefined8 *)(puVar48 + -3);
                    *(undefined8 *)(puVar28 + -8) = 0x10ba10;
                    func_0x(uVar58 + lVar25,uVar41,uVar23,uVar41);
                    uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                  }
                  uVar18 = uVar18 + 1;
                  puVar48 = puVar48 + 8;
                } while (uVar18 < uVar40);
              }
              *(uint *)(&stack0x00000150 + lVar20) = uVar36;
              uVar40 = (uint)(uVar36 < 0x3f3d);
              goto LAB_;
            }
            *(undefined **)(puVar28 + 0x28) = &stack0x00000150 + lVar20;
            *(longlong *)(puVar28 + 0x20) = lVar25;
            *(undefined8 *)(puVar28 + -8) = 0x10ba56;
            uVar40 = func_0x((longlong)&sStackX_10 + lVar20 + 2,0x3f3c,0x3f3c,uVar36);
LAB_:
            uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
LAB_:
            if (uVar40 != 0) goto LAB_;
            uVar23 = 0xb9;
LAB_:
            *(undefined8 *)(puVar28 + -8) = 0x10ba76;
            (*_DAT_)(6,0x52,0x16,uVar23);
          }
          uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
        }
LAB_:
        if (*psVar2 == 0) {
          if (uVar36 == 0) {
            iVar15 = 0;
            *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
            *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                 *(undefined4 *)((longlong)&uStackX_20 + lVar20);
            *(undefined8 *)(puVar28 + -8) = 0x10baa3;
            pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
            uVar36 = 0;
            if ((*pbVar27 & 0x10) != 0) {
              *(undefined8 *)(puVar28 + -8) = 0x10bab1;
              pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              if ((*pbVar27 & 0x10) != 0) {
                uVar36 = (uint)*(ushort *)
                                (*(longlong *)((longlong)&pbStackX_18 + lVar20) +
                                (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20));
              }
              *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                   (uVar36 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
            }
            *(undefined8 *)(puVar28 + -8) = 0x10bae0;
            pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if ((*pbVar27 & 0x20) == 0) {
              uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
              *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
              *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
              *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
            }
            else {
              *(undefined8 *)(puVar28 + -8) = 0x10baf2;
              puVar45 = (ushort *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              uVar11 = *puVar45;
              *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
              if (uVar11 == 0) {
                *(undefined8 *)(puVar28 + -8) = 0x10bb10;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 != '\0') {
                  *(undefined8 *)(puVar28 + -8) = 0x10bb19;
                  cVar8 = func_0x();
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x10bb29;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 == '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x10bb45;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar28 + 0x20) = 0;
                      *(undefined8 *)(puVar28 + -8) = 0x10bb6b;
                      (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
                    }
                  }
                }
                uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar28 + -8) = 0x10bb79;
                func_0x(uVar23,3);
                uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
              }
              uVar36 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar11 * 2;
              *(uint *)(&stack0x00000028 + lVar20) = uVar36;
              if (0x1f9e < uVar36) {
                *(undefined8 *)(puVar28 + -8) = 0x10bba2;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 != '\0') {
                  *(undefined8 *)(puVar28 + -8) = 0x10bbab;
                  cVar8 = func_0x();
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x10bbbb;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 == '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x10bbd7;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar28 + 0x20) = 0;
                      *(undefined8 *)(puVar28 + -8) = 0x10bbfd;
                      (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
                    }
                  }
                }
                uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar28 + -8) = 0x10bc0b;
                func_0x(uVar23,4);
                uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
              }
              puVar45 = puVar45 + 1;
              *(undefined8 *)(puVar28 + -8) = 0x10bc23;
              uVar11 = func_0x(puVar45,(ulonglong)uVar11 - 1);
              *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar11;
              uVar36 = *(uint *)(&stack0x00000028 + lVar20);
              if (uVar11 < uVar36) {
                *(undefined8 *)(puVar28 + -8) = 0x10bc3c;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 != '\0') {
                  *(undefined8 *)(puVar28 + -8) = 0x10bc45;
                  cVar8 = func_0x();
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x10bc55;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 == '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x10bc71;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar28 + 0x20) = 0;
                      *(undefined8 *)(puVar28 + -8) = 0x10bc97;
                      (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
                    }
                  }
                }
                uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar28 + -8) = 0x10bca5;
                func_0x(uVar23,4);
                uVar36 = *(uint *)(&stack0x00000028 + lVar20);
              }
              uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
              iVar42 = iVar15;
              if (uVar11 != 0) {
                do {
                  *(undefined8 *)(puVar28 + -8) = 0x10bccb;
                  uVar11 = func_0x(puVar45,(longlong)iVar42);
                  bVar62 = uVar11 < uVar36;
                  uVar36 = (uint)uVar11;
                  if ((bVar62) ||
                     (uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
                     uVar40 <= uVar11 && uVar36 != uVar40)) {
                    *(undefined8 *)(puVar28 + -8) = 0x10bce3;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x10bcec;
                      cVar8 = func_0x();
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x10bcfc;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x10bd18;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar28 + 0x20) = 0;
                          *(undefined8 *)(puVar28 + -8) = 0x10bd3e;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x10bd4c;
                    func_0x(uVar23,4);
                  }
                  iVar42 = iVar42 + 1;
                  uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                } while (iVar42 < (int)(uint)uVar11);
              }
              while( true ) {
                *(undefined8 *)(puVar28 + -8) = 0x10bd6f;
                iVar42 = func_0x(puVar45,uVar11 - 1);
                if (iVar42 == 0) break;
                uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                *(undefined8 *)(puVar28 + -8) = 0x10bd84;
                lVar25 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if (uVar11 == 1) {
                  uVar40 = *(uint *)(&stack0x00000028 + lVar20);
                }
                else {
                  *(undefined8 *)(puVar28 + -8) = 0x10bd9e;
                  uVar54 = func_0x(lVar25 + 2,(ulonglong)uVar11 - 2);
                  uVar40 = (uint)uVar54;
                }
                *(undefined8 *)(puVar28 + -8) = 0x10bdae;
                uVar11 = func_0x(lVar25 + 2,(ulonglong)uVar11 - 1);
                uVar18 = *(uint *)(&stack0x00000028 + lVar20);
                if (((uVar40 < uVar18) || (uVar11 < uVar40)) ||
                   (uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
                   uVar36 <= uVar11 && uVar11 != uVar36)) {
                  uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x10bdd1;
                  func_0x(uVar23,7);
                  uVar18 = *(uint *)(&stack0x00000028 + lVar20);
                  uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                }
                if ((uVar40 < uVar18) || (uVar36 < uVar40)) goto LAB_;
                lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                uVar54 = *(ushort *)(lVar25 + (ulonglong)uVar40);
                if (uVar54 == 5) {
                  puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                  *puVar45 = *puVar45 | 2;
                  *(short *)(&stack0x0000002c + lVar20) = *(short *)(&stack0x0000002c + lVar20) + -1
                  ;
                  *(short *)(&stack0x0000003a + lVar20) = (short)uVar40;
                  lVar25 = (ulonglong)(uVar40 & 0xffff) + lVar25;
                  *(undefined8 *)(puVar28 + -8) = 0x10be3f;
                  iVar42 = func_0x(lVar25);
                  if (iVar42 == 0) {
                    *(ushort *)(&stack0x0000003c + lVar20) =
                         *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                  }
                  else {
                    *(undefined8 *)(puVar28 + -8) = 0x10be4b;
                    sVar14 = func_0x(lVar25);
                    *(ushort *)(&stack0x0000003c + lVar20) =
                         *(ushort *)(&stack0x0000003c + lVar20) ^
                         (sVar14 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
                  }
                  *(undefined8 *)(puVar28 + -8) = 0x10be80;
                  uVar13 = func_0x(lVar25);
                  uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                  uVar13 = (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff ^ uVar54;
                  uVar43 = (ulonglong)uVar13;
                  *(ushort *)(&stack0x0000003c + lVar20) = uVar13;
                  uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                  lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                  uVar58 = (uVar54 >> 0xb & 7) * 2 + uVar47 + ((uVar43 & 0x7ff) + 2) * 2 + lVar25;
                  if (uVar58 < lVar25 + uVar47) {
                    *(undefined8 *)(puVar28 + -8) = 0x10bed8;
                    func_0x(lVar25 + uVar47,0x19);
                    uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                    uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                    lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                  }
                  if (uVar11 - uVar40 <
                      (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar47) -
                      *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)uVar58) {
                    *(undefined8 *)(puVar28 + -8) = 0x10bf0e;
                    func_0x(uVar47 + lVar25,0x19);
                    uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                    uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                    lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                  }
                  if (((uVar43 & 0x3800) != 0) && ((uVar43 & 0x3800) != 0)) {
                    do {
                      *(undefined8 *)(puVar28 + -8) = 0x10bf4b;
                      uVar11 = func_0x(uVar47 + lVar25 + 4,iVar15);
                      if ((*(ushort *)(&stack0x0000003c + lVar20) & 0x7ff) < uVar11) {
                        uVar11 = *(ushort *)(&stack0x0000003a + lVar20);
                        lVar24 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                        *(undefined8 *)(puVar28 + -8) = 0x10bf6a;
                        func_0x((ulonglong)uVar11 + lVar24,0x1a);
                      }
                      iVar15 = iVar15 + 1;
                    } while (iVar15 < (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7));
                  }
                  break;
                }
                if (uVar54 < 0x400) break;
                puVar60 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                *puVar60 = *puVar60 | 1;
                uVar11 = *(short *)(&stack0x0000002c + lVar20) - 1;
                *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                if (uVar11 == 0) break;
              }
            }
            *(undefined8 *)(puVar28 + -8) = 0x10bf92;
            iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if (iVar15 == 0) {
              *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
              uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
            }
            else {
              iVar15 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
              *(int *)(&stack0x00000036 + lVar20) = iVar15;
              *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar15 + 0xe;
              *(undefined8 *)(puVar28 + -8) = 0x10bfab;
              uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
              *(undefined8 *)(puVar28 + -8) = 0x10bfba;
              func_0x(uVar23,&stack0x00000260 + lVar20);
              *(undefined8 *)(puVar28 + -8) = 0x10bfc6;
              iVar15 = func_0x(&stack0x00000260 + lVar20);
              uVar36 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar15;
              *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar36;
            }
            if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
               (*(ulonglong *)(&stack0x0000002e + lVar20) <
                (ulonglong)uVar36 + *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
              *(undefined8 *)(puVar28 + -8) = 0x10bffb;
              cVar8 = func_0x(0x1ebafb0);
              if (cVar8 != '\0') {
                *(undefined8 *)(puVar28 + -8) = 0x10c004;
                cVar8 = func_0x();
                if (cVar8 != '\0') {
                  *(undefined8 *)(puVar28 + -8) = 0x10c014;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 == '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x10c030;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar28 + 0x20) = 0;
                    *(undefined8 *)(puVar28 + -8) = 0x10c056;
                    (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
                  }
                }
              }
              uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
              *(undefined8 *)(puVar28 + -8) = 0x10c064;
              func_0x(uVar23,0x12);
              uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
            }
            if (0x3f3b < uVar36 - 1) {
              *(undefined8 *)(puVar28 + -8) = 0x10c07d;
              cVar8 = func_0x(0x1ebafb0);
              if (cVar8 != '\0') {
                *(undefined8 *)(puVar28 + -8) = 0x10c086;
                cVar8 = func_0x();
                if (cVar8 != '\0') {
                  *(undefined8 *)(puVar28 + -8) = 0x10c096;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 == '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x10c0b2;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar28 + 0x20) = 0;
                    *(undefined8 *)(puVar28 + -8) = 0x10c0d8;
                    (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
                  }
                }
              }
              uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
              *(undefined8 *)(puVar28 + -8) = 0x10c0e6;
              func_0x(uVar23,5);
              uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
            }
          }
LAB_:
          if (uVar36 < 9) {
            *(undefined8 *)(puVar28 + -8) = 0x10c0f7;
            cVar8 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if ((cVar8 == '\0') ||
               (uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4), cVar8 == '\f')) {
              uVar36 = 9;
            }
          }
          *(undefined8 *)(puVar28 + -8) = 0x10c110;
          iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
          uVar40 = *(uint *)(&stack0x00000036 + lVar20);
        }
        else {
          *(undefined8 *)(puVar28 + -8) = 0x10c11e;
          func_0x((longlong)&sStackX_10 + lVar20 + 2);
          *(undefined8 *)(puVar28 + -8) = 0x10c127;
          uVar36 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
          *(undefined8 *)(puVar28 + -8) = 0x10c132;
          iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
          uVar40 = *(uint *)(&stack0x00000040 + lVar20);
        }
        if (iVar15 == 0) {
          uVar40 = uVar36;
        }
        if (0x1f7c < uVar40) {
          uVar23 = *(undefined8 *)(&stack0x00000090 + lVar20);
          *(undefined8 *)(puVar28 + -8) = 0x10c156;
          func_0x(uVar23,psVar2);
          if (*psVar2 == 0) {
            uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
            if (uVar40 == 0) {
              iVar15 = 0;
              *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
              *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                   *(undefined4 *)((longlong)&uStackX_20 + lVar20);
              *(undefined8 *)(puVar28 + -8) = 0x10c183;
              pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              uVar36 = 0;
              if ((*pbVar27 & 0x10) != 0) {
                *(undefined8 *)(puVar28 + -8) = 0x10c191;
                pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if ((*pbVar27 & 0x10) != 0) {
                  uVar36 = (uint)*(ushort *)
                                  (*(longlong *)((longlong)&pbStackX_18 + lVar20) +
                                  (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20));
                }
                *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                     (uVar36 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
              }
              *(undefined8 *)(puVar28 + -8) = 0x10c1c0;
              pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
              if ((*pbVar27 & 0x20) == 0) {
                uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
                *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
                *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
              }
              else {
                *(undefined8 *)(puVar28 + -8) = 0x10c1d2;
                puVar45 = (ushort *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                uVar11 = *puVar45;
                *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                if (uVar11 == 0) {
                  *(undefined8 *)(puVar28 + -8) = 0x10c1f0;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x10c1f9;
                    cVar8 = func_0x();
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x10c209;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x10c225;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar28 + 0x20) = 0;
                        *(undefined8 *)(puVar28 + -8) = 0x10c24b;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x10c259;
                  func_0x(uVar23,3);
                  uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                }
                uVar36 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar11 * 2;
                *(uint *)(&stack0x00000028 + lVar20) = uVar36;
                if (0x1f9e < uVar36) {
                  *(undefined8 *)(puVar28 + -8) = 0x10c282;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x10c28b;
                    cVar8 = func_0x();
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x10c29b;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x10c2b7;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar28 + 0x20) = 0;
                        *(undefined8 *)(puVar28 + -8) = 0x10c2dd;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x10c2eb;
                  func_0x(uVar23,4);
                  uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                }
                puVar45 = puVar45 + 1;
                *(undefined8 *)(puVar28 + -8) = 0x10c303;
                uVar11 = func_0x(puVar45,(ulonglong)uVar11 - 1);
                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar11;
                uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                if (uVar11 < uVar36) {
                  *(undefined8 *)(puVar28 + -8) = 0x10c31c;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x10c325;
                    cVar8 = func_0x();
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x10c335;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x10c351;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar28 + 0x20) = 0;
                        *(undefined8 *)(puVar28 + -8) = 0x10c377;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x10c385;
                  func_0x(uVar23,4);
                  uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                }
                uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                iVar42 = iVar15;
                if (uVar11 != 0) {
                  do {
                    *(undefined8 *)(puVar28 + -8) = 0x10c3ab;
                    uVar11 = func_0x(puVar45,(longlong)iVar42);
                    bVar62 = uVar11 < uVar36;
                    uVar36 = (uint)uVar11;
                    if ((bVar62) ||
                       (uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
                       uVar40 <= uVar11 && uVar36 != uVar40)) {
                      *(undefined8 *)(puVar28 + -8) = 0x10c3c3;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x10c3cc;
                        cVar8 = func_0x();
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x10c3dc;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x10c3f8;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar28 + 0x20) = 0;
                            *(undefined8 *)(puVar28 + -8) = 0x10c41e;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                          }
                        }
                      }
                      uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x10c42c;
                      func_0x(uVar23,4);
                    }
                    iVar42 = iVar42 + 1;
                    uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                  } while (iVar42 < (int)(uint)uVar11);
                }
                while( true ) {
                  *(undefined8 *)(puVar28 + -8) = 0x10c44f;
                  iVar42 = func_0x(puVar45,uVar11 - 1);
                  if (iVar42 == 0) break;
                  uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x10c464;
                  lVar25 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if (uVar11 == 1) {
                    uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                  }
                  else {
                    *(undefined8 *)(puVar28 + -8) = 0x10c480;
                    uVar54 = func_0x(lVar25 + 2,(ulonglong)uVar11 - 2);
                    uVar36 = (uint)uVar54;
                  }
                  *(undefined8 *)(puVar28 + -8) = 0x10c490;
                  uVar11 = func_0x(lVar25 + 2,(ulonglong)(uint)uVar11 - 1);
                  uVar18 = *(uint *)(&stack0x00000028 + lVar20);
                  if (((uVar36 < uVar18) || (uVar11 < uVar36)) ||
                     (uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
                     uVar40 <= uVar11 && uVar11 != uVar40)) {
                    uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x10c4b3;
                    func_0x(uVar23,7);
                    uVar18 = *(uint *)(&stack0x00000028 + lVar20);
                    uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                  }
                  if ((uVar36 < uVar18) || (uVar40 < uVar36)) goto LAB_;
                  lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                  uVar54 = *(ushort *)(lVar25 + (ulonglong)uVar36);
                  if (uVar54 == 5) {
                    puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                    *puVar45 = *puVar45 | 2;
                    *(short *)(&stack0x0000002c + lVar20) =
                         *(short *)(&stack0x0000002c + lVar20) + -1;
                    *(short *)(&stack0x0000003a + lVar20) = (short)uVar36;
                    lVar25 = (ulonglong)(uVar36 & 0xffff) + lVar25;
                    *(undefined8 *)(puVar28 + -8) = 0x10c521;
                    iVar42 = func_0x(lVar25);
                    if (iVar42 == 0) {
                      *(ushort *)(&stack0x0000003c + lVar20) =
                           *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                    }
                    else {
                      *(undefined8 *)(puVar28 + -8) = 0x10c52d;
                      sVar14 = func_0x(lVar25);
                      *(ushort *)(&stack0x0000003c + lVar20) =
                           *(ushort *)(&stack0x0000003c + lVar20) ^
                           (sVar14 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
                    }
                    *(undefined8 *)(puVar28 + -8) = 0x10c562;
                    uVar13 = func_0x(lVar25);
                    uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                    uVar13 = (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff ^ uVar54;
                    uVar43 = (ulonglong)uVar13;
                    *(ushort *)(&stack0x0000003c + lVar20) = uVar13;
                    uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                    lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    uVar58 = (uVar54 >> 0xb & 7) * 2 + uVar47 + ((uVar43 & 0x7ff) + 2) * 2 + lVar25;
                    if (uVar58 < lVar25 + uVar47) {
                      *(undefined8 *)(puVar28 + -8) = 0x10c5ba;
                      func_0x(lVar25 + uVar47,0x19);
                      uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                      uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                      lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    }
                    if (uVar11 - uVar36 <
                        (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar47) -
                        *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)uVar58) {
                      *(undefined8 *)(puVar28 + -8) = 0x10c5f0;
                      func_0x(uVar47 + lVar25,0x19);
                      uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                      uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                      lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    }
                    if (((uVar43 & 0x3800) != 0) && ((uVar43 & 0x3800) != 0)) {
                      do {
                        *(undefined8 *)(puVar28 + -8) = 0x10c62b;
                        uVar11 = func_0x(uVar47 + lVar25 + 4,iVar15);
                        if ((*(ushort *)(&stack0x0000003c + lVar20) & 0x7ff) < uVar11) {
                          uVar11 = *(ushort *)(&stack0x0000003a + lVar20);
                          lVar24 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                          *(undefined8 *)(puVar28 + -8) = 0x10c64a;
                          func_0x((ulonglong)uVar11 + lVar24,0x1a);
                        }
                        iVar15 = iVar15 + 1;
                      } while (iVar15 < (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7));
                    }
                    break;
                  }
                  if (uVar54 < 0x400) break;
                  puVar60 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                  *puVar60 = *puVar60 | 1;
                  uVar11 = *(short *)(&stack0x0000002c + lVar20) - 1;
                  *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                  if (uVar11 == 0) break;
                }
              }
              *(undefined8 *)(puVar28 + -8) = 0x10c672;
              iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
              if (iVar15 == 0) {
                *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
              }
              else {
                iVar15 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                *(int *)(&stack0x00000036 + lVar20) = iVar15;
                *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar15 + 0xe;
                *(undefined8 *)(puVar28 + -8) = 0x10c68b;
                uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                *(undefined8 *)(puVar28 + -8) = 0x10c69a;
                func_0x(uVar23,&stack0x00000268 + lVar20);
                *(undefined8 *)(puVar28 + -8) = 0x10c6a6;
                iVar15 = func_0x(&stack0x00000268 + lVar20);
                uVar40 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar15;
                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar40;
              }
              if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
                 (*(ulonglong *)(&stack0x0000002e + lVar20) <
                  (ulonglong)uVar40 + *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
                *(undefined8 *)(puVar28 + -8) = 0x10c6db;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 != '\0') {
                  *(undefined8 *)(puVar28 + -8) = 0x10c6e4;
                  cVar8 = func_0x();
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x10c6f4;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 == '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x10c710;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar28 + 0x20) = 0;
                      *(undefined8 *)(puVar28 + -8) = 0x10c736;
                      (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
                    }
                  }
                }
                uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar28 + -8) = 0x10c744;
                func_0x(uVar23,0x12);
                uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
              }
              if (0x3f3b < uVar40 - 1) {
                *(undefined8 *)(puVar28 + -8) = 0x10c75d;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 != '\0') {
                  *(undefined8 *)(puVar28 + -8) = 0x10c766;
                  cVar8 = func_0x();
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x10c776;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 == '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x10c792;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar28 + 0x20) = 0;
                      *(undefined8 *)(puVar28 + -8) = 0x10c7b8;
                      (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
                    }
                  }
                }
                uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar28 + -8) = 0x10c7c6;
                func_0x(uVar23,5);
                uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
              }
            }
LAB_:
            if (uVar40 < 9) {
              *(undefined8 *)(puVar28 + -8) = 0x10c7d7;
              cVar8 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
              if ((cVar8 == '\0') ||
                 (uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4), cVar8 == '\f')) {
                uVar40 = 9;
              }
            }
            *(undefined8 *)(puVar28 + -8) = 0x10c7f0;
            iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            uVar36 = *(uint *)(&stack0x00000036 + lVar20);
            if (iVar15 == 0) {
              uVar36 = uVar40;
            }
          }
          else {
            *(undefined8 *)(puVar28 + -8) = 0x10c803;
            func_0x((longlong)&sStackX_10 + lVar20 + 2);
            *(undefined8 *)(puVar28 + -8) = 0x10c80c;
            uVar40 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            *(undefined8 *)(puVar28 + -8) = 0x10c817;
            iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            uVar36 = *(uint *)(&stack0x00000040 + lVar20);
            if (iVar15 == 0) {
              uVar36 = uVar40;
            }
          }
          if (0x1f7c < uVar36) {
            if (*psVar2 == 0) {
              uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
              if (uVar36 == 0) {
                iVar15 = 0;
                *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                     *(undefined4 *)((longlong)&uStackX_20 + lVar20);
                *(undefined8 *)(puVar28 + -8) = 0x10c858;
                pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                uVar36 = 0;
                if ((*pbVar27 & 0x10) != 0) {
                  *(undefined8 *)(puVar28 + -8) = 0x10c866;
                  pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if ((*pbVar27 & 0x10) != 0) {
                    uVar36 = (uint)*(ushort *)
                                    (*(longlong *)((longlong)&pbStackX_18 + lVar20) +
                                    (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20));
                  }
                  *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                       (uVar36 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
                }
                *(undefined8 *)(puVar28 + -8) = 0x10c895;
                pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if ((*pbVar27 & 0x20) == 0) {
                  uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
                  *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
                  *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                  *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
                }
                else {
                  *(undefined8 *)(puVar28 + -8) = 0x10c8a7;
                  puVar45 = (ushort *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  uVar11 = *puVar45;
                  *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                  if (uVar11 == 0) {
                    *(undefined8 *)(puVar28 + -8) = 0x10c8c5;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x10c8ce;
                      cVar8 = func_0x();
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x10c8de;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x10c8fa;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(puVar28 + 0x20) = 0;
                          *(undefined8 *)(puVar28 + -8) = 0x10c920;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x10c92e;
                    func_0x(uVar23,3);
                    uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                  }
                  uVar36 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar11 * 2;
                  *(uint *)(&stack0x00000028 + lVar20) = uVar36;
                  if (0x1f9e < uVar36) {
                    *(undefined8 *)(puVar28 + -8) = 0x10c957;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x10c960;
                      cVar8 = func_0x();
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x10c970;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x10c98c;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar28 + 0x20) = 0;
                          *(undefined8 *)(puVar28 + -8) = 0x10c9b2;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x10c9c0;
                    func_0x(uVar23,4);
                    uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                  }
                  puVar45 = puVar45 + 1;
                  *(undefined8 *)(puVar28 + -8) = 0x10c9d8;
                  uVar11 = func_0x(puVar45,(ulonglong)uVar11 - 1);
                  *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar11;
                  uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                  if (uVar11 < uVar36) {
                    *(undefined8 *)(puVar28 + -8) = 0x10c9f1;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x10c9fa;
                      cVar8 = func_0x();
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x10ca0a;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x10ca26;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar28 + 0x20) = 0;
                          *(undefined8 *)(puVar28 + -8) = 0x10ca4c;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x10ca5a;
                    func_0x(uVar23,4);
                    uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                  }
                  uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                  iVar42 = iVar15;
                  if (uVar11 != 0) {
                    do {
                      *(undefined8 *)(puVar28 + -8) = 0x10ca7b;
                      uVar11 = func_0x(puVar45,(longlong)iVar42);
                      bVar62 = uVar11 < uVar36;
                      uVar36 = (uint)uVar11;
                      if ((bVar62) ||
                         (uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
                         uVar40 <= uVar11 && uVar36 != uVar40)) {
                        *(undefined8 *)(puVar28 + -8) = 0x10ca93;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x10ca9c;
                          cVar8 = func_0x();
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x10caac;
                            cVar8 = func_0x(0x1ebafb0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar28 + -8) = 0x10cac8;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar28 + 0x20) = 0;
                              *(undefined8 *)(puVar28 + -8) = 0x10caee;
                              (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                            }
                          }
                        }
                        uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                        *(undefined8 *)(puVar28 + -8) = 0x10cafc;
                        func_0x(uVar23,4);
                      }
                      iVar42 = iVar42 + 1;
                      uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                    } while (iVar42 < (int)(uint)uVar11);
                  }
                  while( true ) {
                    *(undefined8 *)(puVar28 + -8) = 0x10cb1f;
                    iVar42 = func_0x(puVar45,uVar11 - 1);
                    if (iVar42 == 0) break;
                    uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x10cb34;
                    lVar25 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    if (uVar11 == 1) {
                      uVar40 = *(uint *)(&stack0x00000028 + lVar20);
                    }
                    else {
                      *(undefined8 *)(puVar28 + -8) = 0x10cb50;
                      uVar54 = func_0x(lVar25 + 2,(ulonglong)uVar11 - 2);
                      uVar40 = (uint)uVar54;
                    }
                    *(undefined8 *)(puVar28 + -8) = 0x10cb60;
                    uVar11 = func_0x(lVar25 + 2,(ulonglong)(uint)uVar11 - 1);
                    uVar18 = *(uint *)(&stack0x00000028 + lVar20);
                    if (((uVar40 < uVar18) || (uVar11 < uVar40)) ||
                       (uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
                       uVar36 <= uVar11 && uVar11 != uVar36)) {
                      uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x10cb83;
                      func_0x(uVar23,7);
                      uVar18 = *(uint *)(&stack0x00000028 + lVar20);
                      uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                    }
                    if ((uVar40 < uVar18) || (uVar36 < uVar40)) goto LAB_;
                    lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    uVar54 = *(ushort *)(lVar25 + (ulonglong)uVar40);
                    if (uVar54 == 5) {
                      puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                      *puVar45 = *puVar45 | 2;
                      *(short *)(&stack0x0000002c + lVar20) =
                           *(short *)(&stack0x0000002c + lVar20) + -1;
                      *(short *)(&stack0x0000003a + lVar20) = (short)uVar40;
                      lVar25 = (ulonglong)(uVar40 & 0xffff) + lVar25;
                      *(undefined8 *)(puVar28 + -8) = 0x10cbf1;
                      iVar42 = func_0x(lVar25);
                      if (iVar42 == 0) {
                        *(ushort *)(&stack0x0000003c + lVar20) =
                             *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                      }
                      else {
                        *(undefined8 *)(puVar28 + -8) = 0x10cbfd;
                        sVar14 = func_0x(lVar25);
                        *(ushort *)(&stack0x0000003c + lVar20) =
                             *(ushort *)(&stack0x0000003c + lVar20) ^
                             (sVar14 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
                      }
                      *(undefined8 *)(puVar28 + -8) = 0x10cc32;
                      uVar13 = func_0x(lVar25);
                      uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                      uVar13 = (*(ushort *)(&stack0x0000003c + lVar20) ^ uVar13) & 0x7ff ^ uVar54;
                      uVar43 = (ulonglong)uVar13;
                      *(ushort *)(&stack0x0000003c + lVar20) = uVar13;
                      uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                      lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                      uVar58 = (uVar54 >> 0xb & 7) * 2 + uVar47 + ((uVar43 & 0x7ff) + 2) * 2 +
                               lVar25;
                      if (uVar58 < uVar47 + lVar25) {
                        *(undefined8 *)(puVar28 + -8) = 0x10cc89;
                        func_0x(uVar47 + lVar25,0x19);
                        uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                        uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                        lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                      }
                      if (uVar11 - uVar40 <
                          (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar47) -
                          *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)uVar58) {
                        *(undefined8 *)(puVar28 + -8) = 0x10ccbe;
                        func_0x(uVar47 + lVar25,0x19);
                        uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                        uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                        lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                      }
                      if (((uVar43 & 0x3800) != 0) && ((uVar43 & 0x3800) != 0)) {
                        do {
                          *(undefined8 *)(puVar28 + -8) = 0x10ccfb;
                          uVar11 = func_0x(uVar47 + lVar25 + 4,iVar15);
                          if ((*(ushort *)(&stack0x0000003c + lVar20) & 0x7ff) < uVar11) {
                            uVar11 = *(ushort *)(&stack0x0000003a + lVar20);
                            lVar24 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                            *(undefined8 *)(puVar28 + -8) = 0x10cd19;
                            func_0x((ulonglong)uVar11 + lVar24,0x1a);
                          }
                          iVar15 = iVar15 + 1;
                        } while (iVar15 < (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7));
                      }
                      break;
                    }
                    if (uVar54 < 0x400) break;
                    puVar60 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                    *puVar60 = *puVar60 | 1;
                    uVar11 = *(short *)(&stack0x0000002c + lVar20) - 1;
                    *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                    if (uVar11 == 0) break;
                  }
                }
                *(undefined8 *)(puVar28 + -8) = 0x10cd41;
                iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if (iVar15 == 0) {
                  *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                  uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                }
                else {
                  iVar15 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                  *(int *)(&stack0x00000036 + lVar20) = iVar15;
                  *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar15 + 0xe;
                  *(undefined8 *)(puVar28 + -8) = 0x10cd5a;
                  uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  *(undefined8 *)(puVar28 + -8) = 0x10cd69;
                  func_0x(uVar23,&stack0x00000270 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x10cd75;
                  iVar15 = func_0x(&stack0x00000270 + lVar20);
                  uVar36 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar15;
                  *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar36;
                }
                if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
                   (*(ulonglong *)(&stack0x0000002e + lVar20) <
                    (ulonglong)uVar36 + *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
                  *(undefined8 *)(puVar28 + -8) = 0x10cdaa;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x10cdb3;
                    cVar8 = func_0x();
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x10cdc3;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x10cddf;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(puVar28 + 0x20) = 0;
                        *(undefined8 *)(puVar28 + -8) = 0x10ce05;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x10ce13;
                  func_0x(uVar23,0x12);
                  uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                }
                if (0x3f3b < uVar36 - 1) {
                  *(undefined8 *)(puVar28 + -8) = 0x10ce2c;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x10ce35;
                    cVar8 = func_0x();
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x10ce45;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x10ce61;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(puVar28 + 0x20) = 0;
                        *(undefined8 *)(puVar28 + -8) = 0x10ce87;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x10ce95;
                  func_0x(uVar23,5);
                  uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                }
              }
LAB_:
              if (uVar36 < 9) {
                *(undefined8 *)(puVar28 + -8) = 0x10cea6;
                cVar8 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if ((cVar8 == '\0') || (cVar8 == '\f')) {
                  uVar36 = 9;
                }
                else {
                  uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                }
              }
            }
            else {
              *(undefined8 *)(puVar28 + -8) = 0x10cec5;
              uVar36 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            }
            *(undefined8 *)(puVar28 + -8) = 0x10ced7;
            func_0x(7,uVar36,0x1f7c);
          }
        }
        goto LAB_;
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1001de;
      puVar22 = (undefined2 *)(*pcVar4)();
      *(undefined2 **)(&stack0x00000060 + lVar20) = puVar22;
      *puVar22 = 0;
      puVar45 = puVar22 + 1;
      *psVar2 = 0;
      lVar25 = *param_3;
      *(longlong *)(&stack0x00000070 + lVar20) = lVar25;
      puVar50 = &stack0xffffffffffffffc0 + lVar20;
      if ((*(byte *)(lVar25 + 0x38) & 0x20) == 0) {
        if (((**(byte **)(puVar22 + 4) & 0xe) == 2) && ((**(byte **)(puVar22 + 4) & 0x40) != 0)) {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100228;
          uVar23 = func_0x(puVar45,&stack0x000002e0 + lVar20);
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100230;
          iVar15 = func_0x(uVar23);
          if (iVar15 == 0) goto LAB_;
          bVar62 = true;
        }
        else {
LAB_:
          bVar62 = false;
        }
        if (((*(byte *)(lVar25 + 0x5c) & 2) == 0) &&
           (*(uint *)(puVar22 + 8) == *(uint *)(lVar25 + 0x14))) {
          uVar40 = uVar36;
          if ((**(byte **)(puVar22 + 4) & 0x10) != 0) {
            uVar40 = (uint)*(ushort *)(*(byte **)(puVar22 + 4) + *(uint *)(puVar22 + 8));
          }
          if ((uVar40 == *(ushort *)
                          (*(longlong *)(*(longlong *)(&stack0x00000090 + lVar20) + 8) + 0xcc)) &&
             (!bVar62)) {
            uVar36 = *(uint *)(puVar22 + 2);
            if (uVar36 == 0) {
              *puVar45 = 0;
              uVar36 = *(uint *)(puVar22 + 8);
              uVar58 = (ulonglong)uVar36;
              *(uint *)(puVar22 + 10) = uVar36;
              pbVar27 = *(byte **)(puVar22 + 4);
              bVar7 = *pbVar27;
              pbVar55 = pbVar27;
              if ((bVar7 & 0x10) != 0) {
                uVar36 = (*(ushort *)(pbVar27 + uVar58) + 7 >> 3) + uVar36 + 2;
                *(uint *)(puVar22 + 10) = uVar36;
                uVar58 = (ulonglong)uVar36;
                bVar7 = *pbVar27;
                pbVar55 = *(byte **)(puVar22 + 4);
              }
              puVar56 = puVar22;
              if ((bVar7 & 0x20) == 0) {
                *(int *)(puVar22 + 2) = (int)uVar58;
                puVar22[0xe] = 0;
                *(uint *)(puVar22 + 0xc) = uVar36;
              }
              else {
                puVar60 = (ushort *)(pbVar27 + uVar58);
                uVar11 = *puVar60;
                puVar22[0xe] = uVar11;
                if (uVar11 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100303;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10030c;
                    lVar24 = func_0x();
                    if ((lVar24 != 0) && (*(char *)(lVar24 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100326;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100342;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10036c;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)(puVar22 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10037a;
                  func_0x(uVar23,3);
                  uVar11 = puVar22[0xe];
                  uVar36 = *(uint *)(puVar22 + 10);
                }
                uVar36 = uVar36 + (uVar11 + 1) * 2;
                *(uint *)(puVar22 + 0xc) = uVar36;
                if (0x1f9e < uVar36) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1003af;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1003b8;
                    lVar24 = func_0x();
                    if ((lVar24 != 0) && (*(char *)(lVar24 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1003d2;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1003ee;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100418;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)(puVar22 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100426;
                  func_0x(uVar23,4);
                  uVar11 = puVar22[0xe];
                  uVar36 = *(uint *)(puVar22 + 0xc);
                }
                uVar58 = (ulonglong)uVar11;
                uVar11 = puVar60[uVar58];
                *(uint *)(puVar22 + 2) = uVar11 & 0x7fff;
                if ((uVar11 & 0x7fff) < uVar36) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100457;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100460;
                    lVar24 = func_0x();
                    if ((lVar24 != 0) && (*(char *)(lVar24 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10047a;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100496;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1004c0;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
                      }
                    }
                  }
                  uVar23 = *(undefined8 *)(puVar22 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1004ce;
                  func_0x(uVar23,4);
                  uVar36 = *(uint *)(puVar22 + 0xc);
                  uVar58 = (ulonglong)(ushort)puVar22[0xe];
                }
                iVar15 = 0;
                puVar6 = puVar60;
                if ((short)uVar58 != 0) {
                  do {
                    uVar40 = puVar6[1] & 0x7fff;
                    if ((uVar40 < uVar36) || (*(uint *)(puVar22 + 2) < uVar40)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100515;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10051e;
                        lVar25 = func_0x();
                        if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100538;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100554;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100578;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                          }
                        }
                      }
                      uVar23 = *(undefined8 *)(puVar22 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100586;
                      func_0x(uVar23,4);
                    }
                    iVar15 = iVar15 + 1;
                    uVar58 = (ulonglong)(ushort)puVar22[0xe];
                    puVar6 = puVar6 + 1;
                    uVar36 = uVar40;
                  } while (iVar15 < (int)(uint)(ushort)puVar22[0xe]);
                  puVar56 = *(undefined2 **)(&stack0x00000060 + lVar20);
                  lVar25 = *(longlong *)(&stack0x00000070 + lVar20);
                }
                if ((short)puVar60[(ulonglong)((int)uVar58 - 1) + 1] < 0) {
                  do {
                    lVar24 = *(longlong *)(puVar22 + 4);
                    uVar40 = *(ushort *)((ulonglong)*(uint *)(puVar22 + 10) + lVar24 + uVar58 * 2) &
                             0x7fff;
                    if ((int)uVar58 == 1) {
                      uVar18 = *(uint *)(puVar22 + 0xc);
                      uVar41 = uVar18;
LAB_:
                      if ((uVar40 < uVar18) || (uVar36 = *(uint *)(puVar22 + 2), uVar36 < uVar40))
                      goto LAB_;
                    }
                    else {
                      uVar18 = *(ushort *)
                                ((ulonglong)*(uint *)(puVar22 + 10) + lVar24 + -2 + uVar58 * 2) &
                               0x7fff;
                      uVar41 = *(uint *)(puVar56 + 0xc);
                      if (uVar41 <= uVar18) goto LAB_;
LAB_:
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10060c;
                      func_0x(lVar24,7);
                      uVar41 = *(uint *)(puVar56 + 0xc);
                      uVar36 = *(uint *)(puVar56 + 2);
                      lVar24 = *(longlong *)(puVar56 + 4);
                    }
                    if ((uVar18 < uVar41) || (uVar36 < uVar18)) goto LAB_;
                    if (*(ushort *)((ulonglong)uVar18 + lVar24) == 5) {
                      *puVar45 = *puVar45 | 2;
                      puVar22[0xe] = puVar22[0xe] + -1;
                      uVar43 = (ulonglong)(uVar18 & 0xffff);
                      puVar22[0x15] = (short)uVar18;
                      uVar58 = *(ulonglong *)(puVar22 + 4);
                      uVar11 = puVar22[0x16] & 0xc7ff;
                      if ((*(ushort *)(uVar43 + 2 + uVar58) >> 0xe & 1) != 0) {
                        uVar11 = *(ushort *)(uVar43 + 2 + uVar58) & 0x3800 | puVar22[0x16] & 0xc7ff;
                      }
                      puVar22[0x16] = uVar11;
                      uVar54 = (uVar11 ^ *(ushort *)(uVar43 + 2 + uVar58)) & 0x7ff ^ uVar11;
                      puVar22[0x16] = uVar54;
                      uVar47 = (ulonglong)(ushort)puVar22[0x15];
                      uVar43 = (ulonglong)((uVar54 & 0x7ff) * 2) + 4 +
                               uVar47 + (uVar11 >> 0xb & 7) * 2 + uVar58;
                      if (uVar43 < uVar47 + uVar58) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10071c;
                        func_0x(uVar47 + uVar58,0x19);
                        uVar54 = puVar22[0x16];
                        uVar47 = (ulonglong)(ushort)puVar22[0x15];
                        uVar58 = (ulonglong)*(uint *)(puVar22 + 4);
                      }
                      if (uVar40 - uVar18 <
                          (((uVar54 & 0x7ff) * 2 - (int)uVar47) - (int)uVar58) + (int)uVar43) {
                        lVar24 = *(longlong *)(puVar22 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100754;
                        func_0x(uVar47 + lVar24,0x19);
                        uVar54 = puVar22[0x16];
                      }
                      iVar15 = 0;
                      if (((uVar54 & 0x3800) != 0) &&
                         (puVar60 = (ushort *)
                                    (*(longlong *)(puVar22 + 4) + 4 +
                                    (ulonglong)(ushort)puVar22[0x15]), (uVar54 & 0x3800) != 0))
                      goto LAB_;
                      break;
                    }
                    if (*(ushort *)((ulonglong)uVar18 + lVar24) < 0x400) break;
                    *puVar45 = *puVar45 | 1;
                    uVar11 = puVar22[0xe] - 1;
                    puVar22[0xe] = uVar11;
                    if ((uVar11 == 0) ||
                       (uVar58 = (ulonglong)uVar11, -1 < (short)puVar60[(ulonglong)(uVar11 - 1) + 1]
                       )) break;
                  } while( true );
                }
                pbVar55 = *(byte **)(puVar22 + 4);
              }
              goto LAB_;
            }
            goto LAB_;
          }
        }
        *(undefined8 *)(&stack0x00000070 + lVar20) = 0;
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104c65;
        lVar25 = func_0x(param_3);
        *(undefined8 *)(&stack0x00000120 + lVar20) = 0;
        *(undefined4 *)(&stack0x0000009c + lVar20) = 0;
        lVar25 = lVar25 + 0x10;
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104c7f;
        iVar15 = func_0x(lVar25);
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104c8b;
        uVar40 = func_0x(puVar45);
        if ((uint)-iVar15 < uVar40) {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104c9a;
          uVar40 = func_0x(puVar45);
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104ca7;
          iVar15 = func_0x(lVar25);
          uVar40 = -iVar15;
        }
        uVar58 = (ulonglong)uVar40;
        *(uint *)(&stack0x00000048 + lVar20) = uVar40;
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104cb9;
        iVar15 = func_0x(puVar45);
        if (iVar15 != 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104cd3;
          cVar8 = func_0x
                            (param_3,&stack0x00000120 + lVar20,&stack0x0000009c + lVar20);
          if (cVar8 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104cec;
            uVar18 = func_0x(*(undefined8 *)(&stack0x00000120 + lVar20),
                                     *(undefined4 *)(&stack0x0000009c + lVar20),puVar45);
            if (uVar40 <= uVar18) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104d09;
              uVar40 = func_0x(*(undefined8 *)(&stack0x00000120 + lVar20),
                                       *(undefined4 *)(&stack0x0000009c + lVar20),puVar45);
              uVar58 = (ulonglong)uVar40;
              *(uint *)(&stack0x00000048 + lVar20) = uVar40;
            }
          }
        }
        uVar40 = (uint)uVar58;
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104d17;
        uVar18 = func_0x(lVar25);
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104d21;
        uVar19 = func_0x(lVar25);
        *(undefined **)((longlong)&pbStackX_18 + lVar20) = &stack0x000028a0 + lVar20;
        *(undefined4 *)((longlong)&uStackX_20 + lVar20) = uVar19;
        uVar41 = 0;
        *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
        *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
        *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104d44;
        cVar8 = func_0x(puVar45);
        lVar25 = (longlong)&sStackX_10 + lVar20 + 2;
        if (cVar8 == '\x06') {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104d51;
          puVar28 = (undefined *)func_0x(lVar25);
          *puVar28 = 6;
          uVar38 = 1;
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104d5e;
          puVar28 = (undefined *)func_0x(lVar25);
          *puVar28 = 0;
          *(undefined *)(*(longlong *)((longlong)&pbStackX_18 + lVar20) + 1) = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104d73;
          func_0x
                    ((longlong)&sStackX_10 + lVar20 + 2,
                     *(undefined4 *)((longlong)&uStackX_20 + lVar20));
          uVar38 = 4;
        }
        uVar39 = *(uint *)(puVar22 + 8);
        if (*(uint *)((longlong)&uStackX_20 + lVar20) <= uVar39) {
          uVar39 = *(uint *)((longlong)&uStackX_20 + lVar20);
        }
        lVar25 = *(longlong *)(puVar22 + 4);
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104d9d;
        func_0x
                  (*(longlong *)((longlong)&pbStackX_18 + lVar20) + (ulonglong)uVar38,
                   lVar25 + (ulonglong)uVar38,uVar39 - uVar38);
        if (uVar18 == 0) {
          *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
               *(undefined4 *)((longlong)&uStackX_20 + lVar20);
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104dae;
          pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
          *pbVar27 = *pbVar27 | 0x10;
          *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
               (uVar18 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20) + 2;
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104dca;
          pbVar27 = (byte *)func_0x(puVar45);
          if ((*pbVar27 & 0x10) == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104e63;
            func_0x(&stack0x00000198 + lVar20);
            *(short *)((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                      *(longlong *)((longlong)&pbStackX_18 + lVar20)) = (short)uVar18;
          }
          else {
            lVar25 = *(longlong *)(puVar22 + 4);
            uVar11 = *(ushort *)((ulonglong)*(uint *)(puVar22 + 8) + lVar25);
            uVar41 = (uint)uVar11;
            if (uVar11 == uVar18) {
              iVar15 = *(int *)((longlong)&uStackX_20 + lVar20 + 4);
              uVar18 = *(uint *)(puVar22 + 8);
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104dfb;
              func_0x
                        ((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                         *(longlong *)((longlong)&pbStackX_18 + lVar20),(ulonglong)uVar18 + lVar25,
                         iVar15 - *(uint *)((longlong)&uStackX_20 + lVar20));
              goto LAB_;
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104e0c;
            func_0x(&stack0x00000198 + lVar20);
            *(short *)((ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) +
                      *(longlong *)((longlong)&pbStackX_18 + lVar20)) = (short)uVar18;
            if (uVar11 != 0) {
              uVar39 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) -
                       *(uint *)((longlong)&uStackX_20 + lVar20);
              uVar38 = *(uint *)(puVar22 + 8);
              uVar16 = *(int *)(puVar22 + 10) - uVar38;
              if (uVar16 <= uVar39) {
                uVar39 = uVar16;
              }
              lVar25 = *(longlong *)(puVar22 + 4);
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104e55;
              func_0x
                        (*(longlong *)((longlong)&pbStackX_18 + lVar20) +
                         (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20) + 2,
                         lVar25 + (ulonglong)uVar38 + 2,uVar39 - 2);
            }
          }
          if (uVar18 < uVar41) {
            uVar41 = uVar18 & 0xffff;
          }
          uVar11 = (ushort)uVar41;
          while (uVar11 = uVar11 + 1, uVar11 <= uVar18) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104e9f;
            func_0x(&stack0x00000198 + lVar20,uVar11);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104eaf;
            func_0x((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000198 + lVar20);
          }
        }
LAB_:
        uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
        *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
        *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
        puVar28 = &stack0xffffffffffffffc0 + lVar20;
        if (uVar40 != 0) {
          uVar43 = uVar58 * 0x20 + 0xf;
          if (uVar43 <= uVar58 * 0x20) {
            uVar43 = 0xffffffffffffff0;
          }
          uVar43 = uVar43 & 0xfffffffffffffff0;
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104efc;
          func_0x();
          lVar25 = -uVar43;
          puVar28 = &stack0xffffffffffffffc0 + lVar25 + lVar20;
          *(longlong *)(&stack0x00000070 + lVar20) = (longlong)&sStackX_10 + lVar25 + lVar20;
          if (*(int *)(puVar22 + 2) == 0) {
            *puVar45 = 0;
            *(undefined4 *)(puVar22 + 10) = *(undefined4 *)(puVar22 + 8);
            *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x104f24;
            pbVar27 = (byte *)func_0x(puVar45);
            if ((*pbVar27 & 0x10) != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x104f31;
              pbVar27 = (byte *)func_0x(puVar45);
              if ((*pbVar27 & 0x10) != 0) {
                uVar36 = (uint)*(ushort *)
                                ((ulonglong)*(uint *)(puVar22 + 8) + *(longlong *)(puVar22 + 4));
              }
              *(uint *)(puVar22 + 10) = *(int *)(puVar22 + 10) + (uVar36 + 7 >> 3) + 2;
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x104f5a;
            pbVar27 = (byte *)func_0x(puVar45);
            puVar56 = puVar22;
            if ((*pbVar27 & 0x20) == 0) {
              *(undefined4 *)(puVar22 + 2) = *(undefined4 *)(puVar22 + 10);
              puVar22[0xe] = 0;
              *(undefined4 *)(puVar22 + 0xc) = *(undefined4 *)(puVar22 + 10);
            }
            else {
              *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x104f6b;
              puVar60 = (ushort *)func_0x(puVar45);
              uVar11 = *puVar60;
              puVar22[0xe] = uVar11;
              if (uVar11 == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x104f86;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x104f8f;
                  cVar8 = func_0x();
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x104f9f;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x104fbb;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar25 + lVar20) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x104fe1;
                      (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
                    }
                  }
                }
                uVar23 = *(undefined8 *)(puVar22 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x104fef;
                func_0x(uVar23,3);
                uVar11 = puVar22[0xe];
              }
              uVar36 = *(int *)(puVar22 + 10) + 2 + (uint)uVar11 * 2;
              *(uint *)(puVar22 + 0xc) = uVar36;
              if (0x1f9e < uVar36) {
                *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105016;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x10501f;
                  cVar8 = func_0x();
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x10502f;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x10504b;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar25 + lVar20) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105071;
                      (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
                    }
                  }
                }
                uVar23 = *(undefined8 *)(puVar22 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x10507f;
                func_0x(uVar23,4);
                uVar11 = puVar22[0xe];
              }
              puVar60 = puVar60 + 1;
              *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105095;
              uVar11 = func_0x(puVar60,(ulonglong)uVar11 - 1);
              *(uint *)(puVar22 + 2) = (uint)uVar11;
              uVar36 = *(uint *)(puVar22 + 0xc);
              if (uVar11 < uVar36) {
                *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1050b0;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1050b9;
                  cVar8 = func_0x();
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1050c9;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1050e5;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar25 + lVar20) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x10510b;
                      (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
                    }
                  }
                }
                uVar23 = *(undefined8 *)(puVar22 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105119;
                func_0x(uVar23,4);
                uVar36 = *(uint *)(puVar22 + 0xc);
              }
              uVar11 = puVar22[0xe];
              puVar30 = puVar29;
              if (uVar11 != 0) {
                do {
                  *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105140;
                  uVar11 = func_0x(puVar60,(longlong)(int)puVar30);
                  bVar62 = uVar11 < uVar36;
                  uVar36 = (uint)uVar11;
                  if ((bVar62) ||
                     (*(uint *)(puVar22 + 2) <= (uint)uVar11 && uVar36 != *(uint *)(puVar22 + 2))) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105159;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105162;
                      cVar8 = func_0x();
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105172;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x10518e;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar25 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1051b2;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                        }
                      }
                    }
                    uVar23 = *(undefined8 *)(puVar22 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1051c0;
                    func_0x(uVar23,4);
                  }
                  uVar40 = (int)puVar30 + 1;
                  uVar11 = puVar22[0xe];
                  puVar30 = (undefined8 *)(ulonglong)uVar40;
                } while ((int)uVar40 < (int)(uint)uVar11);
                puVar56 = *(undefined2 **)(&stack0x00000060 + lVar20);
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1051e2;
              iVar15 = func_0x(puVar60,uVar11 - 1);
              while (iVar15 != 0) {
                uVar11 = puVar22[0xe];
                *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1051fc;
                lVar24 = func_0x(puVar45);
                if (uVar11 == 1) {
                  uVar36 = *(uint *)(puVar22 + 0xc);
                }
                else {
                  *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105219;
                  uVar54 = func_0x(lVar24 + 2,(ulonglong)uVar11 - 2);
                  uVar36 = (uint)uVar54;
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105229;
                uVar11 = func_0x(lVar24 + 2,(ulonglong)(uint)uVar11 - 1);
                uVar40 = *(uint *)(puVar22 + 0xc);
                if (((uVar36 < uVar40) || (uVar11 < uVar36)) ||
                   (*(uint *)(puVar22 + 2) <= (uint)uVar11 && (uint)uVar11 != *(uint *)(puVar22 + 2)
                   )) {
                  uVar23 = *(undefined8 *)(puVar22 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x10524a;
                  func_0x(uVar23,7);
                  uVar40 = *(uint *)(puVar56 + 0xc);
                }
                if ((uVar36 < uVar40) || (*(uint *)(puVar22 + 2) < uVar36)) {
                  uVar40 = *(uint *)(&stack0x00000048 + lVar20);
                  goto LAB_;
                }
                if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(puVar22 + 4)) == 5) {
                  *puVar45 = *puVar45 | 2;
                  puVar22[0xe] = puVar22[0xe] + -1;
                  puVar22[0x15] = (short)uVar36;
                  lVar24 = (ulonglong)(uVar36 & 0xffff) + *(longlong *)(puVar22 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x10531e;
                  iVar15 = func_0x(lVar24);
                  if (iVar15 == 0) {
                    puVar22[0x16] = puVar22[0x16] & 0xc7ff;
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x10532a;
                    uVar54 = func_0x(lVar24);
                    puVar22[0x16] = puVar22[0x16] & 0xc7ff;
                    puVar22[0x16] = puVar22[0x16] | (uVar54 & 7) << 0xb;
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105352;
                  uVar54 = func_0x(lVar24);
                  puVar22[0x16] = puVar22[0x16] ^ (uVar54 ^ puVar22[0x16]) & 0x7ff;
                  uVar13 = puVar22[0x16];
                  uVar43 = *(ulonglong *)(puVar22 + 4);
                  uVar54 = puVar22[0x15];
                  uVar47 = (ulonglong)((uVar13 & 0x7ff) * 2) + 4 + uVar43 + (uVar13 >> 0xb & 7) * 2
                           + (ulonglong)uVar54;
                  uVar58 = uVar43 + uVar54;
                  if (uVar47 < uVar58) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1053a8;
                    func_0x(uVar58,0x19);
                    uVar13 = puVar22[0x16];
                    uVar54 = puVar22[0x15];
                    uVar43 = (ulonglong)*(uint *)(puVar22 + 4);
                  }
                  if (uVar11 - uVar36 <
                      (((uVar13 & 0x7ff) * 2 - (uint)uVar54) - (int)uVar43) + (int)uVar47) {
                    uVar11 = puVar22[0x15];
                    lVar24 = *(longlong *)(puVar22 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1053e3;
                    func_0x((ulonglong)uVar11 + lVar24,0x19);
                    uVar13 = puVar22[0x16];
                  }
                  if (((uVar13 & 0x3800) != 0) &&
                     (uVar11 = puVar22[0x15], lVar24 = *(longlong *)(puVar22 + 4),
                     (uVar13 & 0x3800) != 0)) {
                    do {
                      uVar54 = puVar22[0x16];
                      *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105420;
                      uVar13 = func_0x((ulonglong)uVar11 + lVar24 + 4,puVar29);
                      if ((uVar54 & 0x7ff) < uVar13) {
                        uVar54 = puVar22[0x15];
                        lVar37 = *(longlong *)(puVar22 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x10543e;
                        func_0x((ulonglong)uVar54 + lVar37,0x1a);
                        uVar54 = puVar22[0x16];
                      }
                      uVar36 = (int)puVar29 + 1;
                      puVar29 = (undefined8 *)(ulonglong)uVar36;
                    } while ((int)uVar36 < (int)(uVar54 >> 0xb & 7));
                  }
                  break;
                }
                if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(puVar22 + 4)) < 0x400) break;
                *puVar45 = *puVar45 | 1;
                uVar11 = puVar22[0xe] - 1;
                puVar22[0xe] = uVar11;
                if (uVar11 == 0) break;
                *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x10529f;
                iVar15 = func_0x(puVar60,uVar11 - 1);
              }
              uVar40 = *(uint *)(&stack0x00000048 + lVar20);
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1052b6;
            iVar15 = func_0x(puVar45);
            if (iVar15 == 0) {
              *(undefined4 *)(puVar22 + 0x13) = 0;
              uVar36 = *(uint *)(puVar56 + 2);
            }
            else {
              *(int *)(puVar22 + 0x13) = *(int *)(puVar22 + 2);
              *(int *)(puVar22 + 2) = *(int *)(puVar22 + 2) + 0xe;
              *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1052d5;
              uVar23 = func_0x(puVar45);
              *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1052e4;
              func_0x(uVar23,&stack0x00000200 + lVar20);
              *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1052f0;
              iVar15 = func_0x(&stack0x00000200 + lVar20);
              *(int *)(puVar22 + 2) = *(int *)(puVar22 + 2) + iVar15;
              uVar36 = *(uint *)(puVar22 + 2);
            }
            if ((*(ulonglong *)(puVar22 + 0xf) != 0) &&
               (*(ulonglong *)(puVar22 + 0xf) < (ulonglong)uVar36 + *(longlong *)(puVar22 + 4))) {
              *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105499;
              cVar8 = func_0x(0x1ebafb0);
              if (cVar8 != '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1054a2;
                cVar8 = func_0x();
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1054b2;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 == '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1054ce;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar25 + lVar20) = 0;
                    *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1054f4;
                    (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
                  }
                }
              }
              uVar23 = *(undefined8 *)(puVar22 + 4);
              *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105502;
              func_0x(uVar23,0x12);
              uVar36 = *(uint *)(puVar56 + 2);
            }
            if (0x3f3b < uVar36 - 1) {
              *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105524;
              cVar8 = func_0x(0x1ebafb0);
              if (cVar8 != '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x10552d;
                cVar8 = func_0x();
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x10553d;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 == '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105559;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    uVar23 = *(undefined8 *)(puVar22 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105567;
                    func_0x(uVar23,5);
                    goto LAB_;
                  }
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar25 + lVar20) = 0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x10558d;
                  (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
                }
              }
              uVar23 = *(undefined8 *)(puVar22 + 4);
              *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x10559b;
              func_0x(uVar23,5);
            }
          }
LAB_:
          uVar11 = puVar22[0xe];
          uVar18 = (uint)uVar11;
          uVar36 = uVar40;
          if ((uVar40 <= uVar11) || (uVar36 = (uint)uVar11, uVar11 != 0)) {
            uVar18 = uVar36;
            *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1055c4;
            lVar24 = func_0x(puVar45);
            uVar36 = *(uint *)(puVar22 + 0xc);
            *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1055d6;
            func_0x();
            uVar40 = 0;
            lVar24 = lVar24 + 2;
            *(longlong *)(&stack0x00000060 + lVar20) = lVar24;
            lVar61 = 0;
            lVar37 = *(longlong *)(&stack0x00000070 + lVar20);
            do {
              *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x1055f8;
              uVar11 = func_0x(lVar24,lVar61);
              uVar41 = (uint)uVar11;
              if ((uVar11 < uVar36) ||
                 (*(uint *)(puVar22 + 2) <= (uint)uVar11 && uVar41 != *(uint *)(puVar22 + 2))) {
                uVar23 = *(undefined8 *)(puVar22 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105612;
                func_0x(uVar23,7);
              }
              uVar23 = *(undefined8 *)(&stack0x00000060 + lVar20);
              *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x10561e;
              iVar15 = func_0x(uVar23,uVar40);
              lVar24 = *(longlong *)(puVar22 + 4);
              *(undefined4 *)(&stack0xffffffffffffffe8 + lVar25 + lVar20) = 0;
              *(undefined **)(&stack0xffffffffffffffe0 + lVar25 + lVar20) =
                   &stack0x000002e8 + lVar20;
              *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x10564d;
              func_0x(lVar37,(ulonglong)uVar36 + lVar24,uVar41 - uVar36,iVar15 != 0)
              ;
              uVar40 = uVar40 + 1;
              lVar61 = lVar61 + 1;
              lVar37 = lVar37 + 0x20;
              lVar24 = *(longlong *)(&stack0x00000060 + lVar20);
              uVar36 = uVar41;
            } while (uVar40 < uVar18);
            uVar40 = *(uint *)(&stack0x00000048 + lVar20);
          }
          puVar29 = *(undefined8 **)(&stack0x00000070 + lVar20);
          *(undefined8 *)((longlong)&uStack_48 + lVar25 + lVar20) = 0x105685;
          func_0x(puVar29 + (ulonglong)uVar18 * 4,0,(uVar40 - uVar18) * 0x20);
        }
        lVar25 = *(longlong *)(&stack0x00000120 + lVar20);
        if (lVar25 != 0) {
          *(uint *)(puVar28 + 0x28) = uVar40;
          *(undefined8 **)(puVar28 + 0x20) = puVar29;
          uVar19 = *(undefined4 *)(&stack0x0000009c + lVar20);
          *(undefined8 *)(puVar28 + -8) = 0x1056ad;
          func_0x(lVar25,uVar19,puVar45,(longlong)&sStackX_10 + lVar20 + 2);
        }
        lVar25 = *(longlong *)(&stack0x00000050 + lVar20);
        *(undefined8 *)(puVar28 + -8) = 0x1056b9;
        uVar23 = func_0x(lVar25);
        *(undefined8 *)(puVar28 + -8) = 0x1056c1;
        uVar11 = func_0x(uVar23);
        *(uint *)(&stack0x00000058 + lVar20) = (uint)uVar11;
        *(undefined8 *)(&stack0x000000f8 + lVar20) = 0;
        *(undefined4 *)(&stack0x00000078 + lVar20) = 0;
        *(undefined8 *)(puVar28 + -8) = 0x1056db;
        lVar24 = func_0x(lVar25);
        *(longlong *)(&stack0x00000080 + lVar20) = lVar24;
        if (uVar11 != 0) {
          do {
            iVar42 = 0;
            *(undefined8 *)(puVar28 + -8) = 0x1056fc;
            uVar23 = func_0x(lVar24);
            *(undefined8 *)(&stack0x000000f0 + lVar20) = uVar23;
            *(undefined8 *)(puVar28 + -8) = 0x10570e;
            iVar15 = func_0x(lVar24);
            *(undefined8 *)(puVar28 + -8) = 0x10571f;
            func_0x(lVar25,lVar24,&stack0x00000088 + lVar20);
            if ((&stack0x00000088)[lVar20] == '\x03') {
              *(undefined8 *)(puVar28 + -8) = 0x1074c1;
              iVar42 = func_0x(lVar24);
              if (iVar42 == 0) {
                *(undefined8 *)(puVar28 + -8) = 0x1074cd;
                iVar42 = func_0x(lVar24);
                if (iVar42 == 0) {
                  *(undefined8 *)(puVar28 + -8) = 0x1074e5;
                  (*_DAT_)(6,0x51,0x10,3);
                }
              }
              *(undefined8 *)(puVar28 + -8) = 0x1074f7;
              func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar23,0,0);
              if (iVar15 < 0) {
                puVar48 = (uint *)((longlong)(-1 - iVar15) * 0x20 + 0xc + (longlong)puVar29);
                *puVar48 = *puVar48 | 2;
              }
              goto LAB_;
            }
            *(undefined8 *)(puVar28 + -8) = 0x105731;
            sVar14 = func_0x(uVar23);
            if (sVar14 != 0) {
              *(undefined8 *)(puVar28 + -8) = 0x105742;
              func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar23);
            }
            *(undefined8 *)(puVar28 + -8) = 0x105754;
            func_0x(lVar25,lVar24,&stack0x000000f8 + lVar20);
            *(undefined8 *)(puVar28 + -8) = 0x10575c;
            iVar17 = func_0x(lVar24);
            if ((iVar17 == 1) || (iVar17 == 2)) {
              lVar37 = *(longlong *)(&stack0x000000f8 + lVar20);
              *(undefined8 *)(puVar28 + -8) = 0x107380;
              iVar15 = func_0x(lVar24);
              if (iVar15 == 0) {
                *(undefined8 *)(puVar28 + -8) = 0x10738c;
                uVar12 = func_0x();
                *(undefined8 *)(puVar28 + -8) = 0x107397;
                uVar23 = func_0x(lVar24);
                *(undefined8 *)(puVar28 + -8) = 0x10739f;
                iVar15 = func_0x(uVar23);
                lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar28 + -8) = 0x1073b1;
                func_0x(iVar15 + lVar25,lVar37,uVar12);
                goto LAB_;
              }
              *(undefined8 *)(puVar28 + -8) = 0x1073c2;
              iVar15 = func_0x(lVar24);
              if ((iVar15 == 0) || ((*(byte *)(lVar25 + 0x14) & 8) == 0)) {
                *(undefined8 *)(puVar28 + -8) = 0x1073ef;
                iVar15 = func_0x(lVar24);
                if (iVar15 == 0) {
                  *(undefined8 *)(puVar28 + -8) = 0x10741e;
                  uVar11 = func_0x(lVar24);
                  uVar36 = (uint)uVar11;
                }
                else {
                  *(undefined8 *)(puVar28 + -8) = 0x1073fb;
                  uVar32 = func_0x();
                  uVar23 = *(undefined8 *)(&stack0x00000050 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x10740a;
                  uVar23 = func_0x(uVar23,lVar24);
                  *(undefined8 *)(puVar28 + -8) = 0x107415;
                  uVar36 = func_0x(uVar23,uVar32);
                }
              }
              else {
                *(undefined8 *)(puVar28 + -8) = 0x1073d4;
                uVar36 = func_0x(lVar24);
                uVar36 = *(uint *)((ulonglong)uVar36 * 8 + *(longlong *)(lVar25 + 0x38));
              }
              *(undefined8 *)(puVar28 + -8) = 0x107429;
              uVar11 = func_0x(lVar24);
              if (uVar36 < uVar11) {
                *(undefined8 *)(puVar28 + -8) = 0x107438;
                uVar11 = func_0x(lVar24);
                iVar42 = uVar11 - uVar36;
              }
              else {
                *(undefined8 *)(puVar28 + -8) = 0x107444;
                uVar11 = func_0x(lVar24);
                if (uVar11 < uVar36) {
                  *(undefined8 *)(puVar28 + -8) = 0x107461;
                  (*_DAT_)(6,0x5c,0x16);
                }
              }
              *(undefined8 *)(puVar28 + -8) = 0x107469;
              uVar10 = func_0x(lVar24);
              uVar23 = *(undefined8 *)(&stack0x00000080 + lVar20);
              *(undefined8 *)(puVar28 + -8) = 0x107476;
              uVar23 = func_0x(uVar23);
              *(undefined8 *)(puVar28 + -8) = 0x10747e;
              iVar15 = func_0x(uVar23);
              lVar25 = (longlong)iVar15 + *(longlong *)((longlong)&pbStackX_18 + lVar20);
              if ((lVar37 != 0) && (uVar36 != 0)) {
                *(undefined8 *)(puVar28 + -8) = 0x10749c;
                func_0x(lVar25,lVar37,uVar36);
              }
              if (iVar42 != 0) {
                *(undefined8 *)(puVar28 + -8) = 0x1074b4;
                func_0x((ulonglong)uVar36 + lVar25,uVar10,iVar42);
              }
LAB_:
              lVar24 = *(longlong *)(&stack0x00000080 + lVar20);
LAB_:
              lVar25 = *(longlong *)(&stack0x00000050 + lVar20);
            }
            else {
              uVar40 = 0;
              uVar36 = 0;
              if ((iVar17 == 3) || (iVar17 == 4)) {
                *(undefined8 *)(puVar28 + -8) = 0x1072a0;
                iVar42 = func_0x(lVar24);
                if ((iVar42 == 0) || (**(int **)(&stack0x000000f8 + lVar20) != 0)) {
                  *(undefined8 *)(puVar28 + -8) = 0x1072bc;
                  iVar42 = func_0x(lVar24);
                  if ((iVar42 == 0) || ((*(byte *)(lVar25 + 0x14) & 8) == 0)) {
                    *(undefined8 *)(puVar28 + -8) = 0x1072e9;
                    iVar42 = func_0x(lVar24);
                    if (iVar42 == 0) {
                      *(undefined8 *)(puVar28 + -8) = 0x107318;
                      uVar11 = func_0x(lVar24);
                      uVar36 = (uint)uVar11;
                    }
                    else {
                      *(undefined8 *)(puVar28 + -8) = 0x1072f5;
                      uVar33 = func_0x();
                      uVar32 = *(undefined8 *)(&stack0x00000050 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x107304;
                      uVar32 = func_0x(uVar32,lVar24);
                      *(undefined8 *)(puVar28 + -8) = 0x10730f;
                      uVar36 = func_0x(uVar32,uVar33);
                    }
                  }
                  else {
                    *(undefined8 *)(puVar28 + -8) = 0x1072ce;
                    uVar36 = func_0x(lVar24);
                    uVar36 = *(uint *)((ulonglong)uVar36 * 8 + *(longlong *)(lVar25 + 0x38));
                  }
                }
                *(undefined8 *)(puVar28 + -8) = 0x107323;
                uVar11 = func_0x(lVar24);
                if (uVar11 < uVar36) {
                  *(undefined8 *)(puVar28 + -8) = 0x107340;
                  (*_DAT_)(6,0x52,0x16);
                }
                *(undefined4 *)(puVar28 + 0x28) = 0;
                *(undefined8 *)(puVar28 + 0x20) = uVar23;
                uVar23 = *(undefined8 *)(&stack0x000000f8 + lVar20);
                *(undefined8 *)(puVar28 + -8) = 0x10736c;
                func_0x(puVar29 + (longlong)(-1 - iVar15) * 4,uVar23,uVar36);
                goto LAB_;
              }
              if (iVar17 == 8) {
                pcVar59 = *(char **)(&stack0x000000f8 + lVar20);
                *(char **)(&stack0x00000060 + lVar20) = pcVar59;
                *(undefined8 *)(puVar28 + -8) = 0x1057c3;
                iVar15 = func_0x(uVar23);
                if (iVar15 < 0) {
                  *(undefined8 *)(puVar28 + -8) = 0x105f51;
                  iVar15 = func_0x(uVar23);
                  if (iVar15 != 0) {
                    *(undefined8 *)(puVar28 + -8) = 0x1068db;
                    func_0x(&stack0x00000820 + lVar20);
                    *(undefined4 *)(&stack0x000000a8 + lVar20) = 0;
                    *(undefined8 *)(puVar28 + -8) = 0x1068ed;
                    func_0x(&stack0x00000158 + lVar20);
                    if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                      *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                      *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                           *(undefined4 *)((longlong)&uStackX_20 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x10690a;
                      pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                      if ((*pbVar27 & 0x10) != 0) {
                        *(undefined8 *)(puVar28 + -8) = 0x106918;
                        pbVar27 = (byte *)func_0x
                                                    ((longlong)&sStackX_10 + lVar20 + 2);
                        if ((*pbVar27 & 0x10) != 0) {
                          uVar36 = (uint)*(ushort *)
                                          (*(longlong *)((longlong)&pbStackX_18 + lVar20) +
                                          (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20));
                        }
                        *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                             (uVar36 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
                      }
                      *(undefined8 *)(puVar28 + -8) = 0x106946;
                      pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                      if ((*pbVar27 & 0x20) == 0) {
                        uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
                        *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
                        *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                        *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
                      }
                      else {
                        *(undefined8 *)(puVar28 + -8) = 0x106958;
                        puVar45 = (ushort *)
                                  func_0x((longlong)&sStackX_10 + lVar20 + 2);
                        uVar11 = *puVar45;
                        *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                        if (uVar11 == 0) {
                          *(undefined8 *)(puVar28 + -8) = 0x106976;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x10697f;
                            cVar8 = func_0x();
                            if (cVar8 != '\0') {
                              *(undefined8 *)(puVar28 + -8) = 0x10698f;
                              cVar8 = func_0x(0x1ebafb0);
                              if (cVar8 == '\0') {
                                *(undefined8 *)(puVar28 + -8) = 0x1069ab;
                                (*_DAT_)(0x22,0x44,0x15,0x3eb);
                              }
                              else {
                                *(undefined8 *)(puVar28 + 0x20) = 0;
                                *(undefined8 *)(puVar28 + -8) = 0x1069d1;
                                (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
                              }
                            }
                          }
                          uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                          *(undefined8 *)(puVar28 + -8) = 0x1069df;
                          func_0x(uVar23,3);
                          uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                        }
                        uVar36 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar11 * 2
                        ;
                        *(uint *)(&stack0x00000028 + lVar20) = uVar36;
                        if (0x1f9e < uVar36) {
                          *(undefined8 *)(puVar28 + -8) = 0x106a08;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x106a11;
                            cVar8 = func_0x();
                            if (cVar8 != '\0') {
                              *(undefined8 *)(puVar28 + -8) = 0x106a21;
                              cVar8 = func_0x(0x1ebafb0);
                              if (cVar8 == '\0') {
                                *(undefined8 *)(puVar28 + -8) = 0x106a3d;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar28 + 0x20) = 0;
                                *(undefined8 *)(puVar28 + -8) = 0x106a63;
                                (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
                              }
                            }
                          }
                          uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                          *(undefined8 *)(puVar28 + -8) = 0x106a71;
                          func_0x(uVar23,4);
                          uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                        }
                        puVar45 = puVar45 + 1;
                        *(undefined8 *)(puVar28 + -8) = 0x106a89;
                        uVar11 = func_0x(puVar45,(ulonglong)uVar11 - 1);
                        *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar11;
                        uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                        if (uVar11 < uVar36) {
                          *(undefined8 *)(puVar28 + -8) = 0x106aa2;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x106aab;
                            cVar8 = func_0x();
                            if (cVar8 != '\0') {
                              *(undefined8 *)(puVar28 + -8) = 0x106abb;
                              cVar8 = func_0x(0x1ebafb0);
                              if (cVar8 == '\0') {
                                *(undefined8 *)(puVar28 + -8) = 0x106ad7;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar28 + 0x20) = 0;
                                *(undefined8 *)(puVar28 + -8) = 0x106b01;
                                (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
                              }
                            }
                          }
                          uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                          *(undefined8 *)(puVar28 + -8) = 0x106b0f;
                          func_0x(uVar23,4);
                          uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                        }
                        iVar15 = 0;
                        uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                        if (uVar11 != 0) {
                          do {
                            *(undefined8 *)(puVar28 + -8) = 0x106b3b;
                            uVar11 = func_0x(puVar45,(longlong)iVar15);
                            bVar62 = uVar11 < uVar36;
                            uVar36 = (uint)uVar11;
                            if ((bVar62) ||
                               (uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
                               uVar40 <= uVar11 && uVar36 != uVar40)) {
                              *(undefined8 *)(puVar28 + -8) = 0x106b53;
                              cVar8 = func_0x(0x1ebafb0);
                              if (cVar8 != '\0') {
                                *(undefined8 *)(puVar28 + -8) = 0x106b5c;
                                cVar8 = func_0x();
                                if (cVar8 != '\0') {
                                  *(undefined8 *)(puVar28 + -8) = 0x106b6c;
                                  cVar8 = func_0x(0x1ebafb0);
                                  if (cVar8 == '\0') {
                                    *(undefined8 *)(puVar28 + -8) = 0x106b88;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(puVar28 + 0x20) = 0;
                                    *(undefined8 *)(puVar28 + -8) = 0x106bac;
                                    (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                                  }
                                }
                              }
                              uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                              *(undefined8 *)(puVar28 + -8) = 0x106bba;
                              func_0x(uVar23,4);
                            }
                            iVar15 = iVar15 + 1;
                            uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                          } while (iVar15 < (int)(uint)uVar11);
                          lVar24 = *(longlong *)(&stack0x00000080 + lVar20);
                        }
                        while( true ) {
                          *(undefined8 *)(puVar28 + -8) = 0x106bed;
                          iVar15 = func_0x(puVar45,uVar11 - 1);
                          if (iVar15 == 0) break;
                          uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                          *(undefined8 *)(puVar28 + -8) = 0x106c02;
                          lVar25 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                          if (uVar11 == 1) {
                            uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                          }
                          else {
                            *(undefined8 *)(puVar28 + -8) = 0x106c1e;
                            uVar54 = func_0x(lVar25 + 2,(ulonglong)uVar11 - 2);
                            uVar36 = (uint)uVar54;
                          }
                          *(undefined8 *)(puVar28 + -8) = 0x106c2e;
                          uVar11 = func_0x(lVar25 + 2,(ulonglong)(uint)uVar11 - 1);
                          uVar40 = *(uint *)(&stack0x00000028 + lVar20);
                          if (((uVar36 < uVar40) || (uVar11 < uVar36)) ||
                             (uVar18 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
                             uVar18 <= uVar11 && uVar11 != uVar18)) {
                            uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                            *(undefined8 *)(puVar28 + -8) = 0x106c51;
                            func_0x(uVar23,7);
                            uVar40 = *(uint *)(&stack0x00000028 + lVar20);
                            uVar18 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                          }
                          if ((uVar36 < uVar40) || (uVar18 < uVar36)) goto LAB_;
                          lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                          uVar54 = *(ushort *)(lVar25 + (ulonglong)uVar36);
                          if (uVar54 == 5) {
                            puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                            *puVar45 = *puVar45 | 2;
                            *(short *)(&stack0x0000002c + lVar20) =
                                 *(short *)(&stack0x0000002c + lVar20) + -1;
                            *(short *)(&stack0x0000003a + lVar20) = (short)uVar36;
                            lVar25 = (ulonglong)(uVar36 & 0xffff) + lVar25;
                            *(undefined8 *)(puVar28 + -8) = 0x106d06;
                            iVar15 = func_0x(lVar25);
                            if (iVar15 == 0) {
                              *(ushort *)(&stack0x0000003c + lVar20) =
                                   *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                            }
                            else {
                              *(undefined8 *)(puVar28 + -8) = 0x106d12;
                              sVar14 = func_0x(lVar25);
                              *(ushort *)(&stack0x0000003c + lVar20) =
                                   *(ushort *)(&stack0x0000003c + lVar20) ^
                                   (sVar14 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800
                              ;
                            }
                            *(undefined8 *)(puVar28 + -8) = 0x106d47;
                            uVar13 = func_0x(lVar25);
                            uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                            uVar13 = (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff ^
                                     uVar54;
                            uVar43 = (ulonglong)uVar13;
                            *(ushort *)(&stack0x0000003c + lVar20) = uVar13;
                            uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                            lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                            uVar58 = (uVar54 >> 0xb & 7) * 2 + uVar47 + ((uVar43 & 0x7ff) + 2) * 2 +
                                     lVar25;
                            if (uVar58 < lVar25 + uVar47) {
                              *(undefined8 *)(puVar28 + -8) = 0x106d9f;
                              func_0x(lVar25 + uVar47,0x19);
                              uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                              uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                              lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                            }
                            if (uVar11 - uVar36 <
                                (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar47)
                                - *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)uVar58) {
                              *(undefined8 *)(puVar28 + -8) = 0x106dd5;
                              func_0x(uVar47 + lVar25,0x19);
                              uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                              uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                              lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                            }
                            iVar15 = 0;
                            if (((uVar43 & 0x3800) != 0) && ((uVar43 & 0x3800) != 0)) {
                              do {
                                *(undefined8 *)(puVar28 + -8) = 0x106e1b;
                                uVar11 = func_0x(uVar47 + lVar25 + 4,iVar15);
                                if ((*(ushort *)(&stack0x0000003c + lVar20) & 0x7ff) < uVar11) {
                                  uVar11 = *(ushort *)(&stack0x0000003a + lVar20);
                                  lVar37 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                                  *(undefined8 *)(puVar28 + -8) = 0x106e3a;
                                  func_0x((ulonglong)uVar11 + lVar37,0x1a);
                                }
                                iVar15 = iVar15 + 1;
                              } while (iVar15 < (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb &
                                                     7));
                            }
                            break;
                          }
                          if (uVar54 < 0x400) break;
                          puVar60 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                          *puVar60 = *puVar60 | 1;
                          uVar11 = *(short *)(&stack0x0000002c + lVar20) - 1;
                          *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                          if (uVar11 == 0) break;
                        }
                      }
                      *(undefined8 *)(puVar28 + -8) = 0x106ca5;
                      iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                      if (iVar15 == 0) {
                        *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                        uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                      }
                      else {
                        iVar15 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                        *(int *)(&stack0x00000036 + lVar20) = iVar15;
                        *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar15 + 0xe;
                        *(undefined8 *)(puVar28 + -8) = 0x106cc2;
                        uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                        *(undefined8 *)(puVar28 + -8) = 0x106cd1;
                        func_0x(uVar23,&stack0x00000218 + lVar20);
                        *(undefined8 *)(puVar28 + -8) = 0x106cdd;
                        iVar15 = func_0x(&stack0x00000218 + lVar20);
                        uVar36 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar15;
                        *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar36;
                      }
                      if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
                         (*(ulonglong *)(&stack0x0000002e + lVar20) <
                          (ulonglong)uVar36 + *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
                        *(undefined8 *)(puVar28 + -8) = 0x106e8a;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x106e93;
                          cVar8 = func_0x();
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x106ea3;
                            cVar8 = func_0x(0x1ebafb0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar28 + -8) = 0x106ebf;
                              (*_DAT_)(0x22,0x44,0x15,0x3fa);
                            }
                            else {
                              *(undefined8 *)(puVar28 + 0x20) = 0;
                              *(undefined8 *)(puVar28 + -8) = 0x106ee5;
                              (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
                            }
                          }
                        }
                        uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                        *(undefined8 *)(puVar28 + -8) = 0x106ef3;
                        func_0x(uVar23,0x12);
                        uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                      }
                      if (0x3f3b < uVar36 - 1) {
                        *(undefined8 *)(puVar28 + -8) = 0x106f0c;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x106f15;
                          cVar8 = func_0x();
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x106f25;
                            cVar8 = func_0x(0x1ebafb0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar28 + -8) = 0x106f41;
                              (*_DAT_)(0x22,0x44,0x15,0x3ed);
                            }
                            else {
                              *(undefined8 *)(puVar28 + 0x20) = 0;
                              *(undefined8 *)(puVar28 + -8) = 0x106f67;
                              (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
                            }
                          }
                        }
                        uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                        *(undefined8 *)(puVar28 + -8) = 0x106f75;
                        func_0x(uVar23,5);
                      }
                    }
LAB_:
                    *(undefined8 *)(puVar28 + -8) = 0x106f7e;
                    func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    *(undefined8 *)(puVar28 + -8) = 0x106f87;
                    iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    if (iVar15 != 0) {
                      *(undefined8 *)(puVar28 + -8) = 0x106f9e;
                      func_0x
                                ((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000820 + lVar20);
                    }
                    if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                      *(undefined8 *)(puVar28 + -8) = 0x106fb9;
                      uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2,0x400,
                                               &stack0x000000a8 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x106fc8;
                      func_0x(&stack0x00000158 + lVar20,uVar23);
                    }
                    *(undefined8 *)(puVar28 + -8) = 0x106fd1;
                    pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    if ((*pbVar27 & 0x20) == 0) {
                      *(undefined8 *)(puVar28 + -8) = 0x106fdf;
                      func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    }
                    *(undefined8 *)(puVar28 + -8) = 0x106fe8;
                    lVar25 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    *(undefined8 *)(puVar28 + -8) = 0x106ff4;
                    iVar42 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    if (iVar42 == 0) {
                      uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                      uVar40 = (uint)uVar11;
                      uVar36 = *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                      lVar24 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                      puVar45 = (ushort *)(lVar24 + (ulonglong)uVar36);
                      uVar36 = uVar36 + 2 + uVar40 * 2;
                      uVar18 = 0;
                      if (*puVar45 != 0) {
                        do {
                          *(undefined8 *)(puVar28 + -8) = 0x1070bb;
                          uVar54 = func_0x(puVar45 + 1,uVar18);
                          *(undefined8 *)(puVar28 + -8) = 0x1070cf;
                          func_0x(puVar45 + 1,uVar18 & 0xffff,uVar54 + 2);
                          uVar18 = uVar18 + 1;
                        } while (uVar18 < *puVar45);
                        lVar24 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                      }
                      iVar42 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                      *(undefined8 *)(puVar28 + -8) = 0x1070f7;
                      func_0x
                                ((ulonglong)uVar36 + 2 + lVar24,lVar24 + (ulonglong)uVar36,
                                 iVar42 - uVar36);
                      piVar46 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                      *piVar46 = *piVar46 + 2;
                      uVar36 = *(int *)(&stack0x00000028 + lVar20) + 2;
                      *(uint *)(&stack0x00000028 + lVar20) = uVar36;
                      if (uVar11 != 0) {
                        *(undefined8 *)(puVar28 + -8) = 0x107114;
                        uVar11 = func_0x(puVar45 + 1,uVar40 - 1);
                        uVar36 = (uint)uVar11;
                      }
                      uVar18 = uVar40 + 1;
                      if (uVar40 < uVar18) {
                        do {
                          *(undefined8 *)(puVar28 + -8) = 0x107134;
                          func_0x(puVar45 + 1,uVar40 & 0xffff,uVar36 & 0xffff,0);
                          uVar40 = uVar40 + 1;
                        } while (uVar40 < uVar18);
                      }
                      *puVar45 = *puVar45 + 1;
                      *(undefined8 *)(puVar28 + -8) = 0x107147;
                      func_0x((longlong)&sStackX_10 + lVar20 + 2);
                      iVar17 = 0;
                      uVar12 = *(undefined2 *)(&stack0x0000002c + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x10715d;
                      uVar12 = func_0x(lVar25 + 2,uVar12);
                      *(undefined8 *)(puVar28 + -8) = 0x10716c;
                      func_0x(&stack0x00000348 + lVar20);
                      *(undefined4 *)(puVar28 + 0x28) = 0;
                      *(undefined8 *)(puVar28 + 0x20) = *(undefined8 *)(&stack0x000000f0 + lVar20);
                      uVar23 = *(undefined8 *)(&stack0x00000060 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x107199;
                      func_0x(&stack0x00000348 + lVar20,uVar23,1,0);
                      *(undefined **)(puVar28 + 0x28) = &stack0x00000144 + lVar20;
                      *(undefined **)(puVar28 + 0x20) = &stack0x00000348 + lVar20;
                      *(undefined8 *)(puVar28 + -8) = 0x1071c5;
                      func_0x(&stack0x0000003a + lVar20,uVar12,0x1f9e,1);
                      iVar42 = *(int *)(&stack0x00000144 + lVar20);
                      lVar24 = *(longlong *)(&stack0x00000080 + lVar20);
                    }
                    else {
                      uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                      uVar36 = uVar11 + 1;
                      *(undefined8 *)(puVar28 + -8) = 0x107011;
                      lVar37 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                      if (uVar36 == 1) {
                        uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                      }
                      else {
                        *(undefined8 *)(puVar28 + -8) = 0x10702d;
                        uVar54 = func_0x(lVar37 + 2,(ulonglong)uVar36 - 2);
                        uVar36 = (uint)uVar54;
                      }
                      *(undefined8 *)(puVar28 + -8) = 0x10703c;
                      uVar11 = func_0x(lVar37 + 2,uVar11);
                      if (((uVar36 < *(uint *)(&stack0x00000028 + lVar20)) || (uVar11 < uVar36)) ||
                         (uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
                         uVar40 <= uVar11 && uVar11 != uVar40)) {
                        uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                        *(undefined8 *)(puVar28 + -8) = 0x10705b;
                        func_0x(uVar23,7);
                      }
                      iVar17 = uVar11 - uVar36;
                      uVar23 = *(undefined8 *)(&stack0x00000060 + lVar20);
                      uVar32 = *(undefined8 *)(&stack0x000000f0 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x10707a;
                      iVar42 = func_0x(&stack0x0000003a + lVar20,uVar32,uVar23,1);
                    }
                    iVar17 = (iVar42 - iVar17) + *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                    *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar17;
                    if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                      uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x1071f4;
                      func_0x(lVar25 + 2,uVar11 + 1,iVar17,1);
                      iVar17 = (*(int *)((longlong)&sStackX_10 + lVar20 + 4) -
                               *(int *)(&stack0x000000a8 + lVar20)) + -2;
                    }
                    uVar12 = *(undefined2 *)(&stack0x0000002c + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x107212;
                    func_0x(lVar25 + 2,uVar12,iVar17);
                    lVar25 = (longlong)&sStackX_10 + lVar20 + 2;
                    if (iVar42 == 0) {
                      uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x107228;
                      func_0x(lVar25,uVar11 + 1,0);
                      *(undefined8 *)(puVar28 + -8) = 0x107231;
                      pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                      if ((*pbVar27 & 0x20) != 0) {
                        *(short *)(&stack0x0000002c + lVar20) =
                             *(short *)(&stack0x0000002c + lVar20) + 1;
                        puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                        *puVar45 = *puVar45 & 0xfffd;
                        *(undefined8 *)(puVar28 + -8) = 0x10724c;
                        func_0x(&stack0x0000003a + lVar20);
                      }
                    }
                    else {
                      puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                      *puVar45 = *puVar45 | 2;
                      *(undefined8 *)(puVar28 + -8) = 0x107258;
                      func_0x(lVar25);
                    }
                    if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                      uVar19 = *(undefined4 *)(&stack0x000000a8 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x10727a;
                      func_0x((longlong)&sStackX_10 + lVar20 + 2,0x400,uVar19);
                    }
                    if (iVar15 != 0) {
                      *(undefined8 *)(puVar28 + -8) = 0x107293;
                      func_0x
                                ((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000820 + lVar20);
                    }
                    goto LAB_;
                  }
                  if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                    *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                    *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                         *(undefined4 *)((longlong)&uStackX_20 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x105f78;
                    pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    if ((*pbVar27 & 0x10) != 0) {
                      *(undefined8 *)(puVar28 + -8) = 0x105f86;
                      pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                      if ((*pbVar27 & 0x10) != 0) {
                        uVar36 = (uint)*(ushort *)
                                        (*(longlong *)((longlong)&pbStackX_18 + lVar20) +
                                        (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20));
                      }
                      *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                           (uVar36 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
                    }
                    *(undefined8 *)(puVar28 + -8) = 0x105fb4;
                    pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    if ((*pbVar27 & 0x20) == 0) {
                      uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
                      *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
                      *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                      *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
                    }
                    else {
                      *(undefined8 *)(puVar28 + -8) = 0x105fc6;
                      puVar45 = (ushort *)
                                func_0x((longlong)&sStackX_10 + lVar20 + 2);
                      uVar11 = *puVar45;
                      *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                      if (uVar11 == 0) {
                        *(undefined8 *)(puVar28 + -8) = 0x105fe4;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x105fed;
                          cVar8 = func_0x();
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x105ffd;
                            cVar8 = func_0x(0x1ebafb0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar28 + -8) = 0x106019;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar28 + 0x20) = 0;
                              *(undefined8 *)(puVar28 + -8) = 0x10603f;
                              (*_DAT_)(1,0x17aa9bc,0x18caaa8);
                            }
                          }
                        }
                        uVar32 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                        *(undefined8 *)(puVar28 + -8) = 0x10604d;
                        func_0x(uVar32,3);
                        uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                      }
                      uVar36 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar11 * 2;
                      *(uint *)(&stack0x00000028 + lVar20) = uVar36;
                      if (0x1f9e < uVar36) {
                        *(undefined8 *)(puVar28 + -8) = 0x106076;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x10607f;
                          cVar8 = func_0x();
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x10608f;
                            cVar8 = func_0x(0x1ebafb0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar28 + -8) = 0x1060ab;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar28 + 0x20) = 0;
                              *(undefined8 *)(puVar28 + -8) = 0x1060d1;
                              (*_DAT_)(1,0x17aa9bc,0x18caaa8);
                            }
                          }
                        }
                        uVar32 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                        *(undefined8 *)(puVar28 + -8) = 0x1060df;
                        func_0x(uVar32,4);
                        uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                      }
                      puVar45 = puVar45 + 1;
                      *(undefined8 *)(puVar28 + -8) = 0x1060f7;
                      uVar11 = func_0x(puVar45,(ulonglong)uVar11 - 1);
                      *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar11;
                      uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                      if (uVar11 < uVar36) {
                        *(undefined8 *)(puVar28 + -8) = 0x106110;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x106119;
                          cVar8 = func_0x();
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x106129;
                            cVar8 = func_0x(0x1ebafb0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar28 + -8) = 0x106145;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar28 + 0x20) = 0;
                              *(undefined8 *)(puVar28 + -8) = 0x10616f;
                              (*_DAT_)(1,0x17aa9bc,0x18caaa8);
                            }
                          }
                        }
                        uVar32 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                        *(undefined8 *)(puVar28 + -8) = 0x10617d;
                        func_0x(uVar32,4);
                        uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                      }
                      iVar15 = 0;
                      uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                      if (uVar11 != 0) {
                        do {
                          *(undefined8 *)(puVar28 + -8) = 0x1061ab;
                          uVar11 = func_0x(puVar45,(longlong)iVar15);
                          bVar62 = uVar11 < uVar36;
                          uVar36 = (uint)uVar11;
                          if ((bVar62) ||
                             (uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
                             uVar40 <= uVar11 && uVar36 != uVar40)) {
                            *(undefined8 *)(puVar28 + -8) = 0x1061c3;
                            cVar8 = func_0x(0x1ebafb0);
                            if (cVar8 != '\0') {
                              *(undefined8 *)(puVar28 + -8) = 0x1061cc;
                              cVar8 = func_0x();
                              if (cVar8 != '\0') {
                                *(undefined8 *)(puVar28 + -8) = 0x1061dc;
                                cVar8 = func_0x(0x1ebafb0);
                                if (cVar8 == '\0') {
                                  *(undefined8 *)(puVar28 + -8) = 0x1061f8;
                                  (*_DAT_)(0x22,0x44,0x15);
                                }
                                else {
                                  *(undefined8 *)(puVar28 + 0x20) = 0;
                                  *(undefined8 *)(puVar28 + -8) = 0x10621c;
                                  (*_DAT_)(1,0x17aa9bc,0x18caaa8);
                                }
                              }
                            }
                            uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                            *(undefined8 *)(puVar28 + -8) = 0x10622a;
                            func_0x(uVar23,4);
                          }
                          iVar15 = iVar15 + 1;
                          uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                        } while (iVar15 < (int)(uint)uVar11);
                        uVar23 = *(undefined8 *)(&stack0x000000f0 + lVar20);
                      }
                      while( true ) {
                        *(undefined8 *)(puVar28 + -8) = 0x10625d;
                        iVar15 = func_0x(puVar45,uVar11 - 1);
                        if (iVar15 == 0) break;
                        uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                        *(undefined8 *)(puVar28 + -8) = 0x106272;
                        lVar25 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                        if (uVar11 == 1) {
                          uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                        }
                        else {
                          *(undefined8 *)(puVar28 + -8) = 0x10628e;
                          uVar54 = func_0x(lVar25 + 2,(ulonglong)uVar11 - 2);
                          uVar36 = (uint)uVar54;
                        }
                        *(undefined8 *)(puVar28 + -8) = 0x10629e;
                        uVar11 = func_0x(lVar25 + 2,(ulonglong)(uint)uVar11 - 1);
                        uVar40 = *(uint *)(&stack0x00000028 + lVar20);
                        if (((uVar36 < uVar40) || (uVar11 < uVar36)) ||
                           (uVar18 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
                           uVar18 <= uVar11 && uVar11 != uVar18)) {
                          uVar32 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                          *(undefined8 *)(puVar28 + -8) = 0x1062c1;
                          func_0x(uVar32,7);
                          uVar40 = *(uint *)(&stack0x00000028 + lVar20);
                          uVar18 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                        }
                        if ((uVar36 < uVar40) || (uVar18 < uVar36)) goto LAB_;
                        lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                        uVar54 = *(ushort *)(lVar25 + (ulonglong)uVar36);
                        if (uVar54 == 5) {
                          puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                          *puVar45 = *puVar45 | 2;
                          *(short *)(&stack0x0000002c + lVar20) =
                               *(short *)(&stack0x0000002c + lVar20) + -1;
                          *(short *)(&stack0x0000003a + lVar20) = (short)uVar36;
                          lVar25 = (ulonglong)(uVar36 & 0xffff) + lVar25;
                          *(undefined8 *)(puVar28 + -8) = 0x106376;
                          iVar15 = func_0x(lVar25);
                          if (iVar15 == 0) {
                            *(ushort *)(&stack0x0000003c + lVar20) =
                                 *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                          }
                          else {
                            *(undefined8 *)(puVar28 + -8) = 0x106382;
                            sVar14 = func_0x(lVar25);
                            *(ushort *)(&stack0x0000003c + lVar20) =
                                 *(ushort *)(&stack0x0000003c + lVar20) ^
                                 (sVar14 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
                          }
                          *(undefined8 *)(puVar28 + -8) = 0x1063b7;
                          uVar13 = func_0x(lVar25);
                          uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                          uVar13 = (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff ^
                                   uVar54;
                          uVar43 = (ulonglong)uVar13;
                          *(ushort *)(&stack0x0000003c + lVar20) = uVar13;
                          uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                          lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                          uVar58 = (uVar54 >> 0xb & 7) * 2 + uVar47 + ((uVar43 & 0x7ff) + 2) * 2 +
                                   lVar25;
                          if (uVar58 < lVar25 + uVar47) {
                            *(undefined8 *)(puVar28 + -8) = 0x10640f;
                            func_0x(lVar25 + uVar47,0x19);
                            uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                            uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                            lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                          }
                          if (uVar11 - uVar36 <
                              (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar47) -
                              *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)uVar58) {
                            *(undefined8 *)(puVar28 + -8) = 0x106445;
                            func_0x(uVar47 + lVar25,0x19);
                            uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                            uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                            lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                          }
                          iVar15 = 0;
                          if (((uVar43 & 0x3800) != 0) && ((uVar43 & 0x3800) != 0)) {
                            do {
                              *(undefined8 *)(puVar28 + -8) = 0x10648b;
                              uVar11 = func_0x(uVar47 + lVar25 + 4,iVar15);
                              if ((*(ushort *)(&stack0x0000003c + lVar20) & 0x7ff) < uVar11) {
                                uVar11 = *(ushort *)(&stack0x0000003a + lVar20);
                                lVar24 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                                *(undefined8 *)(puVar28 + -8) = 0x1064aa;
                                func_0x((ulonglong)uVar11 + lVar24,0x1a);
                              }
                              iVar15 = iVar15 + 1;
                            } while (iVar15 < (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7)
                                    );
                          }
                          break;
                        }
                        if (uVar54 < 0x400) break;
                        puVar60 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                        *puVar60 = *puVar60 | 1;
                        uVar11 = *(short *)(&stack0x0000002c + lVar20) - 1;
                        *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                        if (uVar11 == 0) break;
                      }
                    }
                    *(undefined8 *)(puVar28 + -8) = 0x106315;
                    iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    if (iVar15 == 0) {
                      *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                      uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                    }
                    else {
                      iVar15 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                      *(int *)(&stack0x00000036 + lVar20) = iVar15;
                      *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar15 + 0xe;
                      *(undefined8 *)(puVar28 + -8) = 0x106332;
                      uVar32 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                      *(undefined8 *)(puVar28 + -8) = 0x106341;
                      func_0x(uVar32,&stack0x00000210 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x10634d;
                      iVar15 = func_0x(&stack0x00000210 + lVar20);
                      uVar36 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar15;
                      *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar36;
                    }
                    if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
                       (*(ulonglong *)(&stack0x0000002e + lVar20) <
                        (ulonglong)uVar36 + *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
                      *(undefined8 *)(puVar28 + -8) = 0x1064fa;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x106503;
                        cVar8 = func_0x();
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x106513;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x10652f;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar28 + 0x20) = 0;
                            *(undefined8 *)(puVar28 + -8) = 0x106555;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8);
                          }
                        }
                      }
                      uVar32 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x106563;
                      func_0x(uVar32,0x12);
                      uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                    }
                    if (0x3f3b < uVar36 - 1) {
                      *(undefined8 *)(puVar28 + -8) = 0x10657c;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x106585;
                        cVar8 = func_0x();
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x106595;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x1065b1;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar28 + 0x20) = 0;
                            *(undefined8 *)(puVar28 + -8) = 0x1065d7;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8);
                          }
                        }
                      }
                      uVar32 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x1065e5;
                      func_0x(uVar32,5);
                    }
                  }
LAB_:
                  *(undefined8 *)(puVar28 + -8) = 0x1065ed;
                  iVar15 = func_0x(uVar23);
                  uVar36 = -iVar15;
                  *(undefined8 *)(puVar28 + -8) = 0x1065fd;
                  func_0x(&stack0x00000740 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x106606;
                  iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  *(int *)(&stack0x000000f0 + lVar20) = iVar15;
                  if (iVar15 != 0) {
                    *(undefined8 *)(puVar28 + -8) = 0x106623;
                    func_0x
                              ((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000740 + lVar20);
                  }
                  *(undefined8 *)(puVar28 + -8) = 0x10662c;
                  pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if ((*pbVar27 & 0x20) == 0) {
                    *(undefined8 *)(puVar28 + -8) = 0x10663a;
                    func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  }
                  uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                  uVar18 = (uint)uVar11;
                  uVar40 = (uint)uVar11;
                  if (uVar40 < uVar36) {
                    *(uint *)(&stack0x00000148 + lVar20) = uVar36 - uVar11;
                    uVar18 = *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                    lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    puVar45 = (ushort *)(lVar25 + (ulonglong)uVar18);
                    uVar18 = uVar18 + 2 + uVar40 * 2;
                    uVar41 = (uVar36 - uVar11) * 2;
                    uVar38 = 0;
                    if (*puVar45 != 0) {
                      do {
                        *(undefined8 *)(puVar28 + -8) = 0x10667f;
                        uVar54 = func_0x(puVar45 + 1,uVar38);
                        *(undefined8 *)(puVar28 + -8) = 0x106692;
                        func_0x(puVar45 + 1,uVar38 & 0xffff,uVar54 + uVar41);
                        uVar38 = uVar38 + 1;
                      } while (uVar38 < *puVar45);
                      lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    }
                    iVar15 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                    *(undefined8 *)(puVar28 + -8) = 0x1066bc;
                    func_0x
                              ((ulonglong)uVar41 + (ulonglong)uVar18 + lVar25,
                               lVar25 + (ulonglong)uVar18,iVar15 - uVar18);
                    piVar46 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                    *piVar46 = *piVar46 + uVar41;
                    uVar41 = *(int *)(&stack0x00000028 + lVar20) + uVar41;
                    *(uint *)(&stack0x00000028 + lVar20) = uVar41;
                    if (uVar11 != 0) {
                      *(undefined8 *)(puVar28 + -8) = 0x1066d9;
                      uVar11 = func_0x(puVar45 + 1,uVar40 - 1);
                      uVar41 = (uint)uVar11;
                    }
                    do {
                      *(undefined8 *)(puVar28 + -8) = 0x1066f2;
                      func_0x(puVar45 + 1,uVar40 & 0xffff,uVar41 & 0xffff);
                      uVar40 = uVar40 + 1;
                    } while (uVar40 < uVar36);
                    *puVar45 = *puVar45 + (short)*(undefined4 *)(&stack0x00000148 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x10670b;
                    iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    if (iVar15 != 0) {
                      *(undefined8 *)(puVar28 + -8) = 0x106718;
                      func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    }
                    uVar18 = uVar36 & 0xffff;
                    *(short *)(&stack0x0000002c + lVar20) = (short)uVar36;
                    iVar15 = *(int *)(&stack0x000000f0 + lVar20);
                  }
                  lVar25 = (longlong)&sStackX_10 + lVar20 + 2;
                  if (uVar18 < uVar36) {
                    *(undefined8 *)(puVar28 + -8) = 0x10679d;
                    lVar25 = func_0x(lVar25);
                    uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x1067ad;
                    uVar11 = func_0x(lVar25 + 2,(ulonglong)uVar11 - 1);
                    uVar40 = (uint)uVar11;
                    iVar42 = 0;
LAB_:
                    uVar36 = uVar36 - 1;
                    *(undefined8 *)(puVar28 + -8) = 0x1067c0;
                    puVar45 = (ushort *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    uVar19 = *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4);
                    *(undefined8 *)(puVar28 + -8) = 0x1067d2;
                    uVar19 = func_0x(uVar19,uVar40 + iVar42);
                    lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x1067ed;
                    func_0x
                              (lVar25 + 1 + (ulonglong)uVar40,
                               (longlong)iVar42 + (ulonglong)uVar40 + lVar25,uVar19);
                    if ((int)uVar36 < (int)(uint)*puVar45) {
                      do {
                        *(undefined8 *)(puVar28 + -8) = 0x10680c;
                        uVar11 = func_0x(puVar45 + 1,(longlong)(int)uVar36);
                        *(undefined8 *)(puVar28 + -8) = 0x10681f;
                        func_0x
                                  (puVar45 + 1,uVar36 & 0xffff,(uint)uVar11 + (1 - iVar42));
                        uVar36 = uVar36 + 1;
                      } while ((int)uVar36 < (int)(uint)*puVar45);
                    }
                    piVar46 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                    *piVar46 = *piVar46 + (1 - iVar42);
                    *(undefined8 *)(puVar28 + -8) = 0x106836;
                    iVar42 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    if (iVar42 != 0) {
                      *(undefined8 *)(puVar28 + -8) = 0x106843;
                      func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    }
                  }
                  else {
                    *(undefined8 *)(puVar28 + -8) = 0x106736;
                    lVar25 = func_0x(lVar25);
                    if (uVar36 == 1) {
                      uVar40 = *(uint *)(&stack0x00000028 + lVar20);
                    }
                    else {
                      *(undefined8 *)(puVar28 + -8) = 0x106753;
                      uVar11 = func_0x(lVar25 + 2,(longlong)(int)(uVar36 - 2));
                      uVar40 = (uint)uVar11;
                    }
                    *(undefined8 *)(puVar28 + -8) = 0x106766;
                    uVar11 = func_0x(lVar25 + 2,(longlong)(int)(uVar36 - 1));
                    if (((uVar40 < *(uint *)(&stack0x00000028 + lVar20)) || (uVar11 < uVar40)) ||
                       (uVar18 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
                       uVar18 <= uVar11 && uVar11 != uVar18)) {
                      uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x106789;
                      func_0x(uVar23,7);
                    }
                    iVar42 = uVar11 - uVar40;
                    if (iVar42 != 1) goto LAB_;
                  }
                  *(undefined *)((ulonglong)uVar40 + *(longlong *)((longlong)&pbStackX_18 + lVar20))
                       = **(undefined **)(&stack0x00000060 + lVar20);
                  if (iVar15 != 0) {
                    *(undefined8 *)(puVar28 + -8) = 0x106869;
                    func_0x
                              ((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000740 + lVar20);
                  }
                  goto LAB_;
                }
                *(undefined8 *)(puVar28 + -8) = 0x1057d6;
                iVar15 = func_0x();
                if (iVar15 != 0) {
                  cVar8 = *pcVar59;
                  *(undefined8 *)(puVar28 + -8) = 0x1057ea;
                  iVar15 = func_0x(uVar23);
                  uVar36 = iVar15 + 1;
                  if (*(uint *)((longlong)&uStackX_20 + lVar20) < uVar36) {
                    iVar42 = *(int *)((longlong)&uStackX_20 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x10580d;
                    func_0x((longlong)&sStackX_10 + lVar20 + 2,0,uVar36 - iVar42);
                    *(undefined8 *)(puVar28 + -8) = 0x105816;
                    iVar42 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    if (iVar42 != 0) {
                      *(undefined8 *)(puVar28 + -8) = 0x105828;
                      func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar36);
                    }
                    *(uint *)((longlong)&uStackX_20 + lVar20) = uVar36;
                  }
                  pbVar27 = (byte *)((longlong)iVar15 +
                                    *(longlong *)((longlong)&pbStackX_18 + lVar20));
                  bVar7 = *pbVar27;
                  *(undefined8 *)(puVar28 + -8) = 0x10583d;
                  bVar9 = func_0x(uVar23);
                  if (cVar8 == '\0') {
                    *pbVar27 = bVar7 & ~(byte)(1 << (bVar9 & 0x1f));
                  }
                  else {
                    *pbVar27 = bVar7 | (byte)(1 << (bVar9 & 0x1f));
                  }
                  goto LAB_;
                }
                if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                  *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                  *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
                       *(undefined4 *)((longlong)&uStackX_20 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x105876;
                  pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if ((*pbVar27 & 0x10) != 0) {
                    *(undefined8 *)(puVar28 + -8) = 0x105884;
                    pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    if ((*pbVar27 & 0x10) != 0) {
                      uVar40 = (uint)*(ushort *)
                                      (*(longlong *)((longlong)&pbStackX_18 + lVar20) +
                                      (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20));
                    }
                    *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
                         (uVar40 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
                  }
                  *(undefined8 *)(puVar28 + -8) = 0x1058b2;
                  pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if ((*pbVar27 & 0x20) == 0) {
                    uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
                    *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
                    *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                    *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
                  }
                  else {
                    *(undefined8 *)(puVar28 + -8) = 0x1058c4;
                    puVar45 = (ushort *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    uVar11 = *puVar45;
                    *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                    if (uVar11 == 0) {
                      *(undefined8 *)(puVar28 + -8) = 0x1058e2;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x1058eb;
                        cVar8 = func_0x();
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x1058fb;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x105917;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar28 + 0x20) = 0;
                            *(undefined8 *)(puVar28 + -8) = 0x10593d;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8);
                          }
                        }
                      }
                      uVar32 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x10594b;
                      func_0x(uVar32,3);
                      uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                    }
                    uVar36 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar11 * 2;
                    *(uint *)(&stack0x00000028 + lVar20) = uVar36;
                    if (0x1f9e < uVar36) {
                      *(undefined8 *)(puVar28 + -8) = 0x105974;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x10597d;
                        cVar8 = func_0x();
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x10598d;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x1059a9;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar28 + 0x20) = 0;
                            *(undefined8 *)(puVar28 + -8) = 0x1059cf;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8);
                          }
                        }
                      }
                      uVar32 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x1059dd;
                      func_0x(uVar32,4);
                      uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                    }
                    puVar45 = puVar45 + 1;
                    *(undefined8 *)(puVar28 + -8) = 0x1059f5;
                    uVar11 = func_0x(puVar45,(ulonglong)uVar11 - 1);
                    *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar11;
                    uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                    if (uVar11 < uVar36) {
                      *(undefined8 *)(puVar28 + -8) = 0x105a0e;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x105a17;
                        cVar8 = func_0x();
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x105a27;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x105a43;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar28 + 0x20) = 0;
                            *(undefined8 *)(puVar28 + -8) = 0x105a6d;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8);
                          }
                        }
                      }
                      uVar32 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x105a7b;
                      func_0x(uVar32,4);
                      uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                    }
                    iVar15 = 0;
                    uVar40 = (uint)*(ushort *)(&stack0x0000002c + lVar20);
                    if (*(ushort *)(&stack0x0000002c + lVar20) != 0) {
                      do {
                        *(undefined8 *)(puVar28 + -8) = 0x105aab;
                        uVar11 = func_0x(puVar45,(longlong)iVar15);
                        bVar62 = uVar11 < uVar36;
                        uVar36 = (uint)uVar11;
                        if ((bVar62) ||
                           (uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
                           uVar40 <= uVar11 && uVar36 != uVar40)) {
                          *(undefined8 *)(puVar28 + -8) = 0x105ac3;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 != '\0') {
                            *(undefined8 *)(puVar28 + -8) = 0x105acc;
                            cVar8 = func_0x();
                            if (cVar8 != '\0') {
                              *(undefined8 *)(puVar28 + -8) = 0x105adc;
                              cVar8 = func_0x(0x1ebafb0);
                              if (cVar8 == '\0') {
                                *(undefined8 *)(puVar28 + -8) = 0x105af8;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar28 + 0x20) = 0;
                                *(undefined8 *)(puVar28 + -8) = 0x105b1c;
                                (*_DAT_)(1,0x17aa9bc,0x18caaa8);
                              }
                            }
                          }
                          uVar32 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                          *(undefined8 *)(puVar28 + -8) = 0x105b2a;
                          func_0x(uVar32,4);
                        }
                        iVar15 = iVar15 + 1;
                        uVar40 = (uint)*(ushort *)(&stack0x0000002c + lVar20);
                      } while (iVar15 < (int)(uint)*(ushort *)(&stack0x0000002c + lVar20));
                      lVar24 = *(longlong *)(&stack0x00000080 + lVar20);
                      pcVar59 = *(char **)(&stack0x00000060 + lVar20);
                    }
                    while( true ) {
                      *(undefined8 *)(puVar28 + -8) = 0x105b4f;
                      iVar15 = func_0x(puVar45,uVar40 - 1);
                      if (iVar15 == 0) break;
                      uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                      *(undefined8 *)(puVar28 + -8) = 0x105b64;
                      lVar25 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                      if (uVar11 == 1) {
                        uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                      }
                      else {
                        *(undefined8 *)(puVar28 + -8) = 0x105b80;
                        uVar54 = func_0x(lVar25 + 2,(ulonglong)uVar11 - 2);
                        uVar36 = (uint)uVar54;
                      }
                      *(undefined8 *)(puVar28 + -8) = 0x105b90;
                      uVar11 = func_0x(lVar25 + 2,(ulonglong)(uint)uVar11 - 1);
                      uVar40 = *(uint *)(&stack0x00000028 + lVar20);
                      if (((uVar36 < uVar40) || (uVar11 < uVar36)) ||
                         (uVar18 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
                         uVar18 <= uVar11 && uVar11 != uVar18)) {
                        uVar32 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                        *(undefined8 *)(puVar28 + -8) = 0x105bb3;
                        func_0x(uVar32,7);
                        uVar40 = *(uint *)(&stack0x00000028 + lVar20);
                        uVar18 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                      }
                      if ((uVar36 < uVar40) || (uVar18 < uVar36)) goto LAB_;
                      lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                      uVar54 = *(ushort *)(lVar25 + (ulonglong)uVar36);
                      if (uVar54 == 5) {
                        puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                        *puVar45 = *puVar45 | 2;
                        *(short *)(&stack0x0000002c + lVar20) =
                             *(short *)(&stack0x0000002c + lVar20) + -1;
                        *(short *)(&stack0x0000003a + lVar20) = (short)uVar36;
                        lVar25 = (ulonglong)(uVar36 & 0xffff) + lVar25;
                        *(undefined8 *)(puVar28 + -8) = 0x105c70;
                        iVar15 = func_0x(lVar25);
                        if (iVar15 == 0) {
                          *(ushort *)(&stack0x0000003c + lVar20) =
                               *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
                        }
                        else {
                          *(undefined8 *)(puVar28 + -8) = 0x105c7c;
                          sVar14 = func_0x(lVar25);
                          *(ushort *)(&stack0x0000003c + lVar20) =
                               *(ushort *)(&stack0x0000003c + lVar20) ^
                               (sVar14 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
                        }
                        *(undefined8 *)(puVar28 + -8) = 0x105cab;
                        uVar13 = func_0x(lVar25);
                        uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                        uVar13 = (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff ^ uVar54;
                        uVar43 = (ulonglong)uVar13;
                        *(ushort *)(&stack0x0000003c + lVar20) = uVar13;
                        uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                        lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                        uVar58 = (uVar54 >> 0xb & 7) * 2 + uVar47 + ((uVar43 & 0x7ff) + 2) * 2 +
                                 lVar25;
                        if (uVar58 < lVar25 + uVar47) {
                          *(undefined8 *)(puVar28 + -8) = 0x105d03;
                          func_0x(lVar25 + uVar47,0x19);
                          uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                          uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                          lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                        }
                        if (uVar11 - uVar36 <
                            (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar47) -
                            *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)uVar58) {
                          *(undefined8 *)(puVar28 + -8) = 0x105d39;
                          func_0x(uVar47 + lVar25,0x19);
                          uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                          uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                          lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                        }
                        iVar15 = 0;
                        if (((uVar43 & 0x3800) != 0) && ((uVar43 & 0x3800) != 0)) {
                          do {
                            *(undefined8 *)(puVar28 + -8) = 0x105d7b;
                            uVar11 = func_0x(uVar47 + lVar25 + 4,iVar15);
                            if ((*(ushort *)(&stack0x0000003c + lVar20) & 0x7ff) < uVar11) {
                              uVar11 = *(ushort *)(&stack0x0000003a + lVar20);
                              lVar37 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                              *(undefined8 *)(puVar28 + -8) = 0x105d9a;
                              func_0x((ulonglong)uVar11 + lVar37,0x1a);
                            }
                            iVar15 = iVar15 + 1;
                          } while (iVar15 < (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7));
                        }
                        break;
                      }
                      if (uVar54 < 0x400) break;
                      puVar60 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                      *puVar60 = *puVar60 | 1;
                      uVar11 = *(short *)(&stack0x0000002c + lVar20) - 1;
                      uVar40 = (uint)uVar11;
                      *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                      if (uVar11 == 0) break;
                    }
                  }
                  *(undefined8 *)(puVar28 + -8) = 0x105c0b;
                  iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if (iVar15 == 0) {
                    *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                    uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                  }
                  else {
                    iVar15 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                    *(int *)(&stack0x00000036 + lVar20) = iVar15;
                    *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar15 + 0xe;
                    *(undefined8 *)(puVar28 + -8) = 0x105c28;
                    uVar32 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    *(undefined8 *)(puVar28 + -8) = 0x105c37;
                    func_0x(uVar32,&stack0x00000208 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x105c43;
                    iVar15 = func_0x(&stack0x00000208 + lVar20);
                    uVar36 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar15;
                    *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar36;
                  }
                  if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
                     (*(ulonglong *)(&stack0x0000002e + lVar20) <
                      (ulonglong)uVar36 + *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
                    *(undefined8 *)(puVar28 + -8) = 0x105dea;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x105df3;
                      cVar8 = func_0x();
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x105e03;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x105e1f;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(puVar28 + 0x20) = 0;
                          *(undefined8 *)(puVar28 + -8) = 0x105e45;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8);
                        }
                      }
                    }
                    uVar32 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x105e53;
                    func_0x(uVar32,0x12);
                    uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                  }
                  if (0x3f3b < uVar36 - 1) {
                    *(undefined8 *)(puVar28 + -8) = 0x105e6c;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x105e75;
                      cVar8 = func_0x();
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar28 + -8) = 0x105e85;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)(puVar28 + -8) = 0x105ea1;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(puVar28 + 0x20) = 0;
                          *(undefined8 *)(puVar28 + -8) = 0x105ec7;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8);
                        }
                      }
                    }
                    uVar32 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x105ed5;
                    func_0x(uVar32,5);
                  }
                }
LAB_:
                *(undefined8 *)(puVar28 + -8) = 0x105edd;
                iVar15 = func_0x(uVar23);
                uVar36 = iVar15 + 1;
                if (*(uint *)((longlong)&uStackX_20 + lVar20) < uVar36) {
                  iVar15 = *(int *)((longlong)&uStackX_20 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x105efd;
                  func_0x((longlong)&sStackX_10 + lVar20 + 2,0,uVar36 - iVar15);
                  *(undefined8 *)(puVar28 + -8) = 0x105f06;
                  iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if (iVar15 != 0) {
                    *(undefined8 *)(puVar28 + -8) = 0x105f18;
                    func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar36);
                  }
                  *(uint *)((longlong)&uStackX_20 + lVar20) = uVar36;
                }
                *(undefined8 *)(puVar28 + -8) = 0x105f23;
                iVar15 = func_0x(uVar23);
                lVar25 = *(longlong *)(&stack0x00000050 + lVar20);
                if (pcVar59 != (char *)0x0) {
                  *(char *)((longlong)iVar15 + *(longlong *)((longlong)&pbStackX_18 + lVar20)) =
                       *pcVar59;
                }
              }
              else {
                *(undefined8 *)(puVar28 + 0x20) = 0x1525f20;
                *(undefined8 *)(puVar28 + -8) = 0x1057ab;
                (*_DAT_)(1,0x192c2b0,0x1958c78);
              }
            }
LAB_:
            lVar24 = lVar24 + 0x50;
            *(longlong *)(&stack0x00000080 + lVar20) = lVar24;
            iVar15 = *(int *)(&stack0x00000078 + lVar20);
            *(uint *)(&stack0x00000078 + lVar20) = iVar15 + 1U;
            puVar29 = *(undefined8 **)(&stack0x00000070 + lVar20);
          } while (iVar15 + 1U < *(uint *)(&stack0x00000058 + lVar20));
        }
        puVar22 = (undefined2 *)0x0;
        if (*(uint *)(&stack0x00000048 + lVar20) != 0) {
          lVar25 = *(longlong *)(&stack0x00000070 + lVar20);
          uVar36 = *(uint *)(&stack0x00000048 + lVar20);
LAB_:
          uVar40 = uVar36 - 1;
          if (*(int *)((ulonglong)uVar40 * 0x20 + 8 + lVar25) == 0) goto code_r0x001068c6;
          *(short *)(&stack0x0000002c + lVar20) = (short)uVar36;
          iVar15 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + uVar36 * 2;
          *(int *)(&stack0x00000028 + lVar20) = iVar15;
          *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar15;
          *(undefined8 *)(puVar28 + -8) = 0x107536;
          pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
          *pbVar27 = *pbVar27 | 0x20;
          if (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < 0x3f3d) {
            *(undefined8 *)(puVar28 + -8) = 0x10754b;
            puVar22 = (undefined2 *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
            *puVar22 = (short)uVar36;
          }
          uVar40 = 0;
          if (uVar36 != 0) {
            puVar48 = (uint *)(lVar25 + 0xc);
            do {
              uVar18 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
              lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
              uVar41 = puVar48[-1];
              uVar38 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + uVar41;
              *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar38;
              if (uVar38 < 0x3f3d) {
                uVar39 = *puVar48;
                *(undefined8 *)(puVar28 + -8) = 0x107592;
                func_0x(puVar22 + 1,uVar40,uVar38,uVar39 & 1);
                uVar23 = *(undefined8 *)(puVar48 + -3);
                *(undefined8 *)(puVar28 + -8) = 0x1075a4;
                func_0x((ulonglong)uVar18 + lVar25,uVar41,uVar23,uVar41);
              }
              uVar40 = uVar40 + 1;
              puVar48 = puVar48 + 8;
            } while (uVar40 < uVar36);
          }
          if (0x3f3c < *(uint *)((longlong)&sStackX_10 + lVar20 + 4)) {
            uVar23 = 0xb9;
            goto LAB_;
          }
        }
        goto LAB_;
      }
      goto LAB_;
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10cf05;
    func_0x(lVar25 + 0xa60,param_2);
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10cf0d;
    uVar23 = func_0x(param_3);
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10cf15;
    iVar15 = func_0x(uVar23);
    uVar36 = uVar40 & 1;
    if (iVar15 != 0) {
      uVar36 = 0;
    }
    *(longlong *)((longlong)&uStackX_20 + lVar20 + -0x20) = lVar25 + 0x290;
    *(undefined **)(&stack0xfffffffffffffff8 + lVar20) = &stack0x00000190 + lVar20;
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar20) = 0x1f7c;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar20) = 0x3f3c;
    *(undefined **)(&stack0xffffffffffffffe0 + lVar20) = &stack0x000028a0 + lVar20;
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10cf6b;
    func_0x(param_1 + 0xa80,param_3,(uVar36 ^ 1) + 1,psVar2);
    lVar25 = *(longlong *)(&stack0x00000090 + lVar20);
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10cf7a;
    lVar24 = func_0x(lVar25);
    if ((*(byte *)(lVar24 + 0x67) & 0x40) != 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10cf88;
      lVar24 = func_0x(param_3);
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10cf9f;
      func_0x(param_1 + 0xa80,lVar24 + 0x78,psVar2,uVar36);
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10cfa7;
    uVar23 = func_0x(param_3);
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10cfaf;
    lVar24 = func_0x(uVar23);
    puVar51 = &stack0xffffffffffffffc0 + lVar20;
    if (lVar24 != 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10cfbc;
      iVar15 = func_0x(lVar25);
      puVar51 = &stack0xffffffffffffffc0 + lVar20;
      if (iVar15 != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10cfc8;
        iVar15 = func_0x(lVar25);
        puVar51 = &stack0xffffffffffffffc0 + lVar20;
        if (iVar15 == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10cfdb;
          func_0x(param_2,psVar2,lVar25);
          puVar51 = &stack0xffffffffffffffc0 + lVar20;
        }
      }
    }
    goto LAB_;
  }
  uVar23 = *(undefined8 *)(param_1 + 0x2e0);
  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10d3c1;
  uVar23 = func_0x(uVar23);
  *(short **)(&stack0xfffffffffffffff8 + lVar20) = psVar2;
  *(undefined **)(&stack0xfffffffffffffff0 + lVar20) = &stack0x000028a0 + lVar20;
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar20) = 0x3f3c;
  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = *(undefined8 *)(param_1 + 0x1e8);
  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10d3fb;
  func_0x(param_2,lVar25,lVar24,uVar23);
LAB_:
  uVar19 = 0;
  *(undefined8 *)(puVar51 + -8) = 0x10d23b;
  cVar8 = func_0x(param_2,1);
  if (cVar8 != '\0') {
    *(undefined8 *)(puVar51 + -8) = 0x10d251;
    uVar32 = func_0x(param_2,1,1);
    *(undefined8 *)(puVar51 + -8) = 0x10d262;
    uVar33 = func_0x(param_2,1,0);
    *(undefined8 *)(puVar51 + -8) = 0x10d274;
    uVar34 = func_0x(uVar32,&stack0x000002c8 + lVar20);
    *(undefined8 *)(puVar51 + -8) = 0x10d286;
    uVar23 = func_0x(uVar32,&stack0x000002a6 + lVar20);
    *(undefined8 *)(puVar51 + -8) = 0x10d295;
    uVar35 = func_0x(uVar23,&stack0x000002b2 + lVar20);
    uVar23 = *(undefined8 *)(*(longlong *)(&stack0x00000168 + lVar20) + 0x2e0);
    *(undefined8 *)(puVar51 + -8) = 0x10d2ab;
    uVar23 = func_0x(uVar23);
    *(undefined8 *)(puVar51 + -8) = 0x10d2b3;
    uVar23 = func_0x(uVar23);
    *(undefined8 *)(puVar51 + -8) = 0x10d2bb;
    uVar23 = func_0x(uVar23);
    *(undefined8 *)(puVar51 + -8) = 0x10d2cc;
    iVar15 = func_0x(uVar23,uVar35,uVar34,0);
    if (iVar15 != 0) {
      *(undefined8 *)(puVar51 + -8) = 0x10d2df;
      uVar23 = func_0x(uVar32,&stack0x000002d0 + lVar20);
      *(undefined8 *)(puVar51 + -8) = 0x10d2e7;
      uVar10 = func_0x(uVar23);
      *(undefined8 *)(puVar51 + -8) = 0x10d2f9;
      uVar23 = func_0x(uVar32,&stack0x000002ac + lVar20);
      *(undefined8 *)(puVar51 + -8) = 0x10d304;
      iVar15 = func_0x(uVar32);
      *(undefined8 *)(puVar51 + -8) = 0x10d318;
      uVar19 = func_0x(uVar33,iVar15 != 0,uVar23,uVar10);
    }
    param_2 = *(undefined8 **)(&stack0x00000100 + lVar20);
  }
  uVar3 = *(undefined4 *)(&stack0x000000ac + lVar20);
  *(undefined8 *)(puVar51 + -8) = 0x10d338;
  func_0x(param_2,psVar2,uVar3,uVar19);
  if ((*(longlong *)(*(longlong *)(lVar24 + 8) + 0x488) != 0) && (*_DAT_ != '\0')) {
    *(undefined8 *)(puVar51 + -8) = 0x10d35f;
    uVar23 = func_0x();
    *(undefined8 *)(puVar51 + -8) = 0x10d36c;
    iVar15 = func_0x(uVar23,0x281);
    if (iVar15 == 0) {
      lVar25 = *(longlong *)(*(longlong *)(lVar24 + 8) + 0x488);
      if (*(longlong *)(lVar25 + 0x20) != 0) {
        *(undefined8 *)(puVar51 + -8) = 0x10d38b;
        uVar36 = func_0x();
        *(undefined8 *)(puVar51 + -8) = 0x10d399;
        uVar40 = func_0x(_DAT_);
        if (uVar36 < uVar40) {
          lVar25 = *(longlong *)(*(longlong *)(lVar25 + 0x20) + (ulonglong)uVar36 * 8);
          *(longlong *)(lVar25 + 0x10) = *(longlong *)(lVar25 + 0x10) + 1;
          goto LAB_;
        }
      }
      LOCK();
      plVar53 = (longlong *)(*(longlong *)(lVar25 + 0x18) + 0x10);
      *plVar53 = *plVar53 + 1;
      UNLOCK();
    }
  }
LAB_:
  **(undefined8 **)(&stack0x00000170 + lVar20) = param_2;
LAB_:
  *(undefined8 *)(puVar51 + -8) = 0x10d420;
  func_0x(&stack0x00000298 + lVar20);
  uVar58 = *(ulonglong *)(&stack0x000067e0 + lVar20);
  *(undefined8 *)(puVar51 + -8) = 0x10d42f;
  func_0x(uVar58 ^ (ulonglong)psVar2);
  return;
code_r0x0010b914:
  if (uVar36 == 0) goto LAB_;
  goto LAB_;
LAB_:
  do {
    if ((uVar54 & 0x7ff) < (*puVar60 & 0x7ff)) {
      uVar11 = puVar22[0x15];
      lVar24 = *(longlong *)(puVar22 + 4);
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1007b7;
      func_0x((ulonglong)uVar11 + lVar24,0x1a);
      uVar54 = puVar22[0x16];
    }
    iVar15 = iVar15 + 1;
    puVar60 = puVar60 + 1;
  } while (iVar15 < (int)(uVar54 >> 0xb & 7));
  pbVar55 = *(byte **)(puVar22 + 4);
LAB_:
  if ((*pbVar55 & 0x40) == 0) {
    *(undefined4 *)(puVar22 + 0x13) = 0;
    uVar36 = *(uint *)(puVar56 + 2);
  }
  else {
    *(int *)(puVar22 + 0x13) = *(int *)(puVar22 + 2);
    *(int *)(puVar22 + 2) = *(int *)(puVar22 + 2) + 0xe;
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1007fd;
    uVar23 = func_0x(puVar45);
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10080c;
    func_0x(uVar23,&stack0x000001b8 + lVar20);
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100818;
    iVar15 = func_0x(&stack0x000001b8 + lVar20);
    *(int *)(puVar22 + 2) = *(int *)(puVar22 + 2) + iVar15;
    uVar36 = *(uint *)(puVar22 + 2);
    pbVar55 = *(byte **)(puVar22 + 4);
  }
  if ((*(byte **)(puVar22 + 0xf) != (byte *)0x0) && (*(byte **)(puVar22 + 0xf) < pbVar55 + uVar36))
  {
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100854;
    cVar8 = func_0x(0x1ebafb0);
    if (cVar8 != '\0') {
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10085d;
      lVar24 = func_0x();
      if ((lVar24 != 0) && (*(char *)(lVar24 + 0x499) != '\0')) {
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100877;
        cVar8 = func_0x(0x1ebafb0);
        if (cVar8 == '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100893;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1008b9;
          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
        }
      }
    }
    uVar23 = *(undefined8 *)(puVar22 + 4);
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1008c7;
    func_0x(uVar23,0x12);
    uVar36 = *(uint *)(puVar56 + 2);
  }
  if ((uVar36 == 0) || (0x3f3c < uVar36)) {
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1008e8;
    cVar8 = func_0x(0x1ebafb0);
    if (cVar8 != '\0') {
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1008f1;
      lVar24 = func_0x();
      if ((lVar24 != 0) && (*(char *)(lVar24 + 0x499) != '\0')) {
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10090b;
        cVar8 = func_0x(0x1ebafb0);
        if (cVar8 == '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100927;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10094d;
          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
        }
      }
    }
    uVar23 = *(undefined8 *)(puVar22 + 4);
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10095b;
    func_0x(uVar23,5);
    uVar36 = *(uint *)(puVar56 + 2);
  }
LAB_:
  if ((uVar36 < 9) &&
     (((**(byte **)(puVar22 + 4) & 0xe) == 0 || ((**(byte **)(puVar22 + 4) & 0xe) == 0xc)))) {
    uVar36 = 9;
  }
  *(undefined4 *)((longlong)&uStackX_20 + lVar20) = *(undefined4 *)(puVar22 + 8);
  *(ushort *)((longlong)&sStackX_10 + lVar20 + 2) = *puVar45;
  *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = *(undefined4 *)(puVar22 + 2);
  *(undefined2 *)(&stack0x0000002c + lVar20) = puVar22[0xe];
  *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) = *(undefined4 *)(puVar22 + 10);
  *(undefined4 *)(&stack0x00000028 + lVar20) = *(undefined4 *)(puVar22 + 0xc);
  *(undefined4 *)(&stack0x00000036 + lVar20) = *(undefined4 *)(puVar22 + 0x13);
  uVar23 = *(undefined8 *)(puVar22 + 4);
  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1009c4;
  func_0x(&stack0x000028a0 + lVar20,0x3f3c,uVar23,uVar36);
  *(undefined **)((longlong)&pbStackX_18 + lVar20) = &stack0x000028a0 + lVar20;
  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1009d8;
  iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
  if (iVar15 == 0) {
    pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
  }
  else {
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1009f0;
    uVar11 = func_0x((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000128 + lVar20);
    uVar36 = *(uint *)(&stack0x00000128 + lVar20);
    uVar58 = (ulonglong)uVar11;
    *(ushort *)(&stack0x0000003a + lVar20) = uVar11;
    pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
    pbVar55 = pbVar27 + uVar58;
    uVar11 = *(ushort *)(&stack0x0000003c + lVar20);
    if ((*(ushort *)(pbVar55 + 2) & 0x4000) == 0) {
      uVar11 = uVar11 & 0xc7ff;
    }
    else {
      uVar11 = uVar11 ^ (*(ushort *)(pbVar55 + 2) ^ uVar11) & 0x3800;
    }
    *(ushort *)(&stack0x0000003c + lVar20) = uVar11;
    uVar54 = (uVar11 ^ *(ushort *)(pbVar55 + 2)) & 0x7ff ^ uVar11;
    uVar43 = (ulonglong)uVar54;
    *(ushort *)(&stack0x0000003c + lVar20) = uVar54;
    pbVar44 = pbVar27 + (ulonglong)((uVar11 >> 0xb & 7) * 2) + 4 + uVar58 + (uVar43 & 0x7ff) * 2;
    if (pbVar44 < pbVar55) {
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100a87;
      func_0x(pbVar55,0x19);
      uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
      uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
      pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
    }
    if (uVar36 < (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar58) -
                 *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)pbVar44) {
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100abc;
      func_0x(pbVar27 + uVar58,0x19);
      uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
      uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
      pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
    }
    iVar15 = 0;
    if (((uVar43 & 0x3800) != 0) &&
       (puVar45 = (ushort *)(pbVar27 + uVar58 + 4), (uVar43 & 0x3800) != 0)) {
      do {
        if (((ushort)uVar43 & 0x7ff) < (*puVar45 & 0x7ff)) {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100b13;
          func_0x(pbVar27 + uVar58,0x1a);
          uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
          uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
          pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
        }
        iVar15 = iVar15 + 1;
        puVar45 = puVar45 + 1;
      } while (iVar15 < (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7));
    }
  }
  uVar36 = 0;
  if ((*pbVar27 & 0xe) == 2) {
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100b56;
    func_0x((longlong)&sStackX_10 + lVar20 + 2);
  }
  plVar53 = *(longlong **)(&stack0x00000050 + lVar20);
  lVar24 = *plVar53;
  if ((*(byte *)(lVar25 + 0x5c) & 4) == 0) {
    uVar11 = *(ushort *)(lVar24 + 0x62);
    *(uint *)(&stack0x00000078 + lVar20) = (uint)uVar11;
    *(undefined4 *)(&stack0x00000048 + lVar20) = 0;
    puVar48 = (uint *)plVar53[1];
    *(uint **)(&stack0x00000058 + lVar20) = puVar48;
    if (uVar11 != 0) {
      do {
        uVar40 = 0;
        (&stack0x00000068)[lVar20] = 0;
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100d13;
        func_0x(plVar53,puVar48,&stack0x00000068 + lVar20);
        if ((&stack0x00000068)[lVar20] == '\x03') {
          if ((puVar48[0x10] & 0x4000) == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1045e5;
            (*_DAT_)(6,0x51,0x10,1);
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1045ed;
          uVar12 = func_0x(puVar48);
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1045f8;
          uVar23 = func_0x(puVar48);
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10460d;
          func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar23,uVar12,1);
          goto LAB_;
        }
        if (*(short *)(puVar48 + 1) != 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100d31;
          func_0x((longlong)&sStackX_10 + lVar20 + 2,puVar48);
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100d43;
        func_0x(plVar53,puVar48,&stack0x00000118 + lVar20);
        cVar8 = *(char *)(puVar48 + 0x10);
        if ((cVar8 == '\x01') || (cVar8 == '\x02')) {
          lVar25 = *(longlong *)(&stack0x00000118 + lVar20);
          if ((puVar48[0x10] >> 8 & 1) == 0) {
            uVar40 = *puVar48;
            uVar12 = *(undefined2 *)(puVar48 + 0xf);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1044f2;
            func_0x
                      ((longlong)(int)uVar40 + *(longlong *)((longlong)&pbStackX_18 + lVar20),lVar25
                       ,uVar12);
            goto LAB_;
          }
          iVar15 = 0;
          lVar24 = *(longlong *)(&stack0x00000050 + lVar20);
          if (((puVar48[0x10] & 0x8000) == 0) || ((*(byte *)(lVar24 + 0x14) & 8) == 0)) {
            if ((*(byte *)(*(longlong *)(puVar48 + 0x12) + 0x2a) & 0x10) == 0) {
              lVar24 = *(longlong *)(lVar24 + 0x18);
            }
            else {
              lVar24 = *(longlong *)(lVar24 + 0x20);
            }
            uVar40 = *(uint *)(*(longlong *)(*(longlong *)(puVar48 + 0x12) + 0x18) + lVar24);
          }
          else {
            uVar40 = *(uint *)(*(longlong *)(lVar24 + 0x38) + (ulonglong)puVar48[0xe] * 8);
          }
          uVar18 = (uint)*(ushort *)(puVar48 + 0xf);
          if (uVar40 < uVar18) {
            iVar15 = uVar18 - uVar40;
          }
          else if (uVar18 < uVar40) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104559;
            (*_DAT_)(6,0x5c,0x16,1);
          }
          uVar10 = *(undefined *)(*(longlong *)(puVar48 + 0x12) + 0x24);
          lVar24 = (longlong)(int)*puVar48 + *(longlong *)((longlong)&pbStackX_18 + lVar20);
          if ((lVar25 != 0) && (uVar40 != 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104581;
            func_0x(lVar24,lVar25,uVar40);
          }
          if (iVar15 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104595;
            func_0x((ulonglong)uVar40 + lVar24,uVar10,iVar15);
          }
LAB_:
          plVar53 = *(longlong **)(&stack0x00000050 + lVar20);
        }
        else {
          if ((cVar8 == '\x03') || (cVar8 == '\x04')) {
            uVar36 = puVar48[0x10];
            piVar46 = *(int **)(&stack0x00000118 + lVar20);
            *(int **)(&stack0x00000070 + lVar20) = piVar46;
            if (((uVar36 >> 0xd & 1) == 0) || (uVar18 = uVar40, *piVar46 != 0)) {
              if (((uVar36 & 0x8000) == 0) || ((*(byte *)((longlong)plVar53 + 0x14) & 8) == 0)) {
                lVar25 = *(longlong *)(puVar48 + 0x12);
                if ((uVar36 >> 8 & 1) == 0) {
                  uVar18 = (uint)*(ushort *)(lVar25 + 2);
                }
                else if ((*(byte *)(lVar25 + 0x2a) & 0x10) == 0) {
                  uVar18 = *(uint *)(*(longlong *)(lVar25 + 0x18) + plVar53[3]);
                }
                else {
                  uVar18 = *(uint *)(*(longlong *)(lVar25 + 0x18) + plVar53[4]);
                }
              }
              else {
                uVar18 = *(uint *)(plVar53[7] + (ulonglong)puVar48[0xe] * 8);
              }
            }
            puVar48 = *(uint **)(&stack0x00000058 + lVar20);
            if (*(ushort *)(puVar48 + 0xf) < uVar18) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10293a;
              (*_DAT_)(6,0x52,0x16,0x93);
              piVar46 = *(int **)(&stack0x00000118 + lVar20);
              *(int **)(&stack0x00000070 + lVar20) = piVar46;
            }
            uVar36 = *puVar48;
            if ((int)uVar36 < 0) {
              if ((uVar36 & 0xc0000000) == 0x80000000) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103abc;
                func_0x(&stack0x00000660 + lVar20);
                *(undefined4 *)(&stack0x000000a4 + lVar20) = 0;
                if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                  *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                  uVar36 = *(uint *)((longlong)&uStackX_20 + lVar20);
                  uVar58 = (ulonglong)uVar36;
                  *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar36;
                  pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  if ((*pbVar27 & 0x10) != 0) {
                    uVar36 = uVar36 + 2 + (*(ushort *)(pbVar27 + uVar58) + 7 >> 3);
                    uVar58 = (ulonglong)uVar36;
                    *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar36;
                  }
                  if ((*pbVar27 & 0x20) == 0) {
                    *(int *)((longlong)&sStackX_10 + lVar20 + 4) = (int)uVar58;
                    *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                    *(int *)(&stack0x00000028 + lVar20) = (int)uVar58;
                    uVar43 = uVar58;
                  }
                  else {
                    puVar45 = (ushort *)(pbVar27 + uVar58);
                    *(ushort **)(&stack0x00000060 + lVar20) = puVar45;
                    uVar11 = *puVar45;
                    *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                    if (uVar11 == 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103b26;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103b2f;
                        lVar25 = func_0x();
                        if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103b49;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103b65;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103b8f;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103b9d;
                      func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),3);
                      uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                      uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                      pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                    }
                    uVar36 = (int)uVar58 + (uVar11 + 1) * 2;
                    *(uint *)(&stack0x00000028 + lVar20) = uVar36;
                    if (0x1f9e < uVar36) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103bd0;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103bd9;
                        lVar25 = func_0x();
                        if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103bf3;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103c0f;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103c39;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103c47;
                      func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                      uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                      uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                      uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                      pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                    }
                    uVar47 = (ulonglong)uVar11;
                    uVar40 = puVar45[uVar47] & 0x7fff;
                    *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar40;
                    if (uVar40 < uVar36) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103c7f;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103c88;
                        lVar25 = func_0x();
                        if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103ca2;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103cbe;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103ce8;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103cf6;
                      func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                      uVar47 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                      uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                      uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                      pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                      uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                    }
                    uVar43 = (ulonglong)uVar40;
                    iVar15 = 0;
                    if ((short)uVar47 != 0) {
                      do {
                        puVar45 = puVar45 + 1;
                        uVar40 = *puVar45 & 0x7fff;
                        if ((uVar40 < uVar36) || ((uint)uVar43 < uVar40)) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103d4f;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103d58;
                            lVar25 = func_0x();
                            if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103d72;
                              cVar8 = func_0x(0x1ebafb0);
                              if (cVar8 == '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103d8e;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103db2;
                                (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                              }
                            }
                          }
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103dc0;
                          func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                          uVar47 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                          pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                          uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                        }
                        iVar15 = iVar15 + 1;
                        uVar36 = uVar40;
                      } while (iVar15 < (int)uVar47);
                      uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                      uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                      puVar45 = *(ushort **)(&stack0x00000060 + lVar20);
                      piVar46 = *(int **)(&stack0x00000070 + lVar20);
                    }
                    while( true ) {
                      sVar14 = (short)uVar47;
                      if (-1 < (short)puVar45[(ulonglong)((int)uVar47 - 1) + 1]) break;
                      uVar40 = uVar36;
                      if ((int)uVar47 != 1) {
                        uVar40 = *(ushort *)(pbVar27 + uVar47 * 2 + (uVar58 - 2)) & 0x7fff;
                      }
                      uVar41 = *(ushort *)(pbVar27 + uVar47 * 2 + uVar58) & 0x7fff;
                      if (((uVar40 < uVar36) || (uVar41 < uVar40)) || ((uint)uVar43 < uVar41)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103e5d;
                        func_0x(pbVar27,7);
                        sVar14 = *(short *)(&stack0x0000002c + lVar20);
                        uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                        uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                        pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                        uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                      }
                      if ((uVar40 < uVar36) || ((uint)uVar43 < uVar40)) goto LAB_;
                      if (*(ushort *)(pbVar27 + uVar40) == 5) {
                        puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                        *puVar45 = *puVar45 | 2;
                        *(short *)(&stack0x0000002c + lVar20) = sVar14 + -1;
                        uVar58 = (ulonglong)(uVar40 & 0xffff);
                        *(short *)(&stack0x0000003a + lVar20) = (short)uVar40;
                        pbVar55 = pbVar27 + uVar58;
                        uVar11 = *(ushort *)(&stack0x0000003c + lVar20);
                        if ((*(ushort *)(pbVar55 + 2) & 0x4000) == 0) {
                          uVar11 = uVar11 & 0xc7ff;
                        }
                        else {
                          uVar11 = uVar11 ^ (uVar11 ^ *(ushort *)(pbVar55 + 2)) & 0x3800;
                        }
                        *(ushort *)(&stack0x0000003c + lVar20) = uVar11;
                        uVar54 = (uVar11 ^ *(ushort *)(pbVar55 + 2)) & 0x7ff ^ uVar11;
                        *(ushort *)(&stack0x0000003c + lVar20) = uVar54;
                        pbVar44 = pbVar27 + (ulonglong)((uVar11 >> 0xb & 7) * 2) + 4 + uVar58 +
                                            ((ulonglong)uVar54 & 0x7ff) * 2;
                        if (pbVar44 < pbVar55) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103f98;
                          func_0x(pbVar55,0x19);
                          uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                          uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                          pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                          uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                        }
                        if (uVar41 - uVar40 <
                            (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar58) -
                            *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)pbVar44) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103fd4;
                          func_0x(pbVar27 + uVar58,0x19);
                          uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                          uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                          pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                          uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                        }
                        iVar15 = 0;
                        if (((uVar54 & 0x3800) != 0) &&
                           (puVar45 = (ushort *)(pbVar27 + uVar58 + 4), (uVar54 & 0x3800) != 0)) {
                          do {
                            if ((uVar54 & 0x7ff) < (*puVar45 & 0x7ff)) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104042;
                              func_0x(pbVar27 + uVar58,0x1a);
                              uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                              uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                              pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                            }
                            iVar15 = iVar15 + 1;
                            puVar45 = puVar45 + 1;
                          } while (iVar15 < (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7));
                          uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                        }
                        break;
                      }
                      if (*(ushort *)(pbVar27 + uVar40) < 0x400) break;
                      puVar60 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                      *puVar60 = *puVar60 | 1;
                      uVar11 = sVar14 - 1;
                      uVar47 = (ulonglong)uVar11;
                      *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                      if (uVar11 == 0) break;
                    }
                  }
                  if ((*pbVar27 & 0x40) == 0) {
                    *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                  }
                  else {
                    *(int *)(&stack0x00000036 + lVar20) = (int)uVar43;
                    *(int *)((longlong)&sStackX_10 + lVar20 + 4) = (int)uVar43 + 0xe;
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103ed0;
                    uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103edf;
                    func_0x(uVar23,&stack0x000001f0 + lVar20);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103eeb;
                    iVar15 = func_0x(&stack0x000001f0 + lVar20);
                    uVar36 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar15;
                    uVar43 = (ulonglong)uVar36;
                    *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar36;
                    pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                  if ((*(byte **)(&stack0x0000002e + lVar20) != (byte *)0x0) &&
                     (*(byte **)(&stack0x0000002e + lVar20) < pbVar27 + uVar43)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1040af;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1040b8;
                      lVar25 = func_0x();
                      if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1040d2;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1040ee;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104114;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104122;
                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),0x12);
                    uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                  }
                  if (0x3f3b < (int)uVar43 - 1U) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10413d;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104146;
                      lVar25 = func_0x();
                      if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104160;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10417c;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1041a2;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1041b0;
                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),5);
                  }
                }
LAB_:
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1041b9;
                iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                if ((iVar15 != 0) || (uVar18 != 0)) {
                  bVar7 = **(byte **)((longlong)&pbStackX_18 + lVar20) >> 6;
                  if ((bVar7 & 1) != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1041e8;
                    func_0x
                              ((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000660 + lVar20);
                  }
                  if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104203;
                    puVar26 = (undefined4 *)
                              func_0x((longlong)&sStackX_10 + lVar20 + 2,0x400,
                                              &stack0x000000a4 + lVar20);
                    *(undefined4 *)(&stack0x00000138 + lVar20) = *puVar26;
                    *(undefined2 *)(&stack0x0000013c + lVar20) = *(undefined2 *)(puVar26 + 1);
                    *(undefined2 *)(&stack0x0000013e + lVar20) =
                         *(undefined2 *)((longlong)puVar26 + 6);
                  }
                  if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x20) == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104233;
                    func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  }
                  lVar24 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4) +
                           *(longlong *)((longlong)&pbStackX_18 + lVar20);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104243;
                  iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                  if (iVar15 == 0) {
                    uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                    uVar43 = (ulonglong)uVar11;
                    uVar36 = *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                    puVar45 = (ushort *)(lVar25 + (ulonglong)uVar36);
                    uVar36 = uVar36 + (uVar11 + 1) * 2;
                    uVar58 = 0;
                    iVar15 = 0;
                    if (*puVar45 != 0) {
                      do {
                        uVar54 = puVar45[uVar58 + 1];
                        puVar45[(uVar58 & 0xffff) + 1] = puVar45[(uVar58 & 0xffff) + 1] & 0x8000;
                        puVar45[(uVar58 & 0xffff) + 1] =
                             puVar45[(uVar58 & 0xffff) + 1] | (uVar54 & 0x7fff) + 2 & 0x7fff;
                        uVar40 = (int)uVar58 + 1;
                        uVar58 = (ulonglong)uVar40;
                      } while (uVar40 < *puVar45);
                      lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    }
                    iVar42 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10433a;
                    func_0x
                              ((ulonglong)uVar36 + 2 + lVar25,(ulonglong)uVar36 + lVar25,
                               iVar42 - uVar36);
                    piVar1 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                    *piVar1 = *piVar1 + 2;
                    uVar36 = *(int *)(&stack0x00000028 + lVar20) + 2;
                    *(uint *)(&stack0x00000028 + lVar20) = uVar36;
                    if (uVar11 != 0) {
                      uVar36 = puVar45[(ulonglong)(uVar11 - 1) + 1] & 0x7fff;
                    }
                    if ((uint)uVar11 < uVar11 + 1) {
                      do {
                        puVar45[(uVar43 & 0xffff) + 1] = (ushort)uVar36 & 0x7fff;
                        uVar40 = (int)uVar43 + 1;
                        uVar43 = (ulonglong)uVar40;
                      } while (uVar40 < uVar11 + 1);
                    }
                    *puVar45 = *puVar45 + 1;
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10438a;
                    func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    uVar11 = *(ushort *)
                              (lVar24 + 2 + (ulonglong)*(ushort *)(&stack0x0000002c + lVar20) * 2);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1043a2;
                    func_0x(&stack0x00000338 + lVar20);
                    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar20) = 0;
                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) =
                         *(undefined8 *)(&stack0x00000058 + lVar20);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1043c5;
                    func_0x(&stack0x00000328 + lVar20,piVar46,uVar18,0);
                    *(undefined **)(&stack0xffffffffffffffe8 + lVar20) = &stack0x0000014c + lVar20;
                    *(undefined **)(&stack0xffffffffffffffe0 + lVar20) = &stack0x00000328 + lVar20;
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1043fb;
                    func_0x(&stack0x0000003a + lVar20,uVar11 & 0x7fff,0x1f9e,1);
                    iVar42 = *(int *)(&stack0x0000014c + lVar20);
                    puVar48 = *(uint **)(&stack0x00000058 + lVar20);
                  }
                  else {
                    uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                    lVar37 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4) + lVar25;
                    uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                    if (uVar11 != 0) {
                      uVar36 = *(ushort *)(lVar37 + (ulonglong)uVar11 * 2) & 0x7fff;
                    }
                    uVar40 = *(ushort *)(lVar37 + 2 + (ulonglong)(uint)uVar11 * 2) & 0x7fff;
                    if (((uVar36 < *(uint *)(&stack0x00000028 + lVar20)) || (uVar40 < uVar36)) ||
                       (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar40)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104296;
                      func_0x(lVar25,7);
                    }
                    iVar15 = uVar40 - uVar36;
                    puVar48 = *(uint **)(&stack0x00000058 + lVar20);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1042ae;
                    iVar42 = func_0x(&stack0x0000003a + lVar20,puVar48,piVar46,uVar18);
                  }
                  iVar15 = (iVar42 - iVar15) + *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                  *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar15;
                  if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                    *(ushort *)
                     (lVar24 + 2 + (ulonglong)(*(ushort *)(&stack0x0000002c + lVar20) + 1) * 2) =
                         (ushort)iVar15 | 0x8000;
                    iVar15 = (*(int *)((longlong)&sStackX_10 + lVar20 + 4) -
                             *(int *)(&stack0x000000a4 + lVar20)) + -2;
                  }
                  *(ushort *)(lVar24 + 2 + (ulonglong)*(ushort *)(&stack0x0000002c + lVar20) * 2) =
                       (ushort)iVar15 | 0x8000;
                  lVar25 = (longlong)&sStackX_10 + lVar20 + 2;
                  if (iVar42 == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104456;
                    func_0x(lVar25,*(ushort *)(&stack0x0000002c + lVar20) + 1);
                    if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x20) != 0) {
                      *(short *)(&stack0x0000002c + lVar20) =
                           *(short *)(&stack0x0000002c + lVar20) + 1;
                      puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                      *puVar45 = *puVar45 & 0xfffd;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104475;
                      func_0x(&stack0x0000003a + lVar20);
                    }
                  }
                  else {
                    puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                    *puVar45 = *puVar45 | 2;
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104488;
                    uVar12 = func_0x(lVar25,&stack0x0000018c + lVar20);
                    *(undefined2 *)(&stack0x0000003a + lVar20) = uVar12;
                  }
                  if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1044ae;
                    func_0x((longlong)&sStackX_10 + lVar20 + 2,0x400,
                                    *(undefined4 *)(&stack0x000000a4 + lVar20),
                                    &stack0x00000138 + lVar20);
                  }
                  if ((bVar7 & 1) == 0) goto LAB_;
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1044c7;
                  func_0x
                            ((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000660 + lVar20);
                  goto LAB_;
                }
LAB_:
                puVar48 = *(uint **)(&stack0x00000058 + lVar20);
                goto LAB_;
              }
              if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                uVar36 = *(uint *)((longlong)&uStackX_20 + lVar20);
                uVar58 = (ulonglong)uVar36;
                *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar36;
                pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                if ((*pbVar27 & 0x10) != 0) {
                  uVar36 = uVar36 + 2 + (*(ushort *)(pbVar27 + uVar58) + 7 >> 3);
                  uVar58 = (ulonglong)uVar36;
                  *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar36;
                }
                if ((*pbVar27 & 0x20) == 0) {
                  *(int *)((longlong)&sStackX_10 + lVar20 + 4) = (int)uVar58;
                  *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                  *(int *)(&stack0x00000028 + lVar20) = (int)uVar58;
                }
                else {
                  puVar45 = (ushort *)(pbVar27 + uVar58);
                  *(ushort **)(&stack0x00000060 + lVar20) = puVar45;
                  uVar11 = *puVar45;
                  *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                  if (uVar11 == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1031dd;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1031e6;
                      lVar25 = func_0x();
                      if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103200;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10321c;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103242;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103250;
                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),3);
                    uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                    pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                  uVar36 = (int)uVar58 + (*(ushort *)(&stack0x0000002c + lVar20) + 1) * 2;
                  *(uint *)(&stack0x00000028 + lVar20) = uVar36;
                  if (0x1f9e < uVar36) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103280;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103289;
                      lVar25 = func_0x();
                      if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1032a3;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1032bf;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1032e5;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1032f3;
                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                    uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                    uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                    pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                  uVar11 = puVar45[*(ushort *)(&stack0x0000002c + lVar20)];
                  *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar11 & 0x7fff;
                  if ((uVar11 & 0x7fff) < uVar36) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103328;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103331;
                      lVar25 = func_0x();
                      if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10334b;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103367;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10338d;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10339b;
                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                    uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                    uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                    pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                  uVar41 = uVar40;
                  if (*(short *)(&stack0x0000002c + lVar20) != 0) {
                    do {
                      puVar45 = puVar45 + 1;
                      uVar38 = *puVar45 & 0x7fff;
                      if ((uVar38 < uVar36) ||
                         (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar38)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1033e4;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1033ed;
                          lVar25 = func_0x();
                          if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103407;
                            cVar8 = func_0x(0x1ebafb0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103423;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103447;
                              (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                            }
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103455;
                        func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                        pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                      }
                      uVar41 = uVar41 + 1;
                      uVar36 = uVar38;
                    } while ((int)uVar41 < (int)(uint)*(ushort *)(&stack0x0000002c + lVar20));
                    uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                    uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                    puVar45 = *(ushort **)(&stack0x00000060 + lVar20);
                  }
                  while( true ) {
                    uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                    if (-1 < (short)puVar45[(ulonglong)(uVar11 - 1) + 1]) break;
                    uVar41 = uVar36;
                    if (uVar11 != 1) {
                      uVar41 = *(ushort *)(pbVar27 + (ulonglong)uVar11 * 2 + (uVar58 - 2)) & 0x7fff;
                    }
                    uVar38 = *(ushort *)(pbVar27 + (ulonglong)uVar11 * 2 + uVar58) & 0x7fff;
                    if (((uVar41 < uVar36) || (uVar38 < uVar41)) ||
                       (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar38)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1034e2;
                      func_0x(pbVar27,7);
                      uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                      uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                      pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                    }
                    if ((uVar41 < uVar36) ||
                       (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar41)) goto LAB_;
                    if (*(ushort *)(pbVar27 + uVar41) == 5) {
                      puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                      *puVar45 = *puVar45 | 2;
                      *(short *)(&stack0x0000002c + lVar20) =
                           *(short *)(&stack0x0000002c + lVar20) + -1;
                      uVar58 = (ulonglong)(uVar41 & 0xffff);
                      *(short *)(&stack0x0000003a + lVar20) = (short)uVar41;
                      pbVar55 = pbVar27 + uVar58;
                      uVar11 = *(ushort *)(&stack0x0000003c + lVar20);
                      if ((*(ushort *)(pbVar55 + 2) & 0x4000) == 0) {
                        uVar11 = uVar11 & 0xc7ff;
                      }
                      else {
                        uVar11 = uVar11 ^ (*(ushort *)(pbVar55 + 2) ^ uVar11) & 0x3800;
                      }
                      *(ushort *)(&stack0x0000003c + lVar20) = uVar11;
                      uVar54 = (uVar11 ^ *(ushort *)(pbVar55 + 2)) & 0x7ff ^ uVar11;
                      *(ushort *)(&stack0x0000003c + lVar20) = uVar54;
                      pbVar44 = pbVar27 + (ulonglong)((uVar11 >> 0xb & 7) * 2) + 4 + uVar58 +
                                          ((ulonglong)uVar54 & 0x7ff) * 2;
                      if (pbVar44 < pbVar55) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1035ca;
                        func_0x(pbVar55,0x19);
                        uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                        uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                        pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                      }
                      if (uVar38 - uVar41 <
                          (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar58) -
                          *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)pbVar44) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103600;
                        func_0x(pbVar27 + uVar58,0x19);
                        uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                        uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                        pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                      }
                      if (((uVar54 & 0x3800) != 0) &&
                         (puVar45 = (ushort *)(pbVar27 + uVar58 + 4), (uVar54 & 0x3800) != 0)) {
                        do {
                          if ((uVar54 & 0x7ff) < (*puVar45 & 0x7ff)) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103655;
                            func_0x(pbVar27 + uVar58,0x1a);
                            uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                            uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                            pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                          }
                          uVar40 = uVar40 + 1;
                          puVar45 = puVar45 + 1;
                        } while ((int)uVar40 <
                                 (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7));
                      }
                      break;
                    }
                    if (*(ushort *)(pbVar27 + uVar41) < 0x400) break;
                    puVar60 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                    *puVar60 = *puVar60 | 1;
                    psVar21 = (short *)(&stack0x0000002c + lVar20);
                    *psVar21 = *psVar21 + -1;
                    if (*psVar21 == 0) break;
                  }
                }
                if ((*pbVar27 & 0x40) == 0) {
                  *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                }
                else {
                  *(undefined4 *)(&stack0x00000036 + lVar20) =
                       *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4);
                  piVar46 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                  *piVar46 = *piVar46 + 0xe;
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10369e;
                  uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1036ad;
                  func_0x(uVar23,&stack0x000001e8 + lVar20);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1036b9;
                  iVar15 = func_0x(&stack0x000001e8 + lVar20);
                  piVar46 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                  *piVar46 = *piVar46 + iVar15;
                  pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                }
                if ((*(byte **)(&stack0x0000002e + lVar20) != (byte *)0x0) &&
                   (*(byte **)(&stack0x0000002e + lVar20) <
                    pbVar27 + *(uint *)((longlong)&sStackX_10 + lVar20 + 4))) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1036ea;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1036f3;
                    lVar25 = func_0x();
                    if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10370d;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103729;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10374f;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10375d;
                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),0x12);
                }
                if (0x3f3b < *(int *)((longlong)&sStackX_10 + lVar20 + 4) - 1U) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103775;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10377e;
                    lVar25 = func_0x();
                    if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103798;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1037b4;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1037da;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1037e8;
                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),5);
                }
              }
LAB_:
              iVar15 = **(int **)(&stack0x00000058 + lVar20);
              uVar36 = -iVar15;
              if ((uVar18 != 0) || (uVar36 <= *(ushort *)(&stack0x0000002c + lVar20))) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103810;
                func_0x(&stack0x00000580 + lVar20);
                pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                bVar7 = *pbVar27;
                if ((bVar7 >> 6 & 1) != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103832;
                  func_0x
                            ((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000580 + lVar20);
                  pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                }
                if (uVar18 == 0) {
                  uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                }
                else {
                  if ((*pbVar27 & 0x20) == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10384e;
                    func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                  uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                  uVar40 = (uint)uVar11;
                  if (uVar40 < uVar36) {
                    uVar41 = *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                    puVar45 = (ushort *)(pbVar27 + uVar41);
                    uVar41 = uVar41 + 2 + uVar40 * 2;
                    uVar38 = (uVar36 - uVar11) * 2;
                    uVar39 = 0;
                    if (*puVar45 != 0) {
                      do {
                        uVar54 = puVar45[(ulonglong)uVar39 + 1];
                        puVar45[(ulonglong)(uVar39 & 0xffff) + 1] =
                             puVar45[(ulonglong)(uVar39 & 0xffff) + 1] & 0x8000;
                        puVar45[(ulonglong)(uVar39 & 0xffff) + 1] =
                             puVar45[(ulonglong)(uVar39 & 0xffff) + 1] |
                             (uVar54 & 0x7fff) + (short)uVar38 & 0x7fff;
                        uVar39 = uVar39 + 1;
                      } while (uVar39 < *puVar45);
                      pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                    }
                    iVar42 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1038da;
                    func_0x
                              (pbVar27 + (ulonglong)uVar38 + (ulonglong)uVar41,pbVar27 + uVar41,
                               iVar42 - uVar41);
                    piVar46 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                    *piVar46 = *piVar46 + uVar38;
                    uVar38 = *(int *)(&stack0x00000028 + lVar20) + uVar38;
                    *(uint *)(&stack0x00000028 + lVar20) = uVar38;
                    if (uVar11 != 0) {
                      uVar38 = puVar45[(ulonglong)(uVar40 - 1) + 1] & 0x7fff;
                    }
                    do {
                      puVar45[(ulonglong)(uVar40 & 0xffff) + 1] = (ushort)uVar38 & 0x7fff;
                      uVar40 = uVar40 + 1;
                    } while (uVar40 < uVar36);
                    *puVar45 = *puVar45 + (short)(uVar36 - uVar11);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10391c;
                    iVar42 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    if (iVar42 != 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103930;
                      uVar12 = func_0x
                                         ((longlong)&sStackX_10 + lVar20 + 2,
                                          &stack0x00000184 + lVar20);
                      *(undefined2 *)(&stack0x0000003a + lVar20) = uVar12;
                    }
                    uVar11 = (ushort)uVar36;
                    *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                    pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                }
                uVar40 = *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                uVar58 = (ulonglong)uVar40;
                if (uVar11 < uVar36) {
                  uVar41 = *(ushort *)(pbVar27 + (ulonglong)uVar11 * 2 + uVar58) & 0x7fff;
                  uVar38 = 0;
                }
                else {
                  uVar41 = *(uint *)(&stack0x00000028 + lVar20);
                  if (iVar15 != -1) {
                    uVar41 = *(ushort *)(pbVar27 + (longlong)(int)uVar36 * 2 + (uVar58 - 2)) &
                             0x7fff;
                  }
                  uVar38 = *(ushort *)(pbVar27 + (longlong)(int)uVar36 * 2 + uVar58) & 0x7fff;
                  if (((uVar41 < *(uint *)(&stack0x00000028 + lVar20)) || (uVar38 < uVar41)) ||
                     (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar38)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103998;
                    func_0x(pbVar27,7);
                    uVar40 = *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                    pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                  uVar38 = uVar38 - uVar41;
                }
                uVar58 = (ulonglong)uVar41;
                if (uVar18 != uVar38) {
                  puVar45 = (ushort *)(pbVar27 + uVar40);
                  uVar19 = *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1039cf;
                  uVar19 = func_0x(uVar19,uVar38 + uVar41);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1039eb;
                  func_0x
                            ((longlong)(int)uVar18 + uVar58 +
                             *(longlong *)((longlong)&pbStackX_18 + lVar20),
                             (longlong)(int)uVar38 + uVar58 +
                             *(longlong *)((longlong)&pbStackX_18 + lVar20),uVar19);
                  uVar40 = uVar36 - 1;
                  if ((int)uVar40 < (int)(uint)*puVar45) {
                    do {
                      uVar11 = puVar45[(longlong)(int)uVar40 + 1];
                      puVar45[((ulonglong)uVar40 & 0xffff) + 1] =
                           puVar45[((ulonglong)uVar40 & 0xffff) + 1] & 0x8000;
                      puVar45[((ulonglong)uVar40 & 0xffff) + 1] =
                           puVar45[((ulonglong)uVar40 & 0xffff) + 1] |
                           ((uVar11 & 0x7fff) - (short)uVar38) + (short)uVar18 & 0x7fff;
                      uVar40 = uVar40 + 1;
                    } while ((int)uVar40 < (int)(uint)*puVar45);
                  }
                  piVar46 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                  *piVar46 = *piVar46 + (uVar18 - uVar38);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103a4f;
                  iVar42 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if (iVar42 != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103a63;
                    uVar12 = func_0x
                                       ((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000188 + lVar20
                                       );
                    *(undefined2 *)(&stack0x0000003a + lVar20) = uVar12;
                  }
                  pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103a7d;
                func_0x
                          (pbVar27 + uVar58,*(undefined8 *)(&stack0x00000070 + lVar20),uVar18);
                if ((uVar18 == 0) && (-(uint)*(ushort *)(&stack0x0000002c + lVar20) == iVar15)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103a9b;
                  func_0x((longlong)&sStackX_10 + lVar20 + 2,uVar36,1);
                }
                if ((bVar7 >> 6 & 1) == 0) goto LAB_;
                puVar28 = &stack0x00000580;
LAB_:
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101ec1;
                func_0x
                          ((longlong)&sStackX_10 + lVar20 + 2,(longlong)puVar28 + lVar20);
              }
              puVar48 = *(uint **)(&stack0x00000058 + lVar20);
            }
            else {
              bVar7 = (byte)*(ushort *)((longlong)puVar48 + 6);
              if ((*(ushort *)((longlong)puVar48 + 6) & 8) == 0) {
                pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                  *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                  uVar36 = *(uint *)((longlong)&uStackX_20 + lVar20);
                  uVar58 = (ulonglong)uVar36;
                  *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar36;
                  if ((*pbVar27 & 0x10) != 0) {
                    uVar36 = uVar36 + 2 + (*(ushort *)(pbVar27 + uVar58) + 7 >> 3);
                    uVar58 = (ulonglong)uVar36;
                    *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar36;
                  }
                  if ((*pbVar27 & 0x20) == 0) {
                    *(int *)((longlong)&sStackX_10 + lVar20 + 4) = (int)uVar58;
                    *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                    *(int *)(&stack0x00000028 + lVar20) = (int)uVar58;
                  }
                  else {
                    puVar45 = (ushort *)(pbVar27 + uVar58);
                    *(ushort **)(&stack0x00000060 + lVar20) = puVar45;
                    uVar11 = *puVar45;
                    *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                    if (uVar11 == 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102a3b;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102a44;
                        lVar25 = func_0x();
                        if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102a5e;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102a7a;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102aa0;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102aae;
                      func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),3);
                      uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                      uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                      pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                    }
                    uVar36 = (int)uVar58 + (uVar11 + 1) * 2;
                    *(uint *)(&stack0x00000028 + lVar20) = uVar36;
                    if (0x1f9e < uVar36) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102ae2;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102aeb;
                        lVar25 = func_0x();
                        if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102b05;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102b21;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102b47;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102b55;
                      func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                      uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                      uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                      uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                      pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                    }
                    uVar43 = (ulonglong)uVar11;
                    uVar11 = puVar45[uVar43];
                    *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar11 & 0x7fff;
                    if ((uVar11 & 0x7fff) < uVar36) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102b8d;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102b96;
                        lVar25 = func_0x();
                        if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102bb0;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102bcc;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102bf2;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102c00;
                      func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                      uVar43 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                      uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                      uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                      pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                    }
                    uVar41 = uVar40;
                    if ((short)uVar43 != 0) {
                      do {
                        puVar45 = puVar45 + 1;
                        uVar38 = *puVar45 & 0x7fff;
                        if ((uVar38 < uVar36) ||
                           (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar38)) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102c50;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102c59;
                            lVar25 = func_0x();
                            if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102c73;
                              cVar8 = func_0x(0x1ebafb0);
                              if (cVar8 == '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102c8f;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102cb3;
                                (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                              }
                            }
                          }
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102cc1;
                          func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                          uVar43 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                          pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                        }
                        uVar41 = uVar41 + 1;
                        uVar36 = uVar38;
                      } while ((int)uVar41 < (int)uVar43);
                      uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                      uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                      puVar45 = *(ushort **)(&stack0x00000060 + lVar20);
                      piVar46 = *(int **)(&stack0x00000070 + lVar20);
                    }
                    while ((short)puVar45[(ulonglong)((int)uVar43 - 1) + 1] < 0) {
                      uVar41 = uVar36;
                      if ((int)uVar43 != 1) {
                        uVar41 = *(ushort *)(pbVar27 + uVar43 * 2 + (uVar58 - 2)) & 0x7fff;
                      }
                      uVar38 = *(ushort *)(pbVar27 + uVar43 * 2 + uVar58) & 0x7fff;
                      if (((uVar41 < uVar36) || (uVar38 < uVar41)) ||
                         (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar38)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102d54;
                        func_0x(pbVar27,7);
                        uVar43 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                        uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                        uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                        pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                      }
                      if ((uVar41 < uVar36) ||
                         (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar41))
                      goto LAB_;
                      if (*(ushort *)(pbVar27 + uVar41) == 5) {
                        puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                        *puVar45 = *puVar45 | 2;
                        *(short *)(&stack0x0000002c + lVar20) = (short)uVar43 + -1;
                        uVar58 = (ulonglong)(uVar41 & 0xffff);
                        *(short *)(&stack0x0000003a + lVar20) = (short)uVar41;
                        pbVar55 = pbVar27 + uVar58;
                        uVar11 = *(ushort *)(&stack0x0000003c + lVar20);
                        if ((*(ushort *)(pbVar55 + 2) & 0x4000) == 0) {
                          uVar11 = uVar11 & 0xc7ff;
                        }
                        else {
                          uVar11 = uVar11 ^ (*(ushort *)(pbVar55 + 2) ^ uVar11) & 0x3800;
                        }
                        *(ushort *)(&stack0x0000003c + lVar20) = uVar11;
                        uVar54 = (uVar11 ^ *(ushort *)(pbVar55 + 2)) & 0x7ff ^ uVar11;
                        *(ushort *)(&stack0x0000003c + lVar20) = uVar54;
                        pbVar44 = pbVar27 + uVar58 + ((ulonglong)uVar54 & 0x7ff) * 2 +
                                                     (ulonglong)((uVar11 >> 0xb & 7) * 2) + 4;
                        if (pbVar44 < pbVar55) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102e4a;
                          func_0x(pbVar55,0x19);
                          uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                          uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                          pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                        }
                        if (uVar38 - uVar41 <
                            (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar58) -
                            *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)pbVar44) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102e80;
                          func_0x(pbVar27 + uVar58,0x19);
                          uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                          uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                          pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                        }
                        if (((uVar54 & 0x3800) != 0) &&
                           (puVar45 = (ushort *)(pbVar27 + uVar58 + 4), (uVar54 & 0x3800) != 0)) {
                          do {
                            if ((uVar54 & 0x7ff) < (*puVar45 & 0x7ff)) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102ee5;
                              func_0x(pbVar27 + uVar58,0x1a);
                              uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                              uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                              pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                            }
                            uVar40 = uVar40 + 1;
                            puVar45 = puVar45 + 1;
                          } while ((int)uVar40 <
                                   (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7));
                        }
                        break;
                      }
                      if (*(ushort *)(pbVar27 + uVar41) < 0x400) break;
                      puVar60 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                      *puVar60 = *puVar60 | 1;
                      uVar11 = (short)uVar43 - 1;
                      uVar43 = (ulonglong)uVar11;
                      *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                      if (uVar11 == 0) break;
                    }
                  }
                  if ((*pbVar27 & 0x40) == 0) {
                    *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                  }
                  else {
                    *(undefined4 *)(&stack0x00000036 + lVar20) =
                         *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4);
                    piVar1 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                    *piVar1 = *piVar1 + 0xe;
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102f2e;
                    uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102f3d;
                    func_0x(uVar23,&stack0x000001e0 + lVar20);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102f49;
                    iVar15 = func_0x(&stack0x000001e0 + lVar20);
                    piVar1 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                    *piVar1 = *piVar1 + iVar15;
                    pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                  if ((*(byte **)(&stack0x0000002e + lVar20) != (byte *)0x0) &&
                     (*(byte **)(&stack0x0000002e + lVar20) <
                      pbVar27 + *(uint *)((longlong)&sStackX_10 + lVar20 + 4))) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102f7e;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102f87;
                      lVar25 = func_0x();
                      if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102fa1;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102fbd;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102fe3;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102ff1;
                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),0x12);
                    pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                  if (0x3f3b < *(int *)((longlong)&sStackX_10 + lVar20 + 4) - 1U) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103011;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10301a;
                      lVar25 = func_0x();
                      if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103034;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103050;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103076;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x103084;
                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),5);
                    pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                }
LAB_:
                puVar48 = *(uint **)(&stack0x00000058 + lVar20);
                uVar36 = *puVar48;
                uVar40 = uVar36 + uVar18;
                if (*(uint *)((longlong)&uStackX_20 + lVar20) < uVar40) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1030ad;
                  func_0x((longlong)&sStackX_10 + lVar20 + 2,0,
                                  uVar40 - *(uint *)((longlong)&uStackX_20 + lVar20),0);
                  pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  if ((1 << (*pbVar27 & 0xe) & 0x1105U) != 0) {
                    *(short *)(pbVar27 + 2) = (short)uVar40;
                    pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                  *(uint *)((longlong)&uStackX_20 + lVar20) = uVar40;
                  uVar36 = *puVar48;
                }
                if ((piVar46 != (int *)0x0) && (uVar18 != 0)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1030ef;
                  func_0x(pbVar27 + (int)uVar36,piVar46,uVar18);
                }
              }
              else {
                cVar8 = *(char *)piVar46;
                uVar40 = uVar36 + 1;
                if (*(uint *)((longlong)&uStackX_20 + lVar20) < uVar40) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10297d;
                  func_0x((longlong)&sStackX_10 + lVar20 + 2,0,
                                  uVar40 - *(uint *)((longlong)&uStackX_20 + lVar20),0);
                  pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  if ((1 << (*pbVar27 & 0xe) & 0x1105U) != 0) {
                    *(short *)(pbVar27 + 2) = (short)uVar40;
                    pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                  *(uint *)((longlong)&uStackX_20 + lVar20) = uVar40;
                  bVar7 = *(byte *)((longlong)puVar48 + 6);
                }
                else {
                  pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                }
                if (cVar8 == '\0') {
                  pbVar27[(int)uVar36] = pbVar27[(int)uVar36] & ~(byte)(1 << (bVar7 & 7));
                }
                else {
                  pbVar27[(int)uVar36] = pbVar27[(int)uVar36] | (byte)(1 << (bVar7 & 7));
                }
              }
            }
LAB_:
            uVar36 = *(uint *)(&stack0x00000048 + lVar20);
            goto LAB_;
          }
          if (cVar8 == '\b') {
            pbVar27 = *(byte **)(&stack0x00000118 + lVar20);
            *(byte **)(&stack0x00000060 + lVar20) = pbVar27;
            puVar48 = *(uint **)(&stack0x00000058 + lVar20);
            uVar36 = *puVar48;
            if ((int)uVar36 < 0) {
              if ((uVar36 & 0xc0000000) != 0x80000000) {
                if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                  *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                  uVar36 = *(uint *)((longlong)&uStackX_20 + lVar20);
                  uVar58 = (ulonglong)uVar36;
                  *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar36;
                  pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  if ((*pbVar55 & 0x10) != 0) {
                    uVar36 = uVar36 + 2 + (*(ushort *)(pbVar55 + uVar58) + 7 >> 3);
                    uVar58 = (ulonglong)uVar36;
                    *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar36;
                  }
                  if ((*pbVar55 & 0x20) == 0) {
                    *(int *)((longlong)&sStackX_10 + lVar20 + 4) = (int)uVar58;
                    *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                    *(int *)(&stack0x00000028 + lVar20) = (int)uVar58;
                    uVar43 = uVar58;
                  }
                  else {
                    puVar45 = (ushort *)(pbVar55 + uVar58);
                    *(ushort **)(&stack0x00000070 + lVar20) = puVar45;
                    uVar11 = *puVar45;
                    *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                    if (uVar11 == 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1015d6;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1015df;
                        lVar25 = func_0x();
                        if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1015f9;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101615;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10163f;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10164d;
                      func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),3);
                      uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                      uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                      pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                    }
                    uVar36 = (int)uVar58 + (uVar11 + 1) * 2;
                    *(uint *)(&stack0x00000028 + lVar20) = uVar36;
                    if (0x1f9e < uVar36) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101680;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101689;
                        lVar25 = func_0x();
                        if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1016a3;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1016bf;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1016e9;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1016f7;
                      func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                      uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                      uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                      uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                      pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                    }
                    uVar47 = (ulonglong)uVar11;
                    uVar40 = puVar45[uVar47] & 0x7fff;
                    *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar40;
                    if (uVar40 < uVar36) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10172f;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101738;
                        lVar25 = func_0x();
                        if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101752;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10176e;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101798;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1017a6;
                      func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                      uVar47 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                      uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                      uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                      pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                      uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                    }
                    uVar43 = (ulonglong)uVar40;
                    iVar15 = 0;
                    if ((short)uVar47 != 0) {
                      do {
                        puVar45 = puVar45 + 1;
                        uVar40 = *puVar45 & 0x7fff;
                        if ((uVar40 < uVar36) || ((uint)uVar43 < uVar40)) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101800;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101809;
                            lVar25 = func_0x();
                            if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101823;
                              cVar8 = func_0x(0x1ebafb0);
                              if (cVar8 == '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10183f;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101863;
                                (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                              }
                            }
                          }
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101871;
                          func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                          uVar47 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                          pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                          uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                        }
                        iVar15 = iVar15 + 1;
                        uVar36 = uVar40;
                      } while (iVar15 < (int)uVar47);
                      uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                      uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                      puVar45 = *(ushort **)(&stack0x00000070 + lVar20);
                      pbVar27 = *(byte **)(&stack0x00000060 + lVar20);
                    }
                    while( true ) {
                      sVar14 = (short)uVar47;
                      if (-1 < (short)puVar45[(ulonglong)((int)uVar47 - 1) + 1]) break;
                      uVar40 = uVar36;
                      if ((int)uVar47 != 1) {
                        uVar40 = *(ushort *)(pbVar55 + uVar47 * 2 + (uVar58 - 2)) & 0x7fff;
                      }
                      uVar18 = *(ushort *)(pbVar55 + uVar47 * 2 + uVar58) & 0x7fff;
                      if (((uVar40 < uVar36) || (uVar18 < uVar40)) || ((uint)uVar43 < uVar18)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101905;
                        func_0x(pbVar55,7);
                        sVar14 = *(short *)(&stack0x0000002c + lVar20);
                        uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                        uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                        pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                        uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                      }
                      if ((uVar40 < uVar36) || ((uint)uVar43 < uVar40)) goto LAB_;
                      if (*(ushort *)(pbVar55 + uVar40) == 5) {
                        puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                        *puVar45 = *puVar45 | 2;
                        *(short *)(&stack0x0000002c + lVar20) = sVar14 + -1;
                        uVar58 = (ulonglong)(uVar40 & 0xffff);
                        *(short *)(&stack0x0000003a + lVar20) = (short)uVar40;
                        pbVar44 = pbVar55 + uVar58;
                        uVar11 = *(ushort *)(&stack0x0000003c + lVar20);
                        if ((*(ushort *)(pbVar44 + 2) & 0x4000) == 0) {
                          uVar11 = uVar11 & 0xc7ff;
                        }
                        else {
                          uVar11 = uVar11 ^ (*(ushort *)(pbVar44 + 2) ^ uVar11) & 0x3800;
                        }
                        *(ushort *)(&stack0x0000003c + lVar20) = uVar11;
                        uVar54 = (uVar11 ^ *(ushort *)(pbVar44 + 2)) & 0x7ff ^ uVar11;
                        *(ushort *)(&stack0x0000003c + lVar20) = uVar54;
                        pbVar52 = pbVar55 + (ulonglong)((uVar11 >> 0xb & 7) * 2) + 4 + uVar58 +
                                            ((ulonglong)uVar54 & 0x7ff) * 2;
                        if (pbVar52 < pbVar44) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1019fb;
                          func_0x(pbVar44,0x19);
                          uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                          uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                          pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                          uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                        }
                        if (uVar18 - uVar40 <
                            (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar58) -
                            *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)pbVar52) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101a33;
                          func_0x(pbVar55 + uVar58,0x19);
                          uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                          uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                          pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                          uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                        }
                        iVar15 = 0;
                        if (((uVar54 & 0x3800) != 0) &&
                           (puVar45 = (ushort *)(pbVar55 + uVar58 + 4), (uVar54 & 0x3800) != 0)) {
                          do {
                            if ((uVar54 & 0x7ff) < (*puVar45 & 0x7ff)) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101a90;
                              func_0x(pbVar55 + uVar58,0x1a);
                              uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                              uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                              pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                            }
                            iVar15 = iVar15 + 1;
                            puVar45 = puVar45 + 1;
                          } while (iVar15 < (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7));
                          uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                        }
                        break;
                      }
                      if (*(ushort *)(pbVar55 + uVar40) < 0x400) break;
                      puVar60 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                      *puVar60 = *puVar60 | 1;
                      uVar11 = sVar14 - 1;
                      uVar47 = (ulonglong)uVar11;
                      *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                      if (uVar11 == 0) break;
                    }
                  }
                  if ((*pbVar55 & 0x40) == 0) {
                    *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                  }
                  else {
                    *(int *)(&stack0x00000036 + lVar20) = (int)uVar43;
                    *(int *)((longlong)&sStackX_10 + lVar20 + 4) = (int)uVar43 + 0xe;
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101ae4;
                    uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101af3;
                    func_0x(uVar23,&stack0x000001d0 + lVar20);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101aff;
                    iVar15 = func_0x(&stack0x000001d0 + lVar20);
                    uVar36 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar15;
                    uVar43 = (ulonglong)uVar36;
                    *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar36;
                    pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                  if ((*(byte **)(&stack0x0000002e + lVar20) != (byte *)0x0) &&
                     (*(byte **)(&stack0x0000002e + lVar20) < pbVar55 + uVar43)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101b3c;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101b45;
                      lVar25 = func_0x();
                      if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101b5f;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101b7b;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101ba1;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101baf;
                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),0x12);
                    uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                  }
                  if (0x3f3b < (int)uVar43 - 1U) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101bca;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101bd3;
                      lVar25 = func_0x();
                      if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101bed;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101c09;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101c2f;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101c3d;
                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),5);
                  }
                }
LAB_:
                uVar36 = -**(int **)(&stack0x00000058 + lVar20);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101c53;
                func_0x(&stack0x000003c0 + lVar20);
                pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                bVar7 = *pbVar55;
                if ((bVar7 >> 6 & 1) != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101c75;
                  func_0x
                            ((longlong)&sStackX_10 + lVar20 + 2,&stack0x000003c0 + lVar20);
                  pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                }
                if ((*pbVar55 & 0x20) == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101c88;
                  func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                }
                uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                uVar58 = (ulonglong)uVar11;
                uVar40 = (uint)uVar11;
                if (uVar40 < uVar36) {
                  uVar18 = *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                  puVar45 = (ushort *)(pbVar55 + uVar18);
                  uVar18 = uVar18 + 2 + uVar40 * 2;
                  uVar41 = (uVar36 - uVar11) * 2;
                  uVar38 = 0;
                  if (*puVar45 != 0) {
                    do {
                      uVar54 = puVar45[(ulonglong)uVar38 + 1];
                      puVar45[(ulonglong)(uVar38 & 0xffff) + 1] =
                           puVar45[(ulonglong)(uVar38 & 0xffff) + 1] & 0x8000;
                      puVar45[(ulonglong)(uVar38 & 0xffff) + 1] =
                           puVar45[(ulonglong)(uVar38 & 0xffff) + 1] |
                           (uVar54 & 0x7fff) + (short)uVar41 & 0x7fff;
                      uVar38 = uVar38 + 1;
                    } while (uVar38 < *puVar45);
                    pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                  iVar15 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101d13;
                  func_0x
                            (pbVar55 + (ulonglong)uVar41 + (ulonglong)uVar18,pbVar55 + uVar18,
                             iVar15 - uVar18);
                  piVar46 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                  *piVar46 = *piVar46 + uVar41;
                  uVar41 = *(int *)(&stack0x00000028 + lVar20) + uVar41;
                  *(uint *)(&stack0x00000028 + lVar20) = uVar41;
                  if (uVar11 != 0) {
                    uVar41 = puVar45[(ulonglong)(uVar40 - 1) + 1] & 0x7fff;
                  }
                  do {
                    puVar45[(ulonglong)(uVar40 & 0xffff) + 1] = (ushort)uVar41 & 0x7fff;
                    uVar40 = uVar40 + 1;
                  } while (uVar40 < uVar36);
                  *puVar45 = *puVar45 + (short)(uVar36 - uVar11);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101d5c;
                  iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if (iVar15 != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101d70;
                    uVar12 = func_0x
                                       ((longlong)&sStackX_10 + lVar20 + 2,&stack0x00000178 + lVar20
                                       );
                    *(undefined2 *)(&stack0x0000003a + lVar20) = uVar12;
                  }
                  uVar58 = (ulonglong)uVar36 & 0xffff;
                  *(short *)(&stack0x0000002c + lVar20) = (short)uVar36;
                  pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                }
                uVar43 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                if ((uint)uVar58 < uVar36) {
                  uVar58 = (ulonglong)(*(ushort *)(pbVar55 + uVar58 * 2 + uVar43) & 0x7fff);
                  iVar15 = 0;
LAB_:
                  puVar45 = (ushort *)(pbVar55 + uVar43);
                  uVar19 = *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101e0b;
                  uVar19 = func_0x(uVar19,iVar15 + (int)uVar58);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101e27;
                  func_0x
                            (*(longlong *)((longlong)&pbStackX_18 + lVar20) + 1 + uVar58,
                             uVar58 + *(longlong *)((longlong)&pbStackX_18 + lVar20) +
                                      (longlong)iVar15,uVar19);
                  uVar36 = uVar36 - 1;
                  if ((int)uVar36 < (int)(uint)*puVar45) {
                    do {
                      uVar11 = puVar45[(longlong)(int)uVar36 + 1];
                      puVar45[((ulonglong)uVar36 & 0xffff) + 1] =
                           puVar45[((ulonglong)uVar36 & 0xffff) + 1] & 0x8000;
                      puVar45[((ulonglong)uVar36 & 0xffff) + 1] =
                           puVar45[((ulonglong)uVar36 & 0xffff) + 1] |
                           ((uVar11 & 0x7fff) - (short)iVar15) + 1 & 0x7fff;
                      uVar36 = uVar36 + 1;
                    } while ((int)uVar36 < (int)(uint)*puVar45);
                  }
                  piVar46 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                  *piVar46 = *piVar46 + (1 - iVar15);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101e80;
                  iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  if (iVar15 != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101e94;
                    uVar12 = func_0x
                                       ((longlong)&sStackX_10 + lVar20 + 2,&stack0x0000017c + lVar20
                                       );
                    *(undefined2 *)(&stack0x0000003a + lVar20) = uVar12;
                  }
                  pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                }
                else {
                  uVar40 = *(uint *)(&stack0x00000028 + lVar20);
                  if (uVar36 != 1) {
                    uVar40 = *(ushort *)(pbVar55 + (longlong)(int)uVar36 * 2 + (uVar43 - 2)) &
                             0x7fff;
                  }
                  uVar58 = (ulonglong)uVar40;
                  uVar18 = *(ushort *)(pbVar55 + (longlong)(int)uVar36 * 2 + uVar43) & 0x7fff;
                  if (((uVar40 < *(uint *)(&stack0x00000028 + lVar20)) || (uVar18 < uVar40)) ||
                     (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar18)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101dd4;
                    func_0x(pbVar55,7);
                    uVar43 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                    pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                  iVar15 = uVar18 - uVar40;
                  if (iVar15 != 1) goto LAB_;
                }
                pbVar55[uVar58] = *pbVar27;
                if ((bVar7 >> 6 & 1) != 0) {
                  puVar28 = &stack0x000003c0;
                  goto LAB_;
                }
                goto LAB_;
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101ed9;
              func_0x(&stack0x000004a0 + lVar20);
              *(undefined4 *)(&stack0x000000a0 + lVar20) = 0;
              if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
                *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
                uVar36 = *(uint *)((longlong)&uStackX_20 + lVar20);
                uVar58 = (ulonglong)uVar36;
                *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar36;
                pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                if ((*pbVar55 & 0x10) != 0) {
                  uVar36 = uVar36 + 2 + (*(ushort *)(pbVar55 + uVar58) + 7 >> 3);
                  uVar58 = (ulonglong)uVar36;
                  *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar36;
                }
                if ((*pbVar55 & 0x20) == 0) {
                  *(int *)((longlong)&sStackX_10 + lVar20 + 4) = (int)uVar58;
                  *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                  *(int *)(&stack0x00000028 + lVar20) = (int)uVar58;
                  uVar43 = uVar58;
                }
                else {
                  puVar45 = (ushort *)(pbVar55 + uVar58);
                  *(ushort **)(&stack0x00000070 + lVar20) = puVar45;
                  uVar11 = *puVar45;
                  *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                  if (uVar11 == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101f43;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101f4c;
                      lVar25 = func_0x();
                      if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101f66;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101f82;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101fac;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101fba;
                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),3);
                    uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                    uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                    pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                  uVar36 = (int)uVar58 + (uVar11 + 1) * 2;
                  *(uint *)(&stack0x00000028 + lVar20) = uVar36;
                  if (0x1f9e < uVar36) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101fed;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101ff6;
                      lVar25 = func_0x();
                      if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102010;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10202c;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102056;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102064;
                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                    uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                    uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                    uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                    pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                  uVar47 = (ulonglong)uVar11;
                  uVar40 = puVar45[uVar47] & 0x7fff;
                  *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar40;
                  if (uVar40 < uVar36) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10209c;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1020a5;
                      lVar25 = func_0x();
                      if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1020bf;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1020db;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102105;
                          (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102113;
                    func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                    uVar47 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                    uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                    uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                    pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                    uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                  }
                  uVar43 = (ulonglong)uVar40;
                  iVar15 = 0;
                  if ((short)uVar47 != 0) {
                    do {
                      puVar45 = puVar45 + 1;
                      uVar40 = *puVar45 & 0x7fff;
                      if ((uVar40 < uVar36) || ((uint)uVar43 < uVar40)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102165;
                        cVar8 = func_0x(0x1ebafb0);
                        if (cVar8 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10216e;
                          lVar25 = func_0x();
                          if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102188;
                            cVar8 = func_0x(0x1ebafb0);
                            if (cVar8 == '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1021a4;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1021c8;
                              (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                            }
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1021d6;
                        func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                        uVar47 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                        pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                        uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                      }
                      iVar15 = iVar15 + 1;
                      uVar36 = uVar40;
                    } while (iVar15 < (int)uVar47);
                    uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                    uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                    puVar45 = *(ushort **)(&stack0x00000070 + lVar20);
                    pbVar27 = *(byte **)(&stack0x00000060 + lVar20);
                  }
                  while( true ) {
                    sVar14 = (short)uVar47;
                    if (-1 < (short)puVar45[(ulonglong)((int)uVar47 - 1) + 1]) break;
                    uVar40 = uVar36;
                    if ((int)uVar47 != 1) {
                      uVar40 = *(ushort *)(pbVar55 + uVar47 * 2 + (uVar58 - 2)) & 0x7fff;
                    }
                    uVar18 = *(ushort *)(pbVar55 + uVar47 * 2 + uVar58) & 0x7fff;
                    if (((uVar40 < uVar36) || (uVar18 < uVar40)) || ((uint)uVar43 < uVar18)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102271;
                      func_0x(pbVar55,7);
                      sVar14 = *(short *)(&stack0x0000002c + lVar20);
                      uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                      uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                      pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                      uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                    }
                    if ((uVar40 < uVar36) || ((uint)uVar43 < uVar40)) goto LAB_;
                    if (*(ushort *)(pbVar55 + uVar40) == 5) {
                      puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                      *puVar45 = *puVar45 | 2;
                      *(short *)(&stack0x0000002c + lVar20) = sVar14 + -1;
                      uVar58 = (ulonglong)(uVar40 & 0xffff);
                      *(short *)(&stack0x0000003a + lVar20) = (short)uVar40;
                      pbVar44 = pbVar55 + uVar58;
                      uVar11 = *(ushort *)(&stack0x0000003c + lVar20);
                      if ((*(ushort *)(pbVar44 + 2) & 0x4000) == 0) {
                        uVar11 = uVar11 & 0xc7ff;
                      }
                      else {
                        uVar11 = uVar11 ^ (*(ushort *)(pbVar44 + 2) ^ uVar11) & 0x3800;
                      }
                      *(ushort *)(&stack0x0000003c + lVar20) = uVar11;
                      uVar54 = (uVar11 ^ *(ushort *)(pbVar44 + 2)) & 0x7ff ^ uVar11;
                      *(ushort *)(&stack0x0000003c + lVar20) = uVar54;
                      pbVar52 = pbVar55 + (ulonglong)((uVar11 >> 0xb & 7) * 2) + 4 + uVar58 +
                                          ((ulonglong)uVar54 & 0x7ff) * 2;
                      if (pbVar52 < pbVar44) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1023aa;
                        func_0x(pbVar44,0x19);
                        uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                        uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                        pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                        uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                      }
                      if (uVar18 - uVar40 <
                          (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar58) -
                          *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)pbVar52) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1023e2;
                        func_0x(pbVar55 + uVar58,0x19);
                        uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                        uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                        pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                        uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                      }
                      iVar15 = 0;
                      if (((uVar54 & 0x3800) != 0) &&
                         (puVar45 = (ushort *)(pbVar55 + uVar58 + 4), (uVar54 & 0x3800) != 0)) {
                        do {
                          if ((uVar54 & 0x7ff) < (*puVar45 & 0x7ff)) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102454;
                            func_0x(pbVar55 + uVar58,0x1a);
                            uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                            uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                            pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                          }
                          iVar15 = iVar15 + 1;
                          puVar45 = puVar45 + 1;
                        } while (iVar15 < (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7));
                        uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                      }
                      break;
                    }
                    if (*(ushort *)(pbVar55 + uVar40) < 0x400) break;
                    puVar60 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                    *puVar60 = *puVar60 | 1;
                    uVar11 = sVar14 - 1;
                    uVar47 = (ulonglong)uVar11;
                    *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                    if (uVar11 == 0) break;
                  }
                }
                if ((*pbVar55 & 0x40) == 0) {
                  *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
                }
                else {
                  *(int *)(&stack0x00000036 + lVar20) = (int)uVar43;
                  *(int *)((longlong)&sStackX_10 + lVar20 + 4) = (int)uVar43 + 0xe;
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1022e4;
                  uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1022f3;
                  func_0x(uVar23,&stack0x000001d8 + lVar20);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1022ff;
                  iVar15 = func_0x(&stack0x000001d8 + lVar20);
                  uVar36 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar15;
                  uVar43 = (ulonglong)uVar36;
                  *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar36;
                  pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                }
                if ((*(byte **)(&stack0x0000002e + lVar20) != (byte *)0x0) &&
                   (*(byte **)(&stack0x0000002e + lVar20) < pbVar55 + uVar43)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1024bc;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1024c5;
                    lVar25 = func_0x();
                    if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1024df;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1024fb;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102521;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10252f;
                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),0x12);
                  uVar43 = (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4);
                }
                if (0x3f3b < (int)uVar43 - 1U) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10254a;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102553;
                    lVar25 = func_0x();
                    if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10256d;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102589;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1025af;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1025bd;
                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),5);
                }
              }
LAB_:
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1025cc;
              func_0x((longlong)&sStackX_10 + lVar20 + 2);
              bVar7 = **(byte **)((longlong)&pbStackX_18 + lVar20) >> 6;
              if ((bVar7 & 1) != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1025ee;
                func_0x
                          ((longlong)&sStackX_10 + lVar20 + 2,&stack0x000004a0 + lVar20);
              }
              if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102609;
                puVar26 = (undefined4 *)
                          func_0x((longlong)&sStackX_10 + lVar20 + 2,0x400,
                                          &stack0x000000a0 + lVar20);
                *(undefined4 *)(&stack0x00000130 + lVar20) = *puVar26;
                *(undefined2 *)(&stack0x00000134 + lVar20) = *(undefined2 *)(puVar26 + 1);
                *(undefined2 *)(&stack0x00000136 + lVar20) = *(undefined2 *)((longlong)puVar26 + 6);
              }
              if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x20) == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102639;
                func_0x((longlong)&sStackX_10 + lVar20 + 2);
              }
              lVar24 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4) +
                       *(longlong *)((longlong)&pbStackX_18 + lVar20);
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102649;
              iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
              lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
              if (iVar15 == 0) {
                uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                uVar43 = (ulonglong)uVar11;
                uVar36 = *(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                puVar45 = (ushort *)(lVar25 + (ulonglong)uVar36);
                uVar36 = uVar36 + (uVar11 + 1) * 2;
                uVar58 = 0;
                iVar15 = 0;
                if (*puVar45 != 0) {
                  do {
                    uVar54 = puVar45[uVar58 + 1];
                    puVar45[(uVar58 & 0xffff) + 1] = puVar45[(uVar58 & 0xffff) + 1] & 0x8000;
                    puVar45[(uVar58 & 0xffff) + 1] =
                         puVar45[(uVar58 & 0xffff) + 1] | (uVar54 & 0x7fff) + 2 & 0x7fff;
                    uVar40 = (int)uVar58 + 1;
                    uVar58 = (ulonglong)uVar40;
                  } while (uVar40 < *puVar45);
                  lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                }
                iVar42 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10272a;
                func_0x
                          ((ulonglong)uVar36 + 2 + lVar25,(ulonglong)uVar36 + lVar25,iVar42 - uVar36
                          );
                piVar46 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                *piVar46 = *piVar46 + 2;
                uVar36 = *(int *)(&stack0x00000028 + lVar20) + 2;
                *(uint *)(&stack0x00000028 + lVar20) = uVar36;
                if (uVar11 != 0) {
                  uVar36 = puVar45[(ulonglong)(uVar11 - 1) + 1] & 0x7fff;
                }
                if ((uint)uVar11 < uVar11 + 1) {
                  do {
                    puVar45[(uVar43 & 0xffff) + 1] = (ushort)uVar36 & 0x7fff;
                    uVar40 = (int)uVar43 + 1;
                    uVar43 = (ulonglong)uVar40;
                  } while (uVar40 < uVar11 + 1);
                }
                *puVar45 = *puVar45 + 1;
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10276b;
                func_0x((longlong)&sStackX_10 + lVar20 + 2);
                uVar11 = *(ushort *)
                          (lVar24 + 2 + (ulonglong)*(ushort *)(&stack0x0000002c + lVar20) * 2);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102783;
                func_0x(&stack0x00000318 + lVar20);
                *(undefined4 *)(&stack0xffffffffffffffe8 + lVar20) = 0;
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) =
                     *(undefined8 *)(&stack0x00000058 + lVar20);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1027ac;
                func_0x(&stack0x00000308 + lVar20,pbVar27,1,0);
                *(undefined **)(&stack0xffffffffffffffe8 + lVar20) = &stack0x00000154 + lVar20;
                *(undefined **)(&stack0xffffffffffffffe0 + lVar20) = &stack0x00000308 + lVar20;
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1027df;
                func_0x(&stack0x0000003a + lVar20,uVar11 & 0x7fff,0x1f9e);
                iVar42 = *(int *)(&stack0x00000154 + lVar20);
                puVar48 = *(uint **)(&stack0x00000058 + lVar20);
              }
              else {
                uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                lVar37 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4) + lVar25;
                uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                if (uVar11 != 0) {
                  uVar36 = *(ushort *)(lVar37 + (ulonglong)uVar11 * 2) & 0x7fff;
                }
                uVar40 = *(ushort *)(lVar37 + 2 + (ulonglong)uVar11 * 2) & 0x7fff;
                if (((uVar36 < *(uint *)(&stack0x00000028 + lVar20)) || (uVar40 < uVar36)) ||
                   (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar40)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102692;
                  func_0x(lVar25,7);
                }
                iVar15 = uVar40 - uVar36;
                puVar48 = *(uint **)(&stack0x00000058 + lVar20);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1026ad;
                iVar42 = func_0x(&stack0x0000003a + lVar20,puVar48,pbVar27);
              }
              iVar15 = (iVar42 - iVar15) + *(int *)((longlong)&sStackX_10 + lVar20 + 4);
              *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar15;
              if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                *(ushort *)
                 (lVar24 + 2 + (ulonglong)(*(ushort *)(&stack0x0000002c + lVar20) + 1) * 2) =
                     (ushort)iVar15 | 0x8000;
                iVar15 = (*(int *)((longlong)&sStackX_10 + lVar20 + 4) -
                         *(int *)(&stack0x000000a0 + lVar20)) + -2;
              }
              *(ushort *)(lVar24 + 2 + (ulonglong)*(ushort *)(&stack0x0000002c + lVar20) * 2) =
                   (ushort)iVar15 | 0x8000;
              lVar25 = (longlong)&sStackX_10 + lVar20 + 2;
              if (iVar42 == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10283a;
                func_0x(lVar25,*(ushort *)(&stack0x0000002c + lVar20) + 1);
                if ((**(byte **)((longlong)&pbStackX_18 + lVar20) & 0x20) != 0) {
                  *(short *)(&stack0x0000002c + lVar20) = *(short *)(&stack0x0000002c + lVar20) + 1;
                  puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                  *puVar45 = *puVar45 & 0xfffd;
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102859;
                  func_0x(&stack0x0000003a + lVar20);
                }
              }
              else {
                puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                *puVar45 = *puVar45 | 2;
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10286c;
                uVar12 = func_0x(lVar25,&stack0x00000180 + lVar20);
                *(undefined2 *)(&stack0x0000003a + lVar20) = uVar12;
              }
              if ((*(byte *)((longlong)&sStackX_10 + lVar20 + 2) & 1) != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x102892;
                func_0x((longlong)&sStackX_10 + lVar20 + 2,0x400,
                                *(undefined4 *)(&stack0x000000a0 + lVar20));
              }
              if ((bVar7 & 1) != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1028ab;
                func_0x
                          ((longlong)&sStackX_10 + lVar20 + 2,&stack0x000004a0 + lVar20);
                goto LAB_;
              }
LAB_:
              uVar36 = *(uint *)(&stack0x00000048 + lVar20);
              goto LAB_;
            }
            bVar7 = (byte)*(ushort *)((longlong)puVar48 + 6);
            if ((*(ushort *)((longlong)puVar48 + 6) & 8) != 0) {
              bVar9 = *pbVar27;
              uVar40 = uVar36 + 1;
              if (*(uint *)((longlong)&uStackX_20 + lVar20) < uVar40) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100de3;
                func_0x((longlong)&sStackX_10 + lVar20 + 2,0,
                                uVar40 - *(uint *)((longlong)&uStackX_20 + lVar20),0);
                pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                if ((1 << (*pbVar27 & 0xe) & 0x1105U) != 0) {
                  *(short *)(pbVar27 + 2) = (short)uVar40;
                  pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                }
                *(uint *)((longlong)&uStackX_20 + lVar20) = uVar40;
                bVar7 = *(byte *)((longlong)puVar48 + 6);
              }
              else {
                pbVar27 = *(byte **)((longlong)&pbStackX_18 + lVar20);
              }
              if (bVar9 == 0) {
                pbVar27[(int)uVar36] = pbVar27[(int)uVar36] & ~(byte)(1 << (bVar7 & 7));
              }
              else {
                pbVar27[(int)uVar36] = pbVar27[(int)uVar36] | (byte)(1 << (bVar7 & 7));
              }
              goto LAB_;
            }
            pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
            if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
              *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
              uVar36 = *(uint *)((longlong)&uStackX_20 + lVar20);
              uVar58 = (ulonglong)uVar36;
              *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar36;
              if ((*pbVar55 & 0x10) != 0) {
                uVar36 = uVar36 + 2 + (*(ushort *)(pbVar55 + uVar58) + 7 >> 3);
                uVar58 = (ulonglong)uVar36;
                *(uint *)((longlong)&uStackX_20 + lVar20 + 4) = uVar36;
              }
              if ((*pbVar55 & 0x20) == 0) {
                *(int *)((longlong)&sStackX_10 + lVar20 + 4) = (int)uVar58;
                *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
                *(int *)(&stack0x00000028 + lVar20) = (int)uVar58;
              }
              else {
                puVar45 = (ushort *)(pbVar55 + uVar58);
                uVar11 = *puVar45;
                *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                if (uVar11 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100e9e;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100ea7;
                    lVar25 = func_0x();
                    if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100ec1;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100edd;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100f03;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100f11;
                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),3);
                  uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                  uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                  pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                }
                uVar36 = (int)uVar58 + (uVar11 + 1) * 2;
                *(uint *)(&stack0x00000028 + lVar20) = uVar36;
                if (0x1f9e < uVar36) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100f45;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100f4e;
                    lVar25 = func_0x();
                    if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100f68;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100f84;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100faa;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100fb8;
                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                  uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
                  uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                  uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                  pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                }
                uVar43 = (ulonglong)uVar11;
                uVar11 = puVar45[uVar43];
                *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar11 & 0x7fff;
                if ((uVar11 & 0x7fff) < uVar36) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100ff0;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100ff9;
                    lVar25 = func_0x();
                    if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101013;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10102f;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101055;
                        (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101063;
                  func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                  uVar43 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                  uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                  uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                  pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                }
                puVar60 = puVar45;
                uVar18 = uVar40;
                if ((short)uVar43 != 0) {
                  do {
                    uVar41 = puVar60[1] & 0x7fff;
                    if ((uVar41 < uVar36) ||
                       (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar41)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1010b0;
                      cVar8 = func_0x(0x1ebafb0);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1010b9;
                        lVar25 = func_0x();
                        if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1010d3;
                          cVar8 = func_0x(0x1ebafb0);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1010ef;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101113;
                            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101121;
                      func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
                      uVar43 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                      pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                    }
                    uVar18 = uVar18 + 1;
                    uVar36 = uVar41;
                    puVar60 = puVar60 + 1;
                  } while ((int)uVar18 < (int)uVar43);
                  uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                  uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                  pbVar27 = *(byte **)(&stack0x00000060 + lVar20);
                  puVar48 = *(uint **)(&stack0x00000058 + lVar20);
                }
                while ((short)puVar45[(ulonglong)((int)uVar43 - 1) + 1] < 0) {
                  uVar18 = uVar36;
                  if ((int)uVar43 != 1) {
                    uVar18 = *(ushort *)(pbVar55 + uVar43 * 2 + (uVar58 - 2)) & 0x7fff;
                  }
                  uVar41 = *(ushort *)(pbVar55 + uVar43 * 2 + uVar58) & 0x7fff;
                  if (((uVar18 < uVar36) || (uVar41 < uVar18)) ||
                     (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar41)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1011b6;
                    func_0x(pbVar55,7);
                    uVar43 = (ulonglong)*(ushort *)(&stack0x0000002c + lVar20);
                    uVar36 = *(uint *)(&stack0x00000028 + lVar20);
                    uVar58 = (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20 + 4);
                    pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                  }
                  if ((uVar18 < uVar36) || (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar18))
                  goto LAB_;
                  if (*(ushort *)(pbVar55 + uVar18) == 5) {
                    puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                    *puVar45 = *puVar45 | 2;
                    *(short *)(&stack0x0000002c + lVar20) = (short)uVar43 + -1;
                    uVar58 = (ulonglong)(uVar18 & 0xffff);
                    *(short *)(&stack0x0000003a + lVar20) = (short)uVar18;
                    pbVar44 = pbVar55 + uVar58;
                    uVar11 = *(ushort *)(&stack0x0000003c + lVar20);
                    if ((*(ushort *)(pbVar44 + 2) & 0x4000) == 0) {
                      uVar11 = uVar11 & 0xc7ff;
                    }
                    else {
                      uVar11 = uVar11 ^ (*(ushort *)(pbVar44 + 2) ^ uVar11) & 0x3800;
                    }
                    *(ushort *)(&stack0x0000003c + lVar20) = uVar11;
                    uVar54 = (uVar11 ^ *(ushort *)(pbVar44 + 2)) & 0x7ff ^ uVar11;
                    *(ushort *)(&stack0x0000003c + lVar20) = uVar54;
                    pbVar52 = pbVar55 + (ulonglong)((uVar11 >> 0xb & 7) * 2) + 4 + uVar58 +
                                        ((ulonglong)uVar54 & 0x7ff) * 2;
                    if (pbVar52 < pbVar44) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1012ac;
                      func_0x(pbVar44,0x19);
                      uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                      uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                      pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                    }
                    if (uVar41 - uVar18 <
                        (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar58) -
                        *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)pbVar52) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1012e2;
                      func_0x(pbVar55 + uVar58,0x19);
                      uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                      uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                      pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                    }
                    if (((uVar54 & 0x3800) != 0) &&
                       (puVar45 = (ushort *)(pbVar55 + uVar58 + 4), (uVar54 & 0x3800) != 0)) {
                      do {
                        if ((uVar54 & 0x7ff) < (*puVar45 & 0x7ff)) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101345;
                          func_0x(pbVar55 + uVar58,0x1a);
                          uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
                          uVar58 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                          pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
                        }
                        uVar40 = uVar40 + 1;
                        puVar45 = puVar45 + 1;
                      } while ((int)uVar40 < (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7))
                      ;
                    }
                    break;
                  }
                  if (*(ushort *)(pbVar55 + uVar18) < 0x400) break;
                  puVar60 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
                  *puVar60 = *puVar60 | 1;
                  uVar11 = (short)uVar43 - 1;
                  uVar43 = (ulonglong)uVar11;
                  *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
                  if (uVar11 == 0) break;
                }
              }
              if ((*pbVar55 & 0x40) == 0) {
                *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
              }
              else {
                *(undefined4 *)(&stack0x00000036 + lVar20) =
                     *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4);
                piVar46 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                *piVar46 = *piVar46 + 0xe;
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10138e;
                uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10139d;
                func_0x(uVar23,&stack0x000001c8 + lVar20);
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1013a9;
                iVar15 = func_0x(&stack0x000001c8 + lVar20);
                piVar46 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
                *piVar46 = *piVar46 + iVar15;
                pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
              }
              if ((*(byte **)(&stack0x0000002e + lVar20) != (byte *)0x0) &&
                 (*(byte **)(&stack0x0000002e + lVar20) <
                  pbVar55 + *(uint *)((longlong)&sStackX_10 + lVar20 + 4))) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1013de;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1013e7;
                  lVar25 = func_0x();
                  if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101401;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10141d;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101443;
                      (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101451;
                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),0x12);
                pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
              }
              if (0x3f3b < *(int *)((longlong)&sStackX_10 + lVar20 + 4) - 1U) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101471;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10147a;
                  lVar25 = func_0x();
                  if ((lVar25 != 0) && (*(char *)(lVar25 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x101494;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1014b0;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1014d6;
                      (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1014e4;
                func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),5);
                pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
              }
            }
LAB_:
            uVar40 = *puVar48;
            uVar36 = uVar40 + 1;
            if (*(uint *)((longlong)&uStackX_20 + lVar20) < uVar36) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10150a;
              func_0x((longlong)&sStackX_10 + lVar20 + 2,0,
                              uVar36 - *(uint *)((longlong)&uStackX_20 + lVar20),0);
              pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
              if ((1 << (*pbVar55 & 0xe) & 0x1105U) != 0) {
                *(short *)(pbVar55 + 2) = (short)uVar36;
                pbVar55 = *(byte **)((longlong)&pbStackX_18 + lVar20);
              }
              *(uint *)((longlong)&uStackX_20 + lVar20) = uVar36;
              uVar40 = *puVar48;
            }
            uVar36 = *(uint *)(&stack0x00000048 + lVar20);
            plVar53 = *(longlong **)(&stack0x00000050 + lVar20);
            if (pbVar27 != (byte *)0x0) {
              pbVar55[(int)uVar40] = *pbVar27;
            }
            puVar48 = *(uint **)(&stack0x00000058 + lVar20);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0x1525f20;
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100d95;
            (*_DAT_)(1,0x192c2b0,0x1958c78);
          }
        }
LAB_:
        puVar48 = puVar48 + 0x14;
        *(uint **)(&stack0x00000058 + lVar20) = puVar48;
        uVar36 = uVar36 + 1;
        *(uint *)(&stack0x00000048 + lVar20) = uVar36;
      } while (uVar36 < *(uint *)(&stack0x00000078 + lVar20));
    }
  }
  else {
    piVar46 = *(int **)(lVar24 + 0x70);
    if (*(ushort *)(lVar24 + 0x62) != 0) {
      uVar58 = (ulonglong)*(ushort *)(lVar24 + 0x62);
      do {
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100b8d;
        cVar8 = func_0x(plVar53,piVar46);
        if (cVar8 == '\x03') {
          if ((piVar46[0x10] & 0x4000U) == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100cb5;
            (*_DAT_)(6,0x51,0x10,4);
          }
          uVar12 = *(undefined2 *)(piVar46 + 0xf);
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100ccc;
          func_0x((longlong)&sStackX_10 + lVar20 + 2,piVar46,uVar12,1);
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100ba1;
          func_0x((longlong)&sStackX_10 + lVar20 + 2,piVar46);
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100bb3;
          func_0x(plVar53,piVar46,&stack0x000001c0 + lVar20);
          lVar25 = *(longlong *)(&stack0x000001c0 + lVar20);
          if (((uint)piVar46[0x10] >> 8 & 1) == 0) {
            iVar15 = *piVar46;
            uVar12 = *(undefined2 *)(piVar46 + 0xf);
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100bd7;
            func_0x
                      ((longlong)iVar15 + *(longlong *)((longlong)&pbStackX_18 + lVar20),lVar25,
                       uVar12);
          }
          else {
            iVar15 = 0;
            if (((piVar46[0x10] & 0x8000U) == 0) || ((*(byte *)((longlong)plVar53 + 0x14) & 8) == 0)
               ) {
              if ((*(byte *)(*(longlong *)(piVar46 + 0x12) + 0x2a) & 0x10) == 0) {
                lVar24 = plVar53[3];
              }
              else {
                lVar24 = plVar53[4];
              }
              uVar36 = *(uint *)(*(longlong *)(*(longlong *)(piVar46 + 0x12) + 0x18) + lVar24);
            }
            else {
              uVar36 = *(uint *)(plVar53[7] + (ulonglong)(uint)piVar46[0xe] * 8);
            }
            uVar40 = (uint)*(ushort *)(piVar46 + 0xf);
            if (uVar36 < uVar40) {
              iVar15 = uVar40 - uVar36;
            }
            else if (uVar40 < uVar36) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100c38;
              (*_DAT_)(6,0x5c,0x16,1);
            }
            uVar10 = *(undefined *)(*(longlong *)(piVar46 + 0x12) + 0x24);
            lVar24 = (longlong)*piVar46 + *(longlong *)((longlong)&pbStackX_18 + lVar20);
            if ((lVar25 != 0) && (uVar36 != 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100c5f;
              func_0x(lVar24,lVar25,uVar36);
            }
            if (iVar15 != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x100c74;
              func_0x((ulonglong)uVar36 + lVar24,uVar10,iVar15);
            }
            plVar53 = *(longlong **)(&stack0x00000050 + lVar20);
          }
        }
        piVar46 = piVar46 + 0x14;
        uVar58 = uVar58 - 1;
      } while (uVar58 != 0);
    }
  }
  iVar15 = 0;
  if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
    *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
    *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
         *(undefined4 *)((longlong)&uStackX_20 + lVar20);
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10313d;
    pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
    uVar36 = 0;
    if ((*pbVar27 & 0x10) != 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10314f;
      pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
      if ((*pbVar27 & 0x10) != 0) {
        uVar36 = (uint)*(ushort *)
                        (*(longlong *)((longlong)&pbStackX_18 + lVar20) +
                        (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20));
      }
      *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
           (uVar36 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104634;
    pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
    if ((*pbVar27 & 0x20) == 0) {
      uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
      *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
      *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
      *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
    }
    else {
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104646;
      puVar45 = (ushort *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
      uVar11 = *puVar45;
      *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
      if (uVar11 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104664;
        cVar8 = func_0x(0x1ebafb0);
        if (cVar8 != '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10466d;
          cVar8 = func_0x();
          if (cVar8 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10467d;
            cVar8 = func_0x(0x1ebafb0);
            if (cVar8 == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104699;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1046bf;
              (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
            }
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1046cd;
        func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),3);
        uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
      }
      uVar36 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar11 * 2;
      *(uint *)(&stack0x00000028 + lVar20) = uVar36;
      if (0x1f9e < uVar36) {
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1046f6;
        cVar8 = func_0x(0x1ebafb0);
        if (cVar8 != '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1046ff;
          cVar8 = func_0x();
          if (cVar8 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10470f;
            cVar8 = func_0x(0x1ebafb0);
            if (cVar8 == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10472b;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104751;
              (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
            }
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10475f;
        func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
        uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
      }
      puVar45 = puVar45 + 1;
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104777;
      uVar11 = func_0x(puVar45,(ulonglong)uVar11 - 1);
      *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar11;
      uVar36 = *(uint *)(&stack0x00000028 + lVar20);
      if (uVar11 < uVar36) {
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104790;
        cVar8 = func_0x(0x1ebafb0);
        if (cVar8 != '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104799;
          cVar8 = func_0x();
          if (cVar8 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1047a9;
            cVar8 = func_0x(0x1ebafb0);
            if (cVar8 == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1047c5;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1047eb;
              (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
            }
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1047f9;
        func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
        uVar36 = *(uint *)(&stack0x00000028 + lVar20);
      }
      uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
      iVar42 = iVar15;
      if (uVar11 != 0) {
        do {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10481b;
          uVar11 = func_0x(puVar45,(longlong)iVar42);
          bVar62 = uVar11 < uVar36;
          uVar36 = (uint)uVar11;
          if ((bVar62) ||
             (uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
             uVar40 <= uVar11 && uVar36 != uVar40)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104833;
            cVar8 = func_0x(0x1ebafb0);
            if (cVar8 != '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10483c;
              cVar8 = func_0x();
              if (cVar8 != '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10484c;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 == '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104868;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10488e;
                  (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10489c;
            func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),4);
          }
          iVar42 = iVar42 + 1;
          uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
        } while (iVar42 < (int)(uint)uVar11);
      }
      while( true ) {
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1048bf;
        iVar42 = func_0x(puVar45,uVar11 - 1);
        if (iVar42 == 0) break;
        uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1048d4;
        lVar25 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
        if (uVar11 == 1) {
          uVar36 = *(uint *)(&stack0x00000028 + lVar20);
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1048f0;
          uVar54 = func_0x(lVar25 + 2,(ulonglong)uVar11 - 2);
          uVar36 = (uint)uVar54;
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104900;
        uVar11 = func_0x(lVar25 + 2,(ulonglong)(uint)uVar11 - 1);
        uVar40 = *(uint *)(&stack0x00000028 + lVar20);
        if (((uVar36 < uVar40) || (uVar11 < uVar36)) ||
           (uVar18 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
           uVar18 <= uVar11 && uVar11 != uVar18)) {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104921;
          func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),7);
          uVar40 = *(uint *)(&stack0x00000028 + lVar20);
        }
        if ((uVar36 < uVar40) || (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar36))
        goto LAB_;
        lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
        uVar54 = *(ushort *)(lVar25 + (ulonglong)uVar36);
        if (uVar54 == 5) {
          puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
          *puVar45 = *puVar45 | 2;
          *(short *)(&stack0x0000002c + lVar20) = *(short *)(&stack0x0000002c + lVar20) + -1;
          *(short *)(&stack0x0000003a + lVar20) = (short)uVar36;
          lVar25 = (ulonglong)(uVar36 & 0xffff) + lVar25;
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x10498d;
          iVar42 = func_0x(lVar25);
          if (iVar42 == 0) {
            *(ushort *)(&stack0x0000003c + lVar20) = *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff
            ;
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104999;
            sVar14 = func_0x(lVar25);
            *(ushort *)(&stack0x0000003c + lVar20) =
                 *(ushort *)(&stack0x0000003c + lVar20) ^
                 (sVar14 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x1049ce;
          uVar13 = func_0x(lVar25);
          uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
          uVar13 = (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff ^ uVar54;
          uVar43 = (ulonglong)uVar13;
          *(ushort *)(&stack0x0000003c + lVar20) = uVar13;
          uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
          lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
          uVar58 = (uVar54 >> 0xb & 7) * 2 + uVar47 + ((uVar43 & 0x7ff) + 2) * 2 + lVar25;
          if (uVar58 < uVar47 + lVar25) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104a25;
            func_0x(uVar47 + lVar25,0x19);
            uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
            uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
            lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
          }
          if (uVar11 - uVar36 <
              (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar47) -
              *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)uVar58) {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104a5a;
            func_0x(uVar47 + lVar25,0x19);
            uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
            uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
            lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
          }
          if (((uVar43 & 0x3800) != 0) && ((uVar43 & 0x3800) != 0)) {
            do {
              *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104a8d;
              uVar11 = func_0x(uVar47 + lVar25 + 4,iVar15);
              if ((*(ushort *)(&stack0x0000003c + lVar20) & 0x7ff) < uVar11) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104aab;
                func_0x((ulonglong)*(ushort *)(&stack0x0000003a + lVar20) +
                                *(longlong *)((longlong)&pbStackX_18 + lVar20),0x1a);
              }
              iVar15 = iVar15 + 1;
            } while (iVar15 < (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7));
          }
          break;
        }
        if (uVar54 < 0x400) break;
        puVar60 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
        *puVar60 = *puVar60 | 1;
        uVar11 = *(short *)(&stack0x0000002c + lVar20) - 1;
        *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
        if (uVar11 == 0) break;
      }
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104ad3;
    iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
    if (iVar15 == 0) {
      *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
    }
    else {
      iVar15 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
      *(int *)(&stack0x00000036 + lVar20) = iVar15;
      *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar15 + 0xe;
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104aec;
      uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104afb;
      func_0x(uVar23,&stack0x000001f8 + lVar20);
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104b07;
      iVar15 = func_0x(&stack0x000001f8 + lVar20);
      piVar46 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
      *piVar46 = *piVar46 + iVar15;
    }
    if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
       (*(ulonglong *)(&stack0x0000002e + lVar20) <
        (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4) +
        *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104b35;
      cVar8 = func_0x(0x1ebafb0);
      if (cVar8 != '\0') {
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104b3e;
        cVar8 = func_0x();
        if (cVar8 != '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104b4e;
          cVar8 = func_0x(0x1ebafb0);
          if (cVar8 == '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104b6a;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104b90;
            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104b9e;
      func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),0x12);
    }
    if (0x3f3b < *(int *)((longlong)&sStackX_10 + lVar20 + 4) - 1U) {
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104bb6;
      cVar8 = func_0x(0x1ebafb0);
      if (cVar8 != '\0') {
        *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104bbf;
        cVar8 = func_0x();
        if (cVar8 != '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104bcf;
          cVar8 = func_0x(0x1ebafb0);
          if (cVar8 == '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104beb;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20) = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104c11;
            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104c1f;
      func_0x(*(undefined8 *)((longlong)&pbStackX_18 + lVar20),5);
    }
  }
LAB_:
  if (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < 9) {
    *(undefined8 *)((longlong)&uStack_48 + lVar20) = 0x104c2e;
    cVar8 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
    puVar28 = &stack0xffffffffffffffc0 + lVar20;
    if ((cVar8 != '\0') && (puVar28 = &stack0xffffffffffffffc0 + lVar20, cVar8 != '\f'))
    goto LAB_;
  }
  else {
LAB_:
    puVar28 = &stack0xffffffffffffffc0 + lVar20;
    if (0x3f3c < *(uint *)((longlong)&sStackX_10 + lVar20 + 4)) {
      uVar23 = 0xb8;
      puVar28 = &stack0xffffffffffffffc0 + lVar20;
LAB_:
      *(undefined8 *)(puVar28 + -8) = 0x1075d1;
      (*_DAT_)(6,0x52,0x16,uVar23);
    }
  }
LAB_:
  iVar15 = 0;
  uVar36 = 0;
  if (*(int *)((longlong)&sStackX_10 + lVar20 + 4) == 0) {
    *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
    *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
         *(undefined4 *)((longlong)&uStackX_20 + lVar20);
    *(undefined8 *)(puVar28 + -8) = 0x1075f2;
    pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
    if ((*pbVar27 & 0x10) != 0) {
      *(undefined8 *)(puVar28 + -8) = 0x107600;
      pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
      if ((*pbVar27 & 0x10) != 0) {
        uVar36 = (uint)*(ushort *)
                        (*(longlong *)((longlong)&pbStackX_18 + lVar20) +
                        (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20));
      }
      *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
           (uVar36 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
    }
    *(undefined8 *)(puVar28 + -8) = 0x10762f;
    pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
    if ((*pbVar27 & 0x20) == 0) {
      uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
      *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
      *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
      *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
    }
    else {
      *(undefined8 *)(puVar28 + -8) = 0x107641;
      puVar45 = (ushort *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
      uVar11 = *puVar45;
      *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
      if (uVar11 == 0) {
        *(undefined8 *)(puVar28 + -8) = 0x10765f;
        cVar8 = func_0x(0x1ebafb0);
        if (cVar8 != '\0') {
          *(undefined8 *)(puVar28 + -8) = 0x107668;
          cVar8 = func_0x();
          if (cVar8 != '\0') {
            *(undefined8 *)(puVar28 + -8) = 0x107678;
            cVar8 = func_0x(0x1ebafb0);
            if (cVar8 == '\0') {
              *(undefined8 *)(puVar28 + -8) = 0x107694;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(puVar28 + 0x20) = 0;
              *(undefined8 *)(puVar28 + -8) = 0x1076ba;
              (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
            }
          }
        }
        uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
        *(undefined8 *)(puVar28 + -8) = 0x1076c8;
        func_0x(uVar23,3);
        uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
      }
      uVar36 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar11 * 2;
      *(uint *)(&stack0x00000028 + lVar20) = uVar36;
      if (0x1f9e < uVar36) {
        *(undefined8 *)(puVar28 + -8) = 0x1076f1;
        cVar8 = func_0x(0x1ebafb0);
        if (cVar8 != '\0') {
          *(undefined8 *)(puVar28 + -8) = 0x1076fa;
          cVar8 = func_0x();
          if (cVar8 != '\0') {
            *(undefined8 *)(puVar28 + -8) = 0x10770a;
            cVar8 = func_0x(0x1ebafb0);
            if (cVar8 == '\0') {
              *(undefined8 *)(puVar28 + -8) = 0x107726;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar28 + 0x20) = 0;
              *(undefined8 *)(puVar28 + -8) = 0x10774c;
              (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
            }
          }
        }
        uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
        *(undefined8 *)(puVar28 + -8) = 0x10775a;
        func_0x(uVar23,4);
        uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
      }
      puVar45 = puVar45 + 1;
      *(undefined8 *)(puVar28 + -8) = 0x107772;
      uVar11 = func_0x(puVar45,(ulonglong)uVar11 - 1);
      *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar11;
      uVar36 = *(uint *)(&stack0x00000028 + lVar20);
      if (uVar11 < uVar36) {
        *(undefined8 *)(puVar28 + -8) = 0x10778b;
        cVar8 = func_0x(0x1ebafb0);
        if (cVar8 != '\0') {
          *(undefined8 *)(puVar28 + -8) = 0x107794;
          cVar8 = func_0x();
          if (cVar8 != '\0') {
            *(undefined8 *)(puVar28 + -8) = 0x1077a4;
            cVar8 = func_0x(0x1ebafb0);
            if (cVar8 == '\0') {
              *(undefined8 *)(puVar28 + -8) = 0x1077c0;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar28 + 0x20) = 0;
              *(undefined8 *)(puVar28 + -8) = 0x1077e6;
              (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
            }
          }
        }
        uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
        *(undefined8 *)(puVar28 + -8) = 0x1077f4;
        func_0x(uVar23,4);
        uVar36 = *(uint *)(&stack0x00000028 + lVar20);
      }
      uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
      iVar42 = iVar15;
      if (uVar11 != 0) {
        do {
          *(undefined8 *)(puVar28 + -8) = 0x10781b;
          uVar11 = func_0x(puVar45,(longlong)iVar42);
          bVar62 = uVar11 < uVar36;
          uVar36 = (uint)uVar11;
          if ((bVar62) ||
             (uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
             uVar40 <= uVar11 && uVar36 != uVar40)) {
            *(undefined8 *)(puVar28 + -8) = 0x107833;
            cVar8 = func_0x(0x1ebafb0);
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar28 + -8) = 0x10783c;
              cVar8 = func_0x();
              if (cVar8 != '\0') {
                *(undefined8 *)(puVar28 + -8) = 0x10784c;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 == '\0') {
                  *(undefined8 *)(puVar28 + -8) = 0x107868;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar28 + 0x20) = 0;
                  *(undefined8 *)(puVar28 + -8) = 0x10788e;
                  (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                }
              }
            }
            uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
            *(undefined8 *)(puVar28 + -8) = 0x10789c;
            func_0x(uVar23,4);
          }
          iVar42 = iVar42 + 1;
          uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
        } while (iVar42 < (int)(uint)uVar11);
      }
      while( true ) {
        *(undefined8 *)(puVar28 + -8) = 0x1078bf;
        iVar42 = func_0x(puVar45,uVar11 - 1);
        if (iVar42 == 0) break;
        uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
        *(undefined8 *)(puVar28 + -8) = 0x1078d4;
        lVar25 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
        if (uVar11 == 1) {
          uVar36 = *(uint *)(&stack0x00000028 + lVar20);
        }
        else {
          *(undefined8 *)(puVar28 + -8) = 0x1078f0;
          uVar54 = func_0x(lVar25 + 2,(ulonglong)uVar11 - 2);
          uVar36 = (uint)uVar54;
        }
        *(undefined8 *)(puVar28 + -8) = 0x107900;
        uVar11 = func_0x(lVar25 + 2,(ulonglong)(uint)uVar11 - 1);
        uVar40 = *(uint *)(&stack0x00000028 + lVar20);
        if (((uVar36 < uVar40) || (uVar11 < uVar36)) ||
           (uVar18 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
           uVar18 <= uVar11 && uVar11 != uVar18)) {
          uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
          *(undefined8 *)(puVar28 + -8) = 0x107921;
          func_0x(uVar23,7);
          uVar40 = *(uint *)(&stack0x00000028 + lVar20);
        }
        if ((uVar36 < uVar40) || (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < uVar36))
        goto LAB_;
        lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
        uVar54 = *(ushort *)(lVar25 + (ulonglong)uVar36);
        if (uVar54 == 5) {
          puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
          *puVar45 = *puVar45 | 2;
          *(short *)(&stack0x0000002c + lVar20) = *(short *)(&stack0x0000002c + lVar20) + -1;
          *(short *)(&stack0x0000003a + lVar20) = (short)uVar36;
          lVar25 = (ulonglong)(uVar36 & 0xffff) + lVar25;
          *(undefined8 *)(puVar28 + -8) = 0x10798d;
          iVar42 = func_0x(lVar25);
          if (iVar42 == 0) {
            *(ushort *)(&stack0x0000003c + lVar20) = *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff
            ;
          }
          else {
            *(undefined8 *)(puVar28 + -8) = 0x107999;
            sVar14 = func_0x(lVar25);
            *(ushort *)(&stack0x0000003c + lVar20) =
                 *(ushort *)(&stack0x0000003c + lVar20) ^
                 (sVar14 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
          }
          *(undefined8 *)(puVar28 + -8) = 0x1079ce;
          uVar13 = func_0x(lVar25);
          uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
          uVar13 = (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff ^ uVar54;
          uVar43 = (ulonglong)uVar13;
          *(ushort *)(&stack0x0000003c + lVar20) = uVar13;
          uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
          lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
          uVar58 = (uVar54 >> 0xb & 7) * 2 + uVar47 + ((uVar43 & 0x7ff) + 2) * 2 + lVar25;
          if (uVar58 < lVar25 + uVar47) {
            *(undefined8 *)(puVar28 + -8) = 0x107a25;
            func_0x(lVar25 + uVar47,0x19);
            uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
            uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
            lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
          }
          if (uVar11 - uVar36 <
              (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar47) -
              *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)uVar58) {
            *(undefined8 *)(puVar28 + -8) = 0x107a5a;
            func_0x(uVar47 + lVar25,0x19);
            uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
            uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
            lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
          }
          if (((uVar43 & 0x3800) != 0) && (iVar42 = iVar15, (uVar43 & 0x3800) != 0)) {
            do {
              *(undefined8 *)(puVar28 + -8) = 0x107a8d;
              uVar11 = func_0x(uVar47 + lVar25 + 4,iVar42);
              if ((*(ushort *)(&stack0x0000003c + lVar20) & 0x7ff) < uVar11) {
                uVar11 = *(ushort *)(&stack0x0000003a + lVar20);
                lVar24 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar28 + -8) = 0x107aab;
                func_0x((ulonglong)uVar11 + lVar24,0x1a);
              }
              iVar42 = iVar42 + 1;
            } while (iVar42 < (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7));
          }
          break;
        }
        if (uVar54 < 0x400) break;
        puVar60 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
        *puVar60 = *puVar60 | 1;
        uVar11 = *(short *)(&stack0x0000002c + lVar20) - 1;
        *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
        if (uVar11 == 0) break;
      }
    }
    *(undefined8 *)(puVar28 + -8) = 0x107ad3;
    iVar42 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
    if (iVar42 == 0) {
      *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
    }
    else {
      iVar42 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
      *(int *)(&stack0x00000036 + lVar20) = iVar42;
      *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar42 + 0xe;
      *(undefined8 *)(puVar28 + -8) = 0x107aec;
      uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
      *(undefined8 *)(puVar28 + -8) = 0x107afb;
      func_0x(uVar23,&stack0x00000220 + lVar20);
      *(undefined8 *)(puVar28 + -8) = 0x107b07;
      iVar42 = func_0x(&stack0x00000220 + lVar20);
      piVar46 = (int *)((longlong)&sStackX_10 + lVar20 + 4);
      *piVar46 = *piVar46 + iVar42;
    }
    if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
       (*(ulonglong *)(&stack0x0000002e + lVar20) <
        (ulonglong)*(uint *)((longlong)&sStackX_10 + lVar20 + 4) +
        *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
      *(undefined8 *)(puVar28 + -8) = 0x107b35;
      cVar8 = func_0x(0x1ebafb0);
      if (cVar8 != '\0') {
        *(undefined8 *)(puVar28 + -8) = 0x107b3e;
        cVar8 = func_0x();
        if (cVar8 != '\0') {
          *(undefined8 *)(puVar28 + -8) = 0x107b4e;
          cVar8 = func_0x(0x1ebafb0);
          if (cVar8 == '\0') {
            *(undefined8 *)(puVar28 + -8) = 0x107b6a;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(puVar28 + 0x20) = 0;
            *(undefined8 *)(puVar28 + -8) = 0x107b90;
            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
          }
        }
      }
      uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
      *(undefined8 *)(puVar28 + -8) = 0x107b9e;
      func_0x(uVar23,0x12);
    }
    if (0x3f3b < *(int *)((longlong)&sStackX_10 + lVar20 + 4) - 1U) {
      *(undefined8 *)(puVar28 + -8) = 0x107bb6;
      cVar8 = func_0x(0x1ebafb0);
      if (cVar8 != '\0') {
        *(undefined8 *)(puVar28 + -8) = 0x107bbf;
        cVar8 = func_0x();
        if (cVar8 != '\0') {
          *(undefined8 *)(puVar28 + -8) = 0x107bcf;
          cVar8 = func_0x(0x1ebafb0);
          if (cVar8 == '\0') {
            *(undefined8 *)(puVar28 + -8) = 0x107beb;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(puVar28 + 0x20) = 0;
            *(undefined8 *)(puVar28 + -8) = 0x107c11;
            (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
          }
        }
      }
      uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
      *(undefined8 *)(puVar28 + -8) = 0x107c1f;
      func_0x(uVar23,5);
    }
  }
LAB_:
  if (*(uint *)((longlong)&sStackX_10 + lVar20 + 4) < 9) {
    *(undefined8 *)(puVar28 + -8) = 0x107c2e;
    cVar8 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
    if ((cVar8 != '\0') && (cVar8 != '\f')) goto LAB_;
    uVar36 = 9;
  }
  else {
LAB_:
    uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
  }
  *(undefined8 *)(puVar28 + -8) = 0x107c53;
  iVar42 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
  uVar40 = *(uint *)(&stack0x00000036 + lVar20);
  if (iVar42 == 0) {
    uVar40 = uVar36;
  }
  if (0x1f7c < uVar40) {
    uVar23 = *(undefined8 *)(&stack0x00000090 + lVar20);
    *(undefined8 *)(puVar28 + -8) = 0x107c77;
    func_0x(uVar23,(longlong)&sStackX_10 + lVar20 + 2);
    uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
    uVar40 = 0;
    if (uVar36 == 0) {
      *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
      *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
           *(undefined4 *)((longlong)&uStackX_20 + lVar20);
      *(undefined8 *)(puVar28 + -8) = 0x107c96;
      pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
      if ((*pbVar27 & 0x10) != 0) {
        *(undefined8 *)(puVar28 + -8) = 0x107ca4;
        pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
        uVar36 = uVar40;
        if ((*pbVar27 & 0x10) != 0) {
          uVar36 = (uint)*(ushort *)
                          (*(longlong *)((longlong)&pbStackX_18 + lVar20) +
                          (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20));
        }
        *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
             (uVar36 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
      }
      *(undefined8 *)(puVar28 + -8) = 0x107cd3;
      pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
      if ((*pbVar27 & 0x20) == 0) {
        uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
        *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
        *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
        *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
      }
      else {
        *(undefined8 *)(puVar28 + -8) = 0x107ce5;
        puVar45 = (ushort *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
        uVar11 = *puVar45;
        *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
        if (uVar11 == 0) {
          *(undefined8 *)(puVar28 + -8) = 0x107d03;
          cVar8 = func_0x(0x1ebafb0);
          if (cVar8 != '\0') {
            *(undefined8 *)(puVar28 + -8) = 0x107d0c;
            cVar8 = func_0x();
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar28 + -8) = 0x107d1c;
              cVar8 = func_0x(0x1ebafb0);
              if (cVar8 == '\0') {
                *(undefined8 *)(puVar28 + -8) = 0x107d38;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(puVar28 + 0x20) = 0;
                *(undefined8 *)(puVar28 + -8) = 0x107d5e;
                (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
              }
            }
          }
          uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
          *(undefined8 *)(puVar28 + -8) = 0x107d6c;
          func_0x(uVar23,3);
          uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
        }
        uVar36 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar11 * 2;
        *(uint *)(&stack0x00000028 + lVar20) = uVar36;
        if (0x1f9e < uVar36) {
          *(undefined8 *)(puVar28 + -8) = 0x107d95;
          cVar8 = func_0x(0x1ebafb0);
          if (cVar8 != '\0') {
            *(undefined8 *)(puVar28 + -8) = 0x107d9e;
            cVar8 = func_0x();
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar28 + -8) = 0x107dae;
              cVar8 = func_0x(0x1ebafb0);
              if (cVar8 == '\0') {
                *(undefined8 *)(puVar28 + -8) = 0x107dca;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar28 + 0x20) = 0;
                *(undefined8 *)(puVar28 + -8) = 0x107df0;
                (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
              }
            }
          }
          uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
          *(undefined8 *)(puVar28 + -8) = 0x107dfe;
          func_0x(uVar23,4);
          uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
        }
        puVar45 = puVar45 + 1;
        *(undefined8 *)(puVar28 + -8) = 0x107e16;
        uVar11 = func_0x(puVar45,(ulonglong)uVar11 - 1);
        *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar11;
        uVar36 = *(uint *)(&stack0x00000028 + lVar20);
        if (uVar11 < uVar36) {
          *(undefined8 *)(puVar28 + -8) = 0x107e2f;
          cVar8 = func_0x(0x1ebafb0);
          if (cVar8 != '\0') {
            *(undefined8 *)(puVar28 + -8) = 0x107e38;
            cVar8 = func_0x();
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar28 + -8) = 0x107e48;
              cVar8 = func_0x(0x1ebafb0);
              if (cVar8 == '\0') {
                *(undefined8 *)(puVar28 + -8) = 0x107e64;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar28 + 0x20) = 0;
                *(undefined8 *)(puVar28 + -8) = 0x107e8a;
                (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
              }
            }
          }
          uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
          *(undefined8 *)(puVar28 + -8) = 0x107e98;
          func_0x(uVar23,4);
          uVar36 = *(uint *)(&stack0x00000028 + lVar20);
        }
        uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
        iVar42 = iVar15;
        if (uVar11 != 0) {
          do {
            *(undefined8 *)(puVar28 + -8) = 0x107ebb;
            uVar11 = func_0x(puVar45,(longlong)iVar42);
            bVar62 = uVar11 < uVar36;
            uVar36 = (uint)uVar11;
            if ((bVar62) ||
               (uVar18 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
               uVar18 <= uVar11 && uVar36 != uVar18)) {
              *(undefined8 *)(puVar28 + -8) = 0x107ed3;
              cVar8 = func_0x(0x1ebafb0);
              if (cVar8 != '\0') {
                *(undefined8 *)(puVar28 + -8) = 0x107edc;
                cVar8 = func_0x();
                if (cVar8 != '\0') {
                  *(undefined8 *)(puVar28 + -8) = 0x107eec;
                  cVar8 = func_0x(0x1ebafb0);
                  if (cVar8 == '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x107f08;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar28 + 0x20) = 0;
                    *(undefined8 *)(puVar28 + -8) = 0x107f2e;
                    (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                  }
                }
              }
              uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
              *(undefined8 *)(puVar28 + -8) = 0x107f3c;
              func_0x(uVar23,4);
            }
            iVar42 = iVar42 + 1;
            uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
          } while (iVar42 < (int)(uint)uVar11);
        }
        while( true ) {
          *(undefined8 *)(puVar28 + -8) = 0x107f5f;
          iVar42 = func_0x(puVar45,uVar11 - 1);
          if (iVar42 == 0) break;
          uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
          *(undefined8 *)(puVar28 + -8) = 0x107f74;
          lVar25 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
          if (uVar11 == 1) {
            uVar18 = *(uint *)(&stack0x00000028 + lVar20);
          }
          else {
            *(undefined8 *)(puVar28 + -8) = 0x107f90;
            uVar54 = func_0x(lVar25 + 2,(ulonglong)uVar11 - 2);
            uVar18 = (uint)uVar54;
          }
          *(undefined8 *)(puVar28 + -8) = 0x107fa0;
          uVar11 = func_0x(lVar25 + 2,(ulonglong)(uint)uVar11 - 1);
          uVar41 = *(uint *)(&stack0x00000028 + lVar20);
          if (((uVar18 < uVar41) || (uVar11 < uVar18)) ||
             (uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
             uVar36 <= uVar11 && uVar11 != uVar36)) {
            uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
            *(undefined8 *)(puVar28 + -8) = 0x107fc3;
            func_0x(uVar23,7);
            uVar41 = *(uint *)(&stack0x00000028 + lVar20);
            uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
          }
          if ((uVar18 < uVar41) || (uVar36 < uVar18)) goto LAB_;
          lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
          uVar54 = *(ushort *)(lVar25 + (ulonglong)uVar18);
          if (uVar54 == 5) {
            puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
            *puVar45 = *puVar45 | 2;
            *(short *)(&stack0x0000002c + lVar20) = *(short *)(&stack0x0000002c + lVar20) + -1;
            *(short *)(&stack0x0000003a + lVar20) = (short)uVar18;
            lVar25 = (ulonglong)(uVar18 & 0xffff) + lVar25;
            *(undefined8 *)(puVar28 + -8) = 0x108031;
            iVar42 = func_0x(lVar25);
            if (iVar42 == 0) {
              *(ushort *)(&stack0x0000003c + lVar20) =
                   *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
            }
            else {
              *(undefined8 *)(puVar28 + -8) = 0x10803d;
              sVar14 = func_0x(lVar25);
              *(ushort *)(&stack0x0000003c + lVar20) =
                   *(ushort *)(&stack0x0000003c + lVar20) ^
                   (sVar14 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
            }
            *(undefined8 *)(puVar28 + -8) = 0x108072;
            uVar13 = func_0x(lVar25);
            uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
            uVar13 = (uVar13 ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x7ff ^ uVar54;
            uVar43 = (ulonglong)uVar13;
            *(ushort *)(&stack0x0000003c + lVar20) = uVar13;
            uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
            lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
            uVar58 = (uVar54 >> 0xb & 7) * 2 + uVar47 + ((uVar43 & 0x7ff) + 2) * 2 + lVar25;
            if (uVar58 < lVar25 + uVar47) {
              *(undefined8 *)(puVar28 + -8) = 0x1080ca;
              func_0x(lVar25 + uVar47,0x19);
              uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
              uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
              lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
            }
            if (uVar11 - uVar18 <
                (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar47) -
                *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)uVar58) {
              *(undefined8 *)(puVar28 + -8) = 0x108100;
              func_0x(uVar47 + lVar25,0x19);
              uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
              uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
              lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
            }
            if (((uVar43 & 0x3800) != 0) && (iVar42 = iVar15, (uVar43 & 0x3800) != 0)) {
              do {
                *(undefined8 *)(puVar28 + -8) = 0x10813b;
                uVar11 = func_0x(uVar47 + lVar25 + 4,iVar42);
                if ((*(ushort *)(&stack0x0000003c + lVar20) & 0x7ff) < uVar11) {
                  uVar11 = *(ushort *)(&stack0x0000003a + lVar20);
                  lVar24 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                  *(undefined8 *)(puVar28 + -8) = 0x10815a;
                  func_0x((ulonglong)uVar11 + lVar24,0x1a);
                }
                iVar42 = iVar42 + 1;
              } while (iVar42 < (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7));
            }
            break;
          }
          if (uVar54 < 0x400) break;
          puVar60 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
          *puVar60 = *puVar60 | 1;
          uVar11 = *(short *)(&stack0x0000002c + lVar20) - 1;
          *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
          if (uVar11 == 0) break;
        }
      }
      *(undefined8 *)(puVar28 + -8) = 0x108182;
      iVar42 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
      if (iVar42 == 0) {
        *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
        uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
      }
      else {
        iVar42 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
        *(int *)(&stack0x00000036 + lVar20) = iVar42;
        *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar42 + 0xe;
        *(undefined8 *)(puVar28 + -8) = 0x10819b;
        uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
        *(undefined8 *)(puVar28 + -8) = 0x1081aa;
        func_0x(uVar23,&stack0x00000228 + lVar20);
        *(undefined8 *)(puVar28 + -8) = 0x1081b6;
        iVar42 = func_0x(&stack0x00000228 + lVar20);
        uVar36 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar42;
        *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar36;
      }
      if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
         (*(ulonglong *)(&stack0x0000002e + lVar20) <
          (ulonglong)uVar36 + *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
        *(undefined8 *)(puVar28 + -8) = 0x1081eb;
        cVar8 = func_0x(0x1ebafb0);
        if (cVar8 != '\0') {
          *(undefined8 *)(puVar28 + -8) = 0x1081f4;
          cVar8 = func_0x();
          if (cVar8 != '\0') {
            *(undefined8 *)(puVar28 + -8) = 0x108204;
            cVar8 = func_0x(0x1ebafb0);
            if (cVar8 == '\0') {
              *(undefined8 *)(puVar28 + -8) = 0x108220;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(puVar28 + 0x20) = 0;
              *(undefined8 *)(puVar28 + -8) = 0x108246;
              (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
            }
          }
        }
        uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
        *(undefined8 *)(puVar28 + -8) = 0x108254;
        func_0x(uVar23,0x12);
        uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
      }
      if (0x3f3b < uVar36 - 1) {
        *(undefined8 *)(puVar28 + -8) = 0x10826d;
        cVar8 = func_0x(0x1ebafb0);
        if (cVar8 != '\0') {
          *(undefined8 *)(puVar28 + -8) = 0x108276;
          cVar8 = func_0x();
          if (cVar8 != '\0') {
            *(undefined8 *)(puVar28 + -8) = 0x108286;
            cVar8 = func_0x(0x1ebafb0);
            if (cVar8 == '\0') {
              *(undefined8 *)(puVar28 + -8) = 0x1082a2;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(puVar28 + 0x20) = 0;
              *(undefined8 *)(puVar28 + -8) = 0x1082c8;
              (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
            }
          }
        }
        uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
        *(undefined8 *)(puVar28 + -8) = 0x1082d6;
        func_0x(uVar23,5);
        uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
      }
    }
LAB_:
    if (uVar36 < 9) {
      *(undefined8 *)(puVar28 + -8) = 0x1082e7;
      cVar8 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
      if ((cVar8 == '\0') || (uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4), cVar8 == '\f')
         ) {
        uVar36 = 9;
      }
    }
    *(undefined8 *)(puVar28 + -8) = 0x1082fe;
    iVar42 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
    uVar18 = *(uint *)(&stack0x00000036 + lVar20);
    if (iVar42 == 0) {
      uVar18 = uVar36;
    }
    if (0x1f7c < uVar18) {
      uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
      if (uVar36 == 0) {
        *(undefined2 *)((longlong)&sStackX_10 + lVar20 + 2) = 0;
        *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4) =
             *(undefined4 *)((longlong)&uStackX_20 + lVar20);
        *(undefined8 *)(puVar28 + -8) = 0x108331;
        pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
        if ((*pbVar27 & 0x10) != 0) {
          *(undefined8 *)(puVar28 + -8) = 0x10833f;
          pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
          if ((*pbVar27 & 0x10) != 0) {
            uVar40 = (uint)*(ushort *)
                            (*(longlong *)((longlong)&pbStackX_18 + lVar20) +
                            (ulonglong)*(uint *)((longlong)&uStackX_20 + lVar20));
          }
          *(uint *)((longlong)&uStackX_20 + lVar20 + 4) =
               (uVar40 + 7 >> 3) + *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2;
        }
        *(undefined8 *)(puVar28 + -8) = 0x10836e;
        pbVar27 = (byte *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
        if ((*pbVar27 & 0x20) == 0) {
          uVar19 = *(undefined4 *)((longlong)&uStackX_20 + lVar20 + 4);
          *(undefined4 *)((longlong)&sStackX_10 + lVar20 + 4) = uVar19;
          *(undefined2 *)(&stack0x0000002c + lVar20) = 0;
          *(undefined4 *)(&stack0x00000028 + lVar20) = uVar19;
        }
        else {
          *(undefined8 *)(puVar28 + -8) = 0x108380;
          puVar45 = (ushort *)func_0x((longlong)&sStackX_10 + lVar20 + 2);
          uVar11 = *puVar45;
          *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
          if (uVar11 == 0) {
            *(undefined8 *)(puVar28 + -8) = 0x10839e;
            cVar8 = func_0x(0x1ebafb0);
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar28 + -8) = 0x1083a7;
              cVar8 = func_0x();
              if (cVar8 != '\0') {
                *(undefined8 *)(puVar28 + -8) = 0x1083b7;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 == '\0') {
                  *(undefined8 *)(puVar28 + -8) = 0x1083d3;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar28 + 0x20) = 0;
                  *(undefined8 *)(puVar28 + -8) = 0x1083f9;
                  (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x80f);
                }
              }
            }
            uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
            *(undefined8 *)(puVar28 + -8) = 0x108407;
            func_0x(uVar23,3);
            uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
          }
          uVar36 = *(int *)((longlong)&uStackX_20 + lVar20 + 4) + 2 + (uint)uVar11 * 2;
          *(uint *)(&stack0x00000028 + lVar20) = uVar36;
          if (0x1f9e < uVar36) {
            *(undefined8 *)(puVar28 + -8) = 0x108430;
            cVar8 = func_0x(0x1ebafb0);
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar28 + -8) = 0x108439;
              cVar8 = func_0x();
              if (cVar8 != '\0') {
                *(undefined8 *)(puVar28 + -8) = 0x108449;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 == '\0') {
                  *(undefined8 *)(puVar28 + -8) = 0x108465;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar28 + 0x20) = 0;
                  *(undefined8 *)(puVar28 + -8) = 0x10848b;
                  (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x816);
                }
              }
            }
            uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
            *(undefined8 *)(puVar28 + -8) = 0x108499;
            func_0x(uVar23,4);
            uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
          }
          puVar45 = puVar45 + 1;
          *(undefined8 *)(puVar28 + -8) = 0x1084b1;
          uVar11 = func_0x(puVar45,(ulonglong)uVar11 - 1);
          *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = (uint)uVar11;
          uVar36 = *(uint *)(&stack0x00000028 + lVar20);
          if (uVar11 < uVar36) {
            *(undefined8 *)(puVar28 + -8) = 0x1084ca;
            cVar8 = func_0x(0x1ebafb0);
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar28 + -8) = 0x1084d3;
              cVar8 = func_0x();
              if (cVar8 != '\0') {
                *(undefined8 *)(puVar28 + -8) = 0x1084e3;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 == '\0') {
                  *(undefined8 *)(puVar28 + -8) = 0x1084ff;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar28 + 0x20) = 0;
                  *(undefined8 *)(puVar28 + -8) = 0x108525;
                  (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x81d);
                }
              }
            }
            uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
            *(undefined8 *)(puVar28 + -8) = 0x108533;
            func_0x(uVar23,4);
            uVar36 = *(uint *)(&stack0x00000028 + lVar20);
          }
          uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
          iVar42 = iVar15;
          if (uVar11 != 0) {
            do {
              *(undefined8 *)(puVar28 + -8) = 0x10855b;
              uVar11 = func_0x(puVar45,(longlong)iVar42);
              bVar62 = uVar11 < uVar36;
              uVar36 = (uint)uVar11;
              if ((bVar62) ||
                 (uVar40 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
                 uVar40 <= uVar11 && uVar36 != uVar40)) {
                *(undefined8 *)(puVar28 + -8) = 0x108573;
                cVar8 = func_0x(0x1ebafb0);
                if (cVar8 != '\0') {
                  *(undefined8 *)(puVar28 + -8) = 0x10857c;
                  cVar8 = func_0x();
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar28 + -8) = 0x10858c;
                    cVar8 = func_0x(0x1ebafb0);
                    if (cVar8 == '\0') {
                      *(undefined8 *)(puVar28 + -8) = 0x1085a8;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar28 + 0x20) = 0;
                      *(undefined8 *)(puVar28 + -8) = 0x1085ce;
                      (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x82a);
                    }
                  }
                }
                uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
                *(undefined8 *)(puVar28 + -8) = 0x1085dc;
                func_0x(uVar23,4);
              }
              iVar42 = iVar42 + 1;
              uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
            } while (iVar42 < (int)(uint)uVar11);
          }
          while( true ) {
            *(undefined8 *)(puVar28 + -8) = 0x1085ff;
            iVar42 = func_0x(puVar45,uVar11 - 1);
            if (iVar42 == 0) break;
            uVar11 = *(ushort *)(&stack0x0000002c + lVar20);
            *(undefined8 *)(puVar28 + -8) = 0x108614;
            lVar25 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
            if (uVar11 == 1) {
              uVar40 = *(uint *)(&stack0x00000028 + lVar20);
            }
            else {
              *(undefined8 *)(puVar28 + -8) = 0x108630;
              uVar54 = func_0x(lVar25 + 2,(ulonglong)uVar11 - 2);
              uVar40 = (uint)uVar54;
            }
            *(undefined8 *)(puVar28 + -8) = 0x108640;
            uVar11 = func_0x(lVar25 + 2,(ulonglong)(uint)uVar11 - 1);
            uVar18 = *(uint *)(&stack0x00000028 + lVar20);
            if (((uVar40 < uVar18) || (uVar11 < uVar40)) ||
               (uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4),
               uVar36 <= uVar11 && uVar11 != uVar36)) {
              uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
              *(undefined8 *)(puVar28 + -8) = 0x108663;
              func_0x(uVar23,7);
              uVar18 = *(uint *)(&stack0x00000028 + lVar20);
              uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
            }
            if ((uVar40 < uVar18) || (uVar36 < uVar40)) goto LAB_;
            lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
            uVar54 = *(ushort *)(lVar25 + (ulonglong)uVar40);
            if (uVar54 == 5) {
              puVar45 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
              *puVar45 = *puVar45 | 2;
              *(short *)(&stack0x0000002c + lVar20) = *(short *)(&stack0x0000002c + lVar20) + -1;
              *(short *)(&stack0x0000003a + lVar20) = (short)uVar40;
              lVar25 = (ulonglong)(uVar40 & 0xffff) + lVar25;
              *(undefined8 *)(puVar28 + -8) = 0x1086d1;
              iVar42 = func_0x(lVar25);
              if (iVar42 == 0) {
                *(ushort *)(&stack0x0000003c + lVar20) =
                     *(ushort *)(&stack0x0000003c + lVar20) & 0xc7ff;
              }
              else {
                *(undefined8 *)(puVar28 + -8) = 0x1086dd;
                sVar14 = func_0x(lVar25);
                *(ushort *)(&stack0x0000003c + lVar20) =
                     *(ushort *)(&stack0x0000003c + lVar20) ^
                     (sVar14 << 0xb ^ *(ushort *)(&stack0x0000003c + lVar20)) & 0x3800;
              }
              *(undefined8 *)(puVar28 + -8) = 0x108712;
              uVar13 = func_0x(lVar25);
              uVar54 = *(ushort *)(&stack0x0000003c + lVar20);
              uVar13 = (*(ushort *)(&stack0x0000003c + lVar20) ^ uVar13) & 0x7ff ^ uVar54;
              uVar43 = (ulonglong)uVar13;
              *(ushort *)(&stack0x0000003c + lVar20) = uVar13;
              uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
              lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
              uVar58 = (uVar54 >> 0xb & 7) * 2 + uVar47 + ((uVar43 & 0x7ff) + 2) * 2 + lVar25;
              if (uVar58 < lVar25 + uVar47) {
                *(undefined8 *)(puVar28 + -8) = 0x10876a;
                func_0x(lVar25 + uVar47,0x19);
                uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
              }
              if (uVar11 - uVar40 <
                  (((*(uint *)(&stack0x0000003c + lVar20) & 0x7ff) * 2 - (int)uVar47) -
                  *(int *)((longlong)&pbStackX_18 + lVar20)) + (int)uVar58) {
                *(undefined8 *)(puVar28 + -8) = 0x10879f;
                func_0x(uVar47 + lVar25,0x19);
                uVar43 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar20);
                uVar47 = (ulonglong)*(ushort *)(&stack0x0000003a + lVar20);
                lVar25 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
              }
              if (((uVar43 & 0x3800) != 0) && ((uVar43 & 0x3800) != 0)) {
                do {
                  *(undefined8 *)(puVar28 + -8) = 0x1087db;
                  uVar11 = func_0x(uVar47 + lVar25 + 4,iVar15);
                  if ((*(ushort *)(&stack0x0000003c + lVar20) & 0x7ff) < uVar11) {
                    uVar11 = *(ushort *)(&stack0x0000003a + lVar20);
                    lVar24 = *(longlong *)((longlong)&pbStackX_18 + lVar20);
                    *(undefined8 *)(puVar28 + -8) = 0x1087f9;
                    func_0x((ulonglong)uVar11 + lVar24,0x1a);
                  }
                  iVar15 = iVar15 + 1;
                } while (iVar15 < (int)(*(uint *)(&stack0x0000003c + lVar20) >> 0xb & 7));
              }
              break;
            }
            if (uVar54 < 0x400) break;
            puVar60 = (ushort *)((longlong)&sStackX_10 + lVar20 + 2);
            *puVar60 = *puVar60 | 1;
            uVar11 = *(short *)(&stack0x0000002c + lVar20) - 1;
            *(ushort *)(&stack0x0000002c + lVar20) = uVar11;
            if (uVar11 == 0) break;
          }
        }
        *(undefined8 *)(puVar28 + -8) = 0x108821;
        iVar15 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
        if (iVar15 == 0) {
          *(undefined4 *)(&stack0x00000036 + lVar20) = 0;
          uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
        }
        else {
          iVar15 = *(int *)((longlong)&sStackX_10 + lVar20 + 4);
          *(int *)(&stack0x00000036 + lVar20) = iVar15;
          *(int *)((longlong)&sStackX_10 + lVar20 + 4) = iVar15 + 0xe;
          *(undefined8 *)(puVar28 + -8) = 0x10883a;
          uVar23 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
          *(undefined8 *)(puVar28 + -8) = 0x108849;
          func_0x(uVar23,&stack0x00000230 + lVar20);
          *(undefined8 *)(puVar28 + -8) = 0x108855;
          iVar15 = func_0x(&stack0x00000230 + lVar20);
          uVar36 = *(int *)((longlong)&sStackX_10 + lVar20 + 4) + iVar15;
          *(uint *)((longlong)&sStackX_10 + lVar20 + 4) = uVar36;
        }
        if ((*(ulonglong *)(&stack0x0000002e + lVar20) != 0) &&
           (*(ulonglong *)(&stack0x0000002e + lVar20) <
            (ulonglong)uVar36 + *(longlong *)((longlong)&pbStackX_18 + lVar20))) {
          *(undefined8 *)(puVar28 + -8) = 0x10888a;
          cVar8 = func_0x(0x1ebafb0);
          if (cVar8 != '\0') {
            *(undefined8 *)(puVar28 + -8) = 0x108893;
            cVar8 = func_0x();
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar28 + -8) = 0x1088a3;
              cVar8 = func_0x(0x1ebafb0);
              if (cVar8 == '\0') {
                *(undefined8 *)(puVar28 + -8) = 0x1088bf;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar28 + 0x20) = 0;
                *(undefined8 *)(puVar28 + -8) = 0x1088e5;
                (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x886);
              }
            }
          }
          uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
          *(undefined8 *)(puVar28 + -8) = 0x1088f3;
          func_0x(uVar23,0x12);
          uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
        }
        if (0x3f3b < uVar36 - 1) {
          *(undefined8 *)(puVar28 + -8) = 0x10890c;
          cVar8 = func_0x(0x1ebafb0);
          if (cVar8 != '\0') {
            *(undefined8 *)(puVar28 + -8) = 0x108915;
            cVar8 = func_0x();
            if (cVar8 != '\0') {
              *(undefined8 *)(puVar28 + -8) = 0x108925;
              cVar8 = func_0x(0x1ebafb0);
              if (cVar8 == '\0') {
                *(undefined8 *)(puVar28 + -8) = 0x108941;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar28 + 0x20) = 0;
                *(undefined8 *)(puVar28 + -8) = 0x108967;
                (*_DAT_)(1,0x17aa9bc,0x18caaa8,0x88b);
              }
            }
          }
          uVar23 = *(undefined8 *)((longlong)&pbStackX_18 + lVar20);
          *(undefined8 *)(puVar28 + -8) = 0x108975;
          func_0x(uVar23,5);
          uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
        }
      }
LAB_:
      if (uVar36 < 9) {
        *(undefined8 *)(puVar28 + -8) = 0x108986;
        cVar8 = func_0x((longlong)&sStackX_10 + lVar20 + 2);
        uVar36 = 9;
        if ((cVar8 != '\0') && (cVar8 != '\f')) {
          uVar36 = *(uint *)((longlong)&sStackX_10 + lVar20 + 4);
        }
      }
      *(undefined8 *)(puVar28 + -8) = 0x1089a7;
      func_0x(7,uVar36,0x1f7c);
    }
  }
LAB_:
  param_3 = *(longlong **)(&stack0x00000050 + lVar20);
  puVar50 = puVar28;
LAB_:
  *(undefined8 *)(puVar50 + -8) = 0x10ceea;
  func_0x(&stack0x00000278 + lVar20);
  lVar25 = *(longlong *)(&stack0x00000090 + lVar20);
  puVar51 = puVar50;
LAB_:
  uVar36 = 0;
  *(undefined8 *)(puVar51 + -8) = 0x10cfe3;
  iVar15 = func_0x(lVar25);
  if (iVar15 == 0) {
    *(undefined8 *)(puVar51 + -8) = 0x10cff3;
    uVar23 = func_0x(param_3);
    if (lVar25 != 0) {
      *(undefined8 *)(puVar51 + -8) = 0x10d007;
      lVar24 = func_0x(uVar23);
      *(undefined8 *)(puVar51 + -8) = 0x10d015;
      sVar14 = func_0x(uVar23);
      if (sVar14 != 0) {
        do {
          *(undefined8 *)(puVar51 + -8) = 0x10d02a;
          iVar15 = func_0x(lVar24);
          if (iVar15 == 0) {
            *(undefined8 *)(puVar51 + -8) = 0x10d041;
            pplVar31 = (longlong **)func_0x(lVar24,&stack0x00000368 + lVar20);
            uVar32 = *(undefined8 *)(lVar25 + 8);
            *(undefined8 *)(puVar51 + -8) = 0x10d04e;
            cVar8 = func_0x(uVar32);
            if (cVar8 != '\0') {
              if (*(int *)(*(longlong *)(lVar25 + 8) + 0x480) == 0) {
                *(undefined8 *)(puVar51 + -8) = 0x10d06c;
                func_0x(lVar25);
              }
              plVar53 = pplVar31[1];
              plVar5 = *pplVar31;
              if (plVar5[1] == 0) {
LAB_:
                plVar53 = (longlong *)(*plVar5 + (longlong)plVar53 * 8);
                LOCK();
                *plVar53 = *plVar53 + 1;
                UNLOCK();
              }
              else {
                *(undefined8 *)(puVar51 + -8) = 0x10d07f;
                uVar40 = func_0x();
                *(undefined8 *)(puVar51 + -8) = 0x10d08e;
                uVar18 = func_0x(_DAT_);
                if (uVar18 <= uVar40) goto LAB_;
                lVar25 = *(longlong *)(plVar5[1] + (ulonglong)uVar40 * 8);
                *(longlong *)(lVar25 + (longlong)plVar53 * 8) =
                     *(longlong *)(lVar25 + (longlong)plVar53 * 8) + 1;
              }
              plVar53 = *(longlong **)(&stack0x00000280 + lVar20);
              if (plVar53 == (longlong *)0x0) {
                lVar25 = *(longlong *)(&stack0x00000090 + lVar20);
              }
              else {
                *(undefined8 *)(puVar51 + -8) = 0x10d0d4;
                uVar32 = func_0x(plVar53);
                *(undefined8 *)(puVar51 + -8) = 0x10d0dc;
                cVar8 = func_0x(uVar32);
                lVar25 = *(longlong *)(&stack0x00000090 + lVar20);
                if (cVar8 != '\0') {
                  *(undefined **)(puVar51 + 0x20) = &stack0x000002c0 + lVar20;
                  uVar19 = *(undefined4 *)(pplVar31 + 1);
                  uVar32 = *(undefined8 *)(lVar25 + 8);
                  *(undefined8 *)(puVar51 + -8) = 0x10d112;
                  cVar8 = func_0x
                                    (uVar32,uVar19,&stack0x00000290 + lVar20,
                                     &stack0x00000288 + lVar20);
                  if (cVar8 != '\0') {
                    lVar37 = *plVar53;
                    *(undefined8 *)(puVar51 + -8) = 0x10d125;
                    uVar32 = func_0x(lVar25);
                    pcVar4 = *(code **)(lVar37 + 0x2b8);
                    *(undefined8 *)(puVar51 + -8) = 0x10d131;
                    (*pcVar4)(plVar53,uVar32);
                    *(undefined8 *)(puVar51 + -8) = 0x10d13d;
                    func_0x(&stack0x00000380 + lVar20);
                    uVar19 = *(undefined4 *)(pplVar31 + 1);
                    uVar32 = *(undefined8 *)(*(longlong *)(lVar25 + 8) + 0x160);
                    *(undefined8 *)(puVar51 + -8) = 0x10d151;
                    uVar32 = func_0x(uVar32,uVar19);
                    *(undefined8 *)(puVar51 + -8) = 0x10d159;
                    uVar19 = func_0x(uVar32);
                    *(undefined8 *)(puVar51 + -8) = 0x10d163;
                    uVar33 = func_0x(lVar25);
                    *(undefined8 *)(puVar51 + 0x20) = *(undefined8 *)(&stack0x00000288 + lVar20);
                    uVar32 = *(undefined8 *)(&stack0x00000290 + lVar20);
                    *(undefined8 *)(puVar51 + -8) = 0x10d188;
                    func_0x(&stack0x00000380 + lVar20,uVar33,uVar19,uVar32);
                    *(undefined8 *)(puVar51 + -8) = 0x10d197;
                    func_0x(&stack0x00000380 + lVar20,plVar53);
                  }
                }
              }
            }
          }
          uVar36 = uVar36 + 1;
          lVar24 = lVar24 + 0x50;
          *(undefined8 *)(puVar51 + -8) = 0x10d1af;
          uVar11 = func_0x(uVar23);
        } while (uVar36 < uVar11);
      }
    }
  }
  *(undefined8 *)(puVar51 + -8) = 0x10d1c4;
  iVar15 = func_0x(psVar2);
  if (iVar15 != 0) {
    *(undefined8 *)(puVar51 + -8) = 0x10d1d4;
    func_0x(&stack0x00000160 + lVar20);
    *(undefined8 *)(puVar51 + -8) = 0x10d1e0;
    func_0x(&stack0x00000160 + lVar20);
    *(undefined8 *)(puVar51 + -8) = 0x10d1f0;
    func_0x(psVar2,&stack0x00000160 + lVar20);
    *(undefined8 *)(puVar51 + -8) = 0x10d1f8;
    cVar8 = func_0x(lVar25);
    if (cVar8 != '\0') {
      *(undefined8 *)(puVar51 + -8) = 0x10d20d;
      uVar23 = func_0x(&stack0x000002a0 + lVar20,0,0);
      *(undefined8 *)(puVar51 + -8) = 0x10d219;
      func_0x(psVar2,uVar23);
    }
  }
  lVar24 = *(longlong *)(&stack0x00000090 + lVar20);
  param_2 = *(undefined8 **)(&stack0x00000100 + lVar20);
  goto LAB_;
code_r0x001068c6:
  uVar36 = uVar40;
  if (uVar40 == 0) goto LAB_;
  goto LAB_;
}

