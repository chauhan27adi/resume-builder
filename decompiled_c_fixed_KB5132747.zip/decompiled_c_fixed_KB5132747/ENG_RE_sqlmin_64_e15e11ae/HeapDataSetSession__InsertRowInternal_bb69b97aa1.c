
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong **param_2,undefined8 param_3)

{
  byte *pbVar1;
  short *psVar2;
  byte bVar3;
  code *pcVar4;
  short *psVar5;
  ushort *puVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  char cVar9;
  char cVar10;
  undefined uVar11;
  short sVar12;
  ushort uVar13;
  ushort uVar14;
  undefined2 uVar15;
  int iVar16;
  undefined4 uVar17;
  longlong lVar18;
  longlong lVar19;
  undefined4 *puVar20;
  longlong *plVar21;
  longlong lVar22;
  undefined8 *puVar23;
  longlong lVar24;
  undefined8 *puVar25;
  undefined8 uVar26;
  int *piVar27;
  undefined8 uVar28;
  undefined4 *puVar29;
  byte bVar30;
  uint uVar31;
  undefined8 *puVar32;
  byte bVar33;
  uint uVar34;
  int iVar35;
  byte *pbVar36;
  ulonglong uVar37;
  uint *puVar38;
  longlong *plVar39;
  uint uVar40;
  uint uVar41;
  undefined8 unaff_RBX;
  ulonglong uVar42;
  longlong *plVar43;
  undefined *puVar44;
  undefined *puVar45;
  ulonglong uVar46;
  ulonglong uVar47;
  uint uVar48;
  ushort *puVar49;
  ulonglong uVar50;
  longlong lVar51;
  undefined2 *puVar52;
  longlong *plVar53;
  undefined8 *puVar54;
  ushort *puVar55;
  short *psVar56;
  byte *pbVar57;
  longlong unaff_GS_OFFSET;
  bool bVar58;
  longlong alStackX_8 [4];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar18 = func_0x();
  lVar18 = -lVar18;
  puVar45 = &stack0xffffffffffffffc8 + lVar18;
  puVar44 = &stack0xffffffffffffffc8 + lVar18;
  psVar2 = (short *)(&stack0x00000038 + lVar18);
  *(undefined8 *)(&stack0x00000200 + lVar18) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002a00 + lVar18) = unaff_RBX;
  *(ulonglong *)(&stack0x00002998 + lVar18) = _DAT_ ^ (ulonglong)psVar2;
  *(undefined8 *)(&stack0x000001c8 + lVar18) = param_3;
  *(longlong ***)(&stack0x00000070 + lVar18) = param_2;
  *(longlong *)(&stack0x00000098 + lVar18) = param_1;
  *(longlong *)(&stack0x00000128 + lVar18) = param_1;
  *psVar2 = -1;
  plVar21 = (longlong *)0x0;
  *(undefined8 *)(&stack0x00000040 + lVar18) = 0;
  *(undefined4 *)(&stack0x0000003c + lVar18) = 0;
  *(undefined8 *)(&stack0x00000056 + lVar18) = 0;
  *(undefined8 *)(&stack0x00000060 + lVar18) = 0;
  *(undefined8 *)(&stack0x00000048 + lVar18) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100091;
  func_0x(&stack0x000009f8 + lVar18,0,0x1f9e);
  *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1000a9;
  func_0x(&stack0x000001d0 + lVar18,param_1,1);
  puVar54 = (undefined8 *)**(longlong **)(param_1 + 0x2e0);
  *(undefined8 **)(&stack0x00000100 + lVar18) = puVar54;
  plVar43 = *param_2;
  if ((*(int *)(puVar54 + 5) == *(int *)(plVar43 + 1)) &&
     (*plVar43 == (ulonglong)*(uint6 *)((longlong)puVar54 + 0x14) * 0x10000)) {
    pcVar4 = *(code **)*puVar54;
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1000e5;
    sVar12 = (*pcVar4)(puVar54);
    if (*(short *)((longlong)plVar43 + 0xc) != sVar12) goto LAB_;
    if (plVar43[0x15] != 0) {
      LOCK();
      *(undefined4 *)(&stack0xffffffffffffffc8 + lVar18) =
           *(undefined4 *)(&stack0xffffffffffffffc8 + lVar18);
      UNLOCK();
    }
  }
  else {
LAB_:
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100106;
    func_0x(plVar43,puVar54);
  }
  bVar58 = false;
  if ((*(int *)(puVar54[1] + 0x100) != 0) && (1 < *(int *)(puVar54[1] + 0x100) - 3U)) {
    bVar58 = true;
  }
  plVar43 = *param_2;
  *(undefined4 *)(&stack0x000000c8 + lVar18) = 0x10;
  if ((*(byte *)(plVar43 + 7) & 0x20) == 0) {
    if (bVar58) {
      *(undefined8 *)(&stack0x00000080 + lVar18) = 0;
      plVar39 = plVar21;
      if ((*(byte *)((longlong)param_2 + 0x14) & 0x10) != 0) {
        plVar39 = plVar43;
      }
      uVar40 = -*(int *)(plVar39 + 2);
      *(uint *)(&stack0x0000007c + lVar18) = uVar40;
      *(undefined2 *)(&stack0xfffffffffffffff0 + lVar18) = 1;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar18) = *(undefined4 *)(plVar39 + 3);
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1020d9;
      func_0x(psVar2,&stack0x000009f8 + lVar18,0x1f9e);
      if (uVar40 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x102103;
        lVar19 = func_0x();
        lVar19 = -lVar19;
        puVar45 = &stack0xffffffffffffffc8 + lVar19 + lVar18;
        plVar21 = (longlong *)(&stack0x00000038 + lVar19 + lVar18);
        *(longlong **)(&stack0x00000080 + lVar18) = plVar21;
        *(undefined8 *)((longlong)&uStack_40 + lVar19 + lVar18) = 0x102119;
        func_0x(plVar21,0);
      }
      uVar13 = *(ushort *)((longlong)*param_2 + 0x62);
      *(undefined8 *)(&stack0x000000c0 + lVar18) = 0;
      plVar43 = param_2[1];
      if (uVar13 != 0) {
        *(ulonglong *)(&stack0x000000a8 + lVar18) = (ulonglong)uVar13;
        lVar19 = *(longlong *)(&stack0x00000080 + lVar18);
        do {
          uVar40 = *(uint *)plVar43;
          *(undefined8 *)(puVar45 + -8) = 0x102153;
          func_0x(param_2,plVar43,&stack0x00000079 + lVar18);
          if ((&stack0x00000079)[lVar18] == '\x03') {
            if (((*(ushort *)(plVar43[9] + 0xc) & 0x400) == 0) &&
               ((*(uint *)(plVar43 + 8) & 0x4000) == 0)) {
              *(undefined8 *)(puVar45 + -8) = 0x10243d;
              (*_DAT_)(6,0x51,0x10);
            }
            *(undefined8 *)(puVar45 + -8) = 0x10244f;
            func_0x(psVar2,plVar43,0);
            if ((int)uVar40 < 0) {
              puVar38 = (uint *)((longlong)(int)~uVar40 * 0x20 + 0xc + lVar19);
              *puVar38 = *puVar38 | 2;
            }
          }
          else {
            if (*(short *)((longlong)plVar43 + 4) != 0) {
              if (*psVar2 == 0) {
                *(undefined8 *)(puVar45 + -8) = 0x102177;
                func_0x();
              }
              else {
                *(undefined8 *)(puVar45 + -8) = 0x10217e;
                func_0x(&stack0x0000003a + lVar18,plVar43);
              }
            }
            *(undefined8 *)(puVar45 + -8) = 0x102190;
            func_0x(param_2,plVar43,&stack0x000000c0 + lVar18);
            cVar9 = *(char *)(plVar43 + 8);
            uVar41 = 0;
            if ((cVar9 == '\x01') || (cVar9 == '\x02')) {
              lVar24 = *(longlong *)(&stack0x000000c0 + lVar18);
              if ((*(uint *)(plVar43 + 8) >> 8 & 1) == 0) {
                uVar40 = *(uint *)plVar43;
                lVar22 = *(longlong *)(&stack0x00000040 + lVar18);
                uVar15 = *(undefined2 *)((longlong)plVar43 + 0x3c);
                *(undefined8 *)(puVar45 + -8) = 0x102308;
                func_0x((int)uVar40 + lVar22,lVar24,uVar15);
                param_2 = *(longlong ***)(&stack0x00000070 + lVar18);
              }
              else {
                iVar16 = 0;
                lVar22 = *(longlong *)(&stack0x00000070 + lVar18);
                if (((*(uint *)(plVar43 + 8) & 0x8000) == 0) ||
                   ((*(byte *)(lVar22 + 0x14) & 8) == 0)) {
                  if ((*(byte *)(plVar43[9] + 0x2a) & 0x10) == 0) {
                    lVar22 = *(longlong *)(lVar22 + 0x18);
                  }
                  else {
                    lVar22 = *(longlong *)(lVar22 + 0x20);
                  }
                  uVar40 = *(uint *)(*(longlong *)(plVar43[9] + 0x18) + lVar22);
                }
                else {
                  uVar40 = *(uint *)(*(longlong *)(lVar22 + 0x38) +
                                    (ulonglong)*(uint *)(plVar43 + 7) * 8);
                }
                uVar41 = (uint)*(ushort *)((longlong)plVar43 + 0x3c);
                if (uVar40 < uVar41) {
                  iVar16 = uVar41 - uVar40;
                }
                else if (uVar41 < uVar40) {
                  *(undefined8 *)(puVar45 + -8) = 0x102371;
                  (*_DAT_)(6,0x5c,0x16);
                }
                uVar11 = *(undefined *)(plVar43[9] + 0x24);
                uVar41 = *(uint *)plVar43;
                lVar22 = *(longlong *)(&stack0x00000040 + lVar18);
                if ((lVar24 != 0) && (uVar40 != 0)) {
                  *(undefined8 *)(puVar45 + -8) = 0x102398;
                  func_0x((int)uVar41 + lVar22,lVar24,uVar40);
                }
                if (iVar16 != 0) {
                  *(undefined8 *)(puVar45 + -8) = 0x1023ad;
                  func_0x((ulonglong)uVar40 + (int)uVar41 + lVar22,uVar11,iVar16);
                }
                param_2 = *(longlong ***)(&stack0x00000070 + lVar18);
              }
            }
            else if ((cVar9 == '\x03') || (cVar9 == '\x04')) {
              uVar48 = *(uint *)(plVar43 + 8);
              piVar27 = *(int **)(&stack0x000000c0 + lVar18);
              if (((uVar48 >> 0xd & 1) == 0) || (*piVar27 != 0)) {
                if (((uVar48 & 0x8000) == 0) || ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0)) {
                  lVar24 = plVar43[9];
                  if ((uVar48 >> 8 & 1) == 0) {
                    uVar41 = (uint)*(ushort *)(lVar24 + 2);
                  }
                  else if ((*(byte *)(lVar24 + 0x2a) & 0x10) == 0) {
                    uVar41 = *(uint *)(*(longlong *)(lVar24 + 0x18) + (longlong)param_2[3]);
                  }
                  else {
                    uVar41 = *(uint *)(*(longlong *)(lVar24 + 0x18) + (longlong)param_2[4]);
                  }
                }
                else {
                  uVar41 = *(uint *)(param_2[7] + *(uint *)(plVar43 + 7));
                }
              }
              if (*(ushort *)((longlong)plVar43 + 0x3c) < uVar41) {
                *(undefined8 *)(puVar45 + -8) = 0x1022b4;
                (*_DAT_)(6,0x52,0x16);
                piVar27 = *(int **)(&stack0x000000c0 + lVar18);
              }
              *(undefined4 *)(puVar45 + 0x28) = 0;
              *(longlong **)(puVar45 + 0x20) = plVar43;
              *(undefined8 *)(puVar45 + -8) = 0x1022df;
              func_0x((longlong)(int)~uVar40 * 0x20 + lVar19,piVar27,uVar41);
            }
            else if (cVar9 == '\b') {
              if (*psVar2 == 0) {
                uVar26 = *(undefined8 *)(&stack0x000000c0 + lVar18);
                *(undefined8 *)(puVar45 + -8) = 0x102208;
                func_0x(psVar2,plVar43,uVar26);
              }
              else {
                *(undefined4 *)(puVar45 + 0x28) = 0;
                *(longlong **)(puVar45 + 0x20) = plVar43;
                uVar26 = *(undefined8 *)(&stack0x000000c0 + lVar18);
                *(undefined8 *)(puVar45 + -8) = 0x102235;
                func_0x((longlong)(int)~uVar40 * 0x20 + lVar19,uVar26,1);
              }
            }
            else {
              *(undefined8 *)(puVar45 + 0x20) = 0x152b830;
              *(undefined8 *)(puVar45 + -8) = 0x1021e6;
              (*_DAT_)(1,0x1931bc0,0x195e588);
            }
          }
          plVar43 = plVar43 + 10;
          plVar21 = (longlong *)(&stack0x000000a8 + lVar18);
          *plVar21 = *plVar21 + -1;
        } while (*plVar21 != 0);
        uVar40 = *(uint *)(&stack0x0000007c + lVar18);
        plVar21 = *(longlong **)(&stack0x00000080 + lVar18);
      }
      puVar49 = (ushort *)0x0;
      if (uVar40 != 0) {
        if (*psVar2 == 0) {
LAB_:
          uVar47 = (ulonglong)uVar40;
          uVar41 = uVar40 - 1;
          if (*(int *)(plVar21 + (ulonglong)uVar41 * 4 + 1) == 0) goto code_r0x00102404;
          *(ushort *)(&stack0x00000054 + lVar18) = (ushort)uVar40;
          iVar16 = *(int *)(&stack0x0000004c + lVar18) + 2 + uVar40 * 2;
          *(int *)(&stack0x00000050 + lVar18) = iVar16;
          *(int *)(&stack0x0000003c + lVar18) = iVar16;
          **(byte **)(&stack0x00000040 + lVar18) = **(byte **)(&stack0x00000040 + lVar18) | 0x20;
          uVar41 = *(uint *)(&stack0x0000003c + lVar18);
          if (uVar41 < 0x1f7d) {
            puVar49 = (ushort *)
                      ((ulonglong)*(uint *)(&stack0x0000004c + lVar18) +
                      *(longlong *)(&stack0x00000040 + lVar18));
            *puVar49 = (ushort)uVar40;
            uVar41 = *(uint *)(&stack0x0000003c + lVar18);
          }
          if (uVar40 != 0) {
            puVar38 = (uint *)((longlong)plVar21 + 0xc);
            do {
              puVar49 = puVar49 + 1;
              uVar50 = (ulonglong)uVar41;
              lVar19 = *(longlong *)(&stack0x00000040 + lVar18);
              uVar40 = puVar38[-1];
              uVar41 = uVar41 + uVar40;
              *(uint *)(&stack0x0000003c + lVar18) = uVar41;
              if (uVar41 < 0x1f7d) {
                *puVar49 = (ushort)((*puVar38 & 1) << 0xf) | (ushort)uVar41 & 0x7fff;
                uVar26 = *(undefined8 *)(puVar38 + -3);
                *(undefined8 *)(puVar45 + -8) = 0x1024f8;
                func_0x(uVar50 + lVar19,uVar40,uVar26);
                uVar41 = *(uint *)(&stack0x0000003c + lVar18);
              }
              puVar38 = puVar38 + 8;
              uVar47 = uVar47 - 1;
            } while (uVar47 != 0);
          }
          *(uint *)(&stack0x000000a4 + lVar18) = uVar41;
          goto LAB_;
        }
        *(undefined **)(puVar45 + 0x28) = &stack0x000000a4 + lVar18;
        *(longlong **)(puVar45 + 0x20) = plVar21;
        *(undefined8 *)(puVar45 + -8) = 0x102534;
        func_0x(&stack0x0000003a + lVar18,0x1f9e,0x1f7c);
      }
    }
    else {
      *psVar2 = 0;
      *(undefined8 *)(&stack0x000000b0 + lVar18) = 0;
      plVar39 = plVar21;
      if ((*(byte *)((longlong)param_2 + 0x14) & 0x10) != 0) {
        plVar39 = plVar43;
      }
      uVar40 = -*(int *)(plVar39 + 2);
      *(uint *)(&stack0x000000a0 + lVar18) = uVar40;
      (&stack0xfffffffffffffff0)[lVar18] = 0;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar18) = *(undefined4 *)(plVar39 + 3);
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x100197;
      func_0x(&stack0x0000003a + lVar18,&stack0x000009f8 + lVar18);
      puVar45 = &stack0xffffffffffffffc8 + lVar18;
      if (uVar40 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1001bf;
        lVar19 = func_0x();
        lVar19 = -lVar19;
        puVar45 = &stack0xffffffffffffffc8 + lVar19 + lVar18;
        plVar21 = (longlong *)(&stack0x00000038 + lVar19 + lVar18);
        *(longlong **)(&stack0x000000b0 + lVar18) = plVar21;
        *(undefined8 *)((longlong)&uStack_40 + lVar19 + lVar18) = 0x1001d5;
        func_0x(plVar21,0);
      }
      uVar13 = *(ushort *)((longlong)*param_2 + 0x62);
      *(uint *)(&stack0x0000007c + lVar18) = (uint)uVar13;
      *(undefined8 *)(&stack0x000000d0 + lVar18) = 0;
      *(undefined4 *)(&stack0x00000088 + lVar18) = 0;
      plVar43 = param_2[1];
      *(longlong **)(&stack0x00000090 + lVar18) = plVar43;
      if (uVar13 != 0) {
        do {
          uVar47 = 0;
          uVar40 = *(uint *)plVar43;
          *(undefined8 *)(puVar45 + -8) = 0x100213;
          func_0x(param_2,plVar43,&stack0x00000078 + lVar18);
          if ((&stack0x00000078)[lVar18] == '\x03') {
            if (((*(ushort *)(plVar43[9] + 0xc) & 0x400) == 0) &&
               ((*(uint *)(plVar43 + 8) & 0x4000) == 0)) {
              *(undefined8 *)(puVar45 + -8) = 0x101fcf;
              (*_DAT_)(6,0x51,0x10);
            }
            *(undefined8 *)(puVar45 + -8) = 0x101fe1;
            func_0x(&stack0x0000003a + lVar18,plVar43,0);
            if ((int)uVar40 < 0) {
              puVar38 = (uint *)((longlong)(int)~uVar40 * 0x20 + 0xc + (longlong)plVar21);
              *puVar38 = *puVar38 | 2;
            }
            goto LAB_;
          }
          if (*(short *)((longlong)plVar43 + 4) != 0) {
            *(undefined8 *)(puVar45 + -8) = 0x100231;
            func_0x(&stack0x0000003a + lVar18,plVar43);
          }
          *(undefined8 *)(puVar45 + -8) = 0x100243;
          func_0x(param_2,plVar43,&stack0x000000d0 + lVar18);
          cVar9 = *(char *)(plVar43 + 8);
          uVar41 = 0;
          if ((cVar9 == '\x01') || (cVar9 == '\x02')) {
            lVar19 = *(longlong *)(&stack0x000000d0 + lVar18);
            if ((*(uint *)(plVar43 + 8) >> 8 & 1) == 0) {
              uVar40 = *(uint *)plVar43;
              lVar24 = *(longlong *)(&stack0x00000040 + lVar18);
              uVar15 = *(undefined2 *)((longlong)plVar43 + 0x3c);
              *(undefined8 *)(puVar45 + -8) = 0x101ef2;
              func_0x((int)uVar40 + lVar24,lVar19,uVar15);
              goto LAB_;
            }
            if (((*(uint *)(plVar43 + 8) & 0x8000) == 0) ||
               ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0)) {
              if ((*(byte *)(plVar43[9] + 0x2a) & 0x10) == 0) {
                plVar21 = param_2[3];
              }
              else {
                plVar21 = param_2[4];
              }
              uVar40 = *(uint *)(*(longlong *)(plVar43[9] + 0x18) + (longlong)plVar21);
            }
            else {
              uVar40 = *(uint *)(param_2[7] + *(uint *)(plVar43 + 7));
            }
            uVar48 = (uint)*(ushort *)((longlong)plVar43 + 0x3c);
            if (uVar40 < uVar48) {
              uVar41 = uVar48 - uVar40;
            }
            else if (uVar48 < uVar40) {
              *(undefined8 *)(puVar45 + -8) = 0x101f5a;
              (*_DAT_)(6,0x5c,0x16);
            }
            uVar11 = *(undefined *)(plVar43[9] + 0x24);
            uVar48 = *(uint *)plVar43;
            lVar24 = *(longlong *)(&stack0x00000040 + lVar18);
            if ((lVar19 != 0) && (uVar40 != 0)) {
              *(undefined8 *)(puVar45 + -8) = 0x101f82;
              func_0x((int)uVar48 + lVar24,lVar19,uVar40);
            }
            if (uVar41 != 0) {
              *(undefined8 *)(puVar45 + -8) = 0x101f9a;
              func_0x((ulonglong)uVar40 + (int)uVar48 + lVar24,uVar11,uVar41);
            }
LAB_:
            param_2 = *(longlong ***)(&stack0x00000070 + lVar18);
          }
          else if ((cVar9 == '\x03') || (cVar9 == '\x04')) {
            uVar48 = *(uint *)(plVar43 + 8);
            piVar27 = *(int **)(&stack0x000000d0 + lVar18);
            if (((uVar48 >> 0xd & 1) == 0) || (*piVar27 != 0)) {
              if (((uVar48 & 0x8000) == 0) || ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0)) {
                lVar19 = plVar43[9];
                if ((uVar48 >> 8 & 1) == 0) {
                  uVar41 = (uint)*(ushort *)(lVar19 + 2);
                }
                else if ((*(byte *)(lVar19 + 0x2a) & 0x10) == 0) {
                  uVar41 = *(uint *)(*(longlong *)(lVar19 + 0x18) + (longlong)param_2[3]);
                }
                else {
                  uVar41 = *(uint *)(*(longlong *)(lVar19 + 0x18) + (longlong)param_2[4]);
                }
              }
              else {
                uVar41 = *(uint *)(param_2[7] + *(uint *)(plVar43 + 7));
              }
            }
            if (*(ushort *)((longlong)plVar43 + 0x3c) < uVar41) {
              *(undefined8 *)(puVar45 + -8) = 0x101e9c;
              (*_DAT_)(6,0x52,0x16);
              piVar27 = *(int **)(&stack0x000000d0 + lVar18);
            }
            *(undefined4 *)(puVar45 + 0x28) = 0;
            *(longlong **)(puVar45 + 0x20) = plVar43;
            *(undefined8 *)(puVar45 + -8) = 0x101ec7;
            func_0x(plVar21 + (longlong)(int)~uVar40 * 4,piVar27,uVar41);
          }
          else if (cVar9 == '\b') {
            *(char **)(&stack0x00000080 + lVar18) = *(char **)(&stack0x000000d0 + lVar18);
            uVar40 = *(uint *)plVar43;
            if ((int)uVar40 < 0) {
              if ((uVar40 & 0xc0000000) != 0x80000000) {
                if (*(int *)(&stack0x0000003c + lVar18) == 0) {
                  *(undefined2 *)(&stack0x0000003a + lVar18) = 0;
                  uVar40 = *(uint *)(&stack0x00000048 + lVar18);
                  uVar50 = (ulonglong)uVar40;
                  *(uint *)(&stack0x0000004c + lVar18) = uVar40;
                  pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                  if ((*pbVar36 & 0x10) != 0) {
                    uVar40 = uVar40 + 2 + (*(ushort *)(pbVar36 + uVar50) + 7 >> 3);
                    uVar50 = (ulonglong)uVar40;
                    *(uint *)(&stack0x0000004c + lVar18) = uVar40;
                  }
                  if ((*pbVar36 & 0x20) == 0) {
                    *(int *)(&stack0x0000003c + lVar18) = (int)uVar50;
                    *(undefined2 *)(&stack0x00000054 + lVar18) = 0;
                    *(int *)(&stack0x00000050 + lVar18) = (int)uVar50;
                    uVar42 = uVar50;
                  }
                  else {
                    puVar49 = (ushort *)(pbVar36 + uVar50);
                    *(ushort **)(&stack0x000000a8 + lVar18) = puVar49;
                    uVar13 = *puVar49;
                    *(ushort *)(&stack0x00000054 + lVar18) = uVar13;
                    if (uVar13 == 0) {
                      *(undefined8 *)(puVar45 + -8) = 0x100ac6;
                      cVar9 = func_0x(0x1ec08c0);
                      if (cVar9 != '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x100acf;
                        lVar19 = func_0x();
                        if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar45 + -8) = 0x100ae9;
                          cVar9 = func_0x(0x1ec08c0);
                          if (cVar9 == '\0') {
                            *(undefined8 *)(puVar45 + -8) = 0x100b05;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(puVar45 + 0x20) = 0;
                            *(undefined8 *)(puVar45 + -8) = 0x100b29;
                            (*_DAT_)(1,0x17b02cc,0x18d03b8,0x80f);
                          }
                        }
                      }
                      uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                      *(undefined8 *)(puVar45 + -8) = 0x100b37;
                      func_0x(uVar26,3);
                      uVar13 = *(ushort *)(&stack0x00000054 + lVar18);
                      uVar50 = (ulonglong)*(uint *)(&stack0x0000004c + lVar18);
                      pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                    }
                    uVar40 = (int)uVar50 + (uVar13 + 1) * 2;
                    *(uint *)(&stack0x00000050 + lVar18) = uVar40;
                    if (0x1f9e < uVar40) {
                      *(undefined8 *)(puVar45 + -8) = 0x100b6a;
                      cVar9 = func_0x(0x1ec08c0);
                      if (cVar9 != '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x100b73;
                        lVar19 = func_0x();
                        if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar45 + -8) = 0x100b8d;
                          cVar9 = func_0x(0x1ec08c0);
                          if (cVar9 == '\0') {
                            *(undefined8 *)(puVar45 + -8) = 0x100ba9;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar45 + 0x20) = 0;
                            *(undefined8 *)(puVar45 + -8) = 0x100bcd;
                            (*_DAT_)(1,0x17b02cc,0x18d03b8,0x816);
                          }
                        }
                      }
                      uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                      *(undefined8 *)(puVar45 + -8) = 0x100bdb;
                      func_0x(uVar26,4);
                      uVar13 = *(ushort *)(&stack0x00000054 + lVar18);
                      uVar40 = *(uint *)(&stack0x00000050 + lVar18);
                      uVar50 = (ulonglong)*(uint *)(&stack0x0000004c + lVar18);
                      pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                    }
                    uVar37 = (ulonglong)uVar13;
                    uVar41 = puVar49[uVar37] & 0x7fff;
                    *(uint *)(&stack0x0000003c + lVar18) = uVar41;
                    if (uVar41 < uVar40) {
                      *(undefined8 *)(puVar45 + -8) = 0x100c13;
                      cVar9 = func_0x(0x1ec08c0);
                      if (cVar9 != '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x100c1c;
                        lVar19 = func_0x();
                        if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar45 + -8) = 0x100c36;
                          cVar9 = func_0x(0x1ec08c0);
                          if (cVar9 == '\0') {
                            *(undefined8 *)(puVar45 + -8) = 0x100c52;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar45 + 0x20) = 0;
                            *(undefined8 *)(puVar45 + -8) = 0x100c76;
                            (*_DAT_)(1,0x17b02cc,0x18d03b8,0x81d);
                          }
                        }
                      }
                      uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                      *(undefined8 *)(puVar45 + -8) = 0x100c84;
                      func_0x(uVar26,4);
                      uVar37 = (ulonglong)*(ushort *)(&stack0x00000054 + lVar18);
                      uVar40 = *(uint *)(&stack0x00000050 + lVar18);
                      uVar50 = (ulonglong)*(uint *)(&stack0x0000004c + lVar18);
                      pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                      uVar41 = *(uint *)(&stack0x0000003c + lVar18);
                    }
                    uVar42 = (ulonglong)uVar41;
                    uVar46 = uVar47;
                    if ((short)uVar37 != 0) {
                      do {
                        puVar49 = puVar49 + 1;
                        uVar41 = *puVar49 & 0x7fff;
                        if ((uVar41 < uVar40) || ((uint)uVar42 < uVar41)) {
                          *(undefined8 *)(puVar45 + -8) = 0x100cd4;
                          cVar9 = func_0x(0x1ec08c0);
                          if (cVar9 != '\0') {
                            *(undefined8 *)(puVar45 + -8) = 0x100cdd;
                            lVar19 = func_0x();
                            if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar45 + -8) = 0x100cf7;
                              cVar9 = func_0x(0x1ec08c0);
                              if (cVar9 == '\0') {
                                *(undefined8 *)(puVar45 + -8) = 0x100d13;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar45 + 0x20) = 0;
                                *(undefined8 *)(puVar45 + -8) = 0x100d37;
                                (*_DAT_)(1,0x17b02cc,0x18d03b8,0x82a);
                              }
                            }
                          }
                          uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                          *(undefined8 *)(puVar45 + -8) = 0x100d45;
                          func_0x(uVar26,4);
                          uVar37 = (ulonglong)*(ushort *)(&stack0x00000054 + lVar18);
                          pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                          uVar42 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                        }
                        uVar48 = (int)uVar46 + 1;
                        uVar46 = (ulonglong)uVar48;
                        uVar40 = uVar41;
                      } while ((int)uVar48 < (int)uVar37);
                      uVar40 = *(uint *)(&stack0x00000050 + lVar18);
                      uVar50 = (ulonglong)*(uint *)(&stack0x0000004c + lVar18);
                      puVar49 = *(ushort **)(&stack0x000000a8 + lVar18);
                      plVar43 = *(longlong **)(&stack0x00000090 + lVar18);
                    }
                    while( true ) {
                      sVar12 = (short)uVar37;
                      if (-1 < (short)puVar49[(ulonglong)((int)uVar37 - 1) + 1]) break;
                      uVar41 = uVar40;
                      if ((int)uVar37 != 1) {
                        uVar41 = *(ushort *)(pbVar36 + uVar37 * 2 + (uVar50 - 2)) & 0x7fff;
                      }
                      uVar48 = *(ushort *)(pbVar36 + uVar37 * 2 + uVar50) & 0x7fff;
                      if (((uVar41 < uVar40) || (uVar48 < uVar41)) || ((uint)uVar42 < uVar48)) {
                        *(undefined8 *)(puVar45 + -8) = 0x100dd5;
                        func_0x(pbVar36,7);
                        sVar12 = *(short *)(&stack0x00000054 + lVar18);
                        uVar40 = *(uint *)(&stack0x00000050 + lVar18);
                        uVar50 = (ulonglong)*(uint *)(&stack0x0000004c + lVar18);
                        pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                        uVar42 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                      }
                      if ((uVar41 < uVar40) || ((uint)uVar42 < uVar41)) goto LAB_;
                      if (*(ushort *)(pbVar36 + uVar41) == 5) {
                        *(ushort *)(&stack0x0000003a + lVar18) =
                             *(ushort *)(&stack0x0000003a + lVar18) | 2;
                        *(short *)(&stack0x00000054 + lVar18) = sVar12 + -1;
                        uVar50 = (ulonglong)(uVar41 & 0xffff);
                        *(short *)(&stack0x00000062 + lVar18) = (short)uVar41;
                        pbVar1 = pbVar36 + uVar50;
                        uVar13 = *(ushort *)(&stack0x00000064 + lVar18);
                        if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                          uVar13 = uVar13 & 0xc7ff;
                        }
                        else {
                          uVar13 = uVar13 ^ (uVar13 ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
                        }
                        *(ushort *)(&stack0x00000064 + lVar18) = uVar13;
                        uVar14 = (uVar13 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar13;
                        *(ushort *)(&stack0x00000064 + lVar18) = uVar14;
                        pbVar57 = pbVar36 + uVar50 + ((ulonglong)uVar14 & 0x7ff) * 2 +
                                                     (ulonglong)((uVar13 >> 0xb & 7) * 2) + 4;
                        if (pbVar57 < pbVar1) {
                          *(undefined8 *)(puVar45 + -8) = 0x100ece;
                          func_0x(pbVar1,0x19);
                          uVar14 = *(ushort *)(&stack0x00000064 + lVar18);
                          uVar50 = (ulonglong)*(ushort *)(&stack0x00000062 + lVar18);
                          pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                          uVar42 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                        }
                        if (uVar48 - uVar41 <
                            (((*(uint *)(&stack0x00000064 + lVar18) & 0x7ff) * 2 - (int)uVar50) -
                            *(int *)(&stack0x00000040 + lVar18)) + (int)pbVar57) {
                          *(undefined8 *)(puVar45 + -8) = 0x100f06;
                          func_0x(pbVar36 + uVar50,0x19);
                          uVar14 = *(ushort *)(&stack0x00000064 + lVar18);
                          uVar50 = (ulonglong)*(ushort *)(&stack0x00000062 + lVar18);
                          pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                          uVar42 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                        }
                        if (((uVar14 & 0x3800) != 0) &&
                           (puVar49 = (ushort *)(pbVar36 + uVar50 + 4), (uVar14 & 0x3800) != 0)) {
                          do {
                            if ((uVar14 & 0x7ff) < (*puVar49 & 0x7ff)) {
                              *(undefined8 *)(puVar45 + -8) = 0x100f64;
                              func_0x(pbVar36 + uVar50,0x1a);
                              uVar14 = *(ushort *)(&stack0x00000064 + lVar18);
                              uVar50 = (ulonglong)*(ushort *)(&stack0x00000062 + lVar18);
                              pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                            }
                            uVar40 = (int)uVar47 + 1;
                            uVar47 = (ulonglong)uVar40;
                            puVar49 = puVar49 + 1;
                          } while ((int)uVar40 <
                                   (int)(*(uint *)(&stack0x00000064 + lVar18) >> 0xb & 7));
                          uVar42 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                        }
                        break;
                      }
                      if (*(ushort *)(pbVar36 + uVar41) < 0x400) break;
                      *(ushort *)(&stack0x0000003a + lVar18) =
                           *(ushort *)(&stack0x0000003a + lVar18) | 1;
                      uVar13 = sVar12 - 1;
                      uVar37 = (ulonglong)uVar13;
                      *(ushort *)(&stack0x00000054 + lVar18) = uVar13;
                      if (uVar13 == 0) break;
                    }
                  }
                  if ((*pbVar36 & 0x40) == 0) {
                    *(undefined4 *)(&stack0x0000005e + lVar18) = 0;
                  }
                  else {
                    *(int *)(&stack0x0000005e + lVar18) = (int)uVar42;
                    *(int *)(&stack0x0000003c + lVar18) = (int)uVar42 + 0xe;
                    *(undefined8 *)(puVar45 + -8) = 0x100fa9;
                    uVar26 = func_0x(&stack0x0000003a + lVar18);
                    *(undefined8 *)(puVar45 + -8) = 0x100fb8;
                    func_0x(uVar26,&stack0x00000188 + lVar18);
                    *(undefined8 *)(puVar45 + -8) = 0x100fc4;
                    iVar16 = func_0x(&stack0x00000188 + lVar18);
                    uVar42 = (ulonglong)(uint)(*(int *)(&stack0x0000003c + lVar18) + iVar16);
                    *(int *)(&stack0x0000003c + lVar18) =
                         *(int *)(&stack0x0000003c + lVar18) + iVar16;
                    pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                  }
                  if ((*(byte **)(&stack0x00000056 + lVar18) != (byte *)0x0) &&
                     (*(byte **)(&stack0x00000056 + lVar18) < pbVar36 + uVar42)) {
                    *(undefined8 *)(puVar45 + -8) = 0x101011;
                    cVar9 = func_0x(0x1ec08c0);
                    if (cVar9 != '\0') {
                      *(undefined8 *)(puVar45 + -8) = 0x10101a;
                      lVar19 = func_0x();
                      if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar45 + -8) = 0x101034;
                        cVar9 = func_0x(0x1ec08c0);
                        if (cVar9 == '\0') {
                          *(undefined8 *)(puVar45 + -8) = 0x101050;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(puVar45 + 0x20) = 0;
                          *(undefined8 *)(puVar45 + -8) = 0x101074;
                          (*_DAT_)(1,0x17b02cc,0x18d03b8,0x886);
                        }
                      }
                    }
                    uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                    *(undefined8 *)(puVar45 + -8) = 0x101082;
                    func_0x(uVar26,0x12);
                    uVar42 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                  }
                  if (0x3f3b < (int)uVar42 - 1U) {
                    *(undefined8 *)(puVar45 + -8) = 0x10109d;
                    cVar9 = func_0x(0x1ec08c0);
                    if (cVar9 != '\0') {
                      *(undefined8 *)(puVar45 + -8) = 0x1010a6;
                      lVar19 = func_0x();
                      if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar45 + -8) = 0x1010c0;
                        cVar9 = func_0x(0x1ec08c0);
                        if (cVar9 == '\0') {
                          *(undefined8 *)(puVar45 + -8) = 0x1010dc;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(puVar45 + 0x20) = 0;
                          *(undefined8 *)(puVar45 + -8) = 0x101100;
                          (*_DAT_)(1,0x17b02cc,0x18d03b8);
                        }
                      }
                    }
                    uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                    *(undefined8 *)(puVar45 + -8) = 0x10110e;
                    func_0x(uVar26,5);
                  }
                }
LAB_:
                uVar40 = -*(uint *)plVar43;
                *(undefined8 *)(puVar45 + -8) = 0x101121;
                func_0x(&stack0x00000838 + lVar18);
                pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                bVar30 = *pbVar36;
                if ((bVar30 >> 6 & 1) != 0) {
                  *(undefined8 *)(puVar45 + -8) = 0x101143;
                  func_0x(&stack0x0000003a + lVar18,&stack0x00000838 + lVar18);
                  pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                }
                if ((*pbVar36 & 0x20) == 0) {
                  *(undefined8 *)(puVar45 + -8) = 0x101156;
                  func_0x(&stack0x0000003a + lVar18);
                  pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                }
                uVar13 = *(ushort *)(&stack0x00000054 + lVar18);
                uVar48 = (uint)uVar13;
                uVar41 = (uint)uVar13;
                uVar47 = 0;
                if (uVar41 < uVar40) {
                  puVar49 = (ushort *)(pbVar36 + *(uint *)(&stack0x0000004c + lVar18));
                  uVar48 = *(uint *)(&stack0x0000004c + lVar18) + 2 + uVar41 * 2;
                  uVar31 = (uVar40 - uVar13) * 2;
                  if (*puVar49 != 0) {
                    do {
                      uVar14 = puVar49[uVar47 + 1];
                      puVar49[(uVar47 & 0xffff) + 1] = puVar49[(uVar47 & 0xffff) + 1] & 0x8000;
                      puVar49[(uVar47 & 0xffff) + 1] =
                           puVar49[(uVar47 & 0xffff) + 1] |
                           (uVar14 & 0x7fff) + (short)uVar31 & 0x7fff;
                      uVar34 = (int)uVar47 + 1;
                      uVar47 = (ulonglong)uVar34;
                    } while (uVar34 < *puVar49);
                    pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                  }
                  iVar16 = *(int *)(&stack0x0000003c + lVar18);
                  *(undefined8 *)(puVar45 + -8) = 0x1011ea;
                  func_0x
                            (pbVar36 + (ulonglong)uVar48 + (ulonglong)uVar31,pbVar36 + uVar48,
                             iVar16 - uVar48);
                  *(uint *)(&stack0x0000003c + lVar18) =
                       *(int *)(&stack0x0000003c + lVar18) + uVar31;
                  uVar31 = *(int *)(&stack0x00000050 + lVar18) + uVar31;
                  *(uint *)(&stack0x00000050 + lVar18) = uVar31;
                  if (uVar13 != 0) {
                    uVar31 = puVar49[(ulonglong)(uVar41 - 1) + 1] & 0x7fff;
                  }
                  do {
                    puVar49[(ulonglong)(uVar41 & 0xffff) + 1] = (ushort)uVar31 & 0x7fff;
                    uVar41 = uVar41 + 1;
                  } while (uVar41 < uVar40);
                  *puVar49 = *puVar49 + (short)(uVar40 - uVar13);
                  *(undefined8 *)(puVar45 + -8) = 0x10122c;
                  iVar16 = func_0x(&stack0x0000003a + lVar18);
                  if (iVar16 != 0) {
                    *(undefined8 *)(puVar45 + -8) = 0x101240;
                    uVar15 = func_0x
                                       (&stack0x0000003a + lVar18,&stack0x000001d8 + lVar18);
                    *(undefined2 *)(&stack0x00000062 + lVar18) = uVar15;
                  }
                  uVar48 = uVar40 & 0xffff;
                  *(short *)(&stack0x00000054 + lVar18) = (short)uVar40;
                  pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                }
                uVar47 = (ulonglong)*(uint *)(&stack0x0000004c + lVar18);
                if (uVar48 < uVar40) {
                  uVar50 = (ulonglong)
                           (*(ushort *)(pbVar36 + (ulonglong)uVar48 * 2 + uVar47) & 0x7fff);
                  iVar16 = 0;
LAB_:
                  puVar49 = (ushort *)(pbVar36 + uVar47);
                  uVar17 = *(undefined4 *)(&stack0x0000003c + lVar18);
                  *(undefined8 *)(puVar45 + -8) = 0x1012e9;
                  uVar17 = func_0x(uVar17,iVar16 + (int)uVar50);
                  lVar19 = *(longlong *)(&stack0x00000040 + lVar18);
                  *(undefined8 *)(puVar45 + -8) = 0x101305;
                  func_0x(lVar19 + 1 + uVar50,iVar16 + lVar19 + uVar50,uVar17);
                  uVar40 = uVar40 - 1;
                  if ((int)uVar40 < (int)(uint)*puVar49) {
                    do {
                      uVar13 = puVar49[(longlong)(int)uVar40 + 1];
                      puVar49[((ulonglong)uVar40 & 0xffff) + 1] =
                           puVar49[((ulonglong)uVar40 & 0xffff) + 1] & 0x8000;
                      puVar49[((ulonglong)uVar40 & 0xffff) + 1] =
                           puVar49[((ulonglong)uVar40 & 0xffff) + 1] |
                           ((uVar13 & 0x7fff) - (short)iVar16) + 1 & 0x7fff;
                      uVar40 = uVar40 + 1;
                    } while ((int)uVar40 < (int)(uint)*puVar49);
                  }
                  *(int *)(&stack0x0000003c + lVar18) =
                       *(int *)(&stack0x0000003c + lVar18) + (1 - iVar16);
                  *(undefined8 *)(puVar45 + -8) = 0x101360;
                  iVar16 = func_0x(&stack0x0000003a + lVar18);
                  if (iVar16 != 0) {
                    *(undefined8 *)(puVar45 + -8) = 0x101374;
                    uVar15 = func_0x
                                       (&stack0x0000003a + lVar18,&stack0x000001dc + lVar18);
                    *(undefined2 *)(&stack0x00000062 + lVar18) = uVar15;
                  }
                  pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                }
                else {
                  uVar41 = *(uint *)(&stack0x00000050 + lVar18);
                  if (uVar40 != 1) {
                    uVar41 = *(ushort *)(pbVar36 + (longlong)(int)uVar40 * 2 + (uVar47 - 2)) &
                             0x7fff;
                  }
                  uVar50 = (ulonglong)uVar41;
                  uVar48 = *(ushort *)(pbVar36 + (longlong)(int)uVar40 * 2 + uVar47) & 0x7fff;
                  if (((uVar41 < *(uint *)(&stack0x00000050 + lVar18)) || (uVar48 < uVar41)) ||
                     (*(uint *)(&stack0x0000003c + lVar18) < uVar48)) {
                    *(undefined8 *)(puVar45 + -8) = 0x1012ab;
                    func_0x(pbVar36,7);
                    uVar47 = (ulonglong)*(uint *)(&stack0x0000004c + lVar18);
                    pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                  }
                  iVar16 = uVar48 - uVar41;
                  if (iVar16 != 1) goto LAB_;
                }
                pbVar36[uVar50] = **(byte **)(&stack0x00000080 + lVar18);
                if ((bVar30 >> 6 & 1) != 0) {
                  *(undefined8 *)(puVar45 + -8) = 0x10139f;
                  func_0x(&stack0x0000003a + lVar18,&stack0x00000838 + lVar18);
                }
                plVar43 = *(longlong **)(&stack0x00000090 + lVar18);
                goto LAB_;
              }
              *(undefined8 *)(puVar45 + -8) = 0x10147a;
              func_0x(&stack0x00000918 + lVar18);
              *(undefined4 *)(&stack0x000000b8 + lVar18) = 0;
              if (*(int *)(&stack0x0000003c + lVar18) == 0) {
                *(undefined2 *)(&stack0x0000003a + lVar18) = 0;
                uVar40 = *(uint *)(&stack0x00000048 + lVar18);
                uVar50 = (ulonglong)uVar40;
                *(uint *)(&stack0x0000004c + lVar18) = uVar40;
                pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                if ((*pbVar36 & 0x10) != 0) {
                  uVar40 = uVar40 + 2 + (*(ushort *)(pbVar36 + uVar50) + 7 >> 3);
                  uVar50 = (ulonglong)uVar40;
                  *(uint *)(&stack0x0000004c + lVar18) = uVar40;
                }
                if ((*pbVar36 & 0x20) == 0) {
                  *(int *)(&stack0x0000003c + lVar18) = (int)uVar50;
                  *(undefined2 *)(&stack0x00000054 + lVar18) = 0;
                  *(int *)(&stack0x00000050 + lVar18) = (int)uVar50;
                  uVar42 = uVar50;
                }
                else {
                  puVar49 = (ushort *)(pbVar36 + uVar50);
                  *(ushort **)(&stack0x000000a8 + lVar18) = puVar49;
                  uVar13 = *puVar49;
                  *(ushort *)(&stack0x00000054 + lVar18) = uVar13;
                  if (uVar13 == 0) {
                    *(undefined8 *)(puVar45 + -8) = 0x1014e4;
                    cVar9 = func_0x(0x1ec08c0);
                    if (cVar9 != '\0') {
                      *(undefined8 *)(puVar45 + -8) = 0x1014ed;
                      lVar19 = func_0x();
                      if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar45 + -8) = 0x101507;
                        cVar9 = func_0x(0x1ec08c0);
                        if (cVar9 == '\0') {
                          *(undefined8 *)(puVar45 + -8) = 0x101523;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(puVar45 + 0x20) = 0;
                          *(undefined8 *)(puVar45 + -8) = 0x101547;
                          (*_DAT_)(1,0x17b02cc,0x18d03b8,0x80f);
                        }
                      }
                    }
                    uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                    *(undefined8 *)(puVar45 + -8) = 0x101555;
                    func_0x(uVar26,3);
                    uVar13 = *(ushort *)(&stack0x00000054 + lVar18);
                    uVar50 = (ulonglong)*(uint *)(&stack0x0000004c + lVar18);
                    pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                  }
                  uVar40 = (int)uVar50 + (uVar13 + 1) * 2;
                  *(uint *)(&stack0x00000050 + lVar18) = uVar40;
                  if (0x1f9e < uVar40) {
                    *(undefined8 *)(puVar45 + -8) = 0x101588;
                    cVar9 = func_0x(0x1ec08c0);
                    if (cVar9 != '\0') {
                      *(undefined8 *)(puVar45 + -8) = 0x101591;
                      lVar19 = func_0x();
                      if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar45 + -8) = 0x1015ab;
                        cVar9 = func_0x(0x1ec08c0);
                        if (cVar9 == '\0') {
                          *(undefined8 *)(puVar45 + -8) = 0x1015c7;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar45 + 0x20) = 0;
                          *(undefined8 *)(puVar45 + -8) = 0x1015eb;
                          (*_DAT_)(1,0x17b02cc,0x18d03b8,0x816);
                        }
                      }
                    }
                    uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                    *(undefined8 *)(puVar45 + -8) = 0x1015f9;
                    func_0x(uVar26,4);
                    uVar13 = *(ushort *)(&stack0x00000054 + lVar18);
                    uVar40 = *(uint *)(&stack0x00000050 + lVar18);
                    uVar50 = (ulonglong)*(uint *)(&stack0x0000004c + lVar18);
                    pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                  }
                  uVar37 = (ulonglong)uVar13;
                  uVar48 = puVar49[uVar37] & 0x7fff;
                  *(uint *)(&stack0x0000003c + lVar18) = uVar48;
                  if (uVar48 < uVar40) {
                    *(undefined8 *)(puVar45 + -8) = 0x101631;
                    cVar9 = func_0x(0x1ec08c0);
                    if (cVar9 != '\0') {
                      *(undefined8 *)(puVar45 + -8) = 0x10163a;
                      lVar19 = func_0x();
                      if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar45 + -8) = 0x101654;
                        cVar9 = func_0x(0x1ec08c0);
                        if (cVar9 == '\0') {
                          *(undefined8 *)(puVar45 + -8) = 0x101670;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar45 + 0x20) = 0;
                          *(undefined8 *)(puVar45 + -8) = 0x101694;
                          (*_DAT_)(1,0x17b02cc,0x18d03b8,0x81d);
                        }
                      }
                    }
                    uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                    *(undefined8 *)(puVar45 + -8) = 0x1016a2;
                    func_0x(uVar26,4);
                    uVar37 = (ulonglong)*(ushort *)(&stack0x00000054 + lVar18);
                    uVar40 = *(uint *)(&stack0x00000050 + lVar18);
                    uVar50 = (ulonglong)*(uint *)(&stack0x0000004c + lVar18);
                    pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                    uVar48 = *(uint *)(&stack0x0000003c + lVar18);
                  }
                  uVar42 = (ulonglong)uVar48;
                  uVar46 = uVar47;
                  if ((short)uVar37 != 0) {
                    do {
                      puVar49 = puVar49 + 1;
                      uVar48 = *puVar49 & 0x7fff;
                      if ((uVar48 < uVar40) || ((uint)uVar42 < uVar48)) {
                        *(undefined8 *)(puVar45 + -8) = 0x1016f2;
                        cVar9 = func_0x(0x1ec08c0);
                        if (cVar9 != '\0') {
                          *(undefined8 *)(puVar45 + -8) = 0x1016fb;
                          lVar19 = func_0x();
                          if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar45 + -8) = 0x101715;
                            cVar9 = func_0x(0x1ec08c0);
                            if (cVar9 == '\0') {
                              *(undefined8 *)(puVar45 + -8) = 0x101731;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar45 + 0x20) = 0;
                              *(undefined8 *)(puVar45 + -8) = 0x101755;
                              (*_DAT_)(1,0x17b02cc,0x18d03b8,0x82a);
                            }
                          }
                        }
                        uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                        *(undefined8 *)(puVar45 + -8) = 0x101763;
                        func_0x(uVar26,4);
                        uVar37 = (ulonglong)*(ushort *)(&stack0x00000054 + lVar18);
                        pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                        uVar42 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                      }
                      uVar31 = (int)uVar46 + 1;
                      uVar46 = (ulonglong)uVar31;
                      uVar40 = uVar48;
                    } while ((int)uVar31 < (int)uVar37);
                    uVar40 = *(uint *)(&stack0x00000050 + lVar18);
                    uVar50 = (ulonglong)*(uint *)(&stack0x0000004c + lVar18);
                    puVar49 = *(ushort **)(&stack0x000000a8 + lVar18);
                    plVar43 = *(longlong **)(&stack0x00000090 + lVar18);
                  }
                  while( true ) {
                    sVar12 = (short)uVar37;
                    if (-1 < (short)puVar49[(ulonglong)((int)uVar37 - 1) + 1]) break;
                    uVar48 = uVar40;
                    if ((int)uVar37 != 1) {
                      uVar48 = *(ushort *)(pbVar36 + uVar37 * 2 + (uVar50 - 2)) & 0x7fff;
                    }
                    uVar31 = *(ushort *)(pbVar36 + uVar37 * 2 + uVar50) & 0x7fff;
                    if (((uVar48 < uVar40) || (uVar31 < uVar48)) || ((uint)uVar42 < uVar31)) {
                      *(undefined8 *)(puVar45 + -8) = 0x1017f4;
                      func_0x(pbVar36,7);
                      sVar12 = *(short *)(&stack0x00000054 + lVar18);
                      uVar40 = *(uint *)(&stack0x00000050 + lVar18);
                      uVar50 = (ulonglong)*(uint *)(&stack0x0000004c + lVar18);
                      pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                      uVar42 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                    }
                    if ((uVar48 < uVar40) || ((uint)uVar42 < uVar48)) goto LAB_;
                    if (*(ushort *)(pbVar36 + uVar48) == 5) {
                      *(ushort *)(&stack0x0000003a + lVar18) =
                           *(ushort *)(&stack0x0000003a + lVar18) | 2;
                      *(short *)(&stack0x00000054 + lVar18) = sVar12 + -1;
                      uVar50 = (ulonglong)(uVar48 & 0xffff);
                      *(short *)(&stack0x00000062 + lVar18) = (short)uVar48;
                      pbVar1 = pbVar36 + uVar50;
                      uVar13 = *(ushort *)(&stack0x00000064 + lVar18);
                      if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                        uVar13 = uVar13 & 0xc7ff;
                      }
                      else {
                        uVar13 = uVar13 ^ (uVar13 ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
                      }
                      *(ushort *)(&stack0x00000064 + lVar18) = uVar13;
                      uVar14 = (uVar13 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar13;
                      *(ushort *)(&stack0x00000064 + lVar18) = uVar14;
                      pbVar57 = pbVar36 + (ulonglong)((uVar13 >> 0xb & 7) * 2) + 4 + uVar50 +
                                          ((ulonglong)uVar14 & 0x7ff) * 2;
                      if (pbVar57 < pbVar1) {
                        *(undefined8 *)(puVar45 + -8) = 0x1018ed;
                        func_0x(pbVar1,0x19);
                        uVar14 = *(ushort *)(&stack0x00000064 + lVar18);
                        uVar50 = (ulonglong)*(ushort *)(&stack0x00000062 + lVar18);
                        pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                        uVar42 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                      }
                      if (uVar31 - uVar48 <
                          (((*(uint *)(&stack0x00000064 + lVar18) & 0x7ff) * 2 - (int)uVar50) -
                          *(int *)(&stack0x00000040 + lVar18)) + (int)pbVar57) {
                        *(undefined8 *)(puVar45 + -8) = 0x101925;
                        func_0x(pbVar36 + uVar50,0x19);
                        uVar14 = *(ushort *)(&stack0x00000064 + lVar18);
                        uVar50 = (ulonglong)*(ushort *)(&stack0x00000062 + lVar18);
                        pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                        uVar42 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                      }
                      if (((uVar14 & 0x3800) != 0) &&
                         (puVar49 = (ushort *)(pbVar36 + uVar50 + 4), uVar37 = uVar47,
                         (uVar14 & 0x3800) != 0)) {
                        do {
                          if ((uVar14 & 0x7ff) < (*puVar49 & 0x7ff)) {
                            *(undefined8 *)(puVar45 + -8) = 0x101984;
                            func_0x(pbVar36 + uVar50,0x1a);
                            uVar14 = *(ushort *)(&stack0x00000064 + lVar18);
                            uVar50 = (ulonglong)*(ushort *)(&stack0x00000062 + lVar18);
                            pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                          }
                          uVar40 = (int)uVar37 + 1;
                          puVar49 = puVar49 + 1;
                          uVar37 = (ulonglong)uVar40;
                        } while ((int)uVar40 <
                                 (int)(*(uint *)(&stack0x00000064 + lVar18) >> 0xb & 7));
                        uVar42 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                      }
                      break;
                    }
                    if (*(ushort *)(pbVar36 + uVar48) < 0x400) break;
                    *(ushort *)(&stack0x0000003a + lVar18) =
                         *(ushort *)(&stack0x0000003a + lVar18) | 1;
                    uVar13 = sVar12 - 1;
                    uVar37 = (ulonglong)uVar13;
                    *(ushort *)(&stack0x00000054 + lVar18) = uVar13;
                    if (uVar13 == 0) break;
                  }
                }
                if ((*pbVar36 & 0x40) == 0) {
                  *(undefined4 *)(&stack0x0000005e + lVar18) = 0;
                }
                else {
                  *(int *)(&stack0x0000005e + lVar18) = (int)uVar42;
                  *(int *)(&stack0x0000003c + lVar18) = (int)uVar42 + 0xe;
                  *(undefined8 *)(puVar45 + -8) = 0x1019c9;
                  uVar26 = func_0x(&stack0x0000003a + lVar18);
                  *(undefined8 *)(puVar45 + -8) = 0x1019d8;
                  func_0x(uVar26,&stack0x00000190 + lVar18);
                  *(undefined8 *)(puVar45 + -8) = 0x1019e4;
                  iVar16 = func_0x(&stack0x00000190 + lVar18);
                  uVar42 = (ulonglong)(uint)(*(int *)(&stack0x0000003c + lVar18) + iVar16);
                  *(int *)(&stack0x0000003c + lVar18) = *(int *)(&stack0x0000003c + lVar18) + iVar16
                  ;
                  pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                }
                if ((*(byte **)(&stack0x00000056 + lVar18) != (byte *)0x0) &&
                   (*(byte **)(&stack0x00000056 + lVar18) < pbVar36 + uVar42)) {
                  *(undefined8 *)(puVar45 + -8) = 0x101a31;
                  cVar9 = func_0x(0x1ec08c0);
                  if (cVar9 != '\0') {
                    *(undefined8 *)(puVar45 + -8) = 0x101a3a;
                    lVar19 = func_0x();
                    if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar45 + -8) = 0x101a54;
                      cVar9 = func_0x(0x1ec08c0);
                      if (cVar9 == '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x101a70;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(puVar45 + 0x20) = 0;
                        *(undefined8 *)(puVar45 + -8) = 0x101a94;
                        (*_DAT_)(1,0x17b02cc,0x18d03b8,0x886);
                      }
                    }
                  }
                  uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                  *(undefined8 *)(puVar45 + -8) = 0x101aa2;
                  func_0x(uVar26,0x12);
                  uVar42 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                }
                if (0x3f3b < (int)uVar42 - 1U) {
                  *(undefined8 *)(puVar45 + -8) = 0x101abd;
                  cVar9 = func_0x(0x1ec08c0);
                  if (cVar9 != '\0') {
                    *(undefined8 *)(puVar45 + -8) = 0x101ac6;
                    lVar19 = func_0x();
                    if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar45 + -8) = 0x101ae0;
                      cVar9 = func_0x(0x1ec08c0);
                      if (cVar9 == '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x101afc;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(puVar45 + 0x20) = 0;
                        *(undefined8 *)(puVar45 + -8) = 0x101b20;
                        (*_DAT_)(1,0x17b02cc,0x18d03b8,0x88b);
                      }
                    }
                  }
                  uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                  *(undefined8 *)(puVar45 + -8) = 0x101b2e;
                  func_0x(uVar26,5);
                }
              }
LAB_:
              *(undefined8 *)(puVar45 + -8) = 0x101b37;
              func_0x(&stack0x0000003a + lVar18);
              bVar30 = **(byte **)(&stack0x00000040 + lVar18);
              if ((bVar30 >> 6 & 1) != 0) {
                *(undefined8 *)(puVar45 + -8) = 0x101b59;
                func_0x(&stack0x0000003a + lVar18,&stack0x00000918 + lVar18);
              }
              if (((&stack0x0000003a)[lVar18] & 1) != 0) {
                *(undefined8 *)(puVar45 + -8) = 0x101b74;
                puVar20 = (undefined4 *)
                          func_0x(&stack0x0000003a + lVar18,0x400,&stack0x000000b8 + lVar18)
                ;
                *(undefined4 *)(&stack0x00000110 + lVar18) = *puVar20;
                *(undefined2 *)(&stack0x00000114 + lVar18) = *(undefined2 *)(puVar20 + 1);
                *(undefined2 *)(&stack0x00000116 + lVar18) = *(undefined2 *)((longlong)puVar20 + 6);
              }
              if ((**(byte **)(&stack0x00000040 + lVar18) & 0x20) == 0) {
                *(undefined8 *)(puVar45 + -8) = 0x101ba4;
                func_0x(&stack0x0000003a + lVar18);
              }
              lVar24 = (ulonglong)*(uint *)(&stack0x0000004c + lVar18) +
                       *(longlong *)(&stack0x00000040 + lVar18);
              *(undefined8 *)(puVar45 + -8) = 0x101bb4;
              iVar16 = func_0x(&stack0x0000003a + lVar18);
              lVar19 = *(longlong *)(&stack0x00000040 + lVar18);
              if (iVar16 == 0) {
                uVar13 = *(ushort *)(&stack0x00000054 + lVar18);
                uVar50 = (ulonglong)uVar13;
                puVar49 = (ushort *)(lVar19 + (ulonglong)*(uint *)(&stack0x0000004c + lVar18));
                uVar40 = *(uint *)(&stack0x0000004c + lVar18) + (uVar13 + 1) * 2;
                if (*puVar49 != 0) {
                  do {
                    uVar14 = puVar49[uVar47 + 1];
                    puVar49[(uVar47 & 0xffff) + 1] = puVar49[(uVar47 & 0xffff) + 1] & 0x8000;
                    puVar49[(uVar47 & 0xffff) + 1] =
                         puVar49[(uVar47 & 0xffff) + 1] | (uVar14 & 0x7fff) + 2 & 0x7fff;
                    uVar48 = (int)uVar47 + 1;
                    uVar47 = (ulonglong)uVar48;
                  } while (uVar48 < *puVar49);
                  lVar19 = *(longlong *)(&stack0x00000040 + lVar18);
                }
                iVar16 = *(int *)(&stack0x0000003c + lVar18);
                *(undefined8 *)(puVar45 + -8) = 0x101c9a;
                func_0x
                          ((ulonglong)uVar40 + 2 + lVar19,(ulonglong)uVar40 + lVar19,iVar16 - uVar40
                          );
                *(int *)(&stack0x0000003c + lVar18) = *(int *)(&stack0x0000003c + lVar18) + 2;
                uVar40 = *(int *)(&stack0x00000050 + lVar18) + 2;
                *(uint *)(&stack0x00000050 + lVar18) = uVar40;
                if (uVar13 != 0) {
                  uVar40 = puVar49[(ulonglong)(uVar13 - 1) + 1] & 0x7fff;
                }
                if ((uint)uVar13 < uVar13 + 1) {
                  do {
                    puVar49[(uVar50 & 0xffff) + 1] = (ushort)uVar40 & 0x7fff;
                    uVar48 = (int)uVar50 + 1;
                    uVar50 = (ulonglong)uVar48;
                  } while (uVar48 < uVar13 + 1);
                }
                *puVar49 = *puVar49 + 1;
                *(undefined8 *)(puVar45 + -8) = 0x101cdb;
                func_0x(&stack0x0000003a + lVar18);
                uVar13 = *(ushort *)
                          (lVar24 + 2 + (ulonglong)*(ushort *)(&stack0x00000054 + lVar18) * 2);
                *(undefined8 *)(puVar45 + -8) = 0x101cf3;
                func_0x(&stack0x00000298 + lVar18);
                *(undefined4 *)(puVar45 + 0x28) = 0;
                *(longlong **)(puVar45 + 0x20) = plVar43;
                uVar26 = *(undefined8 *)(&stack0x00000080 + lVar18);
                *(undefined8 *)(puVar45 + -8) = 0x101d19;
                func_0x(&stack0x00000288 + lVar18,uVar26,1,0);
                *(undefined **)(puVar45 + 0x28) = &stack0x000000f8 + lVar18;
                *(undefined **)(puVar45 + 0x20) = &stack0x00000288 + lVar18;
                *(undefined8 *)(puVar45 + -8) = 0x101d4c;
                func_0x(&stack0x00000062 + lVar18,uVar13 & 0x7fff,0x1f9e);
                iVar16 = *(int *)(&stack0x000000f8 + lVar18);
              }
              else {
                uVar13 = *(ushort *)(&stack0x00000054 + lVar18);
                uVar40 = *(uint *)(&stack0x00000050 + lVar18);
                if (uVar13 != 0) {
                  uVar40 = *(ushort *)
                            ((ulonglong)*(uint *)(&stack0x0000004c + lVar18) + lVar19 +
                            (ulonglong)uVar13 * 2) & 0x7fff;
                }
                uVar41 = *(ushort *)
                          ((ulonglong)*(uint *)(&stack0x0000004c + lVar18) + lVar19 + 2 +
                          (ulonglong)(uint)uVar13 * 2) & 0x7fff;
                if (((uVar40 < *(uint *)(&stack0x00000050 + lVar18)) || (uVar41 < uVar40)) ||
                   (*(uint *)(&stack0x0000003c + lVar18) < uVar41)) {
                  *(undefined8 *)(puVar45 + -8) = 0x101c07;
                  func_0x(lVar19,7);
                }
                uVar41 = uVar41 - uVar40;
                uVar26 = *(undefined8 *)(&stack0x00000080 + lVar18);
                *(undefined8 *)(puVar45 + -8) = 0x101c1f;
                iVar16 = func_0x(&stack0x00000062 + lVar18,plVar43,uVar26);
              }
              iVar35 = (*(int *)(&stack0x0000003c + lVar18) - uVar41) + iVar16;
              *(int *)(&stack0x0000003c + lVar18) = iVar35;
              if (((&stack0x0000003a)[lVar18] & 1) != 0) {
                *(ushort *)
                 (lVar24 + 2 + (ulonglong)(*(ushort *)(&stack0x00000054 + lVar18) + 1) * 2) =
                     (ushort)iVar35 | 0x8000;
                iVar35 = (*(int *)(&stack0x0000003c + lVar18) - *(int *)(&stack0x000000b8 + lVar18))
                         + -2;
              }
              *(ushort *)(lVar24 + 2 + (ulonglong)*(ushort *)(&stack0x00000054 + lVar18) * 2) =
                   (ushort)iVar35 | 0x8000;
              if (iVar16 == 0) {
                uVar13 = *(ushort *)(&stack0x00000054 + lVar18);
                *(undefined8 *)(puVar45 + -8) = 0x101da3;
                func_0x(&stack0x0000003a + lVar18,uVar13 + 1);
                if ((**(byte **)(&stack0x00000040 + lVar18) & 0x20) != 0) {
                  *(short *)(&stack0x00000054 + lVar18) = *(short *)(&stack0x00000054 + lVar18) + 1;
                  *(ushort *)(&stack0x0000003a + lVar18) =
                       *(ushort *)(&stack0x0000003a + lVar18) & 0xfffd;
                  *(undefined8 *)(puVar45 + -8) = 0x101dc2;
                  func_0x(&stack0x00000062 + lVar18);
                }
              }
              else {
                *(ushort *)(&stack0x0000003a + lVar18) = *(ushort *)(&stack0x0000003a + lVar18) | 2;
                *(undefined8 *)(puVar45 + -8) = 0x101dd5;
                uVar15 = func_0x
                                   (&stack0x0000003a + lVar18,&stack0x00000178 + lVar18);
                *(undefined2 *)(&stack0x00000062 + lVar18) = uVar15;
              }
              if (((&stack0x0000003a)[lVar18] & 1) != 0) {
                uVar17 = *(undefined4 *)(&stack0x000000b8 + lVar18);
                *(undefined8 *)(puVar45 + -8) = 0x101dfb;
                func_0x(&stack0x0000003a + lVar18,0x400,uVar17);
              }
              if ((bVar30 >> 6 & 1) != 0) {
                *(undefined8 *)(puVar45 + -8) = 0x101e10;
                func_0x(&stack0x0000003a + lVar18,&stack0x00000918 + lVar18);
              }
              param_2 = *(longlong ***)(&stack0x00000070 + lVar18);
            }
            else {
              bVar30 = (byte)*(ushort *)((longlong)plVar43 + 6);
              if ((*(ushort *)((longlong)plVar43 + 6) & 8) == 0) {
                if (*(int *)(&stack0x0000003c + lVar18) == 0) {
                  *(undefined2 *)(&stack0x0000003a + lVar18) = 0;
                  uVar40 = *(uint *)(&stack0x00000048 + lVar18);
                  *(uint *)(&stack0x0000004c + lVar18) = uVar40;
                  if ((**(byte **)(&stack0x00000040 + lVar18) & 0x10) != 0) {
                    *(uint *)(&stack0x0000004c + lVar18) =
                         uVar40 + 2 +
                         (*(ushort *)(*(byte **)(&stack0x00000040 + lVar18) + uVar40) + 7 >> 3);
                  }
                  if ((**(byte **)(&stack0x00000040 + lVar18) & 0x20) == 0) {
                    uVar40 = *(uint *)(&stack0x0000004c + lVar18);
                    uVar50 = (ulonglong)uVar40;
                    *(uint *)(&stack0x0000003c + lVar18) = uVar40;
                    *(undefined2 *)(&stack0x00000054 + lVar18) = 0;
                    *(uint *)(&stack0x00000050 + lVar18) = uVar40;
                  }
                  else {
                    puVar49 = (ushort *)
                              (*(byte **)(&stack0x00000040 + lVar18) +
                              *(uint *)(&stack0x0000004c + lVar18));
                    uVar13 = *puVar49;
                    *(ushort *)(&stack0x00000054 + lVar18) = uVar13;
                    if (uVar13 == 0) {
                      *(undefined8 *)(puVar45 + -8) = 0x100397;
                      cVar9 = func_0x(0x1ec08c0);
                      if (cVar9 != '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x1003a0;
                        lVar19 = func_0x();
                        if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar45 + -8) = 0x1003ba;
                          cVar9 = func_0x(0x1ec08c0);
                          if (cVar9 == '\0') {
                            *(undefined8 *)(puVar45 + -8) = 0x1003d6;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(puVar45 + 0x20) = 0;
                            *(undefined8 *)(puVar45 + -8) = 0x1003fc;
                            (*_DAT_)(1,0x17b02cc,0x18d03b8,0x80f);
                          }
                        }
                      }
                      uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                      *(undefined8 *)(puVar45 + -8) = 0x10040a;
                      func_0x(uVar26,3);
                      uVar13 = *(ushort *)(&stack0x00000054 + lVar18);
                    }
                    uVar40 = *(int *)(&stack0x0000004c + lVar18) + 2 + (uint)uVar13 * 2;
                    *(uint *)(&stack0x00000050 + lVar18) = uVar40;
                    if (0x1f9e < uVar40) {
                      *(undefined8 *)(puVar45 + -8) = 0x100439;
                      cVar9 = func_0x(0x1ec08c0);
                      if (cVar9 != '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x100442;
                        lVar19 = func_0x();
                        if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar45 + -8) = 0x10045c;
                          cVar9 = func_0x(0x1ec08c0);
                          if (cVar9 == '\0') {
                            *(undefined8 *)(puVar45 + -8) = 0x100478;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar45 + 0x20) = 0;
                            *(undefined8 *)(puVar45 + -8) = 0x10049e;
                            (*_DAT_)(1,0x17b02cc,0x18d03b8,0x816);
                          }
                        }
                      }
                      uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                      *(undefined8 *)(puVar45 + -8) = 0x1004ac;
                      func_0x(uVar26,4);
                      uVar13 = *(ushort *)(&stack0x00000054 + lVar18);
                      uVar40 = *(uint *)(&stack0x00000050 + lVar18);
                    }
                    uVar42 = (ulonglong)uVar13;
                    uVar41 = puVar49[uVar42] & 0x7fff;
                    *(uint *)(&stack0x0000003c + lVar18) = uVar41;
                    if (uVar41 < uVar40) {
                      *(undefined8 *)(puVar45 + -8) = 0x1004de;
                      cVar9 = func_0x(0x1ec08c0);
                      if (cVar9 != '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x1004e7;
                        lVar19 = func_0x();
                        if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar45 + -8) = 0x100501;
                          cVar9 = func_0x(0x1ec08c0);
                          if (cVar9 == '\0') {
                            *(undefined8 *)(puVar45 + -8) = 0x10051d;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar45 + 0x20) = 0;
                            *(undefined8 *)(puVar45 + -8) = 0x100543;
                            (*_DAT_)(1,0x17b02cc,0x18d03b8,0x81d);
                          }
                        }
                      }
                      uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                      *(undefined8 *)(puVar45 + -8) = 0x100551;
                      func_0x(uVar26,4);
                      uVar42 = (ulonglong)*(ushort *)(&stack0x00000054 + lVar18);
                      uVar40 = *(uint *)(&stack0x00000050 + lVar18);
                      uVar41 = *(uint *)(&stack0x0000003c + lVar18);
                    }
                    uVar50 = (ulonglong)uVar41;
                    uVar37 = uVar47;
                    puVar55 = puVar49;
                    if ((short)uVar42 != 0) {
                      do {
                        uVar41 = puVar55[1] & 0x7fff;
                        if ((uVar41 < uVar40) || ((uint)uVar50 < uVar41)) {
                          *(undefined8 *)(puVar45 + -8) = 0x1005a0;
                          cVar9 = func_0x(0x1ec08c0);
                          if (cVar9 != '\0') {
                            *(undefined8 *)(puVar45 + -8) = 0x1005a9;
                            lVar19 = func_0x();
                            if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar45 + -8) = 0x1005c3;
                              cVar9 = func_0x(0x1ec08c0);
                              if (cVar9 == '\0') {
                                *(undefined8 *)(puVar45 + -8) = 0x1005df;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar45 + 0x20) = 0;
                                *(undefined8 *)(puVar45 + -8) = 0x100603;
                                (*_DAT_)(1,0x17b02cc,0x18d03b8,0x82a);
                              }
                            }
                          }
                          uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                          *(undefined8 *)(puVar45 + -8) = 0x100611;
                          func_0x(uVar26,4);
                          uVar42 = (ulonglong)*(ushort *)(&stack0x00000054 + lVar18);
                          uVar50 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                        }
                        uVar48 = (int)uVar37 + 1;
                        uVar37 = (ulonglong)uVar48;
                        puVar55 = puVar55 + 1;
                        uVar40 = uVar41;
                      } while ((int)uVar48 < (int)uVar42);
                      uVar40 = *(uint *)(&stack0x00000050 + lVar18);
                      param_2 = *(longlong ***)(&stack0x00000070 + lVar18);
                    }
                    while ((short)puVar49[(ulonglong)((int)uVar42 - 1) + 1] < 0) {
                      uVar41 = uVar40;
                      if ((int)uVar42 != 1) {
                        uVar41 = *(ushort *)
                                  ((ulonglong)*(uint *)(&stack0x0000004c + lVar18) +
                                   *(longlong *)(&stack0x00000040 + lVar18) + -2 + uVar42 * 2) &
                                 0x7fff;
                      }
                      uVar48 = *(ushort *)
                                ((ulonglong)*(uint *)(&stack0x0000004c + lVar18) +
                                 *(longlong *)(&stack0x00000040 + lVar18) + uVar42 * 2) & 0x7fff;
                      if (((uVar41 < uVar40) || (uVar48 < uVar41)) || ((uint)uVar50 < uVar48)) {
                        uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                        *(undefined8 *)(puVar45 + -8) = 0x100694;
                        func_0x(uVar26,7);
                        uVar42 = (ulonglong)*(ushort *)(&stack0x00000054 + lVar18);
                        uVar40 = *(uint *)(&stack0x00000050 + lVar18);
                        uVar50 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                      }
                      if ((uVar41 < uVar40) || ((uint)uVar50 < uVar41)) goto LAB_;
                      if (*(ushort *)((ulonglong)uVar41 + *(longlong *)(&stack0x00000040 + lVar18))
                          == 5) {
                        *(ushort *)(&stack0x0000003a + lVar18) =
                             *(ushort *)(&stack0x0000003a + lVar18) | 2;
                        *(short *)(&stack0x00000054 + lVar18) = (short)uVar42 + -1;
                        uVar37 = (ulonglong)(uVar41 & 0xffff);
                        *(short *)(&stack0x00000062 + lVar18) = (short)uVar41;
                        uVar42 = *(longlong *)(&stack0x00000040 + lVar18) + uVar37;
                        uVar13 = *(ushort *)(&stack0x00000064 + lVar18);
                        if ((*(ushort *)(uVar42 + 2) & 0x4000) == 0) {
                          uVar13 = uVar13 & 0xc7ff;
                        }
                        else {
                          uVar13 = uVar13 ^ (uVar13 ^ *(ushort *)(uVar42 + 2)) & 0x3800;
                        }
                        *(ushort *)(&stack0x00000064 + lVar18) = uVar13;
                        uVar14 = (uVar13 ^ *(ushort *)(uVar42 + 2)) & 0x7ff ^ uVar13;
                        *(ushort *)(&stack0x00000064 + lVar18) = uVar14;
                        uVar46 = (ulonglong)((uVar13 >> 0xb & 7) * 2) +
                                 *(longlong *)(&stack0x00000040 + lVar18) + 4 +
                                 ((ulonglong)uVar14 & 0x7ff) * 2 + uVar37;
                        if (uVar46 < uVar42) {
                          *(undefined8 *)(puVar45 + -8) = 0x100793;
                          func_0x(uVar42,0x19);
                          uVar14 = *(ushort *)(&stack0x00000064 + lVar18);
                          uVar37 = (ulonglong)*(ushort *)(&stack0x00000062 + lVar18);
                          uVar50 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                        }
                        if (uVar48 - uVar41 <
                            (((*(uint *)(&stack0x00000064 + lVar18) & 0x7ff) * 2 - (int)uVar37) -
                            *(int *)(&stack0x00000040 + lVar18)) + (int)uVar46) {
                          lVar19 = *(longlong *)(&stack0x00000040 + lVar18);
                          *(undefined8 *)(puVar45 + -8) = 0x1007ca;
                          func_0x(uVar37 + lVar19,0x19);
                          uVar14 = *(ushort *)(&stack0x00000064 + lVar18);
                          uVar37 = (ulonglong)*(ushort *)(&stack0x00000062 + lVar18);
                          uVar50 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                        }
                        if (((uVar14 & 0x3800) != 0) &&
                           (puVar49 = (ushort *)
                                      (*(longlong *)(&stack0x00000040 + lVar18) + 4 + uVar37),
                           (uVar14 & 0x3800) != 0)) {
                          do {
                            if ((uVar14 & 0x7ff) < (*puVar49 & 0x7ff)) {
                              lVar19 = *(longlong *)(&stack0x00000040 + lVar18);
                              *(undefined8 *)(puVar45 + -8) = 0x100836;
                              func_0x(uVar37 + lVar19,0x1a);
                              uVar14 = *(ushort *)(&stack0x00000064 + lVar18);
                              uVar37 = (ulonglong)*(ushort *)(&stack0x00000062 + lVar18);
                            }
                            uVar40 = (int)uVar47 + 1;
                            uVar47 = (ulonglong)uVar40;
                            puVar49 = puVar49 + 1;
                          } while ((int)uVar40 <
                                   (int)(*(uint *)(&stack0x00000064 + lVar18) >> 0xb & 7));
                          uVar50 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                        }
                        break;
                      }
                      if (*(ushort *)((ulonglong)uVar41 + *(longlong *)(&stack0x00000040 + lVar18))
                          < 0x400) break;
                      *(ushort *)(&stack0x0000003a + lVar18) =
                           *(ushort *)(&stack0x0000003a + lVar18) | 1;
                      uVar13 = (short)uVar42 - 1;
                      uVar42 = (ulonglong)uVar13;
                      *(ushort *)(&stack0x00000054 + lVar18) = uVar13;
                      if (uVar13 == 0) break;
                    }
                  }
                  if ((**(byte **)(&stack0x00000040 + lVar18) & 0x40) == 0) {
                    *(undefined4 *)(&stack0x0000005e + lVar18) = 0;
                  }
                  else {
                    *(int *)(&stack0x0000005e + lVar18) = (int)uVar50;
                    *(int *)(&stack0x0000003c + lVar18) = (int)uVar50 + 0xe;
                    *(undefined8 *)(puVar45 + -8) = 0x10088e;
                    uVar26 = func_0x(&stack0x0000003a + lVar18);
                    *(undefined8 *)(puVar45 + -8) = 0x10089d;
                    func_0x(uVar26,&stack0x00000180 + lVar18);
                    *(undefined8 *)(puVar45 + -8) = 0x1008a9;
                    iVar16 = func_0x(&stack0x00000180 + lVar18);
                    uVar50 = (ulonglong)(uint)(*(int *)(&stack0x0000003c + lVar18) + iVar16);
                    *(int *)(&stack0x0000003c + lVar18) =
                         *(int *)(&stack0x0000003c + lVar18) + iVar16;
                  }
                  if ((*(ulonglong *)(&stack0x00000056 + lVar18) != 0) &&
                     (*(ulonglong *)(&stack0x00000056 + lVar18) <
                      uVar50 + *(longlong *)(&stack0x00000040 + lVar18))) {
                    *(undefined8 *)(puVar45 + -8) = 0x1008e3;
                    cVar9 = func_0x(0x1ec08c0);
                    if (cVar9 != '\0') {
                      *(undefined8 *)(puVar45 + -8) = 0x1008ec;
                      lVar19 = func_0x();
                      if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar45 + -8) = 0x100906;
                        cVar9 = func_0x(0x1ec08c0);
                        if (cVar9 == '\0') {
                          *(undefined8 *)(puVar45 + -8) = 0x100922;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(puVar45 + 0x20) = 0;
                          *(undefined8 *)(puVar45 + -8) = 0x100946;
                          (*_DAT_)(1,0x17b02cc,0x18d03b8,0x886);
                        }
                      }
                    }
                    uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                    *(undefined8 *)(puVar45 + -8) = 0x100954;
                    func_0x(uVar26,0x12);
                    uVar50 = (ulonglong)*(uint *)(&stack0x0000003c + lVar18);
                  }
                  if (0x3f3b < (int)uVar50 - 1U) {
                    *(undefined8 *)(puVar45 + -8) = 0x10096f;
                    cVar9 = func_0x(0x1ec08c0);
                    if (cVar9 != '\0') {
                      *(undefined8 *)(puVar45 + -8) = 0x100978;
                      lVar19 = func_0x();
                      if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar45 + -8) = 0x100992;
                        cVar9 = func_0x(0x1ec08c0);
                        if (cVar9 == '\0') {
                          *(undefined8 *)(puVar45 + -8) = 0x1009ae;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(puVar45 + 0x20) = 0;
                          *(undefined8 *)(puVar45 + -8) = 0x1009d2;
                          (*_DAT_)(1,0x17b02cc,0x18d03b8,0x88b);
                        }
                      }
                    }
                    uVar26 = *(undefined8 *)(&stack0x00000040 + lVar18);
                    *(undefined8 *)(puVar45 + -8) = 0x1009e0;
                    func_0x(uVar26,5);
                  }
                }
LAB_:
                uVar48 = *(uint *)plVar43;
                uVar40 = uVar48 + 1;
                uVar41 = *(uint *)(&stack0x00000048 + lVar18);
                if (uVar41 < uVar40) {
                  *(undefined8 *)(puVar45 + -8) = 0x100a04;
                  func_0x(&stack0x0000003a + lVar18,0,uVar40 - uVar41);
                  if ((1 << (**(byte **)(&stack0x00000040 + lVar18) & 0xe) & 0x1105U) != 0) {
                    *(short *)(*(byte **)(&stack0x00000040 + lVar18) + 2) = (short)uVar40;
                  }
                  *(uint *)(&stack0x00000048 + lVar18) = uVar40;
                  uVar48 = *(uint *)plVar43;
                }
                if (*(undefined **)(&stack0x00000080 + lVar18) != (undefined *)0x0) {
                  *(undefined *)((longlong)(int)uVar48 + *(longlong *)(&stack0x00000040 + lVar18)) =
                       **(undefined **)(&stack0x00000080 + lVar18);
                }
              }
              else {
                cVar9 = **(char **)(&stack0x000000d0 + lVar18);
                uVar48 = uVar40 + 1;
                uVar41 = *(uint *)(&stack0x00000048 + lVar18);
                if (uVar41 < uVar48) {
                  *(undefined8 *)(puVar45 + -8) = 0x1002e1;
                  func_0x(&stack0x0000003a + lVar18,0,uVar48 - uVar41);
                  pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                  if ((1 << (*pbVar36 & 0xe) & 0x1105U) != 0) {
                    *(short *)(pbVar36 + 2) = (short)uVar48;
                    pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                  }
                  *(uint *)(&stack0x00000048 + lVar18) = uVar48;
                  bVar30 = *(byte *)((longlong)plVar43 + 6);
                }
                else {
                  pbVar36 = *(byte **)(&stack0x00000040 + lVar18);
                }
                if (cVar9 == '\0') {
                  pbVar36[(int)uVar40] = pbVar36[(int)uVar40] & ~(byte)(1 << (bVar30 & 7));
                }
                else {
                  pbVar36[(int)uVar40] = pbVar36[(int)uVar40] | (byte)(1 << (bVar30 & 7));
                }
              }
            }
          }
          else {
            *(undefined8 *)(puVar45 + 0x20) = 0x152b830;
            *(undefined8 *)(puVar45 + -8) = 0x10029a;
            (*_DAT_)(1,0x1931bc0,0x195e588);
          }
LAB_:
          plVar43 = plVar43 + 10;
          *(longlong **)(&stack0x00000090 + lVar18) = plVar43;
          iVar16 = *(int *)(&stack0x00000088 + lVar18);
          *(uint *)(&stack0x00000088 + lVar18) = iVar16 + 1U;
          plVar21 = *(longlong **)(&stack0x000000b0 + lVar18);
        } while (iVar16 + 1U < *(uint *)(&stack0x0000007c + lVar18));
        uVar40 = *(uint *)(&stack0x000000a0 + lVar18);
      }
      puVar49 = (ushort *)0x0;
      if (uVar40 != 0) {
        lVar19 = *(longlong *)(&stack0x000000b0 + lVar18);
        do {
          uVar47 = (ulonglong)uVar40;
          uVar41 = uVar40 - 1;
          if (*(int *)((ulonglong)uVar41 * 0x20 + 8 + lVar19) != 0) {
            *(ushort *)(&stack0x00000054 + lVar18) = (ushort)uVar40;
            iVar16 = *(int *)(&stack0x0000004c + lVar18) + 2 + uVar40 * 2;
            *(int *)(&stack0x00000050 + lVar18) = iVar16;
            *(int *)(&stack0x0000003c + lVar18) = iVar16;
            **(byte **)(&stack0x00000040 + lVar18) = **(byte **)(&stack0x00000040 + lVar18) | 0x20;
            uVar41 = *(uint *)(&stack0x0000003c + lVar18);
            if (uVar41 < 0x1f7d) {
              puVar49 = (ushort *)
                        ((ulonglong)*(uint *)(&stack0x0000004c + lVar18) +
                        *(longlong *)(&stack0x00000040 + lVar18));
              *puVar49 = (ushort)uVar40;
              uVar41 = *(uint *)(&stack0x0000003c + lVar18);
            }
            if (uVar40 != 0) {
              puVar38 = (uint *)(lVar19 + 0xc);
              do {
                puVar49 = puVar49 + 1;
                uVar50 = (ulonglong)uVar41;
                lVar19 = *(longlong *)(&stack0x00000040 + lVar18);
                uVar40 = puVar38[-1];
                uVar41 = uVar41 + uVar40;
                *(uint *)(&stack0x0000003c + lVar18) = uVar41;
                if (uVar41 < 0x1f7d) {
                  *puVar49 = (ushort)((*puVar38 & 1) << 0xf) | (ushort)uVar41 & 0x7fff;
                  uVar26 = *(undefined8 *)(puVar38 + -3);
                  *(undefined8 *)(puVar45 + -8) = 0x102088;
                  func_0x(uVar50 + lVar19,uVar40,uVar26);
                  uVar41 = *(uint *)(&stack0x0000003c + lVar18);
                }
                puVar38 = puVar38 + 8;
                uVar47 = uVar47 - 1;
              } while (uVar47 != 0);
            }
            break;
          }
          uVar40 = uVar41;
        } while (uVar41 != 0);
      }
    }
LAB_:
    lVar19 = *(longlong *)(&stack0x00000098 + lVar18);
    puVar44 = puVar45;
  }
  else {
    uVar26 = 0x1f32d78;
    if (bVar58) {
      uVar26 = 0x1f6c310;
    }
    lVar19 = *(longlong *)(&stack0x00000098 + lVar18);
    *(undefined8 *)(lVar19 + 0xa68) = uVar26;
    *(undefined8 *)(lVar19 + 0xa70) = 0;
    *(longlong *)((longlong)alStackX_8 + lVar18) = lVar19 + 0x290;
    *(undefined **)((longlong)alStackX_8 + lVar18 + -8) = &stack0x00000108 + lVar18;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar18) = 0x1f7c;
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar18) = 0x1f9e;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar18) = &stack0x000009f8 + lVar18;
    *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1025a7;
    func_0x(lVar19 + 0xa80,param_2,2);
  }
  puVar54 = (undefined8 *)0x0;
  lVar24 = *(longlong *)(&stack0x00000100 + lVar18);
  *(undefined8 *)(puVar44 + -8) = 0x101414;
  iVar16 = func_0x(lVar24);
  if (iVar16 == 0) {
    *(undefined8 *)(puVar44 + -8) = 0x101423;
    func_0x(lVar24,1);
  }
  lVar22 = *(longlong *)(lVar19 + 0xae8);
  if (lVar22 == lVar19 + 0xae0) {
LAB_:
    *(undefined4 *)(&stack0x0000007c + lVar18) = 0x75f;
    puVar44[0x20] = 5;
    uVar26 = *(undefined8 *)(lVar19 + 0x1f0);
    *(undefined8 *)(puVar44 + -8) = 0x1025d7;
    lVar22 = (*_DAT_)(0x638,uVar26,0x17ba918);
    *(longlong *)(&stack0x00000130 + lVar18) = lVar22;
    puVar23 = puVar54;
    if (lVar22 != 0) {
      *(undefined8 *)(puVar44 + -8) = 0x1025eb;
      puVar23 = (undefined8 *)func_0x(lVar22);
    }
    *(undefined8 **)(&stack0x00000090 + lVar18) = puVar23;
    uVar26 = *(undefined8 *)(lVar19 + 0x2d8);
    *(undefined8 *)(puVar44 + -8) = 0x102606;
    func_0x(puVar23,uVar26);
  }
  else {
    puVar23 = puVar54;
    if (lVar22 != 0) {
      puVar23 = (undefined8 *)(lVar22 + -0x10);
    }
    *(undefined8 **)(&stack0x00000090 + lVar18) = puVar23;
    if (puVar23 == (undefined8 *)0x0) goto LAB_;
    plVar21 = (longlong *)puVar23[3];
    lVar22 = puVar23[2];
    *(longlong **)(lVar22 + 8) = plVar21;
    *plVar21 = lVar22;
    puVar23[3] = 0;
    puVar23[2] = 0;
  }
  plVar21 = puVar23 + 2;
  puVar23[3] = *(undefined8 *)(lVar19 + 0xaf8);
  **(longlong ***)(lVar19 + 0xaf8) = plVar21;
  *(longlong **)(lVar19 + 0xaf8) = plVar21;
  *plVar21 = lVar19 + 0xaf0;
  puVar38 = *(uint **)(lVar19 + 0x108);
  uVar40 = *puVar38;
  puVar32 = *(undefined8 **)(lVar19 + 0x2e0);
  uVar41 = 0;
  if (*(int *)(puVar23 + 0xc6) == 1) {
    puVar23[5] = puVar32;
    puVar23[7] = puVar32;
    puVar23[0x20] = *(longlong *)(puVar23[6] + 0x48) + 0x28;
    *(undefined4 *)(puVar23 + 0x1e) = 2;
    if (*(int *)(*(longlong *)(puVar23[4] + 0x48) + 0x18) != 1) {
      uVar26 = *puVar32;
      *(undefined8 *)(puVar44 + -8) = 0x102696;
      func_0x(puVar23 + 0xa7,uVar26,uVar40 >> 0x1b & 1);
      lVar19 = puVar23[4];
      bVar33 = 0;
      bVar30 = bVar33;
      if (*(int *)(lVar19 + 0x40) == 3) {
        bVar30 = 8;
      }
      bVar3 = *(byte *)(puVar23 + 0xa6);
      *(byte *)(puVar23 + 0xa6) = bVar30 | bVar3 & 0xf7;
      if (*(int *)(lVar19 + 0x40) == 4) {
        bVar33 = 0x10;
      }
      bVar33 = bVar33 | bVar30 | bVar3 & 0xe7;
      *(byte *)(puVar23 + 0xa6) = bVar33;
      *(byte *)(puVar23 + 0xa6) =
           ((char)((*(int *)(*(longlong *)(lVar19 + 0x10) + 0x50) << 0x1f) >> 0x1f) << 5 ^ bVar33) &
           0x20 ^ bVar33;
      *(undefined4 *)(puVar23 + 0xa9) = *(undefined4 *)(*(longlong *)(lVar19 + 0x48) + 0x188);
      *(undefined4 *)((longlong)puVar23 + 0x54c) = *(undefined4 *)(puVar32 + 4);
    }
    *(undefined4 *)(puVar23 + 0xc6) = 2;
    lVar19 = *(longlong *)(&stack0x00000098 + lVar18);
    puVar38 = *(uint **)(lVar19 + 0x108);
  }
  else {
    lVar19 = *(longlong *)(&stack0x00000098 + lVar18);
  }
  if (((*(byte *)(*(longlong *)(**(longlong **)(puVar38 + 8) + 8) + 0x107) & 0x40) == 0) ||
     ((*puVar38 & 0x1000000) != 0)) {
    bVar30 = 0;
  }
  else {
    bVar30 = 4;
  }
  plVar21 = *(longlong **)(puVar23[5] + 8);
  *(undefined8 *)(&stack0x00000158 + lVar18) = 0;
  *(undefined4 *)(&stack0x0000007c + lVar18) = 0;
  *(short **)(&stack0x00000150 + lVar18) = psVar2;
  puVar45 = puVar44;
  if (*(int *)(*(longlong *)(lVar24 + 8) + 0x100) == 2) {
    puVar52 = (undefined2 *)(puVar44 + 0x30);
    *puVar52 = 0xffff;
    *(undefined8 *)(puVar44 + 0x38) = 0;
    *(undefined4 *)(puVar44 + 0x34) = 0;
    *(undefined8 *)(puVar44 + 0x4e) = 0;
    *(undefined8 *)(puVar44 + 0x58) = 0;
    *(undefined8 *)(puVar44 + 0x40) = 0;
    *(undefined8 *)(puVar44 + -0x48) = 0x1027a9;
    lVar24 = func_0x();
    lVar24 = -lVar24;
    puVar45 = puVar44 + lVar24 + -0xc0;
    *(undefined (*) [16])(puVar44 + lVar24 + -0x50) = ZEXT816(0);
    *(undefined (*) [16])(puVar44 + lVar24 + -0x40) = ZEXT816(0);
    *(undefined (*) [16])(puVar44 + lVar24 + -0x30) = ZEXT816(0);
    *(undefined (*) [16])(puVar44 + lVar24 + -0x20) = ZEXT816(0);
    *(undefined (*) [16])(puVar44 + lVar24 + -0x10) = ZEXT816(0);
    *(undefined (*) [16])(puVar44 + lVar24) = ZEXT816(0);
    *(undefined (*) [16])(puVar44 + lVar24 + 0x10) = ZEXT816(0);
    *(undefined8 *)(puVar44 + lVar24 + 0x20) = 0;
    *(undefined2 *)(puVar44 + lVar24 + -0x40) = 0xffff;
    *(undefined8 *)(puVar44 + lVar24 + -0x38) = 0;
    *(undefined4 *)(puVar44 + lVar24 + -0x3c) = 0;
    *(undefined8 *)(puVar44 + lVar24 + -0x22) = 0;
    *(undefined8 *)(puVar44 + lVar24 + -0x18) = 0;
    *(undefined8 *)(puVar44 + lVar24 + -0x30) = 0;
    *(undefined8 *)(puVar44 + lVar24 + -8) = 0;
    *(undefined8 *)(puVar44 + lVar24 + 0x10) = 0;
    *(undefined4 *)(puVar44 + lVar24 + 0x18) = 0;
    *(undefined2 *)(puVar44 + lVar24 + 0x22) = 0;
    *(undefined2 **)(&stack0x00000158 + lVar18) = puVar52;
    *(undefined **)(&stack0x00000160 + lVar18) = puVar44 + lVar24 + 0x30;
    *(undefined4 *)(&stack0x00000168 + lVar18) = 0x239e;
    *(undefined (**) [16])(&stack0x00000170 + lVar18) =
         (undefined (*) [16])(puVar44 + lVar24 + -0x50);
  }
  plVar43 = (longlong *)puVar23[5];
  plVar39 = (longlong *)plVar43[3];
  plVar53 = plVar43;
  if (plVar39 == (longlong *)0x0) {
    plVar39 = (longlong *)(plVar43[1] + 0x208);
    plVar43[3] = (longlong)plVar39;
    plVar53 = (longlong *)puVar23[5];
  }
  if ((*plVar39 == (ulonglong)*(uint6 *)(*plVar43 + 0x14) * 0x10000) && (*(int *)(plVar39 + 1) != 0)
     ) {
    *(undefined4 *)(&stack0x0000007c + lVar18) = 1;
    *(undefined4 *)(&stack0x00000070 + lVar18) = 0;
    iVar16 = *(int *)(puVar23 + 0xa9);
    *(int *)(&stack0x000000a0 + lVar18) = iVar16;
    if (iVar16 == 0) {
      *(undefined4 *)(&stack0x00000088 + lVar18) = *(undefined4 *)(&stack0x000000a4 + lVar18);
      *(undefined4 *)(&stack0x000000a0 + lVar18) = *(undefined4 *)(&stack0x000000a4 + lVar18);
    }
    else {
      *(undefined4 *)(&stack0x00000070 + lVar18) = 1;
      *(undefined4 *)(&stack0x00000088 + lVar18) = *(undefined4 *)((longlong)puVar23 + 0x54c);
      lVar24 = plVar53[3];
      iVar16 = *(int *)(lVar24 + 8);
      if ((iVar16 == 0) || (*(int *)(lVar24 + 0xc) != 0)) {
        puVar32 = puVar54;
        if (iVar16 != 0) goto LAB_;
      }
      else {
        puVar32 = (undefined8 *)0x2;
LAB_:
        uVar41 = (uint)puVar32;
        if (*(int *)(lVar24 + 0xc) == iVar16 + -1) {
          uVar41 = uVar41 | 1;
        }
      }
      *(uint *)(puVar23 + 0xa9) = uVar41;
      *(undefined4 *)((longlong)puVar23 + 0x54c) = *(undefined4 *)(plVar53 + 4);
    }
  }
  else {
    *(undefined4 *)(&stack0x00000088 + lVar18) = *(undefined4 *)(&stack0x000000a4 + lVar18);
    *(undefined4 *)(&stack0x00000070 + lVar18) = *(undefined4 *)(&stack0x00000108 + lVar18);
    *(undefined4 *)(&stack0x000000a0 + lVar18) = *(undefined4 *)(&stack0x000000a4 + lVar18);
  }
  *(uint *)((longlong)puVar23 + 0x634) = *(uint *)((longlong)puVar23 + 0x634) & 0xfffffffe;
  puVar32 = puVar23 + 0xa6;
  *(undefined8 **)(&stack0x000000b0 + lVar18) = puVar32;
  *(byte *)puVar32 = (*(byte *)puVar32 & 0xfa | bVar30) & 0x7f;
  *(undefined4 *)((longlong)puVar23 + 0x54c) = *(undefined4 *)(plVar53 + 4);
  if (*(int *)(puVar23[4] + 0x40) != 1) {
    pcVar4 = *(code **)(*plVar21 + 0x270);
    *(undefined8 *)(puVar45 + -8) = 0x102931;
    (*pcVar4)(plVar21);
  }
  *(byte *)((longlong)puVar23 + 0x531) = *(byte *)((longlong)puVar23 + 0x531) & 0xfb;
  lVar24 = 2;
  puVar25 = puVar32;
  puVar20 = (undefined4 *)(&stack0x00000308 + lVar18);
  do {
    uVar17 = *(undefined4 *)((longlong)puVar25 + 4);
    uVar7 = *(undefined4 *)(puVar25 + 1);
    uVar8 = *(undefined4 *)((longlong)puVar25 + 0xc);
    *puVar20 = *(undefined4 *)puVar25;
    puVar20[1] = uVar17;
    puVar20[2] = uVar7;
    puVar20[3] = uVar8;
    uVar17 = *(undefined4 *)((longlong)puVar25 + 0x14);
    uVar7 = *(undefined4 *)(puVar25 + 3);
    uVar8 = *(undefined4 *)((longlong)puVar25 + 0x1c);
    puVar20[4] = *(undefined4 *)(puVar25 + 2);
    puVar20[5] = uVar17;
    puVar20[6] = uVar7;
    puVar20[7] = uVar8;
    uVar17 = *(undefined4 *)((longlong)puVar25 + 0x24);
    uVar7 = *(undefined4 *)(puVar25 + 5);
    uVar8 = *(undefined4 *)((longlong)puVar25 + 0x2c);
    puVar20[8] = *(undefined4 *)(puVar25 + 4);
    puVar20[9] = uVar17;
    puVar20[10] = uVar7;
    puVar20[0xb] = uVar8;
    uVar17 = *(undefined4 *)((longlong)puVar25 + 0x34);
    uVar7 = *(undefined4 *)(puVar25 + 7);
    uVar8 = *(undefined4 *)((longlong)puVar25 + 0x3c);
    puVar20[0xc] = *(undefined4 *)(puVar25 + 6);
    puVar20[0xd] = uVar17;
    puVar20[0xe] = uVar7;
    puVar20[0xf] = uVar8;
    uVar17 = *(undefined4 *)((longlong)puVar25 + 0x44);
    uVar7 = *(undefined4 *)(puVar25 + 9);
    uVar8 = *(undefined4 *)((longlong)puVar25 + 0x4c);
    puVar20[0x10] = *(undefined4 *)(puVar25 + 8);
    puVar20[0x11] = uVar17;
    puVar20[0x12] = uVar7;
    puVar20[0x13] = uVar8;
    uVar17 = *(undefined4 *)((longlong)puVar25 + 0x54);
    uVar7 = *(undefined4 *)(puVar25 + 0xb);
    uVar8 = *(undefined4 *)((longlong)puVar25 + 0x5c);
    puVar20[0x14] = *(undefined4 *)(puVar25 + 10);
    puVar20[0x15] = uVar17;
    puVar20[0x16] = uVar7;
    puVar20[0x17] = uVar8;
    uVar17 = *(undefined4 *)((longlong)puVar25 + 100);
    uVar7 = *(undefined4 *)(puVar25 + 0xd);
    uVar8 = *(undefined4 *)((longlong)puVar25 + 0x6c);
    puVar20[0x18] = *(undefined4 *)(puVar25 + 0xc);
    puVar20[0x19] = uVar17;
    puVar20[0x1a] = uVar7;
    puVar20[0x1b] = uVar8;
    uVar17 = *(undefined4 *)((longlong)puVar25 + 0x74);
    uVar7 = *(undefined4 *)(puVar25 + 0xf);
    uVar8 = *(undefined4 *)((longlong)puVar25 + 0x7c);
    puVar20[0x1c] = *(undefined4 *)(puVar25 + 0xe);
    puVar20[0x1d] = uVar17;
    puVar20[0x1e] = uVar7;
    puVar20[0x1f] = uVar8;
    puVar25 = puVar25 + 0x10;
    lVar24 = lVar24 + -1;
    puVar20 = puVar20 + 0x20;
  } while (lVar24 != 0);
  pcVar4 = *(code **)(*plVar21 + 0x28);
  *(undefined8 *)(puVar45 + -8) = 0x1029ab;
  cVar9 = (*pcVar4)(plVar21);
  puVar25 = (undefined8 *)(lVar19 + 0xa40);
  if (cVar9 != '\0') {
    puVar25 = puVar54;
  }
  *(undefined8 **)(&stack0x00000080 + lVar18) = puVar25;
  plVar21 = puVar23 + 6;
  *(longlong **)(&stack0x000000a8 + lVar18) = plVar21;
  bVar30 = (&stack0x00000309)[lVar18];
  if ((puVar25 != (undefined8 *)0x0) &&
     (((*(int *)(puVar25 + 1) != 0 || (*(short *)((longlong)puVar25 + 0xc) != 0)) &&
      ((bVar30 & 4) == 0)))) {
    puVar54 = (undefined8 *)*plVar21;
    *(undefined **)(puVar45 + 0x20) = &stack0x00000230 + lVar18;
    uVar26 = *puVar54;
    *(undefined8 *)(puVar45 + -8) = 0x102a14;
    iVar16 = func_0x(uVar26,puVar25,3,2);
    if (iVar16 != 0) {
      puVar20 = (undefined4 *)(&stack0x00000308 + lVar18);
      lVar19 = 2;
      puVar29 = (undefined4 *)(&stack0x00000408 + lVar18);
      do {
        uVar17 = puVar20[1];
        uVar7 = puVar20[2];
        uVar8 = puVar20[3];
        *puVar29 = *puVar20;
        puVar29[1] = uVar17;
        puVar29[2] = uVar7;
        puVar29[3] = uVar8;
        uVar17 = puVar20[5];
        uVar7 = puVar20[6];
        uVar8 = puVar20[7];
        puVar29[4] = puVar20[4];
        puVar29[5] = uVar17;
        puVar29[6] = uVar7;
        puVar29[7] = uVar8;
        uVar17 = puVar20[9];
        uVar7 = puVar20[10];
        uVar8 = puVar20[0xb];
        puVar29[8] = puVar20[8];
        puVar29[9] = uVar17;
        puVar29[10] = uVar7;
        puVar29[0xb] = uVar8;
        uVar17 = puVar20[0xd];
        uVar7 = puVar20[0xe];
        uVar8 = puVar20[0xf];
        puVar29[0xc] = puVar20[0xc];
        puVar29[0xd] = uVar17;
        puVar29[0xe] = uVar7;
        puVar29[0xf] = uVar8;
        uVar17 = puVar20[0x11];
        uVar7 = puVar20[0x12];
        uVar8 = puVar20[0x13];
        puVar29[0x10] = puVar20[0x10];
        puVar29[0x11] = uVar17;
        puVar29[0x12] = uVar7;
        puVar29[0x13] = uVar8;
        uVar17 = puVar20[0x15];
        uVar7 = puVar20[0x16];
        uVar8 = puVar20[0x17];
        puVar29[0x14] = puVar20[0x14];
        puVar29[0x15] = uVar17;
        puVar29[0x16] = uVar7;
        puVar29[0x17] = uVar8;
        uVar17 = puVar20[0x19];
        uVar7 = puVar20[0x1a];
        uVar8 = puVar20[0x1b];
        puVar29[0x18] = puVar20[0x18];
        puVar29[0x19] = uVar17;
        puVar29[0x1a] = uVar7;
        puVar29[0x1b] = uVar8;
        uVar17 = puVar20[0x1d];
        uVar7 = puVar20[0x1e];
        uVar8 = puVar20[0x1f];
        puVar29[0x1c] = puVar20[0x1c];
        puVar29[0x1d] = uVar17;
        puVar29[0x1e] = uVar7;
        puVar29[0x1f] = uVar8;
        puVar20 = puVar20 + 0x20;
        lVar19 = lVar19 + -1;
        puVar29 = puVar29 + 0x20;
      } while (lVar19 != 0);
      *(undefined4 *)(puVar45 + 0x30) = 0;
      *(undefined **)(puVar45 + 0x28) = &stack0x00000408 + lVar18;
      *(undefined8 *)(puVar45 + 0x20) = 0;
      *(undefined8 *)(puVar45 + -8) = 0x102ab1;
      func_0x(plVar21,&stack0x00000230 + lVar18,&stack0x00000150 + lVar18,0);
    }
  }
  if (*(int *)(puVar23 + 0x1e) != 4) {
    if ((bVar30 & 4) == 0) {
      *(undefined4 *)(&stack0x00000270 + lVar18) = 0;
      (&stack0x00000280)[lVar18] = 0;
      *(undefined8 *)(puVar45 + -8) = 0x102ae2;
      func_0x(&stack0x00000818 + lVar18);
      *(undefined8 *)(&stack0x000002cc + lVar18) = 0;
      *(undefined4 *)(&stack0x000002dc + lVar18) = 0;
      plVar43 = (longlong *)puVar23[7];
      lVar19 = *plVar43;
      *(longlong *)(&stack0x00000130 + lVar18) = lVar19;
      *(longlong *)(&stack0x00000128 + lVar18) = *(longlong *)(lVar19 + 8) + 0x3c0;
      plVar43 = (longlong *)plVar43[1];
      *(longlong **)(&stack0x00000118 + lVar18) = plVar43;
      pcVar4 = *(code **)(*plVar43 + 0x58);
      *(undefined8 *)(puVar45 + -8) = 0x102b28;
      (*pcVar4)(plVar43);
      (&stack0x00000816)[lVar18] = 1;
      (&stack0x00000138)[lVar18] = (&stack0x00000138)[lVar18] & 0xfc;
      *(undefined8 *)(puVar45 + -8) = 0x102b42;
      func_0x(&stack0x00000140 + lVar18);
      *(undefined4 *)(&stack0x00000140 + lVar18) = *(undefined4 *)(&stack0x00000310 + lVar18);
      *(undefined4 *)(&stack0x00000144 + lVar18) = *(undefined4 *)(&stack0x00000314 + lVar18);
      *(undefined4 *)(&stack0x00000148 + lVar18) = *(undefined4 *)(&stack0x00000318 + lVar18);
      *(undefined4 *)(&stack0x0000014c + lVar18) = *(undefined4 *)(&stack0x0000031c + lVar18);
      (&stack0x00000138)[lVar18] =
           (byte)(&stack0x00000308)[lVar18] >> 6 & 2 | (&stack0x00000308)[lVar18] & 1 |
           (&stack0x00000138)[lVar18] & 0xfc;
      *(undefined4 *)(&stack0x000000d8 + lVar18) = *(undefined4 *)(&stack0x00000138 + lVar18);
      *(undefined4 *)(&stack0x000000dc + lVar18) = *(undefined4 *)(&stack0x0000013c + lVar18);
      *(undefined4 *)(&stack0x000000e0 + lVar18) = *(undefined4 *)(&stack0x00000140 + lVar18);
      *(undefined4 *)(&stack0x000000e4 + lVar18) = *(undefined4 *)(&stack0x00000144 + lVar18);
      *(undefined4 *)(&stack0x000000f0 + lVar18) = *(undefined4 *)(&stack0x00000318 + lVar18);
      *(undefined4 *)(&stack0x000000f4 + lVar18) = *(undefined4 *)(&stack0x0000031c + lVar18);
      psVar5 = *(short **)(&stack0x00000150 + lVar18);
      *(short **)(&stack0x000001a0 + lVar18) = psVar5;
      puVar49 = (ushort *)(psVar5 + 1);
      if (*psVar5 == 0) {
        uVar40 = *(uint *)(psVar5 + 2);
        if (uVar40 == 0) {
          iVar16 = 0;
          *puVar49 = 0;
          uVar40 = *(uint *)(psVar5 + 8);
          uVar47 = (ulonglong)uVar40;
          *(uint *)(psVar5 + 10) = uVar40;
          pbVar36 = *(byte **)(psVar5 + 4);
          bVar30 = *pbVar36;
          if ((bVar30 & 0x10) != 0) {
            uVar40 = uVar40 + 2 + (*(ushort *)(pbVar36 + uVar47) + 7 >> 3);
            uVar47 = (ulonglong)uVar40;
            *(uint *)(psVar5 + 10) = uVar40;
            bVar30 = *pbVar36;
          }
          if ((bVar30 & 0x20) == 0) {
            *(int *)(psVar5 + 2) = (int)uVar47;
            psVar5[0xe] = 0;
            *(undefined4 *)(psVar5 + 0xc) = *(undefined4 *)(psVar5 + 10);
          }
          else {
            puVar55 = (ushort *)(pbVar36 + uVar47);
            uVar13 = *puVar55;
            psVar5[0xe] = uVar13;
            if (uVar13 == 0) {
              *(undefined8 *)(puVar45 + -8) = 0x102c17;
              cVar9 = func_0x(0x1ec08c0);
              if (cVar9 != '\0') {
                *(undefined8 *)(puVar45 + -8) = 0x102c20;
                lVar19 = func_0x();
                if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar45 + -8) = 0x102c3a;
                  cVar9 = func_0x(0x1ec08c0);
                  if (cVar9 == '\0') {
                    *(undefined8 *)(puVar45 + -8) = 0x102c56;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar45 + 0x20) = 0;
                    *(undefined8 *)(puVar45 + -8) = 0x102c7c;
                    (*_DAT_)(1,0x17b02cc,0x18d03b8,0x80f);
                  }
                }
              }
              uVar26 = *(undefined8 *)(psVar5 + 4);
              *(undefined8 *)(puVar45 + -8) = 0x102c8a;
              func_0x(uVar26,3);
              uVar13 = psVar5[0xe];
            }
            uVar40 = *(int *)(psVar5 + 10) + 2 + (uint)uVar13 * 2;
            *(uint *)(psVar5 + 0xc) = uVar40;
            if (0x1f9e < uVar40) {
              *(undefined8 *)(puVar45 + -8) = 0x102cb1;
              cVar9 = func_0x(0x1ec08c0);
              if (cVar9 != '\0') {
                *(undefined8 *)(puVar45 + -8) = 0x102cba;
                lVar19 = func_0x();
                if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar45 + -8) = 0x102cd4;
                  cVar9 = func_0x(0x1ec08c0);
                  if (cVar9 == '\0') {
                    *(undefined8 *)(puVar45 + -8) = 0x102cf0;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar45 + 0x20) = 0;
                    *(undefined8 *)(puVar45 + -8) = 0x102d16;
                    (*_DAT_)(1,0x17b02cc,0x18d03b8,0x816);
                  }
                }
              }
              uVar26 = *(undefined8 *)(psVar5 + 4);
              *(undefined8 *)(puVar45 + -8) = 0x102d24;
              func_0x(uVar26);
            }
            uVar13 = puVar55[(ushort)psVar5[0xe]];
            *(uint *)(psVar5 + 2) = uVar13 & 0x7fff;
            uVar40 = *(uint *)(psVar5 + 0xc);
            if ((uVar13 & 0x7fff) < uVar40) {
              *(undefined8 *)(puVar45 + -8) = 0x102d50;
              cVar9 = func_0x(0x1ec08c0);
              if (cVar9 != '\0') {
                *(undefined8 *)(puVar45 + -8) = 0x102d59;
                lVar19 = func_0x();
                if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar45 + -8) = 0x102d73;
                  cVar9 = func_0x(0x1ec08c0);
                  if (cVar9 == '\0') {
                    *(undefined8 *)(puVar45 + -8) = 0x102d8f;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar45 + 0x20) = 0;
                    *(undefined8 *)(puVar45 + -8) = 0x102db5;
                    (*_DAT_)(1,0x17b02cc,0x18d03b8,0x81d);
                  }
                }
              }
              uVar26 = *(undefined8 *)(psVar5 + 4);
              *(undefined8 *)(puVar45 + -8) = 0x102dc3;
              func_0x(uVar26);
              uVar40 = *(uint *)(psVar5 + 0xc);
            }
            uVar13 = psVar5[0xe];
            puVar6 = puVar55;
            if (uVar13 != 0) {
              do {
                uVar41 = puVar6[1] & 0x7fff;
                if ((uVar41 < uVar40) || (*(uint *)(psVar5 + 2) < uVar41)) {
                  *(undefined8 *)(puVar45 + -8) = 0x102e0f;
                  cVar9 = func_0x(0x1ec08c0);
                  if (cVar9 != '\0') {
                    *(undefined8 *)(puVar45 + -8) = 0x102e18;
                    lVar19 = func_0x();
                    if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar45 + -8) = 0x102e32;
                      cVar9 = func_0x(0x1ec08c0);
                      if (cVar9 == '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x102e4e;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar45 + 0x20) = 0;
                        *(undefined8 *)(puVar45 + -8) = 0x102e72;
                        (*_DAT_)(1,0x17b02cc,0x18d03b8,0x82a);
                      }
                    }
                  }
                  uVar26 = *(undefined8 *)(psVar5 + 4);
                  *(undefined8 *)(puVar45 + -8) = 0x102e80;
                  func_0x(uVar26,4);
                }
                iVar16 = iVar16 + 1;
                uVar13 = psVar5[0xe];
                uVar40 = uVar41;
                puVar6 = puVar6 + 1;
              } while (iVar16 < (int)(uint)uVar13);
              plVar43 = *(longlong **)(&stack0x00000118 + lVar18);
              plVar21 = *(longlong **)(&stack0x000000a8 + lVar18);
            }
            uVar40 = (uint)uVar13;
            if ((short)puVar55[(ulonglong)(uVar40 - 1) + 1] < 0) {
              do {
                lVar19 = *(longlong *)(psVar5 + 4);
                uVar41 = *(ushort *)
                          ((ulonglong)*(uint *)(psVar5 + 10) + lVar19 + (ulonglong)uVar40 * 2) &
                         0x7fff;
                if (uVar40 == 1) {
                  uVar48 = *(uint *)(psVar5 + 0xc);
                  uVar47 = (ulonglong)uVar48;
LAB_:
                  if ((uVar41 < (uint)uVar47) || (uVar40 = *(uint *)(psVar5 + 2), uVar40 < uVar41))
                  goto LAB_;
                }
                else {
                  uVar40 = *(ushort *)
                            ((ulonglong)*(uint *)(psVar5 + 10) + lVar19 + -2 + (ulonglong)uVar40 * 2
                            ) & 0x7fff;
                  uVar47 = (ulonglong)uVar40;
                  uVar48 = *(uint *)(psVar5 + 0xc);
                  if (uVar48 <= uVar40) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar45 + -8) = 0x102f09;
                  func_0x(lVar19,7);
                  uVar48 = *(uint *)(psVar5 + 0xc);
                  uVar40 = *(uint *)(psVar5 + 2);
                  lVar19 = *(longlong *)(psVar5 + 4);
                }
                uVar31 = (uint)uVar47;
                if ((uVar31 < uVar48) || (uVar40 < uVar31)) goto LAB_;
                if (*(ushort *)(uVar47 + lVar19) == 5) {
                  *puVar49 = *puVar49 | 2;
                  psVar5[0xe] = psVar5[0xe] + -1;
                  uVar50 = uVar47 & 0xffff;
                  psVar5[0x15] = (short)uVar47;
                  uVar47 = *(ulonglong *)(psVar5 + 4);
                  uVar13 = psVar5[0x16] & 0xc7ffU;
                  if ((*(ushort *)(uVar50 + 2 + uVar47) >> 0xe & 1) != 0) {
                    uVar13 = *(ushort *)(uVar50 + 2 + uVar47) & 0x3800 | psVar5[0x16] & 0xc7ffU;
                  }
                  psVar5[0x16] = uVar13;
                  uVar14 = (uVar13 ^ *(ushort *)(uVar50 + 2 + uVar47)) & 0x7ff ^ uVar13;
                  psVar5[0x16] = uVar14;
                  uVar42 = (ulonglong)(ushort)psVar5[0x15];
                  uVar50 = uVar42 + 4 +
                           (ulonglong)((uVar14 & 0x7ff) * 2) + uVar47 + (uVar13 >> 0xb & 7) * 2;
                  if (uVar50 < uVar42 + uVar47) {
                    *(undefined8 *)(puVar45 + -8) = 0x103053;
                    func_0x(uVar42 + uVar47,0x19);
                    uVar14 = psVar5[0x16];
                    uVar42 = (ulonglong)(ushort)psVar5[0x15];
                    uVar47 = (ulonglong)*(uint *)(psVar5 + 4);
                  }
                  if (uVar41 - uVar31 <
                      (((uVar14 & 0x7ff) * 2 - (int)uVar42) - (int)uVar47) + (int)uVar50) {
                    lVar19 = *(longlong *)(psVar5 + 4);
                    *(undefined8 *)(puVar45 + -8) = 0x10308b;
                    func_0x(uVar42 + lVar19,0x19);
                    uVar14 = psVar5[0x16];
                  }
                  if ((uVar14 & 0x3800) != 0) {
                    puVar55 = (ushort *)
                              (*(longlong *)(psVar5 + 4) + 4 + (ulonglong)(ushort)psVar5[0x15]);
                    iVar16 = 0;
                    if ((uVar14 & 0x3800) != 0) {
                      do {
                        if ((uVar14 & 0x7ff) < (*puVar55 & 0x7ff)) {
                          uVar13 = psVar5[0x15];
                          lVar19 = *(longlong *)(psVar5 + 4);
                          *(undefined8 *)(puVar45 + -8) = 0x1030f7;
                          func_0x((ulonglong)uVar13 + lVar19,0x1a);
                          uVar14 = psVar5[0x16];
                        }
                        iVar16 = iVar16 + 1;
                        puVar55 = puVar55 + 1;
                      } while (iVar16 < (int)(uVar14 >> 0xb & 7));
                    }
                  }
                  break;
                }
                if (*(ushort *)(uVar47 + lVar19) < 0x400) break;
                *puVar49 = *puVar49 | 1;
                uVar13 = psVar5[0xe] - 1;
                psVar5[0xe] = uVar13;
                if ((uVar13 == 0) ||
                   (uVar40 = (uint)uVar13, -1 < (short)puVar55[(ulonglong)(uVar13 - 1) + 1])) break;
              } while( true );
            }
          }
          if ((**(byte **)(psVar5 + 4) & 0x40) == 0) {
            *(undefined4 *)(psVar5 + 0x13) = 0;
          }
          else {
            *(undefined4 *)(psVar5 + 0x13) = *(undefined4 *)(psVar5 + 2);
            *(int *)(psVar5 + 2) = *(int *)(psVar5 + 2) + 0xe;
            *(undefined8 *)(puVar45 + -8) = 0x102f8d;
            uVar26 = func_0x(puVar49);
            *(undefined8 *)(puVar45 + -8) = 0x102f9c;
            func_0x(uVar26,&stack0x00000198 + lVar18);
            *(undefined8 *)(puVar45 + -8) = 0x102fa8;
            iVar16 = func_0x(&stack0x00000198 + lVar18);
            *(int *)(psVar5 + 2) = *(int *)(psVar5 + 2) + iVar16;
          }
          uVar40 = *(uint *)(psVar5 + 2);
          if ((*(ulonglong *)(psVar5 + 0xf) != 0) &&
             (*(ulonglong *)(psVar5 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar5 + 4))) {
            *(undefined8 *)(puVar45 + -8) = 0x10315a;
            cVar9 = func_0x(0x1ec08c0);
            if (cVar9 != '\0') {
              *(undefined8 *)(puVar45 + -8) = 0x103163;
              lVar19 = func_0x();
              if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                *(undefined8 *)(puVar45 + -8) = 0x10317d;
                cVar9 = func_0x(0x1ec08c0);
                if (cVar9 == '\0') {
                  *(undefined8 *)(puVar45 + -8) = 0x103199;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar45 + 0x20) = 0;
                  *(undefined8 *)(puVar45 + -8) = 0x1031c3;
                  (*_DAT_)(1,0x17b02cc,0x18d03b8,0x886);
                }
              }
            }
            uVar26 = *(undefined8 *)(psVar5 + 4);
            *(undefined8 *)(puVar45 + -8) = 0x1031d1;
            func_0x(uVar26,0x12);
            uVar40 = *(uint *)(psVar5 + 2);
          }
          if ((uVar40 == 0) || (0x3f3c < uVar40)) {
            *(undefined8 *)(puVar45 + -8) = 0x1031f3;
            cVar9 = func_0x(0x1ec08c0);
            if (cVar9 != '\0') {
              *(undefined8 *)(puVar45 + -8) = 0x1031fc;
              lVar19 = func_0x();
              if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                *(undefined8 *)(puVar45 + -8) = 0x103216;
                cVar9 = func_0x(0x1ec08c0);
                if (cVar9 == '\0') {
                  *(undefined8 *)(puVar45 + -8) = 0x103232;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar45 + 0x20) = 0;
                  *(undefined8 *)(puVar45 + -8) = 0x10325c;
                  (*_DAT_)(1,0x17b02cc,0x18d03b8,0x88b);
                }
              }
            }
            uVar26 = *(undefined8 *)(psVar5 + 4);
            *(undefined8 *)(puVar45 + -8) = 0x10326a;
            func_0x(uVar26,5);
            uVar40 = *(uint *)(psVar5 + 2);
          }
        }
LAB_:
        if (uVar40 < 9) {
          bVar30 = **(byte **)(psVar5 + 4);
          if (((bVar30 & 0xe) != 0) && ((bVar30 & 0xe) != 0xc)) goto LAB_;
          uVar40 = 9;
        }
        else {
LAB_:
          bVar30 = **(byte **)(psVar5 + 4);
        }
        if ((bVar30 & 0x40) != 0) {
          uVar40 = *(uint *)(psVar5 + 0x13);
        }
        psVar56 = *(short **)(&stack0x000001a0 + lVar18);
      }
      else {
        if (*(int *)(psVar5 + 2) == 0) {
          *(undefined8 *)(puVar45 + -8) = 0x1032b5;
          func_0x(puVar49);
        }
        *(undefined8 *)(puVar45 + -8) = 0x1032bd;
        uVar40 = func_0x(puVar49);
        psVar56 = psVar5;
        if ((**(byte **)(psVar5 + 4) & 2) != 0) {
          uVar40 = *(uint *)(psVar5 + 0x18);
        }
      }
      pcVar4 = *(code **)*plVar43;
      *(undefined8 *)(puVar45 + -8) = 0x1032d5;
      cVar9 = (*pcVar4)(plVar43);
      if (cVar9 == '\0') {
        if (((&stack0x000000d8)[lVar18] & 1) == 0) {
LAB_:
          lVar19 = plVar43[0x1a];
          if (((&stack0x000000e0)[lVar18] & 1) != 0) goto LAB_;
          pcVar4 = *(code **)*plVar43;
          *(undefined8 *)(puVar45 + -8) = 0x1039cd;
          cVar9 = (*pcVar4)(plVar43);
          if (cVar9 != '\0') goto LAB_;
          pcVar4 = *(code **)(*plVar43 + 0x88);
          *(undefined8 *)(puVar45 + -8) = 0x1039e1;
          cVar9 = (*pcVar4)(plVar43);
          if (cVar9 != '\0') {
            if ((&stack0x000000e1)[lVar18] != '\0') goto LAB_;
            if (lVar19 == 0) {
              pcVar4 = *(code **)(*plVar43 + 0x18);
              *(undefined8 *)(puVar45 + -8) = 0x103a04;
              cVar9 = (*pcVar4)(plVar43);
              if (cVar9 == '\0') goto LAB_;
            }
            if ((*(byte *)(plVar43 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar43 + 0x4a) & 0x5a) == 0) {
                if ((*(byte *)(plVar43 + 0x43) & 1) != 0) {
                  if (plVar43[0x1a] == 0) {
                    pcVar4 = *(code **)(*plVar43 + 0x88);
                    *(undefined8 *)(puVar45 + -8) = 0x103a48;
                    cVar9 = (*pcVar4)(plVar43);
                    if (cVar9 != '\0') {
                      pcVar4 = *(code **)(*plVar43 + 0x18);
                      *(undefined8 *)(puVar45 + -8) = 0x103a55;
                      cVar9 = (*pcVar4)(plVar43);
                      if (cVar9 == '\0') {
                        *(byte *)(plVar43 + 0x4a) = *(byte *)(plVar43 + 0x4a) | 4;
                        goto LAB_;
                      }
                    }
                  }
                  *(undefined8 *)(puVar45 + -8) = 0x103a6e;
                  iVar16 = func_0x(plVar43);
                  if (iVar16 == 0) {
                    pcVar4 = *(code **)(*plVar43 + 0x270);
                    *(undefined8 *)(puVar45 + -8) = 0x103a7e;
                    (*pcVar4)(plVar43);
                  }
                  if ((*(byte *)(plVar43 + 0x43) & 4) == 0) {
                    if ((*(byte *)(plVar43 + 0x4a) & 0x52) == 2) {
                      lVar24 = plVar43[0x1a];
                      *(undefined8 *)(puVar45 + -8) = 0x103ab8;
                      cVar9 = func_0x(lVar24);
                      if (((cVar9 != '\0') && (*(char *)(plVar43[0x1a] + 0x130) == '\0')) &&
                         (*(undefined *)(plVar43[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                        *(undefined8 *)(puVar45 + 0x20) = 0;
                        *(undefined8 *)(puVar45 + -8) = 0x103b01;
                        func_0x(0x1ec1000,0x1c,0x10,1);
                      }
                    }
                    uVar41 = (uint)((*(byte *)(plVar43 + 0x4a) & 0x5a) != 0);
                  }
                  else {
                    pcVar4 = *(code **)(*plVar43 + 0x1e8);
                    *(undefined8 *)(puVar45 + -8) = 0x103a94;
                    uVar26 = (*pcVar4)(plVar43);
                    *(undefined8 *)(puVar45 + -8) = 0x103a9c;
                    uVar41 = func_0x(uVar26);
                  }
                  if (uVar41 != 0) goto LAB_;
                }
              }
              else {
LAB_:
                if (((*(byte *)(plVar43 + 0x4a) & 0x40) != 0) &&
                   ((&stack0x000000e2)[lVar18] != '\0')) goto LAB_;
              }
            }
          }
LAB_:
          if (((&stack0x000000e0)[lVar18] & 0x1c) == 0) {
            lVar24 = *(longlong *)(&stack0x000000e8 + lVar18);
            if (lVar24 != 0) {
              iVar16 = *(int *)(*(longlong *)(lVar24 + 8) + 0x68);
              bVar58 = iVar16 < 0;
              if (bVar58) {
                *(undefined8 *)(puVar45 + 0x20) = 0;
                *(undefined8 *)(puVar45 + -8) = 0x103b7b;
                (*_DAT_)(1,0x195f2a8,0x195d958,0xc9d);
                iVar16 = *(int *)(*(longlong *)(lVar24 + 8) + 0x68);
                bVar58 = iVar16 < 0;
              }
              if (((iVar16 != 0 && !bVar58) &&
                  (iVar16 = *(int *)(*(longlong *)(*(longlong *)(&stack0x000000e8 + lVar18) + 8) +
                                    0x100), iVar16 != 0)) && (1 < iVar16 - 3U)) {
                *(undefined8 *)(puVar45 + 0x20) = 0;
                *(undefined8 *)(puVar45 + -8) = 0x103bca;
                (*_DAT_)(1,0x195f2d0,0x195f320,0x116);
              }
              uVar26 = *(undefined8 *)(&stack0x000000e8 + lVar18);
              *(undefined8 *)(puVar45 + -8) = 0x103bd6;
              iVar16 = func_0x(uVar26);
              if ((((iVar16 != 0) &&
                   ((*(byte *)(*(longlong *)(*(longlong *)(&stack0x000000e8 + lVar18) + 8) + 0x109)
                    & 1) == 0)) &&
                  (iVar16 = *(int *)(*(longlong *)(*(longlong *)(&stack0x000000e8 + lVar18) + 8) +
                                    0x100), iVar16 != 0)) && (1 < iVar16 - 3U)) {
                *(undefined8 *)(puVar45 + 0x20) = 0;
                *(undefined8 *)(puVar45 + -8) = 0x103c28;
                (*_DAT_)(1,0x195f350,0x195f320,0x119);
              }
            }
            if ((lVar19 != 0) && ((0 < *(int *)(lVar19 + 0x78) || (0 < *(int *)(lVar19 + 0x74)))))
            goto LAB_;
            if ((*(byte *)(plVar43 + 0x4a) & 4) != 0) goto LAB_;
            if ((*(byte *)(plVar43 + 0x4a) & 0x5a) != 0) goto LAB_;
            if ((*(byte *)(plVar43 + 0x43) & 1) == 0) goto LAB_;
            if (plVar43[0x1a] != 0) {
LAB_:
              *(undefined8 *)(puVar45 + -8) = 0x103c9a;
              iVar16 = func_0x(plVar43);
              if (iVar16 == 0) {
                pcVar4 = *(code **)(*plVar43 + 0x270);
                *(undefined8 *)(puVar45 + -8) = 0x103caa;
                (*pcVar4)(plVar43);
              }
              if ((*(byte *)(plVar43 + 0x43) & 4) == 0) {
                if ((*(byte *)(plVar43 + 0x4a) & 0x52) == 2) {
                  lVar24 = plVar43[0x1a];
                  *(undefined8 *)(puVar45 + -8) = 0x103ce4;
                  cVar9 = func_0x(lVar24);
                  if (((cVar9 != '\0') && (*(char *)(plVar43[0x1a] + 0x130) == '\0')) &&
                     (*(undefined *)(plVar43[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                    *(undefined8 *)(puVar45 + 0x20) = 0;
                    *(undefined8 *)(puVar45 + -8) = 0x103d2d;
                    func_0x(0x1ec1000,0x1c,0x10,1);
                  }
                }
                uVar41 = (uint)((*(byte *)(plVar43 + 0x4a) & 0x5a) != 0);
              }
              else {
                pcVar4 = *(code **)(*plVar43 + 0x1e8);
                *(undefined8 *)(puVar45 + -8) = 0x103cc0;
                uVar26 = (*pcVar4)(plVar43);
                *(undefined8 *)(puVar45 + -8) = 0x103cc8;
                uVar41 = func_0x(uVar26);
              }
              if (uVar41 == 0) goto LAB_;
              goto LAB_;
            }
            pcVar4 = *(code **)(*plVar43 + 0x88);
            *(undefined8 *)(puVar45 + -8) = 0x103c7d;
            cVar9 = (*pcVar4)(plVar43);
            if (cVar9 == '\0') goto LAB_;
            pcVar4 = *(code **)(*plVar43 + 0x18);
            *(undefined8 *)(puVar45 + -8) = 0x103c8a;
            cVar9 = (*pcVar4)(plVar43);
            if (cVar9 != '\0') goto LAB_;
LAB_:
            *(byte *)(plVar43 + 0x4a) = *(byte *)(plVar43 + 0x4a) | 4;
            goto LAB_;
          }
LAB_:
          if (lVar19 != 0) {
LAB_:
            if (((&stack0x000000e0)[lVar18] & 0x1c) == 0) {
              lVar24 = *(longlong *)(&stack0x000000e8 + lVar18);
              if (lVar24 != 0) {
                iVar16 = *(int *)(*(longlong *)(lVar24 + 8) + 0x68);
                bVar58 = iVar16 < 0;
                if (bVar58) {
                  *(undefined8 *)(puVar45 + 0x20) = 0;
                  *(undefined8 *)(puVar45 + -8) = 0x103d9d;
                  (*_DAT_)(1,0x195f2a8,0x195d958,0xc9d);
                  iVar16 = *(int *)(*(longlong *)(lVar24 + 8) + 0x68);
                  bVar58 = iVar16 < 0;
                }
                if (((iVar16 != 0 && !bVar58) &&
                    (iVar16 = *(int *)(*(longlong *)(*(longlong *)(&stack0x000000e8 + lVar18) + 8) +
                                      0x100), iVar16 != 0)) && (1 < iVar16 - 3U)) {
                  *(undefined8 *)(puVar45 + 0x20) = 0;
                  *(undefined8 *)(puVar45 + -8) = 0x103dec;
                  (*_DAT_)(1,0x195f2d0,0x195f320,0x116);
                }
                uVar26 = *(undefined8 *)(&stack0x000000e8 + lVar18);
                *(undefined8 *)(puVar45 + -8) = 0x103df8;
                iVar16 = func_0x(uVar26);
                if (((iVar16 != 0) &&
                    ((*(byte *)(*(longlong *)(*(longlong *)(&stack0x000000e8 + lVar18) + 8) + 0x109)
                     & 1) == 0)) &&
                   ((iVar16 = *(int *)(*(longlong *)(*(longlong *)(&stack0x000000e8 + lVar18) + 8) +
                                      0x100), iVar16 != 0 && (1 < iVar16 - 3U)))) {
                  *(undefined8 *)(puVar45 + 0x20) = 0;
                  *(undefined8 *)(puVar45 + -8) = 0x103e4a;
                  (*_DAT_)(1,0x195f350,0x195f320,0x119);
                }
              }
              if ((*(int *)(lVar19 + 0x78) < 1) && (*(int *)(lVar19 + 0x74) < 1)) {
                if ((*(byte *)(plVar43 + 0x4a) & 4) == 0) {
                  if ((*(byte *)(plVar43 + 0x4a) & 0x5a) == 0) {
                    if ((*(byte *)(plVar43 + 0x43) & 1) != 0) {
                      if (plVar43[0x1a] == 0) {
                        pcVar4 = *(code **)(*plVar43 + 0x88);
                        *(undefined8 *)(puVar45 + -8) = 0x103e9a;
                        cVar9 = (*pcVar4)(plVar43);
                        if (cVar9 != '\0') {
                          pcVar4 = *(code **)(*plVar43 + 0x18);
                          *(undefined8 *)(puVar45 + -8) = 0x103ea7;
                          cVar9 = (*pcVar4)(plVar43);
                          if (cVar9 == '\0') {
                            *(byte *)(plVar43 + 0x4a) = *(byte *)(plVar43 + 0x4a) | 4;
                            goto LAB_;
                          }
                        }
                      }
                      *(undefined8 *)(puVar45 + -8) = 0x103ec0;
                      iVar16 = func_0x(plVar43);
                      if (iVar16 == 0) {
                        pcVar4 = *(code **)(*plVar43 + 0x270);
                        *(undefined8 *)(puVar45 + -8) = 0x103ed0;
                        (*pcVar4)(plVar43);
                      }
                      if ((*(byte *)(plVar43 + 0x43) & 4) == 0) {
                        if ((*(byte *)(plVar43 + 0x4a) & 0x52) == 2) {
                          lVar24 = plVar43[0x1a];
                          *(undefined8 *)(puVar45 + -8) = 0x103f0a;
                          cVar9 = func_0x(lVar24);
                          if (((cVar9 != '\0') && (*(char *)(plVar43[0x1a] + 0x130) == '\0')) &&
                             (*(undefined *)(plVar43[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                            *(undefined8 *)(puVar45 + 0x20) = 0;
                            *(undefined8 *)(puVar45 + -8) = 0x103f53;
                            func_0x(0x1ec1000,0x1c,0x10,1);
                          }
                        }
                        uVar41 = (uint)((*(byte *)(plVar43 + 0x4a) & 0x5a) != 0);
                      }
                      else {
                        pcVar4 = *(code **)(*plVar43 + 0x1e8);
                        *(undefined8 *)(puVar45 + -8) = 0x103ee6;
                        uVar26 = (*pcVar4)(plVar43);
                        *(undefined8 *)(puVar45 + -8) = 0x103eee;
                        uVar41 = func_0x(uVar26);
                      }
                      if (uVar41 != 0) goto LAB_;
                    }
                  }
                  else {
LAB_:
                    if ((*(byte *)(plVar43 + 0x4a) & 0x10) != 0) goto LAB_;
                  }
                }
LAB_:
                if ((*(byte *)(plVar43 + 0x4a) & 4) == 0) {
                  if ((*(byte *)(plVar43 + 0x4a) & 0x5a) == 0) {
                    if ((*(byte *)(plVar43 + 0x43) & 1) != 0) {
                      if (plVar43[0x1a] == 0) {
                        pcVar4 = *(code **)(*plVar43 + 0x88);
                        *(undefined8 *)(puVar45 + -8) = 0x103fb1;
                        cVar9 = (*pcVar4)(plVar43);
                        if (cVar9 != '\0') {
                          pcVar4 = *(code **)(*plVar43 + 0x18);
                          *(undefined8 *)(puVar45 + -8) = 0x103fbe;
                          cVar9 = (*pcVar4)(plVar43);
                          if (cVar9 == '\0') {
                            *(byte *)(plVar43 + 0x4a) = *(byte *)(plVar43 + 0x4a) | 4;
                            goto LAB_;
                          }
                        }
                      }
                      *(undefined8 *)(puVar45 + -8) = 0x103fd7;
                      iVar16 = func_0x(plVar43);
                      if (iVar16 == 0) {
                        pcVar4 = *(code **)(*plVar43 + 0x270);
                        *(undefined8 *)(puVar45 + -8) = 0x103fe7;
                        (*pcVar4)(plVar43);
                      }
                      if ((*(byte *)(plVar43 + 0x43) & 4) == 0) {
                        if ((*(byte *)(plVar43 + 0x4a) & 0x52) == 2) {
                          lVar24 = plVar43[0x1a];
                          *(undefined8 *)(puVar45 + -8) = 0x104021;
                          cVar9 = func_0x(lVar24);
                          if (((cVar9 != '\0') && (*(char *)(plVar43[0x1a] + 0x130) == '\0')) &&
                             (*(undefined *)(plVar43[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                            *(undefined8 *)(puVar45 + 0x20) = 0;
                            *(undefined8 *)(puVar45 + -8) = 0x10406a;
                            func_0x(0x1ec1000,0x1c,0x10,1);
                          }
                        }
                        uVar41 = (uint)((*(byte *)(plVar43 + 0x4a) & 0x5a) != 0);
                      }
                      else {
                        pcVar4 = *(code **)(*plVar43 + 0x1e8);
                        *(undefined8 *)(puVar45 + -8) = 0x103ffd;
                        uVar26 = (*pcVar4)(plVar43);
                        *(undefined8 *)(puVar45 + -8) = 0x104005;
                        uVar41 = func_0x(uVar26);
                      }
                      if (uVar41 != 0) goto LAB_;
                    }
                  }
                  else {
LAB_:
                    if ((*(byte *)(plVar43 + 0x4a) & 0x40) != 0) goto LAB_;
                  }
                }
              }
            }
LAB_:
            *(undefined8 *)(puVar45 + -8) = 0x104092;
            func_0x(lVar19,0);
          }
LAB_:
          *(undefined8 *)(puVar45 + -8) = 0x10409a;
          iVar16 = func_0x(plVar43);
          if (iVar16 == 0) {
            pcVar4 = *(code **)(*plVar43 + 0x270);
            *(undefined8 *)(puVar45 + -8) = 0x1040aa;
            (*pcVar4)(plVar43);
          }
          lVar19 = plVar43[0x1a];
          if (((&stack0x000000e0)[lVar18] & 0x24) == 0) {
            if ((*(byte *)(plVar43 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar43 + 0x4a) & 0x5a) != 0) goto LAB_;
              if ((*(byte *)(plVar43 + 0x43) & 1) != 0) {
                if (lVar19 == 0) {
                  pcVar4 = *(code **)(*plVar43 + 0x88);
                  *(undefined8 *)(puVar45 + -8) = 0x1040f5;
                  cVar9 = (*pcVar4)(plVar43);
                  if (cVar9 != '\0') {
                    pcVar4 = *(code **)(*plVar43 + 0x18);
                    *(undefined8 *)(puVar45 + -8) = 0x104102;
                    cVar9 = (*pcVar4)(plVar43);
                    if (cVar9 == '\0') goto LAB_;
                  }
                }
                *(undefined8 *)(puVar45 + -8) = 0x104112;
                iVar16 = func_0x(plVar43);
                if (iVar16 == 0) {
                  pcVar4 = *(code **)(*plVar43 + 0x270);
                  *(undefined8 *)(puVar45 + -8) = 0x104122;
                  (*pcVar4)(plVar43);
                }
                if ((*(byte *)(plVar43 + 0x43) & 4) == 0) {
                  if ((*(byte *)(plVar43 + 0x4a) & 0x52) == 2) {
                    lVar24 = plVar43[0x1a];
                    *(undefined8 *)(puVar45 + -8) = 0x10415c;
                    cVar9 = func_0x(lVar24);
                    if (((cVar9 != '\0') && (*(char *)(plVar43[0x1a] + 0x130) == '\0')) &&
                       (*(undefined *)(plVar43[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                      *(undefined8 *)(puVar45 + 0x20) = 0;
                      *(undefined8 *)(puVar45 + -8) = 0x1041a5;
                      func_0x(0x1ec1000,0x1c,0x10,1);
                    }
                  }
                  uVar41 = (uint)((*(byte *)(plVar43 + 0x4a) & 0x5a) != 0);
                }
                else {
                  pcVar4 = *(code **)(*plVar43 + 0x1e8);
                  *(undefined8 *)(puVar45 + -8) = 0x104138;
                  uVar26 = (*pcVar4)(plVar43);
                  *(undefined8 *)(puVar45 + -8) = 0x104140;
                  uVar41 = func_0x(uVar26);
                }
                if (uVar41 != 0) goto LAB_;
              }
            }
            if ((lVar19 == 0) || (*(int *)(lVar19 + 0x74) < 1)) goto LAB_;
          }
LAB_:
          *(undefined8 *)(puVar45 + -8) = 0x1041cc;
          iVar16 = func_0x(psVar56);
          if (iVar16 != 0) {
            *(undefined8 *)(puVar45 + -8) = 0x1041df;
            func_0x(psVar56,&stack0x000001b0 + lVar18);
            *(undefined8 *)(puVar45 + -8) = 0x1041eb;
            iVar16 = func_0x(&stack0x000001b0 + lVar18);
            uVar40 = uVar40 + iVar16;
          }
          lVar19 = plVar43[0x1a];
          pcVar4 = *(code **)(*plVar43 + 0x88);
          *(undefined8 *)(puVar45 + -8) = 0x104201;
          cVar9 = (*pcVar4)(plVar43);
          if ((((cVar9 == '\0') && (lVar19 != 0)) &&
              ((0 < *(int *)(lVar19 + 0x78) || (0 < *(int *)(lVar19 + 0x74))))) && (uVar40 < 0x1f74)
             ) {
            uVar40 = uVar40 + 8;
          }
          uVar40 = uVar40 + 0xe;
        }
        else {
          pcVar4 = *(code **)(*plVar43 + 0x88);
          *(undefined8 *)(puVar45 + -8) = 0x10399c;
          cVar9 = (*pcVar4)(plVar43);
          if (cVar9 == '\0') goto LAB_;
          pcVar4 = *(code **)(*plVar43 + 0x18);
          *(undefined8 *)(puVar45 + -8) = 0x1039a9;
          cVar9 = (*pcVar4)(plVar43);
          if (cVar9 != '\0') goto LAB_;
LAB_:
          *(undefined8 *)(puVar45 + -8) = 0x10423c;
          iVar16 = func_0x(psVar56);
          if (iVar16 != 0) {
            if (*psVar56 != 0) goto LAB_;
            uVar40 = *(uint *)(psVar5 + 2);
            if (uVar40 == 0) {
              iVar16 = 0;
              *puVar49 = 0;
              uVar40 = *(uint *)(psVar5 + 8);
              uVar47 = (ulonglong)uVar40;
              *(uint *)(psVar5 + 10) = uVar40;
              pbVar36 = *(byte **)(psVar5 + 4);
              bVar30 = *pbVar36;
              if ((bVar30 & 0x10) != 0) {
                uVar40 = uVar40 + 2 + (*(ushort *)(pbVar36 + uVar47) + 7 >> 3);
                uVar47 = (ulonglong)uVar40;
                *(uint *)(psVar5 + 10) = uVar40;
                bVar30 = *pbVar36;
              }
              if ((bVar30 & 0x20) == 0) {
                *(int *)(psVar5 + 2) = (int)uVar47;
                psVar5[0xe] = 0;
                *(undefined4 *)(psVar5 + 0xc) = *(undefined4 *)(psVar5 + 10);
              }
              else {
                puVar55 = (ushort *)(pbVar36 + uVar47);
                uVar13 = *puVar55;
                psVar5[0xe] = uVar13;
                if (uVar13 == 0) {
                  *(undefined8 *)(puVar45 + -8) = 0x1042b9;
                  cVar9 = func_0x(0x1ec08c0);
                  if (cVar9 != '\0') {
                    *(undefined8 *)(puVar45 + -8) = 0x1042c2;
                    lVar19 = func_0x();
                    if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar45 + -8) = 0x1042dc;
                      cVar9 = func_0x(0x1ec08c0);
                      if (cVar9 == '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x1042f8;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar45 + 0x20) = 0;
                        *(undefined8 *)(puVar45 + -8) = 0x10431e;
                        (*_DAT_)(1,0x17b02cc,0x18d03b8,0x80f);
                      }
                    }
                  }
                  uVar26 = *(undefined8 *)(psVar5 + 4);
                  *(undefined8 *)(puVar45 + -8) = 0x10432c;
                  func_0x(uVar26,3);
                  uVar13 = psVar5[0xe];
                }
                uVar40 = *(int *)(psVar5 + 10) + 2 + (uint)uVar13 * 2;
                *(uint *)(psVar5 + 0xc) = uVar40;
                if (0x1f9e < uVar40) {
                  *(undefined8 *)(puVar45 + -8) = 0x104353;
                  cVar9 = func_0x(0x1ec08c0);
                  if (cVar9 != '\0') {
                    *(undefined8 *)(puVar45 + -8) = 0x10435c;
                    lVar19 = func_0x();
                    if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar45 + -8) = 0x104376;
                      cVar9 = func_0x(0x1ec08c0);
                      if (cVar9 == '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x104392;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar45 + 0x20) = 0;
                        *(undefined8 *)(puVar45 + -8) = 0x1043b8;
                        (*_DAT_)(1,0x17b02cc,0x18d03b8,0x816);
                      }
                    }
                  }
                  uVar26 = *(undefined8 *)(psVar5 + 4);
                  *(undefined8 *)(puVar45 + -8) = 0x1043c6;
                  func_0x(uVar26);
                }
                uVar13 = puVar55[(ushort)psVar5[0xe]];
                *(uint *)(psVar5 + 2) = uVar13 & 0x7fff;
                uVar40 = *(uint *)(psVar5 + 0xc);
                if ((uVar13 & 0x7fff) < uVar40) {
                  *(undefined8 *)(puVar45 + -8) = 0x1043f2;
                  cVar9 = func_0x(0x1ec08c0);
                  if (cVar9 != '\0') {
                    *(undefined8 *)(puVar45 + -8) = 0x1043fb;
                    lVar19 = func_0x();
                    if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar45 + -8) = 0x104415;
                      cVar9 = func_0x(0x1ec08c0);
                      if (cVar9 == '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x104431;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar45 + 0x20) = 0;
                        *(undefined8 *)(puVar45 + -8) = 0x104457;
                        (*_DAT_)(1,0x17b02cc,0x18d03b8,0x81d);
                      }
                    }
                  }
                  uVar26 = *(undefined8 *)(psVar5 + 4);
                  *(undefined8 *)(puVar45 + -8) = 0x104465;
                  func_0x(uVar26);
                  uVar40 = *(uint *)(psVar5 + 0xc);
                }
                uVar13 = psVar5[0xe];
                puVar6 = puVar55;
                if (uVar13 != 0) {
                  do {
                    uVar41 = puVar6[1] & 0x7fff;
                    if ((uVar41 < uVar40) || (*(uint *)(psVar5 + 2) < uVar41)) {
                      *(undefined8 *)(puVar45 + -8) = 0x1044af;
                      cVar9 = func_0x(0x1ec08c0);
                      if (cVar9 != '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x1044b8;
                        lVar19 = func_0x();
                        if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar45 + -8) = 0x1044d2;
                          cVar9 = func_0x(0x1ec08c0);
                          if (cVar9 == '\0') {
                            *(undefined8 *)(puVar45 + -8) = 0x1044ee;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar45 + 0x20) = 0;
                            *(undefined8 *)(puVar45 + -8) = 0x104512;
                            (*_DAT_)(1,0x17b02cc,0x18d03b8,0x82a);
                          }
                        }
                      }
                      uVar26 = *(undefined8 *)(psVar5 + 4);
                      *(undefined8 *)(puVar45 + -8) = 0x104520;
                      func_0x(uVar26,4);
                    }
                    iVar16 = iVar16 + 1;
                    uVar13 = psVar5[0xe];
                    uVar40 = uVar41;
                    puVar6 = puVar6 + 1;
                  } while (iVar16 < (int)(uint)uVar13);
                  plVar43 = *(longlong **)(&stack0x00000118 + lVar18);
                  plVar21 = *(longlong **)(&stack0x000000a8 + lVar18);
                }
                uVar40 = (uint)uVar13;
                if ((short)puVar55[(ulonglong)(uVar40 - 1) + 1] < 0) {
                  do {
                    lVar19 = *(longlong *)(psVar5 + 4);
                    lVar24 = (ulonglong)*(uint *)(psVar5 + 10) + lVar19;
                    uVar41 = *(ushort *)(lVar24 + (ulonglong)uVar40 * 2) & 0x7fff;
                    if (uVar40 == 1) {
                      uVar48 = *(uint *)(psVar5 + 0xc);
                      uVar47 = (ulonglong)uVar48;
LAB_:
                      if ((uVar41 < (uint)uVar47) ||
                         (uVar40 = *(uint *)(psVar5 + 2), uVar40 < uVar41)) goto LAB_;
                    }
                    else {
                      uVar40 = *(ushort *)(lVar24 + -2 + (ulonglong)uVar40 * 2) & 0x7fff;
                      uVar47 = (ulonglong)uVar40;
                      uVar48 = *(uint *)(psVar5 + 0xc);
                      if (uVar48 <= uVar40) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar45 + -8) = 0x1045a9;
                      func_0x(lVar19,7);
                      uVar48 = *(uint *)(psVar5 + 0xc);
                      uVar40 = *(uint *)(psVar5 + 2);
                    }
                    uVar31 = (uint)uVar47;
                    if ((uVar31 < uVar48) || (uVar40 < uVar31)) goto LAB_;
                    if (*(ushort *)(uVar47 + *(longlong *)(psVar5 + 4)) == 5) {
                      *puVar49 = *puVar49 | 2;
                      psVar5[0xe] = psVar5[0xe] + -1;
                      uVar50 = uVar47 & 0xffff;
                      psVar5[0x15] = (short)uVar47;
                      uVar47 = *(ulonglong *)(psVar5 + 4);
                      uVar13 = psVar5[0x16] & 0xc7ffU;
                      if ((*(ushort *)(uVar50 + 2 + uVar47) >> 0xe & 1) != 0) {
                        uVar13 = *(ushort *)(uVar50 + 2 + uVar47) & 0x3800 | psVar5[0x16] & 0xc7ffU;
                      }
                      psVar5[0x16] = uVar13;
                      uVar14 = (uVar13 ^ *(ushort *)(uVar50 + 2 + uVar47)) & 0x7ff ^ uVar13;
                      psVar5[0x16] = uVar14;
                      uVar42 = (ulonglong)(ushort)psVar5[0x15];
                      uVar50 = uVar42 + 4 +
                               (ulonglong)((uVar14 & 0x7ff) * 2) + uVar47 + (uVar13 >> 0xb & 7) * 2;
                      if (uVar50 < uVar42 + uVar47) {
                        *(undefined8 *)(puVar45 + -8) = 0x1046f2;
                        func_0x(uVar42 + uVar47,0x19);
                        uVar14 = psVar5[0x16];
                        uVar42 = (ulonglong)(ushort)psVar5[0x15];
                        uVar47 = (ulonglong)*(uint *)(psVar5 + 4);
                      }
                      if (uVar41 - uVar31 <
                          (((uVar14 & 0x7ff) * 2 - (int)uVar42) - (int)uVar47) + (int)uVar50) {
                        lVar19 = *(longlong *)(psVar5 + 4);
                        *(undefined8 *)(puVar45 + -8) = 0x10472a;
                        func_0x(uVar42 + lVar19,0x19);
                        uVar14 = psVar5[0x16];
                      }
                      if ((uVar14 & 0x3800) != 0) {
                        puVar55 = (ushort *)
                                  (*(longlong *)(psVar5 + 4) + 4 + (ulonglong)(ushort)psVar5[0x15]);
                        iVar16 = 0;
                        if ((uVar14 & 0x3800) != 0) {
                          do {
                            if ((uVar14 & 0x7ff) < (*puVar55 & 0x7ff)) {
                              uVar13 = psVar5[0x15];
                              lVar19 = *(longlong *)(psVar5 + 4);
                              *(undefined8 *)(puVar45 + -8) = 0x104797;
                              func_0x((ulonglong)uVar13 + lVar19,0x1a);
                              uVar14 = psVar5[0x16];
                            }
                            iVar16 = iVar16 + 1;
                            puVar55 = puVar55 + 1;
                          } while (iVar16 < (int)(uVar14 >> 0xb & 7));
                        }
                      }
                      break;
                    }
                    if (*(ushort *)(uVar47 + *(longlong *)(psVar5 + 4)) < 0x400) break;
                    *puVar49 = *puVar49 | 1;
                    uVar13 = psVar5[0xe] - 1;
                    psVar5[0xe] = uVar13;
                    if ((uVar13 == 0) ||
                       (uVar40 = (uint)uVar13, -1 < (short)puVar55[(ulonglong)(uVar13 - 1) + 1]))
                    break;
                  } while( true );
                }
              }
              if ((**(byte **)(psVar5 + 4) & 0x40) == 0) {
                *(undefined4 *)(psVar5 + 0x13) = 0;
              }
              else {
                *(undefined4 *)(psVar5 + 0x13) = *(undefined4 *)(psVar5 + 2);
                *(int *)(psVar5 + 2) = *(int *)(psVar5 + 2) + 0xe;
                *(undefined8 *)(puVar45 + -8) = 0x10462c;
                uVar26 = func_0x(puVar49);
                *(undefined8 *)(puVar45 + -8) = 0x10463b;
                func_0x(uVar26,&stack0x000001b8 + lVar18);
                *(undefined8 *)(puVar45 + -8) = 0x104647;
                iVar16 = func_0x(&stack0x000001b8 + lVar18);
                *(int *)(psVar5 + 2) = *(int *)(psVar5 + 2) + iVar16;
              }
              uVar40 = *(uint *)(psVar5 + 2);
              if ((*(ulonglong *)(psVar5 + 0xf) != 0) &&
                 (*(ulonglong *)(psVar5 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar5 + 4))) {
                *(undefined8 *)(puVar45 + -8) = 0x1047fa;
                cVar9 = func_0x(0x1ec08c0);
                if (cVar9 != '\0') {
                  *(undefined8 *)(puVar45 + -8) = 0x104803;
                  lVar19 = func_0x();
                  if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar45 + -8) = 0x10481d;
                    cVar9 = func_0x(0x1ec08c0);
                    if (cVar9 == '\0') {
                      *(undefined8 *)(puVar45 + -8) = 0x104839;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar45 + 0x20) = 0;
                      *(undefined8 *)(puVar45 + -8) = 0x104863;
                      (*_DAT_)(1,0x17b02cc,0x18d03b8,0x886);
                    }
                  }
                }
                uVar26 = *(undefined8 *)(psVar5 + 4);
                *(undefined8 *)(puVar45 + -8) = 0x104871;
                func_0x(uVar26,0x12);
                uVar40 = *(uint *)(psVar5 + 2);
              }
              if ((uVar40 == 0) || (0x3f3c < uVar40)) {
                *(undefined8 *)(puVar45 + -8) = 0x104893;
                cVar9 = func_0x(0x1ec08c0);
                if (cVar9 != '\0') {
                  *(undefined8 *)(puVar45 + -8) = 0x10489c;
                  lVar19 = func_0x();
                  if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar45 + -8) = 0x1048b6;
                    cVar9 = func_0x(0x1ec08c0);
                    if (cVar9 == '\0') goto LAB_;
                    *(undefined8 *)(puVar45 + 0x20) = 0;
                    *(undefined8 *)(puVar45 + -8) = 0x1048fc;
                    (*_DAT_)(1,0x17b02cc,0x18d03b8,0x88b);
                  }
                }
                goto LAB_;
              }
            }
            goto LAB_;
          }
        }
      }
      else if (*psVar56 == 0) {
        uVar40 = *(uint *)(psVar5 + 2);
        if (uVar40 == 0) {
          iVar16 = 0;
          *puVar49 = 0;
          uVar40 = *(uint *)(psVar5 + 8);
          uVar47 = (ulonglong)uVar40;
          *(uint *)(psVar5 + 10) = uVar40;
          pbVar36 = *(byte **)(psVar5 + 4);
          bVar30 = *pbVar36;
          if ((bVar30 & 0x10) != 0) {
            uVar40 = uVar40 + 2 + (*(ushort *)(pbVar36 + uVar47) + 7 >> 3);
            uVar47 = (ulonglong)uVar40;
            *(uint *)(psVar5 + 10) = uVar40;
            bVar30 = *pbVar36;
          }
          if ((bVar30 & 0x20) == 0) {
            *(int *)(psVar5 + 2) = (int)uVar47;
            psVar5[0xe] = 0;
            *(undefined4 *)(psVar5 + 0xc) = *(undefined4 *)(psVar5 + 10);
          }
          else {
            puVar55 = (ushort *)(pbVar36 + uVar47);
            uVar13 = *puVar55;
            psVar5[0xe] = uVar13;
            if (uVar13 == 0) {
              *(undefined8 *)(puVar45 + -8) = 0x103352;
              cVar9 = func_0x(0x1ec08c0);
              if (cVar9 != '\0') {
                *(undefined8 *)(puVar45 + -8) = 0x10335b;
                lVar19 = func_0x();
                if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar45 + -8) = 0x103375;
                  cVar9 = func_0x(0x1ec08c0);
                  if (cVar9 == '\0') {
                    *(undefined8 *)(puVar45 + -8) = 0x103391;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar45 + 0x20) = 0;
                    *(undefined8 *)(puVar45 + -8) = 0x1033b7;
                    (*_DAT_)(1,0x17b02cc,0x18d03b8,0x80f);
                  }
                }
              }
              uVar26 = *(undefined8 *)(psVar5 + 4);
              *(undefined8 *)(puVar45 + -8) = 0x1033c5;
              func_0x(uVar26,3);
              uVar13 = psVar5[0xe];
            }
            uVar40 = *(int *)(psVar5 + 10) + 2 + (uint)uVar13 * 2;
            *(uint *)(psVar5 + 0xc) = uVar40;
            if (0x1f9e < uVar40) {
              *(undefined8 *)(puVar45 + -8) = 0x1033ec;
              cVar9 = func_0x(0x1ec08c0);
              if (cVar9 != '\0') {
                *(undefined8 *)(puVar45 + -8) = 0x1033f5;
                lVar19 = func_0x();
                if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar45 + -8) = 0x10340f;
                  cVar9 = func_0x(0x1ec08c0);
                  if (cVar9 == '\0') {
                    *(undefined8 *)(puVar45 + -8) = 0x10342b;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar45 + 0x20) = 0;
                    *(undefined8 *)(puVar45 + -8) = 0x103451;
                    (*_DAT_)(1,0x17b02cc,0x18d03b8,0x816);
                  }
                }
              }
              uVar26 = *(undefined8 *)(psVar5 + 4);
              *(undefined8 *)(puVar45 + -8) = 0x10345f;
              func_0x(uVar26);
            }
            uVar13 = puVar55[(ushort)psVar5[0xe]];
            *(uint *)(psVar5 + 2) = uVar13 & 0x7fff;
            uVar40 = *(uint *)(psVar5 + 0xc);
            if ((uVar13 & 0x7fff) < uVar40) {
              *(undefined8 *)(puVar45 + -8) = 0x10348b;
              cVar9 = func_0x(0x1ec08c0);
              if (cVar9 != '\0') {
                *(undefined8 *)(puVar45 + -8) = 0x103494;
                lVar19 = func_0x();
                if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar45 + -8) = 0x1034ae;
                  cVar9 = func_0x(0x1ec08c0);
                  if (cVar9 == '\0') {
                    *(undefined8 *)(puVar45 + -8) = 0x1034ca;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar45 + 0x20) = 0;
                    *(undefined8 *)(puVar45 + -8) = 0x1034f0;
                    (*_DAT_)(1,0x17b02cc,0x18d03b8,0x81d);
                  }
                }
              }
              uVar26 = *(undefined8 *)(psVar5 + 4);
              *(undefined8 *)(puVar45 + -8) = 0x1034fe;
              func_0x(uVar26);
              uVar40 = *(uint *)(psVar5 + 0xc);
            }
            uVar13 = psVar5[0xe];
            puVar6 = puVar55;
            if (uVar13 != 0) {
              do {
                uVar41 = puVar6[1] & 0x7fff;
                if ((uVar41 < uVar40) || (*(uint *)(psVar5 + 2) < uVar41)) {
                  *(undefined8 *)(puVar45 + -8) = 0x103541;
                  cVar9 = func_0x(0x1ec08c0);
                  if (cVar9 != '\0') {
                    *(undefined8 *)(puVar45 + -8) = 0x10354a;
                    lVar19 = func_0x();
                    if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar45 + -8) = 0x103564;
                      cVar9 = func_0x(0x1ec08c0);
                      if (cVar9 == '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x103580;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar45 + 0x20) = 0;
                        *(undefined8 *)(puVar45 + -8) = 0x1035a4;
                        (*_DAT_)(1,0x17b02cc,0x18d03b8,0x82a);
                      }
                    }
                  }
                  uVar26 = *(undefined8 *)(psVar5 + 4);
                  *(undefined8 *)(puVar45 + -8) = 0x1035b2;
                  func_0x(uVar26,4);
                }
                iVar16 = iVar16 + 1;
                uVar13 = psVar5[0xe];
                uVar40 = uVar41;
                puVar6 = puVar6 + 1;
              } while (iVar16 < (int)(uint)uVar13);
              plVar43 = *(longlong **)(&stack0x00000118 + lVar18);
              plVar21 = *(longlong **)(&stack0x000000a8 + lVar18);
            }
            uVar40 = (uint)uVar13;
            if ((short)puVar55[(ulonglong)(uVar40 - 1) + 1] < 0) {
              do {
                lVar19 = *(longlong *)(psVar5 + 4);
                lVar24 = (ulonglong)*(uint *)(psVar5 + 10) + lVar19;
                uVar41 = *(ushort *)(lVar24 + (ulonglong)uVar40 * 2) & 0x7fff;
                if (uVar40 == 1) {
                  uVar48 = *(uint *)(psVar5 + 0xc);
                  uVar47 = (ulonglong)uVar48;
LAB_:
                  if ((uVar41 < (uint)uVar47) || (uVar40 = *(uint *)(psVar5 + 2), uVar40 < uVar41))
                  goto LAB_;
                }
                else {
                  uVar40 = *(ushort *)(lVar24 + -2 + (ulonglong)uVar40 * 2) & 0x7fff;
                  uVar47 = (ulonglong)uVar40;
                  uVar48 = *(uint *)(psVar5 + 0xc);
                  if (uVar48 <= uVar40) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar45 + -8) = 0x103639;
                  func_0x(lVar19,7);
                  uVar48 = *(uint *)(psVar5 + 0xc);
                  uVar40 = *(uint *)(psVar5 + 2);
                }
                uVar31 = (uint)uVar47;
                if ((uVar31 < uVar48) || (uVar40 < uVar31)) goto LAB_;
                if (*(ushort *)(uVar47 + *(longlong *)(psVar5 + 4)) == 5) {
                  *puVar49 = *puVar49 | 2;
                  psVar5[0xe] = psVar5[0xe] + -1;
                  uVar50 = uVar47 & 0xffff;
                  psVar5[0x15] = (short)uVar47;
                  uVar47 = *(ulonglong *)(psVar5 + 4);
                  uVar13 = psVar5[0x16] & 0xc7ffU;
                  if ((*(ushort *)(uVar50 + 2 + uVar47) >> 0xe & 1) != 0) {
                    uVar13 = *(ushort *)(uVar50 + 2 + uVar47) & 0x3800 | psVar5[0x16] & 0xc7ffU;
                  }
                  psVar5[0x16] = uVar13;
                  uVar14 = (uVar13 ^ *(ushort *)(uVar50 + 2 + uVar47)) & 0x7ff ^ uVar13;
                  psVar5[0x16] = uVar14;
                  uVar42 = (ulonglong)(ushort)psVar5[0x15];
                  uVar50 = uVar47 + 4 +
                           (ulonglong)((uVar14 & 0x7ff) * 2) + uVar42 + (uVar13 >> 0xb & 7) * 2;
                  if (uVar50 < uVar42 + uVar47) {
                    *(undefined8 *)(puVar45 + -8) = 0x103782;
                    func_0x(uVar42 + uVar47,0x19);
                    uVar14 = psVar5[0x16];
                    uVar42 = (ulonglong)(ushort)psVar5[0x15];
                    uVar47 = (ulonglong)*(uint *)(psVar5 + 4);
                  }
                  if (uVar41 - uVar31 <
                      (((uVar14 & 0x7ff) * 2 - (int)uVar42) - (int)uVar47) + (int)uVar50) {
                    lVar19 = *(longlong *)(psVar5 + 4);
                    *(undefined8 *)(puVar45 + -8) = 0x1037ba;
                    func_0x(uVar42 + lVar19,0x19);
                    uVar14 = psVar5[0x16];
                  }
                  if ((uVar14 & 0x3800) != 0) {
                    puVar55 = (ushort *)
                              (*(longlong *)(psVar5 + 4) + 4 + (ulonglong)(ushort)psVar5[0x15]);
                    iVar16 = 0;
                    if ((uVar14 & 0x3800) != 0) {
                      do {
                        if ((uVar14 & 0x7ff) < (*puVar55 & 0x7ff)) {
                          uVar13 = psVar5[0x15];
                          lVar19 = *(longlong *)(psVar5 + 4);
                          *(undefined8 *)(puVar45 + -8) = 0x103827;
                          func_0x((ulonglong)uVar13 + lVar19,0x1a);
                          uVar14 = psVar5[0x16];
                        }
                        iVar16 = iVar16 + 1;
                        puVar55 = puVar55 + 1;
                      } while (iVar16 < (int)(uVar14 >> 0xb & 7));
                    }
                  }
                  break;
                }
                if (*(ushort *)(uVar47 + *(longlong *)(psVar5 + 4)) < 0x400) break;
                *puVar49 = *puVar49 | 1;
                uVar13 = psVar5[0xe] - 1;
                psVar5[0xe] = uVar13;
                if ((uVar13 == 0) ||
                   (uVar40 = (uint)uVar13, -1 < (short)puVar55[(ulonglong)(uVar13 - 1) + 1])) break;
              } while( true );
            }
          }
          if ((**(byte **)(psVar5 + 4) & 0x40) == 0) {
            *(undefined4 *)(psVar5 + 0x13) = 0;
          }
          else {
            *(undefined4 *)(psVar5 + 0x13) = *(undefined4 *)(psVar5 + 2);
            *(int *)(psVar5 + 2) = *(int *)(psVar5 + 2) + 0xe;
            *(undefined8 *)(puVar45 + -8) = 0x1036bc;
            uVar26 = func_0x(puVar49);
            *(undefined8 *)(puVar45 + -8) = 0x1036cb;
            func_0x(uVar26,&stack0x000001a8 + lVar18);
            *(undefined8 *)(puVar45 + -8) = 0x1036d7;
            iVar16 = func_0x(&stack0x000001a8 + lVar18);
            *(int *)(psVar5 + 2) = *(int *)(psVar5 + 2) + iVar16;
          }
          uVar40 = *(uint *)(psVar5 + 2);
          if ((*(ulonglong *)(psVar5 + 0xf) != 0) &&
             (*(ulonglong *)(psVar5 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar5 + 4))) {
            *(undefined8 *)(puVar45 + -8) = 0x10388a;
            cVar9 = func_0x(0x1ec08c0);
            if (cVar9 != '\0') {
              *(undefined8 *)(puVar45 + -8) = 0x103893;
              lVar19 = func_0x();
              if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                *(undefined8 *)(puVar45 + -8) = 0x1038ad;
                cVar9 = func_0x(0x1ec08c0);
                if (cVar9 == '\0') {
                  *(undefined8 *)(puVar45 + -8) = 0x1038c9;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar45 + 0x20) = 0;
                  *(undefined8 *)(puVar45 + -8) = 0x1038f3;
                  (*_DAT_)(1,0x17b02cc,0x18d03b8,0x886);
                }
              }
            }
            uVar26 = *(undefined8 *)(psVar5 + 4);
            *(undefined8 *)(puVar45 + -8) = 0x103901;
            func_0x(uVar26,0x12);
            uVar40 = *(uint *)(psVar5 + 2);
          }
          if ((uVar40 != 0) && (uVar40 < 0x3f3d)) goto LAB_;
          *(undefined8 *)(puVar45 + -8) = 0x103923;
          cVar9 = func_0x(0x1ec08c0);
          if (cVar9 != '\0') {
            *(undefined8 *)(puVar45 + -8) = 0x103930;
            lVar19 = func_0x();
            if ((lVar19 == 0) || (*(char *)(lVar19 + 0x499) == '\0')) goto LAB_;
            *(undefined8 *)(puVar45 + -8) = 0x103952;
            cVar9 = func_0x(0x1ec08c0);
            if (cVar9 != '\0') {
              *(undefined8 *)(puVar45 + 0x20) = 0;
              *(undefined8 *)(puVar45 + -8) = 0x103982;
              (*_DAT_)(1,0x17b02cc,0x18d03b8,0x88b);
              goto LAB_;
            }
LAB_:
            *(undefined8 *)(puVar45 + -8) = 0x1048d2;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
LAB_:
          uVar26 = *(undefined8 *)(psVar5 + 4);
          *(undefined8 *)(puVar45 + -8) = 0x10490a;
          func_0x(uVar26,5);
          uVar40 = *(uint *)(psVar5 + 2);
        }
LAB_:
        if ((uVar40 < 9) &&
           (((**(byte **)(psVar5 + 4) & 0xe) == 0 || ((**(byte **)(psVar5 + 4) & 0xe) == 0xc)))) {
          uVar40 = 9;
        }
      }
      else {
LAB_:
        *(undefined8 *)(puVar45 + -8) = 0x104935;
        uVar40 = func_0x(puVar49);
      }
      lVar19 = *plVar21;
      lVar24 = *(longlong *)(&stack0x00000130 + lVar18);
      bVar30 = *(byte *)(*(longlong *)(lVar24 + 8) + 0x107);
      iVar16 = *(int *)(lVar19 + 0x40);
      *(undefined8 *)(puVar45 + -8) = 0x10496e;
      uVar26 = func_0x(lVar24,&stack0x00000208 + lVar18);
      *(undefined8 *)(puVar45 + 0x40) = *(undefined8 *)(lVar19 + 0x10);
      lVar19 = *(longlong *)(&stack0x00000128 + lVar18);
      *(undefined2 *)(puVar45 + 0x38) = *(undefined2 *)(lVar19 + 8);
      *(longlong *)(puVar45 + 0x30) = lVar19;
      *(uint *)(puVar45 + 0x28) = bVar30 >> 6 & 1;
      *(uint *)(puVar45 + 0x20) = (uint)(iVar16 != 1);
      *(undefined8 *)(puVar45 + -8) = 0x1049a9;
      func_0x(&stack0x000002a8 + lVar18,plVar43,uVar26,lVar24);
      *(undefined *)((longlong)plVar21 + 0x27e) = 0;
      *(undefined8 *)(puVar45 + -8) = 0x1049b9;
      cVar9 = func_0x(lVar24);
      *(undefined8 *)(puVar45 + -8) = 0x1049c8;
      cVar10 = func_0x(lVar24);
      lVar19 = *plVar21;
      *(uint *)(puVar45 + 0x28) = -(uint)(cVar9 != '\0') & 2;
      *(uint *)(puVar45 + 0x20) = (uint)(cVar10 != '\0');
      uVar26 = *(undefined8 *)(lVar19 + 0x20);
      *(undefined8 *)(puVar45 + -8) = 0x1049f7;
      func_0x(&stack0x00000260 + lVar18,&stack0x000002a8 + lVar18,uVar26,uVar40);
      *(undefined8 *)(puVar45 + -8) = 0x104a09;
      uVar26 = func_0x(lVar24,&stack0x00000210 + lVar18);
      *(undefined8 *)(puVar45 + -8) = 0x104a11;
      uVar26 = func_0x(uVar26);
      lVar19 = plVar43[6];
      *(undefined8 *)(puVar45 + -8) = 0x104a1d;
      cVar9 = func_0x(lVar19,uVar26);
      if (cVar9 != '\0') {
        *(undefined4 *)(&stack0x000000c8 + lVar18) = 1;
      }
      uVar40 = 0;
      do {
        uVar17 = 0;
        *(undefined8 *)(puVar45 + -8) = 0x104a45;
        func_0x(&stack0x00000260 + lVar18,&stack0x00000818 + lVar18);
        *(undefined8 *)(puVar45 + -8) = 0x104a58;
        piVar27 = (int *)func_0x
                                   (&stack0x00000818 + lVar18,&stack0x000001e6 + lVar18);
        if ((*piVar27 == 0) && (*(short *)(piVar27 + 1) == 0)) goto LAB_;
        if (*(char *)(*(longlong *)(*plVar21 + 0x20) + 1) == '\x05') {
LAB_:
          puVar54 = (undefined8 *)*plVar21;
          *(undefined **)(puVar45 + 0x20) = &stack0x00000240 + lVar18;
          uVar26 = *puVar54;
          *(undefined8 *)(puVar45 + -8) = 0x104c08;
          iVar16 = func_0x(uVar26,&stack0x00000818 + lVar18,3);
          if (iVar16 == 0) {
            if ((*(char *)(*(longlong *)(*plVar21 + 0x20) + 1) != '\x05') &&
               (*(char *)(*(longlong *)(*plVar21 + 0x20) + 2) != '\0')) {
              *(undefined8 *)(puVar45 + -8) = 0x104ea9;
              iVar16 = func_0x(plVar21 + 0x12);
              if (iVar16 != 0) {
                *(undefined8 *)(puVar45 + -8) = 0x104eb9;
                uVar26 = func_0x(plVar21 + 0x12);
                *(undefined8 *)(puVar45 + -8) = 0x104ec1;
                iVar16 = func_0x(uVar26);
                if (iVar16 != 0) {
                  *(longlong *)(*plVar21 + 0x30) = *(longlong *)(*plVar21 + 0x30) + -1;
                }
              }
              *(undefined8 *)(puVar45 + -8) = 0x104ed9;
              func_0x(plVar21 + 0x12);
              *(undefined8 *)(puVar45 + -8) = 0x104ee5;
              func_0x(plVar21 + 0x12);
              goto LAB_;
            }
          }
          else {
            puVar20 = (undefined4 *)(&stack0x00000308 + lVar18);
            lVar19 = 2;
            puVar29 = (undefined4 *)(&stack0x00000508 + lVar18);
            do {
              uVar17 = puVar20[1];
              uVar7 = puVar20[2];
              uVar8 = puVar20[3];
              *puVar29 = *puVar20;
              puVar29[1] = uVar17;
              puVar29[2] = uVar7;
              puVar29[3] = uVar8;
              uVar17 = puVar20[5];
              uVar7 = puVar20[6];
              uVar8 = puVar20[7];
              puVar29[4] = puVar20[4];
              puVar29[5] = uVar17;
              puVar29[6] = uVar7;
              puVar29[7] = uVar8;
              uVar17 = puVar20[9];
              uVar7 = puVar20[10];
              uVar8 = puVar20[0xb];
              puVar29[8] = puVar20[8];
              puVar29[9] = uVar17;
              puVar29[10] = uVar7;
              puVar29[0xb] = uVar8;
              uVar17 = puVar20[0xd];
              uVar7 = puVar20[0xe];
              uVar8 = puVar20[0xf];
              puVar29[0xc] = puVar20[0xc];
              puVar29[0xd] = uVar17;
              puVar29[0xe] = uVar7;
              puVar29[0xf] = uVar8;
              uVar17 = puVar20[0x11];
              uVar7 = puVar20[0x12];
              uVar8 = puVar20[0x13];
              puVar29[0x10] = puVar20[0x10];
              puVar29[0x11] = uVar17;
              puVar29[0x12] = uVar7;
              puVar29[0x13] = uVar8;
              uVar17 = puVar20[0x15];
              uVar7 = puVar20[0x16];
              uVar8 = puVar20[0x17];
              puVar29[0x14] = puVar20[0x14];
              puVar29[0x15] = uVar17;
              puVar29[0x16] = uVar7;
              puVar29[0x17] = uVar8;
              uVar17 = puVar20[0x19];
              uVar7 = puVar20[0x1a];
              uVar8 = puVar20[0x1b];
              puVar29[0x18] = puVar20[0x18];
              puVar29[0x19] = uVar17;
              puVar29[0x1a] = uVar7;
              puVar29[0x1b] = uVar8;
              uVar17 = puVar20[0x1d];
              uVar7 = puVar20[0x1e];
              uVar8 = puVar20[0x1f];
              puVar29[0x1c] = puVar20[0x1c];
              puVar29[0x1d] = uVar17;
              puVar29[0x1e] = uVar7;
              puVar29[0x1f] = uVar8;
              puVar20 = puVar20 + 0x20;
              lVar19 = lVar19 + -1;
              puVar29 = puVar29 + 0x20;
            } while (lVar19 != 0);
            *(undefined4 *)(puVar45 + 0x30) = 1;
            *(undefined **)(puVar45 + 0x28) = &stack0x00000508 + lVar18;
            *(undefined8 *)(puVar45 + 0x20) = 0;
            *(undefined8 *)(puVar45 + -8) = 0x104ca4;
            func_0x(plVar21,&stack0x00000240 + lVar18,&stack0x00000150 + lVar18);
          }
          if (*(int *)(plVar21 + 0x18) == 4) {
            *(undefined8 *)(puVar45 + -8) = 0x104cbe;
            uVar11 = func_0x(&stack0x00000260 + lVar18);
            *(undefined *)((longlong)plVar21 + 0x27e) = uVar11;
            break;
          }
        }
        else {
          pcVar4 = *(code **)(*plVar43 + 0x28);
          *(undefined8 *)(puVar45 + -8) = 0x104a83;
          cVar10 = (*pcVar4)(plVar43);
          if (cVar10 != '\0') goto LAB_;
          *(undefined8 *)(puVar45 + -8) = 0x104a93;
          iVar16 = func_0x(lVar24);
          if (iVar16 != 0) goto LAB_;
          *(undefined8 *)(puVar45 + -8) = 0x104ab0;
          uVar26 = func_0x(&stack0x00000818 + lVar18,&stack0x000001e0 + lVar18);
          *(undefined8 *)(puVar45 + -8) = 0x104abb;
          uVar15 = func_0x(plVar43);
          *(undefined8 *)(puVar45 + -8) = 0x104ad0;
          func_0x(&stack0x00000808 + lVar18,uVar15,uVar26,0);
          if (*(char *)(*(longlong *)(*plVar21 + 0x20) + 2) == '\0') {
            *(undefined8 *)(puVar45 + -8) = 0x104aea;
            cVar10 = func_0x(lVar24);
            if (cVar10 != '\0') goto LAB_;
            *(undefined8 *)(puVar45 + -8) = 0x104b05;
            uVar26 = func_0x(&stack0x00000218 + lVar18,8);
            *(undefined8 *)(puVar45 + -8) = 0x104b17;
            uVar28 = func_0x(lVar24,&stack0x00000220 + lVar18);
            *(undefined8 *)(puVar45 + -8) = 0x104b22;
            iVar16 = func_0x(uVar28,uVar26);
            if (iVar16 != 0) {
              *(undefined8 *)(puVar45 + -8) = 0x104b40;
              uVar26 = func_0x(lVar24);
              lVar19 = plVar21[1];
              *(undefined8 *)(puVar45 + 0x60) = 0;
              *(longlong **)(puVar45 + 0x58) = plVar21 + 0x12;
              *(undefined8 *)(puVar45 + 0x50) = uVar26;
              *(undefined8 *)(puVar45 + 0x48) = 0;
              *(undefined4 *)(puVar45 + 0x40) = 0;
              puVar45[0x38] = 0;
              *(undefined4 *)(puVar45 + 0x30) = 0;
              *(undefined4 *)(puVar45 + 0x28) = 1;
              *(undefined4 *)(puVar45 + 0x20) = 1;
              uVar26 = *(undefined8 *)(lVar19 + 8);
              *(undefined8 *)(puVar45 + -8) = 0x104b8b;
              uVar17 = func_0x(uVar26,&stack0x00000808 + lVar18,8);
            }
          }
          else {
LAB_:
            *(undefined4 *)(puVar45 + 0x38) = 1;
            *(undefined4 *)(puVar45 + 0x30) = 0;
            *(undefined4 *)(puVar45 + 0x28) = 0;
            *(longlong **)(puVar45 + 0x20) = plVar21 + 0x12;
            *(undefined8 *)(puVar45 + -8) = 0x104bc8;
            uVar17 = func_0x(plVar21,&stack0x00000808 + lVar18,2);
          }
          *(undefined8 *)(puVar45 + -8) = 0x104bd5;
          cVar10 = func_0x(uVar17);
          if (cVar10 == '\0') goto LAB_;
        }
LAB_:
        uVar40 = uVar40 + 1;
      } while (uVar40 < *(uint *)(&stack0x000000c8 + lVar18));
      if ((cVar9 != '\0') && (*(int *)(plVar21 + 0x18) != 4)) {
        *(undefined8 *)(puVar45 + -8) = 0x104cef;
        piVar27 = (int *)func_0x
                                   (&stack0x00000818 + lVar18,&stack0x000001ec + lVar18);
        if ((*piVar27 != 0) || (*(short *)(piVar27 + 1) != 0)) {
          *(undefined8 *)(puVar45 + -8) = 0x104d0b;
          func_0x(&stack0x00000120 + lVar18);
          *(undefined8 *)(puVar45 + -8) = 0x104d13;
          uVar26 = func_0x(lVar24);
          *(undefined8 *)(puVar45 + -8) = 0x104d22;
          func_0x(&stack0x00000120 + lVar18,uVar26);
          *(undefined8 *)(puVar45 + -8) = 0x104d35;
          uVar26 = func_0x(&stack0x00000818 + lVar18,&stack0x000001f4 + lVar18);
          *(undefined8 *)(puVar45 + -8) = 0x104d44;
          func_0x(&stack0x000001c0 + lVar18,uVar26);
          (&stack0x0000007a)[lVar18] = 4;
          *(undefined8 *)(puVar45 + -8) = 0x104d55;
          uVar17 = func_0x(4);
          *(undefined8 *)(puVar45 + -8) = 0x104d5e;
          uVar17 = func_0x(uVar17,2);
          *(undefined8 *)(puVar45 + -8) = 0x104d6a;
          uVar17 = func_0x(uVar17,0x20);
          *(undefined8 *)(puVar45 + -8) = 0x104d78;
          func_0x(&stack0x00000250 + lVar18,uVar17);
          *(longlong **)(puVar45 + 0x30) = plVar43;
          puVar45[0x28] = 1;
          *(undefined4 *)(puVar45 + 0x20) = 1;
          lVar19 = plVar43[6];
          *(undefined8 *)(puVar45 + -8) = 0x104da6;
          func_0x
                    (lVar19,&stack0x00000120 + lVar18,&stack0x000001c0 + lVar18,
                     &stack0x0000007a + lVar18);
          *(undefined8 *)(puVar45 + -8) = 0x104db3;
          func_0x(&stack0x00000250 + lVar18);
        }
      }
LAB_:
      puVar32 = *(undefined8 **)(&stack0x000000b0 + lVar18);
      puVar23 = *(undefined8 **)(&stack0x00000090 + lVar18);
      puVar25 = *(undefined8 **)(&stack0x00000080 + lVar18);
    }
    lVar24 = 2;
    lVar19 = 0;
    if (*(int *)(plVar21 + 0x18) != 4) {
      puVar20 = (undefined4 *)(&stack0x00000308 + lVar18);
      puVar29 = (undefined4 *)(&stack0x00000608 + lVar18);
      do {
        uVar17 = puVar20[1];
        uVar7 = puVar20[2];
        uVar8 = puVar20[3];
        *puVar29 = *puVar20;
        puVar29[1] = uVar17;
        puVar29[2] = uVar7;
        puVar29[3] = uVar8;
        uVar17 = puVar20[5];
        uVar7 = puVar20[6];
        uVar8 = puVar20[7];
        puVar29[4] = puVar20[4];
        puVar29[5] = uVar17;
        puVar29[6] = uVar7;
        puVar29[7] = uVar8;
        uVar17 = puVar20[9];
        uVar7 = puVar20[10];
        uVar8 = puVar20[0xb];
        puVar29[8] = puVar20[8];
        puVar29[9] = uVar17;
        puVar29[10] = uVar7;
        puVar29[0xb] = uVar8;
        uVar17 = puVar20[0xd];
        uVar7 = puVar20[0xe];
        uVar8 = puVar20[0xf];
        puVar29[0xc] = puVar20[0xc];
        puVar29[0xd] = uVar17;
        puVar29[0xe] = uVar7;
        puVar29[0xf] = uVar8;
        uVar17 = puVar20[0x11];
        uVar7 = puVar20[0x12];
        uVar8 = puVar20[0x13];
        puVar29[0x10] = puVar20[0x10];
        puVar29[0x11] = uVar17;
        puVar29[0x12] = uVar7;
        puVar29[0x13] = uVar8;
        uVar17 = puVar20[0x15];
        uVar7 = puVar20[0x16];
        uVar8 = puVar20[0x17];
        puVar29[0x14] = puVar20[0x14];
        puVar29[0x15] = uVar17;
        puVar29[0x16] = uVar7;
        puVar29[0x17] = uVar8;
        uVar17 = puVar20[0x19];
        uVar7 = puVar20[0x1a];
        uVar8 = puVar20[0x1b];
        puVar29[0x18] = puVar20[0x18];
        puVar29[0x19] = uVar17;
        puVar29[0x1a] = uVar7;
        puVar29[0x1b] = uVar8;
        uVar17 = puVar20[0x1d];
        uVar7 = puVar20[0x1e];
        uVar8 = puVar20[0x1f];
        puVar29[0x1c] = puVar20[0x1c];
        puVar29[0x1d] = uVar17;
        puVar29[0x1e] = uVar7;
        puVar29[0x1f] = uVar8;
        puVar20 = puVar20 + 0x20;
        lVar24 = lVar24 + -1;
        puVar29 = puVar29 + 0x20;
      } while (lVar24 != 0);
      *(undefined **)(puVar45 + 0x20) = &stack0x00000608 + lVar18;
      *(undefined8 *)(puVar45 + -8) = 0x104e63;
      func_0x(plVar21,&stack0x00000150 + lVar18,0,0);
    }
    if (puVar25 != (undefined8 *)0x0) {
      if ((longlong *)plVar21[5] == (longlong *)0x0) {
        if (*(int *)(plVar21 + 0x18) != 2) {
          *(undefined8 *)(puVar45 + -8) = 0x104f1a;
          func_0x(plVar21,1);
          if (*(int *)(plVar21 + 0x18) != 2) {
            lVar19 = *(longlong *)plVar21[5];
          }
        }
      }
      else {
        lVar19 = *(longlong *)plVar21[5];
      }
      *(undefined4 *)(puVar25 + 1) = *(undefined4 *)(lVar19 + 0x20);
      *(undefined2 *)((longlong)puVar25 + 0xc) = *(undefined2 *)(lVar19 + 0x24);
      *(undefined2 *)((longlong)puVar25 + 0xe) = 0;
      *puVar25 = 0;
      *(undefined4 *)((longlong)puVar25 + 0x1c) = 1;
      puVar25[2] = 0;
      *(undefined2 *)(puVar25 + 3) = 0;
    }
  }
  lVar19 = 2;
  uVar47 = 0;
  puVar20 = (undefined4 *)(&stack0x00000708 + lVar18);
  do {
    uVar17 = *(undefined4 *)((longlong)puVar32 + 4);
    uVar7 = *(undefined4 *)(puVar32 + 1);
    uVar8 = *(undefined4 *)((longlong)puVar32 + 0xc);
    *puVar20 = *(undefined4 *)puVar32;
    puVar20[1] = uVar17;
    puVar20[2] = uVar7;
    puVar20[3] = uVar8;
    uVar17 = *(undefined4 *)((longlong)puVar32 + 0x14);
    uVar7 = *(undefined4 *)(puVar32 + 3);
    uVar8 = *(undefined4 *)((longlong)puVar32 + 0x1c);
    puVar20[4] = *(undefined4 *)(puVar32 + 2);
    puVar20[5] = uVar17;
    puVar20[6] = uVar7;
    puVar20[7] = uVar8;
    uVar17 = *(undefined4 *)((longlong)puVar32 + 0x24);
    uVar7 = *(undefined4 *)(puVar32 + 5);
    uVar8 = *(undefined4 *)((longlong)puVar32 + 0x2c);
    puVar20[8] = *(undefined4 *)(puVar32 + 4);
    puVar20[9] = uVar17;
    puVar20[10] = uVar7;
    puVar20[0xb] = uVar8;
    uVar17 = *(undefined4 *)((longlong)puVar32 + 0x34);
    uVar7 = *(undefined4 *)(puVar32 + 7);
    uVar8 = *(undefined4 *)((longlong)puVar32 + 0x3c);
    puVar20[0xc] = *(undefined4 *)(puVar32 + 6);
    puVar20[0xd] = uVar17;
    puVar20[0xe] = uVar7;
    puVar20[0xf] = uVar8;
    uVar17 = *(undefined4 *)((longlong)puVar32 + 0x44);
    uVar7 = *(undefined4 *)(puVar32 + 9);
    uVar8 = *(undefined4 *)((longlong)puVar32 + 0x4c);
    puVar20[0x10] = *(undefined4 *)(puVar32 + 8);
    puVar20[0x11] = uVar17;
    puVar20[0x12] = uVar7;
    puVar20[0x13] = uVar8;
    uVar17 = *(undefined4 *)((longlong)puVar32 + 0x54);
    uVar7 = *(undefined4 *)(puVar32 + 0xb);
    uVar8 = *(undefined4 *)((longlong)puVar32 + 0x5c);
    puVar20[0x14] = *(undefined4 *)(puVar32 + 10);
    puVar20[0x15] = uVar17;
    puVar20[0x16] = uVar7;
    puVar20[0x17] = uVar8;
    uVar17 = *(undefined4 *)((longlong)puVar32 + 100);
    uVar7 = *(undefined4 *)(puVar32 + 0xd);
    uVar8 = *(undefined4 *)((longlong)puVar32 + 0x6c);
    puVar20[0x18] = *(undefined4 *)(puVar32 + 0xc);
    puVar20[0x19] = uVar17;
    puVar20[0x1a] = uVar7;
    puVar20[0x1b] = uVar8;
    uVar17 = *(undefined4 *)((longlong)puVar32 + 0x74);
    uVar7 = *(undefined4 *)(puVar32 + 0xf);
    uVar8 = *(undefined4 *)((longlong)puVar32 + 0x7c);
    puVar20[0x1c] = *(undefined4 *)(puVar32 + 0xe);
    puVar20[0x1d] = uVar17;
    puVar20[0x1e] = uVar7;
    puVar20[0x1f] = uVar8;
    puVar32 = puVar32 + 0x10;
    lVar19 = lVar19 + -1;
    puVar20 = puVar20 + 0x20;
  } while (lVar19 != 0);
  *(undefined8 *)(puVar45 + 0x20) = 0;
  *(undefined8 *)(puVar45 + -8) = 0x104fe6;
  func_0x(plVar21,&stack0x00000150 + lVar18,&stack0x00000708 + lVar18,1);
  *(uint *)((longlong)puVar23 + 0x634) = *(uint *)((longlong)puVar23 + 0x634) | 1;
  if (*(int *)(&stack0x0000007c + lVar18) != 0) {
    puVar54 = *(undefined8 **)(puVar23[5] + 0x18);
    *(int *)((longlong)puVar54 + 0xc) = *(int *)((longlong)puVar54 + 0xc) + 1;
    if (*(uint *)(puVar54 + 1) <= *(uint *)((longlong)puVar54 + 0xc)) {
      *(undefined4 *)(puVar54 + 1) = 0;
      *puVar54 = 0;
    }
    if (*(int *)(&stack0x00000070 + lVar18) != 0) {
      *(undefined4 *)(puVar23 + 0xa9) = *(undefined4 *)(&stack0x000000a0 + lVar18);
      *(undefined4 *)((longlong)puVar23 + 0x54c) = *(undefined4 *)(&stack0x00000088 + lVar18);
    }
  }
  lVar19 = *(longlong *)(&stack0x00000100 + lVar18);
  lVar24 = *(longlong *)(*(longlong *)(lVar19 + 8) + 0x488);
  if (((lVar24 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
    if (*(longlong *)(lVar24 + 0x20) != 0) {
      lVar51 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar22 = *(longlong *)(lVar51 + 0x100);
      if (lVar22 == 0) {
        *(undefined8 *)(puVar45 + -8) = 0x105097;
        (*_DAT_)(0);
        lVar22 = *(longlong *)(lVar51 + 0x100);
        lVar19 = *(longlong *)(&stack0x00000100 + lVar18);
      }
      if (*(longlong *)(lVar22 + 0x260) != 0) {
        uVar47 = (ulonglong)*(uint *)(*(longlong *)(lVar22 + 0x260) + 0xe68);
      }
      if ((uint)uVar47 < *(uint *)(_DAT_ + 8)) {
        plVar21 = *(longlong **)(*(longlong *)(lVar24 + 0x20) + uVar47 * 8);
        *plVar21 = *plVar21 + 1;
        goto LAB_;
      }
    }
    LOCK();
    **(longlong **)(lVar24 + 0x18) = **(longlong **)(lVar24 + 0x18) + 1;
    UNLOCK();
  }
LAB_:
  if (((*(longlong *)(*(longlong *)(lVar19 + 8) + 0x70) != 0) ||
      (*(int *)(*(longlong *)(*(longlong *)(lVar19 + 0x20) + 0x710) + 0x40) != 0)) &&
     ((*(byte *)(*(longlong *)(lVar19 + 8) + 0x106) & 4) == 0)) {
    plVar21 = (longlong *)
              (*(longlong *)
                (*(longlong *)(*(longlong *)(*(longlong *)(&stack0x00000098 + lVar18) + 0x2e0) + 8)
                + 0x30) + 0x140);
    *plVar21 = *plVar21 + 1;
  }
  **(undefined8 **)(&stack0x000001c8 + lVar18) = puVar23;
  plVar21 = *(longlong **)(&stack0x000001d0 + lVar18);
  if (plVar21 != (longlong *)0x0) {
    pcVar4 = *(code **)(*plVar21 + 0xd0);
    *(undefined8 *)(puVar45 + -8) = 0x105147;
    (*pcVar4)(plVar21,0);
  }
  uVar47 = *(ulonglong *)(&stack0x00002998 + lVar18);
  *(undefined8 *)(puVar45 + -8) = 0x105156;
  func_0x(uVar47 ^ (ulonglong)psVar2);
  return;
code_r0x00102404:
  uVar40 = uVar41;
  if (uVar41 == 0) goto LAB_;
  goto LAB_;
}

