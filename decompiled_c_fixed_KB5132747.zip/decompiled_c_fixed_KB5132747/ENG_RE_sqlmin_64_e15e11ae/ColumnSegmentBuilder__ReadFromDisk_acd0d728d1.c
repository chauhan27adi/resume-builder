
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined8 param_2,longlong *param_3,char *param_4,
                 undefined2 *param_5,longlong *param_6,int *param_7,longlong *param_8,int *param_9,
                 longlong *param_10,int *param_11)

{
  longlong lVar1;
  ulonglong uVar2;
  undefined8 uStackX_8;
  
  uStackX_8 = param_1;
  (**(code **)(*param_3 + 8))(param_3,param_4,0x22,&uStackX_8);
  if ((int)uStackX_8 != 0x22) {
    (*_DAT_)(1,0x13d2ce0,0x139b258,0x1cd,0);
  }
  if (*param_4 != '\x01') {
    (*_DAT_)(1,0x13d2890,0x139b258,0x1d0,0);
  }
  if (param_4[4] != '\x01') {
    (*_DAT_)(1,0x13d2bd8,0x139b258,0x1d1,0);
  }
  if (*(int *)(param_4 + 0x10) != 3) {
    if (*(int *)(param_4 + 0x10) == 7) goto LAB_;
    (*_DAT_)(1,0x13d2c10,0x139b258,0x1d7,0);
    if (*(int *)(param_4 + 0x10) != 3) goto LAB_;
  }
  (**(code **)(*param_3 + 8))(param_3,param_5,0xe,&uStackX_8);
  if ((int)uStackX_8 != 0xe) {
    (*_DAT_)(1,0x13d2c98,0x139b258,0x1e2,0);
  }
LAB_:
  uVar2 = (ulonglong)*(uint *)(param_4 + 0x14) << 3;
  if (0xffffffff < uVar2) {
    uVar2 = 0xffffffff;
    (*_DAT_)(0x161,0x51,0x16,5);
  }
  *param_7 = (int)uVar2;
  lVar1 = (*_DAT_)(uVar2 & 0xffffffff,param_2,0x1256b98,0x1ec,5);
  if (*param_6 != lVar1) {
    (*_DAT_)(*param_6,0);
  }
  *param_6 = lVar1;
  (**(code **)(*param_3 + 8))(param_3,lVar1,*param_7,&uStackX_8);
  if ((int)uStackX_8 != *param_7) {
    (*_DAT_)(1,0x13d2cc0,0x139b258,500,0);
  }
  uVar2 = (ulonglong)*(ushort *)(param_4 + 0x20) * (ulonglong)*(uint *)(param_4 + 0x1c);
  if (0xffffffff < uVar2) {
    uVar2 = 0xffffffff;
    (*_DAT_)(0x161,0x51,0x16,6);
  }
  *param_9 = (int)uVar2;
  lVar1 = (*_DAT_)(uVar2 & 0xffffffff,param_2,0x1256b98,0x1fc,5);
  if (*param_8 != lVar1) {
    (*_DAT_)(*param_8,0);
  }
  *param_8 = lVar1;
  (**(code **)(*param_3 + 8))(param_3,lVar1,*param_9,&uStackX_8);
  if ((int)uStackX_8 != *param_9) {
    (*_DAT_)(1,0x13d2b98,0x139b258,0x203,0);
  }
  if (*(int *)(param_4 + 0x10) == 7) {
    if (*param_10 != 0) {
      (*_DAT_)(*param_10,0);
    }
    *param_10 = 0;
    *param_11 = 0;
    *param_5 = 0;
    *(undefined8 *)(param_5 + 3) = 0;
    *(undefined4 *)(param_5 + 1) = 0;
  }
  else {
    uVar2 = (ulonglong)*(uint *)(param_5 + 1) << 3;
    if (0xffffffff < uVar2) {
      uVar2 = 0xffffffff;
      (*_DAT_)(0x161,0x51,0x16,7);
    }
    *param_11 = (int)uVar2;
    lVar1 = (*_DAT_)(uVar2 & 0xffffffff,param_2,0x1256b98,0x216,5);
    if (*param_10 != lVar1) {
      (*_DAT_)(*param_10,0);
    }
    *param_10 = lVar1;
    (**(code **)(*param_3 + 8))(param_3,lVar1,*param_11,&uStackX_8);
    if ((int)uStackX_8 != *param_11) {
      (*_DAT_)(1,0x13d2bb8,0x139b258,0x21d,0);
    }
  }
  return;
}

