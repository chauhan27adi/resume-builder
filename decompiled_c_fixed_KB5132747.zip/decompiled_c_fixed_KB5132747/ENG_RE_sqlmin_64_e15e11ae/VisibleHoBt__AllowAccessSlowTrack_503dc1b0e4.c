
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,longlong *param_3)

{
  undefined8 uVar1;
  undefined8 uVar2;
  code *pcVar3;
  ulonglong uVar4;
  uint6 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  longlong lVar9;
  longlong lVar10;
  longlong lVar11;
  undefined8 *puVar12;
  longlong lVar13;
  undefined8 unaff_RBX;
  longlong *plVar14;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  *(undefined8 *)(&stack0x00004c60 + lVar11) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00004cb0 + lVar11) = unaff_RBX;
  plVar14 = (longlong *)((ulonglong)(&stack0x00000058 + lVar11) & 0xffffffffffffffc0);
  plVar14[0x980] = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar11);
  if (param_2 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (((*(short *)(*(longlong *)(param_1 + 0x90) + 0x6b8) == 2) &&
      (lVar13 = *(longlong *)(*(longlong *)(param_1 + 0x90) + 0x65f0), lVar13 != 0)) &&
     (*(char *)(lVar13 + 0x1bc1) != '\0')) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((param_2 == 1) && ((*(byte *)(param_1 + 0x40) & 8) == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar13 = *(longlong *)(param_1 + 0x70);
  if (lVar13 == 0) {
    if (*(int *)(param_1 + 100) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1000bf;
    func_0x(plVar14 + 0x658);
    if (*(int *)(param_1 + 0x480) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((_DAT_ == *(short *)((longlong)param_3 + 0x2c)) &&
       (_DAT_ == *(int *)(param_3 + 5))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined4 *)(plVar14 + 4) = 0xc5a;
    lVar13 = _DAT_;
    plVar14[2] = _DAT_;
    (&stack0xffffffffffffffe8)[lVar11] = 5;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100118;
    puVar12 = (undefined8 *)(*_DAT_)(0x48,lVar13,0x2441c00,0xc5a);
    *plVar14 = (longlong)puVar12;
    if (puVar12 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar1 = *(undefined8 *)(param_1 + 0x84);
    uVar2 = *(undefined8 *)(*(longlong *)(param_1 + 0x90) + 0x710);
    puVar12[1] = 0;
    puVar12[2] = 0;
    puVar12[3] = 0;
    puVar12[4] = 0;
    *puVar12 = 0x23d9130;
    *(undefined2 *)((longlong)puVar12 + 0x46) = 0;
    puVar12[7] = uVar2;
    *(int *)(puVar12 + 8) = (int)uVar1;
    *(short *)((longlong)puVar12 + 0x44) = (short)((ulonglong)uVar1 >> 0x20);
    uVar6 = *(undefined4 *)((longlong)param_3 + 0x7c);
    uVar7 = *(undefined4 *)(param_3 + 0x10);
    uVar8 = *(undefined4 *)((longlong)param_3 + 0x84);
    *(undefined4 *)(param_1 + 0x70) = *(undefined4 *)(param_3 + 0xf);
    *(undefined4 *)(param_1 + 0x74) = uVar6;
    *(undefined4 *)(param_1 + 0x78) = uVar7;
    *(undefined4 *)(param_1 + 0x7c) = uVar8;
    pcVar3 = *(code **)(*param_3 + 0x158);
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10018a;
    (*pcVar3)(param_3,puVar12);
    LOCK();
    *(int *)(param_1 + 100) = *(int *)(param_1 + 100) + 1;
    UNLOCK();
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1001ac;
    func_0x(plVar14 + 0x7c0,0x1c0,8,0xc0320);
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1001cb;
    func_0x(plVar14 + 0x750,0x1c0,2,0xc0320);
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1001e7;
    func_0x(plVar14 + 0x6d8,0x1c0,2,0xc0320);
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100203;
    func_0x(plVar14 + 0x660,0x1c0,2,0xc0320);
LAB_:
    uVar4 = plVar14[0x980];
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100217;
    func_0x(uVar4 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar11));
    return;
  }
  lVar9 = param_3[0xf];
  lVar10 = param_3[0x10];
  *plVar14 = lVar9;
  plVar14[1] = lVar10;
  if (lVar9 == lVar13) {
    if (((int)plVar14[1] != *(int *)(param_1 + 0x78)) ||
       ((int)((ulonglong)plVar14[1] >> 0x20) != *(int *)(param_1 + 0x7c))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (param_2 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar5 = *(uint6 *)(param_1 + 0x84);
    pcVar3 = *(code **)(*param_3 + 0x2a8);
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100294;
    lVar13 = (*pcVar3)(param_3,(ulonglong)uVar5 << 0x10);
    if (lVar13 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(param_1 + 0x480) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(param_1 + 100) == 0) {
      LOCK();
      *(int *)(param_1 + 100) = *(int *)(param_1 + 100) + 1;
      UNLOCK();
      goto LAB_;
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

