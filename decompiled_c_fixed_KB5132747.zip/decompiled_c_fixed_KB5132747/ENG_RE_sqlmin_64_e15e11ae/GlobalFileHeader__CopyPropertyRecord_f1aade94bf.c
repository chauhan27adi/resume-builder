
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  byte bVar2;
  ushort uVar3;
  uint **ppuVar4;
  char cVar5;
  int iVar6;
  longlong lVar7;
  longlong *plVar8;
  ulonglong uVar9;
  longlong lVar10;
  code *UNRECOVERED_JUMPTABLE_00;
  uint uVar11;
  int iVar12;
  byte **ppbVar13;
  uint *puVar14;
  longlong unaff_GS_OFFSET;
  undefined auStack_cd8 [32];
  undefined8 uStack_cb8;
  uint *puStack_cb0;
  longlong *plStack_ca8;
  undefined uStack_ca0;
  uint uStack_c9c;
  uint uStack_c98;
  char cStack_c8c;
  char cStack_c8b;
  char cStack_c8a;
  undefined uStack_c89;
  char cStack_c88;
  ushort uStack_c86;
  int iStack_c70;
  int iStack_c68;
  int iStack_c60;
  int iStack_c58;
  short sStack_c54;
  undefined8 uStack_c50;
  undefined2 uStack_c48;
  ushort uStack_c38;
  ushort uStack_c30;
  ushort uStack_c28;
  ushort uStack_c20;
  ushort uStack_c18;
  ushort uStack_c10;
  char cStack_bf8;
  undefined4 uStack_bf0;
  uint uStack_be8;
  undefined4 uStack_be0;
  byte bStack_bdc;
  byte bStack_bdb;
  byte bStack_bda;
  byte bStack_bd9;
  undefined8 uStack_bd8;
  short sStack_bd0;
  byte bStack_bc8;
  byte bStack_bc7;
  byte bStack_bc6;
  undefined8 uStack_bc4;
  undefined4 uStack_bbc;
  undefined8 uStack_bb8;
  undefined4 uStack_bb0;
  uint uStack_bac;
  uint uStack_ba8;
  uint uStack_ba4;
  undefined8 uStack_ba0;
  ushort uStack_b98;
  undefined8 uStack_b90;
  ushort uStack_b88;
  undefined4 uStack_b80;
  undefined2 uStack_b7c;
  undefined4 uStack_b78;
  undefined2 uStack_b74;
  undefined4 uStack_b70;
  undefined2 uStack_b6c;
  undefined4 uStack_b68;
  undefined2 uStack_b64;
  undefined8 uStack_b60;
  longlong lStack_b58;
  undefined8 uStack_b50;
  ushort uStack_b48;
  ushort uStack_b40;
  short sStack_b3c;
  int iStack_b08;
  uint uStack_b00;
  uint uStack_af8;
  uint uStack_af0;
  uint uStack_ae8;
  uint uStack_ae0;
  uint uStack_ad8;
  uint uStack_ad0;
  uint uStack_acc;
  undefined auStack_ac8 [4];
  undefined4 uStack_ac4;
  uint uStack_ac0;
  uint uStack_ab8;
  uint uStack_ab0;
  undefined4 uStack_a98;
  short sStack_a94;
  undefined2 uStack_a90;
  undefined2 uStack_a88;
  short sStack_a80;
  longlong *plStack_a78;
  longlong *plStack_a70;
  longlong *plStack_a68;
  byte **ppbStack_a60;
  longlong lStack_a58;
  undefined8 uStack_a50;
  longlong *plStack_a40;
  undefined4 uStack_a28;
  undefined4 uStack_a24;
  undefined8 uStack_a08;
  undefined2 uStack_a00;
  undefined8 *puStack_9f8;
  uint *puStack_9f0;
  undefined4 uStack_9e8;
  undefined2 uStack_9e4;
  undefined8 uStack_9e0;
  ushort uStack_9d8;
  undefined8 uStack_9d0;
  undefined2 uStack_9c8;
  undefined auStack_9bc [4];
  undefined4 uStack_9b8;
  undefined auStack_9b4 [4];
  undefined4 uStack_9b0;
  uint uStack_9a8;
  int iStack_9a0;
  int iStack_99c;
  int iStack_998;
  undefined4 uStack_994;
  undefined auStack_990 [8];
  int iStack_988;
  int iStack_980;
  uint uStack_978;
  longlong lStack_940;
  undefined8 *puStack_930;
  uint *puStack_928;
  uint *puStack_920;
  undefined8 *puStack_908;
  undefined8 uStack_8c8;
  undefined2 uStack_8c0;
  undefined2 uStack_8be;
  longlong lStack_8b8;
  uint *puStack_8a0;
  uint *puStack_898;
  ushort *puStack_890;
  ushort *puStack_888;
  uint *puStack_880;
  longlong lStack_878;
  uint *puStack_870;
  uint *puStack_868;
  longlong lStack_860;
  longlong *plStack_858;
  longlong *plStack_850;
  longlong lStack_848;
  longlong lStack_840;
  undefined4 *puStack_838;
  undefined4 *puStack_830;
  undefined8 *puStack_828;
  uint *puStack_820;
  longlong lStack_818;
  longlong lStack_810;
  longlong lStack_808;
  longlong lStack_800;
  uint *puStack_7f8;
  longlong lStack_7f0;
  undefined4 *puStack_7e8;
  undefined4 *puStack_7e0;
  longlong lStack_7d8;
  undefined2 *puStack_7d0;
  uint **ppuStack_7c8;
  longlong *plStack_7c0;
  longlong *plStack_7b8;
  short **ppsStack_7b0;
  short **ppsStack_7a8;
  undefined8 *puStack_7a0;
  longlong lStack_798;
  longlong *plStack_790;
  longlong *plStack_788;
  short *psStack_780;
  short **ppsStack_778;
  short *psStack_770;
  short **ppsStack_768;
  uint *puStack_760;
  uint **ppuStack_758;
  longlong lStack_750;
  longlong lStack_748;
  longlong lStack_740;
  longlong lStack_738;
  undefined8 *puStack_730;
  longlong lStack_728;
  undefined4 *puStack_720;
  undefined4 *puStack_718;
  undefined8 *puStack_710;
  ushort *puStack_708;
  ushort *puStack_700;
  uint *puStack_6f8;
  longlong lStack_6f0;
  uint *puStack_6e8;
  uint *puStack_6e0;
  undefined8 *puStack_6d8;
  undefined8 uStack_6d0;
  longlong lStack_6c8;
  undefined *puStack_6c0;
  undefined *puStack_6b8;
  undefined *puStack_6b0;
  undefined *puStack_6a8;
  undefined *puStack_6a0;
  undefined *puStack_698;
  undefined4 *puStack_690;
  undefined4 *puStack_688;
  undefined8 *puStack_680;
  undefined4 *puStack_678;
  byte *pbStack_670;
  byte **ppbStack_668;
  byte **ppbStack_660;
  longlong lStack_658;
  byte **ppbStack_650;
  undefined4 *puStack_648;
  byte **ppbStack_640;
  short **ppsStack_638;
  byte *pbStack_630;
  byte **ppbStack_628;
  longlong lStack_620;
  byte *pbStack_618;
  longlong lStack_610;
  short *psStack_5e8;
  short **ppsStack_5e0;
  byte *pbStack_5d8;
  undefined *puStack_5d0;
  byte *pbStack_5c8;
  undefined *puStack_5c0;
  longlong lStack_480;
  longlong lStack_478;
  longlong *plStack_470;
  longlong lStack_468;
  longlong lStack_460;
  longlong lStack_458;
  longlong lStack_450;
  longlong lStack_448;
  ushort *puStack_440;
  ushort *puStack_438;
  uint *puStack_430;
  longlong lStack_428;
  uint uStack_420;
  undefined4 uStack_41c;
  undefined4 uStack_418;
  undefined auStack_408 [8];
  undefined2 uStack_400;
  undefined2 uStack_3fe;
  undefined4 uStack_3f8;
  uint **ppuStack_3f0;
  undefined *puStack_3e8;
  undefined8 uStack_3e0;
  uint *puStack_3d8;
  undefined4 uStack_3d0;
  undefined2 uStack_3cc;
  undefined2 uStack_3ca;
  longlong lStack_3c8;
  undefined4 uStack_3c0;
  undefined2 uStack_3bc;
  undefined2 uStack_3ba;
  longlong lStack_3b8;
  undefined4 uStack_3b0;
  undefined2 uStack_3ac;
  undefined2 uStack_3aa;
  short *psStack_3a8;
  int iStack_3a0;
  undefined2 uStack_39c;
  undefined2 uStack_39a;
  short *psStack_398;
  int iStack_390;
  undefined2 uStack_38c;
  undefined2 uStack_38a;
  undefined8 uStack_388;
  undefined4 uStack_380;
  undefined2 uStack_37c;
  undefined2 uStack_37a;
  undefined auStack_378 [448];
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined8 uStack_1b0;
  uint uStack_1a8;
  short sStack_1a4;
  int iStack_1a2;
  undefined uStack_19e;
  undefined uStack_19d;
  ushort uStack_150;
  undefined auStack_14e [2];
  undefined4 uStack_14c;
  byte *pbStack_148;
  byte **ppbStack_140;
  undefined8 uStack_132;
  undefined2 uStack_12a;
  undefined2 uStack_128;
  undefined6 uStack_126;
  undefined4 uStack_11c;
  undefined auStack_118 [16];
  undefined auStack_108 [8];
  undefined8 uStack_100;
  undefined8 uStack_f8;
  undefined6 uStack_f0;
  undefined2 uStack_ea;
  undefined6 uStack_e8;
  undefined2 uStack_e2;
  undefined8 uStack_e0;
  undefined auStack_d8 [16];
  undefined auStack_c8 [16];
  undefined auStack_b8 [16];
  undefined8 uStack_a8;
  short asStack_a0 [24];
  short asStack_70 [24];
  ulonglong uStack_40;
  
  uStack_6d0 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)auStack_cd8;
  uStack_150 = -1;
  lVar10 = 0;
  pbStack_148 = (byte *)0x0;
  iVar12 = 0;
  uStack_14c = 0;
  uStack_132 = 0;
  uStack_128 = 0;
  uStack_126 = 0;
  ppbStack_140 = (byte **)0x0;
  uStack_11c = 0xffffffff;
  plStack_a40 = (longlong *)0x0;
  plStack_ca8 = (longlong *)0x0;
  uStack_ca0 = 0;
  uStack_c9c = 0;
  sStack_c54 = *(short *)(param_1 + 0x20);
  iStack_c58 = 0;
  uStack_b50 = param_2;
  uStack_a50 = param_3;
  lVar7 = func_0x
                    (_DAT_,*(uint *)(param_1 + 0x60) & 0xffff,
                     *(uint *)(param_1 + 0x60) >> 0x10);
  uStack_a90 = *(undefined2 *)(param_1 + 0x20);
  lStack_480 = func_0x(*(undefined8 *)(lVar7 + 0x6a0),uStack_a90,1);
  if (lStack_480 == param_1) {
    uStack_be0 = 0;
    uStack_41c = 0;
    uStack_418 = 0;
    cStack_bf8 = *_DAT_;
    if ((cStack_bf8 != '\0') && (bStack_bdc = DAT_ >> 7, -1 < (char)DAT_)) {
      iStack_b08 = 0;
      lStack_478 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      plStack_470 = (longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)(lStack_478 + (ulonglong)*_DAT_ * 8));
      lStack_468 = *plStack_470;
      if ((lStack_468 == 0) ||
         (lStack_940 = **(longlong **)(lStack_468 + 0x38), lStack_460 = lStack_940, lStack_940 == 0)
         ) {
        lStack_940 = 0;
      }
      else {
        iStack_b08 = (*_DAT_)(lStack_940,0x337);
        if (iStack_b08 != 0) goto LAB_;
      }
      lStack_458 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      lStack_450 = (ulonglong)*_DAT_ +
                   *(longlong *)(lStack_458 + (ulonglong)*_DAT_ * 8);
      lStack_448 = *(longlong *)(lStack_450 + 8);
      if (lStack_448 != 0) {
        lVar10 = *(longlong *)(lStack_448 + 0x60);
      }
    }
LAB_:
    lStack_8b8 = *(longlong *)(lVar7 + 0x728);
    puStack_9f0 = &uStack_420;
    lStack_b58 = lVar10;
LAB_:
    uStack_bac = 0;
    if (plStack_ca8 != (longlong *)0x0) {
      puStack_440 = (ushort *)((longlong)plStack_ca8 + 0x62);
      uStack_c38 = *puStack_440;
      if (((uStack_c38 & 0x400) == 0) || ((short)uStack_c9c < 3)) {
        iStack_c70 = (int)(short)uStack_c9c;
        plStack_a78 = plStack_ca8;
        uStack_c30 = *puStack_440;
        puStack_438 = puStack_440;
        if (((byte)uStack_c30 >> 3 & 1) != 0) {
          if (iStack_c70 == 3) {
            iStack_c70 = 4;
          }
          else if (iStack_c70 < 2) goto LAB_;
          puStack_430 = (uint *)((longlong)plStack_ca8 + 100);
          uStack_b00 = *puStack_430;
          if ((((uStack_b00 & 8) != 0) && (lVar10 = plStack_ca8[0x12], lVar10 != 0)) &&
             (lStack_428 = lVar10, *(longlong *)(lVar10 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(lVar10 + 0x758),plStack_ca8,iStack_c70);
          }
        }
LAB_:
        bStack_bdb = DAT_ >> 7;
        if ((char)DAT_ < '\0') {
          puVar14 = (uint *)((longlong)plStack_a78 + 100);
          uStack_af8 = *puVar14;
          puStack_8a0 = puVar14;
          if ((((uStack_af8 & 8) != 0) && (2 < iStack_c70)) &&
             ((uStack_af0 = *puVar14, puStack_898 = puVar14, (uStack_af0 & 0xc0000000) != 0x40000000
              && (*plStack_a78 != 0)))) {
            uStack_9b8 = 2;
            iVar6 = (*_DAT_)(*plStack_a78,0x2000,2,auStack_9b4);
            if (iVar6 != 0) {
              LOCK();
              *puVar14 = *puVar14 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar14 = *puVar14 | 0x40000000;
              UNLOCK();
            }
          }
        }
        plVar8 = plStack_a78;
        iVar6 = iStack_c70;
        func_0x(plStack_a78 + 0x13,iStack_c70);
        if ((_DAT_ != 0) && (bStack_bda = DAT_ >> 1, (bStack_bda & 1) != 0)) {
          func_0x(plVar8,0,iVar6);
        }
        uStack_c9c = uStack_c9c & 0xffff0000;
        plStack_ca8 = (longlong *)0x0;
      }
      else {
        func_0x(&plStack_ca8);
      }
    }
    if ((*(longlong *)(lVar7 + 0x728) != 0) &&
       (func_0x(&plStack_ca8,&iStack_c58,lVar7), plStack_ca8 != (longlong *)0x0)) {
      puStack_890 = (ushort *)((longlong)plStack_ca8 + 0x62);
      uStack_c28 = *puStack_890;
      if (((uStack_c28 & 0x400) == 0) || ((short)uStack_c9c < 3)) {
        iStack_c68 = (int)(short)uStack_c9c;
        plStack_a70 = plStack_ca8;
        uStack_c20 = *puStack_890;
        puStack_888 = puStack_890;
        if (((byte)uStack_c20 >> 3 & 1) != 0) {
          if (iStack_c68 == 3) {
            iStack_c68 = 4;
          }
          else if (iStack_c68 < 2) goto LAB_;
          puStack_880 = (uint *)((longlong)plStack_ca8 + 100);
          uStack_ae8 = *puStack_880;
          if ((((uStack_ae8 & 8) != 0) && (lVar10 = plStack_ca8[0x12], lVar10 != 0)) &&
             (lStack_878 = lVar10, *(longlong *)(lVar10 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(lVar10 + 0x758),plStack_ca8,iStack_c68);
          }
        }
LAB_:
        bStack_bd9 = DAT_ >> 7;
        if ((char)DAT_ < '\0') {
          puVar14 = (uint *)((longlong)plStack_a70 + 100);
          uStack_ae0 = *puVar14;
          puStack_870 = puVar14;
          if ((((uStack_ae0 & 8) != 0) && (2 < iStack_c68)) &&
             ((uStack_ad8 = *puVar14, puStack_868 = puVar14, (uStack_ad8 & 0xc0000000) != 0x40000000
              && (*plStack_a70 != 0)))) {
            uStack_9b0 = 2;
            iVar6 = (*_DAT_)(*plStack_a70,0x2000,2,auStack_9bc);
            if (iVar6 != 0) {
              LOCK();
              *puVar14 = *puVar14 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar14 = *puVar14 | 0x40000000;
              UNLOCK();
            }
          }
        }
        plVar8 = plStack_a70;
        iVar6 = iStack_c68;
        func_0x(plStack_a70 + 0x13,iStack_c68);
        if ((_DAT_ != 0) && (bStack_bc8 = DAT_ >> 1, (bStack_bc8 & 1) != 0)) {
          func_0x(plVar8,0,iVar6);
        }
        uStack_c9c = uStack_c9c & 0xffff0000;
        plStack_ca8 = (longlong *)0x0;
      }
      else {
        func_0x(&plStack_ca8);
      }
    }
    puStack_cb0 = puStack_9f0;
    uStack_cb8 = CONCAT44(uStack_cb8._4_4_,2);
    plStack_ca8 = (longlong *)func_0x(_DAT_,lVar7,&iStack_c58,&uStack_bac);
    if (lStack_b58 != 0) {
      lStack_860 = *plStack_ca8;
      plStack_858 = (longlong *)(lStack_b58 + 0x500);
      plStack_850 = plStack_858 + (ulonglong)(*(uint *)plStack_858 & 0xf) + 1;
      if (*plStack_850 != lStack_860) {
        *plStack_850 = lStack_860;
        *plStack_858 = *plStack_858 + 1;
      }
    }
    uVar11 = uStack_bac >> 3 & 1;
    uStack_c9c = uVar11 << 0x18 | uStack_c9c & 0xff0002 | 2;
    uStack_c98 = uStack_bac >> 4 & 1 | uStack_c98 & 0xffffff00;
    if (((lStack_8b8 != 0) && (lStack_b58 != 0)) && (lStack_b58 == *(longlong *)(lVar7 + 0x1c38))) {
      lStack_848 = lStack_8b8 + 0x59b8;
      *(longlong *)(lStack_8b8 + 0x5b28) = *(longlong *)(lStack_8b8 + 0x5b28) + 1;
      uStack_9a8 = uVar11;
      if (puStack_9f0[1] != 0) {
        *(longlong *)(lStack_8b8 + 0x5b30) = *(longlong *)(lStack_8b8 + 0x5b30) + 1;
        *(longlong *)(lStack_8b8 + 0x5b38) =
             *(longlong *)(lStack_8b8 + 0x5b38) + (ulonglong)*puStack_9f0;
        if (uVar11 != 0) {
          *(longlong *)(lStack_8b8 + 0x5b40) = *(longlong *)(lStack_8b8 + 0x5b40) + 1;
          *(longlong *)(lStack_8b8 + 0x5b48) =
               *(longlong *)(lStack_8b8 + 0x5b48) + (ulonglong)*puStack_9f0;
        }
      }
    }
    cVar5 = func_0x(lVar7);
    if ((cVar5 == '\0') || (*(char *)(lVar7 + 0x2050) == '\0')) goto LAB_;
    if (iStack_c58 == 0) {
LAB_:
      uStack_c89 = 1;
      goto LAB_;
    }
    uStack_b60 = (longlong *)CONCAT26(uStack_b60._6_2_,0x100000009);
    if ((iStack_c58 == 9) && (sStack_c54 == 1)) goto LAB_;
    uStack_c89 = 0;
    lVar10 = *plStack_ca8;
    cStack_c8c = '\0';
    lStack_840 = lVar10;
    if (*(short *)(lVar10 + 0x24) == 0) {
LAB_:
      uStack_ba0 = *(undefined8 *)(lVar10 + 0x28);
      uStack_b98 = *(ushort *)(lVar10 + 0x30);
    }
    else {
      cVar5 = *(char *)(lVar10 + 1);
      if ((((cVar5 == '\v') || (cVar5 == '\b')) || (cVar5 == '\t')) &&
         (*(int *)(lVar10 + 0x18) == 99)) {
        puStack_838 = &uStack_b70;
        puStack_830 = (undefined4 *)(lVar10 + 0x20);
        uStack_b70 = *puStack_830;
        uStack_b6c = *(undefined2 *)(lVar10 + 0x24);
        cVar5 = func_0x(&uStack_b70);
        if (cVar5 == '\0') goto LAB_;
        cStack_c8c = '\x01';
      }
      else {
LAB_:
        cStack_c8c = '\0';
      }
      if (cStack_c8c == '\0') goto LAB_;
      func_0x(lVar10,&uStack_ba0);
    }
    puStack_828 = &uStack_ba0;
    puVar1 = (undefined8 *)(lVar7 + 0x20fc);
    puVar14 = (uint *)(lVar7 + 0x2108);
    uStack_ba8 = *puVar14;
    do {
      uStack_ad0 = uStack_ba8 & 0xfffffffe;
      uStack_bb8 = *puVar1;
      uStack_bb0 = *(undefined4 *)(lVar7 + 0x2104);
      LOCK();
      UNLOCK();
      uStack_ba8 = *puVar14;
    } while (uStack_ad0 != uStack_ba8);
    puStack_930 = puVar1;
    puStack_928 = puVar14;
    puStack_820 = puVar14;
    if ((uint)uStack_ba0 <= (uint)uStack_bb8) {
      if ((uint)uStack_bb8 != (uint)uStack_ba0) goto LAB_;
      uVar11 = (uint)((ulonglong)uStack_bb8 >> 0x20);
      if ((uStack_ba0._4_4_ <= uVar11) &&
         ((uVar11 != uStack_ba0._4_4_ || (uStack_b98 <= (ushort)uStack_bb0)))) goto LAB_;
    }
    if (*(char *)(lVar7 + 0x6ac8) != '\0') {
LAB_:
      lStack_750 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      lStack_748 = (ulonglong)*_DAT_ +
                   *(longlong *)(lStack_750 + (ulonglong)*_DAT_ * 8);
      lStack_740 = *(longlong *)(lStack_748 + 8);
      lStack_738 = *(longlong *)(lStack_740 + 0x60);
      if ((lStack_738 == *(longlong *)(lVar7 + 0x2120)) ||
         (cVar5 = func_0x(lVar7), cVar5 != '\0')) goto LAB_;
      if (lStack_b58 == 0) {
        lStack_b58 = func_0x();
      }
      puStack_730 = &uStack_c50;
      lVar10 = *plStack_ca8;
      cStack_c8a = '\0';
      lStack_728 = lVar10;
      if (*(short *)(lVar10 + 0x24) == 0) {
LAB_:
        uStack_c50 = *(undefined8 *)(lVar10 + 0x28);
        uStack_c48 = *(undefined2 *)(lVar10 + 0x30);
      }
      else {
        cVar5 = *(char *)(lVar10 + 1);
        if ((((cVar5 == '\v') || (cVar5 == '\b')) || (cVar5 == '\t')) &&
           (*(int *)(lVar10 + 0x18) == 99)) {
          puStack_720 = &uStack_b80;
          puStack_718 = (undefined4 *)(lVar10 + 0x20);
          uStack_b80 = *puStack_718;
          uStack_b7c = *(undefined2 *)(lVar10 + 0x24);
          cVar5 = func_0x(&uStack_b80);
          if (cVar5 == '\0') goto LAB_;
          cStack_c8a = '\x01';
        }
        else {
LAB_:
          cStack_c8a = '\0';
        }
        if (cStack_c8a == '\0') goto LAB_;
        func_0x(lVar10,&uStack_c50);
      }
      puStack_710 = &uStack_c50;
      uStack_8be = 0;
      uStack_8c8 = uStack_c50;
      uStack_8c0 = uStack_c48;
      if (plStack_ca8 != (longlong *)0x0) {
        puStack_708 = (ushort *)((longlong)plStack_ca8 + 0x62);
        uStack_c18 = *puStack_708;
        if (((uStack_c18 & 0x400) == 0) || ((short)uStack_c9c < 3)) {
          iStack_c60 = (int)(short)uStack_c9c;
          plStack_a68 = plStack_ca8;
          uStack_c10 = *puStack_708;
          puStack_700 = puStack_708;
          if (((byte)uStack_c10 >> 3 & 1) != 0) {
            if (iStack_c60 == 3) {
              iStack_c60 = 4;
            }
            else if (iStack_c60 < 2) goto LAB_;
            puStack_6f8 = (uint *)((longlong)plStack_ca8 + 100);
            uStack_ac0 = *puStack_6f8;
            if ((((uStack_ac0 & 8) != 0) && (lVar10 = plStack_ca8[0x12], lVar10 != 0)) &&
               (lStack_6f0 = lVar10, *(longlong *)(lVar10 + 0x758) != 0)) {
              func_0x(*(undefined8 *)(lVar10 + 0x758),plStack_ca8,iStack_c60);
            }
          }
LAB_:
          bStack_bc7 = DAT_ >> 7;
          if ((char)DAT_ < '\0') {
            puVar14 = (uint *)((longlong)plStack_a68 + 100);
            uStack_ab8 = *puVar14;
            puStack_6e8 = puVar14;
            if (((((uStack_ab8 & 8) != 0) && (2 < iStack_c60)) &&
                (uStack_ab0 = *puVar14, puStack_6e0 = puVar14,
                (uStack_ab0 & 0xc0000000) != 0x40000000)) && (*plStack_a68 != 0)) {
              uStack_994 = 2;
              iVar6 = (*_DAT_)(*plStack_a68,0x2000,2,auStack_990);
              if (iVar6 != 0) {
                LOCK();
                *puVar14 = *puVar14 & 0x3fffffff;
                UNLOCK();
                LOCK();
                *puVar14 = *puVar14 | 0x40000000;
                UNLOCK();
              }
            }
          }
          plVar8 = plStack_a68;
          iVar6 = iStack_c60;
          func_0x(plStack_a68 + 0x13,iStack_c60);
          if ((_DAT_ != 0) && (bStack_bc6 = DAT_ >> 1, (bStack_bc6 & 1) != 0)) {
            func_0x(plVar8,0,iVar6);
          }
          uStack_c9c = uStack_c9c & 0xffff0000;
          plStack_ca8 = (longlong *)0x0;
        }
        else {
          func_0x(&plStack_ca8);
        }
      }
      puStack_6d8 = &uStack_9d0;
      puStack_908 = &uStack_a08;
      uStack_cb8 = 0;
      uStack_a08 = uStack_c50;
      uStack_a00 = uStack_c48;
      uStack_9d0 = uStack_c50;
      uStack_9c8 = uStack_c48;
      func_0x(*(undefined8 *)(lVar7 + 0x728),&uStack_a08,4);
      goto LAB_;
    }
    lStack_818 = *(longlong *)(unaff_GS_OFFSET + 0x58);
    lStack_810 = (ulonglong)*_DAT_ +
                 *(longlong *)(lStack_818 + (ulonglong)*_DAT_ * 8);
    lStack_808 = *(longlong *)(lStack_810 + 8);
    lStack_800 = *(longlong *)(lStack_808 + 0x60);
    if ((lStack_800 == *(longlong *)(lVar7 + 0x2120)) ||
       (cVar5 = func_0x(lVar7), cVar5 != '\0')) goto LAB_;
    uStack_ba4 = *puVar14;
    puStack_920 = (uint *)(lVar7 + 0x2108);
    do {
      uStack_acc = uStack_ba4 & 0xfffffffe;
      uStack_bc4 = *puVar1;
      uStack_bbc = *(undefined4 *)(lVar7 + 0x2104);
      LOCK();
      UNLOCK();
      uStack_ba4 = *puStack_920;
    } while (uStack_acc != uStack_ba4);
    uVar3 = (ushort)uStack_bbc;
    uStack_9d8 = (ushort)uStack_bbc;
    lVar10 = *plStack_ca8;
    cStack_c8b = '\0';
    puStack_9f8 = puVar1;
    uStack_9e0 = uStack_bc4;
    puStack_7f8 = puVar14;
    lStack_7f0 = lVar10;
    if (*(short *)(lVar10 + 0x24) == 0) {
LAB_:
      uStack_b90 = *(undefined8 *)(lVar10 + 0x28);
      uStack_b88 = *(ushort *)(lVar10 + 0x30);
    }
    else {
      cVar5 = *(char *)(lVar10 + 1);
      if ((((cVar5 == '\v') || (cVar5 == '\b')) || (cVar5 == '\t')) &&
         (*(int *)(lVar10 + 0x18) == 99)) {
        puStack_7e8 = &uStack_b68;
        puStack_7e0 = (undefined4 *)(lVar10 + 0x20);
        uStack_b68 = *puStack_7e0;
        uStack_b64 = *(undefined2 *)(lVar10 + 0x24);
        cVar5 = func_0x(&uStack_b68);
        if (cVar5 == '\0') goto LAB_;
        cStack_c8b = '\x01';
      }
      else {
LAB_:
        cStack_c8b = '\0';
      }
      if (cStack_c8b == '\0') goto LAB_;
      func_0x(lVar10,&uStack_b90);
    }
    if ((uint)uStack_bc4 < (uint)uStack_b90) {
LAB_:
      lVar10 = *(longlong *)(lVar7 + 0x6b0);
      lStack_7d8 = lVar10;
      func_0x(&uStack_b90,asStack_a0,auStack_ac8);
      func_0x(&uStack_9e0,asStack_70,auStack_ac8);
      uStack_a28 = 0x1d;
      uStack_a24 = 0x10000;
      if ((_DAT_ & 0x10000) == 0) goto LAB_;
      uStack_a88 = 6;
      puStack_7d0 = &uStack_400;
      uStack_400 = 0;
      uStack_3fe = 6;
      uStack_3f8 = 0;
      ppuStack_3f0 = &puStack_3d8;
      puStack_3e8 = auStack_378;
      uStack_1b8 = 0;
      uStack_1b4 = 0;
      uStack_3e0 = 0;
      uStack_1b0 = 0;
      ppuStack_7c8 = &puStack_3d8;
      puStack_3d8 = &uStack_1a8;
      uStack_3d0 = 0x34;
      uStack_3cc = 5;
      uStack_3ca = 0;
      plStack_7c0 = &lStack_3c8;
      plStack_7b8 = &lStack_3b8;
      ppsStack_7b0 = &psStack_3a8;
      psStack_3a8 = (short *)0x0;
      iStack_3a0 = 0;
      uStack_39c = 7;
      uStack_39a = 0;
      ppsStack_7a8 = &psStack_398;
      psStack_398 = (short *)0x0;
      iStack_390 = 0;
      uStack_38c = 8;
      uStack_38a = 0;
      puStack_7a0 = &uStack_388;
      uStack_388 = 0;
      uStack_380 = 0;
      uStack_37c = 9;
      uStack_37a = 0;
      uStack_1a8 = (uint)*(ushort *)(lVar7 + 0x6b8);
      sStack_1a4 = sStack_c54;
      iStack_1a2 = iStack_c58;
      uStack_19e = 0xff;
      lStack_798 = *plStack_ca8;
      uStack_19d = *(undefined *)(lStack_798 + 1);
      plStack_790 = &lStack_3c8;
      lStack_3c8 = lVar10 + 0x254;
      uStack_3c0 = 0x10;
      uStack_3bc = 5;
      uStack_3ba = 0;
      plStack_788 = &lStack_3b8;
      lStack_3b8 = lVar10 + 0x244;
      uStack_3b0 = 0x10;
      uStack_3ac = 6;
      uStack_3aa = 0;
      psStack_780 = asStack_a0;
      lVar7 = -1;
      do {
        lVar7 = lVar7 + 1;
      } while (asStack_a0[lVar7] != 0);
      iStack_9a0 = (int)lVar7 * 2;
      ppsStack_778 = &psStack_3a8;
      psStack_3a8 = asStack_a0;
      iStack_3a0 = iStack_9a0;
      uStack_39c = 7;
      uStack_39a = 0;
      psStack_770 = asStack_70;
      lVar7 = -1;
      do {
        lVar7 = lVar7 + 1;
      } while (asStack_70[lVar7] != 0);
      iStack_99c = (int)lVar7 * 2;
      ppsStack_768 = &psStack_398;
      psStack_398 = asStack_70;
      uStack_38c = 8;
      uStack_38a = 0;
      uStack_ac4 = 0;
      iStack_390 = iStack_99c;
      puStack_760 = (uint *)(**(code **)(_DAT_ + 0x10))(lVar10,&uStack_ac4);
      ppuVar4 = ppuStack_3f0;
      if (puStack_760 != (uint *)0x0) {
        lVar10 = -1;
        do {
          lVar10 = lVar10 + 1;
        } while (*(short *)((longlong)puStack_760 + lVar10 * 2) != 0);
        iVar12 = (int)lVar10 * 2;
      }
      ppuStack_758 = ppuStack_3f0 + 10;
      iStack_998 = iVar12;
      *ppuStack_758 = puStack_760;
      *(int *)(ppuVar4 + 0xb) = iVar12;
      *(undefined2 *)((longlong)ppuVar4 + 0x5c) = 9;
      *(undefined2 *)((longlong)ppuVar4 + 0x5e) = 0;
      func_0x(auStack_408);
      uStack_b60 = plStack_ca8;
      plStack_a40 = plStack_ca8;
      plVar8 = plStack_ca8;
      goto LAB_;
    }
    if ((uint)uStack_bc4 == (uint)uStack_b90) {
      uVar11 = (uint)((ulonglong)uStack_b90 >> 0x20);
      if ((uStack_bc4._4_4_ < uVar11) || ((uStack_bc4._4_4_ == uVar11 && (uVar3 < uStack_b88))))
      goto LAB_;
    }
LAB_:
    uStack_b60 = plStack_ca8;
    plStack_a40 = plStack_ca8;
    plVar8 = plStack_ca8;
  }
  else {
    uStack_be0 = 1;
    plVar8 = (longlong *)func_0x(_DAT_,1,1,1);
    puStack_908 = (undefined8 *)0x0;
    uStack_b60 = plVar8;
    plStack_a40 = plVar8;
    func_0x(param_1,0,*plVar8,&iStack_c58);
  }
LAB_:
  lVar10 = *plVar8;
  uStack_11c = 0;
  lStack_6c8 = lVar10;
  if (-1 < *(char *)(lVar10 + 2)) {
    ppbStack_a60 = (byte **)0x0;
    goto LAB_;
  }
  if ((uStack_150 == 0) || (ppbVar13 = ppbStack_140, ppbStack_140 == (byte **)0x0)) {
    puStack_6c0 = auStack_118;
    uStack_f0 = 0;
    uStack_e2 = 0;
    auStack_c8 = ZEXT816(0);
    puStack_6b8 = auStack_118;
    auStack_118 = ZEXT816(0);
    puStack_6b0 = auStack_108;
    stack0xfffffffffffffefa = SUB1614(ZEXT816(0),2);
    auStack_108._0_2_ = 0xffff;
    uStack_100 = 0;
    uStack_ea = 0;
    uStack_e8 = 0;
    uStack_e0 = 0;
    uStack_f8 = 0;
    puStack_6a8 = auStack_d8 + 8;
    auStack_d8 = ZEXT816(0);
    puStack_6a0 = auStack_b8;
    auStack_b8._0_12_ = ZEXT812(0);
    auStack_b8._12_4_ = 0;
    puStack_698 = auStack_b8 + 0xc;
    uStack_a8 = 0;
    ppbVar13 = (byte **)auStack_118;
  }
  cStack_c88 = '\0';
  ppbStack_a60 = ppbVar13;
  if (*(short *)(lVar10 + 0x24) == 0) {
LAB_:
    uStack_bd8 = *(undefined8 *)(lVar10 + 0x28);
    sStack_bd0 = *(short *)(lVar10 + 0x30);
  }
  else {
    cVar5 = *(char *)(lVar10 + 1);
    if ((((cVar5 == '\v') || (cVar5 == '\b')) || (cVar5 == '\t')) && (*(int *)(lVar10 + 0x18) == 99)
       ) {
      puStack_690 = &uStack_b78;
      puStack_688 = (undefined4 *)(lVar10 + 0x20);
      uStack_b78 = *puStack_688;
      uStack_b74 = *(undefined2 *)(lVar10 + 0x24);
      cVar5 = func_0x(&uStack_b78);
      if (cVar5 == '\0') goto LAB_;
      cStack_c88 = '\x01';
    }
    else {
LAB_:
      cStack_c88 = '\0';
    }
    if (cStack_c88 == '\0') goto LAB_;
    func_0x(lVar10,&uStack_bd8);
  }
  puStack_680 = &uStack_bd8;
  puStack_678 = (undefined4 *)(lVar10 + 0x20);
  pbStack_670 = (byte *)(lVar10 + 0x60);
  if (((pbStack_670 == *ppbVar13) &&
      (ppbStack_660 = ppbVar13 + 0xc, sStack_bd0 == *(short *)(ppbVar13 + 0xd))) &&
     (((int)uStack_bd8 == *(int *)ppbStack_660 &&
      (uStack_bd8._4_4_ == *(int *)((longlong)ppbVar13 + 100))))) {
    lStack_658 = (longlong)ppbVar13 + 0x6c;
  }
  *ppbVar13 = pbStack_670;
  ppbStack_650 = ppbVar13 + 0xc;
  sStack_a80 = sStack_bd0;
  iStack_988 = uStack_bd8._4_4_;
  iStack_980 = (int)uStack_bd8;
  *(int *)ppbStack_650 = (int)uStack_bd8;
  *(int *)((longlong)ppbVar13 + 100) = uStack_bd8._4_4_;
  *(short *)(ppbVar13 + 0xd) = sStack_bd0;
  puStack_648 = (undefined4 *)((longlong)ppbVar13 + 0x6c);
  *puStack_648 = *puStack_678;
  *(undefined2 *)(ppbVar13 + 0xe) = *(undefined2 *)(lVar10 + 0x24);
  *(undefined2 *)((longlong)ppbVar13 + 0x72) = 0;
  uVar9 = (ulonglong)*pbStack_670;
  uStack_b48 = (ushort)*pbStack_670;
  uStack_9e8 = *(undefined4 *)(uVar9 * 6 + 0x11a1320);
  uStack_9e4 = *(undefined2 *)(uVar9 * 6 + 0x11a1324);
  uStack_a98 = *(undefined4 *)(uVar9 * 6 + 0x11a1320);
  uStack_c86 = *(short *)(uVar9 * 6 + 0x11a1324);
  lStack_a58 = lVar10 + 99;
  ppbStack_640 = ppbVar13 + 2;
  *(undefined2 *)ppbStack_640 = 0xffff;
  ppbVar13[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar13 + 0x2e) = 0;
  ppbVar13[7] = (byte *)0x0;
  ppbVar13[4] = (byte *)0x0;
  ppsStack_638 = (short **)(ppbVar13 + 9);
  *ppsStack_638 = (short *)0x0;
  ppbVar13[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar13 + 0xb) = 0;
  sStack_a94 = uStack_c86;
  ppbStack_668 = ppbVar13;
  if ((**ppbVar13 & 2) != 0) {
    pbStack_630 = pbStack_670 + (short)uStack_c86;
    bVar2 = *pbStack_630;
    uStack_b40 = (ushort)(bVar2 & 1);
    *(ushort *)ppbStack_640 = uStack_b40;
    lStack_620 = (longlong)ppbVar13 + 0x12;
    ppbStack_628 = ppbStack_640;
    if ((bVar2 & 1) != 0) {
      ppbVar13[3] = pbStack_630;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_630 & 0x1c) + 0x102ee4)
                              * 4 + 0x102ed4) - 0x13f7af0);
      lStack_610 = lStack_620;
                    /* WARNING: Could not emulate address calculation at 0x00101967 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
    uStack_bf0 = 0;
    ppbVar13[3] = pbStack_630;
    *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
    *(undefined4 *)((longlong)ppbVar13 + 0x36) = 0;
    pbStack_618 = ppbVar13[3];
                    /* WARNING: Could not emulate address calculation at 0x00101891 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_618 & 0xe) * 4 + 0x102e98) - 0x13f7af0)
    )();
    return;
  }
  if ((**ppbVar13 & 4) != 0) {
    uStack_a98._2_2_ = (short)((uint)uStack_a98 >> 0x10);
    if (uStack_a98._2_2_ == 0) {
      uVar9 = (ulonglong)(short)uStack_c86;
    }
    else {
      uVar9 = (ulonglong)*(ushort *)(lVar10 + 0x61 + (longlong)uStack_a98._2_2_ * 2);
    }
    psStack_5e8 = (short *)(pbStack_670 + uVar9);
    *ppsStack_638 = psStack_5e8;
    sStack_b3c = *psStack_5e8;
    ppbVar13[10] = (byte *)(psStack_5e8 + 1);
    *(short *)(ppbVar13 + 0xb) = (sStack_b3c + 1) * 2;
    ppsStack_5e0 = ppsStack_638;
  }
  if (ppbVar13[1] != (byte *)0x0) {
    func_0x(ppbVar13[1],ppbVar13);
  }
LAB_:
  uStack_be8 = (uint)*(ushort *)(lVar10 + 0xe);
  pbStack_5d8 = (byte *)((ulonglong)*(ushort *)(lVar10 + 0x1ffe) + lVar10);
  uStack_c86 = (ushort)(*pbStack_5d8 & 1);
  puStack_5d0 = auStack_14e;
  uStack_978 = uStack_be8;
  uStack_150 = uStack_c86;
  pbStack_148 = pbStack_5d8;
  if ((*pbStack_5d8 & 1) != 0) {
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_5d8 & 0x1c) + 0x102f50) *
                            4 + 0x102f40) - 0x13f7af0);
    puStack_5c0 = puStack_5d0;
                    /* WARNING: Could not emulate address calculation at 0x00101d3b */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,0x1122a40,pbStack_5d8);
    return;
  }
  uStack_14c = 0;
  uStack_12a = 0;
  uStack_128 = 0;
  pbStack_5c8 = pbStack_5d8;
                    /* WARNING: Could not emulate address calculation at 0x00101c81 */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_5d8 & 0xe) * 4 + 0x102f04) - 0x13f7af0))
            ();
  return;
}

