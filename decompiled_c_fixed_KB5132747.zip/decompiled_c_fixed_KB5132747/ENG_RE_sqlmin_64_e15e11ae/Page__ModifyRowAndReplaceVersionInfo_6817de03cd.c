
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                 undefined8 param_9)

{
  byte *pbVar1;
  byte *pbVar2;
  longlong lVar3;
  undefined4 uVar4;
  undefined auVar5 [16];
  undefined8 uVar6;
  char cVar7;
  longlong lVar8;
  code *UNRECOVERED_JUMPTABLE_00;
  ulonglong uVar9;
  undefined2 auStackX_10 [2];
  undefined4 uStackX_14;
  undefined8 auStackX_18 [2];
  undefined8 uStack_20f0;
  undefined2 uStack_20e8;
  undefined4 uStack_20e0;
  undefined4 uStack_20d8;
  undefined8 uStack_20d0;
  undefined4 uStack_20c8;
  int iStack_20c4;
  longlong lStack_20c0;
  undefined8 uStack_20b8;
  undefined2 uStack_20b0;
  undefined4 uStack_20ac;
  byte *pbStack_20a8;
  undefined8 uStack_20a0;
  undefined8 uStack_2092;
  undefined2 uStack_208a;
  undefined2 uStack_2088;
  undefined6 uStack_2086;
  int iStack_207c;
  undefined auStack_2078 [16];
  undefined auStack_2068 [8];
  undefined8 uStack_2060;
  undefined8 uStack_2058;
  undefined6 uStack_2050;
  undefined2 uStack_204a;
  undefined6 uStack_2048;
  undefined2 uStack_2042;
  undefined2 uStack_2040;
  undefined6 uStack_203e;
  undefined8 uStack_2038;
  short *psStack_2030;
  short *psStack_2028;
  short sStack_2020;
  undefined6 uStack_201e;
  undefined auStack_2018 [8];
  undefined8 uStack_2010;
  undefined8 uStack_2008;
  ulonglong uStack_58;
  undefined8 uStack_48;
  
  uStack_48 = 0x10001f;
  uStack_20e0 = param_4;
  iStack_20c4 = param_2;
  uStack_20c8 = param_3;
  lVar8 = func_0x();
  lVar8 = -lVar8;
  uStack_58 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar8);
  uStack_20d8 = param_5;
  uStack_20d0 = param_6;
  uStack_20b8 = param_9;
  uStack_20b0 = 0xffff;
  pbStack_20a8 = (byte *)0x0;
  uStack_20ac = 0;
  uStack_2092 = 0;
  uStack_2088 = 0;
  uStack_2086 = 0;
  uStack_20a0 = 0;
  *(undefined2 *)((longlong)auStackX_10 + lVar8) = 0xffff;
  *(undefined8 *)((longlong)auStackX_18 + lVar8) = 0;
  *(undefined4 *)((longlong)&uStackX_14 + lVar8) = 0;
  *(undefined8 *)(&stack0x0000002e + lVar8) = 0;
  *(undefined8 *)((longlong)&param_7 + lVar8) = 0;
  *(undefined8 *)((longlong)auStackX_18 + lVar8 + 8) = 0;
  lStack_20c0 = param_1;
  iStack_207c = iStack_20c4;
  if (-1 < *(char *)(param_1 + 2)) goto LAB_;
  pbVar1 = (byte *)(param_1 + 0x60);
  stack0xffffffffffffdf9a = SUB1614(ZEXT816(0),2);
  auStack_2068._0_2_ = 0xffff;
  uStack_2050 = 0;
  uStack_2042 = 0;
  uStack_2060 = 0;
  uStack_2038 = 0;
  uStack_204a = 0;
  uStack_2048 = 0;
  uStack_2040 = 0;
  uStack_203e = 0;
  uStack_2058 = 0;
  psStack_2030 = (short *)0x0;
  _auStack_2018 = ZEXT812(0);
  uStack_2010._4_4_ = 0;
  auVar5 = _auStack_2018;
  uStack_2010 = 0;
  uStack_2008 = 0;
  psStack_2028 = (short *)0x0;
  sStack_2020 = 0;
  uStack_201e = 0;
  auStack_2078 = ZEXT816(0);
  lVar3 = 0;
  if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
    auStack_2078._8_8_ = lVar3;
    uStack_20f0 = *(undefined8 *)(param_1 + 0x28);
    uStack_20e8 = *(undefined2 *)(param_1 + 0x30);
  }
  else {
    cVar7 = *(char *)(param_1 + 1);
    if (cVar7 == '\v') {
      if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
        if (cVar7 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar7 != '\b') goto LAB_;
LAB_:
      if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
    }
    uStack_20f0 = CONCAT26(uStack_20f0._6_2_,*(undefined6 *)(param_1 + 0x20));
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10016a;
    _auStack_2018 = auVar5;
    cVar7 = func_0x(&uStack_20f0,0x10ba340);
    lVar3 = auStack_2078._8_8_;
    if (cVar7 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10017a;
    func_0x(param_1,&uStack_20f0);
  }
  auStack_2018 = (undefined  [8])uStack_20f0;
  uStack_2010._4_4_ = *(undefined4 *)(param_1 + 0x20);
  uStack_2010._0_2_ = uStack_20e8;
  lVar3 = (ulonglong)*pbVar1 * 6;
  auStack_2078._0_8_ = pbVar1;
  uVar4 = *(undefined4 *)(lVar3 + 0x1138c20);
  uVar9 = (ulonglong)*(short *)(lVar3 + 0x1138c24);
  uStack_20f0 = CONCAT44((int)((ulonglong)uStack_20f0 >> 0x20),uVar4);
  uVar6 = uStack_20f0;
  auStack_2068._0_2_ = 0xffff;
  auStack_2068 = (undefined  [8])((ulonglong)auStack_2068 & 0xffffffff);
  uStack_2060 = 0;
  uStack_204a = 0;
  uStack_2048 = 0;
  uStack_2040 = 0;
  uStack_203e = 0;
  uStack_2058 = 0;
  sStack_2020 = 0;
  psStack_2030 = (short *)0x0;
  psStack_2028 = (short *)0x0;
  if ((*pbVar1 & 2) != 0) {
    pbVar2 = pbVar1 + uVar9;
    uStack_2060 = pbVar2;
    if ((pbVar1[uVar9] & 1) == 0) {
      auVar5._14_2_ = 0;
      auVar5._0_14_ = stack0xffffffffffffdf9a;
      _auStack_2068 = auVar5 << 0x10;
      uStack_2042 = 0;
      uStack_2040 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001003ac */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar2 & 0xe) * 4 + 0x102274) - 0x14601f0))()
      ;
      return;
    }
    auStack_2068._0_2_ = 1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar2 & 0x1c) + 0x102254) * 4 +
                           0x102244) - 0x14601f0);
                    /* WARNING: Could not emulate address calculation at 0x0010023e */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((*pbVar1 & 4) != 0) {
    uStack_20f0._2_2_ = (short)((uint)uVar4 >> 0x10);
    if (uStack_20f0._2_2_ != 0) {
      uVar9 = (ulonglong)*(ushort *)(param_1 + 0x61 + (longlong)uStack_20f0._2_2_ * 2);
    }
    psStack_2030 = (short *)(pbVar1 + uVar9);
    psStack_2028 = psStack_2030 + 1;
    sStack_2020 = (*psStack_2030 + 1) * 2;
  }
  uStack_20f0 = uVar6;
  if (auStack_2078._8_8_ != 0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10046b;
    func_0x(auStack_2078._8_8_,auStack_2078);
  }
LAB_:
  pbStack_20a8 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - (longlong)iStack_20c4) * 2) +
                         param_1);
  if ((*pbStack_20a8 & 1) == 0) {
    uStack_20b0 = 0;
    uStack_20ac = 0;
    uStack_208a = 0;
    uStack_2088 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100644 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_20a8 & 0xe) * 4 + 0x1022e0) - 0x14601f0
              ))((longlong)(int)(*pbStack_20a8 & 0xe),0x10ba340,pbStack_20a8,9);
    return;
  }
  uStack_20b0 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_20a8 & 0x1c) + 0x1022c0) * 4
                         + 0x1022b0) - 0x14601f0);
                    /* WARNING: Could not emulate address calculation at 0x001004c8 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

