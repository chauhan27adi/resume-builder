
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,int *param_3,int *param_4,undefined8 param_5,
                 undefined4 *param_6)

{
  int iVar1;
  int iVar2;
  short *psVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined auStack_a8 [4];
  int iStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_98;
  uint uStack_94;
  undefined8 uStack_90;
  undefined4 uStack_88;
  short *psStack_80;
  longlong lStack_78;
  longlong lStack_68;
  int *piStack_60;
  int *piStack_58;
  longlong lStack_40;
  ulonglong uStack_38;
  
  uStack_38 = _DAT_ ^ (ulonglong)auStack_a8;
  uVar5 = 0;
  uStack_98 = 0;
  uStack_94 = (uStack_94 >> 0x10 & 0xffe0) << 0x10;
  uStack_90 = 0;
  uStack_88 = 0;
  uStack_a0 = 0;
  lStack_78 = 0;
  if (*(int *)(*(longlong *)(param_2 + 8) + 0x100) == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  psVar3 = *(short **)(param_1 + 8);
  lStack_68 = param_2;
  piStack_60 = param_3;
  piStack_58 = param_4;
  lStack_40 = param_1;
  if (*(undefined8 **)(param_1 + 0x10) != (undefined8 *)0x0) {
    psStack_80 = psVar3;
    psVar3 = (short *)(**(code **)**(undefined8 **)(param_1 + 0x10))();
  }
  *param_3 = 0;
  *param_4 = 0;
  *param_6 = 0;
  if (*psVar3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  psStack_80 = psVar3;
  iVar1 = func_0x(psVar3 + 1);
  iStack_a4 = iVar1;
  if (0 < iVar1) {
    do {
      if ((~uVar5 & 0xc0000000) == 0x80000000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      puVar4 = (undefined4 *)
               func_0x(*(undefined8 *)(*(longlong *)(param_2 + 8) + 0x160),~uVar5);
      psVar3 = psStack_80;
      if (puVar4 == (undefined4 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uStack_98 = *puVar4;
      uStack_94 = puVar4[1];
      uStack_90 = *(undefined8 *)(puVar4 + 2);
      *piStack_60 = *piStack_60 + 1;
      iVar2 = func_0x(psStack_80,&uStack_98);
      if (iVar2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar5 = uVar5 + 1;
    } while ((int)uVar5 < iVar1);
  }
  iStack_a4 = 0;
  iVar1 = func_0x(psVar3);
  lStack_78 = (longlong)iVar1;
  if (0 < lStack_78) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*piStack_58 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong **)(lStack_40 + 0x10) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(lStack_40 + 0x10) + 8))();
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_a8);
  return;
}

