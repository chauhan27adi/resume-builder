
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 param_2)

{
  undefined2 *puVar1;
  byte bVar2;
  ushort uVar3;
  undefined4 uVar4;
  bool bVar5;
  char cVar6;
  int iVar7;
  longlong lVar8;
  short *psVar9;
  uint uVar10;
  ulonglong uVar11;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar12;
  undefined8 unaff_RBX;
  undefined *puVar13;
  undefined8 unaff_RSI;
  undefined8 unaff_RDI;
  byte *pbVar14;
  short sVar15;
  ulonglong uVar16;
  undefined2 auStackX_8 [2];
  undefined4 uStackX_c;
  undefined8 auStackX_10 [3];
  undefined8 uStack_30;
  
  uStack_30 = 0x100014;
  lVar8 = func_0x();
  lVar8 = -lVar8;
  puVar13 = &stack0xffffffffffffffd8 + lVar8;
  puVar1 = (undefined2 *)((longlong)auStackX_8 + lVar8);
  *(undefined8 *)(&stack0x000021a0 + lVar8) = unaff_RBX;
  *(undefined8 *)(&stack0x000021a8 + lVar8) = unaff_RSI;
  *(undefined8 *)(&stack0x000021b0 + lVar8) = unaff_RDI;
  *(ulonglong *)(&stack0x00002158 + lVar8) = _DAT_ ^ (ulonglong)puVar1;
  uVar3 = *(ushort *)(param_1 + 0x16);
  uVar16 = (ulonglong)uVar3;
  lVar12 = 0;
  *(undefined4 *)(&stack0x00000068 + lVar8) = param_2;
  *(undefined8 *)(&stack0x00000078 + lVar8) = 0;
  *(longlong *)(&stack0x00000090 + lVar8) = param_1;
  *puVar1 = 0xffff;
  *(undefined8 *)((longlong)auStackX_10 + lVar8) = 0;
  *(undefined4 *)((longlong)&uStackX_c + lVar8) = 0;
  *(undefined8 *)((longlong)auStackX_10 + lVar8 + 0x16) = 0;
  *(undefined8 *)(&stack0x00000030 + lVar8) = 0;
  *(undefined8 *)((longlong)auStackX_10 + lVar8 + 8) = 0;
  *(ushort *)(&stack0x00000040 + lVar8) = uVar3;
  *(undefined4 *)(&stack0x00000044 + lVar8) = 0;
  if (uVar3 != 0) {
    uVar11 = uVar16 * 2 + 0xf;
    if (uVar11 <= uVar16 * 2) {
      uVar11 = 0xffffffffffffff0;
    }
    uVar11 = uVar11 & 0xfffffffffffffff0;
    *(undefined8 *)((longlong)&uStack_30 + lVar8) = 0x1000b2;
    func_0x();
    puVar13 = &stack0xffffffffffffffd8 + -uVar11 + lVar8;
    lVar12 = (longlong)auStackX_8 + -uVar11 + lVar8;
    *(longlong *)(&stack0x00000078 + lVar8) = lVar12;
  }
  uVar11 = 0;
  *(int *)(&stack0x00000064 + lVar8) = (int)uVar16;
  *(undefined4 *)(&stack0x00000048 + lVar8) = 0;
  if ((int)uVar16 != 0) {
    *(undefined8 *)(&stack0x00000080 + lVar8) = 0;
    uVar16 = uVar11;
    do {
      uVar10 = (uint)uVar11;
      if ((*(ushort *)(param_1 + 0x16) <= uVar10) ||
         (bVar5 = true, *(short *)(param_1 + (0xfff - uVar16) * 2) == 0)) {
        bVar5 = false;
      }
      if (bVar5) {
        cVar6 = *(char *)(param_1 + 2);
        *(undefined2 *)(&stack0x00000108 + lVar8) = 0xffff;
        *(undefined8 *)(&stack0x00000110 + lVar8) = 0;
        *(undefined4 *)(&stack0x0000010c + lVar8) = 0;
        *(undefined8 *)(&stack0x00000126 + lVar8) = 0;
        *(undefined8 *)(&stack0x00000130 + lVar8) = 0;
        *(undefined8 *)(&stack0x00000118 + lVar8) = 0;
        *(uint *)(&stack0x0000013c + lVar8) = uVar10;
        if (-1 < cVar6) goto LAB_;
        pbVar14 = (byte *)(param_1 + 0x60);
        *(undefined (*) [16])(&stack0x00000150 + lVar8) = ZEXT816(0);
        *(undefined8 *)(&stack0x000001b0 + lVar8) = 0;
        *(undefined (*) [16])(&stack0x00000160 + lVar8) = ZEXT816(0);
        *(undefined2 *)(&stack0x00000150 + lVar8) = 0xffff;
        *(undefined (*) [16])(&stack0x00000170 + lVar8) = ZEXT816(0);
        *(undefined8 *)(&stack0x00000158 + lVar8) = 0;
        *(undefined (*) [16])(&stack0x000001a0 + lVar8) = ZEXT816(0);
        *(undefined4 *)(&stack0x00000154 + lVar8) = 0;
        *(undefined (*) [16])(&stack0x00000180 + lVar8) = ZEXT816(0);
        *(undefined8 *)(&stack0x0000016e + lVar8) = 0;
        *(undefined8 *)(&stack0x00000178 + lVar8) = 0;
        *(undefined8 *)(&stack0x00000160 + lVar8) = 0;
        *(undefined8 *)(&stack0x00000188 + lVar8) = 0;
        *(undefined8 *)(&stack0x000001a0 + lVar8) = 0;
        *(undefined4 *)(&stack0x000001a8 + lVar8) = 0;
        *(undefined2 *)(&stack0x000001b2 + lVar8) = 0;
        *(undefined (*) [16])(&stack0x00000190 + lVar8) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x00000140 + lVar8) = ZEXT816(0);
        if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
          sVar15 = *(short *)(param_1 + 0x30);
          *(undefined8 *)(&stack0x00000050 + lVar8) = *(undefined8 *)(param_1 + 0x28);
          *(short *)(&stack0x00000058 + lVar8) = sVar15;
        }
        else {
          cVar6 = *(char *)(param_1 + 1);
          if (cVar6 == '\v') {
            if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
              if (cVar6 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar6 != '\b') goto LAB_;
LAB_:
            if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
          }
          *(undefined4 *)(&stack0x0000006c + lVar8) = *(undefined4 *)(param_1 + 0x20);
          *(undefined2 *)(&stack0x00000070 + lVar8) = *(undefined2 *)(param_1 + 0x24);
          *(undefined8 *)(puVar13 + -8) = 0x100229;
          cVar6 = func_0x(&stack0x0000006c + lVar8,lVar12,2);
          if (cVar6 == '\0') goto LAB_;
          *(undefined8 *)(puVar13 + -8) = 0x100239;
          func_0x(param_1,&stack0x00000050 + lVar8);
          sVar15 = *(short *)(&stack0x00000058 + lVar8);
        }
        iVar7 = (int)((ulonglong)*(undefined8 *)(&stack0x00000050 + lVar8) >> 0x20);
        if ((((pbVar14 != *(byte **)(&stack0x00000140 + lVar8)) ||
             (sVar15 != *(short *)(&stack0x000001a8 + lVar8))) ||
            (*(int *)(&stack0x00000050 + lVar8) != *(int *)(&stack0x000001a0 + lVar8))) ||
           (((iVar7 != *(int *)(&stack0x000001a4 + lVar8) ||
             (*(int *)(param_1 + 0x20) != *(int *)(&stack0x000001ac + lVar8))) ||
            (*(short *)(param_1 + 0x24) != *(short *)(&stack0x000001b0 + lVar8))))) {
          *(undefined4 *)(&stack0x000001ac + lVar8) = *(undefined4 *)(param_1 + 0x20);
          *(undefined2 *)(&stack0x000001b0 + lVar8) = *(undefined2 *)(param_1 + 0x24);
          *(int *)(&stack0x000001a0 + lVar8) = *(int *)(&stack0x00000050 + lVar8);
          bVar2 = *pbVar14;
          *(int *)(&stack0x000001a4 + lVar8) = iVar7;
          *(byte **)(&stack0x00000140 + lVar8) = pbVar14;
          *(short *)(&stack0x000001a8 + lVar8) = sVar15;
          *(undefined2 *)(&stack0x000001b2 + lVar8) = 0;
          *(undefined2 *)(&stack0x00000150 + lVar8) = 0xffff;
          lVar12 = (ulonglong)bVar2 * 6;
          uVar11 = (ulonglong)*(short *)(lVar12 + 0x1556bb4);
          *(undefined4 *)(&stack0x00000088 + lVar8) = *(undefined4 *)(lVar12 + 0x1556bb0);
          *(undefined8 *)(&stack0x00000158 + lVar8) = 0;
          *(undefined4 *)(&stack0x00000154 + lVar8) = 0;
          *(undefined8 *)(&stack0x0000016e + lVar8) = 0;
          *(undefined8 *)(&stack0x00000178 + lVar8) = 0;
          *(undefined8 *)(&stack0x00000160 + lVar8) = 0;
          *(undefined2 *)(&stack0x00000198 + lVar8) = 0;
          *(undefined (*) [16])(&stack0x00000188 + lVar8) = ZEXT816(0);
          if ((bVar2 & 2) != 0) {
            bVar2 = pbVar14[uVar11];
            pbVar14 = pbVar14 + uVar11;
            *(byte **)(&stack0x00000158 + lVar8) = pbVar14;
            if ((bVar2 & 1) == 0) {
              *(undefined2 *)(&stack0x00000150 + lVar8) = 0;
              *(undefined4 *)(&stack0x00000176 + lVar8) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100543 */
                    /* WARNING: Treating indirect jump as call */
              (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar14 & 0xe) * 4 + 0x101458) -
                        0x1042260))();
              return;
            }
            *(undefined2 *)(&stack0x00000150 + lVar8) = 1;
            UNRECOVERED_JUMPTABLE_00 =
                 (code *)((ulonglong)
                          *(uint *)((ulonglong)
                                    *(byte *)((longlong)(int)(*pbVar14 & 0x1c) + 0x101438) * 4 +
                                   0x101428) - 0x1042260);
                    /* WARNING: Could not emulate address calculation at 0x0010037f */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
            return;
          }
          if ((**(byte **)(&stack0x00000140 + lVar8) & 4) != 0) {
            if (*(short *)(&stack0x0000008a + lVar8) != 0) {
              uVar11 = (ulonglong)
                       *(ushort *)
                        (param_1 + 0x61 + (longlong)*(short *)(&stack0x0000008a + lVar8) * 2);
            }
            psVar9 = (short *)(pbVar14 + uVar11);
            *(short **)(&stack0x00000188 + lVar8) = psVar9;
            sVar15 = *psVar9;
            *(short **)(&stack0x00000190 + lVar8) = psVar9 + 1;
            *(short *)(&stack0x00000198 + lVar8) = (sVar15 + 1) * 2;
          }
          lVar12 = *(longlong *)(&stack0x00000148 + lVar8);
          if (lVar12 != 0) {
            *(undefined8 *)(puVar13 + -8) = 0x100617;
            func_0x(lVar12,&stack0x00000140 + lVar8);
          }
        }
LAB_:
        pbVar14 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - uVar16) * 2) + param_1);
        bVar2 = *pbVar14;
        *(byte **)(&stack0x00000110 + lVar8) = pbVar14;
        if ((bVar2 & 1) == 0) {
          *(undefined2 *)(&stack0x00000108 + lVar8) = 0;
          *(undefined4 *)(&stack0x0000010c + lVar8) = 0;
          *(undefined4 *)(&stack0x0000012e + lVar8) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100855 */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar14 & 0xe) * 4 + 0x1014c4) -
                    0x1042260))();
          return;
        }
        *(undefined2 *)(&stack0x00000108 + lVar8) = 1;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar14 & 0x1c) + 0x1014a4) *
                                4 + 0x101494) - 0x1042260);
                    /* WARNING: Could not emulate address calculation at 0x00100669 */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbVar14,2);
        return;
      }
      *(undefined2 *)(lVar12 + uVar16 * 2) = 0xffff;
      uVar10 = uVar10 + 1;
      uVar11 = (ulonglong)uVar10;
      uVar16 = uVar16 + 1;
      *(uint *)(&stack0x00000048 + lVar8) = uVar10;
      *(ulonglong *)(&stack0x00000080 + lVar8) = uVar16;
    } while ((int)uVar10 < *(int *)(&stack0x00000064 + lVar8));
    uVar16 = (ulonglong)*(ushort *)(&stack0x00000040 + lVar8);
  }
  *(longlong *)(&stack0x000000b8 + lVar8) = lVar12;
  *(short *)(&stack0x000000c0 + lVar8) = (short)uVar16;
  uVar4 = *(undefined4 *)(&stack0x00000068 + lVar8);
  *(undefined **)(&stack0x000000a8 + lVar8) = &stack0x000001b8 + lVar8;
  *(undefined2 *)(&stack0x000000d0 + lVar8) = 0xffff;
  *(undefined8 *)(&stack0x000000d8 + lVar8) = 0;
  *(undefined4 *)(&stack0x000000d4 + lVar8) = 0;
  *(undefined8 *)(&stack0x000000ee + lVar8) = 0;
  *(undefined8 *)(&stack0x000000f8 + lVar8) = 0;
  *(undefined8 *)(&stack0x000000e0 + lVar8) = 0;
  *(undefined4 *)(&stack0x000000b0 + lVar8) = 0x1f9e;
  *(undefined8 *)(&stack0x000000c8 + lVar8) = 0;
  *(undefined8 *)(puVar13 + -8) = 0x1013f0;
  func_0x(param_1,&stack0x000000a8 + lVar8,uVar4);
  uVar16 = *(ulonglong *)(&stack0x00002158 + lVar8);
  *(undefined8 *)(puVar13 + -8) = 0x1013ff;
  func_0x(uVar16 ^ (ulonglong)puVar1);
  return;
}

