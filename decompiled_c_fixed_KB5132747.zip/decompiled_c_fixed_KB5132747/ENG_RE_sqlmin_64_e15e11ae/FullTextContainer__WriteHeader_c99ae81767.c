
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  byte *pbVar1;
  longlong lVar2;
  ushort *puVar3;
  char cVar4;
  byte bVar5;
  int iVar6;
  undefined4 uVar7;
  longlong lVar8;
  undefined8 uVar9;
  ulonglong *puVar10;
  ushort uVar11;
  ulonglong uVar12;
  ushort uVar13;
  int iVar14;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  ulonglong uVar18;
  uint uVar19;
  byte *pbVar20;
  byte *pbVar21;
  int iVar22;
  ushort *puVar23;
  undefined auStack_8d8 [32];
  undefined8 uStack_8b8;
  ulonglong uStack_8b0;
  undefined4 uStack_8a8;
  undefined4 auStack_898 [2];
  uint auStack_890 [2];
  undefined auStack_888 [16];
  short sStack_878;
  ushort uStack_876;
  uint uStack_874;
  byte *pbStack_870;
  undefined8 uStack_868;
  uint uStack_860;
  ushort uStack_85c;
  byte *pbStack_85a;
  undefined2 uStack_852;
  undefined2 uStack_850;
  ushort uStack_84e;
  ushort uStack_84c;
  undefined2 uStack_84a;
  undefined auStack_844 [2060];
  ulonglong uStack_38;
  
  uStack_38 = _DAT_ ^ (ulonglong)auStack_8d8;
  iVar22 = 0;
  iVar14 = 0;
  pbStack_870 = (byte *)0x0;
  uStack_874 = 0;
  pbStack_85a = (byte *)0x0;
  uStack_850 = 0;
  uStack_84e = 0;
  uStack_84c = 0;
  uStack_84a = 0;
  uStack_868 = 0;
  if (*(longlong *)(param_1 + 0x310) == 0) {
    uStack_8b8 = 0;
    (*_DAT_)(1,0xda0950,0xd4f0a0,0x3c9);
  }
  if ((*(longlong *)(param_1 + 0x348) == _DAT_) &&
     (*(longlong *)(param_1 + 0x350) == _DAT_)) {
    uStack_8b8 = 0;
    (*_DAT_)(1,0xda0a28,0xd4f0a0,0x3cd);
  }
  if (*(int *)(param_1 + 0x32c) != 0) goto LAB_;
  auStack_898[0] = 4;
  func_0x(auStack_844,0,0x800);
  uStack_8b0 = uStack_8b0 & 0xffffffffffffff00;
  sStack_878 = 0;
  uStack_8b8._0_4_ = 0x3c;
  func_0x(&uStack_876,auStack_844);
  uStack_8b8 = (ulonglong)uStack_8b8._4_4_ << 0x20;
  func_0x(auStack_888,4,1,0);
  func_0x(&sStack_878,auStack_888,auStack_898,4);
  func_0x(&sStack_878,1,param_1 + 0x348);
  func_0x(&sStack_878,0x18,param_1 + 0x358,0x10);
  func_0x(&sStack_878,3,param_1 + 0x368,4);
  func_0x(&sStack_878,4,param_1 + 0x36c,4);
  func_0x(&sStack_878,0x19,param_1 + 0x370,4);
  func_0x(&sStack_878,0x14,param_1 + 0x3d4,0xc);
  func_0x(&sStack_878,0x13,param_1 + 0x3ec,0xc);
  func_0x(&sStack_878,0x1a,param_1 + 0x404,0xc);
  func_0x(&sStack_878,0x11,param_1 + 0x3f8,0xc);
  func_0x(&sStack_878,0x1b,param_1 + 0x374,8);
  func_0x(&sStack_878,0x16,param_1 + 0x37c,0x10);
  func_0x(&sStack_878,0x1d,param_1 + 0x38c,0x10);
  func_0x(&sStack_878,0x12,param_1 + 0x39c,0x1c);
  lVar8 = -1;
  do {
    lVar2 = lVar8 * 2;
    lVar8 = lVar8 + 1;
  } while (*(short *)(param_1 + 0x20a + lVar2) != 0);
  func_0x(&sStack_878,0x1c,param_1 + 0x208,(int)lVar8 * 2);
  func_0x(&sStack_878,0x29,param_1 + 0x3b8,0x1c);
  iVar6 = (*_DAT_)(*(undefined8 *)(param_1 + 0x310),0,auStack_898,0);
  if (iVar6 == 0) {
    uVar7 = (*_DAT_)();
    func_0x(6,uVar7,0xcb9950);
  }
  uVar18 = (ulonglong)uStack_874;
  if (sStack_878 == 0) {
    pbVar21 = pbStack_870;
    if (uStack_874 == 0) {
      uVar18 = uStack_868 & 0xffffffff;
      uStack_876 = 0;
      uVar19 = (uint)uStack_868;
      if ((*pbStack_870 & 0x10) != 0) {
        uVar19 = (uint)uStack_868 + 2 + (*(ushort *)(pbStack_870 + uVar18) + 7 >> 3);
        uVar18 = (ulonglong)uVar19;
      }
      uStack_868 = CONCAT44(uVar19,(uint)uStack_868);
      uStack_860 = (uint)uVar18;
      if ((*pbStack_870 & 0x20) == 0) {
        uStack_85c = 0;
        uStack_874 = uStack_860;
      }
      else {
        puVar23 = (ushort *)(pbStack_870 + uVar18);
        uStack_85c = *puVar23;
        if (uStack_85c == 0) {
          cVar4 = func_0x(0x12d7fb0);
          if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar4 = func_0x(0x12d7fb0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_8b8 = 0;
              (*_DAT_)(1,0xbc79bc,0xce7aa8,0x80f);
            }
          }
          func_0x(pbStack_870,3);
        }
        uStack_860 = uStack_868._4_4_ + 2 + (uint)uStack_85c * 2;
        if (0x1f9e < uStack_860) {
          cVar4 = func_0x(0x12d7fb0);
          if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar4 = func_0x(0x12d7fb0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_8b8 = 0;
              (*_DAT_)(1,0xbc79bc,0xce7aa8,0x816);
            }
          }
          func_0x(pbStack_870,4);
        }
        uVar12 = (ulonglong)uStack_85c;
        uStack_874 = puVar23[uVar12] & 0x7fff;
        if (uStack_874 < uStack_860) {
          cVar4 = func_0x(0x12d7fb0);
          if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar4 = func_0x(0x12d7fb0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_8b8 = 0;
              (*_DAT_)(1,0xbc79bc,0xce7aa8,0x81d);
            }
          }
          func_0x(pbStack_870,4);
          uVar12 = (ulonglong)uStack_85c;
        }
        uVar18 = (ulonglong)uStack_874;
        pbVar21 = pbStack_870;
        puVar3 = puVar23;
        iVar6 = iVar22;
        uVar19 = uStack_860;
        uVar17 = uStack_860;
        if ((short)uVar12 != 0) {
          do {
            uVar17 = puVar3[1] & 0x7fff;
            if ((uVar17 < uVar19) || ((uint)uVar18 < uVar17)) {
              cVar4 = func_0x(0x12d7fb0);
              if ((cVar4 != '\0') &&
                 ((lVar8 = func_0x(), lVar8 != 0 &&
                  (*(char *)(lVar8 + 0x499) != '\0')))) {
                cVar4 = func_0x(0x12d7fb0);
                if (cVar4 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_8b8 = 0;
                  (*_DAT_)(1,0xbc79bc,0xce7aa8,0x82a);
                }
              }
              func_0x(pbStack_870,4);
              uVar12 = (ulonglong)uStack_85c;
              uVar18 = (ulonglong)uStack_874;
              pbVar21 = pbStack_870;
            }
            iVar6 = iVar6 + 1;
            puVar3 = puVar3 + 1;
            uVar19 = uVar17;
            uVar17 = uStack_860;
          } while (iVar6 < (int)uVar12);
        }
        while( true ) {
          uVar11 = (ushort)uVar12;
          if (-1 < (short)puVar23[(ulonglong)((int)uVar12 - 1) + 1]) break;
          if ((int)uVar12 == 1) {
            uVar12 = 1;
            uVar19 = uVar17;
          }
          else {
            uVar19 = *(ushort *)(pbVar21 + uVar12 * 2 + ((uStack_868 >> 0x20) - 2)) & 0x7fff;
          }
          uVar15 = *(ushort *)(pbVar21 + uVar12 * 2 + (uStack_868 >> 0x20)) & 0x7fff;
          if (((uVar19 < uVar17) || (uVar15 < uVar19)) || ((uint)uVar18 < uVar15)) {
            func_0x(pbVar21,7);
            uVar18 = (ulonglong)uStack_874;
            pbVar21 = pbStack_870;
            uVar11 = uStack_85c;
            uVar17 = uStack_860;
          }
          if ((uVar19 < uVar17) || ((uint)uVar18 < uVar19)) goto LAB_;
          if (*(ushort *)(pbVar21 + uVar19) == 5) {
            uStack_876 = uStack_876 | 2;
            uStack_85c = uVar11 - 1;
            uVar12 = (ulonglong)(uVar19 & 0xffff);
            pbVar1 = pbVar21 + uVar12;
            uStack_84e = (ushort)uVar19;
            if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
              uVar11 = uStack_84c & 0xc7ff;
            }
            else {
              uVar11 = uStack_84c ^ (*(ushort *)(pbVar1 + 2) ^ uStack_84c) & 0x3800;
            }
            uStack_84c = (uVar11 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar11;
            uVar17 = (uint)uStack_84c;
            lVar8 = uVar12 + (uVar11 >> 0xb & 7) * 2;
            pbVar20 = pbVar21;
            if (pbVar21 + (ulonglong)((uVar17 & 0x7ff) * 2) + 4 + lVar8 < pbVar1) {
              func_0x(pbVar1,0x19);
              uVar18 = (ulonglong)uStack_874;
              uVar12 = (ulonglong)uStack_84e;
              pbVar20 = pbStack_870;
            }
            if (uVar15 - uVar19 <
                (((uStack_84c & 0x7ff) * 2 - (int)uVar12) - (int)pbStack_870) +
                (int)(pbVar21 + (ulonglong)((uVar17 & 0x7ff) * 2) + 4 + lVar8)) {
              func_0x(pbVar20 + uVar12,0x19);
              uVar18 = (ulonglong)uStack_874;
              uVar12 = (ulonglong)uStack_84e;
              pbVar20 = pbStack_870;
            }
            pbVar21 = pbVar20;
            if (((uStack_84c & 0x3800) != 0) &&
               (puVar23 = (ushort *)(pbVar20 + uVar12 + 4), iVar6 = iVar22, uVar11 = uStack_84c,
               (uStack_84c & 0x3800) != 0)) {
              do {
                if ((uVar11 & 0x7ff) < (*puVar23 & 0x7ff)) {
                  func_0x(pbVar20 + uVar12,0x1a);
                  uVar12 = (ulonglong)uStack_84e;
                  pbVar20 = pbStack_870;
                  uVar11 = uStack_84c;
                }
                iVar6 = iVar6 + 1;
                puVar23 = puVar23 + 1;
              } while (iVar6 < (int)((uStack_84c & 0x3800) >> 0xb));
              uVar18 = (ulonglong)uStack_874;
              pbVar21 = pbVar20;
            }
            break;
          }
          if (*(ushort *)(pbVar21 + uVar19) < 0x400) break;
          uStack_876 = uStack_876 | 1;
          uStack_85c = uVar11 - 1;
          uVar12 = (ulonglong)uStack_85c;
          if (uStack_85c == 0) break;
        }
      }
      if ((*pbVar21 & 0x40) == 0) {
        uStack_852 = 0;
        uStack_850 = 0;
      }
      else {
        uStack_852 = (undefined2)uVar18;
        uStack_850 = (undefined2)(uVar18 >> 0x10);
        uStack_874 = (int)uVar18 + 0xe;
        uVar9 = func_0x(&uStack_876);
        func_0x(uVar9,auStack_898);
        iVar6 = func_0x(auStack_898);
        uStack_874 = uStack_874 + iVar6;
        uVar18 = (ulonglong)uStack_874;
        pbVar21 = pbStack_870;
      }
      if ((pbStack_85a != (byte *)0x0) && (pbStack_85a < pbVar21 + uVar18)) {
        cVar4 = func_0x(0x12d7fb0);
        if ((cVar4 != '\0') &&
           ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0'))))
        {
          cVar4 = func_0x(0x12d7fb0);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_8b8 = 0;
            (*_DAT_)(1,0xbc79bc,0xce7aa8,0x886);
          }
        }
        func_0x(pbStack_870,0x12);
        uVar18 = (ulonglong)uStack_874;
        pbVar21 = pbStack_870;
      }
      if (0x3f3b < (int)uVar18 - 1U) {
        cVar4 = func_0x(0x12d7fb0);
        if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar4 = func_0x(0x12d7fb0);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_8b8 = 0;
            (*_DAT_)(1,0xbc79bc,0xce7aa8,0x88b);
          }
        }
        func_0x(pbStack_870,5);
        uVar18 = (ulonglong)uStack_874;
        pbVar21 = pbStack_870;
      }
    }
LAB_:
    if ((uint)uVar18 < 9) {
      bVar5 = *pbVar21 & 0xe;
joined_r0x00100a49:
      if ((bVar5 == 0) || (bVar5 == 0xc)) {
        uVar18 = 9;
      }
    }
  }
  else {
    if (uStack_874 == 0) {
      func_0x(&uStack_876);
      uVar18 = (ulonglong)uStack_874;
    }
    pbVar21 = pbStack_870;
    if ((uint)uVar18 < 9) {
      bVar5 = *pbStack_870 & 0x1c;
      goto joined_r0x00100a49;
    }
  }
  uVar19 = 9;
  uStack_8b8 = 0;
  iVar6 = (*_DAT_)(*(undefined8 *)(param_1 + 0x310),pbVar21,uVar18,auStack_890);
  if (iVar6 == 0) {
LAB_:
    uVar7 = (*_DAT_)();
    uStack_8a8 = 0x436;
    uStack_8b0 = 0xd4f0a0;
    uStack_8b8 = param_1;
    func_0x(3,uVar7,0,0xcb3410);
  }
  else {
    if (sStack_878 == 0) {
      uVar18 = (ulonglong)uStack_874;
      pbVar21 = pbStack_870;
      if (uStack_874 == 0) {
        uVar18 = uStack_868 & 0xffffffff;
        uStack_876 = 0;
        uVar17 = (uint)uStack_868;
        if ((*pbStack_870 & 0x10) != 0) {
          uVar17 = (uint)uStack_868 + 2 + (*(ushort *)(pbStack_870 + uVar18) + 7 >> 3);
          uVar18 = (ulonglong)uVar17;
        }
        uStack_868 = CONCAT44(uVar17,(uint)uStack_868);
        if ((*pbStack_870 & 0x20) == 0) {
          uStack_85c = 0;
          uStack_874 = (uint)uVar18;
          uStack_860 = (uint)uVar18;
        }
        else {
          puVar23 = (ushort *)(pbStack_870 + uVar18);
          uStack_85c = *puVar23;
          if (uStack_85c == 0) {
            cVar4 = func_0x(0x12d7fb0);
            if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
               (*(char *)(lVar8 + 0x499) != '\0')) {
              cVar4 = func_0x(0x12d7fb0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_8b8 = 0;
                (*_DAT_)(1,0xbc79bc,0xce7aa8,0x80f);
              }
            }
            func_0x(pbStack_870,3);
          }
          uStack_860 = uStack_868._4_4_ + 2 + (uint)uStack_85c * 2;
          if (0x1f9e < uStack_860) {
            cVar4 = func_0x(0x12d7fb0);
            if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
               (*(char *)(lVar8 + 0x499) != '\0')) {
              cVar4 = func_0x(0x12d7fb0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_8b8 = 0;
                (*_DAT_)(1,0xbc79bc,0xce7aa8,0x816);
              }
            }
            func_0x(pbStack_870,4);
          }
          uVar12 = (ulonglong)uStack_85c;
          uStack_874 = puVar23[uVar12] & 0x7fff;
          if (uStack_874 < uStack_860) {
            cVar4 = func_0x(0x12d7fb0);
            if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
               (*(char *)(lVar8 + 0x499) != '\0')) {
              cVar4 = func_0x(0x12d7fb0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_8b8 = 0;
                (*_DAT_)(1,0xbc79bc,0xce7aa8,0x81d);
              }
            }
            func_0x(pbStack_870,4);
            uVar12 = (ulonglong)uStack_85c;
          }
          uVar18 = (ulonglong)uStack_874;
          pbVar21 = pbStack_870;
          puVar3 = puVar23;
          iVar6 = iVar22;
          uVar17 = uStack_860;
          uVar15 = uStack_860;
          if ((short)uVar12 != 0) {
            do {
              uVar15 = puVar3[1] & 0x7fff;
              if ((uVar15 < uVar17) || ((uint)uVar18 < uVar15)) {
                cVar4 = func_0x(0x12d7fb0);
                if ((cVar4 != '\0') &&
                   ((lVar8 = func_0x(), lVar8 != 0 &&
                    (*(char *)(lVar8 + 0x499) != '\0')))) {
                  cVar4 = func_0x(0x12d7fb0);
                  if (cVar4 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_8b8 = 0;
                    (*_DAT_)(1,0xbc79bc,0xce7aa8,0x82a);
                  }
                }
                func_0x(pbStack_870,4);
                uVar12 = (ulonglong)uStack_85c;
                uVar18 = (ulonglong)uStack_874;
                pbVar21 = pbStack_870;
              }
              iVar6 = iVar6 + 1;
              puVar3 = puVar3 + 1;
              uVar17 = uVar15;
              uVar15 = uStack_860;
            } while (iVar6 < (int)uVar12);
          }
          while( true ) {
            uVar11 = (ushort)uVar12;
            if (-1 < (short)puVar23[(ulonglong)((int)uVar12 - 1) + 1]) break;
            if ((int)uVar12 == 1) {
              uVar12 = 1;
              uVar17 = uVar15;
            }
            else {
              uVar17 = *(ushort *)(pbVar21 + uVar12 * 2 + ((uStack_868 >> 0x20) - 2)) & 0x7fff;
            }
            uVar16 = *(ushort *)(pbVar21 + uVar12 * 2 + (uStack_868 >> 0x20)) & 0x7fff;
            if (((uVar17 < uVar15) || (uVar16 < uVar17)) || ((uint)uVar18 < uVar16)) {
              func_0x(pbVar21,7);
              uVar18 = (ulonglong)uStack_874;
              pbVar21 = pbStack_870;
              uVar11 = uStack_85c;
              uVar15 = uStack_860;
            }
            if ((uVar17 < uVar15) || ((uint)uVar18 < uVar17)) goto LAB_;
            if (*(ushort *)(pbVar21 + uVar17) == 5) {
              uStack_876 = uStack_876 | 2;
              uStack_85c = uVar11 - 1;
              uVar12 = (ulonglong)(uVar17 & 0xffff);
              pbVar1 = pbVar21 + uVar12;
              uStack_84e = (ushort)uVar17;
              if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
                uVar11 = uStack_84c & 0xc7ff;
              }
              else {
                uVar11 = uStack_84c ^ (*(ushort *)(pbVar1 + 2) ^ uStack_84c) & 0x3800;
              }
              uStack_84c = (uVar11 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar11;
              uVar15 = (uint)uStack_84c;
              lVar8 = uVar12 + (uVar11 >> 0xb & 7) * 2;
              pbVar20 = pbVar21;
              if (pbVar21 + (ulonglong)((uVar15 & 0x7ff) * 2) + 4 + lVar8 < pbVar1) {
                func_0x(pbVar1,0x19);
                uVar12 = (ulonglong)uStack_84e;
                uVar18 = (ulonglong)uStack_874;
                pbVar20 = pbStack_870;
              }
              if (uVar16 - uVar17 <
                  (((uStack_84c & 0x7ff) * 2 - (int)uVar12) - (int)pbStack_870) +
                  (int)(pbVar21 + (ulonglong)((uVar15 & 0x7ff) * 2) + 4 + lVar8)) {
                func_0x(pbVar20 + uVar12,0x19);
                uVar12 = (ulonglong)uStack_84e;
                uVar18 = (ulonglong)uStack_874;
                pbVar20 = pbStack_870;
              }
              pbVar21 = pbVar20;
              if (((uStack_84c & 0x3800) != 0) &&
                 (puVar23 = (ushort *)(pbVar20 + uVar12 + 4), uVar11 = uStack_84c,
                 (uStack_84c & 0x3800) != 0)) {
                do {
                  if ((uVar11 & 0x7ff) < (*puVar23 & 0x7ff)) {
                    func_0x(pbVar20 + uVar12,0x1a);
                    uVar12 = (ulonglong)uStack_84e;
                    pbVar20 = pbStack_870;
                    uVar11 = uStack_84c;
                  }
                  iVar22 = iVar22 + 1;
                  puVar23 = puVar23 + 1;
                } while (iVar22 < (int)((uStack_84c & 0x3800) >> 0xb));
                uVar18 = (ulonglong)uStack_874;
                pbVar21 = pbVar20;
              }
              break;
            }
            if (*(ushort *)(pbVar21 + uVar17) < 0x400) break;
            uStack_876 = uStack_876 | 1;
            uStack_85c = uVar11 - 1;
            uVar12 = (ulonglong)uStack_85c;
            if (uStack_85c == 0) break;
          }
        }
        if ((*pbVar21 & 0x40) == 0) {
          uStack_852 = 0;
          uStack_850 = 0;
        }
        else {
          uStack_852 = (undefined2)uVar18;
          uStack_850 = (undefined2)(uVar18 >> 0x10);
          uStack_874 = (int)uVar18 + 0xe;
          puVar10 = (ulonglong *)func_0x(&uStack_876);
          uVar13 = (ushort)(*puVar10 >> 0x30);
          uVar11 = uVar13;
          if ((((uint)(int)(short)uVar13 >> 1 ^ (int)(short)uVar13) & 0x2000) != 0) {
            uVar11 = uVar13 & 0xdfff;
            if ((uVar13 >> 0xe & 1) != 0) {
              uVar11 = uVar13 | 0x2000;
            }
          }
          if (uVar11 == 0xfffc) {
            iVar14 = (int)((*puVar10 >> 0x20 & 0xffff) >> 5);
          }
          uStack_874 = uStack_874 + iVar14;
          uVar18 = (ulonglong)uStack_874;
          pbVar21 = pbStack_870;
        }
        if ((pbStack_85a != (byte *)0x0) && (pbStack_85a < pbVar21 + uVar18)) {
          cVar4 = func_0x(0x12d7fb0);
          if ((cVar4 != '\0') &&
             ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')))
             ) {
            cVar4 = func_0x(0x12d7fb0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uStack_8b8 = 0;
              (*_DAT_)(1,0xbc79bc,0xce7aa8,0x886);
            }
          }
          func_0x(pbStack_870,0x12);
          uVar18 = (ulonglong)uStack_874;
          pbVar21 = pbStack_870;
        }
        if (0x3f3b < (int)uVar18 - 1U) {
          cVar4 = func_0x(0x12d7fb0);
          if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar4 = func_0x(0x12d7fb0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              uStack_8b8 = 0;
              (*_DAT_)(1,0xbc79bc,0xce7aa8,0x88b);
            }
          }
          func_0x(pbStack_870,5);
          uVar18 = (ulonglong)uStack_874;
          pbVar21 = pbStack_870;
        }
      }
LAB_:
      if ((8 < (uint)uVar18) || (((*pbVar21 & 0xe) != 0 && ((*pbVar21 & 0xe) != 0xc)))) {
        uVar19 = (uint)uVar18;
      }
    }
    else {
      if (uStack_874 == 0) {
        func_0x(&uStack_876);
      }
      if ((8 < uStack_874) || (((*pbStack_870 & 0x1c) != 0 && ((*pbStack_870 & 0x1c) != 0xc)))) {
        uVar19 = uStack_874;
      }
    }
    if (auStack_890[0] != uVar19) goto LAB_;
  }
  func_0x(*(undefined8 *)(param_1 + 0x310),param_1,6);
  *(undefined4 *)(param_1 + 0x31c) = 1;
LAB_:
  func_0x(uStack_38 ^ (ulonglong)auStack_8d8);
  return;
}

