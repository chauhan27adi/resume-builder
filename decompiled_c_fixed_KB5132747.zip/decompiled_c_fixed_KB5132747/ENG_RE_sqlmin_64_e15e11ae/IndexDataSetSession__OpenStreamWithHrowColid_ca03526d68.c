
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong *param_3,ulonglong param_4,
                 uint param_5,longlong *param_6)

{
  longlong *plVar1;
  code *pcVar2;
  byte bVar3;
  undefined8 uVar4;
  char cVar5;
  ushort uVar6;
  ushort uVar7;
  int iVar8;
  int iVar9;
  uint *puVar10;
  longlong lVar11;
  longlong lVar12;
  undefined8 *puVar13;
  longlong lVar14;
  byte *pbVar15;
  ulonglong uVar16;
  uint uVar17;
  ushort *puVar18;
  longlong lVar19;
  uint uVar20;
  uint uVar21;
  uint *puVar22;
  undefined8 uVar23;
  ushort *puVar24;
  ulonglong uVar25;
  uint *puVar26;
  longlong *plVar27;
  longlong *plVar28;
  longlong unaff_GS_OFFSET;
  undefined8 auStack_200 [5];
  uint *puStack_1d8;
  uint auStack_1d0 [2];
  uint *puStack_1c8;
  uint auStack_1c0 [2];
  longlong *plStack_1b8;
  undefined4 auStack_1b0 [2];
  longlong alStack_1a8 [2];
  uint uStack_198;
  uint uStack_194;
  byte bStack_190;
  uint uStack_18c;
  byte bStack_188;
  byte bStack_187;
  byte bStack_186;
  undefined4 uStack_184;
  undefined8 uStack_178;
  uint uStack_168;
  undefined4 uStack_164;
  undefined2 uStack_160;
  ushort uStack_15c;
  ushort uStack_158;
  ushort uStack_154;
  ushort uStack_150;
  short sStack_14c;
  ushort uStack_148;
  uint uStack_144;
  int iStack_140;
  uint uStack_13c;
  uint uStack_138;
  int iStack_130;
  uint uStack_12c;
  uint *puStack_128;
  undefined4 uStack_120;
  uint uStack_118;
  undefined4 uStack_110;
  uint uStack_10c;
  uint uStack_108;
  uint uStack_100;
  undefined auStack_fc [4];
  uint uStack_f8;
  uint uStack_f4;
  undefined8 uStack_f0;
  longlong lStack_e8;
  longlong *plStack_e0;
  uint *puStack_d8;
  ushort *puStack_d0;
  longlong *plStack_c8;
  longlong *plStack_c0;
  ulonglong uStack_b8;
  longlong lStack_b0;
  undefined8 uStack_a8;
  undefined8 uStack_90;
  uint *puStack_88;
  longlong *plStack_80;
  ulonglong uStack_78;
  undefined auStack_58 [32];
  ulonglong uStack_38;
  
  uStack_90 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)&uStack_198;
  puVar22 = (uint *)0x0;
  iVar9 = 0;
  uStack_184 = 0;
  uStack_12c = param_5;
  *param_6 = 0;
  auStack_200[0] = 0x100098;
  plStack_c8 = param_3;
  uStack_b8 = param_4;
  lStack_b0 = param_1;
  uStack_a8 = param_2;
  puVar10 = (uint *)func_0x
                              (*(undefined8 *)
                                (*(longlong *)(*(longlong *)(param_1 + 0x10) + 8) + 0x160),
                               param_4 & 0xffffffff);
  bStack_190 = *(byte *)((longlong)puVar10 + 0x21) & 4;
  iStack_130 = (bStack_190 != 0) + 1;
  if (param_3 == (longlong *)0x0) {
    puStack_1d8 = (uint *)0x0;
    auStack_200[0] = 0x1000db;
    (*_DAT_)(1,0x19fb620,0x19cef00,0xddd);
  }
  puStack_88 = *(uint **)(param_1 + 0x108);
  if (((*(byte *)(*(longlong *)(**(longlong **)(puStack_88 + 8) + 8) + 0x107) & 0x40) == 0) ||
     ((*puStack_88 & 0x1000000) != 0)) {
    uVar23 = 0;
  }
  else {
    uVar23 = 1;
  }
  auStack_200[0] = 0x100132;
  plStack_c0 = param_3;
  iVar8 = func_0x(param_3,puStack_88 + 0x24,uVar23,auStack_58);
  if (iVar8 == 0x40f02) {
    auStack_200[0] = 0x100141;
    func_0x(param_3);
    auStack_200[0] = 0x10014a;
    (**(code **)(*param_3 + 8))(param_3);
    auStack_200[0] = 0x100160;
    (*_DAT_)(0xdc,0x12,0x19);
  }
  *(uint *)(param_3 + 2) = *(uint *)(param_3 + 2) & 0xfffffeff;
  if (((char)*(uint *)(param_3 + 2) < '\0') || ((*(byte *)((longlong)param_3 + 0x34) & 1) == 0)) {
    auStack_200[0] = 0x10019e;
    uStack_178 = (longlong *)func_0x(param_3,0);
  }
  else if ((*(uint *)(param_3 + 2) >> 0xd & 1) == 0) {
    uStack_178 = param_3 + 9;
  }
  else {
    uStack_178 = (longlong *)param_3[0x29];
  }
  plVar28 = uStack_178;
  puVar18 = (ushort *)((longlong)uStack_178 + 2);
  plStack_e0 = uStack_178;
  plStack_80 = uStack_178;
  if (*(short *)uStack_178 == 0) {
    auStack_200[0] = 0x1001ca;
    func_0x();
  }
  else {
    auStack_200[0] = 0x1001d1;
    func_0x(puVar18,&uStack_164);
  }
  uStack_120 = 0x1f9e;
  auStack_200[0] = 0x1001e2;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  bVar3 = *(byte *)(puVar10 + 8) >> 1;
  puStack_d8 = puVar10;
  if (*(short *)plVar28 != 0) {
    uStack_168 = 0;
    *(uint **)((longlong)auStack_1d0 + lVar11 + -8) = &uStack_168;
    *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100c2e;
    puVar22 = (uint *)func_0x(puVar18,puVar10);
    puStack_128 = puVar22;
    if ((((*(short *)plVar28 != 0) && (plVar27 = (longlong *)plVar28[2], plVar27 != (longlong *)0x0)
         ) && (*plVar27 != 0)) &&
       (((*(byte *)((longlong)puVar10 + 6) & 8) == 0 && ((uStack_168 & 1) == 0)))) {
      if ((puVar22 == (uint *)0x0) || (puVar22 == (uint *)0x15cf220)) {
        puVar22 = (uint *)0x0;
        uStack_198 = 0;
        puStack_128 = puVar22;
      }
      else {
        *(uint *)((longlong)auStack_1c0 + lVar11) = uStack_168;
        *(uint **)((longlong)&puStack_1c8 + lVar11) = &uStack_198;
        *(undefined4 *)((longlong)auStack_1d0 + lVar11) = 0x1f9e;
        *(longlong *)((longlong)auStack_1d0 + lVar11 + -8) = (longlong)&uStack_198 + lVar11;
        uVar17 = uStack_198;
        *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100c92;
        puVar22 = (uint *)func_0x(plVar27,puVar10,puVar22,uVar17);
        puStack_128 = puVar22;
      }
    }
    goto LAB_;
  }
  uVar17 = *puVar10;
  puStack_d0 = puVar18;
  if ((uVar17 & 0xc0000000) == 0x80000000) {
    *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100bef;
    iVar9 = func_0x(puVar18);
    if (iVar9 != 0) {
      *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100c0e;
      puVar22 = (uint *)func_0x((short *)((longlong)plVar28 + 0x2a),puVar10,&uStack_198,
                                        auStack_fc);
      goto LAB_;
    }
LAB_:
    uStack_198 = 0;
    goto LAB_;
  }
  if (((bVar3 & 1) == 0) && ((*(byte *)((longlong)puVar10 + 6) & 0x10) == 0)) {
    uStack_18c = 0;
LAB_:
    iVar8 = 1;
LAB_:
    if (((bVar3 & 1) != 0) && (uStack_18c != 0)) goto LAB_;
    if ((iVar8 == 0) && ((*(byte *)((longlong)puVar10 + 6) & 0x10) != 0)) {
      puVar22 = *(uint **)(puVar10 + 2) + 1;
      uStack_198 = **(uint **)(puVar10 + 2);
      goto LAB_;
    }
  }
  else {
    pbVar15 = (byte *)plVar28[1];
    if ((*pbVar15 & 0x10) == 0) {
      bStack_188 = *pbVar15 & 0xe;
      if ((1 << bStack_188 & 0x1105U) == 0) {
        uStack_18c = 0;
        iVar8 = 1;
      }
      else {
        uStack_18c = ~(uint)(*(ushort *)((longlong)puVar10 + 6) >> 4) & 1;
        iVar8 = iVar9;
      }
      goto LAB_;
    }
    uVar21 = *(uint *)(plVar28 + 2);
    if ((int)uVar21 <= (int)uVar17) {
LAB_:
      uStack_18c = ~(uint)(*(ushort *)((longlong)puVar10 + 6) >> 4) & 1;
      iVar8 = 0;
      goto LAB_;
    }
    if (*(ushort *)(pbVar15 + uVar21) < *(ushort *)(puVar10 + 1)) goto LAB_;
    if ((bVar3 & 1) != 0) {
      uStack_118 = *(ushort *)(puVar10 + 1) - 1;
      bStack_187 = pbVar15[(ulonglong)(uStack_118 >> 3) + (ulonglong)uVar21 + 2] >>
                   ((byte)uStack_118 & 7);
      uStack_18c = bStack_187 & 1;
      goto LAB_;
    }
    uStack_18c = 0;
    uStack_110 = 1;
  }
  if (-1 < (int)uVar17) {
    uVar7 = *(ushort *)((longlong)puVar10 + 6);
    if ((uVar7 & 8) != 0) {
      puVar22 = (uint *)0x15cf220;
      if ((*(byte *)((longlong)(int)uVar17 + plVar28[1]) & (byte)(1 << ((byte)uVar7 & 7))) == 0) {
        puVar22 = (uint *)0x15cf221;
      }
      uStack_198 = 1;
      goto LAB_;
    }
    if ((uVar7 & 0x10) != 0) {
      pbVar15 = (byte *)plVar28[1];
      if ((*pbVar15 & 0x10) == 0) {
        if ((1 << (*pbVar15 & 0xe) & 0x1105U) != 0) {
LAB_:
          puVar22 = *(uint **)(puVar10 + 2) + 1;
          uStack_198 = **(uint **)(puVar10 + 2);
          if (uStack_198 != 0x1f9e) {
            *(undefined8 *)((longlong)auStack_1d0 + lVar11 + -8) = 0;
            *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x1003ac;
            (*_DAT_)(1,0x19f89d0,0x19f7338,0x381);
          }
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(plVar28 + 2) <= (int)uVar17) ||
              (*(ushort *)(pbVar15 + *(uint *)(plVar28 + 2)) < *(ushort *)(puVar10 + 1)))
      goto LAB_;
    }
    uStack_198 = 0x1f9e;
    puVar22 = (uint *)((longlong)(int)*puVar10 + plVar28[1]);
    goto LAB_;
  }
  plVar27 = plVar28;
  if (*(int *)((longlong)plVar28 + 4) == 0) {
    uStack_194 = 0;
    *puVar18 = 0;
    uVar17 = *(uint *)(plVar28 + 2);
    *(uint *)((longlong)plVar28 + 0x14) = uVar17;
    pbVar15 = (byte *)plVar28[1];
    if ((*pbVar15 & 0x10) != 0) {
      uVar17 = uVar17 + 2 + (*(ushort *)(pbVar15 + *(uint *)(plVar28 + 2)) + 7 >> 3);
      *(uint *)((longlong)plVar28 + 0x14) = uVar17;
      pbVar15 = (byte *)plVar28[1];
    }
    if ((*pbVar15 & 0x20) == 0) {
      *(uint *)((longlong)plVar28 + 4) = uVar17;
      *(short *)((longlong)plVar28 + 0x1c) = 0;
      *(undefined4 *)(plVar28 + 3) = *(undefined4 *)((longlong)plVar28 + 0x14);
    }
    else {
      puVar24 = (ushort *)(pbVar15 + uVar17);
      uVar7 = *puVar24;
      *(ushort *)((longlong)plVar28 + 0x1c) = uVar7;
      puVar26 = puVar22;
      if (uVar7 == 0) {
        puVar26 = (uint *)0x1;
        uStack_194 = 1;
        *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100452;
        cVar5 = func_0x(0x1f5ab80);
        if (cVar5 != '\0') {
          *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x10045b;
          lVar12 = func_0x();
          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100475;
            cVar5 = func_0x(0x1f5ab80);
            if (cVar5 == '\0') {
              *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100491;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)((longlong)auStack_1d0 + lVar11 + -8) = 0;
              *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x1004b5;
              (*_DAT_)(1,0x184a58c,0x196a678,0x80f);
            }
          }
        }
        lVar12 = plVar28[1];
        *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x1004c3;
        func_0x(lVar12,3);
        uVar7 = *(ushort *)((longlong)plVar28 + 0x1c);
      }
      uVar17 = *(int *)((longlong)plVar28 + 0x14) + (uVar7 + 1) * 2;
      *(uint *)(plVar28 + 3) = uVar17;
      if (0x1f9e < uVar17) {
        uStack_194 = (int)puVar26 + 1;
        puVar26 = (uint *)(ulonglong)uStack_194;
        *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x1004f5;
        cVar5 = func_0x(0x1f5ab80);
        if (cVar5 != '\0') {
          *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x1004fe;
          lVar12 = func_0x();
          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100518;
            cVar5 = func_0x(0x1f5ab80);
            if (cVar5 == '\0') {
              *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100534;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)((longlong)auStack_1d0 + lVar11 + -8) = 0;
              *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100558;
              (*_DAT_)(1,0x184a58c,0x196a678,0x816);
            }
          }
        }
        lVar12 = plVar28[1];
        *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100566;
        func_0x(lVar12,4);
      }
      uStack_15c = puVar24[*(ushort *)((longlong)plVar28 + 0x1c)];
      *(uint *)((longlong)plVar28 + 4) = uStack_15c & 0x7fff;
      uVar17 = *(uint *)(plVar28 + 3);
      if ((uStack_15c & 0x7fff) < uVar17) {
        uStack_194 = (int)puVar26 + 1;
        puVar26 = (uint *)(ulonglong)uStack_194;
        *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x10059a;
        cVar5 = func_0x(0x1f5ab80);
        if (cVar5 != '\0') {
          *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x1005a3;
          lVar12 = func_0x();
          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x1005bd;
            cVar5 = func_0x(0x1f5ab80);
            if (cVar5 == '\0') {
              *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x1005d9;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)((longlong)auStack_1d0 + lVar11 + -8) = 0;
              *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x1005fd;
              (*_DAT_)(1,0x184a58c,0x196a678,0x81d);
            }
          }
        }
        lVar12 = plVar28[1];
        *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x10060b;
        func_0x(lVar12,4);
        uVar17 = *(uint *)(plVar28 + 3);
      }
      uStack_144 = 0;
      while( true ) {
        uVar7 = *(ushort *)((longlong)plVar28 + 0x1c);
        iVar8 = (int)puVar22;
        iVar9 = (int)puVar26;
        if ((int)(uint)uVar7 <= iVar8) break;
        uStack_158 = puVar24[(longlong)iVar8 + 1];
        uVar21 = uStack_158 & 0x7fff;
        if ((uVar21 < uVar17) || (*(uint *)((longlong)plVar28 + 4) < uVar21)) {
          uStack_194 = iVar9 + 1;
          puVar26 = (uint *)(ulonglong)uStack_194;
          *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x10065f;
          cVar5 = func_0x(0x1f5ab80);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100668;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100682;
              cVar5 = func_0x(0x1f5ab80);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x10069e;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)((longlong)auStack_1d0 + lVar11 + -8) = 0;
                *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x1006c4;
                (*_DAT_)(1,0x184a58c,0x196a678,0x82a);
              }
            }
          }
          lVar12 = plVar28[1];
          *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x1006d2;
          func_0x(lVar12,4);
        }
        uStack_144 = iVar8 + 1;
        puVar22 = (uint *)(ulonglong)uStack_144;
        uVar17 = uVar21;
      }
      do {
        if (-1 < (short)puVar24[(ulonglong)(uVar7 - 1) + 1]) break;
        lVar12 = plVar28[1];
        lVar14 = (ulonglong)*(uint *)((longlong)plVar28 + 0x14) + lVar12;
        if (uVar7 == 1) {
          uVar17 = *(uint *)(plVar28 + 3);
        }
        else {
          uStack_148 = *(ushort *)(lVar14 + 2 + (longlong)(int)(uVar7 - 2) * 2);
          uVar17 = uStack_148 & 0x7fff;
        }
        uStack_154 = *(ushort *)(lVar14 + 2 + (longlong)(int)(uVar7 - 1) * 2);
        uVar20 = uStack_154 & 0x7fff;
        uVar21 = *(uint *)(plVar28 + 3);
        uStack_f8 = uVar17;
        uStack_f4 = uVar20;
        if (((uVar17 < uVar21) || (uVar20 < uVar17)) || (*(uint *)((longlong)plVar28 + 4) < uVar20))
        {
          *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x10076d;
          func_0x(lVar12,7);
          uVar21 = *(uint *)(plVar28 + 3);
        }
        uVar20 = uVar20 - uVar17;
        uStack_10c = uVar17;
        if ((uVar17 < uVar21) || (*(uint *)((longlong)plVar28 + 4) < uVar17)) {
          uStack_194 = iVar9 + 1;
          plVar27 = uStack_178;
          goto LAB_;
        }
        uStack_150 = *(ushort *)((ulonglong)uVar17 + plVar28[1]);
        if (uStack_150 == 5) {
          *puVar18 = *puVar18 | 2;
          *(short *)((longlong)plVar28 + 0x1c) = *(short *)((longlong)plVar28 + 0x1c) + -1;
          *(short *)((longlong)plVar28 + 0x2a) = (short)uVar17;
          lVar12 = ((ulonglong)uVar17 & 0xffff) + plVar28[1];
          uVar7 = *(ushort *)(lVar12 + 2);
          *(ushort *)((longlong)plVar28 + 0x2c) = *(ushort *)((longlong)plVar28 + 0x2c) & 0xc7ff;
          if ((uVar7 >> 0xe & 1) != 0) {
            *(ushort *)((longlong)plVar28 + 0x2c) =
                 *(ushort *)((longlong)plVar28 + 0x2c) | uVar7 & 0x3800;
          }
          uVar7 = *(ushort *)((longlong)plVar28 + 0x2c);
          uVar6 = (uVar7 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar7;
          *(ushort *)((longlong)plVar28 + 0x2c) = uVar6;
          uVar16 = (ulonglong)*(ushort *)((longlong)plVar28 + 0x2a);
          uVar25 = (ulonglong)((uVar7 >> 0xb & 7) * 2) + 4 + ((ulonglong)uVar6 & 0x7ff) * 2 +
                   plVar28[1] + uVar16;
          uStack_108 = uVar20;
          uStack_78 = uVar25;
          if (uVar25 < plVar28[1] + uVar16) {
            lVar12 = plVar28[1];
            *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x10084b;
            func_0x(lVar12 + uVar16,0x19);
            uVar6 = *(ushort *)((longlong)plVar28 + 0x2c);
          }
          uVar7 = *(ushort *)((longlong)plVar28 + 0x2a);
          uStack_100 = (((uVar6 & 0x7ff) * 2 - *(int *)(plVar28 + 1)) - (uint)uVar7) + (int)uVar25;
          if (uVar20 < uStack_100) {
            lVar12 = plVar28[1];
            *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100888;
            func_0x((ulonglong)(uint)uVar7 + lVar12,0x19);
            uVar6 = *(ushort *)((longlong)plVar28 + 0x2c);
          }
          if ((uVar6 & 0x3800) != 0) {
            uVar7 = *(ushort *)((longlong)plVar28 + 0x2a);
            lVar12 = plVar28[1];
            iStack_140 = 0;
            while (iVar8 = iStack_140,
                  iStack_140 < (int)(*(ushort *)((longlong)plVar28 + 0x2c) >> 0xb & 7)) {
              if ((*(ushort *)((longlong)plVar28 + 0x2c) & 0x7ff) <
                  (*(ushort *)(lVar12 + (ulonglong)uVar7 + 4 + (longlong)iStack_140 * 2) & 0x7ff)) {
                uVar6 = *(ushort *)((longlong)plVar28 + 0x2a);
                lVar14 = plVar28[1];
                *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x1008e7;
                func_0x((ulonglong)uVar6 + lVar14,0x1a);
              }
              iStack_140 = iVar8 + 1;
            }
          }
          break;
        }
        if (uStack_150 < 0x400) break;
        *puVar18 = *puVar18 | 1;
        uVar7 = *(short *)((longlong)plVar28 + 0x1c) - 1;
        *(ushort *)((longlong)plVar28 + 0x1c) = uVar7;
      } while (uVar7 != 0);
    }
    if ((*(byte *)plVar28[1] & 0x40) == 0) {
      *(undefined4 *)((longlong)plVar28 + 0x26) = 0;
    }
    else {
      *(undefined4 *)((longlong)plVar28 + 0x26) = *(undefined4 *)((longlong)plVar28 + 4);
      *(int *)((longlong)plVar28 + 4) = *(int *)((longlong)plVar28 + 4) + 0xe;
      *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100945;
      puVar13 = (undefined8 *)func_0x(puVar18);
      uStack_f0 = *puVar13;
      *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x10095b;
      iVar8 = func_0x(&uStack_f0);
      *(int *)((longlong)plVar28 + 4) = *(int *)((longlong)plVar28 + 4) + iVar8;
    }
    if ((*(ulonglong *)((longlong)plVar28 + 0x1e) != 0) &&
       (*(ulonglong *)((longlong)plVar28 + 0x1e) <
        (ulonglong)*(uint *)((longlong)plVar28 + 4) + plVar28[1])) {
      iVar9 = iVar9 + 1;
      uStack_194 = iVar9;
      *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100993;
      cVar5 = func_0x(0x1f5ab80);
      if (cVar5 != '\0') {
        *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x10099c;
        lVar12 = func_0x();
        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
          *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x1009b6;
          cVar5 = func_0x(0x1f5ab80);
          if (cVar5 == '\0') {
            *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x1009d2;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)((longlong)auStack_1d0 + lVar11 + -8) = 0;
            *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x1009f6;
            (*_DAT_)(1,0x184a58c,0x196a678,0x886);
          }
        }
      }
      lVar12 = plVar28[1];
      *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100a04;
      func_0x(lVar12,0x12);
    }
    plVar27 = uStack_178;
    uStack_194 = iVar9;
    if (0x3f3b < *(int *)((longlong)plVar28 + 4) - 1U) {
      uStack_194 = iVar9 + 1;
      *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100a27;
      cVar5 = func_0x(0x1f5ab80);
      if (cVar5 != '\0') {
        *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100a30;
        lVar12 = func_0x();
        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
          *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100a4a;
          cVar5 = func_0x(0x1f5ab80);
          if (cVar5 == '\0') {
            *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100a66;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)((longlong)auStack_1d0 + lVar11 + -8) = 0;
            *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100a8a;
            (*_DAT_)(1,0x184a58c,0x196a678,0x88b);
          }
        }
      }
      lVar12 = plVar28[1];
      *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100a98;
      func_0x(lVar12,5);
      plVar27 = uStack_178;
      uStack_194 = iVar9 + 1;
    }
  }
LAB_:
  sStack_14c = -*(short *)puVar10;
  param_3 = plStack_c8;
  if ((*(byte *)((longlong)puVar10 + 6) & 0x10) == 0) {
LAB_:
    uVar17 = (uint)sStack_14c;
    if (*(ushort *)((longlong)plVar28 + 0x1c) < uVar17) {
      uStack_198 = 0;
      puVar22 = (uint *)plVar28[1];
      plVar28 = plVar27;
    }
    else {
      plVar1 = plVar28 + 1;
      lVar12 = *plVar1;
      lStack_e8 = (ulonglong)*(uint *)((longlong)plVar28 + 0x14) + lVar12;
      if (uVar17 == 1) {
        uVar21 = *(uint *)(plVar28 + 3);
      }
      else {
        uVar21 = *(ushort *)(lStack_e8 + 2 + (longlong)(int)(uVar17 - 2) * 2) & 0x7fff;
        lVar12 = *plVar1;
        param_5 = uStack_12c;
        puVar18 = puStack_d0;
        puVar10 = puStack_d8;
        plVar27 = plStack_e0;
      }
      uVar20 = *(ushort *)(lStack_e8 + 2 + (longlong)(int)(uVar17 - 1) * 2) & 0x7fff;
      uStack_138 = uVar17;
      if (((uVar21 < *(uint *)(puVar18 + 0xb)) || (uVar20 < uVar21)) ||
         (*(uint *)(puVar18 + 1) < uVar20)) {
        *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100bbe;
        func_0x(lVar12,7);
      }
      puVar22 = (uint *)((ulonglong)uVar21 + *plVar1);
      param_3 = plStack_c8;
      plVar28 = plVar27;
      uStack_198 = uVar20 - uVar21;
    }
  }
  else {
    pbVar15 = (byte *)plVar28[1];
    if ((*pbVar15 & 0x10) == 0) {
      bStack_186 = *pbVar15 & 0xe;
      uVar17 = 1 << bStack_186 & 0x1105;
      uStack_13c = (uint)(uVar17 == 0);
      if (uVar17 == 0) goto LAB_;
    }
    else if (((int)*puVar10 < (int)*(uint *)(plVar28 + 2)) &&
            (*(ushort *)(puVar10 + 1) <= *(ushort *)(pbVar15 + *(uint *)(plVar28 + 2)))) {
      uStack_13c = 1;
      goto LAB_;
    }
    puVar22 = *(uint **)(puVar10 + 2) + 1;
    plVar28 = plVar27;
    uStack_198 = **(uint **)(puVar10 + 2);
  }
LAB_:
  if (puVar22 == (uint *)0x0) {
    param_5 = param_5 | 8;
  }
  else {
    *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100cbe;
    iVar9 = func_0x(plVar28,puVar10);
    if (iVar9 == 0) {
      param_5 = param_5 | 0x200;
    }
  }
  *(undefined8 *)((longlong)auStack_200 + lVar11) = 0x100ceb;
  lVar14 = func_0x();
  lVar14 = -lVar14;
  lVar12 = (longlong)&uStack_198 + lVar14 + lVar11;
  *(undefined8 *)((longlong)auStack_200 + lVar14 + lVar11) = 0x100d01;
  func_0x(lVar12);
  pcVar2 = *(code **)(*plStack_c0 + 8);
  *(undefined8 *)((longlong)auStack_200 + lVar14 + lVar11) = 0x100d0e;
  (*pcVar2)();
  *(undefined8 **)((longlong)alStack_1a8 + lVar14 + lVar11) = &uStack_178;
  *(undefined4 *)((longlong)auStack_1b0 + lVar14 + lVar11) = 0;
  *(longlong **)((longlong)&plStack_1b8 + lVar14 + lVar11) = param_6;
  *(uint *)((longlong)auStack_1c0 + lVar14 + lVar11) = param_5;
  uVar16 = uStack_b8;
  *(ulonglong *)((longlong)&puStack_1c8 + lVar14 + lVar11) = uStack_b8;
  *(uint *)((longlong)auStack_1d0 + lVar14 + lVar11) = uStack_198;
  *(longlong *)((longlong)auStack_1d0 + lVar14 + lVar11 + -8) = lVar12;
  uVar4 = uStack_a8;
  lVar12 = lStack_b0;
  iVar9 = iStack_130;
  uVar23 = *(undefined8 *)(lStack_b0 + 0x1e8);
  *(undefined8 *)((longlong)auStack_200 + lVar14 + lVar11) = 0x100d71;
  uStack_184 = func_0x(lVar12,uVar4,uVar23,iVar9);
  lVar12 = *param_6;
  if (bStack_190 == 0) {
    *(int *)((longlong)param_3 + 0xc) = *(int *)((longlong)param_3 + 0xc) + 1;
    *(longlong **)(lVar12 + 0x150) = param_3;
    *(undefined4 *)(lVar12 + 0x158) = 2;
  }
  else {
    *(longlong **)(lVar12 + 0x38) = param_3;
    *(undefined4 *)(lVar12 + 0x40) = 2;
    *(ulonglong *)(lVar12 + 0x48) = uVar16;
  }
  lVar19 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar12 = *(longlong *)(lVar19 + 0x100);
  if (lVar12 == 0) {
    *(undefined8 *)((longlong)auStack_200 + lVar14 + lVar11) = 0x100dd4;
    (*_DAT_)();
    lVar12 = *(longlong *)(lVar19 + 0x100);
  }
  if (*(int *)(lVar12 + 0x22c) != 0) {
    *(undefined8 *)((longlong)auStack_200 + lVar14 + lVar11) = 0x100dea;
    (*_DAT_)();
  }
  uVar16 = uStack_38 ^ (ulonglong)&uStack_198;
  *(undefined8 *)((longlong)auStack_200 + lVar14 + lVar11) = 0x100dfc;
  func_0x(uVar16);
  return;
}

