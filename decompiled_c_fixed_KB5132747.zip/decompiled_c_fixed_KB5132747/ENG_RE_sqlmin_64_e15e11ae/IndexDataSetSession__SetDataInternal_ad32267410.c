
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x01103f35) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,longlong *param_3,longlong **param_4)

{
  undefined2 *puVar1;
  undefined2 uVar2;
  byte *pbVar3;
  code *pcVar4;
  longlong *plVar5;
  byte bVar6;
  char cVar7;
  short sVar8;
  ushort uVar9;
  int iVar10;
  uint uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  longlong lVar14;
  longlong lVar15;
  short *psVar16;
  undefined2 *puVar17;
  undefined8 uVar18;
  longlong **pplVar19;
  undefined8 uVar20;
  uint uVar21;
  int *piVar22;
  ulonglong uVar23;
  longlong lVar24;
  undefined2 uStackX_10;
  undefined2 uStackX_12;
  uint uStackX_14;
  byte *pbStackX_18;
  undefined8 uStackX_20;
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar14 = func_0x();
  lVar14 = -lVar14;
  puVar1 = (undefined2 *)((longlong)&uStackX_10 + lVar14);
  *(undefined8 *)(&stack0x00000300 + lVar14) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00006950 + lVar14) = _DAT_ ^ (ulonglong)puVar1;
  *(longlong ***)(&stack0x00000298 + lVar14) = param_4;
  *(longlong **)(&stack0x00000050 + lVar14) = param_3;
  *(longlong **)(&stack0x00000148 + lVar14) = param_2;
  *(longlong *)(&stack0x000000a8 + lVar14) = param_1;
  *(undefined8 *)(&stack0x000002f0 + lVar14) = 0;
  *(undefined (*) [16])(&stack0x000002e0 + lVar14) = ZEXT816(0);
  *(undefined8 **)(&stack0x00000290 + lVar14) = (undefined8 *)(param_1 + 0x10);
  uVar18 = *(undefined8 *)(param_1 + 0x10);
  *(undefined8 *)(&stack0x00000088 + lVar14) = uVar18;
  *(undefined8 *)(&stack0x00000150 + lVar14) = 0;
  *(undefined4 *)(&stack0x00000110 + lVar14) = 0;
  *(longlong *)(&stack0x00000118 + lVar14) = *param_3;
  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1000a9;
  func_0x(&stack0x00000400 + lVar14);
  *(undefined4 *)(&stack0x00000114 + lVar14) = 0;
  lVar24 = *(longlong *)(param_1 + 0x18);
  *(longlong *)(&stack0x00000098 + lVar14) = lVar24;
  lVar24 = *(longlong *)(lVar24 + 0x30);
  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1000d3;
  func_0x(&stack0x000002a0 + lVar14,param_1,2);
  *puVar1 = 0xffff;
  *(undefined8 *)((longlong)&pbStackX_18 + lVar14) = 0;
  *(undefined4 *)((longlong)&uStackX_10 + lVar14 + 4) = 0;
  *(undefined8 *)(&stack0x0000002e + lVar14) = 0;
  *(undefined8 *)(&stack0x00000038 + lVar14) = 0;
  *(undefined8 *)((longlong)&uStackX_20 + lVar14) = 0;
  uVar23 = 0x3f3c;
  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100106;
  func_0x(&stack0x00002a10 + lVar14,0);
  if (param_4 != (longlong **)0x0) {
    *param_4 = param_2;
  }
  lVar15 = *(longlong *)(param_1 + 0x108);
  if ((*(byte *)(*(longlong *)(**(longlong **)(lVar15 + 0x20) + 8) + 0x107) & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100147;
  iVar10 = func_0x(param_2,lVar15 + 0x90,uVar23 & 0xffffffffffffff00,
                           &stack0x000002d8 + lVar14);
  if (iVar10 == 0x40f02) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10015a;
  lVar15 = func_0x(uVar18);
  if ((*(byte *)(lVar15 + 0x3c) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar15 = *(longlong *)(&stack0x00000118 + lVar14);
  if ((*(byte *)(lVar15 + 0x5c) & 8) != 0) {
    if ((*(byte *)(*(longlong *)(**(longlong **)(*(longlong *)(param_1 + 0x108) + 0x20) + 8) + 0x107
                  ) & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar21 = *(uint *)(param_2 + 2);
    uVar11 = uVar21 & 0xfffffeff;
    *(uint *)(param_2 + 2) = uVar11;
    if (((char)uVar11 < '\0') || ((*(byte *)((longlong)param_2 + 0x34) & 1) == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((uVar21 >> 0xd & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    plVar5 = param_2 + 9;
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1001d2;
    iVar10 = func_0x(plVar5);
    if (iVar10 != 0) {
      if (*(short *)plVar5 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(int *)(param_2 + 0xb) == *(int *)(*(longlong *)(&stack0x00000118 + lVar14) + 0x14)) {
        if (*(short *)plVar5 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((*(byte *)param_2[10] & 0x10) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (((*(short *)((byte *)param_2[10] + *(uint *)(param_2 + 0xb)) ==
              *(short *)(*(longlong *)(*(longlong *)(&stack0x00000088 + lVar14) + 8) + 0xcc)) &&
            (*(int *)(param_2 + 0x2b) != 3)) && (*(char *)(lVar24 + 0x6b4e) == '\0')) {
          uVar21 = *(uint *)((longlong)param_2 + 0x4c);
          if (uVar21 == 0) {
            *(undefined2 *)((longlong)param_2 + 0x4a) = 0;
            uVar21 = *(uint *)(param_2 + 0xb);
            *(uint *)((longlong)param_2 + 0x5c) = uVar21;
            pbVar3 = (byte *)param_2[10];
            bVar6 = *pbVar3;
            if ((bVar6 & 0x10) != 0) {
              uVar21 = uVar21 + 2 + (*(ushort *)(pbVar3 + uVar21) + 7 >> 3);
              *(uint *)((longlong)param_2 + 0x5c) = uVar21;
              bVar6 = *pbVar3;
            }
            if ((bVar6 & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            *(uint *)((longlong)param_2 + 0x4c) = uVar21;
            *(undefined2 *)((longlong)param_2 + 100) = 0;
            *(undefined4 *)(param_2 + 0xc) = *(undefined4 *)((longlong)param_2 + 0x5c);
            if ((*(byte *)param_2[10] & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            *(undefined4 *)((longlong)param_2 + 0x6e) = 0;
            uVar21 = *(uint *)((longlong)param_2 + 0x4c);
            if ((*(ulonglong *)((longlong)param_2 + 0x66) != 0) &&
               (*(ulonglong *)((longlong)param_2 + 0x66) < (ulonglong)uVar21 + param_2[10])) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            if ((uVar21 == 0) || (0x3f3c < uVar21)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
          }
          if (uVar21 < 9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          param_2 = *(longlong **)(&stack0x00000148 + lVar14);
          if (0x80 < uVar21) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          param_3 = *(longlong **)(&stack0x00000050 + lVar14);
        }
      }
    }
    pcVar4 = *(code **)(*param_2 + 8);
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10033e;
    (*pcVar4)(param_2);
    lVar15 = *(longlong *)(&stack0x00000118 + lVar14);
  }
  if ((*(byte *)(lVar15 + 0x38) & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((param_2 != (longlong *)0x0) && (*(int *)(param_2 + 1) == 1)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(byte *)(*param_3 + 0x38) & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((param_2 != (longlong *)0x0) && (*(int *)(param_2 + 1) == 1)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10039b;
  func_0x(&stack0x00000278 + lVar14,0);
  pcVar4 = *(code **)*param_2;
  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1003a4;
  psVar16 = (short *)(*pcVar4)(param_2);
  pcVar4 = *(code **)*param_2;
  if (*psVar16 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1003bb;
  puVar17 = (undefined2 *)(*pcVar4)(param_2);
  *(undefined2 **)(&stack0x00000078 + lVar14) = puVar17;
  *puVar17 = 0;
  *puVar1 = 0;
  lVar24 = *param_3;
  *(longlong *)(&stack0x00000060 + lVar14) = lVar24;
  if ((*(byte *)(lVar24 + 0x38) & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((**(byte **)(puVar17 + 4) & 0xe) == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (((*(byte *)(lVar24 + 0x5c) & 2) == 0) && (*(uint *)(puVar17 + 8) == *(uint *)(lVar24 + 0x14)))
  {
    if ((**(byte **)(puVar17 + 4) & 0x10) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(short *)(*(byte **)(puVar17 + 4) + *(uint *)(puVar17 + 8)) ==
        *(short *)(*(longlong *)(*(longlong *)(&stack0x00000088 + lVar14) + 8) + 0xcc)) {
      uVar21 = *(uint *)(puVar17 + 2);
      if (uVar21 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (uVar21 < 9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(undefined4 *)((longlong)&uStackX_20 + lVar14) = *(undefined4 *)(puVar17 + 8);
      *(undefined2 *)((longlong)&uStackX_10 + lVar14 + 2) = puVar17[1];
      *(undefined4 *)((longlong)&uStackX_10 + lVar14 + 4) = *(undefined4 *)(puVar17 + 2);
      *(undefined2 *)(&stack0x0000002c + lVar14) = puVar17[0xe];
      *(undefined4 *)((longlong)&uStackX_20 + lVar14 + 4) = *(undefined4 *)(puVar17 + 10);
      *(undefined4 *)(&stack0x00000028 + lVar14) = *(undefined4 *)(puVar17 + 0xc);
      *(undefined4 *)(&stack0x00000036 + lVar14) = *(undefined4 *)(puVar17 + 0x13);
      uVar18 = *(undefined8 *)(puVar17 + 4);
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10049b;
      func_0x(&stack0x00002a10 + lVar14,0x3f3c,uVar18,uVar21);
      *(undefined **)((longlong)&pbStackX_18 + lVar14) = &stack0x00002a10 + lVar14;
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1004af;
      iVar10 = func_0x((longlong)&uStackX_10 + lVar14 + 2);
      if (iVar10 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((**(byte **)((longlong)&pbStackX_18 + lVar14) & 0xe) == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      plVar5 = *(longlong **)(&stack0x00000050 + lVar14);
      if ((*(byte *)(lVar24 + 0x5c) & 4) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar9 = *(ushort *)(*plVar5 + 0x62);
      piVar22 = *(int **)(*plVar5 + 0x70);
      if (uVar9 != 0) {
        uVar23 = (ulonglong)uVar9;
        do {
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100503;
          cVar7 = func_0x(plVar5,piVar22);
          if (cVar7 == '\x03') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100517;
          func_0x((longlong)&uStackX_10 + lVar14 + 2,piVar22);
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100529;
          func_0x(plVar5,piVar22,&stack0x000001b8 + lVar14);
          if (((uint)piVar22[0x10] >> 8 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          iVar10 = *piVar22;
          uVar2 = *(undefined2 *)(piVar22 + 0xf);
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100551;
          func_0x((longlong)iVar10 + *(longlong *)((longlong)&pbStackX_18 + lVar14),
                          *(undefined8 *)(&stack0x000001b8 + lVar14),uVar2);
          piVar22 = piVar22 + 0x14;
          uVar23 = uVar23 - 1;
        } while (uVar23 != 0);
      }
      if (*(int *)((longlong)&uStackX_10 + lVar14 + 4) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(uint *)((longlong)&uStackX_10 + lVar14 + 4) < 9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (0x3f3c < *(uint *)((longlong)&uStackX_10 + lVar14 + 4)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(int *)((longlong)&uStackX_10 + lVar14 + 4) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(uint *)((longlong)&uStackX_10 + lVar14 + 4) < 9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar21 = *(uint *)((longlong)&uStackX_10 + lVar14 + 4);
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1005b3;
      iVar10 = func_0x((longlong)&uStackX_10 + lVar14 + 2);
      uVar11 = *(uint *)(&stack0x00000036 + lVar14);
      if (iVar10 == 0) {
        uVar11 = uVar21;
      }
      lVar24 = *(longlong *)(&stack0x00000088 + lVar14);
      if (0x1f7c < uVar11) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar18 = *(undefined8 *)(&stack0x00000050 + lVar14);
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1005de;
      func_0x(&stack0x00000278 + lVar14);
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1005e9;
      iVar10 = func_0x(lVar24);
      if (iVar10 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1005f9;
        uVar18 = func_0x(uVar18);
        if (lVar24 != 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10060d;
          lVar15 = func_0x(uVar18);
          uVar21 = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10061d;
          sVar8 = func_0x(uVar18);
          if (sVar8 != 0) {
            do {
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100638;
              iVar10 = func_0x(lVar15);
              if (iVar10 == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10064b;
                pplVar19 = (longlong **)func_0x(lVar15,&stack0x00000398 + lVar14);
                uVar20 = *(undefined8 *)(lVar24 + 8);
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100658;
                cVar7 = func_0x(uVar20);
                if (cVar7 != '\0') {
                  if (*(int *)(*(longlong *)(lVar24 + 8) + 0x480) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                    halt_baddata();
                  }
                  if ((*pplVar19)[1] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                    halt_baddata();
                  }
                  plVar5 = (longlong *)(**pplVar19 + (longlong)pplVar19[1] * 8);
                  LOCK();
                  *plVar5 = *plVar5 + 1;
                  UNLOCK();
                  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1006a0;
                  uVar20 = func_0x(*(undefined8 *)(&stack0x00000098 + lVar14));
                  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1006a8;
                  cVar7 = func_0x(uVar20);
                  lVar24 = *(longlong *)(&stack0x00000088 + lVar14);
                  if (cVar7 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
                    halt_baddata();
                  }
                }
              }
              uVar21 = uVar21 + 1;
              lVar15 = lVar15 + 0x50;
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1006c3;
              uVar9 = func_0x(uVar18);
            } while (uVar21 < uVar9);
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1006d8;
      iVar10 = func_0x(puVar1);
      if (iVar10 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar18 = *(undefined8 *)(&stack0x00000148 + lVar14);
      lVar24 = *(longlong *)(&stack0x000000a8 + lVar14);
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100709;
      iVar10 = func_0x(*(undefined8 *)(&stack0x00000118 + lVar14));
      if (iVar10 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10071d;
      func_0x(&stack0x000004a8 + lVar14);
      uVar20 = *(undefined8 *)(*(longlong *)(lVar24 + 0x108) + 0x20);
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10072d;
      uVar20 = func_0x(uVar20);
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100735;
      lVar15 = func_0x(uVar20);
      if ((*(byte *)(lVar15 + 0x67) & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(longlong *)(lVar24 + 0x380) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar20 = *(undefined8 *)(lVar24 + 0x108);
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10075e;
      uVar12 = func_0x(uVar20);
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100768;
      uVar13 = func_0x(lVar24);
      *(undefined4 *)(&stack0xfffffffffffffff8 + lVar14) = uVar12;
      *(undefined8 *)(&stack0xfffffffffffffff0 + lVar14) = 0;
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
      *(undefined **)(&stack0xffffffffffffffe0 + lVar14) = &stack0x000002d8 + lVar14;
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100794;
      func_0x(uVar18,puVar1,uVar13,0);
      if (*(longlong *)(lVar24 + 0x380) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      lVar24 = *(longlong *)(&stack0x00000088 + lVar14);
      if ((*(longlong *)(*(longlong *)(lVar24 + 8) + 0x488) != 0) && (*_DAT_ != '\0')) {
        *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1007c9;
        uVar18 = func_0x();
        *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1007d6;
        iVar10 = func_0x(uVar18,0x281);
        if (iVar10 == 0) {
          lVar24 = *(longlong *)(*(longlong *)(lVar24 + 8) + 0x488);
          if (*(longlong *)(lVar24 + 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          LOCK();
          plVar5 = (longlong *)(*(longlong *)(lVar24 + 0x18) + 0x10);
          *plVar5 = *plVar5 + 1;
          UNLOCK();
        }
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100806;
      func_0x(&stack0x000002a0 + lVar14);
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100815;
      func_0x(*(ulonglong *)(&stack0x00006950 + lVar14) ^ (ulonglong)puVar1);
      return;
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

