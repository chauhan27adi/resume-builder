
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,char param_3)

{
  undefined2 uVar1;
  longlong *plVar2;
  code *pcVar3;
  uint **ppuVar4;
  char cVar5;
  undefined2 uVar6;
  ushort uVar7;
  ushort uVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  longlong lVar12;
  byte *pbVar13;
  ushort *puVar14;
  undefined8 uVar15;
  undefined4 *puVar16;
  longlong lVar17;
  longlong *plVar18;
  undefined4 *puVar19;
  longlong lVar20;
  uint *puVar21;
  byte bVar22;
  byte bVar23;
  ulonglong uVar24;
  uint uVar25;
  short sVar26;
  uint uVar27;
  undefined8 unaff_RBX;
  undefined4 *puVar28;
  uint uVar29;
  undefined8 *puVar30;
  undefined4 uVar31;
  ulonglong uVar32;
  longlong unaff_GS_OFFSET;
  int iStackX_8;
  ushort uStackX_c;
  ushort uStackX_e;
  byte *pbStackX_10;
  longlong *plStackX_18;
  undefined auStackX_20 [4];
  uint uStackX_24;
  uint uStack_1588;
  uint uStack_1584;
  undefined4 uStack_1580;
  undefined4 uStack_157c;
  undefined4 auStack_1578 [2];
  undefined8 uStack_1570;
  ushort uStack_1568;
  undefined8 uStack_1560;
  ushort uStack_1558;
  undefined4 uStack_1550;
  undefined4 uStack_154c;
  undefined auStack_1548 [4];
  undefined4 uStack_1544;
  undefined4 uStack_1540;
  undefined2 uStack_153c;
  undefined4 uStack_1538;
  undefined2 uStack_1534;
  undefined4 uStack_1530;
  undefined2 uStack_152c;
  undefined8 uStack_1528;
  undefined2 uStack_1520;
  undefined8 uStack_1518;
  undefined8 uStack_1510;
  undefined2 uStack_1508;
  undefined8 uStack_1500;
  ushort uStack_14f8;
  undefined auStack_14f0 [4];
  undefined auStack_14ec [4];
  undefined auStack_14e8 [4];
  undefined auStack_14e4 [4];
  undefined auStack_14e0 [8];
  uint uStack_14d8;
  undefined8 uStack_14d4;
  undefined8 uStack_14c0;
  undefined auStack_14b8 [8];
  undefined4 uStack_14b0;
  undefined4 uStack_14a8;
  uint **ppuStack_14a0;
  undefined *puStack_1498;
  undefined8 uStack_1490;
  uint *puStack_1488;
  undefined4 uStack_1480;
  undefined4 uStack_147c;
  longlong lStack_1478;
  undefined4 uStack_1470;
  undefined4 uStack_146c;
  longlong lStack_1468;
  undefined4 uStack_1460;
  undefined4 uStack_145c;
  short *psStack_1458;
  int iStack_1450;
  undefined4 uStack_144c;
  short *psStack_1448;
  int iStack_1440;
  undefined4 uStack_143c;
  undefined8 uStack_1438;
  undefined4 uStack_1430;
  undefined4 uStack_142c;
  undefined auStack_1428 [448];
  undefined8 uStack_1268;
  undefined8 uStack_1260;
  uint uStack_1258;
  undefined2 uStack_1254;
  undefined4 uStack_1252;
  undefined uStack_124e;
  undefined uStack_124d;
  undefined8 uStack_1218;
  undefined2 uStack_1210;
  undefined8 uStack_1208;
  undefined2 uStack_1200;
  undefined8 uStack_11f8;
  undefined2 uStack_11f0;
  undefined8 uStack_11e8;
  undefined2 uStack_11e0;
  undefined8 uStack_11d8;
  undefined2 uStack_11d0;
  undefined8 uStack_11c8;
  undefined2 uStack_11c0;
  undefined8 uStack_11b8;
  undefined2 uStack_11b0;
  undefined8 uStack_11a8;
  undefined2 uStack_11a0;
  undefined2 uStack_119e;
  undefined4 uStack_119c;
  undefined4 uStack_1198;
  undefined4 uStack_1194;
  undefined4 uStack_1190;
  undefined4 uStack_1188;
  undefined4 uStack_1184;
  undefined4 uStack_1180;
  undefined4 uStack_117c;
  undefined4 uStack_1178;
  undefined4 uStack_1174;
  undefined4 uStack_1170;
  undefined4 uStack_116c;
  undefined4 uStack_1168;
  undefined4 uStack_1164;
  undefined4 uStack_1160;
  undefined4 uStack_115c;
  short sStack_1158;
  ushort uStack_1156;
  uint uStack_1154;
  undefined4 *puStack_1150;
  undefined8 uStack_1148;
  uint uStack_1140;
  ushort uStack_113c;
  byte *pbStack_113a;
  undefined2 uStack_1132;
  undefined2 uStack_1130;
  ushort uStack_112e;
  ushort uStack_112c;
  undefined2 uStack_112a;
  undefined2 auStack_918 [2];
  undefined4 uStack_914;
  undefined8 uStack_910;
  undefined8 uStack_908;
  undefined8 uStack_8fa;
  undefined8 uStack_8f0;
  short asStack_d8 [24];
  short asStack_a8 [24];
  undefined auStack_78 [48];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  uStack_14c0 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000015e8 + lVar12) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar12);
  puVar19 = (undefined4 *)0x0;
  uVar25 = 0;
  *(undefined8 *)((longlong)&plStackX_18 + lVar12) = 0;
  auStackX_20[lVar12] = 0;
  uVar29 = *(uint *)((longlong)&uStackX_24 + lVar12);
  *(uint *)((longlong)&uStackX_24 + lVar12) = uVar29 & 0xffff0000;
  *(uint *)((longlong)&uStackX_24 + lVar12) = uVar29 & 0xff000000;
  *(undefined4 *)((longlong)&uStackX_24 + lVar12) = 0;
  sStack_1158 = -1;
  puStack_1150 = (undefined4 *)0x0;
  uStack_1154 = 0;
  pbStack_113a = (byte *)0x0;
  uStack_1130 = 0;
  uStack_112e = 0;
  uStack_112c = 0;
  uStack_112a = 0;
  uStack_1148 = (longlong *)0x0;
  uStack_1188 = *(undefined4 *)(param_1 + 0x88);
  uStack_1184 = *(undefined4 *)(param_1 + 0x8c);
  uStack_1180 = *(undefined4 *)(param_1 + 0x90);
  uStack_117c = *(undefined4 *)(param_1 + 0x94);
  uStack_154c = *(undefined4 *)(param_1 + 0x360);
  puVar14 = (ushort *)((longlong)&uStackX_c + lVar12 + 2);
  *puVar14 = *puVar14 & 0xffe0;
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1000cf;
  func_0x(&sStack_1158);
  *(undefined4 *)((longlong)&iStackX_8 + lVar12) = 0xffffffff;
  *(undefined2 *)((longlong)&uStackX_c + lVar12) = 1;
  puVar14 = (ushort *)((longlong)&uStackX_c + lVar12 + 2);
  *puVar14 = *puVar14 & 0xffe0;
  *(undefined8 *)((longlong)&uStackX_c + lVar12 + 4) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100104;
  func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar12,&uStack_1188,0x10);
  if (sStack_1158 == 0) {
    uVar29 = *(ushort *)((longlong)&uStackX_c + lVar12) - 1;
    uVar24 = (ulonglong)(uVar29 >> 3);
    *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
         *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
         ~(byte)(1 << (uVar29 & 7));
  }
  else {
    uVar7 = *(ushort *)((longlong)&uStackX_c + lVar12);
    if (uVar7 <= uStack_1156) {
      pbVar13 = (byte *)((longlong)puStack_1150 +
                        (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar7 - 1) / 2));
      bVar23 = *pbVar13;
      bVar22 = bVar23 >> 4;
      if ((uVar7 & 1) != 0) {
        bVar22 = bVar23 & 0xf;
      }
      if (bVar22 == 0) {
        if ((uVar7 & 1) == 0) {
          bVar23 = bVar23 & 0xf | 0x10;
        }
        else {
          bVar23 = bVar23 & 0xf1 | 1;
        }
        *pbVar13 = bVar23;
      }
    }
  }
  if (param_3 == '\0') {
    *(undefined4 *)((longlong)&iStackX_8 + lVar12) = 0xffffffd1;
    uVar6 = 0x2f;
    uVar31 = 4;
    puVar30 = (undefined8 *)&uStack_154c;
  }
  else {
    uStack_1168 = *(undefined4 *)(param_1 + 0xe4);
    uStack_1164 = *(undefined4 *)(param_1 + 0xe8);
    uStack_1160 = *(undefined4 *)(param_1 + 0xec);
    uStack_115c = *(undefined4 *)(param_1 + 0xf0);
    uStack_1178 = *(undefined4 *)(param_1 + 0xd4);
    uStack_1174 = *(undefined4 *)(param_1 + 0xd8);
    uStack_1170 = *(undefined4 *)(param_1 + 0xdc);
    uStack_116c = *(undefined4 *)(param_1 + 0xe0);
    uStack_1550 = *(undefined4 *)(param_1 + 0x1fc);
    uStack_11e8 = *(undefined8 *)(param_1 + 0x200);
    uStack_11e0 = *(undefined2 *)(param_1 + 0x208);
    uStack_11d8 = *(undefined8 *)(param_1 + 0x10c);
    uStack_11d0 = *(undefined2 *)(param_1 + 0x114);
    uStack_11c8 = *(undefined8 *)(param_1 + 0x118);
    uStack_11c0 = *(undefined2 *)(param_1 + 0x120);
    uStack_11b8 = *(undefined8 *)(param_1 + 0x174);
    uStack_11b0 = *(undefined2 *)(param_1 + 0x17c);
    uStack_11a8 = *(undefined8 *)(param_1 + 0x1de);
    uStack_11a0 = *(undefined2 *)(param_1 + 0x1e6);
    uStack_119e = *(undefined2 *)(param_1 + 0x1e8);
    uStack_119c = *(undefined4 *)(param_1 + 0x1ea);
    uStack_1198 = *(undefined4 *)(param_1 + 0x1ee);
    uStack_1194 = *(undefined4 *)(param_1 + 0x1f2);
    uStack_1190 = *(undefined4 *)(param_1 + 0x1f6);
    *(undefined4 *)((longlong)&iStackX_8 + lVar12) = 0xffffffe3;
    *(undefined2 *)((longlong)&uStackX_c + lVar12) = 0x1d;
    puVar14 = (ushort *)((longlong)&uStackX_c + lVar12 + 2);
    *puVar14 = *puVar14 & 0xffe0;
    *(undefined8 *)((longlong)&uStackX_c + lVar12 + 4) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1002df;
    func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar12,&uStack_1178,0x10);
    if (sStack_1158 == 0) {
      uVar29 = *(ushort *)((longlong)&uStackX_c + lVar12) - 1;
      uVar24 = (ulonglong)(uVar29 >> 3);
      *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
           *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
           ~(byte)(1 << (uVar29 & 7));
    }
    else {
      uVar7 = *(ushort *)((longlong)&uStackX_c + lVar12);
      if (uVar7 <= uStack_1156) {
        pbVar13 = (byte *)((longlong)puStack_1150 +
                          (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar7 - 1) / 2));
        bVar23 = *pbVar13;
        bVar22 = bVar23 >> 4;
        if ((uVar7 & 1) != 0) {
          bVar22 = bVar23 & 0xf;
        }
        if (bVar22 == 0) {
          if ((uVar7 & 1) == 0) {
            bVar23 = bVar23 & 0xf | 0x10;
          }
          else {
            bVar23 = bVar23 & 0xf1 | 1;
          }
          *pbVar13 = bVar23;
        }
      }
    }
    *(undefined4 *)((longlong)&iStackX_8 + lVar12) = 0xffffffe7;
    *(undefined2 *)((longlong)&uStackX_c + lVar12) = 0x19;
    puVar14 = (ushort *)((longlong)&uStackX_c + lVar12 + 2);
    *puVar14 = *puVar14 & 0xffe0;
    *(undefined8 *)((longlong)&uStackX_c + lVar12 + 4) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1003b9;
    func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar12,&uStack_1550,4);
    if (sStack_1158 == 0) {
      uVar29 = *(ushort *)((longlong)&uStackX_c + lVar12) - 1;
      uVar24 = (ulonglong)(uVar29 >> 3);
      *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
           *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
           ~(byte)(1 << (uVar29 & 7));
    }
    else {
      uVar7 = *(ushort *)((longlong)&uStackX_c + lVar12);
      if (uVar7 <= uStack_1156) {
        pbVar13 = (byte *)((longlong)puStack_1150 +
                          (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar7 - 1) / 2));
        bVar23 = *pbVar13;
        bVar22 = bVar23 >> 4;
        if ((uVar7 & 1) != 0) {
          bVar22 = bVar23 & 0xf;
        }
        if (bVar22 == 0) {
          if ((uVar7 & 1) == 0) {
            bVar23 = bVar23 & 0xf | 0x10;
          }
          else {
            bVar23 = bVar23 & 0xf1 | 1;
          }
          *pbVar13 = bVar23;
        }
      }
    }
    *(undefined4 *)((longlong)&iStackX_8 + lVar12) = 0xffffffe6;
    *(undefined2 *)((longlong)&uStackX_c + lVar12) = 0x1a;
    puVar14 = (ushort *)((longlong)&uStackX_c + lVar12 + 2);
    *puVar14 = *puVar14 & 0xffe0;
    *(undefined8 *)((longlong)&uStackX_c + lVar12 + 4) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100497;
    func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar12,&uStack_11e8,10);
    if (sStack_1158 == 0) {
      uVar29 = *(ushort *)((longlong)&uStackX_c + lVar12) - 1;
      uVar24 = (ulonglong)(uVar29 >> 3);
      *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
           *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
           ~(byte)(1 << (uVar29 & 7));
    }
    else {
      uVar7 = *(ushort *)((longlong)&uStackX_c + lVar12);
      if (uVar7 <= uStack_1156) {
        pbVar13 = (byte *)((longlong)puStack_1150 +
                          (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar7 - 1) / 2));
        bVar23 = *pbVar13;
        bVar22 = bVar23 >> 4;
        if ((uVar7 & 1) != 0) {
          bVar22 = bVar23 & 0xf;
        }
        if (bVar22 == 0) {
          if ((uVar7 & 1) == 0) {
            bVar23 = bVar23 & 0xf | 0x10;
          }
          else {
            bVar23 = bVar23 & 0xf1 | 1;
          }
          *pbVar13 = bVar23;
        }
      }
    }
    *(undefined4 *)((longlong)&iStackX_8 + lVar12) = 0xffffffed;
    *(undefined2 *)((longlong)&uStackX_c + lVar12) = 0x13;
    puVar14 = (ushort *)((longlong)&uStackX_c + lVar12 + 2);
    *puVar14 = *puVar14 & 0xffe0;
    *(undefined8 *)((longlong)&uStackX_c + lVar12 + 4) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100577;
    func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar12,&uStack_11d8,10);
    if (sStack_1158 == 0) {
      uVar29 = *(ushort *)((longlong)&uStackX_c + lVar12) - 1;
      uVar24 = (ulonglong)(uVar29 >> 3);
      *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
           *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
           ~(byte)(1 << (uVar29 & 7));
    }
    else {
      uVar7 = *(ushort *)((longlong)&uStackX_c + lVar12);
      if (uVar7 <= uStack_1156) {
        pbVar13 = (byte *)((longlong)puStack_1150 +
                          (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar7 - 1) / 2));
        bVar23 = *pbVar13;
        bVar22 = bVar23 >> 4;
        if ((uVar7 & 1) != 0) {
          bVar22 = bVar23 & 0xf;
        }
        if (bVar22 == 0) {
          if ((uVar7 & 1) == 0) {
            bVar23 = bVar23 & 0xf | 0x10;
          }
          else {
            bVar23 = bVar23 & 0xf1 | 1;
          }
          *pbVar13 = bVar23;
        }
      }
    }
    *(undefined4 *)((longlong)&iStackX_8 + lVar12) = 0xffffffef;
    *(undefined2 *)((longlong)&uStackX_c + lVar12) = 0x11;
    puVar14 = (ushort *)((longlong)&uStackX_c + lVar12 + 2);
    *puVar14 = *puVar14 & 0xffe0;
    *(undefined8 *)((longlong)&uStackX_c + lVar12 + 4) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100657;
    func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar12,&uStack_11c8,10);
    if (sStack_1158 == 0) {
      uVar29 = *(ushort *)((longlong)&uStackX_c + lVar12) - 1;
      uVar24 = (ulonglong)(uVar29 >> 3);
      *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
           *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
           ~(byte)(1 << (uVar29 & 7));
    }
    else {
      uVar7 = *(ushort *)((longlong)&uStackX_c + lVar12);
      if (uVar7 <= uStack_1156) {
        pbVar13 = (byte *)((longlong)puStack_1150 +
                          (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar7 - 1) / 2));
        bVar23 = *pbVar13;
        bVar22 = bVar23 >> 4;
        if ((uVar7 & 1) != 0) {
          bVar22 = bVar23 & 0xf;
        }
        if (bVar22 == 0) {
          if ((uVar7 & 1) == 0) {
            bVar23 = bVar23 & 0xf | 0x10;
          }
          else {
            bVar23 = bVar23 & 0xf1 | 1;
          }
          *pbVar13 = bVar23;
        }
      }
    }
    *(undefined4 *)((longlong)&iStackX_8 + lVar12) = 0xffffffe9;
    *(undefined2 *)((longlong)&uStackX_c + lVar12) = 0x17;
    puVar14 = (ushort *)((longlong)&uStackX_c + lVar12 + 2);
    *puVar14 = *puVar14 & 0xffe0;
    *(undefined8 *)((longlong)&uStackX_c + lVar12 + 4) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100737;
    func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar12,&uStack_11b8,10);
    if (sStack_1158 == 0) {
      uVar29 = *(ushort *)((longlong)&uStackX_c + lVar12) - 1;
      uVar24 = (ulonglong)(uVar29 >> 3);
      *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
           *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
           ~(byte)(1 << (uVar29 & 7));
    }
    else {
      uVar7 = *(ushort *)((longlong)&uStackX_c + lVar12);
      if (uVar7 <= uStack_1156) {
        pbVar13 = (byte *)((longlong)puStack_1150 +
                          (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar7 - 1) / 2));
        bVar23 = *pbVar13;
        bVar22 = bVar23 >> 4;
        if ((uVar7 & 1) != 0) {
          bVar22 = bVar23 & 0xf;
        }
        if (bVar22 == 0) {
          if ((uVar7 & 1) == 0) {
            bVar23 = bVar23 & 0xf | 0x10;
          }
          else {
            bVar23 = bVar23 & 0xf1 | 1;
          }
          *pbVar13 = bVar23;
        }
      }
    }
    *(undefined4 *)((longlong)&iStackX_8 + lVar12) = 0xffffffee;
    *(undefined2 *)((longlong)&uStackX_c + lVar12) = 0x12;
    puVar14 = (ushort *)((longlong)&uStackX_c + lVar12 + 2);
    *puVar14 = *puVar14 & 0xffe0;
    *(undefined8 *)((longlong)&uStackX_c + lVar12 + 4) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100815;
    func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar12,param_1 + 0x1a6,0x1c);
    if (sStack_1158 == 0) {
      uVar29 = *(ushort *)((longlong)&uStackX_c + lVar12) - 1;
      uVar24 = (ulonglong)(uVar29 >> 3);
      *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
           *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
           ~(byte)(1 << (uVar29 & 7));
    }
    else {
      uVar7 = *(ushort *)((longlong)&uStackX_c + lVar12);
      if (uVar7 <= uStack_1156) {
        pbVar13 = (byte *)((longlong)puStack_1150 +
                          (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar7 - 1) / 2));
        bVar23 = *pbVar13;
        bVar22 = bVar23 >> 4;
        if ((uVar7 & 1) != 0) {
          bVar22 = bVar23 & 0xf;
        }
        if (bVar22 == 0) {
          if ((uVar7 & 1) == 0) {
            bVar23 = bVar23 & 0xf | 0x10;
          }
          else {
            bVar23 = bVar23 & 0xf1 | 1;
          }
          *pbVar13 = bVar23;
        }
      }
    }
    *(undefined4 *)((longlong)&iStackX_8 + lVar12) = 0xffffffdc;
    *(undefined2 *)((longlong)&uStackX_c + lVar12) = 0x24;
    puVar14 = (ushort *)((longlong)&uStackX_c + lVar12 + 2);
    *puVar14 = *puVar14 & 0xffe0;
    *(undefined8 *)((longlong)&uStackX_c + lVar12 + 4) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1008f5;
    func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar12,&uStack_1168,0x10);
    if (sStack_1158 == 0) {
      uVar29 = *(ushort *)((longlong)&uStackX_c + lVar12) - 1;
      uVar24 = (ulonglong)(uVar29 >> 3);
      *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
           *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
           ~(byte)(1 << (uVar29 & 7));
    }
    else {
      uVar7 = *(ushort *)((longlong)&uStackX_c + lVar12);
      if (uVar7 <= uStack_1156) {
        pbVar13 = (byte *)((longlong)puStack_1150 +
                          (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar7 - 1) / 2));
        bVar23 = *pbVar13;
        bVar22 = bVar23 >> 4;
        if ((uVar7 & 1) != 0) {
          bVar22 = bVar23 & 0xf;
        }
        if (bVar22 == 0) {
          if ((uVar7 & 1) == 0) {
            bVar23 = bVar23 & 0xf | 0x10;
          }
          else {
            bVar23 = bVar23 & 0xf1 | 1;
          }
          *pbVar13 = bVar23;
        }
      }
    }
    *(undefined4 *)((longlong)&iStackX_8 + lVar12) = 0xffffffd4;
    uVar6 = 0x2c;
    uVar31 = 0x1c;
    puVar30 = &uStack_11a8;
  }
  *(undefined8 *)((longlong)&uStackX_c + lVar12 + 4) = 0;
  puVar14 = (ushort *)((longlong)&uStackX_c + lVar12 + 2);
  *puVar14 = *puVar14 & 0xffe0;
  *(undefined2 *)((longlong)&uStackX_c + lVar12) = uVar6;
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100a61;
  func_0x(&sStack_1158,(longlong)&iStackX_8 + lVar12,puVar30,uVar31);
  if (sStack_1158 == 0) {
    uVar29 = *(ushort *)((longlong)&uStackX_c + lVar12) - 1;
    uVar24 = (ulonglong)(uVar29 >> 3);
    *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) =
         *(byte *)((longlong)puStack_1150 + uVar24 + (longlong)(int)(uint)uStack_1148 + 2) &
         ~(byte)(1 << (uVar29 & 7));
  }
  else {
    uVar7 = *(ushort *)((longlong)&uStackX_c + lVar12);
    if (uVar7 <= uStack_1156) {
      pbVar13 = (byte *)((longlong)puStack_1150 +
                        (ulonglong)(ushort)uStack_1140 + (longlong)((int)(uVar7 - 1) / 2));
      bVar23 = *pbVar13;
      bVar22 = bVar23 >> 4;
      if ((uVar7 & 1) != 0) {
        bVar22 = bVar23 & 0xf;
      }
      if (bVar22 == 0) {
        if ((uVar7 & 1) == 0) {
          bVar23 = bVar23 & 0xf | 0x10;
        }
        else {
          bVar23 = bVar23 & 0xf1 | 1;
        }
        *pbVar13 = bVar23;
      }
    }
  }
  if ((*(uint *)(param_1 + 100) >> 8 & 1) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100acd;
    func_0x(param_1,&sStack_1158,0);
LAB_:
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1022ac;
    func_0x((longlong)&plStackX_18 + lVar12);
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1022bb;
    func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar12));
    return;
  }
  *(undefined4 *)((longlong)&iStackX_8 + lVar12) = 0xffffffd2;
  *(undefined2 *)((longlong)&uStackX_c + lVar12) = 0x2e;
  uVar7 = *(ushort *)((longlong)&uStackX_c + lVar12 + 2) & 0xffe0;
  *(ushort *)((longlong)&uStackX_c + lVar12 + 2) = uVar7;
  *(undefined8 *)((longlong)&uStackX_c + lVar12 + 4) = 0;
  uVar29 = 0;
  if (sStack_1158 == 0) {
    if ((*(byte *)puStack_1150 & 0x10) == 0) {
      if ((1 << (*(byte *)puStack_1150 & 0xe) & 0x1105U) != 0) {
        bVar23 = 0xff;
        uVar25 = uVar29;
        goto LAB_;
      }
LAB_:
      puVar28 = puVar19;
      if (uStack_1154 == 0) {
        uStack_1156 = 0;
        uStack_1148 = (longlong *)CONCAT44((uint)uStack_1148,(uint)uStack_1148);
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100bfc;
        pbVar13 = (byte *)func_0x(&uStack_1156);
        if ((*pbVar13 & 0x10) != 0) {
          uVar25 = uVar29;
          if ((*(byte *)puStack_1150 & 0x10) != 0) {
            uVar25 = (uint)*(ushort *)
                            (((ulonglong)uStack_1148 & 0xffffffff) + (longlong)puStack_1150);
          }
          uStack_1148 = (longlong *)
                        CONCAT44((uVar25 + 7 >> 3) + uStack_1148._4_4_ + 2,(uint)uStack_1148);
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100c3f;
        pbVar13 = (byte *)func_0x(&uStack_1156);
        if ((*pbVar13 & 0x20) == 0) {
          uStack_1154 = uStack_1148._4_4_;
          uStack_113c = 0;
          uStack_1140 = uStack_1154;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100c54;
          puVar14 = (ushort *)func_0x(&uStack_1156);
          uStack_113c = *puVar14;
          if (uStack_113c == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100c75;
            cVar5 = func_0x(0x1ab9db0);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100c7e;
              cVar5 = func_0x();
              if (cVar5 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100c8e;
                cVar5 = func_0x(0x1ab9db0);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100caa;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100ccd;
                  (*_DAT_)(1,0x13a97bc,0x14c98a8,0x80f);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100cde;
            func_0x(puStack_1150,3);
          }
          uStack_1140 = uStack_1148._4_4_ + 2 + (uint)uStack_113c * 2;
          if (0x1f9e < uStack_1140) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d17;
            cVar5 = func_0x(0x1ab9db0);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d20;
              cVar5 = func_0x();
              if (cVar5 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d30;
                cVar5 = func_0x(0x1ab9db0);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d4c;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d6f;
                  (*_DAT_)(1,0x13a97bc,0x14c98a8,0x816);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d80;
            func_0x(puStack_1150,4);
          }
          uVar32 = (ulonglong)uStack_1140;
          uVar24 = (ulonglong)uStack_113c;
          puVar14 = puVar14 + 1;
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100da2;
          uVar7 = func_0x(puVar14,uVar24 - 1);
          uStack_1154 = (uint)uVar7;
          if (uStack_1154 < (uint)uVar32) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100dc3;
            cVar5 = func_0x(0x1ab9db0);
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100dcc;
              cVar5 = func_0x();
              if (cVar5 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100ddc;
                cVar5 = func_0x(0x1ab9db0);
                if (cVar5 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100df8;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100e1b;
                  (*_DAT_)(1,0x13a97bc,0x14c98a8,0x81d);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100e2c;
            func_0x(puStack_1150,4);
            uVar24 = (ulonglong)uStack_113c;
            uVar32 = (ulonglong)uStack_1140;
          }
          puVar16 = puVar19;
          if ((short)uVar24 != 0) {
            do {
              uVar25 = (uint)uVar32;
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100e5b;
              uVar7 = func_0x(puVar14,(longlong)(int)puVar16);
              if ((uVar7 < uVar25) || (uStack_1154 <= uVar7 && uVar7 != uStack_1154)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100e7b;
                cVar5 = func_0x(0x1ab9db0);
                if (cVar5 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100e84;
                  cVar5 = func_0x();
                  if (cVar5 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100e94;
                    cVar5 = func_0x(0x1ab9db0);
                    if (cVar5 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100eb0;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100ed6;
                      (*_DAT_)(1,0x13a97bc,0x14c98a8,0x82a);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100ee7;
                func_0x(puStack_1150,4);
                uVar24 = (ulonglong)uStack_113c;
              }
              uVar32 = (ulonglong)(uint)uVar7;
              uVar25 = (int)puVar16 + 1;
              puVar16 = (undefined4 *)(ulonglong)uVar25;
            } while ((int)uVar25 < (int)((uint)uVar24 & 0xffff));
          }
          while( true ) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100f1e;
            iVar9 = func_0x(puVar14,((uint)uVar24 & 0xffff) - 1);
            if (iVar9 == 0) break;
            uVar24 = (ulonglong)uStack_113c;
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100f3a;
            lVar17 = func_0x(&uStack_1156);
            lVar17 = lVar17 + 2;
            uVar25 = uStack_1140;
            uVar10 = uStack_1140;
            if ((int)uVar24 != 1) {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100f5c;
              uVar7 = func_0x(lVar17,uVar24 - 2);
              uVar25 = (uint)uVar7;
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100f6b;
            uVar7 = func_0x(lVar17,uVar24 - 1);
            uVar27 = (uint)uVar24;
            if (((uVar25 < uVar10) || (uVar7 < uVar25)) ||
               (uStack_1154 <= uVar7 && uVar7 != uStack_1154)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100f90;
              func_0x(puStack_1150,7);
              uVar27 = (uint)uStack_113c;
              uVar10 = uStack_1140;
            }
            if ((uVar25 < uVar10) || (uStack_1154 < uVar25)) {
              puVar28 = *(undefined4 **)((longlong)&uStackX_c + lVar12 + 4);
              uVar25 = (uint)uStack_1148;
              goto LAB_;
            }
            if (*(ushort *)((longlong)puStack_1150 + (ulonglong)uVar25) == 5) {
              uStack_1156 = uStack_1156 | 2;
              uStack_113c = (short)uVar27 - 1;
              uStack_112e = (ushort)uVar25;
              pbVar13 = (byte *)((ulonglong)(uVar25 & 0xffff) + (longlong)puStack_1150);
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101079;
              iVar9 = func_0x(pbVar13);
              if (iVar9 == 0) {
                uStack_112c = uStack_112c & 0xc7ff;
              }
              else {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10108b;
                sVar26 = func_0x(pbVar13);
                uStack_112c = uStack_112c ^ (sVar26 << 0xb ^ uStack_112c) & 0x3800;
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1010bd;
              uVar8 = func_0x(pbVar13);
              uVar8 = uStack_112c ^ (uVar8 ^ uStack_112c) & 0x7ff;
              uVar24 = (ulonglong)uStack_112e;
              pbVar13 = (byte *)((longlong)puStack_1150 +
                                (ulonglong)((uVar8 & 0x7ff) * 2) +
                                (uStack_112c >> 0xb & 7) * 2 + uVar24 + 4);
              uStack_112c = uVar8;
              if (pbVar13 < (byte *)((longlong)puStack_1150 + uVar24)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10111e;
                func_0x((byte *)((longlong)puStack_1150 + uVar24),0x19);
                uVar24 = (ulonglong)uStack_112e;
              }
              if (uVar7 - uVar25 <
                  (((uStack_112c & 0x7ff) * 2 - (int)uVar24) - (int)puStack_1150) + (int)pbVar13) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101162;
                func_0x((byte *)(uVar24 + (longlong)puStack_1150),0x19);
                uVar24 = (ulonglong)uStack_112e;
              }
              puVar16 = puStack_1150;
              if (((uStack_112c & 0x3800) != 0) && ((uStack_112c & 0x3800) != 0)) {
                do {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1011ab;
                  uVar7 = func_0x((byte *)((longlong)puVar16 + uVar24 + 4),puVar28);
                  if ((uStack_112c & 0x7ff) < uVar7) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1011d0;
                    func_0x((byte *)((ulonglong)uStack_112e + (longlong)puStack_1150),0x1a);
                  }
                  uVar25 = (int)puVar28 + 1;
                  puVar28 = (undefined4 *)(ulonglong)uVar25;
                } while ((int)uVar25 < (int)((uStack_112c & 0x3800) >> 0xb));
              }
              break;
            }
            if (*(ushort *)((longlong)puStack_1150 + (ulonglong)uVar25) < 0x400) break;
            uStack_1156 = uStack_1156 | 1;
            uStack_113c = (short)uVar27 - 1;
            uVar24 = (ulonglong)uStack_113c;
            if (uStack_113c == 0) break;
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101007;
        iVar9 = func_0x(&uStack_1156);
        if (iVar9 == 0) {
          uStack_1132 = 0;
          uStack_1130 = 0;
        }
        else {
          uStack_1132 = (undefined2)uStack_1154;
          uStack_1130 = (undefined2)(uStack_1154 >> 0x10);
          uStack_1154 = uStack_1154 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101030;
          uVar15 = func_0x(&uStack_1156);
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10103c;
          func_0x(uVar15,auStack_14e0);
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101045;
          iVar9 = func_0x(auStack_14e0);
          uStack_1154 = uStack_1154 + iVar9;
        }
        if ((pbStack_113a != (byte *)0x0) &&
           (pbStack_113a < (byte *)((ulonglong)uStack_1154 + (longlong)puStack_1150))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10124c;
          cVar5 = func_0x(0x1ab9db0);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101255;
            cVar5 = func_0x();
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101265;
              cVar5 = func_0x(0x1ab9db0);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101281;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1012a7;
                (*_DAT_)(1,0x13a97bc,0x14c98a8,0x886);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1012b6;
          func_0x(puStack_1150,0x12);
        }
        if (0x3f3b < uStack_1154 - 1) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1012d1;
          cVar5 = func_0x(0x1ab9db0);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1012da;
            cVar5 = func_0x();
            if (cVar5 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1012ea;
              cVar5 = func_0x(0x1ab9db0);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101306;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10132c;
                (*_DAT_)(1,0x13a97bc,0x14c98a8,0x88b);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10133a;
          func_0x(puStack_1150,5);
        }
        puVar28 = *(undefined4 **)((longlong)&uStackX_c + lVar12 + 4);
      }
      uVar27 = (uint)uStack_113c;
      uVar25 = (uint)uStack_1148;
      uVar10 = uStack_1140;
LAB_:
      sVar26 = -*(short *)((longlong)&iStackX_8 + lVar12);
      if ((*(byte *)((longlong)&uStackX_c + lVar12 + 2) & 0x10) != 0) {
        if ((*(byte *)puStack_1150 & 0x10) == 0) {
          if ((1 << (*(byte *)puStack_1150 & 0xe) & 0x1105U) != 0) {
LAB_:
            puVar16 = puVar28 + 1;
            *(undefined4 *)(&stack0x00000030 + lVar12) = *puVar28;
            goto LAB_;
          }
        }
        else if (((int)uVar25 <= *(int *)((longlong)&iStackX_8 + lVar12)) ||
                (*(ushort *)((longlong)puStack_1150 + (ulonglong)uVar25) <
                 *(ushort *)((longlong)&uStackX_c + lVar12))) goto LAB_;
      }
      if ((uVar27 & 0xffff) < (uint)(int)sVar26) {
        *(undefined4 *)(&stack0x00000030 + lVar12) = 0;
        puVar16 = puStack_1150;
      }
      else {
        uVar25 = uVar10;
        if (sVar26 != 1) {
          uVar10 = *(ushort *)
                    ((longlong)puStack_1150 +
                    (longlong)sVar26 * 2 + (((ulonglong)uStack_1148 >> 0x20) - 2)) & 0x7fff;
          uVar25 = uStack_1140;
        }
        uVar27 = *(ushort *)
                  ((longlong)puStack_1150 + (longlong)sVar26 * 2 + ((ulonglong)uStack_1148 >> 0x20))
                 & 0x7fff;
        if (((uVar10 < uVar25) || (uVar27 < uVar10)) || (uStack_1154 < uVar27)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10141d;
          func_0x(puStack_1150,7);
        }
        *(uint *)(&stack0x00000030 + lVar12) = uVar27 - uVar10;
        puVar16 = (undefined4 *)((ulonglong)uVar10 + (longlong)puStack_1150);
      }
    }
    else {
      if ((int)(uint)uStack_1148 < -0x2d) {
        bVar23 = 0xff;
      }
      else if (*(ushort *)((longlong)puStack_1150 + ((ulonglong)uStack_1148 & 0xffffffff)) < 0x2e) {
        bVar23 = 0xff;
        uVar25 = 0;
      }
      else {
        bVar23 = *(byte *)(((ulonglong)uStack_1148 & 0xffffffff) + 7 + (longlong)puStack_1150) >> 5;
        uVar25 = 1;
      }
LAB_:
      if ((bVar23 & 1) == 0) {
        if ((uVar25 != 0) || ((*(byte *)((longlong)&uStackX_c + lVar12 + 2) & 0x10) == 0))
        goto LAB_;
        *(undefined4 *)(&stack0x00000030 + lVar12) = uRam0000000000000000;
        puVar16 = (undefined4 *)0x4;
      }
      else {
        *(undefined4 *)(&stack0x00000030 + lVar12) = 0;
        puVar16 = puVar19;
      }
    }
  }
  else {
    uStack_1588 = 0;
    *(uint **)(&stack0xffffffffffffffe8 + lVar12) = &uStack_1588;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101471;
    puVar16 = (undefined4 *)
              func_0x(&uStack_1156,(longlong)&iStackX_8 + lVar12,uVar7,
                              &stack0x00000030 + lVar12);
    plVar18 = uStack_1148;
    if ((((sStack_1158 != 0) && (uStack_1148 != (longlong *)0x0)) && (*uStack_1148 != 0)) &&
       (((*(byte *)((longlong)&uStackX_c + lVar12 + 2) & 8) == 0 && ((uStack_1588 & 1) == 0)))) {
      if ((puVar16 == (undefined4 *)0x0) || (puVar16 == (undefined4 *)0x112e450)) {
        *(undefined4 *)(&stack0x00000030 + lVar12) = 0;
        puVar16 = (undefined4 *)0x0;
      }
      else {
        *(uint *)(auStackX_20 + lVar12 + -0x20) = uStack_1588;
        *(undefined **)(&stack0xfffffffffffffff8 + lVar12) = &stack0x00000030 + lVar12;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar12) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1014d7;
        puVar16 = (undefined4 *)
                  func_0x
                            (plVar18,(longlong)&iStackX_8 + lVar12,puVar16,
                             *(undefined4 *)(&stack0x00000030 + lVar12));
      }
    }
  }
LAB_:
  if ((puVar16 != (undefined4 *)0x0) && (*(int *)(&stack0x00000030 + lVar12) == 600)) {
    bVar23 = *(byte *)puVar16;
    uVar6 = *(undefined2 *)(param_1 + 0x20);
    uVar1 = *(undefined2 *)(param_1 + 0x60);
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10150f;
    func_0x(0x13db4d0,uVar1,uVar6,bVar23 & 0x1f);
  }
  uVar6 = *(undefined2 *)(param_1 + 0x20);
  *(undefined4 *)(&stack0x00000034 + lVar12) = 0;
  *(undefined2 *)(&stack0x00000038 + lVar12) = uVar6;
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101526;
  lVar17 = func_0x(param_1);
  puVar16 = puVar19;
  if ((lVar17 != 0) && (*(short *)(param_1 + 0x62) == 0)) {
    puVar16 = *(undefined4 **)(lVar17 + 0x1210);
  }
  uStack_14d4 = 0;
  if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
    lVar17 = *(longlong *)
              ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar17 != 0) && (lVar17 = **(longlong **)(lVar17 + 0x38), lVar17 != 0)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101595;
      iVar9 = (*_DAT_)(lVar17,0x337);
      if (iVar9 != 0) goto LAB_;
    }
    lVar17 = *(longlong *)
              ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
              + 8);
    if (lVar17 != 0) {
      puVar19 = *(undefined4 **)(lVar17 + 0x60);
    }
  }
LAB_:
  lVar17 = *(longlong *)(puVar16 + 0x1ca);
  do {
    uStack_1584 = 0;
    lVar20 = *(longlong *)((longlong)&plStackX_18 + lVar12);
    if (lVar20 != 0) {
      iVar9 = (int)*(short *)((longlong)&uStackX_24 + lVar12);
      if (((*(ushort *)(lVar20 + 0x62) & 0x400) == 0) || (iVar9 < 3)) {
        plVar18 = *(longlong **)((longlong)&plStackX_18 + lVar12);
        if (((byte)*(undefined2 *)(lVar20 + 0x62) >> 3 & 1) != 0) {
          if (iVar9 == 3) {
            iVar9 = 4;
          }
          else if (iVar9 < 2) goto LAB_;
          if ((((*(uint *)(*(longlong *)((longlong)&plStackX_18 + lVar12) + 100) & 8) != 0) &&
              (lVar20 = *(longlong *)(*(longlong *)((longlong)&plStackX_18 + lVar12) + 0x90),
              lVar20 != 0)) && (*(longlong *)(lVar20 + 0x758) != 0)) {
            uVar15 = *(undefined8 *)(lVar20 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101665;
            func_0x(uVar15,*(undefined8 *)((longlong)&plStackX_18 + lVar12),iVar9);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar18 + 100) & 8) != 0)) &&
           ((2 < iVar9 &&
            (((*(uint *)((longlong)plVar18 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar20 = *plVar18, lVar20 != 0)))))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1016a6;
          iVar11 = (*_DAT_)(lVar20,0x2000,2,auStack_14f0);
          if (iVar11 != 0) {
            LOCK();
            *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1016c8;
        func_0x(plVar18 + 0x13,iVar9);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1016e7;
          func_0x(plVar18,0,iVar9);
        }
        *(uint *)((longlong)&uStackX_24 + lVar12) =
             *(uint *)((longlong)&uStackX_24 + lVar12) & 0xffff0000;
        *(undefined8 *)((longlong)&plStackX_18 + lVar12) = 0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101600;
        func_0x((longlong)&plStackX_18 + lVar12);
      }
    }
    if (*(longlong *)(puVar16 + 0x1ca) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101714;
      func_0x((longlong)&plStackX_18 + lVar12,&stack0x00000034 + lVar12,puVar16);
      lVar20 = *(longlong *)((longlong)&plStackX_18 + lVar12);
      if (lVar20 != 0) {
        iVar9 = (int)*(short *)((longlong)&uStackX_24 + lVar12);
        if (((*(ushort *)(lVar20 + 0x62) & 0x400) == 0) || (iVar9 < 3)) {
          plVar18 = *(longlong **)((longlong)&plStackX_18 + lVar12);
          if (((byte)*(undefined2 *)(lVar20 + 0x62) >> 3 & 1) != 0) {
            if (iVar9 == 3) {
              iVar9 = 4;
            }
            else if (iVar9 < 2) goto LAB_;
            if ((((*(uint *)(*(longlong *)((longlong)&plStackX_18 + lVar12) + 100) & 8) != 0) &&
                (lVar20 = *(longlong *)(*(longlong *)((longlong)&plStackX_18 + lVar12) + 0x90),
                lVar20 != 0)) && (*(longlong *)(lVar20 + 0x758) != 0)) {
              uVar15 = *(undefined8 *)(lVar20 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1017a9;
              func_0x(uVar15,*(undefined8 *)((longlong)&plStackX_18 + lVar12),iVar9)
              ;
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar18 + 100) & 8) != 0)) &&
             ((2 < iVar9 &&
              (((*(uint *)((longlong)plVar18 + 100) & 0xc0000000) != 0x40000000 &&
               (lVar20 = *plVar18, lVar20 != 0)))))) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1017ea;
            iVar11 = (*_DAT_)(lVar20,0x2000,2,auStack_14ec);
            if (iVar11 != 0) {
              LOCK();
              *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar18 + 100) = *(uint *)((longlong)plVar18 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10180c;
          func_0x(plVar18 + 0x13,iVar9);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10182b;
            func_0x(plVar18,0,iVar9);
          }
          *(uint *)((longlong)&uStackX_24 + lVar12) =
               *(uint *)((longlong)&uStackX_24 + lVar12) & 0xffff0000;
          *(undefined8 *)((longlong)&plStackX_18 + lVar12) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101744;
          func_0x((longlong)&plStackX_18 + lVar12);
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10184a;
    func_0x(puVar16,&stack0x00000034 + lVar12);
    *(uint **)(&stack0xfffffffffffffff0 + lVar12) = &uStack_14d8;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar12) = 4;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101873;
    plVar18 = (longlong *)
              func_0x(_DAT_,puVar16,&stack0x00000034 + lVar12,&uStack_1584);
    *(longlong **)((longlong)&plStackX_18 + lVar12) = plVar18;
    uVar25 = *(uint *)((longlong)&uStackX_24 + lVar12) & 0xffff0004 | 4;
    *(uint *)((longlong)&uStackX_24 + lVar12) = uVar25;
    if (puVar19 != (undefined4 *)0x0) {
      if (*(longlong *)(puVar19 + (ulonglong)(puVar19[0x140] & 0xf) * 2 + 0x142) != *plVar18) {
        *(longlong *)(puVar19 + (ulonglong)(puVar19[0x140] & 0xf) * 2 + 0x142) = *plVar18;
        *(longlong *)(puVar19 + 0x140) = *(longlong *)(puVar19 + 0x140) + 1;
        uVar25 = *(uint *)((longlong)&uStackX_24 + lVar12);
      }
    }
    uVar25 = (uStack_1584 >> 3 & 1) << 0x18 | uVar25 & 0xffffff;
    *(uint *)((longlong)&uStackX_24 + lVar12) = uVar25;
    *(uint *)(&stack0x00000028 + lVar12) =
         uStack_1584 >> 4 & 1 | *(uint *)(&stack0x00000028 + lVar12) & 0xffffff00;
    if (((lVar17 != 0) && (puVar19 != (undefined4 *)0x0)) &&
       (puVar19 == *(undefined4 **)(puVar16 + 0x70e))) {
      *(longlong *)(lVar17 + 0x5b28) = *(longlong *)(lVar17 + 0x5b28) + 1;
      if ((int)uStack_14d4 != 0) {
        *(longlong *)(lVar17 + 0x5b30) = *(longlong *)(lVar17 + 0x5b30) + 1;
        *(longlong *)(lVar17 + 0x5b38) = *(longlong *)(lVar17 + 0x5b38) + (ulonglong)uStack_14d8;
        if (0xffffff < uVar25) {
          *(longlong *)(lVar17 + 0x5b40) = *(longlong *)(lVar17 + 0x5b40) + 1;
          *(longlong *)(lVar17 + 0x5b48) = *(longlong *)(lVar17 + 0x5b48) + (ulonglong)uStack_14d8;
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101940;
    cVar5 = func_0x(puVar16);
    if (((cVar5 == '\0') || (*(byte *)(puVar16 + 0x814) == 0)) ||
       ((*(int *)(&stack0x00000034 + lVar12) == 0 ||
        ((*(int *)(&stack0x00000034 + lVar12) == 9 && (*(short *)(&stack0x00000038 + lVar12) == 1)))
        ))) goto LAB_;
    lVar20 = **(longlong **)((longlong)&plStackX_18 + lVar12);
    if (*(short *)(lVar20 + 0x24) == 0) {
LAB_:
      uStack_1560 = *(undefined8 *)(lVar20 + 0x28);
      uStack_1558 = *(ushort *)(lVar20 + 0x30);
    }
    else {
      cVar5 = *(char *)(lVar20 + 1);
      if (cVar5 == '\v') {
        if (*(int *)(lVar20 + 0x18) != 99) {
LAB_:
          if (cVar5 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar5 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar20 + 0x18) != 99) goto LAB_;
      }
      uStack_1540 = *(undefined4 *)(lVar20 + 0x20);
      uStack_153c = *(undefined2 *)(lVar20 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1019c2;
      cVar5 = func_0x(&uStack_1540);
      if (cVar5 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1019d2;
      func_0x(lVar20,&uStack_1560);
    }
    uVar25 = puVar16[0x842];
    do {
      uVar10 = uVar25 & 0xfffffffe;
      *(undefined8 *)(&stack0x0000003c + lVar12) = *(undefined8 *)(puVar16 + 0x83f);
      *(undefined4 *)(&stack0x00000044 + lVar12) = puVar16[0x841];
      LOCK();
      *(undefined4 *)(&stack0xffffffffffffffc8 + lVar12) =
           *(undefined4 *)(&stack0xffffffffffffffc8 + lVar12);
      UNLOCK();
      uVar25 = puVar16[0x842];
    } while (uVar10 != uVar25);
    if ((uint)uStack_1560 <= *(uint *)(&stack0x0000003c + lVar12)) {
      if (*(uint *)(&stack0x0000003c + lVar12) != (uint)uStack_1560) goto LAB_;
      uVar25 = (uint)((ulonglong)*(undefined8 *)(&stack0x0000003c + lVar12) >> 0x20);
      if ((uStack_1560._4_4_ <= uVar25) &&
         ((uVar25 != uStack_1560._4_4_ || (uStack_1558 <= *(ushort *)(&stack0x00000044 + lVar12)))))
      goto LAB_;
    }
    if ((*(byte *)(puVar16 + 0x1ab2) == 0) &&
       (*(longlong *)
         (*(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
           ) + 0x60) != *(longlong *)(puVar16 + 0x848))) {
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101a8f;
      cVar5 = func_0x(puVar16);
      if (cVar5 == '\0') {
        uVar25 = puVar16[0x842];
        do {
          uVar10 = uVar25 & 0xfffffffe;
          uStack_1500 = *(undefined8 *)(puVar16 + 0x83f);
          *(undefined8 *)(&stack0x0000003c + lVar12) = uStack_1500;
          *(undefined4 *)(&stack0x00000044 + lVar12) = puVar16[0x841];
          LOCK();
          *(undefined4 *)(&stack0xffffffffffffffc8 + lVar12) =
               *(undefined4 *)(&stack0xffffffffffffffc8 + lVar12);
          UNLOCK();
          uVar25 = puVar16[0x842];
        } while (uVar10 != uVar25);
        uVar7 = *(ushort *)(&stack0x00000044 + lVar12);
        lVar17 = **(longlong **)((longlong)&plStackX_18 + lVar12);
        uStack_14f8 = uVar7;
        if (*(short *)(lVar17 + 0x24) == 0) {
LAB_:
          uStack_1570 = *(undefined8 *)(lVar17 + 0x28);
          uStack_1568 = *(ushort *)(lVar17 + 0x30);
        }
        else {
          cVar5 = *(char *)(lVar17 + 1);
          if (cVar5 == '\v') {
            if (*(int *)(lVar17 + 0x18) != 99) {
LAB_:
              if (cVar5 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar5 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar17 + 0x18) != 99) goto LAB_;
          }
          uStack_1530 = *(undefined4 *)(lVar17 + 0x20);
          uStack_152c = *(undefined2 *)(lVar17 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101d45;
          cVar5 = func_0x(&uStack_1530);
          if (cVar5 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101d55;
          func_0x(lVar17,&uStack_1570);
        }
        if ((*(uint *)(&stack0x0000003c + lVar12) < (uint)uStack_1570) ||
           ((*(uint *)(&stack0x0000003c + lVar12) == (uint)uStack_1570 &&
            ((uVar25 = (uint)((ulonglong)uStack_1570 >> 0x20),
             *(uint *)(&stack0x00000040 + lVar12) < uVar25 ||
             ((*(uint *)(&stack0x00000040 + lVar12) == uVar25 && (uVar7 < uStack_1568)))))))) {
          lVar17 = *(longlong *)(puVar16 + 0x1ac);
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101db9;
          func_0x(&uStack_1570,asStack_a8,auStack_1548);
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101dcd;
          func_0x(&uStack_1500,asStack_d8,auStack_1548);
          if ((_DAT_ & 0x10000) != 0) {
            uStack_14b0 = 0x60000;
            uStack_14a8 = 0;
            ppuStack_14a0 = &puStack_1488;
            puStack_1498 = auStack_1428;
            uStack_1268 = 0;
            uStack_1490 = 0;
            uStack_1260 = 0;
            puStack_1488 = &uStack_1258;
            uStack_1480 = 0x34;
            uStack_147c = 5;
            uStack_1470 = 0x10;
            uStack_146c = 5;
            uStack_1460 = 0x10;
            uStack_145c = 6;
            uStack_144c = 7;
            uStack_143c = 8;
            uStack_1438 = 0;
            uStack_1430 = 0;
            uStack_142c = 9;
            uStack_1258 = (uint)*(ushort *)(puVar16 + 0x1ae);
            uStack_1254 = *(undefined2 *)(&stack0x00000038 + lVar12);
            uStack_1252 = *(undefined4 *)(&stack0x00000034 + lVar12);
            uStack_124e = 0xf;
            uStack_124d = *(undefined *)(**(longlong **)((longlong)&plStackX_18 + lVar12) + 1);
            lStack_1478 = lVar17 + 0x254;
            lStack_1468 = lVar17 + 0x244;
            lVar20 = -1;
            do {
              lVar20 = lVar20 + 1;
            } while (asStack_a8[lVar20] != 0);
            iStack_1450 = (int)lVar20 * 2;
            psStack_1458 = asStack_a8;
            lVar20 = -1;
            do {
              lVar20 = lVar20 + 1;
            } while (asStack_d8[lVar20] != 0);
            iStack_1440 = (int)lVar20 * 2;
            psStack_1448 = asStack_d8;
            uStack_1544 = 0;
            pcVar3 = *(code **)(_DAT_ + 0x10);
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101f85;
            puVar21 = (uint *)(*pcVar3)(lVar17,&uStack_1544);
            ppuVar4 = ppuStack_14a0;
            if (puVar21 != (uint *)0x0) {
              lVar17 = -1;
              do {
                lVar17 = lVar17 + 1;
              } while (*(short *)((longlong)puVar21 + lVar17 * 2) != 0);
              uVar29 = (int)lVar17 * 2;
            }
            ppuStack_14a0[10] = puVar21;
            *(uint *)(ppuVar4 + 0xb) = uVar29;
            *(undefined4 *)((longlong)ppuVar4 + 0x5c) = 9;
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101fbc;
            func_0x(auStack_14b8);
          }
        }
LAB_:
        if ((1 < *(short *)((longlong)&uStackX_24 + lVar12)) &&
           (*(char *)(**(longlong **)((longlong)&plStackX_18 + lVar12) + 1) != '\x0f')) {
          if (puVar19 != (undefined4 *)0x0) {
            *(longlong *)(puVar19 + 0x162) = **(longlong **)((longlong)&plStackX_18 + lVar12);
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101fec;
          lVar17 = func_0x();
          if (lVar17 != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101ff6;
            lVar17 = func_0x();
            if (*(longlong *)(lVar17 + 0x30) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x102002;
              lVar17 = func_0x();
              uVar29 = *(uint *)(*(longlong *)(lVar17 + 0x30) + 0xc);
              if ((uVar29 < 0xe) && ((0x2640U >> (uVar29 & 0x1f) & 1) != 0)) goto LAB_;
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x102021;
          func_0x(0,8);
        }
LAB_:
        auStack_918[0] = 0xffff;
        uStack_910 = 0;
        uStack_914 = 0;
        uStack_8fa = 0;
        uStack_8f0 = 0;
        uStack_908 = 0;
        uVar15 = **(undefined8 **)((longlong)&plStackX_18 + lVar12);
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10205f;
        func_0x(auStack_918,uVar15);
        uStack_1218 = 0;
        uStack_1210 = 0;
        uStack_1580 = 10;
        uStack_1518 = 0;
        uStack_157c = 8;
        uStack_1208 = 0;
        uStack_1200 = 0;
        auStack_1578[0] = 10;
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1020ae;
        iVar9 = func_0x(auStack_918,0x32,&uStack_1218,&uStack_1580);
        if (iVar9 != 0) {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0x1562638;
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1020df;
          (*_DAT_)(1,0x1562568,0x152eb28,0xb45);
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x102102;
        func_0x(&sStack_1158,0x32,&uStack_1218,uStack_1580);
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10211b;
        iVar9 = func_0x(auStack_918,0x36,&uStack_1518,&uStack_157c);
        if (iVar9 != 0) {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0x1562580;
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x102147;
          (*_DAT_)(1,0x1562568,0x152eb28,0xb4b);
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x102160;
        func_0x(&sStack_1158,0x36,&uStack_1518,uStack_157c);
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10217c;
        iVar9 = func_0x(auStack_918,0x37,&uStack_1208,auStack_1578);
        if (iVar9 != 0) {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0x15625c0;
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1021a8;
          (*_DAT_)(1,0x1562568,0x152eb28,0xb53);
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1021c4;
        func_0x(&sStack_1158,0x37,&uStack_1208,auStack_1578[0]);
        uStack_11f8 = 0;
        uStack_11f0 = 0;
        *(undefined8 *)(&stack0xfffffffffffffff0 + lVar12) = 0;
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1021f8;
        func_0x((longlong)&plStackX_18 + lVar12,&sStack_1158,0,&uStack_11f8);
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x102202;
        func_0x((longlong)&plStackX_18 + lVar12);
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x102219;
        func_0x(&uStack_1218,auStack_78,auStack_14e4);
        uVar6 = *(undefined2 *)(param_1 + 0x20);
        uVar1 = *(undefined2 *)(param_1 + 0x60);
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x102236;
        func_0x(0x13db430,uVar1,uVar6,auStack_78);
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x102242;
        func_0x(*(undefined8 *)((longlong)&plStackX_18 + lVar12),0);
        lVar17 = *(longlong *)((longlong)&plStackX_18 + lVar12);
        lVar20 = *(longlong *)(lVar17 + 0x90);
        if (lVar20 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10225b;
          func_0x(lVar17);
          lVar20 = *(longlong *)(lVar17 + 0x90);
        }
        uVar6 = *(undefined2 *)(lVar17 + 0x74);
        uVar15 = *(undefined8 *)(lVar20 + 0x6a0);
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x102276;
        lVar17 = func_0x(uVar15,uVar6,0);
        if ((((_DAT_ != 0) || ((_DAT_ & 0x40) != 0)) && ((_DAT_ & 8) == 0))
           && (*(short *)(lVar17 + 0x60) != 2)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1022a1;
          func_0x(lVar17,1);
        }
        goto LAB_;
      }
    }
    if (*(longlong *)
         (*(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
           ) + 0x60) == *(longlong *)(puVar16 + 0x848)) goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101ad3;
    cVar5 = func_0x(puVar16);
    if (cVar5 != '\0') goto LAB_;
    if (puVar19 == (undefined4 *)0x0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101ae5;
      puVar19 = (undefined4 *)func_0x();
    }
    plVar18 = *(longlong **)((longlong)&plStackX_18 + lVar12);
    lVar20 = *plVar18;
    if (*(short *)(lVar20 + 0x24) == 0) {
LAB_:
      uStack_1528 = *(undefined8 *)(lVar20 + 0x28);
      uStack_1520 = *(undefined2 *)(lVar20 + 0x30);
    }
    else {
      cVar5 = *(char *)(lVar20 + 1);
      if (cVar5 == '\v') {
        if (*(int *)(lVar20 + 0x18) != 99) {
LAB_:
          if (cVar5 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar5 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar20 + 0x18) != 99) goto LAB_;
      }
      uStack_1538 = *(undefined4 *)(lVar20 + 0x20);
      uStack_1534 = *(undefined2 *)(lVar20 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b35;
      cVar5 = func_0x(&uStack_1538);
      if (cVar5 == '\0') {
        plVar18 = *(longlong **)((longlong)&plStackX_18 + lVar12);
        goto LAB_;
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b45;
      func_0x(lVar20,&uStack_1528);
      plVar18 = *(longlong **)((longlong)&plStackX_18 + lVar12);
    }
    if (plVar18 != (longlong *)0x0) {
      iVar9 = (int)*(short *)((longlong)&uStackX_24 + lVar12);
      if (((*(ushort *)((longlong)plVar18 + 0x62) & 0x400) == 0) || (iVar9 < 3)) {
        plVar2 = *(longlong **)((longlong)&plStackX_18 + lVar12);
        if (((byte)*(undefined2 *)((longlong)plVar18 + 0x62) >> 3 & 1) != 0) {
          if (iVar9 == 3) {
            iVar9 = 4;
          }
          else if (iVar9 < 2) goto LAB_;
          if ((((*(uint *)(*(longlong *)((longlong)&plStackX_18 + lVar12) + 100) & 8) != 0) &&
              (lVar20 = *(longlong *)(*(longlong *)((longlong)&plStackX_18 + lVar12) + 0x90),
              lVar20 != 0)) && (*(longlong *)(lVar20 + 0x758) != 0)) {
            uVar15 = *(undefined8 *)(lVar20 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101bf0;
            func_0x(uVar15,*(undefined8 *)((longlong)&plStackX_18 + lVar12),iVar9);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar2 + 100) & 8) != 0)) &&
            (2 < iVar9)) &&
           (((*(uint *)((longlong)plVar2 + 100) & 0xc0000000) != 0x40000000 &&
            (lVar20 = *plVar2, lVar20 != 0)))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101c31;
          iVar11 = (*_DAT_)(lVar20,0x2000,2,auStack_14e8);
          if (iVar11 != 0) {
            LOCK();
            *(uint *)((longlong)plVar2 + 100) = *(uint *)((longlong)plVar2 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar2 + 100) = *(uint *)((longlong)plVar2 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101c53;
        func_0x(plVar2 + 0x13,iVar9);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101c72;
          func_0x(plVar2,0,iVar9);
        }
        *(uint *)((longlong)&uStackX_24 + lVar12) =
             *(uint *)((longlong)&uStackX_24 + lVar12) & 0xffff0000;
        *(undefined8 *)((longlong)&plStackX_18 + lVar12) = 0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b8b;
        func_0x((longlong)&plStackX_18 + lVar12);
      }
    }
    uStack_1510 = uStack_1528;
    uStack_1508 = uStack_1520;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
    uVar15 = *(undefined8 *)(puVar16 + 0x1ca);
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101caf;
    func_0x(uVar15,&uStack_1510,4);
  } while( true );
}

