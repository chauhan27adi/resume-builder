
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int *param_2,int *param_3,int param_4,longlong param_5,
                 longlong param_6,undefined8 *param_7,undefined8 *param_8)

{
  undefined8 uVar1;
  undefined2 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  ulonglong uVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong lVar11;
  ulonglong uVar12;
  undefined8 *puVar13;
  longlong lVar14;
  undefined8 *puVar15;
  longlong lVar16;
  int iVar17;
  undefined auStack_278 [32];
  undefined8 uStack_258;
  longlong lStack_250;
  int iStack_248;
  int iStack_244;
  int iStack_240;
  int iStack_23c;
  undefined8 *puStack_238;
  longlong lStack_230;
  longlong lStack_228;
  int *piStack_220;
  int *piStack_218;
  undefined8 *puStack_210;
  longlong lStack_208;
  undefined8 uStack_200;
  undefined8 uStack_1f8;
  undefined2 uStack_1f0;
  longlong lStack_1e8;
  undefined2 uStack_1e0;
  undefined8 uStack_1d8;
  int iStack_1d0;
  undefined auStack_1c8 [16];
  undefined auStack_1b8 [16];
  undefined auStack_1a8 [16];
  undefined auStack_198 [16];
  longlong lStack_188;
  uint uStack_180;
  undefined8 uStack_178;
  undefined8 uStack_170;
  undefined auStack_168 [272];
  ulonglong uStack_58;
  
  uStack_200 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)auStack_278;
  lStack_230 = param_5;
  lStack_228 = param_6;
  puStack_210 = param_7;
  puStack_238 = param_8;
  uVar8 = 0;
  *param_2 = 0;
  *param_3 = 0;
  *param_7 = 0;
  *(undefined2 *)(param_7 + 1) = 0;
  *param_8 = 0;
  *(undefined2 *)(param_8 + 1) = 0;
  iStack_244 = param_4;
  piStack_220 = param_2;
  piStack_218 = param_3;
  lStack_208 = param_1;
  iVar4 = func_0x(*(undefined2 *)(param_1 + 8),0x1a8f970);
  if (iVar4 == 0) {
    func_0x(0x4977,0x10,1,0x1a8f970);
  }
  else {
    uStack_1d8 = *(undefined8 *)(param_1 + 0x10);
    uStack_1e0 = *(undefined2 *)(param_1 + 8);
    lStack_1e8 = 0;
    auStack_1c8 = ZEXT816(0);
    auStack_1b8 = ZEXT816(0);
    auStack_1a8 = ZEXT816(0);
    auStack_198 = ZEXT816(0);
    lStack_188 = 0;
    uStack_180 = 0;
    uStack_178 = 0;
    uStack_170 = 0;
    iStack_23c = 0;
    iStack_240 = 0;
    iStack_1d0 = iVar4;
    iVar4 = func_0x(&lStack_1e8,3,1);
    if (iVar4 == 0) {
      func_0x(0x49aa,0x10,7,0x1a8f970);
    }
    else {
      lStack_250 = lStack_1e8;
      uStack_258 = uStack_178;
      iVar5 = (**(code **)(*(longlong *)auStack_1c8._8_8_ + 0x18))(auStack_1c8._8_8_,0,1);
      iVar4 = iStack_248;
      iVar17 = iStack_248;
      lVar16 = lStack_1e8;
      lVar14 = lStack_188;
      uVar6 = uStack_180;
      while (lStack_1e8 = lVar16, lStack_188 = lVar14, uStack_180 = uVar6, iVar5 == 0) {
        lVar10 = 0;
        if (DAT_ == '\0') {
LAB_:
          lVar10 = 0;
          iStack_248 = 0;
          if (((lVar16 != 0) && (lVar14 != 0)) && (uVar6 != 0)) {
            uVar6 = func_0x(&lStack_1e8,0x1901678,&iStack_248);
            if (((lStack_188 != 0) && (uVar6 - 1 < 0xfffffffe)) && (uVar7 = 0, uStack_180 != 0)) {
              do {
                if (*(ulonglong *)((ulonglong)uVar7 * 0x58 + lStack_188) == (ulonglong)uVar6) {
                  lVar10 = (ulonglong)uVar7 * 0x58 + lStack_188;
                  if (lVar10 != 0) goto LAB_;
                  break;
                }
                uVar7 = uVar7 + 1;
                lVar10 = 0;
              } while (uVar7 < uStack_180);
            }
            uStack_258 = CONCAT44(uStack_258._4_4_,iStack_1d0);
            (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
            uVar8 = *(ulonglong *)(*(longlong *)(lVar10 + 0x10) + lStack_1e8);
            lVar10 = *(longlong *)(lVar10 + 8) + lStack_1e8;
            lVar14 = lStack_188;
            lVar16 = lStack_1e8;
            uVar6 = uStack_180;
          }
          lVar11 = 0;
          if (uVar8 < 5) {
            func_0x(&iStack_23c,lVar10,uVar8);
          }
          if (iStack_23c == *(int *)(lStack_208 + 0x18)) {
            iStack_248 = 0;
            if (((lVar16 != 0) && (lVar14 != 0)) && (uVar6 != 0)) {
              uVar6 = func_0x(&lStack_1e8,0x182e888,&iStack_248);
              if (((lStack_188 != 0) && (uVar6 - 1 < 0xfffffffe)) && (uVar7 = 0, uStack_180 != 0)) {
                do {
                  if (*(ulonglong *)((ulonglong)uVar7 * 0x58 + lStack_188) == (ulonglong)uVar6) {
                    lVar11 = (ulonglong)uVar7 * 0x58 + lStack_188;
                    if (lVar11 != 0) goto LAB_;
                    break;
                  }
                  uVar7 = uVar7 + 1;
                } while (uVar7 < uStack_180);
              }
              uStack_258 = CONCAT44(uStack_258._4_4_,iStack_1d0);
              (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
              uVar8 = *(ulonglong *)(*(longlong *)(lVar11 + 0x10) + lStack_1e8);
              lVar11 = *(longlong *)(lVar11 + 8) + lStack_1e8;
              lVar14 = lStack_188;
              lVar16 = lStack_1e8;
              uVar6 = uStack_180;
            }
            if (*piStack_220 == 0) {
              if (uVar8 < 5) {
                func_0x(piStack_220,lVar11,uVar8);
              }
              uVar12 = 0;
              iStack_248 = 0;
              if (((lVar16 != 0) && (lVar14 != 0)) && (uVar6 != 0)) {
                uVar6 = func_0x(&lStack_1e8,0x1a8f930,&iStack_248);
                lVar16 = 0;
                if (((lStack_188 != 0) && (uVar6 - 1 < 0xfffffffe)) && (uStack_180 != 0)) {
                  do {
                    if (*(ulonglong *)(uVar12 * 0x58 + lStack_188) == (ulonglong)uVar6) {
                      lVar16 = uVar12 * 0x58 + lStack_188;
                      if (lVar16 != 0) goto LAB_;
                      break;
                    }
                    uVar7 = (int)uVar12 + 1;
                    uVar12 = (ulonglong)uVar7;
                  } while (uVar7 < uStack_180);
                }
                uStack_258 = CONCAT44(uStack_258._4_4_,iStack_1d0);
                (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
                uVar8 = *(ulonglong *)(*(longlong *)(lVar16 + 0x10) + lStack_1e8);
                uVar12 = *(longlong *)(lVar16 + 8) + lStack_1e8;
                lVar14 = lStack_188;
                lVar16 = lStack_1e8;
                uVar6 = uStack_180;
              }
              lVar10 = lStack_230;
              iVar4 = (int)uVar8;
              if (iStack_244 + -2 < (int)uVar8) {
                iVar4 = iStack_244 + -2;
              }
              func_0x(lStack_230,uVar12,(longlong)iVar4);
              iVar5 = iVar4;
              if (iVar4 < 0) {
                iVar5 = iVar4 + 1;
              }
              *(undefined2 *)(lVar10 + (longlong)(iVar5 >> 1) * 2) = 0;
              puVar9 = (undefined8 *)0x0;
              iStack_248 = 0;
              if (((lVar16 != 0) && (lVar14 != 0)) && (uVar6 != 0)) {
                uVar6 = func_0x(&lStack_1e8,0x19003a0,&iStack_248);
                puVar13 = (undefined8 *)0x0;
                puVar15 = puVar9;
                if (((lStack_188 != 0) && (puVar15 = puVar13, uVar6 - 1 < 0xfffffffe)) &&
                   (uStack_180 != 0)) {
                  do {
                    if (*(ulonglong *)((longlong)puVar9 * 0x58 + lStack_188) == (ulonglong)uVar6) {
                      puVar15 = (undefined8 *)((longlong)puVar9 * 0x58 + lStack_188);
                      if (puVar15 != (undefined8 *)0x0) goto LAB_;
                      break;
                    }
                    uVar7 = (int)puVar9 + 1;
                    puVar9 = (undefined8 *)(ulonglong)uVar7;
                  } while (uVar7 < uStack_180);
                }
                uStack_258 = CONCAT44(uStack_258._4_4_,iStack_1d0);
                (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
                uVar8 = *(ulonglong *)(puVar15[2] + lStack_1e8);
                puVar9 = (undefined8 *)(puVar15[1] + lStack_1e8);
                lVar16 = lStack_1e8;
              }
              if (uVar8 == 10) {
                uVar1 = *puVar9;
                uVar2 = *(undefined2 *)(puVar9 + 1);
                uStack_1f8._0_1_ = (undefined)uVar1;
                uStack_1f8._1_1_ = (undefined)((ulonglong)uVar1 >> 8);
                uStack_1f8._2_1_ = (undefined)((ulonglong)uVar1 >> 0x10);
                uStack_1f8._3_1_ = (undefined)((ulonglong)uVar1 >> 0x18);
                uStack_1f8._4_1_ = (undefined)((ulonglong)uVar1 >> 0x20);
                uStack_1f8._5_1_ = (undefined)((ulonglong)uVar1 >> 0x28);
                uStack_1f8._6_1_ = (undefined)((ulonglong)uVar1 >> 0x30);
                uStack_1f8._7_1_ = (undefined)((ulonglong)uVar1 >> 0x38);
                uStack_1f0._0_1_ = (undefined)uVar2;
                uStack_1f0._1_1_ = (undefined)((ushort)uVar2 >> 8);
                *(uint *)puStack_210 =
                     CONCAT31(CONCAT21(CONCAT11((undefined)uStack_1f8,uStack_1f8._1_1_),
                                       uStack_1f8._2_1_),uStack_1f8._3_1_);
                *(uint *)((longlong)puStack_210 + 4) =
                     CONCAT31(CONCAT21(CONCAT11(uStack_1f8._4_1_,uStack_1f8._5_1_),uStack_1f8._6_1_)
                              ,uStack_1f8._7_1_);
                *(ushort *)(puStack_210 + 1) = CONCAT11((undefined)uStack_1f0,uStack_1f0._1_1_);
                uStack_1f8 = uVar1;
                uStack_1f0 = uVar2;
              }
            }
            else {
              iVar5 = *piStack_218;
              param_8 = puStack_238;
              param_2 = piStack_220;
              if (iVar5 != 0) goto LAB_;
              if (uVar8 < 5) {
                func_0x(piStack_218,lVar11,uVar8);
              }
              uVar12 = 0;
              iStack_248 = 0;
              if (((lVar16 != 0) && (lVar14 != 0)) && (uVar6 != 0)) {
                uVar6 = func_0x(&lStack_1e8,0x1a8f930,&iStack_248);
                lVar16 = 0;
                if (((lStack_188 != 0) && (uVar6 - 1 < 0xfffffffe)) && (uStack_180 != 0)) {
                  do {
                    if (*(ulonglong *)(uVar12 * 0x58 + lStack_188) == (ulonglong)uVar6) {
                      lVar16 = uVar12 * 0x58 + lStack_188;
                      if (lVar16 != 0) goto LAB_;
                      break;
                    }
                    uVar7 = (int)uVar12 + 1;
                    uVar12 = (ulonglong)uVar7;
                  } while (uVar7 < uStack_180);
                }
                uStack_258 = CONCAT44(uStack_258._4_4_,iStack_1d0);
                (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
                uVar8 = *(ulonglong *)(*(longlong *)(lVar16 + 0x10) + lStack_1e8);
                uVar12 = *(longlong *)(lVar16 + 8) + lStack_1e8;
                lVar14 = lStack_188;
                lVar16 = lStack_1e8;
                uVar6 = uStack_180;
              }
              lVar10 = lStack_228;
              iVar17 = (int)uVar8;
              if (iStack_244 + -2 < (int)uVar8) {
                iVar17 = iStack_244 + -2;
              }
              func_0x(lStack_228,uVar12,(longlong)iVar17);
              iVar5 = iVar17;
              if (iVar17 < 0) {
                iVar5 = iVar17 + 1;
              }
              *(undefined2 *)(lVar10 + (longlong)(iVar5 >> 1) * 2) = 0;
              puVar9 = (undefined8 *)0x0;
              iStack_248 = 0;
              if (((lVar16 != 0) && (lVar14 != 0)) && (uVar6 != 0)) {
                uVar6 = func_0x(&lStack_1e8,0x19003a0,&iStack_248);
                puVar13 = (undefined8 *)0x0;
                puVar15 = puVar9;
                if (((lStack_188 != 0) && (puVar15 = puVar13, uVar6 - 1 < 0xfffffffe)) &&
                   (uStack_180 != 0)) {
                  do {
                    if (*(ulonglong *)((longlong)puVar9 * 0x58 + lStack_188) == (ulonglong)uVar6) {
                      puVar15 = (undefined8 *)((longlong)puVar9 * 0x58 + lStack_188);
                      if (puVar15 != (undefined8 *)0x0) goto LAB_;
                      break;
                    }
                    uVar7 = (int)puVar9 + 1;
                    puVar9 = (undefined8 *)(ulonglong)uVar7;
                  } while (uVar7 < uStack_180);
                }
                uStack_258 = CONCAT44(uStack_258._4_4_,iStack_1d0);
                (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
                uVar8 = *(ulonglong *)(puVar15[2] + lStack_1e8);
                puVar9 = (undefined8 *)(puVar15[1] + lStack_1e8);
                lVar16 = lStack_1e8;
              }
              if (uVar8 == 10) {
                uVar1 = *puVar9;
                uVar2 = *(undefined2 *)(puVar9 + 1);
                uStack_1f8._0_1_ = (undefined)uVar1;
                uStack_1f8._1_1_ = (undefined)((ulonglong)uVar1 >> 8);
                uStack_1f8._2_1_ = (undefined)((ulonglong)uVar1 >> 0x10);
                uStack_1f8._3_1_ = (undefined)((ulonglong)uVar1 >> 0x18);
                uStack_1f8._4_1_ = (undefined)((ulonglong)uVar1 >> 0x20);
                uStack_1f8._5_1_ = (undefined)((ulonglong)uVar1 >> 0x28);
                uStack_1f8._6_1_ = (undefined)((ulonglong)uVar1 >> 0x30);
                uStack_1f8._7_1_ = (undefined)((ulonglong)uVar1 >> 0x38);
                uStack_1f0._0_1_ = (undefined)uVar2;
                uStack_1f0._1_1_ = (undefined)((ushort)uVar2 >> 8);
                *(uint *)puStack_238 =
                     CONCAT31(CONCAT21(CONCAT11((undefined)uStack_1f8,uStack_1f8._1_1_),
                                       uStack_1f8._2_1_),uStack_1f8._3_1_);
                *(uint *)((longlong)puStack_238 + 4) =
                     CONCAT31(CONCAT21(CONCAT11(uStack_1f8._4_1_,uStack_1f8._5_1_),uStack_1f8._6_1_)
                              ,uStack_1f8._7_1_);
                *(ushort *)(puStack_238 + 1) = CONCAT11((undefined)uStack_1f0,uStack_1f0._1_1_);
                uStack_1f8 = uVar1;
                uStack_1f0 = uVar2;
              }
            }
          }
        }
        else {
          iStack_248 = 0;
          if (lVar16 != 0) {
            if ((lVar14 == 0) || (uVar6 == 0)) {
              lVar10 = 0;
            }
            else {
              uVar6 = func_0x(&lStack_1e8,0x1a8f998,&iStack_248);
              lVar16 = 0;
              if (((lStack_188 != 0) && (uVar6 - 1 < 0xfffffffe)) &&
                 (uVar8 = 0, lVar16 = 0, uStack_180 != 0)) {
                do {
                  if (*(ulonglong *)(uVar8 * 0x58 + lStack_188) == (ulonglong)uVar6) {
                    lVar16 = uVar8 * 0x58 + lStack_188;
                    if (lVar16 != 0) goto LAB_;
                    break;
                  }
                  uVar7 = (int)uVar8 + 1;
                  uVar8 = (ulonglong)uVar7;
                } while (uVar7 < uStack_180);
              }
              uStack_258 = CONCAT44(uStack_258._4_4_,iStack_1d0);
              (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
              uVar8 = *(ulonglong *)(*(longlong *)(lVar16 + 0x10) + lStack_1e8);
              lVar10 = *(longlong *)(lVar16 + 8) + lStack_1e8;
            }
          }
          uVar6 = uStack_180;
          lVar14 = lStack_188;
          lVar16 = lStack_1e8;
          if (uVar8 < 5) {
            func_0x(&iStack_240,lVar10,uVar8);
          }
          if (iStack_240 != 0) goto LAB_;
        }
        uStack_258 = uStack_178;
        lStack_250 = lVar16;
        iVar5 = (**(code **)(*(longlong *)auStack_1c8._8_8_ + 0x18))(auStack_1c8._8_8_,0,1);
        param_2 = piStack_220;
        lVar16 = lStack_1e8;
        lVar14 = lStack_188;
        uVar6 = uStack_180;
        param_8 = puStack_238;
      }
      iVar5 = *piStack_218;
      if (iVar5 != 0) {
LAB_:
        lVar16 = lStack_230;
        iVar3 = *param_2;
        if (iVar5 < iVar3) {
          *param_2 = iVar5;
          *piStack_218 = iVar3;
          iVar4 = iVar4 + 2;
          if (iVar4 < 0x82) {
            func_0x(auStack_168,lStack_230,(longlong)iVar4);
          }
          lVar14 = lStack_228;
          iVar5 = iStack_244;
          if (iVar17 + 2 <= iStack_244) {
            func_0x(lVar16,lStack_228,(longlong)(iVar17 + 2));
          }
          if (iVar4 <= iVar5) {
            func_0x(lVar14,auStack_168,(longlong)iVar4);
          }
          uStack_1f8 = *puStack_210;
          uVar2 = *(undefined2 *)(puStack_210 + 1);
          *puStack_210 = *param_8;
          *(undefined4 *)(puStack_210 + 1) = *(undefined4 *)(param_8 + 1);
          *(undefined4 *)param_8 = (undefined4)uStack_1f8;
          *(int *)((longlong)param_8 + 4) = (int)((ulonglong)uStack_1f8 >> 0x20);
          *(undefined2 *)(param_8 + 1) = uVar2;
        }
      }
    }
    func_0x(&lStack_1e8);
  }
  func_0x(uStack_58 ^ (ulonglong)auStack_278);
  return;
}

