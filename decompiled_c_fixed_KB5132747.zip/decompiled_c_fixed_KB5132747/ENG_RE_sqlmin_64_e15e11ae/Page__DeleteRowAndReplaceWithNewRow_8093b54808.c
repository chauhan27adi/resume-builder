
void FUN_(longlong param_1,int param_2)

{
  code *UNRECOVERED_JUMPTABLE;
  byte *pbVar1;
  
  pbVar1 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - (longlong)param_2) * 2) + param_1);
  if ((*pbVar1 & 1) != 0) {
    UNRECOVERED_JUMPTABLE =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x101484) * 4 +
                           0x101474) - 0x1459c90);
                    /* WARNING: Could not emulate address calculation at 0x001000c9 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
    return;
  }
                    /* WARNING: Could not emulate address calculation at 0x00100268 */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x1014a4) - 0x1459c90))();
  return;
}

