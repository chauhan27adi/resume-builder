
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2)

{
  ushort *puVar1;
  char cVar2;
  ushort uVar3;
  ushort uVar4;
  int iVar5;
  longlong lVar6;
  undefined8 *puVar7;
  uint uVar8;
  uint uVar9;
  undefined4 uVar10;
  ulonglong uVar11;
  uint uVar12;
  uint uVar13;
  ulonglong uVar14;
  byte bVar15;
  byte *pbVar16;
  ulonglong uVar17;
  int iVar18;
  ushort *puVar19;
  undefined8 uStackX_10;
  
  if (param_2 == (short *)0x0) {
    *(undefined *)(param_1 + 0x6e) = 0;
    *(undefined2 *)(param_1 + 0x50) = 0x70;
    *(undefined4 *)(param_1 + 0x68) = 0;
    return;
  }
  *(undefined *)(param_1 + 0x6e) = 1;
  uVar8 = *(uint *)(param_2 + 2);
  if (*param_2 == 0) {
    if (uVar8 == 0) {
      pbVar16 = *(byte **)(param_2 + 4);
      iVar5 = 0;
      param_2[1] = 0;
      uVar8 = *(uint *)(param_2 + 8);
      uVar11 = (ulonglong)uVar8;
      *(uint *)(param_2 + 10) = uVar8;
      bVar15 = *pbVar16;
      if ((bVar15 & 0x10) != 0) {
        uVar8 = uVar8 + 2 + (*(ushort *)(pbVar16 + uVar11) + 7 >> 3);
        uVar11 = (ulonglong)uVar8;
        *(uint *)(param_2 + 10) = uVar8;
        bVar15 = *pbVar16;
      }
      if ((bVar15 & 0x20) == 0) {
        *(int *)(param_2 + 2) = (int)uVar11;
        param_2[0xe] = 0;
        *(int *)(param_2 + 0xc) = (int)uVar11;
      }
      else {
        puVar19 = (ushort *)(pbVar16 + uVar11);
        uVar3 = *puVar19;
        param_2[0xe] = uVar3;
        if (uVar3 == 0) {
          cVar2 = func_0x(0x14d7f50);
          if (((cVar2 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
             (*(char *)(lVar6 + 0x499) != '\0')) {
            cVar2 = func_0x(0x14d7f50);
            if (cVar2 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0xdc795c,0xee7a48,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),3);
          uVar11 = (ulonglong)*(uint *)(param_2 + 10);
          uVar3 = param_2[0xe];
        }
        uVar8 = (int)uVar11 + (uVar3 + 1) * 2;
        *(uint *)(param_2 + 0xc) = uVar8;
        if (0x1f9e < uVar8) {
          cVar2 = func_0x(0x14d7f50);
          if (((cVar2 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
             (*(char *)(lVar6 + 0x499) != '\0')) {
            cVar2 = func_0x(0x14d7f50);
            if (cVar2 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xdc795c,0xee7a48,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar3 = param_2[0xe];
          uVar8 = *(uint *)(param_2 + 0xc);
        }
        uVar11 = (ulonglong)uVar3;
        uVar3 = puVar19[uVar11];
        *(uint *)(param_2 + 2) = uVar3 & 0x7fff;
        if ((uVar3 & 0x7fff) < uVar8) {
          cVar2 = func_0x(0x14d7f50);
          if (((cVar2 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
             (*(char *)(lVar6 + 0x499) != '\0')) {
            cVar2 = func_0x(0x14d7f50);
            if (cVar2 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xdc795c,0xee7a48,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar8 = *(uint *)(param_2 + 0xc);
          uVar11 = (ulonglong)(ushort)param_2[0xe];
        }
        puVar1 = puVar19;
        iVar18 = iVar5;
        if ((short)uVar11 != 0) {
          do {
            uVar12 = puVar1[1] & 0x7fff;
            if ((uVar12 < uVar8) || (*(uint *)(param_2 + 2) < uVar12)) {
              cVar2 = func_0x(0x14d7f50);
              if ((cVar2 != '\0') &&
                 ((lVar6 = func_0x(), lVar6 != 0 &&
                  (*(char *)(lVar6 + 0x499) != '\0')))) {
                cVar2 = func_0x(0x14d7f50);
                if (cVar2 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0xdc795c,0xee7a48,0x82a,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
            }
            uVar11 = (ulonglong)(ushort)param_2[0xe];
            iVar18 = iVar18 + 1;
            puVar1 = puVar1 + 1;
            uVar8 = uVar12;
          } while (iVar18 < (int)(uint)(ushort)param_2[0xe]);
        }
        if ((short)puVar19[(ulonglong)((int)uVar11 - 1) + 1] < 0) {
          pbVar16 = *(byte **)(param_2 + 4);
          do {
            uVar12 = *(ushort *)(pbVar16 + uVar11 * 2 + (ulonglong)*(uint *)(param_2 + 10)) & 0x7fff
            ;
            if ((int)uVar11 == 1) {
              uVar13 = *(uint *)(param_2 + 0xc);
              uVar9 = uVar13;
LAB_:
              if ((uVar12 < uVar13) || (uVar8 = *(uint *)(param_2 + 2), uVar8 < uVar12))
              goto LAB_;
            }
            else {
              uVar9 = *(uint *)(param_2 + 0xc);
              uVar13 = *(ushort *)(pbVar16 + uVar11 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2))
                       & 0x7fff;
              if (uVar9 <= uVar13) goto LAB_;
LAB_:
              func_0x(pbVar16,7);
              uVar9 = *(uint *)(param_2 + 0xc);
              uVar8 = *(uint *)(param_2 + 2);
            }
            if ((uVar13 < uVar9) || (uVar8 < uVar13)) goto LAB_;
            pbVar16 = *(byte **)(param_2 + 4);
            if (*(ushort *)(pbVar16 + uVar13) == 5) {
              param_2[1] = param_2[1] | 2;
              param_2[0xe] = param_2[0xe] + -1;
              uVar17 = (ulonglong)(uVar13 & 0xffff);
              param_2[0x15] = (short)uVar13;
              uVar11 = *(ulonglong *)(param_2 + 4);
              uVar3 = param_2[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar17 + 2 + uVar11) >> 0xe & 1) != 0) {
                uVar3 = *(ushort *)(uVar17 + 2 + uVar11) & 0x3800 | param_2[0x16] & 0xc7ffU;
              }
              param_2[0x16] = uVar3;
              uVar4 = (uVar3 ^ *(ushort *)(uVar17 + 2 + uVar11)) & 0x7ff ^ uVar3;
              param_2[0x16] = uVar4;
              uVar14 = uVar11 + 4 +
                       (ulonglong)((uVar4 & 0x7ff) * 2) + uVar17 + (uVar3 >> 0xb & 7) * 2;
              if (uVar14 < uVar17 + uVar11) {
                func_0x(uVar17 + uVar11,0x19);
                uVar4 = param_2[0x16];
                uVar17 = (ulonglong)(ushort)param_2[0x15];
                uVar11 = (ulonglong)*(uint *)(param_2 + 4);
              }
              if (uVar12 - uVar13 <
                  (((uVar4 & 0x7ff) * 2 - (int)uVar17) - (int)uVar11) + (int)uVar14) {
                func_0x(uVar17 + *(longlong *)(param_2 + 4),0x19);
                uVar4 = param_2[0x16];
              }
              if (((uVar4 & 0x3800) != 0) &&
                 (puVar19 = (ushort *)
                            (*(longlong *)(param_2 + 4) + 4 + (ulonglong)(ushort)param_2[0x15]),
                 (uVar4 & 0x3800) != 0)) {
                do {
                  if ((uVar4 & 0x7ff) < (*puVar19 & 0x7ff)) {
                    func_0x((ulonglong)(ushort)param_2[0x15] + *(longlong *)(param_2 + 4),
                                    0x1a);
                    uVar4 = param_2[0x16];
                  }
                  iVar5 = iVar5 + 1;
                  puVar19 = puVar19 + 1;
                } while (iVar5 < (int)(uVar4 >> 0xb & 7));
              }
              goto LAB_;
            }
            if (*(ushort *)(pbVar16 + uVar13) < 0x400) goto LAB_;
            param_2[1] = param_2[1] | 1;
            uVar3 = param_2[0xe] - 1;
            param_2[0xe] = uVar3;
            if (uVar3 == 0) goto LAB_;
            uVar11 = (ulonglong)uVar3;
          } while ((short)puVar19[(ulonglong)(uVar3 - 1) + 1] < 0);
          uVar11 = (ulonglong)*(uint *)(param_2 + 2);
        }
        else {
LAB_:
          pbVar16 = *(byte **)(param_2 + 4);
          uVar11 = (ulonglong)*(uint *)(param_2 + 2);
        }
      }
      if ((*pbVar16 & 0x40) == 0) {
        *(undefined4 *)(param_2 + 0x13) = 0;
      }
      else {
        *(int *)(param_2 + 0x13) = (int)uVar11;
        *(int *)(param_2 + 2) = (int)uVar11 + 0xe;
        puVar7 = (undefined8 *)func_0x(param_2 + 1);
        uStackX_10 = *puVar7;
        iVar5 = func_0x(&uStackX_10);
        *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar5;
        uVar11 = (ulonglong)*(uint *)(param_2 + 2);
      }
      uVar8 = (uint)uVar11;
      if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
         (*(ulonglong *)(param_2 + 0xf) < uVar11 + *(longlong *)(param_2 + 4))) {
        cVar2 = func_0x(0x14d7f50);
        if ((cVar2 != '\0') &&
           ((lVar6 = func_0x(), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0'))))
        {
          cVar2 = func_0x(0x14d7f50);
          if (cVar2 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0xdc795c,0xee7a48,0x886,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),0x12);
        uVar8 = *(uint *)(param_2 + 2);
      }
      if ((uVar8 == 0) || (0x3f3c < uVar8)) {
        cVar2 = func_0x(0x14d7f50);
        if ((cVar2 != '\0') &&
           ((lVar6 = func_0x(), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0'))))
        {
          cVar2 = func_0x(0x14d7f50);
          if (cVar2 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0xdc795c,0xee7a48,0x88b,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),5);
        uVar8 = *(uint *)(param_2 + 2);
      }
    }
LAB_:
    if (8 < uVar8) goto LAB_;
    bVar15 = **(byte **)(param_2 + 4) & 0xe;
  }
  else {
    if (uVar8 == 0) {
      func_0x(param_2 + 1);
      uVar8 = *(uint *)(param_2 + 2);
    }
    if (8 < uVar8) goto LAB_;
    bVar15 = **(byte **)(param_2 + 4) & 0x1c;
  }
  if ((bVar15 == 0) || (bVar15 == 0xc)) {
    uVar8 = 9;
  }
LAB_:
  uVar10 = 9;
  *(short *)(param_1 + 0x50) = (short)uVar8 + 0x70;
  if (*param_2 == 0) {
    *(undefined4 *)(param_1 + 0x68) = *(undefined4 *)(param_2 + 8);
    return;
  }
  if ((**(byte **)(param_2 + 4) & 0x1c) == 4) {
    uVar10 = 1;
  }
  else if ((**(byte **)(param_2 + 4) & 0x1c) != 0x10) {
    *(uint *)(param_1 + 0x68) = (uint)(ushort)param_2[0xe] + (uint)(ushort)param_2[0xd];
    return;
  }
  *(undefined4 *)(param_1 + 0x68) = uVar10;
  return;
}

