
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,uint *param_3,short *param_4,byte param_5,
                 undefined4 *param_6)

{
  ushort *puVar1;
  longlong *plVar2;
  ushort *puVar3;
  byte bVar4;
  char cVar5;
  ushort uVar6;
  ushort uVar7;
  int iVar8;
  longlong lVar9;
  undefined8 uVar10;
  ulonglong uVar11;
  uint uVar12;
  ulonglong uVar13;
  undefined *puVar14;
  undefined4 uVar15;
  uint *puVar16;
  uint uVar18;
  short sVar19;
  byte *pbVar20;
  ushort *puVar21;
  short *psVar22;
  uint uVar23;
  undefined auStack_98 [64];
  uint uStack_58;
  uint uStack_54;
  short *psStack_50;
  undefined auStack_48 [8];
  undefined8 uStack_40;
  ulonglong uStack_38;
  ulonglong uVar17;
  
  puVar14 = auStack_98;
  uStack_38 = _DAT_ ^ (ulonglong)&uStack_58;
  lVar9 = *(longlong *)(param_1 + 8);
  uVar17 = 0;
  puVar16 = (uint *)0x0;
  uVar15 = 0;
  uVar13 = uVar17;
  psStack_50 = param_4;
  uStack_40 = param_2;
  if (*(int *)(lVar9 + 0x100) == 2) {
    if ((*(byte *)(lVar9 + 0x42) & 4) == 0) {
      uVar13 = (ulonglong)*(uint *)(lVar9 + 0xb0);
      if (0x1f9e < *(uint *)(lVar9 + 0xb0)) {
        uVar13 = 0x1f9e;
      }
    }
    else {
      uVar13 = 0x1f9e;
    }
    uVar15 = (undefined4)uVar13;
    uVar11 = uVar13 + 0xf;
    if (uVar11 <= uVar13) {
      uVar11 = 0xffffffffffffff0;
    }
    uVar11 = uVar11 & 0xfffffffffffffff0;
    func_0x();
    puVar14 = auStack_98 + -uVar11;
    uVar13 = (longlong)&uStack_58 + -uVar11;
  }
  *(undefined8 *)(puVar14 + -8) = 0x1000a0;
  iVar8 = func_0x(param_4,param_3);
  if (iVar8 == 0) {
    if ((param_5 & 0x10) == 0) goto LAB_;
    *(undefined8 *)(puVar14 + -8) = 0x100b47;
    func_0x(param_4,param_3);
  }
  else {
    puVar1 = (ushort *)(param_4 + 1);
    psVar22 = param_4;
    if (*param_4 == 0) {
      uVar12 = *param_3;
      if ((uVar12 & 0xc0000000) == 0x80000000) {
        *(undefined8 *)(puVar14 + -8) = 0x100975;
        iVar8 = func_0x(puVar1);
        if (iVar8 == 0) {
          uStack_58 = 0;
        }
        else {
          *(undefined8 *)(puVar14 + -8) = 0x100991;
          puVar16 = (uint *)func_0x(param_4 + 0x15,param_3,&uStack_58,&psStack_50);
        }
      }
      else {
        uVar6 = *(ushort *)((longlong)param_3 + 6);
        if ((uVar6 & 0x10) != 0) {
          bVar4 = **(byte **)(param_4 + 4);
          if ((bVar4 & 0x10) == 0) {
            if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
              puVar16 = *(uint **)(param_3 + 2) + 1;
              uStack_58 = **(uint **)(param_3 + 2);
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(param_4 + 8) <= (int)uVar12) ||
                  (*(ushort *)(*(byte **)(param_4 + 4) + *(uint *)(param_4 + 8)) <
                   *(ushort *)(param_3 + 1))) goto LAB_;
        }
        if ((int)uVar12 < 0) {
          if (*(int *)(param_4 + 2) == 0) {
            pbVar20 = *(byte **)(param_4 + 4);
            uVar12 = *(uint *)(param_4 + 8);
            uVar13 = (ulonglong)uVar12;
            *puVar1 = 0;
            *(uint *)(param_4 + 10) = uVar12;
            bVar4 = *pbVar20;
            if ((bVar4 & 0x10) != 0) {
              uVar12 = uVar12 + 2 + (*(ushort *)(pbVar20 + uVar13) + 7 >> 3);
              uVar13 = (ulonglong)uVar12;
              *(uint *)(param_4 + 10) = uVar12;
              bVar4 = *pbVar20;
            }
            if ((bVar4 & 0x20) == 0) {
              *(int *)(param_4 + 2) = (int)uVar13;
              param_4[0xe] = 0;
              *(int *)(param_4 + 0xc) = (int)uVar13;
            }
            else {
              puVar21 = (ushort *)(pbVar20 + uVar13);
              uVar6 = *puVar21;
              param_4[0xe] = uVar6;
              if (uVar6 == 0) {
                *(undefined8 *)(puVar14 + -8) = 0x100262;
                cVar5 = func_0x(0x11c1620);
                if (cVar5 != '\0') {
                  *(undefined8 *)(puVar14 + -8) = 0x10026b;
                  lVar9 = func_0x();
                  if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar14 + -8) = 0x100285;
                    cVar5 = func_0x(0x11c1620);
                    if (cVar5 == '\0') {
                      *(undefined8 *)(puVar14 + -8) = 0x1002a1;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar14 + 0x20) = 0;
                      *(undefined8 *)(puVar14 + -8) = 0x1002c7;
                      (*_DAT_)(1,0xab102c,0xbd1118,0x80f);
                    }
                  }
                }
                uVar10 = *(undefined8 *)(param_4 + 4);
                *(undefined8 *)(puVar14 + -8) = 0x1002d5;
                func_0x(uVar10,3);
                uVar13 = (ulonglong)*(uint *)(param_4 + 10);
                uVar6 = param_4[0xe];
              }
              uVar12 = (int)uVar13 + (uVar6 + 1) * 2;
              *(uint *)(param_4 + 0xc) = uVar12;
              if (0x1f9e < uVar12) {
                *(undefined8 *)(puVar14 + -8) = 0x100305;
                cVar5 = func_0x(0x11c1620);
                if (cVar5 != '\0') {
                  *(undefined8 *)(puVar14 + -8) = 0x10030e;
                  lVar9 = func_0x();
                  if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar14 + -8) = 0x100328;
                    cVar5 = func_0x(0x11c1620);
                    if (cVar5 == '\0') {
                      *(undefined8 *)(puVar14 + -8) = 0x100344;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar14 + 0x20) = 0;
                      *(undefined8 *)(puVar14 + -8) = 0x10036a;
                      (*_DAT_)(1,0xab102c,0xbd1118,0x816);
                    }
                  }
                }
                uVar10 = *(undefined8 *)(param_4 + 4);
                *(undefined8 *)(puVar14 + -8) = 0x100378;
                func_0x(uVar10,4);
                uVar6 = param_4[0xe];
                uVar12 = *(uint *)(param_4 + 0xc);
              }
              uVar13 = (ulonglong)uVar6;
              uVar6 = puVar21[uVar13];
              *(uint *)(param_4 + 2) = uVar6 & 0x7fff;
              if ((uVar6 & 0x7fff) < uVar12) {
                *(undefined8 *)(puVar14 + -8) = 0x1003a8;
                cVar5 = func_0x(0x11c1620);
                if (cVar5 != '\0') {
                  *(undefined8 *)(puVar14 + -8) = 0x1003b1;
                  lVar9 = func_0x();
                  if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar14 + -8) = 0x1003cb;
                    cVar5 = func_0x(0x11c1620);
                    if (cVar5 == '\0') {
                      *(undefined8 *)(puVar14 + -8) = 0x1003e7;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar14 + 0x20) = 0;
                      *(undefined8 *)(puVar14 + -8) = 0x10040d;
                      (*_DAT_)(1,0xab102c,0xbd1118,0x81d);
                    }
                  }
                }
                uVar10 = *(undefined8 *)(param_4 + 4);
                *(undefined8 *)(puVar14 + -8) = 0x10041b;
                func_0x(uVar10,4);
                uVar12 = *(uint *)(param_4 + 0xc);
                uVar13 = (ulonglong)(ushort)param_4[0xe];
              }
              puVar3 = puVar21;
              if ((short)uVar13 != 0) {
                do {
                  uVar18 = puVar3[1] & 0x7fff;
                  if ((uVar18 < uVar12) || (*(uint *)(param_4 + 2) < uVar18)) {
                    *(undefined8 *)(puVar14 + -8) = 0x10045f;
                    cVar5 = func_0x(0x11c1620);
                    if (cVar5 != '\0') {
                      *(undefined8 *)(puVar14 + -8) = 0x100468;
                      lVar9 = func_0x();
                      if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar14 + -8) = 0x100482;
                        cVar5 = func_0x(0x11c1620);
                        if (cVar5 == '\0') {
                          *(undefined8 *)(puVar14 + -8) = 0x10049e;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar14 + 0x20) = 0;
                          *(undefined8 *)(puVar14 + -8) = 0x1004c4;
                          (*_DAT_)(1,0xab102c,0xbd1118,0x82a);
                        }
                      }
                    }
                    uVar10 = *(undefined8 *)(param_4 + 4);
                    *(undefined8 *)(puVar14 + -8) = 0x1004d2;
                    func_0x(uVar10,4);
                  }
                  uVar13 = (ulonglong)(ushort)param_4[0xe];
                  uVar23 = (int)uVar17 + 1;
                  uVar17 = (ulonglong)uVar23;
                  psVar22 = psStack_50;
                  puVar3 = puVar3 + 1;
                  uVar12 = uVar18;
                } while ((int)uVar23 < (int)(uint)(ushort)param_4[0xe]);
              }
              if ((short)puVar21[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
                pbVar20 = *(byte **)(param_4 + 4);
                do {
                  uVar12 = *(ushort *)(pbVar20 + uVar13 * 2 + (ulonglong)*(uint *)(param_4 + 10)) &
                           0x7fff;
                  if ((int)uVar13 == 1) {
                    uVar18 = *(uint *)(param_4 + 0xc);
                    uVar23 = uVar18;
LAB_:
                    if ((uVar12 < uVar18) || (*(uint *)(param_4 + 2) < uVar12)) goto LAB_;
                  }
                  else {
                    uVar23 = *(uint *)(param_4 + 0xc);
                    uVar18 = *(ushort *)
                              (pbVar20 + uVar13 * 2 + ((ulonglong)*(uint *)(param_4 + 10) - 2)) &
                             0x7fff;
                    if (uVar23 <= uVar18) goto LAB_;
LAB_:
                    *(undefined8 *)(puVar14 + -8) = 0x100558;
                    func_0x(pbVar20,7);
                    uVar23 = *(uint *)(param_4 + 0xc);
                  }
                  if ((uVar18 < uVar23) || (*(uint *)(param_4 + 2) < uVar18)) goto LAB_;
                  pbVar20 = *(byte **)(param_4 + 4);
                  if (*(ushort *)(pbVar20 + uVar18) == 5) {
                    *puVar1 = *puVar1 | 2;
                    param_4[0xe] = param_4[0xe] + -1;
                    uVar17 = (ulonglong)(uVar18 & 0xffff);
                    param_4[0x15] = (short)uVar18;
                    uVar13 = *(ulonglong *)(param_4 + 4);
                    uVar6 = param_4[0x16] & 0xc7ffU;
                    if ((*(ushort *)(uVar17 + 2 + uVar13) >> 0xe & 1) != 0) {
                      uVar6 = *(ushort *)(uVar17 + 2 + uVar13) & 0x3800 | param_4[0x16] & 0xc7ffU;
                    }
                    param_4[0x16] = uVar6;
                    uVar7 = (uVar6 ^ *(ushort *)(uVar17 + 2 + uVar13)) & 0x7ff ^ uVar6;
                    param_4[0x16] = uVar7;
                    uVar11 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 + uVar13 + (uVar6 >> 0xb & 7) * 2
                             + uVar17;
                    if (uVar11 < uVar17 + uVar13) {
                      *(undefined8 *)(puVar14 + -8) = 0x100660;
                      func_0x(uVar17 + uVar13,0x19);
                      uVar7 = param_4[0x16];
                      uVar17 = (ulonglong)(ushort)param_4[0x15];
                      uVar13 = (ulonglong)*(uint *)(param_4 + 4);
                    }
                    if (uVar12 - uVar18 <
                        (((uVar7 & 0x7ff) * 2 - (int)uVar17) - (int)uVar13) + (int)uVar11) {
                      lVar9 = *(longlong *)(param_4 + 4);
                      *(undefined8 *)(puVar14 + -8) = 0x100698;
                      func_0x(uVar17 + lVar9,0x19);
                      uVar7 = param_4[0x16];
                    }
                    if ((uVar7 & 0x3800) != 0) {
                      puVar21 = (ushort *)
                                (*(longlong *)(param_4 + 4) + (ulonglong)(ushort)param_4[0x15] + 4);
                      iVar8 = 0;
                      if ((uVar7 & 0x3800) != 0) {
                        do {
                          if ((uVar7 & 0x7ff) < (*puVar21 & 0x7ff)) {
                            uVar6 = param_4[0x15];
                            lVar9 = *(longlong *)(param_4 + 4);
                            *(undefined8 *)(puVar14 + -8) = 0x1006f7;
                            func_0x((ulonglong)uVar6 + lVar9,0x1a);
                            uVar7 = param_4[0x16];
                          }
                          iVar8 = iVar8 + 1;
                          puVar21 = puVar21 + 1;
                        } while (iVar8 < (int)(uVar7 >> 0xb & 7));
                      }
                    }
                    goto LAB_;
                  }
                  if (*(ushort *)(pbVar20 + uVar18) < 0x400) goto LAB_;
                  *puVar1 = *puVar1 | 1;
                  uVar6 = param_4[0xe] - 1;
                  param_4[0xe] = uVar6;
                  if (uVar6 == 0) goto LAB_;
                  uVar13 = (ulonglong)uVar6;
                } while ((short)puVar21[(ulonglong)(uVar6 - 1) + 1] < 0);
                uVar13 = (ulonglong)*(uint *)(param_4 + 2);
              }
              else {
LAB_:
                pbVar20 = *(byte **)(param_4 + 4);
                uVar13 = (ulonglong)*(uint *)(param_4 + 2);
              }
            }
            if ((*pbVar20 & 0x40) == 0) {
              *(undefined4 *)(param_4 + 0x13) = 0;
            }
            else {
              *(int *)(param_4 + 0x13) = (int)uVar13;
              *(int *)(param_4 + 2) = (int)uVar13 + 0xe;
              *(undefined8 *)(puVar14 + -8) = 0x10073e;
              uVar10 = func_0x(puVar1);
              *(undefined8 *)(puVar14 + -8) = 0x10074a;
              func_0x(uVar10,auStack_48);
              *(undefined8 *)(puVar14 + -8) = 0x100753;
              iVar8 = func_0x(auStack_48);
              *(int *)(param_4 + 2) = *(int *)(param_4 + 2) + iVar8;
              uVar13 = (ulonglong)*(uint *)(param_4 + 2);
            }
            iVar8 = (int)uVar13;
            if ((*(ulonglong *)(param_4 + 0xf) != 0) &&
               (*(ulonglong *)(param_4 + 0xf) < uVar13 + *(longlong *)(param_4 + 4))) {
              *(undefined8 *)(puVar14 + -8) = 0x100788;
              cVar5 = func_0x(0x11c1620);
              if (cVar5 != '\0') {
                *(undefined8 *)(puVar14 + -8) = 0x100791;
                lVar9 = func_0x();
                if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar14 + -8) = 0x1007ab;
                  cVar5 = func_0x(0x11c1620);
                  if (cVar5 == '\0') {
                    *(undefined8 *)(puVar14 + -8) = 0x1007c7;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar14 + 0x20) = 0;
                    *(undefined8 *)(puVar14 + -8) = 0x1007ed;
                    (*_DAT_)(1,0xab102c,0xbd1118,0x886);
                  }
                }
              }
              uVar10 = *(undefined8 *)(param_4 + 4);
              *(undefined8 *)(puVar14 + -8) = 0x1007fb;
              func_0x(uVar10,0x12);
              iVar8 = *(int *)(param_4 + 2);
            }
            if (0x3f3b < iVar8 - 1U) {
              *(undefined8 *)(puVar14 + -8) = 0x100814;
              cVar5 = func_0x(0x11c1620);
              if (cVar5 != '\0') {
                *(undefined8 *)(puVar14 + -8) = 0x10081d;
                lVar9 = func_0x();
                if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar14 + -8) = 0x100837;
                  cVar5 = func_0x(0x11c1620);
                  if (cVar5 == '\0') {
                    *(undefined8 *)(puVar14 + -8) = 0x100853;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar14 + 0x20) = 0;
                    *(undefined8 *)(puVar14 + -8) = 0x100879;
                    (*_DAT_)(1,0xab102c,0xbd1118,0x88b);
                  }
                }
              }
              uVar10 = *(undefined8 *)(param_4 + 4);
              *(undefined8 *)(puVar14 + -8) = 0x100887;
              func_0x(uVar10,5);
            }
          }
LAB_:
          sVar19 = -*(short *)param_3;
          param_2 = uStack_40;
          if ((*(byte *)((longlong)param_3 + 6) & 0x10) != 0) {
            bVar4 = **(byte **)(param_4 + 4);
            if ((bVar4 & 0x10) == 0) {
              if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
                puVar16 = *(uint **)(param_3 + 2) + 1;
                uStack_58 = **(uint **)(param_3 + 2);
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(param_4 + 8) <= (int)*param_3) ||
                    (*(ushort *)(*(byte **)(param_4 + 4) + *(uint *)(param_4 + 8)) <
                     *(ushort *)(param_3 + 1))) goto LAB_;
          }
          puVar16 = *(uint **)(param_4 + 4);
          lVar9 = (longlong)sVar19;
          if ((uint)(ushort)param_4[0xe] < (uint)(int)sVar19) {
            uStack_58 = 0;
          }
          else {
            uVar12 = *(uint *)(param_4 + 10);
            if (sVar19 == 1) {
              uVar18 = *(uint *)(param_4 + 0xc);
              uVar12 = *(ushort *)((longlong)puVar16 + lVar9 * 2 + (ulonglong)uVar12) & 0x7fff;
LAB_:
              if ((uVar12 < uVar18) || (*(uint *)(param_4 + 2) < uVar12)) goto LAB_;
            }
            else {
              puVar1 = (ushort *)((longlong)puVar16 + lVar9 * 2 + (ulonglong)uVar12);
              uVar18 = *(ushort *)((longlong)puVar16 + lVar9 * 2 + ((ulonglong)uVar12 - 2)) & 0x7fff
              ;
              puVar16 = *(uint **)(param_4 + 4);
              uVar12 = *puVar1 & 0x7fff;
              if (*(uint *)(param_4 + 0xc) <= uVar18) goto LAB_;
LAB_:
              *(undefined8 *)(puVar14 + -8) = 0x10094a;
              func_0x(puVar16,7);
              puVar16 = *(uint **)(param_4 + 4);
            }
            puVar16 = (uint *)((longlong)puVar16 + (ulonglong)uVar18);
            param_2 = uStack_40;
            uStack_58 = uVar12 - uVar18;
          }
        }
        else if ((uVar6 & 8) == 0) {
          if ((uVar6 & 0x10) != 0) {
            bVar4 = **(byte **)(param_4 + 4);
            if ((bVar4 & 0x10) == 0) {
              if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
                uStack_58 = **(uint **)(param_3 + 2);
                puVar16 = *(uint **)(param_3 + 2) + 1;
                if (uStack_58 != 0x1f9e) {
                  *(undefined8 *)(puVar14 + 0x20) = 0;
                  *(undefined8 *)(puVar14 + -8) = 0x1001c2;
                  (*_DAT_)(1,0xc5f470,0xc5ddd8,0x381);
                }
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(param_4 + 8) <= (int)uVar12) ||
                    (*(ushort *)(*(byte **)(param_4 + 4) + *(uint *)(param_4 + 8)) <
                     *(ushort *)(param_3 + 1))) goto LAB_;
          }
          puVar16 = (uint *)((longlong)(int)uVar12 + *(longlong *)(param_4 + 4));
          uStack_58 = 0x1f9e;
        }
        else {
          puVar16 = (uint *)0x835cc0;
          uStack_58 = 1;
          if ((*(byte *)((longlong)(int)uVar12 + *(longlong *)(param_4 + 4)) &
              (byte)(1 << ((byte)uVar6 & 7))) == 0) {
            puVar16 = (uint *)0x835cc1;
          }
        }
      }
    }
    else {
      uStack_54 = 0;
      *(uint **)(puVar14 + 0x20) = &uStack_54;
      *(undefined8 *)(puVar14 + -8) = 0x100a98;
      puVar16 = (uint *)func_0x(puVar1,param_3);
      uVar12 = uStack_58;
      if ((((*param_4 != 0) && (plVar2 = *(longlong **)(param_4 + 8), plVar2 != (longlong *)0x0)) &&
          (*plVar2 != 0)) &&
         (((*(byte *)((longlong)param_3 + 6) & 8) == 0 && ((uStack_54 & 1) == 0)))) {
        if ((puVar16 == (uint *)0x0) || (puVar16 == (uint *)0x835cc0)) {
          puVar16 = (uint *)0x0;
          uStack_58 = 0;
        }
        else {
          *(uint *)(puVar14 + 0x38) = uStack_54;
          *(uint **)(puVar14 + 0x30) = &uStack_58;
          *(undefined4 *)(puVar14 + 0x28) = uVar15;
          *(ulonglong *)(puVar14 + 0x20) = uVar13;
          *(undefined8 *)(puVar14 + -8) = 0x100b06;
          puVar16 = (uint *)func_0x(plVar2,param_3,puVar16,uVar12);
        }
      }
    }
LAB_:
    if ((puVar16 == (uint *)0x0) || (uStack_58 == 0)) goto LAB_;
    if (uStack_58 < 0xd) {
LAB_:
      if ((uStack_58 != 0x10) || (sVar19 = *(short *)puVar16, sVar19 != 0)) goto LAB_;
    }
    else {
      uVar13 = ((ulonglong)uStack_58 - 0xc) / 0xc;
      if ((((0x1f8 < (uint)uVar13) || (sVar19 = *(short *)puVar16, (sVar19 - 1U & 0xfffc) != 0)) ||
          (sVar19 == 3)) || ((ulonglong)uStack_58 - 0xc != uVar13 * 0xc)) goto LAB_;
    }
    if (0xc < uStack_58) {
      uVar13 = ((ulonglong)uStack_58 - 0xc) / 0xc;
      if ((((uint)uVar13 < 0x1f9) && (sVar19 == 2)) && ((ulonglong)uStack_58 - 0xc == uVar13 * 0xc))
      {
        if ((param_5 & 0x80) == 0) goto LAB_;
        *(undefined8 *)(puVar14 + -8) = 0x100a6e;
        func_0x(param_2,psVar22,param_3);
        goto LAB_;
      }
    }
    if ((param_5 & 0x40) == 0) goto LAB_;
    *(undefined8 *)(puVar14 + -8) = 0x100b31;
    func_0x(param_2,psVar22,param_3);
  }
LAB_:
  *param_6 = 1;
LAB_:
  uVar13 = uStack_38 ^ (ulonglong)&uStack_58;
  *(undefined8 *)(puVar14 + -8) = 0x100b60;
  func_0x(uVar13);
  return;
}

