
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint *param_2,undefined2 param_3,undefined8 param_4)

{
  byte *pbVar1;
  undefined uVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  int **ppiVar5;
  longlong *plVar6;
  uint **ppuVar7;
  char cVar8;
  undefined2 uVar9;
  short sVar10;
  int iVar11;
  uint uVar12;
  int iVar13;
  int iVar14;
  longlong lVar15;
  longlong lVar16;
  uint *puVar17;
  ulonglong uVar18;
  longlong *plVar19;
  longlong lVar20;
  longlong lVar21;
  short *psVar22;
  short sVar23;
  undefined4 *puVar24;
  int *piVar25;
  code *UNRECOVERED_JUMPTABLE_00;
  short sVar26;
  uint uVar27;
  longlong lVar28;
  ulonglong uVar29;
  byte **ppbVar30;
  longlong unaff_GS_OFFSET;
  bool bVar31;
  char acStackX_8 [2];
  short asStackX_a [3];
  uint *apuStackX_10 [2];
  longlong lStackX_20;
  uint uStack_2548;
  uint uStack_2544;
  ushort uStack_2540;
  uint uStack_253c;
  undefined4 uStack_2538;
  undefined4 uStack_2534;
  undefined8 uStack_2528;
  ushort uStack_2520;
  undefined8 uStack_2510;
  undefined2 uStack_2508;
  undefined8 uStack_2500;
  ushort uStack_24f8;
  int iStack_24f0;
  undefined4 uStack_24ec;
  undefined2 uStack_24e8;
  undefined4 uStack_24e4;
  undefined2 uStack_24e0;
  undefined4 uStack_24dc;
  undefined2 uStack_24d8;
  undefined4 uStack_24d4;
  undefined2 uStack_24d0;
  undefined8 uStack_24a8;
  undefined4 uStack_2498;
  undefined2 uStack_2494;
  undefined2 uStack_2492;
  undefined4 uStack_2490;
  undefined2 uStack_248c;
  undefined2 uStack_248a;
  int iStack_2488;
  undefined2 uStack_2484;
  undefined2 uStack_2482;
  int iStack_2480;
  undefined2 uStack_247c;
  undefined2 uStack_247a;
  int iStack_2478;
  short sStack_2474;
  uint uStack_2470;
  undefined2 uStack_246c;
  short sStack_246a;
  undefined8 uStack_2468;
  undefined2 uStack_2460;
  undefined auStack_2458 [4];
  undefined4 uStack_2454;
  undefined8 uStack_2450;
  uint uStack_2448;
  undefined8 uStack_2444;
  undefined8 uStack_2430;
  undefined2 uStack_2428;
  undefined8 uStack_2420;
  ushort uStack_2418;
  undefined8 uStack_2410;
  undefined uStack_2408;
  undefined4 uStack_2404;
  undefined auStack_23f0 [4];
  undefined auStack_23ec [4];
  undefined auStack_23e8 [4];
  undefined auStack_23e4 [12];
  undefined8 uStack_23d8;
  undefined auStack_23c8 [8];
  undefined4 uStack_23c0;
  undefined4 uStack_23b8;
  uint **ppuStack_23b0;
  undefined *puStack_23a8;
  undefined8 uStack_23a0;
  uint *puStack_2398;
  undefined4 uStack_2390;
  undefined4 uStack_238c;
  longlong lStack_2388;
  undefined4 uStack_2380;
  undefined4 uStack_237c;
  longlong lStack_2378;
  undefined4 uStack_2370;
  undefined4 uStack_236c;
  short *psStack_2368;
  int iStack_2360;
  undefined4 uStack_235c;
  short *psStack_2358;
  int iStack_2350;
  undefined4 uStack_234c;
  undefined8 uStack_2348;
  undefined4 uStack_2340;
  undefined4 uStack_233c;
  undefined auStack_2338 [448];
  undefined8 uStack_2178;
  undefined8 uStack_2170;
  uint uStack_2168;
  undefined2 uStack_2164;
  uint uStack_2162;
  undefined uStack_215e;
  undefined uStack_215d;
  short sStack_2128;
  undefined4 uStack_2124;
  byte *pbStack_2120;
  byte **ppbStack_2118;
  undefined8 uStack_210a;
  undefined2 uStack_2102;
  undefined2 uStack_2100;
  undefined6 uStack_20fe;
  int iStack_20f4;
  undefined auStack_20f0 [16];
  undefined auStack_20e0 [8];
  undefined8 uStack_20d8;
  undefined8 uStack_20d0;
  undefined6 uStack_20c8;
  undefined2 uStack_20c2;
  undefined6 uStack_20c0;
  undefined2 uStack_20ba;
  undefined8 uStack_20b8;
  undefined auStack_20b0 [16];
  undefined auStack_20a0 [16];
  undefined auStack_2090 [16];
  undefined8 uStack_2080;
  undefined8 uStack_2078;
  uint uStack_2070;
  undefined2 uStack_206c;
  undefined2 uStack_206a;
  undefined8 uStack_2068;
  undefined8 uStack_2060;
  short asStack_2058 [24];
  short asStack_2028 [4072];
  ulonglong uStack_58;
  undefined8 uStack_48;
  
  uStack_48 = 0x10001f;
  lVar15 = func_0x();
  lVar15 = -lVar15;
  uStack_23d8 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar15);
  uStack_2450 = param_4;
  *(undefined2 *)(acStackX_8 + lVar15 + 2) = param_3;
  *(uint **)((longlong)apuStackX_10 + lVar15) = param_2;
  *(longlong *)((longlong)&lStackX_20 + lVar15) = param_1;
  lVar20 = 0;
  *(undefined8 *)(&stack0x00000030 + lVar15) = 0;
  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar15) = 0;
  (&stack0xfffffffffffffff8)[lVar15] = 0;
  uVar27 = *(uint *)(&stack0xfffffffffffffffc + lVar15);
  *(uint *)(&stack0xfffffffffffffffc + lVar15) = uVar27 & 0xffff0000;
  *(uint *)(&stack0xfffffffffffffffc + lVar15) = uVar27 & 0xff000000;
  iVar14 = 0;
  *(undefined4 *)(&stack0xfffffffffffffffc + lVar15) = 0;
  uStack_2410 = 0;
  uStack_2408 = 0;
  uStack_2404 = 0;
  sStack_2128 = -1;
  pbStack_2120 = (byte *)0x0;
  uStack_2124 = 0;
  uStack_210a = 0;
  uStack_2100 = 0;
  uStack_20fe = 0;
  ppbStack_2118 = (byte **)0x0;
  iStack_20f4 = 0xffffffff;
  *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x1000ee;
  func_0x(0x67);
  lVar21 = *(longlong *)(param_1 + 0xa0);
  sVar26 = *(short *)(param_2 + 1);
  uStack_24a8 = lVar21;
  if (sVar26 == 0) goto LAB_;
  uStack_2534 = 1;
  uVar4 = *(undefined8 *)(*(longlong *)(param_1 + 0x20) + 0x6a0);
  *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100123;
  lVar16 = func_0x(uVar4,sVar26,1);
  if ((lVar16 == 0) || (uVar27 = *param_2, *(uint *)(lVar16 + 0x80) <= uVar27)) goto LAB_;
  lVar16 = *(longlong *)(lVar21 + 8);
  if ((lVar16 == 0) || (lVar28 = *(longlong *)(lVar16 + 8), *(char *)(lVar28 + 0x3f) != '\0')) {
    if (*(int *)(lVar21 + 0x40) == 2) {
      sVar26 = *(short *)(*(longlong *)(lVar21 + 0x30) + 0x10);
      iVar11 = *(int *)(*(longlong *)(lVar21 + 0x30) + 0xc);
    }
    else {
      sVar26 = *(short *)(*(longlong *)(lVar21 + 0x28) + 0x20);
      iVar11 = *(int *)(*(longlong *)(lVar21 + 0x28) + 0x1c);
    }
    *(int *)(&stack0x00000038 + lVar15) = iVar11;
    *(short *)(&stack0x0000003c + lVar15) = sVar26;
    if (lVar16 != 0) goto LAB_;
LAB_:
    if (*(int *)(lVar21 + 0x40) == 2) {
      uStack_2498 = **(undefined4 **)(lVar21 + 0x30);
      uStack_2494 = *(undefined2 *)(*(undefined4 **)(lVar21 + 0x30) + 1);
      uStack_2492 = 0;
      puVar24 = &uStack_2498;
    }
    else {
      uStack_2490 = **(undefined4 **)(lVar21 + 0x28);
      uStack_248c = *(undefined2 *)(*(undefined4 **)(lVar21 + 0x28) + 1);
      uStack_248a = 0;
      puVar24 = &uStack_2490;
    }
    *(undefined4 *)(&stack0x00000028 + lVar15) = *puVar24;
    uVar9 = *(undefined2 *)(puVar24 + 1);
  }
  else {
    iVar11 = *(int *)(lVar28 + 0x38);
    *(int *)(&stack0x00000038 + lVar15) = iVar11;
    sVar26 = *(short *)(lVar28 + 0x3c);
    *(short *)(&stack0x0000003c + lVar15) = sVar26;
LAB_:
    lVar16 = *(longlong *)(lVar16 + 8);
    if (*(char *)(lVar16 + 0x3f) != '\0') goto LAB_;
    *(undefined4 *)(&stack0x00000028 + lVar15) = *(undefined4 *)(lVar16 + 8);
    uVar9 = *(undefined2 *)(lVar16 + 0xc);
  }
  *(undefined2 *)(&stack0x0000002e + lVar15) = 0;
  *(undefined2 *)(&stack0x0000002c + lVar15) = uVar9;
  if ((iVar11 == 0) && (sVar26 == 0)) {
LAB_:
    uStack_2534 = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x102bcc;
    func_0x(&uStack_2410);
    *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x102bd7;
    func_0x(&stack0xfffffffffffffff0 + lVar15);
    *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x102be9;
    func_0x(uStack_58 ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar15));
    return;
  }
  uStack_2060 = 0;
  uStack_206c = *(undefined2 *)(param_2 + 1);
  uStack_206a = 0;
  uStack_2078 = 0;
  uStack_2068 = 0;
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
  *(undefined4 *)(&stack0xffffffffffffffe0 + lVar15) = 5;
  uVar4 = *(undefined8 *)(param_1 + 0x20);
  *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x10025d;
  uStack_2070 = uVar27;
  cVar8 = func_0x
                    (uVar4,&stack0x00000028 + lVar15,&stack0x00000038 + lVar15,&uStack_2078);
  if (cVar8 == '\0') goto LAB_;
  ppiVar5 = *(int ***)(param_1 + 8);
  uStack_2444 = 0;
  lVar16 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar21 = *(longlong *)(lVar16 + 0x100);
  puVar17 = _DAT_;
  if (lVar21 == 0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x1002a3;
    puVar17 = (uint *)(*_DAT_)(0);
    lVar21 = *(longlong *)(lVar16 + 0x100);
  }
  uVar29 = rdtsc();
  uVar18 = CONCAT44((int)((ulonglong)puVar17 >> 0x20),(int)uVar29) | uVar29 & 0xffffffff00000000;
  uVar29 = *(ulonglong *)(lVar21 + 0x340);
  if ((uVar29 < uVar18) ||
     ((uVar29 != 0x7fffffffffffffff &&
      (*(ulonglong *)(*(longlong *)(lVar21 + 0x260) + 0xdf0) < uVar29 - uVar18)))) {
    *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x10031c;
    iVar11 = func_0x(0,0x1ca7da8);
    bVar31 = iVar11 == 2;
LAB_:
    if (bVar31) {
      *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100328;
      func_0x(0xa6);
    }
  }
  else if (((*(uint *)(*(longlong *)(lVar21 + 600) + 0xbc) & 4) != 0) &&
          (lVar21 = *(longlong *)(*(longlong *)(lVar21 + 600) + 0x98),
          (*(byte *)(lVar21 + 0x268) & 1) == 0)) {
    bVar31 = (*(uint *)(lVar21 + 800) & 0x180) == 0;
    goto LAB_;
  }
  lVar21 = *(longlong *)(ppiVar5[0xb] + 8);
  if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
    lVar16 = *(longlong *)
              ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar16 != 0) && (lVar16 = **(longlong **)(lVar16 + 0x38), lVar16 != 0)) {
      *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100384;
      iVar11 = (*_DAT_)(lVar16,0x337);
      if (iVar11 != 0) goto LAB_;
    }
    lVar16 = *(longlong *)
              ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
              + 8);
    if (lVar16 != 0) {
      lVar20 = *(longlong *)(lVar16 + 0x60);
    }
  }
LAB_:
  lVar16 = *(longlong *)(lVar21 + 0x728);
  do {
    uStack_253c = 0;
    lVar28 = *(longlong *)(&stack0xfffffffffffffff0 + lVar15);
    if (lVar28 != 0) {
      iVar11 = (int)*(short *)(&stack0xfffffffffffffffc + lVar15);
      if (((*(ushort *)(lVar28 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
        plVar19 = *(longlong **)(&stack0xfffffffffffffff0 + lVar15);
        if (((byte)*(undefined2 *)(lVar28 + 0x62) >> 3 & 1) != 0) {
          if (iVar11 == 3) {
            iVar11 = 4;
          }
          else if (iVar11 < 2) goto LAB_;
          if ((((*(uint *)(*(longlong *)(&stack0xfffffffffffffff0 + lVar15) + 100) & 8) != 0) &&
              (lVar28 = *(longlong *)(*(longlong *)(&stack0xfffffffffffffff0 + lVar15) + 0x90),
              lVar28 != 0)) && (*(longlong *)(lVar28 + 0x758) != 0)) {
            uVar4 = *(undefined8 *)(lVar28 + 0x758);
            *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100468;
            func_0x(uVar4,*(undefined8 *)(&stack0xfffffffffffffff0 + lVar15),iVar11)
            ;
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar19 + 100) & 8) != 0)) &&
           ((2 < iVar11 &&
            (((*(uint *)((longlong)plVar19 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar28 = *plVar19, lVar28 != 0)))))) {
          *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x1004b1;
          iVar13 = (*_DAT_)(lVar28,0x2000,2,auStack_23e8);
          if (iVar13 != 0) {
            LOCK();
            *(uint *)((longlong)plVar19 + 100) = *(uint *)((longlong)plVar19 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar19 + 100) = *(uint *)((longlong)plVar19 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x1004d4;
        func_0x(plVar19 + 0x13,iVar11);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x1004f3;
          func_0x(plVar19,0,iVar11);
        }
        *(uint *)(&stack0xfffffffffffffffc + lVar15) =
             *(uint *)(&stack0xfffffffffffffffc + lVar15) & 0xffff0000;
        *(undefined8 *)(&stack0xfffffffffffffff0 + lVar15) = 0;
        param_2 = *(uint **)((longlong)apuStackX_10 + lVar15);
      }
      else {
        *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100401;
        func_0x(&stack0xfffffffffffffff0 + lVar15);
      }
    }
    if (*(longlong *)(lVar21 + 0x728) != 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100529;
      func_0x(&stack0xfffffffffffffff0 + lVar15,param_2,lVar21);
      lVar28 = *(longlong *)(&stack0xfffffffffffffff0 + lVar15);
      if (lVar28 != 0) {
        iVar11 = (int)*(short *)(&stack0xfffffffffffffffc + lVar15);
        if (((*(ushort *)(lVar28 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
          plVar19 = *(longlong **)(&stack0xfffffffffffffff0 + lVar15);
          if (((byte)*(undefined2 *)(lVar28 + 0x62) >> 3 & 1) != 0) {
            if (iVar11 == 3) {
              iVar11 = 4;
            }
            else if (iVar11 < 2) goto LAB_;
            if ((((*(uint *)(*(longlong *)(&stack0xfffffffffffffff0 + lVar15) + 100) & 8) != 0) &&
                (lVar28 = *(longlong *)(*(longlong *)(&stack0xfffffffffffffff0 + lVar15) + 0x90),
                lVar28 != 0)) && (*(longlong *)(lVar28 + 0x758) != 0)) {
              uVar4 = *(undefined8 *)(lVar28 + 0x758);
              *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x1005bc;
              func_0x
                        (uVar4,*(undefined8 *)(&stack0xfffffffffffffff0 + lVar15),iVar11);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar19 + 100) & 8) != 0)) &&
             ((2 < iVar11 &&
              (((*(uint *)((longlong)plVar19 + 100) & 0xc0000000) != 0x40000000 &&
               (lVar28 = *plVar19, lVar28 != 0)))))) {
            *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100601;
            iVar13 = (*_DAT_)(lVar28,0x2000,2,auStack_23ec);
            if (iVar13 != 0) {
              LOCK();
              *(uint *)((longlong)plVar19 + 100) = *(uint *)((longlong)plVar19 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar19 + 100) = *(uint *)((longlong)plVar19 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100624;
          func_0x(plVar19 + 0x13,iVar11);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100643;
            func_0x(plVar19,0,iVar11);
          }
          *(uint *)(&stack0xfffffffffffffffc + lVar15) =
               *(uint *)(&stack0xfffffffffffffffc + lVar15) & 0xffff0000;
          *(undefined8 *)(&stack0xfffffffffffffff0 + lVar15) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100555;
          func_0x(&stack0xfffffffffffffff0 + lVar15);
        }
      }
    }
    *(uint **)(&stack0xffffffffffffffe8 + lVar15) = &uStack_2448;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar15) = 2;
    *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x10067d;
    plVar19 = (longlong *)
              func_0x
                        (_DAT_,lVar21,*(undefined8 *)((longlong)apuStackX_10 + lVar15),
                         &uStack_253c);
    *(longlong **)(&stack0xfffffffffffffff0 + lVar15) = plVar19;
    uVar27 = *(uint *)(&stack0xfffffffffffffffc + lVar15) & 0xffff0002 | 2;
    *(uint *)(&stack0xfffffffffffffffc + lVar15) = uVar27;
    if (lVar20 != 0) {
      uVar29 = (ulonglong)(*(uint *)(lVar20 + 0x500) & 0xf);
      if (*(longlong *)(lVar20 + 0x508 + uVar29 * 8) != *plVar19) {
        *(longlong *)(lVar20 + 0x508 + uVar29 * 8) = *plVar19;
        *(longlong *)(lVar20 + 0x500) = *(longlong *)(lVar20 + 0x500) + 1;
        uVar27 = *(uint *)(&stack0xfffffffffffffffc + lVar15);
      }
    }
    uVar27 = (uStack_253c >> 3 & 1) << 0x18 | uVar27 & 0xffffff;
    *(uint *)(&stack0xfffffffffffffffc + lVar15) = uVar27;
    *(uint *)((longlong)&lStackX_20 + lVar15 + -0x20) =
         uStack_253c >> 4 & 1 | *(uint *)((longlong)&lStackX_20 + lVar15 + -0x20) & 0xffffff00;
    if (((lVar16 != 0) && (lVar20 != 0)) && (lVar20 == *(longlong *)(lVar21 + 0x1c38))) {
      *(longlong *)(lVar16 + 0x5b28) = *(longlong *)(lVar16 + 0x5b28) + 1;
      if ((int)uStack_2444 != 0) {
        *(longlong *)(lVar16 + 0x5b30) = *(longlong *)(lVar16 + 0x5b30) + 1;
        *(longlong *)(lVar16 + 0x5b38) = *(longlong *)(lVar16 + 0x5b38) + (ulonglong)uStack_2448;
        if (0xffffff < uVar27) {
          *(longlong *)(lVar16 + 0x5b40) = *(longlong *)(lVar16 + 0x5b40) + 1;
          *(longlong *)(lVar16 + 0x5b48) = *(longlong *)(lVar16 + 0x5b48) + (ulonglong)uStack_2448;
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100753;
    cVar8 = func_0x(lVar21);
    uStack_2538 = 9;
    if ((cVar8 == '\0') || (*(char *)(lVar21 + 0x2050) == '\0')) goto LAB_;
    param_2 = *(uint **)((longlong)apuStackX_10 + lVar15);
    if ((*param_2 == 0) || ((*param_2 == 9 && (*(short *)(param_2 + 1) == 1)))) goto LAB_;
    lVar28 = **(longlong **)(&stack0xfffffffffffffff0 + lVar15);
    if (*(short *)(lVar28 + 0x24) == 0) {
LAB_:
      uStack_2500 = *(undefined8 *)(lVar28 + 0x28);
      uStack_24f8 = *(ushort *)(lVar28 + 0x30);
    }
    else {
      cVar8 = *(char *)(lVar28 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(lVar28 + 0x18) != 99) {
LAB_:
          if (cVar8 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar8 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar28 + 0x18) != 99) goto LAB_;
      }
      uStack_24ec = *(undefined4 *)(lVar28 + 0x20);
      uStack_24e8 = *(undefined2 *)(lVar28 + 0x24);
      *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x1007d9;
      cVar8 = func_0x(&uStack_24ec);
      if (cVar8 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x1007e9;
      func_0x(lVar28,&uStack_2500);
    }
    uVar27 = *(uint *)(lVar21 + 0x2108);
    do {
      uVar12 = uVar27 & 0xfffffffe;
      uVar4 = *(undefined8 *)(lVar21 + 0x20fc);
      uVar3 = *(undefined4 *)(lVar21 + 0x2104);
      LOCK();
      *(undefined4 *)(&stack0xffffffffffffffc0 + lVar15) =
           *(undefined4 *)(&stack0xffffffffffffffc0 + lVar15);
      UNLOCK();
      uVar27 = *(uint *)(lVar21 + 0x2108);
    } while (uVar12 != uVar27);
    uStack_2548 = (uint)uVar4;
    if ((uint)uStack_2500 <= uStack_2548) {
      if (uStack_2548 != (uint)uStack_2500) goto LAB_;
      uVar27 = (uint)((ulonglong)uVar4 >> 0x20);
      if ((uStack_2500._4_4_ <= uVar27) &&
         ((uVar27 != uStack_2500._4_4_ || (uStack_2540 = (ushort)uVar3, uStack_24f8 <= uStack_2540))
         )) goto LAB_;
    }
    if ((*(char *)(lVar21 + 0x6ac8) == '\0') &&
       (*(longlong *)
         (*(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
           ) + 0x60) != *(longlong *)(lVar21 + 0x2120))) {
      *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x1008aa;
      cVar8 = func_0x(lVar21);
      if (cVar8 == '\0') {
        uVar27 = *(uint *)(lVar21 + 0x2108);
        do {
          uVar12 = uVar27 & 0xfffffffe;
          uVar4 = *(undefined8 *)(lVar21 + 0x20fc);
          uVar3 = *(undefined4 *)(lVar21 + 0x2104);
          LOCK();
          *(undefined4 *)(&stack0xffffffffffffffc0 + lVar15) =
               *(undefined4 *)(&stack0xffffffffffffffc0 + lVar15);
          UNLOCK();
          uVar27 = *(uint *)(lVar21 + 0x2108);
        } while (uVar12 != uVar27);
        uStack_2420 = uVar4;
        uStack_2540 = (ushort)uVar3;
        uStack_2418 = uStack_2540;
        lVar20 = **(longlong **)(&stack0xfffffffffffffff0 + lVar15);
        if (*(short *)(lVar20 + 0x24) == 0) {
LAB_:
          uStack_2528 = *(undefined8 *)(lVar20 + 0x28);
          uStack_2520 = *(ushort *)(lVar20 + 0x30);
        }
        else {
          cVar8 = *(char *)(lVar20 + 1);
          if (cVar8 == '\v') {
            if (*(int *)(lVar20 + 0x18) != 99) {
LAB_:
              if (cVar8 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar8 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar20 + 0x18) != 99) goto LAB_;
          }
          uStack_24dc = *(undefined4 *)(lVar20 + 0x20);
          uStack_24d8 = *(undefined2 *)(lVar20 + 0x24);
          *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100b87;
          cVar8 = func_0x(&uStack_24dc);
          if (cVar8 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100b97;
          func_0x(lVar20,&uStack_2528);
        }
        uStack_2548 = (uint)uVar4;
        if (uStack_2548 < (uint)uStack_2528) {
LAB_:
          lVar20 = *(longlong *)(lVar21 + 0x6b0);
          *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100bf7;
          func_0x(&uStack_2528,asStack_2058,auStack_2458);
          *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100c0e;
          func_0x(&uStack_2420,asStack_2028,auStack_2458);
          if ((_DAT_ & 0x10000) == 0) goto LAB_;
          uStack_23c0 = 0x60000;
          uStack_23b8 = 0;
          ppuStack_23b0 = &puStack_2398;
          puStack_23a8 = auStack_2338;
          uStack_2178 = 0;
          uStack_23a0 = 0;
          uStack_2170 = 0;
          puStack_2398 = &uStack_2168;
          uStack_2390 = 0x34;
          uStack_238c = 5;
          lStack_2388 = 0x1498008;
          uStack_2380 = 0x10;
          uStack_237c = 5;
          lStack_2378 = 0x1498008;
          uStack_2370 = 0x10;
          uStack_236c = 6;
          psStack_2368 = (short *)0x0;
          iStack_2360 = 0;
          uStack_235c = 7;
          psStack_2358 = (short *)0x0;
          iStack_2350 = 0;
          uStack_234c = 8;
          uStack_2348 = 0;
          uStack_2340 = 0;
          uStack_233c = 9;
          uStack_2168 = (uint)*(ushort *)(lVar21 + 0x6b8);
          param_2 = *(uint **)((longlong)apuStackX_10 + lVar15);
          uStack_2164 = *(undefined2 *)(param_2 + 1);
          uStack_2162 = *param_2;
          uStack_215e = 0xff;
          uStack_215d = *(undefined *)(**(longlong **)(&stack0xfffffffffffffff0 + lVar15) + 1);
          lStack_2388 = lVar20 + 0x254;
          lStack_2378 = lVar20 + 0x244;
          lVar21 = -1;
          do {
            lVar21 = lVar21 + 1;
          } while (asStack_2058[lVar21] != 0);
          psStack_2368 = asStack_2058;
          iStack_2360 = (int)lVar21 * 2;
          lVar21 = -1;
          do {
            lVar21 = lVar21 + 1;
          } while (asStack_2028[lVar21] != 0);
          iStack_2350 = (int)lVar21 * 2;
          psStack_2358 = asStack_2028;
          uStack_2454 = 0;
          UNRECOVERED_JUMPTABLE_00 = *(code **)(_DAT_ + 0x10);
          *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100dd4;
          puVar17 = (uint *)(*UNRECOVERED_JUMPTABLE_00)(lVar20,&uStack_2454);
          ppuVar7 = ppuStack_23b0;
          if (puVar17 != (uint *)0x0) {
            lVar21 = -1;
            do {
              lVar21 = lVar21 + 1;
            } while (*(short *)((longlong)puVar17 + lVar21 * 2) != 0);
            iVar14 = (int)lVar21 * 2;
          }
          ppuStack_23b0[10] = puVar17;
          *(int *)(ppuVar7 + 0xb) = iVar14;
          *(undefined4 *)((longlong)ppuVar7 + 0x5c) = 9;
          *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100e11;
          func_0x(auStack_23c8);
        }
        else {
          if (uStack_2548 == (uint)uStack_2528) {
            uStack_2544 = (uint)((ulonglong)uVar4 >> 0x20);
            uVar27 = (uint)((ulonglong)uStack_2528 >> 0x20);
            if ((uStack_2544 < uVar27) || ((uStack_2544 == uVar27 && (uStack_2540 < uStack_2520))))
            goto LAB_;
          }
LAB_:
          param_2 = *(uint **)((longlong)apuStackX_10 + lVar15);
        }
LAB_:
        if (*ppiVar5 != (int *)0x0) {
          if (((*(uint *)(&stack0xfffffffffffffffc + lVar15) & 0xff000000) != 0) &&
             (piVar25 = *ppiVar5 + 1, *piVar25 = *piVar25 + 1,
             *(char *)((longlong)&lStackX_20 + lVar15 + -0x20) != '\0')) {
            (*ppiVar5)[2] = (*ppiVar5)[2] + 1;
          }
          **ppiVar5 = **ppiVar5 + 1;
        }
        if ((int)uStack_2444 != 0) {
          uVar3 = *(undefined4 *)(ppiVar5 + 0x2f);
          uVar2 = *(undefined *)(**(longlong **)(&stack0xfffffffffffffff0 + lVar15) + 1);
          piVar25 = ppiVar5[0xb];
          *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100e75;
          func_0x(piVar25,uVar2,&uStack_2448,uVar3);
        }
        lVar21 = **(longlong **)(&stack0xfffffffffffffff0 + lVar15);
        *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100e94;
        iVar14 = func_0x(lVar21,1,3);
        if (iVar14 == 0) {
          sVar26 = *(short *)(acStackX_8 + lVar15 + 2);
          iStack_24f0 = (int)sVar26;
          if (((uint)(int)sVar26 < (uint)*(ushort *)(lVar21 + 0x16)) &&
             (*(short *)(lVar21 + (0xfff - (longlong)sVar26) * 2) != 0)) {
            if ((*(longlong *)(uStack_24a8 + 8) == 0) ||
               (lVar20 = *(longlong *)(*(longlong *)(uStack_24a8 + 8) + 8),
               *(char *)(lVar20 + 0x3f) != '\0')) {
              if (*(int *)(uStack_24a8 + 0x40) == 2) {
                iStack_2488 = **(int **)(uStack_24a8 + 0x30);
                uStack_2484 = *(undefined2 *)(*(int **)(uStack_24a8 + 0x30) + 1);
                uStack_2482 = 0;
                piVar25 = &iStack_2488;
              }
              else {
                iStack_2480 = **(int **)(uStack_24a8 + 0x28);
                uStack_247c = *(undefined2 *)(*(int **)(uStack_24a8 + 0x28) + 1);
                uStack_247a = 0;
                piVar25 = &iStack_2480;
              }
              iStack_2478 = *piVar25;
              sStack_2474 = *(short *)(piVar25 + 1);
            }
            else {
              iStack_2478 = *(int *)(lVar20 + 8);
              sStack_2474 = *(short *)(lVar20 + 0xc);
            }
            if (*(int *)(lVar21 + 0x18) == iStack_2478) {
              sVar23 = 0;
              if (*(short *)(lVar21 + 6) != 1) {
                sVar23 = *(short *)(lVar21 + 6);
              }
              sVar10 = 0;
              if (sStack_2474 != 1) {
                sVar10 = sStack_2474;
              }
              if (sVar23 == sVar10) {
                cVar8 = *(char *)(lVar21 + 1);
                acStackX_8[lVar15] = cVar8;
                if (cVar8 == '\x03' || cVar8 == '\x04') {
                  if (*(char *)(*(longlong *)(*(longlong *)((longlong)&lStackX_20 + lVar15) + 0x20)
                               + 0x1cde) != '\0') {
                    uStack_2470 = *param_2;
                    uStack_246c = *(undefined2 *)(param_2 + 1);
                    (&stack0xffffffffffffffe8)[lVar15] = 0;
                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar15) = 0;
                    *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100fb6;
                    sStack_246a = sVar26;
                    func_0x
                              (*(longlong *)((longlong)&lStackX_20 + lVar15),&uStack_2470,
                               &stack0xfffffffffffffff0 + lVar15,1);
                    acStackX_8[lVar15] = *(char *)(lVar21 + 1);
                  }
                  iStack_20f4 = (int)sVar26;
                  if (-1 < *(char *)(lVar21 + 2)) goto LAB_;
                  pbVar1 = (byte *)(lVar21 + 0x60);
                  if ((sStack_2128 == 0) ||
                     (ppbVar30 = ppbStack_2118, ppbStack_2118 == (byte **)0x0)) {
                    uStack_20c8 = 0;
                    uStack_20ba = 0;
                    auStack_20a0 = ZEXT816(0);
                    auStack_20f0 = ZEXT816(0);
                    stack0xffffffffffffdf22 = SUB1614(ZEXT816(0),2);
                    auStack_20e0._0_2_ = 0xffff;
                    uStack_20d8 = 0;
                    uStack_20c2 = 0;
                    uStack_20c0 = 0;
                    uStack_20b8 = 0;
                    uStack_20d0 = 0;
                    auStack_20b0 = ZEXT816(0);
                    auStack_2090._0_12_ = ZEXT812(0);
                    auStack_2090._12_4_ = 0;
                    uStack_2080 = 0;
                    ppbVar30 = (byte **)auStack_20f0;
                  }
                  if (*(short *)(lVar21 + 0x24) == 0) {
LAB_:
                    uStack_2510 = *(undefined8 *)(lVar21 + 0x28);
                    uStack_2508 = *(undefined2 *)(lVar21 + 0x30);
                  }
                  else {
                    cVar8 = *(char *)(lVar21 + 1);
                    if (cVar8 == '\v') {
                      if (*(int *)(lVar21 + 0x18) != 99) {
LAB_:
                        if (cVar8 != '\t') goto LAB_;
                        goto LAB_;
                      }
                    }
                    else {
                      if (cVar8 != '\b') goto LAB_;
LAB_:
                      if (*(int *)(lVar21 + 0x18) != 99) goto LAB_;
                    }
                    uStack_24d4 = *(undefined4 *)(lVar21 + 0x20);
                    uStack_24d0 = *(undefined2 *)(lVar21 + 0x24);
                    *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x1010dd;
                    cVar8 = func_0x(&uStack_24d4,0x12e7230);
                    if (cVar8 == '\0') goto LAB_;
                    *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x1010ed;
                    func_0x(lVar21,&uStack_2510);
                  }
                  *ppbVar30 = pbVar1;
                  *(undefined4 *)(ppbVar30 + 0xc) = (undefined4)uStack_2510;
                  *(int *)((longlong)ppbVar30 + 100) = (int)((ulonglong)uStack_2510 >> 0x20);
                  *(undefined2 *)(ppbVar30 + 0xd) = uStack_2508;
                  *(undefined4 *)((longlong)ppbVar30 + 0x6c) = *(undefined4 *)(lVar21 + 0x20);
                  *(undefined2 *)(ppbVar30 + 0xe) = *(undefined2 *)(lVar21 + 0x24);
                  *(undefined2 *)((longlong)ppbVar30 + 0x72) = 0;
                  uVar3 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x1365b10);
                  uStack_24a8 = CONCAT44(uStack_24a8._4_4_,uVar3);
                  lVar20 = uStack_24a8;
                  uVar29 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x1365b14);
                  *(undefined2 *)(ppbVar30 + 2) = 0xffff;
                  ppbVar30[3] = (byte *)0x0;
                  *(undefined4 *)((longlong)ppbVar30 + 0x14) = 0;
                  *(undefined8 *)((longlong)ppbVar30 + 0x2e) = 0;
                  ppbVar30[7] = (byte *)0x0;
                  ppbVar30[4] = (byte *)0x0;
                  ppbVar30[9] = (byte *)0x0;
                  ppbVar30[10] = (byte *)0x0;
                  *(undefined2 *)(ppbVar30 + 0xb) = 0;
                  if ((**ppbVar30 & 2) != 0) {
                    pbVar1 = pbVar1 + uVar29;
                    if ((*pbVar1 & 1) == 0) {
                      *(undefined2 *)(ppbVar30 + 2) = 0;
                      ppbVar30[3] = pbVar1;
                      *(undefined4 *)((longlong)ppbVar30 + 0x14) = 0;
                      *(undefined4 *)((longlong)ppbVar30 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101359 */
                    /* WARNING: Treating indirect jump as call */
                      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x102c30)
                                - 0x1233300))();
                      return;
                    }
                    *(undefined2 *)(ppbVar30 + 2) = 1;
                    ppbVar30[3] = pbVar1;
                    UNRECOVERED_JUMPTABLE_00 =
                         (code *)((ulonglong)
                                  *(uint *)((ulonglong)
                                            *(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x102c10) *
                                            4 + 0x102c00) - 0x1233300);
                    /* WARNING: Could not emulate address calculation at 0x001011c1 */
                    /* WARNING: Treating indirect jump as call */
                    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
                    return;
                  }
                  if ((**ppbVar30 & 4) != 0) {
                    uStack_24a8._2_2_ = (short)((uint)uVar3 >> 0x10);
                    if (uStack_24a8._2_2_ != 0) {
                      uVar29 = (ulonglong)
                               *(ushort *)(lVar21 + 0x61 + (longlong)uStack_24a8._2_2_ * 2);
                    }
                    psVar22 = (short *)(pbVar1 + uVar29);
                    ppbVar30[9] = (byte *)psVar22;
                    sVar23 = *psVar22;
                    ppbVar30[10] = (byte *)(psVar22 + 1);
                    *(short *)(ppbVar30 + 0xb) = (sVar23 + 1) * 2;
                  }
                  pbVar1 = ppbVar30[1];
                  uStack_24a8 = lVar20;
                  if (pbVar1 != (byte *)0x0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x10141b;
                    func_0x(pbVar1,ppbVar30);
                  }
LAB_:
                  pbStack_2120 = (byte *)((ulonglong)
                                          *(ushort *)(lVar21 + (0xfff - (longlong)(int)sVar26) * 2)
                                         + lVar21);
                  if ((*pbStack_2120 & 1) == 0) {
                    sStack_2128 = 0;
                    uStack_2124 = 0;
                    uStack_2102 = 0;
                    uStack_2100 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101624 */
                    /* WARNING: Treating indirect jump as call */
                    (*(code *)((ulonglong)
                               *(uint *)((longlong)(int)(*pbStack_2120 & 0xe) * 4 + 0x102c9c) -
                              0x1233300))
                              ((longlong)(int)(*pbStack_2120 & 0xe),0x12e7230,pbStack_2120,0x12e7230
                              );
                    return;
                  }
                  sStack_2128 = 1;
                  UNRECOVERED_JUMPTABLE_00 =
                       (code *)((ulonglong)
                                *(uint *)((ulonglong)
                                          *(byte *)((longlong)(int)(*pbStack_2120 & 0x1c) + 0x102c7c
                                                   ) * 4 + 0x102c6c) - 0x1233300);
                    /* WARNING: Could not emulate address calculation at 0x00101477 */
                    /* WARNING: Treating indirect jump as call */
                  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
                  return;
                }
              }
            }
          }
        }
        lVar21 = *(longlong *)(&stack0xfffffffffffffff0 + lVar15);
        if (lVar21 == 0) goto LAB_;
        iVar14 = (int)*(short *)(&stack0xfffffffffffffffc + lVar15);
        if (((*(ushort *)(lVar21 + 0x62) >> 10 & 1) != 0) && (2 < iVar14)) {
          *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x102ac5;
          func_0x(&stack0xfffffffffffffff0 + lVar15);
          goto LAB_;
        }
        plVar19 = *(longlong **)(&stack0xfffffffffffffff0 + lVar15);
        if (((byte)*(undefined2 *)(lVar21 + 0x62) >> 3 & 1) != 0) {
          if (iVar14 == 3) {
            iVar14 = 4;
          }
          else if (iVar14 < 2) goto LAB_;
          if ((((*(uint *)(*(longlong *)(&stack0xfffffffffffffff0 + lVar15) + 100) & 8) != 0) &&
              (lVar21 = *(longlong *)(*(longlong *)(&stack0xfffffffffffffff0 + lVar15) + 0x90),
              lVar21 != 0)) && (*(longlong *)(lVar21 + 0x758) != 0)) {
            uVar4 = *(undefined8 *)(lVar21 + 0x758);
            *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x102b2b;
            func_0x(uVar4,*(undefined8 *)(&stack0xfffffffffffffff0 + lVar15),iVar14)
            ;
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar19 + 100) & 8) != 0)) &&
           ((2 < iVar14 &&
            (((*(uint *)((longlong)plVar19 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar21 = *plVar19, lVar21 != 0)))))) {
          *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x102b6f;
          iVar11 = (*_DAT_)(lVar21,0x2000,2,auStack_23e4);
          if (iVar11 != 0) {
            LOCK();
            *(uint *)((longlong)plVar19 + 100) = *(uint *)((longlong)plVar19 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar19 + 100) = *(uint *)((longlong)plVar19 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x102b91;
        func_0x(plVar19 + 0x13,iVar14);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x102bb0;
          func_0x(plVar19,0,iVar14);
        }
        *(uint *)(&stack0xfffffffffffffffc + lVar15) =
             *(uint *)(&stack0xfffffffffffffffc + lVar15) & 0xffff0000;
        *(undefined8 *)(&stack0xfffffffffffffff0 + lVar15) = 0;
        goto LAB_;
      }
    }
    if (*(longlong *)
         (*(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
           ) + 0x60) == *(longlong *)(lVar21 + 0x2120)) goto LAB_;
    *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x1008ee;
    cVar8 = func_0x(lVar21);
    if (cVar8 != '\0') goto LAB_;
    if (lVar20 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100900;
      lVar20 = func_0x();
    }
    plVar19 = *(longlong **)(&stack0xfffffffffffffff0 + lVar15);
    lVar28 = *plVar19;
    if (*(short *)(lVar28 + 0x24) == 0) {
LAB_:
      uStack_2468 = *(undefined8 *)(lVar28 + 0x28);
      uStack_2460 = *(undefined2 *)(lVar28 + 0x30);
    }
    else {
      cVar8 = *(char *)(lVar28 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(lVar28 + 0x18) != 99) {
LAB_:
          if (cVar8 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar8 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar28 + 0x18) != 99) goto LAB_;
      }
      uStack_24e4 = *(undefined4 *)(lVar28 + 0x20);
      uStack_24e0 = *(undefined2 *)(lVar28 + 0x24);
      *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100950;
      cVar8 = func_0x(&uStack_24e4);
      if (cVar8 == '\0') {
        plVar19 = *(longlong **)(&stack0xfffffffffffffff0 + lVar15);
        goto LAB_;
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100960;
      func_0x(lVar28,&uStack_2468);
      plVar19 = *(longlong **)(&stack0xfffffffffffffff0 + lVar15);
    }
    if (plVar19 != (longlong *)0x0) {
      iVar11 = (int)*(short *)(&stack0xfffffffffffffffc + lVar15);
      if (((*(ushort *)((longlong)plVar19 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
        plVar6 = *(longlong **)(&stack0xfffffffffffffff0 + lVar15);
        if (((byte)*(undefined2 *)((longlong)plVar19 + 0x62) >> 3 & 1) != 0) {
          if (iVar11 == 3) {
            iVar11 = 4;
          }
          else if (iVar11 < 2) goto LAB_;
          if ((((*(uint *)(*(longlong *)(&stack0xfffffffffffffff0 + lVar15) + 100) & 8) != 0) &&
              (lVar28 = *(longlong *)(*(longlong *)(&stack0xfffffffffffffff0 + lVar15) + 0x90),
              lVar28 != 0)) && (*(longlong *)(lVar28 + 0x758) != 0)) {
            uVar4 = *(undefined8 *)(lVar28 + 0x758);
            *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100a14;
            func_0x(uVar4,*(undefined8 *)(&stack0xfffffffffffffff0 + lVar15),iVar11)
            ;
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar6 + 100) & 8) != 0)) &&
           ((2 < iVar11 &&
            (((*(uint *)((longlong)plVar6 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar28 = *plVar6, lVar28 != 0)))))) {
          *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100a59;
          iVar13 = (*_DAT_)(lVar28,0x2000,2,auStack_23f0);
          if (iVar13 != 0) {
            LOCK();
            *(uint *)((longlong)plVar6 + 100) = *(uint *)((longlong)plVar6 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar6 + 100) = *(uint *)((longlong)plVar6 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100a7c;
        func_0x(plVar6 + 0x13,iVar11);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100a9b;
          func_0x(plVar6,0,iVar11);
        }
        *(uint *)(&stack0xfffffffffffffffc + lVar15) =
             *(uint *)(&stack0xfffffffffffffffc + lVar15) & 0xffff0000;
        *(undefined8 *)(&stack0xfffffffffffffff0 + lVar15) = 0;
        param_2 = *(uint **)((longlong)apuStackX_10 + lVar15);
      }
      else {
        *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x1009ad;
        func_0x(&stack0xfffffffffffffff0 + lVar15);
      }
    }
    uStack_2430 = uStack_2468;
    uStack_2428 = uStack_2460;
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar15) = 0;
    uVar4 = *(undefined8 *)(lVar21 + 0x728);
    *(undefined8 *)((longlong)&uStack_48 + lVar15) = 0x100aec;
    func_0x(uVar4,&uStack_2430,4);
  } while( true );
}

