
/* WARNING: Removing unreachable block (ram,0x00104a14) */
/* WARNING: Removing unreachable block (ram,0x00104a1e) */
/* WARNING: Removing unreachable block (ram,0x00104a2c) */
/* WARNING: Removing unreachable block (ram,0x00104a38) */
/* WARNING: Removing unreachable block (ram,0x00104a3c) */
/* WARNING: Removing unreachable block (ram,0x00103410) */
/* WARNING: Removing unreachable block (ram,0x00103423) */
/* WARNING: Removing unreachable block (ram,0x00103438) */
/* WARNING: Removing unreachable block (ram,0x0010344f) */
/* WARNING: Removing unreachable block (ram,0x0010396e) */
/* WARNING: Removing unreachable block (ram,0x00103459) */
/* WARNING: Removing unreachable block (ram,0x00103478) */
/* WARNING: Removing unreachable block (ram,0x00103488) */
/* WARNING: Removing unreachable block (ram,0x00103492) */
/* WARNING: Removing unreachable block (ram,0x0010349b) */
/* WARNING: Removing unreachable block (ram,0x001034c5) */
/* WARNING: Removing unreachable block (ram,0x001034ab) */
/* WARNING: Removing unreachable block (ram,0x001034e9) */
/* WARNING: Removing unreachable block (ram,0x00103502) */
/* WARNING: Removing unreachable block (ram,0x00103523) */
/* WARNING: Removing unreachable block (ram,0x00103533) */
/* WARNING: Removing unreachable block (ram,0x0010353d) */
/* WARNING: Removing unreachable block (ram,0x00103546) */
/* WARNING: Removing unreachable block (ram,0x00103570) */
/* WARNING: Removing unreachable block (ram,0x00103556) */
/* WARNING: Removing unreachable block (ram,0x00103594) */
/* WARNING: Removing unreachable block (ram,0x001035b2) */
/* WARNING: Removing unreachable block (ram,0x001035cf) */
/* WARNING: Removing unreachable block (ram,0x001035df) */
/* WARNING: Removing unreachable block (ram,0x001035e9) */
/* WARNING: Removing unreachable block (ram,0x001035f2) */
/* WARNING: Removing unreachable block (ram,0x0010361c) */
/* WARNING: Removing unreachable block (ram,0x00103602) */
/* WARNING: Removing unreachable block (ram,0x00103640) */
/* WARNING: Removing unreachable block (ram,0x00103663) */
/* WARNING: Removing unreachable block (ram,0x0010366f) */
/* WARNING: Removing unreachable block (ram,0x00103680) */
/* WARNING: Removing unreachable block (ram,0x0010368e) */
/* WARNING: Removing unreachable block (ram,0x00103697) */
/* WARNING: Removing unreachable block (ram,0x001036a7) */
/* WARNING: Removing unreachable block (ram,0x001036b1) */
/* WARNING: Removing unreachable block (ram,0x001036ba) */
/* WARNING: Removing unreachable block (ram,0x001036e4) */
/* WARNING: Removing unreachable block (ram,0x001036ca) */
/* WARNING: Removing unreachable block (ram,0x00103706) */
/* WARNING: Removing unreachable block (ram,0x00103724) */
/* WARNING: Removing unreachable block (ram,0x0010373a) */
/* WARNING: Removing unreachable block (ram,0x00103746) */
/* WARNING: Removing unreachable block (ram,0x00103750) */
/* WARNING: Removing unreachable block (ram,0x00103765) */
/* WARNING: Removing unreachable block (ram,0x00103777) */
/* WARNING: Removing unreachable block (ram,0x00103772) */
/* WARNING: Removing unreachable block (ram,0x00103783) */
/* WARNING: Removing unreachable block (ram,0x00103793) */
/* WARNING: Removing unreachable block (ram,0x00103797) */
/* WARNING: Removing unreachable block (ram,0x0010379c) */
/* WARNING: Removing unreachable block (ram,0x001037bd) */
/* WARNING: Removing unreachable block (ram,0x001037c8) */
/* WARNING: Removing unreachable block (ram,0x001037d1) */
/* WARNING: Removing unreachable block (ram,0x00103806) */
/* WARNING: Removing unreachable block (ram,0x00103849) */
/* WARNING: Removing unreachable block (ram,0x0010383a) */
/* WARNING: Removing unreachable block (ram,0x00103851) */
/* WARNING: Removing unreachable block (ram,0x0010389b) */
/* WARNING: Removing unreachable block (ram,0x001038bd) */
/* WARNING: Removing unreachable block (ram,0x001038d7) */
/* WARNING: Removing unreachable block (ram,0x001038fd) */
/* WARNING: Removing unreachable block (ram,0x00103903) */
/* WARNING: Removing unreachable block (ram,0x0010391d) */
/* WARNING: Removing unreachable block (ram,0x00103930) */
/* WARNING: Removing unreachable block (ram,0x00103951) */
/* WARNING: Removing unreachable block (ram,0x00103967) */
/* WARNING: Removing unreachable block (ram,0x001037de) */
/* WARNING: Removing unreachable block (ram,0x001037ec) */
/* WARNING: Removing unreachable block (ram,0x0010397d) */
/* WARNING: Removing unreachable block (ram,0x001039c4) */
/* WARNING: Removing unreachable block (ram,0x00103983) */
/* WARNING: Removing unreachable block (ram,0x001039c8) */
/* WARNING: Removing unreachable block (ram,0x001039d6) */
/* WARNING: Removing unreachable block (ram,0x001039e5) */
/* WARNING: Removing unreachable block (ram,0x001039f5) */
/* WARNING: Removing unreachable block (ram,0x001039ff) */
/* WARNING: Removing unreachable block (ram,0x00103a08) */
/* WARNING: Removing unreachable block (ram,0x00103a32) */
/* WARNING: Removing unreachable block (ram,0x00103a18) */
/* WARNING: Removing unreachable block (ram,0x00103a56) */
/* WARNING: Removing unreachable block (ram,0x00103a6f) */
/* WARNING: Removing unreachable block (ram,0x00103a7e) */
/* WARNING: Removing unreachable block (ram,0x00103a8e) */
/* WARNING: Removing unreachable block (ram,0x00103a98) */
/* WARNING: Removing unreachable block (ram,0x00103aa1) */
/* WARNING: Removing unreachable block (ram,0x00103acb) */
/* WARNING: Removing unreachable block (ram,0x00103ab1) */
/* WARNING: Removing unreachable block (ram,0x00103aef) */
/* WARNING: Removing unreachable block (ram,0x00103801) */
/* WARNING: Removing unreachable block (ram,0x00103b08) */
/* WARNING: Removing unreachable block (ram,0x00103b0e) */
/* WARNING: Removing unreachable block (ram,0x00103b16) */
/* WARNING: Removing unreachable block (ram,0x00103b1a) */
/* WARNING: Removing unreachable block (ram,0x00103b1e) */
/* WARNING: Removing unreachable block (ram,0x00103b26) */
/* WARNING: Removing unreachable block (ram,0x00103b2a) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong *
FUN_(longlong **param_1,longlong param_2,longlong *param_3,longlong param_4,uint *param_5,
            uint param_6,int param_7,undefined8 param_8,short **param_9,uint *param_10,int param_11,
            longlong param_12,undefined4 *param_13,int *param_14)

{
  ushort *puVar1;
  undefined2 uVar2;
  byte *pbVar3;
  ushort *puVar4;
  bool bVar5;
  short *psVar6;
  char cVar7;
  byte bVar8;
  short sVar9;
  ushort uVar10;
  ushort uVar11;
  int iVar12;
  longlong lVar13;
  longlong *plVar14;
  longlong *plVar15;
  undefined8 uVar16;
  longlong lVar17;
  code *UNRECOVERED_JUMPTABLE_00;
  uint uVar18;
  uint uVar19;
  ulonglong uVar20;
  uint uVar21;
  undefined4 uVar22;
  longlong lVar23;
  ulonglong uVar24;
  short *psVar25;
  ulonglong uVar26;
  undefined8 *puVar27;
  ushort *puVar28;
  undefined8 *puVar29;
  uint uVar30;
  longlong unaff_GS_OFFSET;
  undefined auStack_a0e [2];
  int iStack_a0c;
  byte *pbStack_a08;
  undefined8 uStack_a00;
  undefined8 uStack_9f2;
  undefined2 uStack_9e8;
  undefined2 uStack_9e6;
  undefined2 uStack_9e4;
  undefined2 uStack_9e2;
  undefined4 uStack_9e0;
  undefined4 uStack_9d8;
  short *psStack_9d0;
  undefined4 uStack_9c8;
  short sStack_9c4;
  int iStack_9c0;
  undefined4 uStack_9bc;
  undefined4 uStack_9b8;
  int iStack_9b4;
  undefined8 *puStack_9b0;
  undefined8 uStack_998;
  longlong *plStack_990;
  int iStack_988;
  uint *puStack_980;
  longlong lStack_978;
  longlong lStack_970;
  undefined4 uStack_968;
  undefined2 uStack_964;
  undefined2 uStack_962;
  undefined2 uStack_960;
  undefined4 uStack_958;
  uint uStack_954;
  uint uStack_950;
  uint uStack_94c;
  undefined auStack_940 [16];
  undefined auStack_930 [8];
  undefined auStack_928 [8];
  undefined auStack_920 [24];
  undefined8 auStack_908 [4];
  undefined8 uStack_8e8;
  ushort auStack_8d8 [4];
  undefined8 auStack_8d0 [31];
  undefined4 uStack_7d8;
  longlong lStack_7d0;
  undefined2 uStack_7c8;
  undefined8 uStack_7c0;
  undefined auStack_7b8 [8];
  undefined4 uStack_7b0;
  undefined4 uStack_7a8;
  undefined4 **ppuStack_7a0;
  undefined *puStack_798;
  undefined8 uStack_790;
  undefined4 *puStack_788;
  undefined8 uStack_780;
  undefined auStack_778 [528];
  undefined8 uStack_568;
  undefined8 uStack_560;
  undefined4 uStack_558;
  uint uStack_554;
  undefined2 uStack_550;
  undefined4 uStack_54e;
  longlong lStack_54a;
  undefined8 uStack_542;
  undefined auStack_538 [8];
  undefined4 uStack_530;
  undefined4 uStack_528;
  undefined4 **ppuStack_520;
  undefined *puStack_518;
  undefined8 uStack_510;
  undefined4 *puStack_508;
  undefined8 uStack_500;
  undefined auStack_4f8 [528];
  undefined8 uStack_2e8;
  undefined8 uStack_2e0;
  undefined4 uStack_2d8;
  uint uStack_2d4;
  undefined2 uStack_2d0;
  undefined4 uStack_2ce;
  longlong lStack_2ca;
  undefined8 uStack_2c2;
  undefined auStack_2b8 [8];
  undefined4 uStack_2b0;
  undefined4 uStack_2a8;
  uint **ppuStack_2a0;
  undefined *puStack_298;
  undefined8 uStack_290;
  uint *puStack_288;
  undefined8 uStack_280;
  undefined auStack_278 [528];
  undefined8 uStack_68;
  undefined8 uStack_60;
  uint uStack_58;
  undefined2 uStack_54;
  undefined4 uStack_52;
  longlong lStack_4e;
  char cStack_46;
  
  uStack_8e8 = 0xfffffffffffffffe;
  plVar15 = (longlong *)0x0;
  auStack_8d8[0] = 0;
  uStack_7d8 = 0;
  uStack_7c8 = 0;
  lStack_7d0 = 0;
  uStack_7c0 = 0;
  uVar21 = (uint)(*(char *)(param_4 + 1) == '\x01');
  if (param_7 == 0) {
    uVar21 = uVar21 | 0x400000;
  }
  else if ((*(uint *)((longlong)*param_1 + 100) >> 0x13 & 1) != 0) {
    func_0x(0x1922d30,0x1922ce0,*(undefined2 *)(param_4 + 0x24),
                    *(undefined4 *)(param_4 + 0x20));
    plVar14 = (longlong *)0x0;
    goto LAB_;
  }
  lVar17 = (ulonglong)*(uint6 *)(param_2 + 0x14) << 0x10;
  uVar2 = *(undefined2 *)(*(longlong *)(param_2 + 0x20) + 0x6b8);
  lStack_970 = -1;
  uStack_962 = 0;
  if ((_DAT_ & 0x1000) == 0) {
    plStack_990 = &lStack_970;
    puStack_9b0 = &uStack_998;
  }
  else {
    uStack_968 = *(undefined4 *)(*param_1 + 0xe);
    uStack_964 = *(undefined2 *)((longlong)*param_1 + 0x74);
    plStack_990 = &lStack_970;
    puStack_9b0 = &uStack_998;
    uStack_998 = _DAT_;
    lStack_970 = lVar17;
    uStack_960 = uVar2;
    if (*_DAT_ != 0) {
      (*_DAT_)(auStack_908);
      uStack_998 = auStack_908[0];
    }
    uStack_7b0 = 0x10000;
    uStack_7a8 = 0;
    ppuStack_7a0 = &puStack_788;
    puStack_798 = auStack_778;
    uStack_568 = 0;
    uStack_790 = 0;
    uStack_560 = 0;
    puStack_788 = &uStack_558;
    uStack_780 = 0x1e;
    uStack_558 = 0;
    uStack_542 = 0;
    lStack_54a = *plStack_990;
    uStack_550 = *(undefined2 *)((longlong)plStack_990 + 0xc);
    uStack_54e = *(undefined4 *)(plStack_990 + 1);
    uStack_554 = (uint)*(ushort *)(plStack_990 + 2);
    func_0x(auStack_7b8);
  }
  iVar12 = func_0x(0,param_1,param_2,param_3,auStack_8d8,uVar21);
  if ((_DAT_ >> 0xc & 1) != 0) {
    uStack_530 = 0x10000;
    uStack_528 = 0;
    ppuStack_520 = &puStack_508;
    puStack_518 = auStack_4f8;
    uStack_2e8 = 0;
    uStack_510 = 0;
    uStack_2e0 = 0;
    puStack_508 = &uStack_2d8;
    uStack_500 = 0x1e;
    uStack_2d8 = 1;
    uStack_2c2 = func_0x(&uStack_998);
    lStack_2ca = *plStack_990;
    uStack_2d0 = *(undefined2 *)((longlong)plStack_990 + 0xc);
    uStack_2ce = *(undefined4 *)(plStack_990 + 1);
    uStack_2d4 = (uint)*(ushort *)(plStack_990 + 2);
    func_0x(auStack_538);
  }
  if (iVar12 != 0) {
    plVar14 = plVar15;
    if ((_DAT_ >> 0xb & 1) != 0) {
      uStack_2b0 = 0x10000;
      uStack_2a8 = 0;
      ppuStack_2a0 = &puStack_288;
      puStack_298 = auStack_278;
      uStack_68 = 0;
      uStack_290 = 0;
      uStack_60 = 0;
      puStack_288 = &uStack_58;
      uStack_280 = 0x13;
      uStack_54 = *(undefined2 *)((longlong)*param_1 + 0x74);
      uStack_52 = *(undefined4 *)(*param_1 + 0xe);
      uStack_58 = (uint)*(ushort *)(*(longlong *)(param_2 + 0x20) + 0x6b8);
      lStack_4e = (ulonglong)*(uint6 *)(param_2 + 0x14) << 0x10;
      cStack_46 = (char)iVar12;
      func_0x(auStack_2b8);
      plVar14 = (longlong *)0x0;
    }
    goto LAB_;
  }
  if (*_DAT_ != (char)iVar12) {
    plVar14 = plVar15;
    if (_DAT_ != 0) {
      plVar14 = (longlong *)(_DAT_ + 0x6800);
    }
    if ((plVar14 != (longlong *)0x0) && (*plVar14 != 0)) {
      LOCK();
      plVar14 = (longlong *)(*plVar14 + 0x150);
      *plVar14 = *plVar14 + 1;
      UNLOCK();
    }
  }
  lVar17 = *(longlong *)(*(longlong *)(param_2 + 8) + 0x488);
  if (((lVar17 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
    if (*(longlong *)(lVar17 + 0x20) != 0) {
      lVar23 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar13 = *(longlong *)(lVar23 + 0x100);
      if (lVar13 == 0) {
        (*_DAT_)(0);
        lVar13 = *(longlong *)(lVar23 + 0x100);
      }
      plVar14 = plVar15;
      if (*(longlong *)(lVar13 + 0x260) != 0) {
        plVar14 = (longlong *)(ulonglong)*(uint *)(*(longlong *)(lVar13 + 0x260) + 0xe68);
      }
      if ((uint)plVar14 < *(uint *)(_DAT_ + 8)) {
        lVar17 = *(longlong *)(*(longlong *)(lVar17 + 0x20) + (longlong)plVar14 * 8);
        *(longlong *)(lVar17 + 0x128) = *(longlong *)(lVar17 + 0x128) + 1;
        goto LAB_;
      }
    }
    LOCK();
    plVar14 = (longlong *)(*(longlong *)(lVar17 + 0x18) + 0x128);
    *plVar14 = *plVar14 + 1;
    UNLOCK();
  }
LAB_:
  *param_13 = 1;
  if (param_9 == (short **)0x0) {
    psStack_9d0 = (short *)0x0;
  }
  else {
    if (param_10 == (uint *)0x0) {
      puVar29 = (undefined8 *)param_9[1];
      puVar29[1] = 0;
      *puVar29 = 0xffff;
      puVar29[3] = 0;
      puVar29[4] = 0;
      puVar29[2] = 0;
      *(undefined4 *)(puVar29 + 6) = 0;
      puVar29[5] = 0;
      puVar29 = (undefined8 *)param_9[4];
      *puVar29 = 0;
      puVar29[0xc] = 0;
      *(undefined2 *)(puVar29 + 0xd) = 0;
      *(undefined8 *)((longlong)puVar29 + 0x6c) = 1;
      puVar29 = (undefined8 *)puVar29[1];
      if (puVar29 != (undefined8 *)0x0) {
        puVar27 = (undefined8 *)puVar29[1];
        if (puVar27 != (undefined8 *)0x0) {
          *puVar27 = 0;
          *(undefined4 *)(puVar27 + 0x481) = 0;
        }
        puVar29[3] = 0;
        *(undefined2 *)(puVar29 + 4) = 0;
        *puVar29 = 0;
        *(undefined4 *)(puVar29 + 0x14b) = 0;
      }
      if (*(char *)(param_4 + 2) < '\0') {
        func_0x(param_9,param_4);
        goto LAB_;
      }
    }
    else {
LAB_:
      if (*(char *)(param_4 + 2) < '\0') {
        psStack_9d0 = param_9[1];
        goto LAB_;
      }
    }
    psStack_9d0 = *param_9;
  }
LAB_:
  uStack_958 = *param_5;
  uStack_954 = param_5[1];
  uStack_950 = param_5[2];
  uStack_94c = param_5[3];
  uStack_9d8 = 0;
  uStack_9c8 = 0;
  uStack_9bc = 0;
  puStack_980 = (uint *)0x0;
  iStack_9b4 = 0;
  pbStack_a08 = (byte *)0x0;
  iStack_a0c = 0;
  uStack_9f2 = 0;
  uStack_9e8 = 0;
  uStack_9e6 = 0;
  uStack_9e4 = 0;
  uStack_9e2 = 0;
  uStack_a00 = 0;
  lStack_978 = **param_1;
  bVar5 = false;
  plVar14 = param_3;
  if ((*(byte *)(param_3 + 0x43) & 4) != 0) {
    plVar14 = (longlong *)(**(code **)(*param_3 + 0x1e8))(param_3);
  }
  iStack_988 = *(int *)(plVar14 + 5);
  sStack_9c4 = *(short *)((longlong)plVar14 + 0x2c);
  iStack_9c0 = 0;
  uStack_9b8 = 9;
  if (param_6 < 6) {
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)*(uint *)((longlong)(int)param_6 * 4 + 0x1060c8) - 0xe84de0);
                    /* WARNING: Could not emulate address calculation at 0x0010056c */
                    /* WARNING: Treating indirect jump as call */
    plVar15 = (longlong *)(*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return plVar15;
  }
  (*_DAT_)(1,0x1a9bae0,0x1ac93f8,0x49f,0x1695750);
  if ((((byte)*(undefined4 *)(param_3 + 0x43) & 5) == 1) && ((*(byte *)(param_3 + 0x5b) & 2) != 0))
  {
LAB_:
    if (param_6 < 6) {
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)*(uint *)((longlong)(int)param_6 * 4 + 0x10614c) - 0xe84de0);
                    /* WARNING: Could not emulate address calculation at 0x00105130 */
                    /* WARNING: Treating indirect jump as call */
      plVar15 = (longlong *)(*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return plVar15;
    }
    (*_DAT_)(1,0x1a9bae0,0x1ac93f8,0x4be,0x1695750);
LAB_:
    uStack_9e0._0_2_ = 0;
  }
  else {
    cVar7 = (**(code **)*param_3)(param_3);
    uVar21 = uStack_958;
    if (cVar7 != '\0') goto LAB_;
    lVar17 = param_3[0x1a];
    if ((uStack_958 & 1) == 0) {
      cVar7 = (**(code **)*param_3)(param_3);
      if (cVar7 == '\0') {
        cVar7 = (**(code **)(*param_3 + 0x88))(param_3);
        if (cVar7 != '\0') {
          if (uStack_958._1_1_ != '\0') goto LAB_;
          if (lVar17 == 0) {
            cVar7 = (**(code **)(*param_3 + 0x18))(param_3);
            if (cVar7 == '\0') goto LAB_;
          }
          if ((*(byte *)(param_3 + 0x4a) & 4) == 0) {
            if ((*(byte *)(param_3 + 0x4a) & 0x5a) == 0) {
              if ((*(byte *)(param_3 + 0x43) & 1) != 0) {
                if (((param_3[0x1a] == 0) &&
                    (cVar7 = (**(code **)(*param_3 + 0x88))(param_3), cVar7 != '\0')) &&
                   (cVar7 = (**(code **)(*param_3 + 0x18))(param_3), cVar7 == '\0')) {
                  *(byte *)(param_3 + 0x4a) = *(byte *)(param_3 + 0x4a) | 4;
                }
                else {
                  iVar12 = func_0x(param_3);
                  if (iVar12 == 0) {
                    (**(code **)(*param_3 + 0x270))(param_3);
                  }
                  if ((*(byte *)(param_3 + 0x43) & 4) == 0) {
                    if (((((*(byte *)(param_3 + 0x4a) & 0x52) == 2) &&
                         (cVar7 = func_0x(param_3[0x1a]), cVar7 != '\0')) &&
                        (*(char *)(param_3[0x1a] + 0x130) == '\0')) &&
                       (*(undefined *)(param_3[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                      plVar14 = plVar15;
                      if (_DAT_ != 0) {
                        plVar14 = (longlong *)(_DAT_ + 0xe000);
                      }
                      if ((plVar14 != (longlong *)0x0) && (*plVar14 != 0)) {
                        LOCK();
                        plVar14 = (longlong *)(*plVar14 + 0x10);
                        *plVar14 = *plVar14 + 1;
                        UNLOCK();
                      }
                    }
                    uVar19 = (uint)((*(byte *)(param_3 + 0x4a) & 0x5a) != 0);
                  }
                  else {
                    uVar16 = (**(code **)(*param_3 + 0x1e8))(param_3);
                    uVar19 = func_0x(uVar16);
                  }
                  if (uVar19 != 0) goto LAB_;
                }
              }
            }
            else {
LAB_:
              if (((*(byte *)(param_3 + 0x4a) & 0x40) != 0) && (uStack_958._2_1_ != '\0'))
              goto LAB_;
            }
          }
        }
        lVar13 = CONCAT44(uStack_94c,uStack_950);
        if ((uVar21 & 0x1c) == 0) {
          if (lVar13 != 0) {
            iVar12 = func_0x(lVar13);
            if (((iVar12 != 0) &&
                (iVar12 = *(int *)(*(longlong *)(lVar13 + 8) + 0x100), iVar12 != 0)) &&
               (1 < iVar12 - 3U)) {
              (*_DAT_)(1,0x1ac91f0,0x1ac9240,0x116,0);
            }
            iVar12 = func_0x(lVar13);
            if (((iVar12 != 0) && ((*(byte *)(*(longlong *)(lVar13 + 8) + 0x109) & 1) == 0)) &&
               ((iVar12 = *(int *)(*(longlong *)(lVar13 + 8) + 0x100), iVar12 != 0 &&
                (1 < iVar12 - 3U)))) {
              (*_DAT_)(1,0x1ac9270,0x1ac9240,0x119,0);
            }
          }
          if ((lVar17 != 0) && ((0 < *(int *)(lVar17 + 0x78) || (0 < *(int *)(lVar17 + 0x74))))) {
LAB_:
            if (lVar13 != 0) {
              iVar12 = func_0x(lVar13);
              if (((iVar12 != 0) &&
                  (iVar12 = *(int *)(*(longlong *)(lVar13 + 8) + 0x100), iVar12 != 0)) &&
                 (1 < iVar12 - 3U)) {
                (*_DAT_)(1,0x1ac91f0,0x1ac9240,0x116,0);
              }
              iVar12 = func_0x(lVar13);
              if ((((iVar12 != 0) && ((*(byte *)(*(longlong *)(lVar13 + 8) + 0x109) & 1) == 0)) &&
                  (iVar12 = *(int *)(*(longlong *)(lVar13 + 8) + 0x100), iVar12 != 0)) &&
                 (1 < iVar12 - 3U)) {
                (*_DAT_)(1,0x1ac9270,0x1ac9240,0x119,0);
              }
            }
            if ((*(int *)(lVar17 + 0x78) < 1) && (*(int *)(lVar17 + 0x74) < 1)) {
              if ((*(byte *)(param_3 + 0x4a) & 4) == 0) {
                if ((*(byte *)(param_3 + 0x4a) & 0x5a) == 0) {
                  if ((*(byte *)(param_3 + 0x43) & 1) != 0) {
                    if (((param_3[0x1a] == 0) &&
                        (cVar7 = (**(code **)(*param_3 + 0x88))(param_3), cVar7 != '\0')) &&
                       (cVar7 = (**(code **)(*param_3 + 0x18))(param_3), cVar7 == '\0')) {
                      *(byte *)(param_3 + 0x4a) = *(byte *)(param_3 + 0x4a) | 4;
                    }
                    else {
                      iVar12 = func_0x(param_3);
                      if (iVar12 == 0) {
                        (**(code **)(*param_3 + 0x270))(param_3);
                      }
                      if ((*(byte *)(param_3 + 0x43) & 4) == 0) {
                        if (((((*(byte *)(param_3 + 0x4a) & 0x52) == 2) &&
                             (cVar7 = func_0x(param_3[0x1a]), cVar7 != '\0')) &&
                            (*(char *)(param_3[0x1a] + 0x130) == '\0')) &&
                           (*(undefined *)(param_3[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                          plVar14 = plVar15;
                          if (_DAT_ != 0) {
                            plVar14 = (longlong *)(_DAT_ + 0xe000);
                          }
                          if ((plVar14 != (longlong *)0x0) && (*plVar14 != 0)) {
                            LOCK();
                            plVar14 = (longlong *)(*plVar14 + 0x10);
                            *plVar14 = *plVar14 + 1;
                            UNLOCK();
                          }
                        }
                        uVar19 = (uint)((*(byte *)(param_3 + 0x4a) & 0x5a) != 0);
                      }
                      else {
                        uVar16 = (**(code **)(*param_3 + 0x1e8))(param_3);
                        uVar19 = func_0x(uVar16);
                      }
                      if (uVar19 != 0) goto LAB_;
                    }
                  }
                }
                else {
LAB_:
                  if ((*(byte *)(param_3 + 0x4a) & 0x10) != 0) goto LAB_;
                }
              }
              if ((*(byte *)(param_3 + 0x4a) & 4) == 0) {
                if ((*(byte *)(param_3 + 0x4a) & 0x5a) == 0) {
                  if ((*(byte *)(param_3 + 0x43) & 1) != 0) {
                    if (((param_3[0x1a] == 0) &&
                        (cVar7 = (**(code **)(*param_3 + 0x88))(param_3), cVar7 != '\0')) &&
                       (cVar7 = (**(code **)(*param_3 + 0x18))(param_3), cVar7 == '\0')) {
                      *(byte *)(param_3 + 0x4a) = *(byte *)(param_3 + 0x4a) | 4;
                    }
                    else {
                      iVar12 = func_0x(param_3);
                      if (iVar12 == 0) {
                        (**(code **)(*param_3 + 0x270))(param_3);
                      }
                      if ((*(byte *)(param_3 + 0x43) & 4) == 0) {
                        if (((((*(byte *)(param_3 + 0x4a) & 0x52) == 2) &&
                             (cVar7 = func_0x(param_3[0x1a]), cVar7 != '\0')) &&
                            (*(char *)(param_3[0x1a] + 0x130) == '\0')) &&
                           (*(undefined *)(param_3[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                          plVar14 = plVar15;
                          if (_DAT_ != 0) {
                            plVar14 = (longlong *)(_DAT_ + 0xe000);
                          }
                          if ((plVar14 != (longlong *)0x0) && (*plVar14 != 0)) {
                            LOCK();
                            plVar14 = (longlong *)(*plVar14 + 0x10);
                            *plVar14 = *plVar14 + 1;
                            UNLOCK();
                          }
                        }
                        uVar19 = (uint)((*(byte *)(param_3 + 0x4a) & 0x5a) != 0);
                      }
                      else {
                        uVar16 = (**(code **)(*param_3 + 0x1e8))(param_3);
                        uVar19 = func_0x(uVar16);
                      }
                      if (uVar19 != 0) goto LAB_;
                    }
                  }
                }
                else {
LAB_:
                  if ((*(byte *)(param_3 + 0x4a) & 0x40) != 0) goto LAB_;
                }
              }
            }
            goto LAB_;
          }
          if ((*(byte *)(param_3 + 0x4a) & 4) == 0) {
            if ((*(byte *)(param_3 + 0x4a) & 0x5a) != 0) goto LAB_;
            if ((*(byte *)(param_3 + 0x43) & 1) != 0) {
              if ((param_3[0x1a] == 0) &&
                 (cVar7 = (**(code **)(*param_3 + 0x88))(param_3), cVar7 != '\0')) {
                cVar7 = (**(code **)(*param_3 + 0x18))(param_3);
                if (cVar7 == '\0') {
                  *(byte *)(param_3 + 0x4a) = *(byte *)(param_3 + 0x4a) | 4;
                  goto LAB_;
                }
              }
              iVar12 = func_0x(param_3);
              if (iVar12 == 0) {
                (**(code **)(*param_3 + 0x270))(param_3);
              }
              if ((*(byte *)(param_3 + 0x43) & 4) == 0) {
                if (((((*(byte *)(param_3 + 0x4a) & 0x52) == 2) &&
                     (cVar7 = func_0x(param_3[0x1a]), cVar7 != '\0')) &&
                    (*(char *)(param_3[0x1a] + 0x130) == '\0')) &&
                   (*(undefined *)(param_3[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                  plVar14 = plVar15;
                  if (_DAT_ != 0) {
                    plVar14 = (longlong *)(_DAT_ + 0xe000);
                  }
                  if ((plVar14 != (longlong *)0x0) && (*plVar14 != 0)) {
                    LOCK();
                    plVar14 = (longlong *)(*plVar14 + 0x10);
                    *plVar14 = *plVar14 + 1;
                    UNLOCK();
                  }
                }
                uVar19 = (uint)((*(byte *)(param_3 + 0x4a) & 0x5a) != 0);
              }
              else {
                uVar16 = (**(code **)(*param_3 + 0x1e8))(param_3);
                uVar19 = func_0x(uVar16);
              }
              if (uVar19 != 0) goto LAB_;
            }
          }
        }
        else {
LAB_:
          if (lVar17 != 0) {
            if ((uVar21 & 0x1c) == 0) goto LAB_;
LAB_:
            func_0x(lVar17,0);
          }
LAB_:
          iVar12 = func_0x(param_3);
          if (iVar12 == 0) {
            (**(code **)(*param_3 + 0x270))(param_3);
          }
          lVar17 = param_3[0x1a];
          if ((uVar21 & 0x24) == 0) {
            if ((*(byte *)(param_3 + 0x4a) & 4) == 0) {
              if ((*(byte *)(param_3 + 0x4a) & 0x5a) != 0) goto LAB_;
              if ((*(byte *)(param_3 + 0x43) & 1) != 0) {
                if ((lVar17 == 0) &&
                   (cVar7 = (**(code **)(*param_3 + 0x88))(param_3), cVar7 != '\0')) {
                  cVar7 = (**(code **)(*param_3 + 0x18))(param_3);
                  if (cVar7 == '\0') {
                    *(byte *)(param_3 + 0x4a) = *(byte *)(param_3 + 0x4a) | 4;
                    goto LAB_;
                  }
                }
                iVar12 = func_0x(param_3);
                if (iVar12 == 0) {
                  (**(code **)(*param_3 + 0x270))(param_3);
                }
                if ((*(byte *)(param_3 + 0x43) & 4) == 0) {
                  if (((((*(byte *)(param_3 + 0x4a) & 0x52) == 2) &&
                       (cVar7 = func_0x(param_3[0x1a]), cVar7 != '\0')) &&
                      (*(char *)(param_3[0x1a] + 0x130) == '\0')) &&
                     (*(undefined *)(param_3[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                    plVar14 = plVar15;
                    if (_DAT_ != 0) {
                      plVar14 = (longlong *)(_DAT_ + 0xe000);
                    }
                    if ((plVar14 != (longlong *)0x0) && (*plVar14 != 0)) {
                      LOCK();
                      plVar14 = (longlong *)(*plVar14 + 0x10);
                      *plVar14 = *plVar14 + 1;
                      UNLOCK();
                    }
                  }
                  uVar21 = (uint)((*(byte *)(param_3 + 0x4a) & 0x5a) != 0);
                }
                else {
                  uVar16 = (**(code **)(*param_3 + 0x1e8))(param_3);
                  uVar21 = func_0x(uVar16);
                }
                if (uVar21 != 0) goto LAB_;
              }
            }
            if ((lVar17 == 0) || (*(int *)(lVar17 + 0x74) < 1)) goto LAB_;
          }
LAB_:
          uVar22 = 0xe;
          uStack_9d8 = 0xe;
          lVar17 = param_3[0x1a];
          if (param_6 == 0) {
            cVar7 = (**(code **)(*param_3 + 0x88))(param_3);
            psVar6 = psStack_9d0;
            if (((cVar7 == '\0') && (lVar17 != 0)) &&
               ((0 < *(int *)(lVar17 + 0x78) || (0 < *(int *)(lVar17 + 0x74))))) {
              puVar1 = (ushort *)(psStack_9d0 + 1);
              if (*psStack_9d0 == 0) {
                uVar21 = *(uint *)(psStack_9d0 + 2);
                if (uVar21 == 0) {
                  *puVar1 = 0;
                  uVar21 = *(uint *)(psStack_9d0 + 8);
                  uVar20 = (ulonglong)uVar21;
                  *(uint *)(psStack_9d0 + 10) = uVar21;
                  pbVar3 = *(byte **)(psStack_9d0 + 4);
                  bVar8 = *pbVar3;
                  if ((bVar8 & 0x10) != 0) {
                    uVar21 = uVar21 + 2 + (*(ushort *)(pbVar3 + uVar20) + 7 >> 3);
                    uVar20 = (ulonglong)uVar21;
                    *(uint *)(psStack_9d0 + 10) = uVar21;
                    bVar8 = *pbVar3;
                  }
                  if ((bVar8 & 0x20) == 0) {
                    *(int *)(psStack_9d0 + 2) = (int)uVar20;
                    psStack_9d0[0xe] = 0;
                    *(uint *)(psStack_9d0 + 0xc) = uVar21;
                  }
                  else {
                    puVar29 = (undefined8 *)(pbVar3 + uVar20);
                    uVar11 = *(ushort *)puVar29;
                    psStack_9d0[0xe] = uVar11;
                    puStack_9b0 = puVar29;
                    if (uVar11 == 0) {
                      cVar7 = func_0x(0x202a7e0);
                      if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                         (*(char *)(lVar17 + 0x499) != '\0')) {
                        cVar7 = func_0x(0x202a7e0);
                        if (cVar7 == '\0') {
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x80f,0);
                        }
                      }
                      func_0x(*(undefined8 *)(psVar6 + 4),3);
                      uVar11 = psVar6[0xe];
                      uVar21 = *(uint *)(psVar6 + 10);
                    }
                    uVar21 = uVar21 + (uVar11 + 1) * 2;
                    *(uint *)(psVar6 + 0xc) = uVar21;
                    if (0x1f9e < uVar21) {
                      cVar7 = func_0x(0x202a7e0);
                      if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                         (*(char *)(lVar17 + 0x499) != '\0')) {
                        cVar7 = func_0x(0x202a7e0);
                        if (cVar7 == '\0') {
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x816,0);
                        }
                      }
                      func_0x(*(undefined8 *)(psVar6 + 4),4);
                      uVar11 = psVar6[0xe];
                      uVar21 = *(uint *)(psVar6 + 0xc);
                    }
                    uVar20 = (ulonglong)uVar11;
                    uVar19 = *(ushort *)((longlong)puVar29 + uVar20 * 2) & 0x7fff;
                    *(uint *)(psVar6 + 2) = uVar19;
                    if (uVar19 < uVar21) {
                      cVar7 = func_0x(0x202a7e0);
                      if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                         (*(char *)(lVar17 + 0x499) != '\0')) {
                        cVar7 = func_0x(0x202a7e0);
                        if (cVar7 == '\0') {
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x81d,0);
                        }
                      }
                      func_0x(*(undefined8 *)(psVar6 + 4),4);
                      uVar21 = *(uint *)(psVar6 + 0xc);
                      uVar20 = (ulonglong)(ushort)psVar6[0xe];
                    }
                    puVar27 = puVar29;
                    plVar14 = plVar15;
                    if ((short)uVar20 != 0) {
                      do {
                        puVar29 = (undefined8 *)((longlong)puVar29 + 2);
                        uVar19 = *(ushort *)puVar29 & 0x7fff;
                        if ((uVar19 < uVar21) || (*(uint *)(psVar6 + 2) < uVar19)) {
                          cVar7 = func_0x(0x202a7e0);
                          if ((cVar7 != '\0') &&
                             ((lVar17 = func_0x(), lVar17 != 0 &&
                              (*(char *)(lVar17 + 0x499) != '\0')))) {
                            cVar7 = func_0x(0x202a7e0);
                            if (cVar7 == '\0') {
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x82a,0);
                            }
                          }
                          func_0x(*(undefined8 *)(psVar6 + 4),4);
                        }
                        uVar30 = (int)plVar14 + 1;
                        uVar20 = (ulonglong)(ushort)psVar6[0xe];
                        puVar27 = puStack_9b0;
                        plVar14 = (longlong *)(ulonglong)uVar30;
                        uVar21 = uVar19;
                      } while ((int)uVar30 < (int)(uint)(ushort)psVar6[0xe]);
                    }
                    if (*(short *)((longlong)puVar27 + (ulonglong)((int)uVar20 - 1) * 2 + 2) < 0) {
                      do {
                        lVar17 = (ulonglong)*(uint *)(psVar6 + 10) + *(longlong *)(psVar6 + 4);
                        uVar19 = *(ushort *)(lVar17 + uVar20 * 2) & 0x7fff;
                        if ((int)uVar20 == 1) {
                          uVar30 = *(uint *)(psVar6 + 0xc);
                          uVar18 = uVar30;
LAB_:
                          if ((uVar19 < uVar30) || (uVar21 = *(uint *)(psVar6 + 2), uVar21 < uVar19)
                             ) goto LAB_;
                        }
                        else {
                          uVar30 = *(ushort *)(lVar17 + -2 + uVar20 * 2) & 0x7fff;
                          uVar18 = *(uint *)(psVar6 + 0xc);
                          if (uVar18 <= uVar30) goto LAB_;
LAB_:
                          func_0x(*(longlong *)(psVar6 + 4),7);
                          uVar18 = *(uint *)(psVar6 + 0xc);
                          uVar21 = *(uint *)(psVar6 + 2);
                        }
                        uVar22 = uStack_9d8;
                        if ((uVar30 < uVar18) || (uVar21 < uVar30)) goto LAB_;
                        if (*(ushort *)((ulonglong)uVar30 + *(longlong *)(psVar6 + 4)) == 5) {
                          *puVar1 = *puVar1 | 2;
                          psVar6[0xe] = psVar6[0xe] + -1;
                          uVar24 = (ulonglong)(uVar30 & 0xffff);
                          psVar6[0x15] = (short)uVar30;
                          uVar20 = *(ulonglong *)(psVar6 + 4);
                          uVar11 = psVar6[0x16] & 0xc7ffU;
                          if ((*(ushort *)(uVar24 + 2 + uVar20) >> 0xe & 1) != 0) {
                            uVar11 = *(ushort *)(uVar24 + 2 + uVar20) & 0x3800 |
                                     psVar6[0x16] & 0xc7ffU;
                          }
                          psVar6[0x16] = uVar11;
                          uVar10 = (uVar11 ^ *(ushort *)(uVar24 + 2 + uVar20)) & 0x7ff ^ uVar11;
                          psVar6[0x16] = uVar10;
                          uVar26 = (ulonglong)(ushort)psVar6[0x15];
                          uVar24 = uVar26 + 4 +
                                   (ulonglong)((uVar10 & 0x7ff) * 2) +
                                   uVar20 + (uVar11 >> 0xb & 7) * 2;
                          if (uVar24 < uVar26 + uVar20) {
                            func_0x(uVar26 + uVar20,0x19);
                            uVar10 = psVar6[0x16];
                            uVar26 = (ulonglong)(ushort)psVar6[0x15];
                            uVar20 = (ulonglong)*(uint *)(psVar6 + 4);
                          }
                          if (uVar19 - uVar30 <
                              (((uVar10 & 0x7ff) * 2 - (int)uVar26) - (int)uVar20) + (int)uVar24) {
                            func_0x(uVar26 + *(longlong *)(psVar6 + 4),0x19);
                            uVar10 = psVar6[0x16];
                          }
                          if (((uVar10 & 0x3800) != 0) &&
                             (puVar28 = (ushort *)
                                        (*(longlong *)(psVar6 + 4) + 4 +
                                        (ulonglong)(ushort)psVar6[0x15]), plVar14 = plVar15,
                             (uVar10 & 0x3800) != 0)) {
                            do {
                              if ((uVar10 & 0x7ff) < (*puVar28 & 0x7ff)) {
                                func_0x((ulonglong)(ushort)psVar6[0x15] +
                                                *(longlong *)(psVar6 + 4),0x1a);
                                uVar10 = psVar6[0x16];
                              }
                              uVar21 = (int)plVar14 + 1;
                              plVar14 = (longlong *)(ulonglong)uVar21;
                              puVar28 = puVar28 + 1;
                            } while ((int)uVar21 < (int)(uVar10 >> 0xb & 7));
                          }
                          break;
                        }
                        if (*(ushort *)((ulonglong)uVar30 + *(longlong *)(psVar6 + 4)) < 0x400)
                        break;
                        *puVar1 = *puVar1 | 1;
                        uVar11 = psVar6[0xe] - 1;
                        psVar6[0xe] = uVar11;
                        if ((uVar11 == 0) ||
                           (uVar20 = (ulonglong)uVar11,
                           -1 < *(short *)((longlong)puVar27 + (ulonglong)(uVar11 - 1) * 2 + 2)))
                        break;
                      } while( true );
                    }
                  }
                  if ((**(byte **)(psVar6 + 4) & 0x40) == 0) {
                    *(undefined4 *)(psVar6 + 0x13) = 0;
                  }
                  else {
                    *(int *)(psVar6 + 0x13) = *(int *)(psVar6 + 2);
                    *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + 0xe;
                    uVar16 = func_0x(puVar1);
                    func_0x(uVar16,auStack_940);
                    iVar12 = func_0x(auStack_940);
                    *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + iVar12;
                  }
                  uVar21 = *(uint *)(psVar6 + 2);
                  if ((*(ulonglong *)(psVar6 + 0xf) != 0) &&
                     (*(ulonglong *)(psVar6 + 0xf) < (ulonglong)uVar21 + *(longlong *)(psVar6 + 4)))
                  {
                    cVar7 = func_0x(0x202a7e0);
                    if ((cVar7 != '\0') &&
                       ((lVar17 = func_0x(), lVar17 != 0 &&
                        (*(char *)(lVar17 + 0x499) != '\0')))) {
                      cVar7 = func_0x(0x202a7e0);
                      if (cVar7 == '\0') {
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x886,0);
                      }
                    }
                    func_0x(*(undefined8 *)(psVar6 + 4),0x12);
                    uVar21 = *(uint *)(psVar6 + 2);
                  }
                  if ((uVar21 == 0) || (uVar22 = uStack_9d8, 0x3f3c < uVar21)) {
                    cVar7 = func_0x(0x202a7e0);
                    if ((cVar7 != '\0') &&
                       ((lVar17 = func_0x(), lVar17 != 0 &&
                        (*(char *)(lVar17 + 0x499) != '\0')))) {
                      cVar7 = func_0x(0x202a7e0);
                      if (cVar7 == '\0') {
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x88b,0);
                      }
                    }
                    func_0x(*(undefined8 *)(psVar6 + 4),5);
                    uVar21 = *(uint *)(psVar6 + 2);
                    uVar22 = uStack_9d8;
                  }
                }
LAB_:
                if ((uVar21 < 9) &&
                   (((**(byte **)(psVar6 + 4) & 0xe) == 0 ||
                    ((**(byte **)(psVar6 + 4) & 0xe) == 0xc)))) {
                  uVar21 = 9;
                }
              }
              else {
                uVar21 = func_0x(puVar1);
              }
              uStack_9d8 = uVar22;
              if (uVar21 < 0x1f74) {
                uStack_9d8 = 0x16;
              }
            }
          }
          bVar5 = true;
        }
      }
    }
LAB_:
    psVar6 = psStack_9d0;
    if ((param_6 == 0) || (param_6 == 1)) {
      puVar1 = (ushort *)(psStack_9d0 + 1);
      psVar25 = psVar6;
      if (*psStack_9d0 == 0) {
        if (*(int *)(psStack_9d0 + 2) == 0) {
          *puVar1 = 0;
          uVar21 = *(uint *)(psStack_9d0 + 8);
          uVar20 = (ulonglong)uVar21;
          *(uint *)(psStack_9d0 + 10) = uVar21;
          pbVar3 = *(byte **)(psStack_9d0 + 4);
          bVar8 = *pbVar3;
          if ((bVar8 & 0x10) != 0) {
            uVar21 = uVar21 + 2 + (*(ushort *)(pbVar3 + uVar20) + 7 >> 3);
            uVar20 = (ulonglong)uVar21;
            *(uint *)(psStack_9d0 + 10) = uVar21;
            bVar8 = *pbVar3;
          }
          if ((bVar8 & 0x20) == 0) {
            *(int *)(psStack_9d0 + 2) = (int)uVar20;
            psStack_9d0[0xe] = 0;
            *(uint *)(psStack_9d0 + 0xc) = uVar21;
          }
          else {
            puVar29 = (undefined8 *)(pbVar3 + uVar20);
            uVar11 = *(ushort *)puVar29;
            psStack_9d0[0xe] = uVar11;
            puStack_9b0 = puVar29;
            if (uVar11 == 0) {
              cVar7 = func_0x(0x202a7e0);
              if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                 (*(char *)(lVar17 + 0x499) != '\0')) {
                cVar7 = func_0x(0x202a7e0);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x80f,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),3);
              uVar11 = psVar6[0xe];
              uVar21 = *(uint *)(psVar6 + 10);
            }
            uVar21 = uVar21 + (uVar11 + 1) * 2;
            *(uint *)(psVar6 + 0xc) = uVar21;
            if (0x1f9e < uVar21) {
              cVar7 = func_0x(0x202a7e0);
              if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                 (*(char *)(lVar17 + 0x499) != '\0')) {
                cVar7 = func_0x(0x202a7e0);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x816,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),4);
              uVar11 = psVar6[0xe];
              uVar21 = *(uint *)(psVar6 + 0xc);
            }
            uVar20 = (ulonglong)uVar11;
            uVar19 = *(ushort *)((longlong)puVar29 + uVar20 * 2) & 0x7fff;
            *(uint *)(psVar6 + 2) = uVar19;
            if (uVar19 < uVar21) {
              cVar7 = func_0x(0x202a7e0);
              if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                 (*(char *)(lVar17 + 0x499) != '\0')) {
                cVar7 = func_0x(0x202a7e0);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x81d,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),4);
              uVar21 = *(uint *)(psVar6 + 0xc);
              uVar20 = (ulonglong)(ushort)psVar6[0xe];
            }
            puVar27 = puVar29;
            plVar14 = plVar15;
            if ((short)uVar20 != 0) {
              do {
                puVar29 = (undefined8 *)((longlong)puVar29 + 2);
                uVar19 = *(ushort *)puVar29 & 0x7fff;
                if ((uVar19 < uVar21) || (*(uint *)(psVar6 + 2) < uVar19)) {
                  cVar7 = func_0x(0x202a7e0);
                  if ((cVar7 != '\0') &&
                     ((lVar17 = func_0x(), lVar17 != 0 &&
                      (*(char *)(lVar17 + 0x499) != '\0')))) {
                    cVar7 = func_0x(0x202a7e0);
                    if (cVar7 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x82a,0);
                    }
                  }
                  func_0x(*(undefined8 *)(psVar6 + 4),4);
                }
                uVar30 = (int)plVar14 + 1;
                uVar20 = (ulonglong)(ushort)psVar6[0xe];
                puVar27 = puStack_9b0;
                plVar14 = (longlong *)(ulonglong)uVar30;
                uVar21 = uVar19;
              } while ((int)uVar30 < (int)(uint)(ushort)psVar6[0xe]);
            }
            if (*(short *)((longlong)puVar27 + (ulonglong)((int)uVar20 - 1) * 2 + 2) < 0) {
              do {
                lVar17 = (ulonglong)*(uint *)(psVar6 + 10) + *(longlong *)(psVar6 + 4);
                uVar21 = *(ushort *)(lVar17 + uVar20 * 2) & 0x7fff;
                if ((int)uVar20 == 1) {
                  uVar19 = *(uint *)(psVar6 + 0xc);
                  uVar30 = uVar19;
LAB_:
                  if ((uVar21 < uVar19) || (uVar18 = *(uint *)(psVar6 + 2), uVar18 < uVar21))
                  goto LAB_;
                }
                else {
                  uVar19 = *(ushort *)(lVar17 + -2 + uVar20 * 2) & 0x7fff;
                  uVar30 = *(uint *)(psVar6 + 0xc);
                  if (uVar30 <= uVar19) goto LAB_;
LAB_:
                  func_0x(*(longlong *)(psVar6 + 4),7);
                  uVar30 = *(uint *)(psVar6 + 0xc);
                  uVar18 = *(uint *)(psVar6 + 2);
                }
                psVar25 = psStack_9d0;
                if ((uVar19 < uVar30) || (uVar18 < uVar19)) goto LAB_;
                if (*(ushort *)((ulonglong)uVar19 + *(longlong *)(psVar6 + 4)) == 5) {
                  *puVar1 = *puVar1 | 2;
                  psVar6[0xe] = psVar6[0xe] + -1;
                  uVar24 = (ulonglong)(uVar19 & 0xffff);
                  psVar6[0x15] = (short)uVar19;
                  uVar20 = *(ulonglong *)(psVar6 + 4);
                  uVar11 = psVar6[0x16] & 0xc7ffU;
                  if ((*(ushort *)(uVar24 + 2 + uVar20) >> 0xe & 1) != 0) {
                    uVar11 = *(ushort *)(uVar24 + 2 + uVar20) & 0x3800 | psVar6[0x16] & 0xc7ffU;
                  }
                  psVar6[0x16] = uVar11;
                  uVar10 = (uVar11 ^ *(ushort *)(uVar24 + 2 + uVar20)) & 0x7ff ^ uVar11;
                  psVar6[0x16] = uVar10;
                  uVar26 = (ulonglong)(ushort)psVar6[0x15];
                  uVar24 = uVar26 + 4 +
                           (ulonglong)((uVar10 & 0x7ff) * 2) + uVar20 + (uVar11 >> 0xb & 7) * 2;
                  if (uVar24 < uVar26 + uVar20) {
                    func_0x(uVar26 + uVar20,0x19);
                    uVar10 = psVar6[0x16];
                    uVar26 = (ulonglong)(ushort)psVar6[0x15];
                    uVar20 = (ulonglong)*(uint *)(psVar6 + 4);
                  }
                  if (uVar21 - uVar19 <
                      (((uVar10 & 0x7ff) * 2 - (int)uVar26) - (int)uVar20) + (int)uVar24) {
                    func_0x(uVar26 + *(longlong *)(psVar6 + 4),0x19);
                    uVar10 = psVar6[0x16];
                  }
                  if (((uVar10 & 0x3800) != 0) &&
                     (puVar28 = (ushort *)
                                (*(longlong *)(psVar6 + 4) + 4 + (ulonglong)(ushort)psVar6[0x15]),
                     plVar14 = plVar15, (uVar10 & 0x3800) != 0)) {
                    do {
                      if ((uVar10 & 0x7ff) < (*puVar28 & 0x7ff)) {
                        func_0x((ulonglong)(ushort)psVar6[0x15] + *(longlong *)(psVar6 + 4),
                                        0x1a);
                        uVar10 = psVar6[0x16];
                      }
                      uVar21 = (int)plVar14 + 1;
                      plVar14 = (longlong *)(ulonglong)uVar21;
                      puVar28 = puVar28 + 1;
                    } while ((int)uVar21 < (int)(uVar10 >> 0xb & 7));
                  }
                  break;
                }
                if (*(ushort *)((ulonglong)uVar19 + *(longlong *)(psVar6 + 4)) < 0x400) break;
                *puVar1 = *puVar1 | 1;
                uVar11 = psVar6[0xe] - 1;
                psVar6[0xe] = uVar11;
                if ((uVar11 == 0) ||
                   (uVar20 = (ulonglong)uVar11,
                   -1 < *(short *)((longlong)puVar27 + (ulonglong)(uVar11 - 1) * 2 + 2))) break;
              } while( true );
            }
          }
          if ((**(byte **)(psVar6 + 4) & 0x40) == 0) {
            *(undefined4 *)(psVar6 + 0x13) = 0;
          }
          else {
            *(int *)(psVar6 + 0x13) = *(int *)(psVar6 + 2);
            *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + 0xe;
            uVar16 = func_0x(puVar1);
            func_0x(uVar16,auStack_928);
            iVar12 = func_0x(auStack_928);
            *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + iVar12;
          }
          uVar21 = *(uint *)(psVar6 + 2);
          if ((*(ulonglong *)(psVar6 + 0xf) != 0) &&
             (*(ulonglong *)(psVar6 + 0xf) < (ulonglong)uVar21 + *(longlong *)(psVar6 + 4))) {
            cVar7 = func_0x(0x202a7e0);
            if ((cVar7 != '\0') &&
               ((lVar17 = func_0x(), lVar17 != 0 &&
                (*(char *)(lVar17 + 0x499) != '\0')))) {
              cVar7 = func_0x(0x202a7e0);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x886,0);
              }
            }
            func_0x(*(undefined8 *)(psVar6 + 4),0x12);
            uVar21 = *(uint *)(psVar6 + 2);
          }
          if ((uVar21 == 0) || (psVar25 = psStack_9d0, 0x3f3c < uVar21)) {
            cVar7 = func_0x(0x202a7e0);
            if ((cVar7 != '\0') &&
               ((lVar17 = func_0x(), lVar17 != 0 &&
                (*(char *)(lVar17 + 0x499) != '\0')))) {
              cVar7 = func_0x(0x202a7e0);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x88b,0);
              }
            }
            func_0x(*(undefined8 *)(psVar6 + 4),5);
            psVar25 = psStack_9d0;
          }
        }
      }
      else {
        func_0x(puVar1);
      }
LAB_:
      uVar22 = uStack_9d8;
      if (((((param_6 == 1) && (sStack_9c4 == 0)) && (iStack_9c0 == iStack_988)) &&
          ((bVar5 && (param_12 == 0)))) &&
         (cVar7 = (**(code **)(*param_3 + 0x20))(), uVar22 = uStack_9d8, cVar7 != '\0')) {
        uVar22 = 0x22;
      }
      sVar9 = (short)uVar22;
      if (*psVar25 == 0) {
        uVar21 = *(uint *)(psVar6 + 2);
        if (uVar21 == 0) {
          *puVar1 = 0;
          uVar21 = *(uint *)(psVar6 + 8);
          uVar20 = (ulonglong)uVar21;
          *(uint *)(psVar6 + 10) = uVar21;
          pbVar3 = *(byte **)(psVar6 + 4);
          bVar8 = *pbVar3;
          if ((bVar8 & 0x10) != 0) {
            uVar21 = uVar21 + 2 + (*(ushort *)(pbVar3 + uVar20) + 7 >> 3);
            uVar20 = (ulonglong)uVar21;
            *(uint *)(psVar6 + 10) = uVar21;
            bVar8 = *pbVar3;
          }
          if ((bVar8 & 0x20) == 0) {
            *(int *)(psVar6 + 2) = (int)uVar20;
            psVar6[0xe] = 0;
            *(uint *)(psVar6 + 0xc) = uVar21;
          }
          else {
            puVar28 = (ushort *)(pbVar3 + uVar20);
            uVar11 = *puVar28;
            psVar6[0xe] = uVar11;
            if (uVar11 == 0) {
              cVar7 = func_0x(0x202a7e0);
              if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                 (*(char *)(lVar17 + 0x499) != '\0')) {
                cVar7 = func_0x(0x202a7e0);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x80f,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),3);
              uVar11 = psVar6[0xe];
              uVar21 = *(uint *)(psVar6 + 10);
            }
            uVar21 = uVar21 + (uVar11 + 1) * 2;
            *(uint *)(psVar6 + 0xc) = uVar21;
            if (0x1f9e < uVar21) {
              cVar7 = func_0x(0x202a7e0);
              if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                 (*(char *)(lVar17 + 0x499) != '\0')) {
                cVar7 = func_0x(0x202a7e0);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x816,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),4);
              uVar11 = psVar6[0xe];
              uVar21 = *(uint *)(psVar6 + 0xc);
            }
            uVar20 = (ulonglong)uVar11;
            uVar11 = puVar28[uVar20];
            *(uint *)(psVar6 + 2) = uVar11 & 0x7fff;
            if ((uVar11 & 0x7fff) < uVar21) {
              cVar7 = func_0x(0x202a7e0);
              if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                 (*(char *)(lVar17 + 0x499) != '\0')) {
                cVar7 = func_0x(0x202a7e0);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x81d,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),4);
              uVar21 = *(uint *)(psVar6 + 0xc);
              uVar20 = (ulonglong)(ushort)psVar6[0xe];
            }
            plVar14 = plVar15;
            puVar4 = puVar28;
            if ((short)uVar20 != 0) {
              do {
                uVar19 = puVar4[1] & 0x7fff;
                if ((uVar19 < uVar21) || (*(uint *)(psVar6 + 2) < uVar19)) {
                  cVar7 = func_0x(0x202a7e0);
                  if ((cVar7 != '\0') &&
                     ((lVar17 = func_0x(), lVar17 != 0 &&
                      (*(char *)(lVar17 + 0x499) != '\0')))) {
                    cVar7 = func_0x(0x202a7e0);
                    if (cVar7 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x82a,0);
                    }
                  }
                  func_0x(*(undefined8 *)(psVar6 + 4),4);
                }
                uVar30 = (int)plVar14 + 1;
                uVar20 = (ulonglong)(ushort)psVar6[0xe];
                plVar14 = (longlong *)(ulonglong)uVar30;
                puVar4 = puVar4 + 1;
                uVar21 = uVar19;
              } while ((int)uVar30 < (int)(uint)(ushort)psVar6[0xe]);
            }
            if ((short)puVar28[(ulonglong)((int)uVar20 - 1) + 1] < 0) {
              do {
                lVar17 = (ulonglong)*(uint *)(psVar6 + 10) + *(longlong *)(psVar6 + 4);
                uVar19 = *(ushort *)(lVar17 + uVar20 * 2) & 0x7fff;
                if ((int)uVar20 == 1) {
                  uVar30 = *(uint *)(psVar6 + 0xc);
                  uVar18 = uVar30;
LAB_:
                  if ((uVar19 < uVar30) || (uVar21 = *(uint *)(psVar6 + 2), uVar21 < uVar19))
                  goto LAB_;
                }
                else {
                  uVar30 = *(ushort *)(lVar17 + -2 + uVar20 * 2) & 0x7fff;
                  uVar18 = *(uint *)(psVar6 + 0xc);
                  if (uVar18 <= uVar30) goto LAB_;
LAB_:
                  func_0x(*(longlong *)(psVar6 + 4),7);
                  uVar18 = *(uint *)(psVar6 + 0xc);
                  uVar21 = *(uint *)(psVar6 + 2);
                }
                if ((uVar30 < uVar18) || (uVar21 < uVar30)) goto LAB_;
                if (*(ushort *)((ulonglong)uVar30 + *(longlong *)(psVar6 + 4)) == 5) {
                  *puVar1 = *puVar1 | 2;
                  psVar6[0xe] = psVar6[0xe] + -1;
                  uVar24 = (ulonglong)(uVar30 & 0xffff);
                  psVar6[0x15] = (short)uVar30;
                  uVar20 = *(ulonglong *)(psVar6 + 4);
                  uVar11 = psVar6[0x16] & 0xc7ffU;
                  if ((*(ushort *)(uVar24 + 2 + uVar20) >> 0xe & 1) != 0) {
                    uVar11 = *(ushort *)(uVar24 + 2 + uVar20) & 0x3800 | psVar6[0x16] & 0xc7ffU;
                  }
                  psVar6[0x16] = uVar11;
                  uVar10 = (uVar11 ^ *(ushort *)(uVar24 + 2 + uVar20)) & 0x7ff ^ uVar11;
                  psVar6[0x16] = uVar10;
                  uVar26 = (ulonglong)(ushort)psVar6[0x15];
                  uVar24 = uVar26 + 4 +
                           (ulonglong)((uVar10 & 0x7ff) * 2) + uVar20 + (uVar11 >> 0xb & 7) * 2;
                  if (uVar24 < uVar26 + uVar20) {
                    func_0x(uVar26 + uVar20,0x19);
                    uVar10 = psVar6[0x16];
                    uVar26 = (ulonglong)(ushort)psVar6[0x15];
                    uVar20 = (ulonglong)*(uint *)(psVar6 + 4);
                  }
                  if (uVar19 - uVar30 <
                      (((uVar10 & 0x7ff) * 2 - (int)uVar26) - (int)uVar20) + (int)uVar24) {
                    func_0x(uVar26 + *(longlong *)(psVar6 + 4),0x19);
                    uVar10 = psVar6[0x16];
                  }
                  if (((uVar10 & 0x3800) != 0) &&
                     (puVar28 = (ushort *)
                                (*(longlong *)(psVar6 + 4) + 4 + (ulonglong)(ushort)psVar6[0x15]),
                     plVar14 = plVar15, (uVar10 & 0x3800) != 0)) {
                    do {
                      if ((uVar10 & 0x7ff) < (*puVar28 & 0x7ff)) {
                        func_0x((ulonglong)(ushort)psVar6[0x15] + *(longlong *)(psVar6 + 4),
                                        0x1a);
                        uVar10 = psVar6[0x16];
                      }
                      uVar21 = (int)plVar14 + 1;
                      plVar14 = (longlong *)(ulonglong)uVar21;
                      puVar28 = puVar28 + 1;
                    } while ((int)uVar21 < (int)(uVar10 >> 0xb & 7));
                  }
                  break;
                }
                if (*(ushort *)((ulonglong)uVar30 + *(longlong *)(psVar6 + 4)) < 0x400) break;
                *puVar1 = *puVar1 | 1;
                uVar11 = psVar6[0xe] - 1;
                psVar6[0xe] = uVar11;
                if ((uVar11 == 0) ||
                   (uVar20 = (ulonglong)uVar11, -1 < (short)puVar28[(ulonglong)(uVar11 - 1) + 1]))
                break;
              } while( true );
            }
          }
          if ((**(byte **)(psVar6 + 4) & 0x40) == 0) {
            *(undefined4 *)(psVar6 + 0x13) = 0;
          }
          else {
            *(int *)(psVar6 + 0x13) = *(int *)(psVar6 + 2);
            *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + 0xe;
            uVar16 = func_0x(puVar1);
            func_0x(uVar16,auStack_920);
            iVar12 = func_0x(auStack_920);
            *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + iVar12;
          }
          uVar21 = *(uint *)(psVar6 + 2);
          if ((*(ulonglong *)(psVar6 + 0xf) != 0) &&
             (*(ulonglong *)(psVar6 + 0xf) < (ulonglong)uVar21 + *(longlong *)(psVar6 + 4))) {
            cVar7 = func_0x(0x202a7e0);
            if ((cVar7 != '\0') &&
               ((lVar17 = func_0x(), lVar17 != 0 &&
                (*(char *)(lVar17 + 0x499) != '\0')))) {
              cVar7 = func_0x(0x202a7e0);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x886,0);
              }
            }
            func_0x(*(undefined8 *)(psVar6 + 4),0x12);
            uVar21 = *(uint *)(psVar6 + 2);
          }
          if ((uVar21 == 0) || (0x3f3c < uVar21)) {
            cVar7 = func_0x(0x202a7e0);
            if ((cVar7 != '\0') &&
               ((lVar17 = func_0x(), lVar17 != 0 &&
                (*(char *)(lVar17 + 0x499) != '\0')))) {
              cVar7 = func_0x(0x202a7e0);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x88b,0);
              }
            }
            func_0x(*(undefined8 *)(psVar6 + 4),5);
            uVar21 = *(uint *)(psVar6 + 2);
          }
        }
LAB_:
        if ((uVar21 < 9) &&
           (((**(byte **)(psVar6 + 4) & 0xe) == 0 || ((**(byte **)(psVar6 + 4) & 0xe) == 0xc)))) {
          uStack_9e0._0_2_ = sVar9 + 9;
        }
        else {
          uStack_9e0._0_2_ = (short)uVar21 + sVar9;
        }
      }
      else {
        uStack_9e0._0_2_ = func_0x(puVar1);
        uStack_9e0._0_2_ = (short)uStack_9e0 + sVar9;
      }
      goto LAB_;
    }
    if (param_6 != 2) {
      if (param_6 == 3) {
        if (iStack_a0c == 0) {
          func_0x(auStack_a0e);
        }
        sVar9 = func_0x(auStack_a0e);
        if ((*pbStack_a08 & 2) == 0) {
          uStack_9e0._0_2_ = sVar9;
        }
        uStack_9e0._0_2_ = (short)uStack_9d8 + (short)uStack_9e0;
        goto LAB_;
      }
      if (param_6 != 4) {
        (*_DAT_)(1,0x1a9bae0,0x1ac93f8,0x52c,0x1695750);
      }
      goto LAB_;
    }
    if (param_10 == (uint *)0x0) {
      puVar1 = (ushort *)(psStack_9d0 + 1);
      if (*psStack_9d0 == 0) {
        uVar21 = *(uint *)(psStack_9d0 + 2);
        if (uVar21 == 0) {
          *puVar1 = 0;
          uVar21 = *(uint *)(psStack_9d0 + 8);
          uVar20 = (ulonglong)uVar21;
          *(uint *)(psStack_9d0 + 10) = uVar21;
          pbVar3 = *(byte **)(psStack_9d0 + 4);
          bVar8 = *pbVar3;
          if ((bVar8 & 0x10) != 0) {
            uVar21 = uVar21 + 2 + (*(ushort *)(pbVar3 + uVar20) + 7 >> 3);
            uVar20 = (ulonglong)uVar21;
            *(uint *)(psStack_9d0 + 10) = uVar21;
            bVar8 = *pbVar3;
          }
          if ((bVar8 & 0x20) == 0) {
            *(int *)(psStack_9d0 + 2) = (int)uVar20;
            psStack_9d0[0xe] = 0;
            *(uint *)(psStack_9d0 + 0xc) = uVar21;
          }
          else {
            puVar28 = (ushort *)(pbVar3 + uVar20);
            uVar11 = *puVar28;
            psStack_9d0[0xe] = uVar11;
            if (uVar11 == 0) {
              cVar7 = func_0x(0x202a7e0);
              if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                 (*(char *)(lVar17 + 0x499) != '\0')) {
                cVar7 = func_0x(0x202a7e0);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x80f,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),3);
              uVar11 = psVar6[0xe];
              uVar21 = *(uint *)(psVar6 + 10);
            }
            uVar21 = uVar21 + (uVar11 + 1) * 2;
            *(uint *)(psVar6 + 0xc) = uVar21;
            if (0x1f9e < uVar21) {
              cVar7 = func_0x(0x202a7e0);
              if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                 (*(char *)(lVar17 + 0x499) != '\0')) {
                cVar7 = func_0x(0x202a7e0);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x816,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),4);
              uVar11 = psVar6[0xe];
              uVar21 = *(uint *)(psVar6 + 0xc);
            }
            uVar20 = (ulonglong)uVar11;
            uVar11 = puVar28[uVar20];
            *(uint *)(psVar6 + 2) = uVar11 & 0x7fff;
            if ((uVar11 & 0x7fff) < uVar21) {
              cVar7 = func_0x(0x202a7e0);
              if (((cVar7 != '\0') && (lVar17 = func_0x(), lVar17 != 0)) &&
                 (*(char *)(lVar17 + 0x499) != '\0')) {
                cVar7 = func_0x(0x202a7e0);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x81d,0);
                }
              }
              func_0x(*(undefined8 *)(psVar6 + 4),4);
              uVar21 = *(uint *)(psVar6 + 0xc);
              uVar20 = (ulonglong)(ushort)psVar6[0xe];
            }
            plVar14 = plVar15;
            puVar4 = puVar28;
            if ((short)uVar20 != 0) {
              do {
                uVar19 = puVar4[1] & 0x7fff;
                if ((uVar19 < uVar21) || (*(uint *)(psVar6 + 2) < uVar19)) {
                  cVar7 = func_0x(0x202a7e0);
                  if ((cVar7 != '\0') &&
                     ((lVar17 = func_0x(), lVar17 != 0 &&
                      (*(char *)(lVar17 + 0x499) != '\0')))) {
                    cVar7 = func_0x(0x202a7e0);
                    if (cVar7 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x82a,0);
                    }
                  }
                  func_0x(*(undefined8 *)(psVar6 + 4),4);
                }
                uVar30 = (int)plVar14 + 1;
                uVar20 = (ulonglong)(ushort)psVar6[0xe];
                plVar14 = (longlong *)(ulonglong)uVar30;
                puVar4 = puVar4 + 1;
                uVar21 = uVar19;
              } while ((int)uVar30 < (int)(uint)(ushort)psVar6[0xe]);
            }
            if ((short)puVar28[(ulonglong)((int)uVar20 - 1) + 1] < 0) {
              do {
                lVar17 = *(longlong *)(psVar6 + 4);
                uVar19 = *(ushort *)((ulonglong)*(uint *)(psVar6 + 10) + lVar17 + uVar20 * 2) &
                         0x7fff;
                if ((int)uVar20 == 1) {
                  uVar30 = *(uint *)(psVar6 + 0xc);
                  uVar18 = uVar30;
LAB_:
                  if ((uVar19 < uVar30) || (uVar21 = *(uint *)(psVar6 + 2), uVar21 < uVar19))
                  goto LAB_;
                }
                else {
                  uVar30 = *(ushort *)((ulonglong)*(uint *)(psVar6 + 10) + lVar17 + -2 + uVar20 * 2)
                           & 0x7fff;
                  uVar18 = *(uint *)(psVar6 + 0xc);
                  if (uVar18 <= uVar30) goto LAB_;
LAB_:
                  func_0x(lVar17,7);
                  uVar18 = *(uint *)(psVar6 + 0xc);
                  uVar21 = *(uint *)(psVar6 + 2);
                  lVar17 = *(longlong *)(psVar6 + 4);
                }
                if ((uVar30 < uVar18) || (uVar21 < uVar30)) goto LAB_;
                if (*(ushort *)((ulonglong)uVar30 + lVar17) == 5) {
                  *puVar1 = *puVar1 | 2;
                  psVar6[0xe] = psVar6[0xe] + -1;
                  uVar24 = (ulonglong)(uVar30 & 0xffff);
                  psVar6[0x15] = (short)uVar30;
                  uVar20 = *(ulonglong *)(psVar6 + 4);
                  uVar11 = psVar6[0x16] & 0xc7ffU;
                  if ((*(ushort *)(uVar24 + 2 + uVar20) >> 0xe & 1) != 0) {
                    uVar11 = *(ushort *)(uVar24 + 2 + uVar20) & 0x3800 | psVar6[0x16] & 0xc7ffU;
                  }
                  psVar6[0x16] = uVar11;
                  uVar10 = (uVar11 ^ *(ushort *)(uVar24 + 2 + uVar20)) & 0x7ff ^ uVar11;
                  psVar6[0x16] = uVar10;
                  uVar26 = (ulonglong)(ushort)psVar6[0x15];
                  uVar24 = uVar26 + 4 +
                           (ulonglong)((uVar10 & 0x7ff) * 2) + uVar20 + (uVar11 >> 0xb & 7) * 2;
                  if (uVar24 < uVar26 + uVar20) {
                    func_0x(uVar26 + uVar20,0x19);
                    uVar10 = psVar6[0x16];
                    uVar26 = (ulonglong)(ushort)psVar6[0x15];
                    uVar20 = (ulonglong)*(uint *)(psVar6 + 4);
                  }
                  if (uVar19 - uVar30 <
                      (((uVar10 & 0x7ff) * 2 - (int)uVar26) - (int)uVar20) + (int)uVar24) {
                    func_0x(uVar26 + *(longlong *)(psVar6 + 4),0x19);
                    uVar10 = psVar6[0x16];
                  }
                  if (((uVar10 & 0x3800) != 0) &&
                     (puVar28 = (ushort *)
                                (*(longlong *)(psVar6 + 4) + 4 + (ulonglong)(ushort)psVar6[0x15]),
                     plVar14 = plVar15, (uVar10 & 0x3800) != 0)) {
                    do {
                      if ((uVar10 & 0x7ff) < (*puVar28 & 0x7ff)) {
                        func_0x((ulonglong)(ushort)psVar6[0x15] + *(longlong *)(psVar6 + 4),
                                        0x1a);
                        uVar10 = psVar6[0x16];
                      }
                      uVar21 = (int)plVar14 + 1;
                      puVar28 = puVar28 + 1;
                      plVar14 = (longlong *)(ulonglong)uVar21;
                    } while ((int)uVar21 < (int)(uVar10 >> 0xb & 7));
                  }
                  break;
                }
                if (*(ushort *)((ulonglong)uVar30 + lVar17) < 0x400) break;
                *puVar1 = *puVar1 | 1;
                uVar11 = psVar6[0xe] - 1;
                psVar6[0xe] = uVar11;
                if ((uVar11 == 0) ||
                   (uVar20 = (ulonglong)uVar11, -1 < (short)puVar28[(ulonglong)(uVar11 - 1) + 1]))
                break;
              } while( true );
            }
          }
          if ((**(byte **)(psVar6 + 4) & 0x40) == 0) {
            *(undefined4 *)(psVar6 + 0x13) = 0;
          }
          else {
            *(int *)(psVar6 + 0x13) = *(int *)(psVar6 + 2);
            *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + 0xe;
            uVar16 = func_0x(puVar1);
            func_0x(uVar16,auStack_930);
            iVar12 = func_0x(auStack_930);
            *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + iVar12;
          }
          uVar21 = *(uint *)(psVar6 + 2);
          if ((*(ulonglong *)(psVar6 + 0xf) != 0) &&
             (*(ulonglong *)(psVar6 + 0xf) < (ulonglong)uVar21 + *(longlong *)(psVar6 + 4))) {
            cVar7 = func_0x(0x202a7e0);
            if ((cVar7 != '\0') &&
               ((lVar17 = func_0x(), lVar17 != 0 &&
                (*(char *)(lVar17 + 0x499) != '\0')))) {
              cVar7 = func_0x(0x202a7e0);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x886,0);
              }
            }
            func_0x(*(undefined8 *)(psVar6 + 4),0x12);
            uVar21 = *(uint *)(psVar6 + 2);
          }
          if ((uVar21 == 0) || (0x3f3c < uVar21)) {
            cVar7 = func_0x(0x202a7e0);
            if ((cVar7 != '\0') &&
               ((lVar17 = func_0x(), lVar17 != 0 &&
                (*(char *)(lVar17 + 0x499) != '\0')))) {
              cVar7 = func_0x(0x202a7e0);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                (*_DAT_)(1,0x191a1ec,0x1a3a2d8,0x88b,0);
              }
            }
            func_0x(*(undefined8 *)(psVar6 + 4),5);
            uVar21 = *(uint *)(psVar6 + 2);
          }
        }
LAB_:
        if (uVar21 < 9) {
          bVar8 = **(byte **)(psVar6 + 4);
          if (((bVar8 & 0xe) != 0) && ((bVar8 & 0xe) != 0xc)) goto LAB_;
          uVar21 = 9;
        }
        else {
LAB_:
          bVar8 = **(byte **)(psVar6 + 4);
        }
        if ((bVar8 & 0x40) != 0) {
          uVar21 = *(uint *)(psVar6 + 0x13);
        }
      }
      else {
        if (*(int *)(psStack_9d0 + 2) == 0) {
          func_0x(puVar1);
        }
        uVar21 = func_0x(puVar1);
        if ((**(byte **)(psVar6 + 4) & 2) != 0) {
          uVar21 = *(uint *)(psVar6 + 0x18);
        }
      }
    }
    else {
      uVar21 = *param_10;
    }
    sVar9 = (short)uVar21;
    if (bVar5) {
      cVar7 = (**(code **)(*param_3 + 0x20))();
      uStack_9e0._0_2_ = (short)uStack_9d8;
      if (cVar7 == '\0') goto LAB_;
      if (*puStack_980 < 0x15) {
        uStack_9e0._0_2_ = sVar9 + (short)uStack_9e0 + 0x14;
      }
      else {
        if (2000 < uVar21) goto LAB_;
        uStack_9e0._0_2_ = sVar9 + (short)uStack_9e0 + 200;
      }
    }
    else {
      uStack_9e0._0_2_ = (short)uStack_9d8;
LAB_:
      uStack_9e0._0_2_ = sVar9 + (short)uStack_9e0;
    }
  }
LAB_:
  uVar11 = (short)(1 << ((byte)*(undefined2 *)(lStack_978 + 4) & 2)) - 1;
  uVar21 = iStack_9b4 + (uint)(ushort)((short)uStack_9e0 + uVar11 & ~uVar11);
  uVar19 = (uint)(ushort)((short)uStack_9c8 + uVar11 & ~uVar11);
  iVar12 = uVar21 - uVar19;
  if (iVar12 == 0) {
    iVar12 = 0;
  }
  *param_14 = iVar12;
  if (uVar21 <= 0x2000U - param_11) {
    uVar21 = 0x2000U - param_11;
  }
  plVar14 = (longlong *)(ulonglong)(uVar21 <= *(ushort *)(lStack_978 + 0x1c) + uVar19);
LAB_:
  if (auStack_8d8[0] != 0) {
    puVar29 = auStack_8d0;
    do {
      (*_DAT_)(*puVar29);
      uVar21 = (int)plVar15 + 1;
      plVar15 = (longlong *)(ulonglong)uVar21;
      puVar29 = puVar29 + 1;
    } while ((int)uVar21 < (int)(uint)auStack_8d8[0]);
  }
  if (lStack_7d0 != 0) {
    (*_DAT_)();
  }
  return plVar14;
}

