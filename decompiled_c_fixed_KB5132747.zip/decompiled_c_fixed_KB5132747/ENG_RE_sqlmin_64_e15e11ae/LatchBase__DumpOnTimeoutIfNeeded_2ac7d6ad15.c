
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(int *param_1)

{
  ulonglong *puVar1;
  byte bVar2;
  bool bVar3;
  int iVar4;
  longlong lVar5;
  ulonglong uVar6;
  longlong lVar7;
  uint uVar8;
  longlong unaff_GS_OFFSET;
  bool bVar9;
  undefined auStack_118 [32];
  undefined4 uStack_f8;
  undefined8 uStack_f0;
  undefined4 uStack_e8;
  undefined8 uStack_e0;
  undefined8 uStack_d8;
  uint uStack_c8;
  ulonglong uStack_c0;
  longlong lStack_b8;
  undefined8 uStack_a0;
  ulonglong uStack_98;
  longlong alStack_78 [8];
  ulonglong uStack_38;
  
  uStack_a0 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_118;
  puVar1 = *(ulonglong **)(param_1 + 6);
  uVar8 = param_1[0xe] & 0x3fffffff;
  bVar2 = DAT_ >> 6;
  uVar6 = 0;
  bVar3 = false;
  bVar9 = bVar3;
  switch(uVar8) {
  case 0x1c:
    if ((*(longlong *)(param_1 + 6) == 0) ||
       (((*(uint *)(*(longlong *)(param_1 + 6) + 100) & 4) == 0 &&
        (((*(ulonglong *)(param_1 + 0xc) & 1) == 0 || (param_1[0x46] == 0)))))) goto LAB_;
  case 0x1d:
  case 0x25:
  case 0x26:
  case 0x30:
  case 0x8d:
  case 0x92:
    bVar9 = true;
  default:
LAB_:
    if ((param_1[0x3c] + 0xfbffffe0U < 6) &&
       (((iVar4 = param_1[0x40], iVar4 == 0x25 || (iVar4 == 0x26)) || (bVar3 = false, iVar4 == 0x30)
        ))) {
      bVar3 = true;
    }
    if (((((*param_1 != 1) && ((DAT_ & 0x20) == 0)) &&
         ((lVar5 = (*_DAT_)(), *(char *)(lVar5 + 0x19a) == '\0' &&
          (((DAT_ & 0x20) == 0 && ((*_DAT_ & 0x40) == 0)))))) &&
        (((!bVar9 && (!bVar3)) || ((bVar2 & 1) != 0)))) &&
       (((*(byte *)((ulonglong)(uVar8 >> 3) + _DAT_) >> ((byte)uVar8 & 7) & 1) == 0 ||
        ((bVar2 & 1) != 0)))) {
      lVar7 = (ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar5 = *(longlong *)(lVar7 + 0x100);
      if (lVar5 == 0) {
        (*_DAT_)();
        lVar5 = *(longlong *)(lVar7 + 0x100);
      }
      LOCK();
      bVar9 = _DAT_ == 0;
      lVar5 = *(longlong *)(lVar5 + 600);
      if (!bVar9) {
        lVar5 = _DAT_;
      }
      _DAT_ = lVar5;
      UNLOCK();
      if (bVar9) {
        if ((((param_1[0x47] == 0) && (param_1[0x49] == 0)) && (param_1[0x48] == param_1[0x4a])) &&
           ((iVar4 = func_0x(&DAT_,uVar8), iVar4 != 0 || ((bVar2 & 1) != 0)))) {
          uStack_c0 = uVar6;
          if (puVar1 != (ulonglong *)0x0) {
            uStack_c0 = *puVar1;
          }
          uStack_98 = uStack_c0 & 0xffffffffffffe000;
          lStack_b8 = uStack_98 + 0x100;
          uStack_c8 = 0;
          while (iVar4 = (int)uVar6, iVar4 < 8) {
            alStack_78[iVar4] = lStack_b8;
            uStack_c8 = iVar4 + 1;
            lStack_b8 = lStack_b8 + 0x400;
            uVar6 = (ulonglong)uStack_c8;
          }
          uStack_d8 = 0;
          uStack_e0 = 0;
          uStack_e8 = 0;
          uStack_f0 = 0;
          uStack_f8 = 0xf;
          (*_DAT_)(0,0,0x13b4628,0x2b0);
          *param_1 = 1;
        }
        _DAT_ = 0;
        lVar7 = (ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
        ;
        lVar5 = *(longlong *)(lVar7 + 0x100);
        if (lVar5 == 0) {
          (*_DAT_)();
          lVar5 = *(longlong *)(lVar7 + 0x100);
        }
        if (*(int *)(lVar5 + 0x22c) != 0) {
          (*_DAT_)();
        }
      }
    }
    func_0x(uStack_38 ^ (ulonglong)auStack_118);
    return;
  }
}

