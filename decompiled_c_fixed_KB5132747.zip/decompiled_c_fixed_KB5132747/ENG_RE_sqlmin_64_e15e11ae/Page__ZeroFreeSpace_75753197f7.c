
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  short *psVar1;
  ushort uVar2;
  longlong lVar3;
  uint uVar4;
  ulonglong uVar5;
  code *UNRECOVERED_JUMPTABLE;
  ulonglong uVar6;
  short *psVar7;
  ulonglong uVar8;
  undefined *puVar9;
  int iVar10;
  ulonglong uVar11;
  short *psVar12;
  short *psVar13;
  longlong lVar14;
  undefined8 uStack_100;
  undefined auStack_f8 [64];
  short asStack_b8 [2];
  int iStack_b4;
  byte *pbStack_b0;
  undefined8 uStack_a8;
  undefined8 uStack_9a;
  undefined2 uStack_92;
  undefined2 uStack_90;
  undefined6 uStack_8e;
  undefined4 uStack_80;
  longlong lStack_68;
  longlong lStack_50;
  longlong lStack_48;
  short *psStack_40;
  ulonglong uStack_38;
  
  uStack_38 = _DAT_ ^ (ulonglong)asStack_b8;
  uStack_100 = 0x100051;
  lStack_50 = param_1;
  func_0x(param_1,0xffffffff);
  uVar2 = *(ushort *)(param_1 + 0x16);
  uVar6 = (ulonglong)uVar2;
  uStack_80 = 0x60;
  if (uVar2 == 0) {
    *(undefined2 *)(param_1 + 0x1e) = 0x60;
    uVar4 = 0x60;
  }
  else {
    uVar4 = (uint)*(ushort *)(param_1 + 0x1e);
  }
  puVar9 = auStack_f8;
  if ((uint)*(ushort *)(param_1 + 0x1c) != (0x1000 - (uint)uVar2) * 2 - uVar4) {
    uVar8 = 0;
    iVar10 = 0;
    uVar5 = uVar6 * 8 + 0xf;
    if (uVar5 <= uVar6 * 8) {
      uVar5 = 0xffffffffffffff0;
    }
    uVar5 = uVar5 & 0xfffffffffffffff0;
    uStack_100 = 0x1000bd;
    uVar11 = uVar8;
    func_0x();
    lVar3 = -uVar5;
    uVar5 = uVar11 & 0xffffffff;
    psVar1 = (short *)((longlong)asStack_b8 + lVar3);
    psStack_40 = psVar1;
    if ((ushort)uVar11 < (ushort)uVar6) {
      psVar7 = (short *)(param_1 + 0x1ffe);
      psVar12 = psVar1;
      do {
        psVar13 = psVar12;
        if (*psVar7 != 0) {
          uVar8 = (ulonglong)((int)uVar8 + 1);
          psVar13 = psVar12 + 4;
          *psVar12 = *psVar7;
          *(int *)(psVar12 + 2) = (int)uVar5;
        }
        iVar10 = (int)uVar8;
        uVar4 = (int)uVar5 + 1;
        uVar5 = (ulonglong)uVar4;
        psVar7 = psVar7 + -1;
        psVar12 = psVar13;
      } while ((int)uVar4 < (int)(uint)*(ushort *)(param_1 + 0x16));
    }
    lVar14 = (longlong)iVar10;
    lStack_48 = lVar14;
    *(undefined8 *)(auStack_f8 + lVar3 + -8) = 0x100128;
    (*_DAT_)(psVar1,lVar14,8,0xfffffffffec22390);
    puVar9 = auStack_f8 + lVar3;
    if (0 < iVar10) {
      lStack_68 = 0;
      do {
        if (psVar1[lStack_68 * 4] != 0) {
          iStack_b4 = 0;
          pbStack_b0 = (byte *)((ulonglong)
                                *(ushort *)
                                 (param_1 +
                                 (0xfff - (longlong)
                                          *(int *)((longlong)&iStack_b4 + lStack_68 * 8 + lVar3)) *
                                 2) + param_1);
          uStack_9a = 0;
          uStack_90 = 0;
          uStack_8e = 0;
          uStack_a8 = 0;
          if ((*pbStack_b0 & 1) == 0) {
            asStack_b8[0] = 0;
            uStack_92 = 0;
            uStack_90 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100338 */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_b0 & 0xe) * 4 + 0x100c3c) -
                      0x1453e60))();
            return;
          }
          asStack_b8[0] = 1;
          UNRECOVERED_JUMPTABLE =
               (code *)((ulonglong)
                        *(uint *)((ulonglong)
                                  *(byte *)((longlong)(int)(*pbStack_b0 & 0x1c) + 0x100c1c) * 4 +
                                 0x100c0c) - 0x1453e60);
                    /* WARNING: Could not emulate address calculation at 0x001001b4 */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
          return;
        }
        lStack_68 = lStack_68 + 1;
        puVar9 = auStack_f8 + lVar3;
      } while (lStack_68 < lVar14);
    }
  }
  uVar2 = *(ushort *)(param_1 + 0x1e);
  iVar10 = (0x1000 - (uint)*(ushort *)(param_1 + 0x16)) * 2 - (uint)uVar2;
  if (iVar10 != 0) {
    *(undefined8 *)(puVar9 + -8) = 0x100bd6;
    func_0x((ulonglong)uVar2 + param_1,0,iVar10);
  }
  uVar6 = uStack_38 ^ (ulonglong)asStack_b8;
  *(undefined8 *)(puVar9 + -8) = 0x100be5;
  func_0x(uVar6);
  return;
}

