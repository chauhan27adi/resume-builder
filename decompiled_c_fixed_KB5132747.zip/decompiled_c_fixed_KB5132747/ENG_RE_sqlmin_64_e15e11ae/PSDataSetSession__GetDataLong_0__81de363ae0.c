
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,longlong *param_3,int *param_4)

{
  undefined *puVar1;
  byte *pbVar2;
  undefined8 uVar3;
  code *pcVar4;
  undefined8 uVar5;
  uint uVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  uint uVar10;
  ulonglong uVar11;
  undefined *puVar12;
  ulonglong uVar13;
  longlong lStackX_8;
  undefined4 auStackX_10 [2];
  longlong lStackX_18;
  undefined4 uStackX_20;
  undefined auStackX_24 [4];
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar7 = func_0x();
  lVar7 = -lVar7;
  puVar12 = &stack0xffffffffffffffc0 + lVar7;
  puVar1 = &stack0xfffffffffffffff0 + lVar7;
  *(undefined8 *)(&stack0xfffffffffffffff8 + lVar7) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00001fd0 + lVar7) = _DAT_ ^ (ulonglong)puVar1;
  uVar11 = 0;
  *(undefined8 *)((longlong)&uStackX_20 + lVar7 + -0x20) = 0;
  *(undefined8 *)((longlong)&lStackX_8 + lVar7) = 0;
  *(undefined4 *)((longlong)auStackX_10 + lVar7) = 0;
  *(undefined8 *)((longlong)&lStackX_18 + lVar7) = 0;
  *(undefined4 *)((longlong)&uStackX_20 + lVar7) = 0;
  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100069;
  func_0x(auStackX_24 + lVar7,0,0x1f9e);
  lVar9 = *param_3;
  uVar13 = uVar11;
  if ((*(byte *)(lVar9 + 0x38) & 8) != 0) {
    uVar13 = (longlong)&uStackX_20 + lVar7 + -0x20;
    *(uint *)((longlong)&uStackX_20 + lVar7 + -0x20) = (uint)*(ushort *)(lVar9 + 0x62);
    *(undefined4 *)((longlong)&uStackX_20 + lVar7) = 0x1f9e;
    *(undefined **)((longlong)&lStackX_18 + lVar7) = auStackX_24 + lVar7;
    *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1000b5;
    lVar8 = func_0x();
    lVar8 = -lVar8;
    puVar12 = &stack0xffffffffffffffc0 + lVar8 + lVar7;
    *(undefined **)((longlong)&lStackX_8 + lVar7) = &stack0xfffffffffffffff0 + lVar8 + lVar7;
    *(undefined8 *)((longlong)&uStack_48 + lVar8 + lVar7) = 0x1000c8;
    func_0x(&stack0xfffffffffffffff0 + lVar8 + lVar7,0);
  }
  *(undefined8 *)(param_1 + 0xf70) = 0;
  *(longlong **)(param_1 + 0xf78) = param_2;
  if ((*(ushort *)(lVar9 + 0x38) & 0x1000) != 0) {
    if ((*(byte *)(param_1 + 0xfc4) & 4) == 0) {
      uVar6 = **(uint **)(param_1 + 0x108);
      uVar10 = **(uint **)(param_1 + 0x108);
      *(undefined8 *)(puVar12 + 0x28) = *(undefined8 *)(param_1 + 0x10);
      *(uint *)(puVar12 + 0x20) = ((int)uVar6 >> 0x1f & 1U) + 1;
      uVar3 = *(undefined8 *)(param_1 + 0x1e8);
      *(undefined8 *)(puVar12 + -8) = 0x100133;
      func_0x
                (param_1 + 0xf90,uVar3,param_1 + 0xf68,((uVar10 & 0x4000000) != 0) + '\x01');
    }
    *(longlong *)(param_1 + 0xfc8) = param_1 + 0x2b8;
  }
  *(undefined8 *)(puVar12 + 0x28) = *(undefined8 *)(*(longlong *)(param_1 + 0x108) + 0x130);
  *(int **)(puVar12 + 0x20) = param_4;
  *(undefined8 *)(puVar12 + -8) = 0x10016f;
  func_0x(param_1 + 0xf90,param_3,uVar13,puVar1);
  if (*param_4 == 2) {
    pcVar4 = *(code **)(*param_2 + 0x10);
    *(undefined8 *)(puVar12 + -8) = 0x10017f;
    (*pcVar4)(param_2);
  }
  if (*(short *)(lVar9 + 0x3a) != 0) {
    if ((*(byte *)(lVar9 + 0x38) & 8) != 0) {
      *(undefined8 *)(param_1 + 0xf70) = 0;
      *(longlong **)(param_1 + 0xf78) = param_2;
      *(longlong **)(puVar12 + 0x28) = param_3;
      *(undefined8 *)(puVar12 + 0x20) = *(undefined8 *)(param_1 + 0x1e8);
      *(undefined8 *)(puVar12 + -8) = 0x1001bb;
      func_0x();
      *param_4 = 0;
    }
    lVar9 = *(longlong *)(*(longlong *)(param_1 + 0x108) + 0x130);
    if (lVar9 != 0) {
      *(longlong *)(puVar12 + 0x20) = lVar9;
      uVar3 = *(undefined8 *)(param_1 + 0x10);
      uVar5 = *(undefined8 *)(param_1 + 0x18);
      *(undefined8 *)(puVar12 + -8) = 0x1001ea;
      func_0x(uVar5,uVar3,param_2,param_3);
    }
  }
  lVar9 = *(longlong *)((longlong)&lStackX_8 + lVar7);
  if ((lVar9 != 0) && (uVar6 = *(uint *)((longlong)&uStackX_20 + lVar7 + -0x20), uVar6 != 0)) {
    do {
      lVar8 = uVar11 * 0x40;
      if ((*(byte *)(lVar8 + 0x18 + lVar9) & 4) != 0) {
        uVar3 = *(undefined8 *)(lVar8 + 0x20 + lVar9);
        *(undefined8 *)(puVar12 + -8) = 0x100218;
        (*_DAT_)(uVar3);
        pbVar2 = (byte *)(lVar8 + 0x18 + *(longlong *)((longlong)&lStackX_8 + lVar7));
        *pbVar2 = *pbVar2 & 0xfb;
        lVar9 = *(longlong *)((longlong)&lStackX_8 + lVar7);
        uVar6 = *(uint *)((longlong)&uStackX_20 + lVar7 + -0x20);
      }
      uVar10 = (int)uVar11 + 1;
      uVar11 = (ulonglong)uVar10;
    } while (uVar10 < uVar6);
  }
  uVar13 = *(ulonglong *)(&stack0x00001fd0 + lVar7);
  *(undefined8 *)(puVar12 + -8) = 0x10023d;
  func_0x(uVar13 ^ (ulonglong)puVar1);
  return;
}

