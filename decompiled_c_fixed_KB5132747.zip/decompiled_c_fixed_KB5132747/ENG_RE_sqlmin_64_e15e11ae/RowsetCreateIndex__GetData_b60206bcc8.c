
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong *param_3,longlong param_4)

{
  ushort *puVar1;
  short *psVar2;
  undefined8 *puVar3;
  undefined4 *puVar4;
  int *piVar5;
  byte bVar6;
  char cVar7;
  short sVar8;
  ushort uVar9;
  int iVar10;
  longlong lVar11;
  longlong lVar12;
  longlong lVar13;
  undefined8 uVar14;
  longlong lVar15;
  byte *pbVar16;
  code *UNRECOVERED_JUMPTABLE;
  ushort uVar17;
  uint uVar18;
  uint uVar19;
  ulonglong uVar20;
  undefined8 unaff_RBX;
  uint *puVar21;
  undefined *puVar22;
  undefined *puVar23;
  int iVar24;
  uint *puVar25;
  ulonglong uVar26;
  uint *puVar27;
  longlong *plVar28;
  byte *pbVar29;
  ulonglong uVar30;
  uint uVar31;
  uint uVar32;
  ushort *puVar33;
  undefined4 uVar34;
  undefined auStackX_8 [24];
  uint auStackX_20 [2];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  puVar22 = &stack0xffffffffffffffc8 + lVar11;
  *(undefined8 *)(&stack0x000002b0 + lVar11) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002430 + lVar11) = unaff_RBX;
  *(ulonglong *)(&stack0x000023d8 + lVar11) = _DAT_ ^ (ulonglong)(auStackX_8 + lVar11);
  *(longlong *)(&stack0x000000d8 + lVar11) = param_1;
  puVar27 = (uint *)0x0;
  uVar20 = 0;
  *(undefined4 *)(&stack0x0000008c + lVar11) = 0;
  *(undefined8 *)(&stack0x000000a0 + lVar11) = 0;
  *(undefined4 *)(&stack0x000000a8 + lVar11) = 0;
  if (param_3 == (longlong *)0x0) {
    uVar31 = *(uint *)(&stack0x00000088 + lVar11);
    *(uint *)((longlong)auStackX_20 + lVar11) = uVar31;
    lVar12 = *(longlong *)(&stack0x00000080 + lVar11);
    *(longlong *)(&stack0x00000058 + lVar11) = lVar12;
    plVar28 = *(longlong **)(&stack0x00000078 + lVar11);
  }
  else {
    puVar3 = *(undefined8 **)(param_1 + 0x20);
    if ((*(int *)(puVar3 + 5) == *(int *)(param_3 + 1)) &&
       (*param_3 == (ulonglong)*(uint6 *)((longlong)puVar3 + 0x14) * 0x10000)) {
      UNRECOVERED_JUMPTABLE = *(code **)*puVar3;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1000a6;
      sVar8 = (*UNRECOVERED_JUMPTABLE)(puVar3);
      if (*(short *)((longlong)param_3 + 0xc) != sVar8) goto LAB_;
      if (param_3[0x15] != 0) {
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar11) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar11);
        UNLOCK();
      }
    }
    else {
LAB_:
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1000c7;
      func_0x(param_3,puVar3);
    }
    lVar13 = *(longlong *)(param_1 + 0x20);
    uVar9 = *(ushort *)((longlong)param_3 + 0x62);
    uVar31 = (uint)uVar9;
    *(uint *)((longlong)auStackX_20 + lVar11) = (uint)uVar9;
    uVar17 = *(ushort *)(param_3 + 7);
    *(longlong **)(&stack0x00000078 + lVar11) = param_3;
    *(uint *)(&stack0x00000088 + lVar11) = (uint)uVar9;
    *(longlong *)(&stack0x00000090 + lVar11) = param_4;
    *(undefined8 *)(&stack0x00000098 + lVar11) = 0;
    *(undefined8 *)(&stack0x000000d0 + lVar11) = 0;
    lVar12 = param_3[0xe];
    *(longlong *)(&stack0x00000058 + lVar11) = lVar12;
    *(longlong *)(&stack0x00000080 + lVar11) = lVar12;
    plVar28 = param_3;
    if ((uVar17 & 0x400) == 0) {
      if (lVar13 != 0) {
        lVar13 = **(longlong **)(*(longlong *)(lVar13 + 8) + 0x160);
        *(undefined8 *)(&stack0x000000a0 + lVar11) = *(undefined8 *)(lVar13 + 0xa8);
        *(undefined4 *)(&stack0x000000a8 + lVar11) = *(undefined4 *)(lVar13 + 0xb0);
      }
      uVar20 = (ulonglong)(*(uint *)(&stack0x0000008c + lVar11) | 0x10);
      *(uint *)(&stack0x0000008c + lVar11) = *(uint *)(&stack0x0000008c + lVar11) | 0x10;
    }
    else {
      *(uint *)((longlong)auStackX_20 + lVar11) = (uint)uVar9;
      if (lVar13 != 0) {
        lVar13 = **(longlong **)(*(longlong *)(lVar13 + 8) + 0x160);
        *(undefined8 *)(&stack0x000000a0 + lVar11) = *(undefined8 *)(lVar13 + 0xa8);
        *(undefined4 *)(&stack0x000000a8 + lVar11) = *(undefined4 *)(lVar13 + 0xb0);
      }
      uVar18 = *(uint *)(&stack0x0000008c + lVar11);
      uVar20 = (ulonglong)(uVar18 | 0x10);
      *(uint *)(&stack0x0000008c + lVar11) = uVar18 | 0x10;
      if (param_4 != 0) {
        *(undefined8 *)(&stack0x000000b0 + lVar11) = 0;
        *(undefined8 *)(&stack0x000000c0 + lVar11) = 0;
        *(undefined8 *)(&stack0x000000b8 + lVar11) = 0;
        if ((uVar18 & 4) == 0) {
          uVar20 = (ulonglong)(uVar18 | 0x12);
          *(uint *)(&stack0x0000008c + lVar11) = uVar18 | 0x12;
        }
      }
    }
  }
  *(undefined8 *)(&stack0x000001c8 + lVar11) = 0x831730;
  psVar2 = (short *)(param_1 + 0x168);
  *(short **)(&stack0x00000030 + lVar11) = psVar2;
  *(short **)(&stack0x000001d0 + lVar11) = psVar2;
  *(undefined (*) [16])(&stack0x000001d8 + lVar11) = ZEXT816(0);
  if ((*(short *)((longlong)param_3 + 0x3a) == 0) && (*(int *)(param_3 + 10) == 0)) {
    lVar13 = *(longlong *)(param_1 + 0x20);
    *(longlong *)(&stack0x00000060 + lVar11) = lVar13;
    if ((*(byte *)(plVar28 + 6) & 1) != 0) {
      puVar1 = (ushort *)(param_1 + 0x16a);
      if (*psVar2 == 0) {
        if ((**(byte **)(param_1 + 0x170) & 0x10) == 0) {
          uVar18 = 0;
        }
        else {
          uVar18 = (uint)*(ushort *)(*(byte **)(param_1 + 0x170) + *(uint *)(param_1 + 0x178));
        }
      }
      else {
        uVar18 = (uint)*puVar1;
      }
      if (*(uint *)(plVar28 + 3) <= uVar18) {
        *psVar2 = 0;
        uVar17 = *(ushort *)(*(longlong *)(&stack0x00000078 + lVar11) + 0x62);
        *(uint *)(&stack0x00000068 + lVar11) = (uint)uVar17;
        puVar21 = *(uint **)(&stack0x00000080 + lVar11);
        uVar31 = 0;
        *(undefined4 *)((longlong)auStackX_20 + lVar11) = 0;
        puVar23 = &stack0xffffffffffffffc8 + lVar11;
        if (uVar17 != 0) {
          do {
            iVar10 = 1;
            puVar25 = (uint *)0x0;
            cVar7 = *(char *)(puVar21 + 0x10);
            if (cVar7 == '\x01') {
              if ((*(byte *)((longlong)puVar21 + 6) & 0x10) == 0) {
                uVar18 = *(byte *)((ulonglong)(*(ushort *)(puVar21 + 1) - 1 >> 3) +
                                   (ulonglong)*(uint *)(param_1 + 0x178) + 2 +
                                  *(longlong *)(param_1 + 0x170)) >>
                         ((byte)(*(ushort *)(puVar21 + 1) - 1) & 7) & 1;
              }
              else {
                *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = &stack0x00000234 + lVar11;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1014b3;
                func_0x(puVar1,puVar21,1,&stack0x00000160 + lVar11);
                uVar18 = *(uint *)(&stack0x00000160 + lVar11);
              }
              if (uVar18 == 0) goto LAB_;
LAB_:
              lVar12 = *(longlong *)(&stack0x00000090 + lVar11);
              if ((*(byte *)(*(longlong *)(puVar21 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar12 = *(longlong *)(&stack0x00000098 + lVar11);
              }
              *(undefined *)(lVar12 + *(longlong *)(puVar21 + 0xc)) = 3;
              puVar25 = puVar27;
            }
            else {
              if (cVar7 == '\x02') {
LAB_:
                uVar17 = *(ushort *)(puVar21 + 0xf);
                if ((*(byte *)((longlong)puVar21 + 6) & 0x10) == 0) {
LAB_:
                  *(uint *)(&stack0x00000038 + lVar11) = (uint)uVar17;
                  puVar25 = (uint *)((longlong)(int)*puVar21 + *(longlong *)(param_1 + 0x170));
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = &stack0x0000015c + lVar11;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101541;
                  func_0x(puVar1,puVar21,0,&stack0x00000238 + lVar11);
                  if (*(int *)(&stack0x0000015c + lVar11) != 0) goto LAB_;
                  puVar25 = *(uint **)(puVar21 + 2) + 1;
                  uVar18 = **(uint **)(puVar21 + 2);
                  if ((uVar17 != 0) && (uVar18 != uVar17)) {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101585;
                    (*_DAT_)(1,0xc3a2b0,0xc38c18,0x381);
                  }
                  *(uint *)(&stack0x00000038 + lVar11) = uVar18;
                }
                lVar12 = *(longlong *)(&stack0x00000090 + lVar11);
                if ((*(byte *)(*(longlong *)(puVar21 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar12 = *(longlong *)(&stack0x00000098 + lVar11);
                }
                *(undefined *)(lVar12 + *(longlong *)(puVar21 + 0xc)) = 0;
              }
              else {
                if (cVar7 == '\x03') {
                  if ((*(byte *)((longlong)puVar21 + 6) & 0x10) == 0) {
                    uVar18 = *(byte *)((ulonglong)(*(ushort *)(puVar21 + 1) - 1 >> 3) +
                                       (ulonglong)*(uint *)(param_1 + 0x178) + 2 +
                                      *(longlong *)(param_1 + 0x170)) >>
                             ((byte)(*(ushort *)(puVar21 + 1) - 1) & 7) & 1;
                  }
                  else {
                    *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = &stack0x0000022c + lVar11;
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c52;
                    func_0x(puVar1,puVar21,1,&stack0x00000170 + lVar11);
                    uVar18 = *(uint *)(&stack0x00000170 + lVar11);
                  }
                  if (uVar18 != 0) goto LAB_;
                }
                else if (cVar7 != '\x04') {
                  if (cVar7 == '\b') {
                    iVar24 = puVar21[0x10] << 0xc;
                    uVar17 = *(ushort *)(puVar21 + 0xf);
                    if ((*puVar21 & 0xc0000000) == 0x80000000) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100bb0;
                      iVar10 = func_0x(puVar1);
                      if (iVar10 != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100bcb;
                        puVar25 = (uint *)func_0x(param_1 + 0x192,puVar21,
                                                          &stack0x00000038 + lVar11,
                                                          &stack0x00000228 + lVar11);
                        goto LAB_;
                      }
                      *(undefined4 *)(&stack0x00000038 + lVar11) = 0;
                      uVar17 = *(ushort *)(*(longlong *)(puVar21 + 0x12) + 0x2a);
                    }
                    else {
                      if ((iVar24 < 0) || ((*(byte *)((longlong)puVar21 + 6) & 0x10) != 0)) {
                        *(undefined **)(&stack0xffffffffffffffe8 + lVar11) =
                             &stack0x000000e4 + lVar11;
                        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10034f;
                        func_0x(puVar1,puVar21,iVar24 < 0,&stack0x000000e0 + lVar11)
                        ;
                        if ((iVar24 < 0) && (*(int *)(&stack0x000000e0 + lVar11) != 0)) {
                          *(undefined4 *)(&stack0x00000038 + lVar11) = 0;
                          puVar25 = (uint *)0x0;
                          goto LAB_;
                        }
                        iVar10 = *(int *)(&stack0x000000e4 + lVar11);
                      }
                      else {
                        *(undefined4 *)(&stack0x000000e0 + lVar11) = 0;
                        *(undefined4 *)(&stack0x000000e4 + lVar11) = 1;
                      }
                      if ((iVar10 == 0) && ((*(byte *)((longlong)puVar21 + 6) & 0x10) != 0)) {
                        puVar4 = *(undefined4 **)(puVar21 + 2);
                        *(undefined4 *)(&stack0x00000038 + lVar11) = *puVar4;
                        puVar25 = puVar4 + 1;
                      }
                      else if ((int)*puVar21 < 0) {
                        if (*(int *)(param_1 + 0x16c) == 0) {
                          *puVar1 = 0;
                          uVar18 = *(uint *)(param_1 + 0x178);
                          uVar20 = (ulonglong)uVar18;
                          *(uint *)(param_1 + 0x17c) = uVar18;
                          pbVar29 = *(byte **)(param_1 + 0x170);
                          bVar6 = *pbVar29;
                          if ((bVar6 & 0x10) != 0) {
                            uVar18 = uVar18 + 2 + (*(ushort *)(pbVar29 + uVar20) + 7 >> 3);
                            uVar20 = (ulonglong)uVar18;
                            *(uint *)(param_1 + 0x17c) = uVar18;
                            bVar6 = *pbVar29;
                          }
                          if ((bVar6 & 0x20) == 0) {
                            *(int *)(param_1 + 0x16c) = (int)uVar20;
                            *(undefined2 *)(param_1 + 0x184) = 0;
                            *(uint *)(param_1 + 0x180) = uVar18;
                          }
                          else {
                            puVar33 = (ushort *)(pbVar29 + uVar20);
                            *(ushort **)(&stack0x00000070 + lVar11) = puVar33;
                            uVar17 = *puVar33;
                            *(ushort *)(param_1 + 0x184) = uVar17;
                            if (uVar17 == 0) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1004a4;
                              cVar7 = func_0x(0x119c460);
                              if (cVar7 != '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1004ad;
                                lVar12 = func_0x();
                                if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1004c7;
                                  cVar7 = func_0x(0x119c460);
                                  if (cVar7 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1004e3;
                                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100509;
                                    (*_DAT_)(1,0xa8be6c,0xbabf58,0x80f);
                                  }
                                }
                              }
                              uVar14 = *(undefined8 *)(param_1 + 0x170);
                              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100517;
                              func_0x(uVar14,3);
                              uVar17 = *(ushort *)(param_1 + 0x184);
                              uVar18 = *(uint *)(param_1 + 0x17c);
                            }
                            uVar18 = uVar18 + (uVar17 + 1) * 2;
                            *(uint *)(param_1 + 0x180) = uVar18;
                            if (0x1f9e < uVar18) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100546;
                              cVar7 = func_0x(0x119c460);
                              if (cVar7 != '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10054f;
                                lVar12 = func_0x();
                                if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100569;
                                  cVar7 = func_0x(0x119c460);
                                  if (cVar7 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100585;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1005ab;
                                    (*_DAT_)(1,0xa8be6c,0xbabf58,0x816);
                                  }
                                }
                              }
                              uVar14 = *(undefined8 *)(param_1 + 0x170);
                              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1005b9;
                              func_0x(uVar14,4);
                              uVar17 = *(ushort *)(param_1 + 0x184);
                              uVar18 = *(uint *)(param_1 + 0x180);
                            }
                            uVar20 = (ulonglong)uVar17;
                            uVar17 = puVar33[uVar20];
                            *(uint *)(param_1 + 0x16c) = uVar17 & 0x7fff;
                            if ((uVar17 & 0x7fff) < uVar18) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1005e7;
                              cVar7 = func_0x(0x119c460);
                              if (cVar7 != '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1005f0;
                                lVar12 = func_0x();
                                if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10060a;
                                  cVar7 = func_0x(0x119c460);
                                  if (cVar7 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100626;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10064c;
                                    (*_DAT_)(1,0xa8be6c,0xbabf58,0x81d);
                                  }
                                }
                              }
                              uVar14 = *(undefined8 *)(param_1 + 0x170);
                              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10065a;
                              func_0x(uVar14,4);
                              uVar18 = *(uint *)(param_1 + 0x180);
                              uVar20 = (ulonglong)*(ushort *)(param_1 + 0x184);
                            }
                            if ((short)uVar20 != 0) {
                              do {
                                puVar33 = puVar33 + 1;
                                uVar31 = *puVar33 & 0x7fff;
                                if ((uVar31 < uVar18) || (*(uint *)(param_1 + 0x16c) < uVar31)) {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10069f;
                                  cVar7 = func_0x(0x119c460);
                                  if (cVar7 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1006a8;
                                    lVar12 = func_0x();
                                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1006c2;
                                      cVar7 = func_0x(0x119c460);
                                      if (cVar7 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1006de;
                                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                                        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100702;
                                        (*_DAT_)(1,0xa8be6c,0xbabf58,0x82a);
                                      }
                                    }
                                  }
                                  uVar14 = *(undefined8 *)(param_1 + 0x170);
                                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100710;
                                  func_0x(uVar14,4);
                                }
                                uVar32 = (int)puVar25 + 1;
                                puVar25 = (uint *)(ulonglong)uVar32;
                                uVar20 = (ulonglong)*(ushort *)(param_1 + 0x184);
                                uVar18 = uVar31;
                              } while ((int)uVar32 < (int)(uint)*(ushort *)(param_1 + 0x184));
                              puVar33 = *(ushort **)(&stack0x00000070 + lVar11);
                              uVar31 = *(uint *)((longlong)auStackX_20 + lVar11);
                            }
                            if ((short)puVar33[(ulonglong)((int)uVar20 - 1) + 1] < 0) {
                              do {
                                lVar12 = *(longlong *)(param_1 + 0x170);
                                lVar13 = (ulonglong)*(uint *)(param_1 + 0x17c) + lVar12;
                                uVar18 = *(ushort *)(lVar13 + uVar20 * 2) & 0x7fff;
                                if ((int)uVar20 == 1) {
                                  uVar32 = *(uint *)(param_1 + 0x180);
                                  uVar19 = uVar32;
LAB_:
                                  if ((uVar18 < uVar32) || (*(uint *)(param_1 + 0x16c) < uVar18))
                                  goto LAB_;
                                }
                                else {
                                  uVar32 = *(ushort *)(lVar13 + -2 + uVar20 * 2) & 0x7fff;
                                  uVar19 = *(uint *)(param_1 + 0x180);
                                  if (uVar19 <= uVar32) goto LAB_;
LAB_:
                                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10078c;
                                  func_0x(lVar12,7);
                                  uVar19 = *(uint *)(param_1 + 0x180);
                                }
                                if ((uVar32 < uVar19) || (*(uint *)(param_1 + 0x16c) < uVar32))
                                goto LAB_;
                                uVar17 = *(ushort *)
                                          ((ulonglong)uVar32 + *(longlong *)(param_1 + 0x170));
                                if (uVar17 == 5) {
                                  *puVar1 = *puVar1 | 2;
                                  *(short *)(param_1 + 0x184) = *(short *)(param_1 + 0x184) + -1;
                                  *(short *)(param_1 + 0x192) = (short)uVar32;
                                  uVar20 = *(ulonglong *)(param_1 + 0x170);
                                  uVar17 = *(ushort *)((ulonglong)(uVar32 & 0xffff) + 2 + uVar20);
                                  uVar9 = *(ushort *)(param_1 + 0x194) & 0xc7ff;
                                  if ((uVar17 >> 0xe & 1) != 0) {
                                    uVar9 = uVar17 & 0x3800 | uVar9;
                                  }
                                  *(ushort *)(param_1 + 0x194) = uVar9;
                                  uVar17 = (uVar9 ^ *(ushort *)
                                                     ((ulonglong)(uVar32 & 0xffff) + 2 + uVar20)) &
                                           0x7ff ^ uVar9;
                                  *(ushort *)(param_1 + 0x194) = uVar17;
                                  uVar30 = (ulonglong)*(ushort *)(param_1 + 0x192);
                                  uVar26 = uVar30 + 4 +
                                           (ulonglong)((uVar17 & 0x7ff) * 2) +
                                           uVar20 + (uVar9 >> 0xb & 7) * 2;
                                  if (uVar26 < uVar30 + uVar20) {
                                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10089d;
                                    func_0x(uVar30 + uVar20,0x19);
                                    uVar17 = *(ushort *)(param_1 + 0x194);
                                    uVar30 = (ulonglong)*(ushort *)(param_1 + 0x192);
                                    uVar20 = (ulonglong)*(uint *)(param_1 + 0x170);
                                  }
                                  if (uVar18 - uVar32 <
                                      (((uVar17 & 0x7ff) * 2 - (int)uVar30) - (int)uVar20) +
                                      (int)uVar26) {
                                    lVar12 = *(longlong *)(param_1 + 0x170);
                                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1008d5;
                                    func_0x(uVar30 + lVar12,0x19);
                                    uVar17 = *(ushort *)(param_1 + 0x194);
                                  }
                                  if ((uVar17 & 0x3800) != 0) {
                                    puVar33 = (ushort *)
                                              (*(longlong *)(param_1 + 0x170) +
                                              (ulonglong)*(ushort *)(param_1 + 0x192) + 4);
                                    iVar10 = 0;
                                    if ((uVar17 & 0x3800) != 0) {
                                      do {
                                        if ((uVar17 & 0x7ff) < (*puVar33 & 0x7ff)) {
                                          uVar17 = *(ushort *)(param_1 + 0x192);
                                          lVar12 = *(longlong *)(param_1 + 0x170);
                                          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100927;
                                          func_0x((ulonglong)uVar17 + lVar12,0x1a);
                                          uVar17 = *(ushort *)(param_1 + 0x194);
                                        }
                                        iVar10 = iVar10 + 1;
                                        puVar33 = puVar33 + 1;
                                      } while (iVar10 < (int)(uVar17 >> 0xb & 7));
                                    }
                                  }
                                  goto LAB_;
                                }
                                if (uVar17 < 0x400) goto LAB_;
                                *puVar1 = *puVar1 | 1;
                                uVar17 = *(short *)(param_1 + 0x184) - 1;
                                *(ushort *)(param_1 + 0x184) = uVar17;
                                if (uVar17 == 0) goto LAB_;
                                uVar20 = (ulonglong)uVar17;
                              } while ((short)puVar33[(ulonglong)(uVar17 - 1) + 1] < 0);
                              pbVar29 = *(byte **)(param_1 + 0x170);
                            }
                            else {
LAB_:
                              pbVar29 = *(byte **)(param_1 + 0x170);
                            }
                          }
                          if ((*pbVar29 & 0x40) == 0) {
                            *(undefined4 *)(param_1 + 0x18e) = 0;
                          }
                          else {
                            *(int *)(param_1 + 0x18e) = *(int *)(param_1 + 0x16c);
                            *(int *)(param_1 + 0x16c) = *(int *)(param_1 + 0x16c) + 0xe;
                            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100972;
                            uVar14 = func_0x(puVar1);
                            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100981;
                            func_0x(uVar14,&stack0x00000240 + lVar11);
                            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10098d;
                            iVar10 = func_0x(&stack0x00000240 + lVar11);
                            *(int *)(param_1 + 0x16c) = *(int *)(param_1 + 0x16c) + iVar10;
                          }
                          uVar18 = *(uint *)(param_1 + 0x16c);
                          if ((*(ulonglong *)(param_1 + 0x186) != 0) &&
                             (*(ulonglong *)(param_1 + 0x186) <
                              (ulonglong)uVar18 + *(longlong *)(param_1 + 0x170))) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1009c0;
                            cVar7 = func_0x(0x119c460);
                            if (cVar7 != '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1009c9;
                              lVar12 = func_0x();
                              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1009e3;
                                cVar7 = func_0x(0x119c460);
                                if (cVar7 == '\0') {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1009ff;
                                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                                }
                                else {
                                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100a23;
                                  (*_DAT_)(1,0xa8be6c,0xbabf58,0x886);
                                }
                              }
                            }
                            uVar14 = *(undefined8 *)(param_1 + 0x170);
                            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100a31;
                            func_0x(uVar14,0x12);
                            uVar18 = *(uint *)(param_1 + 0x16c);
                          }
                          if (0x3f3b < uVar18 - 1) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100a4a;
                            cVar7 = func_0x(0x119c460);
                            if (cVar7 != '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100a53;
                              lVar12 = func_0x();
                              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100a6d;
                                cVar7 = func_0x(0x119c460);
                                if (cVar7 == '\0') {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100a89;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                                }
                                else {
                                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100aad;
                                  (*_DAT_)(1,0xa8be6c,0xbabf58,0x88b);
                                }
                              }
                            }
                            uVar14 = *(undefined8 *)(param_1 + 0x170);
                            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100abb;
                            func_0x(uVar14,5);
                          }
                        }
LAB_:
                        sVar8 = -*(short *)puVar21;
                        if ((*(byte *)((longlong)puVar21 + 6) & 0x10) != 0) {
                          *(undefined **)(&stack0xffffffffffffffe8 + lVar11) =
                               &stack0x00000174 + lVar11;
                          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100aec;
                          func_0x(puVar1,puVar21,0,&stack0x00000224 + lVar11);
                          if (*(int *)(&stack0x00000174 + lVar11) == 0) {
                            puVar4 = *(undefined4 **)(puVar21 + 2);
                            *(undefined4 *)(&stack0x00000038 + lVar11) = *puVar4;
                            puVar25 = puVar4 + 1;
                            goto LAB_;
                          }
                        }
                        lVar12 = (longlong)sVar8;
                        if ((uint)*(ushort *)(param_1 + 0x184) < (uint)(int)sVar8) {
                          *(undefined4 *)(&stack0x00000038 + lVar11) = 0;
                          puVar25 = *(uint **)(param_1 + 0x170);
                        }
                        else {
                          lVar13 = *(longlong *)(param_1 + 0x170);
                          lVar15 = (ulonglong)*(uint *)(param_1 + 0x17c) + lVar13;
                          if (sVar8 == 1) {
                            uVar18 = *(uint *)(*(longlong *)(&stack0x00000030 + lVar11) + 0x18);
                            uVar32 = *(ushort *)(lVar15 + lVar12 * 2) & 0x7fff;
LAB_:
                            if ((uVar32 < uVar18) || (*(uint *)(param_1 + 0x16c) < uVar32))
                            goto LAB_;
                          }
                          else {
                            uVar18 = *(ushort *)(lVar15 + -2 + lVar12 * 2) & 0x7fff;
                            lVar13 = *(longlong *)(param_1 + 0x170);
                            uVar32 = *(ushort *)(lVar15 + lVar12 * 2) & 0x7fff;
                            if (*(uint *)(*(longlong *)(&stack0x00000030 + lVar11) + 0x18) <= uVar18
                               ) goto LAB_;
LAB_:
                            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b7f;
                            func_0x(lVar13,7);
                            lVar13 = *(longlong *)(param_1 + 0x170);
                          }
                          *(uint *)(&stack0x00000038 + lVar11) = uVar32 - uVar18;
                          puVar25 = (uint *)((ulonglong)uVar18 + lVar13);
                        }
                      }
                      else if ((*(ushort *)((longlong)puVar21 + 6) & 8) == 0) {
                        if ((*(ushort *)((longlong)puVar21 + 6) & 0x10) != 0) {
                          *(undefined **)(&stack0xffffffffffffffe8 + lVar11) =
                               &stack0x0000016c + lVar11;
                          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1003ca;
                          func_0x(puVar1,puVar21,0,&stack0x00000220 + lVar11);
                          if (*(int *)(&stack0x0000016c + lVar11) == 0) {
                            puVar25 = *(uint **)(puVar21 + 2) + 1;
                            uVar18 = **(uint **)(puVar21 + 2);
                            if ((uVar17 != 0) && (uVar18 != uVar17)) {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10040e;
                              (*_DAT_)(1,0xc3a2b0,0xc38c18,0x381);
                            }
                            *(uint *)(&stack0x00000038 + lVar11) = uVar18;
                            goto LAB_;
                          }
                        }
                        *(uint *)(&stack0x00000038 + lVar11) = (uint)uVar17;
                        puVar25 = (uint *)((longlong)(int)*puVar21 + *(longlong *)(param_1 + 0x170))
                        ;
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100436;
                        puVar25 = (uint *)func_0x(puVar1,puVar21);
                      }
LAB_:
                      uVar17 = *(ushort *)(*(longlong *)(puVar21 + 0x12) + 0x2a);
                      if (puVar25 != (uint *)0x0) {
                        lVar12 = *(longlong *)(&stack0x00000090 + lVar11);
                        if ((uVar17 & 0x10) != 0) {
                          lVar12 = *(longlong *)(&stack0x00000098 + lVar11);
                        }
                        *(undefined *)(lVar12 + *(longlong *)(puVar21 + 0xc)) = 0;
                        goto LAB_;
                      }
                    }
                    lVar12 = *(longlong *)(&stack0x00000090 + lVar11);
                    if ((uVar17 & 0x10) != 0) {
                      lVar12 = *(longlong *)(&stack0x00000098 + lVar11);
                    }
                    *(undefined *)(lVar12 + *(longlong *)(puVar21 + 0xc)) = 3;
                    goto LAB_;
                  }
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0x8073d0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1002e1;
                  (*_DAT_)(1,0xc0d760,0xc3a128,0x27d);
                  puVar25 = puVar27;
                  goto LAB_;
                }
                if (*(int *)(param_1 + 0x16c) == 0) {
                  *puVar1 = 0;
                  uVar18 = *(uint *)(param_1 + 0x178);
                  uVar20 = (ulonglong)uVar18;
                  *(uint *)(param_1 + 0x17c) = uVar18;
                  pbVar29 = *(byte **)(param_1 + 0x170);
                  bVar6 = *pbVar29;
                  pbVar16 = pbVar29;
                  if ((bVar6 & 0x10) != 0) {
                    uVar18 = uVar18 + 2 + (*(ushort *)(pbVar29 + uVar20) + 7 >> 3);
                    uVar20 = (ulonglong)uVar18;
                    *(uint *)(param_1 + 0x17c) = uVar18;
                    bVar6 = *pbVar29;
                    pbVar16 = *(byte **)(param_1 + 0x170);
                  }
                  if ((bVar6 & 0x20) == 0) {
                    *(int *)(param_1 + 0x16c) = (int)uVar20;
                    *(undefined2 *)(param_1 + 0x184) = 0;
                    *(uint *)(param_1 + 0x180) = uVar18;
                  }
                  else {
                    puVar33 = (ushort *)(pbVar29 + uVar20);
                    *(ushort **)(&stack0x00000070 + lVar11) = puVar33;
                    uVar17 = *puVar33;
                    *(ushort *)(param_1 + 0x184) = uVar17;
                    if (uVar17 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d01;
                      cVar7 = func_0x(0x119c460);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d0a;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d24;
                          cVar7 = func_0x(0x119c460);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d40;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d66;
                            (*_DAT_)(1,0xa8be6c,0xbabf58,0x80f);
                          }
                        }
                      }
                      uVar14 = *(undefined8 *)(param_1 + 0x170);
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d72;
                      func_0x(uVar14,3);
                      uVar17 = *(ushort *)(param_1 + 0x184);
                      uVar18 = *(uint *)(param_1 + 0x17c);
                    }
                    uVar18 = uVar18 + (uVar17 + 1) * 2;
                    *(uint *)(param_1 + 0x180) = uVar18;
                    if (0x1f9e < uVar18) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100da2;
                      cVar7 = func_0x(0x119c460);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100dab;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100dc5;
                          cVar7 = func_0x(0x119c460);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100de1;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e07;
                            (*_DAT_)(1,0xa8be6c,0xbabf58,0x816);
                          }
                        }
                      }
                      uVar14 = *(undefined8 *)(param_1 + 0x170);
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e15;
                      func_0x(uVar14,4);
                      uVar17 = *(ushort *)(param_1 + 0x184);
                      uVar18 = *(uint *)(param_1 + 0x180);
                    }
                    uVar20 = (ulonglong)uVar17;
                    uVar17 = puVar33[uVar20];
                    *(uint *)(param_1 + 0x16c) = uVar17 & 0x7fff;
                    if ((uVar17 & 0x7fff) < uVar18) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e43;
                      cVar7 = func_0x(0x119c460);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e4c;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e66;
                          cVar7 = func_0x(0x119c460);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e82;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100ea8;
                            (*_DAT_)(1,0xa8be6c,0xbabf58,0x81d);
                          }
                        }
                      }
                      uVar14 = *(undefined8 *)(param_1 + 0x170);
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100eb6;
                      func_0x(uVar14,4);
                      uVar18 = *(uint *)(param_1 + 0x180);
                      uVar20 = (ulonglong)*(ushort *)(param_1 + 0x184);
                    }
                    if ((short)uVar20 != 0) {
                      do {
                        puVar33 = puVar33 + 1;
                        uVar31 = *puVar33 & 0x7fff;
                        if ((uVar31 < uVar18) || (*(uint *)(param_1 + 0x16c) < uVar31)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100eff;
                          cVar7 = func_0x(0x119c460);
                          if (cVar7 != '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100f08;
                            lVar12 = func_0x();
                            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100f22;
                              cVar7 = func_0x(0x119c460);
                              if (cVar7 == '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100f3e;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100f62;
                                (*_DAT_)(1,0xa8be6c,0xbabf58,0x82a);
                              }
                            }
                          }
                          uVar14 = *(undefined8 *)(param_1 + 0x170);
                          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100f70;
                          func_0x(uVar14,4);
                        }
                        uVar32 = (int)puVar25 + 1;
                        puVar25 = (uint *)(ulonglong)uVar32;
                        uVar20 = (ulonglong)*(ushort *)(param_1 + 0x184);
                        uVar18 = uVar31;
                      } while ((int)uVar32 < (int)(uint)*(ushort *)(param_1 + 0x184));
                      puVar33 = *(ushort **)(&stack0x00000070 + lVar11);
                      uVar31 = *(uint *)((longlong)auStackX_20 + lVar11);
                    }
                    if ((short)puVar33[(ulonglong)((int)uVar20 - 1) + 1] < 0) {
                      do {
                        lVar12 = *(longlong *)(param_1 + 0x170);
                        lVar13 = (ulonglong)*(uint *)(param_1 + 0x17c) + lVar12;
                        uVar18 = *(ushort *)(lVar13 + uVar20 * 2) & 0x7fff;
                        if ((int)uVar20 == 1) {
                          uVar32 = *(uint *)(param_1 + 0x180);
                          uVar19 = uVar32;
LAB_:
                          if ((uVar18 < uVar32) || (*(uint *)(param_1 + 0x16c) < uVar18))
                          goto LAB_;
                        }
                        else {
                          uVar32 = *(ushort *)(lVar13 + -2 + uVar20 * 2) & 0x7fff;
                          uVar19 = *(uint *)(param_1 + 0x180);
                          if (uVar19 <= uVar32) goto LAB_;
LAB_:
                          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100fec;
                          func_0x(lVar12,7);
                          uVar19 = *(uint *)(param_1 + 0x180);
                          lVar12 = *(longlong *)(param_1 + 0x170);
                        }
                        if ((uVar32 < uVar19) || (*(uint *)(param_1 + 0x16c) < uVar32))
                        goto LAB_;
                        if (*(ushort *)((ulonglong)uVar32 + lVar12) == 5) {
                          *puVar1 = *puVar1 | 2;
                          *(short *)(param_1 + 0x184) = *(short *)(param_1 + 0x184) + -1;
                          *(short *)(param_1 + 0x192) = (short)uVar32;
                          uVar20 = *(ulonglong *)(param_1 + 0x170);
                          uVar17 = *(ushort *)((ulonglong)(uVar32 & 0xffff) + 2 + uVar20);
                          uVar9 = *(ushort *)(param_1 + 0x194) & 0xc7ff;
                          if ((uVar17 >> 0xe & 1) != 0) {
                            uVar9 = uVar17 & 0x3800 | uVar9;
                          }
                          *(ushort *)(param_1 + 0x194) = uVar9;
                          uVar17 = (uVar9 ^ *(ushort *)((ulonglong)(uVar32 & 0xffff) + 2 + uVar20))
                                   & 0x7ff ^ uVar9;
                          *(ushort *)(param_1 + 0x194) = uVar17;
                          uVar30 = (ulonglong)*(ushort *)(param_1 + 0x192);
                          uVar26 = uVar20 + 4 +
                                   (ulonglong)((uVar17 & 0x7ff) * 2) +
                                   uVar30 + (uVar9 >> 0xb & 7) * 2;
                          if (uVar26 < uVar30 + uVar20) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1010fe;
                            func_0x(uVar30 + uVar20,0x19);
                            uVar17 = *(ushort *)(param_1 + 0x194);
                            uVar30 = (ulonglong)*(ushort *)(param_1 + 0x192);
                            uVar20 = (ulonglong)*(uint *)(param_1 + 0x170);
                          }
                          if (uVar18 - uVar32 <
                              (((uVar17 & 0x7ff) * 2 - (int)uVar30) - (int)uVar20) + (int)uVar26) {
                            lVar12 = *(longlong *)(param_1 + 0x170);
                            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101136;
                            func_0x(uVar30 + lVar12,0x19);
                            uVar17 = *(ushort *)(param_1 + 0x194);
                          }
                          if ((uVar17 & 0x3800) != 0) {
                            puVar33 = (ushort *)
                                      (*(longlong *)(param_1 + 0x170) +
                                      (ulonglong)*(ushort *)(param_1 + 0x192) + 4);
                            iVar10 = 0;
                            if ((uVar17 & 0x3800) != 0) {
                              do {
                                if ((uVar17 & 0x7ff) < (*puVar33 & 0x7ff)) {
                                  uVar17 = *(ushort *)(param_1 + 0x192);
                                  lVar12 = *(longlong *)(param_1 + 0x170);
                                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101188;
                                  func_0x((ulonglong)uVar17 + lVar12,0x1a);
                                  uVar17 = *(ushort *)(param_1 + 0x194);
                                }
                                iVar10 = iVar10 + 1;
                                puVar33 = puVar33 + 1;
                              } while (iVar10 < (int)(uVar17 >> 0xb & 7));
                            }
                          }
                          goto LAB_;
                        }
                        if (*(ushort *)((ulonglong)uVar32 + lVar12) < 0x400) goto LAB_;
                        *puVar1 = *puVar1 | 1;
                        uVar17 = *(short *)(param_1 + 0x184) - 1;
                        *(ushort *)(param_1 + 0x184) = uVar17;
                        if (uVar17 == 0) goto LAB_;
                        uVar20 = (ulonglong)uVar17;
                      } while ((short)puVar33[(ulonglong)(uVar17 - 1) + 1] < 0);
                      pbVar16 = *(byte **)(param_1 + 0x170);
                    }
                    else {
LAB_:
                      pbVar16 = *(byte **)(param_1 + 0x170);
                    }
                  }
                  if ((*pbVar16 & 0x40) == 0) {
                    *(undefined4 *)(param_1 + 0x18e) = 0;
                  }
                  else {
                    *(int *)(param_1 + 0x18e) = *(int *)(param_1 + 0x16c);
                    *(int *)(param_1 + 0x16c) = *(int *)(param_1 + 0x16c) + 0xe;
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1011d3;
                    uVar14 = func_0x(puVar1);
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1011e2;
                    func_0x(uVar14,&stack0x00000248 + lVar11);
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1011ee;
                    iVar10 = func_0x(&stack0x00000248 + lVar11);
                    *(int *)(param_1 + 0x16c) = *(int *)(param_1 + 0x16c) + iVar10;
                    pbVar16 = *(byte **)(param_1 + 0x170);
                  }
                  uVar18 = *(uint *)(param_1 + 0x16c);
                  if ((*(byte **)(param_1 + 0x186) != (byte *)0x0) &&
                     (*(byte **)(param_1 + 0x186) < pbVar16 + uVar18)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101224;
                    cVar7 = func_0x(0x119c460);
                    if (cVar7 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10122d;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101247;
                        cVar7 = func_0x(0x119c460);
                        if (cVar7 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101263;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101287;
                          (*_DAT_)(1,0xa8be6c,0xbabf58,0x886);
                        }
                      }
                    }
                    uVar14 = *(undefined8 *)(param_1 + 0x170);
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101295;
                    func_0x(uVar14,0x12);
                    uVar18 = *(uint *)(param_1 + 0x16c);
                  }
                  if (0x3f3b < uVar18 - 1) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1012ae;
                    cVar7 = func_0x(0x119c460);
                    if (cVar7 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1012b7;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1012d1;
                        cVar7 = func_0x(0x119c460);
                        if (cVar7 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1012ed;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101311;
                          (*_DAT_)(1,0xa8be6c,0xbabf58,0x88b);
                        }
                      }
                    }
                    uVar14 = *(undefined8 *)(param_1 + 0x170);
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10131f;
                    func_0x(uVar14,5);
                  }
                }
LAB_:
                sVar8 = -*(short *)puVar21;
                if ((*(byte *)((longlong)puVar21 + 6) & 0x10) == 0) {
LAB_:
                  lVar12 = (longlong)sVar8;
                  if ((uint)*(ushort *)(param_1 + 0x184) < (uint)(int)sVar8) {
                    *(undefined4 *)(&stack0x00000038 + lVar11) = 0;
                    puVar25 = *(uint **)(param_1 + 0x170);
                    iVar10 = 0;
                  }
                  else {
                    lVar13 = *(longlong *)(param_1 + 0x170);
                    lVar15 = (ulonglong)*(uint *)(param_1 + 0x17c) + lVar13;
                    if (sVar8 == 1) {
                      uVar20 = (ulonglong)*(uint *)(*(longlong *)(&stack0x00000030 + lVar11) + 0x18)
                      ;
                      uVar18 = *(ushort *)(lVar15 + lVar12 * 2) & 0x7fff;
LAB_:
                      if ((uVar18 < (uint)uVar20) || (*(uint *)(param_1 + 0x16c) < uVar18))
                      goto LAB_;
                    }
                    else {
                      uVar32 = *(ushort *)(lVar15 + -2 + lVar12 * 2) & 0x7fff;
                      uVar20 = (ulonglong)uVar32;
                      lVar13 = *(longlong *)(param_1 + 0x170);
                      uVar18 = *(ushort *)(lVar15 + lVar12 * 2) & 0x7fff;
                      if (*(uint *)(*(longlong *)(&stack0x00000030 + lVar11) + 0x18) <= uVar32)
                      goto LAB_;
LAB_:
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1013dd;
                      func_0x(lVar13,7);
                      lVar13 = *(longlong *)(param_1 + 0x170);
                    }
                    iVar10 = uVar18 - (int)uVar20;
                    *(int *)(&stack0x00000038 + lVar11) = iVar10;
                    puVar25 = (uint *)(uVar20 + lVar13);
                  }
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = &stack0x00000168 + lVar11;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101350;
                  func_0x(puVar1,puVar21,0,&stack0x00000230 + lVar11);
                  if (*(int *)(&stack0x00000168 + lVar11) != 0) goto LAB_;
                  piVar5 = *(int **)(puVar21 + 2);
                  iVar10 = *piVar5;
                  *(int *)(&stack0x00000038 + lVar11) = iVar10;
                  puVar25 = (uint *)(piVar5 + 1);
                }
                if (((puVar21[0x10] & 0x2000) != 0) && (iVar10 == 0)) {
                  *(undefined4 *)(&stack0x00000038 + lVar11) = 4;
                  puVar25 = (uint *)0x832a34;
                }
                lVar12 = *(longlong *)(&stack0x00000090 + lVar11);
                if ((*(byte *)(*(longlong *)(puVar21 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar12 = *(longlong *)(&stack0x00000098 + lVar11);
                }
                *(undefined *)(lVar12 + *(longlong *)(puVar21 + 0xc)) = 0;
                if ((1 << (**(byte **)(param_1 + 0x170) & 0xe) & 0x440U) != 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101458;
                  iVar10 = func_0x(puVar21);
                  if (iVar10 != 0) goto LAB_;
                }
                if ((uint)*(ushort *)(puVar21 + 0xf) < *(uint *)(&stack0x00000038 + lVar11)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101485;
                  (*_DAT_)(6,0x52,0x16,0x91);
                }
              }
LAB_:
              uVar18 = *(uint *)(&stack0x00000038 + lVar11);
              lVar12 = *(longlong *)(puVar21 + 0x12);
              if ((puVar21[0x10] & 0x800) == 0) {
                lVar13 = *(longlong *)(&stack0x00000090 + lVar11);
                if ((*(byte *)(lVar12 + 0x2a) & 0x10) != 0) {
                  lVar13 = *(longlong *)(&stack0x00000098 + lVar11);
                }
                lVar12 = *(longlong *)(puVar21 + 10);
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1015ee;
                func_0x(lVar13 + lVar12,puVar25);
              }
              else {
                uVar17 = *(ushort *)(lVar12 + 0x2a) & 0x10;
                if (*(int *)(lVar12 + 0x10) == 10) {
                  lVar12 = *(longlong *)(&stack0x00000090 + lVar11);
                  if (uVar17 != 0) {
                    lVar12 = *(longlong *)(&stack0x00000098 + lVar11);
                  }
                  *(uint **)(lVar12 + *(longlong *)(puVar21 + 10)) = puVar25;
                }
                else {
                  lVar12 = *(longlong *)(&stack0x00000090 + lVar11);
                  if (uVar17 != 0) {
                    lVar12 = *(longlong *)(&stack0x00000098 + lVar11);
                  }
                  uVar14 = *(undefined8 *)(*(longlong *)(puVar21 + 10) + lVar12);
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101621;
                  func_0x(uVar14,puVar25);
                }
              }
              if ((puVar21[0x10] & 0x100) != 0) {
                lVar12 = *(longlong *)(&stack0x00000090 + lVar11);
                if ((*(byte *)(*(longlong *)(puVar21 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar12 = *(longlong *)(&stack0x00000098 + lVar11);
                }
                *(ulonglong *)(lVar12 + *(longlong *)(*(longlong *)(puVar21 + 0x12) + 0x18)) =
                     (ulonglong)uVar18;
              }
            }
LAB_:
            uVar31 = uVar31 + 1;
            *(uint *)((longlong)auStackX_20 + lVar11) = uVar31;
            puVar21 = puVar21 + 0x14;
            puVar23 = &stack0xffffffffffffffc8 + lVar11;
            puVar27 = puVar25;
          } while (uVar31 < *(uint *)(&stack0x00000068 + lVar11));
        }
        goto LAB_;
      }
    }
    if (*psVar2 == 0) {
      *psVar2 = 0;
      puVar23 = &stack0xffffffffffffffc8 + lVar11;
      if (((&stack0x0000008c)[lVar11] & 0x10) != 0) {
        *(int *)(&stack0x00000068 + lVar11) = *(int *)(&stack0x00000088 + lVar11);
        lVar12 = *(longlong *)(&stack0x00000080 + lVar11);
        *(longlong *)(&stack0x00000058 + lVar11) = lVar12;
        uVar31 = 0;
        *(undefined4 *)((longlong)auStackX_20 + lVar11) = 0;
        puVar23 = &stack0xffffffffffffffc8 + lVar11;
        if (*(int *)(&stack0x00000088 + lVar11) != 0) {
          do {
            if (*(byte *)(lVar12 + 0x40) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(lVar12 + 0x40) * 4 + 0x107478) -
                           0x1d13160);
                    /* WARNING: Could not emulate address calculation at 0x001016f7 */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
              return;
            }
            uVar18 = *(uint *)(lVar12 + 0x40);
            if ((uVar18 >> 10 & 1) != 0) {
              lVar13 = *(longlong *)(&stack0x00000090 + lVar11);
              if ((*(byte *)(*(longlong *)(lVar12 + 0x48) + 0x2a) & 0x10) != 0) {
                lVar13 = *(longlong *)(&stack0x00000098 + lVar11);
              }
              *(undefined *)(lVar13 + *(longlong *)(lVar12 + 0x30)) = 3;
              uVar18 = *(uint *)(lVar12 + 0x40);
            }
            if ((uVar18 >> 9 & 1) != 0) {
              *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) =
                   *(undefined4 *)(&stack0x00000028 + lVar11);
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103d9c;
              func_0x();
            }
            uVar31 = uVar31 + 1;
            *(uint *)((longlong)auStackX_20 + lVar11) = uVar31;
            lVar12 = lVar12 + 0x50;
            *(longlong *)(&stack0x00000058 + lVar11) = lVar12;
            puVar23 = &stack0xffffffffffffffc8 + lVar11;
          } while (uVar31 < *(uint *)(&stack0x00000068 + lVar11));
        }
      }
    }
    else if (*(int *)(*(longlong *)(lVar13 + 8) + 0x100) == 2) {
      uVar31 = *(uint *)((longlong)plVar28 + 0x34);
      *(uint *)(&stack0x0000014c + lVar11) = uVar31;
      uVar26 = (ulonglong)uVar31 + 0xf;
      if (uVar26 <= uVar31) {
        uVar26 = 0xffffffffffffff0;
      }
      uVar26 = uVar26 & 0xfffffffffffffff0;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1046ea;
      func_0x();
      lVar13 = -uVar26;
      *(undefined **)(&stack0x00000070 + lVar11) = auStackX_8 + lVar13 + lVar11;
      puVar23 = &stack0xffffffffffffffc8 + lVar13 + lVar11;
      if (((uVar20 & 0x10) != 0) &&
         (*(undefined4 *)(&stack0x00000068 + lVar11) = 0,
         puVar23 = &stack0xffffffffffffffc8 + lVar13 + lVar11,
         *(int *)((longlong)auStackX_20 + lVar11) != 0)) {
        do {
          lVar15 = -0x1d13160;
          if (*(byte *)(lVar12 + 0x40) < 0x1c) {
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)((longlong)(char)*(byte *)(lVar12 + 0x40) * 4 + 0x1077c8) -
                         0x1d13160);
                    /* WARNING: Could not emulate address calculation at 0x0010472b */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,0xfffffffffe2ecea0,1);
            return;
          }
          uVar31 = *(uint *)(lVar12 + 0x40);
          if ((uVar31 >> 10 & 1) != 0) {
            lVar15 = *(longlong *)(&stack0x00000090 + lVar11);
            if ((*(byte *)(*(longlong *)(lVar12 + 0x48) + 0x2a) & 0x10) != 0) {
              lVar15 = *(longlong *)(&stack0x00000098 + lVar11);
            }
            *(undefined *)(lVar15 + *(longlong *)(lVar12 + 0x30)) = 3;
            uVar31 = *(uint *)(lVar12 + 0x40);
          }
          if ((uVar31 >> 9 & 1) != 0) {
            *(undefined4 *)(&stack0xffffffffffffffe8 + lVar13 + lVar11) =
                 *(undefined4 *)((longlong)auStackX_20 + lVar11 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar13 + lVar11) = 0x10719a;
            func_0x(&stack0x00000078 + lVar11,lVar15,lVar12,0);
          }
          iVar10 = *(int *)(&stack0x00000068 + lVar11);
          *(uint *)(&stack0x00000068 + lVar11) = iVar10 + 1U;
          lVar12 = lVar12 + 0x50;
          *(longlong *)(&stack0x00000058 + lVar11) = lVar12;
          puVar23 = &stack0xffffffffffffffc8 + lVar13 + lVar11;
        } while (iVar10 + 1U < *(uint *)((longlong)auStackX_20 + lVar11));
      }
    }
    else {
      if (*psVar2 == -1) {
        *psVar2 = 1;
        uVar20 = (ulonglong)*(uint *)(&stack0x0000008c + lVar11);
        uVar31 = *(uint *)(&stack0x00000088 + lVar11);
        lVar12 = *(longlong *)(&stack0x00000080 + lVar11);
      }
      puVar23 = &stack0xffffffffffffffc8 + lVar11;
      if (((uVar20 & 0x10) != 0) && (puVar23 = &stack0xffffffffffffffc8 + lVar11, uVar31 != 0)) {
        do {
          if (*(byte *)(lVar12 + 0x40) < 0x1c) {
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)((longlong)(char)*(byte *)(lVar12 + 0x40) * 4 + 0x107620) -
                         0x1d13160);
                    /* WARNING: Could not emulate address calculation at 0x00103e2f */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
            return;
          }
          uVar18 = *(uint *)(lVar12 + 0x40);
          if ((uVar18 >> 10 & 1) != 0) {
            lVar13 = *(longlong *)(&stack0x00000090 + lVar11);
            if ((*(byte *)(*(longlong *)(lVar12 + 0x48) + 0x2a) & 0x10) != 0) {
              lVar13 = *(longlong *)(&stack0x00000098 + lVar11);
            }
            *(undefined *)(lVar13 + *(longlong *)(lVar12 + 0x30)) = 3;
            uVar18 = *(uint *)(lVar12 + 0x40);
          }
          if ((uVar18 >> 9 & 1) != 0) {
            *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) =
                 *(undefined4 *)(&stack0x00000050 + lVar11);
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x103eef;
            func_0x(&stack0x00000078 + lVar11);
          }
          uVar18 = (int)puVar27 + 1;
          puVar27 = (uint *)(ulonglong)uVar18;
          lVar12 = lVar12 + 0x50;
          puVar23 = &stack0xffffffffffffffc8 + lVar11;
        } while (uVar18 < uVar31);
      }
    }
  }
  else {
    *(uint *)(&stack0x000001bc + lVar11) = *(uint *)(&stack0x000001bc + lVar11) & 0xfffffff8;
    *(undefined8 *)(&stack0x000001c0 + lVar11) = 0;
    lVar12 = *(longlong *)(param_1 + 0x20);
    *(longlong *)(&stack0x00000188 + lVar11) = param_1 + 0x2a0;
    *(undefined **)(&stack0x00000190 + lVar11) = &stack0x000001c8 + lVar11;
    *(undefined4 *)(&stack0x00000198 + lVar11) = 1;
    *(undefined4 *)(&stack0x0000019c + lVar11) = 1;
    *(longlong *)(&stack0x000001a0 + lVar11) = lVar12;
    lVar12 = *(longlong *)(lVar12 + 8);
    lVar13 = lVar12;
    if (*(longlong *)(lVar12 + 0x478) != 0) {
      lVar13 = *(longlong *)(lVar12 + 0x478);
    }
    if ((*(short *)(lVar13 + 0x440) == 0) && (*(short *)(lVar12 + 0xce) == 0)) {
      uVar31 = *(uint *)(&stack0x000001bc + lVar11);
    }
    else {
      uVar31 = *(uint *)(&stack0x000001bc + lVar11) | 1;
      *(uint *)(&stack0x000001bc + lVar11) = uVar31;
    }
    lVar12 = *(longlong *)(&stack0x000001a0 + lVar11);
    if ((0x1f7c < *(uint *)(*(longlong *)(lVar12 + 8) + 0xb0)) &&
       ((*(byte *)(*(longlong *)(lVar12 + 8) + 0x106) & 4) == 0)) {
      uVar31 = uVar31 | 2;
      *(uint *)(&stack0x000001bc + lVar11) = uVar31;
    }
    *(undefined4 *)(&stack0x000001a8 + lVar11) =
         *(undefined4 *)(*(longlong *)(lVar12 + 0x20) + 0x664);
    *(ulonglong *)(&stack0x000001b0 + lVar11) = (ulonglong)*(uint6 *)(lVar12 + 0x14) << 0x10;
    *(undefined2 *)(&stack0x000001b8 + lVar11) =
         *(undefined2 *)(*(longlong *)(lVar12 + 0x20) + 0x660);
    *(uint *)(&stack0x000001bc + lVar11) = uVar31 | 4;
    *(undefined8 *)(&stack0x00000408 + lVar11) = 0;
    *(undefined8 *)(&stack0x00000410 + lVar11) = 0;
    *(undefined4 *)(&stack0x00000418 + lVar11) = 0;
    *(undefined8 *)(&stack0x00000420 + lVar11) = 0;
    *(undefined4 *)(&stack0x00000428 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x107306;
    func_0x(&stack0x0000042c + lVar11,0,0x1f9e);
    *(longlong *)(&stack0x000001d0 + lVar11) = param_1 + 0x168;
    *(undefined8 *)(&stack0x000001d8 + lVar11) = 0;
    lVar12 = *(longlong *)(&stack0x00000078 + lVar11);
    puVar21 = puVar27;
    if ((*(byte *)(lVar12 + 0x38) & 8) != 0) {
      puVar21 = (uint *)(&stack0x00000408 + lVar11);
      uVar17 = *(ushort *)(lVar12 + 0x62);
      *(uint *)(&stack0x00000408 + lVar11) = (uint)uVar17;
      *(undefined4 *)(&stack0x00000428 + lVar11) = 0x1f9e;
      *(undefined **)(&stack0x00000420 + lVar11) = &stack0x0000042c + lVar11;
      uVar26 = (ulonglong)(uint)uVar17 * 0x40;
      uVar20 = uVar26 + 0xf;
      if (uVar20 <= uVar26) {
        uVar20 = 0xffffffffffffff0;
      }
      uVar20 = uVar20 & 0xfffffffffffffff0;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x107378;
      func_0x();
      lVar13 = -uVar20;
      puVar22 = &stack0xffffffffffffffc8 + lVar13 + lVar11;
      *(undefined **)(&stack0x00000410 + lVar11) = auStackX_8 + lVar13 + lVar11;
      *(undefined8 *)((longlong)&uStack_40 + lVar13 + lVar11) = 0x10738e;
      func_0x(auStackX_8 + lVar13 + lVar11,0);
    }
    *(undefined8 *)(puVar22 + 0x28) = 0;
    *(undefined **)(puVar22 + 0x20) = &stack0x00000150 + lVar11;
    *(undefined8 *)(puVar22 + -8) = 0x1073b9;
    uVar34 = func_0x
                       (&stack0x00000188 + lVar11,&stack0x00000078 + lVar11,puVar21,
                        &stack0x0000021c + lVar11);
    if (*(int *)(&stack0x00000150 + lVar11) == 2) {
      UNRECOVERED_JUMPTABLE = *(code **)(_DAT_ + 0x10);
      *(undefined8 *)(puVar22 + -8) = 0x1073cf;
      uVar34 = (*UNRECOVERED_JUMPTABLE)(0);
    }
    if ((*(byte *)(lVar12 + 0x38) & 8) != 0) {
      *(undefined **)(puVar22 + 0x28) = &stack0x00000078 + lVar11;
      *(longlong *)(puVar22 + 0x20) = param_1 + 0x2a0;
      *(undefined8 *)(puVar22 + -8) = 0x1073f0;
      func_0x(uVar34,0,0,puVar21);
    }
    lVar12 = *(longlong *)(&stack0x00000410 + lVar11);
    puVar23 = puVar22;
    if ((lVar12 != 0) && (uVar31 = *(uint *)(&stack0x00000408 + lVar11), uVar31 != 0)) {
      do {
        lVar13 = (longlong)puVar27 * 0x40;
        if ((*(byte *)(lVar12 + 0x18 + lVar13) & 4) != 0) {
          uVar14 = *(undefined8 *)(lVar12 + 0x20 + lVar13);
          *(undefined8 *)(puVar22 + -8) = 0x107429;
          (*_DAT_)(uVar14);
          pbVar29 = (byte *)(*(longlong *)(&stack0x00000410 + lVar11) + 0x18 + lVar13);
          *pbVar29 = *pbVar29 & 0xfb;
          lVar12 = *(longlong *)(&stack0x00000410 + lVar11);
          uVar31 = *(uint *)(&stack0x00000408 + lVar11);
        }
        uVar18 = (int)puVar27 + 1;
        puVar27 = (uint *)(ulonglong)uVar18;
      } while (uVar18 < uVar31);
    }
  }
LAB_:
  uVar20 = *(ulonglong *)(&stack0x000023d8 + lVar11);
  *(undefined8 *)(puVar23 + -8) = 0x10745b;
  func_0x(uVar20 ^ (ulonglong)(auStackX_8 + lVar11));
  return;
}

