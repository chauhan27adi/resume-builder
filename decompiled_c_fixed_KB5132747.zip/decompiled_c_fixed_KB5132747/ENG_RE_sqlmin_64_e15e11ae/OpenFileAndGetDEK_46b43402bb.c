
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined8 param_2,ulonglong param_3,undefined8 param_4,
                 int **param_5,longlong param_6)

{
  byte *pbVar1;
  code *pcVar2;
  ushort *puVar3;
  char cVar4;
  byte bVar5;
  ushort uVar6;
  int iVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong lVar10;
  longlong lVar11;
  int *piVar12;
  undefined4 *puVar13;
  ulonglong uVar14;
  short sVar15;
  uint uVar16;
  uint uVar17;
  int *piVar18;
  int *piVar19;
  uint uVar20;
  int iVar21;
  int **ppiVar22;
  ushort *puVar23;
  uint uVar24;
  byte *pbVar25;
  undefined4 uVar26;
  undefined4 uVar27;
  undefined4 uVar28;
  undefined4 uVar29;
  int iStackX_8;
  ushort uStackX_c;
  ushort uStackX_e;
  int *piStackX_10;
  uint uStackX_18;
  undefined4 uStackX_1c;
  longlong lStackX_20;
  undefined auStack_4128 [16];
  undefined4 uStack_4118;
  undefined4 uStack_4114;
  undefined4 uStack_4110;
  undefined4 uStack_410c;
  short sStack_4108;
  ushort uStack_4106;
  uint uStack_4104;
  int *piStack_4100;
  undefined8 uStack_40f8;
  uint uStack_40f0;
  ushort uStack_40ec;
  byte *pbStack_40ea;
  undefined2 uStack_40e2;
  undefined2 uStack_40e0;
  ushort uStack_40de;
  ushort uStack_40dc;
  undefined2 uStack_40da;
  undefined4 uStack_40d4;
  undefined auStack_4058 [8191];
  undefined auStack_2059 [8193];
  ulonglong uStack_58;
  undefined8 uStack_48;
  
  uStack_48 = 0x10001f;
  lVar8 = func_0x();
  ppiVar22 = param_5;
  lVar8 = -lVar8;
  uStack_58 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar8);
  *(undefined8 *)((longlong)&param_6 + lVar8) = param_1;
  *(int ***)((longlong)&lStackX_20 + lVar8) = param_5;
  lVar10 = param_6;
  *(longlong *)(&stack0x00000038 + lVar8) = param_6;
  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10007a;
  cVar4 = func_0x(param_2,param_3 & 0xffffffff,param_4,(longlong)&uStackX_1c + lVar8);
  if (cVar4 == '\0') {
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100092;
    uVar9 = (*_DAT_)(*(undefined4 *)((longlong)&uStackX_1c + lVar8),auStack_4058,0,0);
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar8) = param_2;
    *(int *)(&stack0xffffffffffffffe8 + lVar8) = (int)param_3;
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = uVar9;
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1000b6;
    (*_DAT_)(0x33,0x17,0x10,0x14);
  }
  piVar12 = (int *)0x0;
  sStack_4108 = -1;
  piStack_4100 = (int *)0x0;
  uStack_4104 = 0;
  pbStack_40ea = (byte *)0x0;
  uStack_40e0 = 0;
  uStack_40de = 0;
  uStack_40dc = 0;
  uStack_40da = 0;
  uStack_40f8 = (longlong *)0x0;
  uStack_40d4 = 0xffffffff;
  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1000f1;
  iVar7 = func_0x(param_4,(ulonglong)auStack_2059 & 0xfffffffffffff000,&sStack_4108);
  if (iVar7 == 0) goto LAB_;
  *(undefined4 *)((longlong)&iStackX_8 + lVar8) = 0xffffffd2;
  *(undefined2 *)((longlong)&uStackX_c + lVar8) = 0x2e;
  uVar6 = *(ushort *)((longlong)&uStackX_c + lVar8 + 2) & 0xffe0;
  *(ushort *)((longlong)&uStackX_c + lVar8 + 2) = uVar6;
  *(undefined8 *)((longlong)&uStackX_c + lVar8 + 4) = 0;
  iVar7 = 0;
  if (sStack_4108 == 0) {
    iVar21 = 1;
    if ((*(byte *)piStack_4100 & 0x10) == 0) {
      if ((1 << (*(byte *)piStack_4100 & 0xe) & 0x1105U) != 0) {
        bVar5 = 0xff;
        iVar21 = iVar7;
        goto LAB_;
      }
LAB_:
      piVar19 = piStack_4100;
      uVar20 = uStack_4104;
      if (uStack_4104 == 0) {
        uStack_4106 = 0;
        uStack_40f0 = (uint)uStack_40f8;
        if ((*(byte *)piStack_4100 & 0x10) != 0) {
          uStack_40f0 = (uint)uStack_40f8 + 2 +
                        (*(ushort *)((longlong)piStack_4100 + ((ulonglong)uStack_40f8 & 0xffffffff))
                         + 7 >> 3);
        }
        uStack_40f8 = (longlong *)CONCAT44(uStack_40f0,(uint)uStack_40f8);
        if ((*(byte *)piStack_4100 & 0x20) == 0) {
          uStack_4104 = uStack_40f0;
          uStack_40ec = 0;
          uVar20 = uStack_40f0;
        }
        else {
          puVar23 = (ushort *)((ulonglong)uStack_40f0 + (longlong)piStack_4100);
          uStack_40ec = *puVar23;
          if (*puVar23 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100234;
            cVar4 = func_0x(0x1b04d30);
            if (cVar4 != '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10023d;
              lVar10 = func_0x();
              if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100257;
                cVar4 = func_0x(0x1b04d30);
                if (cVar4 == '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100273;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100297;
                  (*_DAT_)(1,0x13f473c,0x1514828,0x80f);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1002a5;
            func_0x(piStack_4100,3);
          }
          uStack_40f0 = uStack_40f8._4_4_ + (uStack_40ec + 1) * 2;
          if (0x1f9e < uStack_40f0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1002d1;
            cVar4 = func_0x(0x1b04d30);
            if (cVar4 != '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1002da;
              lVar10 = func_0x();
              if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1002f4;
                cVar4 = func_0x(0x1b04d30);
                if (cVar4 == '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10030e;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100332;
                  (*_DAT_)(1,0x13f473c,0x1514828,0x816);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10033d;
            func_0x(piStack_4100,4);
          }
          uStack_4104 = puVar23[uStack_40ec] & 0x7fff;
          if ((puVar23[uStack_40ec] & 0x7fff) < uStack_40f0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10036c;
            cVar4 = func_0x(0x1b04d30);
            if (cVar4 != '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100375;
              lVar10 = func_0x();
              if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10038f;
                cVar4 = func_0x(0x1b04d30);
                if (cVar4 == '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1003ab;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1003cf;
                  (*_DAT_)(1,0x13f473c,0x1514828,0x81d);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1003da;
            func_0x(piStack_4100,4);
          }
          piVar19 = piStack_4100;
          piVar18 = piVar12;
          uVar20 = uStack_4104;
          uVar17 = uStack_40f0;
          puVar3 = puVar23;
          if (uStack_40ec != 0) {
            do {
              uVar16 = puVar3[1] & 0x7fff;
              if ((uVar16 < uVar17) || (uVar20 < uVar16)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100423;
                cVar4 = func_0x(0x1b04d30);
                if (cVar4 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10042c;
                  lVar10 = func_0x();
                  if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100446;
                    cVar4 = func_0x(0x1b04d30);
                    if (cVar4 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100462;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100486;
                      (*_DAT_)(1,0x13f473c,0x1514828,0x82a);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100491;
                func_0x(piStack_4100,4);
                piVar19 = piStack_4100;
                uVar20 = uStack_4104;
              }
              uVar24 = (int)piVar18 + 1;
              piVar18 = (int *)(ulonglong)uVar24;
              uVar17 = uVar16;
              puVar3 = puVar3 + 1;
            } while ((int)uVar24 < (int)(uint)uStack_40ec);
          }
          while (uVar14 = (ulonglong)uStack_40ec,
                (short)puVar23[(ulonglong)(uStack_40ec - 1) + 1] < 0) {
            if (uStack_40ec == 1) {
              uVar14 = 1;
              uVar17 = uStack_40f0;
            }
            else {
              uVar17 = *(ushort *)
                        ((longlong)piVar19 + uVar14 * 2 + (((ulonglong)uStack_40f8 >> 0x20) - 2)) &
                       0x7fff;
            }
            uVar16 = *(ushort *)((longlong)piVar19 + uVar14 * 2 + ((ulonglong)uStack_40f8 >> 0x20))
                     & 0x7fff;
            if (((uVar17 < uStack_40f0) || (uVar16 < uVar17)) || (uVar20 < uVar16)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100519;
              func_0x(piVar19,7);
              piVar19 = piStack_4100;
              uVar20 = uStack_4104;
            }
            if ((uVar17 < uStack_40f0) || (uVar20 < uVar17)) goto LAB_;
            if (*(ushort *)((longlong)piVar19 + (ulonglong)uVar17) == 5) {
              uStack_4106 = uStack_4106 | 2;
              uStack_40ec = uStack_40ec - 1;
              uVar14 = (ulonglong)(uVar17 & 0xffff);
              uStack_40de = (ushort)uVar17;
              pbVar1 = (byte *)((longlong)piVar19 + uVar14);
              if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
                uVar6 = uStack_40dc & 0xc7ff;
              }
              else {
                uVar6 = uStack_40dc ^ (*(ushort *)(pbVar1 + 2) ^ uStack_40dc) & 0x3800;
              }
              uStack_40dc = (uVar6 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar6;
              pbVar25 = (byte *)((longlong)piVar19 +
                                uVar14 + (ulonglong)((uStack_40dc & 0x7ff) * 2) + 4 +
                                         (ulonglong)((uVar6 >> 0xb & 7) * 2));
              if (pbVar25 < pbVar1) {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1005f7;
                func_0x(pbVar1,0x19);
                uVar14 = (ulonglong)uStack_40de;
                piVar19 = piStack_4100;
                uVar20 = uStack_4104;
              }
              if (uVar16 - uVar17 <
                  (((uStack_40dc & 0x7ff) * 2 - (int)uVar14) - (int)piStack_4100) + (int)pbVar25) {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100632;
                func_0x((byte *)(uVar14 + (longlong)piVar19),0x19);
                uVar14 = (ulonglong)uStack_40de;
                piVar19 = piStack_4100;
                uVar20 = uStack_4104;
              }
              if (((uStack_40dc & 0x3800) != 0) &&
                 (puVar23 = (ushort *)((longlong)piVar19 + uVar14 + 4), piVar18 = piVar12,
                 uVar6 = uStack_40dc, (uStack_40dc & 0x3800) != 0)) {
                do {
                  if ((uVar6 & 0x7ff) < (*puVar23 & 0x7ff)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100695;
                    func_0x((byte *)(uVar14 + (longlong)piVar19),0x1a);
                    uVar14 = (ulonglong)uStack_40de;
                    piVar19 = piStack_4100;
                    uVar6 = uStack_40dc;
                  }
                  uVar17 = (int)piVar18 + 1;
                  puVar23 = puVar23 + 1;
                  piVar18 = (int *)(ulonglong)uVar17;
                  uVar20 = uStack_4104;
                } while ((int)uVar17 < (int)((uStack_40dc & 0x3800) >> 0xb));
              }
              break;
            }
            if (*(ushort *)((longlong)piVar19 + (ulonglong)uVar17) < 0x400) break;
            uStack_4106 = uStack_4106 | 1;
            uStack_40ec = uStack_40ec - 1;
            if (uStack_40ec == 0) break;
          }
        }
        if ((*(byte *)piVar19 & 0x40) == 0) {
          uStack_40e2 = 0;
          uStack_40e0 = 0;
        }
        else {
          uStack_40e2 = (undefined2)uVar20;
          uStack_40e0 = (undefined2)(uVar20 >> 0x10);
          uStack_4104 = uVar20 + 0xe;
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1006e3;
          uVar9 = func_0x(&uStack_4106);
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1006f0;
          func_0x(uVar9,(longlong)&param_5 + lVar8);
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1006fa;
          iVar21 = func_0x((longlong)&param_5 + lVar8);
          uVar20 = uStack_4104 + iVar21;
          uStack_4104 = uVar20;
          piVar19 = piStack_4100;
        }
        if ((pbStack_40ea != (byte *)0x0) &&
           (pbStack_40ea < (byte *)((ulonglong)uVar20 + (longlong)piVar19))) {
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100736;
          cVar4 = func_0x(0x1b04d30);
          if (cVar4 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10073f;
            lVar10 = func_0x();
            if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100759;
              cVar4 = func_0x(0x1b04d30);
              if (cVar4 == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100775;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100799;
                (*_DAT_)(1,0x13f473c,0x1514828,0x886);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1007a7;
          func_0x(piStack_4100,0x12);
          piVar19 = piStack_4100;
          uVar20 = uStack_4104;
        }
        if (0x3f3b < uVar20 - 1) {
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1007ca;
          cVar4 = func_0x(0x1b04d30);
          if (cVar4 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1007d3;
            lVar10 = func_0x();
            if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1007ed;
              cVar4 = func_0x(0x1b04d30);
              if (cVar4 == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100809;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10082d;
                (*_DAT_)(1,0x13f473c,0x1514828,0x88b);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10083b;
          func_0x(piStack_4100,5);
          piVar19 = piStack_4100;
          uVar20 = uStack_4104;
        }
      }
LAB_:
      sVar15 = -*(short *)((longlong)&iStackX_8 + lVar8);
      if ((*(byte *)((longlong)&uStackX_c + lVar8 + 2) & 0x10) != 0) {
        if ((*(byte *)piVar19 & 0x10) == 0) {
          if ((1 << (*(byte *)piVar19 & 0xe) & 0x1105U) != 0) {
LAB_:
            piVar18 = *(int **)((longlong)&uStackX_c + lVar8 + 4);
            piVar19 = piVar18 + 1;
            iVar7 = *piVar18;
            param_1 = *(undefined8 *)((longlong)&param_6 + lVar8);
            lVar10 = *(longlong *)(&stack0x00000038 + lVar8);
            *(int *)((longlong)&lStackX_20 + lVar8 + -0x20) = iVar7;
            ppiVar22 = *(int ***)((longlong)&lStackX_20 + lVar8);
            goto LAB_;
          }
        }
        else if (((int)(uint)uStack_40f8 <= *(int *)((longlong)&iStackX_8 + lVar8)) ||
                (*(ushort *)(((ulonglong)uStack_40f8 & 0xffffffff) + (longlong)piVar19) <
                 *(ushort *)((longlong)&uStackX_c + lVar8))) goto LAB_;
      }
      if ((uint)uStack_40ec < (uint)(int)sVar15) {
        param_1 = *(undefined8 *)((longlong)&param_6 + lVar8);
        lVar10 = *(longlong *)(&stack0x00000038 + lVar8);
        *(undefined4 *)((longlong)&lStackX_20 + lVar8 + -0x20) = 0;
        ppiVar22 = *(int ***)((longlong)&lStackX_20 + lVar8);
      }
      else {
        piVar18 = piVar19;
        uVar17 = uStack_40f0;
        if (sVar15 != 1) {
          piVar18 = piStack_4100;
          uVar20 = uStack_4104;
          uVar17 = *(ushort *)
                    ((longlong)piVar19 +
                    (longlong)sVar15 * 2 + (((ulonglong)uStack_40f8 >> 0x20) - 2)) & 0x7fff;
        }
        uVar16 = *(ushort *)
                  ((longlong)piVar19 + (longlong)sVar15 * 2 + ((ulonglong)uStack_40f8 >> 0x20)) &
                 0x7fff;
        if (((uVar17 < uStack_40f0) || (uVar16 < uVar17)) || (uVar20 < uVar16)) {
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100907;
          func_0x(piVar18,7);
          piVar18 = piStack_4100;
        }
        piVar19 = (int *)((ulonglong)uVar17 + (longlong)piVar18);
        iVar7 = uVar16 - uVar17;
        param_1 = *(undefined8 *)((longlong)&param_6 + lVar8);
        lVar10 = *(longlong *)(&stack0x00000038 + lVar8);
        *(int *)((longlong)&lStackX_20 + lVar8 + -0x20) = iVar7;
        ppiVar22 = *(int ***)((longlong)&lStackX_20 + lVar8);
      }
    }
    else {
      if ((int)(uint)uStack_40f8 < -0x2d) {
        bVar5 = 0xff;
        iVar21 = iVar7;
      }
      else if (*(ushort *)(((ulonglong)uStack_40f8 & 0xffffffff) + (longlong)piStack_4100) < 0x2e) {
        bVar5 = 0xff;
        iVar21 = iVar7;
      }
      else {
        bVar5 = *(byte *)((longlong)piStack_4100 + ((ulonglong)uStack_40f8 & 0xffffffff) + 7) >> 5;
      }
LAB_:
      if ((bVar5 & 1) == 0) {
        if ((iVar21 != 0) || ((*(byte *)((longlong)&uStackX_c + lVar8 + 2) & 0x10) == 0))
        goto LAB_;
        piVar19 = (int *)0x4;
        iVar7 = **(int **)((longlong)&uStackX_c + lVar8 + 4);
        *(int *)((longlong)&lStackX_20 + lVar8 + -0x20) = iVar7;
        ppiVar22 = *(int ***)((longlong)&lStackX_20 + lVar8);
      }
      else {
        *(undefined4 *)((longlong)&lStackX_20 + lVar8 + -0x20) = 0;
        ppiVar22 = *(int ***)((longlong)&lStackX_20 + lVar8);
        piVar19 = piVar12;
      }
    }
  }
  else {
    *(undefined4 *)((longlong)&uStackX_18 + lVar8) = 0;
    *(longlong *)(&stack0xffffffffffffffe0 + lVar8) = (longlong)&uStackX_18 + lVar8;
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10096a;
    piVar19 = (int *)func_0x(&uStack_4106,(longlong)&iStackX_8 + lVar8,uVar6,
                                     (longlong)&lStackX_20 + lVar8 + -0x20);
    if ((((sStack_4108 == 0) || (uStack_40f8 == (longlong *)0x0)) || (*uStack_40f8 == 0)) ||
       (((*(byte *)((longlong)&uStackX_c + lVar8 + 2) & 8) != 0 ||
        ((*(uint *)((longlong)&uStackX_18 + lVar8) & 1) != 0)))) {
LAB_:
      iVar7 = *(int *)((longlong)&lStackX_20 + lVar8 + -0x20);
    }
    else {
      if ((piVar19 != (int *)0x0) && (piVar19 != (int *)0x11793d0)) {
        *(uint *)(&stack0xfffffffffffffff8 + lVar8) = *(uint *)((longlong)&uStackX_18 + lVar8);
        *(longlong *)(&stack0xfffffffffffffff0 + lVar8) = (longlong)&lStackX_20 + lVar8 + -0x20;
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
        uVar26 = *(undefined4 *)((longlong)&lStackX_20 + lVar8 + -0x20);
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1009d2;
        piVar19 = (int *)func_0x
                                   (uStack_40f8,(longlong)&iStackX_8 + lVar8,piVar19,uVar26);
        goto LAB_;
      }
      *(undefined4 *)((longlong)&lStackX_20 + lVar8 + -0x20) = 0;
      piVar19 = (int *)0x0;
    }
  }
LAB_:
  if (iVar7 != 0) {
    if ((piVar19 == (int *)0x0) || (iVar7 != 600)) goto LAB_;
    if ((*(byte *)piVar19 & 0x1f) != 0) {
      *(undefined4 *)((longlong)&uStackX_1c + lVar8) = 0x693b;
      (&stack0xffffffffffffffe0)[lVar8] = 5;
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100a29;
      lVar11 = (*_DAT_)(0x568,param_1,0x119fb68,0x693b);
      *(longlong *)((longlong)&lStackX_20 + lVar8) = lVar11;
      if (lVar11 != 0) {
        *(undefined4 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100a49;
        piVar12 = (int *)(*_DAT_)(lVar11,piVar19,600,param_1);
      }
      if (piVar12 == (int *)0x0) goto LAB_;
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100a57;
      lVar11 = (*_DAT_)();
      if ((*(char *)(lVar11 + 0x393) == '\0') || (lVar10 == 0)) {
        uStack_4118 = _DAT_;
        uStack_4114 = uRam0000000001179814;
        uStack_4110 = uRam0000000001179818;
        uStack_410c = uRam000000000117981c;
        puVar13 = &uStack_4118;
      }
      else {
        uVar26 = _DAT_;
        uVar27 = uRam0000000001179814;
        uVar28 = uRam0000000001179818;
        uVar29 = uRam000000000117981c;
        if (*(longlong **)(lVar10 + 0x58) != (longlong *)0x0) {
          pcVar2 = *(code **)(**(longlong **)(lVar10 + 0x58) + 0x98);
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100a7e;
          puVar13 = (undefined4 *)(*pcVar2)();
          uVar26 = *puVar13;
          uVar27 = puVar13[1];
          uVar28 = puVar13[2];
          uVar29 = puVar13[3];
        }
        auStack_4128._4_4_ = uVar27;
        auStack_4128._0_4_ = uVar26;
        auStack_4128._8_4_ = uVar28;
        auStack_4128._12_4_ = uVar29;
        puVar13 = (undefined4 *)auStack_4128;
      }
      (&stack0xffffffffffffffe8)[lVar8] = 0;
      *(undefined4 **)(&stack0xffffffffffffffe0 + lVar8) = puVar13;
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100ac4;
      (*_DAT_)(piVar12,0,0,0);
    }
  }
  *ppiVar22 = piVar12;
LAB_:
  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100add;
  func_0x(uStack_58 ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar8));
  return;
}

