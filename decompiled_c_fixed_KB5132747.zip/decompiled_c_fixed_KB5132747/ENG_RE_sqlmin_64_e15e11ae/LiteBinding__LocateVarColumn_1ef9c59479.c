
/* WARNING: Control flow encountered bad instruction data */

void FUN_(undefined8 param_1,byte *param_2)

{
  if ((*param_2 & 1) == 0) {
                    /* WARNING: Could not emulate address calculation at 0x00100071 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*param_2 & 0xe) * 4 + 0xfffb0) - 0x479f0))();
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

