
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,ulonglong param_2,longlong param_3,uint param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  ulonglong uVar3;
  uint *puVar4;
  ulonglong uVar5;
  longlong *plVar6;
  longlong lVar7;
  uint uVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  longlong lVar11;
  longlong unaff_GS_OFFSET;
  undefined auStack_518 [32];
  undefined8 uStack_4f8;
  undefined8 uStack_4f0;
  longlong lStack_4e8;
  undefined4 uStack_4e0;
  int iStack_4dc;
  uint uStack_4d8;
  longlong lStack_4d0;
  undefined4 auStack_4c8 [2];
  longlong lStack_4c0;
  undefined4 uStack_4b8;
  int *piStack_4b0;
  longlong lStack_4a8;
  longlong lStack_4a0;
  undefined8 uStack_498;
  longlong *plStack_490;
  longlong *plStack_488;
  int aiStack_478 [264];
  ulonglong uStack_58;
  
  uStack_498 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)auStack_518;
  uVar10 = (ulonglong)param_4;
  piStack_4b0 = param_5;
  uStack_4d8 = param_4;
  lStack_4d0 = param_3;
  plStack_490 = param_1;
  func_0x();
  lVar11 = param_1[5];
  lStack_4c0 = param_1[6];
  *param_5 = 0;
  lStack_4a0 = lVar11;
  if (*(char *)(param_1 + 0x17) == '\0') {
    uStack_4e0 = 3;
    iVar1 = (**(code **)(*param_1 + 0xa0))(param_1,&uStack_4e0);
    if (iVar1 < 0) goto LAB_;
    *(undefined4 *)(param_1 + 0xd) = uStack_4e0;
    *(undefined *)(param_1 + 0x17) = 1;
  }
  if (param_4 != 0) {
    do {
      uVar3 = param_1[0xe];
      if (param_2 < uVar3) {
LAB_:
        lStack_4e8 = 0;
        iVar1 = (**(code **)(*param_1 + 0x90))(param_1,param_2,&lStack_4e8);
        if ((iVar1 < 0) ||
           (iVar1 = (**(code **)(*param_1 + 0x88))
                              (param_1,*(undefined8 *)(lStack_4e8 + 0x10),
                               *(undefined4 *)(lStack_4e8 + 0x20)), iVar1 < 0)) break;
        lVar11 = (*(longlong *)(lStack_4e8 + 0x10) - param_1[0x10]) + lVar11;
        lStack_4a8 = lVar11;
        if (*(int *)(lStack_4e8 + 0x20) == *(int *)(lStack_4e8 + 0x24)) {
          func_0x
                    (param_1[6],*(undefined4 *)((longlong)param_1 + 0x3c),lVar11,
                     *(int *)(lStack_4e8 + 0x20));
          param_1[0xe] = *(longlong *)(lStack_4e8 + 0x18);
          *(undefined4 *)(param_1 + 0xf) = *(undefined4 *)(lStack_4e8 + 0x24);
        }
        else if (*(int *)(param_1 + 0xd) == 0) {
          plVar6 = (longlong *)param_1[9];
          if (plVar6 == (longlong *)0x0) {
            uStack_4b8 = 0xef8;
            uStack_4f8 = (int *)CONCAT71(uStack_4f8._1_7_,5);
            plStack_488 = (longlong *)(*_DAT_)(0x10,param_1[1],0x1268a80,0xef8);
            if (plStack_488 == (longlong *)0x0) {
              plVar6 = (longlong *)0x0;
            }
            else {
              *plStack_488 = param_1[1];
              plStack_488[1] = 1;
              plVar6 = plStack_488;
            }
            param_1[9] = (longlong)plVar6;
          }
          uStack_4f0 = (undefined4 *)
                       CONCAT44(uStack_4f0._4_4_,*(undefined4 *)((longlong)param_1 + 0x3c));
          uStack_4f8 = (int *)param_1[6];
          uVar2 = func_0x(plVar6,lVar11,*(undefined4 *)(lStack_4e8 + 0x20),
                                  *(undefined4 *)(lStack_4e8 + 0x24));
          param_1[0xe] = *(longlong *)(lStack_4e8 + 0x18);
          *(undefined4 *)(param_1 + 0xf) = uVar2;
        }
        else if (*(int *)(param_1 + 0xd) == 1) {
          if (param_1[0xb] == 0) {
            uStack_4f8 = (int *)CONCAT44(uStack_4f8._4_4_,1);
            lVar7 = (*_DAT_)(aiStack_478,param_1[1],0xfc6f0,_DAT_);
            param_1[0xb] = lVar7;
            if (aiStack_478[0] == 1) {
              (*_DAT_)(0xa7);
            }
            else if (aiStack_478[0] != 0) {
              (*_DAT_)(0x161,0x4a,0x10);
            }
          }
          (*_DAT_)(aiStack_478,param_1[0xb],1);
          if (aiStack_478[0] == 1) {
            (*_DAT_)(0xa7);
          }
          else if (aiStack_478[0] != 0) {
            (*_DAT_)(0x161,0x4a,0x10);
          }
          (*_DAT_)(aiStack_478,param_1[0xb],lVar11,*(undefined4 *)(lStack_4e8 + 0x20));
          if (aiStack_478[0] == 1) {
            (*_DAT_)(0xa7);
          }
          else if (aiStack_478[0] != 0) {
            (*_DAT_)(0x161,0x4a,0x10);
          }
          if (*(uint *)((longlong)param_1 + 0x3c) < *(uint *)(lStack_4e8 + 0x24)) {
            uStack_4f8 = *(int **)(lStack_4e8 + 0x10);
            (*_DAT_)(0x161,0x41,0x16,3);
          }
          uVar8 = 0;
          do {
            auStack_4c8[0] = 0;
            uStack_4f0 = auStack_4c8;
            uStack_4f8 = &iStack_4dc;
            iVar1 = (*_DAT_)(aiStack_478,param_1[0xb],(ulonglong)uVar8 + param_1[6],
                                     *(int *)(lStack_4e8 + 0x24) - uVar8);
            if (aiStack_478[0] == 1) {
              (*_DAT_)(0xa7);
            }
            else if (aiStack_478[0] != 0) {
              (*_DAT_)(0x161,0x4a,0x10);
            }
            uVar8 = uVar8 + iStack_4dc;
            lVar7 = (ulonglong)*_DAT_ +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
            lVar11 = *(longlong *)(lVar7 + 0x100);
            puVar4 = _DAT_;
            if (lVar11 == 0) {
              puVar4 = (uint *)(*_DAT_)();
              lVar11 = *(longlong *)(lVar7 + 0x100);
            }
            uVar10 = rdtsc();
            uVar3 = CONCAT44((int)((ulonglong)puVar4 >> 0x20),(int)uVar10) |
                    uVar10 & 0xffffffff00000000;
            uVar10 = *(ulonglong *)(lVar11 + 0x340);
            if ((uVar10 < uVar3) ||
               ((uVar10 != 0x7fffffffffffffff &&
                (*(ulonglong *)(*(longlong *)(lVar11 + 0x260) + 0xdf0) < uVar10 - uVar3)))) {
              (*_DAT_)();
            }
          } while ((iStack_4dc != 0) || (iVar1 != 0));
          (*_DAT_)(aiStack_478,param_1[0xb],lStack_4a8,*(undefined4 *)(lStack_4e8 + 0x20));
          if (aiStack_478[0] == 1) {
            (*_DAT_)(0xa7);
          }
          else if (aiStack_478[0] != 0) {
            (*_DAT_)(0x161,0x4a,0x10);
          }
          param_1[0xe] = *(longlong *)(lStack_4e8 + 0x18);
          *(uint *)(param_1 + 0xf) = uVar8;
          uVar10 = (ulonglong)uStack_4d8;
        }
        lVar7 = (ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
        ;
        lVar11 = *(longlong *)(lVar7 + 0x100);
        puVar4 = _DAT_;
        if (lVar11 == 0) {
          puVar4 = (uint *)(*_DAT_)();
          lVar11 = *(longlong *)(lVar7 + 0x100);
        }
        uVar3 = rdtsc();
        uVar5 = CONCAT44((int)((ulonglong)puVar4 >> 0x20),(int)uVar3) | uVar3 & 0xffffffff00000000;
        uVar3 = *(ulonglong *)(lVar11 + 0x340);
        if ((uVar3 < uVar5) ||
           ((uVar3 != 0x7fffffffffffffff &&
            (*(ulonglong *)(*(longlong *)(lVar11 + 0x260) + 0xdf0) < uVar3 - uVar5)))) {
          (*_DAT_)();
        }
      }
      else {
        uVar5 = uVar3 + *(uint *)(param_1 + 0xf);
        if (uVar5 <= param_2) goto LAB_;
        uVar9 = uVar10;
        if (uVar5 - param_2 <= uVar10) {
          uVar9 = (ulonglong)(((int)uVar3 - (int)param_2) + *(uint *)(param_1 + 0xf));
        }
        func_0x(param_3,uVar10,(param_2 - uVar3) + lStack_4c0,uVar9);
        uStack_4d8 = (int)uVar10 - (int)uVar9;
        uVar10 = (ulonglong)uStack_4d8;
        param_2 = param_2 + uVar9;
        lStack_4d0 = param_3 + uVar9;
        *piStack_4b0 = *piStack_4b0 + (int)uVar9;
      }
      lVar11 = lStack_4a0;
      param_3 = lStack_4d0;
    } while ((int)uVar10 != 0);
  }
LAB_:
  func_0x(uStack_58 ^ (ulonglong)auStack_518);
  return;
}

