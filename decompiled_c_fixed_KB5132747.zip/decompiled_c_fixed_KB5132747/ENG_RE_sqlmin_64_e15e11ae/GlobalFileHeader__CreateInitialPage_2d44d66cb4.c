
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2,undefined *param_3)

{
  undefined2 uVar1;
  undefined4 uVar2;
  byte *pbVar3;
  byte bVar4;
  char cVar5;
  ushort uVar6;
  ushort uVar7;
  undefined4 *puVar8;
  longlong lVar9;
  undefined8 uVar10;
  uint uVar11;
  uint uVar12;
  ulonglong uVar13;
  longlong lVar14;
  int iVar15;
  uint uVar16;
  ulonglong uVar17;
  ushort *puVar18;
  ulonglong uVar19;
  longlong unaff_GS_OFFSET;
  undefined *puStackX_18;
  uint auStackX_20 [2];
  undefined4 uStack_84;
  undefined2 uStack_80;
  undefined8 *puStack_78;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined2 uStack_68;
  undefined auStack_60 [8];
  undefined8 uStack_58;
  
  uStack_58 = 0xfffffffffffffffe;
  iVar15 = 0;
  puStack_78 = (undefined8 *)0x0;
  puStackX_18 = param_3;
  if (param_3 == (undefined *)0x0) {
    puStack_78 = (undefined8 *)func_0x(_DAT_,1,1,0);
    puStackX_18 = (undefined *)*puStack_78;
  }
  func_0x(puStackX_18,0,0x2000);
  uStack_80 = *(undefined2 *)(param_1 + 0x20);
  uStack_84 = 0;
  puVar8 = (undefined4 *)func_0x(param_1,auStack_60,&uStack_84);
  uVar2 = *puVar8;
  uVar1 = *(undefined2 *)(puVar8 + 1);
  uStack_70 = 0;
  uStack_6c = 0;
  uStack_68 = 1;
  *puStackX_18 = 1;
  puStackX_18[1] = 0xf;
  *(undefined4 *)(puStackX_18 + 0x20) = uVar2;
  *(undefined2 *)(puStackX_18 + 0x24) = uVar1;
  *(undefined2 *)(puStackX_18 + 0x1e) = 0x60;
  *(undefined2 *)(puStackX_18 + 0x1c) = 0x1fa0;
  *(undefined8 *)(puStackX_18 + 0x28) = 0;
  *(undefined2 *)(puStackX_18 + 0x30) = 1;
  if (1 < (0xfd0 - (ulonglong)*(ushort *)(puStackX_18 + 0x16)) * 2) {
    *(undefined2 *)(puStackX_18 + 0x60) = 0;
  }
  *(undefined4 *)(puStackX_18 + 0x18) = 99;
  if (*param_2 == 0) {
    if (*(int *)(param_2 + 2) == 0) {
      param_2[1] = 0;
      uVar12 = *(uint *)(param_2 + 8);
      uVar13 = (ulonglong)uVar12;
      *(uint *)(param_2 + 10) = uVar12;
      pbVar3 = *(byte **)(param_2 + 4);
      bVar4 = *pbVar3;
      if ((bVar4 & 0x10) != 0) {
        uVar12 = uVar12 + 2 + (*(ushort *)(pbVar3 + uVar13) + 7 >> 3);
        uVar13 = (ulonglong)uVar12;
        *(uint *)(param_2 + 10) = uVar12;
        bVar4 = *pbVar3;
      }
      if ((bVar4 & 0x20) == 0) {
        *(int *)(param_2 + 2) = (int)uVar13;
        param_2[0xe] = 0;
        *(uint *)(param_2 + 0xc) = uVar12;
      }
      else {
        puVar18 = (ushort *)(pbVar3 + uVar13);
        uVar7 = *puVar18;
        param_2[0xe] = uVar7;
        if (uVar7 == 0) {
          cVar5 = func_0x(0x1aba6c0);
          if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
             (*(char *)(lVar9 + 0x499) != '\0')) {
            cVar5 = func_0x(0x1aba6c0);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0x13aa0cc,0x14ca1b8,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),3);
          uVar7 = param_2[0xe];
          uVar12 = *(uint *)(param_2 + 10);
        }
        uVar12 = uVar12 + (uVar7 + 1) * 2;
        *(uint *)(param_2 + 0xc) = uVar12;
        if (0x1f9e < uVar12) {
          cVar5 = func_0x(0x1aba6c0);
          if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
             (*(char *)(lVar9 + 0x499) != '\0')) {
            cVar5 = func_0x(0x1aba6c0);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x13aa0cc,0x14ca1b8,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar7 = param_2[0xe];
          uVar12 = *(uint *)(param_2 + 0xc);
        }
        uVar7 = puVar18[uVar7];
        *(uint *)(param_2 + 2) = uVar7 & 0x7fff;
        if ((uVar7 & 0x7fff) < uVar12) {
          cVar5 = func_0x(0x1aba6c0);
          if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
             (*(char *)(lVar9 + 0x499) != '\0')) {
            cVar5 = func_0x(0x1aba6c0);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x13aa0cc,0x14ca1b8,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar12 = *(uint *)(param_2 + 0xc);
        }
        for (; uVar7 = param_2[0xe], iVar15 < (int)(uint)uVar7; iVar15 = iVar15 + 1) {
          uVar16 = puVar18[(longlong)iVar15 + 1] & 0x7fff;
          if ((uVar16 < uVar12) || (*(uint *)(param_2 + 2) < uVar16)) {
            cVar5 = func_0x(0x1aba6c0);
            if ((cVar5 != '\0') &&
               ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')
                ))) {
              cVar5 = func_0x(0x1aba6c0);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x13aa0cc,0x14ca1b8,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
          }
          uVar12 = uVar16;
        }
        do {
          if (-1 < (short)puVar18[(ulonglong)(uVar7 - 1) + 1]) break;
          lVar9 = (ulonglong)*(uint *)(param_2 + 10) + *(longlong *)(param_2 + 4);
          uVar12 = *(ushort *)(lVar9 + (ulonglong)uVar7 * 2) & 0x7fff;
          if (uVar7 == 1) {
            uVar16 = *(uint *)(param_2 + 0xc);
            uVar11 = uVar16;
LAB_:
            if ((uVar12 < uVar16) || (*(uint *)(param_2 + 2) < uVar12)) goto LAB_;
          }
          else {
            uVar16 = *(ushort *)(lVar9 + -2 + (ulonglong)uVar7 * 2) & 0x7fff;
            uVar11 = *(uint *)(param_2 + 0xc);
            if (uVar11 <= uVar16) goto LAB_;
LAB_:
            func_0x(*(longlong *)(param_2 + 4),7);
            uVar11 = *(uint *)(param_2 + 0xc);
          }
          auStackX_20[0] = uVar16;
          if ((uVar16 < uVar11) || (*(uint *)(param_2 + 2) < uVar16)) goto LAB_;
          if (*(ushort *)((ulonglong)uVar16 + *(longlong *)(param_2 + 4)) == 5) {
            param_2[1] = param_2[1] | 2;
            param_2[0xe] = param_2[0xe] + -1;
            param_2[0x15] = (short)uVar16;
            uVar13 = *(ulonglong *)(param_2 + 4);
            uVar7 = *(ushort *)((ulonglong)(uVar16 & 0xffff) + 2 + uVar13);
            uVar6 = param_2[0x16] & 0xc7ff;
            if ((uVar7 >> 0xe & 1) == 0) {
              param_2[0x16] = uVar6;
            }
            else {
              uVar6 = uVar7 & 0x3800 | uVar6;
              param_2[0x16] = uVar6;
            }
            uVar7 = (uVar6 ^ *(ushort *)((ulonglong)(uVar16 & 0xffff) + 2 + uVar13)) & 0x7ff ^ uVar6
            ;
            param_2[0x16] = uVar7;
            uVar17 = (ulonglong)(ushort)param_2[0x15];
            uVar19 = uVar13 + 4 + (ulonglong)((uVar7 & 0x7ff) * 2) + uVar17 + (uVar6 >> 0xb & 7) * 2
            ;
            if (uVar19 < uVar17 + uVar13) {
              func_0x(uVar17 + uVar13,0x19);
              uVar7 = param_2[0x16];
              uVar17 = (ulonglong)(ushort)param_2[0x15];
              uVar13 = (ulonglong)*(uint *)(param_2 + 4);
            }
            if (uVar12 - uVar16 < (((uVar7 & 0x7ff) * 2 - (int)uVar17) - (int)uVar13) + (int)uVar19)
            {
              func_0x(uVar17 + *(longlong *)(param_2 + 4),0x19);
              uVar7 = param_2[0x16];
            }
            if ((uVar7 & 0x3800) != 0) {
              uVar7 = param_2[0x15];
              lVar9 = *(longlong *)(param_2 + 4);
              for (iVar15 = 0; iVar15 < (int)((ushort)param_2[0x16] >> 0xb & 7); iVar15 = iVar15 + 1
                  ) {
                if ((param_2[0x16] & 0x7ffU) <
                    (*(ushort *)((ulonglong)uVar7 + lVar9 + 4 + (longlong)iVar15 * 2) & 0x7ff)) {
                  func_0x((ulonglong)(ushort)param_2[0x15] + *(longlong *)(param_2 + 4),0x1a
                                 );
                }
              }
            }
            break;
          }
          if (*(ushort *)((ulonglong)uVar16 + *(longlong *)(param_2 + 4)) < 0x400) break;
          param_2[1] = param_2[1] | 1;
          uVar7 = param_2[0xe] - 1;
          param_2[0xe] = uVar7;
        } while (uVar7 != 0);
      }
      if ((**(byte **)(param_2 + 4) & 0x40) == 0) {
        *(undefined4 *)(param_2 + 0x13) = 0;
      }
      else {
        *(int *)(param_2 + 0x13) = *(int *)(param_2 + 2);
        *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + 0xe;
        uVar10 = func_0x(param_2 + 1);
        func_0x(uVar10,auStackX_20);
        iVar15 = func_0x(auStackX_20);
        *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar15;
      }
      uVar12 = *(uint *)(param_2 + 2);
      if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
         (*(ulonglong *)(param_2 + 0xf) < (ulonglong)uVar12 + *(longlong *)(param_2 + 4))) {
        cVar5 = func_0x(0x1aba6c0);
        if ((cVar5 != '\0') &&
           ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0'))))
        {
          cVar5 = func_0x(0x1aba6c0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0x13aa0cc,0x14ca1b8,0x886,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),0x12);
        uVar12 = *(uint *)(param_2 + 2);
      }
      if (0x3f3b < uVar12 - 1) {
        cVar5 = func_0x(0x1aba6c0);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x1aba6c0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0x13aa0cc,0x14ca1b8,0x88b,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),5);
      }
    }
LAB_:
    uVar12 = *(uint *)(param_2 + 2);
    if ((uVar12 < 9) &&
       (((**(byte **)(param_2 + 4) & 0xe) == 0 || ((**(byte **)(param_2 + 4) & 0xe) == 0xc)))) {
      uVar12 = 9;
    }
  }
  else {
    uVar12 = *(uint *)(param_2 + 2);
    if (uVar12 == 0) {
      func_0x(param_2 + 1);
      uVar12 = *(uint *)(param_2 + 2);
    }
    if ((uVar12 < 9) &&
       (((**(byte **)(param_2 + 4) & 0x1c) == 0 || ((**(byte **)(param_2 + 4) & 0x1c) == 0xc)))) {
      uVar12 = 9;
    }
  }
  iVar15 = func_0x(puStackX_18,*(undefined8 *)(param_2 + 4),uVar12);
  if (iVar15 != 0) {
    (*_DAT_)(1,0x1562f18,0x152f438,0xa81,0);
  }
  func_0x(param_1);
  if (puStack_78 != (undefined8 *)0x0) {
    func_0x(_DAT_,puStack_78,0);
  }
  lVar14 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar9 = *(longlong *)(lVar14 + 0x100);
  if (lVar9 == 0) {
    (*_DAT_)();
    lVar9 = *(longlong *)(lVar14 + 0x100);
  }
  if (*(int *)(lVar9 + 0x22c) != 0) {
    (*_DAT_)();
  }
  return;
}

