
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

byte * FUN_(ushort *param_1)

{
  ushort *puVar1;
  byte bVar2;
  char cVar3;
  ushort uVar4;
  ushort uVar5;
  int iVar6;
  longlong lVar7;
  undefined8 *puVar8;
  byte *pbVar9;
  int iVar10;
  uint uVar11;
  ulonglong uVar12;
  uint uVar13;
  uint uVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  ushort *puVar17;
  undefined8 uStackX_8;
  
  pbVar9 = *(byte **)(param_1 + 3);
  if ((*pbVar9 & 0x40) == 0) {
    return (byte *)0x0;
  }
  if (*(int *)(param_1 + 1) == 0) {
    uVar13 = *(uint *)(param_1 + 7);
    uVar15 = (ulonglong)uVar13;
    iVar6 = 0;
    *param_1 = 0;
    *(uint *)(param_1 + 9) = uVar13;
    bVar2 = *pbVar9;
    if ((bVar2 & 0x10) != 0) {
      uVar13 = uVar13 + 2 + (*(ushort *)(pbVar9 + uVar15) + 7 >> 3);
      uVar15 = (ulonglong)uVar13;
      *(uint *)(param_1 + 9) = uVar13;
      bVar2 = *pbVar9;
    }
    if ((bVar2 & 0x20) == 0) {
      *(int *)(param_1 + 1) = (int)uVar15;
      param_1[0xd] = 0;
      *(int *)(param_1 + 0xb) = (int)uVar15;
    }
    else {
      puVar17 = (ushort *)(pbVar9 + uVar15);
      uVar4 = *puVar17;
      param_1[0xd] = uVar4;
      if (uVar4 == 0) {
        cVar3 = func_0x(0x10fb0b0);
        if (((cVar3 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
           (*(char *)(lVar7 + 0x499) != '\0')) {
          cVar3 = func_0x(0x10fb0b0);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x9eaabc,0xb0aba8,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),3);
        uVar15 = (ulonglong)*(uint *)(param_1 + 9);
        pbVar9 = *(byte **)(param_1 + 3);
        uVar4 = param_1[0xd];
      }
      uVar13 = (int)uVar15 + (uVar4 + 1) * 2;
      *(uint *)(param_1 + 0xb) = uVar13;
      if (0x1f9e < uVar13) {
        cVar3 = func_0x(0x10fb0b0);
        if (((cVar3 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
           (*(char *)(lVar7 + 0x499) != '\0')) {
          cVar3 = func_0x(0x10fb0b0);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9eaabc,0xb0aba8,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar4 = param_1[0xd];
        pbVar9 = *(byte **)(param_1 + 3);
        uVar13 = *(uint *)(param_1 + 0xb);
      }
      uVar15 = (ulonglong)uVar4;
      uVar4 = puVar17[uVar15];
      *(uint *)(param_1 + 1) = uVar4 & 0x7fff;
      if ((uVar4 & 0x7fff) < uVar13) {
        cVar3 = func_0x(0x10fb0b0);
        if (((cVar3 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
           (*(char *)(lVar7 + 0x499) != '\0')) {
          cVar3 = func_0x(0x10fb0b0);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9eaabc,0xb0aba8,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar13 = *(uint *)(param_1 + 0xb);
        uVar15 = (ulonglong)param_1[0xd];
        pbVar9 = *(byte **)(param_1 + 3);
      }
      puVar1 = puVar17;
      iVar10 = iVar6;
      if ((short)uVar15 != 0) {
        do {
          uVar11 = puVar1[1] & 0x7fff;
          if ((uVar11 < uVar13) || (*(uint *)(param_1 + 1) < uVar11)) {
            cVar3 = func_0x(0x10fb0b0);
            if ((cVar3 != '\0') &&
               ((lVar7 = func_0x(), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0')
                ))) {
              cVar3 = func_0x(0x10fb0b0);
              if (cVar3 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x9eaabc,0xb0aba8,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 3),4);
          }
          uVar15 = (ulonglong)param_1[0xd];
          iVar10 = iVar10 + 1;
          puVar1 = puVar1 + 1;
          uVar13 = uVar11;
        } while (iVar10 < (int)(uint)param_1[0xd]);
        pbVar9 = *(byte **)(param_1 + 3);
      }
      if ((short)puVar17[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
        do {
          uVar13 = *(ushort *)(pbVar9 + uVar15 * 2 + (ulonglong)*(uint *)(param_1 + 9)) & 0x7fff;
          if ((int)uVar15 == 1) {
            uVar11 = *(uint *)(param_1 + 0xb);
            uVar14 = uVar11;
LAB_:
            if ((uVar13 < uVar11) || (*(uint *)(param_1 + 1) < uVar13)) goto LAB_;
          }
          else {
            uVar14 = *(uint *)(param_1 + 0xb);
            uVar11 = *(ushort *)(pbVar9 + uVar15 * 2 + ((ulonglong)*(uint *)(param_1 + 9) - 2)) &
                     0x7fff;
            if (uVar14 <= uVar11) goto LAB_;
LAB_:
            func_0x(pbVar9,7);
            uVar14 = *(uint *)(param_1 + 0xb);
            pbVar9 = *(byte **)(param_1 + 3);
          }
          if ((uVar11 < uVar14) || (*(uint *)(param_1 + 1) < uVar11)) goto LAB_;
          if (*(ushort *)(pbVar9 + uVar11) == 5) {
            *param_1 = *param_1 | 2;
            param_1[0xd] = param_1[0xd] - 1;
            uVar16 = (ulonglong)(uVar11 & 0xffff);
            param_1[0x14] = (ushort)uVar11;
            uVar15 = *(ulonglong *)(param_1 + 3);
            uVar4 = param_1[0x15] & 0xc7ff;
            if ((*(ushort *)(uVar16 + 2 + uVar15) >> 0xe & 1) != 0) {
              uVar4 = *(ushort *)(uVar16 + 2 + uVar15) & 0x3800 | param_1[0x15] & 0xc7ff;
            }
            param_1[0x15] = uVar4;
            uVar5 = (uVar4 ^ *(ushort *)(uVar16 + 2 + uVar15)) & 0x7ff ^ uVar4;
            param_1[0x15] = uVar5;
            uVar12 = uVar15 + 4 + (ulonglong)((uVar5 & 0x7ff) * 2) + uVar16 + (uVar4 >> 0xb & 7) * 2
            ;
            if (uVar12 < uVar16 + uVar15) {
              func_0x(uVar16 + uVar15,0x19);
              uVar5 = param_1[0x15];
              uVar16 = (ulonglong)param_1[0x14];
              uVar15 = (ulonglong)*(uint *)(param_1 + 3);
            }
            if (uVar13 - uVar11 < (((uVar5 & 0x7ff) * 2 - (int)uVar16) - (int)uVar15) + (int)uVar12)
            {
              func_0x(uVar16 + *(longlong *)(param_1 + 3),0x19);
              uVar5 = param_1[0x15];
            }
            if (((uVar5 & 0x3800) != 0) &&
               (puVar17 = (ushort *)(*(longlong *)(param_1 + 3) + 4 + (ulonglong)param_1[0x14]),
               (uVar5 & 0x3800) != 0)) {
              do {
                if ((uVar5 & 0x7ff) < (*puVar17 & 0x7ff)) {
                  func_0x((ulonglong)param_1[0x14] + *(longlong *)(param_1 + 3),0x1a);
                  uVar5 = param_1[0x15];
                }
                iVar6 = iVar6 + 1;
                puVar17 = puVar17 + 1;
              } while (iVar6 < (int)(uVar5 >> 0xb & 7));
            }
            pbVar9 = *(byte **)(param_1 + 3);
            goto LAB_;
          }
          if (*(ushort *)(pbVar9 + uVar11) < 0x400) goto LAB_;
          *param_1 = *param_1 | 1;
          uVar4 = param_1[0xd] - 1;
          param_1[0xd] = uVar4;
          if (uVar4 == 0) goto LAB_;
          uVar15 = (ulonglong)uVar4;
        } while ((short)puVar17[(ulonglong)(uVar4 - 1) + 1] < 0);
        uVar15 = (ulonglong)*(uint *)(param_1 + 1);
      }
      else {
LAB_:
        uVar15 = (ulonglong)*(uint *)(param_1 + 1);
      }
    }
    if ((*pbVar9 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x12) = 0;
    }
    else {
      *(int *)(param_1 + 0x12) = (int)uVar15;
      *(int *)(param_1 + 1) = (int)uVar15 + 0xe;
      puVar8 = (undefined8 *)func_0x(param_1);
      uStackX_8 = *puVar8;
      iVar6 = func_0x(&uStackX_8);
      *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + iVar6;
      uVar15 = (ulonglong)*(uint *)(param_1 + 1);
      pbVar9 = *(byte **)(param_1 + 3);
    }
    uVar13 = (uint)uVar15;
    if ((*(byte **)(param_1 + 0xe) != (byte *)0x0) && (*(byte **)(param_1 + 0xe) < pbVar9 + uVar15))
    {
      cVar3 = func_0x(0x10fb0b0);
      if ((cVar3 != '\0') &&
         ((lVar7 = func_0x(), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0')))) {
        cVar3 = func_0x(0x10fb0b0);
        if (cVar3 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x9eaabc,0xb0aba8,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),0x12);
      uVar13 = *(uint *)(param_1 + 1);
      pbVar9 = *(byte **)(param_1 + 3);
    }
    if ((uVar13 == 0) || (0x3f3c < uVar13)) {
      cVar3 = func_0x(0x10fb0b0);
      if ((cVar3 != '\0') &&
         ((lVar7 = func_0x(), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0')))) {
        cVar3 = func_0x(0x10fb0b0);
        if (cVar3 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x9eaabc,0xb0aba8,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),5);
      pbVar9 = *(byte **)(param_1 + 3);
    }
  }
LAB_:
  return pbVar9 + (ulonglong)*(uint *)(param_1 + 0x12) + 0xe;
}

