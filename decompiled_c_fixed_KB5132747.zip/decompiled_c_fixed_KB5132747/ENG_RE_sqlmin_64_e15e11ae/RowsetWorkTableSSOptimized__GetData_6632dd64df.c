
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong param_3,longlong param_4)

{
  ushort *puVar1;
  byte bVar2;
  char cVar3;
  ushort uVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong lVar8;
  byte *pbVar9;
  code *UNRECOVERED_JUMPTABLE;
  ulonglong uVar10;
  uint *puVar11;
  ushort uVar12;
  longlong lVar13;
  undefined *puVar14;
  short sVar15;
  int iVar16;
  uint uVar17;
  uint *puVar18;
  ulonglong uVar19;
  uint *puVar20;
  byte *pbVar21;
  ulonglong uVar22;
  uint uVar23;
  uint uVar25;
  ushort *puVar26;
  ushort *puVar27;
  undefined8 uStack_430;
  undefined auStack_428 [32];
  undefined8 uStack_408;
  ushort auStack_3e8 [12];
  undefined4 uStack_3d0;
  uint uStack_3cc;
  undefined4 uStack_3c8;
  uint uStack_3c4;
  longlong lStack_3c0;
  undefined4 uStack_3a4;
  uint *puStack_3a0;
  longlong lStack_398;
  uint uStack_390;
  ushort *puStack_388;
  longlong lStack_378;
  uint *puStack_370;
  uint uStack_368;
  uint uStack_364;
  longlong lStack_360;
  longlong lStack_358;
  undefined8 uStack_350;
  undefined4 uStack_348;
  undefined8 uStack_340;
  undefined8 uStack_338;
  undefined8 uStack_330;
  undefined8 uStack_320;
  int iStack_318;
  int aiStack_314 [9];
  short *psStack_2f0;
  int iStack_2e8;
  int iStack_2e4;
  uint uStack_2e0;
  int iStack_2dc;
  uint uStack_2d8;
  int aiStack_2d4 [17];
  uint uStack_290;
  undefined auStack_23c [4];
  undefined auStack_238 [4];
  undefined auStack_234 [4];
  undefined auStack_230 [4];
  int iStack_22c;
  undefined auStack_228 [16];
  undefined auStack_218 [8];
  undefined auStack_210 [48];
  int aiStack_1e0 [10];
  undefined8 uStack_1b8;
  short *psStack_1b0;
  undefined8 uStack_1a8;
  undefined8 uStack_1a0;
  ulonglong uStack_48;
  uint *puVar24;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_3e8;
  lVar13 = *(longlong *)(param_1 + 0x3f8);
  puVar20 = (uint *)0x0;
  lStack_3c0 = lVar13;
  if (*(longlong *)(lVar13 + 0x10) == 0) {
    uStack_430 = 0x1071dd;
    func_0x();
    puVar14 = auStack_428;
  }
  else {
    uStack_1a0 = 0;
    uStack_1b8 = 0x7bb040;
    uStack_364 = 0;
    psStack_2f0 = (short *)(lVar13 + 8);
    uStack_350 = 0;
    uStack_348 = 0;
    puVar11 = puVar20;
    if (param_3 != 0) {
      uStack_368 = (uint)*(ushort *)(param_3 + 0x62);
      lStack_358 = 0;
      uStack_320 = 0;
      puStack_370 = *(uint **)(param_3 + 0x70);
      lStack_378 = param_3;
      lStack_360 = param_4;
      if ((*(ushort *)(param_3 + 0x38) & 0x400) == 0) {
        if (param_1 != -0x3b8) {
          lVar5 = **(longlong **)(*(longlong *)(param_1 + 0x3c0) + 0x160);
          uStack_350 = *(undefined8 *)(lVar5 + 0xa8);
          uStack_348 = *(undefined4 *)(lVar5 + 0xb0);
        }
        uStack_364 = 0x10;
        puVar11 = (uint *)0x10;
      }
      else {
        if (param_1 != -0x3b8) {
          lVar5 = **(longlong **)(*(longlong *)(param_1 + 0x3c0) + 0x160);
          uStack_350 = *(undefined8 *)(lVar5 + 0xa8);
          uStack_348 = *(undefined4 *)(lVar5 + 0xb0);
        }
        uStack_364 = 0x10;
        puVar11 = (uint *)0x10;
        if (param_4 != 0) {
          uStack_340 = 0;
          uStack_364 = 0x12;
          uStack_330 = 0;
          uStack_338 = 0;
          puVar11 = (uint *)0x12;
        }
      }
    }
    uVar23 = uStack_368;
    puVar24 = puStack_370;
    lStack_398 = param_1 + 0x3b8;
    uVar17 = 0;
    uStack_3cc = uStack_368;
    puStack_3a0 = puStack_370;
    if ((*(byte *)(lStack_378 + 0x30) & 1) != 0) {
      puVar1 = (ushort *)(lVar13 + 10);
      if (*psStack_2f0 == 0) {
        if ((**(byte **)(lVar13 + 0x10) & 0x10) != 0) {
          uVar17 = (uint)*(ushort *)(*(byte **)(lVar13 + 0x10) + *(uint *)(lVar13 + 0x18));
        }
      }
      else {
        uVar17 = (uint)*puVar1;
      }
      if (*(uint *)(lStack_378 + 0x18) <= uVar17) {
        *psStack_2f0 = 0;
        uStack_390 = (uint)*(ushort *)(lStack_378 + 0x62);
        puVar14 = auStack_428;
        puVar11 = puStack_370;
        puVar24 = puVar20;
        if (uStack_390 != 0) {
          do {
            puVar18 = (uint *)0x0;
            cVar3 = *(char *)(puVar11 + 0x10);
            if (cVar3 == '\x01') {
              if ((*(byte *)((longlong)puVar11 + 6) & 0x10) == 0) {
                uVar23 = *(byte *)((ulonglong)(*(ushort *)(puVar11 + 1) - 1 >> 3) +
                                   (ulonglong)*(uint *)(lVar13 + 0x18) + 2 +
                                  *(longlong *)(lVar13 + 0x10)) >>
                         ((byte)(*(ushort *)(puVar11 + 1) - 1) & 7) & 1;
              }
              else {
                uStack_408 = &iStack_22c;
                uStack_430 = 0x10140c;
                func_0x(puVar1,puVar11,1,&uStack_2d8);
                uVar23 = uStack_2d8;
              }
              if (uVar23 == 0) goto LAB_;
LAB_:
              lVar5 = lStack_360;
              if ((*(byte *)(*(longlong *)(puVar11 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar5 = lStack_358;
              }
              *(undefined *)(lVar5 + *(longlong *)(puVar11 + 0xc)) = 3;
            }
            else {
              if (cVar3 == '\x02') {
LAB_:
                uVar12 = *(ushort *)(puVar11 + 0xf);
                if ((*(byte *)((longlong)puVar11 + 6) & 0x10) == 0) {
LAB_:
                  puVar20 = (uint *)((longlong)(int)*puVar11 + *(longlong *)(lVar13 + 0x10));
                  uVar23 = (uint)uVar12;
                }
                else {
                  uStack_408 = aiStack_2d4;
                  uStack_430 = 0x10149d;
                  func_0x(puVar1,puVar11,0,auStack_228);
                  if (aiStack_2d4[0] != 0) goto LAB_;
                  uVar23 = **(uint **)(puVar11 + 2);
                  puVar20 = *(uint **)(puVar11 + 2) + 1;
                  if ((uVar12 != 0) && (uVar23 != uVar12)) {
                    uStack_408 = (int *)0x0;
                    uStack_430 = 0x1014e1;
                    (*_DAT_)(1,0xbc3bc0,0xbc2528,0x381);
                  }
                }
                uStack_3c4 = uVar23;
                lVar5 = lStack_360;
                if ((*(byte *)(*(longlong *)(puVar11 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar5 = lStack_358;
                }
                *(undefined *)(lVar5 + *(longlong *)(puVar11 + 0xc)) = 0;
              }
              else {
                if (cVar3 == '\x03') {
                  if ((*(byte *)((longlong)puVar11 + 6) & 0x10) == 0) {
                    uVar23 = *(byte *)((ulonglong)(*(ushort *)(puVar11 + 1) - 1 >> 3) +
                                       (ulonglong)*(uint *)(lVar13 + 0x18) + 2 +
                                      *(longlong *)(lVar13 + 0x10)) >>
                             ((byte)(*(ushort *)(puVar11 + 1) - 1) & 7) & 1;
                  }
                  else {
                    uStack_408 = aiStack_1e0;
                    uStack_430 = 0x100bc7;
                    func_0x(puVar1,puVar11,1,&uStack_2e0);
                    uVar23 = uStack_2e0;
                  }
                  if (uVar23 != 0) goto LAB_;
                }
                else if (cVar3 != '\x04') {
                  if (cVar3 == '\b') {
                    uVar12 = *(ushort *)(puVar11 + 0xf);
                    iVar16 = puVar11[0x10] << 0xc;
                    if ((*puVar11 & 0xc0000000) == 0x80000000) {
                      uStack_430 = 0x100b1d;
                      iVar16 = func_0x(puVar1);
                      if (iVar16 != 0) {
                        uStack_430 = 0x100b38;
                        puVar18 = (uint *)func_0x(lVar13 + 0x32,puVar11,&uStack_3c4,
                                                          auStack_23c);
                        uVar23 = uStack_3c4;
                        goto LAB_;
                      }
                      uStack_3c4 = 0;
                      uVar12 = *(ushort *)(*(longlong *)(puVar11 + 0x12) + 0x2a);
                    }
                    else {
                      if ((iVar16 < 0) || ((*(byte *)((longlong)puVar11 + 6) & 0x10) != 0)) {
                        uStack_408 = aiStack_314;
                        uStack_430 = 0x1002c2;
                        func_0x(puVar1,puVar11,iVar16 < 0,&iStack_318);
                        if ((iVar16 < 0) && (iStack_318 != 0)) {
                          uStack_3c4 = 0;
                          puVar18 = (uint *)0x0;
                          uVar23 = uStack_3c4;
                          goto LAB_;
                        }
                      }
                      else {
                        iStack_318 = 0;
                        aiStack_314[0] = 1;
                      }
                      if ((aiStack_314[0] == 0) && ((*(byte *)((longlong)puVar11 + 6) & 0x10) != 0))
                      {
                        puVar18 = *(uint **)(puVar11 + 2) + 1;
                        uVar23 = **(uint **)(puVar11 + 2);
                      }
                      else if ((int)*puVar11 < 0) {
                        if (*(int *)(lVar13 + 0xc) == 0) {
                          *puVar1 = 0;
                          uVar23 = *(uint *)(lVar13 + 0x18);
                          uVar10 = (ulonglong)uVar23;
                          *(uint *)(lVar13 + 0x1c) = uVar23;
                          pbVar21 = *(byte **)(lVar13 + 0x10);
                          bVar2 = *pbVar21;
                          if ((bVar2 & 0x10) != 0) {
                            uVar23 = uVar23 + 2 + (*(ushort *)(pbVar21 + uVar10) + 7 >> 3);
                            uVar10 = (ulonglong)uVar23;
                            *(uint *)(lVar13 + 0x1c) = uVar23;
                            bVar2 = *pbVar21;
                          }
                          if ((bVar2 & 0x20) == 0) {
                            *(int *)(lVar13 + 0xc) = (int)uVar10;
                            *(undefined2 *)(lVar13 + 0x24) = 0;
                            *(uint *)(lVar13 + 0x20) = uVar23;
                          }
                          else {
                            puVar26 = (ushort *)(pbVar21 + uVar10);
                            uVar12 = *puVar26;
                            *(ushort *)(lVar13 + 0x24) = uVar12;
                            puStack_388 = puVar26;
                            if (uVar12 == 0) {
                              uStack_430 = 0x100421;
                              cVar3 = func_0x(0x1125d70);
                              if (cVar3 != '\0') {
                                uStack_430 = 0x10042a;
                                lVar5 = func_0x();
                                if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                                  uStack_430 = 0x100444;
                                  cVar3 = func_0x(0x1125d70);
                                  if (cVar3 == '\0') {
                                    uStack_430 = 0x100460;
                                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                  }
                                  else {
                                    uStack_408 = (int *)0x0;
                                    uStack_430 = 0x100486;
                                    (*_DAT_)(1,0xa1577c,0xb35868,0x80f);
                                  }
                                }
                              }
                              uStack_430 = 0x100494;
                              func_0x(*(undefined8 *)(lVar13 + 0x10),3);
                              uVar12 = *(ushort *)(lVar13 + 0x24);
                              uVar23 = *(uint *)(lVar13 + 0x1c);
                            }
                            uVar23 = uVar23 + (uVar12 + 1) * 2;
                            *(uint *)(lVar13 + 0x20) = uVar23;
                            if (0x1f9e < uVar23) {
                              uStack_430 = 0x1004c3;
                              cVar3 = func_0x(0x1125d70);
                              if (cVar3 != '\0') {
                                uStack_430 = 0x1004cc;
                                lVar5 = func_0x();
                                if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                                  uStack_430 = 0x1004e6;
                                  cVar3 = func_0x(0x1125d70);
                                  if (cVar3 == '\0') {
                                    uStack_430 = 0x100502;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    uStack_408 = (int *)0x0;
                                    uStack_430 = 0x100528;
                                    (*_DAT_)(1,0xa1577c,0xb35868,0x816);
                                  }
                                }
                              }
                              uStack_430 = 0x100536;
                              func_0x(*(undefined8 *)(lVar13 + 0x10),4);
                              uVar12 = *(ushort *)(lVar13 + 0x24);
                              uVar23 = *(uint *)(lVar13 + 0x20);
                            }
                            uVar10 = (ulonglong)uVar12;
                            uVar12 = puVar26[uVar10];
                            *(uint *)(lVar13 + 0xc) = uVar12 & 0x7fff;
                            if ((uVar12 & 0x7fff) < uVar23) {
                              uStack_430 = 0x100564;
                              cVar3 = func_0x(0x1125d70);
                              if (cVar3 != '\0') {
                                uStack_430 = 0x10056d;
                                lVar5 = func_0x();
                                if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                                  uStack_430 = 0x100587;
                                  cVar3 = func_0x(0x1125d70);
                                  if (cVar3 == '\0') {
                                    uStack_430 = 0x1005a3;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    uStack_408 = (int *)0x0;
                                    uStack_430 = 0x1005c9;
                                    (*_DAT_)(1,0xa1577c,0xb35868,0x81d);
                                  }
                                }
                              }
                              uStack_430 = 0x1005d7;
                              func_0x(*(undefined8 *)(lVar13 + 0x10),4);
                              uVar23 = *(uint *)(lVar13 + 0x20);
                              uVar10 = (ulonglong)*(ushort *)(lVar13 + 0x24);
                            }
                            puVar27 = puVar26;
                            if ((short)uVar10 != 0) {
                              do {
                                puVar26 = puVar26 + 1;
                                uVar17 = *puVar26 & 0x7fff;
                                if ((uVar17 < uVar23) || (*(uint *)(lVar13 + 0xc) < uVar17)) {
                                  uStack_430 = 0x10061f;
                                  cVar3 = func_0x(0x1125d70);
                                  if (cVar3 != '\0') {
                                    uStack_430 = 0x100628;
                                    lVar5 = func_0x();
                                    if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                                      uStack_430 = 0x100642;
                                      cVar3 = func_0x(0x1125d70);
                                      if (cVar3 == '\0') {
                                        uStack_430 = 0x10065e;
                                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                      }
                                      else {
                                        uStack_408 = (int *)0x0;
                                        uStack_430 = 0x100684;
                                        (*_DAT_)(1,0xa1577c,0xb35868,0x82a);
                                      }
                                    }
                                  }
                                  uStack_430 = 0x100692;
                                  func_0x(*(undefined8 *)(lVar13 + 0x10),4);
                                }
                                uVar10 = (ulonglong)*(ushort *)(lVar13 + 0x24);
                                uVar25 = (int)puVar18 + 1;
                                puVar18 = (uint *)(ulonglong)uVar25;
                                puVar27 = puStack_388;
                                uVar23 = uVar17;
                              } while ((int)uVar25 < (int)(uint)*(ushort *)(lVar13 + 0x24));
                            }
                            if ((short)puVar27[(ulonglong)((int)uVar10 - 1) + 1] < 0) {
                              do {
                                lVar5 = (ulonglong)*(uint *)(lVar13 + 0x1c) +
                                        *(longlong *)(lVar13 + 0x10);
                                uVar23 = *(ushort *)(lVar5 + uVar10 * 2) & 0x7fff;
                                if ((int)uVar10 == 1) {
                                  uVar17 = *(uint *)(lVar13 + 0x20);
                                  uVar25 = uVar17;
LAB_:
                                  if ((uVar23 < uVar17) || (*(uint *)(lVar13 + 0xc) < uVar23))
                                  goto LAB_;
                                }
                                else {
                                  uVar25 = *(uint *)(lVar13 + 0x20);
                                  uVar17 = *(ushort *)(lVar5 + -2 + uVar10 * 2) & 0x7fff;
                                  if (uVar25 <= uVar17) goto LAB_;
LAB_:
                                  uStack_430 = 0x10070b;
                                  func_0x(*(longlong *)(lVar13 + 0x10),7);
                                  uVar25 = *(uint *)(lVar13 + 0x20);
                                }
                                if ((uVar17 < uVar25) || (*(uint *)(lVar13 + 0xc) < uVar17))
                                goto LAB_;
                                uVar12 = *(ushort *)
                                          ((ulonglong)uVar17 + *(longlong *)(lVar13 + 0x10));
                                if (uVar12 == 5) {
                                  *puVar1 = *puVar1 | 2;
                                  *(short *)(lVar13 + 0x24) = *(short *)(lVar13 + 0x24) + -1;
                                  *(short *)(lVar13 + 0x32) = (short)uVar17;
                                  uVar10 = *(ulonglong *)(lVar13 + 0x10);
                                  uVar4 = *(ushort *)(lVar13 + 0x34) & 0xc7ff;
                                  uVar12 = *(ushort *)((ulonglong)(uVar17 & 0xffff) + 2 + uVar10);
                                  if ((uVar12 >> 0xe & 1) != 0) {
                                    uVar4 = uVar12 & 0x3800 | uVar4;
                                  }
                                  *(ushort *)(lVar13 + 0x34) = uVar4;
                                  uVar12 = (uVar4 ^ *(ushort *)
                                                     ((ulonglong)(uVar17 & 0xffff) + 2 + uVar10)) &
                                           0x7ff ^ uVar4;
                                  *(ushort *)(lVar13 + 0x34) = uVar12;
                                  uVar22 = (ulonglong)*(ushort *)(lVar13 + 0x32);
                                  uVar19 = uVar10 + 4 +
                                           (ulonglong)((uVar12 & 0x7ff) * 2) +
                                           uVar22 + (uVar4 >> 0xb & 7) * 2;
                                  if (uVar19 < uVar22 + uVar10) {
                                    uStack_430 = 0x10081c;
                                    func_0x(uVar22 + uVar10,0x19);
                                    uVar12 = *(ushort *)(lVar13 + 0x34);
                                    uVar22 = (ulonglong)*(ushort *)(lVar13 + 0x32);
                                    uVar10 = (ulonglong)*(uint *)(lVar13 + 0x10);
                                  }
                                  if (uVar23 - uVar17 <
                                      (((uVar12 & 0x7ff) * 2 - (int)uVar22) - (int)uVar10) +
                                      (int)uVar19) {
                                    uStack_430 = 0x100854;
                                    func_0x(uVar22 + *(longlong *)(lVar13 + 0x10),0x19);
                                    uVar12 = *(ushort *)(lVar13 + 0x34);
                                  }
                                  if ((uVar12 & 0x3800) != 0) {
                                    puVar26 = (ushort *)
                                              (*(longlong *)(lVar13 + 0x10) +
                                              (ulonglong)*(ushort *)(lVar13 + 0x32) + 4);
                                    iVar16 = 0;
                                    if ((uVar12 & 0x3800) != 0) {
                                      do {
                                        if ((uVar12 & 0x7ff) < (*puVar26 & 0x7ff)) {
                                          uStack_430 = 0x1008a7;
                                          func_0x((ulonglong)*(ushort *)(lVar13 + 0x32) +
                                                          *(longlong *)(lVar13 + 0x10),0x1a);
                                          uVar12 = *(ushort *)(lVar13 + 0x34);
                                        }
                                        iVar16 = iVar16 + 1;
                                        puVar26 = puVar26 + 1;
                                      } while (iVar16 < (int)(uVar12 >> 0xb & 7));
                                    }
                                  }
                                  goto LAB_;
                                }
                                if (uVar12 < 0x400) goto LAB_;
                                *puVar1 = *puVar1 | 1;
                                uVar12 = *(short *)(lVar13 + 0x24) - 1;
                                *(ushort *)(lVar13 + 0x24) = uVar12;
                                if (uVar12 == 0) goto LAB_;
                                uVar10 = (ulonglong)uVar12;
                              } while ((short)puVar27[(ulonglong)(uVar12 - 1) + 1] < 0);
                              pbVar21 = *(byte **)(lVar13 + 0x10);
                            }
                            else {
LAB_:
                              pbVar21 = *(byte **)(lVar13 + 0x10);
                            }
                          }
                          if ((*pbVar21 & 0x40) == 0) {
                            *(undefined4 *)(lVar13 + 0x2e) = 0;
                          }
                          else {
                            *(int *)(lVar13 + 0x2e) = *(int *)(lVar13 + 0xc);
                            *(int *)(lVar13 + 0xc) = *(int *)(lVar13 + 0xc) + 0xe;
                            uStack_430 = 0x1008f2;
                            uVar6 = func_0x(puVar1);
                            uStack_430 = 0x100901;
                            func_0x(uVar6,auStack_218);
                            uStack_430 = 0x10090d;
                            iVar16 = func_0x(auStack_218);
                            *(int *)(lVar13 + 0xc) = *(int *)(lVar13 + 0xc) + iVar16;
                          }
                          uVar23 = *(uint *)(lVar13 + 0xc);
                          if ((*(ulonglong *)(lVar13 + 0x26) != 0) &&
                             (*(ulonglong *)(lVar13 + 0x26) <
                              (ulonglong)uVar23 + *(longlong *)(lVar13 + 0x10))) {
                            uStack_430 = 0x100940;
                            cVar3 = func_0x(0x1125d70);
                            if (cVar3 != '\0') {
                              uStack_430 = 0x100949;
                              lVar5 = func_0x();
                              if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                                uStack_430 = 0x100963;
                                cVar3 = func_0x(0x1125d70);
                                if (cVar3 == '\0') {
                                  uStack_430 = 0x10097f;
                                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                                }
                                else {
                                  uStack_408 = (int *)0x0;
                                  uStack_430 = 0x1009a3;
                                  (*_DAT_)(1,0xa1577c,0xb35868,0x886);
                                }
                              }
                            }
                            uStack_430 = 0x1009b1;
                            func_0x(*(undefined8 *)(lVar13 + 0x10),0x12);
                            uVar23 = *(uint *)(lVar13 + 0xc);
                          }
                          if (0x3f3b < uVar23 - 1) {
                            uStack_430 = 0x1009ca;
                            cVar3 = func_0x(0x1125d70);
                            if (cVar3 != '\0') {
                              uStack_430 = 0x1009d3;
                              lVar5 = func_0x();
                              if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                                uStack_430 = 0x1009ed;
                                cVar3 = func_0x(0x1125d70);
                                if (cVar3 == '\0') {
                                  uStack_430 = 0x100a09;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                                }
                                else {
                                  uStack_408 = (int *)0x0;
                                  uStack_430 = 0x100a2d;
                                  (*_DAT_)(1,0xa1577c,0xb35868,0x88b);
                                }
                              }
                            }
                            uStack_430 = 0x100a3b;
                            func_0x(*(undefined8 *)(lVar13 + 0x10),5);
                          }
                        }
LAB_:
                        sVar15 = -*(short *)puVar11;
                        if ((*(byte *)((longlong)puVar11 + 6) & 0x10) != 0) {
                          uStack_408 = &iStack_2e4;
                          uStack_430 = 0x100a6c;
                          func_0x(puVar1,puVar11,0,auStack_238);
                          if (iStack_2e4 == 0) {
                            puVar18 = *(uint **)(puVar11 + 2) + 1;
                            uVar23 = **(uint **)(puVar11 + 2);
                            goto LAB_;
                          }
                        }
                        lVar5 = (longlong)sVar15;
                        if ((uint)*(ushort *)(lVar13 + 0x24) < (uint)(int)sVar15) {
                          uStack_3c4 = 0;
                          puVar18 = *(uint **)(lVar13 + 0x10);
                          uVar23 = uStack_3c4;
                        }
                        else {
                          lVar8 = *(longlong *)(lVar13 + 0x10);
                          lVar7 = (ulonglong)*(uint *)(lVar13 + 0x1c) + lVar8;
                          if (sVar15 == 1) {
                            uVar10 = (ulonglong)*(uint *)(lVar13 + 0x20);
                            uVar17 = *(ushort *)(lVar7 + lVar5 * 2) & 0x7fff;
LAB_:
                            if ((uVar17 < (uint)uVar10) || (*(uint *)(lVar13 + 0xc) < uVar17))
                            goto LAB_;
                          }
                          else {
                            uVar23 = *(ushort *)(lVar7 + -2 + lVar5 * 2) & 0x7fff;
                            uVar10 = (ulonglong)uVar23;
                            lVar8 = *(longlong *)(lVar13 + 0x10);
                            uVar17 = *(ushort *)(lVar7 + lVar5 * 2) & 0x7fff;
                            if (*(uint *)(lVar13 + 0x20) <= uVar23) goto LAB_;
LAB_:
                            uStack_430 = 0x100aef;
                            func_0x(lVar8,7);
                          }
                          puVar18 = (uint *)(uVar10 + *(longlong *)(lVar13 + 0x10));
                          uVar23 = uVar17 - (int)uVar10;
                        }
                      }
                      else if ((*(ushort *)((longlong)puVar11 + 6) & 8) == 0) {
                        if ((*(ushort *)((longlong)puVar11 + 6) & 0x10) != 0) {
                          uStack_408 = &iStack_2e8;
                          uStack_430 = 0x10033d;
                          func_0x(puVar1,puVar11,0,auStack_234);
                          if (iStack_2e8 == 0) {
                            uVar23 = **(uint **)(puVar11 + 2);
                            puVar18 = *(uint **)(puVar11 + 2) + 1;
                            if ((uVar12 != 0) && (uVar23 != uVar12)) {
                              uStack_408 = (int *)0x0;
                              uStack_430 = 0x100380;
                              (*_DAT_)(1,0xbc3bc0,0xbc2528,0x381);
                            }
                            goto LAB_;
                          }
                        }
                        puVar18 = (uint *)((longlong)(int)*puVar11 + *(longlong *)(lVar13 + 0x10));
                        uVar23 = (uint)uVar12;
                      }
                      else {
                        uStack_430 = 0x1003b3;
                        puVar18 = (uint *)func_0x(puVar1,puVar11);
                        uVar23 = uStack_3c4;
                      }
LAB_:
                      uStack_3c4 = uVar23;
                      uVar12 = *(ushort *)(*(longlong *)(puVar11 + 0x12) + 0x2a);
                      if (puVar18 != (uint *)0x0) {
                        lVar5 = lStack_360;
                        if ((uVar12 & 0x10) != 0) {
                          lVar5 = lStack_358;
                        }
                        *(undefined *)(lVar5 + *(longlong *)(puVar11 + 0xc)) = 0;
                        puVar20 = puVar18;
                        goto LAB_;
                      }
                    }
                    lVar5 = lStack_360;
                    if ((uVar12 & 0x10) != 0) {
                      lVar5 = lStack_358;
                    }
                    *(undefined *)(lVar5 + *(longlong *)(puVar11 + 0xc)) = 3;
                    puVar20 = puVar18;
                    goto LAB_;
                  }
                  uStack_408 = (int *)0x790ce0;
                  uStack_430 = 0x100254;
                  (*_DAT_)(1,0xb97070,0xbc3a38,0x27d);
                  goto LAB_;
                }
                if (*(int *)(lVar13 + 0xc) == 0) {
                  *puVar1 = 0;
                  uVar23 = *(uint *)(lVar13 + 0x18);
                  uVar10 = (ulonglong)uVar23;
                  *(uint *)(lVar13 + 0x1c) = uVar23;
                  pbVar21 = *(byte **)(lVar13 + 0x10);
                  bVar2 = *pbVar21;
                  pbVar9 = pbVar21;
                  if ((bVar2 & 0x10) != 0) {
                    uVar23 = uVar23 + 2 + (*(ushort *)(pbVar21 + uVar10) + 7 >> 3);
                    uVar10 = (ulonglong)uVar23;
                    *(uint *)(lVar13 + 0x1c) = uVar23;
                    bVar2 = *pbVar21;
                    pbVar9 = *(byte **)(lVar13 + 0x10);
                  }
                  if ((bVar2 & 0x20) == 0) {
                    *(int *)(lVar13 + 0xc) = (int)uVar10;
                    *(undefined2 *)(lVar13 + 0x24) = 0;
                    *(uint *)(lVar13 + 0x20) = uVar23;
                  }
                  else {
                    puVar26 = (ushort *)(pbVar21 + uVar10);
                    uVar12 = *puVar26;
                    *(ushort *)(lVar13 + 0x24) = uVar12;
                    puStack_388 = puVar26;
                    if (uVar12 == 0) {
                      uStack_430 = 0x100c76;
                      cVar3 = func_0x(0x1125d70);
                      if (cVar3 != '\0') {
                        uStack_430 = 0x100c7f;
                        lVar5 = func_0x();
                        if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                          uStack_430 = 0x100c99;
                          cVar3 = func_0x(0x1125d70);
                          if (cVar3 == '\0') {
                            uStack_430 = 0x100cb5;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            uStack_408 = (int *)0x0;
                            uStack_430 = 0x100cdb;
                            (*_DAT_)(1,0xa1577c,0xb35868,0x80f);
                          }
                        }
                      }
                      uStack_430 = 0x100ce7;
                      func_0x(*(undefined8 *)(lVar13 + 0x10),3);
                      uVar12 = *(ushort *)(lVar13 + 0x24);
                      uVar23 = *(uint *)(lVar13 + 0x1c);
                    }
                    uVar23 = uVar23 + (uVar12 + 1) * 2;
                    *(uint *)(lVar13 + 0x20) = uVar23;
                    if (0x1f9e < uVar23) {
                      uStack_430 = 0x100d17;
                      cVar3 = func_0x(0x1125d70);
                      if (cVar3 != '\0') {
                        uStack_430 = 0x100d20;
                        lVar5 = func_0x();
                        if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                          uStack_430 = 0x100d3a;
                          cVar3 = func_0x(0x1125d70);
                          if (cVar3 == '\0') {
                            uStack_430 = 0x100d56;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            uStack_408 = (int *)0x0;
                            uStack_430 = 0x100d7c;
                            (*_DAT_)(1,0xa1577c,0xb35868,0x816);
                          }
                        }
                      }
                      uStack_430 = 0x100d8a;
                      func_0x(*(undefined8 *)(lVar13 + 0x10),4);
                      uVar12 = *(ushort *)(lVar13 + 0x24);
                      uVar23 = *(uint *)(lVar13 + 0x20);
                    }
                    uVar10 = (ulonglong)uVar12;
                    uVar12 = puVar26[uVar10];
                    *(uint *)(lVar13 + 0xc) = uVar12 & 0x7fff;
                    if ((uVar12 & 0x7fff) < uVar23) {
                      uStack_430 = 0x100db8;
                      cVar3 = func_0x(0x1125d70);
                      if (cVar3 != '\0') {
                        uStack_430 = 0x100dc1;
                        lVar5 = func_0x();
                        if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                          uStack_430 = 0x100ddb;
                          cVar3 = func_0x(0x1125d70);
                          if (cVar3 == '\0') {
                            uStack_430 = 0x100df7;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            uStack_408 = (int *)0x0;
                            uStack_430 = 0x100e1d;
                            (*_DAT_)(1,0xa1577c,0xb35868,0x81d);
                          }
                        }
                      }
                      uStack_430 = 0x100e2b;
                      func_0x(*(undefined8 *)(lVar13 + 0x10),4);
                      uVar23 = *(uint *)(lVar13 + 0x20);
                      uVar10 = (ulonglong)*(ushort *)(lVar13 + 0x24);
                    }
                    puVar27 = puVar26;
                    if ((short)uVar10 != 0) {
                      do {
                        puVar26 = puVar26 + 1;
                        uVar17 = *puVar26 & 0x7fff;
                        if ((uVar17 < uVar23) || (*(uint *)(lVar13 + 0xc) < uVar17)) {
                          uStack_430 = 0x100e6f;
                          cVar3 = func_0x(0x1125d70);
                          if (cVar3 != '\0') {
                            uStack_430 = 0x100e78;
                            lVar5 = func_0x();
                            if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                              uStack_430 = 0x100e92;
                              cVar3 = func_0x(0x1125d70);
                              if (cVar3 == '\0') {
                                uStack_430 = 0x100eae;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                uStack_408 = (int *)0x0;
                                uStack_430 = 0x100ed4;
                                (*_DAT_)(1,0xa1577c,0xb35868,0x82a);
                              }
                            }
                          }
                          uStack_430 = 0x100ee2;
                          func_0x(*(undefined8 *)(lVar13 + 0x10),4);
                        }
                        uVar10 = (ulonglong)*(ushort *)(lVar13 + 0x24);
                        uVar25 = (int)puVar18 + 1;
                        puVar18 = (uint *)(ulonglong)uVar25;
                        puVar27 = puStack_388;
                        uVar23 = uVar17;
                      } while ((int)uVar25 < (int)(uint)*(ushort *)(lVar13 + 0x24));
                    }
                    if ((short)puVar27[(ulonglong)((int)uVar10 - 1) + 1] < 0) {
                      do {
                        lVar5 = *(longlong *)(lVar13 + 0x10);
                        lVar8 = (ulonglong)*(uint *)(lVar13 + 0x1c) + lVar5;
                        uVar23 = *(ushort *)(lVar8 + uVar10 * 2) & 0x7fff;
                        if ((int)uVar10 == 1) {
                          uVar17 = *(uint *)(lVar13 + 0x20);
                          uVar25 = uVar17;
LAB_:
                          if ((uVar23 < uVar17) || (*(uint *)(lVar13 + 0xc) < uVar23))
                          goto LAB_;
                        }
                        else {
                          uVar25 = *(uint *)(lVar13 + 0x20);
                          uVar17 = *(ushort *)(lVar8 + -2 + uVar10 * 2) & 0x7fff;
                          if (uVar25 <= uVar17) goto LAB_;
LAB_:
                          uStack_430 = 0x100f5b;
                          func_0x(lVar5,7);
                          uVar25 = *(uint *)(lVar13 + 0x20);
                          lVar5 = *(longlong *)(lVar13 + 0x10);
                        }
                        if ((uVar17 < uVar25) || (*(uint *)(lVar13 + 0xc) < uVar17))
                        goto LAB_;
                        if (*(ushort *)((ulonglong)uVar17 + lVar5) == 5) {
                          *puVar1 = *puVar1 | 2;
                          *(short *)(lVar13 + 0x24) = *(short *)(lVar13 + 0x24) + -1;
                          *(short *)(lVar13 + 0x32) = (short)uVar17;
                          uVar10 = *(ulonglong *)(lVar13 + 0x10);
                          uVar4 = *(ushort *)(lVar13 + 0x34) & 0xc7ff;
                          uVar12 = *(ushort *)((ulonglong)(uVar17 & 0xffff) + 2 + uVar10);
                          if ((uVar12 >> 0xe & 1) != 0) {
                            uVar4 = uVar12 & 0x3800 | uVar4;
                          }
                          *(ushort *)(lVar13 + 0x34) = uVar4;
                          uVar12 = (uVar4 ^ *(ushort *)((ulonglong)(uVar17 & 0xffff) + 2 + uVar10))
                                   & 0x7ff ^ uVar4;
                          *(ushort *)(lVar13 + 0x34) = uVar12;
                          uVar22 = (ulonglong)*(ushort *)(lVar13 + 0x32);
                          uVar19 = uVar22 + 4 +
                                   (ulonglong)((uVar12 & 0x7ff) * 2) +
                                   uVar10 + (uVar4 >> 0xb & 7) * 2;
                          if (uVar19 < uVar22 + uVar10) {
                            uStack_430 = 0x10106d;
                            func_0x(uVar22 + uVar10,0x19);
                            uVar12 = *(ushort *)(lVar13 + 0x34);
                            uVar22 = (ulonglong)*(ushort *)(lVar13 + 0x32);
                            uVar10 = (ulonglong)*(uint *)(lVar13 + 0x10);
                          }
                          if (uVar23 - uVar17 <
                              (((uVar12 & 0x7ff) * 2 - (int)uVar22) - (int)uVar10) + (int)uVar19) {
                            uStack_430 = 0x1010a5;
                            func_0x(uVar22 + *(longlong *)(lVar13 + 0x10),0x19);
                            uVar12 = *(ushort *)(lVar13 + 0x34);
                          }
                          if ((uVar12 & 0x3800) != 0) {
                            puVar26 = (ushort *)
                                      (*(longlong *)(lVar13 + 0x10) +
                                      (ulonglong)*(ushort *)(lVar13 + 0x32) + 4);
                            iVar16 = 0;
                            if ((uVar12 & 0x3800) != 0) {
                              do {
                                if ((uVar12 & 0x7ff) < (*puVar26 & 0x7ff)) {
                                  uStack_430 = 0x1010f7;
                                  func_0x((ulonglong)*(ushort *)(lVar13 + 0x32) +
                                                  *(longlong *)(lVar13 + 0x10),0x1a);
                                  uVar12 = *(ushort *)(lVar13 + 0x34);
                                }
                                iVar16 = iVar16 + 1;
                                puVar26 = puVar26 + 1;
                              } while (iVar16 < (int)(uVar12 >> 0xb & 7));
                            }
                          }
                          goto LAB_;
                        }
                        if (*(ushort *)((ulonglong)uVar17 + lVar5) < 0x400) goto LAB_;
                        *puVar1 = *puVar1 | 1;
                        uVar12 = *(short *)(lVar13 + 0x24) - 1;
                        *(ushort *)(lVar13 + 0x24) = uVar12;
                        if (uVar12 == 0) goto LAB_;
                        uVar10 = (ulonglong)uVar12;
                      } while ((short)puVar27[(ulonglong)(uVar12 - 1) + 1] < 0);
                      pbVar9 = *(byte **)(lVar13 + 0x10);
                    }
                    else {
LAB_:
                      pbVar9 = *(byte **)(lVar13 + 0x10);
                    }
                  }
                  if ((*pbVar9 & 0x40) == 0) {
                    *(undefined4 *)(lVar13 + 0x2e) = 0;
                  }
                  else {
                    *(int *)(lVar13 + 0x2e) = *(int *)(lVar13 + 0xc);
                    *(int *)(lVar13 + 0xc) = *(int *)(lVar13 + 0xc) + 0xe;
                    uStack_430 = 0x101142;
                    uVar6 = func_0x(puVar1);
                    uStack_430 = 0x101151;
                    func_0x(uVar6,auStack_210);
                    uStack_430 = 0x10115d;
                    iVar16 = func_0x(auStack_210);
                    *(int *)(lVar13 + 0xc) = *(int *)(lVar13 + 0xc) + iVar16;
                    pbVar9 = *(byte **)(lVar13 + 0x10);
                  }
                  uVar23 = *(uint *)(lVar13 + 0xc);
                  if ((*(byte **)(lVar13 + 0x26) != (byte *)0x0) &&
                     (*(byte **)(lVar13 + 0x26) < pbVar9 + uVar23)) {
                    uStack_430 = 0x101193;
                    cVar3 = func_0x(0x1125d70);
                    if (cVar3 != '\0') {
                      uStack_430 = 0x10119c;
                      lVar5 = func_0x();
                      if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                        uStack_430 = 0x1011b6;
                        cVar3 = func_0x(0x1125d70);
                        if (cVar3 == '\0') {
                          uStack_430 = 0x1011d2;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          uStack_408 = (int *)0x0;
                          uStack_430 = 0x1011f6;
                          (*_DAT_)(1,0xa1577c,0xb35868,0x886);
                        }
                      }
                    }
                    uStack_430 = 0x101204;
                    func_0x(*(undefined8 *)(lVar13 + 0x10),0x12);
                    uVar23 = *(uint *)(lVar13 + 0xc);
                  }
                  if (0x3f3b < uVar23 - 1) {
                    uStack_430 = 0x10121d;
                    cVar3 = func_0x(0x1125d70);
                    if (cVar3 != '\0') {
                      uStack_430 = 0x101226;
                      lVar5 = func_0x();
                      if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                        uStack_430 = 0x101240;
                        cVar3 = func_0x(0x1125d70);
                        if (cVar3 == '\0') {
                          uStack_430 = 0x10125c;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          uStack_408 = (int *)0x0;
                          uStack_430 = 0x101280;
                          (*_DAT_)(1,0xa1577c,0xb35868,0x88b);
                        }
                      }
                    }
                    uStack_430 = 0x10128e;
                    func_0x(*(undefined8 *)(lVar13 + 0x10),5);
                  }
                }
LAB_:
                sVar15 = -*(short *)puVar11;
                if ((*(byte *)((longlong)puVar11 + 6) & 0x10) == 0) {
LAB_:
                  lVar5 = (longlong)sVar15;
                  if ((uint)*(ushort *)(lVar13 + 0x24) < (uint)(int)sVar15) {
                    uStack_3c4 = 0;
                    puVar20 = *(uint **)(lVar13 + 0x10);
                  }
                  else {
                    lVar8 = *(longlong *)(lVar13 + 0x10);
                    lVar7 = (ulonglong)*(uint *)(lVar13 + 0x1c) + lVar8;
                    if (sVar15 == 1) {
                      uVar10 = (ulonglong)*(uint *)(lVar13 + 0x20);
                      uVar23 = *(ushort *)(lVar7 + lVar5 * 2) & 0x7fff;
LAB_:
                      if ((uVar23 < (uint)uVar10) || (*(uint *)(lVar13 + 0xc) < uVar23))
                      goto LAB_;
                    }
                    else {
                      uVar17 = *(ushort *)(lVar7 + -2 + lVar5 * 2) & 0x7fff;
                      uVar10 = (ulonglong)uVar17;
                      lVar8 = *(longlong *)(lVar13 + 0x10);
                      uVar23 = *(ushort *)(lVar7 + lVar5 * 2) & 0x7fff;
                      if (*(uint *)(lVar13 + 0x20) <= uVar17) goto LAB_;
LAB_:
                      uStack_430 = 0x101339;
                      func_0x(lVar8,7);
                    }
                    uStack_3c4 = uVar23 - (int)uVar10;
                    puVar20 = (uint *)(uVar10 + *(longlong *)(lVar13 + 0x10));
                  }
                }
                else {
                  uStack_408 = &iStack_2dc;
                  uStack_430 = 0x1012bf;
                  func_0x(puVar1,puVar11,0,auStack_230);
                  if (iStack_2dc != 0) goto LAB_;
                  uStack_3c4 = **(uint **)(puVar11 + 2);
                  puVar20 = *(uint **)(puVar11 + 2) + 1;
                }
                if (((puVar11[0x10] & 0x2000) != 0) && (uStack_3c4 == 0)) {
                  uStack_3c4 = 4;
                  puVar20 = (uint *)0x7bc344;
                }
                lVar5 = lStack_360;
                if ((*(byte *)(*(longlong *)(puVar11 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar5 = lStack_358;
                }
                *(undefined *)(lVar5 + *(longlong *)(puVar11 + 0xc)) = 0;
                if ((1 << (**(byte **)(lVar13 + 0x10) & 0xe) & 0x440U) != 0) {
                  uStack_430 = 0x1013b1;
                  iVar16 = func_0x(puVar11);
                  if (iVar16 != 0) goto LAB_;
                }
                if (*(ushort *)(puVar11 + 0xf) < uStack_3c4) {
                  uStack_430 = 0x1013de;
                  (*_DAT_)(6,0x52,0x16,0x91);
                }
              }
LAB_:
              uVar10 = (ulonglong)uStack_3c4;
              lVar5 = *(longlong *)(puVar11 + 0x12);
              if ((puVar11[0x10] & 0x800) == 0) {
                lVar8 = lStack_360;
                if ((*(byte *)(lVar5 + 0x2a) & 0x10) != 0) {
                  lVar8 = lStack_358;
                }
                uStack_430 = 0x10154d;
                func_0x(lVar8 + *(longlong *)(puVar11 + 10),puVar20);
              }
              else {
                uVar12 = *(ushort *)(lVar5 + 0x2a) & 0x10;
                if (*(int *)(lVar5 + 0x10) == 10) {
                  lVar5 = lStack_360;
                  if (uVar12 != 0) {
                    lVar5 = lStack_358;
                  }
                  *(uint **)(lVar5 + *(longlong *)(puVar11 + 10)) = puVar20;
                }
                else {
                  lVar5 = lStack_360;
                  if (uVar12 != 0) {
                    lVar5 = lStack_358;
                  }
                  uStack_430 = 0x101580;
                  func_0x
                            (*(undefined8 *)(*(longlong *)(puVar11 + 10) + lVar5),puVar20);
                }
              }
              if ((puVar11[0x10] & 0x100) != 0) {
                lVar5 = lStack_360;
                if ((*(byte *)(*(longlong *)(puVar11 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar5 = lStack_358;
                }
                *(ulonglong *)(lVar5 + *(longlong *)(*(longlong *)(puVar11 + 0x12) + 0x18)) = uVar10
                ;
              }
            }
LAB_:
            uVar23 = (int)puVar24 + 1;
            puVar24 = (uint *)(ulonglong)uVar23;
            puVar11 = puVar11 + 0x14;
            puVar14 = auStack_428;
          } while (uVar23 < uStack_390);
        }
        goto LAB_;
      }
    }
    uStack_1a8 = 0;
    psStack_1b0 = psStack_2f0;
    if (*psStack_2f0 == 0) {
      *psStack_2f0 = 0;
      puVar14 = auStack_428;
      puStack_3a0 = puStack_370;
      if ((uStack_364 & 0x10) != 0) {
        puStack_3a0 = puStack_370;
        uStack_390 = uStack_368;
        uStack_3cc = 0;
        puVar14 = auStack_428;
        puVar11 = puStack_370;
        if (uStack_368 != 0) {
          do {
            puStack_3a0 = puVar11;
            if (*(byte *)(puVar11 + 0x10) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(puVar11 + 0x10) * 4 + 0x1071e8) -
                           0x1d89850);
                    /* WARNING: Could not emulate address calculation at 0x0010165f */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
              return;
            }
            uVar23 = puVar11[0x10];
            if ((uVar23 >> 10 & 1) != 0) {
              lVar13 = lStack_360;
              if ((*(byte *)(*(longlong *)(puVar11 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar13 = lStack_358;
              }
              *(undefined *)(lVar13 + *(longlong *)(puVar11 + 0xc)) = 3;
              uVar23 = puVar11[0x10];
            }
            if ((uVar23 >> 9 & 1) != 0) {
              uStack_408 = (int *)CONCAT44(uStack_408._4_4_,uStack_3c8);
              uStack_430 = 0x101fa6;
              func_0x(&lStack_378,lStack_398,puVar11,0);
            }
            uStack_3cc = (int)puVar20 + 1;
            puVar20 = (uint *)(ulonglong)uStack_3cc;
            puVar11 = puVar11 + 0x14;
            puVar14 = auStack_428;
            puStack_3a0 = puVar11;
          } while (uStack_3cc < uStack_390);
        }
      }
    }
    else if (*(int *)(*(longlong *)(param_1 + 0x3c0) + 0x100) == 2) {
      uStack_290 = *(uint *)(lStack_378 + 0x34);
      uVar10 = (ulonglong)uStack_290 + 0xf;
      if (uVar10 <= uStack_290) {
        uVar10 = 0xffffffffffffff0;
      }
      uVar10 = uVar10 & 0xfffffffffffffff0;
      uStack_430 = 0x1046eb;
      func_0x();
      lVar13 = -uVar10;
      puStack_388 = (ushort *)((longlong)auStack_3e8 + lVar13);
      puVar14 = auStack_428 + lVar13;
      if ((((ulonglong)puVar11 & 0x10) != 0) &&
         (uStack_390 = 0, puVar14 = auStack_428 + lVar13, uStack_3cc != 0)) {
        do {
          lVar5 = lStack_398;
          if (*(byte *)(puVar24 + 0x10) < 0x1c) {
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)((longlong)(char)*(byte *)(puVar24 + 0x10) * 4 + 0x107538) -
                         0x1d89850);
                    /* WARNING: Could not emulate address calculation at 0x0010472e */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
            return;
          }
          uVar23 = puVar24[0x10];
          if ((uVar23 >> 10 & 1) != 0) {
            lVar8 = lStack_360;
            if ((*(byte *)(*(longlong *)(puVar24 + 0x12) + 0x2a) & 0x10) != 0) {
              lVar8 = lStack_358;
            }
            *(undefined *)(lVar8 + *(longlong *)(puVar24 + 0xc)) = 3;
            uVar23 = puVar24[0x10];
          }
          if ((uVar23 >> 9 & 1) != 0) {
            *(undefined4 *)((longlong)&uStack_408 + lVar13) = uStack_3d0;
            *(undefined8 *)(auStack_428 + lVar13 + -8) = 0x10719d;
            func_0x(&lStack_378,lVar5,puVar24,0);
          }
          puVar24 = puVar24 + 0x14;
          uStack_390 = uStack_390 + 1;
          puVar14 = auStack_428 + lVar13;
          puStack_3a0 = puVar24;
        } while (uStack_390 < uStack_3cc);
      }
    }
    else {
      if (*psStack_2f0 == -1) {
        *psStack_2f0 = 1;
        puVar11 = (uint *)(ulonglong)uStack_364;
      }
      puVar14 = auStack_428;
      if ((((ulonglong)puVar11 & 0x10) != 0) &&
         (puVar14 = auStack_428, puVar11 = puStack_370, uStack_368 != 0)) {
        do {
          if (*(byte *)(puVar11 + 0x10) < 0x1c) {
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)((longlong)(char)*(byte *)(puVar11 + 0x10) * 4 + 0x107390) -
                         0x1d89850);
                    /* WARNING: Could not emulate address calculation at 0x00103e0e */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
            return;
          }
          uVar17 = puVar11[0x10];
          if ((uVar17 >> 10 & 1) != 0) {
            lVar13 = lStack_360;
            if ((*(byte *)(*(longlong *)(puVar11 + 0x12) + 0x2a) & 0x10) != 0) {
              lVar13 = lStack_358;
            }
            *(undefined *)(lVar13 + *(longlong *)(puVar11 + 0xc)) = 3;
            uVar17 = puVar11[0x10];
          }
          if ((uVar17 >> 9 & 1) != 0) {
            uStack_408 = (int *)CONCAT44(uStack_408._4_4_,uStack_3a4);
            uStack_430 = 0x103fdd;
            func_0x(&lStack_378,lStack_398,puVar11,0);
          }
          uVar17 = (int)puVar20 + 1;
          puVar20 = (uint *)(ulonglong)uVar17;
          puVar14 = auStack_428;
          puVar11 = puVar11 + 0x14;
        } while (uVar17 < uVar23);
      }
    }
  }
LAB_:
  uVar10 = uStack_48 ^ (ulonglong)auStack_3e8;
  *(undefined8 *)(puVar14 + -8) = 0x101fe2;
  func_0x(uVar10);
  return;
}

