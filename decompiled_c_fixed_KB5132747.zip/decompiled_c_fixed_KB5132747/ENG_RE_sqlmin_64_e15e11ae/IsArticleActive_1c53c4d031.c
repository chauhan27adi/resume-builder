
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined2 param_1,int param_2,undefined4 *param_3)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  byte *pbVar5;
  byte *pbVar6;
  longlong unaff_GS_OFFSET;
  undefined auStack_2e8 [32];
  undefined8 uStack_2c8;
  undefined8 uStack_2c0;
  ulonglong uStack_2b8;
  undefined8 uStack_2b0;
  undefined4 uStack_2a8;
  uint auStack_298 [2];
  int aiStack_290 [2];
  undefined8 uStack_288;
  undefined4 uStack_280;
  undefined auStack_278 [16];
  undefined auStack_268 [16];
  undefined auStack_258 [16];
  undefined auStack_248 [16];
  undefined auStack_238 [16];
  undefined auStack_228 [16];
  undefined8 uStack_218;
  undefined auStack_208 [16];
  undefined auStack_1f8 [16];
  undefined auStack_1e8 [16];
  undefined auStack_1d8 [16];
  undefined auStack_1c8 [16];
  undefined8 uStack_1b8;
  undefined8 uStack_1a8;
  undefined auStack_1a0 [16];
  undefined auStack_190 [16];
  undefined auStack_180 [16];
  undefined auStack_170 [16];
  undefined auStack_160 [16];
  undefined auStack_150 [24];
  longlong lStack_138;
  undefined2 uStack_130;
  undefined8 uStack_128;
  int iStack_120;
  undefined auStack_118 [16];
  undefined auStack_108 [16];
  undefined auStack_f8 [16];
  undefined auStack_e8 [16];
  longlong lStack_d8;
  uint uStack_d0;
  undefined8 uStack_c8;
  undefined8 uStack_c0;
  longlong lStack_b8;
  undefined2 uStack_b0;
  undefined8 uStack_a8;
  int iStack_a0;
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  longlong lStack_58;
  uint uStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  ulonglong uStack_38;
  
  uStack_1a8 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_2e8;
  pbVar5 = (byte *)0x0;
  uStack_288 = 0;
  uStack_280 = 1;
  auStack_278 = ZEXT816(0);
  aiStack_290[0] = param_2;
  if (param_2 != 0) {
    uStack_280 = 1;
    auStack_278._0_8_ =
         *(longlong **)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
          0x90);
    auStack_278._8_8_ = 0;
    cVar1 = (**(code **)(*(longlong *)auStack_278._0_8_ + 0x1d0))();
    if (cVar1 == '\0') {
      uStack_2a8 = 0;
      uStack_2b0 = 0;
      uStack_2b8 = uStack_2b8 & 0xffffffffffffff00;
      uStack_2c0 = (undefined8 *)CONCAT44(uStack_2c0._4_4_,2);
      uStack_2c8 = CONCAT44(uStack_2c8._4_4_,1);
      (**(code **)(*(longlong *)auStack_278._0_8_ + 8))(auStack_278._0_8_,0x1aac998,9,1);
      uStack_288 = CONCAT44(uStack_288._4_4_,2);
    }
    else {
      (**(code **)(*(longlong *)auStack_278._0_8_ + 0xe8))
                (auStack_278._0_8_,1,1,(longlong)&uStack_288 + 4);
      uStack_280 = 1;
      uStack_288 = CONCAT44(uStack_288._4_4_,4);
    }
    iVar2 = func_0x(param_1,0x1aac9b0);
    if (iVar2 != 0) {
      uStack_128 = (**(code **)(*(longlong *)auStack_278._0_8_ + 0x1b0))();
      lStack_138 = 0;
      auStack_118 = ZEXT816(0);
      auStack_108 = ZEXT816(0);
      auStack_f8 = ZEXT816(0);
      auStack_e8 = ZEXT816(0);
      lStack_d8 = 0;
      uStack_d0 = 0;
      uStack_c8 = 0;
      uStack_c0 = 0;
      uStack_130 = param_1;
      iStack_120 = iVar2;
      iVar2 = func_0x(&lStack_138,3,1);
      if (iVar2 == 0) {
        *param_3 = 0;
        func_0x(&lStack_138);
      }
      else {
        auStack_298[0] = 4;
        auStack_180._0_4_ = func_0x(&lStack_138,0x18ac580,auStack_298);
        auStack_1a0 = ZEXT816(0);
        auStack_190 = ZEXT816(0);
        auStack_180._4_12_ = SUB1612(ZEXT816(0),4);
        uStack_218 = 0;
        auStack_228 = ZEXT416(auStack_298[0]) << 0x40;
        auStack_258 = ZEXT816(0);
        auStack_268 = ZEXT416((uint)auStack_180._0_4_);
        auStack_238._0_12_ = ZEXT412(1) << 0x40;
        auStack_238._12_4_ = 0;
        auStack_248._8_8_ = 0;
        auStack_248._0_8_ = auStack_1a0;
        uStack_2b8 = 0;
        uStack_2c0 = &uStack_c0;
        uStack_2c8 = 0;
        (**(code **)(*(longlong *)auStack_108._8_8_ + 0x20))(auStack_108._8_8_,2,1,auStack_268);
        uStack_2b8 = uStack_2b8 & 0xffffffff00000000;
        uStack_2c0 = (undefined8 *)aiStack_290;
        uStack_2c8 = 1;
        (**(code **)(*(longlong *)auStack_f8._8_8_ + 0x28))
                  (auStack_f8._8_8_,uStack_c0,1,aiStack_290);
        *param_3 = 0;
        uStack_2c0 = (undefined8 *)lStack_138;
        uStack_2c8 = uStack_c8;
        iVar2 = (**(code **)(*(longlong *)auStack_118._8_8_ + 0x18))(auStack_118._8_8_,0,1,0);
        if (iVar2 == 0) {
          auStack_298[0] = 0;
          if (((lStack_138 != 0) && (lStack_d8 != 0)) && (uStack_d0 != 0)) {
            uVar3 = func_0x(&lStack_138,0x1847aa0,auStack_298);
            pbVar6 = pbVar5;
            if (((lStack_d8 != 0) && (uVar3 - 1 < 0xfffffffe)) && (uStack_d0 != 0)) {
              do {
                if (*(ulonglong *)((longlong)pbVar5 * 0x58 + lStack_d8) == (ulonglong)uVar3) {
                  pbVar6 = (byte *)((longlong)pbVar5 * 0x58 + lStack_d8);
                  if (pbVar6 != (byte *)0x0) goto LAB_;
                  break;
                }
                uVar4 = (int)pbVar5 + 1;
                pbVar5 = (byte *)(ulonglong)uVar4;
                pbVar6 = (byte *)0x0;
              } while (uVar4 < uStack_d0);
            }
            uStack_2c8 = CONCAT44(uStack_2c8._4_4_,iStack_120);
            (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
            pbVar5 = (byte *)(lStack_138 + *(longlong *)(pbVar6 + 8));
          }
          if ((*pbVar5 & 1) != 0) {
            *param_3 = 1;
          }
        }
        else {
          iVar2 = func_0x(param_1,0x1aac970);
          if (iVar2 == 0) {
            func_0x(0x4977,0x10,1,0x1aac970);
          }
          else {
            uStack_a8 = (**(code **)(*(longlong *)auStack_278._0_8_ + 0x1b0))();
            lStack_b8 = 0;
            auStack_98 = ZEXT816(0);
            auStack_88 = ZEXT816(0);
            auStack_78 = ZEXT816(0);
            auStack_68 = ZEXT816(0);
            lStack_58 = 0;
            uStack_50 = 0;
            uStack_48 = 0;
            uStack_40 = 0;
            uStack_b0 = param_1;
            iStack_a0 = iVar2;
            iVar2 = func_0x(&lStack_b8,3,1);
            if (iVar2 == 0) {
              func_0x(0x49aa,0x10,1,0x1aac970);
            }
            else {
              auStack_298[0] = 4;
              auStack_150._0_4_ = func_0x(&lStack_b8,0x18ac580,auStack_298);
              auStack_170 = ZEXT816(0);
              auStack_160 = ZEXT816(0);
              auStack_150._4_12_ = SUB1612(ZEXT816(0),4);
              uStack_1b8 = 0;
              auStack_1c8 = ZEXT416(auStack_298[0]) << 0x40;
              auStack_1f8 = ZEXT816(0);
              auStack_208 = ZEXT416((uint)auStack_150._0_4_);
              auStack_1d8._0_12_ = ZEXT412(1) << 0x40;
              auStack_1d8._12_4_ = 0;
              auStack_1e8._8_8_ = 0;
              auStack_1e8._0_8_ = auStack_170;
              uStack_2b8 = 0;
              uStack_2c0 = &uStack_40;
              uStack_2c8 = 0;
              (**(code **)(*(longlong *)auStack_88._8_8_ + 0x20))(auStack_88._8_8_,2,1,auStack_208);
              uStack_2b8 = uStack_2b8 & 0xffffffff00000000;
              uStack_2c0 = (undefined8 *)aiStack_290;
              uStack_2c8 = 1;
              (**(code **)(*(longlong *)auStack_78._8_8_ + 0x28))
                        (auStack_78._8_8_,uStack_40,1,aiStack_290);
              *param_3 = 0;
              uStack_2c0 = (undefined8 *)lStack_b8;
              uStack_2c8 = uStack_48;
              iVar2 = (**(code **)(*(longlong *)auStack_98._8_8_ + 0x18))(auStack_98._8_8_,0,1,0);
              if (iVar2 == 0) {
                auStack_298[0] = 0;
                if (((lStack_b8 != 0) && (lStack_58 != 0)) && (uStack_50 != 0)) {
                  uVar3 = func_0x(&lStack_b8,0x1847aa0,auStack_298);
                  pbVar6 = pbVar5;
                  if (((lStack_58 != 0) && (uVar3 - 1 < 0xfffffffe)) && (uStack_50 != 0)) {
                    do {
                      if (*(ulonglong *)((longlong)pbVar5 * 0x58 + lStack_58) == (ulonglong)uVar3) {
                        pbVar6 = (byte *)((longlong)pbVar5 * 0x58 + lStack_58);
                        if (pbVar6 != (byte *)0x0) goto LAB_;
                        break;
                      }
                      uVar4 = (int)pbVar5 + 1;
                      pbVar5 = (byte *)(ulonglong)uVar4;
                      pbVar6 = (byte *)0x0;
                    } while (uVar4 < uStack_50);
                  }
                  uStack_2c8 = CONCAT44(uStack_2c8._4_4_,iStack_a0);
                  (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
                  pbVar5 = (byte *)(lStack_b8 + *(longlong *)(pbVar6 + 8));
                }
                if ((*pbVar5 & 1) != 0) {
                  *param_3 = 1;
                }
              }
            }
            func_0x(&lStack_b8);
          }
        }
        func_0x(&lStack_138);
        func_0x(&uStack_288,0);
      }
      goto LAB_;
    }
  }
  *param_3 = 0;
LAB_:
  if ((int)uStack_288 != 0) {
    func_0x(&uStack_288,0);
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_2e8);
  return;
}

