
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  byte *pbVar1;
  longlong lVar2;
  code *UNRECOVERED_JUMPTABLE;
  
  lVar2 = func_0x();
  lVar2 = -lVar2;
  *(undefined2 *)(&stack0x00000030 + lVar2) = 0xffff;
  pbVar1 = *(byte **)(param_1 + 0x230);
  *(undefined8 *)(&stack0x00000038 + lVar2) = 0;
  *(undefined4 *)(&stack0x00000034 + lVar2) = 0;
  *(undefined8 *)(&stack0x0000004e + lVar2) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar2) = 0;
  if ((*pbVar1 & 1) != 0) {
    UNRECOVERED_JUMPTABLE =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x102cc0) * 4 +
                           0x102cb0) - 0x1d0eca0);
                    /* WARNING: Could not emulate address calculation at 0x001000e6 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
    return;
  }
                    /* WARNING: Could not emulate address calculation at 0x0010024a */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x102ce0) - 0x1d0eca0))();
  return;
}

