
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,char param_2,short *param_3,longlong param_4,undefined8 *param_5,
                 longlong param_6)

{
  ushort *puVar1;
  short sVar2;
  longlong *plVar3;
  undefined *puVar4;
  byte bVar5;
  char cVar6;
  ushort uVar7;
  ushort uVar8;
  longlong lVar9;
  ulonglong uVar10;
  longlong lVar11;
  short *psVar12;
  short *psVar13;
  undefined8 uVar14;
  ulonglong *puVar15;
  uint uVar16;
  short *psVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  ulonglong uVar22;
  byte *pbVar23;
  ulonglong uVar24;
  int iVar25;
  ushort *puVar26;
  ushort *puVar27;
  undefined auStack_618 [32];
  undefined8 uStack_5f8;
  longlong lStack_5f0;
  ushort *puStack_5e8;
  short *psStack_5e0;
  longlong lStack_5d8;
  undefined8 *puStack_5d0;
  undefined8 uStack_5c8;
  int iStack_5c0;
  undefined8 uStack_5b8;
  int *piStack_5b0;
  undefined **ppuStack_5a8;
  undefined8 uStack_5a0;
  undefined8 uStack_598;
  undefined *puStack_590;
  undefined8 uStack_588;
  undefined4 uStack_580;
  undefined8 uStack_57c;
  undefined8 uStack_574;
  undefined8 uStack_568;
  undefined2 uStack_560;
  undefined auStack_558 [2];
  undefined2 uStack_556;
  undefined8 uStack_554;
  undefined2 uStack_54c;
  undefined2 uStack_54a;
  undefined4 uStack_548;
  undefined2 uStack_544;
  char cStack_542;
  undefined uStack_541;
  ushort uStack_53c;
  undefined2 auStack_53a [65];
  undefined auStack_4b8 [16];
  uint uStack_4a8;
  undefined4 uStack_4a4;
  uint uStack_4a0;
  undefined4 uStack_49c;
  short asStack_498 [261];
  short asStack_28e [129];
  short asStack_18c [129];
  undefined2 uStack_8a;
  undefined uStack_88;
  undefined2 uStack_86;
  undefined uStack_84;
  int iStack_78;
  int iStack_74;
  uint uStack_70;
  undefined *puStack_68;
  uint *puStack_60;
  undefined8 uStack_58;
  ulonglong uStack_50;
  
  uStack_50 = _DAT_ ^ (ulonglong)auStack_618;
  puStack_5d0 = param_5;
  uStack_4a8 = *(uint *)(param_4 + 0x650) & 0xffbfffff;
  uStack_8a = 0;
  uStack_4a4 = *(undefined4 *)(param_4 + 0xc);
  uStack_4a0 = (uint)*(ushort *)(param_4 + 0x10);
  uStack_86 = 0;
  uStack_49c = 0;
  uStack_84 = 0;
  uStack_88 = 0;
  uStack_548 = 0;
  uStack_544 = 0;
  uStack_53c = 0;
  psStack_5e0 = param_3;
  lStack_5d8 = param_1;
  if ((param_2 == -0x72) && (*(char *)(param_6 + 0x5ce) != '\0')) {
    if (((byte)*(uint *)(param_4 + 0x650) & 0x28) != 0x28) {
      uStack_5f8 = 0;
      (*_DAT_)(1,0x159f4e0,0x156bf48,0xedd);
    }
    lVar9 = (*_DAT_)(param_4 + 0x812,0x1d4aec0);
    if ((lVar9 == 0) || (lVar9 != param_4 + 0x812)) {
      uStack_5f8 = 0;
      (*_DAT_)(1,0x159f500,0x156bf48,0xee8);
    }
    param_1 = lStack_5d8;
    uVar10 = 0xffffffffffffffff;
    do {
      uVar10 = uVar10 + 1;
    } while (*(short *)(uVar10 * 2 + 0x1d4aec0) != 0);
    lVar9 = lVar9 + (uVar10 & 0xffffffff) * 2;
    if ((*(ushort *)(*(longlong *)(lStack_5d8 + 0x20) + 0x67e) < 0x356) &&
       ((DAT_ & 0x80) == 0)) {
      lVar11 = -1;
      do {
        lVar11 = lVar11 + 1;
      } while (*(short *)(lVar9 + lVar11 * 2) != 0);
      uStack_5f8 = CONCAT44(uStack_5f8._4_4_,(int)lVar11 * 2);
      lStack_5f0 = lVar9;
      (*_DAT_)(0x33,0x15,0x10,0x65);
    }
  }
  else {
    lVar9 = param_4 + 0x812;
  }
  func_0x(asStack_498,0,0x20a);
  lVar11 = 0x105;
  psVar17 = asStack_498;
  do {
    if ((lVar11 == -0x7ffffef9) ||
       (sVar2 = *(short *)((lVar9 - (longlong)asStack_498) + (longlong)psVar17), sVar2 == 0)) break;
    *psVar17 = sVar2;
    psVar17 = psVar17 + 1;
    lVar11 = lVar11 + -1;
  } while (lVar11 != 0);
  psVar12 = psVar17 + -1;
  if (lVar11 != 0) {
    psVar12 = psVar17;
  }
  *psVar12 = 0;
  func_0x(asStack_28e,0,0x102);
  lVar11 = 0x81;
  psVar17 = asStack_28e;
  lVar9 = 0x81;
  do {
    if ((lVar9 == -0x7fffff7d) ||
       (sVar2 = *(short *)((param_4 - (longlong)asStack_28e) + 0x710 + (longlong)psVar17),
       sVar2 == 0)) break;
    *psVar17 = sVar2;
    psVar17 = psVar17 + 1;
    lVar9 = lVar9 + -1;
  } while (lVar9 != 0);
  psVar12 = psVar17 + -1;
  if (lVar9 != 0) {
    psVar12 = psVar17;
  }
  *psVar12 = 0;
  uVar7 = *(ushort *)(param_4 + 0x10);
  lVar9 = *(longlong *)(*(longlong *)(param_1 + 0x20) + 0x698);
  if ((*(uint *)(lVar9 + 0x4c) < (uint)uVar7) || (uVar7 == 0)) {
    lVar9 = 0;
  }
  else {
    lVar9 = *(longlong *)(*(longlong *)(lVar9 + 0x28) + -8 + (ulonglong)uVar7 * 8);
    if (lVar9 != 0) goto LAB_;
  }
  uStack_5f8 = 0;
  (*_DAT_)(1,0x159eb98,0x156bf48,0xf14);
LAB_:
  func_0x(asStack_18c,0,0x102);
  psVar12 = psStack_5e0;
  psVar17 = asStack_18c;
  do {
    if ((lVar11 == -0x7fffff7d) ||
       (sVar2 = *(short *)((lVar9 - (longlong)asStack_18c) + 100 + (longlong)psVar17), sVar2 == 0))
    break;
    *psVar17 = sVar2;
    psVar17 = psVar17 + 1;
    lVar11 = lVar11 + -1;
  } while (lVar11 != 0);
  psVar13 = psVar17 + -1;
  if (lVar11 != 0) {
    psVar13 = psVar17;
  }
  *psVar13 = 0;
  if (param_2 == -0x72) {
    uStack_88 = *(undefined *)(param_6 + 0x5ce);
  }
  puVar1 = (ushort *)(psStack_5e0 + 1);
  uStack_541 = 0;
  uStack_54a = 0;
  auStack_53a[uStack_53c] = 0x428;
  uStack_53c = uStack_53c + 1;
  uVar18 = *(uint *)(psStack_5e0 + 2);
  uVar10 = (ulonglong)uVar18;
  cStack_542 = param_2;
  if (*psStack_5e0 == 0) {
    if (uVar18 == 0) {
      pbVar23 = *(byte **)(psStack_5e0 + 4);
      uVar18 = *(uint *)(psStack_5e0 + 8);
      uVar10 = (ulonglong)uVar18;
      *puVar1 = 0;
      *(uint *)(psStack_5e0 + 10) = uVar18;
      bVar5 = *pbVar23;
      if ((bVar5 & 0x10) != 0) {
        uVar18 = uVar18 + 2 + (*(ushort *)(pbVar23 + uVar10) + 7 >> 3);
        uVar10 = (ulonglong)uVar18;
        *(uint *)(psStack_5e0 + 10) = uVar18;
        bVar5 = *pbVar23;
      }
      if ((bVar5 & 0x20) == 0) {
        *(int *)(psStack_5e0 + 2) = (int)uVar10;
        psStack_5e0[0xe] = 0;
        *(int *)(psStack_5e0 + 0xc) = (int)uVar10;
      }
      else {
        puVar26 = (ushort *)(pbVar23 + uVar10);
        uVar7 = *puVar26;
        psStack_5e0[0xe] = uVar7;
        if (uVar7 == 0) {
          cVar6 = func_0x(0x1af71f0);
          if (((cVar6 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
             (*(char *)(lVar9 + 0x499) != '\0')) {
            cVar6 = func_0x(0x1af71f0);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_5f8 = 0;
              (*_DAT_)(1,0x13e6bfc,0x1506ce8,0x80f);
            }
          }
          func_0x(*(undefined8 *)(psVar12 + 4),3);
          uVar7 = psVar12[0xe];
          uVar10 = (ulonglong)*(uint *)(psVar12 + 10);
        }
        uVar16 = (uint)uVar7;
        uVar18 = (int)uVar10 + (uVar16 + 1) * 2;
        *(uint *)(psVar12 + 0xc) = uVar18;
        if (0x1f9e < uVar18) {
          cVar6 = func_0x(0x1af71f0);
          if (((cVar6 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
             (*(char *)(lVar9 + 0x499) != '\0')) {
            cVar6 = func_0x(0x1af71f0);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_5f8 = 0;
              (*_DAT_)(1,0x13e6bfc,0x1506ce8,0x816);
            }
          }
          func_0x(*(undefined8 *)(psVar12 + 4),4);
          uVar16 = (uint)(ushort)psVar12[0xe];
          uVar18 = *(uint *)(psVar12 + 0xc);
        }
        uVar19 = puVar26[uVar16] & 0x7fff;
        *(uint *)(psVar12 + 2) = uVar19;
        if (uVar19 < uVar18) {
          cVar6 = func_0x(0x1af71f0);
          if (((cVar6 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
             (*(char *)(lVar9 + 0x499) != '\0')) {
            cVar6 = func_0x(0x1af71f0);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_5f8 = 0;
              (*_DAT_)(1,0x13e6bfc,0x1506ce8,0x81d);
            }
          }
          func_0x(*(undefined8 *)(psVar12 + 4),4);
          uVar18 = *(uint *)(psVar12 + 0xc);
          uVar16 = (uint)(ushort)psVar12[0xe];
          uVar19 = *(uint *)(psVar12 + 2);
        }
        iVar25 = 0;
        puVar27 = puVar26;
        if ((short)uVar16 != 0) {
          do {
            uVar20 = puVar27[1] & 0x7fff;
            if ((uVar20 < uVar18) || (uVar19 = *(uint *)(psVar12 + 2), uVar19 < uVar20)) {
              cVar6 = func_0x(0x1af71f0);
              if ((cVar6 != '\0') &&
                 ((lVar9 = func_0x(), lVar9 != 0 &&
                  (*(char *)(lVar9 + 0x499) != '\0')))) {
                cVar6 = func_0x(0x1af71f0);
                if (cVar6 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_5f8 = 0;
                  (*_DAT_)(1,0x13e6bfc,0x1506ce8,0x82a);
                }
              }
              func_0x(*(undefined8 *)(psVar12 + 4),4);
              uVar19 = *(uint *)(psVar12 + 2);
            }
            uVar16 = (uint)(ushort)psVar12[0xe];
            iVar25 = iVar25 + 1;
            param_5 = puStack_5d0;
            puVar27 = puVar27 + 1;
            uVar18 = uVar20;
          } while (iVar25 < (int)uVar16);
        }
        uVar10 = (ulonglong)uVar19;
        if ((short)puVar26[(ulonglong)(uVar16 - 1) + 1] < 0) {
          pbVar23 = *(byte **)(psVar12 + 4);
          do {
            uVar18 = *(ushort *)
                      (pbVar23 + (ulonglong)uVar16 * 2 + (ulonglong)*(uint *)(psVar12 + 10)) &
                     0x7fff;
            if (uVar16 == 1) {
              uVar16 = *(uint *)(psVar12 + 0xc);
              uVar19 = uVar16;
LAB_:
              if ((uVar18 < uVar16) || (uVar20 = *(uint *)(psVar12 + 2), uVar20 < uVar18))
              goto LAB_;
            }
            else {
              uVar19 = *(uint *)(psVar12 + 0xc);
              uVar16 = *(ushort *)
                        (pbVar23 + (ulonglong)uVar16 * 2 + ((ulonglong)*(uint *)(psVar12 + 10) - 2))
                       & 0x7fff;
              if (uVar19 <= uVar16) goto LAB_;
LAB_:
              func_0x(pbVar23,7);
              uVar19 = *(uint *)(psVar12 + 0xc);
              uVar20 = *(uint *)(psVar12 + 2);
            }
            uVar10 = (ulonglong)uVar20;
            if ((uVar16 < uVar19) || (uVar20 < uVar16)) goto LAB_;
            pbVar23 = *(byte **)(psVar12 + 4);
            if (*(ushort *)(pbVar23 + uVar16) == 5) {
              *puVar1 = *puVar1 | 2;
              psVar12[0xe] = psVar12[0xe] + -1;
              uVar24 = (ulonglong)(uVar16 & 0xffff);
              psVar12[0x15] = (short)uVar16;
              uVar10 = *(ulonglong *)(psVar12 + 4);
              uVar7 = psVar12[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar24 + 2 + uVar10) >> 0xe & 1) != 0) {
                uVar7 = *(ushort *)(uVar24 + 2 + uVar10) & 0x3800 | psVar12[0x16] & 0xc7ffU;
              }
              psVar12[0x16] = uVar7;
              uVar8 = (uVar7 ^ *(ushort *)(uVar24 + 2 + uVar10)) & 0x7ff ^ uVar7;
              psVar12[0x16] = uVar8;
              uVar22 = uVar10 + 4 +
                       (ulonglong)((uVar8 & 0x7ff) * 2) + uVar24 + (uVar7 >> 0xb & 7) * 2;
              if (uVar22 < uVar24 + uVar10) {
                func_0x(uVar24 + uVar10,0x19);
                uVar8 = psVar12[0x16];
                uVar24 = (ulonglong)(ushort)psVar12[0x15];
                uVar10 = (ulonglong)*(uint *)(psVar12 + 4);
              }
              if (uVar18 - uVar16 <
                  (((uVar8 & 0x7ff) * 2 - (int)uVar24) - (int)uVar10) + (int)uVar22) {
                func_0x(uVar24 + *(longlong *)(psVar12 + 4),0x19);
                uVar8 = psVar12[0x16];
              }
              if ((uVar8 & 0x3800) != 0) {
                puVar26 = (ushort *)
                          (*(longlong *)(psVar12 + 4) + (ulonglong)(ushort)psVar12[0x15] + 4);
                iVar25 = 0;
                if ((uVar8 & 0x3800) != 0) {
                  do {
                    if ((uVar8 & 0x7ff) < (*puVar26 & 0x7ff)) {
                      func_0x((ulonglong)(ushort)psVar12[0x15] + *(longlong *)(psVar12 + 4),
                                      0x1a);
                      uVar8 = psVar12[0x16];
                    }
                    iVar25 = iVar25 + 1;
                    puVar26 = puVar26 + 1;
                  } while (iVar25 < (int)(uVar8 >> 0xb & 7));
                }
              }
              uVar10 = (ulonglong)*(uint *)(psVar12 + 2);
              goto LAB_;
            }
            if (*(ushort *)(pbVar23 + uVar16) < 0x400) goto LAB_;
            sVar2 = psVar12[0xe];
            *puVar1 = *puVar1 | 1;
            uVar7 = sVar2 - 1;
            psVar12[0xe] = uVar7;
            if (uVar7 == 0) goto LAB_;
            uVar16 = (uint)uVar7;
          } while ((short)puVar26[(ulonglong)(uVar7 - 1) + 1] < 0);
        }
        else {
LAB_:
          pbVar23 = *(byte **)(psVar12 + 4);
        }
      }
      if ((*pbVar23 & 0x40) == 0) {
        *(undefined4 *)(psVar12 + 0x13) = 0;
      }
      else {
        *(int *)(psVar12 + 0x13) = (int)uVar10;
        *(int *)(psVar12 + 2) = (int)uVar10 + 0xe;
        uVar14 = func_0x(puVar1);
        func_0x(uVar14,&puStack_5e8);
        iVar25 = func_0x(&puStack_5e8);
        *(int *)(psVar12 + 2) = *(int *)(psVar12 + 2) + iVar25;
        uVar10 = (ulonglong)*(uint *)(psVar12 + 2);
      }
      if ((*(ulonglong *)(psVar12 + 0xf) != 0) &&
         (*(ulonglong *)(psVar12 + 0xf) < uVar10 + *(longlong *)(psVar12 + 4))) {
        cVar6 = func_0x(0x1af71f0);
        if ((cVar6 != '\0') &&
           ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0'))))
        {
          cVar6 = func_0x(0x1af71f0);
          if (cVar6 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_5f8 = 0;
            (*_DAT_)(1,0x13e6bfc,0x1506ce8,0x886);
          }
        }
        func_0x(*(undefined8 *)(psVar12 + 4),0x12);
        uVar10 = (ulonglong)*(uint *)(psVar12 + 2);
      }
      if (((uint)uVar10 == 0) || (0x3f3c < (uint)uVar10)) {
        cVar6 = func_0x(0x1af71f0);
        if ((cVar6 != '\0') &&
           ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0'))))
        {
          cVar6 = func_0x(0x1af71f0);
          if (cVar6 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_5f8 = 0;
            (*_DAT_)(1,0x13e6bfc,0x1506ce8,0x88b);
          }
        }
        func_0x(*(undefined8 *)(psVar12 + 4),5);
        uVar10 = (ulonglong)*(uint *)(psVar12 + 2);
      }
    }
LAB_:
    if (((uint)uVar10 < 9) &&
       (((**(byte **)(psVar12 + 4) & 0xe) == 0 || ((**(byte **)(psVar12 + 4) & 0xe) == 0xc)))) {
      uVar10 = 9;
    }
  }
  else {
    if (uVar18 == 0) {
      func_0x(puVar1);
      uVar10 = (ulonglong)*(uint *)(psVar12 + 2);
    }
    if (((uint)uVar10 < 9) &&
       (((**(byte **)(psVar12 + 4) & 0x1c) == 0 || ((**(byte **)(psVar12 + 4) & 0x1c) == 0xc)))) {
      uVar10 = 9;
    }
  }
  psVar17 = psStack_5e0;
  iVar25 = 0;
  uVar18 = 9;
  auStack_53a[uStack_53c] = (short)uVar10;
  uStack_554 = *param_5;
  uStack_53c = uStack_53c + 1;
  uStack_54c = *(undefined2 *)(param_5 + 1);
  uStack_556 = 0x1c;
  iStack_78 = (uint)uStack_53c * 2 + 0x1e;
  puStack_68 = auStack_558;
  puStack_60 = &uStack_4a8;
  iStack_74 = 0x428;
  if (*psStack_5e0 == 0) {
    uVar16 = *(uint *)(psVar12 + 2);
    if (uVar16 == 0) {
      pbVar23 = *(byte **)(psVar12 + 4);
      uVar16 = *(uint *)(psVar12 + 8);
      uVar10 = (ulonglong)uVar16;
      *puVar1 = 0;
      *(uint *)(psVar12 + 10) = uVar16;
      bVar5 = *pbVar23;
      if ((bVar5 & 0x10) != 0) {
        uVar16 = uVar16 + 2 + (*(ushort *)(pbVar23 + uVar10) + 7 >> 3);
        uVar10 = (ulonglong)uVar16;
        *(uint *)(psVar12 + 10) = uVar16;
        bVar5 = *pbVar23;
      }
      if ((bVar5 & 0x20) == 0) {
        *(int *)(psVar12 + 2) = (int)uVar10;
        psVar12[0xe] = 0;
        *(int *)(psVar12 + 0xc) = (int)uVar10;
      }
      else {
        puVar26 = (ushort *)(pbVar23 + uVar10);
        uVar7 = *puVar26;
        psVar12[0xe] = uVar7;
        puStack_5e8 = puVar26;
        if (uVar7 == 0) {
          cVar6 = func_0x(0x1af71f0);
          if (((cVar6 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
             (*(char *)(lVar9 + 0x499) != '\0')) {
            cVar6 = func_0x(0x1af71f0);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_5f8 = 0;
              (*_DAT_)(1,0x13e6bfc,0x1506ce8,0x80f);
            }
          }
          func_0x(*(undefined8 *)(psVar12 + 4),3);
          uVar7 = psVar12[0xe];
          uVar10 = (ulonglong)*(uint *)(psVar12 + 10);
        }
        uVar19 = (uint)uVar7;
        uVar16 = (int)uVar10 + (uVar19 + 1) * 2;
        *(uint *)(psVar12 + 0xc) = uVar16;
        if (0x1f9e < uVar16) {
          cVar6 = func_0x(0x1af71f0);
          if (((cVar6 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
             (*(char *)(lVar9 + 0x499) != '\0')) {
            cVar6 = func_0x(0x1af71f0);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_5f8 = 0;
              (*_DAT_)(1,0x13e6bfc,0x1506ce8,0x816);
            }
          }
          func_0x(*(undefined8 *)(psVar12 + 4),4);
          uVar19 = (uint)(ushort)psVar12[0xe];
          uVar16 = *(uint *)(psVar12 + 0xc);
        }
        uVar20 = puVar26[uVar19] & 0x7fff;
        *(uint *)(psVar12 + 2) = uVar20;
        if (uVar20 < uVar16) {
          cVar6 = func_0x(0x1af71f0);
          if (((cVar6 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
             (*(char *)(lVar9 + 0x499) != '\0')) {
            cVar6 = func_0x(0x1af71f0);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_5f8 = 0;
              (*_DAT_)(1,0x13e6bfc,0x1506ce8,0x81d);
            }
          }
          func_0x(*(undefined8 *)(psVar12 + 4),4);
          uVar16 = *(uint *)(psVar12 + 0xc);
          uVar19 = (uint)(ushort)psVar12[0xe];
          uVar20 = *(uint *)(psVar12 + 2);
        }
        puVar27 = puVar26;
        if ((short)uVar19 != 0) {
          do {
            puVar26 = puVar26 + 1;
            uVar21 = *puVar26 & 0x7fff;
            if ((uVar21 < uVar16) || (uVar20 = *(uint *)(psVar12 + 2), uVar20 < uVar21)) {
              cVar6 = func_0x(0x1af71f0);
              if ((cVar6 != '\0') &&
                 ((lVar9 = func_0x(), lVar9 != 0 &&
                  (*(char *)(lVar9 + 0x499) != '\0')))) {
                cVar6 = func_0x(0x1af71f0);
                if (cVar6 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_5f8 = 0;
                  (*_DAT_)(1,0x13e6bfc,0x1506ce8,0x82a);
                }
              }
              func_0x(*(undefined8 *)(psVar12 + 4),4);
              uVar20 = *(uint *)(psVar17 + 2);
            }
            uVar19 = (uint)(ushort)psVar12[0xe];
            iVar25 = iVar25 + 1;
            puVar27 = puStack_5e8;
            uVar16 = uVar21;
          } while (iVar25 < (int)uVar19);
        }
        uVar10 = (ulonglong)uVar20;
        if ((short)puVar27[(ulonglong)(uVar19 - 1) + 1] < 0) {
          pbVar23 = *(byte **)(psVar12 + 4);
          do {
            uVar20 = *(ushort *)
                      (pbVar23 + (ulonglong)uVar19 * 2 + (ulonglong)*(uint *)(psVar12 + 10)) &
                     0x7fff;
            if (uVar19 == 1) {
              uVar19 = *(uint *)(psVar12 + 0xc);
              uVar21 = uVar19;
LAB_:
              if ((uVar20 < uVar19) || (uVar16 = *(uint *)(psVar12 + 2), uVar16 < uVar20))
              goto LAB_;
            }
            else {
              uVar21 = *(uint *)(psVar12 + 0xc);
              uVar19 = *(ushort *)
                        (pbVar23 + (ulonglong)uVar19 * 2 + ((ulonglong)*(uint *)(psVar12 + 10) - 2))
                       & 0x7fff;
              if (uVar21 <= uVar19) goto LAB_;
LAB_:
              func_0x(pbVar23,7);
              uVar21 = *(uint *)(psVar12 + 0xc);
              uVar16 = *(uint *)(psVar12 + 2);
            }
            uVar10 = (ulonglong)uVar16;
            if ((uVar19 < uVar21) || (uVar16 < uVar19)) goto LAB_;
            pbVar23 = *(byte **)(psVar12 + 4);
            if (*(ushort *)(pbVar23 + uVar19) == 5) {
              *puVar1 = *puVar1 | 2;
              psVar12[0xe] = psVar12[0xe] + -1;
              uVar24 = (ulonglong)(uVar19 & 0xffff);
              psVar12[0x15] = (short)uVar19;
              uVar10 = *(ulonglong *)(psVar12 + 4);
              uVar7 = psVar12[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar24 + 2 + uVar10) >> 0xe & 1) != 0) {
                uVar7 = *(ushort *)(uVar24 + 2 + uVar10) & 0x3800 | psVar12[0x16] & 0xc7ffU;
              }
              psVar12[0x16] = uVar7;
              uVar8 = (uVar7 ^ *(ushort *)(uVar24 + 2 + uVar10)) & 0x7ff ^ uVar7;
              psVar12[0x16] = uVar8;
              uVar22 = (ulonglong)((uVar8 & 0x7ff) * 2) + 4 + uVar10 + (uVar7 >> 0xb & 7) * 2 +
                       uVar24;
              if (uVar22 < uVar24 + uVar10) {
                func_0x(uVar24 + uVar10,0x19);
                uVar8 = psVar12[0x16];
                uVar24 = (ulonglong)(ushort)psVar12[0x15];
                uVar10 = (ulonglong)*(uint *)(psVar12 + 4);
              }
              if (uVar20 - uVar19 <
                  (((uVar8 & 0x7ff) * 2 - (int)uVar24) - (int)uVar10) + (int)uVar22) {
                func_0x(uVar24 + *(longlong *)(psVar12 + 4),0x19);
                uVar8 = psVar12[0x16];
              }
              if ((uVar8 & 0x3800) != 0) {
                puVar26 = (ushort *)
                          (*(longlong *)(psVar12 + 4) + (ulonglong)(ushort)psVar12[0x15] + 4);
                iVar25 = 0;
                if ((uVar8 & 0x3800) != 0) {
                  do {
                    if ((uVar8 & 0x7ff) < (*puVar26 & 0x7ff)) {
                      func_0x((ulonglong)(ushort)psVar12[0x15] + *(longlong *)(psVar12 + 4),
                                      0x1a);
                      uVar8 = psVar12[0x16];
                    }
                    iVar25 = iVar25 + 1;
                    puVar26 = puVar26 + 1;
                  } while (iVar25 < (int)(uVar8 >> 0xb & 7));
                }
              }
              uVar10 = (ulonglong)*(uint *)(psVar12 + 2);
              goto LAB_;
            }
            if (*(ushort *)(pbVar23 + uVar19) < 0x400) goto LAB_;
            sVar2 = psVar12[0xe];
            *puVar1 = *puVar1 | 1;
            uVar7 = sVar2 - 1;
            psVar12[0xe] = uVar7;
            if (uVar7 == 0) goto LAB_;
            uVar19 = (uint)uVar7;
          } while ((short)puVar27[(ulonglong)(uVar7 - 1) + 1] < 0);
        }
        else {
LAB_:
          pbVar23 = *(byte **)(psVar12 + 4);
        }
      }
      iVar25 = 0;
      if ((*pbVar23 & 0x40) == 0) {
        *(undefined4 *)(psVar12 + 0x13) = 0;
      }
      else {
        *(int *)(psVar12 + 0x13) = *(int *)(psVar12 + 2);
        *(int *)(psVar12 + 2) = *(int *)(psVar12 + 2) + 0xe;
        puVar15 = (ulonglong *)func_0x(puVar1);
        uVar8 = (ushort)(*puVar15 >> 0x30);
        uVar7 = uVar8;
        if ((((uint)(int)(short)uVar8 >> 1 ^ (int)(short)uVar8) & 0x2000) != 0) {
          uVar7 = uVar8 & 0xdfff;
          if ((uVar8 >> 0xe & 1) != 0) {
            uVar7 = uVar8 | 0x2000;
          }
        }
        if (uVar7 == 0xfffc) {
          iVar25 = (int)((*puVar15 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(psVar12 + 2) = *(int *)(psVar12 + 2) + iVar25;
        uVar10 = (ulonglong)*(uint *)(psVar12 + 2);
      }
      if ((*(ulonglong *)(psVar12 + 0xf) != 0) &&
         (*(ulonglong *)(psVar12 + 0xf) < uVar10 + *(longlong *)(psVar12 + 4))) {
        cVar6 = func_0x(0x1af71f0);
        if ((cVar6 != '\0') &&
           ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0'))))
        {
          cVar6 = func_0x(0x1af71f0);
          if (cVar6 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_5f8 = 0;
            (*_DAT_)(1,0x13e6bfc,0x1506ce8,0x886);
          }
        }
        func_0x(*(undefined8 *)(psVar12 + 4),0x12);
        uVar10 = (ulonglong)*(uint *)(psVar12 + 2);
      }
      uVar16 = (uint)uVar10;
      if ((uVar16 == 0) || (0x3f3c < uVar16)) {
        cVar6 = func_0x(0x1af71f0);
        if ((cVar6 != '\0') &&
           ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0'))))
        {
          cVar6 = func_0x(0x1af71f0);
          if (cVar6 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_5f8 = 0;
            (*_DAT_)(1,0x13e6bfc,0x1506ce8,0x88b);
          }
        }
        func_0x(*(undefined8 *)(psVar12 + 4),5);
        uVar16 = *(uint *)(psVar12 + 2);
      }
    }
LAB_:
    if ((8 < uVar16) ||
       (((**(byte **)(psVar12 + 4) & 0xe) != 0 && ((**(byte **)(psVar12 + 4) & 0xe) != 0xc)))) {
      uVar18 = uVar16;
    }
  }
  else {
    uVar16 = *(uint *)(psVar12 + 2);
    if (uVar16 == 0) {
      func_0x(puVar1);
      uVar16 = *(uint *)(psVar12 + 2);
    }
    if ((8 < uVar16) ||
       (((**(byte **)(psVar12 + 4) & 0x1c) != 0 && ((**(byte **)(psVar12 + 4) & 0x1c) != 0xc)))) {
      uVar18 = uVar16;
    }
  }
  lVar11 = lStack_5d8;
  uStack_58 = *(undefined8 *)(psVar17 + 4);
  lVar9 = *(longlong *)(lStack_5d8 + 0x20);
  uStack_70 = uVar18;
  iVar25 = func_0x(lVar9);
  if (((iVar25 == 0) && (iVar25 = func_0x(lVar9), iVar25 == 0)) ||
     (*(char *)(lVar9 + 0x2050) != '\0')) {
    func_0x(*(undefined8 *)(lVar9 + 0x6b0));
    uVar18 = uStack_70;
  }
  puVar4 = puStack_68;
  uStack_57c = 0xffffffffffffffff;
  uStack_5b8 = 3;
  uStack_580 = 0;
  uStack_574 = 0;
  uStack_5c8 = 0;
  uStack_5a0 = 0;
  iStack_5c0 = (uVar18 + 3 & 0xfffffffc) + (iStack_74 + 3U & 0xfffffffc) +
               (iStack_78 + 3U & 0xfffffffc);
  uStack_598 = 0;
  piStack_5b0 = &iStack_78;
  ppuStack_5a8 = &puStack_68;
  uStack_588 = 0;
  puStack_590 = auStack_4b8;
  (**(code **)(**(longlong **)(lVar9 + 0x6c8) + 0x2c8))(*(longlong **)(lVar9 + 0x6c8),&uStack_5c8);
  func_0x(lVar9,puVar4);
  plVar3 = *(longlong **)(*(longlong *)(lVar11 + 0x20) + 0x6c8);
  uStack_568 = 0;
  uStack_560 = 0;
  (**(code **)(*plVar3 + 0x90))(plVar3,&uStack_568,0);
  func_0x(uStack_50 ^ (ulonglong)auStack_618);
  return;
}

