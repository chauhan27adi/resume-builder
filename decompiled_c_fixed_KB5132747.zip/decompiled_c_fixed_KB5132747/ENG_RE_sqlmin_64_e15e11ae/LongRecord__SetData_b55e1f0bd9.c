
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x001001bd) */
/* WARNING: Removing unreachable block (ram,0x01cf3501) */
/* WARNING: Removing unreachable block (ram,0x01cf3428) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong *param_2,undefined4 param_3,undefined8 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong unaff_GS_OFFSET;
  undefined4 auStackX_10 [4];
  undefined8 uStackX_20;
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar7 = func_0x();
  lVar7 = -lVar7;
  puVar1 = (undefined4 *)((longlong)auStackX_10 + lVar7);
  *(undefined8 *)(&stack0x00000128 + lVar7) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002150 + lVar7) = _DAT_ ^ (ulonglong)puVar1;
  *(undefined8 *)(&stack0x000000e8 + lVar7) = param_4;
  *(undefined4 *)((longlong)auStackX_10 + lVar7 + 8) = param_3;
  *(undefined8 *)(&stack0x000000d8 + lVar7) = param_1;
  uVar4 = *(undefined8 *)(&stack0x000021d0 + lVar7);
  *(undefined8 *)(&stack0x000000e0 + lVar7) = uVar4;
  *puVar1 = *(undefined4 *)(&stack0x000021d8 + lVar7);
  *(undefined8 *)(&stack0x000000b0 + lVar7) = *(undefined8 *)(&stack0x000021e8 + lVar7);
  *(undefined2 *)(&stack0x000000f0 + lVar7) = 0xffff;
  *(undefined8 *)(&stack0x000000f8 + lVar7) = 0;
  *(undefined4 *)(&stack0x000000f4 + lVar7) = 0;
  *(undefined8 *)(&stack0x0000010e + lVar7) = 0;
  *(undefined8 *)(&stack0x00000118 + lVar7) = 0;
  *(undefined8 *)(&stack0x00000100 + lVar7) = 0;
  *(undefined8 *)((longlong)&uStackX_20 + lVar7) = param_4;
  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1000ca;
  func_0x(&stack0x000001b0 + lVar7,0,0x1f9e);
  *(undefined4 *)((longlong)auStackX_10 + lVar7 + 4) = 0;
  lVar5 = *(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
           0x100);
  if (lVar5 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar6 = *(undefined8 *)(lVar5 + 1000);
  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100111;
  (*_DAT_)(&stack0x00000140 + lVar7,uVar6);
  *(undefined8 *)(&stack0x000000b8 + lVar7) = 0x2432ae0;
  *(undefined8 *)(&stack0x000000b8 + lVar7) = 0x2447890;
  *(undefined (*) [16])(&stack0x000000c0 + lVar7) = ZEXT816(0);
  *(undefined4 *)(&stack0x000000d0 + lVar7) = 0;
  *(undefined4 *)(&stack0x00000064 + lVar7) = 0;
  *(undefined8 *)(&stack0x00000078 + lVar7) = 0;
  *(undefined4 *)(&stack0x00000080 + lVar7) = 0;
  *(undefined8 *)(&stack0x00000048 + lVar7) = 0;
  *(undefined (*) [16])(&stack0x00000038 + lVar7) = ZEXT816(0);
  *(undefined4 *)(&stack0x00000028 + lVar7) = 0;
  *(undefined8 *)(&stack0x00000030 + lVar7) = 0;
  *(undefined2 *)(&stack0x0000002c + lVar7) = 0;
  if (*(longlong *)(*param_2 + 0xf0) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar2 = *puVar1;
  if ((*(ushort *)(*param_2 + 0xe) >> 0xe & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar3 = *(undefined4 *)(&stack0x000021e0 + lVar7);
  *(undefined8 *)((longlong)&uStackX_20 + lVar7 + -0x20) = *(undefined8 *)(&stack0x000000b0 + lVar7)
  ;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar7) = 0;
  *(undefined4 *)(&stack0xfffffffffffffff0 + lVar7) = uVar3;
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar7) = uVar2;
  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar7) = uVar4;
  uVar2 = *(undefined4 *)((longlong)auStackX_10 + lVar7 + 8);
  *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x1001f8;
  func_0x(*(undefined8 *)(&stack0x000000d8 + lVar7),param_2,uVar2,
                  *(undefined8 *)((longlong)&uStackX_20 + lVar7));
  if (*(longlong *)(&stack0x00000038 + lVar7) == 0) {
    *(undefined8 *)(&stack0x000000b8 + lVar7) = 0x2447890;
    if (*(longlong *)(&stack0x000000c8 + lVar7) == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100239;
      (*_DAT_)(&stack0x00000140 + lVar7);
      *(undefined8 *)((longlong)&uStack_48 + lVar7) = 0x100248;
      func_0x(*(ulonglong *)(&stack0x00002150 + lVar7) ^ (ulonglong)puVar1);
      return;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

