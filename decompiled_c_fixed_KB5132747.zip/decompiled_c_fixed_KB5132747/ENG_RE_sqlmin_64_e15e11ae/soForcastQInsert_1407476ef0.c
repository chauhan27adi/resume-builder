
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1,ushort param_2)

{
  longlong lVar1;
  longlong lVar2;
  byte *pbVar3;
  
  lVar1 = *(longlong *)(*(longlong *)(param_1 + 400) + (ulonglong)param_2 * 8);
  lVar2 = **(longlong **)(lVar1 + 0x50);
  pbVar3 = (byte *)((ulonglong)
                    *(ushort *)(lVar2 + (0x1000 - (ulonglong)*(ushort *)(lVar2 + 0x16)) * 2) + lVar2
                   );
  *(byte **)(lVar1 + 0x28) = pbVar3;
  if ((*pbVar3 & 1) == 0) {
                    /* WARNING: Could not emulate address calculation at 0x001000cc */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0xfffbc) - 0x44140))();
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

