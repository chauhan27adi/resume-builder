// NOTE: 1 cold fragment(s) of this function could not be laid out for the decompiler; branches into them appear unresolved.

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 param_5)

{
  code *pcVar1;
  undefined auStack_168 [72];
  undefined8 uStack_120;
  undefined4 uStack_118;
  undefined2 uStack_114;
  undefined8 uStack_110;
  undefined8 uStack_108;
  undefined2 uStack_100;
  undefined4 uStack_fc;
  byte *pbStack_f8;
  undefined8 uStack_f0;
  undefined8 uStack_e2;
  undefined2 uStack_da;
  undefined2 uStack_d8;
  undefined6 uStack_d6;
  undefined4 uStack_cc;
  ulonglong uStack_50;
  
  uStack_50 = _DAT_ ^ (ulonglong)auStack_168;
  uStack_110 = param_5;
  uStack_108 = *(undefined8 *)(**(longlong **)(param_1 + 8) + 8);
  if (param_2 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_114 = *(undefined2 *)(param_2 + 0x24);
  uStack_118 = *(undefined4 *)(param_2 + 0x20);
  uStack_100 = 0xffff;
  pbStack_f8 = (byte *)0x0;
  uStack_fc = 0;
  uStack_e2 = 0;
  uStack_d8 = 0;
  uStack_d6 = 0;
  uStack_f0 = 0;
  uStack_cc = 0;
  uStack_120 = param_4;
  if (-1 < *(char *)(param_2 + 2)) {
    pbStack_f8 = (byte *)((ulonglong)*(ushort *)(param_2 + 0x1ffe) + param_2);
    if ((*pbStack_f8 & 1) == 0) {
      uStack_100 = 0;
      uStack_fc = 0;
      uStack_da = 0;
      uStack_d8 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001000fc */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_f8 & 0xe) * 4 + 0xfffbc) - 0xe7070))
                ();
      return;
    }
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
  }
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}

