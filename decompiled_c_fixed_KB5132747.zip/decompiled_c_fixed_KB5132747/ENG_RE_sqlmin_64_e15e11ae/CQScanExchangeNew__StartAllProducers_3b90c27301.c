
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2)

{
  int *piVar1;
  undefined8 *puVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  longlong lVar6;
  longlong lVar7;
  int iVar8;
  ulonglong uVar9;
  undefined8 uVar10;
  longlong lVar11;
  ulonglong *puVar12;
  ulonglong uVar13;
  uint uVar14;
  longlong *plVar15;
  longlong unaff_GS_OFFSET;
  bool bVar16;
  uint uStack_5b8;
  int iStack_5b4;
  uint uStack_59c;
  uint uStack_598;
  longlong lStack_578;
  undefined4 uStack_554;
  int iStack_550;
  uint uStack_54c;
  undefined4 uStack_548;
  uint uStack_538;
  longlong lStack_530;
  ulonglong uStack_528;
  undefined8 uStack_520;
  undefined8 uStack_510;
  longlong lStack_4c0;
  undefined8 uStack_498;
  longlong lStack_488;
  longlong lStack_468;
  undefined4 uStack_460;
  undefined4 uStack_458;
  int iStack_43c;
  int iStack_438;
  int iStack_430;
  int iStack_42c;
  longlong lStack_3e0;
  undefined8 uStack_3d8;
  longlong *plStack_3c8;
  longlong lStack_390;
  longlong lStack_318;
  longlong lStack_310;
  undefined4 uStack_308;
  longlong lStack_2f0;
  longlong lStack_2e8;
  longlong *plStack_2e0;
  longlong *plStack_2d8;
  longlong lStack_2d0;
  longlong lStack_2c8;
  longlong lStack_2c0;
  undefined8 uStack_260;
  undefined8 uStack_258;
  ulonglong uStack_250;
  ulonglong uStack_248;
  longlong lStack_1f8;
  undefined8 *puStack_1f0;
  longlong lStack_1e8;
  longlong lStack_1e0;
  undefined8 uStack_68;
  longlong lStack_60;
  undefined8 uStack_58;
  
  uStack_68 = 0xfffffffffffffffe;
  uVar13 = 0;
  iStack_550 = 1;
  uStack_554 = 0;
  uStack_498 = 0;
  lStack_530 = 0xffffffffffffffff;
  lVar6 = *(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x50) + 0x1a8) + 0x20);
  lVar7 = *(longlong *)(*(longlong *)(lVar6 + 0x78) + 0x1a8);
  lStack_468 = *(longlong *)(lVar7 + 0x228) + 0x20;
  uStack_460 = 0;
  lStack_318 = lVar6;
  func_0x(&lStack_468,0x400302);
  lVar7 = *(longlong *)(lVar7 + 0x228);
  uVar9 = uVar13;
  if (lVar7 != 0) {
    uVar9 = *(ulonglong *)(lVar7 + 8);
  }
  uVar3 = *(uint *)(uVar9 + 0x14);
  lStack_3e0 = *(longlong *)(uVar9 + 0x28);
  uVar4 = *(uint *)(uVar9 + 0xc);
  lStack_4c0 = *(longlong *)(param_2 + 0x20);
  func_0x(param_2);
  if (*(uint *)(*(longlong *)(param_2 + 0x18) + 0x5c) < uVar4) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  LOCK();
  piVar1 = (int *)(*(longlong *)
                    (*(longlong *)
                      (*(longlong *)
                        ((ulonglong)*_DAT_ +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                        8) + 0x60) + 0x450) + 0x18);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  lVar7 = *(longlong *)
           (*(longlong *)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
               + 8) + 0x60) + 0x450);
  lStack_310 = lVar7;
  func_0x(lVar7);
  if (*(longlong **)(lVar7 + 0x30) == (longlong *)(lVar7 + 0x28)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lStack_578 = *(longlong *)(lVar7 + 0x28);
  func_0x(lVar7);
  lVar11 = *(longlong *)
            ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            0x100);
  if (lVar11 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar11 = *(longlong *)(*(longlong *)(lVar11 + 600) + 0xa0);
  iStack_5b4 = *(int *)(lVar11 + 0x1458);
  if (*(int *)(lVar11 + 0x13f8) == 0) {
    iStack_5b4 = iStack_5b4 + *(int *)(lVar11 + 0xde8);
  }
  uVar5 = *(uint *)(*(longlong *)(lVar6 + 0x88) + 0x130);
  uStack_5b8 = 0;
  uStack_538 = 0;
  uVar9 = uVar13;
  while ((uint)uVar9 < uVar4) {
    uVar14 = (uint)uVar9 + 1;
    uVar10 = func_0x(param_1,param_2,uVar14);
    *(undefined8 *)(lStack_4c0 + uVar9 * 8) = uVar10;
    uStack_538 = uVar14;
    uVar9 = (ulonglong)uVar14;
  }
  lStack_60 = *(longlong *)(*(longlong *)(param_1 + 0x50) + 0x1a8);
  if (*(longlong *)(*(longlong *)(lStack_60 + 0x228) + 0x18) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_58 = *(undefined8 *)(lStack_60 + 0x1f0);
  uVar10 = SUB168(ZEXT816(8) * ZEXT416(uVar4),0);
  if (SUB168(ZEXT816(8) * ZEXT416(uVar4),8) != 0) {
    uVar10 = 0xffffffffffffffff;
  }
  lVar11 = (*_DAT_)(uVar10,uStack_58,0x24f0fd8,0x35f,1);
  for (uVar9 = uVar13; (uint)uVar9 < uVar4; uVar9 = (ulonglong)((uint)uVar9 + 1)) {
    *(longlong *)(lVar11 + uVar9 * 8) = lVar6;
  }
  lStack_2f0 = lVar11;
  iVar8 = func_0x(lVar6,uVar4);
  if (iVar8 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_598 = 0;
  do {
    if (uVar3 <= (uint)uVar13) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    puVar2 = (undefined8 *)(lStack_3e0 + (ulonglong)uStack_598 * 0x18);
    uStack_498 = *puVar2;
    iVar8 = *(int *)(puVar2 + 2);
    if (uVar4 == 1) {
      iVar8 = 1;
    }
    if ((DAT_ & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uStack_308 = 0x58;
    lStack_2e8 = *(longlong *)(unaff_GS_OFFSET + 0x58);
    plStack_2e0 = (longlong *)
                  ((ulonglong)*_DAT_ +
                  *(longlong *)(lStack_2e8 + (ulonglong)*_DAT_ * 8));
    lStack_2d0 = *plStack_2e0;
    if ((lStack_2d0 != 0) && (lStack_2c0 = **(longlong **)(lStack_2d0 + 0x38), lStack_2c0 != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uStack_3d8 = 0;
    if (iStack_5b4 - 1U <= uVar5) {
      return;
    }
    plVar15 = puVar2 + 1;
    if (uVar4 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (plVar15 == (longlong *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar6 = *plVar15;
    uVar9 = (ulonglong)uStack_5b8;
    lStack_530 = lVar6;
    plStack_3c8 = plVar15;
    plStack_2d8 = plStack_2e0;
    lStack_2c8 = lStack_2d0;
    iStack_550 = func_0x(lVar7,0xf6870,0,lStack_4c0 + uVar9 * 8,lVar11 + uVar9 * 8,iVar8,
                                 uStack_498,&uStack_554,plVar15,0,1);
    if ((plVar15 != (longlong *)0x0) && (lVar6 != -1)) {
      *plVar15 = lVar6;
    }
    if (iStack_550 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uStack_59c = uStack_5b8;
    while ((uint)uVar9 < iVar8 + uStack_5b8) {
      if (lStack_578 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      lStack_578 = func_0x(lVar7);
      puVar12 = (ulonglong *)(lStack_578 + 0x20);
      uStack_260 = 0;
      uStack_258 = 0;
      uStack_510 = 0;
      uStack_520 = 0;
      uStack_528 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
      uStack_458 = 0x100;
      if (*(int *)puVar12 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      LOCK();
      uStack_250 = *puVar12;
      bVar16 = uStack_250 == 0;
      if (bVar16) {
        *puVar12 = uStack_528;
        uStack_250 = 0;
      }
      UNLOCK();
      uStack_54c = (uint)bVar16;
      if (uStack_54c == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      lVar6 = *(longlong *)(lStack_578 + 0x28);
      if (lVar6 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      lStack_1f8 = lVar6 + 0x10;
      LOCK();
      piVar1 = (int *)(lVar6 + 0x28);
      iStack_43c = *piVar1;
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      iStack_43c = iStack_43c + 1;
      lVar6 = *(longlong *)(lStack_578 + 0x28);
      puStack_1f0 = (undefined8 *)(lStack_578 + 0x20);
      if (*_DAT_ != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *puStack_1f0 = 0;
      lStack_488 = lVar6;
      iStack_438 = iStack_43c;
      uStack_248 = uStack_250;
      lStack_1e8 = lVar6;
      if (lVar6 != 0) {
        func_0x(param_2,lVar6,uStack_59c);
        lStack_1e0 = *(longlong *)(*(longlong *)(param_1 + 0x48) + 0xf8);
        uStack_548 = 0;
        if (*(int *)(lStack_1e0 + 0xc) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        lStack_390 = lVar6 + 0x10;
        LOCK();
        piVar1 = (int *)(lVar6 + 0x28);
        iStack_430 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        iStack_430 = iStack_430 + -1;
        iStack_42c = iStack_430;
        if (iStack_430 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
      }
      uStack_59c = uStack_59c + 1;
      uVar9 = (ulonglong)uStack_59c;
    }
    uStack_5b8 = uStack_5b8 + iVar8;
    uStack_598 = uStack_598 + 1;
    uVar13 = (ulonglong)uStack_598;
  } while( true );
}

