// NOTE: 4 cold fragment(s) of this function could not be laid out for the decompiler; branches into them appear unresolved.

/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined8 *param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  undefined auStack_128 [88];
  undefined8 uStack_d0;
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_128;
  uStack_d0 = param_4;
  cVar1 = (**(code **)*param_2)(param_2);
  if (cVar1 == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

