
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong *param_1)

{
  ushort uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  undefined4 *puVar6;
  undefined8 uVar7;
  longlong lVar8;
  uint uVar9;
  ulonglong uVar10;
  uint uVar11;
  longlong *plVar12;
  longlong unaff_GS_OFFSET;
  longlong unaff_retaddr;
  undefined auStackX_8 [8];
  longlong lStack_18;
  undefined2 uStack_10;
  
  *(undefined4 *)((longlong)param_1 + (ulonglong)(*(uint *)(param_1 + 0x46) & 0x3f) * 4 + 0x130) = 7
  ;
  uVar10 = (ulonglong)*(byte *)(param_1 + 0x347);
  param_1[0x46] = param_1[0x46] + 1;
  plVar12 = param_1 + uVar10 * 3;
  lVar5 = func_0x();
  plVar12[0x47] = lVar5;
  param_1[uVar10 * 3 + 0x48] = unaff_retaddr;
  plVar12[0x49] = 0x298;
  param_1[0x347] = param_1[0x347] + 1;
  func_0x(param_1);
  lVar5 = 0;
  do {
    while( true ) {
      plVar12 = (longlong *)param_1[0x355];
      if (plVar12 == (longlong *)0x0) {
        uVar11 = (uint)*(byte *)((longlong)param_1 + 0x22);
      }
      else {
        uVar11 = *(uint *)((longlong)plVar12 + 0x3cc);
      }
      if (uVar11 == 3) {
        return 0;
      }
      if (uVar11 == 2) {
        uVar1 = *(ushort *)(param_1 + 4);
        uVar9 = uVar1 - 1;
        *(short *)(param_1 + 4) = (short)uVar9;
        if ((short)uVar9 != 0) goto LAB_;
        *(ushort *)(param_1 + 4) = uVar1;
      }
      if (plVar12 == (longlong *)0x0) {
        (**(code **)(*param_1 + 0xa8))(param_1);
      }
      else {
        puVar6 = (undefined4 *)(**(code **)(*plVar12 + 0x38))(plVar12,_DAT_,0,0,0);
        uVar2 = puVar6[1];
        uVar3 = puVar6[2];
        uVar4 = puVar6[3];
        *(undefined4 *)(param_1 + 7) = *puVar6;
        *(undefined4 *)((longlong)param_1 + 0x3c) = uVar2;
        *(undefined4 *)(param_1 + 8) = uVar3;
        *(undefined4 *)((longlong)param_1 + 0x44) = uVar4;
        if (uVar11 != 1) {
          puVar6 = (undefined4 *)
                   (**(code **)(*(longlong *)param_1[0x355] + 0x60))
                             ((longlong *)param_1[0x355],auStackX_8);
          uVar2 = puVar6[1];
          *(undefined4 *)(param_1 + 3) = *puVar6;
          *(undefined4 *)((longlong)param_1 + 0x1c) = uVar2;
          *(undefined2 *)(param_1 + 4) = 0;
        }
        if ((((*(char *)(param_1 + 8) != '\0') && (*(short *)(param_1 + 10) == 0)) &&
            (*(int *)(param_1 + 9) == 0)) &&
           ((*(int *)((longlong)param_1 + 0x4c) == 0 && (lVar8 = param_1[7], lVar8 != 0)))) {
          param_1[9] = *(longlong *)(lVar8 + 0xc);
          *(undefined2 *)(param_1 + 10) = *(undefined2 *)(lVar8 + 0x14);
          *(short *)(param_1 + 10) = *(short *)(lVar8 + 2) + 1;
        }
      }
      lVar8 = param_1[7];
      if (lVar8 != 0) break;
      plVar12 = (longlong *)param_1[0x355];
      if (plVar12 == (longlong *)0x0) {
        *(undefined *)((longlong)param_1 + 0x22) = 3;
        param_1[5] = 0;
      }
      else {
        (**(code **)(*plVar12 + 0x30))(plVar12,1);
        param_1[5] = 0;
      }
    }
    if (uVar11 == 1) {
      if (param_1[0x355] == 0) {
        *(undefined *)((longlong)param_1 + 0x22) = 2;
      }
      if (*(ushort *)(lVar8 + 2) != 0) {
        if (*(ushort *)(lVar8 + 2) < *(ushort *)(param_1 + 4)) {
          lVar8 = func_0x();
          if (lVar8 == 0) {
            lVar8 = *(longlong *)
                     ((ulonglong)*_DAT_ + 8 +
                     *(longlong *)
                      ((ulonglong)*_DAT_ * 8 + *(longlong *)(unaff_GS_OFFSET + 0x58)));
            if (((lVar8 == 0) || (*(longlong *)(lVar8 + 0x60) == 0)) ||
               (*(char *)(*(longlong *)
                           (*(longlong *)
                             ((ulonglong)*_DAT_ + 8 +
                             *(longlong *)
                              ((ulonglong)*_DAT_ * 8 + *(longlong *)(unaff_GS_OFFSET + 0x58)
                              )) + 0x60) + 0x49f) == '\0')) {
              (*_DAT_)(1,0x11cc890,0x1189ee0,0xed5,0);
            }
          }
          plVar12 = (longlong *)param_1[0x355];
          if (plVar12 == (longlong *)0x0) {
            *(undefined *)((longlong)param_1 + 0x22) = 3;
          }
          else {
            (**(code **)(*plVar12 + 0x30))(plVar12,1);
          }
          uStack_10 = *(undefined2 *)(param_1 + 4);
          lStack_18 = param_1[3];
          param_1[5] = 0;
          lVar8 = *(longlong *)(*(longlong *)(param_1[2] + 8) + 0x6b0);
          (*_DAT_)(0x5a,3,0x14,8,&lStack_18,*(undefined4 *)(lVar8 + 0x3a0),lVar8 + 0x3a8);
        }
        uVar9 = (uint)*(ushort *)(param_1 + 4);
LAB_:
        lVar8 = func_0x(param_1 + 7,uVar9);
        param_1[5] = lVar8;
        if (3 < *(ushort *)param_1[7]) {
          lVar5 = *(longlong *)((ushort *)param_1[7] + 0x10);
        }
        param_1[6] = lVar5;
                    /* WARNING: Could not recover jumptable at 0x001001e9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        uVar7 = (**(code **)(*param_1 + 0x20))(param_1);
        return uVar7;
      }
    }
    *(short *)(param_1 + 4) = *(short *)(lVar8 + 2) + 1;
  } while( true );
}

