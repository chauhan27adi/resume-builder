
/* WARNING: Heritage AFTER dead removal. Example location: s0xffffffffffffcc30 : 0x001002a6 */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_(undefined8 param_1,longlong param_2,longlong param_3)

{
  byte *pbVar1;
  byte bVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  bool bVar11;
  undefined8 *puVar12;
  undefined8 *puVar13;
  char cVar14;
  longlong lVar15;
  undefined8 uVar16;
  ulonglong uVar17;
  undefined4 *puVar18;
  short *psVar19;
  short sVar20;
  ushort uVar21;
  undefined4 uVar22;
  undefined8 *puVar23;
  undefined8 *puVar24;
  longlong lVar25;
  ulonglong uVar26;
  longlong lVar27;
  longlong lVar28;
  longlong lVar29;
  undefined2 *puVar30;
  byte *pbVar31;
  undefined2 uVar32;
  uint uVar33;
  uint uVar34;
  longlong lVar35;
  short asStackX_8 [2];
  undefined4 uStackX_c;
  longlong lStackX_10;
  undefined2 auStackX_18 [4];
  byte **ppbStack_33f8;
  undefined auStack_33d0 [16];
  undefined auStack_33c0 [8];
  undefined8 uStack_33b8;
  undefined8 uStack_33b0;
  undefined6 uStack_33a8;
  undefined2 uStack_33a2;
  undefined6 uStack_33a0;
  undefined2 uStack_339a;
  undefined8 uStack_3398;
  undefined auStack_3390 [16];
  undefined auStack_3380 [16];
  undefined auStack_3370 [16];
  undefined8 uStack_3360;
  uint uStack_3358;
  undefined auStack_3354 [2];
  undefined2 auStack_3352 [128];
  undefined2 auStack_3252 [2308];
  undefined auStack_2049 [8193];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x100022;
  lVar15 = func_0x();
  lVar15 = -lVar15;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar15);
  ppbStack_33f8 = (byte **)0x0;
  *(longlong *)(&stack0x00000028 + lVar15) = param_3;
  lVar35 = -1;
  *(undefined8 *)(&stack0x00000040 + lVar15) = 0;
  param_3 = param_3 + 0x66;
  *(undefined2 *)(&stack0x00000038 + lVar15) = 0xffff;
  *(undefined4 *)(&stack0x0000003c + lVar15) = 0;
  lVar27 = -1;
  *(longlong *)(&stack0x00000030 + lVar15) = param_3;
  *(longlong *)((longlong)&lStackX_10 + lVar15) = param_2;
  *(undefined8 *)(&stack0x00000020 + lVar15) = param_1;
  do {
    lVar27 = lVar27 + 1;
  } while (*(short *)(param_3 + lVar27 * 2) != 0);
  param_2 = param_2 + 0x66;
  lVar25 = -1;
  do {
    lVar25 = lVar25 + 1;
  } while (*(short *)(param_2 + lVar25 * 2) != 0);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1000a3;
  uVar16 = (*_DAT_)();
  *(int *)(&stack0xffffffffffffffe8 + lVar15) = (int)lVar27 * 2;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1000b9;
  cVar14 = (*_DAT_)(uVar16,param_2,(int)lVar25 * 2,param_3);
  *(undefined4 *)((longlong)&uStackX_c + lVar15) = 2;
  if (cVar14 != '\0') {
    lVar27 = -1;
    do {
      lVar27 = lVar27 + 1;
    } while (*(short *)(param_2 + lVar27 * 2) != 0);
    *(longlong *)(&stack0xfffffffffffffff0 + lVar15) = param_2;
    *(int *)(&stack0xffffffffffffffe8 + lVar15) = (int)lVar27 * 2;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1000fa;
    (*_DAT_)(0x12,0x1c,0x10,2);
  }
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = 0x20;
  uVar26 = (ulonglong)auStack_2049 & 0xfffffffffffff000;
  *(undefined2 *)(&stack0xfffffffffffffffc + lVar15) = 1;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100130;
  func_0x(*(undefined8 *)(&stack0x00000020 + lVar15),0,uVar26,
                  &stack0xfffffffffffffff8 + lVar15);
  uVar34 = 0;
  if (*(char *)(uVar26 + 2) < '\0') {
    pbVar31 = (byte *)(uVar26 + 0x60);
    ppbStack_33f8 = (byte **)auStack_33d0;
    stack0xffffffffffffcc42 = SUB1614(ZEXT816(0),2);
    auStack_33c0._0_2_ = 0xffff;
    uStack_339a = SUB162(ZEXT816(0),6);
    uStack_33b8 = 0;
    uStack_33a2 = 0;
    uStack_33a0 = 0;
    uStack_33b0 = 0;
    auStack_3390 = ZEXT816(0);
    auStack_3370._0_12_ = ZEXT812(0);
    auStack_3370._12_4_ = 0;
    uStack_3360 = 0;
    auStack_3380 = ZEXT816(0);
    auStack_33d0 = ZEXT816(0);
    uStack_3360 = 0;
    uStack_3398 = 0;
    uStack_339a = 0;
    uStack_33a0 = 0;
    uStack_33a2 = 0;
    uStack_33a8 = 0;
    uStack_33b0 = 0;
    if (*(short *)(uVar26 + 0x24) == 0) {
LAB_:
      *(undefined8 *)(&stack0xfffffffffffffff8 + lVar15) = *(undefined8 *)(uVar26 + 0x28);
    }
    else {
      cVar14 = *(char *)(uVar26 + 1);
      if (cVar14 == '\v') {
        if (*(int *)(uVar26 + 0x18) != 99) {
LAB_:
          if (cVar14 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar14 != '\b') goto LAB_;
LAB_:
        if (*(int *)(uVar26 + 0x18) != 99) goto LAB_;
      }
      *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = *(undefined4 *)(uVar26 + 0x20);
      *(undefined2 *)(&stack0xfffffffffffffffc + lVar15) = *(undefined2 *)(uVar26 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100200;
      cVar14 = func_0x(&stack0xfffffffffffffff8 + lVar15);
      if (cVar14 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100211;
      func_0x(uVar26,&stack0xfffffffffffffff8 + lVar15);
    }
                    /* WARNING: Ignoring partial resolution of indirect */
    auStack_33d0._0_8_ = pbVar31;
                    /* WARNING: Ignoring partial resolution of indirect */
    auStack_3370._0_4_ = *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15);
                    /* WARNING: Ignoring partial resolution of indirect */
    uStack_3360._0_2_ = *(undefined2 *)(uVar26 + 0x24);
    sVar20 = *(short *)((ulonglong)*pbVar31 * 6 + 0x11f94a4);
                    /* WARNING: Ignoring partial resolution of indirect */
    auStack_33c0._0_2_ = 0xffff;
    uStack_33b0 = 0;
                    /* WARNING: Ignoring partial resolution of indirect */
    auStack_3380._0_8_ = 0;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) =
         *(undefined4 *)((ulonglong)*pbVar31 * 6 + 0x11f94a0);
    *(short *)((longlong)asStackX_8 + lVar15) = sVar20;
    if ((*pbVar31 & 2) != 0) {
      pbVar1 = pbVar31 + sVar20;
      if ((pbVar31[sVar20] & 1) == 0) {
                    /* WARNING: Ignoring partial resolution of indirect */
        auStack_33c0._0_2_ = 0;
        uVar33 = uVar34;
        switch(*pbVar1 & 0xe) {
        default:
          uVar33 = (uint)*(ushort *)(pbVar1 + 2);
          if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100491;
            func_0x(pbVar1,6);
          }
          break;
        case 4:
          uVar33 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar33 = 1;
        }
                    /* WARNING: Ignoring partial resolution of indirect */
        uStack_33b0._0_4_ = uVar33;
      }
      else {
                    /* WARNING: Ignoring partial resolution of indirect */
        auStack_33c0._0_2_ = 1;
        bVar2 = *pbVar1;
        switch(bVar2 & 0x1c) {
        default:
          if ((char)pbVar1[1] < '\0') {
            uVar32 = 3;
            uVar21 = (*(ushort *)(pbVar1 + 1) & 0x7f) << 8 | *(ushort *)(pbVar1 + 1) >> 8;
          }
          else {
            uVar32 = 2;
            uVar21 = (ushort)pbVar1[1];
          }
                    /* WARNING: Ignoring partial resolution of indirect */
          uStack_33a8._0_2_ = uVar32;
          if (uVar21 < 0x1f) {
                    /* WARNING: Ignoring partial resolution of indirect */
            auStack_3390._0_4_ = 0;
            uStack_33b0 = 0;
          }
          else {
                    /* WARNING: Ignoring partial resolution of indirect */
            auStack_3390._0_4_ = 0;
            uStack_33b0 = 0;
          }
          break;
        case 4:
          if (((bVar2 & 0x1c) != 4) || (bVar11 = true, (bVar2 & 2) == 0)) {
            bVar11 = false;
          }
          if (bVar11) {
                    /* WARNING: Ignoring partial resolution of indirect */
            auStack_3390._0_4_ = 0;
          }
                    /* WARNING: Ignoring partial resolution of indirect */
          auStack_3390._0_4_ = (uint)bVar11;
          uStack_33b0 = 0;
          break;
        case 8:
                    /* WARNING: Ignoring partial resolution of indirect */
          auStack_3390._0_4_ = 0;
          uStack_33b0 = 0;
        }
      }
      sVar20 = *(short *)((longlong)asStackX_8 + lVar15);
    }
    if ((*(byte *)auStack_33d0._0_8_ & 4) != 0) {
      if (*(short *)(&stack0xfffffffffffffffa + lVar15) == 0) {
        uVar17 = (ulonglong)sVar20;
      }
      else {
        uVar17 = (ulonglong)
                 *(ushort *)
                  (uVar26 + 0x61 + (longlong)*(short *)(&stack0xfffffffffffffffa + lVar15) * 2);
      }
                    /* WARNING: Ignoring partial resolution of indirect */
      auStack_3380._0_8_ = pbVar31 + uVar17 + 2;
    }
    if (auStack_33d0._8_8_ != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10052e;
      func_0x(auStack_33d0._8_8_,ppbStack_33f8);
    }
  }
  lVar27 = 6;
  uVar33 = (uint)*(ushort *)(uVar26 + 0xe);
  pbVar31 = (byte *)(*(ushort *)(uVar26 + 0x1ffe) + uVar26);
  bVar2 = *pbVar31;
  *(byte **)(&stack0x00000040 + lVar15) = pbVar31;
  if ((bVar2 & 1) == 0) {
    *(undefined2 *)(&stack0x00000038 + lVar15) = 0;
    *(undefined4 *)(&stack0x0000003c + lVar15) = 0;
    switch(*pbVar31 & 0xe) {
    default:
      uVar33 = (uint)*(ushort *)(pbVar31 + 2);
      if (0x1f9d < *(ushort *)(pbVar31 + 2) - 1) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1006f6;
        func_0x(pbVar31,6);
      }
      break;
    case 4:
      uVar33 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar33 = 1;
    }
    ppbStack_33f8 = (byte **)(ulonglong)uVar33;
  }
  else {
    *(undefined2 *)(&stack0x00000038 + lVar15) = 1;
    bVar2 = *pbVar31;
    switch(bVar2 & 0x1c) {
    default:
      if ((char)pbVar31[1] < '\0') {
        uVar21 = (*(ushort *)(pbVar31 + 1) & 0x7f) << 8 | *(ushort *)(pbVar31 + 1) >> 8;
        *(ushort *)(&stack0x0000003a + lVar15) = uVar21;
      }
      else {
        uVar21 = (ushort)pbVar31[1];
        *(ushort *)(&stack0x0000003a + lVar15) = uVar21;
      }
      if (uVar21 < 0x1f) {
        *(undefined4 *)(&stack0x0000003c + lVar15) = 0;
      }
      else {
        *(undefined4 *)(&stack0x0000003c + lVar15) = 0;
      }
      break;
    case 4:
      if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
        *(undefined2 *)(&stack0x0000003a + lVar15) = 0;
        *(undefined4 *)(&stack0x0000003c + lVar15) = 0xf;
      }
      else {
        *(undefined2 *)(&stack0x0000003a + lVar15) = 0;
        *(undefined4 *)(&stack0x0000003c + lVar15) = 1;
      }
      break;
    case 8:
      *(undefined2 *)(&stack0x0000003a + lVar15) = 0;
      *(undefined4 *)(&stack0x0000003c + lVar15) = 9;
    }
  }
  if ((undefined8 *)(*(longlong *)(&stack0x00000040 + lVar15) + 4) == (undefined8 *)0x0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1007ca;
    func_0x(auStack_3354,0,0x30a);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1007d0;
    puVar18 = (undefined4 *)(*pcRam000000000107db70)();
    *puVar18 = 0x16;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1007dc;
    (*pcRam000000000107db88)();
  }
  else {
    puVar12 = (undefined8 *)(*(longlong *)(&stack0x00000040 + lVar15) + 4);
    puVar13 = (undefined8 *)&uStack_3358;
    do {
      puVar24 = puVar13;
      puVar23 = puVar12;
      uVar22 = *(undefined4 *)((longlong)puVar23 + 4);
      uVar3 = *(undefined4 *)(puVar23 + 1);
      uVar4 = *(undefined4 *)((longlong)puVar23 + 0xc);
      uVar5 = *(undefined4 *)(puVar23 + 2);
      uVar6 = *(undefined4 *)((longlong)puVar23 + 0x14);
      uVar7 = *(undefined4 *)(puVar23 + 3);
      uVar8 = *(undefined4 *)((longlong)puVar23 + 0x1c);
      *(undefined4 *)puVar24 = *(undefined4 *)puVar23;
      *(undefined4 *)((longlong)puVar24 + 4) = uVar22;
      *(undefined4 *)(puVar24 + 1) = uVar3;
      *(undefined4 *)((longlong)puVar24 + 0xc) = uVar4;
      uVar22 = *(undefined4 *)(puVar23 + 4);
      uVar3 = *(undefined4 *)((longlong)puVar23 + 0x24);
      uVar4 = *(undefined4 *)(puVar23 + 5);
      uVar9 = *(undefined4 *)((longlong)puVar23 + 0x2c);
      *(undefined4 *)(puVar24 + 2) = uVar5;
      *(undefined4 *)((longlong)puVar24 + 0x14) = uVar6;
      *(undefined4 *)(puVar24 + 3) = uVar7;
      *(undefined4 *)((longlong)puVar24 + 0x1c) = uVar8;
      uVar5 = *(undefined4 *)(puVar23 + 6);
      uVar6 = *(undefined4 *)((longlong)puVar23 + 0x34);
      uVar7 = *(undefined4 *)(puVar23 + 7);
      uVar8 = *(undefined4 *)((longlong)puVar23 + 0x3c);
      *(undefined4 *)(puVar24 + 4) = uVar22;
      *(undefined4 *)((longlong)puVar24 + 0x24) = uVar3;
      *(undefined4 *)(puVar24 + 5) = uVar4;
      *(undefined4 *)((longlong)puVar24 + 0x2c) = uVar9;
      uVar22 = *(undefined4 *)(puVar23 + 8);
      uVar3 = *(undefined4 *)((longlong)puVar23 + 0x44);
      uVar4 = *(undefined4 *)(puVar23 + 9);
      uVar9 = *(undefined4 *)((longlong)puVar23 + 0x4c);
      *(undefined4 *)(puVar24 + 6) = uVar5;
      *(undefined4 *)((longlong)puVar24 + 0x34) = uVar6;
      *(undefined4 *)(puVar24 + 7) = uVar7;
      *(undefined4 *)((longlong)puVar24 + 0x3c) = uVar8;
      uVar6 = *(undefined4 *)(puVar23 + 10);
      uVar7 = *(undefined4 *)((longlong)puVar23 + 0x54);
      uVar8 = *(undefined4 *)(puVar23 + 0xb);
      uVar10 = *(undefined4 *)((longlong)puVar23 + 0x5c);
      *(undefined4 *)(puVar24 + 8) = uVar22;
      *(undefined4 *)((longlong)puVar24 + 0x44) = uVar3;
      *(undefined4 *)(puVar24 + 9) = uVar4;
      *(undefined4 *)((longlong)puVar24 + 0x4c) = uVar9;
      uVar22 = *(undefined4 *)(puVar23 + 0xc);
      uVar3 = *(undefined4 *)((longlong)puVar23 + 100);
      uVar4 = *(undefined4 *)(puVar23 + 0xd);
      uVar5 = *(undefined4 *)((longlong)puVar23 + 0x6c);
      *(undefined4 *)(puVar24 + 10) = uVar6;
      *(undefined4 *)((longlong)puVar24 + 0x54) = uVar7;
      *(undefined4 *)(puVar24 + 0xb) = uVar8;
      *(undefined4 *)((longlong)puVar24 + 0x5c) = uVar10;
      uVar6 = *(undefined4 *)(puVar23 + 0xe);
      uVar7 = *(undefined4 *)((longlong)puVar23 + 0x74);
      uVar8 = *(undefined4 *)(puVar23 + 0xf);
      uVar9 = *(undefined4 *)((longlong)puVar23 + 0x7c);
      *(undefined4 *)(puVar24 + 0xc) = uVar22;
      *(undefined4 *)((longlong)puVar24 + 100) = uVar3;
      *(undefined4 *)(puVar24 + 0xd) = uVar4;
      *(undefined4 *)((longlong)puVar24 + 0x6c) = uVar5;
      *(undefined4 *)(puVar24 + 0xe) = uVar6;
      *(undefined4 *)((longlong)puVar24 + 0x74) = uVar7;
      *(undefined4 *)(puVar24 + 0xf) = uVar8;
      *(undefined4 *)((longlong)puVar24 + 0x7c) = uVar9;
      lVar27 = lVar27 + -1;
      puVar12 = puVar23 + 0x10;
      puVar13 = puVar24 + 0x10;
    } while (lVar27 != 0);
    puVar24[0x10] = puVar23[0x10];
    *(undefined4 *)(puVar24 + 0x11) = *(undefined4 *)(puVar23 + 0x11);
    *(undefined2 *)((longlong)puVar24 + 0x8c) = *(undefined2 *)((longlong)puVar23 + 0x8c);
  }
  lVar27 = *(longlong *)((longlong)&lStackX_10 + lVar15);
  uStack_3358 = *(uint *)(lVar27 + 0x38) & 0xf250397f;
  lVar25 = -1;
  do {
    lVar25 = lVar25 + 1;
  } while (*(short *)(param_2 + lVar25 * 2) != 0);
  lVar28 = (longlong)(int)lVar25;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100815;
  func_0x(auStack_3352,0x100,param_2,lVar28 * 2);
  lVar25 = 0x80 - lVar28;
  if (lVar25 != 0) {
    puVar30 = auStack_3352 + lVar28;
    for (; lVar25 != 0; lVar25 = lVar25 + -1) {
      *puVar30 = 0x20;
      puVar30 = puVar30 + 1;
    }
  }
  lVar27 = lVar27 + 0x168;
  lVar25 = -1;
  do {
    lVar25 = lVar25 + 1;
  } while (*(short *)(lVar27 + lVar25 * 2) != 0);
  lVar25 = (longlong)(int)lVar25;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100862;
  func_0x(auStack_3252,0x208,lVar27,lVar25 * 2);
  lVar27 = 0x104 - lVar25;
  if (lVar27 != 0) {
    puVar30 = auStack_3252 + lVar25;
    for (; lVar27 != 0; lVar27 = lVar27 + -1) {
      *puVar30 = 0x20;
      puVar30 = puVar30 + 1;
    }
  }
  if ((undefined8 *)(*(longlong *)(&stack0x00000040 + lVar15) + 4) == (undefined8 *)0x0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100893;
    puVar18 = (undefined4 *)(*pcRam000000000107db70)();
    *puVar18 = 0x16;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10089f;
    (*pcRam000000000107db88)();
  }
  else {
    lVar27 = 6;
    puVar12 = (undefined8 *)(*(longlong *)(&stack0x00000040 + lVar15) + 4);
    puVar13 = (undefined8 *)&uStack_3358;
    do {
      puVar24 = puVar13;
      puVar23 = puVar12;
      uVar22 = *(undefined4 *)((longlong)puVar24 + 4);
      uVar3 = *(undefined4 *)(puVar24 + 1);
      uVar4 = *(undefined4 *)((longlong)puVar24 + 0xc);
      uVar5 = *(undefined4 *)(puVar24 + 2);
      uVar6 = *(undefined4 *)((longlong)puVar24 + 0x14);
      uVar7 = *(undefined4 *)(puVar24 + 3);
      uVar8 = *(undefined4 *)((longlong)puVar24 + 0x1c);
      *(undefined4 *)puVar23 = *(undefined4 *)puVar24;
      *(undefined4 *)((longlong)puVar23 + 4) = uVar22;
      *(undefined4 *)(puVar23 + 1) = uVar3;
      *(undefined4 *)((longlong)puVar23 + 0xc) = uVar4;
      uVar22 = *(undefined4 *)(puVar24 + 4);
      uVar3 = *(undefined4 *)((longlong)puVar24 + 0x24);
      uVar4 = *(undefined4 *)(puVar24 + 5);
      uVar9 = *(undefined4 *)((longlong)puVar24 + 0x2c);
      *(undefined4 *)(puVar23 + 2) = uVar5;
      *(undefined4 *)((longlong)puVar23 + 0x14) = uVar6;
      *(undefined4 *)(puVar23 + 3) = uVar7;
      *(undefined4 *)((longlong)puVar23 + 0x1c) = uVar8;
      uVar5 = *(undefined4 *)(puVar24 + 6);
      uVar6 = *(undefined4 *)((longlong)puVar24 + 0x34);
      uVar7 = *(undefined4 *)(puVar24 + 7);
      uVar8 = *(undefined4 *)((longlong)puVar24 + 0x3c);
      *(undefined4 *)(puVar23 + 4) = uVar22;
      *(undefined4 *)((longlong)puVar23 + 0x24) = uVar3;
      *(undefined4 *)(puVar23 + 5) = uVar4;
      *(undefined4 *)((longlong)puVar23 + 0x2c) = uVar9;
      uVar22 = *(undefined4 *)(puVar24 + 8);
      uVar3 = *(undefined4 *)((longlong)puVar24 + 0x44);
      uVar4 = *(undefined4 *)(puVar24 + 9);
      uVar9 = *(undefined4 *)((longlong)puVar24 + 0x4c);
      *(undefined4 *)(puVar23 + 6) = uVar5;
      *(undefined4 *)((longlong)puVar23 + 0x34) = uVar6;
      *(undefined4 *)(puVar23 + 7) = uVar7;
      *(undefined4 *)((longlong)puVar23 + 0x3c) = uVar8;
      uVar6 = *(undefined4 *)(puVar24 + 10);
      uVar7 = *(undefined4 *)((longlong)puVar24 + 0x54);
      uVar8 = *(undefined4 *)(puVar24 + 0xb);
      uVar10 = *(undefined4 *)((longlong)puVar24 + 0x5c);
      *(undefined4 *)(puVar23 + 8) = uVar22;
      *(undefined4 *)((longlong)puVar23 + 0x44) = uVar3;
      *(undefined4 *)(puVar23 + 9) = uVar4;
      *(undefined4 *)((longlong)puVar23 + 0x4c) = uVar9;
      uVar22 = *(undefined4 *)(puVar24 + 0xc);
      uVar3 = *(undefined4 *)((longlong)puVar24 + 100);
      uVar4 = *(undefined4 *)(puVar24 + 0xd);
      uVar5 = *(undefined4 *)((longlong)puVar24 + 0x6c);
      *(undefined4 *)(puVar23 + 10) = uVar6;
      *(undefined4 *)((longlong)puVar23 + 0x54) = uVar7;
      *(undefined4 *)(puVar23 + 0xb) = uVar8;
      *(undefined4 *)((longlong)puVar23 + 0x5c) = uVar10;
      uVar6 = *(undefined4 *)(puVar24 + 0xe);
      uVar7 = *(undefined4 *)((longlong)puVar24 + 0x74);
      uVar8 = *(undefined4 *)(puVar24 + 0xf);
      uVar9 = *(undefined4 *)((longlong)puVar24 + 0x7c);
      *(undefined4 *)(puVar23 + 0xc) = uVar22;
      *(undefined4 *)((longlong)puVar23 + 100) = uVar3;
      *(undefined4 *)(puVar23 + 0xd) = uVar4;
      *(undefined4 *)((longlong)puVar23 + 0x6c) = uVar5;
      *(undefined4 *)(puVar23 + 0xe) = uVar6;
      *(undefined4 *)((longlong)puVar23 + 0x74) = uVar7;
      *(undefined4 *)(puVar23 + 0xf) = uVar8;
      *(undefined4 *)((longlong)puVar23 + 0x7c) = uVar9;
      lVar27 = lVar27 + -1;
      puVar12 = puVar23 + 0x10;
      puVar13 = puVar24 + 0x10;
    } while (lVar27 != 0);
    puVar23[0x10] = puVar24[0x10];
    *(undefined4 *)(puVar23 + 0x11) = *(undefined4 *)(puVar24 + 0x11);
    *(undefined2 *)((longlong)puVar23 + 0x8c) = *(undefined2 *)((longlong)puVar24 + 0x8c);
  }
  if (-1 < *(char *)(uVar26 + 2)) goto code_r0x00100cf1;
  pbVar31 = (byte *)(uVar26 + 0x60);
  if ((*(short *)(&stack0x00000038 + lVar15) == 0) || (ppbStack_33f8 == (byte **)0x0)) {
    ppbStack_33f8 = (byte **)auStack_33d0;
    stack0xffffffffffffcc42 = SUB1614(ZEXT816(0),2);
    auStack_33c0._0_2_ = 0xffff;
    uStack_33a8 = 0;
    uStack_339a = SUB162(ZEXT816(0),6);
    uStack_339a = 0;
    uStack_33b8 = 0;
    uStack_33a2 = 0;
    uStack_33a0 = 0;
    uStack_3398 = 0;
    uStack_33b0 = 0;
    auStack_3390 = ZEXT816(0);
    auStack_3370._0_12_ = ZEXT812(0);
    auStack_3370._12_4_ = 0;
    uStack_3360 = 0;
    auStack_3380 = ZEXT816(0);
    auStack_33d0 = ZEXT816(0);
  }
  if (*(short *)(uVar26 + 0x24) == 0) {
code_r0x001009ef:
    uVar32 = *(undefined2 *)(uVar26 + 0x30);
    *(undefined8 *)((longlong)&lStackX_10 + lVar15) = *(undefined8 *)(uVar26 + 0x28);
  }
  else {
    cVar14 = *(char *)(uVar26 + 1);
    if (cVar14 == '\v') {
      if (*(int *)(uVar26 + 0x18) != 99) {
code_r0x001009b2:
        if (cVar14 != '\t') goto code_r0x001009ef;
        goto code_r0x001009b6;
      }
    }
    else {
      if (cVar14 != '\b') goto code_r0x001009b2;
code_r0x001009b6:
      if (*(int *)(uVar26 + 0x18) != 99) goto code_r0x001009ef;
    }
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = *(undefined4 *)(uVar26 + 0x20);
    *(undefined2 *)(&stack0xfffffffffffffffc + lVar15) = *(undefined2 *)(uVar26 + 0x24);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1009d6;
    cVar14 = func_0x(&stack0xfffffffffffffff8 + lVar15);
    if (cVar14 == '\0') goto code_r0x001009ef;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1009e7;
    func_0x(uVar26,(longlong)&lStackX_10 + lVar15);
    uVar32 = *(undefined2 *)((longlong)auStackX_18 + lVar15);
  }
  uVar22 = *(undefined4 *)((longlong)&lStackX_10 + lVar15);
  *ppbStack_33f8 = pbVar31;
  *(undefined4 *)(ppbStack_33f8 + 0xc) = uVar22;
  uVar16 = *(undefined8 *)((longlong)&lStackX_10 + lVar15);
  *(undefined2 *)(ppbStack_33f8 + 0xd) = uVar32;
  *(int *)((longlong)ppbStack_33f8 + 100) = (int)((ulonglong)uVar16 >> 0x20);
  *(undefined4 *)((longlong)ppbStack_33f8 + 0x6c) = *(undefined4 *)(uVar26 + 0x20);
  *(undefined2 *)(ppbStack_33f8 + 0xe) = *(undefined2 *)(uVar26 + 0x24);
  *(undefined2 *)((longlong)ppbStack_33f8 + 0x72) = 0;
  uVar22 = *(undefined4 *)((ulonglong)*pbVar31 * 6 + 0x11f94a0);
  uVar17 = (ulonglong)*(short *)((ulonglong)*pbVar31 * 6 + 0x11f94a4);
  *(undefined2 *)(ppbStack_33f8 + 2) = 0xffff;
  ppbStack_33f8[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbStack_33f8 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbStack_33f8 + 0x2e) = 0;
  ppbStack_33f8[7] = (byte *)0x0;
  ppbStack_33f8[4] = (byte *)0x0;
  ppbStack_33f8[9] = (byte *)0x0;
  ppbStack_33f8[10] = (byte *)0x0;
  *(undefined2 *)(ppbStack_33f8 + 0xb) = 0;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = uVar22;
  if ((**ppbStack_33f8 & 2) != 0) {
    pbVar1 = pbVar31 + uVar17;
    if ((pbVar31[uVar17] & 1) == 0) {
      *(undefined2 *)(ppbStack_33f8 + 2) = 0;
      ppbStack_33f8[3] = pbVar1;
      *(undefined4 *)((longlong)ppbStack_33f8 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbStack_33f8 + 0x36) = 0;
      switch(*pbVar1 & 0xe) {
      default:
        uVar34 = (uint)*(ushort *)(pbVar1 + 2);
        if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100c55;
          func_0x(pbVar1,6);
        }
        break;
      case 4:
        uVar34 = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar34 = 1;
      }
      *(uint *)(ppbStack_33f8 + 4) = uVar34;
      *(undefined8 *)((longlong)ppbStack_33f8 + 0x2e) = 0;
    }
    else {
      *(undefined2 *)(ppbStack_33f8 + 2) = 1;
      ppbStack_33f8[3] = pbVar1;
      bVar2 = *pbVar1;
      switch(bVar2 & 0x1c) {
      default:
        if ((char)pbVar1[1] < '\0') {
          uVar21 = *(ushort *)(pbVar1 + 1);
          sVar20 = 3;
          *(ushort *)((longlong)ppbStack_33f8 + 0x12) = uVar21;
          uVar21 = (uVar21 & 0x7f) << 8 | uVar21 >> 8;
        }
        else {
          sVar20 = 2;
          uVar21 = (ushort)pbVar1[1];
        }
        *(ushort *)((longlong)ppbStack_33f8 + 0x12) = uVar21;
        *(short *)(ppbStack_33f8 + 5) = sVar20;
        uVar21 = *(ushort *)((longlong)ppbStack_33f8 + 0x12);
        *(short *)((longlong)ppbStack_33f8 + 0x2c) = (short)(uVar21 + 1 >> 1) + sVar20;
        if (uVar21 < 0x1f) {
          *(undefined2 *)((longlong)ppbStack_33f8 + 0x2a) = 0;
          *(undefined4 *)((longlong)ppbStack_33f8 + 0x14) = 0;
          *(undefined4 *)(ppbStack_33f8 + 8) = 0;
          ppbStack_33f8[7] = (byte *)0x0;
          ppbStack_33f8[4] = (byte *)0x0;
        }
        else {
          *(short *)((longlong)ppbStack_33f8 + 0x2a) = (short)((int)(uVar21 - 1) / 0x1e);
          *(undefined4 *)((longlong)ppbStack_33f8 + 0x14) = 0;
          *(undefined4 *)(ppbStack_33f8 + 8) = 0;
          ppbStack_33f8[7] = (byte *)0x0;
          ppbStack_33f8[4] = (byte *)0x0;
        }
        break;
      case 4:
        if (((bVar2 & 0x1c) != 4) || (uVar33 = 1, (bVar2 & 2) == 0)) {
          uVar33 = uVar34;
        }
        if (uVar33 == 0) {
          uVar22 = 1;
        }
        else {
          *(undefined4 *)(ppbStack_33f8 + 8) = 0;
          uVar22 = 0xf;
        }
        ppbStack_33f8[5] = (byte *)0x0;
        *(undefined2 *)((longlong)ppbStack_33f8 + 0x12) = 0;
        ppbStack_33f8[6] = (byte *)0x0;
        ppbStack_33f8[4] = (byte *)0x0;
        ppbStack_33f8[7] = (byte *)0x0;
        ppbStack_33f8[3] = pbVar1;
        *(undefined4 *)((longlong)ppbStack_33f8 + 0x14) = uVar22;
        *(uint *)(ppbStack_33f8 + 8) = (uint)(uVar33 != 0);
        ppbStack_33f8[7] = (byte *)0x0;
        ppbStack_33f8[4] = (byte *)0x0;
        break;
      case 8:
        ppbStack_33f8[7] = (byte *)0x0;
        ppbStack_33f8[7] = (byte *)0x0;
        ppbStack_33f8[5] = (byte *)0x0;
        *(undefined2 *)((longlong)ppbStack_33f8 + 0x12) = 0;
        ppbStack_33f8[6] = (byte *)0x0;
        ppbStack_33f8[4] = (byte *)0x0;
        ppbStack_33f8[3] = pbVar1;
        *(undefined4 *)((longlong)ppbStack_33f8 + 0x14) = 9;
        *(undefined4 *)(ppbStack_33f8 + 8) = 0;
        ppbStack_33f8[4] = (byte *)0x0;
      }
    }
  }
  if ((**ppbStack_33f8 & 4) != 0) {
    if (*(short *)(&stack0xfffffffffffffffa + lVar15) != 0) {
      uVar17 = (ulonglong)
               *(ushort *)
                (uVar26 + 0x61 + (longlong)*(short *)(&stack0xfffffffffffffffa + lVar15) * 2);
    }
    psVar19 = (short *)(pbVar31 + uVar17);
    ppbStack_33f8[9] = (byte *)psVar19;
    sVar20 = *psVar19;
    ppbStack_33f8[10] = (byte *)(psVar19 + 1);
    *(short *)(ppbStack_33f8 + 0xb) = (sVar20 + 1) * 2;
  }
  pbVar31 = ppbStack_33f8[1];
  if (pbVar31 != (byte *)0x0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100ce5;
    func_0x(pbVar31,ppbStack_33f8);
  }
code_r0x00100cf1:
  pbVar31 = (byte *)(*(ushort *)(uVar26 + 0x1ffc) + uVar26);
  bVar2 = *pbVar31;
  *(byte **)(&stack0x00000040 + lVar15) = pbVar31;
  if ((bVar2 & 1) == 0) {
    *(undefined2 *)(&stack0x00000038 + lVar15) = 0;
    *(undefined4 *)(&stack0x0000003c + lVar15) = 0;
    switch(*pbVar31 & 0xe) {
    default:
      if (0x1f9d < *(ushort *)(pbVar31 + 2) - 1) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100ea7;
        func_0x(pbVar31,6);
      }
      break;
    case 4:
      break;
    case 6:
    case 10:
      break;
    case 0xe:
    }
  }
  else {
    *(undefined2 *)(&stack0x00000038 + lVar15) = 1;
    bVar2 = *pbVar31;
    switch(bVar2 & 0x1c) {
    default:
      if ((char)pbVar31[1] < '\0') {
        uVar21 = (*(ushort *)(pbVar31 + 1) & 0x7f) << 8 | *(ushort *)(pbVar31 + 1) >> 8;
        *(undefined2 *)((longlong)&uStackX_c + lVar15) = 3;
        *(ushort *)(&stack0x0000003a + lVar15) = uVar21;
      }
      else {
        uVar21 = (ushort)pbVar31[1];
        *(ushort *)(&stack0x0000003a + lVar15) = uVar21;
      }
      if (uVar21 < 0x1f) {
        *(undefined4 *)(&stack0x0000003c + lVar15) = 0;
      }
      else {
        *(undefined4 *)(&stack0x0000003c + lVar15) = 0;
      }
      break;
    case 4:
      if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
        *(undefined2 *)(&stack0x0000003a + lVar15) = 0;
        *(undefined4 *)(&stack0x0000003c + lVar15) = 0xf;
      }
      else {
        *(undefined2 *)(&stack0x0000003a + lVar15) = 0;
        *(undefined4 *)(&stack0x0000003c + lVar15) = 1;
      }
      break;
    case 8:
      *(undefined2 *)(&stack0x0000003a + lVar15) = 0;
      *(undefined4 *)(&stack0x0000003c + lVar15) = 9;
    }
  }
  if ((undefined8 *)(*(longlong *)(&stack0x00000040 + lVar15) + 4) == (undefined8 *)0x0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100f8a;
    func_0x(auStack_3354,0,0x30a);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100f90;
    puVar18 = (undefined4 *)(*pcRam000000000107db70)();
    *puVar18 = 0x16;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100f9c;
    (*pcRam000000000107db88)();
  }
  else {
    lVar27 = 6;
    puVar12 = (undefined8 *)(*(longlong *)(&stack0x00000040 + lVar15) + 4);
    puVar13 = (undefined8 *)&uStack_3358;
    do {
      puVar24 = puVar13;
      puVar23 = puVar12;
      uVar22 = *(undefined4 *)((longlong)puVar23 + 4);
      uVar3 = *(undefined4 *)(puVar23 + 1);
      uVar4 = *(undefined4 *)((longlong)puVar23 + 0xc);
      uVar5 = *(undefined4 *)(puVar23 + 2);
      uVar6 = *(undefined4 *)((longlong)puVar23 + 0x14);
      uVar7 = *(undefined4 *)(puVar23 + 3);
      uVar8 = *(undefined4 *)((longlong)puVar23 + 0x1c);
      *(undefined4 *)puVar24 = *(undefined4 *)puVar23;
      *(undefined4 *)((longlong)puVar24 + 4) = uVar22;
      *(undefined4 *)(puVar24 + 1) = uVar3;
      *(undefined4 *)((longlong)puVar24 + 0xc) = uVar4;
      uVar22 = *(undefined4 *)(puVar23 + 4);
      uVar3 = *(undefined4 *)((longlong)puVar23 + 0x24);
      uVar4 = *(undefined4 *)(puVar23 + 5);
      uVar9 = *(undefined4 *)((longlong)puVar23 + 0x2c);
      *(undefined4 *)(puVar24 + 2) = uVar5;
      *(undefined4 *)((longlong)puVar24 + 0x14) = uVar6;
      *(undefined4 *)(puVar24 + 3) = uVar7;
      *(undefined4 *)((longlong)puVar24 + 0x1c) = uVar8;
      uVar5 = *(undefined4 *)(puVar23 + 6);
      uVar6 = *(undefined4 *)((longlong)puVar23 + 0x34);
      uVar7 = *(undefined4 *)(puVar23 + 7);
      uVar8 = *(undefined4 *)((longlong)puVar23 + 0x3c);
      *(undefined4 *)(puVar24 + 4) = uVar22;
      *(undefined4 *)((longlong)puVar24 + 0x24) = uVar3;
      *(undefined4 *)(puVar24 + 5) = uVar4;
      *(undefined4 *)((longlong)puVar24 + 0x2c) = uVar9;
      uVar22 = *(undefined4 *)(puVar23 + 8);
      uVar3 = *(undefined4 *)((longlong)puVar23 + 0x44);
      uVar4 = *(undefined4 *)(puVar23 + 9);
      uVar9 = *(undefined4 *)((longlong)puVar23 + 0x4c);
      *(undefined4 *)(puVar24 + 6) = uVar5;
      *(undefined4 *)((longlong)puVar24 + 0x34) = uVar6;
      *(undefined4 *)(puVar24 + 7) = uVar7;
      *(undefined4 *)((longlong)puVar24 + 0x3c) = uVar8;
      uVar6 = *(undefined4 *)(puVar23 + 10);
      uVar7 = *(undefined4 *)((longlong)puVar23 + 0x54);
      uVar8 = *(undefined4 *)(puVar23 + 0xb);
      uVar10 = *(undefined4 *)((longlong)puVar23 + 0x5c);
      *(undefined4 *)(puVar24 + 8) = uVar22;
      *(undefined4 *)((longlong)puVar24 + 0x44) = uVar3;
      *(undefined4 *)(puVar24 + 9) = uVar4;
      *(undefined4 *)((longlong)puVar24 + 0x4c) = uVar9;
      uVar22 = *(undefined4 *)(puVar23 + 0xc);
      uVar3 = *(undefined4 *)((longlong)puVar23 + 100);
      uVar4 = *(undefined4 *)(puVar23 + 0xd);
      uVar5 = *(undefined4 *)((longlong)puVar23 + 0x6c);
      *(undefined4 *)(puVar24 + 10) = uVar6;
      *(undefined4 *)((longlong)puVar24 + 0x54) = uVar7;
      *(undefined4 *)(puVar24 + 0xb) = uVar8;
      *(undefined4 *)((longlong)puVar24 + 0x5c) = uVar10;
      uVar6 = *(undefined4 *)(puVar23 + 0xe);
      uVar7 = *(undefined4 *)((longlong)puVar23 + 0x74);
      uVar8 = *(undefined4 *)(puVar23 + 0xf);
      uVar9 = *(undefined4 *)((longlong)puVar23 + 0x7c);
      *(undefined4 *)(puVar24 + 0xc) = uVar22;
      *(undefined4 *)((longlong)puVar24 + 100) = uVar3;
      *(undefined4 *)(puVar24 + 0xd) = uVar4;
      *(undefined4 *)((longlong)puVar24 + 0x6c) = uVar5;
      *(undefined4 *)(puVar24 + 0xe) = uVar6;
      *(undefined4 *)((longlong)puVar24 + 0x74) = uVar7;
      *(undefined4 *)(puVar24 + 0xf) = uVar8;
      *(undefined4 *)((longlong)puVar24 + 0x7c) = uVar9;
      lVar27 = lVar27 + -1;
      puVar12 = puVar23 + 0x10;
      puVar13 = puVar24 + 0x10;
    } while (lVar27 != 0);
    puVar24[0x10] = puVar23[0x10];
    *(undefined4 *)(puVar24 + 0x11) = *(undefined4 *)(puVar23 + 0x11);
    *(undefined2 *)((longlong)puVar24 + 0x8c) = *(undefined2 *)((longlong)puVar23 + 0x8c);
  }
  lVar28 = 6;
  lVar27 = *(longlong *)(&stack0x00000028 + lVar15);
  uStack_3358 = *(uint *)(lVar27 + 0x38) & 0xf250397f | 2;
  lVar25 = -1;
  do {
    lVar25 = lVar25 + 1;
  } while (*(short *)(*(longlong *)(&stack0x00000030 + lVar15) + lVar25 * 2) != 0);
  lVar29 = (longlong)(int)lVar25;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100fdf;
  func_0x(auStack_3352,0x100,*(longlong *)(&stack0x00000030 + lVar15),lVar29 * 2);
  lVar25 = 0x80 - lVar29;
  if (lVar25 != 0) {
    puVar30 = auStack_3352 + lVar29;
    for (; lVar25 != 0; lVar25 = lVar25 + -1) {
      *puVar30 = 0x20;
      puVar30 = puVar30 + 1;
    }
  }
  lVar27 = lVar27 + 0x168;
  do {
    lVar35 = lVar35 + 1;
  } while (*(short *)(lVar27 + lVar35 * 2) != 0);
  lVar35 = (longlong)(int)lVar35;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101022;
  func_0x(auStack_3252,0x208,lVar27,lVar35 * 2);
  lVar27 = 0x104 - lVar35;
  if (lVar27 != 0) {
    puVar30 = auStack_3252 + lVar35;
    for (; lVar27 != 0; lVar27 = lVar27 + -1) {
      *puVar30 = 0x20;
      puVar30 = puVar30 + 1;
    }
  }
  if ((undefined8 *)(*(longlong *)(&stack0x00000040 + lVar15) + 4) == (undefined8 *)0x0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x101053;
    puVar18 = (undefined4 *)(*pcRam000000000107db70)();
    *puVar18 = 0x16;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10105f;
    (*pcRam000000000107db88)();
  }
  else {
    puVar12 = (undefined8 *)(*(longlong *)(&stack0x00000040 + lVar15) + 4);
    puVar13 = (undefined8 *)&uStack_3358;
    do {
      puVar24 = puVar13;
      puVar23 = puVar12;
      uVar22 = *(undefined4 *)((longlong)puVar24 + 4);
      uVar3 = *(undefined4 *)(puVar24 + 1);
      uVar4 = *(undefined4 *)((longlong)puVar24 + 0xc);
      uVar5 = *(undefined4 *)(puVar24 + 2);
      uVar6 = *(undefined4 *)((longlong)puVar24 + 0x14);
      uVar7 = *(undefined4 *)(puVar24 + 3);
      uVar8 = *(undefined4 *)((longlong)puVar24 + 0x1c);
      *(undefined4 *)puVar23 = *(undefined4 *)puVar24;
      *(undefined4 *)((longlong)puVar23 + 4) = uVar22;
      *(undefined4 *)(puVar23 + 1) = uVar3;
      *(undefined4 *)((longlong)puVar23 + 0xc) = uVar4;
      uVar22 = *(undefined4 *)(puVar24 + 4);
      uVar3 = *(undefined4 *)((longlong)puVar24 + 0x24);
      uVar4 = *(undefined4 *)(puVar24 + 5);
      uVar9 = *(undefined4 *)((longlong)puVar24 + 0x2c);
      *(undefined4 *)(puVar23 + 2) = uVar5;
      *(undefined4 *)((longlong)puVar23 + 0x14) = uVar6;
      *(undefined4 *)(puVar23 + 3) = uVar7;
      *(undefined4 *)((longlong)puVar23 + 0x1c) = uVar8;
      uVar5 = *(undefined4 *)(puVar24 + 6);
      uVar6 = *(undefined4 *)((longlong)puVar24 + 0x34);
      uVar7 = *(undefined4 *)(puVar24 + 7);
      uVar8 = *(undefined4 *)((longlong)puVar24 + 0x3c);
      *(undefined4 *)(puVar23 + 4) = uVar22;
      *(undefined4 *)((longlong)puVar23 + 0x24) = uVar3;
      *(undefined4 *)(puVar23 + 5) = uVar4;
      *(undefined4 *)((longlong)puVar23 + 0x2c) = uVar9;
      uVar22 = *(undefined4 *)(puVar24 + 8);
      uVar3 = *(undefined4 *)((longlong)puVar24 + 0x44);
      uVar4 = *(undefined4 *)(puVar24 + 9);
      uVar9 = *(undefined4 *)((longlong)puVar24 + 0x4c);
      *(undefined4 *)(puVar23 + 6) = uVar5;
      *(undefined4 *)((longlong)puVar23 + 0x34) = uVar6;
      *(undefined4 *)(puVar23 + 7) = uVar7;
      *(undefined4 *)((longlong)puVar23 + 0x3c) = uVar8;
      uVar6 = *(undefined4 *)(puVar24 + 10);
      uVar7 = *(undefined4 *)((longlong)puVar24 + 0x54);
      uVar8 = *(undefined4 *)(puVar24 + 0xb);
      uVar10 = *(undefined4 *)((longlong)puVar24 + 0x5c);
      *(undefined4 *)(puVar23 + 8) = uVar22;
      *(undefined4 *)((longlong)puVar23 + 0x44) = uVar3;
      *(undefined4 *)(puVar23 + 9) = uVar4;
      *(undefined4 *)((longlong)puVar23 + 0x4c) = uVar9;
      uVar22 = *(undefined4 *)(puVar24 + 0xc);
      uVar3 = *(undefined4 *)((longlong)puVar24 + 100);
      uVar4 = *(undefined4 *)(puVar24 + 0xd);
      uVar5 = *(undefined4 *)((longlong)puVar24 + 0x6c);
      *(undefined4 *)(puVar23 + 10) = uVar6;
      *(undefined4 *)((longlong)puVar23 + 0x54) = uVar7;
      *(undefined4 *)(puVar23 + 0xb) = uVar8;
      *(undefined4 *)((longlong)puVar23 + 0x5c) = uVar10;
      uVar6 = *(undefined4 *)(puVar24 + 0xe);
      uVar7 = *(undefined4 *)((longlong)puVar24 + 0x74);
      uVar8 = *(undefined4 *)(puVar24 + 0xf);
      uVar9 = *(undefined4 *)((longlong)puVar24 + 0x7c);
      *(undefined4 *)(puVar23 + 0xc) = uVar22;
      *(undefined4 *)((longlong)puVar23 + 100) = uVar3;
      *(undefined4 *)(puVar23 + 0xd) = uVar4;
      *(undefined4 *)((longlong)puVar23 + 0x6c) = uVar5;
      *(undefined4 *)(puVar23 + 0xe) = uVar6;
      *(undefined4 *)((longlong)puVar23 + 0x74) = uVar7;
      *(undefined4 *)(puVar23 + 0xf) = uVar8;
      *(undefined4 *)((longlong)puVar23 + 0x7c) = uVar9;
      lVar28 = lVar28 + -1;
      puVar12 = puVar23 + 0x10;
      puVar13 = puVar24 + 0x10;
    } while (lVar28 != 0);
    puVar23[0x10] = puVar24[0x10];
    *(undefined4 *)(puVar23 + 0x11) = *(undefined4 *)(puVar24 + 0x11);
    *(undefined2 *)((longlong)puVar23 + 0x8c) = *(undefined2 *)((longlong)puVar24 + 0x8c);
  }
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = 0x20;
  *(undefined2 *)(&stack0xfffffffffffffffc + lVar15) = 1;
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1010fc;
  func_0x(*(undefined8 *)(&stack0x00000020 + lVar15));
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10110b;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar15));
  return;
}

