
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined8 *puVar1;
  byte *pbVar2;
  undefined4 *puVar3;
  uint uVar4;
  int iVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  longlong lVar12;
  longlong lVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  undefined8 unaff_RBX;
  undefined8 unaff_RSI;
  longlong lVar16;
  undefined8 unaff_RDI;
  longlong lVar17;
  undefined4 uVar18;
  int iVar19;
  longlong unaff_GS_OFFSET;
  undefined8 auStackX_8 [2];
  undefined8 auStackX_18 [2];
  undefined8 uStack_30;
  
  uStack_30 = 0x100014;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  puVar1 = (undefined8 *)((longlong)auStackX_8 + lVar12);
  *puVar1 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002100 + lVar12) = unaff_RBX;
  *(undefined8 *)(&stack0x00002108 + lVar12) = unaff_RSI;
  *(undefined8 *)(&stack0x00002110 + lVar12) = unaff_RDI;
  *(ulonglong *)(&stack0x000020b8 + lVar12) = _DAT_ ^ (ulonglong)puVar1;
  uVar6 = *(undefined8 *)(&stack0x00002120 + lVar12);
  lVar7 = *(longlong *)(&stack0x00002128 + lVar12);
  *(undefined8 *)((longlong)&uStack_30 + lVar12) = 0x100071;
  func_0x((longlong)auStackX_18 + lVar12,&stack0x00000120 + lVar12);
  *(undefined8 *)((longlong)auStackX_18 + lVar12) = 0x853c28;
  uVar18 = 0;
  if ((((*(byte *)(*(longlong *)(*(longlong *)(param_1 + 0x58) + 8) + 0x107) & 0x40) != 0) &&
      (uVar18 = 0, (*(byte *)(*(longlong *)(param_3 + 0x12) + 0xc) & 4) != 0)) &&
     (uVar18 = 0, *(int *)(&stack0x00002118 + lVar12) != 0)) {
    uVar18 = 0x20;
  }
  *(undefined4 *)((longlong)auStackX_18 + lVar12 + -0x18) = uVar18;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar12) = *param_3;
  *(undefined8 *)((longlong)&uStack_30 + lVar12) = 0x1000c9;
  func_0x((longlong)auStackX_18 + lVar12,param_1,uVar6);
  *(undefined8 *)((longlong)&uStack_30 + lVar12) = 0x1000d2;
  func_0x((longlong)auStackX_18 + lVar12);
  if ((((*(uint *)(&stack0x00000054 + lVar12) & 0x800) == 0) ||
      (*(int *)(&stack0x00000038 + lVar12) != 0)) || (*(short *)(&stack0x0000003c + lVar12) != 0)) {
    uVar14 = 0x10;
  }
  else {
    lVar8 = *(longlong *)(&stack0x00000068 + lVar12);
    if ((*(byte *)(lVar8 + 0xc) & 0xf) == 0) {
      uVar14 = (ulonglong)*(ushort *)(lVar8 + 0xe);
    }
    else {
      uVar14 = (ulonglong)(ushort)((*(short *)(lVar8 + 0x10) + 1) * 0xc);
    }
  }
  uVar15 = uVar14 + 0xf;
  if (uVar15 <= uVar14) {
    uVar15 = 0xffffffffffffff0;
  }
  uVar15 = uVar15 & 0xfffffffffffffff0;
  *(undefined8 *)((longlong)&uStack_30 + lVar12) = 0x100135;
  func_0x();
  lVar9 = -uVar15;
  lVar8 = (longlong)auStackX_8 + lVar9 + lVar12;
  uVar14 = uVar14 & 0xffff;
  iVar19 = (int)uVar14;
  *(undefined8 *)((longlong)&uStack_30 + lVar9 + lVar12) = 0x100150;
  func_0x((longlong)auStackX_18 + lVar12,uVar14,lVar8);
  *(undefined8 *)((longlong)&uStack_30 + lVar9 + lVar12) = 0x100159;
  func_0x((longlong)auStackX_18 + lVar12);
  lVar16 = (ulonglong)*(uint *)(lVar7 + 4) * 0x40;
  pbVar2 = (byte *)(lVar16 + 0x18 + *(longlong *)(lVar7 + 8));
  *pbVar2 = *pbVar2 & 0xfb;
  if (*(uint *)(lVar7 + 0x20) < (uint)(*(int *)(lVar7 + 0x10) + iVar19)) {
    lVar17 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar13 = *(longlong *)(lVar17 + 0x100);
    if (lVar13 == 0) {
      *(undefined8 *)((longlong)&uStack_30 + lVar9 + lVar12) = 0x1001ab;
      (*_DAT_)(0);
      lVar13 = *(longlong *)(lVar17 + 0x100);
    }
    (&stack0xfffffffffffffff8)[lVar9 + lVar12] = 5;
    uVar6 = *(undefined8 *)(lVar13 + 1000);
    *(undefined8 *)((longlong)&uStack_30 + lVar9 + lVar12) = 0x1001d6;
    lVar13 = (*_DAT_)(0x1f9e,uVar6,0xbd7658,0xda);
    if (lVar13 == 0) {
      lVar13 = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_30 + lVar9 + lVar12) = 0x1001ee;
      func_0x(lVar13,0,0x1f9e);
    }
    *(longlong *)(lVar7 + 0x18) = lVar13;
    *(undefined4 *)(lVar7 + 0x10) = 0;
    pbVar2 = (byte *)(lVar16 + 0x18 + *(longlong *)(lVar7 + 8));
    *pbVar2 = *pbVar2 | 4;
    *(undefined4 *)(lVar7 + 0x20) = 0x1f9e;
  }
  uVar18 = param_3[1];
  uVar10 = param_3[2];
  uVar11 = param_3[3];
  puVar3 = (undefined4 *)(lVar16 + 8 + *(longlong *)(lVar7 + 8));
  *puVar3 = *param_3;
  puVar3[1] = uVar18;
  puVar3[2] = uVar10;
  puVar3[3] = uVar11;
  *(undefined4 *)(lVar16 + *(longlong *)(lVar7 + 8)) = param_2;
  pbVar2 = (byte *)(lVar16 + 0x18 + *(longlong *)(lVar7 + 8));
  *pbVar2 = *pbVar2 & 0xfe;
  pbVar2 = (byte *)(lVar16 + 0x18 + *(longlong *)(lVar7 + 8));
  *pbVar2 = *pbVar2 & 0xfd;
  lVar16 = *(longlong *)(lVar7 + 8) + lVar16;
  *(ulonglong *)(lVar16 + 0x20) = (ulonglong)*(uint *)(lVar7 + 0x10) + *(longlong *)(lVar7 + 0x18);
  *(int *)(lVar16 + 0x28) = iVar19;
  uVar4 = *(uint *)(lVar16 + 0x2c);
  *(uint *)(lVar16 + 0x2c) = uVar4 & 0xfffffffb | 1;
  uVar18 = param_3[1];
  uVar10 = param_3[2];
  uVar11 = param_3[3];
  *(undefined4 *)(lVar16 + 0x30) = *param_3;
  *(undefined4 *)(lVar16 + 0x34) = uVar18;
  *(undefined4 *)(lVar16 + 0x38) = uVar10;
  *(undefined4 *)(lVar16 + 0x3c) = uVar11;
  *(uint *)(lVar16 + 0x2c) = uVar4 & 0xfffffff1 | 1;
  uVar4 = *(uint *)(lVar7 + 0x10);
  iVar5 = *(int *)(lVar7 + 0x20);
  lVar16 = *(longlong *)(lVar7 + 0x18);
  *(undefined8 *)((longlong)&uStack_30 + lVar9 + lVar12) = 0x10027b;
  func_0x((ulonglong)uVar4 + lVar16,iVar5 - uVar4,lVar8,uVar14);
  *(int *)(lVar7 + 4) = *(int *)(lVar7 + 4) + 1;
  *(int *)(lVar7 + 0x10) = *(int *)(lVar7 + 0x10) + iVar19;
  *(undefined8 *)((longlong)&uStack_30 + lVar9 + lVar12) = 0x10028b;
  func_0x((longlong)auStackX_18 + lVar12);
  uVar14 = *(ulonglong *)(&stack0x000020b8 + lVar12);
  *(undefined8 *)((longlong)&uStack_30 + lVar9 + lVar12) = 0x10029a;
  func_0x(uVar14 ^ (ulonglong)puVar1);
  return;
}

