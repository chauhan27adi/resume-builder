
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  undefined2 uVar1;
  undefined8 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint uVar7;
  undefined8 uVar8;
  longlong lVar9;
  ulonglong uVar10;
  undefined2 *puVar11;
  int iVar12;
  undefined8 unaff_retaddr;
  undefined auStack_2b8 [32];
  undefined8 uStack_298;
  undefined8 uStack_290;
  undefined *puStack_288;
  undefined4 auStack_278 [4];
  ulonglong uStack_268;
  ushort uStack_260;
  undefined2 *puStack_258;
  uint uStack_250;
  undefined4 uStack_24c;
  undefined8 uStack_248;
  ushort uStack_240;
  undefined auStack_238 [512];
  ulonglong uStack_38;
  
  uStack_38 = _DAT_ ^ (ulonglong)auStack_2b8;
  *(undefined4 *)(param_1 + 0x130 + (ulonglong)(*(uint *)(param_1 + 0x230) & 0x3f) * 4) = 0xd;
  uVar10 = (ulonglong)*(byte *)(param_1 + 0x1a38);
  *(longlong *)(param_1 + 0x230) = *(longlong *)(param_1 + 0x230) + 1;
  lVar9 = param_1 + uVar10 * 0x18;
  uVar8 = func_0x();
  *(undefined8 *)(lVar9 + 0x238) = uVar8;
  *(undefined8 *)(param_1 + 0x240 + uVar10 * 0x18) = unaff_retaddr;
  *(undefined8 *)(lVar9 + 0x248) = 0x298;
  uStack_248 = *(ulonglong *)(param_1 + 0x90);
  *(longlong *)(param_1 + 0x1a38) = *(longlong *)(param_1 + 0x1a38) + 1;
  uStack_240 = *(ushort *)(param_1 + 0x98);
  if ((*(uint *)(param_1 + 0x18) < (uint)uStack_248) ||
     (((uint)uStack_248 == *(uint *)(param_1 + 0x18) &&
      ((uVar7 = (uint)(uStack_248 >> 0x20), *(uint *)(param_1 + 0x1c) < uVar7 ||
       ((uVar7 == *(uint *)(param_1 + 0x1c) && (*(ushort *)(param_1 + 0x20) < uStack_240)))))))) {
    uStack_298 = (ulonglong *)0x0;
    (*_DAT_)(1,0x11cbd10,0x11893b0,0x103e);
  }
  if ((((*(ushort *)(param_1 + 0x50) != 0) || (*(int *)(param_1 + 0x48) != 0)) ||
      (*(int *)(param_1 + 0x4c) != 0)) && (*(uint *)(param_1 + 0x48) <= (uint)uStack_248)) {
    if ((uint)uStack_248 == *(uint *)(param_1 + 0x48)) {
      if ((uStack_248._4_4_ < *(uint *)(param_1 + 0x4c)) ||
         ((uStack_248._4_4_ == *(uint *)(param_1 + 0x4c) &&
          (uStack_240 < *(ushort *)(param_1 + 0x50))))) goto LAB_;
    }
    uStack_298 = (ulonglong *)0x0;
    (*_DAT_)(1,0x11cbd28,0x11893b0,0x1042);
  }
LAB_:
  if (*(longlong *)(param_1 + 0xa8) == 0) {
    func_0x(param_1,*(undefined8 *)(param_1 + 0x88));
    *(undefined8 *)(param_1 + 0x88) = 0;
    uStack_290 = (undefined *)CONCAT71(uStack_290._1_7_,1);
    auStack_278[0] = 0x200;
    uStack_298 = (ulonglong *)auStack_278;
    func_0x
              (_DAT_,0,
               *(undefined2 *)(*(longlong *)(*(longlong *)(param_1 + 0x10) + 8) + 0x6b8),auStack_238
              );
    if (*(char *)(param_1 + 0x22) == '\x01') {
      uStack_260 = uStack_240;
      puStack_288 = auStack_238;
      uStack_268 = uStack_248;
      uStack_290 = (undefined *)CONCAT44(uStack_290._4_4_,auStack_278[0]);
      uStack_298 = &uStack_268;
      (*_DAT_)(0x5a,3,0x14,5);
    }
    else {
      uStack_290 = auStack_238;
      uStack_298 = (ulonglong *)CONCAT44(uStack_298._4_4_,auStack_278[0]);
      (*_DAT_)(0x5a,4,0x17,0xb);
    }
  }
  uVar3 = *(undefined4 *)(param_1 + 0xac);
  uVar4 = *(undefined4 *)(param_1 + 0xb0);
  uVar5 = *(undefined4 *)(param_1 + 0xb4);
  puVar2 = *(undefined8 **)(param_1 + 0x88);
  *(undefined4 *)(puVar2 + 2) = *(undefined4 *)(param_1 + 0xa8);
  *(undefined4 *)((longlong)puVar2 + 0x14) = uVar3;
  *(undefined4 *)(puVar2 + 3) = uVar4;
  *(undefined4 *)((longlong)puVar2 + 0x1c) = uVar5;
  uVar3 = *(undefined4 *)(param_1 + 0xb8);
  uVar4 = *(undefined4 *)(param_1 + 0xbc);
  uVar5 = *(undefined4 *)(param_1 + 0xc0);
  uVar6 = *(undefined4 *)(param_1 + 0xc4);
  *(undefined4 *)((longlong)puVar2 + 0x23c) = 0;
  *(undefined *)((longlong)puVar2 + 0x243) = 0;
  *(undefined4 *)(puVar2 + 4) = uVar3;
  *(undefined4 *)((longlong)puVar2 + 0x24) = uVar4;
  *(undefined4 *)(puVar2 + 5) = uVar5;
  *(undefined4 *)((longlong)puVar2 + 0x2c) = uVar6;
  *puVar2 = 0;
  puVar2[1] = 0;
  *(bool *)(puVar2 + 0x48) = *(int *)(param_1 + 200) != 0;
  iVar12 = *(int *)(param_1 + 0xd8);
  *(undefined *)((longlong)puVar2 + 0x244) = 0;
  *(undefined *)((longlong)puVar2 + 0x242) = 0;
  *(bool *)((longlong)puVar2 + 0x241) = iVar12 != 0;
  func_0x(param_1);
  if (((*(int *)(param_1 + 200) != 0) && (*(short *)(param_1 + 0x50) == 0)) &&
     ((*(int *)(param_1 + 0x48) == 0 && (*(int *)(param_1 + 0x4c) == 0)))) {
    lVar9 = *(longlong *)(param_1 + 0xb8);
    *(undefined8 *)(param_1 + 0x48) = *(undefined8 *)(lVar9 + 0xc);
    *(undefined2 *)(param_1 + 0x50) = *(undefined2 *)(lVar9 + 0x14);
    *(short *)(param_1 + 0x50) = *(short *)(lVar9 + 2) + 1;
  }
  if ((*(longlong *)(param_1 + 0x60) != 0) || (*(int *)(param_1 + 0x128) != 0)) {
    lVar9 = func_0x(param_1,&uStack_248);
    while (lVar9 != 0) {
      *(undefined *)(lVar9 + 0x243) = 1;
      if (*(longlong *)(param_1 + 0x60) == 0) {
        uStack_248 = CONCAT44(*(undefined4 *)(*(longlong *)(lVar9 + 0x10) + 0x10),(uint)uStack_248);
        puVar11 = *(undefined2 **)(lVar9 + 0x10);
        uStack_250 = *(uint *)(lVar9 + 0x18);
        uStack_24c = *(undefined4 *)(lVar9 + 0x1c);
        puStack_258 = puVar11;
      }
      else {
        if (*(char *)(lVar9 + 0x242) != '\0') {
          uStack_298 = (ulonglong *)0x0;
          (*_DAT_)(1,0x11cc0f8,0x11893e0,0x135);
        }
        lVar9 = *(longlong *)(lVar9 + 0x10);
        uStack_250 = uStack_250 & 0xffffff00;
        uStack_268 = *(ulonglong *)(lVar9 + 0xc);
        uStack_260 = *(ushort *)(lVar9 + 0x14);
        puVar11 = (undefined2 *)
                  ((ulonglong)(uStack_248._4_4_ * 0x200 - ((uint)(uStack_268 >> 0x17) & 0xfffffe00))
                  + lVar9);
        iVar12 = 0;
        puStack_258 = puVar11;
        if (puVar11[1] != 0) {
          do {
            uStack_240 = (short)iVar12 + 1;
            uVar1 = *puVar11;
            uVar8 = func_0x(&puStack_258);
            uStack_298 = (ulonglong *)(*(longlong *)(param_1 + 0x1aa8) + 0x1d48);
            if (*(longlong *)(param_1 + 0x1aa8) == 0) {
              uStack_298 = (ulonglong *)(param_1 + 0x1ab8);
            }
            uVar8 = func_0x(&uStack_248,uVar8,uVar1,*(undefined8 *)(param_1 + 0x10))
            ;
            (**(code **)(**(longlong **)(param_1 + 0x60) + 8))
                      (*(longlong **)(param_1 + 0x60),uVar8,&uStack_248);
            iVar12 = iVar12 + 1;
          } while (iVar12 < (int)(uint)(ushort)puVar11[1]);
        }
      }
      if (puVar11[5] == 0) {
LAB_:
        uStack_268 = 0;
        *(undefined8 *)(param_1 + 0x11c) = 0;
        *(undefined2 *)(param_1 + 0x124) = 0;
        goto LAB_;
      }
      lVar9 = func_0x(param_1,&uStack_248,&puStack_258);
      if (lVar9 == 0) {
        if (uStack_248._4_4_ == 0x10) goto LAB_;
        uStack_290 = (undefined *)CONCAT71(uStack_290._1_7_,1);
        auStack_278[0] = 0x200;
        uStack_298 = (ulonglong *)auStack_278;
        func_0x
                  (_DAT_,0,
                   *(undefined2 *)(*(longlong *)(*(longlong *)(param_1 + 0x10) + 8) + 0x6b8),
                   auStack_238);
        uStack_290 = auStack_238;
        uStack_298 = (ulonglong *)CONCAT44(uStack_298._4_4_,auStack_278[0]);
        (*_DAT_)(0x5a,4,0x17,0xc);
      }
      lVar9 = func_0x(param_1,&uStack_248);
    }
    if (*(int *)(param_1 + 0x128) != 0) {
      *(ulonglong *)(param_1 + 0x11c) = uStack_248;
      *(ushort *)(param_1 + 0x124) = uStack_240;
    }
  }
LAB_:
  func_0x(uStack_38 ^ (ulonglong)auStack_2b8);
  return;
}

