
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined4 *param_1,longlong param_2,longlong *param_3,longlong param_4)

{
  longlong **pplVar1;
  ushort uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  longlong *plVar6;
  int *piVar7;
  longlong lVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  undefined auStack_348 [32];
  uint *puStack_328;
  uint uStack_318;
  undefined4 uStack_314;
  uint uStack_310;
  uint auStack_308 [2];
  undefined8 uStack_300;
  undefined8 uStack_2f8;
  undefined4 uStack_2f0;
  longlong lStack_2e8;
  longlong *plStack_2e0;
  longlong lStack_2d8;
  undefined auStack_2c8 [11];
  byte bStack_2bd;
  undefined4 auStack_268 [68];
  undefined auStack_158 [272];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_348;
  uVar9 = 0;
  uStack_318 = 0;
  uStack_314 = 0;
  lStack_2e8 = param_4;
  plStack_2e0 = param_3;
  lStack_2d8 = param_2;
  func_0x(auStack_268,0,0x104);
  func_0x(auStack_158,0,0x104);
  auStack_308[0] = 0;
  uVar10 = uVar9;
  uVar11 = uVar9;
  while( true ) {
    if (param_1[4] != -1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((auStack_308[0] & 0x10000) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    auStack_308[0] = 3;
    uStack_300 = 0;
    uStack_2f8 = 0;
    uStack_2f0 = 0;
    if (lStack_2e8 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uStack_310 = (uint)uVar10;
    iVar3 = (**(code **)(*param_3 + 0x28))(param_3,(int)uVar11 + 1,0xfffe);
    if (iVar3 == -1) {
      puStack_328 = (uint *)((ulonglong)puStack_328 & 0xffffffff00000000);
      func_0x(param_1,uVar11,uStack_318,uStack_314);
      func_0x(param_1);
      if ((uint)uVar10 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (param_1[7] != 0) {
        pplVar1 = (longlong **)(param_1 + 0xc);
        do {
          lVar8 = func_0x(*(undefined8 *)(param_1 + 2),auStack_268[uVar9]);
          plVar6 = (longlong *)(lVar8 + 0x160);
          uVar4 = (int)uVar9 + 1;
          uVar9 = (ulonglong)uVar4;
          *plVar6 = (longlong)*pplVar1;
          (*pplVar1)[1] = (longlong)plVar6;
          *pplVar1 = plVar6;
          *(longlong ***)(lVar8 + 0x168) = pplVar1;
        } while (uVar4 < (uint)param_1[7]);
      }
      if (param_1[8] == 0) {
        if (*(int *)(lStack_2d8 + 0x674) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        uVar2 = _DAT_;
        if (*(char *)(*(longlong *)(lStack_2d8 + 0x6b0) + 0x939) != '\0') {
          uVar2 = 0x388;
        }
        if (uVar2 <= *(ushort *)(lStack_2d8 + 0x67e)) {
          uVar2 = 1;
          if ((DAT_ & 2) == 0) {
            uVar2 = 0x3bd;
          }
          if (*(ushort *)(lStack_2d8 + 0x67e) <= uVar2) {
            *param_1 = 3;
            func_0x(uStack_48 ^ (ulonglong)auStack_348);
            return;
          }
        }
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    plVar6 = (longlong *)(**(code **)(*param_3 + 0x18))(param_3,iVar3);
    uVar4 = (**(code **)(*plVar6 + 0x10))(plVar6);
    (**(code **)(*plVar6 + 0x20))(plVar6,auStack_2c8);
    if ((bStack_2bd & 0x80) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    piVar7 = (int *)func_0x(*(undefined8 *)(param_1 + 2),uVar11);
    puStack_328 = auStack_308;
    func_0x(piVar7,iVar3,uVar4,auStack_2c8);
    if ((*(byte *)((longlong)piVar7 + 0x21) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(byte *)((longlong)piVar7 + 0x21) & 8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(short *)(piVar7 + 10) != 0) break;
    if (piVar7[0xb] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (piVar7[0xc] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(char *)((longlong)piVar7 + 0x21) < '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*piVar7 < 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(byte *)(piVar7 + 8) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((uVar4 <= uStack_318) || (0x4000000 < uVar4)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar11 = (ulonglong)((int)uVar11 + 1);
    uVar5 = uStack_310 + 1;
    if ((*(byte *)((longlong)piVar7 + 6) & 0x10) == 0) {
      uVar5 = uStack_310;
    }
    uVar10 = (ulonglong)uVar5;
    param_3 = plStack_2e0;
    uStack_318 = uVar4;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

