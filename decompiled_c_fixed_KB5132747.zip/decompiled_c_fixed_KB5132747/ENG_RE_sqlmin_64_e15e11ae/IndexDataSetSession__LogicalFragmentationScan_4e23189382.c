
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2)

{
  byte *pbVar1;
  byte bVar2;
  longlong *plVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  char cVar7;
  int iVar8;
  uint uVar9;
  byte **ppbVar10;
  undefined8 uVar11;
  int *piVar12;
  ushort uVar13;
  longlong lVar14;
  short sVar15;
  byte *pbVar16;
  longlong lVar17;
  uint *puVar18;
  ushort *puVar19;
  uint uVar20;
  uint uVar21;
  ulonglong uVar22;
  int iVar23;
  longlong unaff_GS_OFFSET;
  undefined auStack_6f8 [32];
  uint *puStack_6d8;
  undefined8 uStack_6d0;
  int *piStack_6c8;
  uint uStack_6c0;
  int iStack_6b8;
  int iStack_6b4;
  int iStack_6a8;
  byte bStack_6a0;
  ushort uStack_698;
  undefined2 uStack_690;
  uint uStack_688;
  uint uStack_680;
  byte bStack_678;
  longlong *plStack_668;
  int iStack_660;
  undefined2 uStack_65c;
  uint uStack_658;
  uint uStack_654;
  undefined4 uStack_650;
  undefined4 uStack_64c;
  undefined2 uStack_648;
  longlong lStack_640;
  ushort uStack_638;
  ushort uStack_634;
  ushort uStack_630;
  short sStack_62c;
  ushort uStack_628;
  ushort uStack_624;
  ushort uStack_610;
  ushort uStack_608;
  ushort uStack_600;
  undefined4 uStack_5fc;
  uint uStack_5f8;
  uint uStack_5f4;
  int iStack_5f0;
  int iStack_5ec;
  uint auStack_5e8 [2];
  uint uStack_5e0;
  uint uStack_5d8;
  uint uStack_5d0;
  uint uStack_5c8;
  uint uStack_5c0;
  ushort uStack_5b8;
  ushort uStack_5b4;
  ushort uStack_5b2;
  undefined4 uStack_5b0;
  undefined2 uStack_5ac;
  undefined4 uStack_5a8;
  short sStack_5a4;
  ushort uStack_5a0;
  undefined4 uStack_598;
  undefined2 uStack_594;
  undefined4 uStack_590;
  undefined2 uStack_58c;
  ushort uStack_588;
  int *piStack_580;
  longlong **pplStack_578;
  undefined4 uStack_558;
  undefined4 uStack_554;
  undefined2 uStack_550;
  undefined4 uStack_548;
  undefined4 uStack_544;
  undefined2 uStack_540;
  uint *puStack_538;
  undefined8 uStack_530;
  int *piStack_528;
  int *piStack_520;
  int *piStack_518;
  longlong lStack_510;
  longlong **pplStack_508;
  longlong lStack_500;
  int *piStack_4f0;
  byte **ppbStack_4e8;
  uint uStack_4d8;
  uint uStack_4d4;
  int iStack_4cc;
  undefined auStack_4c8 [4];
  uint uStack_4c4;
  int iStack_4c0;
  uint uStack_4bc;
  uint uStack_4b8;
  int iStack_4b0;
  uint uStack_4a8;
  uint uStack_4a4;
  uint uStack_4a0;
  uint uStack_498;
  uint uStack_490;
  uint uStack_48c;
  undefined auStack_488 [4];
  int iStack_484;
  uint uStack_480;
  uint uStack_478;
  uint uStack_470;
  undefined auStack_46c [4];
  int iStack_468;
  uint uStack_460;
  undefined4 uStack_458;
  longlong lStack_450;
  int *piStack_448;
  undefined auStack_440 [8];
  byte *pbStack_438;
  undefined auStack_430 [8];
  undefined4 uStack_428;
  longlong lStack_420;
  longlong lStack_418;
  longlong lStack_410;
  longlong lStack_408;
  undefined4 *puStack_400;
  undefined4 *puStack_3f8;
  longlong **pplStack_3f0;
  longlong lStack_3e8;
  longlong **pplStack_3e0;
  int *piStack_3d8;
  longlong lStack_3d0;
  longlong lStack_3c8;
  byte *pbStack_3c0;
  undefined8 uStack_3b8;
  undefined *puStack_3b0;
  longlong lStack_3a8;
  undefined8 uStack_3a0;
  byte *pbStack_398;
  byte **ppbStack_390;
  longlong lStack_388;
  longlong lStack_380;
  byte **ppbStack_378;
  byte **ppbStack_370;
  byte *pbStack_368;
  ushort *puStack_360;
  byte *pbStack_358;
  ushort *puStack_350;
  byte *pbStack_348;
  ushort *puStack_340;
  byte *pbStack_338;
  byte *pbStack_330;
  byte *pbStack_328;
  byte *pbStack_320;
  int *piStack_318;
  ushort *puStack_310;
  int *piStack_308;
  ushort *puStack_300;
  int *piStack_2f8;
  ushort *puStack_2f0;
  int *piStack_2e8;
  int *piStack_2e0;
  int *piStack_2d8;
  ushort *puStack_2d0;
  int *piStack_2c8;
  int *piStack_2c0;
  int *piStack_2b8;
  int *piStack_2b0;
  int *piStack_2a8;
  ushort *puStack_2a0;
  longlong lStack_298;
  longlong lStack_290;
  longlong lStack_288;
  longlong lStack_280;
  ushort *puStack_278;
  byte *pbStack_270;
  ushort *puStack_268;
  ushort *puStack_260;
  byte *pbStack_258;
  ushort *puStack_250;
  byte *pbStack_248;
  ushort *puStack_240;
  ushort *puStack_238;
  ushort *puStack_230;
  ushort *puStack_228;
  ushort *puStack_220;
  byte *pbStack_218;
  ushort *puStack_210;
  int *piStack_208;
  undefined8 uStack_200;
  longlong lStack_1f8;
  longlong lStack_1f0;
  int *piStack_1e8;
  byte **ppbStack_1e0;
  byte **ppbStack_1d8;
  int *piStack_1d0;
  byte **ppbStack_1c8;
  ushort *puStack_1c0;
  undefined2 *puStack_1b8;
  uint *puStack_1b0;
  longlong lStack_1a8;
  uint *puStack_1a0;
  uint *puStack_198;
  undefined8 *puStack_190;
  undefined8 uStack_188;
  undefined4 *puStack_180;
  longlong lStack_178;
  longlong lStack_140;
  undefined8 uStack_138;
  byte **ppbStack_130;
  ushort uStack_100;
  ushort uStack_fe;
  uint uStack_fc;
  int *piStack_f8;
  undefined8 uStack_f0;
  uint uStack_e8;
  ushort uStack_e4;
  byte *pbStack_e2;
  undefined2 uStack_da;
  undefined2 uStack_d8;
  ushort uStack_d6;
  ushort uStack_d4;
  undefined2 uStack_d2;
  undefined4 uStack_d0;
  int iStack_cc;
  undefined auStack_c8 [16];
  undefined auStack_b8 [16];
  undefined auStack_a8 [16];
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  undefined8 uStack_58;
  undefined auStack_50 [16];
  uint auStack_40 [2];
  ulonglong uStack_38;
  
  uStack_138 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_6f8;
  uStack_5b0 = 0;
  uStack_5ac = 0;
  uVar9 = *(uint *)(**(longlong **)(*(longlong *)(*(longlong *)(param_1 + 0x10) + 8) + 0x160) + 0x1c
                   );
  lStack_640 = 0;
  lStack_418 = *(longlong *)(param_1 + 0x328);
  uStack_530 = param_2;
  lStack_510 = param_1;
  lStack_420 = param_1;
  if ((lStack_418 == 0) || (*(uint *)(lStack_418 + 0xc) < uVar9)) {
    lStack_140 = lStack_418;
    (*_DAT_)(lStack_418,0x18);
    *(undefined8 *)(param_1 + 0x328) = 0;
    func_0x
              (*(undefined8 *)(*(longlong *)(param_1 + 0x2e0) + 8),uVar9,param_1 + 0x328);
    lStack_418 = *(longlong *)(param_1 + 0x328);
  }
  *(undefined4 *)(lStack_418 + 0x10) = 1;
  *(undefined4 *)(lStack_418 + 0x14) = 0;
  func_0x(*(undefined8 *)(*(longlong *)(param_1 + 0x2e0) + 8),uVar9,&lStack_640);
  lStack_410 = lStack_640;
  *(undefined4 *)(lStack_640 + 0x10) = 2;
  *(undefined4 *)(lStack_640 + 0x14) = 0;
  func_0x(param_1,*(undefined8 *)(param_1 + 0x328),lStack_640);
  func_0x(*(undefined8 *)(param_1 + 0x2f8),*(undefined8 *)(param_1 + 0x388));
  lStack_408 = *(longlong *)(param_1 + 0x2f8);
  *(undefined4 *)(lStack_408 + 0xf4) = 0;
  puStack_400 = (undefined4 *)(lStack_408 + 0x118);
  uStack_598 = 0;
  uStack_594 = 0;
  *puStack_400 = 0;
  *(undefined2 *)(lStack_408 + 0x11c) = 0;
  uStack_558 = 0;
  uStack_554 = 0;
  uStack_550 = 0;
  *(undefined8 *)(lStack_408 + 0x124) = 0;
  *(undefined2 *)(lStack_408 + 300) = 0;
  *(undefined4 *)(lStack_408 + 0x120) = 0;
  *(undefined4 *)(lStack_408 + 0x130) = 0;
  *(undefined4 *)(lStack_408 + 0xd0) = 0;
  uStack_6d0 = &pplStack_508;
  puStack_6d8 = (uint *)0x0;
  puStack_3f8 = puStack_400;
  func_0x(*(undefined8 *)(param_1 + 0x2f8),*(undefined8 *)(param_1 + 0x328),0,0);
  while (lVar14 = *(longlong *)(param_1 + 0x2f8), pplStack_508 != (longlong **)0x0) {
    pplStack_3f0 = pplStack_508;
    pplStack_3e0 = pplStack_508;
    lStack_3e8 = lVar14;
    if (*(int *)(pplStack_508 + 5) == 0) {
      lVar17 = *(longlong *)(**(longlong **)(lVar14 + 8) + 8);
      lStack_3d0 = lVar17 + 0x200;
      lVar14 = **pplStack_508;
      puStack_538 = (uint *)(lVar17 + 0x210);
      iStack_4b0 = *(int *)(pplStack_508 + 3);
      lStack_450 = (longlong)iStack_4b0;
      uStack_600 = *(ushort *)(lVar14 + (0xfff - lStack_450) * 2);
      pbStack_3c0 = (byte *)((ulonglong)uStack_600 + lVar14);
      uStack_5b8 = (ushort)(*pbStack_3c0 & 1);
      lStack_3c8 = lVar14;
      if ((*pbStack_3c0 & 1) == 0) {
        uStack_4b8 = *puStack_538;
        piVar12 = (int *)(pbStack_3c0 + (int)uStack_4b8);
        iVar8 = iStack_6b8;
        piVar4 = piStack_580;
        piVar5 = piStack_520;
        piVar6 = piStack_448;
      }
      else {
        uStack_100 = 0xffff;
        ppbVar10 = (byte **)0x0;
        piStack_f8 = (int *)0x0;
        uStack_fc = 0;
        pbStack_e2 = (byte *)0x0;
        uStack_d8 = 0;
        uStack_d6 = 0;
        uStack_d4 = 0;
        uStack_d2 = 0;
        uStack_f0 = (byte **)0x0;
        iStack_cc = iStack_4b0;
        if (*(char *)(lVar14 + 2) < '\0') {
          pbVar16 = (byte *)(lVar14 + 0x60);
          uStack_3b8 = 0;
          ppbStack_4e8 = (byte **)0x0;
          puStack_3b0 = auStack_c8;
          auStack_c8 = ZEXT816(0);
          auStack_b8 = ZEXT816(0);
          auStack_a8 = ZEXT816(0);
          auStack_98 = ZEXT816(0);
          auStack_88 = ZEXT816(0);
          auStack_78 = ZEXT816(0);
          auStack_68 = ZEXT816(0);
          uStack_58 = 0;
          ppbVar10 = (byte **)func_0x(auStack_c8);
          ppbStack_4e8 = ppbVar10;
          lStack_3a8 = lVar14 + 0x20;
          uVar11 = func_0x(lVar14,auStack_50,0,0);
          uStack_3a0 = uVar11;
          pbStack_398 = pbVar16;
          ppbStack_390 = ppbVar10;
          if ((pbVar16 == *ppbVar10) &&
             (iVar8 = func_0x(uVar11,ppbVar10 + 0xc), iVar8 != 0)) {
            lStack_388 = (longlong)ppbVar10 + 0x6c;
          }
          *ppbVar10 = pbVar16;
          func_0x(ppbVar10 + 0xc,uVar11);
          func_0x((longlong)ppbVar10 + 0x6c,lVar14 + 0x20);
          uVar22 = (ulonglong)*pbVar16;
          uStack_608 = (ushort)*pbVar16;
          uStack_64c = *(undefined4 *)(uVar22 * 6 + 0x1600f90);
          uStack_648 = *(undefined2 *)(uVar22 * 6 + 0x1600f94);
          uStack_5a8 = *(undefined4 *)(uVar22 * 6 + 0x1600f90);
          sStack_5a4 = *(short *)(uVar22 * 6 + 0x1600f94);
          uVar22 = (ulonglong)sStack_5a4;
          lStack_380 = lVar14 + 99;
          ppbStack_378 = ppbVar10 + 2;
          *(undefined2 *)ppbStack_378 = 0xffff;
          ppbVar10[3] = (byte *)0x0;
          uVar9 = 0;
          *(undefined4 *)((longlong)ppbVar10 + 0x14) = 0;
          *(undefined8 *)((longlong)ppbVar10 + 0x2e) = 0;
          ppbVar10[7] = (byte *)0x0;
          ppbVar10[4] = (byte *)0x0;
          ppbStack_370 = ppbVar10 + 9;
          *ppbStack_370 = (byte *)0x0;
          ppbVar10[10] = (byte *)0x0;
          *(undefined2 *)(ppbVar10 + 0xb) = 0;
          if ((**ppbVar10 & 2) != 0) {
            pbVar1 = pbVar16 + uVar22;
            bVar2 = *pbVar1;
            uStack_5b4 = (ushort)(bVar2 & 1);
            *(ushort *)ppbStack_378 = uStack_5b4;
            puVar19 = (ushort *)((longlong)ppbVar10 + 0x12);
            pbStack_368 = pbVar1;
            ppbStack_130 = ppbStack_378;
            if ((bVar2 & 1) == 0) {
              uStack_688 = 0;
              ppbVar10[3] = pbVar1;
              *(undefined4 *)((longlong)ppbVar10 + 0x14) = 0;
              *(undefined4 *)((longlong)ppbVar10 + 0x36) = 0;
              pbStack_358 = ppbVar10[3];
              puStack_360 = puVar19;
              switch(*pbStack_358 & 0xe) {
              default:
                uVar13 = *(ushort *)(pbVar1 + 2);
                uVar9 = (uint)uVar13;
                uVar20 = (uint)uVar13;
                uStack_688 = uVar20;
                if (uVar13 - 1 < 0x1f9e) goto code_r0x001005f6;
                func_0x(pbStack_358,6);
                *(uint *)(ppbVar10 + 4) = uVar20;
                *(undefined8 *)((longlong)ppbVar10 + 0x2e) = 0;
                break;
              case 4:
                uStack_688 = 9;
                *(undefined4 *)(ppbVar10 + 4) = 9;
                *(undefined8 *)((longlong)ppbVar10 + 0x2e) = 0;
                break;
              case 6:
              case 10:
code_r0x001005f6:
                *(uint *)(ppbVar10 + 4) = uVar9;
                *(undefined8 *)((longlong)ppbVar10 + 0x2e) = 0;
                break;
              case 0xe:
                uStack_688 = 1;
                *(undefined4 *)(ppbVar10 + 4) = 1;
                *(undefined8 *)((longlong)ppbVar10 + 0x2e) = 0;
              }
            }
            else {
              ppbVar10[3] = pbVar1;
              bVar2 = *pbVar1;
              puStack_350 = puVar19;
              pbStack_348 = pbVar1;
              switch(bVar2 & 0x1c) {
              default:
                puStack_340 = (ushort *)(pbVar1 + 1);
                if ((char)*(byte *)puStack_340 < '\0') {
                  uVar13 = *puStack_340;
                  *puVar19 = uVar13;
                  *puVar19 = (uVar13 & 0x7f) << 8 | uVar13 >> 8;
                  *(undefined2 *)(ppbVar10 + 5) = 3;
                  sVar15 = 3;
                }
                else {
                  *puVar19 = (ushort)*(byte *)puStack_340;
                  sVar15 = 2;
                  *(undefined2 *)(ppbVar10 + 5) = 2;
                }
                *(short *)((longlong)ppbVar10 + 0x2c) = (short)(*puVar19 + 1 >> 1) + sVar15;
                if (*puVar19 < 0x1f) {
                  *(undefined2 *)((longlong)ppbVar10 + 0x2a) = 0;
                  *(undefined4 *)((longlong)ppbVar10 + 0x14) = 0;
                  *(undefined4 *)(ppbVar10 + 8) = 0;
                }
                else {
                  iVar8 = *puVar19 - 1;
                  *(short *)((longlong)ppbVar10 + 0x2a) =
                       ((short)(iVar8 / 0x1e) + (short)(iVar8 >> 0x1f)) -
                       (short)((longlong)iVar8 * 0x88888889 >> 0x3f);
                  *(undefined4 *)((longlong)ppbVar10 + 0x14) = 0;
                  *(undefined4 *)(ppbVar10 + 8) = 0;
                }
                break;
              case 4:
                pbStack_330 = pbVar1;
                pbStack_328 = pbVar1;
                if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
                  func_0x(puVar19);
                  ppbVar10[3] = pbVar1;
                  *(undefined4 *)((longlong)ppbVar10 + 0x14) = 0xf;
                  *(undefined4 *)(ppbVar10 + 8) = 0;
                  *(undefined4 *)(ppbVar10 + 8) = 1;
                }
                else {
                  func_0x(puVar19);
                  ppbVar10[3] = pbVar1;
                  *(undefined4 *)((longlong)ppbVar10 + 0x14) = 1;
                  *(undefined4 *)(ppbVar10 + 8) = 0;
                }
                break;
              case 8:
                pbStack_338 = pbVar1;
                func_0x(puVar19);
                ppbVar10[3] = pbVar1;
                *(undefined4 *)((longlong)ppbVar10 + 0x14) = 9;
                *(undefined4 *)(ppbVar10 + 8) = 0;
              }
              ppbVar10[7] = (byte *)0x0;
              ppbVar10[4] = (byte *)0x0;
            }
          }
          if ((**ppbVar10 & 4) != 0) {
            if (uStack_5a8._2_2_ != 0) {
              uVar22 = (ulonglong)*(ushort *)(lVar14 + 0x61 + (longlong)uStack_5a8._2_2_ * 2);
            }
            pbStack_320 = pbVar16 + uVar22;
            func_0x(ppbVar10 + 9);
          }
          param_2 = uStack_530;
          if (ppbVar10[1] != (byte *)0x0) {
            func_0x(ppbVar10[1],ppbVar10);
            param_2 = uStack_530;
          }
        }
        else {
          ppbStack_4e8 = (byte **)0x0;
        }
        puVar18 = puStack_538;
        uVar9 = (uint)*(ushort *)(lVar14 + 0xe);
        uStack_4bc = (uint)*(ushort *)(lVar14 + 0xe);
        uStack_5b2 = *(ushort *)(lVar14 + (0xfff - lStack_450) * 2);
        piVar12 = (int *)((ulonglong)uStack_5b2 + lVar14);
        uStack_5a0 = (ushort)(*(byte *)piVar12 & 1);
        piStack_318 = piVar12;
        uStack_100 = uStack_5a0;
        piStack_f8 = piVar12;
        if ((*(byte *)piVar12 & 1) == 0) {
          uStack_fc = 0;
          uStack_da = 0;
          uStack_d8 = 0;
          uStack_680 = uStack_4bc;
          puStack_310 = &uStack_fe;
          piStack_308 = piVar12;
          switch(*(byte *)piVar12 & 0xe) {
          default:
            uVar13 = *(ushort *)((longlong)piVar12 + 2);
            uVar9 = (uint)uVar13;
            uStack_680 = (uint)uVar13;
            if (0x1f9d < uVar13 - 1) {
              func_0x(piVar12,6);
            }
            break;
          case 4:
            uVar9 = 9;
            uStack_680 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar9 = 1;
            uStack_680 = 1;
          }
          uStack_f0 = (byte **)CONCAT44(uStack_f0._4_4_,uVar9);
          pbStack_e2 = (byte *)(lVar14 + 0x2000);
        }
        else {
          bVar2 = *(byte *)piVar12;
          puStack_300 = &uStack_fe;
          piStack_2f8 = piVar12;
          switch(bVar2 & 0x1c) {
          default:
            puStack_2f0 = (ushort *)((longlong)piVar12 + 1);
            if ((char)*(byte *)puStack_2f0 < '\0') {
              uStack_fe = *puStack_2f0 >> 8 | (*puStack_2f0 & 0x7f) << 8;
              uStack_e8 = 3;
              sVar15 = 3;
            }
            else {
              uStack_fe = (ushort)*(byte *)puStack_2f0;
              uStack_e8 = 2;
              sVar15 = 2;
            }
            uStack_e4 = (short)(uStack_fe + 1 >> 1) + sVar15;
            if (uStack_fe < 0x1f) {
              uStack_fc = 0;
              uStack_d0 = 0;
            }
            else {
              iVar8 = uStack_fe - 1;
              uStack_e8 = CONCAT22(((short)(iVar8 / 0x1e) + (short)(iVar8 >> 0x1f)) -
                                   (short)((longlong)iVar8 * 0x88888889 >> 0x3f),
                                   (undefined2)uStack_e8);
              uStack_fc = 0;
              uStack_d0 = 0;
            }
            break;
          case 4:
            piStack_2e0 = piVar12;
            piStack_2d8 = piVar12;
            if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
              func_0x(&uStack_fe);
              uStack_fc = 0xf;
              uStack_d0 = 1;
            }
            else {
              func_0x(&uStack_fe);
              uStack_fc = 1;
              uStack_d0 = 0;
            }
            break;
          case 8:
            piStack_2e8 = piVar12;
            func_0x(&uStack_fe);
            uStack_fc = 9;
            uStack_d0 = 0;
          }
          lVar14 = lVar14 + 0x2000;
          uStack_d8 = (undefined2)lVar14;
          uStack_d6 = (ushort)((ulonglong)lVar14 >> 0x10);
          uStack_d4 = (ushort)((ulonglong)lVar14 >> 0x20);
          uStack_d2 = (undefined2)((ulonglong)lVar14 >> 0x30);
          uVar9 = (uint)ppbVar10;
          piStack_f8 = piVar12;
          uStack_f0 = ppbVar10;
        }
        if (uStack_100 == 0) {
          puStack_2d0 = &uStack_fe;
          if ((*puVar18 & 0xc0000000) == 0x80000000) {
            iVar8 = func_0x(&uStack_fe);
            if (iVar8 == 0) {
              iStack_6b8 = 0;
              piStack_520 = (int *)0x0;
              piVar12 = (int *)0x0;
              param_1 = lStack_510;
              iVar8 = iStack_6b8;
              piVar4 = piStack_580;
              piVar5 = piStack_520;
              piVar6 = piStack_448;
            }
            else {
              piVar12 = (int *)func_0x(&uStack_d6,puVar18,&iStack_6b8,auStack_46c);
              param_1 = lStack_510;
              iVar8 = iStack_6b8;
              piVar4 = piStack_580;
              piVar5 = piVar12;
              piVar6 = piStack_448;
            }
          }
          else {
            if ((*(byte *)((longlong)puVar18 + 6) & 0x10) == 0) {
              uStack_5fc = 0;
              uStack_654 = 1;
            }
            else {
              puStack_6d8 = &uStack_654;
              func_0x(&uStack_fe,puVar18,0,&uStack_5fc);
              if ((uStack_654 == 0) && ((*(byte *)((longlong)puVar18 + 6) & 0x10) != 0)) {
                piStack_2c8 = *(int **)(puVar18 + 2) + 1;
                iStack_4c0 = **(int **)(puVar18 + 2);
                piVar12 = piStack_2c8;
                param_1 = lStack_510;
                iVar8 = iStack_4c0;
                piVar4 = piStack_2c8;
                piVar5 = piStack_2c8;
                piVar6 = piStack_448;
                goto LAB_;
              }
              uVar9 = (uint)uStack_f0;
            }
            iVar23 = 0;
            iVar8 = 0;
            uStack_4c4 = *puVar18;
            if ((int)uStack_4c4 < 0) {
              piVar12 = piStack_f8;
              if (uStack_fc == 0) {
                iStack_6b4 = 0;
                uStack_fe = 0;
                if ((*(byte *)piStack_f8 & 0x10) != 0) {
                  uVar9 = uVar9 + 2 +
                          (*(ushort *)((longlong)piStack_f8 + (ulonglong)uVar9) + 7 >> 3);
                  piStack_2b0 = piStack_f8;
                }
                uStack_f0 = (byte **)CONCAT44(uVar9,(uint)uStack_f0);
                piStack_2b8 = piStack_f8;
                piStack_2a8 = piStack_f8;
                if ((*(byte *)piStack_f8 & 0x20) == 0) {
                  uStack_e4 = 0;
                  uStack_fc = uVar9;
                  uStack_e8 = uVar9;
                }
                else {
                  puVar19 = (ushort *)((ulonglong)uVar9 + (longlong)piStack_f8);
                  uStack_e4 = *puVar19;
                  puStack_2a0 = puVar19;
                  if (uStack_e4 == 0) {
                    iVar23 = 1;
                    iStack_6b4 = 1;
                    cVar7 = func_0x(0x1f17740);
                    if (((cVar7 != '\0') &&
                        (lStack_298 = func_0x(), lStack_298 != 0)) &&
                       (*(char *)(lStack_298 + 0x499) != '\0')) {
                      cVar7 = func_0x(0x1f17740);
                      if (cVar7 == '\0') {
                        (*pcRam00000000014852c8)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        puStack_6d8 = (uint *)0x0;
                        (*pcRam00000000014852c0)(1,0x180714c,0x1927238,0x80f);
                      }
                    }
                    func_0x(piStack_f8,3);
                  }
                  uStack_e8 = uStack_f0._4_4_ + (uStack_e4 + 1) * 2;
                  if (0x1f9e < uStack_e8) {
                    iVar23 = iVar23 + 1;
                    iStack_6b4 = iVar23;
                    cVar7 = func_0x(0x1f17740);
                    if (((cVar7 != '\0') &&
                        (lStack_290 = func_0x(), lStack_290 != 0)) &&
                       (*(char *)(lStack_290 + 0x499) != '\0')) {
                      cVar7 = func_0x(0x1f17740);
                      if (cVar7 == '\0') {
                        (*pcRam00000000014852c8)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        puStack_6d8 = (uint *)0x0;
                        (*pcRam00000000014852c0)(1,0x180714c,0x1927238,0x816);
                      }
                    }
                    func_0x(piStack_f8,4);
                  }
                  uStack_588 = puVar19[uStack_e4];
                  uStack_fc = uStack_588 & 0x7fff;
                  if (uStack_fc < uStack_e8) {
                    iVar23 = iVar23 + 1;
                    iStack_6b4 = iVar23;
                    cVar7 = func_0x(0x1f17740);
                    if (((cVar7 != '\0') &&
                        (lStack_288 = func_0x(), lStack_288 != 0)) &&
                       (*(char *)(lStack_288 + 0x499) != '\0')) {
                      cVar7 = func_0x(0x1f17740);
                      if (cVar7 == '\0') {
                        (*pcRam00000000014852c8)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        puStack_6d8 = (uint *)0x0;
                        (*pcRam00000000014852c0)(1,0x180714c,0x1927238,0x81d);
                      }
                    }
                    func_0x(piStack_f8,4);
                  }
                  iStack_5f0 = 0;
                  piVar12 = piStack_f8;
                  uStack_5f4 = uStack_e8;
                  iVar8 = iVar23;
                  while (iVar23 = iStack_5f0, iStack_5f0 < (int)(uint)uStack_e4) {
                    uStack_610 = puVar19[(longlong)iStack_5f0 + 1];
                    uVar9 = uStack_610 & 0x7fff;
                    uStack_4d8 = uVar9;
                    if ((uVar9 < uStack_5f4) || (uStack_fc < uVar9)) {
                      iVar8 = iVar8 + 1;
                      iStack_6b4 = iVar8;
                      cVar7 = func_0x(0x1f17740);
                      if ((cVar7 != '\0') &&
                         ((lStack_280 = func_0x(), lStack_280 != 0 &&
                          (*(char *)(lStack_280 + 0x499) != '\0')))) {
                        cVar7 = func_0x(0x1f17740);
                        if (cVar7 == '\0') {
                          (*pcRam00000000014852c8)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          puStack_6d8 = (uint *)0x0;
                          (*pcRam00000000014852c0)(1,0x180714c,0x1927238,0x82a);
                        }
                      }
                      func_0x(piStack_f8,4);
                      piVar12 = piStack_f8;
                    }
                    uStack_5f4 = uVar9;
                    iStack_5f0 = iVar23 + 1;
                  }
                  do {
                    puStack_278 = puVar19 + (ulonglong)(uStack_e4 - 1) + 1;
                    if (-1 < (short)*puStack_278) break;
                    uStack_478 = (uint)uStack_e4;
                    pbStack_270 = (byte *)(((ulonglong)uStack_f0 >> 0x20) + (longlong)piVar12);
                    uVar9 = uStack_e8;
                    if (uStack_478 != 1) {
                      uStack_638 = *(ushort *)(pbStack_270 + (longlong)(int)(uStack_e4 - 2) * 2 + 2)
                      ;
                      uVar9 = uStack_638 & 0x7fff;
                    }
                    uStack_634 = *(ushort *)(pbStack_270 + (longlong)(int)(uStack_e4 - 1) * 2 + 2);
                    uVar20 = uStack_634 & 0x7fff;
                    uStack_4a8 = uVar20;
                    if (((uVar9 < uStack_e8) || (uVar20 < uVar9)) || (uStack_fc < uVar20)) {
                      func_0x(piVar12,7);
                      piVar12 = piStack_f8;
                    }
                    uVar20 = uVar20 - uVar9;
                    uStack_4a4 = uVar20;
                    uStack_4a0 = uVar9;
                    if ((uVar9 < uStack_e8) || (uStack_fc < uVar9)) {
                      iStack_6b4 = iVar8 + 1;
                      goto code_r0x00101690;
                    }
                    uStack_630 = *(ushort *)((longlong)piVar12 + (ulonglong)uVar9);
                    if (uStack_630 == 5) {
                      uStack_fe = uStack_fe | 2;
                      uStack_e4 = uStack_e4 - 1;
                      puStack_268 = &uStack_d6;
                      uVar22 = (ulonglong)(uVar9 & 0xffff);
                      uStack_d6 = (ushort)uVar9;
                      puStack_260 = &uStack_fe;
                      pbStack_258 = (byte *)(uVar22 + (longlong)piVar12);
                      if ((*(ushort *)(pbStack_258 + 2) >> 0xe & 1) == 0) {
                        uVar13 = uStack_d4 & 0xc7ff;
                      }
                      else {
                        uVar13 = uStack_d4 ^ (*(ushort *)(pbStack_258 + 2) ^ uStack_d4) & 0x3800;
                      }
                      uStack_d4 = (uVar13 ^ *(ushort *)(pbStack_258 + 2)) & 0x7ff ^ uVar13;
                      puStack_250 = &uStack_fe;
                      pbVar16 = (byte *)((ulonglong)((uStack_d4 & 0x7ff) * 2) +
                                         (ulonglong)((uVar13 >> 0xb & 7) * 2) + 4 + uVar22 +
                                        (longlong)piVar12);
                      puStack_240 = &uStack_fe;
                      uStack_498 = uVar20;
                      pbStack_248 = pbVar16;
                      if (pbVar16 < pbStack_258) {
                        puStack_238 = &uStack_fe;
                        func_0x(pbStack_258,0x19);
                        uVar22 = (ulonglong)uStack_d6;
                        piVar12 = piStack_f8;
                      }
                      puStack_230 = &uStack_fe;
                      uStack_490 = (int)pbVar16 +
                                   (((uStack_d4 & 0x7ff) * 2 - (int)uVar22) - (int)piStack_f8);
                      if (uVar20 < uStack_490) {
                        puStack_228 = &uStack_fe;
                        func_0x((byte *)(uVar22 + (longlong)piVar12),0x19);
                        uVar22 = (ulonglong)uStack_d6;
                        piVar12 = piStack_f8;
                      }
                      if ((uStack_d4 & 0x3800) != 0) {
                        puStack_220 = &uStack_fe;
                        pbVar16 = (byte *)((longlong)piVar12 + uVar22 + 4);
                        iStack_5ec = 0;
                        pbStack_218 = pbVar16;
                        while (iVar23 = iStack_5ec, iStack_5ec < (int)((uStack_d4 & 0x3800) >> 0xb))
                        {
                          if ((uStack_d4 & 0x7ff) <
                              (*(ushort *)(pbVar16 + (longlong)iStack_5ec * 2) & 0x7ff)) {
                            puStack_210 = &uStack_fe;
                            func_0x((byte *)(uVar22 + (longlong)piVar12),0x1a);
                            uVar22 = (ulonglong)uStack_d6;
                            piVar12 = piStack_f8;
                          }
                          iStack_5ec = iVar23 + 1;
                        }
                      }
                      break;
                    }
                    if (uStack_630 < 0x400) break;
                    uStack_fe = uStack_fe | 1;
                    uStack_e4 = uStack_e4 - 1;
                  } while (uStack_e4 != 0);
                }
                piStack_208 = piVar12;
                if ((*(byte *)piVar12 & 0x40) == 0) {
                  uStack_da = 0;
                  uStack_d8 = 0;
                }
                else {
                  uStack_da = (undefined2)uStack_fc;
                  uStack_d8 = (undefined2)(uStack_fc >> 0x10);
                  uStack_fc = uStack_fc + 0xe;
                  uStack_200 = func_0x(&uStack_fe);
                  func_0x(uStack_200,auStack_440);
                  iVar23 = func_0x(auStack_440);
                  uStack_fc = uStack_fc + iVar23;
                  piVar12 = piStack_f8;
                }
                if ((pbStack_e2 != (byte *)0x0) &&
                   (pbStack_e2 < (byte *)((ulonglong)uStack_fc + (longlong)piVar12))) {
                  iVar8 = iVar8 + 1;
                  iStack_6b4 = iVar8;
                  cVar7 = func_0x(0x1f17740);
                  if ((cVar7 != '\0') &&
                     ((lStack_1f8 = func_0x(), lStack_1f8 != 0 &&
                      (*(char *)(lStack_1f8 + 0x499) != '\0')))) {
                    cVar7 = func_0x(0x1f17740);
                    if (cVar7 == '\0') {
                      (*pcRam00000000014852c8)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      puStack_6d8 = (uint *)0x0;
                      (*pcRam00000000014852c0)(1,0x180714c,0x1927238,0x886);
                    }
                  }
                  func_0x(piStack_f8,0x12);
                  piVar12 = piStack_f8;
                }
                iStack_6b4 = iVar8;
                if (0x3f3b < uStack_fc - 1) {
                  iStack_6b4 = iVar8 + 1;
                  cVar7 = func_0x(0x1f17740);
                  if (((cVar7 != '\0') && (lStack_1f0 = func_0x(), lStack_1f0 != 0))
                     && (*(char *)(lStack_1f0 + 0x499) != '\0')) {
                    cVar7 = func_0x(0x1f17740);
                    if (cVar7 == '\0') {
                      (*pcRam00000000014852c8)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      puStack_6d8 = (uint *)0x0;
                      (*pcRam00000000014852c0)(1,0x180714c,0x1927238,0x88b);
                    }
                  }
                  func_0x(piStack_f8,5);
                  piVar12 = piStack_f8;
                  iStack_6b4 = iVar8 + 1;
                }
              }
code_r0x00101690:
              uStack_48c = *puVar18;
              sVar15 = -(short)uStack_48c;
              sStack_62c = sVar15;
              if ((*(byte *)((longlong)puVar18 + 6) & 0x10) != 0) {
                puStack_6d8 = auStack_5e8;
                func_0x(&uStack_fe,puVar18,0,auStack_488);
                piVar12 = piStack_f8;
                if (auStack_5e8[0] == 0) {
                  piStack_1e8 = *(int **)(puVar18 + 2) + 1;
                  iStack_484 = **(int **)(puVar18 + 2);
                  piVar12 = piStack_1e8;
                  param_1 = lStack_510;
                  iVar8 = iStack_484;
                  piVar4 = piStack_1e8;
                  piStack_528 = piStack_1e8;
                  piVar5 = piStack_1e8;
                  piVar6 = piStack_448;
                  goto LAB_;
                }
              }
              uVar9 = (uint)sVar15;
              if (uStack_e4 < uVar9) {
                iStack_6b8 = 0;
                param_1 = lStack_510;
                iVar8 = iStack_6b8;
                piVar4 = piVar12;
                piStack_528 = piVar12;
                piVar5 = piVar12;
                piVar6 = piStack_448;
              }
              else {
                pbStack_438 = (byte *)(((ulonglong)uStack_f0 >> 0x20) + (longlong)piVar12);
                uVar20 = uStack_e8;
                if (uVar9 != 1) {
                  uStack_628 = *(ushort *)(pbStack_438 + (longlong)(int)(uVar9 - 2) * 2 + 2);
                  piVar12 = piStack_f8;
                  uVar20 = uStack_628 & 0x7fff;
                }
                uStack_624 = *(ushort *)(pbStack_438 + (longlong)(int)(uVar9 - 1) * 2 + 2);
                uVar21 = uStack_624 & 0x7fff;
                uStack_5e0 = uVar9;
                uStack_5d8 = uVar20;
                uStack_480 = uVar21;
                if (((uVar20 < uStack_e8) || (uVar21 < uVar20)) || (uStack_fc < uVar21)) {
                  func_0x(piVar12,7);
                  piVar12 = piStack_f8;
                }
                piVar12 = (int *)((ulonglong)uVar20 + (longlong)piVar12);
                param_1 = lStack_510;
                iVar8 = uVar21 - uVar20;
                piVar4 = piVar12;
                piStack_528 = piVar12;
                piVar5 = piVar12;
                uStack_470 = uVar20;
                piVar6 = piStack_448;
              }
            }
            else if ((*(ushort *)((longlong)puVar18 + 6) & 8) == 0) {
              if ((*(ushort *)((longlong)puVar18 + 6) & 0x10) != 0) {
                puStack_6d8 = &uStack_5f8;
                func_0x(&uStack_fe,puVar18,0,auStack_4c8);
                if (uStack_5f8 == 0) {
                  piVar12 = *(int **)(puVar18 + 2) + 1;
                  iVar8 = **(int **)(puVar18 + 2);
                  param_1 = lStack_510;
                  piVar4 = piVar12;
                  piVar5 = piVar12;
                  iStack_4cc = iVar8;
                  piVar6 = piVar12;
                  piStack_2c0 = piVar12;
                  if (iVar8 != 6) {
                    puStack_6d8 = (uint *)0x0;
                    (*pcRam00000000014852c0)(1,0x19b5590,0x19b3ef8,0x381);
                    param_1 = lStack_510;
                  }
                  goto LAB_;
                }
              }
              iStack_6b8 = 6;
              uStack_4d4 = *puVar18;
              piVar12 = (int *)((longlong)piStack_f8 + (longlong)(int)uStack_4d4);
              param_1 = lStack_510;
              iVar8 = iStack_6b8;
              piVar4 = piVar12;
              piVar5 = piVar12;
              piVar6 = piVar12;
            }
            else {
              piVar12 = (int *)func_0x(&uStack_fe,puVar18,&iStack_6b8);
              param_1 = lStack_510;
              iVar8 = iStack_6b8;
              piVar4 = piVar12;
              piVar5 = piVar12;
              piVar6 = piStack_448;
            }
          }
        }
        else {
          uStack_658 = 0;
          puStack_6d8 = &uStack_658;
          piVar12 = (int *)func_0x(&uStack_fe,puVar18,0,&iStack_6b8);
          param_1 = lStack_510;
          iVar8 = iStack_6b8;
          piVar4 = piStack_580;
          piVar5 = piStack_520;
          piStack_4f0 = piVar12;
          piVar6 = piStack_448;
          if (((uStack_100 == 0) || (ppbStack_1e0 = uStack_f0, uStack_f0 == (byte **)0x0)) ||
             (ppbStack_1d8 = uStack_f0, *uStack_f0 == (byte *)0x0)) {
            uStack_650 = 0;
          }
          else {
            uStack_650 = 1;
            if (((*(byte *)((longlong)puVar18 + 6) & 8) == 0) && ((uStack_658 & 1) == 0)) {
              iStack_468 = iStack_6b8;
              ppbStack_1c8 = uStack_f0;
              uStack_460 = uStack_658;
              piStack_1d0 = piVar12;
              if ((piVar12 == (int *)0x0) || (piVar12 == (int *)0x158bde0)) {
                iStack_6b8 = 0;
                piStack_4f0 = (int *)0x0;
                piVar12 = (int *)0x0;
                iVar8 = iStack_6b8;
              }
              else {
                uStack_6c0 = uStack_658;
                piStack_6c8 = &iStack_6b8;
                uStack_6d0 = (longlong ***)CONCAT44(uStack_6d0._4_4_,6);
                puStack_6d8 = auStack_40;
                piVar12 = (int *)func_0x(uStack_f0,puVar18,piVar12);
                param_1 = lStack_510;
                iVar8 = iStack_6b8;
                piVar4 = piStack_580;
                piVar5 = piStack_520;
                piStack_4f0 = piVar12;
                piVar6 = piStack_448;
              }
            }
          }
        }
      }
LAB_:
      piStack_448 = piVar6;
      piStack_520 = piVar5;
      piStack_580 = piVar4;
      iStack_6b8 = iVar8;
      iStack_660 = *piVar12;
      uStack_65c = *(undefined2 *)(piVar12 + 1);
      piStack_518 = piVar12;
    }
    else {
      piStack_3d8 = (int *)((longlong)pplStack_508 + 0x34);
      iStack_660 = *piStack_3d8;
      uStack_65c = *(undefined2 *)(pplStack_508 + 7);
    }
    func_0x(param_2,&iStack_660,&uStack_5b0);
    func_0x(*(undefined8 *)(param_1 + 0x2f8),0,&pplStack_508);
  }
  lStack_500 = lVar14;
  if (*(int *)(lVar14 + 0xd0) == 2) goto LAB_;
  pplStack_578 = (longlong **)(lVar14 + 0x68);
  if (*pplStack_578 != (longlong *)0x0) {
    puStack_1c0 = (ushort *)((longlong)*pplStack_578 + 0x62);
    uStack_698 = *puStack_1c0;
    if (((uStack_698 & 0x400) == 0) || (*(short *)(lVar14 + 0x74) < 3)) {
      iStack_6a8 = (int)*(short *)(lVar14 + 0x74);
      plStack_668 = *pplStack_578;
      puStack_1b8 = (undefined2 *)((longlong)plStack_668 + 0x62);
      uStack_690 = *puStack_1b8;
      if (((byte)uStack_690 >> 3 & 1) != 0) {
        if (iStack_6a8 == 3) {
          iStack_6a8 = 4;
        }
        else if (iStack_6a8 < 2) goto LAB_;
        puStack_1b0 = (uint *)((longlong)plStack_668 + 100);
        uStack_5d0 = *puStack_1b0;
        if ((((uStack_5d0 & 8) != 0) && (lVar17 = plStack_668[0x12], lVar17 != 0)) &&
           (lStack_1a8 = lVar17, *(longlong *)(lVar17 + 0x758) != 0)) {
          func_0x(*(undefined8 *)(lVar17 + 0x758),plStack_668,iStack_6a8);
        }
      }
LAB_:
      bStack_678 = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar18 = (uint *)((longlong)plStack_668 + 100);
        uStack_5c8 = *puVar18;
        puStack_1a0 = puVar18;
        if ((((uStack_5c8 & 8) != 0) && (2 < iStack_6a8)) &&
           ((uStack_5c0 = *puVar18, puStack_198 = puVar18, (uStack_5c0 & 0xc0000000) != 0x40000000
            && (*plStack_668 != 0)))) {
          uStack_458 = 2;
          iVar8 = (*_DAT_)(*plStack_668,0x2000,2,auStack_430);
          if (iVar8 != 0) {
            LOCK();
            *puVar18 = *puVar18 & 0x3fffffff;
            UNLOCK();
            LOCK();
            *puVar18 = *puVar18 | 0x40000000;
            UNLOCK();
          }
        }
      }
      plVar3 = plStack_668;
      iVar8 = iStack_6a8;
      func_0x(plStack_668 + 0x13,iStack_6a8);
      if ((_DAT_ != 0) && (bStack_6a0 = DAT_ >> 1, (bStack_6a0 & 1) != 0)) {
        func_0x(plVar3,0,iVar8);
      }
      *(uint *)(lVar14 + 0x74) = *(uint *)(lVar14 + 0x74) & 0xffff0000;
      *pplStack_578 = (longlong *)0x0;
    }
    else {
      func_0x(pplStack_578);
    }
  }
  lVar14 = lStack_500;
  *(undefined4 *)(lStack_500 + 0x80) = 0xffffffff;
  puStack_190 = (undefined8 *)(lStack_500 + 0x88);
  if (*(int *)(lStack_500 + 0x90) != 0) {
    uStack_428 = *(undefined4 *)(lStack_500 + 0x94);
    uStack_188 = *puStack_190;
    func_0x();
    *(undefined4 *)(lVar14 + 0x90) = 0;
  }
  uStack_590 = 0;
  uStack_58c = 0;
  puStack_180 = (undefined4 *)(lVar14 + 0x9c);
  *puStack_180 = 0;
  *(undefined2 *)(lVar14 + 0xa0) = 0;
  uStack_548 = 0;
  uStack_544 = 0;
  uStack_540 = 0;
  *(undefined8 *)(lVar14 + 0xbc) = 0;
  *(undefined2 *)(lVar14 + 0xc4) = 0;
  *(int *)(lVar14 + 0xd0) = 2;
LAB_:
  if (lStack_640 != 0) {
    lStack_178 = lStack_640;
    (*_DAT_)(lStack_640,0x18);
  }
  lVar17 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar14 = *(longlong *)(lVar17 + 0x100);
  if (lVar14 == 0) {
    (*_DAT_)();
    lVar14 = *(longlong *)(lVar17 + 0x100);
  }
  if (*(int *)(lVar14 + 0x22c) != 0) {
    (*_DAT_)();
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_6f8);
  return;
}

