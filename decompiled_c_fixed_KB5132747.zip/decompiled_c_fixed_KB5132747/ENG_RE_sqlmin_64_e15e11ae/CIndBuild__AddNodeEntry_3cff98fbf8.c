
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,int *param_2,int *param_3)

{
  byte *pbVar1;
  undefined uVar2;
  longlong lVar3;
  ushort *puVar4;
  longlong *plVar5;
  ushort uVar6;
  uint **ppuVar7;
  char cVar8;
  byte bVar9;
  ushort uVar10;
  int iVar11;
  uint uVar12;
  int iVar13;
  ulonglong uVar14;
  longlong lVar15;
  short *psVar16;
  undefined8 uVar17;
  longlong lVar18;
  longlong lVar19;
  uint *puVar20;
  undefined4 uVar21;
  ulonglong *puVar22;
  uint uVar23;
  uint uVar24;
  int *piVar25;
  byte *pbVar26;
  uint uVar27;
  byte **ppbVar28;
  ulonglong **ppuVar29;
  int *piVar30;
  short sVar31;
  longlong lVar32;
  longlong *plVar33;
  ulonglong uVar34;
  ushort *puVar35;
  longlong unaff_GS_OFFSET;
  bool bVar36;
  undefined auStack_d98 [32];
  undefined8 uStack_d78;
  undefined8 uStack_d70;
  undefined8 uStack_d68;
  undefined8 uStack_d60;
  longlong lStack_d58;
  undefined8 uStack_d50;
  ulonglong uStack_d48;
  undefined4 uStack_d40;
  undefined8 uStack_d38;
  ulonglong *puStack_d28;
  undefined uStack_d20;
  uint uStack_d1c;
  uint uStack_d18;
  int aiStack_d10 [2];
  longlong *plStack_d08;
  undefined uStack_d00;
  uint uStack_cfc;
  uint uStack_cf8;
  undefined8 uStack_cf0;
  undefined4 uStack_ce8;
  int iStack_ce0;
  short sStack_cdc;
  undefined8 uStack_cd8;
  undefined4 uStack_cd0;
  undefined2 uStack_cc8;
  ushort uStack_cc6;
  undefined4 uStack_cc4;
  byte *pbStack_cc0;
  undefined8 uStack_cb8;
  uint uStack_cb0;
  short sStack_cac;
  undefined8 uStack_caa;
  undefined2 uStack_ca2;
  undefined2 uStack_ca0;
  undefined6 uStack_c9e;
  undefined4 uStack_c98;
  uint uStack_c90;
  uint uStack_c8c;
  uint uStack_c88;
  uint uStack_c84;
  undefined4 uStack_c80;
  longlong *plStack_c78;
  ulonglong uStack_c70;
  undefined8 uStack_c68;
  ushort uStack_c60;
  undefined8 uStack_c58;
  ushort uStack_c50;
  undefined8 uStack_c48;
  ushort uStack_c40;
  undefined8 uStack_c38;
  ushort uStack_c30;
  undefined8 uStack_c28;
  ushort uStack_c20;
  undefined8 uStack_c18;
  undefined2 uStack_c10;
  undefined8 uStack_c08;
  ushort uStack_c00;
  undefined auStack_bf8 [4];
  undefined4 uStack_bf4;
  undefined auStack_bf0 [4];
  undefined4 uStack_bec;
  undefined4 uStack_be8;
  uint uStack_be4;
  undefined8 uStack_be0;
  undefined2 uStack_bd8;
  undefined4 uStack_bd0;
  undefined2 uStack_bcc;
  undefined4 uStack_bc8;
  undefined2 uStack_bc4;
  undefined4 uStack_bc0;
  undefined2 uStack_bbc;
  undefined4 uStack_bb8;
  undefined2 uStack_bb4;
  int iStack_bb0;
  undefined2 uStack_bac;
  int iStack_ba8;
  undefined2 uStack_ba4;
  undefined4 uStack_ba0;
  undefined2 uStack_b9c;
  undefined4 uStack_b98;
  undefined2 uStack_b94;
  undefined4 uStack_b90;
  undefined2 uStack_b8c;
  undefined4 uStack_b88;
  undefined2 uStack_b84;
  undefined4 uStack_b80;
  undefined2 uStack_b7c;
  undefined4 uStack_b78;
  undefined2 uStack_b74;
  uint uStack_b70;
  undefined2 uStack_b6c;
  undefined auStack_b68 [8];
  int *piStack_b60;
  undefined4 uStack_b58;
  undefined2 uStack_b54;
  undefined8 uStack_b50;
  undefined2 uStack_b48;
  undefined8 uStack_b40;
  undefined2 uStack_b38;
  ulonglong *puStack_b30;
  undefined uStack_b28;
  undefined4 uStack_b24;
  undefined4 uStack_b18;
  int *piStack_b10;
  ushort uStack_b08;
  undefined8 uStack_b00;
  ushort uStack_af8;
  undefined8 uStack_af0;
  undefined2 uStack_ae8;
  int *piStack_ae0;
  ushort uStack_ad8;
  undefined8 uStack_ad0;
  undefined2 uStack_ac8;
  undefined8 uStack_ac0;
  undefined2 uStack_ab8;
  ulonglong uStack_ab0;
  undefined auStack_aa8 [4];
  undefined auStack_aa4 [4];
  undefined auStack_aa0 [4];
  undefined auStack_a9c [4];
  undefined auStack_a98 [4];
  undefined auStack_a94 [4];
  undefined auStack_a90 [8];
  undefined auStack_a88 [8];
  undefined auStack_a80 [4];
  undefined auStack_a7c [8];
  undefined auStack_a74 [4];
  uint uStack_a70;
  undefined8 uStack_a6c;
  uint uStack_a58;
  undefined8 uStack_a54;
  uint uStack_a40;
  undefined8 uStack_a3c;
  undefined8 uStack_a28;
  undefined2 *puStack_a20;
  undefined8 uStack_a18;
  undefined auStack_9f8 [8];
  undefined4 uStack_9f0;
  undefined4 uStack_9e8;
  uint **ppuStack_9e0;
  undefined *puStack_9d8;
  undefined8 uStack_9d0;
  uint *puStack_9c8;
  undefined4 uStack_9c0;
  undefined4 uStack_9bc;
  longlong lStack_9b8;
  undefined4 uStack_9b0;
  undefined4 uStack_9ac;
  longlong lStack_9a8;
  undefined4 uStack_9a0;
  undefined4 uStack_99c;
  short *psStack_998;
  int iStack_990;
  undefined4 uStack_98c;
  short *psStack_988;
  int iStack_980;
  undefined4 uStack_97c;
  undefined8 uStack_978;
  undefined4 uStack_970;
  undefined4 uStack_96c;
  undefined auStack_968 [448];
  undefined8 uStack_7a8;
  undefined8 uStack_7a0;
  uint uStack_798;
  short sStack_794;
  int iStack_792;
  undefined uStack_78e;
  undefined uStack_78d;
  undefined auStack_758 [8];
  undefined4 uStack_750;
  undefined4 uStack_748;
  uint **ppuStack_740;
  undefined *puStack_738;
  undefined8 uStack_730;
  uint *puStack_728;
  undefined4 uStack_720;
  undefined4 uStack_71c;
  longlong lStack_718;
  undefined4 uStack_710;
  undefined4 uStack_70c;
  longlong lStack_708;
  undefined4 uStack_700;
  undefined4 uStack_6fc;
  short *psStack_6f8;
  int iStack_6f0;
  undefined4 uStack_6ec;
  short *psStack_6e8;
  int iStack_6e0;
  undefined4 uStack_6dc;
  undefined8 uStack_6d8;
  undefined4 uStack_6d0;
  undefined4 uStack_6cc;
  undefined auStack_6c8 [448];
  undefined8 uStack_508;
  undefined8 uStack_500;
  uint uStack_4f8;
  undefined2 uStack_4f4;
  int iStack_4f2;
  undefined uStack_4ee;
  undefined uStack_4ed;
  undefined auStack_4b8 [8];
  undefined4 uStack_4b0;
  undefined4 uStack_4a8;
  uint **ppuStack_4a0;
  undefined *puStack_498;
  undefined8 uStack_490;
  uint *puStack_488;
  undefined4 uStack_480;
  undefined4 uStack_47c;
  longlong lStack_478;
  undefined4 uStack_470;
  undefined4 uStack_46c;
  longlong lStack_468;
  undefined4 uStack_460;
  undefined4 uStack_45c;
  short *psStack_458;
  int iStack_450;
  undefined4 uStack_44c;
  short *psStack_448;
  int iStack_440;
  undefined4 uStack_43c;
  undefined8 uStack_438;
  undefined4 uStack_430;
  undefined4 uStack_42c;
  undefined auStack_428 [448];
  undefined8 uStack_268;
  undefined8 uStack_260;
  uint uStack_258;
  undefined2 uStack_254;
  int iStack_252;
  undefined uStack_24e;
  undefined uStack_24d;
  short sStack_218;
  ushort uStack_216;
  uint uStack_214;
  int *piStack_210;
  undefined8 uStack_208;
  undefined4 uStack_200;
  ushort uStack_1fc;
  undefined2 uStack_1fa;
  undefined6 uStack_1f8;
  undefined2 uStack_1f2;
  undefined2 uStack_1f0;
  ushort uStack_1ee;
  ushort uStack_1ec;
  undefined2 uStack_1ea;
  undefined4 uStack_1e8;
  int iStack_1e4;
  undefined auStack_1e0 [16];
  undefined auStack_1d0 [8];
  undefined8 uStack_1c8;
  undefined8 uStack_1c0;
  undefined6 uStack_1b8;
  undefined2 uStack_1b2;
  undefined6 uStack_1b0;
  undefined2 uStack_1aa;
  undefined8 uStack_1a8;
  undefined auStack_1a0 [16];
  undefined auStack_190 [16];
  undefined auStack_180 [16];
  undefined8 uStack_170;
  uint auStack_168 [2];
  short asStack_160 [24];
  short asStack_130 [24];
  short asStack_100 [24];
  short asStack_d0 [24];
  short asStack_a0 [24];
  short asStack_70 [24];
  ulonglong uStack_40;
  
  uStack_a28 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)auStack_d98;
  lVar15 = 0;
  puStack_d28 = (ulonglong *)0x0;
  uStack_d20 = 0;
  uStack_d1c = 0;
  puStack_b30 = (ulonglong *)0x0;
  uStack_b28 = 0;
  uStack_b24 = 0;
  uStack_be4 = 0;
  sStack_218 = -1;
  piStack_210 = (int *)0x0;
  uStack_214 = 0;
  uStack_1fa = 0;
  uStack_1f8 = 0;
  uStack_1f0 = 0;
  uStack_1ee = 0;
  uStack_1ec = 0;
  uStack_1ea = 0;
  uStack_208 = (byte **)0x0;
  iStack_1e4 = -1;
  lVar19 = param_1[5];
  lVar18 = param_1[8];
  uStack_a6c = 0;
  uStack_cf0 = param_2;
  plStack_c78 = param_1;
  piStack_b60 = param_3;
  if ((((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) &&
      ((lVar3 = *(longlong *)
                 ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
       lVar3 == 0 ||
       ((lVar3 = **(longlong **)(lVar3 + 0x38), lVar3 == 0 ||
        (iVar11 = (*_DAT_)(lVar3,0x337), iVar11 == 0)))))) &&
     (lVar3 = *(longlong *)
               ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
               + 8), lVar3 != 0)) {
    lVar15 = *(longlong *)(lVar3 + 0x60);
  }
  lVar3 = *(longlong *)(lVar18 + 0x728);
  uStack_c80 = 2;
  do {
    puVar22 = puStack_d28;
    uStack_c90 = 0;
    if (puStack_d28 != (ulonglong *)0x0) {
      iVar11 = (int)(short)uStack_d1c;
      if (((*(ushort *)((longlong)puStack_d28 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
        if (((byte)*(undefined2 *)((longlong)puStack_d28 + 0x62) >> 3 & 1) != 0) {
          if (iVar11 == 3) {
            iVar11 = 4;
          }
          else if (iVar11 < 2) goto LAB_;
          if ((((*(uint *)((longlong)puStack_d28 + 100) & 8) != 0) &&
              (uVar14 = puStack_d28[0x12], uVar14 != 0)) && (*(longlong *)(uVar14 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(uVar14 + 0x758),puStack_d28,iVar11);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)puVar22 + 100) & 8) != 0)) &&
            ((2 < iVar11 &&
             (((*(uint *)((longlong)puVar22 + 100) & 0xc0000000) != 0x40000000 && (*puVar22 != 0))))
            )) && (iVar13 = (*_DAT_)(*puVar22,0x2000,2,auStack_a7c), iVar13 != 0)) {
          LOCK();
          *(uint *)((longlong)puVar22 + 100) = *(uint *)((longlong)puVar22 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)puVar22 + 100) = *(uint *)((longlong)puVar22 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(puVar22 + 0x13,iVar11);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(puVar22,0,iVar11);
        }
        uStack_d1c = uStack_d1c & 0xffff0000;
        puStack_d28 = (ulonglong *)0x0;
      }
      else {
        func_0x(&puStack_d28);
      }
    }
    if ((*(longlong *)(lVar18 + 0x728) != 0) &&
       (func_0x(&puStack_d28,param_2,lVar18), puVar22 = puStack_d28,
       puStack_d28 != (ulonglong *)0x0)) {
      iVar11 = (int)(short)uStack_d1c;
      if (((*(ushort *)((longlong)puStack_d28 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
        if (((byte)*(undefined2 *)((longlong)puStack_d28 + 0x62) >> 3 & 1) != 0) {
          if (iVar11 == 3) {
            iVar11 = 4;
          }
          else if (iVar11 < 2) goto LAB_;
          if ((((*(uint *)((longlong)puStack_d28 + 100) & 8) != 0) &&
              (uVar14 = puStack_d28[0x12], uVar14 != 0)) && (*(longlong *)(uVar14 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(uVar14 + 0x758),puStack_d28,iVar11);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)puVar22 + 100) & 8) != 0)) &&
            ((2 < iVar11 &&
             (((*(uint *)((longlong)puVar22 + 100) & 0xc0000000) != 0x40000000 && (*puVar22 != 0))))
            )) && (iVar13 = (*_DAT_)(*puVar22,0x2000,2,auStack_aa8), iVar13 != 0)) {
          LOCK();
          *(uint *)((longlong)puVar22 + 100) = *(uint *)((longlong)puVar22 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)puVar22 + 100) = *(uint *)((longlong)puVar22 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(puVar22 + 0x13,iVar11);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(puVar22,0,iVar11);
        }
        uStack_d1c = uStack_d1c & 0xffff0000;
        puStack_d28 = (ulonglong *)0x0;
      }
      else {
        func_0x(&puStack_d28);
      }
    }
    func_0x(lVar18,param_2);
    uStack_d70 = (undefined2 **)&uStack_a70;
    uStack_d78 = (ulonglong **)CONCAT44(uStack_d78._4_4_,4);
    puStack_d28 = (ulonglong *)func_0x(_DAT_,lVar18,param_2);
    if (lVar15 != 0) {
      uVar14 = (ulonglong)(*(uint *)(lVar15 + 0x500) & 0xf);
      if (*(ulonglong *)(lVar15 + 0x508 + uVar14 * 8) != *puStack_d28) {
        *(ulonglong *)(lVar15 + 0x508 + uVar14 * 8) = *puStack_d28;
        *(longlong *)(lVar15 + 0x500) = *(longlong *)(lVar15 + 0x500) + 1;
      }
    }
    uStack_d1c = (uStack_c90 >> 3 & 1) << 0x18 | uStack_d1c & 0xff0004 | 4;
    uStack_d18 = uStack_c90 >> 4 & 1 | uStack_d18 & 0xffffff00;
    if (((lVar3 != 0) && (lVar15 != 0)) && (lVar15 == *(longlong *)(lVar18 + 0x1c38))) {
      *(longlong *)(lVar3 + 0x5b28) = *(longlong *)(lVar3 + 0x5b28) + 1;
      if ((int)uStack_a6c != 0) {
        *(longlong *)(lVar3 + 0x5b30) = *(longlong *)(lVar3 + 0x5b30) + 1;
        *(longlong *)(lVar3 + 0x5b38) = *(longlong *)(lVar3 + 0x5b38) + (ulonglong)uStack_a70;
        if (0xffffff < uStack_d1c) {
          *(longlong *)(lVar3 + 0x5b40) = *(longlong *)(lVar3 + 0x5b40) + 1;
          *(longlong *)(lVar3 + 0x5b48) = *(longlong *)(lVar3 + 0x5b48) + (ulonglong)uStack_a70;
        }
      }
    }
    cVar8 = func_0x(lVar18);
    if (((cVar8 == '\0') || (*(char *)(lVar18 + 0x2050) == '\0')) ||
       ((*param_2 == 0 || ((*param_2 == 9 && (*(short *)(param_2 + 1) == 1)))))) goto LAB_;
    uVar14 = *puStack_d28;
    if (*(short *)(uVar14 + 0x24) == 0) {
LAB_:
      uStack_c08 = *(undefined8 *)(uVar14 + 0x28);
      uStack_c00 = *(ushort *)(uVar14 + 0x30);
    }
    else {
      cVar8 = *(char *)(uVar14 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(uVar14 + 0x18) != 99) {
LAB_:
          if (cVar8 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar8 != '\b') goto LAB_;
LAB_:
        if (*(int *)(uVar14 + 0x18) != 99) goto LAB_;
      }
      uStack_bd0 = *(undefined4 *)(uVar14 + 0x20);
      uStack_bcc = *(undefined2 *)(uVar14 + 0x24);
      cVar8 = func_0x(&uStack_bd0);
      if (cVar8 == '\0') goto LAB_;
      func_0x(uVar14,&uStack_c08);
    }
    uVar23 = *(uint *)(lVar18 + 0x2108);
    do {
      uVar12 = uVar23 & 0xfffffffe;
      uStack_cd8 = *(undefined8 *)(lVar18 + 0x20fc);
      uStack_cd0 = *(undefined4 *)(lVar18 + 0x2104);
      LOCK();
      UNLOCK();
      uVar23 = *(uint *)(lVar18 + 0x2108);
    } while (uVar12 != uVar23);
    if ((uint)uStack_c08 <= (uint)uStack_cd8) {
      if ((uint)uStack_cd8 != (uint)uStack_c08) goto LAB_;
      uVar23 = (uint)(uStack_cd8 >> 0x20);
      if ((uStack_c08._4_4_ <= uVar23) &&
         ((uVar23 != uStack_c08._4_4_ ||
          (uStack_cd0._0_2_ = (ushort)*(undefined4 *)(lVar18 + 0x2104),
          bVar36 = uStack_c00 <= (ushort)uStack_cd0, bVar36)))) goto LAB_;
    }
    if ((*(char *)(lVar18 + 0x6ac8) == '\0') &&
       ((*(longlong *)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            8) + 0x60) != *(longlong *)(lVar18 + 0x2120) &&
        (cVar8 = func_0x(lVar18), cVar8 == '\0')))) break;
    if ((*(longlong *)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            8) + 0x60) == *(longlong *)(lVar18 + 0x2120)) ||
       (cVar8 = func_0x(lVar18), cVar8 != '\0')) goto LAB_;
    if (lVar15 == 0) {
      lVar15 = func_0x();
    }
    uVar14 = *puStack_d28;
    if (*(short *)(uVar14 + 0x24) == 0) {
LAB_:
      uStack_b50 = *(undefined8 *)(uVar14 + 0x28);
      uStack_b48 = *(undefined2 *)(uVar14 + 0x30);
    }
    else {
      cVar8 = *(char *)(uVar14 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(uVar14 + 0x18) != 99) {
LAB_:
          if (cVar8 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar8 != '\b') goto LAB_;
LAB_:
        if (*(int *)(uVar14 + 0x18) != 99) goto LAB_;
      }
      uStack_bc8 = *(undefined4 *)(uVar14 + 0x20);
      uStack_bc4 = *(undefined2 *)(uVar14 + 0x24);
      cVar8 = func_0x(&uStack_bc8);
      if (cVar8 == '\0') goto LAB_;
      func_0x(uVar14,&uStack_b50);
    }
    puVar22 = puStack_d28;
    if (puStack_d28 != (ulonglong *)0x0) {
      iVar11 = (int)(short)uStack_d1c;
      if (((*(ushort *)((longlong)puStack_d28 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
        if (((byte)*(undefined2 *)((longlong)puStack_d28 + 0x62) >> 3 & 1) != 0) {
          if (iVar11 == 3) {
            iVar11 = 4;
          }
          else if (iVar11 < 2) goto LAB_;
          if ((((*(uint *)((longlong)puStack_d28 + 100) & 8) != 0) &&
              (uVar14 = puStack_d28[0x12], uVar14 != 0)) && (*(longlong *)(uVar14 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(uVar14 + 0x758),puStack_d28,iVar11);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)puVar22 + 100) & 8) != 0)) &&
            ((2 < iVar11 &&
             (((*(uint *)((longlong)puVar22 + 100) & 0xc0000000) != 0x40000000 && (*puVar22 != 0))))
            )) && (iVar13 = (*_DAT_)(*puVar22,0x2000,2,auStack_a74), iVar13 != 0)) {
          LOCK();
          *(uint *)((longlong)puVar22 + 100) = *(uint *)((longlong)puVar22 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)puVar22 + 100) = *(uint *)((longlong)puVar22 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(puVar22 + 0x13,iVar11);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(puVar22,0,iVar11);
        }
        uStack_d1c = uStack_d1c & 0xffff0000;
        puStack_d28 = (ulonglong *)0x0;
      }
      else {
        func_0x(&puStack_d28);
      }
    }
    uStack_ac0 = uStack_b50;
    uStack_ab8 = uStack_b48;
    uStack_d78 = (ulonglong **)0x0;
    func_0x(*(undefined8 *)(lVar18 + 0x728),&uStack_ac0,4);
  } while( true );
  uVar23 = *(uint *)(lVar18 + 0x2108);
  do {
    uVar12 = uVar23 & 0xfffffffe;
    uStack_cd8 = *(undefined8 *)(lVar18 + 0x20fc);
    uStack_cd0 = *(undefined4 *)(lVar18 + 0x2104);
    uVar21 = uStack_cd0;
    LOCK();
    UNLOCK();
    uVar23 = *(uint *)(lVar18 + 0x2108);
  } while (uVar12 != uVar23);
  uStack_cd0._0_2_ = (ushort)*(undefined4 *)(lVar18 + 0x2104);
  uVar10 = (ushort)uStack_cd0;
  uStack_af8 = (ushort)uStack_cd0;
  uVar14 = *puStack_d28;
  uStack_cd0 = uVar21;
  uStack_b00 = uStack_cd8;
  if (*(short *)(uVar14 + 0x24) == 0) {
LAB_:
    uStack_c58 = *(undefined8 *)(uVar14 + 0x28);
    uStack_c50 = *(ushort *)(uVar14 + 0x30);
  }
  else {
    cVar8 = *(char *)(uVar14 + 1);
    if (cVar8 == '\v') {
      if (*(int *)(uVar14 + 0x18) != 99) {
LAB_:
        if (cVar8 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar8 != '\b') goto LAB_;
LAB_:
      if (*(int *)(uVar14 + 0x18) != 99) goto LAB_;
    }
    uStack_bc0 = *(undefined4 *)(uVar14 + 0x20);
    uStack_bbc = *(undefined2 *)(uVar14 + 0x24);
    cVar8 = func_0x(&uStack_bc0);
    if (cVar8 == '\0') goto LAB_;
    func_0x(uVar14,&uStack_c58);
  }
  if ((uint)uStack_cd8 < (uint)uStack_c58) {
LAB_:
    lVar15 = *(longlong *)(lVar18 + 0x6b0);
    func_0x(&uStack_c58,asStack_70,auStack_bf8);
    func_0x(&uStack_b00,asStack_160,auStack_bf8);
    if ((_DAT_ & 0x10000) != 0) {
      uStack_750 = 0x60000;
      iVar11 = 0;
      uStack_748 = 0;
      ppuStack_740 = &puStack_728;
      puStack_738 = auStack_6c8;
      uStack_508 = 0;
      uStack_730 = 0;
      uStack_500 = 0;
      puStack_728 = &uStack_4f8;
      uStack_720 = 0x34;
      uStack_71c = 5;
      uStack_710 = 0x10;
      uStack_70c = 5;
      uStack_700 = 0x10;
      uStack_6fc = 6;
      uStack_6ec = 7;
      uStack_6dc = 8;
      uStack_6d8 = 0;
      uStack_6d0 = 0;
      uStack_6cc = 9;
      uStack_4f8 = (uint)*(ushort *)(lVar18 + 0x6b8);
      uStack_4f4 = *(undefined2 *)(param_2 + 1);
      iStack_4f2 = *param_2;
      uStack_4ee = 0xff;
      uStack_4ed = *(undefined *)(*puStack_d28 + 1);
      lStack_718 = lVar15 + 0x254;
      lStack_708 = lVar15 + 0x244;
      lVar18 = -1;
      do {
        lVar18 = lVar18 + 1;
      } while (asStack_70[lVar18] != 0);
      iStack_6f0 = (int)lVar18 * 2;
      psStack_6f8 = asStack_70;
      lVar18 = -1;
      do {
        lVar18 = lVar18 + 1;
      } while (asStack_160[lVar18] != 0);
      iStack_6e0 = (int)lVar18 * 2;
      psStack_6e8 = asStack_160;
      uStack_bf4 = 0;
      puVar20 = (uint *)(**(code **)(_DAT_ + 0x10))(lVar15,&uStack_bf4);
      ppuVar7 = ppuStack_740;
      if (puVar20 != (uint *)0x0) {
        lVar18 = -1;
        do {
          lVar18 = lVar18 + 1;
        } while (*(short *)((longlong)puVar20 + lVar18 * 2) != 0);
        iVar11 = (int)lVar18 * 2;
      }
      ppuStack_740[10] = puVar20;
      *(int *)(ppuVar7 + 0xb) = iVar11;
      *(undefined4 *)((longlong)ppuVar7 + 0x5c) = 9;
      func_0x(auStack_758);
    }
  }
  else if ((uint)uStack_cd8 == (uint)uStack_c58) {
    uVar23 = (uint)((ulonglong)uStack_c58 >> 0x20);
    if ((uStack_cd8._4_4_ < uVar23) || ((uStack_cd8._4_4_ == uVar23 && (uVar10 < uStack_c50))))
    goto LAB_;
  }
LAB_:
  uVar14 = *puStack_d28;
  uStack_cd8 = uVar14;
  if ((*(int *)(uVar14 + 0x20) != *piStack_b60) ||
     (plVar33 = plStack_c78, *(short *)(uVar14 + 0x24) != *(short *)(piStack_b60 + 1))) {
    if (*(int *)(plStack_c78 + 0x1ea) == 0) {
      iVar11 = *(ushort *)(uVar14 + 0x16) - 1;
    }
    else {
      iVar11 = 0;
    }
    ppbVar28 = (byte **)0x0;
    iStack_1e4 = iVar11;
    if (*(char *)(uVar14 + 2) < '\0') {
      pbVar1 = (byte *)(uVar14 + 0x60);
      if ((sStack_218 == 0) || (ppbVar28 = uStack_208, uStack_208 == (byte **)0x0)) {
        uStack_1b8 = 0;
        uStack_1aa = 0;
        auStack_190 = ZEXT816(0);
        auStack_1e0 = ZEXT816(0);
        stack0xfffffffffffffe32 = SUB1614(ZEXT816(0),2);
        auStack_1d0._0_2_ = 0xffff;
        uStack_1c8 = 0;
        uStack_1b2 = 0;
        uStack_1b0 = 0;
        uStack_1a8 = 0;
        uStack_1c0 = 0;
        auStack_1a0 = ZEXT816(0);
        auStack_180._0_12_ = ZEXT812(0);
        auStack_180._12_4_ = 0;
        uStack_170 = 0;
        ppbVar28 = (byte **)auStack_1e0;
      }
      if (*(short *)(uVar14 + 0x24) == 0) {
LAB_:
        uStack_c18 = *(undefined8 *)(uVar14 + 0x28);
        uStack_c10 = *(undefined2 *)(uVar14 + 0x30);
      }
      else {
        cVar8 = *(char *)(uVar14 + 1);
        if (cVar8 == '\v') {
          if (*(int *)(uVar14 + 0x18) != 99) {
LAB_:
            if (cVar8 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar8 != '\b') goto LAB_;
LAB_:
          if (*(int *)(uVar14 + 0x18) != 99) goto LAB_;
        }
        uStack_bb8 = *(undefined4 *)(uVar14 + 0x20);
        uStack_bb4 = *(undefined2 *)(uVar14 + 0x24);
        cVar8 = func_0x(&uStack_bb8,0x1023ec0);
        if (cVar8 == '\0') goto LAB_;
        func_0x(uVar14,&uStack_c18);
      }
      *ppbVar28 = pbVar1;
      *(undefined4 *)(ppbVar28 + 0xc) = (undefined4)uStack_c18;
      *(int *)((longlong)ppbVar28 + 100) = (int)((ulonglong)uStack_c18 >> 0x20);
      *(undefined2 *)(ppbVar28 + 0xd) = uStack_c10;
      *(undefined4 *)((longlong)ppbVar28 + 0x6c) = *(undefined4 *)(uVar14 + 0x20);
      *(undefined2 *)(ppbVar28 + 0xe) = *(undefined2 *)(uVar14 + 0x24);
      *(undefined2 *)((longlong)ppbVar28 + 0x72) = 0;
      uStack_b18 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x10a27a0);
      uVar34 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x10a27a4);
      *(undefined2 *)(ppbVar28 + 2) = 0xffff;
      ppbVar28[3] = (byte *)0x0;
      uVar23 = 0;
      *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
      *(undefined8 *)((longlong)ppbVar28 + 0x2e) = 0;
      ppbVar28[7] = (byte *)0x0;
      ppbVar28[4] = (byte *)0x0;
      ppbVar28[9] = (byte *)0x0;
      ppbVar28[10] = (byte *)0x0;
      *(undefined2 *)(ppbVar28 + 0xb) = 0;
      if ((**ppbVar28 & 2) != 0) {
        pbVar26 = pbVar1 + uVar34;
        if ((*pbVar26 & 1) == 0) {
          *(undefined2 *)(ppbVar28 + 2) = 0;
          ppbVar28[3] = pbVar26;
          *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
          *(undefined4 *)((longlong)ppbVar28 + 0x36) = 0;
          switch(*pbVar26 & 0xe) {
          default:
            uVar23 = (uint)*(ushort *)(pbVar26 + 2);
            if (0x1f9d < *(ushort *)(pbVar26 + 2) - 1) {
              func_0x(pbVar26,6);
            }
            break;
          case 4:
            uVar23 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar23 = 1;
          }
          *(uint *)(ppbVar28 + 4) = uVar23;
          *(undefined8 *)((longlong)ppbVar28 + 0x2e) = 0;
        }
        else {
          *(undefined2 *)(ppbVar28 + 2) = 1;
          ppbVar28[3] = pbVar26;
          bVar9 = *pbVar26;
          switch(bVar9 & 0x1c) {
          default:
            if ((char)pbVar26[1] < '\0') {
              uVar10 = *(ushort *)(pbVar26 + 1);
              *(ushort *)((longlong)ppbVar28 + 0x12) = uVar10;
              sVar31 = 3;
              uVar10 = (uVar10 & 0x7f) << 8 | uVar10 >> 8;
            }
            else {
              sVar31 = 2;
              uVar10 = (ushort)pbVar26[1];
            }
            *(ushort *)((longlong)ppbVar28 + 0x12) = uVar10;
            *(short *)(ppbVar28 + 5) = sVar31;
            uVar10 = *(ushort *)((longlong)ppbVar28 + 0x12);
            *(short *)((longlong)ppbVar28 + 0x2c) = (short)(uVar10 + 1 >> 1) + sVar31;
            if (uVar10 < 0x1f) {
              *(undefined2 *)((longlong)ppbVar28 + 0x2a) = 0;
              *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
              *(undefined4 *)(ppbVar28 + 8) = 0;
              ppbVar28[7] = (byte *)0x0;
              ppbVar28[4] = (byte *)0x0;
            }
            else {
              iVar13 = uVar10 - 1;
              *(short *)((longlong)ppbVar28 + 0x2a) =
                   ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
                   (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
              *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0;
              *(undefined4 *)(ppbVar28 + 8) = 0;
              ppbVar28[7] = (byte *)0x0;
              ppbVar28[4] = (byte *)0x0;
            }
            break;
          case 4:
            if (((bVar9 & 0x1c) != 4) || (uVar12 = 1, (bVar9 & 2) == 0)) {
              uVar12 = uVar23;
            }
            if (uVar12 == 0) {
              uVar21 = 1;
            }
            else {
              *(undefined4 *)(ppbVar28 + 8) = 0;
              uVar21 = 0xf;
            }
            ppbVar28[5] = (byte *)0x0;
            *(undefined2 *)((longlong)ppbVar28 + 0x12) = 0;
            ppbVar28[6] = (byte *)0x0;
            ppbVar28[4] = (byte *)0x0;
            ppbVar28[7] = (byte *)0x0;
            ppbVar28[3] = pbVar26;
            *(undefined4 *)((longlong)ppbVar28 + 0x14) = uVar21;
            *(uint *)(ppbVar28 + 8) = (uint)(uVar12 != 0);
            ppbVar28[7] = (byte *)0x0;
            ppbVar28[4] = (byte *)0x0;
            break;
          case 8:
            ppbVar28[5] = (byte *)0x0;
            *(undefined2 *)((longlong)ppbVar28 + 0x12) = 0;
            ppbVar28[6] = (byte *)0x0;
            ppbVar28[4] = (byte *)0x0;
            ppbVar28[7] = (byte *)0x0;
            ppbVar28[3] = pbVar26;
            *(undefined4 *)((longlong)ppbVar28 + 0x14) = 9;
            *(undefined4 *)(ppbVar28 + 8) = 0;
            ppbVar28[7] = (byte *)0x0;
            ppbVar28[4] = (byte *)0x0;
          }
        }
      }
      if ((**ppbVar28 & 4) != 0) {
        if (uStack_b18._2_2_ != 0) {
          uVar34 = (ulonglong)*(ushort *)(uVar14 + 0x61 + (longlong)uStack_b18._2_2_ * 2);
        }
        psVar16 = (short *)(pbVar1 + uVar34);
        ppbVar28[9] = (byte *)psVar16;
        sVar31 = *psVar16;
        ppbVar28[10] = (byte *)(psVar16 + 1);
        *(short *)(ppbVar28 + 0xb) = (sVar31 + 1) * 2;
      }
      if (ppbVar28[1] != (byte *)0x0) {
        func_0x(ppbVar28[1],ppbVar28);
      }
    }
    piStack_210 = (int *)(*(ushort *)(uVar14 + (0xfff - (longlong)iVar11) * 2) + uVar14);
    if ((*(byte *)piStack_210 & 1) == 0) {
      sStack_218 = 0;
      uStack_214 = 0;
      uStack_1f2 = 0;
      uStack_1f0 = 0;
      ppbVar28 = (byte **)(ulonglong)*(ushort *)(uVar14 + 0xe);
      switch(*(byte *)piStack_210 & 0xe) {
      default:
        ppbVar28 = (byte **)(ulonglong)*(ushort *)((longlong)piStack_210 + 2);
        if (0x1f9d < *(ushort *)((longlong)piStack_210 + 2) - 1) {
          func_0x(piStack_210,6);
        }
        break;
      case 4:
        ppbVar28 = (byte **)0x9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        ppbVar28 = (byte **)0x1;
      }
      uStack_208 = (byte **)CONCAT44(uStack_208._4_4_,(int)ppbVar28);
      uStack_1fa = (undefined2)(uVar14 + 0x2000);
      uStack_1f8 = (undefined6)(uVar14 + 0x2000 >> 0x10);
    }
    else {
      sStack_218 = 1;
      bVar9 = *(byte *)piStack_210;
      switch(bVar9 & 0x1c) {
      default:
        if ((char)*(byte *)((longlong)piStack_210 + 1) < '\0') {
          uStack_216 = (*(ushort *)((longlong)piStack_210 + 1) & 0x7f) << 8 |
                       *(ushort *)((longlong)piStack_210 + 1) >> 8;
          uStack_200._0_2_ = 3;
          sVar31 = 3;
        }
        else {
          uStack_216 = (ushort)*(byte *)((longlong)piStack_210 + 1);
          uStack_200._0_2_ = 2;
          sVar31 = 2;
        }
        uStack_1fc = (short)(uStack_216 + 1 >> 1) + sVar31;
        if (uStack_216 < 0x1f) {
          uStack_200._2_2_ = 0;
          uStack_214 = 0;
          uStack_1e8 = 0;
        }
        else {
          iVar11 = uStack_216 - 1;
          uStack_200._2_2_ =
               ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
               (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
          uStack_214 = 0;
          uStack_1e8 = 0;
        }
        break;
      case 4:
        if (((bVar9 & 0x1c) == 4) && ((bVar9 & 2) != 0)) {
          uStack_200._0_2_ = 0;
          uStack_200._2_2_ = 0;
          uStack_1fc = 0;
          uStack_1fa = 0;
          uStack_216 = 0;
          uStack_1f8 = 0;
          uStack_1f2 = 0;
          uStack_214 = 0xf;
          uStack_1e8 = 1;
        }
        else {
          uStack_200._0_2_ = 0;
          uStack_200._2_2_ = 0;
          uStack_1fc = 0;
          uStack_1fa = 0;
          uStack_216 = 0;
          uStack_1f8 = 0;
          uStack_1f2 = 0;
          uStack_214 = 1;
          uStack_1e8 = 0;
        }
        break;
      case 8:
        uStack_200._0_2_ = 0;
        uStack_200._2_2_ = 0;
        uStack_1fc = 0;
        uStack_1fa = 0;
        uStack_216 = 0;
        uStack_1f8 = 0;
        uStack_1f2 = 0;
        uStack_214 = 9;
        uStack_1e8 = 0;
      }
      lVar18 = uVar14 + 0x2000;
      uStack_1f0 = (undefined2)lVar18;
      uStack_1ee = (ushort)((ulonglong)lVar18 >> 0x10);
      uStack_1ec = (ushort)((ulonglong)lVar18 >> 0x20);
      uStack_1ea = (undefined2)((ulonglong)lVar18 >> 0x30);
      uStack_208 = ppbVar28;
    }
    puVar20 = (uint *)(lVar19 + 0x210);
    if (sStack_218 == 0) {
      uVar23 = *puVar20;
      if ((uVar23 & 0xc0000000) == 0x80000000) {
        iVar11 = func_0x(&uStack_216);
        if (iVar11 == 0) {
          aiStack_d10[0] = 0;
          piVar25 = (int *)0x0;
          goto code_r0x00101ca7;
        }
        piVar25 = (int *)func_0x(&uStack_1ee,puVar20,aiStack_d10);
        goto code_r0x00101ca4;
      }
      uVar10 = *(ushort *)(lVar19 + 0x216);
      if ((uVar10 & 0x10) == 0) {
code_r0x001013e5:
        if ((int)uVar23 < 0) {
          piVar25 = piStack_210;
          if (uStack_214 == 0) {
            uStack_216 = 0;
            uVar34 = (ulonglong)uStack_208 & 0xffffffff;
            uVar23 = (uint)uStack_208;
            if ((*(byte *)piStack_210 & 0x10) != 0) {
              uVar23 = (uint)uStack_208 + 2 + (*(ushort *)((longlong)piStack_210 + uVar34) + 7 >> 3)
              ;
              uVar34 = (ulonglong)uVar23;
            }
            uStack_208 = (byte **)CONCAT44(uVar23,(uint)uStack_208);
            uVar23 = (uint)uVar34;
            if ((*(byte *)piStack_210 & 0x20) == 0) {
              uStack_1fc = 0;
              uStack_214 = uVar23;
            }
            else {
              puVar35 = (ushort *)(uVar34 + (longlong)piStack_210);
              uStack_1fc = *puVar35;
              if (uStack_1fc == 0) {
                cVar8 = func_0x(0x19b8f50);
                if ((cVar8 != '\0') && (cVar8 = func_0x(), cVar8 != '\0')) {
                  cVar8 = func_0x(0x19b8f50);
                  if (cVar8 == '\0') {
                    (*pcRam0000000000f26ad8)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    uStack_d78 = (ulonglong **)0x0;
                    (*pcRam0000000000f26ad0)(1,0x12a895c,0x13c8a48,0x80f);
                  }
                }
                func_0x(piStack_210,3);
              }
              uStack_200 = uStack_208._4_4_ + (uStack_1fc + 1) * 2;
              if (0x1f9e < uStack_200) {
                cVar8 = func_0x(0x19b8f50);
                if (cVar8 != '\0') {
                  cVar8 = func_0x();
                  if (cVar8 != '\0') {
                    cVar8 = func_0x(0x19b8f50);
                    if (cVar8 == '\0') {
                      (*pcRam0000000000f26ad8)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_d78 = (ulonglong **)0x0;
                      (*pcRam0000000000f26ad0)(1,0x12a895c,0x13c8a48,0x816);
                    }
                  }
                }
                func_0x(piStack_210,4);
              }
              uStack_214 = puVar35[uStack_1fc] & 0x7fff;
              if (uStack_214 < uStack_200) {
                cVar8 = func_0x(0x19b8f50);
                if (cVar8 != '\0') {
                  cVar8 = func_0x();
                  if (cVar8 != '\0') {
                    cVar8 = func_0x(0x19b8f50);
                    if (cVar8 == '\0') {
                      (*pcRam0000000000f26ad8)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_d78 = (ulonglong **)0x0;
                      (*pcRam0000000000f26ad0)(1,0x12a895c,0x13c8a48,0x81d);
                    }
                  }
                }
                func_0x(piStack_210,4);
              }
              iVar11 = 0;
              piVar25 = piStack_210;
              puVar4 = puVar35;
              uVar23 = uStack_200;
              if (uStack_1fc != 0) {
                do {
                  uVar12 = puVar4[1] & 0x7fff;
                  if ((uVar12 < uStack_200) || (uStack_214 < uVar12)) {
                    uStack_200 = uVar23;
                    cVar8 = func_0x(0x19b8f50);
                    if (cVar8 != '\0') {
                      cVar8 = func_0x();
                      if (cVar8 != '\0') {
                        cVar8 = func_0x(0x19b8f50);
                        if (cVar8 == '\0') {
                          (*pcRam0000000000f26ad8)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_d78 = (ulonglong **)0x0;
                          (*pcRam0000000000f26ad0)(1,0x12a895c,0x13c8a48,0x82a);
                        }
                      }
                    }
                    func_0x(piStack_210,4);
                    piVar25 = piStack_210;
                    uVar23 = uStack_200;
                  }
                  iVar11 = iVar11 + 1;
                  uStack_200 = uVar12;
                  puVar4 = puVar4 + 1;
                  uVar14 = uStack_cd8;
                } while (iVar11 < (int)(uint)uStack_1fc);
              }
              while ((short)puVar35[(ulonglong)(uStack_1fc - 1) + 1] < 0) {
                uVar12 = uVar23;
                if (uStack_1fc != 1) {
                  uVar12 = *(ushort *)
                            ((longlong)piVar25 +
                            (ulonglong)uStack_1fc * 2 + (((ulonglong)uStack_208 >> 0x20) - 2)) &
                           0x7fff;
                }
                uVar27 = *(ushort *)
                          ((longlong)piVar25 +
                          (ulonglong)uStack_1fc * 2 + ((ulonglong)uStack_208 >> 0x20)) & 0x7fff;
                if (((uVar12 < uVar23) || (uVar27 < uVar12)) || (uStack_214 < uVar27)) {
                  uStack_200 = uVar23;
                  func_0x(piVar25,7);
                  piVar25 = piStack_210;
                  uVar23 = uStack_200;
                }
                uStack_200 = uVar23;
                if ((uVar12 < uVar23) || (uStack_214 < uVar12)) goto code_r0x00101b99;
                if (*(ushort *)((ulonglong)uVar12 + (longlong)piVar25) == 5) {
                  uStack_216 = uStack_216 | 2;
                  uStack_1fc = uStack_1fc - 1;
                  uVar34 = (ulonglong)(uVar12 & 0xffff);
                  uStack_1ee = (ushort)uVar12;
                  pbVar1 = (byte *)((longlong)piVar25 + uVar34);
                  if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
                    uVar10 = uStack_1ec & 0xc7ff;
                  }
                  else {
                    uVar10 = uStack_1ec ^ (*(ushort *)(pbVar1 + 2) ^ uStack_1ec) & 0x3800;
                  }
                  uStack_1ec = (uVar10 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar10;
                  pbVar26 = (byte *)((longlong)piVar25 +
                                    uVar34 + (ulonglong)((uStack_1ec & 0x7ff) * 2) + 4 +
                                             (ulonglong)((uVar10 >> 0xb & 7) * 2));
                  if (pbVar26 < pbVar1) {
                    func_0x(pbVar1,0x19);
                    uVar34 = (ulonglong)uStack_1ee;
                    piVar25 = piStack_210;
                  }
                  uVar23 = uStack_200;
                  if (uVar27 - uVar12 <
                      (((uStack_1ec & 0x7ff) * 2 - (int)uVar34) - (int)piStack_210) + (int)pbVar26)
                  {
                    func_0x((byte *)(uVar34 + (longlong)piVar25),0x19);
                    uVar34 = (ulonglong)uStack_1ee;
                    piVar25 = piStack_210;
                    uVar23 = uStack_200;
                  }
                  iVar11 = 0;
                  if (((uStack_1ec & 0x3800) != 0) &&
                     (puVar35 = (ushort *)((longlong)piVar25 + uVar34 + 4), uVar10 = uStack_1ec,
                     (uStack_1ec & 0x3800) != 0)) {
                    do {
                      if ((uVar10 & 0x7ff) < (*puVar35 & 0x7ff)) {
                        uStack_200 = uVar23;
                        func_0x((byte *)(uVar34 + (longlong)piVar25),0x1a);
                        uVar34 = (ulonglong)uStack_1ee;
                        piVar25 = piStack_210;
                        uVar23 = uStack_200;
                        uVar10 = uStack_1ec;
                      }
                      iVar11 = iVar11 + 1;
                      puVar35 = puVar35 + 1;
                    } while (iVar11 < (int)((uStack_1ec & 0x3800) >> 0xb));
                  }
                  break;
                }
                if (*(ushort *)((ulonglong)uVar12 + (longlong)piVar25) < 0x400) break;
                uStack_216 = uStack_216 | 1;
                uStack_1fc = uStack_1fc - 1;
                if (uStack_1fc == 0) break;
              }
            }
            if ((*(byte *)piVar25 & 0x40) == 0) {
              uStack_1f2 = 0;
              uStack_1f0 = 0;
            }
            else {
              uStack_1f2 = (undefined2)uStack_214;
              uStack_1f0 = (undefined2)(uStack_214 >> 0x10);
              uStack_214 = uStack_214 + 0xe;
              uStack_200 = uVar23;
              uVar17 = func_0x(&uStack_216);
              func_0x(uVar17,auStack_a88);
              iVar11 = func_0x(auStack_a88);
              uStack_214 = uStack_214 + iVar11;
              piVar25 = piStack_210;
              uVar23 = uStack_200;
            }
            uStack_200 = uVar23;
            if (((byte *)CONCAT62(uStack_1f8,uStack_1fa) != (byte *)0x0) &&
               ((byte *)CONCAT62(uStack_1f8,uStack_1fa) <
                (byte *)((ulonglong)uStack_214 + (longlong)piVar25))) {
              cVar8 = func_0x(0x19b8f50);
              if (cVar8 != '\0') {
                cVar8 = func_0x();
                if (cVar8 != '\0') {
                  cVar8 = func_0x(0x19b8f50);
                  if (cVar8 == '\0') {
                    (*pcRam0000000000f26ad8)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    uStack_d78 = (ulonglong **)0x0;
                    (*pcRam0000000000f26ad0)(1,0x12a895c,0x13c8a48,0x886);
                  }
                }
              }
              func_0x(piStack_210,0x12);
              piVar25 = piStack_210;
            }
            if (0x3f3b < uStack_214 - 1) {
              cVar8 = func_0x(0x19b8f50);
              if (cVar8 != '\0') {
                cVar8 = func_0x();
                if (cVar8 != '\0') {
                  cVar8 = func_0x(0x19b8f50);
                  if (cVar8 == '\0') {
                    (*pcRam0000000000f26ad8)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    uStack_d78 = (ulonglong **)0x0;
                    (*pcRam0000000000f26ad0)(1,0x12a895c,0x13c8a48,0x88b);
                  }
                }
              }
              func_0x(piStack_210,5);
              piVar25 = piStack_210;
            }
          }
code_r0x00101b99:
          aiStack_d10[0] = 0;
          sVar31 = -*(short *)puVar20;
          if ((*(byte *)(lVar19 + 0x216) & 0x10) != 0) {
            if ((*(byte *)piVar25 & 0x10) == 0) {
              if ((1 << (*(byte *)piVar25 & 0xe) & 0x1105U) != 0) {
code_r0x00101c02:
                piVar25 = *(int **)(lVar19 + 0x218) + 1;
                aiStack_d10[0] = **(int **)(lVar19 + 0x218);
                goto code_r0x00101ca7;
              }
            }
            else if (((int)(uint)uStack_208 <= (int)*puVar20) ||
                    (*(ushort *)(((ulonglong)uStack_208 & 0xffffffff) + (longlong)piVar25) <
                     *(ushort *)(lVar19 + 0x214))) goto code_r0x00101c02;
          }
          if ((uint)(int)sVar31 <= (uint)uStack_1fc) {
            piVar30 = piVar25;
            uVar23 = uStack_200;
            if (sVar31 != 1) {
              piVar30 = piStack_210;
              uVar23 = *(ushort *)
                        ((longlong)piVar25 +
                        (longlong)sVar31 * 2 + (((ulonglong)uStack_208 >> 0x20) - 2)) & 0x7fff;
            }
            uVar12 = *(ushort *)
                      ((longlong)piVar25 + (longlong)sVar31 * 2 + ((ulonglong)uStack_208 >> 0x20)) &
                     0x7fff;
            if (((uVar23 < uStack_200) || (uVar12 < uVar23)) || (uStack_214 < uVar12)) {
              func_0x(piVar30,7);
              piVar30 = piStack_210;
            }
            piVar25 = (int *)((ulonglong)uVar23 + (longlong)piVar30);
            aiStack_d10[0] = uVar12 - uVar23;
          }
        }
        else if ((uVar10 & 8) == 0) {
          if ((uVar10 & 0x10) != 0) {
            if ((*(byte *)piStack_210 & 0x10) == 0) {
              if ((1 << (*(byte *)piStack_210 & 0xe) & 0x1105U) != 0) goto code_r0x0010143f;
            }
            else if (((int)(uint)uStack_208 <= (int)uVar23) ||
                    (*(ushort *)(((ulonglong)uStack_208 & 0xffffffff) + (longlong)piStack_210) <
                     *(ushort *)(lVar19 + 0x214))) {
code_r0x0010143f:
              piVar25 = *(int **)(lVar19 + 0x218) + 1;
              aiStack_d10[0] = **(int **)(lVar19 + 0x218);
              if (aiStack_d10[0] != 6) {
                uStack_d78 = (ulonglong **)0x0;
                (*pcRam0000000000f26ad0)(1,0x1456da0,0x1455708);
              }
              goto code_r0x00101ca7;
            }
          }
          aiStack_d10[0] = 6;
          piVar25 = (int *)((longlong)(int)*puVar20 + (longlong)piStack_210);
        }
        else {
          aiStack_d10[0] = 1;
          piVar25 = (int *)0x102d5f0;
          if ((*(byte *)((longlong)(int)uVar23 + (longlong)piStack_210) &
              (byte)(1 << ((byte)uVar10 & 7))) == 0) {
            piVar25 = (int *)0x102d5f1;
          }
        }
      }
      else if ((*(byte *)piStack_210 & 0x10) == 0) {
        if ((1 << (*(byte *)piStack_210 & 0xe) & 0x1105U) == 0) goto code_r0x001013e5;
        piVar25 = *(int **)(lVar19 + 0x218) + 1;
        aiStack_d10[0] = **(int **)(lVar19 + 0x218);
      }
      else {
        if (((int)uVar23 < (int)ppbVar28) &&
           (*(ushort *)(lVar19 + 0x214) <=
            *(ushort *)(((ulonglong)ppbVar28 & 0xffffffff) + (longlong)piStack_210)))
        goto code_r0x001013e5;
        piVar25 = *(int **)(lVar19 + 0x218) + 1;
        aiStack_d10[0] = **(int **)(lVar19 + 0x218);
      }
    }
    else {
      uStack_c8c = 0;
      uStack_d78 = (ulonglong **)&uStack_c8c;
      piVar25 = (int *)func_0x(&uStack_216,puVar20);
      if ((((sStack_218 != 0) && (uStack_208 != (byte **)0x0)) && (*uStack_208 != (byte *)0x0)) &&
         (((*(byte *)(lVar19 + 0x216) & 8) == 0 && ((uStack_c8c & 1) == 0)))) {
        if ((piVar25 == (int *)0x0) || (piVar25 == (int *)0x102d5f0)) {
          aiStack_d10[0] = 0;
          piVar25 = (int *)0x0;
        }
        else {
          uStack_d60 = CONCAT44(uStack_d60._4_4_,uStack_c8c);
          uStack_d68 = aiStack_d10;
          uStack_d70 = (undefined2 **)CONCAT44(uStack_d70._4_4_,6);
          uStack_d78 = (ulonglong **)auStack_168;
          piVar25 = (int *)func_0x(uStack_208,puVar20,piVar25);
        }
      }
code_r0x00101ca4:
    }
code_r0x00101ca7:
    plVar33 = plStack_c78;
    iStack_ba8 = *piVar25;
    uStack_ba4 = *(undefined2 *)(piVar25 + 1);
    iStack_bb0 = *piStack_b60;
    uStack_bac = *(undefined2 *)(piStack_b60 + 1);
    iVar11 = FUN_(plStack_c78,&iStack_ba8,&iStack_bb0);
    if (iVar11 == 0) goto code_r0x00103a3a;
  }
  puVar22 = puStack_d28;
  uStack_cd8 = plVar33[1];
  *(undefined *)(uStack_cd8 + 0x2c9) = 1;
  uVar23 = *(ushort *)(uVar14 + 0x1c) - 2;
  if (*(ushort *)(uVar14 + 0x1c) < 3) {
    uVar23 = 0;
  }
  uVar10 = (short)(1 << ((byte)*(undefined2 *)(uVar14 + 4) & 2)) - 1;
  uStack_ab0 = uStack_cd8;
  if (uVar23 < (ushort)(uVar10 + *(short *)(plVar33 + 0x1b) & ~uVar10)) {
    uStack_b58 = *(undefined4 *)(uVar14 + 0x10);
    uStack_b54 = *(undefined2 *)(uVar14 + 0x14);
    uVar2 = *(undefined *)(uVar14 + 3);
    uVar10 = *(ushort *)(uVar14 + 0x16);
    if (puStack_d28 != (ulonglong *)0x0) {
      iVar11 = (int)(short)uStack_d1c;
      if (((*(ushort *)((longlong)puStack_d28 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
        if (((byte)*(undefined2 *)((longlong)puStack_d28 + 0x62) >> 3 & 1) != 0) {
          if (iVar11 == 3) {
            iVar11 = 4;
          }
          else if (iVar11 < 2) goto LAB_;
          if ((((*(uint *)((longlong)puStack_d28 + 100) & 8) != 0) &&
              (uVar14 = puStack_d28[0x12], uVar14 != 0)) && (*(longlong *)(uVar14 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(uVar14 + 0x758),puStack_d28,iVar11);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)puVar22 + 100) & 8) != 0)) &&
           ((2 < iVar11 &&
            (((*(uint *)((longlong)puVar22 + 100) & 0xc0000000) != 0x40000000 && (*puVar22 != 0)))))
           ) {
          iVar13 = (*_DAT_)(*puVar22,0x2000,2,auStack_a90);
          if (iVar13 != 0) {
            LOCK();
            *(uint *)((longlong)puVar22 + 100) = *(uint *)((longlong)puVar22 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)puVar22 + 100) = *(uint *)((longlong)puVar22 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        func_0x(puVar22 + 0x13,iVar11);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(puVar22,0,iVar11);
        }
        uStack_d1c = uStack_d1c & 0xffff0000;
        puStack_d28 = (ulonglong *)0x0;
      }
      else {
        func_0x(&puStack_d28);
      }
    }
    plVar33 = plStack_c78;
    piVar25 = uStack_cf0;
    lVar18 = 0;
    uStack_d78 = &puStack_b30;
    func_0x(plStack_c78,uVar2,uStack_cf0,&uStack_b58);
    uStack_c70 = *puStack_b30;
    lVar19 = plVar33[8];
    uStack_a54 = 0;
    if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
      lVar15 = *(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                );
      if ((lVar15 != 0) && (lVar15 = **(longlong **)(lVar15 + 0x38), lVar15 != 0)) {
        iVar11 = (*_DAT_)(lVar15,0x337);
        if (iVar11 != 0) goto LAB_;
      }
      lVar15 = *(longlong *)
                ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
      if (lVar15 != 0) {
        lVar18 = *(longlong *)(lVar15 + 0x60);
      }
    }
LAB_:
    lVar15 = *(longlong *)(lVar19 + 0x728);
    do {
      puVar22 = puStack_d28;
      uStack_c88 = 0;
      if (puStack_d28 != (ulonglong *)0x0) {
        iVar11 = (int)(short)uStack_d1c;
        if (((*(ushort *)((longlong)puStack_d28 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
          if (((byte)*(undefined2 *)((longlong)puStack_d28 + 0x62) >> 3 & 1) != 0) {
            if (iVar11 == 3) {
              iVar11 = 4;
            }
            else if (iVar11 < 2) goto LAB_;
            if ((((*(uint *)((longlong)puStack_d28 + 100) & 8) != 0) &&
                (uVar14 = puStack_d28[0x12], uVar14 != 0)) && (*(longlong *)(uVar14 + 0x758) != 0))
            {
              func_0x(*(undefined8 *)(uVar14 + 0x758),puStack_d28,iVar11);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)puVar22 + 100) & 8) != 0)) &&
             ((2 < iVar11 &&
              (((*(uint *)((longlong)puVar22 + 100) & 0xc0000000) != 0x40000000 && (*puVar22 != 0)))
              ))) {
            iVar13 = (*_DAT_)(*puVar22,0x2000,2,auStack_a94);
            if (iVar13 != 0) {
              LOCK();
              *(uint *)((longlong)puVar22 + 100) = *(uint *)((longlong)puVar22 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)puVar22 + 100) = *(uint *)((longlong)puVar22 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          func_0x(puVar22 + 0x13,iVar11);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            func_0x(puVar22,0,iVar11);
          }
          uStack_d1c = uStack_d1c & 0xffff0000;
          puStack_d28 = (ulonglong *)0x0;
        }
        else {
          func_0x(&puStack_d28);
        }
      }
      if (*(longlong *)(lVar19 + 0x728) != 0) {
        func_0x(&puStack_d28,piVar25,lVar19);
        puVar22 = puStack_d28;
        if (puStack_d28 != (ulonglong *)0x0) {
          iVar11 = (int)(short)uStack_d1c;
          if (((*(ushort *)((longlong)puStack_d28 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
            if (((byte)*(undefined2 *)((longlong)puStack_d28 + 0x62) >> 3 & 1) != 0) {
              if (iVar11 == 3) {
                iVar11 = 4;
              }
              else if (iVar11 < 2) goto LAB_;
              if ((((*(uint *)((longlong)puStack_d28 + 100) & 8) != 0) &&
                  (uVar14 = puStack_d28[0x12], uVar14 != 0)) && (*(longlong *)(uVar14 + 0x758) != 0)
                 ) {
                func_0x(*(undefined8 *)(uVar14 + 0x758),puStack_d28,iVar11);
              }
            }
LAB_:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)puVar22 + 100) & 8) != 0)) &&
               ((2 < iVar11 &&
                (((*(uint *)((longlong)puVar22 + 100) & 0xc0000000) != 0x40000000 && (*puVar22 != 0)
                 ))))) {
              iVar13 = (*_DAT_)(*puVar22,0x2000,2,auStack_a98);
              if (iVar13 != 0) {
                LOCK();
                *(uint *)((longlong)puVar22 + 100) = *(uint *)((longlong)puVar22 + 100) & 0x3fffffff
                ;
                UNLOCK();
                LOCK();
                *(uint *)((longlong)puVar22 + 100) = *(uint *)((longlong)puVar22 + 100) | 0x40000000
                ;
                UNLOCK();
              }
            }
            func_0x(puVar22 + 0x13,iVar11);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              func_0x(puVar22,0,iVar11);
            }
            uStack_d1c = uStack_d1c & 0xffff0000;
            puStack_d28 = (ulonglong *)0x0;
          }
          else {
            func_0x(&puStack_d28);
          }
        }
      }
      func_0x(lVar19,piVar25);
      uStack_d70 = (undefined2 **)&uStack_a58;
      uStack_d78 = (ulonglong **)CONCAT44(uStack_d78._4_4_,4);
      puStack_d28 = (ulonglong *)func_0x(_DAT_,lVar19,piVar25,&uStack_c88);
      if (lVar18 != 0) {
        uVar14 = (ulonglong)(*(uint *)(lVar18 + 0x500) & 0xf);
        if (*(ulonglong *)(lVar18 + 0x508 + uVar14 * 8) != *puStack_d28) {
          *(ulonglong *)(lVar18 + 0x508 + uVar14 * 8) = *puStack_d28;
          *(longlong *)(lVar18 + 0x500) = *(longlong *)(lVar18 + 0x500) + 1;
        }
      }
      uStack_d1c = (uStack_c88 >> 3 & 1) << 0x18 | uStack_d1c & 0xff0004 | 4;
      uStack_d18 = uStack_c88 >> 4 & 1 | uStack_d18 & 0xffffff00;
      if (((lVar15 != 0) && (lVar18 != 0)) && (lVar18 == *(longlong *)(lVar19 + 0x1c38))) {
        *(longlong *)(lVar15 + 0x5b28) = *(longlong *)(lVar15 + 0x5b28) + 1;
        if ((int)uStack_a54 != 0) {
          *(longlong *)(lVar15 + 0x5b30) = *(longlong *)(lVar15 + 0x5b30) + 1;
          *(longlong *)(lVar15 + 0x5b38) = *(longlong *)(lVar15 + 0x5b38) + (ulonglong)uStack_a58;
          if (0xffffff < uStack_d1c) {
            *(longlong *)(lVar15 + 0x5b40) = *(longlong *)(lVar15 + 0x5b40) + 1;
            *(longlong *)(lVar15 + 0x5b48) = *(longlong *)(lVar15 + 0x5b48) + (ulonglong)uStack_a58;
          }
        }
      }
      cVar8 = func_0x(lVar19);
      if (((cVar8 == '\0') || (*(char *)(lVar19 + 0x2050) == '\0')) ||
         ((*piVar25 == 0 || ((*piVar25 == 9 && (*(short *)(piVar25 + 1) == 1))))))
      goto LAB_;
      uVar14 = *puStack_d28;
      if (*(short *)(uVar14 + 0x24) == 0) {
LAB_:
        uStack_c28 = *(undefined8 *)(uVar14 + 0x28);
        uStack_c20 = *(ushort *)(uVar14 + 0x30);
      }
      else {
        cVar8 = *(char *)(uVar14 + 1);
        if (cVar8 == '\v') {
          if (*(int *)(uVar14 + 0x18) != 99) {
LAB_:
            if (cVar8 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar8 != '\b') goto LAB_;
LAB_:
          if (*(int *)(uVar14 + 0x18) != 99) goto LAB_;
        }
        uStack_ba0 = *(undefined4 *)(uVar14 + 0x20);
        uStack_b9c = *(undefined2 *)(uVar14 + 0x24);
        cVar8 = func_0x(&uStack_ba0);
        if (cVar8 == '\0') goto LAB_;
        func_0x(uVar14,&uStack_c28);
      }
      uVar23 = *(uint *)(lVar19 + 0x2108);
      do {
        uVar12 = uVar23 & 0xfffffffe;
        uStack_cf0 = *(int **)(lVar19 + 0x20fc);
        uStack_ce8 = *(undefined4 *)(lVar19 + 0x2104);
        LOCK();
        UNLOCK();
        uVar23 = *(uint *)(lVar19 + 0x2108);
      } while (uVar12 != uVar23);
      if ((uint)uStack_c28 <= (uint)uStack_cf0) {
        if ((uint)uStack_cf0 == (uint)uStack_c28) {
          uVar23 = (uint)((ulonglong)uStack_cf0 >> 0x20);
          if ((uVar23 < uStack_c28._4_4_) ||
             ((uVar23 == uStack_c28._4_4_ && ((ushort)uStack_ce8 < uStack_c20)))) goto LAB_;
        }
        goto LAB_;
      }
LAB_:
      if ((*(char *)(lVar19 + 0x6ac8) == '\0') &&
         (*(longlong *)
           (*(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8) + 0x60) != *(longlong *)(lVar19 + 0x2120))) {
        cVar8 = func_0x(lVar19);
        if (cVar8 == '\0') {
          uVar23 = *(uint *)(lVar19 + 0x2108);
          do {
            uVar12 = uVar23 & 0xfffffffe;
            uStack_cf0 = *(int **)(lVar19 + 0x20fc);
            uStack_ce8 = *(undefined4 *)(lVar19 + 0x2104);
            LOCK();
            UNLOCK();
            uVar23 = *(uint *)(lVar19 + 0x2108);
          } while (uVar12 != uVar23);
          uVar6 = (ushort)uStack_ce8;
          uStack_ad8 = (ushort)uStack_ce8;
          uVar14 = *puStack_d28;
          piStack_ae0 = uStack_cf0;
          if (*(short *)(uVar14 + 0x24) == 0) {
LAB_:
            uStack_c68 = *(undefined8 *)(uVar14 + 0x28);
            uStack_c60 = *(ushort *)(uVar14 + 0x30);
          }
          else {
            cVar8 = *(char *)(uVar14 + 1);
            if (cVar8 == '\v') {
              if (*(int *)(uVar14 + 0x18) != 99) {
LAB_:
                if (cVar8 != '\t') goto LAB_;
                goto LAB_;
              }
            }
            else {
              if (cVar8 != '\b') goto LAB_;
LAB_:
              if (*(int *)(uVar14 + 0x18) != 99) goto LAB_;
            }
            uStack_b90 = *(undefined4 *)(uVar14 + 0x20);
            uStack_b8c = *(undefined2 *)(uVar14 + 0x24);
            cVar8 = func_0x(&uStack_b90);
            if (cVar8 == '\0') goto LAB_;
            func_0x(uVar14,&uStack_c68);
          }
          if ((uint)uStack_cf0 < (uint)uStack_c68) {
LAB_:
            lVar18 = *(longlong *)(lVar19 + 0x6b0);
            func_0x(&uStack_c68,asStack_130,auStack_bf0);
            func_0x(&piStack_ae0,asStack_100,auStack_bf0);
            if ((_DAT_ & 0x10000) != 0) {
              uStack_4b0 = 0x60000;
              uStack_4a8 = 0;
              ppuStack_4a0 = &puStack_488;
              puStack_498 = auStack_428;
              uStack_268 = 0;
              uStack_490 = 0;
              uStack_260 = 0;
              puStack_488 = &uStack_258;
              uStack_480 = 0x34;
              uStack_47c = 5;
              uStack_470 = 0x10;
              uStack_46c = 5;
              uStack_460 = 0x10;
              uStack_45c = 6;
              uStack_44c = 7;
              uStack_43c = 8;
              uStack_438 = 0;
              uStack_430 = 0;
              uStack_42c = 9;
              uStack_258 = (uint)*(ushort *)(lVar19 + 0x6b8);
              uStack_254 = *(undefined2 *)(piVar25 + 1);
              iStack_252 = *piVar25;
              uStack_24e = 0xff;
              uStack_24d = *(undefined *)(*puStack_d28 + 1);
              lStack_478 = lVar18 + 0x254;
              lStack_468 = lVar18 + 0x244;
              lVar19 = -1;
              do {
                lVar19 = lVar19 + 1;
              } while (asStack_130[lVar19] != 0);
              iStack_450 = (int)lVar19 * 2;
              psStack_458 = asStack_130;
              lVar19 = -1;
              do {
                lVar19 = lVar19 + 1;
              } while (asStack_100[lVar19] != 0);
              iStack_440 = (int)lVar19 * 2;
              psStack_448 = asStack_100;
              iVar11 = 0;
              uStack_bec = 0;
              puVar20 = (uint *)(**(code **)(_DAT_ + 0x10))(lVar18,&uStack_bec);
              ppuVar7 = ppuStack_4a0;
              if (puVar20 != (uint *)0x0) {
                lVar19 = -1;
                do {
                  lVar19 = lVar19 + 1;
                } while (*(short *)((longlong)puVar20 + lVar19 * 2) != 0);
                iVar11 = (int)lVar19 * 2;
              }
              ppuStack_4a0[10] = puVar20;
              *(int *)(ppuVar7 + 0xb) = iVar11;
              *(undefined4 *)((longlong)ppuVar7 + 0x5c) = 9;
              func_0x(auStack_4b8);
            }
          }
          else if ((uint)uStack_cf0 == (uint)uStack_c68) {
            uVar23 = (uint)((ulonglong)uStack_c68 >> 0x20);
            if ((uStack_cf0._4_4_ < uVar23) ||
               ((uStack_cf0._4_4_ == uVar23 && (uVar6 < uStack_c60)))) goto LAB_;
          }
          goto LAB_;
        }
      }
      if (*(longlong *)
           (*(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8) + 0x60) == *(longlong *)(lVar19 + 0x2120)) goto LAB_;
      cVar8 = func_0x(lVar19);
      if (cVar8 != '\0') goto LAB_;
      if (lVar18 == 0) {
        lVar18 = func_0x();
      }
      uVar14 = *puStack_d28;
      if (*(short *)(uVar14 + 0x24) == 0) {
LAB_:
        uStack_b40 = *(undefined8 *)(uVar14 + 0x28);
        uStack_b38 = *(undefined2 *)(uVar14 + 0x30);
      }
      else {
        cVar8 = *(char *)(uVar14 + 1);
        if (cVar8 == '\v') {
          if (*(int *)(uVar14 + 0x18) != 99) {
LAB_:
            if (cVar8 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar8 != '\b') goto LAB_;
LAB_:
          if (*(int *)(uVar14 + 0x18) != 99) goto LAB_;
        }
        uStack_b98 = *(undefined4 *)(uVar14 + 0x20);
        uStack_b94 = *(undefined2 *)(uVar14 + 0x24);
        cVar8 = func_0x(&uStack_b98);
        if (cVar8 == '\0') goto LAB_;
        func_0x(uVar14,&uStack_b40);
      }
      puVar22 = puStack_d28;
      if (puStack_d28 != (ulonglong *)0x0) {
        iVar11 = (int)(short)uStack_d1c;
        if (((*(ushort *)((longlong)puStack_d28 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
          if (((byte)*(undefined2 *)((longlong)puStack_d28 + 0x62) >> 3 & 1) != 0) {
            if (iVar11 == 3) {
              iVar11 = 4;
            }
            else if (iVar11 < 2) goto LAB_;
            if ((((*(uint *)((longlong)puStack_d28 + 100) & 8) != 0) &&
                (uVar14 = puStack_d28[0x12], uVar14 != 0)) && (*(longlong *)(uVar14 + 0x758) != 0))
            {
              func_0x(*(undefined8 *)(uVar14 + 0x758),puStack_d28,iVar11);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)puVar22 + 100) & 8) != 0)) &&
             ((2 < iVar11 &&
              (((*(uint *)((longlong)puVar22 + 100) & 0xc0000000) != 0x40000000 && (*puVar22 != 0)))
              ))) {
            iVar13 = (*_DAT_)(*puVar22,0x2000,2,auStack_a9c);
            if (iVar13 != 0) {
              LOCK();
              *(uint *)((longlong)puVar22 + 100) = *(uint *)((longlong)puVar22 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)puVar22 + 100) = *(uint *)((longlong)puVar22 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          func_0x(puVar22 + 0x13,iVar11);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            func_0x(puVar22,0,iVar11);
          }
          uStack_d1c = uStack_d1c & 0xffff0000;
          puStack_d28 = (ulonglong *)0x0;
        }
        else {
          func_0x(&puStack_d28);
        }
      }
      uStack_af0 = uStack_b40;
      uStack_ae8 = uStack_b38;
      uStack_d78 = (ulonglong **)0x0;
      func_0x(*(undefined8 *)(lVar19 + 0x728),&uStack_af0,4);
    } while( true );
  }
  ppuVar29 = &puStack_d28;
  iVar11 = *(int *)(plVar33 + 0x1ea);
  uVar14 = (ulonglong)uStack_be4;
  uVar23 = uStack_be4;
  goto LAB_;
LAB_:
  uVar14 = uStack_c70;
  uVar21 = 2;
  if (1 < *(int *)(plVar33 + 3) + 1U) {
    uVar21 = 0;
  }
  uStack_b70 = *(uint *)(uStack_c70 + 0x20);
  uStack_b6c = *(undefined2 *)(uStack_c70 + 0x24);
  uStack_d68 = (int *)plVar33[1];
  uStack_d70 = (undefined2 **)CONCAT44(uStack_d70._4_4_,uVar21);
  uStack_d78 = (ulonglong **)&uStack_b70;
  func_0x(&plStack_d08,plVar33[5] + 0x3c0,8);
  func_0x(&plStack_d08);
  goto LAB_;
LAB_:
  plVar33 = plStack_c78;
  lVar18 = -1;
  lVar19 = 0;
  uVar23 = (uint)(uVar10 >> 1);
  if (*(char *)(plStack_c78[8] + 0x1cdf) == '\0') {
    bVar9 = 0;
  }
  else if (*(char *)(plStack_c78[8] + 0x1cdc) == '\0') {
    bVar9 = 0;
  }
  else {
    bVar9 = *(byte *)(plStack_c78[5] + 0x109) >> 6 & 1;
  }
  iVar11 = uVar10 - uVar23;
  uStack_d60 = CONCAT71(uStack_d60._1_7_,bVar9);
  uStack_d68 = (int *)plStack_c78[1];
  uStack_d70._0_4_ = *(undefined4 *)((longlong)plStack_c78 + 0x1c);
  uStack_d78._0_4_ = iVar11;
  func_0x(&puStack_b30,plStack_c78[5] + 0x3c0,&puStack_d28,uVar23);
  uStack_d38 = 0;
  uStack_d40 = 0;
  uStack_d48 = 0;
  uStack_d50 = CONCAT44(uStack_d50._4_4_,4);
  lStack_d58 = 0;
  uStack_d60 = plVar33[1];
  uStack_d68 = (int *)((ulonglong)uStack_d68 & 0xffffffff00000000);
  uStack_d70 = (undefined2 **)CONCAT44(uStack_d70._4_4_,*(undefined4 *)((longlong)plVar33 + 0x1c));
  uStack_d78 = (ulonglong **)CONCAT44(uStack_d78._4_4_,iVar11);
  func_0x
            (&puStack_d28,(ulonglong)*(uint6 *)((longlong)plVar33 + 0x34) << 0x10,plVar33[5] + 0x3c0
            );
  if ((*(int *)(uStack_c70 + 0x10) != 0) ||
     (uVar14 = uStack_c70, *(short *)(uStack_c70 + 0x14) != 0)) {
    plStack_d08 = (longlong *)0x0;
    uStack_d00 = 0;
    uStack_cfc = 0;
    lVar15 = *(longlong *)(*plVar33 + 0x30);
    iStack_ce0 = *(int *)(uStack_c70 + 0x10);
    sStack_cdc = *(short *)(uStack_c70 + 0x14);
    uStack_a3c = 0;
    if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
      lVar3 = *(longlong *)
               ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
      ;
      if ((lVar3 != 0) && (lVar3 = **(longlong **)(lVar3 + 0x38), lVar3 != 0)) {
        iVar11 = (*_DAT_)(lVar3,0x337);
        if (iVar11 != 0) goto LAB_;
      }
      lVar3 = *(longlong *)
               ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
               + 8);
      if (lVar3 != 0) {
        lVar19 = *(longlong *)(lVar3 + 0x60);
      }
    }
LAB_:
    lVar3 = *(longlong *)(lVar15 + 0x728);
    do {
      plVar5 = plStack_d08;
      uStack_c84 = 0;
      if (plStack_d08 != (longlong *)0x0) {
        iVar11 = (int)(short)uStack_cfc;
        if (((*(ushort *)((longlong)plStack_d08 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
          if (((byte)*(undefined2 *)((longlong)plStack_d08 + 0x62) >> 3 & 1) != 0) {
            if (iVar11 == 3) {
              iVar11 = 4;
            }
            else if (iVar11 < 2) goto LAB_;
            if ((((*(uint *)((longlong)plStack_d08 + 100) & 8) != 0) &&
                (lVar32 = plStack_d08[0x12], lVar32 != 0)) && (*(longlong *)(lVar32 + 0x758) != 0))
            {
              func_0x(*(undefined8 *)(lVar32 + 0x758),plStack_d08,iVar11);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar5 + 100) & 8) != 0)) &&
             ((2 < iVar11 &&
              (((*(uint *)((longlong)plVar5 + 100) & 0xc0000000) != 0x40000000 && (*plVar5 != 0)))))
             ) {
            iVar13 = (*_DAT_)(*plVar5,0x2000,2,auStack_aa0);
            if (iVar13 != 0) {
              LOCK();
              *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          func_0x(plVar5 + 0x13,iVar11);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            func_0x(plVar5,0,iVar11);
          }
          uStack_cfc = uStack_cfc & 0xffff0000;
          plStack_d08 = (longlong *)0x0;
        }
        else {
          func_0x(&plStack_d08);
        }
      }
      if (*(longlong *)(lVar15 + 0x728) != 0) {
        func_0x(&plStack_d08,&iStack_ce0,lVar15);
        plVar5 = plStack_d08;
        if (plStack_d08 != (longlong *)0x0) {
          iVar11 = (int)(short)uStack_cfc;
          if (((*(ushort *)((longlong)plStack_d08 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
            if (((byte)*(undefined2 *)((longlong)plStack_d08 + 0x62) >> 3 & 1) != 0) {
              if (iVar11 == 3) {
                iVar11 = 4;
              }
              else if (iVar11 < 2) goto LAB_;
              if ((((*(uint *)((longlong)plStack_d08 + 100) & 8) != 0) &&
                  (lVar32 = plStack_d08[0x12], lVar32 != 0)) && (*(longlong *)(lVar32 + 0x758) != 0)
                 ) {
                func_0x(*(undefined8 *)(lVar32 + 0x758),plStack_d08,iVar11);
              }
            }
LAB_:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar5 + 100) & 8) != 0)) &&
               ((2 < iVar11 &&
                (((*(uint *)((longlong)plVar5 + 100) & 0xc0000000) != 0x40000000 && (*plVar5 != 0)))
                ))) {
              iVar13 = (*_DAT_)(*plVar5,0x2000,2,auStack_aa4);
              if (iVar13 != 0) {
                LOCK();
                *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) & 0x3fffffff;
                UNLOCK();
                LOCK();
                *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) | 0x40000000;
                UNLOCK();
              }
            }
            func_0x(plVar5 + 0x13,iVar11);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              func_0x(plVar5,0,iVar11);
            }
            uStack_cfc = uStack_cfc & 0xffff0000;
            plStack_d08 = (longlong *)0x0;
          }
          else {
            func_0x(&plStack_d08);
          }
        }
      }
      func_0x(lVar15,&iStack_ce0);
      uStack_d70 = (undefined2 **)&uStack_a40;
      uStack_d78 = (ulonglong **)CONCAT44(uStack_d78._4_4_,4);
      plStack_d08 = (longlong *)
                    func_0x(_DAT_,lVar15,&iStack_ce0,&uStack_c84);
      if (lVar19 != 0) {
        uVar14 = (ulonglong)(*(uint *)(lVar19 + 0x500) & 0xf);
        if (*(longlong *)(lVar19 + 0x508 + uVar14 * 8) != *plStack_d08) {
          *(longlong *)(lVar19 + 0x508 + uVar14 * 8) = *plStack_d08;
          *(longlong *)(lVar19 + 0x500) = *(longlong *)(lVar19 + 0x500) + 1;
        }
      }
      uStack_cfc = (uStack_c84 >> 3 & 1) << 0x18 | uStack_cfc & 0xff0004 | 4;
      uStack_cf8 = uStack_c84 >> 4 & 1 | uStack_cf8 & 0xffffff00;
      if (((lVar3 != 0) && (lVar19 != 0)) && (lVar19 == *(longlong *)(lVar15 + 0x1c38))) {
        *(longlong *)(lVar3 + 0x5b28) = *(longlong *)(lVar3 + 0x5b28) + 1;
        if ((int)uStack_a3c != 0) {
          *(longlong *)(lVar3 + 0x5b30) = *(longlong *)(lVar3 + 0x5b30) + 1;
          *(longlong *)(lVar3 + 0x5b38) = *(longlong *)(lVar3 + 0x5b38) + (ulonglong)uStack_a40;
          if (0xffffff < uStack_cfc) {
            *(longlong *)(lVar3 + 0x5b40) = *(longlong *)(lVar3 + 0x5b40) + 1;
            *(longlong *)(lVar3 + 0x5b48) = *(longlong *)(lVar3 + 0x5b48) + (ulonglong)uStack_a40;
          }
        }
      }
      cVar8 = func_0x(lVar15);
      iVar11 = 0;
      if (((cVar8 == '\0') || (*(char *)(lVar15 + 0x2050) == '\0')) ||
         ((iStack_ce0 == 0 || ((iStack_ce0 == 9 && (sStack_cdc == 1)))))) goto LAB_;
      lVar32 = *plStack_d08;
      if (*(short *)(lVar32 + 0x24) == 0) {
LAB_:
        uStack_c38 = *(undefined8 *)(lVar32 + 0x28);
        uStack_c30 = *(ushort *)(lVar32 + 0x30);
      }
      else {
        cVar8 = *(char *)(lVar32 + 1);
        if (cVar8 == '\v') {
          if (*(int *)(lVar32 + 0x18) != 99) {
LAB_:
            if (cVar8 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar8 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar32 + 0x18) != 99) goto LAB_;
        }
        uStack_b88 = *(undefined4 *)(lVar32 + 0x20);
        uStack_b84 = *(undefined2 *)(lVar32 + 0x24);
        cVar8 = func_0x(&uStack_b88);
        if (cVar8 == '\0') goto LAB_;
        func_0x(lVar32,&uStack_c38);
      }
      uVar23 = *(uint *)(lVar15 + 0x2108);
      do {
        uVar12 = uVar23 & 0xfffffffe;
        uStack_cf0 = *(int **)(lVar15 + 0x20fc);
        uStack_ce8 = *(undefined4 *)(lVar15 + 0x2104);
        LOCK();
        UNLOCK();
        uVar23 = *(uint *)(lVar15 + 0x2108);
      } while (uVar12 != uVar23);
      if ((uint)uStack_c38 <= (uint)uStack_cf0) {
        if ((uint)uStack_cf0 == (uint)uStack_c38) {
          uVar23 = (uint)((ulonglong)uStack_cf0 >> 0x20);
          if ((uVar23 < uStack_c38._4_4_) ||
             ((uVar23 == uStack_c38._4_4_ && ((ushort)uStack_ce8 < uStack_c30)))) goto LAB_;
        }
        goto LAB_;
      }
LAB_:
      if ((*(char *)(lVar15 + 0x6ac8) == '\0') &&
         (*(longlong *)
           (*(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8) + 0x60) != *(longlong *)(lVar15 + 0x2120))) {
        cVar8 = func_0x(lVar15);
        if (cVar8 == '\0') {
          uVar23 = *(uint *)(lVar15 + 0x2108);
          do {
            uVar12 = uVar23 & 0xfffffffe;
            uStack_cf0 = *(int **)(lVar15 + 0x20fc);
            uStack_ce8 = *(undefined4 *)(lVar15 + 0x2104);
            LOCK();
            UNLOCK();
            uVar23 = *(uint *)(lVar15 + 0x2108);
          } while (uVar12 != uVar23);
          uVar10 = (ushort)uStack_ce8;
          uStack_b08 = (ushort)uStack_ce8;
          lVar19 = *plStack_d08;
          piStack_b10 = uStack_cf0;
          if (*(short *)(lVar19 + 0x24) == 0) {
LAB_:
            uStack_c48 = *(undefined8 *)(lVar19 + 0x28);
            uStack_c40 = *(ushort *)(lVar19 + 0x30);
          }
          else {
            cVar8 = *(char *)(lVar19 + 1);
            if (cVar8 == '\v') {
              if (*(int *)(lVar19 + 0x18) != 99) {
LAB_:
                if (cVar8 != '\t') goto LAB_;
                goto LAB_;
              }
            }
            else {
              if (cVar8 != '\b') goto LAB_;
LAB_:
              if (*(int *)(lVar19 + 0x18) != 99) goto LAB_;
            }
            uStack_b78 = *(undefined4 *)(lVar19 + 0x20);
            uStack_b74 = *(undefined2 *)(lVar19 + 0x24);
            cVar8 = func_0x(&uStack_b78);
            if (cVar8 == '\0') goto LAB_;
            func_0x(lVar19,&uStack_c48);
          }
          if ((uint)uStack_cf0 < (uint)uStack_c48) {
LAB_:
            lVar19 = *(longlong *)(lVar15 + 0x6b0);
            func_0x(&uStack_c48,asStack_d0,auStack_b68);
            func_0x(&piStack_b10,asStack_a0,auStack_b68);
            if ((_DAT_ & 0x10000) != 0) {
              uStack_9f0 = 0x60000;
              uStack_9e8 = 0;
              ppuStack_9e0 = &puStack_9c8;
              puStack_9d8 = auStack_968;
              uStack_7a8 = 0;
              uStack_9d0 = 0;
              uStack_7a0 = 0;
              puStack_9c8 = &uStack_798;
              uStack_9c0 = 0x34;
              uStack_9bc = 5;
              uStack_9b0 = 0x10;
              uStack_9ac = 5;
              uStack_9a0 = 0x10;
              uStack_99c = 6;
              uStack_98c = 7;
              uStack_97c = 8;
              uStack_978 = 0;
              uStack_970 = 0;
              uStack_96c = 9;
              uStack_798 = (uint)*(ushort *)(lVar15 + 0x6b8);
              sStack_794 = sStack_cdc;
              iStack_792 = iStack_ce0;
              uStack_78e = 0xff;
              uStack_78d = *(undefined *)(*plStack_d08 + 1);
              lStack_9b8 = lVar19 + 0x254;
              lStack_9a8 = lVar19 + 0x244;
              lVar15 = lVar18;
              do {
                lVar15 = lVar15 + 1;
              } while (asStack_d0[lVar15] != 0);
              iStack_990 = (int)lVar15 * 2;
              psStack_998 = asStack_d0;
              lVar15 = lVar18;
              do {
                lVar15 = lVar15 + 1;
              } while (asStack_a0[lVar15] != 0);
              iStack_980 = (int)lVar15 * 2;
              psStack_988 = asStack_a0;
              uStack_be8 = 0;
              puVar20 = (uint *)(**(code **)(_DAT_ + 0x10))(lVar19,&uStack_be8);
              ppuVar7 = ppuStack_9e0;
              if (puVar20 != (uint *)0x0) {
                do {
                  lVar18 = lVar18 + 1;
                } while (*(short *)((longlong)puVar20 + lVar18 * 2) != 0);
                iVar11 = (int)lVar18 * 2;
              }
              ppuStack_9e0[10] = puVar20;
              *(int *)(ppuVar7 + 0xb) = iVar11;
              *(undefined4 *)((longlong)ppuVar7 + 0x5c) = 9;
              func_0x(auStack_9f8);
            }
          }
          else if ((uint)uStack_cf0 == (uint)uStack_c48) {
            uVar23 = (uint)((ulonglong)uStack_c48 >> 0x20);
            if ((uStack_cf0._4_4_ < uVar23) ||
               ((uStack_cf0._4_4_ == uVar23 && (uVar10 < uStack_c40)))) goto LAB_;
          }
          goto LAB_;
        }
      }
      if (*(longlong *)
           (*(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8) + 0x60) == *(longlong *)(lVar15 + 0x2120)) goto LAB_;
      cVar8 = func_0x(lVar15);
      if (cVar8 != '\0') goto LAB_;
      if (lVar19 == 0) {
        lVar19 = func_0x();
      }
      lVar32 = *plStack_d08;
      if (*(short *)(lVar32 + 0x24) == 0) {
LAB_:
        uStack_be0 = *(undefined8 *)(lVar32 + 0x28);
        uStack_bd8 = *(undefined2 *)(lVar32 + 0x30);
      }
      else {
        cVar8 = *(char *)(lVar32 + 1);
        if (cVar8 == '\v') {
          if (*(int *)(lVar32 + 0x18) != 99) {
LAB_:
            if (cVar8 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar8 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar32 + 0x18) != 99) goto LAB_;
        }
        uStack_b80 = *(undefined4 *)(lVar32 + 0x20);
        uStack_b7c = *(undefined2 *)(lVar32 + 0x24);
        cVar8 = func_0x(&uStack_b80);
        if (cVar8 == '\0') goto LAB_;
        func_0x(lVar32,&uStack_be0);
      }
      plVar5 = plStack_d08;
      if (plStack_d08 != (longlong *)0x0) {
        iVar11 = (int)(short)uStack_cfc;
        if (((*(ushort *)((longlong)plStack_d08 + 0x62) >> 10 & 1) == 0) || (iVar11 < 3)) {
          if (((byte)*(undefined2 *)((longlong)plStack_d08 + 0x62) >> 3 & 1) != 0) {
            if (iVar11 == 3) {
              iVar11 = 4;
            }
            else if (iVar11 < 2) goto LAB_;
            if ((((*(uint *)((longlong)plStack_d08 + 100) & 8) != 0) &&
                (lVar32 = plStack_d08[0x12], lVar32 != 0)) && (*(longlong *)(lVar32 + 0x758) != 0))
            {
              func_0x(*(undefined8 *)(lVar32 + 0x758),plStack_d08,iVar11);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar5 + 100) & 8) != 0)) &&
             ((2 < iVar11 &&
              (((*(uint *)((longlong)plVar5 + 100) & 0xc0000000) != 0x40000000 && (*plVar5 != 0)))))
             ) {
            iVar13 = (*_DAT_)(*plVar5,0x2000,2,auStack_a80);
            if (iVar13 != 0) {
              LOCK();
              *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          func_0x(plVar5 + 0x13,iVar11);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            func_0x(plVar5,0,iVar11);
          }
          uStack_cfc = uStack_cfc & 0xffff0000;
          plStack_d08 = (longlong *)0x0;
        }
        else {
          func_0x(&plStack_d08);
        }
      }
      uStack_ad0 = uStack_be0;
      uStack_ac8 = uStack_bd8;
      uStack_d78 = (ulonglong **)0x0;
      func_0x(*(undefined8 *)(lVar15 + 0x728),&uStack_ad0,4);
    } while( true );
  }
LAB_:
  iVar11 = *(int *)(plVar33 + 0x1ea);
  ppuVar29 = &puStack_b30;
  if (iVar11 != 0) {
    ppuVar29 = &puStack_d28;
  }
  puVar22 = *ppuVar29;
  uVar23 = 1;
LAB_:
  uVar34 = uStack_cd8;
  uVar12 = 1;
  if (iVar11 == 0) {
    uVar27 = (uint)*(ushort *)(*puVar22 + 0x16);
  }
  else {
    uVar27 = uVar12;
    if ((*(int *)(puVar22 + 0xe) == *piStack_b60) &&
       (*(short *)((longlong)puVar22 + 0x74) == *(short *)(piStack_b60 + 1))) {
      uVar27 = 0;
    }
  }
  uStack_a18 = 0;
  uStack_cc4 = 0;
  uStack_caa = 0;
  uStack_ca0 = 0;
  uStack_c9e = 0;
  uStack_cb8 = 0;
  pbStack_cc0 = (byte *)((longlong)plVar33 + 0xdc);
  bVar9 = *pbStack_cc0;
  if ((bVar9 & 1) == 0) {
    uStack_cc8 = 0;
    uStack_ca2 = 0;
    uStack_ca0 = 0;
    uVar24 = *(uint *)(plVar33 + 0x168);
    switch(bVar9 & 0xe) {
    default:
      uVar24 = (uint)*(ushort *)((longlong)plVar33 + 0xde);
      if (0x1f9d < uVar24 - 1) {
        func_0x(pbStack_cc0,6);
      }
      break;
    case 4:
      uVar24 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar24 = uVar12;
    }
    uStack_cb8 = CONCAT44(uStack_cb8._4_4_,uVar24);
  }
  else {
    uStack_cc8 = 1;
    switch(bVar9 & 0x1c) {
    default:
      if ((char)*(byte *)((longlong)plVar33 + 0xdd) < '\0') {
        uStack_cc6 = (*(ushort *)((longlong)plVar33 + 0xdd) & 0x7f) << 8 |
                     *(ushort *)((longlong)plVar33 + 0xdd) >> 8;
        uVar10 = 3;
        uStack_c80 = CONCAT22(uStack_c80._2_2_,3);
      }
      else {
        uStack_cc6 = (ushort)*(byte *)((longlong)plVar33 + 0xdd);
        uVar10 = 2;
      }
      sStack_cac = (short)(uStack_cc6 + 1 >> 1) + (short)uStack_c80;
      if (uStack_cc6 < 0x1f) {
        uStack_cb0 = (uint)uVar10;
        uStack_c98 = 0;
      }
      else {
        iVar11 = uStack_cc6 - 1;
        uStack_cb0 = CONCAT22(((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                              (short)((longlong)iVar11 * 0x88888889 >> 0x3f),uVar10);
        uStack_c98 = 0;
      }
      break;
    case 4:
      if (((bVar9 & 0x1c) == 4) && ((bVar9 & 2) != 0)) {
        uStack_cb0 = 0;
        uStack_cc6 = 0;
        sStack_cac = 0;
        uStack_ca2 = 0;
        uStack_cc4 = 0xf;
        uStack_c98 = 1;
      }
      else {
        uStack_cb0 = 0;
        uStack_cc6 = 0;
        sStack_cac = 0;
        uStack_ca2 = 0;
        uStack_cc4 = 1;
        uStack_c98 = 0;
      }
      break;
    case 8:
      uStack_cb0 = 0;
      uStack_cc6 = 0;
      sStack_cac = 0;
      uStack_ca2 = 0;
      uStack_cc4 = 9;
      uStack_c98 = 0;
    }
  }
  puStack_a20 = &uStack_cc8;
  lStack_d58 = plVar33[1];
  uStack_d40 = 0;
  uStack_d48 = uStack_d48 & 0xffffffff00000000;
  uStack_d50 = 0;
  uStack_d60 = CONCAT44(uStack_d60._4_4_,(uint)(*(byte *)(plVar33[5] + 0x107) >> 6)) &
               0xffffffff00000001;
  uStack_d68 = (int *)CONCAT44(uStack_d68._4_4_,*(undefined4 *)((longlong)plVar33 + 0x1c));
  uStack_d70 = &puStack_a20;
  uStack_d78 = (ulonglong **)CONCAT44(uStack_d78._4_4_,1);
  func_0x
            (ppuVar29,(ulonglong)*(uint6 *)((longlong)plVar33 + 0x34) << 0x10,plVar33[5] + 0x3c0,
             uVar27);
  if (uVar23 != 0) {
    func_0x(plVar33,uVar14);
  }
  *(undefined *)(uVar34 + 0x2c9) = 0;
  uStack_ab0 = 0;
code_r0x00103a3a:
  func_0x(&puStack_b30);
  func_0x(&puStack_d28);
  func_0x(uStack_40 ^ (ulonglong)auStack_d98);
  return;
}

