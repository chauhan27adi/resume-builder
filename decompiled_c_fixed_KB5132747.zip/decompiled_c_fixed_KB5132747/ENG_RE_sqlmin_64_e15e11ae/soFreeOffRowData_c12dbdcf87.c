
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2)

{
  byte *pbVar1;
  byte bVar2;
  bool bVar3;
  char cVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  short *psVar8;
  longlong lVar9;
  uint *puVar10;
  longlong lVar11;
  undefined8 uVar12;
  uint *puVar13;
  uint *puVar14;
  undefined4 uVar15;
  ulonglong uVar16;
  uint uVar17;
  byte **ppbVar18;
  byte *pbVar19;
  ulonglong uVar20;
  uint uVar21;
  byte **ppbVar22;
  ushort uVar23;
  ushort uVar24;
  short sVar25;
  uint uVar26;
  longlong lVar27;
  uint uVar28;
  longlong lVar29;
  ushort *puVar30;
  ushort *puVar31;
  undefined auStack_1d8 [32];
  uint *puStack_1b8;
  undefined4 uStack_1b0;
  uint *puStack_1a8;
  uint uStack_1a0;
  uint uStack_198;
  uint uStack_194;
  uint uStack_190;
  undefined4 uStack_18c;
  uint *puStack_188;
  uint uStack_180;
  uint uStack_17c;
  uint uStack_178;
  uint uStack_174;
  int iStack_170;
  longlong lStack_168;
  ushort *puStack_160;
  undefined8 uStack_158;
  undefined2 uStack_150;
  undefined4 uStack_148;
  undefined2 uStack_144;
  longlong lStack_140;
  longlong lStack_138;
  undefined4 uStack_130;
  undefined auStack_128 [8];
  undefined auStack_120 [8];
  longlong lStack_118;
  longlong *plStack_110;
  longlong lStack_108;
  longlong lStack_100;
  longlong lStack_f8;
  short sStack_f0;
  ushort uStack_ee;
  uint uStack_ec;
  uint *puStack_e8;
  undefined8 uStack_e0;
  undefined4 uStack_d8;
  ushort uStack_d4;
  undefined2 uStack_d2;
  undefined6 uStack_d0;
  undefined2 uStack_ca;
  undefined2 uStack_c8;
  ushort uStack_c6;
  ushort uStack_c4;
  undefined2 uStack_c2;
  undefined4 uStack_c0;
  uint uStack_bc;
  undefined auStack_b8 [16];
  undefined auStack_a8 [8];
  undefined8 uStack_a0;
  undefined8 uStack_98;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined6 uStack_88;
  undefined2 uStack_82;
  undefined8 uStack_80;
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  undefined auStack_58 [16];
  undefined8 uStack_48;
  ulonglong uStack_40;
  
  uStack_40 = _DAT_ ^ (ulonglong)auStack_1d8;
  plStack_110 = *(longlong **)(param_1 + 0x60);
  lVar11 = *param_2;
  iStack_170 = -1;
  lVar29 = *(longlong *)(*plStack_110 + 0x58);
  sStack_f0 = -1;
  puStack_e8 = (uint *)0x0;
  uStack_ec = 0;
  uStack_d2 = 0;
  uStack_d0 = 0;
  uStack_c8 = 0;
  uStack_c6 = 0;
  uStack_c4 = 0;
  uStack_c2 = 0;
  uStack_e0 = (byte **)0x0;
  uStack_bc = 0xffffffff;
  uStack_190 = 0;
  uStack_18c = (uint)(uStack_18c._2_2_ & 0xffe0) << 0x10;
  puStack_188 = (uint *)0x0;
  uVar24 = *(ushort *)(lVar11 + 0x16);
  uStack_180 = (uVar24 != 0) - 1;
  lStack_168 = lVar29;
  lStack_f8 = lVar11;
  if ((int)uStack_180 < (int)(uint)uVar24) {
    lVar27 = (longlong)(int)uStack_180;
    uStack_174 = uStack_178;
    do {
      ppbVar22 = (byte **)0x0;
      uVar7 = uStack_180;
      if ((uStack_180 < uVar24) && (*(short *)(lVar11 + (0xfff - lVar27) * 2) != 0)) {
        lStack_140 = lVar27;
        uStack_bc = uStack_180;
        if (*(char *)(lVar11 + 2) < '\0') {
          pbVar1 = (byte *)(lVar11 + 0x60);
          if ((sStack_f0 == 0) || (ppbVar18 = uStack_e0, uStack_e0 == (byte **)0x0)) {
            ppbVar18 = (byte **)auStack_b8;
            uStack_90 = 0;
            stack0xffffffffffffff5a = SUB1614(ZEXT816(0),2);
            auStack_a8._0_2_ = 0xffff;
            uStack_82 = 0;
            uStack_a0 = 0;
            uStack_8a = 0;
            uStack_88 = 0;
            uStack_80 = 0;
            uStack_98 = 0;
            auStack_78 = ZEXT816(0);
            auStack_58._0_12_ = ZEXT812(0);
            auStack_58._12_4_ = 0;
            uStack_48 = 0;
            auStack_68 = ZEXT816(0);
            auStack_b8 = ZEXT816(0);
          }
          if (*(short *)(lVar11 + 0x24) == 0) {
LAB_:
            uStack_158 = *(undefined8 *)(lVar11 + 0x28);
            uStack_150 = *(undefined2 *)(lVar11 + 0x30);
          }
          else {
            cVar4 = *(char *)(lVar11 + 1);
            if (cVar4 == '\v') {
              if (*(int *)(lVar11 + 0x18) != 99) {
LAB_:
                if (cVar4 != '\t') goto LAB_;
                goto LAB_;
              }
            }
            else {
              if (cVar4 != '\b') goto LAB_;
LAB_:
              if (*(int *)(lVar11 + 0x18) != 99) goto LAB_;
            }
            uStack_148 = *(undefined4 *)(lVar11 + 0x20);
            uStack_144 = *(undefined2 *)(lVar11 + 0x24);
            cVar4 = func_0x(&uStack_148);
            if (cVar4 == '\0') goto LAB_;
            func_0x(lVar11,&uStack_158);
          }
          *ppbVar18 = pbVar1;
          *(undefined4 *)(ppbVar18 + 0xc) = (undefined4)uStack_158;
          *(undefined2 *)(ppbVar18 + 0xd) = uStack_150;
          *(int *)((longlong)ppbVar18 + 100) = (int)((ulonglong)uStack_158 >> 0x20);
          *(undefined4 *)((longlong)ppbVar18 + 0x6c) = *(undefined4 *)(lVar11 + 0x20);
          *(undefined2 *)(ppbVar18 + 0xe) = *(undefined2 *)(lVar11 + 0x24);
          *(undefined2 *)((longlong)ppbVar18 + 0x72) = 0;
          uStack_130 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x1085590);
          uVar20 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x1085594);
          *(undefined2 *)(ppbVar18 + 2) = 0xffff;
          ppbVar18[3] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar18 + 0x14) = 0;
          *(undefined8 *)((longlong)ppbVar18 + 0x2e) = 0;
          ppbVar18[7] = (byte *)0x0;
          ppbVar18[4] = (byte *)0x0;
          ppbVar18[9] = (byte *)0x0;
          ppbVar18[10] = (byte *)0x0;
          *(undefined2 *)(ppbVar18 + 0xb) = 0;
          if ((**ppbVar18 & 2) != 0) {
            pbVar19 = pbVar1 + uVar20;
            if ((pbVar1[uVar20] & 1) == 0) {
              *(undefined2 *)(ppbVar18 + 2) = 0;
              *(undefined4 *)((longlong)ppbVar18 + 0x14) = 0;
              *(undefined4 *)((longlong)ppbVar18 + 0x36) = 0;
              ppbVar18[3] = pbVar19;
              switch(*pbVar19 & 0xe) {
              default:
                ppbVar22 = (byte **)(ulonglong)*(ushort *)(pbVar19 + 2);
                if (0x1f9d < *(ushort *)(pbVar19 + 2) - 1) {
                  func_0x(pbVar19,6);
                }
                break;
              case 4:
                ppbVar22 = (byte **)0x9;
                break;
              case 6:
              case 10:
                break;
              case 0xe:
                ppbVar22 = (byte **)0x1;
              }
              *(int *)(ppbVar18 + 4) = (int)ppbVar22;
              *(undefined8 *)((longlong)ppbVar18 + 0x2e) = 0;
            }
            else {
              *(undefined2 *)(ppbVar18 + 2) = 1;
              ppbVar18[3] = pbVar19;
              bVar2 = *pbVar19;
              switch(bVar2 & 0x1c) {
              default:
                if ((char)pbVar19[1] < '\0') {
                  uVar24 = *(ushort *)(pbVar19 + 1);
                  sVar25 = 3;
                  *(ushort *)((longlong)ppbVar18 + 0x12) = uVar24;
                  uVar24 = (uVar24 & 0x7f) << 8 | uVar24 >> 8;
                }
                else {
                  sVar25 = 2;
                  uVar24 = (ushort)pbVar19[1];
                }
                *(ushort *)((longlong)ppbVar18 + 0x12) = uVar24;
                *(short *)(ppbVar18 + 5) = sVar25;
                uVar24 = *(ushort *)((longlong)ppbVar18 + 0x12);
                *(short *)((longlong)ppbVar18 + 0x2c) = (short)(uVar24 + 1 >> 1) + sVar25;
                if (uVar24 < 0x1f) {
                  *(undefined2 *)((longlong)ppbVar18 + 0x2a) = 0;
                  *(undefined4 *)((longlong)ppbVar18 + 0x14) = 0;
                  *(undefined4 *)(ppbVar18 + 8) = 0;
                  ppbVar18[7] = (byte *)0x0;
                  ppbVar18[4] = (byte *)0x0;
                }
                else {
                  iVar6 = uVar24 - 1;
                  *(short *)((longlong)ppbVar18 + 0x2a) =
                       ((short)(iVar6 / 0x1e) + (short)(iVar6 >> 0x1f)) -
                       (short)((longlong)iVar6 * 0x88888889 >> 0x3f);
                  *(undefined4 *)((longlong)ppbVar18 + 0x14) = 0;
                  *(undefined4 *)(ppbVar18 + 8) = 0;
                  ppbVar18[7] = (byte *)0x0;
                  ppbVar18[4] = (byte *)0x0;
                }
                break;
              case 4:
                if (((bVar2 & 0x1c) != 4) || (bVar3 = true, (bVar2 & 2) == 0)) {
                  bVar3 = false;
                }
                if (!bVar3) {
                  uVar15 = 1;
                }
                else {
                  *(undefined4 *)(ppbVar18 + 8) = 0;
                  uVar15 = 0xf;
                }
                ppbVar18[5] = (byte *)0x0;
                *(undefined2 *)((longlong)ppbVar18 + 0x12) = 0;
                ppbVar18[6] = (byte *)0x0;
                ppbVar18[4] = (byte *)0x0;
                ppbVar18[7] = (byte *)0x0;
                ppbVar18[3] = pbVar19;
                *(undefined4 *)((longlong)ppbVar18 + 0x14) = uVar15;
                *(uint *)(ppbVar18 + 8) = (uint)bVar3;
                ppbVar18[7] = (byte *)0x0;
                ppbVar18[4] = (byte *)0x0;
                break;
              case 8:
                ppbVar18[7] = (byte *)0x0;
                ppbVar18[7] = (byte *)0x0;
                ppbVar18[5] = (byte *)0x0;
                *(undefined2 *)((longlong)ppbVar18 + 0x12) = 0;
                ppbVar18[6] = (byte *)0x0;
                ppbVar18[4] = (byte *)0x0;
                ppbVar18[3] = pbVar19;
                *(undefined4 *)((longlong)ppbVar18 + 0x14) = 9;
                *(undefined4 *)(ppbVar18 + 8) = 0;
                ppbVar18[4] = (byte *)0x0;
              }
            }
          }
          if ((**ppbVar18 & 4) != 0) {
            if (uStack_130._2_2_ != 0) {
              uVar20 = (ulonglong)*(ushort *)(lVar11 + 0x61 + (longlong)uStack_130._2_2_ * 2);
            }
            psVar8 = (short *)(pbVar1 + uVar20);
            ppbVar18[9] = (byte *)psVar8;
            sVar25 = *psVar8;
            ppbVar18[10] = (byte *)(psVar8 + 1);
            *(short *)(ppbVar18 + 0xb) = (sVar25 + 1) * 2;
          }
          ppbVar22 = ppbVar18;
          lVar29 = lStack_168;
          if (ppbVar18[1] != (byte *)0x0) {
            func_0x(ppbVar18[1],ppbVar18);
            lVar29 = lStack_168;
          }
        }
        uVar7 = uStack_180;
        puStack_e8 = (uint *)((ulonglong)*(ushort *)(lVar11 + (0xfff - lVar27) * 2) + lVar11);
        if ((*(byte *)puStack_e8 & 1) == 0) {
          sStack_f0 = 0;
          uStack_ec = 0;
          uStack_ca = 0;
          uStack_c8 = 0;
          uVar5 = (uint)*(ushort *)(lVar11 + 0xe);
          switch(*(byte *)puStack_e8 & 0xe) {
          default:
            uVar5 = (uint)*(ushort *)((longlong)puStack_e8 + 2);
            if (0x1f9d < *(ushort *)((longlong)puStack_e8 + 2) - 1) {
              func_0x(puStack_e8,6);
            }
            break;
          case 4:
            uVar5 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar5 = 1;
          }
          uStack_e0 = (byte **)CONCAT44(uStack_e0._4_4_,uVar5);
          lVar9 = lVar11 + 0x2000;
          if (lVar11 == 0) {
            lVar9 = 0;
          }
          uStack_d2 = (undefined2)lVar9;
          uStack_d0 = (undefined6)((ulonglong)lVar9 >> 0x10);
        }
        else {
          sStack_f0 = 1;
          bVar2 = *(byte *)puStack_e8;
          switch(bVar2 & 0x1c) {
          default:
            if ((char)*(byte *)((longlong)puStack_e8 + 1) < '\0') {
              uStack_d8._0_2_ = 3;
              uStack_ee = (*(ushort *)((longlong)puStack_e8 + 1) & 0x7f) << 8 |
                          *(ushort *)((longlong)puStack_e8 + 1) >> 8;
            }
            else {
              uStack_ee = (ushort)*(byte *)((longlong)puStack_e8 + 1);
              uStack_d8._0_2_ = 2;
            }
            uStack_d4 = (short)(uStack_ee + 1 >> 1) + (short)uStack_d8;
            if (uStack_ee < 0x1f) {
              uStack_d8._2_2_ = 0;
              uStack_ec = 0;
              uStack_c0 = 0;
            }
            else {
              iVar6 = uStack_ee - 1;
              uStack_d8._2_2_ =
                   ((short)(iVar6 / 0x1e) + (short)(iVar6 >> 0x1f)) -
                   (short)((longlong)iVar6 * 0x88888889 >> 0x3f);
              uStack_ec = 0;
              uStack_c0 = 0;
            }
            break;
          case 4:
            if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
              uStack_ec = 0xf;
              uStack_d8._0_2_ = 0;
              uStack_d8._2_2_ = 0;
              uStack_d4 = 0;
              uStack_d2 = 0;
              uStack_ee = 0;
              uStack_d0 = 0;
              uStack_ca = 0;
              uStack_c0 = 1;
            }
            else {
              uStack_ec = 1;
              uStack_d8._0_2_ = 0;
              uStack_d8._2_2_ = 0;
              uStack_d4 = 0;
              uStack_d2 = 0;
              uStack_ee = 0;
              uStack_d0 = 0;
              uStack_ca = 0;
              uStack_c0 = 0;
            }
            break;
          case 8:
            uStack_ec = 9;
            uStack_d8._0_2_ = 0;
            uStack_d8._2_2_ = 0;
            uStack_d4 = 0;
            uStack_d2 = 0;
            uStack_ee = 0;
            uStack_d0 = 0;
            uStack_ca = 0;
            uStack_c0 = 0;
          }
          lVar9 = lVar11 + 0x2000;
          if (lVar11 == 0) {
            lVar9 = 0;
          }
          uStack_c8 = (undefined2)lVar9;
          uStack_c6 = (ushort)((ulonglong)lVar9 >> 0x10);
          uStack_c4 = (ushort)((ulonglong)lVar9 >> 0x20);
          uStack_c2 = (undefined2)((ulonglong)lVar9 >> 0x30);
          uStack_e0 = ppbVar22;
        }
        if (((*(byte *)puStack_e8 & 1) != 0) || ((*(byte *)puStack_e8 & 0x20) != 0)) {
          if (sStack_f0 == 0) {
            uVar5 = func_0x(&uStack_ee);
          }
          else {
            uVar5 = (uint)uStack_ee;
          }
          uStack_178 = 0;
          uStack_194 = uVar5;
          iVar6 = func_0x(&sStack_f0);
          lStack_108 = (longlong)(int)(iVar6 + uVar5);
          lVar27 = lStack_140;
          if (0 < lStack_108) {
            lStack_100 = (longlong)(int)uVar5;
            lStack_138 = 0;
            puVar10 = puStack_e8;
            uVar26 = 0;
            do {
              puVar14 = (uint *)0x0;
              if (lStack_138 < lStack_100) {
                uVar26 = ~uVar26;
                if ((uVar26 & 0xc0000000) == 0x80000000) {
                  puVar10 = (uint *)func_0x
                                              (**(undefined8 **)(*(longlong *)(lVar29 + 8) + 0x160),
                                               uVar26 & 0x1fffffff);
                }
                else {
                  puVar10 = (uint *)func_0x
                                              (*(undefined8 *)(*(longlong *)(lVar29 + 8) + 0x160));
                }
                uStack_190 = *puVar10;
                uStack_18c = puVar10[1];
                puStack_188 = *(uint **)(puVar10 + 2);
                iVar6 = func_0x(&sStack_f0,&uStack_190);
                puVar10 = puStack_e8;
                if (iVar6 != 0) {
                  if (sStack_f0 == 0) {
                    if ((uStack_190 & 0xc0000000) == 0x80000000) {
                      iVar6 = func_0x(&uStack_ee);
                      if (iVar6 == 0) goto code_r0x00101154;
                      puVar13 = (uint *)func_0x(&uStack_c6,&uStack_190,&uStack_198,
                                                        &puStack_160);
                      puVar10 = puStack_e8;
                      uVar7 = uStack_198;
                    }
                    else {
                      uVar24 = uStack_18c._2_2_ >> 4 & 1;
                      if (uVar24 == 0) {
code_r0x00100885:
                        if ((int)uStack_190 < 0) {
                          if (uStack_ec == 0) {
                            uStack_ee = 0;
                            uVar7 = (uint)uStack_e0;
                            if ((*(byte *)puStack_e8 & 0x10) != 0) {
                              uVar7 = (uint)uStack_e0 + 2 +
                                      (*(ushort *)
                                        (((ulonglong)uStack_e0 & 0xffffffff) + (longlong)puStack_e8)
                                       + 7 >> 3);
                            }
                            uStack_e0 = (byte **)CONCAT44(uVar7,(uint)uStack_e0);
                            if ((*(byte *)puStack_e8 & 0x20) == 0) {
                              uStack_d4 = 0;
                              uStack_ec = uVar7;
                            }
                            else {
                              puVar30 = (ushort *)((ulonglong)uVar7 + (longlong)puStack_e8);
                              uStack_d4 = *puVar30;
                              puStack_160 = puVar30;
                              if (uStack_d4 == 0) {
                                cVar4 = func_0x(0x199bd40);
                                if (cVar4 != '\0') {
                                  lVar11 = func_0x();
                                  if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                                    cVar4 = func_0x(0x199bd40);
                                    if (cVar4 == '\0') {
                                      (*pcRam0000000000f098c8)(0x22,0x44,0x15,0x3eb);
                                    }
                                    else {
                                      puStack_1b8 = (uint *)0x0;
                                      (*pcRam0000000000f098c0)(1,0x128b74c,0x13ab838,0x80f);
                                    }
                                  }
                                }
                                func_0x(puStack_e8,3);
                              }
                              uStack_d8 = uStack_e0._4_4_ + (uStack_d4 + 1) * 2;
                              if (0x1f9e < uStack_d8) {
                                cVar4 = func_0x(0x199bd40);
                                if (cVar4 != '\0') {
                                  lVar11 = func_0x();
                                  if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                                    cVar4 = func_0x(0x199bd40);
                                    if (cVar4 == '\0') {
                                      (*pcRam0000000000f098c8)(0x22,0x44,0x15,0x3ec);
                                    }
                                    else {
                                      puStack_1b8 = (uint *)0x0;
                                      (*pcRam0000000000f098c0)(1,0x128b74c,0x13ab838,0x816);
                                    }
                                  }
                                }
                                func_0x(puStack_e8,4);
                              }
                              uStack_ec = puVar30[uStack_d4] & 0x7fff;
                              if (uStack_ec < uStack_d8) {
                                cVar4 = func_0x(0x199bd40);
                                if (cVar4 != '\0') {
                                  lVar11 = func_0x();
                                  if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                                    cVar4 = func_0x(0x199bd40);
                                    if (cVar4 == '\0') {
                                      (*pcRam0000000000f098c8)(0x22,0x44,0x15,0x3ec);
                                    }
                                    else {
                                      puStack_1b8 = (uint *)0x0;
                                      (*pcRam0000000000f098c0)(1,0x128b74c,0x13ab838,0x81d);
                                    }
                                  }
                                }
                                func_0x(puStack_e8,4);
                              }
                              puVar10 = puStack_e8;
                              uVar7 = uStack_d8;
                              puVar31 = puVar30;
                              if (uStack_d4 != 0) {
                                do {
                                  puVar30 = puVar30 + 1;
                                  uVar5 = *puVar30 & 0x7fff;
                                  if ((uVar5 < uStack_d8) || (uStack_ec < uVar5)) {
                                    uStack_d8 = uVar7;
                                    cVar4 = func_0x(0x199bd40);
                                    if (cVar4 != '\0') {
                                      lVar11 = func_0x();
                                      if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                                        cVar4 = func_0x(0x199bd40);
                                        if (cVar4 == '\0') {
                                          (*pcRam0000000000f098c8)(0x22,0x44,0x15,0x3ec);
                                        }
                                        else {
                                          puStack_1b8 = (uint *)0x0;
                                          (*pcRam0000000000f098c0)(1,0x128b74c,0x13ab838,0x82a);
                                        }
                                      }
                                    }
                                    func_0x(puStack_e8,4);
                                    puVar10 = puStack_e8;
                                    uVar7 = uStack_d8;
                                  }
                                  uVar28 = (int)puVar14 + 1;
                                  puVar14 = (uint *)(ulonglong)uVar28;
                                  uStack_d8 = uVar5;
                                  puVar31 = puStack_160;
                                } while ((int)uVar28 < (int)(uint)uStack_d4);
                              }
                              while ((short)puVar31[(ulonglong)(uStack_d4 - 1) + 1] < 0) {
                                uVar5 = uVar7;
                                if (uStack_d4 != 1) {
                                  uVar5 = *(ushort *)
                                           ((longlong)puVar10 +
                                           (ulonglong)uStack_d4 * 2 +
                                           (((ulonglong)uStack_e0 >> 0x20) - 2)) & 0x7fff;
                                }
                                uVar28 = *(ushort *)
                                          ((longlong)puVar10 +
                                          (ulonglong)uStack_d4 * 2 + ((ulonglong)uStack_e0 >> 0x20))
                                         & 0x7fff;
                                if (((uVar5 < uVar7) || (uVar28 < uVar5)) || (uStack_ec < uVar28)) {
                                  uStack_d8 = uVar7;
                                  func_0x(puVar10,7);
                                  puVar10 = puStack_e8;
                                  uVar7 = uStack_d8;
                                }
                                uStack_d8 = uVar7;
                                if ((uVar5 < uVar7) || (uStack_ec < uVar5)) goto code_r0x00100fb2;
                                if (*(ushort *)((ulonglong)uVar5 + (longlong)puVar10) == 5) {
                                  uStack_ee = uStack_ee | 2;
                                  uStack_d4 = uStack_d4 - 1;
                                  uVar20 = (ulonglong)(uVar5 & 0xffff);
                                  pbVar1 = (byte *)((longlong)puVar10 + uVar20);
                                  uStack_c6 = (ushort)uVar5;
                                  if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                                    uVar24 = uStack_c4 & 0xc7ff;
                                  }
                                  else {
                                    uVar24 = uStack_c4 ^
                                             (*(ushort *)(pbVar1 + 2) ^ uStack_c4) & 0x3800;
                                  }
                                  uStack_c4 = (uVar24 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar24;
                                  uVar16 = (ulonglong)uStack_c4;
                                  pbVar19 = (byte *)((longlong)puVar10 +
                                                    uVar20 + ((uVar16 & 0x7ff) + 2) * 2 +
                                                             (ulonglong)((uVar24 >> 0xb & 7) * 2));
                                  if (pbVar19 < pbVar1) {
                                    func_0x(pbVar1,0x19);
                                    uVar16 = (ulonglong)uStack_c4;
                                    uVar20 = (ulonglong)uStack_c6;
                                    puVar10 = puStack_e8;
                                  }
                                  uVar7 = uStack_d8;
                                  if (uVar28 - uVar5 <
                                      (((uStack_c4 & 0x7ff) * 2 - (int)uVar20) - (int)puStack_e8) +
                                      (int)pbVar19) {
                                    func_0x((byte *)(uVar20 + (longlong)puVar10),0x19);
                                    uVar16 = (ulonglong)uStack_c4;
                                    uVar20 = (ulonglong)uStack_c6;
                                    puVar10 = puStack_e8;
                                    uVar7 = uStack_d8;
                                  }
                                  if ((uVar16 & 0x3800) != 0) {
                                    puVar30 = (ushort *)((longlong)puVar10 + uVar20 + 4);
                                    iVar6 = 0;
                                    if ((uVar16 & 0x3800) != 0) {
                                      do {
                                        if (((ushort)uVar16 & 0x7ff) < (*puVar30 & 0x7ff)) {
                                          uStack_d8 = uVar7;
                                          func_0x((byte *)(uVar20 + (longlong)puVar10),0x1a)
                                          ;
                                          uVar16 = (ulonglong)uStack_c4;
                                          uVar20 = (ulonglong)uStack_c6;
                                          puVar10 = puStack_e8;
                                          uVar7 = uStack_d8;
                                        }
                                        iVar6 = iVar6 + 1;
                                        puVar30 = puVar30 + 1;
                                      } while (iVar6 < (int)((uStack_c4 & 0x3800) >> 0xb));
                                    }
                                  }
                                  break;
                                }
                                if (*(ushort *)((ulonglong)uVar5 + (longlong)puVar10) < 0x400)
                                break;
                                uStack_ee = uStack_ee | 1;
                                uStack_d4 = uStack_d4 - 1;
                                if (uStack_d4 == 0) break;
                              }
                            }
                            if ((*(byte *)puVar10 & 0x40) == 0) {
                              uStack_ca = 0;
                              uStack_c8 = 0;
                            }
                            else {
                              uStack_ca = (undefined2)uStack_ec;
                              uStack_c8 = (undefined2)(uStack_ec >> 0x10);
                              uStack_ec = uStack_ec + 0xe;
                              uStack_d8 = uVar7;
                              uVar12 = func_0x(&uStack_ee);
                              func_0x(uVar12,auStack_128);
                              iVar6 = func_0x(auStack_128);
                              uStack_ec = uStack_ec + iVar6;
                              puVar10 = puStack_e8;
                              uVar7 = uStack_d8;
                            }
                            uStack_d8 = uVar7;
                            if (((byte *)CONCAT62(uStack_d0,uStack_d2) != (byte *)0x0) &&
                               ((byte *)CONCAT62(uStack_d0,uStack_d2) <
                                (byte *)((ulonglong)uStack_ec + (longlong)puVar10))) {
                              cVar4 = func_0x(0x199bd40);
                              if (cVar4 != '\0') {
                                lVar11 = func_0x();
                                if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                                  cVar4 = func_0x(0x199bd40);
                                  if (cVar4 == '\0') {
                                    (*pcRam0000000000f098c8)(0x22,0x44,0x15,0x3fa);
                                  }
                                  else {
                                    puStack_1b8 = (uint *)0x0;
                                    (*pcRam0000000000f098c0)(1,0x128b74c,0x13ab838,0x886);
                                  }
                                }
                              }
                              func_0x(puStack_e8,0x12);
                              puVar10 = puStack_e8;
                            }
                            if (0x3f3b < uStack_ec - 1) {
                              cVar4 = func_0x(0x199bd40);
                              if (cVar4 != '\0') {
                                lVar11 = func_0x();
                                if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                                  cVar4 = func_0x(0x199bd40);
                                  if (cVar4 == '\0') {
                                    (*pcRam0000000000f098c8)(0x22,0x44,0x15,0x3ed);
                                  }
                                  else {
                                    puStack_1b8 = (uint *)0x0;
                                    (*pcRam0000000000f098c0)(1,0x128b74c,0x13ab838,0x88b);
                                  }
                                }
                              }
                              func_0x(puStack_e8,5);
                              puVar10 = puStack_e8;
                            }
                          }
code_r0x00100fb2:
                          sVar25 = -(short)uStack_190;
                          lVar29 = lStack_168;
                          if ((uStack_18c & 0x100000) != 0) {
                            if ((*(byte *)puVar10 & 0x10) == 0) {
                              if ((1 << (*(byte *)puVar10 & 0xe) & 0x1105U) != 0)
                              goto code_r0x00101011;
                            }
                            else if (((int)(uint)uStack_e0 <= (int)uStack_190) ||
                                    (*(ushort *)
                                      (((ulonglong)uStack_e0 & 0xffffffff) + (longlong)puVar10) <
                                     (ushort)uStack_18c)) {
code_r0x00101011:
                              puVar13 = puStack_188 + 1;
                              uVar7 = *puStack_188;
                              goto code_r0x001019f0;
                            }
                          }
                          if ((uint)uStack_d4 < (uint)(int)sVar25) {
                            puVar13 = puVar10;
                            uVar7 = 0;
                          }
                          else {
                            puVar14 = puVar10;
                            uVar7 = uStack_d8;
                            if (sVar25 != 1) {
                              puVar14 = puStack_e8;
                              uVar7 = *(ushort *)
                                       ((longlong)puVar10 +
                                       (longlong)sVar25 * 2 + (((ulonglong)uStack_e0 >> 0x20) - 2))
                                      & 0x7fff;
                            }
                            uVar5 = *(ushort *)
                                     ((longlong)puVar10 +
                                     (longlong)sVar25 * 2 + ((ulonglong)uStack_e0 >> 0x20)) & 0x7fff
                            ;
                            if (((uVar7 < uStack_d8) || (uVar5 < uVar7)) || (uStack_ec < uVar5)) {
                              func_0x(puVar14,7);
                              puVar14 = puStack_e8;
                            }
                            puVar10 = puVar14;
                            puVar13 = (uint *)((ulonglong)uVar7 + (longlong)puVar14);
                            lVar29 = lStack_168;
                            uVar7 = uVar5 - uVar7;
                          }
                        }
                        else if ((uStack_18c & 0x80000) == 0) {
                          if (uVar24 == 0) {
code_r0x001008ba:
                            uStack_198 = 0x1f9e;
                            puVar13 = (uint *)((longlong)puStack_e8 + (longlong)(int)uStack_190);
                            uVar7 = uStack_198;
                          }
                          else {
                            if ((*(byte *)puStack_e8 & 0x10) == 0) {
                              if ((1 << (*(byte *)puStack_e8 & 0xe) & 0x1105U) == 0)
                              goto code_r0x001008ba;
                            }
                            else if (((int)uStack_190 < (int)(uint)uStack_e0) &&
                                    ((ushort)uStack_18c <=
                                     *(ushort *)
                                      (((ulonglong)uStack_e0 & 0xffffffff) + (longlong)puStack_e8)))
                            goto code_r0x001008ba;
                            uVar7 = *puStack_188;
                            puVar13 = puStack_188 + 1;
                            if (uVar7 != 0x1f9e) {
                              puStack_1b8 = (uint *)0x0;
                              (*pcRam0000000000f098c0)(1,0x1439b90,0x14384f8,0x381);
                              puVar10 = puStack_e8;
                            }
                          }
                        }
                        else {
                          uStack_198 = 1;
                          puVar13 = (uint *)0x10103e0;
                          uVar7 = uStack_198;
                          if ((*(byte *)((longlong)(int)uStack_190 + (longlong)puStack_e8) &
                              (byte)(1 << (uStack_18c._2_1_ & 7))) == 0) {
                            puVar13 = (uint *)0x10103e1;
                          }
                        }
                      }
                      else if ((*(byte *)puStack_e8 & 0x10) == 0) {
                        if ((1 << (*(byte *)puStack_e8 & 0xe) & 0x1105U) == 0)
                        goto code_r0x00100885;
                        puVar13 = puStack_188 + 1;
                        uVar7 = *puStack_188;
                      }
                      else {
                        if (((int)uStack_190 < (int)(uint)uStack_e0) &&
                           ((ushort)uStack_18c <=
                            *(ushort *)(((ulonglong)uStack_e0 & 0xffffffff) + (longlong)puStack_e8))
                           ) goto code_r0x00100885;
                        puVar13 = puStack_188 + 1;
                        uVar7 = *puStack_188;
                      }
                    }
                  }
                  else {
                    puStack_1b8 = &uStack_17c;
                    uStack_17c = 0;
                    puVar13 = (uint *)func_0x(&uStack_ee,&uStack_190);
                    puVar10 = puStack_e8;
                    uVar7 = uStack_198;
                    if (((sStack_f0 != 0) && (uStack_e0 != (byte **)0x0)) &&
                       ((*uStack_e0 != (byte *)0x0 &&
                        (((uStack_18c & 0x80000) == 0 && ((uStack_17c & 1) == 0)))))) {
                      if ((puVar13 == (uint *)0x0) || (puVar13 == (uint *)0x10103e0)) {
code_r0x00101154:
                        uStack_198 = 0;
                        puVar10 = puStack_e8;
                        puVar13 = puVar14;
                        uVar7 = uStack_198;
                      }
                      else {
                        uStack_1a0 = uStack_17c;
                        puStack_1a8 = &uStack_198;
                        uStack_1b0 = 0;
                        puStack_1b8 = (uint *)0x0;
                        puVar13 = (uint *)func_0x
                                                    (uStack_e0,&uStack_190,puVar13,uStack_198);
                        puVar10 = puStack_e8;
                        uVar7 = uStack_198;
                      }
                    }
                  }
code_r0x001019f0:
                  uStack_198 = uVar7;
                  uVar5 = uStack_194;
                  if ((puVar13 != (uint *)0x0) && (0xc < uStack_198)) {
                    uVar20 = (ulonglong)uStack_198 - 0xc;
                    uVar16 = uVar20 / 0xc;
                    if (((uint)uVar16 < 0x1f9) &&
                       ((*(short *)puVar13 == 2 && (uVar20 == uVar16 * 0xc)))) {
                      func_0x(plStack_110,uVar26,(ulonglong)uStack_198,puVar13);
                      puVar10 = puStack_e8;
                      uVar5 = uStack_194;
                    }
                  }
                }
              }
              else {
                uVar26 = uVar26 - uVar5;
                lStack_118 = lStack_138 - lStack_100;
                uStack_17c = uVar26;
                uVar7 = uStack_d8;
                if (uStack_ec == 0) {
                  uVar20 = (ulonglong)uStack_e0 & 0xffffffff;
                  uStack_ee = 0;
                  uVar7 = (uint)uStack_e0;
                  if ((*(byte *)puVar10 & 0x10) != 0) {
                    uVar7 = (uint)uStack_e0 + 2 + (*(ushort *)(uVar20 + (longlong)puVar10) + 7 >> 3)
                    ;
                    uVar20 = (ulonglong)uVar7;
                  }
                  uStack_e0 = (byte **)CONCAT44(uVar7,(uint)uStack_e0);
                  uVar7 = (uint)uVar20;
                  if ((*(byte *)puVar10 & 0x20) == 0) {
                    uStack_d4 = 0;
                    uVar5 = uVar7;
                    uStack_ec = uVar7;
                  }
                  else {
                    puVar30 = (ushort *)(uVar20 + (longlong)puVar10);
                    uStack_d4 = *puVar30;
                    puStack_160 = puVar30;
                    if (uStack_d4 == 0) {
                      cVar4 = func_0x(0x199bd40);
                      if (cVar4 != '\0') {
                        lVar11 = func_0x();
                        if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                          cVar4 = func_0x(0x199bd40);
                          if (cVar4 == '\0') {
                            (*pcRam0000000000f098c8)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            puStack_1b8 = (uint *)0x0;
                            (*pcRam0000000000f098c0)(1,0x128b74c,0x13ab838,0x80f);
                          }
                        }
                      }
                      func_0x(puStack_e8,3);
                      uVar20 = (ulonglong)uStack_e0 >> 0x20;
                      puVar10 = puStack_e8;
                    }
                    uStack_d8 = (int)uVar20 + (uStack_d4 + 1) * 2;
                    if (0x1f9e < uStack_d8) {
                      cVar4 = func_0x(0x199bd40);
                      if (cVar4 != '\0') {
                        lVar11 = func_0x();
                        if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                          cVar4 = func_0x(0x199bd40);
                          if (cVar4 == '\0') {
                            (*pcRam0000000000f098c8)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            puStack_1b8 = (uint *)0x0;
                            (*pcRam0000000000f098c0)(1,0x128b74c,0x13ab838,0x816);
                          }
                        }
                      }
                      func_0x(puStack_e8,4);
                      uVar20 = (ulonglong)uStack_e0 >> 0x20;
                      puVar10 = puStack_e8;
                    }
                    uVar16 = (ulonglong)uStack_d4;
                    uStack_ec = puVar30[uVar16] & 0x7fff;
                    if (uStack_ec < uStack_d8) {
                      cVar4 = func_0x(0x199bd40);
                      if (cVar4 != '\0') {
                        lVar11 = func_0x();
                        if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                          cVar4 = func_0x(0x199bd40);
                          if (cVar4 == '\0') {
                            (*pcRam0000000000f098c8)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            puStack_1b8 = (uint *)0x0;
                            (*pcRam0000000000f098c0)(1,0x128b74c,0x13ab838,0x81d);
                          }
                        }
                      }
                      func_0x(puStack_e8,4);
                      uVar16 = (ulonglong)uStack_d4;
                      uVar20 = (ulonglong)uStack_e0 >> 0x20;
                      puVar10 = puStack_e8;
                    }
                    uVar28 = uStack_d8;
                    uVar5 = uStack_ec;
                    uVar7 = uStack_d8;
                    if ((short)uVar16 != 0) {
                      do {
                        puVar30 = puVar30 + 1;
                        uVar7 = *puVar30 & 0x7fff;
                        if ((uVar7 < uStack_d8) || (uVar5 < uVar7)) {
                          uStack_d8 = uVar28;
                          cVar4 = func_0x(0x199bd40);
                          if (cVar4 != '\0') {
                            lVar11 = func_0x();
                            if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                              cVar4 = func_0x(0x199bd40);
                              if (cVar4 == '\0') {
                                (*pcRam0000000000f098c8)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                puStack_1b8 = (uint *)0x0;
                                (*pcRam0000000000f098c0)(1,0x128b74c,0x13ab838,0x82a);
                              }
                            }
                          }
                          func_0x(puStack_e8,4);
                          uVar16 = (ulonglong)uStack_d4;
                          puVar10 = puStack_e8;
                          uVar5 = uStack_ec;
                          uVar28 = uStack_d8;
                        }
                        uVar26 = (int)puVar14 + 1;
                        puVar14 = (uint *)(ulonglong)uVar26;
                        uStack_d8 = uVar7;
                      } while ((int)uVar26 < (int)uVar16);
                      uVar20 = (ulonglong)uStack_e0 >> 0x20;
                      uVar7 = uVar28;
                      puVar30 = puStack_160;
                      uVar26 = uStack_17c;
                    }
                    while ((short)puVar30[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
                      uVar17 = uVar28;
                      if ((int)uVar16 != 1) {
                        uVar17 = *(ushort *)((longlong)puVar10 + uVar16 * 2 + (uVar20 - 2)) & 0x7fff
                        ;
                      }
                      uVar21 = *(ushort *)((longlong)puVar10 + uVar16 * 2 + uVar20) & 0x7fff;
                      if (((uVar17 < uVar28) || (uVar21 < uVar17)) ||
                         (uStack_d8 = uVar28, uVar5 < uVar21)) {
                        uStack_d8 = uVar7;
                        func_0x(puVar10,7);
                        uVar16 = (ulonglong)uStack_d4;
                        uVar20 = (ulonglong)uStack_e0 >> 0x20;
                        puVar10 = puStack_e8;
                        uVar5 = uStack_ec;
                        uVar7 = uStack_d8;
                      }
                      if ((uVar17 < uStack_d8) || (uVar5 < uVar17)) goto code_r0x00101839;
                      if (*(ushort *)((ulonglong)uVar17 + (longlong)puVar10) == 5) {
                        uStack_ee = uStack_ee | 2;
                        uStack_d4 = (short)uVar16 - 1;
                        uVar20 = (ulonglong)(uVar17 & 0xffff);
                        pbVar1 = (byte *)((longlong)puVar10 + uVar20);
                        uStack_c6 = (ushort)uVar17;
                        if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                          uVar24 = uStack_c4 & 0xc7ff;
                        }
                        else {
                          uVar24 = uStack_c4 ^ (uStack_c4 ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
                        }
                        uStack_c4 = (uVar24 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar24;
                        uVar16 = (ulonglong)uStack_c4;
                        pbVar19 = (byte *)((ulonglong)((uVar24 >> 0xb & 7) * 2) + 4 + uVar20 +
                                           (uVar16 & 0x7ff) * 2 + (longlong)puVar10);
                        uStack_d8 = uVar7;
                        if (pbVar19 < pbVar1) {
                          func_0x(pbVar1,0x19);
                          uVar16 = (ulonglong)uStack_c4;
                          uVar20 = (ulonglong)uStack_c6;
                          puVar10 = puStack_e8;
                          uVar5 = uStack_ec;
                        }
                        uVar7 = uStack_d8;
                        if (uVar21 - uVar17 <
                            (((uStack_c4 & 0x7ff) * 2 - (int)uVar20) - (int)puStack_e8) +
                            (int)pbVar19) {
                          func_0x((byte *)(uVar20 + (longlong)puVar10),0x19);
                          uVar16 = (ulonglong)uStack_c4;
                          uVar20 = (ulonglong)uStack_c6;
                          puVar10 = puStack_e8;
                          uVar5 = uStack_ec;
                          uVar7 = uStack_d8;
                        }
                        if ((uVar16 & 0x3800) != 0) {
                          puVar30 = (ushort *)((longlong)puVar10 + uVar20 + 4);
                          iVar6 = 0;
                          if ((uVar16 & 0x3800) != 0) {
                            do {
                              if (((ushort)uVar16 & 0x7ff) < (*puVar30 & 0x7ff)) {
                                uStack_d8 = uVar7;
                                func_0x((byte *)(uVar20 + (longlong)puVar10),0x1a);
                                uVar16 = (ulonglong)uStack_c4;
                                uVar20 = (ulonglong)uStack_c6;
                                puVar10 = puStack_e8;
                                uVar7 = uStack_d8;
                              }
                              iVar6 = iVar6 + 1;
                              puVar30 = puVar30 + 1;
                              uVar5 = uStack_ec;
                            } while (iVar6 < (int)((uStack_c4 & 0x3800) >> 0xb));
                          }
                        }
                        break;
                      }
                      if (*(ushort *)((ulonglong)uVar17 + (longlong)puVar10) < 0x400) break;
                      uStack_ee = uStack_ee | 1;
                      uStack_d4 = (short)uVar16 - 1;
                      uVar16 = (ulonglong)uStack_d4;
                      uVar28 = uStack_d8;
                      if (uStack_d4 == 0) break;
                    }
                  }
                  if ((*(byte *)puVar10 & 0x40) == 0) {
                    uStack_ca = 0;
                    uStack_c8 = 0;
                  }
                  else {
                    uStack_ca = (undefined2)uVar5;
                    uStack_c8 = (undefined2)(uVar5 >> 0x10);
                    uStack_ec = uVar5 + 0xe;
                    uStack_d8 = uVar7;
                    uVar12 = func_0x(&uStack_ee);
                    func_0x(uVar12,auStack_120);
                    iVar6 = func_0x(auStack_120);
                    uVar5 = uStack_ec + iVar6;
                    puVar10 = puStack_e8;
                    uStack_ec = uVar5;
                    uVar7 = uStack_d8;
                  }
                  uStack_d8 = uVar7;
                  if (((byte *)CONCAT62(uStack_d0,uStack_d2) != (byte *)0x0) &&
                     ((byte *)CONCAT62(uStack_d0,uStack_d2) <
                      (byte *)((ulonglong)uVar5 + (longlong)puVar10))) {
                    cVar4 = func_0x(0x199bd40);
                    if (cVar4 != '\0') {
                      lVar11 = func_0x();
                      if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                        cVar4 = func_0x(0x199bd40);
                        if (cVar4 == '\0') {
                          (*pcRam0000000000f098c8)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          puStack_1b8 = (uint *)0x0;
                          (*pcRam0000000000f098c0)(1,0x128b74c,0x13ab838,0x886);
                        }
                      }
                    }
                    func_0x(puStack_e8,0x12);
                    uVar5 = uStack_ec;
                  }
                  uVar7 = uStack_d8;
                  if (0x3f3b < uVar5 - 1) {
                    cVar4 = func_0x(0x199bd40);
                    if (cVar4 != '\0') {
                      lVar11 = func_0x();
                      if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                        cVar4 = func_0x(0x199bd40);
                        if (cVar4 == '\0') {
                          (*pcRam0000000000f098c8)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          puStack_1b8 = (uint *)0x0;
                          (*pcRam0000000000f098c0)(1,0x128b74c,0x13ab838,0x88b);
                        }
                      }
                    }
                    func_0x(puStack_e8,5);
                    uVar7 = uStack_d8;
                  }
                }
code_r0x00101839:
                uStack_d8 = uVar7;
                iVar6 = func_0x(&uStack_ee);
                if (iVar6 == 0) {
                  iVar6 = func_0x(&uStack_ee);
                  if (iVar6 == 0) {
                    puStack_1b8 = (uint *)0x0;
                    (*pcRam0000000000f098c0)(1,0x1447468,0x14384f8,0xd7a);
                  }
code_r0x001019c6:
                  puVar13 = (uint *)0x0;
                }
                else {
                  lVar11 = 0;
                  if (((int)uVar26 < 0) || ((int)(uStack_c4 & 0x7ff) <= (int)uVar26)) {
                    puStack_1b8 = (uint *)0x0;
                    (*pcRam0000000000f098c0)(1,0x1447438,0x1447400,0x41a);
                    goto code_r0x001019c6;
                  }
                  uVar20 = (ulonglong)uStack_c6;
                  uVar24 = 0;
                  if ((uStack_c4 & 0x3800) == 0) {
                    uVar23 = *(ushort *)((longlong)puStack_e8 + uVar20 + 2);
code_r0x001018e1:
                    uVar24 = uVar23 >> 0xb & 7;
                  }
                  else if ((uStack_c4 >> 0xb & 7) != 0) {
                    do {
                      if (((lVar11 == 0) ||
                          ((int)(*(ushort *)((longlong)puStack_e8 + lVar11 * 2 + uVar20 + 2) & 0x7ff
                                ) <= (int)uVar26)) &&
                         (uVar23 = *(ushort *)((longlong)puStack_e8 + lVar11 * 2 + uVar20 + 4),
                         (int)uVar26 <= (int)((uVar23 & 0x7ff) - 1))) goto code_r0x001018e1;
                      lVar11 = lVar11 + 1;
                    } while (lVar11 < (longlong)(ulonglong)(uStack_c4 >> 0xb & 7));
                  }
                  uVar5 = uStack_c4 >> 0xb & 7;
                  uVar16 = (ulonglong)(uVar5 * 2);
                  uVar7 = (uStack_c4 & 0x7ff) * 2;
                  iStack_170 = (uint)*(ushort *)
                                      ((longlong)puStack_e8 + uVar16 + uVar20 + (lStack_118 + 2) * 2
                                      ) + (uint)uVar24 * 0x10000;
                  lVar11 = uVar16 + 4 + uVar7 + uVar20;
                  if (uVar26 == 0) {
                    uVar7 = (uVar7 + uVar5) * 2 + 4;
                  }
                  else {
                    uVar7 = *(ushort *)((longlong)puStack_e8 + lStack_118 * 2 + lVar11 + -2) &
                            0x7fff;
                  }
                  uStack_198 = (*(ushort *)((longlong)puStack_e8 + lStack_118 * 2 + lVar11) & 0x7fff
                               ) - uVar7;
                  uStack_174 = (uint)(*(ushort *)
                                       ((longlong)puStack_e8 + (ulonglong)uVar26 * 2 + lVar11) >>
                                     0xf);
                  puVar13 = (uint *)((longlong)puStack_e8 + uVar7 + uVar20);
                }
                puVar10 = puStack_e8;
                lVar29 = lStack_168;
                uVar5 = uStack_194;
                if (uStack_174 != 0) {
                  puVar14 = (uint *)func_0x
                                              (**(undefined8 **)
                                                 (*(longlong *)(lStack_168 + 8) + 0x160),iStack_170)
                  ;
                  uVar26 = *puVar14;
                  uVar7 = uStack_198;
                  goto code_r0x001019f0;
                }
              }
              uStack_178 = uStack_178 + 1;
              lStack_138 = lStack_138 + 1;
              lVar11 = lStack_f8;
              lVar27 = lStack_140;
              uVar7 = uStack_180;
              uVar26 = uStack_178;
            } while (lStack_138 < lStack_108);
          }
        }
      }
      uVar24 = *(ushort *)(lVar11 + 0x16);
      uStack_180 = uVar7 + 1;
      lVar27 = lVar27 + 1;
      lStack_140 = lVar27;
    } while ((int)uStack_180 < (int)(uint)uVar24);
  }
  func_0x(uStack_40 ^ (ulonglong)auStack_1d8);
  return;
}

