
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,byte *param_2,ulonglong param_3,longlong param_4)

{
  undefined2 *puVar1;
  longlong lVar2;
  byte bVar3;
  char cVar4;
  ushort uVar5;
  ushort uVar6;
  int iVar7;
  longlong lVar8;
  longlong lVar9;
  undefined8 uVar10;
  ulonglong uVar11;
  ulonglong *puVar12;
  undefined4 *puVar13;
  byte *pbVar14;
  uint uVar15;
  code *UNRECOVERED_JUMPTABLE;
  byte *pbVar16;
  uint uVar17;
  uint uVar18;
  ushort *puVar19;
  ulonglong uVar20;
  ulonglong uVar21;
  uint uVar22;
  uint uVar23;
  undefined8 uStackX_e;
  undefined auStackX_16 [18];
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar8 = func_0x();
  lVar8 = -lVar8;
  puVar1 = (undefined2 *)(&stack0xfffffffffffffff0 + lVar8);
  *(ulonglong *)(&stack0x00002180 + lVar8) = _DAT_ ^ (ulonglong)puVar1;
  pbVar14 = (byte *)0x0;
  *(undefined8 *)(&stack0x00000048 + lVar8) = *(undefined8 *)(&stack0x00002208 + lVar8);
  uVar5 = *(ushort *)(param_4 + 4);
  uVar11 = param_3 & 0xffffffff;
  uVar6 = uVar5 >> 5;
  uVar23 = (uint)uVar6;
  *(uint *)(&stack0x00000030 + lVar8) = (uint)param_3;
  *(byte **)(&stack0x00000040 + lVar8) = param_2;
  *(uint *)(&stack0x00000038 + lVar8) = uVar23;
  if (((byte)uVar5 & 0x1f) == 3) {
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10008c;
    (*_DAT_)(1,0x109ade0,0x1051208,0x91a);
  }
  if (uVar6 == 0) {
    uVar23 = *(uint *)(param_1 + 2);
    if (*param_1 == 0) {
      if (uVar23 == 0) {
        pbVar16 = *(byte **)(param_1 + 4);
        uVar23 = *(uint *)(param_1 + 8);
        uVar11 = (ulonglong)uVar23;
        param_1[1] = 0;
        *(uint *)(param_1 + 10) = uVar23;
        bVar3 = *pbVar16;
        if ((bVar3 & 0x10) != 0) {
          uVar23 = uVar23 + 2 + (*(ushort *)(pbVar16 + uVar11) + 7 >> 3);
          uVar11 = (ulonglong)uVar23;
          *(uint *)(param_1 + 10) = uVar23;
          bVar3 = *pbVar16;
        }
        if ((bVar3 & 0x20) == 0) {
          *(int *)(param_1 + 2) = (int)uVar11;
          param_1[0xe] = 0;
          *(int *)(param_1 + 0xc) = (int)uVar11;
        }
        else {
          puVar19 = (ushort *)(pbVar16 + uVar11);
          *(ushort **)(&stack0x00000038 + lVar8) = puVar19;
          uVar5 = *puVar19;
          param_1[0xe] = uVar5;
          if (uVar5 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100112;
            cVar4 = func_0x(0x15daa30);
            if (cVar4 != '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10011b;
              lVar9 = func_0x();
              if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100135;
                cVar4 = func_0x(0x15daa30);
                if (cVar4 == '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100151;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100175;
                  (*_DAT_)(1,0xeca43c,0xfea528,0x80f);
                }
              }
            }
            uVar10 = *(undefined8 *)(param_1 + 4);
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100184;
            func_0x(uVar10,3);
            uVar5 = param_1[0xe];
            uVar11 = (ulonglong)*(uint *)(param_1 + 10);
          }
          uVar15 = (uint)uVar5;
          uVar23 = (int)uVar11 + (uVar15 + 1) * 2;
          *(uint *)(param_1 + 0xc) = uVar23;
          if (0x1f9e < uVar23) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1001b8;
            cVar4 = func_0x(0x15daa30);
            if (cVar4 != '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1001c1;
              lVar9 = func_0x();
              if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1001db;
                cVar4 = func_0x(0x15daa30);
                if (cVar4 == '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1001f7;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10021b;
                  (*_DAT_)(1,0xeca43c,0xfea528,0x816);
                }
              }
            }
            uVar10 = *(undefined8 *)(param_1 + 4);
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10022a;
            func_0x(uVar10,4);
            uVar15 = (uint)(ushort)param_1[0xe];
            uVar23 = *(uint *)(param_1 + 0xc);
          }
          uVar17 = puVar19[uVar15] & 0x7fff;
          *(uint *)(param_1 + 2) = uVar17;
          if (uVar17 < uVar23) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10025c;
            cVar4 = func_0x(0x15daa30);
            if (cVar4 != '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100265;
              lVar9 = func_0x();
              if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10027f;
                cVar4 = func_0x(0x15daa30);
                if (cVar4 == '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10029b;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1002bf;
                  (*_DAT_)(1,0xeca43c,0xfea528,0x81d);
                }
              }
            }
            uVar10 = *(undefined8 *)(param_1 + 4);
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1002ce;
            func_0x(uVar10,4);
            uVar23 = *(uint *)(param_1 + 0xc);
            uVar15 = (uint)(ushort)param_1[0xe];
            uVar17 = *(uint *)(param_1 + 2);
          }
          pbVar16 = pbVar14;
          if ((short)uVar15 != 0) {
            do {
              puVar19 = puVar19 + 1;
              uVar18 = *puVar19 & 0x7fff;
              if ((uVar18 < uVar23) || (uVar17 = *(uint *)(param_1 + 2), uVar17 < uVar18)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100318;
                cVar4 = func_0x(0x15daa30);
                if (cVar4 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100321;
                  lVar9 = func_0x();
                  if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10033b;
                    cVar4 = func_0x(0x15daa30);
                    if (cVar4 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100357;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10037b;
                      (*_DAT_)(1,0xeca43c,0xfea528,0x82a);
                    }
                  }
                }
                uVar10 = *(undefined8 *)(param_1 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10038a;
                func_0x(uVar10,4);
                uVar17 = *(uint *)(param_1 + 2);
              }
              uVar15 = (uint)(ushort)param_1[0xe];
              uVar22 = (int)pbVar16 + 1;
              pbVar16 = (byte *)(ulonglong)uVar22;
              uVar23 = uVar18;
            } while ((int)uVar22 < (int)uVar15);
            puVar19 = *(ushort **)(&stack0x00000038 + lVar8);
          }
          uVar11 = (ulonglong)uVar17;
          if ((short)puVar19[(ulonglong)(uVar15 - 1) + 1] < 0) {
            pbVar16 = *(byte **)(param_1 + 4);
            lVar9 = *(longlong *)(&stack0x00000038 + lVar8);
            do {
              uVar17 = *(ushort *)
                        (pbVar16 + (ulonglong)uVar15 * 2 + (ulonglong)*(uint *)(param_1 + 10)) &
                       0x7fff;
              if (uVar15 == 1) {
                uVar15 = *(uint *)(param_1 + 0xc);
                uVar18 = uVar15;
LAB_:
                if ((uVar17 < uVar15) || (uVar23 = *(uint *)(param_1 + 2), uVar23 < uVar17))
                goto LAB_;
              }
              else {
                uVar18 = *(uint *)(param_1 + 0xc);
                uVar15 = *(ushort *)
                          (pbVar16 +
                          (ulonglong)uVar15 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2)) & 0x7fff
                ;
                if (uVar18 <= uVar15) goto LAB_;
LAB_:
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100425;
                func_0x(pbVar16,7);
                uVar18 = *(uint *)(param_1 + 0xc);
                uVar23 = *(uint *)(param_1 + 2);
              }
              uVar11 = (ulonglong)uVar23;
              if ((uVar15 < uVar18) || (uVar23 < uVar15)) goto LAB_;
              pbVar16 = *(byte **)(param_1 + 4);
              if (*(ushort *)(pbVar16 + uVar15) == 5) {
                param_1[1] = param_1[1] | 2;
                param_1[0xe] = param_1[0xe] + -1;
                uVar21 = (ulonglong)(uVar15 & 0xffff);
                param_1[0x15] = (short)uVar15;
                uVar11 = *(ulonglong *)(param_1 + 4);
                uVar5 = param_1[0x16] & 0xc7ffU;
                if ((*(ushort *)(uVar21 + 2 + uVar11) >> 0xe & 1) != 0) {
                  uVar5 = *(ushort *)(uVar21 + 2 + uVar11) & 0x3800 | param_1[0x16] & 0xc7ffU;
                }
                param_1[0x16] = uVar5;
                uVar6 = (uVar5 ^ *(ushort *)(uVar21 + 2 + uVar11)) & 0x7ff ^ uVar5;
                param_1[0x16] = uVar6;
                uVar20 = uVar11 + 4 +
                         (ulonglong)((uVar6 & 0x7ff) * 2) + uVar21 + (uVar5 >> 0xb & 7) * 2;
                if (uVar20 < uVar21 + uVar11) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100543;
                  func_0x(uVar21 + uVar11,0x19);
                  uVar6 = param_1[0x16];
                  uVar21 = (ulonglong)(ushort)param_1[0x15];
                  uVar11 = (ulonglong)*(uint *)(param_1 + 4);
                }
                if (uVar17 - uVar15 <
                    (((uVar6 & 0x7ff) * 2 - (int)uVar21) - (int)uVar11) + (int)uVar20) {
                  lVar9 = *(longlong *)(param_1 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100580;
                  func_0x(uVar21 + lVar9,0x19);
                  uVar6 = param_1[0x16];
                }
                if (((uVar6 & 0x3800) != 0) &&
                   (puVar19 = (ushort *)
                              (*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]),
                   (uVar6 & 0x3800) != 0)) {
                  do {
                    if ((uVar6 & 0x7ff) < (*puVar19 & 0x7ff)) {
                      uVar5 = param_1[0x15];
                      lVar9 = *(longlong *)(param_1 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1005ea;
                      func_0x((ulonglong)uVar5 + lVar9,0x1a);
                      uVar6 = param_1[0x16];
                    }
                    uVar23 = (int)pbVar14 + 1;
                    pbVar14 = (byte *)(ulonglong)uVar23;
                    puVar19 = puVar19 + 1;
                  } while ((int)uVar23 < (int)(uVar6 >> 0xb & 7));
                }
                uVar11 = (ulonglong)*(uint *)(param_1 + 2);
                goto LAB_;
              }
              if (*(ushort *)(pbVar16 + uVar15) < 0x400) goto LAB_;
              param_1[1] = param_1[1] | 1;
              uVar5 = param_1[0xe] - 1;
              param_1[0xe] = uVar5;
              if (uVar5 == 0) goto LAB_;
              uVar15 = (uint)uVar5;
            } while (*(short *)(lVar9 + 2 + (ulonglong)(uVar5 - 1) * 2) < 0);
          }
          else {
LAB_:
            pbVar16 = *(byte **)(param_1 + 4);
          }
        }
        if ((*pbVar16 & 0x40) == 0) {
          *(undefined4 *)(param_1 + 0x13) = 0;
        }
        else {
          *(int *)(param_1 + 0x13) = (int)uVar11;
          *(int *)(param_1 + 2) = (int)uVar11 + 0xe;
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100642;
          uVar10 = func_0x(param_1 + 1);
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10064e;
          func_0x(uVar10,&stack0x00000028 + lVar8);
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100657;
          iVar7 = func_0x(&stack0x00000028 + lVar8);
          *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar7;
          uVar11 = (ulonglong)*(uint *)(param_1 + 2);
        }
        if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
           (*(ulonglong *)(param_1 + 0xf) < uVar11 + *(longlong *)(param_1 + 4))) {
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100694;
          cVar4 = func_0x(0x15daa30);
          if (cVar4 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10069d;
            lVar9 = func_0x();
            if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1006b7;
              cVar4 = func_0x(0x15daa30);
              if (cVar4 == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1006d3;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1006f7;
                (*_DAT_)(1,0xeca43c,0xfea528,0x886);
              }
            }
          }
          uVar10 = *(undefined8 *)(param_1 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100706;
          func_0x(uVar10,0x12);
          uVar11 = (ulonglong)*(uint *)(param_1 + 2);
        }
        uVar23 = (uint)uVar11;
        if ((uVar23 == 0) || (0x3f3c < uVar23)) {
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100727;
          cVar4 = func_0x(0x15daa30);
          if (cVar4 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100730;
            lVar9 = func_0x();
            if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10074a;
              cVar4 = func_0x(0x15daa30);
              if (cVar4 == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100766;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10078a;
                (*_DAT_)(1,0xeca43c,0xfea528,0x88b);
              }
            }
          }
          uVar10 = *(undefined8 *)(param_1 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100799;
          func_0x(uVar10,5);
          uVar23 = *(uint *)(param_1 + 2);
        }
      }
LAB_:
      if ((uVar23 < 9) &&
         (((**(byte **)(param_1 + 4) & 0xe) == 0 || ((**(byte **)(param_1 + 4) & 0xe) == 0xc)))) {
        uVar23 = 9;
      }
      uVar11 = (ulonglong)*(uint *)(&stack0x00000030 + lVar8);
      param_2 = *(byte **)(&stack0x00000040 + lVar8);
    }
    else {
      if (uVar23 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1007d1;
        func_0x(param_1 + 1);
        uVar23 = *(uint *)(param_1 + 2);
      }
      if ((uVar23 < 9) &&
         (((**(byte **)(param_1 + 4) & 0x1c) == 0 || ((**(byte **)(param_1 + 4) & 0x1c) == 0xc)))) {
        uVar23 = 9;
      }
    }
    uVar10 = *(undefined8 *)(param_1 + 4);
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100804;
    func_0x(param_2,uVar11,uVar10,uVar23);
    if ((*param_2 & 1) != 0) {
      *param_1 = 1;
      *(byte **)(param_1 + 4) = param_2;
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*param_2 & 0x1c) + 0x1024c0) * 4
                             + 0x1024b0) - 0x18d4b90);
                    /* WARNING: Could not emulate address calculation at 0x00100869 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
      return;
    }
    *param_1 = 0;
    *(byte **)(param_1 + 4) = param_2;
    *(undefined4 *)(param_1 + 2) = 0;
    *(undefined4 *)(param_1 + 0x13) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001009e5 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*param_2 & 0xe) * 4 + 0x1024e0) - 0x18d4b90))();
    return;
  }
  uVar5 = *(ushort *)(param_4 + 4) & 0x1f;
  if (uVar5 != 2) {
    if (uVar5 != 1) {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10248c;
      (*_DAT_)(1,0x1054dd8,0x1051208,0x98e);
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10249b;
      func_0x(*(ulonglong *)(&stack0x00002180 + lVar8) ^ (ulonglong)puVar1);
      return;
    }
    if ((uint)param_3 < uVar23) {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1021a4;
      (*_DAT_)(1,0x109adc0,0x1051208,0x981);
    }
    if (*param_1 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1021b5;
      pbVar14 = (byte *)func_0x(param_1 + 1);
    }
    else {
      pbVar16 = *(byte **)(param_1 + 4);
      if ((*pbVar16 & 2) != 0) {
        if (*(int *)(param_1 + 2) == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1021d2;
          func_0x(param_1 + 1);
          pbVar16 = *(byte **)(param_1 + 4);
        }
        pbVar14 = pbVar16 + (ulonglong)*(uint *)(param_1 + 0x18) + 0xe;
      }
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1021f9;
    func_0x(param_2,uVar11,pbVar14,uVar23);
    if ((*param_2 & 1) != 0) {
      *param_1 = 1;
      *(byte **)(param_1 + 4) = param_2;
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*param_2 & 0x1c) + 0x102604) * 4
                             + 0x1025f4) - 0x18d4b90);
                    /* WARNING: Could not emulate address calculation at 0x0010225e */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
      return;
    }
    *param_1 = 0;
    *(byte **)(param_1 + 4) = param_2;
    *(undefined4 *)(param_1 + 2) = 0;
    *(undefined4 *)(param_1 + 0x13) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001023e1 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*param_2 & 0xe) * 4 + 0x102624) - 0x18d4b90))();
    return;
  }
  uVar23 = *(uint *)(param_1 + 2);
  *(undefined8 *)(&stack0x00000030 + lVar8) = 0;
  *(undefined8 *)(&stack0x000000a0 + lVar8) = 0;
  *(undefined4 *)(&stack0x000000a8 + lVar8) = 0;
  *(undefined2 *)(&stack0x000000ac + lVar8) = 0;
  *(undefined4 *)(&stack0xfffffffffffffff4 + lVar8) = 0;
  *(undefined8 *)((longlong)&uStackX_e + lVar8) = 0;
  *(undefined8 *)(auStackX_16 + lVar8 + 2) = 0;
  *(undefined8 *)(auStackX_16 + lVar8 + -0x16) = 0;
  if (*param_1 == 0) {
    if (uVar23 == 0) {
      pbVar16 = *(byte **)(param_1 + 4);
      uVar23 = *(uint *)(param_1 + 8);
      uVar11 = (ulonglong)uVar23;
      param_1[1] = 0;
      *(uint *)(param_1 + 10) = uVar23;
      bVar3 = *pbVar16;
      if ((bVar3 & 0x10) != 0) {
        uVar23 = uVar23 + 2 + (*(ushort *)(pbVar16 + uVar11) + 7 >> 3);
        uVar11 = (ulonglong)uVar23;
        *(uint *)(param_1 + 10) = uVar23;
        bVar3 = *pbVar16;
      }
      if ((bVar3 & 0x20) == 0) {
        *(int *)(param_1 + 2) = (int)uVar11;
        param_1[0xe] = 0;
        *(int *)(param_1 + 0xc) = (int)uVar11;
      }
      else {
        puVar19 = (ushort *)(pbVar16 + uVar11);
        *(ushort **)(&stack0x00000028 + lVar8) = puVar19;
        uVar5 = *puVar19;
        param_1[0xe] = uVar5;
        if (uVar5 == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100c9c;
          cVar4 = func_0x(0x15daa30);
          if (cVar4 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100ca5;
            lVar9 = func_0x();
            if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100cbf;
              cVar4 = func_0x(0x15daa30);
              if (cVar4 == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100cdb;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100cff;
                (*_DAT_)(1,0xeca43c,0xfea528,0x80f);
              }
            }
          }
          uVar10 = *(undefined8 *)(param_1 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100d0e;
          func_0x(uVar10,3);
          uVar5 = param_1[0xe];
          uVar11 = (ulonglong)*(uint *)(param_1 + 10);
        }
        uVar15 = (uint)uVar5;
        uVar23 = (int)uVar11 + (uVar15 + 1) * 2;
        *(uint *)(param_1 + 0xc) = uVar23;
        if (0x1f9e < uVar23) {
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100d42;
          cVar4 = func_0x(0x15daa30);
          if (cVar4 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100d4b;
            lVar9 = func_0x();
            if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100d65;
              cVar4 = func_0x(0x15daa30);
              if (cVar4 == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100d81;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100da5;
                (*_DAT_)(1,0xeca43c,0xfea528,0x816);
              }
            }
          }
          uVar10 = *(undefined8 *)(param_1 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100db4;
          func_0x(uVar10,4);
          uVar15 = (uint)(ushort)param_1[0xe];
          uVar23 = *(uint *)(param_1 + 0xc);
        }
        uVar17 = puVar19[uVar15] & 0x7fff;
        *(uint *)(param_1 + 2) = uVar17;
        if (uVar17 < uVar23) {
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100de6;
          cVar4 = func_0x(0x15daa30);
          if (cVar4 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100def;
            lVar9 = func_0x();
            if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100e09;
              cVar4 = func_0x(0x15daa30);
              if (cVar4 == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100e25;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100e49;
                (*_DAT_)(1,0xeca43c,0xfea528,0x81d);
              }
            }
          }
          uVar10 = *(undefined8 *)(param_1 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100e58;
          func_0x(uVar10,4);
          uVar23 = *(uint *)(param_1 + 0xc);
          uVar15 = (uint)(ushort)param_1[0xe];
          uVar17 = *(uint *)(param_1 + 2);
        }
        pbVar16 = pbVar14;
        if ((short)uVar15 != 0) {
          do {
            puVar19 = puVar19 + 1;
            uVar18 = *puVar19 & 0x7fff;
            if ((uVar18 < uVar23) || (uVar17 = *(uint *)(param_1 + 2), uVar17 < uVar18)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100ea8;
              cVar4 = func_0x(0x15daa30);
              if (cVar4 != '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100eb1;
                lVar9 = func_0x();
                if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100ecb;
                  cVar4 = func_0x(0x15daa30);
                  if (cVar4 == '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100ee7;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
                    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100f0b;
                    (*_DAT_)(1,0xeca43c,0xfea528,0x82a);
                  }
                }
              }
              uVar10 = *(undefined8 *)(param_1 + 4);
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100f1a;
              func_0x(uVar10,4);
              uVar17 = *(uint *)(param_1 + 2);
            }
            uVar15 = (uint)(ushort)param_1[0xe];
            uVar22 = (int)pbVar16 + 1;
            pbVar16 = (byte *)(ulonglong)uVar22;
            uVar23 = uVar18;
          } while ((int)uVar22 < (int)uVar15);
          puVar19 = *(ushort **)(&stack0x00000028 + lVar8);
        }
        uVar11 = (ulonglong)uVar17;
        if ((short)puVar19[(ulonglong)(uVar15 - 1) + 1] < 0) {
          lVar9 = *(longlong *)(param_1 + 4);
          lVar2 = *(longlong *)(&stack0x00000028 + lVar8);
LAB_:
          uVar17 = *(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar9 + (ulonglong)uVar15 * 2) &
                   0x7fff;
          if (uVar15 == 1) {
            uVar15 = *(uint *)(param_1 + 0xc);
            uVar18 = uVar15;
LAB_:
            if ((uVar17 < uVar15) || (uVar23 = *(uint *)(param_1 + 2), uVar23 < uVar17))
            goto LAB_;
          }
          else {
            uVar18 = *(uint *)(param_1 + 0xc);
            uVar15 = *(ushort *)
                      ((ulonglong)*(uint *)(param_1 + 10) + lVar9 + -2 + (ulonglong)uVar15 * 2) &
                     0x7fff;
            if (uVar18 <= uVar15) goto LAB_;
LAB_:
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x100fb5;
            func_0x(lVar9,7);
            uVar18 = *(uint *)(param_1 + 0xc);
            uVar23 = *(uint *)(param_1 + 2);
          }
          uVar11 = (ulonglong)uVar23;
          if ((uVar18 <= uVar15) && (uVar15 <= uVar23)) {
            lVar9 = *(longlong *)(param_1 + 4);
            if (*(ushort *)((ulonglong)uVar15 + lVar9) == 5) {
              param_1[1] = param_1[1] | 2;
              param_1[0xe] = param_1[0xe] + -1;
              uVar21 = (ulonglong)(uVar15 & 0xffff);
              param_1[0x15] = (short)uVar15;
              uVar11 = *(ulonglong *)(param_1 + 4);
              uVar5 = param_1[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar21 + 2 + uVar11) >> 0xe & 1) != 0) {
                uVar5 = *(ushort *)(uVar21 + 2 + uVar11) & 0x3800 | param_1[0x16] & 0xc7ffU;
              }
              param_1[0x16] = uVar5;
              uVar6 = (uVar5 ^ *(ushort *)(uVar21 + 2 + uVar11)) & 0x7ff ^ uVar5;
              param_1[0x16] = uVar6;
              uVar20 = (ulonglong)((uVar6 & 0x7ff) * 2) + 4 + uVar11 + (uVar5 >> 0xb & 7) * 2 +
                       uVar21;
              if (uVar20 < uVar21 + uVar11) {
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1010d1;
                func_0x(uVar21 + uVar11,0x19);
                uVar6 = param_1[0x16];
                uVar21 = (ulonglong)(ushort)param_1[0x15];
                uVar11 = (ulonglong)*(uint *)(param_1 + 4);
              }
              if (uVar17 - uVar15 <
                  (((uVar6 & 0x7ff) * 2 - (int)uVar21) - (int)uVar11) + (int)uVar20) {
                lVar9 = *(longlong *)(param_1 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10110e;
                func_0x(uVar21 + lVar9,0x19);
                uVar6 = param_1[0x16];
              }
              if (((uVar6 & 0x3800) != 0) &&
                 (puVar19 = (ushort *)
                            (*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]),
                 pbVar16 = pbVar14, (uVar6 & 0x3800) != 0)) {
                do {
                  if ((uVar6 & 0x7ff) < (*puVar19 & 0x7ff)) {
                    uVar5 = param_1[0x15];
                    lVar9 = *(longlong *)(param_1 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10116a;
                    func_0x((ulonglong)uVar5 + lVar9,0x1a);
                    uVar6 = param_1[0x16];
                  }
                  uVar23 = (int)pbVar16 + 1;
                  pbVar16 = (byte *)(ulonglong)uVar23;
                  puVar19 = puVar19 + 1;
                } while ((int)uVar23 < (int)(uVar6 >> 0xb & 7));
              }
              uVar11 = (ulonglong)*(uint *)(param_1 + 2);
            }
            else if (0x3ff < *(ushort *)((ulonglong)uVar15 + lVar9)) goto code_r0x00100ff2;
            goto LAB_;
          }
          goto LAB_;
        }
LAB_:
        pbVar16 = *(byte **)(param_1 + 4);
      }
      if ((*pbVar16 & 0x40) == 0) {
        *(undefined4 *)(param_1 + 0x13) = 0;
      }
      else {
        *(int *)(param_1 + 0x13) = *(int *)(param_1 + 2);
        *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + 0xe;
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1011d8;
        puVar12 = (ulonglong *)func_0x(param_1 + 1);
        uVar11 = *puVar12;
        uVar6 = (ushort)(uVar11 >> 0x30);
        uVar5 = uVar6;
        if ((((uint)(int)(short)uVar6 >> 1 ^ (int)(short)uVar6) & 0x2000) != 0) {
          uVar5 = uVar6 & 0xdfff;
          if ((uVar11 & 0x4000000000000000) != 0) {
            uVar5 = uVar6 | 0x2000;
          }
        }
        if (uVar5 == 0xfffc) {
          pbVar14 = (byte *)((uVar11 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + (int)pbVar14;
        uVar11 = (ulonglong)*(uint *)(param_1 + 2);
      }
      if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
         (*(ulonglong *)(param_1 + 0xf) < uVar11 + *(longlong *)(param_1 + 4))) {
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101260;
        cVar4 = func_0x(0x15daa30);
        if (cVar4 != '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101269;
          lVar9 = func_0x();
          if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101283;
            cVar4 = func_0x(0x15daa30);
            if (cVar4 == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10129f;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1012c3;
              (*_DAT_)(1,0xeca43c,0xfea528,0x886);
            }
          }
        }
        uVar10 = *(undefined8 *)(param_1 + 4);
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1012d2;
        func_0x(uVar10,0x12);
        uVar11 = (ulonglong)*(uint *)(param_1 + 2);
      }
      uVar23 = (uint)uVar11;
      if ((uVar23 == 0) || (0x3f3c < uVar23)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1012f3;
        cVar4 = func_0x(0x15daa30);
        if (cVar4 != '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1012fc;
          lVar9 = func_0x();
          if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101316;
            cVar4 = func_0x(0x15daa30);
            if (cVar4 == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101332;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar8) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101356;
              (*_DAT_)(1,0xeca43c,0xfea528,0x88b);
            }
          }
        }
        uVar10 = *(undefined8 *)(param_1 + 4);
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101365;
        func_0x(uVar10,5);
        uVar23 = *(uint *)(param_1 + 2);
      }
    }
LAB_:
    if ((uVar23 < 9) &&
       (((**(byte **)(param_1 + 4) & 0xe) == 0 || ((**(byte **)(param_1 + 4) & 0xe) == 0xc)))) {
      uVar23 = 9;
    }
  }
  else {
    if (uVar23 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x10139c;
      func_0x(param_1 + 1);
      uVar23 = *(uint *)(param_1 + 2);
    }
    if ((uVar23 < 9) &&
       (((**(byte **)(param_1 + 4) & 0x1c) == 0 || ((**(byte **)(param_1 + 4) & 0x1c) == 0xc)))) {
      uVar23 = 9;
    }
  }
  lVar9 = *(longlong *)(param_1 + 4);
  if (uVar23 != 0) {
    if ((lVar9 == 0) || (0x2000 < uVar23)) {
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1013f7;
      func_0x(&stack0x00000180 + lVar8,0,0x2000);
      if (lVar9 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101402;
        puVar13 = (undefined4 *)(*_DAT_)();
        *puVar13 = 0x16;
      }
      else {
        if (uVar23 < 0x2001) goto LAB_;
        *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101415;
        puVar13 = (undefined4 *)(*_DAT_)();
        *puVar13 = 0x22;
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x101421;
      (*_DAT_)();
    }
    else {
      *(undefined8 *)((longlong)&uStack_48 + lVar8) = 0x1013e4;
      func_0x(&stack0x00000180 + lVar8,lVar9,uVar23);
    }
  }
LAB_:
  bVar3 = (&stack0x00000180)[lVar8];
  *(undefined **)(&stack0xfffffffffffffff8 + lVar8) = &stack0x00000180 + lVar8;
  if ((bVar3 & 1) != 0) {
    *puVar1 = 1;
    UNRECOVERED_JUMPTABLE =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(bVar3 & 0x1c) + 0x10252c) * 4 +
                           0x10251c) - 0x18d4b90);
                    /* WARNING: Could not emulate address calculation at 0x001014a1 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
    return;
  }
  *puVar1 = 0;
  lVar9 = (longlong)(int)(bVar3 & 0xe);
  *(undefined4 *)(auStackX_16 + lVar8) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001015cf */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((ulonglong)*(uint *)(lVar9 * 4 + 0x10254c) - 0x18d4b90))
            (lVar9,0xfffffffffe72b470,0xc459a0,0xc459a0);
  return;
code_r0x00100ff2:
  param_1[1] = param_1[1] | 1;
  uVar5 = param_1[0xe] - 1;
  param_1[0xe] = uVar5;
  if ((uVar5 == 0) ||
     (uVar15 = (uint)uVar5, -1 < *(short *)(lVar2 + 2 + (ulonglong)(uVar5 - 1) * 2)))
  goto LAB_;
  goto LAB_;
}

