
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(short *param_1)

{
  uint uVar1;
  ushort *puVar2;
  byte bVar3;
  char cVar4;
  ushort uVar5;
  ushort uVar6;
  int iVar7;
  longlong lVar8;
  undefined8 *puVar9;
  uint uVar10;
  uint uVar11;
  ulonglong uVar12;
  int iVar13;
  uint uVar14;
  ulonglong uVar15;
  byte *pbVar16;
  ulonglong uVar17;
  ushort *puVar18;
  undefined8 uStackX_8;
  
  iVar7 = 0;
  if (*param_1 == 0) {
    if (*(int *)(param_1 + 2) == 0) {
      pbVar16 = *(byte **)(param_1 + 4);
      uVar10 = *(uint *)(param_1 + 8);
      uVar12 = (ulonglong)uVar10;
      param_1[1] = 0;
      *(uint *)(param_1 + 10) = uVar10;
      bVar3 = *pbVar16;
      if ((bVar3 & 0x10) != 0) {
        uVar10 = uVar10 + 2 + (*(ushort *)(pbVar16 + uVar12) + 7 >> 3);
        uVar12 = (ulonglong)uVar10;
        *(uint *)(param_1 + 10) = uVar10;
        bVar3 = *pbVar16;
      }
      if ((bVar3 & 0x20) == 0) {
        *(int *)(param_1 + 2) = (int)uVar12;
        param_1[0xe] = 0;
        *(int *)(param_1 + 0xc) = (int)uVar12;
      }
      else {
        puVar18 = (ushort *)(pbVar16 + uVar12);
        uVar5 = *puVar18;
        param_1[0xe] = uVar5;
        if (uVar5 == 0) {
          cVar4 = func_0x(0x11096e0);
          if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar4 = func_0x(0x11096e0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0x9f90ec,0xb191d8,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),3);
          uVar12 = (ulonglong)*(uint *)(param_1 + 10);
          uVar5 = param_1[0xe];
        }
        uVar10 = (int)uVar12 + (uVar5 + 1) * 2;
        *(uint *)(param_1 + 0xc) = uVar10;
        if (0x1f9e < uVar10) {
          cVar4 = func_0x(0x11096e0);
          if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar4 = func_0x(0x11096e0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x9f90ec,0xb191d8,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar5 = param_1[0xe];
          uVar10 = *(uint *)(param_1 + 0xc);
        }
        uVar12 = (ulonglong)uVar5;
        uVar5 = puVar18[uVar12];
        *(uint *)(param_1 + 2) = uVar5 & 0x7fff;
        if ((uVar5 & 0x7fff) < uVar10) {
          cVar4 = func_0x(0x11096e0);
          if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar4 = func_0x(0x11096e0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x9f90ec,0xb191d8,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar10 = *(uint *)(param_1 + 0xc);
          uVar12 = (ulonglong)(ushort)param_1[0xe];
        }
        puVar2 = puVar18;
        iVar13 = iVar7;
        if ((short)uVar12 != 0) {
          do {
            uVar14 = puVar2[1] & 0x7fff;
            if ((uVar14 < uVar10) || (*(uint *)(param_1 + 2) < uVar14)) {
              cVar4 = func_0x(0x11096e0);
              if ((cVar4 != '\0') &&
                 ((lVar8 = func_0x(), lVar8 != 0 &&
                  (*(char *)(lVar8 + 0x499) != '\0')))) {
                cVar4 = func_0x(0x11096e0);
                if (cVar4 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x9f90ec,0xb191d8,0x82a,0);
                }
              }
              func_0x(*(undefined8 *)(param_1 + 4),4);
            }
            uVar12 = (ulonglong)(ushort)param_1[0xe];
            iVar13 = iVar13 + 1;
            puVar2 = puVar2 + 1;
            uVar10 = uVar14;
          } while (iVar13 < (int)(uint)(ushort)param_1[0xe]);
        }
        if ((short)puVar18[(ulonglong)((int)uVar12 - 1) + 1] < 0) {
          pbVar16 = *(byte **)(param_1 + 4);
          do {
            uVar10 = *(ushort *)(pbVar16 + uVar12 * 2 + (ulonglong)*(uint *)(param_1 + 10)) & 0x7fff
            ;
            if ((int)uVar12 == 1) {
              uVar14 = *(uint *)(param_1 + 0xc);
              uVar11 = uVar14;
LAB_:
              if ((uVar10 < uVar14) || (uVar1 = *(uint *)(param_1 + 2), uVar1 < uVar10))
              goto LAB_;
            }
            else {
              uVar11 = *(uint *)(param_1 + 0xc);
              uVar14 = *(ushort *)(pbVar16 + uVar12 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2))
                       & 0x7fff;
              if (uVar11 <= uVar14) goto LAB_;
LAB_:
              func_0x(pbVar16,7);
              uVar11 = *(uint *)(param_1 + 0xc);
              uVar1 = *(uint *)(param_1 + 2);
            }
            if ((uVar14 < uVar11) || (uVar1 < uVar14)) goto LAB_;
            pbVar16 = *(byte **)(param_1 + 4);
            if (*(ushort *)(pbVar16 + uVar14) == 5) {
              param_1[1] = param_1[1] | 2;
              param_1[0xe] = param_1[0xe] + -1;
              uVar17 = (ulonglong)(uVar14 & 0xffff);
              param_1[0x15] = (short)uVar14;
              uVar12 = *(ulonglong *)(param_1 + 4);
              uVar5 = param_1[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar17 + 2 + uVar12) >> 0xe & 1) != 0) {
                uVar5 = *(ushort *)(uVar17 + 2 + uVar12) & 0x3800 | param_1[0x16] & 0xc7ffU;
              }
              param_1[0x16] = uVar5;
              uVar6 = (uVar5 ^ *(ushort *)(uVar17 + 2 + uVar12)) & 0x7ff ^ uVar5;
              param_1[0x16] = uVar6;
              uVar15 = (ulonglong)((uVar6 & 0x7ff) * 2) + 4 + uVar12 + (uVar5 >> 0xb & 7) * 2 +
                       uVar17;
              if (uVar15 < uVar17 + uVar12) {
                func_0x(uVar17 + uVar12,0x19);
                uVar6 = param_1[0x16];
                uVar17 = (ulonglong)(ushort)param_1[0x15];
                uVar12 = (ulonglong)*(uint *)(param_1 + 4);
              }
              if (uVar10 - uVar14 <
                  (((uVar6 & 0x7ff) * 2 - (int)uVar17) - (int)uVar12) + (int)uVar15) {
                func_0x(uVar17 + *(longlong *)(param_1 + 4),0x19);
                uVar6 = param_1[0x16];
              }
              if (((uVar6 & 0x3800) != 0) &&
                 (puVar18 = (ushort *)
                            (*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]),
                 (uVar6 & 0x3800) != 0)) {
                do {
                  if ((uVar6 & 0x7ff) < (*puVar18 & 0x7ff)) {
                    func_0x((ulonglong)(ushort)param_1[0x15] + *(longlong *)(param_1 + 4),
                                    0x1a);
                    uVar6 = param_1[0x16];
                  }
                  iVar7 = iVar7 + 1;
                  puVar18 = puVar18 + 1;
                } while (iVar7 < (int)(uVar6 >> 0xb & 7));
              }
              goto LAB_;
            }
            if (*(ushort *)(pbVar16 + uVar14) < 0x400) goto LAB_;
            param_1[1] = param_1[1] | 1;
            uVar5 = param_1[0xe] - 1;
            param_1[0xe] = uVar5;
            if (uVar5 == 0) goto LAB_;
            uVar12 = (ulonglong)uVar5;
          } while ((short)puVar18[(ulonglong)(uVar5 - 1) + 1] < 0);
          uVar12 = (ulonglong)*(uint *)(param_1 + 2);
        }
        else {
LAB_:
          pbVar16 = *(byte **)(param_1 + 4);
          uVar12 = (ulonglong)*(uint *)(param_1 + 2);
        }
      }
      if ((*pbVar16 & 0x40) == 0) {
        *(undefined4 *)(param_1 + 0x13) = 0;
      }
      else {
        *(int *)(param_1 + 0x13) = (int)uVar12;
        *(int *)(param_1 + 2) = (int)uVar12 + 0xe;
        puVar9 = (undefined8 *)func_0x(param_1 + 1);
        uStackX_8 = *puVar9;
        iVar7 = func_0x(&uStackX_8);
        *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar7;
        uVar12 = (ulonglong)*(uint *)(param_1 + 2);
      }
      if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
         (*(ulonglong *)(param_1 + 0xf) < uVar12 + *(longlong *)(param_1 + 4))) {
        cVar4 = func_0x(0x11096e0);
        if ((cVar4 != '\0') &&
           ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0'))))
        {
          cVar4 = func_0x(0x11096e0);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0x9f90ec,0xb191d8,0x886,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),0x12);
        uVar12 = (ulonglong)*(uint *)(param_1 + 2);
      }
      if (((uint)uVar12 == 0) || (0x3f3c < (uint)uVar12)) {
        cVar4 = func_0x(0x11096e0);
        if ((cVar4 != '\0') &&
           ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0'))))
        {
          cVar4 = func_0x(0x11096e0);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0x9f90ec,0xb191d8,0x88b,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),5);
      }
    }
  }
  else if (*(int *)(param_1 + 2) == 0) {
    func_0x(param_1 + 1);
  }
LAB_:
  if ((**(byte **)(param_1 + 4) & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((**(byte **)(param_1 + 4) & 1) == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  (*_DAT_)(1,0xb7a9e0,0xbd6a88,0x10b,0x774650);
  return 0;
}

