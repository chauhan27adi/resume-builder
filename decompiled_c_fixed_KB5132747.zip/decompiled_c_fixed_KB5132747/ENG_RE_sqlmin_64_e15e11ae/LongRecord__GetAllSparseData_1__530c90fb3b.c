
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined8 param_2,undefined8 param_3,longlong param_4)

{
  ushort *puVar1;
  code *pcVar2;
  ushort *puVar3;
  byte bVar4;
  char cVar5;
  ushort uVar6;
  ushort uVar7;
  longlong lVar8;
  longlong lVar9;
  undefined8 *puVar10;
  int iVar11;
  uint uVar12;
  ulonglong uVar13;
  int iVar14;
  uint uVar15;
  uint uVar16;
  ulonglong uVar17;
  byte *pbVar18;
  ulonglong uVar19;
  ushort *puVar20;
  undefined8 uStackX_18;
  
  uStackX_18 = param_3;
  func_0x(param_4);
  iVar14 = 0;
  puVar1 = (ushort *)(param_4 + 2);
  iVar11 = 0;
  if (*(int *)(param_4 + 4) == 0) {
    pbVar18 = *(byte **)(param_4 + 8);
    uVar12 = *(uint *)(param_4 + 0x10);
    uVar13 = (ulonglong)uVar12;
    *puVar1 = 0;
    *(uint *)(param_4 + 0x14) = uVar12;
    bVar4 = *pbVar18;
    if ((bVar4 & 0x10) != 0) {
      uVar12 = uVar12 + 2 + (*(ushort *)(pbVar18 + uVar13) + 7 >> 3);
      uVar13 = (ulonglong)uVar12;
      *(uint *)(param_4 + 0x14) = uVar12;
      bVar4 = *pbVar18;
    }
    if ((bVar4 & 0x20) == 0) {
      *(int *)(param_4 + 4) = (int)uVar13;
      *(undefined2 *)(param_4 + 0x1c) = 0;
      *(int *)(param_4 + 0x18) = (int)uVar13;
    }
    else {
      puVar20 = (ushort *)(pbVar18 + uVar13);
      uVar6 = *puVar20;
      *(ushort *)(param_4 + 0x1c) = uVar6;
      if (uVar6 == 0) {
        cVar5 = func_0x(0x11b37f0);
        if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar5 = func_0x(0x11b37f0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0xaa31fc,0xbc32e8,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),3);
        uVar13 = (ulonglong)*(uint *)(param_4 + 0x14);
        uVar6 = *(ushort *)(param_4 + 0x1c);
      }
      uVar12 = (int)uVar13 + (uVar6 + 1) * 2;
      *(uint *)(param_4 + 0x18) = uVar12;
      if (0x1f9e < uVar12) {
        cVar5 = func_0x(0x11b37f0);
        if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar5 = func_0x(0x11b37f0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xaa31fc,0xbc32e8,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),4);
        uVar6 = *(ushort *)(param_4 + 0x1c);
        uVar12 = *(uint *)(param_4 + 0x18);
      }
      uVar13 = (ulonglong)uVar6;
      uVar6 = puVar20[uVar13];
      *(uint *)(param_4 + 4) = uVar6 & 0x7fff;
      if ((uVar6 & 0x7fff) < uVar12) {
        cVar5 = func_0x(0x11b37f0);
        if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar5 = func_0x(0x11b37f0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xaa31fc,0xbc32e8,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 8),4);
        uVar12 = *(uint *)(param_4 + 0x18);
        uVar13 = (ulonglong)*(ushort *)(param_4 + 0x1c);
      }
      puVar3 = puVar20;
      if ((short)uVar13 != 0) {
        do {
          uVar15 = puVar3[1] & 0x7fff;
          if ((uVar15 < uVar12) || (*(uint *)(param_4 + 4) < uVar15)) {
            cVar5 = func_0x(0x11b37f0);
            if ((cVar5 != '\0') &&
               ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')
                ))) {
              cVar5 = func_0x(0x11b37f0);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0xaa31fc,0xbc32e8,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_4 + 8),4);
          }
          uVar13 = (ulonglong)*(ushort *)(param_4 + 0x1c);
          iVar14 = iVar14 + 1;
          puVar3 = puVar3 + 1;
          uVar12 = uVar15;
        } while (iVar14 < (int)(uint)*(ushort *)(param_4 + 0x1c));
      }
      if ((short)puVar20[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
        lVar8 = *(longlong *)(param_4 + 8);
        do {
          lVar9 = (ulonglong)*(uint *)(param_4 + 0x14) + lVar8;
          uVar12 = *(ushort *)(lVar9 + uVar13 * 2) & 0x7fff;
          if ((int)uVar13 == 1) {
            uVar15 = *(uint *)(param_4 + 0x18);
            uVar13 = (ulonglong)uVar15;
LAB_:
            if ((uVar12 < (uint)uVar13) || (*(uint *)(param_4 + 4) < uVar12)) goto LAB_;
          }
          else {
            uVar15 = *(uint *)(param_4 + 0x18);
            uVar16 = *(ushort *)(lVar9 + -2 + uVar13 * 2) & 0x7fff;
            uVar13 = (ulonglong)uVar16;
            if (uVar15 <= uVar16) goto LAB_;
LAB_:
            func_0x(lVar8,7);
            uVar15 = *(uint *)(param_4 + 0x18);
          }
          uVar16 = (uint)uVar13;
          if ((uVar16 < uVar15) || (*(uint *)(param_4 + 4) < uVar16)) goto LAB_;
          lVar8 = *(longlong *)(param_4 + 8);
          if (*(ushort *)(lVar8 + uVar13) == 5) {
            *puVar1 = *puVar1 | 2;
            *(short *)(param_4 + 0x1c) = *(short *)(param_4 + 0x1c) + -1;
            uVar6 = *(ushort *)(param_4 + 0x2c) & 0xc7ff;
            uVar19 = uVar13 & 0xffff;
            *(short *)(param_4 + 0x2a) = (short)uVar13;
            uVar13 = *(ulonglong *)(param_4 + 8);
            if ((*(ushort *)(uVar19 + 2 + uVar13) >> 0xe & 1) != 0) {
              uVar6 = *(ushort *)(uVar19 + 2 + uVar13) & 0x3800 | uVar6;
            }
            *(ushort *)(param_4 + 0x2c) = uVar6;
            uVar7 = (uVar6 ^ *(ushort *)(uVar19 + 2 + uVar13)) & 0x7ff ^ uVar6;
            *(ushort *)(param_4 + 0x2c) = uVar7;
            uVar17 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 + uVar13 + (uVar6 >> 0xb & 7) * 2 + uVar19
            ;
            if (uVar17 < uVar19 + uVar13) {
              func_0x(uVar19 + uVar13,0x19);
              uVar7 = *(ushort *)(param_4 + 0x2c);
              uVar19 = (ulonglong)*(ushort *)(param_4 + 0x2a);
              uVar13 = (ulonglong)*(uint *)(param_4 + 8);
            }
            if (uVar12 - uVar16 < (((uVar7 & 0x7ff) * 2 - (int)uVar19) - (int)uVar13) + (int)uVar17)
            {
              func_0x(uVar19 + *(longlong *)(param_4 + 8),0x19);
              uVar7 = *(ushort *)(param_4 + 0x2c);
            }
            if ((uVar7 & 0x3800) != 0) {
              puVar20 = (ushort *)
                        (*(longlong *)(param_4 + 8) + (ulonglong)*(ushort *)(param_4 + 0x2a) + 4);
              iVar14 = 0;
              if ((uVar7 & 0x3800) != 0) {
                do {
                  if ((uVar7 & 0x7ff) < (*puVar20 & 0x7ff)) {
                    func_0x((ulonglong)*(ushort *)(param_4 + 0x2a) +
                                    *(longlong *)(param_4 + 8),0x1a);
                    uVar7 = *(ushort *)(param_4 + 0x2c);
                  }
                  iVar14 = iVar14 + 1;
                  puVar20 = puVar20 + 1;
                } while (iVar14 < (int)(uVar7 >> 0xb & 7));
              }
            }
            goto LAB_;
          }
          if (*(ushort *)(lVar8 + uVar13) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar6 = *(short *)(param_4 + 0x1c) - 1;
          *(ushort *)(param_4 + 0x1c) = uVar6;
          if (uVar6 == 0) goto LAB_;
          uVar13 = (ulonglong)uVar6;
        } while ((short)puVar20[(ulonglong)(uVar6 - 1) + 1] < 0);
        pbVar18 = *(byte **)(param_4 + 8);
        uVar13 = (ulonglong)*(uint *)(param_4 + 4);
      }
      else {
LAB_:
        pbVar18 = *(byte **)(param_4 + 8);
        uVar13 = (ulonglong)*(uint *)(param_4 + 4);
      }
    }
    if ((*pbVar18 & 0x40) == 0) {
      *(undefined4 *)(param_4 + 0x26) = 0;
    }
    else {
      *(int *)(param_4 + 0x26) = (int)uVar13;
      *(int *)(param_4 + 4) = (int)uVar13 + 0xe;
      puVar10 = (undefined8 *)func_0x(puVar1);
      uStackX_18 = *puVar10;
      iVar14 = func_0x(&uStackX_18);
      *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + iVar14;
      uVar13 = (ulonglong)*(uint *)(param_4 + 4);
    }
    iVar14 = (int)uVar13;
    if ((*(ulonglong *)(param_4 + 0x1e) != 0) &&
       (*(ulonglong *)(param_4 + 0x1e) < uVar13 + *(longlong *)(param_4 + 8))) {
      cVar5 = func_0x(0x11b37f0);
      if ((cVar5 != '\0') &&
         ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')))) {
        cVar5 = func_0x(0x11b37f0);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0xaa31fc,0xbc32e8,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(param_4 + 8),0x12);
      iVar14 = *(int *)(param_4 + 4);
    }
    if (0x3f3b < iVar14 - 1U) {
      cVar5 = func_0x(0x11b37f0);
      if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
         (*(char *)(lVar8 + 0x499) != '\0')) {
        cVar5 = func_0x(0x11b37f0);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0xaa31fc,0xbc32e8,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(param_4 + 8),5);
    }
  }
LAB_:
  iVar14 = func_0x(puVar1);
  if (iVar14 != 0) {
    uVar6 = *(ushort *)(param_4 + 0x2c);
    uVar12 = (uint)uVar6;
    iVar11 = *(int *)(param_4 + 4) - (uint)*(ushort *)(param_4 + 0x2a);
    iVar14 = iVar11 + -10;
    if ((*(byte *)puVar1 & 1) == 0) {
      iVar14 = iVar11;
    }
    if ((**(byte **)(param_4 + 8) & 0x40) != 0) {
      lVar8 = func_0x(puVar1,&uStackX_18);
      uVar15 = 0;
      uVar6 = *(ushort *)(lVar8 + 6);
      uVar7 = uVar6;
      if ((((uint)(int)(short)uVar6 >> 1 ^ (int)(short)uVar6) & 0x2000) != 0) {
        uVar7 = uVar6 & 0xdfff;
        if ((uVar6 >> 0xe & 1) != 0) {
          uVar7 = uVar6 | 0x2000;
        }
      }
      if (uVar7 == 0xfffc) {
        uVar15 = (uint)(*(ushort *)(lVar8 + 4) >> 5);
      }
      uVar6 = *(ushort *)(param_4 + 0x2c);
      iVar14 = (iVar14 - uVar15) + -0xe;
    }
    iVar11 = (uVar12 & 0x7ff) * 4 + -4 + iVar14 + ((uVar6 >> 0xb & 7) + (uVar6 & 0x7ff)) * -2;
  }
  uVar6 = func_0x(param_2);
  if ((uint)uVar6 < iVar11 + 0x17U) {
    (*_DAT_)(1,0xc7fc40,0xc7fc10,0x4cd,0);
  }
  func_0x();
  pcVar2 = (code *)swi(3);
  (*pcVar2)();
  return;
}

