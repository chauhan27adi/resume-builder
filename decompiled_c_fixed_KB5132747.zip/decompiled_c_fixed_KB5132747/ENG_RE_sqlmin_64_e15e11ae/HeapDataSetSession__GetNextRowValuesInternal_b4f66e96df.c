
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,longlong **param_3,uint param_4,undefined8 *param_5)

{
  ushort *puVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  char cVar5;
  byte bVar6;
  ushort uVar7;
  ushort uVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  longlong lVar12;
  byte **ppbVar13;
  undefined8 uVar14;
  longlong **pplVar15;
  short *psVar16;
  longlong lVar17;
  longlong *plVar18;
  uint uVar19;
  undefined4 uVar20;
  longlong *plVar21;
  byte *pbVar22;
  code *UNRECOVERED_JUMPTABLE;
  ulonglong uVar23;
  ulonglong uVar24;
  uint uVar25;
  longlong lVar26;
  undefined *puVar27;
  undefined *puVar28;
  short sVar29;
  uint uVar30;
  uint uVar31;
  longlong **pplVar32;
  longlong **pplVar33;
  ulonglong uVar34;
  byte *pbVar35;
  ushort *puVar36;
  ushort *puVar37;
  longlong unaff_GS_OFFSET;
  bool bVar38;
  undefined8 uStack_580;
  undefined auStack_578 [32];
  undefined8 uStack_558;
  uint uStack_550;
  undefined8 uStack_548;
  undefined8 uStack_540;
  undefined8 uStack_538;
  uint uStack_518;
  undefined4 uStack_514;
  undefined8 uStack_510;
  longlong **pplStack_508;
  char cStack_500;
  undefined4 uStack_4fc;
  uint auStack_4f8 [2];
  longlong *plStack_4f0;
  int iStack_4e8;
  undefined4 uStack_4e4;
  char cStack_4dc;
  undefined4 uStack_4cc;
  undefined8 uStack_4c8;
  undefined2 uStack_4c0;
  int iStack_4bc;
  int iStack_4b8;
  uint uStack_4b0;
  undefined4 uStack_4ac;
  undefined2 uStack_4a8;
  ushort *puStack_4a0;
  uint uStack_498;
  uint uStack_494;
  longlong **pplStack_490;
  undefined8 uStack_488;
  uint uStack_480;
  uint uStack_47c;
  undefined4 uStack_470;
  undefined2 uStack_46c;
  undefined2 uStack_46a;
  longlong lStack_468;
  longlong lStack_460;
  longlong *plStack_458;
  longlong lStack_450;
  int iStack_434;
  int iStack_430;
  int aiStack_42c [3];
  int aiStack_420 [2];
  longlong lStack_418;
  undefined4 uStack_3c4;
  undefined2 uStack_3c0;
  undefined4 uStack_3be;
  undefined2 uStack_3ba;
  int iStack_388;
  int iStack_384;
  uint uStack_380;
  int iStack_37c;
  undefined4 uStack_378;
  undefined2 uStack_374;
  undefined2 uStack_372;
  undefined4 uStack_370;
  undefined2 uStack_36c;
  undefined2 uStack_36a;
  uint auStack_368 [4];
  int iStack_358;
  undefined8 *puStack_350;
  undefined auStack_328 [40];
  undefined8 uStack_300;
  undefined8 uStack_2f8;
  undefined auStack_2f0 [4];
  undefined auStack_2ec [44];
  longlong alStack_2c0 [2];
  undefined auStack_2b0 [8];
  undefined auStack_2a8 [80];
  undefined4 uStack_258;
  undefined4 uStack_254;
  undefined4 uStack_250;
  undefined4 uStack_24c;
  short sStack_248;
  undefined4 uStack_244;
  byte *pbStack_240;
  byte **ppbStack_238;
  undefined8 uStack_22a;
  undefined2 uStack_222;
  undefined2 uStack_220;
  undefined6 uStack_21e;
  int iStack_214;
  undefined auStack_210 [16];
  undefined auStack_200 [16];
  undefined auStack_1f0 [16];
  undefined auStack_1e0 [16];
  undefined auStack_1d0 [16];
  undefined auStack_1c0 [16];
  undefined auStack_1b0 [16];
  undefined8 uStack_1a0;
  undefined auStack_198 [14];
  undefined uStack_18a;
  undefined auStack_188 [14];
  undefined uStack_17a;
  undefined auStack_178 [14];
  undefined uStack_16a;
  undefined auStack_168 [16];
  undefined auStack_158 [16];
  undefined auStack_148 [240];
  ulonglong uStack_58;
  
  puVar27 = auStack_578;
  uStack_58 = _DAT_ ^ (ulonglong)&uStack_538;
  puStack_350 = param_5;
  uStack_580 = 0x100067;
  pplStack_508 = param_3;
  iStack_4b8 = param_2;
  uStack_480 = param_4;
  lStack_460 = param_1;
  cVar5 = func_0x(0x1ee7ee0);
  if ((cVar5 == '\0') ||
     (cStack_4dc = '\x01', (*(uint *)(*(longlong *)(param_1 + 0x108) + 8) >> 1 & 1) == 0)) {
    cStack_4dc = '\0';
  }
  puVar28 = auStack_578;
  if ((*(byte *)(param_1 + 0x2e8) & 4) != 0) {
    plVar21 = (longlong *)0x0;
    if (*(int *)(param_1 + 0x1c8) == 0) {
      if ((*(longlong *)(param_1 + 0x158) != 0) || (uVar19 = 0, *(longlong *)(param_1 + 0x160) != 0)
         ) {
        uVar19 = 1;
      }
      if ((*(byte *)((longlong)param_3 + 0x14) & 0x10) != 0) {
        plVar21 = *param_3;
      }
      if (*(int *)(param_1 + 0x1b8) == 0) {
        if (plVar21 == (longlong *)0x0) {
          bVar38 = *(longlong *)(param_1 + 0x1c0) == -1;
        }
        else {
          bVar38 = plVar21[0x1c] == *(longlong *)(param_1 + 0x1c0);
        }
        param_2 = iStack_4b8;
        if (bVar38) goto LAB_;
      }
      uStack_580 = 0x10013e;
      uStack_558 = plVar21;
      uStack_550 = uVar19;
      uStack_548 = *(undefined8 *)(param_1 + 0x170);
      uStack_540 = *(undefined8 *)(param_1 + 0x178);
      func_0x(param_1 + 0x1d4,**(undefined8 **)(param_1 + 0x2e0));
      *(undefined4 *)(param_1 + 0x1b8) = 0;
      param_2 = iStack_4b8;
    }
    else {
      *(undefined4 *)(param_1 + 0x1d4) = 1;
    }
LAB_:
    pplVar32 = (longlong **)(param_1 + 0xa28);
    uStack_4e4 = aiStack_42c[0];
    iVar9 = aiStack_42c[0];
    pplStack_490 = pplVar32;
LAB_:
    plStack_4f0 = *(longlong **)(param_1 + 0xa18);
    iStack_434 = *(int *)(param_1 + 0x1d4);
    if (*(int *)(plStack_4f0 + 1) == 1) {
      iStack_4e8 = -1;
      iStack_4bc = 1;
      uStack_518 = 0;
      lStack_468 = *(longlong *)(plStack_4f0[3] + 0x18);
      uStack_538._4_4_ = 0;
      uStack_538._0_4_ = 0;
      uStack_47c = 1;
      uVar19 = 0;
      uVar25 = 0;
LAB_:
      do {
        iVar11 = iStack_4e8;
        uVar30 = uStack_518;
        lVar12 = plStack_4f0[0x58];
        if (lVar12 == 0) {
          *(uint *)((longlong)plStack_4f0 + 0x66c) =
               *(uint *)((longlong)plStack_4f0 + 0x66c) & 0xfffffffe;
          if (*(int *)(plStack_4f0 + 0x75) == 4) {
            uStack_580 = 0x100204;
            func_0x(plStack_4f0 + 0x5d);
          }
          uStack_580 = 0x100211;
          lVar12 = func_0x(plStack_4f0 + 0xd);
          if (*(char *)(plStack_4f0[0xc] + 0xb5) == '\0') {
            *(uint *)((longlong)plStack_4f0 + 0x66c) = *(uint *)((longlong)plStack_4f0 + 0x66c) | 1;
          }
          if (lVar12 != 0) goto LAB_;
LAB_:
          if (iVar11 != -1) {
            iVar11 = *(int *)(plStack_4f0 + 0x5a);
            if (*(int *)((longlong)plStack_4f0 + 0x2d4) == 0) {
              if ((*(char *)(lStack_468 + 3) == '\0') &&
                 (*(longlong *)(*(longlong *)(*(longlong *)(plStack_4f0[2] + 8) + 0x30) + 0x1b28) ==
                  0)) {
                iVar11 = 0;
              }
              else if (((*(byte *)(lStack_468 + 4) & 8) == 0) ||
                      ((*(longlong *)(lStack_468 + 0x10) != 0 || ((DAT_ & 4) != 0)))) {
LAB_:
                iVar11 = 2;
              }
              else {
                lVar26 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
                if ((lVar26 != 0) && (lVar26 = **(longlong **)(lVar26 + 0x38), lVar26 != 0)) {
                  uStack_580 = 0x100899;
                  iVar11 = (*_DAT_)(lVar26,0x4c2);
                  if (iVar11 != 0) goto LAB_;
                }
                plVar21 = plStack_4f0 + 0xd1;
                uStack_580 = 0x1008bd;
                uVar14 = func_0x(lVar12,auStack_168);
                uStack_580 = 0x1008c8;
                iVar10 = func_0x(uVar14,plVar21);
                iVar11 = 3;
                uVar19 = (uint)uStack_538;
                if (iVar10 != 0) {
                  iVar11 = 1;
                }
              }
              *(int *)(plStack_4f0 + 0x5a) = iVar11;
              *(undefined4 *)((longlong)plStack_4f0 + 0x2d4) = 1;
            }
            if (iVar11 == 0) goto LAB_;
            if (iVar11 == 1) {
              if (iStack_434 == 1) goto LAB_;
            }
            else if (iVar11 != 2) {
              if (iVar11 != 3) {
                uStack_558 = (longlong *)0x1552e50;
                uStack_580 = 0x10092f;
                (*_DAT_)(1,0x19591e0);
                goto LAB_;
              }
              if (iStack_434 == 1) {
                uStack_518 = 1;
                iStack_4bc = 0;
                uStack_47c = ~(*(uint *)(*(longlong *)(plStack_4f0[3] + 0x18) + 4) >> 2) & 1;
                uVar30 = 1;
                goto LAB_;
              }
            }
            uStack_518 = 1;
            iStack_4bc = 1;
            uStack_47c = ~(*(uint *)(*(longlong *)(plStack_4f0[3] + 0x18) + 4) >> 2) & 1;
            uVar30 = 1;
LAB_:
            plVar21 = plStack_4f0 + 7;
            plStack_458 = plVar21;
LAB_:
            iVar11 = 0;
            *(uint *)((longlong)plVar21 + 0x634) = *(uint *)((longlong)plVar21 + 0x634) & 0xfffffffe
            ;
            uStack_488 = uStack_488 & 0xffffffff00000000;
            uStack_538._0_4_ = uVar19;
LAB_:
            plVar18 = plVar21;
            uStack_538._4_4_ = uVar25;
            if ((*(int *)(plVar21 + 0x6e) == 4) &&
               ((plVar4 = plVar21 + 0x56, plVar21[0x58] != _DAT_ ||
                (plVar18 = plStack_458, plVar21[0x59] != _DAT_)))) {
              if ((*(byte *)(plVar21 + 100) & 2) != 0) {
                uStack_580 = 0x100a09;
                iVar10 = func_0x(plVar21 + 0x65);
                if (iVar10 != 0) {
                  *(longlong *)(*plVar4 + 0x30) = *(longlong *)(*plVar4 + 0x30) + -1;
                }
              }
              *(undefined *)(plVar21 + 100) = 0;
              *(undefined4 *)((longlong)plVar21 + 0x31c) = 0;
              *(undefined4 *)(plVar21 + 0x67) = 0;
              if ((*(byte *)(plVar21 + 0x6a) & 2) != 0) {
                uStack_580 = 0x100a3b;
                iVar10 = func_0x(plVar21 + 0x6b);
                if (iVar10 != 0) {
                  *(longlong *)(*plVar4 + 0x30) = *(longlong *)(*plVar4 + 0x30) + -1;
                }
              }
              *(undefined *)(plVar21 + 0x6a) = 0;
              *(undefined4 *)((longlong)plVar21 + 0x34c) = 0;
              *(undefined4 *)(plVar21 + 0x6d) = 0;
              if (plVar21[0x5b] != 0) {
                *(undefined *)((longlong)plVar21 + 0x2e6) = 0;
                plVar21[0x5b] = 0;
                *(undefined2 *)((longlong)plVar21 + 0x2e4) = 0;
                *(undefined4 *)(plVar21[0x58] + 0x48) = 0;
              }
              uStack_580 = 0x100a89;
              func_0x(*(undefined8 *)*plVar4,plVar21 + 0x58);
              uStack_580 = 0x100a91;
              func_0x(plVar4);
              *(undefined4 *)(plVar21 + 0x6e) = 2;
              plVar18 = plStack_458;
            }
            plVar21 = plVar18;
            if (iVar11 < 1) {
              if (iVar11 != 0) goto LAB_;
LAB_:
              plVar18 = plVar21 + 6;
              bVar38 = uVar30 == 0;
              lVar12 = *(longlong *)(plVar21[7] + 8);
              pbStack_240 = (byte *)0x0;
              sStack_248 = -1;
              iStack_214 = 0xffffffff;
              uStack_244 = 0;
              uStack_22a = 0;
              uStack_220 = 0;
              uStack_21e = 0;
              ppbStack_238 = (byte **)0x0;
              uStack_4ac = 0;
              uStack_4a8 = 0;
              lStack_418 = *(longlong *)(*plVar18 + 0x18);
              cStack_500 = bVar38;
              lStack_450 = lVar12;
              if ((*(byte *)(plVar21 + 0x14) & 2) != 0) {
                uStack_580 = 0x100b85;
                iVar9 = func_0x(plVar21 + 0x15);
                if (iVar9 != 0) {
                  *(longlong *)(*plVar18 + 0x30) = *(longlong *)(*plVar18 + 0x30) + -1;
                }
              }
              *(undefined *)(plVar21 + 0x14) = 0;
              *(undefined4 *)((longlong)plVar21 + 0x9c) = 0;
              *(undefined4 *)(plVar21 + 0x17) = 0;
              *(int *)(plVar21 + 10) = iStack_4e8;
              if (((((*(uint *)(plVar21[0x20] + 0x10) & 1) != 0) &&
                   ((*(uint *)(plVar21[0x20] + 0x10) & 0x40) == 0)) &&
                  (*(char *)(*(longlong *)(lVar12 + 0x30) + 0x1cd2) != '\0')) &&
                 (*(char *)(*(longlong *)(lVar12 + 0x30) + 0x2050) == '\0')) {
                uStack_17a = 1;
                uStack_378 = *(undefined4 *)(*(longlong *)plVar21[0xb] + 0x20);
                uStack_374 = *(undefined2 *)(*(longlong *)plVar21[0xb] + 0x24);
                uStack_372 = (undefined2)*(undefined4 *)(plVar21 + 10);
                uStack_580 = 0x100c2c;
                func_0x
                          (auStack_188,*(undefined2 *)(*(longlong *)(lVar12 + 0x30) + 0x6b8),
                           &uStack_378);
                uStack_580 = 0x100c40;
                cVar5 = func_0x(lVar12,3,auStack_188);
                if (cVar5 == '\0') {
                  uStack_580 = 0x100c4c;
                  func_0x(plVar18);
                  uStack_558 = (longlong *)CONCAT71(uStack_558._1_7_,1);
                  uStack_580 = 0x100c6d;
                  func_0x(lVar12,3,*(undefined4 *)(*(longlong *)(*plVar18 + 0x18) + 0x18));
                  if (plVar21[0xb] == 0) {
                    uStack_580 = 0x100c7e;
                    func_0x(plVar18,0);
                  }
                }
              }
              uStack_4c0 = _DAT_;
              uStack_498 = _DAT_;
              while( true ) {
                uStack_494 = (uint)uStack_538;
                uStack_4b0 = uVar25;
                if (((*(char *)(plVar21[7] + 0x29) != '\0') &&
                    ((*(uint *)(lStack_418 + 4) & 0x140) == 0)) &&
                   (lVar26 = plVar21[0x51], lVar12 = lStack_450,
                   *(ushort *)(plVar21 + 10) < *(ushort *)(lVar26 + 0x16))) {
                  iVar9 = *(int *)(plVar21 + 10);
                  puStack_4a0 = (ushort *)(0xfff - (longlong)iVar9);
                  if (*(short *)(lVar26 + (longlong)puStack_4a0 * 2) != 0) {
                    iStack_214 = iVar9;
                    if (*(char *)(lVar26 + 2) < '\0') {
                      pbVar35 = (byte *)(lVar26 + 0x60);
                      if ((sStack_248 == 0) ||
                         (ppbVar13 = ppbStack_238, ppbStack_238 == (byte **)0x0)) {
                        auStack_210 = ZEXT816(0);
                        uStack_1a0 = 0;
                        auStack_200 = ZEXT816(0);
                        auStack_1f0 = ZEXT816(0);
                        auStack_1e0 = ZEXT816(0);
                        auStack_1d0 = ZEXT816(0);
                        auStack_1c0 = ZEXT816(0);
                        auStack_1b0 = ZEXT816(0);
                        uStack_580 = 0x100d85;
                        ppbVar13 = (byte **)func_0x(auStack_210);
                      }
                      uStack_580 = 0x100d9d;
                      uVar14 = func_0x(lVar26,auStack_158,0,0);
                      if (pbVar35 == *ppbVar13) {
                        uStack_580 = 0x100db1;
                        func_0x(uVar14,ppbVar13 + 0xc);
                      }
                      *ppbVar13 = pbVar35;
                      uStack_580 = 0x100dc0;
                      func_0x(ppbVar13 + 0xc,uVar14);
                      uStack_580 = 0x100dcd;
                      func_0x((longlong)ppbVar13 + 0x6c,lVar26 + 0x20);
                      uVar20 = *(undefined4 *)((ulonglong)*pbVar35 * 6 + 0x15d1730);
                      sVar29 = *(short *)((ulonglong)*pbVar35 * 6 + 0x15d1734);
                      uStack_4c8 = (longlong *)CONCAT44(uStack_4c8._4_4_,uVar20);
                      plVar21 = uStack_4c8;
                      *(undefined2 *)(ppbVar13 + 2) = 0xffff;
                      ppbVar13[3] = (byte *)0x0;
                      *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
                      *(undefined8 *)((longlong)ppbVar13 + 0x2e) = 0;
                      ppbVar13[7] = (byte *)0x0;
                      ppbVar13[4] = (byte *)0x0;
                      ppbVar13[9] = (byte *)0x0;
                      ppbVar13[10] = (byte *)0x0;
                      *(undefined2 *)(ppbVar13 + 0xb) = 0;
                      uStack_4e4 = CONCAT22(uStack_4e4._2_2_,sVar29);
                      if ((**ppbVar13 & 2) != 0) {
                        pbVar22 = pbVar35 + sVar29;
                        if ((pbVar35[sVar29] & 1) != 0) {
                          *(undefined2 *)(ppbVar13 + 2) = 1;
                          ppbVar13[3] = pbVar22;
                          uStack_538._0_4_ = uStack_494;
                          uStack_538._4_4_ = uStack_4b0;
                          UNRECOVERED_JUMPTABLE =
                               (code *)((ulonglong)
                                        *(uint *)((ulonglong)
                                                  *(byte *)((longlong)(int)(*pbVar22 & 0x1c) +
                                                           0x1097c8) * 4 + 0x1097b8) - 0xfc76e0);
                    /* WARNING: Could not emulate address calculation at 0x00100e78 */
                    /* WARNING: Treating indirect jump as call */
                          (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                          return;
                        }
                        *(undefined2 *)(ppbVar13 + 2) = 0;
                        ppbVar13[3] = pbVar22;
                        *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
                        *(undefined4 *)((longlong)ppbVar13 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101038 */
                    /* WARNING: Treating indirect jump as call */
                        (*(code *)((ulonglong)
                                   *(uint *)((longlong)(int)(*pbVar22 & 0xe) * 4 + 0x1097e8) -
                                  0xfc76e0))();
                        return;
                      }
                      if ((**ppbVar13 & 4) != 0) {
                        uStack_4c8._2_2_ = (short)((uint)uVar20 >> 0x10);
                        if (uStack_4c8._2_2_ == 0) {
                          uVar24 = (ulonglong)sVar29;
                        }
                        else {
                          uVar24 = (ulonglong)
                                   *(ushort *)(lVar26 + 0x61 + (longlong)uStack_4c8._2_2_ * 2);
                        }
                        uStack_580 = 0x1010e8;
                        uStack_4c8 = plVar21;
                        func_0x(ppbVar13 + 9,pbVar35 + uVar24);
                      }
                      if (ppbVar13[1] != (byte *)0x0) {
                        uStack_580 = 0x1010fc;
                        func_0x(ppbVar13[1],ppbVar13);
                      }
                    }
                    pbStack_240 = (byte *)((ulonglong)
                                           *(ushort *)(lVar26 + (longlong)puStack_4a0 * 2) + lVar26)
                    ;
                    if ((*pbStack_240 & 1) != 0) {
                      sStack_248 = 1;
                      UNRECOVERED_JUMPTABLE =
                           (code *)((ulonglong)
                                    *(uint *)((ulonglong)
                                              *(byte *)((longlong)(int)(*pbStack_240 & 0x1c) +
                                                       0x109834) * 4 + 0x109824) - 0xfc76e0);
                    /* WARNING: Could not emulate address calculation at 0x0010114e */
                    /* WARNING: Treating indirect jump as call */
                      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                      return;
                    }
                    sStack_248 = 0;
                    uStack_244 = 0;
                    uStack_222 = 0;
                    uStack_220 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101368 */
                    /* WARNING: Treating indirect jump as call */
                    (*(code *)((ulonglong)
                               *(uint *)((longlong)(int)(*pbStack_240 & 0xe) * 4 + 0x109854) -
                              0xfc76e0))();
                    return;
                  }
                }
                lVar26 = lStack_418;
                if (bVar38 != false) break;
                uStack_16a = 1;
                uStack_370 = *(undefined4 *)(*(longlong *)plVar21[0xb] + 0x20);
                uStack_36c = *(undefined2 *)(*(longlong *)plVar21[0xb] + 0x24);
                uStack_36a = (undefined2)*(undefined4 *)(plVar21 + 10);
                uStack_580 = 0x1015c9;
                func_0x
                          (auStack_178,*(undefined2 *)(*(longlong *)(lVar12 + 0x30) + 0x6b8),
                           &uStack_370);
                lVar26 = lStack_418;
                uStack_540 = CONCAT44(uStack_540._4_4_,iStack_4bc);
                uStack_548 = CONCAT44(uStack_548._4_4_,uStack_47c);
                uStack_550 = uStack_518;
                uStack_580 = 0x101605;
                uStack_558 = plVar21 + 0x12;
                iVar9 = func_0x(plVar18);
                if (iVar9 < 0) {
                  *(undefined4 *)(plVar21 + 0x1e) = 3;
                  *(undefined4 *)(plVar21 + 10) = 0xffffffff;
                  iVar9 = 1;
                  *(uint *)((longlong)plStack_4f0 + 0x66c) =
                       *(uint *)((longlong)plStack_4f0 + 0x66c) | 1;
                  uStack_4e4 = 1;
                  uVar19 = (uint)uStack_538;
                  goto LAB_;
                }
                if (iVar9 != 1) break;
                bVar38 = true;
                cStack_500 = bVar38;
              }
              *(undefined4 *)(plVar21 + 0x1e) = 4;
              lVar12 = *(longlong *)(lVar12 + 0x30);
              if (*(longlong *)(lVar12 + 0x1b28) != 0) {
                if (((((*(uint *)(plVar21[0x20] + 0x10) & 1) == 0) ||
                     ((*(uint *)(plVar21[0x20] + 0x10) & 0x40) != 0)) ||
                    (*(char *)(lVar12 + 0x1cd2) == '\0')) || (*(char *)(lVar12 + 0x2050) != '\0')) {
                  if (uStack_518 == 1) {
                    uStack_580 = 0x10167b;
                    cVar5 = func_0x(lVar26);
                    if (cVar5 == '\0') goto LAB_;
                  }
                }
                else {
LAB_:
                  lVar12 = plVar21[0x51];
                  if (*(ushort *)(plVar21 + 10) < *(ushort *)(lVar12 + 0x16)) {
                    iVar9 = *(int *)(plVar21 + 10);
                    puStack_4a0 = (ushort *)(0xfff - (longlong)iVar9);
                    if (*(short *)(lVar12 + (longlong)puStack_4a0 * 2) != 0) {
                      iStack_214 = iVar9;
                      if (*(char *)(lVar12 + 2) < '\0') {
                        pbVar35 = (byte *)(lVar12 + 0x60);
                        if ((sStack_248 == 0) ||
                           (ppbVar13 = ppbStack_238, ppbStack_238 == (byte **)0x0)) {
                          auStack_210 = ZEXT816(0);
                          uStack_1a0 = 0;
                          auStack_200 = ZEXT816(0);
                          auStack_1f0 = ZEXT816(0);
                          auStack_1e0 = ZEXT816(0);
                          auStack_1d0 = ZEXT816(0);
                          auStack_1c0 = ZEXT816(0);
                          auStack_1b0 = ZEXT816(0);
                          uStack_580 = 0x101738;
                          ppbVar13 = (byte **)func_0x(auStack_210);
                        }
                        uStack_580 = 0x101750;
                        uVar14 = func_0x(lVar12,auStack_148,0,0);
                        if (pbVar35 == *ppbVar13) {
                          uStack_580 = 0x101764;
                          func_0x(uVar14,ppbVar13 + 0xc);
                        }
                        *ppbVar13 = pbVar35;
                        uStack_580 = 0x101773;
                        func_0x(ppbVar13 + 0xc,uVar14);
                        uStack_580 = 0x101780;
                        func_0x((longlong)ppbVar13 + 0x6c,lVar12 + 0x20);
                        uVar20 = *(undefined4 *)((ulonglong)*pbVar35 * 6 + 0x15d1730);
                        sVar29 = *(short *)((ulonglong)*pbVar35 * 6 + 0x15d1734);
                        uStack_510 = (short *)CONCAT44(uStack_510._4_4_,uVar20);
                        psVar16 = uStack_510;
                        *(undefined2 *)(ppbVar13 + 2) = 0xffff;
                        ppbVar13[3] = (byte *)0x0;
                        *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
                        *(undefined8 *)((longlong)ppbVar13 + 0x2e) = 0;
                        ppbVar13[7] = (byte *)0x0;
                        ppbVar13[4] = (byte *)0x0;
                        ppbVar13[9] = (byte *)0x0;
                        ppbVar13[10] = (byte *)0x0;
                        *(undefined2 *)(ppbVar13 + 0xb) = 0;
                        uStack_4e4 = CONCAT22(uStack_4e4._2_2_,sVar29);
                        if ((**ppbVar13 & 2) != 0) {
                          pbVar22 = pbVar35 + sVar29;
                          if ((pbVar35[sVar29] & 1) != 0) {
                            *(undefined2 *)(ppbVar13 + 2) = 1;
                            ppbVar13[3] = pbVar22;
                            uStack_538._0_4_ = uStack_494;
                            uStack_538._4_4_ = uStack_4b0;
                            UNRECOVERED_JUMPTABLE =
                                 (code *)((ulonglong)
                                          *(uint *)((ulonglong)
                                                    *(byte *)((longlong)(int)(*pbVar22 & 0x1c) +
                                                             0x1098a0) * 4 + 0x109890) - 0xfc76e0);
                    /* WARNING: Could not emulate address calculation at 0x0010182b */
                    /* WARNING: Treating indirect jump as call */
                            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                            return;
                          }
                          *(undefined2 *)(ppbVar13 + 2) = 0;
                          ppbVar13[3] = pbVar22;
                          *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
                          *(undefined4 *)((longlong)ppbVar13 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001019e2 */
                    /* WARNING: Treating indirect jump as call */
                          (*(code *)((ulonglong)
                                     *(uint *)((longlong)(int)(*pbVar22 & 0xe) * 4 + 0x1098c0) -
                                    0xfc76e0))();
                          return;
                        }
                        if ((**ppbVar13 & 4) != 0) {
                          uStack_510._2_2_ = (short)((uint)uVar20 >> 0x10);
                          if (uStack_510._2_2_ == 0) {
                            uVar24 = (ulonglong)sVar29;
                          }
                          else {
                            uVar24 = (ulonglong)
                                     *(ushort *)(lVar12 + 0x61 + (longlong)uStack_510._2_2_ * 2);
                          }
                          uStack_580 = 0x101a92;
                          uStack_510 = psVar16;
                          func_0x(ppbVar13 + 9,pbVar35 + uVar24);
                        }
                        if (ppbVar13[1] != (byte *)0x0) {
                          uStack_580 = 0x101aa6;
                          func_0x(ppbVar13[1],ppbVar13);
                        }
                      }
                      pbStack_240 = (byte *)((ulonglong)
                                             *(ushort *)(lVar12 + (longlong)puStack_4a0 * 2) +
                                            lVar12);
                      if ((*pbStack_240 & 1) != 0) {
                        sStack_248 = 1;
                        UNRECOVERED_JUMPTABLE =
                             (code *)((ulonglong)
                                      *(uint *)((ulonglong)
                                                *(byte *)((longlong)(int)(*pbStack_240 & 0x1c) +
                                                         0x10990c) * 4 + 0x1098fc) - 0xfc76e0);
                    /* WARNING: Could not emulate address calculation at 0x00101af4 */
                    /* WARNING: Treating indirect jump as call */
                        (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                        return;
                      }
                      sStack_248 = 0;
                      uStack_244 = 0;
                      uStack_222 = 0;
                      uStack_220 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101d0e */
                    /* WARNING: Treating indirect jump as call */
                      (*(code *)((ulonglong)
                                 *(uint *)((longlong)(int)(*pbStack_240 & 0xe) * 4 + 0x10992c) -
                                0xfc76e0))();
                      return;
                    }
                  }
                }
              }
              uStack_580 = 0x101e6d;
              func_0x(plVar18,1);
              uStack_538._4_4_ = *(uint *)(plVar21 + 0x4d);
              uStack_538._0_4_ = *(uint *)((longlong)plVar21 + 0x26c);
              iVar9 = 0;
              uStack_4e4 = 0;
              plVar21 = plStack_458;
              iVar11 = (int)uStack_488;
              uVar25 = uStack_538._4_4_;
            }
            else {
              if (plVar21[0xb] == 0) {
                uStack_580 = 0x100abd;
                func_0x(plVar21 + 6,0);
              }
              if (*(int *)(plVar21 + 0x4e) == 0) {
                uStack_580 = 0x100ad2;
                func_0x(plVar21 + 6,1);
              }
              uStack_538._4_4_ = *(uint *)(plVar21 + 0x4d);
              uStack_538._0_4_ = *(uint *)((longlong)plVar21 + 0x26c);
              uVar25 = uStack_538._4_4_;
LAB_:
              if (*(char *)(plVar21[5] + 0x29) != '\0') goto LAB_;
              if (iVar9 != 0) goto LAB_;
            }
            uVar30 = uStack_518;
            if ((uVar25 != 3) ||
               ((*(char *)(*(longlong *)(plVar21[4] + 0x18) + 3) != '\0' &&
                ((uStack_518 == 0 || (iStack_4bc == 0)))))) goto LAB_;
            bVar38 = false;
            if (*(char *)(plVar21[5] + 0x29) == '\0') {
              uStack_580 = 0x101f55;
              cVar5 = func_0x();
              if ((cVar5 == '\0') || (2 < iVar11)) goto LAB_;
              uStack_470 = 0;
              uStack_46c = 0;
              uStack_46a = 0;
              uStack_580 = 0x101f8e;
              iVar10 = func_0x(plVar21,1,1);
            }
            else {
              bVar38 = iVar11 < 0x32;
LAB_:
              uStack_470 = 0;
              uStack_46c = 0;
              uStack_46a = 0;
              uStack_580 = 0x101f06;
              iVar10 = func_0x(plVar21,1,bVar38);
              if (bVar38 == false) goto LAB_;
            }
            if (1 < iVar10 - 1U) goto LAB_;
            iVar11 = iVar11 + 1;
            uStack_488 = CONCAT44(uStack_488._4_4_,iVar11);
            uStack_580 = 0x101f28;
            func_0x(plVar21 + 6);
            uVar19 = (uint)uStack_538;
            uStack_538._0_4_ = uVar19;
            if (*(char *)(plVar21[5] + 0x29) == '\0') {
              uStack_580 = 0x101f48;
              func_0x(10);
              uStack_538._0_4_ = uVar19;
            }
            goto LAB_;
          }
        }
        else {
LAB_:
          if (*(int *)((longlong)plStack_4f0 + 0x34) == 0) {
            iStack_4e8 = iStack_4b8 + *(int *)(plStack_4f0 + 6);
          }
          else {
            *(undefined4 *)((longlong)plStack_4f0 + 0x34) = 0;
            iStack_4e8 = *(int *)((longlong)plStack_4f0 + 0x684);
            if (iStack_4e8 == -1) {
              iStack_4e8 = (int)*(short *)((longlong)plStack_4f0 + 0x682);
              if (*(short *)((longlong)plStack_4f0 + 0x682) == -1) {
                if (iStack_4b8 == 1) {
                  iStack_4e8 = 0;
                }
                else {
                  iStack_4e8 = *(ushort *)(lVar12 + 0x16) - 1;
                }
              }
            }
            else {
              *(undefined4 *)((longlong)plStack_4f0 + 0x684) = 0xffffffff;
            }
          }
          if ((ushort)iStack_4e8 < *(ushort *)(lVar12 + 0x16)) {
            if ((*(short *)((longlong)plStack_4f0 + 0x682) == -1) ||
               (iStack_4e8 == *(short *)((longlong)plStack_4f0 + 0x682))) {
              *(int *)(plStack_4f0 + 6) = iStack_4e8;
              iVar11 = iStack_4e8;
              goto LAB_;
            }
            iStack_4e8 = -1;
          }
          else {
            iStack_4e8 = -1;
          }
        }
        plVar18 = plStack_4f0;
        plVar21 = plStack_4f0 + 0xd;
        if ((plStack_4f0[0xf] != _DAT_) || (plStack_4f0[0x10] != _DAT_)) {
          if ((*(byte *)(plStack_4f0 + 0x1b) & 2) != 0) {
            uStack_580 = 0x100308;
            iVar9 = func_0x(plStack_4f0 + 0x1c);
            if (iVar9 != 0) {
              *(longlong *)(*plVar21 + 0x30) = *(longlong *)(*plVar21 + 0x30) + -1;
            }
          }
          *(undefined *)(plVar18 + 0x1b) = 0;
          *(undefined4 *)((longlong)plVar18 + 0xd4) = 0;
          *(undefined4 *)(plVar18 + 0x1e) = 0;
          if ((*(byte *)(plVar18 + 0x21) & 2) != 0) {
            uStack_580 = 0x10033a;
            iVar9 = func_0x(plVar18 + 0x22);
            if (iVar9 != 0) {
              *(longlong *)(*plVar21 + 0x30) = *(longlong *)(*plVar21 + 0x30) + -1;
            }
          }
          *(undefined *)(plVar18 + 0x21) = 0;
          *(undefined4 *)((longlong)plVar18 + 0x104) = 0;
          *(undefined4 *)(plVar18 + 0x24) = 0;
          if (plVar18[0x12] != 0) {
            *(undefined *)((longlong)plVar18 + 0x9e) = 0;
            plVar18[0x12] = 0;
            *(undefined2 *)((longlong)plVar18 + 0x9c) = 0;
            *(undefined4 *)(plVar18[0xf] + 0x48) = 0;
          }
          uStack_580 = 0x100384;
          func_0x(*(undefined8 *)*plVar21,plVar18 + 0xf);
          uStack_580 = 0x10038c;
          func_0x(plVar21);
          *(undefined4 *)(plVar18 + 0x25) = 2;
        }
        plVar2 = plStack_4f0;
        plVar4 = plStack_4f0 + 0x5d;
        if ((plStack_4f0[0x5f] != _DAT_) || (plStack_4f0[0x60] != _DAT_)) {
          if ((*(byte *)(plStack_4f0 + 0x6b) & 2) != 0) {
            uStack_580 = 0x1003da;
            iVar9 = func_0x(plStack_4f0 + 0x6c);
            if (iVar9 != 0) {
              *(longlong *)(*plVar4 + 0x30) = *(longlong *)(*plVar4 + 0x30) + -1;
            }
          }
          *(undefined *)(plVar2 + 0x6b) = 0;
          *(undefined4 *)((longlong)plVar2 + 0x354) = 0;
          *(undefined4 *)(plVar2 + 0x6e) = 0;
          if ((*(byte *)(plVar2 + 0x71) & 2) != 0) {
            uStack_580 = 0x100409;
            iVar9 = func_0x(plVar2 + 0x72);
            if (iVar9 != 0) {
              *(longlong *)(*plVar4 + 0x30) = *(longlong *)(*plVar4 + 0x30) + -1;
            }
          }
          *(undefined *)(plVar2 + 0x71) = 0;
          *(undefined4 *)((longlong)plVar2 + 900) = 0;
          *(undefined4 *)(plVar2 + 0x74) = 0;
          if (plVar2[0x62] != 0) {
            *(undefined *)((longlong)plVar2 + 0x31e) = 0;
            plVar2[0x62] = 0;
            *(undefined2 *)((longlong)plVar2 + 0x31c) = 0;
            *(undefined4 *)(plVar2[0x5f] + 0x48) = 0;
          }
          uStack_580 = 0x100454;
          func_0x(*(undefined8 *)*plVar4,plVar2 + 0x5f);
          uStack_580 = 0x10045c;
          func_0x(plVar4);
          *(undefined4 *)(plVar2 + 0x75) = 2;
        }
        plVar4 = plStack_4f0 + 5;
        *(undefined4 *)((longlong)plStack_4f0 + 0x66c) = 0;
        while( true ) {
          uStack_558 = (longlong *)&uStack_258;
          uStack_580 = 0x1004b5;
          iVar9 = func_0x(*(undefined8 *)plStack_4f0[3],plVar4);
          if (iVar9 != 0) {
            plVar21 = (longlong *)0x0;
            iVar11 = 1;
            *pplStack_490 = (longlong *)0x0;
            pplVar32 = pplStack_490;
            param_1 = lStack_460;
            iVar9 = uStack_4e4;
            goto LAB_;
          }
          uVar20 = *(undefined4 *)(plStack_4f0 + 0xcf);
          *(uint *)((longlong)plStack_4f0 + 0x66c) =
               *(uint *)((longlong)plStack_4f0 + 0x66c) & 0xfffffffe;
          uStack_18a = 1;
          uVar14 = *(undefined8 *)*plVar21;
          plVar2 = *(longlong **)(plVar18[0xe] + 8);
          *(undefined4 *)(plVar18 + 0xf) = uStack_258;
          *(undefined4 *)((longlong)plVar18 + 0x7c) = uStack_254;
          *(undefined4 *)(plVar18 + 0x10) = uStack_250;
          *(undefined4 *)((longlong)plVar18 + 0x84) = uStack_24c;
          uStack_580 = 0x1004fb;
          func_0x(uVar14);
          plVar18[0x58] = *(longlong *)plVar18[0x12];
          *(undefined4 *)(plVar18 + 0x18) = uVar20;
          *(undefined4 *)((longlong)plVar18 + 0x2d4) = 0;
          lVar12 = *(longlong *)(*plVar21 + 0x18);
          if (((((*(uint *)(plVar18[0x27] + 0x10) & 1) != 0) &&
               ((*(uint *)(plVar18[0x27] + 0x10) & 0x40) == 0)) &&
              (*(char *)(plVar2[6] + 0x1cd2) != '\0')) && (*(char *)(plVar2[6] + 0x2050) == '\0')) {
            uStack_3c4 = *(undefined4 *)(plVar18[0xf] + 0x90);
            uStack_3c0 = *(undefined2 *)(plVar18[0xf] + 0x94);
            uStack_580 = 0x100594;
            func_0x(auStack_198,*(undefined2 *)(plVar2[6] + 0x6b8),&uStack_3c4,0);
            uStack_580 = 0x1005ad;
            cVar5 = func_0x(*(undefined8 *)(plVar18[0xe] + 8));
            if (cVar5 == '\0') {
              uStack_580 = 0x1005b9;
              func_0x(plVar21);
              uStack_558 = (longlong *)CONCAT71(uStack_558._1_7_,1);
              uStack_580 = 0x1005df;
              func_0x(*(undefined8 *)(plVar18[0xe] + 8));
            }
          }
          if (*(char *)(lVar12 + 2) == '\0') {
            uStack_580 = 0x1005f1;
            func_0x(*(undefined8 *)plVar18[0xe]);
          }
          else {
            uStack_580 = 0x10063d;
            cVar5 = (**(code **)(*plVar2 + 0x28))(plVar2);
            if (cVar5 == '\0') {
              uStack_3be = *(undefined4 *)(plVar18[0xf] + 0x90);
              uStack_3ba = *(undefined2 *)(plVar18[0xf] + 0x94);
              uStack_580 = 0x100688;
              func_0x
                        (auStack_198,
                         *(undefined2 *)
                          (*(longlong *)(*(longlong *)(plVar18[0xe] + 8) + 0x30) + 0x6b8),
                         &uStack_3be,0);
              uStack_558 = plVar18 + 0x1f;
              uStack_540 = CONCAT44(uStack_540._4_4_,1);
              uStack_548 = CONCAT44(uStack_548._4_4_,1);
              uStack_550 = 1;
              uStack_580 = 0x1006bb;
              iVar9 = func_0x(plVar21);
              if (iVar9 < 0) {
                if ((plVar18[0xf] != _DAT_) || (plVar18[0x10] != _DAT_)) {
                  if ((*(byte *)(plVar18 + 0x1b) & 2) != 0) {
                    uStack_580 = 0x1006f6;
                    iVar9 = func_0x(plVar18 + 0x1c);
                    if (iVar9 != 0) {
                      *(longlong *)(*plVar21 + 0x30) = *(longlong *)(*plVar21 + 0x30) + -1;
                    }
                  }
                  *(undefined *)(plVar18 + 0x1b) = 0;
                  *(undefined4 *)((longlong)plVar18 + 0xd4) = 0;
                  *(undefined4 *)(plVar18 + 0x1e) = 0;
                  if ((*(byte *)(plVar18 + 0x21) & 2) != 0) {
                    uStack_580 = 0x10072b;
                    iVar9 = func_0x(plVar18 + 0x22);
                    if (iVar9 != 0) {
                      *(longlong *)(*plVar21 + 0x30) = *(longlong *)(*plVar21 + 0x30) + -1;
                    }
                  }
                  *(undefined *)(plVar18 + 0x21) = 0;
                  *(undefined4 *)((longlong)plVar18 + 0x104) = 0;
                  *(undefined4 *)(plVar18 + 0x24) = 0;
                  if (plVar18[0x12] != 0) {
                    if (plVar18[0x12] != 0) {
                      *(undefined *)((longlong)plVar18 + 0x9e) = 0;
                      plVar18[0x12] = 0;
                      *(undefined2 *)((longlong)plVar18 + 0x9c) = 0;
                    }
                    *(undefined4 *)(plVar18[0xf] + 0x48) = 0;
                  }
                  uStack_580 = 0x10077b;
                  func_0x(*(undefined8 *)*plVar21);
                  uStack_580 = 0x100783;
                  func_0x(plVar21);
                  *(undefined4 *)(plVar18 + 0x25) = 2;
                }
                *(uint *)((longlong)plStack_4f0 + 0x66c) =
                     *(uint *)((longlong)plStack_4f0 + 0x66c) | 1;
                goto LAB_;
              }
            }
          }
          *(undefined4 *)(plVar18 + 0x25) = 3;
          if (plVar18[0x12] != 0) break;
          uStack_580 = 0x100616;
          func_0x(plVar21,1);
          if (*(int *)(plVar18 + 0x25) == 3) break;
          *(uint *)((longlong)plStack_4f0 + 0x66c) = *(uint *)((longlong)plStack_4f0 + 0x66c) | 1;
        }
        *(uint *)((longlong)plStack_4f0 + 0x66c) = *(uint *)((longlong)plStack_4f0 + 0x66c) | 1;
LAB_:
        *(undefined4 *)((longlong)plStack_4f0 + 0x34) = 1;
        iVar9 = uStack_4e4;
        uVar19 = (uint)uStack_538;
        uVar25 = uStack_538._4_4_;
      } while( true );
    }
    uStack_580 = 0x1021d4;
    iVar11 = (**(code **)(*plStack_4f0 + 0x38))(plStack_4f0,param_2);
    plVar21 = *pplVar32;
    goto LAB_;
  }
  goto LAB_;
LAB_:
  if (plVar21[0x5b] == 0) {
    uStack_580 = 0x101fab;
    func_0x(plVar21 + 0x56,0);
  }
  if (*(int *)(plVar21 + 0x9e) == 0) {
    uStack_580 = 0x101fc3;
    func_0x(plVar21 + 0x56,1);
  }
  uStack_538._0_4_ = *(uint *)((longlong)plVar21 + 0x4ec);
LAB_:
  plVar18 = plStack_4f0;
  uVar19 = (uint)uStack_538;
  uVar30 = 1;
  uVar31 = *(uint *)((longlong)plVar21 + 0x634);
  *(uint *)((longlong)plVar21 + 0x634) = uVar31 | 1;
  if (iVar9 != 0) goto LAB_;
  if (uVar25 == 2) goto LAB_;
  if (uVar25 == 3) {
    if ((*(char *)(*(longlong *)(plStack_4f0[3] + 0x18) + 3) == '\0') ||
       ((uStack_518 != 0 && (iStack_4bc != 0)))) goto LAB_;
    uStack_518 = 1;
    iStack_4bc = 1;
    if (plStack_4f0[0x58] == 0) {
      *(uint *)((longlong)plStack_4f0 + 0x66c) = uVar31 & 0xfffffffe;
      if (*(int *)(plStack_4f0 + 0x75) == 4) {
        uStack_580 = 0x102065;
        func_0x(plStack_4f0 + 0x5d);
      }
      uStack_580 = 0x10206e;
      func_0x(plVar18 + 0xd);
      if (*(char *)(plVar18[0xc] + 0xb5) == '\0') {
        *(uint *)((longlong)plVar18 + 0x66c) = *(uint *)((longlong)plVar18 + 0x66c) | 1;
      }
    }
    goto LAB_;
  }
  if ((uVar25 == 1) || (uVar25 == 4)) goto LAB_;
LAB_:
  if ((uint)uStack_538 == 0) {
LAB_:
    if ((*(int *)(*(longlong *)(plStack_4f0[3] + 0x18) + 8) == 0x10000) ||
       (*(longlong *)(*(longlong *)(plStack_4f0[3] + 0x18) + 0x10) != 0)) {
      uStack_580 = 0x10216a;
      func_0x(plVar21);
    }
    goto LAB_;
  }
  iVar11 = 0;
  plVar21 = plStack_4f0 + 7;
  *pplStack_490 = plVar21;
  pplVar32 = pplStack_490;
  param_1 = lStack_460;
LAB_:
  if (iVar11 != 0) {
    if (plVar21 != (longlong *)0x0) {
      uStack_558 = (longlong *)0x0;
      uStack_580 = 0x1023d1;
      (*_DAT_)(1,0x1988dc8);
    }
    uStack_580 = 0x1023dc;
    iVar11 = func_0x(param_1);
    puVar28 = auStack_578;
    param_2 = iStack_4b8;
    if (iVar11 != 0) goto LAB_;
    goto LAB_;
  }
  lVar12 = *(longlong *)(*(longlong *)(param_1 + 0x1e0) + 0x58);
  if (lVar12 != 0) {
    plVar21 = (longlong *)(lVar12 + 0x58);
    *plVar21 = *plVar21 + 1;
    plVar21 = *pplVar32;
  }
  if ((((*(uint *)(param_1 + 0x2e8) & 0x800) != 0) &&
      (plVar21 = *pplVar32, plVar21 != (longlong *)0x0)) && (*(char *)(plVar21 + 199) != '\0')) {
    lVar12 = *(longlong *)(*(longlong *)(param_1 + 0x1e0) + 0x58);
    lVar26 = param_1;
    if (lVar12 != 0) {
      plVar21 = (longlong *)(lVar12 + 0x70);
      *plVar21 = *plVar21 + 1;
      lVar26 = param_1;
    }
    goto LAB_;
  }
  lStack_468 = *(longlong *)(param_1 + 0x178);
  puVar3 = *(undefined8 **)(param_1 + 0x168);
  lVar12 = param_1 + 400;
  plVar18 = *(longlong **)(param_1 + 0x160);
  lVar26 = *(longlong *)(param_1 + 0x158);
  puStack_4a0 = *(ushort **)(param_1 + 0x170);
  uStack_580 = 0x102266;
  uVar14 = func_0x(plVar21,1);
  if ((lVar26 == 0) && (puVar3 == (undefined8 *)0x0)) {
LAB_:
    if (plVar18 != (longlong *)0x0) {
      plVar4 = *(longlong **)plVar18[1];
      *(undefined8 *)(param_1 + 0x1b0) = uVar14;
      *(longlong **)(param_1 + 0x1a8) = plVar21;
      uStack_580 = 0x1022e2;
      (**(code **)(*plVar4 + 0x20))(plVar4,lVar12);
      uStack_580 = 0x1022f2;
      iVar9 = (**(code **)(*plVar18 + 8))(plVar18);
      if (iVar9 == 0) goto LAB_;
    }
    pplVar32 = pplStack_490;
    lVar26 = lStack_460;
    if (puStack_4a0 == (ushort *)0x0) goto LAB_;
    *(undefined8 *)(param_1 + 0x1b0) = uVar14;
    *(longlong **)(param_1 + 0x1a8) = plVar21;
    uStack_580 = 0x102320;
    iVar9 = func_0x(lVar12);
    pplVar32 = pplStack_490;
    lVar26 = lStack_460;
    if (iVar9 != 0) goto LAB_;
  }
  else {
    *(undefined8 *)(param_1 + 0x1b0) = uVar14;
    *(longlong **)(param_1 + 0x1a8) = plVar21;
    alStack_2c0[0] = lVar12;
    if (lVar26 == 0) {
LAB_:
      if (puVar3 != (undefined8 *)0x0) {
        uStack_580 = 0x1022ba;
        cVar5 = (**(code **)*puVar3)(puVar3);
        if (cVar5 == '\0') goto LAB_;
      }
      goto LAB_;
    }
    uStack_580 = 0x102297;
    (**(code **)(lVar26 + 8))(alStack_2c0);
    if ((*(char *)(param_1 + 0xac0) != '\x03') && (*(char *)(param_1 + 0xac8) != '\0'))
    goto LAB_;
  }
LAB_:
  param_1 = lStack_460;
  pplVar32 = pplStack_490;
  if ((cStack_4dc == '\0') ||
     (lVar12 = *(longlong *)(lStack_460 + 0x1e0), plVar21 = (longlong *)(lVar12 + 0x60),
     *plVar21 = *plVar21 + 1, *(longlong *)(lVar12 + 0x60) < 10000)) {
    lVar12 = *(longlong *)(*(longlong *)(lStack_460 + 0x2d8) + 0x18);
    if ((*(int *)(lVar12 + 8) == 0x10000) || (*(longlong *)(lVar12 + 0x10) != 0)) {
      uStack_580 = 0x102378;
      func_0x(*pplStack_490);
    }
    uStack_580 = 0x10238a;
    (**(code **)(**pplVar32 + 8))();
    iVar9 = uStack_4e4;
    param_2 = iStack_4b8;
    goto LAB_;
  }
  *(undefined *)puStack_350[1] = 1;
  *(undefined8 *)(*(longlong *)(lStack_460 + 0x1e0) + 0x60) = 0;
  lVar26 = lStack_460;
LAB_:
  pplVar33 = (longlong **)0x0;
  puVar28 = auStack_578;
  if ((*(byte *)((longlong)pplStack_508 + 0x14) & 0x10) != 0) {
    pplVar32 = (longlong **)*pplVar32;
    plVar21 = *pplStack_508;
    pplVar15 = pplVar32;
    if ((*(uint *)(lVar26 + 0x2e8) & 0x800) == 0) {
      pplVar15 = pplVar33;
    }
    pplStack_490 = pplVar32;
    if ((pplVar15 == (longlong **)0x0) || (*(char *)(pplVar15 + 199) == '\0')) {
      if ((*(short *)((longlong)plVar21 + 0x3a) == 0) && (*(int *)(plVar21 + 10) == 0)) {
        uStack_580 = 0x1024ea;
        psVar16 = (short *)func_0x(pplVar32,1);
        plStack_4f0 = (longlong *)(lVar26 + 0x110);
        uVar24 = lVar26 + 0xa60;
        plVar21 = *pplStack_508;
        uStack_510 = psVar16;
        uStack_488 = uVar24;
        if ((*(byte *)(plVar21 + 6) & 1) != 0) {
          puVar1 = (ushort *)(psVar16 + 1);
          if (*psVar16 == 0) {
            if ((**(byte **)(psVar16 + 4) & 0x10) == 0) {
              uVar19 = 0;
            }
            else {
              uVar19 = (uint)*(ushort *)(*(byte **)(psVar16 + 4) + *(uint *)(psVar16 + 8));
            }
          }
          else {
            uVar19 = (uint)*puVar1;
          }
          if (*(uint *)(plVar21 + 3) <= uVar19) {
            *psVar16 = 0;
            plVar21 = pplStack_508[1];
            uStack_498 = 0;
            uStack_494 = (uint)*(ushort *)((longlong)*pplStack_508 + 0x62);
            pplVar15 = pplStack_508;
            if (uStack_494 != 0) goto LAB_;
            goto LAB_;
          }
        }
        if (pplVar32 == (longlong **)0x0) {
          *(short **)(lVar26 + 0xa68) = psVar16;
          *(undefined8 *)(lVar26 + 0xa70) = 0;
        }
        else {
          *(undefined8 *)(lVar26 + 0xa68) = 0;
          *(longlong ***)(lVar26 + 0xa70) = pplVar32;
          uStack_580 = 0x103981;
          uVar14 = (*(code *)**pplVar32)(pplVar32);
          *(undefined8 *)(lVar26 + 0xa68) = uVar14;
        }
        uVar34 = 0;
        if (*uStack_510 == 0) {
          *uStack_510 = 0;
          puVar27 = auStack_578;
          if ((*(byte *)((longlong)pplStack_508 + 0x14) & 0x10) != 0) {
            uVar19 = *(uint *)(pplStack_508 + 2);
            plVar21 = pplStack_508[1];
            uStack_538._4_4_ = 0;
            puVar27 = auStack_578;
            uStack_538._0_4_ = uVar19;
            uStack_4c8 = plVar21;
            if (uVar19 != 0) {
              do {
                uStack_4c8 = plVar21;
                if (*(byte *)(plVar21 + 8) < 0x1c) {
                  UNRECOVERED_JUMPTABLE =
                       (code *)((ulonglong)
                                *(uint *)((longlong)(char)*(byte *)(plVar21 + 8) * 4 + 0x109968) -
                               0xfc76e0);
                    /* WARNING: Could not emulate address calculation at 0x00103a06 */
                    /* WARNING: Treating indirect jump as call */
                  (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,pplStack_508,0,uStack_510);
                  return;
                }
                uVar25 = *(uint *)(plVar21 + 8);
                if ((uVar25 & 0x400) != 0) {
                  if ((*(byte *)(plVar21[9] + 0x2a) & 0x10) == 0) {
                    plVar18 = pplStack_508[3];
                  }
                  else {
                    plVar18 = pplStack_508[4];
                  }
                  *(undefined *)((longlong)plVar18 + plVar21[6]) = 3;
                  uVar25 = *(uint *)(plVar21 + 8);
                }
                if ((uVar25 >> 9 & 1) != 0) {
                  uStack_558 = (longlong *)CONCAT44(uStack_558._4_4_,uStack_4fc);
                  uStack_580 = 0x1061e5;
                  func_0x(pplStack_508,plStack_4f0,plVar21,0);
                }
                uStack_538._4_4_ = (int)uVar34 + 1;
                uVar34 = (ulonglong)uStack_538._4_4_;
                plVar21 = plVar21 + 10;
                puVar27 = auStack_578;
                uVar24 = uStack_488;
                pplVar32 = pplStack_490;
                uStack_4c8 = plVar21;
              } while (uStack_538._4_4_ < uVar19);
            }
          }
        }
        else if (*(int *)(plStack_4f0[1] + 0x100) == 2) {
          uStack_480 = *(uint *)((longlong)plVar21 + 0x34);
          uVar23 = (ulonglong)uStack_480 + 0xf;
          if (uVar23 <= uStack_480) {
            uVar23 = 0xffffffffffffff0;
          }
          uVar23 = uVar23 & 0xfffffffffffffff0;
          uStack_580 = 0x106bc5;
          pplVar33 = pplStack_508;
          func_0x();
          uStack_510 = *(short **)(lVar26 + 0xa68);
          lVar12 = -uVar23;
          plStack_458 = (longlong *)((longlong)&uStack_538 + lVar12);
          puVar27 = auStack_578 + lVar12;
          if ((*(byte *)((longlong)pplVar33 + 0x14) & 0x10) != 0) {
            uStack_494 = *(uint *)(pplVar33 + 2);
            plVar21 = pplVar33[1];
            uStack_518 = (uint)uVar34;
            uVar23 = uVar34 & 0xffffffff;
            puVar27 = auStack_578 + lVar12;
            uVar24 = uStack_488;
            pplVar32 = pplStack_490;
            uStack_4c8 = plVar21;
            if (uStack_494 != 0) {
              do {
                uStack_4c8 = plVar21;
                if (*(byte *)(plVar21 + 8) < 0x1c) {
                  UNRECOVERED_JUMPTABLE =
                       (code *)((ulonglong)
                                *(uint *)((longlong)(char)*(byte *)(plVar21 + 8) * 4 + 0x109cb8) -
                               0xfc76e0);
                    /* WARNING: Could not emulate address calculation at 0x00106c25 */
                    /* WARNING: Treating indirect jump as call */
                  (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
                  return;
                }
                *(undefined8 *)(auStack_578 + lVar12 + -8) = 0x109670;
                iVar9 = func_0x(plVar21);
                pplVar32 = pplStack_508;
                if (iVar9 != 0) {
                  uVar20 = 0;
                  if (uVar34 == 0) {
                    uVar20 = 3;
                  }
                  *(undefined8 *)(auStack_578 + lVar12 + -8) = 0x109692;
                  func_0x(pplVar32,plVar21,uVar20);
                }
                *(undefined8 *)(auStack_578 + lVar12 + -8) = 0x1096a0;
                iVar9 = func_0x(plVar21);
                plVar18 = plStack_4f0;
                if (iVar9 != 0) {
                  *(undefined4 *)((longlong)&uStack_558 + lVar12) = uStack_514;
                  *(undefined8 *)(auStack_578 + lVar12 + -8) = 0x1096bd;
                  func_0x(pplVar32,plVar18,plVar21,uVar34);
                }
                uStack_518 = (int)uVar23 + 1;
                uVar23 = (ulonglong)uStack_518;
                plVar21 = plVar21 + 10;
                puVar27 = auStack_578 + lVar12;
                uVar24 = uStack_488;
                pplVar32 = pplStack_490;
                uStack_4c8 = plVar21;
              } while (uStack_518 < uStack_494);
            }
          }
        }
        else {
          if (*uStack_510 == -1) {
            *uStack_510 = 1;
          }
          puVar27 = auStack_578;
          uVar24 = uStack_488;
          if ((*(byte *)((longlong)pplStack_508 + 0x14) & 0x10) != 0) {
            uVar19 = *(uint *)(pplStack_508 + 2);
            plVar21 = pplStack_508[1];
            puVar27 = auStack_578;
            pplVar32 = pplStack_490;
            if (uVar19 != 0) {
              do {
                if (*(byte *)(plVar21 + 8) < 0x1c) {
                  UNRECOVERED_JUMPTABLE =
                       (code *)((ulonglong)
                                *(uint *)((longlong)(char)*(byte *)(plVar21 + 8) * 4 + 0x109b10) -
                               0xfc76e0);
                    /* WARNING: Could not emulate address calculation at 0x00106271 */
                    /* WARNING: Treating indirect jump as call */
                  (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,pplStack_508,0,uStack_510);
                  return;
                }
                uVar25 = *(uint *)(plVar21 + 8);
                if ((uVar25 >> 10 & 1) != 0) {
                  if ((*(byte *)(plVar21[9] + 0x2a) & 0x10) == 0) {
                    plVar18 = pplStack_508[3];
                  }
                  else {
                    plVar18 = pplStack_508[4];
                  }
                  *(undefined *)((longlong)plVar18 + plVar21[6]) = 3;
                  uVar25 = *(uint *)(plVar21 + 8);
                }
                if ((uVar25 >> 9 & 1) != 0) {
                  uStack_558 = (longlong *)CONCAT44(uStack_558._4_4_,uStack_4cc);
                  uStack_580 = 0x106b74;
                  func_0x(pplStack_508,plStack_4f0,plVar21,0);
                }
                uVar25 = (int)uVar34 + 1;
                uVar34 = (ulonglong)uVar25;
                plVar21 = plVar21 + 10;
                puVar27 = auStack_578;
                pplVar32 = pplStack_490;
              } while (uVar25 < uVar19);
            }
          }
        }
        if (pplVar32 != (longlong **)0x0) {
          UNRECOVERED_JUMPTABLE = *(code **)(**(longlong **)(uVar24 + 0x10) + 8);
          *(undefined8 *)(puVar27 + -8) = 0x10970a;
          (*UNRECOVERED_JUMPTABLE)();
        }
LAB_:
        UNRECOVERED_JUMPTABLE = (code *)(*pplVar32)[1];
        *(undefined8 *)(puVar27 + -8) = 0x109713;
        (*UNRECOVERED_JUMPTABLE)(pplVar32);
        puVar28 = puVar27;
      }
      else {
        uStack_580 = 0x109733;
        func_0x(lVar26,pplVar32,pplStack_508,aiStack_42c);
        puVar28 = auStack_578;
        if (aiStack_42c[0] != 1) {
          uStack_580 = 0x10974a;
          lVar12 = func_0x(*(undefined8 *)(lVar26 + 0x108),0);
          puVar28 = auStack_578;
          if (*(longlong *)(lVar12 + 0x10) != 0) {
            uStack_580 = 0x10975d;
            iVar9 = func_0x(*(undefined8 *)(lVar26 + 0x108));
            puVar28 = auStack_578;
            if (iVar9 != 0) {
              uStack_580 = 0x10976f;
              lVar12 = func_0x(*(undefined8 *)(lVar26 + 0x108),0);
              uStack_580 = 0x10977b;
              func_0x(pplVar32,*(undefined8 *)(lVar12 + 0x10));
              puVar28 = auStack_578;
            }
          }
        }
      }
    }
    else {
      plVar18 = pplVar15[200];
      plVar4 = pplStack_508[3];
      lVar12 = plVar21[0x20];
      if (plVar18 == (longlong *)0x0) {
        uStack_558 = (longlong *)0x0;
        uStack_580 = 0x1024b0;
        (*_DAT_)(1,0x1987a30,0x195c278,0x3b);
      }
      uStack_580 = 0x1024be;
      func_0x(plVar18,lVar12,plVar4);
      puVar28 = auStack_578;
    }
  }
  goto LAB_;
LAB_:
  do {
    uVar19 = uStack_498;
    cVar5 = *(char *)(plVar21 + 8);
    if (cVar5 == '\x01') {
      if ((*(byte *)((longlong)plVar21 + 6) & 0x10) == 0) {
        uVar25 = *(ushort *)((longlong)plVar21 + 4) - 1;
        uVar25 = *(byte *)((ulonglong)(uVar25 >> 3) + (ulonglong)*(uint *)(psVar16 + 8) + 2 +
                          *(longlong *)(psVar16 + 4)) >> ((byte)uVar25 & 7) & 1;
      }
      else {
        uStack_558 = &uStack_300;
        uStack_580 = 0x103773;
        func_0x(puVar1,plVar21,1,auStack_368);
        uVar25 = auStack_368[0];
      }
      if (uVar25 == 0) goto LAB_;
LAB_:
      bVar38 = (*(byte *)(plVar21[9] + 0x2a) & 0x10) == 0;
LAB_:
      if (bVar38) {
        *(undefined *)((longlong)pplVar15[3] + plVar21[6]) = 3;
      }
      else {
        *(undefined *)((longlong)pplVar15[4] + plVar21[6]) = 3;
      }
    }
    else {
      if (cVar5 == '\x02') {
LAB_:
        uVar8 = *(ushort *)((longlong)plVar21 + 0x3c);
        if ((*(byte *)((longlong)plVar21 + 6) & 0x10) == 0) {
LAB_:
          pplVar33 = (longlong **)((longlong)(int)*(uint *)plVar21 + *(longlong *)(psVar16 + 4));
          uVar25 = (uint)uVar8;
        }
        else {
          uStack_558 = (longlong *)&iStack_358;
          uStack_580 = 0x10380a;
          func_0x(puVar1,plVar21,0,auStack_328);
          if (iStack_358 != 0) goto LAB_;
          uVar25 = *(uint *)plVar21[1];
          pplVar33 = (longlong **)((uint *)plVar21[1] + 1);
          pplVar15 = pplStack_508;
          if ((uVar8 != 0) && (uVar25 != uVar8)) {
            uStack_558 = (longlong *)0x0;
            uStack_580 = 0x10384c;
            (*_DAT_)(1,0x1985d30,0x1984698,0x381);
            pplVar15 = pplStack_508;
          }
        }
        auStack_4f8[0] = uVar25;
        if ((*(byte *)(plVar21[9] + 0x2a) & 0x10) == 0) {
LAB_:
          plVar18 = pplVar15[3];
        }
        else {
          plVar18 = pplVar15[4];
        }
LAB_:
        *(undefined *)((longlong)plVar18 + plVar21[6]) = 0;
      }
      else {
        if (cVar5 == '\x03') {
          if ((*(byte *)((longlong)plVar21 + 6) & 0x10) == 0) {
            uVar25 = *(ushort *)((longlong)plVar21 + 4) - 1;
            uVar25 = *(byte *)((ulonglong)(uVar25 >> 3) + (ulonglong)*(uint *)(psVar16 + 8) + 2 +
                              *(longlong *)(psVar16 + 4)) >> ((byte)uVar25 & 7) & 1;
          }
          else {
            uStack_558 = &uStack_2f8;
            uStack_580 = 0x102f18;
            func_0x(puVar1,plVar21,1,&uStack_380);
            uVar25 = uStack_380;
          }
          if (uVar25 != 0) goto LAB_;
        }
        else if (cVar5 != '\x04') {
          if (cVar5 == '\b') {
            pplVar33 = (longlong **)0x0;
            uVar8 = *(ushort *)((longlong)plVar21 + 0x3c);
            iVar9 = *(uint *)(plVar21 + 8) << 0xc;
            if ((*(uint *)plVar21 & 0xc0000000) == 0x80000000) {
              uStack_580 = 0x102e93;
              iVar9 = func_0x(puVar1);
              if (iVar9 != 0) {
                uStack_580 = 0x102eae;
                pplVar33 = (longlong **)
                           func_0x(psVar16 + 0x15,plVar21,auStack_4f8,
                                           (longlong)&uStack_2f8 + 4);
                uVar25 = auStack_4f8[0];
                goto LAB_;
              }
              auStack_4f8[0] = 0;
              uVar8 = *(ushort *)(plVar21[9] + 0x2a);
LAB_:
              bVar38 = (uVar8 & 0x10) == 0;
              pplVar15 = pplStack_508;
              goto LAB_;
            }
            if ((iVar9 < 0) || ((*(byte *)((longlong)plVar21 + 6) & 0x10) != 0)) {
              uStack_558 = (longlong *)&iStack_430;
              uStack_580 = 0x102641;
              func_0x(puVar1,plVar21,iVar9 < 0,aiStack_420);
              if ((iVar9 < 0) && (aiStack_420[0] != 0)) {
                auStack_4f8[0] = 0;
                pplVar33 = (longlong **)0x0;
                uVar25 = auStack_4f8[0];
                goto LAB_;
              }
            }
            else {
              aiStack_420[0] = 0;
              iStack_430 = 1;
            }
            if ((iStack_430 == 0) && ((*(byte *)((longlong)plVar21 + 6) & 0x10) != 0)) {
              pplVar33 = (longlong **)((uint *)plVar21[1] + 1);
              uVar25 = *(uint *)plVar21[1];
            }
            else if ((int)*(uint *)plVar21 < 0) {
              if (*(int *)(psVar16 + 2) == 0) {
                *puVar1 = 0;
                uVar25 = *(uint *)(psVar16 + 8);
                uVar24 = (ulonglong)uVar25;
                *(uint *)(psVar16 + 10) = uVar25;
                pbVar35 = *(byte **)(psVar16 + 4);
                bVar6 = *pbVar35;
                if ((bVar6 & 0x10) != 0) {
                  uVar25 = uVar25 + (*(ushort *)(pbVar35 + uVar24) + 7 >> 3) + 2;
                  uVar24 = (ulonglong)uVar25;
                  *(uint *)(psVar16 + 10) = uVar25;
                  bVar6 = *pbVar35;
                }
                if ((bVar6 & 0x20) == 0) {
                  *(int *)(psVar16 + 2) = (int)uVar24;
                  psVar16[0xe] = 0;
                  *(uint *)(psVar16 + 0xc) = uVar25;
                }
                else {
                  puVar36 = (ushort *)(pbVar35 + uVar24);
                  uVar8 = *puVar36;
                  psVar16[0xe] = uVar8;
                  puStack_4a0 = puVar36;
                  if (uVar8 == 0) {
                    uStack_580 = 0x102798;
                    cVar5 = func_0x(0x1ee7ee0);
                    if (cVar5 != '\0') {
                      uStack_580 = 0x1027a1;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        uStack_580 = 0x1027bb;
                        cVar5 = func_0x(0x1ee7ee0);
                        if (cVar5 == '\0') {
                          uStack_580 = 0x1027d7;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          uStack_558 = (longlong *)0x0;
                          uStack_580 = 0x1027fc;
                          (*_DAT_)(1,0x17d78ec,0x18f79d8,0x80f);
                        }
                      }
                    }
                    uStack_580 = 0x10280a;
                    func_0x(*(undefined8 *)(psVar16 + 4),3);
                    uVar8 = psVar16[0xe];
                    uVar25 = *(uint *)(psVar16 + 10);
                  }
                  uVar25 = uVar25 + (uVar8 + 1) * 2;
                  *(uint *)(psVar16 + 0xc) = uVar25;
                  if (0x1f9e < uVar25) {
                    uStack_580 = 0x102839;
                    cVar5 = func_0x(0x1ee7ee0);
                    if (cVar5 != '\0') {
                      uStack_580 = 0x102842;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        uStack_580 = 0x10285c;
                        cVar5 = func_0x(0x1ee7ee0);
                        if (cVar5 == '\0') {
                          uStack_580 = 0x102878;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_558 = (longlong *)0x0;
                          uStack_580 = 0x10289d;
                          (*_DAT_)(1,0x17d78ec,0x18f79d8,0x816);
                        }
                      }
                    }
                    uStack_580 = 0x1028ab;
                    func_0x(*(undefined8 *)(psVar16 + 4),4);
                    uVar8 = psVar16[0xe];
                    uVar25 = *(uint *)(psVar16 + 0xc);
                  }
                  uVar24 = (ulonglong)uVar8;
                  uVar8 = puVar36[uVar24];
                  *(uint *)(psVar16 + 2) = uVar8 & 0x7fff;
                  if ((uVar8 & 0x7fff) < uVar25) {
                    uStack_580 = 0x1028d9;
                    cVar5 = func_0x(0x1ee7ee0);
                    if (cVar5 != '\0') {
                      uStack_580 = 0x1028e2;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        uStack_580 = 0x1028fc;
                        cVar5 = func_0x(0x1ee7ee0);
                        if (cVar5 == '\0') {
                          uStack_580 = 0x102918;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_558 = (longlong *)0x0;
                          uStack_580 = 0x10293d;
                          (*_DAT_)(1,0x17d78ec,0x18f79d8,0x81d);
                        }
                      }
                    }
                    uStack_580 = 0x10294b;
                    func_0x(*(undefined8 *)(psVar16 + 4),4);
                    uVar25 = *(uint *)(psVar16 + 0xc);
                    uVar24 = (ulonglong)(ushort)psVar16[0xe];
                  }
                  iVar9 = 0;
                  puVar37 = puVar36;
                  if ((short)uVar24 != 0) {
                    do {
                      puVar36 = puVar36 + 1;
                      uVar30 = *puVar36 & 0x7fff;
                      if ((uVar30 < uVar25) || (*(uint *)(psVar16 + 2) < uVar30)) {
                        uStack_580 = 0x10298f;
                        cVar5 = func_0x(0x1ee7ee0);
                        if (cVar5 != '\0') {
                          uStack_580 = 0x102998;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            uStack_580 = 0x1029b2;
                            cVar5 = func_0x(0x1ee7ee0);
                            if (cVar5 == '\0') {
                              uStack_580 = 0x1029ce;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              uStack_558 = (longlong *)0x0;
                              uStack_580 = 0x1029f2;
                              (*_DAT_)(1,0x17d78ec,0x18f79d8,0x82a);
                            }
                          }
                        }
                        uStack_580 = 0x102a00;
                        func_0x(*(undefined8 *)(psVar16 + 4),4);
                      }
                      uVar24 = (ulonglong)(ushort)psVar16[0xe];
                      iVar9 = iVar9 + 1;
                      puVar37 = puStack_4a0;
                      uVar19 = uStack_498;
                      uVar25 = uVar30;
                    } while (iVar9 < (int)(uint)(ushort)psVar16[0xe]);
                  }
                  if ((short)puVar37[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                    do {
                      lVar12 = (ulonglong)*(uint *)(psVar16 + 10) + *(longlong *)(psVar16 + 4);
                      uVar25 = *(ushort *)(lVar12 + uVar24 * 2) & 0x7fff;
                      if ((int)uVar24 == 1) {
                        uVar30 = *(uint *)(psVar16 + 0xc);
                        uVar31 = uVar30;
LAB_:
                        if ((uVar25 < uVar30) || (*(uint *)(psVar16 + 2) < uVar25))
                        goto LAB_;
                      }
                      else {
                        uVar31 = *(uint *)(psVar16 + 0xc);
                        uVar30 = *(ushort *)(lVar12 + -2 + uVar24 * 2) & 0x7fff;
                        if (uVar31 <= uVar30) goto LAB_;
LAB_:
                        uStack_580 = 0x102a8b;
                        func_0x(*(longlong *)(psVar16 + 4),7);
                        uVar31 = *(uint *)(psVar16 + 0xc);
                      }
                      if ((uVar30 < uVar31) || (*(uint *)(psVar16 + 2) < uVar30)) goto LAB_;
                      if (*(ushort *)((ulonglong)uVar30 + *(longlong *)(psVar16 + 4)) == 5) {
                        *puVar1 = *puVar1 | 2;
                        psVar16[0xe] = psVar16[0xe] + -1;
                        psVar16[0x15] = (short)uVar30;
                        uVar24 = *(ulonglong *)(psVar16 + 4);
                        uVar7 = psVar16[0x16] & 0xc7ff;
                        uVar8 = *(ushort *)((ulonglong)(uVar30 & 0xffff) + 2 + uVar24);
                        if ((uVar8 >> 0xe & 1) != 0) {
                          uVar7 = uVar8 & 0x3800 | uVar7;
                        }
                        psVar16[0x16] = uVar7;
                        uVar8 = (uVar7 ^ *(ushort *)((ulonglong)(uVar30 & 0xffff) + 2 + uVar24)) &
                                0x7ff ^ uVar7;
                        psVar16[0x16] = uVar8;
                        uVar23 = (ulonglong)(ushort)psVar16[0x15];
                        uVar34 = (ulonglong)((uVar8 & 0x7ff) * 2) + 4 +
                                 uVar23 + (uVar7 >> 0xb & 7) * 2 + uVar24;
                        if (uVar34 < uVar23 + uVar24) {
                          uStack_580 = 0x102b9e;
                          func_0x(uVar23 + uVar24,0x19);
                          uVar8 = psVar16[0x16];
                          uVar23 = (ulonglong)(ushort)psVar16[0x15];
                          uVar24 = (ulonglong)*(uint *)(psVar16 + 4);
                        }
                        if (uVar25 - uVar30 <
                            (((uVar8 & 0x7ff) * 2 - (int)uVar23) - (int)uVar24) + (int)uVar34) {
                          uStack_580 = 0x102bd6;
                          func_0x(uVar23 + *(longlong *)(psVar16 + 4),0x19);
                          uVar8 = psVar16[0x16];
                        }
                        if ((uVar8 & 0x3800) != 0) {
                          puVar36 = (ushort *)
                                    (*(longlong *)(psVar16 + 4) +
                                    (ulonglong)(ushort)psVar16[0x15] + 4);
                          iVar9 = 0;
                          if ((uVar8 & 0x3800) != 0) {
                            do {
                              if ((uVar8 & 0x7ff) < (*puVar36 & 0x7ff)) {
                                uStack_580 = 0x102c28;
                                func_0x((ulonglong)(ushort)psVar16[0x15] +
                                                *(longlong *)(psVar16 + 4),0x1a);
                                uVar8 = psVar16[0x16];
                              }
                              iVar9 = iVar9 + 1;
                              puVar36 = puVar36 + 1;
                            } while (iVar9 < (int)(uVar8 >> 0xb & 7));
                          }
                        }
                        goto LAB_;
                      }
                      if (*(ushort *)((ulonglong)uVar30 + *(longlong *)(psVar16 + 4)) < 0x400)
                      goto LAB_;
                      *puVar1 = *puVar1 | 1;
                      uVar8 = psVar16[0xe] - 1;
                      psVar16[0xe] = uVar8;
                      if (uVar8 == 0) goto LAB_;
                      uVar24 = (ulonglong)uVar8;
                    } while ((short)puVar37[(ulonglong)(uVar8 - 1) + 1] < 0);
                    pbVar35 = *(byte **)(psVar16 + 4);
                  }
                  else {
LAB_:
                    pbVar35 = *(byte **)(psVar16 + 4);
                  }
                }
                if ((*pbVar35 & 0x40) == 0) {
                  *(undefined4 *)(psVar16 + 0x13) = 0;
                }
                else {
                  *(int *)(psVar16 + 0x13) = *(int *)(psVar16 + 2);
                  *(int *)(psVar16 + 2) = *(int *)(psVar16 + 2) + 0xe;
                  uStack_580 = 0x102c76;
                  uVar14 = func_0x(puVar1);
                  uStack_580 = 0x102c85;
                  func_0x(uVar14,auStack_2b0);
                  uStack_580 = 0x102c91;
                  iVar9 = func_0x(auStack_2b0);
                  *(int *)(psVar16 + 2) = *(int *)(psVar16 + 2) + iVar9;
                }
                uVar25 = *(uint *)(psVar16 + 2);
                if ((*(ulonglong *)(psVar16 + 0xf) != 0) &&
                   (*(ulonglong *)(psVar16 + 0xf) < (ulonglong)uVar25 + *(longlong *)(psVar16 + 4)))
                {
                  uStack_580 = 0x102cc1;
                  cVar5 = func_0x(0x1ee7ee0);
                  if (cVar5 != '\0') {
                    uStack_580 = 0x102cca;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      uStack_580 = 0x102ce4;
                      cVar5 = func_0x(0x1ee7ee0);
                      if (cVar5 == '\0') {
                        uStack_580 = 0x102d00;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        uStack_558 = (longlong *)0x0;
                        uStack_580 = 0x102d23;
                        (*_DAT_)(1,0x17d78ec,0x18f79d8,0x886);
                      }
                    }
                  }
                  uStack_580 = 0x102d31;
                  func_0x(*(undefined8 *)(psVar16 + 4),0x12);
                  uVar25 = *(uint *)(psVar16 + 2);
                }
                if (0x3f3b < uVar25 - 1) {
                  uStack_580 = 0x102d4a;
                  cVar5 = func_0x(0x1ee7ee0);
                  if (cVar5 != '\0') {
                    uStack_580 = 0x102d53;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      uStack_580 = 0x102d6d;
                      cVar5 = func_0x(0x1ee7ee0);
                      if (cVar5 == '\0') {
                        uStack_580 = 0x102d89;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        uStack_558 = (longlong *)0x0;
                        uStack_580 = 0x102dac;
                        (*_DAT_)(1,0x17d78ec,0x18f79d8,0x88b);
                      }
                    }
                  }
                  uStack_580 = 0x102dba;
                  func_0x(*(undefined8 *)(psVar16 + 4),5);
                }
              }
LAB_:
              sVar29 = -*(short *)plVar21;
              if ((*(byte *)((longlong)plVar21 + 6) & 0x10) != 0) {
                uStack_558 = (longlong *)&iStack_384;
                uStack_580 = 0x102deb;
                func_0x(puVar1,plVar21,0,auStack_2f0);
                if (iStack_384 == 0) {
                  pplVar33 = (longlong **)((uint *)plVar21[1] + 1);
                  uVar25 = *(uint *)plVar21[1];
                  goto LAB_;
                }
              }
              lVar12 = (longlong)sVar29;
              if ((uint)(ushort)psVar16[0xe] < (uint)(int)sVar29) {
                auStack_4f8[0] = 0;
                pplVar33 = *(longlong ***)(psVar16 + 4);
                uVar25 = auStack_4f8[0];
              }
              else {
                lVar26 = *(longlong *)(psVar16 + 4);
                lVar17 = (ulonglong)*(uint *)(psVar16 + 10) + lVar26;
                if (sVar29 == 1) {
                  uVar30 = *(ushort *)(lVar17 + lVar12 * 2) & 0x7fff;
                  uVar25 = *(uint *)(uStack_510 + 0xc);
LAB_:
                  if ((uVar30 < uVar25) || (*(uint *)(psVar16 + 2) < uVar30)) goto LAB_;
                }
                else {
                  uVar25 = *(ushort *)(lVar17 + -2 + lVar12 * 2) & 0x7fff;
                  uVar30 = *(ushort *)(lVar17 + lVar12 * 2) & 0x7fff;
                  lVar26 = *(longlong *)(psVar16 + 4);
                  if (*(uint *)(uStack_510 + 0xc) <= uVar25) goto LAB_;
LAB_:
                  uStack_580 = 0x102e73;
                  func_0x(lVar26,7);
                }
                pplVar33 = (longlong **)((ulonglong)uVar25 + *(longlong *)(psVar16 + 4));
                uVar25 = uVar30 - uVar25;
              }
            }
            else if ((*(ushort *)((longlong)plVar21 + 6) & 8) == 0) {
              if ((*(ushort *)((longlong)plVar21 + 6) & 0x10) != 0) {
                uStack_558 = (longlong *)&iStack_388;
                uStack_580 = 0x1026bc;
                func_0x(puVar1,plVar21,0,auStack_2ec);
                if (iStack_388 == 0) {
                  uVar25 = *(uint *)plVar21[1];
                  pplVar33 = (longlong **)((uint *)plVar21[1] + 1);
                  if ((uVar8 != 0) && (uVar25 != uVar8)) {
                    uStack_558 = (longlong *)0x0;
                    uStack_580 = 0x1026fe;
                    (*_DAT_)(1,0x1985d30,0x1984698,0x381);
                  }
                  goto LAB_;
                }
              }
              pplVar33 = (longlong **)((longlong)(int)*(uint *)plVar21 + *(longlong *)(psVar16 + 4))
              ;
              uVar25 = (uint)uVar8;
            }
            else {
              uStack_580 = 0x102726;
              pplVar33 = (longlong **)func_0x(puVar1,plVar21);
              uVar25 = auStack_4f8[0];
            }
LAB_:
            auStack_4f8[0] = uVar25;
            uVar8 = *(ushort *)(plVar21[9] + 0x2a);
            if (pplVar33 == (longlong **)0x0) goto LAB_;
            pplVar15 = pplStack_508;
            if ((uVar8 & 0x10) == 0) goto LAB_;
            plVar18 = pplStack_508[4];
            goto LAB_;
          }
          uStack_558 = (longlong *)0x1552e50;
          uStack_580 = 0x1025d0;
          (*_DAT_)(1,0x19591e0,0x1985ba8,0x27d);
          goto LAB_;
        }
        if (*(int *)(psVar16 + 2) == 0) {
          iVar9 = 0;
          *puVar1 = 0;
          uVar25 = *(uint *)(psVar16 + 8);
          uVar24 = (ulonglong)uVar25;
          *(uint *)(psVar16 + 10) = uVar25;
          pbVar35 = *(byte **)(psVar16 + 4);
          bVar6 = *pbVar35;
          pbVar22 = pbVar35;
          if ((bVar6 & 0x10) != 0) {
            uVar25 = uVar25 + (*(ushort *)(pbVar35 + uVar24) + 7 >> 3) + 2;
            uVar24 = (ulonglong)uVar25;
            *(uint *)(psVar16 + 10) = uVar25;
            bVar6 = *pbVar35;
            pbVar22 = *(byte **)(psVar16 + 4);
          }
          if ((bVar6 & 0x20) == 0) {
            *(int *)(psVar16 + 2) = (int)uVar24;
            psVar16[0xe] = 0;
            *(uint *)(psVar16 + 0xc) = uVar25;
          }
          else {
            puVar36 = (ushort *)(pbVar35 + uVar24);
            uVar8 = *puVar36;
            psVar16[0xe] = uVar8;
            puStack_4a0 = puVar36;
            if (uVar8 == 0) {
              uStack_580 = 0x102fcc;
              cVar5 = func_0x(0x1ee7ee0);
              if (cVar5 != '\0') {
                uStack_580 = 0x102fd5;
                lVar12 = func_0x();
                if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                  uStack_580 = 0x102fef;
                  cVar5 = func_0x(0x1ee7ee0);
                  if (cVar5 == '\0') {
                    uStack_580 = 0x10300b;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    uStack_558 = (longlong *)0x0;
                    uStack_580 = 0x10302e;
                    (*_DAT_)(1,0x17d78ec,0x18f79d8,0x80f);
                  }
                }
              }
              uStack_580 = 0x10303c;
              func_0x(*(undefined8 *)(psVar16 + 4),3);
              uVar8 = psVar16[0xe];
              uVar25 = *(uint *)(psVar16 + 10);
            }
            uVar25 = uVar25 + (uVar8 + 1) * 2;
            *(uint *)(psVar16 + 0xc) = uVar25;
            if (0x1f9e < uVar25) {
              uStack_580 = 0x10306c;
              cVar5 = func_0x(0x1ee7ee0);
              if (cVar5 != '\0') {
                uStack_580 = 0x103075;
                lVar12 = func_0x();
                if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                  uStack_580 = 0x10308f;
                  cVar5 = func_0x(0x1ee7ee0);
                  if (cVar5 == '\0') {
                    uStack_580 = 0x1030ab;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_558 = (longlong *)0x0;
                    uStack_580 = 0x1030ce;
                    (*_DAT_)(1,0x17d78ec,0x18f79d8,0x816);
                  }
                }
              }
              uStack_580 = 0x1030dc;
              func_0x(*(undefined8 *)(psVar16 + 4),4);
              uVar8 = psVar16[0xe];
              uVar25 = *(uint *)(psVar16 + 0xc);
            }
            uVar24 = (ulonglong)uVar8;
            uVar8 = puVar36[uVar24];
            *(uint *)(psVar16 + 2) = uVar8 & 0x7fff;
            if ((uVar8 & 0x7fff) < uVar25) {
              uStack_580 = 0x10310a;
              cVar5 = func_0x(0x1ee7ee0);
              if (cVar5 != '\0') {
                uStack_580 = 0x103113;
                lVar12 = func_0x();
                if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                  uStack_580 = 0x10312d;
                  cVar5 = func_0x(0x1ee7ee0);
                  if (cVar5 == '\0') {
                    uStack_580 = 0x103149;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_558 = (longlong *)0x0;
                    uStack_580 = 0x10316c;
                    (*_DAT_)(1,0x17d78ec,0x18f79d8,0x81d);
                  }
                }
              }
              uStack_580 = 0x10317a;
              func_0x(*(undefined8 *)(psVar16 + 4),4);
              uVar25 = *(uint *)(psVar16 + 0xc);
              uVar24 = (ulonglong)(ushort)psVar16[0xe];
            }
            puVar37 = puVar36;
            if ((short)uVar24 != 0) {
              do {
                puVar36 = puVar36 + 1;
                uVar30 = *puVar36 & 0x7fff;
                if ((uVar30 < uVar25) || (*(uint *)(psVar16 + 2) < uVar30)) {
                  uStack_580 = 0x1031bf;
                  cVar5 = func_0x(0x1ee7ee0);
                  if (cVar5 != '\0') {
                    uStack_580 = 0x1031c8;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      uStack_580 = 0x1031e2;
                      cVar5 = func_0x(0x1ee7ee0);
                      if (cVar5 == '\0') {
                        uStack_580 = 0x1031fe;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        uStack_558 = (longlong *)0x0;
                        uStack_580 = 0x103222;
                        (*_DAT_)(1,0x17d78ec,0x18f79d8,0x82a);
                      }
                    }
                  }
                  uStack_580 = 0x103230;
                  func_0x(*(undefined8 *)(psVar16 + 4),4);
                }
                uVar24 = (ulonglong)(ushort)psVar16[0xe];
                iVar9 = iVar9 + 1;
                puVar37 = puStack_4a0;
                uVar19 = uStack_498;
                uVar25 = uVar30;
              } while (iVar9 < (int)(uint)(ushort)psVar16[0xe]);
            }
            if ((short)puVar37[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
              do {
                lVar12 = *(longlong *)(psVar16 + 4);
                uVar25 = *(ushort *)((ulonglong)*(uint *)(psVar16 + 10) + lVar12 + uVar24 * 2) &
                         0x7fff;
                if ((int)uVar24 == 1) {
                  uVar30 = *(uint *)(psVar16 + 0xc);
                  uVar24 = (ulonglong)uVar30;
LAB_:
                  if ((uVar25 < (uint)uVar24) || (*(uint *)(psVar16 + 2) < uVar25))
                  goto LAB_;
                }
                else {
                  uVar30 = *(uint *)(psVar16 + 0xc);
                  uVar31 = *(ushort *)
                            ((ulonglong)*(uint *)(psVar16 + 10) + lVar12 + -2 + uVar24 * 2) & 0x7fff
                  ;
                  uVar24 = (ulonglong)uVar31;
                  if (uVar30 <= uVar31) goto LAB_;
LAB_:
                  uStack_580 = 0x1032bb;
                  func_0x(lVar12,7);
                  uVar30 = *(uint *)(psVar16 + 0xc);
                  lVar12 = *(longlong *)(psVar16 + 4);
                }
                uVar31 = (uint)uVar24;
                if ((uVar31 < uVar30) || (*(uint *)(psVar16 + 2) < uVar31)) goto LAB_;
                if (*(ushort *)(uVar24 + lVar12) == 5) {
                  *puVar1 = *puVar1 | 2;
                  psVar16[0xe] = psVar16[0xe] + -1;
                  psVar16[0x15] = (short)uVar24;
                  uVar34 = *(ulonglong *)(psVar16 + 4);
                  uVar7 = psVar16[0x16] & 0xc7ff;
                  uVar8 = *(ushort *)((uVar24 & 0xffff) + 2 + uVar34);
                  if ((uVar8 >> 0xe & 1) != 0) {
                    uVar7 = uVar8 & 0x3800 | uVar7;
                  }
                  psVar16[0x16] = uVar7;
                  uVar8 = (uVar7 ^ *(ushort *)((uVar24 & 0xffff) + 2 + uVar34)) & 0x7ff ^ uVar7;
                  psVar16[0x16] = uVar8;
                  uVar23 = (ulonglong)(ushort)psVar16[0x15];
                  uVar24 = (ulonglong)((uVar8 & 0x7ff) * 2) + 4 + uVar23 + (uVar7 >> 0xb & 7) * 2 +
                           uVar34;
                  if (uVar24 < uVar23 + uVar34) {
                    uStack_580 = 0x1033ce;
                    func_0x(uVar23 + uVar34,0x19);
                    uVar8 = psVar16[0x16];
                    uVar23 = (ulonglong)(ushort)psVar16[0x15];
                    uVar34 = (ulonglong)*(uint *)(psVar16 + 4);
                  }
                  if (uVar25 - uVar31 <
                      (((uVar8 & 0x7ff) * 2 - (int)uVar23) - (int)uVar34) + (int)uVar24) {
                    uStack_580 = 0x103406;
                    func_0x(uVar23 + *(longlong *)(psVar16 + 4),0x19);
                    uVar8 = psVar16[0x16];
                  }
                  if ((uVar8 & 0x3800) != 0) {
                    puVar36 = (ushort *)
                              (*(longlong *)(psVar16 + 4) + (ulonglong)(ushort)psVar16[0x15] + 4);
                    iVar9 = 0;
                    if ((uVar8 & 0x3800) != 0) {
                      do {
                        if ((uVar8 & 0x7ff) < (*puVar36 & 0x7ff)) {
                          uStack_580 = 0x103458;
                          func_0x((ulonglong)(ushort)psVar16[0x15] +
                                          *(longlong *)(psVar16 + 4),0x1a);
                          uVar8 = psVar16[0x16];
                        }
                        iVar9 = iVar9 + 1;
                        puVar36 = puVar36 + 1;
                      } while (iVar9 < (int)(uVar8 >> 0xb & 7));
                    }
                  }
                  goto LAB_;
                }
                if (*(ushort *)(uVar24 + lVar12) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar8 = psVar16[0xe] - 1;
                psVar16[0xe] = uVar8;
                if (uVar8 == 0) goto LAB_;
                uVar24 = (ulonglong)uVar8;
              } while ((short)puVar37[(ulonglong)(uVar8 - 1) + 1] < 0);
              pbVar22 = *(byte **)(psVar16 + 4);
            }
            else {
LAB_:
              pbVar22 = *(byte **)(psVar16 + 4);
            }
          }
          if ((*pbVar22 & 0x40) == 0) {
            *(undefined4 *)(psVar16 + 0x13) = 0;
          }
          else {
            *(int *)(psVar16 + 0x13) = *(int *)(psVar16 + 2);
            *(int *)(psVar16 + 2) = *(int *)(psVar16 + 2) + 0xe;
            uStack_580 = 0x1034a4;
            uVar14 = func_0x(puVar1);
            uStack_580 = 0x1034b3;
            func_0x(uVar14,auStack_2a8);
            uStack_580 = 0x1034bf;
            iVar9 = func_0x(auStack_2a8);
            *(int *)(psVar16 + 2) = *(int *)(psVar16 + 2) + iVar9;
            pbVar22 = *(byte **)(psVar16 + 4);
          }
          uVar25 = *(uint *)(psVar16 + 2);
          if ((*(byte **)(psVar16 + 0xf) != (byte *)0x0) &&
             (*(byte **)(psVar16 + 0xf) < pbVar22 + uVar25)) {
            uStack_580 = 0x1034f1;
            cVar5 = func_0x(0x1ee7ee0);
            if (cVar5 != '\0') {
              uStack_580 = 0x1034fa;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                uStack_580 = 0x103514;
                cVar5 = func_0x(0x1ee7ee0);
                if (cVar5 == '\0') {
                  uStack_580 = 0x103530;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  uStack_558 = (longlong *)0x0;
                  uStack_580 = 0x103553;
                  (*_DAT_)(1,0x17d78ec,0x18f79d8,0x886);
                }
              }
            }
            uStack_580 = 0x103561;
            func_0x(*(undefined8 *)(psVar16 + 4),0x12);
            uVar25 = *(uint *)(psVar16 + 2);
          }
          if (0x3f3b < uVar25 - 1) {
            uStack_580 = 0x10357a;
            cVar5 = func_0x(0x1ee7ee0);
            if (cVar5 != '\0') {
              uStack_580 = 0x103583;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                uStack_580 = 0x10359d;
                cVar5 = func_0x(0x1ee7ee0);
                if (cVar5 == '\0') {
                  uStack_580 = 0x1035b9;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  uStack_558 = (longlong *)0x0;
                  uStack_580 = 0x1035dc;
                  (*_DAT_)(1,0x17d78ec,0x18f79d8,0x88b);
                }
              }
            }
            uStack_580 = 0x1035ea;
            func_0x(*(undefined8 *)(psVar16 + 4),5);
          }
        }
LAB_:
        sVar29 = -*(short *)plVar21;
        if ((*(byte *)((longlong)plVar21 + 6) & 0x10) == 0) {
LAB_:
          lVar12 = (longlong)sVar29;
          if ((uint)(ushort)psVar16[0xe] < (uint)(int)sVar29) {
            auStack_4f8[0] = 0;
            pplVar33 = *(longlong ***)(psVar16 + 4);
          }
          else {
            lVar26 = *(longlong *)(psVar16 + 4);
            lVar17 = (ulonglong)*(uint *)(psVar16 + 10) + lVar26;
            if (sVar29 == 1) {
              uVar25 = *(ushort *)(lVar17 + lVar12 * 2) & 0x7fff;
              uVar24 = (ulonglong)*(uint *)(uStack_510 + 0xc);
LAB_:
              if ((uVar25 < (uint)uVar24) || (*(uint *)(psVar16 + 2) < uVar25)) goto LAB_;
            }
            else {
              uVar30 = *(ushort *)(lVar17 + -2 + lVar12 * 2) & 0x7fff;
              uVar24 = (ulonglong)uVar30;
              uVar25 = *(ushort *)(lVar17 + lVar12 * 2) & 0x7fff;
              lVar26 = *(longlong *)(psVar16 + 4);
              if (*(uint *)(uStack_510 + 0xc) <= uVar30) goto LAB_;
LAB_:
              uStack_580 = 0x1036a3;
              func_0x(lVar26,7);
            }
            auStack_4f8[0] = uVar25 - (int)uVar24;
            pplVar33 = (longlong **)(uVar24 + *(longlong *)(psVar16 + 4));
          }
        }
        else {
          uStack_558 = (longlong *)&iStack_37c;
          uStack_580 = 0x10361b;
          func_0x(puVar1,plVar21,0,(longlong)&uStack_300 + 4);
          if (iStack_37c != 0) goto LAB_;
          auStack_4f8[0] = *(uint *)plVar21[1];
          pplVar33 = (longlong **)((uint *)plVar21[1] + 1);
        }
        pplVar15 = pplStack_508;
        if (((*(uint *)(plVar21 + 8) & 0x2000) != 0) && (auStack_4f8[0] == 0)) {
          auStack_4f8[0] = 4;
          pplVar33 = (longlong **)0x157e4b4;
        }
        if ((*(byte *)(plVar21[9] + 0x2a) & 0x10) == 0) {
          plVar18 = pplStack_508[3];
        }
        else {
          plVar18 = pplStack_508[4];
        }
        *(undefined *)((longlong)plVar18 + plVar21[6]) = 0;
        if ((1 << (**(byte **)(psVar16 + 4) & 0xe) & 0x440U) != 0) {
          uStack_580 = 0x103718;
          iVar9 = func_0x(plVar21);
          if (iVar9 != 0) goto LAB_;
        }
        if (*(ushort *)((longlong)plVar21 + 0x3c) < auStack_4f8[0]) {
          uStack_580 = 0x103745;
          (*_DAT_)(6,0x52,0x16,0x91);
        }
      }
LAB_:
      uVar24 = (ulonglong)auStack_4f8[0];
      lVar12 = plVar21[9];
      if ((*(uint *)(plVar21 + 8) & 0x800) == 0) {
        if ((*(byte *)(lVar12 + 0x2a) & 0x10) == 0) {
          plVar18 = pplVar15[3];
        }
        else {
          plVar18 = pplVar15[4];
        }
        uStack_580 = 0x1038b5;
        func_0x((longlong)plVar18 + plVar21[5],pplVar33);
      }
      else {
        uVar8 = *(ushort *)(lVar12 + 0x2a) & 0x10;
        if (*(int *)(lVar12 + 0x10) == 10) {
          if (uVar8 == 0) {
            plVar18 = pplVar15[3];
          }
          else {
            plVar18 = pplVar15[4];
          }
          *(longlong ***)((longlong)plVar18 + plVar21[5]) = pplVar33;
        }
        else {
          if (uVar8 == 0) {
            plVar18 = pplVar15[3];
          }
          else {
            plVar18 = pplVar15[4];
          }
          uStack_580 = 0x1038eb;
          func_0x(*(undefined8 *)(plVar21[5] + (longlong)plVar18),pplVar33);
        }
      }
      if ((*(uint *)(plVar21 + 8) & 0x100) != 0) {
        if ((*(byte *)(plVar21[9] + 0x2a) & 0x10) == 0) {
          plVar18 = pplVar15[3];
        }
        else {
          plVar18 = pplVar15[4];
        }
        *(ulonglong *)((longlong)plVar18 + *(longlong *)(plVar21[9] + 0x18)) = uVar24;
      }
    }
    uStack_498 = uVar19 + 1;
    plVar21 = plVar21 + 10;
  } while (uStack_498 < uStack_494);
  uStack_580 = 0x103967;
  (*(code *)(*pplStack_490)[1])(pplStack_490);
  puVar28 = auStack_578;
LAB_:
  *puStack_350 = *(undefined8 *)(lStack_460 + 0xa28);
  uVar24 = uStack_58 ^ (ulonglong)&uStack_538;
  *(undefined8 *)(puVar28 + -8) = 0x1097a2;
  func_0x(uVar24);
  return;
}

