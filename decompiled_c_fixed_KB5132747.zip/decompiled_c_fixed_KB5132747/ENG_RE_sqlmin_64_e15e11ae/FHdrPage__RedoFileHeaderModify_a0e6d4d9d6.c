
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  byte *pbVar1;
  longlong lVar2;
  byte *pbVar3;
  undefined4 uVar4;
  undefined auVar5 [16];
  char cVar6;
  code *UNRECOVERED_JUMPTABLE_00;
  ulonglong uVar7;
  undefined auStack_9d8 [88];
  undefined4 uStack_980;
  undefined2 uStack_97c;
  undefined8 uStack_970;
  longlong lStack_968;
  undefined8 uStack_958;
  undefined2 uStack_950;
  undefined8 uStack_948;
  undefined2 uStack_938;
  undefined4 uStack_934;
  byte *pbStack_930;
  undefined8 uStack_928;
  undefined8 uStack_91a;
  undefined2 uStack_912;
  undefined2 uStack_910;
  undefined6 uStack_90e;
  undefined4 uStack_904;
  undefined auStack_900 [16];
  undefined auStack_8f0 [8];
  undefined8 uStack_8e8;
  undefined8 uStack_8e0;
  undefined6 uStack_8d8;
  undefined2 uStack_8d2;
  undefined6 uStack_8d0;
  undefined2 uStack_8ca;
  undefined2 uStack_8c8;
  undefined6 uStack_8c6;
  undefined8 uStack_8c0;
  short *psStack_8b8;
  short *psStack_8b0;
  short sStack_8a8;
  undefined6 uStack_8a6;
  undefined auStack_8a0 [8];
  undefined8 uStack_898;
  undefined8 uStack_890;
  undefined2 uStack_888;
  undefined4 uStack_884;
  undefined8 uStack_880;
  undefined8 uStack_878;
  undefined8 uStack_86a;
  undefined8 uStack_860;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_9d8;
  uStack_888 = 0xffff;
  uStack_880 = 0;
  uStack_884 = 0;
  uStack_86a = 0;
  uStack_860 = 0;
  uStack_878 = 0;
  uStack_938 = 0xffff;
  pbStack_930 = (byte *)0x0;
  uStack_934 = 0;
  uStack_91a = 0;
  uStack_910 = 0;
  uStack_90e = 0;
  uStack_928 = 0;
  uStack_904 = 0;
  uStack_970 = param_2;
  lStack_968 = param_1;
  uStack_948 = param_3;
  if (-1 < *(char *)(param_1 + 2)) goto LAB_;
  pbVar3 = (byte *)(param_1 + 0x60);
  uStack_8d8 = 0;
  stack0xfffffffffffff712 = SUB1614(ZEXT816(0),2);
  auStack_8f0._0_2_ = 0xffff;
  uStack_8ca = 0;
  uStack_8e8 = 0;
  uStack_8c0 = 0;
  uStack_8d2 = 0;
  uStack_8d0 = 0;
  uStack_8c8 = 0;
  uStack_8c6 = 0;
  uStack_8e0 = 0;
  psStack_8b8 = (short *)0x0;
  _auStack_8a0 = ZEXT812(0);
  uStack_898._4_4_ = 0;
  auVar5 = _auStack_8a0;
  uStack_898 = 0;
  uStack_890 = 0;
  psStack_8b0 = (short *)0x0;
  sStack_8a8 = 0;
  uStack_8a6 = 0;
  auStack_900 = ZEXT816(0);
  lVar2 = 0;
  if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
    auStack_900._8_8_ = lVar2;
    uStack_958 = *(undefined8 *)(param_1 + 0x28);
    uStack_950 = *(undefined2 *)(param_1 + 0x30);
  }
  else {
    cVar6 = *(char *)(param_1 + 1);
    if (cVar6 == '\v') {
      if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
        if (cVar6 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar6 != '\b') goto LAB_;
LAB_:
      if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
    }
    uStack_980 = *(undefined4 *)(param_1 + 0x20);
    uStack_97c = *(undefined2 *)(param_1 + 0x24);
    _auStack_8a0 = auVar5;
    cVar6 = func_0x(&uStack_980,0x10ac360);
    lVar2 = auStack_900._8_8_;
    if (cVar6 == '\0') goto LAB_;
    func_0x(param_1,&uStack_958);
  }
  auStack_8a0 = (undefined  [8])uStack_958;
  uStack_898._4_4_ = *(undefined4 *)(param_1 + 0x20);
  auStack_900._0_8_ = pbVar3;
  lVar2 = (ulonglong)*pbVar3 * 6;
  uVar4 = *(undefined4 *)(lVar2 + 0x112ac40);
  uVar7 = (ulonglong)*(short *)(lVar2 + 0x112ac44);
  auStack_8f0._0_2_ = 0xffff;
  uStack_898._0_2_ = uStack_950;
  auStack_8f0 = (undefined  [8])((ulonglong)auStack_8f0 & 0xffffffff);
  uStack_8e8 = 0;
  uStack_8d2 = 0;
  uStack_8d0 = 0;
  uStack_8c8 = 0;
  uStack_8c6 = 0;
  uStack_8e0 = 0;
  sStack_8a8 = 0;
  psStack_8b8 = (short *)0x0;
  psStack_8b0 = (short *)0x0;
  uStack_980 = uVar4;
  if ((*pbVar3 & 2) != 0) {
    pbVar1 = pbVar3 + uVar7;
    uStack_8e8 = pbVar1;
    if ((pbVar3[uVar7] & 1) == 0) {
      auVar5._14_2_ = 0;
      auVar5._0_14_ = stack0xfffffffffffff712;
      _auStack_8f0 = auVar5 << 0x10;
      uStack_8ca = 0;
      uStack_8c8 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100384 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x101884) - 0x146e1d0))()
      ;
      return;
    }
    auStack_8f0._0_2_ = 1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x101864) * 4 +
                           0x101854) - 0x146e1d0);
                    /* WARNING: Could not emulate address calculation at 0x00100232 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((*pbVar3 & 4) != 0) {
    uStack_980._2_2_ = (short)((uint)uVar4 >> 0x10);
    if (uStack_980._2_2_ != 0) {
      uVar7 = (ulonglong)*(ushort *)(param_1 + 0x61 + (longlong)uStack_980._2_2_ * 2);
    }
    psStack_8b8 = (short *)(pbVar3 + uVar7);
    psStack_8b0 = psStack_8b8 + 1;
    sStack_8a8 = (*psStack_8b8 + 1) * 2;
  }
  if (auStack_900._8_8_ != 0) {
    func_0x(auStack_900._8_8_,auStack_900);
  }
LAB_:
  pbStack_930 = (byte *)((ulonglong)*(ushort *)(lStack_968 + 0x1ffe) + lStack_968);
  if ((*pbStack_930 & 1) == 0) {
    uStack_938 = 0;
    uStack_934 = 0;
    uStack_912 = 0;
    uStack_910 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010060a */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_930 & 0xe) * 4 + 0x1018f0) - 0x146e1d0)
    )((longlong)(int)(*pbStack_930 & 0xe),0x10ac360,pbStack_930);
    return;
  }
  uStack_938 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_930 & 0x1c) + 0x1018d0) * 4
                         + 0x1018c0) - 0x146e1d0);
                    /* WARNING: Could not emulate address calculation at 0x00100499 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

