
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,short *param_3,int *param_4)

{
  byte **ppbVar1;
  byte **ppbVar2;
  byte *pbVar3;
  ushort uVar4;
  ushort uVar5;
  undefined2 uVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  longlong lVar9;
  undefined8 uVar10;
  char cVar11;
  byte bVar12;
  undefined uVar13;
  undefined2 uVar14;
  int iVar15;
  int iVar16;
  uint uVar17;
  uint uVar18;
  undefined4 uVar19;
  longlong lVar20;
  undefined2 *puVar21;
  ushort *puVar22;
  undefined2 *puVar23;
  byte **ppbVar24;
  ulonglong uVar25;
  ulonglong uVar26;
  undefined8 uVar27;
  uint *puVar28;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar29;
  undefined4 *puVar30;
  longlong *plVar31;
  longlong *plVar32;
  undefined8 *puVar33;
  int *piVar34;
  longlong lVar35;
  longlong lVar36;
  longlong **pplVar37;
  short sVar38;
  ulonglong uVar39;
  longlong unaff_GS_OFFSET;
  char acStackX_8 [8];
  longlong *plStackX_10;
  char acStackX_18 [4];
  uint uStackX_1c;
  uint auStackX_20 [2];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar20 = func_0x();
  lVar20 = -lVar20;
  *(undefined8 *)(&stack0x000016c8 + lVar20) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002770 + lVar20) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar20);
  *(int **)(&stack0x00000630 + lVar20) = param_4;
  *(short **)(&stack0x00000278 + lVar20) = param_3;
  *(longlong *)(&stack0x000000f0 + lVar20) = param_1;
  *(longlong *)(&stack0x00000a88 + lVar20) = param_1;
  puVar23 = *(undefined2 **)(&stack0x000027d8 + lVar20);
  *(undefined2 **)(&stack0x000005d0 + lVar20) = puVar23;
  puVar30 = *(undefined4 **)(&stack0x000027e0 + lVar20);
  *(undefined4 **)(&stack0x00000340 + lVar20) = puVar30;
  puVar8 = *(undefined4 **)(&stack0x000027e8 + lVar20);
  *(undefined4 **)(&stack0x00000a80 + lVar20) = puVar8;
  *(undefined4 *)(&stack0x00000058 + lVar20) = 0;
  *(undefined2 *)(&stack0x0000005c + lVar20) = 0;
  *(undefined8 *)((longlong)&plStackX_10 + lVar20) = 0;
  acStackX_18[lVar20] = '\0';
  uVar17 = *(uint *)((longlong)&uStackX_1c + lVar20);
  *(uint *)((longlong)&uStackX_1c + lVar20) = uVar17 & 0xffff0000;
  *(uint *)((longlong)&uStackX_1c + lVar20) = uVar17 & 0xff000000;
  *(undefined4 *)((longlong)&uStackX_1c + lVar20) = 0;
  *(undefined4 *)(&stack0x00000208 + lVar20) = 0;
  acStackX_8[lVar20] = '\x01';
  *puVar23 = 0xffff;
  *puVar30 = 0;
  *puVar8 = 0;
  if (*(int *)(param_1 + 0xd0) != 2) {
    *(int *)(&stack0x00000204 + lVar20) = *(int *)(param_1 + 0x80) + param_2;
    while (acStackX_8[lVar20] != '\0') {
      *(undefined4 **)(&stack0x000016d0 + lVar20) = (undefined4 *)(param_1 + 0x170);
      *(undefined4 **)(&stack0x000016d8 + lVar20) = (undefined4 *)(param_1 + 0x16c);
      *(undefined4 *)(param_1 + 0x16c) = 0;
      *(undefined4 *)(param_1 + 0x170) = 0;
      pplVar37 = (longlong **)(param_1 + 0x68);
      *(longlong ***)(&stack0x000016e0 + lVar20) = pplVar37;
      if (((*pplVar37 != (longlong *)0x0) && (*(short *)(param_1 + 0x74) != 1)) ||
         (*(int *)(param_1 + 0x90) != 0)) goto LAB_;
      lVar35 = **(longlong **)(param_1 + 8);
      *(longlong *)(&stack0x00000788 + lVar20) = lVar35;
      *(longlong ***)(&stack0x000016e8 + lVar20) = pplVar37;
      if ((*(int *)(param_1 + 0x80) == -1) && (*(int *)(param_1 + 0x90) == 0)) {
LAB_:
        (&stack0x00001cac)[lVar20] = 0;
        uVar17 = (uint)(*(short *)(*(longlong *)(lVar35 + 8) + 0x3c4) != 1);
        *(uint *)(&stack0x00000ab8 + lVar20) = uVar17;
        iVar15 = *(int *)(param_1 + 0xf4);
        *(undefined8 *)((longlong)auStackX_20 + lVar20 + -0x20) = 0;
        *(undefined **)(&stack0xfffffffffffffff8 + lVar20) = &stack0x00001c98 + lVar20;
        *(longlong ***)(&stack0xfffffffffffffff0 + lVar20) = pplVar37;
        *(uint *)(&stack0xffffffffffffffe8 + lVar20) = uVar17 + iVar15;
        uVar27 = *(undefined8 *)(param_1 + 0xa8);
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100706;
        func_0x(param_1,uVar27,0,0);
      }
      else {
        *(undefined4 *)(&stack0x00000aec + lVar20) = 0;
        *(undefined4 *)(&stack0x00000af0 + lVar20) = 0;
        (&stack0xfffffffffffffff8)[lVar20] = 1;
        *(undefined8 *)(&stack0xfffffffffffffff0 + lVar20) = 0;
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar20) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1001be;
        func_0x(pplVar37,2,0xffffffff);
        if (*(int *)(&stack0x00000aec + lVar20) != 0) {
          lVar36 = **pplVar37;
          *(longlong *)(&stack0x000016f0 + lVar20) = lVar36;
          uVar13 = *(undefined *)(lVar36 + 1);
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1001f0;
          func_0x(lVar35,uVar13,&stack0x00000ae8 + lVar20);
        }
        lVar36 = **pplVar37;
        *(longlong *)(&stack0x000016f8 + lVar20) = lVar36;
        *(int **)(&stack0x00001700 + lVar20) = (int *)(param_1 + 0xbc);
        lVar29 = **(longlong **)(param_1 + 8);
        puVar28 = (uint *)(lVar29 + 0x14);
        *(uint **)(&stack0x00001708 + lVar20) = puVar28;
        if (((*puVar28 & 0xe0000000) == 0x80000000) && (*(ushort *)(lVar29 + 0x18) < 0x100)) {
LAB_:
          *(undefined4 *)(&stack0x000003a8 + lVar20) = 1;
          *(longlong ***)(&stack0x00000690 + lVar20) = pplVar37;
          if (*pplVar37 != (longlong *)0x0) {
            puVar21 = (undefined2 *)((longlong)*pplVar37 + 0x62);
            *(undefined2 **)(&stack0x00001740 + lVar20) = puVar21;
            *(undefined2 *)(&stack0x00000108 + lVar20) = *puVar21;
            plVar31 = *(longlong **)(&stack0x00000690 + lVar20);
            if (((*(ushort *)(&stack0x00000108 + lVar20) & 0x400) == 0) ||
               (*(short *)((longlong)plVar31 + 0xc) < 3)) {
              *(int *)(&stack0x000000c0 + lVar20) = (int)*(short *)((longlong)plVar31 + 0xc);
              lVar35 = *plVar31;
              *(longlong *)(&stack0x00000230 + lVar20) = lVar35;
              puVar21 = (undefined2 *)(lVar35 + 0x62);
              *(undefined2 **)(&stack0x00001738 + lVar20) = puVar21;
              uVar14 = *puVar21;
              *(undefined2 *)(&stack0x00000110 + lVar20) = uVar14;
              if (((byte)uVar14 >> 3 & 1) != 0) {
                if (*(int *)(&stack0x000000c0 + lVar20) == 3) {
                  *(undefined4 *)(&stack0x000000c0 + lVar20) = 4;
                }
                else if (*(int *)(&stack0x000000c0 + lVar20) < 2) goto LAB_;
                *(uint **)(&stack0x00001748 + lVar20) =
                     (uint *)(*(longlong *)(&stack0x00000230 + lVar20) + 100);
                uVar17 = *(uint *)(*(longlong *)(&stack0x00000230 + lVar20) + 100);
                *(uint *)(&stack0x000003b0 + lVar20) = uVar17;
                if ((((uVar17 & 8) != 0) &&
                    (lVar35 = *(longlong *)(*(longlong *)(&stack0x00000230 + lVar20) + 0x90),
                    lVar35 != 0)) &&
                   (*(longlong *)(&stack0x00001750 + lVar20) = lVar35,
                   *(longlong *)(lVar35 + 0x758) != 0)) {
                  uVar27 = *(undefined8 *)(lVar35 + 0x758);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10057b;
                  func_0x
                            (uVar27,*(undefined8 *)(&stack0x00000230 + lVar20),
                             *(undefined4 *)(&stack0x000000c0 + lVar20));
                }
              }
LAB_:
              (&stack0x000001b8)[lVar20] = DAT_ >> 7;
              if ((char)DAT_ < '\0') {
                puVar28 = (uint *)(*(longlong *)(&stack0x00000230 + lVar20) + 100);
                *(uint **)(&stack0x00001758 + lVar20) = puVar28;
                uVar17 = *puVar28;
                *(uint *)(&stack0x000003b8 + lVar20) = uVar17;
                if (((uVar17 & 8) != 0) && (2 < *(int *)(&stack0x000000c0 + lVar20))) {
                  *(uint **)(&stack0x00000b50 + lVar20) = puVar28;
                  uVar17 = *puVar28;
                  *(uint *)(&stack0x000003c0 + lVar20) = uVar17;
                  if (((uVar17 & 0xc0000000) != 0x40000000) &&
                     (lVar35 = **(longlong **)(&stack0x00000230 + lVar20), lVar35 != 0)) {
                    *(undefined4 *)(&stack0x00000aa0 + lVar20) = 2;
                    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10060e;
                    iVar15 = (*_DAT_)(lVar35,0x2000,2);
                    if (iVar15 != 0) {
                      LOCK();
                      *puVar28 = *puVar28 & 0x3fffffff;
                      UNLOCK();
                      LOCK();
                      *puVar28 = *puVar28 | 0x40000000;
                      UNLOCK();
                    }
                  }
                }
              }
              lVar35 = *(longlong *)(&stack0x00000230 + lVar20);
              uVar19 = *(undefined4 *)(&stack0x000000c0 + lVar20);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10063f;
              func_0x(lVar35 + 0x98,uVar19);
              if ((_DAT_ != 0) &&
                 ((&stack0x000001b9)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100669;
                func_0x(lVar35,0,uVar19);
              }
              *(uint *)((longlong)plVar31 + 0xc) = *(uint *)((longlong)plVar31 + 0xc) & 0xffff0000;
              **(undefined8 **)(&stack0x00000690 + lVar20) = 0;
              lVar35 = *(longlong *)(&stack0x00000788 + lVar20);
              param_1 = *(longlong *)(&stack0x000000f0 + lVar20);
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100431;
              func_0x(plVar31);
              lVar35 = *(longlong *)(&stack0x00000788 + lVar20);
            }
          }
          *(undefined4 *)(param_1 + 0x80) = 0xffffffff;
          iVar15 = *(int *)(param_1 + 0xcc);
          if (iVar15 != 0) {
            *(int *)(&stack0x00000aa8 + lVar20) = iVar15;
            lVar29 = (longlong)*(int *)(param_1 + 200);
            *(int *)(&stack0x00000ab0 + lVar20) = *(int *)(param_1 + 200);
            lVar36 = *(longlong *)(lVar35 + 0x20);
            *(longlong *)(&stack0x00000b58 + lVar20) = lVar36;
            lVar36 = *(longlong *)(lVar36 + 0x6c10);
            *(longlong *)(&stack0x00000b60 + lVar20) = lVar36;
            if (lVar36 != 0) {
              if (iVar15 == 1) {
                plVar31 = (longlong *)(lVar36 + lVar29 * 0x28);
                *plVar31 = *plVar31 + 1;
              }
              else if (iVar15 == 2) {
                plVar31 = (longlong *)(lVar36 + 8 + lVar29 * 0x28);
                *plVar31 = *plVar31 + 1;
              }
              else if (iVar15 == 3) {
                plVar31 = (longlong *)(lVar36 + 0x18 + lVar29 * 0x28);
                *plVar31 = *plVar31 + 1;
              }
            }
            *(undefined4 *)(param_1 + 0xcc) = 0;
          }
          goto LAB_;
        }
        (&stack0x0000004c)[lVar20] = 0;
        if (*(short *)(lVar36 + 0x24) == 0) {
LAB_:
          *(undefined8 *)(&stack0x000002b0 + lVar20) = *(undefined8 *)(lVar36 + 0x28);
          sVar38 = *(short *)(lVar36 + 0x30);
          *(short *)(&stack0x000002b8 + lVar20) = sVar38;
        }
        else {
          cVar11 = *(char *)(lVar36 + 1);
          if ((((cVar11 == '\v') || (cVar11 == '\b')) || (cVar11 == '\t')) &&
             (*(int *)(lVar36 + 0x18) == 99)) {
            *(undefined **)(&stack0x00001710 + lVar20) = &stack0x000002f0 + lVar20;
            *(undefined4 **)(&stack0x00001718 + lVar20) = (undefined4 *)(lVar36 + 0x20);
            *(undefined4 *)(&stack0x000002f0 + lVar20) = *(undefined4 *)(lVar36 + 0x20);
            *(undefined2 *)(&stack0x000002f4 + lVar20) = *(undefined2 *)(lVar36 + 0x24);
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1002a7;
            cVar11 = func_0x(&stack0x000002f0 + lVar20);
            if (cVar11 == '\0') goto LAB_;
            cVar11 = '\x01';
          }
          else {
LAB_:
            cVar11 = '\0';
          }
          (&stack0x0000004c)[lVar20] = cVar11;
          if (cVar11 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1002cc;
          func_0x(lVar36,&stack0x000002b0 + lVar20);
          sVar38 = *(short *)(&stack0x000002b8 + lVar20);
        }
        *(undefined **)(&stack0x00001720 + lVar20) = &stack0x000002b0 + lVar20;
        if (((sVar38 != *(short *)(param_1 + 0xc4)) ||
            (*(int *)(&stack0x000002b0 + lVar20) != *(int *)(param_1 + 0xbc))) ||
           (*(int *)(&stack0x000002b4 + lVar20) != *(int *)(param_1 + 0xc0))) goto LAB_;
        *(undefined4 *)(&stack0x000003a8 + lVar20) = 0;
        iVar15 = *(int *)(param_1 + 0xcc);
        if (iVar15 == 0) goto LAB_;
        *(int *)(&stack0x00000a90 + lVar20) = iVar15;
        lVar36 = (longlong)*(int *)(param_1 + 200);
        *(int *)(&stack0x00000a98 + lVar20) = *(int *)(param_1 + 200);
        lVar35 = *(longlong *)(lVar35 + 0x20);
        *(longlong *)(&stack0x00001728 + lVar20) = lVar35;
        lVar35 = *(longlong *)(lVar35 + 0x6c10);
        *(longlong *)(&stack0x00001730 + lVar20) = lVar35;
        if (lVar35 == 0) {
LAB_:
          *(undefined4 *)(param_1 + 0xcc) = 0;
        }
        else {
          if (iVar15 == 1) {
            plVar31 = (longlong *)(lVar35 + 0x10 + lVar36 * 0x28);
            *plVar31 = *plVar31 + 1;
            goto LAB_;
          }
          if (iVar15 == 2) {
            plVar31 = (longlong *)(lVar35 + 8 + lVar36 * 0x28);
            *plVar31 = *plVar31 + 1;
            *(undefined4 *)(param_1 + 0xcc) = 0;
          }
          else {
            if (iVar15 != 3) goto LAB_;
            plVar31 = (longlong *)(lVar35 + 0x20 + lVar36 * 0x28);
            *plVar31 = *plVar31 + 1;
            *(undefined4 *)(param_1 + 0xcc) = 0;
          }
        }
      }
LAB_:
      if (*(int *)(param_1 + 0x90) != 0) {
        if (*(int *)(param_1 + 0xd0) != 2) {
          *(longlong ***)(&stack0x00000698 + lVar20) = pplVar37;
          if (*pplVar37 != (longlong *)0x0) {
            puVar22 = (ushort *)((longlong)*pplVar37 + 0x62);
            *(ushort **)(&stack0x00000b68 + lVar20) = puVar22;
            uVar4 = *puVar22;
            *(ushort *)(&stack0x00000118 + lVar20) = uVar4;
            plVar31 = *(longlong **)(&stack0x00000698 + lVar20);
            if (((uVar4 & 0x400) == 0) || (*(short *)((longlong)plVar31 + 0xc) < 3)) {
              *(int *)(&stack0x000000c8 + lVar20) = (int)*(short *)((longlong)plVar31 + 0xc);
              lVar35 = *plVar31;
              *(longlong *)(&stack0x00000220 + lVar20) = lVar35;
              puVar23 = (undefined2 *)(lVar35 + 0x62);
              *(undefined2 **)(&stack0x00000b70 + lVar20) = puVar23;
              uVar14 = *puVar23;
              *(undefined2 *)(&stack0x00000120 + lVar20) = uVar14;
              if (((byte)uVar14 >> 3 & 1) != 0) {
                if (*(int *)(&stack0x000000c8 + lVar20) == 3) {
                  *(undefined4 *)(&stack0x000000c8 + lVar20) = 4;
                }
                else if (*(int *)(&stack0x000000c8 + lVar20) < 2) goto LAB_;
                *(uint **)(&stack0x00000b78 + lVar20) =
                     (uint *)(*(longlong *)(&stack0x00000220 + lVar20) + 100);
                uVar17 = *(uint *)(*(longlong *)(&stack0x00000220 + lVar20) + 100);
                *(uint *)(&stack0x000003c8 + lVar20) = uVar17;
                if ((((uVar17 & 8) != 0) &&
                    (lVar35 = *(longlong *)(*(longlong *)(&stack0x00000220 + lVar20) + 0x90),
                    lVar35 != 0)) &&
                   (*(longlong *)(&stack0x00000b80 + lVar20) = lVar35,
                   *(longlong *)(lVar35 + 0x758) != 0)) {
                  uVar27 = *(undefined8 *)(lVar35 + 0x758);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10083f;
                  func_0x
                            (uVar27,*(undefined8 *)(&stack0x00000220 + lVar20),
                             *(undefined4 *)(&stack0x000000c8 + lVar20));
                }
              }
LAB_:
              (&stack0x000001ba)[lVar20] = DAT_ >> 7;
              if ((char)DAT_ < '\0') {
                puVar28 = (uint *)(*(longlong *)(&stack0x00000220 + lVar20) + 100);
                *(uint **)(&stack0x00000b88 + lVar20) = puVar28;
                uVar17 = *puVar28;
                *(uint *)(&stack0x000003d0 + lVar20) = uVar17;
                if (((uVar17 & 8) != 0) && (2 < *(int *)(&stack0x000000c8 + lVar20))) {
                  *(uint **)(&stack0x00000b90 + lVar20) = puVar28;
                  uVar17 = *puVar28;
                  *(uint *)(&stack0x000003d8 + lVar20) = uVar17;
                  if (((uVar17 & 0xc0000000) != 0x40000000) &&
                     (lVar35 = **(longlong **)(&stack0x00000220 + lVar20), lVar35 != 0)) {
                    *(undefined4 *)(&stack0x00000abc + lVar20) = 2;
                    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1008d2;
                    iVar15 = (*_DAT_)(lVar35,0x2000,2,&stack0x00000ac0 + lVar20);
                    if (iVar15 != 0) {
                      LOCK();
                      *puVar28 = *puVar28 & 0x3fffffff;
                      UNLOCK();
                      LOCK();
                      *puVar28 = *puVar28 | 0x40000000;
                      UNLOCK();
                    }
                  }
                }
              }
              lVar35 = *(longlong *)(&stack0x00000220 + lVar20);
              uVar19 = *(undefined4 *)(&stack0x000000c8 + lVar20);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100901;
              func_0x(lVar35 + 0x98,uVar19);
              if ((_DAT_ != 0) &&
                 ((&stack0x000001bb)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10092b;
                func_0x(lVar35,0,uVar19);
              }
              *(uint *)((longlong)plVar31 + 0xc) = *(uint *)((longlong)plVar31 + 0xc) & 0xffff0000;
              **(undefined8 **)(&stack0x00000698 + lVar20) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10077b;
              func_0x(plVar31);
            }
          }
          *(undefined4 *)(param_1 + 0x80) = 0xffffffff;
          *(undefined8 **)(&stack0x00000b98 + lVar20) = (undefined8 *)(param_1 + 0x88);
          if (*(int *)(param_1 + 0x90) != 0) {
            *(undefined4 *)(&stack0x00000ac8 + lVar20) = *(undefined4 *)(param_1 + 0x94);
            *(undefined8 *)(&stack0x00000ba0 + lVar20) = *(undefined8 *)(param_1 + 0x88);
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10097c;
            func_0x();
            *(undefined4 *)(param_1 + 0x90) = 0;
          }
          *(undefined4 *)(&stack0x000000d8 + lVar20) = 0;
          *(undefined2 *)(&stack0x000000dc + lVar20) = 0;
          *(undefined4 **)(&stack0x00000ba8 + lVar20) = (undefined4 *)(param_1 + 0x9c);
          *(undefined4 *)(param_1 + 0x9c) = 0;
          *(undefined2 *)(param_1 + 0xa0) = 0;
          *(undefined4 *)(&stack0x000006e0 + lVar20) = 0;
          *(undefined4 *)(&stack0x000006e4 + lVar20) = 0;
          *(undefined2 *)(&stack0x000006e8 + lVar20) = 0;
          *(undefined8 *)(param_1 + 0xbc) = *(undefined8 *)(&stack0x000006e0 + lVar20);
          *(undefined2 *)(param_1 + 0xc4) = 0;
          *(undefined4 *)(param_1 + 0xd0) = 2;
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1009e9;
        func_0x((longlong)&plStackX_10 + lVar20);
        goto LAB_;
      }
      acStackX_8[lVar20] = '\0';
      lVar35 = **pplVar37;
      *(longlong *)(&stack0x00000bb0 + lVar20) = lVar35;
      iVar15 = *(int *)(param_1 + 0x80);
      *(int *)(&stack0x00000ad0 + lVar20) = iVar15;
      *(longlong *)(&stack0x000000f8 + lVar20) = (longlong)iVar15;
      uVar4 = *(ushort *)(lVar35 + (0xfff - (longlong)iVar15) * 2);
      *(ushort *)(&stack0x000005c8 + lVar20) = uVar4;
      pbVar3 = (byte *)((ulonglong)uVar4 + lVar35);
      *(byte **)(&stack0x00000bb8 + lVar20) = pbVar3;
      bVar12 = *pbVar3;
      *(ushort *)(&stack0x000005e8 + lVar20) = (ushort)(bVar12 & 1);
      if ((bVar12 & 1) != 0) {
        *(undefined2 *)(&stack0x00001a38 + lVar20) = 0xffff;
        *(undefined8 *)(&stack0x00001a40 + lVar20) = 0;
        *(undefined4 *)(&stack0x00001a3c + lVar20) = 0;
        *(undefined8 *)(&stack0x00001a56 + lVar20) = 0;
        *(undefined8 *)(&stack0x00001a60 + lVar20) = 0;
        *(undefined8 *)(&stack0x00001a48 + lVar20) = 0;
        *(undefined4 *)(&stack0x00001a6c + lVar20) = 0xffffffff;
        *(int *)(&stack0x00001a6c + lVar20) = iVar15;
        if (-1 < *(char *)(lVar35 + 2)) {
          *(undefined8 *)(&stack0x00000770 + lVar20) = 0;
          goto LAB_;
        }
        *(undefined8 *)(&stack0x00000bc0 + lVar20) = 0;
        *(undefined8 *)(&stack0x00000770 + lVar20) = 0;
        *(undefined **)(&stack0x00000bc8 + lVar20) = &stack0x00001a70 + lVar20;
        *(undefined (*) [16])(&stack0x00001a70 + lVar20) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x00001a80 + lVar20) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x00001a90 + lVar20) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x00001aa0 + lVar20) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x00001ab0 + lVar20) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x00001ac0 + lVar20) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x00001ad0 + lVar20) = ZEXT816(0);
        *(undefined8 *)(&stack0x00001ae0 + lVar20) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100b2a;
        ppbVar24 = (byte **)func_0x(&stack0x00001a70 + lVar20);
        *(byte ***)(&stack0x00000770 + lVar20) = ppbVar24;
        (&stack0x0000004d)[lVar20] = 0;
        if (*(short *)(lVar35 + 0x24) == 0) {
LAB_:
          *(undefined8 *)(&stack0x00001c68 + lVar20) = *(undefined8 *)(lVar35 + 0x28);
          sVar38 = *(short *)(lVar35 + 0x30);
          *(short *)(&stack0x00001c70 + lVar20) = sVar38;
        }
        else {
          cVar11 = *(char *)(lVar35 + 1);
          if ((((cVar11 == '\v') || (cVar11 == '\b')) || (cVar11 == '\t')) &&
             (*(int *)(lVar35 + 0x18) == 99)) {
            *(undefined **)(&stack0x00000bd0 + lVar20) = &stack0x000002f8 + lVar20;
            *(undefined4 **)(&stack0x00000bd8 + lVar20) = (undefined4 *)(lVar35 + 0x20);
            *(undefined4 *)(&stack0x000002f8 + lVar20) = *(undefined4 *)(lVar35 + 0x20);
            *(undefined2 *)(&stack0x000002fc + lVar20) = *(undefined2 *)(lVar35 + 0x24);
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100b9c;
            cVar11 = func_0x(&stack0x000002f8 + lVar20);
            if (cVar11 == '\0') goto LAB_;
            cVar11 = '\x01';
          }
          else {
LAB_:
            cVar11 = '\0';
          }
          (&stack0x0000004d)[lVar20] = cVar11;
          if (cVar11 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100bc1;
          func_0x(lVar35,&stack0x00001c68 + lVar20);
          sVar38 = *(short *)(&stack0x00001c70 + lVar20);
        }
        *(undefined **)(&stack0x00000be0 + lVar20) = &stack0x00001c68 + lVar20;
        *(longlong *)(&stack0x00000be8 + lVar20) = lVar35 + 0x20;
        pbVar3 = (byte *)(lVar35 + 0x60);
        *(byte **)(&stack0x00000bf0 + lVar20) = pbVar3;
        *(byte ***)(&stack0x00000bf8 + lVar20) = ppbVar24;
        if (pbVar3 == *ppbVar24) {
          *(byte ***)(&stack0x00000c00 + lVar20) = ppbVar24 + 0xc;
          if (((sVar38 == *(short *)(ppbVar24 + 0xd)) &&
              (*(int *)(&stack0x00001c68 + lVar20) == *(int *)(ppbVar24 + 0xc))) &&
             (*(int *)(&stack0x00001c6c + lVar20) == *(int *)((longlong)ppbVar24 + 100))) {
            *(longlong *)(&stack0x00000c08 + lVar20) = (longlong)ppbVar24 + 0x6c;
          }
        }
        *ppbVar24 = pbVar3;
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100c67;
        func_0x(ppbVar24 + 0xc,&stack0x00001c68 + lVar20);
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100c73;
        func_0x((longlong)ppbVar24 + 0x6c,lVar35 + 0x20);
        uVar39 = (ulonglong)*pbVar3;
        *(ushort *)(&stack0x000005f0 + lVar20) = (ushort)*pbVar3;
        *(undefined4 *)(&stack0x00000790 + lVar20) = *(undefined4 *)(uVar39 * 6 + 0x176c630);
        *(undefined2 *)(&stack0x00000794 + lVar20) = *(undefined2 *)(uVar39 * 6 + 0x176c634);
        *(undefined4 *)(&stack0x00000610 + lVar20) = *(undefined4 *)(uVar39 * 6 + 0x176c630);
        sVar38 = *(short *)(uVar39 * 6 + 0x176c634);
        uVar39 = (ulonglong)sVar38;
        *(short *)(&stack0x00000614 + lVar20) = sVar38;
        *(longlong *)(&stack0x00000c10 + lVar20) = lVar35 + 99;
        ppbVar1 = ppbVar24 + 2;
        *(byte ***)(&stack0x00000c18 + lVar20) = ppbVar1;
        *(undefined2 *)ppbVar1 = 0xffff;
        ppbVar24[3] = (byte *)0x0;
        *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
        *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
        ppbVar24[7] = (byte *)0x0;
        ppbVar24[4] = (byte *)0x0;
        *(byte ***)(&stack0x00000c20 + lVar20) = ppbVar24 + 9;
        ppbVar24[9] = (byte *)0x0;
        ppbVar24[10] = (byte *)0x0;
        *(undefined2 *)(ppbVar24 + 0xb) = 0;
        if ((**ppbVar24 & 2) != 0) {
          pbVar3 = pbVar3 + uVar39;
          *(byte **)(&stack0x00000c28 + lVar20) = pbVar3;
          *(byte ***)(&stack0x00000c30 + lVar20) = ppbVar1;
          bVar12 = *pbVar3 & 1;
          *(ushort *)(&stack0x000005f8 + lVar20) = (ushort)bVar12;
          *(ushort *)ppbVar1 = (ushort)bVar12;
          if (bVar12 != 0) {
            *(longlong *)(&stack0x00000c48 + lVar20) = (longlong)ppbVar24 + 0x12;
            ppbVar24[3] = pbVar3;
            *(byte **)(&stack0x00000c50 + lVar20) = pbVar3;
            UNRECOVERED_JUMPTABLE_00 =
                 (code *)((ulonglong)
                          *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x107db0)
                                    * 4 + 0x107da0) - 0xe2c7e0);
                    /* WARNING: Could not emulate address calculation at 0x00100e5c */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
            return;
          }
          *(undefined4 *)(&stack0x000001c8 + lVar20) = 0;
          *(longlong *)(&stack0x00000c38 + lVar20) = (longlong)ppbVar24 + 0x12;
          ppbVar24[3] = pbVar3;
          *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
          *(undefined4 *)((longlong)ppbVar24 + 0x36) = 0;
          pbVar3 = ppbVar24[3];
          *(byte **)(&stack0x00000c40 + lVar20) = pbVar3;
                    /* WARNING: Could not emulate address calculation at 0x00100d8b */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x107d64) - 0xe2c7e0)
          )();
          return;
        }
        if ((**ppbVar24 & 4) != 0) {
          if (*(short *)(&stack0x00000612 + lVar20) != 0) {
            uVar39 = (ulonglong)
                     *(ushort *)
                      (lVar35 + 0x61 + (longlong)*(short *)(&stack0x00000612 + lVar20) * 2);
          }
          *(byte **)(&stack0x00000c78 + lVar20) = pbVar3 + uVar39;
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x100ff4;
          func_0x();
        }
        pbVar3 = ppbVar24[1];
        if (pbVar3 != (byte *)0x0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x101005;
          func_0x(pbVar3,ppbVar24);
        }
LAB_:
        uVar4 = *(ushort *)(lVar35 + 0xe);
        *(uint *)(&stack0x00000adc + lVar20) = (uint)uVar4;
        uVar5 = *(ushort *)(lVar35 + (0xfff - *(longlong *)(&stack0x000000f8 + lVar20)) * 2);
        *(ushort *)(&stack0x000005fa + lVar20) = uVar5;
        pbVar3 = (byte *)((ulonglong)uVar5 + lVar35);
        *(byte **)(&stack0x00000c80 + lVar20) = pbVar3;
        bVar12 = *pbVar3 & 1;
        *(ushort *)(&stack0x000005fc + lVar20) = (ushort)bVar12;
        *(ushort *)(&stack0x00001a38 + lVar20) = (ushort)bVar12;
        if (bVar12 != 0) {
          *(undefined **)(&stack0x00000c98 + lVar20) = &stack0x00001a3a + lVar20;
          *(byte **)(&stack0x00001a40 + lVar20) = pbVar3;
          *(byte **)(&stack0x00000ca0 + lVar20) = pbVar3;
          UNRECOVERED_JUMPTABLE_00 =
               (code *)((ulonglong)
                        *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x107e1c) *
                                  4 + 0x107e0c) - 0xe2c7e0);
                    /* WARNING: Could not emulate address calculation at 0x0010117d */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbVar3,0xffffffffff1d3820,pbVar3);
          return;
        }
        *(uint *)(&stack0x000001d0 + lVar20) = (uint)uVar4;
        *(undefined **)(&stack0x00000c88 + lVar20) = &stack0x00001a3a + lVar20;
        *(byte **)(&stack0x00001a40 + lVar20) = pbVar3;
        *(undefined4 *)(&stack0x00001a3c + lVar20) = 0;
        *(undefined4 *)(&stack0x00001a5e + lVar20) = 0;
        *(byte **)(&stack0x00000c90 + lVar20) = pbVar3;
                    /* WARNING: Could not emulate address calculation at 0x001010b5 */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x107dd0) - 0xe2c7e0))
                  ();
        return;
      }
      iVar15 = *param_4;
      *(int *)(&stack0x00000ad8 + lVar20) = iVar15;
      puVar30 = (undefined4 *)(pbVar3 + iVar15);
      *(undefined4 **)(&stack0x00000710 + lVar20) = puVar30;
      *(undefined4 *)(&stack0x000007a8 + lVar20) = *puVar30;
      uVar14 = *(undefined2 *)(puVar30 + 1);
      *(undefined2 *)(&stack0x000007ac + lVar20) = uVar14;
      *puVar23 = uVar14;
      uVar39 = (ulonglong)*(uint *)(param_1 + 0x80);
      *(uint *)(&stack0x000000d8 + lVar20) = *(uint *)(param_1 + 0x80);
LAB_:
      pplVar37 = (longlong **)(param_1 + 0x68);
      *(longlong ***)(&stack0x000000f8 + lVar20) = pplVar37;
      lVar35 = **pplVar37;
      *(longlong *)(&stack0x000000e0 + lVar20) = lVar35;
      *(longlong *)(&stack0x00000038 + lVar20) = lVar35;
      uVar4 = *(ushort *)(lVar35 + 0x16);
      *(uint *)(&stack0x00000458 + lVar20) = (uint)uVar4;
      *(int *)(&stack0x00000454 + lVar20) = (int)uVar39;
      iVar15 = uVar4 - 1;
      *(int *)(&stack0x00000060 + lVar20) = iVar15;
      *(int *)(&stack0x00000404 + lVar20) = iVar15;
      if (*(int *)(&stack0x00000204 + lVar20) != 0) {
        iVar16 = *(int *)(&stack0x00000204 + lVar20) + -1;
        if (iVar16 < iVar15) {
          *(int *)(&stack0x00000060 + lVar20) = iVar16;
          *(int *)(&stack0x00000404 + lVar20) = iVar16;
          iVar15 = iVar16;
        }
        *(int *)(&stack0x00000200 + lVar20) = (int)uVar39;
        *(int *)(&stack0x000001fc + lVar20) = iVar15;
        piVar34 = *(int **)(param_3 + 8);
        *(int **)(&stack0x000000e8 + lVar20) = piVar34;
        *(int **)(&stack0x00000dd8 + lVar20) = piVar34;
        uVar4 = *(ushort *)(lVar35 + (0xfff - (longlong)iVar15) * 2);
        *(ushort *)(&stack0x00000648 + lVar20) = uVar4;
        pbVar3 = (byte *)((ulonglong)uVar4 + lVar35);
        *(byte **)(&stack0x00000de0 + lVar20) = pbVar3;
        bVar12 = *pbVar3;
        *(ushort *)(&stack0x0000064c + lVar20) = (ushort)(bVar12 & 1);
        if ((bVar12 & 1) != 0) {
          *(undefined2 *)(&stack0x00001ae8 + lVar20) = 0xffff;
          *(undefined8 *)(&stack0x00001af0 + lVar20) = 0;
          *(undefined4 *)(&stack0x00001aec + lVar20) = 0;
          *(undefined8 *)(&stack0x00001b06 + lVar20) = 0;
          *(undefined8 *)(&stack0x00001b10 + lVar20) = 0;
          *(undefined8 *)(&stack0x00001af8 + lVar20) = 0;
          *(undefined4 *)(&stack0x00001b1c + lVar20) = 0xffffffff;
          *(int *)(&stack0x00001b1c + lVar20) = iVar15;
          if (-1 < *(char *)(lVar35 + 2)) {
            *(undefined8 *)(&stack0x00000718 + lVar20) = 0;
            goto LAB_;
          }
          *(undefined8 *)(&stack0x00000de8 + lVar20) = 0;
          *(undefined8 *)(&stack0x00000718 + lVar20) = 0;
          *(undefined **)(&stack0x00000df0 + lVar20) = &stack0x00001b20 + lVar20;
          *(undefined (*) [16])(&stack0x00001b20 + lVar20) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x00001b30 + lVar20) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x00001b40 + lVar20) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x00001b50 + lVar20) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x00001b60 + lVar20) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x00001b70 + lVar20) = ZEXT816(0);
          *(undefined (*) [16])(&stack0x00001b80 + lVar20) = ZEXT816(0);
          *(undefined8 *)(&stack0x00001b90 + lVar20) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x102366;
          ppbVar24 = (byte **)func_0x(&stack0x00001b20 + lVar20);
          *(byte ***)(&stack0x00000718 + lVar20) = ppbVar24;
          (&stack0x0000004e)[lVar20] = 0;
          if (*(short *)(lVar35 + 0x24) == 0) {
LAB_:
            *(undefined8 *)(&stack0x00001c48 + lVar20) = *(undefined8 *)(lVar35 + 0x28);
            sVar38 = *(short *)(lVar35 + 0x30);
            *(short *)(&stack0x00001c50 + lVar20) = sVar38;
          }
          else {
            cVar11 = *(char *)(lVar35 + 1);
            if ((((cVar11 == '\v') || (cVar11 == '\b')) || (cVar11 == '\t')) &&
               (*(int *)(lVar35 + 0x18) == 99)) {
              *(undefined **)(&stack0x00000df8 + lVar20) = &stack0x00000300 + lVar20;
              *(undefined4 **)(&stack0x00000e00 + lVar20) = (undefined4 *)(lVar35 + 0x20);
              *(undefined4 *)(&stack0x00000300 + lVar20) = *(undefined4 *)(lVar35 + 0x20);
              *(undefined2 *)(&stack0x00000304 + lVar20) = *(undefined2 *)(lVar35 + 0x24);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1023e2;
              cVar11 = func_0x(&stack0x00000300 + lVar20);
              if (cVar11 == '\0') goto LAB_;
              cVar11 = '\x01';
            }
            else {
LAB_:
              cVar11 = '\0';
            }
            (&stack0x0000004e)[lVar20] = cVar11;
            if (cVar11 == '\0') goto LAB_;
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x102407;
            func_0x(lVar35,&stack0x00001c48 + lVar20);
            sVar38 = *(short *)(&stack0x00001c50 + lVar20);
          }
          *(undefined **)(&stack0x00000e08 + lVar20) = &stack0x00001c48 + lVar20;
          *(longlong *)(&stack0x00000e10 + lVar20) = lVar35 + 0x20;
          pbVar3 = (byte *)(lVar35 + 0x60);
          *(byte **)(&stack0x00000e18 + lVar20) = pbVar3;
          *(byte ***)(&stack0x00000e20 + lVar20) = ppbVar24;
          if (pbVar3 == *ppbVar24) {
            *(byte ***)(&stack0x00000e28 + lVar20) = ppbVar24 + 0xc;
            if (((sVar38 == *(short *)(ppbVar24 + 0xd)) &&
                (*(int *)(&stack0x00001c48 + lVar20) == *(int *)(ppbVar24 + 0xc))) &&
               (*(int *)(&stack0x00001c4c + lVar20) == *(int *)((longlong)ppbVar24 + 100))) {
              *(longlong *)(&stack0x00000e30 + lVar20) = (longlong)ppbVar24 + 0x6c;
            }
          }
          *ppbVar24 = pbVar3;
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1024b2;
          func_0x(ppbVar24 + 0xc,&stack0x00001c48 + lVar20);
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1024be;
          func_0x((longlong)ppbVar24 + 0x6c,lVar35 + 0x20);
          uVar39 = (ulonglong)*pbVar3;
          *(ushort *)(&stack0x00000650 + lVar20) = (ushort)*pbVar3;
          *(undefined4 *)(&stack0x000007a2 + lVar20) = *(undefined4 *)(uVar39 * 6 + 0x176c630);
          *(undefined2 *)(&stack0x000007a6 + lVar20) = *(undefined2 *)(uVar39 * 6 + 0x176c634);
          *(undefined4 *)(&stack0x00000618 + lVar20) = *(undefined4 *)(uVar39 * 6 + 0x176c630);
          sVar38 = *(short *)(uVar39 * 6 + 0x176c634);
          uVar39 = (ulonglong)sVar38;
          *(short *)(&stack0x0000061c + lVar20) = sVar38;
          *(longlong *)(&stack0x00000e38 + lVar20) = lVar35 + 99;
          ppbVar1 = ppbVar24 + 2;
          *(byte ***)(&stack0x00000e40 + lVar20) = ppbVar1;
          *(undefined2 *)ppbVar1 = 0xffff;
          ppbVar24[3] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
          *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
          ppbVar24[7] = (byte *)0x0;
          ppbVar24[4] = (byte *)0x0;
          ppbVar2 = ppbVar24 + 9;
          *(byte ***)(&stack0x00000e48 + lVar20) = ppbVar2;
          *ppbVar2 = (byte *)0x0;
          ppbVar24[10] = (byte *)0x0;
          *(undefined2 *)(ppbVar24 + 0xb) = 0;
          if ((**ppbVar24 & 2) != 0) {
            pbVar3 = pbVar3 + uVar39;
            *(byte **)(&stack0x00000e50 + lVar20) = pbVar3;
            *(byte ***)(&stack0x00000e58 + lVar20) = ppbVar1;
            bVar12 = *pbVar3 & 1;
            *(ushort *)(&stack0x00000658 + lVar20) = (ushort)bVar12;
            *(ushort *)ppbVar1 = (ushort)bVar12;
            if (bVar12 != 0) {
              *(longlong *)(&stack0x00000e70 + lVar20) = (longlong)ppbVar24 + 0x12;
              ppbVar24[3] = pbVar3;
              *(byte **)(&stack0x00000e78 + lVar20) = pbVar3;
              UNRECOVERED_JUMPTABLE_00 =
                   (code *)((ulonglong)
                            *(uint *)((ulonglong)
                                      *(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x107e88) * 4 +
                                     0x107e78) - 0xe2c7e0);
                    /* WARNING: Could not emulate address calculation at 0x001026b0 */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
              return;
            }
            *(undefined4 *)(&stack0x000001d8 + lVar20) = 0;
            *(longlong *)(&stack0x00000e60 + lVar20) = (longlong)ppbVar24 + 0x12;
            ppbVar24[3] = pbVar3;
            *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
            *(undefined4 *)((longlong)ppbVar24 + 0x36) = 0;
            pbVar3 = ppbVar24[3];
            *(byte **)(&stack0x00000e68 + lVar20) = pbVar3;
                    /* WARNING: Could not emulate address calculation at 0x001025d2 */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x107e3c) -
                      0xe2c7e0))();
            return;
          }
          if ((**ppbVar24 & 4) != 0) {
            if (*(short *)(&stack0x0000061a + lVar20) != 0) {
              uVar39 = (ulonglong)
                       *(ushort *)
                        (lVar35 + 0x61 + (longlong)*(short *)(&stack0x0000061a + lVar20) * 2);
            }
            *(byte **)(&stack0x00000ea0 + lVar20) = pbVar3 + uVar39;
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x102851;
            func_0x(ppbVar2);
          }
          pbVar3 = ppbVar24[1];
          if (pbVar3 != (byte *)0x0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x102862;
            func_0x(pbVar3,ppbVar24);
          }
          iVar15 = *(int *)(&stack0x00000060 + lVar20);
          lVar35 = *(longlong *)(&stack0x000000e0 + lVar20);
LAB_:
          uVar4 = *(ushort *)(lVar35 + 0xe);
          *(uint *)(&stack0x0000084c + lVar20) = (uint)uVar4;
          uVar5 = *(ushort *)(lVar35 + (0xfff - (longlong)iVar15) * 2);
          *(ushort *)(&stack0x0000065a + lVar20) = uVar5;
          pbVar3 = (byte *)((ulonglong)uVar5 + lVar35);
          *(byte **)(&stack0x00000ea8 + lVar20) = pbVar3;
          bVar12 = *pbVar3 & 1;
          *(ushort *)(&stack0x0000065c + lVar20) = (ushort)bVar12;
          *(ushort *)(&stack0x00001ae8 + lVar20) = (ushort)bVar12;
          if (bVar12 != 0) {
            *(undefined **)(&stack0x00000ec0 + lVar20) = &stack0x00001aea + lVar20;
            *(byte **)(&stack0x00001af0 + lVar20) = pbVar3;
            *(byte **)(&stack0x00000ec8 + lVar20) = pbVar3;
            UNRECOVERED_JUMPTABLE_00 =
                 (code *)((ulonglong)
                          *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x107ef4)
                                    * 4 + 0x107ee4) - 0xe2c7e0);
                    /* WARNING: Could not emulate address calculation at 0x001029da */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbVar3,0xffffffffff1d3820,pbVar3);
            return;
          }
          *(uint *)(&stack0x000001e0 + lVar20) = (uint)uVar4;
          *(undefined **)(&stack0x00000eb0 + lVar20) = &stack0x00001aea + lVar20;
          *(byte **)(&stack0x00001af0 + lVar20) = pbVar3;
          *(undefined4 *)(&stack0x00001aec + lVar20) = 0;
          *(undefined4 *)(&stack0x00001b0e + lVar20) = 0;
          *(byte **)(&stack0x00000eb8 + lVar20) = pbVar3;
                    /* WARNING: Could not emulate address calculation at 0x00102911 */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x107ea8) - 0xe2c7e0)
          )();
          return;
        }
        iVar16 = *piVar34;
        *(int *)(&stack0x00000848 + lVar20) = iVar16;
        puVar30 = (undefined4 *)(pbVar3 + iVar16);
        *(undefined4 **)(&stack0x00000730 + lVar20) = puVar30;
        *(undefined4 *)(&stack0x00000320 + lVar20) = *puVar30;
        sVar38 = *(short *)(puVar30 + 1);
        *(short *)(&stack0x00000324 + lVar20) = sVar38;
        param_3 = *(short **)(&stack0x00000278 + lVar20);
        if (sVar38 != *param_3) {
          while ((int)uVar39 < iVar15) {
            uVar17 = ((int)uVar39 + 1 + iVar15) / 2;
            *(uint *)(&stack0x000001f8 + lVar20) = uVar17;
            piVar34 = *(int **)(param_3 + 8);
            *(int **)(&stack0x000000e8 + lVar20) = piVar34;
            *(int **)(&stack0x00001000 + lVar20) = piVar34;
            uVar4 = *(ushort *)(lVar35 + (0xfff - (longlong)(int)uVar17) * 2);
            *(ushort *)(&stack0x00000680 + lVar20) = uVar4;
            pbVar3 = (byte *)((ulonglong)uVar4 + lVar35);
            *(byte **)(&stack0x00001008 + lVar20) = pbVar3;
            bVar12 = *pbVar3;
            *(ushort *)(&stack0x00000684 + lVar20) = (ushort)(bVar12 & 1);
            if ((bVar12 & 1) != 0) {
              *(undefined2 *)(&stack0x00001b98 + lVar20) = 0xffff;
              *(undefined8 *)(&stack0x00001ba0 + lVar20) = 0;
              *(undefined4 *)(&stack0x00001b9c + lVar20) = 0;
              *(undefined8 *)(&stack0x00001bb6 + lVar20) = 0;
              *(undefined8 *)(&stack0x00001bc0 + lVar20) = 0;
              *(undefined8 *)(&stack0x00001ba8 + lVar20) = 0;
              *(undefined4 *)(&stack0x00001bcc + lVar20) = 0xffffffff;
              *(uint *)(&stack0x00001bcc + lVar20) = uVar17;
              if (-1 < *(char *)(lVar35 + 2)) {
                *(undefined8 *)(&stack0x00000738 + lVar20) = 0;
                goto LAB_;
              }
              pbVar3 = (byte *)(lVar35 + 0x60);
              *(undefined8 *)(&stack0x00001010 + lVar20) = 0;
              *(undefined8 *)(&stack0x00000738 + lVar20) = 0;
              *(undefined **)(&stack0x00001018 + lVar20) = &stack0x00001bd0 + lVar20;
              *(undefined (*) [16])(&stack0x00001bd0 + lVar20) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001be0 + lVar20) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001bf0 + lVar20) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001c00 + lVar20) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001c10 + lVar20) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001c20 + lVar20) = ZEXT816(0);
              *(undefined (*) [16])(&stack0x00001c30 + lVar20) = ZEXT816(0);
              *(undefined8 *)(&stack0x00001c40 + lVar20) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x103b7b;
              ppbVar24 = (byte **)func_0x(&stack0x00001bd0 + lVar20);
              *(byte ***)(&stack0x00000738 + lVar20) = ppbVar24;
              (&stack0x0000004f)[lVar20] = 0;
              if (*(short *)(lVar35 + 0x24) == 0) {
LAB_:
                *(undefined8 *)(&stack0x00001c58 + lVar20) = *(undefined8 *)(lVar35 + 0x28);
                sVar38 = *(short *)(lVar35 + 0x30);
                *(short *)(&stack0x00001c60 + lVar20) = sVar38;
              }
              else {
                cVar11 = *(char *)(lVar35 + 1);
                if ((((cVar11 == '\v') || (cVar11 == '\b')) || (cVar11 == '\t')) &&
                   (*(int *)(lVar35 + 0x18) == 99)) {
                  *(undefined **)(&stack0x00001020 + lVar20) = &stack0x00000308 + lVar20;
                  *(undefined4 **)(&stack0x00001028 + lVar20) = (undefined4 *)(lVar35 + 0x20);
                  *(undefined4 *)(&stack0x00000308 + lVar20) = *(undefined4 *)(lVar35 + 0x20);
                  *(undefined2 *)(&stack0x0000030c + lVar20) = *(undefined2 *)(lVar35 + 0x24);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x103bf7;
                  cVar11 = func_0x(&stack0x00000308 + lVar20);
                  if (cVar11 == '\0') goto LAB_;
                  cVar11 = '\x01';
                }
                else {
LAB_:
                  cVar11 = '\0';
                }
                (&stack0x0000004f)[lVar20] = cVar11;
                if (cVar11 == '\0') goto LAB_;
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x103c1c;
                func_0x(lVar35,&stack0x00001c58 + lVar20);
                sVar38 = *(short *)(&stack0x00001c60 + lVar20);
              }
              *(undefined **)(&stack0x00001030 + lVar20) = &stack0x00001c58 + lVar20;
              *(longlong *)(&stack0x00001038 + lVar20) = lVar35 + 0x20;
              *(byte **)(&stack0x00001040 + lVar20) = pbVar3;
              *(byte ***)(&stack0x00001048 + lVar20) = ppbVar24;
              if (pbVar3 == *ppbVar24) {
                *(byte ***)(&stack0x00001050 + lVar20) = ppbVar24 + 0xc;
                if (((sVar38 == *(short *)(ppbVar24 + 0xd)) &&
                    (*(int *)(&stack0x00001c58 + lVar20) == *(int *)(ppbVar24 + 0xc))) &&
                   (*(int *)(&stack0x00001c5c + lVar20) == *(int *)((longlong)ppbVar24 + 100))) {
                  *(longlong *)(&stack0x00001058 + lVar20) = (longlong)ppbVar24 + 0x6c;
                }
              }
              *ppbVar24 = pbVar3;
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x103cc2;
              func_0x(ppbVar24 + 0xc,&stack0x00001c58 + lVar20);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x103cce;
              func_0x((longlong)ppbVar24 + 0x6c,lVar35 + 0x20);
              uVar39 = (ulonglong)*pbVar3;
              *(ushort *)(&stack0x00000688 + lVar20) = (ushort)*pbVar3;
              *(undefined4 *)(&stack0x0000079c + lVar20) = *(undefined4 *)(uVar39 * 6 + 0x176c630);
              *(undefined2 *)(&stack0x000007a0 + lVar20) = *(undefined2 *)(uVar39 * 6 + 0x176c634);
              *(undefined4 *)(&stack0x00000620 + lVar20) = *(undefined4 *)(uVar39 * 6 + 0x176c630);
              sVar38 = *(short *)(uVar39 * 6 + 0x176c634);
              uVar39 = (ulonglong)sVar38;
              *(short *)(&stack0x00000624 + lVar20) = sVar38;
              *(longlong *)(&stack0x00001060 + lVar20) = lVar35 + 99;
              ppbVar1 = ppbVar24 + 2;
              *(byte ***)(&stack0x00001068 + lVar20) = ppbVar1;
              *(undefined2 *)ppbVar1 = 0xffff;
              ppbVar24[3] = (byte *)0x0;
              *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
              *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
              ppbVar24[7] = (byte *)0x0;
              ppbVar24[4] = (byte *)0x0;
              ppbVar2 = ppbVar24 + 9;
              *(byte ***)(&stack0x00001070 + lVar20) = ppbVar2;
              *ppbVar2 = (byte *)0x0;
              ppbVar24[10] = (byte *)0x0;
              *(undefined2 *)(ppbVar24 + 0xb) = 0;
              if ((**ppbVar24 & 2) != 0) {
                pbVar3 = pbVar3 + uVar39;
                *(byte **)(&stack0x00001078 + lVar20) = pbVar3;
                *(byte ***)(&stack0x00001080 + lVar20) = ppbVar1;
                bVar12 = *pbVar3 & 1;
                *(ushort *)(&stack0x000006a0 + lVar20) = (ushort)bVar12;
                *(ushort *)ppbVar1 = (ushort)bVar12;
                if (bVar12 != 0) {
                  *(longlong *)(&stack0x00001098 + lVar20) = (longlong)ppbVar24 + 0x12;
                  ppbVar24[3] = pbVar3;
                  *(byte **)(&stack0x000010a0 + lVar20) = pbVar3;
                  UNRECOVERED_JUMPTABLE_00 =
                       (code *)((ulonglong)
                                *(uint *)((ulonglong)
                                          *(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x107f60) * 4
                                         + 0x107f50) - 0xe2c7e0);
                    /* WARNING: Could not emulate address calculation at 0x00103eb4 */
                    /* WARNING: Treating indirect jump as call */
                  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
                  return;
                }
                *(undefined4 *)(&stack0x000001e8 + lVar20) = 0;
                *(longlong *)(&stack0x00001088 + lVar20) = (longlong)ppbVar24 + 0x12;
                ppbVar24[3] = pbVar3;
                *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                *(undefined4 *)((longlong)ppbVar24 + 0x36) = 0;
                pbVar3 = ppbVar24[3];
                *(byte **)(&stack0x00001090 + lVar20) = pbVar3;
                    /* WARNING: Could not emulate address calculation at 0x00103dec */
                    /* WARNING: Treating indirect jump as call */
                (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x107f14) -
                          0xe2c7e0))();
                return;
              }
              if ((**ppbVar24 & 4) != 0) {
                if (*(short *)(&stack0x00000622 + lVar20) != 0) {
                  uVar39 = (ulonglong)
                           *(ushort *)
                            (lVar35 + 0x61 + (longlong)*(short *)(&stack0x00000622 + lVar20) * 2);
                }
                *(byte **)(&stack0x000010c8 + lVar20) = pbVar3 + uVar39;
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x104053;
                func_0x(ppbVar2);
              }
              pbVar3 = ppbVar24[1];
              if (pbVar3 != (byte *)0x0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x104067;
                func_0x(pbVar3,ppbVar24);
              }
              lVar35 = *(longlong *)(&stack0x000000e0 + lVar20);
LAB_:
              uVar4 = *(ushort *)(lVar35 + 0xe);
              *(uint *)(&stack0x000008ac + lVar20) = (uint)uVar4;
              uVar5 = *(ushort *)
                       (lVar35 + (0xfff - (longlong)*(int *)(&stack0x000001f8 + lVar20)) * 2);
              *(ushort *)(&stack0x000006a2 + lVar20) = uVar5;
              pbVar3 = (byte *)((ulonglong)uVar5 + lVar35);
              *(byte **)(&stack0x000010d0 + lVar20) = pbVar3;
              bVar12 = *pbVar3 & 1;
              *(ushort *)(&stack0x000006a4 + lVar20) = (ushort)bVar12;
              *(ushort *)(&stack0x00001b98 + lVar20) = (ushort)bVar12;
              if (bVar12 != 0) {
                *(undefined **)(&stack0x000010e8 + lVar20) = &stack0x00001b9a + lVar20;
                *(byte **)(&stack0x00001ba0 + lVar20) = pbVar3;
                *(byte **)(&stack0x000010f0 + lVar20) = pbVar3;
                UNRECOVERED_JUMPTABLE_00 =
                     (code *)((ulonglong)
                              *(uint *)((ulonglong)
                                        *(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x107fcc) * 4 +
                                       0x107fbc) - 0xe2c7e0);
                    /* WARNING: Could not emulate address calculation at 0x001041ec */
                    /* WARNING: Treating indirect jump as call */
                (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
                return;
              }
              *(uint *)(&stack0x000001f0 + lVar20) = (uint)uVar4;
              *(undefined **)(&stack0x000010d8 + lVar20) = &stack0x00001b9a + lVar20;
              *(byte **)(&stack0x00001ba0 + lVar20) = pbVar3;
              *(undefined4 *)(&stack0x00001b9c + lVar20) = 0;
              *(undefined4 *)(&stack0x00001bbe + lVar20) = 0;
              *(byte **)(&stack0x000010e0 + lVar20) = pbVar3;
                    /* WARNING: Could not emulate address calculation at 0x00104120 */
                    /* WARNING: Treating indirect jump as call */
              (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x107f80) -
                        0xe2c7e0))();
              return;
            }
            iVar16 = *piVar34;
            *(int *)(&stack0x000008a8 + lVar20) = iVar16;
            puVar30 = (undefined4 *)(pbVar3 + iVar16);
            *(undefined4 **)(&stack0x00000750 + lVar20) = puVar30;
            *(undefined4 *)(&stack0x00000320 + lVar20) = *puVar30;
            sVar38 = *(short *)(puVar30 + 1);
            *(short *)(&stack0x00000324 + lVar20) = sVar38;
            param_3 = *(short **)(&stack0x00000278 + lVar20);
            if (sVar38 == *param_3) {
              *(uint *)(&stack0x000000d8 + lVar20) = uVar17;
              *(uint *)(&stack0x00000200 + lVar20) = uVar17;
            }
            else {
              iVar15 = uVar17 - 1;
              *(int *)(&stack0x00000060 + lVar20) = iVar15;
              *(int *)(&stack0x000001fc + lVar20) = iVar15;
              uVar17 = *(uint *)(&stack0x000000d8 + lVar20);
            }
            uVar39 = (ulonglong)uVar17;
          }
          param_1 = *(longlong *)(&stack0x000000f0 + lVar20);
          pplVar37 = *(longlong ***)(&stack0x000000f8 + lVar20);
        }
        *(int *)(&stack0x00000908 + lVar20) = iVar15;
        *(int *)(param_1 + 0x80) = iVar15 + 1;
        piVar34 = *(int **)(&stack0x00000340 + lVar20);
        *piVar34 = *piVar34 + (iVar15 - *(int *)(&stack0x00000454 + lVar20)) + 1;
        if (*(int *)(param_1 + 0x80) < *(int *)(&stack0x00000458 + lVar20)) goto LAB_;
        *(int *)(&stack0x00000204 + lVar20) =
             *(int *)(&stack0x00000204 + lVar20) - *(int *)(&stack0x00000458 + lVar20);
        *(int **)(&stack0x00001228 + lVar20) = (int *)(lVar35 + 0x10);
        iVar15 = *(int *)(lVar35 + 0x10);
        *(int *)(&stack0x00000060 + lVar20) = iVar15;
        sVar38 = *(short *)(lVar35 + 0x14);
        *(short *)(&stack0x00000064 + lVar20) = sVar38;
        *(int *)(&stack0x00000058 + lVar20) = iVar15;
        *(short *)(&stack0x0000005c + lVar20) = sVar38;
        uVar39 = 0;
        *(undefined4 *)(&stack0x000007b0 + lVar20) = 0;
        *(undefined2 *)(&stack0x000007b4 + lVar20) = 0;
        if ((iVar15 != 0) || (sVar38 != 0)) {
          *(undefined **)(&stack0x00001278 + lVar20) = &stack0x00000628 + lVar20;
          *(int *)(&stack0x00000628 + lVar20) = iVar15;
          *(short *)(&stack0x0000062c + lVar20) = sVar38;
          *(longlong ***)(&stack0x00000768 + lVar20) = pplVar37;
          plVar31 = *(longlong **)(param_1 + 8);
          *(longlong **)(&stack0x00000780 + lVar20) = plVar31;
          *(undefined8 *)(&stack0x000005a0 + lVar20) = *(undefined8 *)(param_1 + 0x10);
          *(undefined4 *)(&stack0x00000348 + lVar20) = 0;
          *(undefined4 *)(&stack0x0000034c + lVar20) = 0;
          *(undefined2 *)(&stack0x00000350 + lVar20) = 0;
          lVar35 = *plVar31;
          *(longlong *)(&stack0x00000778 + lVar20) = lVar35;
          *(undefined4 *)(&stack0x00000b04 + lVar20) = 0;
          *(undefined4 *)(&stack0x00000b08 + lVar20) = 0;
          lVar36 = *(longlong *)(lVar35 + 0x20);
          *(longlong *)(&stack0x000000d0 + lVar20) = lVar36;
          *(uint6 **)(&stack0x00001280 + lVar20) = (uint6 *)(lVar35 + 0x14);
          lVar29 = (ulonglong)*(uint6 *)(lVar35 + 0x14) * 0x10000;
          *(longlong *)(&stack0x00001288 + lVar20) = lVar29;
          lVar35 = *(longlong *)(lVar36 + 2000);
          if ((lVar35 == lVar29) && (lVar35 - 1U < 0xfffffffffffffffe)) {
            (&stack0x00000050)[lVar20] = 1;
            lVar35 = *(longlong *)(&stack0x000000e0 + lVar20);
          }
          else {
            (&stack0x00000050)[lVar20] = 0;
            if ((*(longlong *)(*(longlong *)(&stack0x000000d0 + lVar20) + 0x7d8) == lVar29) &&
               (*(longlong *)(*(longlong *)(&stack0x000000d0 + lVar20) + 0x7d8) - 1U <
                0xfffffffffffffffe)) {
              (&stack0x00000051)[lVar20] = 1;
              lVar35 = *(longlong *)(&stack0x000000e0 + lVar20);
            }
            else {
              (&stack0x00000051)[lVar20] = 0;
              lVar35 = *(longlong *)(unaff_GS_OFFSET + 0x58);
              *(longlong *)(&stack0x00001290 + lVar20) = lVar35;
              lVar36 = (ulonglong)*_DAT_ +
                       *(longlong *)(lVar35 + (ulonglong)*_DAT_ * 8);
              *(longlong *)(&stack0x00001298 + lVar20) = lVar36;
              lVar35 = *(longlong *)(lVar36 + 0x100);
              *(longlong *)(&stack0x00000a38 + lVar20) = lVar35;
              puVar28 = _DAT_;
              if (lVar35 == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105767;
                puVar28 = (uint *)(*_DAT_)(0);
                lVar35 = *(longlong *)(lVar36 + 0x100);
                *(longlong *)(&stack0x00000a38 + lVar20) = lVar35;
              }
              *(longlong *)(&stack0x000012a0 + lVar20) = lVar35;
              uVar26 = rdtsc();
              uVar25 = CONCAT44((int)((ulonglong)puVar28 >> 0x20),(int)uVar26) |
                       uVar26 & 0xffffffff00000000;
              *(ulonglong *)(&stack0x000012a8 + lVar20) = uVar25;
              uVar26 = *(ulonglong *)(lVar35 + 0x340);
              if ((uVar26 < uVar25) ||
                 ((uVar26 != 0x7fffffffffffffff &&
                  (*(ulonglong *)(*(longlong *)(lVar35 + 0x260) + 0xdf0) < uVar26 - uVar25)))) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105836;
                iVar15 = func_0x(0,0x20ae8c8);
                *(int *)(&stack0x00000268 + lVar20) = iVar15;
                if (iVar15 == 2) {
LAB_:
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105849;
                  func_0x(0x7c);
                }
              }
              else {
                lVar35 = *(longlong *)(lVar35 + 600);
                *(longlong *)(&stack0x00000a40 + lVar20) = lVar35;
                puVar28 = (uint *)(lVar35 + 0xbc);
                *(uint **)(&stack0x000012b0 + lVar20) = puVar28;
                if ((*puVar28 & 4) != 0) {
                  lVar35 = *(longlong *)(*(longlong *)(&stack0x00000a40 + lVar20) + 0x98);
                  *(longlong *)(&stack0x000012b8 + lVar20) = lVar35;
                  if (((*(byte *)(lVar35 + 0x268) & 1) == 0) &&
                     ((*(uint *)(lVar35 + 800) & 0x180) == 0)) {
                    *(undefined4 *)(&stack0x00000268 + lVar20) = 2;
                    goto LAB_;
                  }
                }
                *(undefined4 *)(&stack0x00000268 + lVar20) = 0;
              }
              lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
            }
          }
          *(undefined4 *)(&stack0x000007b8 + lVar20) = 0;
          *(undefined4 *)(&stack0x000007bc + lVar20) = 0;
          *(undefined2 *)(&stack0x000007c0 + lVar20) = 0;
          if (*(longlong *)(&stack0x00000768 + lVar20) == 0) {
            (&stack0x00000028)[lVar20] = 0;
          }
          else {
            (&stack0x00000028)[lVar20] = 1;
            uVar13 = 0xff;
            if (*(char *)(*(longlong *)(&stack0x000000d0 + lVar20) + 0x2050) != '\0')
            goto LAB_;
          }
          uVar13 = 2;
LAB_:
          (&stack0x00000029)[lVar20] = uVar13;
          do {
            *(undefined **)(&stack0x00000758 + lVar20) = &stack0x00000b00 + lVar20;
            *(undefined4 *)(&stack0x00001a0c + lVar20) = 0;
            *(undefined4 *)(&stack0x00001a10 + lVar20) = 0;
            cVar11 = *_DAT_;
            (&stack0x000001be)[lVar20] = cVar11;
            uVar26 = uVar39;
            if ((cVar11 != '\0') &&
               ((&stack0x000001bf)[lVar20] = DAT_ >> 7, -1 < (char)DAT_)) {
              *(undefined4 *)(&stack0x00000478 + lVar20) = 0;
              lVar35 = *(longlong *)(unaff_GS_OFFSET + 0x58);
              *(longlong *)(&stack0x000012c0 + lVar20) = lVar35;
              plVar31 = (longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)(lVar35 + (ulonglong)*_DAT_ * 8));
              *(longlong **)(&stack0x000012c8 + lVar20) = plVar31;
              lVar35 = *plVar31;
              *(longlong *)(&stack0x000012d0 + lVar20) = lVar35;
              if (lVar35 == 0) {
LAB_:
                *(undefined8 *)(&stack0x00000a48 + lVar20) = 0;
              }
              else {
                lVar35 = **(longlong **)(lVar35 + 0x38);
                *(longlong *)(&stack0x000012d8 + lVar20) = lVar35;
                if (lVar35 == 0) goto LAB_;
                *(longlong *)(&stack0x00000a48 + lVar20) = lVar35;
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105968;
                iVar15 = (*_DAT_)(lVar35,0x337);
                *(int *)(&stack0x00000478 + lVar20) = iVar15;
                if (iVar15 != 0) {
                  lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
                  goto LAB_;
                }
              }
              lVar35 = *(longlong *)(unaff_GS_OFFSET + 0x58);
              *(longlong *)(&stack0x000012e0 + lVar20) = lVar35;
              lVar35 = (ulonglong)*_DAT_ +
                       *(longlong *)(lVar35 + (ulonglong)*_DAT_ * 8);
              *(longlong *)(&stack0x000012e8 + lVar20) = lVar35;
              lVar36 = *(longlong *)(lVar35 + 8);
              *(longlong *)(&stack0x000012f0 + lVar20) = lVar36;
              lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
              if (lVar36 != 0) {
                uVar26 = *(ulonglong *)(lVar36 + 0x60);
              }
            }
LAB_:
            *(ulonglong *)(&stack0x000002a8 + lVar20) = uVar26;
            lVar36 = *(longlong *)(&stack0x000000d0 + lVar20);
            *(undefined8 *)(&stack0x00000a50 + lVar20) = *(undefined8 *)(lVar36 + 0x728);
LAB_:
            *(undefined4 *)(&stack0x000002a0 + lVar20) = 0;
            if (*(longlong *)((longlong)&plStackX_10 + lVar20) != 0) {
              puVar23 = (undefined2 *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x62);
              *(undefined2 **)(&stack0x000012f8 + lVar20) = puVar23;
              *(undefined2 *)(&stack0x00000138 + lVar20) = *puVar23;
              if (((*(ushort *)(&stack0x00000138 + lVar20) & 0x400) == 0) ||
                 (*(short *)((longlong)&uStackX_1c + lVar20) < 3)) {
                *(int *)(&stack0x00000070 + lVar20) =
                     (int)*(short *)((longlong)&uStackX_1c + lVar20);
                *(undefined8 *)(&stack0x00000580 + lVar20) =
                     *(undefined8 *)((longlong)&plStackX_10 + lVar20);
                *(undefined2 **)(&stack0x00001300 + lVar20) = puVar23;
                uVar14 = *puVar23;
                *(undefined2 *)(&stack0x00000140 + lVar20) = uVar14;
                if (((byte)uVar14 >> 3 & 1) != 0) {
                  if (*(int *)(&stack0x00000070 + lVar20) == 3) {
                    *(undefined4 *)(&stack0x00000070 + lVar20) = 4;
                  }
                  else if (*(int *)(&stack0x00000070 + lVar20) < 2) goto LAB_;
                  puVar28 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 100);
                  *(uint **)(&stack0x00001308 + lVar20) = puVar28;
                  uVar17 = *puVar28;
                  *(uint *)(&stack0x00000480 + lVar20) = uVar17;
                  if ((((uVar17 & 8) != 0) &&
                      (lVar35 = *(longlong *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x90)
                      , lVar35 != 0)) &&
                     (*(longlong *)(&stack0x00001310 + lVar20) = lVar35,
                     *(longlong *)(lVar35 + 0x758) != 0)) {
                    uVar27 = *(undefined8 *)(lVar35 + 0x758);
                    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105afc;
                    func_0x
                              (uVar27,*(undefined8 *)((longlong)&plStackX_10 + lVar20),
                               *(undefined4 *)(&stack0x00000070 + lVar20));
                  }
                }
LAB_:
                (&stack0x000001c0)[lVar20] = DAT_ >> 7;
                if ((char)DAT_ < '\0') {
                  puVar28 = (uint *)(*(longlong *)(&stack0x00000580 + lVar20) + 100);
                  *(uint **)(&stack0x00001318 + lVar20) = puVar28;
                  uVar17 = *puVar28;
                  *(uint *)(&stack0x00000488 + lVar20) = uVar17;
                  if (((uVar17 & 8) != 0) && (2 < *(int *)(&stack0x00000070 + lVar20))) {
                    *(uint **)(&stack0x00001320 + lVar20) = puVar28;
                    uVar17 = *puVar28;
                    *(uint *)(&stack0x00000490 + lVar20) = uVar17;
                    if (((uVar17 & 0xc0000000) != 0x40000000) &&
                       (lVar35 = **(longlong **)(&stack0x00000580 + lVar20), lVar35 != 0)) {
                      *(undefined4 *)(&stack0x00000920 + lVar20) = 2;
                      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105b8b;
                      iVar15 = (*_DAT_)(lVar35,0x2000,2,&stack0x00000924 + lVar20);
                      if (iVar15 != 0) {
                        LOCK();
                        *puVar28 = *puVar28 & 0x3fffffff;
                        UNLOCK();
                        LOCK();
                        *puVar28 = *puVar28 | 0x40000000;
                        UNLOCK();
                      }
                    }
                  }
                }
                lVar35 = *(longlong *)(&stack0x00000580 + lVar20);
                uVar19 = *(undefined4 *)(&stack0x00000070 + lVar20);
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105bba;
                func_0x(lVar35 + 0x98,uVar19);
                if ((_DAT_ != 0) &&
                   ((&stack0x000001c1)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105be4;
                  func_0x(lVar35,0,uVar19);
                }
                *(uint *)((longlong)&uStackX_1c + lVar20) =
                     *(uint *)((longlong)&uStackX_1c + lVar20) & 0xffff0000;
                *(undefined8 *)((longlong)&plStackX_10 + lVar20) = 0;
              }
              else {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1059f1;
                func_0x((longlong)&plStackX_10 + lVar20);
              }
              lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
            }
            if (*(longlong *)(lVar36 + 0x728) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105c22;
              func_0x((longlong)&plStackX_10 + lVar20,&stack0x00000058 + lVar20,
                              *(undefined8 *)(&stack0x000000d0 + lVar20));
              if (*(longlong *)((longlong)&plStackX_10 + lVar20) != 0) {
                puVar23 = (undefined2 *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x62);
                *(undefined2 **)(&stack0x00001328 + lVar20) = puVar23;
                *(undefined2 *)(&stack0x00000148 + lVar20) = *puVar23;
                if (((*(ushort *)(&stack0x00000148 + lVar20) & 0x400) == 0) ||
                   (*(short *)((longlong)&uStackX_1c + lVar20) < 3)) {
                  *(int *)(&stack0x000000b8 + lVar20) =
                       (int)*(short *)((longlong)&uStackX_1c + lVar20);
                  *(undefined8 *)(&stack0x00000588 + lVar20) =
                       *(undefined8 *)((longlong)&plStackX_10 + lVar20);
                  *(undefined2 **)(&stack0x00001330 + lVar20) = puVar23;
                  uVar14 = *puVar23;
                  *(undefined2 *)(&stack0x00000150 + lVar20) = uVar14;
                  if (((byte)uVar14 >> 3 & 1) != 0) {
                    if (*(int *)(&stack0x000000b8 + lVar20) == 3) {
                      *(undefined4 *)(&stack0x000000b8 + lVar20) = 4;
                    }
                    else if (*(int *)(&stack0x000000b8 + lVar20) < 2) goto LAB_;
                    puVar28 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 100);
                    *(uint **)(&stack0x00001338 + lVar20) = puVar28;
                    uVar17 = *puVar28;
                    *(uint *)(&stack0x00000498 + lVar20) = uVar17;
                    if ((((uVar17 & 8) != 0) &&
                        (lVar35 = *(longlong *)
                                   (*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x90),
                        lVar35 != 0)) &&
                       (*(longlong *)(&stack0x00001340 + lVar20) = lVar35,
                       *(longlong *)(lVar35 + 0x758) != 0)) {
                      uVar27 = *(undefined8 *)(lVar35 + 0x758);
                      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105d17;
                      func_0x
                                (uVar27,*(undefined8 *)((longlong)&plStackX_10 + lVar20),
                                 *(undefined4 *)(&stack0x000000b8 + lVar20));
                    }
                  }
LAB_:
                  (&stack0x000001c2)[lVar20] = DAT_ >> 7;
                  if ((char)DAT_ < '\0') {
                    puVar28 = (uint *)(*(longlong *)(&stack0x00000588 + lVar20) + 100);
                    *(uint **)(&stack0x00001348 + lVar20) = puVar28;
                    uVar17 = *puVar28;
                    *(uint *)(&stack0x000004a0 + lVar20) = uVar17;
                    if (((uVar17 & 8) != 0) && (2 < *(int *)(&stack0x000000b8 + lVar20))) {
                      *(uint **)(&stack0x00001350 + lVar20) = puVar28;
                      uVar17 = *puVar28;
                      *(uint *)(&stack0x000004a8 + lVar20) = uVar17;
                      if (((uVar17 & 0xc0000000) != 0x40000000) &&
                         (lVar35 = **(longlong **)(&stack0x00000588 + lVar20), lVar35 != 0)) {
                        *(undefined4 *)(&stack0x00000928 + lVar20) = 2;
                        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105da6;
                        iVar15 = (*_DAT_)(lVar35,0x2000,2,&stack0x0000092c + lVar20);
                        if (iVar15 != 0) {
                          LOCK();
                          *puVar28 = *puVar28 & 0x3fffffff;
                          UNLOCK();
                          LOCK();
                          *puVar28 = *puVar28 | 0x40000000;
                          UNLOCK();
                        }
                      }
                    }
                  }
                  lVar35 = *(longlong *)(&stack0x00000588 + lVar20);
                  uVar19 = *(undefined4 *)(&stack0x000000b8 + lVar20);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105dd5;
                  func_0x(lVar35 + 0x98,uVar19);
                  if ((_DAT_ != 0) &&
                     ((&stack0x000001c3)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0))
                  {
                    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105dff;
                    func_0x(lVar35,0,uVar19);
                  }
                  *(uint *)((longlong)&uStackX_1c + lVar20) =
                       *(uint *)((longlong)&uStackX_1c + lVar20) & 0xffff0000;
                  *(undefined8 *)((longlong)&plStackX_10 + lVar20) = 0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105c66;
                  func_0x((longlong)&plStackX_10 + lVar20);
                }
                lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
              }
            }
            *(undefined8 *)(&stack0xfffffffffffffff0 + lVar20) =
                 *(undefined8 *)(&stack0x00000758 + lVar20);
            *(undefined4 *)(&stack0xffffffffffffffe8 + lVar20) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105e47;
            plVar31 = (longlong *)
                      func_0x
                                (_DAT_,*(undefined8 *)(&stack0x000000d0 + lVar20),
                                 &stack0x00000058 + lVar20,&stack0x000002a0 + lVar20);
            *(longlong **)((longlong)&plStackX_10 + lVar20) = plVar31;
            uVar17 = *(uint *)((longlong)&uStackX_1c + lVar20) & 0xffff0002 | 2;
            *(uint *)((longlong)&uStackX_1c + lVar20) = uVar17;
            if (*(longlong *)(&stack0x000002a8 + lVar20) != 0) {
              lVar29 = *plVar31;
              *(longlong *)(&stack0x00001358 + lVar20) = lVar29;
              plVar32 = (longlong *)(*(longlong *)(&stack0x000002a8 + lVar20) + 0x500);
              *(longlong **)(&stack0x00001360 + lVar20) = plVar32;
              plVar31 = plVar32 + (ulonglong)(*(uint *)plVar32 & 0xf) + 1;
              *(longlong **)(&stack0x00001368 + lVar20) = plVar31;
              if (*plVar31 != lVar29) {
                *plVar31 = lVar29;
                *plVar32 = *plVar32 + 1;
                uVar17 = *(uint *)((longlong)&uStackX_1c + lVar20);
              }
            }
            uVar18 = *(uint *)(&stack0x000002a0 + lVar20) >> 3 & 1;
            *(uint *)((longlong)&uStackX_1c + lVar20) = uVar18 << 0x18 | uVar17 & 0xffffff;
            *(uint *)((longlong)auStackX_20 + lVar20) =
                 *(uint *)(&stack0x000002a0 + lVar20) >> 4 & 1 |
                 *(uint *)((longlong)auStackX_20 + lVar20) & 0xffffff00;
            lVar29 = *(longlong *)(&stack0x00000a50 + lVar20);
            if (((lVar29 != 0) && (*(longlong *)(&stack0x000002a8 + lVar20) != 0)) &&
               (*(longlong *)(&stack0x000002a8 + lVar20) ==
                *(longlong *)(*(longlong *)(&stack0x000000d0 + lVar20) + 0x1c38))) {
              *(uint *)(&stack0x00000930 + lVar20) = uVar18;
              *(longlong *)(&stack0x00001370 + lVar20) = lVar29 + 0x59b8;
              *(longlong *)(lVar29 + 0x5b28) = *(longlong *)(lVar29 + 0x5b28) + 1;
              puVar28 = *(uint **)(&stack0x00000758 + lVar20);
              if (puVar28[1] != 0) {
                *(longlong *)(lVar29 + 0x5b30) = *(longlong *)(lVar29 + 0x5b30) + 1;
                *(longlong *)(lVar29 + 0x5b38) =
                     *(longlong *)(lVar29 + 0x5b38) + (ulonglong)*puVar28;
                if (uVar18 != 0) {
                  *(longlong *)(lVar29 + 0x5b40) = *(longlong *)(lVar29 + 0x5b40) + 1;
                  *(longlong *)(lVar29 + 0x5b48) =
                       *(longlong *)(lVar29 + 0x5b48) + (ulonglong)*puVar28;
                }
              }
            }
            lVar29 = *(longlong *)(&stack0x000000d0 + lVar20);
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105f6c;
            cVar11 = func_0x(lVar29);
            if ((cVar11 == '\0') || (*(char *)(lVar29 + 0x2050) == '\0')) goto LAB_;
            if (*(int *)(&stack0x00000058 + lVar20) == 0) {
LAB_:
              (&stack0x00000055)[lVar20] = 1;
              goto LAB_;
            }
            *(undefined4 *)(&stack0x00000796 + lVar20) = 9;
            *(undefined2 *)(&stack0x0000079a + lVar20) = 1;
            if ((*(int *)(&stack0x00000058 + lVar20) == 9) &&
               (*(short *)(&stack0x0000005c + lVar20) == 1)) goto LAB_;
            (&stack0x00000055)[lVar20] = 0;
            lVar35 = **(longlong **)((longlong)&plStackX_10 + lVar20);
            *(longlong *)(&stack0x00001378 + lVar20) = lVar35;
            (&stack0x00000052)[lVar20] = 0;
            if (*(short *)(lVar35 + 0x24) == 0) {
LAB_:
              *(undefined8 *)(&stack0x000002c0 + lVar20) = *(undefined8 *)(lVar35 + 0x28);
              *(undefined2 *)(&stack0x000002c8 + lVar20) = *(undefined2 *)(lVar35 + 0x30);
            }
            else {
              cVar11 = *(char *)(lVar35 + 1);
              if ((((cVar11 == '\v') || (cVar11 == '\b')) || (cVar11 == '\t')) &&
                 (*(int *)(lVar35 + 0x18) == 99)) {
                *(undefined **)(&stack0x00001380 + lVar20) = &stack0x00000310 + lVar20;
                *(undefined4 **)(&stack0x00001388 + lVar20) = (undefined4 *)(lVar35 + 0x20);
                *(undefined4 *)(&stack0x00000310 + lVar20) = *(undefined4 *)(lVar35 + 0x20);
                *(undefined2 *)(&stack0x00000314 + lVar20) = *(undefined2 *)(lVar35 + 0x24);
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106039;
                cVar11 = func_0x(&stack0x00000310 + lVar20);
                if (cVar11 == '\0') goto LAB_;
                cVar11 = '\x01';
              }
              else {
LAB_:
                cVar11 = '\0';
              }
              (&stack0x00000052)[lVar20] = cVar11;
              if (cVar11 == '\0') goto LAB_;
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10605e;
              func_0x(lVar35,&stack0x000002c0 + lVar20);
            }
            *(undefined **)(&stack0x00001390 + lVar20) = &stack0x000002c0 + lVar20;
            lVar35 = *(longlong *)(&stack0x000000d0 + lVar20) + 0x20fc;
            *(longlong *)(&stack0x00000a58 + lVar20) = lVar35;
            *(undefined4 *)(&stack0x00000284 + lVar20) = 0;
            *(undefined4 *)(&stack0x00000288 + lVar20) = 0;
            *(undefined2 *)(&stack0x0000028c + lVar20) = 0;
            *(undefined2 *)(&stack0x0000028e + lVar20) = 0;
            puVar28 = (uint *)(*(longlong *)(&stack0x000000d0 + lVar20) + 0x2108);
            *(uint **)(&stack0x00001398 + lVar20) = puVar28;
            uVar17 = *puVar28;
            *(uint *)(&stack0x0000026c + lVar20) = uVar17;
            *(uint **)(&stack0x00000a60 + lVar20) = puVar28;
            do {
              *(uint *)(&stack0x000004b0 + lVar20) = uVar17 & 0xfffffffe;
              *(undefined8 *)(&stack0x00000284 + lVar20) =
                   **(undefined8 **)(&stack0x00000a58 + lVar20);
              *(undefined4 *)(&stack0x0000028c + lVar20) =
                   *(undefined4 *)(*(undefined8 **)(&stack0x00000a58 + lVar20) + 1);
              LOCK();
              *(undefined4 *)(&stack0xffffffffffffffc8 + lVar20) =
                   *(undefined4 *)(&stack0xffffffffffffffc8 + lVar20);
              UNLOCK();
              uVar17 = **(uint **)(&stack0x00000a60 + lVar20);
              *(uint *)(&stack0x0000026c + lVar20) = uVar17;
            } while (*(uint *)(&stack0x000004b0 + lVar20) != uVar17);
            if (*(uint *)(&stack0x000002c0 + lVar20) <= *(uint *)(&stack0x00000284 + lVar20)) {
              if (*(uint *)(&stack0x00000284 + lVar20) != *(uint *)(&stack0x000002c0 + lVar20))
              goto LAB_;
              uVar17 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000284 + lVar20) >> 0x20);
              if (*(uint *)(&stack0x000002c4 + lVar20) <= uVar17) {
                if (uVar17 != *(uint *)(&stack0x000002c4 + lVar20)) goto LAB_;
                if (*(ushort *)(&stack0x000002c8 + lVar20) <= *(ushort *)(&stack0x0000028c + lVar20)
                   ) {
                  lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
                  goto LAB_;
                }
              }
            }
            if (*(char *)(*(longlong *)(&stack0x000000d0 + lVar20) + 0x6ac8) != '\0') {
LAB_:
              if ((&stack0x00000028)[lVar20] != '\0') {
                lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
                goto LAB_;
              }
              lVar35 = *(longlong *)(unaff_GS_OFFSET + 0x58);
              *(longlong *)(&stack0x00001468 + lVar20) = lVar35;
              lVar35 = (ulonglong)*_DAT_ +
                       *(longlong *)(lVar35 + (ulonglong)*_DAT_ * 8);
              *(longlong *)(&stack0x00001470 + lVar20) = lVar35;
              lVar35 = *(longlong *)(lVar35 + 8);
              *(longlong *)(&stack0x00001478 + lVar20) = lVar35;
              lVar35 = *(longlong *)(lVar35 + 0x60);
              *(longlong *)(&stack0x00001480 + lVar20) = lVar35;
              if (lVar35 == *(longlong *)(*(longlong *)(&stack0x000000d0 + lVar20) + 0x2120))
              goto LAB_;
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10689f;
              cVar11 = func_0x(*(longlong *)(&stack0x000000d0 + lVar20));
              if (cVar11 != '\0') goto LAB_;
              if (*(longlong *)(&stack0x000002a8 + lVar20) == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1068b2;
                uVar27 = func_0x();
                *(undefined8 *)(&stack0x000002a8 + lVar20) = uVar27;
              }
              *(undefined **)(&stack0x00001488 + lVar20) = &stack0x000002e0 + lVar20;
              lVar35 = **(longlong **)((longlong)&plStackX_10 + lVar20);
              *(longlong *)(&stack0x00001490 + lVar20) = lVar35;
              (&stack0x00000054)[lVar20] = 0;
              if (*(short *)(lVar35 + 0x24) == 0) {
LAB_:
                uVar27 = *(undefined8 *)(lVar35 + 0x28);
                *(undefined8 *)(&stack0x000002e0 + lVar20) = uVar27;
                uVar14 = *(undefined2 *)(lVar35 + 0x30);
                *(undefined2 *)(&stack0x000002e8 + lVar20) = uVar14;
              }
              else {
                cVar11 = *(char *)(lVar35 + 1);
                if ((((cVar11 == '\v') || (cVar11 == '\b')) || (cVar11 == '\t')) &&
                   (*(int *)(lVar35 + 0x18) == 99)) {
                  *(undefined **)(&stack0x00001498 + lVar20) = &stack0x00000318 + lVar20;
                  *(undefined4 **)(&stack0x000014a0 + lVar20) = (undefined4 *)(lVar35 + 0x20);
                  *(undefined4 *)(&stack0x00000318 + lVar20) = *(undefined4 *)(lVar35 + 0x20);
                  *(undefined2 *)(&stack0x0000031c + lVar20) = *(undefined2 *)(lVar35 + 0x24);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106943;
                  cVar11 = func_0x(&stack0x00000318 + lVar20);
                  if (cVar11 == '\0') goto LAB_;
                  cVar11 = '\x01';
                }
                else {
LAB_:
                  cVar11 = '\0';
                }
                (&stack0x00000054)[lVar20] = cVar11;
                if (cVar11 == '\0') goto LAB_;
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106968;
                func_0x(lVar35,&stack0x000002e0 + lVar20);
                uVar14 = *(undefined2 *)(&stack0x000002e8 + lVar20);
                uVar27 = *(undefined8 *)(&stack0x000002e0 + lVar20);
              }
              *(undefined **)(&stack0x000014a8 + lVar20) = &stack0x000002e0 + lVar20;
              *(undefined8 *)(&stack0x00000358 + lVar20) = uVar27;
              *(undefined2 *)(&stack0x00000360 + lVar20) = uVar14;
              *(undefined2 *)(&stack0x00000362 + lVar20) = 0;
              if (*(longlong *)((longlong)&plStackX_10 + lVar20) != 0) {
                puVar23 = (undefined2 *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x62);
                *(undefined2 **)(&stack0x000014b0 + lVar20) = puVar23;
                *(undefined2 *)(&stack0x00000158 + lVar20) = *puVar23;
                if (((*(ushort *)(&stack0x00000158 + lVar20) & 0x400) == 0) ||
                   (*(short *)((longlong)&uStackX_1c + lVar20) < 3)) {
                  *(int *)(&stack0x00000078 + lVar20) =
                       (int)*(short *)((longlong)&uStackX_1c + lVar20);
                  *(undefined8 *)(&stack0x00000590 + lVar20) =
                       *(undefined8 *)((longlong)&plStackX_10 + lVar20);
                  *(undefined2 **)(&stack0x000014b8 + lVar20) = puVar23;
                  uVar14 = *puVar23;
                  *(undefined2 *)(&stack0x00000160 + lVar20) = uVar14;
                  if (((byte)uVar14 >> 3 & 1) != 0) {
                    if (*(int *)(&stack0x00000078 + lVar20) == 3) {
                      *(undefined4 *)(&stack0x00000078 + lVar20) = 4;
                    }
                    else if (*(int *)(&stack0x00000078 + lVar20) < 2) goto LAB_;
                    puVar28 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 100);
                    *(uint **)(&stack0x000014c0 + lVar20) = puVar28;
                    uVar17 = *puVar28;
                    *(uint *)(&stack0x000004c0 + lVar20) = uVar17;
                    if ((((uVar17 & 8) != 0) &&
                        (lVar35 = *(longlong *)
                                   (*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x90),
                        lVar35 != 0)) &&
                       (*(longlong *)(&stack0x000014c8 + lVar20) = lVar35,
                       *(longlong *)(lVar35 + 0x758) != 0)) {
                      uVar27 = *(undefined8 *)(lVar35 + 0x758);
                      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106abe;
                      func_0x
                                (uVar27,*(undefined8 *)((longlong)&plStackX_10 + lVar20),
                                 *(undefined4 *)(&stack0x00000078 + lVar20));
                    }
                  }
LAB_:
                  (&stack0x0000020c)[lVar20] = DAT_ >> 7;
                  if ((char)DAT_ < '\0') {
                    puVar28 = (uint *)(*(longlong *)(&stack0x00000590 + lVar20) + 100);
                    *(uint **)(&stack0x000014d0 + lVar20) = puVar28;
                    uVar17 = *puVar28;
                    *(uint *)(&stack0x000004c8 + lVar20) = uVar17;
                    if (((uVar17 & 8) != 0) && (2 < *(int *)(&stack0x00000078 + lVar20))) {
                      *(uint **)(&stack0x000014d8 + lVar20) = puVar28;
                      uVar17 = *puVar28;
                      *(uint *)(&stack0x000004d0 + lVar20) = uVar17;
                      if (((uVar17 & 0xc0000000) != 0x40000000) &&
                         (lVar35 = **(longlong **)(&stack0x00000590 + lVar20), lVar35 != 0)) {
                        *(undefined4 *)(&stack0x00000944 + lVar20) = 2;
                        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106b4d;
                        iVar15 = (*_DAT_)(lVar35,0x2000,2,&stack0x00000948 + lVar20);
                        if (iVar15 != 0) {
                          LOCK();
                          *puVar28 = *puVar28 & 0x3fffffff;
                          UNLOCK();
                          LOCK();
                          *puVar28 = *puVar28 | 0x40000000;
                          UNLOCK();
                        }
                      }
                    }
                  }
                  lVar35 = *(longlong *)(&stack0x00000590 + lVar20);
                  uVar19 = *(undefined4 *)(&stack0x00000078 + lVar20);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106b7c;
                  func_0x(lVar35 + 0x98,uVar19);
                  if ((_DAT_ != 0) &&
                     ((&stack0x0000020d)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0))
                  {
                    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106ba6;
                    func_0x(lVar35,0,uVar19);
                  }
                  *(uint *)((longlong)&uStackX_1c + lVar20) =
                       *(uint *)((longlong)&uStackX_1c + lVar20) & 0xffff0000;
                  *(undefined8 *)((longlong)&plStackX_10 + lVar20) = 0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106a0d;
                  func_0x((longlong)&plStackX_10 + lVar20);
                }
                uVar27 = *(undefined8 *)(&stack0x00000358 + lVar20);
                uVar14 = *(undefined2 *)(&stack0x00000360 + lVar20);
              }
              *(undefined **)(&stack0x000014e0 + lVar20) = &stack0x000007d8 + lVar20;
              *(undefined8 *)(&stack0x000007d8 + lVar20) = uVar27;
              *(undefined2 *)(&stack0x000007e0 + lVar20) = uVar14;
              *(undefined **)(&stack0x000014e8 + lVar20) = &stack0x000006c0 + lVar20;
              *(undefined8 *)(&stack0x000006c0 + lVar20) = uVar27;
              *(undefined2 *)(&stack0x000006c8 + lVar20) = uVar14;
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar20) = 0;
              uVar27 = *(undefined8 *)(lVar36 + 0x728);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106c2b;
              func_0x(uVar27,&stack0x000006c0 + lVar20,4);
              lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
              goto LAB_;
            }
            lVar29 = *(longlong *)(unaff_GS_OFFSET + 0x58);
            *(longlong *)(&stack0x000013a0 + lVar20) = lVar29;
            lVar29 = (ulonglong)*_DAT_ +
                     *(longlong *)(lVar29 + (ulonglong)*_DAT_ * 8);
            *(longlong *)(&stack0x000013a8 + lVar20) = lVar29;
            lVar29 = *(longlong *)(lVar29 + 8);
            *(longlong *)(&stack0x000013b0 + lVar20) = lVar29;
            lVar29 = *(longlong *)(lVar29 + 0x60);
            *(longlong *)(&stack0x000013b8 + lVar20) = lVar29;
            if (lVar29 == *(longlong *)(*(longlong *)(&stack0x000000d0 + lVar20) + 0x2120))
            goto LAB_;
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1061f2;
            cVar11 = func_0x(*(longlong *)(&stack0x000000d0 + lVar20));
            if (cVar11 != '\0') goto LAB_;
            *(longlong *)(&stack0x00000760 + lVar20) = lVar35;
            *(undefined4 *)(&stack0x00000250 + lVar20) = 0;
            *(undefined4 *)(&stack0x00000254 + lVar20) = 0;
            *(undefined2 *)(&stack0x00000258 + lVar20) = 0;
            *(undefined2 *)(&stack0x0000025a + lVar20) = 0;
            *(uint **)(&stack0x000013c0 + lVar20) = puVar28;
            uVar17 = *puVar28;
            *(uint *)(&stack0x00000270 + lVar20) = uVar17;
            puVar33 = *(undefined8 **)(&stack0x00000760 + lVar20);
            *(longlong *)(&stack0x00000a68 + lVar20) = (longlong)puVar33 + 0xc;
            while( true ) {
              *(uint *)(&stack0x000004b4 + lVar20) = uVar17 & 0xfffffffe;
              *(undefined8 *)(&stack0x00000250 + lVar20) = *puVar33;
              *(undefined4 *)(&stack0x00000258 + lVar20) = *(undefined4 *)(puVar33 + 1);
              LOCK();
              *(undefined4 *)(&stack0xffffffffffffffc8 + lVar20) =
                   *(undefined4 *)(&stack0xffffffffffffffc8 + lVar20);
              UNLOCK();
              uVar17 = **(uint **)(&stack0x00000a68 + lVar20);
              *(uint *)(&stack0x00000270 + lVar20) = uVar17;
              if (*(uint *)(&stack0x000004b4 + lVar20) == uVar17) break;
              puVar33 = *(undefined8 **)(&stack0x00000760 + lVar20);
            }
            *(undefined8 *)(&stack0x000007c8 + lVar20) = *(undefined8 *)(&stack0x00000250 + lVar20);
            uVar4 = *(ushort *)(&stack0x00000258 + lVar20);
            *(ushort *)(&stack0x000007d0 + lVar20) = uVar4;
            lVar35 = **(longlong **)((longlong)&plStackX_10 + lVar20);
            *(longlong *)(&stack0x000013c8 + lVar20) = lVar35;
            (&stack0x00000053)[lVar20] = 0;
            if (*(short *)(lVar35 + 0x24) == 0) {
LAB_:
              *(undefined8 *)(&stack0x000002d0 + lVar20) = *(undefined8 *)(lVar35 + 0x28);
              uVar5 = *(ushort *)(lVar35 + 0x30);
              *(ushort *)(&stack0x000002d8 + lVar20) = uVar5;
            }
            else {
              cVar11 = *(char *)(lVar35 + 1);
              if ((((cVar11 == '\v') || (cVar11 == '\b')) || (cVar11 == '\t')) &&
                 (*(int *)(lVar35 + 0x18) == 99)) {
                *(undefined **)(&stack0x000013d0 + lVar20) = &stack0x00000328 + lVar20;
                *(undefined4 **)(&stack0x000013d8 + lVar20) = (undefined4 *)(lVar35 + 0x20);
                *(undefined4 *)(&stack0x00000328 + lVar20) = *(undefined4 *)(lVar35 + 0x20);
                *(undefined2 *)(&stack0x0000032c + lVar20) = *(undefined2 *)(lVar35 + 0x24);
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106335;
                cVar11 = func_0x(&stack0x00000328 + lVar20);
                if (cVar11 == '\0') goto LAB_;
                cVar11 = '\x01';
              }
              else {
LAB_:
                cVar11 = '\0';
              }
              (&stack0x00000053)[lVar20] = cVar11;
              if (cVar11 == '\0') goto LAB_;
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10635a;
              func_0x(lVar35,&stack0x000002d0 + lVar20);
              uVar5 = *(ushort *)(&stack0x000002d8 + lVar20);
            }
            if (*(uint *)(&stack0x00000250 + lVar20) < *(uint *)(&stack0x000002d0 + lVar20)) {
LAB_:
              lVar35 = *(longlong *)(&stack0x000000d0 + lVar20);
              lVar36 = *(longlong *)(lVar35 + 0x6b0);
              *(longlong *)(&stack0x000013e0 + lVar20) = lVar36;
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1063f7;
              func_0x(&stack0x000002d0 + lVar20,&stack0x00002710 + lVar20,
                              &stack0x000004b8 + lVar20);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106414;
              func_0x(&stack0x000007c8 + lVar20,&stack0x00002740 + lVar20,
                              &stack0x000004b8 + lVar20);
              *(undefined4 *)(&stack0x00000a70 + lVar20) = 0x1d;
              *(undefined4 *)(&stack0x00000a74 + lVar20) = 0x10000;
              if ((_DAT_ & 0x10000) != 0) {
                *(undefined2 *)(&stack0x00000380 + lVar20) = 6;
                *(undefined **)(&stack0x000013e8 + lVar20) = &stack0x00001770 + lVar20;
                *(undefined2 *)(&stack0x00001770 + lVar20) = 0;
                *(undefined2 *)(&stack0x00001772 + lVar20) = 6;
                *(undefined4 *)(&stack0x00001778 + lVar20) = 0;
                *(undefined **)(&stack0x00001780 + lVar20) = &stack0x00001798 + lVar20;
                *(undefined **)(&stack0x00001788 + lVar20) = &stack0x000017f8 + lVar20;
                *(undefined4 *)(&stack0x000019b8 + lVar20) = 0;
                *(undefined4 *)(&stack0x000019bc + lVar20) = 0;
                *(undefined8 *)(&stack0x00001790 + lVar20) = 0;
                *(undefined8 *)(&stack0x000019c0 + lVar20) = 0;
                *(undefined **)(&stack0x000013f0 + lVar20) = &stack0x00001798 + lVar20;
                *(undefined **)(&stack0x00001798 + lVar20) = &stack0x000019c8 + lVar20;
                *(undefined4 *)(&stack0x000017a0 + lVar20) = 0x34;
                *(undefined2 *)(&stack0x000017a4 + lVar20) = 5;
                *(undefined2 *)(&stack0x000017a6 + lVar20) = 0;
                *(undefined **)(&stack0x000013f8 + lVar20) = &stack0x000017a8 + lVar20;
                *(undefined8 *)(&stack0x000017a8 + lVar20) = 0x189eb28;
                *(undefined4 *)(&stack0x000017b0 + lVar20) = 0x10;
                *(undefined2 *)(&stack0x000017b4 + lVar20) = 5;
                *(undefined2 *)(&stack0x000017b6 + lVar20) = 0;
                *(undefined **)(&stack0x00001400 + lVar20) = &stack0x000017b8 + lVar20;
                *(undefined8 *)(&stack0x000017b8 + lVar20) = 0x189eb28;
                *(undefined4 *)(&stack0x000017c0 + lVar20) = 0x10;
                *(undefined2 *)(&stack0x000017c4 + lVar20) = 6;
                *(undefined2 *)(&stack0x000017c6 + lVar20) = 0;
                *(undefined **)(&stack0x00001408 + lVar20) = &stack0x000017c8 + lVar20;
                *(undefined8 *)(&stack0x000017c8 + lVar20) = 0;
                *(undefined4 *)(&stack0x000017d0 + lVar20) = 0;
                *(undefined2 *)(&stack0x000017d4 + lVar20) = 7;
                *(undefined2 *)(&stack0x000017d6 + lVar20) = 0;
                *(undefined **)(&stack0x00001410 + lVar20) = &stack0x000017d8 + lVar20;
                *(undefined8 *)(&stack0x000017d8 + lVar20) = 0;
                *(undefined4 *)(&stack0x000017e0 + lVar20) = 0;
                *(undefined2 *)(&stack0x000017e4 + lVar20) = 8;
                *(undefined2 *)(&stack0x000017e6 + lVar20) = 0;
                *(undefined **)(&stack0x00001418 + lVar20) = &stack0x000017e8 + lVar20;
                *(undefined8 *)(&stack0x000017e8 + lVar20) = 0;
                *(undefined4 *)(&stack0x000017f0 + lVar20) = 0;
                *(undefined2 *)(&stack0x000017f4 + lVar20) = 9;
                *(undefined2 *)(&stack0x000017f6 + lVar20) = 0;
                *(uint *)(&stack0x000019c8 + lVar20) = (uint)*(ushort *)(lVar35 + 0x6b8);
                *(undefined2 *)(&stack0x000019cc + lVar20) =
                     *(undefined2 *)(&stack0x0000005c + lVar20);
                *(undefined4 *)(&stack0x000019ce + lVar20) =
                     *(undefined4 *)(&stack0x00000058 + lVar20);
                (&stack0x000019d2)[lVar20] = (&stack0x00000029)[lVar20];
                lVar35 = **(longlong **)((longlong)&plStackX_10 + lVar20);
                *(longlong *)(&stack0x00001420 + lVar20) = lVar35;
                (&stack0x000019d3)[lVar20] = *(undefined *)(lVar35 + 1);
                *(undefined **)(&stack0x00001428 + lVar20) = &stack0x000017a8 + lVar20;
                *(longlong *)(&stack0x000017a8 + lVar20) = lVar36 + 0x254;
                *(undefined4 *)(&stack0x000017b0 + lVar20) = 0x10;
                *(undefined2 *)(&stack0x000017b4 + lVar20) = 5;
                *(undefined2 *)(&stack0x000017b6 + lVar20) = 0;
                *(undefined **)(&stack0x00001430 + lVar20) = &stack0x000017b8 + lVar20;
                *(longlong *)(&stack0x000017b8 + lVar20) = lVar36 + 0x244;
                *(undefined4 *)(&stack0x000017c0 + lVar20) = 0x10;
                *(undefined2 *)(&stack0x000017c4 + lVar20) = 6;
                *(undefined2 *)(&stack0x000017c6 + lVar20) = 0;
                *(undefined **)(&stack0x00001438 + lVar20) = &stack0x00002710 + lVar20;
                lVar35 = -1;
                do {
                  lVar35 = lVar35 + 1;
                } while (*(short *)(&stack0x00002710 + lVar35 * 2 + lVar20) != 0);
                iVar15 = (int)lVar35 * 2;
                *(int *)(&stack0x00000938 + lVar20) = iVar15;
                *(undefined **)(&stack0x00001440 + lVar20) = &stack0x000017c8 + lVar20;
                *(undefined **)(&stack0x000017c8 + lVar20) = &stack0x00002710 + lVar20;
                *(int *)(&stack0x000017d0 + lVar20) = iVar15;
                *(undefined2 *)(&stack0x000017d4 + lVar20) = 7;
                *(undefined2 *)(&stack0x000017d6 + lVar20) = 0;
                *(undefined **)(&stack0x00001448 + lVar20) = &stack0x00002740 + lVar20;
                lVar35 = -1;
                do {
                  lVar35 = lVar35 + 1;
                } while (*(short *)(&stack0x00002740 + lVar35 * 2 + lVar20) != 0);
                iVar15 = (int)lVar35 * 2;
                *(int *)(&stack0x0000093c + lVar20) = iVar15;
                *(undefined **)(&stack0x00001450 + lVar20) = &stack0x000017d8 + lVar20;
                *(undefined **)(&stack0x000017d8 + lVar20) = &stack0x00002740 + lVar20;
                *(int *)(&stack0x000017e0 + lVar20) = iVar15;
                *(undefined2 *)(&stack0x000017e4 + lVar20) = 8;
                *(undefined2 *)(&stack0x000017e6 + lVar20) = 0;
                *(undefined4 *)(&stack0x000004bc + lVar20) = 0;
                UNRECOVERED_JUMPTABLE_00 = *(code **)(_DAT_ + 0x10);
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1067cf;
                lVar35 = (*UNRECOVERED_JUMPTABLE_00)(lVar36,&stack0x000004bc + lVar20);
                *(longlong *)(&stack0x00001458 + lVar20) = lVar35;
                iVar15 = 0;
                if (lVar35 != 0) {
                  lVar36 = -1;
                  do {
                    lVar36 = lVar36 + 1;
                  } while (*(short *)(lVar35 + lVar36 * 2) != 0);
                  iVar15 = (int)lVar36 * 2;
                }
                *(int *)(&stack0x00000940 + lVar20) = iVar15;
                lVar36 = *(longlong *)(&stack0x00001780 + lVar20);
                *(longlong **)(&stack0x00001460 + lVar20) = (longlong *)(lVar36 + 0x50);
                *(longlong *)(lVar36 + 0x50) = lVar35;
                *(int *)(lVar36 + 0x58) = iVar15;
                *(undefined2 *)(lVar36 + 0x5c) = 9;
                *(undefined2 *)(lVar36 + 0x5e) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10682a;
                func_0x(&stack0x00001768 + lVar20);
              }
LAB_:
              lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
            }
            else {
              if (*(uint *)(&stack0x00000250 + lVar20) != *(uint *)(&stack0x000002d0 + lVar20))
              goto LAB_;
              uVar17 = (uint)((ulonglong)*(undefined8 *)(&stack0x000002d0 + lVar20) >> 0x20);
              if (*(uint *)(&stack0x00000254 + lVar20) < uVar17) goto LAB_;
              if (*(uint *)(&stack0x00000254 + lVar20) != uVar17) goto LAB_;
              if (uVar4 < uVar5) goto LAB_;
              lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
            }
LAB_:
            if ((1 < *(short *)((longlong)&uStackX_1c + lVar20)) &&
               ((&stack0x00000029)[lVar20] != -1)) {
              lVar36 = **(longlong **)((longlong)&plStackX_10 + lVar20);
              *(longlong *)(&stack0x000014f0 + lVar20) = lVar36;
              if (*(char *)(lVar36 + 1) != (&stack0x00000029)[lVar20]) {
                if (*(longlong *)(&stack0x000002a8 + lVar20) != 0) {
                  *(longlong *)(&stack0x000014f8 + lVar20) = lVar36;
                  *(longlong *)(*(longlong *)(&stack0x000002a8 + lVar20) + 0x588) = lVar36;
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106c97;
                lVar36 = func_0x();
                if (lVar36 == 0) {
LAB_:
                  *(undefined4 *)(&stack0x000004d8 + lVar20) = 0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106ca1;
                  lVar36 = func_0x();
                  if (*(longlong *)(lVar36 + 0x30) == 0) goto LAB_;
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106cac;
                  lVar36 = func_0x();
                  uVar17 = *(uint *)(*(longlong *)(lVar36 + 0x30) + 0xc);
                  *(uint *)(&stack0x0000094c + lVar20) = uVar17;
                  if ((0xd < uVar17) || (iVar15 = 1, (0x2640U >> (uVar17 & 0x1f) & 1) == 0)) {
                    iVar15 = 0;
                  }
                  *(int *)(&stack0x000004d8 + lVar20) = iVar15;
                  if (iVar15 != 0) goto LAB_;
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106cf2;
                func_0x(0,8);
              }
            }
LAB_:
            *(undefined4 *)(&stack0x000007e8 + lVar20) = 0;
            *(undefined4 *)(&stack0x000007ec + lVar20) = 0;
            *(undefined2 *)(&stack0x000007f0 + lVar20) = 0;
            if (((*(short *)(&stack0x00000350 + lVar20) == 0) &&
                (*(int *)(&stack0x00000348 + lVar20) == 0)) &&
               (*(int *)(&stack0x0000034c + lVar20) == 0)) goto LAB_;
            lVar36 = **(longlong **)((longlong)&plStackX_10 + lVar20);
            *(longlong *)(&stack0x00001500 + lVar20) = lVar36;
            if ((*(byte *)(lVar36 + 4) & 1) == 0) goto LAB_;
            puVar23 = (undefined2 *)
                      ((longlong)*(longlong **)((longlong)&plStackX_10 + lVar20) + 0x62);
            *(undefined2 **)(&stack0x00001508 + lVar20) = puVar23;
            *(undefined2 *)(&stack0x000001b0 + lVar20) = *puVar23;
            if (((*(ushort *)(&stack0x000001b0 + lVar20) & 0x400) == 0) ||
               (*(short *)((longlong)&uStackX_1c + lVar20) < 3)) {
              *(int *)(&stack0x00000080 + lVar20) = (int)*(short *)((longlong)&uStackX_1c + lVar20);
              *(undefined8 *)(&stack0x00000598 + lVar20) =
                   *(undefined8 *)((longlong)&plStackX_10 + lVar20);
              *(undefined2 **)(&stack0x00001510 + lVar20) = puVar23;
              uVar14 = *puVar23;
              *(undefined2 *)(&stack0x00000168 + lVar20) = uVar14;
              if (((byte)uVar14 >> 3 & 1) != 0) {
                if (*(int *)(&stack0x00000080 + lVar20) == 3) {
                  *(undefined4 *)(&stack0x00000080 + lVar20) = 4;
                }
                else if (*(int *)(&stack0x00000080 + lVar20) < 2) goto LAB_;
                puVar28 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 100);
                *(uint **)(&stack0x00001518 + lVar20) = puVar28;
                uVar17 = *puVar28;
                *(uint *)(&stack0x000004e0 + lVar20) = uVar17;
                if ((((uVar17 & 8) != 0) &&
                    (lVar35 = *(longlong *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x90),
                    lVar35 != 0)) &&
                   (*(longlong *)(&stack0x00001520 + lVar20) = lVar35,
                   *(longlong *)(lVar35 + 0x758) != 0)) {
                  uVar27 = *(undefined8 *)(lVar35 + 0x758);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106e36;
                  func_0x
                            (uVar27,*(undefined8 *)((longlong)&plStackX_10 + lVar20),
                             *(undefined4 *)(&stack0x00000080 + lVar20));
                }
              }
LAB_:
              (&stack0x0000020e)[lVar20] = DAT_ >> 7;
              if ((char)DAT_ < '\0') {
                puVar28 = (uint *)(*(longlong *)(&stack0x00000598 + lVar20) + 100);
                *(uint **)(&stack0x00001528 + lVar20) = puVar28;
                uVar17 = *puVar28;
                *(uint *)(&stack0x000004e8 + lVar20) = uVar17;
                if (((uVar17 & 8) != 0) && (2 < *(int *)(&stack0x00000080 + lVar20))) {
                  *(uint **)(&stack0x00001530 + lVar20) = puVar28;
                  uVar17 = *puVar28;
                  *(uint *)(&stack0x000004f0 + lVar20) = uVar17;
                  if (((uVar17 & 0xc0000000) != 0x40000000) &&
                     (lVar35 = **(longlong **)(&stack0x00000598 + lVar20), lVar35 != 0)) {
                    *(undefined4 *)(&stack0x00000950 + lVar20) = 2;
                    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106ec5;
                    iVar15 = (*_DAT_)(lVar35,0x2000,2,&stack0x00000954 + lVar20);
                    if (iVar15 != 0) {
                      LOCK();
                      *puVar28 = *puVar28 & 0x3fffffff;
                      UNLOCK();
                      LOCK();
                      *puVar28 = *puVar28 | 0x40000000;
                      UNLOCK();
                    }
                  }
                }
              }
              lVar35 = *(longlong *)(&stack0x00000598 + lVar20);
              uVar19 = *(undefined4 *)(&stack0x00000080 + lVar20);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106ef4;
              func_0x(lVar35 + 0x98,uVar19);
              if ((_DAT_ != 0) &&
                 ((&stack0x0000020f)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106f1e;
                func_0x(lVar35,0,uVar19);
              }
              *(uint *)((longlong)&uStackX_1c + lVar20) =
                   *(uint *)((longlong)&uStackX_1c + lVar20) & 0xffff0000;
              *(undefined8 *)((longlong)&plStackX_10 + lVar20) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106d84;
              func_0x((longlong)&plStackX_10 + lVar20);
            }
            *(undefined4 *)(&stack0x00000b28 + lVar20) = 0x400060;
            *(undefined8 *)(&stack0x00000b30 + lVar20) = 0;
            *(undefined8 *)(&stack0x00000b40 + lVar20) = 0;
            *(undefined8 *)(&stack0x00000b38 + lVar20) = 0;
            *(undefined8 *)(&stack0x00000b48 + lVar20) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x106f68;
            func_0x(10,&stack0x00000b28 + lVar20);
            lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
          } while( true );
        }
        if (*(int *)(param_1 + 0xd0) != 2) {
          *(longlong **)(&stack0x00000578 + lVar20) = (longlong *)(param_1 + 0x68);
          lVar35 = *(longlong *)(param_1 + 0x68);
          if (lVar35 != 0) {
            puVar23 = (undefined2 *)(lVar35 + 0x62);
            *(undefined2 **)(&stack0x00001230 + lVar20) = puVar23;
            *(undefined2 *)(&stack0x00000128 + lVar20) = *puVar23;
            plVar31 = *(longlong **)(&stack0x00000578 + lVar20);
            if (((*(ushort *)(&stack0x00000128 + lVar20) & 0x400) == 0) ||
               (*(short *)((longlong)plVar31 + 0xc) < 3)) {
              *(int *)(&stack0x00000068 + lVar20) = (int)*(short *)((longlong)plVar31 + 0xc);
              lVar35 = *plVar31;
              *(longlong *)(&stack0x00000218 + lVar20) = lVar35;
              puVar23 = (undefined2 *)(lVar35 + 0x62);
              *(undefined2 **)(&stack0x00001238 + lVar20) = puVar23;
              uVar14 = *puVar23;
              *(undefined2 *)(&stack0x00000130 + lVar20) = uVar14;
              if (((byte)uVar14 >> 3 & 1) != 0) {
                if (*(int *)(&stack0x00000068 + lVar20) == 3) {
                  *(undefined4 *)(&stack0x00000068 + lVar20) = 4;
                }
                else if (*(int *)(&stack0x00000068 + lVar20) < 2) goto LAB_;
                *(uint **)(&stack0x00001240 + lVar20) =
                     (uint *)(*(longlong *)(&stack0x00000218 + lVar20) + 100);
                uVar17 = *(uint *)(*(longlong *)(&stack0x00000218 + lVar20) + 100);
                *(uint *)(&stack0x00000460 + lVar20) = uVar17;
                if ((((uVar17 & 8) != 0) &&
                    (lVar35 = *(longlong *)(*(longlong *)(&stack0x00000218 + lVar20) + 0x90),
                    lVar35 != 0)) &&
                   (*(longlong *)(&stack0x00001248 + lVar20) = lVar35,
                   *(longlong *)(lVar35 + 0x758) != 0)) {
                  uVar27 = *(undefined8 *)(lVar35 + 0x758);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105457;
                  func_0x
                            (uVar27,*(undefined8 *)(&stack0x00000218 + lVar20),
                             *(undefined4 *)(&stack0x00000068 + lVar20));
                }
              }
LAB_:
              (&stack0x000001bc)[lVar20] = DAT_ >> 7;
              if ((char)DAT_ < '\0') {
                puVar28 = (uint *)(*(longlong *)(&stack0x00000218 + lVar20) + 100);
                *(uint **)(&stack0x00001250 + lVar20) = puVar28;
                uVar17 = *puVar28;
                *(uint *)(&stack0x00000468 + lVar20) = uVar17;
                if (((uVar17 & 8) != 0) && (2 < *(int *)(&stack0x00000068 + lVar20))) {
                  *(uint **)(&stack0x00001258 + lVar20) = puVar28;
                  uVar17 = *puVar28;
                  *(uint *)(&stack0x00000470 + lVar20) = uVar17;
                  if (((uVar17 & 0xc0000000) != 0x40000000) &&
                     (lVar35 = **(longlong **)(&stack0x00000218 + lVar20), lVar35 != 0)) {
                    *(undefined4 *)(&stack0x0000090c + lVar20) = 2;
                    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1054ea;
                    iVar15 = (*_DAT_)(lVar35,0x2000,2,&stack0x00000910 + lVar20);
                    if (iVar15 != 0) {
                      LOCK();
                      *puVar28 = *puVar28 & 0x3fffffff;
                      UNLOCK();
                      LOCK();
                      *puVar28 = *puVar28 | 0x40000000;
                      UNLOCK();
                    }
                  }
                }
              }
              lVar35 = *(longlong *)(&stack0x00000218 + lVar20);
              uVar19 = *(undefined4 *)(&stack0x00000068 + lVar20);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105519;
              func_0x(lVar35 + 0x98,uVar19);
              if ((_DAT_ != 0) &&
                 ((&stack0x000001bd)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105543;
                func_0x(lVar35,0,uVar19);
              }
              *(uint *)((longlong)plVar31 + 0xc) = *(uint *)((longlong)plVar31 + 0xc) & 0xffff0000;
              **(undefined8 **)(&stack0x00000578 + lVar20) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105394;
              func_0x(plVar31);
            }
          }
          *(undefined4 *)(param_1 + 0x80) = 0xffffffff;
          *(undefined8 **)(&stack0x00001260 + lVar20) = (undefined8 *)(param_1 + 0x88);
          if (*(int *)(param_1 + 0x90) != 0) {
            *(undefined4 *)(&stack0x00000918 + lVar20) = *(undefined4 *)(param_1 + 0x94);
            *(undefined8 *)(&stack0x00001268 + lVar20) = *(undefined8 *)(param_1 + 0x88);
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105592;
            func_0x();
            *(undefined4 *)(param_1 + 0x90) = 0;
          }
          *(undefined4 *)(&stack0x000000f0 + lVar20) = 0;
          *(undefined2 *)(&stack0x000000f4 + lVar20) = 0;
          *(undefined4 **)(&stack0x00001270 + lVar20) = (undefined4 *)(param_1 + 0x9c);
          *(undefined4 *)(param_1 + 0x9c) = 0;
          *(undefined2 *)(param_1 + 0xa0) = 0;
          *(undefined4 *)(&stack0x000006d0 + lVar20) = 0;
          *(undefined4 *)(&stack0x000006d4 + lVar20) = 0;
          *(undefined2 *)(&stack0x000006d8 + lVar20) = 0;
          *(undefined8 *)(param_1 + 0xbc) = *(undefined8 *)(&stack0x000006d0 + lVar20);
          *(undefined2 *)(param_1 + 0xc4) = 0;
          *(undefined4 *)(param_1 + 0xd0) = 2;
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x105607;
        func_0x((longlong)&plStackX_10 + lVar20);
        goto LAB_;
      }
      piVar34 = *(int **)(&stack0x00000340 + lVar20);
LAB_:
      if (*piVar34 == 0) {
        if (*(int *)(param_1 + 0xd0) != 2) {
          *(longlong **)(&stack0x000005c0 + lVar20) = (longlong *)(param_1 + 0x68);
          lVar35 = *(longlong *)(param_1 + 0x68);
          if (lVar35 != 0) {
            puVar23 = (undefined2 *)(lVar35 + 0x62);
            *(undefined2 **)(&stack0x00001620 + lVar20) = puVar23;
            *(undefined2 *)(&stack0x000001a0 + lVar20) = *puVar23;
            plVar31 = *(longlong **)(&stack0x000005c0 + lVar20);
            if (((*(ushort *)(&stack0x000001a0 + lVar20) & 0x400) == 0) ||
               (*(short *)((longlong)plVar31 + 0xc) < 3)) {
              *(int *)(&stack0x000000a0 + lVar20) = (int)*(short *)((longlong)plVar31 + 0xc);
              lVar35 = *plVar31;
              *(longlong *)(&stack0x00000240 + lVar20) = lVar35;
              puVar23 = (undefined2 *)(lVar35 + 0x62);
              *(undefined2 **)(&stack0x00001628 + lVar20) = puVar23;
              uVar14 = *puVar23;
              *(undefined2 *)(&stack0x000001a8 + lVar20) = uVar14;
              if (((byte)uVar14 >> 3 & 1) != 0) {
                if (*(int *)(&stack0x000000a0 + lVar20) == 3) {
                  *(undefined4 *)(&stack0x000000a0 + lVar20) = 4;
                }
                else if (*(int *)(&stack0x000000a0 + lVar20) < 2) goto LAB_;
                *(uint **)(&stack0x00001630 + lVar20) =
                     (uint *)(*(longlong *)(&stack0x00000240 + lVar20) + 100);
                uVar17 = *(uint *)(*(longlong *)(&stack0x00000240 + lVar20) + 100);
                *(uint *)(&stack0x00000548 + lVar20) = uVar17;
                if ((((uVar17 & 8) != 0) &&
                    (lVar35 = *(longlong *)(*(longlong *)(&stack0x00000240 + lVar20) + 0x90),
                    lVar35 != 0)) &&
                   (*(longlong *)(&stack0x00001638 + lVar20) = lVar35,
                   *(longlong *)(lVar35 + 0x758) != 0)) {
                  uVar27 = *(undefined8 *)(lVar35 + 0x758);
                  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107b1d;
                  func_0x
                            (uVar27,*(undefined8 *)(&stack0x00000240 + lVar20),
                             *(undefined4 *)(&stack0x000000a0 + lVar20));
                }
              }
LAB_:
              (&stack0x00000103)[lVar20] = DAT_ >> 7;
              if ((char)DAT_ < '\0') {
                puVar28 = (uint *)(*(longlong *)(&stack0x00000240 + lVar20) + 100);
                *(uint **)(&stack0x00001640 + lVar20) = puVar28;
                uVar17 = *puVar28;
                *(uint *)(&stack0x00000550 + lVar20) = uVar17;
                if (((uVar17 & 8) != 0) && (2 < *(int *)(&stack0x000000a0 + lVar20))) {
                  *(uint **)(&stack0x00001648 + lVar20) = puVar28;
                  uVar17 = *puVar28;
                  *(uint *)(&stack0x00000558 + lVar20) = uVar17;
                  if (((uVar17 & 0xc0000000) != 0x40000000) &&
                     (lVar35 = **(longlong **)(&stack0x00000240 + lVar20), lVar35 != 0)) {
                    *(undefined4 *)(&stack0x00000974 + lVar20) = 2;
                    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107bac;
                    iVar15 = (*_DAT_)(lVar35,0x2000,2,&stack0x00000978 + lVar20);
                    if (iVar15 != 0) {
                      LOCK();
                      *puVar28 = *puVar28 & 0x3fffffff;
                      UNLOCK();
                      LOCK();
                      *puVar28 = *puVar28 | 0x40000000;
                      UNLOCK();
                    }
                  }
                }
              }
              lVar35 = *(longlong *)(&stack0x00000240 + lVar20);
              uVar19 = *(undefined4 *)(&stack0x000000a0 + lVar20);
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107bdb;
              func_0x(lVar35 + 0x98,uVar19);
              if ((_DAT_ != 0) &&
                 ((&stack0x00000104)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107c05;
                func_0x(lVar35,0,uVar19);
              }
              *(uint *)((longlong)plVar31 + 0xc) = *(uint *)((longlong)plVar31 + 0xc) & 0xffff0000;
              **(undefined8 **)(&stack0x000005c0 + lVar20) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107a59;
              func_0x(plVar31);
            }
          }
          *(undefined4 *)(param_1 + 0x80) = 0xffffffff;
          *(undefined8 **)(&stack0x00001650 + lVar20) = (undefined8 *)(param_1 + 0x88);
          if (*(int *)(param_1 + 0x90) != 0) {
            *(undefined4 *)(&stack0x00000980 + lVar20) = *(undefined4 *)(param_1 + 0x94);
            *(undefined8 *)(&stack0x00001658 + lVar20) = *(undefined8 *)(param_1 + 0x88);
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107c54;
            func_0x();
            *(undefined4 *)(param_1 + 0x90) = 0;
          }
          *(undefined4 *)(&stack0x000000e0 + lVar20) = 0;
          *(undefined2 *)(&stack0x000000e4 + lVar20) = 0;
          *(undefined4 **)(&stack0x00001660 + lVar20) = (undefined4 *)(param_1 + 0x9c);
          *(undefined4 *)(param_1 + 0x9c) = 0;
          *(undefined2 *)(param_1 + 0xa0) = 0;
          *(undefined4 *)(&stack0x000006b0 + lVar20) = 0;
          *(undefined4 *)(&stack0x000006b4 + lVar20) = 0;
          *(undefined2 *)(&stack0x000006b8 + lVar20) = 0;
          *(undefined8 *)(param_1 + 0xbc) = *(undefined8 *)(&stack0x000006b0 + lVar20);
          *(undefined2 *)(param_1 + 0xc4) = 0;
          *(undefined4 *)(param_1 + 0xd0) = 2;
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107cc4;
        func_0x((longlong)&plStackX_10 + lVar20);
        goto LAB_;
      }
      **(undefined4 **)(&stack0x00000a80 + lVar20) = *(undefined4 *)(&stack0x00000208 + lVar20);
      param_4 = *(int **)(&stack0x00000630 + lVar20);
      puVar23 = *(undefined2 **)(&stack0x000005d0 + lVar20);
    }
    lVar36 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar35 = *(longlong *)(lVar36 + 0x100);
    if (lVar35 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107d1f;
      (*_DAT_)();
      lVar35 = *(longlong *)(lVar36 + 0x100);
    }
    if (*(int *)(lVar35 + 0x22c) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107d35;
      (*_DAT_)();
    }
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107d40;
  func_0x((longlong)&plStackX_10 + lVar20);
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107d50;
  func_0x
            (*(ulonglong *)(&stack0x00002770 + lVar20) ^
             (ulonglong)(&stack0xffffffffffffffc8 + lVar20));
  return;
LAB_:
  lVar36 = *(longlong *)(&stack0x000005a0 + lVar20);
  *(int *)(lVar36 + 4) = *(int *)(lVar36 + 4) + 1;
  if (*(longlong *)(lVar36 + 0x58) != 0) {
    piVar34 = (int *)(*(longlong *)(lVar36 + 0x58) + 4);
    *piVar34 = *piVar34 + 1;
  }
  if ((*(uint *)((longlong)&uStackX_1c + lVar20) & 0xff000000) != 0) {
    *(int *)(*(longlong *)(&stack0x000005a0 + lVar20) + 8) =
         *(int *)(*(longlong *)(&stack0x000005a0 + lVar20) + 8) + 1;
    if (*(longlong *)(lVar36 + 0x58) != 0) {
      piVar34 = (int *)(*(longlong *)(lVar36 + 0x58) + 8);
      *piVar34 = *piVar34 + 1;
    }
    if (*(char *)((longlong)auStackX_20 + lVar20) != '\0') {
      *(int *)(*(longlong *)(&stack0x000005a0 + lVar20) + 0xc) =
           *(int *)(*(longlong *)(&stack0x000005a0 + lVar20) + 0xc) + 1;
      if (*(longlong *)(lVar36 + 0x58) != 0) {
        piVar34 = (int *)(*(longlong *)(lVar36 + 0x58) + 0xc);
        *piVar34 = *piVar34 + 1;
      }
    }
  }
  if (*(int *)(&stack0x00000b04 + lVar20) != 0) {
    lVar36 = **(longlong **)((longlong)&plStackX_10 + lVar20);
    *(longlong *)(&stack0x00001538 + lVar20) = lVar36;
    uVar13 = *(undefined *)(lVar36 + 1);
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107001;
    func_0x
              (*(undefined8 *)(&stack0x00000778 + lVar20),uVar13,&stack0x00000b00 + lVar20,
               0xffffffff);
  }
  if ((*(longlong *)(&stack0x00000768 + lVar20) == 0) ||
     (*(char *)(*(longlong *)(&stack0x000000d0 + lVar20) + 0x2050) == '\0')) {
    (&stack0x00000056)[lVar20] = 0;
    cVar11 = '\x01';
    (&stack0x00000057)[lVar20] = 1;
LAB_:
    *(undefined4 *)(&stack0x000000e8 + lVar20) = 0;
    *(undefined2 *)(&stack0x000000ec + lVar20) = 0;
    *(undefined2 *)(&stack0x000000ee + lVar20) = 0;
    lVar36 = **(longlong **)(&stack0x00000780 + lVar20);
    *(longlong *)(&stack0x00000a78 + lVar20) = lVar36;
    lVar29 = **(longlong **)((longlong)&plStackX_10 + lVar20);
    *(longlong *)(&stack0x00001540 + lVar20) = lVar29;
    lVar9 = *(longlong *)(lVar36 + 8);
    piVar34 = (int *)(lVar9 + 0x3c0);
    *(int **)(&stack0x00001548 + lVar20) = piVar34;
    *(undefined4 *)(&stack0x000004f8 + lVar20) = 0;
    if (*(int *)(lVar29 + 0x18) == *piVar34) {
      uVar4 = *(ushort *)(lVar9 + 0x3c4);
      if ((*(ushort *)(lVar29 + 6) == uVar4) || ((uVar4 | *(ushort *)(lVar29 + 6)) < 2)) {
        *(undefined4 *)(&stack0x000004f8 + lVar20) = 1;
        goto LAB_;
      }
    }
    *(longlong *)(&stack0x00001550 + lVar20) = lVar29;
    *(undefined4 *)(&stack0x000000f8 + lVar20) = 0;
    *(undefined2 *)(&stack0x000000fc + lVar20) = 0;
    *(undefined2 *)(&stack0x000000fe + lVar20) = 0;
    uVar19 = *(undefined4 *)(lVar29 + 0x18);
    *(undefined4 *)(&stack0x000000f8 + lVar20) = uVar19;
    uVar14 = *(undefined2 *)(lVar29 + 6);
    *(undefined2 *)(&stack0x000000fc + lVar20) = uVar14;
    *(undefined4 *)(&stack0x000000e8 + lVar20) = uVar19;
    *(undefined2 *)(&stack0x000000ec + lVar20) = uVar14;
    *(undefined2 *)(&stack0x000000ee + lVar20) = 0;
    puVar23 = (undefined2 *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x62);
    *(undefined2 **)(&stack0x00001558 + lVar20) = puVar23;
    *(undefined2 *)(&stack0x00000170 + lVar20) = *puVar23;
    if (((*(ushort *)(&stack0x00000170 + lVar20) & 0x400) == 0) ||
       (*(short *)((longlong)&uStackX_1c + lVar20) < 3)) {
      *(int *)(&stack0x00000088 + lVar20) = (int)*(short *)((longlong)&uStackX_1c + lVar20);
      *(undefined8 *)(&stack0x000005a8 + lVar20) = *(undefined8 *)((longlong)&plStackX_10 + lVar20);
      *(undefined2 **)(&stack0x00001560 + lVar20) = puVar23;
      uVar6 = *puVar23;
      *(undefined2 *)(&stack0x00000178 + lVar20) = uVar6;
      if (((byte)uVar6 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x00000088 + lVar20) == 3) {
          *(undefined4 *)(&stack0x00000088 + lVar20) = 4;
        }
        else if (*(int *)(&stack0x00000088 + lVar20) < 2) goto LAB_;
        puVar28 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 100);
        *(uint **)(&stack0x00001568 + lVar20) = puVar28;
        uVar17 = *puVar28;
        *(uint *)(&stack0x00000500 + lVar20) = uVar17;
        if ((((uVar17 & 8) != 0) &&
            (lVar35 = *(longlong *)(*(longlong *)((longlong)&plStackX_10 + lVar20) + 0x90),
            lVar35 != 0)) &&
           (*(longlong *)(&stack0x00001570 + lVar20) = lVar35, *(longlong *)(lVar35 + 0x758) != 0))
        {
          uVar27 = *(undefined8 *)(lVar35 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107245;
          func_0x
                    (uVar27,*(undefined8 *)((longlong)&plStackX_10 + lVar20),
                     *(undefined4 *)(&stack0x00000088 + lVar20));
        }
      }
LAB_:
      (&stack0x00000210)[lVar20] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar28 = (uint *)(*(longlong *)(&stack0x000005a8 + lVar20) + 100);
        *(uint **)(&stack0x00001578 + lVar20) = puVar28;
        uVar17 = *puVar28;
        *(uint *)(&stack0x00000508 + lVar20) = uVar17;
        if (((uVar17 & 8) != 0) && (2 < *(int *)(&stack0x00000088 + lVar20))) {
          *(uint **)(&stack0x00001580 + lVar20) = puVar28;
          uVar17 = *puVar28;
          *(uint *)(&stack0x00000510 + lVar20) = uVar17;
          if (((uVar17 & 0xc0000000) != 0x40000000) &&
             (lVar35 = **(longlong **)(&stack0x000005a8 + lVar20), lVar35 != 0)) {
            *(undefined4 *)(&stack0x00000958 + lVar20) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1072d8;
            iVar15 = (*_DAT_)(lVar35,0x2000,2,&stack0x0000095c + lVar20);
            if (iVar15 != 0) {
              LOCK();
              *puVar28 = *puVar28 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar28 = *puVar28 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar35 = *(longlong *)(&stack0x000005a8 + lVar20);
      uVar7 = *(undefined4 *)(&stack0x00000088 + lVar20);
      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107307;
      func_0x(lVar35 + 0x98,uVar7);
      if ((_DAT_ != 0) &&
         ((&stack0x00000211)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107331;
        func_0x(lVar35,0,uVar7);
      }
      *(uint *)((longlong)&uStackX_1c + lVar20) =
           *(uint *)((longlong)&uStackX_1c + lVar20) & 0xffff0000;
      *(undefined8 *)((longlong)&plStackX_10 + lVar20) = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107194;
      func_0x((longlong)&plStackX_10 + lVar20);
    }
    *(undefined **)(&stack0x00001588 + lVar20) = &stack0x00000330 + lVar20;
    *(undefined **)(&stack0x00001590 + lVar20) = &stack0x00000338 + lVar20;
    lVar35 = *(longlong *)(lVar36 + 8);
    puVar30 = (undefined4 *)(lVar35 + 0x3c0);
    *(undefined4 **)(&stack0x00001598 + lVar20) = puVar30;
    *(undefined4 *)(&stack0x00000330 + lVar20) = *puVar30;
    *(undefined2 *)(&stack0x00000334 + lVar20) = *(undefined2 *)(lVar35 + 0x3c4);
    *(undefined2 *)(&stack0x00000336 + lVar20) = 0;
    *(undefined4 *)(&stack0x00000338 + lVar20) = uVar19;
    *(undefined2 *)(&stack0x0000033c + lVar20) = uVar14;
    *(undefined2 *)(&stack0x0000033e + lVar20) = 0;
    UNRECOVERED_JUMPTABLE_00 = *(code **)**(undefined8 **)(&stack0x00000a78 + lVar20);
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1073b6;
    uVar14 = (*UNRECOVERED_JUMPTABLE_00)();
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar20) =
         *(undefined4 *)(*(longlong *)(&stack0x00000780 + lVar20) + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1073e6;
    func_0x(&stack0x00000058 + lVar20,&stack0x00000338 + lVar20,uVar14,
                    &stack0x00000330 + lVar20);
    lVar35 = *(longlong *)(&stack0x00000038 + lVar20);
    param_1 = *(longlong *)(&stack0x000000f0 + lVar20);
    param_3 = *(short **)(&stack0x00000278 + lVar20);
  }
  else {
    (&stack0x00000056)[lVar20] = 1;
    (&stack0xfffffffffffffff8)[lVar20] = 0;
    *(longlong *)(&stack0xfffffffffffffff0 + lVar20) = *(longlong *)(&stack0x00000768 + lVar20);
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar20) = *(undefined8 *)(&stack0x00000778 + lVar20);
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10704f;
    cVar11 = func_0x((longlong)&plStackX_10 + lVar20);
    (&stack0x00000057)[lVar20] = cVar11;
    if (cVar11 != '\0') goto LAB_;
  }
LAB_:
  (&stack0x00000212)[lVar20] = cVar11;
  if (cVar11 == '\0') {
    *(uint *)(param_1 + 0x80) = *(ushort *)(lVar35 + 0x16) - 1;
    piVar34 = *(int **)(&stack0x00000340 + lVar20);
    *piVar34 = *piVar34 + -1;
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107435;
    func_0x(param_1,param_1 + 0x68);
    acStackX_8[lVar20] = '\x01';
    lVar35 = **(longlong **)(param_1 + 8);
    *(longlong *)(&stack0x000015a0 + lVar20) = lVar35;
    uVar39 = *(ulonglong *)(lVar35 + 0x14);
    *(ulonglong *)(&stack0x000015a8 + lVar20) = uVar39;
    lVar35 = *(longlong *)(lVar35 + 8);
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107482;
    func_0x((longlong)&plStackX_10 + lVar20,lVar35 + 0xa0,
                    ((uVar39 >> 0x20 & 0xffff) << 0x20 | uVar39 & 0xffffffff) << 0x10);
    *(undefined4 *)(param_1 + 200) = 2;
    *(uint *)(param_1 + 0xcc) = 2 - (uint)(acStackX_18[lVar20] != '\0');
    goto LAB_;
  }
  lVar36 = **(longlong **)((longlong)&plStackX_10 + lVar20);
  *(longlong *)(&stack0x000015b0 + lVar20) = lVar36;
  if (((*(byte *)(lVar36 + 4) & 1) != 0) || (*(int *)(param_1 + 0x16c) != 0)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10793a;
    func_0x((longlong)&plStackX_10 + lVar20);
    *(uint *)(param_1 + 0x80) = *(ushort *)(lVar35 + 0x16) - 1;
    piVar34 = *(int **)(&stack0x00000340 + lVar20);
    *piVar34 = *piVar34 + -1;
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10795d;
    func_0x(param_1,param_1 + 0x68);
    *(undefined8 *)(&stack0x00001c78 + lVar20) = 0;
    *(undefined **)(&stack0x00001618 + lVar20) = &stack0x00001c80 + lVar20;
    (&stack0x00001c8e)[lVar20] = 1;
    (&stack0x00001c8f)[lVar20] = 0;
    uVar27 = **(undefined8 **)(param_1 + 8);
    uVar10 = (*(undefined8 **)(param_1 + 8))[1];
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1079a5;
    uVar19 = func_0x(&stack0x00001c78 + lVar20,&stack0x00000058 + lVar20,uVar10,uVar27);
    *(undefined4 *)(&stack0x00000970 + lVar20) = uVar19;
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1079b5;
    func_0x(uVar19,0x15);
    *(undefined4 *)(param_1 + 200) = 2;
    *(undefined4 *)(param_1 + 0xcc) = 3;
    acStackX_8[lVar20] = '\x01';
    *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1079da;
    func_0x(&stack0x00001c78 + lVar20);
    goto LAB_;
  }
  plVar31 = (longlong *)(param_1 + 0x68);
  *(longlong **)(&stack0x000005b0 + lVar20) = plVar31;
  if (*plVar31 != 0) {
    puVar22 = (ushort *)(*plVar31 + 0x62);
    *(ushort **)(&stack0x000015b8 + lVar20) = puVar22;
    uVar4 = *puVar22;
    *(ushort *)(&stack0x00000180 + lVar20) = uVar4;
    plVar32 = *(longlong **)(&stack0x000005b0 + lVar20);
    if (((uVar4 & 0x400) == 0) || (*(short *)((longlong)plVar32 + 0xc) < 3)) {
      *(int *)(&stack0x00000090 + lVar20) = (int)*(short *)((longlong)plVar32 + 0xc);
      lVar35 = *plVar32;
      *(longlong *)(&stack0x00000228 + lVar20) = lVar35;
      puVar23 = (undefined2 *)(lVar35 + 0x62);
      *(undefined2 **)(&stack0x000015c0 + lVar20) = puVar23;
      uVar14 = *puVar23;
      *(undefined2 *)(&stack0x00000188 + lVar20) = uVar14;
      if (((byte)uVar14 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x00000090 + lVar20) == 3) {
          *(undefined4 *)(&stack0x00000090 + lVar20) = 4;
        }
        else if (*(int *)(&stack0x00000090 + lVar20) < 2) goto LAB_;
        *(uint **)(&stack0x000015c8 + lVar20) =
             (uint *)(*(longlong *)(&stack0x00000228 + lVar20) + 100);
        uVar17 = *(uint *)(*(longlong *)(&stack0x00000228 + lVar20) + 100);
        *(uint *)(&stack0x00000518 + lVar20) = uVar17;
        if ((((uVar17 & 8) != 0) &&
            (lVar35 = *(longlong *)(*(longlong *)(&stack0x00000228 + lVar20) + 0x90), lVar35 != 0))
           && (*(longlong *)(&stack0x000015d0 + lVar20) = lVar35, *(longlong *)(lVar35 + 0x758) != 0
              )) {
          uVar27 = *(undefined8 *)(lVar35 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1075db;
          func_0x
                    (uVar27,*(undefined8 *)(&stack0x00000228 + lVar20),
                     *(undefined4 *)(&stack0x00000090 + lVar20));
        }
      }
LAB_:
      (&stack0x00000213)[lVar20] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar28 = (uint *)(*(longlong *)(&stack0x00000228 + lVar20) + 100);
        *(uint **)(&stack0x000015d8 + lVar20) = puVar28;
        uVar17 = *puVar28;
        *(uint *)(&stack0x00000520 + lVar20) = uVar17;
        if (((uVar17 & 8) != 0) && (2 < *(int *)(&stack0x00000090 + lVar20))) {
          *(uint **)(&stack0x000015e0 + lVar20) = puVar28;
          uVar17 = *puVar28;
          *(uint *)(&stack0x00000528 + lVar20) = uVar17;
          if (((uVar17 & 0xc0000000) != 0x40000000) &&
             (lVar35 = **(longlong **)(&stack0x00000228 + lVar20), lVar35 != 0)) {
            *(undefined4 *)(&stack0x00000960 + lVar20) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10766a;
            iVar15 = (*_DAT_)(lVar35,0x2000,2,&stack0x00000964 + lVar20);
            if (iVar15 != 0) {
              LOCK();
              *puVar28 = *puVar28 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar28 = *puVar28 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar35 = *(longlong *)(&stack0x00000228 + lVar20);
      uVar19 = *(undefined4 *)(&stack0x00000090 + lVar20);
      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10769b;
      func_0x(lVar35 + 0x98,uVar19);
      if ((_DAT_ != 0) &&
         ((&stack0x00000100)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1076c5;
        func_0x(lVar35,0,uVar19);
      }
      *(uint *)((longlong)plVar32 + 0xc) = *(uint *)((longlong)plVar32 + 0xc) & 0xffff0000;
      **(undefined8 **)(&stack0x000005b0 + lVar20) = 0;
      param_1 = *(longlong *)(&stack0x000000f0 + lVar20);
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x107518;
      func_0x(plVar32);
    }
  }
  *(longlong **)(&stack0x000005b8 + lVar20) = plVar31;
  if (*plVar31 != 0) {
    puVar22 = (ushort *)(*plVar31 + 0x62);
    *(ushort **)(&stack0x000015e8 + lVar20) = puVar22;
    uVar4 = *puVar22;
    *(ushort *)(&stack0x00000190 + lVar20) = uVar4;
    plVar31 = *(longlong **)(&stack0x000005b8 + lVar20);
    if (((uVar4 & 0x400) == 0) || (*(short *)((longlong)plVar31 + 0xc) < 3)) {
      *(int *)(&stack0x00000098 + lVar20) = (int)*(short *)((longlong)plVar31 + 0xc);
      lVar35 = *plVar31;
      *(longlong *)(&stack0x00000248 + lVar20) = lVar35;
      puVar23 = (undefined2 *)(lVar35 + 0x62);
      *(undefined2 **)(&stack0x000015f0 + lVar20) = puVar23;
      uVar14 = *puVar23;
      *(undefined2 *)(&stack0x00000198 + lVar20) = uVar14;
      if (((byte)uVar14 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x00000098 + lVar20) == 3) {
          *(undefined4 *)(&stack0x00000098 + lVar20) = 4;
        }
        else if (*(int *)(&stack0x00000098 + lVar20) < 2) goto LAB_;
        *(uint **)(&stack0x000015f8 + lVar20) =
             (uint *)(*(longlong *)(&stack0x00000248 + lVar20) + 100);
        uVar17 = *(uint *)(*(longlong *)(&stack0x00000248 + lVar20) + 100);
        *(uint *)(&stack0x00000530 + lVar20) = uVar17;
        if ((((uVar17 & 8) != 0) &&
            (lVar35 = *(longlong *)(*(longlong *)(&stack0x00000248 + lVar20) + 0x90), lVar35 != 0))
           && (*(longlong *)(&stack0x00001600 + lVar20) = lVar35, *(longlong *)(lVar35 + 0x758) != 0
              )) {
          uVar27 = *(undefined8 *)(lVar35 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1077ee;
          func_0x
                    (uVar27,*(undefined8 *)(&stack0x00000248 + lVar20),
                     *(undefined4 *)(&stack0x00000098 + lVar20));
        }
      }
LAB_:
      (&stack0x00000101)[lVar20] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar28 = (uint *)(*(longlong *)(&stack0x00000248 + lVar20) + 100);
        *(uint **)(&stack0x00001608 + lVar20) = puVar28;
        uVar17 = *puVar28;
        *(uint *)(&stack0x00000538 + lVar20) = uVar17;
        if (((uVar17 & 8) != 0) && (2 < *(int *)(&stack0x00000098 + lVar20))) {
          *(uint **)(&stack0x00001610 + lVar20) = puVar28;
          uVar17 = *puVar28;
          *(uint *)(&stack0x00000540 + lVar20) = uVar17;
          if (((uVar17 & 0xc0000000) != 0x40000000) &&
             (lVar35 = **(longlong **)(&stack0x00000248 + lVar20), lVar35 != 0)) {
            *(undefined4 *)(&stack0x00000968 + lVar20) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10787d;
            iVar15 = (*_DAT_)(lVar35,0x2000,2,&stack0x0000096c + lVar20);
            if (iVar15 != 0) {
              LOCK();
              *puVar28 = *puVar28 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar28 = *puVar28 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar35 = *(longlong *)(&stack0x00000248 + lVar20);
      uVar19 = *(undefined4 *)(&stack0x00000098 + lVar20);
      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1078ac;
      func_0x(lVar35 + 0x98,uVar19);
      if ((_DAT_ != 0) &&
         ((&stack0x00000102)[lVar20] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x1078d6;
        func_0x(lVar35,0,uVar19);
      }
      *(uint *)((longlong)plVar31 + 0xc) = *(uint *)((longlong)plVar31 + 0xc) & 0xffff0000;
      plVar31 = *(longlong **)(&stack0x000005b8 + lVar20);
      *plVar31 = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar20) = 0x10772b;
      func_0x(plVar31);
    }
  }
  *plVar31 = *(longlong *)((longlong)&plStackX_10 + lVar20);
  *(uint *)((longlong)plVar31 + 0xc) =
       *(uint *)((longlong)plVar31 + 0xc) & 0xffff0000 |
       (uint)*(ushort *)((longlong)&uStackX_1c + lVar20);
  *(undefined8 *)((longlong)&plStackX_10 + lVar20) = 0;
  *(uint *)((longlong)&uStackX_1c + lVar20) = *(uint *)((longlong)&uStackX_1c + lVar20) & 0xffff0000
  ;
  *(undefined4 *)(param_1 + 0x80) = 0;
  *(int *)(&stack0x00000208 + lVar20) = *(int *)(&stack0x00000208 + lVar20) + 1;
  *(undefined4 *)(&stack0x000000d8 + lVar20) = 0;
  goto LAB_;
}

