
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  longlong unaff_GS_OFFSET;
  bool bVar3;
  
  if ((uint)param_2[1] < 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 0x48) == 0) {
    LOCK();
    bVar3 = *(ulonglong *)(param_1 + 0x48) == 0;
    if (bVar3) {
      *(ulonglong *)(param_1 + 0x48) = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
    }
    UNLOCK();
    if (bVar3) {
      *(int *)(param_1 + 0x30) = *(int *)(param_1 + 0x30) + -1;
      if (*(int *)(param_1 + 0x30) < 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*_DAT_ != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(undefined8 *)(param_1 + 0x48) = 0;
      if (*param_2 == 1) {
        if ((uint)param_2[1] < 2) {
          return;
        }
        iVar2 = param_2[1];
      }
      else {
        iVar2 = param_2[1];
        if (iVar2 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
      }
      if (iVar2 == 2) {
        if (*(int *)(param_1 + 0x48) == 0) {
          LOCK();
          bVar3 = *(ulonglong *)(param_1 + 0x48) == 0;
          if (bVar3) {
            *(ulonglong *)(param_1 + 0x48) = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
          }
          UNLOCK();
          if (bVar3) {
            piVar1 = (int *)(param_1 + 0x38);
            *piVar1 = *piVar1 + -1;
            if (*piVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            if (*_DAT_ != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            *(undefined8 *)(param_1 + 0x48) = 0;
            goto LAB_;
          }
        }
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
LAB_:
      if (param_3 == 0) {
        iVar2 = 0;
        if (param_2[5] + 1 !=
            *(int *)(*(longlong *)(param_1 + 0x18) + 0x5c) +
            *(int *)(*(longlong *)(param_1 + 0x18) + 0x58)) {
          iVar2 = param_2[5] + 1;
        }
        param_2[0xb] = 4;
        *(undefined *)(param_2 + 0xc) = 1;
        **(int **)(param_2 + 0xe) = iVar2;
        param_2[0x10] = 1;
        func_0x(param_1 + 0x50,param_1 + 0x48,param_2,0x200011b);
        param_2[0xb] = 0;
      }
      return;
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

