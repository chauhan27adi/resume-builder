
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_(longlong param_1,longlong param_2)

{
  undefined8 *puVar1;
  byte bVar2;
  longlong lVar3;
  longlong lVar4;
  undefined8 uVar5;
  undefined auVar6 [16];
  undefined auVar7 [16];
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  uint uVar15;
  uint uVar16;
  longlong lVar17;
  undefined8 uVar18;
  undefined8 *puVar19;
  undefined8 *puVar20;
  undefined4 *puVar21;
  undefined4 *puVar22;
  ushort *puVar23;
  undefined4 *puVar24;
  uint uVar25;
  ulonglong uVar26;
  undefined4 *puVar27;
  uint uVar28;
  ulonglong uVar29;
  uint uVar30;
  int iVar31;
  longlong *plVar32;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_e8;
  undefined8 *puStack_e0;
  longlong lStack_d8;
  ulonglong uStack_d0;
  undefined8 *puStack_c8;
  longlong lStack_c0;
  undefined8 uStack_b8;
  int iStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined8 *puStack_a0;
  undefined4 *puStack_98;
  undefined4 *puStack_90;
  undefined8 uStack_88;
  longlong lStack_80;
  undefined8 uStack_78;
  undefined4 *puStack_70;
  undefined4 *puStack_68;
  undefined4 *apuStack_60 [4];
  
  uStack_88 = 0xfffffffffffffffe;
  if ((*(int *)(*(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)_DAT_ * 8)
               + 4) < _DAT_) &&
     (func_0x(&DAT_), _DAT_ == -1)) {
    _DAT_ = 0x11c;
    _DAT_ = 0x61;
    _DAT_ = 0x100;
    _DAT_ = 0xd9;
    _DAT_ = 0xdb;
    _DAT_ = 0xda;
    _DAT_ = 0xa9;
    _DAT_ = 0x1ae;
    _DAT_ = 0x13c;
    _DAT_ = 0x13d;
    _DAT_ = 0x79;
    _DAT_ = 0x2c6;
    _DAT_ = 0x1d7;
    _DAT_ = 0xab;
    _DAT_ = 0x7b;
    _DAT_ = 299;
    _DAT_ = 0xd5;
    _DAT_ = 0x13b;
    _DAT_ = 0xb8;
    _DAT_ = 0x60;
    _DAT_ = 0xc9;
    _DAT_ = 0x127;
    _DAT_ = 0x10d;
    _DAT_ = 0x132;
    _DAT_ = 0x2bd;
    _DAT_ = 0xd3;
    _DAT_ = 0xd8;
    _DAT_ = 0xe8;
    _DAT_ = 0xd4;
    _DAT_ = 0x108;
    _DAT_ = 0xfe;
    _DAT_ = 0xbd;
    _DAT_ = 0x369;
    _DAT_ = 0x35a;
    _DAT_ = 0x32a;
    _DAT_ = 0x421;
    _DAT_ = 0x448;
    _DAT_ = 0x3dd;
    func_0x(&DAT_);
  }
  lVar3 = *(longlong *)(param_2 + 0x178);
  if (((lVar3 == 0) || ((*(byte *)(lVar3 + 0x410) & 2) == 0)) ||
     (lVar3 = *(longlong *)(lVar3 + 0x498), lVar3 == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar17 = *(longlong *)
            ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            0x100);
  if (lVar17 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lStack_d8 = lVar3;
  lVar17 = (*_DAT_)(0x13890,*(undefined8 *)(lVar17 + 1000),0x2504db8,0x4d8,1);
  lStack_c0 = lVar17;
  lStack_80 = lVar17;
  func_0x(lVar17,0,0x13890);
  uVar15 = (*_DAT_)(**(undefined8 **)(param_2 + 0x60),lVar17);
  puVar27 = (undefined4 *)0x0;
  puVar22 = puVar27;
  if (uVar15 != 0) {
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    *(undefined8 *)(lVar17 + 0x20 + (ulonglong)_DAT_ * 0x30) = 0;
    puStack_e0 = (undefined8 *)0x0;
    if (10 < uVar15) {
      uVar15 = 10;
    }
    lVar4 = *(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             0x100);
    if (lVar4 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uStack_e8 = (ulonglong)uVar15;
    uVar29 = CONCAT44(0,uVar15 + 1);
    auVar6._8_8_ = 0;
    auVar6._0_8_ = uVar29;
    uVar18 = SUB168(ZEXT816(0x10) * auVar6,0);
    if (SUB168(ZEXT816(0x10) * auVar6,8) != 0) {
      uVar18 = 0xffffffffffffffff;
    }
    puVar19 = (undefined8 *)(*_DAT_)(uVar18,*(undefined8 *)(lVar4 + 1000),0x251bbc0,0x2c,1);
    if (puVar19 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    puVar20 = puVar19;
    for (; uVar29 != 0; uVar29 = uVar29 - 1) {
      *puVar20 = 0;
      *(undefined4 *)(puVar20 + 1) = 0;
      puVar20 = puVar20 + 2;
    }
    plVar32 = (longlong *)(lVar3 + 0x20);
    lVar17 = lVar17 - lStack_d8;
    puVar21 = puVar27;
    uVar28 = uStack_e8._4_4_;
    puStack_e0 = puVar19;
    do {
      lVar3 = *(longlong *)(lVar17 + (longlong)plVar32);
      iVar31 = (int)puVar21;
      if ((lVar3 != 0) && (lVar3 != *plVar32)) {
        uVar29 = *(ulonglong *)(lVar17 + -0x20 + (longlong)plVar32);
        puVar21 = (undefined4 *)(uVar29 - plVar32[-4]);
        if (uVar29 < (ulonglong)plVar32[-4]) {
          puVar21 = puVar27;
        }
        if (puVar21 == (undefined4 *)0xffffffffffffffff) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (*_DAT_ == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        puVar21 = (undefined4 *)((ulonglong)((longlong)puVar21 * 1000) / *_DAT_);
        if (puVar21 != (undefined4 *)0x0) {
          uStack_b8 = puVar21;
          iStack_b0 = iVar31;
          if (uVar28 < uVar15) {
            uVar28 = uVar28 + 1;
            uStack_e8 = CONCAT44(uVar28,(undefined4)uStack_e8);
            puVar20 = puVar19 + (ulonglong)uVar28 * 2;
            *puVar20 = puVar21;
            *(int *)(puVar20 + 1) = iVar31;
            *(undefined4 *)((longlong)puVar20 + 0xc) = uStack_ac;
            for (uVar25 = uVar28; 1 < uVar25; uVar25 = uVar25 >> 1) {
              uVar26 = (ulonglong)uVar25;
              uVar29 = uVar26 & 0xfffffffffffffffe;
              if ((ulonglong)puVar19[uVar29] <= (ulonglong)puVar19[uVar26 * 2]) break;
              puVar20 = puVar19 + uVar29;
              uVar11 = *(undefined4 *)puVar20;
              uVar12 = *(undefined4 *)((longlong)puVar20 + 4);
              uVar13 = *(undefined4 *)(puVar20 + 1);
              uVar14 = *(undefined4 *)((longlong)puVar20 + 0xc);
              puVar20 = puVar19 + uVar26 * 2;
              uVar8 = *(undefined4 *)((longlong)puVar20 + 4);
              uVar9 = *(undefined4 *)(puVar20 + 1);
              uVar10 = *(undefined4 *)((longlong)puVar20 + 0xc);
              puVar1 = puVar19 + uVar29;
              *(undefined4 *)puVar1 = *(undefined4 *)puVar20;
              *(undefined4 *)((longlong)puVar1 + 4) = uVar8;
              *(undefined4 *)(puVar1 + 1) = uVar9;
              *(undefined4 *)((longlong)puVar1 + 0xc) = uVar10;
              puVar20 = puVar19 + uVar26 * 2;
              *(undefined4 *)puVar20 = uVar11;
              *(undefined4 *)((longlong)puVar20 + 4) = uVar12;
              *(undefined4 *)(puVar20 + 1) = uVar13;
              *(undefined4 *)((longlong)puVar20 + 0xc) = uVar14;
            }
          }
          else {
            if (uVar28 == 0) {
              (*_DAT_)(1,0x290c1d8,0x290c1b8,0x91,0);
            }
            if ((undefined4 *)puVar19[2] < puVar21) {
              if (uVar28 != 0) {
                puVar20 = puVar19 + (ulonglong)uVar28 * 2;
                uVar8 = *(undefined4 *)((longlong)puVar20 + 4);
                uVar9 = *(undefined4 *)(puVar20 + 1);
                uVar10 = *(undefined4 *)((longlong)puVar20 + 0xc);
                *(undefined4 *)(puVar19 + 2) = *(undefined4 *)puVar20;
                *(undefined4 *)((longlong)puVar19 + 0x14) = uVar8;
                *(undefined4 *)(puVar19 + 3) = uVar9;
                *(undefined4 *)((longlong)puVar19 + 0x1c) = uVar10;
                uVar28 = uVar28 - 1;
                uStack_e8 = CONCAT44(uVar28,(undefined4)uStack_e8);
                uVar25 = 1;
                if (1 < uVar28) {
                  do {
                    uVar30 = uVar25 * 2;
                    uVar16 = uVar25;
                    if ((uVar30 <= uVar28) &&
                       ((ulonglong)puVar19[(ulonglong)uVar30 * 2] <
                        (ulonglong)puVar19[(ulonglong)uVar25 * 2])) {
                      uVar16 = uVar30;
                    }
                    uVar30 = uVar30 + 1;
                    if ((uVar30 <= uVar28) &&
                       ((ulonglong)puVar19[(ulonglong)uVar30 * 2] <
                        (ulonglong)puVar19[(ulonglong)uVar16 * 2])) {
                      uVar16 = uVar30;
                    }
                    if (uVar16 == uVar25) break;
                    puVar20 = puVar19 + (ulonglong)uVar25 * 2;
                    uVar11 = *(undefined4 *)puVar20;
                    uVar12 = *(undefined4 *)((longlong)puVar20 + 4);
                    uVar13 = *(undefined4 *)(puVar20 + 1);
                    uVar14 = *(undefined4 *)((longlong)puVar20 + 0xc);
                    puVar20 = puVar19 + (ulonglong)uVar16 * 2;
                    uVar8 = *(undefined4 *)((longlong)puVar20 + 4);
                    uVar9 = *(undefined4 *)(puVar20 + 1);
                    uVar10 = *(undefined4 *)((longlong)puVar20 + 0xc);
                    puVar1 = puVar19 + (ulonglong)uVar25 * 2;
                    *(undefined4 *)puVar1 = *(undefined4 *)puVar20;
                    *(undefined4 *)((longlong)puVar1 + 4) = uVar8;
                    *(undefined4 *)(puVar1 + 1) = uVar9;
                    *(undefined4 *)((longlong)puVar1 + 0xc) = uVar10;
                    puVar20 = puVar19 + (ulonglong)uVar16 * 2;
                    *(undefined4 *)puVar20 = uVar11;
                    *(undefined4 *)((longlong)puVar20 + 4) = uVar12;
                    *(undefined4 *)(puVar20 + 1) = uVar13;
                    *(undefined4 *)((longlong)puVar20 + 0xc) = uVar14;
                    uVar25 = uVar16;
                  } while (uVar16 < uVar28);
                }
              }
              if (uVar28 < uVar15) {
                uVar28 = uVar28 + 1;
                uStack_e8 = CONCAT44(uVar28,(undefined4)uStack_e8);
                puVar20 = puVar19 + (ulonglong)uVar28 * 2;
                *(undefined4 *)puVar20 = (undefined4)uStack_b8;
                *(undefined4 *)((longlong)puVar20 + 4) = uStack_b8._4_4_;
                *(int *)(puVar20 + 1) = iStack_b0;
                *(undefined4 *)((longlong)puVar20 + 0xc) = uStack_ac;
                for (uVar25 = uVar28; 1 < uVar25; uVar25 = uVar25 >> 1) {
                  uVar26 = (ulonglong)uVar25;
                  uVar29 = uVar26 & 0xfffffffffffffffe;
                  if ((ulonglong)puVar19[uVar29] <= (ulonglong)puVar19[uVar26 * 2]) break;
                  puVar20 = puVar19 + uVar29;
                  uVar11 = *(undefined4 *)puVar20;
                  uVar12 = *(undefined4 *)((longlong)puVar20 + 4);
                  uVar13 = *(undefined4 *)(puVar20 + 1);
                  uVar14 = *(undefined4 *)((longlong)puVar20 + 0xc);
                  puVar20 = puVar19 + uVar26 * 2;
                  uVar8 = *(undefined4 *)((longlong)puVar20 + 4);
                  uVar9 = *(undefined4 *)(puVar20 + 1);
                  uVar10 = *(undefined4 *)((longlong)puVar20 + 0xc);
                  puVar1 = puVar19 + uVar29;
                  *(undefined4 *)puVar1 = *(undefined4 *)puVar20;
                  *(undefined4 *)((longlong)puVar1 + 4) = uVar8;
                  *(undefined4 *)(puVar1 + 1) = uVar9;
                  *(undefined4 *)((longlong)puVar1 + 0xc) = uVar10;
                  puVar20 = puVar19 + uVar26 * 2;
                  *(undefined4 *)puVar20 = uVar11;
                  *(undefined4 *)((longlong)puVar20 + 4) = uVar12;
                  *(undefined4 *)(puVar20 + 1) = uVar13;
                  *(undefined4 *)((longlong)puVar20 + 0xc) = uVar14;
                }
              }
            }
          }
        }
      }
      puVar21 = (undefined4 *)(ulonglong)(iVar31 + 1U);
      plVar32 = plVar32 + 6;
    } while (iVar31 + 1U < 0x682);
    if (uVar28 != 0) {
      puStack_a0 = (undefined8 *)0x0;
      lVar3 = *(longlong *)
               ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
               + 0x100);
      if (lVar3 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar15 = uStack_e8._4_4_;
      uVar29 = CONCAT44(0,uStack_e8._4_4_);
      auVar7._8_8_ = 0;
      auVar7._0_8_ = uVar29;
      uVar18 = SUB168(ZEXT816(0x10) * auVar7,0);
      if (SUB168(ZEXT816(0x10) * auVar7,8) != 0) {
        uVar18 = 0xffffffffffffffff;
      }
      uStack_d0 = uVar29;
      puVar19 = (undefined8 *)
                (*_DAT_)(uVar18,*(undefined8 *)(lVar3 + 1000),0x251bbc0,0x43,1);
      if (puVar19 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      puVar20 = puVar19;
      if (uVar15 != 0) {
        do {
          *puVar20 = 0;
          *(undefined4 *)(puVar20 + 1) = 0;
          puVar20 = puVar20 + 2;
          uVar29 = uVar29 - 1;
        } while (uVar29 != 0);
      }
      puStack_c8 = puVar19;
      puStack_a0 = puVar19;
      if (uVar15 != 0) {
        do {
          puVar21 = (undefined4 *)func_0x(&uStack_e8,apuStack_60);
          uVar8 = puVar21[1];
          uVar9 = puVar21[2];
          uVar10 = puVar21[3];
          puVar20 = puVar19 + (ulonglong)((uVar15 - (int)puVar22) - 1) * 2;
          *(undefined4 *)puVar20 = *puVar21;
          *(undefined4 *)((longlong)puVar20 + 4) = uVar8;
          *(undefined4 *)(puVar20 + 1) = uVar9;
          *(undefined4 *)((longlong)puVar20 + 0xc) = uVar10;
          uVar28 = (int)puVar22 + 1;
          puVar22 = (undefined4 *)(ulonglong)uVar28;
        } while (uVar28 < uVar15);
      }
      uVar18 = *(undefined8 *)(param_1 + 0x18);
      uStack_78 = uVar18;
      puVar22 = (undefined4 *)(*_DAT_)(0x90,uVar18,0x2504db8,0x537,1);
      if (puVar22 == (undefined4 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *puVar22 = 0x1c8;
      *(undefined2 *)(puVar22 + 1) = 0x101;
      *(undefined8 *)(puVar22 + 2) = 0;
      *(undefined8 *)(puVar22 + 4) = *(undefined8 *)(param_1 + 0x18);
      puVar22[6] = 0;
      *(undefined8 *)(puVar22 + 0x20) = 0;
      *(undefined8 *)(puVar22 + 0x22) = 0;
      puStack_90 = puVar22;
      if (uVar15 != 0) {
        do {
          lVar3 = *(longlong *)(lStack_c0 + 0x20 + (ulonglong)*(uint *)(puVar19 + 1) * 0x30);
          lVar17 = *(longlong *)(lStack_d8 + 0x20 + (ulonglong)*(uint *)(puVar19 + 1) * 0x30);
          puVar23 = (ushort *)(*_DAT_)();
          puVar21 = (undefined4 *)(*_DAT_)(0x90,uVar18,0x2504db8,0x53e,1);
          if (puVar21 == (undefined4 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *puVar21 = 0x177;
          *(undefined2 *)(puVar21 + 1) = 0x101;
          *(undefined8 *)(puVar21 + 2) = 0;
          *(undefined8 *)(puVar21 + 4) = *(undefined8 *)(param_1 + 0x18);
          puVar21[6] = 0;
          *(undefined8 *)(puVar21 + 0x20) = 0;
          *(undefined8 *)(puVar21 + 0x22) = 0;
          puStack_98 = puVar21;
          puStack_70 = puVar21;
          puStack_68 = (undefined4 *)(*_DAT_)(0x18,uVar18,0x2504db8,0x53f,1);
          if (puStack_68 == (undefined4 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *puStack_68 = 0x178;
          uVar29 = 0xffffffffffffffff;
          do {
            uVar29 = uVar29 + 1;
          } while (puVar23[uVar29] != 0);
          bVar2 = *(byte *)(puStack_68 + 5);
          *(ushort **)(puStack_68 + 2) = puVar23;
          puStack_68[4] = (uint)uVar29 * 2;
          *(byte *)(puStack_68 + 5) = bVar2 & 0xfc | 1;
          uVar28 = (uint)uVar29 & 0x7fffffff;
          puVar24 = puVar27;
          uVar15 = 0;
          if ((uVar29 & 0x7fffffff) != 0) {
            do {
              uVar15 = (uint)puVar24;
              if ((*puVar23 & 0xff00) != 0) break;
              uVar15 = uVar15 + 1;
              puVar23 = puVar23 + 1;
              puVar24 = (undefined4 *)(ulonglong)uVar15;
            } while (uVar15 < uVar28);
          }
          if (uVar28 <= uVar15) {
            *(byte *)(puStack_68 + 5) = bVar2 & 0xfc | 3;
          }
          func_0x(puVar21);
          apuStack_60[0] = (undefined4 *)(*_DAT_)(0x18,uVar18,0x2504db8,0x540,1);
          if (apuStack_60[0] == (undefined4 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          uVar5 = *puVar19;
          *apuStack_60[0] = 0x1c6;
          *(undefined8 *)(apuStack_60[0] + 2) = uVar5;
          func_0x(puVar21);
          uStack_a8 = 0x541;
          uStack_b8 = (undefined4 *)(*_DAT_)(0x18,uVar18,0x2504db8,0x541,1);
          if (uStack_b8 == (undefined4 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *uStack_b8 = 0x1c7;
          *(longlong *)(uStack_b8 + 2) = lVar3 - lVar17;
          func_0x(puVar21,uStack_b8);
          puStack_98 = (undefined4 *)0x0;
          func_0x(puVar22,puVar21);
          (*_DAT_)(0,0x90);
          puVar19 = puVar19 + 2;
          uStack_d0 = uStack_d0 - 1;
        } while (uStack_d0 != 0);
        uStack_d0 = 0;
        puVar19 = puStack_c8;
      }
      puStack_90 = (undefined4 *)0x0;
      (*_DAT_)(0,0x90);
      (*_DAT_)(puVar19);
      puVar19 = puStack_e0;
    }
    (*_DAT_)(puVar19);
    lVar17 = lStack_c0;
  }
  (*_DAT_)(lVar17);
  return puVar22;
}

