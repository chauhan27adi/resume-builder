
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  int *piVar1;
  byte bVar2;
  undefined2 uVar3;
  longlong lVar4;
  char cVar5;
  int iVar6;
  uint uVar7;
  longlong lVar8;
  undefined8 *puVar9;
  longlong lVar10;
  uint uVar11;
  byte *pbVar12;
  longlong lVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  longlong unaff_GS_OFFSET;
  undefined auStack_148 [32];
  undefined8 uStack_128;
  longlong lStack_120;
  undefined4 uStack_118;
  int iStack_114;
  uint uStack_110;
  int iStack_10c;
  int iStack_108;
  int iStack_104;
  longlong lStack_100;
  int iStack_f8;
  undefined8 uStack_f0;
  undefined2 uStack_e8;
  undefined2 uStack_e6;
  undefined8 uStack_e0;
  undefined2 uStack_d8;
  undefined2 uStack_d6;
  longlong lStack_d0;
  undefined8 uStack_c8;
  longlong lStack_b8;
  undefined2 uStack_b0;
  undefined8 uStack_a8;
  int iStack_a0;
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  longlong lStack_58;
  uint uStack_50;
  undefined8 *puStack_48;
  undefined8 uStack_40;
  ulonglong uStack_38;
  
  uStack_c8 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_148;
  uVar3 = *(undefined2 *)(param_1 + 1);
  uVar14 = 0;
  if ((DAT_ & 8) == 0) {
    iStack_f8 = 0;
  }
  else {
    iStack_f8 = 1;
    iStack_108 = (*_DAT_)();
    iStack_104 = 0x22;
    lStack_100 = func_0x(uVar3);
  }
  lVar10 = *(longlong *)
            ((ulonglong)*_DAT_ + 8 +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
  lVar13 = *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
           (ulonglong)*_DAT_;
  lVar8 = *(longlong *)(lVar13 + 0x100);
  if (lVar8 == 0) {
    (*_DAT_)(0);
    lVar8 = *(longlong *)(lVar13 + 0x100);
  }
  lStack_d0 = *(longlong *)(lVar8 + 600);
  iStack_114 = 0;
  uStack_110 = 0;
  lVar8 = *(longlong *)(param_1[0xe] + 8);
  if ((lVar10 == 0) || (lStack_d0 == 0)) {
    uStack_128 = (undefined8 *)0x0;
    (*_DAT_)(1,0x1c3e648,0x1c18c40);
  }
  iStack_10c = func_0x(*(undefined2 *)(param_1 + 1),0x1a86278);
  if ((((iStack_10c == 0) && ((*(uint *)(*param_1 + 0x18) & 2) == 0)) &&
      (*(int *)(*(longlong *)(param_1[0xe] + 8) + 0x348) < 1)) &&
     ((*(uint *)(*param_1 + 0x18) & 4) == 0)) {
    func_0x(0x4977,0x10,2);
  }
  iVar6 = func_0x(*(undefined2 *)(param_1 + 1),0x1a89e40);
  if (iVar6 == 0) {
    if ((((*(uint *)(*param_1 + 0x18) & 2) == 0) &&
        (*(int *)(*(longlong *)(param_1[0xe] + 8) + 0x348) < 1)) &&
       ((*(uint *)(*param_1 + 0x18) & 4) == 0)) {
      func_0x(0x4977,0x10,2,0x1a89e40);
    }
  }
  else {
    uStack_a8 = (**(code **)(**(longlong **)
                               (*(longlong *)
                                 ((ulonglong)*_DAT_ +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8)) + 0x90) + 0x1b0))();
    uStack_b0 = *(undefined2 *)(param_1 + 1);
    lStack_b8 = 0;
    auStack_98 = ZEXT816(0);
    auStack_88 = ZEXT816(0);
    auStack_78 = ZEXT816(0);
    auStack_68 = ZEXT816(0);
    lStack_58 = 0;
    uStack_50 = 0;
    puStack_48 = (undefined8 *)0x0;
    uStack_40 = 0;
    iStack_a0 = iVar6;
    iVar6 = func_0x(&lStack_b8,3,1);
    if (iVar6 == 0) {
      if (((*(byte *)(*param_1 + 0x18) & 2) == 0) &&
         (*(int *)(*(longlong *)(param_1[0xe] + 8) + 0x348) < 1)) {
        func_0x(0x49aa,0x10,10,0x1a89e40);
      }
    }
    else {
      lStack_120 = lStack_b8;
      uStack_128 = puStack_48;
      iVar6 = (**(code **)(*(longlong *)auStack_98._8_8_ + 0x18))(auStack_98._8_8_,0,1);
      uVar15 = uVar14;
      if (iVar6 == 0) {
        do {
          uStack_118 = 0;
          if (((lStack_b8 == 0) || (lStack_58 == 0)) || (uStack_50 == 0)) {
            lVar10 = 0;
          }
          else {
            uVar7 = func_0x(&lStack_b8,0x1825ea8,&uStack_118);
            lVar10 = 0;
            if (((lStack_58 != 0) && (uVar7 - 1 < 0xfffffffe)) && (uVar11 = 0, uStack_50 != 0)) {
              do {
                if (*(ulonglong *)((ulonglong)uVar11 * 0x58 + lStack_58) == (ulonglong)uVar7) {
                  lVar10 = (ulonglong)uVar11 * 0x58 + lStack_58;
                  if (lVar10 != 0) goto LAB_;
                  break;
                }
                uVar11 = uVar11 + 1;
                lVar10 = 0;
              } while (uVar11 < uStack_50);
            }
            uStack_128 = (undefined8 *)CONCAT44(uStack_128._4_4_,iStack_a0);
            (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
            uVar14 = *(ulonglong *)(lStack_b8 + *(longlong *)(lVar10 + 0x10));
            lVar10 = *(longlong *)(lVar10 + 8) + lStack_b8;
            uVar15 = (ulonglong)uStack_110;
          }
          uVar7 = uStack_50;
          lVar4 = lStack_58;
          lVar13 = lStack_b8;
          if (uVar14 < 5) {
            func_0x(&iStack_114,lVar10,uVar14);
          }
          if (iStack_114 == *(int *)param_1[0xe]) {
            uStack_118 = 0;
            if (((lVar13 == 0) || (lVar4 == 0)) || (uVar7 == 0)) {
              pbVar12 = (byte *)0x0;
            }
            else {
              uVar7 = func_0x(&lStack_b8,0x1824f30,&uStack_118);
              lVar10 = 0;
              if (((lStack_58 != 0) && (uVar7 - 1 < 0xfffffffe)) && (uVar11 = 0, uStack_50 != 0)) {
                do {
                  if (*(ulonglong *)((ulonglong)uVar11 * 0x58 + lStack_58) == (ulonglong)uVar7) {
                    lVar10 = (ulonglong)uVar11 * 0x58 + lStack_58;
                    if (lVar10 != 0) goto LAB_;
                    break;
                  }
                  uVar11 = uVar11 + 1;
                  lVar10 = 0;
                } while (uVar11 < uStack_50);
              }
              uStack_128 = (undefined8 *)CONCAT44(uStack_128._4_4_,iStack_a0);
              (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
              uVar14 = *(ulonglong *)(lStack_b8 + *(longlong *)(lVar10 + 0x10));
              pbVar12 = (byte *)(*(longlong *)(lVar10 + 8) + lStack_b8);
            }
            bVar2 = *pbVar12;
            if (((*(uint *)(lStack_d0 + 0xbc) & 4) != 0) &&
               ((iVar6 = func_0x(), iVar6 != 0 ||
                (((lVar10 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              )), lVar10 != 0 &&
                  (*(char *)(*(longlong *)(lVar10 + 0x38) + 8) != '\0')) &&
                 (iVar6 = func_0x(), iVar6 == 0)))))) {
              func_0x(&lStack_b8);
              goto LAB_;
            }
            lVar13 = lStack_b8;
            if ((bVar2 & 1) != 0) {
              puVar9 = (undefined8 *)func_0x(param_1);
              param_1[0x10] = (longlong)puVar9;
              if (puVar9 == (undefined8 *)0x0) {
                uStack_128 = puVar9;
                (*_DAT_)(1,0x1c3e8d8,0x1c18c40,0xb11);
              }
              func_0x(param_1,&lStack_b8,iStack_10c);
              *(undefined8 *)(param_1[0x10] + 0x708) = *(undefined8 *)(param_1[0xe] + 8);
              func_0x(param_1);
              uVar15 = 1;
              uStack_110 = 1;
              lVar13 = lStack_b8;
            }
          }
          uStack_128 = puStack_48;
          lStack_120 = lVar13;
          iVar6 = (**(code **)(*(longlong *)auStack_98._8_8_ + 0x18))(auStack_98._8_8_,0,1);
        } while (iVar6 == 0);
        if ((((int)uVar15 != 0) && (lVar8 != 0)) && (*(int *)(lVar8 + 0x338) == 0)) {
          uStack_128 = (undefined8 *)CONCAT44(uStack_128._4_4_,*(undefined4 *)(lVar8 + 8));
          (*_DAT_)(0xbb,0x38,0x10,3);
        }
      }
    }
    func_0x(&lStack_b8);
  }
  if (((*(byte *)(*param_1 + 0x18) & 2) != 0) && (0 < *(int *)(lVar8 + 0x348))) {
    lVar10 = func_0x(param_1);
    param_1[0x10] = lVar10;
    if (lVar10 == 0) {
      uStack_128 = (undefined8 *)0x0;
      (*_DAT_)(1,0x1c3e8d8,0x1c18c40,0xb37);
      lVar10 = param_1[0x10];
    }
    *(longlong *)(lVar10 + 0x708) = lVar8;
    uStack_f0 = *(undefined8 *)(lVar8 + 0x554);
    uStack_e8 = *(undefined2 *)(lVar8 + 0x55c);
    uStack_e6 = *(undefined2 *)(lVar8 + 0x55e);
    uStack_128 = &uStack_f0;
    func_0x(param_1,*(undefined4 *)(lVar8 + 0x348),0,lVar8 + 0x350);
    func_0x(param_1);
    if (0 < *(int *)(lVar8 + 0x34c)) {
      lVar10 = func_0x(param_1);
      param_1[0x10] = lVar10;
      if (lVar10 == 0) {
        uStack_128 = (undefined8 *)0x0;
        (*_DAT_)(1,0x1c3e8d8,0x1c18c40,0xb45);
        lVar10 = param_1[0x10];
      }
      *(longlong *)(lVar10 + 0x708) = lVar8;
      uStack_e0 = *(undefined8 *)(lVar8 + 0x560);
      uStack_d8 = *(undefined2 *)(lVar8 + 0x568);
      uStack_d6 = *(undefined2 *)(lVar8 + 0x56a);
      uStack_128 = &uStack_e0;
      func_0x(param_1,*(undefined4 *)(lVar8 + 0x34c),2,lVar8 + 0x452);
      func_0x(param_1);
    }
  }
  if ((*(byte *)(*param_1 + 0x18) & 4) != 0) {
    lVar10 = func_0x(param_1);
    param_1[0x10] = lVar10;
    if (lVar10 == 0) {
      (*_DAT_)(0xe3,0x1a,0x11,0xc);
      lVar10 = param_1[0x10];
    }
    *(longlong *)(lVar10 + 0x708) = lVar8;
    cVar5 = func_0x(param_1);
    if (cVar5 != '\0') {
      func_0x(param_1);
    }
  }
LAB_:
  lVar10 = lStack_100;
  if ((iStack_f8 != 0) && (lStack_100 != 0)) {
    iVar6 = (*_DAT_)();
    piVar1 = (int *)(lVar10 + 8 + (longlong)iStack_104 * 4);
    *piVar1 = *piVar1 + (iVar6 - iStack_108);
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_148);
  return;
}

