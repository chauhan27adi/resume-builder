
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined param_2,longlong param_3,undefined8 *param_4,
                 int param_5,undefined8 param_6)

{
  longlong *plVar1;
  ushort *puVar2;
  longlong lVar3;
  undefined *puVar4;
  char cVar5;
  byte bVar6;
  int iVar7;
  ulonglong uVar8;
  longlong lVar9;
  undefined8 uVar10;
  ulonglong *puVar11;
  ushort uVar12;
  ulonglong uVar13;
  ulonglong uVar14;
  ushort uVar15;
  ulonglong uVar16;
  int iVar17;
  uint uVar18;
  uint uVar19;
  ulonglong uVar20;
  uint uVar21;
  byte *pbVar22;
  byte *pbVar23;
  ushort *puVar24;
  byte *pbVar25;
  undefined auStack_d58 [32];
  undefined8 uStack_d38;
  short sStack_d28;
  ushort uStack_d26;
  uint uStack_d24;
  byte *pbStack_d20;
  undefined8 uStack_d18;
  uint uStack_d10;
  ushort uStack_d0c;
  byte *pbStack_d0a;
  undefined2 uStack_d02;
  undefined2 uStack_d00;
  ushort uStack_cfe;
  ushort uStack_cfc;
  undefined2 uStack_cfa;
  undefined8 *puStack_cf0;
  undefined auStack_ce8 [16];
  undefined8 uStack_cd8;
  int iStack_cd0;
  undefined8 uStack_cc8;
  int *piStack_cc0;
  undefined **ppuStack_cb8;
  undefined8 uStack_cb0;
  undefined8 uStack_ca8;
  undefined *puStack_ca0;
  undefined8 uStack_c98;
  undefined4 uStack_c90;
  undefined8 uStack_c8c;
  undefined8 uStack_c84;
  longlong lStack_c78;
  undefined2 uStack_c70;
  undefined auStack_c68 [2];
  undefined2 uStack_c66;
  undefined8 uStack_c64;
  undefined2 uStack_c5c;
  undefined2 uStack_c5a;
  undefined4 uStack_c58;
  undefined2 uStack_c54;
  undefined uStack_c52;
  undefined uStack_c51;
  ushort uStack_c4c;
  short asStack_c4a [65];
  undefined auStack_bc8 [16];
  undefined auStack_bb8 [800];
  int iStack_898;
  int iStack_894;
  uint uStack_890;
  int iStack_88c;
  int iStack_888;
  undefined *puStack_880;
  undefined *puStack_878;
  byte *pbStack_870;
  undefined8 *puStack_868;
  undefined8 uStack_860;
  undefined auStack_858 [2048];
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_d58;
  iVar7 = 0;
  pbStack_d20 = (byte *)0x0;
  uStack_d24 = 0;
  pbStack_d0a = (byte *)0x0;
  sStack_d28 = -1;
  uStack_d00 = 0;
  uStack_cfe = 0;
  uStack_cfc = 0;
  uStack_cfa = 0;
  uStack_d18 = 0;
  uStack_c58 = 0;
  uStack_c54 = 0;
  uStack_c4c = 0;
  puStack_cf0 = param_4;
  lStack_c78 = param_1;
  func_0x(param_3,&sStack_d28,auStack_858);
  uStack_d38 = param_3 + 0xb60;
  func_0x(auStack_bb8,*(undefined2 *)(param_3 + 0x20),*(undefined4 *)(param_3 + 100),
                  param_3 + 0x940);
  uVar8 = 0xffffffffffffffff;
  do {
    uVar8 = uVar8 + 1;
  } while (*(short *)(uVar8 * 2 + 0x1d7d6d0) != 0);
  if ((((_DAT_ == 0) || (DAT_ == '\0')) ||
      (*(char *)(*(longlong *)(param_1 + 0x20) + 0x6c18) == '\0')) ||
     ((lVar9 = *(longlong *)(*(longlong *)(param_1 + 0x20) + 0x2400), lVar9 == 0 ||
      (*(int *)(lVar9 + 0x5b8) != 1)))) {
    cVar5 = '\0';
  }
  else {
    cVar5 = '\x01';
  }
  if ((((_DAT_ == 0) && ((DAT_ & 8) == 0)) && ((int)uVar8 != 0)) || (cVar5 != '\0'))
  {
    uStack_d38 = CONCAT71(uStack_d38._1_7_,cVar5);
    func_0x(auStack_bb8,0x1d7d6d0,uVar8 & 0xffffffff,0x1259c98);
  }
  uStack_c51 = 0;
  uStack_c5a = 0;
  asStack_c4a[uStack_c4c] = 0x314;
  uStack_c4c = uStack_c4c + 1;
  uVar8 = (ulonglong)uStack_d24;
  uStack_c52 = param_2;
  if (sStack_d28 == 0) {
    pbVar23 = pbStack_d20;
    if (uStack_d24 == 0) {
      uVar8 = uStack_d18 & 0xffffffff;
      uStack_d26 = 0;
      uVar21 = (uint)uStack_d18;
      if ((*pbStack_d20 & 0x10) != 0) {
        uVar21 = (uint)uStack_d18 + 2 + (*(ushort *)(pbStack_d20 + uVar8) + 7 >> 3);
        uVar8 = (ulonglong)uVar21;
      }
      uStack_d18 = CONCAT44(uVar21,(uint)uStack_d18);
      uStack_d10 = (uint)uVar8;
      if ((*pbStack_d20 & 0x20) == 0) {
        uStack_d0c = 0;
        uStack_d24 = uStack_d10;
      }
      else {
        puVar24 = (ushort *)(pbStack_d20 + uVar8);
        uStack_d0c = *puVar24;
        if (uStack_d0c == 0) {
          cVar5 = func_0x(0x1b29a00);
          if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
             (*(char *)(lVar9 + 0x499) != '\0')) {
            cVar5 = func_0x(0x1b29a00);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_d38 = 0;
              (*_DAT_)(1,0x141940c,0x15394f8,0x80f);
            }
          }
          func_0x(pbStack_d20,3);
        }
        uStack_d10 = uStack_d18._4_4_ + 2 + (uint)uStack_d0c * 2;
        if (0x1f9e < uStack_d10) {
          cVar5 = func_0x(0x1b29a00);
          if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
             (*(char *)(lVar9 + 0x499) != '\0')) {
            cVar5 = func_0x(0x1b29a00);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_d38 = 0;
              (*_DAT_)(1,0x141940c,0x15394f8,0x816);
            }
          }
          func_0x(pbStack_d20,4);
        }
        uVar13 = (ulonglong)uStack_d0c;
        uStack_d24 = puVar24[uVar13] & 0x7fff;
        if (uStack_d24 < uStack_d10) {
          cVar5 = func_0x(0x1b29a00);
          if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
             (*(char *)(lVar9 + 0x499) != '\0')) {
            cVar5 = func_0x(0x1b29a00);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_d38 = 0;
              (*_DAT_)(1,0x141940c,0x15394f8,0x81d);
            }
          }
          func_0x(pbStack_d20,4);
          uVar13 = (ulonglong)uStack_d0c;
        }
        uVar8 = (ulonglong)uStack_d24;
        uVar20 = (ulonglong)uStack_d10;
        pbVar23 = pbStack_d20;
        puVar2 = puVar24;
        iVar17 = iVar7;
        if ((short)uVar13 != 0) {
          do {
            uVar21 = puVar2[1] & 0x7fff;
            if ((uVar21 < (uint)uVar20) || ((uint)uVar8 < uVar21)) {
              cVar5 = func_0x(0x1b29a00);
              if ((cVar5 != '\0') &&
                 ((lVar9 = func_0x(), lVar9 != 0 &&
                  (*(char *)(lVar9 + 0x499) != '\0')))) {
                cVar5 = func_0x(0x1b29a00);
                if (cVar5 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_d38 = 0;
                  (*_DAT_)(1,0x141940c,0x15394f8,0x82a);
                }
              }
              func_0x(pbStack_d20,4);
              uVar13 = (ulonglong)uStack_d0c;
              uVar8 = (ulonglong)uStack_d24;
              pbVar23 = pbStack_d20;
            }
            iVar17 = iVar17 + 1;
            uVar20 = (ulonglong)uVar21;
            puVar2 = puVar2 + 1;
          } while (iVar17 < (int)uVar13);
          uVar20 = (ulonglong)uStack_d10;
        }
        while( true ) {
          uVar12 = (ushort)uVar13;
          if (-1 < (short)puVar24[(ulonglong)((int)uVar13 - 1) + 1]) break;
          if ((int)uVar13 == 1) {
            uVar13 = 1;
            uVar14 = uVar20;
          }
          else {
            uVar14 = (ulonglong)
                     (*(ushort *)(pbVar23 + uVar13 * 2 + ((uStack_d18 >> 0x20) - 2)) & 0x7fff);
          }
          uVar18 = *(ushort *)(pbVar23 + uVar13 * 2 + (uStack_d18 >> 0x20)) & 0x7fff;
          uVar21 = (uint)uVar14;
          if (((uVar21 < (uint)uVar20) || (uVar18 < uVar21)) || ((uint)uVar8 < uVar18)) {
            func_0x(pbVar23,7);
            uVar20 = (ulonglong)uStack_d10;
            uVar8 = (ulonglong)uStack_d24;
            pbVar23 = pbStack_d20;
            uVar12 = uStack_d0c;
          }
          if ((uVar21 < (uint)uVar20) || ((uint)uVar8 < uVar21)) goto LAB_;
          if (*(ushort *)(pbVar23 + uVar14) == 5) {
            uStack_d26 = uStack_d26 | 2;
            uStack_d0c = uVar12 - 1;
            uStack_cfe = (ushort)uVar14;
            uVar14 = uVar14 & 0xffff;
            pbVar25 = pbVar23 + uVar14;
            if ((*(ushort *)(pbVar25 + 2) >> 0xe & 1) == 0) {
              uVar12 = uStack_cfc & 0xc7ff;
            }
            else {
              uVar12 = uStack_cfc ^ (uStack_cfc ^ *(ushort *)(pbVar25 + 2)) & 0x3800;
            }
            uStack_cfc = (uVar12 ^ *(ushort *)(pbVar25 + 2)) & 0x7ff ^ uVar12;
            uVar19 = (uint)uStack_cfc;
            lVar9 = uVar14 + (uVar12 >> 0xb & 7) * 2;
            pbVar22 = pbVar23;
            if (pbVar23 + (ulonglong)((uVar19 & 0x7ff) * 2) + 4 + lVar9 < pbVar25) {
              func_0x(pbVar25,0x19);
              uVar8 = (ulonglong)uStack_d24;
              uVar14 = (ulonglong)uStack_cfe;
              pbVar22 = pbStack_d20;
            }
            if (uVar18 - uVar21 <
                (((uStack_cfc & 0x7ff) * 2 - (int)uVar14) - (int)pbStack_d20) +
                (int)(pbVar23 + (ulonglong)((uVar19 & 0x7ff) * 2) + 4 + lVar9)) {
              func_0x(pbVar22 + uVar14,0x19);
              uVar8 = (ulonglong)uStack_d24;
              uVar14 = (ulonglong)uStack_cfe;
              pbVar22 = pbStack_d20;
            }
            pbVar23 = pbVar22;
            if (((uStack_cfc & 0x3800) != 0) &&
               (puVar24 = (ushort *)(pbVar22 + uVar14 + 4), uVar12 = uStack_cfc,
               (uStack_cfc & 0x3800) != 0)) {
              do {
                if ((uVar12 & 0x7ff) < (*puVar24 & 0x7ff)) {
                  func_0x(pbVar22 + uVar14,0x1a);
                  uVar14 = (ulonglong)uStack_cfe;
                  pbVar22 = pbStack_d20;
                  uVar12 = uStack_cfc;
                }
                iVar7 = iVar7 + 1;
                puVar24 = puVar24 + 1;
              } while (iVar7 < (int)((uStack_cfc & 0x3800) >> 0xb));
              uVar8 = (ulonglong)uStack_d24;
              pbVar23 = pbVar22;
            }
            break;
          }
          if (*(ushort *)(pbVar23 + uVar14) < 0x400) break;
          uStack_d26 = uStack_d26 | 1;
          uStack_d0c = uVar12 - 1;
          uVar13 = (ulonglong)uStack_d0c;
          if (uStack_d0c == 0) break;
        }
      }
      if ((*pbVar23 & 0x40) == 0) {
        uStack_d02 = 0;
        uStack_d00 = 0;
      }
      else {
        uStack_d02 = (undefined2)uVar8;
        uStack_d00 = (undefined2)(uVar8 >> 0x10);
        uStack_d24 = (int)uVar8 + 0xe;
        uVar10 = func_0x(&uStack_d26);
        func_0x(uVar10,auStack_ce8);
        iVar7 = func_0x(auStack_ce8);
        uStack_d24 = uStack_d24 + iVar7;
        uVar8 = (ulonglong)uStack_d24;
        pbVar23 = pbStack_d20;
      }
      if ((pbStack_d0a != (byte *)0x0) && (pbStack_d0a < pbVar23 + uVar8)) {
        cVar5 = func_0x(0x1b29a00);
        if ((cVar5 != '\0') &&
           ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0'))))
        {
          cVar5 = func_0x(0x1b29a00);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_d38 = 0;
            (*_DAT_)(1,0x141940c,0x15394f8,0x886);
          }
        }
        func_0x(pbStack_d20,0x12);
        uVar8 = (ulonglong)uStack_d24;
        pbVar23 = pbStack_d20;
      }
      if (0x3f3b < (int)uVar8 - 1U) {
        cVar5 = func_0x(0x1b29a00);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x1b29a00);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_d38 = 0;
            (*_DAT_)(1,0x141940c,0x15394f8,0x88b);
          }
        }
        func_0x(pbStack_d20,5);
        uVar8 = (ulonglong)uStack_d24;
        pbVar23 = pbStack_d20;
      }
    }
LAB_:
    if (8 < (uint)uVar8) goto LAB_;
    bVar6 = *pbVar23 & 0xe;
  }
  else {
    if (uStack_d24 == 0) {
      func_0x(&uStack_d26);
      uVar8 = (ulonglong)uStack_d24;
    }
    if (8 < (uint)uVar8) goto LAB_;
    bVar6 = *pbStack_d20 & 0x1c;
  }
  if ((bVar6 == 0) || (bVar6 == 0xc)) {
    uVar8 = 9;
  }
LAB_:
  uVar21 = 9;
  asStack_c4a[uStack_c4c] = (short)uVar8;
  asStack_c4a[(ushort)(uStack_c4c + 1)] = 10;
  asStack_c4a[(ushort)(uStack_c4c + 2)] = (short)param_5 << 5;
  uStack_c64 = *puStack_cf0;
  uStack_c4c = uStack_c4c + 3;
  uStack_c5c = *(undefined2 *)(puStack_cf0 + 1);
  uStack_c66 = 0x1c;
  iStack_898 = (uint)uStack_c4c * 2 + 0x1e;
  puStack_880 = auStack_c68;
  puStack_878 = auStack_bb8;
  iStack_894 = 0x314;
  if (sStack_d28 == 0) {
    pbStack_870 = pbStack_d20;
    uVar18 = uStack_d24;
    if (uStack_d24 == 0) {
      uVar8 = uStack_d18 & 0xffffffff;
      iVar7 = 0;
      uStack_d26 = 0;
      uVar18 = (uint)uStack_d18;
      if ((*pbStack_d20 & 0x10) != 0) {
        uVar18 = (uint)uStack_d18 + 2 + (*(ushort *)(pbStack_d20 + uVar8) + 7 >> 3);
        uVar8 = (ulonglong)uVar18;
      }
      uStack_d18 = CONCAT44(uVar18,(uint)uStack_d18);
      if ((*pbStack_d20 & 0x20) == 0) {
        uStack_d0c = 0;
        uStack_d24 = (uint)uVar8;
        uStack_d10 = (uint)uVar8;
      }
      else {
        puVar24 = (ushort *)(pbStack_d20 + uVar8);
        uStack_d0c = *puVar24;
        if (uStack_d0c == 0) {
          cVar5 = func_0x(0x1b29a00);
          if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
             (*(char *)(lVar9 + 0x499) != '\0')) {
            cVar5 = func_0x(0x1b29a00);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_d38 = 0;
              (*_DAT_)(1,0x141940c,0x15394f8,0x80f);
            }
          }
          func_0x(pbStack_d20,3);
        }
        uStack_d10 = uStack_d18._4_4_ + 2 + (uint)uStack_d0c * 2;
        if (0x1f9e < uStack_d10) {
          cVar5 = func_0x(0x1b29a00);
          if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
             (*(char *)(lVar9 + 0x499) != '\0')) {
            cVar5 = func_0x(0x1b29a00);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_d38 = 0;
              (*_DAT_)(1,0x141940c,0x15394f8,0x816);
            }
          }
          func_0x(pbStack_d20,4);
        }
        uVar13 = (ulonglong)uStack_d0c;
        uStack_d24 = puVar24[uVar13] & 0x7fff;
        if (uStack_d24 < uStack_d10) {
          cVar5 = func_0x(0x1b29a00);
          if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
             (*(char *)(lVar9 + 0x499) != '\0')) {
            cVar5 = func_0x(0x1b29a00);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_d38 = 0;
              (*_DAT_)(1,0x141940c,0x15394f8,0x81d);
            }
          }
          func_0x(pbStack_d20,4);
          uVar13 = (ulonglong)uStack_d0c;
        }
        uVar8 = (ulonglong)uStack_d24;
        uVar20 = (ulonglong)uStack_d10;
        pbStack_870 = pbStack_d20;
        puVar2 = puVar24;
        if ((short)uVar13 != 0) {
          do {
            uVar18 = puVar2[1] & 0x7fff;
            if ((uVar18 < (uint)uVar20) || ((uint)uVar8 < uVar18)) {
              cVar5 = func_0x(0x1b29a00);
              if ((cVar5 != '\0') &&
                 ((lVar9 = func_0x(), lVar9 != 0 &&
                  (*(char *)(lVar9 + 0x499) != '\0')))) {
                cVar5 = func_0x(0x1b29a00);
                if (cVar5 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_d38 = 0;
                  (*_DAT_)(1,0x141940c,0x15394f8,0x82a);
                }
              }
              func_0x(pbStack_d20,4);
              uVar13 = (ulonglong)uStack_d0c;
              uVar8 = (ulonglong)uStack_d24;
              pbStack_870 = pbStack_d20;
            }
            iVar7 = iVar7 + 1;
            uVar20 = (ulonglong)uVar18;
            puVar2 = puVar2 + 1;
          } while (iVar7 < (int)uVar13);
          uVar20 = (ulonglong)uStack_d10;
        }
        while ((short)puVar24[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
          if ((int)uVar13 == 1) {
            uVar14 = 1;
            uVar16 = uVar20;
          }
          else {
            uVar16 = (ulonglong)
                     (*(ushort *)(pbStack_870 + uVar13 * 2 + ((uStack_d18 >> 0x20) - 2)) & 0x7fff);
            uVar14 = uVar13;
          }
          uVar19 = *(ushort *)(pbStack_870 + uVar14 * 2 + (uStack_d18 >> 0x20)) & 0x7fff;
          uVar18 = (uint)uVar16;
          if (((uVar18 < (uint)uVar20) || (uVar19 < uVar18)) || ((uint)uVar8 < uVar19)) {
            func_0x(pbStack_870,7);
            uVar13 = (ulonglong)uStack_d0c;
            uVar20 = (ulonglong)uStack_d10;
            uVar8 = (ulonglong)uStack_d24;
            pbStack_870 = pbStack_d20;
          }
          if ((uVar18 < (uint)uVar20) || ((uint)uVar8 < uVar18)) goto LAB_;
          if (*(ushort *)(pbStack_870 + uVar16) == 5) {
            uStack_d26 = uStack_d26 | 2;
            uStack_d0c = (short)uVar13 - 1;
            uStack_cfe = (ushort)uVar16;
            uVar16 = uVar16 & 0xffff;
            pbVar23 = pbStack_870 + uVar16;
            if ((*(ushort *)(pbVar23 + 2) >> 0xe & 1) == 0) {
              uVar12 = uStack_cfc & 0xc7ff;
            }
            else {
              uVar12 = uStack_cfc ^ (*(ushort *)(pbVar23 + 2) ^ uStack_cfc) & 0x3800;
            }
            uStack_cfc = (uVar12 ^ *(ushort *)(pbVar23 + 2)) & 0x7ff ^ uVar12;
            pbVar25 = pbStack_870 +
                      (ulonglong)((uStack_cfc & 0x7ff) * 2) + 4 + (uVar12 >> 0xb & 7) * 2 + uVar16;
            if (pbVar25 < pbVar23) {
              func_0x(pbVar23,0x19);
              uVar8 = (ulonglong)uStack_d24;
              uVar16 = (ulonglong)uStack_cfe;
              pbStack_870 = pbStack_d20;
            }
            if (uVar19 - uVar18 <
                (((uStack_cfc & 0x7ff) * 2 - (int)uVar16) - (int)pbStack_d20) + (int)pbVar25) {
              func_0x(pbStack_870 + uVar16,0x19);
              uVar8 = (ulonglong)uStack_d24;
              uVar16 = (ulonglong)uStack_cfe;
              pbStack_870 = pbStack_d20;
            }
            if ((uStack_cfc & 0x3800) != 0) {
              puVar24 = (ushort *)(pbStack_870 + uVar16 + 4);
              iVar7 = 0;
              uVar12 = uStack_cfc;
              if ((uStack_cfc & 0x3800) != 0) {
                do {
                  if ((uVar12 & 0x7ff) < (*puVar24 & 0x7ff)) {
                    func_0x(pbStack_870 + uVar16,0x1a);
                    uVar16 = (ulonglong)uStack_cfe;
                    pbStack_870 = pbStack_d20;
                    uVar12 = uStack_cfc;
                  }
                  iVar7 = iVar7 + 1;
                  puVar24 = puVar24 + 1;
                } while (iVar7 < (int)((uStack_cfc & 0x3800) >> 0xb));
                uVar8 = (ulonglong)uStack_d24;
              }
            }
            break;
          }
          if (*(ushort *)(pbStack_870 + uVar16) < 0x400) break;
          uStack_d26 = uStack_d26 | 1;
          uStack_d0c = (short)uVar13 - 1;
          uVar13 = (ulonglong)uStack_d0c;
          if (uStack_d0c == 0) break;
        }
      }
      iVar7 = 0;
      if ((*pbStack_870 & 0x40) == 0) {
        uStack_d02 = 0;
        uStack_d00 = 0;
      }
      else {
        uStack_d02 = (undefined2)uVar8;
        uStack_d00 = (undefined2)(uVar8 >> 0x10);
        uStack_d24 = (int)uVar8 + 0xe;
        puVar11 = (ulonglong *)func_0x(&uStack_d26);
        uVar15 = (ushort)(*puVar11 >> 0x30);
        uVar12 = uVar15;
        if ((((uint)(int)(short)uVar15 >> 1 ^ (int)(short)uVar15) & 0x2000) != 0) {
          uVar12 = uVar15 & 0xdfff;
          if ((uVar15 >> 0xe & 1) != 0) {
            uVar12 = uVar15 | 0x2000;
          }
        }
        if (uVar12 == 0xfffc) {
          iVar7 = (int)((*puVar11 >> 0x20 & 0xffff) >> 5);
        }
        uStack_d24 = uStack_d24 + iVar7;
        uVar8 = (ulonglong)uStack_d24;
        pbStack_870 = pbStack_d20;
      }
      if ((pbStack_d0a != (byte *)0x0) && (pbStack_d0a < pbStack_870 + uVar8)) {
        cVar5 = func_0x(0x1b29a00);
        if ((cVar5 != '\0') &&
           ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0'))))
        {
          cVar5 = func_0x(0x1b29a00);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_d38 = 0;
            (*_DAT_)(1,0x141940c,0x15394f8,0x886);
          }
        }
        func_0x(pbStack_d20,0x12);
        uVar8 = (ulonglong)uStack_d24;
        pbStack_870 = pbStack_d20;
      }
      if (0x3f3b < (int)uVar8 - 1U) {
        cVar5 = func_0x(0x1b29a00);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x1b29a00);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_d38 = 0;
            (*_DAT_)(1,0x141940c,0x15394f8,0x88b);
          }
        }
        func_0x(pbStack_d20,5);
        uVar8 = (ulonglong)uStack_d24;
        pbStack_870 = pbStack_d20;
      }
LAB_:
      uVar18 = (uint)uVar8;
    }
    if ((8 < uVar18) || (((*pbStack_870 & 0xe) != 0 && ((*pbStack_870 & 0xe) != 0xc)))) {
      uVar21 = uVar18;
    }
  }
  else {
    if (uStack_d24 == 0) {
      func_0x(&uStack_d26);
    }
    pbStack_870 = pbStack_d20;
    if ((8 < uStack_d24) || (((*pbStack_d20 & 0x1c) != 0 && ((*pbStack_d20 & 0x1c) != 0xc)))) {
      uVar21 = uStack_d24;
    }
  }
  lVar3 = lStack_c78;
  lVar9 = *(longlong *)(lStack_c78 + 0x20);
  iStack_88c = 10;
  uStack_860 = param_6;
  uStack_890 = uVar21;
  iStack_888 = param_5 << 5;
  puStack_868 = puStack_cf0;
  iVar7 = func_0x(lVar9);
  if (((iVar7 == 0) && (iVar7 = func_0x(lVar9), iVar7 == 0)) ||
     (iVar7 = param_5 << 5, iVar17 = 10, *(char *)(lVar9 + 0x2050) != '\0')) {
    func_0x(*(undefined8 *)(lVar9 + 0x6b0));
    iVar7 = iStack_888;
    iVar17 = iStack_88c;
    uVar21 = uStack_890;
  }
  puVar4 = puStack_880;
  uStack_c8c = 0xffffffffffffffff;
  uStack_cc8 = 5;
  uStack_cb0 = 2;
  uStack_c90 = 0;
  uStack_c84 = 0;
  uStack_cd8 = 0;
  uStack_ca8 = 0;
  uStack_c98 = 0;
  iStack_cd0 = (iVar7 + 3U & 0xfffffffc) + (iVar17 + 3U & 0xfffffffc) + (uVar21 + 3 & 0xfffffffc) +
               (iStack_894 + 3U & 0xfffffffc) + (iStack_898 + 3U & 0xfffffffc);
  piStack_cc0 = &iStack_898;
  ppuStack_cb8 = &puStack_880;
  puStack_ca0 = auStack_bc8;
  (**(code **)(**(longlong **)(lVar9 + 0x6c8) + 0x2c8))(*(longlong **)(lVar9 + 0x6c8),&uStack_cd8);
  func_0x(lVar9,puVar4);
  plVar1 = *(longlong **)(*(longlong *)(lVar3 + 0x20) + 0x6c8);
  lStack_c78 = 0;
  uStack_c70 = 0;
  (**(code **)(*plVar1 + 0x90))(plVar1,&lStack_c78,0);
  func_0x(uStack_58 ^ (ulonglong)auStack_d58);
  return;
}

