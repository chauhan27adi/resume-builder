
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong **param_2,undefined4 *param_3)

{
  byte *pbVar1;
  byte bVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  short sVar5;
  int iVar6;
  byte **ppbVar7;
  undefined8 uVar8;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar9;
  ulonglong uVar10;
  undefined4 uVar11;
  uint *puVar12;
  longlong lVar13;
  longlong unaff_GS_OFFSET;
  undefined auStack_658 [32];
  undefined8 uStack_638;
  short sStack_610;
  int iStack_600;
  longlong lStack_5f8;
  byte bStack_5f0;
  ushort uStack_5e8;
  undefined2 uStack_5e0;
  undefined4 uStack_5d8;
  uint uStack_5d0;
  byte bStack_5c8;
  longlong lStack_5c0;
  longlong *plStack_5b8;
  byte *pbStack_5b0;
  undefined4 uStack_5a8;
  undefined2 uStack_5a4;
  int *piStack_590;
  ushort uStack_560;
  ushort uStack_55c;
  ushort uStack_558;
  uint uStack_530;
  uint uStack_528;
  uint uStack_520;
  ushort uStack_510;
  ushort uStack_50e;
  ushort uStack_50c;
  undefined4 uStack_500;
  short sStack_4fc;
  undefined4 *puStack_4e8;
  longlong **pplStack_4e0;
  undefined4 *puStack_4d8;
  byte **ppbStack_4d0;
  undefined4 uStack_4c0;
  undefined2 uStack_4bc;
  int iStack_4b8;
  uint uStack_4b4;
  undefined4 uStack_454;
  undefined auStack_450 [40];
  longlong **pplStack_428;
  longlong lStack_400;
  longlong lStack_3f8;
  byte **ppbStack_3e0;
  undefined8 uStack_3d8;
  longlong lStack_3d0;
  longlong lStack_3c8;
  byte *pbStack_3c0;
  undefined8 uStack_3b8;
  undefined *puStack_3b0;
  longlong lStack_3a8;
  undefined8 uStack_3a0;
  byte *pbStack_398;
  longlong lStack_388;
  byte **ppbStack_380;
  byte **ppbStack_378;
  byte *pbStack_370;
  byte **ppbStack_368;
  longlong lStack_360;
  byte *pbStack_358;
  longlong lStack_350;
  byte *pbStack_348;
  byte *pbStack_328;
  byte *pbStack_320;
  undefined *puStack_318;
  byte *pbStack_310;
  undefined *puStack_308;
  byte *pbStack_300;
  ushort *puStack_1d0;
  undefined2 *puStack_1c8;
  uint *puStack_1c0;
  longlong lStack_1b8;
  uint *puStack_1b0;
  uint *puStack_1a8;
  undefined8 uStack_168;
  undefined8 *puStack_160;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  ushort uStack_110;
  undefined auStack_10e [2];
  undefined4 uStack_10c;
  byte *pbStack_108;
  undefined8 uStack_100;
  undefined8 uStack_f2;
  undefined2 uStack_ea;
  undefined2 uStack_e8;
  undefined6 uStack_e6;
  undefined4 uStack_dc;
  undefined auStack_d8 [16];
  undefined auStack_c8 [16];
  undefined auStack_b8 [16];
  undefined auStack_a8 [16];
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  undefined8 uStack_68;
  undefined auStack_60 [24];
  ulonglong uStack_48;
  
  uStack_3d8 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_658;
  puVar3 = (undefined8 *)**(longlong **)(param_1 + 8);
  uVar11 = 2;
  if (*(int *)(param_1 + 0xfc) == 3) {
    uVar11 = 0;
  }
  uStack_130 = 0;
  uStack_168 = 0;
  pplStack_4e0 = param_2;
  puStack_4d8 = param_3;
  pplStack_428 = param_2;
  lStack_400 = param_1;
  lStack_3f8 = param_1;
  puStack_160 = puVar3;
  sVar5 = (**(code **)*puVar3)(puVar3);
  if (sVar5 == 2) {
    uVar11 = 2;
  }
  uStack_12c = uVar11;
  if (*(short *)((longlong)param_2 + 0xc) < 4) {
    uStack_638 = 0;
    (*_DAT_)(1,0x1b3ac50,0x1b115d8,0x11ab);
  }
  if ((*(int *)(param_1 + 0xfc) - 2U < 2) &&
     ((plVar4 = *(longlong **)(*(longlong *)(param_1 + 8) + 8),
      ((byte)*(undefined4 *)(plVar4 + 0x43) & 5) != 1 || ((*(byte *)(plVar4 + 0x5b) & 2) == 0)))) {
    (**(code **)(*plVar4 + 0x170))(plVar4,0x2000,0);
  }
  func_0x(param_1,0x1995548);
  uStack_168 = *(undefined8 *)(param_1 + 0x110);
  func_0x(&uStack_168,param_2);
  lStack_3d0 = puVar3[1] + 0x200;
  lVar9 = **param_2;
  piStack_590 = (int *)(puVar3[1] + 0x210);
  uStack_55c = *(ushort *)(lVar9 + 0x1ffe);
  pbStack_3c0 = (byte *)(lVar9 + (ulonglong)uStack_55c);
  uStack_560 = (ushort)(*pbStack_3c0 & 1);
  lStack_5f8 = lVar9;
  lStack_3c8 = lVar9;
  if ((*pbStack_3c0 & 1) != 0) {
    uStack_110 = 0xffff;
    pbStack_108 = (byte *)0x0;
    uStack_10c = 0;
    uStack_f2 = 0;
    uStack_e8 = 0;
    uStack_e6 = 0;
    uStack_100 = 0;
    uStack_dc = 0;
    if (*(char *)(lVar9 + 2) < '\0') {
      pbVar1 = (byte *)(lVar9 + 0x60);
      uStack_3b8 = 0;
      ppbStack_4d0 = (byte **)0x0;
      puStack_3b0 = auStack_d8;
      auStack_d8 = ZEXT816(0);
      auStack_c8 = ZEXT816(0);
      auStack_b8 = ZEXT816(0);
      auStack_a8 = ZEXT816(0);
      auStack_98 = ZEXT816(0);
      auStack_88 = ZEXT816(0);
      auStack_78 = ZEXT816(0);
      uStack_68 = 0;
      pbStack_5b0 = pbVar1;
      ppbVar7 = (byte **)func_0x(auStack_d8);
      ppbStack_4d0 = ppbVar7;
      lStack_3a8 = lVar9 + 0x20;
      uVar8 = func_0x(lVar9,auStack_60,0,0);
      ppbStack_3e0 = ppbVar7;
      uStack_3a0 = uVar8;
      pbStack_398 = pbVar1;
      if (pbVar1 == *ppbVar7) {
        iVar6 = func_0x(uVar8,ppbVar7 + 0xc);
        if (iVar6 != 0) {
          lStack_388 = (longlong)ppbVar7 + 0x6c;
        }
      }
      *ppbVar7 = pbVar1;
      func_0x(ppbVar7 + 0xc,uVar8);
      func_0x((longlong)ppbVar7 + 0x6c,lVar9 + 0x20);
      uVar10 = (ulonglong)*pbVar1;
      uStack_558 = (ushort)*pbVar1;
      uStack_4c0 = *(undefined4 *)(uVar10 * 6 + 0x1786b70);
      uStack_4bc = *(undefined2 *)(uVar10 * 6 + 0x1786b74);
      uStack_500 = *(undefined4 *)(uVar10 * 6 + 0x1786b70);
      sStack_610 = *(short *)(uVar10 * 6 + 0x1786b74);
      lStack_5c0 = lVar9 + 99;
      ppbStack_380 = ppbVar7 + 2;
      *(undefined2 *)ppbStack_380 = 0xffff;
      ppbVar7[3] = (byte *)0x0;
      *(undefined4 *)((longlong)ppbVar7 + 0x14) = 0;
      *(undefined8 *)((longlong)ppbVar7 + 0x2e) = 0;
      ppbVar7[7] = (byte *)0x0;
      ppbVar7[4] = (byte *)0x0;
      ppbStack_378 = ppbVar7 + 9;
      *ppbStack_378 = (byte *)0x0;
      ppbVar7[10] = (byte *)0x0;
      *(undefined2 *)(ppbVar7 + 0xb) = 0;
      sStack_4fc = sStack_610;
      if ((**ppbVar7 & 2) != 0) {
        pbStack_370 = pbVar1 + sStack_610;
        bVar2 = *pbStack_370;
        uStack_510 = (ushort)(bVar2 & 1);
        *(ushort *)ppbStack_380 = uStack_510;
        lStack_360 = (longlong)ppbVar7 + 0x12;
        ppbStack_368 = ppbStack_380;
        if ((bVar2 & 1) == 0) {
          uStack_5d8 = 0;
          ppbVar7[3] = pbStack_370;
          *(undefined4 *)((longlong)ppbVar7 + 0x14) = 0;
          *(undefined4 *)((longlong)ppbVar7 + 0x36) = 0;
          pbStack_358 = ppbVar7[3];
                    /* WARNING: Could not emulate address calculation at 0x00100449 */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_358 & 0xe) * 4 + 0x101b20) -
                    0xe122a0))();
          return;
        }
        ppbVar7[3] = pbStack_370;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)
                                *(byte *)((longlong)(int)(*pbStack_370 & 0x1c) + 0x101b6c) * 4 +
                               0x101b5c) - 0xe122a0);
        lStack_350 = lStack_360;
        pbStack_348 = pbStack_370;
                    /* WARNING: Could not emulate address calculation at 0x00100516 */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
        return;
      }
      if ((**ppbVar7 & 4) != 0) {
        uStack_500._2_2_ = (short)((uint)uStack_500 >> 0x10);
        uVar10 = (ulonglong)sStack_610;
        if (uStack_500._2_2_ != 0) {
          uVar10 = (ulonglong)*(ushort *)(lVar9 + 0x61 + (longlong)uStack_500._2_2_ * 2);
        }
        pbStack_328 = pbVar1 + uVar10;
        func_0x(ppbStack_378);
      }
      if (ppbVar7[1] != (byte *)0x0) {
        func_0x(ppbVar7[1],ppbVar7);
      }
    }
    else {
      ppbStack_4d0 = (byte **)0x0;
    }
    uStack_5d0 = (uint)*(ushort *)(lVar9 + 0xe);
    uStack_50e = *(ushort *)(lVar9 + 0x1ffe);
    pbStack_320 = (byte *)(lVar9 + (ulonglong)uStack_50e);
    uStack_50c = (ushort)(*pbStack_320 & 1);
    puStack_318 = auStack_10e;
    uStack_4b4 = uStack_5d0;
    uStack_110 = uStack_50c;
    pbStack_108 = pbStack_320;
    if ((*pbStack_320 & 1) == 0) {
      uStack_10c = 0;
      uStack_ea = 0;
      uStack_e8 = 0;
      pbStack_310 = pbStack_320;
                    /* WARNING: Could not emulate address calculation at 0x001007a0 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_320 & 0xe) * 4 + 0x101b8c) - 0xe122a0
                ))();
      return;
    }
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_320 & 0x1c) + 0x101bd8) *
                            4 + 0x101bc8) - 0xe122a0);
    puStack_308 = puStack_318;
    pbStack_300 = pbStack_320;
                    /* WARNING: Could not emulate address calculation at 0x0010085b */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbStack_320,pbStack_320);
    return;
  }
  iStack_4b8 = *piStack_590;
  puStack_4e8 = (undefined4 *)(pbStack_3c0 + iStack_4b8);
  uStack_5a8 = *puStack_4e8;
  uStack_5a4 = *(undefined2 *)(puStack_4e8 + 1);
  func_0x(lStack_400,param_2,&uStack_5a8,&uStack_168);
  func_0x(&uStack_168);
  func_0x(lStack_400);
  if (*param_2 == (longlong *)0x0) goto LAB_;
  puStack_1d0 = (ushort *)((longlong)*param_2 + 0x62);
  uStack_5e8 = *puStack_1d0;
  if (((uStack_5e8 & 0x400) != 0) && (2 < *(short *)((longlong)param_2 + 0xc))) {
    func_0x(param_2);
    goto LAB_;
  }
  iStack_600 = (int)*(short *)((longlong)param_2 + 0xc);
  plStack_5b8 = *param_2;
  puStack_1c8 = (undefined2 *)((longlong)plStack_5b8 + 0x62);
  uStack_5e0 = *puStack_1c8;
  if (((byte)uStack_5e0 >> 3 & 1) != 0) {
    if (iStack_600 == 3) {
      iStack_600 = 4;
    }
    else if (iStack_600 < 2) goto LAB_;
    puStack_1c0 = (uint *)((longlong)plStack_5b8 + 100);
    uStack_530 = *puStack_1c0;
    if ((((uStack_530 & 8) != 0) && (lVar9 = plStack_5b8[0x12], lVar9 != 0)) &&
       (lStack_1b8 = lVar9, *(longlong *)(lVar9 + 0x758) != 0)) {
      func_0x(*(undefined8 *)(lVar9 + 0x758),plStack_5b8,iStack_600);
    }
  }
LAB_:
  bStack_5c8 = DAT_ >> 7;
  if ((char)DAT_ < '\0') {
    puVar12 = (uint *)((longlong)plStack_5b8 + 100);
    uStack_528 = *puVar12;
    puStack_1b0 = puVar12;
    if (((uStack_528 & 8) != 0) && (2 < iStack_600)) {
      uStack_520 = *puVar12;
      puStack_1a8 = puVar12;
      if (((uStack_520 & 0xc0000000) != 0x40000000) && (*plStack_5b8 != 0)) {
        uStack_454 = 2;
        iVar6 = (*_DAT_)(*plStack_5b8,0x2000,2,auStack_450);
        if (iVar6 != 0) {
          LOCK();
          *puVar12 = *puVar12 & 0x3fffffff;
          UNLOCK();
          LOCK();
          *puVar12 = *puVar12 | 0x40000000;
          UNLOCK();
        }
      }
    }
  }
  plVar4 = plStack_5b8;
  iVar6 = iStack_600;
  func_0x(plStack_5b8 + 0x13,iStack_600);
  if ((_DAT_ != 0) && (bStack_5f0 = DAT_ >> 1, (bStack_5f0 & 1) != 0)) {
    func_0x(plVar4,0,iVar6);
  }
  *(uint *)((longlong)param_2 + 0xc) = *(uint *)((longlong)param_2 + 0xc) & 0xffff0000;
  *param_2 = (longlong *)0x0;
LAB_:
  *param_3 = uStack_5a8;
  *(undefined2 *)(param_3 + 1) = uStack_5a4;
  lVar13 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar9 = *(longlong *)(lVar13 + 0x100);
  if (lVar9 == 0) {
    (*_DAT_)();
    lVar9 = *(longlong *)(lVar13 + 0x100);
  }
  if (*(int *)(lVar9 + 0x22c) != 0) {
    (*_DAT_)();
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_658);
  return;
}

