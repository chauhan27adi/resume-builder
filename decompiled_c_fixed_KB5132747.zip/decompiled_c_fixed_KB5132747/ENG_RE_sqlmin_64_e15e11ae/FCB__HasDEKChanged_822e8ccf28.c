
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_(longlong param_1,short *param_2,undefined8 param_3)

{
  ushort *puVar1;
  longlong *plVar2;
  ushort *puVar3;
  byte bVar4;
  char cVar5;
  ushort uVar6;
  ushort uVar7;
  int iVar8;
  longlong lVar9;
  undefined8 uVar10;
  int *piVar11;
  uint uVar12;
  ulonglong uVar13;
  int *piVar14;
  uint uVar15;
  ulonglong uVar16;
  short sVar17;
  byte *pbVar18;
  ulonglong uVar19;
  uint uVar20;
  ushort *puVar21;
  int aiStackX_10 [2];
  uint auStackX_18 [2];
  undefined auStackX_20 [8];
  ulonglong in_stack_ffffffffffffff90;
  int iStack_58;
  ushort uStack_54;
  ushort uStack_52;
  int *piStack_50;
  
  piVar14 = (int *)0x0;
  iStack_58 = -0x2e;
  uStack_54 = 0x2e;
  puVar1 = (ushort *)(param_2 + 1);
  piStack_50 = (int *)0x0;
  uStack_52 = uStack_52 & 0xffe0;
  if (*param_2 != 0) {
    auStackX_18[0] = 0;
    piVar11 = (int *)func_0x(puVar1,&iStack_58,param_3,aiStackX_10,auStackX_18);
    if ((((*param_2 != 0) && (plVar2 = *(longlong **)(param_2 + 8), plVar2 != (longlong *)0x0)) &&
        (*plVar2 != 0)) && (((uStack_52 & 8) == 0 && ((auStackX_18[0] & 1) == 0)))) {
      if ((piVar11 == (int *)0x0) || (piVar11 == (int *)0x11f3d50)) {
        aiStackX_10[0] = 0;
        piVar11 = piVar14;
      }
      else {
        piVar11 = (int *)func_0x
                                   (plVar2,&iStack_58,piVar11,aiStackX_10[0],0,
                                    in_stack_ffffffffffffff90 & 0xffffffff00000000,aiStackX_10,
                                    auStackX_18[0]);
      }
    }
    goto LAB_;
  }
  pbVar18 = *(byte **)(param_2 + 4);
  if ((*pbVar18 & 0x10) == 0) {
    uVar12 = 1 << (*pbVar18 & 0xe) & 0x1105;
LAB_:
    if (uVar12 == 0) {
      if (*(int *)(param_2 + 2) == 0) {
        uVar12 = *(uint *)(param_2 + 8);
        uVar13 = (ulonglong)uVar12;
        *(uint *)(param_2 + 10) = uVar12;
        *puVar1 = 0;
        bVar4 = *pbVar18;
        if ((bVar4 & 0x10) != 0) {
          uVar12 = uVar12 + 2 + (*(ushort *)(pbVar18 + uVar13) + 7 >> 3);
          uVar13 = (ulonglong)uVar12;
          *(uint *)(param_2 + 10) = uVar12;
          bVar4 = *pbVar18;
        }
        if ((bVar4 & 0x20) == 0) {
          *(int *)(param_2 + 2) = (int)uVar13;
          param_2[0xe] = 0;
          *(int *)(param_2 + 0xc) = (int)uVar13;
        }
        else {
          puVar21 = (ushort *)(pbVar18 + uVar13);
          uVar6 = *puVar21;
          param_2[0xe] = uVar6;
          if (uVar6 == 0) {
            cVar5 = func_0x(0x1b7f6b0);
            if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
               (*(char *)(lVar9 + 0x499) != '\0')) {
              cVar5 = func_0x(0x1b7f6b0);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0x146f0bc,0x158f1a8,0x80f,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),3);
            uVar13 = (ulonglong)*(uint *)(param_2 + 10);
            uVar6 = param_2[0xe];
          }
          uVar12 = (int)uVar13 + (uVar6 + 1) * 2;
          *(uint *)(param_2 + 0xc) = uVar12;
          if (0x1f9e < uVar12) {
            cVar5 = func_0x(0x1b7f6b0);
            if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
               (*(char *)(lVar9 + 0x499) != '\0')) {
              cVar5 = func_0x(0x1b7f6b0);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x146f0bc,0x158f1a8,0x816,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
            uVar6 = param_2[0xe];
            uVar12 = *(uint *)(param_2 + 0xc);
          }
          uVar13 = (ulonglong)uVar6;
          uVar6 = puVar21[uVar13];
          *(uint *)(param_2 + 2) = uVar6 & 0x7fff;
          if ((uVar6 & 0x7fff) < uVar12) {
            cVar5 = func_0x(0x1b7f6b0);
            if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
               (*(char *)(lVar9 + 0x499) != '\0')) {
              cVar5 = func_0x(0x1b7f6b0);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x146f0bc,0x158f1a8,0x81d,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
            uVar12 = *(uint *)(param_2 + 0xc);
            uVar13 = (ulonglong)(ushort)param_2[0xe];
          }
          piVar11 = piVar14;
          puVar3 = puVar21;
          if ((short)uVar13 != 0) {
            do {
              uVar15 = puVar3[1] & 0x7fff;
              if ((uVar15 < uVar12) || (*(uint *)(param_2 + 2) < uVar15)) {
                cVar5 = func_0x(0x1b7f6b0);
                if ((cVar5 != '\0') &&
                   ((lVar9 = func_0x(), lVar9 != 0 &&
                    (*(char *)(lVar9 + 0x499) != '\0')))) {
                  cVar5 = func_0x(0x1b7f6b0);
                  if (cVar5 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    (*_DAT_)(1,0x146f0bc,0x158f1a8,0x82a,0);
                  }
                }
                func_0x(*(undefined8 *)(param_2 + 4),4);
              }
              uVar13 = (ulonglong)(ushort)param_2[0xe];
              uVar20 = (int)piVar11 + 1;
              piVar11 = (int *)(ulonglong)uVar20;
              puVar3 = puVar3 + 1;
              uVar12 = uVar15;
            } while ((int)uVar20 < (int)(uint)(ushort)param_2[0xe]);
          }
          if ((short)puVar21[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
            pbVar18 = *(byte **)(param_2 + 4);
            do {
              uVar12 = *(ushort *)(pbVar18 + uVar13 * 2 + (ulonglong)*(uint *)(param_2 + 10)) &
                       0x7fff;
              if ((int)uVar13 == 1) {
                uVar15 = *(uint *)(param_2 + 0xc);
                uVar20 = uVar15;
LAB_:
                if ((uVar12 < uVar15) || (*(uint *)(param_2 + 2) < uVar12)) goto LAB_;
              }
              else {
                uVar20 = *(uint *)(param_2 + 0xc);
                uVar15 = *(ushort *)
                          (pbVar18 + uVar13 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) & 0x7fff
                ;
                if (uVar20 <= uVar15) goto LAB_;
LAB_:
                func_0x(pbVar18,7);
                uVar20 = *(uint *)(param_2 + 0xc);
              }
              if ((uVar15 < uVar20) || (*(uint *)(param_2 + 2) < uVar15)) goto LAB_;
              pbVar18 = *(byte **)(param_2 + 4);
              if (*(ushort *)(pbVar18 + uVar15) == 5) {
                *puVar1 = *puVar1 | 2;
                param_2[0xe] = param_2[0xe] + -1;
                uVar19 = (ulonglong)(uVar15 & 0xffff);
                param_2[0x15] = (short)uVar15;
                uVar13 = *(ulonglong *)(param_2 + 4);
                uVar6 = param_2[0x16] & 0xc7ffU;
                if ((*(ushort *)(uVar19 + 2 + uVar13) >> 0xe & 1) != 0) {
                  uVar6 = *(ushort *)(uVar19 + 2 + uVar13) & 0x3800 | param_2[0x16] & 0xc7ffU;
                }
                param_2[0x16] = uVar6;
                uVar7 = (uVar6 ^ *(ushort *)(uVar19 + 2 + uVar13)) & 0x7ff ^ uVar6;
                param_2[0x16] = uVar7;
                uVar16 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 + uVar13 + (uVar6 >> 0xb & 7) * 2 +
                         uVar19;
                if (uVar16 < uVar19 + uVar13) {
                  func_0x(uVar19 + uVar13,0x19);
                  uVar7 = param_2[0x16];
                  uVar19 = (ulonglong)(ushort)param_2[0x15];
                  uVar13 = (ulonglong)*(uint *)(param_2 + 4);
                }
                if (uVar12 - uVar15 <
                    (((uVar7 & 0x7ff) * 2 - (int)uVar19) - (int)uVar13) + (int)uVar16) {
                  func_0x(uVar19 + *(longlong *)(param_2 + 4),0x19);
                  uVar7 = param_2[0x16];
                }
                if (((uVar7 & 0x3800) != 0) &&
                   (puVar21 = (ushort *)
                              (*(longlong *)(param_2 + 4) + 4 + (ulonglong)(ushort)param_2[0x15]),
                   (uVar7 & 0x3800) != 0)) {
                  do {
                    if ((uVar7 & 0x7ff) < (*puVar21 & 0x7ff)) {
                      func_0x((ulonglong)(ushort)param_2[0x15] + *(longlong *)(param_2 + 4),
                                      0x1a);
                      uVar7 = param_2[0x16];
                    }
                    uVar12 = (int)piVar14 + 1;
                    piVar14 = (int *)(ulonglong)uVar12;
                    puVar21 = puVar21 + 1;
                  } while ((int)uVar12 < (int)(uVar7 >> 0xb & 7));
                }
                goto LAB_;
              }
              if (*(ushort *)(pbVar18 + uVar15) < 0x400) goto LAB_;
              *puVar1 = *puVar1 | 1;
              uVar6 = param_2[0xe] - 1;
              param_2[0xe] = uVar6;
              if (uVar6 == 0) goto LAB_;
              uVar13 = (ulonglong)uVar6;
            } while ((short)puVar21[(ulonglong)(uVar6 - 1) + 1] < 0);
            uVar13 = (ulonglong)*(uint *)(param_2 + 2);
          }
          else {
LAB_:
            pbVar18 = *(byte **)(param_2 + 4);
            uVar13 = (ulonglong)*(uint *)(param_2 + 2);
          }
        }
        if ((*pbVar18 & 0x40) == 0) {
          *(undefined4 *)(param_2 + 0x13) = 0;
        }
        else {
          *(int *)(param_2 + 0x13) = (int)uVar13;
          *(int *)(param_2 + 2) = (int)uVar13 + 0xe;
          uVar10 = func_0x(puVar1);
          func_0x(uVar10,auStackX_20);
          iVar8 = func_0x(auStackX_20);
          *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar8;
          uVar13 = (ulonglong)*(uint *)(param_2 + 2);
        }
        iVar8 = (int)uVar13;
        if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
           (*(ulonglong *)(param_2 + 0xf) < uVar13 + *(longlong *)(param_2 + 4))) {
          cVar5 = func_0x(0x1b7f6b0);
          if ((cVar5 != '\0') &&
             ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')))
             ) {
            cVar5 = func_0x(0x1b7f6b0);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              (*_DAT_)(1,0x146f0bc,0x158f1a8,0x886,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),0x12);
          iVar8 = *(int *)(param_2 + 2);
        }
        if (0x3f3b < iVar8 - 1U) {
          cVar5 = func_0x(0x1b7f6b0);
          if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
             (*(char *)(lVar9 + 0x499) != '\0')) {
            cVar5 = func_0x(0x1b7f6b0);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              (*_DAT_)(1,0x146f0bc,0x158f1a8,0x88b,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),5);
        }
      }
LAB_:
      sVar17 = -(short)iStack_58;
      if ((uStack_52 & 0x10) != 0) {
        bVar4 = **(byte **)(param_2 + 4);
        if ((bVar4 & 0x10) == 0) {
          if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
            aiStackX_10[0] = *piStack_50;
            piVar11 = piStack_50 + 1;
            goto LAB_;
          }
        }
        else if (((int)*(uint *)(param_2 + 8) <= iStack_58) ||
                (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) < uStack_54))
        goto LAB_;
      }
      piVar11 = *(int **)(param_2 + 4);
      lVar9 = (longlong)sVar17;
      if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar17) {
        aiStackX_10[0] = 0;
        goto LAB_;
      }
      uVar12 = *(uint *)(param_2 + 10);
      if (sVar17 == 1) {
        uVar15 = *(uint *)(param_2 + 0xc);
        uVar12 = *(ushort *)((longlong)piVar11 + lVar9 * 2 + (ulonglong)uVar12) & 0x7fff;
LAB_:
        if ((uVar12 < uVar15) || (*(uint *)(param_2 + 2) < uVar12)) goto LAB_;
      }
      else {
        puVar1 = (ushort *)((longlong)piVar11 + lVar9 * 2 + (ulonglong)uVar12);
        uVar15 = *(ushort *)((longlong)piVar11 + lVar9 * 2 + ((ulonglong)uVar12 - 2)) & 0x7fff;
        piVar11 = *(int **)(param_2 + 4);
        uVar12 = *puVar1 & 0x7fff;
        if (*(uint *)(param_2 + 0xc) <= uVar15) goto LAB_;
LAB_:
        func_0x(piVar11,7);
        piVar11 = *(int **)(param_2 + 4);
      }
      aiStackX_10[0] = uVar12 - uVar15;
      piVar11 = (int *)((longlong)piVar11 + (ulonglong)uVar15);
      goto LAB_;
    }
  }
  else {
    uVar12 = *(uint *)(param_2 + 8);
    if ((-0x2e < (int)uVar12) && (0x2d < *(ushort *)(pbVar18 + uVar12))) {
      uVar12 = pbVar18[(ulonglong)uVar12 + 7] >> 5 & 1;
      goto LAB_;
    }
  }
  aiStackX_10[0] = 0;
  piVar11 = (int *)0x0;
LAB_:
  if (aiStackX_10[0] == 0) {
    return *(longlong *)(param_1 + 0x370) != 0;
  }
  if ((piVar11 != (int *)0x0) && (aiStackX_10[0] == 600)) {
    if (*(longlong *)(param_1 + 0x370) == 0) {
      if ((*(byte *)piVar11 & 0x1f) == 0) {
        return false;
      }
    }
    else {
      iVar8 = (*_DAT_)(*(longlong *)(param_1 + 0x370),piVar11,600);
      if (iVar8 != 0) {
        return false;
      }
    }
    return true;
  }
  (*_DAT_)(0x33,0x48,0x10,0x51,param_1 + 0x940,0x1495160);
  return false;
}

