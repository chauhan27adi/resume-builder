
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_(longlong param_1,uint param_2,int param_3,undefined4 *param_4)

{
  int iVar1;
  longlong lVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  longlong unaff_GS_OFFSET;
  undefined8 uStackX_20;
  longlong lStack_70;
  undefined4 uStack_68;
  int iStack_60;
  int iStack_5c;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  
  piVar4 = (int *)0x0;
  iStack_60 = 0x400000;
  uStack_58 = 0;
  uStack_48 = 0;
  uStack_50 = 0;
  uStack_40 = 0;
  uVar3 = 0;
  *param_4 = 0;
  if (*(int *)(param_1 + 0xb8) == 0) {
    if (param_2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lStack_70 = 0;
    uStack_68 = 0;
    iVar1 = func_0x(param_1,&lStack_70,&iStack_60,&uStackX_20);
    if (lStack_70 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iVar1 != 0) {
      return 0;
    }
    goto LAB_;
  }
  func_0x(param_1);
  if (param_2 == 0) {
    piVar5 = piVar4;
    uVar3 = 0;
    if ((*(longlong *)(param_1 + 0x98) != 0) &&
       (piVar4 = *(int **)(param_1 + 200), piVar5 = (int *)0x0, uVar3 = 0, piVar4 != (int *)0x0)) {
      uStackX_20 = *(undefined8 *)(*(longlong *)(param_1 + 0x98) + 0x88);
      iStack_60 = *piVar4;
      iStack_5c = piVar4[1];
      uStack_58 = *(undefined8 *)(piVar4 + 2);
      uStack_50 = *(undefined8 *)(piVar4 + 4);
      uStack_48 = *(undefined8 *)(piVar4 + 6);
      uStack_40 = *(undefined8 *)(piVar4 + 8);
LAB_:
      uVar3 = *(undefined4 *)(param_1 + 0x108);
      lVar2 = (*_DAT_)(piVar4);
      if (lVar2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      goto LAB_;
    }
LAB_:
    piVar4 = piVar5;
    if (((ulonglong)param_2 < *(ulonglong *)(param_1 + 0x100)) &&
       (*(longlong *)(param_1 + 200 + (*(ulonglong *)(param_1 + 0x100) - (ulonglong)param_2) * 8) !=
        0)) {
      *param_4 = 1;
    }
  }
  else {
    uVar3 = 0;
    if (((ulonglong)(param_2 - 1) < *(ulonglong *)(param_1 + 0x100)) &&
       (piVar4 = *(int **)(param_1 + 200 +
                          (*(longlong *)(param_1 + 0x100) - (ulonglong)(param_2 - 1)) * 8),
       uVar3 = 0, piVar4 != (int *)0x0)) {
      iStack_60 = *piVar4;
      iStack_5c = piVar4[1];
      uStack_58 = *(undefined8 *)(piVar4 + 2);
      uStack_50 = *(undefined8 *)(piVar4 + 4);
      uStack_48 = *(undefined8 *)(piVar4 + 6);
      uStack_40 = *(undefined8 *)(piVar4 + 8);
      uStackX_20 = *(undefined8 *)(piVar4 + 10);
      goto LAB_;
    }
LAB_:
    piVar5 = piVar4;
    if (param_2 < 6) goto LAB_;
  }
  func_0x(param_1);
  if (piVar4 == (int *)0x0) {
    return 0;
  }
LAB_:
  if (param_3 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar2 = (*_DAT_)(&iStack_60);
  if (lVar2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iStack_60 != 0) {
    if ((short)((uint)iStack_60 >> 0x10) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (((iStack_60 + 0xfdfffee7U < 4) && ((DAT_ & 0x10) == 0)) &&
       ((lVar2 = *(longlong *)
                  ((ulonglong)*_DAT_ +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
        lVar2 == 0 ||
        ((lVar2 = **(longlong **)(lVar2 + 0x38), lVar2 == 0 ||
         (iVar1 = (*_DAT_)(lVar2,0x4c4), iVar1 == 0)))))) {
      lVar2 = func_0x(param_1,&iStack_60);
      if (lVar2 != 0) {
        *(undefined4 *)(lVar2 + 0x30) = uVar3;
        return lVar2;
      }
      return 0;
    }
    if (iStack_60 == 0x400062) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((iStack_60 - 0x40012bU < 2) || (iStack_60 == 0x4000bb)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iStack_60 == 0x4000d5) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  return 0;
}

