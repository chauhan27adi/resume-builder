
/* WARNING: Control flow encountered bad instruction data */

undefined8 FUN_(char param_1)

{
  if (param_1 == '\x01') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_1 == '\x02') {
    return 0x1000;
  }
  if (param_1 == '\x03') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_1 != '\x04') {
    if (param_1 == '\x05') {
      return 0x1000000;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

