
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,longlong param_3,undefined8 param_4)

{
  byte bVar1;
  undefined4 uVar2;
  int iVar3;
  byte *pbVar4;
  ushort *puVar5;
  longlong *plVar6;
  char cVar7;
  ushort uVar8;
  int iVar9;
  longlong lVar10;
  ulonglong uVar11;
  short *psVar12;
  longlong lVar13;
  undefined8 uVar14;
  short sVar15;
  ushort uVar16;
  uint uVar17;
  byte **ppbVar18;
  uint uVar19;
  byte **ppbVar20;
  byte *pbVar21;
  uint uVar22;
  byte *pbVar23;
  undefined2 uVar24;
  short sVar25;
  short sVar26;
  ushort *puVar27;
  ulonglong uVar28;
  uint uVar29;
  undefined4 extraout_XMM0_Da;
  undefined4 uStackX_8;
  undefined2 auStackX_c [2];
  int iStackX_10;
  longlong lStackX_18;
  undefined8 uStackX_20;
  ushort uStack_391c;
  undefined auStack_3910 [16];
  undefined auStack_3900 [8];
  undefined8 uStack_38f8;
  undefined8 uStack_38f0;
  undefined6 uStack_38e8;
  undefined2 uStack_38e2;
  undefined6 uStack_38e0;
  undefined2 uStack_38da;
  undefined8 uStack_38d8;
  undefined auStack_38d0 [16];
  undefined auStack_38c0 [16];
  undefined auStack_38b0 [16];
  undefined8 uStack_38a0;
  undefined2 auStack_3898 [2];
  undefined4 uStack_3894;
  undefined8 uStack_3890;
  undefined8 uStack_3888;
  undefined8 uStack_387a;
  undefined8 uStack_3870;
  undefined auStack_2059 [8193];
  ulonglong uStack_58;
  undefined8 uStack_48;
  
  uStack_48 = 0x10002c;
  iStackX_10 = param_2;
  lStackX_18 = param_3;
  uStackX_20 = param_4;
  lVar10 = func_0x();
  lVar10 = -lVar10;
  uStack_58 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar10);
  uVar24 = *(undefined2 *)(param_1 + 0x20);
  ppbVar18 = (byte **)0x0;
  *(longlong *)((longlong)&lStackX_18 + lVar10) = param_1;
  uVar28 = (ulonglong)auStack_2059 & 0xfffffffffffff000;
  *(undefined8 *)(&stack0x00000028 + lVar10) = 0;
  *(undefined4 *)((longlong)&uStackX_20 + lVar10 + 4) = 0;
  *(undefined2 *)((longlong)&uStackX_20 + lVar10) = 0xffff;
  *(undefined8 *)(&stack0x0000003e + lVar10) = 0;
  uStack_391c = 0;
  *(undefined8 *)(&stack0x00000030 + lVar10) = 0;
  auStack_3898[0] = 0xffff;
  uStack_3890 = 0;
  uStack_3894 = 0;
  uStack_387a = 0;
  uStack_3870 = 0;
  uStack_3888 = 0;
  *(undefined4 *)((longlong)&uStackX_8 + lVar10) = 0;
  *(undefined2 *)((longlong)auStackX_c + lVar10) = uVar24;
  *(ulonglong *)((longlong)&iStackX_10 + lVar10) = uVar28;
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1000b1;
  func_0x(extraout_XMM0_Da,0,uVar28,(longlong)&uStackX_8 + lVar10);
  uVar22 = 0xf;
  sVar25 = 2;
  uVar17 = 0;
  sVar26 = 2;
  ppbVar20 = ppbVar18;
  if (*(char *)(uVar28 + 2) < '\0') {
    pbVar23 = (byte *)(uVar28 + 0x60);
    if ((*(short *)((longlong)&uStackX_20 + lVar10) == 0) ||
       (ppbVar20 = *(byte ***)(&stack0x00000030 + lVar10), ppbVar20 == (byte **)0x0)) {
      ppbVar20 = (byte **)auStack_3910;
      stack0xffffffffffffc702 = SUB1614(ZEXT816(0),2);
      auStack_3900._0_2_ = 0xffff;
      uStack_38e8 = 0;
      uStack_38da = 0;
      uStack_38f8 = 0;
      uStack_38e2 = 0;
      uStack_38e0 = 0;
      uStack_38d8 = 0;
      uStack_38f0 = 0;
      auStack_38d0 = ZEXT816(0);
      auStack_38b0._0_12_ = ZEXT812(0);
      auStack_38b0._12_4_ = 0;
      uStack_38a0 = 0;
      auStack_38c0 = ZEXT816(0);
      auStack_3910 = ZEXT816(0);
    }
    if (*(short *)(uVar28 + 0x24) == 0) {
LAB_:
      uVar24 = *(undefined2 *)(uVar28 + 0x30);
      *(undefined8 *)(&stack0xfffffffffffffff8 + lVar10) = *(undefined8 *)(uVar28 + 0x28);
    }
    else {
      cVar7 = *(char *)(uVar28 + 1);
      if (cVar7 == '\v') {
        if (*(int *)(uVar28 + 0x18) != 99) {
LAB_:
          if (cVar7 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar7 != '\b') goto LAB_;
LAB_:
        if (*(int *)(uVar28 + 0x18) != 99) goto LAB_;
      }
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar10) = *(undefined4 *)(uVar28 + 0x20);
      *(undefined2 *)(&stack0xfffffffffffffff4 + lVar10) = *(undefined2 *)(uVar28 + 0x24);
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10018c;
      cVar7 = func_0x(&stack0xfffffffffffffff0 + lVar10,0x112ffd0);
      if (cVar7 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10019d;
      func_0x(uVar28,&stack0xfffffffffffffff8 + lVar10);
      uVar24 = *(undefined2 *)(&stack0x00000000 + lVar10);
    }
    uVar2 = *(undefined4 *)(&stack0xfffffffffffffff8 + lVar10);
    *ppbVar20 = pbVar23;
    *(undefined4 *)(ppbVar20 + 0xc) = uVar2;
    uVar14 = *(undefined8 *)(&stack0xfffffffffffffff8 + lVar10);
    *(undefined2 *)(ppbVar20 + 0xd) = uVar24;
    *(int *)((longlong)ppbVar20 + 100) = (int)((ulonglong)uVar14 >> 0x20);
    *(undefined4 *)((longlong)ppbVar20 + 0x6c) = *(undefined4 *)(uVar28 + 0x20);
    *(undefined2 *)(ppbVar20 + 0xe) = *(undefined2 *)(uVar28 + 0x24);
    *(undefined2 *)((longlong)ppbVar20 + 0x72) = 0;
    uVar2 = *(undefined4 *)((ulonglong)*pbVar23 * 6 + 0x11ae8b0);
    sVar15 = *(short *)((ulonglong)*pbVar23 * 6 + 0x11ae8b4);
    *(undefined2 *)(ppbVar20 + 2) = 0xffff;
    ppbVar20[3] = (byte *)0x0;
    *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar20 + 0x2e) = 0;
    ppbVar20[7] = (byte *)0x0;
    ppbVar20[4] = (byte *)0x0;
    ppbVar20[9] = (byte *)0x0;
    ppbVar20[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar20 + 0xb) = 0;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar10) = uVar2;
    pbVar4 = *ppbVar20;
    *(short *)(&stack0xfffffffffffffff0 + lVar10) = sVar15;
    if ((*pbVar4 & 2) != 0) {
      pbVar4 = pbVar23 + sVar15;
      if ((pbVar23[sVar15] & 1) == 0) {
        *(undefined2 *)(ppbVar20 + 2) = 0;
        ppbVar20[3] = pbVar4;
        *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar20 + 0x36) = 0;
        uVar19 = uVar17;
        switch(*pbVar4 & 0xe) {
        default:
          uVar19 = (uint)*(ushort *)(pbVar4 + 2);
          if (0x1f9d < *(ushort *)(pbVar4 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100416;
            func_0x(pbVar4,6);
          }
          break;
        case 4:
          uVar19 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar19 = 1;
        }
        *(uint *)(ppbVar20 + 4) = uVar19;
        *(undefined8 *)((longlong)ppbVar20 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar20 + 2) = 1;
        ppbVar20[3] = pbVar4;
        bVar1 = *pbVar4;
        switch(bVar1 & 0x1c) {
        default:
          if ((char)pbVar4[1] < '\0') {
            uVar16 = *(ushort *)(pbVar4 + 1);
            sVar26 = 3;
            *(ushort *)((longlong)ppbVar20 + 0x12) = uVar16;
            uVar16 = (uVar16 & 0x7f) << 8 | uVar16 >> 8;
          }
          else {
            uVar16 = (ushort)pbVar4[1];
          }
          *(ushort *)((longlong)ppbVar20 + 0x12) = uVar16;
          *(short *)(ppbVar20 + 5) = sVar26;
          uVar16 = *(ushort *)((longlong)ppbVar20 + 0x12);
          *(short *)((longlong)ppbVar20 + 0x2c) = (short)(uVar16 + 1 >> 1) + sVar26;
          if (uVar16 < 0x1f) {
            *(undefined2 *)((longlong)ppbVar20 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
            *(undefined4 *)(ppbVar20 + 8) = 0;
            ppbVar20[7] = (byte *)0x0;
            ppbVar20[4] = (byte *)0x0;
          }
          else {
            iVar9 = uVar16 - 1;
            *(short *)((longlong)ppbVar20 + 0x2a) =
                 ((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
                 (short)((longlong)iVar9 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
            *(undefined4 *)(ppbVar20 + 8) = 0;
            ppbVar20[7] = (byte *)0x0;
            ppbVar20[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar1 & 0x1c) != 4) || (uVar19 = 1, (bVar1 & 2) == 0)) {
            uVar19 = uVar17;
          }
          if (uVar19 == 0) {
            uVar29 = 1;
          }
          else {
            *(undefined4 *)(ppbVar20 + 8) = 0;
            uVar29 = uVar22;
          }
          ppbVar20[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar20 + 0x12) = 0;
          ppbVar20[6] = (byte *)0x0;
          ppbVar20[4] = (byte *)0x0;
          ppbVar20[7] = (byte *)0x0;
          ppbVar20[3] = pbVar4;
          *(uint *)((longlong)ppbVar20 + 0x14) = uVar29;
          *(uint *)(ppbVar20 + 8) = (uint)(uVar19 != 0);
          ppbVar20[7] = (byte *)0x0;
          ppbVar20[4] = (byte *)0x0;
          break;
        case 8:
          ppbVar20[7] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar20 + 0x14) = 9;
          ppbVar20[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar20 + 0x12) = 0;
          ppbVar20[6] = (byte *)0x0;
          ppbVar20[4] = (byte *)0x0;
          ppbVar20[3] = pbVar4;
          *(undefined4 *)(ppbVar20 + 8) = 0;
          ppbVar20[7] = (byte *)0x0;
          ppbVar20[4] = (byte *)0x0;
        }
      }
      sVar15 = *(short *)(&stack0xfffffffffffffff0 + lVar10);
    }
    if ((**ppbVar20 & 4) != 0) {
      if (*(short *)(&stack0xfffffffffffffffa + lVar10) == 0) {
        uVar11 = (ulonglong)sVar15;
      }
      else {
        uVar11 = (ulonglong)
                 *(ushort *)
                  (uVar28 + 0x61 + (longlong)*(short *)(&stack0xfffffffffffffffa + lVar10) * 2);
      }
      psVar12 = (short *)(pbVar23 + uVar11);
      ppbVar20[9] = (byte *)psVar12;
      sVar26 = *psVar12;
      ppbVar20[10] = (byte *)(psVar12 + 1);
      *(short *)(ppbVar20 + 0xb) = (sVar26 + 1) * 2;
    }
    pbVar23 = ppbVar20[1];
    if (pbVar23 != (byte *)0x0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1004b2;
      func_0x(pbVar23,ppbVar20);
    }
  }
  uVar19 = 9;
  uVar16 = *(ushort *)(uVar28 + 0xe);
  pbVar23 = (byte *)(*(ushort *)(uVar28 + 0x1ffe) + uVar28);
  bVar1 = *pbVar23;
  *(byte **)(&stack0x00000028 + lVar10) = pbVar23;
  if ((bVar1 & 1) == 0) {
    *(undefined2 *)((longlong)&uStackX_20 + lVar10) = 0;
    *(undefined4 *)((longlong)&uStackX_20 + lVar10 + 4) = 0;
    uVar22 = uVar17;
    uVar29 = (uint)uVar16;
    switch(*pbVar23 & 0xe) {
    default:
      uVar16 = *(ushort *)(pbVar23 + 2);
      uVar29 = (uint)uVar16;
      if (0x1f9d < uVar16 - 1) {
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10068f;
        func_0x(pbVar23,6);
        pbVar23 = *(byte **)(&stack0x00000028 + lVar10);
        uVar22 = *(uint *)((longlong)&uStackX_20 + lVar10 + 4);
      }
      break;
    case 4:
      uVar22 = 0;
      uVar29 = uVar19;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar29 = 1;
    }
    *(uint *)(&stack0x00000030 + lVar10) = uVar29;
    *(ulonglong *)(&stack0x0000003e + lVar10) = uVar28 + 0x2000;
    ppbVar20 = (byte **)(ulonglong)uVar29;
  }
  else {
    *(undefined2 *)((longlong)&uStackX_20 + lVar10) = 1;
    bVar1 = *pbVar23;
    switch(bVar1 & 0x1c) {
    default:
      if ((char)pbVar23[1] < '\0') {
        uVar16 = (*(ushort *)(pbVar23 + 1) & 0x7f) << 8 | *(ushort *)(pbVar23 + 1) >> 8;
        *(undefined2 *)(&stack0x00000038 + lVar10) = 3;
        sVar25 = 3;
        *(ushort *)((longlong)&uStackX_20 + lVar10 + 2) = uVar16;
      }
      else {
        uVar16 = (ushort)pbVar23[1];
        *(ushort *)((longlong)&uStackX_20 + lVar10 + 2) = uVar16;
        *(undefined2 *)(&stack0x00000038 + lVar10) = 2;
      }
      *(ushort *)(&stack0x0000003c + lVar10) = ((ushort)(uVar16 + 1) >> 1) + sVar25;
      if (uVar16 < 0x1f) {
        *(undefined2 *)(&stack0x0000003a + lVar10) = 0;
        *(undefined4 *)((longlong)&uStackX_20 + lVar10 + 4) = 0;
        uVar22 = uVar17;
      }
      else {
        iVar9 = uVar16 - 1;
        *(undefined4 *)((longlong)&uStackX_20 + lVar10 + 4) = 0;
        *(short *)(&stack0x0000003a + lVar10) =
             ((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
             (short)((longlong)iVar9 * 0x88888889 >> 0x3f);
        uVar22 = uVar17;
      }
      break;
    case 4:
      if (((bVar1 & 0x1c) == 4) && ((bVar1 & 2) != 0)) {
        *(undefined8 *)(&stack0x00000038 + lVar10) = 0;
        *(undefined2 *)((longlong)&uStackX_20 + lVar10 + 2) = 0;
        *(undefined4 *)((longlong)&uStackX_20 + lVar10 + 4) = 0xf;
      }
      else {
        *(undefined8 *)(&stack0x00000038 + lVar10) = 0;
        uVar22 = 1;
        *(undefined2 *)((longlong)&uStackX_20 + lVar10 + 2) = 0;
        *(undefined4 *)((longlong)&uStackX_20 + lVar10 + 4) = 1;
      }
      break;
    case 8:
      *(undefined8 *)(&stack0x00000038 + lVar10) = 0;
      *(undefined2 *)((longlong)&uStackX_20 + lVar10 + 2) = 0;
      *(undefined4 *)((longlong)&uStackX_20 + lVar10 + 4) = 9;
      uVar22 = uVar19;
    }
    *(byte ***)(&stack0x00000030 + lVar10) = ppbVar20;
    uStack_391c = (ushort)(uVar28 + 0x2000 >> 0x20);
  }
  if (*(short *)((longlong)&uStackX_20 + lVar10) == 0) {
    if (uVar22 == 0) {
      *(undefined2 *)((longlong)&uStackX_20 + lVar10 + 2) = 0;
      uVar22 = (uint)ppbVar20;
      *(uint *)(&stack0x00000034 + lVar10) = uVar22;
      if ((*pbVar23 & 0x10) != 0) {
        uVar22 = uVar22 + 2 + (*(ushort *)(pbVar23 + ((ulonglong)ppbVar20 & 0xffffffff)) + 7 >> 3);
        *(uint *)(&stack0x00000034 + lVar10) = uVar22;
      }
      if ((*pbVar23 & 0x20) == 0) {
        *(uint *)((longlong)&uStackX_20 + lVar10 + 4) = uVar22;
        *(undefined2 *)(&stack0x0000003c + lVar10) = 0;
        *(uint *)(&stack0x00000038 + lVar10) = uVar22;
      }
      else {
        puVar27 = (ushort *)(pbVar23 + uVar22);
        uVar16 = *puVar27;
        *(ushort *)(&stack0x0000003c + lVar10) = uVar16;
        if (uVar16 == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100743;
          cVar7 = func_0x(0x1ac5060);
          if (cVar7 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10074c;
            lVar13 = func_0x();
            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100765;
              cVar7 = func_0x(0x1ac5060);
              if (cVar7 == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100781;
                (*pcRam0000000001032be8)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1007a7;
                (*pcRam0000000001032be0)(1,0x13b4a6c,0x14d4b58,0x80f);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1007b6;
          func_0x(*(undefined8 *)(&stack0x00000028 + lVar10),3);
          uVar16 = *(ushort *)(&stack0x0000003c + lVar10);
          pbVar23 = *(byte **)(&stack0x00000028 + lVar10);
        }
        uVar17 = *(int *)(&stack0x00000034 + lVar10) + 2 + (uint)uVar16 * 2;
        *(uint *)(&stack0x00000038 + lVar10) = uVar17;
        if (0x1f9e < uVar17) {
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1007ed;
          cVar7 = func_0x(0x1ac5060);
          if (cVar7 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1007f6;
            lVar13 = func_0x();
            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10080f;
              cVar7 = func_0x(0x1ac5060);
              if (cVar7 == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10082b;
                (*pcRam0000000001032be8)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100851;
                (*pcRam0000000001032be0)(1,0x13b4a6c,0x14d4b58,0x816);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100860;
          func_0x(*(undefined8 *)(&stack0x00000028 + lVar10),4);
          uVar16 = *(ushort *)(&stack0x0000003c + lVar10);
          uVar17 = *(uint *)(&stack0x00000038 + lVar10);
          pbVar23 = *(byte **)(&stack0x00000028 + lVar10);
        }
        uVar11 = (ulonglong)uVar16;
        uVar22 = puVar27[uVar11] & 0x7fff;
        *(uint *)((longlong)&uStackX_20 + lVar10 + 4) = uVar22;
        if (uVar22 < uVar17) {
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100896;
          cVar7 = func_0x(0x1ac5060);
          if (cVar7 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10089f;
            lVar13 = func_0x();
            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1008b8;
              cVar7 = func_0x(0x1ac5060);
              if (cVar7 == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1008d4;
                (*pcRam0000000001032be8)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1008fa;
                (*pcRam0000000001032be0)(1,0x13b4a6c,0x14d4b58,0x81d);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100909;
          func_0x(*(undefined8 *)(&stack0x00000028 + lVar10),4);
          uVar11 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar10);
          uVar17 = *(uint *)(&stack0x00000038 + lVar10);
          pbVar23 = *(byte **)(&stack0x00000028 + lVar10);
          uVar22 = *(uint *)((longlong)&uStackX_20 + lVar10 + 4);
        }
        ppbVar20 = ppbVar18;
        puVar5 = puVar27;
        if ((short)uVar11 != 0) {
          do {
            uVar19 = puVar5[1] & 0x7fff;
            if ((uVar19 < uVar17) || (uVar22 < uVar19)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100963;
              cVar7 = func_0x(0x1ac5060);
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10096c;
                lVar13 = func_0x();
                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100985;
                  cVar7 = func_0x(0x1ac5060);
                  if (cVar7 == '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1009a1;
                    (*pcRam0000000001032be8)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1009c5;
                    (*pcRam0000000001032be0)(1,0x13b4a6c,0x14d4b58,0x82a);
                  }
                }
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1009d4;
              func_0x(*(undefined8 *)(&stack0x00000028 + lVar10),4);
              uVar11 = (ulonglong)*(ushort *)(&stack0x0000003c + lVar10);
              pbVar23 = *(byte **)(&stack0x00000028 + lVar10);
              uVar22 = *(uint *)((longlong)&uStackX_20 + lVar10 + 4);
            }
            uVar29 = (int)ppbVar20 + 1;
            ppbVar20 = (byte **)(ulonglong)uVar29;
            puVar5 = puVar5 + 1;
            uVar17 = uVar19;
          } while ((int)uVar29 < (int)uVar11);
          uVar17 = *(uint *)(&stack0x00000038 + lVar10);
          uVar28 = *(ulonglong *)((longlong)&iStackX_10 + lVar10);
        }
        while( true ) {
          sVar26 = (short)uVar11;
          if (-1 < (short)puVar27[(ulonglong)((int)uVar11 - 1) + 1]) break;
          uVar19 = uVar17;
          if ((int)uVar11 != 1) {
            uVar19 = *(ushort *)
                      (pbVar23 + uVar11 * 2 + ((ulonglong)*(uint *)(&stack0x00000034 + lVar10) - 2))
                     & 0x7fff;
          }
          uVar29 = *(ushort *)
                    (pbVar23 + uVar11 * 2 + (ulonglong)*(uint *)(&stack0x00000034 + lVar10)) &
                   0x7fff;
          if (((uVar19 < uVar17) || (uVar29 < uVar19)) || (uVar22 < uVar29)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100a6a;
            func_0x(pbVar23,7);
            sVar26 = *(short *)(&stack0x0000003c + lVar10);
            uVar17 = *(uint *)(&stack0x00000038 + lVar10);
            pbVar23 = *(byte **)(&stack0x00000028 + lVar10);
            uVar22 = *(uint *)((longlong)&uStackX_20 + lVar10 + 4);
          }
          if ((uVar19 < uVar17) || (uVar22 < uVar19)) goto code_r0x00100dbb;
          if (*(ushort *)(pbVar23 + uVar19) == 5) {
            puVar27 = (ushort *)((longlong)&uStackX_20 + lVar10 + 2);
            *puVar27 = *puVar27 | 2;
            uVar11 = (ulonglong)(uVar19 & 0xffff);
            pbVar4 = pbVar23 + uVar11;
            *(short *)(&stack0x0000003c + lVar10) = sVar26 + -1;
            uVar16 = (ushort)uVar19;
            if ((*(ushort *)(pbVar4 + 2) >> 0xe & 1) == 0) {
              uStack_391c = uStack_391c & 0xc7ff;
            }
            else {
              uStack_391c = uStack_391c ^ (uStack_391c ^ *(ushort *)(pbVar4 + 2)) & 0x3800;
            }
            uVar8 = (uStack_391c ^ *(ushort *)(pbVar4 + 2)) & 0x7ff ^ uStack_391c;
            pbVar21 = pbVar23 + uVar11 + (ulonglong)((uVar8 & 0x7ff) * 2) + 4 +
                                         (ulonglong)((uStack_391c >> 0xb & 7) * 2);
            if (pbVar21 < pbVar4) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100b68;
              func_0x(pbVar4,0x19);
              uVar11 = (ulonglong)uVar16;
              pbVar23 = *(byte **)(&stack0x00000028 + lVar10);
              uVar22 = *(uint *)((longlong)&uStackX_20 + lVar10 + 4);
            }
            if (uVar29 - uVar19 <
                (((uVar8 & 0x7ff) * 2 - (int)uVar11) - *(int *)(&stack0x00000028 + lVar10)) +
                (int)pbVar21) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100ba5;
              func_0x(pbVar23 + uVar11,0x19);
              uVar11 = (ulonglong)uVar16;
              pbVar23 = *(byte **)(&stack0x00000028 + lVar10);
              uVar22 = *(uint *)((longlong)&uStackX_20 + lVar10 + 4);
            }
            if (((uVar8 & 0x3800) != 0) &&
               (puVar27 = (ushort *)(pbVar23 + uVar11 + 4), (uVar8 & 0x3800) != 0)) {
              do {
                if ((uVar8 & 0x7ff) < (*puVar27 & 0x7ff)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100c05;
                  func_0x(pbVar23 + uVar11,0x1a);
                  uVar11 = (ulonglong)uVar16;
                  pbVar23 = *(byte **)(&stack0x00000028 + lVar10);
                }
                uVar22 = (int)ppbVar18 + 1;
                ppbVar18 = (byte **)(ulonglong)uVar22;
                puVar27 = puVar27 + 1;
              } while ((int)uVar22 < (int)((uVar8 & 0x3800) >> 0xb));
              uVar22 = *(uint *)((longlong)&uStackX_20 + lVar10 + 4);
            }
            break;
          }
          if (*(ushort *)(pbVar23 + uVar19) < 0x400) break;
          puVar5 = (ushort *)((longlong)&uStackX_20 + lVar10 + 2);
          *puVar5 = *puVar5 | 1;
          uVar16 = sVar26 - 1;
          uVar11 = (ulonglong)uVar16;
          *(ushort *)(&stack0x0000003c + lVar10) = uVar16;
          if (uVar16 == 0) break;
        }
      }
      if ((*pbVar23 & 0x40) != 0) {
        *(uint *)((longlong)&uStackX_20 + lVar10 + 4) = uVar22 + 0xe;
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100c56;
        uVar14 = func_0x((longlong)&uStackX_20 + lVar10 + 2);
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100c63;
        func_0x(uVar14,(longlong)&iStackX_10 + lVar10);
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100c6d;
        iVar9 = func_0x((longlong)&iStackX_10 + lVar10);
        pbVar23 = *(byte **)(&stack0x00000028 + lVar10);
        uVar22 = *(int *)((longlong)&uStackX_20 + lVar10 + 4) + iVar9;
        *(uint *)((longlong)&uStackX_20 + lVar10 + 4) = uVar22;
      }
      if ((*(byte **)(&stack0x0000003e + lVar10) != (byte *)0x0) &&
         (*(byte **)(&stack0x0000003e + lVar10) < pbVar23 + uVar22)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100ca9;
        cVar7 = func_0x(0x1ac5060);
        if (cVar7 != '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100cb2;
          lVar13 = func_0x();
          if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100ccb;
            cVar7 = func_0x(0x1ac5060);
            if (cVar7 == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100ce7;
              (*pcRam0000000001032be8)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100d0d;
              (*pcRam0000000001032be0)(1,0x13b4a6c,0x14d4b58,0x886);
            }
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100d1c;
        func_0x(*(undefined8 *)(&stack0x00000028 + lVar10),0x12);
        pbVar23 = *(byte **)(&stack0x00000028 + lVar10);
        uVar22 = *(uint *)((longlong)&uStackX_20 + lVar10 + 4);
      }
      if (0x3f3b < uVar22 - 1) {
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100d3f;
        cVar7 = func_0x(0x1ac5060);
        if (cVar7 != '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100d48;
          lVar13 = func_0x();
          if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100d61;
            cVar7 = func_0x(0x1ac5060);
            if (cVar7 == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100d7d;
              (*pcRam0000000001032be8)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100da3;
              (*pcRam0000000001032be0)(1,0x13b4a6c,0x14d4b58,0x88b);
            }
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100db2;
        func_0x(*(undefined8 *)(&stack0x00000028 + lVar10),5);
        pbVar23 = *(byte **)(&stack0x00000028 + lVar10);
        uVar22 = *(uint *)((longlong)&uStackX_20 + lVar10 + 4);
      }
    }
code_r0x00100dbb:
    if ((uVar22 < 9) && (((*pbVar23 & 0xe) == 0 || ((*pbVar23 & 0xe) == 0xc)))) {
      uVar19 = 9;
      goto code_r0x00100e04;
    }
  }
  else {
    if (uVar22 == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100de1;
      func_0x((longlong)&uStackX_20 + lVar10 + 2);
      pbVar23 = *(byte **)(&stack0x00000028 + lVar10);
      uVar22 = *(uint *)((longlong)&uStackX_20 + lVar10 + 4);
    }
    if ((uVar22 < 9) && (((*pbVar23 & 0x1c) == 0 || ((*pbVar23 & 0x1c) == 0xc))))
    goto code_r0x00100e04;
  }
  uVar19 = uVar22;
code_r0x00100e04:
  if (0x7ff < uVar19) {
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100e33;
    (*pcRam0000000001032be0)(1,0x156d7a0,0x1539dd8,0x580);
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100e47;
  func_0x(auStack_3898,uVar28);
  plVar6 = &lStackX_18;
  while (iStackX_10 != 0) {
    iStackX_10 = iStackX_10 + -1;
    iVar9 = *(int *)plVar6;
    lVar13 = plVar6[1];
    iVar3 = *(int *)(plVar6 + 2);
    if (0x3b < iVar9) {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100e9e;
      (*pcRam0000000001032be0)(1,0x156d7c8,0x1539dd8,0x58e);
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100eaf;
    func_0x(auStack_3898,iVar9,lVar13,iVar3);
    plVar6 = plVar6 + 3;
  }
  iStackX_10 = -1;
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100ecd;
  func_0x(uVar28,auStack_3898);
  *(undefined4 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100ee3;
  func_0x(*(undefined8 *)((longlong)&lStackX_18 + lVar10));
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100ef2;
  func_0x(uStack_58 ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar10));
  return;
}

