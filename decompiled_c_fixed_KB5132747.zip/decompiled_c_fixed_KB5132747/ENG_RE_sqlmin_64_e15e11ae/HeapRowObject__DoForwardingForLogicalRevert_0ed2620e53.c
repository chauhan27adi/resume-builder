
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2,short *param_3,undefined4 param_4,
                 undefined4 param_5)

{
  uint uVar1;
  byte *pbVar2;
  code *pcVar3;
  ushort *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  short *psVar7;
  char cVar8;
  byte bVar9;
  char cVar10;
  ushort uVar11;
  ushort uVar12;
  undefined2 uVar13;
  uint uVar14;
  undefined4 uVar15;
  int iVar16;
  longlong lVar17;
  longlong lVar18;
  longlong lVar19;
  undefined8 uVar20;
  longlong *plVar21;
  undefined4 *puVar22;
  ulonglong *puVar23;
  longlong lVar24;
  int *piVar25;
  undefined8 uVar26;
  undefined4 *puVar27;
  byte bVar28;
  undefined4 *puVar29;
  uint uVar30;
  ulonglong uVar31;
  undefined8 unaff_RBX;
  uint uVar32;
  uint uVar33;
  ulonglong uVar34;
  ulonglong uVar35;
  int iVar36;
  ushort *puVar37;
  ushort *puVar38;
  bool bVar39;
  longlong alStackX_8 [4];
  int iStack_5318;
  char cStack_52ff;
  char cStack_52fe;
  longlong lStack_52f8;
  longlong *plStack_52e8;
  undefined auStack_52d8 [8];
  undefined auStack_52d0 [4];
  ushort uStack_52cc;
  ushort uStack_52ca;
  longlong lStack_52c8;
  undefined4 uStack_52c0;
  uint uStack_52b8;
  undefined4 uStack_52b4;
  undefined4 uStack_52b0;
  undefined4 uStack_52ac;
  longlong *plStack_52a8;
  longlong lStack_52a0;
  undefined auStack_5298 [8];
  short *psStack_5290;
  undefined2 *puStack_5288;
  undefined *puStack_5280;
  undefined4 uStack_5278;
  undefined *puStack_5270;
  short *psStack_5268;
  undefined2 *puStack_5260;
  undefined *puStack_5258;
  undefined4 uStack_5250;
  undefined *puStack_5248;
  undefined auStack_5240 [6];
  undefined auStack_523a [6];
  undefined auStack_5234 [8];
  undefined auStack_522c [12];
  undefined2 auStack_5220 [2];
  undefined4 uStack_521c;
  undefined8 uStack_5218;
  undefined8 uStack_5210;
  undefined8 uStack_5202;
  undefined8 uStack_51f8;
  undefined2 auStack_51e8 [2];
  undefined4 uStack_51e4;
  undefined8 uStack_51e0;
  undefined8 uStack_51d8;
  undefined8 uStack_51ca;
  undefined8 uStack_51c0;
  undefined auStack_51b0 [16];
  undefined auStack_51a0 [8];
  undefined auStack_5198 [16];
  undefined auStack_5188 [16];
  undefined auStack_5178 [8];
  undefined8 uStack_5170;
  undefined auStack_5158 [16];
  undefined4 uStack_5148;
  undefined uStack_5138;
  undefined auStack_5130 [8];
  undefined auStack_5128 [16];
  undefined auStack_5118 [36];
  undefined8 uStack_50f4;
  undefined4 uStack_50e4;
  byte bStack_50b8;
  uint uStack_50b0;
  undefined4 uStack_50ac;
  undefined4 uStack_50a8;
  undefined4 uStack_50a4;
  ulonglong auStack_4fb8 [32];
  undefined4 auStack_4eb8 [64];
  undefined4 auStack_4db8 [64];
  undefined4 auStack_4cb8 [64];
  undefined4 auStack_4bb8 [64];
  undefined auStack_4ab8 [14];
  undefined uStack_4aaa;
  undefined auStack_4aa8 [32];
  undefined8 *puStack_4a88;
  longlong *plStack_4a80;
  undefined4 uStack_4a78;
  undefined4 uStack_4a74;
  undefined4 uStack_4a70;
  undefined4 uStack_4a6c;
  undefined4 uStack_4a68;
  longlong *plStack_4a60;
  undefined uStack_4a58;
  uint uStack_4a54;
  undefined8 uStack_4a40;
  undefined4 uStack_4a1c;
  byte bStack_4a18;
  undefined8 auStack_4a10 [2];
  undefined4 uStack_4a00;
  undefined auStack_49f8 [12];
  undefined4 uStack_49ec;
  byte bStack_49e8;
  undefined8 auStack_49e0 [2];
  undefined4 uStack_49d0;
  int iStack_49c8;
  undefined8 uStack_49c0;
  longlong lStack_49b8;
  undefined2 uStack_49b0;
  undefined4 uStack_49ac;
  undefined8 uStack_49a8;
  undefined8 uStack_49a0;
  undefined8 uStack_4992;
  undefined8 uStack_4988;
  undefined4 uStack_497c;
  undefined2 uStack_4900;
  undefined4 uStack_48fc;
  undefined8 uStack_48f8;
  undefined8 uStack_48f0;
  undefined8 uStack_48e2;
  undefined8 uStack_48d8;
  undefined4 uStack_48cc;
  undefined4 uStack_4848;
  undefined8 uStack_4838;
  undefined8 uStack_4830;
  undefined8 uStack_4828;
  undefined4 uStack_4818;
  undefined2 uStack_4814;
  undefined8 uStack_4812;
  undefined uStack_480a;
  undefined auStack_4808 [16];
  undefined2 uStack_47f8;
  undefined4 uStack_47f4;
  undefined8 uStack_47f0;
  undefined8 uStack_47e8;
  undefined8 uStack_47da;
  undefined8 uStack_47d0;
  undefined8 uStack_47c0;
  undefined8 uStack_47a8;
  undefined4 uStack_47a0;
  undefined2 uStack_4796;
  undefined auStack_4788 [9120];
  undefined auStack_23e8 [9120];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar17 = func_0x();
  lVar17 = -lVar17;
  uStack_5170 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00005370 + lVar17) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar17);
  *(undefined4 *)(&stack0x0000003c + lVar17) = param_4;
  *(short **)(&stack0x00000040 + lVar17) = param_2;
  plStack_52e8 = *(longlong **)(*(longlong *)(param_1 + 0x28) + 8);
  iVar36 = 0;
  plStack_4a60 = (longlong *)0x0;
  uStack_4a58 = 0;
  uStack_4a54 = 0;
  uStack_4a40 = 0;
  uStack_4a1c = 0;
  bStack_4a18 = 0;
  auStack_4a10[0] = 0;
  uStack_4a00 = 0;
  uStack_49ec = 0;
  bStack_49e8 = 0;
  auStack_49e0[0] = 0;
  uStack_49d0 = 0;
  iStack_49c8 = 0;
  uStack_49b0 = 0xffff;
  uStack_49a8 = 0;
  uStack_49ac = 0;
  uStack_4992 = 0;
  uStack_4988 = 0;
  uStack_49a0 = 0;
  uStack_497c = 0xffffffff;
  uStack_4900 = 0xffff;
  uStack_48f8 = 0;
  uStack_48fc = 0;
  uStack_48e2 = 0;
  uStack_48d8 = 0;
  uStack_48f0 = 0;
  uStack_48cc = 0xffffffff;
  uStack_4818 = 0;
  uStack_4814 = 0;
  auStack_4808 = ZEXT816(0);
  uStack_47f8 = 0xffff;
  uStack_47f0 = 0;
  uStack_47f4 = 0;
  uStack_47da = 0;
  uStack_47d0 = 0;
  uStack_47e8 = 0;
  uStack_47c0 = 0;
  uStack_47a8 = 0;
  uStack_47a0 = 0;
  uStack_4796 = 0;
  auStack_5220[0] = 0xffff;
  uStack_5218 = 0;
  uStack_521c = 0;
  uStack_5202 = 0;
  uStack_51f8 = 0;
  uStack_5210 = 0;
  auStack_51e8[0] = 0xffff;
  uStack_51e0 = 0;
  uStack_51e4 = 0;
  uStack_51ca = 0;
  uStack_51c0 = 0;
  uStack_51d8 = 0;
  lStack_52c8 = param_1;
  if (*param_3 == 0) {
    if (*(int *)(param_3 + 2) == 0) {
      param_3[1] = 0;
      uVar30 = *(uint *)(param_3 + 8);
      uVar31 = (ulonglong)uVar30;
      *(uint *)(param_3 + 10) = uVar30;
      pbVar2 = *(byte **)(param_3 + 4);
      bVar28 = *pbVar2;
      if ((bVar28 & 0x10) != 0) {
        uVar30 = uVar30 + 2 + (*(ushort *)(pbVar2 + uVar31) + 7 >> 3);
        uVar31 = (ulonglong)uVar30;
        *(uint *)(param_3 + 10) = uVar30;
        bVar28 = *pbVar2;
      }
      if ((bVar28 & 0x20) == 0) {
        *(int *)(param_3 + 2) = (int)uVar31;
        param_3[0xe] = 0;
        *(uint *)(param_3 + 0xc) = uVar30;
      }
      else {
        puVar37 = (ushort *)(pbVar2 + uVar31);
        uVar11 = *puVar37;
        param_3[0xe] = uVar11;
        if (uVar11 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10024a;
          cVar8 = func_0x(0x1fb4e30);
          if (cVar8 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100253;
            lVar18 = func_0x();
            if ((lVar18 != 0) && (*(char *)(lVar18 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10026d;
              cVar8 = func_0x(0x1fb4e30);
              if (cVar8 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100289;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1002af;
                (*_DAT_)(1,0x18a483c,0x19c4928,0x80f);
              }
            }
          }
          uVar20 = *(undefined8 *)(param_3 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1002bd;
          func_0x(uVar20,3);
          uVar11 = param_3[0xe];
          uVar30 = *(uint *)(param_3 + 10);
        }
        uVar30 = uVar30 + (uVar11 + 1) * 2;
        *(uint *)(param_3 + 0xc) = uVar30;
        if (0x1f9e < uVar30) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1002f1;
          cVar8 = func_0x(0x1fb4e30);
          if (cVar8 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1002fa;
            lVar18 = func_0x();
            if ((lVar18 != 0) && (*(char *)(lVar18 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100314;
              cVar8 = func_0x(0x1fb4e30);
              if (cVar8 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100330;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100356;
                (*_DAT_)(1,0x18a483c,0x19c4928,0x816);
              }
            }
          }
          uVar20 = *(undefined8 *)(param_3 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100364;
          func_0x(uVar20,4);
          uVar11 = param_3[0xe];
          uVar30 = *(uint *)(param_3 + 0xc);
        }
        uVar31 = (ulonglong)uVar11;
        uVar11 = puVar37[uVar31];
        *(uint *)(param_3 + 2) = uVar11 & 0x7fff;
        if ((uVar11 & 0x7fff) < uVar30) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100394;
          cVar8 = func_0x(0x1fb4e30);
          if (cVar8 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10039d;
            lVar18 = func_0x();
            if ((lVar18 != 0) && (*(char *)(lVar18 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1003b7;
              cVar8 = func_0x(0x1fb4e30);
              if (cVar8 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1003d3;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1003f9;
                (*_DAT_)(1,0x18a483c,0x19c4928,0x81d);
              }
            }
          }
          uVar20 = *(undefined8 *)(param_3 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100407;
          func_0x(uVar20,4);
          uVar30 = *(uint *)(param_3 + 0xc);
          uVar31 = (ulonglong)(ushort)param_3[0xe];
        }
        puVar38 = puVar37;
        if ((short)uVar31 != 0) {
          do {
            uVar32 = puVar38[1] & 0x7fff;
            if ((uVar32 < uVar30) || (*(uint *)(param_3 + 2) < uVar32)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100450;
              cVar8 = func_0x(0x1fb4e30);
              if (cVar8 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100459;
                lVar18 = func_0x();
                if ((lVar18 != 0) && (*(char *)(lVar18 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100473;
                  cVar8 = func_0x(0x1fb4e30);
                  if (cVar8 == '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10048f;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1004b5;
                    (*_DAT_)(1,0x18a483c,0x19c4928,0x82a);
                  }
                }
              }
              uVar20 = *(undefined8 *)(param_3 + 4);
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1004c3;
              func_0x(uVar20,4);
            }
            iVar36 = iVar36 + 1;
            uVar31 = (ulonglong)(ushort)param_3[0xe];
            puVar38 = puVar38 + 1;
            uVar30 = uVar32;
          } while (iVar36 < (int)(uint)(ushort)param_3[0xe]);
          param_2 = *(short **)(&stack0x00000040 + lVar17);
        }
        if ((short)puVar37[(ulonglong)((int)uVar31 - 1) + 1] < 0) {
          do {
            lVar18 = *(longlong *)(param_3 + 4);
            lVar19 = (ulonglong)*(uint *)(param_3 + 10) + lVar18;
            uVar30 = *(ushort *)(lVar19 + uVar31 * 2) & 0x7fff;
            if ((int)uVar31 == 1) {
              uVar32 = *(uint *)(param_3 + 0xc);
              uVar31 = (ulonglong)uVar32;
LAB_:
              if ((uVar30 < (uint)uVar31) || (uVar33 = *(uint *)(param_3 + 2), uVar33 < uVar30))
              goto LAB_;
            }
            else {
              uVar33 = *(ushort *)(lVar19 + -2 + uVar31 * 2) & 0x7fff;
              uVar31 = (ulonglong)uVar33;
              uVar32 = *(uint *)(param_3 + 0xc);
              if (uVar32 <= uVar33) goto LAB_;
LAB_:
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100551;
              func_0x(lVar18,7);
              uVar32 = *(uint *)(param_3 + 0xc);
              uVar33 = *(uint *)(param_3 + 2);
            }
            uVar14 = (uint)uVar31;
            if ((uVar14 < uVar32) || (uVar33 < uVar14)) goto LAB_;
            if (*(ushort *)(uVar31 + *(longlong *)(param_3 + 4)) == 5) {
              param_3[1] = param_3[1] | 2;
              param_3[0xe] = param_3[0xe] + -1;
              uVar34 = uVar31 & 0xffff;
              param_3[0x15] = (short)uVar31;
              uVar31 = *(ulonglong *)(param_3 + 4);
              uVar11 = param_3[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar34 + 2 + uVar31) >> 0xe & 1) != 0) {
                uVar11 = *(ushort *)(uVar34 + 2 + uVar31) & 0x3800 | param_3[0x16] & 0xc7ffU;
              }
              param_3[0x16] = uVar11;
              uVar12 = (uVar11 ^ *(ushort *)(uVar34 + 2 + uVar31)) & 0x7ff ^ uVar11;
              param_3[0x16] = uVar12;
              uVar35 = (ulonglong)(ushort)param_3[0x15];
              uVar34 = uVar31 + 4 +
                       (ulonglong)((uVar12 & 0x7ff) * 2) + uVar35 + (uVar11 >> 0xb & 7) * 2;
              if (uVar34 < uVar35 + uVar31) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100661;
                func_0x(uVar35 + uVar31,0x19);
                uVar12 = param_3[0x16];
                uVar35 = (ulonglong)(ushort)param_3[0x15];
                uVar31 = (ulonglong)*(uint *)(param_3 + 4);
              }
              if (uVar30 - uVar14 <
                  (((uVar12 & 0x7ff) * 2 - (int)uVar35) - (int)uVar31) + (int)uVar34) {
                lVar18 = *(longlong *)(param_3 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100699;
                func_0x(uVar35 + lVar18,0x19);
                uVar12 = param_3[0x16];
              }
              if ((uVar12 & 0x3800) != 0) {
                puVar37 = (ushort *)
                          (*(longlong *)(param_3 + 4) + (ulonglong)(ushort)param_3[0x15] + 4);
                iVar36 = 0;
                if ((uVar12 & 0x3800) != 0) {
                  do {
                    if ((uVar12 & 0x7ff) < (*puVar37 & 0x7ff)) {
                      uVar11 = param_3[0x15];
                      lVar18 = *(longlong *)(param_3 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1006f8;
                      func_0x((ulonglong)uVar11 + lVar18,0x1a);
                      uVar12 = param_3[0x16];
                    }
                    iVar36 = iVar36 + 1;
                    puVar37 = puVar37 + 1;
                  } while (iVar36 < (int)(uVar12 >> 0xb & 7));
                }
              }
              break;
            }
            if (*(ushort *)(uVar31 + *(longlong *)(param_3 + 4)) < 0x400) break;
            param_3[1] = param_3[1] | 1;
            uVar11 = param_3[0xe] - 1;
            param_3[0xe] = uVar11;
            if ((uVar11 == 0) ||
               (uVar31 = (ulonglong)uVar11, -1 < (short)puVar37[(ulonglong)(uVar11 - 1) + 1]))
            break;
          } while( true );
        }
      }
      if ((**(byte **)(param_3 + 4) & 0x40) == 0) {
        *(undefined4 *)(param_3 + 0x13) = 0;
      }
      else {
        *(int *)(param_3 + 0x13) = *(int *)(param_3 + 2);
        *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + 0xe;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100744;
        uVar20 = func_0x(param_3 + 1);
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100751;
        func_0x(uVar20,&stack0x00000040 + lVar17);
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10075b;
        iVar36 = func_0x(&stack0x00000040 + lVar17);
        *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + iVar36;
      }
      uVar30 = *(uint *)(param_3 + 2);
      if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
         (*(ulonglong *)(param_3 + 0xf) < (ulonglong)uVar30 + *(longlong *)(param_3 + 4))) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100795;
        cVar8 = func_0x(0x1fb4e30);
        if (cVar8 != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10079e;
          lVar18 = func_0x();
          if ((lVar18 != 0) && (*(char *)(lVar18 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1007b8;
            cVar8 = func_0x(0x1fb4e30);
            if (cVar8 == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1007d4;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1007fa;
              (*_DAT_)(1,0x18a483c,0x19c4928,0x886);
            }
          }
        }
        uVar20 = *(undefined8 *)(param_3 + 4);
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100808;
        func_0x(uVar20,0x12);
        uVar30 = *(uint *)(param_3 + 2);
      }
      if (0x3f3b < uVar30 - 1) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100826;
        cVar8 = func_0x(0x1fb4e30);
        if (cVar8 != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10082f;
          lVar18 = func_0x();
          if ((lVar18 != 0) && (*(char *)(lVar18 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100849;
            cVar8 = func_0x(0x1fb4e30);
            if (cVar8 == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100865;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
              uVar20 = *(undefined8 *)(param_3 + 4);
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100873;
              func_0x(uVar20,5);
              goto LAB_;
            }
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100899;
            (*_DAT_)(1,0x18a483c,0x19c4928,0x88b);
          }
        }
        uVar20 = *(undefined8 *)(param_3 + 4);
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1008a7;
        func_0x(uVar20,5);
      }
    }
  }
  else if (*(int *)(param_3 + 2) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1008b9;
    func_0x(param_3 + 1);
  }
LAB_:
  iStack_5318 = 0;
  pcVar3 = *(code **)(*plStack_52e8 + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1008d2;
  cVar8 = (*pcVar3)(plStack_52e8);
  if (cVar8 == '\0') {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1008fa;
    (*_DAT_)(1,0x1a53bc8,0x1a29158,0x1376);
  }
  puStack_5288 = auStack_5220;
  puStack_5280 = auStack_4788;
  uStack_5278 = 0x239e;
  puStack_5270 = auStack_4808;
  *(byte *)(lStack_52c8 + 0x531) = *(byte *)(lStack_52c8 + 0x531) & 0xfd;
  puStack_5260 = auStack_51e8;
  puStack_5258 = auStack_23e8;
  uStack_5250 = 0x239e;
  puStack_5248 = auStack_4808;
  *(uint *)(lStack_52c8 + 0x634) = *(uint *)(lStack_52c8 + 0x634) | 1;
  puStack_4a88 = *(undefined8 **)(lStack_52c8 + 0x20);
  *(int *)((longlong)puStack_4a88 + 0x44) = *(int *)((longlong)puStack_4a88 + 0x44) + 1;
  uStack_49c0 = 0;
  uStack_4a78 = _DAT_;
  uStack_4a74 = uRam0000000001fe08dc;
  uStack_4a70 = _DAT_;
  uStack_4a6c = uRam0000000001fe08e4;
  uStack_4a68 = 0xffffffff;
  uStack_4848 = 0;
  uStack_4830 = 0;
  uStack_4838 = 0;
  uStack_4828 = 0;
  uStack_4818 = 0xffffffff;
  uStack_4814 = 0xffff;
  uStack_4812 = 0;
  uStack_480a = 0;
  plStack_4a80 = *(longlong **)(lStack_52c8 + 0x28);
  lStack_49b8 = puStack_4a88[9] + 0x28;
  iStack_49c8 = 2;
  uVar30 = *(uint *)(&stack0x0000003c + lVar17) & 4;
  *(uint *)(&stack0x0000003c + lVar17) = uVar30;
  puVar22 = (undefined4 *)(lStack_52c8 + 0x530);
  *(undefined4 **)(&stack0x00000040 + lVar17) = puVar22;
  lVar18 = lStack_52c8;
  psStack_5290 = param_2;
  psStack_5268 = param_3;
  do {
    pcVar3 = *(code **)(*plStack_52e8 + 0x1e8);
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100a30;
    plVar21 = (longlong *)(*pcVar3)(plStack_52e8);
    if ((uVar30 == 0) && (plVar21 != (longlong *)0x0)) {
      pcVar3 = *(code **)(*plVar21 + 0x88);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100a46;
      cVar8 = (*pcVar3)(plVar21);
      if (cVar8 == '\0') goto LAB_;
      bVar28 = 4;
    }
    else {
LAB_:
      bVar28 = 0;
    }
    *(byte *)(lVar18 + 0x531) = *(byte *)(lVar18 + 0x531) & 0xfb;
    *(byte *)(lVar18 + 0x531) = *(byte *)(lVar18 + 0x531) | bVar28;
    lVar18 = 2;
    puVar27 = puVar22;
    puVar23 = auStack_4fb8;
    do {
      uVar15 = puVar27[1];
      uVar5 = puVar27[2];
      uVar6 = puVar27[3];
      *(undefined4 *)puVar23 = *puVar27;
      *(undefined4 *)((longlong)puVar23 + 4) = uVar15;
      *(undefined4 *)(puVar23 + 1) = uVar5;
      *(undefined4 *)((longlong)puVar23 + 0xc) = uVar6;
      uVar15 = puVar27[5];
      uVar5 = puVar27[6];
      uVar6 = puVar27[7];
      *(undefined4 *)(puVar23 + 2) = puVar27[4];
      *(undefined4 *)((longlong)puVar23 + 0x14) = uVar15;
      *(undefined4 *)(puVar23 + 3) = uVar5;
      *(undefined4 *)((longlong)puVar23 + 0x1c) = uVar6;
      uVar15 = puVar27[9];
      uVar5 = puVar27[10];
      uVar6 = puVar27[0xb];
      *(undefined4 *)(puVar23 + 4) = puVar27[8];
      *(undefined4 *)((longlong)puVar23 + 0x24) = uVar15;
      *(undefined4 *)(puVar23 + 5) = uVar5;
      *(undefined4 *)((longlong)puVar23 + 0x2c) = uVar6;
      uVar15 = puVar27[0xd];
      uVar5 = puVar27[0xe];
      uVar6 = puVar27[0xf];
      *(undefined4 *)(puVar23 + 6) = puVar27[0xc];
      *(undefined4 *)((longlong)puVar23 + 0x34) = uVar15;
      *(undefined4 *)(puVar23 + 7) = uVar5;
      *(undefined4 *)((longlong)puVar23 + 0x3c) = uVar6;
      uVar15 = puVar27[0x11];
      uVar5 = puVar27[0x12];
      uVar6 = puVar27[0x13];
      *(undefined4 *)(puVar23 + 8) = puVar27[0x10];
      *(undefined4 *)((longlong)puVar23 + 0x44) = uVar15;
      *(undefined4 *)(puVar23 + 9) = uVar5;
      *(undefined4 *)((longlong)puVar23 + 0x4c) = uVar6;
      uVar15 = puVar27[0x15];
      uVar5 = puVar27[0x16];
      uVar6 = puVar27[0x17];
      *(undefined4 *)(puVar23 + 10) = puVar27[0x14];
      *(undefined4 *)((longlong)puVar23 + 0x54) = uVar15;
      *(undefined4 *)(puVar23 + 0xb) = uVar5;
      *(undefined4 *)((longlong)puVar23 + 0x5c) = uVar6;
      uVar15 = puVar27[0x19];
      uVar5 = puVar27[0x1a];
      uVar6 = puVar27[0x1b];
      *(undefined4 *)(puVar23 + 0xc) = puVar27[0x18];
      *(undefined4 *)((longlong)puVar23 + 100) = uVar15;
      *(undefined4 *)(puVar23 + 0xd) = uVar5;
      *(undefined4 *)((longlong)puVar23 + 0x6c) = uVar6;
      uVar15 = puVar27[0x1d];
      uVar5 = puVar27[0x1e];
      uVar6 = puVar27[0x1f];
      *(undefined4 *)(puVar23 + 0xe) = puVar27[0x1c];
      *(undefined4 *)((longlong)puVar23 + 0x74) = uVar15;
      *(undefined4 *)(puVar23 + 0xf) = uVar5;
      *(undefined4 *)((longlong)puVar23 + 0x7c) = uVar6;
      puVar27 = puVar27 + 0x20;
      lVar18 = lVar18 + -1;
      puVar23 = puVar23 + 0x10;
    } while (lVar18 != 0);
    if (iStack_49c8 != 4) {
      if ((auStack_4fb8[0] >> 8 & 4) == 0) {
        lVar18 = 2;
        puVar27 = (undefined4 *)&bStack_50b8;
        do {
          uVar15 = puVar22[1];
          uVar5 = puVar22[2];
          uVar6 = puVar22[3];
          *puVar27 = *puVar22;
          puVar27[1] = uVar15;
          puVar27[2] = uVar5;
          puVar27[3] = uVar6;
          uVar15 = puVar22[5];
          uVar5 = puVar22[6];
          uVar6 = puVar22[7];
          puVar27[4] = puVar22[4];
          puVar27[5] = uVar15;
          puVar27[6] = uVar5;
          puVar27[7] = uVar6;
          uVar15 = puVar22[9];
          uVar5 = puVar22[10];
          uVar6 = puVar22[0xb];
          puVar27[8] = puVar22[8];
          puVar27[9] = uVar15;
          puVar27[10] = uVar5;
          puVar27[0xb] = uVar6;
          uVar15 = puVar22[0xd];
          uVar5 = puVar22[0xe];
          uVar6 = puVar22[0xf];
          puVar27[0xc] = puVar22[0xc];
          puVar27[0xd] = uVar15;
          puVar27[0xe] = uVar5;
          puVar27[0xf] = uVar6;
          uVar15 = puVar22[0x11];
          uVar5 = puVar22[0x12];
          uVar6 = puVar22[0x13];
          puVar27[0x10] = puVar22[0x10];
          puVar27[0x11] = uVar15;
          puVar27[0x12] = uVar5;
          puVar27[0x13] = uVar6;
          uVar15 = puVar22[0x15];
          uVar5 = puVar22[0x16];
          uVar6 = puVar22[0x17];
          puVar27[0x14] = puVar22[0x14];
          puVar27[0x15] = uVar15;
          puVar27[0x16] = uVar5;
          puVar27[0x17] = uVar6;
          uVar15 = puVar22[0x19];
          uVar5 = puVar22[0x1a];
          uVar6 = puVar22[0x1b];
          puVar27[0x18] = puVar22[0x18];
          puVar27[0x19] = uVar15;
          puVar27[0x1a] = uVar5;
          puVar27[0x1b] = uVar6;
          uVar15 = puVar22[0x1d];
          uVar5 = puVar22[0x1e];
          uVar6 = puVar22[0x1f];
          puVar27[0x1c] = puVar22[0x1c];
          puVar27[0x1d] = uVar15;
          puVar27[0x1e] = uVar5;
          puVar27[0x1f] = uVar6;
          puVar22 = puVar22 + 0x20;
          lVar18 = lVar18 + -1;
          puVar27 = puVar27 + 0x20;
        } while (lVar18 != 0);
        iVar36 = 0;
        uStack_5148 = 0;
        uStack_5138 = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100b60;
        func_0x(auStack_4aa8);
        uStack_50f4 = 0;
        uStack_50e4 = 0;
        lStack_52a0 = *plStack_4a80;
        lVar18 = *(longlong *)(lStack_52a0 + 8);
        plVar21 = (longlong *)plStack_4a80[1];
        pcVar3 = *(code **)(*plVar21 + 0x58);
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100b9d;
        plStack_52a8 = plVar21;
        (*pcVar3)(plVar21);
        uStack_4aaa = 1;
        uStack_52c0 = uStack_52c0 & 0xfffffffc;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100bb1;
        func_0x(&uStack_52b8);
        uVar32 = uStack_50b0;
        psVar7 = psStack_5290;
        uStack_52b8 = uStack_50b0;
        uStack_52b4 = uStack_50ac;
        uStack_52b0 = uStack_50a8;
        uStack_52ac = uStack_50a4;
        bVar28 = bStack_50b8 & 1;
        uStack_52c0 = CONCAT31(uStack_52c0._1_3_,
                               bStack_50b8 >> 6 & 2 | (byte)uStack_52c0 & 0xfc | bVar28);
        puVar37 = (ushort *)(psStack_5290 + 1);
        uVar30 = *(uint *)(psStack_5290 + 2);
        if (*psStack_5290 == 0) {
          if (uVar30 == 0) {
            *puVar37 = 0;
            uVar30 = *(uint *)(psStack_5290 + 8);
            uVar31 = (ulonglong)uVar30;
            *(uint *)(psStack_5290 + 10) = uVar30;
            pbVar2 = *(byte **)(psStack_5290 + 4);
            bVar9 = *pbVar2;
            if ((bVar9 & 0x10) != 0) {
              uVar30 = uVar30 + 2 + (*(ushort *)(pbVar2 + uVar31) + 7 >> 3);
              uVar31 = (ulonglong)uVar30;
              *(uint *)(psStack_5290 + 10) = uVar30;
              bVar9 = *pbVar2;
            }
            if ((bVar9 & 0x20) == 0) {
              *(int *)(psStack_5290 + 2) = (int)uVar31;
              psStack_5290[0xe] = 0;
              *(undefined4 *)(psStack_5290 + 0xc) = *(undefined4 *)(psStack_5290 + 10);
            }
            else {
              puVar38 = (ushort *)(pbVar2 + uVar31);
              uVar11 = *puVar38;
              psStack_5290[0xe] = uVar11;
              if (uVar11 == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100c63;
                cVar8 = func_0x(0x1fb4e30);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100c6c;
                  lVar19 = func_0x();
                  if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100c86;
                    cVar8 = func_0x(0x1fb4e30);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100ca2;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100cc8;
                      (*_DAT_)(1,0x18a483c,0x19c4928,0x80f);
                    }
                  }
                }
                uVar20 = *(undefined8 *)(psVar7 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100cd6;
                func_0x(uVar20,3);
                uVar11 = psVar7[0xe];
              }
              uVar30 = *(int *)(psVar7 + 10) + 2 + (uint)uVar11 * 2;
              *(uint *)(psVar7 + 0xc) = uVar30;
              if (0x1f9e < uVar30) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100cfd;
                cVar8 = func_0x(0x1fb4e30);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100d06;
                  lVar19 = func_0x();
                  if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100d20;
                    cVar8 = func_0x(0x1fb4e30);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100d3c;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100d62;
                      (*_DAT_)(1,0x18a483c,0x19c4928,0x816);
                    }
                  }
                }
                uVar20 = *(undefined8 *)(psVar7 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100d70;
                func_0x(uVar20);
              }
              uVar11 = puVar38[(ushort)psVar7[0xe]];
              *(uint *)(psVar7 + 2) = uVar11 & 0x7fff;
              uVar30 = *(uint *)(psVar7 + 0xc);
              if ((uVar11 & 0x7fff) < uVar30) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100d99;
                cVar8 = func_0x(0x1fb4e30);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100da2;
                  lVar19 = func_0x();
                  if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100dbc;
                    cVar8 = func_0x(0x1fb4e30);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100dd8;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100dfe;
                      (*_DAT_)(1,0x18a483c,0x19c4928,0x81d);
                    }
                  }
                }
                uVar20 = *(undefined8 *)(psVar7 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100e0c;
                func_0x(uVar20);
                uVar30 = *(uint *)(psVar7 + 0xc);
              }
              uVar11 = psVar7[0xe];
              puVar4 = puVar38;
              if (uVar11 != 0) {
                do {
                  uVar33 = puVar4[1] & 0x7fff;
                  if ((uVar33 < uVar30) || (*(uint *)(psVar7 + 2) < uVar33)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100e4e;
                    cVar8 = func_0x(0x1fb4e30);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100e57;
                      lVar19 = func_0x();
                      if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100e71;
                        cVar8 = func_0x(0x1fb4e30);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100e8d;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100eb3;
                          (*_DAT_)(1,0x18a483c,0x19c4928,0x82a);
                        }
                      }
                    }
                    uVar20 = *(undefined8 *)(psVar7 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100ec1;
                    func_0x(uVar20,4);
                  }
                  iVar36 = iVar36 + 1;
                  uVar11 = psVar7[0xe];
                  plVar21 = plStack_52a8;
                  uVar30 = uVar33;
                  puVar4 = puVar4 + 1;
                } while (iVar36 < (int)(uint)uVar11);
              }
              uVar30 = (uint)uVar11;
              if ((short)puVar38[(ulonglong)(uVar30 - 1) + 1] < 0) {
                do {
                  lVar19 = *(longlong *)(psVar7 + 4);
                  uVar33 = *(ushort *)
                            ((ulonglong)*(uint *)(psVar7 + 10) + lVar19 + (ulonglong)uVar30 * 2) &
                           0x7fff;
                  if (uVar30 == 1) {
                    uVar14 = *(uint *)(psVar7 + 0xc);
                    uVar1 = uVar14;
LAB_:
                    if ((uVar33 < uVar14) || (uVar30 = *(uint *)(psVar7 + 2), uVar30 < uVar33))
                    goto LAB_;
                  }
                  else {
                    uVar14 = *(ushort *)
                              ((ulonglong)*(uint *)(psVar7 + 10) + lVar19 + -2 +
                              (ulonglong)uVar30 * 2) & 0x7fff;
                    uVar1 = *(uint *)(psVar7 + 0xc);
                    if (uVar1 <= uVar14) goto LAB_;
LAB_:
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100f41;
                    func_0x(lVar19,7);
                    uVar1 = *(uint *)(psVar7 + 0xc);
                    uVar30 = *(uint *)(psVar7 + 2);
                    lVar19 = *(longlong *)(psVar7 + 4);
                  }
                  if ((uVar14 < uVar1) || (uVar30 < uVar14)) goto LAB_;
                  if (*(ushort *)((ulonglong)uVar14 + lVar19) == 5) {
                    *puVar37 = *puVar37 | 2;
                    psVar7[0xe] = psVar7[0xe] + -1;
                    uVar34 = (ulonglong)(uVar14 & 0xffff);
                    psVar7[0x15] = (short)uVar14;
                    uVar31 = *(ulonglong *)(psVar7 + 4);
                    uVar11 = psVar7[0x16] & 0xc7ffU;
                    if ((*(ushort *)(uVar34 + 2 + uVar31) & 0x4000) != 0) {
                      uVar11 = *(ushort *)(uVar34 + 2 + uVar31) & 0x3800 | psVar7[0x16] & 0xc7ffU;
                    }
                    psVar7[0x16] = uVar11;
                    uVar12 = (uVar11 ^ *(ushort *)(uVar34 + 2 + uVar31)) & 0x7ff ^ uVar11;
                    psVar7[0x16] = uVar12;
                    uVar35 = (ulonglong)(ushort)psVar7[0x15];
                    uVar34 = uVar31 + 4 +
                             (ulonglong)((uVar12 & 0x7ff) * 2) + uVar35 + (uVar11 >> 0xb & 7) * 2;
                    if (uVar34 < uVar35 + uVar31) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1010c8;
                      func_0x(uVar35 + uVar31,0x19);
                      uVar12 = psVar7[0x16];
                      uVar35 = (ulonglong)(ushort)psVar7[0x15];
                      uVar31 = (ulonglong)*(uint *)(psVar7 + 4);
                    }
                    if (uVar33 - uVar14 <
                        (((uVar12 & 0x7ff) * 2 - (int)uVar35) - (int)uVar31) + (int)uVar34) {
                      lVar19 = *(longlong *)(psVar7 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101101;
                      func_0x(uVar35 + lVar19,0x19);
                      uVar12 = psVar7[0x16];
                    }
                    iVar36 = 0;
                    if (((uVar12 & 0x3800) != 0) &&
                       (puVar38 = (ushort *)
                                  (*(longlong *)(psVar7 + 4) + 4 + (ulonglong)(ushort)psVar7[0x15]),
                       (uVar12 & 0x3800) != 0)) {
                      do {
                        if ((uVar12 & 0x7ff) < (*puVar38 & 0x7ff)) {
                          uVar11 = psVar7[0x15];
                          lVar19 = *(longlong *)(psVar7 + 4);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101167;
                          func_0x((ulonglong)uVar11 + lVar19,0x1a);
                          uVar12 = psVar7[0x16];
                        }
                        iVar36 = iVar36 + 1;
                        puVar38 = puVar38 + 1;
                      } while (iVar36 < (int)(uVar12 >> 0xb & 7));
                    }
                    break;
                  }
                  if (*(ushort *)((ulonglong)uVar14 + lVar19) < 0x400) break;
                  *puVar37 = *puVar37 | 1;
                  uVar11 = psVar7[0xe] - 1;
                  psVar7[0xe] = uVar11;
                  if ((uVar11 == 0) ||
                     (uVar30 = (uint)uVar11, -1 < (short)puVar38[(ulonglong)(uVar11 - 1) + 1]))
                  break;
                } while( true );
              }
            }
            iVar36 = 0;
            if ((**(byte **)(psVar7 + 4) & 0x40) == 0) {
              *(undefined4 *)(psVar7 + 0x13) = 0;
            }
            else {
              *(undefined4 *)(psVar7 + 0x13) = *(undefined4 *)(psVar7 + 2);
              *(int *)(psVar7 + 2) = *(int *)(psVar7 + 2) + 0xe;
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100fc7;
              puVar23 = (ulonglong *)func_0x(puVar37);
              uVar31 = *puVar23;
              uVar12 = (ushort)(uVar31 >> 0x30);
              uVar11 = uVar12;
              if ((((uint)(int)(short)uVar12 >> 1 ^ (int)(short)uVar12) & 0x2000) != 0) {
                uVar11 = uVar12 & 0xdfff;
                if ((uVar31 & 0x4000000000000000) != 0) {
                  uVar11 = uVar12 | 0x2000;
                }
              }
              if (uVar11 == 0xfffc) {
                iVar36 = (int)((uVar31 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(psVar7 + 2) = *(int *)(psVar7 + 2) + iVar36;
            }
            uVar30 = *(uint *)(psVar7 + 2);
            if ((*(ulonglong *)(psVar7 + 0xf) != 0) &&
               (*(ulonglong *)(psVar7 + 0xf) < (ulonglong)uVar30 + *(longlong *)(psVar7 + 4))) {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1011d1;
              cVar8 = func_0x(0x1fb4e30);
              if (cVar8 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1011da;
                lVar19 = func_0x();
                if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1011f4;
                  cVar8 = func_0x(0x1fb4e30);
                  if (cVar8 == '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101210;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101236;
                    (*_DAT_)(1,0x18a483c,0x19c4928,0x886);
                  }
                }
              }
              uVar20 = *(undefined8 *)(psVar7 + 4);
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101244;
              func_0x(uVar20,0x12);
              uVar30 = *(uint *)(psVar7 + 2);
            }
            if ((uVar30 == 0) || (0x3f3c < uVar30)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101263;
              cVar8 = func_0x(0x1fb4e30);
              if (cVar8 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10126c;
                lVar19 = func_0x();
                if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101286;
                  cVar8 = func_0x(0x1fb4e30);
                  if (cVar8 == '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1012a2;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1012c8;
                    (*_DAT_)(1,0x18a483c,0x19c4928,0x88b);
                  }
                }
              }
              uVar20 = *(undefined8 *)(psVar7 + 4);
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1012d6;
              func_0x(uVar20,5);
              uVar30 = *(uint *)(psVar7 + 2);
            }
          }
LAB_:
          if (uVar30 < 9) {
            bVar9 = **(byte **)(psVar7 + 4);
            if (((bVar9 & 0xe) != 0) && ((bVar9 & 0xe) != 0xc)) goto LAB_;
            uVar30 = 9;
          }
          else {
LAB_:
            bVar9 = **(byte **)(psVar7 + 4);
          }
          if ((bVar9 & 0x40) != 0) {
            uVar30 = *(uint *)(psVar7 + 0x13);
          }
        }
        else {
          if (uVar30 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101314;
            func_0x(puVar37);
            uVar30 = *(uint *)(psVar7 + 2);
            if (uVar30 == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101323;
              func_0x(puVar37);
              uVar30 = *(uint *)(psVar7 + 2);
            }
          }
          if (uVar30 < 9) {
            bVar9 = **(byte **)(psVar7 + 4);
            if (((bVar9 & 0x1c) != 0) && ((bVar9 & 0x1c) != 0xc)) goto LAB_;
            uVar30 = 9;
          }
          else {
LAB_:
            bVar9 = **(byte **)(psVar7 + 4);
          }
          if ((bVar9 & 2) != 0) {
            uVar30 = *(uint *)(psVar7 + 0x18);
          }
        }
        iVar36 = 0;
        pcVar3 = *(code **)*plVar21;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10135d;
        cVar8 = (*pcVar3)(plVar21);
        if (cVar8 == '\0') {
          if (bVar28 == 0) {
LAB_:
            lVar19 = plVar21[0x1a];
            if ((uVar32 & 1) == 0) {
              pcVar3 = *(code **)*plVar21;
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101aa6;
              cVar8 = (*pcVar3)(plVar21);
              if (cVar8 == '\0') {
                pcVar3 = *(code **)(*plVar21 + 0x88);
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101abb;
                cVar8 = (*pcVar3)(plVar21);
                uVar33 = 0;
                if (cVar8 != '\0') {
                  cStack_52ff = (char)(uVar32 >> 8);
                  if (cStack_52ff != '\0') goto LAB_;
                  if (lVar19 == 0) {
                    pcVar3 = *(code **)(*plVar21 + 0x18);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101adc;
                    cVar8 = (*pcVar3)(plVar21);
                    if (cVar8 == '\0') goto LAB_;
                  }
                  if ((*(byte *)(plVar21 + 0x4a) & 4) == 0) {
                    if ((*(byte *)(plVar21 + 0x4a) & 0x5a) == 0) {
                      if ((*(byte *)(plVar21 + 0x43) & 1) != 0) {
                        if (plVar21[0x1a] == 0) {
                          pcVar3 = *(code **)(*plVar21 + 0x88);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101b24;
                          cVar8 = (*pcVar3)(plVar21);
                          if (cVar8 != '\0') {
                            pcVar3 = *(code **)(*plVar21 + 0x18);
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101b32;
                            cVar8 = (*pcVar3)(plVar21);
                            if (cVar8 == '\0') {
                              *(byte *)(plVar21 + 0x4a) = *(byte *)(plVar21 + 0x4a) | 4;
                              goto LAB_;
                            }
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101b4c;
                        iVar16 = func_0x(plVar21);
                        if (iVar16 == 0) {
                          pcVar3 = *(code **)(*plVar21 + 0x270);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101b5d;
                          (*pcVar3)(plVar21);
                        }
                        if ((*(byte *)(plVar21 + 0x43) & 4) == 0) {
                          if ((*(byte *)(plVar21 + 0x4a) & 0x52) == 2) {
                            lVar24 = plVar21[0x1a];
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101b9b;
                            cVar8 = func_0x(lVar24);
                            if (((cVar8 != '\0') && (*(char *)(plVar21[0x1a] + 0x130) == '\0')) &&
                               (*(undefined *)(plVar21[0x1a] + 0x130) = 1, *_DAT_ != '\0'))
                            {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101be1;
                              func_0x(0x1fb5570,0x1c,0x10,1);
                            }
                          }
                          uVar14 = (uint)((*(byte *)(plVar21 + 0x4a) & 0x5a) != 0);
                        }
                        else {
                          pcVar3 = *(code **)(*plVar21 + 0x1e8);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101b75;
                          uVar20 = (*pcVar3)(plVar21);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101b7d;
                          uVar14 = func_0x(uVar20);
                        }
                        if (uVar14 != 0) goto LAB_;
                      }
                    }
                    else {
LAB_:
                      if (((*(byte *)(plVar21 + 0x4a) & 0x40) != 0) &&
                         (cStack_52fe = (char)(uVar32 >> 0x10), cStack_52fe != '\0'))
                      goto LAB_;
                    }
                  }
                }
LAB_:
                if ((uVar32 & 0x1c) != 0) {
LAB_:
                  if (lVar19 != 0) {
LAB_:
                    if ((uVar32 & 0x1c) == 0) {
                      if (lStack_52f8 != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101e03;
                        iVar16 = func_0x();
                        if (((iVar16 != 0) &&
                            (iVar16 = *(int *)(*(longlong *)(lStack_52f8 + 8) + 0x100), iVar16 != 0)
                            ) && (1 < iVar16 - 3U)) {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101e45;
                          (*_DAT_)(1,0x1a53840,0x1a53890,0x116);
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101e4e;
                        iVar16 = func_0x(lStack_52f8);
                        if (((iVar16 != 0) &&
                            ((*(byte *)(*(longlong *)(lStack_52f8 + 8) + 0x109) & 1) == 0)) &&
                           ((iVar16 = *(int *)(*(longlong *)(lStack_52f8 + 8) + 0x100), iVar16 != 0
                            && (1 < iVar16 - 3U)))) {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101e99;
                          (*_DAT_)(1,0x1a538c0,0x1a53890,0x119);
                        }
                      }
                      if ((*(int *)(lVar19 + 0x78) < 1) && (*(int *)(lVar19 + 0x74) < 1)) {
                        if ((*(byte *)(plVar21 + 0x4a) & 4) == 0) {
                          if ((*(byte *)(plVar21 + 0x4a) & 0x5a) == 0) {
                            if ((*(byte *)(plVar21 + 0x43) & 1) != 0) {
                              if (plVar21[0x1a] == 0) {
                                pcVar3 = *(code **)(*plVar21 + 0x88);
                                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101eed;
                                cVar8 = (*pcVar3)(plVar21);
                                if (cVar8 != '\0') {
                                  pcVar3 = *(code **)(*plVar21 + 0x18);
                                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101efb;
                                  cVar8 = (*pcVar3)(plVar21);
                                  if (cVar8 == '\0') {
                                    *(byte *)(plVar21 + 0x4a) = *(byte *)(plVar21 + 0x4a) | 4;
                                    goto LAB_;
                                  }
                                }
                              }
                              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101f15;
                              iVar16 = func_0x(plVar21);
                              if (iVar16 == 0) {
                                pcVar3 = *(code **)(*plVar21 + 0x270);
                                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101f26;
                                (*pcVar3)(plVar21);
                              }
                              if ((*(byte *)(plVar21 + 0x43) & 4) == 0) {
                                if ((*(byte *)(plVar21 + 0x4a) & 0x52) == 2) {
                                  lVar24 = plVar21[0x1a];
                                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101f64;
                                  cVar8 = func_0x(lVar24);
                                  if (((cVar8 != '\0') && (*(char *)(plVar21[0x1a] + 0x130) == '\0')
                                      ) && (*(undefined *)(plVar21[0x1a] + 0x130) = 1,
                                           *_DAT_ != '\0')) {
                                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101faa;
                                    func_0x(0x1fb5570,0x1c,0x10,1);
                                  }
                                }
                                uVar14 = (uint)((*(byte *)(plVar21 + 0x4a) & 0x5a) != 0);
                              }
                              else {
                                pcVar3 = *(code **)(*plVar21 + 0x1e8);
                                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101f3e;
                                uVar20 = (*pcVar3)(plVar21);
                                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101f46;
                                uVar14 = func_0x(uVar20);
                              }
                              if (uVar14 != 0) goto LAB_;
                            }
                          }
                          else {
LAB_:
                            if ((*(byte *)(plVar21 + 0x4a) & 0x10) != 0) goto LAB_;
                          }
                        }
LAB_:
                        if ((*(byte *)(plVar21 + 0x4a) & 4) == 0) {
                          if ((*(byte *)(plVar21 + 0x4a) & 0x5a) == 0) {
                            if ((*(byte *)(plVar21 + 0x43) & 1) != 0) {
                              if (plVar21[0x1a] == 0) {
                                pcVar3 = *(code **)(*plVar21 + 0x88);
                                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10200c;
                                cVar8 = (*pcVar3)(plVar21);
                                if (cVar8 != '\0') {
                                  pcVar3 = *(code **)(*plVar21 + 0x18);
                                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10201a;
                                  cVar8 = (*pcVar3)(plVar21);
                                  if (cVar8 == '\0') {
                                    *(byte *)(plVar21 + 0x4a) = *(byte *)(plVar21 + 0x4a) | 4;
                                    goto LAB_;
                                  }
                                }
                              }
                              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102034;
                              iVar16 = func_0x(plVar21);
                              if (iVar16 == 0) {
                                pcVar3 = *(code **)(*plVar21 + 0x270);
                                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102045;
                                (*pcVar3)(plVar21);
                              }
                              if ((*(byte *)(plVar21 + 0x43) & 4) == 0) {
                                if ((*(byte *)(plVar21 + 0x4a) & 0x52) == 2) {
                                  lVar24 = plVar21[0x1a];
                                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102083;
                                  cVar8 = func_0x(lVar24);
                                  if (((cVar8 != '\0') && (*(char *)(plVar21[0x1a] + 0x130) == '\0')
                                      ) && (*(undefined *)(plVar21[0x1a] + 0x130) = 1,
                                           *_DAT_ != '\0')) {
                                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1020c9;
                                    func_0x(0x1fb5570,0x1c,0x10,1);
                                  }
                                }
                                uVar14 = (uint)((*(byte *)(plVar21 + 0x4a) & 0x5a) != 0);
                              }
                              else {
                                pcVar3 = *(code **)(*plVar21 + 0x1e8);
                                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10205d;
                                uVar20 = (*pcVar3)(plVar21);
                                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102065;
                                uVar14 = func_0x(uVar20);
                              }
                              if (uVar14 != 0) goto LAB_;
                            }
                          }
                          else {
LAB_:
                            if ((*(byte *)(plVar21 + 0x4a) & 0x40) != 0) goto LAB_;
                          }
                        }
                      }
                    }
LAB_:
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1020f1;
                    func_0x(lVar19,0);
                  }
LAB_:
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1020f9;
                  iVar16 = func_0x(plVar21);
                  if (iVar16 == 0) {
                    pcVar3 = *(code **)(*plVar21 + 0x270);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10210a;
                    (*pcVar3)(plVar21);
                  }
                  lVar19 = plVar21[0x1a];
                  if ((uVar32 & 0x24) == 0) {
                    if ((*(byte *)(plVar21 + 0x4a) & 4) == 0) {
                      if ((*(byte *)(plVar21 + 0x4a) & 0x5a) != 0) goto LAB_;
                      if ((*(byte *)(plVar21 + 0x43) & 1) != 0) {
                        if (lVar19 == 0) {
                          pcVar3 = *(code **)(*plVar21 + 0x88);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102156;
                          cVar8 = (*pcVar3)(plVar21);
                          if (cVar8 != '\0') {
                            pcVar3 = *(code **)(*plVar21 + 0x18);
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102164;
                            cVar8 = (*pcVar3)(plVar21);
                            if (cVar8 == '\0') goto LAB_;
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102174;
                        iVar16 = func_0x(plVar21);
                        if (iVar16 == 0) {
                          pcVar3 = *(code **)(*plVar21 + 0x270);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102185;
                          (*pcVar3)(plVar21);
                        }
                        if ((*(byte *)(plVar21 + 0x43) & 4) == 0) {
                          if ((*(byte *)(plVar21 + 0x4a) & 0x52) == 2) {
                            lVar24 = plVar21[0x1a];
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1021c3;
                            cVar8 = func_0x(lVar24);
                            if (((cVar8 != '\0') && (*(char *)(plVar21[0x1a] + 0x130) == '\0')) &&
                               (*(undefined *)(plVar21[0x1a] + 0x130) = 1, *_DAT_ != '\0'))
                            {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102209;
                              func_0x(0x1fb5570,0x1c,0x10,1);
                            }
                          }
                          uVar32 = (uint)((*(byte *)(plVar21 + 0x4a) & 0x5a) != 0);
                        }
                        else {
                          pcVar3 = *(code **)(*plVar21 + 0x1e8);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10219d;
                          uVar20 = (*pcVar3)(plVar21);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1021a5;
                          uVar32 = func_0x(uVar20);
                        }
                        if (uVar32 != 0) goto LAB_;
                      }
                    }
                    if ((lVar19 == 0) || (*(int *)(lVar19 + 0x74) < 1)) goto LAB_;
                  }
LAB_:
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102237;
                  iVar36 = func_0x(psVar7);
                  if (iVar36 != 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102247;
                    func_0x(psVar7,auStack_52d0);
                    uVar11 = uStack_52ca;
                    if ((((uint)(int)(short)uStack_52ca >> 1 ^ (int)(short)uStack_52ca) & 0x2000) !=
                        0) {
                      uVar11 = uStack_52ca & 0xdfff;
                      if ((uStack_52ca >> 0xe & 1) != 0) {
                        uVar11 = uStack_52ca | 0x2000;
                      }
                    }
                    if (uVar11 == 0xfffc) {
                      uVar33 = (uint)(uStack_52cc >> 5);
                    }
                    uVar30 = uVar30 + uVar33;
                  }
                  lVar19 = plVar21[0x1a];
                  pcVar3 = *(code **)(*plVar21 + 0x88);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1022a7;
                  cVar8 = (*pcVar3)(plVar21);
                  if ((((cVar8 == '\0') && (lVar19 != 0)) &&
                      ((0 < *(int *)(lVar19 + 0x78) || (0 < *(int *)(lVar19 + 0x74))))) &&
                     (uVar30 < 0x1f74)) {
                    uVar30 = uVar30 + 8;
                  }
                  uVar30 = uVar30 + 0xe;
                  goto LAB_;
                }
                if (lStack_52f8 != 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101c25;
                  iVar16 = func_0x();
                  if (((iVar16 != 0) &&
                      (iVar16 = *(int *)(*(longlong *)(lStack_52f8 + 8) + 0x100), iVar16 != 0)) &&
                     (1 < iVar16 - 3U)) {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101c67;
                    (*_DAT_)(1,0x1a53840,0x1a53890,0x116);
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101c70;
                  iVar16 = func_0x(lStack_52f8);
                  if ((((iVar16 != 0) &&
                       ((*(byte *)(*(longlong *)(lStack_52f8 + 8) + 0x109) & 1) == 0)) &&
                      (iVar16 = *(int *)(*(longlong *)(lStack_52f8 + 8) + 0x100), iVar16 != 0)) &&
                     (1 < iVar16 - 3U)) {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101cbb;
                    (*_DAT_)(1,0x1a538c0,0x1a53890,0x119);
                  }
                }
                if ((lVar19 != 0) &&
                   ((0 < *(int *)(lVar19 + 0x78) || (0 < *(int *)(lVar19 + 0x74)))))
                goto LAB_;
                if ((*(byte *)(plVar21 + 0x4a) & 4) != 0) goto LAB_;
                if ((*(byte *)(plVar21 + 0x4a) & 0x5a) != 0) goto LAB_;
                if ((*(byte *)(plVar21 + 0x43) & 1) == 0) goto LAB_;
                if (plVar21[0x1a] != 0) {
LAB_:
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d32;
                  iVar16 = func_0x(plVar21);
                  if (iVar16 == 0) {
                    pcVar3 = *(code **)(*plVar21 + 0x270);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d43;
                    (*pcVar3)(plVar21);
                  }
                  if ((*(byte *)(plVar21 + 0x43) & 4) == 0) {
                    if ((*(byte *)(plVar21 + 0x4a) & 0x52) == 2) {
                      lVar24 = plVar21[0x1a];
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d81;
                      cVar8 = func_0x(lVar24);
                      if (((cVar8 != '\0') && (*(char *)(plVar21[0x1a] + 0x130) == '\0')) &&
                         (*(undefined *)(plVar21[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101dc7;
                        func_0x(0x1fb5570,0x1c,0x10,1);
                      }
                    }
                    uVar14 = (uint)((*(byte *)(plVar21 + 0x4a) & 0x5a) != 0);
                  }
                  else {
                    pcVar3 = *(code **)(*plVar21 + 0x1e8);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d5b;
                    uVar20 = (*pcVar3)(plVar21);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d63;
                    uVar14 = func_0x(uVar20);
                  }
                  if (uVar14 == 0) goto LAB_;
                  goto LAB_;
                }
                pcVar3 = *(code **)(*plVar21 + 0x88);
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d14;
                cVar8 = (*pcVar3)(plVar21);
                if (cVar8 == '\0') goto LAB_;
                pcVar3 = *(code **)(*plVar21 + 0x18);
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d22;
                cVar8 = (*pcVar3)(plVar21);
                if (cVar8 != '\0') goto LAB_;
LAB_:
                *(byte *)(plVar21 + 0x4a) = *(byte *)(plVar21 + 0x4a) | 4;
              }
            }
          }
          else {
            pcVar3 = *(code **)(*plVar21 + 0x88);
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101a75;
            cVar8 = (*pcVar3)(plVar21);
            if (cVar8 == '\0') goto LAB_;
            pcVar3 = *(code **)(*plVar21 + 0x18);
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101a83;
            cVar8 = (*pcVar3)(plVar21);
            if (cVar8 != '\0') goto LAB_;
          }
LAB_:
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1022e0;
          iVar16 = func_0x(psVar7);
          if (iVar16 != 0) {
            uVar30 = *(uint *)(psVar7 + 2);
            if (*psVar7 != 0) goto LAB_;
            if (uVar30 == 0) {
              *puVar37 = 0;
              uVar30 = *(uint *)(psVar7 + 8);
              uVar31 = (ulonglong)uVar30;
              *(uint *)(psVar7 + 10) = uVar30;
              pbVar2 = *(byte **)(psVar7 + 4);
              bVar28 = *pbVar2;
              if ((bVar28 & 0x10) != 0) {
                uVar30 = uVar30 + 2 + (*(ushort *)(pbVar2 + uVar31) + 7 >> 3);
                uVar31 = (ulonglong)uVar30;
                *(uint *)(psVar7 + 10) = uVar30;
                bVar28 = *pbVar2;
              }
              if ((bVar28 & 0x20) == 0) {
                *(int *)(psVar7 + 2) = (int)uVar31;
                psVar7[0xe] = 0;
                *(undefined4 *)(psVar7 + 0xc) = *(undefined4 *)(psVar7 + 10);
              }
              else {
                puVar38 = (ushort *)(pbVar2 + uVar31);
                uVar11 = *puVar38;
                psVar7[0xe] = uVar11;
                if (uVar11 == 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102357;
                  cVar8 = func_0x(0x1fb4e30);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102360;
                    lVar19 = func_0x();
                    if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10237a;
                      cVar8 = func_0x(0x1fb4e30);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102396;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1023bc;
                        (*_DAT_)(1,0x18a483c,0x19c4928,0x80f);
                      }
                    }
                  }
                  uVar20 = *(undefined8 *)(psVar7 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1023ca;
                  func_0x(uVar20,3);
                  uVar11 = psVar7[0xe];
                }
                uVar30 = *(int *)(psVar7 + 10) + 2 + (uint)uVar11 * 2;
                *(uint *)(psVar7 + 0xc) = uVar30;
                if (0x1f9e < uVar30) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1023f1;
                  cVar8 = func_0x(0x1fb4e30);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1023fa;
                    lVar19 = func_0x();
                    if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102414;
                      cVar8 = func_0x(0x1fb4e30);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102430;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102456;
                        (*_DAT_)(1,0x18a483c,0x19c4928,0x816);
                      }
                    }
                  }
                  uVar20 = *(undefined8 *)(psVar7 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102464;
                  func_0x(uVar20,4);
                }
                uVar11 = puVar38[(ushort)psVar7[0xe]];
                *(uint *)(psVar7 + 2) = uVar11 & 0x7fff;
                uVar30 = *(uint *)(psVar7 + 0xc);
                if ((uVar11 & 0x7fff) < uVar30) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10248d;
                  cVar8 = func_0x(0x1fb4e30);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102496;
                    lVar19 = func_0x();
                    if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1024b0;
                      cVar8 = func_0x(0x1fb4e30);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1024cc;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1024f2;
                        (*_DAT_)(1,0x18a483c,0x19c4928,0x81d);
                      }
                    }
                  }
                  uVar20 = *(undefined8 *)(psVar7 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102500;
                  func_0x(uVar20,4);
                  uVar30 = *(uint *)(psVar7 + 0xc);
                }
                uVar11 = psVar7[0xe];
                puVar4 = puVar38;
                if (uVar11 != 0) {
                  do {
                    uVar32 = puVar4[1] & 0x7fff;
                    if ((uVar32 < uVar30) || (*(uint *)(psVar7 + 2) < uVar32)) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10253e;
                      cVar8 = func_0x(0x1fb4e30);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102547;
                        lVar19 = func_0x();
                        if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102561;
                          cVar8 = func_0x(0x1fb4e30);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10257d;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1025a3;
                            (*_DAT_)(1,0x18a483c,0x19c4928,0x82a);
                          }
                        }
                      }
                      uVar20 = *(undefined8 *)(psVar7 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1025b1;
                      func_0x(uVar20,4);
                    }
                    iVar36 = iVar36 + 1;
                    uVar11 = psVar7[0xe];
                    uVar30 = uVar32;
                    puVar4 = puVar4 + 1;
                  } while (iVar36 < (int)(uint)uVar11);
                }
                uVar30 = (uint)uVar11;
                if ((short)puVar38[(ulonglong)(uVar30 - 1) + 1] < 0) {
                  do {
                    lVar19 = *(longlong *)(psVar7 + 4);
                    lVar24 = (ulonglong)*(uint *)(psVar7 + 10) + lVar19;
                    uVar32 = *(ushort *)(lVar24 + (ulonglong)uVar30 * 2) & 0x7fff;
                    if (uVar30 == 1) {
                      uVar33 = *(uint *)(psVar7 + 0xc);
                      uVar14 = uVar33;
LAB_:
                      if ((uVar32 < uVar33) || (uVar30 = *(uint *)(psVar7 + 2), uVar30 < uVar32))
                      goto LAB_;
                    }
                    else {
                      uVar33 = *(ushort *)(lVar24 + -2 + (ulonglong)uVar30 * 2) & 0x7fff;
                      uVar14 = *(uint *)(psVar7 + 0xc);
                      if (uVar14 <= uVar33) goto LAB_;
LAB_:
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102631;
                      func_0x(lVar19,7);
                      uVar14 = *(uint *)(psVar7 + 0xc);
                      uVar30 = *(uint *)(psVar7 + 2);
                    }
                    if ((uVar33 < uVar14) || (uVar30 < uVar33)) goto LAB_;
                    if (*(ushort *)((ulonglong)uVar33 + *(longlong *)(psVar7 + 4)) == 5) {
                      *puVar37 = *puVar37 | 2;
                      psVar7[0xe] = psVar7[0xe] + -1;
                      uVar34 = (ulonglong)(uVar33 & 0xffff);
                      psVar7[0x15] = (short)uVar33;
                      uVar31 = *(ulonglong *)(psVar7 + 4);
                      uVar11 = psVar7[0x16] & 0xc7ffU;
                      if ((*(ushort *)(uVar34 + 2 + uVar31) & 0x4000) != 0) {
                        uVar11 = *(ushort *)(uVar34 + 2 + uVar31) & 0x3800 | psVar7[0x16] & 0xc7ffU;
                      }
                      psVar7[0x16] = uVar11;
                      uVar12 = (uVar11 ^ *(ushort *)(uVar34 + 2 + uVar31)) & 0x7ff ^ uVar11;
                      psVar7[0x16] = uVar12;
                      uVar35 = (ulonglong)(ushort)psVar7[0x15];
                      uVar34 = uVar31 + 4 +
                               (ulonglong)((uVar12 & 0x7ff) * 2) + uVar35 + (uVar11 >> 0xb & 7) * 2;
                      if (uVar34 < uVar35 + uVar31) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1027b6;
                        func_0x(uVar35 + uVar31,0x19);
                        uVar12 = psVar7[0x16];
                        uVar35 = (ulonglong)(ushort)psVar7[0x15];
                        uVar31 = (ulonglong)*(uint *)(psVar7 + 4);
                      }
                      if (uVar32 - uVar33 <
                          (((uVar12 & 0x7ff) * 2 - (int)uVar35) - (int)uVar31) + (int)uVar34) {
                        lVar19 = *(longlong *)(psVar7 + 4);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1027ef;
                        func_0x(uVar35 + lVar19,0x19);
                        uVar12 = psVar7[0x16];
                      }
                      iVar36 = 0;
                      if (((uVar12 & 0x3800) != 0) &&
                         (puVar38 = (ushort *)
                                    (*(longlong *)(psVar7 + 4) + 4 + (ulonglong)(ushort)psVar7[0x15]
                                    ), (uVar12 & 0x3800) != 0)) {
                        do {
                          if ((uVar12 & 0x7ff) < (*puVar38 & 0x7ff)) {
                            uVar11 = psVar7[0x15];
                            lVar19 = *(longlong *)(psVar7 + 4);
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102857;
                            func_0x((ulonglong)uVar11 + lVar19,0x1a);
                            uVar12 = psVar7[0x16];
                          }
                          iVar36 = iVar36 + 1;
                          puVar38 = puVar38 + 1;
                        } while (iVar36 < (int)(uVar12 >> 0xb & 7));
                      }
                      break;
                    }
                    if (*(ushort *)((ulonglong)uVar33 + *(longlong *)(psVar7 + 4)) < 0x400) break;
                    *puVar37 = *puVar37 | 1;
                    uVar11 = psVar7[0xe] - 1;
                    psVar7[0xe] = uVar11;
                    if ((uVar11 == 0) ||
                       (uVar30 = (uint)uVar11, -1 < (short)puVar38[(ulonglong)(uVar11 - 1) + 1]))
                    break;
                  } while( true );
                }
              }
              iVar36 = 0;
              if ((**(byte **)(psVar7 + 4) & 0x40) == 0) {
                *(undefined4 *)(psVar7 + 0x13) = 0;
              }
              else {
                *(undefined4 *)(psVar7 + 0x13) = *(undefined4 *)(psVar7 + 2);
                *(int *)(psVar7 + 2) = *(int *)(psVar7 + 2) + 0xe;
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1026b5;
                puVar23 = (ulonglong *)func_0x(puVar37);
                uVar31 = *puVar23;
                uVar12 = (ushort)(uVar31 >> 0x30);
                uVar11 = uVar12;
                if ((((uint)(int)(short)uVar12 >> 1 ^ (int)(short)uVar12) & 0x2000) != 0) {
                  uVar11 = uVar12 & 0xdfff;
                  if ((uVar31 & 0x4000000000000000) != 0) {
                    uVar11 = uVar12 | 0x2000;
                  }
                }
                if (uVar11 == 0xfffc) {
                  iVar36 = (int)((uVar31 >> 0x20 & 0xffff) >> 5);
                }
                *(int *)(psVar7 + 2) = *(int *)(psVar7 + 2) + iVar36;
              }
              uVar30 = *(uint *)(psVar7 + 2);
              if ((*(ulonglong *)(psVar7 + 0xf) != 0) &&
                 (*(ulonglong *)(psVar7 + 0xf) < (ulonglong)uVar30 + *(longlong *)(psVar7 + 4))) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1028b9;
                cVar8 = func_0x(0x1fb4e30);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1028c2;
                  lVar19 = func_0x();
                  if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1028dc;
                    cVar8 = func_0x(0x1fb4e30);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1028f8;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10291e;
                      (*_DAT_)(1,0x18a483c,0x19c4928,0x886);
                    }
                  }
                }
                uVar20 = *(undefined8 *)(psVar7 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10292c;
                func_0x(uVar20,0x12);
                uVar30 = *(uint *)(psVar7 + 2);
              }
              if ((uVar30 == 0) || (0x3f3c < uVar30)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10294b;
                cVar8 = func_0x(0x1fb4e30);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102954;
                  lVar19 = func_0x();
                  if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10296e;
                    cVar8 = func_0x(0x1fb4e30);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10298a;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1029b0;
                      (*_DAT_)(1,0x18a483c,0x19c4928,0x88b);
                    }
                  }
                }
                uVar20 = *(undefined8 *)(psVar7 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1029be;
                func_0x(uVar20,5);
                uVar30 = *(uint *)(psVar7 + 2);
              }
            }
LAB_:
            if (uVar30 < 9) {
              if ((**(byte **)(psVar7 + 4) & 0xe) != 0) {
                bVar39 = (**(byte **)(psVar7 + 4) & 0xe) == 0xc;
                goto LAB_;
              }
              goto LAB_;
            }
          }
        }
        else {
          uVar30 = *(uint *)(psVar7 + 2);
          if (*psVar7 == 0) {
            if (uVar30 == 0) {
              *puVar37 = 0;
              uVar30 = *(uint *)(psVar7 + 8);
              uVar31 = (ulonglong)uVar30;
              *(uint *)(psVar7 + 10) = uVar30;
              pbVar2 = *(byte **)(psVar7 + 4);
              bVar28 = *pbVar2;
              if ((bVar28 & 0x10) != 0) {
                uVar30 = uVar30 + 2 + (*(ushort *)(pbVar2 + uVar31) + 7 >> 3);
                uVar31 = (ulonglong)uVar30;
                *(uint *)(psVar7 + 10) = uVar30;
                bVar28 = *pbVar2;
              }
              if ((bVar28 & 0x20) == 0) {
                *(int *)(psVar7 + 2) = (int)uVar31;
                psVar7[0xe] = 0;
                *(undefined4 *)(psVar7 + 0xc) = *(undefined4 *)(psVar7 + 10);
              }
              else {
                puVar38 = (ushort *)(pbVar2 + uVar31);
                uVar11 = *puVar38;
                psVar7[0xe] = uVar11;
                if (uVar11 == 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1013d4;
                  cVar8 = func_0x(0x1fb4e30);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1013dd;
                    lVar19 = func_0x();
                    if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1013f7;
                      cVar8 = func_0x(0x1fb4e30);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101413;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101439;
                        (*_DAT_)(1,0x18a483c,0x19c4928,0x80f);
                      }
                    }
                  }
                  uVar20 = *(undefined8 *)(psVar7 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101447;
                  func_0x(uVar20,3);
                  uVar11 = psVar7[0xe];
                }
                uVar30 = *(int *)(psVar7 + 10) + 2 + (uint)uVar11 * 2;
                *(uint *)(psVar7 + 0xc) = uVar30;
                if (0x1f9e < uVar30) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10146e;
                  cVar8 = func_0x(0x1fb4e30);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101477;
                    lVar19 = func_0x();
                    if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101491;
                      cVar8 = func_0x(0x1fb4e30);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1014ad;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1014d3;
                        (*_DAT_)(1,0x18a483c,0x19c4928,0x816);
                      }
                    }
                  }
                  uVar20 = *(undefined8 *)(psVar7 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1014e1;
                  func_0x(uVar20,4);
                }
                uVar11 = puVar38[(ushort)psVar7[0xe]];
                *(uint *)(psVar7 + 2) = uVar11 & 0x7fff;
                uVar30 = *(uint *)(psVar7 + 0xc);
                if ((uVar11 & 0x7fff) < uVar30) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10150a;
                  cVar8 = func_0x(0x1fb4e30);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101513;
                    lVar19 = func_0x();
                    if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10152d;
                      cVar8 = func_0x(0x1fb4e30);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101549;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10156f;
                        (*_DAT_)(1,0x18a483c,0x19c4928,0x81d);
                      }
                    }
                  }
                  uVar20 = *(undefined8 *)(psVar7 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10157d;
                  func_0x(uVar20,4);
                  uVar30 = *(uint *)(psVar7 + 0xc);
                }
                uVar11 = psVar7[0xe];
                puVar4 = puVar38;
                if (uVar11 != 0) {
                  do {
                    uVar32 = puVar4[1] & 0x7fff;
                    if ((uVar32 < uVar30) || (*(uint *)(psVar7 + 2) < uVar32)) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1015be;
                      cVar8 = func_0x(0x1fb4e30);
                      if (cVar8 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1015c7;
                        lVar19 = func_0x();
                        if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1015e1;
                          cVar8 = func_0x(0x1fb4e30);
                          if (cVar8 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1015fd;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101623;
                            (*_DAT_)(1,0x18a483c,0x19c4928,0x82a);
                          }
                        }
                      }
                      uVar20 = *(undefined8 *)(psVar7 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101631;
                      func_0x(uVar20,4);
                    }
                    iVar36 = iVar36 + 1;
                    uVar11 = psVar7[0xe];
                    uVar30 = uVar32;
                    puVar4 = puVar4 + 1;
                  } while (iVar36 < (int)(uint)uVar11);
                }
                uVar30 = (uint)uVar11;
                if ((short)puVar38[(ulonglong)(uVar30 - 1) + 1] < 0) {
                  do {
                    lVar19 = *(longlong *)(psVar7 + 4);
                    lVar24 = (ulonglong)*(uint *)(psVar7 + 10) + lVar19;
                    uVar32 = *(ushort *)(lVar24 + (ulonglong)uVar30 * 2) & 0x7fff;
                    if (uVar30 == 1) {
                      uVar33 = *(uint *)(psVar7 + 0xc);
                      uVar14 = uVar33;
LAB_:
                      if ((uVar32 < uVar33) || (uVar30 = *(uint *)(psVar7 + 2), uVar30 < uVar32))
                      goto LAB_;
                    }
                    else {
                      uVar33 = *(ushort *)(lVar24 + -2 + (ulonglong)uVar30 * 2) & 0x7fff;
                      uVar14 = *(uint *)(psVar7 + 0xc);
                      if (uVar14 <= uVar33) goto LAB_;
LAB_:
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1016b1;
                      func_0x(lVar19,7);
                      uVar14 = *(uint *)(psVar7 + 0xc);
                      uVar30 = *(uint *)(psVar7 + 2);
                    }
                    if ((uVar33 < uVar14) || (uVar30 < uVar33)) goto LAB_;
                    if (*(ushort *)((ulonglong)uVar33 + *(longlong *)(psVar7 + 4)) == 5) {
                      *puVar37 = *puVar37 | 2;
                      psVar7[0xe] = psVar7[0xe] + -1;
                      uVar34 = (ulonglong)(uVar33 & 0xffff);
                      psVar7[0x15] = (short)uVar33;
                      uVar31 = *(ulonglong *)(psVar7 + 4);
                      uVar11 = psVar7[0x16] & 0xc7ffU;
                      if ((*(ushort *)(uVar34 + 2 + uVar31) & 0x4000) != 0) {
                        uVar11 = *(ushort *)(uVar34 + 2 + uVar31) & 0x3800 | psVar7[0x16] & 0xc7ffU;
                      }
                      psVar7[0x16] = uVar11;
                      uVar12 = (uVar11 ^ *(ushort *)(uVar34 + 2 + uVar31)) & 0x7ff ^ uVar11;
                      psVar7[0x16] = uVar12;
                      uVar35 = (ulonglong)(ushort)psVar7[0x15];
                      uVar34 = uVar35 + 4 +
                               (ulonglong)((uVar12 & 0x7ff) * 2) + uVar31 + (uVar11 >> 0xb & 7) * 2;
                      if (uVar34 < uVar35 + uVar31) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101836;
                        func_0x(uVar35 + uVar31,0x19);
                        uVar12 = psVar7[0x16];
                        uVar35 = (ulonglong)(ushort)psVar7[0x15];
                        uVar31 = (ulonglong)*(uint *)(psVar7 + 4);
                      }
                      if (uVar32 - uVar33 <
                          (((uVar12 & 0x7ff) * 2 - (int)uVar35) - (int)uVar31) + (int)uVar34) {
                        lVar19 = *(longlong *)(psVar7 + 4);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10186f;
                        func_0x(uVar35 + lVar19,0x19);
                        uVar12 = psVar7[0x16];
                      }
                      iVar36 = 0;
                      if (((uVar12 & 0x3800) != 0) &&
                         (puVar38 = (ushort *)
                                    (*(longlong *)(psVar7 + 4) + 4 + (ulonglong)(ushort)psVar7[0x15]
                                    ), (uVar12 & 0x3800) != 0)) {
                        do {
                          if ((uVar12 & 0x7ff) < (*puVar38 & 0x7ff)) {
                            uVar11 = psVar7[0x15];
                            lVar19 = *(longlong *)(psVar7 + 4);
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1018d7;
                            func_0x((ulonglong)uVar11 + lVar19,0x1a);
                            uVar12 = psVar7[0x16];
                          }
                          iVar36 = iVar36 + 1;
                          puVar38 = puVar38 + 1;
                        } while (iVar36 < (int)(uVar12 >> 0xb & 7));
                      }
                      break;
                    }
                    if (*(ushort *)((ulonglong)uVar33 + *(longlong *)(psVar7 + 4)) < 0x400) break;
                    *puVar37 = *puVar37 | 1;
                    uVar11 = psVar7[0xe] - 1;
                    psVar7[0xe] = uVar11;
                    if ((uVar11 == 0) ||
                       (uVar30 = (uint)uVar11, -1 < (short)puVar38[(ulonglong)(uVar11 - 1) + 1]))
                    break;
                  } while( true );
                }
              }
              iVar36 = 0;
              if ((**(byte **)(psVar7 + 4) & 0x40) == 0) {
                *(undefined4 *)(psVar7 + 0x13) = 0;
              }
              else {
                *(undefined4 *)(psVar7 + 0x13) = *(undefined4 *)(psVar7 + 2);
                *(int *)(psVar7 + 2) = *(int *)(psVar7 + 2) + 0xe;
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101735;
                puVar23 = (ulonglong *)func_0x(puVar37);
                uVar31 = *puVar23;
                uVar12 = (ushort)(uVar31 >> 0x30);
                uVar11 = uVar12;
                if ((((uint)(int)(short)uVar12 >> 1 ^ (int)(short)uVar12) & 0x2000) != 0) {
                  uVar11 = uVar12 & 0xdfff;
                  if ((uVar31 & 0x4000000000000000) != 0) {
                    uVar11 = uVar12 | 0x2000;
                  }
                }
                if (uVar11 == 0xfffc) {
                  iVar36 = (int)((uVar31 >> 0x20 & 0xffff) >> 5);
                }
                *(int *)(psVar7 + 2) = *(int *)(psVar7 + 2) + iVar36;
              }
              uVar30 = *(uint *)(psVar7 + 2);
              if ((*(ulonglong *)(psVar7 + 0xf) != 0) &&
                 (*(ulonglong *)(psVar7 + 0xf) < (ulonglong)uVar30 + *(longlong *)(psVar7 + 4))) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101939;
                cVar8 = func_0x(0x1fb4e30);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101942;
                  lVar19 = func_0x();
                  if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10195c;
                    cVar8 = func_0x(0x1fb4e30);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101978;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10199e;
                      (*_DAT_)(1,0x18a483c,0x19c4928,0x886);
                    }
                  }
                }
                uVar20 = *(undefined8 *)(psVar7 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1019ac;
                func_0x(uVar20,0x12);
                uVar30 = *(uint *)(psVar7 + 2);
              }
              if ((uVar30 == 0) || (0x3f3c < uVar30)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1019cb;
                cVar8 = func_0x(0x1fb4e30);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1019d4;
                  lVar19 = func_0x();
                  if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1019ee;
                    cVar8 = func_0x(0x1fb4e30);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101a0a;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101a30;
                      (*_DAT_)(1,0x18a483c,0x19c4928,0x88b);
                    }
                  }
                }
                uVar20 = *(undefined8 *)(psVar7 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101a3e;
                func_0x(uVar20,5);
                uVar30 = *(uint *)(psVar7 + 2);
              }
            }
LAB_:
            if (uVar30 < 9) {
              if ((**(byte **)(psVar7 + 4) & 0xe) != 0) {
                bVar39 = (**(byte **)(psVar7 + 4) & 0xe) == 0xc;
LAB_:
                if (!bVar39) goto LAB_;
              }
LAB_:
              uVar30 = 9;
            }
          }
          else {
LAB_:
            if (uVar30 == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1029e3;
              func_0x(puVar37);
              uVar30 = *(uint *)(psVar7 + 2);
            }
            if (uVar30 < 9) {
              if ((**(byte **)(psVar7 + 4) & 0x1c) != 0) {
                bVar39 = (**(byte **)(psVar7 + 4) & 0x1c) == 0xc;
                goto LAB_;
              }
              goto LAB_;
            }
          }
        }
LAB_:
        lVar19 = lStack_52a0;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102a0d;
        lVar24 = func_0x(lStack_52a0);
        bVar28 = *(byte *)(lVar24 + 0x67);
        iVar36 = *(int *)(puStack_4a88 + 8);
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102a3a;
        uVar20 = func_0x(lVar19,auStack_5130);
        *(undefined8 *)((longlong)alStackX_8 + lVar17) = puStack_4a88[2];
        *(undefined2 *)((longlong)alStackX_8 + lVar17 + -8) = *(undefined2 *)(lVar18 + 0x3c8);
        *(longlong *)(&stack0xfffffffffffffff8 + lVar17) = lVar18 + 0x3c0;
        *(uint *)(&stack0xfffffffffffffff0 + lVar17) = bVar28 >> 6 & 1;
        *(uint *)(&stack0xffffffffffffffe8 + lVar17) = (uint)(iVar36 != 1);
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102a79;
        func_0x(auStack_5118,plVar21,uVar20,lVar19);
        uStack_480a = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102a88;
        cVar8 = func_0x(lVar19);
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102a97;
        cVar10 = func_0x(lVar19);
        *(uint *)(&stack0xfffffffffffffff0 + lVar17) = -(uint)(cVar8 != '\0') & 2;
        *(uint *)(&stack0xffffffffffffffe8 + lVar17) = (uint)(cVar10 != '\0');
        uVar20 = puStack_4a88[4];
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102ac8;
        func_0x(auStack_5158,auStack_5118,uVar20,uVar30);
        uVar30 = 0x10;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102ae0;
        uVar20 = func_0x(lVar19,auStack_5128);
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102ae8;
        uVar20 = func_0x(uVar20);
        lVar18 = plVar21[6];
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102af5;
        cVar8 = func_0x(lVar18,uVar20);
        if (cVar8 != '\0') {
          uVar30 = 1;
        }
        uVar32 = 0;
        do {
          uVar15 = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102b23;
          func_0x(auStack_5158,auStack_4aa8);
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102b33;
          piVar25 = (int *)func_0x(auStack_4aa8,auStack_5240);
          if ((*piVar25 == 0) && (*(short *)(piVar25 + 1) == 0)) goto LAB_;
          if (*(char *)(puStack_4a88[4] + 1) == '\x05') {
LAB_:
            *(undefined **)(&stack0xffffffffffffffe8 + lVar17) = auStack_5198;
            uVar20 = *puStack_4a88;
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102cf4;
            iVar36 = func_0x(uVar20,auStack_4aa8,3);
            if (iVar36 == 0) {
              if ((*(char *)(puStack_4a88[4] + 1) != '\x05') &&
                 (*(char *)(puStack_4a88[4] + 2) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102dce;
                iVar36 = func_0x(auStack_49f8);
                if (iVar36 != 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102dde;
                  uVar20 = func_0x(auStack_49f8);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102de6;
                  iVar36 = func_0x(uVar20);
                  if (iVar36 != 0) {
                    puStack_4a88[6] = puStack_4a88[6] + -1;
                  }
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102e01;
                func_0x(auStack_49f8);
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102e0d;
                func_0x(auStack_49f8);
                goto LAB_;
              }
            }
            else {
              puVar22 = (undefined4 *)&bStack_50b8;
              lVar18 = 2;
              puVar27 = auStack_4eb8;
              do {
                uVar15 = puVar22[1];
                uVar5 = puVar22[2];
                uVar6 = puVar22[3];
                *puVar27 = *puVar22;
                puVar27[1] = uVar15;
                puVar27[2] = uVar5;
                puVar27[3] = uVar6;
                uVar15 = puVar22[5];
                uVar5 = puVar22[6];
                uVar6 = puVar22[7];
                puVar27[4] = puVar22[4];
                puVar27[5] = uVar15;
                puVar27[6] = uVar5;
                puVar27[7] = uVar6;
                uVar15 = puVar22[9];
                uVar5 = puVar22[10];
                uVar6 = puVar22[0xb];
                puVar27[8] = puVar22[8];
                puVar27[9] = uVar15;
                puVar27[10] = uVar5;
                puVar27[0xb] = uVar6;
                uVar15 = puVar22[0xd];
                uVar5 = puVar22[0xe];
                uVar6 = puVar22[0xf];
                puVar27[0xc] = puVar22[0xc];
                puVar27[0xd] = uVar15;
                puVar27[0xe] = uVar5;
                puVar27[0xf] = uVar6;
                uVar15 = puVar22[0x11];
                uVar5 = puVar22[0x12];
                uVar6 = puVar22[0x13];
                puVar27[0x10] = puVar22[0x10];
                puVar27[0x11] = uVar15;
                puVar27[0x12] = uVar5;
                puVar27[0x13] = uVar6;
                uVar15 = puVar22[0x15];
                uVar5 = puVar22[0x16];
                uVar6 = puVar22[0x17];
                puVar27[0x14] = puVar22[0x14];
                puVar27[0x15] = uVar15;
                puVar27[0x16] = uVar5;
                puVar27[0x17] = uVar6;
                uVar15 = puVar22[0x19];
                uVar5 = puVar22[0x1a];
                uVar6 = puVar22[0x1b];
                puVar27[0x18] = puVar22[0x18];
                puVar27[0x19] = uVar15;
                puVar27[0x1a] = uVar5;
                puVar27[0x1b] = uVar6;
                uVar15 = puVar22[0x1d];
                uVar5 = puVar22[0x1e];
                uVar6 = puVar22[0x1f];
                puVar27[0x1c] = puVar22[0x1c];
                puVar27[0x1d] = uVar15;
                puVar27[0x1e] = uVar5;
                puVar27[0x1f] = uVar6;
                puVar22 = puVar22 + 0x20;
                lVar18 = lVar18 + -1;
                puVar27 = puVar27 + 0x20;
              } while (lVar18 != 0);
              *(undefined4 *)(&stack0xfffffffffffffff8 + lVar17) = 1;
              *(undefined4 **)(&stack0xfffffffffffffff0 + lVar17) = auStack_4eb8;
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102d96;
              func_0x(&puStack_4a88,auStack_5198,&psStack_5290);
            }
            if (iStack_49c8 == 4) {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102e1b;
              uStack_480a = func_0x(auStack_5158);
              break;
            }
          }
          else {
            pcVar3 = *(code **)(*plVar21 + 0x28);
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102b62;
            cVar10 = (*pcVar3)(plVar21);
            if (cVar10 != '\0') goto LAB_;
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102b72;
            iVar36 = func_0x(lVar19);
            if (iVar36 != 0) goto LAB_;
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102b8c;
            uVar20 = func_0x(auStack_4aa8,auStack_523a);
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102b97;
            uVar13 = func_0x(plVar21);
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102bac;
            func_0x(auStack_4ab8,uVar13,uVar20,0);
            if (*(char *)(puStack_4a88[4] + 2) == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102bc9;
              cVar10 = func_0x(lVar19);
              if (cVar10 != '\0') goto LAB_;
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102be4;
              uVar20 = func_0x(auStack_51b0,8);
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102bf6;
              uVar26 = func_0x(lVar19,auStack_5178);
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102c01;
              iVar36 = func_0x(uVar26,uVar20);
              if (iVar36 != 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102c18;
                uVar20 = func_0x(lVar19,auStack_51a0);
                *(undefined8 *)((longlong)&param_5 + lVar17) = 0;
                *(undefined **)((longlong)alStackX_8 + lVar17 + 0x18) = auStack_49f8;
                *(undefined8 *)((longlong)alStackX_8 + lVar17 + 0x10) = uVar20;
                *(undefined8 *)((longlong)alStackX_8 + lVar17 + 8) = 0;
                *(undefined4 *)((longlong)alStackX_8 + lVar17) = 0;
                *(undefined *)((longlong)alStackX_8 + lVar17 + -8) = 0;
                *(undefined4 *)(&stack0xfffffffffffffff8 + lVar17) = 0;
                *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = 1;
                *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) = 1;
                lVar18 = plStack_4a80[1];
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102c6f;
                uVar15 = func_0x(lVar18,auStack_4ab8,8);
              }
            }
            else {
LAB_:
              *(undefined4 *)((longlong)alStackX_8 + lVar17 + -8) = 1;
              *(undefined4 *)(&stack0xfffffffffffffff8 + lVar17) = 0;
              *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = 0;
              *(undefined **)(&stack0xffffffffffffffe8 + lVar17) = auStack_49f8;
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102cb3;
              uVar15 = func_0x(&puStack_4a88,auStack_4ab8,2);
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102cc0;
            cVar10 = func_0x(uVar15);
            if (cVar10 == '\0') goto LAB_;
          }
LAB_:
          uVar32 = uVar32 + 1;
        } while (uVar32 < uVar30);
        if (cVar8 != '\0') {
          if (iStack_49c8 == 4) {
            puVar22 = *(undefined4 **)(&stack0x00000040 + lVar17);
            goto LAB_;
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102e47;
          piVar25 = (int *)func_0x(auStack_4aa8,auStack_522c);
          if ((*piVar25 != 0) || (*(short *)(piVar25 + 1) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102e60;
            func_0x(auStack_52d8);
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102e68;
            uVar20 = func_0x(lVar19);
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102e74;
            func_0x(auStack_52d8,uVar20);
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102e84;
            uVar20 = func_0x(auStack_4aa8,auStack_5234);
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102e90;
            func_0x(auStack_5298,uVar20);
            (&stack0x00000038)[lVar17] = 4;
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102ea2;
            uVar15 = func_0x(4);
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102eae;
            uVar15 = func_0x(uVar15,2);
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102eba;
            uVar15 = func_0x(uVar15,0x20);
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102ec8;
            func_0x(auStack_5188,uVar15);
            *(longlong **)(&stack0xfffffffffffffff8 + lVar17) = plVar21;
            (&stack0xfffffffffffffff0)[lVar17] = 1;
            *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) = 1;
            lVar18 = plVar21[6];
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102ef2;
            func_0x(lVar18,auStack_52d8,auStack_5298,&stack0x00000038 + lVar17);
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102eff;
            func_0x(auStack_5188);
          }
        }
LAB_:
        puVar22 = *(undefined4 **)(&stack0x00000040 + lVar17);
      }
      if (iStack_49c8 != 4) {
        puVar23 = auStack_4fb8;
        lVar18 = 2;
        puVar27 = auStack_4db8;
        do {
          uVar15 = *(undefined4 *)((longlong)puVar23 + 4);
          uVar5 = *(undefined4 *)(puVar23 + 1);
          uVar6 = *(undefined4 *)((longlong)puVar23 + 0xc);
          *puVar27 = *(undefined4 *)puVar23;
          puVar27[1] = uVar15;
          puVar27[2] = uVar5;
          puVar27[3] = uVar6;
          uVar15 = *(undefined4 *)((longlong)puVar23 + 0x14);
          uVar5 = *(undefined4 *)(puVar23 + 3);
          uVar6 = *(undefined4 *)((longlong)puVar23 + 0x1c);
          puVar27[4] = *(undefined4 *)(puVar23 + 2);
          puVar27[5] = uVar15;
          puVar27[6] = uVar5;
          puVar27[7] = uVar6;
          uVar15 = *(undefined4 *)((longlong)puVar23 + 0x24);
          uVar5 = *(undefined4 *)(puVar23 + 5);
          uVar6 = *(undefined4 *)((longlong)puVar23 + 0x2c);
          puVar27[8] = *(undefined4 *)(puVar23 + 4);
          puVar27[9] = uVar15;
          puVar27[10] = uVar5;
          puVar27[0xb] = uVar6;
          uVar15 = *(undefined4 *)((longlong)puVar23 + 0x34);
          uVar5 = *(undefined4 *)(puVar23 + 7);
          uVar6 = *(undefined4 *)((longlong)puVar23 + 0x3c);
          puVar27[0xc] = *(undefined4 *)(puVar23 + 6);
          puVar27[0xd] = uVar15;
          puVar27[0xe] = uVar5;
          puVar27[0xf] = uVar6;
          uVar15 = *(undefined4 *)((longlong)puVar23 + 0x44);
          uVar5 = *(undefined4 *)(puVar23 + 9);
          uVar6 = *(undefined4 *)((longlong)puVar23 + 0x4c);
          puVar27[0x10] = *(undefined4 *)(puVar23 + 8);
          puVar27[0x11] = uVar15;
          puVar27[0x12] = uVar5;
          puVar27[0x13] = uVar6;
          uVar15 = *(undefined4 *)((longlong)puVar23 + 0x54);
          uVar5 = *(undefined4 *)(puVar23 + 0xb);
          uVar6 = *(undefined4 *)((longlong)puVar23 + 0x5c);
          puVar27[0x14] = *(undefined4 *)(puVar23 + 10);
          puVar27[0x15] = uVar15;
          puVar27[0x16] = uVar5;
          puVar27[0x17] = uVar6;
          uVar15 = *(undefined4 *)((longlong)puVar23 + 100);
          uVar5 = *(undefined4 *)(puVar23 + 0xd);
          uVar6 = *(undefined4 *)((longlong)puVar23 + 0x6c);
          puVar27[0x18] = *(undefined4 *)(puVar23 + 0xc);
          puVar27[0x19] = uVar15;
          puVar27[0x1a] = uVar5;
          puVar27[0x1b] = uVar6;
          uVar15 = *(undefined4 *)((longlong)puVar23 + 0x74);
          uVar5 = *(undefined4 *)(puVar23 + 0xf);
          uVar6 = *(undefined4 *)((longlong)puVar23 + 0x7c);
          puVar27[0x1c] = *(undefined4 *)(puVar23 + 0xe);
          puVar27[0x1d] = uVar15;
          puVar27[0x1e] = uVar5;
          puVar27[0x1f] = uVar6;
          puVar23 = puVar23 + 0x10;
          lVar18 = lVar18 + -1;
          puVar27 = puVar27 + 0x20;
        } while (lVar18 != 0);
        *(undefined4 **)(&stack0xffffffffffffffe8 + lVar17) = auStack_4db8;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102fa5;
        func_0x(&puStack_4a88,&psStack_5290,&psStack_5268,0);
      }
    }
LAB_:
    *(byte *)puVar22 = *(byte *)puVar22 & 0xfb;
    *(byte *)puVar22 = *(byte *)puVar22 | 1;
    lVar18 = 2;
    puVar27 = puVar22;
    puVar29 = auStack_4cb8;
    do {
      uVar15 = puVar27[1];
      uVar5 = puVar27[2];
      uVar6 = puVar27[3];
      *puVar29 = *puVar27;
      puVar29[1] = uVar15;
      puVar29[2] = uVar5;
      puVar29[3] = uVar6;
      uVar15 = puVar27[5];
      uVar5 = puVar27[6];
      uVar6 = puVar27[7];
      puVar29[4] = puVar27[4];
      puVar29[5] = uVar15;
      puVar29[6] = uVar5;
      puVar29[7] = uVar6;
      uVar15 = puVar27[9];
      uVar5 = puVar27[10];
      uVar6 = puVar27[0xb];
      puVar29[8] = puVar27[8];
      puVar29[9] = uVar15;
      puVar29[10] = uVar5;
      puVar29[0xb] = uVar6;
      uVar15 = puVar27[0xd];
      uVar5 = puVar27[0xe];
      uVar6 = puVar27[0xf];
      puVar29[0xc] = puVar27[0xc];
      puVar29[0xd] = uVar15;
      puVar29[0xe] = uVar5;
      puVar29[0xf] = uVar6;
      uVar15 = puVar27[0x11];
      uVar5 = puVar27[0x12];
      uVar6 = puVar27[0x13];
      puVar29[0x10] = puVar27[0x10];
      puVar29[0x11] = uVar15;
      puVar29[0x12] = uVar5;
      puVar29[0x13] = uVar6;
      uVar15 = puVar27[0x15];
      uVar5 = puVar27[0x16];
      uVar6 = puVar27[0x17];
      puVar29[0x14] = puVar27[0x14];
      puVar29[0x15] = uVar15;
      puVar29[0x16] = uVar5;
      puVar29[0x17] = uVar6;
      uVar15 = puVar27[0x19];
      uVar5 = puVar27[0x1a];
      uVar6 = puVar27[0x1b];
      puVar29[0x18] = puVar27[0x18];
      puVar29[0x19] = uVar15;
      puVar29[0x1a] = uVar5;
      puVar29[0x1b] = uVar6;
      uVar15 = puVar27[0x1d];
      uVar5 = puVar27[0x1e];
      uVar6 = puVar27[0x1f];
      puVar29[0x1c] = puVar27[0x1c];
      puVar29[0x1d] = uVar15;
      puVar29[0x1e] = uVar5;
      puVar29[0x1f] = uVar6;
      puVar27 = puVar27 + 0x20;
      lVar18 = lVar18 + -1;
      puVar29 = puVar29 + 0x20;
    } while (lVar18 != 0);
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10303c;
    iVar36 = func_0x(&puStack_4a88,&psStack_5290,auStack_4cb8,0);
    if (iVar36 != 0) {
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103066;
      (*_DAT_)(1,0x1a53798,0x1a29158,0x13c4);
    }
    lVar18 = lStack_52c8;
    *(uint *)(lStack_52c8 + 0x634) = *(uint *)(lStack_52c8 + 0x634) & 0xfffffffe;
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103089;
    func_0x(lStack_52c8,&puStack_4a88,0);
    *(uint *)(lVar18 + 0x634) = *(uint *)(lVar18 + 0x634) | 1;
    *(byte *)puVar22 = *(byte *)puVar22 & 0xf8;
    lVar19 = 2;
    puVar27 = puVar22;
    puVar29 = auStack_4bb8;
    do {
      uVar15 = puVar27[1];
      uVar5 = puVar27[2];
      uVar6 = puVar27[3];
      *puVar29 = *puVar27;
      puVar29[1] = uVar15;
      puVar29[2] = uVar5;
      puVar29[3] = uVar6;
      uVar15 = puVar27[5];
      uVar5 = puVar27[6];
      uVar6 = puVar27[7];
      puVar29[4] = puVar27[4];
      puVar29[5] = uVar15;
      puVar29[6] = uVar5;
      puVar29[7] = uVar6;
      uVar15 = puVar27[9];
      uVar5 = puVar27[10];
      uVar6 = puVar27[0xb];
      puVar29[8] = puVar27[8];
      puVar29[9] = uVar15;
      puVar29[10] = uVar5;
      puVar29[0xb] = uVar6;
      uVar15 = puVar27[0xd];
      uVar5 = puVar27[0xe];
      uVar6 = puVar27[0xf];
      puVar29[0xc] = puVar27[0xc];
      puVar29[0xd] = uVar15;
      puVar29[0xe] = uVar5;
      puVar29[0xf] = uVar6;
      uVar15 = puVar27[0x11];
      uVar5 = puVar27[0x12];
      uVar6 = puVar27[0x13];
      puVar29[0x10] = puVar27[0x10];
      puVar29[0x11] = uVar15;
      puVar29[0x12] = uVar5;
      puVar29[0x13] = uVar6;
      uVar15 = puVar27[0x15];
      uVar5 = puVar27[0x16];
      uVar6 = puVar27[0x17];
      puVar29[0x14] = puVar27[0x14];
      puVar29[0x15] = uVar15;
      puVar29[0x16] = uVar5;
      puVar29[0x17] = uVar6;
      uVar15 = puVar27[0x19];
      uVar5 = puVar27[0x1a];
      uVar6 = puVar27[0x1b];
      puVar29[0x18] = puVar27[0x18];
      puVar29[0x19] = uVar15;
      puVar29[0x1a] = uVar5;
      puVar29[0x1b] = uVar6;
      uVar15 = puVar27[0x1d];
      uVar5 = puVar27[0x1e];
      uVar6 = puVar27[0x1f];
      puVar29[0x1c] = puVar27[0x1c];
      puVar29[0x1d] = uVar15;
      puVar29[0x1e] = uVar5;
      puVar29[0x1f] = uVar6;
      puVar27 = puVar27 + 0x20;
      lVar19 = lVar19 + -1;
      puVar29 = puVar29 + 0x20;
    } while (lVar19 != 0);
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103120;
    iVar36 = func_0x(&puStack_4a88,&psStack_5268,auStack_4bb8,param_5);
    if (iVar36 == 0) {
      if (iStack_49c8 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10331f;
        func_0x(&puStack_4a88);
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10332c;
        (*_DAT_)(uStack_49c0);
        uStack_49c0 = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10333f;
        func_0x(puStack_4a88);
        puStack_4a88 = (undefined8 *)0x0;
        iStack_49c8 = 0;
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103364;
      func_0x(&plStack_4a60);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103373;
      func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar17));
      return;
    }
    if (plStack_4a60 == (longlong *)0x0) {
      if (iStack_49c8 != 2) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103153;
        func_0x(&puStack_4a88,1);
        if (iStack_49c8 != 2) {
          lVar19 = *plStack_4a60;
          goto LAB_;
        }
      }
      lVar19 = 0;
    }
    else {
      lVar19 = *plStack_4a60;
    }
LAB_:
    uVar15 = *(undefined4 *)(lVar19 + 0x20);
    iVar36 = (int)(short)uStack_4a68;
    uVar11 = *(ushort *)(lVar19 + 0x24);
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10318d;
    func_0x(0x18ad740,uVar11,uVar15);
    if ((CONCAT44(uStack_4a74,uStack_4a78) != CONCAT44(uRam0000000001fe08dc,_DAT_)) ||
       (CONCAT44(uStack_4a6c,uStack_4a70) != CONCAT44(uRam0000000001fe08e4,_DAT_))) {
      if ((bStack_4a18 & 2) != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1031c6;
        iVar16 = func_0x(auStack_4a10);
        if (iVar16 != 0) {
          puStack_4a88[6] = puStack_4a88[6] + -1;
        }
      }
      bStack_4a18 = 0;
      uStack_4a1c = 0;
      uStack_4a00 = 0;
      if ((bStack_49e8 & 2) != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1031ff;
        iVar16 = func_0x(auStack_49e0);
        if (iVar16 != 0) {
          puStack_4a88[6] = puStack_4a88[6] + -1;
        }
      }
      bStack_49e8 = 0;
      uStack_49ec = 0;
      uStack_49d0 = 0;
      if (plStack_4a60 != (longlong *)0x0) {
        uStack_4a54 = uStack_4a54 & 0xff000000;
        plStack_4a60 = (longlong *)0x0;
        *(undefined4 *)(CONCAT44(uStack_4a74,uStack_4a78) + 0x48) = 0;
      }
      uVar20 = *puStack_4a88;
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103264;
      func_0x(uVar20,&uStack_4a78);
      uStack_4a78 = _DAT_;
      uStack_4a74 = uRam0000000001fe08dc;
      uStack_4a70 = _DAT_;
      uStack_4a6c = uRam0000000001fe08e4;
      uStack_4a68 = 0xffffffff;
      uStack_4848 = 0;
      uStack_4830 = 0;
      uStack_4838 = 0;
      uStack_4828 = 0;
      uStack_4818 = 0xffffffff;
      uStack_4814 = 0xffff;
      uStack_4812 = 0;
      iStack_49c8 = 2;
    }
    *(uint *)(lVar18 + 0x634) = *(uint *)(lVar18 + 0x634) | 1;
    iStack_5318 = iStack_5318 + 1;
    uVar30 = *(uint *)(&stack0x0000003c + lVar17);
    if (iStack_5318 == 10) {
      *(int *)(&stack0xfffffffffffffff8 + lVar17) = iVar36;
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = uVar15;
      *(uint *)(&stack0xffffffffffffffe8 + lVar17) = (uint)uVar11;
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103305;
      (*_DAT_)(0xdc,0xf,10);
    }
  } while( true );
}

