
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(ushort *param_1,undefined4 param_2,int param_3,longlong param_4)

{
  uint uVar1;
  ushort *puVar2;
  byte bVar3;
  char cVar4;
  ushort uVar5;
  int iVar6;
  uint uVar7;
  longlong lVar8;
  undefined8 *puVar9;
  ulonglong uVar10;
  undefined4 *puVar11;
  uint uVar12;
  byte *pbVar13;
  undefined2 *puVar14;
  ushort uVar15;
  ulonglong uVar16;
  int iVar17;
  uint uVar18;
  ulonglong uVar19;
  uint uVar20;
  uint uVar21;
  uint uVar22;
  ushort *puVar23;
  undefined auStack_198 [32];
  undefined8 uStack_178;
  int iStack_168;
  int iStack_164;
  uint uStack_160;
  int iStack_15c;
  undefined4 uStack_158;
  undefined8 uStack_150;
  undefined8 uStack_148;
  longlong lStack_140;
  undefined8 uStack_138;
  undefined4 uStack_130;
  undefined2 uStack_12c;
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_198;
  iVar6 = 0;
  uStack_138 = 0;
  uStack_150 = 0;
  uStack_130 = 0;
  uStack_12c = 0;
  iStack_168 = param_3;
  uStack_158 = param_2;
  lStack_140 = param_4;
  if (*(int *)(param_1 + 1) == 0) {
    pbVar13 = *(byte **)(param_1 + 3);
    uVar22 = *(uint *)(param_1 + 7);
    uVar16 = (ulonglong)uVar22;
    *param_1 = 0;
    *(uint *)(param_1 + 9) = uVar22;
    bVar3 = *pbVar13;
    if ((bVar3 & 0x10) != 0) {
      uVar22 = uVar22 + 2 + (*(ushort *)(pbVar13 + uVar16) + 7 >> 3);
      uVar16 = (ulonglong)uVar22;
      *(uint *)(param_1 + 9) = uVar22;
      bVar3 = *pbVar13;
    }
    iVar17 = (int)uVar16;
    if ((bVar3 & 0x20) == 0) {
      *(int *)(param_1 + 1) = iVar17;
      param_1[0xd] = 0;
      *(int *)(param_1 + 0xb) = iVar17;
    }
    else {
      puVar23 = (ushort *)(pbVar13 + uVar16);
      uVar15 = *puVar23;
      param_1[0xd] = uVar15;
      if (uVar15 == 0) {
        cVar4 = func_0x(0x10ff3d0);
        if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar4 = func_0x(0x10ff3d0);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            uStack_178 = 0;
            (*_DAT_)(1,0x9eeddc,0xb0eec8,0x80f);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),3);
        uVar15 = param_1[0xd];
        iVar17 = *(int *)(param_1 + 9);
        pbVar13 = *(byte **)(param_1 + 3);
      }
      uVar22 = iVar17 + (uVar15 + 1) * 2;
      *(uint *)(param_1 + 0xb) = uVar22;
      if (0x1f9e < uVar22) {
        cVar4 = func_0x(0x10ff3d0);
        if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar4 = func_0x(0x10ff3d0);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            uStack_178 = 0;
            (*_DAT_)(1,0x9eeddc,0xb0eec8,0x816);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar15 = param_1[0xd];
        uVar22 = *(uint *)(param_1 + 0xb);
        pbVar13 = *(byte **)(param_1 + 3);
      }
      uVar16 = (ulonglong)uVar15;
      uVar15 = puVar23[uVar16];
      *(uint *)(param_1 + 1) = uVar15 & 0x7fff;
      if ((uVar15 & 0x7fff) < uVar22) {
        cVar4 = func_0x(0x10ff3d0);
        if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar4 = func_0x(0x10ff3d0);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            uStack_178 = 0;
            (*_DAT_)(1,0x9eeddc,0xb0eec8,0x81d);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar22 = *(uint *)(param_1 + 0xb);
        uVar16 = (ulonglong)param_1[0xd];
        pbVar13 = *(byte **)(param_1 + 3);
      }
      puVar2 = puVar23;
      iVar17 = iVar6;
      if ((short)uVar16 != 0) {
        do {
          uVar18 = puVar2[1] & 0x7fff;
          if ((uVar18 < uVar22) || (*(uint *)(param_1 + 1) < uVar18)) {
            cVar4 = func_0x(0x10ff3d0);
            if ((cVar4 != '\0') &&
               ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')
                ))) {
              cVar4 = func_0x(0x10ff3d0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_178 = 0;
                (*_DAT_)(1,0x9eeddc,0xb0eec8,0x82a);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 3),4);
          }
          uVar16 = (ulonglong)param_1[0xd];
          iVar17 = iVar17 + 1;
          puVar2 = puVar2 + 1;
          uVar22 = uVar18;
        } while (iVar17 < (int)(uint)param_1[0xd]);
        pbVar13 = *(byte **)(param_1 + 3);
      }
      uVar10 = uVar16;
      if ((short)puVar23[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
        do {
          uVar15 = (ushort)uVar16;
          uVar22 = *(ushort *)(pbVar13 + uVar10 * 2 + (ulonglong)*(uint *)(param_1 + 9)) & 0x7fff;
          if ((int)uVar10 == 1) {
            uVar18 = *(uint *)(param_1 + 0xb);
            uVar12 = uVar18;
LAB_:
            if ((uVar22 < uVar18) || (*(uint *)(param_1 + 1) < uVar22)) goto LAB_;
          }
          else {
            uVar12 = *(uint *)(param_1 + 0xb);
            uVar18 = *(ushort *)(pbVar13 + uVar10 * 2 + ((ulonglong)*(uint *)(param_1 + 9) - 2)) &
                     0x7fff;
            if (uVar12 <= uVar18) goto LAB_;
LAB_:
            func_0x(pbVar13,7);
            uVar12 = *(uint *)(param_1 + 0xb);
            pbVar13 = *(byte **)(param_1 + 3);
            uVar15 = param_1[0xd];
          }
          if ((uVar18 < uVar12) || (*(uint *)(param_1 + 1) < uVar18)) goto LAB_;
          if (*(ushort *)(pbVar13 + uVar18) == 5) {
            *param_1 = *param_1 | 2;
            param_1[0xd] = uVar15 - 1;
            uVar10 = (ulonglong)(uVar18 & 0xffff);
            param_1[0x14] = (ushort)uVar18;
            uVar16 = *(ulonglong *)(param_1 + 3);
            uVar15 = param_1[0x15] & 0xc7ff;
            if ((*(ushort *)(uVar10 + 2 + uVar16) >> 0xe & 1) != 0) {
              uVar15 = *(ushort *)(uVar10 + 2 + uVar16) & 0x3800 | param_1[0x15] & 0xc7ff;
            }
            param_1[0x15] = uVar15;
            uVar5 = (uVar15 ^ *(ushort *)(uVar10 + 2 + uVar16)) & 0x7ff ^ uVar15;
            param_1[0x15] = uVar5;
            uVar19 = uVar16 + 4 +
                     (ulonglong)((uVar5 & 0x7ff) * 2) + uVar10 + (uVar15 >> 0xb & 7) * 2;
            if (uVar19 < uVar10 + uVar16) {
              func_0x(uVar10 + uVar16,0x19);
              uVar5 = param_1[0x15];
              uVar10 = (ulonglong)param_1[0x14];
              uVar16 = (ulonglong)*(uint *)(param_1 + 3);
            }
            if (uVar22 - uVar18 < (((uVar5 & 0x7ff) * 2 - (int)uVar10) - (int)uVar16) + (int)uVar19)
            {
              func_0x(uVar10 + *(longlong *)(param_1 + 3),0x19);
              uVar5 = param_1[0x15];
            }
            if (((uVar5 & 0x3800) != 0) &&
               (puVar23 = (ushort *)(*(longlong *)(param_1 + 3) + 4 + (ulonglong)param_1[0x14]),
               (uVar5 & 0x3800) != 0)) {
              do {
                if ((uVar5 & 0x7ff) < (*puVar23 & 0x7ff)) {
                  func_0x((ulonglong)param_1[0x14] + *(longlong *)(param_1 + 3),0x1a);
                  uVar5 = param_1[0x15];
                }
                iVar6 = iVar6 + 1;
                puVar23 = puVar23 + 1;
              } while (iVar6 < (int)(uVar5 >> 0xb & 7));
            }
            pbVar13 = *(byte **)(param_1 + 3);
            goto LAB_;
          }
          if (*(ushort *)(pbVar13 + uVar18) < 0x400) goto LAB_;
          *param_1 = *param_1 | 1;
          uVar15 = uVar15 - 1;
          param_1[0xd] = uVar15;
          if (uVar15 == 0) goto LAB_;
          uVar16 = (ulonglong)uVar15;
          uVar10 = (ulonglong)(uint)uVar15;
        } while ((short)puVar23[(ulonglong)(uVar15 - 1) + 1] < 0);
        uVar16 = (ulonglong)*(uint *)(param_1 + 1);
      }
      else {
LAB_:
        uVar16 = (ulonglong)*(uint *)(param_1 + 1);
      }
    }
    if ((*pbVar13 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x12) = 0;
    }
    else {
      *(int *)(param_1 + 0x12) = (int)uVar16;
      *(int *)(param_1 + 1) = (int)uVar16 + 0xe;
      puVar9 = (undefined8 *)func_0x(param_1);
      uStack_148 = *puVar9;
      iVar6 = func_0x(&uStack_148);
      *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + iVar6;
      uVar16 = (ulonglong)*(uint *)(param_1 + 1);
      pbVar13 = *(byte **)(param_1 + 3);
    }
    iVar6 = (int)uVar16;
    if ((*(byte **)(param_1 + 0xe) != (byte *)0x0) && (*(byte **)(param_1 + 0xe) < pbVar13 + uVar16)
       ) {
      cVar4 = func_0x(0x10ff3d0);
      if ((cVar4 != '\0') &&
         ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')))) {
        cVar4 = func_0x(0x10ff3d0);
        if (cVar4 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          uStack_178 = 0;
          (*_DAT_)(1,0x9eeddc,0xb0eec8,0x886);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),0x12);
      iVar6 = *(int *)(param_1 + 1);
    }
    if (0x3f3b < iVar6 - 1U) {
      cVar4 = func_0x(0x10ff3d0);
      if (((cVar4 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
         (*(char *)(lVar8 + 0x499) != '\0')) {
        cVar4 = func_0x(0x10ff3d0);
        if (cVar4 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          uStack_178 = 0;
          (*_DAT_)(1,0x9eeddc,0xb0eec8,0x88b);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),5);
    }
  }
LAB_:
  pbVar13 = *(byte **)(param_1 + 3);
  bVar3 = *pbVar13;
  uVar22 = bVar3 >> 6 & 1;
  uStack_160 = uVar22;
  if ((bVar3 >> 6 & 1) != 0) {
    func_0x(param_1,&uStack_138);
    pbVar13 = *(byte **)(param_1 + 3);
    bVar3 = *pbVar13;
  }
  if ((bVar3 & 0x20) == 0) {
    *pbVar13 = bVar3 | 0x20;
    *(undefined2 *)((ulonglong)*(uint *)(param_1 + 9) + *(longlong *)(param_1 + 3)) = 0;
    pbVar13 = *(byte **)(param_1 + 3);
    *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + 2;
    *(int *)(param_1 + 0xb) = *(int *)(param_1 + 9) + 2;
  }
  uVar18 = *(uint *)(param_1 + 9);
  uVar15 = param_1[0xd];
  uVar16 = (ulonglong)uVar15;
  iVar6 = func_0x(param_1);
  if (iVar6 != 0) {
    uVar16 = (ulonglong)(uVar15 + 1);
  }
  uVar12 = (uint)uVar16;
  if ((param_4 != 0) && ((*(byte *)param_1 & 1) == 0)) {
    uVar20 = 0;
    lVar8 = *(longlong *)(param_1 + 3);
    puVar23 = (ushort *)(lVar8 + (ulonglong)*(uint *)(param_1 + 9));
    uVar21 = *(uint *)(param_1 + 9) + 2 + uVar12 * 2;
    if (*puVar23 != 0) {
      do {
        uVar7 = uVar20 & 0xffff;
        uVar10 = (ulonglong)uVar20;
        uVar20 = uVar20 + 1;
        puVar23[(ulonglong)uVar7 + 1] =
             puVar23[(ulonglong)uVar7 + 1] ^
             (puVar23[uVar10 + 1] + 2 ^ puVar23[(ulonglong)uVar7 + 1]) & 0x7fff;
      } while (uVar20 < *puVar23);
      lVar8 = *(longlong *)(param_1 + 3);
    }
    lVar8 = (ulonglong)uVar21 + lVar8;
    func_0x(lVar8 + 2,lVar8,*(int *)(param_1 + 1) - uVar21);
    *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + 2;
    uVar20 = *(int *)(param_1 + 0xb) + 2;
    *(uint *)(param_1 + 0xb) = uVar20;
    if (uVar12 != 0) {
      uVar20 = puVar23[(ulonglong)(uVar12 - 1) + 1] & 0x7fff;
    }
    if (uVar12 < uVar12 + 1) {
      uVar10 = uVar16;
      do {
        uVar19 = uVar10 & 0xffff;
        uVar21 = (int)uVar10 + 1;
        uVar10 = (ulonglong)uVar21;
        puVar23[uVar19 + 1] = (ushort)uVar20 & 0x7fff;
      } while (uVar21 < uVar12 + 1);
    }
    *puVar23 = *puVar23 + 1;
    func_0x(param_1);
    *param_1 = *param_1 | 1;
    *(ushort *)(pbVar13 + uVar16 * 2 + (ulonglong)uVar18 + 2) =
         *(ushort *)(pbVar13 + uVar16 * 2 + (ulonglong)uVar18 + 2) | 0x8000;
  }
  iVar6 = uVar12 + 1;
  lVar8 = (ulonglong)*(uint *)(param_1 + 9) + *(longlong *)(param_1 + 3);
  uVar18 = (uint)*(ushort *)(lVar8 + 2 + uVar16 * 2);
  iStack_15c = iVar6;
  if (iVar6 == 1) {
    uVar20 = *(uint *)(param_1 + 0xb);
LAB_:
    uVar21 = uVar18 & 0x7fff;
    if ((uVar21 < uVar20) || (*(uint *)(param_1 + 1) < uVar21)) goto LAB_;
  }
  else {
    uVar20 = *(ushort *)(lVar8 + uVar16 * 2) & 0x7fff;
    if (*(uint *)(param_1 + 0xb) <= uVar20) goto LAB_;
LAB_:
    func_0x(*(longlong *)(param_1 + 3),7);
  }
  uVar18 = uVar18 & 0x7fff;
  uVar7 = uVar18 - uVar20;
  uVar21 = iStack_168 + 2;
  if (iStack_168 == 0) {
    uVar21 = 0;
  }
  if (uVar21 != uVar7) {
    lVar8 = *(longlong *)(param_1 + 3);
    uVar1 = *(uint *)(param_1 + 1);
    puVar23 = (ushort *)((ulonglong)*(uint *)(param_1 + 9) + lVar8);
    if (uVar1 < uVar18) {
      iStack_164 = -1;
      func_0x(0x80070216,uVar1,uVar18);
      lVar8 = *(longlong *)(param_1 + 3);
    }
    else {
      iStack_164 = uVar1 - uVar18;
    }
    func_0x
              ((longlong)(int)uVar21 + (ulonglong)uVar20 + lVar8,
               (longlong)(int)uVar7 + (ulonglong)uVar20 + lVar8,iStack_164);
    if (uVar12 < *puVar23) {
      do {
        uVar10 = uVar16 & 0xffff;
        iVar6 = (int)uVar16;
        uVar18 = iVar6 + 1;
        uVar16 = (ulonglong)uVar18;
        puVar23[uVar10 + 1] =
             puVar23[uVar10 + 1] ^
             ((puVar23[(longlong)iVar6 + 1] - (short)uVar7) + (short)uVar21 ^ puVar23[uVar10 + 1]) &
             0x7fff;
        uVar22 = uStack_160;
      } while ((int)uVar18 < (int)(uint)*puVar23);
    }
    *(uint *)(param_1 + 1) = *(int *)(param_1 + 1) + (uVar21 - uVar7);
    func_0x(param_1);
    iVar6 = iStack_15c;
  }
  if (iStack_168 == 0) goto LAB_;
  puVar14 = (undefined2 *)(*(longlong *)(param_1 + 3) + (ulonglong)uVar20);
  if (puVar14 == (undefined2 *)0x0) {
    puVar11 = (undefined4 *)(*_DAT_)();
    *puVar11 = 0x16;
LAB_:
    (*_DAT_)();
  }
  else {
    if (uVar21 < 2) {
      func_0x(puVar14,0);
      puVar11 = (undefined4 *)(*_DAT_)();
      *puVar11 = 0x22;
      goto LAB_;
    }
    *puVar14 = (short)uStack_158;
  }
  func_0x
            (*(longlong *)(param_1 + 3) + 2 + (ulonglong)uVar20,uVar21 - 2,lStack_140,iStack_168);
LAB_:
  if (uVar21 == 0) {
    func_0x(param_1,iVar6,0);
    if ((**(byte **)(param_1 + 3) & 0x20) != 0) {
      param_1[0xd] = param_1[0xd] + 1;
    }
    *param_1 = *param_1 & 0xfffe;
  }
  if (uVar22 != 0) {
    func_0x(param_1,&uStack_138);
  }
  iVar6 = func_0x(param_1);
  if (iVar6 != 0) {
    func_0x(param_1);
  }
  func_0x(uStack_58 ^ (ulonglong)auStack_198);
  return;
}

