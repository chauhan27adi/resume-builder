
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,char param_2,char param_3,undefined8 param_4)

{
  byte bVar1;
  undefined2 uVar2;
  longlong lVar3;
  longlong lVar4;
  char cVar5;
  longlong lVar6;
  longlong *plVar7;
  ulonglong uVar8;
  longlong lVar9;
  uint uVar10;
  byte *pbVar11;
  longlong unaff_GS_OFFSET;
  longlong *plStackX_8;
  undefined auStackX_10 [4];
  uint auStackX_14 [4];
  char acStackX_24 [4];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar6 = func_0x();
  lVar6 = -lVar6;
  *(undefined8 *)(&stack0x00000208 + lVar6) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00004658 + lVar6) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar6);
  *(undefined8 *)(&stack0x00000188 + lVar6) = param_4;
  acStackX_24[lVar6] = param_3;
  acStackX_24[lVar6 + 1] = param_2;
  *(longlong **)(&stack0x00000150 + lVar6) = param_1;
  *(longlong **)(&stack0x000000e8 + lVar6) = param_1;
  (&stack0x00000028)[lVar6] = param_2;
  *(undefined8 *)(&stack0x00000180 + lVar6) = param_4;
  *(undefined8 *)(&stack0x00000190 + lVar6) = *(undefined8 *)(&stack0x000046d0 + lVar6);
  *(undefined8 *)(&stack0x00000198 + lVar6) = *(undefined8 *)(&stack0x000046e0 + lVar6);
  *(undefined8 *)((longlong)&plStackX_8 + lVar6) = 0;
  auStackX_10[lVar6] = 0;
  uVar10 = *(uint *)((longlong)auStackX_14 + lVar6);
  *(uint *)((longlong)auStackX_14 + lVar6) = uVar10 & 0xffff0000;
  *(uint *)((longlong)auStackX_14 + lVar6) = uVar10 & 0xff000000;
  *(undefined4 *)((longlong)auStackX_14 + lVar6) = 0;
  *(undefined2 *)(&stack0x00000508 + lVar6) = 0xffff;
  *(undefined8 *)(&stack0x00000510 + lVar6) = 0;
  *(undefined4 *)(&stack0x0000050c + lVar6) = 0;
  *(undefined8 *)(&stack0x00000526 + lVar6) = 0;
  *(undefined8 *)(&stack0x00000530 + lVar6) = 0;
  *(undefined8 *)(&stack0x00000518 + lVar6) = 0;
  *(undefined4 *)(&stack0x0000053c + lVar6) = 0xffffffff;
  *(undefined2 *)(&stack0x000005b8 + lVar6) = 0xffff;
  *(undefined8 *)(&stack0x000005c0 + lVar6) = 0;
  *(undefined4 *)(&stack0x000005bc + lVar6) = 0;
  *(undefined8 *)(&stack0x000005d6 + lVar6) = 0;
  *(undefined8 *)(&stack0x000005e0 + lVar6) = 0;
  *(undefined8 *)(&stack0x000005c8 + lVar6) = 0;
  *(undefined2 *)(&stack0x00000050 + lVar6) = 0xffff;
  *(undefined8 *)(&stack0x00000058 + lVar6) = 0;
  *(undefined4 *)(&stack0x00000054 + lVar6) = 0;
  *(undefined8 *)(&stack0x0000006e + lVar6) = 0;
  *(undefined8 *)(&stack0x00000078 + lVar6) = 0;
  *(undefined8 *)(&stack0x00000060 + lVar6) = 0;
  if (param_1[1] == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((param_2 != '\0') && ((*(uint *)(*param_1 + 100) >> 8 & 1) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(uint *)(*param_1 + 100) & 0x1000) != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1007ea;
    func_0x((longlong)&plStackX_8 + lVar6);
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1007ff;
    func_0x
              (*(ulonglong *)(&stack0x00004658 + lVar6) ^
               (ulonglong)(&stack0xffffffffffffffc8 + lVar6));
    return;
  }
  uVar2 = *(undefined2 *)(*param_1 + 0x20);
  *(undefined4 *)(&stack0x00000030 + lVar6) = 0;
  *(undefined2 *)(&stack0x00000034 + lVar6) = uVar2;
  if (param_3 == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar9 = param_1[1];
  *(undefined8 *)(&stack0x000001b4 + lVar6) = 0;
  if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
    lVar3 = *(longlong *)
             ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar3 != 0) && (**(longlong **)(lVar3 + 0x38) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar3 = *(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8);
    if (lVar3 != 0) {
      lVar3 = *(longlong *)(lVar3 + 0x60);
      lVar4 = *(longlong *)(lVar9 + 0x728);
      *(undefined4 *)(&stack0x00000048 + lVar6) = 2;
      *(undefined4 *)(&stack0x00000038 + lVar6) = 0;
      if (*(longlong *)((longlong)&plStackX_8 + lVar6) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(longlong *)(lVar9 + 0x728) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100281;
      func_0x(lVar9,&stack0x00000030 + lVar6);
      *(undefined **)(&stack0xfffffffffffffff0 + lVar6) = &stack0x000001b0 + lVar6;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar6) = 4;
      *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1002af;
      plVar7 = (longlong *)
               func_0x
                         (_DAT_,lVar9,&stack0x00000030 + lVar6,&stack0x00000038 + lVar6);
      *(longlong **)((longlong)&plStackX_8 + lVar6) = plVar7;
      uVar10 = *(uint *)((longlong)auStackX_14 + lVar6) & 0xffff0004 | 4;
      *(uint *)((longlong)auStackX_14 + lVar6) = uVar10;
      if (lVar3 != 0) {
        uVar8 = (ulonglong)(*(uint *)(lVar3 + 0x500) & 0xf);
        if (*(longlong *)(lVar3 + 0x508 + uVar8 * 8) != *plVar7) {
          *(longlong *)(lVar3 + 0x508 + uVar8 * 8) = *plVar7;
          *(longlong *)(lVar3 + 0x500) = *(longlong *)(lVar3 + 0x500) + 1;
          uVar10 = *(uint *)((longlong)auStackX_14 + lVar6);
        }
      }
      *(uint *)((longlong)auStackX_14 + lVar6) =
           (*(uint *)(&stack0x00000038 + lVar6) >> 3 & 1) << 0x18 | uVar10 & 0xffffff;
      *(uint *)((longlong)auStackX_14 + lVar6 + 4) =
           *(uint *)(&stack0x00000038 + lVar6) >> 4 & 1 |
           *(uint *)((longlong)auStackX_14 + lVar6 + 4) & 0xffffff00;
      if (lVar4 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x10033c;
      cVar5 = func_0x(lVar9);
      if (cVar5 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(undefined4 *)((longlong)auStackX_14 + lVar6 + 0xc) = 9;
      *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100376;
      lVar9 = func_0x(_DAT_,*(undefined8 *)((longlong)&plStackX_8 + lVar6),1,0);
      *(longlong *)(&stack0x00000040 + lVar6) = lVar9;
      *(ushort *)(lVar9 + 4) = *(ushort *)(lVar9 + 4) & 0xedff;
      *(undefined4 *)(lVar9 + 0x40) = 1;
      *(undefined4 *)(&stack0x0000053c + lVar6) = 0;
      if (-1 < *(char *)(lVar9 + 2)) {
        pbVar11 = (byte *)((ulonglong)*(ushort *)(*(longlong *)(&stack0x00000040 + lVar6) + 0x1ffe)
                          + *(longlong *)(&stack0x00000040 + lVar6));
        bVar1 = *pbVar11;
        *(byte **)(&stack0x00000510 + lVar6) = pbVar11;
        if ((bVar1 & 1) == 0) {
          *(undefined2 *)(&stack0x00000508 + lVar6) = 0;
          *(undefined4 *)(&stack0x0000050c + lVar6) = 0;
          *(undefined4 *)(&stack0x0000052e + lVar6) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100410 */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar11 & 0xe) * 4 + 0xff3a0) - 0x25c60))
                    ();
          return;
        }
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

