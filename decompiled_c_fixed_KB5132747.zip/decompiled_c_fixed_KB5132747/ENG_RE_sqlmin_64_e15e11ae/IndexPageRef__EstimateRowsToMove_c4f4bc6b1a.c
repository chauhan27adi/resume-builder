
undefined8 FUN_(longlong **param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  code *UNRECOVERED_JUMPTABLE;
  byte *pbVar3;
  
  lVar1 = **param_1;
  if (*(short *)(lVar1 + 0x16) == 0) {
    return 0;
  }
  pbVar3 = (byte *)((ulonglong)*(ushort *)(lVar1 + 0x1ffe) + lVar1);
  if ((*pbVar3 & 1) != 0) {
    UNRECOVERED_JUMPTABLE =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x100a48) * 4 +
                           0x100a38) - 0xe8af50);
                    /* WARNING: Could not emulate address calculation at 0x001000b2 */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
    return uVar2;
  }
                    /* WARNING: Could not emulate address calculation at 0x0010021e */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x100a68) - 0xe8af50)
          )(0xffffffff,(longlong)(int)(*pbVar3 & 0xe),0);
  return uVar2;
}

