
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2,undefined8 param_3)

{
  ushort *puVar1;
  longlong *plVar2;
  ushort *puVar3;
  byte bVar4;
  char cVar5;
  ushort uVar6;
  int iVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong lVar10;
  short sVar11;
  uint uVar12;
  uint uVar13;
  ulonglong uVar14;
  uint uVar15;
  ulonglong uVar16;
  longlong lVar17;
  byte *pbVar18;
  ushort uVar19;
  ulonglong uVar20;
  int iVar21;
  ushort *puVar22;
  uint *puVar23;
  undefined auStack_a8 [32];
  uint *puStack_88;
  undefined4 uStack_80;
  undefined4 *puStack_78;
  uint uStack_70;
  undefined4 uStack_68;
  uint uStack_64;
  undefined auStack_60 [8];
  undefined auStack_58 [8];
  uint auStack_50 [2];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_a8;
  lVar17 = *(longlong *)(param_1 + 8);
  puVar1 = (ushort *)(param_2 + 1);
  puVar23 = (uint *)(lVar17 + 0x210);
  if (*param_2 != 0) {
    puStack_88 = &uStack_64;
    uStack_64 = 0;
    lVar8 = func_0x(puVar1,puVar23,param_3,&uStack_68);
    if ((((((*param_2 != 0) && (plVar2 = *(longlong **)(param_2 + 8), plVar2 != (longlong *)0x0)) &&
          (*plVar2 != 0)) && (((*(byte *)(lVar17 + 0x216) & 8) == 0 && ((uStack_64 & 1) == 0)))) &&
        (lVar8 != 0)) && (lVar8 != 0xa71f40)) {
      uStack_70 = uStack_64;
      puStack_78 = &uStack_68;
      puStack_88 = auStack_50;
      uStack_80 = 6;
      func_0x(plVar2,puVar23,lVar8,uStack_68);
    }
    goto LAB_;
  }
  uVar12 = *puVar23;
  if ((uVar12 & 0xc0000000) == 0x80000000) {
    iVar7 = func_0x(puVar1);
    if (iVar7 != 0) {
      func_0x(param_2 + 0x15,puVar23,&uStack_68,auStack_60);
    }
    goto LAB_;
  }
  uVar19 = *(ushort *)(lVar17 + 0x216) & 0x10;
  if (uVar19 != 0) {
    bVar4 = **(byte **)(param_2 + 4);
    if ((bVar4 & 0x10) == 0) {
      if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) goto LAB_;
    }
    else if (((int)*(uint *)(param_2 + 8) <= (int)uVar12) ||
            (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
             *(ushort *)(lVar17 + 0x214))) goto LAB_;
  }
  if (-1 < (int)uVar12) {
    if ((*(ushort *)(lVar17 + 0x216) & 8) != 0) goto LAB_;
    if (uVar19 != 0) {
      bVar4 = **(byte **)(param_2 + 4);
      if ((bVar4 & 0x10) == 0) {
        if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) goto LAB_;
      }
      else if (((int)*(uint *)(param_2 + 8) <= (int)uVar12) ||
              (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
               *(ushort *)(lVar17 + 0x214))) {
LAB_:
        if (**(int **)(lVar17 + 0x218) != 6) {
          puStack_88 = (uint *)0x0;
          (*_DAT_)(1,0xe9b6f0,0xe9a058,0x381);
        }
        goto LAB_;
      }
    }
    uStack_68 = 6;
    goto LAB_;
  }
  if (*(int *)(param_2 + 2) == 0) {
    pbVar18 = *(byte **)(param_2 + 4);
    iVar7 = 0;
    uVar12 = *(uint *)(param_2 + 8);
    uVar14 = (ulonglong)uVar12;
    *puVar1 = 0;
    *(uint *)(param_2 + 10) = uVar12;
    bVar4 = *pbVar18;
    if ((bVar4 & 0x10) != 0) {
      uVar12 = uVar12 + 2 + (*(ushort *)(pbVar18 + uVar14) + 7 >> 3);
      uVar14 = (ulonglong)uVar12;
      *(uint *)(param_2 + 10) = uVar12;
      bVar4 = *pbVar18;
    }
    if ((bVar4 & 0x20) == 0) {
      *(int *)(param_2 + 2) = (int)uVar14;
      param_2[0xe] = 0;
      *(int *)(param_2 + 0xc) = (int)uVar14;
    }
    else {
      puVar22 = (ushort *)(pbVar18 + uVar14);
      uVar19 = *puVar22;
      param_2[0xe] = uVar19;
      if (uVar19 == 0) {
        cVar5 = func_0x(0x13fd8a0);
        if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar5 = func_0x(0x13fd8a0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            puStack_88 = (uint *)0x0;
            (*_DAT_)(1,0xced2ac,0xe0d398,0x80f);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),3);
        uVar14 = (ulonglong)*(uint *)(param_2 + 10);
        uVar19 = param_2[0xe];
      }
      uVar12 = (int)uVar14 + (uVar19 + 1) * 2;
      *(uint *)(param_2 + 0xc) = uVar12;
      if (0x1f9e < uVar12) {
        cVar5 = func_0x(0x13fd8a0);
        if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar5 = func_0x(0x13fd8a0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            puStack_88 = (uint *)0x0;
            (*_DAT_)(1,0xced2ac,0xe0d398,0x816);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),4);
        uVar19 = param_2[0xe];
        uVar12 = *(uint *)(param_2 + 0xc);
      }
      uVar14 = (ulonglong)uVar19;
      uVar19 = puVar22[uVar14];
      *(uint *)(param_2 + 2) = uVar19 & 0x7fff;
      if ((uVar19 & 0x7fff) < uVar12) {
        cVar5 = func_0x(0x13fd8a0);
        if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar5 = func_0x(0x13fd8a0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            puStack_88 = (uint *)0x0;
            (*_DAT_)(1,0xced2ac,0xe0d398,0x81d);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),4);
        uVar12 = *(uint *)(param_2 + 0xc);
        uVar14 = (ulonglong)(ushort)param_2[0xe];
      }
      puVar3 = puVar22;
      iVar21 = iVar7;
      if ((short)uVar14 != 0) {
        do {
          uVar15 = puVar3[1] & 0x7fff;
          if ((uVar15 < uVar12) || (*(uint *)(param_2 + 2) < uVar15)) {
            cVar5 = func_0x(0x13fd8a0);
            if ((cVar5 != '\0') &&
               ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')
                ))) {
              cVar5 = func_0x(0x13fd8a0);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                puStack_88 = (uint *)0x0;
                (*_DAT_)(1,0xced2ac,0xe0d398,0x82a);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
          }
          uVar14 = (ulonglong)(ushort)param_2[0xe];
          iVar21 = iVar21 + 1;
          puVar3 = puVar3 + 1;
          uVar12 = uVar15;
        } while (iVar21 < (int)(uint)(ushort)param_2[0xe]);
      }
      if ((short)puVar22[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
        pbVar18 = *(byte **)(param_2 + 4);
        do {
          uVar12 = *(ushort *)(pbVar18 + uVar14 * 2 + (ulonglong)*(uint *)(param_2 + 10)) & 0x7fff;
          if ((int)uVar14 == 1) {
            uVar15 = *(uint *)(param_2 + 0xc);
            uVar13 = uVar15;
LAB_:
            if ((uVar12 < uVar15) || (*(uint *)(param_2 + 2) < uVar12)) goto LAB_;
          }
          else {
            uVar13 = *(uint *)(param_2 + 0xc);
            uVar15 = *(ushort *)(pbVar18 + uVar14 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) &
                     0x7fff;
            if (uVar13 <= uVar15) goto LAB_;
LAB_:
            func_0x(pbVar18,7);
            uVar13 = *(uint *)(param_2 + 0xc);
          }
          if ((uVar15 < uVar13) || (*(uint *)(param_2 + 2) < uVar15)) goto LAB_;
          pbVar18 = *(byte **)(param_2 + 4);
          if (*(ushort *)(pbVar18 + uVar15) == 5) {
            *puVar1 = *puVar1 | 2;
            param_2[0xe] = param_2[0xe] + -1;
            uVar20 = (ulonglong)(uVar15 & 0xffff);
            param_2[0x15] = (short)uVar15;
            uVar14 = *(ulonglong *)(param_2 + 4);
            uVar19 = param_2[0x16] & 0xc7ffU;
            if ((*(ushort *)(uVar20 + 2 + uVar14) >> 0xe & 1) != 0) {
              uVar19 = *(ushort *)(uVar20 + 2 + uVar14) & 0x3800 | param_2[0x16] & 0xc7ffU;
            }
            param_2[0x16] = uVar19;
            uVar6 = (uVar19 ^ *(ushort *)(uVar20 + 2 + uVar14)) & 0x7ff ^ uVar19;
            param_2[0x16] = uVar6;
            uVar16 = (ulonglong)((uVar6 & 0x7ff) * 2) + 4 + uVar14 + (uVar19 >> 0xb & 7) * 2 +
                     uVar20;
            if (uVar16 < uVar20 + uVar14) {
              func_0x(uVar20 + uVar14,0x19);
              uVar6 = param_2[0x16];
              uVar20 = (ulonglong)(ushort)param_2[0x15];
              uVar14 = (ulonglong)*(uint *)(param_2 + 4);
            }
            if (uVar12 - uVar15 < (((uVar6 & 0x7ff) * 2 - (int)uVar20) - (int)uVar14) + (int)uVar16)
            {
              func_0x(uVar20 + *(longlong *)(param_2 + 4),0x19);
              uVar6 = param_2[0x16];
            }
            if (((uVar6 & 0x3800) != 0) &&
               (puVar22 = (ushort *)
                          (*(longlong *)(param_2 + 4) + 4 + (ulonglong)(ushort)param_2[0x15]),
               (uVar6 & 0x3800) != 0)) {
              do {
                if ((uVar6 & 0x7ff) < (*puVar22 & 0x7ff)) {
                  func_0x((ulonglong)(ushort)param_2[0x15] + *(longlong *)(param_2 + 4),0x1a
                                 );
                  uVar6 = param_2[0x16];
                }
                iVar7 = iVar7 + 1;
                puVar22 = puVar22 + 1;
              } while (iVar7 < (int)(uVar6 >> 0xb & 7));
            }
            goto LAB_;
          }
          if (*(ushort *)(pbVar18 + uVar15) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar19 = param_2[0xe] - 1;
          param_2[0xe] = uVar19;
          if (uVar19 == 0) goto LAB_;
          uVar14 = (ulonglong)uVar19;
        } while ((short)puVar22[(ulonglong)(uVar19 - 1) + 1] < 0);
        uVar14 = (ulonglong)*(uint *)(param_2 + 2);
      }
      else {
LAB_:
        pbVar18 = *(byte **)(param_2 + 4);
        uVar14 = (ulonglong)*(uint *)(param_2 + 2);
      }
    }
    if ((*pbVar18 & 0x40) == 0) {
      *(undefined4 *)(param_2 + 0x13) = 0;
    }
    else {
      *(int *)(param_2 + 0x13) = (int)uVar14;
      *(int *)(param_2 + 2) = (int)uVar14 + 0xe;
      uVar9 = func_0x(puVar1);
      func_0x(uVar9,auStack_58);
      iVar7 = func_0x(auStack_58);
      *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar7;
      uVar14 = (ulonglong)*(uint *)(param_2 + 2);
    }
    iVar7 = (int)uVar14;
    if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
       (*(ulonglong *)(param_2 + 0xf) < uVar14 + *(longlong *)(param_2 + 4))) {
      cVar5 = func_0x(0x13fd8a0);
      if ((cVar5 != '\0') &&
         ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')))) {
        cVar5 = func_0x(0x13fd8a0);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          puStack_88 = (uint *)0x0;
          (*_DAT_)(1,0xced2ac,0xe0d398,0x886);
        }
      }
      func_0x(*(undefined8 *)(param_2 + 4),0x12);
      iVar7 = *(int *)(param_2 + 2);
    }
    if (0x3f3b < iVar7 - 1U) {
      cVar5 = func_0x(0x13fd8a0);
      if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
         (*(char *)(lVar8 + 0x499) != '\0')) {
        cVar5 = func_0x(0x13fd8a0);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          puStack_88 = (uint *)0x0;
          (*_DAT_)(1,0xced2ac,0xe0d398,0x88b);
        }
      }
      func_0x(*(undefined8 *)(param_2 + 4),5);
    }
  }
LAB_:
  sVar11 = -*(short *)puVar23;
  if ((*(byte *)(lVar17 + 0x216) & 0x10) != 0) {
    bVar4 = **(byte **)(param_2 + 4);
    if ((bVar4 & 0x10) == 0) {
      if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) goto LAB_;
    }
    else if (((int)*(uint *)(param_2 + 8) <= (int)*puVar23) ||
            (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
             *(ushort *)(lVar17 + 0x214))) goto LAB_;
  }
  lVar17 = *(longlong *)(param_2 + 4);
  lVar8 = (longlong)sVar11;
  if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar11) goto LAB_;
  lVar10 = (ulonglong)*(uint *)(param_2 + 10) + lVar17;
  if (sVar11 == 1) {
    uVar19 = *(ushort *)(lVar10 + lVar8 * 2);
    uVar12 = *(uint *)(param_2 + 0xc);
LAB_:
    if ((uVar12 <= (uVar19 & 0x7fff)) && ((uVar19 & 0x7fff) <= *(uint *)(param_2 + 2)))
    goto LAB_;
  }
  else {
    uVar19 = *(ushort *)(lVar10 + lVar8 * 2);
    uVar12 = *(ushort *)(lVar10 + -2 + lVar8 * 2) & 0x7fff;
    lVar17 = *(longlong *)(param_2 + 4);
    if (*(uint *)(param_2 + 0xc) <= uVar12) goto LAB_;
  }
  func_0x(lVar17,7);
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_a8);
  return;
}

