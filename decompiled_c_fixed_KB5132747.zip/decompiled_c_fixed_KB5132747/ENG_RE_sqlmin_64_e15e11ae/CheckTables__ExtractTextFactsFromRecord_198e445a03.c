
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong param_2,undefined param_3)

{
  ushort *puVar1;
  longlong *plVar2;
  bool bVar3;
  undefined uVar4;
  undefined2 uVar5;
  undefined *puVar6;
  char cVar7;
  int iVar8;
  uint *puVar9;
  longlong lVar10;
  longlong lVar11;
  undefined8 uVar12;
  byte bVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  byte bVar16;
  uint uVar17;
  undefined *puVar18;
  uint uVar19;
  int *piVar20;
  ulonglong uVar21;
  ushort uVar22;
  short sVar23;
  byte *pbVar24;
  ulonglong uVar25;
  int iVar26;
  short *psVar27;
  undefined4 uVar28;
  ulonglong uVar29;
  ushort uVar30;
  uint uVar31;
  ushort *puVar32;
  ushort *puVar33;
  undefined auStack_148 [96];
  undefined auStack_e8 [4];
  int iStack_e4;
  uint uStack_e0;
  undefined4 uStack_dc;
  int *piStack_d8;
  undefined2 uStack_d0;
  undefined2 uStack_ce;
  uint uStack_cc;
  ushort uStack_c8;
  uint uStack_c4;
  uint uStack_c0;
  longlong lStack_b8;
  uint uStack_b0;
  undefined4 uStack_ac;
  byte bStack_a8;
  undefined2 uStack_a7;
  undefined uStack_a5;
  undefined4 uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined2 uStack_84;
  undefined2 uStack_82;
  longlong lStack_80;
  undefined4 uStack_78;
  undefined2 uStack_74;
  undefined2 uStack_72;
  longlong lStack_70;
  longlong lStack_68;
  short *psStack_60;
  ushort *puStack_58;
  undefined *puStack_50;
  undefined8 uStack_48;
  undefined auStack_40 [8];
  ulonglong uStack_38;
  
  puVar18 = auStack_148;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_e8;
  uVar29 = 0;
  uStack_e0 = 0;
  lStack_70 = *(longlong *)(param_2 + 0x98);
  uStack_dc = (uint)(uStack_dc._2_2_ & 0xffe0) << 0x10;
  piStack_d8 = (int *)0x0;
  lVar10 = *(longlong *)(lStack_70 + 0x80);
  uStack_c4 = 0;
  lVar11 = *(longlong *)(lVar10 + 8);
  puStack_50 = (undefined *)0x0;
  uVar15 = uVar29;
  auStack_e8[0] = param_3;
  lStack_80 = lVar10;
  lStack_68 = param_2;
  uStack_48 = param_1;
  if (*(int *)(lVar11 + 0x100) == 2) {
    if ((*(byte *)(lVar11 + 0x42) & 4) == 0) {
      uVar15 = (ulonglong)*(uint *)(lVar11 + 0xb0);
      if (0x1f9e < *(uint *)(lVar11 + 0xb0)) {
        uVar15 = 0x1f9e;
      }
    }
    else {
      uVar15 = 0x1f9e;
    }
    uStack_c4 = (uint)uVar15;
    uVar14 = uVar15 + 0xf;
    if (uVar14 <= uVar15) {
      uVar14 = 0xffffffffffffff0;
    }
    uVar14 = uVar14 & 0xfffffffffffffff0;
    func_0x();
    puVar18 = auStack_148 + -uVar14;
    puStack_50 = auStack_e8 + -uVar14;
  }
  psVar27 = (short *)(param_2 + 0xa0);
  uVar14 = *(ulonglong *)(param_2 + 0xa8) & 0xffffffffffffe000;
  uStack_ac = *(undefined4 *)(uVar14 + 0x20);
  uStack_d0 = *(undefined2 *)(uVar14 + 0x24);
  uStack_ce = *(undefined2 *)(param_2 + 0xd4);
  pbVar24 = *(byte **)(param_2 + 0xa8);
  if (*psVar27 == 0) {
    bVar16 = *pbVar24 & 0xe;
    param_2 = lStack_68;
    if (bVar16 == 2) {
      bVar3 = false;
      if ((pbVar24[1] & 1) != 0) {
        bVar3 = true;
      }
    }
    else {
      bVar3 = false;
      if (((bVar16 - 10 & 0xf9) == 0) && (bVar3 = false, bVar16 != 0x10)) {
        bVar3 = true;
      }
    }
  }
  else {
    bVar3 = ((*pbVar24 & 0x1c) - 4 & 0xffffffe7) == 0;
  }
  psStack_60 = psVar27;
  if (!bVar3) {
    puVar1 = (ushort *)(param_2 + 0xa2);
    if (*psVar27 == 0) {
      *(undefined8 *)(puVar18 + -8) = 0x100197;
      uStack_c0 = func_0x(puVar1);
      lVar10 = lStack_80;
    }
    else {
      uStack_c0 = (uint)*puVar1;
    }
    uStack_cc = 0;
    if (0 < (int)uStack_c0) {
      do {
        uVar17 = (uint)uVar29;
        puVar9 = (uint *)0x0;
        uVar30 = ~(ushort)uVar29;
        uVar19 = (uint)(short)uVar30;
        uStack_c8 = uVar30;
        if (-1 < (short)(ushort)uVar29) {
          if ((uVar19 & 0xc0000000) == 0x80000000) {
            uVar12 = **(undefined8 **)(*(longlong *)(lVar10 + 8) + 0x160);
            *(undefined8 *)(puVar18 + -8) = 0x100215;
            puVar9 = (uint *)func_0x(uVar12,uVar19 & 0x1fffffff);
          }
          else {
            uVar12 = *(undefined8 *)(*(longlong *)(lVar10 + 8) + 0x160);
            *(undefined8 *)(puVar18 + -8) = 0x1001fa;
            puVar9 = (uint *)func_0x(uVar12);
          }
        }
        lVar10 = lStack_80;
        uVar28 = 0;
        if (puVar9 == (uint *)0x0) {
          *(undefined8 *)(puVar18 + -8) = 0x100230;
          func_0x(lVar10,uVar19,&uStack_e0);
        }
        else {
          uStack_e0 = *puVar9;
          uStack_dc = puVar9[1];
          piStack_d8 = *(int **)(puVar9 + 2);
          if ((((*(int *)(lStack_70 + 0x328) == 3) && (uVar22 = 0, DAT_ != '\0')) &&
              ((DAT_ & 0x10) == 0)) && ((DAT_ != '\0' && ((DAT_ & 1) == 0)))
             ) {
            uStack_a7 = 0;
            uStack_a5 = 0;
            uStack_94 = 0;
            bStack_a8 = 0;
            uStack_a4 = 0;
            uStack_a0 = 0xffffffffffffffff;
            uStack_98 = 0;
            uStack_8c = 0;
            *(undefined8 *)(puVar18 + -8) = 0x100338;
            func_0x(puVar9,&bStack_a8);
            if (((short)uStack_98 == -1) ||
               (*(char *)((ulonglong)*(byte *)((ulonglong)bStack_a8 + 0xaf5540) + 0x14ac5d8) != '\0'
               )) {
              if (*psVar27 == 0) {
                pbVar24 = *(byte **)(psVar27 + 4);
                if ((*pbVar24 & 0x10) == 0) {
                  if ((1 << (*pbVar24 & 0xe) & 0x1105U) != 0) {
LAB_:
                    uVar22 = ~(uStack_dc._2_2_ >> 4) & 1;
                  }
                }
                else {
                  uVar19 = *(uint *)(psVar27 + 8);
                  if ((int)uStack_e0 < (int)uVar19) {
                    if ((uint)*(ushort *)(pbVar24 + uVar19) < (uStack_dc & 0xffff))
                    goto LAB_;
                    uVar31 = (uStack_dc & 0xffff) - 1;
                    uVar22 = pbVar24[(ulonglong)(uVar31 >> 3) + (ulonglong)uVar19 + 2] >>
                             ((byte)uVar31 & 7) & 1;
                  }
                  else {
                    uVar22 = ~(uStack_dc._2_2_ >> 4) & 1;
                  }
                }
              }
              else if ((ushort)psVar27[1] < (ushort)uStack_dc) {
                uVar22 = ~(uStack_dc._2_2_ >> 4) & 1;
              }
              else {
                bVar16 = *(byte *)((longlong)((int)((uStack_dc & 0xffff) - 1) / 2) +
                                   (ulonglong)(ushort)psVar27[0xc] + *(longlong *)(psVar27 + 4));
                bVar13 = bVar16 >> 4;
                if ((uStack_dc & 1) != 0) {
                  bVar13 = bVar16 & 0xf;
                }
                uVar22 = (ushort)(bVar13 == 0);
              }
              if (uVar22 == 0) {
                uVar28 = 1;
              }
            }
          }
        }
        piVar20 = (int *)0x0;
        *(undefined8 *)(puVar18 + -8) = 0x10023e;
        iVar8 = func_0x(psVar27,&uStack_e0);
        if ((iVar8 != 0) || ((char)uVar28 != '\0')) {
          if (*psVar27 == 0) {
            if ((uStack_e0 & 0xc0000000) == 0x80000000) {
              *(undefined8 *)(puVar18 + -8) = 0x100ccb;
              iVar8 = func_0x(puVar1);
              if (iVar8 == 0) {
                iStack_e4 = 0;
                iVar8 = iStack_e4;
              }
              else {
                *(undefined8 *)(puVar18 + -8) = 0x100ce4;
                piVar20 = (int *)func_0x(param_2 + 0xca,&uStack_e0,&iStack_e4,&lStack_b8);
                iVar8 = iStack_e4;
              }
            }
            else {
              uVar22 = uStack_dc._2_2_ >> 4 & 1;
              uVar17 = uStack_cc;
              if (uVar22 == 0) {
LAB_:
                if ((int)uStack_e0 < 0) {
                  if (*(int *)(param_2 + 0xa4) == 0) {
                    pbVar24 = *(byte **)(param_2 + 0xa8);
                    uVar17 = *(uint *)(param_2 + 0xb0);
                    uVar15 = (ulonglong)uVar17;
                    *puVar1 = 0;
                    *(uint *)(param_2 + 0xb4) = uVar17;
                    bVar16 = *pbVar24;
                    if ((bVar16 & 0x10) != 0) {
                      uVar17 = uVar17 + 2 + (*(ushort *)(pbVar24 + uVar15) + 7 >> 3);
                      uVar15 = (ulonglong)uVar17;
                      *(uint *)(param_2 + 0xb4) = uVar17;
                      bVar16 = *pbVar24;
                    }
                    if ((bVar16 & 0x20) == 0) {
                      *(int *)(param_2 + 0xa4) = (int)uVar15;
                      *(undefined2 *)(param_2 + 0xbc) = 0;
                      *(int *)(param_2 + 0xb8) = (int)uVar15;
                    }
                    else {
                      puVar32 = (ushort *)(pbVar24 + uVar15);
                      uVar30 = *puVar32;
                      *(ushort *)(param_2 + 0xbc) = uVar30;
                      if (uVar30 == 0) {
                        *(undefined8 *)(puVar18 + -8) = 0x1005ba;
                        cVar7 = func_0x(0x1480880);
                        if (cVar7 != '\0') {
                          *(undefined8 *)(puVar18 + -8) = 0x1005c3;
                          lVar10 = func_0x();
                          if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar18 + -8) = 0x1005dd;
                            cVar7 = func_0x(0x1480880);
                            if (cVar7 == '\0') {
                              *(undefined8 *)(puVar18 + -8) = 0x1005f9;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar18 + 0x20) = 0;
                              *(undefined8 *)(puVar18 + -8) = 0x10061c;
                              (*_DAT_)(1,0xd7028c,0xe90378,0x80f);
                            }
                          }
                        }
                        uVar12 = *(undefined8 *)(param_2 + 0xa8);
                        *(undefined8 *)(puVar18 + -8) = 0x10062a;
                        func_0x(uVar12,3);
                        uVar15 = (ulonglong)*(uint *)(param_2 + 0xb4);
                        uVar30 = *(ushort *)(param_2 + 0xbc);
                      }
                      uVar17 = (int)uVar15 + (uVar30 + 1) * 2;
                      *(uint *)(param_2 + 0xb8) = uVar17;
                      if (0x1f9e < uVar17) {
                        *(undefined8 *)(puVar18 + -8) = 0x10065a;
                        cVar7 = func_0x(0x1480880);
                        if (cVar7 != '\0') {
                          *(undefined8 *)(puVar18 + -8) = 0x100663;
                          lVar10 = func_0x();
                          if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar18 + -8) = 0x10067d;
                            cVar7 = func_0x(0x1480880);
                            if (cVar7 == '\0') {
                              *(undefined8 *)(puVar18 + -8) = 0x100699;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar18 + 0x20) = 0;
                              *(undefined8 *)(puVar18 + -8) = 0x1006bc;
                              (*_DAT_)(1,0xd7028c,0xe90378,0x816);
                            }
                          }
                        }
                        uVar12 = *(undefined8 *)(param_2 + 0xa8);
                        *(undefined8 *)(puVar18 + -8) = 0x1006ca;
                        func_0x(uVar12,4);
                        uVar30 = *(ushort *)(param_2 + 0xbc);
                        uVar17 = *(uint *)(param_2 + 0xb8);
                      }
                      uVar15 = (ulonglong)uVar30;
                      uVar30 = puVar32[uVar15];
                      *(uint *)(param_2 + 0xa4) = uVar30 & 0x7fff;
                      if ((uVar30 & 0x7fff) < uVar17) {
                        *(undefined8 *)(puVar18 + -8) = 0x1006fa;
                        cVar7 = func_0x(0x1480880);
                        if (cVar7 != '\0') {
                          *(undefined8 *)(puVar18 + -8) = 0x100703;
                          lVar10 = func_0x();
                          if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar18 + -8) = 0x10071d;
                            cVar7 = func_0x(0x1480880);
                            if (cVar7 == '\0') {
                              *(undefined8 *)(puVar18 + -8) = 0x100739;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar18 + 0x20) = 0;
                              *(undefined8 *)(puVar18 + -8) = 0x10075c;
                              (*_DAT_)(1,0xd7028c,0xe90378,0x81d);
                            }
                          }
                        }
                        uVar12 = *(undefined8 *)(param_2 + 0xa8);
                        *(undefined8 *)(puVar18 + -8) = 0x10076a;
                        func_0x(uVar12,4);
                        uVar17 = *(uint *)(param_2 + 0xb8);
                        uVar15 = (ulonglong)*(ushort *)(param_2 + 0xbc);
                      }
                      puVar33 = puVar32;
                      if ((short)uVar15 != 0) {
                        do {
                          uVar19 = puVar33[1] & 0x7fff;
                          if ((uVar19 < uVar17) || (*(uint *)(param_2 + 0xa4) < uVar19)) {
                            *(undefined8 *)(puVar18 + -8) = 0x1007af;
                            cVar7 = func_0x(0x1480880);
                            if (cVar7 != '\0') {
                              *(undefined8 *)(puVar18 + -8) = 0x1007b8;
                              lVar10 = func_0x();
                              if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar18 + -8) = 0x1007d2;
                                cVar7 = func_0x(0x1480880);
                                if (cVar7 == '\0') {
                                  *(undefined8 *)(puVar18 + -8) = 0x1007ee;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar18 + 0x20) = 0;
                                  *(undefined8 *)(puVar18 + -8) = 0x100814;
                                  (*_DAT_)(1,0xd7028c,0xe90378,0x82a);
                                }
                              }
                            }
                            uVar12 = *(undefined8 *)(param_2 + 0xa8);
                            *(undefined8 *)(puVar18 + -8) = 0x100822;
                            func_0x(uVar12,4);
                          }
                          uVar15 = (ulonglong)*(ushort *)(param_2 + 0xbc);
                          uVar31 = (int)piVar20 + 1;
                          piVar20 = (int *)(ulonglong)uVar31;
                          psVar27 = psStack_60;
                          puVar33 = puVar33 + 1;
                          uVar17 = uVar19;
                        } while ((int)uVar31 < (int)(uint)*(ushort *)(param_2 + 0xbc));
                      }
                      if ((short)puVar32[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
                        pbVar24 = *(byte **)(param_2 + 0xa8);
                        do {
                          uVar17 = *(ushort *)
                                    (pbVar24 + uVar15 * 2 + (ulonglong)*(uint *)(param_2 + 0xb4)) &
                                   0x7fff;
                          if ((int)uVar15 == 1) {
                            uVar19 = *(uint *)(param_2 + 0xb8);
                            uVar29 = (ulonglong)uVar19;
LAB_:
                            if ((uVar17 < (uint)uVar29) || (*(uint *)(param_2 + 0xa4) < uVar17))
                            goto LAB_;
                          }
                          else {
                            uVar19 = *(uint *)(param_2 + 0xb8);
                            uVar29 = (ulonglong)
                                     (*(ushort *)
                                       (pbVar24 +
                                       uVar15 * 2 + ((ulonglong)*(uint *)(param_2 + 0xb4) - 2)) &
                                     0x7fff);
                            if (uVar19 <= (*(ushort *)
                                            (pbVar24 +
                                            uVar15 * 2 + ((ulonglong)*(uint *)(param_2 + 0xb4) - 2))
                                          & 0x7fff)) goto LAB_;
LAB_:
                            *(undefined8 *)(puVar18 + -8) = 0x1008a8;
                            func_0x(pbVar24,7);
                            uVar19 = *(uint *)(param_2 + 0xb8);
                          }
                          uVar31 = (uint)uVar29;
                          if ((uVar31 < uVar19) || (*(uint *)(param_2 + 0xa4) < uVar31))
                          goto LAB_;
                          pbVar24 = *(byte **)(param_2 + 0xa8);
                          if (*(ushort *)(pbVar24 + uVar29) == 5) {
                            *puVar1 = *puVar1 | 2;
                            *(short *)(param_2 + 0xbc) = *(short *)(param_2 + 0xbc) + -1;
                            uVar30 = *(ushort *)(param_2 + 0xcc) & 0xc7ff;
                            uVar14 = uVar29 & 0xffff;
                            *(short *)(param_2 + 0xca) = (short)uVar29;
                            uVar15 = *(ulonglong *)(param_2 + 0xa8);
                            if ((*(ushort *)(uVar14 + 2 + uVar15) >> 0xe & 1) != 0) {
                              uVar30 = *(ushort *)(uVar14 + 2 + uVar15) & 0x3800 | uVar30;
                            }
                            *(ushort *)(param_2 + 0xcc) = uVar30;
                            uVar21 = (ulonglong)*(ushort *)(param_2 + 0xca);
                            uVar22 = (uVar30 ^ *(ushort *)(uVar14 + 2 + uVar15)) & 0x7ff ^ uVar30;
                            *(ushort *)(param_2 + 0xcc) = uVar22;
                            uVar29 = (ulonglong)((uVar22 & 0x7ff) * 2) + 4 +
                                     uVar21 + (uVar30 >> 0xb & 7) * 2 + uVar15;
                            if (uVar29 < uVar21 + uVar15) {
                              *(undefined8 *)(puVar18 + -8) = 0x1009b9;
                              func_0x(uVar21 + uVar15,0x19);
                              uVar22 = *(ushort *)(param_2 + 0xcc);
                              uVar21 = (ulonglong)*(ushort *)(param_2 + 0xca);
                              uVar15 = (ulonglong)*(uint *)(param_2 + 0xa8);
                            }
                            if (uVar17 - uVar31 <
                                (((uVar22 & 0x7ff) * 2 - (int)uVar21) - (int)uVar15) + (int)uVar29)
                            {
                              lVar10 = *(longlong *)(param_2 + 0xa8);
                              *(undefined8 *)(puVar18 + -8) = 0x1009f1;
                              func_0x(uVar21 + lVar10,0x19);
                              uVar22 = *(ushort *)(param_2 + 0xcc);
                            }
                            if ((uVar22 & 0x3800) != 0) {
                              puVar32 = (ushort *)
                                        (*(longlong *)(param_2 + 0xa8) +
                                        (ulonglong)*(ushort *)(param_2 + 0xca) + 4);
                              iVar8 = 0;
                              if ((uVar22 & 0x3800) != 0) {
                                do {
                                  if ((uVar22 & 0x7ff) < (*puVar32 & 0x7ff)) {
                                    uVar30 = *(ushort *)(param_2 + 0xca);
                                    lVar10 = *(longlong *)(param_2 + 0xa8);
                                    *(undefined8 *)(puVar18 + -8) = 0x100a47;
                                    func_0x((ulonglong)uVar30 + lVar10,0x1a);
                                    uVar22 = *(ushort *)(param_2 + 0xcc);
                                  }
                                  iVar8 = iVar8 + 1;
                                  puVar32 = puVar32 + 1;
                                } while (iVar8 < (int)(uVar22 >> 0xb & 7));
                              }
                            }
                            goto LAB_;
                          }
                          if (*(ushort *)(pbVar24 + uVar29) < 0x400) goto LAB_;
                          *puVar1 = *puVar1 | 1;
                          uVar30 = *(short *)(param_2 + 0xbc) - 1;
                          *(ushort *)(param_2 + 0xbc) = uVar30;
                          if (uVar30 == 0) goto LAB_;
                          uVar15 = (ulonglong)uVar30;
                        } while ((short)puVar32[(ulonglong)(uVar30 - 1) + 1] < 0);
                        uVar15 = (ulonglong)*(uint *)(param_2 + 0xa4);
                      }
                      else {
LAB_:
                        pbVar24 = *(byte **)(param_2 + 0xa8);
                        uVar15 = (ulonglong)*(uint *)(param_2 + 0xa4);
                      }
                    }
                    if ((*pbVar24 & 0x40) == 0) {
                      *(undefined4 *)(param_2 + 0xc6) = 0;
                    }
                    else {
                      *(int *)(param_2 + 0xc6) = (int)uVar15;
                      *(int *)(param_2 + 0xa4) = (int)uVar15 + 0xe;
                      *(undefined8 *)(puVar18 + -8) = 0x100a8e;
                      uVar12 = func_0x(puVar1);
                      *(undefined8 *)(puVar18 + -8) = 0x100a9d;
                      func_0x(uVar12,&puStack_58);
                      *(undefined8 *)(puVar18 + -8) = 0x100aa9;
                      iVar8 = func_0x(&puStack_58);
                      *(int *)(param_2 + 0xa4) = *(int *)(param_2 + 0xa4) + iVar8;
                      uVar15 = (ulonglong)*(uint *)(param_2 + 0xa4);
                    }
                    iVar8 = (int)uVar15;
                    if ((*(ulonglong *)(param_2 + 0xbe) != 0) &&
                       (*(ulonglong *)(param_2 + 0xbe) < uVar15 + *(longlong *)(param_2 + 0xa8))) {
                      *(undefined8 *)(puVar18 + -8) = 0x100ade;
                      cVar7 = func_0x(0x1480880);
                      if (cVar7 != '\0') {
                        *(undefined8 *)(puVar18 + -8) = 0x100ae7;
                        lVar10 = func_0x();
                        if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar18 + -8) = 0x100b01;
                          cVar7 = func_0x(0x1480880);
                          if (cVar7 == '\0') {
                            *(undefined8 *)(puVar18 + -8) = 0x100b1d;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            *(undefined8 *)(puVar18 + 0x20) = 0;
                            *(undefined8 *)(puVar18 + -8) = 0x100b43;
                            (*_DAT_)(1,0xd7028c,0xe90378,0x886);
                          }
                        }
                      }
                      uVar12 = *(undefined8 *)(param_2 + 0xa8);
                      *(undefined8 *)(puVar18 + -8) = 0x100b51;
                      func_0x(uVar12,0x12);
                      iVar8 = *(int *)(param_2 + 0xa4);
                    }
                    if (0x3f3b < iVar8 - 1U) {
                      *(undefined8 *)(puVar18 + -8) = 0x100b6a;
                      cVar7 = func_0x(0x1480880);
                      if (cVar7 != '\0') {
                        *(undefined8 *)(puVar18 + -8) = 0x100b73;
                        lVar10 = func_0x();
                        if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar18 + -8) = 0x100b8d;
                          cVar7 = func_0x(0x1480880);
                          if (cVar7 == '\0') {
                            *(undefined8 *)(puVar18 + -8) = 0x100ba9;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            *(undefined8 *)(puVar18 + 0x20) = 0;
                            *(undefined8 *)(puVar18 + -8) = 0x100bcf;
                            (*_DAT_)(1,0xd7028c,0xe90378,0x88b);
                          }
                        }
                      }
                      uVar12 = *(undefined8 *)(param_2 + 0xa8);
                      *(undefined8 *)(puVar18 + -8) = 0x100bdd;
                      func_0x(uVar12,5);
                    }
                  }
LAB_:
                  sVar23 = -(short)uStack_e0;
                  uVar17 = uStack_cc;
                  uVar30 = uStack_c8;
                  if ((uStack_dc & 0x100000) != 0) {
                    bVar16 = **(byte **)(param_2 + 0xa8);
                    if ((bVar16 & 0x10) == 0) {
                      if ((1 << (bVar16 & 0xe) & 0x1105U) != 0) {
LAB_:
                        piVar20 = piStack_d8 + 1;
                        iVar8 = *piStack_d8;
                        goto LAB_;
                      }
                    }
                    else if (((int)*(uint *)(param_2 + 0xb0) <= (int)uStack_e0) ||
                            (*(ushort *)(*(byte **)(param_2 + 0xa8) + *(uint *)(param_2 + 0xb0)) <
                             (ushort)uStack_dc)) goto LAB_;
                  }
                  piVar20 = *(int **)(param_2 + 0xa8);
                  if ((uint)*(ushort *)(param_2 + 0xbc) < (uint)(int)sVar23) {
                    iVar8 = 0;
                  }
                  else {
                    uVar19 = *(ushort *)
                              ((longlong)piVar20 +
                              (longlong)sVar23 * 2 + (ulonglong)*(uint *)(param_2 + 0xb4)) & 0x7fff;
                    if (sVar23 == 1) {
                      uVar31 = *(uint *)(param_2 + 0xb8);
LAB_:
                      if ((uVar19 < uVar31) || (*(uint *)(param_2 + 0xa4) < uVar19))
                      goto LAB_;
                    }
                    else {
                      uVar31 = *(ushort *)
                                ((longlong)piVar20 +
                                (longlong)sVar23 * 2 + ((ulonglong)*(uint *)(param_2 + 0xb4) - 2)) &
                               0x7fff;
                      if (*(uint *)(param_2 + 0xb8) <= uVar31) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar18 + -8) = 0x100c92;
                      func_0x(piVar20,7);
                      piVar20 = *(int **)(param_2 + 0xa8);
                    }
                    piVar20 = (int *)((longlong)piVar20 + (ulonglong)uVar31);
                    uVar17 = uStack_cc;
                    uVar30 = uStack_c8;
                    iVar8 = uVar19 - uVar31;
                  }
                }
                else if ((uStack_dc & 0x80000) == 0) {
                  if (uVar22 != 0) {
                    bVar16 = **(byte **)(param_2 + 0xa8);
                    if ((bVar16 & 0x10) == 0) {
                      if ((1 << (bVar16 & 0xe) & 0x1105U) != 0) {
LAB_:
                        iVar8 = *piStack_d8;
                        piVar20 = piStack_d8 + 1;
                        if (iVar8 != 0x1f9e) {
                          *(undefined8 *)(puVar18 + 0x20) = 0;
                          *(undefined8 *)(puVar18 + -8) = 0x10051a;
                          (*_DAT_)(1,0xf1e6d0,0xf1d038,0x381);
                          uVar17 = uStack_cc;
                        }
                        goto LAB_;
                      }
                    }
                    else if (((int)*(uint *)(param_2 + 0xb0) <= (int)uStack_e0) ||
                            (*(ushort *)(*(byte **)(param_2 + 0xa8) + *(uint *)(param_2 + 0xb0)) <
                             (ushort)uStack_dc)) goto LAB_;
                  }
                  piVar20 = (int *)((longlong)(int)uStack_e0 + *(longlong *)(param_2 + 0xa8));
                  iStack_e4 = 0x1f9e;
                  iVar8 = iStack_e4;
                }
                else {
                  piVar20 = (int *)0xaf4f20;
                  iStack_e4 = 1;
                  iVar8 = iStack_e4;
                  if ((*(byte *)((longlong)(int)uStack_e0 + *(longlong *)(param_2 + 0xa8)) &
                      (byte)(1 << (uStack_dc._2_1_ & 7))) == 0) {
                    piVar20 = (int *)0xaf4f21;
                  }
                }
              }
              else {
                bVar16 = **(byte **)(param_2 + 0xa8);
                if ((bVar16 & 0x10) == 0) {
                  if ((1 << (bVar16 & 0xe) & 0x1105U) == 0) goto LAB_;
                  piVar20 = piStack_d8 + 1;
                  iVar8 = *piStack_d8;
                }
                else {
                  if (((int)uStack_e0 < (int)*(uint *)(param_2 + 0xb0)) &&
                     ((ushort)uStack_dc <=
                      *(ushort *)(*(byte **)(param_2 + 0xa8) + *(uint *)(param_2 + 0xb0))))
                  goto LAB_;
                  piVar20 = piStack_d8 + 1;
                  iVar8 = *piStack_d8;
                }
              }
            }
          }
          else {
            uStack_b0 = 0;
            *(uint **)(puVar18 + 0x20) = &uStack_b0;
            *(undefined8 *)(puVar18 + -8) = 0x100d0d;
            piVar20 = (int *)func_0x(puVar1,&uStack_e0);
            iVar8 = iStack_e4;
            if ((((*psVar27 != 0) &&
                 (plVar2 = *(longlong **)(psVar27 + 8), plVar2 != (longlong *)0x0)) &&
                (*plVar2 != 0)) && (((uStack_dc & 0x80000) == 0 && ((uStack_b0 & 1) == 0)))) {
              if ((piVar20 == (int *)0x0) || (piVar20 == (int *)0xaf4f20)) {
                piVar20 = (int *)0x0;
                iStack_e4 = 0;
                iVar8 = iStack_e4;
              }
              else {
                *(uint *)(puVar18 + 0x38) = uStack_b0;
                *(int **)(puVar18 + 0x30) = &iStack_e4;
                puVar6 = puStack_50;
                *(int *)(puVar18 + 0x28) = (int)uVar15;
                *(undefined **)(puVar18 + 0x20) = puVar6;
                *(undefined8 *)(puVar18 + -8) = 0x100d74;
                piVar20 = (int *)func_0x(plVar2,&uStack_e0,piVar20,iVar8);
                iVar8 = iStack_e4;
              }
            }
          }
LAB_:
          iStack_e4 = iVar8;
          uVar12 = uStack_48;
          lVar11 = lStack_68;
          lVar10 = lStack_70;
          uVar4 = auStack_e8[0];
          uStack_88 = uStack_ac;
          uStack_84 = uStack_d0;
          uStack_82 = uStack_ce;
          *(undefined4 *)(puVar18 + 0x50) = uVar28;
          iVar8 = iStack_e4;
          *(ushort *)(puVar18 + 0x48) = uVar30;
          *(undefined4 *)(puVar18 + 0x40) = 0;
          *(uint *)(puVar18 + 0x38) = uVar17;
          *(int **)(puVar18 + 0x30) = piVar20;
          *(int *)(puVar18 + 0x28) = iVar8;
          *(undefined4 **)(puVar18 + 0x20) = &uStack_88;
          *(undefined8 *)(puVar18 + -8) = 0x100ddf;
          iVar8 = func_0x(uVar12,lVar11,uVar4,lVar10);
          if (iVar8 == 0) goto LAB_;
        }
        uVar15 = (ulonglong)uStack_c4;
        uStack_cc = uVar17 + 1;
        uVar29 = (ulonglong)uStack_cc;
        lVar10 = lStack_80;
      } while ((int)uStack_cc < (int)uStack_c0);
    }
    *(undefined8 *)(puVar18 + -8) = 0x100e0f;
    iVar8 = func_0x(psVar27);
    if (0 < iVar8) {
      *(undefined8 *)(puVar18 + -8) = 0x100e22;
      iVar8 = func_0x(psVar27);
      uVar15 = 0;
      if (0 < iVar8) {
        psStack_60 = (short *)(longlong)iVar8;
        lStack_b8 = 0;
        uStack_cc = 0;
LAB_:
        uVar29 = 0;
        if (*(int *)(param_2 + 0xa4) == 0) {
          pbVar24 = *(byte **)(param_2 + 0xa8);
          uVar17 = *(uint *)(param_2 + 0xb0);
          uVar14 = (ulonglong)uVar17;
          *puVar1 = 0;
          *(uint *)(param_2 + 0xb4) = uVar17;
          bVar16 = *pbVar24;
          if ((bVar16 & 0x10) != 0) {
            uVar17 = uVar17 + 2 + (*(ushort *)(pbVar24 + uVar14) + 7 >> 3);
            uVar14 = (ulonglong)uVar17;
            *(uint *)(param_2 + 0xb4) = uVar17;
            bVar16 = *pbVar24;
          }
          if ((bVar16 & 0x20) == 0) {
            *(int *)(param_2 + 0xa4) = (int)uVar14;
            *(undefined2 *)(param_2 + 0xbc) = 0;
            *(int *)(param_2 + 0xb8) = (int)uVar14;
          }
          else {
            puVar32 = (ushort *)(pbVar24 + uVar14);
            uVar30 = *puVar32;
            *(ushort *)(param_2 + 0xbc) = uVar30;
            puStack_58 = puVar32;
            if (uVar30 == 0) {
              *(undefined8 *)(puVar18 + -8) = 0x100eaf;
              cVar7 = func_0x(0x1480880);
              if (cVar7 != '\0') {
                *(undefined8 *)(puVar18 + -8) = 0x100eb8;
                lVar10 = func_0x();
                if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar18 + -8) = 0x100ed2;
                  cVar7 = func_0x(0x1480880);
                  if (cVar7 == '\0') {
                    *(undefined8 *)(puVar18 + -8) = 0x100eee;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar18 + 0x20) = 0;
                    *(undefined8 *)(puVar18 + -8) = 0x100f11;
                    (*_DAT_)(1,0xd7028c,0xe90378,0x80f);
                  }
                }
              }
              uVar12 = *(undefined8 *)(param_2 + 0xa8);
              *(undefined8 *)(puVar18 + -8) = 0x100f1f;
              func_0x(uVar12,3);
              uVar14 = (ulonglong)*(uint *)(param_2 + 0xb4);
              uVar30 = *(ushort *)(param_2 + 0xbc);
            }
            uVar17 = (int)uVar14 + (uVar30 + 1) * 2;
            *(uint *)(param_2 + 0xb8) = uVar17;
            if (0x1f9e < uVar17) {
              *(undefined8 *)(puVar18 + -8) = 0x100f4f;
              cVar7 = func_0x(0x1480880);
              if (cVar7 != '\0') {
                *(undefined8 *)(puVar18 + -8) = 0x100f58;
                lVar10 = func_0x();
                if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar18 + -8) = 0x100f72;
                  cVar7 = func_0x(0x1480880);
                  if (cVar7 == '\0') {
                    *(undefined8 *)(puVar18 + -8) = 0x100f8e;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar18 + 0x20) = 0;
                    *(undefined8 *)(puVar18 + -8) = 0x100fb1;
                    (*_DAT_)(1,0xd7028c,0xe90378,0x816);
                  }
                }
              }
              uVar12 = *(undefined8 *)(param_2 + 0xa8);
              *(undefined8 *)(puVar18 + -8) = 0x100fbf;
              func_0x(uVar12,4);
              uVar30 = *(ushort *)(param_2 + 0xbc);
              uVar17 = *(uint *)(param_2 + 0xb8);
            }
            uVar14 = (ulonglong)uVar30;
            uVar30 = puVar32[uVar14];
            *(uint *)(param_2 + 0xa4) = uVar30 & 0x7fff;
            if ((uVar30 & 0x7fff) < uVar17) {
              *(undefined8 *)(puVar18 + -8) = 0x100fef;
              cVar7 = func_0x(0x1480880);
              if (cVar7 != '\0') {
                *(undefined8 *)(puVar18 + -8) = 0x100ff8;
                lVar10 = func_0x();
                if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar18 + -8) = 0x101012;
                  cVar7 = func_0x(0x1480880);
                  if (cVar7 == '\0') {
                    *(undefined8 *)(puVar18 + -8) = 0x10102e;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar18 + 0x20) = 0;
                    *(undefined8 *)(puVar18 + -8) = 0x101051;
                    (*_DAT_)(1,0xd7028c,0xe90378,0x81d);
                  }
                }
              }
              uVar12 = *(undefined8 *)(param_2 + 0xa8);
              *(undefined8 *)(puVar18 + -8) = 0x10105f;
              func_0x(uVar12,4);
              uVar17 = *(uint *)(param_2 + 0xb8);
              uVar14 = (ulonglong)*(ushort *)(param_2 + 0xbc);
            }
            uVar21 = uVar29;
            puVar33 = puVar32;
            if ((short)uVar14 != 0) {
              do {
                puVar32 = puVar32 + 1;
                uVar19 = *puVar32 & 0x7fff;
                if ((uVar19 < uVar17) || (*(uint *)(param_2 + 0xa4) < uVar19)) {
                  *(undefined8 *)(puVar18 + -8) = 0x10109f;
                  cVar7 = func_0x(0x1480880);
                  if (cVar7 != '\0') {
                    *(undefined8 *)(puVar18 + -8) = 0x1010a8;
                    lVar10 = func_0x();
                    if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar18 + -8) = 0x1010c2;
                      cVar7 = func_0x(0x1480880);
                      if (cVar7 == '\0') {
                        *(undefined8 *)(puVar18 + -8) = 0x1010de;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar18 + 0x20) = 0;
                        *(undefined8 *)(puVar18 + -8) = 0x101104;
                        (*_DAT_)(1,0xd7028c,0xe90378,0x82a);
                      }
                    }
                  }
                  uVar12 = *(undefined8 *)(param_2 + 0xa8);
                  *(undefined8 *)(puVar18 + -8) = 0x101112;
                  func_0x(uVar12,4);
                }
                uVar14 = (ulonglong)*(ushort *)(param_2 + 0xbc);
                uVar31 = (int)uVar21 + 1;
                uVar21 = (ulonglong)uVar31;
                puVar33 = puStack_58;
                uVar17 = uVar19;
              } while ((int)uVar31 < (int)(uint)*(ushort *)(param_2 + 0xbc));
            }
            if ((short)puVar33[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
              lVar10 = *(longlong *)(param_2 + 0xa8);
              do {
                lVar11 = (ulonglong)*(uint *)(param_2 + 0xb4) + lVar10;
                uVar17 = *(ushort *)(lVar11 + uVar14 * 2) & 0x7fff;
                if ((int)uVar14 == 1) {
                  uVar19 = *(uint *)(param_2 + 0xb8);
                  uVar31 = uVar19;
LAB_:
                  if ((uVar17 < uVar19) || (*(uint *)(param_2 + 0xa4) < uVar17)) goto LAB_;
                }
                else {
                  uVar31 = *(uint *)(param_2 + 0xb8);
                  uVar19 = *(ushort *)(lVar11 + -2 + uVar14 * 2) & 0x7fff;
                  if (uVar31 <= uVar19) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar18 + -8) = 0x101198;
                  func_0x(lVar10,7);
                  uVar31 = *(uint *)(param_2 + 0xb8);
                }
                if ((uVar19 < uVar31) || (*(uint *)(param_2 + 0xa4) < uVar19)) goto LAB_;
                lVar10 = *(longlong *)(param_2 + 0xa8);
                if (*(ushort *)(lVar10 + (ulonglong)uVar19) == 5) {
                  *puVar1 = *puVar1 | 2;
                  *(short *)(param_2 + 0xbc) = *(short *)(param_2 + 0xbc) + -1;
                  uVar14 = *(ulonglong *)(param_2 + 0xa8);
                  uVar30 = *(ushort *)(param_2 + 0xcc) & 0xc7ff;
                  uVar21 = (ulonglong)(uVar19 & 0xffff);
                  *(short *)(param_2 + 0xca) = (short)uVar19;
                  if ((*(ushort *)(uVar21 + 2 + uVar14) >> 0xe & 1) != 0) {
                    uVar30 = *(ushort *)(uVar21 + 2 + uVar14) & 0x3800 | uVar30;
                  }
                  *(ushort *)(param_2 + 0xcc) = uVar30;
                  uVar25 = (ulonglong)*(ushort *)(param_2 + 0xca);
                  uVar22 = (uVar30 ^ *(ushort *)(uVar21 + 2 + uVar14)) & 0x7ff ^ uVar30;
                  *(ushort *)(param_2 + 0xcc) = uVar22;
                  uVar21 = (ulonglong)((uVar22 & 0x7ff) * 2) + 4 + uVar14 + (uVar30 >> 0xb & 7) * 2
                           + uVar25;
                  if (uVar21 < uVar25 + uVar14) {
                    *(undefined8 *)(puVar18 + -8) = 0x1012a3;
                    func_0x(uVar25 + uVar14,0x19);
                    uVar22 = *(ushort *)(param_2 + 0xcc);
                    uVar25 = (ulonglong)*(ushort *)(param_2 + 0xca);
                    uVar14 = (ulonglong)*(uint *)(param_2 + 0xa8);
                  }
                  if (uVar17 - uVar19 <
                      (((uVar22 & 0x7ff) * 2 - (int)uVar25) - (int)uVar14) + (int)uVar21) {
                    lVar10 = *(longlong *)(param_2 + 0xa8);
                    *(undefined8 *)(puVar18 + -8) = 0x1012db;
                    func_0x(uVar25 + lVar10,0x19);
                    uVar22 = *(ushort *)(param_2 + 0xcc);
                  }
                  iVar8 = 0;
                  if (((uVar22 & 0x3800) != 0) &&
                     (puVar32 = (ushort *)
                                (*(longlong *)(param_2 + 0xa8) + 4 +
                                (ulonglong)*(ushort *)(param_2 + 0xca)), (uVar22 & 0x3800) != 0))
                  goto LAB_;
                  break;
                }
                if (*(ushort *)(lVar10 + (ulonglong)uVar19) < 0x400) break;
                *puVar1 = *puVar1 | 1;
                uVar30 = *(short *)(param_2 + 0xbc) - 1;
                *(ushort *)(param_2 + 0xbc) = uVar30;
                if ((uVar30 == 0) ||
                   (uVar14 = (ulonglong)uVar30, -1 < (short)puVar33[(ulonglong)(uVar30 - 1) + 1]))
                break;
              } while( true );
            }
            pbVar24 = *(byte **)(param_2 + 0xa8);
            uVar14 = (ulonglong)*(uint *)(param_2 + 0xa4);
          }
          goto LAB_;
        }
        goto LAB_;
      }
    }
  }
LAB_:
  uVar15 = uStack_38 ^ (ulonglong)auStack_e8;
  *(undefined8 *)(puVar18 + -8) = 0x10167b;
  func_0x(uVar15);
  return;
LAB_:
  do {
    if ((uVar22 & 0x7ff) < (*puVar32 & 0x7ff)) {
      uVar30 = *(ushort *)(param_2 + 0xca);
      lVar10 = *(longlong *)(param_2 + 0xa8);
      *(undefined8 *)(puVar18 + -8) = 0x101347;
      func_0x((ulonglong)uVar30 + lVar10,0x1a);
      uVar22 = *(ushort *)(param_2 + 0xcc);
    }
    iVar8 = iVar8 + 1;
    puVar32 = puVar32 + 1;
  } while (iVar8 < (int)(uVar22 >> 0xb & 7));
  pbVar24 = *(byte **)(param_2 + 0xa8);
  uVar14 = (ulonglong)*(uint *)(param_2 + 0xa4);
LAB_:
  if ((*pbVar24 & 0x40) == 0) {
    *(undefined4 *)(param_2 + 0xc6) = 0;
  }
  else {
    *(int *)(param_2 + 0xc6) = (int)uVar14;
    *(int *)(param_2 + 0xa4) = (int)uVar14 + 0xe;
    *(undefined8 *)(puVar18 + -8) = 0x10138d;
    uVar12 = func_0x(puVar1);
    *(undefined8 *)(puVar18 + -8) = 0x10139c;
    func_0x(uVar12,auStack_40);
    *(undefined8 *)(puVar18 + -8) = 0x1013a8;
    iVar8 = func_0x(auStack_40);
    *(int *)(param_2 + 0xa4) = *(int *)(param_2 + 0xa4) + iVar8;
    uVar14 = (ulonglong)*(uint *)(param_2 + 0xa4);
  }
  iVar8 = (int)uVar14;
  if ((*(ulonglong *)(param_2 + 0xbe) != 0) &&
     (*(ulonglong *)(param_2 + 0xbe) < uVar14 + *(longlong *)(param_2 + 0xa8))) {
    *(undefined8 *)(puVar18 + -8) = 0x1013de;
    cVar7 = func_0x(0x1480880);
    if (cVar7 != '\0') {
      *(undefined8 *)(puVar18 + -8) = 0x1013e7;
      lVar10 = func_0x();
      if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
        *(undefined8 *)(puVar18 + -8) = 0x101401;
        cVar7 = func_0x(0x1480880);
        if (cVar7 == '\0') {
          *(undefined8 *)(puVar18 + -8) = 0x10141d;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(puVar18 + 0x20) = 0;
          *(undefined8 *)(puVar18 + -8) = 0x101443;
          (*_DAT_)(1,0xd7028c,0xe90378,0x886);
        }
      }
    }
    uVar12 = *(undefined8 *)(param_2 + 0xa8);
    *(undefined8 *)(puVar18 + -8) = 0x101451;
    func_0x(uVar12,0x12);
    iVar8 = *(int *)(param_2 + 0xa4);
  }
  if (0x3f3b < iVar8 - 1U) {
    *(undefined8 *)(puVar18 + -8) = 0x10146a;
    cVar7 = func_0x(0x1480880);
    if (cVar7 != '\0') {
      *(undefined8 *)(puVar18 + -8) = 0x101473;
      lVar10 = func_0x();
      if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
        *(undefined8 *)(puVar18 + -8) = 0x10148d;
        cVar7 = func_0x(0x1480880);
        if (cVar7 == '\0') {
          *(undefined8 *)(puVar18 + -8) = 0x1014a9;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)(puVar18 + 0x20) = 0;
          *(undefined8 *)(puVar18 + -8) = 0x1014cf;
          (*_DAT_)(1,0xd7028c,0xe90378,0x88b);
        }
      }
    }
    uVar12 = *(undefined8 *)(param_2 + 0xa8);
    *(undefined8 *)(puVar18 + -8) = 0x1014dd;
    func_0x(uVar12,5);
  }
LAB_:
  *(undefined8 *)(puVar18 + -8) = 0x1014e5;
  iVar8 = func_0x(puVar1);
  iVar26 = (int)uVar15;
  if (iVar8 == 0) {
    *(undefined8 *)(puVar18 + -8) = 0x1015b4;
    iVar8 = func_0x(puVar1);
    if (iVar8 == 0) {
      *(undefined8 *)(puVar18 + 0x20) = 0;
      *(undefined8 *)(puVar18 + -8) = 0x1015dd;
      (*_DAT_)(1,0xf2bfa8,0xf1d038,0xd7a);
    }
  }
  else {
    uVar29 = 0;
    if (-1 < iVar26) {
      uVar17 = *(ushort *)(param_2 + 0xcc) & 0x7ff;
      if (iVar26 < (int)uVar17) {
        uVar17 = uVar17 * 2;
        uVar19 = *(ushort *)(param_2 + 0xcc) >> 0xb & 7;
        lVar10 = *(longlong *)(param_2 + 0xa8) + (ulonglong)(uVar19 * 2) + (ulonglong)uVar17 +
                 (ulonglong)*(ushort *)(param_2 + 0xca);
        if (iVar26 == 0) {
          uVar17 = (uVar19 + uVar17) * 2 + 4;
        }
        else {
          uVar17 = *(ushort *)(lVar10 + 2 + lStack_b8 * 2) & 0x7fff;
        }
        iStack_e4 = (*(ushort *)(lVar10 + 4 + lStack_b8 * 2) & 0x7fff) - uVar17;
        uStack_cc = (uint)(*(ushort *)(lVar10 + 4 + uVar15 * 2) >> 0xf);
        uVar29 = (ulonglong)uVar17 +
                 (ulonglong)*(ushort *)(param_2 + 0xca) + *(longlong *)(param_2 + 0xa8);
        goto LAB_;
      }
    }
    *(undefined8 *)(puVar18 + 0x20) = 0;
    *(undefined8 *)(puVar18 + -8) = 0x1015aa;
    (*_DAT_)(1,0xf2bf78,0xf2bf40,0x41a);
  }
LAB_:
  uVar12 = uStack_48;
  lVar11 = lStack_68;
  lVar10 = lStack_70;
  uVar5 = uStack_ce;
  uVar4 = auStack_e8[0];
  if (uStack_cc != 0) {
    uStack_78 = uStack_ac;
    uStack_74 = uStack_d0;
    *(undefined4 *)(puVar18 + 0x50) = 0;
    uVar17 = uStack_c0;
    uStack_72 = uVar5;
    *(undefined2 *)(puVar18 + 0x48) = 0;
    *(undefined4 *)(puVar18 + 0x40) = 1;
    *(uint *)(puVar18 + 0x38) = uVar17 + iVar26;
    iVar8 = iStack_e4;
    *(ulonglong *)(puVar18 + 0x30) = uVar29;
    *(int *)(puVar18 + 0x28) = iVar8;
    *(undefined4 **)(puVar18 + 0x20) = &uStack_78;
    *(undefined8 *)(puVar18 + -8) = 0x10164d;
    iVar8 = func_0x(uVar12,lVar11,uVar4,lVar10);
    if (iVar8 == 0) goto LAB_;
  }
  uVar15 = (ulonglong)(iVar26 + 1);
  lStack_b8 = lStack_b8 + 1;
  if ((longlong)psStack_60 <= lStack_b8) goto LAB_;
  goto LAB_;
}

