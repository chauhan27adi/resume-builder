
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x001003ec) */
/* WARNING: Removing unreachable block (ram,0x001003e3) */
/* WARNING: Removing unreachable block (ram,0x0012021f) */
/* WARNING: Removing unreachable block (ram,0x01116c61) */
/* WARNING: Removing unreachable block (ram,0x000fbcd5) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,undefined8 *param_2,int param_3,longlong param_4)

{
  uint *puVar1;
  uint *puVar2;
  byte bVar3;
  ushort uVar4;
  int iVar5;
  byte *pbVar6;
  uint uVar7;
  longlong lVar8;
  uint uVar9;
  longlong lVar10;
  code *UNRECOVERED_JUMPTABLE_00;
  uint *puVar11;
  uint uVar12;
  undefined8 unaff_RBX;
  uint **ppuVar13;
  longlong lVar14;
  ulonglong uVar15;
  uint auStackX_18 [2];
  undefined8 uStackX_20;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar8 = func_0x();
  lVar8 = -lVar8;
  puVar2 = (uint *)((longlong)auStackX_18 + lVar8);
  *(undefined8 *)(&stack0x00002248 + lVar8) = unaff_RBX;
  *(ulonglong *)(&stack0x000021e8 + lVar8) = _DAT_ ^ (ulonglong)puVar2;
  ppuVar13 = (uint **)0x0;
  *(longlong *)(&stack0x000000c8 + lVar8) = param_4;
  *(undefined8 **)(&stack0x000000d0 + lVar8) = param_2;
  *(short **)(&stack0x000000c0 + lVar8) = param_1;
  *(undefined4 *)(&stack0x00000030 + lVar8) = 0;
  *(int *)(&stack0x0000008c + lVar8) = param_3;
  uVar7 = *(uint *)(&stack0x00002258 + lVar8);
  puVar11 = (uint *)(ulonglong)uVar7;
  lVar14 = *(longlong *)(param_4 + 8);
  *(undefined8 *)(&stack0x000000a0 + lVar8) = 0;
  uVar15 = (ulonglong)(uVar7 != 0);
  *(undefined8 *)(&stack0x000000a8 + lVar8) = 0;
  uVar7 = (uint)(uVar7 != 0);
  *(uint *)(&stack0x00000090 + lVar8) = uVar7;
  if (*(int *)(lVar14 + 0x100) == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined4 *)(&stack0x00000084 + lVar8) = 0;
  if (param_3 == 0) {
LAB_:
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x10037d;
    func_0x(*(ulonglong *)(&stack0x000021e8 + lVar8) ^ (ulonglong)puVar2,puVar11,ppuVar13,
                    uVar15);
    return;
  }
  *(ulonglong *)(&stack0x000000e0 + lVar8) = uVar15 * 0x10;
  *(undefined8 *)(&stack0x000000b8 + lVar8) = 0;
  *(short **)(&stack0x000000b0 + lVar8) = param_1 + 1;
  *(undefined8 *)((longlong)&uStackX_20 + lVar8) = *param_2;
  lVar14 = **(longlong **)(*(longlong *)(param_4 + 8) + 0x160);
  lVar10 = *(longlong *)(lVar14 + 0x38);
  if (lVar10 == lVar14 + 0x30) {
    lVar10 = 0;
  }
  lVar14 = 0;
  if (lVar10 != 0) {
    lVar14 = lVar10 + -0x160;
  }
  *(longlong *)(&stack0x00000038 + lVar8) = lVar14;
  bVar3 = *(byte *)(lVar14 + 0x21);
  puVar1 = (uint *)(lVar14 + uVar15 * 0x10);
  *(uint **)(&stack0x00000098 + lVar8) = puVar1;
  *(uint *)(&stack0x00000088 + lVar8) = bVar3 >> 5 & 1;
  if (uVar7 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  bVar3 = *(byte *)(lVar14 + 0x20) >> 1;
  uVar4 = *(ushort *)(lVar14 + 0x38);
  if (*param_1 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar7 = *puVar1;
  uVar15 = (ulonglong)(int)uVar7;
  if ((uVar7 & 0xc0000000) == 0x80000000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((bVar3 & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  pbVar6 = *(byte **)(param_1 + 4);
  if ((*pbVar6 & 0x10) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar12 = *(uint *)(param_1 + 8);
  if ((int)uVar7 < (int)uVar12) {
    if ((uint)*(ushort *)(puVar1 + 1) <= (uint)*(ushort *)(pbVar6 + uVar12)) {
      if (((bVar3 & 1) != 0) &&
         (uVar9 = *(ushort *)(puVar1 + 1) - 1,
         (pbVar6[(ulonglong)uVar12 + (ulonglong)(uVar9 >> 3) + 2] >> ((byte)uVar9 & 7) & 1) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((int)uVar7 < 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(ushort *)((longlong)puVar1 + 6) & 8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(ushort *)((longlong)puVar1 + 6) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *puVar2 = (uint)uVar4;
      ppuVar13 = *(uint ***)((longlong)&uStackX_20 + lVar8);
      if ((*(byte *)(lVar14 + 0x21) & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (((*(char *)(lVar14 + 0x34) != '8') || ((char)*(byte *)(lVar14 + 0x21) < '\0')) ||
         (-1 < (int)*puVar1)) {
        uVar15 = 0;
        puVar11 = *ppuVar13;
        if ((uint *)((longlong)(int)*puVar1 + *(longlong *)(param_1 + 4)) == (uint *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (puVar11 != (uint *)0x0) {
          uVar12 = (uint)*(byte *)(lVar14 + 0x34);
          uVar7 = *(byte *)(lVar14 + 0x34) - 0x6a;
          if (uVar7 < 0x86) {
            UNRECOVERED_JUMPTABLE_00 =
                 (code *)((ulonglong)
                          *(uint *)((ulonglong)*(byte *)((longlong)(int)uVar7 + 0x100660) * 4 +
                                   0x100658) + 0xedb50);
                    /* WARNING: Could not emulate address calculation at 0x0010025b */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
            return;
          }
          if (uVar4 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (*(short *)((longlong)ppuVar13 + 0xc) != 0) {
            if (uVar12 != 0xa7) {
              if (uVar12 == 0xad) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
              if (uVar12 != 0xaf) {
                if ((uVar12 == 0xe7) || (uVar12 == 0xef)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                  halt_baddata();
                }
                if ((*(byte *)(*(longlong *)(&stack0x00000038 + lVar8) + 0x21) & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                  halt_baddata();
                }
                if (uVar12 - 0x24 < 0xcd) {
                  UNRECOVERED_JUMPTABLE_00 =
                       (code *)((ulonglong)
                                *(uint *)((ulonglong)
                                          *(byte *)((longlong)(int)(uVar12 - 0x24) + 0x100734) * 4 +
                                         0x1006e8) + 0xedb50);
                    /* WARNING: Could not emulate address calculation at 0x001002e7 */
                    /* WARNING: Treating indirect jump as call */
                  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
                  return;
                }
                ppuVar13 = *(uint ***)((longlong)&uStackX_20 + lVar8);
                if (((*(char *)((longlong)ppuVar13 + 0xe) + 0x7fU & 0xf9) == 0) &&
                   (*(char *)((longlong)ppuVar13 + 0xe) != -0x79)) {
                  iVar5 = *(int *)(&stack0x00000084 + lVar8);
                  *(uint *)(&stack0x00000084 + lVar8) = iVar5 + 1U;
                  *(longlong *)(&stack0x000000b8 + lVar8) =
                       *(longlong *)(&stack0x000000b8 + lVar8) + 1;
                  if (iVar5 + 1U < *(uint *)(&stack0x0000008c + lVar8)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                    halt_baddata();
                  }
                }
                goto LAB_;
              }
            }
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
        }
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      puVar11 = *ppuVar13;
      uVar7 = 0;
      if (uVar4 != 0) {
        uVar7 = *(uint *)((longlong)(int)*puVar1 + *(longlong *)(param_1 + 4));
      }
      if ((*(short *)((longlong)ppuVar13 + 0xc) == 0) || (*puVar11 <= uVar7)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      goto LAB_;
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

