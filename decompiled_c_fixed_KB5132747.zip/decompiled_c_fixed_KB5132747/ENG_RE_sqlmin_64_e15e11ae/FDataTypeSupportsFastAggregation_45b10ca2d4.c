
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_(uint param_1,byte *param_2,byte *param_3)

{
  uint uVar1;
  byte bVar2;
  
  if ((param_1 != 8) && (param_1 != 0x26)) {
    if (param_1 == 0x23) {
      return true;
    }
    if ((0x30 < param_1) || ((0x1800000000005U >> ((longlong)(int)param_1 & 0x3fU) & 1) == 0)) {
      if (param_1 == 0xc) {
        return true;
      }
      if (param_1 == 0x2b) goto LAB_;
      if (param_1 == 0x2c) {
        return false;
      }
      if (param_1 == 0x37) goto LAB_;
      if (param_1 == 0x38) {
        return false;
      }
      (*_DAT_)(1,0x1cf5e80,0x1cd1908,0x1c6,0);
      goto LAB_;
    }
  }
  if (param_1 == 0x2b) {
LAB_:
    return (*param_2 + 0x59 & 0xb7) != 0;
  }
  if ((param_1 < 0x39) && ((0x101900000000000U >> ((longlong)(int)param_1 & 0x3fU) & 1) != 0)) {
    return false;
  }
  if (param_1 == 0x37) {
LAB_:
    switch(*param_2) {
    case 0x30:
    case 0x34:
    case 0x38:
    case 0x3b:
    case 0x3c:
    case 0x3e:
    case 0x68:
    case 0x7a:
    case 0x7f:
      goto LAB_;
    default:
      return false;
    }
  }
LAB_:
  switch(*param_3) {
  case 0x28:
  case 0x29:
  case 0x2a:
  case 0x3a:
  case 0x3d:
    return (param_1 & 0xfffffffd) == 0;
  default:
    return false;
  case 0x30:
  case 0x34:
  case 0x38:
  case 0x68:
  case 0x7f:
    uVar1 = *param_2 - 0x30;
    if (((0x38 < (byte)uVar1) || ((0x100000000000111U >> ((ulonglong)uVar1 & 0x3f) & 1) == 0)) &&
       (*param_2 != 0x7f)) {
      (*_DAT_)(1,0x1cf5dd0,0x1cd1908,0x204,0);
    }
LAB_:
    return true;
  case 0x3c:
  case 0x6a:
  case 0x6c:
  case 0x7a:
    bVar2 = *param_2;
    if ((((bVar2 != 0x3c) && (bVar2 != 0x7a)) && (bVar2 != 0x6c)) && (bVar2 != 0x6a)) {
      (*_DAT_)(1,0x1cf5d30,0x1cd1908,0x211,0);
      bVar2 = *param_2;
    }
  }
  if ((byte)(bVar2 + 0x10) < 2) {
    bVar2 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar2 + 0x18d3010) * 4 + 0x18d4113);
  }
  else {
    bVar2 = param_2[0x13];
  }
  if ((byte)(*param_3 + 0x10) < 2) {
    return bVar2 == *(byte *)((ulonglong)*(byte *)((ulonglong)*param_3 + 0x18d3010) * 4 + 0x18d4113)
    ;
  }
  return bVar2 == param_3[0x13];
}

