
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong param_2,longlong param_3,undefined8 param_4)

{
  byte *pbVar1;
  short sVar2;
  char cVar3;
  longlong lVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong *plVar7;
  short *psVar8;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  byte **ppbVar12;
  longlong lStackX_8;
  undefined4 auStackX_10 [3];
  ushort auStackX_1e [5];
  undefined4 uStack_d350;
  undefined4 uStack_d34c;
  undefined2 uStack_d348;
  undefined4 uStack_d344;
  ulonglong uStack_d318;
  ulonglong uStack_d310;
  longlong lStack_d308;
  undefined4 uStack_d300;
  undefined2 uStack_d2fc;
  ulonglong uStack_d2e8;
  undefined8 uStack_d2e0;
  undefined8 uStack_d2d8;
  undefined8 uStack_d2d0;
  undefined2 uStack_d2c8;
  longlong *plStack_d2b0;
  longlong *plStack_d2a8;
  undefined8 uStack_d288;
  undefined8 uStack_d280;
  undefined2 uStack_d270;
  undefined4 uStack_d26c;
  undefined8 uStack_d268;
  undefined8 uStack_d260;
  undefined8 uStack_d252;
  undefined8 uStack_d248;
  undefined4 uStack_d23c;
  undefined2 uStack_d1c0;
  undefined4 uStack_d1bc;
  undefined8 uStack_d1b8;
  undefined8 uStack_d1b0;
  undefined8 uStack_d1a2;
  undefined8 uStack_d198;
  short sStack_d110;
  undefined4 uStack_d10c;
  byte *pbStack_d108;
  byte **ppbStack_d100;
  undefined8 uStack_d0f2;
  undefined2 uStack_d0ea;
  undefined2 uStack_d0e8;
  undefined6 uStack_d0e6;
  undefined4 uStack_d0dc;
  undefined auStack_d0d8 [16];
  undefined auStack_d0c8 [8];
  undefined8 uStack_d0c0;
  undefined8 uStack_d0b8;
  undefined6 uStack_d0b0;
  undefined2 uStack_d0aa;
  undefined6 uStack_d0a8;
  undefined2 uStack_d0a2;
  undefined8 uStack_d0a0;
  undefined auStack_d098 [16];
  undefined auStack_d088 [16];
  undefined auStack_d078 [16];
  undefined8 uStack_d068;
  undefined auStack_d058 [12287];
  undefined auStack_a059 [16384];
  undefined auStack_6059 [16384];
  undefined auStack_2059 [8193];
  ulonglong uStack_58;
  undefined8 uStack_48;
  
  uStack_48 = 0x10001f;
  lVar4 = func_0x();
  lVar4 = -lVar4;
  uStack_d280 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar4);
  uStack_d350 = 0;
  uStack_d2e8 = (ulonglong)auStack_6059 & 0xffffffffffffe000;
  uVar10 = (ulonglong)auStack_2059 & 0xffffffffffffe000;
  lVar9 = -1;
  sStack_d110 = -1;
  pbStack_d108 = (byte *)0x0;
  uStack_d10c = 0;
  uStack_d0f2 = 0;
  uStack_d0e8 = 0;
  uStack_d0e6 = 0;
  ppbStack_d100 = (byte **)0x0;
  uStack_d1c0 = 0xffff;
  uStack_d1b8 = 0;
  uStack_d1bc = 0;
  uStack_d1a2 = 0;
  uStack_d198 = 0;
  uStack_d1b0 = 0;
  uStack_d270 = 0xffff;
  uStack_d268 = 0;
  uStack_d26c = 0;
  uStack_d252 = 0;
  uStack_d248 = 0;
  uStack_d260 = 0;
  uStack_d23c = 0xffffffff;
  *(ushort *)((longlong)auStackX_1e + lVar4) = *(ushort *)((longlong)auStackX_1e + lVar4) & 0xffe0;
  *(undefined4 **)((longlong)&lStackX_8 + lVar4) = &uStack_d350;
  uStack_d318 = uVar10;
  uStack_d310 = (ulonglong)auStack_a059 & 0xffffffffffffe000;
  lStack_d308 = param_2;
  uStack_d2e0 = param_1;
  uStack_d288 = param_4;
  *(undefined8 *)((longlong)auStackX_1e + lVar4 + -0x1e) = 0;
  (&stack0xfffffffffffffff8)[lVar4] = 0;
  (&stack0xfffffffffffffff0)[lVar4] = 0;
  (&stack0xffffffffffffffe8)[lVar4] = 0;
  (&stack0xffffffffffffffe0)[lVar4] = 0;
  *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x10013d;
  lVar5 = func_0x(param_3,2,3,0);
  if (lVar5 == -1) {
    do {
      lVar9 = lVar9 + 1;
    } while (*(short *)(param_3 + lVar9 * 2) != 0);
    *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100168;
    uVar6 = (*_DAT_)(uStack_d350,auStack_d058,0,0);
    *(int *)(&stack0xfffffffffffffff0 + lVar4) = (int)lVar9 * 2;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar4) = param_3;
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar4) = uVar6;
    *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x10018c;
    (*_DAT_)(0x33,0x17,0x10,0x42);
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x10019c;
  (*_DAT_)(lVar5);
  *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x1001ab;
  plVar7 = (longlong *)func_0x(uStack_d2e0,param_3,0);
  *(longlong **)(&stack0x00000030 + lVar4) = plVar7;
  lVar5 = -1;
  do {
    lVar5 = lVar5 + 1;
  } while (*(short *)(param_3 + lVar5 * 2) != 0);
  lVar9 = *plVar7;
  *(undefined4 *)((longlong)&lStackX_8 + lVar4) = 1;
  plStack_d2b0 = plVar7;
  *(undefined4 *)((longlong)auStackX_1e + lVar4 + -0x1e) = 2;
  *(ulonglong *)(&stack0xfffffffffffffff8 + lVar4) = (ulonglong)(uint)((int)lVar5 * 2);
  *(longlong *)(&stack0xfffffffffffffff0 + lVar4) = param_3;
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar4) = 0;
  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar4) = 0x121c988;
  UNRECOVERED_JUMPTABLE_00 = *(code **)(lVar9 + 0x68);
  *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x10020e;
  (*UNRECOVERED_JUMPTABLE_00)(plVar7,0,0,1);
  UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar7 + 0x50);
  *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100217;
  (*UNRECOVERED_JUMPTABLE_00)(plVar7);
  UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar7 + 0x60);
  *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100226;
  (*UNRECOVERED_JUMPTABLE_00)(plVar7,0x10,1);
  UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar7 + 0x20);
  *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100239;
  (*UNRECOVERED_JUMPTABLE_00)(plVar7,0,0,0x10);
  *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100248;
  plVar7 = (longlong *)func_0x(uStack_d2e0,param_2,0);
  lVar5 = -1;
  do {
    lVar5 = lVar5 + 1;
  } while (*(short *)(param_2 + lVar5 * 2) != 0);
  lVar9 = *plVar7;
  *(undefined4 *)((longlong)&lStackX_8 + lVar4) = 1;
  plStack_d2a8 = plVar7;
  *(undefined4 *)((longlong)auStackX_1e + lVar4 + -0x1e) = 0x42;
  *(ulonglong *)(&stack0xfffffffffffffff8 + lVar4) = (ulonglong)(uint)((int)lVar5 * 2);
  *(longlong *)(&stack0xfffffffffffffff0 + lVar4) = param_2;
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar4) = 0;
  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar4) = 0x121c988;
  UNRECOVERED_JUMPTABLE_00 = *(code **)(lVar9 + 0x68);
  *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x1002b3;
  (*UNRECOVERED_JUMPTABLE_00)(plVar7,0,0,2);
  uStack_d34c = 0;
  uStack_d348 = 2;
  UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar7 + 0x50);
  *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x1002c8;
  (*UNRECOVERED_JUMPTABLE_00)(plVar7);
  *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x1002da;
  func_0x(plVar7,0,uVar10,&uStack_d34c);
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar4) = 0;
  *(undefined4 *)(&stack0xffffffffffffffe0 + lVar4) = 1;
  *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x1002f9;
  lVar5 = func_0x(_DAT_,0,3,0x26);
  uVar6 = *(undefined8 *)(*(longlong *)(lVar5 + 0x1210) + 0x6a0);
  *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100312;
  uStack_d2d8 = func_0x(uVar6,1,0);
  uStack_d34c = 0;
  uStack_d348 = 1;
  *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100330;
  func_0x(uStack_d2d8,0,(ulonglong)auStack_a059 & 0xffffffffffffe000,&uStack_d34c);
  uStack_d0dc = 0;
  *(undefined4 *)((longlong)auStackX_10 + lVar4) = 0xf;
  if (-1 < *(char *)(uVar10 + 2)) goto LAB_;
  pbVar1 = (byte *)(uVar10 + 0x60);
  if ((sStack_d110 == 0) || (ppbVar12 = ppbStack_d100, ppbStack_d100 == (byte **)0x0)) {
    uStack_d0b0 = 0;
    uStack_d0a2 = 0;
    auStack_d088 = ZEXT816(0);
    auStack_d0d8 = ZEXT816(0);
    stack0xffffffffffff2f3a = SUB1614(ZEXT816(0),2);
    auStack_d0c8._0_2_ = 0xffff;
    uStack_d0c0 = 0;
    uStack_d0aa = 0;
    uStack_d0a8 = 0;
    uStack_d0a0 = 0;
    uStack_d0b8 = 0;
    auStack_d098 = ZEXT816(0);
    auStack_d078._0_12_ = ZEXT812(0);
    auStack_d078._12_4_ = 0;
    uStack_d068 = 0;
    ppbVar12 = (byte **)auStack_d0d8;
  }
  if (*(short *)(uVar10 + 0x24) == 0) {
LAB_:
    uStack_d2d0 = *(undefined8 *)(uVar10 + 0x28);
    uStack_d2c8 = *(undefined2 *)(uVar10 + 0x30);
  }
  else {
    cVar3 = *(char *)(uVar10 + 1);
    if (cVar3 == '\v') {
      if (*(int *)(uVar10 + 0x18) != 99) {
LAB_:
        if (cVar3 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar3 != '\b') goto LAB_;
LAB_:
      if (*(int *)(uVar10 + 0x18) != 99) goto LAB_;
    }
    uStack_d300 = *(undefined4 *)(uVar10 + 0x20);
    uStack_d2fc = *(undefined2 *)(uVar10 + 0x24);
    *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100464;
    cVar3 = func_0x(&uStack_d300,0x1212e20);
    if (cVar3 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100474;
    func_0x(uVar10,&uStack_d2d0);
  }
  *ppbVar12 = pbVar1;
  *(undefined4 *)(ppbVar12 + 0xc) = (undefined4)uStack_d2d0;
  *(int *)((longlong)ppbVar12 + 100) = (int)((ulonglong)uStack_d2d0 >> 0x20);
  *(undefined2 *)(ppbVar12 + 0xd) = uStack_d2c8;
  *(undefined4 *)((longlong)ppbVar12 + 0x6c) = *(undefined4 *)(uVar10 + 0x20);
  *(undefined2 *)(ppbVar12 + 0xe) = *(undefined2 *)(uVar10 + 0x24);
  *(undefined2 *)((longlong)ppbVar12 + 0x72) = 0;
  uStack_d344 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x1291700);
  uVar11 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x1291704);
  *(undefined2 *)(ppbVar12 + 2) = 0xffff;
  ppbVar12[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar12 + 0x2e) = 0;
  ppbVar12[7] = (byte *)0x0;
  ppbVar12[4] = (byte *)0x0;
  ppbVar12[9] = (byte *)0x0;
  ppbVar12[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar12 + 0xb) = 0;
  if ((**ppbVar12 & 2) != 0) {
    pbVar1 = pbVar1 + uVar11;
    if ((*pbVar1 & 1) == 0) {
      *(undefined2 *)(ppbVar12 + 2) = 0;
      ppbVar12[3] = pbVar1;
      *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbVar12 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001006d8 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x104f74) - 0x1307710))()
      ;
      return;
    }
    *(undefined2 *)(ppbVar12 + 2) = 1;
    ppbVar12[3] = pbVar1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x104f54) * 4 +
                           0x104f44) - 0x1307710);
                    /* WARNING: Could not emulate address calculation at 0x0010053c */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbVar12 & 4) != 0) {
    uStack_d344._2_2_ = (short)((uint)uStack_d344 >> 0x10);
    if (uStack_d344._2_2_ != 0) {
      uVar11 = (ulonglong)*(ushort *)(uVar10 + 0x61 + (longlong)uStack_d344._2_2_ * 2);
    }
    psVar8 = (short *)(pbVar1 + uVar11);
    ppbVar12[9] = (byte *)psVar8;
    sVar2 = *psVar8;
    ppbVar12[10] = (byte *)(psVar8 + 1);
    *(short *)(ppbVar12 + 0xb) = (sVar2 + 1) * 2;
  }
  pbVar1 = ppbVar12[1];
  uVar10 = uStack_d318;
  if (pbVar1 != (byte *)0x0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar4) = 0x100799;
    func_0x(pbVar1,ppbVar12);
    uVar10 = uStack_d318;
  }
LAB_:
  pbStack_d108 = (byte *)(*(ushort *)(uVar10 + 0x1ffe) + uVar10);
  if ((*pbStack_d108 & 1) == 0) {
    sStack_d110 = 0;
    uStack_d10c = 0;
    uStack_d0ea = 0;
    uStack_d0e8 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100997 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_d108 & 0xe) * 4 + 0x104fe0) - 0x1307710
              ))((longlong)(int)(*pbStack_d108 & 0xe),0x1212e20,pbStack_d108);
    return;
  }
  sStack_d110 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_d108 & 0x1c) + 0x104fc0) * 4
                         + 0x104fb0) - 0x1307710);
                    /* WARNING: Could not emulate address calculation at 0x001007f6 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

