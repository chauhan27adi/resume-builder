
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong **param_2,longlong **param_3,undefined8 param_4,
                 undefined8 param_5,int param_6)

{
  short sVar1;
  short sVar2;
  int iVar3;
  int iVar4;
  undefined8 *puVar5;
  longlong **pplVar6;
  undefined *puVar7;
  char cVar8;
  short sVar9;
  ulonglong uVar10;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar11;
  longlong lVar12;
  undefined4 uVar13;
  longlong unaff_GS_OFFSET;
  undefined auStack_918 [32];
  undefined8 uStack_8f8;
  undefined4 uStack_8f0;
  undefined8 uStack_8e8;
  byte bStack_8e0;
  char cStack_880;
  short sStack_87e;
  undefined4 uStack_87c;
  undefined4 uStack_850;
  undefined2 uStack_84c;
  longlong **pplStack_848;
  longlong **pplStack_840;
  longlong lStack_838;
  longlong lStack_830;
  byte bStack_828;
  longlong lStack_818;
  uint uStack_810;
  undefined4 uStack_808;
  undefined8 uStack_800;
  short sStack_7f8;
  longlong lStack_7f0;
  undefined uStack_7e8;
  undefined4 uStack_7e4;
  undefined8 uStack_7d8;
  undefined4 uStack_7d0;
  undefined2 uStack_7cc;
  undefined2 uStack_7ca;
  undefined4 uStack_7b8;
  undefined2 uStack_7b4;
  undefined4 uStack_7b0;
  undefined2 uStack_7ac;
  undefined4 uStack_7a8;
  undefined2 uStack_7a4;
  longlong lStack_7a0;
  undefined *puStack_798;
  int iStack_738;
  short sStack_734;
  int iStack_730;
  short sStack_72c;
  undefined4 uStack_728;
  short sStack_724;
  short sStack_720;
  ushort uStack_704;
  short sStack_6f0;
  ushort uStack_6e0;
  undefined4 uStack_6d8;
  undefined2 uStack_6d4;
  undefined4 uStack_6d0;
  undefined2 uStack_6cc;
  undefined4 uStack_6c8;
  undefined2 uStack_6c4;
  undefined4 uStack_6c0;
  undefined2 uStack_6bc;
  ushort uStack_6b8;
  undefined8 uStack_6b0;
  undefined8 uStack_690;
  undefined uStack_688;
  undefined4 uStack_684;
  undefined4 uStack_678;
  undefined2 uStack_674;
  uint uStack_670;
  undefined *puStack_548;
  longlong **pplStack_528;
  undefined8 uStack_520;
  longlong **pplStack_518;
  int iStack_510;
  int iStack_508;
  undefined8 uStack_4f8;
  undefined8 *puStack_4f0;
  undefined4 uStack_4c0;
  undefined4 uStack_4bc;
  undefined8 uStack_4a8;
  undefined4 *puStack_4a0;
  undefined8 uStack_498;
  longlong lStack_490;
  longlong lStack_488;
  longlong lStack_480;
  undefined *puStack_478;
  undefined *puStack_470;
  undefined *puStack_468;
  short **ppsStack_460;
  undefined *puStack_458;
  undefined *puStack_450;
  undefined4 *puStack_448;
  undefined4 *puStack_440;
  undefined8 *puStack_438;
  undefined4 *puStack_430;
  byte *pbStack_428;
  undefined *puStack_420;
  undefined *puStack_418;
  undefined *puStack_410;
  undefined *puStack_408;
  longlong lStack_400;
  undefined *puStack_3f8;
  short **ppsStack_3f0;
  byte *pbStack_3e8;
  undefined *puStack_3e0;
  undefined *puStack_3d8;
  byte *pbStack_3d0;
  undefined *puStack_3c8;
  short *psStack_3a0;
  short **ppsStack_398;
  byte *pbStack_390;
  undefined *puStack_388;
  byte *pbStack_380;
  undefined *puStack_378;
  undefined4 *puStack_130;
  undefined8 uStack_128;
  longlong lStack_120;
  undefined4 *puStack_118;
  ushort uStack_f8;
  undefined auStack_f6 [2];
  undefined4 uStack_f4;
  byte *pbStack_f0;
  undefined8 uStack_e8;
  undefined8 uStack_da;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  undefined6 uStack_ce;
  int iStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [8];
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined6 uStack_98;
  undefined2 uStack_92;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined2 uStack_88;
  undefined6 uStack_86;
  undefined8 uStack_80;
  short *psStack_78;
  short *psStack_70;
  short sStack_68;
  undefined6 uStack_66;
  undefined auStack_60 [8];
  short sStack_58;
  undefined auStack_56 [2];
  undefined4 uStack_54;
  undefined8 uStack_50;
  ulonglong uStack_40;
  
  uStack_128 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)auStack_918;
  uStack_7d8 = param_5;
  uStack_6b0 = param_5;
  puVar5 = (undefined8 *)**(longlong **)(param_1 + 8);
  lStack_830 = (ulonglong)*(uint6 *)((longlong)puVar5 + 0x14) << 0x10;
  uStack_7d0 = *(undefined4 *)(puVar5[1] + 0x3c0);
  uStack_7cc = *(undefined2 *)(puVar5[1] + 0x3c4);
  uStack_7ca = 0;
  lVar11 = **param_2;
  iVar3 = *(int *)(lVar11 + 8);
  sVar1 = *(short *)(lVar11 + 0xc);
  iVar4 = *(int *)(lVar11 + 0x10);
  sVar2 = *(short *)(lVar11 + 0x14);
  lStack_7f0 = 0;
  uStack_7e8 = 0;
  uStack_7e4 = 0;
  uStack_850 = 0;
  uStack_84c = 0;
  uStack_87c = 2;
  uVar13 = 2;
  if (*(int *)(param_1 + 0xfc) == 3) {
    uVar13 = 0;
  }
  uStack_4c0 = 0;
  uStack_4f8 = 0;
  pplStack_848 = param_2;
  pplStack_840 = param_3;
  lStack_838 = param_1;
  lStack_818 = param_1;
  iStack_738 = iVar4;
  sStack_734 = sVar2;
  iStack_730 = iVar3;
  sStack_72c = sVar1;
  pplStack_528 = param_2;
  uStack_520 = param_4;
  pplStack_518 = param_3;
  puStack_4f0 = puVar5;
  sVar9 = (**(code **)*puVar5)(puVar5);
  uStack_4bc = uVar13;
  if (sVar9 == 2) {
    uStack_4bc = 2;
  }
  if ((*(byte *)(**pplStack_848 + 2) & 0x20) != 0) {
    uStack_8f8 = (undefined4 *)0x0;
    (*_DAT_)(1,0x1b47360,0x1b1dc18,0xc25);
  }
  func_0x(lStack_818,0x19a1b30);
  uStack_4f8 = *(undefined8 *)(lStack_818 + 0x110);
  if (*pplStack_840 != (longlong *)0x0) {
    func_0x(&uStack_4f8,pplStack_840);
  }
  uStack_6c0 = 0;
  uStack_6bc = 0;
  if ((iVar3 != 0) || (sVar1 != 0)) {
    func_0x(&uStack_4f8,param_4);
  }
  func_0x(&uStack_4f8,pplStack_848);
  uStack_6c8 = 0;
  uStack_6c4 = 0;
  if ((iVar4 != 0) || (sVar2 != 0)) {
    func_0x(&uStack_4f8,uStack_7d8);
  }
  lStack_120 = **pplStack_848;
  uStack_8f0 = 1;
  uStack_8f8 = (undefined4 *)CONCAT44(uStack_8f8._4_4_,(uint)*(byte *)(lStack_120 + 3));
  func_0x(lStack_818,&lStack_7f0,&iStack_730,&iStack_738);
  puStack_130 = (undefined4 *)(lStack_7f0 + 0x70);
  uStack_850 = *puStack_130;
  uStack_84c = *(undefined2 *)(lStack_7f0 + 0x74);
  func_0x(&uStack_4f8,&lStack_7f0);
  lVar11 = lStack_818;
  uStack_6d0 = 0;
  uStack_6cc = 0;
  if ((iVar3 != 0) || (sVar1 != 0)) {
    puStack_118 = &uStack_7b8;
    uStack_7b8 = uStack_850;
    uStack_7b4 = uStack_84c;
    uStack_8e8 = *(undefined8 *)(lStack_818 + 0x110);
    uStack_8f8 = &uStack_7b8;
    uStack_8f0 = uVar13;
    uStack_4a8 = uStack_8e8;
    func_0x(param_4,&uStack_7d0);
  }
  uStack_6d8 = 0;
  uStack_6d4 = 0;
  if ((iVar4 != 0) || (sVar2 != 0)) {
    puStack_4a0 = &uStack_7a8;
    uStack_7a8 = uStack_850;
    uStack_7a4 = uStack_84c;
    uStack_8e8 = *(undefined8 *)(lVar11 + 0x110);
    uStack_8f8 = &uStack_7a8;
    uStack_8f0 = uVar13;
    uStack_498 = uStack_8e8;
    func_0x(uStack_7d8,&uStack_7d0);
  }
  pplVar6 = pplStack_848;
  if (*(char *)(puVar5[4] + 0x1cdf) == '\0') {
    bStack_8e0 = 0;
  }
  else if (*(char *)(puVar5[4] + 0x1cdc) == '\0') {
    bStack_8e0 = 0;
  }
  else {
    bStack_8e0 = *(byte *)(puVar5[1] + 0x109) >> 6 & 1;
  }
  lStack_490 = **pplStack_848;
  uStack_8e8 = *(undefined8 *)(lVar11 + 0x110);
  uStack_8f0 = *(undefined4 *)(lVar11 + 0x100);
  uStack_8f8 = (undefined4 *)CONCAT44(uStack_8f8._4_4_,(uint)*(ushort *)(lStack_490 + 0x16));
  bStack_828 = bStack_8e0;
  func_0x(&lStack_7f0,&uStack_7d0,pplStack_848,0);
  if (*pplStack_840 == (longlong *)0x0) {
    func_0x(lVar11,pplVar6,&uStack_850,&uStack_4f8);
    func_0x(&uStack_4f8);
    func_0x(lVar11);
    lVar12 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar11 = *(longlong *)(lVar12 + 0x100);
    if (lVar11 == 0) {
      (*_DAT_)();
      lVar11 = *(longlong *)(lVar12 + 0x100);
    }
    if (*(int *)(lVar11 + 0x22c) != 0) {
      (*_DAT_)();
    }
    func_0x(&lStack_7f0);
    func_0x(uStack_40 ^ (ulonglong)auStack_918);
    return;
  }
  uStack_690 = 0;
  uStack_688 = 0;
  uStack_684 = 0;
  uStack_f8 = 0xffff;
  pbStack_f0 = (byte *)0x0;
  uStack_f4 = 0;
  uStack_da = 0;
  uStack_d0 = 0;
  uStack_ce = 0;
  uStack_e8 = 0;
  lStack_7a0 = puVar5[1] + 0x200;
  lVar11 = **pplStack_840;
  iStack_c4 = param_6;
  lStack_488 = lStack_7a0;
  lStack_480 = lVar11;
  if (-1 < *(char *)(lVar11 + 2)) {
    puStack_798 = (undefined *)0x0;
    goto LAB_;
  }
  puStack_478 = auStack_c0;
  uStack_98 = 0;
  uStack_8a = 0;
  uStack_80 = 0;
  psStack_70 = (short *)0x0;
  sStack_68 = 0;
  uStack_66 = 0;
  puStack_470 = auStack_c0;
  auStack_c0 = ZEXT816(0);
  puStack_468 = auStack_b0;
  stack0xffffffffffffff52 = SUB1614(ZEXT816(0),2);
  auStack_b0._0_2_ = 0xffff;
  uStack_a8 = 0;
  uStack_92 = 0;
  uStack_90 = 0;
  uStack_88 = 0;
  uStack_86 = 0;
  uStack_a0 = 0;
  ppsStack_460 = &psStack_78;
  psStack_78 = (short *)0x0;
  puStack_458 = auStack_60;
  _auStack_60 = ZEXT812(0);
  uStack_54 = 0;
  puStack_450 = auStack_56 + 2;
  uStack_50 = 0;
  puStack_798 = auStack_c0;
  cStack_880 = '\0';
  if (*(short *)(lVar11 + 0x24) == 0) {
LAB_:
    uStack_800 = *(undefined8 *)(lVar11 + 0x28);
    sStack_7f8 = *(short *)(lVar11 + 0x30);
  }
  else {
    cVar8 = *(char *)(lVar11 + 1);
    if ((((cVar8 == '\v') || (cVar8 == '\b')) || (cVar8 == '\t')) && (*(int *)(lVar11 + 0x18) == 99)
       ) {
      puStack_448 = &uStack_7b0;
      puStack_440 = (undefined4 *)(lVar11 + 0x20);
      uStack_7b0 = *puStack_440;
      uStack_7ac = *(undefined2 *)(lVar11 + 0x24);
      cVar8 = func_0x(&uStack_7b0);
      if (cVar8 == '\0') goto LAB_;
      cStack_880 = '\x01';
    }
    else {
LAB_:
      cStack_880 = '\0';
    }
    if (cStack_880 == '\0') goto LAB_;
    func_0x(lVar11,&uStack_800);
  }
  puStack_438 = &uStack_800;
  puStack_430 = (undefined4 *)(lVar11 + 0x20);
  pbStack_428 = (byte *)(lVar11 + 0x60);
  puStack_420 = auStack_c0;
  puVar7 = puStack_548;
  if (pbStack_428 == (byte *)auStack_c0._0_8_) {
    puStack_418 = auStack_60;
    if ((sStack_7f8 == sStack_58) && ((int)uStack_800 == auStack_60._0_4_)) {
      puVar7 = auStack_56 + 2;
      if (uStack_800._4_4_ != auStack_60._4_4_) {
        puVar7 = puStack_548;
      }
    }
  }
  puStack_548 = puVar7;
  iStack_508 = (int)uStack_800;
  auStack_c0._0_8_ = pbStack_428;
  puStack_410 = auStack_60;
  iStack_510 = uStack_800._4_4_;
  sStack_58 = sStack_7f8;
  auStack_60 = (undefined  [8])uStack_800;
  puStack_408 = auStack_56 + 2;
  uStack_54 = *puStack_430;
  uVar10 = (ulonglong)*pbStack_428;
  uStack_6b8 = (ushort)*pbStack_428;
  uStack_678 = *(undefined4 *)(uVar10 * 6 + 0x17931b0);
  uStack_674 = *(undefined2 *)(uVar10 * 6 + 0x17931b4);
  uStack_728 = *(undefined4 *)(uVar10 * 6 + 0x17931b0);
  sStack_87e = *(short *)(uVar10 * 6 + 0x17931b4);
  lStack_400 = lVar11 + 99;
  puStack_3f8 = auStack_b0;
  auStack_b0._0_2_ = 0xffff;
  auStack_b0 = (undefined  [8])((ulonglong)auStack_b0 & 0xffffffff);
  uStack_a8 = 0;
  uStack_92 = 0;
  uStack_90 = 0;
  uStack_88 = 0;
  uStack_86 = 0;
  uStack_a0 = 0;
  ppsStack_3f0 = &psStack_78;
  psStack_78 = (short *)0x0;
  psStack_70 = (short *)0x0;
  sStack_68 = 0;
  sStack_724 = sStack_87e;
  sStack_720 = sStack_7f8;
  if ((*pbStack_428 & 2) != 0) {
    pbStack_3e8 = pbStack_428 + sStack_87e;
    puStack_3e0 = auStack_b0;
    uStack_6e0 = (ushort)(*pbStack_3e8 & 1);
    auStack_b0 = (undefined  [8])CONCAT62((int6)((ulonglong)auStack_b0 >> 0x10),uStack_6e0);
    puStack_3d8 = auStack_b0 + 2;
    if ((*pbStack_3e8 & 1) != 0) {
      uStack_a8 = pbStack_3e8;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_3e8 & 0x1c) + 0x1023fc)
                              * 4 + 0x1023ec) - 0xe05c60);
      puStack_3c8 = puStack_3d8;
                    /* WARNING: Could not emulate address calculation at 0x00100ad6 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
    uStack_808 = 0;
    uStack_a8 = pbStack_3e8;
    uStack_8a = 0;
    uStack_88 = 0;
    pbStack_3d0 = pbStack_3e8;
                    /* WARNING: Could not emulate address calculation at 0x00100a1b */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_3e8 & 0xe) * 4 + 0x1023b0) - 0xe05c60))
              ();
    return;
  }
  if ((*pbStack_428 & 4) != 0) {
    uStack_728._2_2_ = (short)((uint)uStack_728 >> 0x10);
    if (uStack_728._2_2_ == 0) {
      uVar10 = (ulonglong)sStack_87e;
    }
    else {
      uVar10 = (ulonglong)*(ushort *)(lVar11 + 0x61 + (longlong)uStack_728._2_2_ * 2);
    }
    psStack_3a0 = (short *)(pbStack_428 + uVar10);
    ppsStack_398 = &psStack_78;
    sStack_6f0 = *psStack_3a0;
    psStack_70 = psStack_3a0 + 1;
    sStack_68 = (sStack_6f0 + 1) * 2;
    psStack_78 = psStack_3a0;
  }
  if (auStack_c0._8_8_ != 0) {
    func_0x(auStack_c0._8_8_,auStack_c0);
  }
LAB_:
  uStack_810 = (uint)*(ushort *)(lVar11 + 0xe);
  pbStack_390 = (byte *)((ulonglong)*(ushort *)(lVar11 + (0xfff - (longlong)param_6) * 2) + lVar11);
  uStack_704 = (ushort)(*pbStack_390 & 1);
  puStack_388 = auStack_f6;
  uStack_670 = uStack_810;
  uStack_f8 = uStack_704;
  pbStack_f0 = pbStack_390;
  if ((*pbStack_390 & 1) != 0) {
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_390 & 0x1c) + 0x102468) *
                            4 + 0x102458) - 0xe05c60);
    puStack_378 = puStack_388;
                    /* WARNING: Could not emulate address calculation at 0x0010100e */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbStack_390,pbStack_390,pbStack_390);
    return;
  }
  uStack_f4 = 0;
  uStack_d2 = 0;
  uStack_d0 = 0;
  pbStack_380 = pbStack_390;
                    /* WARNING: Could not emulate address calculation at 0x00100f5a */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_390 & 0xe) * 4 + 0x10241c) - 0xe05c60))()
  ;
  return;
}

