
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2)

{
  undefined2 uVar1;
  uint uVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  ushort *puVar5;
  uint6 uVar6;
  byte bVar7;
  char cVar8;
  ushort uVar9;
  ushort uVar10;
  int iVar11;
  longlong lVar12;
  longlong lVar13;
  undefined8 uVar14;
  undefined8 uVar15;
  longlong lVar16;
  ulonglong *puVar17;
  longlong *plVar18;
  undefined4 *puVar19;
  uint uVar20;
  uint uVar21;
  undefined8 unaff_RBX;
  ushort *puVar22;
  uint uVar23;
  longlong lVar24;
  ulonglong uVar25;
  ulonglong uVar26;
  byte *pbVar27;
  longlong *plVar28;
  ushort *puVar29;
  short *psVar30;
  short *psVar31;
  ulonglong uVar32;
  longlong unaff_GS_OFFSET;
  short *apsStackX_8 [2];
  longlong lStackX_18;
  longlong lStackX_20;
  undefined8 *puStack_2bb8;
  undefined8 uStack_2bb0;
  undefined2 auStack_2ba8 [2];
  undefined4 uStack_2ba4;
  undefined8 uStack_2ba0;
  undefined8 uStack_2b98;
  undefined8 uStack_2b8a;
  undefined8 uStack_2b80;
  undefined8 uStack_2b70;
  undefined auStack_2b68 [8];
  undefined4 uStack_2b60;
  undefined4 uStack_2b58;
  undefined4 **ppuStack_2b50;
  undefined *puStack_2b48;
  undefined8 uStack_2b40;
  undefined4 *puStack_2b38;
  undefined8 uStack_2b30;
  undefined auStack_2b28 [528];
  undefined8 uStack_2918;
  undefined8 uStack_2910;
  undefined4 uStack_2908;
  uint uStack_2904;
  undefined2 uStack_2900;
  undefined4 uStack_28fe;
  undefined8 uStack_28fa;
  undefined8 uStack_28f2;
  undefined auStack_28e8 [8];
  undefined4 uStack_28e0;
  undefined4 uStack_28d8;
  undefined4 **ppuStack_28d0;
  undefined *puStack_28c8;
  undefined8 uStack_28c0;
  undefined4 *puStack_28b8;
  undefined8 uStack_28b0;
  undefined auStack_28a8 [528];
  undefined8 uStack_2698;
  undefined8 uStack_2690;
  undefined4 uStack_2688;
  uint uStack_2684;
  undefined2 uStack_2680;
  undefined4 uStack_267e;
  undefined8 uStack_267a;
  undefined8 uStack_2672;
  undefined auStack_2668 [8];
  undefined4 uStack_2660;
  undefined4 uStack_2658;
  uint **ppuStack_2650;
  undefined *puStack_2648;
  undefined8 uStack_2640;
  uint *puStack_2638;
  undefined8 uStack_2630;
  undefined auStack_2628 [528];
  undefined8 uStack_2418;
  undefined8 uStack_2410;
  uint uStack_2408;
  undefined2 uStack_2404;
  undefined4 uStack_2402;
  longlong lStack_23fe;
  char cStack_23f6;
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  uStack_2b70 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002c28 + lVar12) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar12);
  *(longlong *)((longlong)&lStackX_18 + lVar12) = param_1;
  auStack_2ba8[0] = 0xffff;
  plVar28 = (longlong *)0x0;
  uStack_2ba0 = 0;
  uStack_2ba4 = 0;
  uStack_2b8a = 0;
  uStack_2b80 = 0;
  uStack_2b98 = 0;
  *(undefined8 *)(&stack0x00000038 + lVar12) = param_2;
  *(undefined2 **)(&stack0x00000040 + lVar12) = auStack_2ba8;
  puStack_2bb8 = (undefined8 *)(param_1 + 600);
  lVar13 = *(longlong *)(param_1 + 0x250);
  uVar9 = *(ushort *)(lVar13 + 0x1c);
  plVar18 = (longlong *)(ulonglong)(uVar9 - 2);
  if (uVar9 < 3) {
    plVar18 = plVar28;
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1000bc;
  iVar11 = func_0x(lVar13,&stack0x00000038 + lVar12,plVar18,0);
  if (iVar11 == 0) {
    uVar14 = *(undefined8 *)(param_1 + 8);
    lVar13 = *(longlong *)(param_1 + 0x250);
    if (lVar13 == 0) {
      puVar19 = (undefined4 *)(_DAT_ + 0x70);
    }
    else {
      puVar19 = (undefined4 *)(lVar13 + 0x20);
    }
    uVar6 = *(uint6 *)(param_1 + 0x24);
    uVar1 = *(undefined2 *)(*(longlong *)(param_1 + 0x30) + 0x6b8);
    *(undefined8 *)((longlong)&lStackX_20 + lVar12) = 0xffffffffffffffff;
    *(undefined2 *)(&stack0x0000002e + lVar12) = 0;
    if ((_DAT_ & 0x1000) == 0) {
      *(longlong *)((longlong)&lStackX_20 + lVar12 + -0x20) = (longlong)&lStackX_20 + lVar12;
      *(undefined **)((longlong)apsStackX_8 + lVar12 + 8) = &stack0xfffffffffffffff8 + lVar12;
    }
    else {
      *(ulonglong *)((longlong)&lStackX_20 + lVar12) = (ulonglong)uVar6 << 0x10;
      *(undefined2 *)(&stack0x00000030 + lVar12) = uVar1;
      *(undefined4 *)(&stack0x00000028 + lVar12) = *puVar19;
      *(undefined2 *)(&stack0x0000002c + lVar12) = *(undefined2 *)(puVar19 + 1);
      *(longlong *)((longlong)&lStackX_20 + lVar12 + -0x20) = (longlong)&lStackX_20 + lVar12;
      *(undefined **)((longlong)apsStackX_8 + lVar12 + 8) = &stack0xfffffffffffffff8 + lVar12;
      uVar15 = _DAT_;
      if (*_DAT_ != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1008b2;
        (*_DAT_)(&uStack_2bb0);
        uVar15 = uStack_2bb0;
      }
      *(undefined8 *)(&stack0xfffffffffffffff8 + lVar12) = uVar15;
      uStack_2b60 = 0x10000;
      uStack_2b58 = 0;
      ppuStack_2b50 = &puStack_2b38;
      puStack_2b48 = auStack_2b28;
      uStack_2918 = 0;
      uStack_2b40 = 0;
      uStack_2910 = 0;
      puStack_2b38 = &uStack_2908;
      uStack_2b30 = 0x1e;
      uStack_2908 = 0;
      uStack_28f2 = 0;
      puVar3 = *(undefined8 **)((longlong)&lStackX_20 + lVar12 + -0x20);
      uStack_28fa = *puVar3;
      uStack_2900 = *(undefined2 *)((longlong)puVar3 + 0xc);
      uStack_28fe = *(undefined4 *)(puVar3 + 1);
      uStack_2904 = (uint)*(ushort *)(puVar3 + 2);
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100949;
      func_0x(auStack_2b68);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar12) = 0;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar12) = param_1 + 0x330;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100981;
    iVar11 = func_0x(lVar13,0,param_1 + 0x10,uVar14);
    if ((_DAT_ >> 0xc & 1) != 0) {
      uStack_28e0 = 0x10000;
      uStack_28d8 = 0;
      ppuStack_28d0 = &puStack_28b8;
      puStack_28c8 = auStack_28a8;
      uStack_2698 = 0;
      uStack_28c0 = 0;
      uStack_2690 = 0;
      puStack_28b8 = &uStack_2688;
      uStack_28b0 = 0x1e;
      uStack_2688 = 1;
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100a00;
      uStack_2672 = func_0x(&stack0xfffffffffffffff8 + lVar12);
      puVar3 = *(undefined8 **)((longlong)&lStackX_20 + lVar12 + -0x20);
      uStack_267a = *puVar3;
      uStack_2680 = *(undefined2 *)((longlong)puVar3 + 0xc);
      uStack_267e = *(undefined4 *)(puVar3 + 1);
      uStack_2684 = (uint)*(ushort *)(puVar3 + 2);
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100a40;
      func_0x(auStack_28e8);
    }
    if (iVar11 != 0) {
      if (lVar13 == 0) {
        puVar19 = (undefined4 *)(_DAT_ + 0x70);
      }
      else {
        puVar19 = (undefined4 *)(lVar13 + 0x20);
      }
      if ((_DAT_ >> 0xb & 1) != 0) {
        uStack_2660 = 0x10000;
        uStack_2658 = 0;
        ppuStack_2650 = &puStack_2638;
        puStack_2648 = auStack_2628;
        uStack_2418 = 0;
        uStack_2640 = 0;
        uStack_2410 = 0;
        puStack_2638 = &uStack_2408;
        uStack_2630 = 0x13;
        uStack_2404 = *(undefined2 *)(puVar19 + 1);
        uStack_2402 = *puVar19;
        uStack_2408 = (uint)*(ushort *)(*(longlong *)(param_1 + 0x30) + 0x6b8);
        lStack_23fe = (ulonglong)*(uint6 *)(param_1 + 0x24) << 0x10;
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1013c1;
        cStack_23f6 = (char)iVar11;
        func_0x(auStack_2668);
      }
      goto LAB_;
    }
    if (*_DAT_ != (char)iVar11) {
      plVar18 = plVar28;
      if (_DAT_ != 0) {
        plVar18 = (longlong *)(_DAT_ + 0x6800);
      }
      if ((plVar18 != (longlong *)0x0) && (*plVar18 != 0)) {
        LOCK();
        plVar18 = (longlong *)(*plVar18 + 0x150);
        *plVar18 = *plVar18 + 1;
        UNLOCK();
      }
    }
    lVar13 = *(longlong *)(*(longlong *)(param_1 + 0x18) + 0x488);
    if (((lVar13 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
      if (*(longlong *)(lVar13 + 0x20) != 0) {
        lVar24 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        lVar16 = *(longlong *)(lVar24 + 0x100);
        if (lVar16 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100af7;
          (*_DAT_)(0);
          lVar16 = *(longlong *)(lVar24 + 0x100);
        }
        plVar18 = plVar28;
        if (*(longlong *)(lVar16 + 0x260) != 0) {
          plVar18 = (longlong *)(ulonglong)*(uint *)(*(longlong *)(lVar16 + 0x260) + 0xe68);
        }
        if ((uint)plVar18 < *(uint *)(_DAT_ + 8)) {
          lVar13 = *(longlong *)(*(longlong *)(lVar13 + 0x20) + (longlong)plVar18 * 8);
          *(longlong *)(lVar13 + 0x128) = *(longlong *)(lVar13 + 0x128) + 1;
          goto LAB_;
        }
      }
      LOCK();
      plVar18 = (longlong *)(*(longlong *)(lVar13 + 0x18) + 0x128);
      *plVar18 = *plVar18 + 1;
      UNLOCK();
    }
LAB_:
    puVar3 = *(undefined8 **)(&stack0x00000040 + lVar12);
    puVar3[1] = 0;
    *puVar3 = 0xffff;
    puVar3[3] = 0;
    puVar3[4] = 0;
    puVar3[2] = 0;
    *(undefined4 *)(puVar3 + 6) = 0;
    puVar3[5] = 0;
    *puStack_2bb8 = 0;
    puStack_2bb8[0xc] = 0;
    *(undefined2 *)(puStack_2bb8 + 0xd) = 0;
    *(undefined8 *)((longlong)puStack_2bb8 + 0x6c) = 1;
    puVar3 = (undefined8 *)puStack_2bb8[1];
    if (puVar3 != (undefined8 *)0x0) {
      puVar4 = (undefined8 *)puVar3[1];
      if (puVar4 != (undefined8 *)0x0) {
        *puVar4 = 0;
        *(undefined4 *)(puVar4 + 0x481) = 0;
      }
      puVar3[3] = 0;
      *(undefined2 *)(puVar3 + 4) = 0;
      *puVar3 = 0;
      *(undefined4 *)(puVar3 + 0x14b) = 0;
    }
    lVar13 = *(longlong *)(param_1 + 0x250);
    uVar9 = *(ushort *)(lVar13 + 0x1c);
    plVar18 = (longlong *)(ulonglong)(uVar9 - 2);
    if (uVar9 < 3) {
      plVar18 = plVar28;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100bde;
    iVar11 = func_0x(lVar13,&stack0x00000038 + lVar12,plVar18,0);
    if (iVar11 == 0) goto LAB_;
    psVar30 = *(short **)(&stack0x00000040 + lVar12);
    if (-1 < *(char *)(*(longlong *)(param_1 + 0x250) + 2)) {
      psVar30 = *(short **)(&stack0x00000038 + lVar12);
    }
    *(short **)((longlong)apsStackX_8 + lVar12 + 8) = psVar30;
    puVar22 = (ushort *)(psVar30 + 1);
    uVar26 = (ulonglong)*(uint *)(psVar30 + 2);
    if (*psVar30 == 0) {
      psVar31 = psVar30;
      if (*(uint *)(psVar30 + 2) != 0) goto LAB_;
      *puVar22 = 0;
      uVar20 = *(uint *)(psVar30 + 8);
      uVar26 = (ulonglong)uVar20;
      *(uint *)(psVar30 + 10) = uVar20;
      pbVar27 = *(byte **)(psVar30 + 4);
      bVar7 = *pbVar27;
      if ((bVar7 & 0x10) != 0) {
        uVar20 = uVar20 + 2 + (*(ushort *)(pbVar27 + uVar26) + 7 >> 3);
        uVar26 = (ulonglong)uVar20;
        *(uint *)(psVar30 + 10) = uVar20;
        bVar7 = *pbVar27;
      }
      if ((bVar7 & 0x20) == 0) {
        *(int *)(psVar30 + 2) = (int)uVar26;
        psVar30[0xe] = 0;
        *(int *)(psVar30 + 0xc) = (int)uVar26;
      }
      else {
        puVar29 = (ushort *)(pbVar27 + uVar26);
        uVar9 = *puVar29;
        psVar30[0xe] = uVar9;
        if (uVar9 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100c7c;
          cVar8 = func_0x(0x19ab8a0);
          if (cVar8 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100c85;
            lVar13 = func_0x();
            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100c9f;
              cVar8 = func_0x(0x19ab8a0);
              if (cVar8 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100cbb;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100ce1;
                (*_DAT_)(1,0x129b2ac,0x13bb398,0x80f);
              }
            }
          }
          uVar14 = *(undefined8 *)(psVar30 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100cef;
          func_0x(uVar14,3);
          uVar26 = (ulonglong)*(uint *)(psVar30 + 10);
          uVar9 = psVar30[0xe];
        }
        uVar20 = (int)uVar26 + (uVar9 + 1) * 2;
        *(uint *)(psVar30 + 0xc) = uVar20;
        if (0x1f9e < uVar20) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d1f;
          cVar8 = func_0x(0x19ab8a0);
          if (cVar8 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d28;
            lVar13 = func_0x();
            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d42;
              cVar8 = func_0x(0x19ab8a0);
              if (cVar8 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d5e;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d84;
                (*_DAT_)(1,0x129b2ac,0x13bb398,0x816);
              }
            }
          }
          uVar14 = *(undefined8 *)(psVar30 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d92;
          func_0x(uVar14,4);
          uVar9 = psVar30[0xe];
          uVar20 = *(uint *)(psVar30 + 0xc);
        }
        uVar26 = (ulonglong)uVar9;
        uVar9 = puVar29[uVar26];
        *(uint *)(psVar30 + 2) = uVar9 & 0x7fff;
        if ((uVar9 & 0x7fff) < uVar20) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100dc2;
          cVar8 = func_0x(0x19ab8a0);
          if (cVar8 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100dcb;
            lVar13 = func_0x();
            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100de5;
              cVar8 = func_0x(0x19ab8a0);
              if (cVar8 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100e01;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100e27;
                (*_DAT_)(1,0x129b2ac,0x13bb398,0x81d);
              }
            }
          }
          uVar14 = *(undefined8 *)(psVar30 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100e35;
          func_0x(uVar14,4);
          uVar20 = *(uint *)(psVar30 + 0xc);
          uVar26 = (ulonglong)(ushort)psVar30[0xe];
        }
        iVar11 = 0;
        puVar5 = puVar29;
        if ((short)uVar26 != 0) {
          do {
            uVar23 = puVar5[1] & 0x7fff;
            if ((uVar23 < uVar20) || (*(uint *)(psVar30 + 2) < uVar23)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100e7f;
              cVar8 = func_0x(0x19ab8a0);
              if (cVar8 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100e88;
                lVar13 = func_0x();
                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100ea2;
                  cVar8 = func_0x(0x19ab8a0);
                  if (cVar8 == '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100ebe;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100ee2;
                    (*_DAT_)(1,0x129b2ac,0x13bb398,0x82a);
                  }
                }
              }
              uVar14 = *(undefined8 *)(psVar30 + 4);
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100ef0;
              func_0x(uVar14,4);
            }
            iVar11 = iVar11 + 1;
            uVar26 = (ulonglong)(ushort)psVar30[0xe];
            puVar5 = puVar5 + 1;
            uVar20 = uVar23;
          } while (iVar11 < (int)(uint)(ushort)psVar30[0xe]);
          psVar31 = *(short **)((longlong)apsStackX_8 + lVar12 + 8);
        }
        if ((short)puVar29[(ulonglong)((int)uVar26 - 1) + 1] < 0) {
          lVar13 = *(longlong *)(psVar30 + 4);
          do {
            uVar20 = *(ushort *)((ulonglong)*(uint *)(psVar30 + 10) + lVar13 + uVar26 * 2) & 0x7fff;
            if ((int)uVar26 == 1) {
              uVar23 = *(uint *)(psVar30 + 0xc);
              uVar21 = uVar23;
LAB_:
              if ((uVar20 < uVar23) || (uVar2 = *(uint *)(psVar30 + 2), uVar2 < uVar20))
              goto LAB_;
            }
            else {
              uVar23 = *(ushort *)((ulonglong)*(uint *)(psVar30 + 10) + lVar13 + -2 + uVar26 * 2) &
                       0x7fff;
              uVar21 = *(uint *)(psVar30 + 0xc);
              if (uVar21 <= uVar23) goto LAB_;
LAB_:
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100f7c;
              func_0x(lVar13,7);
              uVar21 = *(uint *)(psVar30 + 0xc);
              uVar2 = *(uint *)(psVar30 + 2);
            }
            uVar26 = (ulonglong)uVar2;
            if ((uVar23 < uVar21) || (uVar2 < uVar23)) goto LAB_;
            lVar13 = *(longlong *)(psVar30 + 4);
            if (*(ushort *)(lVar13 + (ulonglong)uVar23) == 5) {
              *puVar22 = *puVar22 | 2;
              psVar30[0xe] = psVar30[0xe] + -1;
              uVar25 = (ulonglong)(uVar23 & 0xffff);
              psVar30[0x15] = (short)uVar23;
              uVar26 = *(ulonglong *)(psVar30 + 4);
              uVar9 = psVar30[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar25 + 2 + uVar26) >> 0xe & 1) != 0) {
                uVar9 = *(ushort *)(uVar25 + 2 + uVar26) & 0x3800 | psVar30[0x16] & 0xc7ffU;
              }
              psVar30[0x16] = uVar9;
              uVar10 = (uVar9 ^ *(ushort *)(uVar25 + 2 + uVar26)) & 0x7ff ^ uVar9;
              psVar30[0x16] = uVar10;
              uVar25 = (ulonglong)(ushort)psVar30[0x15];
              uVar32 = uVar25 + 4 +
                       (ulonglong)((uVar10 & 0x7ff) * 2) + uVar26 + (uVar9 >> 0xb & 7) * 2;
              if (uVar32 < uVar25 + uVar26) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101089;
                func_0x(uVar25 + uVar26,0x19);
                uVar10 = psVar30[0x16];
                uVar25 = (ulonglong)(ushort)psVar30[0x15];
                uVar26 = (ulonglong)*(uint *)(psVar30 + 4);
              }
              if (uVar20 - uVar23 <
                  (((uVar10 & 0x7ff) * 2 - (int)uVar25) - (int)uVar26) + (int)uVar32) {
                lVar13 = *(longlong *)(psVar30 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1010c1;
                func_0x(uVar25 + lVar13,0x19);
                uVar10 = psVar30[0x16];
              }
              if ((uVar10 & 0x3800) != 0) {
                puVar29 = (ushort *)
                          (*(longlong *)(psVar30 + 4) + 4 + (ulonglong)(ushort)psVar30[0x15]);
                iVar11 = 0;
                if ((uVar10 & 0x3800) != 0) goto LAB_;
              }
              break;
            }
            if (*(ushort *)(lVar13 + (ulonglong)uVar23) < 0x400) break;
            *puVar22 = *puVar22 | 1;
            uVar9 = psVar30[0xe] - 1;
            psVar30[0xe] = uVar9;
            if ((uVar9 == 0) ||
               (uVar26 = (ulonglong)uVar9, -1 < (short)puVar29[(ulonglong)(uVar9 - 1) + 1])) break;
          } while( true );
        }
        pbVar27 = *(byte **)(psVar30 + 4);
        uVar26 = (ulonglong)*(uint *)(psVar30 + 2);
      }
      goto LAB_;
    }
  }
  else {
    psVar30 = *(short **)(&stack0x00000040 + lVar12);
    if (-1 < *(char *)(*(longlong *)(param_1 + 0x250) + 2)) {
      psVar30 = *(short **)(&stack0x00000038 + lVar12);
    }
    *(short **)((longlong)apsStackX_8 + lVar12) = psVar30;
    puVar22 = (ushort *)(psVar30 + 1);
    uVar26 = (ulonglong)*(uint *)(psVar30 + 2);
    if (*psVar30 == 0) {
      psVar31 = psVar30;
      if (*(uint *)(psVar30 + 2) == 0) {
        *puVar22 = 0;
        uVar20 = *(uint *)(psVar30 + 8);
        uVar26 = (ulonglong)uVar20;
        *(uint *)(psVar30 + 10) = uVar20;
        pbVar27 = *(byte **)(psVar30 + 4);
        bVar7 = *pbVar27;
        if ((bVar7 & 0x10) != 0) {
          uVar20 = uVar20 + 2 + (*(ushort *)(pbVar27 + uVar26) + 7 >> 3);
          uVar26 = (ulonglong)uVar20;
          *(uint *)(psVar30 + 10) = uVar20;
          bVar7 = *pbVar27;
        }
        if ((bVar7 & 0x20) == 0) {
          *(int *)(psVar30 + 2) = (int)uVar26;
          psVar30[0xe] = 0;
          *(int *)(psVar30 + 0xc) = (int)uVar26;
        }
        else {
          puVar29 = (ushort *)(pbVar27 + uVar26);
          uVar9 = *puVar29;
          psVar30[0xe] = uVar9;
          if (uVar9 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10015a;
            cVar8 = func_0x(0x19ab8a0);
            if (cVar8 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100163;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10017d;
                cVar8 = func_0x(0x19ab8a0);
                if (cVar8 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100198;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001c0;
                  (*_DAT_)(1,0x129b2ac,0x13bb398,0x80f);
                }
              }
            }
            uVar14 = *(undefined8 *)(psVar30 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001ce;
            func_0x(uVar14,3);
            uVar26 = (ulonglong)*(uint *)(psVar30 + 10);
            uVar9 = psVar30[0xe];
          }
          uVar20 = (int)uVar26 + (uVar9 + 1) * 2;
          *(uint *)(psVar30 + 0xc) = uVar20;
          if (0x1f9e < uVar20) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001fe;
            cVar8 = func_0x(0x19ab8a0);
            if (cVar8 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100207;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100221;
                cVar8 = func_0x(0x19ab8a0);
                if (cVar8 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10023d;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100265;
                  (*_DAT_)(1,0x129b2ac,0x13bb398,0x816);
                }
              }
            }
            uVar14 = *(undefined8 *)(psVar30 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100273;
            func_0x(uVar14,4);
            uVar9 = psVar30[0xe];
            uVar20 = *(uint *)(psVar30 + 0xc);
          }
          uVar26 = (ulonglong)uVar9;
          uVar9 = puVar29[uVar26];
          *(uint *)(psVar30 + 2) = uVar9 & 0x7fff;
          if ((uVar9 & 0x7fff) < uVar20) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1002a3;
            cVar8 = func_0x(0x19ab8a0);
            if (cVar8 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1002ac;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1002c6;
                cVar8 = func_0x(0x19ab8a0);
                if (cVar8 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1002e2;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10030a;
                  (*_DAT_)(1,0x129b2ac,0x13bb398,0x81d);
                }
              }
            }
            uVar14 = *(undefined8 *)(psVar30 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100318;
            func_0x(uVar14,4);
            uVar20 = *(uint *)(psVar30 + 0xc);
            uVar26 = (ulonglong)(ushort)psVar30[0xe];
          }
          iVar11 = 0;
          puVar5 = puVar29;
          if ((short)uVar26 != 0) {
            do {
              uVar23 = puVar5[1] & 0x7fff;
              if ((uVar23 < uVar20) || (*(uint *)(psVar30 + 2) < uVar23)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10035f;
                cVar8 = func_0x(0x19ab8a0);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100368;
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100382;
                    cVar8 = func_0x(0x19ab8a0);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10039e;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1003c2;
                      (*_DAT_)(1,0x129b2ac,0x13bb398,0x82a);
                    }
                  }
                }
                uVar14 = *(undefined8 *)(psVar30 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1003d0;
                func_0x(uVar14,4);
              }
              iVar11 = iVar11 + 1;
              uVar26 = (ulonglong)(ushort)psVar30[0xe];
              puVar5 = puVar5 + 1;
              uVar20 = uVar23;
            } while (iVar11 < (int)(uint)(ushort)psVar30[0xe]);
            psVar31 = *(short **)((longlong)apsStackX_8 + lVar12);
          }
          if ((short)puVar29[(ulonglong)((int)uVar26 - 1) + 1] < 0) {
            lVar13 = *(longlong *)(psVar30 + 4);
            do {
              uVar20 = *(ushort *)((ulonglong)*(uint *)(psVar30 + 10) + lVar13 + uVar26 * 2) &
                       0x7fff;
              if ((int)uVar26 == 1) {
                uVar23 = *(uint *)(psVar30 + 0xc);
                uVar21 = uVar23;
LAB_:
                if ((uVar20 < uVar23) || (uVar2 = *(uint *)(psVar30 + 2), uVar2 < uVar20))
                goto LAB_;
              }
              else {
                uVar23 = *(ushort *)((ulonglong)*(uint *)(psVar30 + 10) + lVar13 + -2 + uVar26 * 2)
                         & 0x7fff;
                uVar21 = *(uint *)(psVar30 + 0xc);
                if (uVar21 <= uVar23) goto LAB_;
LAB_:
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10045c;
                func_0x(lVar13,7);
                uVar21 = *(uint *)(psVar30 + 0xc);
                uVar2 = *(uint *)(psVar30 + 2);
              }
              uVar26 = (ulonglong)uVar2;
              if ((uVar23 < uVar21) || (uVar2 < uVar23)) goto LAB_;
              lVar13 = *(longlong *)(psVar30 + 4);
              if (*(ushort *)(lVar13 + (ulonglong)uVar23) == 5) {
                *puVar22 = *puVar22 | 2;
                psVar30[0xe] = psVar30[0xe] + -1;
                uVar25 = (ulonglong)(uVar23 & 0xffff);
                psVar30[0x15] = (short)uVar23;
                uVar26 = *(ulonglong *)(psVar30 + 4);
                uVar9 = psVar30[0x16] & 0xc7ffU;
                if ((*(ushort *)(uVar25 + 2 + uVar26) >> 0xe & 1) != 0) {
                  uVar9 = *(ushort *)(uVar25 + 2 + uVar26) & 0x3800 | psVar30[0x16] & 0xc7ffU;
                }
                psVar30[0x16] = uVar9;
                uVar10 = (uVar9 ^ *(ushort *)(uVar25 + 2 + uVar26)) & 0x7ff ^ uVar9;
                psVar30[0x16] = uVar10;
                uVar25 = (ulonglong)(ushort)psVar30[0x15];
                uVar32 = uVar26 + 4 +
                         (ulonglong)((uVar10 & 0x7ff) * 2) + uVar25 + (uVar9 >> 0xb & 7) * 2;
                if (uVar32 < uVar25 + uVar26) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100564;
                  func_0x(uVar25 + uVar26,0x19);
                  uVar10 = psVar30[0x16];
                  uVar25 = (ulonglong)(ushort)psVar30[0x15];
                  uVar26 = (ulonglong)*(uint *)(psVar30 + 4);
                }
                if (uVar20 - uVar23 <
                    (((uVar10 & 0x7ff) * 2 - (int)uVar25) - (int)uVar26) + (int)uVar32) {
                  lVar13 = *(longlong *)(psVar30 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10059c;
                  func_0x(uVar25 + lVar13,0x19);
                  uVar10 = psVar30[0x16];
                }
                if ((uVar10 & 0x3800) != 0) {
                  puVar29 = (ushort *)
                            (*(longlong *)(psVar30 + 4) + 4 + (ulonglong)(ushort)psVar30[0x15]);
                  iVar11 = 0;
                  if ((uVar10 & 0x3800) != 0) goto LAB_;
                }
                break;
              }
              if (*(ushort *)(lVar13 + (ulonglong)uVar23) < 0x400) break;
              *puVar22 = *puVar22 | 1;
              uVar9 = psVar30[0xe] - 1;
              psVar30[0xe] = uVar9;
              if ((uVar9 == 0) ||
                 (uVar26 = (ulonglong)uVar9, -1 < (short)puVar29[(ulonglong)(uVar9 - 1) + 1]))
              break;
            } while( true );
          }
          pbVar27 = *(byte **)(psVar30 + 4);
          uVar26 = (ulonglong)*(uint *)(psVar30 + 2);
        }
        goto LAB_;
      }
      goto LAB_;
    }
  }
  if ((int)uVar26 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1007d5;
    func_0x(puVar22);
    uVar26 = (ulonglong)*(uint *)(puVar22 + 1);
  }
  if (((uint)uVar26 < 9) &&
     (((**(byte **)(puVar22 + 3) & 0x1c) == 0 || ((**(byte **)(puVar22 + 3) & 0x1c) == 0xc)))) {
    uVar26 = 9;
  }
  goto LAB_;
LAB_:
  do {
    if ((uVar10 & 0x7ff) < (*puVar29 & 0x7ff)) {
      uVar9 = psVar30[0x15];
      lVar13 = *(longlong *)(psVar30 + 4);
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100606;
      func_0x((ulonglong)uVar9 + lVar13,0x1a);
      uVar10 = psVar30[0x16];
    }
    iVar11 = iVar11 + 1;
    puVar29 = puVar29 + 1;
  } while (iVar11 < (int)(uVar10 >> 0xb & 7));
  pbVar27 = *(byte **)(psVar30 + 4);
  uVar26 = (ulonglong)*(uint *)(psVar30 + 2);
LAB_:
  if ((*pbVar27 & 0x40) == 0) {
    *(undefined4 *)(psVar30 + 0x13) = 0;
  }
  else {
    *(int *)(psVar30 + 0x13) = (int)uVar26;
    *(int *)(psVar30 + 2) = (int)uVar26 + 0xe;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10064e;
    uVar14 = func_0x(puVar22);
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10065b;
    func_0x(uVar14,(longlong)apsStackX_8 + lVar12);
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100665;
    iVar11 = func_0x((longlong)apsStackX_8 + lVar12);
    *(int *)(psVar30 + 2) = *(int *)(psVar30 + 2) + iVar11;
    uVar26 = (ulonglong)*(uint *)(psVar30 + 2);
  }
  if ((*(ulonglong *)(psVar30 + 0xf) != 0) &&
     (*(ulonglong *)(psVar30 + 0xf) < uVar26 + *(longlong *)(psVar30 + 4))) {
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10069c;
    cVar8 = func_0x(0x19ab8a0);
    if (cVar8 != '\0') {
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1006a5;
      lVar13 = func_0x();
      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1006bf;
        cVar8 = func_0x(0x19ab8a0);
        if (cVar8 == '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1006db;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1006ff;
          (*_DAT_)(1,0x129b2ac,0x13bb398,0x886);
        }
      }
    }
    uVar14 = *(undefined8 *)(psVar30 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10070d;
    func_0x(uVar14,0x12);
    uVar26 = (ulonglong)*(uint *)(psVar30 + 2);
  }
  if (((uint)uVar26 == 0) || (0x3f3c < (uint)uVar26)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10072f;
    cVar8 = func_0x(0x19ab8a0);
    if (cVar8 != '\0') {
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100738;
      lVar13 = func_0x();
      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100752;
        cVar8 = func_0x(0x19ab8a0);
        if (cVar8 == '\0') {
LAB_:
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10076e;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100792;
          (*_DAT_)(1,0x129b2ac,0x13bb398,0x88b);
        }
      }
    }
LAB_:
    uVar14 = *(undefined8 *)(puVar22 + 3);
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1007a0;
    func_0x(uVar14,5);
    uVar26 = (ulonglong)*(uint *)(puVar22 + 1);
  }
  goto LAB_;
LAB_:
  do {
    if ((uVar10 & 0x7ff) < (*puVar29 & 0x7ff)) {
      uVar9 = psVar30[0x15];
      lVar13 = *(longlong *)(psVar30 + 4);
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101126;
      func_0x((ulonglong)uVar9 + lVar13,0x1a);
      uVar10 = psVar30[0x16];
    }
    iVar11 = iVar11 + 1;
    puVar29 = puVar29 + 1;
  } while (iVar11 < (int)(uVar10 >> 0xb & 7));
  pbVar27 = *(byte **)(psVar30 + 4);
  uVar26 = (ulonglong)*(uint *)(psVar30 + 2);
LAB_:
  iVar11 = 0;
  if ((*pbVar27 & 0x40) == 0) {
    *(undefined4 *)(psVar30 + 0x13) = 0;
  }
  else {
    *(int *)(psVar30 + 0x13) = (int)uVar26;
    *(int *)(psVar30 + 2) = (int)uVar26 + 0xe;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101175;
    puVar17 = (ulonglong *)func_0x(puVar22);
    uVar26 = *puVar17;
    uVar10 = (ushort)(uVar26 >> 0x30);
    uVar9 = uVar10;
    if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
      uVar9 = uVar10 & 0xdfff;
      if ((uVar26 & 0x4000000000000000) != 0) {
        uVar9 = uVar10 | 0x2000;
      }
    }
    if (uVar9 == 0xfffc) {
      iVar11 = (int)((uVar26 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)(psVar30 + 2) = *(int *)(psVar30 + 2) + iVar11;
    uVar26 = (ulonglong)*(uint *)(psVar30 + 2);
  }
  if ((*(ulonglong *)(psVar30 + 0xf) != 0) &&
     (*(ulonglong *)(psVar30 + 0xf) < uVar26 + *(longlong *)(psVar30 + 4))) {
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101202;
    cVar8 = func_0x(0x19ab8a0);
    if (cVar8 != '\0') {
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10120b;
      lVar13 = func_0x();
      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101225;
        cVar8 = func_0x(0x19ab8a0);
        if (cVar8 == '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101241;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101265;
          (*_DAT_)(1,0x129b2ac,0x13bb398,0x886);
        }
      }
    }
    uVar14 = *(undefined8 *)(psVar30 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101273;
    func_0x(uVar14,0x12);
    uVar26 = (ulonglong)*(uint *)(psVar30 + 2);
  }
  if (((uint)uVar26 == 0) || (0x3f3c < (uint)uVar26)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101295;
    cVar8 = func_0x(0x19ab8a0);
    if (cVar8 != '\0') {
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1012a2;
      lVar13 = func_0x();
      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1012c4;
        cVar8 = func_0x(0x19ab8a0);
        if (cVar8 == '\0') goto LAB_;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1012ee;
        (*_DAT_)(1,0x129b2ac,0x13bb398,0x88b);
      }
    }
    goto LAB_;
  }
LAB_:
  if (((uint)uVar26 < 9) &&
     (((**(byte **)(puVar22 + 3) & 0xe) == 0 || ((**(byte **)(puVar22 + 3) & 0xe) == 0xc)))) {
    uVar26 = 9;
  }
  param_1 = *(longlong *)((longlong)&lStackX_18 + lVar12);
  psVar30 = psVar31;
LAB_:
  uVar14 = *(undefined8 *)(psVar30 + 4);
  uVar15 = *(undefined8 *)(param_1 + 0x250);
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100806;
  func_0x(uVar15,uVar14,uVar26);
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1013d3;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar12));
  return;
}

