
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,undefined8 param_2,undefined8 *param_3,undefined8 param_4)

{
  byte *pbVar1;
  byte bVar2;
  undefined2 uVar3;
  short sVar4;
  longlong *plVar5;
  longlong lVar6;
  code **ppcVar7;
  undefined8 uVar8;
  char cVar9;
  longlong lVar10;
  short *psVar11;
  code *UNRECOVERED_JUMPTABLE_00;
  byte **ppbVar12;
  byte *pbVar13;
  ulonglong uVar14;
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar10 = func_0x();
  lVar10 = -lVar10;
  *(ulonglong *)(&stack0x00002400 + lVar10) = _DAT_ ^ (ulonglong)(&stack0x00000050 + lVar10)
  ;
  *(longlong ***)(&stack0x000000e0 + lVar10) = param_1;
  *(undefined8 *)(&stack0x000000a0 + lVar10) = 0;
  *(undefined4 *)(&stack0x0000009c + lVar10) = 0;
  *(undefined8 *)(&stack0x000000b6 + lVar10) = 0;
  *(undefined8 *)(&stack0x000000c0 + lVar10) = 0;
  *(undefined8 *)(&stack0x000000a8 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000358 + lVar10) = 0;
  *(undefined4 *)(&stack0x00000354 + lVar10) = 0;
  *(undefined8 *)(&stack0x0000036e + lVar10) = 0;
  *(undefined8 *)(&stack0x00000378 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000360 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000408 + lVar10) = 0;
  *(undefined4 *)(&stack0x00000404 + lVar10) = 0;
  *(undefined8 *)(&stack0x0000041e + lVar10) = 0;
  *(undefined8 *)(&stack0x00000428 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000410 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000438 + lVar10) = 0;
  *(undefined4 *)(&stack0x00000440 + lVar10) = 0;
  *(undefined8 *)(&stack0x000000f0 + lVar10) = *(undefined8 *)(&stack0x00002490 + lVar10);
  *(undefined2 *)(&stack0x00000098 + lVar10) = 0xffff;
  *(undefined2 *)(&stack0x00000350 + lVar10) = 0xffff;
  *(undefined2 *)(&stack0x00000400 + lVar10) = 0xffff;
  plVar5 = *param_1;
  *(undefined8 *)(&stack0x000001b8 + lVar10) = param_4;
  *(undefined8 **)(&stack0x00000108 + lVar10) = param_3;
  *(undefined8 *)(&stack0x00000148 + lVar10) = param_2;
  lVar6 = *plVar5;
  *(undefined8 *)(&stack0x00000448 + lVar10) = 0;
  *(undefined (*) [16])(&stack0x000001c0 + lVar10) = ZEXT816(0);
  *(undefined4 *)(&stack0x00000450 + lVar10) = 0;
  *(undefined2 *)(&stack0x00000454 + lVar10) = 0;
  ppcVar7 = (code **)*param_3;
  *(undefined8 *)(&stack0x000000d0 + lVar10) = *(undefined8 *)(&stack0x00002488 + lVar10);
  *(longlong *)(&stack0x00000120 + lVar10) = lVar6;
  *(undefined4 *)(&stack0x00000090 + lVar10) = 0;
  *(undefined8 *)(&stack0x000001a8 + lVar10) = 0;
  (&stack0x000000dc)[lVar10] = 0;
  UNRECOVERED_JUMPTABLE_00 = *ppcVar7;
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100135;
  (*UNRECOVERED_JUMPTABLE_00)(param_3);
  *(undefined4 *)(&stack0x00000384 + lVar10) = *(undefined4 *)(&stack0x00002480 + lVar10);
  *(undefined4 *)(&stack0x00000138 + lVar10) = *(undefined4 *)(&stack0x00002480 + lVar10);
  *(undefined4 *)(&stack0x00000118 + lVar10) = 9;
  (&stack0x00000050)[lVar10] = 0;
  if (-1 < *(char *)(lVar6 + 2)) goto LAB_;
  pbVar13 = (byte *)(lVar6 + 0x60);
  if ((*(short *)(&stack0x00000350 + lVar10) == 0) ||
     (ppbVar12 = *(byte ***)(&stack0x00000360 + lVar10), ppbVar12 == (byte **)0x0)) {
    ppbVar12 = (byte **)(&stack0x00000388 + lVar10);
    *(undefined (*) [16])(&stack0x00000398 + lVar10) = ZEXT816(0);
    *(undefined8 *)(&stack0x000003a0 + lVar10) = 0;
    *(undefined8 *)(&stack0x000003f8 + lVar10) = 0;
    *(undefined (*) [16])(&stack0x000003a8 + lVar10) = ZEXT816(0);
    *(undefined2 *)(&stack0x00000398 + lVar10) = 0xffff;
    *(undefined (*) [16])(&stack0x000003b8 + lVar10) = ZEXT816(0);
    *(undefined4 *)(&stack0x0000039c + lVar10) = 0;
    *(undefined (*) [16])(&stack0x000003e8 + lVar10) = ZEXT816(0);
    *(undefined8 *)(&stack0x000003b6 + lVar10) = 0;
    *(undefined (*) [16])(&stack0x000003c8 + lVar10) = ZEXT816(0);
    *(undefined8 *)(&stack0x000003c0 + lVar10) = 0;
    *(undefined (*) [16])(&stack0x000003d8 + lVar10) = ZEXT816(0);
    *(undefined8 *)(&stack0x000003a8 + lVar10) = 0;
    *(undefined (*) [16])(&stack0x00000388 + lVar10) = ZEXT816(0);
    *(undefined8 *)(&stack0x000003d0 + lVar10) = 0;
    *(undefined8 *)(&stack0x000003e8 + lVar10) = 0;
    *(undefined4 *)(&stack0x000003f0 + lVar10) = 0;
    *(undefined2 *)(&stack0x000003fa + lVar10) = 0;
  }
  if (*(short *)(lVar6 + 0x24) == 0) {
LAB_:
    *(undefined8 *)(&stack0x00000150 + lVar10) = *(undefined8 *)(lVar6 + 0x28);
    *(undefined2 *)(&stack0x00000158 + lVar10) = *(undefined2 *)(lVar6 + 0x30);
  }
  else {
    cVar9 = *(char *)(lVar6 + 1);
    if (cVar9 == '\v') {
      if (*(int *)(lVar6 + 0x18) != 99) {
LAB_:
        if (cVar9 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar9 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar6 + 0x18) != 99) goto LAB_;
    }
    *(undefined4 *)(&stack0x00000190 + lVar10) = *(undefined4 *)(lVar6 + 0x20);
    *(undefined2 *)(&stack0x00000194 + lVar10) = *(undefined2 *)(lVar6 + 0x24);
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100272;
    cVar9 = func_0x(&stack0x00000190 + lVar10);
    if (cVar9 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100285;
    func_0x(lVar6,&stack0x00000150 + lVar10);
  }
  *ppbVar12 = pbVar13;
  uVar8 = *(undefined8 *)(&stack0x00000150 + lVar10);
  uVar3 = *(undefined2 *)(&stack0x00000158 + lVar10);
  *(undefined4 *)(ppbVar12 + 0xc) = *(undefined4 *)(&stack0x00000150 + lVar10);
  *(int *)((longlong)ppbVar12 + 100) = (int)((ulonglong)uVar8 >> 0x20);
  *(undefined2 *)(ppbVar12 + 0xd) = uVar3;
  *(undefined4 *)((longlong)ppbVar12 + 0x6c) = *(undefined4 *)(lVar6 + 0x20);
  *(undefined2 *)(ppbVar12 + 0xe) = *(undefined2 *)(lVar6 + 0x24);
  *(undefined2 *)((longlong)ppbVar12 + 0x72) = 0;
  uVar14 = (ulonglong)*(short *)((ulonglong)*pbVar13 * 6 + 0x172ee94);
  *(undefined4 *)(&stack0x00000188 + lVar10) = *(undefined4 *)((ulonglong)*pbVar13 * 6 + 0x172ee90);
  *(undefined2 *)(ppbVar12 + 2) = 0xffff;
  ppbVar12[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar12 + 0x2e) = 0;
  ppbVar12[7] = (byte *)0x0;
  ppbVar12[4] = (byte *)0x0;
  ppbVar12[9] = (byte *)0x0;
  ppbVar12[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar12 + 0xb) = 0;
  if ((**ppbVar12 & 2) != 0) {
    pbVar1 = pbVar13 + uVar14;
    if ((pbVar13[uVar14] & 1) == 0) {
      *(undefined2 *)(ppbVar12 + 2) = 0;
      ppbVar12[3] = pbVar1;
      *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbVar12 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001004fe */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x10812c) - 0xe69f80))();
      return;
    }
    *(undefined2 *)(ppbVar12 + 2) = 1;
    ppbVar12[3] = pbVar1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x10810c) * 4 +
                           0x1080fc) - 0xe69f80);
                    /* WARNING: Could not emulate address calculation at 0x00100361 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbVar12 & 4) != 0) {
    if (*(short *)(&stack0x0000018a + lVar10) != 0) {
      uVar14 = (ulonglong)
               *(ushort *)(lVar6 + 0x61 + (longlong)*(short *)(&stack0x0000018a + lVar10) * 2);
    }
    psVar11 = (short *)(pbVar13 + uVar14);
    ppbVar12[9] = (byte *)psVar11;
    sVar4 = *psVar11;
    ppbVar12[10] = (byte *)(psVar11 + 1);
    *(short *)(ppbVar12 + 0xb) = (sVar4 + 1) * 2;
  }
  pbVar13 = ppbVar12[1];
  if (pbVar13 != (byte *)0x0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1005bc;
    func_0x(pbVar13,ppbVar12);
  }
LAB_:
  pbVar13 = (byte *)((ulonglong)
                     *(ushort *)
                      (*(longlong *)(&stack0x00000120 + lVar10) +
                      (0xfff - (longlong)*(int *)(&stack0x00000138 + lVar10)) * 2) +
                    *(longlong *)(&stack0x00000120 + lVar10));
  bVar2 = *pbVar13;
  *(byte **)(&stack0x00000358 + lVar10) = pbVar13;
  if ((bVar2 & 1) == 0) {
    *(undefined2 *)(&stack0x00000350 + lVar10) = 0;
    *(undefined4 *)(&stack0x00000354 + lVar10) = 0;
    *(undefined4 *)(&stack0x00000376 + lVar10) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001007cc */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar13 & 0xe) * 4 + 0x108198) - 0xe69f80))
              (0xfff - (longlong)*(int *)(&stack0x00000138 + lVar10),(longlong)(int)(*pbVar13 & 0xe)
               ,pbVar13,9);
    return;
  }
  *(undefined2 *)(&stack0x00000350 + lVar10) = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar13 & 0x1c) + 0x108178) * 4 +
                         0x108168) - 0xe69f80);
                    /* WARNING: Could not emulate address calculation at 0x00100624 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

