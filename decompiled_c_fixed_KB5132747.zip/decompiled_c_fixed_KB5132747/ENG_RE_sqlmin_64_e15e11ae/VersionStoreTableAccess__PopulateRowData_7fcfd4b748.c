
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int *param_2,ulonglong *param_3,longlong param_4,
                 undefined4 param_5,uint *param_6,undefined *param_7)

{
  byte *pbVar1;
  ulonglong *puVar2;
  byte *pbVar3;
  byte bVar4;
  undefined2 uVar5;
  ushort *puVar6;
  byte **ppbVar7;
  uint **ppuVar8;
  char cVar9;
  int iVar10;
  int iVar11;
  uint uVar12;
  uint uVar13;
  longlong lVar14;
  byte **ppbVar15;
  uint *puVar16;
  longlong lVar17;
  short *psVar18;
  undefined4 *puVar19;
  undefined8 uVar20;
  ushort uVar21;
  undefined4 uVar22;
  short sVar23;
  short sVar24;
  undefined *puVar25;
  int iVar26;
  uint uVar27;
  ulonglong *puVar28;
  byte **ppbVar29;
  uint uVar31;
  byte *pbVar33;
  ulonglong uVar34;
  ulonglong uVar35;
  int *piVar36;
  ushort *puVar37;
  ulonglong uVar38;
  longlong unaff_GS_OFFSET;
  undefined auStack_5a8 [32];
  undefined8 uStack_588;
  undefined8 uStack_580;
  uint *puStack_578;
  undefined8 uStack_570;
  uint auStack_568 [2];
  byte **ppbStack_560;
  undefined uStack_558;
  uint uStack_554;
  uint uStack_550;
  uint uStack_548;
  ushort uStack_544;
  ushort uStack_542;
  uint *puStack_540;
  undefined4 uStack_538;
  undefined2 uStack_534;
  undefined8 uStack_530;
  undefined4 uStack_528;
  uint uStack_524;
  undefined4 uStack_520;
  uint uStack_51c;
  undefined8 uStack_518;
  ushort uStack_510;
  undefined8 uStack_508;
  ushort uStack_500;
  undefined auStack_4f8 [4];
  undefined4 uStack_4f4;
  int *piStack_4f0;
  undefined4 uStack_4e8;
  undefined2 uStack_4e4;
  undefined4 uStack_4e0;
  undefined2 uStack_4dc;
  undefined4 uStack_4d8;
  undefined2 uStack_4d4;
  undefined8 uStack_4d0;
  undefined2 uStack_4c8;
  undefined8 uStack_4c0;
  undefined2 uStack_4b8;
  ulonglong *puStack_4b0;
  undefined *puStack_4a8;
  undefined8 uStack_4a0;
  undefined2 uStack_498;
  undefined8 uStack_490;
  ushort uStack_488;
  undefined auStack_480 [4];
  undefined auStack_47c [4];
  uint *puStack_478;
  longlong lStack_470;
  undefined auStack_468 [8];
  undefined auStack_460 [4];
  undefined auStack_45c [4];
  uint uStack_458;
  undefined8 uStack_454;
  undefined4 auStack_440 [2];
  undefined8 uStack_438;
  undefined8 uStack_430;
  undefined8 uStack_428;
  undefined8 uStack_420;
  undefined8 uStack_418;
  undefined auStack_408 [8];
  undefined4 uStack_400;
  undefined4 uStack_3f8;
  uint **ppuStack_3f0;
  undefined *puStack_3e8;
  undefined8 uStack_3e0;
  uint *puStack_3d8;
  undefined4 uStack_3d0;
  undefined4 uStack_3cc;
  longlong lStack_3c8;
  undefined4 uStack_3c0;
  undefined4 uStack_3bc;
  longlong lStack_3b8;
  undefined4 uStack_3b0;
  undefined4 uStack_3ac;
  short *psStack_3a8;
  int iStack_3a0;
  undefined4 uStack_39c;
  short *psStack_398;
  int iStack_390;
  undefined4 uStack_38c;
  undefined8 uStack_388;
  undefined4 uStack_380;
  undefined4 uStack_37c;
  undefined auStack_378 [448];
  undefined8 uStack_1b8;
  undefined8 uStack_1b0;
  uint uStack_1a8;
  undefined2 uStack_1a4;
  int iStack_1a2;
  undefined uStack_19e;
  byte bStack_19d;
  short sStack_168;
  ushort uStack_166;
  uint uStack_164;
  byte **ppbStack_160;
  undefined8 uStack_158;
  undefined4 uStack_150;
  ushort uStack_14c;
  undefined2 uStack_14a;
  undefined6 uStack_148;
  undefined2 uStack_142;
  undefined2 uStack_140;
  ushort uStack_13e;
  ushort uStack_13c;
  undefined2 uStack_13a;
  undefined4 uStack_138;
  int iStack_134;
  undefined auStack_130 [16];
  undefined auStack_120 [8];
  undefined8 uStack_118;
  undefined8 uStack_110;
  undefined6 uStack_108;
  undefined2 uStack_102;
  undefined6 uStack_100;
  undefined2 uStack_fa;
  undefined8 uStack_f8;
  undefined auStack_f0 [16];
  undefined auStack_e0 [16];
  undefined auStack_d0 [16];
  undefined8 uStack_c0;
  short asStack_b8 [24];
  short asStack_88 [24];
  ulonglong uStack_58;
  byte **ppbVar30;
  ulonglong uVar32;
  
  uStack_418 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)auStack_5a8;
  puStack_4a8 = param_7;
  puStack_478 = param_6;
  ppbVar30 = (byte **)0x0;
  ppbVar29 = (byte **)0x0;
  ppbStack_560 = (byte **)0x0;
  uStack_558 = 0;
  uStack_554 = 0;
  sStack_168 = -1;
  ppbStack_160 = (byte **)0x0;
  uStack_164 = 0;
  uStack_14a = 0;
  uStack_148 = 0;
  uStack_140 = 0;
  uStack_13e = 0;
  uStack_13c = 0;
  uStack_13a = 0;
  uStack_158 = (byte **)0x0;
  iStack_134 = -1;
  auStack_568[0] = 0;
  lVar17 = *(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x10) + 0x60) + 0x30);
  uVar31 = 0;
  piStack_4f0 = param_2;
  puStack_4b0 = param_3;
  lStack_470 = param_4;
  if (((*(short *)(param_6 + 2) != 0) || (*param_6 != 0)) || (param_6[1] != 0)) {
    if (param_7 == (undefined *)0x0) {
      uStack_588 = (uint *)0x0;
      (*_DAT_)(1,0x1116d68,0x10cf8c8,0x13c8);
    }
    lVar14 = func_0x(*(undefined8 *)(lVar17 + 0x6a0));
    iVar11 = *param_2;
    uVar5 = *(undefined2 *)(lVar14 + 0x5f0);
    iVar26 = 0x3c;
    do {
      uStack_570 = 0;
      puStack_578 = (uint *)0x0;
      uStack_580 = (uint *)CONCAT44(uStack_580._4_4_,10000);
      uStack_588 = param_6;
      iVar10 = func_0x(lVar17,uVar5,iVar11,1);
      if (-1 < iVar10) goto LAB_;
      auStack_440[0] = 0x400060;
      uStack_438 = 0;
      uStack_428 = 0;
      uStack_430 = 0;
      uStack_420 = 0;
      func_0x(100,auStack_440);
      iVar26 = iVar26 + -1;
      puVar25 = puStack_4a8;
    } while (iVar26 != 0);
LAB_:
    *puVar25 = 1;
code_r0x00101fdd:
    func_0x(&ppbStack_560);
    func_0x(uStack_58 ^ (ulonglong)auStack_5a8);
    return;
  }
LAB_:
  uStack_454 = 0;
  ppbVar15 = ppbVar30;
  if ((((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) &&
      ((lVar14 = *(longlong *)
                  ((ulonglong)*_DAT_ +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
       lVar14 == 0 ||
       ((lVar14 = **(longlong **)(lVar14 + 0x38), lVar14 == 0 ||
        (iVar11 = (*_DAT_)(lVar14,0x337), iVar11 == 0)))))) &&
     (lVar14 = *(longlong *)
                ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8),
     lVar14 != 0)) {
    ppbVar15 = *(byte ***)(lVar14 + 0x60);
  }
  lVar14 = *(longlong *)(lVar17 + 0x728);
  uStack_520 = 2;
  do {
    ppbVar7 = ppbStack_560;
    uStack_524 = 0;
    if (ppbStack_560 != (byte **)0x0) {
      iVar11 = (int)(short)uStack_554;
      if (((*(ushort *)((longlong)ppbStack_560 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
        if (((byte)*(undefined2 *)((longlong)ppbStack_560 + 0x62) >> 3 & 1) != 0) {
          if (iVar11 == 3) {
            iVar11 = 4;
          }
          else if (iVar11 < 2) goto LAB_;
          if ((((*(uint *)((longlong)ppbStack_560 + 100) & 8) != 0) &&
              (pbVar33 = ppbStack_560[0x12], pbVar33 != (byte *)0x0)) &&
             (*(longlong *)(pbVar33 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(pbVar33 + 0x758),ppbStack_560,iVar11);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)ppbVar7 + 100) & 8) != 0)) &&
            ((2 < iVar11 &&
             (((*(uint *)((longlong)ppbVar7 + 100) & 0xc0000000) != 0x40000000 &&
              (*ppbVar7 != (byte *)0x0)))))) &&
           (iVar26 = (*_DAT_)(*ppbVar7,0x2000,2,auStack_460), iVar26 != 0)) {
          LOCK();
          *(uint *)((longlong)ppbVar7 + 100) = *(uint *)((longlong)ppbVar7 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)ppbVar7 + 100) = *(uint *)((longlong)ppbVar7 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(ppbVar7 + 0x13,iVar11);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(ppbVar7,0,iVar11);
        }
        uStack_554 = uStack_554 & 0xffff0000;
        ppbStack_560 = (byte **)0x0;
      }
      else {
        func_0x(&ppbStack_560);
      }
    }
    piVar36 = piStack_4f0;
    if ((*(longlong *)(lVar17 + 0x728) != 0) &&
       (func_0x(&ppbStack_560,piStack_4f0,lVar17), ppbVar7 = ppbStack_560,
       ppbStack_560 != (byte **)0x0)) {
      iVar11 = (int)(short)uStack_554;
      if (((*(ushort *)((longlong)ppbStack_560 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
        if (((byte)*(undefined2 *)((longlong)ppbStack_560 + 0x62) >> 3 & 1) != 0) {
          if (iVar11 == 3) {
            iVar11 = 4;
          }
          else if (iVar11 < 2) goto LAB_;
          if ((((*(uint *)((longlong)ppbStack_560 + 100) & 8) != 0) &&
              (pbVar33 = ppbStack_560[0x12], pbVar33 != (byte *)0x0)) &&
             (*(longlong *)(pbVar33 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(pbVar33 + 0x758),ppbStack_560,iVar11);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)ppbVar7 + 100) & 8) != 0)) &&
            ((2 < iVar11 &&
             (((*(uint *)((longlong)ppbVar7 + 100) & 0xc0000000) != 0x40000000 &&
              (*ppbVar7 != (byte *)0x0)))))) &&
           (iVar26 = (*_DAT_)(*ppbVar7,0x2000,2,auStack_45c), iVar26 != 0)) {
          LOCK();
          *(uint *)((longlong)ppbVar7 + 100) = *(uint *)((longlong)ppbVar7 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)ppbVar7 + 100) = *(uint *)((longlong)ppbVar7 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(ppbVar7 + 0x13,iVar11);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(ppbVar7,0,iVar11);
        }
        uStack_554 = uStack_554 & 0xffff0000;
        ppbStack_560 = (byte **)0x0;
        piVar36 = piStack_4f0;
      }
      else {
        func_0x(&ppbStack_560);
      }
    }
    uStack_580 = &uStack_458;
    uStack_588 = (uint *)CONCAT44(uStack_588._4_4_,2);
    ppbStack_560 = (byte **)func_0x(_DAT_,lVar17,piVar36,&uStack_524);
    if (ppbVar15 != (byte **)0x0) {
      if (ppbVar15[(ulonglong)(*(uint *)(ppbVar15 + 0xa0) & 0xf) + 0xa1] != *ppbStack_560) {
        ppbVar15[(ulonglong)(*(uint *)(ppbVar15 + 0xa0) & 0xf) + 0xa1] = *ppbStack_560;
        ppbVar15[0xa0] = ppbVar15[0xa0] + 1;
      }
    }
    uStack_554 = (uStack_524 >> 3 & 1) << 0x18 | uStack_554 & 0xff0002 | 2;
    uStack_550 = uStack_524 >> 4 & 1 | uStack_550 & 0xffffff00;
    if (((lVar14 != 0) && (ppbVar15 != (byte **)0x0)) && (ppbVar15 == *(byte ***)(lVar17 + 0x1c38)))
    {
      *(longlong *)(lVar14 + 0x5b28) = *(longlong *)(lVar14 + 0x5b28) + 1;
      if ((int)uStack_454 != 0) {
        *(longlong *)(lVar14 + 0x5b30) = *(longlong *)(lVar14 + 0x5b30) + 1;
        *(longlong *)(lVar14 + 0x5b38) = *(longlong *)(lVar14 + 0x5b38) + (ulonglong)uStack_458;
        if (0xffffff < uStack_554) {
          *(longlong *)(lVar14 + 0x5b40) = *(longlong *)(lVar14 + 0x5b40) + 1;
          *(longlong *)(lVar14 + 0x5b48) = *(longlong *)(lVar14 + 0x5b48) + (ulonglong)uStack_458;
        }
      }
    }
    cVar9 = func_0x(lVar17);
    if (((cVar9 == '\0') || (*(char *)(lVar17 + 0x2050) == '\0')) ||
       ((*piVar36 == 0 || ((*piVar36 == 9 && (*(short *)(piVar36 + 1) == 1)))))) goto LAB_;
    pbVar33 = *ppbStack_560;
    if (*(short *)(pbVar33 + 0x24) == 0) {
LAB_:
      uStack_508 = *(undefined8 *)(pbVar33 + 0x28);
      uStack_500 = *(ushort *)(pbVar33 + 0x30);
    }
    else {
      bVar4 = pbVar33[1];
      if (bVar4 == 0xb) {
        if (*(int *)(pbVar33 + 0x18) != 99) {
LAB_:
          if (bVar4 != 9) goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (bVar4 != 8) goto LAB_;
LAB_:
        if (*(int *)(pbVar33 + 0x18) != 99) goto LAB_;
      }
      uStack_4e8 = *(undefined4 *)(pbVar33 + 0x20);
      uStack_4e4 = *(undefined2 *)(pbVar33 + 0x24);
      cVar9 = func_0x(&uStack_4e8);
      if (cVar9 == '\0') goto LAB_;
      func_0x(pbVar33,&uStack_508);
    }
    uVar13 = *(uint *)(lVar17 + 0x2108);
    do {
      uVar12 = uVar13 & 0xfffffffe;
      uStack_530 = *(undefined8 *)(lVar17 + 0x20fc);
      uStack_528 = *(undefined4 *)(lVar17 + 0x2104);
      LOCK();
      UNLOCK();
      uVar13 = *(uint *)(lVar17 + 0x2108);
    } while (uVar12 != uVar13);
    if ((uint)uStack_508 <= (uint)uStack_530) {
      if ((uint)uStack_530 != (uint)uStack_508) goto LAB_;
      uVar13 = (uint)((ulonglong)uStack_530 >> 0x20);
      if ((uStack_508._4_4_ <= uVar13) &&
         ((uVar13 != uStack_508._4_4_ || (uStack_500 <= (ushort)uStack_528)))) goto LAB_;
    }
    if ((*(char *)(lVar17 + 0x6ac8) == '\0') &&
       ((*(longlong *)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            8) + 0x60) != *(longlong *)(lVar17 + 0x2120) &&
        (cVar9 = func_0x(lVar17), cVar9 == '\0')))) break;
    if ((*(longlong *)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            8) + 0x60) == *(longlong *)(lVar17 + 0x2120)) ||
       (cVar9 = func_0x(lVar17), cVar9 != '\0')) goto LAB_;
    if (ppbVar15 == (byte **)0x0) {
      ppbVar15 = (byte **)func_0x();
    }
    pbVar33 = *ppbStack_560;
    if (*(short *)(pbVar33 + 0x24) == 0) {
LAB_:
      uStack_4d0 = *(undefined8 *)(pbVar33 + 0x28);
      uStack_4c8 = *(undefined2 *)(pbVar33 + 0x30);
    }
    else {
      bVar4 = pbVar33[1];
      if (bVar4 == 0xb) {
        if (*(int *)(pbVar33 + 0x18) != 99) {
LAB_:
          if (bVar4 != 9) goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (bVar4 != 8) goto LAB_;
LAB_:
        if (*(int *)(pbVar33 + 0x18) != 99) goto LAB_;
      }
      uStack_4e0 = *(undefined4 *)(pbVar33 + 0x20);
      uStack_4dc = *(undefined2 *)(pbVar33 + 0x24);
      cVar9 = func_0x(&uStack_4e0);
      if (cVar9 == '\0') goto LAB_;
      func_0x(pbVar33,&uStack_4d0);
    }
    ppbVar7 = ppbStack_560;
    if (ppbStack_560 != (byte **)0x0) {
      iVar11 = (int)(short)uStack_554;
      if (((*(ushort *)((longlong)ppbStack_560 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
        if (((byte)*(undefined2 *)((longlong)ppbStack_560 + 0x62) >> 3 & 1) != 0) {
          if (iVar11 == 3) {
            iVar11 = 4;
          }
          else if (iVar11 < 2) goto LAB_;
          if ((((*(uint *)((longlong)ppbStack_560 + 100) & 8) != 0) &&
              (pbVar33 = ppbStack_560[0x12], pbVar33 != (byte *)0x0)) &&
             (*(longlong *)(pbVar33 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(pbVar33 + 0x758),ppbStack_560,iVar11);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)ppbVar7 + 100) & 8) != 0)) &&
            ((2 < iVar11 &&
             (((*(uint *)((longlong)ppbVar7 + 100) & 0xc0000000) != 0x40000000 &&
              (*ppbVar7 != (byte *)0x0)))))) &&
           (iVar26 = (*_DAT_)(*ppbVar7,0x2000,2,auStack_480), iVar26 != 0)) {
          LOCK();
          *(uint *)((longlong)ppbVar7 + 100) = *(uint *)((longlong)ppbVar7 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)ppbVar7 + 100) = *(uint *)((longlong)ppbVar7 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(ppbVar7 + 0x13,iVar11);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(ppbVar7,0,iVar11);
        }
        uStack_554 = uStack_554 & 0xffff0000;
        ppbStack_560 = (byte **)0x0;
      }
      else {
        func_0x(&ppbStack_560);
      }
    }
    uStack_4a0 = uStack_4d0;
    uStack_498 = uStack_4c8;
    uStack_588 = (uint *)0x0;
    func_0x(*(undefined8 *)(lVar17 + 0x728),&uStack_4a0,4);
  } while( true );
  uVar13 = *(uint *)(lVar17 + 0x2108);
  do {
    uVar12 = uVar13 & 0xfffffffe;
    uStack_530 = *(undefined8 *)(lVar17 + 0x20fc);
    uStack_528 = *(undefined4 *)(lVar17 + 0x2104);
    LOCK();
    UNLOCK();
    uVar13 = *(uint *)(lVar17 + 0x2108);
  } while (uVar12 != uVar13);
  uVar21 = (ushort)uStack_528;
  uStack_488 = (ushort)uStack_528;
  pbVar33 = *ppbStack_560;
  uStack_490 = uStack_530;
  if (*(short *)(pbVar33 + 0x24) == 0) {
LAB_:
    uStack_518 = *(undefined8 *)(pbVar33 + 0x28);
    uStack_510 = *(ushort *)(pbVar33 + 0x30);
  }
  else {
    bVar4 = pbVar33[1];
    if (bVar4 == 0xb) {
      if (*(int *)(pbVar33 + 0x18) != 99) {
LAB_:
        if (bVar4 != 9) goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (bVar4 != 8) goto LAB_;
LAB_:
      if (*(int *)(pbVar33 + 0x18) != 99) goto LAB_;
    }
    uStack_4d8 = *(undefined4 *)(pbVar33 + 0x20);
    uStack_4d4 = *(undefined2 *)(pbVar33 + 0x24);
    cVar9 = func_0x(&uStack_4d8);
    if (cVar9 == '\0') goto LAB_;
    func_0x(pbVar33,&uStack_518);
  }
  if ((uint)uStack_530 < (uint)uStack_518) {
LAB_:
    lVar14 = *(longlong *)(lVar17 + 0x6b0);
    func_0x(&uStack_518,asStack_b8,auStack_4f8);
    func_0x(&uStack_490,asStack_88,auStack_4f8);
    if ((_DAT_ & 0x10000) != 0) {
      uStack_400 = 0x60000;
      uStack_3f8 = 0;
      ppuStack_3f0 = &puStack_3d8;
      puStack_3e8 = auStack_378;
      uStack_1b8 = 0;
      uStack_3e0 = 0;
      uStack_1b0 = 0;
      puStack_3d8 = &uStack_1a8;
      uStack_3d0 = 0x34;
      uStack_3cc = 5;
      uStack_3c0 = 0x10;
      uStack_3bc = 5;
      uStack_3b0 = 0x10;
      uStack_3ac = 6;
      uStack_39c = 7;
      uStack_38c = 8;
      uStack_388 = 0;
      uStack_380 = 0;
      uStack_37c = 9;
      uStack_1a8 = (uint)*(ushort *)(lVar17 + 0x6b8);
      uStack_1a4 = *(undefined2 *)(piVar36 + 1);
      iStack_1a2 = *piVar36;
      uStack_19e = 1;
      bStack_19d = (*ppbStack_560)[1];
      lStack_3c8 = lVar14 + 0x254;
      lStack_3b8 = lVar14 + 0x244;
      lVar17 = -1;
      do {
        lVar17 = lVar17 + 1;
      } while (asStack_b8[lVar17] != 0);
      iStack_3a0 = (int)lVar17 * 2;
      psStack_3a8 = asStack_b8;
      lVar17 = -1;
      do {
        lVar17 = lVar17 + 1;
      } while (asStack_88[lVar17] != 0);
      iStack_390 = (int)lVar17 * 2;
      psStack_398 = asStack_88;
      uStack_4f4 = 0;
      puVar16 = (uint *)(**(code **)(_DAT_ + 0x10))(lVar14,&uStack_4f4);
      ppuVar8 = ppuStack_3f0;
      uVar13 = uVar31;
      if (puVar16 != (uint *)0x0) {
        lVar17 = -1;
        do {
          lVar17 = lVar17 + 1;
        } while (*(short *)((longlong)puVar16 + lVar17 * 2) != 0);
        uVar13 = (int)lVar17 * 2;
      }
      ppuStack_3f0[10] = puVar16;
      *(uint *)(ppuVar8 + 0xb) = uVar13;
      *(undefined4 *)((longlong)ppuVar8 + 0x5c) = 9;
      func_0x(auStack_408);
    }
  }
  else if ((uint)uStack_530 == (uint)uStack_518) {
    uVar13 = (uint)((ulonglong)uStack_518 >> 0x20);
    if ((uStack_530._4_4_ < uVar13) || ((uStack_530._4_4_ == uVar13 && (uVar21 < uStack_510))))
    goto LAB_;
  }
LAB_:
  uVar35 = 8;
  if ((1 < (short)uStack_554) && ((*ppbStack_560)[1] != 1)) {
    if (ppbVar15 != (byte **)0x0) {
      ppbVar15[0xb1] = *ppbStack_560;
    }
    lVar17 = func_0x();
    if ((lVar17 != 0) && (lVar17 = func_0x(), *(longlong *)(lVar17 + 0x30) != 0)) {
      lVar17 = func_0x();
      uVar13 = *(uint *)(*(longlong *)(lVar17 + 0x30) + 0xc);
      if ((uVar13 < 0xe) && ((0x2640U >> (uVar13 & 0x1f) & 1) != 0)) goto LAB_;
    }
    func_0x(0,uVar35 & 0xffffffff);
  }
LAB_:
  pbVar33 = *ppbStack_560;
  if ((pbVar33[1] != 1) ||
     (sVar24 = *(short *)((longlong)piVar36 + 6),
     (int)(*(ushort *)(pbVar33 + 0x16) - 1) < (int)sVar24)) {
    cVar9 = func_0x();
    if ((cVar9 != '\0') && (DAT_ == '\0')) {
      (*_DAT_)(0xdc,0x11,0x11,2);
    }
    puVar25 = puStack_4a8;
    if (((*(short *)(puStack_478 + 2) == 0) && (*puStack_478 == 0)) && (puStack_478[1] == 0)) {
      uStack_588 = (uint *)0x1116df8;
      (*_DAT_)(1,0x10d3568,0x10cf8c8,0x13fb);
      sVar24 = *(short *)((longlong)piVar36 + 6);
      goto LAB_;
    }
    if (puStack_4a8 == (undefined *)0x0) {
      uStack_588 = (uint *)0x0;
      (*_DAT_)(1,0x1116d68,0x10cf8c8,0x13f5);
    }
    goto LAB_;
  }
LAB_:
  iStack_134 = (int)sVar24;
  ppbVar15 = ppbVar30;
  if ((char)pbVar33[2] < '\0') {
    pbVar1 = pbVar33 + 0x60;
    if ((sStack_168 == 0) || (ppbVar15 = uStack_158, uStack_158 == (byte **)0x0)) {
      uStack_108 = 0;
      uStack_fa = 0;
      auStack_e0 = ZEXT816(0);
      auStack_130 = ZEXT816(0);
      stack0xfffffffffffffee2 = SUB1614(ZEXT816(0),2);
      auStack_120._0_2_ = 0xffff;
      uStack_118 = 0;
      uStack_102 = 0;
      uStack_100 = 0;
      uStack_f8 = 0;
      uStack_110 = 0;
      auStack_f0 = ZEXT816(0);
      auStack_d0._0_12_ = ZEXT812(0);
      auStack_d0._12_4_ = 0;
      uStack_c0 = 0;
      ppbVar15 = (byte **)auStack_130;
    }
    if (*(short *)(pbVar33 + 0x24) == 0) {
LAB_:
      uStack_4c0 = *(undefined8 *)(pbVar33 + 0x28);
      uStack_4b8 = *(undefined2 *)(pbVar33 + 0x30);
    }
    else {
      bVar4 = pbVar33[1];
      if (bVar4 == 0xb) {
        if (*(int *)(pbVar33 + 0x18) != 99) {
LAB_:
          if (bVar4 != 9) goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (bVar4 != 8) goto LAB_;
LAB_:
        if (*(int *)(pbVar33 + 0x18) != 99) goto LAB_;
      }
      uStack_538 = *(undefined4 *)(pbVar33 + 0x20);
      uStack_534 = *(undefined2 *)(pbVar33 + 0x24);
      cVar9 = func_0x(&uStack_538,0xcc4130,0xcc4130);
      if (cVar9 == '\0') goto LAB_;
      func_0x(pbVar33,&uStack_4c0);
    }
    *ppbVar15 = pbVar1;
    *(undefined4 *)(ppbVar15 + 0xc) = (undefined4)uStack_4c0;
    *(int *)((longlong)ppbVar15 + 100) = (int)((ulonglong)uStack_4c0 >> 0x20);
    *(undefined2 *)(ppbVar15 + 0xd) = uStack_4b8;
    *(undefined4 *)((longlong)ppbVar15 + 0x6c) = *(undefined4 *)(pbVar33 + 0x20);
    *(undefined2 *)(ppbVar15 + 0xe) = *(undefined2 *)(pbVar33 + 0x24);
    *(undefined2 *)((longlong)ppbVar15 + 0x72) = 0;
    uStack_538 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0xd42a10);
    uVar35 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0xd42a14);
    *(undefined2 *)(ppbVar15 + 2) = 0xffff;
    ppbVar15[3] = (byte *)0x0;
    *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar15 + 0x2e) = 0;
    ppbVar15[7] = (byte *)0x0;
    ppbVar15[4] = (byte *)0x0;
    ppbVar15[9] = (byte *)0x0;
    ppbVar15[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar15 + 0xb) = 0;
    if ((**ppbVar15 & 2) != 0) {
      pbVar3 = pbVar1 + uVar35;
      if ((*pbVar3 & 1) == 0) {
        *(undefined2 *)(ppbVar15 + 2) = 0;
        ppbVar15[3] = pbVar3;
        *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar15 + 0x36) = 0;
        uVar13 = uVar31;
        switch(*pbVar3 & 0xe) {
        default:
          uVar13 = (uint)*(ushort *)(pbVar3 + 2);
          if (0x1f9d < *(ushort *)(pbVar3 + 2) - 1) {
            func_0x(pbVar3,6);
          }
          break;
        case 4:
          uVar13 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar13 = 1;
        }
        *(uint *)(ppbVar15 + 4) = uVar13;
        *(undefined8 *)((longlong)ppbVar15 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar15 + 2) = 1;
        ppbVar15[3] = pbVar3;
        bVar4 = *pbVar3;
        switch(bVar4 & 0x1c) {
        default:
          if ((char)pbVar3[1] < '\0') {
            uVar21 = *(ushort *)(pbVar3 + 1);
            *(ushort *)((longlong)ppbVar15 + 0x12) = uVar21;
            sVar23 = 3;
            uVar21 = (uVar21 & 0x7f) << 8 | uVar21 >> 8;
          }
          else {
            sVar23 = 2;
            uVar21 = (ushort)pbVar3[1];
          }
          *(ushort *)((longlong)ppbVar15 + 0x12) = uVar21;
          *(short *)(ppbVar15 + 5) = sVar23;
          uVar21 = *(ushort *)((longlong)ppbVar15 + 0x12);
          *(short *)((longlong)ppbVar15 + 0x2c) = (short)(uVar21 + 1 >> 1) + sVar23;
          if (uVar21 < 0x1f) {
            *(undefined2 *)((longlong)ppbVar15 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0;
            *(undefined4 *)(ppbVar15 + 8) = 0;
            ppbVar15[7] = (byte *)0x0;
            ppbVar15[4] = (byte *)0x0;
          }
          else {
            iVar11 = uVar21 - 1;
            *(short *)((longlong)ppbVar15 + 0x2a) =
                 ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                 (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar15 + 0x14) = 0;
            *(undefined4 *)(ppbVar15 + 8) = 0;
            ppbVar15[7] = (byte *)0x0;
            ppbVar15[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar4 & 0x1c) != 4) || (uVar13 = 1, (bVar4 & 2) == 0)) {
            uVar13 = uVar31;
          }
          if (uVar13 == 0) {
            uVar22 = 1;
          }
          else {
            *(undefined4 *)(ppbVar15 + 8) = 0;
            uVar22 = 0xf;
          }
          ppbVar15[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar15 + 0x12) = 0;
          ppbVar15[6] = (byte *)0x0;
          ppbVar15[4] = (byte *)0x0;
          ppbVar15[7] = (byte *)0x0;
          ppbVar15[3] = pbVar3;
          *(undefined4 *)((longlong)ppbVar15 + 0x14) = uVar22;
          *(uint *)(ppbVar15 + 8) = (uint)(uVar13 != 0);
          ppbVar15[7] = (byte *)0x0;
          ppbVar15[4] = (byte *)0x0;
          break;
        case 8:
          ppbVar15[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar15 + 0x12) = 0;
          ppbVar15[6] = (byte *)0x0;
          ppbVar15[4] = (byte *)0x0;
          ppbVar15[7] = (byte *)0x0;
          ppbVar15[3] = pbVar3;
          *(undefined4 *)((longlong)ppbVar15 + 0x14) = 9;
          *(undefined4 *)(ppbVar15 + 8) = 0;
          ppbVar15[7] = (byte *)0x0;
          ppbVar15[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar15 & 4) != 0) {
      if (uStack_538._2_2_ != 0) {
        uVar35 = (ulonglong)*(ushort *)(pbVar33 + (longlong)uStack_538._2_2_ * 2 + 0x61);
      }
      psVar18 = (short *)(pbVar1 + uVar35);
      ppbVar15[9] = (byte *)psVar18;
      sVar23 = *psVar18;
      ppbVar15[10] = (byte *)(psVar18 + 1);
      *(short *)(ppbVar15 + 0xb) = (sVar23 + 1) * 2;
    }
    if (ppbVar15[1] != (byte *)0x0) {
      func_0x(ppbVar15[1],ppbVar15);
    }
  }
  uVar13 = 1;
  ppbStack_160 = (byte **)(pbVar33 + *(ushort *)(pbVar33 + (0xfff - (longlong)sVar24) * 2));
  if ((*(byte *)ppbStack_160 & 1) == 0) {
    sStack_168 = 0;
    uStack_164 = 0;
    uStack_142 = 0;
    uStack_140 = 0;
    uVar12 = (uint)*(ushort *)(pbVar33 + 0xe);
    switch(*(byte *)ppbStack_160 & 0xe) {
    default:
      uVar12 = (uint)*(ushort *)((longlong)ppbStack_160 + 2);
      if (0x1f9d < *(ushort *)((longlong)ppbStack_160 + 2) - 1) {
        func_0x(ppbStack_160,6);
      }
      break;
    case 4:
      uVar12 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar12 = uVar13;
    }
    uStack_158 = (byte **)CONCAT44(uStack_158._4_4_,uVar12);
    uStack_14a = SUB82(pbVar33 + 0x2000,0);
    uStack_148 = (undefined6)((ulonglong)(pbVar33 + 0x2000) >> 0x10);
  }
  else {
    sStack_168 = 1;
    bVar4 = *(byte *)ppbStack_160;
    switch(bVar4 & 0x1c) {
    default:
      if ((char)*(byte *)((longlong)ppbStack_160 + 1) < '\0') {
        uStack_166 = (*(ushort *)((longlong)ppbStack_160 + 1) & 0x7f) << 8 |
                     *(ushort *)((longlong)ppbStack_160 + 1) >> 8;
        uStack_150._0_2_ = 3;
        uStack_520 = CONCAT22(uStack_520._2_2_,3);
      }
      else {
        uStack_166 = (ushort)*(byte *)((longlong)ppbStack_160 + 1);
        uStack_150._0_2_ = 2;
      }
      uStack_14c = (short)(uStack_166 + 1 >> 1) + (short)uStack_520;
      if (uStack_166 < 0x1f) {
        uStack_150._2_2_ = 0;
        uStack_164 = 0;
        uStack_138 = 0;
      }
      else {
        iVar11 = uStack_166 - 1;
        uStack_150._2_2_ =
             ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
             (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
        uStack_164 = 0;
        uStack_138 = 0;
      }
      break;
    case 4:
      if (((bVar4 & 0x1c) == 4) && ((bVar4 & 2) != 0)) {
        uStack_150._0_2_ = 0;
        uStack_150._2_2_ = 0;
        uStack_14c = 0;
        uStack_14a = 0;
        uStack_166 = 0;
        uStack_148 = 0;
        uStack_142 = 0;
        uStack_164 = 0xf;
        uStack_138 = 1;
      }
      else {
        uStack_150._0_2_ = 0;
        uStack_150._2_2_ = 0;
        uStack_14c = 0;
        uStack_14a = 0;
        uStack_166 = 0;
        uStack_148 = 0;
        uStack_142 = 0;
        uStack_164 = 1;
        uStack_138 = 0;
      }
      break;
    case 8:
      uStack_150._0_2_ = 0;
      uStack_150._2_2_ = 0;
      uStack_14c = 0;
      uStack_14a = 0;
      uStack_166 = 0;
      uStack_148 = 0;
      uStack_142 = 0;
      uStack_164 = 9;
      uStack_138 = 0;
    }
    pbVar33 = pbVar33 + 0x2000;
    uStack_140 = SUB82(pbVar33,0);
    uStack_13e = (ushort)((ulonglong)pbVar33 >> 0x10);
    uStack_13c = (ushort)((ulonglong)pbVar33 >> 0x20);
    uStack_13a = (undefined2)((ulonglong)pbVar33 >> 0x30);
    uStack_158 = ppbVar15;
  }
  ppbVar15 = ppbStack_160;
  puVar28 = puStack_4b0;
  func_0x(puStack_4b0 + 2,0x28,(longlong)ppbStack_160 + 4);
  puVar2 = puVar28 + 7;
  if (puVar2 == (ulonglong *)0x0) {
code_r0x00101438:
    puVar19 = (undefined4 *)(*pcRam0000000000bc70e0)();
    *puVar19 = 0x16;
    (*pcRam0000000000bc70f8)();
  }
  else {
    if ((undefined2 *)((longlong)ppbVar15 + 0x2c) == (undefined2 *)0x0) {
      *(undefined2 *)puVar2 = 0;
      goto code_r0x00101438;
    }
    *(undefined2 *)puVar2 = *(undefined2 *)((longlong)ppbVar15 + 0x2c);
  }
  puVar2 = puVar28 + 8;
  if (puVar2 == (ulonglong *)0x0) {
code_r0x00101469:
    puVar19 = (undefined4 *)(*pcRam0000000000bc70e0)();
    *puVar19 = 0x16;
    (*pcRam0000000000bc70f8)();
  }
  else {
    if ((ulonglong *)((longlong)ppbVar15 + 0x2e) == (ulonglong *)0x0) {
      *puVar2 = 0;
      goto code_r0x00101469;
    }
    *puVar2 = *(ulonglong *)((longlong)ppbVar15 + 0x2e);
  }
  puVar2 = puVar28 + 9;
  if (puVar2 == (ulonglong *)0x0) {
code_r0x00101498:
    puVar19 = (undefined4 *)(*pcRam0000000000bc70e0)();
    *puVar19 = 0x16;
    (*pcRam0000000000bc70f8)();
  }
  else {
    if ((ulonglong *)((longlong)ppbVar15 + 0x36) == (ulonglong *)0x0) {
      *puVar2 = 0;
      goto code_r0x00101498;
    }
    *puVar2 = *(ulonglong *)((longlong)ppbVar15 + 0x36);
  }
  lVar17 = lStack_470;
  if (lStack_470 == 0) goto code_r0x00101fdd;
  uStack_588 = (uint *)((ulonglong)uStack_588 & 0xffffffff00000000);
  func_0x(&uStack_548,0xffffffff,1);
  if (sStack_168 == 0) {
    if ((uStack_548 & 0xc0000000) == 0x80000000) {
      iVar11 = func_0x(&uStack_166);
      if (iVar11 != 0) {
        ppbVar29 = (byte **)func_0x(&uStack_13e,&uStack_548,auStack_568,auStack_47c);
        goto code_r0x00101f8d;
      }
      auStack_568[0] = 0;
    }
    else {
      bVar4 = *(byte *)ppbStack_160;
      uVar35 = (ulonglong)uStack_158 & 0xffffffff;
      puVar28 = puStack_4b0;
      if ((bVar4 & 0x10) == 0) {
        if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
          uVar21 = ~(uStack_542 >> 4);
          uVar13 = uVar31;
          goto code_r0x0010157f;
        }
code_r0x001015ba:
        if ((int)uStack_548 < 0) {
          ppbVar29 = ppbStack_160;
          uVar31 = uStack_164;
          if (uStack_164 == 0) {
            uStack_166 = 0;
            uVar32 = uVar35;
            uVar31 = (uint)uStack_158;
            if ((*(byte *)ppbStack_160 & 0x10) != 0) {
              uVar31 = (uint)uStack_158 + 2 +
                       (*(ushort *)((longlong)ppbStack_160 + uVar35) + 7 >> 3);
              uVar32 = (ulonglong)uVar31;
            }
            uStack_158 = (byte **)CONCAT44(uVar31,(uint)uStack_158);
            uVar13 = (uint)uVar32;
            if ((*(byte *)ppbStack_160 & 0x20) != 0) {
              puVar37 = (ushort *)(uVar32 + (longlong)ppbStack_160);
              uStack_14c = *puVar37;
              if (uStack_14c == 0) {
                cVar9 = func_0x(0x16591c0);
                if ((cVar9 != '\0') && (cVar9 = func_0x(), cVar9 != '\0')) {
                  cVar9 = func_0x(0x16591c0);
                  if (cVar9 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    uStack_588 = (uint *)0x0;
                    (*_DAT_)(1,0xf48bcc,0x1068cb8,0x80f);
                  }
                }
                func_0x(ppbStack_160,3);
              }
              uStack_150 = uStack_158._4_4_ + (uStack_14c + 1) * 2;
              if (0x1f9e < uStack_150) {
                cVar9 = func_0x(0x16591c0);
                if (cVar9 != '\0') {
                  cVar9 = func_0x();
                  if (cVar9 != '\0') {
                    cVar9 = func_0x(0x16591c0);
                    if (cVar9 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_588 = (uint *)0x0;
                      (*_DAT_)(1,0xf48bcc,0x1068cb8,0x816);
                    }
                  }
                }
                func_0x(ppbStack_160,4);
              }
              uStack_164 = puVar37[uStack_14c] & 0x7fff;
              if (uStack_164 < uStack_150) {
                cVar9 = func_0x(0x16591c0);
                if (cVar9 != '\0') {
                  cVar9 = func_0x();
                  if (cVar9 != '\0') {
                    cVar9 = func_0x(0x16591c0);
                    if (cVar9 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_588 = (uint *)0x0;
                      (*_DAT_)(1,0xf48bcc,0x1068cb8,0x81d);
                    }
                  }
                }
                func_0x(ppbStack_160,4);
              }
              uVar32 = (ulonglong)uStack_164;
              ppbVar29 = ppbStack_160;
              ppbVar15 = ppbVar30;
              puVar6 = puVar37;
              uVar13 = uStack_150;
              if (uStack_14c != 0) {
                do {
                  uVar31 = puVar6[1] & 0x7fff;
                  if ((uVar31 < uStack_150) || ((uint)uVar32 < uVar31)) {
                    uStack_150 = uVar13;
                    cVar9 = func_0x(0x16591c0);
                    if (cVar9 != '\0') {
                      cVar9 = func_0x();
                      if (cVar9 != '\0') {
                        cVar9 = func_0x(0x16591c0);
                        if (cVar9 == '\0') {
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_588 = (uint *)0x0;
                          (*_DAT_)(1,0xf48bcc,0x1068cb8,0x82a);
                        }
                      }
                    }
                    func_0x(ppbStack_160,4);
                    uVar32 = (ulonglong)uStack_164;
                    ppbVar29 = ppbStack_160;
                    uVar13 = uStack_150;
                  }
                  uVar12 = (int)ppbVar15 + 1;
                  ppbVar15 = (byte **)(ulonglong)uVar12;
                  uStack_150 = uVar31;
                  puVar6 = puVar6 + 1;
                } while ((int)uVar12 < (int)(uint)uStack_14c);
              }
              do {
                if (-1 < (short)puVar37[(ulonglong)(uStack_14c - 1) + 1]) {
code_r0x00101a22:
                  uVar35 = (ulonglong)uStack_158 & 0xffffffff;
                  goto code_r0x00101c04;
                }
                uVar12 = uVar13;
                if (uStack_14c != 1) {
                  uVar12 = *(ushort *)
                            ((longlong)ppbVar29 +
                            (ulonglong)uStack_14c * 2 + (((ulonglong)uStack_158 >> 0x20) - 2)) &
                           0x7fff;
                }
                uVar27 = *(ushort *)
                          ((longlong)ppbVar29 +
                          (ulonglong)uStack_14c * 2 + ((ulonglong)uStack_158 >> 0x20)) & 0x7fff;
                if (((uVar12 < uVar13) || (uVar27 < uVar12)) || ((uint)uVar32 < uVar27)) {
                  uStack_150 = uVar13;
                  func_0x(ppbVar29,7);
                  uVar32 = (ulonglong)uStack_164;
                  ppbVar29 = ppbStack_160;
                  uVar13 = uStack_150;
                }
                uVar31 = (uint)uVar32;
                uStack_150 = uVar13;
                if ((uVar12 < uVar13) || (uVar31 < uVar12)) goto code_r0x00101db5;
                if (*(ushort *)((longlong)ppbVar29 + (ulonglong)uVar12) == 5) {
                  uStack_166 = uStack_166 | 2;
                  uStack_14c = uStack_14c - 1;
                  uVar34 = (ulonglong)(uVar12 & 0xffff);
                  uStack_13e = (ushort)uVar12;
                  uVar35 = uVar34 + (longlong)ppbVar29;
                  if ((*(ushort *)(uVar35 + 2) >> 0xe & 1) == 0) {
                    uVar21 = uStack_13c & 0xc7ff;
                  }
                  else {
                    uVar21 = uStack_13c ^ (uStack_13c ^ *(ushort *)(uVar35 + 2)) & 0x3800;
                  }
                  uStack_13c = (uVar21 ^ *(ushort *)(uVar35 + 2)) & 0x7ff ^ uVar21;
                  uVar38 = (longlong)ppbVar29 +
                           uVar34 + (ulonglong)((uStack_13c & 0x7ff) * 2) + 4 +
                                    (ulonglong)((uVar21 >> 0xb & 7) * 2);
                  if (uVar38 < uVar35) {
                    func_0x(uVar35,0x19);
                    uVar34 = (ulonglong)uStack_13e;
                    uVar32 = (ulonglong)uStack_164;
                    ppbVar29 = ppbStack_160;
                  }
                  uVar13 = uStack_150;
                  if (uVar27 - uVar12 <
                      (((uStack_13c & 0x7ff) * 2 - (int)uVar34) - (int)ppbStack_160) + (int)uVar38)
                  {
                    func_0x(uVar34 + (longlong)ppbVar29,0x19);
                    uVar34 = (ulonglong)uStack_13e;
                    uVar32 = (ulonglong)uStack_164;
                    ppbVar29 = ppbStack_160;
                    uVar13 = uStack_150;
                  }
                  if (((uStack_13c & 0x3800) != 0) &&
                     (puVar37 = (ushort *)((longlong)ppbVar29 + uVar34 + 4), uVar21 = uStack_13c,
                     (uStack_13c & 0x3800) != 0)) {
                    do {
                      if ((uVar21 & 0x7ff) < (*puVar37 & 0x7ff)) {
                        uStack_150 = uVar13;
                        func_0x(uVar34 + (longlong)ppbVar29,0x1a);
                        uVar34 = (ulonglong)uStack_13e;
                        ppbVar29 = ppbStack_160;
                        uVar21 = uStack_13c;
                        uVar13 = uStack_150;
                      }
                      uVar31 = (int)ppbVar30 + 1;
                      ppbVar30 = (byte **)(ulonglong)uVar31;
                      puVar37 = puVar37 + 1;
                    } while ((int)uVar31 < (int)((uStack_13c & 0x3800) >> 0xb));
                    uVar35 = (ulonglong)uStack_158 & 0xffffffff;
                    uVar32 = (ulonglong)uStack_164;
                    goto code_r0x00101c04;
                  }
                  goto code_r0x00101a22;
                }
                if (*(ushort *)((longlong)ppbVar29 + (ulonglong)uVar12) < 0x400)
                goto code_r0x00101a22;
                uStack_166 = uStack_166 | 1;
                uStack_14c = uStack_14c - 1;
                if (uStack_14c == 0) goto code_r0x00101a22;
              } while( true );
            }
            uStack_14c = 0;
            uStack_164 = uVar13;
code_r0x00101c04:
            if ((*(byte *)ppbVar29 & 0x40) == 0) {
              uStack_142 = 0;
              uStack_140 = 0;
            }
            else {
              uStack_142 = (undefined2)uVar32;
              uStack_140 = (undefined2)(uVar32 >> 0x10);
              uStack_164 = (int)uVar32 + 0xe;
              uStack_150 = uVar13;
              uVar20 = func_0x(&uStack_166);
              func_0x(uVar20,auStack_468);
              iVar11 = func_0x(auStack_468);
              uStack_164 = uStack_164 + iVar11;
              uVar32 = (ulonglong)uStack_164;
              uVar35 = (ulonglong)uStack_158 & 0xffffffff;
              ppbVar29 = ppbStack_160;
              uVar13 = uStack_150;
            }
            uVar31 = (uint)uVar32;
            uStack_150 = uVar13;
            if ((CONCAT62(uStack_148,uStack_14a) != 0) &&
               (CONCAT62(uStack_148,uStack_14a) < uVar32 + (longlong)ppbVar29)) {
              cVar9 = func_0x(0x16591c0);
              if (cVar9 != '\0') {
                cVar9 = func_0x();
                if (cVar9 != '\0') {
                  cVar9 = func_0x(0x16591c0);
                  if (cVar9 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    uStack_588 = (uint *)0x0;
                    (*_DAT_)(1,0xf48bcc,0x1068cb8,0x886);
                  }
                }
              }
              func_0x(ppbStack_160,0x12);
              uVar35 = (ulonglong)uStack_158 & 0xffffffff;
              ppbVar29 = ppbStack_160;
              uVar31 = uStack_164;
            }
            if (uVar31 - 1 < 0x3f3c) goto code_r0x00101dc6;
            cVar9 = func_0x(0x16591c0);
            if (cVar9 != '\0') {
              cVar9 = func_0x();
              if (cVar9 != '\0') {
                cVar9 = func_0x(0x16591c0);
                if (cVar9 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  uStack_588 = (uint *)0x0;
                  (*_DAT_)(1,0xf48bcc,0x1068cb8,0x88b);
                }
              }
            }
            func_0x(ppbStack_160,5);
            ppbVar29 = ppbStack_160;
            uVar31 = uStack_164;
code_r0x00101db5:
            uVar35 = (ulonglong)uStack_158 & 0xffffffff;
          }
code_r0x00101dc6:
          sVar24 = -(short)uStack_548;
          if ((uStack_542 & 0x10) == 0) {
code_r0x00101dea:
            if ((uint)uStack_14c < (uint)(int)sVar24) {
              auStack_568[0] = 0;
              puVar28 = puStack_4b0;
            }
            else {
              ppbVar30 = ppbVar29;
              uVar13 = uStack_150;
              if (sVar24 != 1) {
                ppbVar30 = ppbStack_160;
                uVar13 = *(ushort *)
                          ((longlong)ppbVar29 +
                          (longlong)sVar24 * 2 + (((ulonglong)uStack_158 >> 0x20) - 2)) & 0x7fff;
                uVar31 = uStack_164;
              }
              uVar12 = *(ushort *)
                        ((longlong)ppbVar29 + (longlong)sVar24 * 2 + ((ulonglong)uStack_158 >> 0x20)
                        ) & 0x7fff;
              if (((uVar13 < uStack_150) || (uVar12 < uVar13)) || (uVar31 < uVar12)) {
                func_0x(ppbVar30,7);
                ppbVar30 = ppbStack_160;
              }
              ppbVar29 = (byte **)((ulonglong)uVar13 + (longlong)ppbVar30);
              auStack_568[0] = uVar12 - uVar13;
              puVar28 = puStack_4b0;
            }
          }
          else {
            if ((*(byte *)ppbVar29 & 0x10) == 0) {
              if ((1 << (*(byte *)ppbVar29 & 0xe) & 0x1105U) == 0) goto code_r0x00101dea;
            }
            else if (((int)uStack_548 < (int)uVar35) &&
                    (uStack_544 <= *(ushort *)(uVar35 + (longlong)ppbVar29))) goto code_r0x00101dea;
code_r0x00101e27:
            ppbVar29 = (byte **)(puStack_540 + 1);
            auStack_568[0] = *puStack_540;
            puVar28 = puStack_4b0;
          }
        }
        else {
          if ((uStack_542 & 8) != 0) {
            ppbVar29 = (byte **)0xccd860;
            if ((*(byte *)((longlong)ppbStack_160 + (longlong)(int)uStack_548) &
                (byte)(1 << ((byte)uStack_542 & 7))) == 0) {
              ppbVar29 = (byte **)0xccd861;
            }
            auStack_568[0] = 1;
            goto code_r0x00101f90;
          }
          if ((uStack_542 & 0x10) != 0) {
            if ((bVar4 & 0x10) != 0) {
              if (((int)uStack_548 < (int)(uint)uStack_158) &&
                 (uStack_544 <= *(ushort *)(uVar35 + (longlong)ppbStack_160)))
              goto code_r0x0010161c;
              goto code_r0x00101e27;
            }
            if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
              ppbVar29 = (byte **)(puStack_540 + 1);
              auStack_568[0] = *puStack_540;
              goto code_r0x00101f90;
            }
          }
code_r0x0010161c:
          ppbVar29 = (byte **)((longlong)ppbStack_160 + (longlong)(int)uStack_548);
          auStack_568[0] = 0;
        }
      }
      else {
        if ((int)uStack_548 < (int)(uint)uStack_158) {
          if ((uint)*(ushort *)(uVar35 + (longlong)ppbStack_160) < (uint)uStack_544) {
            uVar21 = ~(uStack_542 >> 4);
            uVar13 = uVar31;
          }
          else {
            uVar31 = uStack_544 - 1;
            uVar21 = (ushort)(*(byte *)((uVar31 >> 3) + uVar35 + 2 + (longlong)ppbStack_160) >>
                             ((byte)uVar31 & 7));
          }
        }
        else {
          uVar21 = ~(uStack_542 >> 4);
          uVar13 = uVar31;
        }
code_r0x0010157f:
        if ((uVar21 & 1) == 0) {
          if ((uVar13 != 0) || ((uStack_542 & 0x10) == 0)) goto code_r0x001015ba;
          ppbVar29 = (byte **)(puStack_540 + 1);
          auStack_568[0] = *puStack_540;
        }
        else {
          auStack_568[0] = 0;
          ppbVar29 = ppbVar30;
        }
      }
    }
  }
  else {
    uStack_51c = 0;
    uStack_588 = &uStack_51c;
    ppbVar29 = (byte **)func_0x(&uStack_166,&uStack_548);
    if ((((sStack_168 != 0) && (uStack_158 != (byte **)0x0)) && (*uStack_158 != (byte *)0x0)) &&
       (((uStack_542 & 8) == 0 && ((uStack_51c & 1) == 0)))) {
      if ((ppbVar29 == (byte **)0x0) || (ppbVar29 == (byte **)0xccd860)) {
        auStack_568[0] = 0;
        ppbVar29 = ppbVar30;
      }
      else {
        uStack_570 = CONCAT44(uStack_570._4_4_,uStack_51c);
        puStack_578 = auStack_568;
        uStack_580 = (uint *)((ulonglong)uStack_580 & 0xffffffff00000000);
        uStack_588 = (uint *)0x0;
        ppbVar29 = (byte **)func_0x(uStack_158,&uStack_548,ppbVar29,auStack_568[0]);
      }
    }
code_r0x00101f8d:
  }
code_r0x00101f90:
  func_0x(lVar17,param_5,ppbVar29,auStack_568[0]);
  *puVar28 = (ulonglong)auStack_568[0];
  goto code_r0x00101fdd;
}

