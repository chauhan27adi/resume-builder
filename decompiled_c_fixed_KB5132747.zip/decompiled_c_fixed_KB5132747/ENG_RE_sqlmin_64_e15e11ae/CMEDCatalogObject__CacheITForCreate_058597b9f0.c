
void FUN_(undefined8 param_1,longlong param_2,longlong param_3)

{
  code *UNRECOVERED_JUMPTABLE;
  longlong lVar1;
  longlong lVar2;
  
  lVar1 = 0;
  lVar2 = lVar1;
  if (*(int *)(param_2 + 0x80) == 1) {
    lVar2 = *(longlong *)(param_2 + 0x88);
  }
  if (*(int *)(param_3 + 0x80) == 1) {
    lVar1 = *(longlong *)(param_3 + 0x88);
  }
  UNRECOVERED_JUMPTABLE =
       (code *)((ulonglong)
                *(uint *)((ulonglong)
                          *(byte *)((longlong)(**(int **)(lVar2 + 800) + -0xc9) + 0x100268) * 4 +
                         0x100230) - 0x412f10);
                    /* WARNING: Could not recover jumptable at 0x00100065. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,lVar1,param_3,param_2);
  return;
}

