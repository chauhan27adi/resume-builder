
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,longlong *param_3,longlong param_4)

{
  uint *puVar1;
  code *pcVar2;
  char cVar3;
  byte bVar4;
  undefined uVar5;
  short sVar6;
  ushort uVar7;
  ushort uVar8;
  ushort uVar9;
  undefined2 uVar10;
  uint uVar11;
  longlong lVar12;
  byte *pbVar13;
  undefined4 *puVar14;
  longlong lVar15;
  longlong lVar16;
  undefined8 uVar17;
  longlong lVar18;
  undefined *puVar19;
  byte *pbVar20;
  ushort *puVar21;
  undefined8 uVar22;
  undefined8 uVar23;
  byte bVar24;
  uint uVar25;
  uint uVar26;
  uint uVar27;
  undefined8 unaff_RBX;
  int *piVar28;
  longlong *plVar29;
  ulonglong uVar30;
  uint *puVar31;
  ulonglong uVar32;
  undefined *puVar33;
  int iVar34;
  uint uVar35;
  uint uVar36;
  int iVar37;
  longlong lVar38;
  ulonglong uVar39;
  char *pcVar40;
  uint uVar41;
  undefined4 uVar42;
  short *psVar43;
  ulonglong uVar44;
  int iVar45;
  ushort *puVar46;
  ushort *puVar47;
  bool bVar48;
  uint auStackX_18 [2];
  uint *puStackX_20;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  puVar33 = &stack0xffffffffffffffc8 + lVar12;
  puVar19 = &stack0xffffffffffffffc8 + lVar12;
  puVar1 = (uint *)((longlong)auStackX_18 + lVar12);
  *(undefined8 *)(&stack0x000002f8 + lVar12) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00006860 + lVar12) = unaff_RBX;
  *(ulonglong *)(&stack0x00006808 + lVar12) = _DAT_ ^ (ulonglong)puVar1;
  uVar17 = 0;
  lVar38 = *(longlong *)(param_1 + 0x3f0);
  *(longlong *)(&stack0x00000088 + lVar12) = lVar38;
  if (*(longlong *)(lVar38 + 0x10) == 0) {
    plVar29 = (longlong *)(param_1 + 0x40);
    if (param_2 != plVar29) {
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x109f99;
      (*_DAT_)(1,0xbdbbd8,0xbdbbb0,0x4f5);
    }
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar12) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar12) = &stack0x000001f8 + lVar12;
    lVar38 = *plVar29;
    uVar17 = *(undefined8 *)(param_1 + 0x38);
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x109fc0;
    func_0x(uVar17,lVar38,param_3,param_4);
    lVar38 = *(longlong *)(&stack0x000001f8 + lVar12);
    if (lVar38 != 0) {
      if (lVar38 != *plVar29) {
        *(longlong *)(param_1 + 0x48) = *plVar29;
        lVar38 = *(longlong *)(&stack0x000001f8 + lVar12);
      }
      *plVar29 = lVar38;
      puVar19 = &stack0xffffffffffffffc8 + lVar12;
    }
    goto LAB_;
  }
  *(undefined8 *)(&stack0x00000320 + lVar12) = 0x7c50d0;
  *(undefined (*) [16])(&stack0x00000328 + lVar12) = ZEXT816(0);
  *(undefined8 *)(&stack0x00000338 + lVar12) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10008d;
  func_0x(&stack0x000003a8 + lVar12);
  *(undefined4 *)(&stack0x000000cc + lVar12) = 0;
  *(undefined8 *)(&stack0x000000e0 + lVar12) = 0;
  *(undefined4 *)(&stack0x000000e8 + lVar12) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1000ac;
  func_0x(&stack0x000002d0 + lVar12);
  if (param_3 == (longlong *)0x0) {
    param_3 = *(longlong **)(&stack0x000000b8 + lVar12);
    puVar33 = &stack0xffffffffffffffc8 + lVar12;
  }
  else {
    if ((*(int *)(param_1 + 0x3d8) == *(int *)(param_3 + 1)) &&
       (*param_3 == (ulonglong)*(uint6 *)(param_1 + 0x3c4) * 0x10000)) {
      pcVar2 = **(code ***)(param_1 + 0x3b0);
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1000f8;
      sVar6 = (*pcVar2)(param_1 + 0x3b0);
      if (*(short *)((longlong)param_3 + 0xc) != sVar6) goto LAB_;
      if (param_3[0x15] != 0) {
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar12) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar12);
        UNLOCK();
      }
    }
    else {
LAB_:
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10011c;
      func_0x(param_3,param_1 + 0x3b0);
    }
    uVar7 = *(ushort *)(param_3 + 7);
    uVar8 = *(ushort *)((longlong)param_3 + 0x62);
    if ((uVar7 >> 10 & 1) == 0) {
      *(longlong **)(&stack0x000000b8 + lVar12) = param_3;
      *(uint *)(&stack0x000000c8 + lVar12) = (uint)uVar8;
      *(longlong *)(&stack0x000000d0 + lVar12) = param_4;
      *(undefined8 *)(&stack0x000000d8 + lVar12) = 0;
      *(undefined8 *)(&stack0x00000110 + lVar12) = 0;
      *(longlong *)(&stack0x000000c0 + lVar12) = param_3[0xe];
      lVar38 = **(longlong **)(*(longlong *)(param_1 + 0x3b8) + 0x160);
      *(undefined8 *)(&stack0x000000e0 + lVar12) = *(undefined8 *)(lVar38 + 0xa8);
      *(undefined4 *)(&stack0x000000e8 + lVar12) = *(undefined4 *)(lVar38 + 0xb0);
      *(uint *)(&stack0x000000cc + lVar12) = *(uint *)(&stack0x000000cc + lVar12) | 0x10;
      puVar33 = &stack0xffffffffffffffc8 + lVar12;
    }
    else {
      if (uVar8 == 0) {
        lVar38 = 0;
        iVar45 = 0;
        uVar8 = 0;
      }
      else {
        iVar45 = (uint)uVar8 * 8;
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001bc;
        lVar15 = func_0x();
        lVar15 = -lVar15;
        *(longlong *)(&stack0x00000070 + lVar12) = (longlong)auStackX_18 + lVar15 + lVar12;
        *(undefined8 *)((longlong)&uStack_40 + lVar15 + lVar12) = 0x1001dd;
        lVar16 = func_0x();
        lVar16 = -lVar16;
        puVar33 = &stack0xffffffffffffffc8 + lVar16 + lVar15 + lVar12;
        lVar38 = (longlong)auStackX_18 + lVar16 + lVar15 + lVar12;
        *(longlong *)(&stack0x00000028 + lVar12) = lVar38;
        uVar9 = *(ushort *)(param_3 + 0xb);
        uVar27 = *(uint *)((longlong)param_3 + 0x54);
        uVar35 = 0x1f9e;
        if (uVar27 < 0x1f9f) {
LAB_:
          uVar35 = uVar27;
          if (uVar27 != 0) goto LAB_;
        }
        else {
          if (0x1f9d < uVar9) {
            uVar27 = (uint)uVar9;
            goto LAB_;
          }
LAB_:
          *(undefined **)(&stack0x00000108 + lVar12) = &stack0x000002d0 + lVar12;
          *(undefined8 *)((longlong)&uStack_40 + lVar16 + lVar15 + lVar12) = 0x100225;
          func_0x(&stack0x000002d0 + lVar12);
          uVar44 = (ulonglong)uVar35 + 0xf;
          if (uVar44 <= uVar35) {
            uVar44 = 0xffffffffffffff0;
          }
          uVar44 = uVar44 & 0xfffffffffffffff0;
          *(undefined8 *)((longlong)&uStack_40 + lVar16 + lVar15 + lVar12) = 0x100246;
          func_0x();
          puVar33 = &stack0xffffffffffffffc8 + -uVar44 + lVar16 + lVar15 + lVar12;
          *(ulonglong *)(&stack0x000002d8 + lVar12) =
               (longlong)auStackX_18 + -uVar44 + lVar16 + lVar15 + lVar12;
          *(ushort *)(&stack0x000002d4 + lVar12) = (short)uVar35 - uVar9;
          *(ushort *)(&stack0x000002d6 + lVar12) = uVar9;
          uVar8 = *(ushort *)((longlong)param_3 + 0x62);
          uVar7 = *(ushort *)(param_3 + 7);
          lVar38 = *(longlong *)(&stack0x00000028 + lVar12);
        }
        uVar17 = *(undefined8 *)(&stack0x00000070 + lVar12);
      }
      *(longlong **)(&stack0x000000b8 + lVar12) = param_3;
      *(uint *)(&stack0x000000c8 + lVar12) = (uint)uVar8;
      *(longlong *)(&stack0x000000d0 + lVar12) = param_4;
      *(undefined8 *)(&stack0x000000d8 + lVar12) = 0;
      *(undefined8 *)(&stack0x00000110 + lVar12) = 0;
      *(longlong *)(&stack0x000000c0 + lVar12) = param_3[0xe];
      lVar15 = **(longlong **)(*(longlong *)(param_1 + 0x3b8) + 0x160);
      *(undefined8 *)(&stack0x000000e0 + lVar12) = *(undefined8 *)(lVar15 + 0xa8);
      *(undefined4 *)(&stack0x000000e8 + lVar12) = *(undefined4 *)(lVar15 + 0xb0);
      uVar27 = *(uint *)(&stack0x000000cc + lVar12);
      *(uint *)(&stack0x000000cc + lVar12) = uVar27 | 0x10;
      if (((uVar7 >> 10 & 1) != 0) && (param_4 != 0)) {
        *(uint *)(&stack0x000000cc + lVar12) = uVar27 | 0x14;
        *(int *)(puVar33 + 0x30) = iVar45;
        *(longlong *)(puVar33 + 0x28) = lVar38;
        *(int *)(puVar33 + 0x20) = iVar45;
        *(undefined8 *)(puVar33 + -8) = 0x100334;
        func_0x(&stack0x000000b8 + lVar12,param_1 + 0x3b0,(uint)uVar8,uVar17);
        param_3 = *(longlong **)(&stack0x000000b8 + lVar12);
      }
    }
  }
  uVar44 = 0;
  lVar38 = *(longlong *)(&stack0x00000088 + lVar12);
  psVar43 = (short *)(lVar38 + 8);
  *(short **)(&stack0x00000078 + lVar12) = psVar43;
  *(int *)(&stack0x00000080 + lVar12) = *(int *)(*(longlong *)(param_1 + 0x3b8) + 0xb0) * 2;
  uVar27 = 0;
  if ((*(byte *)(param_3 + 7) & 0x20) == 0) {
    if ((*(uint *)((longlong)param_3 + 0x5c) & 2) == 0) {
      if ((*(uint *)((longlong)param_3 + 0x5c) & 4) == 0) {
        if (*psVar43 == 0) {
          *psVar43 = 0;
          puVar47 = (ushort *)(*(longlong *)(&stack0x00000088 + lVar12) + 10);
          *(ushort **)(&stack0x000000a0 + lVar12) = puVar47;
          uVar7 = *(ushort *)(*(longlong *)(&stack0x000000b8 + lVar12) + 0x62);
          *(uint *)(&stack0x00000124 + lVar12) = (uint)uVar7;
          *(undefined4 *)(&stack0x00000094 + lVar12) = 0;
          puVar31 = *(uint **)(&stack0x000000c0 + lVar12);
          *(uint **)((longlong)&puStackX_20 + lVar12) = puVar31;
          if (uVar7 != 0) {
            do {
              uVar27 = 0;
              (&stack0x00000030)[lVar12] = 0;
              *(undefined8 *)(puVar33 + -8) = 0x100597;
              func_0x(&stack0x000000b8 + lVar12,puVar31,&stack0x00000030 + lVar12);
              if ((&stack0x00000030)[lVar12] == '\x03') {
                if ((puVar31[0x10] & 0x4000) == 0) {
                  *(undefined8 *)(puVar33 + -8) = 0x103cdd;
                  (*_DAT_)(6,0x51,0x10,1);
                }
                uVar10 = *(undefined2 *)(puVar31 + 0xf);
                *(undefined8 *)(puVar33 + -8) = 0x103cf3;
                func_0x(puVar47,puVar31,uVar10,1);
              }
              else {
                if (*(short *)(puVar31 + 1) != 0) {
                  *(undefined8 *)(puVar33 + -8) = 0x1005b4;
                  func_0x(puVar47,puVar31);
                }
                *(undefined8 *)(puVar33 + -8) = 0x1005ca;
                func_0x(&stack0x000000b8 + lVar12,puVar31,&stack0x000001a8 + lVar12)
                ;
                cVar3 = *(char *)(puVar31 + 0x10);
                iVar45 = 0;
                if ((cVar3 == '\x01') || (cVar3 == '\x02')) {
                  lVar38 = *(longlong *)(&stack0x000001a8 + lVar12);
                  if ((puVar31[0x10] >> 8 & 1) == 0) {
                    uVar27 = *puVar31;
                    lVar15 = *(longlong *)(puVar47 + 3);
                    uVar10 = *(undefined2 *)(puVar31 + 0xf);
                    *(undefined8 *)(puVar33 + -8) = 0x103bf6;
                    func_0x((int)uVar27 + lVar15,lVar38,uVar10);
                  }
                  else {
                    if (((puVar31[0x10] & 0x8000) == 0) || (((&stack0x000000cc)[lVar12] & 8) == 0))
                    {
                      piVar28 = *(int **)((longlong)&puStackX_20 + lVar12);
                      lVar15 = *(longlong *)(&stack0x000000d0 + lVar12);
                      if ((*(byte *)(*(longlong *)(piVar28 + 0x12) + 0x2a) & 0x10) != 0) {
                        lVar15 = *(longlong *)(&stack0x000000d8 + lVar12);
                      }
                      uVar27 = *(uint *)(*(longlong *)(*(longlong *)(piVar28 + 0x12) + 0x18) +
                                        lVar15);
                    }
                    else {
                      piVar28 = *(int **)((longlong)&puStackX_20 + lVar12);
                      uVar27 = *(uint *)(*(longlong *)(&stack0x000000f0 + lVar12) +
                                        (ulonglong)(uint)piVar28[0xe] * 8);
                    }
                    uVar35 = (uint)*(ushort *)(piVar28 + 0xf);
                    if (uVar27 < uVar35) {
                      iVar45 = uVar35 - uVar27;
                    }
                    else if (uVar35 < uVar27) {
                      *(undefined8 *)(puVar33 + -8) = 0x103c6e;
                      (*_DAT_)(6,0x5c,0x16,1);
                    }
                    uVar5 = *(undefined *)(*(longlong *)(piVar28 + 0x12) + 0x24);
                    iVar34 = *piVar28;
                    lVar15 = *(longlong *)(puVar47 + 3);
                    if ((lVar38 != 0) && (uVar27 != 0)) {
                      *(undefined8 *)(puVar33 + -8) = 0x103c95;
                      func_0x(iVar34 + lVar15,lVar38,uVar27);
                    }
                    if (iVar45 != 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x103caa;
                      func_0x((ulonglong)uVar27 + iVar34 + lVar15,uVar5,iVar45);
                    }
                    puVar31 = *(uint **)((longlong)&puStackX_20 + lVar12);
                  }
                }
                else if ((cVar3 == '\x03') || (cVar3 == '\x04')) {
                  uVar35 = puVar31[0x10];
                  piVar28 = *(int **)(&stack0x000001a8 + lVar12);
                  *(int **)(&stack0x00000028 + lVar12) = piVar28;
                  if (((uVar35 >> 0xd & 1) == 0) || (*piVar28 != 0)) {
                    if (((uVar35 & 0x8000) == 0) || (((&stack0x000000cc)[lVar12] & 8) == 0)) {
                      lVar38 = *(longlong *)(puVar31 + 0x12);
                      if ((uVar35 >> 8 & 1) == 0) {
                        uVar35 = (uint)*(ushort *)(lVar38 + 2);
                      }
                      else {
                        lVar15 = *(longlong *)(&stack0x000000d0 + lVar12);
                        if ((*(byte *)(lVar38 + 0x2a) & 0x10) != 0) {
                          lVar15 = *(longlong *)(&stack0x000000d8 + lVar12);
                        }
                        uVar35 = *(uint *)(*(longlong *)(lVar38 + 0x18) + lVar15);
                      }
                    }
                    else {
                      uVar35 = *(uint *)(*(longlong *)(&stack0x000000f0 + lVar12) +
                                        (ulonglong)puVar31[0xe] * 8);
                    }
                    *puVar1 = uVar35;
                  }
                  else {
                    *puVar1 = 0;
                    uVar35 = uVar27;
                  }
                  if (*(ushort *)(puVar31 + 0xf) < uVar35) {
                    *(undefined8 *)(puVar33 + -8) = 0x1020f7;
                    (*_DAT_)(6,0x52,0x16,0x93);
                    piVar28 = *(int **)(&stack0x000001a8 + lVar12);
                    *(int **)(&stack0x00000028 + lVar12) = piVar28;
                  }
                  uVar36 = *puVar31;
                  lVar38 = (longlong)(int)uVar36;
                  if (-1 < (int)uVar36) {
                    uVar41 = (uint)*(ushort *)((longlong)puVar31 + 6);
                    if ((*(ushort *)((longlong)puVar31 + 6) & 8) == 0) {
                      if (*(int *)(puVar47 + 1) == 0) {
                        *puVar47 = 0;
                        uVar36 = *(uint *)(puVar47 + 7);
                        uVar44 = (ulonglong)uVar36;
                        *(uint *)(puVar47 + 9) = uVar36;
                        pbVar20 = *(byte **)(puVar47 + 3);
                        bVar24 = *pbVar20;
                        pbVar13 = pbVar20;
                        if ((bVar24 & 0x10) != 0) {
                          uVar36 = uVar36 + (*(ushort *)(pbVar20 + uVar44) + 7 >> 3) + 2;
                          uVar44 = (ulonglong)uVar36;
                          *(uint *)(puVar47 + 9) = uVar36;
                          bVar24 = *pbVar20;
                          pbVar13 = *(byte **)(puVar47 + 3);
                        }
                        if ((bVar24 & 0x20) == 0) {
                          *(int *)(puVar47 + 1) = (int)uVar44;
                          puVar47[0xd] = 0;
                          *(uint *)(puVar47 + 0xb) = uVar36;
                        }
                        else {
                          puVar46 = (ushort *)(pbVar20 + uVar44);
                          uVar7 = *puVar46;
                          puVar47[0xd] = uVar7;
                          if (uVar7 == 0) {
                            *(undefined8 *)(puVar33 + -8) = 0x1021f8;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x102201;
                              lVar38 = func_0x();
                              if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar33 + -8) = 0x10221b;
                                cVar3 = func_0x(0x112fe00);
                                if (cVar3 == '\0') {
                                  *(undefined8 *)(puVar33 + -8) = 0x102237;
                                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                }
                                else {
                                  *(undefined8 *)(puVar33 + 0x20) = 0;
                                  *(undefined8 *)(puVar33 + -8) = 0x10225d;
                                  (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x80f);
                                }
                              }
                            }
                            uVar17 = *(undefined8 *)(puVar47 + 3);
                            *(undefined8 *)(puVar33 + -8) = 0x10226b;
                            func_0x(uVar17,3);
                            uVar7 = puVar47[0xd];
                            uVar36 = *(uint *)(puVar47 + 9);
                          }
                          uVar36 = uVar36 + (uVar7 + 1) * 2;
                          *(uint *)(puVar47 + 0xb) = uVar36;
                          if (0x1f9e < uVar36) {
                            *(undefined8 *)(puVar33 + -8) = 0x10229a;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x1022a3;
                              lVar38 = func_0x();
                              if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar33 + -8) = 0x1022bd;
                                cVar3 = func_0x(0x112fe00);
                                if (cVar3 == '\0') {
                                  *(undefined8 *)(puVar33 + -8) = 0x1022d9;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar33 + 0x20) = 0;
                                  *(undefined8 *)(puVar33 + -8) = 0x1022ff;
                                  (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x816);
                                }
                              }
                            }
                            uVar17 = *(undefined8 *)(puVar47 + 3);
                            *(undefined8 *)(puVar33 + -8) = 0x10230d;
                            func_0x(uVar17,4);
                            uVar7 = puVar47[0xd];
                            uVar36 = *(uint *)(puVar47 + 0xb);
                          }
                          uVar44 = (ulonglong)uVar7;
                          uVar7 = puVar46[uVar44];
                          *(uint *)(puVar47 + 1) = uVar7 & 0x7fff;
                          if ((uVar7 & 0x7fff) < uVar36) {
                            *(undefined8 *)(puVar33 + -8) = 0x10233e;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x102347;
                              lVar38 = func_0x();
                              if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar33 + -8) = 0x102361;
                                cVar3 = func_0x(0x112fe00);
                                if (cVar3 == '\0') {
                                  *(undefined8 *)(puVar33 + -8) = 0x10237d;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar33 + 0x20) = 0;
                                  *(undefined8 *)(puVar33 + -8) = 0x1023a3;
                                  (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x81d);
                                }
                              }
                            }
                            uVar17 = *(undefined8 *)(puVar47 + 3);
                            *(undefined8 *)(puVar33 + -8) = 0x1023b1;
                            func_0x(uVar17,4);
                            uVar36 = *(uint *)(puVar47 + 0xb);
                            uVar44 = (ulonglong)puVar47[0xd];
                          }
                          puVar21 = puVar46;
                          if ((short)uVar44 != 0) {
                            do {
                              uVar35 = puVar21[1] & 0x7fff;
                              if ((uVar35 < uVar36) || (*(uint *)(puVar47 + 1) < uVar35)) {
                                *(undefined8 *)(puVar33 + -8) = 0x102400;
                                cVar3 = func_0x(0x112fe00);
                                if (cVar3 != '\0') {
                                  *(undefined8 *)(puVar33 + -8) = 0x102409;
                                  lVar38 = func_0x();
                                  if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                                    *(undefined8 *)(puVar33 + -8) = 0x102423;
                                    cVar3 = func_0x(0x112fe00);
                                    if (cVar3 == '\0') {
                                      *(undefined8 *)(puVar33 + -8) = 0x10243f;
                                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                    }
                                    else {
                                      *(undefined8 *)(puVar33 + 0x20) = 0;
                                      *(undefined8 *)(puVar33 + -8) = 0x102463;
                                      (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x82a);
                                    }
                                  }
                                }
                                uVar17 = *(undefined8 *)(puVar47 + 3);
                                *(undefined8 *)(puVar33 + -8) = 0x102471;
                                func_0x(uVar17,4);
                              }
                              uVar27 = uVar27 + 1;
                              uVar44 = (ulonglong)puVar47[0xd];
                              puVar21 = puVar21 + 1;
                              uVar36 = uVar35;
                            } while ((int)uVar27 < (int)(uint)puVar47[0xd]);
                            uVar35 = *puVar1;
                            piVar28 = *(int **)(&stack0x00000028 + lVar12);
                          }
                          if ((short)puVar46[(ulonglong)((int)uVar44 - 1) + 1] < 0) {
                            do {
                              lVar38 = *(longlong *)(puVar47 + 3);
                              uVar27 = *(ushort *)
                                        ((ulonglong)*(uint *)(puVar47 + 9) + lVar38 + uVar44 * 2) &
                                       0x7fff;
                              if ((int)uVar44 == 1) {
                                uVar36 = *(uint *)(puVar47 + 0xb);
                                uVar41 = uVar36;
LAB_:
                                if ((uVar27 < uVar36) || (*(uint *)(puVar47 + 1) < uVar27))
                                goto LAB_;
                              }
                              else {
                                uVar36 = *(ushort *)
                                          ((ulonglong)*(uint *)(puVar47 + 9) + lVar38 + -2 +
                                          uVar44 * 2) & 0x7fff;
                                uVar41 = *(uint *)(puVar47 + 0xb);
                                if (uVar41 <= uVar36) goto LAB_;
LAB_:
                                *(undefined8 *)(puVar33 + -8) = 0x1024f5;
                                func_0x(lVar38,7);
                                uVar41 = *(uint *)(puVar47 + 0xb);
                                lVar38 = *(longlong *)(puVar47 + 3);
                              }
                              if ((uVar36 < uVar41) || (*(uint *)(puVar47 + 1) < uVar36)) {
                                puVar31 = *(uint **)((longlong)&puStackX_20 + lVar12);
                                goto LAB_;
                              }
                              if (*(ushort *)((ulonglong)uVar36 + lVar38) == 5) {
                                *puVar47 = *puVar47 | 2;
                                puVar47[0xd] = puVar47[0xd] - 1;
                                puVar47[0x14] = (ushort)uVar36;
                                uVar44 = *(ulonglong *)(puVar47 + 3);
                                uVar7 = *(ushort *)((ulonglong)(uVar36 & 0xffff) + 2 + uVar44);
                                uVar8 = puVar47[0x15] & 0xc7ff;
                                if ((uVar7 >> 0xe & 1) != 0) {
                                  uVar8 = uVar7 & 0x3800 | uVar8;
                                }
                                puVar47[0x15] = uVar8;
                                uVar7 = (uVar8 ^ *(ushort *)
                                                  ((ulonglong)(uVar36 & 0xffff) + 2 + uVar44)) &
                                        0x7ff ^ uVar8;
                                puVar47[0x15] = uVar7;
                                uVar30 = (ulonglong)puVar47[0x14];
                                uVar39 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 +
                                         uVar44 + (uVar8 >> 0xb & 7) * 2 + uVar30;
                                if (uVar39 < uVar30 + uVar44) {
                                  *(undefined8 *)(puVar33 + -8) = 0x10260d;
                                  func_0x(uVar30 + uVar44,0x19);
                                  uVar7 = puVar47[0x15];
                                  uVar30 = (ulonglong)puVar47[0x14];
                                  uVar44 = (ulonglong)*(uint *)(puVar47 + 3);
                                }
                                if (uVar27 - uVar36 <
                                    (((uVar7 & 0x7ff) * 2 - (int)uVar30) - (int)uVar44) +
                                    (int)uVar39) {
                                  lVar38 = *(longlong *)(puVar47 + 3);
                                  *(undefined8 *)(puVar33 + -8) = 0x102645;
                                  func_0x(uVar30 + lVar38,0x19);
                                  uVar7 = puVar47[0x15];
                                }
                                if ((uVar7 & 0x3800) != 0) {
                                  puVar46 = (ushort *)
                                            (*(longlong *)(puVar47 + 3) +
                                            (ulonglong)puVar47[0x14] + 4);
                                  iVar45 = 0;
                                  if ((uVar7 & 0x3800) != 0) {
                                    do {
                                      if ((uVar7 & 0x7ff) < (*puVar46 & 0x7ff)) {
                                        uVar7 = puVar47[0x14];
                                        lVar38 = *(longlong *)(puVar47 + 3);
                                        *(undefined8 *)(puVar33 + -8) = 0x102697;
                                        func_0x((ulonglong)uVar7 + lVar38,0x1a);
                                        uVar7 = puVar47[0x15];
                                      }
                                      iVar45 = iVar45 + 1;
                                      puVar46 = puVar46 + 1;
                                    } while (iVar45 < (int)(uVar7 >> 0xb & 7));
                                  }
                                }
                                goto LAB_;
                              }
                              if (*(ushort *)((ulonglong)uVar36 + lVar38) < 0x400)
                              goto LAB_;
                              *puVar47 = *puVar47 | 1;
                              uVar7 = puVar47[0xd] - 1;
                              puVar47[0xd] = uVar7;
                              if (uVar7 == 0) goto LAB_;
                              uVar44 = (ulonglong)uVar7;
                            } while ((short)puVar46[(ulonglong)(uVar7 - 1) + 1] < 0);
                            pbVar13 = *(byte **)(puVar47 + 3);
                            puVar31 = *(uint **)((longlong)&puStackX_20 + lVar12);
                          }
                          else {
LAB_:
                            pbVar13 = *(byte **)(puVar47 + 3);
                            puVar31 = *(uint **)((longlong)&puStackX_20 + lVar12);
                          }
                        }
                        if ((*pbVar13 & 0x40) == 0) {
                          *(undefined4 *)(puVar47 + 0x12) = 0;
                        }
                        else {
                          *(int *)(puVar47 + 0x12) = *(int *)(puVar47 + 1);
                          *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + 0xe;
                          *(undefined8 *)(puVar33 + -8) = 0x1026e2;
                          uVar17 = func_0x(puVar47);
                          *(undefined8 *)(puVar33 + -8) = 0x1026f1;
                          func_0x(uVar17,&stack0x00000238 + lVar12);
                          *(undefined8 *)(puVar33 + -8) = 0x1026fd;
                          iVar45 = func_0x(&stack0x00000238 + lVar12);
                          *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + iVar45;
                          pbVar13 = *(byte **)(puVar47 + 3);
                        }
                        uVar27 = *(uint *)(puVar47 + 1);
                        if ((*(byte **)(puVar47 + 0xe) != (byte *)0x0) &&
                           (*(byte **)(puVar47 + 0xe) < pbVar13 + uVar27)) {
                          *(undefined8 *)(puVar33 + -8) = 0x102733;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x10273c;
                            lVar38 = func_0x();
                            if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar33 + -8) = 0x102756;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x102772;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x102798;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x1027a6;
                          func_0x(uVar17,0x12);
                          uVar27 = *(uint *)(puVar47 + 1);
                        }
                        if (0x3f3b < uVar27 - 1) {
                          *(undefined8 *)(puVar33 + -8) = 0x1027c3;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x1027cc;
                            lVar38 = func_0x();
                            if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar33 + -8) = 0x1027e6;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x102802;
                                (*_DAT_)(0x22,0x44,0x15);
                                uVar17 = *(undefined8 *)(puVar47 + 3);
                                *(undefined8 *)(puVar33 + -8) = 0x102810;
                                func_0x(uVar17,5);
                                goto LAB_;
                              }
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x102836;
                              (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                            }
                          }
                          uVar17 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x102844;
                          func_0x(uVar17,5);
                        }
                      }
LAB_:
                      uVar27 = *puVar31;
                      uVar41 = uVar35 + uVar27;
                      uVar36 = *(uint *)(puVar47 + 7);
                      if (uVar36 < uVar41) {
                        *(undefined8 *)(puVar33 + -8) = 0x10286b;
                        func_0x(puVar47,0,uVar41 - uVar36);
                        if ((1 << (**(byte **)(puVar47 + 3) & 0xe) & 0x1105U) != 0) {
                          *(short *)(*(byte **)(puVar47 + 3) + 2) = (short)uVar41;
                        }
                        *(uint *)(puVar47 + 7) = uVar41;
                        uVar27 = *puVar31;
                      }
                      lVar38 = *(longlong *)(puVar47 + 3);
                      if ((piVar28 != (int *)0x0) && (uVar35 != 0)) {
                        *(undefined8 *)(puVar33 + -8) = 0x1028b1;
                        func_0x((int)uVar27 + lVar38,piVar28,uVar35);
                      }
                    }
                    else {
                      cVar3 = *(char *)piVar28;
                      uVar36 = uVar36 + 1;
                      uVar27 = *(uint *)(puVar47 + 7);
                      if (uVar27 < uVar36) {
                        *(undefined8 *)(puVar33 + -8) = 0x102139;
                        func_0x(puVar47,0,uVar36 - uVar27);
                        if ((1 << (**(byte **)(puVar47 + 3) & 0xe) & 0x1105U) != 0) {
                          *(short *)(*(byte **)(puVar47 + 3) + 2) = (short)uVar36;
                        }
                        *(uint *)(puVar47 + 7) = uVar36;
                        uVar41 = (uint)*(byte *)(*(longlong *)((longlong)&puStackX_20 + lVar12) + 6)
                        ;
                      }
                      lVar15 = *(longlong *)(puVar47 + 3);
                      if (cVar3 == '\0') {
                        *(byte *)(lVar15 + lVar38) =
                             *(byte *)(lVar15 + lVar38) & ~(byte)(1 << (uVar41 & 7));
                      }
                      else {
                        *(byte *)(lVar15 + lVar38) =
                             *(byte *)(lVar15 + lVar38) | (byte)(1 << (uVar41 & 7));
                      }
LAB_:
                      puVar31 = *(uint **)((longlong)&puStackX_20 + lVar12);
                    }
                    goto LAB_;
                  }
                  if ((uVar36 & 0xc0000000) == 0x80000000) {
                    *(undefined8 *)(puVar33 + -8) = 0x103259;
                    func_0x(&stack0x00000688 + lVar12);
                    *(undefined4 *)(&stack0x0000011c + lVar12) = 0;
                    if (*(int *)(puVar47 + 1) == 0) {
                      *puVar47 = 0;
                      uVar36 = *(uint *)(puVar47 + 7);
                      uVar44 = (ulonglong)uVar36;
                      *(uint *)(puVar47 + 9) = uVar36;
                      pbVar20 = *(byte **)(puVar47 + 3);
                      bVar24 = *pbVar20;
                      if ((bVar24 & 0x10) != 0) {
                        uVar36 = uVar36 + (*(ushort *)(pbVar20 + uVar44) + 7 >> 3) + 2;
                        uVar44 = (ulonglong)uVar36;
                        *(uint *)(puVar47 + 9) = uVar36;
                        bVar24 = *pbVar20;
                      }
                      if ((bVar24 & 0x20) == 0) {
                        *(int *)(puVar47 + 1) = (int)uVar44;
                        puVar47[0xd] = 0;
                        *(uint *)(puVar47 + 0xb) = uVar36;
                      }
                      else {
                        puVar46 = (ushort *)(pbVar20 + uVar44);
                        uVar7 = *puVar46;
                        puVar47[0xd] = uVar7;
                        if (uVar7 == 0) {
                          *(undefined8 *)(puVar33 + -8) = 0x1032c4;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x1032cd;
                            lVar38 = func_0x();
                            if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar33 + -8) = 0x1032e7;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x103303;
                                (*_DAT_)(0x22,0x44,0x15,0x3eb);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x103329;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x80f);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x103337;
                          func_0x(uVar17,3);
                          uVar7 = puVar47[0xd];
                          uVar36 = *(uint *)(puVar47 + 9);
                        }
                        uVar36 = uVar36 + (uVar7 + 1) * 2;
                        *(uint *)(puVar47 + 0xb) = uVar36;
                        if (0x1f9e < uVar36) {
                          *(undefined8 *)(puVar33 + -8) = 0x103366;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x10336f;
                            lVar38 = func_0x();
                            if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar33 + -8) = 0x103389;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x1033a5;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x1033cb;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x816);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x1033d9;
                          func_0x(uVar17,4);
                          uVar7 = puVar47[0xd];
                          uVar36 = *(uint *)(puVar47 + 0xb);
                        }
                        uVar44 = (ulonglong)uVar7;
                        uVar7 = puVar46[uVar44];
                        *(uint *)(puVar47 + 1) = uVar7 & 0x7fff;
                        if ((uVar7 & 0x7fff) < uVar36) {
                          *(undefined8 *)(puVar33 + -8) = 0x10340a;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x103413;
                            lVar38 = func_0x();
                            if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar33 + -8) = 0x10342d;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x103449;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x10346f;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x81d);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x10347d;
                          func_0x(uVar17,4);
                          uVar36 = *(uint *)(puVar47 + 0xb);
                          uVar44 = (ulonglong)puVar47[0xd];
                        }
                        puVar21 = puVar46;
                        if ((short)uVar44 != 0) {
                          do {
                            uVar35 = puVar21[1] & 0x7fff;
                            if ((uVar35 < uVar36) || (*(uint *)(puVar47 + 1) < uVar35)) {
                              *(undefined8 *)(puVar33 + -8) = 0x1034c2;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 != '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x1034cb;
                                lVar38 = func_0x();
                                if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                                  *(undefined8 *)(puVar33 + -8) = 0x1034e5;
                                  cVar3 = func_0x(0x112fe00);
                                  if (cVar3 == '\0') {
                                    *(undefined8 *)(puVar33 + -8) = 0x103501;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(puVar33 + 0x20) = 0;
                                    *(undefined8 *)(puVar33 + -8) = 0x103525;
                                    (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x82a);
                                  }
                                }
                              }
                              uVar17 = *(undefined8 *)(puVar47 + 3);
                              *(undefined8 *)(puVar33 + -8) = 0x103533;
                              func_0x(uVar17,4);
                            }
                            uVar27 = uVar27 + 1;
                            uVar44 = (ulonglong)puVar47[0xd];
                            puVar21 = puVar21 + 1;
                            uVar36 = uVar35;
                          } while ((int)uVar27 < (int)(uint)puVar47[0xd]);
                          uVar35 = *puVar1;
                          piVar28 = *(int **)(&stack0x00000028 + lVar12);
                        }
                        if ((short)puVar46[(ulonglong)((int)uVar44 - 1) + 1] < 0) {
                          do {
                            lVar38 = *(longlong *)(puVar47 + 3);
                            lVar15 = (ulonglong)*(uint *)(puVar47 + 9) + lVar38;
                            uVar27 = *(ushort *)(lVar15 + uVar44 * 2) & 0x7fff;
                            if ((int)uVar44 == 1) {
                              uVar36 = *(uint *)(puVar47 + 0xb);
                              uVar41 = uVar36;
LAB_:
                              if ((uVar27 < uVar36) || (*(uint *)(puVar47 + 1) < uVar27))
                              goto LAB_;
                            }
                            else {
                              uVar36 = *(ushort *)(lVar15 + -2 + uVar44 * 2) & 0x7fff;
                              uVar41 = *(uint *)(puVar47 + 0xb);
                              if (uVar41 <= uVar36) goto LAB_;
LAB_:
                              *(undefined8 *)(puVar33 + -8) = 0x1035b5;
                              func_0x(lVar38,7);
                              uVar41 = *(uint *)(puVar47 + 0xb);
                            }
                            if ((uVar36 < uVar41) || (*(uint *)(puVar47 + 1) < uVar36))
                            goto LAB_;
                            if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(puVar47 + 3)) == 5) {
                              *puVar47 = *puVar47 | 2;
                              puVar47[0xd] = puVar47[0xd] - 1;
                              puVar47[0x14] = (ushort)uVar36;
                              uVar44 = *(ulonglong *)(puVar47 + 3);
                              uVar7 = *(ushort *)((ulonglong)(uVar36 & 0xffff) + 2 + uVar44);
                              uVar8 = puVar47[0x15] & 0xc7ff;
                              if ((uVar7 >> 0xe & 1) != 0) {
                                uVar8 = uVar7 & 0x3800 | uVar8;
                              }
                              puVar47[0x15] = uVar8;
                              uVar7 = (uVar8 ^ *(ushort *)
                                                ((ulonglong)(uVar36 & 0xffff) + 2 + uVar44)) & 0x7ff
                                      ^ uVar8;
                              puVar47[0x15] = uVar7;
                              uVar30 = (ulonglong)puVar47[0x14];
                              uVar39 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 +
                                       uVar44 + (uVar8 >> 0xb & 7) * 2 + uVar30;
                              if (uVar39 < uVar30 + uVar44) {
                                *(undefined8 *)(puVar33 + -8) = 0x1036c8;
                                func_0x(uVar30 + uVar44,0x19);
                                uVar7 = puVar47[0x15];
                                uVar30 = (ulonglong)puVar47[0x14];
                                uVar44 = (ulonglong)*(uint *)(puVar47 + 3);
                              }
                              if (uVar27 - uVar36 <
                                  (((uVar7 & 0x7ff) * 2 - (int)uVar30) - (int)uVar44) + (int)uVar39)
                              {
                                lVar38 = *(longlong *)(puVar47 + 3);
                                *(undefined8 *)(puVar33 + -8) = 0x103700;
                                func_0x(uVar30 + lVar38,0x19);
                                uVar7 = puVar47[0x15];
                              }
                              if ((uVar7 & 0x3800) != 0) {
                                puVar46 = (ushort *)
                                          (*(longlong *)(puVar47 + 3) + (ulonglong)puVar47[0x14] + 4
                                          );
                                iVar45 = 0;
                                if ((uVar7 & 0x3800) != 0) {
                                  do {
                                    if ((uVar7 & 0x7ff) < (*puVar46 & 0x7ff)) {
                                      uVar7 = puVar47[0x14];
                                      lVar38 = *(longlong *)(puVar47 + 3);
                                      *(undefined8 *)(puVar33 + -8) = 0x103757;
                                      func_0x((ulonglong)uVar7 + lVar38,0x1a);
                                      uVar7 = puVar47[0x15];
                                    }
                                    iVar45 = iVar45 + 1;
                                    puVar46 = puVar46 + 1;
                                  } while (iVar45 < (int)(uVar7 >> 0xb & 7));
                                }
                              }
                              goto LAB_;
                            }
                            if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(puVar47 + 3)) < 0x400)
                            goto LAB_;
                            *puVar47 = *puVar47 | 1;
                            uVar7 = puVar47[0xd] - 1;
                            puVar47[0xd] = uVar7;
                            if (uVar7 == 0) goto LAB_;
                            uVar44 = (ulonglong)uVar7;
                          } while ((short)puVar46[(ulonglong)(uVar7 - 1) + 1] < 0);
                          pbVar20 = *(byte **)(puVar47 + 3);
                        }
                        else {
LAB_:
                          pbVar20 = *(byte **)(puVar47 + 3);
                        }
                      }
                      if ((*pbVar20 & 0x40) == 0) {
                        *(undefined4 *)(puVar47 + 0x12) = 0;
                      }
                      else {
                        *(int *)(puVar47 + 0x12) = *(int *)(puVar47 + 1);
                        *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + 0xe;
                        *(undefined8 *)(puVar33 + -8) = 0x10379e;
                        uVar17 = func_0x(puVar47);
                        *(undefined8 *)(puVar33 + -8) = 0x1037ad;
                        func_0x(uVar17,&stack0x00000248 + lVar12);
                        *(undefined8 *)(puVar33 + -8) = 0x1037b9;
                        iVar45 = func_0x(&stack0x00000248 + lVar12);
                        *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + iVar45;
                      }
                      uVar27 = *(uint *)(puVar47 + 1);
                      if ((*(ulonglong *)(puVar47 + 0xe) != 0) &&
                         (*(ulonglong *)(puVar47 + 0xe) <
                          (ulonglong)uVar27 + *(longlong *)(puVar47 + 3))) {
                        *(undefined8 *)(puVar33 + -8) = 0x1037ec;
                        cVar3 = func_0x(0x112fe00);
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x1037f5;
                          lVar38 = func_0x();
                          if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar33 + -8) = 0x10380f;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x10382b;
                              (*_DAT_)(0x22,0x44,0x15,0x3fa);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x103851;
                              (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x886);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x10385f;
                        func_0x(uVar17,0x12);
                        uVar27 = *(uint *)(puVar47 + 1);
                      }
                      if (0x3f3b < uVar27 - 1) {
                        *(undefined8 *)(puVar33 + -8) = 0x103878;
                        cVar3 = func_0x(0x112fe00);
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x103881;
                          lVar38 = func_0x();
                          if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar33 + -8) = 0x10389b;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x1038b7;
                              (*_DAT_)(0x22,0x44,0x15,0x3ed);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x1038dd;
                              (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x88b);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x1038eb;
                        func_0x(uVar17,5);
                      }
                    }
LAB_:
                    *(undefined8 *)(puVar33 + -8) = 0x1038f3;
                    iVar45 = func_0x(puVar47);
                    if ((iVar45 == 0) && (uVar35 == 0)) goto LAB_;
                    bVar24 = **(byte **)(puVar47 + 3);
                    if ((bVar24 >> 6 & 1) != 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x103921;
                      func_0x(puVar47,&stack0x00000688 + lVar12);
                    }
                    if ((*(byte *)puVar47 & 1) != 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x10393a;
                      puVar14 = (undefined4 *)
                                func_0x(puVar47,0x400,&stack0x0000011c + lVar12);
                      *(undefined4 *)(&stack0x000001e8 + lVar12) = *puVar14;
                      *(undefined2 *)(&stack0x000001ec + lVar12) = *(undefined2 *)(puVar14 + 1);
                      *(undefined2 *)(&stack0x000001ee + lVar12) =
                           *(undefined2 *)((longlong)puVar14 + 6);
                    }
                    pbVar20 = *(byte **)(puVar47 + 3);
                    if ((*pbVar20 & 0x20) == 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x103969;
                      func_0x(puVar47);
                      pbVar20 = *(byte **)(puVar47 + 3);
                    }
                    uVar27 = *(uint *)(puVar47 + 9);
                    *(undefined8 *)(puVar33 + -8) = 0x10397c;
                    iVar45 = func_0x(puVar47);
                    lVar38 = *(longlong *)(puVar47 + 3);
                    uVar7 = puVar47[0xd];
                    uVar44 = (ulonglong)uVar7;
                    puVar46 = (ushort *)(lVar38 + (ulonglong)*(uint *)(puVar47 + 9));
                    uVar35 = (uint)uVar7;
                    if (iVar45 == 0) {
                      uVar41 = *(uint *)(puVar47 + 9) + 2 + (uint)uVar7 * 2;
                      uVar36 = 0;
                      if (*puVar46 != 0) {
                        do {
                          uVar8 = puVar46[(ulonglong)uVar36 + 1];
                          puVar46[(ulonglong)(uVar36 & 0xffff) + 1] =
                               puVar46[(ulonglong)(uVar36 & 0xffff) + 1] & 0x8000;
                          puVar46[(ulonglong)(uVar36 & 0xffff) + 1] =
                               puVar46[(ulonglong)(uVar36 & 0xffff) + 1] |
                               (uVar8 & 0x7fff) + 2 & 0x7fff;
                          uVar36 = uVar36 + 1;
                        } while (uVar36 < *puVar46);
                        lVar38 = *(longlong *)(puVar47 + 3);
                      }
                      lVar38 = (ulonglong)uVar41 + lVar38;
                      iVar45 = *(int *)(puVar47 + 1);
                      *(undefined8 *)(puVar33 + -8) = 0x103a56;
                      func_0x(lVar38 + 2,lVar38,iVar45 - uVar41);
                      *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + 2;
                      *(int *)(puVar47 + 0xb) = *(int *)(puVar47 + 0xb) + 2;
                      uVar8 = (ushort)*(undefined4 *)(puVar47 + 0xb);
                      if (uVar35 != 0) {
                        uVar8 = puVar46[(ulonglong)(uVar7 - 1) + 1] & 0x7fff;
                      }
                      if (uVar35 < uVar7 + 1) {
                        do {
                          puVar46[(uVar44 & 0xffff) + 1] = uVar8 & 0x7fff;
                          uVar35 = (int)uVar44 + 1;
                          uVar44 = (ulonglong)uVar35;
                        } while (uVar35 < uVar7 + 1);
                      }
                      *puVar46 = *puVar46 + 1;
                      *(undefined8 *)(puVar33 + -8) = 0x103a99;
                      func_0x(puVar47);
                      iVar34 = 0;
                      uVar7 = *(ushort *)
                               (pbVar20 + (ulonglong)puVar47[0xd] * 2 + (ulonglong)uVar27 + 2);
                      *(undefined8 *)(puVar33 + -8) = 0x103ab5;
                      func_0x(&stack0x00000350 + lVar12);
                      *(undefined4 *)(puVar33 + 0x28) = 0;
                      *(undefined8 *)(puVar33 + 0x20) =
                           *(undefined8 *)((longlong)&puStackX_20 + lVar12);
                      uVar35 = *puVar1;
                      *(undefined8 *)(puVar33 + -8) = 0x103ad9;
                      func_0x(&stack0x00000340 + lVar12,piVar28,uVar35,0);
                      *(undefined **)(puVar33 + 0x28) = &stack0x000001cc + lVar12;
                      *(undefined **)(puVar33 + 0x20) = &stack0x00000340 + lVar12;
                      *(undefined8 *)(puVar33 + -8) = 0x103b14;
                      func_0x(puVar47 + 0x14,uVar7 & 0x7fff,0x1f9e);
                      iVar45 = *(int *)(&stack0x000001cc + lVar12);
                    }
                    else {
                      if (uVar35 == 0) {
                        uVar35 = *(uint *)(puVar47 + 0xb);
                        uVar36 = puVar46[uVar44 + 1] & 0x7fff;
LAB_:
                        if ((uVar36 < uVar35) || (*(uint *)(puVar47 + 1) < uVar36))
                        goto LAB_;
                      }
                      else {
                        uVar35 = puVar46[uVar44] & 0x7fff;
                        uVar36 = puVar46[uVar44 + 1] & 0x7fff;
                        if (*(uint *)(puVar47 + 0xb) <= uVar35) goto LAB_;
LAB_:
                        *(undefined8 *)(puVar33 + -8) = 0x1039cf;
                        func_0x(lVar38,7);
                      }
                      iVar34 = uVar36 - uVar35;
                      uVar17 = *(undefined8 *)((longlong)&puStackX_20 + lVar12);
                      *(undefined8 *)(puVar33 + -8) = 0x1039e8;
                      iVar45 = func_0x(puVar47 + 0x14,uVar17,piVar28);
                    }
                    iVar34 = (iVar45 - iVar34) + *(int *)(puVar47 + 1);
                    *(int *)(puVar47 + 1) = iVar34;
                    if ((*(byte *)puVar47 & 1) != 0) {
                      *(ushort *)(pbVar20 + (ulonglong)puVar47[0xd] * 2 + (ulonglong)uVar27 + 4) =
                           (ushort)iVar34 | 0x8000;
                      iVar34 = (*(int *)(puVar47 + 1) - *(int *)(&stack0x0000011c + lVar12)) + -2;
                    }
                    *(ushort *)(pbVar20 + (ulonglong)puVar47[0xd] * 2 + (ulonglong)uVar27 + 2) =
                         (ushort)iVar34 | 0x8000;
                    if (iVar45 == 0) {
                      uVar7 = puVar47[0xd];
                      *(undefined8 *)(puVar33 + -8) = 0x103b69;
                      func_0x(puVar47,uVar7 + 1);
                      if ((**(byte **)(puVar47 + 3) & 0x20) != 0) {
                        puVar47[0xd] = puVar47[0xd] + 1;
                        *puVar47 = *puVar47 & 0xfffd;
                        *(undefined8 *)(puVar33 + -8) = 0x103b86;
                        func_0x(puVar47 + 0x14);
                      }
                    }
                    else {
                      *puVar47 = *puVar47 | 2;
                      *(undefined8 *)(puVar33 + -8) = 0x103b98;
                      uVar7 = func_0x(puVar47,&stack0x000002c4 + lVar12);
                      puVar47[0x14] = uVar7;
                    }
                    if ((*(byte *)puVar47 & 1) != 0) {
                      uVar42 = *(undefined4 *)(&stack0x0000011c + lVar12);
                      *(undefined8 *)(puVar33 + -8) = 0x103bbc;
                      func_0x(puVar47,0x400,uVar42);
                    }
                    if ((bVar24 >> 6 & 1) != 0) {
                      puVar19 = &stack0x00000688;
LAB_:
                      *(undefined8 *)(puVar33 + -8) = 0x102050;
                      func_0x(puVar47,(longlong)puVar19 + lVar12);
                    }
LAB_:
                    puVar31 = *(uint **)((longlong)&puStackX_20 + lVar12);
                    goto LAB_;
                  }
                  if (*(int *)(puVar47 + 1) == 0) {
                    *puVar47 = 0;
                    uVar36 = *(uint *)(puVar47 + 7);
                    uVar44 = (ulonglong)uVar36;
                    *(uint *)(puVar47 + 9) = uVar36;
                    pbVar20 = *(byte **)(puVar47 + 3);
                    bVar24 = *pbVar20;
                    if ((bVar24 & 0x10) != 0) {
                      uVar36 = uVar36 + (*(ushort *)(pbVar20 + uVar44) + 7 >> 3) + 2;
                      uVar44 = (ulonglong)uVar36;
                      *(uint *)(puVar47 + 9) = uVar36;
                      bVar24 = *pbVar20;
                    }
                    if ((bVar24 & 0x20) == 0) {
                      *(int *)(puVar47 + 1) = (int)uVar44;
                      puVar47[0xd] = 0;
                      *(uint *)(puVar47 + 0xb) = uVar36;
                    }
                    else {
                      puVar46 = (ushort *)(pbVar20 + uVar44);
                      *(ushort **)(&stack0x00000070 + lVar12) = puVar46;
                      uVar7 = *puVar46;
                      puVar47[0xd] = uVar7;
                      if (uVar7 == 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x10293d;
                        cVar3 = func_0x(0x112fe00);
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x102946;
                          lVar38 = func_0x();
                          if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar33 + -8) = 0x102960;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x10297c;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x1029a2;
                              (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x80f);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x1029b0;
                        func_0x(uVar17,3);
                        uVar7 = puVar47[0xd];
                        uVar36 = *(uint *)(puVar47 + 9);
                      }
                      uVar36 = uVar36 + (uVar7 + 1) * 2;
                      *(uint *)(puVar47 + 0xb) = uVar36;
                      if (0x1f9e < uVar36) {
                        *(undefined8 *)(puVar33 + -8) = 0x1029df;
                        cVar3 = func_0x(0x112fe00);
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x1029e8;
                          lVar38 = func_0x();
                          if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar33 + -8) = 0x102a02;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x102a1e;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x102a44;
                              (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x816);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x102a52;
                        func_0x(uVar17,4);
                        uVar7 = puVar47[0xd];
                        uVar36 = *(uint *)(puVar47 + 0xb);
                      }
                      uVar44 = (ulonglong)uVar7;
                      uVar7 = puVar46[uVar44];
                      *(uint *)(puVar47 + 1) = uVar7 & 0x7fff;
                      if ((uVar7 & 0x7fff) < uVar36) {
                        *(undefined8 *)(puVar33 + -8) = 0x102a83;
                        cVar3 = func_0x(0x112fe00);
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x102a8c;
                          lVar38 = func_0x();
                          if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar33 + -8) = 0x102aa6;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x102ac2;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x102ae8;
                              (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x81d);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x102af6;
                        func_0x(uVar17,4);
                        uVar36 = *(uint *)(puVar47 + 0xb);
                        uVar44 = (ulonglong)puVar47[0xd];
                      }
                      if ((short)uVar44 != 0) {
                        do {
                          puVar46 = puVar46 + 1;
                          uVar35 = *puVar46 & 0x7fff;
                          if ((uVar35 < uVar36) || (*(uint *)(puVar47 + 1) < uVar35)) {
                            *(undefined8 *)(puVar33 + -8) = 0x102b40;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x102b49;
                              lVar38 = func_0x();
                              if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar33 + -8) = 0x102b63;
                                cVar3 = func_0x(0x112fe00);
                                if (cVar3 == '\0') {
                                  *(undefined8 *)(puVar33 + -8) = 0x102b7f;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar33 + 0x20) = 0;
                                  *(undefined8 *)(puVar33 + -8) = 0x102ba3;
                                  (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x82a);
                                }
                              }
                            }
                            uVar17 = *(undefined8 *)(puVar47 + 3);
                            *(undefined8 *)(puVar33 + -8) = 0x102bb1;
                            func_0x(uVar17,4);
                          }
                          uVar27 = uVar27 + 1;
                          uVar44 = (ulonglong)puVar47[0xd];
                          uVar36 = uVar35;
                        } while ((int)uVar27 < (int)(uint)puVar47[0xd]);
                        puVar46 = *(ushort **)(&stack0x00000070 + lVar12);
                        uVar35 = *puVar1;
                      }
                      if ((short)puVar46[(ulonglong)((int)uVar44 - 1) + 1] < 0) {
                        do {
                          lVar38 = *(longlong *)(puVar47 + 3);
                          lVar15 = (ulonglong)*(uint *)(puVar47 + 9) + lVar38;
                          uVar27 = *(ushort *)(lVar15 + uVar44 * 2) & 0x7fff;
                          if ((int)uVar44 == 1) {
                            uVar36 = *(uint *)(puVar47 + 0xb);
                            uVar41 = uVar36;
LAB_:
                            if ((uVar27 < uVar36) || (*(uint *)(puVar47 + 1) < uVar27))
                            goto LAB_;
                          }
                          else {
                            uVar36 = *(ushort *)(lVar15 + -2 + uVar44 * 2) & 0x7fff;
                            uVar41 = *(uint *)(puVar47 + 0xb);
                            if (uVar41 <= uVar36) goto LAB_;
LAB_:
                            *(undefined8 *)(puVar33 + -8) = 0x102c35;
                            func_0x(lVar38,7);
                            uVar41 = *(uint *)(puVar47 + 0xb);
                          }
                          if ((uVar36 < uVar41) || (*(uint *)(puVar47 + 1) < uVar36)) {
                            puVar31 = *(uint **)((longlong)&puStackX_20 + lVar12);
                            goto LAB_;
                          }
                          if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(puVar47 + 3)) == 5) {
                            *puVar47 = *puVar47 | 2;
                            puVar47[0xd] = puVar47[0xd] - 1;
                            puVar47[0x14] = (ushort)uVar36;
                            uVar44 = *(ulonglong *)(puVar47 + 3);
                            uVar7 = *(ushort *)((ulonglong)(uVar36 & 0xffff) + 2 + uVar44);
                            uVar8 = puVar47[0x15] & 0xc7ff;
                            if ((uVar7 >> 0xe & 1) != 0) {
                              uVar8 = uVar7 & 0x3800 | uVar8;
                            }
                            puVar47[0x15] = uVar8;
                            uVar7 = (uVar8 ^ *(ushort *)((ulonglong)(uVar36 & 0xffff) + 2 + uVar44))
                                    & 0x7ff ^ uVar8;
                            puVar47[0x15] = uVar7;
                            uVar30 = (ulonglong)puVar47[0x14];
                            uVar39 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 +
                                     uVar44 + (uVar8 >> 0xb & 7) * 2 + uVar30;
                            if (uVar39 < uVar30 + uVar44) {
                              *(undefined8 *)(puVar33 + -8) = 0x102d4c;
                              func_0x(uVar30 + uVar44,0x19);
                              uVar7 = puVar47[0x15];
                              uVar30 = (ulonglong)puVar47[0x14];
                              uVar44 = (ulonglong)*(uint *)(puVar47 + 3);
                            }
                            if (uVar27 - uVar36 <
                                (((uVar7 & 0x7ff) * 2 - (int)uVar30) - (int)uVar44) + (int)uVar39) {
                              lVar38 = *(longlong *)(puVar47 + 3);
                              *(undefined8 *)(puVar33 + -8) = 0x102d84;
                              func_0x(uVar30 + lVar38,0x19);
                              uVar7 = puVar47[0x15];
                            }
                            if ((uVar7 & 0x3800) != 0) {
                              puVar46 = (ushort *)
                                        (*(longlong *)(puVar47 + 3) + (ulonglong)puVar47[0x14] + 4);
                              iVar45 = 0;
                              if ((uVar7 & 0x3800) != 0) {
                                do {
                                  if ((uVar7 & 0x7ff) < (*puVar46 & 0x7ff)) {
                                    uVar7 = puVar47[0x14];
                                    lVar38 = *(longlong *)(puVar47 + 3);
                                    *(undefined8 *)(puVar33 + -8) = 0x102dd7;
                                    func_0x((ulonglong)uVar7 + lVar38,0x1a);
                                    uVar7 = puVar47[0x15];
                                  }
                                  iVar45 = iVar45 + 1;
                                  puVar46 = puVar46 + 1;
                                } while (iVar45 < (int)(uVar7 >> 0xb & 7));
                              }
                            }
                            goto LAB_;
                          }
                          if (*(ushort *)((ulonglong)uVar36 + *(longlong *)(puVar47 + 3)) < 0x400)
                          goto LAB_;
                          *puVar47 = *puVar47 | 1;
                          uVar7 = puVar47[0xd] - 1;
                          puVar47[0xd] = uVar7;
                          if (uVar7 == 0) goto LAB_;
                          uVar44 = (ulonglong)uVar7;
                        } while ((short)puVar46[(ulonglong)(uVar7 - 1) + 1] < 0);
                        pbVar20 = *(byte **)(puVar47 + 3);
                        puVar31 = *(uint **)((longlong)&puStackX_20 + lVar12);
                      }
                      else {
LAB_:
                        pbVar20 = *(byte **)(puVar47 + 3);
                        puVar31 = *(uint **)((longlong)&puStackX_20 + lVar12);
                      }
                    }
                    if ((*pbVar20 & 0x40) == 0) {
                      *(undefined4 *)(puVar47 + 0x12) = 0;
                    }
                    else {
                      *(int *)(puVar47 + 0x12) = *(int *)(puVar47 + 1);
                      *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + 0xe;
                      *(undefined8 *)(puVar33 + -8) = 0x102e22;
                      uVar17 = func_0x(puVar47);
                      *(undefined8 *)(puVar33 + -8) = 0x102e31;
                      func_0x(uVar17,&stack0x00000240 + lVar12);
                      *(undefined8 *)(puVar33 + -8) = 0x102e3d;
                      iVar45 = func_0x(&stack0x00000240 + lVar12);
                      *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + iVar45;
                    }
                    uVar27 = *(uint *)(puVar47 + 1);
                    if ((*(ulonglong *)(puVar47 + 0xe) != 0) &&
                       (*(ulonglong *)(puVar47 + 0xe) <
                        (ulonglong)uVar27 + *(longlong *)(puVar47 + 3))) {
                      *(undefined8 *)(puVar33 + -8) = 0x102e70;
                      cVar3 = func_0x(0x112fe00);
                      if (cVar3 != '\0') {
                        *(undefined8 *)(puVar33 + -8) = 0x102e79;
                        lVar38 = func_0x();
                        if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar33 + -8) = 0x102e93;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 == '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x102eaf;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar33 + 0x20) = 0;
                            *(undefined8 *)(puVar33 + -8) = 0x102ed5;
                            (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(puVar47 + 3);
                      *(undefined8 *)(puVar33 + -8) = 0x102ee3;
                      func_0x(uVar17,0x12);
                      uVar27 = *(uint *)(puVar47 + 1);
                    }
                    if (0x3f3b < uVar27 - 1) {
                      *(undefined8 *)(puVar33 + -8) = 0x102f00;
                      cVar3 = func_0x(0x112fe00);
                      if (cVar3 != '\0') {
                        *(undefined8 *)(puVar33 + -8) = 0x102f09;
                        lVar38 = func_0x();
                        if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar33 + -8) = 0x102f23;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 == '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x102f3f;
                            (*_DAT_)(0x22,0x44,0x15);
                            uVar17 = *(undefined8 *)(puVar47 + 3);
                            *(undefined8 *)(puVar33 + -8) = 0x102f4d;
                            func_0x(uVar17,5);
                            goto LAB_;
                          }
                          *(undefined8 *)(puVar33 + 0x20) = 0;
                          *(undefined8 *)(puVar33 + -8) = 0x102f73;
                          (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                        }
                      }
                      uVar17 = *(undefined8 *)(puVar47 + 3);
                      *(undefined8 *)(puVar33 + -8) = 0x102f81;
                      func_0x(uVar17,5);
                    }
                  }
LAB_:
                  uVar27 = -*puVar31;
                  if ((uVar35 == 0) && (puVar47[0xd] < uVar27)) goto LAB_;
                  *(undefined8 *)(puVar33 + -8) = 0x102fab;
                  func_0x(&stack0x000005a8 + lVar12);
                  pbVar20 = *(byte **)(puVar47 + 3);
                  bVar24 = *pbVar20;
                  *(uint *)(&stack0x00000098 + lVar12) = bVar24 >> 6 & 1;
                  if ((bVar24 >> 6 & 1) != 0) {
                    *(undefined8 *)(puVar33 + -8) = 0x102fd2;
                    func_0x(puVar47,&stack0x000005a8 + lVar12);
                    pbVar20 = *(byte **)(puVar47 + 3);
                  }
                  if (uVar35 != 0) {
                    if ((*pbVar20 & 0x20) == 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x102fef;
                      func_0x(puVar47);
                      pbVar20 = *(byte **)(puVar47 + 3);
                    }
                    uVar7 = puVar47[0xd];
                    uVar35 = (uint)uVar7;
                    if (uVar7 < uVar27) {
                      iVar45 = uVar27 - uVar7;
                      puVar46 = (ushort *)(pbVar20 + *(uint *)(puVar47 + 9));
                      uVar36 = *(uint *)(puVar47 + 9) + 2 + uVar35 * 2;
                      uVar41 = iVar45 * 2;
                      uVar26 = 0;
                      if (*puVar46 != 0) {
                        do {
                          uVar7 = puVar46[(ulonglong)uVar26 + 1];
                          puVar46[(ulonglong)(uVar26 & 0xffff) + 1] =
                               puVar46[(ulonglong)(uVar26 & 0xffff) + 1] & 0x8000;
                          puVar46[(ulonglong)(uVar26 & 0xffff) + 1] =
                               puVar46[(ulonglong)(uVar26 & 0xffff) + 1] |
                               (uVar7 & 0x7fff) + (short)uVar41 & 0x7fff;
                          uVar26 = uVar26 + 1;
                        } while (uVar26 < *puVar46);
                        pbVar20 = *(byte **)(puVar47 + 3);
                      }
                      iVar34 = *(int *)(puVar47 + 1);
                      *(undefined8 *)(puVar33 + -8) = 0x10307c;
                      func_0x
                                (pbVar20 + (ulonglong)uVar41 + (ulonglong)uVar36,pbVar20 + uVar36,
                                 iVar34 - uVar36);
                      *(uint *)(puVar47 + 1) = *(int *)(puVar47 + 1) + uVar41;
                      *(uint *)(puVar47 + 0xb) = *(int *)(puVar47 + 0xb) + uVar41;
                      uVar7 = (ushort)*(undefined4 *)(puVar47 + 0xb);
                      if (uVar35 != 0) {
                        uVar7 = puVar46[(ulonglong)(uVar35 - 1) + 1] & 0x7fff;
                      }
                      do {
                        puVar46[(ulonglong)(uVar35 & 0xffff) + 1] = uVar7 & 0x7fff;
                        uVar35 = uVar35 + 1;
                      } while (uVar35 < uVar27);
                      *puVar46 = *puVar46 + (short)iVar45;
                      *(undefined8 *)(puVar33 + -8) = 0x1030bb;
                      iVar45 = func_0x(puVar47);
                      if (iVar45 != 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x1030ce;
                        uVar7 = func_0x(puVar47,&stack0x00000298 + lVar12);
                        puVar47[0x14] = uVar7;
                      }
                      puVar47[0xd] = (ushort)uVar27;
                      pbVar20 = *(byte **)(puVar47 + 3);
                    }
                  }
                  uVar35 = *(uint *)(puVar47 + 9);
                  if (puVar47[0xd] < uVar27) {
                    uVar35 = *(ushort *)(pbVar20 + (ulonglong)puVar47[0xd] * 2 + (ulonglong)uVar35)
                             & 0x7fff;
                    uVar36 = 0;
                  }
                  else {
                    uVar36 = *(ushort *)(pbVar20 + (longlong)(int)uVar27 * 2 + (ulonglong)uVar35) &
                             0x7fff;
                    if (uVar27 == 1) {
                      uVar35 = *(uint *)(puVar47 + 0xb);
LAB_:
                      if ((uVar36 < uVar35) || (*(uint *)(puVar47 + 1) < uVar36)) goto LAB_;
                    }
                    else {
                      uVar35 = *(ushort *)
                                (pbVar20 + (longlong)(int)uVar27 * 2 + ((ulonglong)uVar35 - 2)) &
                               0x7fff;
                      if (*(uint *)(puVar47 + 0xb) <= uVar35) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar33 + -8) = 0x10312e;
                      func_0x(pbVar20,7);
                      pbVar20 = *(byte **)(puVar47 + 3);
                    }
                    uVar36 = uVar36 - uVar35;
                  }
                  if (*puVar1 != uVar36) {
                    puVar46 = (ushort *)(pbVar20 + *(uint *)(puVar47 + 9));
                    lVar38 = *(longlong *)(puVar47 + 3);
                    uVar42 = *(undefined4 *)(puVar47 + 1);
                    *(undefined8 *)(puVar33 + -8) = 0x103166;
                    uVar42 = func_0x(uVar42,uVar35 + uVar36);
                    uVar41 = *puVar1;
                    *(undefined8 *)(puVar33 + -8) = 0x103181;
                    func_0x
                              ((int)uVar41 + lVar38 + (ulonglong)uVar35,
                               (int)uVar36 + lVar38 + (ulonglong)uVar35,uVar42);
                    uVar41 = uVar27 - 1;
                    if ((int)uVar41 < (int)(uint)*puVar46) {
                      uVar26 = *puVar1;
                      do {
                        uVar7 = puVar46[(longlong)(int)uVar41 + 1];
                        puVar46[((ulonglong)uVar41 & 0xffff) + 1] =
                             puVar46[((ulonglong)uVar41 & 0xffff) + 1] & 0x8000;
                        puVar46[((ulonglong)uVar41 & 0xffff) + 1] =
                             puVar46[((ulonglong)uVar41 & 0xffff) + 1] |
                             ((uVar7 & 0x7fff) - (short)uVar36) + (short)uVar26 & 0x7fff;
                        uVar41 = uVar41 + 1;
                      } while ((int)uVar41 < (int)(uint)*puVar46);
                      puVar47 = *(ushort **)(&stack0x000000a0 + lVar12);
                    }
                    *(uint *)(puVar47 + 1) = *(int *)(puVar47 + 1) + (*puVar1 - uVar36);
                    *(undefined8 *)(puVar33 + -8) = 0x1031e9;
                    iVar45 = func_0x(puVar47);
                    if (iVar45 != 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x1031fc;
                      uVar7 = func_0x(puVar47,&stack0x000002c8 + lVar12);
                      puVar47[0x14] = uVar7;
                    }
                  }
                  uVar36 = *puVar1;
                  lVar38 = *(longlong *)(puVar47 + 3);
                  uVar17 = *(undefined8 *)(&stack0x00000028 + lVar12);
                  *(undefined8 *)(puVar33 + -8) = 0x103217;
                  func_0x((ulonglong)uVar35 + lVar38,uVar17,uVar36);
                  if ((uVar36 == 0) && (uVar27 == puVar47[0xd])) {
                    *(undefined8 *)(puVar33 + -8) = 0x103234;
                    func_0x(puVar47,uVar27,1);
                  }
                  if (*(int *)(&stack0x00000098 + lVar12) != 0) {
                    puVar19 = &stack0x000005a8;
                    goto LAB_;
                  }
LAB_:
                  puVar31 = *(uint **)((longlong)&puStackX_20 + lVar12);
                }
                else if (cVar3 == '\b') {
                  pcVar40 = *(char **)(&stack0x000001a8 + lVar12);
                  *(char **)(&stack0x00000028 + lVar12) = pcVar40;
                  uVar35 = *puVar31;
                  lVar38 = (longlong)(int)uVar35;
                  if ((int)uVar35 < 0) {
                    if ((uVar35 & 0xc0000000) == 0x80000000) {
                      *(undefined8 *)(puVar33 + -8) = 0x1016df;
                      func_0x(&stack0x000004c8 + lVar12);
                      *(undefined4 *)(&stack0x00000118 + lVar12) = 0;
                      if (*(int *)(puVar47 + 1) == 0) {
                        *puVar47 = 0;
                        uVar35 = *(uint *)(puVar47 + 7);
                        uVar44 = (ulonglong)uVar35;
                        *(uint *)(puVar47 + 9) = uVar35;
                        pbVar20 = *(byte **)(puVar47 + 3);
                        bVar24 = *pbVar20;
                        pbVar13 = pbVar20;
                        if ((bVar24 & 0x10) != 0) {
                          uVar35 = uVar35 + (*(ushort *)(pbVar20 + uVar44) + 7 >> 3) + 2;
                          uVar44 = (ulonglong)uVar35;
                          *(uint *)(puVar47 + 9) = uVar35;
                          bVar24 = *pbVar20;
                          pbVar13 = *(byte **)(puVar47 + 3);
                        }
                        if ((bVar24 & 0x20) == 0) {
                          *(int *)(puVar47 + 1) = (int)uVar44;
                          puVar47[0xd] = 0;
                          *(uint *)(puVar47 + 0xb) = uVar35;
                        }
                        else {
                          puVar46 = (ushort *)(pbVar20 + uVar44);
                          *(ushort **)(&stack0x00000070 + lVar12) = puVar46;
                          uVar7 = *puVar46;
                          puVar47[0xd] = uVar7;
                          if (uVar7 == 0) {
                            *(undefined8 *)(puVar33 + -8) = 0x101755;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x10175e;
                              lVar38 = func_0x();
                              if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar33 + -8) = 0x101778;
                                cVar3 = func_0x(0x112fe00);
                                if (cVar3 == '\0') {
                                  *(undefined8 *)(puVar33 + -8) = 0x101794;
                                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                }
                                else {
                                  *(undefined8 *)(puVar33 + 0x20) = 0;
                                  *(undefined8 *)(puVar33 + -8) = 0x1017ba;
                                  (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x80f);
                                }
                              }
                            }
                            uVar17 = *(undefined8 *)(puVar47 + 3);
                            *(undefined8 *)(puVar33 + -8) = 0x1017c8;
                            func_0x(uVar17,3);
                            uVar7 = puVar47[0xd];
                            uVar35 = *(uint *)(puVar47 + 9);
                          }
                          uVar35 = uVar35 + (uVar7 + 1) * 2;
                          *(uint *)(puVar47 + 0xb) = uVar35;
                          if (0x1f9e < uVar35) {
                            *(undefined8 *)(puVar33 + -8) = 0x1017f7;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x101800;
                              lVar38 = func_0x();
                              if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar33 + -8) = 0x10181a;
                                cVar3 = func_0x(0x112fe00);
                                if (cVar3 == '\0') {
                                  *(undefined8 *)(puVar33 + -8) = 0x101836;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar33 + 0x20) = 0;
                                  *(undefined8 *)(puVar33 + -8) = 0x10185c;
                                  (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x816);
                                }
                              }
                            }
                            uVar17 = *(undefined8 *)(puVar47 + 3);
                            *(undefined8 *)(puVar33 + -8) = 0x10186a;
                            func_0x(uVar17,4);
                            uVar7 = puVar47[0xd];
                            uVar35 = *(uint *)(puVar47 + 0xb);
                          }
                          uVar44 = (ulonglong)uVar7;
                          uVar7 = puVar46[uVar44];
                          *(uint *)(puVar47 + 1) = uVar7 & 0x7fff;
                          if ((uVar7 & 0x7fff) < uVar35) {
                            *(undefined8 *)(puVar33 + -8) = 0x101895;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x10189e;
                              lVar38 = func_0x();
                              if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar33 + -8) = 0x1018b8;
                                cVar3 = func_0x(0x112fe00);
                                if (cVar3 == '\0') {
                                  *(undefined8 *)(puVar33 + -8) = 0x1018d4;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar33 + 0x20) = 0;
                                  *(undefined8 *)(puVar33 + -8) = 0x1018fa;
                                  (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x81d);
                                }
                              }
                            }
                            uVar17 = *(undefined8 *)(puVar47 + 3);
                            *(undefined8 *)(puVar33 + -8) = 0x101908;
                            func_0x(uVar17,4);
                            uVar35 = *(uint *)(puVar47 + 0xb);
                            uVar44 = (ulonglong)puVar47[0xd];
                          }
                          if ((short)uVar44 != 0) {
                            do {
                              puVar46 = puVar46 + 1;
                              uVar36 = *puVar46 & 0x7fff;
                              if ((uVar36 < uVar35) || (*(uint *)(puVar47 + 1) < uVar36)) {
                                *(undefined8 *)(puVar33 + -8) = 0x10194c;
                                cVar3 = func_0x(0x112fe00);
                                if (cVar3 != '\0') {
                                  *(undefined8 *)(puVar33 + -8) = 0x101955;
                                  lVar38 = func_0x();
                                  if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                                    *(undefined8 *)(puVar33 + -8) = 0x10196f;
                                    cVar3 = func_0x(0x112fe00);
                                    if (cVar3 == '\0') {
                                      *(undefined8 *)(puVar33 + -8) = 0x10198b;
                                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                    }
                                    else {
                                      *(undefined8 *)(puVar33 + 0x20) = 0;
                                      *(undefined8 *)(puVar33 + -8) = 0x1019af;
                                      (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x82a);
                                    }
                                  }
                                }
                                uVar17 = *(undefined8 *)(puVar47 + 3);
                                *(undefined8 *)(puVar33 + -8) = 0x1019bd;
                                func_0x(uVar17,4);
                              }
                              uVar27 = uVar27 + 1;
                              uVar44 = (ulonglong)puVar47[0xd];
                              uVar35 = uVar36;
                            } while ((int)uVar27 < (int)(uint)puVar47[0xd]);
                            puVar46 = *(ushort **)(&stack0x00000070 + lVar12);
                            pcVar40 = *(char **)(&stack0x00000028 + lVar12);
                          }
                          if ((short)puVar46[(ulonglong)((int)uVar44 - 1) + 1] < 0) {
                            do {
                              lVar38 = *(longlong *)(puVar47 + 3);
                              uVar27 = *(ushort *)
                                        ((ulonglong)*(uint *)(puVar47 + 9) + lVar38 + uVar44 * 2) &
                                       0x7fff;
                              if ((int)uVar44 == 1) {
                                uVar35 = *(uint *)(puVar47 + 0xb);
                                uVar36 = uVar35;
LAB_:
                                if ((uVar27 < uVar35) ||
                                   (uVar41 = *(uint *)(puVar47 + 1), uVar41 < uVar27))
                                goto LAB_;
                              }
                              else {
                                uVar35 = *(ushort *)
                                          ((ulonglong)*(uint *)(puVar47 + 9) + lVar38 + -2 +
                                          uVar44 * 2) & 0x7fff;
                                uVar36 = *(uint *)(puVar47 + 0xb);
                                if (uVar36 <= uVar35) goto LAB_;
LAB_:
                                *(undefined8 *)(puVar33 + -8) = 0x101a37;
                                func_0x(lVar38,7);
                                uVar36 = *(uint *)(puVar47 + 0xb);
                                uVar41 = *(uint *)(puVar47 + 1);
                                lVar38 = *(longlong *)(puVar47 + 3);
                              }
                              if ((uVar35 < uVar36) || (uVar41 < uVar35)) goto LAB_;
                              if (*(ushort *)((ulonglong)uVar35 + lVar38) == 5) {
                                *puVar47 = *puVar47 | 2;
                                puVar47[0xd] = puVar47[0xd] - 1;
                                puVar47[0x14] = (ushort)uVar35;
                                uVar44 = *(ulonglong *)(puVar47 + 3);
                                uVar7 = *(ushort *)((ulonglong)(uVar35 & 0xffff) + 2 + uVar44);
                                uVar8 = puVar47[0x15] & 0xc7ff;
                                if ((uVar7 >> 0xe & 1) != 0) {
                                  uVar8 = uVar7 & 0x3800 | uVar8;
                                }
                                puVar47[0x15] = uVar8;
                                uVar7 = (uVar8 ^ *(ushort *)
                                                  ((ulonglong)(uVar35 & 0xffff) + 2 + uVar44)) &
                                        0x7ff ^ uVar8;
                                puVar47[0x15] = uVar7;
                                uVar30 = (ulonglong)puVar47[0x14];
                                uVar39 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 +
                                         uVar30 + (uVar8 >> 0xb & 7) * 2 + uVar44;
                                if (uVar39 < uVar30 + uVar44) {
                                  *(undefined8 *)(puVar33 + -8) = 0x101b4a;
                                  func_0x(uVar30 + uVar44,0x19);
                                  uVar7 = puVar47[0x15];
                                  uVar30 = (ulonglong)puVar47[0x14];
                                  uVar44 = (ulonglong)*(uint *)(puVar47 + 3);
                                }
                                if (uVar27 - uVar35 <
                                    (((uVar7 & 0x7ff) * 2 - (int)uVar30) - (int)uVar44) +
                                    (int)uVar39) {
                                  lVar38 = *(longlong *)(puVar47 + 3);
                                  *(undefined8 *)(puVar33 + -8) = 0x101b82;
                                  func_0x(uVar30 + lVar38,0x19);
                                  uVar7 = puVar47[0x15];
                                }
                                if ((uVar7 & 0x3800) != 0) {
                                  puVar46 = (ushort *)
                                            (*(longlong *)(puVar47 + 3) +
                                            (ulonglong)puVar47[0x14] + 4);
                                  iVar45 = 0;
                                  if ((uVar7 & 0x3800) != 0) {
                                    do {
                                      if ((uVar7 & 0x7ff) < (*puVar46 & 0x7ff)) {
                                        uVar7 = puVar47[0x14];
                                        lVar38 = *(longlong *)(puVar47 + 3);
                                        *(undefined8 *)(puVar33 + -8) = 0x101bd7;
                                        func_0x((ulonglong)uVar7 + lVar38,0x1a);
                                        uVar7 = puVar47[0x15];
                                      }
                                      iVar45 = iVar45 + 1;
                                      puVar46 = puVar46 + 1;
                                    } while (iVar45 < (int)(uVar7 >> 0xb & 7));
                                  }
                                }
                                goto LAB_;
                              }
                              if (*(ushort *)((ulonglong)uVar35 + lVar38) < 0x400)
                              goto LAB_;
                              *puVar47 = *puVar47 | 1;
                              uVar7 = puVar47[0xd] - 1;
                              puVar47[0xd] = uVar7;
                              if (uVar7 == 0) goto LAB_;
                              uVar44 = (ulonglong)uVar7;
                            } while ((short)puVar46[(ulonglong)(uVar7 - 1) + 1] < 0);
                            pbVar13 = *(byte **)(puVar47 + 3);
                            uVar44 = (ulonglong)*(uint *)(puVar47 + 1);
                          }
                          else {
LAB_:
                            pbVar13 = *(byte **)(puVar47 + 3);
                            uVar44 = (ulonglong)*(uint *)(puVar47 + 1);
                          }
                        }
                        if ((*pbVar13 & 0x40) == 0) {
                          *(undefined4 *)(puVar47 + 0x12) = 0;
                        }
                        else {
                          *(int *)(puVar47 + 0x12) = (int)uVar44;
                          *(int *)(puVar47 + 1) = (int)uVar44 + 0xe;
                          *(undefined8 *)(puVar33 + -8) = 0x101c1e;
                          uVar17 = func_0x(puVar47);
                          *(undefined8 *)(puVar33 + -8) = 0x101c2d;
                          func_0x(uVar17,&stack0x00000230 + lVar12);
                          *(undefined8 *)(puVar33 + -8) = 0x101c39;
                          iVar45 = func_0x(&stack0x00000230 + lVar12);
                          *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + iVar45;
                          uVar44 = (ulonglong)*(uint *)(puVar47 + 1);
                          pbVar13 = *(byte **)(puVar47 + 3);
                        }
                        iVar45 = (int)uVar44;
                        if ((*(byte **)(puVar47 + 0xe) != (byte *)0x0) &&
                           (*(byte **)(puVar47 + 0xe) < pbVar13 + uVar44)) {
                          *(undefined8 *)(puVar33 + -8) = 0x101c71;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x101c7a;
                            lVar38 = func_0x();
                            if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar33 + -8) = 0x101c94;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x101cb0;
                                (*_DAT_)(0x22,0x44,0x15,0x3fa);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x101cd6;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x886);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x101ce4;
                          func_0x(uVar17,0x12);
                          iVar45 = *(int *)(puVar47 + 1);
                        }
                        if (0x3f3b < iVar45 - 1U) {
                          *(undefined8 *)(puVar33 + -8) = 0x101cfd;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x101d06;
                            lVar38 = func_0x();
                            if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar33 + -8) = 0x101d20;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x101d3c;
                                (*_DAT_)(0x22,0x44,0x15,0x3ed);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x101d62;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x88b);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x101d70;
                          func_0x(uVar17,5);
                        }
                      }
LAB_:
                      *(undefined8 *)(puVar33 + -8) = 0x101d78;
                      func_0x(puVar47);
                      bVar24 = **(byte **)(puVar47 + 3);
                      if ((bVar24 >> 6 & 1) != 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x101d99;
                        func_0x(puVar47,&stack0x000004c8 + lVar12);
                      }
                      if ((*(byte *)puVar47 & 1) != 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x101db2;
                        puVar14 = (undefined4 *)
                                  func_0x(puVar47,0x400,&stack0x00000118 + lVar12);
                        *(undefined4 *)(&stack0x000001f0 + lVar12) = *puVar14;
                        *(undefined2 *)(&stack0x000001f4 + lVar12) = *(undefined2 *)(puVar14 + 1);
                        *(undefined2 *)(&stack0x000001f6 + lVar12) =
                             *(undefined2 *)((longlong)puVar14 + 6);
                      }
                      pbVar20 = *(byte **)(puVar47 + 3);
                      if ((*pbVar20 & 0x20) == 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x101de1;
                        func_0x(puVar47);
                        pbVar20 = *(byte **)(puVar47 + 3);
                      }
                      uVar27 = *(uint *)(puVar47 + 9);
                      *(undefined8 *)(puVar33 + -8) = 0x101df4;
                      iVar45 = func_0x(puVar47);
                      lVar38 = *(longlong *)(puVar47 + 3);
                      uVar7 = puVar47[0xd];
                      uVar44 = (ulonglong)uVar7;
                      puVar46 = (ushort *)(lVar38 + (ulonglong)*(uint *)(puVar47 + 9));
                      uVar35 = (uint)uVar7;
                      if (iVar45 == 0) {
                        uVar41 = *(uint *)(puVar47 + 9) + 2 + (uint)uVar7 * 2;
                        uVar36 = 0;
                        if (*puVar46 != 0) {
                          do {
                            uVar8 = puVar46[(ulonglong)uVar36 + 1];
                            puVar46[(ulonglong)(uVar36 & 0xffff) + 1] =
                                 puVar46[(ulonglong)(uVar36 & 0xffff) + 1] & 0x8000;
                            puVar46[(ulonglong)(uVar36 & 0xffff) + 1] =
                                 puVar46[(ulonglong)(uVar36 & 0xffff) + 1] |
                                 (uVar8 & 0x7fff) + 2 & 0x7fff;
                            uVar36 = uVar36 + 1;
                          } while (uVar36 < *puVar46);
                          lVar38 = *(longlong *)(puVar47 + 3);
                        }
                        lVar38 = (ulonglong)uVar41 + lVar38;
                        iVar45 = *(int *)(puVar47 + 1);
                        *(undefined8 *)(puVar33 + -8) = 0x101ed6;
                        func_0x(lVar38 + 2,lVar38,iVar45 - uVar41);
                        *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + 2;
                        *(int *)(puVar47 + 0xb) = *(int *)(puVar47 + 0xb) + 2;
                        uVar8 = (ushort)*(undefined4 *)(puVar47 + 0xb);
                        if (uVar35 != 0) {
                          uVar8 = puVar46[(ulonglong)(uVar7 - 1) + 1] & 0x7fff;
                        }
                        if (uVar35 < uVar7 + 1) {
                          do {
                            puVar46[(uVar44 & 0xffff) + 1] = uVar8 & 0x7fff;
                            uVar35 = (int)uVar44 + 1;
                            uVar44 = (ulonglong)uVar35;
                          } while (uVar35 < uVar7 + 1);
                        }
                        *puVar46 = *puVar46 + 1;
                        *(undefined8 *)(puVar33 + -8) = 0x101f19;
                        func_0x(puVar47);
                        iVar34 = 0;
                        uVar7 = *(ushort *)
                                 (pbVar20 + (ulonglong)puVar47[0xd] * 2 + (ulonglong)uVar27 + 2);
                        *(undefined8 *)(puVar33 + -8) = 0x101f35;
                        func_0x(&stack0x00000390 + lVar12);
                        *(undefined4 *)(puVar33 + 0x28) = 0;
                        *(undefined8 *)(puVar33 + 0x20) =
                             *(undefined8 *)((longlong)&puStackX_20 + lVar12);
                        *(undefined8 *)(puVar33 + -8) = 0x101f59;
                        func_0x(&stack0x00000380 + lVar12,pcVar40,1,0);
                        *(undefined **)(puVar33 + 0x28) = &stack0x000001c8 + lVar12;
                        *(undefined **)(puVar33 + 0x20) = &stack0x00000380 + lVar12;
                        *(undefined8 *)(puVar33 + -8) = 0x101f94;
                        func_0x(puVar47 + 0x14,uVar7 & 0x7fff,0x1f9e);
                        iVar45 = *(int *)(&stack0x000001c8 + lVar12);
                      }
                      else {
                        if (uVar35 == 0) {
                          uVar35 = *(uint *)(puVar47 + 0xb);
                          uVar36 = puVar46[uVar44 + 1] & 0x7fff;
LAB_:
                          if ((uVar36 < uVar35) || (*(uint *)(puVar47 + 1) < uVar36))
                          goto LAB_;
                        }
                        else {
                          uVar35 = puVar46[uVar44] & 0x7fff;
                          uVar36 = puVar46[uVar44 + 1] & 0x7fff;
                          if (*(uint *)(puVar47 + 0xb) <= uVar35) goto LAB_;
LAB_:
                          *(undefined8 *)(puVar33 + -8) = 0x101e47;
                          func_0x(lVar38,7);
                        }
                        iVar34 = uVar36 - uVar35;
                        uVar17 = *(undefined8 *)((longlong)&puStackX_20 + lVar12);
                        *(undefined8 *)(puVar33 + -8) = 0x101e62;
                        iVar45 = func_0x(puVar47 + 0x14,uVar17,pcVar40);
                      }
                      iVar34 = (*(int *)(puVar47 + 1) - iVar34) + iVar45;
                      *(int *)(puVar47 + 1) = iVar34;
                      if ((*(byte *)puVar47 & 1) != 0) {
                        *(ushort *)(pbVar20 + (ulonglong)puVar47[0xd] * 2 + (ulonglong)uVar27 + 4) =
                             (ushort)iVar34 | 0x8000;
                        iVar34 = (*(int *)(puVar47 + 1) - *(int *)(&stack0x00000118 + lVar12)) + -2;
                      }
                      *(ushort *)(pbVar20 + (ulonglong)puVar47[0xd] * 2 + (ulonglong)uVar27 + 2) =
                           (ushort)iVar34 | 0x8000;
                      if (iVar45 == 0) {
                        uVar7 = puVar47[0xd];
                        *(undefined8 *)(puVar33 + -8) = 0x101fe9;
                        func_0x(puVar47,uVar7 + 1,0);
                        if ((**(byte **)(puVar47 + 3) & 0x20) != 0) {
                          puVar47[0xd] = puVar47[0xd] + 1;
                          *puVar47 = *puVar47 & 0xfffd;
                          *(undefined8 *)(puVar33 + -8) = 0x102006;
                          func_0x(puVar47 + 0x14);
                        }
                      }
                      else {
                        *puVar47 = *puVar47 | 2;
                        *(undefined8 *)(puVar33 + -8) = 0x102018;
                        uVar7 = func_0x(puVar47,&stack0x00000210 + lVar12);
                        puVar47[0x14] = uVar7;
                      }
                      if ((*(byte *)puVar47 & 1) != 0) {
                        uVar42 = *(undefined4 *)(&stack0x00000118 + lVar12);
                        *(undefined8 *)(puVar33 + -8) = 0x10203c;
                        func_0x(puVar47,0x400,uVar42);
                      }
                      if ((bVar24 >> 6 & 1) != 0) {
                        puVar19 = &stack0x000004c8;
                        goto LAB_;
                      }
                      goto LAB_;
                    }
                    if (*(int *)(puVar47 + 1) == 0) {
                      *puVar47 = 0;
                      uVar35 = *(uint *)(puVar47 + 7);
                      uVar44 = (ulonglong)uVar35;
                      *(uint *)(puVar47 + 9) = uVar35;
                      pbVar20 = *(byte **)(puVar47 + 3);
                      bVar24 = *pbVar20;
                      pbVar13 = pbVar20;
                      if ((bVar24 & 0x10) != 0) {
                        uVar35 = uVar35 + (*(ushort *)(pbVar20 + uVar44) + 7 >> 3) + 2;
                        uVar44 = (ulonglong)uVar35;
                        *(uint *)(puVar47 + 9) = uVar35;
                        bVar24 = *pbVar20;
                        pbVar13 = *(byte **)(puVar47 + 3);
                      }
                      if ((bVar24 & 0x20) == 0) {
                        *(int *)(puVar47 + 1) = (int)uVar44;
                        puVar47[0xd] = 0;
                        *(uint *)(puVar47 + 0xb) = uVar35;
                      }
                      else {
                        puVar46 = (ushort *)(pbVar20 + uVar44);
                        *(ushort **)(&stack0x00000070 + lVar12) = puVar46;
                        uVar7 = *puVar46;
                        puVar47[0xd] = uVar7;
                        if (uVar7 == 0) {
                          *(undefined8 *)(puVar33 + -8) = 0x100e45;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x100e4e;
                            lVar38 = func_0x();
                            if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar33 + -8) = 0x100e68;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x100e84;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x100eaa;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x100eb8;
                          func_0x(uVar17,3);
                          uVar7 = puVar47[0xd];
                          uVar35 = *(uint *)(puVar47 + 9);
                        }
                        uVar35 = uVar35 + (uVar7 + 1) * 2;
                        *(uint *)(puVar47 + 0xb) = uVar35;
                        if (0x1f9e < uVar35) {
                          *(undefined8 *)(puVar33 + -8) = 0x100ee7;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x100ef0;
                            lVar38 = func_0x();
                            if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar33 + -8) = 0x100f0a;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x100f26;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x100f4c;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x100f5a;
                          func_0x(uVar17,4);
                          uVar7 = puVar47[0xd];
                          uVar35 = *(uint *)(puVar47 + 0xb);
                        }
                        uVar44 = (ulonglong)uVar7;
                        uVar7 = puVar46[uVar44];
                        *(uint *)(puVar47 + 1) = uVar7 & 0x7fff;
                        if ((uVar7 & 0x7fff) < uVar35) {
                          *(undefined8 *)(puVar33 + -8) = 0x100f85;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x100f8e;
                            lVar38 = func_0x();
                            if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar33 + -8) = 0x100fa8;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x100fc4;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x100fea;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x100ff8;
                          func_0x(uVar17,4);
                          uVar35 = *(uint *)(puVar47 + 0xb);
                          uVar44 = (ulonglong)puVar47[0xd];
                        }
                        if ((short)uVar44 != 0) {
                          do {
                            puVar46 = puVar46 + 1;
                            uVar36 = *puVar46 & 0x7fff;
                            if ((uVar36 < uVar35) || (*(uint *)(puVar47 + 1) < uVar36)) {
                              *(undefined8 *)(puVar33 + -8) = 0x10102f;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 != '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x101038;
                                lVar38 = func_0x();
                                if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                                  *(undefined8 *)(puVar33 + -8) = 0x101052;
                                  cVar3 = func_0x(0x112fe00);
                                  if (cVar3 == '\0') {
                                    *(undefined8 *)(puVar33 + -8) = 0x10106e;
                                    (*_DAT_)(0x22,0x44,0x15);
                                  }
                                  else {
                                    *(undefined8 *)(puVar33 + 0x20) = 0;
                                    *(undefined8 *)(puVar33 + -8) = 0x101094;
                                    (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                                  }
                                }
                              }
                              uVar17 = *(undefined8 *)(puVar47 + 3);
                              *(undefined8 *)(puVar33 + -8) = 0x1010a2;
                              func_0x(uVar17,4);
                            }
                            uVar27 = uVar27 + 1;
                            uVar44 = (ulonglong)puVar47[0xd];
                            uVar35 = uVar36;
                          } while ((int)uVar27 < (int)(uint)puVar47[0xd]);
                          puVar46 = *(ushort **)(&stack0x00000070 + lVar12);
                        }
                        if ((short)puVar46[(ulonglong)((int)uVar44 - 1) + 1] < 0) {
                          do {
                            lVar38 = *(longlong *)(puVar47 + 3);
                            lVar15 = (ulonglong)*(uint *)(puVar47 + 9) + lVar38;
                            uVar27 = *(ushort *)(lVar15 + uVar44 * 2) & 0x7fff;
                            if ((int)uVar44 == 1) {
                              uVar35 = *(uint *)(puVar47 + 0xb);
                              uVar36 = uVar35;
LAB_:
                              if ((uVar27 < uVar35) || (*(uint *)(puVar47 + 1) < uVar27))
                              goto LAB_;
                            }
                            else {
                              uVar35 = *(ushort *)(lVar15 + -2 + uVar44 * 2) & 0x7fff;
                              uVar36 = *(uint *)(puVar47 + 0xb);
                              if (uVar36 <= uVar35) goto LAB_;
LAB_:
                              *(undefined8 *)(puVar33 + -8) = 0x101115;
                              func_0x(lVar38,7);
                              uVar36 = *(uint *)(puVar47 + 0xb);
                            }
                            if ((uVar35 < uVar36) || (*(uint *)(puVar47 + 1) < uVar35))
                            goto LAB_;
                            if (*(ushort *)((ulonglong)uVar35 + *(longlong *)(puVar47 + 3)) == 5) {
                              *puVar47 = *puVar47 | 2;
                              puVar47[0xd] = puVar47[0xd] - 1;
                              puVar47[0x14] = (ushort)uVar35;
                              uVar44 = *(ulonglong *)(puVar47 + 3);
                              uVar7 = *(ushort *)((ulonglong)(uVar35 & 0xffff) + 2 + uVar44);
                              uVar8 = puVar47[0x15] & 0xc7ff;
                              if ((uVar7 >> 0xe & 1) != 0) {
                                uVar8 = uVar7 & 0x3800 | uVar8;
                              }
                              puVar47[0x15] = uVar8;
                              uVar7 = (uVar8 ^ *(ushort *)
                                                ((ulonglong)(uVar35 & 0xffff) + 2 + uVar44)) & 0x7ff
                                      ^ uVar8;
                              puVar47[0x15] = uVar7;
                              uVar30 = (ulonglong)puVar47[0x14];
                              uVar39 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 +
                                       uVar44 + (uVar8 >> 0xb & 7) * 2 + uVar30;
                              if (uVar39 < uVar30 + uVar44) {
                                *(undefined8 *)(puVar33 + -8) = 0x101222;
                                func_0x(uVar30 + uVar44,0x19);
                                uVar7 = puVar47[0x15];
                                uVar30 = (ulonglong)puVar47[0x14];
                                uVar44 = (ulonglong)*(uint *)(puVar47 + 3);
                              }
                              if (uVar27 - uVar35 <
                                  (((uVar7 & 0x7ff) * 2 - (int)uVar30) - (int)uVar44) + (int)uVar39)
                              {
                                lVar38 = *(longlong *)(puVar47 + 3);
                                *(undefined8 *)(puVar33 + -8) = 0x10125a;
                                func_0x(uVar30 + lVar38,0x19);
                                uVar7 = puVar47[0x15];
                              }
                              if ((uVar7 & 0x3800) != 0) {
                                puVar46 = (ushort *)
                                          (*(longlong *)(puVar47 + 3) + (ulonglong)puVar47[0x14] + 4
                                          );
                                iVar45 = 0;
                                if ((uVar7 & 0x3800) != 0) {
                                  do {
                                    if ((uVar7 & 0x7ff) < (*puVar46 & 0x7ff)) {
                                      uVar7 = puVar47[0x14];
                                      lVar38 = *(longlong *)(puVar47 + 3);
                                      *(undefined8 *)(puVar33 + -8) = 0x1012b7;
                                      func_0x((ulonglong)uVar7 + lVar38,0x1a);
                                      uVar7 = puVar47[0x15];
                                    }
                                    iVar45 = iVar45 + 1;
                                    puVar46 = puVar46 + 1;
                                  } while (iVar45 < (int)(uVar7 >> 0xb & 7));
                                }
                              }
                              goto LAB_;
                            }
                            if (*(ushort *)((ulonglong)uVar35 + *(longlong *)(puVar47 + 3)) < 0x400)
                            goto LAB_;
                            *puVar47 = *puVar47 | 1;
                            uVar7 = puVar47[0xd] - 1;
                            puVar47[0xd] = uVar7;
                            if (uVar7 == 0) goto LAB_;
                            uVar44 = (ulonglong)uVar7;
                          } while ((short)puVar46[(ulonglong)(uVar7 - 1) + 1] < 0);
                          pbVar13 = *(byte **)(puVar47 + 3);
                        }
                        else {
LAB_:
                          pbVar13 = *(byte **)(puVar47 + 3);
                        }
                      }
                      if ((*pbVar13 & 0x40) == 0) {
                        *(undefined4 *)(puVar47 + 0x12) = 0;
                      }
                      else {
                        *(int *)(puVar47 + 0x12) = *(int *)(puVar47 + 1);
                        *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + 0xe;
                        *(undefined8 *)(puVar33 + -8) = 0x1012fd;
                        uVar17 = func_0x(puVar47);
                        *(undefined8 *)(puVar33 + -8) = 0x10130c;
                        func_0x(uVar17,&stack0x00000228 + lVar12);
                        *(undefined8 *)(puVar33 + -8) = 0x101318;
                        iVar45 = func_0x(&stack0x00000228 + lVar12);
                        *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + iVar45;
                      }
                      uVar27 = *(uint *)(puVar47 + 1);
                      if ((*(ulonglong *)(puVar47 + 0xe) != 0) &&
                         (*(ulonglong *)(puVar47 + 0xe) <
                          (ulonglong)uVar27 + *(longlong *)(puVar47 + 3))) {
                        *(undefined8 *)(puVar33 + -8) = 0x10134b;
                        cVar3 = func_0x(0x112fe00);
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x101354;
                          lVar38 = func_0x();
                          if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar33 + -8) = 0x10136e;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x10138a;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x1013b0;
                              (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x1013be;
                        func_0x(uVar17,0x12);
                        uVar27 = *(uint *)(puVar47 + 1);
                      }
                      if (0x3f3b < uVar27 - 1) {
                        *(undefined8 *)(puVar33 + -8) = 0x1013d7;
                        cVar3 = func_0x(0x112fe00);
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x1013e0;
                          lVar38 = func_0x();
                          if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar33 + -8) = 0x1013fa;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x101416;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x10143c;
                              (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x10144a;
                        func_0x(uVar17,5);
                      }
                    }
LAB_:
                    uVar27 = -**(int **)((longlong)&puStackX_20 + lVar12);
                    *(undefined8 *)(puVar33 + -8) = 0x101460;
                    func_0x(&stack0x000003e8 + lVar12);
                    pbVar20 = *(byte **)(puVar47 + 3);
                    bVar24 = *pbVar20;
                    bVar4 = bVar24 >> 6;
                    if ((bVar4 & 1) != 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x101484;
                      func_0x(puVar47,&stack0x000003e8 + lVar12);
                      pbVar20 = *(byte **)(puVar47 + 3);
                      bVar24 = *pbVar20;
                    }
                    if ((bVar24 & 0x20) == 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x101498;
                      func_0x(puVar47);
                      pbVar20 = *(byte **)(puVar47 + 3);
                    }
                    uVar7 = puVar47[0xd];
                    uVar35 = (uint)uVar7;
                    if (uVar7 < uVar27) {
                      iVar45 = uVar27 - uVar7;
                      puVar46 = (ushort *)(pbVar20 + *(uint *)(puVar47 + 9));
                      uVar36 = *(uint *)(puVar47 + 9) + 2 + uVar35 * 2;
                      uVar41 = iVar45 * 2;
                      uVar26 = 0;
                      if (*puVar46 != 0) {
                        do {
                          uVar7 = puVar46[(ulonglong)uVar26 + 1];
                          puVar46[(ulonglong)(uVar26 & 0xffff) + 1] =
                               puVar46[(ulonglong)(uVar26 & 0xffff) + 1] & 0x8000;
                          puVar46[(ulonglong)(uVar26 & 0xffff) + 1] =
                               puVar46[(ulonglong)(uVar26 & 0xffff) + 1] |
                               (uVar7 & 0x7fff) + (short)uVar41 & 0x7fff;
                          uVar26 = uVar26 + 1;
                        } while (uVar26 < *puVar46);
                        pbVar20 = *(byte **)(puVar47 + 3);
                      }
                      iVar34 = *(int *)(puVar47 + 1);
                      *(undefined8 *)(puVar33 + -8) = 0x10152c;
                      func_0x
                                (pbVar20 + (ulonglong)uVar41 + (ulonglong)uVar36,pbVar20 + uVar36,
                                 iVar34 - uVar36);
                      *(uint *)(puVar47 + 1) = *(int *)(puVar47 + 1) + uVar41;
                      *(uint *)(puVar47 + 0xb) = *(int *)(puVar47 + 0xb) + uVar41;
                      uVar7 = (ushort)*(undefined4 *)(puVar47 + 0xb);
                      if (uVar35 != 0) {
                        uVar7 = puVar46[(ulonglong)(uVar35 - 1) + 1] & 0x7fff;
                      }
                      do {
                        puVar46[(ulonglong)(uVar35 & 0xffff) + 1] = uVar7 & 0x7fff;
                        uVar35 = uVar35 + 1;
                      } while (uVar35 < uVar27);
                      *puVar46 = *puVar46 + (short)iVar45;
                      *(undefined8 *)(puVar33 + -8) = 0x10156b;
                      iVar45 = func_0x(puVar47);
                      if (iVar45 != 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x10157e;
                        uVar7 = func_0x(puVar47,&stack0x00000208 + lVar12);
                        puVar47[0x14] = uVar7;
                      }
                      puVar47[0xd] = (ushort)uVar27;
                      uVar35 = uVar27 & 0xffff;
                      pbVar20 = *(byte **)(puVar47 + 3);
                    }
                    uVar36 = *(uint *)(puVar47 + 9);
                    if (uVar35 < uVar27) {
                      uVar44 = (ulonglong)
                               (*(ushort *)(pbVar20 + (ulonglong)uVar35 * 2 + (ulonglong)uVar36) &
                               0x7fff);
                      iVar45 = 0;
LAB_:
                      puVar46 = (ushort *)(pbVar20 + *(uint *)(puVar47 + 9));
                      lVar38 = *(longlong *)(puVar47 + 3);
                      uVar42 = *(undefined4 *)(puVar47 + 1);
                      *(undefined8 *)(puVar33 + -8) = 0x101617;
                      uVar42 = func_0x(uVar42,(int)uVar44 + iVar45);
                      *(undefined8 *)(puVar33 + -8) = 0x101629;
                      func_0x
                                (uVar44 + lVar38 + 1,(longlong)iVar45 + uVar44 + lVar38,uVar42);
                      uVar27 = uVar27 - 1;
                      if ((int)uVar27 < (int)(uint)*puVar46) {
                        do {
                          uVar7 = puVar46[(longlong)(int)uVar27 + 1];
                          puVar46[((ulonglong)uVar27 & 0xffff) + 1] =
                               puVar46[((ulonglong)uVar27 & 0xffff) + 1] & 0x8000;
                          puVar46[((ulonglong)uVar27 & 0xffff) + 1] =
                               puVar46[((ulonglong)uVar27 & 0xffff) + 1] |
                               ((uVar7 & 0x7fff) - (short)iVar45) + 1 & 0x7fff;
                          uVar27 = uVar27 + 1;
                        } while ((int)uVar27 < (int)(uint)*puVar46);
                      }
                      *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + (1 - iVar45);
                      *(undefined8 *)(puVar33 + -8) = 0x101682;
                      iVar45 = func_0x(puVar47);
                      if (iVar45 != 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x101695;
                        uVar7 = func_0x(puVar47,&stack0x0000020c + lVar12);
                        puVar47[0x14] = uVar7;
                      }
                    }
                    else {
                      uVar35 = *(ushort *)(pbVar20 + (longlong)(int)uVar27 * 2 + (ulonglong)uVar36)
                               & 0x7fff;
                      if (uVar27 == 1) {
                        uVar44 = (ulonglong)*(uint *)(puVar47 + 0xb);
LAB_:
                        if ((uVar35 < (uint)uVar44) || (*(uint *)(puVar47 + 1) < uVar35))
                        goto LAB_;
                      }
                      else {
                        uVar44 = (ulonglong)
                                 (*(ushort *)
                                   (pbVar20 + (longlong)(int)uVar27 * 2 + ((ulonglong)uVar36 - 2)) &
                                 0x7fff);
                        if (*(uint *)(puVar47 + 0xb) <=
                            (*(ushort *)
                              (pbVar20 + (longlong)(int)uVar27 * 2 + ((ulonglong)uVar36 - 2)) &
                            0x7fff)) goto LAB_;
LAB_:
                        *(undefined8 *)(puVar33 + -8) = 0x1015e1;
                        func_0x(pbVar20,7);
                        pbVar20 = *(byte **)(puVar47 + 3);
                      }
                      iVar45 = uVar35 - (int)uVar44;
                      if (iVar45 != 1) goto LAB_;
                    }
                    *(undefined *)(*(longlong *)(puVar47 + 3) + uVar44) =
                         **(undefined **)(&stack0x00000028 + lVar12);
                    if ((bVar4 & 1) != 0) {
                      puVar19 = &stack0x000003e8;
LAB_:
                      *(undefined8 *)(puVar33 + -8) = 0x1016be;
                      func_0x(puVar47,(longlong)puVar19 + lVar12);
                    }
                    goto LAB_;
                  }
                  uVar36 = (uint)*(ushort *)((longlong)puVar31 + 6);
                  if ((*(ushort *)((longlong)puVar31 + 6) & 8) != 0) {
                    cVar3 = *pcVar40;
                    uVar35 = uVar35 + 1;
                    uVar27 = *(uint *)(puVar47 + 7);
                    if (uVar27 < uVar35) {
                      *(undefined8 *)(puVar33 + -8) = 0x100663;
                      func_0x(puVar47,0,uVar35 - uVar27);
                      if ((1 << (**(byte **)(puVar47 + 3) & 0xe) & 0x1105U) != 0) {
                        *(short *)(*(byte **)(puVar47 + 3) + 2) = (short)uVar35;
                      }
                      *(uint *)(puVar47 + 7) = uVar35;
                      uVar36 = (uint)*(byte *)(*(longlong *)((longlong)&puStackX_20 + lVar12) + 6);
                    }
                    lVar15 = *(longlong *)(puVar47 + 3);
                    if (cVar3 == '\0') {
                      *(byte *)(lVar15 + lVar38) =
                           *(byte *)(lVar15 + lVar38) & ~(byte)(1 << (uVar36 & 7));
                    }
                    else {
                      *(byte *)(lVar15 + lVar38) =
                           *(byte *)(lVar15 + lVar38) | (byte)(1 << (uVar36 & 7));
                    }
                    goto LAB_;
                  }
                  if (*(int *)(puVar47 + 1) == 0) {
                    *puVar47 = 0;
                    uVar35 = *(uint *)(puVar47 + 7);
                    uVar44 = (ulonglong)uVar35;
                    *(uint *)(puVar47 + 9) = uVar35;
                    pbVar20 = *(byte **)(puVar47 + 3);
                    bVar24 = *pbVar20;
                    pbVar13 = pbVar20;
                    if ((bVar24 & 0x10) != 0) {
                      uVar35 = uVar35 + (*(ushort *)(pbVar20 + uVar44) + 7 >> 3) + 2;
                      uVar44 = (ulonglong)uVar35;
                      *(uint *)(puVar47 + 9) = uVar35;
                      bVar24 = *pbVar20;
                      pbVar13 = *(byte **)(puVar47 + 3);
                    }
                    if ((bVar24 & 0x20) == 0) {
                      *(int *)(puVar47 + 1) = (int)uVar44;
                      puVar47[0xd] = 0;
                      *(uint *)(puVar47 + 0xb) = uVar35;
                    }
                    else {
                      puVar46 = (ushort *)(pbVar20 + uVar44);
                      *(ushort **)(&stack0x00000070 + lVar12) = puVar46;
                      uVar7 = *puVar46;
                      puVar47[0xd] = uVar7;
                      if (uVar7 == 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x100726;
                        cVar3 = func_0x(0x112fe00);
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x10072f;
                          lVar38 = func_0x();
                          if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar33 + -8) = 0x100749;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x100765;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x10078b;
                              (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x100799;
                        func_0x(uVar17,3);
                        uVar7 = puVar47[0xd];
                        uVar35 = *(uint *)(puVar47 + 9);
                      }
                      uVar35 = uVar35 + (uVar7 + 1) * 2;
                      *(uint *)(puVar47 + 0xb) = uVar35;
                      if (0x1f9e < uVar35) {
                        *(undefined8 *)(puVar33 + -8) = 0x1007c8;
                        cVar3 = func_0x(0x112fe00);
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x1007d1;
                          lVar38 = func_0x();
                          if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar33 + -8) = 0x1007eb;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x100807;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x10082d;
                              (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x10083b;
                        func_0x(uVar17,4);
                        uVar7 = puVar47[0xd];
                        uVar35 = *(uint *)(puVar47 + 0xb);
                      }
                      uVar44 = (ulonglong)uVar7;
                      uVar7 = puVar46[uVar44];
                      *(uint *)(puVar47 + 1) = uVar7 & 0x7fff;
                      if ((uVar7 & 0x7fff) < uVar35) {
                        *(undefined8 *)(puVar33 + -8) = 0x100866;
                        cVar3 = func_0x(0x112fe00);
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x10086f;
                          lVar38 = func_0x();
                          if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar33 + -8) = 0x100889;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x1008a5;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x1008cb;
                              (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x1008d9;
                        func_0x(uVar17,4);
                        uVar35 = *(uint *)(puVar47 + 0xb);
                        uVar44 = (ulonglong)puVar47[0xd];
                      }
                      if ((short)uVar44 != 0) {
                        do {
                          puVar46 = puVar46 + 1;
                          uVar36 = *puVar46 & 0x7fff;
                          if ((uVar36 < uVar35) || (*(uint *)(puVar47 + 1) < uVar36)) {
                            *(undefined8 *)(puVar33 + -8) = 0x10091c;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x100925;
                              lVar38 = func_0x();
                              if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar33 + -8) = 0x10093f;
                                cVar3 = func_0x(0x112fe00);
                                if (cVar3 == '\0') {
                                  *(undefined8 *)(puVar33 + -8) = 0x10095b;
                                  (*_DAT_)(0x22,0x44,0x15);
                                }
                                else {
                                  *(undefined8 *)(puVar33 + 0x20) = 0;
                                  *(undefined8 *)(puVar33 + -8) = 0x10097f;
                                  (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                                }
                              }
                            }
                            uVar17 = *(undefined8 *)(puVar47 + 3);
                            *(undefined8 *)(puVar33 + -8) = 0x10098d;
                            func_0x(uVar17,4);
                          }
                          uVar27 = uVar27 + 1;
                          uVar44 = (ulonglong)puVar47[0xd];
                          uVar35 = uVar36;
                        } while ((int)uVar27 < (int)(uint)puVar47[0xd]);
                        puVar46 = *(ushort **)(&stack0x00000070 + lVar12);
                        pcVar40 = *(char **)(&stack0x00000028 + lVar12);
                      }
                      if ((short)puVar46[(ulonglong)((int)uVar44 - 1) + 1] < 0) {
                        do {
                          lVar38 = *(longlong *)(puVar47 + 3);
                          uVar27 = *(ushort *)
                                    ((ulonglong)*(uint *)(puVar47 + 9) + lVar38 + uVar44 * 2) &
                                   0x7fff;
                          if ((int)uVar44 == 1) {
                            uVar35 = *(uint *)(puVar47 + 0xb);
                            uVar36 = uVar35;
LAB_:
                            if ((uVar27 < uVar35) || (*(uint *)(puVar47 + 1) < uVar27))
                            goto LAB_;
                          }
                          else {
                            uVar35 = *(ushort *)
                                      ((ulonglong)*(uint *)(puVar47 + 9) + lVar38 + -2 + uVar44 * 2)
                                     & 0x7fff;
                            uVar36 = *(uint *)(puVar47 + 0xb);
                            if (uVar36 <= uVar35) goto LAB_;
LAB_:
                            *(undefined8 *)(puVar33 + -8) = 0x100a05;
                            func_0x(lVar38,7);
                            uVar36 = *(uint *)(puVar47 + 0xb);
                            lVar38 = *(longlong *)(puVar47 + 3);
                          }
                          if ((uVar35 < uVar36) || (*(uint *)(puVar47 + 1) < uVar35)) {
                            puVar31 = *(uint **)((longlong)&puStackX_20 + lVar12);
                            goto LAB_;
                          }
                          if (*(ushort *)((ulonglong)uVar35 + lVar38) == 5) {
                            *puVar47 = *puVar47 | 2;
                            puVar47[0xd] = puVar47[0xd] - 1;
                            puVar47[0x14] = (ushort)uVar35;
                            uVar44 = *(ulonglong *)(puVar47 + 3);
                            uVar7 = *(ushort *)((ulonglong)(uVar35 & 0xffff) + 2 + uVar44);
                            uVar8 = puVar47[0x15] & 0xc7ff;
                            if ((uVar7 >> 0xe & 1) != 0) {
                              uVar8 = uVar7 & 0x3800 | uVar8;
                            }
                            puVar47[0x15] = uVar8;
                            uVar7 = (uVar8 ^ *(ushort *)((ulonglong)(uVar35 & 0xffff) + 2 + uVar44))
                                    & 0x7ff ^ uVar8;
                            puVar47[0x15] = uVar7;
                            uVar30 = (ulonglong)puVar47[0x14];
                            uVar39 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 +
                                     uVar44 + (uVar8 >> 0xb & 7) * 2 + uVar30;
                            if (uVar39 < uVar30 + uVar44) {
                              *(undefined8 *)(puVar33 + -8) = 0x100b17;
                              func_0x(uVar30 + uVar44,0x19);
                              uVar7 = puVar47[0x15];
                              uVar30 = (ulonglong)puVar47[0x14];
                              uVar44 = (ulonglong)*(uint *)(puVar47 + 3);
                            }
                            if (uVar27 - uVar35 <
                                (((uVar7 & 0x7ff) * 2 - (int)uVar30) - (int)uVar44) + (int)uVar39) {
                              lVar38 = *(longlong *)(puVar47 + 3);
                              *(undefined8 *)(puVar33 + -8) = 0x100b4f;
                              func_0x(uVar30 + lVar38,0x19);
                              uVar7 = puVar47[0x15];
                            }
                            if ((uVar7 & 0x3800) != 0) {
                              puVar46 = (ushort *)
                                        (*(longlong *)(puVar47 + 3) + (ulonglong)puVar47[0x14] + 4);
                              iVar45 = 0;
                              if ((uVar7 & 0x3800) != 0) {
                                do {
                                  if ((uVar7 & 0x7ff) < (*puVar46 & 0x7ff)) {
                                    uVar7 = puVar47[0x14];
                                    lVar38 = *(longlong *)(puVar47 + 3);
                                    *(undefined8 *)(puVar33 + -8) = 0x100ba7;
                                    func_0x((ulonglong)uVar7 + lVar38,0x1a);
                                    uVar7 = puVar47[0x15];
                                  }
                                  iVar45 = iVar45 + 1;
                                  puVar46 = puVar46 + 1;
                                } while (iVar45 < (int)(uVar7 >> 0xb & 7));
                              }
                            }
                            goto LAB_;
                          }
                          if (*(ushort *)((ulonglong)uVar35 + lVar38) < 0x400) goto LAB_;
                          *puVar47 = *puVar47 | 1;
                          uVar7 = puVar47[0xd] - 1;
                          puVar47[0xd] = uVar7;
                          if (uVar7 == 0) goto LAB_;
                          uVar44 = (ulonglong)uVar7;
                        } while ((short)puVar46[(ulonglong)(uVar7 - 1) + 1] < 0);
                        pbVar13 = *(byte **)(puVar47 + 3);
                        puVar31 = *(uint **)((longlong)&puStackX_20 + lVar12);
                      }
                      else {
LAB_:
                        pbVar13 = *(byte **)(puVar47 + 3);
                        puVar31 = *(uint **)((longlong)&puStackX_20 + lVar12);
                      }
                    }
                    if ((*pbVar13 & 0x40) == 0) {
                      *(undefined4 *)(puVar47 + 0x12) = 0;
                    }
                    else {
                      *(int *)(puVar47 + 0x12) = *(int *)(puVar47 + 1);
                      *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + 0xe;
                      *(undefined8 *)(puVar33 + -8) = 0x100bf2;
                      uVar17 = func_0x(puVar47);
                      *(undefined8 *)(puVar33 + -8) = 0x100c01;
                      func_0x(uVar17,&stack0x00000220 + lVar12);
                      *(undefined8 *)(puVar33 + -8) = 0x100c0d;
                      iVar45 = func_0x(&stack0x00000220 + lVar12);
                      *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + iVar45;
                      pbVar13 = *(byte **)(puVar47 + 3);
                    }
                    uVar27 = *(uint *)(puVar47 + 1);
                    if ((*(byte **)(puVar47 + 0xe) != (byte *)0x0) &&
                       (*(byte **)(puVar47 + 0xe) < pbVar13 + uVar27)) {
                      *(undefined8 *)(puVar33 + -8) = 0x100c43;
                      cVar3 = func_0x(0x112fe00);
                      if (cVar3 != '\0') {
                        *(undefined8 *)(puVar33 + -8) = 0x100c4c;
                        lVar38 = func_0x();
                        if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar33 + -8) = 0x100c66;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 == '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x100c82;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar33 + 0x20) = 0;
                            *(undefined8 *)(puVar33 + -8) = 0x100ca8;
                            (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(puVar47 + 3);
                      *(undefined8 *)(puVar33 + -8) = 0x100cb6;
                      func_0x(uVar17,0x12);
                      uVar27 = *(uint *)(puVar47 + 1);
                    }
                    if (0x3f3b < uVar27 - 1) {
                      *(undefined8 *)(puVar33 + -8) = 0x100cd3;
                      cVar3 = func_0x(0x112fe00);
                      if (cVar3 != '\0') {
                        *(undefined8 *)(puVar33 + -8) = 0x100cdc;
                        lVar38 = func_0x();
                        if ((lVar38 != 0) && (*(char *)(lVar38 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar33 + -8) = 0x100cf6;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 == '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x100d12;
                            (*_DAT_)(0x22,0x44,0x15);
                            uVar17 = *(undefined8 *)(puVar47 + 3);
                            *(undefined8 *)(puVar33 + -8) = 0x100d20;
                            func_0x(uVar17,5);
                            goto LAB_;
                          }
                          *(undefined8 *)(puVar33 + 0x20) = 0;
                          *(undefined8 *)(puVar33 + -8) = 0x100d46;
                          (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                        }
                      }
                      uVar17 = *(undefined8 *)(puVar47 + 3);
                      *(undefined8 *)(puVar33 + -8) = 0x100d54;
                      func_0x(uVar17,5);
                    }
                  }
LAB_:
                  uVar35 = *puVar31;
                  uVar27 = uVar35 + 1;
                  uVar36 = *(uint *)(puVar47 + 7);
                  if (uVar36 < uVar27) {
                    *(undefined8 *)(puVar33 + -8) = 0x100d7a;
                    func_0x(puVar47,0,uVar27 - uVar36);
                    if ((1 << (**(byte **)(puVar47 + 3) & 0xe) & 0x1105U) != 0) {
                      *(short *)(*(byte **)(puVar47 + 3) + 2) = (short)uVar27;
                    }
                    *(uint *)(puVar47 + 7) = uVar27;
                    uVar35 = *puVar31;
                  }
                  if (pcVar40 != (char *)0x0) {
                    *(char *)((longlong)(int)uVar35 + *(longlong *)(puVar47 + 3)) = *pcVar40;
                  }
                }
                else {
                  *(undefined8 *)(puVar33 + 0x20) = 0x79ad70;
                  *(undefined8 *)(puVar33 + -8) = 0x10061c;
                  (*_DAT_)(1,0xba1100,0xbcdac8);
                }
              }
LAB_:
              puVar31 = puVar31 + 0x14;
              *(uint **)((longlong)&puStackX_20 + lVar12) = puVar31;
              iVar45 = *(int *)(&stack0x00000094 + lVar12);
              *(uint *)(&stack0x00000094 + lVar12) = iVar45 + 1U;
            } while (iVar45 + 1U < *(uint *)(&stack0x00000124 + lVar12));
LAB_:
            psVar43 = *(short **)(&stack0x00000078 + lVar12);
          }
        }
        else if (*(ushort *)((longlong)param_3 + 0x62) != 0) {
          plVar29 = (longlong *)(*(longlong *)(&stack0x000000c0 + lVar12) + 0x48);
          uVar44 = (ulonglong)*(ushort *)((longlong)param_3 + 0x62);
          do {
            iVar45 = 0;
            (&stack0x00000031)[lVar12] = 0;
            *(undefined8 *)(puVar33 + -8) = 0x103d78;
            func_0x
                      (&stack0x000000b8 + lVar12,plVar29 + -9,&stack0x00000031 + lVar12);
            if ((&stack0x00000031)[lVar12] == '\x03') {
              if ((*(uint *)(plVar29 + -1) & 0x4000) == 0) {
                *(undefined8 *)(puVar33 + -8) = 0x1040a4;
                (*_DAT_)(6,0x51,0x10,1);
              }
              uVar10 = *(undefined2 *)((longlong)plVar29 + -0xc);
              uVar17 = *(undefined8 *)(&stack0x00000078 + lVar12);
              *(undefined8 *)(puVar33 + -8) = 0x1040b9;
              func_0x(uVar17,plVar29 + -9,uVar10,1);
            }
            else {
              lVar38 = *(longlong *)(&stack0x00000088 + lVar12);
              if (*(short *)((longlong)plVar29 + -0x44) != 0) {
                if (*(short *)(lVar38 + 8) == 0) {
                  *(undefined8 *)(puVar33 + -8) = 0x103da1;
                  func_0x();
                }
                else {
                  *(undefined8 *)(puVar33 + -8) = 0x103da8;
                  func_0x(lVar38 + 10,plVar29 + -9);
                }
              }
              *(undefined8 *)(puVar33 + -8) = 0x103dbf;
              func_0x
                        (&stack0x000000b8 + lVar12,plVar29 + -9,&stack0x000001b0 + lVar12);
              cVar3 = *(char *)(plVar29 + -1);
              if ((cVar3 == '\x01') || (cVar3 == '\x02')) {
                lVar15 = *(longlong *)(&stack0x000001b0 + lVar12);
                if ((*(uint *)(plVar29 + -1) >> 8 & 1) == 0) {
                  iVar45 = *(int *)(plVar29 + -9);
                  lVar38 = *(longlong *)(lVar38 + 0x10);
                  uVar10 = *(undefined2 *)((longlong)plVar29 + -0xc);
                  *(undefined8 *)(puVar33 + -8) = 0x103ef6;
                  func_0x(iVar45 + lVar38,lVar15,uVar10);
                }
                else {
                  if (((*(uint *)(plVar29 + -1) & 0x8000) == 0) ||
                     (((&stack0x000000cc)[lVar12] & 8) == 0)) {
                    lVar38 = *(longlong *)(&stack0x000000d0 + lVar12);
                    if ((*(byte *)(*plVar29 + 0x2a) & 0x10) != 0) {
                      lVar38 = *(longlong *)(&stack0x000000d8 + lVar12);
                    }
                    uVar27 = *(uint *)(*(longlong *)(*plVar29 + 0x18) + lVar38);
                  }
                  else {
                    uVar27 = *(uint *)(*(longlong *)(&stack0x000000f0 + lVar12) +
                                      (ulonglong)*(uint *)(plVar29 + -2) * 8);
                  }
                  uVar35 = (uint)*(ushort *)((longlong)plVar29 + -0xc);
                  if (uVar27 < uVar35) {
                    iVar45 = uVar35 - uVar27;
                  }
                  else if (uVar35 < uVar27) {
                    *(undefined8 *)(puVar33 + -8) = 0x103f5b;
                    (*_DAT_)(6,0x5c,0x16,1);
                  }
                  uVar5 = *(undefined *)(*plVar29 + 0x24);
                  lVar38 = (longlong)*(int *)(plVar29 + -9) +
                           *(longlong *)(*(longlong *)(&stack0x00000088 + lVar12) + 0x10);
                  if ((lVar15 != 0) && (uVar27 != 0)) {
                    *(undefined8 *)(puVar33 + -8) = 0x103f86;
                    func_0x(lVar38,lVar15,uVar27);
                  }
                  if (iVar45 != 0) {
                    *(undefined8 *)(puVar33 + -8) = 0x103f9a;
                    func_0x((ulonglong)uVar27 + lVar38,uVar5,iVar45);
                  }
                }
              }
              else if ((cVar3 == '\x03') || (cVar3 == '\x04')) {
                uVar27 = *(uint *)(plVar29 + -1);
                piVar28 = *(int **)(&stack0x000001b0 + lVar12);
                if (((uVar27 >> 0xd & 1) == 0) || (*piVar28 != 0)) {
                  if (((uVar27 & 0x8000) == 0) || (((&stack0x000000cc)[lVar12] & 8) == 0)) {
                    lVar38 = *plVar29;
                    if ((uVar27 >> 8 & 1) == 0) {
                      uVar27 = (uint)*(ushort *)(lVar38 + 2);
                    }
                    else {
                      lVar15 = *(longlong *)(&stack0x000000d0 + lVar12);
                      if ((*(byte *)(lVar38 + 0x2a) & 0x10) != 0) {
                        lVar15 = *(longlong *)(&stack0x000000d8 + lVar12);
                      }
                      uVar27 = *(uint *)(*(longlong *)(lVar38 + 0x18) + lVar15);
                    }
                  }
                  else {
                    uVar27 = *(uint *)(*(longlong *)(&stack0x000000f0 + lVar12) +
                                      (ulonglong)*(uint *)(plVar29 + -2) * 8);
                  }
                }
                else {
                  uVar27 = 0;
                }
                if (*(ushort *)((longlong)plVar29 + -0xc) < uVar27) {
                  *(undefined8 *)(puVar33 + -8) = 0x103eb5;
                  (*_DAT_)(6,0x52,0x16,0x93);
                  piVar28 = *(int **)(&stack0x000001b0 + lVar12);
                }
                uVar17 = *(undefined8 *)(&stack0x00000078 + lVar12);
                *(undefined8 *)(puVar33 + -8) = 0x103ecc;
                func_0x(uVar17,plVar29 + -9,piVar28,uVar27);
              }
              else if (cVar3 == '\b') {
                uVar17 = *(undefined8 *)(&stack0x000001b0 + lVar12);
                uVar22 = *(undefined8 *)(&stack0x00000078 + lVar12);
                *(undefined8 *)(puVar33 + -8) = 0x103e32;
                func_0x(uVar22,plVar29 + -9,uVar17,1);
              }
              else {
                *(undefined8 *)(puVar33 + 0x20) = 0x79ad70;
                *(undefined8 *)(puVar33 + -8) = 0x103e11;
                (*_DAT_)(1,0xba1100,0xbcdac8,0x380);
              }
            }
            plVar29 = plVar29 + 10;
            uVar44 = uVar44 - 1;
          } while (uVar44 != 0);
          goto LAB_;
        }
      }
      else {
        *psVar43 = 0;
        lVar38 = *(longlong *)(&stack0x00000088 + lVar12);
        uVar7 = *(ushort *)(*(longlong *)(&stack0x000000b8 + lVar12) + 0x62);
        piVar28 = *(int **)(*(longlong *)(&stack0x000000b8 + lVar12) + 0x70);
        if (uVar7 != 0) {
          *(ulonglong *)(&stack0x00000028 + lVar12) = (ulonglong)uVar7;
          do {
            iVar45 = 0;
            *(undefined8 *)(puVar33 + -8) = 0x1003cf;
            cVar3 = func_0x(&stack0x000000b8 + lVar12,piVar28);
            if (cVar3 == '\x03') {
              if ((piVar28[0x10] & 0x4000U) == 0) {
                *(undefined8 *)(puVar33 + -8) = 0x100509;
                (*_DAT_)(6,0x51,0x10,4);
              }
              uVar10 = *(undefined2 *)(piVar28 + 0xf);
              *(undefined8 *)(puVar33 + -8) = 0x100521;
              func_0x(lVar38 + 10,piVar28,uVar10,1);
            }
            else {
              *(undefined8 *)(puVar33 + -8) = 0x1003e4;
              func_0x(lVar38 + 10,piVar28);
              *(undefined8 *)(puVar33 + -8) = 0x1003fa;
              func_0x(&stack0x000000b8 + lVar12,piVar28,&stack0x00000218 + lVar12);
              lVar15 = *(longlong *)(&stack0x00000218 + lVar12);
              if (((uint)piVar28[0x10] >> 8 & 1) == 0) {
                iVar45 = *piVar28;
                lVar16 = *(longlong *)(lVar38 + 0x10);
                uVar10 = *(undefined2 *)(piVar28 + 0xf);
                *(undefined8 *)(puVar33 + -8) = 0x10041f;
                func_0x(iVar45 + lVar16,lVar15,uVar10);
              }
              else {
                if (((piVar28[0x10] & 0x8000U) == 0) || (((&stack0x000000cc)[lVar12] & 8) == 0)) {
                  lVar16 = *(longlong *)(&stack0x000000d0 + lVar12);
                  if ((*(byte *)(*(longlong *)(piVar28 + 0x12) + 0x2a) & 0x10) != 0) {
                    lVar16 = *(longlong *)(&stack0x000000d8 + lVar12);
                  }
                  uVar27 = *(uint *)(*(longlong *)(*(longlong *)(piVar28 + 0x12) + 0x18) + lVar16);
                }
                else {
                  uVar27 = *(uint *)(*(longlong *)(&stack0x000000f0 + lVar12) +
                                    (ulonglong)(uint)piVar28[0xe] * 8);
                }
                uVar35 = (uint)*(ushort *)(piVar28 + 0xf);
                if (uVar27 < uVar35) {
                  iVar45 = uVar35 - uVar27;
                }
                else if (uVar35 < uVar27) {
                  *(undefined8 *)(puVar33 + -8) = 0x100490;
                  (*_DAT_)(6,0x5c,0x16,1);
                }
                uVar5 = *(undefined *)(*(longlong *)(piVar28 + 0x12) + 0x24);
                lVar16 = (longlong)*piVar28 + *(longlong *)(lVar38 + 0x10);
                if ((lVar15 != 0) && (uVar27 != 0)) {
                  *(undefined8 *)(puVar33 + -8) = 0x1004b8;
                  func_0x(lVar16,lVar15,uVar27);
                }
                if (iVar45 != 0) {
                  *(undefined8 *)(puVar33 + -8) = 0x1004cc;
                  func_0x((ulonglong)uVar27 + lVar16,uVar5,iVar45);
                }
              }
            }
            piVar28 = piVar28 + 0x14;
            plVar29 = (longlong *)(&stack0x00000028 + lVar12);
            *plVar29 = *plVar29 + -1;
          } while (*plVar29 != 0);
          goto LAB_;
        }
      }
      iVar45 = 0;
      lVar38 = *(longlong *)(&stack0x00000088 + lVar12);
      if (*psVar43 == 0) {
        uVar27 = *(uint *)(lVar38 + 0xc);
        if (uVar27 == 0) {
          *(undefined2 *)(lVar38 + 10) = 0;
          uVar27 = *(uint *)(lVar38 + 0x18);
          uVar44 = (ulonglong)uVar27;
          *(uint *)(lVar38 + 0x1c) = uVar27;
          pbVar20 = *(byte **)(lVar38 + 0x10);
          bVar24 = *pbVar20;
          if ((bVar24 & 0x10) != 0) {
            uVar27 = uVar27 + 2 + (*(ushort *)(pbVar20 + uVar44) + 7 >> 3);
            uVar44 = (ulonglong)uVar27;
            *(uint *)(lVar38 + 0x1c) = uVar27;
            bVar24 = *pbVar20;
          }
          if ((bVar24 & 0x20) == 0) {
            *(int *)(lVar38 + 0xc) = (int)uVar44;
            *(undefined2 *)(lVar38 + 0x24) = 0;
            *(uint *)(lVar38 + 0x20) = uVar27;
          }
          else {
            puVar47 = (ushort *)(pbVar20 + uVar44);
            *(ushort **)(&stack0x00000028 + lVar12) = puVar47;
            uVar7 = *puVar47;
            *(ushort *)(lVar38 + 0x24) = uVar7;
            if (uVar7 == 0) {
              *(undefined8 *)(puVar33 + -8) = 0x10403c;
              cVar3 = func_0x(0x112fe00);
              if (cVar3 != '\0') {
                *(undefined8 *)(puVar33 + -8) = 0x104049;
                lVar15 = func_0x();
                if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar33 + -8) = 0x10406b;
                  cVar3 = func_0x(0x112fe00);
                  if (cVar3 == '\0') {
                    *(undefined8 *)(puVar33 + -8) = 0x104087;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar33 + 0x20) = 0;
                    *(undefined8 *)(puVar33 + -8) = 0x1040e2;
                    (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x80f);
                  }
                }
              }
              uVar17 = *(undefined8 *)(lVar38 + 0x10);
              *(undefined8 *)(puVar33 + -8) = 0x1040f0;
              func_0x(uVar17,3);
              uVar7 = *(ushort *)(lVar38 + 0x24);
              uVar27 = *(uint *)(lVar38 + 0x1c);
            }
            uVar27 = uVar27 + (uVar7 + 1) * 2;
            *(uint *)(lVar38 + 0x20) = uVar27;
            if (0x1f9e < uVar27) {
              *(undefined8 *)(puVar33 + -8) = 0x10411f;
              cVar3 = func_0x(0x112fe00);
              if (cVar3 != '\0') {
                *(undefined8 *)(puVar33 + -8) = 0x104128;
                lVar15 = func_0x();
                if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar33 + -8) = 0x104142;
                  cVar3 = func_0x(0x112fe00);
                  if (cVar3 == '\0') {
                    *(undefined8 *)(puVar33 + -8) = 0x10415e;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar33 + 0x20) = 0;
                    *(undefined8 *)(puVar33 + -8) = 0x104184;
                    (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x816);
                  }
                }
              }
              uVar17 = *(undefined8 *)(lVar38 + 0x10);
              *(undefined8 *)(puVar33 + -8) = 0x104192;
              func_0x(uVar17,4);
              uVar7 = *(ushort *)(lVar38 + 0x24);
              uVar27 = *(uint *)(lVar38 + 0x20);
            }
            uVar44 = (ulonglong)uVar7;
            uVar7 = puVar47[uVar44];
            *(uint *)(lVar38 + 0xc) = uVar7 & 0x7fff;
            if ((uVar7 & 0x7fff) < uVar27) {
              *(undefined8 *)(puVar33 + -8) = 0x1041c3;
              cVar3 = func_0x(0x112fe00);
              if (cVar3 != '\0') {
                *(undefined8 *)(puVar33 + -8) = 0x1041cc;
                lVar15 = func_0x();
                if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar33 + -8) = 0x1041e6;
                  cVar3 = func_0x(0x112fe00);
                  if (cVar3 == '\0') {
                    *(undefined8 *)(puVar33 + -8) = 0x104202;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar33 + 0x20) = 0;
                    *(undefined8 *)(puVar33 + -8) = 0x104228;
                    (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x81d);
                  }
                }
              }
              uVar17 = *(undefined8 *)(lVar38 + 0x10);
              *(undefined8 *)(puVar33 + -8) = 0x104236;
              func_0x(uVar17,4);
              uVar27 = *(uint *)(lVar38 + 0x20);
              uVar44 = (ulonglong)*(ushort *)(lVar38 + 0x24);
            }
            if ((short)uVar44 != 0) {
              do {
                puVar47 = puVar47 + 1;
                uVar35 = *puVar47 & 0x7fff;
                if ((uVar35 < uVar27) || (*(uint *)(lVar38 + 0xc) < uVar35)) {
                  *(undefined8 *)(puVar33 + -8) = 0x104280;
                  cVar3 = func_0x(0x112fe00);
                  if (cVar3 != '\0') {
                    *(undefined8 *)(puVar33 + -8) = 0x104289;
                    lVar15 = func_0x();
                    if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar33 + -8) = 0x1042a3;
                      cVar3 = func_0x(0x112fe00);
                      if (cVar3 == '\0') {
                        *(undefined8 *)(puVar33 + -8) = 0x1042bf;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar33 + 0x20) = 0;
                        *(undefined8 *)(puVar33 + -8) = 0x1042e5;
                        (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x82a);
                      }
                    }
                  }
                  uVar17 = *(undefined8 *)(lVar38 + 0x10);
                  *(undefined8 *)(puVar33 + -8) = 0x1042f3;
                  func_0x(uVar17,4);
                }
                iVar45 = iVar45 + 1;
                uVar44 = (ulonglong)*(ushort *)(lVar38 + 0x24);
                uVar27 = uVar35;
              } while (iVar45 < (int)(uint)*(ushort *)(lVar38 + 0x24));
              puVar47 = *(ushort **)(&stack0x00000028 + lVar12);
            }
            if ((short)puVar47[(ulonglong)((int)uVar44 - 1) + 1] < 0) {
              do {
                lVar15 = *(longlong *)(lVar38 + 0x10);
                lVar16 = (ulonglong)*(uint *)(lVar38 + 0x1c) + lVar15;
                uVar35 = *(ushort *)(lVar16 + uVar44 * 2) & 0x7fff;
                if ((int)uVar44 == 1) {
                  uVar36 = *(uint *)(lVar38 + 0x20);
                  uVar41 = uVar36;
LAB_:
                  if ((uVar35 < uVar36) || (uVar27 = *(uint *)(lVar38 + 0xc), uVar27 < uVar35))
                  goto LAB_;
                }
                else {
                  uVar36 = *(ushort *)(lVar16 + -2 + uVar44 * 2) & 0x7fff;
                  uVar41 = *(uint *)(lVar38 + 0x20);
                  if (uVar41 <= uVar36) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar33 + -8) = 0x104379;
                  func_0x(lVar15,7);
                  uVar41 = *(uint *)(lVar38 + 0x20);
                  uVar27 = *(uint *)(lVar38 + 0xc);
                }
                if ((uVar36 < uVar41) || (uVar27 < uVar36)) goto LAB_;
                uVar7 = *(ushort *)((ulonglong)uVar36 + *(longlong *)(lVar38 + 0x10));
                if (uVar7 == 5) {
                  *(ushort *)(lVar38 + 10) = *(ushort *)(lVar38 + 10) | 2;
                  *(short *)(lVar38 + 0x24) = *(short *)(lVar38 + 0x24) + -1;
                  uVar39 = (ulonglong)(uVar36 & 0xffff);
                  *(short *)(lVar38 + 0x32) = (short)uVar36;
                  uVar44 = *(ulonglong *)(lVar38 + 0x10);
                  uVar7 = *(ushort *)(lVar38 + 0x34) & 0xc7ff;
                  if ((*(ushort *)(uVar39 + 2 + uVar44) >> 0xe & 1) != 0) {
                    uVar7 = *(ushort *)(uVar39 + 2 + uVar44) & 0x3800 | uVar7;
                  }
                  *(ushort *)(lVar38 + 0x34) = uVar7;
                  uVar8 = (uVar7 ^ *(ushort *)(uVar39 + 2 + uVar44)) & 0x7ff ^ uVar7;
                  *(ushort *)(lVar38 + 0x34) = uVar8;
                  uVar30 = (ulonglong)*(ushort *)(lVar38 + 0x32);
                  uVar39 = uVar44 + 4 +
                           (ulonglong)((uVar8 & 0x7ff) * 2) + uVar30 + (uVar7 >> 0xb & 7) * 2;
                  if (uVar39 < uVar30 + uVar44) {
                    *(undefined8 *)(puVar33 + -8) = 0x10448c;
                    func_0x(uVar30 + uVar44,0x19);
                    uVar8 = *(ushort *)(lVar38 + 0x34);
                    uVar30 = (ulonglong)*(ushort *)(lVar38 + 0x32);
                    uVar44 = (ulonglong)*(uint *)(lVar38 + 0x10);
                  }
                  if (uVar35 - uVar36 <
                      (((uVar8 & 0x7ff) * 2 - (int)uVar30) - (int)uVar44) + (int)uVar39) {
                    lVar15 = *(longlong *)(lVar38 + 0x10);
                    *(undefined8 *)(puVar33 + -8) = 0x1044c4;
                    func_0x(uVar30 + lVar15,0x19);
                    uVar8 = *(ushort *)(lVar38 + 0x34);
                  }
                  iVar45 = 0;
                  if (((uVar8 & 0x3800) != 0) &&
                     (puVar47 = (ushort *)
                                (*(longlong *)(lVar38 + 0x10) + 4 +
                                (ulonglong)*(ushort *)(lVar38 + 0x32)), (uVar8 & 0x3800) != 0)) {
                    do {
                      if ((uVar8 & 0x7ff) < (*puVar47 & 0x7ff)) {
                        uVar7 = *(ushort *)(lVar38 + 0x32);
                        lVar15 = *(longlong *)(lVar38 + 0x10);
                        *(undefined8 *)(puVar33 + -8) = 0x104527;
                        func_0x((ulonglong)uVar7 + lVar15,0x1a);
                        uVar8 = *(ushort *)(lVar38 + 0x34);
                      }
                      iVar45 = iVar45 + 1;
                      puVar47 = puVar47 + 1;
                    } while (iVar45 < (int)(uVar8 >> 0xb & 7));
                  }
                  break;
                }
                if (uVar7 < 0x400) break;
                *(ushort *)(lVar38 + 10) = *(ushort *)(lVar38 + 10) | 1;
                uVar7 = *(short *)(lVar38 + 0x24) - 1;
                *(ushort *)(lVar38 + 0x24) = uVar7;
                if ((uVar7 == 0) ||
                   (uVar44 = (ulonglong)uVar7, -1 < (short)puVar47[(ulonglong)(uVar7 - 1) + 1]))
                break;
              } while( true );
            }
          }
          if ((**(byte **)(lVar38 + 0x10) & 0x40) == 0) {
            *(undefined4 *)(lVar38 + 0x2e) = 0;
          }
          else {
            *(int *)(lVar38 + 0x2e) = *(int *)(lVar38 + 0xc);
            *(int *)(lVar38 + 0xc) = *(int *)(lVar38 + 0xc) + 0xe;
            *(undefined8 *)(puVar33 + -8) = 0x10456f;
            uVar17 = func_0x(lVar38 + 10);
            *(undefined8 *)(puVar33 + -8) = 0x10457e;
            func_0x(uVar17,&stack0x00000250 + lVar12);
            *(undefined8 *)(puVar33 + -8) = 0x10458a;
            iVar45 = func_0x(&stack0x00000250 + lVar12);
            *(int *)(lVar38 + 0xc) = *(int *)(lVar38 + 0xc) + iVar45;
          }
          uVar27 = *(uint *)(lVar38 + 0xc);
          if ((*(ulonglong *)(lVar38 + 0x26) != 0) &&
             (*(ulonglong *)(lVar38 + 0x26) < (ulonglong)uVar27 + *(longlong *)(lVar38 + 0x10))) {
            *(undefined8 *)(puVar33 + -8) = 0x1045bf;
            cVar3 = func_0x(0x112fe00);
            if (cVar3 != '\0') {
              *(undefined8 *)(puVar33 + -8) = 0x1045c8;
              lVar15 = func_0x();
              if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                *(undefined8 *)(puVar33 + -8) = 0x1045e2;
                cVar3 = func_0x(0x112fe00);
                if (cVar3 == '\0') {
                  *(undefined8 *)(puVar33 + -8) = 0x1045fe;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar33 + 0x20) = 0;
                  *(undefined8 *)(puVar33 + -8) = 0x104624;
                  (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x886);
                }
              }
            }
            uVar17 = *(undefined8 *)(lVar38 + 0x10);
            *(undefined8 *)(puVar33 + -8) = 0x104632;
            func_0x(uVar17,0x12);
            uVar27 = *(uint *)(lVar38 + 0xc);
          }
          if ((uVar27 == 0) || (0x3f3c < uVar27)) {
            *(undefined8 *)(puVar33 + -8) = 0x104654;
            cVar3 = func_0x(0x112fe00);
            if (cVar3 != '\0') {
              *(undefined8 *)(puVar33 + -8) = 0x10465d;
              lVar15 = func_0x();
              if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                *(undefined8 *)(puVar33 + -8) = 0x104677;
                cVar3 = func_0x(0x112fe00);
                if (cVar3 == '\0') {
                  *(undefined8 *)(puVar33 + -8) = 0x104693;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar33 + 0x20) = 0;
                  *(undefined8 *)(puVar33 + -8) = 0x1046b9;
                  (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x88b);
                }
              }
            }
            uVar17 = *(undefined8 *)(lVar38 + 0x10);
            *(undefined8 *)(puVar33 + -8) = 0x1046c7;
            func_0x(uVar17,5);
            uVar27 = *(uint *)(lVar38 + 0xc);
          }
        }
LAB_:
        if ((uVar27 < 9) &&
           ((bVar24 = **(byte **)(lVar38 + 0x10) & 0xe, bVar24 == 0 || (bVar24 == 0xc)))) {
          uVar27 = 9;
        }
      }
      else {
        *(undefined8 *)(puVar33 + -8) = 0x1046f3;
        uVar27 = func_0x(lVar38 + 10);
      }
      if (uVar27 <= *(uint *)(&stack0x00000080 + lVar12)) goto LAB_;
      uVar42 = 0xba;
    }
    else {
      *(undefined8 *)(&stack0x00000040 + lVar12) = 0;
      *(undefined4 *)(&stack0x0000003c + lVar12) = 0;
      *(undefined8 *)(&stack0x00000056 + lVar12) = 0;
      *(undefined8 *)(&stack0x00000060 + lVar12) = 0;
      *(undefined8 *)(&stack0x00000048 + lVar12) = 0;
      sVar6 = *psVar43;
      *(short *)(&stack0x00000038 + lVar12) = sVar6;
      puVar47 = (ushort *)(lVar38 + 10);
      *(ushort **)(&stack0x00000028 + lVar12) = puVar47;
      *(undefined4 *)(&stack0x00000094 + lVar12) = 1;
      if (sVar6 == 0) {
        uVar27 = *(uint *)(lVar38 + 0xc);
        if (uVar27 == 0) {
          iVar45 = 0;
          *puVar47 = 0;
          uVar27 = *(uint *)(lVar38 + 0x18);
          uVar44 = (ulonglong)uVar27;
          *(uint *)(lVar38 + 0x1c) = uVar27;
          pbVar20 = *(byte **)(lVar38 + 0x10);
          bVar24 = *pbVar20;
          pbVar13 = pbVar20;
          if ((bVar24 & 0x10) != 0) {
            uVar27 = uVar27 + 2 + (*(ushort *)(pbVar20 + uVar44) + 7 >> 3);
            uVar44 = (ulonglong)uVar27;
            *(uint *)(lVar38 + 0x1c) = uVar27;
            bVar24 = *pbVar20;
            pbVar13 = *(byte **)(lVar38 + 0x10);
          }
          if ((bVar24 & 0x20) == 0) {
            *(int *)(lVar38 + 0xc) = (int)uVar44;
            *(undefined2 *)(lVar38 + 0x24) = 0;
            *(uint *)(lVar38 + 0x20) = uVar27;
            lVar15 = lVar38;
          }
          else {
            puVar46 = (ushort *)(pbVar20 + uVar44);
            uVar7 = *puVar46;
            *(ushort *)(lVar38 + 0x24) = uVar7;
            if (uVar7 == 0) {
              *(undefined8 *)(puVar33 + -8) = 0x1047d2;
              cVar3 = func_0x(0x112fe00);
              if (cVar3 != '\0') {
                *(undefined8 *)(puVar33 + -8) = 0x1047db;
                lVar15 = func_0x();
                if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar33 + -8) = 0x1047f5;
                  cVar3 = func_0x(0x112fe00);
                  if (cVar3 == '\0') {
                    *(undefined8 *)(puVar33 + -8) = 0x104811;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar33 + 0x20) = 0;
                    *(undefined8 *)(puVar33 + -8) = 0x104834;
                    (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x80f);
                  }
                }
              }
              uVar17 = *(undefined8 *)(lVar38 + 0x10);
              *(undefined8 *)(puVar33 + -8) = 0x104842;
              func_0x(uVar17,3);
              uVar7 = *(ushort *)(lVar38 + 0x24);
              uVar27 = *(uint *)(lVar38 + 0x1c);
            }
            uVar27 = uVar27 + (uVar7 + 1) * 2;
            *(uint *)(lVar38 + 0x20) = uVar27;
            if (0x1f9e < uVar27) {
              *(undefined8 *)(puVar33 + -8) = 0x104871;
              cVar3 = func_0x(0x112fe00);
              if (cVar3 != '\0') {
                *(undefined8 *)(puVar33 + -8) = 0x10487a;
                lVar15 = func_0x();
                if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar33 + -8) = 0x104894;
                  cVar3 = func_0x(0x112fe00);
                  if (cVar3 == '\0') {
                    *(undefined8 *)(puVar33 + -8) = 0x1048b0;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar33 + 0x20) = 0;
                    *(undefined8 *)(puVar33 + -8) = 0x1048d3;
                    (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x816);
                  }
                }
              }
              uVar17 = *(undefined8 *)(lVar38 + 0x10);
              *(undefined8 *)(puVar33 + -8) = 0x1048e1;
              func_0x(uVar17,4);
              uVar7 = *(ushort *)(lVar38 + 0x24);
              uVar27 = *(uint *)(lVar38 + 0x20);
            }
            uVar44 = (ulonglong)uVar7;
            uVar7 = puVar46[uVar44];
            *(uint *)(lVar38 + 0xc) = uVar7 & 0x7fff;
            if ((uVar7 & 0x7fff) < uVar27) {
              *(undefined8 *)(puVar33 + -8) = 0x104912;
              cVar3 = func_0x(0x112fe00);
              if (cVar3 != '\0') {
                *(undefined8 *)(puVar33 + -8) = 0x10491b;
                lVar15 = func_0x();
                if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar33 + -8) = 0x104935;
                  cVar3 = func_0x(0x112fe00);
                  if (cVar3 == '\0') {
                    *(undefined8 *)(puVar33 + -8) = 0x104951;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar33 + 0x20) = 0;
                    *(undefined8 *)(puVar33 + -8) = 0x104974;
                    (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x81d);
                  }
                }
              }
              uVar17 = *(undefined8 *)(lVar38 + 0x10);
              *(undefined8 *)(puVar33 + -8) = 0x104982;
              func_0x(uVar17,4);
              uVar27 = *(uint *)(lVar38 + 0x20);
              uVar44 = (ulonglong)*(ushort *)(lVar38 + 0x24);
            }
            puVar21 = puVar46;
            iVar34 = iVar45;
            if ((short)uVar44 != 0) {
              do {
                uVar35 = puVar21[1] & 0x7fff;
                if ((uVar35 < uVar27) || (*(uint *)(lVar38 + 0xc) < uVar35)) {
                  *(undefined8 *)(puVar33 + -8) = 0x1049d0;
                  cVar3 = func_0x(0x112fe00);
                  if (cVar3 != '\0') {
                    *(undefined8 *)(puVar33 + -8) = 0x1049d9;
                    lVar15 = func_0x();
                    if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar33 + -8) = 0x1049f3;
                      cVar3 = func_0x(0x112fe00);
                      if (cVar3 == '\0') {
                        *(undefined8 *)(puVar33 + -8) = 0x104a0f;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar33 + 0x20) = 0;
                        *(undefined8 *)(puVar33 + -8) = 0x104a33;
                        (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x82a);
                      }
                    }
                  }
                  uVar17 = *(undefined8 *)(lVar38 + 0x10);
                  *(undefined8 *)(puVar33 + -8) = 0x104a41;
                  func_0x(uVar17,4);
                }
                iVar34 = iVar34 + 1;
                uVar44 = (ulonglong)*(ushort *)(lVar38 + 0x24);
                puVar21 = puVar21 + 1;
                uVar27 = uVar35;
              } while (iVar34 < (int)(uint)*(ushort *)(lVar38 + 0x24));
            }
            if ((short)puVar46[(ulonglong)((int)uVar44 - 1) + 1] < 0) {
              do {
                lVar15 = *(longlong *)(lVar38 + 0x10);
                lVar18 = (ulonglong)*(uint *)(lVar38 + 0x1c) + lVar15;
                lVar16 = *(longlong *)(&stack0x00000088 + lVar12);
                uVar35 = *(ushort *)(lVar18 + uVar44 * 2) & 0x7fff;
                if ((int)uVar44 == 1) {
                  uVar36 = *(uint *)(lVar38 + 0x20);
                  uVar41 = uVar36;
LAB_:
                  if ((uVar35 < uVar36) || (uVar27 = *(uint *)(lVar38 + 0xc), uVar27 < uVar35))
                  goto LAB_;
                }
                else {
                  uVar36 = *(ushort *)(lVar18 + -2 + uVar44 * 2) & 0x7fff;
                  uVar41 = *(uint *)(lVar16 + 0x20);
                  if (uVar41 <= uVar36) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar33 + -8) = 0x104acc;
                  func_0x(lVar15,7);
                  uVar41 = *(uint *)(lVar16 + 0x20);
                  uVar27 = *(uint *)(lVar16 + 0xc);
                  lVar15 = *(longlong *)(lVar16 + 0x10);
                }
                if ((uVar36 < uVar41) || (uVar27 < uVar36)) goto LAB_;
                if (*(ushort *)((ulonglong)uVar36 + lVar15) == 5) {
                  *puVar47 = *puVar47 | 2;
                  *(short *)(lVar38 + 0x24) = *(short *)(lVar38 + 0x24) + -1;
                  uVar39 = (ulonglong)(uVar36 & 0xffff);
                  *(short *)(lVar38 + 0x32) = (short)uVar36;
                  uVar44 = *(ulonglong *)(lVar38 + 0x10);
                  uVar7 = *(ushort *)(lVar38 + 0x34) & 0xc7ff;
                  if ((*(ushort *)(uVar39 + 2 + uVar44) >> 0xe & 1) != 0) {
                    uVar7 = *(ushort *)(uVar39 + 2 + uVar44) & 0x3800 | uVar7;
                  }
                  *(ushort *)(lVar38 + 0x34) = uVar7;
                  uVar8 = (uVar7 ^ *(ushort *)(uVar39 + 2 + uVar44)) & 0x7ff ^ uVar7;
                  *(ushort *)(lVar38 + 0x34) = uVar8;
                  uVar30 = (ulonglong)*(ushort *)(lVar38 + 0x32);
                  uVar39 = uVar30 + 4 +
                           (ulonglong)((uVar8 & 0x7ff) * 2) + uVar44 + (uVar7 >> 0xb & 7) * 2;
                  if (uVar39 < uVar30 + uVar44) {
                    *(undefined8 *)(puVar33 + -8) = 0x104bea;
                    func_0x(uVar30 + uVar44,0x19);
                    uVar8 = *(ushort *)(lVar38 + 0x34);
                    uVar30 = (ulonglong)*(ushort *)(lVar38 + 0x32);
                    uVar44 = (ulonglong)*(uint *)(lVar38 + 0x10);
                  }
                  if (uVar35 - uVar36 <
                      (((uVar8 & 0x7ff) * 2 - (int)uVar30) - (int)uVar44) + (int)uVar39) {
                    lVar15 = *(longlong *)(lVar38 + 0x10);
                    *(undefined8 *)(puVar33 + -8) = 0x104c22;
                    func_0x(uVar30 + lVar15,0x19);
                    uVar8 = *(ushort *)(lVar38 + 0x34);
                  }
                  if (((uVar8 & 0x3800) != 0) &&
                     (puVar46 = (ushort *)
                                (*(longlong *)(lVar38 + 0x10) + 4 +
                                (ulonglong)*(ushort *)(lVar38 + 0x32)), (uVar8 & 0x3800) != 0)) {
                    do {
                      if ((uVar8 & 0x7ff) < (*puVar46 & 0x7ff)) {
                        uVar7 = *(ushort *)(lVar38 + 0x32);
                        lVar15 = *(longlong *)(lVar38 + 0x10);
                        *(undefined8 *)(puVar33 + -8) = 0x104c87;
                        func_0x((ulonglong)uVar7 + lVar15,0x1a);
                        uVar8 = *(ushort *)(lVar38 + 0x34);
                      }
                      iVar45 = iVar45 + 1;
                      puVar46 = puVar46 + 1;
                    } while (iVar45 < (int)(uVar8 >> 0xb & 7));
                  }
                  goto LAB_;
                }
                if (*(ushort *)((ulonglong)uVar36 + lVar15) < 0x400) goto LAB_;
                *puVar47 = *puVar47 | 1;
                uVar7 = *(short *)(lVar38 + 0x24) - 1;
                *(ushort *)(lVar38 + 0x24) = uVar7;
                if (uVar7 == 0) goto LAB_;
                uVar44 = (ulonglong)uVar7;
              } while ((short)puVar46[(ulonglong)(uVar7 - 1) + 1] < 0);
              pbVar13 = *(byte **)(lVar38 + 0x10);
              lVar15 = *(longlong *)(&stack0x00000088 + lVar12);
            }
            else {
LAB_:
              pbVar13 = *(byte **)(lVar38 + 0x10);
              lVar15 = *(longlong *)(&stack0x00000088 + lVar12);
            }
          }
          if ((*pbVar13 & 0x40) == 0) {
            *(undefined4 *)(lVar38 + 0x2e) = 0;
            uVar27 = *(uint *)(lVar15 + 0xc);
          }
          else {
            *(int *)(lVar38 + 0x2e) = *(int *)(lVar38 + 0xc);
            *(int *)(lVar38 + 0xc) = *(int *)(lVar38 + 0xc) + 0xe;
            *(undefined8 *)(puVar33 + -8) = 0x104cd6;
            uVar17 = func_0x(puVar47);
            *(undefined8 *)(puVar33 + -8) = 0x104ce5;
            func_0x(uVar17,&stack0x00000258 + lVar12);
            *(undefined8 *)(puVar33 + -8) = 0x104cf1;
            iVar45 = func_0x(&stack0x00000258 + lVar12);
            *(int *)(lVar38 + 0xc) = *(int *)(lVar38 + 0xc) + iVar45;
            uVar27 = *(uint *)(lVar38 + 0xc);
            pbVar13 = *(byte **)(lVar38 + 0x10);
          }
          if ((*(byte **)(lVar38 + 0x26) != (byte *)0x0) &&
             (*(byte **)(lVar38 + 0x26) < pbVar13 + uVar27)) {
            *(undefined8 *)(puVar33 + -8) = 0x104d2d;
            cVar3 = func_0x(0x112fe00);
            if (cVar3 != '\0') {
              *(undefined8 *)(puVar33 + -8) = 0x104d36;
              lVar16 = func_0x();
              if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                *(undefined8 *)(puVar33 + -8) = 0x104d50;
                cVar3 = func_0x(0x112fe00);
                if (cVar3 == '\0') {
                  *(undefined8 *)(puVar33 + -8) = 0x104d6c;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar33 + 0x20) = 0;
                  *(undefined8 *)(puVar33 + -8) = 0x104d8f;
                  (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x886);
                }
              }
            }
            uVar17 = *(undefined8 *)(lVar38 + 0x10);
            *(undefined8 *)(puVar33 + -8) = 0x104d9d;
            func_0x(uVar17,0x12);
            uVar27 = *(uint *)(lVar15 + 0xc);
          }
          if ((uVar27 == 0) || (0x3f3c < uVar27)) {
            *(undefined8 *)(puVar33 + -8) = 0x104dbe;
            cVar3 = func_0x(0x112fe00);
            if (cVar3 != '\0') {
              *(undefined8 *)(puVar33 + -8) = 0x104dc7;
              lVar16 = func_0x();
              if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                *(undefined8 *)(puVar33 + -8) = 0x104de1;
                cVar3 = func_0x(0x112fe00);
                if (cVar3 == '\0') {
                  *(undefined8 *)(puVar33 + -8) = 0x104dfd;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar33 + 0x20) = 0;
                  *(undefined8 *)(puVar33 + -8) = 0x104e20;
                  (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x88b);
                }
              }
            }
            uVar17 = *(undefined8 *)(lVar38 + 0x10);
            *(undefined8 *)(puVar33 + -8) = 0x104e2e;
            func_0x(uVar17,5);
            uVar27 = *(uint *)(lVar15 + 0xc);
          }
LAB_:
          psVar43 = *(short **)(&stack0x00000078 + lVar12);
        }
        if ((uVar27 < 9) &&
           ((bVar24 = **(byte **)(lVar38 + 0x10) & 0xe, bVar24 == 0 || (bVar24 == 0xc)))) {
          uVar27 = 9;
        }
        *(undefined4 *)(&stack0x00000048 + lVar12) = *(undefined4 *)(lVar38 + 0x18);
        *(ushort *)(&stack0x0000003a + lVar12) = *puVar47;
        *(undefined4 *)(&stack0x0000003c + lVar12) = *(undefined4 *)(lVar38 + 0xc);
        *(undefined2 *)(&stack0x00000054 + lVar12) = *(undefined2 *)(lVar38 + 0x24);
        *(undefined4 *)(&stack0x0000004c + lVar12) = *(undefined4 *)(lVar38 + 0x1c);
        *(undefined4 *)(&stack0x00000050 + lVar12) = *(undefined4 *)(lVar38 + 0x20);
        *(undefined4 *)(&stack0x0000005e + lVar12) = *(undefined4 *)(lVar38 + 0x2e);
        uVar17 = *(undefined8 *)(lVar38 + 0x10);
        *(undefined8 *)(puVar33 + -8) = 0x104e97;
        func_0x(&stack0x00000928 + lVar12,0x1f9e,uVar17,uVar27);
        *(undefined **)(&stack0x00000040 + lVar12) = &stack0x00000928 + lVar12;
        *(undefined8 *)(puVar33 + -8) = 0x104eab;
        iVar45 = func_0x(&stack0x0000003a + lVar12);
        if (iVar45 != 0) {
          *(undefined8 *)(puVar33 + -8) = 0x104ec3;
          uVar7 = func_0x(&stack0x0000003a + lVar12,&stack0x000001d0 + lVar12);
          uVar27 = *(uint *)(&stack0x000001d0 + lVar12);
          *(ushort *)(&stack0x00000062 + lVar12) = uVar7;
          lVar38 = (ulonglong)uVar7 + *(longlong *)(&stack0x00000040 + lVar12);
          *(undefined8 *)(puVar33 + -8) = 0x104edc;
          iVar45 = func_0x(lVar38);
          if (iVar45 == 0) {
            *(ushort *)(&stack0x00000064 + lVar12) = *(ushort *)(&stack0x00000064 + lVar12) & 0xc7ff
            ;
          }
          else {
            *(undefined8 *)(puVar33 + -8) = 0x104ee8;
            sVar6 = func_0x(lVar38);
            *(ushort *)(&stack0x00000064 + lVar12) =
                 *(ushort *)(&stack0x00000064 + lVar12) ^
                 (sVar6 << 0xb ^ *(ushort *)(&stack0x00000064 + lVar12)) & 0x3800;
          }
          *(undefined8 *)(puVar33 + -8) = 0x104f17;
          uVar8 = func_0x(lVar38);
          uVar7 = *(ushort *)(&stack0x00000064 + lVar12);
          uVar8 = (uVar8 ^ *(ushort *)(&stack0x00000064 + lVar12)) & 0x7ff ^ uVar7;
          uVar39 = (ulonglong)uVar8;
          *(ushort *)(&stack0x00000064 + lVar12) = uVar8;
          uVar30 = (ulonglong)*(ushort *)(&stack0x00000062 + lVar12);
          lVar38 = *(longlong *)(&stack0x00000040 + lVar12);
          uVar44 = (uVar7 >> 0xb & 7) * 2 + uVar30 + ((uVar39 & 0x7ff) + 2) * 2 + lVar38;
          if (uVar44 < lVar38 + uVar30) {
            *(undefined8 *)(puVar33 + -8) = 0x104f6f;
            func_0x(lVar38 + uVar30,0x19);
            uVar39 = (ulonglong)*(ushort *)(&stack0x00000064 + lVar12);
            uVar30 = (ulonglong)*(ushort *)(&stack0x00000062 + lVar12);
            lVar38 = *(longlong *)(&stack0x00000040 + lVar12);
          }
          if (uVar27 < (((*(uint *)(&stack0x00000064 + lVar12) & 0x7ff) * 2 - (int)uVar30) -
                       *(int *)(&stack0x00000040 + lVar12)) + (int)uVar44) {
            *(undefined8 *)(puVar33 + -8) = 0x104fa5;
            func_0x(uVar30 + lVar38,0x19);
            uVar39 = (ulonglong)*(ushort *)(&stack0x00000064 + lVar12);
            uVar30 = (ulonglong)*(ushort *)(&stack0x00000062 + lVar12);
            lVar38 = *(longlong *)(&stack0x00000040 + lVar12);
          }
          iVar45 = 0;
          if (((uVar39 & 0x3800) != 0) && ((uVar39 & 0x3800) != 0)) {
            do {
              *(undefined8 *)(puVar33 + -8) = 0x104fe0;
              uVar7 = func_0x(uVar30 + lVar38 + 4,iVar45);
              if ((*(ushort *)(&stack0x00000064 + lVar12) & 0x7ff) < uVar7) {
                uVar7 = *(ushort *)(&stack0x00000062 + lVar12);
                lVar15 = *(longlong *)(&stack0x00000040 + lVar12);
                *(undefined8 *)(puVar33 + -8) = 0x104fff;
                func_0x((ulonglong)uVar7 + lVar15,0x1a);
              }
              iVar45 = iVar45 + 1;
            } while (iVar45 < (int)(*(uint *)(&stack0x00000064 + lVar12) >> 0xb & 7));
          }
        }
        lVar38 = *(longlong *)(&stack0x00000088 + lVar12);
      }
      else {
        if (*psVar43 != 0) {
          *(undefined8 *)(puVar33 + -8) = 0x1050ae;
          lVar15 = func_0x(puVar47);
          if (lVar15 != 0) {
            if (*psVar43 == 0) {
              uVar17 = 0;
            }
            else {
              *(undefined8 *)(puVar33 + -8) = 0x1050cb;
              uVar17 = func_0x(puVar47);
            }
            *(undefined8 *)(puVar33 + -8) = 0x1050d6;
            iVar45 = func_0x(uVar17);
            if (iVar45 != 0) {
              *(undefined8 *)(puVar33 + -8) = 0x1050f5;
              func_0x(&stack0x00000038 + lVar12,&stack0x00000928 + lVar12,0x1f9e,psVar43);
              goto LAB_;
            }
          }
        }
        *(undefined8 *)(puVar33 + -8) = 0x105115;
        func_0x(&stack0x0000003a + lVar12,&stack0x00000928 + lVar12,0x1f9e,puVar47);
        if (*psVar43 == 0) {
          *(undefined8 *)(puVar33 + -8) = 0x10512e;
          func_0x(&stack0x0000003a + lVar12,0);
        }
        else {
          *(undefined8 *)(puVar33 + -8) = 0x10513b;
          uVar17 = func_0x(puVar47);
          *(undefined8 *)(puVar33 + -8) = 0x10514a;
          func_0x(&stack0x0000003a + lVar12,uVar17);
        }
      }
LAB_:
      uVar17 = 0;
      *(undefined8 *)(puVar33 + -8) = 0x105025;
      sVar6 = func_0x(&stack0x00000038 + lVar12);
      uVar27 = 0;
      if (sVar6 == 0) {
        *(undefined8 *)(puVar33 + -8) = 0x105037;
        puVar46 = (ushort *)func_0x(&stack0x00000038 + lVar12);
        *(undefined8 *)(puVar33 + -8) = 0x105042;
        puVar47 = (ushort *)func_0x(psVar43);
        *(ushort **)(&stack0x00000070 + lVar12) = puVar47;
        uVar17 = *(undefined8 *)(lVar38 + 0x10);
        *(undefined8 *)(&stack0x00000028 + lVar12) = 0;
        *(undefined8 *)(puVar33 + -8) = 0x10505e;
        lVar38 = func_0x(&stack0x000000b8 + lVar12);
        *(undefined8 *)(&stack0x000001b8 + lVar12) = 0;
        *(undefined4 *)(&stack0x000000a8 + lVar12) = 0;
        lVar38 = lVar38 + 0x10;
        *(undefined8 *)(puVar33 + -8) = 0x105078;
        iVar45 = func_0x(lVar38);
        *(undefined8 *)(puVar33 + -8) = 0x105084;
        uVar27 = func_0x(puVar46);
        if ((uint)-iVar45 < uVar27) {
          *(undefined8 *)(puVar33 + -8) = 0x105097;
          uVar27 = func_0x(puVar46);
        }
        else {
          *(undefined8 *)(puVar33 + -8) = 0x10515f;
          iVar45 = func_0x(lVar38);
          uVar27 = -iVar45;
        }
        uVar44 = (ulonglong)uVar27;
        *puVar1 = uVar27;
        *(undefined8 *)(puVar33 + -8) = 0x10516e;
        iVar45 = func_0x(puVar46);
        if (iVar45 != 0) {
          *(undefined8 *)(puVar33 + -8) = 0x10518c;
          cVar3 = func_0x
                            (&stack0x000000b8 + lVar12,&stack0x000001b8 + lVar12,
                             &stack0x000000a8 + lVar12);
          if (cVar3 != '\0') {
            uVar42 = *(undefined4 *)(&stack0x000000a8 + lVar12);
            uVar22 = *(undefined8 *)(&stack0x000001b8 + lVar12);
            *(undefined8 *)(puVar33 + -8) = 0x1051a5;
            uVar35 = func_0x(uVar22,uVar42,puVar46);
            if (uVar27 <= uVar35) {
              uVar42 = *(undefined4 *)(&stack0x000000a8 + lVar12);
              uVar22 = *(undefined8 *)(&stack0x000001b8 + lVar12);
              *(undefined8 *)(puVar33 + -8) = 0x1051c1;
              uVar27 = func_0x(uVar22,uVar42,puVar46);
              uVar44 = (ulonglong)uVar27;
              *puVar1 = uVar27;
            }
          }
        }
        *(undefined8 *)(puVar33 + -8) = 0x1051ce;
        uVar27 = func_0x(lVar38);
        *(undefined8 *)(puVar33 + -8) = 0x1051d9;
        uVar42 = func_0x(lVar38);
        *(undefined8 *)(puVar47 + 3) = uVar17;
        *(undefined4 *)(puVar47 + 7) = uVar42;
        iVar45 = 0;
        puVar47[0xd] = 0;
        *puVar47 = 0;
        uVar35 = 0;
        *(undefined4 *)(puVar47 + 0x12) = 0;
        *(undefined8 *)(puVar33 + -8) = 0x1051f8;
        cVar3 = func_0x(puVar46);
        if (cVar3 == '\x06') {
          *(undefined8 *)(puVar33 + -8) = 0x105204;
          puVar19 = (undefined *)func_0x(puVar47);
          *puVar19 = 6;
          uVar36 = 1;
        }
        else {
          *(undefined8 *)(puVar33 + -8) = 0x105217;
          puVar19 = (undefined *)func_0x(puVar47);
          *puVar19 = 0;
          *(undefined *)(*(longlong *)(puVar47 + 3) + 1) = 0;
          uVar42 = *(undefined4 *)(puVar47 + 7);
          *(undefined8 *)(puVar33 + -8) = 0x10522d;
          func_0x(puVar47,uVar42);
          uVar36 = 4;
        }
        uVar41 = *(uint *)(puVar46 + 7);
        if (*(uint *)(puVar47 + 7) <= uVar41) {
          uVar41 = *(uint *)(puVar47 + 7);
        }
        lVar38 = *(longlong *)(puVar46 + 3);
        lVar15 = *(longlong *)(puVar47 + 3);
        *(undefined8 *)(puVar33 + -8) = 0x10525b;
        func_0x
                  (lVar15 + (ulonglong)uVar36,lVar38 + (ulonglong)uVar36,uVar41 - uVar36);
        if (uVar27 == 0) {
          uVar42 = *(undefined4 *)(puVar47 + 7);
          *(undefined4 *)(puVar47 + 9) = uVar42;
        }
        else {
          *(undefined8 *)(puVar33 + -8) = 0x10526c;
          pbVar20 = (byte *)func_0x(puVar47);
          *pbVar20 = *pbVar20 | 0x10;
          *(uint *)(puVar47 + 9) = (uVar27 + 7 >> 3) + 2 + *(int *)(puVar47 + 7);
          *(undefined8 *)(puVar33 + -8) = 0x105287;
          pbVar20 = (byte *)func_0x(puVar46);
          if ((*pbVar20 & 0x10) == 0) {
            uVar36 = 0;
            *(undefined8 *)(puVar33 + -8) = 0x10532b;
            func_0x(&stack0x000002a0 + lVar12);
            *(short *)((ulonglong)*(uint *)(puVar47 + 7) + *(longlong *)(puVar47 + 3)) =
                 (short)uVar27;
          }
          else {
            lVar38 = *(longlong *)(puVar46 + 3);
            uVar7 = *(ushort *)((ulonglong)*(uint *)(puVar46 + 7) + lVar38);
            uVar36 = (uint)uVar7;
            if (uVar7 == uVar27) {
              uVar27 = *(uint *)(puVar47 + 7);
              iVar34 = *(int *)(puVar47 + 9);
              uVar36 = *(uint *)(puVar46 + 7);
              lVar15 = *(longlong *)(puVar47 + 3);
              *(undefined8 *)(puVar33 + -8) = 0x1052b9;
              func_0x
                        ((ulonglong)uVar27 + lVar15,(ulonglong)uVar36 + lVar38,iVar34 - uVar27);
              uVar42 = *(undefined4 *)(puVar47 + 9);
              uVar44 = (ulonglong)*puVar1;
              goto LAB_;
            }
            *(undefined8 *)(puVar33 + -8) = 0x1052d0;
            func_0x(&stack0x000002a0 + lVar12);
            *(short *)((ulonglong)*(uint *)(puVar47 + 7) + *(longlong *)(puVar47 + 3)) =
                 (short)uVar27;
            if (uVar7 != 0) {
              uVar41 = *(uint *)(puVar46 + 7);
              uVar11 = *(int *)(puVar46 + 9) - uVar41;
              uVar26 = *(uint *)(puVar47 + 7);
              uVar25 = *(int *)(puVar47 + 9) - uVar26;
              if (uVar11 <= uVar25) {
                uVar25 = uVar11;
              }
              lVar38 = *(longlong *)(puVar46 + 3);
              lVar15 = *(longlong *)(puVar47 + 3);
              *(undefined8 *)(puVar33 + -8) = 0x10531a;
              func_0x
                        (lVar15 + (ulonglong)uVar26 + 2,(ulonglong)uVar41 + lVar38 + 2,uVar25 - 2);
            }
          }
          if (uVar27 < uVar36) {
            uVar36 = uVar27 & 0xffff;
          }
          uVar7 = (ushort)uVar36;
          while (uVar7 = uVar7 + 1, uVar7 <= uVar27) {
            *(undefined8 *)(puVar33 + -8) = 0x10535f;
            func_0x(&stack0x000002a0 + lVar12,uVar7);
            *(undefined8 *)(puVar33 + -8) = 0x10536e;
            func_0x(puVar47,&stack0x000002a0 + lVar12);
          }
          uVar42 = *(undefined4 *)(puVar47 + 9);
          uVar44 = (ulonglong)*puVar1;
        }
LAB_:
        *(undefined4 *)(puVar47 + 0xb) = uVar42;
        *(undefined4 *)(puVar47 + 1) = uVar42;
        uVar27 = (uint)uVar44;
        if (uVar27 == 0) {
          lVar38 = *(longlong *)(&stack0x00000028 + lVar12);
        }
        else {
          uVar39 = uVar44 * 0x20 + 0xf;
          if (uVar39 <= uVar44 * 0x20) {
            uVar39 = 0xffffffffffffff0;
          }
          uVar39 = uVar39 & 0xfffffffffffffff0;
          *(undefined8 *)(puVar33 + -8) = 0x1053bf;
          func_0x();
          lVar15 = -uVar39;
          *(undefined **)(&stack0x00000028 + lVar12) = puVar33 + lVar15 + 0x50;
          if (*(int *)(puVar46 + 1) == 0) {
            *puVar46 = 0;
            *(undefined4 *)(puVar46 + 9) = *(undefined4 *)(puVar46 + 7);
            *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1053e7;
            pbVar20 = (byte *)func_0x(puVar46);
            if ((*pbVar20 & 0x10) != 0) {
              *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1053f4;
              pbVar20 = (byte *)func_0x(puVar46);
              if ((*pbVar20 & 0x10) != 0) {
                uVar35 = (uint)*(ushort *)
                                ((ulonglong)*(uint *)(puVar46 + 7) + *(longlong *)(puVar46 + 3));
              }
              *(uint *)(puVar46 + 9) = *(int *)(puVar46 + 9) + (uVar35 + 7 >> 3) + 2;
            }
            *(undefined8 *)(puVar33 + lVar15 + -8) = 0x10541d;
            pbVar20 = (byte *)func_0x(puVar46);
            if ((*pbVar20 & 0x20) == 0) {
              *(undefined4 *)(puVar46 + 1) = *(undefined4 *)(puVar46 + 9);
              puVar46[0xd] = 0;
              *(undefined4 *)(puVar46 + 0xb) = *(undefined4 *)(puVar46 + 9);
            }
            else {
              *(undefined8 *)(puVar33 + lVar15 + -8) = 0x10542e;
              puVar21 = (ushort *)func_0x(puVar46);
              uVar7 = *puVar21;
              puVar46[0xd] = uVar7;
              if (uVar7 == 0) {
                *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105449;
                cVar3 = func_0x(0x112fe00);
                if (cVar3 != '\0') {
                  *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105452;
                  cVar3 = func_0x();
                  if (cVar3 != '\0') {
                    *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105462;
                    cVar3 = func_0x(0x112fe00);
                    if (cVar3 == '\0') {
                      *(undefined8 *)(puVar33 + lVar15 + -8) = 0x10547e;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar33 + lVar15 + 0x20) = 0;
                      *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1054a2;
                      (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x80f);
                    }
                  }
                }
                uVar17 = *(undefined8 *)(puVar46 + 3);
                *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1054b0;
                func_0x(uVar17,3);
                uVar7 = puVar46[0xd];
              }
              uVar27 = *(int *)(puVar46 + 9) + (uVar7 + 1) * 2;
              *(uint *)(puVar46 + 0xb) = uVar27;
              if (0x1f9e < uVar27) {
                *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1054d7;
                cVar3 = func_0x(0x112fe00);
                if (cVar3 != '\0') {
                  *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1054e0;
                  cVar3 = func_0x();
                  if (cVar3 != '\0') {
                    *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1054f0;
                    cVar3 = func_0x(0x112fe00);
                    if (cVar3 == '\0') {
                      *(undefined8 *)(puVar33 + lVar15 + -8) = 0x10550c;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar33 + lVar15 + 0x20) = 0;
                      *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105530;
                      (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x816);
                    }
                  }
                }
                uVar17 = *(undefined8 *)(puVar46 + 3);
                *(undefined8 *)(puVar33 + lVar15 + -8) = 0x10553e;
                func_0x(uVar17,4);
                uVar7 = puVar46[0xd];
              }
              puVar21 = puVar21 + 1;
              *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105554;
              uVar7 = func_0x(puVar21,(ulonglong)uVar7 - 1);
              *(uint *)(puVar46 + 1) = (uint)uVar7;
              uVar27 = *(uint *)(puVar46 + 0xb);
              if (uVar7 < uVar27) {
                *(undefined8 *)(puVar33 + lVar15 + -8) = 0x10556f;
                cVar3 = func_0x(0x112fe00);
                if (cVar3 != '\0') {
                  *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105578;
                  cVar3 = func_0x();
                  if (cVar3 != '\0') {
                    *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105588;
                    cVar3 = func_0x(0x112fe00);
                    if (cVar3 == '\0') {
                      *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1055a4;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar33 + lVar15 + 0x20) = 0;
                      *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1055ca;
                      (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x81d);
                    }
                  }
                }
                uVar17 = *(undefined8 *)(puVar46 + 3);
                *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1055d8;
                func_0x(uVar17,4);
                uVar27 = *(uint *)(puVar46 + 0xb);
              }
              uVar7 = puVar46[0xd];
              iVar34 = iVar45;
              if (uVar7 != 0) {
                do {
                  *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1055fd;
                  uVar7 = func_0x(puVar21,(longlong)iVar34);
                  bVar48 = uVar7 < uVar27;
                  uVar27 = (uint)uVar7;
                  if ((bVar48) ||
                     (*(uint *)(puVar46 + 1) <= (uint)uVar7 && uVar27 != *(uint *)(puVar46 + 1))) {
                    *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105618;
                    cVar3 = func_0x(0x112fe00);
                    if (cVar3 != '\0') {
                      *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105621;
                      cVar3 = func_0x();
                      if (cVar3 != '\0') {
                        *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105631;
                        cVar3 = func_0x(0x112fe00);
                        if (cVar3 == '\0') {
                          *(undefined8 *)(puVar33 + lVar15 + -8) = 0x10564d;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar33 + lVar15 + 0x20) = 0;
                          *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105670;
                          (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x82a);
                        }
                      }
                    }
                    uVar17 = *(undefined8 *)(puVar46 + 3);
                    *(undefined8 *)(puVar33 + lVar15 + -8) = 0x10567e;
                    func_0x(uVar17,4);
                  }
                  iVar34 = iVar34 + 1;
                  uVar7 = puVar46[0xd];
                } while (iVar34 < (int)(uint)uVar7);
                puVar47 = *(ushort **)(&stack0x00000070 + lVar12);
              }
              *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1056a0;
              iVar34 = func_0x(puVar21,uVar7 - 1);
              while (iVar34 != 0) {
                uVar7 = puVar46[0xd];
                *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1056bc;
                lVar38 = func_0x(puVar46);
                if (uVar7 == 1) {
                  uVar27 = *(uint *)(puVar46 + 0xb);
                }
                else {
                  *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1056d9;
                  uVar8 = func_0x(lVar38 + 2,(ulonglong)uVar7 - 2);
                  uVar27 = (uint)uVar8;
                }
                *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1056e9;
                uVar7 = func_0x(lVar38 + 2,(ulonglong)(uint)uVar7 - 1);
                uVar35 = *(uint *)(puVar46 + 0xb);
                if (((uVar27 < uVar35) || (uVar7 < uVar27)) ||
                   (*(uint *)(puVar46 + 1) <= (uint)uVar7 && (uint)uVar7 != *(uint *)(puVar46 + 1)))
                {
                  uVar17 = *(undefined8 *)(puVar46 + 3);
                  *(undefined8 *)(puVar33 + lVar15 + -8) = 0x10570d;
                  func_0x(uVar17,7);
                  uVar35 = *(uint *)(puVar46 + 0xb);
                }
                if ((uVar27 < uVar35) || (*(uint *)(puVar46 + 1) < uVar27)) {
                  uVar27 = *puVar1;
                  goto LAB_;
                }
                if (*(ushort *)((ulonglong)uVar27 + *(longlong *)(puVar46 + 3)) == 5) {
                  *puVar46 = *puVar46 | 2;
                  puVar46[0xd] = puVar46[0xd] - 1;
                  puVar46[0x14] = (ushort)uVar27;
                  lVar38 = (ulonglong)(uVar27 & 0xffff) + *(longlong *)(puVar46 + 3);
                  *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1057dc;
                  iVar34 = func_0x(lVar38);
                  if (iVar34 == 0) {
                    puVar46[0x15] = puVar46[0x15] & 0xc7ff;
                  }
                  else {
                    *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1057e8;
                    uVar8 = func_0x(lVar38);
                    puVar46[0x15] = puVar46[0x15] & 0xc7ff;
                    puVar46[0x15] = puVar46[0x15] | (uVar8 & 7) << 0xb;
                  }
                  *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105810;
                  uVar8 = func_0x(lVar38);
                  puVar46[0x15] = puVar46[0x15] ^ (uVar8 ^ puVar46[0x15]) & 0x7ff;
                  uVar9 = puVar46[0x15];
                  uVar39 = *(ulonglong *)(puVar46 + 3);
                  uVar8 = puVar46[0x14];
                  uVar30 = (ulonglong)((uVar9 & 0x7ff) * 2) + 4 + uVar39 + (uVar9 >> 0xb & 7) * 2 +
                           (ulonglong)uVar8;
                  uVar44 = uVar39 + uVar8;
                  if (uVar30 < uVar44) {
                    *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105866;
                    func_0x(uVar44,0x19);
                    uVar9 = puVar46[0x15];
                    uVar8 = puVar46[0x14];
                    uVar39 = (ulonglong)*(uint *)(puVar46 + 3);
                  }
                  if (uVar7 - uVar27 <
                      (((uVar9 & 0x7ff) * 2 - (uint)uVar8) - (int)uVar39) + (int)uVar30) {
                    uVar7 = puVar46[0x14];
                    lVar38 = *(longlong *)(puVar46 + 3);
                    *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1058a2;
                    func_0x((ulonglong)uVar7 + lVar38,0x19);
                    uVar9 = puVar46[0x15];
                  }
                  if (((uVar9 & 0x3800) != 0) &&
                     (uVar7 = puVar46[0x14], lVar38 = *(longlong *)(puVar46 + 3),
                     (uVar9 & 0x3800) != 0)) {
                    do {
                      uVar8 = puVar46[0x15];
                      *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1058f0;
                      uVar9 = func_0x((ulonglong)uVar7 + lVar38 + 4,iVar45);
                      if ((uVar8 & 0x7ff) < uVar9) {
                        uVar8 = puVar46[0x14];
                        lVar16 = *(longlong *)(puVar46 + 3);
                        *(undefined8 *)(puVar33 + lVar15 + -8) = 0x10590f;
                        func_0x((ulonglong)uVar8 + lVar16,0x1a);
                        uVar8 = puVar46[0x15];
                      }
                      iVar45 = iVar45 + 1;
                    } while (iVar45 < (int)(uVar8 >> 0xb & 7));
                  }
                  break;
                }
                if (*(ushort *)((ulonglong)uVar27 + *(longlong *)(puVar46 + 3)) < 0x400) break;
                *puVar46 = *puVar46 | 1;
                uVar7 = puVar46[0xd] - 1;
                puVar46[0xd] = uVar7;
                if (uVar7 == 0) break;
                *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105761;
                iVar34 = func_0x(puVar21,uVar7 - 1);
              }
              uVar27 = *puVar1;
            }
            *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105777;
            iVar45 = func_0x(puVar46);
            if (iVar45 == 0) {
              *(undefined4 *)(puVar46 + 0x12) = 0;
            }
            else {
              *(int *)(puVar46 + 0x12) = *(int *)(puVar46 + 1);
              *(int *)(puVar46 + 1) = *(int *)(puVar46 + 1) + 0xe;
              *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105796;
              uVar17 = func_0x(puVar46);
              *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1057a5;
              func_0x(uVar17,&stack0x00000260 + lVar12);
              *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1057b1;
              iVar45 = func_0x(&stack0x00000260 + lVar12);
              *(int *)(puVar46 + 1) = *(int *)(puVar46 + 1) + iVar45;
            }
            uVar35 = *(uint *)(puVar46 + 1);
            if ((*(ulonglong *)(puVar46 + 0xe) != 0) &&
               (*(ulonglong *)(puVar46 + 0xe) < (ulonglong)uVar35 + *(longlong *)(puVar46 + 3))) {
              *(undefined8 *)(puVar33 + lVar15 + -8) = 0x10596a;
              cVar3 = func_0x(0x112fe00);
              if (cVar3 != '\0') {
                *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105973;
                cVar3 = func_0x();
                if (cVar3 != '\0') {
                  *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105983;
                  cVar3 = func_0x(0x112fe00);
                  if (cVar3 == '\0') {
                    *(undefined8 *)(puVar33 + lVar15 + -8) = 0x10599f;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar33 + lVar15 + 0x20) = 0;
                    *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1059c5;
                    (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x886);
                  }
                }
              }
              uVar17 = *(undefined8 *)(puVar46 + 3);
              *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1059d3;
              func_0x(uVar17,0x12);
              uVar35 = *(uint *)(puVar46 + 1);
            }
            if (0x3f3b < uVar35 - 1) {
              *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1059f3;
              cVar3 = func_0x(0x112fe00);
              if (cVar3 != '\0') {
                *(undefined8 *)(puVar33 + lVar15 + -8) = 0x1059fc;
                cVar3 = func_0x();
                if (cVar3 != '\0') {
                  *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105a0c;
                  cVar3 = func_0x(0x112fe00);
                  if (cVar3 == '\0') {
                    *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105a28;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    uVar17 = *(undefined8 *)(puVar46 + 3);
                    *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105a36;
                    func_0x(uVar17,5);
                    goto LAB_;
                  }
                  *(undefined8 *)(puVar33 + lVar15 + 0x20) = 0;
                  *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105a5c;
                  (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x88b);
                }
              }
              uVar17 = *(undefined8 *)(puVar46 + 3);
              *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105a6a;
              func_0x(uVar17,5);
            }
          }
LAB_:
          uVar35 = (uint)puVar46[0xd];
          if (uVar27 <= puVar46[0xd]) {
            uVar35 = uVar27;
          }
          if (uVar35 != 0) {
            *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105a8f;
            lVar38 = func_0x(puVar46);
            uVar27 = *(uint *)(puVar46 + 0xb);
            *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105aa2;
            func_0x(&stack0x00000300 + lVar12);
            uVar44 = 0;
            do {
              *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105abf;
              uVar7 = func_0x(lVar38 + 2,uVar44);
              uVar36 = (uint)uVar7;
              if ((uVar7 < uVar27) ||
                 (*(uint *)(puVar46 + 1) <= (uint)uVar7 && uVar36 != *(uint *)(puVar46 + 1))) {
                uVar17 = *(undefined8 *)(puVar46 + 3);
                *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105adc;
                func_0x(uVar17,7);
              }
              *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105ae8;
              iVar45 = func_0x(lVar38 + 2,uVar44);
              lVar16 = *(longlong *)(puVar46 + 3);
              lVar18 = *(longlong *)(&stack0x00000028 + lVar12);
              *(undefined4 *)(puVar33 + lVar15 + 0x28) = 0;
              *(undefined **)(puVar33 + lVar15 + 0x20) = &stack0x00000300 + lVar12;
              *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105b20;
              func_0x
                        (uVar44 * 0x20 + lVar18,(ulonglong)uVar27 + lVar16,uVar36 - uVar27,
                         iVar45 != 0);
              uVar41 = (int)uVar44 + 1;
              uVar44 = (ulonglong)uVar41;
              uVar27 = uVar36;
            } while (uVar41 < uVar35);
            puVar47 = *(ushort **)(&stack0x00000070 + lVar12);
            uVar27 = *puVar1;
          }
          lVar38 = *(longlong *)(&stack0x00000028 + lVar12);
          *(undefined8 *)(puVar33 + lVar15 + -8) = 0x105b51;
          func_0x((ulonglong)uVar35 * 0x20 + lVar38,0,(uVar27 - uVar35) * 0x20);
          puVar33 = puVar33 + lVar15;
        }
        lVar15 = *(longlong *)(&stack0x000001b8 + lVar12);
        if (lVar15 != 0) {
          *(uint *)(puVar33 + 0x28) = uVar27;
          *(longlong *)(puVar33 + 0x20) = lVar38;
          uVar42 = *(undefined4 *)(&stack0x000000a8 + lVar12);
          *(undefined8 *)(puVar33 + -8) = 0x105b7d;
          func_0x(lVar15,uVar42,puVar46,puVar47);
        }
        *(undefined8 *)(puVar33 + -8) = 0x105b89;
        uVar17 = func_0x(&stack0x000000b8 + lVar12);
        *(undefined8 *)(puVar33 + -8) = 0x105b91;
        uVar7 = func_0x(uVar17);
        *(uint *)((longlong)&puStackX_20 + lVar12) = (uint)uVar7;
        *(undefined8 *)(&stack0x000001a0 + lVar12) = 0;
        *(undefined4 *)(&stack0x00000098 + lVar12) = 0;
        *(undefined8 *)(puVar33 + -8) = 0x105bb2;
        lVar15 = func_0x(&stack0x000000b8 + lVar12);
        *(longlong *)(&stack0x00000070 + lVar12) = lVar15;
        if (uVar7 != 0) {
          do {
            uVar27 = 0;
            *(undefined8 *)(puVar33 + -8) = 0x105bcd;
            uVar17 = func_0x(lVar15);
            *(undefined8 *)(&stack0x00000078 + lVar12) = uVar17;
            *(undefined8 *)(puVar33 + -8) = 0x105bdc;
            iVar45 = func_0x(lVar15);
            *(undefined8 *)(puVar33 + -8) = 0x105bf1;
            func_0x(&stack0x000000b8 + lVar12,lVar15,&stack0x00000090 + lVar12);
            if ((&stack0x00000090)[lVar12] == '\x03') {
              *(undefined8 *)(puVar33 + -8) = 0x10795a;
              iVar34 = func_0x(lVar15);
              if (iVar34 == 0) {
                *(undefined8 *)(puVar33 + -8) = 0x107966;
                iVar34 = func_0x(lVar15);
                if (iVar34 == 0) {
                  *(undefined8 *)(puVar33 + -8) = 0x10797e;
                  (*_DAT_)(6,0x51,0x10,3);
                }
              }
              *(undefined8 *)(puVar33 + -8) = 0x10798f;
              func_0x(puVar47,uVar17,0,0);
              if (iVar45 < 0) {
                puVar31 = (uint *)((longlong)(-1 - iVar45) * 0x20 + 0xc + lVar38);
                *puVar31 = *puVar31 | 2;
              }
            }
            else {
              *(undefined8 *)(puVar33 + -8) = 0x105c03;
              sVar6 = func_0x(uVar17);
              if (sVar6 != 0) {
                *(undefined8 *)(puVar33 + -8) = 0x105c13;
                func_0x(puVar47,uVar17);
              }
              *(undefined8 *)(puVar33 + -8) = 0x105c29;
              func_0x(&stack0x000000b8 + lVar12,lVar15,&stack0x000001a0 + lVar12);
              *(undefined8 *)(puVar33 + -8) = 0x105c31;
              iVar34 = func_0x(lVar15);
              uVar35 = 0;
              if ((iVar34 == 1) || (iVar34 == 2)) {
                lVar38 = *(longlong *)(&stack0x000001a0 + lVar12);
                *(undefined8 *)(puVar33 + -8) = 0x10781e;
                iVar45 = func_0x(lVar15);
                if (iVar45 == 0) {
                  *(undefined8 *)(puVar33 + -8) = 0x10782a;
                  uVar10 = func_0x();
                  *(undefined8 *)(puVar33 + -8) = 0x107835;
                  uVar17 = func_0x(lVar15);
                  *(undefined8 *)(puVar33 + -8) = 0x10783d;
                  iVar45 = func_0x(uVar17);
                  lVar16 = *(longlong *)(puVar47 + 3);
                  *(undefined8 *)(puVar33 + -8) = 0x10784f;
                  func_0x(iVar45 + lVar16,lVar38,uVar10);
                }
                else {
                  *(undefined8 *)(puVar33 + -8) = 0x10785b;
                  iVar45 = func_0x(lVar15);
                  if ((iVar45 == 0) || (((&stack0x000000cc)[lVar12] & 8) == 0)) {
                    *(undefined8 *)(puVar33 + -8) = 0x107886;
                    iVar45 = func_0x(lVar15);
                    if (iVar45 == 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x1078b8;
                      uVar7 = func_0x(lVar15);
                      uVar44 = (ulonglong)uVar7;
                    }
                    else {
                      *(undefined8 *)(puVar33 + -8) = 0x107892;
                      uVar17 = func_0x();
                      *(undefined8 *)(puVar33 + -8) = 0x1078a4;
                      uVar22 = func_0x(&stack0x000000b8 + lVar12,lVar15);
                      *(undefined8 *)(puVar33 + -8) = 0x1078af;
                      uVar35 = func_0x(uVar22,uVar17);
                      uVar44 = (ulonglong)uVar35;
                    }
                  }
                  else {
                    *(undefined8 *)(puVar33 + -8) = 0x107870;
                    uVar35 = func_0x(lVar15);
                    uVar44 = (ulonglong)
                             *(uint *)(*(longlong *)(&stack0x000000f0 + lVar12) +
                                      (ulonglong)uVar35 * 8);
                  }
                  *(undefined8 *)(puVar33 + -8) = 0x1078c3;
                  uVar7 = func_0x(lVar15);
                  uVar35 = (uint)uVar44;
                  if (uVar35 < uVar7) {
                    *(undefined8 *)(puVar33 + -8) = 0x1078d2;
                    uVar7 = func_0x(lVar15);
                    uVar27 = uVar7 - uVar35;
                  }
                  else {
                    *(undefined8 *)(puVar33 + -8) = 0x1078de;
                    uVar7 = func_0x(lVar15);
                    if (uVar7 < uVar35) {
                      *(undefined8 *)(puVar33 + -8) = 0x1078fb;
                      (*_DAT_)(6,0x5c,0x16);
                      uVar27 = 0;
                    }
                  }
                  *(undefined8 *)(puVar33 + -8) = 0x107903;
                  uVar5 = func_0x(lVar15);
                  *(undefined8 *)(puVar33 + -8) = 0x10790f;
                  uVar17 = func_0x(lVar15);
                  *(undefined8 *)(puVar33 + -8) = 0x107917;
                  iVar45 = func_0x(uVar17);
                  lVar16 = *(longlong *)(puVar47 + 3);
                  if ((lVar38 != 0) && (uVar35 != 0)) {
                    *(undefined8 *)(puVar33 + -8) = 0x107935;
                    func_0x(iVar45 + lVar16,lVar38,uVar44);
                  }
                  if (uVar27 != 0) {
                    *(undefined8 *)(puVar33 + -8) = 0x10794d;
                    func_0x(uVar44 + iVar45 + lVar16,uVar5,uVar27);
                  }
                }
              }
              else if ((iVar34 == 3) || (iVar34 == 4)) {
                *(undefined8 *)(puVar33 + -8) = 0x10773f;
                iVar34 = func_0x(lVar15);
                if ((iVar34 == 0) || (**(int **)(&stack0x000001a0 + lVar12) != 0)) {
                  *(undefined8 *)(puVar33 + -8) = 0x107757;
                  iVar34 = func_0x(lVar15);
                  if ((iVar34 == 0) || (((&stack0x000000cc)[lVar12] & 8) == 0)) {
                    *(undefined8 *)(puVar33 + -8) = 0x107782;
                    iVar34 = func_0x(lVar15);
                    if (iVar34 == 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x1077b4;
                      uVar7 = func_0x(lVar15);
                      uVar27 = (uint)uVar7;
                    }
                    else {
                      *(undefined8 *)(puVar33 + -8) = 0x10778e;
                      uVar22 = func_0x();
                      *(undefined8 *)(puVar33 + -8) = 0x1077a0;
                      uVar23 = func_0x(&stack0x000000b8 + lVar12,lVar15);
                      *(undefined8 *)(puVar33 + -8) = 0x1077ab;
                      uVar27 = func_0x(uVar23,uVar22);
                    }
                  }
                  else {
                    *(undefined8 *)(puVar33 + -8) = 0x10776c;
                    uVar27 = func_0x(lVar15);
                    uVar27 = *(uint *)(*(longlong *)(&stack0x000000f0 + lVar12) +
                                      (ulonglong)uVar27 * 8);
                  }
                }
                *(undefined8 *)(puVar33 + -8) = 0x1077bf;
                uVar7 = func_0x(lVar15);
                if (uVar7 < uVar27) {
                  *(undefined8 *)(puVar33 + -8) = 0x1077dc;
                  (*_DAT_)(6,0x52,0x16);
                }
                *(undefined4 *)(puVar33 + 0x28) = 0;
                *(undefined8 *)(puVar33 + 0x20) = uVar17;
                uVar17 = *(undefined8 *)(&stack0x000001a0 + lVar12);
                *(undefined8 *)(puVar33 + -8) = 0x10780a;
                func_0x((longlong)(-1 - iVar45) * 0x20 + lVar38,uVar17,uVar27);
              }
              else if (iVar34 == 8) {
                pcVar40 = *(char **)(&stack0x000001a0 + lVar12);
                *(char **)(&stack0x000000a0 + lVar12) = pcVar40;
                *(undefined8 *)(puVar33 + -8) = 0x105ca2;
                iVar45 = func_0x(uVar17);
                if (iVar45 < 0) {
                  *(undefined8 *)(puVar33 + -8) = 0x106423;
                  iVar45 = func_0x(uVar17);
                  uVar27 = 0;
                  if (iVar45 == 0) {
                    if (*(int *)(puVar47 + 1) == 0) {
                      *puVar47 = 0;
                      *(undefined4 *)(puVar47 + 9) = *(undefined4 *)(puVar47 + 7);
                      *(undefined8 *)(puVar33 + -8) = 0x106448;
                      pbVar20 = (byte *)func_0x(puVar47);
                      if ((*pbVar20 & 0x10) != 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x106455;
                        pbVar20 = (byte *)func_0x(puVar47);
                        if ((*pbVar20 & 0x10) != 0) {
                          uVar27 = (uint)*(ushort *)
                                          ((ulonglong)*(uint *)(puVar47 + 7) +
                                          *(longlong *)(puVar47 + 3));
                        }
                        *(uint *)(puVar47 + 9) = *(int *)(puVar47 + 9) + (uVar27 + 7 >> 3) + 2;
                      }
                      *(undefined8 *)(puVar33 + -8) = 0x10647d;
                      pbVar20 = (byte *)func_0x(puVar47);
                      if ((*pbVar20 & 0x20) == 0) {
                        *(undefined4 *)(puVar47 + 1) = *(undefined4 *)(puVar47 + 9);
                        puVar47[0xd] = 0;
                        *(undefined4 *)(puVar47 + 0xb) = *(undefined4 *)(puVar47 + 9);
                      }
                      else {
                        *(undefined8 *)(puVar33 + -8) = 0x10648e;
                        puVar46 = (ushort *)func_0x(puVar47);
                        uVar7 = *puVar46;
                        puVar47[0xd] = uVar7;
                        if (uVar7 == 0) {
                          *(undefined8 *)(puVar33 + -8) = 0x1064a9;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x1064b2;
                            cVar3 = func_0x();
                            if (cVar3 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x1064c2;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x1064de;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x106508;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                              }
                            }
                          }
                          uVar22 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x106516;
                          func_0x(uVar22,3);
                          uVar7 = puVar47[0xd];
                        }
                        uVar27 = *(int *)(puVar47 + 9) + (uVar7 + 1) * 2;
                        *(uint *)(puVar47 + 0xb) = uVar27;
                        if (0x1f9e < uVar27) {
                          *(undefined8 *)(puVar33 + -8) = 0x10653d;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x106546;
                            cVar3 = func_0x();
                            if (cVar3 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x106556;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x106572;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x10659c;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                              }
                            }
                          }
                          uVar22 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x1065aa;
                          func_0x(uVar22,4);
                          uVar7 = puVar47[0xd];
                        }
                        puVar46 = puVar46 + 1;
                        *(undefined8 *)(puVar33 + -8) = 0x1065c0;
                        uVar7 = func_0x(puVar46,(ulonglong)uVar7 - 1);
                        *(uint *)(puVar47 + 1) = (uint)uVar7;
                        uVar27 = *(uint *)(puVar47 + 0xb);
                        if (uVar7 < uVar27) {
                          *(undefined8 *)(puVar33 + -8) = 0x1065d9;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x1065e2;
                            cVar3 = func_0x();
                            if (cVar3 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x1065f2;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x10660e;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x106638;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                              }
                            }
                          }
                          uVar22 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x106646;
                          func_0x(uVar22,4);
                          uVar27 = *(uint *)(puVar47 + 0xb);
                        }
                        iVar34 = 0;
                        uVar7 = puVar47[0xd];
                        iVar45 = iVar34;
                        if (uVar7 != 0) {
                          do {
                            *(undefined8 *)(puVar33 + -8) = 0x10666c;
                            uVar7 = func_0x(puVar46,(longlong)iVar45);
                            bVar48 = uVar7 < uVar27;
                            uVar27 = (uint)uVar7;
                            if ((bVar48) ||
                               (*(uint *)(puVar47 + 1) <= (uint)uVar7 &&
                                uVar27 != *(uint *)(puVar47 + 1))) {
                              *(undefined8 *)(puVar33 + -8) = 0x106684;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 != '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x10668d;
                                cVar3 = func_0x();
                                if (cVar3 != '\0') {
                                  *(undefined8 *)(puVar33 + -8) = 0x10669d;
                                  cVar3 = func_0x(0x112fe00);
                                  if (cVar3 == '\0') {
                                    *(undefined8 *)(puVar33 + -8) = 0x1066b9;
                                    (*_DAT_)(0x22,0x44,0x15);
                                  }
                                  else {
                                    *(undefined8 *)(puVar33 + 0x20) = 0;
                                    *(undefined8 *)(puVar33 + -8) = 0x1066dd;
                                    (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                                  }
                                }
                              }
                              uVar17 = *(undefined8 *)(puVar47 + 3);
                              *(undefined8 *)(puVar33 + -8) = 0x1066eb;
                              func_0x(uVar17,4);
                            }
                            iVar45 = iVar45 + 1;
                            uVar7 = puVar47[0xd];
                          } while (iVar45 < (int)(uint)uVar7);
                          uVar17 = *(undefined8 *)(&stack0x00000078 + lVar12);
                        }
                        *(undefined8 *)(puVar33 + -8) = 0x10670e;
                        iVar45 = func_0x(puVar46,uVar7 - 1);
                        while (iVar45 != 0) {
                          uVar7 = puVar47[0xd];
                          *(undefined8 *)(puVar33 + -8) = 0x10672c;
                          lVar38 = func_0x(puVar47);
                          if (uVar7 == 1) {
                            uVar44 = (ulonglong)*(uint *)(puVar47 + 0xb);
                          }
                          else {
                            *(undefined8 *)(puVar33 + -8) = 0x106749;
                            uVar8 = func_0x(lVar38 + 2,(ulonglong)uVar7 - 2);
                            uVar44 = (ulonglong)uVar8;
                          }
                          *(undefined8 *)(puVar33 + -8) = 0x106759;
                          uVar7 = func_0x(lVar38 + 2,(ulonglong)(uint)uVar7 - 1);
                          uVar27 = *(uint *)(puVar47 + 0xb);
                          uVar35 = (uint)uVar44;
                          if (((uVar35 < uVar27) || (uVar7 < uVar35)) ||
                             (*(uint *)(puVar47 + 1) <= (uint)uVar7 &&
                              (uint)uVar7 != *(uint *)(puVar47 + 1))) {
                            uVar22 = *(undefined8 *)(puVar47 + 3);
                            *(undefined8 *)(puVar33 + -8) = 0x10677a;
                            func_0x(uVar22,7);
                            uVar27 = *(uint *)(puVar47 + 0xb);
                          }
                          if ((uVar35 < uVar27) || (*(uint *)(puVar47 + 1) < uVar35))
                          goto LAB_;
                          uVar8 = *(ushort *)(*(longlong *)(puVar47 + 3) + uVar44);
                          if (uVar8 == 5) {
                            *puVar47 = *puVar47 | 2;
                            puVar47[0xd] = puVar47[0xd] - 1;
                            puVar47[0x14] = (ushort)uVar44;
                            lVar38 = (uVar44 & 0xffff) + *(longlong *)(puVar47 + 3);
                            *(undefined8 *)(puVar33 + -8) = 0x106839;
                            iVar45 = func_0x(lVar38);
                            if (iVar45 == 0) {
                              puVar47[0x15] = puVar47[0x15] & 0xc7ff;
                            }
                            else {
                              *(undefined8 *)(puVar33 + -8) = 0x106845;
                              uVar8 = func_0x(lVar38);
                              puVar47[0x15] = puVar47[0x15] & 0xc7ff;
                              puVar47[0x15] = puVar47[0x15] | (uVar8 & 7) << 0xb;
                            }
                            *(undefined8 *)(puVar33 + -8) = 0x10686d;
                            uVar8 = func_0x(lVar38);
                            puVar47[0x15] = puVar47[0x15] ^ (uVar8 ^ puVar47[0x15]) & 0x7ff;
                            uVar9 = puVar47[0x15];
                            uVar39 = *(ulonglong *)(puVar47 + 3);
                            uVar8 = puVar47[0x14];
                            uVar30 = (ulonglong)((uVar9 & 0x7ff) * 2) + 4 +
                                     (ulonglong)uVar8 + (ulonglong)((uVar9 >> 0xb & 7) * 2) + uVar39
                            ;
                            uVar44 = uVar39 + uVar8;
                            if (uVar30 < uVar44) {
                              *(undefined8 *)(puVar33 + -8) = 0x1068c3;
                              func_0x(uVar44,0x19);
                              uVar9 = puVar47[0x15];
                              uVar8 = puVar47[0x14];
                              uVar39 = (ulonglong)*(uint *)(puVar47 + 3);
                            }
                            if (uVar7 - uVar35 <
                                (((uVar9 & 0x7ff) * 2 - (uint)uVar8) - (int)uVar39) + (int)uVar30) {
                              uVar7 = puVar47[0x14];
                              lVar38 = *(longlong *)(puVar47 + 3);
                              *(undefined8 *)(puVar33 + -8) = 0x1068fe;
                              func_0x((ulonglong)uVar7 + lVar38,0x19);
                              uVar9 = puVar47[0x15];
                            }
                            if (((uVar9 & 0x3800) != 0) &&
                               (uVar7 = puVar47[0x14], lVar38 = *(longlong *)(puVar47 + 3),
                               (uVar9 & 0x3800) != 0)) {
                              do {
                                uVar8 = puVar47[0x15];
                                *(undefined8 *)(puVar33 + -8) = 0x10693f;
                                uVar9 = func_0x
                                                  ((ulonglong)uVar7 + lVar38 + 4,iVar34);
                                if ((uVar8 & 0x7ff) < uVar9) {
                                  uVar8 = puVar47[0x14];
                                  lVar15 = *(longlong *)(puVar47 + 3);
                                  *(undefined8 *)(puVar33 + -8) = 0x10695d;
                                  func_0x((ulonglong)uVar8 + lVar15,0x1a);
                                  uVar8 = puVar47[0x15];
                                }
                                iVar34 = iVar34 + 1;
                              } while (iVar34 < (int)(uVar8 >> 0xb & 7));
                            }
                            break;
                          }
                          if (uVar8 < 0x400) break;
                          *puVar47 = *puVar47 | 1;
                          uVar7 = puVar47[0xd] - 1;
                          puVar47[0xd] = uVar7;
                          if (uVar7 == 0) break;
                          *(undefined8 *)(puVar33 + -8) = 0x1067c9;
                          iVar45 = func_0x(puVar46,uVar7 - 1);
                        }
                      }
                      *(undefined8 *)(puVar33 + -8) = 0x1067db;
                      iVar45 = func_0x(puVar47);
                      if (iVar45 == 0) {
                        *(undefined4 *)(puVar47 + 0x12) = 0;
                      }
                      else {
                        *(int *)(puVar47 + 0x12) = *(int *)(puVar47 + 1);
                        *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + 0xe;
                        *(undefined8 *)(puVar33 + -8) = 0x1067f7;
                        uVar22 = func_0x(puVar47);
                        *(undefined8 *)(puVar33 + -8) = 0x106806;
                        func_0x(uVar22,&stack0x00000270 + lVar12);
                        *(undefined8 *)(puVar33 + -8) = 0x106812;
                        iVar45 = func_0x(&stack0x00000270 + lVar12);
                        *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + iVar45;
                      }
                      uVar27 = *(uint *)(puVar47 + 1);
                      if ((*(ulonglong *)(puVar47 + 0xe) != 0) &&
                         (*(ulonglong *)(puVar47 + 0xe) <
                          (ulonglong)uVar27 + *(longlong *)(puVar47 + 3))) {
                        *(undefined8 *)(puVar33 + -8) = 0x1069b1;
                        cVar3 = func_0x(0x112fe00);
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x1069ba;
                          cVar3 = func_0x();
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x1069ca;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x1069e6;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x106a0c;
                              (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                            }
                          }
                        }
                        uVar22 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x106a1a;
                        func_0x(uVar22,0x12);
                        uVar27 = *(uint *)(puVar47 + 1);
                      }
                      if (0x3f3b < uVar27 - 1) {
                        *(undefined8 *)(puVar33 + -8) = 0x106a33;
                        cVar3 = func_0x(0x112fe00);
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x106a3c;
                          cVar3 = func_0x();
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x106a4c;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x106a68;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x106a8e;
                              (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                            }
                          }
                        }
                        uVar22 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x106a9c;
                        func_0x(uVar22,5);
                      }
                    }
LAB_:
                    *(undefined8 *)(puVar33 + -8) = 0x106aa4;
                    iVar45 = func_0x(uVar17);
                    uVar27 = -iVar45;
                    *(undefined8 *)(puVar33 + -8) = 0x106ab6;
                    func_0x(&stack0x00000768 + lVar12);
                    *(undefined8 *)(puVar33 + -8) = 0x106abe;
                    iVar45 = func_0x(puVar47);
                    *(int *)(&stack0x00000088 + lVar12) = iVar45;
                    if (iVar45 != 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x106ad4;
                      func_0x(puVar47,&stack0x00000768 + lVar12);
                    }
                    *(undefined8 *)(puVar33 + -8) = 0x106adc;
                    pbVar20 = (byte *)func_0x(puVar47);
                    if ((*pbVar20 & 0x20) == 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x106ae9;
                      func_0x(puVar47);
                    }
                    uVar7 = puVar47[0xd];
                    uVar35 = (uint)uVar7;
                    if (uVar7 < uVar27) {
                      iVar45 = uVar27 - uVar7;
                      *(int *)(&stack0x00000078 + lVar12) = iVar45;
                      lVar38 = *(longlong *)(puVar47 + 3);
                      puVar46 = (ushort *)(lVar38 + (ulonglong)*(uint *)(puVar47 + 9));
                      uVar36 = *(uint *)(puVar47 + 9) + 2 + uVar35 * 2;
                      *(uint *)(&stack0x00000124 + lVar12) = uVar36;
                      uVar41 = iVar45 * 2;
                      uVar26 = 0;
                      if (*puVar46 != 0) {
                        do {
                          *(undefined8 *)(puVar33 + -8) = 0x106b2f;
                          uVar7 = func_0x(puVar46 + 1,uVar26);
                          *(undefined8 *)(puVar33 + -8) = 0x106b42;
                          func_0x(puVar46 + 1,uVar26 & 0xffff,uVar7 + uVar41);
                          uVar26 = uVar26 + 1;
                        } while (uVar26 < *puVar46);
                        lVar38 = *(longlong *)(puVar47 + 3);
                        uVar36 = *(uint *)(&stack0x00000124 + lVar12);
                      }
                      iVar45 = *(int *)(puVar47 + 1);
                      *(undefined8 *)(puVar33 + -8) = 0x106b73;
                      func_0x
                                ((ulonglong)uVar41 + lVar38 + (ulonglong)uVar36,
                                 lVar38 + (ulonglong)uVar36,iVar45 - uVar36);
                      *(uint *)(puVar47 + 1) = *(int *)(puVar47 + 1) + uVar41;
                      *(uint *)(puVar47 + 0xb) = *(int *)(puVar47 + 0xb) + uVar41;
                      uVar36 = *(uint *)(puVar47 + 0xb);
                      if (uVar35 != 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x106b8e;
                        uVar7 = func_0x(puVar46 + 1,uVar35 - 1);
                        uVar36 = (uint)uVar7;
                      }
                      do {
                        *(undefined8 *)(puVar33 + -8) = 0x106bb2;
                        func_0x(puVar46 + 1,uVar35 & 0xffff,uVar36 & 0xffff);
                        uVar35 = uVar35 + 1;
                      } while (uVar35 < uVar27);
                      *puVar46 = *puVar46 + (short)*(undefined4 *)(&stack0x00000078 + lVar12);
                      *(undefined8 *)(puVar33 + -8) = 0x106bc9;
                      iVar45 = func_0x(puVar47);
                      if (iVar45 != 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x106bd5;
                        func_0x(puVar47);
                      }
                      puVar47[0xd] = (ushort)uVar27;
                      uVar35 = uVar27 & 0xffff;
                    }
                    if (uVar35 < uVar27) {
                      *(undefined8 *)(puVar33 + -8) = 0x106c57;
                      lVar38 = func_0x(puVar47);
                      uVar7 = puVar47[0xd];
                      *(undefined8 *)(puVar33 + -8) = 0x106c67;
                      uVar7 = func_0x(lVar38 + 2,(ulonglong)uVar7 - 1);
                      uVar35 = (uint)uVar7;
                      iVar45 = 0;
LAB_:
                      uVar27 = uVar27 - 1;
                      *(undefined8 *)(puVar33 + -8) = 0x106c79;
                      puVar46 = (ushort *)func_0x(puVar47);
                      lVar38 = *(longlong *)(puVar47 + 3);
                      uVar42 = *(undefined4 *)(puVar47 + 1);
                      *(undefined8 *)(puVar33 + -8) = 0x106c8f;
                      uVar42 = func_0x(uVar42,iVar45 + uVar35);
                      *(undefined8 *)(puVar33 + -8) = 0x106ca7;
                      func_0x
                                ((ulonglong)uVar35 + 1 + lVar38,iVar45 + lVar38 + (ulonglong)uVar35,
                                 uVar42);
                      if ((int)uVar27 < (int)(uint)*puVar46) {
                        do {
                          *(undefined8 *)(puVar33 + -8) = 0x106ccc;
                          uVar7 = func_0x(puVar46 + 1,(longlong)(int)uVar27);
                          *(undefined8 *)(puVar33 + -8) = 0x106ce0;
                          func_0x
                                    (puVar46 + 1,uVar27 & 0xffff,(uint)uVar7 + (1 - iVar45));
                          uVar27 = uVar27 + 1;
                        } while ((int)uVar27 < (int)(uint)*puVar46);
                      }
                      *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + (1 - iVar45);
                      *(undefined8 *)(puVar33 + -8) = 0x106d00;
                      iVar45 = func_0x(puVar47);
                      if (iVar45 != 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x106d0c;
                        func_0x(puVar47);
                      }
                    }
                    else {
                      *(undefined8 *)(puVar33 + -8) = 0x106bee;
                      lVar38 = func_0x(puVar47);
                      if (uVar27 == 1) {
                        uVar35 = *(uint *)(puVar47 + 0xb);
                      }
                      else {
                        *(undefined8 *)(puVar33 + -8) = 0x106c0d;
                        uVar7 = func_0x(lVar38 + 2,(longlong)(int)(uVar27 - 2));
                        uVar35 = (uint)uVar7;
                      }
                      *(undefined8 *)(puVar33 + -8) = 0x106c20;
                      uVar7 = func_0x(lVar38 + 2,(longlong)(int)(uVar27 - 1));
                      if (((uVar35 < *(uint *)(puVar47 + 0xb)) || (uVar7 < uVar35)) ||
                         (*(uint *)(puVar47 + 1) <= (uint)uVar7 &&
                          (uint)uVar7 != *(uint *)(puVar47 + 1))) {
                        uVar17 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x106c43;
                        func_0x(uVar17,7);
                      }
                      iVar45 = uVar7 - uVar35;
                      if (iVar45 != 1) goto LAB_;
                    }
                    *(undefined *)(*(longlong *)(puVar47 + 3) + (ulonglong)uVar35) =
                         **(undefined **)(&stack0x000000a0 + lVar12);
                    if (*(int *)(&stack0x00000088 + lVar12) != 0) {
                      puVar19 = &stack0x00000768;
                      goto LAB_;
                    }
                  }
                  else {
                    *(undefined8 *)(puVar33 + -8) = 0x106dab;
                    func_0x(&stack0x00000848 + lVar12);
                    *(undefined4 *)(&stack0x00000120 + lVar12) = 0;
                    *(undefined8 *)(puVar33 + -8) = 0x106dbd;
                    func_0x(&stack0x00000200 + lVar12);
                    if (*(int *)(puVar47 + 1) == 0) {
                      *puVar47 = 0;
                      *(undefined4 *)(puVar47 + 9) = *(undefined4 *)(puVar47 + 7);
                      *(undefined8 *)(puVar33 + -8) = 0x106dd8;
                      pbVar20 = (byte *)func_0x(puVar47);
                      if ((*pbVar20 & 0x10) != 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x106de5;
                        pbVar20 = (byte *)func_0x(puVar47);
                        if ((*pbVar20 & 0x10) != 0) {
                          uVar27 = (uint)*(ushort *)
                                          ((ulonglong)*(uint *)(puVar47 + 7) +
                                          *(longlong *)(puVar47 + 3));
                        }
                        *(uint *)(puVar47 + 9) = *(int *)(puVar47 + 9) + (uVar27 + 7 >> 3) + 2;
                      }
                      *(undefined8 *)(puVar33 + -8) = 0x106e0d;
                      pbVar20 = (byte *)func_0x(puVar47);
                      if ((*pbVar20 & 0x20) == 0) {
                        *(undefined4 *)(puVar47 + 1) = *(undefined4 *)(puVar47 + 9);
                        puVar47[0xd] = 0;
                        *(undefined4 *)(puVar47 + 0xb) = *(undefined4 *)(puVar47 + 9);
                      }
                      else {
                        *(undefined8 *)(puVar33 + -8) = 0x106e1e;
                        puVar46 = (ushort *)func_0x(puVar47);
                        uVar7 = *puVar46;
                        puVar47[0xd] = uVar7;
                        if (uVar7 == 0) {
                          *(undefined8 *)(puVar33 + -8) = 0x106e39;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x106e42;
                            cVar3 = func_0x();
                            if (cVar3 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x106e52;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x106e6e;
                                (*_DAT_)(0x22,0x44,0x15,0x3eb);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x106e98;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x80f);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x106ea6;
                          func_0x(uVar17,3);
                          uVar7 = puVar47[0xd];
                        }
                        uVar27 = *(int *)(puVar47 + 9) + (uVar7 + 1) * 2;
                        *(uint *)(puVar47 + 0xb) = uVar27;
                        if (0x1f9e < uVar27) {
                          *(undefined8 *)(puVar33 + -8) = 0x106ecd;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x106ed6;
                            cVar3 = func_0x();
                            if (cVar3 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x106ee6;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x106f02;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x106f2c;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x816);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x106f3a;
                          func_0x(uVar17,4);
                          uVar7 = puVar47[0xd];
                        }
                        puVar46 = puVar46 + 1;
                        *(undefined8 *)(puVar33 + -8) = 0x106f50;
                        uVar7 = func_0x(puVar46,(ulonglong)uVar7 - 1);
                        *(uint *)(puVar47 + 1) = (uint)uVar7;
                        uVar27 = *(uint *)(puVar47 + 0xb);
                        if (uVar7 < uVar27) {
                          *(undefined8 *)(puVar33 + -8) = 0x106f69;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x106f72;
                            cVar3 = func_0x();
                            if (cVar3 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x106f82;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x106f9e;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x106fc8;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x81d);
                              }
                            }
                          }
                          uVar17 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x106fd6;
                          func_0x(uVar17,4);
                          uVar27 = *(uint *)(puVar47 + 0xb);
                        }
                        iVar34 = 0;
                        uVar7 = puVar47[0xd];
                        iVar45 = iVar34;
                        if (uVar7 != 0) {
                          do {
                            *(undefined8 *)(puVar33 + -8) = 0x106ffb;
                            uVar7 = func_0x(puVar46,(longlong)iVar45);
                            bVar48 = uVar7 < uVar27;
                            uVar27 = (uint)uVar7;
                            if ((bVar48) ||
                               (*(uint *)(puVar47 + 1) <= (uint)uVar7 &&
                                uVar27 != *(uint *)(puVar47 + 1))) {
                              *(undefined8 *)(puVar33 + -8) = 0x107013;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 != '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x10701c;
                                cVar3 = func_0x();
                                if (cVar3 != '\0') {
                                  *(undefined8 *)(puVar33 + -8) = 0x10702c;
                                  cVar3 = func_0x(0x112fe00);
                                  if (cVar3 == '\0') {
                                    *(undefined8 *)(puVar33 + -8) = 0x107048;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(puVar33 + 0x20) = 0;
                                    *(undefined8 *)(puVar33 + -8) = 0x10706e;
                                    (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x82a);
                                  }
                                }
                              }
                              uVar17 = *(undefined8 *)(puVar47 + 3);
                              *(undefined8 *)(puVar33 + -8) = 0x10707c;
                              func_0x(uVar17,4);
                            }
                            iVar45 = iVar45 + 1;
                            uVar7 = puVar47[0xd];
                          } while (iVar45 < (int)(uint)uVar7);
                        }
                        *(undefined8 *)(puVar33 + -8) = 0x10709b;
                        iVar45 = func_0x(puVar46,uVar7 - 1);
                        while (iVar45 != 0) {
                          uVar7 = puVar47[0xd];
                          *(undefined8 *)(puVar33 + -8) = 0x1070af;
                          lVar38 = func_0x(puVar47);
                          if (uVar7 == 1) {
                            uVar44 = (ulonglong)*(uint *)(puVar47 + 0xb);
                          }
                          else {
                            *(undefined8 *)(puVar33 + -8) = 0x1070cc;
                            uVar8 = func_0x(lVar38 + 2,(ulonglong)uVar7 - 2);
                            uVar44 = (ulonglong)uVar8;
                          }
                          *(undefined8 *)(puVar33 + -8) = 0x1070dc;
                          uVar7 = func_0x(lVar38 + 2,(ulonglong)(uint)uVar7 - 1);
                          uVar27 = *(uint *)(puVar47 + 0xb);
                          uVar35 = (uint)uVar44;
                          if (((uVar35 < uVar27) || (uVar7 < uVar35)) ||
                             (uVar36 = *(uint *)(puVar47 + 1), uVar36 <= uVar7 && uVar7 != uVar36))
                          {
                            uVar17 = *(undefined8 *)(puVar47 + 3);
                            *(undefined8 *)(puVar33 + -8) = 0x1070ff;
                            func_0x(uVar17,7);
                            uVar27 = *(uint *)(puVar47 + 0xb);
                            uVar36 = *(uint *)(puVar47 + 1);
                          }
                          if ((uVar35 < uVar27) || (uVar36 < uVar35)) goto LAB_;
                          uVar8 = *(ushort *)(*(longlong *)(puVar47 + 3) + uVar44);
                          if (uVar8 == 5) {
                            *puVar47 = *puVar47 | 2;
                            puVar47[0xd] = puVar47[0xd] - 1;
                            puVar47[0x14] = (ushort)uVar44;
                            lVar38 = (uVar44 & 0xffff) + *(longlong *)(puVar47 + 3);
                            *(undefined8 *)(puVar33 + -8) = 0x1071c0;
                            iVar45 = func_0x(lVar38);
                            if (iVar45 == 0) {
                              puVar47[0x15] = puVar47[0x15] & 0xc7ff;
                            }
                            else {
                              *(undefined8 *)(puVar33 + -8) = 0x1071cc;
                              uVar8 = func_0x(lVar38);
                              puVar47[0x15] = puVar47[0x15] & 0xc7ff;
                              puVar47[0x15] = puVar47[0x15] | (uVar8 & 7) << 0xb;
                            }
                            *(undefined8 *)(puVar33 + -8) = 0x1071f4;
                            uVar8 = func_0x(lVar38);
                            puVar47[0x15] = puVar47[0x15] ^ (uVar8 ^ puVar47[0x15]) & 0x7ff;
                            uVar9 = puVar47[0x15];
                            uVar39 = *(ulonglong *)(puVar47 + 3);
                            uVar8 = puVar47[0x14];
                            uVar30 = (ulonglong)((uVar9 & 0x7ff) * 2) + 4 +
                                     uVar39 + (uVar9 >> 0xb & 7) * 2 + (ulonglong)uVar8;
                            uVar44 = uVar39 + uVar8;
                            if (uVar30 < uVar44) {
                              *(undefined8 *)(puVar33 + -8) = 0x10724a;
                              func_0x(uVar44,0x19);
                              uVar9 = puVar47[0x15];
                              uVar8 = puVar47[0x14];
                              uVar39 = (ulonglong)*(uint *)(puVar47 + 3);
                            }
                            if (uVar7 - uVar35 <
                                (((uVar9 & 0x7ff) * 2 - (uint)uVar8) - (int)uVar39) + (int)uVar30) {
                              uVar7 = puVar47[0x14];
                              lVar38 = *(longlong *)(puVar47 + 3);
                              *(undefined8 *)(puVar33 + -8) = 0x107285;
                              func_0x((ulonglong)uVar7 + lVar38,0x19);
                              uVar9 = puVar47[0x15];
                            }
                            if (((uVar9 & 0x3800) != 0) &&
                               (uVar7 = puVar47[0x14], lVar38 = *(longlong *)(puVar47 + 3),
                               (uVar9 & 0x3800) != 0)) {
                              do {
                                uVar8 = puVar47[0x15];
                                *(undefined8 *)(puVar33 + -8) = 0x1072cf;
                                uVar9 = func_0x
                                                  ((ulonglong)uVar7 + lVar38 + 4,iVar34);
                                if ((uVar8 & 0x7ff) < uVar9) {
                                  uVar8 = puVar47[0x14];
                                  lVar15 = *(longlong *)(puVar47 + 3);
                                  *(undefined8 *)(puVar33 + -8) = 0x1072ed;
                                  func_0x((ulonglong)uVar8 + lVar15,0x1a);
                                  uVar8 = puVar47[0x15];
                                }
                                iVar34 = iVar34 + 1;
                              } while (iVar34 < (int)(uVar8 >> 0xb & 7));
                            }
                            break;
                          }
                          if (uVar8 < 0x400) break;
                          *puVar47 = *puVar47 | 1;
                          uVar7 = puVar47[0xd] - 1;
                          puVar47[0xd] = uVar7;
                          if (uVar7 == 0) break;
                          *(undefined8 *)(puVar33 + -8) = 0x107150;
                          iVar45 = func_0x(puVar46,uVar7 - 1);
                        }
                      }
                      *(undefined8 *)(puVar33 + -8) = 0x107162;
                      iVar45 = func_0x(puVar47);
                      if (iVar45 == 0) {
                        *(undefined4 *)(puVar47 + 0x12) = 0;
                      }
                      else {
                        *(int *)(puVar47 + 0x12) = *(int *)(puVar47 + 1);
                        *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + 0xe;
                        *(undefined8 *)(puVar33 + -8) = 0x10717e;
                        uVar17 = func_0x(puVar47);
                        *(undefined8 *)(puVar33 + -8) = 0x10718d;
                        func_0x(uVar17,&stack0x00000278 + lVar12);
                        *(undefined8 *)(puVar33 + -8) = 0x107199;
                        iVar45 = func_0x(&stack0x00000278 + lVar12);
                        *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + iVar45;
                      }
                      uVar27 = *(uint *)(puVar47 + 1);
                      if ((*(ulonglong *)(puVar47 + 0xe) != 0) &&
                         (*(ulonglong *)(puVar47 + 0xe) <
                          (ulonglong)uVar27 + *(longlong *)(puVar47 + 3))) {
                        *(undefined8 *)(puVar33 + -8) = 0x107341;
                        cVar3 = func_0x(0x112fe00);
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x10734a;
                          cVar3 = func_0x();
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x10735a;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x107376;
                              (*_DAT_)(0x22,0x44,0x15,0x3fa);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x10739c;
                              (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x886);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x1073aa;
                        func_0x(uVar17,0x12);
                        uVar27 = *(uint *)(puVar47 + 1);
                      }
                      if (0x3f3b < uVar27 - 1) {
                        *(undefined8 *)(puVar33 + -8) = 0x1073c3;
                        cVar3 = func_0x(0x112fe00);
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x1073cc;
                          cVar3 = func_0x();
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x1073dc;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x1073f8;
                              (*_DAT_)(0x22,0x44,0x15,0x3ed);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x10741e;
                              (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x88b);
                            }
                          }
                        }
                        uVar17 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x10742c;
                        func_0x(uVar17,5);
                      }
                    }
LAB_:
                    *(undefined8 *)(puVar33 + -8) = 0x107434;
                    func_0x(puVar47);
                    *(undefined8 *)(puVar33 + -8) = 0x10743c;
                    iVar45 = func_0x(puVar47);
                    *(int *)(&stack0x00000088 + lVar12) = iVar45;
                    if (iVar45 != 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x107455;
                      func_0x(puVar47,&stack0x00000848 + lVar12);
                    }
                    if ((*(byte *)puVar47 & 1) != 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x10746e;
                      uVar17 = func_0x(puVar47,0x400,&stack0x00000120 + lVar12);
                      *(undefined8 *)(puVar33 + -8) = 0x10747d;
                      func_0x(&stack0x00000200 + lVar12,uVar17);
                    }
                    *(undefined8 *)(puVar33 + -8) = 0x107485;
                    pbVar20 = (byte *)func_0x(puVar47);
                    if ((*pbVar20 & 0x20) == 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x107492;
                      func_0x(puVar47);
                    }
                    *(undefined8 *)(puVar33 + -8) = 0x10749a;
                    lVar38 = func_0x(puVar47);
                    *(undefined8 *)(puVar33 + -8) = 0x1074a5;
                    iVar34 = func_0x(puVar47);
                    if (iVar34 == 0) {
                      uVar7 = puVar47[0xd];
                      uVar35 = (uint)uVar7;
                      lVar15 = *(longlong *)(puVar47 + 3);
                      puVar46 = (ushort *)(lVar15 + (ulonglong)*(uint *)(puVar47 + 9));
                      uVar27 = *(uint *)(puVar47 + 9) + 2 + uVar35 * 2;
                      uVar36 = 0;
                      if (*puVar46 != 0) {
                        do {
                          *(undefined8 *)(puVar33 + -8) = 0x10756c;
                          uVar8 = func_0x(puVar46 + 1,uVar36);
                          *(undefined8 *)(puVar33 + -8) = 0x107580;
                          func_0x(puVar46 + 1,uVar36 & 0xffff,uVar8 + 2);
                          uVar36 = uVar36 + 1;
                        } while (uVar36 < *puVar46);
                        lVar15 = *(longlong *)(puVar47 + 3);
                      }
                      lVar15 = (ulonglong)uVar27 + lVar15;
                      iVar45 = *(int *)(puVar47 + 1);
                      *(undefined8 *)(puVar33 + -8) = 0x1075a4;
                      func_0x(lVar15 + 2,lVar15,iVar45 - uVar27);
                      *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + 2;
                      *(int *)(puVar47 + 0xb) = *(int *)(puVar47 + 0xb) + 2;
                      uVar27 = *(uint *)(puVar47 + 0xb);
                      if (uVar7 != 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x1075bf;
                        uVar7 = func_0x(puVar46 + 1,uVar35 - 1);
                        uVar27 = (uint)uVar7;
                      }
                      uVar36 = uVar35 + 1;
                      if (uVar35 < uVar36) {
                        do {
                          *(undefined8 *)(puVar33 + -8) = 0x1075e2;
                          func_0x(puVar46 + 1,uVar35 & 0xffff,uVar27 & 0xffff,0);
                          uVar35 = uVar35 + 1;
                        } while (uVar35 < uVar36);
                      }
                      *puVar46 = *puVar46 + 1;
                      *(undefined8 *)(puVar33 + -8) = 0x1075f4;
                      func_0x(puVar47);
                      iVar37 = 0;
                      uVar7 = puVar47[0xd];
                      *(undefined8 *)(puVar33 + -8) = 0x10760a;
                      uVar10 = func_0x(lVar38 + 2,uVar7);
                      *(undefined8 *)(puVar33 + -8) = 0x107619;
                      func_0x(&stack0x00000360 + lVar12);
                      *(undefined4 *)(puVar33 + 0x28) = 0;
                      *(undefined8 *)(puVar33 + 0x20) = *(undefined8 *)(&stack0x00000078 + lVar12);
                      uVar17 = *(undefined8 *)(&stack0x000000a0 + lVar12);
                      *(undefined8 *)(puVar33 + -8) = 0x107646;
                      func_0x(&stack0x00000360 + lVar12,uVar17,1,0);
                      *(undefined **)(puVar33 + 0x28) = &stack0x000001d4 + lVar12;
                      *(undefined **)(puVar33 + 0x20) = &stack0x00000360 + lVar12;
                      *(undefined8 *)(puVar33 + -8) = 0x107675;
                      func_0x(puVar47 + 0x14,uVar10,0x1f9e,1);
                      iVar34 = *(int *)(&stack0x000001d4 + lVar12);
                      iVar45 = *(int *)(&stack0x00000088 + lVar12);
                    }
                    else {
                      uVar7 = puVar47[0xd];
                      uVar27 = uVar7 + 1;
                      *(undefined8 *)(puVar33 + -8) = 0x1074c1;
                      lVar15 = func_0x(puVar47);
                      if (uVar27 == 1) {
                        uVar27 = *(uint *)(puVar47 + 0xb);
                      }
                      else {
                        *(undefined8 *)(puVar33 + -8) = 0x1074de;
                        uVar8 = func_0x(lVar15 + 2,(ulonglong)uVar27 - 2);
                        uVar27 = (uint)uVar8;
                      }
                      *(undefined8 *)(puVar33 + -8) = 0x1074ee;
                      uVar7 = func_0x(lVar15 + 2,uVar7);
                      if (((uVar27 < *(uint *)(puVar47 + 0xb)) || (uVar7 < uVar27)) ||
                         (*(uint *)(puVar47 + 1) <= (uint)uVar7 &&
                          (uint)uVar7 != *(uint *)(puVar47 + 1))) {
                        uVar17 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x10750f;
                        func_0x(uVar17,7);
                      }
                      iVar37 = uVar7 - uVar27;
                      uVar17 = *(undefined8 *)(&stack0x000000a0 + lVar12);
                      uVar22 = *(undefined8 *)(&stack0x00000078 + lVar12);
                      *(undefined8 *)(puVar33 + -8) = 0x10752f;
                      iVar34 = func_0x(puVar47 + 0x14,uVar22,uVar17,1);
                    }
                    iVar37 = (iVar34 - iVar37) + *(int *)(puVar47 + 1);
                    *(int *)(puVar47 + 1) = iVar37;
                    if ((*(byte *)puVar47 & 1) != 0) {
                      uVar7 = puVar47[0xd];
                      *(undefined8 *)(puVar33 + -8) = 0x1076a3;
                      func_0x(lVar38 + 2,uVar7 + 1,iVar37,1);
                      iVar37 = (*(int *)(puVar47 + 1) - *(int *)(&stack0x00000120 + lVar12)) + -2;
                    }
                    uVar7 = puVar47[0xd];
                    *(undefined8 *)(puVar33 + -8) = 0x1076c1;
                    func_0x(lVar38 + 2,uVar7,iVar37);
                    if (iVar34 == 0) {
                      uVar7 = puVar47[0xd];
                      *(undefined8 *)(puVar33 + -8) = 0x1076d6;
                      func_0x(puVar47,uVar7 + 1,0);
                      *(undefined8 *)(puVar33 + -8) = 0x1076de;
                      pbVar20 = (byte *)func_0x(puVar47);
                      if ((*pbVar20 & 0x20) != 0) {
                        puVar47[0xd] = puVar47[0xd] + 1;
                        *puVar47 = *puVar47 & 0xfffd;
                        *(undefined8 *)(puVar33 + -8) = 0x1076f7;
                        func_0x(puVar47 + 0x14);
                      }
                    }
                    else {
                      *puVar47 = *puVar47 | 2;
                      *(undefined8 *)(puVar33 + -8) = 0x107702;
                      func_0x(puVar47);
                    }
                    if ((*(byte *)puVar47 & 1) != 0) {
                      uVar42 = *(undefined4 *)(&stack0x00000120 + lVar12);
                      *(undefined8 *)(puVar33 + -8) = 0x107722;
                      func_0x(puVar47,0x400,uVar42);
                    }
                    if (iVar45 != 0) {
                      puVar19 = &stack0x00000848;
LAB_:
                      *(undefined8 *)(puVar33 + -8) = 0x106d35;
                      func_0x(puVar47,(longlong)puVar19 + lVar12);
                    }
                  }
                  lVar15 = *(longlong *)(&stack0x00000070 + lVar12);
                }
                else {
                  *(undefined8 *)(puVar33 + -8) = 0x105cb5;
                  iVar45 = func_0x();
                  if (iVar45 == 0) {
                    if (*(int *)(puVar47 + 1) == 0) {
                      *puVar47 = 0;
                      *(undefined4 *)(puVar47 + 9) = *(undefined4 *)(puVar47 + 7);
                      *(undefined8 *)(puVar33 + -8) = 0x105d4f;
                      pbVar20 = (byte *)func_0x(puVar47);
                      if ((*pbVar20 & 0x10) != 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x105d5c;
                        pbVar20 = (byte *)func_0x(puVar47);
                        if ((*pbVar20 & 0x10) != 0) {
                          uVar35 = (uint)*(ushort *)
                                          ((ulonglong)*(uint *)(puVar47 + 7) +
                                          *(longlong *)(puVar47 + 3));
                        }
                        *(uint *)(puVar47 + 9) = *(int *)(puVar47 + 9) + (uVar35 + 7 >> 3) + 2;
                      }
                      *(undefined8 *)(puVar33 + -8) = 0x105d84;
                      pbVar20 = (byte *)func_0x(puVar47);
                      if ((*pbVar20 & 0x20) == 0) {
                        *(undefined4 *)(puVar47 + 1) = *(undefined4 *)(puVar47 + 9);
                        puVar47[0xd] = 0;
                        *(undefined4 *)(puVar47 + 0xb) = *(undefined4 *)(puVar47 + 9);
                      }
                      else {
                        *(undefined8 *)(puVar33 + -8) = 0x105d95;
                        puVar46 = (ushort *)func_0x(puVar47);
                        uVar7 = *puVar46;
                        puVar47[0xd] = uVar7;
                        if (uVar7 == 0) {
                          *(undefined8 *)(puVar33 + -8) = 0x105db0;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x105db9;
                            cVar3 = func_0x();
                            if (cVar3 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x105dc9;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x105de5;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x105e0f;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                              }
                            }
                          }
                          uVar22 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x105e1d;
                          func_0x(uVar22,3);
                          uVar7 = puVar47[0xd];
                        }
                        uVar27 = *(int *)(puVar47 + 9) + (uVar7 + 1) * 2;
                        *(uint *)(puVar47 + 0xb) = uVar27;
                        if (0x1f9e < uVar27) {
                          *(undefined8 *)(puVar33 + -8) = 0x105e44;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x105e4d;
                            cVar3 = func_0x();
                            if (cVar3 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x105e5d;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x105e79;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x105ea3;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                              }
                            }
                          }
                          uVar22 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x105eb1;
                          func_0x(uVar22,4);
                          uVar7 = puVar47[0xd];
                        }
                        puVar46 = puVar46 + 1;
                        *(undefined8 *)(puVar33 + -8) = 0x105ec7;
                        uVar7 = func_0x(puVar46,(ulonglong)uVar7 - 1);
                        *(uint *)(puVar47 + 1) = (uint)uVar7;
                        uVar27 = *(uint *)(puVar47 + 0xb);
                        if (uVar7 < uVar27) {
                          *(undefined8 *)(puVar33 + -8) = 0x105ee0;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x105ee9;
                            cVar3 = func_0x();
                            if (cVar3 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x105ef9;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x105f15;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x105f3f;
                                (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                              }
                            }
                          }
                          uVar22 = *(undefined8 *)(puVar47 + 3);
                          *(undefined8 *)(puVar33 + -8) = 0x105f4d;
                          func_0x(uVar22,4);
                          uVar27 = *(uint *)(puVar47 + 0xb);
                        }
                        iVar45 = 0;
                        uVar7 = puVar47[0xd];
                        if (uVar7 != 0) {
                          do {
                            *(undefined8 *)(puVar33 + -8) = 0x105f7b;
                            uVar7 = func_0x(puVar46,(longlong)iVar45);
                            bVar48 = uVar7 < uVar27;
                            uVar27 = (uint)uVar7;
                            if ((bVar48) ||
                               (*(uint *)(puVar47 + 1) <= (uint)uVar7 &&
                                uVar27 != *(uint *)(puVar47 + 1))) {
                              *(undefined8 *)(puVar33 + -8) = 0x105f93;
                              cVar3 = func_0x(0x112fe00);
                              if (cVar3 != '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x105f9c;
                                cVar3 = func_0x();
                                if (cVar3 != '\0') {
                                  *(undefined8 *)(puVar33 + -8) = 0x105fac;
                                  cVar3 = func_0x(0x112fe00);
                                  if (cVar3 == '\0') {
                                    *(undefined8 *)(puVar33 + -8) = 0x105fc8;
                                    (*_DAT_)(0x22,0x44,0x15);
                                  }
                                  else {
                                    *(undefined8 *)(puVar33 + 0x20) = 0;
                                    *(undefined8 *)(puVar33 + -8) = 0x105fec;
                                    (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                                  }
                                }
                              }
                              uVar17 = *(undefined8 *)(puVar47 + 3);
                              *(undefined8 *)(puVar33 + -8) = 0x105ffa;
                              func_0x(uVar17,4);
                            }
                            iVar45 = iVar45 + 1;
                            uVar7 = puVar47[0xd];
                          } while (iVar45 < (int)(uint)uVar7);
                          lVar15 = *(longlong *)(&stack0x00000070 + lVar12);
                          uVar17 = *(undefined8 *)(&stack0x00000078 + lVar12);
                        }
                        *(undefined8 *)(puVar33 + -8) = 0x106021;
                        iVar45 = func_0x(puVar46,uVar7 - 1);
                        while (iVar45 != 0) {
                          uVar7 = puVar47[0xd];
                          *(undefined8 *)(puVar33 + -8) = 0x10603c;
                          lVar38 = func_0x(puVar47);
                          if (uVar7 == 1) {
                            uVar44 = (ulonglong)*(uint *)(puVar47 + 0xb);
                          }
                          else {
                            *(undefined8 *)(puVar33 + -8) = 0x106059;
                            uVar8 = func_0x(lVar38 + 2,(ulonglong)uVar7 - 2);
                            uVar44 = (ulonglong)uVar8;
                          }
                          *(undefined8 *)(puVar33 + -8) = 0x106069;
                          uVar7 = func_0x(lVar38 + 2,(ulonglong)(uint)uVar7 - 1);
                          uVar27 = *(uint *)(puVar47 + 0xb);
                          uVar35 = (uint)uVar44;
                          if (((uVar35 < uVar27) || (uVar7 < uVar35)) ||
                             (*(uint *)(puVar47 + 1) <= (uint)uVar7 &&
                              (uint)uVar7 != *(uint *)(puVar47 + 1))) {
                            uVar22 = *(undefined8 *)(puVar47 + 3);
                            *(undefined8 *)(puVar33 + -8) = 0x10608a;
                            func_0x(uVar22,7);
                            uVar27 = *(uint *)(puVar47 + 0xb);
                          }
                          if ((uVar35 < uVar27) || (*(uint *)(puVar47 + 1) < uVar35))
                          goto LAB_;
                          uVar8 = *(ushort *)(*(longlong *)(puVar47 + 3) + uVar44);
                          if (uVar8 == 5) {
                            *puVar47 = *puVar47 | 2;
                            puVar47[0xd] = puVar47[0xd] - 1;
                            puVar47[0x14] = (ushort)uVar44;
                            lVar38 = (uVar44 & 0xffff) + *(longlong *)(puVar47 + 3);
                            *(undefined8 *)(puVar33 + -8) = 0x106149;
                            iVar45 = func_0x(lVar38);
                            if (iVar45 == 0) {
                              puVar47[0x15] = puVar47[0x15] & 0xc7ff;
                            }
                            else {
                              *(undefined8 *)(puVar33 + -8) = 0x106155;
                              uVar8 = func_0x(lVar38);
                              puVar47[0x15] = puVar47[0x15] & 0xc7ff;
                              puVar47[0x15] = puVar47[0x15] | (uVar8 & 7) << 0xb;
                            }
                            *(undefined8 *)(puVar33 + -8) = 0x10617d;
                            uVar8 = func_0x(lVar38);
                            puVar47[0x15] = puVar47[0x15] ^ (uVar8 ^ puVar47[0x15]) & 0x7ff;
                            uVar9 = puVar47[0x15];
                            uVar39 = *(ulonglong *)(puVar47 + 3);
                            uVar8 = puVar47[0x14];
                            uVar30 = (ulonglong)((uVar9 & 0x7ff) * 2) + 4 +
                                     (ulonglong)uVar8 + (ulonglong)((uVar9 >> 0xb & 7) * 2) + uVar39
                            ;
                            uVar44 = uVar39 + uVar8;
                            if (uVar30 < uVar44) {
                              *(undefined8 *)(puVar33 + -8) = 0x1061d3;
                              func_0x(uVar44,0x19);
                              uVar9 = puVar47[0x15];
                              uVar8 = puVar47[0x14];
                              uVar39 = (ulonglong)*(uint *)(puVar47 + 3);
                            }
                            if (uVar7 - uVar35 <
                                (((uVar9 & 0x7ff) * 2 - (uint)uVar8) - (int)uVar39) + (int)uVar30) {
                              uVar7 = puVar47[0x14];
                              lVar38 = *(longlong *)(puVar47 + 3);
                              *(undefined8 *)(puVar33 + -8) = 0x10620e;
                              func_0x((ulonglong)uVar7 + lVar38,0x19);
                              uVar9 = puVar47[0x15];
                            }
                            if ((uVar9 & 0x3800) != 0) {
                              uVar7 = puVar47[0x14];
                              lVar38 = *(longlong *)(puVar47 + 3);
                              iVar45 = 0;
                              if ((uVar9 & 0x3800) != 0) {
                                do {
                                  uVar8 = puVar47[0x15];
                                  *(undefined8 *)(puVar33 + -8) = 0x10624f;
                                  uVar9 = func_0x
                                                    ((ulonglong)uVar7 + lVar38 + 4,iVar45);
                                  if ((uVar8 & 0x7ff) < uVar9) {
                                    uVar8 = puVar47[0x14];
                                    lVar16 = *(longlong *)(puVar47 + 3);
                                    *(undefined8 *)(puVar33 + -8) = 0x10626d;
                                    func_0x((ulonglong)uVar8 + lVar16,0x1a);
                                    uVar8 = puVar47[0x15];
                                  }
                                  iVar45 = iVar45 + 1;
                                } while (iVar45 < (int)(uVar8 >> 0xb & 7));
                              }
                            }
                            break;
                          }
                          if (uVar8 < 0x400) break;
                          *puVar47 = *puVar47 | 1;
                          uVar7 = puVar47[0xd] - 1;
                          puVar47[0xd] = uVar7;
                          if (uVar7 == 0) break;
                          *(undefined8 *)(puVar33 + -8) = 0x1060d9;
                          iVar45 = func_0x(puVar46,uVar7 - 1);
                        }
                      }
                      *(undefined8 *)(puVar33 + -8) = 0x1060eb;
                      iVar45 = func_0x(puVar47);
                      if (iVar45 == 0) {
                        *(undefined4 *)(puVar47 + 0x12) = 0;
                      }
                      else {
                        *(int *)(puVar47 + 0x12) = *(int *)(puVar47 + 1);
                        *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + 0xe;
                        *(undefined8 *)(puVar33 + -8) = 0x106107;
                        uVar22 = func_0x(puVar47);
                        *(undefined8 *)(puVar33 + -8) = 0x106116;
                        func_0x(uVar22,&stack0x00000268 + lVar12);
                        *(undefined8 *)(puVar33 + -8) = 0x106122;
                        iVar45 = func_0x(&stack0x00000268 + lVar12);
                        *(int *)(puVar47 + 1) = *(int *)(puVar47 + 1) + iVar45;
                      }
                      uVar27 = *(uint *)(puVar47 + 1);
                      if ((*(ulonglong *)(puVar47 + 0xe) != 0) &&
                         (*(ulonglong *)(puVar47 + 0xe) <
                          (ulonglong)uVar27 + *(longlong *)(puVar47 + 3))) {
                        *(undefined8 *)(puVar33 + -8) = 0x1062c1;
                        cVar3 = func_0x(0x112fe00);
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x1062ca;
                          cVar3 = func_0x();
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x1062da;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x1062f6;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x10631c;
                              (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                            }
                          }
                        }
                        uVar22 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x10632a;
                        func_0x(uVar22,0x12);
                        uVar27 = *(uint *)(puVar47 + 1);
                      }
                      if (0x3f3b < uVar27 - 1) {
                        *(undefined8 *)(puVar33 + -8) = 0x106343;
                        cVar3 = func_0x(0x112fe00);
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x10634c;
                          cVar3 = func_0x();
                          if (cVar3 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x10635c;
                            cVar3 = func_0x(0x112fe00);
                            if (cVar3 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x106378;
                              (*_DAT_)(0x22,0x44,0x15);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x10639e;
                              (*_DAT_)(1,0xa1f80c,0xb3f8f8);
                            }
                          }
                        }
                        uVar22 = *(undefined8 *)(puVar47 + 3);
                        *(undefined8 *)(puVar33 + -8) = 0x1063ac;
                        func_0x(uVar22,5);
                      }
LAB_:
                      pcVar40 = *(char **)(&stack0x000000a0 + lVar12);
                    }
                    *(undefined8 *)(puVar33 + -8) = 0x1063bb;
                    iVar45 = func_0x(uVar17);
                    uVar27 = iVar45 + 1;
                    if (*(uint *)(puVar47 + 7) < uVar27) {
                      iVar45 = *(int *)(puVar47 + 7);
                      *(undefined8 *)(puVar33 + -8) = 0x1063da;
                      func_0x(puVar47,0,uVar27 - iVar45);
                      *(undefined8 *)(puVar33 + -8) = 0x1063e2;
                      iVar45 = func_0x(puVar47);
                      if (iVar45 != 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x1063f3;
                        func_0x(puVar47,uVar27);
                      }
                      *(uint *)(puVar47 + 7) = uVar27;
                    }
                    *(undefined8 *)(puVar33 + -8) = 0x1063fe;
                    iVar45 = func_0x(uVar17);
                    if (pcVar40 != (char *)0x0) {
                      *(char *)((longlong)iVar45 + *(longlong *)(puVar47 + 3)) = *pcVar40;
                    }
                  }
                  else {
                    cVar3 = *pcVar40;
                    *(undefined8 *)(puVar33 + -8) = 0x105cc8;
                    iVar45 = func_0x(uVar17);
                    uVar27 = iVar45 + 1;
                    if (*(uint *)(puVar47 + 7) < uVar27) {
                      iVar34 = *(int *)(puVar47 + 7);
                      *(undefined8 *)(puVar33 + -8) = 0x105cea;
                      func_0x(puVar47,0,uVar27 - iVar34);
                      *(undefined8 *)(puVar33 + -8) = 0x105cf2;
                      iVar34 = func_0x(puVar47);
                      if (iVar34 != 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x105d03;
                        func_0x(puVar47,uVar27);
                      }
                      *(uint *)(puVar47 + 7) = uVar27;
                    }
                    pbVar20 = (byte *)((longlong)iVar45 + *(longlong *)(puVar47 + 3));
                    bVar24 = *pbVar20;
                    *(undefined8 *)(puVar33 + -8) = 0x105d18;
                    bVar4 = func_0x(uVar17);
                    if (cVar3 == '\0') {
                      *pbVar20 = bVar24 & ~(byte)(1 << (bVar4 & 0x1f));
                    }
                    else {
                      *pbVar20 = bVar24 | (byte)(1 << (bVar4 & 0x1f));
                    }
                  }
                }
              }
              else {
                *(undefined8 *)(puVar33 + 0x20) = 0x79ad70;
                *(undefined8 *)(puVar33 + -8) = 0x105c87;
                (*_DAT_)(1,0xba1100,0xbcdac8);
              }
            }
            lVar15 = lVar15 + 0x50;
            *(longlong *)(&stack0x00000070 + lVar12) = lVar15;
            iVar45 = *(int *)(&stack0x00000098 + lVar12);
            *(uint *)(&stack0x00000098 + lVar12) = iVar45 + 1U;
            lVar38 = *(longlong *)(&stack0x00000028 + lVar12);
          } while (iVar45 + 1U < *(uint *)((longlong)&puStackX_20 + lVar12));
        }
        puVar46 = (ushort *)0x0;
        if (*puVar1 != 0) {
          lVar38 = *(longlong *)(&stack0x00000028 + lVar12);
          uVar27 = *puVar1;
LAB_:
          uVar35 = uVar27 - 1;
          if (*(int *)((ulonglong)uVar35 * 0x20 + 8 + lVar38) == 0) goto code_r0x00106d96;
          puVar47[0xd] = (ushort)uVar27;
          iVar45 = *(int *)(puVar47 + 9) + 2 + uVar27 * 2;
          *(int *)(puVar47 + 0xb) = iVar45;
          *(int *)(puVar47 + 1) = iVar45;
          *(undefined8 *)(puVar33 + -8) = 0x1079cb;
          pbVar20 = (byte *)func_0x(puVar47);
          *pbVar20 = *pbVar20 | 0x20;
          uVar35 = *(uint *)(puVar47 + 1);
          uVar36 = *(uint *)(&stack0x00000080 + lVar12);
          if (uVar35 <= uVar36) {
            *(undefined8 *)(puVar33 + -8) = 0x1079e0;
            puVar46 = (ushort *)func_0x(puVar47);
            *puVar46 = (ushort)uVar27;
            uVar35 = *(uint *)(puVar47 + 1);
            uVar36 = *(uint *)(&stack0x00000080 + lVar12);
          }
          uVar41 = 0;
          if (uVar27 != 0) {
            puVar31 = (uint *)(lVar38 + 0xc);
            do {
              uVar26 = *(uint *)(puVar47 + 1);
              lVar38 = *(longlong *)(puVar47 + 3);
              uVar25 = puVar31[-1];
              uVar35 = uVar26 + uVar25;
              *(uint *)(puVar47 + 1) = uVar35;
              if (uVar35 <= uVar36) {
                uVar36 = *puVar31;
                *(undefined8 *)(puVar33 + -8) = 0x107a2e;
                func_0x(puVar46 + 1,uVar41,uVar35,uVar36 & 1);
                uVar17 = *(undefined8 *)(puVar31 + -3);
                *(undefined8 *)(puVar33 + -8) = 0x107a40;
                func_0x((ulonglong)uVar26 + lVar38,uVar25,uVar17,uVar25);
                uVar35 = *(uint *)(puVar47 + 1);
                uVar36 = *(uint *)(&stack0x00000080 + lVar12);
              }
              uVar41 = uVar41 + 1;
              puVar31 = puVar31 + 8;
            } while (uVar41 < uVar27);
          }
          if (uVar36 < uVar35) {
            *(undefined4 *)(&stack0x00000094 + lVar12) = 0;
          }
        }
      }
      else {
        *(undefined8 *)(&stack0x00000070 + lVar12) = *(undefined8 *)(lVar38 + 0x10);
        *(undefined8 *)((longlong)&puStackX_20 + lVar12) = 0;
        *(undefined8 *)(puVar33 + -8) = 0x107a80;
        lVar38 = func_0x(&stack0x000000b8 + lVar12);
        *(longlong *)(&stack0x000000a0 + lVar12) = lVar38;
        *(undefined2 *)(&stack0x00000130 + lVar12) = 0xffff;
        *(undefined8 *)(&stack0x00000138 + lVar12) = 0;
        *(undefined4 *)(&stack0x00000134 + lVar12) = 0;
        *(undefined8 *)(&stack0x0000014e + lVar12) = 0;
        *(undefined8 *)(&stack0x00000158 + lVar12) = 0;
        *(undefined8 *)(puVar33 + -8) = 0x107ac0;
        func_0x(&stack0x00000132 + lVar12,0);
        *(undefined8 *)(&stack0x000001c0 + lVar12) = 0;
        *(undefined4 *)(&stack0x000000ac + lVar12) = 0;
        if (*(short *)(&stack0x00000038 + lVar12) == 0) {
LAB_:
          psVar43 = (short *)(&stack0x00000038 + lVar12);
          puVar46 = (ushort *)(&stack0x0000003a + lVar12);
        }
        else {
          *(undefined8 *)(puVar33 + -8) = 0x107ae2;
          lVar15 = func_0x(&stack0x0000003a + lVar12);
          if (lVar15 == 0) goto LAB_;
          uVar22 = uVar17;
          if (*(short *)(&stack0x00000038 + lVar12) != 0) {
            *(undefined8 *)(puVar33 + -8) = 0x107b00;
            uVar22 = func_0x(&stack0x0000003a + lVar12);
          }
          *(undefined8 *)(puVar33 + -8) = 0x107b08;
          iVar45 = func_0x(uVar22);
          if (iVar45 == 0) goto LAB_;
          *(short *)(&stack0x00000130 + lVar12) = *(short *)(&stack0x00000038 + lVar12);
          if (*(short *)(&stack0x00000038 + lVar12) == 0) {
            uVar35 = *(uint *)(&stack0x0000003c + lVar12);
            if (uVar35 == 0) {
              *(undefined2 *)(&stack0x0000003a + lVar12) = 0;
              *(undefined4 *)(&stack0x0000004c + lVar12) =
                   *(undefined4 *)(&stack0x00000048 + lVar12);
              *(undefined8 *)(puVar33 + -8) = 0x107b43;
              pbVar20 = (byte *)func_0x(&stack0x0000003a + lVar12);
              if ((*pbVar20 & 0x10) != 0) {
                *(undefined8 *)(puVar33 + -8) = 0x107b51;
                pbVar20 = (byte *)func_0x(&stack0x0000003a + lVar12);
                if ((*pbVar20 & 0x10) != 0) {
                  uVar27 = (uint)*(ushort *)
                                  (*(longlong *)(&stack0x00000040 + lVar12) +
                                  (ulonglong)*(uint *)(&stack0x00000048 + lVar12));
                }
                *(uint *)(&stack0x0000004c + lVar12) =
                     (uVar27 + 7 >> 3) + *(int *)(&stack0x0000004c + lVar12) + 2;
              }
              *(undefined8 *)(puVar33 + -8) = 0x107b80;
              pbVar20 = (byte *)func_0x(&stack0x0000003a + lVar12);
              if ((*pbVar20 & 0x20) == 0) {
                *(undefined4 *)(&stack0x0000003c + lVar12) =
                     *(undefined4 *)(&stack0x0000004c + lVar12);
                *(undefined2 *)(&stack0x00000054 + lVar12) = 0;
                *(undefined4 *)(&stack0x00000050 + lVar12) =
                     *(undefined4 *)(&stack0x0000004c + lVar12);
              }
              else {
                *(undefined8 *)(puVar33 + -8) = 0x107b92;
                puVar46 = (ushort *)func_0x(&stack0x0000003a + lVar12);
                uVar7 = *puVar46;
                *(ushort *)(&stack0x00000054 + lVar12) = uVar7;
                if (uVar7 == 0) {
                  *(undefined8 *)(puVar33 + -8) = 0x107bb0;
                  cVar3 = func_0x(0x112fe00);
                  if (cVar3 != '\0') {
                    *(undefined8 *)(puVar33 + -8) = 0x107bb9;
                    cVar3 = func_0x();
                    if (cVar3 != '\0') {
                      *(undefined8 *)(puVar33 + -8) = 0x107bc9;
                      cVar3 = func_0x(0x112fe00);
                      if (cVar3 == '\0') {
                        *(undefined8 *)(puVar33 + -8) = 0x107be5;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar33 + 0x20) = 0;
                        *(undefined8 *)(puVar33 + -8) = 0x107c08;
                        (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x80f);
                      }
                    }
                  }
                  uVar17 = *(undefined8 *)(&stack0x00000040 + lVar12);
                  *(undefined8 *)(puVar33 + -8) = 0x107c16;
                  func_0x(uVar17,3);
                  uVar7 = *(ushort *)(&stack0x00000054 + lVar12);
                }
                uVar27 = *(int *)(&stack0x0000004c + lVar12) + 2 + (uint)uVar7 * 2;
                *(uint *)(&stack0x00000050 + lVar12) = uVar27;
                if (0x1f9e < uVar27) {
                  *(undefined8 *)(puVar33 + -8) = 0x107c3f;
                  cVar3 = func_0x(0x112fe00);
                  if (cVar3 != '\0') {
                    *(undefined8 *)(puVar33 + -8) = 0x107c48;
                    cVar3 = func_0x();
                    if (cVar3 != '\0') {
                      *(undefined8 *)(puVar33 + -8) = 0x107c58;
                      cVar3 = func_0x(0x112fe00);
                      if (cVar3 == '\0') {
                        *(undefined8 *)(puVar33 + -8) = 0x107c74;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar33 + 0x20) = 0;
                        *(undefined8 *)(puVar33 + -8) = 0x107c97;
                        (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x816);
                      }
                    }
                  }
                  uVar17 = *(undefined8 *)(&stack0x00000040 + lVar12);
                  *(undefined8 *)(puVar33 + -8) = 0x107ca5;
                  func_0x(uVar17,4);
                  uVar7 = *(ushort *)(&stack0x00000054 + lVar12);
                }
                puVar46 = puVar46 + 1;
                *(undefined8 *)(puVar33 + -8) = 0x107cbd;
                uVar7 = func_0x(puVar46,(ulonglong)uVar7 - 1);
                *(uint *)(&stack0x0000003c + lVar12) = (uint)uVar7;
                uVar27 = *(uint *)(&stack0x00000050 + lVar12);
                if (uVar7 < uVar27) {
                  *(undefined8 *)(puVar33 + -8) = 0x107cd8;
                  cVar3 = func_0x(0x112fe00);
                  if (cVar3 != '\0') {
                    *(undefined8 *)(puVar33 + -8) = 0x107ce1;
                    cVar3 = func_0x();
                    if (cVar3 != '\0') {
                      *(undefined8 *)(puVar33 + -8) = 0x107cf1;
                      cVar3 = func_0x(0x112fe00);
                      if (cVar3 == '\0') {
                        *(undefined8 *)(puVar33 + -8) = 0x107d0d;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar33 + 0x20) = 0;
                        *(undefined8 *)(puVar33 + -8) = 0x107d34;
                        (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x81d);
                      }
                    }
                  }
                  uVar17 = *(undefined8 *)(&stack0x00000040 + lVar12);
                  *(undefined8 *)(puVar33 + -8) = 0x107d42;
                  func_0x(uVar17,4);
                  uVar27 = *(uint *)(&stack0x00000050 + lVar12);
                }
                iVar45 = 0;
                uVar35 = (uint)*(ushort *)(&stack0x00000054 + lVar12);
                if (*(ushort *)(&stack0x00000054 + lVar12) != 0) {
                  do {
                    *(undefined8 *)(puVar33 + -8) = 0x107d6b;
                    uVar7 = func_0x(puVar46,(longlong)iVar45);
                    bVar48 = uVar7 < uVar27;
                    uVar27 = (uint)uVar7;
                    if ((bVar48) ||
                       (*(uint *)(&stack0x0000003c + lVar12) <= (uint)uVar7 &&
                        uVar27 != *(uint *)(&stack0x0000003c + lVar12))) {
                      *(undefined8 *)(puVar33 + -8) = 0x107d84;
                      cVar3 = func_0x(0x112fe00);
                      if (cVar3 != '\0') {
                        *(undefined8 *)(puVar33 + -8) = 0x107d8d;
                        cVar3 = func_0x();
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x107d9d;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 == '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x107db9;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar33 + 0x20) = 0;
                            *(undefined8 *)(puVar33 + -8) = 0x107ddd;
                            (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x82a);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(&stack0x00000040 + lVar12);
                      *(undefined8 *)(puVar33 + -8) = 0x107deb;
                      func_0x(uVar17,4);
                    }
                    iVar45 = iVar45 + 1;
                    uVar35 = (uint)*(ushort *)(&stack0x00000054 + lVar12);
                  } while (iVar45 < (int)(uint)*(ushort *)(&stack0x00000054 + lVar12));
                  puVar47 = *(ushort **)(&stack0x00000028 + lVar12);
                  lVar38 = *(longlong *)(&stack0x000000a0 + lVar12);
                }
                while( true ) {
                  *(undefined8 *)(puVar33 + -8) = 0x107e1d;
                  iVar45 = func_0x(puVar46,uVar35 - 1);
                  if (iVar45 == 0) break;
                  uVar7 = *(ushort *)(&stack0x00000054 + lVar12);
                  *(undefined8 *)(puVar33 + -8) = 0x107e32;
                  lVar15 = func_0x(&stack0x0000003a + lVar12);
                  if (uVar7 == 1) {
                    uVar27 = *(uint *)(&stack0x00000050 + lVar12);
                  }
                  else {
                    *(undefined8 *)(puVar33 + -8) = 0x107e4f;
                    uVar8 = func_0x(lVar15 + 2,(ulonglong)uVar7 - 2);
                    uVar27 = (uint)uVar8;
                  }
                  *(undefined8 *)(puVar33 + -8) = 0x107e5f;
                  uVar7 = func_0x(lVar15 + 2,(ulonglong)(uint)uVar7 - 1);
                  if (((uVar27 < *(uint *)(&stack0x00000050 + lVar12)) || (uVar7 < uVar27)) ||
                     (uVar35 = *(uint *)(&stack0x0000003c + lVar12),
                     uVar35 <= uVar7 && uVar7 != uVar35)) {
                    uVar17 = *(undefined8 *)(&stack0x00000040 + lVar12);
                    *(undefined8 *)(puVar33 + -8) = 0x107e80;
                    func_0x(uVar17,7);
                    uVar35 = *(uint *)(&stack0x0000003c + lVar12);
                  }
                  if ((uVar27 < *(uint *)(&stack0x00000050 + lVar12)) || (uVar35 < uVar27))
                  goto LAB_;
                  uVar8 = *(ushort *)(*(longlong *)(&stack0x00000040 + lVar12) + (ulonglong)uVar27);
                  if (uVar8 == 5) {
                    *(ushort *)(&stack0x0000003a + lVar12) =
                         *(ushort *)(&stack0x0000003a + lVar12) | 2;
                    *(short *)(&stack0x00000054 + lVar12) =
                         *(short *)(&stack0x00000054 + lVar12) + -1;
                    *(short *)(&stack0x00000062 + lVar12) = (short)uVar27;
                    lVar15 = (ulonglong)(uVar27 & 0xffff) + *(longlong *)(&stack0x00000040 + lVar12)
                    ;
                    *(undefined8 *)(puVar33 + -8) = 0x107f3c;
                    iVar45 = func_0x(lVar15);
                    if (iVar45 == 0) {
                      *(ushort *)(&stack0x00000064 + lVar12) =
                           *(ushort *)(&stack0x00000064 + lVar12) & 0xc7ff;
                    }
                    else {
                      *(undefined8 *)(puVar33 + -8) = 0x107f48;
                      sVar6 = func_0x(lVar15);
                      *(ushort *)(&stack0x00000064 + lVar12) =
                           *(ushort *)(&stack0x00000064 + lVar12) ^
                           (sVar6 << 0xb ^ *(ushort *)(&stack0x00000064 + lVar12)) & 0x3800;
                    }
                    *(undefined8 *)(puVar33 + -8) = 0x107f77;
                    uVar9 = func_0x(lVar15);
                    uVar8 = *(ushort *)(&stack0x00000064 + lVar12);
                    uVar9 = (*(ushort *)(&stack0x00000064 + lVar12) ^ uVar9) & 0x7ff ^ uVar8;
                    uVar39 = (ulonglong)uVar9;
                    *(ushort *)(&stack0x00000064 + lVar12) = uVar9;
                    uVar30 = (ulonglong)*(ushort *)(&stack0x00000062 + lVar12);
                    lVar15 = *(longlong *)(&stack0x00000040 + lVar12);
                    uVar44 = (uVar8 >> 0xb & 7) * 2 + uVar30 + ((uVar39 & 0x7ff) + 2) * 2 + lVar15;
                    if (uVar44 < lVar15 + uVar30) {
                      *(undefined8 *)(puVar33 + -8) = 0x107fd0;
                      func_0x(lVar15 + uVar30,0x19);
                      uVar39 = (ulonglong)*(ushort *)(&stack0x00000064 + lVar12);
                      uVar30 = (ulonglong)*(ushort *)(&stack0x00000062 + lVar12);
                      lVar15 = *(longlong *)(&stack0x00000040 + lVar12);
                    }
                    if (uVar7 - uVar27 <
                        (((*(uint *)(&stack0x00000064 + lVar12) & 0x7ff) * 2 - (int)uVar30) -
                        *(int *)(&stack0x00000040 + lVar12)) + (int)uVar44) {
                      *(undefined8 *)(puVar33 + -8) = 0x108006;
                      func_0x(uVar30 + lVar15,0x19);
                      uVar39 = (ulonglong)*(ushort *)(&stack0x00000064 + lVar12);
                      uVar30 = (ulonglong)*(ushort *)(&stack0x00000062 + lVar12);
                      lVar15 = *(longlong *)(&stack0x00000040 + lVar12);
                    }
                    iVar45 = 0;
                    if (((uVar39 & 0x3800) != 0) && ((uVar39 & 0x3800) != 0)) {
                      do {
                        *(undefined8 *)(puVar33 + -8) = 0x10804b;
                        uVar7 = func_0x(uVar30 + lVar15 + 4,iVar45);
                        if ((*(ushort *)(&stack0x00000064 + lVar12) & 0x7ff) < uVar7) {
                          uVar7 = *(ushort *)(&stack0x00000062 + lVar12);
                          lVar16 = *(longlong *)(&stack0x00000040 + lVar12);
                          *(undefined8 *)(puVar33 + -8) = 0x10806a;
                          func_0x((ulonglong)uVar7 + lVar16,0x1a);
                        }
                        iVar45 = iVar45 + 1;
                      } while (iVar45 < (int)(*(uint *)(&stack0x00000064 + lVar12) >> 0xb & 7));
                    }
                    break;
                  }
                  if (uVar8 < 0x400) break;
                  *(ushort *)(&stack0x0000003a + lVar12) =
                       *(ushort *)(&stack0x0000003a + lVar12) | 1;
                  uVar7 = *(short *)(&stack0x00000054 + lVar12) - 1;
                  uVar35 = (uint)uVar7;
                  *(ushort *)(&stack0x00000054 + lVar12) = uVar7;
                  if (uVar7 == 0) break;
                }
              }
              *(undefined8 *)(puVar33 + -8) = 0x107ed7;
              iVar45 = func_0x(&stack0x0000003a + lVar12);
              if (iVar45 == 0) {
                *(undefined4 *)(&stack0x0000005e + lVar12) = 0;
                uVar35 = *(uint *)(&stack0x0000003c + lVar12);
              }
              else {
                *(int *)(&stack0x0000005e + lVar12) = *(int *)(&stack0x0000003c + lVar12);
                *(int *)(&stack0x0000003c + lVar12) = *(int *)(&stack0x0000003c + lVar12) + 0xe;
                *(undefined8 *)(puVar33 + -8) = 0x107ef4;
                uVar17 = func_0x(&stack0x0000003a + lVar12);
                *(undefined8 *)(puVar33 + -8) = 0x107f03;
                func_0x(uVar17,&stack0x00000280 + lVar12);
                *(undefined8 *)(puVar33 + -8) = 0x107f0f;
                iVar45 = func_0x(&stack0x00000280 + lVar12);
                uVar35 = *(int *)(&stack0x0000003c + lVar12) + iVar45;
                *(uint *)(&stack0x0000003c + lVar12) = uVar35;
              }
              if ((*(ulonglong *)(&stack0x00000056 + lVar12) != 0) &&
                 (*(ulonglong *)(&stack0x00000056 + lVar12) <
                  (ulonglong)uVar35 + *(longlong *)(&stack0x00000040 + lVar12))) {
                *(undefined8 *)(puVar33 + -8) = 0x1080bc;
                cVar3 = func_0x(0x112fe00);
                if (cVar3 != '\0') {
                  *(undefined8 *)(puVar33 + -8) = 0x1080c5;
                  cVar3 = func_0x();
                  if (cVar3 != '\0') {
                    *(undefined8 *)(puVar33 + -8) = 0x1080d5;
                    cVar3 = func_0x(0x112fe00);
                    if (cVar3 == '\0') {
                      *(undefined8 *)(puVar33 + -8) = 0x1080f1;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar33 + 0x20) = 0;
                      *(undefined8 *)(puVar33 + -8) = 0x108117;
                      (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x886);
                    }
                  }
                }
                uVar17 = *(undefined8 *)(&stack0x00000040 + lVar12);
                *(undefined8 *)(puVar33 + -8) = 0x108125;
                func_0x(uVar17,0x12);
                uVar35 = *(uint *)(&stack0x0000003c + lVar12);
              }
              if (0x3f3b < uVar35 - 1) {
                *(undefined8 *)(puVar33 + -8) = 0x10813e;
                cVar3 = func_0x(0x112fe00);
                if (cVar3 != '\0') {
                  *(undefined8 *)(puVar33 + -8) = 0x108147;
                  cVar3 = func_0x();
                  if (cVar3 != '\0') {
                    *(undefined8 *)(puVar33 + -8) = 0x108157;
                    cVar3 = func_0x(0x112fe00);
                    if (cVar3 == '\0') {
                      *(undefined8 *)(puVar33 + -8) = 0x108173;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar33 + 0x20) = 0;
                      *(undefined8 *)(puVar33 + -8) = 0x108199;
                      (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x88b);
                    }
                  }
                }
                uVar17 = *(undefined8 *)(&stack0x00000040 + lVar12);
                *(undefined8 *)(puVar33 + -8) = 0x1081a7;
                func_0x(uVar17,5);
                uVar35 = *(uint *)(&stack0x0000003c + lVar12);
              }
            }
LAB_:
            uVar27 = uVar35;
            if (uVar35 < 9) {
              *(undefined8 *)(puVar33 + -8) = 0x1081b8;
              cVar3 = func_0x(&stack0x0000003a + lVar12);
              if ((cVar3 == '\0') || (cVar3 == '\f')) {
                uVar35 = *(uint *)(&stack0x0000003c + lVar12);
                uVar27 = 9;
              }
              else {
                uVar35 = *(uint *)(&stack0x0000003c + lVar12);
                uVar27 = uVar35;
              }
            }
            *(undefined4 *)(&stack0x00000140 + lVar12) = *(undefined4 *)(&stack0x00000048 + lVar12);
            *(undefined2 *)(&stack0x00000132 + lVar12) = *(undefined2 *)(&stack0x0000003a + lVar12);
            *(uint *)(&stack0x00000134 + lVar12) = uVar35;
            *(undefined2 *)(&stack0x0000014c + lVar12) = *(undefined2 *)(&stack0x00000054 + lVar12);
            *(undefined4 *)(&stack0x00000144 + lVar12) = *(undefined4 *)(&stack0x0000004c + lVar12);
            *(undefined4 *)(&stack0x00000148 + lVar12) = *(undefined4 *)(&stack0x00000050 + lVar12);
            *(undefined4 *)(&stack0x00000156 + lVar12) = *(undefined4 *)(&stack0x0000005e + lVar12);
            *(undefined8 *)(puVar33 + -8) = 0x108217;
            uVar17 = func_0x(&stack0x0000003a + lVar12);
            *(undefined8 *)(puVar33 + -8) = 0x10822e;
            func_0x(&stack0x000028c8 + lVar12,0x1f9e,uVar17,uVar27);
            *(undefined **)(&stack0x00000138 + lVar12) = &stack0x000028c8 + lVar12;
            *(undefined8 *)(puVar33 + -8) = 0x108248;
            iVar45 = func_0x(&stack0x00000132 + lVar12);
            if (iVar45 != 0) {
              *(undefined8 *)(puVar33 + -8) = 0x108263;
              uVar7 = func_0x(&stack0x00000132 + lVar12,&stack0x000001d8 + lVar12);
              uVar27 = *(uint *)(&stack0x000001d8 + lVar12);
              *(ushort *)(&stack0x0000015a + lVar12) = uVar7;
              lVar15 = (ulonglong)uVar7 + *(longlong *)(&stack0x00000138 + lVar12);
              *(undefined8 *)(puVar33 + -8) = 0x108282;
              iVar45 = func_0x(lVar15);
              if (iVar45 == 0) {
                *(ushort *)(&stack0x0000015c + lVar12) =
                     *(ushort *)(&stack0x0000015c + lVar12) & 0xc7ff;
              }
              else {
                *(undefined8 *)(puVar33 + -8) = 0x10828e;
                sVar6 = func_0x(lVar15);
                *(ushort *)(&stack0x0000015c + lVar12) =
                     *(ushort *)(&stack0x0000015c + lVar12) ^
                     (sVar6 << 0xb ^ *(ushort *)(&stack0x0000015c + lVar12)) & 0x3800;
              }
              *(undefined8 *)(puVar33 + -8) = 0x1082d4;
              uVar8 = func_0x(lVar15);
              uVar7 = *(ushort *)(&stack0x0000015c + lVar12);
              uVar8 = (uVar8 ^ *(ushort *)(&stack0x0000015c + lVar12)) & 0x7ff ^ uVar7;
              uVar39 = (ulonglong)uVar8;
              *(ushort *)(&stack0x0000015c + lVar12) = uVar8;
              uVar30 = (ulonglong)*(ushort *)(&stack0x0000015a + lVar12);
              lVar15 = *(longlong *)(&stack0x00000138 + lVar12);
              uVar44 = (ulonglong)((uVar7 >> 0xb & 7) * 2) + lVar15 + ((uVar39 & 0x7ff) + 2) * 2 +
                       uVar30;
              if (uVar44 < uVar30 + lVar15) {
                *(undefined8 *)(puVar33 + -8) = 0x10833b;
                func_0x(uVar30 + lVar15,0x19);
                uVar39 = (ulonglong)*(ushort *)(&stack0x0000015c + lVar12);
                uVar30 = (ulonglong)*(ushort *)(&stack0x0000015a + lVar12);
                lVar15 = *(longlong *)(&stack0x00000138 + lVar12);
              }
              if (uVar27 < (((*(uint *)(&stack0x0000015c + lVar12) & 0x7ff) * 2 - (int)uVar30) -
                           *(int *)(&stack0x00000138 + lVar12)) + (int)uVar44) {
                *(undefined8 *)(puVar33 + -8) = 0x108380;
                func_0x(uVar30 + lVar15,0x19);
                uVar39 = (ulonglong)*(ushort *)(&stack0x0000015c + lVar12);
                uVar30 = (ulonglong)*(ushort *)(&stack0x0000015a + lVar12);
                lVar15 = *(longlong *)(&stack0x00000138 + lVar12);
              }
              if ((uVar39 & 0x3800) != 0) {
                iVar45 = 0;
                if ((uVar39 & 0x3800) != 0) {
                  do {
                    *(undefined8 *)(puVar33 + -8) = 0x1083cb;
                    uVar7 = func_0x(uVar30 + lVar15 + 4,iVar45);
                    if ((*(ushort *)(&stack0x0000015c + lVar12) & 0x7ff) < uVar7) {
                      uVar7 = *(ushort *)(&stack0x0000015a + lVar12);
                      lVar16 = *(longlong *)(&stack0x00000138 + lVar12);
                      *(undefined8 *)(puVar33 + -8) = 0x1083f3;
                      func_0x((ulonglong)uVar7 + lVar16,0x1a);
                    }
                    iVar45 = iVar45 + 1;
                  } while (iVar45 < (int)(*(uint *)(&stack0x0000015c + lVar12) >> 0xb & 7));
                  psVar43 = (short *)(&stack0x00000130 + lVar12);
                  puVar46 = (ushort *)(&stack0x00000132 + lVar12);
                  goto LAB_;
                }
              }
            }
LAB_:
            psVar43 = (short *)(&stack0x00000130 + lVar12);
            puVar46 = (ushort *)(&stack0x00000132 + lVar12);
          }
          else {
            *(undefined8 *)(puVar33 + -8) = 0x108421;
            lVar15 = func_0x(&stack0x0000003a + lVar12);
            if (lVar15 == 0) {
LAB_:
              *(undefined8 *)(puVar33 + -8) = 0x10848b;
              func_0x(&stack0x00000132 + lVar12,&stack0x000028c8 + lVar12,0x1f9e,
                              &stack0x0000003a + lVar12);
              if (*(short *)(&stack0x00000038 + lVar12) != 0) {
                *(undefined8 *)(puVar33 + -8) = 0x1084a0;
                uVar17 = func_0x(&stack0x0000003a + lVar12);
              }
              *(undefined8 *)(puVar33 + -8) = 0x1084af;
              func_0x(&stack0x00000132 + lVar12,uVar17);
              goto LAB_;
            }
            uVar22 = uVar17;
            if (*(short *)(&stack0x00000038 + lVar12) != 0) {
              *(undefined8 *)(puVar33 + -8) = 0x10843b;
              uVar22 = func_0x(&stack0x0000003a + lVar12);
            }
            *(undefined8 *)(puVar33 + -8) = 0x108443;
            iVar45 = func_0x(uVar22);
            if (iVar45 == 0) goto LAB_;
            *(undefined8 *)(puVar33 + -8) = 0x108461;
            func_0x(&stack0x00000130 + lVar12,&stack0x000028c8 + lVar12,0x1f9e,
                            &stack0x00000038 + lVar12);
            psVar43 = (short *)(&stack0x00000130 + lVar12);
            puVar46 = (ushort *)(&stack0x00000132 + lVar12);
          }
        }
LAB_:
        lVar38 = lVar38 + 0x10;
        *(undefined8 *)(puVar33 + -8) = 0x1084d3;
        iVar45 = func_0x(lVar38);
        *(undefined8 *)(puVar33 + -8) = 0x1084df;
        uVar27 = func_0x(psVar43);
        if ((uint)-iVar45 < uVar27) {
          *(undefined8 *)(puVar33 + -8) = 0x1084ee;
          uVar27 = func_0x(psVar43);
        }
        else {
          *(undefined8 *)(puVar33 + -8) = 0x1084fb;
          iVar45 = func_0x(lVar38);
          uVar27 = -iVar45;
        }
        uVar44 = (ulonglong)uVar27;
        *puVar1 = uVar27;
        *(undefined8 *)(puVar33 + -8) = 0x10850e;
        iVar45 = func_0x(&stack0x00000038 + lVar12);
        if (iVar45 != 0) {
          *(undefined8 *)(puVar33 + -8) = 0x10852c;
          cVar3 = func_0x
                            (&stack0x000000b8 + lVar12,&stack0x000001c0 + lVar12,
                             &stack0x000000ac + lVar12);
          if (cVar3 != '\0') {
            uVar42 = *(undefined4 *)(&stack0x000000ac + lVar12);
            uVar17 = *(undefined8 *)(&stack0x000001c0 + lVar12);
            *(undefined8 *)(puVar33 + -8) = 0x108546;
            uVar35 = func_0x(uVar17,uVar42,&stack0x00000038 + lVar12);
            if (uVar27 <= uVar35) {
              uVar42 = *(undefined4 *)(&stack0x000000ac + lVar12);
              uVar17 = *(undefined8 *)(&stack0x000001c0 + lVar12);
              *(undefined8 *)(puVar33 + -8) = 0x108561;
              uVar27 = func_0x(uVar17,uVar42,&stack0x00000038 + lVar12);
              uVar44 = (ulonglong)uVar27;
              *puVar1 = uVar27;
            }
          }
        }
        *(undefined8 *)(puVar33 + -8) = 0x10856f;
        uVar27 = func_0x(lVar38);
        *(undefined8 *)(puVar33 + -8) = 0x10857a;
        uVar42 = func_0x(lVar38);
        sVar6 = *psVar43;
        **(short **)(&stack0x00000078 + lVar12) = sVar6;
        uVar17 = *(undefined8 *)(&stack0x00000070 + lVar12);
        if (sVar6 == 0) {
          *(undefined8 *)(puVar47 + 3) = uVar17;
          *(undefined4 *)(puVar47 + 7) = uVar42;
          uVar35 = 0;
          puVar47[0xd] = 0;
          *puVar47 = 0;
          *(undefined4 *)(puVar47 + 0x12) = 0;
          *(undefined8 *)(puVar33 + -8) = 0x1085ae;
          cVar3 = func_0x(puVar46);
          if (cVar3 == '\x06') {
            *(undefined8 *)(puVar33 + -8) = 0x1085ba;
            puVar19 = (undefined *)func_0x(puVar47);
            *puVar19 = 6;
            uVar36 = 1;
          }
          else {
            *(undefined8 *)(puVar33 + -8) = 0x1085c7;
            puVar19 = (undefined *)func_0x(puVar47);
            *puVar19 = 0;
            *(undefined *)(*(longlong *)(puVar47 + 3) + 1) = 0;
            uVar42 = *(undefined4 *)(puVar47 + 7);
            *(undefined8 *)(puVar33 + -8) = 0x1085db;
            func_0x(puVar47,uVar42);
            uVar36 = 4;
          }
          uVar41 = *(uint *)(puVar46 + 7);
          if (*(uint *)(puVar47 + 7) <= uVar41) {
            uVar41 = *(uint *)(puVar47 + 7);
          }
          lVar38 = *(longlong *)(puVar46 + 3);
          lVar15 = *(longlong *)(puVar47 + 3);
          *(undefined8 *)(puVar33 + -8) = 0x108605;
          func_0x
                    (lVar15 + (ulonglong)uVar36,lVar38 + (ulonglong)uVar36,uVar41 - uVar36);
          if (uVar27 == 0) {
            uVar42 = *(undefined4 *)(puVar47 + 7);
            *(undefined4 *)(puVar47 + 9) = uVar42;
            *(undefined4 *)(puVar47 + 0xb) = uVar42;
            *(undefined4 *)(puVar47 + 1) = uVar42;
          }
          else {
            *(undefined8 *)(puVar33 + -8) = 0x108616;
            pbVar20 = (byte *)func_0x(puVar47);
            *pbVar20 = *pbVar20 | 0x10;
            *(uint *)(puVar47 + 9) = (uVar27 + 7 >> 3) + *(int *)(puVar47 + 7) + 2;
            *(undefined8 *)(puVar33 + -8) = 0x108633;
            pbVar20 = (byte *)func_0x(puVar46);
            if ((*pbVar20 & 0x10) == 0) {
              *(undefined8 *)(puVar33 + -8) = 0x1086d9;
              func_0x(&stack0x000002b0 + lVar12);
              *(short *)((ulonglong)*(uint *)(puVar47 + 7) + *(longlong *)(puVar47 + 3)) =
                   (short)uVar27;
            }
            else {
              lVar38 = *(longlong *)(puVar46 + 3);
              uVar7 = *(ushort *)((ulonglong)*(uint *)(puVar46 + 7) + lVar38);
              uVar35 = (uint)uVar7;
              if (uVar7 == uVar27) {
                uVar27 = *(uint *)(puVar47 + 7);
                iVar45 = *(int *)(puVar47 + 9);
                uVar35 = *(uint *)(puVar46 + 7);
                lVar15 = *(longlong *)(puVar47 + 3);
                *(undefined8 *)(puVar33 + -8) = 0x108665;
                func_0x
                          ((ulonglong)uVar27 + lVar15,(ulonglong)uVar35 + lVar38,iVar45 - uVar27);
                *(undefined4 *)(puVar47 + 0xb) = *(undefined4 *)(puVar47 + 9);
                *(undefined4 *)(puVar47 + 1) = *(undefined4 *)(puVar47 + 9);
                goto LAB_;
              }
              *(undefined8 *)(puVar33 + -8) = 0x108681;
              func_0x(&stack0x000002b0 + lVar12);
              *(short *)((ulonglong)*(uint *)(puVar47 + 7) + *(longlong *)(puVar47 + 3)) =
                   (short)uVar27;
              if (uVar7 != 0) {
                uVar36 = *(uint *)(puVar46 + 7);
                uVar25 = *(int *)(puVar46 + 9) - uVar36;
                uVar41 = *(uint *)(puVar47 + 7);
                uVar26 = *(int *)(puVar47 + 9) - uVar41;
                if (uVar25 <= uVar26) {
                  uVar26 = uVar25;
                }
                lVar38 = *(longlong *)(puVar46 + 3);
                lVar15 = *(longlong *)(puVar47 + 3);
                *(undefined8 *)(puVar33 + -8) = 0x1086cb;
                func_0x
                          (lVar15 + (ulonglong)uVar41 + 2,(ulonglong)uVar36 + lVar38 + 2,uVar26 - 2)
                ;
              }
            }
            if (uVar27 < uVar35) {
              uVar35 = uVar27 & 0xffff;
            }
            uVar7 = (ushort)uVar35;
            while (uVar7 = uVar7 + 1, uVar7 <= uVar27) {
              *(undefined8 *)(puVar33 + -8) = 0x10870f;
              func_0x(&stack0x000002b0 + lVar12,uVar7);
              *(undefined8 *)(puVar33 + -8) = 0x10871e;
              func_0x(puVar47,&stack0x000002b0 + lVar12);
            }
            *(undefined4 *)(puVar47 + 0xb) = *(undefined4 *)(puVar47 + 9);
            *(undefined4 *)(puVar47 + 1) = *(undefined4 *)(puVar47 + 9);
          }
        }
        else {
          *(uint *)(puVar33 + 0x20) = uVar27;
          uVar42 = *(undefined4 *)(&stack0x00000080 + lVar12);
          *(undefined8 *)(puVar33 + -8) = 0x10875a;
          func_0x(puVar47,uVar17,uVar42,puVar46);
        }
LAB_:
        if ((int)uVar44 == 0) {
          puVar19 = *(undefined **)((longlong)&puStackX_20 + lVar12);
        }
        else {
          uVar39 = uVar44 * 0x20 + 0xf;
          if (uVar39 <= uVar44 * 0x20) {
            uVar39 = 0xffffffffffffff0;
          }
          uVar39 = uVar39 & 0xfffffffffffffff0;
          *(undefined8 *)(puVar33 + -8) = 0x10878c;
          func_0x();
          lVar38 = -uVar39;
          puVar19 = puVar33 + lVar38 + 0x50;
          *(undefined **)((longlong)&puStackX_20 + lVar12) = puVar19;
          if (*psVar43 == 0) {
            if (*(int *)(puVar46 + 1) == 0) {
              iVar45 = 0;
              *puVar46 = 0;
              *(undefined4 *)(puVar46 + 9) = *(undefined4 *)(puVar46 + 7);
              *(undefined8 *)(puVar33 + lVar38 + -8) = 0x1087c1;
              pbVar20 = (byte *)func_0x(puVar46);
              if ((*pbVar20 & 0x10) != 0) {
                *(undefined8 *)(puVar33 + lVar38 + -8) = 0x1087ce;
                pbVar20 = (byte *)func_0x(puVar46);
                if ((*pbVar20 & 0x10) == 0) {
                  uVar27 = 0;
                }
                else {
                  uVar27 = (uint)*(ushort *)
                                  ((ulonglong)*(uint *)(puVar46 + 7) + *(longlong *)(puVar46 + 3));
                }
                *(uint *)(puVar46 + 9) = *(int *)(puVar46 + 9) + (uVar27 + 7 >> 3) + 2;
              }
              *(undefined8 *)(puVar33 + lVar38 + -8) = 0x1087f6;
              pbVar20 = (byte *)func_0x(puVar46);
              if ((*pbVar20 & 0x20) == 0) {
                *(undefined4 *)(puVar46 + 1) = *(undefined4 *)(puVar46 + 9);
                puVar46[0xd] = 0;
                *(undefined4 *)(puVar46 + 0xb) = *(undefined4 *)(puVar46 + 9);
              }
              else {
                *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108807;
                puVar21 = (ushort *)func_0x(puVar46);
                uVar7 = *puVar21;
                puVar46[0xd] = uVar7;
                if (uVar7 == 0) {
                  *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108822;
                  cVar3 = func_0x(0x112fe00);
                  if (cVar3 != '\0') {
                    *(undefined8 *)(puVar33 + lVar38 + -8) = 0x10882b;
                    cVar3 = func_0x();
                    if (cVar3 != '\0') {
                      *(undefined8 *)(puVar33 + lVar38 + -8) = 0x10883b;
                      cVar3 = func_0x(0x112fe00);
                      if (cVar3 == '\0') {
                        *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108857;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar33 + lVar38 + 0x20) = 0;
                        *(undefined8 *)(puVar33 + lVar38 + -8) = 0x10887d;
                        (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x80f);
                      }
                    }
                  }
                  uVar17 = *(undefined8 *)(puVar46 + 3);
                  *(undefined8 *)(puVar33 + lVar38 + -8) = 0x10888b;
                  func_0x(uVar17,3);
                  uVar7 = puVar46[0xd];
                }
                uVar27 = *(int *)(puVar46 + 9) + (uVar7 + 1) * 2;
                *(uint *)(puVar46 + 0xb) = uVar27;
                if (0x1f9e < uVar27) {
                  *(undefined8 *)(puVar33 + lVar38 + -8) = 0x1088b2;
                  cVar3 = func_0x(0x112fe00);
                  if (cVar3 != '\0') {
                    *(undefined8 *)(puVar33 + lVar38 + -8) = 0x1088bb;
                    cVar3 = func_0x();
                    if (cVar3 != '\0') {
                      *(undefined8 *)(puVar33 + lVar38 + -8) = 0x1088cb;
                      cVar3 = func_0x(0x112fe00);
                      if (cVar3 == '\0') {
                        *(undefined8 *)(puVar33 + lVar38 + -8) = 0x1088e7;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar33 + lVar38 + 0x20) = 0;
                        *(undefined8 *)(puVar33 + lVar38 + -8) = 0x10890d;
                        (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x816);
                      }
                    }
                  }
                  uVar17 = *(undefined8 *)(puVar46 + 3);
                  *(undefined8 *)(puVar33 + lVar38 + -8) = 0x10891b;
                  func_0x(uVar17,4);
                  uVar7 = puVar46[0xd];
                }
                puVar21 = puVar21 + 1;
                *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108931;
                uVar7 = func_0x(puVar21,(ulonglong)uVar7 - 1);
                *(uint *)(puVar46 + 1) = (uint)uVar7;
                uVar27 = *(uint *)(puVar46 + 0xb);
                if (uVar7 < uVar27) {
                  *(undefined8 *)(puVar33 + lVar38 + -8) = 0x10894c;
                  cVar3 = func_0x(0x112fe00);
                  if (cVar3 != '\0') {
                    *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108955;
                    cVar3 = func_0x();
                    if (cVar3 != '\0') {
                      *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108965;
                      cVar3 = func_0x(0x112fe00);
                      if (cVar3 == '\0') {
                        *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108981;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar33 + lVar38 + 0x20) = 0;
                        *(undefined8 *)(puVar33 + lVar38 + -8) = 0x1089a7;
                        (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x81d);
                      }
                    }
                  }
                  uVar17 = *(undefined8 *)(puVar46 + 3);
                  *(undefined8 *)(puVar33 + lVar38 + -8) = 0x1089b5;
                  func_0x(uVar17,4);
                  uVar27 = *(uint *)(puVar46 + 0xb);
                }
                uVar7 = puVar46[0xd];
                if (uVar7 != 0) {
                  do {
                    *(undefined8 *)(puVar33 + lVar38 + -8) = 0x1089db;
                    uVar7 = func_0x(puVar21,(longlong)iVar45);
                    bVar48 = uVar7 < uVar27;
                    uVar27 = (uint)uVar7;
                    if ((bVar48) ||
                       (*(uint *)(puVar46 + 1) <= (uint)uVar7 && uVar27 != *(uint *)(puVar46 + 1)))
                    {
                      *(undefined8 *)(puVar33 + lVar38 + -8) = 0x1089f6;
                      cVar3 = func_0x(0x112fe00);
                      if (cVar3 != '\0') {
                        *(undefined8 *)(puVar33 + lVar38 + -8) = 0x1089ff;
                        cVar3 = func_0x();
                        if (cVar3 != '\0') {
                          *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108a0f;
                          cVar3 = func_0x(0x112fe00);
                          if (cVar3 == '\0') {
                            *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108a2b;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar33 + lVar38 + 0x20) = 0;
                            *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108a4f;
                            (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x82a);
                          }
                        }
                      }
                      uVar17 = *(undefined8 *)(puVar46 + 3);
                      *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108a5d;
                      func_0x(uVar17,4);
                    }
                    iVar45 = iVar45 + 1;
                    uVar7 = puVar46[0xd];
                  } while (iVar45 < (int)(uint)uVar7);
                  puVar47 = *(ushort **)(&stack0x00000028 + lVar12);
                  uVar44 = (ulonglong)*puVar1;
                }
                *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108a83;
                iVar45 = func_0x(puVar21,uVar7 - 1);
                while (iVar45 != 0) {
                  uVar7 = puVar46[0xd];
                  *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108a9c;
                  lVar15 = func_0x(puVar46);
                  if (uVar7 == 1) {
                    uVar39 = (ulonglong)*(uint *)(puVar46 + 0xb);
                  }
                  else {
                    *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108ab9;
                    uVar8 = func_0x(lVar15 + 2,(ulonglong)uVar7 - 2);
                    uVar39 = (ulonglong)uVar8;
                  }
                  *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108ac9;
                  uVar7 = func_0x(lVar15 + 2,(ulonglong)(uint)uVar7 - 1);
                  uVar27 = *(uint *)(puVar46 + 0xb);
                  uVar35 = (uint)uVar39;
                  if (((uVar35 < uVar27) || (uVar7 < uVar35)) ||
                     (*(uint *)(puVar46 + 1) <= (uint)uVar7 && (uint)uVar7 != *(uint *)(puVar46 + 1)
                     )) {
                    uVar17 = *(undefined8 *)(puVar46 + 3);
                    *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108aed;
                    func_0x(uVar17,7);
                    uVar27 = *(uint *)(puVar46 + 0xb);
                  }
                  if ((uVar35 < uVar27) || (*(uint *)(puVar46 + 1) < uVar35)) goto LAB_;
                  if (*(ushort *)(uVar39 + *(longlong *)(puVar46 + 3)) == 5) {
                    *puVar46 = *puVar46 | 2;
                    puVar46[0xd] = puVar46[0xd] - 1;
                    puVar46[0x14] = (ushort)uVar39;
                    lVar15 = (uVar39 & 0xffff) + *(longlong *)(puVar46 + 3);
                    *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108bbb;
                    iVar45 = func_0x(lVar15);
                    if (iVar45 == 0) {
                      puVar46[0x15] = puVar46[0x15] & 0xc7ff;
                    }
                    else {
                      *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108bc7;
                      uVar8 = func_0x(lVar15);
                      puVar46[0x15] = puVar46[0x15] & 0xc7ff;
                      puVar46[0x15] = puVar46[0x15] | (uVar8 & 7) << 0xb;
                    }
                    *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108bef;
                    uVar8 = func_0x(lVar15);
                    puVar46[0x15] = puVar46[0x15] ^ (uVar8 ^ puVar46[0x15]) & 0x7ff;
                    uVar9 = puVar46[0x15];
                    uVar30 = *(ulonglong *)(puVar46 + 3);
                    uVar8 = puVar46[0x14];
                    uVar32 = (ulonglong)((uVar9 & 0x7ff) * 2) + 4 + uVar30 + (uVar9 >> 0xb & 7) * 2
                             + (ulonglong)uVar8;
                    uVar39 = uVar30 + uVar8;
                    if (uVar32 < uVar39) {
                      *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108c45;
                      func_0x(uVar39,0x19);
                      uVar9 = puVar46[0x15];
                      uVar8 = puVar46[0x14];
                      uVar30 = (ulonglong)*(uint *)(puVar46 + 3);
                    }
                    if (uVar7 - uVar35 <
                        (((uVar9 & 0x7ff) * 2 - (uint)uVar8) - (int)uVar30) + (int)uVar32) {
                      uVar7 = puVar46[0x14];
                      lVar15 = *(longlong *)(puVar46 + 3);
                      *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108c81;
                      func_0x((ulonglong)uVar7 + lVar15,0x19);
                      uVar9 = puVar46[0x15];
                    }
                    if ((uVar9 & 0x3800) != 0) {
                      uVar7 = puVar46[0x14];
                      lVar15 = *(longlong *)(puVar46 + 3);
                      iVar45 = 0;
                      if ((uVar9 & 0x3800) != 0) {
                        do {
                          uVar8 = puVar46[0x15];
                          *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108cd0;
                          uVar9 = func_0x((ulonglong)uVar7 + lVar15 + 4,iVar45);
                          if ((uVar8 & 0x7ff) < uVar9) {
                            uVar8 = puVar46[0x14];
                            lVar16 = *(longlong *)(puVar46 + 3);
                            *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108cef;
                            func_0x((ulonglong)uVar8 + lVar16,0x1a);
                            uVar8 = puVar46[0x15];
                          }
                          iVar45 = iVar45 + 1;
                        } while (iVar45 < (int)(uVar8 >> 0xb & 7));
                      }
                    }
                    break;
                  }
                  if (*(ushort *)(uVar39 + *(longlong *)(puVar46 + 3)) < 0x400) break;
                  *puVar46 = *puVar46 | 1;
                  uVar7 = puVar46[0xd] - 1;
                  puVar46[0xd] = uVar7;
                  if (uVar7 == 0) break;
                  *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108b41;
                  iVar45 = func_0x(puVar21,uVar7 - 1);
                }
              }
              *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108b56;
              iVar45 = func_0x(puVar46);
              if (iVar45 == 0) {
                *(undefined4 *)(puVar46 + 0x12) = 0;
              }
              else {
                *(int *)(puVar46 + 0x12) = *(int *)(puVar46 + 1);
                *(int *)(puVar46 + 1) = *(int *)(puVar46 + 1) + 0xe;
                *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108b75;
                uVar17 = func_0x(puVar46);
                *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108b84;
                func_0x(uVar17,&stack0x00000288 + lVar12);
                *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108b90;
                iVar45 = func_0x(&stack0x00000288 + lVar12);
                *(int *)(puVar46 + 1) = *(int *)(puVar46 + 1) + iVar45;
              }
              uVar27 = *(uint *)(puVar46 + 1);
              if ((*(ulonglong *)(puVar46 + 0xe) != 0) &&
                 (*(ulonglong *)(puVar46 + 0xe) < (ulonglong)uVar27 + *(longlong *)(puVar46 + 3))) {
                *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108d48;
                cVar3 = func_0x(0x112fe00);
                if (cVar3 != '\0') {
                  *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108d51;
                  cVar3 = func_0x();
                  if (cVar3 != '\0') {
                    *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108d61;
                    cVar3 = func_0x(0x112fe00);
                    if (cVar3 == '\0') {
                      *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108d7d;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar33 + lVar38 + 0x20) = 0;
                      *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108da3;
                      (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x886);
                    }
                  }
                }
                uVar17 = *(undefined8 *)(puVar46 + 3);
                *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108db1;
                func_0x(uVar17,0x12);
                uVar27 = *(uint *)(puVar46 + 1);
              }
              if (0x3f3b < uVar27 - 1) {
                *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108dcd;
                cVar3 = func_0x(0x112fe00);
                if (cVar3 != '\0') {
                  *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108dd6;
                  cVar3 = func_0x();
                  if (cVar3 != '\0') {
                    *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108de6;
                    cVar3 = func_0x(0x112fe00);
                    if (cVar3 == '\0') {
                      *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108e02;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar33 + lVar38 + 0x20) = 0;
                      *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108e28;
                      (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x88b);
                    }
                  }
                }
                uVar17 = *(undefined8 *)(puVar46 + 3);
                *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108e36;
                func_0x(uVar17,5);
              }
            }
LAB_:
            uVar39 = (ulonglong)(uint)puVar46[0xd];
            if ((uint)uVar44 <= (uint)puVar46[0xd]) {
              uVar39 = uVar44;
            }
            *(int *)(&stack0x00000098 + lVar12) = (int)uVar39;
            if ((int)uVar39 != 0) {
              *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108e5a;
              lVar15 = func_0x(puVar46);
              uVar27 = *(uint *)(puVar46 + 0xb);
              *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108e6d;
              func_0x(&stack0x00000310 + lVar12);
              uVar44 = 0;
              uVar35 = *(uint *)(&stack0x00000098 + lVar12);
              do {
                *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108e8f;
                uVar7 = func_0x(lVar15 + 2,uVar44);
                uVar36 = (uint)uVar7;
                if ((uVar7 < uVar27) ||
                   (*(uint *)(puVar46 + 1) <= (uint)uVar7 && uVar36 != *(uint *)(puVar46 + 1))) {
                  uVar17 = *(undefined8 *)(puVar46 + 3);
                  *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108eac;
                  func_0x(uVar17,7);
                }
                *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108eb8;
                iVar45 = func_0x(lVar15 + 2,uVar44);
                lVar16 = *(longlong *)(puVar46 + 3);
                lVar18 = *(longlong *)((longlong)&puStackX_20 + lVar12);
                *(undefined4 *)(puVar33 + lVar38 + 0x28) = 0;
                *(undefined **)(puVar33 + lVar38 + 0x20) = &stack0x00000310 + lVar12;
                *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108ef0;
                func_0x
                          (uVar44 * 0x20 + lVar18,(ulonglong)uVar27 + lVar16,uVar36 - uVar27,
                           iVar45 != 0);
                uVar41 = (int)uVar44 + 1;
                uVar44 = (ulonglong)uVar41;
                uVar27 = uVar36;
              } while (uVar41 < uVar35);
              puVar47 = *(ushort **)(&stack0x00000028 + lVar12);
              uVar44 = (ulonglong)*puVar1;
              uVar39 = (ulonglong)*(uint *)(&stack0x00000098 + lVar12);
            }
            puVar19 = *(undefined **)((longlong)&puStackX_20 + lVar12);
            *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108f25;
            func_0x(puVar19 + uVar39 * 0x20,0,((int)uVar44 - (int)uVar39) * 0x20);
            puVar33 = puVar33 + lVar38;
          }
          else {
            *(undefined8 *)(puVar33 + lVar38 + -8) = 0x108f3b;
            func_0x(puVar46,puVar19,uVar44);
            puVar33 = puVar33 + lVar38;
          }
        }
        lVar38 = *(longlong *)(&stack0x000001c0 + lVar12);
        if (lVar38 != 0) {
          *(int *)(puVar33 + 0x28) = (int)uVar44;
          *(undefined **)(puVar33 + 0x20) = puVar19;
          uVar17 = *(undefined8 *)(&stack0x00000078 + lVar12);
          uVar42 = *(undefined4 *)(&stack0x000000ac + lVar12);
          *(undefined8 *)(puVar33 + -8) = 0x108f6a;
          func_0x(lVar38,uVar42,&stack0x00000038 + lVar12,uVar17);
        }
        *(undefined8 *)(puVar33 + -8) = 0x108f76;
        uVar17 = func_0x(&stack0x000000b8 + lVar12);
        *(undefined8 *)(puVar33 + -8) = 0x108f7e;
        uVar7 = func_0x(uVar17);
        *(undefined8 *)(&stack0x00000128 + lVar12) = 0;
        *(undefined8 *)(puVar33 + -8) = 0x108f97;
        lVar38 = func_0x(&stack0x000000b8 + lVar12);
        if (uVar7 != 0) {
          uVar44 = (ulonglong)uVar7;
          do {
            *(undefined8 *)(puVar33 + -8) = 0x108fad;
            uVar17 = func_0x(lVar38);
            *(undefined8 *)(puVar33 + -8) = 0x108fb8;
            iVar45 = func_0x(lVar38);
            *(undefined8 *)(puVar33 + -8) = 0x108fce;
            func_0x(&stack0x000000b8 + lVar12,lVar38,&stack0x00000091 + lVar12);
            if ((&stack0x00000091)[lVar12] == '\x03') {
              *(undefined8 *)(puVar33 + -8) = 0x10930d;
              iVar34 = func_0x(lVar38);
              if (iVar34 == 0) {
                *(undefined8 *)(puVar33 + -8) = 0x109319;
                iVar34 = func_0x(lVar38);
                if (iVar34 == 0) {
                  *(undefined8 *)(puVar33 + -8) = 0x109331;
                  (*_DAT_)(6,0x51,0x10,3);
                }
              }
              uVar22 = *(undefined8 *)(&stack0x00000078 + lVar12);
              *(undefined8 *)(puVar33 + -8) = 0x109343;
              func_0x(uVar22,uVar17,0,0);
              if (iVar45 < 0) {
                *(uint *)(puVar19 + (longlong)-iVar45 * 0x20 + -0x14) =
                     *(uint *)(puVar19 + (longlong)-iVar45 * 0x20 + -0x14) | 2;
              }
            }
            else {
              *(undefined8 *)(puVar33 + -8) = 0x108fe0;
              sVar6 = func_0x(uVar17);
              psVar43 = *(short **)(&stack0x00000078 + lVar12);
              if (sVar6 != 0) {
                if (*psVar43 == 0) {
                  *(undefined8 *)(puVar33 + -8) = 0x108ffa;
                  func_0x();
                }
                else {
                  *(undefined8 *)(puVar33 + -8) = 0x109001;
                  func_0x(puVar47,uVar17);
                }
              }
              *(undefined8 *)(puVar33 + -8) = 0x109017;
              func_0x(&stack0x000000b8 + lVar12,lVar38,&stack0x00000128 + lVar12);
              *(undefined8 *)(puVar33 + -8) = 0x10901f;
              iVar34 = func_0x(lVar38);
              if ((iVar34 == 1) || (iVar34 == 2)) {
                lVar15 = *(longlong *)(&stack0x00000128 + lVar12);
                *(undefined8 *)(puVar33 + -8) = 0x1091c9;
                iVar45 = func_0x(lVar38);
                if (iVar45 == 0) {
                  *(undefined8 *)(puVar33 + -8) = 0x1091d5;
                  uVar10 = func_0x();
                  *(undefined8 *)(puVar33 + -8) = 0x1091e0;
                  uVar17 = func_0x(lVar38);
                  *(undefined8 *)(puVar33 + -8) = 0x1091e8;
                  iVar45 = func_0x(uVar17);
                  lVar16 = *(longlong *)(*(longlong *)(&stack0x00000088 + lVar12) + 0x10);
                  *(undefined8 *)(puVar33 + -8) = 0x109201;
                  func_0x(iVar45 + lVar16,lVar15,uVar10);
                }
                else {
                  iVar34 = 0;
                  *(undefined8 *)(puVar33 + -8) = 0x10920e;
                  iVar45 = func_0x(lVar38);
                  if ((iVar45 == 0) || (((&stack0x000000cc)[lVar12] & 8) == 0)) {
                    *(undefined8 *)(puVar33 + -8) = 0x109239;
                    iVar45 = func_0x(lVar38);
                    if (iVar45 == 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x10926b;
                      uVar7 = func_0x(lVar38);
                      uVar27 = (uint)uVar7;
                    }
                    else {
                      *(undefined8 *)(puVar33 + -8) = 0x109245;
                      uVar17 = func_0x();
                      *(undefined8 *)(puVar33 + -8) = 0x109257;
                      uVar22 = func_0x(&stack0x000000b8 + lVar12,lVar38);
                      *(undefined8 *)(puVar33 + -8) = 0x109262;
                      uVar27 = func_0x(uVar22,uVar17);
                    }
                  }
                  else {
                    *(undefined8 *)(puVar33 + -8) = 0x109223;
                    uVar27 = func_0x(lVar38);
                    uVar27 = *(uint *)(*(longlong *)(&stack0x000000f0 + lVar12) +
                                      (ulonglong)uVar27 * 8);
                  }
                  *(undefined8 *)(puVar33 + -8) = 0x109276;
                  uVar7 = func_0x(lVar38);
                  if (uVar27 < uVar7) {
                    *(undefined8 *)(puVar33 + -8) = 0x109285;
                    uVar7 = func_0x(lVar38);
                    iVar34 = uVar7 - uVar27;
                  }
                  else {
                    *(undefined8 *)(puVar33 + -8) = 0x109293;
                    uVar7 = func_0x(lVar38);
                    if (uVar7 < uVar27) {
                      *(undefined8 *)(puVar33 + -8) = 0x1092b0;
                      (*_DAT_)(6,0x5c,0x16);
                    }
                  }
                  *(undefined8 *)(puVar33 + -8) = 0x1092b8;
                  uVar5 = func_0x(lVar38);
                  (&stack0x00000092)[lVar12] = uVar5;
                  *(undefined8 *)(puVar33 + -8) = 0x1092c3;
                  uVar17 = func_0x(lVar38);
                  *(undefined8 *)(puVar33 + -8) = 0x1092cb;
                  iVar45 = func_0x(uVar17);
                  lVar16 = (longlong)iVar45 +
                           *(longlong *)(*(longlong *)(&stack0x00000088 + lVar12) + 0x10);
                  if ((lVar15 != 0) && (uVar27 != 0)) {
                    *(undefined8 *)(puVar33 + -8) = 0x1092ed;
                    func_0x(lVar16,lVar15,uVar27);
                  }
                  if (iVar34 != 0) {
                    uVar5 = (&stack0x00000092)[lVar12];
                    *(undefined8 *)(puVar33 + -8) = 0x109303;
                    func_0x((ulonglong)uVar27 + lVar16,uVar5,iVar34);
                  }
                }
              }
              else if ((iVar34 == 3) || (iVar34 == 4)) {
                *(undefined8 *)(puVar33 + -8) = 0x1090e3;
                iVar34 = func_0x(lVar38);
                if ((iVar34 == 0) || (**(int **)(&stack0x00000128 + lVar12) != 0)) {
                  *(undefined8 *)(puVar33 + -8) = 0x1090ff;
                  iVar34 = func_0x(lVar38);
                  if ((iVar34 == 0) || (((&stack0x000000cc)[lVar12] & 8) == 0)) {
                    *(undefined8 *)(puVar33 + -8) = 0x10912a;
                    iVar34 = func_0x(lVar38);
                    if (iVar34 == 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x10915c;
                      uVar7 = func_0x(lVar38);
                      uVar27 = (uint)uVar7;
                    }
                    else {
                      *(undefined8 *)(puVar33 + -8) = 0x109136;
                      uVar22 = func_0x();
                      *(undefined8 *)(puVar33 + -8) = 0x109148;
                      uVar23 = func_0x(&stack0x000000b8 + lVar12,lVar38);
                      *(undefined8 *)(puVar33 + -8) = 0x109153;
                      uVar27 = func_0x(uVar23,uVar22);
                    }
                  }
                  else {
                    *(undefined8 *)(puVar33 + -8) = 0x109114;
                    uVar27 = func_0x(lVar38);
                    uVar27 = *(uint *)(*(longlong *)(&stack0x000000f0 + lVar12) +
                                      (ulonglong)uVar27 * 8);
                  }
                }
                else {
                  uVar27 = 0;
                }
                *(undefined8 *)(puVar33 + -8) = 0x109167;
                uVar7 = func_0x(lVar38);
                if (uVar7 < uVar27) {
                  *(undefined8 *)(puVar33 + -8) = 0x109184;
                  (*_DAT_)(6,0x52,0x16);
                }
                *(undefined4 *)(puVar33 + 0x28) = 0;
                *(undefined8 *)(puVar33 + 0x20) = uVar17;
                uVar17 = *(undefined8 *)(&stack0x00000128 + lVar12);
                *(undefined8 *)(puVar33 + -8) = 0x1091b5;
                func_0x(puVar19 + (longlong)(-1 - iVar45) * 0x20,uVar17,uVar27);
              }
              else if (iVar34 == 8) {
                *(undefined8 *)(puVar33 + -8) = 0x109082;
                sVar6 = func_0x(psVar43);
                if (sVar6 == 0) {
                  uVar22 = *(undefined8 *)(&stack0x00000128 + lVar12);
                  *(undefined8 *)(puVar33 + -8) = 0x10909f;
                  func_0x(psVar43,uVar17,uVar22);
                }
                else {
                  *(undefined4 *)(puVar33 + 0x28) = 0;
                  *(undefined8 *)(puVar33 + 0x20) = uVar17;
                  uVar17 = *(undefined8 *)(&stack0x00000128 + lVar12);
                  *(undefined8 *)(puVar33 + -8) = 0x1090d6;
                  func_0x(puVar19 + (longlong)(-1 - iVar45) * 0x20,uVar17,1);
                }
              }
              else {
                *(undefined8 *)(puVar33 + 0x20) = 0x79ad70;
                *(undefined8 *)(puVar33 + -8) = 0x109075;
                (*_DAT_)(1,0xba1100,0xbcdac8);
              }
            }
            lVar38 = lVar38 + 0x50;
            uVar44 = uVar44 - 1;
            puVar19 = *(undefined **)((longlong)&puStackX_20 + lVar12);
          } while (uVar44 != 0);
          uVar44 = (ulonglong)*puVar1;
        }
        puVar46 = (ushort *)0x0;
        if ((int)uVar44 != 0) {
          if (**(short **)(&stack0x00000078 + lVar12) == 0) {
            *(undefined8 *)(&stack0x00000028 + lVar12) = 0;
            lVar38 = *(longlong *)((longlong)&puStackX_20 + lVar12);
LAB_:
            uVar27 = (uint)uVar44;
            uVar35 = uVar27 - 1;
            if (*(int *)((ulonglong)uVar35 * 0x20 + 8 + lVar38) == 0) goto code_r0x001093a4;
            puVar47[0xd] = (ushort)uVar44;
            iVar45 = *(int *)(puVar47 + 9) + 2 + uVar27 * 2;
            *(int *)(puVar47 + 0xb) = iVar45;
            *(int *)(puVar47 + 1) = iVar45;
            *(undefined8 *)(puVar33 + -8) = 0x1093cf;
            pbVar20 = (byte *)func_0x(puVar47);
            *pbVar20 = *pbVar20 | 0x20;
            uVar35 = *(uint *)(puVar47 + 1);
            uVar36 = *(uint *)(&stack0x00000080 + lVar12);
            puVar21 = puVar46;
            if (uVar35 <= uVar36) {
              *(undefined8 *)(puVar33 + -8) = 0x1093e6;
              puVar21 = (ushort *)func_0x(puVar47);
              *(ushort **)(&stack0x00000028 + lVar12) = puVar21;
              *puVar21 = (ushort)uVar44;
              uVar35 = *(uint *)(puVar47 + 1);
              uVar36 = *(uint *)(&stack0x00000080 + lVar12);
            }
            if (uVar27 != 0) {
              puVar31 = (uint *)(lVar38 + 0xc);
              do {
                uVar41 = *(uint *)(puVar47 + 1);
                lVar38 = *(longlong *)(puVar47 + 3);
                uVar26 = puVar31[-1];
                uVar35 = uVar41 + uVar26;
                *(uint *)(puVar47 + 1) = uVar35;
                if (uVar35 <= uVar36) {
                  uVar36 = *puVar31;
                  *(undefined8 *)(puVar33 + -8) = 0x10943f;
                  func_0x(puVar21 + 1,puVar46,uVar35,uVar36 & 1);
                  uVar17 = *(undefined8 *)(puVar31 + -3);
                  *(undefined8 *)(puVar33 + -8) = 0x109451;
                  func_0x((ulonglong)uVar41 + lVar38,uVar26,uVar17,uVar26);
                  uVar35 = *(uint *)(puVar47 + 1);
                  uVar36 = *(uint *)(&stack0x00000080 + lVar12);
                }
                uVar41 = (int)puVar46 + 1;
                puVar46 = (ushort *)(ulonglong)uVar41;
                puVar31 = puVar31 + 8;
                puVar21 = *(ushort **)(&stack0x00000028 + lVar12);
              } while (uVar41 < uVar27);
            }
            *(uint *)(&stack0x000001dc + lVar12) = uVar35;
            uVar27 = (uint)(*(uint *)(puVar47 + 1) <= uVar36);
            goto LAB_;
          }
          *(undefined **)(puVar33 + 0x28) = &stack0x000001dc + lVar12;
          *(undefined8 *)(puVar33 + 0x20) = *(undefined8 *)((longlong)&puStackX_20 + lVar12);
          uVar42 = *(undefined4 *)(&stack0x00000080 + lVar12);
          *(undefined8 *)(puVar33 + -8) = 0x1094a5;
          uVar27 = func_0x(puVar47,uVar42,uVar42,uVar44);
LAB_:
          *(undefined4 *)(&stack0x00000094 + lVar12) = 0;
          if (uVar27 == 0) goto LAB_;
        }
        *(undefined4 *)(&stack0x00000094 + lVar12) = 1;
      }
LAB_:
      if (*(int *)(&stack0x00000094 + lVar12) != 0) goto LAB_;
      uVar42 = 0xb7;
    }
    *(undefined8 *)(puVar33 + -8) = 0x104714;
    (*_DAT_)(6,0x52,0x16,uVar42);
  }
  else {
    *(undefined2 *)(&stack0x00000168 + lVar12) = 0xffff;
    *(undefined8 *)(&stack0x00000170 + lVar12) = 0;
    *(undefined4 *)(&stack0x0000016c + lVar12) = 0;
    *(undefined8 *)(&stack0x00000186 + lVar12) = 0;
    *(undefined8 *)(&stack0x00000190 + lVar12) = 0;
    *(undefined8 *)(puVar33 + -8) = 0x109504;
    func_0x(&stack0x0000016a + lVar12,0);
    sVar6 = *psVar43;
    *(short *)(&stack0x00000168 + lVar12) = sVar6;
    puVar47 = (ushort *)(lVar38 + 10);
    *(ushort **)(&stack0x00000028 + lVar12) = puVar47;
    if (sVar6 == 0) {
      uVar35 = *(uint *)(lVar38 + 0xc);
      if (uVar35 == 0) {
        *puVar47 = 0;
        *(undefined4 *)(lVar38 + 0x1c) = *(undefined4 *)(lVar38 + 0x18);
        *(undefined8 *)(puVar33 + -8) = 0x109545;
        pbVar20 = (byte *)func_0x(puVar47);
        if ((*pbVar20 & 0x10) != 0) {
          *(undefined8 *)(puVar33 + -8) = 0x109552;
          pbVar20 = (byte *)func_0x(puVar47);
          if ((*pbVar20 & 0x10) != 0) {
            uVar27 = (uint)*(ushort *)
                            ((ulonglong)*(uint *)(lVar38 + 0x18) + *(longlong *)(lVar38 + 0x10));
          }
          *(int *)(lVar38 + 0x1c) = *(int *)(lVar38 + 0x1c) + (uVar27 + 7 >> 3) + 2;
        }
        *(undefined8 *)(puVar33 + -8) = 0x10957f;
        pbVar20 = (byte *)func_0x(puVar47);
        if ((*pbVar20 & 0x20) == 0) {
          *(undefined4 *)(lVar38 + 0xc) = *(undefined4 *)(lVar38 + 0x1c);
          *(undefined2 *)(lVar38 + 0x24) = 0;
          *(undefined4 *)(lVar38 + 0x20) = *(undefined4 *)(lVar38 + 0x1c);
        }
        else {
          *(undefined8 *)(puVar33 + -8) = 0x109595;
          puVar46 = (ushort *)func_0x(puVar47);
          uVar7 = *puVar46;
          *(ushort *)(lVar38 + 0x24) = uVar7;
          if (uVar7 == 0) {
            *(undefined8 *)(puVar33 + -8) = 0x1095b2;
            cVar3 = func_0x(0x112fe00);
            if (cVar3 != '\0') {
              *(undefined8 *)(puVar33 + -8) = 0x1095bb;
              cVar3 = func_0x();
              if (cVar3 != '\0') {
                *(undefined8 *)(puVar33 + -8) = 0x1095cb;
                cVar3 = func_0x(0x112fe00);
                if (cVar3 == '\0') {
                  *(undefined8 *)(puVar33 + -8) = 0x1095e5;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar33 + 0x20) = 0;
                  *(undefined8 *)(puVar33 + -8) = 0x109608;
                  (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x80f);
                }
              }
            }
            uVar17 = *(undefined8 *)(lVar38 + 0x10);
            *(undefined8 *)(puVar33 + -8) = 0x109617;
            func_0x(uVar17,3);
            uVar7 = *(ushort *)(lVar38 + 0x24);
          }
          uVar27 = *(int *)(lVar38 + 0x1c) + 2 + (uint)uVar7 * 2;
          *(uint *)(lVar38 + 0x20) = uVar27;
          if (0x1f9e < uVar27) {
            *(undefined8 *)(puVar33 + -8) = 0x109644;
            cVar3 = func_0x(0x112fe00);
            if (cVar3 != '\0') {
              *(undefined8 *)(puVar33 + -8) = 0x10964d;
              cVar3 = func_0x();
              if (cVar3 != '\0') {
                *(undefined8 *)(puVar33 + -8) = 0x10965d;
                cVar3 = func_0x(0x112fe00);
                if (cVar3 == '\0') {
                  *(undefined8 *)(puVar33 + -8) = 0x109679;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar33 + 0x20) = 0;
                  *(undefined8 *)(puVar33 + -8) = 0x10969c;
                  (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x816);
                }
              }
            }
            uVar17 = *(undefined8 *)(lVar38 + 0x10);
            *(undefined8 *)(puVar33 + -8) = 0x1096ab;
            func_0x(uVar17,4);
            uVar7 = *(ushort *)(lVar38 + 0x24);
          }
          puVar46 = puVar46 + 1;
          *(undefined8 *)(puVar33 + -8) = 0x1096c3;
          uVar7 = func_0x(puVar46,(ulonglong)uVar7 - 1);
          *(uint *)(lVar38 + 0xc) = (uint)uVar7;
          uVar27 = *(uint *)(lVar38 + 0x20);
          if (uVar7 < uVar27) {
            *(undefined8 *)(puVar33 + -8) = 0x1096e1;
            cVar3 = func_0x(0x112fe00);
            if (cVar3 != '\0') {
              *(undefined8 *)(puVar33 + -8) = 0x1096ea;
              cVar3 = func_0x();
              if (cVar3 != '\0') {
                *(undefined8 *)(puVar33 + -8) = 0x1096fa;
                cVar3 = func_0x(0x112fe00);
                if (cVar3 == '\0') {
                  *(undefined8 *)(puVar33 + -8) = 0x109716;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar33 + 0x20) = 0;
                  *(undefined8 *)(puVar33 + -8) = 0x109739;
                  (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x81d);
                }
              }
            }
            uVar17 = *(undefined8 *)(lVar38 + 0x10);
            *(undefined8 *)(puVar33 + -8) = 0x109748;
            func_0x(uVar17,4);
            uVar27 = *(uint *)(lVar38 + 0x20);
          }
          uVar7 = *(ushort *)(lVar38 + 0x24);
          if (uVar7 != 0) {
            do {
              *(undefined8 *)(puVar33 + -8) = 0x10976f;
              uVar7 = func_0x(puVar46,(longlong)(int)uVar44);
              bVar48 = uVar7 < uVar27;
              uVar27 = (uint)uVar7;
              if ((bVar48) ||
                 (*(uint *)(lVar38 + 0xc) <= (uint)uVar7 && uVar27 != *(uint *)(lVar38 + 0xc))) {
                *(undefined8 *)(puVar33 + -8) = 0x10978a;
                cVar3 = func_0x(0x112fe00);
                if (cVar3 != '\0') {
                  *(undefined8 *)(puVar33 + -8) = 0x109793;
                  cVar3 = func_0x();
                  if (cVar3 != '\0') {
                    *(undefined8 *)(puVar33 + -8) = 0x1097a3;
                    cVar3 = func_0x(0x112fe00);
                    if (cVar3 == '\0') {
                      *(undefined8 *)(puVar33 + -8) = 0x1097bf;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar33 + 0x20) = 0;
                      *(undefined8 *)(puVar33 + -8) = 0x1097e3;
                      (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x82a);
                    }
                  }
                }
                uVar17 = *(undefined8 *)(lVar38 + 0x10);
                *(undefined8 *)(puVar33 + -8) = 0x1097f2;
                func_0x(uVar17,4);
              }
              uVar35 = (int)uVar44 + 1;
              uVar44 = (ulonglong)uVar35;
              uVar7 = *(ushort *)(lVar38 + 0x24);
            } while ((int)uVar35 < (int)(uint)uVar7);
            puVar47 = *(ushort **)(&stack0x00000028 + lVar12);
          }
          *(undefined8 *)(puVar33 + -8) = 0x10981d;
          iVar45 = func_0x(puVar46,uVar7 - 1);
          while (iVar45 != 0) {
            uVar7 = *(ushort *)(lVar38 + 0x24);
            *(undefined8 *)(puVar33 + -8) = 0x10983e;
            lVar15 = func_0x(puVar47);
            if (uVar7 == 1) {
              uVar27 = *(uint *)(lVar38 + 0x20);
            }
            else {
              *(undefined8 *)(puVar33 + -8) = 0x10985d;
              uVar8 = func_0x(lVar15 + 2,(ulonglong)uVar7 - 2);
              uVar27 = (uint)uVar8;
            }
            *(undefined8 *)(puVar33 + -8) = 0x10986d;
            uVar7 = func_0x(lVar15 + 2,(ulonglong)(uint)uVar7 - 1);
            uVar36 = *(uint *)(lVar38 + 0x20);
            if (((uVar27 < uVar36) || (uVar7 < uVar27)) ||
               (uVar35 = *(uint *)(lVar38 + 0xc), uVar35 <= uVar7 && uVar7 != uVar35)) {
              uVar17 = *(undefined8 *)(lVar38 + 0x10);
              *(undefined8 *)(puVar33 + -8) = 0x109896;
              func_0x(uVar17,7);
              uVar36 = *(uint *)(lVar38 + 0x20);
              uVar35 = *(uint *)(lVar38 + 0xc);
            }
            if ((uVar27 < uVar36) || (uVar35 < uVar27)) goto LAB_;
            uVar8 = *(ushort *)((ulonglong)uVar27 + *(longlong *)(lVar38 + 0x10));
            if (uVar8 == 5) {
              *puVar47 = *puVar47 | 2;
              *(short *)(lVar38 + 0x24) = *(short *)(lVar38 + 0x24) + -1;
              *(short *)(lVar38 + 0x32) = (short)uVar27;
              lVar15 = (ulonglong)(uVar27 & 0xffff) + *(longlong *)(lVar38 + 0x10);
              *(undefined8 *)(puVar33 + -8) = 0x109978;
              iVar45 = func_0x(lVar15);
              if (iVar45 == 0) {
                *(ushort *)(lVar38 + 0x34) = *(ushort *)(lVar38 + 0x34) & 0xc7ff;
              }
              else {
                *(undefined8 *)(puVar33 + -8) = 0x109984;
                uVar8 = func_0x(lVar15);
                *(ushort *)(lVar38 + 0x34) = *(ushort *)(lVar38 + 0x34) & 0xc7ff;
                *(ushort *)(lVar38 + 0x34) = *(ushort *)(lVar38 + 0x34) | (uVar8 & 7) << 0xb;
              }
              *(undefined8 *)(puVar33 + -8) = 0x1099b2;
              uVar8 = func_0x(lVar15);
              *(ushort *)(lVar38 + 0x34) =
                   *(ushort *)(lVar38 + 0x34) ^ (uVar8 ^ *(ushort *)(lVar38 + 0x34)) & 0x7ff;
              uVar9 = *(ushort *)(lVar38 + 0x34);
              uVar39 = *(ulonglong *)(lVar38 + 0x10);
              uVar8 = *(ushort *)(lVar38 + 0x32);
              uVar30 = uVar39 + 4 +
                       (ulonglong)((uVar9 & 0x7ff) * 2) +
                       (ulonglong)uVar8 + (ulonglong)((uVar9 >> 0xb & 7) * 2);
              uVar44 = uVar39 + uVar8;
              if (uVar30 < uVar44) {
                *(undefined8 *)(puVar33 + -8) = 0x109a0f;
                func_0x(uVar44,0x19);
                uVar9 = *(ushort *)(lVar38 + 0x34);
                uVar8 = *(ushort *)(lVar38 + 0x32);
                uVar39 = (ulonglong)*(uint *)(lVar38 + 0x10);
              }
              if (uVar7 - uVar27 < (((uVar9 & 0x7ff) * 2 - (uint)uVar8) - (int)uVar39) + (int)uVar30
                 ) {
                uVar7 = *(ushort *)(lVar38 + 0x32);
                lVar15 = *(longlong *)(lVar38 + 0x10);
                *(undefined8 *)(puVar33 + -8) = 0x109a50;
                func_0x((ulonglong)uVar7 + lVar15,0x19);
                uVar9 = *(ushort *)(lVar38 + 0x34);
              }
              iVar45 = 0;
              if (((uVar9 & 0x3800) != 0) &&
                 (uVar7 = *(ushort *)(lVar38 + 0x32), lVar15 = *(longlong *)(lVar38 + 0x10),
                 (uVar9 & 0x3800) != 0)) {
                do {
                  uVar8 = *(ushort *)(lVar38 + 0x34);
                  *(undefined8 *)(puVar33 + -8) = 0x109a94;
                  uVar9 = func_0x((ulonglong)uVar7 + lVar15 + 4,iVar45);
                  if ((uVar8 & 0x7ff) < uVar9) {
                    uVar8 = *(ushort *)(lVar38 + 0x32);
                    lVar16 = *(longlong *)(lVar38 + 0x10);
                    *(undefined8 *)(puVar33 + -8) = 0x109ab5;
                    func_0x((ulonglong)uVar8 + lVar16,0x1a);
                    uVar8 = *(ushort *)(lVar38 + 0x34);
                  }
                  iVar45 = iVar45 + 1;
                } while (iVar45 < (int)(uVar8 >> 0xb & 7));
              }
              break;
            }
            if (uVar8 < 0x400) break;
            *puVar47 = *puVar47 | 1;
            uVar7 = *(short *)(lVar38 + 0x24) - 1;
            *(ushort *)(lVar38 + 0x24) = uVar7;
            if (uVar7 == 0) break;
            *(undefined8 *)(puVar33 + -8) = 0x1098f5;
            iVar45 = func_0x(puVar46,uVar7 - 1);
          }
        }
        *(undefined8 *)(puVar33 + -8) = 0x10990c;
        iVar45 = func_0x(puVar47);
        if (iVar45 == 0) {
          *(undefined4 *)(lVar38 + 0x2e) = 0;
        }
        else {
          *(int *)(lVar38 + 0x2e) = *(int *)(lVar38 + 0xc);
          *(int *)(lVar38 + 0xc) = *(int *)(lVar38 + 0xc) + 0xe;
          *(undefined8 *)(puVar33 + -8) = 0x10992e;
          uVar17 = func_0x(puVar47);
          *(undefined8 *)(puVar33 + -8) = 0x10993d;
          func_0x(uVar17,&stack0x00000290 + lVar12);
          *(undefined8 *)(puVar33 + -8) = 0x109949;
          iVar45 = func_0x(&stack0x00000290 + lVar12);
          *(int *)(lVar38 + 0xc) = *(int *)(lVar38 + 0xc) + iVar45;
        }
        uVar35 = *(uint *)(lVar38 + 0xc);
        if ((*(ulonglong *)(lVar38 + 0x26) != 0) &&
           (*(ulonglong *)(lVar38 + 0x26) < (ulonglong)uVar35 + *(longlong *)(lVar38 + 0x10))) {
          *(undefined8 *)(puVar33 + -8) = 0x109b21;
          cVar3 = func_0x(0x112fe00);
          if (cVar3 != '\0') {
            *(undefined8 *)(puVar33 + -8) = 0x109b2a;
            cVar3 = func_0x();
            if (cVar3 != '\0') {
              *(undefined8 *)(puVar33 + -8) = 0x109b3a;
              cVar3 = func_0x(0x112fe00);
              if (cVar3 == '\0') {
                *(undefined8 *)(puVar33 + -8) = 0x109b56;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar33 + 0x20) = 0;
                *(undefined8 *)(puVar33 + -8) = 0x109b79;
                (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x886);
              }
            }
          }
          uVar17 = *(undefined8 *)(lVar38 + 0x10);
          *(undefined8 *)(puVar33 + -8) = 0x109b88;
          func_0x(uVar17,0x12);
          uVar35 = *(uint *)(lVar38 + 0xc);
        }
        if ((uVar35 == 0) || (0x3f3c < uVar35)) {
          *(undefined8 *)(puVar33 + -8) = 0x109ba7;
          cVar3 = func_0x(0x112fe00);
          if (cVar3 != '\0') {
            *(undefined8 *)(puVar33 + -8) = 0x109bb0;
            cVar3 = func_0x();
            if (cVar3 != '\0') {
              *(undefined8 *)(puVar33 + -8) = 0x109bc0;
              cVar3 = func_0x(0x112fe00);
              if (cVar3 == '\0') {
                *(undefined8 *)(puVar33 + -8) = 0x109bdc;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar33 + 0x20) = 0;
                *(undefined8 *)(puVar33 + -8) = 0x109bff;
                (*_DAT_)(1,0xa1f80c,0xb3f8f8,0x88b);
              }
            }
          }
          uVar17 = *(undefined8 *)(lVar38 + 0x10);
          *(undefined8 *)(puVar33 + -8) = 0x109c0e;
          func_0x(uVar17,5);
          uVar35 = *(uint *)(lVar38 + 0xc);
        }
      }
LAB_:
      iVar45 = 0;
      if (uVar35 < 9) {
        *(undefined8 *)(puVar33 + -8) = 0x109c21;
        cVar3 = func_0x(puVar47);
        if ((cVar3 == '\0') || (cVar3 == '\f')) {
          uVar35 = 9;
        }
        else {
          uVar35 = *(uint *)(lVar38 + 0xc);
        }
      }
      *(undefined4 *)(&stack0x00000178 + lVar12) = *(undefined4 *)(lVar38 + 0x18);
      *(ushort *)(&stack0x0000016a + lVar12) = *puVar47;
      *(undefined4 *)(&stack0x0000016c + lVar12) = *(undefined4 *)(lVar38 + 0xc);
      *(undefined2 *)(&stack0x00000184 + lVar12) = *(undefined2 *)(lVar38 + 0x24);
      *(undefined4 *)(&stack0x0000017c + lVar12) = *(undefined4 *)(lVar38 + 0x1c);
      *(undefined4 *)(&stack0x00000180 + lVar12) = *(undefined4 *)(lVar38 + 0x20);
      *(undefined4 *)(&stack0x0000018e + lVar12) = *(undefined4 *)(lVar38 + 0x2e);
      *(undefined8 *)(puVar33 + -8) = 0x109c8c;
      uVar17 = func_0x(puVar47);
      *(undefined8 *)(puVar33 + -8) = 0x109ca3;
      func_0x(&stack0x00004868 + lVar12,0x1f9e,uVar17,uVar35);
      *(undefined **)(&stack0x00000170 + lVar12) = &stack0x00004868 + lVar12;
      *(undefined8 *)(puVar33 + -8) = 0x109cbd;
      iVar34 = func_0x(&stack0x0000016a + lVar12);
      if (iVar34 != 0) {
        *(undefined8 *)(puVar33 + -8) = 0x109cd8;
        uVar7 = func_0x(&stack0x0000016a + lVar12,&stack0x000001e0 + lVar12);
        uVar27 = *(uint *)(&stack0x000001e0 + lVar12);
        *(ushort *)(&stack0x00000192 + lVar12) = uVar7;
        lVar15 = (ulonglong)uVar7 + *(longlong *)(&stack0x00000170 + lVar12);
        *(undefined8 *)(puVar33 + -8) = 0x109cf7;
        iVar34 = func_0x(lVar15);
        if (iVar34 == 0) {
          *(ushort *)(&stack0x00000194 + lVar12) = *(ushort *)(&stack0x00000194 + lVar12) & 0xc7ff;
        }
        else {
          *(undefined8 *)(puVar33 + -8) = 0x109d03;
          sVar6 = func_0x(lVar15);
          *(ushort *)(&stack0x00000194 + lVar12) =
               *(ushort *)(&stack0x00000194 + lVar12) ^
               (sVar6 << 0xb ^ *(ushort *)(&stack0x00000194 + lVar12)) & 0x3800;
        }
        *(undefined8 *)(puVar33 + -8) = 0x109d41;
        uVar8 = func_0x(lVar15);
        uVar7 = *(ushort *)(&stack0x00000194 + lVar12);
        uVar8 = (uVar8 ^ *(ushort *)(&stack0x00000194 + lVar12)) & 0x7ff ^ uVar7;
        uVar39 = (ulonglong)uVar8;
        *(ushort *)(&stack0x00000194 + lVar12) = uVar8;
        uVar30 = (ulonglong)*(ushort *)(&stack0x00000192 + lVar12);
        lVar15 = *(longlong *)(&stack0x00000170 + lVar12);
        uVar44 = (ulonglong)((uVar7 >> 0xb & 7) * 2) + lVar15 + ((uVar39 & 0x7ff) + 2) * 2 + uVar30;
        if (uVar44 < lVar15 + uVar30) {
          *(undefined8 *)(puVar33 + -8) = 0x109da9;
          func_0x(lVar15 + uVar30,0x19);
          uVar39 = (ulonglong)*(ushort *)(&stack0x00000194 + lVar12);
          uVar30 = (ulonglong)*(ushort *)(&stack0x00000192 + lVar12);
          lVar15 = *(longlong *)(&stack0x00000170 + lVar12);
        }
        if (uVar27 < (((*(uint *)(&stack0x00000194 + lVar12) & 0x7ff) * 2 - (int)uVar30) -
                     *(int *)(&stack0x00000170 + lVar12)) + (int)uVar44) {
          *(undefined8 *)(puVar33 + -8) = 0x109dee;
          func_0x(uVar30 + lVar15,0x19);
          uVar39 = (ulonglong)*(ushort *)(&stack0x00000194 + lVar12);
          uVar30 = (ulonglong)*(ushort *)(&stack0x00000192 + lVar12);
          lVar15 = *(longlong *)(&stack0x00000170 + lVar12);
        }
        if (((uVar39 & 0x3800) != 0) && ((uVar39 & 0x3800) != 0)) {
          do {
            *(undefined8 *)(puVar33 + -8) = 0x109e3b;
            uVar7 = func_0x(uVar30 + lVar15 + 4,iVar45);
            if ((*(ushort *)(&stack0x00000194 + lVar12) & 0x7ff) < uVar7) {
              uVar7 = *(ushort *)(&stack0x00000192 + lVar12);
              lVar16 = *(longlong *)(&stack0x00000170 + lVar12);
              *(undefined8 *)(puVar33 + -8) = 0x109e63;
              func_0x((ulonglong)uVar7 + lVar16,0x1a);
            }
            iVar45 = iVar45 + 1;
          } while (iVar45 < (int)(*(uint *)(&stack0x00000194 + lVar12) >> 0xb & 7));
        }
      }
    }
    else {
      if (*psVar43 != 0) {
        *(undefined8 *)(puVar33 + -8) = 0x109e8a;
        lVar15 = func_0x(puVar47);
        if (lVar15 != 0) {
          uVar39 = uVar44;
          if (*psVar43 != 0) {
            *(undefined8 *)(puVar33 + -8) = 0x109ea4;
            uVar39 = func_0x(puVar47);
          }
          *(undefined8 *)(puVar33 + -8) = 0x109eac;
          iVar45 = func_0x(uVar39);
          if (iVar45 != 0) {
            *(undefined8 *)(puVar33 + -8) = 0x109ecc;
            func_0x(&stack0x00000168 + lVar12,&stack0x00004868 + lVar12,0x1f9e,psVar43);
            goto LAB_;
          }
        }
      }
      *(undefined8 *)(puVar33 + -8) = 0x109eea;
      func_0x(&stack0x0000016a + lVar12,&stack0x00004868 + lVar12,0x1f9e,puVar47);
      if (*psVar43 != 0) {
        *(undefined8 *)(puVar33 + -8) = 0x109eff;
        uVar44 = func_0x(puVar47);
      }
      *(undefined8 *)(puVar33 + -8) = 0x109f0e;
      func_0x(&stack0x0000016a + lVar12,uVar44);
    }
LAB_:
    *(undefined8 *)(puVar33 + -8) = 0x109f21;
    func_0x(&stack0x00000320 + lVar12,&stack0x00000168 + lVar12);
    *(undefined8 *)(puVar33 + 0x40) = 0;
    *(undefined **)(puVar33 + 0x38) = &stack0x000002c0 + lVar12;
    uVar42 = *(undefined4 *)(&stack0x00000080 + lVar12);
    *(undefined4 *)(puVar33 + 0x30) = uVar42;
    *(undefined4 *)(puVar33 + 0x28) = uVar42;
    *(undefined8 *)(puVar33 + 0x20) = *(undefined8 *)(lVar38 + 0x10);
    *(undefined8 *)(puVar33 + -8) = 0x109f63;
    func_0x(&stack0x000003a8 + lVar12,&stack0x000000b8 + lVar12,2,lVar38 + 8);
  }
LAB_:
  *(undefined8 *)(puVar33 + -8) = 0x104722;
  func_0x(&stack0x000002d0 + lVar12);
  puVar19 = puVar33;
LAB_:
  uVar44 = *(ulonglong *)(&stack0x00006808 + lVar12);
  *(undefined8 *)(puVar19 + -8) = 0x109ffa;
  func_0x(uVar44 ^ (ulonglong)puVar1);
  return;
code_r0x00106d96:
  uVar27 = uVar35;
  if (uVar35 == 0) goto LAB_;
  goto LAB_;
code_r0x001093a4:
  uVar44 = (ulonglong)uVar35;
  if (uVar35 == 0) goto LAB_;
  goto LAB_;
}

