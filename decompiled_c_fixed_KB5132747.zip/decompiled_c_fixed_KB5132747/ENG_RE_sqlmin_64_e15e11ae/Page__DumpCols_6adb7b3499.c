
/* WARNING: Instruction at (ram,0x001065a0) overlaps instruction at (ram,0x0010659d)
    */
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong param_2,undefined8 param_3)

{
  byte *pbVar1;
  undefined uVar2;
  undefined4 uVar3;
  code *pcVar4;
  undefined8 *puVar5;
  ushort *puVar6;
  undefined4 *puVar7;
  uint6 uVar8;
  char cVar9;
  byte bVar10;
  byte bVar11;
  short sVar12;
  undefined2 uVar13;
  undefined4 uVar14;
  int iVar15;
  undefined4 uVar16;
  longlong lVar17;
  longlong lVar18;
  longlong *plVar19;
  short *psVar20;
  ulonglong uVar21;
  undefined8 uVar22;
  ulonglong *puVar23;
  int **ppiVar24;
  undefined4 *puVar25;
  ushort uVar26;
  int iVar27;
  ulonglong uVar28;
  uint *puVar29;
  ulonglong uVar30;
  int *piVar31;
  int *piVar32;
  uint uVar33;
  longlong lVar34;
  ushort *puVar35;
  byte *pbVar36;
  int *piVar37;
  undefined *puVar38;
  ushort uVar39;
  byte *pbVar40;
  undefined8 uVar41;
  uint uVar42;
  ulonglong uVar43;
  ushort uVar44;
  uint uVar45;
  uint uVar46;
  ulonglong uVar47;
  ulonglong uVar48;
  longlong unaff_GS_OFFSET;
  bool bVar49;
  float10 in_ST0;
  uint auStackX_8 [8];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar17 = func_0x();
  lVar17 = -lVar17;
  *(undefined8 *)(&stack0x00000218 + lVar17) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00008e78 + lVar17) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar17);
  *(longlong *)(&stack0x00000030 + lVar17) = param_2;
  *(undefined8 *)(&stack0x00000108 + lVar17) = param_1;
  *(undefined8 *)(&stack0x00000180 + lVar17) = param_1;
  *(undefined8 *)(&stack0x00000190 + lVar17) = param_1;
  *(longlong *)(&stack0x00000168 + lVar17) = param_2;
  *(undefined8 *)(&stack0x00000198 + lVar17) = param_3;
  uVar28 = 0;
  *(undefined8 *)(&stack0x00000048 + lVar17) = 0;
  lVar34 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar18 = *(longlong *)(lVar34 + 0x100);
  if (lVar18 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1000a7;
    (*_DAT_)(0);
    lVar18 = *(longlong *)(lVar34 + 0x100);
  }
  plVar19 = *(longlong **)(lVar18 + 1000);
  *(longlong **)(&stack0x000042a8 + lVar17) = plVar19;
  *(undefined4 *)(&stack0x000042b0 + lVar17) = 0;
  *(undefined4 *)(&stack0x000042b8 + lVar17) = 0;
  *(undefined4 *)(&stack0x000042bc + lVar17) = 0xffffffff;
  *(undefined8 *)(&stack0x000042c0 + lVar17) = 0;
  *(undefined4 *)(&stack0x000042c8 + lVar17) = _DAT_;
  *(undefined2 *)(&stack0x000042cc + lVar17) = _DAT_;
  *(undefined4 *)(&stack0x000042ce + lVar17) = 0;
  *(undefined2 *)(&stack0x000042d2 + lVar17) = 0;
  *(undefined8 *)(&stack0x000042d4 + lVar17) = 0;
  *(undefined (*) [16])(&stack0x000042e0 + lVar17) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x000042f0 + lVar17) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00004310 + lVar17) = ZEXT816(0);
  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100148;
  func_0x(&stack0x00004320 + lVar17);
  *(undefined2 *)(&stack0x000043a0 + lVar17) = 0xffff;
  *(undefined8 *)(&stack0x000043a8 + lVar17) = 0;
  *(undefined4 *)(&stack0x000043a4 + lVar17) = 0;
  *(undefined8 *)(&stack0x000043be + lVar17) = 0;
  *(undefined8 *)(&stack0x000043c8 + lVar17) = 0;
  *(undefined8 *)(&stack0x000043b0 + lVar17) = 0;
  *(undefined4 *)(&stack0x000043d4 + lVar17) = 0xffffffff;
  *(undefined8 *)(&stack0x00004450 + lVar17) = 0;
  *(undefined4 *)(&stack0x00004458 + lVar17) = 0;
  *(undefined4 *)(&stack0x00004460 + lVar17) = 0;
  *(undefined (*) [16])(&stack0x00004468 + lVar17) = ZEXT816(0);
  *(undefined4 *)(&stack0x00004478 + lVar17) = 0;
  pcVar4 = *(code **)(*plVar19 + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1001ba;
  (*pcVar4)(plVar19);
  if (param_2 == 0) {
    if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1001d3;
      lVar18 = func_0x();
      *(undefined8 *)(lVar18 + 0x110) = 0;
      if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1001f3;
        func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
      }
      *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
    }
    lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
    if (lVar18 != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100218;
      func_0x(lVar18);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100226;
      (*_DAT_)(lVar18,0xc0);
      *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
      *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
    }
    if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
      pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100250;
      (*pcVar4)();
      *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
      *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
    }
    puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
    if (puVar5 != (undefined8 *)0x0) {
      pcVar4 = *(code **)*puVar5;
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100275;
      (*pcVar4)(puVar5,1);
      *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
    }
    if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
      pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100290;
      (*pcVar4)();
      *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1002a5;
    func_0x(&stack0x00004320 + lVar17);
    goto LAB_;
  }
  pcVar4 = **(code ***)*_DAT_;
  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1002bc;
  plVar19 = (longlong *)(*pcVar4)();
  *(longlong **)(&stack0x00000118 + lVar17) = plVar19;
  *(longlong **)(&stack0x00000048 + lVar17) = plVar19;
  pcVar4 = *(code **)(*plVar19 + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1002e6;
  (*pcVar4)(plVar19,0x1388860,0x10);
  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar17) = 0;
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = _DAT_;
  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10030d;
  func_0x(&stack0x000002f8 + lVar17,0,0,0);
  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10032e;
  uVar14 = func_0x(&stack0x000042a8 + lVar17,*(undefined8 *)(&stack0x00000198 + lVar17),
                           &stack0x00000048 + lVar17,param_1);
  *(undefined4 *)(&stack0x00000120 + lVar17) = uVar14;
  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100342;
  func_0x(&stack0x000002f8 + lVar17);
  lVar34 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar18 = *(longlong *)(lVar34 + 0x100);
  if (lVar18 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1003a1;
    (*_DAT_)();
    lVar18 = *(longlong *)(lVar34 + 0x100);
  }
  if (*(int *)(lVar18 + 0x22c) != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1003b7;
    (*_DAT_)();
  }
  if (*(int *)(&stack0x00000120 + lVar17) == 0) {
    if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1003d5;
      lVar18 = func_0x();
      *(undefined8 *)(lVar18 + 0x110) = 0;
      if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1003f7;
        func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
      }
      *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
    }
    lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
    if (lVar18 != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10041c;
      func_0x(lVar18);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10042a;
      (*_DAT_)(lVar18,0xc0);
      *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
      *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
    }
    if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
      pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100454;
      (*pcVar4)();
      *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
      *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
    }
    puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
    if (puVar5 != (undefined8 *)0x0) {
      pcVar4 = *(code **)*puVar5;
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100479;
      (*pcVar4)(puVar5,1);
      *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
    }
    if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
      pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100494;
      (*pcVar4)();
      *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1004a9;
    func_0x(&stack0x00004320 + lVar17);
    if (plVar19 != (longlong *)0x0) {
      pcVar4 = *(code **)*plVar19;
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1004be;
      (*pcVar4)(plVar19,1);
    }
    goto LAB_;
  }
  lVar18 = *(longlong *)(&stack0x00000108 + lVar17);
  if (*(char *)(lVar18 + 2) < '\0') {
    *(undefined (*) [16])(&stack0x00004498 + lVar17) = ZEXT816(0);
    *(undefined2 *)(&stack0x000044a8 + lVar17) = 0xffff;
    *(undefined8 *)(&stack0x000044b0 + lVar17) = 0;
    *(undefined4 *)(&stack0x000044ac + lVar17) = 0;
    *(undefined8 *)(&stack0x000044c6 + lVar17) = 0;
    *(undefined8 *)(&stack0x000044d0 + lVar17) = 0;
    *(undefined8 *)(&stack0x000044b8 + lVar17) = 0;
    *(undefined8 *)(&stack0x000044e0 + lVar17) = 0;
    *(undefined8 *)(&stack0x000044f8 + lVar17) = 0;
    *(undefined4 *)(&stack0x00004500 + lVar17) = 0;
    *(undefined2 *)(&stack0x0000450a + lVar17) = 0;
    pbVar40 = (byte *)(lVar18 + 0x60);
    if (((((pbVar40 == (byte *)0x0) && (*(short *)(lVar18 + 0x30) == 0)) &&
         (*(int *)(lVar18 + 0x28) == 0)) &&
        ((*(int *)(lVar18 + 0x2c) == 0 &&
         (*(int *)(lVar18 + 0x20) == *(int *)(&stack0x00004504 + lVar17))))) &&
       (*(short *)(lVar18 + 0x24) == *(short *)(&stack0x00004508 + lVar17))) {
      *(undefined4 *)(&stack0x00000038 + lVar17) = 2;
      *(undefined4 *)(&stack0x0000002c + lVar17) = 9;
    }
    else {
      *(byte **)(&stack0x00004498 + lVar17) = pbVar40;
      uVar13 = *(undefined2 *)(lVar18 + 0x30);
      uVar14 = *(undefined4 *)(lVar18 + 0x2c);
      *(undefined4 *)(&stack0x000044f8 + lVar17) = *(undefined4 *)(lVar18 + 0x28);
      *(undefined4 *)(&stack0x000044fc + lVar17) = uVar14;
      *(undefined2 *)(&stack0x00004500 + lVar17) = uVar13;
      *(undefined4 *)(&stack0x00004504 + lVar17) = *(undefined4 *)(lVar18 + 0x20);
      *(undefined2 *)(&stack0x00004508 + lVar17) = *(undefined2 *)(lVar18 + 0x24);
      bVar10 = *pbVar40;
      *(undefined4 *)(&stack0x00000130 + lVar17) =
           *(undefined4 *)((ulonglong)bVar10 * 6 + 0x114b750);
      uVar48 = (ulonglong)*(short *)((ulonglong)bVar10 * 6 + 0x114b754);
      *(undefined8 *)(&stack0x000044e8 + lVar17) = 0;
      *(undefined2 *)(&stack0x000044f0 + lVar17) = 0;
      if ((bVar10 & 2) == 0) {
code_r0x001008ea:
        *(undefined4 *)(&stack0x00000038 + lVar17) = 2;
code_r0x001008f2:
        *(undefined4 *)(&stack0x0000002c + lVar17) = 9;
      }
      else {
        pbVar1 = pbVar40 + uVar48;
        bVar10 = *pbVar1;
        *(byte **)(&stack0x000044b0 + lVar17) = pbVar1;
        if ((bVar10 & 1) == 0) {
          *(undefined2 *)(&stack0x000044a8 + lVar17) = 0;
          *(undefined4 *)(&stack0x000044ce + lVar17) = 0;
          uVar45 = 0;
          switch(*pbVar1 & 0xe) {
          default:
            uVar26 = *(ushort *)(pbVar1 + 2);
            uVar45 = (uint)uVar26;
            if (0x1f9d < uVar26 - 1) {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100847;
              func_0x(pbVar1,6);
              uVar45 = (uint)uVar26;
            }
          case 6:
          case 10:
            *(undefined4 *)(&stack0x0000002c + lVar17) = 9;
            break;
          case 4:
            uVar45 = 9;
            *(undefined4 *)(&stack0x0000002c + lVar17) = 9;
            break;
          case 0xe:
            *(undefined4 *)(&stack0x0000002c + lVar17) = 9;
            *(undefined4 *)(&stack0x000044b8 + lVar17) = 1;
            *(undefined4 *)(&stack0x00000038 + lVar17) = 2;
            goto code_r0x001008fa;
          }
          *(uint *)(&stack0x000044b8 + lVar17) = uVar45;
          *(undefined4 *)(&stack0x00000038 + lVar17) = 2;
        }
        else {
          *(undefined2 *)(&stack0x000044a8 + lVar17) = 1;
          bVar10 = *pbVar1;
          switch(bVar10 & 0x1c) {
          default:
            if ((char)pbVar1[1] < '\0') {
              uVar26 = (*(ushort *)(pbVar1 + 1) & 0x7f) << 8 | *(ushort *)(pbVar1 + 1) >> 8;
              *(ushort *)(&stack0x000044aa + lVar17) = uVar26;
              uVar13 = 3;
              sVar12 = 3;
              *(undefined4 *)(&stack0x00000038 + lVar17) = 2;
            }
            else {
              uVar26 = (ushort)pbVar1[1];
              *(ushort *)(&stack0x000044aa + lVar17) = uVar26;
              uVar13 = 2;
              *(undefined4 *)(&stack0x00000038 + lVar17) = 2;
              sVar12 = 2;
            }
            *(undefined2 *)(&stack0x000044c0 + lVar17) = uVar13;
            *(short *)(&stack0x000044c4 + lVar17) = (short)(uVar26 + 1 >> 1) + sVar12;
            if (uVar26 < 0x1f) {
              *(undefined2 *)(&stack0x000044c2 + lVar17) = 0;
              *(undefined4 *)(&stack0x000044d8 + lVar17) = 0;
            }
            else {
              iVar15 = uVar26 - 1;
              *(short *)(&stack0x000044c2 + lVar17) =
                   ((short)(iVar15 / 0x1e) + (short)(iVar15 >> 0x1f)) -
                   (short)((longlong)iVar15 * 0x88888889 >> 0x3f);
              *(undefined4 *)(&stack0x000044d8 + lVar17) = 0;
            }
            goto code_r0x001008f2;
          case 4:
            if (((bVar10 & 0x1c) == 4) && ((bVar10 & 2) != 0)) {
              *(undefined4 *)(&stack0x000044c0 + lVar17) = 0;
              *(undefined2 *)(&stack0x000044aa + lVar17) = 0;
              *(undefined2 *)(&stack0x000044c4 + lVar17) = 0;
              *(undefined2 *)(&stack0x000044ce + lVar17) = 0;
              *(undefined4 *)(&stack0x000044ac + lVar17) = 0xf;
              *(undefined4 *)(&stack0x000044d8 + lVar17) = 1;
            }
            else {
              *(undefined4 *)(&stack0x000044c0 + lVar17) = 0;
              *(undefined2 *)(&stack0x000044aa + lVar17) = 0;
              *(undefined2 *)(&stack0x000044c4 + lVar17) = 0;
              *(undefined2 *)(&stack0x000044ce + lVar17) = 0;
              *(undefined4 *)(&stack0x000044ac + lVar17) = 1;
              *(undefined4 *)(&stack0x000044d8 + lVar17) = 0;
            }
            goto code_r0x001008ea;
          case 8:
            *(undefined4 *)(&stack0x000044c0 + lVar17) = 0;
            *(undefined2 *)(&stack0x000044aa + lVar17) = 0;
            *(undefined2 *)(&stack0x000044c4 + lVar17) = 0;
            *(undefined2 *)(&stack0x000044ce + lVar17) = 0;
            *(undefined4 *)(&stack0x0000002c + lVar17) = 9;
            *(undefined4 *)(&stack0x000044ac + lVar17) = 9;
            *(undefined4 *)(&stack0x000044d8 + lVar17) = 0;
            *(undefined4 *)(&stack0x00000038 + lVar17) = 2;
          }
        }
      }
code_r0x001008fa:
      if ((**(byte **)(&stack0x00004498 + lVar17) & 4) != 0) {
        if (*(short *)(&stack0x00000132 + lVar17) != 0) {
          uVar48 = (ulonglong)
                   *(ushort *)(lVar18 + 0x61 + (longlong)*(short *)(&stack0x00000132 + lVar17) * 2);
        }
        psVar20 = (short *)(pbVar40 + uVar48);
        *(short **)(&stack0x000044e0 + lVar17) = psVar20;
        sVar12 = *psVar20;
        *(short **)(&stack0x000044e8 + lVar17) = psVar20 + 1;
        *(short *)(&stack0x000044f0 + lVar17) = (sVar12 + 1) * 2;
      }
      if (*(longlong *)(&stack0x000044a0 + lVar17) != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100961;
        func_0x(*(longlong *)(&stack0x000044a0 + lVar17),&stack0x00004498 + lVar17);
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10097b;
    func_0x(&stack0x00004498 + lVar17,1,param_2);
    lVar18 = *(longlong *)(&stack0x00000108 + lVar17);
  }
  else {
    *(undefined4 *)(&stack0x00000038 + lVar17) = 2;
    *(undefined4 *)(&stack0x0000002c + lVar17) = 9;
  }
  *(undefined4 *)(&stack0x00000028 + lVar17) = 0;
  uVar26 = *(ushort *)(lVar18 + 0x16);
  if ((ulonglong)uVar26 != 0) {
    psVar20 = (short *)(lVar18 + 0x1ffe);
    uVar48 = uVar28;
    do {
      if (*psVar20 != 0) goto LAB_;
      uVar45 = (int)uVar48 + 1;
      uVar48 = (ulonglong)uVar45;
      *(uint *)(&stack0x00000028 + lVar17) = uVar45;
      uVar28 = uVar28 + 1;
      psVar20 = psVar20 + -1;
    } while ((longlong)uVar28 < (longlong)(ulonglong)uVar26);
  }
  uVar48 = 0xffffffff;
  *(undefined4 *)(&stack0x00000028 + lVar17) = 0xffffffff;
LAB_:
  *(int *)(&stack0x000000fc + lVar17) = (int)uVar48;
  while( true ) {
    uVar28 = 0;
    if ((int)uVar48 == -1) break;
    uVar45 = 0;
    *(undefined4 *)(&stack0x00000124 + lVar17) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1009fb;
    lVar34 = func_0x();
    if (lVar34 == 0) {
LAB_:
      *(undefined8 *)(&stack0xfffffffffffffff0 + lVar17) = 0;
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = _DAT_;
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100a56;
      func_0x(&stack0x00000278 + lVar17,0,0,0);
      *(undefined8 *)(&stack0x00000220 + lVar17) = _DAT_;
      lVar34 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar18 = *(longlong *)(lVar34 + 0x100);
      if (lVar18 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100a97;
        (*_DAT_)();
        lVar18 = *(longlong *)(lVar34 + 0x100);
      }
      uVar22 = *(undefined8 *)(lVar18 + 0xc88);
      *(undefined8 *)(&stack0x00000138 + lVar17) = uVar22;
      *(undefined8 *)(lVar18 + 0xc88) = _DAT_;
      *(undefined8 *)(&stack0x00000228 + lVar17) = uVar22;
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100adb;
      func_0x(&stack0x000042a8 + lVar17,*(undefined8 *)(&stack0x00000108 + lVar17),uVar48);
      lVar34 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar18 = *(longlong *)(lVar34 + 0x100);
      if (lVar18 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100b0d;
        (*_DAT_)();
        lVar18 = *(longlong *)(lVar34 + 0x100);
      }
      *(undefined8 *)(&stack0x00000230 + lVar17) = *(undefined8 *)(&stack0x00000138 + lVar17);
      *(undefined8 *)(lVar18 + 0xc88) = *(undefined8 *)(&stack0x00000138 + lVar17);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100b38;
      func_0x(&stack0x00000278 + lVar17);
      lVar34 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar18 = *(longlong *)(lVar34 + 0x100);
      if (lVar18 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100bb3;
        (*_DAT_)();
        lVar18 = *(longlong *)(lVar34 + 0x100);
      }
      if (*(int *)(lVar18 + 0x22c) != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100bc9;
        (*_DAT_)();
      }
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100a05;
      lVar34 = func_0x();
      puVar29 = (uint *)(lVar34 + 0x18);
      if (lVar34 == 0) {
        puVar29 = (uint *)0x4;
      }
      if ((*puVar29 >> 1 & 1) == 0) goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100a2b;
      func_0x(&stack0x000042a8 + lVar17,lVar18,uVar48);
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100bd7;
    (*_DAT_)(&stack0x00004548 + lVar17);
    *(undefined2 *)(&stack0x00000050 + lVar17) = 0xffff;
    *(undefined8 *)(&stack0x00000058 + lVar17) = 0;
    uVar43 = 0;
    *(undefined4 *)(&stack0x00000054 + lVar17) = 0;
    *(undefined8 *)(&stack0x0000006e + lVar17) = 0;
    *(undefined8 *)(&stack0x00000078 + lVar17) = 0;
    *(undefined8 *)(&stack0x00000060 + lVar17) = 0;
    lVar18 = *(longlong *)(&stack0x00000108 + lVar17);
    piVar37 = (int *)(lVar18 + (0xfff - (longlong)(int)uVar48) * 2);
    *(int **)(&stack0x00000138 + lVar17) = piVar37;
    pbVar40 = (byte *)((ulonglong)*(ushort *)piVar37 + lVar18);
    uVar47 = (ulonglong)*(ushort *)(lVar18 + 0xe);
    bVar10 = *pbVar40;
    *(byte **)(&stack0x00000058 + lVar17) = pbVar40;
    uVar26 = 0;
    if ((bVar10 & 1) == 0) {
      *(undefined2 *)(&stack0x00000050 + lVar17) = 0;
      *(undefined4 *)(&stack0x00000076 + lVar17) = 0;
      uVar30 = uVar28;
      switch(*pbVar40 & 0xe) {
      default:
        uVar47 = (ulonglong)*(ushort *)(pbVar40 + 2);
        uVar30 = uVar43;
        if (0x1f9d < *(ushort *)(pbVar40 + 2) - 1) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100e98;
          func_0x(pbVar40,6);
          pbVar40 = *(byte **)(&stack0x00000058 + lVar17);
          uVar30 = (ulonglong)*(uint *)(&stack0x00000054 + lVar17);
        }
        break;
      case 4:
        uVar47 = 9;
        uVar30 = uVar43;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar47 = 1;
        uVar30 = uVar43;
      }
      uVar45 = (uint)uVar47;
      *(uint *)(&stack0x00000060 + lVar17) = uVar45;
      uVar21 = *(longlong *)(&stack0x00000190 + lVar17) + 0x2000;
      if (*(longlong *)(&stack0x00000190 + lVar17) == 0) {
        uVar21 = uVar28;
      }
      *(ulonglong *)(&stack0x0000006e + lVar17) = uVar21;
    }
    else {
      *(undefined2 *)(&stack0x00000050 + lVar17) = 1;
      bVar10 = *pbVar40;
      switch(bVar10 & 0x1c) {
      default:
        if ((char)pbVar40[1] < '\0') {
          uVar39 = (*(ushort *)(pbVar40 + 1) & 0x7f) << 8 | *(ushort *)(pbVar40 + 1) >> 8;
          *(ushort *)(&stack0x00000052 + lVar17) = uVar39;
          sVar12 = 3;
          *(undefined2 *)(&stack0x00000068 + lVar17) = 3;
        }
        else {
          uVar39 = (ushort)pbVar40[1];
          *(ushort *)(&stack0x00000052 + lVar17) = uVar39;
          sVar12 = 2;
          *(undefined2 *)(&stack0x00000068 + lVar17) = 2;
        }
        *(short *)(&stack0x0000006c + lVar17) = (short)(uVar39 + 1 >> 1) + sVar12;
        if (uVar39 < 0x1f) {
          *(undefined2 *)(&stack0x0000006a + lVar17) = 0;
          *(undefined4 *)(&stack0x00000080 + lVar17) = 0;
          uVar43 = uVar28;
        }
        else {
          iVar15 = uVar39 - 1;
          *(short *)(&stack0x0000006a + lVar17) =
               ((short)(iVar15 / 0x1e) + (short)(iVar15 >> 0x1f)) -
               (short)((longlong)iVar15 * 0x88888889 >> 0x3f);
          *(undefined4 *)(&stack0x00000080 + lVar17) = 0;
        }
        break;
      case 4:
        if (((bVar10 & 0x1c) == 4) && ((bVar10 & 2) != 0)) {
          *(undefined4 *)(&stack0x00000068 + lVar17) = 0;
          *(undefined2 *)(&stack0x00000052 + lVar17) = 0;
          *(undefined2 *)(&stack0x0000006c + lVar17) = 0;
          *(undefined2 *)(&stack0x00000076 + lVar17) = 0;
          uVar43 = 0xf;
          *(undefined4 *)(&stack0x00000054 + lVar17) = 0xf;
          *(undefined4 *)(&stack0x00000080 + lVar17) = 1;
        }
        else {
          *(undefined4 *)(&stack0x00000068 + lVar17) = 0;
          *(undefined2 *)(&stack0x00000052 + lVar17) = 0;
          *(undefined2 *)(&stack0x0000006c + lVar17) = 0;
          *(undefined2 *)(&stack0x00000076 + lVar17) = 0;
          uVar43 = 1;
          *(undefined4 *)(&stack0x00000054 + lVar17) = 1;
          *(undefined4 *)(&stack0x00000080 + lVar17) = 0;
        }
        break;
      case 8:
        *(undefined4 *)(&stack0x00000068 + lVar17) = 0;
        *(undefined2 *)(&stack0x00000052 + lVar17) = 0;
        *(undefined2 *)(&stack0x0000006c + lVar17) = 0;
        *(undefined2 *)(&stack0x00000076 + lVar17) = 0;
        uVar43 = 9;
        *(undefined4 *)(&stack0x00000054 + lVar17) = 9;
        *(undefined4 *)(&stack0x00000080 + lVar17) = 0;
      }
      uVar21 = *(longlong *)(&stack0x00000190 + lVar17) + 0x2000;
      if (*(longlong *)(&stack0x00000190 + lVar17) == 0) {
        uVar21 = uVar28;
      }
      *(ulonglong *)(&stack0x00000078 + lVar17) = uVar21;
      *(undefined8 *)(&stack0x00000060 + lVar17) = 0;
      uVar30 = uVar43;
      uVar47 = uVar28;
    }
    *(ulonglong *)(&stack0x00000040 + lVar17) = uVar21;
    uVar42 = (uint)uVar30;
    uVar33 = 0;
    if (*(short *)(&stack0x00000050 + lVar17) == 0) {
      if (uVar42 == 0) {
        *(undefined2 *)(&stack0x00000052 + lVar17) = 0;
        *(uint *)(&stack0x00000064 + lVar17) = uVar45;
        bVar10 = *pbVar40;
        *(int *)(&stack0x00000064 + lVar17) = (int)uVar47;
        uVar30 = uVar47;
        if ((bVar10 & 0x10) != 0) {
          uVar42 = uVar33;
          if ((*pbVar40 & 0x10) != 0) {
            uVar42 = (uint)*(ushort *)(pbVar40 + uVar45);
          }
          uVar45 = (int)uVar47 + 2 + (uVar42 + 7 >> 3);
          uVar30 = (ulonglong)uVar45;
          *(uint *)(&stack0x00000064 + lVar17) = uVar45;
        }
        if ((*pbVar40 & 0x20) == 0) {
          *(int *)(&stack0x00000054 + lVar17) = (int)uVar30;
          *(undefined2 *)(&stack0x0000006c + lVar17) = 0;
          *(int *)(&stack0x00000068 + lVar17) = (int)uVar30;
        }
        else {
          puVar35 = (ushort *)(pbVar40 + uVar30);
          *(ushort **)(&stack0x00000130 + lVar17) = puVar35;
          uVar39 = *puVar35;
          *(ushort *)(&stack0x0000006c + lVar17) = uVar39;
          uVar48 = uVar30;
          if (uVar39 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100fa5;
            cVar9 = func_0x(0x1a61f00);
            if (cVar9 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100fae;
              cVar9 = func_0x();
              if (cVar9 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100fbe;
                cVar9 = func_0x(0x1a61f00);
                if (cVar9 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100fda;
                  (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100ffe;
                  (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x80f);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101010;
            func_0x(*(undefined8 *)(&stack0x00000058 + lVar17),3);
            uVar39 = *(ushort *)(&stack0x0000006c + lVar17);
            uVar48 = (ulonglong)*(uint *)(&stack0x00000064 + lVar17);
            pbVar40 = *(byte **)(&stack0x00000058 + lVar17);
          }
          uVar45 = (uint)uVar39 * 2 + 2 + (int)uVar48;
          *(uint *)(&stack0x00000068 + lVar17) = uVar45;
          if (0x1f9e < uVar45) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101059;
            cVar9 = func_0x(0x1a61f00);
            if (cVar9 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101062;
              cVar9 = func_0x();
              if (cVar9 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101072;
                cVar9 = func_0x(0x1a61f00);
                if (cVar9 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10108e;
                  (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1010b2;
                  (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x816);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1010c1;
            func_0x(*(undefined8 *)(&stack0x00000058 + lVar17),4);
            uVar39 = *(ushort *)(&stack0x0000006c + lVar17);
            uVar45 = *(uint *)(&stack0x00000068 + lVar17);
            uVar48 = (ulonglong)*(uint *)(&stack0x00000064 + lVar17);
            pbVar40 = *(byte **)(&stack0x00000058 + lVar17);
          }
          uVar43 = (ulonglong)uVar39;
          uVar42 = puVar35[uVar43] & 0x7fff;
          *(uint *)(&stack0x00000054 + lVar17) = uVar42;
          if (uVar42 < uVar45) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10110f;
            cVar9 = func_0x(0x1a61f00);
            if (cVar9 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101118;
              cVar9 = func_0x();
              if (cVar9 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101128;
                cVar9 = func_0x(0x1a61f00);
                if (cVar9 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101144;
                  (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101168;
                  (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x81d);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101177;
            func_0x(*(undefined8 *)(&stack0x00000058 + lVar17),4);
            uVar43 = (ulonglong)*(ushort *)(&stack0x0000006c + lVar17);
            uVar45 = *(uint *)(&stack0x00000068 + lVar17);
            uVar48 = (ulonglong)*(uint *)(&stack0x00000064 + lVar17);
            pbVar40 = *(byte **)(&stack0x00000058 + lVar17);
            uVar42 = *(uint *)(&stack0x00000054 + lVar17);
          }
          uVar30 = (ulonglong)uVar42;
          uVar47 = uVar28;
          if ((short)uVar43 != 0) {
            do {
              puVar35 = puVar35 + 1;
              uVar42 = *puVar35 & 0x7fff;
              if ((uVar42 < uVar45) || ((uint)uVar30 < uVar42)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1011d4;
                cVar9 = func_0x(0x1a61f00);
                if (cVar9 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1011dd;
                  cVar9 = func_0x();
                  if (cVar9 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1011ed;
                    cVar9 = func_0x(0x1a61f00);
                    if (cVar9 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101209;
                      (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10122d;
                      (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x82a);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10123f;
                func_0x(*(undefined8 *)(&stack0x00000058 + lVar17),4);
                uVar43 = (ulonglong)*(ushort *)(&stack0x0000006c + lVar17);
                pbVar40 = *(byte **)(&stack0x00000058 + lVar17);
                uVar30 = (ulonglong)*(uint *)(&stack0x00000054 + lVar17);
              }
              uVar46 = (int)uVar47 + 1;
              uVar47 = (ulonglong)uVar46;
              uVar45 = uVar42;
            } while ((int)uVar46 < (int)uVar43);
            uVar45 = *(uint *)(&stack0x00000068 + lVar17);
            uVar48 = (ulonglong)*(uint *)(&stack0x00000064 + lVar17);
            puVar35 = *(ushort **)(&stack0x00000130 + lVar17);
          }
          while ((short)puVar35[(ulonglong)((int)uVar43 - 1) + 1] < 0) {
            if ((int)uVar43 == 1) {
              uVar47 = 1;
              uVar42 = uVar45;
            }
            else {
              uVar42 = *(ushort *)(pbVar40 + uVar43 * 2 + (uVar48 - 2)) & 0x7fff;
              uVar47 = uVar43;
            }
            uVar46 = *(ushort *)(pbVar40 + uVar47 * 2 + uVar48) & 0x7fff;
            if (((uVar42 < uVar45) || (uVar46 < uVar42)) || ((uint)uVar30 < uVar46)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1012e9;
              func_0x(pbVar40,7);
              uVar43 = (ulonglong)*(ushort *)(&stack0x0000006c + lVar17);
              uVar45 = *(uint *)(&stack0x00000068 + lVar17);
              uVar48 = (ulonglong)*(uint *)(&stack0x00000064 + lVar17);
              pbVar40 = *(byte **)(&stack0x00000058 + lVar17);
              uVar30 = (ulonglong)*(uint *)(&stack0x00000054 + lVar17);
            }
            if ((uVar42 < uVar45) || ((uint)uVar30 < uVar42)) goto code_r0x001016e0;
            if (*(ushort *)(pbVar40 + uVar42) == 5) {
              *(ushort *)(&stack0x00000052 + lVar17) = *(ushort *)(&stack0x00000052 + lVar17) | 2;
              *(short *)(&stack0x0000006c + lVar17) = (short)uVar43 + -1;
              uVar48 = (ulonglong)(uVar42 & 0xffff);
              *(short *)(&stack0x0000007a + lVar17) = (short)uVar42;
              pbVar1 = pbVar40 + uVar48;
              uVar39 = *(ushort *)(&stack0x0000007c + lVar17);
              if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                uVar39 = uVar39 & 0xc7ff;
              }
              else {
                uVar39 = uVar39 ^ (uVar39 ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
              }
              *(ushort *)(&stack0x0000007c + lVar17) = uVar39;
              uVar44 = (uVar39 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar39;
              *(ushort *)(&stack0x0000007c + lVar17) = uVar44;
              pbVar36 = pbVar40 + (ulonglong)((uVar39 >> 0xb & 7) * 2) + 4 + uVar48 +
                                  ((ulonglong)uVar44 & 0x7ff) * 2;
              if (pbVar36 < pbVar1) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10141d;
                func_0x(pbVar1,0x19);
                uVar44 = *(ushort *)(&stack0x0000007c + lVar17);
                uVar48 = (ulonglong)*(ushort *)(&stack0x0000007a + lVar17);
                pbVar40 = *(byte **)(&stack0x00000058 + lVar17);
                uVar30 = (ulonglong)*(uint *)(&stack0x00000054 + lVar17);
              }
              if (uVar46 - uVar42 <
                  (((*(uint *)(&stack0x0000007c + lVar17) & 0x7ff) * 2 - (int)uVar48) -
                  *(int *)(&stack0x00000058 + lVar17)) + (int)pbVar36) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10146f;
                func_0x(pbVar40 + uVar48,0x19);
                uVar44 = *(ushort *)(&stack0x0000007c + lVar17);
                uVar48 = (ulonglong)*(ushort *)(&stack0x0000007a + lVar17);
                pbVar40 = *(byte **)(&stack0x00000058 + lVar17);
                uVar30 = (ulonglong)*(uint *)(&stack0x00000054 + lVar17);
              }
              if (((uVar44 & 0x3800) != 0) &&
                 (puVar35 = (ushort *)(pbVar40 + uVar48 + 4), uVar43 = uVar28,
                 (uVar44 & 0x3800) != 0)) {
                do {
                  if ((uVar44 & 0x7ff) < (*puVar35 & 0x7ff)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1014e5;
                    func_0x(pbVar40 + uVar48,0x1a);
                    uVar44 = *(ushort *)(&stack0x0000007c + lVar17);
                    uVar48 = (ulonglong)*(ushort *)(&stack0x0000007a + lVar17);
                    pbVar40 = *(byte **)(&stack0x00000058 + lVar17);
                  }
                  uVar45 = (int)uVar43 + 1;
                  uVar43 = (ulonglong)uVar45;
                  puVar35 = puVar35 + 1;
                } while ((int)uVar45 < (int)(*(uint *)(&stack0x0000007c + lVar17) >> 0xb & 7));
                uVar30 = (ulonglong)*(uint *)(&stack0x00000054 + lVar17);
              }
              break;
            }
            if (*(ushort *)(pbVar40 + uVar42) < 0x400) break;
            *(ushort *)(&stack0x00000052 + lVar17) = *(ushort *)(&stack0x00000052 + lVar17) | 1;
            uVar39 = (short)uVar43 - 1;
            uVar43 = (ulonglong)uVar39;
            *(ushort *)(&stack0x0000006c + lVar17) = uVar39;
            if (uVar39 == 0) break;
            puVar35 = *(ushort **)(&stack0x00000130 + lVar17);
          }
        }
        if ((*pbVar40 & 0x40) == 0) {
          *(undefined4 *)(&stack0x00000076 + lVar17) = 0;
        }
        else {
          *(int *)(&stack0x00000076 + lVar17) = (int)uVar30;
          *(int *)(&stack0x00000054 + lVar17) = (int)uVar30 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101562;
          uVar22 = func_0x(&stack0x00000052 + lVar17);
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101572;
          func_0x(uVar22,&stack0x000001a8 + lVar17);
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10157f;
          iVar15 = func_0x(&stack0x000001a8 + lVar17);
          uVar30 = (ulonglong)(uint)(*(int *)(&stack0x00000054 + lVar17) + iVar15);
          *(int *)(&stack0x00000054 + lVar17) = *(int *)(&stack0x00000054 + lVar17) + iVar15;
          pbVar40 = *(byte **)(&stack0x00000058 + lVar17);
        }
        if ((*(byte **)(&stack0x0000006e + lVar17) != (byte *)0x0) &&
           (*(byte **)(&stack0x0000006e + lVar17) < pbVar40 + uVar30)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1015cf;
          cVar9 = func_0x(0x1a61f00);
          if (cVar9 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1015d8;
            cVar9 = func_0x();
            if (cVar9 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1015e8;
              cVar9 = func_0x(0x1a61f00);
              if (cVar9 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101604;
                (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101628;
                (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x886);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10163a;
          func_0x(*(undefined8 *)(&stack0x00000058 + lVar17),0x12);
          pbVar40 = *(byte **)(&stack0x00000058 + lVar17);
          uVar30 = (ulonglong)*(uint *)(&stack0x00000054 + lVar17);
        }
        if (0x3f3b < (int)uVar30 - 1U) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101665;
          cVar9 = func_0x(0x1a61f00);
          if (cVar9 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10166e;
            cVar9 = func_0x();
            if (cVar9 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10167e;
              cVar9 = func_0x(0x1a61f00);
              if (cVar9 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10169a;
                (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1016be;
                (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x88b);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1016d0;
          func_0x(*(undefined8 *)(&stack0x00000058 + lVar17),5);
          pbVar40 = *(byte **)(&stack0x00000058 + lVar17);
          uVar30 = (ulonglong)*(uint *)(&stack0x00000054 + lVar17);
        }
      }
code_r0x001016e0:
      uVar42 = (uint)uVar30;
      if ((uVar42 < 9) && (((*pbVar40 & 0xe) == 0 || ((*pbVar40 & 0xe) == 0xc)))) {
        uVar42 = 9;
      }
      piVar37 = *(int **)(&stack0x00000138 + lVar17);
      uVar48 = (ulonglong)*(uint *)(&stack0x00000028 + lVar17);
    }
    else {
      if (uVar42 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101719;
        func_0x(&stack0x00000052 + lVar17);
        pbVar40 = *(byte **)(&stack0x00000058 + lVar17);
        uVar42 = *(uint *)(&stack0x00000054 + lVar17);
      }
      if ((uVar42 < 9) && (((*pbVar40 & 0x1c) == 0 || ((*pbVar40 & 0x1c) == 0xc)))) {
        uVar42 = 9;
      }
    }
    uVar39 = *(ushort *)piVar37;
    *(uint *)(&stack0xfffffffffffffff0 + lVar17) = uVar42;
    *(uint *)(&stack0xffffffffffffffe8 + lVar17) = (uint)uVar39;
    iVar15 = (int)uVar48;
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10176c;
    (*pcRam0000000000fcf788)
              (&stack0x00004548 + lVar17,*(undefined8 *)(&stack0x00000030 + lVar17),0x1388840,uVar48
              );
    *(undefined2 *)(&stack0x00000088 + lVar17) = 0xffff;
    *(undefined8 *)(&stack0x00000090 + lVar17) = 0;
    uVar48 = 0;
    *(undefined4 *)(&stack0x0000008c + lVar17) = 0;
    *(undefined8 *)(&stack0x000000a6 + lVar17) = 0;
    *(undefined8 *)(&stack0x000000b0 + lVar17) = 0;
    *(undefined8 *)(&stack0x00000098 + lVar17) = 0;
    lVar18 = *(longlong *)(&stack0x00000108 + lVar17);
    pbVar40 = (byte *)((ulonglong)*(ushort *)piVar37 + lVar18);
    uVar43 = (ulonglong)*(ushort *)(lVar18 + 0xe);
    bVar10 = *pbVar40;
    *(byte **)(&stack0x00000090 + lVar17) = pbVar40;
    if ((bVar10 & 1) == 0) {
      *(undefined2 *)(&stack0x00000088 + lVar17) = 0;
      *(undefined4 *)(&stack0x000000ae + lVar17) = 0;
      uVar47 = uVar28;
      switch(*pbVar40 & 0xe) {
      default:
        uVar43 = (ulonglong)*(ushort *)(pbVar40 + 2);
        uVar47 = uVar48;
        if (0x1f9d < *(ushort *)(pbVar40 + 2) - 1) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101a08;
          func_0x(pbVar40,6);
          pbVar40 = *(byte **)(&stack0x00000090 + lVar17);
          uVar47 = (ulonglong)*(uint *)(&stack0x0000008c + lVar17);
        }
        break;
      case 4:
        uVar43 = 9;
        uVar47 = uVar48;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar43 = 1;
        uVar47 = uVar48;
      }
      uVar45 = (uint)uVar43;
      *(uint *)(&stack0x00000098 + lVar17) = uVar45;
      *(undefined8 *)(&stack0x000000a6 + lVar17) = *(undefined8 *)(&stack0x00000040 + lVar17);
    }
    else {
      *(undefined2 *)(&stack0x00000088 + lVar17) = 1;
      bVar10 = *pbVar40;
      piVar37 = (int *)0xfffffffffebb2940;
      switch(bVar10 & 0x1c) {
      default:
        if ((char)pbVar40[1] < '\0') {
          uVar39 = (*(ushort *)(pbVar40 + 1) & 0x7f) << 8 | *(ushort *)(pbVar40 + 1) >> 8;
          *(ushort *)(&stack0x0000008a + lVar17) = uVar39;
          sVar12 = 3;
          *(undefined2 *)(&stack0x000000a0 + lVar17) = 3;
        }
        else {
          uVar39 = (ushort)pbVar40[1];
          *(ushort *)(&stack0x0000008a + lVar17) = uVar39;
          sVar12 = 2;
          *(undefined2 *)(&stack0x000000a0 + lVar17) = 2;
        }
        *(short *)(&stack0x000000a4 + lVar17) = (short)(uVar39 + 1 >> 1) + sVar12;
        if (uVar39 < 0x1f) {
          *(undefined2 *)(&stack0x000000a2 + lVar17) = 0;
          *(undefined4 *)(&stack0x000000b8 + lVar17) = 0;
          uVar48 = uVar28;
        }
        else {
          iVar27 = uVar39 - 1;
          *(short *)(&stack0x000000a2 + lVar17) =
               ((short)(iVar27 / 0x1e) + (short)(iVar27 >> 0x1f)) -
               (short)((longlong)iVar27 * 0x88888889 >> 0x3f);
          *(undefined4 *)(&stack0x000000b8 + lVar17) = 0;
        }
        break;
      case 4:
        if (((bVar10 & 0x1c) == 4) && ((bVar10 & 2) != 0)) {
          *(undefined4 *)(&stack0x000000a0 + lVar17) = 0;
          *(undefined2 *)(&stack0x0000008a + lVar17) = 0;
          *(undefined2 *)(&stack0x000000a4 + lVar17) = 0;
          *(undefined2 *)(&stack0x000000ae + lVar17) = 0;
          uVar48 = 0xf;
          *(undefined4 *)(&stack0x0000008c + lVar17) = 0xf;
          *(undefined4 *)(&stack0x000000b8 + lVar17) = 1;
        }
        else {
          *(undefined4 *)(&stack0x000000a0 + lVar17) = 0;
          *(undefined2 *)(&stack0x0000008a + lVar17) = 0;
          *(undefined2 *)(&stack0x000000a4 + lVar17) = 0;
          *(undefined2 *)(&stack0x000000ae + lVar17) = 0;
          uVar48 = 1;
          *(undefined4 *)(&stack0x0000008c + lVar17) = 1;
          *(undefined4 *)(&stack0x000000b8 + lVar17) = 0;
        }
        break;
      case 8:
        *(undefined4 *)(&stack0x000000a0 + lVar17) = 0;
        *(undefined2 *)(&stack0x0000008a + lVar17) = 0;
        *(undefined2 *)(&stack0x000000a4 + lVar17) = 0;
        *(undefined2 *)(&stack0x000000ae + lVar17) = 0;
        uVar48 = 9;
        *(undefined4 *)(&stack0x0000008c + lVar17) = 9;
        *(undefined4 *)(&stack0x000000b8 + lVar17) = 0;
      }
      *(undefined8 *)(&stack0x000000b0 + lVar17) = *(undefined8 *)(&stack0x00000040 + lVar17);
      *(undefined8 *)(&stack0x00000098 + lVar17) = 0;
      uVar47 = uVar48;
      uVar43 = uVar28;
      uVar45 = uVar33;
    }
    uVar42 = (uint)uVar47;
    if (*(short *)(&stack0x00000088 + lVar17) == 0) {
      if (uVar42 == 0) {
        *(undefined2 *)(&stack0x0000008a + lVar17) = 0;
        *(uint *)(&stack0x0000009c + lVar17) = uVar45;
        bVar10 = *pbVar40;
        *(int *)(&stack0x0000009c + lVar17) = (int)uVar43;
        uVar47 = uVar43;
        if ((bVar10 & 0x10) != 0) {
          uVar42 = uVar33;
          if ((*pbVar40 & 0x10) != 0) {
            uVar42 = (uint)*(ushort *)(pbVar40 + uVar45);
          }
          uVar45 = (int)uVar43 + 2 + (uVar42 + 7 >> 3);
          uVar47 = (ulonglong)uVar45;
          *(uint *)(&stack0x0000009c + lVar17) = uVar45;
        }
        if ((*pbVar40 & 0x20) == 0) {
          *(int *)(&stack0x0000008c + lVar17) = (int)uVar47;
          *(undefined2 *)(&stack0x000000a4 + lVar17) = 0;
          *(int *)(&stack0x000000a0 + lVar17) = (int)uVar47;
        }
        else {
          puVar35 = (ushort *)(pbVar40 + uVar47);
          uVar39 = *puVar35;
          *(ushort *)(&stack0x000000a4 + lVar17) = uVar39;
          uVar48 = uVar47;
          if (uVar39 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101af8;
            cVar9 = func_0x(0x1a61f00);
            if (cVar9 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101b01;
              cVar9 = func_0x();
              if (cVar9 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101b11;
                cVar9 = func_0x(0x1a61f00);
                if (cVar9 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101b2d;
                  (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101b51;
                  (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x80f);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101b63;
            func_0x(*(undefined8 *)(&stack0x00000090 + lVar17),3);
            uVar39 = *(ushort *)(&stack0x000000a4 + lVar17);
            uVar48 = (ulonglong)*(uint *)(&stack0x0000009c + lVar17);
            pbVar40 = *(byte **)(&stack0x00000090 + lVar17);
          }
          uVar45 = (uint)uVar39 * 2 + 2 + (int)uVar48;
          *(uint *)(&stack0x000000a0 + lVar17) = uVar45;
          if (0x1f9e < uVar45) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101bac;
            cVar9 = func_0x(0x1a61f00);
            if (cVar9 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101bb5;
              cVar9 = func_0x();
              if (cVar9 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101bc5;
                cVar9 = func_0x(0x1a61f00);
                if (cVar9 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101be1;
                  (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101c05;
                  (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x816);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101c17;
            func_0x(*(undefined8 *)(&stack0x00000090 + lVar17),4);
            uVar39 = *(ushort *)(&stack0x000000a4 + lVar17);
            uVar45 = *(uint *)(&stack0x000000a0 + lVar17);
            uVar48 = (ulonglong)*(uint *)(&stack0x0000009c + lVar17);
            pbVar40 = *(byte **)(&stack0x00000090 + lVar17);
          }
          uVar43 = (ulonglong)uVar39;
          uVar42 = puVar35[uVar43] & 0x7fff;
          *(uint *)(&stack0x0000008c + lVar17) = uVar42;
          if (uVar42 < uVar45) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101c65;
            cVar9 = func_0x(0x1a61f00);
            if (cVar9 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101c6e;
              cVar9 = func_0x();
              if (cVar9 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101c7e;
                cVar9 = func_0x(0x1a61f00);
                if (cVar9 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101c9a;
                  (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101cbe;
                  (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x81d);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101cd0;
            func_0x(*(undefined8 *)(&stack0x00000090 + lVar17),4);
            uVar43 = (ulonglong)*(ushort *)(&stack0x000000a4 + lVar17);
            uVar45 = *(uint *)(&stack0x000000a0 + lVar17);
            uVar48 = (ulonglong)*(uint *)(&stack0x0000009c + lVar17);
            pbVar40 = *(byte **)(&stack0x00000090 + lVar17);
            uVar42 = *(uint *)(&stack0x0000008c + lVar17);
          }
          uVar47 = (ulonglong)uVar42;
          uVar30 = uVar28;
          puVar6 = puVar35;
          if ((short)uVar43 != 0) {
            do {
              uVar42 = puVar6[1] & 0x7fff;
              piVar37 = (int *)(ulonglong)uVar42;
              if ((uVar42 < uVar45) || ((uint)uVar47 < uVar42)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d33;
                cVar9 = func_0x(0x1a61f00);
                if (cVar9 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d3c;
                  cVar9 = func_0x();
                  if (cVar9 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d4c;
                    cVar9 = func_0x(0x1a61f00);
                    if (cVar9 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d68;
                      (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d8c;
                      (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x82a);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d9e;
                func_0x(*(undefined8 *)(&stack0x00000090 + lVar17),4);
                uVar43 = (ulonglong)*(ushort *)(&stack0x000000a4 + lVar17);
                pbVar40 = *(byte **)(&stack0x00000090 + lVar17);
                uVar47 = (ulonglong)*(uint *)(&stack0x0000008c + lVar17);
              }
              uVar46 = (int)uVar30 + 1;
              uVar30 = (ulonglong)uVar46;
              uVar45 = uVar42;
              puVar6 = puVar6 + 1;
            } while ((int)uVar46 < (int)uVar43);
            uVar45 = *(uint *)(&stack0x000000a0 + lVar17);
            uVar48 = (ulonglong)*(uint *)(&stack0x0000009c + lVar17);
          }
          while ((short)puVar35[(ulonglong)((int)uVar43 - 1) + 1] < 0) {
            if ((int)uVar43 == 1) {
              uVar30 = 1;
              uVar42 = uVar45;
            }
            else {
              uVar42 = *(ushort *)(pbVar40 + uVar43 * 2 + (uVar48 - 2)) & 0x7fff;
              uVar30 = uVar43;
            }
            piVar37 = (int *)(ulonglong)uVar42;
            uVar46 = *(ushort *)(pbVar40 + uVar30 * 2 + uVar48) & 0x7fff;
            if (((uVar42 < uVar45) || (uVar46 < uVar42)) || ((uint)uVar47 < uVar46)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101e4a;
              func_0x(pbVar40,7);
              uVar43 = (ulonglong)*(ushort *)(&stack0x000000a4 + lVar17);
              uVar45 = *(uint *)(&stack0x000000a0 + lVar17);
              uVar48 = (ulonglong)*(uint *)(&stack0x0000009c + lVar17);
              pbVar40 = *(byte **)(&stack0x00000090 + lVar17);
              uVar47 = (ulonglong)*(uint *)(&stack0x0000008c + lVar17);
            }
            if ((uVar42 < uVar45) || ((uint)uVar47 < uVar42)) goto code_r0x00102273;
            if (*(ushort *)(pbVar40 + (longlong)piVar37) == 5) {
              *(ushort *)(&stack0x0000008a + lVar17) = *(ushort *)(&stack0x0000008a + lVar17) | 2;
              *(short *)(&stack0x000000a4 + lVar17) = (short)uVar43 + -1;
              uVar48 = (ulonglong)piVar37 & 0xffff;
              *(short *)(&stack0x000000b2 + lVar17) = (short)uVar42;
              piVar32 = (int *)(pbVar40 + uVar48);
              uVar39 = *(ushort *)(&stack0x000000b4 + lVar17);
              if ((*(ushort *)((longlong)piVar32 + 2) & 0x4000) == 0) {
                uVar39 = uVar39 & 0xc7ff;
              }
              else {
                uVar39 = uVar39 ^ (uVar39 ^ *(ushort *)((longlong)piVar32 + 2)) & 0x3800;
              }
              *(ushort *)(&stack0x000000b4 + lVar17) = uVar39;
              uVar44 = (uVar39 ^ *(ushort *)((longlong)piVar32 + 2)) & 0x7ff ^ uVar39;
              *(ushort *)(&stack0x000000b4 + lVar17) = uVar44;
              piVar37 = (int *)(pbVar40 +
                               uVar48 + ((ulonglong)uVar44 & 0x7ff) * 2 +
                                        (ulonglong)((uVar39 >> 0xb & 7) * 2) + 4);
              if (piVar37 < piVar32) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101f76;
                func_0x(piVar32,0x19);
                uVar44 = *(ushort *)(&stack0x000000b4 + lVar17);
                uVar48 = (ulonglong)*(ushort *)(&stack0x000000b2 + lVar17);
                pbVar40 = *(byte **)(&stack0x00000090 + lVar17);
                uVar47 = (ulonglong)*(uint *)(&stack0x0000008c + lVar17);
              }
              if (uVar46 - uVar42 <
                  (((*(uint *)(&stack0x000000b4 + lVar17) & 0x7ff) * 2 - (int)uVar48) -
                  *(int *)(&stack0x00000090 + lVar17)) + (int)piVar37) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101fc8;
                func_0x(pbVar40 + uVar48,0x19);
                uVar44 = *(ushort *)(&stack0x000000b4 + lVar17);
                uVar48 = (ulonglong)*(ushort *)(&stack0x000000b2 + lVar17);
                pbVar40 = *(byte **)(&stack0x00000090 + lVar17);
                uVar47 = (ulonglong)*(uint *)(&stack0x0000008c + lVar17);
              }
              if (((uVar44 & 0x3800) != 0) &&
                 (piVar37 = (int *)(pbVar40 + uVar48 + 4), uVar43 = uVar28, (uVar44 & 0x3800) != 0))
              {
                do {
                  if ((uVar44 & 0x7ff) < (*(ushort *)piVar37 & 0x7ff)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102045;
                    func_0x(pbVar40 + uVar48,0x1a);
                    uVar44 = *(ushort *)(&stack0x000000b4 + lVar17);
                    uVar48 = (ulonglong)*(ushort *)(&stack0x000000b2 + lVar17);
                    pbVar40 = *(byte **)(&stack0x00000090 + lVar17);
                  }
                  uVar45 = (int)uVar43 + 1;
                  piVar37 = (int *)((longlong)piVar37 + 2);
                  uVar43 = (ulonglong)uVar45;
                } while ((int)uVar45 < (int)(*(uint *)(&stack0x000000b4 + lVar17) >> 0xb & 7));
                uVar47 = (ulonglong)*(uint *)(&stack0x0000008c + lVar17);
              }
              break;
            }
            if (*(ushort *)(pbVar40 + (longlong)piVar37) < 0x400) break;
            *(ushort *)(&stack0x0000008a + lVar17) = *(ushort *)(&stack0x0000008a + lVar17) | 1;
            uVar39 = (short)uVar43 - 1;
            uVar43 = (ulonglong)uVar39;
            *(ushort *)(&stack0x000000a4 + lVar17) = uVar39;
            if (uVar39 == 0) break;
          }
        }
        if ((*pbVar40 & 0x40) == 0) {
          *(undefined4 *)(&stack0x000000ae + lVar17) = 0;
        }
        else {
          *(int *)(&stack0x000000ae + lVar17) = (int)uVar47;
          *(int *)(&stack0x0000008c + lVar17) = (int)uVar47 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1020c6;
          puVar23 = (ulonglong *)func_0x(&stack0x0000008a + lVar17);
          uVar39 = (ushort)(*puVar23 >> 0x30);
          if ((((uint)(int)(short)uVar39 >> 1 ^ (int)(short)uVar39) & 0x2000) != 0) {
            if ((uVar39 >> 0xe & 1) == 0) {
              uVar39 = uVar39 & 0xdfff;
            }
            else {
              uVar39 = uVar39 | 0x2000;
            }
          }
          uVar45 = uVar33;
          if (uVar39 == 0xfffc) {
            uVar45 = (uint)((*puVar23 >> 0x20 & 0xffff) >> 5);
          }
          uVar47 = (ulonglong)(*(int *)(&stack0x0000008c + lVar17) + uVar45);
          *(uint *)(&stack0x0000008c + lVar17) = *(int *)(&stack0x0000008c + lVar17) + uVar45;
          pbVar40 = *(byte **)(&stack0x00000090 + lVar17);
        }
        if ((*(byte **)(&stack0x000000a6 + lVar17) != (byte *)0x0) &&
           (*(byte **)(&stack0x000000a6 + lVar17) < pbVar40 + uVar47)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102162;
          cVar9 = func_0x(0x1a61f00);
          if (cVar9 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10216b;
            cVar9 = func_0x();
            if (cVar9 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10217b;
              cVar9 = func_0x(0x1a61f00);
              if (cVar9 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102197;
                (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1021bb;
                (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x886);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1021cd;
          func_0x(*(undefined8 *)(&stack0x00000090 + lVar17),0x12);
          pbVar40 = *(byte **)(&stack0x00000090 + lVar17);
          uVar47 = (ulonglong)*(uint *)(&stack0x0000008c + lVar17);
        }
        if (0x3f3b < (int)uVar47 - 1U) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1021f8;
          cVar9 = func_0x(0x1a61f00);
          if (cVar9 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102201;
            cVar9 = func_0x();
            if (cVar9 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102211;
              cVar9 = func_0x(0x1a61f00);
              if (cVar9 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10222d;
                (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102251;
                (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x88b);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102263;
          func_0x(*(undefined8 *)(&stack0x00000090 + lVar17),5);
          pbVar40 = *(byte **)(&stack0x00000090 + lVar17);
          uVar47 = (ulonglong)*(uint *)(&stack0x0000008c + lVar17);
        }
      }
code_r0x00102273:
      uVar42 = (uint)uVar47;
      if ((uVar42 < 9) && (((*pbVar40 & 0xe) == 0 || ((*pbVar40 & 0xe) == 0xc)))) {
        uVar42 = 9;
      }
      iVar15 = *(int *)(&stack0x00000028 + lVar17);
      lVar18 = *(longlong *)(&stack0x00000108 + lVar17);
    }
    else {
      if (uVar42 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1022ac;
        func_0x(&stack0x0000008a + lVar17);
        pbVar40 = *(byte **)(&stack0x00000090 + lVar17);
        uVar42 = *(uint *)(&stack0x0000008c + lVar17);
      }
      if ((uVar42 < 9) && (((*pbVar40 & 0x1c) == 0 || ((*pbVar40 & 0x1c) == 0xc)))) {
        uVar42 = 9;
      }
    }
    if ((uVar42 == 0) || (*(int *)(&stack0x00000124 + lVar17) != 0)) {
      *(longlong *)(&stack0x00000118 + lVar17) = 0xfff - (longlong)iVar15;
      uVar26 = *(ushort *)(lVar18 + (0xfff - (longlong)iVar15) * 2);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1057c3;
      uVar22 = (*pcRam0000000000fcfa00)();
      *(uint *)(&stack0xffffffffffffffe8 + lVar17) = (uint)uVar26;
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1057e3;
      iVar15 = func_0x(&stack0x00006268 + lVar17,0x200,0x1389530,uVar22);
      if (iVar15 < 0) {
        *(int *)(&stack0xfffffffffffffff8 + lVar17) = iVar15;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = 0x548;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0x1388720;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105817;
        (*pcRam0000000000fcfa88)(4,7,0x10,1);
      }
      param_2 = *(longlong *)(&stack0x00000030 + lVar17);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10582e;
      (*_DAT_)(param_2);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10583f;
      (*pcRam0000000000fceb68)(param_2,&stack0x00006268 + lVar17);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105848;
      (*_DAT_)(param_2);
      uVar26 = *(ushort *)(lVar18 + 0x16);
      lVar34 = *(longlong *)(&stack0x00000118 + lVar17);
      uVar39 = *(ushort *)(lVar18 + lVar34 * 2);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10586b;
      uVar22 = (*pcRam0000000000fcfa00)();
      *(uint *)(&stack0xffffffffffffffe8 + lVar17) = (0x1000 - (uint)uVar26) * 2 - (uint)uVar39;
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10588b;
      iVar15 = func_0x(&stack0x00006268 + lVar17,0x200,0x13894f0,uVar22);
      if (iVar15 < 0) {
        *(int *)(&stack0xfffffffffffffff8 + lVar17) = iVar15;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = 0x555;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0x1388720;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1058b8;
        (*pcRam0000000000fcfa88)(4,7,0x10,1);
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1058c9;
      (*pcRam0000000000fceb68)(param_2,&stack0x00006268 + lVar17);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1058d2;
      (*_DAT_)(param_2);
      uVar43 = 0;
      *(undefined4 *)(&stack0x000000c4 + lVar17) = 0;
      *(undefined8 *)(&stack0x000000de + lVar17) = 0;
      *(undefined8 *)(&stack0x000000e8 + lVar17) = 0;
      *(undefined8 *)(&stack0x000000d0 + lVar17) = 0;
      pbVar40 = (byte *)((ulonglong)*(ushort *)(lVar18 + lVar34 * 2) + lVar18);
      uVar48 = (ulonglong)*(ushort *)(lVar18 + 0xe);
      bVar10 = *pbVar40;
      *(byte **)(&stack0x000000c8 + lVar17) = pbVar40;
      if ((bVar10 & 1) == 0) {
        *(undefined2 *)(&stack0x000000c0 + lVar17) = 0;
        *(undefined4 *)(&stack0x000000e6 + lVar17) = 0;
        uVar47 = uVar28;
        switch(*pbVar40 & 0xe) {
        default:
          uVar48 = (ulonglong)*(ushort *)(pbVar40 + 2);
          uVar47 = uVar43;
          if (0x1f9d < *(ushort *)(pbVar40 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105b94;
            func_0x(pbVar40,6);
            pbVar40 = *(byte **)(&stack0x000000c8 + lVar17);
            uVar47 = (ulonglong)*(uint *)(&stack0x000000c4 + lVar17);
          }
          break;
        case 4:
          uVar48 = 9;
          uVar47 = uVar43;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar48 = 1;
          uVar47 = uVar43;
        }
        uVar43 = uVar47;
        *(int *)(&stack0x000000d0 + lVar17) = (int)uVar48;
        *(longlong *)(&stack0x000000de + lVar17) = lVar18 + 0x2000;
      }
      else {
        *(undefined2 *)(&stack0x000000c0 + lVar17) = 1;
        bVar10 = *pbVar40;
        switch(bVar10 & 0x1c) {
        default:
          if ((char)pbVar40[1] < '\0') {
            uVar26 = (*(ushort *)(pbVar40 + 1) & 0x7f) << 8 | *(ushort *)(pbVar40 + 1) >> 8;
            *(ushort *)(&stack0x000000c2 + lVar17) = uVar26;
            uVar13 = 3;
            *(undefined2 *)(&stack0x00000038 + lVar17) = 3;
          }
          else {
            uVar26 = (ushort)pbVar40[1];
            *(ushort *)(&stack0x000000c2 + lVar17) = uVar26;
            uVar13 = 2;
          }
          *(undefined2 *)(&stack0x000000d8 + lVar17) = uVar13;
          *(short *)(&stack0x000000dc + lVar17) =
               (short)(uVar26 + 1 >> 1) + *(short *)(&stack0x00000038 + lVar17);
          if (uVar26 < 0x1f) {
            *(undefined2 *)(&stack0x000000da + lVar17) = 0;
            *(undefined4 *)(&stack0x000000f0 + lVar17) = 0;
            *(longlong *)(&stack0x000000e8 + lVar17) = lVar18 + 0x2000;
            uVar48 = uVar28;
            uVar43 = uVar28;
          }
          else {
            iVar15 = uVar26 - 1;
            *(short *)(&stack0x000000da + lVar17) =
                 ((short)(iVar15 / 0x1e) + (short)(iVar15 >> 0x1f)) -
                 (short)((longlong)iVar15 * 0x88888889 >> 0x3f);
            *(undefined4 *)(&stack0x000000f0 + lVar17) = 0;
            *(longlong *)(&stack0x000000e8 + lVar17) = lVar18 + 0x2000;
            uVar48 = 0;
          }
          break;
        case 4:
          if (((bVar10 & 0x1c) == 4) && ((bVar10 & 2) != 0)) {
            *(undefined4 *)(&stack0x000000d8 + lVar17) = 0;
            *(undefined2 *)(&stack0x000000c2 + lVar17) = 0;
            *(undefined2 *)(&stack0x000000dc + lVar17) = 0;
            *(undefined2 *)(&stack0x000000e6 + lVar17) = 0;
            uVar43 = 0xf;
            *(undefined4 *)(&stack0x000000c4 + lVar17) = 0xf;
            *(undefined4 *)(&stack0x000000f0 + lVar17) = 1;
            *(longlong *)(&stack0x000000e8 + lVar17) = lVar18 + 0x2000;
            uVar48 = 0;
          }
          else {
            *(undefined4 *)(&stack0x000000d8 + lVar17) = 0;
            *(undefined2 *)(&stack0x000000c2 + lVar17) = 0;
            *(undefined2 *)(&stack0x000000dc + lVar17) = 0;
            *(undefined2 *)(&stack0x000000e6 + lVar17) = 0;
            uVar43 = 1;
            *(undefined4 *)(&stack0x000000c4 + lVar17) = 1;
            *(undefined4 *)(&stack0x000000f0 + lVar17) = 0;
            *(longlong *)(&stack0x000000e8 + lVar17) = lVar18 + 0x2000;
            uVar48 = 0;
          }
          break;
        case 8:
          *(undefined4 *)(&stack0x000000d8 + lVar17) = 0;
          *(undefined2 *)(&stack0x000000c2 + lVar17) = 0;
          *(undefined2 *)(&stack0x000000dc + lVar17) = 0;
          *(undefined2 *)(&stack0x000000e6 + lVar17) = 0;
          uVar43 = 9;
          *(undefined4 *)(&stack0x000000c4 + lVar17) = 9;
          *(undefined4 *)(&stack0x000000f0 + lVar17) = 0;
          *(longlong *)(&stack0x000000e8 + lVar17) = lVar18 + 0x2000;
          uVar48 = 0;
        }
      }
      uVar45 = (uint)uVar43;
      if (*(short *)(&stack0x000000c0 + lVar17) != 0) {
        if (uVar45 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1063fe;
          func_0x(&stack0x000000c2 + lVar17);
          pbVar40 = *(byte **)(&stack0x000000c8 + lVar17);
          uVar45 = *(uint *)(&stack0x000000c4 + lVar17);
        }
        if ((uVar45 < 9) && (((*pbVar40 & 0x1c) == 0 || ((*pbVar40 & 0x1c) == 0xc)))) {
          *(undefined4 *)(&stack0x0000002c + lVar17) = 9;
        }
        else {
          *(uint *)(&stack0x0000002c + lVar17) = uVar45;
        }
        goto code_r0x00106431;
      }
      if (uVar45 != 0) goto code_r0x001063c3;
      *(undefined2 *)(&stack0x000000c2 + lVar17) = 0;
      *(int *)(&stack0x000000d4 + lVar17) = (int)uVar48;
      uVar43 = uVar48;
      if ((*pbVar40 & 0x10) != 0) {
        uVar45 = (int)uVar48 + 2 + (*(ushort *)(pbVar40 + uVar48) + 7 >> 3);
        uVar43 = (ulonglong)uVar45;
        *(uint *)(&stack0x000000d4 + lVar17) = uVar45;
      }
      if ((*pbVar40 & 0x20) == 0) {
        *(int *)(&stack0x000000c4 + lVar17) = (int)uVar43;
        *(undefined2 *)(&stack0x000000dc + lVar17) = 0;
        *(int *)(&stack0x000000d8 + lVar17) = (int)uVar43;
        goto code_r0x001061eb;
      }
      puVar35 = (ushort *)(pbVar40 + uVar43);
      uVar26 = *puVar35;
      *(ushort *)(&stack0x000000dc + lVar17) = uVar26;
      if (uVar26 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105c6f;
        cVar9 = func_0x(0x1a61f00);
        if (cVar9 != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105c78;
          cVar9 = func_0x();
          if (cVar9 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105c88;
            cVar9 = func_0x(0x1a61f00);
            if (cVar9 == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105ca4;
              (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105cc8;
              (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x80f);
            }
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105cda;
        func_0x(*(undefined8 *)(&stack0x000000c8 + lVar17),3);
        uVar26 = *(ushort *)(&stack0x000000dc + lVar17);
        pbVar40 = *(byte **)(&stack0x000000c8 + lVar17);
      }
      uVar45 = *(int *)(&stack0x000000d4 + lVar17) + 2 + (uint)uVar26 * 2;
      *(uint *)(&stack0x000000d8 + lVar17) = uVar45;
      if (0x1f9e < uVar45) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105d1d;
        cVar9 = func_0x(0x1a61f00);
        if (cVar9 != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105d26;
          cVar9 = func_0x();
          if (cVar9 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105d36;
            cVar9 = func_0x(0x1a61f00);
            if (cVar9 == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105d52;
              (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105d76;
              (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x816);
            }
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105d88;
        func_0x(*(undefined8 *)(&stack0x000000c8 + lVar17),4);
        uVar26 = *(ushort *)(&stack0x000000dc + lVar17);
        uVar45 = *(uint *)(&stack0x000000d8 + lVar17);
        pbVar40 = *(byte **)(&stack0x000000c8 + lVar17);
      }
      uVar48 = (ulonglong)uVar26;
      uVar42 = puVar35[uVar48] & 0x7fff;
      *(uint *)(&stack0x000000c4 + lVar17) = uVar42;
      if (uVar42 < uVar45) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105dcc;
        cVar9 = func_0x(0x1a61f00);
        if (cVar9 != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105dd5;
          cVar9 = func_0x();
          if (cVar9 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105de5;
            cVar9 = func_0x(0x1a61f00);
            if (cVar9 == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105e01;
              (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105e25;
              (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x81d);
            }
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105e37;
        func_0x(*(undefined8 *)(&stack0x000000c8 + lVar17),4);
        uVar48 = (ulonglong)*(ushort *)(&stack0x000000dc + lVar17);
        uVar45 = *(uint *)(&stack0x000000d8 + lVar17);
        pbVar40 = *(byte **)(&stack0x000000c8 + lVar17);
        uVar42 = *(uint *)(&stack0x000000c4 + lVar17);
      }
      uVar43 = (ulonglong)uVar42;
      uVar47 = uVar28;
      puVar6 = puVar35;
      if ((short)uVar48 != 0) {
        do {
          uVar42 = puVar6[1] & 0x7fff;
          if ((uVar42 < uVar45) || ((uint)uVar43 < uVar42)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105e93;
            cVar9 = func_0x(0x1a61f00);
            if (cVar9 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105e9c;
              cVar9 = func_0x();
              if (cVar9 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105eac;
                cVar9 = func_0x(0x1a61f00);
                if (cVar9 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105ec8;
                  (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105eec;
                  (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x82a);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105efe;
            func_0x(*(undefined8 *)(&stack0x000000c8 + lVar17),4);
            uVar48 = (ulonglong)*(ushort *)(&stack0x000000dc + lVar17);
            pbVar40 = *(byte **)(&stack0x000000c8 + lVar17);
            uVar43 = (ulonglong)*(uint *)(&stack0x000000c4 + lVar17);
          }
          uVar46 = (int)uVar47 + 1;
          uVar47 = (ulonglong)uVar46;
          puVar6 = puVar6 + 1;
          uVar45 = uVar42;
        } while ((int)uVar46 < (int)uVar48);
        uVar45 = *(uint *)(&stack0x000000d8 + lVar17);
      }
      goto code_r0x00105f40;
    }
    uVar45 = *(uint *)(&stack0x000043a4 + lVar17);
    uVar48 = (ulonglong)uVar45;
    if (*(short *)(&stack0x000043a0 + lVar17) == 0) {
      if (uVar45 == 0) {
        *(undefined2 *)(&stack0x000043a2 + lVar17) = 0;
        uVar45 = *(uint *)(&stack0x000043b0 + lVar17);
        uVar48 = (ulonglong)uVar45;
        *(uint *)(&stack0x000043b4 + lVar17) = uVar45;
        pbVar40 = *(byte **)(&stack0x000043a8 + lVar17);
        if ((*pbVar40 & 0x10) != 0) {
          uVar45 = uVar45 + 2 + (*(ushort *)(pbVar40 + uVar48) + 7 >> 3);
          uVar48 = (ulonglong)uVar45;
          *(uint *)(&stack0x000043b4 + lVar17) = uVar45;
        }
        if ((*pbVar40 & 0x20) == 0) {
          *(int *)(&stack0x000043a4 + lVar17) = (int)uVar48;
          *(undefined2 *)(&stack0x000043bc + lVar17) = 0;
          *(int *)(&stack0x000043b8 + lVar17) = (int)uVar48;
        }
        else {
          puVar35 = (ushort *)(pbVar40 + uVar48);
          uVar39 = *puVar35;
          *(ushort *)(&stack0x000043bc + lVar17) = uVar39;
          uVar43 = uVar48;
          if (uVar39 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102381;
            cVar9 = func_0x(0x1a61f00);
            if (cVar9 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10238a;
              cVar9 = func_0x();
              if (cVar9 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10239a;
                cVar9 = func_0x(0x1a61f00);
                if (cVar9 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1023b6;
                  (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1023da;
                  (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x80f);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1023ec;
            func_0x(*(undefined8 *)(&stack0x000043a8 + lVar17),3);
            uVar39 = *(ushort *)(&stack0x000043bc + lVar17);
            uVar43 = (ulonglong)*(uint *)(&stack0x000043b4 + lVar17);
            pbVar40 = *(byte **)(&stack0x000043a8 + lVar17);
          }
          uVar45 = (int)uVar43 + (uVar39 + 1) * 2;
          *(uint *)(&stack0x000043b8 + lVar17) = uVar45;
          if (0x1f9e < uVar45) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102431;
            cVar9 = func_0x(0x1a61f00);
            if (cVar9 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10243a;
              cVar9 = func_0x();
              if (cVar9 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10244a;
                cVar9 = func_0x(0x1a61f00);
                if (cVar9 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102466;
                  (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10248a;
                  (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x816);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10249c;
            func_0x(*(undefined8 *)(&stack0x000043a8 + lVar17),4);
            uVar39 = *(ushort *)(&stack0x000043bc + lVar17);
            uVar45 = *(uint *)(&stack0x000043b8 + lVar17);
            uVar43 = (ulonglong)*(uint *)(&stack0x000043b4 + lVar17);
            pbVar40 = *(byte **)(&stack0x000043a8 + lVar17);
          }
          uVar47 = (ulonglong)uVar39;
          uVar42 = puVar35[uVar47] & 0x7fff;
          *(uint *)(&stack0x000043a4 + lVar17) = uVar42;
          if (uVar42 < uVar45) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1024eb;
            cVar9 = func_0x(0x1a61f00);
            if (cVar9 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1024f4;
              cVar9 = func_0x();
              if (cVar9 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102504;
                cVar9 = func_0x(0x1a61f00);
                if (cVar9 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102520;
                  (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102544;
                  (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x81d);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102556;
            func_0x(*(undefined8 *)(&stack0x000043a8 + lVar17),4);
            uVar47 = (ulonglong)*(ushort *)(&stack0x000043bc + lVar17);
            uVar45 = *(uint *)(&stack0x000043b8 + lVar17);
            uVar43 = (ulonglong)*(uint *)(&stack0x000043b4 + lVar17);
            pbVar40 = *(byte **)(&stack0x000043a8 + lVar17);
            uVar42 = *(uint *)(&stack0x000043a4 + lVar17);
          }
          uVar48 = (ulonglong)uVar42;
          uVar30 = uVar28;
          puVar6 = puVar35;
          if ((short)uVar47 != 0) {
            do {
              uVar42 = puVar6[1] & 0x7fff;
              piVar37 = (int *)(ulonglong)uVar42;
              if ((uVar42 < uVar45) || ((uint)uVar48 < uVar42)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1025b3;
                cVar9 = func_0x(0x1a61f00);
                if (cVar9 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1025bc;
                  cVar9 = func_0x();
                  if (cVar9 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1025cc;
                    cVar9 = func_0x(0x1a61f00);
                    if (cVar9 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1025e8;
                      (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10260c;
                      (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x82a);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10261e;
                func_0x(*(undefined8 *)(&stack0x000043a8 + lVar17),4);
                uVar47 = (ulonglong)*(ushort *)(&stack0x000043bc + lVar17);
                pbVar40 = *(byte **)(&stack0x000043a8 + lVar17);
                uVar48 = (ulonglong)*(uint *)(&stack0x000043a4 + lVar17);
              }
              uVar46 = (int)uVar30 + 1;
              uVar30 = (ulonglong)uVar46;
              uVar45 = uVar42;
              puVar6 = puVar6 + 1;
            } while ((int)uVar46 < (int)uVar47);
            uVar45 = *(uint *)(&stack0x000043b8 + lVar17);
            uVar43 = (ulonglong)*(uint *)(&stack0x000043b4 + lVar17);
          }
          while ((short)puVar35[(ulonglong)((int)uVar47 - 1) + 1] < 0) {
            if ((int)uVar47 == 1) {
              uVar30 = 1;
              uVar42 = uVar45;
            }
            else {
              uVar42 = *(ushort *)(pbVar40 + uVar47 * 2 + (uVar43 - 2)) & 0x7fff;
              uVar30 = uVar47;
            }
            piVar37 = (int *)(ulonglong)uVar42;
            uVar46 = *(ushort *)(pbVar40 + uVar30 * 2 + uVar43) & 0x7fff;
            if (((uVar42 < uVar45) || (uVar46 < uVar42)) || ((uint)uVar48 < uVar46)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1026ca;
              func_0x(pbVar40,7);
              uVar47 = (ulonglong)*(ushort *)(&stack0x000043bc + lVar17);
              uVar45 = *(uint *)(&stack0x000043b8 + lVar17);
              uVar43 = (ulonglong)*(uint *)(&stack0x000043b4 + lVar17);
              pbVar40 = *(byte **)(&stack0x000043a8 + lVar17);
              uVar48 = (ulonglong)*(uint *)(&stack0x000043a4 + lVar17);
            }
            if ((uVar42 < uVar45) || ((uint)uVar48 < uVar42)) goto code_r0x00102af3;
            if (*(ushort *)(pbVar40 + (longlong)piVar37) == 5) {
              *(ushort *)(&stack0x000043a2 + lVar17) = *(ushort *)(&stack0x000043a2 + lVar17) | 2;
              *(short *)(&stack0x000043bc + lVar17) = (short)uVar47 + -1;
              uVar43 = (ulonglong)piVar37 & 0xffff;
              *(short *)(&stack0x000043ca + lVar17) = (short)uVar42;
              piVar32 = (int *)(pbVar40 + uVar43);
              uVar39 = *(ushort *)(&stack0x000043cc + lVar17);
              if ((*(ushort *)((longlong)piVar32 + 2) & 0x4000) == 0) {
                uVar39 = uVar39 & 0xc7ff;
              }
              else {
                uVar39 = uVar39 ^ (uVar39 ^ *(ushort *)((longlong)piVar32 + 2)) & 0x3800;
              }
              *(ushort *)(&stack0x000043cc + lVar17) = uVar39;
              uVar44 = (uVar39 ^ *(ushort *)((longlong)piVar32 + 2)) & 0x7ff ^ uVar39;
              *(ushort *)(&stack0x000043cc + lVar17) = uVar44;
              piVar37 = (int *)(pbVar40 +
                               (ulonglong)((uVar39 >> 0xb & 7) * 2) + 4 + uVar43 +
                               ((ulonglong)uVar44 & 0x7ff) * 2);
              if (piVar37 < piVar32) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1027f6;
                func_0x(piVar32,0x19);
                uVar44 = *(ushort *)(&stack0x000043cc + lVar17);
                uVar43 = (ulonglong)*(ushort *)(&stack0x000043ca + lVar17);
                pbVar40 = *(byte **)(&stack0x000043a8 + lVar17);
                uVar48 = (ulonglong)*(uint *)(&stack0x000043a4 + lVar17);
              }
              if (uVar46 - uVar42 <
                  (((*(uint *)(&stack0x000043cc + lVar17) & 0x7ff) * 2 - (int)uVar43) -
                  *(int *)(&stack0x000043a8 + lVar17)) + (int)piVar37) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102848;
                func_0x(pbVar40 + uVar43,0x19);
                uVar44 = *(ushort *)(&stack0x000043cc + lVar17);
                uVar43 = (ulonglong)*(ushort *)(&stack0x000043ca + lVar17);
                pbVar40 = *(byte **)(&stack0x000043a8 + lVar17);
                uVar48 = (ulonglong)*(uint *)(&stack0x000043a4 + lVar17);
              }
              if (((uVar44 & 0x3800) != 0) &&
                 (piVar37 = (int *)(pbVar40 + uVar43 + 4), (uVar44 & 0x3800) != 0)) {
                do {
                  if ((uVar44 & 0x7ff) < (*(ushort *)piVar37 & 0x7ff)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1028c5;
                    func_0x(pbVar40 + uVar43,0x1a);
                    uVar44 = *(ushort *)(&stack0x000043cc + lVar17);
                    uVar43 = (ulonglong)*(ushort *)(&stack0x000043ca + lVar17);
                    pbVar40 = *(byte **)(&stack0x000043a8 + lVar17);
                  }
                  uVar45 = (int)uVar28 + 1;
                  uVar28 = (ulonglong)uVar45;
                  piVar37 = (int *)((longlong)piVar37 + 2);
                } while ((int)uVar45 < (int)(*(uint *)(&stack0x000043cc + lVar17) >> 0xb & 7));
                uVar48 = (ulonglong)*(uint *)(&stack0x000043a4 + lVar17);
              }
              break;
            }
            if (*(ushort *)(pbVar40 + (longlong)piVar37) < 0x400) break;
            *(ushort *)(&stack0x000043a2 + lVar17) = *(ushort *)(&stack0x000043a2 + lVar17) | 1;
            uVar39 = (short)uVar47 - 1;
            uVar47 = (ulonglong)uVar39;
            *(ushort *)(&stack0x000043bc + lVar17) = uVar39;
            if (uVar39 == 0) break;
          }
        }
        if ((*pbVar40 & 0x40) == 0) {
          *(undefined4 *)(&stack0x000043c6 + lVar17) = 0;
        }
        else {
          *(int *)(&stack0x000043c6 + lVar17) = (int)uVar48;
          *(int *)(&stack0x000043a4 + lVar17) = (int)uVar48 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102946;
          puVar23 = (ulonglong *)func_0x(&stack0x000043a2 + lVar17);
          uVar39 = (ushort)(*puVar23 >> 0x30);
          if ((((uint)(int)(short)uVar39 >> 1 ^ (int)(short)uVar39) & 0x2000) != 0) {
            if ((uVar39 >> 0xe & 1) == 0) {
              uVar39 = uVar39 & 0xdfff;
            }
            else {
              uVar39 = uVar39 | 0x2000;
            }
          }
          if (uVar39 == 0xfffc) {
            uVar33 = (uint)((*puVar23 >> 0x20 & 0xffff) >> 5);
          }
          uVar48 = (ulonglong)(*(int *)(&stack0x000043a4 + lVar17) + uVar33);
          *(uint *)(&stack0x000043a4 + lVar17) = *(int *)(&stack0x000043a4 + lVar17) + uVar33;
          pbVar40 = *(byte **)(&stack0x000043a8 + lVar17);
        }
        if ((*(byte **)(&stack0x000043be + lVar17) != (byte *)0x0) &&
           (*(byte **)(&stack0x000043be + lVar17) < pbVar40 + uVar48)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1029e2;
          cVar9 = func_0x(0x1a61f00);
          if (cVar9 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1029eb;
            cVar9 = func_0x();
            if (cVar9 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1029fb;
              cVar9 = func_0x(0x1a61f00);
              if (cVar9 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102a17;
                (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102a3b;
                (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x886);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102a4d;
          func_0x(*(undefined8 *)(&stack0x000043a8 + lVar17),0x12);
          pbVar40 = *(byte **)(&stack0x000043a8 + lVar17);
          uVar48 = (ulonglong)*(uint *)(&stack0x000043a4 + lVar17);
        }
        if (0x3f3b < (int)uVar48 - 1U) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102a78;
          cVar9 = func_0x(0x1a61f00);
          if (cVar9 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102a81;
            cVar9 = func_0x();
            if (cVar9 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102a91;
              cVar9 = func_0x(0x1a61f00);
              if (cVar9 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102aad;
                (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102ad1;
                (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x88b);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102ae3;
          func_0x(*(undefined8 *)(&stack0x000043a8 + lVar17),5);
          uVar48 = (ulonglong)*(uint *)(&stack0x000043a4 + lVar17);
          goto code_r0x00102aeb;
        }
      }
      else {
code_r0x00102aeb:
        pbVar40 = *(byte **)(&stack0x000043a8 + lVar17);
      }
code_r0x00102af3:
      if ((uint)uVar48 < 9) {
        bVar10 = *pbVar40 & 0xe;
joined_r0x00102b34:
        if ((bVar10 == 0) || (bVar10 == 0xc)) {
          uVar48 = 9;
        }
      }
    }
    else {
      if (uVar45 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102b17;
        func_0x(&stack0x000043a2 + lVar17);
        uVar48 = (ulonglong)*(uint *)(&stack0x000043a4 + lVar17);
      }
      pbVar40 = *(byte **)(&stack0x000043a8 + lVar17);
      if ((uint)uVar48 < 9) {
        bVar10 = *pbVar40 & 0x1c;
        goto joined_r0x00102b34;
      }
    }
    if ((*pbVar40 & 1) == 0) {
      param_2 = *(longlong *)(&stack0x00000030 + lVar17);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102ba7;
      func_0x(param_2,pbVar40,uVar48);
    }
    else if ((*pbVar40 & 1) == 1) {
      param_2 = *(longlong *)(&stack0x00000030 + lVar17);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102b92;
      func_0x(param_2,pbVar40,uVar48);
    }
    else {
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0x10cce70;
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102b78;
      (*pcRam0000000000fcfa80)(1,0x14d3200,0x152f2a8,0x10b);
      param_2 = *(longlong *)(&stack0x00000030 + lVar17);
    }
    pbVar40 = *(byte **)(&stack0x000043a8 + lVar17);
    if (*(short *)(&stack0x000043a0 + lVar17) == 0) {
      bVar10 = *pbVar40 >> 6;
    }
    else {
      bVar10 = *pbVar40 >> 1;
    }
    if ((bVar10 & 1) != 0) {
      if (*(short *)(&stack0x000043a0 + lVar17) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102bef;
        func_0x();
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102bf6;
        func_0x(&stack0x000043a2 + lVar17,&stack0x00000110 + lVar17);
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102c03;
      cVar9 = func_0x(&stack0x00000110 + lVar17);
      if (cVar9 == '\0') {
        uVar39 = *(ushort *)(&stack0x00000116 + lVar17);
        uVar42 = (uint)(int)(short)uVar39 >> 0xd & 1;
        uVar45 = (uint)(int)(short)uVar39 >> 0xe & 1;
        uVar44 = uVar39;
        if (uVar42 != uVar45) {
          if ((uVar39 & 0x4000) == 0) {
            uVar44 = uVar39 & 0xdfff;
          }
          else {
            uVar44 = uVar39 | 0x2000;
          }
        }
        if (uVar44 == 0xffff) {
code_r0x00102f09:
          if (*(short *)(&stack0x000043a0 + lVar17) == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102f29;
            func_0x();
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102f30;
            func_0x(&stack0x000043a2 + lVar17,&stack0x00000152 + lVar17);
          }
          uVar13 = *(undefined2 *)(&stack0x00000156 + lVar17);
          uVar14 = *(undefined4 *)(&stack0x00000152 + lVar17);
          uVar22 = 0x1388a10;
          goto code_r0x00102f47;
        }
        if (uVar42 != uVar45) {
          if ((uVar39 & 0x4000) == 0) {
            uVar39 = uVar39 & 0xdfff;
          }
          else {
            uVar39 = uVar39 | 0x2000;
          }
        }
        if (uVar39 == 0xfffd) goto code_r0x00102f09;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102ccb;
        cVar9 = func_0x(&stack0x00000110 + lVar17);
        if (cVar9 == '\0') {
          uVar22 = 0x10ee758;
          puVar38 = &stack0x00000110;
          piVar37 = *(int **)(&stack0x00000110 + lVar17);
          if ((int)(uint)piVar37 < 0) {
            uVar39 = *(ushort *)(&stack0x00000116 + lVar17);
            uVar45 = (uint)(int)(short)uVar39 >> 0xd & 1;
            uVar42 = (uint)(int)(short)uVar39 >> 0xe & 1;
            uVar44 = uVar39;
            if (uVar45 != uVar42) {
              if ((uVar39 >> 0xe & 1) == 0) {
                uVar44 = uVar39 & 0xdfff;
              }
              else {
                uVar44 = uVar39 | 0x2000;
              }
            }
            if (uVar44 == 0xfffc) {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102dfa;
              (*pcRam0000000000fcfa80)(1,0x14fc6a0,0x14d5e10,0x4ec);
            }
            uVar44 = uVar39;
            if (uVar45 != uVar42) {
              if ((uVar39 >> 0xe & 1) == 0) {
                uVar44 = uVar39 & 0xdfff;
              }
              else {
                uVar44 = uVar39 | 0x2000;
              }
            }
            if (uVar44 == 0xfffc) {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102e47;
              (*pcRam0000000000fcfa80)(1,0x14fc6a0,0x14d5e10,0x4ec);
            }
            uVar33 = (uint)piVar37 & 0x7fffffff;
            piVar37 = (int *)(ulonglong)uVar33;
            if (uVar45 != uVar42) {
              if ((uVar39 >> 0xe & 1) == 0) {
                uVar39 = uVar39 & 0xdfff;
              }
              else {
                uVar39 = uVar39 | 0x2000;
              }
            }
            *(uint *)(&stack0x00000188 + lVar17) = uVar33;
            *(undefined2 *)(&stack0x0000018c + lVar17) = *(undefined2 *)(&stack0x00000114 + lVar17);
            *(ushort *)(&stack0x0000018e + lVar17) = uVar39;
            puVar38 = &stack0x00000188;
            uVar22 = 0x1388958;
          }
          puVar25 = (undefined4 *)(puVar38 + lVar17);
          if (*(short *)(&stack0x000043a0 + lVar17) == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102eb7;
            func_0x();
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102ebe;
            func_0x(&stack0x000043a2 + lVar17,&stack0x0000014c + lVar17);
          }
          sVar12 = *(short *)((longlong)puVar25 + 6);
          uVar39 = *(ushort *)(puVar25 + 1);
          uVar8 = *(uint6 *)(&stack0x0000014c + lVar17);
          *(undefined8 *)((longlong)auStackX_8 + lVar17 + -8) = uVar22;
          *(int *)(&stack0xfffffffffffffff8 + lVar17) = (int)sVar12;
          *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = *puVar25;
          *(uint *)(&stack0xffffffffffffffe8 + lVar17) = (uint)uVar39;
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102f07;
          (*pcRam0000000000fce630)(param_2,0x1388798,0x1388880,(ulonglong)uVar8);
        }
        else {
          *(undefined8 *)(&stack0x00004518 + lVar17) = 0;
          *(undefined2 *)(&stack0x00004520 + lVar17) = 0;
          if (*(short *)(&stack0x000043a0 + lVar17) == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102d07;
            func_0x();
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102d0e;
            func_0x(&stack0x000043a2 + lVar17,&stack0x00000146 + lVar17);
          }
          piVar37 = (int *)(ulonglong)*(uint6 *)(&stack0x00000146 + lVar17);
          *(undefined **)(&stack0xffffffffffffffe8 + lVar17) = &stack0x00004518 + lVar17;
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102d4c;
          uVar22 = func_0x
                             (&stack0x00000110 + lVar17,*(undefined8 *)(&stack0x00000198 + lVar17),0
                              ,0);
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = uVar22;
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102d6b;
          (*pcRam0000000000fce630)(param_2,0x1388798,0x1388960,piVar37);
        }
      }
      else {
        if (*(short *)(&stack0x000043a0 + lVar17) == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102c27;
          func_0x();
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102c2e;
          func_0x(&stack0x000043a2 + lVar17,&stack0x00000140 + lVar17);
        }
        uVar13 = *(undefined2 *)(&stack0x00000144 + lVar17);
        uVar14 = *(undefined4 *)(&stack0x00000140 + lVar17);
        uVar22 = 0x13887d0;
code_r0x00102f47:
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102f5e;
        (*pcRam0000000000fce630)(param_2,0x1388798,uVar22,(ulonglong)CONCAT24(uVar13,uVar14));
      }
      pbVar40 = *(byte **)(&stack0x000043a8 + lVar17);
    }
    if (*(short *)(&stack0x000043a0 + lVar17) == 0) {
      bVar49 = (*pbVar40 & 0xe) == 4;
    }
    else {
      bVar49 = (*pbVar40 & 0x1c) == 8;
    }
    if (bVar49) {
      if (*(short *)(&stack0x000043a0 + lVar17) == 0) {
        piVar37 = *(int **)(pbVar40 + 1);
        sVar12 = (short)((ulonglong)piVar37 >> 0x30);
        uVar39 = (ushort)((ulonglong)piVar37 >> 0x20);
      }
      else if ((int **)(pbVar40 + 1) == (int **)0x0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102fcc;
        puVar25 = (undefined4 *)(*pcRam0000000000fcfe20)();
        *puVar25 = 0x16;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102fd8;
        (*pcRam0000000000fcfe38)();
        sVar12 = 0;
        piVar37 = (int *)0x0;
        uVar39 = uVar26;
      }
      else {
        piVar37 = *(int **)(pbVar40 + 1);
        sVar12 = (short)((ulonglong)piVar37 >> 0x30);
        uVar39 = (ushort)((ulonglong)piVar37 >> 0x20);
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x102fea;
      uVar22 = (*pcRam0000000000fcfa00)();
      *(int *)(&stack0xfffffffffffffff8 + lVar17) = (int)sVar12;
      *(int *)(&stack0xfffffffffffffff0 + lVar17) = (int)piVar37;
      *(uint *)(&stack0xffffffffffffffe8 + lVar17) = (uint)uVar39;
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103013;
      iVar15 = func_0x(&stack0x00005f68 + lVar17,0x80,0x1388b50,uVar22);
      if (iVar15 < 0) {
        *(int *)(&stack0xfffffffffffffff8 + lVar17) = iVar15;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = 0x31e;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0x1388720;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103047;
        (*pcRam0000000000fcfa88)(4,7,0x10,1);
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103066;
      iVar15 = (*pcRam0000000000fce630)(param_2,0x1388b30,0x119fe3c,&stack0x00005f68 + lVar17);
      if (iVar15 != 0) {
        pbVar40 = *(byte **)(&stack0x000043a8 + lVar17);
        goto code_r0x00103161;
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10307c;
      (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
      if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10308d;
        lVar18 = func_0x();
        *(undefined8 *)(lVar18 + 0x110) = 0;
        if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1030a9;
          func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
        }
        *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
      }
      lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
      if (lVar18 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1030c6;
        func_0x(lVar18);
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1030d4;
        (*_DAT_)(lVar18,0xc0);
        *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
        *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
      }
      if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
        pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1030fe;
        (*pcVar4)();
        *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
        *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
      }
      puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
      if (puVar5 != (undefined8 *)0x0) {
        pcVar4 = *(code **)*puVar5;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103123;
        (*pcVar4)(puVar5,1);
        *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
      }
      if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
        pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10313e;
        (*pcVar4)();
        *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103153;
      func_0x(&stack0x00004320 + lVar17);
code_r0x00105772:
      puVar5 = *(undefined8 **)(&stack0x00000048 + lVar17);
      if (puVar5 != (undefined8 *)0x0) {
        pcVar4 = *(code **)*puVar5;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105787;
        (*pcVar4)(puVar5,1);
      }
      goto LAB_;
    }
code_r0x00103161:
    if (*(short *)(&stack0x000043a0 + lVar17) == 0) {
      if ((*pbVar40 & 0xe) == 2) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10318e;
        ppiVar24 = (int **)func_0x(&stack0x000043a2 + lVar17);
code_r0x001031b1:
        if (ppiVar24 == (int **)0x0) {
          piVar37 = (int *)0x0;
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1031d1;
          puVar25 = (undefined4 *)(*pcRam0000000000fcfe20)();
          *puVar25 = 0x16;
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1031dd;
          (*pcRam0000000000fcfe38)();
          uVar45 = 0;
        }
        else {
          piVar37 = *ppiVar24;
          uVar26 = (ushort)((ulonglong)piVar37 >> 0x30);
          uVar45 = (uint)((ulonglong)piVar37 >> 0x20);
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1031f0;
        uVar22 = (*pcRam0000000000fcfa00)();
        *(int *)(&stack0xfffffffffffffff8 + lVar17) = (int)(short)uVar26;
        *(int *)(&stack0xfffffffffffffff0 + lVar17) = (int)piVar37;
        *(uint *)(&stack0xffffffffffffffe8 + lVar17) = uVar45 & 0xffff;
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103219;
        iVar15 = func_0x(&stack0x00005f68 + lVar17,0x80,0x1388b50,uVar22);
        if (iVar15 < 0) {
          *(int *)(&stack0xfffffffffffffff8 + lVar17) = iVar15;
          *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = 0x333;
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0x1388720;
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10324d;
          (*pcRam0000000000fcfa88)(4,7,0x10,1);
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10326c;
        iVar15 = (*pcRam0000000000fce630)(param_2,0x1388b10,0x119fe3c,&stack0x00005f68 + lVar17);
        if (iVar15 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103282;
          (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
          if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103293;
            lVar18 = func_0x();
            *(undefined8 *)(lVar18 + 0x110) = 0;
            if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1032af;
              func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
            }
            *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
          }
          lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
          if (lVar18 != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1032cc;
            func_0x(lVar18);
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1032da;
            (*_DAT_)(lVar18,0xc0);
            *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
            *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
          }
          if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
            pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103304;
            (*pcVar4)();
            *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
            *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
          }
          puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
          if (puVar5 != (undefined8 *)0x0) {
            pcVar4 = *(code **)*puVar5;
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103329;
            (*pcVar4)(puVar5,1);
            *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
          }
          if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
            pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103344;
            (*pcVar4)();
            *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103359;
          func_0x(&stack0x00004320 + lVar17);
          goto code_r0x00105772;
        }
      }
    }
    else if (((*pbVar40 & 0x1c) - 0x10 & 0xfffffffb) == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1031b1;
      ppiVar24 = (int **)func_0x(&stack0x000043a2 + lVar17);
      goto code_r0x001031b1;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103368;
    (*_DAT_)(param_2);
    if (*(short *)(&stack0x000043a0 + lVar17) == 0) {
      bVar10 = **(byte **)(&stack0x000043a8 + lVar17);
      bVar11 = bVar10 & 0xe;
      if (bVar11 == 2) {
        if (((*(byte **)(&stack0x000043a8 + lVar17))[1] & 1) == 0) {
code_r0x0010340f:
          bVar49 = bVar11 == 4;
          goto code_r0x0010343a;
        }
      }
      else if (bVar11 != 0xe) goto code_r0x0010340f;
    }
    else {
      bVar10 = **(byte **)(&stack0x000043a8 + lVar17);
      bVar11 = bVar10 & 0x1c;
      if ((bVar11 == 0x14) || ((bVar11 == 4 && ((bVar10 & 2) != 0)))) goto code_r0x00103395;
      bVar49 = bVar11 == 8;
code_r0x0010343a:
      if (!bVar49) {
        if (*(short *)(&stack0x000043a0 + lVar17) == 0) {
          if ((1 << (bVar10 & 0xe) & 0x440U) == 0) {
code_r0x00103480:
            while( true ) {
              uVar28 = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103495;
              iVar15 = func_0x(&stack0x000042a8 + lVar17);
              sVar12 = 0;
              if (iVar15 == 0) break;
              puVar25 = *(undefined4 **)(&stack0x000022e0 + lVar17);
              *(undefined4 **)(&stack0x00000118 + lVar17) = puVar25;
              uVar45 = *(uint *)(&stack0x00004288 + lVar17);
              piVar37 = (int *)(ulonglong)uVar45;
              pbVar40 = *(byte **)(&stack0x00000330 + lVar17);
              uVar42 = *(uint *)(&stack0x000022d8 + lVar17);
              piVar32 = (int *)(ulonglong)uVar42;
              *(uint *)(&stack0x000000f8 + lVar17) = uVar42;
              *(uint *)(&stack0x00000100 + lVar17) = uVar42;
              *(undefined8 *)(&stack0x00000040 + lVar17) =
                   *(undefined8 *)(&stack0x00004290 + lVar17);
              *(undefined8 *)(&stack0x00000138 + lVar17) =
                   *(undefined8 *)(&stack0x00004290 + lVar17);
              lVar18 = *(longlong *)(&stack0x00000328 + lVar17);
              uVar14 = *(undefined4 *)(lVar18 + 0x3c);
              if (puVar25 == (undefined4 *)0x0) {
                if (-1 < *(char *)(lVar18 + 0x21)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103513;
                  (*_DAT_)(&stack0x000051a8 + lVar17);
                  *(undefined8 *)((longlong)auStackX_8 + lVar17 + -8) = 0;
                  *(undefined8 *)(&stack0xfffffffffffffff8 + lVar17) = 0;
                  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar17) = 0;
                  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) = uVar14;
                  param_2 = *(longlong *)(&stack0x00000030 + lVar17);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10354a;
                  (*pcRam0000000000fce620)
                            (&stack0x000051a8 + lVar17,param_2,0x1388a90,
                             *(undefined4 *)(&stack0x00000028 + lVar17));
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103566;
                  iVar15 = (*pcRam0000000000fce630)
                                     (param_2,*(undefined8 *)(&stack0x00000040 + lVar17),0x1388c40);
                  puVar38 = &stack0x000051a8 + lVar17;
                  piVar37 = piVar32;
                  if (iVar15 != 0) goto code_r0x001054fa;
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10357d;
                  (*pcRam0000000000fcf790)();
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10358c;
                  (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
                  if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10359c;
                    lVar18 = func_0x();
                    *(undefined8 *)(lVar18 + 0x110) = 0;
                    if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1035b8;
                      func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
                    }
                    *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
                  }
                  lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
                  if (lVar18 != 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1035d5;
                    func_0x(lVar18);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1035e3;
                    (*_DAT_)(lVar18,0xc0);
                    *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
                    *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
                  }
                  if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
                    pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10360d;
                    (*pcVar4)();
                    *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
                    *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
                  }
                  puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
                  if (puVar5 != (undefined8 *)0x0) {
                    pcVar4 = *(code **)*puVar5;
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103632;
                    (*pcVar4)(puVar5,1);
                    *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
                  }
                  if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
                    pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10364d;
                    (*pcVar4)();
                    *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103662;
                  func_0x(&stack0x00004320 + lVar17);
                  goto code_r0x00105772;
                }
                param_2 = *(longlong *)(&stack0x00000030 + lVar17);
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10556a;
                (*_DAT_)(param_2);
                piVar37 = piVar32;
              }
              else if (*(short *)(lVar18 + 0x38) == -1) {
code_r0x00104248:
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104258;
                iVar15 = func_0x(&stack0x000043a0 + lVar17,lVar18);
                if (iVar15 == 0) {
                  if (8 < uVar42) {
                    piVar37 = (int *)0x10d69d8;
                    if (*(char *)(*(longlong *)(&stack0x00000328 + lVar17) + 0x21) < '\0') {
                      piVar37 = (int *)0x1388770;
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1044e5;
                    uVar22 = (*pcRam0000000000fcfa00)();
                    *(uint *)((longlong)auStackX_8 + lVar17 + 0x10) = uVar45;
                    *(undefined4 *)((longlong)auStackX_8 + lVar17 + 8) =
                         *(undefined4 *)(&stack0x000000f8 + lVar17);
                    *(undefined4 *)((longlong)auStackX_8 + lVar17) =
                         *(undefined4 *)(&stack0x0000428c + lVar17);
                    *(int **)((longlong)auStackX_8 + lVar17 + -8) = piVar37;
                    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar17) = uVar14;
                    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) =
                         *(undefined4 *)(&stack0x00000028 + lVar17);
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) =
                         *(undefined8 *)(&stack0x00000040 + lVar17);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104537;
                    iVar15 = func_0x
                                       (&stack0x00008a78 + lVar17,0x200,0x1388d20,uVar22);
                    if (iVar15 < 0) {
                      *(int *)(&stack0xfffffffffffffff8 + lVar17) = iVar15;
                      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = 0x3b7;
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0x1388720;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10456b;
                      (*pcRam0000000000fcfa88)(4,7,0x10,1);
                    }
                    puVar38 = &stack0x00008a78;
                    goto code_r0x00104573;
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104277;
                  (*_DAT_)(&stack0x000053b8 + lVar17);
                  uVar22 = 0x10d69d8;
                  if (*(char *)(*(longlong *)(&stack0x00000328 + lVar17) + 0x21) < '\0') {
                    uVar22 = 0x1388770;
                  }
                  *(uint *)((longlong)auStackX_8 + lVar17 + 8) = uVar45;
                  *(uint *)((longlong)auStackX_8 + lVar17) = uVar45;
                  *(undefined4 *)((longlong)auStackX_8 + lVar17 + -8) =
                       *(undefined4 *)(&stack0x0000428c + lVar17);
                  *(undefined8 *)(&stack0xfffffffffffffff8 + lVar17) = uVar22;
                  *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = uVar14;
                  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) =
                       *(undefined4 *)(&stack0x00000028 + lVar17);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1042da;
                  (*pcRam0000000000fce620)
                            (&stack0x000053b8 + lVar17,*(undefined8 *)(&stack0x00000030 + lVar17),
                             0x1388b90,*(undefined8 *)(&stack0x00000040 + lVar17));
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1042e0;
                  uVar22 = (*pcRam0000000000fcfa00)();
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1042fc;
                  func_0x(&stack0x00006668 + lVar17,0x2002,0x1388b8c,uVar22);
                  lVar18 = -1;
                  do {
                    lVar18 = lVar18 + 1;
                  } while ((&stack0x00006669)[lVar18 + lVar17 + -1] != '\0');
                  puVar38 = &stack0x00006669 + lVar18 + lVar17 + -1;
                  piVar37 = piVar32;
                  if (uVar42 != 0) {
                    uVar45 = *(uint *)(&stack0x000000f8 + lVar17);
                    do {
                      bVar10 = *pbVar40;
                      piVar37 = (int *)(ulonglong)bVar10;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10434b;
                      uVar22 = (*pcRam0000000000fcfa00)();
                      *(uint *)(&stack0xffffffffffffffe8 + lVar17) = (uint)bVar10;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10436c;
                      iVar15 = func_0x
                                         (puVar38,&stack0x0000866a + (lVar17 - (longlong)puVar38),
                                          0x1388b84,uVar22);
                      if (iVar15 < 0) break;
                      lVar18 = -1;
                      do {
                        lVar18 = lVar18 + 1;
                      } while (puVar38[lVar18] != '\0');
                      puVar38 = puVar38 + lVar18;
                      if (&stack0x0000866a + lVar17 <= puVar38) break;
                      uVar42 = (int)uVar28 + 1;
                      uVar28 = (ulonglong)uVar42;
                      pbVar40 = pbVar40 + 1;
                    } while (uVar42 < uVar45);
                  }
                  param_2 = *(longlong *)(&stack0x00000030 + lVar17);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1043bb;
                  iVar15 = (*pcRam0000000000fce630)
                                     (param_2,*(undefined8 *)(&stack0x00000040 + lVar17),0x119fe54);
                  puVar38 = &stack0x000053b8 + lVar17;
                  if (iVar15 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1043d2;
                    (*pcRam0000000000fcf790)(puVar38);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1043e1;
                    (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
                    if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1043f2;
                      lVar18 = func_0x();
                      *(undefined8 *)(lVar18 + 0x110) = 0;
                      if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10440e;
                        func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
                      }
                      *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
                    }
                    lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
                    if (lVar18 != 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10442b;
                      func_0x(lVar18);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104439;
                      (*_DAT_)(lVar18,0xc0);
                      *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
                      *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
                    }
                    if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
                      pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104463;
                      (*pcVar4)();
                      *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
                      *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
                    }
                    puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
                    if (puVar5 != (undefined8 *)0x0) {
                      pcVar4 = *(code **)*puVar5;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104488;
                      (*pcVar4)(puVar5,1);
                      *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
                    }
                    if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
                      pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1044a3;
                      (*pcVar4)();
                      *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1044b8;
                    func_0x(&stack0x00004320 + lVar17);
                    goto code_r0x00105772;
                  }
code_r0x001054fa:
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105500;
                  (*pcRam0000000000fcf790)(puVar38);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105509;
                  (*_DAT_)(param_2);
                }
                else {
                  if ((uVar45 != 0x10) || (bVar49 = true, *(short *)puVar25 != 0)) {
                    bVar49 = false;
                  }
                  uVar26 = 0;
                  if (bVar49) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1045c4;
                    (*_DAT_)(&stack0x00004d88 + lVar17);
                    uVar22 = 0x10d69d8;
                    if (*(char *)(*(longlong *)(&stack0x00000328 + lVar17) + 0x21) < '\0') {
                      uVar22 = 0x1388770;
                    }
                    *(uint *)((longlong)auStackX_8 + lVar17 + 8) = uVar45;
                    *(uint *)((longlong)auStackX_8 + lVar17) = uVar45;
                    *(undefined4 *)((longlong)auStackX_8 + lVar17 + -8) =
                         *(undefined4 *)(&stack0x0000428c + lVar17);
                    *(undefined8 *)(&stack0xfffffffffffffff8 + lVar17) = uVar22;
                    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = uVar14;
                    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) =
                         *(undefined4 *)(&stack0x00000028 + lVar17);
                    param_2 = *(longlong *)(&stack0x00000030 + lVar17);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10462a;
                    (*pcRam0000000000fce620)
                              (&stack0x00004d88 + lVar17,param_2,0x1388c70,
                               *(undefined8 *)(&stack0x00000040 + lVar17));
                    if ((int **)(puVar25 + 2) == (int **)0x0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10464c;
                      puVar25 = (undefined4 *)(*pcRam0000000000fcfe20)();
                      *puVar25 = 0x16;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104658;
                      (*pcRam0000000000fcfe38)();
                      piVar37 = (int *)0x0;
                    }
                    else {
                      piVar37 = *(int **)(puVar25 + 2);
                      sVar12 = (short)((ulonglong)piVar37 >> 0x30);
                      uVar26 = (ushort)((ulonglong)piVar37 >> 0x20);
                    }
                    uVar22 = **(undefined8 **)(&stack0x00000118 + lVar17);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104681;
                    iVar15 = (*pcRam0000000000fcfaa8)(param_2,0x1388c60,0x12fe068,uVar22);
                    if (iVar15 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104697;
                      (*pcRam0000000000fcf790)(&stack0x00004d88 + lVar17);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1046a6;
                      (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
                      if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1046b7;
                        lVar18 = func_0x();
                        *(undefined8 *)(lVar18 + 0x110) = 0;
                        if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1046d3;
                          func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
                        }
                        *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
                      }
                      lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
                      if (lVar18 != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1046f0;
                        func_0x(lVar18);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1046fe;
                        (*_DAT_)(lVar18,0xc0);
                        *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
                        *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
                      }
                      if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
                        pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104728;
                        (*pcVar4)();
                        *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
                        *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
                      }
                      puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
                      if (puVar5 != (undefined8 *)0x0) {
                        pcVar4 = *(code **)*puVar5;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10474d;
                        (*pcVar4)(puVar5,1);
                        *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
                      }
                      if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
                        pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104768;
                        (*pcVar4)();
                        *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10477d;
                      func_0x(&stack0x00004320 + lVar17);
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104790;
                      uVar22 = (*pcRam0000000000fcfa00)();
                      *(int *)(&stack0xfffffffffffffff8 + lVar17) = (int)sVar12;
                      *(int *)(&stack0xfffffffffffffff0 + lVar17) = (int)piVar37;
                      *(uint *)(&stack0xffffffffffffffe8 + lVar17) = (uint)uVar26;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1047b9;
                      iVar15 = func_0x
                                         (&stack0x00005e68 + lVar17,0x80,0x13837d0,uVar22);
                      if (iVar15 < 0) {
                        *(int *)(&stack0xfffffffffffffff8 + lVar17) = iVar15;
                        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = 0x3e0;
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0x1388720;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1047ed;
                        (*pcRam0000000000fcfa88)(4,7,0x10,1);
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10480c;
                      iVar15 = (*pcRam0000000000fcfaa8)(param_2,0x1388c54,0x13646ec);
                      puVar38 = &stack0x00004d88 + lVar17;
                      if (iVar15 != 0) goto code_r0x001054fa;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104823;
                      (*pcRam0000000000fcf790)(puVar38);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104832;
                      (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
                      if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104843;
                        lVar18 = func_0x();
                        *(undefined8 *)(lVar18 + 0x110) = 0;
                        if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10485f;
                          func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
                        }
                        *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
                      }
                      lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
                      if (lVar18 != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10487c;
                        func_0x(lVar18);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10488a;
                        (*_DAT_)(lVar18,0xc0);
                        *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
                        *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
                      }
                      if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
                        pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1048b4;
                        (*pcVar4)();
                        *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
                        *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
                      }
                      puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
                      if (puVar5 != (undefined8 *)0x0) {
                        pcVar4 = *(code **)*puVar5;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1048d9;
                        (*pcVar4)(puVar5,1);
                        *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
                      }
                      if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
                        pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1048f4;
                        (*pcVar4)();
                        *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104909;
                      func_0x(&stack0x00004320 + lVar17);
                    }
                    goto code_r0x00105772;
                  }
                  if (uVar45 < 0xd) {
code_r0x00104957:
                    if (0xc < uVar45) {
                      uVar48 = (ulonglong)(piVar37 + -3) / 0xc;
                      if ((((uint)uVar48 < 0x1f9) && (*(short *)puVar25 == 2)) &&
                         (piVar37 + -3 == (int *)(uVar48 * 0xc))) goto code_r0x0010499c;
                    }
                    if ((uVar45 < 0x30) || (bVar49 = true, *(short *)puVar25 != 3)) {
                      bVar49 = false;
                    }
                    if (bVar49) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10538b;
                      (*_DAT_)(&stack0x000059e8 + lVar17);
                      uVar22 = 0x10d69d8;
                      if (*(char *)(*(longlong *)(&stack0x00000328 + lVar17) + 0x21) < '\0') {
                        uVar22 = 0x1388770;
                      }
                      *(uint *)((longlong)auStackX_8 + lVar17) = uVar45;
                      *(undefined4 *)((longlong)auStackX_8 + lVar17 + -8) =
                           *(undefined4 *)(&stack0x0000428c + lVar17);
                      *(undefined8 *)(&stack0xfffffffffffffff8 + lVar17) = uVar22;
                      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = uVar14;
                      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) =
                           *(undefined4 *)(&stack0x00000028 + lVar17);
                      param_2 = *(longlong *)(&stack0x00000030 + lVar17);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1053ed;
                      (*pcRam0000000000fce620)
                                (&stack0x000059e8 + lVar17,param_2,0x1388f80,
                                 *(undefined8 *)(&stack0x00000040 + lVar17));
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1053f6;
                      (*_DAT_)(param_2);
                      sVar12 = *(short *)puVar25;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105411;
                      (*pcRam0000000000fcfaa8)(param_2,0x13831a0,0x12fd078,sVar12);
                      uVar2 = *(undefined *)((longlong)puVar25 + 0x23);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10542d;
                      (*pcRam0000000000fcfaa8)(param_2,0x1383198,0x12fd078,uVar2);
                      uVar14 = puVar25[1];
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105448;
                      (*pcRam0000000000fcfaa8)(param_2,0x1383254,0x134ffa8,uVar14);
                      uVar14 = puVar25[6];
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105463;
                      (*pcRam0000000000fcfaa8)(param_2,0x1383248,0x134ffa8,uVar14);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10547c;
                      func_0x(puVar25 + 9,&stack0x00005e08 + lVar17,
                                      &stack0x00000130 + lVar17);
                      *(uint *)(&stack0xfffffffffffffff8 + lVar17) =
                           (uint)*(ushort *)(puVar25 + 0xb);
                      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = puVar25[10];
                      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) = puVar25[9];
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1054b4;
                      (*pcRam0000000000fcfaa8)
                                (param_2,0x1383228,0x1383238,&stack0x00005e08 + lVar17);
                      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) = puVar25[7];
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1054d8;
                      (*pcRam0000000000fcfaa8)(param_2,0x138325c,0x1365150);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1054e8;
                      (*pcRam0000000000fce690)(param_2,0x12c0d80);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1054f1;
                      (*_DAT_)(param_2);
                      puVar38 = &stack0x000059e8 + lVar17;
                      goto code_r0x001054fa;
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10551c;
                    (*_DAT_)(&stack0x00005bf8 + lVar17);
                    param_2 = *(longlong *)(&stack0x00000030 + lVar17);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10553f;
                    (*pcRam0000000000fce620)(&stack0x00005bf8 + lVar17,param_2,0x1388f48);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10554e;
                    (*pcRam0000000000fcf790)(&stack0x00005bf8 + lVar17);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105557;
                    (*_DAT_)(param_2);
                  }
                  else {
                    uVar48 = (ulonglong)(piVar37 + -3) / 0xc;
                    if ((0x1f8 < (uint)uVar48) ||
                       (((*(short *)puVar25 != 1 && (*(short *)puVar25 != 4)) ||
                        (piVar37 + -3 != (int *)(uVar48 * 0xc))))) goto code_r0x00104957;
code_r0x0010499c:
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1049aa;
                    (*_DAT_)(&stack0x00004758 + lVar17);
                    uVar22 = 0x10d69d8;
                    if (*(char *)(*(longlong *)(&stack0x00000328 + lVar17) + 0x21) < '\0') {
                      uVar22 = 0x1388770;
                    }
                    *(uint *)((longlong)auStackX_8 + lVar17 + 8) = uVar45;
                    *(uint *)((longlong)auStackX_8 + lVar17) = uVar45;
                    *(undefined4 *)((longlong)auStackX_8 + lVar17 + -8) =
                         *(undefined4 *)(&stack0x0000428c + lVar17);
                    *(undefined8 *)(&stack0xfffffffffffffff8 + lVar17) = uVar22;
                    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = uVar14;
                    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) =
                         *(undefined4 *)(&stack0x00000028 + lVar17);
                    param_2 = *(longlong *)(&stack0x00000030 + lVar17);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104a10;
                    (*pcRam0000000000fce620)
                              (&stack0x00004758 + lVar17,param_2,0x1388df0,
                               *(undefined8 *)(&stack0x00000040 + lVar17));
                    uVar2 = *(undefined *)((longlong)puVar25 + 2);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104a2c;
                    iVar15 = (*pcRam0000000000fcfaa8)(param_2,0x1388de4,0x12fd078,uVar2);
                    if (iVar15 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104a42;
                      (*pcRam0000000000fcf790)(&stack0x00004758 + lVar17);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104a51;
                      (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
                      if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104a62;
                        lVar18 = func_0x();
                        *(undefined8 *)(lVar18 + 0x110) = 0;
                        if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104a7e;
                          func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
                        }
                        *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
                      }
                      lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
                      if (lVar18 != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104a9b;
                        func_0x(lVar18);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104aa9;
                        (*_DAT_)(lVar18,0xc0);
                        *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
                        *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
                      }
                      if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
                        pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104ad3;
                        (*pcVar4)();
                        *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
                        *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
                      }
                      puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
                      if (puVar5 != (undefined8 *)0x0) {
                        pcVar4 = *(code **)*puVar5;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104af8;
                        (*pcVar4)(puVar5,1);
                        *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
                      }
                      if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
                        pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104b13;
                        (*pcVar4)();
                        *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104b28;
                      func_0x(&stack0x00004320 + lVar17);
                      goto code_r0x00105772;
                    }
                    uVar2 = *(undefined *)((longlong)puVar25 + 3);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104b4a;
                    iVar15 = (*pcRam0000000000fcfaa8)(param_2,0x137a090,0x12fd078,uVar2);
                    if (iVar15 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104b60;
                      (*pcRam0000000000fcf790)(&stack0x00004758 + lVar17);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104b6f;
                      (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
                      if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104b80;
                        lVar18 = func_0x();
                        *(undefined8 *)(lVar18 + 0x110) = 0;
                        if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104b9c;
                          func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
                        }
                        *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
                      }
                      lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
                      if (lVar18 != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104bb9;
                        func_0x(lVar18);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104bc7;
                        (*_DAT_)(lVar18,0xc0);
                        *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
                        *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
                      }
                      if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
                        pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104bf1;
                        (*pcVar4)();
                        *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
                        *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
                      }
                      puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
                      if (puVar5 != (undefined8 *)0x0) {
                        pcVar4 = *(code **)*puVar5;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104c16;
                        (*pcVar4)(puVar5,1);
                        *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
                      }
                      if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
                        pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104c31;
                        (*pcVar4)();
                        *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104c46;
                      func_0x(&stack0x00004320 + lVar17);
                      goto code_r0x00105772;
                    }
                    uVar14 = puVar25[1];
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104c67;
                    iVar15 = (*pcRam0000000000fcfaa8)(param_2,0x1383248,0x12fd078,uVar14);
                    if (iVar15 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104c7d;
                      (*pcRam0000000000fcf790)(&stack0x00004758 + lVar17);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104c8c;
                      (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
                      if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104c9d;
                        lVar18 = func_0x();
                        *(undefined8 *)(lVar18 + 0x110) = 0;
                        if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104cb9;
                          func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
                        }
                        *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
                      }
                      lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
                      if (lVar18 != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104cd6;
                        func_0x(lVar18);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104ce4;
                        (*_DAT_)(lVar18,0xc0);
                        *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
                        *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
                      }
                      if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
                        pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104d0e;
                        (*pcVar4)();
                        *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
                        *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
                      }
                      puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
                      if (puVar5 != (undefined8 *)0x0) {
                        pcVar4 = *(code **)*puVar5;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104d33;
                        (*pcVar4)(puVar5,1);
                        *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
                      }
                      if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
                        pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104d4e;
                        (*pcVar4)();
                        *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104d63;
                      func_0x(&stack0x00004320 + lVar17);
                      goto code_r0x00105772;
                    }
                    *(ulonglong *)(&stack0x000001a0 + lVar17) = (ulonglong)(uint)puVar25[2] << 0x10;
                    *(undefined2 *)(&stack0x000001a0 + lVar17) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104da0;
                    iVar15 = (*pcRam0000000000fcfaa8)
                                       (param_2,0x1388dd8,0x12fe068,
                                        *(undefined8 *)(&stack0x000001a0 + lVar17));
                    if (iVar15 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104db6;
                      (*pcRam0000000000fcf790)(&stack0x00004758 + lVar17);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104dc5;
                      (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
                      if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104dd6;
                        lVar18 = func_0x();
                        *(undefined8 *)(lVar18 + 0x110) = 0;
                        if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104df2;
                          func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
                        }
                        *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
                      }
                      lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
                      if (lVar18 != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104e0f;
                        func_0x(lVar18);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104e1d;
                        (*_DAT_)(lVar18,0xc0);
                        *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
                        *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
                      }
                      if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
                        pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104e47;
                        (*pcVar4)();
                        *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
                        *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
                      }
                      puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
                      if (puVar5 != (undefined8 *)0x0) {
                        pcVar4 = *(code **)*puVar5;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104e6c;
                        (*pcVar4)(puVar5,1);
                        *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
                      }
                      if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
                        pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104e87;
                        (*pcVar4)();
                        *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104e9c;
                      func_0x(&stack0x00004320 + lVar17);
                      goto code_r0x00105772;
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104ebd;
                    iVar15 = (*pcRam0000000000fcfaa8)(param_2,0x1388dd0,0x12fd078);
                    if (iVar15 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104ed3;
                      (*pcRam0000000000fcf790)(&stack0x00004758 + lVar17);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104ee2;
                      (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
                      if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104ef3;
                        lVar18 = func_0x();
                        *(undefined8 *)(lVar18 + 0x110) = 0;
                        if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104f0f;
                          func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
                        }
                        *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
                      }
                      lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
                      if (lVar18 != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104f2c;
                        func_0x(lVar18);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104f3a;
                        (*_DAT_)(lVar18,0xc0);
                        *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
                        *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
                      }
                      if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
                        pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104f64;
                        (*pcVar4)();
                        *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
                        *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
                      }
                      puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
                      if (puVar5 != (undefined8 *)0x0) {
                        pcVar4 = *(code **)*puVar5;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104f89;
                        (*pcVar4)(puVar5,1);
                        *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
                      }
                      if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
                        pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104fa4;
                        (*pcVar4)();
                        *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104fb9;
                      func_0x(&stack0x00004320 + lVar17);
                      goto code_r0x00105772;
                    }
                    *(ulonglong *)(&stack0x00000040 + lVar17) = (ulonglong)(piVar37 + -3) / 0xc;
                    puVar7 = puVar25;
                    if ((int)((ulonglong)(piVar37 + -3) / 0xc) != 0) {
                      do {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104ffe;
                        (*_DAT_)(&stack0x00004f98 + lVar17);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10501c;
                        (*pcRam0000000000fce620)
                                  (&stack0x00004f98 + lVar17,
                                   *(undefined8 *)(&stack0x00000030 + lVar17),0x1389008,uVar28);
                        if ((int **)(puVar25 + uVar28 * 3 + 4) == (int **)0x0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105049;
                          puVar25 = (undefined4 *)(*pcRam0000000000fcfe20)();
                          *puVar25 = 0x16;
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105055;
                          (*pcRam0000000000fcfe38)();
                          piVar37 = (int *)0x0;
                          uVar39 = uVar26;
                          uVar44 = uVar26;
                        }
                        else {
                          piVar37 = *(int **)(puVar25 + uVar28 * 3 + 4);
                          uVar39 = (ushort)((ulonglong)piVar37 >> 0x30);
                          uVar44 = (ushort)((ulonglong)piVar37 >> 0x20);
                        }
                        uVar14 = puVar7[3];
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105079;
                        iVar15 = (*pcRam0000000000fcfaa8)
                                           (*(undefined8 *)(&stack0x00000030 + lVar17),0x13836f4,
                                            0x12fe068,uVar14);
                        if (iVar15 == 0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105269;
                          (*pcRam0000000000fcf790)(&stack0x00004f98 + lVar17);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105278;
                          (*pcRam0000000000fcf790)(&stack0x00004758 + lVar17);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105287;
                          (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
                          if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105298;
                            lVar18 = func_0x();
                            *(undefined8 *)(lVar18 + 0x110) = 0;
                            if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1052b4;
                              func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
                            }
                            *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
                          }
                          lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
                          if (lVar18 != 0) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1052d1;
                            func_0x(lVar18);
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1052df;
                            (*_DAT_)(lVar18,0xc0);
                            *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
                            *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
                          }
                          if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
                            pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105309;
                            (*pcVar4)();
                            *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
                            *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
                          }
                          puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
                          if (puVar5 != (undefined8 *)0x0) {
                            pcVar4 = *(code **)*puVar5;
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10532e;
                            (*pcVar4)(puVar5,1);
                            *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
                          }
                          if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
                            pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105349;
                            (*pcVar4)();
                            *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
                          }
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10535e;
                          func_0x(&stack0x00004320 + lVar17);
                          goto code_r0x00105772;
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10508e;
                        uVar22 = (*pcRam0000000000fcfa00)();
                        *(int *)(&stack0xfffffffffffffff8 + lVar17) = (int)(short)uVar39;
                        *(int *)(&stack0xfffffffffffffff0 + lVar17) = (int)piVar37;
                        *(uint *)(&stack0xffffffffffffffe8 + lVar17) = (uint)uVar44;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1050b7;
                        iVar15 = func_0x
                                           (&stack0x00005ee8 + lVar17,0x80,0x13837d0,uVar22);
                        if (iVar15 < 0) {
                          *(int *)(&stack0xfffffffffffffff8 + lVar17) = iVar15;
                          *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = 0x417;
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0x1388720;
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1050eb;
                          (*pcRam0000000000fcfa88)(4,7,0x10,1);
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10510c;
                        iVar15 = (*pcRam0000000000fcfaa8)
                                           (*(undefined8 *)(&stack0x00000030 + lVar17),0x1388c54,
                                            0x13646ec);
                        if (iVar15 == 0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105160;
                          (*pcRam0000000000fcf790)(&stack0x00004f98 + lVar17);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10516f;
                          (*pcRam0000000000fcf790)(&stack0x00004758 + lVar17);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10517e;
                          (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
                          if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10518f;
                            lVar18 = func_0x();
                            *(undefined8 *)(lVar18 + 0x110) = 0;
                            if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1051ab;
                              func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
                            }
                            *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
                          }
                          lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
                          if (lVar18 != 0) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1051c8;
                            func_0x(lVar18);
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1051d6;
                            (*_DAT_)(lVar18,0xc0);
                            *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
                            *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
                          }
                          if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
                            pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105200;
                            (*pcVar4)();
                            *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
                            *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
                          }
                          puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
                          if (puVar5 != (undefined8 *)0x0) {
                            pcVar4 = *(code **)*puVar5;
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105225;
                            (*pcVar4)(puVar5,1);
                            *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
                          }
                          if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
                            pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105240;
                            (*pcVar4)();
                            *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
                          }
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105255;
                          func_0x(&stack0x00004320 + lVar17);
                          goto code_r0x00105772;
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10511f;
                        (*pcRam0000000000fcf790)();
                        uVar45 = (int)uVar28 + 1;
                        uVar28 = (ulonglong)uVar45;
                        puVar25 = *(undefined4 **)(&stack0x00000118 + lVar17);
                        puVar7 = puVar7 + 3;
                      } while (uVar45 < *(uint *)(&stack0x00000040 + lVar17));
                      param_2 = *(longlong *)(&stack0x00000030 + lVar17);
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10514c;
                    (*pcRam0000000000fcf790)(&stack0x00004758 + lVar17);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105155;
                    (*_DAT_)(param_2);
                  }
                }
              }
              else {
                uVar48 = (ulonglong)*(byte *)((ulonglong)*(byte *)(lVar18 + 0x34) + 0x10d6bc0);
                if (*(char *)(uVar48 + 0x1a8dc58) != '\0') goto code_r0x00104248;
                if (0xc < uVar45) {
                  uVar43 = (ulonglong)(piVar37 + -3) / 0xc;
                  if (((uint)uVar43 < 0x1f9) &&
                     (((*(short *)puVar25 == 1 || (*(short *)puVar25 == 4)) &&
                      (piVar37 + -3 == (int *)(uVar43 * 0xc))))) goto code_r0x00104248;
                }
                if ((((0xc < uVar45) && ((uint)((ulonglong)(piVar37 + -3) / 0xc) < 0x1f9)) &&
                    (*(short *)puVar25 == 2)) && ((ulonglong)(piVar37 + -3) % 0xc == 0))
                goto code_r0x00104248;
                if (*(char *)(uVar48 + 0x10fbe00) == '\0') {
                  if (*(byte *)(lVar18 + 0x34) == 0x24) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103a8d;
                    (*_DAT_)(&stack0x00004b78 + lVar17);
                    uVar22 = 0x10d69d8;
                    if (*(char *)(*(longlong *)(&stack0x00000328 + lVar17) + 0x21) < '\0') {
                      uVar22 = 0x1388770;
                    }
                    *(uint *)((longlong)auStackX_8 + lVar17) = uVar45;
                    *(uint *)((longlong)auStackX_8 + lVar17 + -8) = uVar42;
                    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar17) =
                         *(undefined4 *)(&stack0x0000428c + lVar17);
                    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar17) = uVar22;
                    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) = uVar14;
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103ae8;
                    (*pcRam0000000000fce620)
                              (&stack0x00004b78 + lVar17,*(undefined8 *)(&stack0x00000030 + lVar17),
                               0x1389120,*(undefined4 *)(&stack0x00000028 + lVar17));
                    *(undefined8 *)(&stack0x00000178 + lVar17) = 0;
                    uVar14 = puVar25[1];
                    uVar3 = puVar25[2];
                    uVar16 = puVar25[3];
                    *(undefined4 *)(&stack0x00004538 + lVar17) = *puVar25;
                    *(undefined4 *)(&stack0x0000453c + lVar17) = uVar14;
                    *(undefined4 *)(&stack0x00004540 + lVar17) = uVar3;
                    *(undefined4 *)(&stack0x00004544 + lVar17) = uVar16;
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103b12;
                    iVar15 = (*pcRam0000000000fcc940)
                                       (&stack0x00004538 + lVar17,&stack0x00000178 + lVar17);
                    if ((iVar15 == 0) && (*(longlong *)(&stack0x00000178 + lVar17) != 0)) {
                      param_2 = *(longlong *)(&stack0x00000030 + lVar17);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103b45;
                      iVar15 = (*pcRam0000000000fce630)
                                         (param_2,*(undefined8 *)(&stack0x00000040 + lVar17),
                                          0x1172928);
                      if (iVar15 == 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103b5b;
                        (*pcRam0000000000fcf790)(&stack0x00004b78 + lVar17);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103b6a;
                        (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
                        if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103b7b;
                          lVar18 = func_0x();
                          *(undefined8 *)(lVar18 + 0x110) = 0;
                          if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103b97;
                            func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
                          }
                          *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
                        }
                        lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
                        if (lVar18 != 0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103bb4;
                          func_0x(lVar18);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103bc2;
                          (*_DAT_)(lVar18,0xc0);
                          *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
                          *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
                        }
                        if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
                          pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103bec;
                          (*pcVar4)();
                          *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
                          *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
                        }
                        puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
                        if (puVar5 != (undefined8 *)0x0) {
                          pcVar4 = *(code **)*puVar5;
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103c11;
                          (*pcVar4)(puVar5,1);
                          *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
                        }
                        if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
                          pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103c2c;
                          (*pcVar4)();
                          *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103c41;
                        func_0x(&stack0x00004320 + lVar17);
                        goto code_r0x00105772;
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103c55;
                      (*pcRam0000000000fcc950)(&stack0x00000178 + lVar17);
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103c78;
                      uVar22 = (*pcRam0000000000fcfa00)();
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103c94;
                      iVar15 = func_0x
                                         (&stack0x00006668 + lVar17,0x2002,0x1388b8c,uVar22);
                      if (iVar15 < 0) {
                        *(int *)(&stack0xfffffffffffffff8 + lVar17) = iVar15;
                        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = 0x4bb;
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0x1388720;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103cc8;
                        (*pcRam0000000000fcfa88)(4,7,0x10,1);
                      }
                      lVar18 = -1;
                      do {
                        lVar18 = lVar18 + 1;
                      } while ((&stack0x00006669)[lVar18 + lVar17 + -1] != '\0');
                      puVar38 = &stack0x00006669 + lVar18 + lVar17 + -1;
                      if (uVar42 != 0) {
                        uVar45 = *(uint *)(&stack0x000000f8 + lVar17);
                        do {
                          bVar10 = *pbVar40;
                          piVar32 = (int *)(ulonglong)bVar10;
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103d10;
                          uVar22 = (*pcRam0000000000fcfa00)();
                          *(uint *)(&stack0xffffffffffffffe8 + lVar17) = (uint)bVar10;
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103d31;
                          iVar15 = func_0x
                                             (puVar38,&stack0x0000866a +
                                                      (lVar17 - (longlong)puVar38),0x1388b84,uVar22)
                          ;
                          if (iVar15 < 0) {
                            *(int *)(&stack0xfffffffffffffff8 + lVar17) = iVar15;
                            *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = 0x4c6;
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0x1388720;
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103d65;
                            (*pcRam0000000000fcfa88)(4,7,0x10,1);
                          }
                          lVar18 = -1;
                          do {
                            lVar18 = lVar18 + 1;
                          } while (puVar38[lVar18] != '\0');
                          puVar38 = puVar38 + lVar18;
                          if (&stack0x0000866a + lVar17 <= puVar38) break;
                          uVar42 = (int)uVar28 + 1;
                          uVar28 = (ulonglong)uVar42;
                          pbVar40 = pbVar40 + 1;
                        } while (uVar42 < uVar45);
                      }
                      param_2 = *(longlong *)(&stack0x00000030 + lVar17);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103dbc;
                      iVar15 = (*pcRam0000000000fce630)
                                         (param_2,*(undefined8 *)(&stack0x00000040 + lVar17),
                                          0x119fe54);
                      if (iVar15 == 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103dd2;
                        (*pcRam0000000000fcf790)(&stack0x00004b78 + lVar17);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103de1;
                        (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
                        if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103df2;
                          lVar18 = func_0x();
                          *(undefined8 *)(lVar18 + 0x110) = 0;
                          if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103e0e;
                            func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
                          }
                          *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
                        }
                        lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
                        if (lVar18 != 0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103e2b;
                          func_0x(lVar18);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103e39;
                          (*_DAT_)(lVar18,0xc0);
                          *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
                          *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
                        }
                        if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
                          pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103e63;
                          (*pcVar4)();
                          *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
                          *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
                        }
                        puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
                        if (puVar5 != (undefined8 *)0x0) {
                          pcVar4 = *(code **)*puVar5;
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103e88;
                          (*pcVar4)(puVar5,1);
                          *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
                        }
                        if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
                          pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103ea3;
                          (*pcVar4)();
                          *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103eb8;
                        func_0x(&stack0x00004320 + lVar17);
                        goto code_r0x00105772;
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103c64;
                    (*pcRam0000000000fcf790)(&stack0x00004b78 + lVar17);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103c6d;
                    (*_DAT_)(param_2);
                    piVar37 = piVar32;
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103ecc;
                    (*_DAT_)(&stack0x00004968 + lVar17);
                    puVar25 = *(undefined4 **)(&stack0x00000328 + lVar17);
                    uVar3 = *(undefined4 *)(&stack0x00000028 + lVar17);
                    if (*(char *)(puVar25 + 0xd) == 'h') {
                      if (*(short *)(&stack0x000043a0 + lVar17) != 1) {
                        uVar22 = 0x10d69d8;
                        if (*(char *)((longlong)puVar25 + 0x21) < '\0') {
                          uVar22 = 0x1388770;
                        }
                        *(uint *)((longlong)auStackX_8 + lVar17) =
                             *(byte *)((longlong)puVar25 + 6) & 7;
                        uVar16 = *puVar25;
                        uVar41 = 0x1389020;
                        goto code_r0x00103f7f;
                      }
                      uVar22 = 0x10d69d8;
                      if (*(char *)((longlong)puVar25 + 0x21) < '\0') {
                        uVar22 = 0x1388770;
                      }
                      *(uint *)(&stack0xfffffffffffffff8 + lVar17) = uVar42;
                      *(undefined8 *)(&stack0xfffffffffffffff0 + lVar17) = uVar22;
                      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) = uVar14;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103f29;
                      (*pcRam0000000000fce620)
                                (&stack0x00004968 + lVar17,
                                 *(undefined8 *)(&stack0x00000030 + lVar17),0x13890a0);
                    }
                    else {
                      uVar22 = 0x10d69d8;
                      if (*(char *)((longlong)puVar25 + 0x21) < '\0') {
                        uVar22 = 0x1388770;
                      }
                      *(uint *)((longlong)auStackX_8 + lVar17) = uVar45;
                      uVar16 = *(undefined4 *)(&stack0x0000428c + lVar17);
                      uVar41 = 0x1389120;
code_r0x00103f7f:
                      *(uint *)((longlong)auStackX_8 + lVar17 + -8) = uVar42;
                      *(undefined4 *)(&stack0xfffffffffffffff8 + lVar17) = uVar16;
                      *(undefined8 *)(&stack0xfffffffffffffff0 + lVar17) = uVar22;
                      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) = uVar14;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103fa4;
                      (*pcRam0000000000fce620)
                                (&stack0x00004968 + lVar17,
                                 *(undefined8 *)(&stack0x00000030 + lVar17),uVar41,uVar3);
                    }
                    *(undefined4 *)(&stack0x0000012c + lVar17) = 0;
                    *(undefined8 *)(&stack0x00000158 + lVar17) = 0;
                    *(undefined4 *)(&stack0x00000128 + lVar17) = 0;
                    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar17) = 0;
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = _DAT_;
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103fe0;
                    func_0x(&stack0x000002a0 + lVar17,0,0,0);
                    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104000;
                    lVar18 = func_0x(*(undefined8 *)(&stack0x00000328 + lVar17),pbVar40,
                                             piVar32);
                    *(longlong *)(&stack0x00000158 + lVar17) = lVar18;
                    uVar22 = *(undefined8 *)(&stack0x00000040 + lVar17);
                    param_2 = *(longlong *)(&stack0x00000030 + lVar17);
                    if (lVar18 != 0) {
                      *(longlong *)(&stack0xffffffffffffffe8 + lVar17) = lVar18;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10403a;
                      (*pcRam0000000000fce630)(param_2,uVar22,0x119fea8);
                      *(longlong *)(&stack0x00000270 + lVar17) = lVar18;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10404b;
                      (*pcRam0000000000fcfb10)(lVar18);
                      *(undefined8 *)(&stack0x00000158 + lVar17) = 0;
                      *(undefined4 *)(&stack0x0000012c + lVar17) = 1;
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104068;
                    func_0x(&stack0x000002a0 + lVar17);
                    piVar37 = (int *)((ulonglong)*_DAT_ +
                                     *(longlong *)
                                      (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                      (ulonglong)*_DAT_ * 8));
                    lVar18 = *(longlong *)(piVar37 + 0x40);
                    if (lVar18 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1040f0;
                      (*_DAT_)();
                      lVar18 = *(longlong *)(piVar37 + 0x40);
                    }
                    if (*(int *)(lVar18 + 0x22c) != 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104106;
                      (*_DAT_)();
                    }
                    if (*(int *)(&stack0x0000012c + lVar17) == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10412a;
                      iVar15 = (*pcRam0000000000fce630)(param_2,uVar22,0x1389580);
                      if (iVar15 == 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104140;
                        (*pcRam0000000000fcf790)(&stack0x00004968 + lVar17);
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10414f;
                        (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
                        if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104160;
                          lVar18 = func_0x();
                          *(undefined8 *)(lVar18 + 0x110) = 0;
                          if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10417c;
                            func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
                          }
                          *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
                        }
                        lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
                        if (lVar18 != 0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104199;
                          func_0x(lVar18);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1041a7;
                          (*_DAT_)(lVar18,0xc0);
                          *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
                          *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
                        }
                        if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
                          pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1041d1;
                          (*pcVar4)();
                          *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
                          *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
                        }
                        puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
                        if (puVar5 != (undefined8 *)0x0) {
                          pcVar4 = *(code **)*puVar5;
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1041f6;
                          (*pcVar4)(puVar5,1);
                          *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
                        }
                        if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
                          pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
                          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104211;
                          (*pcVar4)();
                          *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104226;
                        func_0x(&stack0x00004320 + lVar17);
                        goto code_r0x00105772;
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10423a;
                    (*pcRam0000000000fcf790)(&stack0x00004968 + lVar17);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104243;
                    (*_DAT_)(param_2);
                  }
                }
                else {
                  if (uVar42 < 9) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10374b;
                    (*_DAT_)(&stack0x000057d8 + lVar17);
                    uVar22 = 0x10d69d8;
                    if (*(char *)(*(longlong *)(&stack0x00000328 + lVar17) + 0x21) < '\0') {
                      uVar22 = 0x1388770;
                    }
                    *(uint *)((longlong)auStackX_8 + lVar17 + 8) = uVar45;
                    *(uint *)((longlong)auStackX_8 + lVar17) = uVar42;
                    *(undefined4 *)((longlong)auStackX_8 + lVar17 + -8) =
                         *(undefined4 *)(&stack0x0000428c + lVar17);
                    *(undefined8 *)(&stack0xfffffffffffffff8 + lVar17) = uVar22;
                    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = uVar14;
                    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) =
                         *(undefined4 *)(&stack0x00000028 + lVar17);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1037ae;
                    (*pcRam0000000000fce620)
                              (&stack0x000057d8 + lVar17,*(undefined8 *)(&stack0x00000030 + lVar17),
                               0x1388ea0,*(undefined8 *)(&stack0x00000040 + lVar17));
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1037b4;
                    uVar22 = (*pcRam0000000000fcfa00)();
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1037d0;
                    iVar15 = func_0x
                                       (&stack0x00006668 + lVar17,0x2002,0x1388b8c,uVar22);
                    if (iVar15 < 0) {
                      *(int *)(&stack0xfffffffffffffff8 + lVar17) = iVar15;
                      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = 0x464;
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0x1388720;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103804;
                      (*pcRam0000000000fcfa88)(4,7,0x10,1);
                    }
                    lVar18 = -1;
                    do {
                      lVar18 = lVar18 + 1;
                    } while ((&stack0x00006669)[lVar18 + lVar17 + -1] != '\0');
                    puVar38 = &stack0x00006669 + lVar18 + lVar17 + -1;
                    if (uVar42 != 0) {
                      uVar45 = *(uint *)(&stack0x000000f8 + lVar17);
                      do {
                        bVar10 = *pbVar40;
                        piVar32 = (int *)(ulonglong)bVar10;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10384b;
                        uVar22 = (*pcRam0000000000fcfa00)();
                        *(uint *)(&stack0xffffffffffffffe8 + lVar17) = (uint)bVar10;
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10386c;
                        iVar15 = func_0x
                                           (puVar38,&stack0x0000866a + (lVar17 - (longlong)puVar38),
                                            0x1388b84,uVar22);
                        if (iVar15 < 0) break;
                        lVar18 = -1;
                        do {
                          lVar18 = lVar18 + 1;
                        } while (puVar38[lVar18] != '\0');
                        puVar38 = puVar38 + lVar18;
                        if (&stack0x0000866a + lVar17 <= puVar38) break;
                        uVar42 = (int)uVar28 + 1;
                        uVar28 = (ulonglong)uVar42;
                        pbVar40 = pbVar40 + 1;
                      } while (uVar42 < uVar45);
                    }
                    param_2 = *(longlong *)(&stack0x00000030 + lVar17);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1038bb;
                    iVar15 = (*pcRam0000000000fce630)
                                       (param_2,*(undefined8 *)(&stack0x00000040 + lVar17),0x119fe54
                                       );
                    puVar38 = &stack0x000057d8 + lVar17;
                    piVar37 = piVar32;
                    if (iVar15 != 0) goto code_r0x001054fa;
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1038d2;
                    (*pcRam0000000000fcf790)(puVar38);
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1038e1;
                    (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
                    if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1038f2;
                      lVar18 = func_0x();
                      *(undefined8 *)(lVar18 + 0x110) = 0;
                      if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10390e;
                        func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
                      }
                      *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
                    }
                    lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
                    if (lVar18 != 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10392b;
                      func_0x(lVar18);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103939;
                      (*_DAT_)(lVar18,0xc0);
                      *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
                      *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
                    }
                    if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
                      pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103963;
                      (*pcVar4)();
                      *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
                      *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
                    }
                    puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
                    if (puVar5 != (undefined8 *)0x0) {
                      pcVar4 = *(code **)*puVar5;
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103988;
                      (*pcVar4)(puVar5,1);
                      *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
                    }
                    if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
                      pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
                      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1039a3;
                      (*pcVar4)();
                      *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1039b8;
                    func_0x(&stack0x00004320 + lVar17);
                    goto code_r0x00105772;
                  }
                  piVar37 = (int *)0x10d69d8;
                  if (*(char *)(*(longlong *)(&stack0x00000328 + lVar17) + 0x21) < '\0') {
                    piVar37 = (int *)0x1388770;
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1039e2;
                  uVar22 = (*pcRam0000000000fcfa00)();
                  *(uint *)((longlong)auStackX_8 + lVar17 + 0x10) = uVar45;
                  *(undefined4 *)((longlong)auStackX_8 + lVar17 + 8) =
                       *(undefined4 *)(&stack0x000000f8 + lVar17);
                  *(undefined4 *)((longlong)auStackX_8 + lVar17) =
                       *(undefined4 *)(&stack0x0000428c + lVar17);
                  *(int **)((longlong)auStackX_8 + lVar17 + -8) = piVar37;
                  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar17) = uVar14;
                  *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) =
                       *(undefined4 *)(&stack0x00000028 + lVar17);
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) =
                       *(undefined8 *)(&stack0x00000040 + lVar17);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103a34;
                  iVar15 = func_0x(&stack0x00008678 + lVar17,0x200,0x13891a0,uVar22)
                  ;
                  if (iVar15 < 0) {
                    *(int *)(&stack0xfffffffffffffff8 + lVar17) = iVar15;
                    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = 0x494;
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0x1388720;
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x103a68;
                    (*pcRam0000000000fcfa88)(4,7,0x10,1);
                  }
                  puVar38 = &stack0x00008678;
code_r0x00104573:
                  *(longlong *)(&stack0xffffffffffffffe8 + lVar17) = (longlong)puVar38 + lVar17;
                  param_2 = *(longlong *)(&stack0x00000030 + lVar17);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10458f;
                  (*pcRam0000000000fce628)(param_2,pbVar40,pbVar40);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x104598;
                  (*_DAT_)(param_2);
                }
              }
            }
            if (*(int *)(**(longlong **)
                           (*(longlong *)
                             (*(longlong *)(*(longlong *)(&stack0x00004310 + lVar17) + 0x80) + 8) +
                           0x160) + 0x1c) != 0) {
              (&stack0x00004536)[lVar17] = 1;
              *(undefined4 *)(&stack0x00000100 + lVar17) = 0x200;
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1055b7;
              (*_DAT_)(&stack0x000055c8 + lVar17);
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
              uVar22 = *(undefined8 *)(*(longlong *)(&stack0x00004310 + lVar17) + 0x80);
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1055e4;
              func_0x(&stack0x00004528 + lVar17,uVar22,&stack0x000043a0 + lVar17,0);
              *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) = 1;
              piVar32 = (int *)(&stack0x00006068 + lVar17);
              piVar31 = (int *)(&stack0x00004528 + lVar17);
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105609;
              func_0x(piVar31,piVar32,&stack0x00000100 + lVar17,0);
              bVar10 = ((longlong)*(int *)(&stack0x00000100 + lVar17) & 0xfffffffffffffffeU) < 0x200
              ;
              if (!(bool)bVar10) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x106587;
                iVar15 = func_0x();
                uVar45 = iVar15 + 0x150154dd + (uint)bVar10;
                *(double *)((longlong)piVar31 + ((ulonglong)uVar45 - 0x6b)) = (double)in_ST0;
                uVar45 = uVar45 + *piVar37 + *piVar31 + *piVar37 + *piVar32 + *piVar37;
                uVar45 = uVar45 + *(int *)(ulonglong)uVar45 + *piVar37;
                uVar45 = uVar45 + *(int *)(ulonglong)uVar45 + *piVar37;
                uVar45 = uVar45 + *(int *)(ulonglong)uVar45 + *piVar37;
                uVar45 = uVar45 + *(int *)(ulonglong)uVar45 + *piVar37;
                iVar15 = uVar45 + *(int *)(ulonglong)uVar45;
                *(char *)piVar37 = *(char *)piVar37 + (char)iVar15;
                iVar15 = iVar15 + *piVar37;
                *piVar37 = *piVar37 + iVar15;
                cVar9 = (char)iVar15 + (char)*piVar37 + *(char *)piVar37 + (char)*piVar37;
                *(char *)piVar37 = *(char *)piVar37 + cVar9;
                cVar9 = cVar9 + (char)*piVar37;
                *(char *)piVar37 = *(char *)piVar37 + cVar9;
                cVar9 = cVar9 + (char)*piVar37;
                *(char *)piVar37 = *(char *)piVar37 + cVar9;
                *(char *)piVar37 = *(char *)piVar37 + cVar9 + (char)*piVar37;
                cRam0000000000000000 = cRam0000000000000000 + (char)piVar31;
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
              *(undefined2 *)
               (&stack0x00006068 +
               ((longlong)*(int *)(&stack0x00000100 + lVar17) & 0xfffffffffffffffeU) + lVar17) = 0;
              *(undefined8 *)(&stack0xfffffffffffffff8 + lVar17) = 0;
              *(undefined8 *)(&stack0xfffffffffffffff0 + lVar17) = 0;
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105655;
              (*pcRam0000000000fcf788)
                        (&stack0x000055c8 + lVar17,param_2,0x13894b8,
                         *(undefined4 *)(&stack0x00000028 + lVar17));
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105674;
              iVar15 = (*pcRam0000000000fcfaa8)
                                 (param_2,0x1389660,0x12b16c8,&stack0x00006068 + lVar17);
              if (iVar15 == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10568b;
                (*pcRam0000000000fcf790)();
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10569a;
                (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
                if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1056ab;
                  lVar18 = func_0x();
                  *(undefined8 *)(lVar18 + 0x110) = 0;
                  if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1056c7;
                    func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
                  }
                  *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
                }
                lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
                if (lVar18 != 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1056e4;
                  func_0x(lVar18);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1056f2;
                  (*_DAT_)(lVar18,0xc0);
                  *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
                  *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
                }
                if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
                  pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10571c;
                  (*pcVar4)();
                  *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
                  *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
                }
                puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
                if (puVar5 != (undefined8 *)0x0) {
                  pcVar4 = *(code **)*puVar5;
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105741;
                  (*pcVar4)(puVar5,1);
                  *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
                }
                if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
                  pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
                  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10575c;
                  (*pcVar4)();
                  *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105771;
                func_0x(&stack0x00004320 + lVar17);
                goto code_r0x00105772;
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105794;
              (*pcRam0000000000fcf790)(&stack0x000055c8 + lVar17);
            }
          }
        }
        else if (((bVar10 & 0x1c) - 0x18 & 0xfffffffb) != 0) goto code_r0x00103480;
      }
    }
code_r0x00103395:
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1033a3;
    (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
    uVar45 = *(int *)(&stack0x00000028 + lVar17) + 1;
    *(uint *)(&stack0x00000028 + lVar17) = uVar45;
    lVar34 = (longlong)(int)uVar45;
    lVar18 = *(longlong *)(&stack0x00000108 + lVar17);
    uVar26 = *(ushort *)(lVar18 + 0x16);
    if (lVar34 < (longlong)(ulonglong)uVar26) {
      psVar20 = (short *)(lVar18 + (0xfff - lVar34) * 2);
      do {
        uVar48 = (ulonglong)uVar45;
        if (*psVar20 != 0) goto LAB_;
        uVar45 = uVar45 + 1;
        *(uint *)(&stack0x00000028 + lVar17) = uVar45;
        lVar34 = lVar34 + 1;
        psVar20 = psVar20 + -1;
      } while (lVar34 < (longlong)(ulonglong)uVar26);
    }
    uVar48 = 0xffffffff;
    *(undefined4 *)(&stack0x00000028 + lVar17) = 0xffffffff;
    *(undefined4 *)(&stack0x000000fc + lVar17) = 0xffffffff;
  }
  goto LAB_;
code_r0x00105f40:
  sVar12 = (short)uVar48;
  if (-1 < (short)puVar35[(ulonglong)((int)uVar48 - 1) + 1]) goto code_r0x001061eb;
  if ((int)uVar48 == 1) {
    uVar48 = 1;
    uVar42 = uVar45;
  }
  else {
    uVar42 = *(ushort *)
              (pbVar40 + uVar48 * 2 + ((ulonglong)*(uint *)(&stack0x000000d4 + lVar17) - 2)) &
             0x7fff;
  }
  uVar46 = *(ushort *)(pbVar40 + uVar48 * 2 + (ulonglong)*(uint *)(&stack0x000000d4 + lVar17)) &
           0x7fff;
  if (((uVar42 < uVar45) || (uVar46 < uVar42)) || ((uint)uVar43 < uVar46)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x105fa1;
    func_0x(pbVar40,7);
    sVar12 = *(short *)(&stack0x000000dc + lVar17);
    uVar45 = *(uint *)(&stack0x000000d8 + lVar17);
    pbVar40 = *(byte **)(&stack0x000000c8 + lVar17);
    uVar43 = (ulonglong)*(uint *)(&stack0x000000c4 + lVar17);
  }
  if ((uVar42 < uVar45) || ((uint)uVar43 < uVar42)) goto code_r0x001063c3;
  if (*(ushort *)(pbVar40 + uVar42) == 5) {
    *(ushort *)(&stack0x000000c2 + lVar17) = *(ushort *)(&stack0x000000c2 + lVar17) | 2;
    *(short *)(&stack0x000000dc + lVar17) = sVar12 + -1;
    uVar48 = (ulonglong)(uVar42 & 0xffff);
    *(short *)(&stack0x000000ea + lVar17) = (short)uVar42;
    pbVar1 = pbVar40 + uVar48;
    if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
      uVar26 = *(ushort *)(&stack0x000000ec + lVar17) & 0xc7ff;
    }
    else {
      uVar26 = (*(ushort *)(pbVar1 + 2) ^ *(ushort *)(&stack0x000000ec + lVar17)) & 0x3800 ^
               *(ushort *)(&stack0x000000ec + lVar17);
    }
    uVar39 = (uVar26 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar26;
    *(ushort *)(&stack0x000000ec + lVar17) = uVar39;
    pbVar36 = pbVar40 + uVar48 + (ulonglong)((uVar39 & 0x7ff) * 2) + 4 +
                                 (ulonglong)((uVar26 >> 0xb & 7) * 2);
    if (pbVar36 < pbVar1) {
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1060be;
      func_0x(pbVar1,0x19);
      uVar39 = *(ushort *)(&stack0x000000ec + lVar17);
      uVar48 = (ulonglong)*(ushort *)(&stack0x000000ea + lVar17);
      pbVar40 = *(byte **)(&stack0x000000c8 + lVar17);
      uVar43 = (ulonglong)*(uint *)(&stack0x000000c4 + lVar17);
    }
    if (uVar46 - uVar42 <
        (((*(uint *)(&stack0x000000ec + lVar17) & 0x7ff) * 2 - (int)uVar48) -
        *(int *)(&stack0x000000c8 + lVar17)) + (int)pbVar36) {
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x106114;
      func_0x(pbVar40 + uVar48,0x19);
      uVar39 = *(ushort *)(&stack0x000000ec + lVar17);
      uVar48 = (ulonglong)*(ushort *)(&stack0x000000ea + lVar17);
      pbVar40 = *(byte **)(&stack0x000000c8 + lVar17);
      uVar43 = (ulonglong)*(uint *)(&stack0x000000c4 + lVar17);
    }
    if (((uVar39 & 0x3800) != 0) &&
       (puVar35 = (ushort *)(pbVar40 + uVar48 + 4), (uVar39 & 0x3800) != 0)) {
      do {
        if ((uVar39 & 0x7ff) < (*puVar35 & 0x7ff)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x106192;
          func_0x(pbVar40 + uVar48,0x1a);
          uVar39 = *(ushort *)(&stack0x000000ec + lVar17);
          uVar48 = (ulonglong)*(ushort *)(&stack0x000000ea + lVar17);
          pbVar40 = *(byte **)(&stack0x000000c8 + lVar17);
        }
        uVar45 = (int)uVar28 + 1;
        uVar28 = (ulonglong)uVar45;
        puVar35 = puVar35 + 1;
      } while ((int)uVar45 < (int)(*(uint *)(&stack0x000000ec + lVar17) >> 0xb & 7));
      uVar43 = (ulonglong)*(uint *)(&stack0x000000c4 + lVar17);
    }
    goto code_r0x001061eb;
  }
  if (*(ushort *)(pbVar40 + uVar42) < 0x400) goto code_r0x001061eb;
  *(ushort *)(&stack0x000000c2 + lVar17) = *(ushort *)(&stack0x000000c2 + lVar17) | 1;
  uVar26 = sVar12 - 1;
  uVar48 = (ulonglong)uVar26;
  *(ushort *)(&stack0x000000dc + lVar17) = uVar26;
  if (uVar26 == 0) goto code_r0x001061eb;
  goto code_r0x00105f40;
code_r0x001061eb:
  if ((*pbVar40 & 0x40) == 0) {
    *(undefined4 *)(&stack0x000000e6 + lVar17) = 0;
  }
  else {
    *(int *)(&stack0x000000e6 + lVar17) = (int)uVar43;
    *(int *)(&stack0x000000c4 + lVar17) = (int)uVar43 + 0xe;
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x106216;
    puVar23 = (ulonglong *)func_0x(&stack0x000000c2 + lVar17);
    uVar26 = (ushort)(*puVar23 >> 0x30);
    if ((((uint)(int)(short)uVar26 >> 1 ^ (int)(short)uVar26) & 0x2000) != 0) {
      if ((uVar26 >> 0xe & 1) == 0) {
        uVar26 = uVar26 & 0xdfff;
      }
      else {
        uVar26 = uVar26 | 0x2000;
      }
    }
    if (uVar26 == 0xfffc) {
      uVar33 = (uint)((*puVar23 >> 0x20 & 0xffff) >> 5);
    }
    uVar43 = (ulonglong)(*(int *)(&stack0x000000c4 + lVar17) + uVar33);
    *(uint *)(&stack0x000000c4 + lVar17) = *(int *)(&stack0x000000c4 + lVar17) + uVar33;
    pbVar40 = *(byte **)(&stack0x000000c8 + lVar17);
  }
  if ((*(byte **)(&stack0x000000de + lVar17) != (byte *)0x0) &&
     (*(byte **)(&stack0x000000de + lVar17) < pbVar40 + uVar43)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1062b2;
    cVar9 = func_0x(0x1a61f00);
    if (cVar9 != '\0') {
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1062bb;
      cVar9 = func_0x();
      if (cVar9 != '\0') {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1062cb;
        cVar9 = func_0x(0x1a61f00);
        if (cVar9 == '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1062e7;
          (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10630b;
          (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x886);
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10631d;
    func_0x(*(undefined8 *)(&stack0x000000c8 + lVar17),0x12);
    pbVar40 = *(byte **)(&stack0x000000c8 + lVar17);
    uVar43 = (ulonglong)*(uint *)(&stack0x000000c4 + lVar17);
  }
  if (0x3f3b < (int)uVar43 - 1U) {
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x106348;
    cVar9 = func_0x(0x1a61f00);
    if (cVar9 != '\0') {
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x106351;
      cVar9 = func_0x();
      if (cVar9 != '\0') {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x106361;
        cVar9 = func_0x(0x1a61f00);
        if (cVar9 == '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10637d;
          (*pcRam0000000000fcfa88)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1063a1;
          (*pcRam0000000000fcfa80)(1,0x135190c,0x14719f8,0x88b);
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1063b3;
    func_0x(*(undefined8 *)(&stack0x000000c8 + lVar17),5);
    pbVar40 = *(byte **)(&stack0x000000c8 + lVar17);
    uVar43 = (ulonglong)*(uint *)(&stack0x000000c4 + lVar17);
  }
code_r0x001063c3:
  if ((8 < (uint)uVar43) || (((*pbVar40 & 0xe) != 0 && ((*pbVar40 & 0xe) != 0xc)))) {
    *(uint *)(&stack0x0000002c + lVar17) = (uint)uVar43;
  }
  lVar18 = *(longlong *)(&stack0x00000108 + lVar17);
  lVar34 = *(longlong *)(&stack0x00000118 + lVar17);
code_r0x00106431:
  lVar18 = (ulonglong)*(ushort *)(lVar18 + lVar34 * 2) + lVar18;
  *(undefined **)(&stack0xffffffffffffffe8 + lVar17) = &stack0x00006268 + lVar17;
  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x106457;
  (*pcRam0000000000fce628)(param_2,lVar18,lVar18,*(undefined4 *)(&stack0x0000002c + lVar17));
  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x106466;
  (*pcRam0000000000fcf790)(&stack0x00004548 + lVar17);
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10646f;
  (*_DAT_)(param_2);
  if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x106481;
    lVar18 = func_0x();
    *(undefined8 *)(lVar18 + 0x110) = 0;
    if (*(longlong *)(&stack0x00004318 + lVar17) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10649d;
      func_0x(*(longlong *)(&stack0x00004318 + lVar17),1);
    }
    *(undefined8 *)(&stack0x00004318 + lVar17) = 0;
  }
  lVar18 = *(longlong *)(&stack0x00004300 + lVar17);
  if (lVar18 != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1064ba;
    func_0x(lVar18);
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1064c8;
    (*_DAT_)(lVar18,0xc0);
    *(undefined (*) [16])(&stack0x00004300 + lVar17) = ZEXT816(0);
    *(undefined8 *)(&stack0x00004310 + lVar17) = 0;
  }
  if (*(longlong **)(&stack0x000042f0 + lVar17) != (longlong *)0x0) {
    pcVar4 = *(code **)(**(longlong **)(&stack0x000042f0 + lVar17) + 0x118);
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1064f2;
    (*pcVar4)();
    *(undefined8 *)(&stack0x000042f0 + lVar17) = 0;
    *(undefined8 *)(&stack0x000042e8 + lVar17) = 0;
  }
  puVar5 = *(undefined8 **)(&stack0x000042e0 + lVar17);
  if (puVar5 != (undefined8 *)0x0) {
    pcVar4 = *(code **)*puVar5;
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x106517;
    (*pcVar4)(puVar5,1);
    *(undefined8 *)(&stack0x000042e0 + lVar17) = 0;
  }
  if (*(longlong **)(&stack0x000042a8 + lVar17) != (longlong *)0x0) {
    pcVar4 = *(code **)(**(longlong **)(&stack0x000042a8 + lVar17) + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x106532;
    (*pcVar4)();
    *(undefined8 *)(&stack0x000042a8 + lVar17) = 0;
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x106547;
  func_0x(&stack0x00004320 + lVar17);
  puVar5 = *(undefined8 **)(&stack0x00000048 + lVar17);
  if (puVar5 != (undefined8 *)0x0) {
    pcVar4 = *(code **)*puVar5;
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10655d;
    (*pcVar4)(puVar5,1);
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10656f;
  func_0x
            (*(ulonglong *)(&stack0x00008e78 + lVar17) ^
             (ulonglong)(&stack0xffffffffffffffc8 + lVar17));
  return;
}

