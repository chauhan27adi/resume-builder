
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x010ff18e) */

void FUN_(longlong **param_1,longlong param_2,short *param_3,int param_4)

{
  byte bVar1;
  ushort uVar2;
  ushort uVar3;
  ushort uVar4;
  longlong lVar5;
  longlong lVar6;
  byte *pbVar7;
  ushort *puVar8;
  uint uVar9;
  code *UNRECOVERED_JUMPTABLE;
  short sVar10;
  int iVar11;
  uint uVar12;
  ushort *puVar13;
  int *piVar14;
  
  lVar5 = *(longlong *)(param_2 + 0x10);
  uVar2 = *(ushort *)(lVar5 + 0x28);
  piVar14 = (int *)((longlong)param_4 * 0x10 + lVar5);
  lVar6 = **param_1;
  if (param_4 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  bVar1 = *(byte *)(lVar5 + 0x20) >> 1;
  if (*param_3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((bVar1 & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  pbVar7 = *(byte **)(param_3 + 4);
  if ((*pbVar7 & 0x10) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar12 = *(uint *)(param_3 + 8);
  if (*piVar14 < (int)uVar12) {
    if ((uint)*(ushort *)(piVar14 + 1) <= (uint)*(ushort *)(pbVar7 + uVar12)) {
      if (((bVar1 & 1) != 0) &&
         (uVar9 = *(ushort *)(piVar14 + 1) - 1,
         (pbVar7[(ulonglong)(uVar9 >> 3) + (ulonglong)uVar12 + 2] >> ((byte)uVar9 & 7) & 1) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (-1 < *piVar14) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(int *)(param_3 + 2) == 0) {
        uVar12 = *(uint *)(param_3 + 8);
        param_3[1] = 0;
        *(uint *)(param_3 + 10) = uVar12;
        bVar1 = **(byte **)(param_3 + 4);
        if ((bVar1 & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((bVar1 & 0x20) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        puVar13 = (ushort *)(*(byte **)(param_3 + 4) + uVar12);
        uVar3 = *puVar13;
        param_3[0xe] = uVar3;
        if (uVar3 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        uVar12 = uVar12 + (uVar3 + 1) * 2;
        *(uint *)(param_3 + 0xc) = uVar12;
        if (0x1f9e < uVar12) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        uVar4 = puVar13[uVar3];
        *(uint *)(param_3 + 2) = uVar4 & 0x7fff;
        if ((uVar4 & 0x7fff) < uVar12) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        iVar11 = 0;
        puVar8 = puVar13;
        if (uVar3 != 0) {
          do {
            uVar9 = puVar8[1] & 0x7fff;
            if ((uVar9 < uVar12) || (*(uint *)(param_3 + 2) < uVar9)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            uVar3 = param_3[0xe];
            iVar11 = iVar11 + 1;
            puVar8 = puVar8 + 1;
            uVar12 = uVar9;
          } while (iVar11 < (int)(uint)uVar3);
        }
        if ((short)puVar13[(ulonglong)(uVar3 - 1) + 1] < 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((**(byte **)(param_3 + 4) & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *(undefined4 *)(param_3 + 0x13) = 0;
        if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
           (*(ulonglong *)(param_3 + 0xf) <
            (ulonglong)*(uint *)(param_3 + 2) + *(longlong *)(param_3 + 4))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (0x3f3b < *(uint *)(param_3 + 2) - 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
      }
      sVar10 = -*(short *)piVar14;
      if ((*(byte *)((longlong)piVar14 + 6) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((uint)(ushort)param_3[0xe] < (uint)(int)sVar10) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (sVar10 != 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar12 = *(ushort *)
                ((ulonglong)*(uint *)(param_3 + 10) + *(longlong *)(param_3 + 4) +
                (longlong)sVar10 * 2) & 0x7fff;
      if ((*(uint *)(param_3 + 0xc) <= uVar12) && (uVar12 <= *(uint *)(param_3 + 2))) {
        if (*(byte *)(lVar5 + 0x34) == 0x38) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (*(longlong *)(param_3 + 4) + (ulonglong)*(uint *)(param_3 + 0xc) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (*(longlong *)((ulonglong)(uVar2 - 1) * 0x10 + lVar6) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        uVar12 = *(byte *)(lVar5 + 0x34) - 0xa5;
        if (uVar12 < 0x4b) {
          UNRECOVERED_JUMPTABLE =
               (code *)((ulonglong)
                        *(uint *)((ulonglong)*(byte *)((longlong)(int)uVar12 + 0x1003ac) * 4 +
                                 0x1003a0) + 0xd0230);
                    /* WARNING: Could not emulate address calculation at 0x001002cd */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
          return;
        }
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

