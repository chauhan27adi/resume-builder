
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined8 param_2,int param_3,longlong param_4,
                 ulonglong param_5,uint param_6,longlong *param_7)

{
  ushort *puVar1;
  byte *pbVar2;
  code *pcVar3;
  ushort *puVar4;
  byte bVar5;
  char cVar6;
  ushort uVar7;
  ushort uVar8;
  int iVar9;
  longlong *plVar10;
  longlong lVar11;
  uint *puVar12;
  longlong *plVar13;
  longlong lVar14;
  uint *puVar15;
  longlong lVar16;
  undefined8 uVar17;
  longlong lVar18;
  uint *puVar19;
  ulonglong uVar20;
  short sVar21;
  undefined *puVar22;
  undefined *puVar23;
  uint uVar24;
  uint *puVar25;
  ulonglong uVar26;
  ulonglong uVar27;
  ushort *puVar28;
  uint uVar29;
  uint uVar30;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_190;
  undefined auStack_188 [32];
  uint *puStack_168;
  undefined4 auStack_160 [2];
  uint *puStack_158;
  uint auStack_150 [10];
  uint uStack_128;
  uint uStack_124;
  uint uStack_120;
  int iStack_11c;
  undefined4 uStack_118;
  uint *puStack_110;
  uint uStack_108;
  undefined4 uStack_f8;
  undefined2 uStack_f4;
  longlong *plStack_e8;
  longlong *plStack_e0;
  undefined auStack_d8 [8];
  longlong lStack_d0;
  longlong *plStack_c8;
  longlong *plStack_c0;
  ulonglong uStack_b8;
  longlong lStack_b0;
  longlong *plStack_a8;
  undefined8 uStack_a0;
  longlong lStack_98;
  longlong *plStack_90;
  undefined8 uStack_78;
  undefined auStack_70 [32];
  undefined auStack_50 [16];
  ulonglong uStack_40;
  
  puVar23 = auStack_188;
  uStack_78 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)&uStack_128;
  plStack_a8 = param_7;
  plStack_90 = param_7;
  uStack_108 = param_6;
  uStack_120 = param_6;
  uStack_118 = 0x80004005;
  plVar10 = (longlong *)0x0;
  iStack_11c = 0;
  lVar14 = param_1[2];
  plVar13 = (longlong *)param_1[3];
  *param_7 = 0;
  puVar22 = auStack_188;
  plStack_c8 = plVar13;
  plStack_c0 = param_1;
  lStack_b0 = lVar14;
  uStack_a0 = param_2;
  if ((param_4 == 0) || (puVar22 = auStack_188, param_3 != 0x10)) goto LAB_;
  lVar11 = *(longlong *)(lVar14 + 8);
  if (*(longlong *)(lVar11 + 0x478) != 0) {
    lVar11 = *(longlong *)(lVar11 + 0x478);
  }
  if ((*(byte *)(lVar11 + 0x474) & 1) == 0) {
    puStack_168 = (uint *)auStack_50;
    uStack_190 = 0x100c6c;
    iVar9 = func_0x(lVar14,param_5 & 0xffffffff,0x10);
    puVar22 = auStack_188;
    if (iVar9 == 0) goto LAB_;
    uStack_128 = 0x10;
    puVar22 = auStack_50;
    uVar30 = uStack_120;
  }
  else {
    uStack_190 = 0x1000db;
    iVar9 = func_0x(lVar14,plVar13);
    puVar22 = auStack_188;
    if (iVar9 == 0) goto LAB_;
    iStack_11c = (int)*(short *)(param_4 + 2);
    uStack_190 = 0x1000ff;
    lVar11 = (**(code **)(*plVar13 + 0xe0))(plVar13,iStack_11c,auStack_70);
    puVar22 = auStack_188;
    lStack_d0 = lVar11;
    if (((*(byte *)(lVar11 + 4) & 2) != 0) ||
       (uStack_b8 = param_5, puVar22 = auStack_188,
       param_5 != *(uint *)(*(longlong *)(lVar11 + 8) + 4))) goto LAB_;
    uStack_190 = 0x10013d;
    puVar12 = (uint *)func_0x
                                (*(undefined8 *)(*(longlong *)(lVar14 + 8) + 0x160),
                                 param_5 & 0xffffffff);
    uStack_190 = 0x10015d;
    puStack_110 = puVar12;
    (**(code **)(*param_1 + 0x80))(param_1,*(longlong *)(lVar11 + 8) + 0xc,&plStack_e0);
    if (plStack_e0 == (longlong *)0x0) {
      puStack_168 = (uint *)0x0;
      uStack_190 = 0x10018a;
      (*_DAT_)(1,0x19fa7d8,0x19ce0d0,0xebc);
    }
    puVar25 = (uint *)0x0;
    *(uint *)(plStack_e0 + 2) = *(uint *)(plStack_e0 + 2) & 0xfffffeff;
    if (((char)*(uint *)(plStack_e0 + 2) < '\0') ||
       ((*(byte *)((longlong)plStack_e0 + 0x34) & 1) == 0)) {
      uStack_190 = 0x1001c4;
      plVar13 = (longlong *)func_0x(plStack_e0,0);
    }
    else if ((*(uint *)(plStack_e0 + 2) >> 0xd & 1) == 0) {
      plVar13 = plStack_e0 + 9;
    }
    else {
      plVar13 = (longlong *)plStack_e0[0x29];
    }
    uStack_190 = 0x1001d5;
    plStack_e8 = plVar13;
    lVar14 = func_0x();
    lVar14 = -lVar14;
    bVar5 = *(byte *)(puVar12 + 8);
    puVar1 = (ushort *)((longlong)plVar13 + 2);
    if (*(short *)plVar13 == 0) {
      uVar30 = *puVar12;
      if ((uVar30 & 0xc0000000) == 0x80000000) {
        *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100b05;
        iVar9 = func_0x(puVar1);
        if (iVar9 != 0) {
          *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100b21;
          puVar25 = (uint *)func_0x((short *)((longlong)plVar13 + 0x2a),puVar12,&uStack_128,
                                            &puStack_110);
          goto LAB_;
        }
LAB_:
        uStack_128 = 0;
      }
      else {
        if (((bVar5 & 2) != 0) || ((*(byte *)((longlong)puVar12 + 6) & 0x10) != 0)) {
          pbVar2 = (byte *)plVar13[1];
          if ((*pbVar2 & 0x10) == 0) {
            if ((1 << (*pbVar2 & 0xe) & 0x1105U) != 0) goto LAB_;
            puVar15 = puVar25;
            puVar19 = (uint *)0x1;
LAB_:
            uVar24 = (uint)puVar15;
            iVar9 = (int)puVar19;
            if ((bVar5 & 2) != 0) goto LAB_;
          }
          else {
            uVar24 = *(uint *)(plVar13 + 2);
            if ((int)uVar24 <= (int)uVar30) {
LAB_:
              puVar15 = (uint *)(ulonglong)(~(uint)(*(ushort *)((longlong)puVar12 + 6) >> 4) & 1);
              puVar19 = puVar25;
              goto LAB_;
            }
            if ((uint)*(ushort *)(pbVar2 + uVar24) < (uint)*(ushort *)(puVar12 + 1))
            goto LAB_;
            if ((bVar5 & 2) == 0) goto LAB_;
            uVar29 = *(ushort *)(puVar12 + 1) - 1;
            uVar24 = pbVar2[(ulonglong)(uVar29 >> 3) + (ulonglong)uVar24 + 2] >> ((byte)uVar29 & 7)
                     & 1;
            iVar9 = 1;
LAB_:
            if (uVar24 != 0) goto LAB_;
          }
          if ((iVar9 == 0) && ((*(byte *)((longlong)puVar12 + 6) & 0x10) != 0)) {
            puVar25 = *(uint **)(puVar12 + 2) + 1;
            uStack_128 = **(uint **)(puVar12 + 2);
            goto LAB_;
          }
        }
LAB_:
        if ((int)uVar30 < 0) {
          if (*(int *)((longlong)plVar13 + 4) == 0) {
            *puVar1 = 0;
            uVar30 = *(uint *)(plVar13 + 2);
            uVar20 = (ulonglong)uVar30;
            *(uint *)((longlong)plVar13 + 0x14) = uVar30;
            pbVar2 = (byte *)plVar13[1];
            bVar5 = *pbVar2;
            if ((bVar5 & 0x10) != 0) {
              uVar30 = uVar30 + 2 + (*(ushort *)(pbVar2 + uVar20) + 7 >> 3);
              uVar20 = (ulonglong)uVar30;
              *(uint *)((longlong)plVar13 + 0x14) = uVar30;
              bVar5 = *pbVar2;
            }
            if ((bVar5 & 0x20) == 0) {
              *(int *)((longlong)plVar13 + 4) = (int)uVar20;
              *(short *)((longlong)plVar13 + 0x1c) = 0;
              *(int *)(plVar13 + 3) = (int)uVar20;
            }
            else {
              puVar28 = (ushort *)(pbVar2 + uVar20);
              uVar7 = *puVar28;
              *(ushort *)((longlong)plVar13 + 0x1c) = uVar7;
              if (uVar7 == 0) {
                *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x1003fe;
                cVar6 = func_0x(0x1f59d50);
                if (cVar6 != '\0') {
                  *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100407;
                  lVar11 = func_0x();
                  if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                    *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100421;
                    cVar6 = func_0x(0x1f59d50);
                    if (cVar6 == '\0') {
                      *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x10043d;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)((longlong)auStack_160 + lVar14 + -8) = 0;
                      *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100463;
                      (*_DAT_)(1,0x184975c,0x1969848,0x80f);
                    }
                  }
                }
                lVar11 = plVar13[1];
                *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100471;
                func_0x(lVar11,3);
                uVar7 = *(ushort *)((longlong)plVar13 + 0x1c);
                uVar20 = (ulonglong)*(uint *)((longlong)plVar13 + 0x14);
              }
              uVar30 = (int)uVar20 + (uVar7 + 1) * 2;
              *(uint *)(plVar13 + 3) = uVar30;
              if (0x1f9e < uVar30) {
                *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x1004a1;
                cVar6 = func_0x(0x1f59d50);
                if (cVar6 != '\0') {
                  *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x1004aa;
                  lVar11 = func_0x();
                  if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                    *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x1004c4;
                    cVar6 = func_0x(0x1f59d50);
                    if (cVar6 == '\0') {
                      *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x1004e0;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)((longlong)auStack_160 + lVar14 + -8) = 0;
                      *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100506;
                      (*_DAT_)(1,0x184975c,0x1969848,0x816);
                    }
                  }
                }
                lVar11 = plVar13[1];
                *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100514;
                func_0x(lVar11,4);
                uVar7 = *(ushort *)((longlong)plVar13 + 0x1c);
                uVar30 = *(uint *)(plVar13 + 3);
              }
              uVar20 = (ulonglong)uVar7;
              uVar7 = puVar28[uVar20];
              *(uint *)((longlong)plVar13 + 4) = uVar7 & 0x7fff;
              if ((uVar7 & 0x7fff) < uVar30) {
                *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100542;
                cVar6 = func_0x(0x1f59d50);
                if (cVar6 != '\0') {
                  *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x10054b;
                  lVar11 = func_0x();
                  if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                    *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100565;
                    cVar6 = func_0x(0x1f59d50);
                    if (cVar6 == '\0') {
                      *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100581;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)((longlong)auStack_160 + lVar14 + -8) = 0;
                      *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x1005a7;
                      (*_DAT_)(1,0x184975c,0x1969848,0x81d);
                    }
                  }
                }
                lVar11 = plVar13[1];
                *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x1005b5;
                func_0x(lVar11,4);
                uVar30 = *(uint *)(plVar13 + 3);
                uVar20 = (ulonglong)*(ushort *)((longlong)plVar13 + 0x1c);
              }
              puVar4 = puVar28;
              if ((short)uVar20 != 0) {
                do {
                  uVar24 = puVar4[1] & 0x7fff;
                  if ((uVar24 < uVar30) || (*(uint *)((longlong)plVar13 + 4) < uVar24)) {
                    *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x1005f0;
                    cVar6 = func_0x(0x1f59d50);
                    if (cVar6 != '\0') {
                      *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x1005f9;
                      lVar11 = func_0x();
                      if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                        *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100613;
                        cVar6 = func_0x(0x1f59d50);
                        if (cVar6 == '\0') {
                          *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x10062f;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)((longlong)auStack_160 + lVar14 + -8) = 0;
                          *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100655;
                          (*_DAT_)(1,0x184975c,0x1969848,0x82a);
                        }
                      }
                    }
                    lVar11 = plVar13[1];
                    *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100663;
                    func_0x(lVar11,4);
                  }
                  uVar29 = (int)puVar25 + 1;
                  puVar25 = (uint *)(ulonglong)uVar29;
                  uVar20 = (ulonglong)*(ushort *)((longlong)plVar13 + 0x1c);
                  puVar12 = puStack_110;
                  puVar4 = puVar4 + 1;
                  uVar30 = uVar24;
                } while ((int)uVar29 < (int)(uint)*(ushort *)((longlong)plVar13 + 0x1c));
              }
              if ((short)puVar28[(ulonglong)((int)uVar20 - 1) + 1] < 0) {
                lVar11 = plVar13[1];
                do {
                  lVar16 = (ulonglong)*(uint *)((longlong)plVar13 + 0x14) + lVar11;
                  uVar30 = *(ushort *)(lVar16 + uVar20 * 2) & 0x7fff;
                  if ((int)uVar20 == 1) {
                    uVar24 = *(uint *)(plVar13 + 3);
                    uVar20 = (ulonglong)uVar24;
LAB_:
                    if ((uVar30 < (uint)uVar20) || (*(uint *)((longlong)plVar13 + 4) < uVar30))
                    goto LAB_;
                  }
                  else {
                    uVar29 = *(ushort *)(lVar16 + -2 + uVar20 * 2) & 0x7fff;
                    uVar20 = (ulonglong)uVar29;
                    uVar24 = *(uint *)(plVar13 + 3);
                    if (uVar24 <= uVar29) goto LAB_;
LAB_:
                    *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x1006e7;
                    func_0x(lVar11,7);
                    uVar24 = *(uint *)(plVar13 + 3);
                  }
                  uVar29 = (uint)uVar20;
                  if ((uVar29 < uVar24) || (*(uint *)((longlong)plVar13 + 4) < uVar29))
                  goto LAB_;
                  lVar11 = plVar13[1];
                  if (*(ushort *)(uVar20 + lVar11) == 5) {
                    *puVar1 = *puVar1 | 2;
                    *(short *)((longlong)plVar13 + 0x1c) = *(short *)((longlong)plVar13 + 0x1c) + -1
                    ;
                    uVar27 = uVar20 & 0xffff;
                    *(short *)((longlong)plVar13 + 0x2a) = (short)uVar20;
                    uVar7 = *(ushort *)(uVar27 + 2 + lVar11);
                    uVar8 = *(ushort *)((longlong)plVar13 + 0x2c) & 0xc7ff;
                    if ((uVar7 >> 0xe & 1) != 0) {
                      uVar8 = uVar7 & 0x3800 | uVar8;
                    }
                    *(ushort *)((longlong)plVar13 + 0x2c) = uVar8;
                    uVar7 = (uVar8 ^ *(ushort *)(uVar27 + 2 + lVar11)) & 0x7ff ^ uVar8;
                    *(ushort *)((longlong)plVar13 + 0x2c) = uVar7;
                    uVar20 = plVar13[1];
                    uVar26 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 + uVar20 + (uVar8 >> 0xb & 7) * 2
                             + uVar27;
                    if (uVar26 < uVar27 + uVar20) {
                      *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x1007ec;
                      func_0x(uVar27 + uVar20,0x19);
                      uVar7 = *(ushort *)((longlong)plVar13 + 0x2c);
                      uVar27 = (ulonglong)*(ushort *)((longlong)plVar13 + 0x2a);
                      uVar20 = (ulonglong)*(uint *)(plVar13 + 1);
                    }
                    if (uVar30 - uVar29 <
                        (((uVar7 & 0x7ff) * 2 - (int)uVar27) - (int)uVar20) + (int)uVar26) {
                      lVar11 = plVar13[1];
                      *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100824;
                      func_0x(uVar27 + lVar11,0x19);
                      uVar7 = *(ushort *)((longlong)plVar13 + 0x2c);
                    }
                    if ((uVar7 & 0x3800) != 0) {
                      puVar28 = (ushort *)
                                (plVar13[1] + (ulonglong)*(ushort *)((longlong)plVar13 + 0x2a) + 4);
                      iVar9 = 0;
                      if ((uVar7 & 0x3800) != 0) {
                        do {
                          if ((uVar7 & 0x7ff) < (*puVar28 & 0x7ff)) {
                            uVar7 = *(ushort *)((longlong)plVar13 + 0x2a);
                            lVar11 = plVar13[1];
                            *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100877;
                            func_0x((ulonglong)uVar7 + lVar11,0x1a);
                            uVar7 = *(ushort *)((longlong)plVar13 + 0x2c);
                          }
                          iVar9 = iVar9 + 1;
                          puVar28 = puVar28 + 1;
                        } while (iVar9 < (int)(uVar7 >> 0xb & 7));
                      }
                    }
                    goto LAB_;
                  }
                  if (*(ushort *)(uVar20 + lVar11) < 0x400) goto LAB_;
                  *puVar1 = *puVar1 | 1;
                  uVar7 = *(short *)((longlong)plVar13 + 0x1c) - 1;
                  *(ushort *)((longlong)plVar13 + 0x1c) = uVar7;
                  if (uVar7 == 0) goto LAB_;
                  uVar20 = (ulonglong)uVar7;
                } while ((short)puVar28[(ulonglong)(uVar7 - 1) + 1] < 0);
                uVar20 = (ulonglong)*(uint *)((longlong)plVar13 + 4);
              }
              else {
LAB_:
                uVar20 = (ulonglong)*(uint *)((longlong)plVar13 + 4);
              }
            }
            if ((*(byte *)plVar13[1] & 0x40) == 0) {
              *(undefined4 *)((longlong)plVar13 + 0x26) = 0;
            }
            else {
              *(int *)((longlong)plVar13 + 0x26) = (int)uVar20;
              *(int *)((longlong)plVar13 + 4) = (int)uVar20 + 0xe;
              *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x1008c2;
              uVar17 = func_0x(puVar1);
              *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x1008ce;
              func_0x(uVar17,auStack_d8);
              *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x1008d7;
              iVar9 = func_0x(auStack_d8);
              *(int *)((longlong)plVar13 + 4) = *(int *)((longlong)plVar13 + 4) + iVar9;
              uVar20 = (ulonglong)*(uint *)((longlong)plVar13 + 4);
            }
            iVar9 = (int)uVar20;
            if ((*(ulonglong *)((longlong)plVar13 + 0x1e) != 0) &&
               (*(ulonglong *)((longlong)plVar13 + 0x1e) < uVar20 + plVar13[1])) {
              *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x10090f;
              cVar6 = func_0x(0x1f59d50);
              if (cVar6 != '\0') {
                *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100918;
                lVar11 = func_0x();
                if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                  *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100932;
                  cVar6 = func_0x(0x1f59d50);
                  if (cVar6 == '\0') {
                    *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x10094e;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)((longlong)auStack_160 + lVar14 + -8) = 0;
                    *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100974;
                    (*_DAT_)(1,0x184975c,0x1969848,0x886);
                  }
                }
              }
              lVar11 = plVar13[1];
              *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100982;
              func_0x(lVar11,0x12);
              iVar9 = *(int *)((longlong)plVar13 + 4);
            }
            if (0x3f3b < iVar9 - 1U) {
              *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x10099b;
              cVar6 = func_0x(0x1f59d50);
              if (cVar6 != '\0') {
                *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x1009a4;
                lVar11 = func_0x();
                if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                  *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x1009be;
                  cVar6 = func_0x(0x1f59d50);
                  if (cVar6 == '\0') {
                    *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x1009da;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)((longlong)auStack_160 + lVar14 + -8) = 0;
                    *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100a00;
                    (*_DAT_)(1,0x184975c,0x1969848,0x88b);
                  }
                }
              }
              lVar11 = plVar13[1];
              *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100a0e;
              func_0x(lVar11,5);
            }
          }
LAB_:
          sVar21 = -*(short *)puVar12;
          param_6 = uStack_108;
          if ((*(byte *)((longlong)puVar12 + 6) & 0x10) != 0) {
            bVar5 = *(byte *)plVar13[1];
            if ((bVar5 & 0x10) == 0) {
              if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
                puVar25 = *(uint **)(puVar12 + 2) + 1;
                plVar13 = plStack_e8;
                uStack_128 = **(uint **)(puVar12 + 2);
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(plVar13 + 2) <= (int)*puVar12) ||
                    (*(ushort *)((byte *)plVar13[1] + *(uint *)(plVar13 + 2)) <
                     *(ushort *)(puVar12 + 1))) goto LAB_;
          }
          lVar11 = (longlong)sVar21;
          if ((uint)*(ushort *)((longlong)plVar13 + 0x1c) < (uint)(int)sVar21) {
            uStack_128 = 0;
            puVar25 = (uint *)plVar13[1];
            plVar13 = plStack_e8;
          }
          else {
            lVar16 = plVar13[1];
            lVar18 = (ulonglong)*(uint *)((longlong)plVar13 + 0x14) + lVar16;
            if (sVar21 == 1) {
              uVar30 = *(uint *)(plVar13 + 3);
              uVar24 = *(ushort *)(lVar18 + lVar11 * 2) & 0x7fff;
LAB_:
              if ((uVar24 < uVar30) || (*(uint *)((longlong)plVar13 + 4) < uVar24))
              goto LAB_;
            }
            else {
              uVar30 = *(ushort *)(lVar18 + -2 + lVar11 * 2) & 0x7fff;
              uVar24 = *(ushort *)(lVar18 + lVar11 * 2) & 0x7fff;
              lVar16 = plVar13[1];
              if (*(uint *)(plVar13 + 3) <= uVar30) goto LAB_;
LAB_:
              *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100acf;
              func_0x(lVar16,7);
            }
            puVar25 = (uint *)((ulonglong)uVar30 + plVar13[1]);
            plVar13 = plStack_e8;
            param_6 = uStack_108;
            uStack_128 = uVar24 - uVar30;
          }
        }
        else {
          uVar7 = *(ushort *)((longlong)puVar12 + 6);
          if ((uVar7 & 8) == 0) {
            if ((uVar7 & 0x10) != 0) {
              bVar5 = *(byte *)plVar13[1];
              if ((bVar5 & 0x10) == 0) {
                if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
                  puVar25 = *(uint **)(puVar12 + 2) + 1;
                  uStack_128 = **(uint **)(puVar12 + 2);
                  if (uStack_128 != 0x1f9e) {
                    *(undefined8 *)((longlong)auStack_160 + lVar14 + -8) = 0;
                    *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100358;
                    (*_DAT_)(1,0x19f7ba0,0x19f6508,0x381);
                  }
                  goto LAB_;
                }
              }
              else if (((int)*(uint *)(plVar13 + 2) <= (int)uVar30) ||
                      (*(ushort *)((byte *)plVar13[1] + *(uint *)(plVar13 + 2)) <
                       *(ushort *)(puVar12 + 1))) goto LAB_;
            }
            uStack_128 = 0x1f9e;
            puVar25 = (uint *)((longlong)(int)*puVar12 + plVar13[1]);
          }
          else {
            uStack_128 = 1;
            puVar25 = (uint *)0x15ce3f0;
            if ((*(byte *)((longlong)(int)uVar30 + plVar13[1]) & (byte)(1 << ((byte)uVar7 & 7))) ==
                0) {
              puVar25 = (uint *)0x15ce3f1;
            }
          }
        }
      }
    }
    else {
      uStack_124 = 0;
      *(uint **)((longlong)auStack_160 + lVar14 + -8) = &uStack_124;
      *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100b41;
      puVar25 = (uint *)func_0x(puVar1,puVar12);
      if ((((*(short *)plVar13 != 0) &&
           (plVar10 = (longlong *)plVar13[2], plVar10 != (longlong *)0x0)) && (*plVar10 != 0)) &&
         (((*(byte *)((longlong)puVar12 + 6) & 8) == 0 && ((uStack_124 & 1) == 0)))) {
        if ((puVar25 == (uint *)0x0) || (puVar25 == (uint *)0x15ce3f0)) {
          puVar25 = (uint *)0x0;
          uStack_128 = 0;
        }
        else {
          *(uint *)((longlong)auStack_150 + lVar14) = uStack_124;
          *(uint **)((longlong)&puStack_158 + lVar14) = &uStack_128;
          *(undefined4 *)((longlong)auStack_160 + lVar14) = 0x1f9e;
          *(longlong *)((longlong)auStack_160 + lVar14 + -8) = (longlong)&uStack_128 + lVar14;
          uVar30 = uStack_128;
          *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100ba2;
          puVar25 = (uint *)func_0x(plVar10,puVar12,puVar25,uVar30);
        }
      }
    }
LAB_:
    if (puVar25 == (uint *)0x0) {
      uVar30 = param_6 | 8;
    }
    else {
      *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100bc5;
      iVar9 = func_0x(plVar13,puVar12);
      uVar30 = uStack_120;
      if (iVar9 == 0) {
        uVar30 = param_6 | 0x200;
      }
    }
    *(undefined8 *)(auStack_188 + lVar14 + -8) = 0x100bf3;
    lVar11 = func_0x();
    lVar11 = -lVar11;
    puVar23 = auStack_188 + lVar11 + lVar14;
    puVar22 = (undefined *)((longlong)&uStack_128 + lVar11 + lVar14);
    *(undefined8 *)(auStack_188 + lVar11 + lVar14 + -8) = 0x100c09;
    func_0x(puVar22);
    if (((*(byte *)(lStack_d0 + 4) & 1) == 0) &&
       ((*(uint *)(*(longlong *)(plStack_c8[6] + 0x6b0) + 0x278) & 0x1000) == 0)) {
      uVar30 = uVar30 | 0x10000;
    }
    pcVar3 = *(code **)(*plStack_e0 + 8);
    *(undefined8 *)(auStack_188 + lVar11 + lVar14 + -8) = 0x100c3d;
    (*pcVar3)(plStack_e0);
    param_5 = uStack_b8;
    param_1 = plStack_c0;
    param_7 = plStack_a8;
    plVar10 = plStack_e0;
    lVar14 = lStack_b0;
  }
  puStack_110 = (uint *)((ulonglong)puStack_110 & 0xffff000000000000);
  uStack_f8 = 0;
  uStack_f4 = 0;
  *(undefined4 **)(puVar23 + 0x50) = &uStack_f8;
  *(int *)(puVar23 + 0x48) = iStack_11c;
  *(longlong **)(puVar23 + 0x40) = param_7;
  *(uint *)(puVar23 + 0x38) = uVar30 | 0x80;
  *(ulonglong *)(puVar23 + 0x30) = param_5;
  *(uint *)(puVar23 + 0x28) = uStack_128;
  *(undefined **)(puVar23 + 0x20) = puVar22;
  uVar17 = uStack_a0;
  lVar11 = param_1[0x3d];
  *(undefined8 *)(puVar23 + -8) = 0x100ce2;
  iVar9 = func_0x(param_1,uVar17,lVar11,1);
  if (iVar9 != 0) {
    uStack_118 = 0;
    lStack_98 = *(longlong *)(lVar14 + 8);
    lVar14 = lStack_98;
    if (*(longlong *)(lStack_98 + 0x478) != 0) {
      lVar14 = *(longlong *)(lStack_98 + 0x478);
    }
    if ((*(byte *)(lVar14 + 0x474) & 1) != 0) {
      lVar14 = *param_7;
      *(int *)((longlong)plVar10 + 0xc) = *(int *)((longlong)plVar10 + 0xc) + 1;
      *(longlong **)(lVar14 + 0x150) = plVar10;
      *(undefined4 *)(lVar14 + 0x158) = 1;
    }
  }
  lVar11 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar14 = *(longlong *)(lVar11 + 0x100);
  if (lVar14 == 0) {
    *(undefined8 *)(puVar23 + -8) = 0x100d68;
    (*_DAT_)();
    lVar14 = *(longlong *)(lVar11 + 0x100);
  }
  puVar22 = puVar23;
  if (*(int *)(lVar14 + 0x22c) != 0) {
    *(undefined8 *)(puVar23 + -8) = 0x100d7e;
    (*_DAT_)();
  }
LAB_:
  uVar20 = uStack_40 ^ (ulonglong)&uStack_128;
  *(undefined8 *)(puVar22 + -8) = 0x100d97;
  func_0x(uVar20);
  return;
}

