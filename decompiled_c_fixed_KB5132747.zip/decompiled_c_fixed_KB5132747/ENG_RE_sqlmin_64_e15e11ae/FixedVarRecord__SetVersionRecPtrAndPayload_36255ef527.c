
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(ushort *param_1,undefined8 param_2,undefined8 param_3)

{
  ushort *puVar1;
  byte bVar2;
  char cVar3;
  ushort uVar4;
  ushort uVar5;
  uint uVar6;
  longlong lVar7;
  undefined8 *puVar8;
  undefined8 uVar9;
  ulonglong *puVar10;
  uint uVar11;
  uint uVar12;
  ulonglong uVar13;
  int iVar14;
  int iVar15;
  uint uVar16;
  ulonglong uVar17;
  byte *pbVar18;
  ulonglong uVar19;
  int iVar20;
  ushort *puVar21;
  undefined8 uStackX_8;
  
  iVar15 = 0;
  iVar20 = 0;
  if (*(int *)(param_1 + 1) == 0) {
    pbVar18 = *(byte **)(param_1 + 3);
    uVar11 = *(uint *)(param_1 + 7);
    uVar13 = (ulonglong)uVar11;
    *param_1 = 0;
    *(uint *)(param_1 + 9) = uVar11;
    bVar2 = *pbVar18;
    if ((bVar2 & 0x10) != 0) {
      uVar11 = uVar11 + 2 + (*(ushort *)(pbVar18 + uVar13) + 7 >> 3);
      uVar13 = (ulonglong)uVar11;
      *(uint *)(param_1 + 9) = uVar11;
      bVar2 = *pbVar18;
    }
    if ((bVar2 & 0x20) == 0) {
      *(int *)(param_1 + 1) = (int)uVar13;
      param_1[0xd] = 0;
      *(int *)(param_1 + 0xb) = (int)uVar13;
    }
    else {
      puVar21 = (ushort *)(pbVar18 + uVar13);
      uVar4 = *puVar21;
      param_1[0xd] = uVar4;
      if (uVar4 == 0) {
        cVar3 = func_0x(0x10fa990);
        if (((cVar3 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
           (*(char *)(lVar7 + 0x499) != '\0')) {
          cVar3 = func_0x(0x10fa990);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x9ea39c,0xb0a488,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),3);
        uVar13 = (ulonglong)*(uint *)(param_1 + 9);
        uVar4 = param_1[0xd];
      }
      uVar11 = (int)uVar13 + (uVar4 + 1) * 2;
      *(uint *)(param_1 + 0xb) = uVar11;
      if (0x1f9e < uVar11) {
        cVar3 = func_0x(0x10fa990);
        if (((cVar3 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
           (*(char *)(lVar7 + 0x499) != '\0')) {
          cVar3 = func_0x(0x10fa990);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9ea39c,0xb0a488,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar4 = param_1[0xd];
        uVar11 = *(uint *)(param_1 + 0xb);
      }
      uVar13 = (ulonglong)uVar4;
      uVar4 = puVar21[uVar13];
      *(uint *)(param_1 + 1) = uVar4 & 0x7fff;
      if ((uVar4 & 0x7fff) < uVar11) {
        cVar3 = func_0x(0x10fa990);
        if (((cVar3 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
           (*(char *)(lVar7 + 0x499) != '\0')) {
          cVar3 = func_0x(0x10fa990);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9ea39c,0xb0a488,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar11 = *(uint *)(param_1 + 0xb);
        uVar13 = (ulonglong)param_1[0xd];
      }
      puVar1 = puVar21;
      iVar14 = iVar15;
      if ((short)uVar13 != 0) {
        do {
          uVar16 = puVar1[1] & 0x7fff;
          if ((uVar16 < uVar11) || (*(uint *)(param_1 + 1) < uVar16)) {
            cVar3 = func_0x(0x10fa990);
            if ((cVar3 != '\0') &&
               ((lVar7 = func_0x(), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0')
                ))) {
              cVar3 = func_0x(0x10fa990);
              if (cVar3 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x9ea39c,0xb0a488,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 3),4);
          }
          uVar13 = (ulonglong)param_1[0xd];
          iVar14 = iVar14 + 1;
          puVar1 = puVar1 + 1;
          uVar11 = uVar16;
        } while (iVar14 < (int)(uint)param_1[0xd]);
      }
      if ((short)puVar21[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
        pbVar18 = *(byte **)(param_1 + 3);
        do {
          uVar11 = *(ushort *)(pbVar18 + uVar13 * 2 + (ulonglong)*(uint *)(param_1 + 9)) & 0x7fff;
          if ((int)uVar13 == 1) {
            uVar16 = *(uint *)(param_1 + 0xb);
            uVar12 = uVar16;
LAB_:
            if ((uVar11 < uVar16) || (uVar6 = *(uint *)(param_1 + 1), uVar6 < uVar11))
            goto LAB_;
          }
          else {
            uVar12 = *(uint *)(param_1 + 0xb);
            uVar16 = *(ushort *)(pbVar18 + uVar13 * 2 + ((ulonglong)*(uint *)(param_1 + 9) - 2)) &
                     0x7fff;
            if (uVar12 <= uVar16) goto LAB_;
LAB_:
            func_0x(pbVar18,7);
            uVar12 = *(uint *)(param_1 + 0xb);
            uVar6 = *(uint *)(param_1 + 1);
          }
          if ((uVar16 < uVar12) || (uVar6 < uVar16)) goto LAB_;
          pbVar18 = *(byte **)(param_1 + 3);
          if (*(ushort *)(pbVar18 + uVar16) == 5) {
            *param_1 = *param_1 | 2;
            param_1[0xd] = param_1[0xd] - 1;
            uVar19 = (ulonglong)(uVar16 & 0xffff);
            param_1[0x14] = (ushort)uVar16;
            uVar13 = *(ulonglong *)(param_1 + 3);
            uVar4 = param_1[0x15] & 0xc7ff;
            if ((*(ushort *)(uVar19 + 2 + uVar13) >> 0xe & 1) != 0) {
              uVar4 = *(ushort *)(uVar19 + 2 + uVar13) & 0x3800 | param_1[0x15] & 0xc7ff;
            }
            param_1[0x15] = uVar4;
            uVar5 = (uVar4 ^ *(ushort *)(uVar19 + 2 + uVar13)) & 0x7ff ^ uVar4;
            param_1[0x15] = uVar5;
            uVar17 = (ulonglong)((uVar5 & 0x7ff) * 2) + 4 + uVar13 + (uVar4 >> 0xb & 7) * 2 + uVar19
            ;
            if (uVar17 < uVar19 + uVar13) {
              func_0x(uVar19 + uVar13,0x19);
              uVar5 = param_1[0x15];
              uVar19 = (ulonglong)param_1[0x14];
              uVar13 = (ulonglong)*(uint *)(param_1 + 3);
            }
            if (uVar11 - uVar16 < (((uVar5 & 0x7ff) * 2 - (int)uVar19) - (int)uVar13) + (int)uVar17)
            {
              func_0x(uVar19 + *(longlong *)(param_1 + 3),0x19);
              uVar5 = param_1[0x15];
            }
            if (((uVar5 & 0x3800) != 0) &&
               (puVar21 = (ushort *)(*(longlong *)(param_1 + 3) + 4 + (ulonglong)param_1[0x14]),
               iVar14 = iVar15, (uVar5 & 0x3800) != 0)) {
              do {
                if ((uVar5 & 0x7ff) < (*puVar21 & 0x7ff)) {
                  func_0x((ulonglong)param_1[0x14] + *(longlong *)(param_1 + 3),0x1a);
                  uVar5 = param_1[0x15];
                }
                iVar14 = iVar14 + 1;
                puVar21 = puVar21 + 1;
              } while (iVar14 < (int)(uVar5 >> 0xb & 7));
            }
            goto LAB_;
          }
          if (*(ushort *)(pbVar18 + uVar16) < 0x400) goto LAB_;
          *param_1 = *param_1 | 1;
          uVar4 = param_1[0xd] - 1;
          param_1[0xd] = uVar4;
          if (uVar4 == 0) goto LAB_;
          uVar13 = (ulonglong)uVar4;
        } while ((short)puVar21[(ulonglong)(uVar4 - 1) + 1] < 0);
        uVar13 = (ulonglong)*(uint *)(param_1 + 1);
      }
      else {
LAB_:
        pbVar18 = *(byte **)(param_1 + 3);
        uVar13 = (ulonglong)*(uint *)(param_1 + 1);
      }
    }
    if ((*pbVar18 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x12) = 0;
    }
    else {
      *(int *)(param_1 + 0x12) = (int)uVar13;
      *(int *)(param_1 + 1) = (int)uVar13 + 0xe;
      puVar8 = (undefined8 *)func_0x(param_1);
      uStackX_8 = *puVar8;
      iVar14 = func_0x(&uStackX_8);
      *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + iVar14;
      uVar13 = (ulonglong)*(uint *)(param_1 + 1);
    }
    iVar14 = (int)uVar13;
    if ((*(ulonglong *)(param_1 + 0xe) != 0) &&
       (*(ulonglong *)(param_1 + 0xe) < uVar13 + *(longlong *)(param_1 + 3))) {
      cVar3 = func_0x(0x10fa990);
      if ((cVar3 != '\0') &&
         ((lVar7 = func_0x(), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0')))) {
        cVar3 = func_0x(0x10fa990);
        if (cVar3 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x9ea39c,0xb0a488,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),0x12);
      iVar14 = *(int *)(param_1 + 1);
    }
    if (0x3f3b < iVar14 - 1U) {
      cVar3 = func_0x(0x10fa990);
      if (((cVar3 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
         (*(char *)(lVar7 + 0x499) != '\0')) {
        cVar3 = func_0x(0x10fa990);
        if (cVar3 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x9ea39c,0xb0a488,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),5);
    }
  }
LAB_:
  uVar9 = func_0x(param_1);
  func_0x(uVar9,param_2,param_3);
  pbVar18 = *(byte **)(param_1 + 3);
  uVar11 = *(uint *)(param_1 + 7);
  uVar13 = (ulonglong)uVar11;
  *(undefined4 *)(param_1 + 1) = 0;
  *param_1 = 0;
  *(uint *)(param_1 + 9) = uVar11;
  bVar2 = *pbVar18;
  if ((bVar2 & 0x10) != 0) {
    uVar11 = uVar11 + 2 + (*(ushort *)(pbVar18 + uVar13) + 7 >> 3);
    uVar13 = (ulonglong)uVar11;
    *(uint *)(param_1 + 9) = uVar11;
    bVar2 = *pbVar18;
  }
  if ((bVar2 & 0x20) == 0) {
    *(int *)(param_1 + 1) = (int)uVar13;
    param_1[0xd] = 0;
    *(int *)(param_1 + 0xb) = (int)uVar13;
  }
  else {
    puVar21 = (ushort *)(pbVar18 + uVar13);
    uVar4 = *puVar21;
    param_1[0xd] = uVar4;
    if (uVar4 == 0) {
      cVar3 = func_0x(0x10fa990);
      if (((cVar3 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
         (*(char *)(lVar7 + 0x499) != '\0')) {
        cVar3 = func_0x(0x10fa990);
        if (cVar3 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3eb);
        }
        else {
          (*_DAT_)(1,0x9ea39c,0xb0a488,0x80f,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),3);
      uVar13 = (ulonglong)*(uint *)(param_1 + 9);
      uVar4 = param_1[0xd];
    }
    uVar11 = (int)uVar13 + (uVar4 + 1) * 2;
    *(uint *)(param_1 + 0xb) = uVar11;
    if (0x1f9e < uVar11) {
      cVar3 = func_0x(0x10fa990);
      if (((cVar3 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
         (*(char *)(lVar7 + 0x499) != '\0')) {
        cVar3 = func_0x(0x10fa990);
        if (cVar3 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ec);
        }
        else {
          (*_DAT_)(1,0x9ea39c,0xb0a488,0x816,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),4);
      uVar4 = param_1[0xd];
      uVar11 = *(uint *)(param_1 + 0xb);
    }
    uVar13 = (ulonglong)uVar4;
    uVar4 = puVar21[uVar13];
    *(uint *)(param_1 + 1) = uVar4 & 0x7fff;
    if ((uVar4 & 0x7fff) < uVar11) {
      cVar3 = func_0x(0x10fa990);
      if (((cVar3 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
         (*(char *)(lVar7 + 0x499) != '\0')) {
        cVar3 = func_0x(0x10fa990);
        if (cVar3 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ec);
        }
        else {
          (*_DAT_)(1,0x9ea39c,0xb0a488,0x81d,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),4);
      uVar11 = *(uint *)(param_1 + 0xb);
      uVar13 = (ulonglong)param_1[0xd];
    }
    puVar1 = puVar21;
    iVar14 = iVar15;
    if ((short)uVar13 != 0) {
      do {
        uVar16 = puVar1[1] & 0x7fff;
        if ((uVar16 < uVar11) || (*(uint *)(param_1 + 1) < uVar16)) {
          cVar3 = func_0x(0x10fa990);
          if ((cVar3 != '\0') &&
             ((lVar7 = func_0x(), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0')))
             ) {
            cVar3 = func_0x(0x10fa990);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x9ea39c,0xb0a488,0x82a,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 3),4);
        }
        uVar13 = (ulonglong)param_1[0xd];
        iVar14 = iVar14 + 1;
        puVar1 = puVar1 + 1;
        uVar11 = uVar16;
      } while (iVar14 < (int)(uint)param_1[0xd]);
    }
    if ((short)puVar21[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
      pbVar18 = *(byte **)(param_1 + 3);
      do {
        uVar11 = *(ushort *)(pbVar18 + uVar13 * 2 + (ulonglong)*(uint *)(param_1 + 9)) & 0x7fff;
        if ((int)uVar13 == 1) {
          uVar16 = *(uint *)(param_1 + 0xb);
          uVar12 = uVar16;
LAB_:
          if ((uVar11 < uVar16) || (*(uint *)(param_1 + 1) < uVar11)) goto LAB_;
        }
        else {
          uVar12 = *(uint *)(param_1 + 0xb);
          uVar16 = *(ushort *)(pbVar18 + uVar13 * 2 + ((ulonglong)*(uint *)(param_1 + 9) - 2)) &
                   0x7fff;
          if (uVar12 <= uVar16) goto LAB_;
LAB_:
          func_0x(pbVar18,7);
          uVar12 = *(uint *)(param_1 + 0xb);
        }
        if (uVar16 < uVar12) {
          return;
        }
        if (*(uint *)(param_1 + 1) < uVar16) {
          return;
        }
        pbVar18 = *(byte **)(param_1 + 3);
        if (*(ushort *)(pbVar18 + uVar16) == 5) {
          *param_1 = *param_1 | 2;
          param_1[0xd] = param_1[0xd] - 1;
          uVar19 = (ulonglong)(uVar16 & 0xffff);
          param_1[0x14] = (ushort)uVar16;
          uVar13 = *(ulonglong *)(param_1 + 3);
          uVar4 = param_1[0x15] & 0xc7ff;
          if ((*(ushort *)(uVar19 + 2 + uVar13) >> 0xe & 1) != 0) {
            uVar4 = *(ushort *)(uVar19 + 2 + uVar13) & 0x3800 | param_1[0x15] & 0xc7ff;
          }
          param_1[0x15] = uVar4;
          uVar5 = (uVar4 ^ *(ushort *)(uVar19 + 2 + uVar13)) & 0x7ff ^ uVar4;
          param_1[0x15] = uVar5;
          uVar17 = (ulonglong)((uVar5 & 0x7ff) * 2) + 4 + uVar13 + (uVar4 >> 0xb & 7) * 2 + uVar19;
          if (uVar17 < uVar19 + uVar13) {
            func_0x(uVar19 + uVar13,0x19);
            uVar5 = param_1[0x15];
            uVar19 = (ulonglong)param_1[0x14];
            uVar13 = (ulonglong)*(uint *)(param_1 + 3);
          }
          if (uVar11 - uVar16 < (((uVar5 & 0x7ff) * 2 - (int)uVar19) - (int)uVar13) + (int)uVar17) {
            func_0x(uVar19 + *(longlong *)(param_1 + 3),0x19);
            uVar5 = param_1[0x15];
          }
          if (((uVar5 & 0x3800) != 0) &&
             (puVar21 = (ushort *)(*(longlong *)(param_1 + 3) + 4 + (ulonglong)param_1[0x14]),
             (uVar5 & 0x3800) != 0)) {
            do {
              if ((uVar5 & 0x7ff) < (*puVar21 & 0x7ff)) {
                func_0x((ulonglong)param_1[0x14] + *(longlong *)(param_1 + 3),0x1a);
                uVar5 = param_1[0x15];
              }
              iVar15 = iVar15 + 1;
              puVar21 = puVar21 + 1;
            } while (iVar15 < (int)(uVar5 >> 0xb & 7));
          }
          goto LAB_;
        }
        if (*(ushort *)(pbVar18 + uVar16) < 0x400) goto LAB_;
        *param_1 = *param_1 | 1;
        uVar4 = param_1[0xd] - 1;
        param_1[0xd] = uVar4;
        if (uVar4 == 0) goto LAB_;
        uVar13 = (ulonglong)uVar4;
      } while ((short)puVar21[(ulonglong)(uVar4 - 1) + 1] < 0);
      uVar13 = (ulonglong)*(uint *)(param_1 + 1);
    }
    else {
LAB_:
      pbVar18 = *(byte **)(param_1 + 3);
      uVar13 = (ulonglong)*(uint *)(param_1 + 1);
    }
  }
  if ((*pbVar18 & 0x40) == 0) {
    *(undefined4 *)(param_1 + 0x12) = 0;
  }
  else {
    *(int *)(param_1 + 0x12) = (int)uVar13;
    *(int *)(param_1 + 1) = (int)uVar13 + 0xe;
    puVar10 = (ulonglong *)func_0x(param_1);
    uVar5 = (ushort)(*puVar10 >> 0x30);
    uVar4 = uVar5;
    if ((((uint)(int)(short)uVar5 >> 1 ^ (int)(short)uVar5) & 0x2000) != 0) {
      uVar4 = uVar5 & 0xdfff;
      if ((uVar5 >> 0xe & 1) != 0) {
        uVar4 = uVar5 | 0x2000;
      }
    }
    if (uVar4 == 0xfffc) {
      iVar20 = (int)((*puVar10 >> 0x20 & 0xffff) >> 5);
    }
    *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + iVar20;
    uVar13 = (ulonglong)*(uint *)(param_1 + 1);
  }
  iVar20 = (int)uVar13;
  if ((*(ulonglong *)(param_1 + 0xe) != 0) &&
     (*(ulonglong *)(param_1 + 0xe) < uVar13 + *(longlong *)(param_1 + 3))) {
    cVar3 = func_0x(0x10fa990);
    if ((cVar3 != '\0') &&
       ((lVar7 = func_0x(), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0')))) {
      cVar3 = func_0x(0x10fa990);
      if (cVar3 == '\0') {
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        (*_DAT_)(1,0x9ea39c,0xb0a488,0x886,0);
      }
    }
    func_0x(*(undefined8 *)(param_1 + 3),0x12);
    iVar20 = *(int *)(param_1 + 1);
  }
  if (0x3f3b < iVar20 - 1U) {
    cVar3 = func_0x(0x10fa990);
    if (((cVar3 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
       (*(char *)(lVar7 + 0x499) != '\0')) {
      cVar3 = func_0x(0x10fa990);
      if (cVar3 == '\0') {
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        (*_DAT_)(1,0x9ea39c,0xb0a488,0x88b,0);
      }
    }
    func_0x(*(undefined8 *)(param_1 + 3),5);
  }
  return;
}

