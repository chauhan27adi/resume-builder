
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(ulonglong param_1,longlong **param_2,int param_3,undefined4 param_4,int param_5,
                 undefined8 param_6)

{
  byte *pbVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  ushort *puVar6;
  bool bVar7;
  longlong **pplVar8;
  ulonglong uVar9;
  char cVar10;
  byte bVar11;
  short sVar12;
  ushort uVar13;
  int iVar14;
  undefined8 uVar15;
  uint uVar16;
  undefined4 *puVar17;
  ulonglong *puVar18;
  ushort uVar19;
  longlong lVar20;
  longlong lVar21;
  uint uVar22;
  ulonglong uVar23;
  undefined8 *puVar24;
  undefined8 *puVar25;
  uint uVar26;
  ulonglong uVar27;
  byte *pbVar28;
  uint uVar29;
  byte bVar30;
  uint uVar31;
  ulonglong uVar32;
  ushort *puVar33;
  byte *pbVar34;
  undefined auStack_328 [24];
  undefined8 uStack_310;
  undefined8 auStack_308 [4];
  undefined8 uStack_2e8;
  undefined4 uStack_2e0;
  undefined4 uStack_2dc;
  undefined4 uStack_2d8;
  undefined4 uStack_2d4;
  undefined8 uStack_2d0;
  undefined8 uStack_2c8;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined4 uStack_2b8;
  undefined4 uStack_2b4;
  undefined4 auStack_2b0 [2];
  undefined2 auStack_2a8 [4];
  undefined8 uStack_2a0;
  undefined auStack_298 [32];
  ulonglong uStack_278;
  undefined8 uStack_270;
  undefined uStack_268;
  short sStack_258;
  ushort uStack_256;
  uint uStack_254;
  byte *pbStack_250;
  undefined8 uStack_248;
  uint uStack_240;
  ushort uStack_23c;
  byte *pbStack_23a;
  undefined2 uStack_232;
  undefined2 uStack_230;
  ushort uStack_22e;
  ushort uStack_22c;
  undefined2 uStack_22a;
  undefined4 uStack_228;
  int iStack_220;
  undefined4 uStack_21c;
  undefined2 uStack_218;
  undefined2 uStack_216;
  undefined4 uStack_214;
  undefined2 uStack_210;
  undefined2 uStack_20e;
  undefined8 uStack_208;
  undefined4 uStack_200;
  undefined4 uStack_1fc;
  ulonglong uStack_1f8;
  undefined4 uStack_1f0;
  undefined4 uStack_1ec;
  undefined2 uStack_1e8;
  undefined2 uStack_1e6;
  undefined4 uStack_1e4;
  undefined2 uStack_1e0;
  undefined2 uStack_1de;
  undefined4 uStack_1dc;
  undefined2 uStack_1d8;
  undefined2 uStack_1d6;
  longlong **pplStack_1d0;
  undefined8 uStack_1c8;
  undefined4 uStack_1c0;
  uint uStack_1bc;
  undefined8 *puStack_1b8;
  undefined8 uStack_1b0;
  uint uStack_1a8;
  undefined2 uStack_1a4;
  undefined8 uStack_1a2;
  undefined2 uStack_19a;
  undefined2 uStack_198;
  undefined6 uStack_196;
  undefined4 uStack_188;
  undefined2 uStack_184;
  undefined8 uStack_180;
  undefined4 uStack_178;
  undefined8 uStack_170;
  undefined8 uStack_168;
  undefined8 uStack_160;
  undefined4 *puStack_158;
  undefined4 *puStack_150;
  undefined4 *puStack_148;
  undefined2 uStack_140;
  char cStack_13e;
  longlong alStack_138 [3];
  byte bStack_120;
  undefined7 uStack_11f;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined8 uStack_108;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined8 uStack_e8;
  undefined4 uStack_d8;
  undefined4 auStack_d4 [31];
  ulonglong uStack_58;
  
  puVar25 = (undefined8 *)auStack_298;
  uStack_58 = _DAT_ ^ (ulonglong)&sStack_258;
  uStack_168 = 0x78;
  puStack_1b8 = (undefined8 *)0x0;
  uStack_1c0 = CONCAT22(uStack_1c0._2_2_,0xffff);
  uStack_1bc = 0;
  puStack_158 = &uStack_d8;
  uStack_1a2 = 0;
  puStack_148 = auStack_d4;
  uStack_198 = 0;
  uStack_196 = 0;
  puStack_150 = &uStack_d8;
  uStack_208 = *(longlong *)(param_1 + 0x50);
  uStack_1b0 = 0;
  uStack_188 = 0;
  uStack_184 = 0;
  uStack_180 = 0;
  uStack_178 = 0;
  uStack_170 = 0;
  uStack_160 = 0;
  uStack_140 = 0;
  cStack_13e = '\0';
  uStack_d8 = 0x4000000;
  uStack_1f8 = param_1;
  lVar20 = *(longlong *)(*(longlong *)(param_1 + 0x10) + 0x58);
  uStack_1f0 = param_4;
  iStack_220 = param_3;
  pplStack_1d0 = param_2;
  if (((*(uint *)(lVar20 + 0x14) & 0xe0000000) != 0x80000000) ||
     (bVar7 = true, 0xff < *(ushort *)(lVar20 + 0x18))) {
    bVar7 = false;
  }
  uVar16 = 0x68;
  if (!bVar7) {
    uVar16 = 0x54;
  }
  lVar20 = uStack_208;
  if ((param_5 == 1) && ((*(uint *)(param_1 + 0x3c) & 0x10000) != 0)) {
    uVar32 = 0;
    uStack_254 = 0;
    uVar27 = 0;
    pbStack_23a = (byte *)0x0;
    lVar20 = **param_2;
    uVar29 = 9;
    uStack_22e = 0;
    uStack_22c = 0;
    uStack_22a = 0;
    uStack_248 = 0;
    uVar23 = (ulonglong)*(ushort *)(lVar20 + 0xe);
    pbStack_250 = (byte *)((ulonglong)*(ushort *)(lVar20 + (0xfff - (longlong)param_3) * 2) + lVar20
                          );
    if ((*pbStack_250 & 1) == 0) {
      sStack_258 = 0;
      uStack_232 = 0;
      uStack_230 = 0;
      uVar9 = uVar32;
      switch(*pbStack_250 & 0xe) {
      default:
        uVar23 = (ulonglong)*(ushort *)(pbStack_250 + 2);
        uVar9 = uVar27;
        if (0x1f9d < *(ushort *)(pbStack_250 + 2) - 1) {
          uStack_2a0 = 0x10039d;
          func_0x(pbStack_250,6);
          uVar9 = (ulonglong)uStack_254;
        }
        break;
      case 4:
        uVar23 = 9;
        uVar9 = uVar27;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar23 = 1;
        uVar9 = uVar27;
      }
      uVar27 = uVar9;
      uStack_248 = CONCAT44(uStack_248._4_4_,(int)uVar23);
      pbStack_23a = (byte *)(lVar20 + 0x2000);
    }
    else {
      sStack_258 = 1;
      bVar11 = *pbStack_250;
      switch(bVar11 & 0x1c) {
      default:
        if ((char)pbStack_250[1] < '\0') {
          uStack_256 = (*(ushort *)(pbStack_250 + 1) & 0x7f) << 8 |
                       *(ushort *)(pbStack_250 + 1) >> 8;
          uVar13 = 3;
          sVar12 = 3;
        }
        else {
          uStack_256 = (ushort)pbStack_250[1];
          uVar13 = 2;
          sVar12 = 2;
        }
        uStack_23c = ((ushort)(uStack_256 + 1) >> 1) + sVar12;
        if (uStack_256 < 0x1f) {
          lVar20 = lVar20 + 0x2000;
          uStack_240 = (uint)uVar13;
          uStack_230 = (undefined2)lVar20;
          uStack_22e = (ushort)((ulonglong)lVar20 >> 0x10);
          uStack_22c = (ushort)((ulonglong)lVar20 >> 0x20);
          uStack_22a = (undefined2)((ulonglong)lVar20 >> 0x30);
          uStack_228 = 0;
          uVar23 = uVar32;
          uVar27 = uVar32;
        }
        else {
          iVar14 = uStack_256 - 1;
          uStack_228 = 0;
          uVar23 = 0;
          lVar20 = lVar20 + 0x2000;
          uStack_230 = (undefined2)lVar20;
          uStack_22e = (ushort)((ulonglong)lVar20 >> 0x10);
          uStack_22c = (ushort)((ulonglong)lVar20 >> 0x20);
          uStack_22a = (undefined2)((ulonglong)lVar20 >> 0x30);
          uStack_240 = CONCAT22(((short)(iVar14 / 0x1e) + (short)(iVar14 >> 0x1f)) -
                                (short)((longlong)iVar14 * 0x88888889 >> 0x3f),uVar13);
        }
        break;
      case 4:
        if (((bVar11 & 0x1c) == 4) && ((bVar11 & 2) != 0)) {
          uVar27 = 0xf;
          uStack_240 = 0;
          lVar20 = lVar20 + 0x2000;
          uStack_254 = 0xf;
          uStack_230 = (undefined2)lVar20;
          uStack_22e = (ushort)((ulonglong)lVar20 >> 0x10);
          uStack_22c = (ushort)((ulonglong)lVar20 >> 0x20);
          uStack_22a = (undefined2)((ulonglong)lVar20 >> 0x30);
          uVar23 = 0;
          uStack_256 = 0;
          uStack_23c = 0;
          uStack_232 = 0;
          uStack_228 = 1;
        }
        else {
          uVar27 = 1;
          uStack_240 = 0;
          lVar20 = lVar20 + 0x2000;
          uStack_254 = 1;
          uStack_230 = (undefined2)lVar20;
          uStack_22e = (ushort)((ulonglong)lVar20 >> 0x10);
          uStack_22c = (ushort)((ulonglong)lVar20 >> 0x20);
          uStack_22a = (undefined2)((ulonglong)lVar20 >> 0x30);
          uVar23 = 0;
          uStack_256 = 0;
          uStack_23c = 0;
          uStack_232 = 0;
          uStack_228 = 0;
        }
        break;
      case 8:
        lVar20 = lVar20 + 0x2000;
        uStack_240 = 0;
        uStack_230 = (undefined2)lVar20;
        uStack_22e = (ushort)((ulonglong)lVar20 >> 0x10);
        uStack_22c = (ushort)((ulonglong)lVar20 >> 0x20);
        uStack_22a = (undefined2)((ulonglong)lVar20 >> 0x30);
        uVar27 = 9;
        uStack_256 = 0;
        uVar23 = 0;
        uStack_23c = 0;
        uStack_232 = 0;
        uStack_254 = 9;
        uStack_228 = 0;
      }
    }
    uVar26 = (uint)uVar27;
    if (sStack_258 == 0) {
      pbVar28 = pbStack_250;
      if (uVar26 == 0) {
        uStack_256 = 0;
        uVar26 = (uint)uVar23;
        uVar27 = uVar23;
        if ((*pbStack_250 & 0x10) != 0) {
          uVar26 = uVar26 + 2 + (*(ushort *)(pbStack_250 + uVar23) + 7 >> 3);
          uVar27 = (ulonglong)uVar26;
        }
        uStack_248 = CONCAT44(uVar26,(undefined4)uStack_248);
        if ((*pbStack_250 & 0x20) == 0) {
          uStack_254 = (uint)uVar27;
          uStack_23c = 0;
          uStack_240 = (uint)uVar27;
        }
        else {
          puVar33 = (ushort *)(pbStack_250 + uVar27);
          uStack_23c = *puVar33;
          if (*puVar33 == 0) {
            uStack_2a0 = 0x100456;
            cVar10 = func_0x(0x1c60860);
            if (cVar10 != '\0') {
              uStack_2a0 = 0x10045f;
              lVar20 = func_0x();
              if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                uStack_2a0 = 0x100479;
                cVar10 = func_0x(0x1c60860);
                if (cVar10 == '\0') {
                  uStack_2a0 = 0x100495;
                  (*pcRam00000000011ce3e8)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  uStack_278 = 0;
                  uStack_2a0 = 0x1004bb;
                  (*_DAT_)(1,0x155026c,0x1670358,0x80f);
                }
              }
            }
            uStack_2a0 = 0x1004c9;
            func_0x(pbStack_250,3);
          }
          uStack_240 = uStack_248._4_4_ + 2 + (uint)uStack_23c * 2;
          if (0x1f9e < uStack_240) {
            uStack_2a0 = 0x1004fc;
            cVar10 = func_0x(0x1c60860);
            if (cVar10 != '\0') {
              uStack_2a0 = 0x100505;
              lVar20 = func_0x();
              if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                uStack_2a0 = 0x10051f;
                cVar10 = func_0x(0x1c60860);
                if (cVar10 == '\0') {
                  uStack_2a0 = 0x10053b;
                  (*pcRam00000000011ce3e8)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_278 = 0;
                  uStack_2a0 = 0x100561;
                  (*_DAT_)(1,0x155026c,0x1670358,0x816);
                }
              }
            }
            uStack_2a0 = 0x10056f;
            func_0x(pbStack_250,4);
          }
          uVar23 = (ulonglong)uStack_23c;
          uStack_254 = puVar33[uVar23] & 0x7fff;
          if ((puVar33[uVar23] & 0x7fff) < uStack_240) {
            uStack_2a0 = 0x1005a3;
            cVar10 = func_0x(0x1c60860);
            if (cVar10 != '\0') {
              uStack_2a0 = 0x1005ac;
              lVar20 = func_0x();
              if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                uStack_2a0 = 0x1005c6;
                cVar10 = func_0x(0x1c60860);
                if (cVar10 == '\0') {
                  uStack_2a0 = 0x1005e2;
                  (*pcRam00000000011ce3e8)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_278 = 0;
                  uStack_2a0 = 0x100608;
                  (*_DAT_)(1,0x155026c,0x1670358,0x81d);
                }
              }
            }
            uStack_2a0 = 0x100616;
            func_0x(pbStack_250,4);
            uVar23 = (ulonglong)uStack_23c;
          }
          uVar27 = (ulonglong)uStack_254;
          pbVar28 = pbStack_250;
          puVar6 = puVar33;
          uVar26 = uStack_240;
          uVar22 = uStack_240;
          if ((short)uVar23 != 0) {
            do {
              uVar22 = puVar6[1] & 0x7fff;
              if ((uVar22 < uVar26) || ((uint)uVar27 < uVar22)) {
                uStack_2a0 = 0x100663;
                cVar10 = func_0x(0x1c60860);
                if (cVar10 != '\0') {
                  uStack_2a0 = 0x10066c;
                  lVar20 = func_0x();
                  if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                    uStack_2a0 = 0x100686;
                    cVar10 = func_0x(0x1c60860);
                    if (cVar10 == '\0') {
                      uStack_2a0 = 0x1006a2;
                      (*pcRam00000000011ce3e8)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_278 = 0;
                      uStack_2a0 = 0x1006c8;
                      (*_DAT_)(1,0x155026c,0x1670358,0x82a);
                    }
                  }
                }
                uStack_2a0 = 0x1006d6;
                func_0x(pbStack_250,4);
                uVar23 = (ulonglong)uStack_23c;
                uVar27 = (ulonglong)uStack_254;
                pbVar28 = pbStack_250;
              }
              uVar31 = (int)uVar32 + 1;
              uVar32 = (ulonglong)uVar31;
              puVar6 = puVar6 + 1;
              uVar26 = uVar22;
              uVar22 = uStack_240;
              param_1 = uStack_1f8;
            } while ((int)uVar31 < (int)uVar23);
          }
          while( true ) {
            if (-1 < (short)puVar33[(ulonglong)((int)uVar23 - 1) + 1]) break;
            uVar26 = uVar22;
            if ((int)uVar23 != 1) {
              uVar26 = *(ushort *)(pbVar28 + uVar23 * 2 + ((uStack_248 >> 0x20) - 2)) & 0x7fff;
            }
            uVar31 = *(ushort *)(pbVar28 + uVar23 * 2 + (uStack_248 >> 0x20)) & 0x7fff;
            if (((uVar26 < uVar22) || (uVar31 < uVar26)) ||
               (uVar13 = (ushort)uVar23, (uint)uVar27 < uVar31)) {
              uStack_2a0 = 0x100768;
              func_0x(pbVar28,7);
              uVar27 = (ulonglong)uStack_254;
              pbVar28 = pbStack_250;
              uVar13 = uStack_23c;
              uVar22 = uStack_240;
            }
            if ((uVar26 < uVar22) || ((uint)uVar27 < uVar26)) goto code_r0x00100ac3;
            if (*(ushort *)(pbVar28 + uVar26) == 5) {
              uStack_256 = uStack_256 | 2;
              uStack_23c = uVar13 - 1;
              uVar23 = (ulonglong)(uVar26 & 0xffff);
              pbVar1 = pbVar28 + uVar23;
              uStack_22e = (ushort)uVar26;
              uVar13 = *(ushort *)(pbVar1 + 2);
              uVar19 = uStack_22c & 0xc7ff;
              if ((uVar13 >> 0xe & 1) != 0) {
                uVar19 = (uVar13 ^ uStack_22c) & 0x3800 ^ uStack_22c;
              }
              uStack_22c = (uVar19 ^ uVar13) & 0x7ff ^ uVar19;
              pbVar34 = pbVar28 + (ulonglong)((uStack_22c & 0x7ff) * 2) + 4 +
                                  uVar23 + (uVar19 >> 0xb & 7) * 2;
              if (pbVar34 < pbVar1) {
                uStack_2a0 = 0x100857;
                func_0x(pbVar1,0x19);
                uVar27 = (ulonglong)uStack_254;
                uVar23 = (ulonglong)uStack_22e;
                pbVar28 = pbStack_250;
              }
              if (uVar31 - uVar26 <
                  (((uStack_22c & 0x7ff) * 2 - (int)uVar23) - (int)pbStack_250) + (int)pbVar34) {
                uStack_2a0 = 0x100896;
                func_0x(pbVar28 + uVar23,0x19);
                uVar27 = (ulonglong)uStack_254;
                uVar23 = (ulonglong)uStack_22e;
                pbVar28 = pbStack_250;
              }
              if ((uStack_22c & 0x3800) != 0) {
                puVar33 = (ushort *)(pbVar28 + uVar23 + 4);
                iVar14 = 0;
                uVar13 = uStack_22c;
                if ((uStack_22c & 0x3800) != 0) {
                  do {
                    if ((uVar13 & 0x7ff) < (*puVar33 & 0x7ff)) {
                      uStack_2a0 = 0x100903;
                      func_0x(pbVar28 + uVar23,0x1a);
                      uVar23 = (ulonglong)uStack_22e;
                      pbVar28 = pbStack_250;
                      uVar13 = uStack_22c;
                    }
                    iVar14 = iVar14 + 1;
                    puVar33 = puVar33 + 1;
                  } while (iVar14 < (int)((uStack_22c & 0x3800) >> 0xb));
                  uVar27 = (ulonglong)uStack_254;
                }
              }
              break;
            }
            if (*(ushort *)(pbVar28 + uVar26) < 0x400) break;
            uStack_256 = uStack_256 | 1;
            uStack_23c = uVar13 - 1;
            uVar23 = (ulonglong)uStack_23c;
            if (uStack_23c == 0) break;
          }
        }
        if ((*pbVar28 & 0x40) == 0) {
          uStack_232 = 0;
          uStack_230 = 0;
        }
        else {
          uStack_232 = (undefined2)uVar27;
          uStack_230 = (undefined2)(uVar27 >> 0x10);
          uStack_254 = (int)uVar27 + 0xe;
          uStack_2a0 = 0x10095a;
          uVar15 = func_0x(&uStack_256);
          uStack_2a0 = 0x100969;
          func_0x(uVar15,&uStack_1c8);
          uStack_2a0 = 0x100975;
          iVar14 = func_0x(&uStack_1c8);
          uVar27 = (ulonglong)(uStack_254 + iVar14);
          uStack_254 = uStack_254 + iVar14;
          pbVar28 = pbStack_250;
        }
        if ((pbStack_23a != (byte *)0x0) && (pbStack_23a < pbVar28 + uVar27)) {
          uStack_2a0 = 0x1009b2;
          cVar10 = func_0x(0x1c60860);
          if (cVar10 != '\0') {
            uStack_2a0 = 0x1009bb;
            lVar20 = func_0x();
            if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
              uStack_2a0 = 0x1009d5;
              cVar10 = func_0x(0x1c60860);
              if (cVar10 == '\0') {
                uStack_2a0 = 0x1009f1;
                (*pcRam00000000011ce3e8)(0x22,0x44,0x15,0x3fa);
              }
              else {
                uStack_278 = 0;
                uStack_2a0 = 0x100a17;
                (*_DAT_)(1,0x155026c,0x1670358,0x886);
              }
            }
          }
          uStack_2a0 = 0x100a25;
          func_0x(pbStack_250,0x12);
          uVar27 = (ulonglong)uStack_254;
          pbVar28 = pbStack_250;
        }
        if (0x3f3b < (int)uVar27 - 1U) {
          uStack_2a0 = 0x100a48;
          cVar10 = func_0x(0x1c60860);
          if (cVar10 != '\0') {
            uStack_2a0 = 0x100a51;
            lVar20 = func_0x();
            if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
              uStack_2a0 = 0x100a6b;
              cVar10 = func_0x(0x1c60860);
              if (cVar10 == '\0') {
                uStack_2a0 = 0x100a87;
                (*pcRam00000000011ce3e8)(0x22,0x44,0x15,0x3ed);
              }
              else {
                uStack_278 = 0;
                uStack_2a0 = 0x100aad;
                (*_DAT_)(1,0x155026c,0x1670358,0x88b);
              }
            }
          }
          uStack_2a0 = 0x100abb;
          func_0x(pbStack_250,5);
          uVar27 = (ulonglong)uStack_254;
          pbVar28 = pbStack_250;
        }
      }
code_r0x00100ac3:
      param_2 = pplStack_1d0;
      if ((8 < (uint)uVar27) || (((*pbVar28 & 0xe) != 0 && ((*pbVar28 & 0xe) != 0xc)))) {
        uVar29 = (uint)uVar27;
      }
    }
    else {
      if (uVar26 == 0) {
        uStack_2a0 = 0x100aef;
        func_0x(&uStack_256);
        uVar26 = uStack_254;
      }
      if ((8 < uVar26) || (((*pbStack_250 & 0x1c) != 0 && ((*pbStack_250 & 0x1c) != 0xc)))) {
        uVar29 = uVar26;
      }
    }
    lVar20 = uStack_208;
    if (uVar29 == uVar16) {
      uStack_2a0 = 0x100b26;
      uVar29 = func_0x(param_2,*(undefined8 *)(param_1 + 8));
      lVar20 = uStack_208;
      if (uVar29 < 0xe) {
        uVar13 = *(ushort *)(*(longlong *)(param_1 + 0x50) + 0xc) & 0xf;
        if (uVar13 == 0) {
          if (*(ushort *)(*(longlong *)(param_1 + 0x50) + 0xe) < 0x33) {
code_r0x00100bf3:
            uVar16 = uVar16 - 0xe;
          }
          else {
            uStack_2a0 = 0x100b53;
            func_0x(param_2);
            uStack_2a0 = 0x100b5b;
            func_0x(param_1);
            uStack_268 = 1;
            uStack_270 = 0;
            uStack_278 = uStack_278 & 0xffffffff00000000;
            uStack_2a0 = 0x100b83;
            func_0x(param_2,4,0xffffffff,0);
            uVar16 = uVar16 - 0xe;
            lVar20 = uStack_208;
          }
        }
        else {
          if (uVar13 == 8) goto code_r0x00100bf3;
          lVar21 = *(longlong *)(*(longlong *)(param_1 + 0x10) + 0x58);
          if (((*(uint *)(lVar21 + 0x14) & 0xe0000000) == 0x80000000) &&
             (*(ushort *)(lVar21 + 0x18) < 0x100)) {
            if (*(ushort *)(uStack_208 + 0x10) < 5) goto code_r0x00100bf3;
            uStack_2a0 = 0x100bc9;
            func_0x(param_1 + 8);
            uVar16 = uVar16 - 0xe;
          }
          else {
            if (*(ushort *)(uStack_208 + 0x10) < 4) goto code_r0x00100bf3;
            uStack_2a0 = 0x100be6;
            func_0x(param_1 + 8);
            uVar16 = uVar16 - 0xe;
          }
        }
      }
    }
  }
  uVar23 = 0;
  uVar13 = *(ushort *)(lVar20 + 0xc) & 0xf;
  if ((*(ushort *)(lVar20 + 0xc) & 0xf) == 0) {
LAB_:
    *(undefined4 *)(*(longlong *)(param_1 + 0x50) + 0x10) = *(undefined4 *)(param_1 + 0x34);
    puVar24 = *(undefined8 **)(param_1 + 0x50);
    puVar25 = (undefined8 *)auStack_298;
  }
  else {
    if (uVar13 != 1) {
      if (uVar13 != 8) {
        uStack_278 = 0x12cb7d0;
        uStack_2a0 = 0x100c5d;
        (*_DAT_)(1,0x16d1b60,0x16d54d8,0x852);
        goto LAB_;
      }
      goto LAB_;
    }
    lVar20 = *(longlong *)(*(longlong *)(param_1 + 0x10) + 0x58);
    if (((*(uint *)(lVar20 + 0x14) & 0xe0000000) == 0x80000000) &&
       (*(ushort *)(lVar20 + 0x18) < 0x100)) {
      puVar4 = *(undefined8 **)(param_1 + 0x50);
      puVar24 = &uStack_2e8;
      uStack_2e8 = *puVar4;
      uStack_2e0 = *(undefined4 *)(puVar4 + 1);
      uStack_2d8 = *(undefined4 *)(puVar4 + 2);
      uStack_2d4 = *(undefined4 *)(param_1 + 0x34);
      uStack_2dc = CONCAT22((short)((uint)*(undefined4 *)((longlong)puVar4 + 0xc) >> 0x10),6);
      uVar13 = *(ushort *)(puVar4 + 2);
      if (5 < uVar13) {
        auStack_308[0] = 0;
        (*_DAT_)(1,0x1705c30,0x16d54d8,0x792);
        uVar13 = *(ushort *)(puVar4 + 2);
      }
      puVar25 = (undefined8 *)auStack_328;
      if (uVar13 != 0) {
        do {
          lVar20 = uVar23 + 2;
          uVar29 = (int)uVar23 + 1;
          (&uStack_2d0)[uVar23 * 2] = *(undefined8 *)((longlong)puVar4 + uVar23 * 0x10 + 0x14);
          *(undefined4 *)(puVar24 + lVar20 * 2) =
               *(undefined4 *)((longlong)puVar4 + uVar23 * 0x10 + 0x1c);
          *(undefined2 *)((longlong)&uStack_2e8 + lVar20 * 0x10 + 4) =
               *(undefined2 *)(puVar4 + uVar23 * 2 + 4);
          *(undefined2 *)((longlong)&uStack_2e8 + lVar20 * 0x10 + 6) =
               *(undefined2 *)((longlong)puVar4 + uVar23 * 0x10 + 0x22);
          puVar25 = (undefined8 *)auStack_328;
          uVar23 = (ulonglong)uVar29;
        } while (uVar29 < *(ushort *)(puVar4 + 2));
      }
    }
    else {
      puVar17 = *(undefined4 **)(param_1 + 0x50);
      puVar24 = &uStack_2c8;
      uStack_2c8._0_4_ = *puVar17;
      uStack_2c8._4_4_ = puVar17[1];
      uStack_2c0 = puVar17[2];
      uStack_2b8 = puVar17[4];
      uStack_2b4 = *(undefined4 *)(param_1 + 0x34);
      uStack_2bc = CONCAT22((short)((uint)puVar17[3] >> 0x10),5);
      uVar13 = *(ushort *)(puVar17 + 4);
      if (5 < uVar13) {
        uStack_2e8 = 0;
        uStack_310 = 0x100d9b;
        (*_DAT_)(1,0x1705c30,0x16d54d8,0x767);
        uVar13 = *(ushort *)(puVar17 + 4);
      }
      puVar25 = auStack_308;
      if (uVar13 != 0) {
        do {
          uVar29 = (int)uVar23 + 1;
          auStack_2b0[uVar23 * 3] = puVar17[uVar23 * 4 + 5];
          auStack_2b0[uVar23 * 3 + 1] = puVar17[uVar23 * 4 + 7];
          auStack_2a8[uVar23 * 6] = *(undefined2 *)(puVar17 + uVar23 * 4 + 8);
          auStack_2a8[uVar23 * 6 + 1] = *(undefined2 *)((longlong)puVar17 + uVar23 * 0x10 + 0x22);
          puVar25 = auStack_308;
          uVar23 = (ulonglong)uVar29;
        } while (uVar29 < *(ushort *)(puVar17 + 4));
      }
    }
  }
  uVar15 = *puVar24;
  uVar3 = *(undefined4 *)(puVar24 + 1);
  uVar2 = *(undefined2 *)((longlong)puVar24 + 0xc);
  uStack_1c0 = 0;
  uStack_19a = 0;
  uStack_198 = 0;
  puStack_1b8 = puVar24;
  *(undefined *)puVar24 = 8;
  uStack_1c8 = uVar15;
  *(undefined *)((longlong)puStack_1b8 + 1) = 0;
  *(short *)((longlong)puStack_1b8 + 2) = (short)uVar16;
  uStack_1b0 = CONCAT44(uVar16,uVar16);
  uStack_1a4 = 0;
  *(undefined8 *)((longlong)puVar25 + -8) = 0x100e76;
  uStack_1bc = uVar16;
  uStack_1a8 = uVar16;
  bVar11 = func_0x(param_1 + 8);
  bVar30 = 0;
  uStack_208 = *(longlong *)(param_1 + 0x58);
  uStack_200 = *(undefined4 *)(param_1 + 0x60);
  uStack_1fc = *(undefined4 *)(param_1 + 100);
  lVar20 = *(longlong *)(param_1 + 0xa8);
  if (*(int *)(*(longlong *)(param_1 + 0x10) + 0x38) == 3) {
    bVar30 = 2;
  }
  bVar11 = (bVar30 | bVar11 & 1) * '\x02';
  bStack_120 = bVar11 | (byte)uStack_1f0 & 1 | bStack_120 & 0xe0;
  if (param_5 == 1) {
    puStack_150 = puStack_158;
    *puStack_158 = 0x4000000;
    puStack_148 = puStack_158 + 1;
    uStack_160 = 0;
    if ((*(byte *)(param_1 + 0x68) & 2) == 0) {
      if ((*(byte *)(param_1 + 0x94) & 1) != 0) {
        lVar21 = param_1 + 0x98;
        goto LAB_;
      }
    }
    else {
      lVar21 = param_1 + 0x44;
LAB_:
      *(undefined8 *)((longlong)puVar25 + -8) = 0x100f24;
      func_0x(param_1 + 8,lVar21,&uStack_188);
    }
    if ((bVar11 & 4) != 0) {
      *(undefined8 *)((longlong)puVar25 + 0x20) = 0x1705c08;
      *(undefined8 *)((longlong)puVar25 + -8) = 0x100f55;
      (*_DAT_)(1,0x1705bf8,0x16d54d8,0x87d);
    }
    pplVar8 = pplStack_1d0;
    lVar21 = **pplStack_1d0;
    *(undefined8 *)((longlong)puVar25 + -8) = 0x100f6f;
    func_0x(param_1 + 8,lVar21,iStack_220);
    uStack_118 = (undefined4)uStack_208;
    uStack_114 = uStack_208._4_4_;
    uStack_110 = uStack_200;
    uStack_10c = uStack_1fc;
    uStack_108 = CONCAT71(uStack_11f,bStack_120);
    if ((*(longlong *)(lVar20 + 8) == 0) ||
       (lVar21 = *(longlong *)(*(longlong *)(lVar20 + 8) + 8), *(char *)(lVar21 + 0x3f) != '\0')) {
      if (*(int *)(lVar20 + 0x40) == 2) {
        uStack_1e6 = 0;
        uStack_1ec = **(undefined4 **)(lVar20 + 0x30);
        puVar17 = &uStack_1ec;
        uStack_1e8 = *(undefined2 *)(*(undefined4 **)(lVar20 + 0x30) + 1);
      }
      else {
        uStack_1de = 0;
        uStack_1e4 = **(undefined4 **)(lVar20 + 0x28);
        puVar17 = &uStack_1e4;
        uStack_1e0 = *(undefined2 *)(*(undefined4 **)(lVar20 + 0x28) + 1);
      }
      uStack_21c = *puVar17;
      uStack_218 = *(undefined2 *)(puVar17 + 1);
    }
    else {
      uStack_21c = *(undefined4 *)(lVar21 + 8);
      uStack_218 = *(undefined2 *)(lVar21 + 0xc);
    }
    lVar20 = *(longlong *)(param_1 + 0x10);
    uVar15 = *(undefined8 *)(param_1 + 8);
    *(undefined4 **)((longlong)puVar25 + 0x38) = &uStack_1c0;
    *(undefined4 **)((longlong)puVar25 + 0x30) = &uStack_118;
    *(int *)((longlong)puVar25 + 0x28) = iStack_220;
    uStack_216 = 0;
    uVar5 = *(undefined8 *)(lVar20 + 0x58);
    *(undefined4 **)((longlong)puVar25 + 0x20) = &uStack_188;
    *(undefined8 *)((longlong)puVar25 + -8) = 0x10103d;
    iVar14 = func_0x(pplVar8,uVar5,&uStack_21c,uVar15);
    if (iVar14 != 0) {
      *(undefined8 *)((longlong)puVar25 + 0x20) = 0;
      *(undefined8 *)((longlong)puVar25 + -8) = 0x101065;
      (*_DAT_)(1,0x1705598,0x16d54d8,0x88a);
    }
    *(uint *)(param_1 + 0x68) = *(uint *)(param_1 + 0x68) & 0xfffffffd;
    *(uint *)(param_1 + 0x94) = *(uint *)(param_1 + 0x94) & 0xfffffffe;
  }
  else {
    *(undefined8 *)((longlong)puVar25 + -8) = 0x101088;
    func_0x(param_1 + 8,param_6,&uStack_188);
    uStack_f8 = (undefined4)uStack_208;
    uStack_f4 = uStack_208._4_4_;
    uStack_f0 = uStack_200;
    uStack_ec = uStack_1fc;
    alStack_138[0] = (ulonglong)*(uint6 *)(*(longlong *)(lVar20 + 0x10) + 0x14) << 0x10;
    uStack_e8 = CONCAT71(uStack_11f,bStack_120);
    if ((*(longlong *)(lVar20 + 8) == 0) ||
       (lVar21 = *(longlong *)(*(longlong *)(lVar20 + 8) + 8), *(char *)(lVar21 + 0x3f) != '\0')) {
      if (*(int *)(lVar20 + 0x40) == 2) {
        uStack_1dc = **(undefined4 **)(lVar20 + 0x30);
        puVar18 = (ulonglong *)&uStack_1dc;
        uStack_1d8 = *(undefined2 *)(*(undefined4 **)(lVar20 + 0x30) + 1);
        uStack_1d6 = 0;
      }
      else {
        puVar18 = &uStack_1f8;
        uStack_1f8 = (ulonglong)**(uint6 **)(lVar20 + 0x28);
      }
      uStack_214 = *(undefined4 *)puVar18;
      uStack_210 = *(undefined2 *)((longlong)puVar18 + 4);
    }
    else {
      uStack_214 = *(undefined4 *)(lVar21 + 8);
      uStack_210 = *(undefined2 *)(lVar21 + 0xc);
    }
    uVar15 = *(undefined8 *)(param_1 + 8);
    uStack_20e = 0;
    *(undefined4 **)((longlong)puVar25 + 0x38) = &uStack_1c0;
    *(undefined4 **)((longlong)puVar25 + 0x30) = &uStack_f8;
    *(int *)((longlong)puVar25 + 0x28) = iStack_220;
    *(undefined4 **)((longlong)puVar25 + 0x20) = &uStack_188;
    *(undefined8 *)((longlong)puVar25 + -8) = 0x10117c;
    func_0x(pplStack_1d0,alStack_138,&uStack_214,uVar15);
  }
  *puVar24 = uStack_1c8;
  *(undefined4 *)(puVar24 + 1) = uVar3;
  *(undefined2 *)((longlong)puVar24 + 0xc) = uVar2;
  if (cStack_13e != '\0') {
    *(undefined *)(*(longlong *)(param_1 + 0x10) + 0x188) = 0;
  }
LAB_:
  *(undefined8 *)((longlong)puVar25 + -8) = 0x1011b4;
  func_0x(uStack_58 ^ (ulonglong)&sStack_258);
  return;
}

