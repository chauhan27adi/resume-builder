
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,int param_3)

{
  ushort *puVar1;
  undefined2 uVar2;
  undefined2 uVar3;
  longlong lVar4;
  longlong lVar5;
  bool bVar6;
  char cVar7;
  byte bVar8;
  short sVar9;
  ushort uVar10;
  int iVar11;
  undefined8 uVar12;
  ulonglong *puVar13;
  ushort uVar14;
  undefined4 uVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  ushort uVar18;
  uint uVar19;
  ulonglong uVar20;
  ushort *puVar21;
  longlong lVar22;
  longlong lVar23;
  uint uVar24;
  longlong lVar25;
  uint uVar26;
  short *psVar27;
  ulonglong uVar28;
  byte *pbVar29;
  ulonglong uVar30;
  ushort *puVar31;
  uint uVar32;
  ulonglong uVar33;
  int iVar34;
  longlong unaff_GS_OFFSET;
  undefined8 auStack_200 [5];
  undefined8 uStack_1d8;
  longlong alStack_1d0 [2];
  int aiStack_1c0 [2];
  short *apsStack_1b8 [2];
  uint uStack_1a8;
  uint uStack_1a4;
  uint uStack_1a0;
  ushort *puStack_198;
  int iStack_190;
  uint uStack_18c;
  uint uStack_188;
  longlong lStack_180;
  ushort *puStack_178;
  byte bStack_170;
  longlong lStack_168;
  int iStack_160;
  longlong lStack_158;
  longlong lStack_150;
  uint uStack_148;
  undefined2 uStack_144;
  undefined2 uStack_142;
  uint uStack_140;
  undefined2 uStack_13c;
  undefined2 uStack_13a;
  ushort uStack_138;
  ushort uStack_134;
  ushort uStack_130;
  ushort uStack_12c;
  ushort uStack_128;
  uint uStack_124;
  uint uStack_120;
  int iStack_11c;
  longlong lStack_118;
  longlong lStack_110;
  ushort *puStack_108;
  longlong lStack_100;
  longlong lStack_f8;
  longlong lStack_f0;
  uint uStack_e8;
  uint uStack_e4;
  uint uStack_e0;
  uint uStack_d8;
  uint uStack_d4;
  uint uStack_d0;
  uint uStack_cc;
  undefined auStack_c8 [8];
  longlong lStack_c0;
  longlong lStack_b8;
  longlong lStack_a8;
  undefined8 uStack_a0;
  ulonglong uStack_98;
  undefined auStack_68 [40];
  ulonglong uStack_40;
  
  uStack_a0 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)&uStack_1a8;
  uVar33 = 0;
  uVar17 = 1;
  uStack_1a8 = 0;
  uVar10 = *(ushort *)(param_1 + 0x16);
  uVar28 = (ulonglong)uVar10;
  if (uVar10 == 0) {
    uVar28 = 1;
  }
  uVar16 = uVar28 * 8 + 0xf;
  uVar30 = 0xffffffffffffff0;
  if (uVar16 <= uVar28 * 8) {
    uVar16 = 0xffffffffffffff0;
  }
  uVar16 = uVar16 & 0xfffffffffffffff0;
  auStack_200[0] = 0x1000c7;
  uVar20 = uVar33;
  lStack_168 = param_1;
  lStack_150 = param_1;
  lStack_110 = param_1;
  lStack_100 = param_1;
  lStack_f8 = param_1;
  lStack_c0 = param_1;
  lStack_b8 = param_1;
  func_0x();
  lVar4 = -uVar16;
  puStack_198 = (ushort *)((longlong)&uStack_1a8 + lVar4);
  uVar16 = uVar28 * 0x34 + 0xf;
  if (uVar16 <= uVar28 * 0x34) {
    uVar16 = uVar30;
  }
  uVar16 = uVar16 & 0xfffffffffffffff0;
  *(undefined8 *)((longlong)auStack_200 + lVar4) = 0x1000ef;
  func_0x();
  puVar1 = puStack_198;
  lVar5 = -uVar16;
  lStack_118 = (longlong)&uStack_1a8 + lVar5 + lVar4;
  iStack_160 = (param_3 != 2) + 2;
  iStack_11c = iStack_160;
  if (uVar10 != 0) {
    puVar21 = (ushort *)(param_1 + 0x1ffe);
    puVar31 = puStack_198;
    uVar28 = uVar33;
    do {
      uVar10 = *puVar21;
      uVar17 = uVar17 & 0xffffffff;
      if ((uint)uVar10 < (uint)uVar20) {
        uVar17 = uVar33;
      }
      *puVar31 = uVar10;
      *(int *)(puVar31 + 2) = (int)uVar28;
      uVar32 = (int)uVar28 + 1;
      uVar28 = (ulonglong)uVar32;
      puVar21 = puVar21 + -1;
      puVar31 = puVar31 + 4;
      uVar18 = *(ushort *)(param_1 + 0x16);
      uVar16 = (ulonglong)(uint)uVar10;
      if ((uint)uVar10 < (uint)uVar20) {
        uVar16 = uVar20 & 0xffffffff;
      }
      uVar20 = uVar16;
    } while ((int)uVar32 < (int)(uint)uVar18);
    if ((int)uVar17 == 0) {
      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10017d;
      (*_DAT_)(puVar1,(uint)uVar18,8,0xfffffffffec05a40);
    }
  }
  lVar22 = param_1 + 0x60;
  lStack_180 = lVar22;
  lStack_158 = lVar22;
  lStack_f0 = lVar22;
  lStack_a8 = lVar22;
  if (*(char *)(param_1 + 2) < '\0') {
    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10019d;
    sVar9 = func_0x();
    uVar32 = (uint)(ushort)(sVar9 + 0x60);
    uStack_1a0 = 0x1fa0;
    if (*(char *)(param_1 + 2) < '\0') {
      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1001c2;
      uVar10 = func_0x(lVar22);
      uStack_1a0 = 0x1fa0 - uVar10;
    }
  }
  else {
    uVar32 = 0x60;
    uStack_1a0 = 0x1fa0;
  }
  uStack_188 = 0;
  lVar22 = param_1;
  uVar17 = uVar33;
  uVar28 = uVar33;
  uVar16 = uVar33;
  while (puVar1 = puStack_198, uVar26 = uStack_1a0, iStack_190 = (int)uVar17,
        iStack_190 < (int)(uint)*(ushort *)(lVar22 + 0x16)) {
    puVar21 = (ushort *)(longlong)iStack_190;
    uVar10 = puStack_198[(longlong)puVar21 * 4];
    puStack_178 = puVar21;
    puStack_108 = puVar21;
    if (uVar10 == 0) {
      uStack_188 = (int)uVar28 + 1;
      uVar28 = (ulonglong)uStack_188;
      uStack_1a0 = uStack_1a0 - 2;
      uVar17 = (ulonglong)(iStack_190 + 1);
    }
    else {
      if (uVar10 < uVar32) {
        uStack_1a8 = 1;
        uVar16 = 1;
        if ((param_3 != 0) && (uVar16 = 1, param_3 == 2)) {
          *(uint *)((longlong)alStack_1d0 + lVar5 + lVar4) = (uint)uVar10;
          *(undefined4 *)((longlong)&uStack_1d8 + lVar5 + lVar4) =
               *(undefined4 *)(puVar1 + (longlong)puVar21 * 4 + 2);
          *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100269;
          func_0x(0x22ee,param_1,0x1366648,1);
          uVar10 = puStack_198[(longlong)puStack_178 * 4];
          uVar16 = (ulonglong)uStack_1a8;
        }
      }
      puVar1 = puStack_198;
      if (((1 << ((byte)*(undefined2 *)(param_1 + 4) & 2)) - 1U & (uint)uVar10) != 0) {
        uStack_1a8 = (int)uVar16 + 1;
        uVar16 = (ulonglong)uStack_1a8;
        if (param_3 == 2) {
          *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1002b6;
          func_0x(param_1,0x13665f0,0x66);
        }
      }
      psVar27 = (short *)(lStack_118 + (longlong)puStack_178 * 0x34);
      if (param_2 == 1) {
        uVar10 = puStack_198[(longlong)puStack_178 * 4];
        lVar22 = (ulonglong)uVar10 + lStack_100;
        if (iStack_190 == *(ushort *)(lStack_168 + 0x16) - 1) {
          uVar18 = *(ushort *)(lStack_168 + 0x1e);
        }
        else {
          uVar18 = puStack_198[(longlong)puStack_178 * 4 + 4];
        }
        lVar25 = (ulonglong)uVar18 + lStack_f8;
        if (*(char *)(param_1 + 2) < '\0') {
          *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10031c;
          sVar9 = func_0x(param_1 + 0x60);
          uVar18 = sVar9 + 0x60;
          uVar10 = puStack_198[(longlong)puStack_178 * 4];
        }
        else {
          uVar18 = 0x60;
        }
        puVar21 = puStack_178;
        puVar1 = puStack_198;
        uVar32 = (uint)uVar16;
        if (((uVar10 < uVar18) && (uStack_1a8 = (uint)uVar16 + 1, uVar32 = uStack_1a8, param_3 != 0)
            ) && (param_3 == 2)) {
          *(uint *)((longlong)alStack_1d0 + lVar5 + lVar4) = (uint)uVar10;
          *(undefined4 *)((longlong)&uStack_1d8 + lVar5 + lVar4) =
               *(undefined4 *)(puVar1 + (longlong)puVar21 * 4 + 2);
          *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10037b;
          func_0x(0x22ed,param_1,0x1366580,1);
          uVar10 = puStack_198[(longlong)puStack_178 * 4];
          uVar32 = uStack_1a8;
        }
        puVar21 = puStack_178;
        puVar1 = puStack_198;
        if ((*(ushort *)(lStack_168 + 0x1e) < uVar10) &&
           (uStack_1a8 = uVar32 + 1, uVar32 = uStack_1a8, param_3 == 2)) {
          *(uint *)((longlong)alStack_1d0 + lVar5 + lVar4) = (uint)uVar10;
          *(undefined4 *)((longlong)&uStack_1d8 + lVar5 + lVar4) =
               *(undefined4 *)(puVar1 + (longlong)puVar21 * 4 + 2);
          *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1003d2;
          func_0x(0x22ed,param_1,0x1366730,2);
          uVar32 = uStack_1a8;
        }
        if (uVar32 != 0) goto LAB_;
        *(undefined8 *)((longlong)alStack_1d0 + lVar5 + lVar4) = 0;
        *(undefined8 *)((longlong)&uStack_1d8 + lVar5 + lVar4) = _DAT_;
        *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100404;
        func_0x(auStack_68,0,0,0);
        uStack_13a = 0;
        uVar32 = *(uint *)(param_1 + 0x18);
        uVar2 = *(undefined2 *)(param_1 + 6);
        uStack_142 = 0;
        uVar3 = *(undefined2 *)(param_1 + 0xe);
        uStack_148 = uVar32;
        uStack_144 = uVar2;
        uStack_140 = uVar32;
        uStack_13c = uVar2;
        *(short **)((longlong)apsStack_1b8 + lVar5 + lVar4) = psVar27;
        *(int *)((longlong)aiStack_1c0 + lVar5 + lVar4) = iStack_160;
        *(longlong *)((longlong)alStack_1d0 + lVar5 + lVar4 + 8) = lVar25;
        *(undefined2 *)((longlong)alStack_1d0 + lVar5 + lVar4) = uVar2;
        *(uint *)((longlong)&uStack_1d8 + lVar5 + lVar4) = uVar32;
        uVar15 = *(undefined4 *)(puStack_198 + (longlong)puStack_178 * 4 + 2);
        *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100473;
        uVar32 = func_0x(lVar22,uVar3,param_1 + 0x20,uVar15);
        if (uVar32 == 0) {
          puVar1 = (ushort *)(psVar27 + 1);
          if (*psVar27 == 0) {
            if (*(int *)(psVar27 + 2) == 0) {
              uStack_1a4 = 0;
              *puVar1 = 0;
              uVar32 = *(uint *)(psVar27 + 8);
              *(uint *)(psVar27 + 10) = uVar32;
              pbVar29 = *(byte **)(psVar27 + 4);
              if ((*pbVar29 & 0x10) != 0) {
                uVar32 = uVar32 + 2 + (*(ushort *)(pbVar29 + *(uint *)(psVar27 + 8)) + 7 >> 3);
                *(uint *)(psVar27 + 10) = uVar32;
                pbVar29 = *(byte **)(psVar27 + 4);
              }
              if ((*pbVar29 & 0x20) == 0) {
                *(uint *)(psVar27 + 2) = uVar32;
                psVar27[0xe] = 0;
                *(undefined4 *)(psVar27 + 0xc) = *(undefined4 *)(psVar27 + 10);
                iVar34 = 0;
              }
              else {
                puVar21 = (ushort *)(pbVar29 + uVar32);
                uVar10 = *puVar21;
                psVar27[0xe] = uVar10;
                uVar17 = uVar33;
                if (uVar10 == 0) {
                  uVar17 = 1;
                  uStack_1a4 = 1;
                  *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100518;
                  cVar7 = func_0x(0x1a3ee10);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100521;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10053b;
                      cVar7 = func_0x(0x1a3ee10);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100555;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_1d8 + lVar5 + lVar4) = 0;
                        *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100578;
                        (*_DAT_)(1,0x132e81c,0x144e908,0x80f);
                      }
                    }
                  }
                  uVar12 = *(undefined8 *)(psVar27 + 4);
                  *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100586;
                  func_0x(uVar12,3);
                  uVar10 = psVar27[0xe];
                }
                uVar32 = *(int *)(psVar27 + 10) + 2 + (uint)uVar10 * 2;
                *(uint *)(psVar27 + 0xc) = uVar32;
                if (0x1f9e < uVar32) {
                  uStack_1a4 = (int)uVar17 + 1;
                  uVar17 = (ulonglong)uStack_1a4;
                  *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1005b8;
                  cVar7 = func_0x(0x1a3ee10);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1005c1;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1005db;
                      cVar7 = func_0x(0x1a3ee10);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1005f7;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_1d8 + lVar5 + lVar4) = 0;
                        *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10061a;
                        (*_DAT_)(1,0x132e81c,0x144e908,0x816);
                      }
                    }
                  }
                  uVar12 = *(undefined8 *)(psVar27 + 4);
                  *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100628;
                  func_0x(uVar12,4);
                }
                uStack_138 = puVar21[(ushort)psVar27[0xe]];
                *(uint *)(psVar27 + 2) = uStack_138 & 0x7fff;
                uVar32 = *(uint *)(psVar27 + 0xc);
                if ((uStack_138 & 0x7fff) < uVar32) {
                  uStack_1a4 = (int)uVar17 + 1;
                  uVar17 = (ulonglong)uStack_1a4;
                  *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10065c;
                  cVar7 = func_0x(0x1a3ee10);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100665;
                    lVar22 = func_0x();
                    if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10067f;
                      cVar7 = func_0x(0x1a3ee10);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10069b;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_1d8 + lVar5 + lVar4) = 0;
                        *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1006be;
                        (*_DAT_)(1,0x132e81c,0x144e908,0x81d);
                      }
                    }
                  }
                  uVar12 = *(undefined8 *)(psVar27 + 4);
                  *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1006cc;
                  func_0x(uVar12,4);
                  uVar32 = *(uint *)(psVar27 + 0xc);
                }
                uStack_124 = 0;
                uVar28 = uVar33;
                while( true ) {
                  uVar10 = psVar27[0xe];
                  iVar11 = (int)uVar28;
                  iVar34 = (int)uVar17;
                  if ((int)(uint)uVar10 <= iVar11) break;
                  uStack_134 = puVar21[(longlong)iVar11 + 1];
                  uVar26 = uStack_134 & 0x7fff;
                  if ((uVar26 < uVar32) || (*(uint *)(psVar27 + 2) < uVar26)) {
                    uStack_1a4 = iVar34 + 1;
                    uVar17 = (ulonglong)uStack_1a4;
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10071f;
                    cVar7 = func_0x(0x1a3ee10);
                    if (cVar7 != '\0') {
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100728;
                      lVar22 = func_0x();
                      if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100742;
                        cVar7 = func_0x(0x1a3ee10);
                        if (cVar7 == '\0') {
                          *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10075e;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_1d8 + lVar5 + lVar4) = 0;
                          *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100784;
                          (*_DAT_)(1,0x132e81c,0x144e908,0x82a);
                        }
                      }
                    }
                    uVar12 = *(undefined8 *)(psVar27 + 4);
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100792;
                    func_0x(uVar12,4);
                  }
                  uStack_124 = iVar11 + 1;
                  uVar28 = (ulonglong)uStack_124;
                  uVar32 = uVar26;
                }
                do {
                  if (-1 < (short)puVar21[(ulonglong)(uVar10 - 1) + 1]) break;
                  lVar22 = *(longlong *)(psVar27 + 4);
                  lVar25 = (ulonglong)*(uint *)(psVar27 + 10) + lVar22;
                  if (uVar10 == 1) {
                    uVar32 = *(uint *)(psVar27 + 0xc);
                  }
                  else {
                    uStack_130 = *(ushort *)(lVar25 + 2 + (longlong)(int)(uVar10 - 2) * 2);
                    uVar32 = uStack_130 & 0x7fff;
                  }
                  uStack_12c = *(ushort *)(lVar25 + 2 + (longlong)(int)(uVar10 - 1) * 2);
                  uVar24 = uStack_12c & 0x7fff;
                  uVar26 = *(uint *)(psVar27 + 0xc);
                  uStack_e8 = uVar32;
                  uStack_e4 = uVar24;
                  if (((uVar32 < uVar26) || (uVar24 < uVar32)) || (*(uint *)(psVar27 + 2) < uVar24))
                  {
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100820;
                    func_0x(lVar22,7);
                    uVar26 = *(uint *)(psVar27 + 0xc);
                  }
                  uVar24 = uVar24 - uVar32;
                  uStack_d4 = uVar32;
                  if ((uVar32 < uVar26) || (*(uint *)(psVar27 + 2) < uVar32)) {
                    uStack_1a4 = iVar34 + 1;
                    goto LAB_;
                  }
                  uStack_128 = *(ushort *)((ulonglong)uVar32 + *(longlong *)(psVar27 + 4));
                  if (uStack_128 == 5) {
                    *puVar1 = *puVar1 | 2;
                    psVar27[0xe] = psVar27[0xe] + -1;
                    psVar27[0x15] = (short)uVar32;
                    lVar22 = (ulonglong)(uVar32 & 0xffff) + *(longlong *)(psVar27 + 4);
                    uVar10 = *(ushort *)(lVar22 + 2);
                    if ((uVar10 & 0x4000) == 0) {
                      psVar27[0x16] = psVar27[0x16] & 0xc7ff;
                    }
                    else {
                      psVar27[0x16] = psVar27[0x16] & 0xc7ff;
                      psVar27[0x16] = psVar27[0x16] | uVar10 & 0x3800;
                    }
                    uVar10 = psVar27[0x16];
                    uVar18 = (uVar10 ^ *(ushort *)(lVar22 + 2)) & 0x7ff ^ uVar10;
                    psVar27[0x16] = uVar18;
                    uVar28 = (ulonglong)(ushort)psVar27[0x15];
                    uVar17 = (ulonglong)((uVar10 >> 0xb & 7) * 2) + 4 +
                             ((ulonglong)uVar18 & 0x7ff) * 2 + *(longlong *)(psVar27 + 4) + uVar28;
                    uStack_e0 = uVar24;
                    uStack_98 = uVar17;
                    if (uVar17 < *(longlong *)(psVar27 + 4) + uVar28) {
                      lVar22 = *(longlong *)(psVar27 + 4);
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10090b;
                      func_0x(lVar22 + uVar28,0x19);
                      uVar18 = psVar27[0x16];
                    }
                    uVar10 = psVar27[0x15];
                    uStack_d8 = (((uVar18 & 0x7ff) * 2 - *(int *)(psVar27 + 4)) - (uint)uVar10) +
                                (int)uVar17;
                    if (uVar24 < uStack_d8) {
                      lVar22 = *(longlong *)(psVar27 + 4);
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10093e;
                      func_0x((ulonglong)(uint)uVar10 + lVar22,0x19);
                      uVar18 = psVar27[0x16];
                    }
                    if ((uVar18 & 0x3800) != 0) {
                      uVar10 = psVar27[0x15];
                      lVar22 = *(longlong *)(psVar27 + 4);
                      uStack_120 = 0;
                      uVar17 = uVar33;
                      while( true ) {
                        iVar11 = (int)uVar17;
                        if ((int)((ushort)psVar27[0x16] >> 0xb & 7) <= iVar11) break;
                        if ((psVar27[0x16] & 0x7ffU) <
                            (*(ushort *)(lVar22 + (ulonglong)uVar10 + 4 + (longlong)iVar11 * 2) &
                            0x7ff)) {
                          uVar18 = psVar27[0x15];
                          lVar25 = *(longlong *)(psVar27 + 4);
                          *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1009a7;
                          func_0x((ulonglong)uVar18 + lVar25,0x1a);
                        }
                        uStack_120 = iVar11 + 1;
                        uVar17 = (ulonglong)uStack_120;
                      }
                    }
                    break;
                  }
                  if (uStack_128 < 0x400) break;
                  *puVar1 = *puVar1 | 1;
                  uVar10 = psVar27[0xe] - 1;
                  psVar27[0xe] = uVar10;
                } while (uVar10 != 0);
              }
              if ((**(byte **)(psVar27 + 4) & 0x40) == 0) {
                *(undefined4 *)(psVar27 + 0x13) = 0;
              }
              else {
                *(undefined4 *)(psVar27 + 0x13) = *(undefined4 *)(psVar27 + 2);
                *(int *)(psVar27 + 2) = *(int *)(psVar27 + 2) + 0xe;
                *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100a0b;
                uVar12 = func_0x(puVar1);
                *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100a1a;
                func_0x(uVar12,auStack_c8);
                *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100a26;
                iVar11 = func_0x(auStack_c8);
                *(int *)(psVar27 + 2) = *(int *)(psVar27 + 2) + iVar11;
              }
              if ((*(ulonglong *)(psVar27 + 0xf) != 0) &&
                 (*(ulonglong *)(psVar27 + 0xf) <
                  (ulonglong)*(uint *)(psVar27 + 2) + *(longlong *)(psVar27 + 4))) {
                iVar34 = iVar34 + 1;
                uStack_1a4 = iVar34;
                *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100a5f;
                cVar7 = func_0x(0x1a3ee10);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100a68;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100a82;
                    cVar7 = func_0x(0x1a3ee10);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100a9e;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_1d8 + lVar5 + lVar4) = 0;
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100ac2;
                      (*_DAT_)(1,0x132e81c,0x144e908,0x886);
                    }
                  }
                }
                uVar12 = *(undefined8 *)(psVar27 + 4);
                *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100ad0;
                func_0x(uVar12,0x12);
              }
              uStack_1a4 = iVar34;
              if (0x3f3b < *(int *)(psVar27 + 2) - 1U) {
                uStack_1a4 = iVar34 + 1;
                *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100af3;
                cVar7 = func_0x(0x1a3ee10);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100afc;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100b16;
                    cVar7 = func_0x(0x1a3ee10);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100b32;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_1d8 + lVar5 + lVar4) = 0;
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100b56;
                      (*_DAT_)(1,0x132e81c,0x144e908,0x88b);
                    }
                  }
                }
                uVar12 = *(undefined8 *)(psVar27 + 4);
                *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100b64;
                func_0x(uVar12,5);
                uStack_1a4 = iVar34 + 1;
              }
            }
LAB_:
            uVar26 = *(uint *)(psVar27 + 2);
            uStack_cc = uVar26;
            if ((uVar26 < 9) &&
               ((bStack_170 = **(byte **)(psVar27 + 4) & 0xe, bStack_170 == 0 || (bStack_170 == 0xc)
                ))) {
              uVar26 = 9;
              uStack_cc = uVar26;
            }
          }
          else {
            uVar26 = *(uint *)(psVar27 + 2);
            if (uVar26 == 0) {
              *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100bad;
              func_0x(puVar1);
              uVar26 = *(uint *)(psVar27 + 2);
            }
            uStack_148 = uVar26;
            if ((uVar26 < 9) &&
               ((uStack_d0 = **(byte **)(psVar27 + 4) & 0x1c, (**(byte **)(psVar27 + 4) & 0x1c) == 0
                || (uStack_d0 == 0xc)))) {
              uVar26 = 9;
              uStack_148 = uVar26;
            }
          }
          uVar32 = uStack_1a8;
          uStack_18c = uVar26;
          if (0x1f9e < uVar26) {
            uStack_1a8 = 1;
            uVar32 = 1;
            if (param_3 == 2) {
              *(undefined4 *)((longlong)alStack_1d0 + lVar5 + lVar4) = 0x1f9e;
              *(uint *)((longlong)&uStack_1d8 + lVar5 + lVar4) = uVar26;
              *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100c1e;
              func_0x(0x22ed,param_1,0x13666f8,0x39);
              uVar32 = uStack_1a8;
            }
          }
        }
        uStack_1a8 = uVar32;
        *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10048c;
        func_0x(auStack_68);
        lVar25 = lStack_180;
        lVar23 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        lVar22 = *(longlong *)(lVar23 + 0x100);
        if (lVar22 == 0) {
          *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100cb3;
          (*_DAT_)();
          lVar22 = *(longlong *)(lVar23 + 0x100);
        }
        if (*(int *)(lVar22 + 0x22c) != 0) {
          *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100cc9;
          (*_DAT_)();
        }
        uVar16 = (ulonglong)uStack_1a8;
        if (uStack_1a8 != 0) goto LAB_;
        lStack_158 = lVar25;
      }
      else {
        uVar32 = (uint)*(ushort *)(param_1 + 0xe);
        pbVar29 = (byte *)((ulonglong)
                           *(ushort *)
                            (param_1 +
                            (0xfff - (longlong)*(int *)(puVar1 + (longlong)puStack_178 * 4 + 2)) * 2
                            ) + param_1);
        puVar1 = (ushort *)(psVar27 + 1);
        if ((*pbVar29 & 1) == 0) {
          *psVar27 = 0;
          *(byte **)(psVar27 + 4) = pbVar29;
          *(undefined4 *)(psVar27 + 2) = 0;
          *(undefined4 *)(psVar27 + 0x13) = 0;
          switch(*pbVar29 & 0xe) {
          default:
            uVar32 = (uint)*(ushort *)(pbVar29 + 2);
            if (0x1f9d < *(ushort *)(pbVar29 + 2) - 1) {
              *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100ed9;
              func_0x(pbVar29,6);
            }
            break;
          case 4:
            uVar32 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar32 = 1;
          }
          *(uint *)(psVar27 + 8) = uVar32;
          uVar17 = lStack_150 + 0x2000;
          if (lStack_110 == 0) {
            uVar17 = uVar33;
          }
          *(ulonglong *)(psVar27 + 0xf) = uVar17;
        }
        else {
          *psVar27 = 1;
          *(byte **)(psVar27 + 4) = pbVar29;
          bVar8 = *pbVar29;
          switch(bVar8 & 0x1c) {
          default:
            if ((char)pbVar29[1] < '\0') {
              uVar10 = *(ushort *)(pbVar29 + 1);
              *puVar1 = uVar10;
              sVar9 = 3;
              uVar10 = (uVar10 & 0x7f) << 8 | uVar10 >> 8;
            }
            else {
              sVar9 = 2;
              uVar10 = (ushort)pbVar29[1];
            }
            *puVar1 = uVar10;
            psVar27[0xc] = sVar9;
            uVar10 = *puVar1;
            psVar27[0xe] = (short)(uVar10 + 1 >> 1) + sVar9;
            if (uVar10 < 0x1f) {
              psVar27[0xd] = 0;
              *(undefined4 *)(psVar27 + 2) = 0;
              *(undefined4 *)(psVar27 + 0x18) = 0;
            }
            else {
              iVar34 = uVar10 - 1;
              psVar27[0xd] = ((short)(iVar34 / 0x1e) + (short)(iVar34 >> 0x1f)) -
                             (short)((longlong)iVar34 * 0x88888889 >> 0x3f);
              *(undefined4 *)(psVar27 + 2) = 0;
              *(undefined4 *)(psVar27 + 0x18) = 0;
            }
            break;
          case 4:
            if (((bVar8 & 0x1c) != 4) || (bVar6 = true, (bVar8 & 2) == 0)) {
              bVar6 = false;
            }
            if (!bVar6) {
              uVar15 = 1;
            }
            else {
              *(undefined4 *)(psVar27 + 0x18) = 0;
              uVar15 = 0xf;
            }
            *(undefined8 *)(psVar27 + 0xc) = 0;
            *puVar1 = 0;
            *(undefined8 *)(psVar27 + 0x10) = 0;
            *(undefined8 *)(psVar27 + 8) = 0;
            *(undefined8 *)(psVar27 + 0x14) = 0;
            *(byte **)(psVar27 + 4) = pbVar29;
            *(undefined4 *)(psVar27 + 2) = uVar15;
            *(uint *)(psVar27 + 0x18) = (uint)bVar6;
            break;
          case 8:
            *(undefined8 *)(psVar27 + 0xc) = 0;
            *puVar1 = 0;
            *(undefined8 *)(psVar27 + 0x10) = 0;
            *(undefined8 *)(psVar27 + 8) = 0;
            *(undefined8 *)(psVar27 + 0x14) = 0;
            *(byte **)(psVar27 + 4) = pbVar29;
            *(undefined4 *)(psVar27 + 2) = 9;
            *(undefined4 *)(psVar27 + 0x18) = 0;
          }
          uVar17 = lStack_150 + 0x2000;
          if (lStack_110 == 0) {
            uVar17 = uVar33;
          }
          *(ulonglong *)(psVar27 + 0x14) = uVar17;
          *(undefined8 *)(psVar27 + 8) = 0;
        }
        lStack_158 = lStack_180;
        uVar32 = *(uint *)(psVar27 + 2);
        if (*psVar27 == 0) {
          if (uVar32 == 0) {
            *puVar1 = 0;
            uVar32 = *(uint *)(psVar27 + 8);
            uVar17 = (ulonglong)uVar32;
            *(uint *)(psVar27 + 10) = uVar32;
            pbVar29 = *(byte **)(psVar27 + 4);
            bVar8 = *pbVar29;
            if ((bVar8 & 0x10) != 0) {
              uVar32 = uVar32 + 2 + (*(ushort *)(pbVar29 + uVar17) + 7 >> 3);
              uVar17 = (ulonglong)uVar32;
              *(uint *)(psVar27 + 10) = uVar32;
              bVar8 = *pbVar29;
            }
            if ((bVar8 & 0x20) == 0) {
              *(int *)(psVar27 + 2) = (int)uVar17;
              psVar27[0xe] = 0;
              *(int *)(psVar27 + 0xc) = (int)uVar17;
            }
            else {
              puVar21 = (ushort *)(pbVar29 + uVar17);
              uVar10 = *puVar21;
              psVar27[0xe] = uVar10;
              puStack_108 = puVar21;
              if (uVar10 == 0) {
                *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100fad;
                cVar7 = func_0x(0x1a3ee10);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100fb6;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100fd0;
                    cVar7 = func_0x(0x1a3ee10);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x100fec;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_1d8 + lVar5 + lVar4) = 0;
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101010;
                      (*_DAT_)(1,0x132e81c,0x144e908,0x80f);
                    }
                  }
                }
                uVar12 = *(undefined8 *)(psVar27 + 4);
                *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10101e;
                func_0x(uVar12,3);
                uVar17 = (ulonglong)*(uint *)(psVar27 + 10);
                uVar10 = psVar27[0xe];
              }
              uVar32 = (int)uVar17 + (uVar10 + 1) * 2;
              *(uint *)(psVar27 + 0xc) = uVar32;
              if (0x1f9e < uVar32) {
                *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10104e;
                cVar7 = func_0x(0x1a3ee10);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101057;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101071;
                    cVar7 = func_0x(0x1a3ee10);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10108d;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_1d8 + lVar5 + lVar4) = 0;
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1010b1;
                      (*_DAT_)(1,0x132e81c,0x144e908,0x816);
                    }
                  }
                }
                uVar12 = *(undefined8 *)(psVar27 + 4);
                *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1010bf;
                func_0x(uVar12,4);
                uVar10 = psVar27[0xe];
                uVar32 = *(uint *)(psVar27 + 0xc);
              }
              uVar17 = (ulonglong)uVar10;
              uVar10 = puVar21[uVar17];
              *(uint *)(psVar27 + 2) = uVar10 & 0x7fff;
              if ((uVar10 & 0x7fff) < uVar32) {
                *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1010ef;
                cVar7 = func_0x(0x1a3ee10);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1010f8;
                  lVar22 = func_0x();
                  if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101112;
                    cVar7 = func_0x(0x1a3ee10);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10112e;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_1d8 + lVar5 + lVar4) = 0;
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101152;
                      (*_DAT_)(1,0x132e81c,0x144e908,0x81d);
                    }
                  }
                }
                uVar12 = *(undefined8 *)(psVar27 + 4);
                *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101160;
                func_0x(uVar12,4);
                uVar32 = *(uint *)(psVar27 + 0xc);
                uVar17 = (ulonglong)(ushort)psVar27[0xe];
              }
              uVar28 = uVar33;
              puVar31 = puVar21;
              if ((short)uVar17 != 0) {
                do {
                  puVar21 = puVar21 + 1;
                  uVar26 = *puVar21 & 0x7fff;
                  if ((uVar26 < uVar32) || (*(uint *)(psVar27 + 2) < uVar26)) {
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10119f;
                    cVar7 = func_0x(0x1a3ee10);
                    if (cVar7 != '\0') {
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1011a8;
                      lVar22 = func_0x();
                      if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1011c2;
                        cVar7 = func_0x(0x1a3ee10);
                        if (cVar7 == '\0') {
                          *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1011de;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_1d8 + lVar5 + lVar4) = 0;
                          *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101202;
                          (*_DAT_)(1,0x132e81c,0x144e908,0x82a);
                        }
                      }
                    }
                    uVar12 = *(undefined8 *)(psVar27 + 4);
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101210;
                    func_0x(uVar12,4);
                  }
                  uVar24 = (int)uVar28 + 1;
                  uVar17 = (ulonglong)(ushort)psVar27[0xe];
                  uVar28 = (ulonglong)uVar24;
                  puVar31 = puStack_108;
                  uVar32 = uVar26;
                } while ((int)uVar24 < (int)(uint)(ushort)psVar27[0xe]);
              }
              if ((short)puVar31[(ulonglong)((int)uVar17 - 1) + 1] < 0) {
                lVar22 = *(longlong *)(psVar27 + 4);
                do {
                  uVar26 = *(ushort *)((ulonglong)*(uint *)(psVar27 + 10) + lVar22 + uVar17 * 2) &
                           0x7fff;
                  if ((int)uVar17 == 1) {
                    uVar24 = *(uint *)(psVar27 + 0xc);
                    uVar19 = uVar24;
code_r0x00101284:
                    if ((uVar26 < uVar24) || (uVar32 = *(uint *)(psVar27 + 2), uVar32 < uVar26))
                    goto code_r0x00101291;
                  }
                  else {
                    uVar24 = *(ushort *)
                              ((ulonglong)*(uint *)(psVar27 + 10) + lVar22 + -2 + uVar17 * 2) &
                             0x7fff;
                    uVar19 = *(uint *)(psVar27 + 0xc);
                    if (uVar19 <= uVar24) goto code_r0x00101284;
code_r0x00101291:
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10129e;
                    func_0x(lVar22,7);
                    uVar19 = *(uint *)(psVar27 + 0xc);
                    uVar32 = *(uint *)(psVar27 + 2);
                  }
                  if ((uVar24 < uVar19) || (uVar32 < uVar24)) goto code_r0x00101619;
                  lVar22 = *(longlong *)(psVar27 + 4);
                  if (*(ushort *)(lVar22 + (ulonglong)uVar24) == 5) {
                    *puVar1 = *puVar1 | 2;
                    psVar27[0xe] = psVar27[0xe] + -1;
                    psVar27[0x15] = (short)uVar24;
                    uVar17 = *(ulonglong *)(psVar27 + 4);
                    uVar10 = *(ushort *)((ulonglong)(uVar24 & 0xffff) + 2 + uVar17);
                    uVar18 = psVar27[0x16] & 0xc7ff;
                    if ((uVar10 >> 0xe & 1) != 0) {
                      uVar18 = uVar10 & 0x3800 | uVar18;
                    }
                    psVar27[0x16] = uVar18;
                    uVar10 = (uVar18 ^ *(ushort *)((ulonglong)(uVar24 & 0xffff) + 2 + uVar17)) &
                             0x7ff ^ uVar18;
                    psVar27[0x16] = uVar10;
                    uVar30 = (ulonglong)(ushort)psVar27[0x15];
                    uVar28 = uVar30 + 4 +
                             (ulonglong)((uVar10 & 0x7ff) * 2) + uVar17 + (uVar18 >> 0xb & 7) * 2;
                    if (uVar28 < uVar30 + uVar17) {
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1013b7;
                      func_0x(uVar30 + uVar17,0x19);
                      uVar10 = psVar27[0x16];
                      uVar30 = (ulonglong)(ushort)psVar27[0x15];
                      uVar17 = (ulonglong)*(uint *)(psVar27 + 4);
                    }
                    if (uVar26 - uVar24 <
                        (((uVar10 & 0x7ff) * 2 - (int)uVar30) - (int)uVar17) + (int)uVar28) {
                      lVar22 = *(longlong *)(psVar27 + 4);
                      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1013f0;
                      func_0x(uVar30 + lVar22,0x19);
                      uVar10 = psVar27[0x16];
                    }
                    if (((uVar10 & 0x3800) != 0) &&
                       (puVar21 = (ushort *)
                                  (*(longlong *)(psVar27 + 4) + 4 + (ulonglong)(ushort)psVar27[0x15]
                                  ), uVar17 = uVar33, (uVar10 & 0x3800) != 0)) {
                      do {
                        if ((uVar10 & 0x7ff) < (*puVar21 & 0x7ff)) {
                          uVar10 = psVar27[0x15];
                          lVar22 = *(longlong *)(psVar27 + 4);
                          *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101447;
                          func_0x((ulonglong)uVar10 + lVar22,0x1a);
                          uVar10 = psVar27[0x16];
                        }
                        uVar32 = (int)uVar17 + 1;
                        uVar17 = (ulonglong)uVar32;
                        puVar21 = puVar21 + 1;
                      } while ((int)uVar32 < (int)(uVar10 >> 0xb & 7));
                    }
                    goto code_r0x00101462;
                  }
                  if (*(ushort *)(lVar22 + (ulonglong)uVar24) < 0x400) goto code_r0x00101462;
                  *puVar1 = *puVar1 | 1;
                  uVar10 = psVar27[0xe] - 1;
                  psVar27[0xe] = uVar10;
                  if (uVar10 == 0) goto code_r0x00101462;
                  uVar17 = (ulonglong)uVar10;
                } while ((short)puVar31[(ulonglong)(uVar10 - 1) + 1] < 0);
                pbVar29 = *(byte **)(psVar27 + 4);
                uVar17 = (ulonglong)*(uint *)(psVar27 + 2);
              }
              else {
code_r0x00101462:
                pbVar29 = *(byte **)(psVar27 + 4);
                uVar17 = (ulonglong)*(uint *)(psVar27 + 2);
              }
            }
            if ((*pbVar29 & 0x40) == 0) {
              *(undefined4 *)(psVar27 + 0x13) = 0;
            }
            else {
              *(int *)(psVar27 + 0x13) = (int)uVar17;
              *(int *)(psVar27 + 2) = (int)uVar17 + 0xe;
              *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101495;
              puVar13 = (ulonglong *)func_0x(puVar1);
              uVar10 = (ushort)(*puVar13 >> 0x30);
              if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
                if ((uVar10 >> 0xe & 1) == 0) {
                  uVar10 = uVar10 & 0xdfff;
                }
                else {
                  uVar10 = uVar10 | 0x2000;
                }
              }
              uVar17 = uVar33;
              if (uVar10 == 0xfffc) {
                uVar17 = (*puVar13 >> 0x20 & 0xffff) >> 5;
              }
              *(int *)(psVar27 + 2) = *(int *)(psVar27 + 2) + (int)uVar17;
              uVar17 = (ulonglong)*(uint *)(psVar27 + 2);
            }
            if ((*(ulonglong *)(psVar27 + 0xf) != 0) &&
               (*(ulonglong *)(psVar27 + 0xf) < uVar17 + *(longlong *)(psVar27 + 4))) {
              *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101515;
              cVar7 = func_0x(0x1a3ee10);
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10151e;
                lVar22 = func_0x();
                if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101538;
                  cVar7 = func_0x(0x1a3ee10);
                  if (cVar7 == '\0') {
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101554;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_1d8 + lVar5 + lVar4) = 0;
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101578;
                    (*_DAT_)(1,0x132e81c,0x144e908,0x886);
                  }
                }
              }
              uVar12 = *(undefined8 *)(psVar27 + 4);
              *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101586;
              func_0x(uVar12,0x12);
              uVar17 = (ulonglong)*(uint *)(psVar27 + 2);
            }
            uVar32 = (uint)uVar17;
            if ((uVar32 == 0) || (0x3f3c < uVar32)) {
              *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1015a5;
              cVar7 = func_0x(0x1a3ee10);
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1015ae;
                lVar22 = func_0x();
                if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1015c8;
                  cVar7 = func_0x(0x1a3ee10);
                  if (cVar7 == '\0') {
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1015e4;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_1d8 + lVar5 + lVar4) = 0;
                    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101608;
                    (*_DAT_)(1,0x132e81c,0x144e908,0x88b);
                  }
                }
              }
              uVar12 = *(undefined8 *)(psVar27 + 4);
              *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101616;
              func_0x(uVar12,5);
              uVar32 = *(uint *)(psVar27 + 2);
            }
          }
code_r0x00101619:
          uStack_18c = uVar32;
          if ((uVar32 < 9) &&
             (((**(byte **)(psVar27 + 4) & 0xe) == 0 || ((**(byte **)(psVar27 + 4) & 0xe) == 0xc))))
          {
            uStack_18c = 9;
          }
        }
        else {
          if (uVar32 == 0) {
            *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10164f;
            func_0x(puVar1);
            uVar32 = *(uint *)(psVar27 + 2);
          }
          uStack_18c = uVar32;
          if ((uVar32 < 9) &&
             (((**(byte **)(psVar27 + 4) & 0x1c) == 0 || ((**(byte **)(psVar27 + 4) & 0x1c) == 0xc))
             )) {
            uStack_18c = 9;
          }
        }
      }
      puVar21 = puStack_178;
      uVar26 = uStack_18c;
      puVar1 = puStack_198;
      bVar8 = (byte)*(undefined2 *)(param_1 + 4);
      sVar9 = 1 << (bVar8 & 2);
      uVar32 = (uint)(ushort)(sVar9 + -1 + (short)uStack_18c +
                              puStack_198[(longlong)puStack_178 * 4] & -sVar9);
      if (*(ushort *)(lStack_168 + 0x1e) < uVar32) {
        uStack_1a8 = (int)uVar16 + 1;
        uVar16 = (ulonglong)uStack_1a8;
        if ((param_3 != 0) && (param_3 == 2)) {
          *(uint *)((longlong)alStack_1d0 + lVar5 + lVar4) = (uint)*(ushort *)(lStack_168 + 0x1e);
          *(undefined4 *)((longlong)&uStack_1d8 + lVar5 + lVar4) =
               *(undefined4 *)(puVar1 + (longlong)puVar21 * 4 + 2);
          *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1016e9;
          func_0x(0x22ef,param_1,0x1366688,1);
          bVar8 = (byte)*(undefined2 *)(lStack_150 + 4);
        }
      }
      uVar10 = (1 << (bVar8 & 2)) - 1;
      uStack_1a0 = uStack_1a0 + (-2 - (uVar10 + uVar26 & 0xffff & (uint)(ushort)~uVar10));
      if ((int)uVar16 != 0) goto LAB_;
      uVar28 = (ulonglong)uStack_188;
      uVar17 = (ulonglong)(iStack_190 + 1);
      lVar22 = lStack_168;
    }
  }
  if ((*(ushort *)(lVar22 + 0x1e) < uVar32) && (param_3 == 2)) {
    *(uint *)((longlong)alStack_1d0 + lVar5 + lVar4) = (uint)*(ushort *)(lVar22 + 0x1e);
    *(uint *)((longlong)&uStack_1d8 + lVar5 + lVar4) = uVar32;
    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10176e;
    func_0x(0x22eb,param_1,0x1366688,0x69);
  }
  lVar22 = lStack_168;
  if (((*(char *)(lStack_168 + 1) != '\x0e') &&
      (uVar10 = *(ushort *)(lStack_168 + 0x1c), uVar10 != uVar26)) && (param_3 == 2)) {
    *(uint *)((longlong)alStack_1d0 + lVar5 + lVar4) = uVar26;
    *(uint *)((longlong)&uStack_1d8 + lVar5 + lVar4) = (uint)uVar10;
    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1017aa;
    func_0x(0x22eb,param_1,0x13668b8,0x6a);
  }
  lVar25 = lStack_180;
  if (*(char *)(param_1 + 2) < '\0') {
    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x1017ba;
    sVar9 = func_0x(lVar25);
    uVar10 = sVar9 + 0x60;
  }
  else {
    uVar10 = 0x60;
  }
  lVar25 = lStack_f0;
  uVar14 = 0x60;
  uVar18 = *(ushort *)(lVar22 + 0x16);
  if (((ulonglong)uVar10 + (0xfd0 - (ulonglong)uVar18) * 2 < (ulonglong)*(ushort *)(lVar22 + 0x1e))
     && (param_3 == 2)) {
    if (*(char *)(param_1 + 2) < '\0') {
      *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101808;
      sVar9 = func_0x(lVar25);
      uVar18 = *(ushort *)(lStack_150 + 0x16);
      uVar14 = sVar9 + 0x60;
    }
    uVar10 = *(ushort *)(lVar22 + 0x1c);
    *(uint *)((longlong)alStack_1d0 + lVar5 + lVar4) = (uint)uVar14 + (0xfd0 - (uint)uVar18) * 2;
    *(uint *)((longlong)&uStack_1d8 + lVar5 + lVar4) = (uint)uVar10;
    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10184a;
    func_0x(0x22eb,param_1,0x13667b0,0x6b);
  }
  uVar32 = uStack_188;
  if ((((*(byte *)(param_1 + 4) & 8) == 0) && (uStack_188 != 0)) && (param_3 == 2)) {
    *(undefined4 *)((longlong)alStack_1d0 + lVar5 + lVar4) = 0;
    *(uint *)((longlong)&uStack_1d8 + lVar5 + lVar4) = uVar32;
    *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x10187e;
    func_0x(0x22eb,param_1,0x1366788,0x6c);
  }
LAB_:
  uVar17 = uStack_40 ^ (ulonglong)&uStack_1a8;
  *(undefined8 *)((longlong)auStack_200 + lVar5 + lVar4) = 0x101896;
  func_0x(uVar17);
  return;
}

