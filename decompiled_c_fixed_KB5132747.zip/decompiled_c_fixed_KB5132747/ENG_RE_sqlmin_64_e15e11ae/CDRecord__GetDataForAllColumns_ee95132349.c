
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_(longlong param_1,undefined8 param_2,ushort param_3)

{
  byte bVar1;
  uint uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  byte bVar5;
  code *UNRECOVERED_JUMPTABLE;
  uint uVar6;
  
  uVar3 = (ulonglong)param_3;
  if (*(int *)(param_1 + 2) == 0) {
    func_0x();
  }
  uVar4 = (ulonglong)*(ushort *)(param_1 + 0x18);
  if (param_3 != 0) {
    uVar6 = 1;
    do {
      uVar2 = uVar6 - 1;
      if ((int)(uVar6 - 1) < 0) {
        uVar2 = uVar6;
      }
      bVar1 = *(byte *)((ulonglong)*(ushort *)(param_1 + 0x16) +
                       (longlong)((int)uVar2 >> 1) + *(longlong *)(param_1 + 6));
      bVar5 = bVar1 >> 4;
      if ((uVar6 & 1) != 0) {
        bVar5 = bVar1 & 0xf;
      }
      if (bVar5 < 0xe) {
        UNRECOVERED_JUMPTABLE =
             (code *)((ulonglong)*(uint *)((longlong)(int)(uint)bVar5 * 4 + 0x1001e4) - 0x1dc0b00);
                    /* WARNING: Could not emulate address calculation at 0x001000ae */
                    /* WARNING: Treating indirect jump as call */
        uVar3 = (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
        return uVar3;
      }
      uVar4 = (*_DAT_)(1,0xb5fdc0,0xb661e0,0x17d7,0x759a30);
      uVar6 = (uint)(ushort)((short)uVar6 + 1);
      uVar3 = uVar3 - 1;
    } while (uVar3 != 0);
  }
  return uVar4;
}

