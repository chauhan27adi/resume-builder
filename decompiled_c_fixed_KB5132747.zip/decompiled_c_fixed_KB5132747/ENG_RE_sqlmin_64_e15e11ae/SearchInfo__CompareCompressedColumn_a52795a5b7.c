
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,longlong param_2,short *param_3,int param_4,double *param_5,
                 undefined4 param_6)

{
  ushort *puVar1;
  float fVar2;
  float fVar3;
  longlong *plVar4;
  double *pdVar5;
  char cVar6;
  byte bVar7;
  ushort uVar8;
  ushort uVar9;
  uint uVar10;
  uint uVar11;
  undefined8 uVar12;
  uint *puVar13;
  byte *pbVar14;
  byte *pbVar15;
  longlong lVar16;
  char *pcVar17;
  code *UNRECOVERED_JUMPTABLE;
  ulonglong uVar18;
  uint uVar19;
  longlong lVar20;
  undefined *puVar21;
  undefined *puVar22;
  undefined *puVar23;
  ulonglong uVar24;
  short sVar25;
  uint uVar26;
  byte bVar27;
  ulonglong uVar28;
  double *pdVar29;
  int *piVar30;
  int iVar31;
  double *pdVar32;
  ushort *puVar33;
  ushort *puVar34;
  int iVar35;
  bool bVar36;
  undefined auStack_1b8 [32];
  undefined8 uStack_198;
  undefined8 uStack_190;
  undefined8 uStack_188;
  undefined8 uStack_180;
  uint uStack_178;
  uint auStack_168 [2];
  undefined8 uStack_160;
  undefined8 uStack_138;
  undefined4 uStack_130;
  longlong lStack_128;
  double **ppdStack_120;
  undefined auStack_118 [8];
  longlong lStack_110;
  ulonglong uStack_58;
  
  puVar22 = auStack_1b8;
  puVar23 = auStack_1b8;
  uStack_58 = _DAT_ ^ (ulonglong)auStack_168;
  lVar20 = *(longlong *)(param_2 + 0x10);
  bVar7 = 0;
  iVar31 = 1;
  uStack_160 = (ushort *)CONCAT44(uStack_160._4_4_,param_6);
  ppdStack_120 = (double **)((ulonglong)(*(ushort *)(lVar20 + 0x28) - 1) * 0x10 + **param_1);
  piVar30 = (int *)((longlong)param_4 * 0x10 + lVar20);
  uStack_138 = piVar30;
  lStack_128 = lVar20;
  lStack_110 = param_2;
  if (param_4 == 0) {
    bVar7 = *(byte *)(lVar20 + 0x20) >> 1;
LAB_:
    bVar7 = bVar7 & 1;
  }
  else {
    if (param_4 == 1) {
      bVar7 = *(byte *)(lVar20 + 0x20);
      goto LAB_;
    }
    uStack_198 = (double *)0x15ed6f0;
    (*_DAT_)(1,0x19f3a80,0x1a1fb18,0x22c);
  }
  uVar8 = 0;
  puVar1 = (ushort *)(param_3 + 1);
  uStack_130 = 0xffff;
  if (*param_3 == 0) {
    if ((bVar7 != 0) || ((*(byte *)((longlong)piVar30 + 6) & 0x10) != 0)) {
      pbVar15 = *(byte **)(param_3 + 4);
      iVar35 = iVar31;
      if ((*pbVar15 & 0x10) == 0) {
        if ((1 << (*pbVar15 & 0xe) & 0x1105U) != 0) goto LAB_;
LAB_:
        if (bVar7 != 0) goto LAB_;
      }
      else {
        uVar11 = *(uint *)(param_3 + 8);
        if ((int)uVar11 <= *piVar30) {
LAB_:
          uVar8 = ~(*(ushort *)((longlong)piVar30 + 6) >> 4) & 1;
          iVar35 = 0;
          goto LAB_;
        }
        if ((uint)*(ushort *)(pbVar15 + uVar11) < (uint)*(ushort *)(piVar30 + 1)) goto LAB_;
        if (bVar7 == 0) goto LAB_;
        uVar10 = *(ushort *)(piVar30 + 1) - 1;
        uVar8 = pbVar15[(ulonglong)(uVar10 >> 3) + (ulonglong)uVar11 + 2] >> ((byte)uVar10 & 7) & 1;
LAB_:
        if (uVar8 != 0) {
          auStack_168[0] = 0;
          pdVar32 = (double *)0x0;
          goto LAB_;
        }
      }
      if ((iVar35 == 0) && ((*(byte *)((longlong)piVar30 + 6) & 0x10) != 0)) {
        pdVar32 = (double *)(*(uint **)(piVar30 + 2) + 1);
        auStack_168[0] = **(uint **)(piVar30 + 2);
        goto LAB_;
      }
    }
LAB_:
    iVar35 = *piVar30;
    if (iVar35 < 0) {
      if (*(int *)(param_3 + 2) == 0) {
        pbVar15 = *(byte **)(param_3 + 4);
        uVar11 = *(uint *)(param_3 + 8);
        uVar18 = (ulonglong)uVar11;
        *puVar1 = 0;
        *(uint *)(param_3 + 10) = uVar11;
        bVar7 = *pbVar15;
        if ((bVar7 & 0x10) != 0) {
          uVar11 = uVar11 + 2 + (*(ushort *)(pbVar15 + uVar18) + 7 >> 3);
          uVar18 = (ulonglong)uVar11;
          *(uint *)(param_3 + 10) = uVar11;
          bVar7 = *pbVar15;
        }
        if ((bVar7 & 0x20) == 0) {
          *(int *)(param_3 + 2) = (int)uVar18;
          param_3[0xe] = 0;
          *(int *)(param_3 + 0xc) = (int)uVar18;
        }
        else {
          puVar33 = (ushort *)(pbVar15 + uVar18);
          uVar8 = *puVar33;
          param_3[0xe] = uVar8;
          uStack_160 = puVar33;
          if (uVar8 == 0) {
            cVar6 = func_0x(0x1f82780);
            if (((cVar6 != '\0') && (lVar20 = func_0x(), lVar20 != 0)) &&
               (*(char *)(lVar20 + 0x499) != '\0')) {
              cVar6 = func_0x(0x1f82780);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_198 = (double *)0x0;
                (*_DAT_)(1,0x187218c,0x1992278,0x80f);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 4),3);
            uVar8 = param_3[0xe];
            uVar18 = (ulonglong)*(uint *)(param_3 + 10);
          }
          uVar11 = (int)uVar18 + (uVar8 + 1) * 2;
          *(uint *)(param_3 + 0xc) = uVar11;
          if (0x1f9e < uVar11) {
            cVar6 = func_0x(0x1f82780);
            if (((cVar6 != '\0') && (lVar20 = func_0x(), lVar20 != 0)) &&
               (*(char *)(lVar20 + 0x499) != '\0')) {
              cVar6 = func_0x(0x1f82780);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_198 = (double *)0x0;
                (*_DAT_)(1,0x187218c,0x1992278,0x816);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 4),4);
            uVar8 = param_3[0xe];
            uVar11 = *(uint *)(param_3 + 0xc);
          }
          uVar18 = (ulonglong)uVar8;
          uVar8 = puVar33[uVar18];
          *(uint *)(param_3 + 2) = uVar8 & 0x7fff;
          if ((uVar8 & 0x7fff) < uVar11) {
            cVar6 = func_0x(0x1f82780);
            if (((cVar6 != '\0') && (lVar20 = func_0x(), lVar20 != 0)) &&
               (*(char *)(lVar20 + 0x499) != '\0')) {
              cVar6 = func_0x(0x1f82780);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_198 = (double *)0x0;
                (*_DAT_)(1,0x187218c,0x1992278,0x81d);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 4),4);
            uVar11 = *(uint *)(param_3 + 0xc);
            uVar18 = (ulonglong)(ushort)param_3[0xe];
          }
          iVar35 = 0;
          puVar34 = puVar33;
          if ((short)uVar18 != 0) {
            do {
              puVar33 = puVar33 + 1;
              uVar10 = *puVar33 & 0x7fff;
              if ((uVar10 < uVar11) || (*(uint *)(param_3 + 2) < uVar10)) {
                cVar6 = func_0x(0x1f82780);
                if ((cVar6 != '\0') &&
                   ((lVar20 = func_0x(), lVar20 != 0 &&
                    (*(char *)(lVar20 + 0x499) != '\0')))) {
                  cVar6 = func_0x(0x1f82780);
                  if (cVar6 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_198 = (double *)0x0;
                    (*_DAT_)(1,0x187218c,0x1992278,0x82a);
                  }
                }
                func_0x(*(undefined8 *)(param_3 + 4),4);
              }
              uVar18 = (ulonglong)(ushort)param_3[0xe];
              iVar35 = iVar35 + 1;
              piVar30 = uStack_138;
              puVar34 = uStack_160;
              uVar11 = uVar10;
            } while (iVar35 < (int)(uint)(ushort)param_3[0xe]);
          }
          if ((short)puVar34[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
            pbVar15 = *(byte **)(param_3 + 4);
            do {
              uVar11 = *(ushort *)(pbVar15 + uVar18 * 2 + (ulonglong)*(uint *)(param_3 + 10)) &
                       0x7fff;
              if ((int)uVar18 == 1) {
                uVar10 = *(uint *)(param_3 + 0xc);
                uVar19 = uVar10;
LAB_:
                if ((uVar11 < uVar10) || (*(uint *)(param_3 + 2) < uVar11)) goto LAB_;
              }
              else {
                uVar19 = *(uint *)(param_3 + 0xc);
                uVar10 = *(ushort *)
                          (pbVar15 + uVar18 * 2 + ((ulonglong)*(uint *)(param_3 + 10) - 2)) & 0x7fff
                ;
                if (uVar19 <= uVar10) goto LAB_;
LAB_:
                func_0x(pbVar15,7);
                uVar19 = *(uint *)(param_3 + 0xc);
              }
              if ((uVar10 < uVar19) || (*(uint *)(param_3 + 2) < uVar10)) goto LAB_;
              pbVar15 = *(byte **)(param_3 + 4);
              if (*(ushort *)(pbVar15 + uVar10) == 5) {
                *puVar1 = *puVar1 | 2;
                param_3[0xe] = param_3[0xe] + -1;
                uVar28 = (ulonglong)(uVar10 & 0xffff);
                param_3[0x15] = (short)uVar10;
                uVar18 = *(ulonglong *)(param_3 + 4);
                uVar8 = param_3[0x16] & 0xc7ffU;
                if ((*(ushort *)(uVar28 + 2 + uVar18) >> 0xe & 1) != 0) {
                  uVar8 = *(ushort *)(uVar28 + 2 + uVar18) & 0x3800 | param_3[0x16] & 0xc7ffU;
                }
                param_3[0x16] = uVar8;
                uVar9 = (uVar8 ^ *(ushort *)(uVar28 + 2 + uVar18)) & 0x7ff ^ uVar8;
                param_3[0x16] = uVar9;
                uVar24 = (ulonglong)((uVar9 & 0x7ff) * 2) + 4 + uVar18 + (uVar8 >> 0xb & 7) * 2 +
                         uVar28;
                if (uVar24 < uVar28 + uVar18) {
                  func_0x(uVar28 + uVar18,0x19);
                  uVar9 = param_3[0x16];
                  uVar28 = (ulonglong)(ushort)param_3[0x15];
                  uVar18 = (ulonglong)*(uint *)(param_3 + 4);
                }
                if (uVar11 - uVar10 <
                    (((uVar9 & 0x7ff) * 2 - (int)uVar28) - (int)uVar18) + (int)uVar24) {
                  func_0x(uVar28 + *(longlong *)(param_3 + 4),0x19);
                  uVar9 = param_3[0x16];
                }
                iVar35 = 0;
                if (((uVar9 & 0x3800) != 0) &&
                   (puVar33 = (ushort *)
                              (*(longlong *)(param_3 + 4) + 4 + (ulonglong)(ushort)param_3[0x15]),
                   (uVar9 & 0x3800) != 0)) {
                  do {
                    if ((uVar9 & 0x7ff) < (*puVar33 & 0x7ff)) {
                      func_0x((ulonglong)(ushort)param_3[0x15] + *(longlong *)(param_3 + 4),
                                      0x1a);
                      uVar9 = param_3[0x16];
                    }
                    iVar35 = iVar35 + 1;
                    puVar33 = puVar33 + 1;
                  } while (iVar35 < (int)(uVar9 >> 0xb & 7));
                }
                goto LAB_;
              }
              if (*(ushort *)(pbVar15 + uVar10) < 0x400) goto LAB_;
              *puVar1 = *puVar1 | 1;
              uVar8 = param_3[0xe] - 1;
              param_3[0xe] = uVar8;
              if (uVar8 == 0) goto LAB_;
              uVar18 = (ulonglong)uVar8;
            } while ((short)puVar34[(ulonglong)(uVar8 - 1) + 1] < 0);
            uVar18 = (ulonglong)*(uint *)(param_3 + 2);
          }
          else {
LAB_:
            pbVar15 = *(byte **)(param_3 + 4);
            uVar18 = (ulonglong)*(uint *)(param_3 + 2);
          }
        }
        if ((*pbVar15 & 0x40) == 0) {
          *(undefined4 *)(param_3 + 0x13) = 0;
        }
        else {
          *(int *)(param_3 + 0x13) = (int)uVar18;
          *(int *)(param_3 + 2) = (int)uVar18 + 0xe;
          uVar12 = func_0x(puVar1);
          func_0x(uVar12,auStack_118);
          iVar35 = func_0x(auStack_118);
          *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + iVar35;
          uVar18 = (ulonglong)*(uint *)(param_3 + 2);
        }
        iVar35 = (int)uVar18;
        if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
           (*(ulonglong *)(param_3 + 0xf) < uVar18 + *(longlong *)(param_3 + 4))) {
          cVar6 = func_0x(0x1f82780);
          if ((cVar6 != '\0') &&
             ((lVar20 = func_0x(), lVar20 != 0 &&
              (*(char *)(lVar20 + 0x499) != '\0')))) {
            cVar6 = func_0x(0x1f82780);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uStack_198 = (double *)0x0;
              (*_DAT_)(1,0x187218c,0x1992278,0x886);
            }
          }
          func_0x(*(undefined8 *)(param_3 + 4),0x12);
          iVar35 = *(int *)(param_3 + 2);
        }
        if (0x3f3b < iVar35 - 1U) {
          cVar6 = func_0x(0x1f82780);
          if (((cVar6 != '\0') && (lVar20 = func_0x(), lVar20 != 0)) &&
             (*(char *)(lVar20 + 0x499) != '\0')) {
            cVar6 = func_0x(0x1f82780);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              uStack_198 = (double *)0x0;
              (*_DAT_)(1,0x187218c,0x1992278,0x88b);
            }
          }
          func_0x(*(undefined8 *)(param_3 + 4),5);
        }
      }
LAB_:
      sVar25 = -*(short *)piVar30;
      if ((*(byte *)((longlong)piVar30 + 6) & 0x10) != 0) {
        bVar7 = **(byte **)(param_3 + 4);
        if ((bVar7 & 0x10) == 0) {
          if ((1 << (bVar7 & 0xe) & 0x1105U) != 0) {
LAB_:
            pdVar32 = (double *)(*(uint **)(piVar30 + 2) + 1);
            auStack_168[0] = **(uint **)(piVar30 + 2);
            goto LAB_;
          }
        }
        else if (((int)*(uint *)(param_3 + 8) <= *piVar30) ||
                (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) <
                 *(ushort *)(piVar30 + 1))) goto LAB_;
      }
      pdVar32 = *(double **)(param_3 + 4);
      lVar20 = (longlong)sVar25;
      if ((uint)(ushort)param_3[0xe] < (uint)(int)sVar25) {
        auStack_168[0] = 0;
      }
      else {
        uVar11 = *(uint *)(param_3 + 10);
        if (sVar25 == 1) {
          uVar10 = *(uint *)(param_3 + 0xc);
          uVar11 = *(ushort *)((longlong)pdVar32 + lVar20 * 2 + (ulonglong)uVar11) & 0x7fff;
LAB_:
          if ((uVar11 < uVar10) || (*(uint *)(param_3 + 2) < uVar11)) goto LAB_;
        }
        else {
          puVar1 = (ushort *)((longlong)pdVar32 + lVar20 * 2 + (ulonglong)uVar11);
          uVar10 = *(ushort *)((longlong)pdVar32 + lVar20 * 2 + ((ulonglong)uVar11 - 2)) & 0x7fff;
          pdVar32 = *(double **)(param_3 + 4);
          uVar11 = *puVar1 & 0x7fff;
          if (*(uint *)(param_3 + 0xc) <= uVar10) goto LAB_;
LAB_:
          func_0x(pdVar32,7);
          pdVar32 = *(double **)(param_3 + 4);
        }
        pdVar32 = (double *)((longlong)pdVar32 + (ulonglong)uVar10);
        auStack_168[0] = uVar11 - uVar10;
      }
    }
    else {
      uVar8 = *(ushort *)((longlong)piVar30 + 6);
      if ((uVar8 & 8) == 0) {
        uVar11 = (uint)*(ushort *)(lVar20 + 0x38);
        if ((uVar8 & 0x10) != 0) {
          bVar7 = **(byte **)(param_3 + 4);
          if ((bVar7 & 0x10) == 0) {
            if ((1 << (bVar7 & 0xe) & 0x1105U) != 0) {
LAB_:
              auStack_168[0] = **(uint **)(piVar30 + 2);
              pdVar32 = (double *)(*(uint **)(piVar30 + 2) + 1);
              if ((uVar11 != 0) && (auStack_168[0] != uVar11)) {
                uStack_198 = (double *)0x0;
                (*_DAT_)(1,0x1a205d0,0x1a1ef38,0x381);
              }
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(param_3 + 8) <= iVar35) ||
                  (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) <
                   *(ushort *)(piVar30 + 1))) goto LAB_;
        }
        pdVar32 = (double *)((longlong)*piVar30 + *(longlong *)(param_3 + 4));
        auStack_168[0] = uVar11;
      }
      else {
        pdVar32 = (double *)0x15f6e20;
        auStack_168[0] = 1;
        if ((*(byte *)((longlong)iVar35 + *(longlong *)(param_3 + 4)) &
            (byte)(1 << ((byte)uVar8 & 7))) == 0) {
          pdVar32 = (double *)0x15f6e21;
        }
      }
    }
  }
  else {
    uStack_198 = (double *)&uStack_138;
    uStack_138 = (int *)((ulonglong)uStack_138 & 0xffffffff00000000);
    pdVar32 = (double *)func_0x(puVar1,piVar30,*(ushort *)(lVar20 + 0x38),auStack_168);
    if ((((*param_3 != 0) && (plVar4 = *(longlong **)(param_3 + 8), plVar4 != (longlong *)0x0)) &&
        (*plVar4 != 0)) &&
       (((*(byte *)((longlong)piVar30 + 6) & 8) == 0 && (((ulonglong)uStack_138 & 1) == 0)))) {
      if ((pdVar32 == (double *)0x0) || (pdVar32 == (double *)0x15f6e20)) {
        pdVar32 = (double *)0x0;
        auStack_168[0] = 0;
      }
      else {
        uStack_180 = (double *)CONCAT44(uStack_180._4_4_,(undefined4)uStack_138);
        uStack_190 = (double *)CONCAT44(uStack_190._4_4_,(undefined4)uStack_160);
        uStack_198 = param_5;
        uStack_188 = auStack_168;
        pdVar32 = (double *)func_0x(plVar4,piVar30,pdVar32,auStack_168[0]);
      }
    }
  }
LAB_:
  lVar20 = lStack_128;
  uVar11 = auStack_168[0];
  if (*(char *)(lStack_110 + 0x24) == '\0') {
    lVar20 = -0xf2ce40;
    if (pdVar32 == (double *)0x0) {
      lVar16 = 0;
    }
    else {
      lVar16 = func_0x();
      puVar22 = auStack_1b8 + -lVar16;
      uVar8 = *(ushort *)(lStack_128 + 0x38);
      lVar16 = (longlong)auStack_168 + -lVar16;
      if (0x1f9e < uVar8) {
        uVar8 = 0x1f9e;
      }
      uVar10 = *(byte *)(lStack_128 + 0x34) - 0x30;
      uStack_160 = (ushort *)CONCAT44(uStack_160._4_4_,(uint)uVar8);
      uVar11 = (uint)uVar8;
      if (uVar10 < 0xc0) {
        UNRECOVERED_JUMPTABLE =
             (code *)((ulonglong)
                      *(uint *)(lVar20 + 0x102ec6c +
                               (ulonglong)*(byte *)(lVar20 + 0x102eca0 + (longlong)(int)uVar10) * 4)
                     + lVar20);
                    /* WARNING: Could not recover jumptable at 0x00101043. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
        return;
      }
    }
    auStack_168[0] = uVar11;
    puVar23 = puVar22;
    if (lVar16 == 0) {
      bVar36 = *ppdStack_120 == (double *)0x0;
    }
    else {
      if (*ppdStack_120 == (double *)0x0) goto LAB_;
      uVar11 = *(byte *)(lStack_128 + 0x34) - 0xa5;
      if (uVar11 < 0x4b) {
        UNRECOVERED_JUMPTABLE =
             (code *)((ulonglong)
                      *(uint *)(lVar20 + 0x102eda4 +
                               (ulonglong)*(byte *)(lVar20 + 0x102edb0 + (longlong)(int)uVar11) * 4)
                     + lVar20);
                    /* WARNING: Could not recover jumptable at 0x0010165e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
        return;
      }
      if (auStack_168[0] != 0) {
        if (*(short *)((longlong)ppdStack_120 + 0xc) != 0) {
          uVar11 = *(byte *)(lStack_128 + 0x34) - 0x24;
          uStack_138 = (int *)CONCAT44(uStack_138._4_4_,
                                       (uint)*(ushort *)((longlong)ppdStack_120 + 0xc));
          if (uVar11 < 0xcd) {
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)(lVar20 + 0x102edfc +
                                   (ulonglong)*(byte *)(lVar20 + 0x102ee48 + (longlong)(int)uVar11)
                                   * 4) + lVar20);
                    /* WARNING: Could not recover jumptable at 0x001016ee. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
            return;
          }
        }
        goto LAB_;
      }
      bVar36 = *(short *)((longlong)ppdStack_120 + 0xc) == 0;
    }
    puVar21 = puVar22;
    if (!bVar36) goto LAB_;
    goto LAB_;
  }
  pdVar29 = (double *)0x0;
  cVar6 = *(char *)(lStack_128 + 0x34);
  if (cVar6 != -0x53) {
    if (cVar6 != -0x51) {
      if ((cVar6 == -0x19) || (cVar6 == -0x11)) {
        if (*(longlong *)(lStack_128 + 0x100) == 0) {
          func_0x(lStack_128);
        }
        pdVar29 = *(double **)(lVar20 + 0x100);
        cVar6 = *(char *)(lVar20 + 0x34);
      }
      puVar23 = auStack_1b8;
      if ((pdVar32 == (double *)0x0) || (puVar23 = auStack_1b8, *ppdStack_120 == (double *)0x0))
      goto LAB_;
      uStack_188 = (uint *)CONCAT71(uStack_188._1_7_,
                                    *(char *)((longlong)ppdStack_120 + 0xe) == -0x7a);
      uStack_198 = (double *)
                   CONCAT44(uStack_198._4_4_,(uint)*(ushort *)((longlong)ppdStack_120 + 0xc));
      uStack_190 = pdVar29;
      iVar31 = func_0x(cVar6,pdVar32,uVar11);
      puVar23 = auStack_1b8;
      puVar21 = auStack_1b8;
      if (iVar31 != 0) goto LAB_;
      goto LAB_;
    }
    if (*(longlong *)(lStack_128 + 0x100) == 0) {
      func_0x(lStack_128);
    }
    pdVar29 = *(double **)(lVar20 + 0x100);
  }
  pdVar5 = *ppdStack_120;
  if ((pdVar32 == (double *)0x0) || (puVar23 = auStack_1b8, pdVar5 == (double *)0x0))
  goto LAB_;
  uVar8 = *(ushort *)((longlong)ppdStack_120 + 0xc);
  uVar10 = (uint)uVar8;
  uVar19 = (uint)uVar8;
  uVar26 = (uint)uVar8;
  puVar21 = auStack_1b8;
  switch(*(undefined *)(lVar20 + 0x34)) {
  case 0x24:
    bVar7 = func_0x(pdVar32,uVar11,pdVar5,uVar10);
    goto code_r0x00100f2f;
  case 0x28:
    pcVar17 = (char *)((longlong)pdVar32 + 2);
    iVar31 = 2;
    do {
      if (*pcVar17 != pcVar17[(longlong)pdVar5 - (longlong)pdVar32]) {
        puVar23 = auStack_1b8;
        if (*(byte *)((longlong)pdVar5 + (longlong)iVar31) <=
            *(byte *)((longlong)iVar31 + (longlong)pdVar32)) goto code_r0x00100fb9;
        break;
      }
      iVar31 = iVar31 + -1;
      pcVar17 = pcVar17 + -1;
      puVar23 = auStack_1b8;
    } while (-1 < (longlong)pcVar17 - (longlong)pdVar32);
    goto LAB_;
  case 0x29:
    iVar31 = uVar11 - 1;
    puVar21 = auStack_1b8;
    if (-1 < iVar31) {
      pcVar17 = (char *)((longlong)iVar31 + (longlong)pdVar32);
      do {
        if (*pcVar17 != pcVar17[(longlong)pdVar5 - (longlong)pdVar32]) {
          puVar23 = auStack_1b8;
          if (*(byte *)((longlong)pdVar5 + (longlong)iVar31) <=
              *(byte *)((longlong)iVar31 + (longlong)pdVar32)) goto code_r0x00100fb9;
          break;
        }
        iVar31 = iVar31 + -1;
        pcVar17 = pcVar17 + -1;
        puVar23 = auStack_1b8;
      } while (-1 < (longlong)pcVar17 - (longlong)pdVar32);
      goto LAB_;
    }
    break;
  case 0x2a:
    uVar18 = (ulonglong)(uVar11 - 4);
    puVar13 = (uint *)((longlong)pdVar32 + uVar18);
    uVar10 = *puVar13;
    bVar36 = uVar10 < *(uint *)(uVar18 + (longlong)pdVar5);
    if (uVar10 != *(uint *)(uVar18 + (longlong)pdVar5)) {
code_r0x00100e7c:
      iVar35 = 4;
      if (bVar36) {
        iVar35 = iVar31;
      }
      puVar23 = auStack_1b8;
      if (iVar35 != 4) goto LAB_;
      goto code_r0x00100fb9;
    }
    pbVar15 = (byte *)((uVar18 - 1) + (longlong)pdVar5);
    puVar21 = auStack_1b8;
    if (uVar11 - 4 != 0) {
      pbVar14 = pbVar15;
      do {
        bVar36 = pbVar14[(longlong)puVar13 + (-1 - (longlong)pbVar15)] < *pbVar14;
        if (pbVar14[(longlong)puVar13 + (-1 - (longlong)pbVar15)] != *pbVar14)
        goto code_r0x00100e7c;
        pbVar14 = pbVar14 + -1;
        uVar11 = (int)uVar18 - 1;
        uVar18 = (ulonglong)uVar11;
        puVar23 = auStack_1b8;
      } while (uVar11 != 0);
      goto LAB_;
    }
    break;
  case 0x2b:
    uVar18 = (ulonglong)(uVar11 - 6);
    bVar36 = *(uint *)(uVar18 + (longlong)pdVar32) < *(uint *)((longlong)pdVar5 + uVar18);
    if (*(uint *)(uVar18 + (longlong)pdVar32) != *(uint *)((longlong)pdVar5 + uVar18))
    goto code_r0x00100e7c;
    pbVar15 = (byte *)((uVar18 - 1) + (longlong)pdVar5);
    puVar21 = auStack_1b8;
    if (uVar11 - 6 != 0) {
      lVar20 = uVar18 - (longlong)pbVar15;
      do {
        bVar36 = pbVar15[(longlong)pdVar32 + lVar20 + -1] < *pbVar15;
        if (pbVar15[(longlong)pdVar32 + lVar20 + -1] != *pbVar15) goto code_r0x00100e7c;
        pbVar15 = pbVar15 + -1;
        uVar11 = (int)uVar18 - 1;
        uVar18 = (ulonglong)uVar11;
        puVar23 = auStack_1b8;
      } while (uVar11 != 0);
      goto LAB_;
    }
    break;
  case 0x30:
    if (*(byte *)pdVar5 < *(byte *)pdVar32) goto code_r0x00100fb9;
    puVar23 = auStack_1b8;
    if (*(byte *)pdVar5 <= *(byte *)pdVar32) goto LAB_;
    goto code_r0x00100fc5;
  case 0x34:
    if (*(short *)pdVar32 <= *(short *)pdVar5) {
      puVar23 = auStack_1b8;
      if (*(short *)pdVar5 <= *(short *)pdVar32) goto LAB_;
      goto code_r0x00100fc5;
    }
    goto code_r0x00100fb9;
  case 0x38:
  case 0x7a:
    if ((int)*(float *)pdVar32 <= (int)*(float *)pdVar5) {
      puVar23 = auStack_1b8;
      if ((int)*(float *)pdVar5 <= (int)*(float *)pdVar32) goto LAB_;
      goto code_r0x00100fc5;
    }
    goto code_r0x00100fb9;
  case 0x3a:
    fVar3 = *(float *)pdVar32;
    fVar2 = *(float *)pdVar5;
    if ((uint)fVar2 > (uint)fVar3 || fVar3 == fVar2) {
      puVar23 = auStack_1b8;
      if ((uint)fVar2 <= (uint)fVar3) goto LAB_;
      goto code_r0x00100fc5;
    }
    goto code_r0x00100fb9;
  case 0x3b:
    if (*(float *)pdVar32 <= *(float *)pdVar5) {
      puVar23 = auStack_1b8;
      if (*(float *)pdVar5 <= *(float *)pdVar32) goto LAB_;
      goto code_r0x00100fc5;
    }
    goto code_r0x00100fb9;
  case 0x3c:
  case 0x3d:
  case 0x7f:
    if ((longlong)*pdVar32 <= (longlong)*pdVar5) {
      puVar23 = auStack_1b8;
      if ((longlong)*pdVar5 <= (longlong)*pdVar32) goto LAB_;
      goto code_r0x00100fc5;
    }
    goto code_r0x00100fb9;
  case 0x3e:
    if (*pdVar32 <= *pdVar5) {
      puVar23 = auStack_1b8;
      if (*pdVar5 <= *pdVar32) goto LAB_;
      goto code_r0x00100fc5;
    }
    goto code_r0x00100fb9;
  case 0x62:
    bVar7 = (*pcRam00000000014edf20)(pdVar32,uVar11,pdVar5,uVar10);
code_r0x00100f2f:
    puVar21 = auStack_1b8;
    if ((bVar7 & 2) == 0) {
      puVar23 = auStack_1b8;
      if ((bVar7 & 4) == 0) goto LAB_;
      goto code_r0x00100fb9;
    }
    break;
  case 0x68:
    if (*(byte *)pdVar5 < *(byte *)pdVar32) goto code_r0x00100fb9;
    puVar21 = auStack_1b8;
    if (*(byte *)pdVar32 < *(byte *)pdVar5) goto code_r0x00100fc5;
    break;
  case 0x6a:
  case 0x6c:
    if (uVar11 == 0) {
      puVar21 = auStack_1b8;
      if (uVar8 != 0) {
code_r0x00100c99:
        puVar21 = auStack_1b8;
        if (*(char *)((longlong)ppdStack_120 + 0xe) != -0x7a) {
          if (uVar11 == 0) {
            puVar23 = auStack_1b8;
            if (uVar19 == 0) goto LAB_;
            goto code_r0x00100fc5;
          }
          goto code_r0x00100fb9;
        }
      }
    }
    else {
      if (uVar19 == 0) goto code_r0x00100c99;
      bVar27 = *(byte *)pdVar32 & 1;
      bVar7 = *(byte *)pdVar5 & 1;
      if (bVar27 >= bVar7 && bVar27 != bVar7) goto code_r0x00100fb9;
      if (bVar27 < bVar7) goto code_r0x00100fc5;
      bVar36 = uVar26 <= uVar11;
      if (uVar11 != uVar26) goto joined_r0x00100fa7;
      lVar20 = (longlong)(int)uVar11;
      iVar31 = uVar11 - 4;
      puVar13 = (uint *)((longlong)pdVar32 + lVar20);
      if (bVar27 == 0) {
        puVar21 = auStack_1b8;
        if (0 < iVar31) {
          lVar20 = lVar20 - (longlong)puVar13;
          do {
            uVar11 = *(uint *)((longlong)puVar13 + (longlong)pdVar5 + lVar20 + -4);
            puVar13 = puVar13 + -1;
            iVar31 = iVar31 + -4;
            uVar10 = *puVar13;
            if (uVar10 >= uVar11 && uVar10 != uVar11) goto code_r0x00100fc5;
            if (uVar10 < uVar11) goto code_r0x00100fb9;
            puVar23 = auStack_1b8;
          } while (0 < iVar31);
          goto LAB_;
        }
      }
      else {
        puVar21 = auStack_1b8;
        if (0 < iVar31) {
          lVar20 = lVar20 - (longlong)puVar13;
          do {
            uVar11 = *(uint *)((longlong)puVar13 + (longlong)pdVar5 + lVar20 + -4);
            puVar13 = puVar13 + -1;
            iVar31 = iVar31 + -4;
            uVar10 = *puVar13;
            if (uVar10 >= uVar11 && uVar10 != uVar11) goto code_r0x00100fb9;
            if (uVar10 < uVar11) goto code_r0x00100fc5;
            puVar23 = auStack_1b8;
          } while (0 < iVar31);
          goto LAB_;
        }
      }
    }
    break;
  case 0xa5:
  case 0xad:
  case 0xf0:
    iVar31 = func_0x(pdVar32,uVar11,pdVar5,uVar10);
    goto joined_r0x00100f0a;
  case 0xa7:
  case 0xaf:
  case 0xe7:
  case 0xef:
    uStack_188 = (uint *)CONCAT44(uStack_188._4_4_,uVar11);
    uStack_198 = pdVar29;
    uStack_190 = pdVar32;
    uStack_180 = pdVar5;
    uStack_178 = uVar19;
    iVar31 = (*(code *)pdVar29[0xc])
                       (pdVar29[8],*(float *)((longlong)pdVar29 + 0x54),pdVar29[9],
                        *(float *)(pdVar29 + 10));
joined_r0x00100f0a:
    if (0 < iVar31) goto code_r0x00100fb9;
    puVar23 = auStack_1b8;
    if (-1 < iVar31) goto LAB_;
code_r0x00100fc5:
    puVar21 = auStack_1b8;
    break;
  case 0xbd:
    if ((int)uVar11 < (int)uVar26) {
      uVar10 = uVar11;
    }
    if (uVar10 != 0) {
      lVar20 = (longlong)pdVar5 - (longlong)pdVar32;
      do {
        bVar27 = *(byte *)(lVar20 + (longlong)pdVar32);
        uVar10 = uVar10 - 1;
        bVar7 = *(byte *)pdVar32;
        if (bVar7 >= bVar27 && bVar7 != bVar27) goto code_r0x00100fb9;
        if (bVar7 < bVar27) goto code_r0x00100fc5;
        pdVar32 = (double *)((longlong)pdVar32 + 1);
      } while (uVar10 != 0);
    }
    bVar36 = uVar19 <= uVar11;
    if (!bVar36 || uVar11 == uVar19) {
joined_r0x00100fa7:
      puVar23 = auStack_1b8;
      if (bVar36) goto LAB_;
      goto code_r0x00100fc5;
    }
code_r0x00100fb9:
    puVar23 = auStack_1b8;
    goto LAB_;
  }
LAB_:
  puVar23 = puVar21;
LAB_:
  uVar18 = uStack_58 ^ (ulonglong)auStack_168;
  *(undefined8 *)(puVar23 + -8) = 0x101cfc;
  func_0x(uVar18);
  return;
}

