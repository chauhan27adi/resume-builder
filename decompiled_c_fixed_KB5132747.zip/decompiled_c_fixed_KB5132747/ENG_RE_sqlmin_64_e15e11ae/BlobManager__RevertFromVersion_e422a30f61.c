
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined8 param_2,undefined8 param_3,short *param_4)

{
  code *pcVar1;
  uint *puVar2;
  byte *pbVar3;
  undefined8 uVar4;
  undefined4 *puVar5;
  undefined *puVar6;
  char cVar7;
  char cVar8;
  ushort uVar9;
  short sVar10;
  undefined2 uVar11;
  int iVar12;
  undefined4 uVar13;
  longlong lVar14;
  longlong lVar15;
  undefined8 *puVar16;
  uint *puVar17;
  longlong lVar18;
  undefined8 uVar19;
  ulonglong *puVar20;
  short *psVar21;
  longlong lVar22;
  byte bVar23;
  uint uVar24;
  undefined8 uVar25;
  uint uVar26;
  longlong *plVar27;
  longlong *plVar28;
  byte bVar29;
  uint uVar30;
  byte **ppbVar31;
  int iVar32;
  longlong lVar33;
  longlong lVar34;
  ushort uVar35;
  longlong lVar36;
  byte *pbVar37;
  byte *pbVar38;
  int iVar39;
  ushort *puVar40;
  byte **ppbVar41;
  uint uVar42;
  ushort *puVar43;
  ulonglong uVar44;
  ulonglong uVar45;
  longlong unaff_GS_OFFSET;
  longlong alStackX_8 [2];
  longlong alStackX_18 [2];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar14 = func_0x();
  lVar14 = -lVar14;
  *(undefined8 *)(&stack0x00000850 + lVar14) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002bd8 + lVar14) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar14);
  *(undefined8 *)(&stack0x00000140 + lVar14) = param_3;
  *(undefined8 *)(&stack0x00000110 + lVar14) = param_2;
  *(longlong **)(&stack0x00000028 + lVar14) = param_1;
  lVar36 = *(longlong *)(&stack0x00002c48 + lVar14);
  *(longlong *)(&stack0x00000060 + lVar14) = lVar36;
  *(undefined8 *)(&stack0x00000230 + lVar14) = *(undefined8 *)(&stack0x00002c50 + lVar14);
  *(undefined8 *)(&stack0x00000118 + lVar14) = *(undefined8 *)(&stack0x00002c58 + lVar14);
  *(undefined8 *)(&stack0x00000258 + lVar14) = *(undefined8 *)(&stack0x00002c70 + lVar14);
  *(undefined8 *)(&stack0x00000068 + lVar14) = *(undefined8 *)(&stack0x00002c78 + lVar14);
  *(undefined4 *)(&stack0x00000038 + lVar14) = 0;
  lVar15 = param_1[6];
  *(longlong *)(&stack0x00000148 + lVar14) = lVar15;
  *(undefined8 *)(&stack0x000003f8 + lVar14) = *(undefined8 *)(&stack0x00002c78 + lVar14);
  *(undefined8 *)(&stack0x00000108 + lVar14) = 0;
  *(undefined8 *)(&stack0x0000042c + lVar14) = 0;
  puVar40 = (ushort *)(param_4 + 1);
  if (*param_4 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1000e8;
    func_0x();
  }
  else {
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1000ef;
    func_0x(puVar40,&stack0x00000130 + lVar14);
  }
  *(int *)(&stack0x000001f4 + lVar14) = *(int *)(&stack0x00000130 + lVar14);
  *(short *)(&stack0x000001f8 + lVar14) = *(short *)(&stack0x00000134 + lVar14);
  sVar10 = *param_4;
  if (sVar10 == 0) {
    bVar23 = **(byte **)(param_4 + 4) >> 6;
  }
  else {
    bVar23 = **(byte **)(param_4 + 4) >> 1;
  }
  *(uint *)(&stack0x00000344 + lVar14) = bVar23 & 1;
  if ((bVar23 & 1) != 0) {
    *(undefined4 *)(&stack0x000001dc + lVar14) = 0;
    *(undefined2 *)(&stack0x000001e0 + lVar14) = 0;
    if ((*(short *)(&stack0x00000134 + lVar14) != 0) || (*(int *)(&stack0x00000130 + lVar14) != 0))
    {
      if (sVar10 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100170;
        func_0x();
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100177;
        func_0x(puVar40,&stack0x00000244 + lVar14);
      }
      *(undefined **)(&stack0x00000858 + lVar14) = &stack0x00000244 + lVar14;
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1001a3;
      iVar12 = func_0x(lVar15 + 0x19c8,&stack0x000001f4 + lVar14,&stack0x00000244 + lVar14);
      if (iVar12 != 0) {
        if (*(char *)(lVar15 + 0x2050) != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1001cc;
          func_0x(0x298,10,3);
          uVar19 = *(undefined8 *)(lVar15 + 0x6b0);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1001d8;
          func_0x(uVar19);
        }
        if (*param_4 == 0) {
          *(ushort **)(&stack0x00000860 + lVar14) = puVar40;
          if (*(int *)(param_4 + 2) == 0) {
            iVar12 = 0;
            *(undefined4 *)(&stack0x00000040 + lVar14) = 0;
            *puVar40 = 0;
            uVar26 = *(uint *)(param_4 + 8);
            *(uint *)(param_4 + 10) = uVar26;
            pbVar38 = *(byte **)(param_4 + 4);
            *(byte **)(&stack0x00000868 + lVar14) = pbVar38;
            if ((*pbVar38 & 0x10) != 0) {
              uVar26 = uVar26 + 2 + (*(ushort *)(pbVar38 + *(uint *)(param_4 + 8)) + 7 >> 3);
              *(uint *)(param_4 + 10) = uVar26;
              pbVar38 = *(byte **)(param_4 + 4);
            }
            *(byte **)(&stack0x00000870 + lVar14) = pbVar38;
            if ((*pbVar38 & 0x20) == 0) {
              *(uint *)(param_4 + 2) = uVar26;
              param_4[0xe] = 0;
              *(undefined4 *)(param_4 + 0xc) = *(undefined4 *)(param_4 + 10);
            }
            else {
              puVar43 = (ushort *)(pbVar38 + uVar26);
              *(ushort **)(&stack0x00000878 + lVar14) = puVar43;
              uVar35 = *puVar43;
              param_4[0xe] = uVar35;
              iVar39 = iVar12;
              if (uVar35 == 0) {
                iVar39 = 1;
                *(undefined4 *)(&stack0x00000040 + lVar14) = 1;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100279;
                cVar7 = func_0x(0x1c58840);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100282;
                  lVar15 = func_0x();
                  *(longlong *)(&stack0x00000908 + lVar14) = lVar15;
                  if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1002a4;
                    cVar7 = func_0x(0x1c58840);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1002c1;
                      (*_DAT_)(0x22,0x44,0x15);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1002e5;
                      (*_DAT_)(1,0x154824c,0x1668338);
                    }
                  }
                }
                uVar19 = *(undefined8 *)(param_4 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1002f1;
                func_0x(uVar19,3);
                uVar35 = param_4[0xe];
              }
              uVar26 = *(int *)(param_4 + 10) + 2 + (uint)uVar35 * 2;
              *(uint *)(param_4 + 0xc) = uVar26;
              if (0x1f9e < uVar26) {
                iVar39 = iVar39 + 1;
                *(int *)(&stack0x00000040 + lVar14) = iVar39;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100324;
                cVar7 = func_0x(0x1c58840);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10032d;
                  lVar15 = func_0x();
                  *(longlong *)(&stack0x00000440 + lVar14) = lVar15;
                  if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10034f;
                    cVar7 = func_0x(0x1c58840);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10036b;
                      (*_DAT_)(0x22,0x44,0x15);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100391;
                      (*_DAT_)(1,0x154824c,0x1668338);
                    }
                  }
                }
                uVar19 = *(undefined8 *)(param_4 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1003a3;
                func_0x(uVar19,4);
              }
              uVar35 = puVar43[(ushort)param_4[0xe]];
              *(ushort *)(&stack0x00000188 + lVar14) = uVar35;
              uVar24 = uVar35 & 0x7fff;
              *(uint *)(param_4 + 2) = uVar24;
              uVar26 = *(uint *)(param_4 + 0xc);
              if (uVar24 < uVar26) {
                iVar39 = iVar39 + 1;
                *(int *)(&stack0x00000040 + lVar14) = iVar39;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1003e4;
                cVar7 = func_0x(0x1c58840);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1003ed;
                  lVar15 = func_0x();
                  *(longlong *)(&stack0x00000448 + lVar14) = lVar15;
                  if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10040f;
                    cVar7 = func_0x(0x1c58840);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10042b;
                      (*_DAT_)(0x22,0x44,0x15);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100451;
                      (*_DAT_)(1,0x154824c,0x1668338);
                    }
                  }
                }
                uVar19 = *(undefined8 *)(param_4 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10045d;
                func_0x(uVar19,4);
                uVar26 = *(uint *)(param_4 + 0xc);
              }
              *(uint *)(&stack0x000001ec + lVar14) = uVar26;
              *(undefined4 *)(&stack0x000001f0 + lVar14) = 0;
              iVar32 = iVar12;
              iVar12 = iVar39;
              while (uVar35 = param_4[0xe], iVar32 < (int)(uint)uVar35) {
                uVar35 = puVar43[(longlong)iVar32 + 1];
                *(ushort *)(&stack0x000001d8 + lVar14) = uVar35;
                uVar24 = uVar35 & 0x7fff;
                *(uint *)(&stack0x00000340 + lVar14) = uVar24;
                if ((uVar24 < uVar26) || (*(uint *)(param_4 + 2) < uVar24)) {
                  iVar12 = iVar12 + 1;
                  *(int *)(&stack0x00000040 + lVar14) = iVar12;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1004bd;
                  cVar7 = func_0x(0x1c58840);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1004c6;
                    lVar15 = func_0x();
                    *(longlong *)(&stack0x00000450 + lVar14) = lVar15;
                    if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1004e8;
                      cVar7 = func_0x(0x1c58840);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100504;
                        (*_DAT_)(0x22);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10052a;
                        (*_DAT_)(1,0x154824c);
                      }
                    }
                  }
                  uVar19 = *(undefined8 *)(param_4 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100536;
                  func_0x(uVar19,4);
                }
                *(uint *)(&stack0x000001ec + lVar14) = uVar24;
                iVar32 = iVar32 + 1;
                *(int *)(&stack0x000001f0 + lVar14) = iVar32;
                uVar26 = uVar24;
              }
              do {
                *(ushort **)(&stack0x00000458 + lVar14) = puVar43 + (ulonglong)(uVar35 - 1) + 1;
                if (-1 < (short)puVar43[(ulonglong)(uVar35 - 1) + 1]) break;
                *(uint *)(&stack0x00000338 + lVar14) = (uint)uVar35;
                lVar15 = *(longlong *)(param_4 + 4);
                lVar36 = (ulonglong)*(uint *)(param_4 + 10) + lVar15;
                *(longlong *)(&stack0x00000460 + lVar14) = lVar36;
                if (uVar35 == 1) {
                  uVar26 = *(uint *)(param_4 + 0xc);
                }
                else {
                  uVar9 = *(ushort *)(lVar36 + 2 + (longlong)(int)(uVar35 - 2) * 2);
                  *(ushort *)(&stack0x0000018c + lVar14) = uVar9;
                  uVar26 = uVar9 & 0x7fff;
                }
                *(uint *)(&stack0x00000334 + lVar14) = uVar26;
                uVar35 = *(ushort *)(lVar36 + 2 + (longlong)(int)(uVar35 - 1) * 2);
                *(ushort *)(&stack0x00000190 + lVar14) = uVar35;
                uVar42 = uVar35 & 0x7fff;
                *(uint *)(&stack0x00000330 + lVar14) = uVar42;
                uVar24 = *(uint *)(param_4 + 0xc);
                if (((uVar26 < uVar24) || (uVar42 < uVar26)) || (*(uint *)(param_4 + 2) < uVar42)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100608;
                  func_0x(lVar15,7);
                  uVar24 = *(uint *)(param_4 + 0xc);
                }
                uVar42 = uVar42 - uVar26;
                *(uint *)(&stack0x0000032c + lVar14) = uVar42;
                *(uint *)(&stack0x00000328 + lVar14) = uVar26;
                if ((uVar26 < uVar24) || (*(uint *)(param_4 + 2) < uVar26)) {
                  iVar12 = iVar12 + 1;
                  goto LAB_;
                }
                uVar35 = *(ushort *)((ulonglong)uVar26 + *(longlong *)(param_4 + 4));
                *(ushort *)(&stack0x00000194 + lVar14) = uVar35;
                if (uVar35 == 5) {
                  *puVar40 = *puVar40 | 2;
                  param_4[0xe] = param_4[0xe] + -1;
                  *(uint *)(&stack0x00000320 + lVar14) = uVar42;
                  puVar43 = (ushort *)(param_4 + 0x15);
                  *(ushort **)(&stack0x00000468 + lVar14) = puVar43;
                  *puVar43 = (ushort)uVar26;
                  psVar21 = param_4 + 1;
                  *(short **)(&stack0x00000470 + lVar14) = psVar21;
                  lVar15 = (ulonglong)(uVar26 & 0xffff) + *(longlong *)(param_4 + 4);
                  *(longlong *)(&stack0x00000478 + lVar14) = lVar15;
                  uVar35 = *(ushort *)(lVar15 + 2);
                  if ((uVar35 & 0x4000) == 0) {
                    param_4[0x16] = param_4[0x16] & 0xc7ff;
                  }
                  else {
                    param_4[0x16] = param_4[0x16] & 0xc7ff;
                    param_4[0x16] = param_4[0x16] | uVar35 & 0x3800;
                  }
                  uVar35 = param_4[0x16];
                  uVar9 = (uVar35 ^ *(ushort *)(lVar15 + 2)) & 0x7ff ^ uVar35;
                  param_4[0x16] = uVar9;
                  *(short **)(&stack0x00000480 + lVar14) = psVar21;
                  uVar45 = (ulonglong)*puVar43;
                  uVar44 = (ulonglong)((uVar35 >> 0xb & 7) * 2) + 4 + ((ulonglong)uVar9 & 0x7ff) * 2
                           + *(longlong *)(param_4 + 4) + uVar45;
                  *(ulonglong *)(&stack0x00000488 + lVar14) = uVar44;
                  *(short **)(&stack0x00000490 + lVar14) = psVar21;
                  lVar15 = *(longlong *)(param_4 + 4);
                  if (uVar44 < uVar45 + lVar15) {
                    *(short **)(&stack0x00000498 + lVar14) = psVar21;
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100737;
                    func_0x(uVar45 + lVar15,0x19);
                    uVar9 = param_4[0x16];
                  }
                  *(short **)(&stack0x000004a0 + lVar14) = psVar21;
                  uVar35 = *puVar43;
                  uVar26 = (((uVar9 & 0x7ff) * 2 - *(int *)(param_4 + 4)) - (uint)uVar35) +
                           (int)uVar44;
                  *(uint *)(&stack0x00000308 + lVar14) = uVar26;
                  if (uVar42 < uVar26) {
                    *(short **)(&stack0x000004a8 + lVar14) = psVar21;
                    lVar15 = *(longlong *)(param_4 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100782;
                    func_0x((ulonglong)(uint)uVar35 + lVar15,0x19);
                    uVar9 = param_4[0x16];
                  }
                  if ((uVar9 & 0x3800) != 0) {
                    *(short **)(&stack0x000004b0 + lVar14) = psVar21;
                    lVar15 = (ulonglong)*puVar43 + 4 + *(longlong *)(param_4 + 4);
                    *(longlong *)(&stack0x000004b8 + lVar14) = lVar15;
                    *(undefined4 *)(&stack0x00000238 + lVar14) = 0;
                    iVar39 = 0;
                    while (iVar39 < (int)((ushort)param_4[0x16] >> 0xb & 7)) {
                      if ((param_4[0x16] & 0x7ffU) <
                          (*(ushort *)(lVar15 + (longlong)iVar39 * 2) & 0x7ff)) {
                        *(short **)(&stack0x000004c0 + lVar14) = param_4 + 1;
                        uVar35 = *puVar43;
                        lVar36 = *(longlong *)(param_4 + 4);
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100803;
                        func_0x((ulonglong)uVar35 + lVar36,0x1a);
                      }
                      iVar39 = iVar39 + 1;
                      *(int *)(&stack0x00000238 + lVar14) = iVar39;
                    }
                  }
                  break;
                }
                if (uVar35 < 0x400) break;
                *puVar40 = *puVar40 | 1;
                uVar35 = param_4[0xe] - 1;
                param_4[0xe] = uVar35;
              } while (uVar35 != 0);
            }
            if ((**(byte **)(param_4 + 4) & 0x40) == 0) {
              *(undefined4 *)(param_4 + 0x13) = 0;
            }
            else {
              *(undefined4 *)(param_4 + 0x13) = *(undefined4 *)(param_4 + 2);
              *(int *)(param_4 + 2) = *(int *)(param_4 + 2) + 0xe;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100864;
              puVar16 = (undefined8 *)func_0x(puVar40);
              *(undefined8 **)(&stack0x000004c8 + lVar14) = puVar16;
              *(undefined8 *)(&stack0x00000390 + lVar14) = *puVar16;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100884;
              iVar39 = func_0x(&stack0x00000390 + lVar14);
              *(int *)(param_4 + 2) = *(int *)(param_4 + 2) + iVar39;
            }
            if ((*(ulonglong *)(param_4 + 0xf) != 0) &&
               (*(ulonglong *)(param_4 + 0xf) <
                (ulonglong)*(uint *)(param_4 + 2) + *(longlong *)(param_4 + 4))) {
              iVar12 = iVar12 + 1;
              *(int *)(&stack0x00000040 + lVar14) = iVar12;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1008bd;
              cVar7 = func_0x(0x1c58840);
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1008c6;
                lVar15 = func_0x();
                *(longlong *)(&stack0x000004d0 + lVar14) = lVar15;
                if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1008e8;
                  cVar7 = func_0x(0x1c58840);
                  if (cVar7 == '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100904;
                    (*_DAT_)(0x22,0x44,0x15);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10092a;
                    (*_DAT_)(1,0x154824c,0x1668338);
                  }
                }
              }
              uVar19 = *(undefined8 *)(param_4 + 4);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100938;
              func_0x(uVar19,0x12);
            }
            if (0x3f3b < *(int *)(param_4 + 2) - 1U) {
              iVar12 = iVar12 + 1;
              *(int *)(&stack0x00000040 + lVar14) = iVar12;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10095c;
              cVar7 = func_0x(0x1c58840);
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100965;
                lVar15 = func_0x();
                *(longlong *)(&stack0x000004d8 + lVar14) = lVar15;
                if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100987;
                  cVar7 = func_0x(0x1c58840);
                  if (cVar7 == '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1009a3;
                    (*_DAT_)(0x22,0x44,0x15);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1009c9;
                    (*_DAT_)(1,0x154824c,0x1668338);
                  }
                }
              }
              uVar19 = *(undefined8 *)(param_4 + 4);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1009d7;
              func_0x(uVar19,5);
            }
LAB_:
            *(int *)(&stack0x00000040 + lVar14) = iVar12;
            *(int *)(&stack0x0000023c + lVar14) = iVar12;
          }
          uVar26 = *(uint *)(param_4 + 2);
          if (uVar26 < 9) {
            pbVar38 = *(byte **)(param_4 + 4);
            *(byte **)(&stack0x000004e0 + lVar14) = pbVar38;
            bVar23 = *pbVar38 & 0xe;
            (&stack0x000000a8)[lVar14] = bVar23;
            if ((bVar23 == 0) || (bVar23 == 0xc)) {
              uVar26 = 9;
            }
          }
          *(uint *)(&stack0x00000304 + lVar14) = uVar26;
          *(uint *)(&stack0x00000098 + lVar14) = uVar26;
          lVar36 = *(longlong *)(&stack0x00000060 + lVar14);
          param_1 = *(longlong **)(&stack0x00000028 + lVar14);
        }
        else {
          *(ushort **)(&stack0x000004e8 + lVar14) = puVar40;
          uVar26 = *(uint *)(param_4 + 2);
          if (uVar26 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100a51;
            func_0x(puVar40);
            uVar26 = *(uint *)(param_4 + 2);
          }
          if (uVar26 < 9) {
            bVar23 = **(byte **)(param_4 + 4);
            uVar24 = bVar23 & 0x1c;
            *(uint *)(&stack0x00000300 + lVar14) = uVar24;
            if (((bVar23 & 0x1c) == 0) || (uVar24 == 0xc)) {
              uVar26 = 9;
            }
          }
          *(uint *)(&stack0x000002fc + lVar14) = uVar26;
          *(uint *)(&stack0x00000098 + lVar14) = uVar26;
        }
        *(undefined2 *)(&stack0x00000a68 + lVar14) = 0xffff;
        *(undefined8 *)(&stack0x00000a70 + lVar14) = 0;
        *(undefined4 *)(&stack0x00000a6c + lVar14) = 0;
        *(undefined8 *)(&stack0x00000a86 + lVar14) = 0;
        *(undefined8 *)(&stack0x00000a90 + lVar14) = 0;
        *(undefined8 *)(&stack0x00000a78 + lVar14) = 0;
        *(undefined4 *)(&stack0x00000a9c + lVar14) = 0xffffffff;
        *(undefined4 *)(&stack0x00000100 + lVar14) = 0;
        if (*param_4 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100aee;
          func_0x();
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100af5;
          func_0x(puVar40,&stack0x00000200 + lVar14);
        }
        *(undefined8 *)(&stack0x00000138 + lVar14) = 0;
        *(int *)(&stack0x00000058 + lVar14) =
             (int)*(short *)(*(longlong *)(&stack0x00000230 + lVar14) + 6);
        (&stack0x00000031)[lVar14] = 0;
        *(undefined4 *)(&stack0x00000054 + lVar14) = 0;
        *(undefined **)(&stack0x000004f0 + lVar14) = &stack0x00000070 + lVar14;
        bVar23 = (&stack0x00000070)[lVar14];
        (&stack0x00000070)[lVar14] = bVar23 & 0xfe;
        (&stack0x00000070)[lVar14] = bVar23 & 0xfc;
        (&stack0x00000070)[lVar14] = bVar23 & 0xf8;
        (&stack0x00000070)[lVar14] = bVar23 & 0xf0;
        (&stack0x00000070)[lVar14] = bVar23 & 0xe0;
        (&stack0x00000070)[lVar14] = bVar23 & 0xc0;
        (&stack0x00000071)[lVar14] = 0;
        (&stack0x00000072)[lVar14] = 0;
        *(undefined8 *)(&stack0x00000078 + lVar14) = 0;
        bVar23 = (&stack0x00000080)[lVar14];
        (&stack0x00000080)[lVar14] = bVar23 & 0xfe;
        (&stack0x00000080)[lVar14] = bVar23 & 0xfc;
        (&stack0x00000080)[lVar14] = bVar23 & 0xf8;
        (&stack0x00000080)[lVar14] = bVar23 & 0xf0;
        (&stack0x00000080)[lVar14] = bVar23 & 0xe0;
        (&stack0x00000050)[lVar14] = 0;
        (&stack0x00000030)[lVar14] = 1;
        cVar7 = (&stack0x00002c68)[lVar14];
        if (cVar7 != '\0') {
          param_1 = *(longlong **)(&stack0x00000258 + lVar14);
          if (param_1 == (longlong *)0x0) {
            (&stack0xffffffffffffffe8)[lVar14] = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100bfe;
            func_0x(&stack0x00000108 + lVar14,0x155faf8,0x3c);
            pcVar1 = *(code **)(**(longlong **)(&stack0x00000108 + lVar14) + 0x58);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100c14;
            param_1 = (longlong *)
                      (*pcVar1)(*(longlong **)(&stack0x00000108 + lVar14),
                                *(undefined8 *)(&stack0x00000148 + lVar14));
          }
          *(longlong **)(&stack0x00000028 + lVar14) = param_1;
          *(longlong **)(&stack0x00000138 + lVar14) = param_1;
          pcVar1 = *(code **)(*param_1 + 0x348);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100c32;
          (*pcVar1)(param_1,1);
        }
        *(longlong **)(&stack0x00000048 + lVar14) = param_1;
        pcVar1 = *(code **)(*param_1 + 8);
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100c43;
        cVar8 = (*pcVar1)(param_1);
        (&stack0x00000034)[lVar14] = cVar8;
        if ((cVar8 == '\0') && (cVar7 != '\0')) {
          *(undefined4 **)(&stack0x000004f8 + lVar14) = (undefined4 *)(lVar36 + 0x20);
          uVar13 = *(undefined4 *)(lVar36 + 0x20);
          *(undefined4 *)(&stack0x000001e4 + lVar14) = uVar13;
          uVar11 = *(undefined2 *)(lVar36 + 0x24);
          *(undefined2 *)(&stack0x000001e8 + lVar14) = uVar11;
          *(undefined **)(&stack0x00000500 + lVar14) = &stack0x00000128 + lVar14;
          *(undefined4 *)(&stack0x00000128 + lVar14) = uVar13;
          *(undefined2 *)(&stack0x0000012c + lVar14) = uVar11;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100cae;
          iVar12 = func_0x(*(undefined8 *)(&stack0x00000138 + lVar14),0,
                                   &stack0x00000128 + lVar14);
          *(int *)(&stack0x00000240 + lVar14) = iVar12;
          if (iVar12 < 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100ccd;
            func_0x(*(undefined8 *)(&stack0x00000068 + lVar14));
            *(undefined **)(&stack0x00000508 + lVar14) = &stack0x00000120 + lVar14;
            *(undefined4 *)(&stack0x00000120 + lVar14) = uVar13;
            *(undefined2 *)(&stack0x00000124 + lVar14) = uVar11;
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100d06;
            uVar13 = func_0x(*(undefined8 *)(&stack0x00000138 + lVar14),0xffffffff,
                                     &stack0x00000120 + lVar14);
            *(undefined4 *)(&stack0x00000240 + lVar14) = uVar13;
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100d16;
            func_0x(uVar13,0x23);
            (&stack0xfffffffffffffff8)[lVar14] = 1;
            *(undefined8 *)(&stack0xfffffffffffffff0 + lVar14) = 0;
            *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100d44;
            func_0x(*(undefined8 *)(&stack0x00000068 + lVar14),4,0xffffffff);
            param_1 = *(longlong **)(&stack0x00000048 + lVar14);
            *(longlong **)(&stack0x00000028 + lVar14) = param_1;
          }
          else {
            param_1 = *(longlong **)(&stack0x00000028 + lVar14);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100d67;
        cVar7 = func_0x(&stack0x00000200 + lVar14);
        if (cVar7 == '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100d7c;
          cVar7 = func_0x(&stack0x00000200 + lVar14);
          if (cVar7 != '\0') goto LAB_;
          *(undefined4 *)(&stack0x00000a58 + lVar14) = 0;
          *(undefined4 *)(&stack0x00000a5c + lVar14) = 0;
          *(undefined2 *)(&stack0x00000a60 + lVar14) = 0;
          uVar35 = *(ushort *)(lVar36 + 4);
          *(uint *)(&stack0x000002f8 + lVar14) = uVar35 & 0x2000;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100dc2;
          puVar17 = (uint *)func_0x(lVar36,&stack0x00000910 + lVar14,0);
          *(uint **)(&stack0x00000510 + lVar14) = puVar17;
          plVar27 = *(longlong **)(&stack0x00000028 + lVar14);
          plVar28 = plVar27 + 6;
          lVar15 = *plVar28;
          *(longlong *)(&stack0x000002c0 + lVar14) = lVar15;
          cVar7 = *(char *)(lVar15 + 0x1cde);
          (&stack0x00000032)[lVar14] = cVar7;
          if ((*(char *)(lVar15 + 0x2050) != '\0') &&
             ((*(byte *)(*(longlong *)(&stack0x00000118 + lVar14) + 0x10) & 1) != 0)) {
            *(longlong *)(&stack0x00000518 + lVar14) = lVar15;
            *(undefined8 *)(&stack0x00000520 + lVar14) =
                 *(undefined8 *)(*(longlong *)(lVar15 + 0x728) + 0x5fb0);
            pcVar1 = *(code **)(*plVar27 + 0xf0);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100e33;
            iVar12 = (*pcVar1)(plVar27);
            if (iVar12 == 0) {
              lVar36 = (*(longlong **)(&stack0x00000028 + lVar14))[0x49];
            }
            else {
              pcVar1 = *(code **)(**(longlong **)(&stack0x00000028 + lVar14) + 0x1e8);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100e45;
              lVar36 = (*pcVar1)();
              lVar36 = *(longlong *)(lVar36 + 0x248);
            }
            *(longlong *)(&stack0x00000528 + lVar14) = lVar36;
            *(longlong *)(&stack0x00000530 + lVar14) = lVar36;
            if (*(char *)(lVar36 + 0x16) == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100e81;
              (*_DAT_)(0x27,0x30,0x10);
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100e91;
          func_0x(&stack0x00000a68 + lVar14,param_4);
          *(undefined4 *)(&stack0x00000054 + lVar14) = 1;
          if ((uVar35 & 0x2000) == 0) {
            (&stack0x000000aa)[lVar14] = DAT_ >> 3;
            uVar19 = 0;
            if ((DAT_ >> 3 & 1) == 0) {
              *(undefined4 *)(&stack0x00000164 + lVar14) = 0;
              *(undefined4 *)(&stack0x000002e0 + lVar14) = 0x58;
              lVar15 = *(longlong *)(unaff_GS_OFFSET + 0x58);
              *(longlong *)(&stack0x000005d0 + lVar14) = lVar15;
              plVar27 = (longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)(lVar15 + (ulonglong)*_DAT_ * 8));
              *(longlong **)(&stack0x000005d8 + lVar14) = plVar27;
              *(longlong **)(&stack0x000005e0 + lVar14) = plVar27;
              lVar15 = *plVar27;
              *(longlong *)(&stack0x000005e8 + lVar14) = lVar15;
              *(longlong *)(&stack0x000005f0 + lVar14) = lVar15;
              if (lVar15 == 0) {
LAB_:
                *(undefined8 *)(&stack0x000003a0 + lVar14) = 0;
              }
              else {
                lVar15 = **(longlong **)(lVar15 + 0x38);
                *(longlong *)(&stack0x000005f8 + lVar14) = lVar15;
                if (lVar15 == 0) goto LAB_;
                *(longlong *)(&stack0x000003a0 + lVar14) = lVar15;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10150f;
                iVar12 = (*_DAT_)(lVar15,0xf73);
                *(int *)(&stack0x00000164 + lVar14) = iVar12;
                if (iVar12 != 0) {
                  lVar15 = *(longlong *)(&stack0x00000048 + lVar14);
                  *(longlong *)(&stack0x00000028 + lVar14) = lVar15;
                  goto LAB_;
                }
              }
              *(undefined8 *)(&stack0x00000028 + lVar14) =
                   *(undefined8 *)(&stack0x00000048 + lVar14);
            }
            else {
              lVar15 = *(longlong *)(&stack0x00000028 + lVar14);
LAB_:
              lVar36 = *(longlong *)(lVar15 + 0xd0);
              *(longlong *)(&stack0x00000600 + lVar14) = lVar36;
              if (lVar36 != 0) {
                uVar19 = *(undefined8 *)(lVar36 + 0x40);
              }
              plVar27 = *(longlong **)(lVar15 + 0x290);
              uVar11 = *(undefined2 *)(*plVar28 + 0x6b8);
              *(undefined2 *)(&stack0x000001a8 + lVar14) = uVar11;
              pcVar1 = *(code **)(*plVar27 + 0x138);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101584;
              (*pcVar1)();
              uVar25 = 0x15512f0;
LAB_:
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = uVar19;
              uVar19 = *(undefined8 *)(*(longlong *)(&stack0x00000118 + lVar14) + 0x28);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1015a6;
              func_0x(uVar25,uVar11,uVar19);
            }
LAB_:
            (&stack0x00000033)[lVar14] = 1;
LAB_:
            (&stack0x000000ab)[lVar14] = DAT_ >> 3;
            puVar16 = (undefined8 *)0x0;
            if ((DAT_ >> 3 & 1) == 0) {
              *(undefined4 *)(&stack0x00000168 + lVar14) = 0;
              *(undefined4 *)(&stack0x000002dc + lVar14) = 0x58;
              lVar15 = *(longlong *)(unaff_GS_OFFSET + 0x58);
              *(longlong *)(&stack0x00000608 + lVar14) = lVar15;
              plVar28 = (longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)(lVar15 + (ulonglong)*_DAT_ * 8));
              *(longlong **)(&stack0x00000610 + lVar14) = plVar28;
              *(longlong **)(&stack0x00000618 + lVar14) = plVar28;
              lVar15 = *plVar28;
              *(longlong *)(&stack0x00000620 + lVar14) = lVar15;
              *(longlong *)(&stack0x00000628 + lVar14) = lVar15;
              if (lVar15 == 0) {
LAB_:
                *(undefined8 *)(&stack0x000003a8 + lVar14) = 0;
              }
              else {
                lVar15 = **(longlong **)(lVar15 + 0x38);
                *(longlong *)(&stack0x00000630 + lVar14) = lVar15;
                if (lVar15 == 0) goto LAB_;
                *(longlong *)(&stack0x000003a8 + lVar14) = lVar15;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101654;
                iVar12 = (*_DAT_)(lVar15,0xf73);
                *(int *)(&stack0x00000168 + lVar14) = iVar12;
                if (iVar12 != 0) {
                  *(undefined8 *)(&stack0x00000028 + lVar14) =
                       *(undefined8 *)(&stack0x00000048 + lVar14);
                  goto LAB_;
                }
              }
              param_1 = *(longlong **)(&stack0x00000048 + lVar14);
              *(longlong **)(&stack0x00000028 + lVar14) = param_1;
            }
            else {
LAB_:
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10167a;
              (*_DAT_)(&stack0x00000938 + lVar14);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101681;
              uVar19 = (*_DAT_)();
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101692;
              lVar15 = (*_DAT_)(uVar19,0,0x6c0);
              *(longlong *)(&stack0x00000638 + lVar14) = lVar15;
              if (lVar15 != 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1016a9;
                puVar16 = (undefined8 *)func_0x(lVar15,0);
              }
              *(undefined8 **)(&stack0x00000640 + lVar14) = puVar16;
              *(undefined8 **)(&stack0x000003b0 + lVar14) = puVar16;
              if (puVar16 != (undefined8 *)0x0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1016ee;
                iVar12 = (*_DAT_)(&stack0x00000938 + lVar14,puVar16);
                if (iVar12 == 0) {
                  *(undefined8 **)(&stack0x00000648 + lVar14) = puVar16;
                  pcVar1 = *(code **)*puVar16;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101707;
                  (*pcVar1)(puVar16,1);
                  *(undefined8 *)(&stack0x000003b0 + lVar14) = 0;
                }
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101724;
              func_0x(&stack0x00000a68 + lVar14,&stack0x00000938 + lVar14);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101733;
              (*_DAT_)(&stack0x00000938 + lVar14);
              param_1 = *(longlong **)(&stack0x00000028 + lVar14);
            }
          }
          else {
            lVar36 = *plVar28;
            *(longlong *)(&stack0x00000538 + lVar14) = lVar36;
            if (*(char *)(lVar36 + 0x1ad8) == '\0') {
              if (*param_4 == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100ed1;
                func_0x();
              }
              else {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100ed8;
                func_0x(param_4 + 1,&stack0x00000208 + lVar14);
              }
              *(undefined **)(&stack0x00000540 + lVar14) = &stack0x00000208 + lVar14;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100ef5;
              cVar8 = func_0x(&stack0x00000208 + lVar14);
              if (cVar8 == '\0') goto LAB_;
            }
            else {
LAB_:
              puVar2 = *(uint **)(*(longlong *)(lVar36 + 0x6b0) + 0x2c0);
              *(uint **)(&stack0x00000548 + lVar14) = puVar2;
              if ((*(short *)((longlong)puVar2 + 10) != 2) || (*puVar17 != 0)) {
                *(uint **)(&stack0x00000550 + lVar14) = puVar2;
                if ((*puVar17 <= *puVar2) &&
                   ((*puVar17 != *puVar2 ||
                    ((puVar17[1] <= puVar2[1] &&
                     ((puVar17[1] != puVar2[1] ||
                      (*(ushort *)(puVar17 + 2) <= *(ushort *)(puVar2 + 2))))))))) {
                  uVar19 = 0;
                  *(undefined4 *)(&stack0x000000fc + lVar14) = 0;
                  if (*(char *)(lVar36 + 0x2050) != '\0') {
                    if (*param_4 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100f7d;
                      func_0x();
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100f84;
                      func_0x(param_4 + 1,&stack0x00000210 + lVar14);
                    }
                    *(undefined **)(&stack0x00000558 + lVar14) = &stack0x00000210 + lVar14;
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100fa1;
                    cVar8 = func_0x(&stack0x00000210 + lVar14);
                    if (cVar8 != '\0') goto LAB_;
                  }
                  (&stack0x000000a9)[lVar14] = DAT_ >> 3;
                  if ((DAT_ >> 3 & 1) != 0) {
                    lVar15 = *(longlong *)(&stack0x00000028 + lVar14);
LAB_:
                    lVar36 = *(longlong *)(lVar15 + 0xd0);
                    *(longlong *)(&stack0x00000590 + lVar14) = lVar36;
                    if (lVar36 != 0) {
                      uVar19 = *(undefined8 *)(lVar36 + 0x40);
                    }
                    plVar27 = *(longlong **)(lVar15 + 0x290);
                    uVar11 = *(undefined2 *)(*plVar28 + 0x6b8);
                    *(undefined2 *)(&stack0x00000198 + lVar14) = uVar11;
                    pcVar1 = *(code **)(*plVar27 + 0x138);
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1010bd;
                    (*pcVar1)();
                    uVar25 = 0x1551240;
                    goto LAB_;
                  }
                  *(undefined4 *)(&stack0x00000160 + lVar14) = 0;
                  *(undefined4 *)(&stack0x00000318 + lVar14) = 0x58;
                  lVar15 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  *(longlong *)(&stack0x00000560 + lVar14) = lVar15;
                  plVar27 = (longlong *)
                            ((ulonglong)*_DAT_ +
                            *(longlong *)(lVar15 + (ulonglong)*_DAT_ * 8));
                  *(longlong **)(&stack0x00000568 + lVar14) = plVar27;
                  *(longlong **)(&stack0x00000570 + lVar14) = plVar27;
                  lVar15 = *plVar27;
                  *(longlong *)(&stack0x00000578 + lVar14) = lVar15;
                  *(longlong *)(&stack0x00000580 + lVar14) = lVar15;
                  if (lVar15 == 0) {
LAB_:
                    *(undefined8 *)(&stack0x00000410 + lVar14) = 0;
                  }
                  else {
                    lVar15 = **(longlong **)(lVar15 + 0x38);
                    *(longlong *)(&stack0x00000588 + lVar14) = lVar15;
                    if (lVar15 == 0) goto LAB_;
                    *(longlong *)(&stack0x00000410 + lVar14) = lVar15;
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10104a;
                    iVar12 = (*_DAT_)(lVar15,0xf73);
                    *(int *)(&stack0x00000160 + lVar14) = iVar12;
                    if (iVar12 != 0) {
                      lVar15 = *(longlong *)(&stack0x00000048 + lVar14);
                      *(longlong *)(&stack0x00000028 + lVar14) = lVar15;
                      goto LAB_;
                    }
                  }
                  *(undefined8 *)(&stack0x00000028 + lVar14) =
                       *(undefined8 *)(&stack0x00000048 + lVar14);
                  goto LAB_;
                }
              }
              *(undefined4 *)(&stack0x000000fc + lVar14) = 1;
            }
LAB_:
            (&stack0x00000033)[lVar14] = 0;
            if (*(short *)(&stack0x00000a68 + lVar14) == 0) {
              bVar23 = **(byte **)(&stack0x00000a70 + lVar14) >> 6;
            }
            else {
              bVar23 = **(byte **)(&stack0x00000a70 + lVar14) >> 1;
            }
            *(uint *)(&stack0x000002f0 + lVar14) = bVar23 & 1;
            if ((bVar23 & 1) == 0) goto LAB_;
            *(undefined4 *)(&stack0x000002b8 + lVar14) = 0;
            *(undefined2 *)(&stack0x000002bc + lVar14) = 0;
            if (*(short *)(&stack0x00000a68 + lVar14) == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101135;
              func_0x();
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10113c;
              func_0x(&stack0x00000a6a + lVar14);
            }
            *(undefined **)(&stack0x000002b8 + lVar14) = &stack0x000000ee + lVar14;
            if ((*(short *)(&stack0x000000f2 + lVar14) == 0) &&
               (*(int *)(&stack0x000000ee + lVar14) == 0)) goto LAB_;
            plVar28 = *(longlong **)(&stack0x00000118 + lVar14);
            param_1 = *(longlong **)(&stack0x00000028 + lVar14);
            if ((plVar28 == (longlong *)0x0) || ((*(byte *)(plVar28 + 2) & 0x20) == 0)) {
LAB_:
              sVar10 = *param_4;
              *(uint *)(&stack0x000002e4 + lVar14) = (uint)(sVar10 == 1);
              if (sVar10 == 1) {
                *(undefined8 *)((longlong)alStackX_18 + lVar14 + 8) = 0;
                *(undefined **)((longlong)alStackX_18 + lVar14) = &stack0x00000a58 + lVar14;
                *(undefined8 *)((longlong)alStackX_8 + lVar14 + 8) = 0;
                *(undefined8 *)((longlong)alStackX_8 + lVar14) = 0;
                *(undefined *)((longlong)alStackX_18 + lVar14 + -0x18) = 1;
                *(undefined **)(&stack0xfffffffffffffff8 + lVar14) = &stack0x00000054 + lVar14;
                *(undefined **)(&stack0xfffffffffffffff0 + lVar14) = &stack0x00000a68 + lVar14;
                *(longlong **)(&stack0xffffffffffffffe8 + lVar14) = plVar28;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10140c;
                func_0x(param_4,&stack0x00000c38 + lVar14,0x1f9e);
              }
              else {
                *(undefined8 *)((longlong)alStackX_18 + lVar14 + 8) = 0;
                *(undefined *)((longlong)alStackX_18 + lVar14) = 1;
                *(undefined **)((longlong)alStackX_8 + lVar14 + 8) = &stack0x00000a58 + lVar14;
                *(undefined8 *)((longlong)alStackX_8 + lVar14) = 0;
                *(undefined8 *)((longlong)alStackX_18 + lVar14 + -0x18) = 0;
                (&stack0xfffffffffffffff8)[lVar14] = 1;
                *(undefined **)(&stack0xfffffffffffffff0 + lVar14) = &stack0x00000054 + lVar14;
                *(undefined **)(&stack0xffffffffffffffe8 + lVar14) = &stack0x00000a68 + lVar14;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101467;
                func_0x(&stack0x00000c38 + lVar14,0x1f9e,param_1);
              }
            }
            else {
              plVar27 = param_1;
              if ((*(byte *)(param_1 + 0x43) & 4) != 0) {
                pcVar1 = *(code **)(*param_1 + 0x1e8);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1011a1;
                plVar27 = (longlong *)(*pcVar1)(param_1);
              }
              *(longlong **)(&stack0x00000598 + lVar14) = plVar27 + 5;
              if (*(short *)(&stack0x00000a68 + lVar14) == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1011cd;
                func_0x();
              }
              else {
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1011d4;
                func_0x(&stack0x00000a6a + lVar14);
              }
              *(undefined **)(&stack0x000005a0 + lVar14) = &stack0x000000f4 + lVar14;
              if ((*(short *)(&stack0x000000f8 + lVar14) != *(short *)((longlong)plVar27 + 0x2c)) ||
                 (*(int *)(&stack0x000000f4 + lVar14) != *(int *)(plVar27 + 5))) goto LAB_;
              plVar27 = param_1 + 0x1a;
              lVar36 = *plVar27;
              *(longlong *)(&stack0x000005a8 + lVar14) = lVar36;
              if (cVar7 == '\0') {
LAB_:
                *(undefined8 *)((longlong)alStackX_18 + lVar14) = 0;
                *(undefined **)((longlong)alStackX_8 + lVar14 + 8) = &stack0x00000054 + lVar14;
                *(undefined *)((longlong)alStackX_8 + lVar14) = 1;
                *(undefined8 *)((longlong)alStackX_18 + lVar14 + -0x18) = 0;
                *(undefined **)(&stack0xfffffffffffffff8 + lVar14) = &stack0x00000a68 + lVar14;
                *(longlong *)(&stack0xfffffffffffffff0 + lVar14) = *plVar28;
                *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) = 0x1f9e;
                uVar19 = *(undefined8 *)(lVar15 + 0x6b0);
                lVar36 = plVar28[4];
                lVar18 = *plVar27;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1012d1;
                func_0x(lVar18,lVar36,uVar19);
              }
              else if (((lVar36 != 0) && (*(char *)(lVar36 + 0x34) != '\0')) &&
                      (*(longlong *)(lVar36 + 0x40) != 0)) {
                LOCK();
                lVar18 = *(longlong *)(lVar36 + 0x128);
                if (lVar18 == 0) {
                  *(longlong *)(lVar36 + 0x128) = 0;
                  lVar18 = 0;
                }
                UNLOCK();
                *(longlong *)(&stack0x000005b0 + lVar14) = lVar18;
                *(longlong *)(&stack0x000005b8 + lVar14) = lVar18;
                lVar36 = *plVar28;
                param_1 = *(longlong **)(&stack0x00000048 + lVar14);
                lVar15 = *(longlong *)(&stack0x000002c0 + lVar14);
                cVar7 = (&stack0x00000032)[lVar14];
                *(longlong **)(&stack0x00000028 + lVar14) = param_1;
                if (*(longlong *)(lVar36 + 0x28) != lVar18) goto LAB_;
              }
              if (cVar7 != '\0') {
                if (*(short *)(&stack0x00000a68 + lVar14) == 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1012fa;
                  func_0x();
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101301;
                  func_0x(&stack0x00000a6a + lVar14,&stack0x00000218 + lVar14);
                }
                *(undefined **)(&stack0x000005c0 + lVar14) = &stack0x00000218 + lVar14;
                if (*(short *)(&stack0x00000a68 + lVar14) == 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101331;
                  func_0x();
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101338;
                  func_0x(&stack0x00000a6a + lVar14,&stack0x000000e8 + lVar14);
                }
                *(undefined **)(&stack0x000005c8 + lVar14) = &stack0x000000e8 + lVar14;
                *(undefined4 *)(&stack0x000002e8 + lVar14) =
                     *(undefined4 *)(&stack0x000000e8 + lVar14);
                *(undefined2 *)(&stack0x000001a0 + lVar14) =
                     *(undefined2 *)(&stack0x000000ec + lVar14);
                *(undefined4 *)(&stack0x000001b8 + lVar14) =
                     *(undefined4 *)(&stack0x000000e8 + lVar14);
                *(undefined2 *)(&stack0x000001bc + lVar14) =
                     *(undefined2 *)(&stack0x000000ec + lVar14);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101391;
                iVar12 = func_0x(lVar15 + 0x19c8,&stack0x000001b8 + lVar14,
                                         &stack0x00000218 + lVar14);
                if (iVar12 != 0) goto LAB_;
              }
            }
          }
          iVar39 = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101745;
          iVar12 = func_0x(&stack0x00000a68 + lVar14);
          if ((iVar12 != 0) || (*(int *)(&stack0x00000054 + lVar14) == 0)) {
            (&stack0x00000031)[lVar14] = 1;
            goto LAB_;
          }
          if (*(short *)(&stack0x00000a68 + lVar14) == 0) {
            *(undefined **)(&stack0x00000650 + lVar14) = &stack0x00000a6a + lVar14;
            if (*(int *)(&stack0x00000a6c + lVar14) == 0) {
              *(undefined4 *)(&stack0x0000003c + lVar14) = 0;
              *(undefined2 *)(&stack0x00000a6a + lVar14) = 0;
              uVar26 = *(uint *)(&stack0x00000a78 + lVar14);
              *(uint *)(&stack0x00000a7c + lVar14) = uVar26;
              pbVar38 = *(byte **)(&stack0x00000a70 + lVar14);
              *(byte **)(&stack0x00000658 + lVar14) = pbVar38;
              if ((*pbVar38 & 0x10) != 0) {
                *(uint *)(&stack0x00000a7c + lVar14) =
                     uVar26 + 2 + (*(ushort *)(pbVar38 + uVar26) + 7 >> 3);
              }
              *(byte **)(&stack0x00000660 + lVar14) = pbVar38;
              iVar12 = iVar39;
              if ((*pbVar38 & 0x20) == 0) {
                *(undefined4 *)(&stack0x00000a6c + lVar14) =
                     *(undefined4 *)(&stack0x00000a7c + lVar14);
                *(undefined2 *)(&stack0x00000a84 + lVar14) = 0;
                *(undefined4 *)(&stack0x00000a80 + lVar14) =
                     *(undefined4 *)(&stack0x00000a7c + lVar14);
              }
              else {
                puVar40 = (ushort *)(pbVar38 + *(uint *)(&stack0x00000a7c + lVar14));
                *(ushort **)(&stack0x00000668 + lVar14) = puVar40;
                uVar35 = *puVar40;
                *(ushort *)(&stack0x00000a84 + lVar14) = uVar35;
                if (uVar35 == 0) {
                  iVar12 = 1;
                  *(undefined4 *)(&stack0x0000003c + lVar14) = 1;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101825;
                  cVar7 = func_0x(0x1c58840);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10182e;
                    lVar15 = func_0x();
                    *(longlong *)(&stack0x00000670 + lVar14) = lVar15;
                    if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101850;
                      cVar7 = func_0x(0x1c58840);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10186b;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10188f;
                        (*_DAT_)(1,0x154824c,0x1668338,0x80f);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1018a1;
                  func_0x(*(undefined8 *)(&stack0x00000a70 + lVar14),3);
                  uVar35 = *(ushort *)(&stack0x00000a84 + lVar14);
                  pbVar38 = *(byte **)(&stack0x00000a70 + lVar14);
                }
                uVar26 = *(int *)(&stack0x00000a7c + lVar14) + 2 + (uint)uVar35 * 2;
                *(uint *)(&stack0x00000a80 + lVar14) = uVar26;
                if (0x1f9e < uVar26) {
                  iVar12 = iVar12 + 1;
                  *(int *)(&stack0x0000003c + lVar14) = iVar12;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1018ed;
                  cVar7 = func_0x(0x1c58840);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1018f6;
                    lVar15 = func_0x();
                    *(longlong *)(&stack0x00000678 + lVar14) = lVar15;
                    if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101918;
                      cVar7 = func_0x(0x1c58840);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101934;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10195a;
                        (*_DAT_)(1,0x154824c,0x1668338,0x816);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10196e;
                  func_0x(*(undefined8 *)(&stack0x00000a70 + lVar14),4);
                  uVar35 = *(ushort *)(&stack0x00000a84 + lVar14);
                  uVar26 = *(uint *)(&stack0x00000a80 + lVar14);
                  pbVar38 = *(byte **)(&stack0x00000a70 + lVar14);
                }
                uVar45 = (ulonglong)uVar35;
                uVar35 = puVar40[uVar45];
                *(ushort *)(&stack0x000001ac + lVar14) = uVar35;
                uVar24 = uVar35 & 0x7fff;
                *(uint *)(&stack0x00000a6c + lVar14) = uVar24;
                if (uVar24 < uVar26) {
                  iVar12 = iVar12 + 1;
                  *(int *)(&stack0x0000003c + lVar14) = iVar12;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1019cc;
                  cVar7 = func_0x(0x1c58840);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1019d5;
                    lVar15 = func_0x();
                    *(longlong *)(&stack0x00000680 + lVar14) = lVar15;
                    if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1019f7;
                      cVar7 = func_0x(0x1c58840);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101a13;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101a39;
                        (*_DAT_)(1,0x154824c,0x1668338,0x81d);
                      }
                    }
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101a48;
                  func_0x(*(undefined8 *)(&stack0x00000a70 + lVar14),4);
                  uVar45 = (ulonglong)*(ushort *)(&stack0x00000a84 + lVar14);
                  uVar26 = *(uint *)(&stack0x00000a80 + lVar14);
                  pbVar38 = *(byte **)(&stack0x00000a70 + lVar14);
                  uVar24 = *(uint *)(&stack0x00000a6c + lVar14);
                }
                *(uint *)(&stack0x0000016c + lVar14) = uVar26;
                *(undefined4 *)(&stack0x00000170 + lVar14) = 0;
                uVar42 = uVar26;
                while (iVar39 < (int)uVar45) {
                  uVar35 = puVar40[(longlong)iVar39 + 1];
                  *(ushort *)(&stack0x000001c0 + lVar14) = uVar35;
                  uVar30 = uVar35 & 0x7fff;
                  *(uint *)(&stack0x00000398 + lVar14) = uVar30;
                  if ((uVar30 < uVar42) || (uVar24 < uVar30)) {
                    iVar12 = iVar12 + 1;
                    *(int *)(&stack0x0000003c + lVar14) = iVar12;
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101acc;
                    cVar7 = func_0x(0x1c58840);
                    if (cVar7 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101ad5;
                      lVar15 = func_0x();
                      *(longlong *)(&stack0x00000688 + lVar14) = lVar15;
                      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101af7;
                        cVar7 = func_0x(0x1c58840);
                        if (cVar7 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101b13;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101b39;
                          (*_DAT_)(1,0x154824c,0x1668338,0x82a);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101b48;
                    func_0x(*(undefined8 *)(&stack0x00000a70 + lVar14),4);
                    uVar45 = (ulonglong)*(ushort *)(&stack0x00000a84 + lVar14);
                    uVar26 = *(uint *)(&stack0x00000a80 + lVar14);
                    pbVar38 = *(byte **)(&stack0x00000a70 + lVar14);
                    uVar24 = *(uint *)(&stack0x00000a6c + lVar14);
                  }
                  *(uint *)(&stack0x0000016c + lVar14) = uVar30;
                  iVar39 = iVar39 + 1;
                  *(int *)(&stack0x00000170 + lVar14) = iVar39;
                  uVar42 = uVar30;
                }
                do {
                  iVar39 = (int)uVar45;
                  *(ushort **)(&stack0x00000690 + lVar14) = puVar40 + (ulonglong)(iVar39 - 1) + 1;
                  if (-1 < (short)puVar40[(ulonglong)(iVar39 - 1) + 1]) break;
                  *(int *)(&stack0x00000310 + lVar14) = iVar39;
                  pbVar37 = pbVar38 + *(uint *)(&stack0x00000a7c + lVar14);
                  *(byte **)(&stack0x00000698 + lVar14) = pbVar37;
                  uVar42 = uVar26;
                  if (iVar39 != 1) {
                    uVar35 = *(ushort *)(pbVar37 + (longlong)(iVar39 + -2) * 2 + 2);
                    *(ushort *)(&stack0x000001c4 + lVar14) = uVar35;
                    uVar42 = uVar35 & 0x7fff;
                  }
                  uVar35 = *(ushort *)(pbVar37 + (longlong)(iVar39 + -1) * 2 + 2);
                  *(ushort *)(&stack0x000001c8 + lVar14) = uVar35;
                  uVar30 = uVar35 & 0x7fff;
                  *(uint *)(&stack0x00000348 + lVar14) = uVar30;
                  if (((uVar42 < uVar26) || (uVar30 < uVar42)) || (uVar24 < uVar30)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101c2b;
                    func_0x(pbVar38,7);
                    uVar45 = (ulonglong)*(ushort *)(&stack0x00000a84 + lVar14);
                    uVar26 = *(uint *)(&stack0x00000a80 + lVar14);
                    pbVar38 = *(byte **)(&stack0x00000a70 + lVar14);
                    uVar24 = *(uint *)(&stack0x00000a6c + lVar14);
                  }
                  uVar30 = uVar30 - uVar42;
                  *(uint *)(&stack0x0000034c + lVar14) = uVar30;
                  *(uint *)(&stack0x00000350 + lVar14) = uVar42;
                  if ((uVar42 < uVar26) || (uVar24 < uVar42)) {
                    iVar12 = iVar12 + 1;
                    goto LAB_;
                  }
                  uVar35 = *(ushort *)(pbVar38 + uVar42);
                  *(ushort *)(&stack0x000001cc + lVar14) = uVar35;
                  if (uVar35 == 5) {
                    *(ushort *)(&stack0x00000a6a + lVar14) =
                         *(ushort *)(&stack0x00000a6a + lVar14) | 2;
                    *(short *)(&stack0x00000a84 + lVar14) =
                         *(short *)(&stack0x00000a84 + lVar14) + -1;
                    *(uint *)(&stack0x00000358 + lVar14) = uVar30;
                    puVar40 = (ushort *)(&stack0x00000a92 + lVar14);
                    *(ushort **)(&stack0x000006a0 + lVar14) = puVar40;
                    *puVar40 = (ushort)uVar42;
                    puVar6 = &stack0x00000a6a + lVar14;
                    *(undefined **)(&stack0x000006a8 + lVar14) = puVar6;
                    lVar15 = (ulonglong)(uVar42 & 0xffff) + *(longlong *)(&stack0x00000a70 + lVar14)
                    ;
                    *(longlong *)(&stack0x000006b0 + lVar14) = lVar15;
                    uVar35 = *(ushort *)(lVar15 + 2);
                    *(ushort *)(&stack0x00000a94 + lVar14) =
                         *(ushort *)(&stack0x00000a94 + lVar14) & 0xc7ff;
                    if ((uVar35 >> 0xe & 1) != 0) {
                      *(ushort *)(&stack0x00000a94 + lVar14) =
                           *(ushort *)(&stack0x00000a94 + lVar14) | uVar35 & 0x3800;
                    }
                    uVar35 = *(ushort *)(&stack0x00000a94 + lVar14);
                    uVar9 = (uVar35 ^ *(ushort *)(lVar15 + 2)) & 0x7ff ^ uVar35;
                    *(ushort *)(&stack0x00000a94 + lVar14) = uVar9;
                    *(undefined **)(&stack0x000006b8 + lVar14) = puVar6;
                    uVar45 = (ulonglong)*puVar40;
                    uVar44 = (ulonglong)((uVar35 >> 0xb & 7) * 2) + 4 +
                             ((ulonglong)uVar9 & 0x7ff) * 2 +
                             *(longlong *)(&stack0x00000a70 + lVar14) + uVar45;
                    *(ulonglong *)(&stack0x000006c0 + lVar14) = uVar44;
                    *(undefined **)(&stack0x000006c8 + lVar14) = puVar6;
                    if (uVar44 < uVar45 + *(longlong *)(&stack0x00000a70 + lVar14)) {
                      *(undefined **)(&stack0x000006d0 + lVar14) = puVar6;
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101d66;
                      func_0x(uVar45 + *(longlong *)(&stack0x00000a70 + lVar14),0x19);
                      uVar9 = *(ushort *)(&stack0x00000a94 + lVar14);
                    }
                    *(undefined **)(&stack0x000006d8 + lVar14) = puVar6;
                    uVar26 = (((uVar9 & 0x7ff) * 2 - *(int *)(&stack0x00000a70 + lVar14)) -
                             (uint)*puVar40) + (int)uVar44;
                    *(uint *)(&stack0x00000360 + lVar14) = uVar26;
                    if (uVar30 < uVar26) {
                      *(undefined **)(&stack0x000006e0 + lVar14) = puVar6;
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101daa;
                      func_0x((ulonglong)(uint)*puVar40 +
                                      *(longlong *)(&stack0x00000a70 + lVar14),0x19);
                      uVar9 = *(ushort *)(&stack0x00000a94 + lVar14);
                    }
                    if ((uVar9 & 0x3800) != 0) {
                      *(undefined **)(&stack0x000006e8 + lVar14) = puVar6;
                      lVar15 = (ulonglong)*puVar40 + 4 + *(longlong *)(&stack0x00000a70 + lVar14);
                      *(longlong *)(&stack0x000006f0 + lVar14) = lVar15;
                      iVar39 = 0;
                      *(undefined4 *)(&stack0x00000174 + lVar14) = 0;
                      while (iVar39 < (int)(*(ushort *)(&stack0x00000a94 + lVar14) >> 0xb & 7)) {
                        if ((*(ushort *)(&stack0x00000a94 + lVar14) & 0x7ff) <
                            (*(ushort *)(lVar15 + (longlong)iVar39 * 2) & 0x7ff)) {
                          *(undefined **)(&stack0x000006f8 + lVar14) = &stack0x00000a6a + lVar14;
                          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101e26;
                          func_0x((ulonglong)*puVar40 +
                                          *(longlong *)(&stack0x00000a70 + lVar14),0x1a);
                        }
                        iVar39 = iVar39 + 1;
                        *(int *)(&stack0x00000174 + lVar14) = iVar39;
                      }
                    }
                    break;
                  }
                  if (uVar35 < 0x400) break;
                  *(ushort *)(&stack0x00000a6a + lVar14) =
                       *(ushort *)(&stack0x00000a6a + lVar14) | 1;
                  uVar35 = (short)uVar45 - 1;
                  uVar45 = (ulonglong)uVar35;
                  *(ushort *)(&stack0x00000a84 + lVar14) = uVar35;
                } while (uVar35 != 0);
              }
              iVar39 = 0;
              if ((**(byte **)(&stack0x00000a70 + lVar14) & 0x40) == 0) {
                *(undefined4 *)(&stack0x00000a8e + lVar14) = 0;
              }
              else {
                *(undefined4 *)(&stack0x00000a8e + lVar14) =
                     *(undefined4 *)(&stack0x00000a6c + lVar14);
                *(int *)(&stack0x00000a6c + lVar14) = *(int *)(&stack0x00000a6c + lVar14) + 0xe;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101eb4;
                puVar20 = (ulonglong *)func_0x(&stack0x00000a6a + lVar14);
                *(ulonglong **)(&stack0x00000700 + lVar14) = puVar20;
                uVar45 = *puVar20;
                *(ulonglong *)(&stack0x000003b8 + lVar14) = uVar45;
                *(undefined4 *)(&stack0x00000178 + lVar14) = 0;
                uVar35 = (ushort)(uVar45 >> 0x30);
                if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                  if ((uVar45 & 0x4000000000000000) == 0) {
                    uVar35 = uVar35 & 0xdfff;
                  }
                  else {
                    uVar35 = uVar35 | 0x2000;
                  }
                }
                *(ushort *)(&stack0x000001d0 + lVar14) = uVar35;
                if (uVar35 == 0xfffc) {
                  *(undefined **)(&stack0x00000708 + lVar14) = &stack0x000003b8 + lVar14;
                  iVar39 = (int)((uVar45 >> 0x20 & 0xffff) >> 5);
                  *(int *)(&stack0x00000178 + lVar14) = iVar39;
                }
                *(int *)(&stack0x00000a6c + lVar14) = *(int *)(&stack0x00000a6c + lVar14) + iVar39;
              }
              if ((*(ulonglong *)(&stack0x00000a86 + lVar14) != 0) &&
                 (*(ulonglong *)(&stack0x00000a86 + lVar14) <
                  (ulonglong)*(uint *)(&stack0x00000a6c + lVar14) +
                  *(longlong *)(&stack0x00000a70 + lVar14))) {
                iVar12 = iVar12 + 1;
                *(int *)(&stack0x0000003c + lVar14) = iVar12;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101f90;
                cVar7 = func_0x(0x1c58840);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101f99;
                  lVar15 = func_0x();
                  *(longlong *)(&stack0x00000710 + lVar14) = lVar15;
                  if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101fbb;
                    cVar7 = func_0x(0x1c58840);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101fd7;
                      (*_DAT_)(0x22,0x44,0x15);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x101ffd;
                      (*_DAT_)(1,0x154824c,0x1668338);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10200b;
                func_0x(*(undefined8 *)(&stack0x00000a70 + lVar14),0x12);
              }
              if (0x3f3b < *(int *)(&stack0x00000a6c + lVar14) - 1U) {
                iVar12 = iVar12 + 1;
                *(int *)(&stack0x0000003c + lVar14) = iVar12;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10202f;
                cVar7 = func_0x(0x1c58840);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102038;
                  lVar15 = func_0x();
                  *(longlong *)(&stack0x00000718 + lVar14) = lVar15;
                  if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10205a;
                    cVar7 = func_0x(0x1c58840);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102076;
                      (*_DAT_)(0x22,0x44,0x15);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10209c;
                      (*_DAT_)(1,0x154824c,0x1668338);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1020aa;
                func_0x(*(undefined8 *)(&stack0x00000a70 + lVar14),5);
              }
LAB_:
              *(int *)(&stack0x0000003c + lVar14) = iVar12;
              *(int *)(&stack0x0000017c + lVar14) = iVar12;
            }
            uVar26 = *(uint *)(&stack0x00000a6c + lVar14);
            if (uVar26 < 9) {
              *(byte **)(&stack0x00000720 + lVar14) = *(byte **)(&stack0x00000a70 + lVar14);
              bVar23 = **(byte **)(&stack0x00000a70 + lVar14) & 0xe;
              (&stack0x000000ac)[lVar14] = bVar23;
              if ((bVar23 == 0) || (bVar23 == 0xc)) {
                uVar26 = 9;
              }
            }
            *(uint *)(&stack0x00000364 + lVar14) = uVar26;
            *(uint *)(&stack0x00000100 + lVar14) = uVar26;
            sVar10 = (short)uVar26;
            if ((&stack0x00000031)[lVar14] != '\0') {
              param_1 = *(longlong **)(&stack0x00000028 + lVar14);
              goto LAB_;
            }
          }
          else {
            uVar26 = *(uint *)(&stack0x00000a6c + lVar14);
            if (uVar26 == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10229e;
              func_0x(&stack0x00000a6a + lVar14);
              uVar26 = *(uint *)(&stack0x00000a6c + lVar14);
            }
            if ((uVar26 < 9) &&
               (((**(byte **)(&stack0x00000a70 + lVar14) & 0x1c) == 0 ||
                ((**(byte **)(&stack0x00000a70 + lVar14) & 0x1c) == 0xc)))) {
              uVar26 = 9;
            }
            *(uint *)(&stack0x00000100 + lVar14) = uVar26;
            sVar10 = (short)uVar26;
          }
          lVar15 = *(longlong *)(&stack0x00000060 + lVar14);
          iVar12 = (1 << ((byte)*(undefined2 *)(lVar15 + 4) & 2)) + -1;
          *(int *)(&stack0x00000368 + lVar14) = iVar12;
          uVar35 = (ushort)iVar12;
          *(int *)(&stack0x0000036c + lVar14) = iVar12;
          if ((ushort)(uVar35 + *(short *)(&stack0x00000098 + lVar14) & ~uVar35) <
              (ushort)(uVar35 + sVar10 & ~uVar35)) {
            if ((&stack0x00002c68)[lVar14] == '\0') {
              puVar16 = *(undefined8 **)(&stack0x00000108 + lVar14);
              if (puVar16 != (undefined8 *)0x0) {
                pcVar1 = *(code **)*puVar16;
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10233c;
                (*pcVar1)(puVar16,1);
              }
              goto LAB_;
            }
LAB_:
            sVar10 = -1;
            *(undefined2 *)(&stack0x000009a8 + lVar14) = 0xffff;
            ppbVar31 = (byte **)0x0;
            *(undefined8 *)(&stack0x000009b0 + lVar14) = 0;
            *(undefined4 *)(&stack0x000009ac + lVar14) = 0;
            *(undefined8 *)(&stack0x000009c6 + lVar14) = 0;
            *(undefined8 *)(&stack0x000009d0 + lVar14) = 0;
            *(undefined8 *)(&stack0x000009b8 + lVar14) = 0;
            *(undefined4 *)(&stack0x000009dc + lVar14) = 0xffffffff;
            *(undefined4 *)(&stack0x00000180 + lVar14) = 0;
            ppbVar41 = ppbVar31;
            while( true ) {
              iVar12 = (int)ppbVar41;
              if ((int)(uint)*(ushort *)(lVar15 + 0x16) <= iVar12) break;
              if ((iVar12 == *(int *)(&stack0x00000058 + lVar14)) ||
                 (*(short *)(lVar15 + (0xfff - (longlong)iVar12) * 2) == 0)) {
                ppbVar41 = (byte **)(ulonglong)(iVar12 + 1U);
                *(uint *)(&stack0x00000180 + lVar14) = iVar12 + 1U;
              }
              else {
                *(int *)(&stack0x000009dc + lVar14) = iVar12;
                lVar36 = lVar15;
                if (*(char *)(lVar15 + 2) < '\0') {
                  pbVar38 = (byte *)(lVar15 + 0x60);
                  if (*(short *)(&stack0x000009a8 + lVar14) == 0) {
                    *(undefined8 *)(&stack0x00000220 + lVar14) = 0;
LAB_:
                    *(undefined (*) [16])(&stack0x000009e0 + lVar14) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x000009f0 + lVar14) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000a00 + lVar14) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000a10 + lVar14) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000a20 + lVar14) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000a30 + lVar14) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000a40 + lVar14) = ZEXT816(0);
                    *(undefined8 *)(&stack0x00000a50 + lVar14) = 0;
                    *(undefined (*) [16])(&stack0x000009e0 + lVar14) = ZEXT816(0);
                    *(short *)(&stack0x000009f0 + lVar14) = sVar10;
                    *(undefined8 *)(&stack0x000009f8 + lVar14) = 0;
                    *(undefined4 *)(&stack0x000009f4 + lVar14) = 0;
                    *(undefined8 *)(&stack0x00000a0e + lVar14) = 0;
                    *(undefined8 *)(&stack0x00000a18 + lVar14) = 0;
                    *(undefined8 *)(&stack0x00000a00 + lVar14) = 0;
                    *(undefined8 *)(&stack0x00000a28 + lVar14) = 0;
                    *(undefined4 *)(&stack0x00000a40 + lVar14) = 0;
                    *(undefined4 *)(&stack0x00000a44 + lVar14) = 0;
                    *(undefined2 *)(&stack0x00000a48 + lVar14) = 0;
                    *(undefined2 *)(&stack0x00000a4a + lVar14) = 0;
                    *(undefined2 *)(&stack0x00000a52 + lVar14) = 0;
                    ppbVar31 = (byte **)(&stack0x000009e0 + lVar14);
                    *(byte ***)(&stack0x00000220 + lVar14) = ppbVar31;
                  }
                  else {
                    *(byte ***)(&stack0x00000220 + lVar14) = ppbVar31;
                    if (ppbVar31 == (byte **)0x0) goto LAB_;
                  }
                  (&stack0x00000051)[lVar14] = 0;
                  if (*(short *)(lVar15 + 0x24) == 0) {
LAB_:
                    *(undefined8 *)(&stack0x00000150 + lVar14) = *(undefined8 *)(lVar36 + 0x28);
                    *(undefined2 *)(&stack0x00000158 + lVar14) = *(undefined2 *)(lVar36 + 0x30);
                  }
                  else {
                    cVar7 = *(char *)(lVar15 + 1);
                    if (cVar7 == '\v') {
                      if (*(int *)(lVar15 + 0x18) == 99) goto LAB_;
LAB_:
                      if (cVar7 == '\t') goto LAB_;
LAB_:
                      cVar7 = '\0';
                    }
                    else {
                      if (cVar7 != '\b') goto LAB_;
LAB_:
                      if (*(int *)(lVar15 + 0x18) != 99) goto LAB_;
LAB_:
                      *(undefined4 *)(&stack0x000001b0 + lVar14) = *(undefined4 *)(lVar15 + 0x20);
                      *(undefined2 *)(&stack0x000001b4 + lVar14) = *(undefined2 *)(lVar15 + 0x24);
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102555;
                      cVar7 = func_0x(&stack0x000001b0 + lVar14);
                      if (cVar7 == '\0') goto LAB_;
                      cVar7 = '\x01';
                    }
                    (&stack0x00000051)[lVar14] = cVar7;
                    if (cVar7 == '\0') goto LAB_;
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10257a;
                    func_0x(lVar36,&stack0x00000150 + lVar14);
                  }
                  *ppbVar31 = pbVar38;
                  uVar11 = *(undefined2 *)(&stack0x00000158 + lVar14);
                  uVar13 = *(undefined4 *)(&stack0x00000154 + lVar14);
                  *(undefined4 *)(ppbVar31 + 0xc) = *(undefined4 *)(&stack0x00000150 + lVar14);
                  *(undefined4 *)((longlong)ppbVar31 + 100) = uVar13;
                  *(undefined2 *)(ppbVar31 + 0xd) = uVar11;
                  *(undefined4 *)((longlong)ppbVar31 + 0x6c) = *(undefined4 *)(lVar36 + 0x20);
                  *(undefined2 *)(ppbVar31 + 0xe) = *(undefined2 *)(lVar36 + 0x24);
                  *(undefined2 *)((longlong)ppbVar31 + 0x72) = 0;
                  bVar23 = *pbVar38;
                  *(undefined4 *)(&stack0x000002d0 + lVar14) =
                       *(undefined4 *)((ulonglong)bVar23 * 6 + 0x1342090);
                  uVar45 = (ulonglong)*(short *)((ulonglong)bVar23 * 6 + 0x1342094);
                  *(short *)(ppbVar31 + 2) = sVar10;
                  ppbVar31[3] = (byte *)0x0;
                  uVar24 = 0;
                  *(undefined4 *)((longlong)ppbVar31 + 0x14) = 0;
                  *(undefined8 *)((longlong)ppbVar31 + 0x2e) = 0;
                  ppbVar31[7] = (byte *)0x0;
                  ppbVar31[4] = (byte *)0x0;
                  ppbVar31[9] = (byte *)0x0;
                  ppbVar31[10] = (byte *)0x0;
                  *(undefined2 *)(ppbVar31 + 0xb) = 0;
                  if ((**ppbVar31 & 2) != 0) {
                    pbVar37 = pbVar38 + uVar45;
                    bVar23 = *pbVar37;
                    *(ushort *)(ppbVar31 + 2) = (ushort)(bVar23 & 1);
                    if ((bVar23 & 1) == 0) {
                      *(undefined4 *)(&stack0x00000090 + lVar14) = 0;
                      ppbVar31[3] = pbVar37;
                      *(undefined4 *)((longlong)ppbVar31 + 0x14) = 0;
                      *(undefined4 *)((longlong)ppbVar31 + 0x36) = 0;
                      pbVar3 = ppbVar31[3];
                      switch(*pbVar3 & 0xe) {
                      default:
                        uVar35 = *(ushort *)(pbVar37 + 2);
                        uVar24 = (uint)uVar35;
                        *(uint *)(&stack0x00000090 + lVar14) = (uint)uVar35;
                        if (uVar35 - 1 < 0x1f9e) goto code_r0x0010270e;
                        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102691;
                        func_0x(pbVar3,6);
                        lVar36 = *(longlong *)(&stack0x00000060 + lVar14);
                        *(uint *)(ppbVar31 + 4) = (uint)uVar35;
                        *(undefined8 *)((longlong)ppbVar31 + 0x2e) = 0;
                        break;
                      case 4:
                        *(undefined4 *)(&stack0x00000090 + lVar14) = 9;
                        *(undefined4 *)(ppbVar31 + 4) = 9;
                        *(undefined8 *)((longlong)ppbVar31 + 0x2e) = 0;
                        break;
                      case 6:
                      case 10:
code_r0x0010270e:
                        *(uint *)(ppbVar31 + 4) = uVar24;
                        *(undefined8 *)((longlong)ppbVar31 + 0x2e) = 0;
                        break;
                      case 0xe:
                        *(undefined4 *)(&stack0x00000090 + lVar14) = 1;
                        *(undefined4 *)(ppbVar31 + 4) = 1;
                        *(undefined8 *)((longlong)ppbVar31 + 0x2e) = 0;
                      }
                    }
                    else {
                      ppbVar31[3] = pbVar37;
                      bVar23 = *pbVar37;
                      switch(bVar23 & 0x1c) {
                      default:
                        if ((char)pbVar37[1] < '\0') {
                          uVar35 = *(ushort *)(pbVar37 + 1);
                          *(ushort *)((longlong)ppbVar31 + 0x12) = uVar35;
                          *(ushort *)((longlong)ppbVar31 + 0x12) =
                               (uVar35 & 0x7f) << 8 | uVar35 >> 8;
                          uVar11 = 3;
                          sVar10 = 3;
                        }
                        else {
                          *(ushort *)((longlong)ppbVar31 + 0x12) = (ushort)pbVar37[1];
                          uVar11 = 2;
                          sVar10 = 2;
                        }
                        *(undefined2 *)(ppbVar31 + 5) = uVar11;
                        *(short *)((longlong)ppbVar31 + 0x2c) =
                             (short)(*(ushort *)((longlong)ppbVar31 + 0x12) + 1 >> 1) + sVar10;
                        if (*(ushort *)((longlong)ppbVar31 + 0x12) < 0x1f) {
                          *(undefined2 *)((longlong)ppbVar31 + 0x2a) = 0;
                          *(undefined4 *)((longlong)ppbVar31 + 0x14) = 0;
                          *(undefined4 *)(ppbVar31 + 8) = 0;
                        }
                        else {
                          iVar39 = *(ushort *)((longlong)ppbVar31 + 0x12) - 1;
                          *(short *)((longlong)ppbVar31 + 0x2a) =
                               ((short)(iVar39 / 0x1e) + (short)(iVar39 >> 0x1f)) -
                               (short)((longlong)iVar39 * 0x88888889 >> 0x3f);
                          *(undefined4 *)((longlong)ppbVar31 + 0x14) = 0;
                          *(undefined4 *)(ppbVar31 + 8) = 0;
                        }
                        break;
                      case 4:
                        if (((bVar23 & 0x1c) == 4) && ((bVar23 & 2) != 0)) {
                          ppbVar31[3] = (byte *)0x0;
                          *(undefined4 *)((longlong)ppbVar31 + 0x14) = 0;
                          *(undefined2 *)(ppbVar31 + 5) = 0;
                          *(undefined2 *)((longlong)ppbVar31 + 0x12) = 0;
                          *(undefined2 *)((longlong)ppbVar31 + 0x2a) = 0;
                          *(undefined2 *)((longlong)ppbVar31 + 0x2c) = 0;
                          *(undefined2 *)((longlong)ppbVar31 + 0x2e) = 0;
                          *(undefined2 *)(ppbVar31 + 6) = 0;
                          *(undefined2 *)((longlong)ppbVar31 + 0x32) = 0;
                          *(undefined2 *)((longlong)ppbVar31 + 0x34) = 0;
                          *(undefined2 *)((longlong)ppbVar31 + 0x36) = 0;
                          ppbVar31[4] = (byte *)0x0;
                          *(undefined4 *)(ppbVar31 + 8) = 0;
                          ppbVar31[7] = (byte *)0x0;
                          ppbVar31[3] = pbVar37;
                          *(undefined4 *)((longlong)ppbVar31 + 0x14) = 0xf;
                          *(undefined4 *)(ppbVar31 + 8) = 0;
                          *(undefined4 *)(ppbVar31 + 8) = 1;
                        }
                        else {
                          ppbVar31[3] = (byte *)0x0;
                          *(undefined4 *)((longlong)ppbVar31 + 0x14) = 0;
                          *(undefined2 *)(ppbVar31 + 5) = 0;
                          *(undefined2 *)((longlong)ppbVar31 + 0x12) = 0;
                          *(undefined2 *)((longlong)ppbVar31 + 0x2a) = 0;
                          *(undefined2 *)((longlong)ppbVar31 + 0x2c) = 0;
                          *(undefined2 *)((longlong)ppbVar31 + 0x2e) = 0;
                          *(undefined2 *)(ppbVar31 + 6) = 0;
                          *(undefined2 *)((longlong)ppbVar31 + 0x32) = 0;
                          *(undefined2 *)((longlong)ppbVar31 + 0x34) = 0;
                          *(undefined2 *)((longlong)ppbVar31 + 0x36) = 0;
                          ppbVar31[4] = (byte *)0x0;
                          *(undefined4 *)(ppbVar31 + 8) = 0;
                          ppbVar31[7] = (byte *)0x0;
                          ppbVar31[3] = pbVar37;
                          *(undefined4 *)((longlong)ppbVar31 + 0x14) = 1;
                          *(undefined4 *)(ppbVar31 + 8) = 0;
                        }
                        break;
                      case 8:
                        ppbVar31[3] = (byte *)0x0;
                        *(undefined4 *)((longlong)ppbVar31 + 0x14) = 0;
                        *(undefined2 *)(ppbVar31 + 5) = 0;
                        *(undefined2 *)((longlong)ppbVar31 + 0x12) = 0;
                        *(undefined2 *)((longlong)ppbVar31 + 0x2a) = 0;
                        *(undefined2 *)((longlong)ppbVar31 + 0x2c) = 0;
                        *(undefined2 *)((longlong)ppbVar31 + 0x2e) = 0;
                        *(undefined2 *)(ppbVar31 + 6) = 0;
                        *(undefined2 *)((longlong)ppbVar31 + 0x32) = 0;
                        *(undefined2 *)((longlong)ppbVar31 + 0x34) = 0;
                        *(undefined2 *)((longlong)ppbVar31 + 0x36) = 0;
                        ppbVar31[4] = (byte *)0x0;
                        *(undefined4 *)(ppbVar31 + 8) = 0;
                        ppbVar31[7] = (byte *)0x0;
                        ppbVar31[3] = pbVar37;
                        *(undefined4 *)((longlong)ppbVar31 + 0x14) = 9;
                        *(undefined4 *)(ppbVar31 + 8) = 0;
                      }
                      ppbVar31[7] = (byte *)0x0;
                      ppbVar31[4] = (byte *)0x0;
                    }
                  }
                  if ((**ppbVar31 & 4) != 0) {
                    if (*(short *)(&stack0x000002d2 + lVar14) != 0) {
                      uVar45 = (ulonglong)
                               *(ushort *)
                                (lVar15 + 0x61 + (longlong)*(short *)(&stack0x000002d2 + lVar14) * 2
                                );
                    }
                    psVar21 = (short *)(pbVar38 + uVar45);
                    ppbVar31[9] = (byte *)psVar21;
                    sVar10 = *psVar21;
                    ppbVar31[10] = (byte *)(psVar21 + 1);
                    *(short *)(ppbVar31 + 0xb) = (sVar10 + 1) * 2;
                  }
                  pbVar38 = ppbVar31[1];
                  if (pbVar38 != (byte *)0x0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10296e;
                    func_0x(pbVar38,ppbVar31);
                    lVar36 = *(longlong *)(&stack0x00000060 + lVar14);
                  }
                }
                else {
                  *(undefined8 *)(&stack0x00000220 + lVar14) = 0;
                  ppbVar31 = (byte **)0x0;
                }
                uVar35 = *(ushort *)(lVar36 + 0xe);
                uVar24 = (uint)uVar35;
                pbVar38 = (byte *)((ulonglong)*(ushort *)(lVar36 + (0xfff - (longlong)iVar12) * 2) +
                                  lVar36);
                bVar23 = *pbVar38;
                *(ushort *)(&stack0x000009a8 + lVar14) = (ushort)(bVar23 & 1);
                if ((bVar23 & 1) == 0) {
                  *(uint *)(&stack0x000000a0 + lVar14) = (uint)uVar35;
                  *(byte **)(&stack0x000009b0 + lVar14) = pbVar38;
                  *(undefined4 *)(&stack0x000009ac + lVar14) = 0;
                  *(undefined4 *)(&stack0x000009ce + lVar14) = 0;
                  switch(*pbVar38 & 0xe) {
                  default:
                    uVar35 = *(ushort *)(pbVar38 + 2);
                    uVar24 = (uint)uVar35;
                    *(uint *)(&stack0x000000a0 + lVar14) = (uint)uVar35;
                    if (0x1f9d < uVar35 - 1) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102a0e;
                      func_0x(pbVar38,6);
                      lVar36 = *(longlong *)(&stack0x00000060 + lVar14);
                    }
                    break;
                  case 4:
                    uVar24 = 9;
                    *(undefined4 *)(&stack0x000000a0 + lVar14) = 9;
                    break;
                  case 6:
                  case 10:
                    break;
                  case 0xe:
                    uVar24 = 1;
                    *(undefined4 *)(&stack0x000000a0 + lVar14) = 1;
                  }
                  *(uint *)(&stack0x000009b8 + lVar14) = uVar24;
                  *(longlong *)(&stack0x000009c6 + lVar14) = lVar36 + 0x2000;
                  ppbVar31 = *(byte ***)(&stack0x000009b8 + lVar14);
                  lVar15 = lVar36;
                }
                else {
                  *(byte **)(&stack0x000009b0 + lVar14) = pbVar38;
                  bVar23 = *pbVar38;
                  switch(bVar23 & 0x1c) {
                  default:
                    uVar35 = (ushort)pbVar38[1];
                    if ((char)pbVar38[1] < '\0') {
                      uVar35 = *(ushort *)(pbVar38 + 1);
                      *(ushort *)(&stack0x000009aa + lVar14) = uVar35;
                      uVar35 = uVar35 >> 8 | (uVar35 & 0x7f) << 8;
                      sVar10 = 3;
                    }
                    else {
                      sVar10 = 2;
                    }
                    *(ushort *)(&stack0x000009aa + lVar14) = uVar35;
                    *(short *)(&stack0x000009c0 + lVar14) = sVar10;
                    *(short *)(&stack0x000009c4 + lVar14) = (short)(uVar35 + 1 >> 1) + sVar10;
                    if (uVar35 < 0x1f) {
                      *(undefined2 *)(&stack0x000009c2 + lVar14) = 0;
                      *(undefined4 *)(&stack0x000009ac + lVar14) = 0;
                      *(undefined4 *)(&stack0x000009d8 + lVar14) = 0;
                    }
                    else {
                      iVar39 = uVar35 - 1;
                      *(short *)(&stack0x000009c2 + lVar14) =
                           ((short)(iVar39 / 0x1e) + (short)(iVar39 >> 0x1f)) -
                           (short)((longlong)iVar39 * 0x88888889 >> 0x3f);
                      *(undefined4 *)(&stack0x000009ac + lVar14) = 0;
                      *(undefined4 *)(&stack0x000009d8 + lVar14) = 0;
                    }
                    break;
                  case 4:
                    if (((bVar23 & 0x1c) == 4) && ((bVar23 & 2) != 0)) {
                      *(undefined8 *)(&stack0x000009b0 + lVar14) = 0;
                      *(undefined4 *)(&stack0x000009ac + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009c0 + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009aa + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009c2 + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009c4 + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009c6 + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009c8 + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009ca + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009cc + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009ce + lVar14) = 0;
                      *(undefined8 *)(&stack0x000009b8 + lVar14) = 0;
                      *(undefined4 *)(&stack0x000009d8 + lVar14) = 0;
                      *(undefined8 *)(&stack0x000009d0 + lVar14) = 0;
                      *(byte **)(&stack0x000009b0 + lVar14) = pbVar38;
                      *(undefined4 *)(&stack0x000009ac + lVar14) = 0xf;
                      *(undefined4 *)(&stack0x000009d8 + lVar14) = 0;
                      *(undefined4 *)(&stack0x000009d8 + lVar14) = 1;
                    }
                    else {
                      *(undefined8 *)(&stack0x000009b0 + lVar14) = 0;
                      *(undefined4 *)(&stack0x000009ac + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009c0 + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009aa + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009c2 + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009c4 + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009c6 + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009c8 + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009ca + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009cc + lVar14) = 0;
                      *(undefined2 *)(&stack0x000009ce + lVar14) = 0;
                      *(undefined8 *)(&stack0x000009b8 + lVar14) = 0;
                      *(undefined4 *)(&stack0x000009d8 + lVar14) = 0;
                      *(undefined8 *)(&stack0x000009d0 + lVar14) = 0;
                      *(byte **)(&stack0x000009b0 + lVar14) = pbVar38;
                      *(undefined4 *)(&stack0x000009ac + lVar14) = 1;
                      *(undefined4 *)(&stack0x000009d8 + lVar14) = 0;
                    }
                    break;
                  case 8:
                    *(undefined8 *)(&stack0x000009b0 + lVar14) = 0;
                    *(undefined4 *)(&stack0x000009ac + lVar14) = 0;
                    *(undefined2 *)(&stack0x000009c0 + lVar14) = 0;
                    *(undefined2 *)(&stack0x000009aa + lVar14) = 0;
                    *(undefined2 *)(&stack0x000009c2 + lVar14) = 0;
                    *(undefined2 *)(&stack0x000009c4 + lVar14) = 0;
                    *(undefined2 *)(&stack0x000009c6 + lVar14) = 0;
                    *(undefined2 *)(&stack0x000009c8 + lVar14) = 0;
                    *(undefined2 *)(&stack0x000009ca + lVar14) = 0;
                    *(undefined2 *)(&stack0x000009cc + lVar14) = 0;
                    *(undefined2 *)(&stack0x000009ce + lVar14) = 0;
                    *(undefined8 *)(&stack0x000009b8 + lVar14) = 0;
                    *(undefined4 *)(&stack0x000009d8 + lVar14) = 0;
                    *(undefined8 *)(&stack0x000009d0 + lVar14) = 0;
                    *(byte **)(&stack0x000009b0 + lVar14) = pbVar38;
                    *(undefined4 *)(&stack0x000009ac + lVar14) = 9;
                    *(undefined4 *)(&stack0x000009d8 + lVar14) = 0;
                  }
                  *(longlong *)(&stack0x000009d0 + lVar14) = lVar36 + 0x2000;
                  *(byte ***)(&stack0x000009b8 + lVar14) = ppbVar31;
                  lVar15 = lVar36;
                }
                if (*(short *)(&stack0x000009a8 + lVar14) == 0) {
                  bVar23 = **(byte **)(&stack0x000009b0 + lVar14) >> 6;
                }
                else {
                  bVar23 = **(byte **)(&stack0x000009b0 + lVar14) >> 1;
                }
                if ((bVar23 & 1) == 0) {
                  sVar10 = (bVar23 & 1) - 1;
                  ppbVar41 = (byte **)(ulonglong)(iVar12 + 1U);
                  *(uint *)(&stack0x00000180 + lVar14) = iVar12 + 1U;
                }
                else {
                  *(undefined4 *)(&stack0x00000228 + lVar14) =
                       **(undefined4 **)(&stack0x00000230 + lVar14);
                  *(undefined2 *)(&stack0x0000022c + lVar14) =
                       *(undefined2 *)(*(undefined4 **)(&stack0x00000230 + lVar14) + 1);
                  *(short *)(&stack0x0000022e + lVar14) = (short)ppbVar41;
                  *(undefined8 *)((longlong)alStackX_18 + lVar14) =
                       *(undefined8 *)(&stack0x00000068 + lVar14);
                  *(undefined8 *)((longlong)alStackX_8 + lVar14 + 8) =
                       *(undefined8 *)(&stack0x00000138 + lVar14);
                  *(undefined *)((longlong)alStackX_8 + lVar14) = 0;
                  cVar7 = (&stack0x00002c60)[lVar14];
                  *(char *)((longlong)alStackX_18 + lVar14 + -0x18) = cVar7;
                  *(undefined8 *)(&stack0xfffffffffffffff8 + lVar14) =
                       *(undefined8 *)(&stack0x00000118 + lVar14);
                  *(undefined **)(&stack0xfffffffffffffff0 + lVar14) = &stack0x00000228 + lVar14;
                  *(longlong *)(&stack0xffffffffffffffe8 + lVar14) = lVar15;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102e57;
                  iVar39 = FUN_(*(undefined8 *)(&stack0x00000028 + lVar14),
                                        *(undefined8 *)(&stack0x00000110 + lVar14),
                                        *(undefined8 *)(&stack0x00000140 + lVar14));
                  if (iVar39 == 3) {
                    if (cVar7 == '\0') {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102e84;
                      (*_DAT_)(1,0x16fdbc8,0x16cd4b8,0x14b5);
                    }
                    (&stack0x00000030)[lVar14] = 0;
                    *(undefined4 *)(&stack0x00000038 + lVar14) = 3;
                    goto LAB_;
                  }
                  if (iVar39 == 2) {
                    (&stack0x00000030)[lVar14] = 0;
                    *(undefined4 *)(&stack0x00000038 + lVar14) = 2;
                    goto LAB_;
                  }
                  ppbVar31 = *(byte ***)(&stack0x000009b8 + lVar14);
                  lVar15 = *(longlong *)(&stack0x00000060 + lVar14);
                  sVar10 = -1;
                  ppbVar41 = (byte **)(ulonglong)(iVar12 + 1U);
                  *(uint *)(&stack0x00000180 + lVar14) = iVar12 + 1U;
                }
              }
            }
          }
          else if ((&stack0x00000050)[lVar14] != '\0') goto LAB_;
          if ((&stack0x00000030)[lVar14] != '\0') {
            bVar23 = (&stack0x00000080)[lVar14];
            (&stack0x00000080)[lVar14] = bVar23 & 0xfe;
            (&stack0x00000080)[lVar14] = bVar23 & 0xfc;
            bVar29 = 0;
            lVar15 = *(longlong *)(&stack0x00000140 + lVar14);
            if (*(int *)(lVar15 + 0x38) == 3) {
              bVar29 = 4;
            }
            (&stack0x00000080)[lVar14] = bVar29 | bVar23 & 0xf8;
            bVar23 = *(byte *)(lVar15 + 0x78);
            uVar19 = *(undefined8 *)(lVar15 + 0x58);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102f5c;
            func_0x(&stack0x00000070 + lVar14,uVar19,bVar23 >> 5 & 1);
            uVar19 = *(undefined8 *)(lVar15 + 0x58);
            uVar25 = *(undefined8 *)(&stack0x00000028 + lVar14);
            uVar4 = *(undefined8 *)(&stack0x00000110 + lVar14);
            if ((&stack0x00000034)[lVar14] == '\0') {
              *(undefined4 *)(&stack0x000008a8 + lVar14) =
                   *(undefined4 *)(&stack0x00000070 + lVar14);
              *(undefined4 *)(&stack0x000008ac + lVar14) =
                   *(undefined4 *)(&stack0x00000074 + lVar14);
              *(undefined4 *)(&stack0x000008b0 + lVar14) =
                   *(undefined4 *)(&stack0x00000078 + lVar14);
              *(undefined4 *)(&stack0x000008b4 + lVar14) =
                   *(undefined4 *)(&stack0x0000007c + lVar14);
              *(undefined8 *)(&stack0x000008b8 + lVar14) =
                   *(undefined8 *)(&stack0x00000080 + lVar14);
              *(undefined **)((longlong)alStackX_18 + lVar14) = &stack0x000008a8 + lVar14;
              *(undefined8 *)((longlong)alStackX_8 + lVar14 + 8) =
                   *(undefined8 *)(&stack0x00000a70 + lVar14);
              *(uint *)((longlong)alStackX_8 + lVar14) = uVar26;
              *(undefined4 *)((longlong)alStackX_18 + lVar14 + -0x18) =
                   *(undefined4 *)(&stack0x00000098 + lVar14);
              *(undefined4 *)(&stack0xfffffffffffffff8 + lVar14) = 0;
              *(undefined4 *)(&stack0xfffffffffffffff0 + lVar14) =
                   *(undefined4 *)(&stack0x00000058 + lVar14);
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10303e;
              func_0x
                        (*(undefined8 *)(&stack0x00000068 + lVar14),uVar19,uVar4,uVar25);
              *(longlong *)(*(longlong *)(&stack0x00000148 + lVar14) + 0x200) =
                   *(longlong *)(*(longlong *)(&stack0x00000148 + lVar14) + 0x200) + 1;
              *(undefined4 *)(&stack0x00000038 + lVar14) = 4;
            }
            else {
              *(undefined4 *)(&stack0x00000888 + lVar14) =
                   *(undefined4 *)(&stack0x00000070 + lVar14);
              *(undefined4 *)(&stack0x0000088c + lVar14) =
                   *(undefined4 *)(&stack0x00000074 + lVar14);
              *(undefined4 *)(&stack0x00000890 + lVar14) =
                   *(undefined4 *)(&stack0x00000078 + lVar14);
              *(undefined4 *)(&stack0x00000894 + lVar14) =
                   *(undefined4 *)(&stack0x0000007c + lVar14);
              *(undefined8 *)(&stack0x00000898 + lVar14) =
                   *(undefined8 *)(&stack0x00000080 + lVar14);
              *(undefined **)(&stack0xfffffffffffffff8 + lVar14) = &stack0x00000a68 + lVar14;
              *(undefined **)(&stack0xfffffffffffffff0 + lVar14) = &stack0x00000888 + lVar14;
              *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) =
                   *(undefined4 *)(&stack0x00000058 + lVar14);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102fc8;
              func_0x(*(undefined8 *)(&stack0x00000068 + lVar14));
              *(longlong *)(*(longlong *)(&stack0x00000148 + lVar14) + 0x200) =
                   *(longlong *)(*(longlong *)(&stack0x00000148 + lVar14) + 0x200) + 1;
              *(undefined4 *)(&stack0x00000038 + lVar14) = 4;
            }
          }
        }
        else {
LAB_:
          (&stack0x00000031)[lVar14] = 1;
LAB_:
          if ((&stack0x00000034)[lVar14] == '\0') {
            lVar15 = *(longlong *)(&stack0x00000140 + lVar14);
            *(undefined8 *)(&stack0x00000250 + lVar14) = *(undefined8 *)(lVar15 + 0x58);
            *(undefined **)(&stack0x00000728 + lVar14) = &stack0x00000268 + lVar14;
            *(undefined4 *)(&stack0x00000268 + lVar14) = 0;
            *(undefined2 *)(&stack0x0000026c + lVar14) = 0;
            *(undefined4 *)(&stack0x00000270 + lVar14) = 0;
            *(undefined **)(&stack0x00000730 + lVar14) = &stack0x00000274 + lVar14;
            *(undefined4 *)(&stack0x00000274 + lVar14) = 0;
            *(undefined2 *)(&stack0x00000278 + lVar14) = 0;
            *(undefined2 *)(&stack0x0000027a + lVar14) = 0;
            *(undefined8 *)(&stack0x00000280 + lVar14) = 0;
            *(undefined8 *)(&stack0x00000288 + lVar14) = 0x78;
            *(undefined8 *)(&stack0x00000290 + lVar14) = 0;
            *(undefined **)(&stack0x00000298 + lVar14) = &stack0x00000bb8 + lVar14;
            *(undefined **)(&stack0x000002a8 + lVar14) = &stack0x00000bbc + lVar14;
            (&stack0x000002b0)[lVar14] = 0;
            (&stack0x000002b1)[lVar14] = 0;
            (&stack0x000002b2)[lVar14] = 0;
            *(undefined **)(&stack0x000002a0 + lVar14) = &stack0x00000bb8 + lVar14;
            *(undefined2 *)(&stack0x00000278 + lVar14) = 0;
            *(undefined4 *)(&stack0x00000274 + lVar14) = 0;
            *(undefined **)(&stack0x00000738 + lVar14) = &stack0x00000bb8 + lVar14;
            (&stack0x00000bb8)[lVar14] = 0;
            (&stack0x00000bb9)[lVar14] = 0;
            (&stack0x00000bba)[lVar14] = 0;
            (&stack0x00000bbb)[lVar14] = 4;
            (&stack0x00000b18)[lVar14] = 0;
            *(undefined4 *)(&stack0x00000b1c + lVar14) = 0xffffffff;
            *(undefined4 *)(&stack0x00000b20 + lVar14) = 0;
            *(undefined (*) [16])(&stack0x00000b28 + lVar14) = ZEXT816(0);
            *(undefined4 *)(&stack0x00000b38 + lVar14) = 0;
            *(undefined8 *)(&stack0x00000b48 + lVar14) = 0;
            *(undefined4 *)(&stack0x00000b50 + lVar14) = 0;
            *(undefined8 *)(&stack0x00000b58 + lVar14) = 0;
            (&stack0x000009a6)[lVar14] = 1;
            *(undefined4 *)(&stack0x00000b74 + lVar14) = 0;
            (&stack0x00000b78)[lVar14] = 0;
            *(undefined **)(&stack0x00000740 + lVar14) = &stack0x00000b80 + lVar14;
            *(undefined8 *)(&stack0x00000b80 + lVar14) = 0;
            lVar36 = *(longlong *)(&stack0x00000148 + lVar14);
            uVar11 = *(undefined2 *)(lVar36 + 0x6b8);
            *(undefined2 *)(&stack0x000001d4 + lVar14) = uVar11;
            (&stack0x00000b18)[lVar14] = 5;
            *(longlong **)(&stack0x00000b28 + lVar14) = param_1 + 7;
            *(undefined4 *)(&stack0x00000b20 + lVar14) = 0x2000000;
            (&stack0x000009a6)[lVar14] = 9;
            *(undefined2 *)(&stack0x000009a4 + lVar14) = uVar11;
            *(undefined4 *)(&stack0x000009a0 + lVar14) = 0;
            *(undefined **)(&stack0x00000748 + lVar14) = &stack0x00000998 + lVar14;
            puVar5 = *(undefined4 **)(&stack0x00000230 + lVar14);
            *(undefined4 **)(&stack0x00000750 + lVar14) = puVar5;
            *(undefined **)(&stack0x00000758 + lVar14) = &stack0x00000998 + lVar14;
            *(undefined4 *)(&stack0x00000998 + lVar14) = *puVar5;
            *(undefined2 *)(&stack0x0000099c + lVar14) = *(undefined2 *)(puVar5 + 1);
            *(undefined2 *)(&stack0x0000099e + lVar14) = *(undefined2 *)((longlong)puVar5 + 6);
            *(undefined4 *)(&stack0x00000b1c + lVar14) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1032a2;
            iVar12 = func_0x
                               (&stack0x00000b18 + lVar14,&stack0x00000998 + lVar14,
                                &stack0x00000b68 + lVar14,0);
            *(int *)(&stack0x00000370 + lVar14) = iVar12;
            if (iVar12 < 0) {
              if ((&stack0x00002c60)[lVar14] == '\0') {
                *(undefined4 *)(&stack0x00000b1c + lVar14) = 0xffffffff;
                uVar19 = *(undefined8 *)(&stack0x00000068 + lVar14);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1032e2;
                func_0x(uVar19);
                cVar7 = (&stack0x000009a6)[lVar14];
                if (cVar7 == '\x05') {
                  iVar12 = *(int *)(&stack0x0000099c + lVar14);
joined_r0x00103373:
                  if (iVar12 != 0) goto LAB_;
LAB_:
                  if (_DAT_ == 0) goto LAB_;
                  if (cVar7 == '\x02') {
                    uVar26 = (uint)*(byte *)((ulonglong)(byte)(&stack0x00000b18)[lVar14] + 0x1c844a0
                                            );
                  }
                  else {
                    uVar26 = *(uint *)((ulonglong)(byte)(&stack0x00000b18)[lVar14] * 0x14 +
                                      0x1c84ae0);
                  }
                  *(uint *)(&stack0x00000374 + lVar14) = uVar26;
                  if (uVar26 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1034f5;
                    iVar12 = func_0x
                                       (&stack0x00000b18 + lVar14,&stack0x00000998 + lVar14,
                                        &stack0x00000b68 + lVar14);
                  }
                  else {
                    *(undefined **)(&stack0x00000760 + lVar14) = &stack0x00000b68 + lVar14;
                    *(longlong *)(&stack0x00000768 + lVar14) =
                         *(longlong *)(&stack0x00000b28 + lVar14);
                    *(undefined4 *)(&stack0x00000b9c + lVar14) = 0;
                    (&stack0x00000ba0)[lVar14] = 0;
                    *(undefined **)(&stack0x00000770 + lVar14) = &stack0x00000ba8 + lVar14;
                    *(undefined8 *)(&stack0x00000ba8 + lVar14) = 0;
                    *(undefined **)(&stack0x00000778 + lVar14) = &stack0x00000b68 + lVar14;
                    uVar13 = *(undefined4 *)(*(longlong *)(&stack0x00000b28 + lVar14) + 0x7c);
                    *(undefined4 *)(&stack0x00000378 + lVar14) = uVar13;
                    if (cVar7 == '\x02') {
                      *(undefined **)(&stack0x00000790 + lVar14) = &stack0x00000998 + lVar14;
LAB_:
                      *(undefined4 *)(&stack0x000009a0 + lVar14) = uVar13;
                    }
                    else {
                      if (cVar7 == '\x05') {
                        *(undefined **)(&stack0x00000788 + lVar14) = &stack0x00000998 + lVar14;
                        goto LAB_;
                      }
                      if (cVar7 == '\v') {
                        *(undefined **)(&stack0x00000780 + lVar14) = &stack0x00000998 + lVar14;
                        *(short *)(&stack0x000009a2 + lVar14) = (short)uVar13;
                      }
                    }
                    *(uint *)(&stack0x00000b50 + lVar14) =
                         *(uint *)(&stack0x00000b50 + lVar14) | 0x20;
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103497;
                    iVar12 = func_0x
                                       (&stack0x00000b18 + lVar14,&stack0x00000998 + lVar14,
                                        &stack0x00000b68 + lVar14,0);
                    *(int *)(&stack0x00000184 + lVar14) = iVar12;
                    *(uint *)(&stack0x00000b50 + lVar14) =
                         *(uint *)(&stack0x00000b50 + lVar14) & 0xffffffdf;
                    if (iVar12 == -5) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1034cc;
                      iVar12 = func_0x
                                         (&stack0x00000b18 + lVar14,&stack0x00000998 + lVar14,
                                          &stack0x00000b68 + lVar14);
                      *(int *)(&stack0x00000184 + lVar14) = iVar12;
                    }
                  }
                }
                else {
                  if (cVar7 == '\v') {
                    if (DAT_ != '\0') goto LAB_;
                  }
                  else if (cVar7 == '\x02') {
                    iVar12 = *(int *)(&stack0x00000998 + lVar14);
                    goto joined_r0x00103373;
                  }
LAB_:
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103319;
                  iVar12 = func_0x
                                     (&stack0x00000b18 + lVar14,&stack0x00000998 + lVar14,
                                      &stack0x00000b68 + lVar14,0);
                  *(int *)(&stack0x00000380 + lVar14) = iVar12;
                }
                *(int *)(&stack0x0000009c + lVar14) = iVar12;
                if (iVar12 < 0) {
                  if (iVar12 != -1) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103347;
                    func_0x(*(undefined4 *)(&stack0x0000009c + lVar14),0x19);
                  }
                  *(undefined4 *)(&stack0x00000038 + lVar14) = 3;
                }
                else {
                  (&stack0xfffffffffffffff8)[lVar14] = 1;
                  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar14) = 0;
                  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103523;
                  func_0x(uVar19,4,0xffffffff,&stack0x00000428 + lVar14);
                  *(undefined4 *)(&stack0x00000038 + lVar14) = 2;
                }
              }
              else {
                *(undefined4 *)(&stack0x00000038 + lVar14) = 3;
              }
            }
            else {
              if (*(int *)(&stack0x00000038 + lVar14) != 0) goto LAB_;
              lVar18 = *(longlong *)(&stack0x00000250 + lVar14);
              plVar28 = *(longlong **)(*(longlong *)(lVar18 + 8) + 0x488);
              if (((plVar28 != (longlong *)0x0) &&
                  (cVar7 = *_DAT_, (&stack0x000000ad)[lVar14] = cVar7, cVar7 != '\0')) &&
                 ((&stack0x000000c8)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) == 0)) {
                *(longlong **)(&stack0x000003c8 + lVar14) = plVar28;
                *(undefined8 *)(&stack0x00000798 + lVar14) = 1;
                *(longlong **)(&stack0x000007a0 + lVar14) = plVar28;
                if (plVar28[1] == 0) {
LAB_:
                  plVar28 = (longlong *)(*plVar28 + 8);
                  *(longlong **)(&stack0x000007c8 + lVar14) = plVar28;
                  LOCK();
                  lVar22 = *plVar28;
                  *plVar28 = *plVar28 + 1;
                  UNLOCK();
                  *(longlong *)(&stack0x000007d0 + lVar14) = lVar22 + 1;
                }
                else {
                  *(undefined4 *)(&stack0x00000384 + lVar14) = 0x58;
                  lVar22 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  *(longlong *)(&stack0x000007a8 + lVar14) = lVar22;
                  lVar33 = (ulonglong)*_DAT_ +
                           *(longlong *)(lVar22 + (ulonglong)*_DAT_ * 8);
                  *(longlong *)(&stack0x000007b0 + lVar14) = lVar33;
                  lVar22 = *(longlong *)(lVar33 + 0x100);
                  *(longlong *)(&stack0x000003c0 + lVar14) = lVar22;
                  if (lVar22 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103604;
                    (*_DAT_)(0);
                    lVar22 = *(longlong *)(lVar33 + 0x100);
                    *(longlong *)(&stack0x000003c0 + lVar14) = lVar22;
                  }
                  lVar22 = *(longlong *)(lVar22 + 0x260);
                  *(longlong *)(&stack0x000007b8 + lVar14) = lVar22;
                  if (lVar22 == 0) {
                    uVar45 = 0;
                  }
                  else {
                    uVar45 = (ulonglong)*(uint *)(lVar22 + 0xe68);
                  }
                  uVar26 = (uint)uVar45;
                  *(uint *)(&stack0x00000388 + lVar14) = uVar26;
                  *(uint *)(&stack0x00000400 + lVar14) = uVar26;
                  if (*(uint *)(_DAT_ + 8) <= uVar26) {
                    plVar28 = *(longlong **)(&stack0x000003c8 + lVar14);
                    goto LAB_;
                  }
                  lVar22 = *(longlong *)(plVar28[1] + uVar45 * 8);
                  *(longlong *)(&stack0x000007c0 + lVar14) = lVar22;
                  *(longlong *)(lVar22 + 8) = *(longlong *)(lVar22 + 8) + 1;
                }
                *(undefined8 *)(&stack0x00000028 + lVar14) =
                     *(undefined8 *)(&stack0x00000048 + lVar14);
              }
              if (*(int *)(&stack0x00000b74 + lVar14) != 0) {
                lVar22 = *(longlong *)(*(longlong *)(lVar18 + 8) + 0x488);
                if (((lVar22 != 0) &&
                    (cVar7 = *_DAT_, (&stack0x00000088)[lVar14] = cVar7, cVar7 != '\0')) &&
                   ((&stack0x00000089)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) == 0)) {
                  *(longlong *)(&stack0x000007d8 + lVar14) = lVar22;
                  *(undefined8 *)(&stack0x000007e0 + lVar14) = 0x16;
                  plVar28 = (longlong *)(lVar22 + 0x18);
                  *(longlong **)(&stack0x000003d8 + lVar14) = plVar28;
                  if (*(longlong *)(lVar22 + 0x20) == 0) {
LAB_:
                    plVar28 = (longlong *)(*plVar28 + 0xb0);
                    *(longlong **)(&stack0x00000808 + lVar14) = plVar28;
                    LOCK();
                    lVar22 = *plVar28;
                    *plVar28 = *plVar28 + 1;
                    UNLOCK();
                    *(longlong *)(&stack0x00000810 + lVar14) = lVar22 + 1;
                  }
                  else {
                    *(undefined4 *)(&stack0x00000404 + lVar14) = 0x58;
                    lVar33 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                    *(longlong *)(&stack0x000007e8 + lVar14) = lVar33;
                    lVar34 = (ulonglong)*_DAT_ +
                             *(longlong *)(lVar33 + (ulonglong)*_DAT_ * 8);
                    *(longlong *)(&stack0x000007f0 + lVar14) = lVar34;
                    lVar33 = *(longlong *)(lVar34 + 0x100);
                    *(longlong *)(&stack0x000003d0 + lVar14) = lVar33;
                    if (lVar33 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10377a;
                      (*_DAT_)(0);
                      lVar33 = *(longlong *)(lVar34 + 0x100);
                      *(longlong *)(&stack0x000003d0 + lVar14) = lVar33;
                    }
                    lVar33 = *(longlong *)(lVar33 + 0x260);
                    *(longlong *)(&stack0x000007f8 + lVar14) = lVar33;
                    if (lVar33 == 0) {
                      uVar45 = 0;
                    }
                    else {
                      uVar45 = (ulonglong)*(uint *)(lVar33 + 0xe68);
                    }
                    uVar26 = (uint)uVar45;
                    *(uint *)(&stack0x00000408 + lVar14) = uVar26;
                    *(uint *)(&stack0x0000040c + lVar14) = uVar26;
                    if (*(uint *)(_DAT_ + 8) <= uVar26) {
                      plVar28 = *(longlong **)(&stack0x000003d8 + lVar14);
                      goto LAB_;
                    }
                    lVar22 = *(longlong *)(*(longlong *)(lVar22 + 0x20) + uVar45 * 8);
                    *(longlong *)(&stack0x00000800 + lVar14) = lVar22;
                    *(longlong *)(lVar22 + 0xb0) = *(longlong *)(lVar22 + 0xb0) + 1;
                  }
                  *(undefined8 *)(&stack0x00000028 + lVar14) =
                       *(undefined8 *)(&stack0x00000048 + lVar14);
                }
                uVar45 = (ulonglong)*(uint *)(&stack0x00000b74 + lVar14);
                *(ulonglong *)(&stack0x000002c8 + lVar14) = uVar45;
                if (((uVar45 != 0) &&
                    (lVar18 = *(longlong *)(*(longlong *)(lVar18 + 8) + 0x488), lVar18 != 0)) &&
                   ((cVar7 = *_DAT_, (&stack0x0000008a)[lVar14] = cVar7, cVar7 != '\0' &&
                    ((&stack0x0000008b)[lVar14] = DAT_ >> 1, (DAT_ >> 1 & 1) == 0)))
                   ) {
                  *(longlong *)(&stack0x00000818 + lVar14) = lVar18;
                  *(undefined8 *)(&stack0x00000820 + lVar14) = 0x17;
                  plVar28 = (longlong *)(lVar18 + 0x18);
                  *(longlong **)(&stack0x000003e8 + lVar14) = plVar28;
                  if (*(longlong *)(lVar18 + 0x20) == 0) {
LAB_:
                    LOCK();
                    *(longlong *)(*plVar28 + 0xb8) = *(longlong *)(*plVar28 + 0xb8) + uVar45;
                    UNLOCK();
                  }
                  else {
                    *(undefined4 *)(&stack0x000002f4 + lVar14) = 0x58;
                    lVar22 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                    *(longlong *)(&stack0x00000828 + lVar14) = lVar22;
                    lVar33 = (ulonglong)*_DAT_ +
                             *(longlong *)(lVar22 + (ulonglong)*_DAT_ * 8);
                    *(longlong *)(&stack0x00000830 + lVar14) = lVar33;
                    lVar22 = *(longlong *)(lVar33 + 0x100);
                    *(longlong *)(&stack0x000003e0 + lVar14) = lVar22;
                    if (lVar22 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103902;
                      (*_DAT_)(0);
                      lVar22 = *(longlong *)(lVar33 + 0x100);
                      *(longlong *)(&stack0x000003e0 + lVar14) = lVar22;
                    }
                    lVar22 = *(longlong *)(lVar22 + 0x260);
                    *(longlong *)(&stack0x00000838 + lVar14) = lVar22;
                    if (lVar22 == 0) {
                      uVar45 = 0;
                    }
                    else {
                      uVar45 = (ulonglong)*(uint *)(lVar22 + 0xe68);
                    }
                    uVar26 = (uint)uVar45;
                    *(uint *)(&stack0x000002d8 + lVar14) = uVar26;
                    *(uint *)(&stack0x000001e4 + lVar14) = uVar26;
                    if (*(uint *)(_DAT_ + 8) <= uVar26) {
                      plVar28 = *(longlong **)(&stack0x000003e8 + lVar14);
                      uVar45 = *(ulonglong *)(&stack0x000002c8 + lVar14);
                      goto LAB_;
                    }
                    lVar18 = *(longlong *)(*(longlong *)(lVar18 + 0x20) + uVar45 * 8);
                    *(longlong *)(&stack0x00000840 + lVar14) = lVar18;
                    *(longlong *)(lVar18 + 0xb8) =
                         *(longlong *)(lVar18 + 0xb8) + *(longlong *)(&stack0x000002c8 + lVar14);
                  }
                  *(undefined8 *)(&stack0x00000028 + lVar14) =
                       *(undefined8 *)(&stack0x00000048 + lVar14);
                }
              }
              puVar6 = *(undefined **)(&stack0x00000298 + lVar14);
              *(undefined **)(&stack0x000002a0 + lVar14) = puVar6;
              *(undefined **)(&stack0x00000848 + lVar14) = puVar6;
              *puVar6 = 0;
              puVar6[1] = 0;
              puVar6[2] = 0;
              puVar6[3] = 4;
              *(longlong *)(&stack0x000002a8 + lVar14) =
                   *(longlong *)(&stack0x00000298 + lVar14) + 4;
              *(undefined8 *)(&stack0x00000290 + lVar14) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1039f1;
              uVar19 = func_0x(*(undefined8 *)(&stack0x00000250 + lVar14));
              *(undefined8 *)(&stack0x000003f0 + lVar14) = uVar19;
              bVar29 = 0;
              *(undefined *)(*(longlong *)(&stack0x000002a0 + lVar14) + 2) = 0;
              (&stack0x000002b2)[lVar14] = 1;
              *(undefined **)(&stack0xffffffffffffffe8 + lVar14) = &stack0x000003f0 + lVar14;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103a32;
              func_0x(&stack0x00000268 + lVar14,1,1,8);
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103a4d;
              func_0x(&stack0x00000268 + lVar14,1,2,0);
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar14) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103a69;
              func_0x(&stack0x00000268 + lVar14,2,3,0);
              bVar23 = (&stack0x000000b0)[lVar14];
              (&stack0x000000b0)[lVar14] = bVar23 & 0xfe;
              (&stack0x000000b0)[lVar14] = bVar23 & 0xfc;
              (&stack0x000000b0)[lVar14] = bVar23 & 0xf8;
              (&stack0x000000b0)[lVar14] = bVar23 & 0xf0;
              (&stack0x000000b0)[lVar14] = bVar23 & 0xe0;
              (&stack0x000000b0)[lVar14] = bVar23 & 0xc0;
              (&stack0x000000b1)[lVar14] = 0;
              (&stack0x000000b2)[lVar14] = 0;
              *(undefined8 *)(&stack0x000000b8 + lVar14) = 0;
              bVar23 = (&stack0x000000c0)[lVar14];
              (&stack0x000000c0)[lVar14] = bVar23 & 0xfe;
              (&stack0x000000c0)[lVar14] = bVar23 & 0xfc;
              (&stack0x000000c0)[lVar14] = bVar23 & 0xf8;
              (&stack0x000000c0)[lVar14] = bVar23 & 0xf0;
              bVar23 = bVar23 & 0xe0;
              (&stack0x000000c0)[lVar14] = bVar23;
              (&stack0x000000c0)[lVar14] = bVar23;
              (&stack0x000000c0)[lVar14] = bVar23;
              if (*(int *)(lVar15 + 0x38) == 3) {
                bVar29 = 4;
              }
              (&stack0x000000c0)[lVar14] = bVar29 | bVar23;
              bVar23 = *(byte *)(lVar15 + 0x78);
              uVar19 = *(undefined8 *)(lVar15 + 0x58);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103b44;
              func_0x(&stack0x000000b0 + lVar14,uVar19,bVar23 >> 5 & 1);
              (&stack0x000000c0)[lVar14] = (&stack0x000000c0)[lVar14] & 0xef;
              *(undefined4 *)(&stack0x000008e8 + lVar14) =
                   *(undefined4 *)(&stack0x000000b0 + lVar14);
              *(undefined4 *)(&stack0x000008ec + lVar14) =
                   *(undefined4 *)(&stack0x000000b4 + lVar14);
              *(undefined4 *)(&stack0x000008f0 + lVar14) =
                   *(undefined4 *)(&stack0x000000b8 + lVar14);
              *(undefined4 *)(&stack0x000008f4 + lVar14) =
                   *(undefined4 *)(&stack0x000000bc + lVar14);
              *(undefined8 *)(&stack0x000008f8 + lVar14) =
                   *(undefined8 *)(&stack0x000000c0 + lVar14);
              *(undefined **)(&stack0xfffffffffffffff8 + lVar14) = &stack0x000008e8 + lVar14;
              *(undefined4 *)(&stack0xfffffffffffffff0 + lVar14) =
                   *(undefined4 *)(&stack0x00000058 + lVar14);
              *(undefined **)(&stack0xffffffffffffffe8 + lVar14) = &stack0x00000268 + lVar14;
              uVar19 = *(undefined8 *)(lVar15 + 0x58);
              *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103bb1;
              func_0x(*(undefined8 *)(&stack0x00000068 + lVar14),uVar19,
                              *(undefined8 *)(&stack0x00000110 + lVar14),
                              *(undefined8 *)(&stack0x00000028 + lVar14));
              plVar28 = (longlong *)(lVar36 + 0x200);
              *plVar28 = *plVar28 + 1;
              *(undefined4 *)(&stack0x00000038 + lVar14) = 4;
            }
LAB_:
            plVar28 = *(longlong **)(&stack0x00000b48 + lVar14);
            if (plVar28 != (longlong *)0x0) {
              plVar27 = plVar28 + 1;
              LOCK();
              iVar12 = *(int *)plVar27;
              *(int *)plVar27 = *(int *)plVar27 + -1;
              UNLOCK();
              *(int *)(&stack0x000001dc + lVar14) = iVar12 + -1;
              if (iVar12 + -1 == 0) {
                if (plVar27 == (longlong *)0x0) {
                  plVar28 = (longlong *)0x0;
                }
                pcVar1 = *(code **)(*plVar28 + 8);
                *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103bf2;
                (*pcVar1)();
              }
            }
          }
          else {
            bVar23 = (&stack0x000000d0)[lVar14];
            (&stack0x000000d0)[lVar14] = bVar23 & 0xfe;
            (&stack0x000000d0)[lVar14] = bVar23 & 0xfc;
            (&stack0x000000d0)[lVar14] = bVar23 & 0xf8;
            (&stack0x000000d0)[lVar14] = bVar23 & 0xf0;
            (&stack0x000000d0)[lVar14] = bVar23 & 0xe0;
            (&stack0x000000d0)[lVar14] = bVar23 & 0xc0;
            (&stack0x000000d1)[lVar14] = 0;
            (&stack0x000000d2)[lVar14] = 0;
            *(undefined8 *)(&stack0x000000d8 + lVar14) = 0;
            bVar23 = (&stack0x000000e0)[lVar14];
            (&stack0x000000e0)[lVar14] = bVar23 & 0xfe;
            (&stack0x000000e0)[lVar14] = bVar23 & 0xfc;
            (&stack0x000000e0)[lVar14] = bVar23 & 0xf8;
            (&stack0x000000e0)[lVar14] = bVar23 & 0xf0;
            bVar23 = bVar23 & 0xe0;
            (&stack0x000000e0)[lVar14] = bVar23;
            (&stack0x000000e0)[lVar14] = bVar23;
            (&stack0x000000e0)[lVar14] = bVar23;
            bVar29 = 0;
            lVar15 = *(longlong *)(&stack0x00000140 + lVar14);
            if (*(int *)(lVar15 + 0x38) == 3) {
              bVar29 = 4;
            }
            (&stack0x000000e0)[lVar14] = bVar29 | bVar23;
            bVar23 = *(byte *)(lVar15 + 0x78);
            uVar19 = *(undefined8 *)(lVar15 + 0x58);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10220a;
            func_0x(&stack0x000000d0 + lVar14,uVar19,bVar23 >> 5 & 1);
            *(undefined4 *)(&stack0x000008c8 + lVar14) = *(undefined4 *)(&stack0x000000d0 + lVar14);
            *(undefined4 *)(&stack0x000008cc + lVar14) = *(undefined4 *)(&stack0x000000d4 + lVar14);
            *(undefined4 *)(&stack0x000008d0 + lVar14) = *(undefined4 *)(&stack0x000000d8 + lVar14);
            *(undefined4 *)(&stack0x000008d4 + lVar14) = *(undefined4 *)(&stack0x000000dc + lVar14);
            *(undefined8 *)(&stack0x000008d8 + lVar14) = *(undefined8 *)(&stack0x000000e0 + lVar14);
            *(undefined8 *)(&stack0xfffffffffffffff8 + lVar14) = 0;
            *(undefined **)(&stack0xfffffffffffffff0 + lVar14) = &stack0x000008c8 + lVar14;
            *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) =
                 *(undefined4 *)(&stack0x00000058 + lVar14);
            uVar19 = *(undefined8 *)(lVar15 + 0x58);
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x102265;
            func_0x(*(undefined8 *)(&stack0x00000068 + lVar14),uVar19,
                            *(undefined8 *)(&stack0x00000110 + lVar14),param_1);
            lVar15 = *(longlong *)(&stack0x00000148 + lVar14);
            plVar28 = (longlong *)(lVar15 + 0x200);
            *plVar28 = *plVar28 + 1;
            plVar28 = (longlong *)(lVar15 + 0x3d8);
            *plVar28 = *plVar28 + 1;
            *(undefined4 *)(&stack0x00000038 + lVar14) = 4;
          }
        }
LAB_:
        if (((&stack0x00002c68)[lVar14] != '\0') && (*(longlong *)(&stack0x00000258 + lVar14) == 0))
        {
          pcVar1 = *(code **)(**(longlong **)(&stack0x00000108 + lVar14) + 0x28);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103c15;
          (*pcVar1)();
        }
      }
    }
  }
  lVar36 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar15 = *(longlong *)(lVar36 + 0x100);
  if (lVar15 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103c47;
    (*_DAT_)();
    lVar15 = *(longlong *)(lVar36 + 0x100);
  }
  if (*(int *)(lVar15 + 0x22c) != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103c5d;
    (*_DAT_)();
  }
  puVar16 = *(undefined8 **)(&stack0x00000108 + lVar14);
  if (puVar16 != (undefined8 *)0x0) {
    pcVar1 = *(code **)*puVar16;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103c75;
    (*pcVar1)(puVar16,1);
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x103c89;
  func_0x
            (*(ulonglong *)(&stack0x00002bd8 + lVar14) ^
             (ulonglong)(&stack0xffffffffffffffc8 + lVar14));
  return;
}

