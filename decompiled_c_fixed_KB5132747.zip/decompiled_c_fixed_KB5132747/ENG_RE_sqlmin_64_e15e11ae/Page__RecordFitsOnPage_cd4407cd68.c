
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_(longlong param_1,short **param_2,uint param_3,uint param_4)

{
  ushort *puVar1;
  ushort *puVar2;
  byte bVar3;
  char cVar4;
  ushort uVar5;
  ushort uVar6;
  longlong lVar7;
  undefined8 uVar8;
  short *psVar9;
  ulonglong *puVar10;
  short sVar11;
  uint uVar12;
  uint uVar13;
  ulonglong uVar14;
  int iVar15;
  int iVar16;
  uint uVar17;
  uint uVar18;
  ulonglong uVar19;
  byte *pbVar20;
  ulonglong uVar21;
  short sVar22;
  ushort *puVar23;
  int iVar24;
  undefined auStackX_10 [8];
  uint uStackX_18;
  uint uStackX_20;
  
  uStackX_18 = param_3;
  uStackX_20 = param_4;
  if ((*(char *)(param_1 + 2) < '\0') &&
     (func_0x(param_2,param_1), *(char *)(param_1 + 2) < '\0')) {
    psVar9 = param_2[1];
  }
  else {
    psVar9 = *param_2;
  }
  uVar12 = *(uint *)(psVar9 + 2);
  uVar14 = (ulonglong)uVar12;
  puVar1 = (ushort *)(psVar9 + 1);
  iVar16 = 0;
  iVar24 = 0;
  if (*psVar9 == 0) {
    if (uVar12 == 0) {
      pbVar20 = *(byte **)(psVar9 + 4);
      uVar12 = *(uint *)(psVar9 + 8);
      uVar14 = (ulonglong)uVar12;
      *puVar1 = 0;
      *(uint *)(psVar9 + 10) = uVar12;
      bVar3 = *pbVar20;
      if ((bVar3 & 0x10) != 0) {
        uVar12 = uVar12 + 2 + (*(ushort *)(pbVar20 + uVar14) + 7 >> 3);
        uVar14 = (ulonglong)uVar12;
        *(uint *)(psVar9 + 10) = uVar12;
        bVar3 = *pbVar20;
      }
      if ((bVar3 & 0x20) == 0) {
        *(int *)(psVar9 + 2) = (int)uVar14;
        psVar9[0xe] = 0;
        *(int *)(psVar9 + 0xc) = (int)uVar14;
      }
      else {
        puVar23 = (ushort *)(pbVar20 + uVar14);
        uVar5 = *puVar23;
        psVar9[0xe] = uVar5;
        if (uVar5 == 0) {
          cVar4 = func_0x(0x1a46ca0);
          if (((cVar4 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
             (*(char *)(lVar7 + 0x499) != '\0')) {
            cVar4 = func_0x(0x1a46ca0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0x13366ac,0x1456798,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(psVar9 + 4),3);
          uVar14 = (ulonglong)*(uint *)(psVar9 + 10);
          uVar5 = psVar9[0xe];
        }
        uVar12 = (int)uVar14 + (uVar5 + 1) * 2;
        *(uint *)(psVar9 + 0xc) = uVar12;
        if (0x1f9e < uVar12) {
          cVar4 = func_0x(0x1a46ca0);
          if (((cVar4 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
             (*(char *)(lVar7 + 0x499) != '\0')) {
            cVar4 = func_0x(0x1a46ca0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x13366ac,0x1456798,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(psVar9 + 4),4);
          uVar5 = psVar9[0xe];
          uVar12 = *(uint *)(psVar9 + 0xc);
        }
        uVar14 = (ulonglong)uVar5;
        uVar5 = puVar23[uVar14];
        *(uint *)(psVar9 + 2) = uVar5 & 0x7fff;
        if ((uVar5 & 0x7fff) < uVar12) {
          cVar4 = func_0x(0x1a46ca0);
          if (((cVar4 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
             (*(char *)(lVar7 + 0x499) != '\0')) {
            cVar4 = func_0x(0x1a46ca0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x13366ac,0x1456798,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(psVar9 + 4),4);
          uVar12 = *(uint *)(psVar9 + 0xc);
          uVar14 = (ulonglong)(ushort)psVar9[0xe];
        }
        puVar2 = puVar23;
        iVar15 = iVar16;
        if ((short)uVar14 != 0) {
          do {
            uVar17 = puVar2[1] & 0x7fff;
            if ((uVar17 < uVar12) || (*(uint *)(psVar9 + 2) < uVar17)) {
              cVar4 = func_0x(0x1a46ca0);
              if ((cVar4 != '\0') &&
                 ((lVar7 = func_0x(), lVar7 != 0 &&
                  (*(char *)(lVar7 + 0x499) != '\0')))) {
                cVar4 = func_0x(0x1a46ca0);
                if (cVar4 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x13366ac,0x1456798,0x82a,0);
                }
              }
              func_0x(*(undefined8 *)(psVar9 + 4),4);
            }
            uVar14 = (ulonglong)(ushort)psVar9[0xe];
            iVar15 = iVar15 + 1;
            puVar2 = puVar2 + 1;
            uVar12 = uVar17;
          } while (iVar15 < (int)(uint)(ushort)psVar9[0xe]);
        }
        if ((short)puVar23[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
          pbVar20 = *(byte **)(psVar9 + 4);
          do {
            uVar12 = *(ushort *)(pbVar20 + uVar14 * 2 + (ulonglong)*(uint *)(psVar9 + 10)) & 0x7fff;
            if ((int)uVar14 == 1) {
              uVar17 = *(uint *)(psVar9 + 0xc);
              uVar18 = uVar17;
LAB_:
              if ((uVar12 < uVar17) || (uVar13 = *(uint *)(psVar9 + 2), uVar13 < uVar12))
              goto LAB_;
            }
            else {
              uVar18 = *(uint *)(psVar9 + 0xc);
              uVar17 = *(ushort *)(pbVar20 + uVar14 * 2 + ((ulonglong)*(uint *)(psVar9 + 10) - 2)) &
                       0x7fff;
              if (uVar18 <= uVar17) goto LAB_;
LAB_:
              func_0x(pbVar20,7);
              uVar18 = *(uint *)(psVar9 + 0xc);
              uVar13 = *(uint *)(psVar9 + 2);
            }
            uVar14 = (ulonglong)uVar13;
            if ((uVar17 < uVar18) || (uVar13 < uVar17)) goto LAB_;
            pbVar20 = *(byte **)(psVar9 + 4);
            if (*(ushort *)(pbVar20 + uVar17) == 5) {
              *puVar1 = *puVar1 | 2;
              psVar9[0xe] = psVar9[0xe] + -1;
              uVar21 = (ulonglong)(uVar17 & 0xffff);
              psVar9[0x15] = (short)uVar17;
              uVar14 = *(ulonglong *)(psVar9 + 4);
              uVar5 = psVar9[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar21 + 2 + uVar14) >> 0xe & 1) != 0) {
                uVar5 = *(ushort *)(uVar21 + 2 + uVar14) & 0x3800 | psVar9[0x16] & 0xc7ffU;
              }
              psVar9[0x16] = uVar5;
              uVar6 = (uVar5 ^ *(ushort *)(uVar21 + 2 + uVar14)) & 0x7ff ^ uVar5;
              psVar9[0x16] = uVar6;
              uVar19 = (ulonglong)((uVar6 & 0x7ff) * 2) + 4 + uVar14 + (uVar5 >> 0xb & 7) * 2 +
                       uVar21;
              if (uVar19 < uVar21 + uVar14) {
                func_0x(uVar21 + uVar14,0x19);
                uVar6 = psVar9[0x16];
                uVar21 = (ulonglong)(ushort)psVar9[0x15];
                uVar14 = (ulonglong)*(uint *)(psVar9 + 4);
              }
              if (uVar12 - uVar17 <
                  (((uVar6 & 0x7ff) * 2 - (int)uVar21) - (int)uVar14) + (int)uVar19) {
                func_0x(uVar21 + *(longlong *)(psVar9 + 4),0x19);
                uVar6 = psVar9[0x16];
              }
              if (((uVar6 & 0x3800) != 0) &&
                 (puVar23 = (ushort *)
                            (*(longlong *)(psVar9 + 4) + 4 + (ulonglong)(ushort)psVar9[0x15]),
                 iVar15 = iVar16, (uVar6 & 0x3800) != 0)) {
                do {
                  if ((uVar6 & 0x7ff) < (*puVar23 & 0x7ff)) {
                    func_0x((ulonglong)(ushort)psVar9[0x15] + *(longlong *)(psVar9 + 4),0x1a
                                   );
                    uVar6 = psVar9[0x16];
                  }
                  iVar15 = iVar15 + 1;
                  puVar23 = puVar23 + 1;
                } while (iVar15 < (int)(uVar6 >> 0xb & 7));
              }
              goto LAB_;
            }
            if (*(ushort *)(pbVar20 + uVar17) < 0x400) goto LAB_;
            *puVar1 = *puVar1 | 1;
            uVar5 = psVar9[0xe] - 1;
            psVar9[0xe] = uVar5;
            if (uVar5 == 0) goto LAB_;
            uVar14 = (ulonglong)uVar5;
          } while ((short)puVar23[(ulonglong)(uVar5 - 1) + 1] < 0);
          uVar14 = (ulonglong)*(uint *)(psVar9 + 2);
        }
        else {
LAB_:
          pbVar20 = *(byte **)(psVar9 + 4);
          uVar14 = (ulonglong)*(uint *)(psVar9 + 2);
        }
      }
      if ((*pbVar20 & 0x40) == 0) {
        *(undefined4 *)(psVar9 + 0x13) = 0;
      }
      else {
        *(int *)(psVar9 + 0x13) = (int)uVar14;
        *(int *)(psVar9 + 2) = (int)uVar14 + 0xe;
        uVar8 = func_0x(puVar1);
        func_0x(uVar8,auStackX_10);
        iVar15 = func_0x(auStackX_10);
        *(int *)(psVar9 + 2) = *(int *)(psVar9 + 2) + iVar15;
        uVar14 = (ulonglong)*(uint *)(psVar9 + 2);
      }
      if ((*(ulonglong *)(psVar9 + 0xf) != 0) &&
         (*(ulonglong *)(psVar9 + 0xf) < uVar14 + *(longlong *)(psVar9 + 4))) {
        cVar4 = func_0x(0x1a46ca0);
        if ((cVar4 != '\0') &&
           ((lVar7 = func_0x(), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0'))))
        {
          cVar4 = func_0x(0x1a46ca0);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0x13366ac,0x1456798,0x886,0);
          }
        }
        func_0x(*(undefined8 *)(psVar9 + 4),0x12);
        uVar14 = (ulonglong)*(uint *)(psVar9 + 2);
      }
      if (((uint)uVar14 == 0) || (0x3f3c < (uint)uVar14)) {
        cVar4 = func_0x(0x1a46ca0);
        if ((cVar4 != '\0') &&
           ((lVar7 = func_0x(), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0'))))
        {
          cVar4 = func_0x(0x1a46ca0);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0x13366ac,0x1456798,0x88b,0);
          }
        }
        func_0x(*(undefined8 *)(psVar9 + 4),5);
        uVar14 = (ulonglong)*(uint *)(psVar9 + 2);
      }
    }
LAB_:
    param_4 = uStackX_20;
    if (((uint)uVar14 < 9) &&
       (((**(byte **)(psVar9 + 4) & 0xe) == 0 || ((**(byte **)(psVar9 + 4) & 0xe) == 0xc)))) {
      uVar14 = 9;
    }
  }
  else {
    if (uVar12 == 0) {
      func_0x(puVar1);
      uVar14 = (ulonglong)*(uint *)(psVar9 + 2);
    }
    if (((uint)uVar14 < 9) &&
       (((**(byte **)(psVar9 + 4) & 0x1c) == 0 || ((**(byte **)(psVar9 + 4) & 0x1c) == 0xc)))) {
      uVar14 = 9;
    }
  }
  sVar22 = 9;
  sVar11 = 1 << ((byte)*(undefined2 *)(param_1 + 4) & 2);
  if (param_4 <= (ushort)((short)uVar14 + -1 + sVar11 & -sVar11)) {
    if (*(char *)(param_1 + 2) < '\0') {
      psVar9 = param_2[1];
    }
    else {
      psVar9 = *param_2;
    }
    puVar1 = (ushort *)(psVar9 + 1);
    uVar12 = *(uint *)(psVar9 + 2);
    if (*psVar9 == 0) {
      if (uVar12 == 0) {
        pbVar20 = *(byte **)(psVar9 + 4);
        uVar12 = *(uint *)(psVar9 + 8);
        uVar14 = (ulonglong)uVar12;
        *puVar1 = 0;
        *(uint *)(psVar9 + 10) = uVar12;
        bVar3 = *pbVar20;
        if ((bVar3 & 0x10) != 0) {
          uVar12 = uVar12 + 2 + (*(ushort *)(pbVar20 + uVar14) + 7 >> 3);
          uVar14 = (ulonglong)uVar12;
          *(uint *)(psVar9 + 10) = uVar12;
          bVar3 = *pbVar20;
        }
        if ((bVar3 & 0x20) == 0) {
          *(int *)(psVar9 + 2) = (int)uVar14;
          psVar9[0xe] = 0;
          *(int *)(psVar9 + 0xc) = (int)uVar14;
        }
        else {
          puVar23 = (ushort *)(pbVar20 + uVar14);
          uVar5 = *puVar23;
          psVar9[0xe] = uVar5;
          if (uVar5 == 0) {
            cVar4 = func_0x(0x1a46ca0);
            if (((cVar4 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
               (*(char *)(lVar7 + 0x499) != '\0')) {
              cVar4 = func_0x(0x1a46ca0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0x13366ac,0x1456798,0x80f,0);
              }
            }
            func_0x(*(undefined8 *)(psVar9 + 4),3);
            uVar14 = (ulonglong)*(uint *)(psVar9 + 10);
            uVar5 = psVar9[0xe];
          }
          uVar12 = (int)uVar14 + (uVar5 + 1) * 2;
          *(uint *)(psVar9 + 0xc) = uVar12;
          if (0x1f9e < uVar12) {
            cVar4 = func_0x(0x1a46ca0);
            if (((cVar4 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
               (*(char *)(lVar7 + 0x499) != '\0')) {
              cVar4 = func_0x(0x1a46ca0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x13366ac,0x1456798,0x816,0);
              }
            }
            func_0x(*(undefined8 *)(psVar9 + 4),4);
            uVar5 = psVar9[0xe];
            uVar12 = *(uint *)(psVar9 + 0xc);
          }
          uVar14 = (ulonglong)uVar5;
          uVar5 = puVar23[uVar14];
          *(uint *)(psVar9 + 2) = uVar5 & 0x7fff;
          if ((uVar5 & 0x7fff) < uVar12) {
            cVar4 = func_0x(0x1a46ca0);
            if (((cVar4 != '\0') && (lVar7 = func_0x(), lVar7 != 0)) &&
               (*(char *)(lVar7 + 0x499) != '\0')) {
              cVar4 = func_0x(0x1a46ca0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x13366ac,0x1456798,0x81d,0);
              }
            }
            func_0x(*(undefined8 *)(psVar9 + 4),4);
            uVar12 = *(uint *)(psVar9 + 0xc);
            uVar14 = (ulonglong)(ushort)psVar9[0xe];
          }
          puVar2 = puVar23;
          iVar15 = iVar16;
          if ((short)uVar14 != 0) {
            do {
              uVar17 = puVar2[1] & 0x7fff;
              if ((uVar17 < uVar12) || (*(uint *)(psVar9 + 2) < uVar17)) {
                cVar4 = func_0x(0x1a46ca0);
                if ((cVar4 != '\0') &&
                   ((lVar7 = func_0x(), lVar7 != 0 &&
                    (*(char *)(lVar7 + 0x499) != '\0')))) {
                  cVar4 = func_0x(0x1a46ca0);
                  if (cVar4 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    (*_DAT_)(1,0x13366ac,0x1456798,0x82a,0);
                  }
                }
                func_0x(*(undefined8 *)(psVar9 + 4),4);
              }
              uVar14 = (ulonglong)(ushort)psVar9[0xe];
              iVar15 = iVar15 + 1;
              puVar2 = puVar2 + 1;
              uVar12 = uVar17;
            } while (iVar15 < (int)(uint)(ushort)psVar9[0xe]);
          }
          if ((short)puVar23[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
            pbVar20 = *(byte **)(psVar9 + 4);
            do {
              uVar17 = *(ushort *)(pbVar20 + uVar14 * 2 + (ulonglong)*(uint *)(psVar9 + 10)) &
                       0x7fff;
              if ((int)uVar14 == 1) {
                uVar18 = *(uint *)(psVar9 + 0xc);
                uVar13 = uVar18;
LAB_:
                if ((uVar17 < uVar18) || (uVar12 = *(uint *)(psVar9 + 2), uVar12 < uVar17))
                goto LAB_;
              }
              else {
                uVar13 = *(uint *)(psVar9 + 0xc);
                uVar18 = *(ushort *)(pbVar20 + uVar14 * 2 + ((ulonglong)*(uint *)(psVar9 + 10) - 2))
                         & 0x7fff;
                if (uVar13 <= uVar18) goto LAB_;
LAB_:
                func_0x(pbVar20,7);
                uVar13 = *(uint *)(psVar9 + 0xc);
                uVar12 = *(uint *)(psVar9 + 2);
              }
              if ((uVar18 < uVar13) || (uVar12 < uVar18)) goto LAB_;
              pbVar20 = *(byte **)(psVar9 + 4);
              if (*(ushort *)(pbVar20 + uVar18) == 5) {
                *puVar1 = *puVar1 | 2;
                psVar9[0xe] = psVar9[0xe] + -1;
                uVar21 = (ulonglong)(uVar18 & 0xffff);
                psVar9[0x15] = (short)uVar18;
                uVar14 = *(ulonglong *)(psVar9 + 4);
                uVar5 = psVar9[0x16] & 0xc7ffU;
                if ((*(ushort *)(uVar21 + 2 + uVar14) >> 0xe & 1) != 0) {
                  uVar5 = *(ushort *)(uVar21 + 2 + uVar14) & 0x3800 | psVar9[0x16] & 0xc7ffU;
                }
                psVar9[0x16] = uVar5;
                uVar6 = (uVar5 ^ *(ushort *)(uVar21 + 2 + uVar14)) & 0x7ff ^ uVar5;
                psVar9[0x16] = uVar6;
                uVar19 = (ulonglong)((uVar6 & 0x7ff) * 2) + 4 + uVar14 + (uVar5 >> 0xb & 7) * 2 +
                         uVar21;
                if (uVar19 < uVar21 + uVar14) {
                  func_0x(uVar21 + uVar14,0x19);
                  uVar6 = psVar9[0x16];
                  uVar21 = (ulonglong)(ushort)psVar9[0x15];
                  uVar14 = (ulonglong)*(uint *)(psVar9 + 4);
                }
                if (uVar17 - uVar18 <
                    (((uVar6 & 0x7ff) * 2 - (int)uVar21) - (int)uVar14) + (int)uVar19) {
                  func_0x(uVar21 + *(longlong *)(psVar9 + 4),0x19);
                  uVar6 = psVar9[0x16];
                }
                if (((uVar6 & 0x3800) != 0) &&
                   (puVar23 = (ushort *)
                              (*(longlong *)(psVar9 + 4) + 4 + (ulonglong)(ushort)psVar9[0x15]),
                   (uVar6 & 0x3800) != 0)) {
                  do {
                    if ((uVar6 & 0x7ff) < (*puVar23 & 0x7ff)) {
                      func_0x((ulonglong)(ushort)psVar9[0x15] + *(longlong *)(psVar9 + 4),
                                      0x1a);
                      uVar6 = psVar9[0x16];
                    }
                    iVar16 = iVar16 + 1;
                    puVar23 = puVar23 + 1;
                  } while (iVar16 < (int)(uVar6 >> 0xb & 7));
                }
                goto LAB_;
              }
              if (*(ushort *)(pbVar20 + uVar18) < 0x400) goto LAB_;
              *puVar1 = *puVar1 | 1;
              uVar5 = psVar9[0xe] - 1;
              psVar9[0xe] = uVar5;
              if (uVar5 == 0) goto LAB_;
              uVar14 = (ulonglong)uVar5;
            } while ((short)puVar23[(ulonglong)(uVar5 - 1) + 1] < 0);
            uVar14 = (ulonglong)*(uint *)(psVar9 + 2);
          }
          else {
LAB_:
            pbVar20 = *(byte **)(psVar9 + 4);
            uVar14 = (ulonglong)*(uint *)(psVar9 + 2);
          }
        }
        if ((*pbVar20 & 0x40) == 0) {
          *(undefined4 *)(psVar9 + 0x13) = 0;
        }
        else {
          *(int *)(psVar9 + 0x13) = (int)uVar14;
          *(int *)(psVar9 + 2) = (int)uVar14 + 0xe;
          puVar10 = (ulonglong *)func_0x(puVar1);
          uVar6 = (ushort)(*puVar10 >> 0x30);
          uVar5 = uVar6;
          if ((((uint)(int)(short)uVar6 >> 1 ^ (int)(short)uVar6) & 0x2000) != 0) {
            uVar5 = uVar6 & 0xdfff;
            if ((uVar6 >> 0xe & 1) != 0) {
              uVar5 = uVar6 | 0x2000;
            }
          }
          if (uVar5 == 0xfffc) {
            iVar24 = (int)((*puVar10 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(psVar9 + 2) = *(int *)(psVar9 + 2) + iVar24;
          uVar14 = (ulonglong)*(uint *)(psVar9 + 2);
        }
        uVar12 = (uint)uVar14;
        if ((*(ulonglong *)(psVar9 + 0xf) != 0) &&
           (*(ulonglong *)(psVar9 + 0xf) < uVar14 + *(longlong *)(psVar9 + 4))) {
          cVar4 = func_0x(0x1a46ca0);
          if ((cVar4 != '\0') &&
             ((lVar7 = func_0x(), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0')))
             ) {
            cVar4 = func_0x(0x1a46ca0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              (*_DAT_)(1,0x13366ac,0x1456798,0x886,0);
            }
          }
          func_0x(*(undefined8 *)(psVar9 + 4),0x12);
          uVar12 = *(uint *)(psVar9 + 2);
        }
        if ((uVar12 == 0) || (0x3f3c < uVar12)) {
          cVar4 = func_0x(0x1a46ca0);
          if ((cVar4 != '\0') &&
             ((lVar7 = func_0x(), lVar7 != 0 && (*(char *)(lVar7 + 0x499) != '\0')))
             ) {
            cVar4 = func_0x(0x1a46ca0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              (*_DAT_)(1,0x13366ac,0x1456798,0x88b,0);
            }
          }
          func_0x(*(undefined8 *)(psVar9 + 4),5);
          uVar12 = *(uint *)(psVar9 + 2);
        }
      }
LAB_:
      if ((8 < uVar12) ||
         (((**(byte **)(psVar9 + 4) & 0xe) != 0 && ((**(byte **)(psVar9 + 4) & 0xe) != 0xc)))) {
        sVar22 = (short)uVar12;
      }
    }
    else {
      if (uVar12 == 0) {
        func_0x(puVar1);
        uVar12 = *(uint *)(psVar9 + 2);
      }
      if ((8 < uVar12) ||
         ((sVar22 = 9, (**(byte **)(psVar9 + 4) & 0x1c) != 0 &&
          ((**(byte **)(psVar9 + 4) & 0x1c) != 0xc)))) {
        sVar22 = (short)uVar12;
      }
    }
    sVar11 = 1 << ((byte)*(undefined2 *)(param_1 + 4) & 2);
    param_4 = (uint)(ushort)(sVar22 + -1 + sVar11 & -sVar11);
  }
  return param_4 <= uStackX_18;
}

