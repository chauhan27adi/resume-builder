
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,uint param_2,undefined8 param_3)

{
  byte *pbVar1;
  longlong lVar2;
  ushort *puVar3;
  undefined auVar4 [16];
  longlong **pplVar5;
  char cVar6;
  byte bVar7;
  short sVar8;
  uint uVar9;
  longlong lVar10;
  undefined8 uVar11;
  longlong lVar12;
  ushort uVar13;
  ulonglong uVar14;
  longlong lVar15;
  undefined4 uVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  byte *pbVar22;
  longlong lVar23;
  byte *pbVar24;
  undefined *puVar25;
  ulonglong uVar26;
  int iVar27;
  ushort *puVar28;
  undefined8 auStack_260 [5];
  longlong lStack_238;
  undefined auStack_230 [8];
  undefined4 auStack_228 [4];
  undefined8 auStack_218 [2];
  undefined auStack_208 [8];
  undefined8 uStack_200;
  undefined4 auStack_1f8 [2];
  undefined8 uStack_1f0;
  undefined4 auStack_1e8 [2];
  undefined8 uStack_1e0;
  undefined4 auStack_1d8 [2];
  undefined auStack_1d0 [8];
  undefined8 auStack_1c8 [2];
  undefined4 uStack_1b8;
  undefined2 uStack_1b4;
  uint auStack_1b0 [2];
  undefined8 uStack_1a8;
  undefined2 uStack_1a0;
  undefined8 uStack_198;
  longlong **pplStack_190;
  undefined2 uStack_188;
  undefined auStack_186 [2];
  undefined4 uStack_184;
  longlong lStack_180;
  undefined8 uStack_178;
  undefined8 uStack_16a;
  undefined8 uStack_160;
  undefined auStack_148 [12];
  undefined4 uStack_13c;
  undefined4 uStack_138;
  uint uStack_134;
  int iStack_130;
  longlong lStack_128;
  int iStack_120;
  longlong lStack_118;
  longlong lStack_110;
  longlong lStack_108;
  longlong lStack_100;
  short sStack_f8;
  ushort uStack_f6;
  uint uStack_f4;
  byte *pbStack_f0;
  undefined8 uStack_e8;
  undefined4 uStack_e0;
  ushort uStack_dc;
  undefined2 uStack_da;
  undefined6 uStack_d8;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  ushort uStack_ce;
  ushort uStack_cc;
  undefined2 uStack_ca;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [2];
  undefined auStack_ae [2];
  undefined auStack_ac [12];
  uint uStack_a0;
  undefined4 uStack_9c;
  short sStack_98;
  short sStack_96;
  short sStack_94;
  undefined2 uStack_92;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined2 uStack_88;
  undefined6 uStack_86;
  uint uStack_80;
  undefined4 uStack_7c;
  short *psStack_78;
  short *psStack_70;
  short sStack_68;
  undefined6 uStack_66;
  undefined auStack_60 [10];
  undefined auStack_56 [6];
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)&uStack_1b8;
  puVar25 = (undefined *)0x0;
  pbStack_f0 = (byte *)0x0;
  sStack_f8 = 0xffff;
  uStack_f4 = 0;
  uStack_da = 0;
  uStack_d8 = 0;
  uStack_d0 = 0;
  uStack_ce = 0;
  uStack_cc = 0;
  uStack_ca = 0;
  uVar16 = 0xf;
  uStack_e8 = (undefined *)0x0;
  uStack_188 = 0xffff;
  lStack_180 = 0;
  uStack_184 = 0;
  uStack_16a = 0;
  uStack_160 = 0;
  uStack_178 = 0;
  lVar10 = **param_1;
  uStack_c4 = 1;
  auStack_1b0[0] = param_2;
  uStack_198 = param_3;
  pplStack_190 = param_1;
  if (*(char *)(lVar10 + 2) < '\0') {
    pbVar24 = (byte *)(lVar10 + 0x60);
    puVar25 = auStack_c0;
    _auStack_ae = SUB1614(ZEXT816(0),2);
    auStack_b0 = (undefined  [2])0xffff;
    sStack_98 = 0;
    sStack_96 = 0;
    sStack_94 = 0;
    uStack_8a = 0;
    auStack_ac._4_8_ = 0;
    uStack_80 = 0;
    uStack_7c = 0;
    uStack_92 = 0;
    uStack_90 = 0;
    uStack_88 = 0;
    uStack_86 = 0;
    uStack_a0 = 0;
    uStack_9c = 0;
    psStack_78 = (short *)0x0;
    _auStack_60 = ZEXT812(0);
    auStack_56._2_4_ = 0;
    uStack_50 = 0;
    psStack_70 = (short *)0x0;
    sStack_68 = 0;
    uStack_66 = 0;
    auStack_c0 = ZEXT816(0);
    uVar11 = 0;
    if (*(short *)(lVar10 + 0x24) == 0) {
LAB_:
      auStack_c0._8_8_ = uVar11;
      uStack_1a8 = *(undefined8 *)(lVar10 + 0x28);
      uStack_1a0 = *(undefined2 *)(lVar10 + 0x30);
    }
    else {
      cVar6 = *(char *)(lVar10 + 1);
      if (cVar6 == '\v') {
        if (*(int *)(lVar10 + 0x18) != 99) {
LAB_:
          if (cVar6 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar6 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar10 + 0x18) != 99) goto LAB_;
      }
      uStack_1b8 = *(undefined4 *)(lVar10 + 0x20);
      uStack_1b4 = *(undefined2 *)(lVar10 + 0x24);
      auStack_260[0] = 0x100196;
      cVar6 = func_0x(&uStack_1b8,0x1061980);
      uVar11 = auStack_c0._8_8_;
      if (cVar6 == '\0') goto LAB_;
      auStack_260[0] = 0x1001a6;
      func_0x(lVar10,&uStack_1a8);
    }
    auStack_60._8_2_ = uStack_1a0;
    auStack_60._0_8_ = uStack_1a8;
    auStack_c0._0_8_ = pbVar24;
    auStack_56._2_4_ = *(undefined4 *)(lVar10 + 0x20);
    auStack_b0 = (undefined  [2])0xffff;
    uVar18 = 0;
    _auStack_b0 = _auStack_b0 & 0xffffffff;
    auStack_ac._4_8_ = 0;
    uStack_92 = 0;
    uStack_90 = 0;
    uStack_1b8 = *(undefined4 *)((ulonglong)*pbVar24 * 6 + 0x10e0260);
    uVar26 = (ulonglong)*(short *)((ulonglong)*pbVar24 * 6 + 0x10e0264);
    uStack_88 = 0;
    uStack_86 = 0;
    uStack_a0 = 0;
    uStack_9c = 0;
    psStack_78 = (short *)0x0;
    psStack_70 = (short *)0x0;
    sStack_68 = 0;
    uVar20 = uStack_a0;
    if ((*pbVar24 & 2) != 0) {
      pbVar1 = pbVar24 + uVar26;
      auStack_ac._4_8_ = pbVar1;
      if ((pbVar24[uVar26] & 1) == 0) {
        auVar4._14_2_ = 0;
        auVar4._0_14_ = _auStack_ae;
        _auStack_b0 = auVar4 << 0x10;
        uStack_8a = 0;
        uStack_88 = 0;
        uVar20 = uVar18;
        switch(*pbVar1 & 0xe) {
        default:
          uVar13 = *(ushort *)(pbVar1 + 2);
          uVar20 = (uint)uVar13;
          if (0x1f9d < uVar13 - 1) {
            auStack_260[0] = 0x10048b;
            func_0x(pbVar1,6);
          }
          break;
        case 4:
          uVar20 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar20 = 1;
        }
      }
      else {
        bVar7 = *pbVar1;
        switch(bVar7 & 0x1c) {
        default:
          if ((char)pbVar1[1] < '\0') {
            sStack_98 = 3;
            auStack_ae = (undefined  [2])
                         ((*(ushort *)(pbVar1 + 1) & 0x7f) << 8 | *(ushort *)(pbVar1 + 1) >> 8);
          }
          else {
            sStack_98 = 2;
            auStack_ae = (undefined  [2])(ushort)pbVar1[1];
          }
          auStack_b0 = (undefined  [2])0x1;
          sStack_94 = (short)((ushort)auStack_ae + 1 >> 1) + sStack_98;
          if ((ushort)auStack_ae < 0x1f) {
            uStack_80 = 0;
            sStack_96 = 0;
            uStack_88 = 0;
            uStack_86 = 0;
            uStack_a0 = 0;
            uStack_9c = 0;
            uVar20 = uStack_a0;
          }
          else {
            iVar27 = (ushort)auStack_ae - 1;
            uStack_80 = 0;
            uStack_88 = 0;
            uStack_86 = 0;
            uStack_a0 = 0;
            uStack_9c = 0;
            sStack_96 = ((short)(iVar27 / 0x1e) + (short)(iVar27 >> 0x1f)) -
                        (short)((longlong)iVar27 * 0x88888889 >> 0x3f);
            uVar20 = uStack_a0;
          }
          break;
        case 4:
          if (((bVar7 & 0x1c) == 4) && ((bVar7 & 2) != 0)) {
            uVar18 = 1;
          }
          else {
            uVar16 = 1;
          }
          sStack_98 = 0;
          sStack_96 = 0;
          sStack_94 = 0;
          uStack_8a = 0;
          auStack_ac._0_4_ = uVar16;
          _auStack_b0 = 1;
          uStack_88 = 0;
          uStack_86 = 0;
          uStack_a0 = 0;
          uStack_9c = 0;
          uVar20 = uStack_a0;
          uStack_80 = uVar18;
          break;
        case 8:
          sStack_98 = 0;
          sStack_96 = 0;
          sStack_94 = 0;
          uStack_8a = 0;
          _auStack_b0 = 0x900000001;
          uStack_80 = 0;
          uStack_88 = 0;
          uStack_86 = 0;
          uStack_a0 = 0;
          uStack_9c = 0;
          uVar20 = uStack_a0;
        }
      }
    }
    uStack_a0 = uVar20;
    uStack_90 = 0;
    uStack_92 = 0;
    if ((*(byte *)auStack_c0._0_8_ & 4) != 0) {
      if (uStack_1b8._2_2_ != 0) {
        uVar26 = (ulonglong)*(ushort *)(lVar10 + 0x61 + (longlong)uStack_1b8._2_2_ * 2);
      }
      psStack_78 = (short *)(pbVar24 + uVar26);
      psStack_70 = psStack_78 + 1;
      sStack_68 = (*psStack_78 + 1) * 2;
    }
    if (auStack_c0._8_8_ != 0) {
      auStack_260[0] = 0x100539;
      func_0x(auStack_c0._8_8_,auStack_c0);
    }
  }
  uVar20 = auStack_1b0[0];
  uVar18 = (uint)*(ushort *)(lVar10 + 0xe);
  pbStack_f0 = (byte *)((ulonglong)*(ushort *)(lVar10 + 0x1ffc) + lVar10);
  if ((*pbStack_f0 & 1) == 0) {
    sStack_f8 = 0;
    uStack_f4 = 0;
    uStack_d2 = 0;
    uStack_d0 = 0;
    switch(*pbStack_f0 & 0xe) {
    default:
      uVar18 = (uint)*(ushort *)(pbStack_f0 + 2);
      if (0x1f9d < *(ushort *)(pbStack_f0 + 2) - 1) {
        auStack_260[0] = 0x1007f7;
        func_0x(pbStack_f0,6);
      }
      break;
    case 4:
      uVar18 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar18 = 1;
    }
    uStack_e8 = (undefined *)CONCAT44(uStack_e8._4_4_,uVar18);
    puVar25 = (undefined *)(ulonglong)uVar18;
    uStack_da = (undefined2)(lVar10 + 0x2000);
    uStack_d8 = (undefined6)((ulonglong)(lVar10 + 0x2000) >> 0x10);
  }
  else {
    sStack_f8 = 1;
    bVar7 = *pbStack_f0;
    uStack_e8 = puVar25;
    switch(bVar7 & 0x1c) {
    default:
      if ((char)pbStack_f0[1] < '\0') {
        uStack_f6 = (*(ushort *)(pbStack_f0 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_f0 + 1) >> 8;
        uStack_e0._0_2_ = 3;
        sVar8 = 3;
      }
      else {
        uStack_f6 = (ushort)pbStack_f0[1];
        uStack_e0._0_2_ = 2;
        sVar8 = 2;
      }
      uStack_dc = ((ushort)(uStack_f6 + 1) >> 1) + sVar8;
      if (uStack_f6 < 0x1f) {
        uStack_e0._2_2_ = 0;
        lVar10 = lVar10 + 0x2000;
        uStack_f4 = 0;
        uStack_d0 = (undefined2)lVar10;
        uStack_ce = (ushort)((ulonglong)lVar10 >> 0x10);
        uStack_cc = (ushort)((ulonglong)lVar10 >> 0x20);
        uStack_ca = (undefined2)((ulonglong)lVar10 >> 0x30);
        uStack_c8 = 0;
      }
      else {
        iVar27 = uStack_f6 - 1;
        uStack_c8 = 0;
        uStack_f4 = 0;
        uStack_e0._2_2_ =
             ((short)(iVar27 / 0x1e) + (short)(iVar27 >> 0x1f)) -
             (short)((longlong)iVar27 * 0x88888889 >> 0x3f);
        lVar10 = lVar10 + 0x2000;
        uStack_d0 = (undefined2)lVar10;
        uStack_ce = (ushort)((ulonglong)lVar10 >> 0x10);
        uStack_cc = (ushort)((ulonglong)lVar10 >> 0x20);
        uStack_ca = (undefined2)((ulonglong)lVar10 >> 0x30);
      }
      break;
    case 4:
      if (((bVar7 & 0x1c) == 4) && ((bVar7 & 2) != 0)) {
        lVar10 = lVar10 + 0x2000;
        uStack_e0._0_2_ = 0;
        uStack_e0._2_2_ = 0;
        uStack_dc = 0;
        uStack_da = 0;
        uStack_d0 = (undefined2)lVar10;
        uStack_ce = (ushort)((ulonglong)lVar10 >> 0x10);
        uStack_cc = (ushort)((ulonglong)lVar10 >> 0x20);
        uStack_ca = (undefined2)((ulonglong)lVar10 >> 0x30);
        uStack_f6 = 0;
        uStack_d8 = 0;
        uStack_d2 = 0;
        uStack_f4 = 0xf;
        uStack_c8 = 1;
      }
      else {
        uStack_e0._0_2_ = 0;
        uStack_e0._2_2_ = 0;
        uStack_dc = 0;
        uStack_da = 0;
        lVar10 = lVar10 + 0x2000;
        uStack_f4 = 1;
        uStack_d0 = (undefined2)lVar10;
        uStack_ce = (ushort)((ulonglong)lVar10 >> 0x10);
        uStack_cc = (ushort)((ulonglong)lVar10 >> 0x20);
        uStack_ca = (undefined2)((ulonglong)lVar10 >> 0x30);
        uStack_f6 = 0;
        uStack_d8 = 0;
        uStack_d2 = 0;
        uStack_c8 = 0;
      }
      break;
    case 8:
      uStack_e0._0_2_ = 0;
      uStack_e0._2_2_ = 0;
      uStack_dc = 0;
      uStack_da = 0;
      lVar10 = lVar10 + 0x2000;
      uStack_f4 = 9;
      uStack_d0 = (undefined2)lVar10;
      uStack_ce = (ushort)((ulonglong)lVar10 >> 0x10);
      uStack_cc = (ushort)((ulonglong)lVar10 >> 0x20);
      uStack_ca = (undefined2)((ulonglong)lVar10 >> 0x30);
      uStack_f6 = 0;
      uStack_d8 = 0;
      uStack_d2 = 0;
      uStack_c8 = 0;
    }
  }
  if (sStack_f8 == 0) {
    pbVar24 = pbStack_f0;
    uVar18 = uStack_f4;
    uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0);
    if (uStack_f4 == 0) {
      uStack_f6 = 0;
      uVar17 = (uint)puVar25;
      if ((*pbStack_f0 & 0x10) != 0) {
        uVar17 = uVar17 + 2 + (*(ushort *)(pbStack_f0 + ((ulonglong)puVar25 & 0xffffffff)) + 7 >> 3)
        ;
      }
      uStack_e8 = (undefined *)CONCAT44(uVar17,(undefined4)uStack_e8);
      if ((*pbStack_f0 & 0x20) == 0) {
        uStack_dc = 0;
        uVar18 = uVar17;
        uStack_f4 = uVar17;
      }
      else {
        puVar28 = (ushort *)(pbStack_f0 + uVar17);
        uStack_dc = *puVar28;
        if (uStack_dc == 0) {
          auStack_260[0] = 0x1008cd;
          cVar6 = func_0x(0x19f6a10);
          if (cVar6 != '\0') {
            auStack_260[0] = 0x1008d6;
            lVar10 = func_0x();
            if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
              auStack_260[0] = 0x1008f0;
              cVar6 = func_0x(0x19f6a10);
              if (cVar6 == '\0') {
                auStack_260[0] = 0x10090c;
                (*pcRam0000000000f64598)(0x22,0x44,0x15,0x3eb);
              }
              else {
                lStack_238 = 0;
                auStack_260[0] = 0x100933;
                (*pcRam0000000000f64590)(1,0x12e641c,0x1406508,0x80f);
              }
            }
          }
          auStack_260[0] = 0x100944;
          func_0x(pbStack_f0,3);
        }
        uStack_e0 = uStack_e8._4_4_ + 2 + (uint)uStack_dc * 2;
        if (0x1f9e < uStack_e0) {
          auStack_260[0] = 0x100983;
          cVar6 = func_0x(0x19f6a10);
          if (cVar6 != '\0') {
            auStack_260[0] = 0x10098c;
            lVar10 = func_0x();
            if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
              auStack_260[0] = 0x1009a6;
              cVar6 = func_0x(0x19f6a10);
              if (cVar6 == '\0') {
                auStack_260[0] = 0x1009c2;
                (*pcRam0000000000f64598)(0x22,0x44,0x15,0x3ec);
              }
              else {
                lStack_238 = 0;
                auStack_260[0] = 0x1009e9;
                (*pcRam0000000000f64590)(1,0x12e641c,0x1406508,0x816);
              }
            }
          }
          auStack_260[0] = 0x1009fa;
          func_0x(pbStack_f0,4);
        }
        uVar26 = (ulonglong)uStack_dc;
        uStack_f4 = puVar28[uVar26] & 0x7fff;
        if (uStack_f4 < uStack_e0) {
          auStack_260[0] = 0x100a38;
          cVar6 = func_0x(0x19f6a10);
          if (cVar6 != '\0') {
            auStack_260[0] = 0x100a41;
            lVar10 = func_0x();
            if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
              auStack_260[0] = 0x100a5b;
              cVar6 = func_0x(0x19f6a10);
              if (cVar6 == '\0') {
                auStack_260[0] = 0x100a77;
                (*pcRam0000000000f64598)(0x22,0x44,0x15,0x3ec);
              }
              else {
                lStack_238 = 0;
                auStack_260[0] = 0x100a9e;
                (*pcRam0000000000f64590)(1,0x12e641c,0x1406508,0x81d);
              }
            }
          }
          auStack_260[0] = 0x100aaf;
          func_0x(pbStack_f0,4);
          uVar26 = (ulonglong)uStack_dc;
        }
        iVar27 = 0;
        pbVar24 = pbStack_f0;
        uVar18 = uStack_f4;
        puVar3 = puVar28;
        uVar9 = uStack_e0;
        uVar17 = uStack_e0;
        if ((short)uVar26 != 0) {
          do {
            uVar20 = puVar3[1] & 0x7fff;
            if ((uVar20 < uStack_e0) || (uVar18 < uVar20)) {
              auStack_260[0] = 0x100b12;
              uStack_e0 = uVar9;
              cVar6 = func_0x(0x19f6a10);
              if (cVar6 != '\0') {
                auStack_260[0] = 0x100b1b;
                lVar10 = func_0x();
                if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                  auStack_260[0] = 0x100b35;
                  cVar6 = func_0x(0x19f6a10);
                  if (cVar6 == '\0') {
                    auStack_260[0] = 0x100b51;
                    (*pcRam0000000000f64598)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    lStack_238 = 0;
                    auStack_260[0] = 0x100b75;
                    (*pcRam0000000000f64590)(1,0x12e641c,0x1406508,0x82a);
                  }
                }
              }
              auStack_260[0] = 0x100b86;
              func_0x(pbStack_f0,4);
              uVar26 = (ulonglong)uStack_dc;
              pbVar24 = pbStack_f0;
              uVar18 = uStack_f4;
              uVar9 = uStack_e0;
            }
            iVar27 = iVar27 + 1;
            puVar3 = puVar3 + 1;
            uStack_e0 = uVar20;
            uVar17 = uVar9;
            uVar20 = auStack_1b0[0];
          } while (iVar27 < (int)uVar26);
        }
        while( true ) {
          if (-1 < (short)puVar28[(ulonglong)((int)uVar26 - 1) + 1]) break;
          uVar21 = uVar9;
          if ((int)uVar26 != 1) {
            uVar21 = *(ushort *)(pbVar24 + uVar26 * 2 + (((ulonglong)uStack_e8 >> 0x20) - 2)) &
                     0x7fff;
          }
          uVar19 = *(ushort *)(pbVar24 + uVar26 * 2 + ((ulonglong)uStack_e8 >> 0x20)) & 0x7fff;
          if (((uVar21 < uVar9) || (uVar19 < uVar21)) || (uVar13 = (ushort)uVar26, uVar18 < uVar19))
          {
            auStack_260[0] = 0x100c2a;
            uStack_e0 = uVar17;
            func_0x(pbVar24,7);
            pbVar24 = pbStack_f0;
            uVar18 = uStack_f4;
            uVar13 = uStack_dc;
            uVar9 = uStack_e0;
            uVar17 = uStack_e0;
          }
          uStack_e0 = uVar17;
          if ((uVar21 < uVar9) || (uVar18 < uVar21)) goto code_r0x00100fe0;
          if (*(ushort *)(pbVar24 + uVar21) == 5) {
            uStack_f6 = uStack_f6 | 2;
            uStack_dc = uVar13 - 1;
            uVar26 = (ulonglong)(uVar21 & 0xffff);
            pbVar1 = pbVar24 + uVar26;
            uStack_ce = (ushort)uVar21;
            if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
              uVar13 = uStack_cc & 0xc7ff;
            }
            else {
              uVar13 = uStack_cc ^ (*(ushort *)(pbVar1 + 2) ^ uStack_cc) & 0x3800;
            }
            uStack_cc = (uVar13 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar13;
            pbVar22 = pbVar24 + uVar26 + (ulonglong)((uStack_cc & 0x7ff) * 2) + 4 +
                                         (ulonglong)((uVar13 >> 0xb & 7) * 2);
            if (pbVar22 < pbVar1) {
              auStack_260[0] = 0x100d40;
              func_0x(pbVar1,0x19);
              uVar26 = (ulonglong)uStack_ce;
              pbVar24 = pbStack_f0;
              uVar18 = uStack_f4;
            }
            uVar17 = uStack_e0;
            if (uVar19 - uVar21 <
                (((uStack_cc & 0x7ff) * 2 - (int)uVar26) - (int)pbStack_f0) + (int)pbVar22) {
              auStack_260[0] = 0x100d8b;
              func_0x(pbVar24 + uVar26,0x19);
              uVar26 = (ulonglong)uStack_ce;
              pbVar24 = pbStack_f0;
              uVar18 = uStack_f4;
              uVar17 = uStack_e0;
            }
            iVar27 = 0;
            if (((uStack_cc & 0x3800) != 0) &&
               (puVar28 = (ushort *)(pbVar24 + uVar26 + 4), uVar13 = uStack_cc,
               (uStack_cc & 0x3800) != 0)) {
              do {
                if ((uVar13 & 0x7ff) < (*puVar28 & 0x7ff)) {
                  auStack_260[0] = 0x100df6;
                  uStack_e0 = uVar17;
                  func_0x(pbVar24 + uVar26,0x1a);
                  uVar26 = (ulonglong)uStack_ce;
                  pbVar24 = pbStack_f0;
                  uVar13 = uStack_cc;
                  uVar17 = uStack_e0;
                }
                iVar27 = iVar27 + 1;
                puVar28 = puVar28 + 1;
                uVar18 = uStack_f4;
              } while (iVar27 < (int)((uStack_cc & 0x3800) >> 0xb));
            }
            break;
          }
          if (*(ushort *)(pbVar24 + uVar21) < 0x400) break;
          uStack_f6 = uStack_f6 | 1;
          uStack_dc = uVar13 - 1;
          uVar26 = (ulonglong)uStack_dc;
          if (uStack_dc == 0) break;
        }
      }
      if ((*pbVar24 & 0x40) == 0) {
        uStack_d2 = 0;
        uStack_d0 = 0;
      }
      else {
        uStack_d2 = (undefined2)uVar18;
        uStack_d0 = (undefined2)(uVar18 >> 0x10);
        uStack_f4 = uVar18 + 0xe;
        auStack_260[0] = 0x100e63;
        uStack_e0 = uVar17;
        uVar11 = func_0x(&uStack_f6);
        auStack_260[0] = 0x100e6f;
        func_0x(uVar11,auStack_1b0);
        auStack_260[0] = 0x100e78;
        iVar27 = func_0x(auStack_1b0);
        uVar18 = uStack_f4 + iVar27;
        pbVar24 = pbStack_f0;
        uStack_f4 = uVar18;
        uVar17 = uStack_e0;
      }
      uStack_e0 = uVar17;
      if (((byte *)CONCAT62(uStack_d8,uStack_da) != (byte *)0x0) &&
         ((byte *)CONCAT62(uStack_d8,uStack_da) < pbVar24 + uVar18)) {
        auStack_260[0] = 0x100ec0;
        cVar6 = func_0x(0x19f6a10);
        if (cVar6 != '\0') {
          auStack_260[0] = 0x100ec9;
          lVar10 = func_0x();
          if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
            auStack_260[0] = 0x100ee3;
            cVar6 = func_0x(0x19f6a10);
            if (cVar6 == '\0') {
              auStack_260[0] = 0x100eff;
              (*pcRam0000000000f64598)(0x22,0x44,0x15,0x3fa);
            }
            else {
              lStack_238 = 0;
              auStack_260[0] = 0x100f25;
              (*pcRam0000000000f64590)(1,0x12e641c,0x1406508,0x886);
            }
          }
        }
        auStack_260[0] = 0x100f36;
        func_0x(pbStack_f0,0x12);
        pbVar24 = pbStack_f0;
        uVar18 = uStack_f4;
      }
      if (0x3f3b < uVar18 - 1) {
        auStack_260[0] = 0x100f5d;
        cVar6 = func_0x(0x19f6a10);
        if (cVar6 != '\0') {
          auStack_260[0] = 0x100f66;
          lVar10 = func_0x();
          if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
            auStack_260[0] = 0x100f80;
            cVar6 = func_0x(0x19f6a10);
            if (cVar6 == '\0') {
              auStack_260[0] = 0x100f9c;
              (*pcRam0000000000f64598)(0x22,0x44,0x15,0x3ed);
            }
            else {
              lStack_238 = 0;
              auStack_260[0] = 0x100fc2;
              (*pcRam0000000000f64590)(1,0x12e641c,0x1406508,0x88b);
            }
          }
        }
        auStack_260[0] = 0x100fd3;
        func_0x(pbStack_f0,5);
        pbVar24 = pbStack_f0;
        uVar18 = uStack_f4;
      }
    }
code_r0x00100fe0:
    if (uVar18 < 9) {
      bVar7 = *pbVar24 & 0xe;
joined_r0x0010101a:
      uVar17 = 9;
      if ((bVar7 == 0) || (uVar17 = 9, bVar7 == 0xc)) goto code_r0x00101024;
    }
  }
  else {
    if (uStack_f4 == 0) {
      auStack_260[0] = 0x101001;
      func_0x(&uStack_f6);
    }
    uVar18 = uStack_f4;
    if (uStack_f4 < 9) {
      bVar7 = *pbStack_f0 & 0x1c;
      goto joined_r0x0010101a;
    }
  }
  uVar17 = uVar18;
code_r0x00101024:
  uStack_134 = (uVar17 >> 4) + 4;
  iStack_130 = ((uVar17 >> 4) * 2 + 0xc + uStack_134 * 0xf) * 2 + 0x54;
  auStack_260[0] = 0x101070;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  uVar18 = uVar17 + 4;
  lVar10 = (longlong)&uStack_1b8 + lVar12;
  if (uVar18 < uVar17) {
    uVar26 = 0xffffffff;
    *(undefined8 *)((longlong)auStack_260 + lVar12) = 0x1010a6;
    func_0x(0x80070216,uVar17,4);
  }
  else {
    uVar26 = (ulonglong)uVar18;
  }
  uVar14 = uVar26 + 0xf;
  if (uVar14 <= uVar26) {
    uVar14 = 0xffffffffffffff0;
  }
  uVar14 = uVar14 & 0xfffffffffffffff0;
  *(undefined8 *)((longlong)auStack_260 + lVar12) = 0x1010c0;
  func_0x();
  lVar2 = -uVar14;
  if (uVar18 < uVar17) {
    *(undefined8 *)((longlong)auStack_260 + lVar2 + lVar12) = 0x1010e6;
    func_0x(0x80070216,uVar17,4);
  }
  auStack_230[lVar2 + lVar12] = 0;
  *(undefined4 *)(auStack_230 + lVar2 + lVar12 + -8) = 0;
  uStack_188 = 0;
  *(undefined8 *)((longlong)auStack_260 + lVar2 + lVar12) = 0x101104;
  func_0x(auStack_186,(longlong)&uStack_1b8 + lVar2 + lVar12);
  lVar23 = lStack_180 + 4;
  uVar9 = uVar17 >> 2;
  lVar15 = lVar23;
  uVar18 = 0;
  if (uVar9 != 0) {
    *(undefined8 *)((longlong)auStack_260 + lVar2 + lVar12) = 0x101133;
    func_0x(lVar23,0,(ulonglong)uVar9 * 4);
    lVar15 = lVar23 + (ulonglong)uVar9 * 4;
    uVar18 = uVar9;
  }
  uVar26 = 0;
  if (uVar18 * 4 < uVar17) {
    *(undefined8 *)((longlong)auStack_260 + lVar2 + lVar12) = 0x101152;
    func_0x(lVar15,0,uVar17 + uVar18 * -4);
  }
  uVar14 = uVar26;
  if (uVar20 != 0) {
    do {
      uVar18 = (uint)uVar26 & 7;
      pbVar24 = (byte *)(lVar23 + (uVar14 >> 3));
      bVar7 = *pbVar24;
      if ((pbStack_f0[(uVar14 >> 3) + 4] >> ((byte)uVar26 & 7) & 1) == 0) {
        bVar7 = bVar7 & ~(byte)(1 << uVar18);
      }
      else {
        bVar7 = bVar7 | (byte)(1 << uVar18);
      }
      uVar18 = (uint)uVar26 + 1;
      uVar26 = (ulonglong)uVar18;
      *pbVar24 = bVar7;
      uVar14 = uVar14 + 1;
    } while (uVar18 < uVar20);
  }
  uVar26 = (ulonglong)uStack_134;
  iStack_120 = 0;
  lStack_108 = uVar26 * 0x10 + 0x38 + lVar10;
  uStack_13c = 0;
  lStack_118 = uVar26 * 8 + 0x1c + lStack_108;
  lStack_110 = lStack_118 + uVar26 * 4;
  lStack_128 = lStack_110 + uVar26 * 2;
  uStack_138 = 2;
  lStack_100 = lVar10;
  if (sStack_f8 == 0) {
    *(undefined8 *)((longlong)auStack_260 + lVar2 + lVar12) = 0x10122a;
    func_0x();
  }
  else {
    *(undefined8 *)((longlong)auStack_260 + lVar2 + lVar12) = 0x101231;
    func_0x(&uStack_f6,auStack_186,auStack_148);
  }
  pplVar5 = pplStack_190;
  uVar11 = uStack_198;
  if (iStack_120 != 0) {
    *(undefined8 *)((longlong)auStack_1c8 + lVar2 + lVar12) = 0;
    auStack_1d0[lVar2 + lVar12] = 0;
    *(undefined4 *)((longlong)auStack_1d8 + lVar2 + lVar12) = 0;
    *(undefined8 *)((longlong)&uStack_1e0 + lVar2 + lVar12) = 0;
    *(undefined4 *)((longlong)auStack_1e8 + lVar2 + lVar12) = 0;
    *(undefined8 *)((longlong)&uStack_1f0 + lVar2 + lVar12) = 0;
    *(undefined4 *)((longlong)auStack_1f8 + lVar2 + lVar12) = 0;
    *(undefined8 *)((longlong)&uStack_200 + lVar2 + lVar12) = 0;
    auStack_208[lVar2 + lVar12] = 0;
    *(undefined8 *)((longlong)auStack_218 + lVar2 + lVar12 + 8) = 0;
    *(undefined8 *)((longlong)auStack_218 + lVar2 + lVar12) = uVar11;
    *(undefined4 *)((longlong)auStack_228 + lVar2 + lVar12 + 8) = 0;
    *(undefined4 *)((longlong)auStack_228 + lVar2 + lVar12) = 0;
    auStack_230[lVar2 + lVar12] = 0x11;
    *(undefined **)(auStack_230 + lVar2 + lVar12 + -8) = auStack_148;
    *(undefined8 *)((longlong)auStack_260 + lVar2 + lVar12) = 0x1012a9;
    func_0x(pplVar5,0,0x1a422f0,1);
  }
  uVar26 = uStack_48 ^ (ulonglong)&uStack_1b8;
  *(undefined8 *)((longlong)auStack_260 + lVar2 + lVar12) = 0x1012b8;
  func_0x(uVar26);
  return;
}

