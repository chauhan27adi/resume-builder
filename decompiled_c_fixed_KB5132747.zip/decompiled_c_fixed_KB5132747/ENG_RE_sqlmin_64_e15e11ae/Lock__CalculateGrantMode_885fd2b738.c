
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong param_1,longlong param_2,int param_3)

{
  ulonglong uVar1;
  undefined8 uVar2;
  ulonglong uVar3;
  undefined8 *puVar4;
  uint uVar5;
  int iVar6;
  
  uVar5 = 0;
  if (param_3 == 0) {
    uVar5 = *_DAT_;
    uVar3 = func_0x();
    uVar5 = (uint)((uVar3 & 0xffffffff) % (ulonglong)uVar5) >> ((byte)_DAT_ & 0x1f) & 3;
  }
  iVar6 = 0;
  uVar3 = (ulonglong)uVar5;
  while (puVar4 = *(undefined8 **)(param_1 + 0x10 + uVar3 * 8), puVar4 == (undefined8 *)0x0) {
LAB_:
    uVar1 = uVar3 + 1;
    iVar6 = iVar6 + 1;
    uVar3 = 0;
    if ((longlong)uVar1 < 4) {
      uVar3 = uVar1;
    }
    if (3 < iVar6) {
      return 0;
    }
  }
  if ((*(byte *)((longlong)puVar4 + 0x37) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  do {
    if (param_2 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar2 = *(undefined8 *)(puVar4[5] + 0x48);
    if (*(longlong *)(param_2 + 0x40) != *(longlong *)(puVar4[5] + 0x40)) {
      return;
    }
    if (((int)*(undefined8 *)(param_2 + 0x48) != (int)uVar2) ||
       ((int)((ulonglong)*(undefined8 *)(param_2 + 0x48) >> 0x20) != (int)((ulonglong)uVar2 >> 0x20)
       )) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((param_3 == 0) &&
       (*(char *)((ulonglong)*(byte *)(param_1 + 0x5a) + 0x2f9b5a0) != (char)param_3)) {
      return 0;
    }
    puVar4 = (undefined8 *)*puVar4;
    while( true ) {
      if (puVar4 == (undefined8 *)0x0) goto LAB_;
      if ((*(byte *)((longlong)puVar4 + 0x37) & 1) == 0) break;
      puVar4 = (undefined8 *)*puVar4;
    }
  } while( true );
}

