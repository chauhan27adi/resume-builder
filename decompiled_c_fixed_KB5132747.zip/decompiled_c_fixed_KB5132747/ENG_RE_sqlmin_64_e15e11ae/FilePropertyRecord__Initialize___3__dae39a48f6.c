
/* WARNING: Control flow encountered bad instruction data */

void FUN_(short *param_1,short *param_2)

{
  ushort uVar1;
  ushort uVar2;
  short sVar3;
  byte *pbVar4;
  ushort *puVar5;
  byte bVar6;
  uint uVar7;
  ulonglong uVar8;
  int iVar9;
  uint uVar10;
  ushort *puVar11;
  
  uVar7 = *(uint *)(param_2 + 2);
  if (*param_2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (uVar7 == 0) {
    pbVar4 = *(byte **)(param_2 + 4);
    param_2[1] = 0;
    uVar7 = *(uint *)(param_2 + 8);
    uVar8 = (ulonglong)uVar7;
    *(uint *)(param_2 + 10) = uVar7;
    bVar6 = *pbVar4;
    if ((bVar6 & 0x10) != 0) {
      uVar7 = uVar7 + 2 + (*(ushort *)(pbVar4 + uVar8) + 7 >> 3);
      uVar8 = (ulonglong)uVar7;
      *(uint *)(param_2 + 10) = uVar7;
      bVar6 = *pbVar4;
    }
    if ((bVar6 & 0x20) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    puVar11 = (ushort *)(pbVar4 + uVar8);
    uVar1 = *puVar11;
    param_2[0xe] = uVar1;
    if (uVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar7 = (int)uVar8 + (uVar1 + 1) * 2;
    *(uint *)(param_2 + 0xc) = uVar7;
    if (0x1f9e < uVar7) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar2 = puVar11[uVar1];
    *(uint *)(param_2 + 2) = uVar2 & 0x7fff;
    if ((uVar2 & 0x7fff) < uVar7) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    iVar9 = 0;
    puVar5 = puVar11;
    if (uVar1 != 0) {
      do {
        uVar10 = puVar5[1] & 0x7fff;
        if ((uVar10 < uVar7) || (*(uint *)(param_2 + 2) < uVar10)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        uVar1 = param_2[0xe];
        iVar9 = iVar9 + 1;
        uVar7 = uVar10;
        puVar5 = puVar5 + 1;
      } while (iVar9 < (int)(uint)uVar1);
    }
    if ((short)puVar11[(ulonglong)(uVar1 - 1) + 1] < 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar7 = *(uint *)(param_2 + 2);
    if ((**(byte **)(param_2 + 4) & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined4 *)(param_2 + 0x13) = 0;
    if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
       (*(ulonglong *)(param_2 + 0xf) < (ulonglong)uVar7 + *(longlong *)(param_2 + 4))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((uVar7 == 0) || (0x3f3c < uVar7)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  if (uVar7 < 9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (0x7ff < uVar7) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  sVar3 = *param_2;
  *param_1 = sVar3;
  if (sVar3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar7 = *(uint *)(param_2 + 2);
  if (uVar7 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (uVar7 < 9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_2 + 8);
  param_1[1] = param_2[1];
  *(undefined4 *)(param_1 + 2) = *(undefined4 *)(param_2 + 2);
  param_1[0xe] = param_2[0xe];
  *(undefined4 *)(param_1 + 10) = *(undefined4 *)(param_2 + 10);
  *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0xc);
  *(undefined4 *)(param_1 + 0x13) = *(undefined4 *)(param_2 + 0x13);
  func_0x(param_1 + 0x1a,0x800,*(undefined8 *)(param_2 + 4),uVar7);
  *(short **)(param_1 + 4) = param_1 + 0x1a;
  iVar9 = func_0x(param_1 + 1);
  if (iVar9 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  return;
}

