
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,int param_3)

{
  int *piVar1;
  byte *pbVar2;
  byte bVar3;
  undefined2 uVar4;
  code *pcVar5;
  uint **ppuVar6;
  char cVar7;
  undefined4 uVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  longlong lVar12;
  longlong *plVar13;
  longlong lVar14;
  uint *puVar15;
  longlong lVar16;
  short *psVar17;
  undefined8 uVar18;
  longlong lVar19;
  ushort uVar20;
  uint uVar21;
  undefined8 unaff_RBX;
  uint uVar22;
  byte **ppbVar23;
  undefined *puVar24;
  byte **ppbVar25;
  undefined *puVar26;
  byte *pbVar27;
  byte *pbVar28;
  longlong lVar29;
  ulonglong uVar30;
  short sVar31;
  ulonglong uVar32;
  ushort *puVar33;
  ushort *puVar34;
  longlong unaff_GS_OFFSET;
  longlong *plStackX_8;
  undefined8 uStackX_10;
  undefined8 uStackX_18;
  undefined4 auStackX_20 [2];
  undefined auStack_49e8 [8];
  longlong *plStack_49e0;
  undefined uStack_49d8;
  uint uStack_49d4;
  uint uStack_49d0;
  int iStack_49c8;
  int iStack_49c4;
  short sStack_49c0;
  undefined8 uStack_49b8;
  undefined4 uStack_49b0;
  short sStack_49a8;
  ushort uStack_49a6;
  uint uStack_49a4;
  undefined *puStack_49a0;
  byte **ppbStack_4998;
  uint uStack_4990;
  ushort uStack_498c;
  undefined8 uStack_498a;
  undefined2 uStack_4982;
  undefined2 uStack_4980;
  ushort uStack_497e;
  ushort uStack_497c;
  undefined2 uStack_497a;
  uint auStack_4970 [2];
  undefined8 uStack_4968;
  ushort uStack_4960;
  undefined8 uStack_4958;
  undefined2 uStack_4950;
  undefined8 uStack_4948;
  ushort uStack_4940;
  undefined auStack_4938 [4];
  undefined4 uStack_4934;
  undefined4 uStack_4930;
  undefined4 uStack_492c;
  undefined2 uStack_4928;
  undefined4 uStack_4924;
  undefined2 uStack_4920;
  undefined4 uStack_491c;
  undefined2 uStack_4918;
  undefined4 uStack_4914;
  undefined2 uStack_4910;
  undefined8 uStack_4908;
  undefined8 uStack_4900;
  undefined2 uStack_48f8;
  undefined8 uStack_48f0;
  undefined4 uStack_48e8;
  undefined8 uStack_48e0;
  ushort uStack_48d8;
  undefined8 uStack_48d0;
  undefined2 uStack_48c8;
  undefined auStack_48c0 [8];
  longlong *plStack_48b8;
  longlong lStack_48b0;
  undefined auStack_48a8 [8];
  longlong lStack_48a0;
  undefined8 uStack_4898;
  undefined auStack_4890 [8];
  uint uStack_4888;
  undefined8 uStack_4884;
  undefined auStack_4870 [8];
  undefined8 uStack_4868;
  longlong lStack_4860;
  ulonglong uStack_4858;
  undefined4 uStack_4850;
  undefined4 uStack_4840;
  undefined uStack_4838;
  undefined4 uStack_4830;
  undefined auStack_4828 [16];
  undefined *puStack_4818;
  undefined4 uStack_4810;
  undefined *puStack_4808;
  undefined2 auStack_4800 [2];
  undefined4 uStack_47fc;
  undefined8 uStack_47f8;
  undefined8 uStack_47f0;
  undefined8 uStack_47e2;
  undefined8 uStack_47d8;
  undefined8 uStack_47c8;
  undefined auStack_47b8 [8];
  undefined4 uStack_47b0;
  undefined4 uStack_47a8;
  uint **ppuStack_47a0;
  undefined *puStack_4798;
  undefined8 uStack_4790;
  uint *puStack_4788;
  undefined4 uStack_4780;
  undefined4 uStack_477c;
  longlong lStack_4778;
  undefined4 uStack_4770;
  undefined4 uStack_476c;
  longlong lStack_4768;
  undefined4 uStack_4760;
  undefined4 uStack_475c;
  short *psStack_4758;
  int iStack_4750;
  undefined4 uStack_474c;
  short *psStack_4748;
  int iStack_4740;
  undefined4 uStack_473c;
  undefined8 uStack_4738;
  undefined4 uStack_4730;
  undefined4 uStack_472c;
  undefined auStack_4728 [448];
  undefined8 uStack_4568;
  undefined8 uStack_4560;
  uint uStack_4558;
  short sStack_4554;
  int iStack_4552;
  undefined uStack_454e;
  undefined uStack_454d;
  short sStack_4518;
  ushort uStack_4516;
  uint uStack_4514;
  byte *pbStack_4510;
  undefined8 uStack_4508;
  undefined4 uStack_4500;
  ushort uStack_44fc;
  undefined2 uStack_44fa;
  undefined6 uStack_44f8;
  undefined2 uStack_44f2;
  undefined2 uStack_44f0;
  ushort uStack_44ee;
  ushort uStack_44ec;
  undefined2 uStack_44ea;
  undefined4 uStack_44e8;
  int iStack_44e4;
  undefined auStack_44e0 [16];
  undefined auStack_44d0 [8];
  undefined8 uStack_44c8;
  undefined8 uStack_44c0;
  undefined6 uStack_44b8;
  undefined2 uStack_44b2;
  undefined6 uStack_44b0;
  undefined2 uStack_44aa;
  undefined8 uStack_44a8;
  undefined auStack_44a0 [16];
  undefined auStack_4490 [16];
  undefined auStack_4480 [16];
  undefined8 uStack_4470;
  undefined auStack_4468 [16];
  undefined2 uStack_4458;
  undefined4 uStack_4454;
  undefined8 uStack_4450;
  undefined8 uStack_4448;
  undefined8 uStack_443a;
  undefined8 uStack_4430;
  undefined8 uStack_4420;
  undefined8 uStack_4408;
  undefined4 uStack_4400;
  undefined2 uStack_43f6;
  short asStack_43e8 [24];
  short asStack_43b8 [24];
  undefined auStack_4388 [8096];
  undefined auStack_23e8 [9120];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  iStack_49c8 = param_3;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  uStack_47c8 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00004a80 + lVar12) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar12);
  sStack_4518 = -1;
  pbStack_4510 = (byte *)0x0;
  uStack_4514 = 0;
  uStack_44fa = 0;
  uStack_44f8 = 0;
  uStack_44f0 = 0;
  uStack_44ee = 0;
  uStack_44ec = 0;
  uStack_44ea = 0;
  uStack_4508 = (byte **)0x0;
  iStack_44e4 = 0xffffffff;
  sStack_49a8 = -1;
  puStack_49a0 = (undefined *)0x0;
  uStack_49a4 = 0;
  uStack_498a = 0;
  uStack_4980 = 0;
  uStack_497e = 0;
  uStack_497c = 0;
  uStack_497a = 0;
  ppbStack_4998 = (byte **)0x0;
  auStack_4800[0] = 0xffff;
  uStack_47f8 = 0;
  uStack_47fc = 0;
  uStack_47e2 = 0;
  uStack_47d8 = 0;
  uStack_47f0 = 0;
  auStack_4468 = ZEXT816(0);
  uStack_4458 = 0xffff;
  uStack_4450 = 0;
  uStack_4454 = 0;
  uStack_443a = 0;
  uStack_4430 = 0;
  uStack_4448 = 0;
  uStack_4420 = 0;
  uStack_4408 = 0;
  uStack_4400 = 0;
  uStack_43f6 = 0;
  auStack_4828 = ZEXT816(0);
  plStack_49e0 = (longlong *)0x0;
  uStack_49d8 = 0;
  uStack_49d4 = 0;
  auStack_49e8[0] = 5;
  uStack_4868 = 0xace4c0;
  uStack_4858 = 0;
  uStack_4850 = 0;
  uStack_4840 = 0xffffffff;
  uStack_4830 = 0x80000000;
  uStack_4838 = 0;
  uVar4 = *(undefined2 *)(param_1 + 0x18);
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001a0;
  lStack_48b0 = param_1;
  lStack_48a0 = param_2;
  plVar13 = (longlong *)func_0x(uVar4);
  plStack_48b8 = plVar13;
  if (*(short *)(param_1 + 0x1a) != 1) {
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001b6;
    lVar14 = func_0x();
    if (lVar14 == 0) {
      puVar15 = (uint *)0x4;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001c0;
      lVar14 = func_0x();
      puVar15 = (uint *)(lVar14 + 0x10);
    }
    *puVar15 = *puVar15 | 2;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001e4;
    (*_DAT_)(0x59,0x43,0x10,0x9d);
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001ec;
  func_0x(param_1);
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001f1;
  uVar8 = func_0x();
  *(undefined4 *)((longlong)auStackX_20 + lVar12) = 0;
  *(undefined4 *)((longlong)&uStackX_18 + lVar12) = 0;
  *(undefined4 *)((longlong)&uStackX_10 + lVar12) = 1;
  *(undefined4 *)((longlong)&plStackX_8 + lVar12) = uVar8;
  *(undefined4 *)((longlong)auStackX_20 + lVar12 + -0x20) = 1;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar12) = 0;
  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar12) = 0;
  *(undefined8 **)(&stack0xffffffffffffffe8 + lVar12) = &uStack_4898;
  uVar18 = *(undefined8 *)(param_1 + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100239;
  func_0x(plVar13,uVar18,&uStack_4868,auStack_49e8);
  (&stack0xffffffffffffffe8)[lVar12] = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100255;
  func_0x(plVar13,uStack_4898,auStack_49e8[0],0);
  pcVar5 = *(code **)(*plVar13 + 0x270);
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100261;
  (*pcVar5)(plVar13);
  iStack_49c4 = *(int *)(param_2 + 4);
  sStack_49c0 = *(short *)(param_2 + 8);
  lVar14 = plVar13[6];
  lVar16 = 0;
  uStack_4884 = 0;
  if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
    lVar19 = *(longlong *)
              ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar19 != 0) && (lVar19 = **(longlong **)(lVar19 + 0x38), lVar19 != 0)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1002cf;
      iVar9 = (*_DAT_)(lVar19,0x337);
      if (iVar9 != 0) goto LAB_;
    }
    lVar19 = *(longlong *)
              ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
              + 8);
    if (lVar19 != 0) {
      lVar16 = *(longlong *)(lVar19 + 0x60);
    }
  }
LAB_:
  lVar19 = *(longlong *)(lVar14 + 0x728);
LAB_:
  plVar13 = plStack_49e0;
  auStack_4970[0] = 0;
  if (plStack_49e0 != (longlong *)0x0) {
    iVar9 = (int)(short)uStack_49d4;
    if (((*(ushort *)((longlong)plStack_49e0 + 0x62) & 0x400) == 0) || (iVar9 < 3)) {
      if (((byte)*(undefined2 *)((longlong)plStack_49e0 + 0x62) >> 3 & 1) != 0) {
        if (iVar9 == 3) {
          iVar9 = 4;
        }
        else if (iVar9 < 2) goto LAB_;
        if ((((*(uint *)((longlong)plStack_49e0 + 100) & 8) != 0) &&
            (lVar29 = plStack_49e0[0x12], lVar29 != 0)) && (*(longlong *)(lVar29 + 0x758) != 0)) {
          uVar18 = *(undefined8 *)(lVar29 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1003ac;
          func_0x(uVar18,plStack_49e0,iVar9);
        }
      }
LAB_:
      if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar13 + 100) & 8) != 0)) &&
         ((2 < iVar9 &&
          (((*(uint *)((longlong)plVar13 + 100) & 0xc0000000) != 0x40000000 &&
           (lVar29 = *plVar13, lVar29 != 0)))))) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1003ed;
        iVar11 = (*_DAT_)(lVar29,0x2000,2,auStack_48c0);
        if (iVar11 != 0) {
          LOCK();
          *(uint *)((longlong)plVar13 + 100) = *(uint *)((longlong)plVar13 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar13 + 100) = *(uint *)((longlong)plVar13 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10040f;
      func_0x(plVar13 + 0x13,iVar9);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10042e;
        func_0x(plVar13,0,iVar9);
      }
      uStack_49d4 = uStack_49d4 & 0xffff0000;
      plStack_49e0 = (longlong *)0x0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10034b;
      func_0x(&plStack_49e0);
    }
  }
  if (*(longlong *)(lVar14 + 0x728) != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10045e;
    func_0x(&plStack_49e0,&iStack_49c4,lVar14);
    plVar13 = plStack_49e0;
    if (plStack_49e0 != (longlong *)0x0) {
      iVar9 = (int)(short)uStack_49d4;
      if (((*(ushort *)((longlong)plStack_49e0 + 0x62) & 0x400) == 0) || (iVar9 < 3)) {
        if (((byte)*(undefined2 *)((longlong)plStack_49e0 + 0x62) >> 3 & 1) != 0) {
          if (iVar9 == 3) {
            iVar9 = 4;
          }
          else if (iVar9 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plStack_49e0 + 100) & 8) != 0) &&
              (lVar29 = plStack_49e0[0x12], lVar29 != 0)) && (*(longlong *)(lVar29 + 0x758) != 0)) {
            uVar18 = *(undefined8 *)(lVar29 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1004e7;
            func_0x(uVar18,plStack_49e0,iVar9);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar13 + 100) & 8) != 0)) &&
           ((2 < iVar9 &&
            (((*(uint *)((longlong)plVar13 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar29 = *plVar13, lVar29 != 0)))))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100528;
          iVar11 = (*_DAT_)(lVar29,0x2000,2,auStack_4870);
          if (iVar11 != 0) {
            LOCK();
            *(uint *)((longlong)plVar13 + 100) = *(uint *)((longlong)plVar13 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar13 + 100) = *(uint *)((longlong)plVar13 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10054a;
        func_0x(plVar13 + 0x13,iVar9);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100569;
          func_0x(plVar13,0,iVar9);
        }
        uStack_49d4 = uStack_49d4 & 0xffff0000;
        plStack_49e0 = (longlong *)0x0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100486;
        func_0x(&plStack_49e0);
      }
    }
  }
  ppbVar23 = (byte **)0x0;
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100582;
  func_0x(lVar14,&iStack_49c4);
  *(uint **)(&stack0xfffffffffffffff0 + lVar12) = &uStack_4888;
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar12) = 4;
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1005ad;
  plStack_49e0 = (longlong *)func_0x(_DAT_,lVar14,&iStack_49c4,auStack_4970)
  ;
  if (lVar16 != 0) {
    uVar32 = (ulonglong)(*(uint *)(lVar16 + 0x500) & 0xf);
    if (*(longlong *)(lVar16 + 0x508 + uVar32 * 8) != *plStack_49e0) {
      *(longlong *)(lVar16 + 0x508 + uVar32 * 8) = *plStack_49e0;
      *(longlong *)(lVar16 + 0x500) = *(longlong *)(lVar16 + 0x500) + 1;
    }
  }
  uStack_49d4 = (auStack_4970[0] >> 3 & 1) << 0x18 | uStack_49d4 & 0xff0004 | 4;
  uStack_49d0 = auStack_4970[0] >> 4 & 1 | uStack_49d0 & 0xffffff00;
  if (((lVar19 != 0) && (lVar16 != 0)) && (lVar16 == *(longlong *)(lVar14 + 0x1c38))) {
    *(longlong *)(lVar19 + 0x5b28) = *(longlong *)(lVar19 + 0x5b28) + 1;
    if ((int)uStack_4884 != 0) {
      *(longlong *)(lVar19 + 0x5b30) = *(longlong *)(lVar19 + 0x5b30) + 1;
      *(longlong *)(lVar19 + 0x5b38) = *(longlong *)(lVar19 + 0x5b38) + (ulonglong)uStack_4888;
      if (0xffffff < uStack_49d4) {
        *(longlong *)(lVar19 + 0x5b40) = *(longlong *)(lVar19 + 0x5b40) + 1;
        *(longlong *)(lVar19 + 0x5b48) = *(longlong *)(lVar19 + 0x5b48) + (ulonglong)uStack_4888;
      }
    }
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10067c;
  cVar7 = func_0x(lVar14);
  if (((cVar7 == '\0') || (*(char *)(lVar14 + 0x2050) == '\0')) ||
     ((iStack_49c4 == 0 || ((iStack_49c4 == 9 && (sStack_49c0 == 1)))))) goto LAB_;
  lVar29 = *plStack_49e0;
  if (*(short *)(lVar29 + 0x24) == 0) {
LAB_:
    uStack_4948 = *(undefined8 *)(lVar29 + 0x28);
    uStack_4940 = *(ushort *)(lVar29 + 0x30);
  }
  else {
    cVar7 = *(char *)(lVar29 + 1);
    if (cVar7 == '\v') {
      if (*(int *)(lVar29 + 0x18) != 99) {
LAB_:
        if (cVar7 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar7 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar29 + 0x18) != 99) goto LAB_;
    }
    uStack_492c = *(undefined4 *)(lVar29 + 0x20);
    uStack_4928 = *(undefined2 *)(lVar29 + 0x24);
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100701;
    cVar7 = func_0x(&uStack_492c);
    if (cVar7 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100711;
    func_0x(lVar29,&uStack_4948);
  }
  uVar21 = *(uint *)(lVar14 + 0x2108);
  do {
    uVar10 = uVar21 & 0xfffffffe;
    uStack_49b8 = *(undefined8 *)(lVar14 + 0x20fc);
    uStack_49b0 = *(undefined4 *)(lVar14 + 0x2104);
    LOCK();
    *(undefined4 *)(&stack0xffffffffffffffc8 + lVar12) =
         *(undefined4 *)(&stack0xffffffffffffffc8 + lVar12);
    UNLOCK();
    uVar21 = *(uint *)(lVar14 + 0x2108);
  } while (uVar10 != uVar21);
  if ((uint)uStack_4948 <= (uint)uStack_49b8) {
    if ((uint)uStack_49b8 != (uint)uStack_4948) goto LAB_;
    uVar21 = (uint)((ulonglong)uStack_49b8 >> 0x20);
    if ((uStack_4948._4_4_ <= uVar21) &&
       ((uVar21 != uStack_4948._4_4_ || (uStack_4940 <= (ushort)uStack_49b0)))) goto LAB_;
  }
  if ((*(char *)(lVar14 + 0x6ac8) == '\0') &&
     (*(longlong *)
       (*(longlong *)
         ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8)
       + 0x60) != *(longlong *)(lVar14 + 0x2120))) {
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1007ca;
    cVar7 = func_0x(lVar14);
    if (cVar7 == '\0') {
      uVar21 = *(uint *)(lVar14 + 0x2108);
      do {
        uVar10 = uVar21 & 0xfffffffe;
        uStack_49b8 = *(undefined8 *)(lVar14 + 0x20fc);
        uStack_49b0 = *(undefined4 *)(lVar14 + 0x2104);
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar12) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar12);
        UNLOCK();
        uVar21 = *(uint *)(lVar14 + 0x2108);
      } while (uVar10 != uVar21);
      uVar20 = (ushort)uStack_49b0;
      uStack_48d8 = (ushort)uStack_49b0;
      lVar19 = *plStack_49e0;
      uStack_48e0 = uStack_49b8;
      if (*(short *)(lVar19 + 0x24) == 0) {
LAB_:
        uStack_4968 = *(undefined8 *)(lVar19 + 0x28);
        uStack_4960 = *(ushort *)(lVar19 + 0x30);
      }
      else {
        cVar7 = *(char *)(lVar19 + 1);
        if (cVar7 == '\v') {
          if (*(int *)(lVar19 + 0x18) != 99) {
LAB_:
            if (cVar7 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar7 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar19 + 0x18) != 99) goto LAB_;
        }
        uStack_491c = *(undefined4 *)(lVar19 + 0x20);
        uStack_4918 = *(undefined2 *)(lVar19 + 0x24);
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100a8b;
        cVar7 = func_0x(&uStack_491c);
        if (cVar7 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100a9b;
        func_0x(lVar19,&uStack_4968);
      }
      if ((uint)uStack_49b8 < (uint)uStack_4968) {
LAB_:
        lVar19 = *(longlong *)(lVar14 + 0x6b0);
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100afd;
        func_0x(&uStack_4968,asStack_43e8,auStack_4938);
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100b14;
        func_0x(&uStack_48e0,asStack_43b8,auStack_4938);
        if ((_DAT_ & 0x10000) != 0) {
          uStack_47b0 = 0x60000;
          uStack_47a8 = 0;
          ppuStack_47a0 = &puStack_4788;
          puStack_4798 = auStack_4728;
          uStack_4568 = 0;
          uStack_4790 = 0;
          uStack_4560 = 0;
          puStack_4788 = &uStack_4558;
          uStack_4780 = 0x34;
          uStack_477c = 5;
          uStack_4770 = 0x10;
          uStack_476c = 5;
          uStack_4760 = 0x10;
          uStack_475c = 6;
          uStack_474c = 7;
          uStack_473c = 8;
          uStack_4738 = 0;
          uStack_4730 = 0;
          uStack_472c = 9;
          uStack_4558 = (uint)*(ushort *)(lVar14 + 0x6b8);
          sStack_4554 = sStack_49c0;
          iStack_4552 = iStack_49c4;
          uStack_454e = 1;
          uStack_454d = *(undefined *)(*plStack_49e0 + 1);
          lStack_4778 = lVar19 + 0x254;
          lStack_4768 = lVar19 + 0x244;
          lVar14 = -1;
          do {
            lVar14 = lVar14 + 1;
          } while (asStack_43e8[lVar14] != 0);
          iStack_4750 = (int)lVar14 * 2;
          psStack_4758 = asStack_43e8;
          lVar14 = -1;
          do {
            lVar14 = lVar14 + 1;
          } while (asStack_43b8[lVar14] != 0);
          iStack_4740 = (int)lVar14 * 2;
          psStack_4748 = asStack_43b8;
          uStack_4934 = 0;
          pcVar5 = *(code **)(_DAT_ + 0x10);
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100cd4;
          puVar15 = (uint *)(*pcVar5)(lVar19,&uStack_4934);
          ppuVar6 = ppuStack_47a0;
          iVar9 = 0;
          if (puVar15 != (uint *)0x0) {
            lVar14 = -1;
            do {
              lVar14 = lVar14 + 1;
            } while (*(short *)((longlong)puVar15 + lVar14 * 2) != 0);
            iVar9 = (int)lVar14 * 2;
          }
          ppuStack_47a0[10] = puVar15;
          *(int *)(ppuVar6 + 0xb) = iVar9;
          *(undefined4 *)((longlong)ppuVar6 + 0x5c) = 9;
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d0e;
          func_0x(auStack_47b8);
        }
      }
      else if ((uint)uStack_49b8 == (uint)uStack_4968) {
        uVar21 = (uint)((ulonglong)uStack_4968 >> 0x20);
        if ((uStack_49b8._4_4_ < uVar21) ||
           ((uStack_49b8._4_4_ == uVar21 && (uVar20 < uStack_4960)))) goto LAB_;
      }
LAB_:
      uVar21 = 0x2640;
      if ((1 < (short)uStack_49d4) && (*(char *)(*plStack_49e0 + 1) != '\x01')) {
        if (lVar16 != 0) {
          *(longlong *)(lVar16 + 0x588) = *plStack_49e0;
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d39;
        lVar14 = func_0x();
        if (lVar14 != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d43;
          lVar14 = func_0x();
          if (*(longlong *)(lVar14 + 0x30) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d4f;
            lVar14 = func_0x();
            uVar10 = *(uint *)(*(longlong *)(lVar14 + 0x30) + 0xc);
            if ((uVar10 < 0xe) && ((uVar21 >> (uVar10 & 0x1f) & 1) != 0)) goto LAB_;
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d6b;
        func_0x(0,8);
      }
LAB_:
      lVar14 = *plStack_49e0;
      iStack_44e4 = iStack_49c8;
      uVar21 = 0xf;
      uStack_49b8 = lVar14;
      if (*(char *)(lVar14 + 2) < '\0') {
        pbVar28 = (byte *)(lVar14 + 0x60);
        if ((sStack_4518 == 0) || (ppbVar25 = uStack_4508, uStack_4508 == (byte **)0x0)) {
          uStack_44b8 = 0;
          uStack_44aa = 0;
          auStack_4490 = ZEXT816(0);
          auStack_44e0 = ZEXT816(0);
          stack0xffffffffffffbb32 = SUB1614(ZEXT816(0),2);
          auStack_44d0._0_2_ = 0xffff;
          uStack_44c8 = 0;
          uStack_44b2 = 0;
          uStack_44b0 = 0;
          uStack_44a8 = 0;
          uStack_44c0 = 0;
          auStack_44a0 = ZEXT816(0);
          auStack_4480._0_12_ = ZEXT812(0);
          auStack_4480._12_4_ = 0;
          uStack_4470 = 0;
          ppbVar25 = (byte **)auStack_44e0;
        }
        if (*(short *)(lVar14 + 0x24) == 0) {
LAB_:
          uStack_4958 = *(undefined8 *)(lVar14 + 0x28);
          uStack_4950 = *(undefined2 *)(lVar14 + 0x30);
        }
        else {
          cVar7 = *(char *)(lVar14 + 1);
          if (cVar7 == '\v') {
            if (*(int *)(lVar14 + 0x18) != 99) {
LAB_:
              if (cVar7 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar7 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar14 + 0x18) != 99) goto LAB_;
          }
          uStack_4914 = *(undefined4 *)(lVar14 + 0x20);
          uStack_4910 = *(undefined2 *)(lVar14 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100eab;
          cVar7 = func_0x(&uStack_4914,0xace580,0xace580);
          if (cVar7 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100ebb;
          func_0x(lVar14,&uStack_4958);
        }
        *ppbVar25 = pbVar28;
        *(undefined4 *)(ppbVar25 + 0xc) = (undefined4)uStack_4958;
        *(int *)((longlong)ppbVar25 + 100) = (int)((ulonglong)uStack_4958 >> 0x20);
        *(undefined2 *)(ppbVar25 + 0xd) = uStack_4950;
        *(undefined4 *)((longlong)ppbVar25 + 0x6c) = *(undefined4 *)(lVar14 + 0x20);
        *(undefined2 *)(ppbVar25 + 0xe) = *(undefined2 *)(lVar14 + 0x24);
        *(undefined2 *)((longlong)ppbVar25 + 0x72) = 0;
        uStack_4908 = (ushort *)
                      CONCAT44(uStack_4908._4_4_,*(undefined4 *)((ulonglong)*pbVar28 * 6 + 0xb4ce60)
                              );
        uVar32 = (ulonglong)*(short *)((ulonglong)*pbVar28 * 6 + 0xb4ce64);
        *(undefined2 *)(ppbVar25 + 2) = 0xffff;
        ppbVar25[3] = (byte *)0x0;
        *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
        *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
        ppbVar25[7] = (byte *)0x0;
        ppbVar25[4] = (byte *)0x0;
        ppbVar25[9] = (byte *)0x0;
        ppbVar25[10] = (byte *)0x0;
        *(undefined2 *)(ppbVar25 + 0xb) = 0;
        if ((**ppbVar25 & 2) != 0) {
          pbVar2 = pbVar28 + uVar32;
          if ((*pbVar2 & 1) == 0) {
            *(undefined2 *)(ppbVar25 + 2) = 0;
            ppbVar25[3] = pbVar2;
            *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
            *(undefined4 *)((longlong)ppbVar25 + 0x36) = 0;
            switch(*pbVar2 & 0xe) {
            default:
              ppbVar23 = (byte **)(ulonglong)*(ushort *)(pbVar2 + 2);
              if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10113f;
                func_0x(pbVar2,6);
              }
              break;
            case 4:
              ppbVar23 = (byte **)0x9;
              break;
            case 6:
            case 10:
              break;
            case 0xe:
              ppbVar23 = (byte **)0x1;
            }
            *(int *)(ppbVar25 + 4) = (int)ppbVar23;
            *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
          }
          else {
            *(undefined2 *)(ppbVar25 + 2) = 1;
            ppbVar25[3] = pbVar2;
            bVar3 = *pbVar2;
            switch(bVar3 & 0x1c) {
            default:
              if ((char)pbVar2[1] < '\0') {
                uVar20 = *(ushort *)(pbVar2 + 1);
                *(ushort *)((longlong)ppbVar25 + 0x12) = uVar20;
                sVar31 = 3;
                uVar20 = (uVar20 & 0x7f) << 8 | uVar20 >> 8;
              }
              else {
                sVar31 = 2;
                uVar20 = (ushort)pbVar2[1];
              }
              *(ushort *)((longlong)ppbVar25 + 0x12) = uVar20;
              *(short *)(ppbVar25 + 5) = sVar31;
              uVar20 = *(ushort *)((longlong)ppbVar25 + 0x12);
              *(short *)((longlong)ppbVar25 + 0x2c) = (short)(uVar20 + 1 >> 1) + sVar31;
              if (uVar20 < 0x1f) {
                *(undefined2 *)((longlong)ppbVar25 + 0x2a) = 0;
                *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
                *(undefined4 *)(ppbVar25 + 8) = 0;
                ppbVar25[7] = (byte *)0x0;
                ppbVar25[4] = (byte *)0x0;
              }
              else {
                iVar9 = uVar20 - 1;
                *(short *)((longlong)ppbVar25 + 0x2a) =
                     ((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
                     (short)((longlong)iVar9 * 0x88888889 >> 0x3f);
                *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
                *(undefined4 *)(ppbVar25 + 8) = 0;
                ppbVar25[7] = (byte *)0x0;
                ppbVar25[4] = (byte *)0x0;
              }
              break;
            case 4:
              if (((bVar3 & 0x1c) != 4) || (iVar9 = 1, (bVar3 & 2) == 0)) {
                iVar9 = 0;
              }
              if (iVar9 == 0) {
                uVar8 = 1;
              }
              else {
                *(undefined4 *)(ppbVar25 + 8) = 0;
                uVar8 = 0xf;
              }
              ppbVar25[5] = (byte *)0x0;
              *(undefined2 *)((longlong)ppbVar25 + 0x12) = 0;
              ppbVar25[6] = (byte *)0x0;
              ppbVar25[4] = (byte *)0x0;
              ppbVar25[7] = (byte *)0x0;
              ppbVar25[3] = pbVar2;
              *(undefined4 *)((longlong)ppbVar25 + 0x14) = uVar8;
              *(uint *)(ppbVar25 + 8) = (uint)(iVar9 != 0);
              ppbVar25[7] = (byte *)0x0;
              ppbVar25[4] = (byte *)0x0;
              break;
            case 8:
              ppbVar25[5] = (byte *)0x0;
              *(undefined2 *)((longlong)ppbVar25 + 0x12) = 0;
              ppbVar25[6] = (byte *)0x0;
              ppbVar25[4] = (byte *)0x0;
              ppbVar25[7] = (byte *)0x0;
              ppbVar25[3] = pbVar2;
              *(undefined4 *)((longlong)ppbVar25 + 0x14) = 9;
              *(undefined4 *)(ppbVar25 + 8) = 0;
              ppbVar25[7] = (byte *)0x0;
              ppbVar25[4] = (byte *)0x0;
            }
          }
        }
        if ((**ppbVar25 & 4) != 0) {
          if (uStack_4908._2_2_ != 0) {
            uVar32 = (ulonglong)*(ushort *)(lVar14 + 0x61 + (longlong)uStack_4908._2_2_ * 2);
          }
          psVar17 = (short *)(pbVar28 + uVar32);
          ppbVar25[9] = (byte *)psVar17;
          sVar31 = *psVar17;
          ppbVar25[10] = (byte *)(psVar17 + 1);
          *(short *)(ppbVar25 + 0xb) = (sVar31 + 1) * 2;
        }
        pbVar28 = ppbVar25[1];
        ppbVar23 = ppbVar25;
        if (pbVar28 != (byte *)0x0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1011d3;
          func_0x(pbVar28,ppbVar25);
        }
      }
      iVar9 = iStack_49c8;
      uVar32 = (ulonglong)*(ushort *)(lVar14 + 0xe);
      pbStack_4510 = (byte *)((ulonglong)*(ushort *)(lVar14 + (0xfff - (longlong)iStack_49c8) * 2) +
                             lVar14);
      if ((*pbStack_4510 & 1) == 0) {
        sStack_4518 = 0;
        uStack_4514 = 0;
        uStack_44f2 = 0;
        uStack_44f0 = 0;
        switch(*pbStack_4510 & 0xe) {
        default:
          uVar32 = (ulonglong)*(ushort *)(pbStack_4510 + 2);
          if (0x1f9d < *(ushort *)(pbStack_4510 + 2) - 1) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101439;
            func_0x(pbStack_4510,6);
          }
          break;
        case 4:
          uVar32 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar32 = 1;
        }
        uStack_4508 = (byte **)CONCAT44(uStack_4508._4_4_,(int)uVar32);
        lVar16 = lVar14 + 0x2000;
        if (lVar14 == 0) {
          lVar16 = 0;
        }
        uStack_44fa = (undefined2)lVar16;
        uStack_44f8 = (undefined6)((ulonglong)lVar16 >> 0x10);
        uVar21 = uStack_4514;
      }
      else {
        sStack_4518 = 1;
        bVar3 = *pbStack_4510;
        switch(bVar3 & 0x1c) {
        default:
          if ((char)pbStack_4510[1] < '\0') {
            uStack_4516 = (*(ushort *)(pbStack_4510 + 1) & 0x7f) << 8 |
                          *(ushort *)(pbStack_4510 + 1) >> 8;
            sVar31 = 3;
            uStack_4500._0_2_ = 3;
          }
          else {
            uStack_4516 = (ushort)pbStack_4510[1];
            uStack_4500._0_2_ = 2;
            sVar31 = 2;
          }
          uStack_44fc = (short)(uStack_4516 + 1 >> 1) + sVar31;
          if (uStack_4516 < 0x1f) {
            uVar21 = 0;
            uStack_4500._2_2_ = 0;
            uStack_4514 = 0;
            uStack_44e8 = 0;
          }
          else {
            iVar11 = uStack_4516 - 1;
            uStack_4500._2_2_ =
                 ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                 (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
            uVar21 = 0;
            uStack_4514 = 0;
            uStack_44e8 = 0;
          }
          break;
        case 4:
          if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
            uStack_4500._0_2_ = 0;
            uStack_4500._2_2_ = 0;
            uStack_44fc = 0;
            uStack_44fa = 0;
            uStack_4516 = 0;
            uStack_44f8 = 0;
            uStack_44f2 = 0;
            uStack_4514 = 0xf;
            uStack_44e8 = 1;
          }
          else {
            uStack_4500._0_2_ = 0;
            uStack_4500._2_2_ = 0;
            uStack_44fc = 0;
            uStack_44fa = 0;
            uStack_4516 = 0;
            uStack_44f8 = 0;
            uStack_44f2 = 0;
            uVar21 = 1;
            uStack_4514 = 1;
            uStack_44e8 = 0;
          }
          break;
        case 8:
          uStack_4500._0_2_ = 0;
          uStack_4500._2_2_ = 0;
          uStack_44fc = 0;
          uStack_44fa = 0;
          uStack_4516 = 0;
          uStack_44f8 = 0;
          uStack_44f2 = 0;
          uVar21 = 9;
          uStack_4514 = 9;
          uStack_44e8 = 0;
        }
        lVar16 = lVar14 + 0x2000;
        if (lVar14 == 0) {
          lVar16 = 0;
        }
        uStack_44f0 = (undefined2)lVar16;
        uStack_44ee = (ushort)((ulonglong)lVar16 >> 0x10);
        uStack_44ec = (ushort)((ulonglong)lVar16 >> 0x20);
        uStack_44ea = (undefined2)((ulonglong)lVar16 >> 0x30);
        uVar32 = (ulonglong)ppbVar23 & 0xffffffff;
        uStack_4508 = ppbVar23;
      }
      sStack_49a8 = sStack_4518;
      if (sStack_4518 != 0) {
        if ((uStack_4508 == (byte **)0x0) || (*uStack_4508 == (byte *)0x0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101e30;
          func_0x(&uStack_49a6,auStack_4388,0x1f9e,&uStack_4516);
          ppbStack_4998 = uStack_4508;
          if (sStack_4518 == 0) {
            ppbStack_4998 = (byte **)0x0;
          }
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101e11;
          func_0x(&sStack_49a8,auStack_4388,0x1f9e,&sStack_4518);
        }
        goto code_r0x00101e50;
      }
      pbVar28 = pbStack_4510;
      uStack_4990 = CONCAT22(uStack_4500._2_2_,(undefined2)uStack_4500);
      if (uVar21 == 0) {
        uStack_4516 = 0;
        uVar21 = (uint)uVar32;
        if ((*pbStack_4510 & 0x10) != 0) {
          uVar21 = uVar21 + 2 + (*(ushort *)(pbStack_4510 + uVar32) + 7 >> 3);
          uVar32 = (ulonglong)uVar21;
        }
        uStack_4508 = (byte **)CONCAT44(uVar21,(undefined4)uStack_4508);
        uStack_4990 = (uint)uVar32;
        if ((*pbStack_4510 & 0x20) == 0) {
          uStack_44fc = 0;
          uStack_4514 = uStack_4990;
        }
        else {
          puVar33 = (ushort *)(pbStack_4510 + uVar32);
          uStack_44fc = *puVar33;
          uStack_4908 = puVar33;
          if (uStack_44fc == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101519;
            cVar7 = func_0x(0x1463610);
            if (cVar7 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101522;
              cVar7 = func_0x();
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101532;
                cVar7 = func_0x(0x1463610);
                if (cVar7 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10154e;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10158e;
                  (*pcRam00000000009d1190)(1,0xd5301c,0xe73108,0x80f);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101561;
            func_0x(pbStack_4510,3);
          }
          uStack_4500 = uStack_4508._4_4_ + (uStack_44fc + 1) * 2;
          if (0x1f9e < uStack_4500) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1015be;
            cVar7 = func_0x(0x1463610);
            if (cVar7 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1015c7;
              cVar7 = func_0x();
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1015d7;
                cVar7 = func_0x(0x1463610);
                if (cVar7 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1015f3;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101619;
                  (*pcRam00000000009d1190)(1,0xd5301c,0xe73108,0x816);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10162a;
            func_0x(pbStack_4510,4);
          }
          uStack_4514 = puVar33[uStack_44fc] & 0x7fff;
          if (uStack_4514 < uStack_4500) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101661;
            cVar7 = func_0x(0x1463610);
            if (cVar7 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10166a;
              cVar7 = func_0x();
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10167a;
                cVar7 = func_0x(0x1463610);
                if (cVar7 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101696;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1016bc;
                  (*pcRam00000000009d1190)(1,0xd5301c,0xe73108,0x81d);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1016cd;
            func_0x(pbStack_4510,4);
          }
          uVar32 = (ulonglong)uStack_4514;
          iVar9 = 0;
          pbVar28 = pbStack_4510;
          uStack_4990 = uStack_4500;
          puVar34 = puVar33;
          if (uStack_44fc != 0) {
            do {
              puVar33 = puVar33 + 1;
              uVar21 = *puVar33 & 0x7fff;
              if ((uVar21 < uStack_4500) || ((uint)uVar32 < uVar21)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101721;
                uStack_4500 = uStack_4990;
                cVar7 = func_0x(0x1463610);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10172a;
                  cVar7 = func_0x();
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10173a;
                    cVar7 = func_0x(0x1463610);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101756;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10177a;
                      (*pcRam00000000009d1190)(1,0xd5301c,0xe73108,0x82a);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10178b;
                func_0x(pbStack_4510,4);
                uVar32 = (ulonglong)uStack_4514;
                pbVar28 = pbStack_4510;
                uStack_4990 = uStack_4500;
              }
              iVar9 = iVar9 + 1;
              uStack_4500 = uVar21;
              puVar34 = uStack_4908;
              lVar14 = uStack_49b8;
            } while (iVar9 < (int)(uint)uStack_44fc);
          }
          while ((short)puVar34[(ulonglong)(uStack_44fc - 1) + 1] < 0) {
            uVar10 = uStack_4990;
            if (uStack_44fc != 1) {
              uVar10 = *(ushort *)
                        (pbVar28 +
                        (ulonglong)uStack_44fc * 2 + (((ulonglong)uStack_4508 >> 0x20) - 2)) &
                       0x7fff;
            }
            uVar22 = *(ushort *)
                      (pbVar28 + (ulonglong)uStack_44fc * 2 + ((ulonglong)uStack_4508 >> 0x20)) &
                     0x7fff;
            if (((uVar10 < uStack_4990) || (uVar22 < uVar10)) || ((uint)uVar32 < uVar22)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10181f;
              uStack_4500 = uStack_4990;
              func_0x(pbVar28,7);
              uVar32 = (ulonglong)uStack_4514;
              pbVar28 = pbStack_4510;
              uStack_4990 = uStack_4500;
            }
            uVar21 = (uint)uVar32;
            if ((uVar10 < uStack_4990) || (uVar21 < uVar10)) goto code_r0x00101bc1;
            if (*(ushort *)(pbVar28 + uVar10) == 5) {
              uStack_4516 = uStack_4516 | 2;
              uStack_44fc = uStack_44fc - 1;
              uVar30 = (ulonglong)(uVar10 & 0xffff);
              uStack_44ee = (ushort)uVar10;
              pbVar2 = pbVar28 + uVar30;
              if ((*(ushort *)(pbVar2 + 2) >> 0xe & 1) == 0) {
                uVar20 = uStack_44ec & 0xc7ff;
              }
              else {
                uVar20 = uStack_44ec ^ (uStack_44ec ^ *(ushort *)(pbVar2 + 2)) & 0x3800;
              }
              uStack_44ec = (uVar20 ^ *(ushort *)(pbVar2 + 2)) & 0x7ff ^ uVar20;
              uVar21 = (uint)uStack_44ec;
              lVar16 = uVar30 + (uVar20 >> 0xb & 7) * 2;
              pbVar27 = pbVar28;
              if (pbVar28 + (ulonglong)((uVar21 & 0x7ff) * 2) + 4 + lVar16 < pbVar2) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10191f;
                uStack_4500 = uStack_4990;
                func_0x(pbVar2,0x19);
                uVar30 = (ulonglong)uStack_44ee;
                uVar32 = (ulonglong)uStack_4514;
                pbVar27 = pbStack_4510;
                uStack_4990 = uStack_4500;
              }
              if (uVar22 - uVar10 <
                  (((uStack_44ec & 0x7ff) * 2 - (int)uVar30) - (int)pbStack_4510) +
                  (int)(pbVar28 + (ulonglong)((uVar21 & 0x7ff) * 2) + 4 + lVar16)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10196f;
                uStack_4500 = uStack_4990;
                func_0x(pbVar27 + uVar30,0x19);
                uVar30 = (ulonglong)uStack_44ee;
                uVar32 = (ulonglong)uStack_4514;
                pbVar27 = pbStack_4510;
                uStack_4990 = uStack_4500;
              }
              iVar9 = 0;
              pbVar28 = pbVar27;
              if (((uStack_44ec & 0x3800) != 0) &&
                 (puVar33 = (ushort *)(pbVar27 + uVar30 + 4), uVar20 = uStack_44ec,
                 (uStack_44ec & 0x3800) != 0)) {
                do {
                  if ((uVar20 & 0x7ff) < (*puVar33 & 0x7ff)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1019e3;
                    uStack_4500 = uStack_4990;
                    func_0x(pbVar27 + uVar30,0x1a);
                    uVar30 = (ulonglong)uStack_44ee;
                    pbVar27 = pbStack_4510;
                    uStack_4990 = uStack_4500;
                    uVar20 = uStack_44ec;
                  }
                  iVar9 = iVar9 + 1;
                  puVar33 = puVar33 + 1;
                } while (iVar9 < (int)((uStack_44ec & 0x3800) >> 0xb));
                uVar32 = (ulonglong)uStack_4514;
                pbVar28 = pbVar27;
              }
              break;
            }
            if (*(ushort *)(pbVar28 + uVar10) < 0x400) break;
            uStack_4516 = uStack_4516 | 1;
            uStack_44fc = uStack_44fc - 1;
            if (uStack_44fc == 0) break;
          }
        }
        if ((*pbVar28 & 0x40) == 0) {
          uStack_44f2 = 0;
          uStack_44f0 = 0;
        }
        else {
          uStack_44f2 = (undefined2)uVar32;
          uStack_44f0 = (undefined2)(uVar32 >> 0x10);
          uStack_4514 = (int)uVar32 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101a52;
          uStack_4500 = uStack_4990;
          uVar18 = func_0x(&uStack_4516);
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101a61;
          func_0x(uVar18,auStack_48a8);
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101a6d;
          iVar9 = func_0x(auStack_48a8);
          uStack_4514 = uStack_4514 + iVar9;
          uVar32 = (ulonglong)uStack_4514;
          pbVar28 = pbStack_4510;
          uStack_4990 = uStack_4500;
        }
        uVar21 = (uint)uVar32;
        uStack_4500 = uStack_4990;
        if (((byte *)CONCAT62(uStack_44f8,uStack_44fa) != (byte *)0x0) &&
           ((byte *)CONCAT62(uStack_44f8,uStack_44fa) < pbVar28 + uVar32)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101ab5;
          cVar7 = func_0x(0x1463610);
          if (cVar7 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101abe;
            cVar7 = func_0x();
            if (cVar7 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101ace;
              cVar7 = func_0x(0x1463610);
              if (cVar7 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101aea;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b10;
                (*pcRam00000000009d1190)(1,0xd5301c,0xe73108,0x886);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b21;
          func_0x(pbStack_4510,0x12);
          pbVar28 = pbStack_4510;
          uVar21 = uStack_4514;
        }
        uStack_4990 = uStack_4500;
        if (0x3f3b < uVar21 - 1) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b48;
          cVar7 = func_0x(0x1463610);
          if (cVar7 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b51;
            cVar7 = func_0x();
            if (cVar7 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b61;
              cVar7 = func_0x(0x1463610);
              if (cVar7 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101b7d;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101ba3;
                (*pcRam00000000009d1190)(1,0xd5301c,0xe73108,0x88b);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101bb4;
          func_0x(pbStack_4510,5);
          pbVar28 = pbStack_4510;
          uVar21 = uStack_4514;
          uStack_4990 = uStack_4500;
        }
      }
code_r0x00101bc1:
      if ((8 < uVar21) || ((uVar10 = 9, (*pbVar28 & 0xe) != 0 && ((*pbVar28 & 0xe) != 0xc)))) {
        uVar10 = uVar21;
      }
      uStack_49a6 = uStack_4516;
      uStack_498c = uStack_44fc;
      ppbStack_4998 = uStack_4508;
      uStack_4982 = uStack_44f2;
      uStack_4980 = uStack_44f0;
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101c29;
      uStack_49a4 = uVar21;
      uStack_4500 = uStack_4990;
      func_0x(auStack_4388,0x1f9e,pbVar28,uVar10);
      puStack_49a0 = auStack_4388;
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101c3d;
      iVar11 = func_0x(&uStack_49a6);
      iVar9 = iStack_49c8;
      if (iVar11 != 0) {
        puVar33 = (ushort *)(puStack_49a0 + ((ulonglong)ppbStack_4998 >> 0x20));
        uVar21 = *puVar33 - 1;
        if ((uStack_49a6 & 1) == 0) {
          uVar21 = (uint)*puVar33;
        }
        uVar10 = uStack_4990;
        if (uVar21 != 1) {
          uVar10 = puVar33[(longlong)(int)uVar21 + -1] & 0x7fff;
        }
        uVar21 = puVar33[(int)uVar21] & 0x7fff;
        if (((uVar10 < uStack_4990) || (uVar21 < uVar10)) || (uStack_49a4 < uVar21)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101c9d;
          func_0x(puStack_49a0,7);
        }
        uVar32 = (ulonglong)(uVar10 & 0xffff);
        uStack_497e = (ushort)uVar10;
        puVar26 = puStack_49a0 + uVar32;
        if ((*(ushort *)(puVar26 + 2) >> 0xe & 1) == 0) {
          uVar20 = uStack_497c & 0xc7ff;
        }
        else {
          uVar20 = uStack_497c ^ (*(ushort *)(puVar26 + 2) ^ uStack_497c) & 0x3800;
        }
        uStack_497c = (uVar20 ^ *(ushort *)(puVar26 + 2)) & 0x7ff ^ uVar20;
        puVar24 = puStack_49a0 +
                  (ulonglong)((uStack_497c & 0x7ff) * 2) + 4 + (uVar20 >> 0xb & 7) * 2 + uVar32;
        if (puVar24 < puVar26) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101d30;
          func_0x(puVar26,0x19);
          uVar32 = (ulonglong)uStack_497e;
        }
        if (uVar21 - uVar10 <
            (((uStack_497c & 0x7ff) * 2 - (int)uVar32) - (int)puStack_49a0) + (int)puVar24) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101d66;
          func_0x(puStack_49a0 + uVar32,0x19);
          uVar32 = (ulonglong)uStack_497e;
        }
        iVar11 = 0;
        iVar9 = iStack_49c8;
        if (((uStack_497c & 0x3800) != 0) &&
           (puVar33 = (ushort *)(puStack_49a0 + uVar32 + 4), puVar26 = puStack_49a0,
           uVar20 = uStack_497c, (uStack_497c & 0x3800) != 0)) {
          do {
            if ((uVar20 & 0x7ff) < (*puVar33 & 0x7ff)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101dc6;
              func_0x(puVar26 + uVar32,0x1a);
              uVar32 = (ulonglong)uStack_497e;
              puVar26 = puStack_49a0;
              uVar20 = uStack_497c;
            }
            iVar11 = iVar11 + 1;
            puVar33 = puVar33 + 1;
            iVar9 = iStack_49c8;
          } while (iVar11 < (int)((uStack_497c & 0x3800) >> 0xb));
        }
      }
code_r0x00101e50:
      lVar16 = 0;
      if (sStack_49a8 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101e60;
        func_0x();
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101e67;
        func_0x(&uStack_49a6);
      }
      auStack_4828._0_8_ = &sStack_49a8;
      if (*(char *)(lVar14 + 2) < '\0') {
        auStack_4828._8_8_ = auStack_4800;
        puStack_4818 = auStack_23e8;
        uStack_4810 = 0x239e;
        puStack_4808 = auStack_4468;
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101ebc;
        func_0x(auStack_4828,lVar14);
      }
      lVar14 = lStack_48b0;
      plVar13 = plStack_48b8;
      *(undefined8 *)(&stack0x00000028 + lVar12) = 0;
      *(undefined4 *)((longlong)auStackX_20 + lVar12) = 0;
      *(undefined8 *)((longlong)&uStackX_18 + lVar12) = 0;
      *(undefined4 *)((longlong)&uStackX_10 + lVar12) = 2;
      *(undefined8 *)((longlong)&plStackX_8 + lVar12) = 0;
      *(longlong **)((longlong)auStackX_20 + lVar12 + -0x20) = plStack_48b8;
      *(undefined4 *)(&stack0xfffffffffffffff8 + lVar12) = 0;
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar12) = 0;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar12) = 1;
      uVar18 = *(undefined8 *)(lVar14 + 8);
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101f15;
      func_0x(&plStack_49e0,uVar18,lVar14 + 0x10,iVar9);
      *(undefined4 *)((longlong)auStackX_20 + lVar12) = 0;
      *(undefined4 *)((longlong)&uStackX_18 + lVar12) = 0;
      *(undefined8 *)((longlong)&uStackX_10 + lVar12) = 0;
      *(longlong **)((longlong)&plStackX_8 + lVar12) = plVar13;
      *(undefined4 *)((longlong)auStackX_20 + lVar12 + -0x20) = 0;
      *(undefined4 *)(&stack0xfffffffffffffff8 + lVar12) = 0;
      *(undefined **)(&stack0xfffffffffffffff0 + lVar12) = auStack_4828;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar12) = 1;
      uVar18 = *(undefined8 *)(lVar14 + 8);
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101f58;
      func_0x(&plStack_49e0,uVar18,lVar14 + 0x10,iVar9);
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101f5d;
      lVar19 = func_0x();
      uStack_4930 = *(undefined4 *)(lVar19 + 0x68);
      uStack_48f0 = 0;
      uStack_48e8 = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101f7a;
      lVar19 = func_0x();
      if (lVar19 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101f84;
        lVar19 = func_0x();
        if (*(longlong *)(lVar19 + 0x30) != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101f90;
          lVar19 = func_0x();
          uVar21 = *(uint *)(*(longlong *)(lVar19 + 0x30) + 0xc);
          if ((uVar21 < 0xe) && ((0x2640U >> (uVar21 & 0x1f) & 1) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101fab;
            lVar19 = func_0x();
            if (*(longlong *)(lVar19 + 0xa0) != 0) {
              lVar16 = *(longlong *)(*(longlong *)(lVar19 + 0xa0) + 8);
            }
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101fc5;
      lVar19 = func_0x();
      if ((lVar19 == 0) || ((*(uint *)(lVar19 + 0x18) >> 2 & 1) == 0)) {
        LOCK();
        piVar1 = (int *)(lVar16 + 8);
        iVar11 = *piVar1;
        *piVar1 = *piVar1 + 1;
        UNLOCK();
        *(undefined2 *)(&stack0x00000070 + lVar12) = 0;
        *(undefined4 *)(&stack0x00000068 + lVar12) = 0;
        *(undefined8 *)(&stack0x00000060 + lVar12) = 0;
        *(undefined4 *)(&stack0x00000058 + lVar12) = 0;
        *(undefined2 *)(&stack0x00000050 + lVar12) = 1;
        *(undefined8 *)(&stack0x00000048 + lVar12) = 0;
        *(undefined4 *)(&stack0x00000040 + lVar12) = 0;
        *(undefined8 *)(&stack0x00000038 + lVar12) = 0;
        *(undefined4 *)(&stack0x00000030 + lVar12) = 0;
        *(undefined8 *)(&stack0x00000028 + lVar12) = 0;
        *(undefined4 *)((longlong)auStackX_20 + lVar12) = 0;
        *(int *)((longlong)&uStackX_18 + lVar12) = iVar11 + 1;
        *(undefined4 *)((longlong)&uStackX_10 + lVar12) = 1;
        *(undefined4 *)((longlong)&plStackX_8 + lVar12) = 10;
        *(undefined4 *)((longlong)auStackX_20 + lVar12 + -0x20) = 0x1eed;
        *(undefined4 *)(&stack0xfffffffffffffff8 + lVar12) = 0;
        *(undefined8 **)(&stack0xfffffffffffffff0 + lVar12) = &uStack_48f0;
        *(longlong *)(&stack0xffffffffffffffe8 + lVar12) = lVar14;
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x102071;
        func_0x(lVar16,&uStack_4930,lStack_48a0,iVar9);
      }
      uStack_4868 = 0xace4c0;
      if ((int)uStack_4858 == 3) {
        uStack_4858 = uStack_4858 & 0xffffffff00000000;
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1020a6;
        func_0x(lStack_4860 + 0x530,1);
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1020b0;
      func_0x(&plStack_49e0);
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1020bf;
      func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar12));
      return;
    }
  }
  if (*(longlong *)
       (*(longlong *)
         ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8)
       + 0x60) == *(longlong *)(lVar14 + 0x2120)) goto LAB_;
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10080e;
  cVar7 = func_0x(lVar14);
  if (cVar7 != '\0') goto LAB_;
  if (lVar16 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100820;
    lVar16 = func_0x();
  }
  lVar29 = *plStack_49e0;
  if (*(short *)(lVar29 + 0x24) == 0) {
LAB_:
    uStack_4900 = *(undefined8 *)(lVar29 + 0x28);
    uStack_48f8 = *(undefined2 *)(lVar29 + 0x30);
  }
  else {
    cVar7 = *(char *)(lVar29 + 1);
    if (cVar7 == '\v') {
      if (*(int *)(lVar29 + 0x18) != 99) {
LAB_:
        if (cVar7 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar7 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar29 + 0x18) != 99) goto LAB_;
    }
    uStack_4924 = *(undefined4 *)(lVar29 + 0x20);
    uStack_4920 = *(undefined2 *)(lVar29 + 0x24);
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10086f;
    cVar7 = func_0x(&uStack_4924);
    if (cVar7 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10087f;
    func_0x(lVar29,&uStack_4900);
  }
  plVar13 = plStack_49e0;
  if (plStack_49e0 != (longlong *)0x0) {
    iVar9 = (int)(short)uStack_49d4;
    if (((*(ushort *)((longlong)plStack_49e0 + 0x62) & 0x400) == 0) || (iVar9 < 3)) {
      if (((byte)*(undefined2 *)((longlong)plStack_49e0 + 0x62) >> 3 & 1) != 0) {
        if (iVar9 == 3) {
          iVar9 = 4;
        }
        else if (iVar9 < 2) goto LAB_;
        if ((((*(uint *)((longlong)plStack_49e0 + 100) & 8) != 0) &&
            (lVar29 = plStack_49e0[0x12], lVar29 != 0)) && (*(longlong *)(lVar29 + 0x758) != 0)) {
          uVar18 = *(undefined8 *)(lVar29 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100927;
          func_0x(uVar18,plStack_49e0,iVar9);
        }
      }
LAB_:
      if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar13 + 100) & 8) != 0)) &&
         ((2 < iVar9 &&
          (((*(uint *)((longlong)plVar13 + 100) & 0xc0000000) != 0x40000000 &&
           (lVar29 = *plVar13, lVar29 != 0)))))) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10096c;
        iVar11 = (*_DAT_)(lVar29,0x2000,2,auStack_4890);
        if (iVar11 != 0) {
          LOCK();
          *(uint *)((longlong)plVar13 + 100) = *(uint *)((longlong)plVar13 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar13 + 100) = *(uint *)((longlong)plVar13 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10098e;
      func_0x(plVar13 + 0x13,iVar9);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1009ad;
        func_0x(plVar13,0,iVar9);
      }
      uStack_49d4 = uStack_49d4 & 0xffff0000;
      plStack_49e0 = (longlong *)0x0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1008c6;
      func_0x(&plStack_49e0);
    }
  }
  uStack_48d0 = uStack_4900;
  uStack_48c8 = uStack_48f8;
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
  uVar18 = *(undefined8 *)(lVar14 + 0x728);
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1009f8;
  func_0x(uVar18,&uStack_48d0,4);
  goto LAB_;
}

