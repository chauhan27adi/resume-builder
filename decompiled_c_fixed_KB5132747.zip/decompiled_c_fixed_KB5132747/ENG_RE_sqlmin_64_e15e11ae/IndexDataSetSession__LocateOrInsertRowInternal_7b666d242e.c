
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,ushort **param_2,undefined8 param_3)

{
  byte *pbVar1;
  short *psVar2;
  uint *puVar3;
  undefined4 uVar4;
  longlong *plVar5;
  code *pcVar6;
  char cVar7;
  undefined2 uVar8;
  undefined4 uVar9;
  int iVar10;
  longlong lVar11;
  longlong lVar12;
  longlong lVar13;
  undefined8 uVar14;
  undefined4 *puVar15;
  undefined uVar16;
  byte bVar17;
  undefined8 uVar18;
  uint uVar19;
  int iVar20;
  byte *pbVar21;
  int *piVar22;
  uint uVar23;
  undefined8 unaff_RBX;
  ulonglong uVar24;
  ushort *puVar25;
  uint *puVar26;
  undefined *puVar27;
  undefined *puVar28;
  uint uVar29;
  ulonglong uVar30;
  byte *pbVar31;
  ushort *puVar32;
  ulonglong uVar33;
  uint uVar34;
  ushort *puVar35;
  ushort uVar36;
  uint uVar37;
  ushort uVar38;
  ulonglong uVar39;
  ushort *puVar40;
  longlong lVar41;
  uint uVar42;
  bool bVar43;
  longlong alStackX_8 [2];
  ushort uStackX_18;
  ushort uStackX_1a;
  uint uStackX_1c;
  byte *pbStackX_20;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  puVar27 = &stack0xffffffffffffffc8 + lVar11;
  puVar28 = &stack0xffffffffffffffc8 + lVar11;
  psVar2 = (short *)((longlong)&uStackX_18 + lVar11);
  *(undefined8 *)(&stack0x000000e8 + lVar11) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002200 + lVar11) = unaff_RBX;
  *(ulonglong *)(&stack0x00002198 + lVar11) = _DAT_ ^ (ulonglong)psVar2;
  *(undefined8 *)(&stack0x000000d0 + lVar11) = param_3;
  *(ushort ***)(&stack0x00000060 + lVar11) = param_2;
  *(longlong *)(&stack0x00000068 + lVar11) = param_1;
  *(ushort **)(&stack0x000000d8 + lVar11) = *param_2;
  lVar13 = *(longlong *)(param_1 + 0x10);
  *(longlong *)(&stack0x000000c8 + lVar11) = lVar13;
  *psVar2 = -1;
  puVar35 = (ushort *)0x0;
  *(undefined8 *)((longlong)&pbStackX_20 + lVar11) = 0;
  uVar23 = 0;
  *(undefined4 *)((longlong)&uStackX_18 + lVar11 + 4) = 0;
  *(undefined8 *)(&stack0x00000036 + lVar11) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar11) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar11) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10009f;
  func_0x(&stack0x000001f8 + lVar11,0,0x1f9e);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1000b7;
  func_0x(&stack0x000000e0 + lVar11,param_1,1);
  lVar13 = *(longlong *)(lVar13 + 8);
  bVar17 = *(byte *)(lVar13 + 0x106);
  uVar42 = **(uint **)(param_1 + 0x108) & 0x20000000;
  *(uint *)(&stack0x00000054 + lVar11) = uVar42;
  iVar10 = *(int *)(lVar13 + 0x100);
  bVar43 = false;
  if ((iVar10 != 0) && (iVar10 != 3 && iVar10 != 4)) {
    bVar43 = true;
  }
  puVar40 = *param_2;
  if ((*(byte *)(puVar40 + 0x1c) & 0x20) == 0) {
    uVar42 = *(uint *)((longlong)param_2 + 0x14) & 0x10;
    if (bVar43) {
      *(undefined8 *)(&stack0x00000080 + lVar11) = 0;
      puVar25 = puVar35;
      if (uVar42 != 0) {
        puVar25 = puVar40;
      }
      uVar42 = -*(int *)(puVar25 + 8);
      *(uint *)(&stack0x00000074 + lVar11) = uVar42;
      uVar9 = *(undefined4 *)(puVar25 + 0xc);
      uVar4 = *(undefined4 *)(puVar25 + 10);
      *(undefined2 *)(&stack0xfffffffffffffff0 + lVar11) = 1;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = uVar9;
      if ((bVar17 & 1) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1020dc;
        func_0x(psVar2,&stack0x000001f8 + lVar11,0x1f9e,uVar4);
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1020d5;
        func_0x();
      }
      puVar27 = &stack0xffffffffffffffc8 + lVar11;
      if (uVar42 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x102106;
        lVar13 = func_0x();
        lVar13 = -lVar13;
        puVar27 = &stack0xffffffffffffffc8 + lVar13 + lVar11;
        puVar35 = (ushort *)((longlong)&uStackX_18 + lVar13 + lVar11);
        *(ushort **)(&stack0x00000080 + lVar11) = puVar35;
        *(undefined8 *)((longlong)&uStack_40 + lVar13 + lVar11) = 0x10211c;
        func_0x(puVar35,0);
      }
      uVar36 = (*param_2)[0x31];
      *(undefined8 *)(&stack0x00000058 + lVar11) = 0;
      puVar26 = (uint *)param_2[1];
      if (uVar36 != 0) {
        *(ulonglong *)(&stack0x00000078 + lVar11) = (ulonglong)uVar36;
        lVar13 = *(longlong *)(&stack0x00000080 + lVar11);
        do {
          uVar42 = *puVar26;
          *(undefined8 *)(puVar27 + -8) = 0x102161;
          func_0x(param_2,puVar26,&stack0x00000050 + lVar11);
          if ((&stack0x00000050)[lVar11] == '\x03') {
            if (((*(ushort *)(*(longlong *)(puVar26 + 0x12) + 0xc) & 0x400) == 0) &&
               ((puVar26[0x10] & 0x4000) == 0)) {
              *(undefined8 *)(puVar27 + -8) = 0x102478;
              (*_DAT_)(6,0x51,0x10,3);
            }
            *(undefined8 *)(puVar27 + -8) = 0x10248a;
            func_0x(psVar2,puVar26,0,0);
            if ((int)uVar42 < 0) {
              puVar3 = (uint *)((longlong)(int)~uVar42 * 0x20 + 0xc + lVar13);
              *puVar3 = *puVar3 | 2;
            }
          }
          else {
            if (*(short *)(puVar26 + 1) != 0) {
              if (*psVar2 == 0) {
                *(undefined8 *)(puVar27 + -8) = 0x102185;
                func_0x();
              }
              else {
                *(undefined8 *)(puVar27 + -8) = 0x10218c;
                func_0x((longlong)&uStackX_18 + lVar11 + 2,puVar26);
              }
            }
            *(undefined8 *)(puVar27 + -8) = 0x10219b;
            func_0x(param_2,puVar26,&stack0x00000058 + lVar11);
            cVar7 = *(char *)(puVar26 + 0x10);
            uVar23 = 0;
            if ((cVar7 == '\x01') || (cVar7 == '\x02')) {
              lVar12 = *(longlong *)(&stack0x00000058 + lVar11);
              if ((puVar26[0x10] >> 8 & 1) == 0) {
                uVar42 = *puVar26;
                lVar41 = *(longlong *)((longlong)&pbStackX_20 + lVar11);
                uVar8 = *(undefined2 *)(puVar26 + 0xf);
                *(undefined8 *)(puVar27 + -8) = 0x10234a;
                func_0x((int)uVar42 + lVar41,lVar12,uVar8);
              }
              else {
                iVar10 = 0;
                if (((puVar26[0x10] & 0x8000) == 0) ||
                   ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0)) {
                  if ((*(byte *)(*(longlong *)(puVar26 + 0x12) + 0x2a) & 0x10) == 0) {
                    puVar35 = param_2[3];
                  }
                  else {
                    puVar35 = param_2[4];
                  }
                  uVar42 = *(uint *)(*(longlong *)(*(longlong *)(puVar26 + 0x12) + 0x18) +
                                    (longlong)puVar35);
                }
                else {
                  uVar42 = *(uint *)(param_2[7] + (ulonglong)puVar26[0xe] * 4);
                }
                uVar23 = (uint)*(ushort *)(puVar26 + 0xf);
                if (uVar42 < uVar23) {
                  iVar10 = uVar23 - uVar42;
                }
                else if (uVar23 < uVar42) {
                  *(undefined8 *)(puVar27 + -8) = 0x1023b0;
                  (*_DAT_)(6,0x5c,0x16);
                }
                uVar16 = *(undefined *)(*(longlong *)(puVar26 + 0x12) + 0x24);
                lVar41 = (longlong)(int)*puVar26 + *(longlong *)((longlong)&pbStackX_20 + lVar11);
                if ((lVar12 != 0) && (uVar42 != 0)) {
                  *(undefined8 *)(puVar27 + -8) = 0x1023d7;
                  func_0x(lVar41,lVar12,uVar42);
                }
                if (iVar10 != 0) {
                  *(undefined8 *)(puVar27 + -8) = 0x1023eb;
                  func_0x((ulonglong)uVar42 + lVar41,uVar16,iVar10);
                }
                param_2 = *(ushort ***)(&stack0x00000060 + lVar11);
              }
            }
            else if ((cVar7 == '\x03') || (cVar7 == '\x04')) {
              uVar37 = puVar26[0x10];
              piVar22 = *(int **)(&stack0x00000058 + lVar11);
              if ((uVar37 >> 0xd & 1) == 0) {
                if (((uVar37 & 0x8000) == 0) || ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0)) {
                  lVar12 = *(longlong *)(puVar26 + 0x12);
                  if ((uVar37 >> 8 & 1) == 0) {
LAB_:
                    uVar23 = (uint)*(ushort *)(lVar12 + 2);
                  }
                  else if ((*(byte *)(lVar12 + 0x2a) & 0x10) == 0) {
                    uVar23 = *(uint *)(*(longlong *)(lVar12 + 0x18) + (longlong)param_2[3]);
                  }
                  else {
                    uVar23 = *(uint *)(*(longlong *)(lVar12 + 0x18) + (longlong)param_2[4]);
                  }
                }
                else {
                  uVar23 = *(uint *)(param_2[7] + (ulonglong)puVar26[0xe] * 4);
                }
              }
              else if (*piVar22 != 0) {
                if (((uVar37 & 0x8000) == 0) || ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0)) {
                  lVar12 = *(longlong *)(puVar26 + 0x12);
                  if ((uVar37 >> 8 & 1) == 0) goto LAB_;
                  if ((*(byte *)(lVar12 + 0x2a) & 0x10) == 0) {
                    uVar23 = *(uint *)(*(longlong *)(lVar12 + 0x18) + (longlong)param_2[3]);
                  }
                  else {
                    uVar23 = *(uint *)(*(longlong *)(lVar12 + 0x18) + (longlong)param_2[4]);
                  }
                }
                else {
                  uVar23 = *(uint *)(param_2[7] + (ulonglong)puVar26[0xe] * 4);
                }
              }
              if (*(ushort *)(puVar26 + 0xf) < uVar23) {
                *(undefined8 *)(puVar27 + -8) = 0x1022ff;
                (*_DAT_)(6,0x52,0x16);
                piVar22 = *(int **)(&stack0x00000058 + lVar11);
              }
              *(undefined4 *)(puVar27 + 0x28) = 0;
              *(uint **)(puVar27 + 0x20) = puVar26;
              *(undefined8 *)(puVar27 + -8) = 0x102324;
              func_0x((longlong)(int)~uVar42 * 0x20 + lVar13,piVar22,uVar23);
            }
            else if (cVar7 == '\b') {
              if (*psVar2 == 0) {
                uVar14 = *(undefined8 *)(&stack0x00000058 + lVar11);
                *(undefined8 *)(puVar27 + -8) = 0x102215;
                func_0x(psVar2,puVar26,uVar14);
              }
              else {
                *(undefined4 *)(puVar27 + 0x28) = 0;
                *(uint **)(puVar27 + 0x20) = puVar26;
                uVar14 = *(undefined8 *)(&stack0x00000058 + lVar11);
                *(undefined8 *)(puVar27 + -8) = 0x102240;
                func_0x((longlong)(int)~uVar42 * 0x20 + lVar13,uVar14,1);
              }
            }
            else {
              *(undefined8 *)(puVar27 + 0x20) = 0x15b06a0;
              *(undefined8 *)(puVar27 + -8) = 0x1021f3;
              (*_DAT_)(1,0x19b6a30,0x19e33f8);
            }
          }
          puVar26 = puVar26 + 0x14;
          plVar5 = (longlong *)(&stack0x00000078 + lVar11);
          *plVar5 = *plVar5 + -1;
        } while (*plVar5 != 0);
        uVar42 = *(uint *)(&stack0x00000074 + lVar11);
        puVar35 = *(ushort **)(&stack0x00000080 + lVar11);
      }
      puVar40 = (ushort *)0x0;
      if (uVar42 != 0) {
        if (*psVar2 == 0) {
          do {
            uVar33 = (ulonglong)uVar42;
            uVar23 = uVar42 - 1;
            if (*(int *)(puVar35 + (ulonglong)uVar23 * 0x10 + 4) != 0) {
              *(ushort *)(&stack0x00000034 + lVar11) = (ushort)uVar42;
              iVar10 = *(int *)(&stack0x0000002c + lVar11) + 2 + uVar42 * 2;
              *(int *)(&stack0x00000030 + lVar11) = iVar10;
              *(int *)((longlong)&uStackX_18 + lVar11 + 4) = iVar10;
              **(byte **)((longlong)&pbStackX_20 + lVar11) =
                   **(byte **)((longlong)&pbStackX_20 + lVar11) | 0x20;
              uVar23 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
              if (uVar23 < 0x1f7d) {
                puVar40 = (ushort *)
                          ((ulonglong)*(uint *)(&stack0x0000002c + lVar11) +
                          *(longlong *)((longlong)&pbStackX_20 + lVar11));
                *puVar40 = (ushort)uVar42;
                uVar23 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
              }
              if (uVar42 != 0) {
                puVar26 = (uint *)(puVar35 + 6);
                do {
                  puVar40 = puVar40 + 1;
                  uVar24 = (ulonglong)uVar23;
                  lVar13 = *(longlong *)((longlong)&pbStackX_20 + lVar11);
                  uVar42 = puVar26[-1];
                  uVar23 = uVar23 + uVar42;
                  *(uint *)((longlong)&uStackX_18 + lVar11 + 4) = uVar23;
                  if (uVar23 < 0x1f7d) {
                    *puVar40 = (ushort)((*puVar26 & 1) << 0xf) | (ushort)uVar23 & 0x7fff;
                    uVar14 = *(undefined8 *)(puVar26 + -3);
                    *(undefined8 *)(puVar27 + -8) = 0x102529;
                    func_0x(uVar24 + lVar13,uVar42,uVar14,uVar42);
                    uVar23 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                  }
                  puVar26 = puVar26 + 8;
                  uVar33 = uVar33 - 1;
                } while (uVar33 != 0);
              }
              break;
            }
            uVar42 = uVar23;
          } while (uVar23 != 0);
        }
        else {
          *(undefined **)(puVar27 + 0x28) = &stack0x0000008c + lVar11;
          *(ushort **)(puVar27 + 0x20) = puVar35;
          *(undefined8 *)(puVar27 + -8) = 0x102562;
          func_0x((longlong)&uStackX_18 + lVar11 + 2,0x1f9e,0x1f7c,uVar42);
        }
      }
    }
    else {
      *psVar2 = 0;
      *(undefined8 *)(&stack0x00000078 + lVar11) = 0;
      puVar25 = puVar35;
      if (uVar42 != 0) {
        puVar25 = puVar40;
      }
      uVar42 = -*(int *)(puVar25 + 8);
      *(uint *)(&stack0x00000074 + lVar11) = uVar42;
      uVar16 = 0;
      bVar43 = (bVar17 & 1) == 0;
      if (bVar43) {
        uVar16 = 6;
      }
      iVar10 = 4;
      if (bVar43) {
        iVar10 = 1;
      }
      iVar20 = *(int *)(puVar25 + 10);
      (&stack0xfffffffffffffff0)[lVar11] = uVar16;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = *(undefined4 *)(puVar25 + 0xc);
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100189;
      func_0x
                ((longlong)&uStackX_18 + lVar11 + 2,&stack0x000001f8 + lVar11,0x1f9e,iVar20 - iVar10
                );
      if (uVar42 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1001b1;
        lVar12 = func_0x();
        lVar12 = -lVar12;
        puVar27 = &stack0xffffffffffffffc8 + lVar12 + lVar11;
        lVar13 = (longlong)&uStackX_18 + lVar12 + lVar11;
        *(longlong *)(&stack0x00000078 + lVar11) = lVar13;
        *(undefined8 *)((longlong)&uStack_40 + lVar12 + lVar11) = 0x1001c7;
        func_0x(lVar13,0);
      }
      uVar36 = (*param_2)[0x31];
      *(uint *)(&stack0x000000a4 + lVar11) = (uint)uVar36;
      *(undefined8 *)(&stack0x00000090 + lVar11) = 0;
      *(undefined4 *)(&stack0x00000088 + lVar11) = 0;
      puVar26 = (uint *)param_2[1];
      *(uint **)(&stack0x00000058 + lVar11) = puVar26;
      if (uVar36 != 0) {
        do {
          uVar42 = *puVar26;
          *(undefined8 *)(puVar27 + -8) = 0x100212;
          func_0x(param_2,puVar26,&stack0x00000050 + lVar11);
          if ((&stack0x00000050)[lVar11] == '\x03') {
            if (((*(ushort *)(*(longlong *)(puVar26 + 0x12) + 0xc) & 0x400) == 0) &&
               ((puVar26[0x10] & 0x4000) == 0)) {
              *(undefined8 *)(puVar27 + -8) = 0x101fbe;
              (*_DAT_)(6,0x51,0x10,3);
            }
            *(undefined8 *)(puVar27 + -8) = 0x101fd0;
            func_0x((longlong)&uStackX_18 + lVar11 + 2,puVar26,0,0);
            if ((int)uVar42 < 0) {
              puVar3 = (uint *)((longlong)(int)~uVar42 * 0x20 + 0xc +
                               *(longlong *)(&stack0x00000078 + lVar11));
              *puVar3 = *puVar3 | 2;
            }
            goto LAB_;
          }
          if (*(short *)(puVar26 + 1) != 0) {
            *(undefined8 *)(puVar27 + -8) = 0x100230;
            func_0x((longlong)&uStackX_18 + lVar11 + 2,puVar26);
          }
          *(undefined8 *)(puVar27 + -8) = 0x10023f;
          func_0x(param_2,puVar26,&stack0x00000090 + lVar11);
          cVar7 = *(char *)(puVar26 + 0x10);
          if ((cVar7 == '\x01') || (cVar7 == '\x02')) {
            lVar13 = *(longlong *)(&stack0x00000090 + lVar11);
            puVar26 = *(uint **)(&stack0x00000058 + lVar11);
            if ((puVar26[0x10] >> 8 & 1) == 0) {
              uVar42 = *puVar26;
              lVar12 = *(longlong *)((longlong)&pbStackX_20 + lVar11);
              uVar8 = *(undefined2 *)(puVar26 + 0xf);
              *(undefined8 *)(puVar27 + -8) = 0x101eed;
              func_0x((int)uVar42 + lVar12,lVar13,uVar8);
              goto LAB_;
            }
            iVar10 = 0;
            if (((puVar26[0x10] & 0x8000) == 0) || ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0))
            {
              if ((*(byte *)(*(longlong *)(puVar26 + 0x12) + 0x2a) & 0x10) == 0) {
                puVar40 = param_2[3];
              }
              else {
                puVar40 = param_2[4];
              }
              uVar42 = *(uint *)(*(longlong *)(*(longlong *)(puVar26 + 0x12) + 0x18) +
                                (longlong)puVar40);
            }
            else {
              uVar42 = *(uint *)(param_2[7] + (ulonglong)puVar26[0xe] * 4);
            }
            uVar37 = (uint)*(ushort *)(puVar26 + 0xf);
            if (uVar42 < uVar37) {
              iVar10 = uVar37 - uVar42;
            }
            else if (uVar37 < uVar42) {
              *(undefined8 *)(puVar27 + -8) = 0x101f50;
              (*_DAT_)(6,0x5c,0x16);
            }
            uVar16 = *(undefined *)(*(longlong *)(puVar26 + 0x12) + 0x24);
            lVar12 = (longlong)(int)*puVar26 + *(longlong *)((longlong)&pbStackX_20 + lVar11);
            if ((lVar13 != 0) && (uVar42 != 0)) {
              *(undefined8 *)(puVar27 + -8) = 0x101f77;
              func_0x(lVar12,lVar13,uVar42);
            }
            if (iVar10 != 0) {
              *(undefined8 *)(puVar27 + -8) = 0x101f8f;
              func_0x((ulonglong)uVar42 + lVar12,uVar16,iVar10);
            }
LAB_:
            param_2 = *(ushort ***)(&stack0x00000060 + lVar11);
            puVar26 = *(uint **)(&stack0x00000058 + lVar11);
          }
          else if ((cVar7 == '\x03') || (cVar7 == '\x04')) {
            uVar37 = puVar26[0x10];
            piVar22 = *(int **)(&stack0x00000090 + lVar11);
            if (((uVar37 >> 0xd & 1) == 0) || (uVar34 = uVar23, *piVar22 != 0)) {
              if (((uVar37 & 0x8000) == 0) || ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0)) {
                lVar13 = *(longlong *)(puVar26 + 0x12);
                if ((uVar37 >> 8 & 1) == 0) {
                  uVar34 = (uint)*(ushort *)(lVar13 + 2);
                }
                else if ((*(byte *)(lVar13 + 0x2a) & 0x10) == 0) {
                  uVar34 = *(uint *)(*(longlong *)(lVar13 + 0x18) + (longlong)param_2[3]);
                }
                else {
                  uVar34 = *(uint *)(*(longlong *)(lVar13 + 0x18) + (longlong)param_2[4]);
                }
              }
              else {
                uVar34 = *(uint *)(param_2[7] + (ulonglong)puVar26[0xe] * 4);
              }
            }
            if (*(ushort *)(puVar26 + 0xf) < uVar34) {
              *(undefined8 *)(puVar27 + -8) = 0x101e9a;
              (*_DAT_)(6,0x52,0x16);
              piVar22 = *(int **)(&stack0x00000090 + lVar11);
            }
            lVar13 = *(longlong *)(&stack0x00000078 + lVar11);
            *(undefined4 *)(puVar27 + 0x28) = 0;
            *(uint **)(puVar27 + 0x20) = puVar26;
            *(undefined8 *)(puVar27 + -8) = 0x101ec3;
            func_0x((longlong)(int)~uVar42 * 0x20 + lVar13,piVar22,uVar34);
          }
          else if (cVar7 == '\b') {
            *(char **)(&stack0x00000098 + lVar11) = *(char **)(&stack0x00000090 + lVar11);
            uVar42 = *puVar26;
            if ((int)uVar42 < 0) {
              if ((uVar42 & 0xc0000000) != 0x80000000) {
                if (*(int *)((longlong)&uStackX_18 + lVar11 + 4) == 0) {
                  *(undefined2 *)((longlong)&uStackX_18 + lVar11 + 2) = 0;
                  uVar42 = *(uint *)(&stack0x00000028 + lVar11);
                  uVar33 = (ulonglong)uVar42;
                  *(uint *)(&stack0x0000002c + lVar11) = uVar42;
                  pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                  if ((*pbVar21 & 0x10) != 0) {
                    uVar42 = uVar42 + 2 + (*(ushort *)(pbVar21 + uVar33) + 7 >> 3);
                    uVar33 = (ulonglong)uVar42;
                    *(uint *)(&stack0x0000002c + lVar11) = uVar42;
                  }
                  uVar42 = (uint)uVar33;
                  if ((*pbVar21 & 0x20) == 0) {
                    *(uint *)((longlong)&uStackX_18 + lVar11 + 4) = uVar42;
                    *(undefined2 *)(&stack0x00000034 + lVar11) = 0;
                    *(uint *)(&stack0x00000030 + lVar11) = uVar42;
                  }
                  else {
                    puVar40 = (ushort *)(pbVar21 + uVar33);
                    uVar36 = *puVar40;
                    *(ushort *)(&stack0x00000034 + lVar11) = uVar36;
                    if (uVar36 == 0) {
                      *(undefined8 *)(puVar27 + -8) = 0x100aa0;
                      cVar7 = func_0x(0x1f45730);
                      if (cVar7 != '\0') {
                        *(undefined8 *)(puVar27 + -8) = 0x100aa9;
                        lVar13 = func_0x();
                        if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar27 + -8) = 0x100ac3;
                          cVar7 = func_0x(0x1f45730);
                          if (cVar7 == '\0') {
                            *(undefined8 *)(puVar27 + -8) = 0x100adf;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(puVar27 + 0x20) = 0;
                            *(undefined8 *)(puVar27 + -8) = 0x100b05;
                            (*_DAT_)(1,0x183513c,0x1955228,0x80f);
                          }
                        }
                      }
                      uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                      *(undefined8 *)(puVar27 + -8) = 0x100b13;
                      func_0x(uVar14,3);
                      uVar36 = *(ushort *)(&stack0x00000034 + lVar11);
                      uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar11);
                      pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                    }
                    uVar37 = (int)uVar33 + (uVar36 + 1) * 2;
                    *(uint *)(&stack0x00000030 + lVar11) = uVar37;
                    if (0x1f9e < uVar37) {
                      *(undefined8 *)(puVar27 + -8) = 0x100b48;
                      cVar7 = func_0x(0x1f45730);
                      if (cVar7 != '\0') {
                        *(undefined8 *)(puVar27 + -8) = 0x100b51;
                        lVar13 = func_0x();
                        if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar27 + -8) = 0x100b6b;
                          cVar7 = func_0x(0x1f45730);
                          if (cVar7 == '\0') {
                            *(undefined8 *)(puVar27 + -8) = 0x100b87;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar27 + 0x20) = 0;
                            *(undefined8 *)(puVar27 + -8) = 0x100bad;
                            (*_DAT_)(1,0x183513c,0x1955228,0x816);
                          }
                        }
                      }
                      uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                      *(undefined8 *)(puVar27 + -8) = 0x100bbb;
                      func_0x(uVar14,4);
                      uVar36 = *(ushort *)(&stack0x00000034 + lVar11);
                      uVar37 = *(uint *)(&stack0x00000030 + lVar11);
                      uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar11);
                      pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                    }
                    uVar24 = (ulonglong)uVar36;
                    uVar42 = puVar40[uVar24] & 0x7fff;
                    *(uint *)((longlong)&uStackX_18 + lVar11 + 4) = uVar42;
                    if (uVar42 < uVar37) {
                      *(undefined8 *)(puVar27 + -8) = 0x100bf1;
                      cVar7 = func_0x(0x1f45730);
                      if (cVar7 != '\0') {
                        *(undefined8 *)(puVar27 + -8) = 0x100bfa;
                        lVar13 = func_0x();
                        if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar27 + -8) = 0x100c14;
                          cVar7 = func_0x(0x1f45730);
                          if (cVar7 == '\0') {
                            *(undefined8 *)(puVar27 + -8) = 0x100c30;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar27 + 0x20) = 0;
                            *(undefined8 *)(puVar27 + -8) = 0x100c56;
                            (*_DAT_)(1,0x183513c,0x1955228,0x81d);
                          }
                        }
                      }
                      uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                      *(undefined8 *)(puVar27 + -8) = 0x100c64;
                      func_0x(uVar14,4);
                      uVar24 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar11);
                      uVar37 = *(uint *)(&stack0x00000030 + lVar11);
                      uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar11);
                      pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                      uVar42 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                    }
                    puVar32 = puVar35;
                    puVar25 = puVar40;
                    if ((short)uVar24 != 0) {
                      do {
                        uVar34 = puVar25[1] & 0x7fff;
                        if ((uVar34 < uVar37) || (uVar42 < uVar34)) {
                          *(undefined8 *)(puVar27 + -8) = 0x100cb0;
                          cVar7 = func_0x(0x1f45730);
                          if (cVar7 != '\0') {
                            *(undefined8 *)(puVar27 + -8) = 0x100cb9;
                            lVar13 = func_0x();
                            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar27 + -8) = 0x100cd3;
                              cVar7 = func_0x(0x1f45730);
                              if (cVar7 == '\0') {
                                *(undefined8 *)(puVar27 + -8) = 0x100cef;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar27 + 0x20) = 0;
                                *(undefined8 *)(puVar27 + -8) = 0x100d15;
                                (*_DAT_)(1,0x183513c,0x1955228,0x82a);
                              }
                            }
                          }
                          uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                          *(undefined8 *)(puVar27 + -8) = 0x100d23;
                          func_0x(uVar14,4);
                          uVar24 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar11);
                          pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                          uVar42 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                        }
                        uVar29 = (int)puVar32 + 1;
                        puVar32 = (ushort *)(ulonglong)uVar29;
                        puVar25 = puVar25 + 1;
                        uVar37 = uVar34;
                      } while ((int)uVar29 < (int)uVar24);
                      uVar37 = *(uint *)(&stack0x00000030 + lVar11);
                      uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar11);
                    }
                    while ((short)puVar40[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                      uVar34 = uVar37;
                      if ((int)uVar24 != 1) {
                        uVar34 = *(ushort *)(pbVar21 + uVar24 * 2 + (uVar33 - 2)) & 0x7fff;
                      }
                      uVar29 = *(ushort *)(pbVar21 + uVar24 * 2 + uVar33) & 0x7fff;
                      if (((uVar34 < uVar37) || (uVar29 < uVar34)) || (uVar42 < uVar29)) {
                        *(undefined8 *)(puVar27 + -8) = 0x100da0;
                        func_0x(pbVar21,7);
                        uVar24 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar11);
                        uVar37 = *(uint *)(&stack0x00000030 + lVar11);
                        uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar11);
                        pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                        uVar42 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                      }
                      if ((uVar34 < uVar37) || (uVar42 < uVar34)) goto LAB_;
                      if (*(ushort *)(pbVar21 + uVar34) == 5) {
                        puVar40 = (ushort *)((longlong)&uStackX_18 + lVar11 + 2);
                        *puVar40 = *puVar40 | 2;
                        *(short *)(&stack0x00000034 + lVar11) = (short)uVar24 + -1;
                        uVar33 = (ulonglong)(uVar34 & 0xffff);
                        *(short *)(&stack0x00000042 + lVar11) = (short)uVar34;
                        pbVar1 = pbVar21 + uVar33;
                        uVar36 = *(ushort *)(&stack0x00000044 + lVar11);
                        if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                          uVar36 = uVar36 & 0xc7ff;
                        }
                        else {
                          uVar36 = uVar36 ^ (*(ushort *)(pbVar1 + 2) ^ uVar36) & 0x3800;
                        }
                        *(ushort *)(&stack0x00000044 + lVar11) = uVar36;
                        uVar38 = (uVar36 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar36;
                        uVar24 = (ulonglong)uVar38;
                        *(ushort *)(&stack0x00000044 + lVar11) = uVar38;
                        pbVar31 = pbVar21 + (ulonglong)((uVar36 >> 0xb & 7) * 2) + 4 + uVar33 +
                                            (uVar24 & 0x7ff) * 2;
                        if (pbVar31 < pbVar1) {
                          *(undefined8 *)(puVar27 + -8) = 0x100e9b;
                          func_0x(pbVar1,0x19);
                          uVar24 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar11);
                          uVar33 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar11);
                          pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                          uVar42 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                        }
                        if (uVar29 - uVar34 <
                            (((*(uint *)(&stack0x00000044 + lVar11) & 0x7ff) * 2 - (int)uVar33) -
                            *(int *)((longlong)&pbStackX_20 + lVar11)) + (int)pbVar31) {
                          *(undefined8 *)(puVar27 + -8) = 0x100ed5;
                          func_0x(pbVar21 + uVar33,0x19);
                          uVar24 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar11);
                          uVar33 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar11);
                          pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                          uVar42 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                        }
                        if (((uVar24 & 0x3800) != 0) &&
                           (puVar25 = (ushort *)(pbVar21 + uVar33 + 4), puVar40 = puVar35,
                           (uVar24 & 0x3800) != 0)) {
                          do {
                            if (((ushort)uVar24 & 0x7ff) < (*puVar25 & 0x7ff)) {
                              *(undefined8 *)(puVar27 + -8) = 0x100f35;
                              func_0x(pbVar21 + uVar33,0x1a);
                              uVar24 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar11);
                              uVar33 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar11);
                              pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                            }
                            uVar42 = (int)puVar40 + 1;
                            puVar40 = (ushort *)(ulonglong)uVar42;
                            puVar25 = puVar25 + 1;
                          } while ((int)uVar42 <
                                   (int)(*(uint *)(&stack0x00000044 + lVar11) >> 0xb & 7));
                          uVar42 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                        }
                        break;
                      }
                      if (*(ushort *)(pbVar21 + uVar34) < 0x400) break;
                      puVar25 = (ushort *)((longlong)&uStackX_18 + lVar11 + 2);
                      *puVar25 = *puVar25 | 1;
                      uVar36 = (short)uVar24 - 1;
                      uVar24 = (ulonglong)uVar36;
                      *(ushort *)(&stack0x00000034 + lVar11) = uVar36;
                      if (uVar36 == 0) break;
                    }
                  }
                  if ((*pbVar21 & 0x40) == 0) {
                    *(undefined4 *)(&stack0x0000003e + lVar11) = 0;
                  }
                  else {
                    *(uint *)(&stack0x0000003e + lVar11) = uVar42;
                    *(uint *)((longlong)&uStackX_18 + lVar11 + 4) = uVar42 + 0xe;
                    *(undefined8 *)(puVar27 + -8) = 0x100f87;
                    uVar14 = func_0x((longlong)&uStackX_18 + lVar11 + 2);
                    *(undefined8 *)(puVar27 + -8) = 0x100f96;
                    func_0x(uVar14,&stack0x000000b8 + lVar11);
                    *(undefined8 *)(puVar27 + -8) = 0x100fa2;
                    iVar10 = func_0x(&stack0x000000b8 + lVar11);
                    uVar42 = *(int *)((longlong)&uStackX_18 + lVar11 + 4) + iVar10;
                    *(uint *)((longlong)&uStackX_18 + lVar11 + 4) = uVar42;
                    pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                  }
                  if ((*(byte **)(&stack0x00000036 + lVar11) != (byte *)0x0) &&
                     (*(byte **)(&stack0x00000036 + lVar11) < pbVar21 + uVar42)) {
                    *(undefined8 *)(puVar27 + -8) = 0x100fdf;
                    cVar7 = func_0x(0x1f45730);
                    if (cVar7 != '\0') {
                      *(undefined8 *)(puVar27 + -8) = 0x100fe8;
                      lVar13 = func_0x();
                      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar27 + -8) = 0x101002;
                        cVar7 = func_0x(0x1f45730);
                        if (cVar7 == '\0') {
                          *(undefined8 *)(puVar27 + -8) = 0x10101e;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(puVar27 + 0x20) = 0;
                          *(undefined8 *)(puVar27 + -8) = 0x101044;
                          (*_DAT_)(1,0x183513c,0x1955228);
                        }
                      }
                    }
                    uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                    *(undefined8 *)(puVar27 + -8) = 0x101052;
                    func_0x(uVar14,0x12);
                    uVar42 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                  }
                  if (0x3f3b < uVar42 - 1) {
                    *(undefined8 *)(puVar27 + -8) = 0x10106d;
                    cVar7 = func_0x(0x1f45730);
                    if (cVar7 != '\0') {
                      *(undefined8 *)(puVar27 + -8) = 0x101076;
                      lVar13 = func_0x();
                      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar27 + -8) = 0x101090;
                        cVar7 = func_0x(0x1f45730);
                        if (cVar7 == '\0') {
                          *(undefined8 *)(puVar27 + -8) = 0x1010ac;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(puVar27 + 0x20) = 0;
                          *(undefined8 *)(puVar27 + -8) = 0x1010d2;
                          (*_DAT_)(1,0x183513c,0x1955228);
                        }
                      }
                    }
                    uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                    *(undefined8 *)(puVar27 + -8) = 0x1010e0;
                    func_0x(uVar14,5);
                  }
                }
LAB_:
                uVar42 = -**(int **)(&stack0x00000058 + lVar11);
                *(undefined8 *)(puVar27 + -8) = 0x1010f6;
                func_0x(&stack0x00000118 + lVar11);
                pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                bVar17 = *pbVar21;
                if ((bVar17 >> 6 & 1) != 0) {
                  *(undefined8 *)(puVar27 + -8) = 0x101118;
                  func_0x
                            ((longlong)&uStackX_18 + lVar11 + 2,&stack0x00000118 + lVar11);
                  pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                }
                if ((*pbVar21 & 0x20) == 0) {
                  *(undefined8 *)(puVar27 + -8) = 0x10112b;
                  func_0x((longlong)&uStackX_18 + lVar11 + 2);
                  pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                }
                uVar36 = *(ushort *)(&stack0x00000034 + lVar11);
                uVar34 = (uint)uVar36;
                uVar37 = (uint)uVar36;
                if (uVar37 < uVar42) {
                  puVar40 = (ushort *)(pbVar21 + *(uint *)(&stack0x0000002c + lVar11));
                  uVar34 = *(uint *)(&stack0x0000002c + lVar11) + 2 + uVar37 * 2;
                  uVar29 = (uVar42 - uVar36) * 2;
                  puVar25 = puVar35;
                  if (*puVar40 != 0) {
                    do {
                      uVar38 = puVar40[(longlong)puVar25 + 1];
                      puVar40[((ulonglong)puVar25 & 0xffff) + 1] =
                           puVar40[((ulonglong)puVar25 & 0xffff) + 1] & 0x8000;
                      puVar40[((ulonglong)puVar25 & 0xffff) + 1] =
                           puVar40[((ulonglong)puVar25 & 0xffff) + 1] |
                           (uVar38 & 0x7fff) + (short)uVar29 & 0x7fff;
                      uVar19 = (int)puVar25 + 1;
                      puVar25 = (ushort *)(ulonglong)uVar19;
                    } while (uVar19 < *puVar40);
                    pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                  }
                  iVar10 = *(int *)((longlong)&uStackX_18 + lVar11 + 4);
                  *(undefined8 *)(puVar27 + -8) = 0x1011ba;
                  func_0x
                            (pbVar21 + (ulonglong)uVar29 + (ulonglong)uVar34,pbVar21 + uVar34,
                             iVar10 - uVar34);
                  piVar22 = (int *)((longlong)&uStackX_18 + lVar11 + 4);
                  *piVar22 = *piVar22 + uVar29;
                  uVar29 = *(int *)(&stack0x00000030 + lVar11) + uVar29;
                  *(uint *)(&stack0x00000030 + lVar11) = uVar29;
                  if (uVar36 != 0) {
                    uVar29 = puVar40[(ulonglong)(uVar37 - 1) + 1] & 0x7fff;
                  }
                  do {
                    puVar40[(ulonglong)(uVar37 & 0xffff) + 1] = (ushort)uVar29 & 0x7fff;
                    uVar37 = uVar37 + 1;
                  } while (uVar37 < uVar42);
                  *puVar40 = *puVar40 + (short)(uVar42 - uVar36);
                  *(undefined8 *)(puVar27 + -8) = 0x1011fc;
                  iVar10 = func_0x((longlong)&uStackX_18 + lVar11 + 2);
                  if (iVar10 != 0) {
                    *(undefined8 *)(puVar27 + -8) = 0x101210;
                    uVar8 = func_0x
                                      ((longlong)&uStackX_18 + lVar11 + 2,&stack0x000000a8 + lVar11)
                    ;
                    *(undefined2 *)(&stack0x00000042 + lVar11) = uVar8;
                  }
                  uVar34 = uVar42 & 0xffff;
                  *(short *)(&stack0x00000034 + lVar11) = (short)uVar42;
                  pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                }
                uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar11);
                if (uVar34 < uVar42) {
                  uVar37 = *(ushort *)(pbVar21 + (ulonglong)uVar34 * 2 + uVar33) & 0x7fff;
                  uVar34 = uVar23;
LAB_:
                  puVar40 = (ushort *)(pbVar21 + uVar33);
                  uVar9 = *(undefined4 *)((longlong)&uStackX_18 + lVar11 + 4);
                  *(undefined8 *)(puVar27 + -8) = 0x1012ad;
                  uVar9 = func_0x(uVar9,uVar34 + uVar37);
                  lVar13 = *(longlong *)((longlong)&pbStackX_20 + lVar11);
                  *(undefined8 *)(puVar27 + -8) = 0x1012c9;
                  func_0x
                            (lVar13 + 1 + (ulonglong)uVar37,
                             (longlong)(int)uVar34 + (ulonglong)uVar37 + lVar13,uVar9);
                  uVar42 = uVar42 - 1;
                  if ((int)uVar42 < (int)(uint)*puVar40) {
                    do {
                      uVar36 = puVar40[(longlong)(int)uVar42 + 1];
                      puVar40[((ulonglong)uVar42 & 0xffff) + 1] =
                           puVar40[((ulonglong)uVar42 & 0xffff) + 1] & 0x8000;
                      puVar40[((ulonglong)uVar42 & 0xffff) + 1] =
                           puVar40[((ulonglong)uVar42 & 0xffff) + 1] |
                           ((uVar36 & 0x7fff) - (short)uVar34) + 1 & 0x7fff;
                      uVar42 = uVar42 + 1;
                    } while ((int)uVar42 < (int)(uint)*puVar40);
                  }
                  piVar22 = (int *)((longlong)&uStackX_18 + lVar11 + 4);
                  *piVar22 = *piVar22 + (1 - uVar34);
                  *(undefined8 *)(puVar27 + -8) = 0x101320;
                  iVar10 = func_0x((longlong)&uStackX_18 + lVar11 + 2);
                  if (iVar10 != 0) {
                    *(undefined8 *)(puVar27 + -8) = 0x101334;
                    uVar8 = func_0x
                                      ((longlong)&uStackX_18 + lVar11 + 2,&stack0x000000ac + lVar11)
                    ;
                    *(undefined2 *)(&stack0x00000042 + lVar11) = uVar8;
                  }
                  pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                }
                else {
                  uVar37 = *(uint *)(&stack0x00000030 + lVar11);
                  if (uVar42 != 1) {
                    uVar37 = *(ushort *)(pbVar21 + (longlong)(int)uVar42 * 2 + (uVar33 - 2)) &
                             0x7fff;
                  }
                  uVar34 = *(ushort *)(pbVar21 + (longlong)(int)uVar42 * 2 + uVar33) & 0x7fff;
                  if (((uVar37 < *(uint *)(&stack0x00000030 + lVar11)) || (uVar34 < uVar37)) ||
                     (*(uint *)((longlong)&uStackX_18 + lVar11 + 4) < uVar34)) {
                    *(undefined8 *)(puVar27 + -8) = 0x101273;
                    func_0x(pbVar21,7);
                    uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar11);
                    pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                  }
                  uVar34 = uVar34 - uVar37;
                  if (uVar34 != 1) goto LAB_;
                }
                pbVar21[uVar37] = **(byte **)(&stack0x00000098 + lVar11);
                if ((bVar17 >> 6 & 1) != 0) {
                  *(undefined8 *)(puVar27 + -8) = 0x101362;
                  func_0x
                            ((longlong)&uStackX_18 + lVar11 + 2,&stack0x00000118 + lVar11);
                }
                goto LAB_;
              }
              *(undefined8 *)(puVar27 + -8) = 0x1014a5;
              func_0x(&stack0x00000118 + lVar11);
              *(undefined4 *)(&stack0x00000070 + lVar11) = 0;
              if (*(int *)((longlong)&uStackX_18 + lVar11 + 4) == 0) {
                *(undefined2 *)((longlong)&uStackX_18 + lVar11 + 2) = 0;
                uVar42 = *(uint *)(&stack0x00000028 + lVar11);
                uVar33 = (ulonglong)uVar42;
                *(uint *)(&stack0x0000002c + lVar11) = uVar42;
                pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                if ((*pbVar21 & 0x10) != 0) {
                  uVar42 = uVar42 + 2 + (*(ushort *)(pbVar21 + uVar33) + 7 >> 3);
                  uVar33 = (ulonglong)uVar42;
                  *(uint *)(&stack0x0000002c + lVar11) = uVar42;
                }
                uVar42 = (uint)uVar33;
                if ((*pbVar21 & 0x20) == 0) {
                  *(uint *)((longlong)&uStackX_18 + lVar11 + 4) = uVar42;
                  *(undefined2 *)(&stack0x00000034 + lVar11) = 0;
                  *(uint *)(&stack0x00000030 + lVar11) = uVar42;
                }
                else {
                  puVar40 = (ushort *)(pbVar21 + uVar33);
                  uVar36 = *puVar40;
                  *(ushort *)(&stack0x00000034 + lVar11) = uVar36;
                  if (uVar36 == 0) {
                    *(undefined8 *)(puVar27 + -8) = 0x10150f;
                    cVar7 = func_0x(0x1f45730);
                    if (cVar7 != '\0') {
                      *(undefined8 *)(puVar27 + -8) = 0x101518;
                      lVar13 = func_0x();
                      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar27 + -8) = 0x101532;
                        cVar7 = func_0x(0x1f45730);
                        if (cVar7 == '\0') {
                          *(undefined8 *)(puVar27 + -8) = 0x10154e;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(puVar27 + 0x20) = 0;
                          *(undefined8 *)(puVar27 + -8) = 0x101574;
                          (*_DAT_)(1,0x183513c,0x1955228,0x80f);
                        }
                      }
                    }
                    uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                    *(undefined8 *)(puVar27 + -8) = 0x101582;
                    func_0x(uVar14,3);
                    uVar36 = *(ushort *)(&stack0x00000034 + lVar11);
                    uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar11);
                    pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                  }
                  uVar37 = (int)uVar33 + (uVar36 + 1) * 2;
                  *(uint *)(&stack0x00000030 + lVar11) = uVar37;
                  if (0x1f9e < uVar37) {
                    *(undefined8 *)(puVar27 + -8) = 0x1015b7;
                    cVar7 = func_0x(0x1f45730);
                    if (cVar7 != '\0') {
                      *(undefined8 *)(puVar27 + -8) = 0x1015c0;
                      lVar13 = func_0x();
                      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar27 + -8) = 0x1015da;
                        cVar7 = func_0x(0x1f45730);
                        if (cVar7 == '\0') {
                          *(undefined8 *)(puVar27 + -8) = 0x1015f6;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar27 + 0x20) = 0;
                          *(undefined8 *)(puVar27 + -8) = 0x10161c;
                          (*_DAT_)(1,0x183513c,0x1955228,0x816);
                        }
                      }
                    }
                    uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                    *(undefined8 *)(puVar27 + -8) = 0x10162a;
                    func_0x(uVar14,4);
                    uVar36 = *(ushort *)(&stack0x00000034 + lVar11);
                    uVar37 = *(uint *)(&stack0x00000030 + lVar11);
                    uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar11);
                    pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                  }
                  uVar24 = (ulonglong)uVar36;
                  uVar42 = puVar40[uVar24] & 0x7fff;
                  *(uint *)((longlong)&uStackX_18 + lVar11 + 4) = uVar42;
                  if (uVar42 < uVar37) {
                    *(undefined8 *)(puVar27 + -8) = 0x101660;
                    cVar7 = func_0x(0x1f45730);
                    if (cVar7 != '\0') {
                      *(undefined8 *)(puVar27 + -8) = 0x101669;
                      lVar13 = func_0x();
                      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar27 + -8) = 0x101683;
                        cVar7 = func_0x(0x1f45730);
                        if (cVar7 == '\0') {
                          *(undefined8 *)(puVar27 + -8) = 0x10169f;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar27 + 0x20) = 0;
                          *(undefined8 *)(puVar27 + -8) = 0x1016c5;
                          (*_DAT_)(1,0x183513c,0x1955228,0x81d);
                        }
                      }
                    }
                    uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                    *(undefined8 *)(puVar27 + -8) = 0x1016d3;
                    func_0x(uVar14,4);
                    uVar24 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar11);
                    uVar37 = *(uint *)(&stack0x00000030 + lVar11);
                    uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar11);
                    pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                    uVar42 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                  }
                  puVar32 = puVar35;
                  puVar25 = puVar40;
                  if ((short)uVar24 != 0) {
                    do {
                      uVar34 = puVar25[1] & 0x7fff;
                      if ((uVar34 < uVar37) || (uVar42 < uVar34)) {
                        *(undefined8 *)(puVar27 + -8) = 0x101720;
                        cVar7 = func_0x(0x1f45730);
                        if (cVar7 != '\0') {
                          *(undefined8 *)(puVar27 + -8) = 0x101729;
                          lVar13 = func_0x();
                          if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar27 + -8) = 0x101743;
                            cVar7 = func_0x(0x1f45730);
                            if (cVar7 == '\0') {
                              *(undefined8 *)(puVar27 + -8) = 0x10175f;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar27 + 0x20) = 0;
                              *(undefined8 *)(puVar27 + -8) = 0x101785;
                              (*_DAT_)(1,0x183513c,0x1955228,0x82a);
                            }
                          }
                        }
                        uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                        *(undefined8 *)(puVar27 + -8) = 0x101793;
                        func_0x(uVar14,4);
                        uVar24 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar11);
                        pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                        uVar42 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                      }
                      uVar29 = (int)puVar32 + 1;
                      puVar32 = (ushort *)(ulonglong)uVar29;
                      puVar25 = puVar25 + 1;
                      uVar37 = uVar34;
                    } while ((int)uVar29 < (int)uVar24);
                    uVar37 = *(uint *)(&stack0x00000030 + lVar11);
                    uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar11);
                  }
                  while ((short)puVar40[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                    uVar34 = uVar37;
                    if ((int)uVar24 != 1) {
                      uVar34 = *(ushort *)(pbVar21 + uVar24 * 2 + (uVar33 - 2)) & 0x7fff;
                    }
                    uVar29 = *(ushort *)(pbVar21 + uVar24 * 2 + uVar33) & 0x7fff;
                    if (((uVar34 < uVar37) || (uVar29 < uVar34)) || (uVar42 < uVar29)) {
                      *(undefined8 *)(puVar27 + -8) = 0x101810;
                      func_0x(pbVar21,7);
                      uVar24 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar11);
                      uVar37 = *(uint *)(&stack0x00000030 + lVar11);
                      uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar11);
                      pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                      uVar42 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                    }
                    if ((uVar34 < uVar37) || (uVar42 < uVar34)) goto LAB_;
                    if (*(ushort *)(pbVar21 + uVar34) == 5) {
                      puVar40 = (ushort *)((longlong)&uStackX_18 + lVar11 + 2);
                      *puVar40 = *puVar40 | 2;
                      *(short *)(&stack0x00000034 + lVar11) = (short)uVar24 + -1;
                      uVar33 = (ulonglong)(uVar34 & 0xffff);
                      *(short *)(&stack0x00000042 + lVar11) = (short)uVar34;
                      pbVar1 = pbVar21 + uVar33;
                      uVar36 = *(ushort *)(&stack0x00000044 + lVar11);
                      if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                        uVar36 = uVar36 & 0xc7ff;
                      }
                      else {
                        uVar36 = uVar36 ^ (*(ushort *)(pbVar1 + 2) ^ uVar36) & 0x3800;
                      }
                      *(ushort *)(&stack0x00000044 + lVar11) = uVar36;
                      uVar38 = (uVar36 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar36;
                      uVar24 = (ulonglong)uVar38;
                      *(ushort *)(&stack0x00000044 + lVar11) = uVar38;
                      pbVar31 = pbVar21 + (ulonglong)((uVar36 >> 0xb & 7) * 2) + 4 + uVar33 +
                                          (uVar24 & 0x7ff) * 2;
                      if (pbVar31 < pbVar1) {
                        *(undefined8 *)(puVar27 + -8) = 0x101909;
                        func_0x(pbVar1,0x19);
                        uVar24 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar11);
                        uVar33 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar11);
                        pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                        uVar42 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                      }
                      if (uVar29 - uVar34 <
                          (((*(uint *)(&stack0x00000044 + lVar11) & 0x7ff) * 2 - (int)uVar33) -
                          *(int *)((longlong)&pbStackX_20 + lVar11)) + (int)pbVar31) {
                        *(undefined8 *)(puVar27 + -8) = 0x101943;
                        func_0x(pbVar21 + uVar33,0x19);
                        uVar24 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar11);
                        uVar33 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar11);
                        pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                        uVar42 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                      }
                      if (((uVar24 & 0x3800) != 0) &&
                         (puVar25 = (ushort *)(pbVar21 + uVar33 + 4), puVar40 = puVar35,
                         (uVar24 & 0x3800) != 0)) {
                        do {
                          if (((ushort)uVar24 & 0x7ff) < (*puVar25 & 0x7ff)) {
                            *(undefined8 *)(puVar27 + -8) = 0x1019a5;
                            func_0x(pbVar21 + uVar33,0x1a);
                            uVar24 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar11);
                            uVar33 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar11);
                            pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                          }
                          uVar42 = (int)puVar40 + 1;
                          puVar25 = puVar25 + 1;
                          puVar40 = (ushort *)(ulonglong)uVar42;
                        } while ((int)uVar42 <
                                 (int)(*(uint *)(&stack0x00000044 + lVar11) >> 0xb & 7));
                        uVar42 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                      }
                      break;
                    }
                    if (*(ushort *)(pbVar21 + uVar34) < 0x400) break;
                    puVar25 = (ushort *)((longlong)&uStackX_18 + lVar11 + 2);
                    *puVar25 = *puVar25 | 1;
                    uVar36 = (short)uVar24 - 1;
                    uVar24 = (ulonglong)uVar36;
                    *(ushort *)(&stack0x00000034 + lVar11) = uVar36;
                    if (uVar36 == 0) break;
                  }
                }
                if ((*pbVar21 & 0x40) == 0) {
                  *(undefined4 *)(&stack0x0000003e + lVar11) = 0;
                }
                else {
                  *(uint *)(&stack0x0000003e + lVar11) = uVar42;
                  *(uint *)((longlong)&uStackX_18 + lVar11 + 4) = uVar42 + 0xe;
                  *(undefined8 *)(puVar27 + -8) = 0x1019ea;
                  uVar14 = func_0x((longlong)&uStackX_18 + lVar11 + 2);
                  *(undefined8 *)(puVar27 + -8) = 0x1019f9;
                  func_0x(uVar14,&stack0x000000c0 + lVar11);
                  *(undefined8 *)(puVar27 + -8) = 0x101a05;
                  iVar10 = func_0x(&stack0x000000c0 + lVar11);
                  uVar42 = *(int *)((longlong)&uStackX_18 + lVar11 + 4) + iVar10;
                  *(uint *)((longlong)&uStackX_18 + lVar11 + 4) = uVar42;
                  pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                }
                if ((*(byte **)(&stack0x00000036 + lVar11) != (byte *)0x0) &&
                   (*(byte **)(&stack0x00000036 + lVar11) < pbVar21 + uVar42)) {
                  *(undefined8 *)(puVar27 + -8) = 0x101a54;
                  cVar7 = func_0x(0x1f45730);
                  if (cVar7 != '\0') {
                    *(undefined8 *)(puVar27 + -8) = 0x101a5d;
                    lVar13 = func_0x();
                    if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar27 + -8) = 0x101a77;
                      cVar7 = func_0x(0x1f45730);
                      if (cVar7 == '\0') {
                        *(undefined8 *)(puVar27 + -8) = 0x101a93;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(puVar27 + 0x20) = 0;
                        *(undefined8 *)(puVar27 + -8) = 0x101ab9;
                        (*_DAT_)(1,0x183513c,0x1955228,0x886);
                      }
                    }
                  }
                  uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                  *(undefined8 *)(puVar27 + -8) = 0x101ac7;
                  func_0x(uVar14,0x12);
                  uVar42 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                }
                if (0x3f3b < uVar42 - 1) {
                  *(undefined8 *)(puVar27 + -8) = 0x101ae2;
                  cVar7 = func_0x(0x1f45730);
                  if (cVar7 != '\0') {
                    *(undefined8 *)(puVar27 + -8) = 0x101aeb;
                    lVar13 = func_0x();
                    if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar27 + -8) = 0x101b05;
                      cVar7 = func_0x(0x1f45730);
                      if (cVar7 == '\0') {
                        *(undefined8 *)(puVar27 + -8) = 0x101b21;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(puVar27 + 0x20) = 0;
                        *(undefined8 *)(puVar27 + -8) = 0x101b47;
                        (*_DAT_)(1,0x183513c,0x1955228,0x88b);
                      }
                    }
                  }
                  uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                  *(undefined8 *)(puVar27 + -8) = 0x101b55;
                  func_0x(uVar14,5);
                }
              }
LAB_:
              *(undefined8 *)(puVar27 + -8) = 0x101b5e;
              func_0x((longlong)&uStackX_18 + lVar11 + 2);
              bVar17 = **(byte **)((longlong)&pbStackX_20 + lVar11) >> 6;
              if ((bVar17 & 1) != 0) {
                *(undefined8 *)(puVar27 + -8) = 0x101b80;
                func_0x
                          ((longlong)&uStackX_18 + lVar11 + 2,&stack0x00000118 + lVar11);
              }
              if ((*(byte *)((longlong)&uStackX_18 + lVar11 + 2) & 1) != 0) {
                *(undefined8 *)(puVar27 + -8) = 0x101b95;
                puVar15 = (undefined4 *)
                          func_0x((longlong)&uStackX_18 + lVar11 + 2,0x400,
                                          &stack0x00000070 + lVar11);
                *(undefined4 *)(&stack0x00000080 + lVar11) = *puVar15;
                *(undefined2 *)(&stack0x00000084 + lVar11) = *(undefined2 *)(puVar15 + 1);
                *(undefined2 *)(&stack0x00000086 + lVar11) = *(undefined2 *)((longlong)puVar15 + 6);
              }
              if ((**(byte **)((longlong)&pbStackX_20 + lVar11) & 0x20) == 0) {
                *(undefined8 *)(puVar27 + -8) = 0x101bbc;
                func_0x((longlong)&uStackX_18 + lVar11 + 2);
              }
              lVar12 = (ulonglong)*(uint *)(&stack0x0000002c + lVar11) +
                       *(longlong *)((longlong)&pbStackX_20 + lVar11);
              *(undefined8 *)(puVar27 + -8) = 0x101bcc;
              iVar10 = func_0x((longlong)&uStackX_18 + lVar11 + 2);
              lVar13 = *(longlong *)((longlong)&pbStackX_20 + lVar11);
              if (iVar10 == 0) {
                uVar36 = *(ushort *)(&stack0x00000034 + lVar11);
                uVar33 = (ulonglong)uVar36;
                puVar40 = (ushort *)(lVar13 + (ulonglong)*(uint *)(&stack0x0000002c + lVar11));
                uVar42 = *(uint *)(&stack0x0000002c + lVar11) + (uVar36 + 1) * 2;
                puVar25 = puVar35;
                if (*puVar40 != 0) {
                  do {
                    uVar38 = puVar40[(longlong)puVar25 + 1];
                    puVar40[((ulonglong)puVar25 & 0xffff) + 1] =
                         puVar40[((ulonglong)puVar25 & 0xffff) + 1] & 0x8000;
                    puVar40[((ulonglong)puVar25 & 0xffff) + 1] =
                         puVar40[((ulonglong)puVar25 & 0xffff) + 1] | (uVar38 & 0x7fff) + 2 & 0x7fff
                    ;
                    uVar37 = (int)puVar25 + 1;
                    puVar25 = (ushort *)(ulonglong)uVar37;
                  } while (uVar37 < *puVar40);
                  lVar13 = *(longlong *)((longlong)&pbStackX_20 + lVar11);
                }
                iVar10 = *(int *)((longlong)&uStackX_18 + lVar11 + 4);
                *(undefined8 *)(puVar27 + -8) = 0x101caa;
                func_0x
                          ((ulonglong)uVar42 + 2 + lVar13,(ulonglong)uVar42 + lVar13,iVar10 - uVar42
                          );
                piVar22 = (int *)((longlong)&uStackX_18 + lVar11 + 4);
                *piVar22 = *piVar22 + 2;
                uVar42 = *(int *)(&stack0x00000030 + lVar11) + 2;
                *(uint *)(&stack0x00000030 + lVar11) = uVar42;
                if (uVar36 != 0) {
                  uVar42 = puVar40[(ulonglong)(uVar36 - 1) + 1] & 0x7fff;
                }
                if ((uint)uVar36 < uVar36 + 1) {
                  do {
                    puVar40[(uVar33 & 0xffff) + 1] = (ushort)uVar42 & 0x7fff;
                    uVar37 = (int)uVar33 + 1;
                    uVar33 = (ulonglong)uVar37;
                  } while (uVar37 < uVar36 + 1);
                }
                *puVar40 = *puVar40 + 1;
                *(undefined8 *)(puVar27 + -8) = 0x101ceb;
                func_0x((longlong)&uStackX_18 + lVar11 + 2);
                uVar36 = *(ushort *)
                          (lVar12 + 2 + (ulonglong)*(ushort *)(&stack0x00000034 + lVar11) * 2);
                *(undefined8 *)(puVar27 + -8) = 0x101d03;
                func_0x(&stack0x00000100 + lVar11);
                *(undefined4 *)(puVar27 + 0x28) = 0;
                puVar26 = *(uint **)(&stack0x00000058 + lVar11);
                *(uint **)(puVar27 + 0x20) = puVar26;
                uVar14 = *(undefined8 *)(&stack0x00000098 + lVar11);
                *(undefined8 *)(puVar27 + -8) = 0x101d2b;
                func_0x(&stack0x000000f0 + lVar11,uVar14,1);
                *(undefined **)(puVar27 + 0x28) = &stack0x000000a0 + lVar11;
                *(undefined **)(puVar27 + 0x20) = &stack0x000000f0 + lVar11;
                *(undefined8 *)(puVar27 + -8) = 0x101d5d;
                func_0x(&stack0x00000042 + lVar11,uVar36 & 0x7fff,0x1f9e);
                iVar10 = *(int *)(&stack0x000000a0 + lVar11);
                uVar42 = uVar23;
              }
              else {
                uVar36 = *(ushort *)(&stack0x00000034 + lVar11);
                uVar42 = *(uint *)(&stack0x00000030 + lVar11);
                if (uVar36 != 0) {
                  uVar42 = *(ushort *)
                            ((ulonglong)*(uint *)(&stack0x0000002c + lVar11) + lVar13 +
                            (ulonglong)uVar36 * 2) & 0x7fff;
                }
                uVar37 = *(ushort *)
                          ((ulonglong)*(uint *)(&stack0x0000002c + lVar11) + lVar13 + 2 +
                          (ulonglong)uVar36 * 2) & 0x7fff;
                if (((uVar42 < *(uint *)(&stack0x00000030 + lVar11)) || (uVar37 < uVar42)) ||
                   (*(uint *)((longlong)&uStackX_18 + lVar11 + 4) < uVar37)) {
                  *(undefined8 *)(puVar27 + -8) = 0x101c15;
                  func_0x(lVar13,7);
                }
                uVar14 = *(undefined8 *)(&stack0x00000098 + lVar11);
                puVar26 = *(uint **)(&stack0x00000058 + lVar11);
                *(undefined8 *)(puVar27 + -8) = 0x101c34;
                iVar10 = func_0x(&stack0x00000042 + lVar11,puVar26,uVar14);
                uVar42 = uVar37 - uVar42;
              }
              iVar20 = (iVar10 - uVar42) + *(int *)((longlong)&uStackX_18 + lVar11 + 4);
              *(int *)((longlong)&uStackX_18 + lVar11 + 4) = iVar20;
              if ((*(byte *)((longlong)&uStackX_18 + lVar11 + 2) & 1) != 0) {
                *(ushort *)
                 (lVar12 + 2 + (ulonglong)(*(ushort *)(&stack0x00000034 + lVar11) + 1) * 2) =
                     (ushort)iVar20 | 0x8000;
                iVar20 = (*(int *)((longlong)&uStackX_18 + lVar11 + 4) -
                         *(int *)(&stack0x00000070 + lVar11)) + -2;
              }
              *(ushort *)(lVar12 + 2 + (ulonglong)*(ushort *)(&stack0x00000034 + lVar11) * 2) =
                   (ushort)iVar20 | 0x8000;
              lVar13 = (longlong)&uStackX_18 + lVar11 + 2;
              if (iVar10 == 0) {
                uVar36 = *(ushort *)(&stack0x00000034 + lVar11);
                *(undefined8 *)(puVar27 + -8) = 0x101db1;
                func_0x(lVar13,uVar36 + 1);
                if ((**(byte **)((longlong)&pbStackX_20 + lVar11) & 0x20) != 0) {
                  *(short *)(&stack0x00000034 + lVar11) = *(short *)(&stack0x00000034 + lVar11) + 1;
                  puVar40 = (ushort *)((longlong)&uStackX_18 + lVar11 + 2);
                  *puVar40 = *puVar40 & 0xfffd;
                  *(undefined8 *)(puVar27 + -8) = 0x101dd0;
                  func_0x(&stack0x00000042 + lVar11);
                }
              }
              else {
                puVar40 = (ushort *)((longlong)&uStackX_18 + lVar11 + 2);
                *puVar40 = *puVar40 | 2;
                *(undefined8 *)(puVar27 + -8) = 0x101de0;
                uVar8 = func_0x(lVar13,&stack0x0000008c + lVar11);
                *(undefined2 *)(&stack0x00000042 + lVar11) = uVar8;
              }
              if ((*(byte *)((longlong)&uStackX_18 + lVar11 + 2) & 1) != 0) {
                uVar9 = *(undefined4 *)(&stack0x00000070 + lVar11);
                *(undefined8 *)(puVar27 + -8) = 0x101e02;
                func_0x((longlong)&uStackX_18 + lVar11 + 2,0x400,uVar9);
              }
              if ((bVar17 & 1) != 0) {
                *(undefined8 *)(puVar27 + -8) = 0x101e17;
                func_0x
                          ((longlong)&uStackX_18 + lVar11 + 2,&stack0x00000118 + lVar11);
              }
              param_2 = *(ushort ***)(&stack0x00000060 + lVar11);
            }
            else {
              bVar17 = (byte)*(ushort *)((longlong)puVar26 + 6);
              if ((*(ushort *)((longlong)puVar26 + 6) & 8) == 0) {
                if (*(int *)((longlong)&uStackX_18 + lVar11 + 4) == 0) {
                  *(undefined2 *)((longlong)&uStackX_18 + lVar11 + 2) = 0;
                  uVar42 = *(uint *)(&stack0x00000028 + lVar11);
                  *(uint *)(&stack0x0000002c + lVar11) = uVar42;
                  if ((**(byte **)((longlong)&pbStackX_20 + lVar11) & 0x10) != 0) {
                    *(uint *)(&stack0x0000002c + lVar11) =
                         uVar42 + 2 +
                         (*(ushort *)(*(byte **)((longlong)&pbStackX_20 + lVar11) + uVar42) + 7 >> 3
                         );
                  }
                  if ((**(byte **)((longlong)&pbStackX_20 + lVar11) & 0x20) == 0) {
                    uVar42 = *(uint *)(&stack0x0000002c + lVar11);
                    uVar33 = (ulonglong)uVar42;
                    *(uint *)((longlong)&uStackX_18 + lVar11 + 4) = uVar42;
                    *(undefined2 *)(&stack0x00000034 + lVar11) = 0;
                    *(uint *)(&stack0x00000030 + lVar11) = uVar42;
                  }
                  else {
                    puVar40 = (ushort *)
                              (*(byte **)((longlong)&pbStackX_20 + lVar11) +
                              *(uint *)(&stack0x0000002c + lVar11));
                    uVar36 = *puVar40;
                    *(ushort *)(&stack0x00000034 + lVar11) = uVar36;
                    if (uVar36 == 0) {
                      *(undefined8 *)(puVar27 + -8) = 0x100398;
                      cVar7 = func_0x(0x1f45730);
                      if (cVar7 != '\0') {
                        *(undefined8 *)(puVar27 + -8) = 0x1003a1;
                        lVar13 = func_0x();
                        if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar27 + -8) = 0x1003bb;
                          cVar7 = func_0x(0x1f45730);
                          if (cVar7 == '\0') {
                            *(undefined8 *)(puVar27 + -8) = 0x1003d7;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(puVar27 + 0x20) = 0;
                            *(undefined8 *)(puVar27 + -8) = 0x1003fd;
                            (*_DAT_)(1,0x183513c,0x1955228,0x80f);
                          }
                        }
                      }
                      uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                      *(undefined8 *)(puVar27 + -8) = 0x10040b;
                      func_0x(uVar14,3);
                      uVar36 = *(ushort *)(&stack0x00000034 + lVar11);
                    }
                    uVar42 = *(int *)(&stack0x0000002c + lVar11) + 2 + (uint)uVar36 * 2;
                    *(uint *)(&stack0x00000030 + lVar11) = uVar42;
                    if (0x1f9e < uVar42) {
                      *(undefined8 *)(puVar27 + -8) = 0x10043b;
                      cVar7 = func_0x(0x1f45730);
                      if (cVar7 != '\0') {
                        *(undefined8 *)(puVar27 + -8) = 0x100444;
                        lVar13 = func_0x();
                        if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar27 + -8) = 0x10045e;
                          cVar7 = func_0x(0x1f45730);
                          if (cVar7 == '\0') {
                            *(undefined8 *)(puVar27 + -8) = 0x10047a;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar27 + 0x20) = 0;
                            *(undefined8 *)(puVar27 + -8) = 0x1004a0;
                            (*_DAT_)(1,0x183513c,0x1955228,0x816);
                          }
                        }
                      }
                      uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                      *(undefined8 *)(puVar27 + -8) = 0x1004ae;
                      func_0x(uVar14,4);
                      uVar36 = *(ushort *)(&stack0x00000034 + lVar11);
                      uVar42 = *(uint *)(&stack0x00000030 + lVar11);
                    }
                    uVar24 = (ulonglong)uVar36;
                    uVar37 = puVar40[uVar24] & 0x7fff;
                    *(uint *)((longlong)&uStackX_18 + lVar11 + 4) = uVar37;
                    if (uVar37 < uVar42) {
                      *(undefined8 *)(puVar27 + -8) = 0x1004dc;
                      cVar7 = func_0x(0x1f45730);
                      if (cVar7 != '\0') {
                        *(undefined8 *)(puVar27 + -8) = 0x1004e5;
                        lVar13 = func_0x();
                        if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar27 + -8) = 0x1004ff;
                          cVar7 = func_0x(0x1f45730);
                          if (cVar7 == '\0') {
                            *(undefined8 *)(puVar27 + -8) = 0x10051b;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar27 + 0x20) = 0;
                            *(undefined8 *)(puVar27 + -8) = 0x100541;
                            (*_DAT_)(1,0x183513c,0x1955228,0x81d);
                          }
                        }
                      }
                      uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                      *(undefined8 *)(puVar27 + -8) = 0x10054f;
                      func_0x(uVar14,4);
                      uVar24 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar11);
                      uVar42 = *(uint *)(&stack0x00000030 + lVar11);
                      uVar37 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                    }
                    uVar33 = (ulonglong)uVar37;
                    puVar32 = puVar35;
                    puVar25 = puVar40;
                    if ((short)uVar24 != 0) {
                      do {
                        uVar37 = puVar25[1] & 0x7fff;
                        if ((uVar37 < uVar42) || ((uint)uVar33 < uVar37)) {
                          *(undefined8 *)(puVar27 + -8) = 0x100590;
                          cVar7 = func_0x(0x1f45730);
                          if (cVar7 != '\0') {
                            *(undefined8 *)(puVar27 + -8) = 0x100599;
                            lVar13 = func_0x();
                            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar27 + -8) = 0x1005b3;
                              cVar7 = func_0x(0x1f45730);
                              if (cVar7 == '\0') {
                                *(undefined8 *)(puVar27 + -8) = 0x1005cf;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar27 + 0x20) = 0;
                                *(undefined8 *)(puVar27 + -8) = 0x1005f5;
                                (*_DAT_)(1,0x183513c,0x1955228,0x82a);
                              }
                            }
                          }
                          uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                          *(undefined8 *)(puVar27 + -8) = 0x100603;
                          func_0x(uVar14,4);
                          uVar24 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar11);
                          uVar33 = (ulonglong)*(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                        }
                        uVar34 = (int)puVar32 + 1;
                        puVar32 = (ushort *)(ulonglong)uVar34;
                        uVar42 = uVar37;
                        puVar25 = puVar25 + 1;
                      } while ((int)uVar34 < (int)uVar24);
                      uVar42 = *(uint *)(&stack0x00000030 + lVar11);
                    }
                    while ((short)puVar40[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                      lVar13 = (ulonglong)*(uint *)(&stack0x0000002c + lVar11) +
                               *(longlong *)((longlong)&pbStackX_20 + lVar11);
                      uVar37 = uVar42;
                      if ((int)uVar24 != 1) {
                        uVar37 = *(ushort *)(lVar13 + -2 + uVar24 * 2) & 0x7fff;
                      }
                      uVar34 = *(ushort *)(lVar13 + uVar24 * 2) & 0x7fff;
                      if (((uVar37 < uVar42) || (uVar34 < uVar37)) || ((uint)uVar33 < uVar34)) {
                        uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                        *(undefined8 *)(puVar27 + -8) = 0x100680;
                        func_0x(uVar14,7);
                        uVar24 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar11);
                        uVar42 = *(uint *)(&stack0x00000030 + lVar11);
                        uVar33 = (ulonglong)*(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                      }
                      if ((uVar37 < uVar42) || ((uint)uVar33 < uVar37)) goto LAB_;
                      uVar36 = *(ushort *)
                                ((ulonglong)uVar37 + *(longlong *)((longlong)&pbStackX_20 + lVar11))
                      ;
                      if (uVar36 == 5) {
                        puVar40 = (ushort *)((longlong)&uStackX_18 + lVar11 + 2);
                        *puVar40 = *puVar40 | 2;
                        *(short *)(&stack0x00000034 + lVar11) = (short)uVar24 + -1;
                        uVar39 = (ulonglong)(uVar37 & 0xffff);
                        *(short *)(&stack0x00000042 + lVar11) = (short)uVar37;
                        uVar24 = *(longlong *)((longlong)&pbStackX_20 + lVar11) + uVar39;
                        uVar36 = *(ushort *)(&stack0x00000044 + lVar11);
                        if ((*(ushort *)(uVar24 + 2) & 0x4000) == 0) {
                          uVar36 = uVar36 & 0xc7ff;
                        }
                        else {
                          uVar36 = uVar36 ^ (*(ushort *)(uVar24 + 2) ^ uVar36) & 0x3800;
                        }
                        *(ushort *)(&stack0x00000044 + lVar11) = uVar36;
                        uVar38 = (uVar36 ^ *(ushort *)(uVar24 + 2)) & 0x7ff ^ uVar36;
                        *(ushort *)(&stack0x00000044 + lVar11) = uVar38;
                        uVar30 = (ulonglong)((uVar36 >> 0xb & 7) * 2) + 4 + uVar39 +
                                 ((ulonglong)uVar38 & 0x7ff) * 2 +
                                 *(longlong *)((longlong)&pbStackX_20 + lVar11);
                        if (uVar30 < uVar24) {
                          *(undefined8 *)(puVar27 + -8) = 0x100778;
                          func_0x(uVar24,0x19);
                          uVar38 = *(ushort *)(&stack0x00000044 + lVar11);
                          uVar39 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar11);
                          uVar33 = (ulonglong)*(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                        }
                        if (uVar34 - uVar37 <
                            (((*(uint *)(&stack0x00000044 + lVar11) & 0x7ff) * 2 - (int)uVar39) -
                            *(int *)((longlong)&pbStackX_20 + lVar11)) + (int)uVar30) {
                          lVar13 = *(longlong *)((longlong)&pbStackX_20 + lVar11);
                          *(undefined8 *)(puVar27 + -8) = 0x1007af;
                          func_0x(uVar39 + lVar13,0x19);
                          uVar38 = *(ushort *)(&stack0x00000044 + lVar11);
                          uVar39 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar11);
                          uVar33 = (ulonglong)*(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                        }
                        if (((uVar38 & 0x3800) != 0) &&
                           (puVar25 = (ushort *)
                                      (*(longlong *)((longlong)&pbStackX_20 + lVar11) + 4 + uVar39),
                           puVar40 = puVar35, (uVar38 & 0x3800) != 0)) {
                          do {
                            if ((uVar38 & 0x7ff) < (*puVar25 & 0x7ff)) {
                              lVar13 = *(longlong *)((longlong)&pbStackX_20 + lVar11);
                              *(undefined8 *)(puVar27 + -8) = 0x100816;
                              func_0x(uVar39 + lVar13,0x1a);
                              uVar38 = *(ushort *)(&stack0x00000044 + lVar11);
                              uVar39 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar11);
                            }
                            uVar42 = (int)puVar40 + 1;
                            puVar25 = puVar25 + 1;
                            puVar40 = (ushort *)(ulonglong)uVar42;
                          } while ((int)uVar42 <
                                   (int)(*(uint *)(&stack0x00000044 + lVar11) >> 0xb & 7));
                          uVar33 = (ulonglong)*(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                        }
                        break;
                      }
                      if (uVar36 < 0x400) break;
                      puVar25 = (ushort *)((longlong)&uStackX_18 + lVar11 + 2);
                      *puVar25 = *puVar25 | 1;
                      uVar36 = (short)uVar24 - 1;
                      uVar24 = (ulonglong)uVar36;
                      *(ushort *)(&stack0x00000034 + lVar11) = uVar36;
                      if (uVar36 == 0) break;
                    }
                  }
                  if ((**(byte **)((longlong)&pbStackX_20 + lVar11) & 0x40) == 0) {
                    *(undefined4 *)(&stack0x0000003e + lVar11) = 0;
                  }
                  else {
                    *(int *)(&stack0x0000003e + lVar11) = (int)uVar33;
                    *(int *)((longlong)&uStackX_18 + lVar11 + 4) = (int)uVar33 + 0xe;
                    *(undefined8 *)(puVar27 + -8) = 0x100868;
                    uVar14 = func_0x((longlong)&uStackX_18 + lVar11 + 2);
                    *(undefined8 *)(puVar27 + -8) = 0x100877;
                    func_0x(uVar14,&stack0x000000b0 + lVar11);
                    *(undefined8 *)(puVar27 + -8) = 0x100883;
                    iVar10 = func_0x(&stack0x000000b0 + lVar11);
                    uVar42 = *(int *)((longlong)&uStackX_18 + lVar11 + 4) + iVar10;
                    uVar33 = (ulonglong)uVar42;
                    *(uint *)((longlong)&uStackX_18 + lVar11 + 4) = uVar42;
                  }
                  if ((*(ulonglong *)(&stack0x00000036 + lVar11) != 0) &&
                     (*(ulonglong *)(&stack0x00000036 + lVar11) <
                      uVar33 + *(longlong *)((longlong)&pbStackX_20 + lVar11))) {
                    *(undefined8 *)(puVar27 + -8) = 0x1008bd;
                    cVar7 = func_0x(0x1f45730);
                    if (cVar7 != '\0') {
                      *(undefined8 *)(puVar27 + -8) = 0x1008c6;
                      lVar13 = func_0x();
                      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar27 + -8) = 0x1008e0;
                        cVar7 = func_0x(0x1f45730);
                        if (cVar7 == '\0') {
                          *(undefined8 *)(puVar27 + -8) = 0x1008fc;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(puVar27 + 0x20) = 0;
                          *(undefined8 *)(puVar27 + -8) = 0x100922;
                          (*_DAT_)(1,0x183513c,0x1955228,0x886);
                        }
                      }
                    }
                    uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                    *(undefined8 *)(puVar27 + -8) = 0x100930;
                    func_0x(uVar14,0x12);
                    uVar33 = (ulonglong)*(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                  }
                  if (0x3f3b < (int)uVar33 - 1U) {
                    *(undefined8 *)(puVar27 + -8) = 0x10094b;
                    cVar7 = func_0x(0x1f45730);
                    if (cVar7 != '\0') {
                      *(undefined8 *)(puVar27 + -8) = 0x100954;
                      lVar13 = func_0x();
                      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar27 + -8) = 0x10096e;
                        cVar7 = func_0x(0x1f45730);
                        if (cVar7 == '\0') {
                          *(undefined8 *)(puVar27 + -8) = 0x10098a;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(puVar27 + 0x20) = 0;
                          *(undefined8 *)(puVar27 + -8) = 0x1009b0;
                          (*_DAT_)(1,0x183513c,0x1955228,0x88b);
                        }
                      }
                    }
                    uVar14 = *(undefined8 *)((longlong)&pbStackX_20 + lVar11);
                    *(undefined8 *)(puVar27 + -8) = 0x1009be;
                    func_0x(uVar14,5);
                  }
                }
LAB_:
                uVar37 = *puVar26;
                uVar42 = uVar37 + 1;
                uVar34 = *(uint *)(&stack0x00000028 + lVar11);
                if (uVar34 < uVar42) {
                  *(undefined8 *)(puVar27 + -8) = 0x1009e1;
                  func_0x((longlong)&uStackX_18 + lVar11 + 2,0,uVar42 - uVar34);
                  if ((1 << (**(byte **)((longlong)&pbStackX_20 + lVar11) & 0xe) & 0x1105U) != 0) {
                    *(short *)(*(byte **)((longlong)&pbStackX_20 + lVar11) + 2) = (short)uVar42;
                  }
                  *(uint *)(&stack0x00000028 + lVar11) = uVar42;
                  uVar37 = *puVar26;
                }
                param_2 = *(ushort ***)(&stack0x00000060 + lVar11);
                if (*(undefined **)(&stack0x00000098 + lVar11) != (undefined *)0x0) {
                  *(undefined *)
                   ((longlong)(int)uVar37 + *(longlong *)((longlong)&pbStackX_20 + lVar11)) =
                       **(undefined **)(&stack0x00000098 + lVar11);
                }
              }
              else {
                cVar7 = **(char **)(&stack0x00000090 + lVar11);
                uVar34 = uVar42 + 1;
                uVar37 = *(uint *)(&stack0x00000028 + lVar11);
                if (uVar37 < uVar34) {
                  *(undefined8 *)(puVar27 + -8) = 0x1002de;
                  func_0x((longlong)&uStackX_18 + lVar11 + 2,0,uVar34 - uVar37);
                  pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                  if ((1 << (*pbVar21 & 0xe) & 0x1105U) != 0) {
                    *(short *)(pbVar21 + 2) = (short)uVar34;
                    pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                  }
                  *(uint *)(&stack0x00000028 + lVar11) = uVar34;
                  bVar17 = *(byte *)((longlong)puVar26 + 6);
                }
                else {
                  pbVar21 = *(byte **)((longlong)&pbStackX_20 + lVar11);
                }
                if (cVar7 == '\0') {
                  pbVar21[(int)uVar42] = pbVar21[(int)uVar42] & ~(byte)(1 << (bVar17 & 7));
                }
                else {
                  pbVar21[(int)uVar42] = pbVar21[(int)uVar42] | (byte)(1 << (bVar17 & 7));
                }
              }
            }
          }
          else {
            *(undefined8 *)(puVar27 + 0x20) = 0x15b06a0;
            *(undefined8 *)(puVar27 + -8) = 0x100298;
            (*_DAT_)(1,0x19b6a30,0x19e33f8);
          }
LAB_:
          puVar26 = puVar26 + 0x14;
          *(uint **)(&stack0x00000058 + lVar11) = puVar26;
          iVar10 = *(int *)(&stack0x00000088 + lVar11);
          *(uint *)(&stack0x00000088 + lVar11) = iVar10 + 1U;
        } while (iVar10 + 1U < *(uint *)(&stack0x000000a4 + lVar11));
        uVar42 = *(uint *)(&stack0x00000074 + lVar11);
      }
      if (uVar42 != 0) {
        lVar13 = *(longlong *)(&stack0x00000078 + lVar11);
        do {
          uVar33 = (ulonglong)uVar42;
          uVar23 = uVar42 - 1;
          if (*(int *)((ulonglong)uVar23 * 0x20 + 8 + lVar13) != 0) {
            *(ushort *)(&stack0x00000034 + lVar11) = (ushort)uVar42;
            iVar10 = *(int *)(&stack0x0000002c + lVar11) + 2 + uVar42 * 2;
            *(int *)(&stack0x00000030 + lVar11) = iVar10;
            *(int *)((longlong)&uStackX_18 + lVar11 + 4) = iVar10;
            **(byte **)((longlong)&pbStackX_20 + lVar11) =
                 **(byte **)((longlong)&pbStackX_20 + lVar11) | 0x20;
            uVar23 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
            if (uVar23 < 0x1f7d) {
              puVar35 = (ushort *)
                        ((ulonglong)*(uint *)(&stack0x0000002c + lVar11) +
                        *(longlong *)((longlong)&pbStackX_20 + lVar11));
              *puVar35 = (ushort)uVar42;
              uVar23 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
            }
            if (uVar42 != 0) {
              puVar26 = (uint *)(lVar13 + 0xc);
              do {
                puVar35 = puVar35 + 1;
                uVar24 = (ulonglong)uVar23;
                lVar13 = *(longlong *)((longlong)&pbStackX_20 + lVar11);
                uVar42 = puVar26[-1];
                uVar23 = uVar23 + uVar42;
                *(uint *)((longlong)&uStackX_18 + lVar11 + 4) = uVar23;
                if (uVar23 < 0x1f7d) {
                  *puVar35 = (ushort)((*puVar26 & 1) << 0xf) | (ushort)uVar23 & 0x7fff;
                  uVar14 = *(undefined8 *)(puVar26 + -3);
                  *(undefined8 *)(puVar27 + -8) = 0x102078;
                  func_0x(uVar24 + lVar13,uVar42,uVar14,uVar42);
                  uVar23 = *(uint *)((longlong)&uStackX_18 + lVar11 + 4);
                }
                puVar26 = puVar26 + 8;
                uVar33 = uVar33 - 1;
              } while (uVar33 != 0);
            }
            break;
          }
          uVar42 = uVar23;
        } while (uVar23 != 0);
      }
    }
    param_1 = *(longlong *)(&stack0x00000068 + lVar11);
    uVar42 = *(uint *)(&stack0x00000054 + lVar11);
    puVar28 = puVar27;
  }
  else {
    if (bVar43) {
      uVar14 = 0x1ff1180;
      uVar18 = 0x1fa05a8;
    }
    else {
      uVar14 = 0x1fb7be8;
      uVar18 = 0x1fa0570;
    }
    if ((bVar17 & 1) == 0) {
      uVar14 = uVar18;
    }
    *(undefined8 *)(param_1 + 0x3a0) = uVar14;
    *(undefined8 *)(param_1 + 0x3a8) = 0;
    *(longlong *)((longlong)alStackX_8 + lVar11) = param_1 + 0x290;
    *(undefined **)((longlong)&pbStackX_20 + lVar11 + -0x20) = &stack0x0000008c + lVar11;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar11) = 0x1f7c;
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0x1f9e;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = &stack0x000001f8 + lVar11;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1025eb;
    func_0x(param_1 + 0x3b8,param_2,2,psVar2);
  }
  uVar14 = *(undefined8 *)(&stack0x000000c8 + lVar11);
  *(undefined8 *)(puVar28 + -8) = 0x1013e1;
  iVar10 = func_0x(uVar14);
  if ((iVar10 == 0) && (uVar42 == 0)) {
    *(undefined8 *)(puVar28 + -8) = 0x1013f9;
    func_0x(uVar14,1);
  }
  *(undefined8 *)(puVar28 + 0x28) = *(undefined8 *)(&stack0x000000d0 + lVar11);
  *(undefined8 *)(puVar28 + 0x20) = 0;
  *(undefined8 *)(puVar28 + -8) = 0x10141c;
  iVar10 = func_0x(param_1,psVar2,0,0);
  if ((iVar10 != 0) && (*(int *)(param_1 + 0x1cc) != 0)) {
    *(short **)(param_1 + 0x3a0) = psVar2;
    *(undefined8 *)(param_1 + 0x3a8) = 0;
    lVar13 = *(longlong *)(&stack0x000000d8 + lVar11);
    *(undefined8 *)(puVar28 + -8) = 0x101452;
    func_0x(param_1 + 0x3b8,lVar13 + 0x78);
  }
  plVar5 = *(longlong **)(&stack0x000000e0 + lVar11);
  if (plVar5 != (longlong *)0x0) {
    pcVar6 = *(code **)(*plVar5 + 0xd0);
    *(undefined8 *)(puVar28 + -8) = 0x10146d;
    (*pcVar6)(plVar5,0);
  }
  uVar33 = *(ulonglong *)(&stack0x00002198 + lVar11);
  *(undefined8 *)(puVar28 + -8) = 0x10147f;
  func_0x(uVar33 ^ (ulonglong)psVar2);
  return;
}

