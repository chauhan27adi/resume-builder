
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2)

{
  undefined2 uVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  ushort *puVar6;
  uint6 uVar7;
  char cVar8;
  ushort uVar9;
  ushort uVar10;
  int iVar11;
  longlong lVar12;
  longlong lVar13;
  undefined8 uVar14;
  undefined8 uVar15;
  longlong lVar16;
  ulonglong *puVar17;
  byte bVar18;
  longlong *plVar19;
  undefined4 *puVar20;
  uint uVar21;
  uint uVar22;
  undefined8 unaff_RBX;
  ushort *puVar23;
  uint uVar24;
  longlong lVar25;
  ulonglong uVar26;
  byte *pbVar27;
  ulonglong uVar28;
  longlong *plVar29;
  ushort *puVar30;
  short *psVar31;
  short *psVar32;
  ulonglong uVar33;
  longlong unaff_GS_OFFSET;
  short *apsStackX_8 [2];
  longlong lStackX_18;
  longlong lStackX_20;
  undefined8 *puStack_2bb8;
  undefined8 uStack_2bb0;
  undefined2 auStack_2ba8 [2];
  undefined4 uStack_2ba4;
  undefined8 uStack_2ba0;
  undefined8 uStack_2b98;
  undefined8 uStack_2b8a;
  undefined8 uStack_2b80;
  undefined8 uStack_2b70;
  undefined auStack_2b68 [8];
  undefined4 uStack_2b60;
  undefined4 uStack_2b58;
  undefined4 **ppuStack_2b50;
  undefined *puStack_2b48;
  undefined8 uStack_2b40;
  undefined4 *puStack_2b38;
  undefined8 uStack_2b30;
  undefined auStack_2b28 [528];
  undefined8 uStack_2918;
  undefined8 uStack_2910;
  undefined4 uStack_2908;
  uint uStack_2904;
  undefined2 uStack_2900;
  undefined4 uStack_28fe;
  undefined8 uStack_28fa;
  undefined8 uStack_28f2;
  undefined auStack_28e8 [8];
  undefined4 uStack_28e0;
  undefined4 uStack_28d8;
  undefined4 **ppuStack_28d0;
  undefined *puStack_28c8;
  undefined8 uStack_28c0;
  undefined4 *puStack_28b8;
  undefined8 uStack_28b0;
  undefined auStack_28a8 [528];
  undefined8 uStack_2698;
  undefined8 uStack_2690;
  undefined4 uStack_2688;
  uint uStack_2684;
  undefined2 uStack_2680;
  undefined4 uStack_267e;
  undefined8 uStack_267a;
  undefined8 uStack_2672;
  undefined auStack_2668 [8];
  undefined4 uStack_2660;
  undefined4 uStack_2658;
  uint **ppuStack_2650;
  undefined *puStack_2648;
  undefined8 uStack_2640;
  uint *puStack_2638;
  undefined8 uStack_2630;
  undefined auStack_2628 [528];
  undefined8 uStack_2418;
  undefined8 uStack_2410;
  uint uStack_2408;
  undefined2 uStack_2404;
  undefined4 uStack_2402;
  longlong lStack_23fe;
  char cStack_23f6;
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  uStack_2b70 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002c28 + lVar12) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar12);
  *(longlong *)((longlong)&lStackX_18 + lVar12) = param_1;
  auStack_2ba8[0] = 0xffff;
  plVar29 = (longlong *)0x0;
  uStack_2ba0 = 0;
  uStack_2ba4 = 0;
  uStack_2b8a = 0;
  uStack_2b80 = 0;
  uStack_2b98 = 0;
  lVar13 = *(longlong *)(param_1 + 0xdf0);
  if (lVar13 == 0) goto LAB_;
  *(undefined8 *)(&stack0x00000038 + lVar12) = param_2;
  *(undefined2 **)(&stack0x00000040 + lVar12) = auStack_2ba8;
  puStack_2bb8 = (undefined8 *)(param_1 + 4000);
  plVar19 = (longlong *)(ulonglong)(*(ushort *)(lVar13 + 0x1c) - 2);
  if (*(ushort *)(lVar13 + 0x1c) < 3) {
    plVar19 = plVar29;
  }
  iVar11 = *(int *)(param_1 + 0xb38);
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1000cf;
  iVar11 = func_0x(lVar13,&stack0x00000038 + lVar12,plVar19,0x2000 - iVar11);
  if (iVar11 == 0) {
    uVar3 = *(undefined4 *)(param_1 + 0x1c);
    uVar14 = *(undefined8 *)(param_1 + 8);
    lVar13 = *(longlong *)(param_1 + 0xdf0);
    if (lVar13 == 0) {
      puVar20 = (undefined4 *)(_DAT_ + 0x70);
    }
    else {
      puVar20 = (undefined4 *)(lVar13 + 0x20);
    }
    uVar7 = *(uint6 *)(param_1 + 0x34);
    uVar1 = *(undefined2 *)(*(longlong *)(param_1 + 0x40) + 0x6b8);
    *(undefined8 *)((longlong)&lStackX_20 + lVar12) = 0xffffffffffffffff;
    *(undefined2 *)(&stack0x0000002e + lVar12) = 0;
    if ((_DAT_ & 0x1000) == 0) {
      *(longlong *)((longlong)&lStackX_20 + lVar12 + -0x20) = (longlong)&lStackX_20 + lVar12;
      *(undefined **)((longlong)apsStackX_8 + lVar12 + 8) = &stack0xfffffffffffffff8 + lVar12;
    }
    else {
      *(ulonglong *)((longlong)&lStackX_20 + lVar12) = (ulonglong)uVar7 << 0x10;
      *(undefined2 *)(&stack0x00000030 + lVar12) = uVar1;
      *(undefined4 *)(&stack0x00000028 + lVar12) = *puVar20;
      *(undefined2 *)(&stack0x0000002c + lVar12) = *(undefined2 *)(puVar20 + 1);
      *(longlong *)((longlong)&lStackX_20 + lVar12 + -0x20) = (longlong)&lStackX_20 + lVar12;
      *(undefined **)((longlong)apsStackX_8 + lVar12 + 8) = &stack0xfffffffffffffff8 + lVar12;
      uVar15 = _DAT_;
      if (*_DAT_ != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1008be;
        (*_DAT_)(&uStack_2bb0);
        uVar15 = uStack_2bb0;
      }
      *(undefined8 *)(&stack0xfffffffffffffff8 + lVar12) = uVar15;
      uStack_2b60 = 0x10000;
      uStack_2b58 = 0;
      ppuStack_2b50 = &puStack_2b38;
      puStack_2b48 = auStack_2b28;
      uStack_2918 = 0;
      uStack_2b40 = 0;
      uStack_2910 = 0;
      puStack_2b38 = &uStack_2908;
      uStack_2b30 = 0x1e;
      uStack_2908 = 0;
      uStack_28f2 = 0;
      puVar4 = *(undefined8 **)((longlong)&lStackX_20 + lVar12 + -0x20);
      uStack_28fa = *puVar4;
      uStack_2900 = *(undefined2 *)((longlong)puVar4 + 0xc);
      uStack_28fe = *(undefined4 *)(puVar4 + 1);
      uStack_2904 = (uint)*(ushort *)(puVar4 + 2);
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100955;
      func_0x(auStack_2b68);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar12) = uVar3;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar12) = param_1 + 0xe30;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10098c;
    iVar11 = func_0x(lVar13,0,param_1 + 0x20,uVar14);
    if ((_DAT_ >> 0xc & 1) != 0) {
      uStack_28e0 = 0x10000;
      uStack_28d8 = 0;
      ppuStack_28d0 = &puStack_28b8;
      puStack_28c8 = auStack_28a8;
      uStack_2698 = 0;
      uStack_28c0 = 0;
      uStack_2690 = 0;
      puStack_28b8 = &uStack_2688;
      uStack_28b0 = 0x1e;
      uStack_2688 = 1;
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100a0b;
      uStack_2672 = func_0x(&stack0xfffffffffffffff8 + lVar12);
      puVar4 = *(undefined8 **)((longlong)&lStackX_20 + lVar12 + -0x20);
      uStack_267a = *puVar4;
      uStack_2680 = *(undefined2 *)((longlong)puVar4 + 0xc);
      uStack_267e = *(undefined4 *)(puVar4 + 1);
      uStack_2684 = (uint)*(ushort *)(puVar4 + 2);
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100a4b;
      func_0x(auStack_28e8);
    }
    if (iVar11 != 0) {
      if (lVar13 == 0) {
        puVar20 = (undefined4 *)(_DAT_ + 0x70);
      }
      else {
        puVar20 = (undefined4 *)(lVar13 + 0x20);
      }
      if ((_DAT_ >> 0xb & 1) != 0) {
        uStack_2660 = 0x10000;
        uStack_2658 = 0;
        ppuStack_2650 = &puStack_2638;
        puStack_2648 = auStack_2628;
        uStack_2418 = 0;
        uStack_2640 = 0;
        uStack_2410 = 0;
        puStack_2638 = &uStack_2408;
        uStack_2630 = 0x13;
        uStack_2404 = *(undefined2 *)(puVar20 + 1);
        uStack_2402 = *puVar20;
        uStack_2408 = (uint)*(ushort *)(*(longlong *)(param_1 + 0x40) + 0x6b8);
        lStack_23fe = (ulonglong)*(uint6 *)(param_1 + 0x34) << 0x10;
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1013d7;
        cStack_23f6 = (char)iVar11;
        func_0x(auStack_2668);
      }
      goto LAB_;
    }
    if (*_DAT_ != (char)iVar11) {
      plVar19 = plVar29;
      if (_DAT_ != 0) {
        plVar19 = (longlong *)(_DAT_ + 0x6800);
      }
      if ((plVar19 != (longlong *)0x0) && (*plVar19 != 0)) {
        LOCK();
        plVar19 = (longlong *)(*plVar19 + 0x150);
        *plVar19 = *plVar19 + 1;
        UNLOCK();
      }
    }
    lVar13 = *(longlong *)(*(longlong *)(param_1 + 0x28) + 0x488);
    if (((lVar13 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
      if (*(longlong *)(lVar13 + 0x20) != 0) {
        lVar25 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        lVar16 = *(longlong *)(lVar25 + 0x100);
        if (lVar16 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100b02;
          (*_DAT_)(0);
          lVar16 = *(longlong *)(lVar25 + 0x100);
        }
        plVar19 = plVar29;
        if (*(longlong *)(lVar16 + 0x260) != 0) {
          plVar19 = (longlong *)(ulonglong)*(uint *)(*(longlong *)(lVar16 + 0x260) + 0xe68);
        }
        if ((uint)plVar19 < *(uint *)(_DAT_ + 8)) {
          lVar13 = *(longlong *)(*(longlong *)(lVar13 + 0x20) + (longlong)plVar19 * 8);
          *(longlong *)(lVar13 + 0x128) = *(longlong *)(lVar13 + 0x128) + 1;
          goto LAB_;
        }
      }
      LOCK();
      plVar19 = (longlong *)(*(longlong *)(lVar13 + 0x18) + 0x128);
      *plVar19 = *plVar19 + 1;
      UNLOCK();
    }
LAB_:
    puVar4 = *(undefined8 **)(&stack0x00000040 + lVar12);
    puVar4[1] = 0;
    *puVar4 = 0xffff;
    puVar4[3] = 0;
    puVar4[4] = 0;
    puVar4[2] = 0;
    *(undefined4 *)(puVar4 + 6) = 0;
    puVar4[5] = 0;
    *puStack_2bb8 = 0;
    puStack_2bb8[0xc] = 0;
    *(undefined2 *)(puStack_2bb8 + 0xd) = 0;
    *(undefined8 *)((longlong)puStack_2bb8 + 0x6c) = 1;
    puVar4 = (undefined8 *)puStack_2bb8[1];
    if (puVar4 != (undefined8 *)0x0) {
      puVar5 = (undefined8 *)puVar4[1];
      if (puVar5 != (undefined8 *)0x0) {
        *puVar5 = 0;
        *(undefined4 *)(puVar5 + 0x481) = 0;
      }
      puVar4[3] = 0;
      *(undefined2 *)(puVar4 + 4) = 0;
      *puVar4 = 0;
      *(undefined4 *)(puVar4 + 0x14b) = 0;
    }
    lVar13 = *(longlong *)(param_1 + 0xdf0);
    uVar9 = *(ushort *)(lVar13 + 0x1c);
    plVar19 = (longlong *)(ulonglong)(uVar9 - 2);
    if (uVar9 < 3) {
      plVar19 = plVar29;
    }
    iVar11 = *(int *)(param_1 + 0xb38);
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100bfc;
    iVar11 = func_0x(lVar13,&stack0x00000038 + lVar12,plVar19,0x2000 - iVar11);
    if (iVar11 == 0) goto LAB_;
    psVar31 = *(short **)(&stack0x00000040 + lVar12);
    if (-1 < *(char *)(*(longlong *)(param_1 + 0xdf0) + 2)) {
      psVar31 = *(short **)(&stack0x00000038 + lVar12);
    }
    *(short **)((longlong)apsStackX_8 + lVar12 + 8) = psVar31;
    puVar23 = (ushort *)(psVar31 + 1);
    uVar28 = (ulonglong)*(uint *)(psVar31 + 2);
    if (*psVar31 == 0) {
      psVar32 = psVar31;
      if (*(uint *)(psVar31 + 2) == 0) {
        *puVar23 = 0;
        uVar21 = *(uint *)(psVar31 + 8);
        uVar28 = (ulonglong)uVar21;
        *(uint *)(psVar31 + 10) = uVar21;
        pbVar27 = *(byte **)(psVar31 + 4);
        bVar18 = *pbVar27;
        if ((bVar18 & 0x10) != 0) {
          uVar21 = uVar21 + 2 + (*(ushort *)(pbVar27 + uVar28) + 7 >> 3);
          uVar28 = (ulonglong)uVar21;
          *(uint *)(psVar31 + 10) = uVar21;
          bVar18 = *pbVar27;
        }
        if ((bVar18 & 0x20) == 0) {
          *(int *)(psVar31 + 2) = (int)uVar28;
          psVar31[0xe] = 0;
          *(int *)(psVar31 + 0xc) = (int)uVar28;
        }
        else {
          puVar30 = (ushort *)(pbVar27 + uVar28);
          uVar9 = *puVar30;
          psVar31[0xe] = uVar9;
          if (uVar9 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100c9a;
            cVar8 = func_0x(0x19c6960);
            if (cVar8 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100ca3;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100cbd;
                cVar8 = func_0x(0x19c6960);
                if (cVar8 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100cd9;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100cff;
                  (*_DAT_)(1,0x12b636c,0x13d6458,0x80f);
                }
              }
            }
            uVar14 = *(undefined8 *)(psVar31 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d0d;
            func_0x(uVar14,3);
            uVar28 = (ulonglong)*(uint *)(psVar31 + 10);
            uVar9 = psVar31[0xe];
          }
          uVar21 = (int)uVar28 + (uVar9 + 1) * 2;
          *(uint *)(psVar31 + 0xc) = uVar21;
          if (0x1f9e < uVar21) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d3d;
            cVar8 = func_0x(0x19c6960);
            if (cVar8 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d46;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d60;
                cVar8 = func_0x(0x19c6960);
                if (cVar8 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100d7c;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100da2;
                  (*_DAT_)(1,0x12b636c,0x13d6458,0x816);
                }
              }
            }
            uVar14 = *(undefined8 *)(psVar31 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100db0;
            func_0x(uVar14,4);
            uVar9 = psVar31[0xe];
            uVar21 = *(uint *)(psVar31 + 0xc);
          }
          uVar28 = (ulonglong)uVar9;
          uVar9 = puVar30[uVar28];
          *(uint *)(psVar31 + 2) = uVar9 & 0x7fff;
          if ((uVar9 & 0x7fff) < uVar21) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100de0;
            cVar8 = func_0x(0x19c6960);
            if (cVar8 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100de9;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100e03;
                cVar8 = func_0x(0x19c6960);
                if (cVar8 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100e1f;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100e45;
                  (*_DAT_)(1,0x12b636c,0x13d6458,0x81d);
                }
              }
            }
            uVar14 = *(undefined8 *)(psVar31 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100e53;
            func_0x(uVar14,4);
            uVar21 = *(uint *)(psVar31 + 0xc);
            uVar28 = (ulonglong)(ushort)psVar31[0xe];
          }
          iVar11 = 0;
          puVar6 = puVar30;
          if ((short)uVar28 != 0) {
            do {
              uVar24 = puVar6[1] & 0x7fff;
              if ((uVar24 < uVar21) || (*(uint *)(psVar31 + 2) < uVar24)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100e9f;
                cVar8 = func_0x(0x19c6960);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100ea8;
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100ec2;
                    cVar8 = func_0x(0x19c6960);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100ede;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100f02;
                      (*_DAT_)(1,0x12b636c,0x13d6458,0x82a);
                    }
                  }
                }
                uVar14 = *(undefined8 *)(psVar31 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100f10;
                func_0x(uVar14,4);
              }
              iVar11 = iVar11 + 1;
              uVar28 = (ulonglong)(ushort)psVar31[0xe];
              puVar6 = puVar6 + 1;
              uVar21 = uVar24;
            } while (iVar11 < (int)(uint)(ushort)psVar31[0xe]);
            psVar32 = *(short **)((longlong)apsStackX_8 + lVar12 + 8);
          }
          if ((short)puVar30[(ulonglong)((int)uVar28 - 1) + 1] < 0) {
            lVar13 = *(longlong *)(psVar31 + 4);
            do {
              uVar21 = *(ushort *)((ulonglong)*(uint *)(psVar31 + 10) + lVar13 + uVar28 * 2) &
                       0x7fff;
              if ((int)uVar28 == 1) {
                uVar24 = *(uint *)(psVar31 + 0xc);
                uVar22 = uVar24;
LAB_:
                if ((uVar21 < uVar24) || (uVar2 = *(uint *)(psVar31 + 2), uVar2 < uVar21))
                goto LAB_;
              }
              else {
                uVar24 = *(ushort *)((ulonglong)*(uint *)(psVar31 + 10) + lVar13 + -2 + uVar28 * 2)
                         & 0x7fff;
                uVar22 = *(uint *)(psVar31 + 0xc);
                if (uVar22 <= uVar24) goto LAB_;
LAB_:
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100f9c;
                func_0x(lVar13,7);
                uVar22 = *(uint *)(psVar31 + 0xc);
                uVar2 = *(uint *)(psVar31 + 2);
              }
              uVar28 = (ulonglong)uVar2;
              if ((uVar24 < uVar22) || (uVar2 < uVar24)) goto LAB_;
              lVar13 = *(longlong *)(psVar31 + 4);
              if (*(ushort *)(lVar13 + (ulonglong)uVar24) == 5) {
                *puVar23 = *puVar23 | 2;
                psVar31[0xe] = psVar31[0xe] + -1;
                uVar26 = (ulonglong)(uVar24 & 0xffff);
                psVar31[0x15] = (short)uVar24;
                uVar28 = *(ulonglong *)(psVar31 + 4);
                uVar9 = psVar31[0x16] & 0xc7ffU;
                if ((*(ushort *)(uVar26 + 2 + uVar28) >> 0xe & 1) != 0) {
                  uVar9 = *(ushort *)(uVar26 + 2 + uVar28) & 0x3800 | psVar31[0x16] & 0xc7ffU;
                }
                psVar31[0x16] = uVar9;
                uVar10 = (uVar9 ^ *(ushort *)(uVar26 + 2 + uVar28)) & 0x7ff ^ uVar9;
                psVar31[0x16] = uVar10;
                uVar26 = (ulonglong)(ushort)psVar31[0x15];
                uVar33 = uVar26 + 4 +
                         (ulonglong)((uVar10 & 0x7ff) * 2) + uVar28 + (uVar9 >> 0xb & 7) * 2;
                if (uVar33 < uVar26 + uVar28) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1010ae;
                  func_0x(uVar26 + uVar28,0x19);
                  uVar10 = psVar31[0x16];
                  uVar26 = (ulonglong)(ushort)psVar31[0x15];
                  uVar28 = (ulonglong)*(uint *)(psVar31 + 4);
                }
                if (uVar21 - uVar24 <
                    (((uVar10 & 0x7ff) * 2 - (int)uVar26) - (int)uVar28) + (int)uVar33) {
                  lVar13 = *(longlong *)(psVar31 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1010e6;
                  func_0x(uVar26 + lVar13,0x19);
                  uVar10 = psVar31[0x16];
                }
                if ((uVar10 & 0x3800) != 0) {
                  puVar30 = (ushort *)
                            (*(longlong *)(psVar31 + 4) + 4 + (ulonglong)(ushort)psVar31[0x15]);
                  iVar11 = 0;
                  if ((uVar10 & 0x3800) != 0) {
                    do {
                      if ((uVar10 & 0x7ff) < (*puVar30 & 0x7ff)) {
                        uVar9 = psVar31[0x15];
                        lVar13 = *(longlong *)(psVar31 + 4);
                        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101146;
                        func_0x((ulonglong)uVar9 + lVar13,0x1a);
                        uVar10 = psVar31[0x16];
                      }
                      iVar11 = iVar11 + 1;
                      puVar30 = puVar30 + 1;
                    } while (iVar11 < (int)(uVar10 >> 0xb & 7));
                  }
                }
                break;
              }
              if (*(ushort *)(lVar13 + (ulonglong)uVar24) < 0x400) break;
              *puVar23 = *puVar23 | 1;
              uVar9 = psVar31[0xe] - 1;
              psVar31[0xe] = uVar9;
              if ((uVar9 == 0) ||
                 (uVar28 = (ulonglong)uVar9, -1 < (short)puVar30[(ulonglong)(uVar9 - 1) + 1]))
              break;
            } while( true );
          }
          pbVar27 = *(byte **)(psVar31 + 4);
          uVar28 = (ulonglong)*(uint *)(psVar31 + 2);
        }
        iVar11 = 0;
        if ((*pbVar27 & 0x40) == 0) {
          *(undefined4 *)(psVar31 + 0x13) = 0;
        }
        else {
          *(int *)(psVar31 + 0x13) = (int)uVar28;
          *(int *)(psVar31 + 2) = (int)uVar28 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10118c;
          puVar17 = (ulonglong *)func_0x(puVar23);
          uVar28 = *puVar17;
          uVar10 = (ushort)(uVar28 >> 0x30);
          uVar9 = uVar10;
          if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
            uVar9 = uVar10 & 0xdfff;
            if ((uVar28 & 0x4000000000000000) != 0) {
              uVar9 = uVar10 | 0x2000;
            }
          }
          if (uVar9 == 0xfffc) {
            iVar11 = (int)((uVar28 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + iVar11;
          uVar28 = (ulonglong)*(uint *)(psVar31 + 2);
        }
        if ((*(ulonglong *)(psVar31 + 0xf) != 0) &&
           (*(ulonglong *)(psVar31 + 0xf) < uVar28 + *(longlong *)(psVar31 + 4))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101211;
          cVar8 = func_0x(0x19c6960);
          if (cVar8 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10121a;
            lVar13 = func_0x();
            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101234;
              cVar8 = func_0x(0x19c6960);
              if (cVar8 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101250;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101274;
                (*_DAT_)(1,0x12b636c,0x13d6458,0x886);
              }
            }
          }
          uVar14 = *(undefined8 *)(psVar31 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x101282;
          func_0x(uVar14,0x12);
          uVar28 = (ulonglong)*(uint *)(psVar31 + 2);
        }
        if (((uint)uVar28 == 0) || (0x3f3c < (uint)uVar28)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1012a4;
          cVar8 = func_0x(0x19c6960);
          if (cVar8 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1012b1;
            lVar13 = func_0x();
            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1012d3;
              cVar8 = func_0x(0x19c6960);
              if (cVar8 == '\0') goto LAB_;
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1012fd;
              (*_DAT_)(1,0x12b636c,0x13d6458,0x88b);
            }
          }
          goto LAB_;
        }
      }
      goto LAB_;
    }
  }
  else {
    psVar31 = *(short **)(&stack0x00000040 + lVar12);
    if (-1 < *(char *)(*(longlong *)(param_1 + 0xdf0) + 2)) {
      psVar31 = *(short **)(&stack0x00000038 + lVar12);
    }
    *(short **)((longlong)apsStackX_8 + lVar12) = psVar31;
    puVar23 = (ushort *)(psVar31 + 1);
    uVar28 = (ulonglong)*(uint *)(psVar31 + 2);
    if (*psVar31 == 0) {
      psVar32 = psVar31;
      if (*(uint *)(psVar31 + 2) == 0) {
        *puVar23 = 0;
        uVar21 = *(uint *)(psVar31 + 8);
        uVar28 = (ulonglong)uVar21;
        *(uint *)(psVar31 + 10) = uVar21;
        pbVar27 = *(byte **)(psVar31 + 4);
        bVar18 = *pbVar27;
        if ((bVar18 & 0x10) != 0) {
          uVar21 = uVar21 + 2 + (*(ushort *)(pbVar27 + uVar28) + 7 >> 3);
          uVar28 = (ulonglong)uVar21;
          *(uint *)(psVar31 + 10) = uVar21;
          bVar18 = *pbVar27;
        }
        if ((bVar18 & 0x20) == 0) {
          *(int *)(psVar31 + 2) = (int)uVar28;
          psVar31[0xe] = 0;
          *(int *)(psVar31 + 0xc) = (int)uVar28;
        }
        else {
          puVar30 = (ushort *)(pbVar27 + uVar28);
          uVar9 = *puVar30;
          psVar31[0xe] = uVar9;
          if (uVar9 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10016d;
            cVar8 = func_0x(0x19c6960);
            if (cVar8 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100176;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100190;
                cVar8 = func_0x(0x19c6960);
                if (cVar8 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001ab;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001d3;
                  (*_DAT_)(1,0x12b636c,0x13d6458,0x80f);
                }
              }
            }
            uVar14 = *(undefined8 *)(psVar31 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1001e1;
            func_0x(uVar14,3);
            uVar28 = (ulonglong)*(uint *)(psVar31 + 10);
            uVar9 = psVar31[0xe];
          }
          uVar21 = (int)uVar28 + (uVar9 + 1) * 2;
          *(uint *)(psVar31 + 0xc) = uVar21;
          if (0x1f9e < uVar21) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100211;
            cVar8 = func_0x(0x19c6960);
            if (cVar8 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10021a;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100234;
                cVar8 = func_0x(0x19c6960);
                if (cVar8 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100250;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100278;
                  (*_DAT_)(1,0x12b636c,0x13d6458,0x816);
                }
              }
            }
            uVar14 = *(undefined8 *)(psVar31 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100286;
            func_0x(uVar14,4);
            uVar9 = psVar31[0xe];
            uVar21 = *(uint *)(psVar31 + 0xc);
          }
          uVar28 = (ulonglong)uVar9;
          uVar9 = puVar30[uVar28];
          *(uint *)(psVar31 + 2) = uVar9 & 0x7fff;
          if ((uVar9 & 0x7fff) < uVar21) {
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1002b6;
            cVar8 = func_0x(0x19c6960);
            if (cVar8 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1002bf;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1002d9;
                cVar8 = func_0x(0x19c6960);
                if (cVar8 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1002f5;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10031d;
                  (*_DAT_)(1,0x12b636c,0x13d6458,0x81d);
                }
              }
            }
            uVar14 = *(undefined8 *)(psVar31 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10032b;
            func_0x(uVar14,4);
            uVar21 = *(uint *)(psVar31 + 0xc);
            uVar28 = (ulonglong)(ushort)psVar31[0xe];
          }
          iVar11 = 0;
          puVar6 = puVar30;
          if ((short)uVar28 != 0) {
            do {
              uVar24 = puVar6[1] & 0x7fff;
              if ((uVar24 < uVar21) || (*(uint *)(psVar31 + 2) < uVar24)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10036f;
                cVar8 = func_0x(0x19c6960);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100378;
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100392;
                    cVar8 = func_0x(0x19c6960);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1003ae;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1003d2;
                      (*_DAT_)(1,0x12b636c,0x13d6458,0x82a);
                    }
                  }
                }
                uVar14 = *(undefined8 *)(psVar31 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1003e0;
                func_0x(uVar14,4);
              }
              iVar11 = iVar11 + 1;
              uVar28 = (ulonglong)(ushort)psVar31[0xe];
              puVar6 = puVar6 + 1;
              uVar21 = uVar24;
            } while (iVar11 < (int)(uint)(ushort)psVar31[0xe]);
            psVar32 = *(short **)((longlong)apsStackX_8 + lVar12);
          }
          if ((short)puVar30[(ulonglong)((int)uVar28 - 1) + 1] < 0) {
            lVar13 = *(longlong *)(psVar31 + 4);
            do {
              uVar21 = *(ushort *)((ulonglong)*(uint *)(psVar31 + 10) + lVar13 + uVar28 * 2) &
                       0x7fff;
              if ((int)uVar28 == 1) {
                uVar24 = *(uint *)(psVar31 + 0xc);
                uVar22 = uVar24;
LAB_:
                if ((uVar21 < uVar24) || (uVar2 = *(uint *)(psVar31 + 2), uVar2 < uVar21))
                goto LAB_;
              }
              else {
                uVar24 = *(ushort *)((ulonglong)*(uint *)(psVar31 + 10) + lVar13 + -2 + uVar28 * 2)
                         & 0x7fff;
                uVar22 = *(uint *)(psVar31 + 0xc);
                if (uVar22 <= uVar24) goto LAB_;
LAB_:
                *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10046c;
                func_0x(lVar13,7);
                uVar22 = *(uint *)(psVar31 + 0xc);
                uVar2 = *(uint *)(psVar31 + 2);
              }
              uVar28 = (ulonglong)uVar2;
              if ((uVar24 < uVar22) || (uVar2 < uVar24)) goto LAB_;
              lVar13 = *(longlong *)(psVar31 + 4);
              if (*(ushort *)(lVar13 + (ulonglong)uVar24) == 5) {
                *puVar23 = *puVar23 | 2;
                psVar31[0xe] = psVar31[0xe] + -1;
                uVar26 = (ulonglong)(uVar24 & 0xffff);
                psVar31[0x15] = (short)uVar24;
                uVar28 = *(ulonglong *)(psVar31 + 4);
                uVar9 = psVar31[0x16] & 0xc7ffU;
                if ((*(ushort *)(uVar26 + 2 + uVar28) >> 0xe & 1) != 0) {
                  uVar9 = *(ushort *)(uVar26 + 2 + uVar28) & 0x3800 | psVar31[0x16] & 0xc7ffU;
                }
                psVar31[0x16] = uVar9;
                uVar10 = (uVar9 ^ *(ushort *)(uVar26 + 2 + uVar28)) & 0x7ff ^ uVar9;
                psVar31[0x16] = uVar10;
                uVar26 = (ulonglong)(ushort)psVar31[0x15];
                uVar33 = uVar28 + 4 +
                         (ulonglong)((uVar10 & 0x7ff) * 2) + uVar26 + (uVar9 >> 0xb & 7) * 2;
                if (uVar33 < uVar26 + uVar28) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100574;
                  func_0x(uVar26 + uVar28,0x19);
                  uVar10 = psVar31[0x16];
                  uVar26 = (ulonglong)(ushort)psVar31[0x15];
                  uVar28 = (ulonglong)*(uint *)(psVar31 + 4);
                }
                if (uVar21 - uVar24 <
                    (((uVar10 & 0x7ff) * 2 - (int)uVar26) - (int)uVar28) + (int)uVar33) {
                  lVar13 = *(longlong *)(psVar31 + 4);
                  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1005ac;
                  func_0x(uVar26 + lVar13,0x19);
                  uVar10 = psVar31[0x16];
                }
                if ((uVar10 & 0x3800) != 0) {
                  puVar30 = (ushort *)
                            (*(longlong *)(psVar31 + 4) + 4 + (ulonglong)(ushort)psVar31[0x15]);
                  iVar11 = 0;
                  if ((uVar10 & 0x3800) != 0) goto LAB_;
                }
                break;
              }
              if (*(ushort *)(lVar13 + (ulonglong)uVar24) < 0x400) break;
              *puVar23 = *puVar23 | 1;
              uVar9 = psVar31[0xe] - 1;
              psVar31[0xe] = uVar9;
              if ((uVar9 == 0) ||
                 (uVar28 = (ulonglong)uVar9, -1 < (short)puVar30[(ulonglong)(uVar9 - 1) + 1]))
              break;
            } while( true );
          }
          pbVar27 = *(byte **)(psVar31 + 4);
          uVar28 = (ulonglong)*(uint *)(psVar31 + 2);
        }
        goto LAB_;
      }
      goto LAB_;
    }
  }
  if ((int)uVar28 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1007d8;
    func_0x(puVar23);
    uVar28 = (ulonglong)*(uint *)(puVar23 + 1);
  }
  if ((uint)uVar28 < 9) {
    bVar18 = **(byte **)(puVar23 + 3) & 0x1c;
joined_r0x001007c4:
    if ((bVar18 == 0) || (bVar18 == 0xc)) {
      uVar28 = 9;
    }
  }
  goto LAB_;
LAB_:
  do {
    if ((uVar10 & 0x7ff) < (*puVar30 & 0x7ff)) {
      uVar9 = psVar31[0x15];
      lVar13 = *(longlong *)(psVar31 + 4);
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100616;
      func_0x((ulonglong)uVar9 + lVar13,0x1a);
      uVar10 = psVar31[0x16];
    }
    iVar11 = iVar11 + 1;
    puVar30 = puVar30 + 1;
  } while (iVar11 < (int)(uVar10 >> 0xb & 7));
  pbVar27 = *(byte **)(psVar31 + 4);
  uVar28 = (ulonglong)*(uint *)(psVar31 + 2);
LAB_:
  if ((*pbVar27 & 0x40) == 0) {
    *(undefined4 *)(psVar31 + 0x13) = 0;
  }
  else {
    *(int *)(psVar31 + 0x13) = (int)uVar28;
    *(int *)(psVar31 + 2) = (int)uVar28 + 0xe;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10065e;
    uVar14 = func_0x(puVar23);
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10066b;
    func_0x(uVar14,(longlong)apsStackX_8 + lVar12);
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100675;
    iVar11 = func_0x((longlong)apsStackX_8 + lVar12);
    *(int *)(psVar31 + 2) = *(int *)(psVar31 + 2) + iVar11;
    uVar28 = (ulonglong)*(uint *)(psVar31 + 2);
  }
  if ((*(ulonglong *)(psVar31 + 0xf) != 0) &&
     (*(ulonglong *)(psVar31 + 0xf) < uVar28 + *(longlong *)(psVar31 + 4))) {
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1006ac;
    cVar8 = func_0x(0x19c6960);
    if (cVar8 != '\0') {
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1006b5;
      lVar13 = func_0x();
      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1006cf;
        cVar8 = func_0x(0x19c6960);
        if (cVar8 == '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1006eb;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10070f;
          (*_DAT_)(1,0x12b636c,0x13d6458,0x886);
        }
      }
    }
    uVar14 = *(undefined8 *)(psVar31 + 4);
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10071d;
    func_0x(uVar14,0x12);
    uVar28 = (ulonglong)*(uint *)(psVar31 + 2);
  }
  if (((uint)uVar28 == 0) || (0x3f3c < (uint)uVar28)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10073f;
    cVar8 = func_0x(0x19c6960);
    if (cVar8 != '\0') {
      *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100748;
      lVar13 = func_0x();
      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
        *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x100762;
        cVar8 = func_0x(0x19c6960);
        if (cVar8 == '\0') {
LAB_:
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10077e;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar12) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1007a2;
          (*_DAT_)(1,0x12b636c,0x13d6458,0x88b);
        }
      }
    }
LAB_:
    uVar14 = *(undefined8 *)(puVar23 + 3);
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1007b0;
    func_0x(uVar14,5);
    uVar28 = (ulonglong)*(uint *)(puVar23 + 1);
  }
LAB_:
  psVar31 = psVar32;
  if ((uint)uVar28 < 9) {
    bVar18 = **(byte **)(puVar23 + 3) & 0xe;
    goto joined_r0x001007c4;
  }
LAB_:
  uVar14 = *(undefined8 *)(psVar31 + 4);
  uVar15 = *(undefined8 *)(*(longlong *)((longlong)&lStackX_18 + lVar12) + 0xdf0);
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x10080e;
  func_0x(uVar15,uVar14,uVar28);
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1013f2;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar12));
  return;
}

