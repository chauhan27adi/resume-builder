
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_(longlong param_1,undefined (*param_2) [16],ulonglong param_3)

{
  ushort uVar1;
  ushort uVar2;
  ushort uVar3;
  undefined8 uVar4;
  undefined auVar5 [16];
  undefined4 uVar6;
  undefined2 **ppuVar7;
  char cVar8;
  int iVar9;
  int iVar10;
  longlong lVar11;
  ulonglong uVar12;
  longlong lVar13;
  longlong lVar14;
  longlong *plVar15;
  undefined8 uVar16;
  code *UNRECOVERED_JUMPTABLE_00;
  uint *puVar17;
  ulonglong uVar18;
  undefined8 unaff_RBX;
  ulonglong uVar19;
  uint uVar20;
  ulonglong uVar21;
  ushort *puVar22;
  byte *pbVar23;
  undefined2 uVar24;
  uint uVar25;
  uint uVar26;
  ushort uVar27;
  longlong unaff_GS_OFFSET;
  bool bVar28;
  bool bVar29;
  undefined4 extraout_XMM0_Da;
  uint uStackX_8;
  uint uStackX_c;
  ushort auStackX_10 [4];
  undefined4 uStackX_18;
  ushort auStackX_1c [2];
  undefined8 uStackX_20;
  undefined2 uStack_46a8;
  uint uStack_46a0;
  ushort uStack_469c;
  undefined4 uStack_4698;
  undefined2 uStack_4694;
  undefined4 uStack_4688;
  ushort uStack_4684;
  int iStack_4680;
  ushort uStack_467c;
  undefined4 uStack_4678;
  undefined8 uStack_4670;
  longlong lStack_4660;
  longlong lStack_4658;
  longlong lStack_4648;
  longlong lStack_4640;
  undefined4 uStack_4638;
  undefined4 auStack_4630 [2];
  undefined8 uStack_4628;
  undefined8 uStack_4620;
  undefined8 uStack_4618;
  undefined8 uStack_4610;
  undefined8 uStack_4608;
  undefined auStack_4378 [8];
  undefined4 uStack_4370;
  undefined4 uStack_4368;
  undefined2 **ppuStack_4360;
  undefined *puStack_4358;
  undefined8 uStack_4350;
  undefined2 *puStack_4348;
  undefined4 uStack_4340;
  undefined4 uStack_433c;
  longlong lStack_4338;
  int iStack_4330;
  undefined4 uStack_432c;
  undefined8 uStack_4328;
  undefined4 uStack_4320;
  undefined4 uStack_431c;
  undefined auStack_4318 [496];
  undefined8 uStack_4128;
  undefined8 uStack_4120;
  undefined2 auStack_4118 [16];
  undefined2 uStack_40f8;
  undefined4 uStack_40f4;
  byte *pbStack_40f0;
  undefined8 uStack_40e8;
  undefined8 uStack_40da;
  undefined2 uStack_40d2;
  undefined2 uStack_40d0;
  undefined6 uStack_40ce;
  undefined4 uStack_40c4;
  undefined auStack_40c0 [16];
  undefined auStack_40b0 [8];
  undefined8 uStack_40a8;
  undefined8 uStack_40a0;
  undefined6 uStack_4098;
  undefined2 uStack_4092;
  undefined6 uStack_4090;
  undefined2 uStack_408a;
  undefined2 uStack_4088;
  undefined6 uStack_4086;
  undefined8 uStack_4080;
  short *psStack_4078;
  undefined *puStack_4070;
  short sStack_4068;
  undefined6 uStack_4066;
  undefined auStack_4060 [8];
  undefined2 uStack_4058;
  undefined auStack_4056 [6];
  undefined8 uStack_4050;
  byte abStack_4048 [24];
  int iStack_4030;
  undefined4 uStack_4028;
  ushort uStack_4024;
  undefined8 uStack_4020;
  undefined2 uStack_4018;
  undefined auStack_3fe8 [2];
  undefined auStack_3fe6 [8092];
  ushort uStack_204a;
  short asStack_1048 [2048];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  uStack_4608 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00004708 + lVar11) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar11);
  uVar21 = param_3 & 0xffffffff;
  *(int *)((longlong)&uStackX_8 + lVar11) = (int)param_3;
  *(undefined (**) [16])(&stack0x00000030 + lVar11) = param_2;
  lStack_4658 = param_1;
  if ((*param_2)[1] != 'd') {
    uVar19 = 0;
    if ((*(uint *)(param_1 + 0x15f8) & 0x4000) != 0) {
      if (*(int *)((longlong)&uStackX_8 + lVar11) != 0) {
        puVar22 = (ushort *)(param_2[2] + 4);
        uVar27 = *(ushort *)((longlong)auStackX_10 + lVar11);
        uVar20 = *(uint *)((longlong)&uStackX_c + lVar11);
        uVar26 = *(uint *)((longlong)&uStackX_8 + lVar11);
        uVar21 = uVar19;
        do {
          uVar25 = 1;
          if ((uVar21 & 7) == 0) {
            uVar20 = *(uint *)(puVar22 + -2);
            uVar27 = *puVar22;
            *(ushort *)((longlong)auStackX_10 + lVar11) = uVar27;
          }
          else {
            uVar20 = uVar20 + 1;
          }
          *(uint *)((longlong)&uStackX_c + lVar11) = uVar20;
          if (*(char *)((longlong)puVar22 + -0x23) != 'e') {
            if ((puVar22[-0x10] & 0x200) == 0) {
              if ((puVar22[-0x10] & 0x100) != 0) {
                if (1 < (byte)((*(byte *)(puVar22 + 0xc) & 3) - 1)) goto LAB_;
                do {
                  if ((*(byte *)((ulonglong)(uVar25 << 9) + 0x1db + (longlong)puVar22) & 3) !=
                      (*(byte *)(puVar22 + 0xc) & 3)) goto LAB_;
                  uVar25 = uVar25 + 1;
                } while (uVar25 < 0x10);
              }
            }
            else {
              if ((*(uint *)(puVar22 + -2) == uVar20) && (*puVar22 == uVar27)) {
                uVar26 = *(uint *)(puVar22 + 0xc);
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100106;
                iVar9 = func_0x
                                  (puVar22 + -0x12,0x2000,(uVar26 >> 1) + uVar26 * -0x80000000);
                if (iVar9 == *(int *)(puVar22 + 0xc)) goto LAB_;
              }
LAB_:
              if ((_DAT_ == 0) || (DAT_ == '\0')) {
                uVar26 = *(uint *)(param_1 + 0x15f8);
LAB_:
                *(uint *)(param_1 + 0x1604) = *(uint *)(param_1 + 0x1604) | 0x4000;
              }
              else {
                uVar26 = *(uint *)(param_1 + 0x15f8);
                if (((uVar26 >> 0x19 & 1) != 0) || ((*(byte *)(param_1 + 0x1018) & 0x10) != 0))
                goto LAB_;
              }
              if (((uVar26 >> 0x19 & 1) == 0) &&
                 (((_DAT_ == 0 || (DAT_ == '\0')) ||
                  ((*(byte *)(param_1 + 0x1018) & 0x10) != 0)))) {
                puVar17 = &uStack_46a0;
                uVar16 = 2;
                uStack_46a0 = uVar20;
                uStack_469c = uVar27;
LAB_:
                uVar4 = *(undefined8 *)(param_1 + 0xb0);
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1003f6;
                func_0x(uVar16,puVar17,uVar4);
              }
              else {
                if ((DAT_ & 4) == 0) {
                  lVar13 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            );
                  if ((lVar13 != 0) && (lVar13 = **(longlong **)(lVar13 + 0x38), lVar13 != 0)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10021c;
                    iVar9 = (*_DAT_)(lVar13,0xbba);
                    if (iVar9 != 0) {
                      uVar27 = *(ushort *)((longlong)auStackX_10 + lVar11);
                      uVar20 = *(uint *)((longlong)&uStackX_c + lVar11);
                      goto LAB_;
                    }
                  }
                  uVar27 = *(ushort *)((longlong)auStackX_10 + lVar11);
                  uVar16 = *(undefined8 *)(param_1 + 0xb0);
                  uVar20 = *(uint *)((longlong)&uStackX_c + lVar11);
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10024d;
                  func_0x(0xc6f,uVar27,uVar20,uVar16);
                }
LAB_:
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100255;
                iVar9 = func_0x(param_1);
                if (iVar9 == 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10026b;
                  lVar13 = func_0x(extraout_XMM0_Da,0,uVar27);
                  if ((*(uint *)(param_1 + 0x15f8) & 0x2000000) == 0) {
                    if (lVar13 == 0) {
LAB_:
                      uVar16 = *(undefined8 *)(param_1 + 0xb0);
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10039e;
                      func_0x(0xcefb20,uVar27,uVar20,uVar16);
                    }
                    else {
                      bVar28 = uVar27 < *(ushort *)(lVar13 + 0x19c);
                      bVar29 = uVar27 == *(ushort *)(lVar13 + 0x19c);
                      if (bVar29) {
                        bVar28 = uVar20 < *(uint *)(lVar13 + 0x198);
                        bVar29 = uVar20 == *(uint *)(lVar13 + 0x198);
                      }
                      if (bVar28 || bVar29) {
                        lVar13 = *(longlong *)(param_1 + 0xb0);
                        uVar12 = 0xffffffffffffffff;
                        do {
                          uVar12 = uVar12 + 1;
                        } while (*(short *)(lVar13 + uVar12 * 2) != 0);
                        if (_DAT_ != 0) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100352;
                          cVar8 = func_0x(_DAT_,lVar13,uVar12 & 0xffffffff,
                                                  (longlong)&uStackX_c + lVar11);
                          if (cVar8 != '\0') goto LAB_;
                        }
                        uVar16 = 2;
                        if (_DAT_ != 0) {
                          uVar16 = 4;
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10037e;
                        (*_DAT_)(0x76,uVar16,0x10,0xb);
                        goto LAB_;
                      }
                      if (lVar13 == 0) goto LAB_;
                      uStack_4698 = *(undefined4 *)(lVar13 + 0x198);
                      uStack_4694 = *(undefined2 *)(lVar13 + 0x19c);
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) =
                           *(undefined8 *)(param_1 + 0xb0);
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1003d6;
                      func_0x(0xcefa00,uVar27,&uStack_4698,uVar20);
                    }
                    *(uint *)(&stack0x00000038 + lVar11) = uVar20;
                    *(ushort *)(&stack0x0000003c + lVar11) = uVar27;
                    puVar17 = (uint *)(&stack0x00000038 + lVar11);
                    uVar16 = 1;
                    goto LAB_;
                  }
                  if (lVar13 != 0) {
                    bVar28 = uVar27 < *(ushort *)(lVar13 + 0x19c);
                    bVar29 = uVar27 == *(ushort *)(lVar13 + 0x19c);
                    if (bVar29) {
                      bVar28 = uVar20 + 7 < *(uint *)(lVar13 + 0x198);
                      bVar29 = uVar20 + 7 == *(uint *)(lVar13 + 0x198);
                    }
                    if (bVar28 || bVar29) {
                      uVar1 = puVar22[-0x10];
                      uVar2 = *(ushort *)(lVar13 + 0x40);
                      uVar3 = *(ushort *)(*(longlong *)(lVar13 + 0x108) + 0x1490);
                      if (_DAT_ != 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1002ee;
                        func_0x(_DAT_,(longlong)&uStackX_c + lVar11,
                                        (uint)uVar2 * 0x10000 + (uint)uVar3,
                                        3 - (uint)((uVar1 & 0x200) != 0));
                      }
                    }
                  }
                }
              }
            }
LAB_:
            uVar26 = *(uint *)((longlong)&uStackX_8 + lVar11);
          }
          uVar25 = (int)uVar21 + 1;
          uVar21 = (ulonglong)uVar25;
          puVar22 = puVar22 + 0x1000;
        } while (uVar25 < uVar26);
        param_2 = *(undefined (**) [16])(&stack0x00000030 + lVar11);
      }
      uVar21 = (ulonglong)*(uint *)((longlong)&uStackX_8 + lVar11);
    }
    uVar20 = (uint)uVar21;
    uVar12 = *(ulonglong *)(param_1 + 0x868);
    if (*(ulonglong *)(param_1 + 0x868) == param_1 + 0x860U) {
      uVar12 = uVar19;
    }
    plVar15 = (longlong *)0x60;
    if (uVar12 != 0) {
      plVar15 = (longlong *)(uVar12 + 0x38);
    }
    lStack_4660 = *(longlong *)(*(longlong *)(*plVar15 + 0x10) + 0xf0);
    if ((lStack_4660 != 0) && (uVar20 != 0)) {
      param_2 = param_2 + 2;
      do {
        if (*(int *)*param_2 == 9) {
          if (*(short *)(*param_2 + 4) != 1) {
LAB_:
            uVar24 = *(undefined2 *)(*param_2 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1004a7;
            lVar13 = func_0x(param_1,0,uVar24);
            uVar12 = uVar19;
            if (lVar13 != 0) {
              uVar12 = *(ulonglong *)(lVar13 + 0x4e0);
            }
            uVar27 = *(ushort *)(param_2[-2] + 4);
            if ((uVar27 >> 9 & 1) == 0) {
              uVar18 = uVar19;
              if ((uVar27 >> 8 & 1) != 0) {
                uVar18 = 2;
              }
            }
            else {
              uVar18 = 1;
            }
            if ((uVar27 & 0xc00) == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1004e6;
              func_0x(param_2 + -2,uVar18,uVar12);
            }
          }
        }
        else if (*(int *)*param_2 != 0) goto LAB_;
        param_2 = param_2 + 0x200;
        uVar21 = uVar21 - 1;
      } while (uVar21 != 0);
      param_2 = *(undefined (**) [16])(&stack0x00000030 + lVar11);
      uVar20 = *(uint *)((longlong)&uStackX_8 + lVar11);
    }
    *(uint *)((longlong)&uStackX_8 + lVar11) = uVar20 >> 3;
    *(undefined4 *)(&stack0x00000028 + lVar11) = 0;
    uVar20 = *(uint *)((longlong)&uStackX_8 + lVar11);
    if (uVar20 != 0) {
      do {
        iVar9 = (int)uVar19;
        if ((*param_2)[1] != 'e') {
          iVar10 = *(int *)param_2[2];
          *(int *)((longlong)&uStackX_c + lVar11) = iVar10;
          uVar27 = *(ushort *)(param_2[2] + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100545;
          lVar13 = func_0x(param_1,0,uVar27);
          lStack_4648 = lVar13;
          if (lVar13 == 0) {
LAB_:
            *(uint *)(param_1 + 0x1604) = *(uint *)(param_1 + 0x1604) | 0x5000;
            if ((*(uint *)(param_1 + 0x15f8) >> 0x19 & 1) == 0) {
              uVar16 = *(undefined8 *)(param_1 + 0xb0);
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101d3c;
              iStack_4680 = iVar10;
              uStack_467c = uVar27;
              func_0x(3,&iStack_4680,uVar16);
            }
            else {
              if (((*(uint *)(param_1 + 0x15f8) >> 0xe & 1) == 0) && ((DAT_ & 4) == 0)) {
                lVar13 = *(longlong *)
                          ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
                if ((lVar13 != 0) && (**(longlong **)(lVar13 + 0x38) != 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1005e9;
                  iVar10 = (*_DAT_)();
                  if (iVar10 != 0) goto LAB_;
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100605;
                func_0x(0xc6f,uVar27,*(undefined4 *)((longlong)&uStackX_c + lVar11));
              }
LAB_:
              uStack_4670 = 0;
              *param_2 = ZEXT816(0);
              param_2[1] = ZEXT816(0);
              param_2[2] = ZEXT816(0);
              param_2[3] = ZEXT816(0);
              param_2[4] = ZEXT816(0);
              param_2[5] = ZEXT816(0);
              (*param_2)[0] = 1;
              *(undefined2 *)(param_2[2] + 4) = 0;
              *(undefined4 *)(param_2[1] + 0xc) = 0x601fa0;
              *(undefined8 *)(param_2[2] + 8) = 0;
              *(undefined2 *)param_2[3] = 1;
              if (1 < (0xfd0 - (ulonglong)*(ushort *)(param_2[1] + 6)) * 2) {
                *(undefined2 *)param_2[6] = 0;
              }
              (*param_2)[1] = 0x65;
            }
          }
          else if ((*(byte *)(param_1 + 0x1614) & 0x10) == 0) {
            bVar28 = uVar27 < *(ushort *)(lVar13 + 0x19c);
            bVar29 = uVar27 == *(ushort *)(lVar13 + 0x19c);
            if (bVar29) {
              bVar28 = iVar10 + 7U < *(uint *)(lVar13 + 0x198);
              bVar29 = iVar10 + 7U == *(uint *)(lVar13 + 0x198);
            }
            if (!bVar28 && !bVar29) goto LAB_;
          }
          else {
            uVar20 = *(uint *)(lVar13 + 0x198);
            uVar21 = (ulonglong)(uVar20 + 1);
            uVar1 = *(ushort *)(lVar13 + 0x19c);
            bVar28 = uVar27 < uVar1;
            if (uVar27 == uVar1) {
              bVar28 = iVar10 + 7U < uVar20;
            }
            if (bVar28 || uVar27 == uVar1 && iVar10 + 7U == uVar20) {
              if (((*param_2)[1] == '\x0f') && (iVar10 == 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1006c8;
                func_0x(abStack_4048,param_2,0x2000);
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1006e2;
                iVar9 = func_0x(abStack_4048,1,lStack_4660,1);
                if (iVar9 == 0) {
                  uVar24 = 0xffff;
                  uStack_40f8 = 0xffff;
                  pbStack_40f0 = (byte *)0x0;
                  uStack_40f4 = 0;
                  uStack_40da = 0;
                  uStack_40d0 = 0;
                  uStack_40ce = 0;
                  uStack_40e8 = 0;
                  *(undefined4 *)((longlong)&uStackX_18 + lVar11) = 0;
                  *(undefined2 *)((longlong)auStackX_1c + lVar11) = 0;
                  puVar22 = (ushort *)((longlong)auStackX_1c + lVar11 + 2);
                  *puVar22 = *puVar22 & 0xffe0;
                  *(undefined8 *)((longlong)auStackX_1c + lVar11 + 4) = 0;
                  uStack_40c4 = 0;
                  if ((abStack_4048[2] & 0x80) == 0) goto LAB_;
                  uStack_4098 = 0;
                  uStack_408a = SUB162(ZEXT816(0),6);
                  uStack_408a = 0;
                  uStack_4080 = 0;
                  puStack_4070 = (undefined *)0x0;
                  sStack_4068 = 0;
                  uStack_4066 = 0;
                  auStack_40c0 = ZEXT816(0);
                  lVar13 = 0;
                  stack0xffffffffffffbf52 = SUB1614(ZEXT816(0),2);
                  auStack_40b0._0_2_ = 0xffff;
                  uStack_40a8 = 0;
                  uStack_4092 = 0;
                  uStack_4090 = 0;
                  uStack_4088 = 0;
                  uStack_4086 = 0;
                  uStack_40a0 = 0;
                  psStack_4078 = (short *)0x0;
                  _auStack_4060 = ZEXT812(0);
                  auStack_4056._2_4_ = 0;
                  uStack_4050 = 0;
                  if ((uStack_4024 == 0) ||
                     ((((abStack_4048[1] != '\v' || (iStack_4030 != 99)) &&
                       ((abStack_4048[1] != '\b' || (iStack_4030 != 99)))) &&
                      ((abStack_4048[1] != '\t' || (iStack_4030 != 99)))))) {
LAB_:
                    auStack_40c0._8_8_ = lVar13;
                    *(undefined8 *)(&stack0x00000040 + lVar11) = uStack_4020;
                    uStack_46a8 = uStack_4018;
                  }
                  else {
                    uStack_4688 = uStack_4028;
                    uStack_4684 = uStack_4024;
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10082b;
                    uVar24 = 0xffff;
                    cVar8 = func_0x(&uStack_4688);
                    lVar13 = auStack_40c0._8_8_;
                    if (cVar8 == '\0') goto LAB_;
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100840;
                    func_0x(abStack_4048,&stack0x00000040 + lVar11);
                  }
                  auVar5 = _auStack_4060;
                  auStack_40c0._0_8_ = auStack_3fe8;
                  auStack_4060._4_4_ =
                       (int)((ulonglong)*(undefined8 *)(&stack0x00000040 + lVar11) >> 0x20);
                  auStack_4060._0_4_ = *(undefined4 *)(&stack0x00000040 + lVar11);
                  auStack_4056 = auVar5._10_6_;
                  uStack_4058 = uStack_46a8;
                  auStack_4056._2_4_ = uStack_4028;
                  uStack_4678 = *(undefined4 *)((ulonglong)auStack_3fe8[0] * 6 + 0x9e8900);
                  uVar6 = uStack_4678;
                  uVar21 = (ulonglong)*(short *)((ulonglong)auStack_3fe8[0] * 6 + 0x9e8904);
                  auStack_40b0._0_2_ = uVar24;
                  auStack_40b0 = (undefined  [8])((ulonglong)auStack_40b0 & 0xffffffff);
                  uStack_40a8 = 0;
                  uStack_4092 = 0;
                  uStack_4090 = 0;
                  uStack_4088 = 0;
                  uStack_4086 = 0;
                  uStack_40a0 = 0;
                  psStack_4078 = (short *)0x0;
                  puStack_4070 = (undefined *)0x0;
                  sStack_4068 = 0;
                  if ((auStack_3fe8[0] & 2) != 0) {
                    pbVar23 = auStack_3fe8 + uVar21;
                    uStack_40a8 = pbVar23;
                    if ((*pbVar23 & 1) == 0) {
                      auVar5._14_2_ = 0;
                      auVar5._0_14_ = stack0xffffffffffffbf52;
                      _auStack_40b0 = auVar5 << 0x10;
                      uStack_408a = 0;
                      uStack_4088 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100b09 */
                    /* WARNING: Treating indirect jump as call */
                      (*(code *)((ulonglong)
                                 *(uint *)((longlong)(int)(*pbVar23 & 0xe) * 4 + 0x101d78) -
                                0x1bb0510))();
                      return;
                    }
                    auStack_40b0._0_2_ = 1;
                    UNRECOVERED_JUMPTABLE_00 =
                         (code *)((ulonglong)
                                  *(uint *)((ulonglong)
                                            *(byte *)((longlong)(int)(*pbVar23 & 0x1c) + 0x101d58) *
                                            4 + 0x101d48) - 0x1bb0510);
                    /* WARNING: Could not emulate address calculation at 0x00100958 */
                    /* WARNING: Treating indirect jump as call */
                    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
                    return;
                  }
                  if ((auStack_3fe8[0] & 4) != 0) {
                    uStack_4678._2_2_ = (short)((uint)uStack_4678 >> 0x10);
                    if (uStack_4678._2_2_ != 0) {
                      uVar21 = (ulonglong)
                               *(ushort *)(auStack_3fe8 + (longlong)uStack_4678._2_2_ * 2 + 1);
                    }
                    psStack_4078 = (short *)(auStack_3fe8 + uVar21);
                    puStack_4070 = auStack_3fe8 + uVar21 + 2;
                    sStack_4068 = (*(short *)(auStack_3fe8 + uVar21) + 1) * 2;
                  }
                  uStack_4678 = uVar6;
                  if (auStack_40c0._8_8_ != 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100bdf;
                    func_0x(auStack_40c0._8_8_,auStack_40c0);
                  }
LAB_:
                  pbStack_40f0 = abStack_4048 + uStack_204a;
                  if ((*pbStack_40f0 & 1) == 0) {
                    uStack_40f8 = 0;
                    uStack_40f4 = 0;
                    uStack_40d2 = 0;
                    uStack_40d0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100ddc */
                    /* WARNING: Treating indirect jump as call */
                    (*(code *)((ulonglong)
                               *(uint *)((longlong)(int)(*pbStack_40f0 & 0xe) * 4 + 0x101de4) -
                              0x1bb0510))();
                    return;
                  }
                  uStack_40f8 = 1;
                  UNRECOVERED_JUMPTABLE_00 =
                       (code *)((ulonglong)
                                *(uint *)((ulonglong)
                                          *(byte *)((longlong)(int)(*pbStack_40f0 & 0x1c) + 0x101dc4
                                                   ) * 4 + 0x101db4) - 0x1bb0510);
                    /* WARNING: Could not emulate address calculation at 0x00100c2a */
                    /* WARNING: Treating indirect jump as call */
                  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
                  return;
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101ad1;
                func_0x(0xcef890);
              }
            }
            else {
              uVar21 = (ulonglong)(iVar10 + 8);
            }
            uVar20 = (uint)uVar21;
            if (*(int *)(lVar13 + 0x198) + 1U < uVar20) {
              uStack_4638 = 0;
              auStack_4630[0] = 0x4000e1;
              uStack_4628 = 0;
              uStack_4618 = 0;
              uStack_4620 = 0;
              uStack_4610 = 0;
              (&stack0xffffffffffffffe8)[lVar11] = 1;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1019d3;
              lStack_4640 = param_1;
              iVar9 = (*_DAT_)(param_1 + 0x1598,0xffffffff,auStack_4630,0);
              if (iVar9 != 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101d46;
                func_0x(param_1);
                UNRECOVERED_JUMPTABLE_00 = (code *)swi(3);
                (*UNRECOVERED_JUMPTABLE_00)();
                return;
              }
              uStack_4638 = 1;
              uVar26 = *(int *)(lVar13 + 0x198) + 1;
              if (uVar26 < uVar20) {
                if ((_DAT_ & 0x2000000) != 0) {
                  uStack_4370 = 0x30000;
                  uStack_4368 = 0;
                  ppuStack_4360 = &puStack_4348;
                  puStack_4358 = auStack_4318;
                  uStack_4128 = 0;
                  uStack_4350 = 0;
                  uStack_4120 = 0;
                  puStack_4348 = auStack_4118;
                  uStack_4340 = 0x12;
                  uStack_433c = 2;
                  uStack_432c = 2;
                  uStack_4328 = 0;
                  uStack_4320 = 0;
                  uStack_431c = 3;
                  auStack_4118[0] = 0x101;
                  lStack_4338 = *(longlong *)(param_1 + 0xb0);
                  iStack_4330 = 0;
                  if (lStack_4338 != 0) {
                    lVar14 = -1;
                    do {
                      lVar14 = lVar14 + 1;
                    } while (*(short *)(lStack_4338 + lVar14 * 2) != 0);
                    iStack_4330 = (int)lVar14 * 2;
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101af9;
                  func_0x(asStack_1048,0,0x1000);
                  *(uint *)(&stack0xffffffffffffffe8 + lVar11) = uVar20;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101b19;
                  func_0x(asStack_1048,0x800,0xcef7b0);
                  ppuVar7 = ppuStack_4360;
                  lVar14 = -1;
                  do {
                    lVar14 = lVar14 + 1;
                  } while (asStack_1048[lVar14] != 0);
                  ppuStack_4360[4] = asStack_1048;
                  *(int *)(ppuVar7 + 5) = (int)lVar14 * 2;
                  *(undefined4 *)((longlong)ppuVar7 + 0x2c) = 3;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101b64;
                  func_0x(auStack_4378);
                }
                if ((DAT_ & 0x40) == 0) {
                  lVar14 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                            );
                  if ((lVar14 != 0) && (**(longlong **)(lVar14 + 0x38) != 0)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101bab;
                    iVar9 = (*_DAT_)();
                    if (iVar9 != 0) goto code_r0x00101bb2;
                  }
                }
                else {
code_r0x00101bb2:
                  uVar16 = *(undefined8 *)(param_1 + 0xb0);
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101bcb;
                  func_0x(0xcef430,uVar16,uVar26);
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101bd3;
                iVar9 = func_0x(param_1);
                if (iVar9 == 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101be3;
                  lVar14 = func_0x(lVar13);
                  if (lVar14 == 0) {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101c0a;
                    (*_DAT_)(1,0xdc6a88,0xd760c0);
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101c12;
                  lVar14 = func_0x(lVar13);
                  if ((*(uint *)(lVar14 + 0x1fc) >> 2 & 1) == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101c2f;
                    plVar15 = (longlong *)func_0x(lVar13);
                    UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar15 + 0x60);
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101c42;
                    (*UNRECOVERED_JUMPTABLE_00)(plVar15,uVar21,1);
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101c4a;
                    uVar16 = func_0x(lVar13);
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101c55;
                    func_0x(uVar16,uVar21);
                    if (((_DAT_ != 0) && (DAT_ != '\0')) &&
                       ((DAT_ & 2) == 0)) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101c78;
                      plVar15 = (longlong *)func_0x(lVar13);
                      UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar15 + 0x170);
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101c84;
                      iVar9 = (*UNRECOVERED_JUMPTABLE_00)(plVar15);
                      if (iVar9 == 0) goto LAB_;
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101c93;
                    plVar15 = (longlong *)func_0x(lVar13);
                    UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar15 + 0x20);
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101ca8;
                    (*UNRECOVERED_JUMPTABLE_00)(plVar15,0,uVar26);
                  }
                }
LAB_:
                *(int *)(lVar13 + 0x198) = *(int *)(lVar13 + 0x198) + (uVar20 - uVar26);
                *(ulonglong *)(lVar13 + 0x90) = uVar21;
              }
              uStack_4638 = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101ccf;
              func_0x(param_1 + 0x1598);
            }
            iVar9 = *(int *)(&stack0x00000028 + lVar11);
          }
          uVar20 = *(uint *)((longlong)&uStackX_8 + lVar11);
        }
        uVar26 = iVar9 + 1;
        uVar19 = (ulonglong)uVar26;
        *(uint *)(&stack0x00000028 + lVar11) = uVar26;
        param_2 = param_2 + 0x1000;
        *(undefined (**) [16])(&stack0x00000030 + lVar11) = param_2;
      } while (uVar26 < uVar20);
    }
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101d05;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar11));
  return;
}

