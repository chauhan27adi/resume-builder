
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 *
FUN_(undefined4 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
            undefined8 param_5,undefined8 param_6,uint param_7,uint param_8,undefined8 param_9,
            undefined8 param_10,undefined8 param_11,undefined8 param_12)

{
  longlong **pplVar1;
  int iVar2;
  undefined8 uVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  undefined *puVar7;
  longlong lVar8;
  undefined8 *puVar9;
  ulonglong uVar10;
  uint uVar11;
  undefined8 *puVar12;
  
  *param_1 = 1;
  param_1[1] = param_8;
  puVar12 = (undefined8 *)0x0;
  *(undefined8 *)(param_1 + 2) = 0;
  *(undefined8 *)(param_1 + 4) = 0;
  *(undefined8 *)(param_1 + 6) = 0;
  *(undefined8 *)(param_1 + 8) = 0;
  *(undefined8 *)(param_1 + 10) = param_2;
  *(undefined8 *)(param_1 + 0xc) = 0;
  *(undefined8 *)(param_1 + 0xe) = param_3;
  *(undefined8 *)(param_1 + 0x10) = param_4;
  *(undefined8 *)(param_1 + 0x12) = param_5;
  *(undefined8 *)(param_1 + 0x14) = param_10;
  *(undefined8 *)(param_1 + 0x16) = param_11;
  *(undefined8 *)(param_1 + 0x18) = param_12;
  *(undefined8 *)(param_1 + 0x1a) = param_6;
  *(undefined8 *)(param_1 + 0x1c) = 0;
  pplVar1 = (longlong **)(param_1 + 0x1e);
  *pplVar1 = (longlong *)0x0;
  *(undefined8 *)(param_1 + 0x20) = 0;
  *(undefined8 *)(param_1 + 0x22) = param_9;
  uVar3 = SUB168(ZEXT816(4) * ZEXT416(param_8),0);
  if (SUB168(ZEXT816(4) * ZEXT416(param_8),8) != 0) {
    uVar3 = 0xffffffffffffffff;
  }
  plVar4 = (longlong *)(*_DAT_)(uVar3,param_2,0x1f88988,0x193,1);
  *pplVar1 = plVar4;
  if (param_8 != 0) {
    puVar6 = puVar12;
    if ((3 < param_8) &&
       ((pplVar1 < plVar4 ||
        (puVar6 = (undefined8 *)0x0,
        (longlong *)((longlong)plVar4 + (ulonglong)(param_8 - 1) * 4) < pplVar1)))) {
      puVar6 = puVar12;
      do {
        uVar11 = (int)puVar6 + 4;
        puVar6 = (undefined8 *)(ulonglong)uVar11;
      } while (uVar11 < (param_8 & 0xfffffffc));
      func_0x(plVar4,0xffffffff,(ulonglong)((param_8 & 0xfffffffc) + 3 >> 2) << 4);
      if (param_8 <= uVar11) goto LAB_;
    }
    lVar8 = (longlong)puVar6 * 4;
    uVar10 = (ulonglong)(param_8 - (int)puVar6);
    do {
      *(undefined4 *)(lVar8 + (longlong)*pplVar1) = 0xffffffff;
      lVar8 = lVar8 + 4;
      uVar10 = uVar10 - 1;
    } while (uVar10 != 0);
  }
LAB_:
  uVar3 = (*_DAT_)((longlong)(int)(param_8 * 0x1f94),*(undefined8 *)(param_1 + 10),0x1f88988
                           ,0x19f,1);
  puVar5 = (undefined8 *)(*_DAT_)(0x20,*(undefined8 *)(param_1 + 10),0x1f88988,0x1a0,1);
  puVar6 = puVar12;
  if (puVar5 != (undefined8 *)0x0) {
    *puVar5 = 0x1f889d0;
    *(uint *)(puVar5 + 1) = param_8 * 0x1f94;
    *(undefined4 *)((longlong)puVar5 + 0xc) = 0;
    puVar5[2] = uVar3;
    puVar5[3] = 0;
    puVar6 = puVar5;
  }
  *(undefined8 **)(param_1 + 0x20) = puVar6;
  if (param_7 == 0) {
    *(undefined8 *)(param_1 + 0x1c) = 0;
  }
  else {
    uVar3 = SUB168(ZEXT816(8) * ZEXT416(param_7),0);
    if (SUB168(ZEXT816(8) * ZEXT416(param_7),8) != 0) {
      uVar3 = 0xffffffffffffffff;
    }
    uVar3 = (*_DAT_)(uVar3,*(undefined8 *)(param_1 + 10),0x1f88988,0x1a2,1);
    *(undefined8 *)(param_1 + 0x1c) = uVar3;
    puVar6 = puVar12;
    puVar5 = puVar12;
    if (param_7 != 0) {
      do {
        plVar4 = *(longlong **)((longlong)puVar5 + *(longlong *)(param_1 + 0x1a));
        puVar7 = (undefined *)(**(code **)*plVar4)(plVar4);
        switch(*puVar7) {
        case 0x22:
        case 0x23:
        case 0x62:
        case 99:
        case 0xa5:
        case 0xa7:
        case 0xad:
        case 0xaf:
        case 0xe7:
        case 0xef:
        case 0xf0:
        case 0xf1:
          puVar9 = (undefined8 *)0x19827f0;
          break;
        case 0x24:
          puVar9 = (undefined8 *)0x1982690;
          break;
        default:
          (*_DAT_)(1,0x2134818,0x2133f80,0x10b,0x21944c8);
          puVar9 = puVar12;
          break;
        case 0x28:
          puVar9 = (undefined8 *)0x1982620;
          break;
        case 0x29:
          puVar9 = (undefined8 *)0x19825d0;
          break;
        case 0x2a:
          puVar9 = (undefined8 *)0x1982580;
          break;
        case 0x2b:
          puVar9 = (undefined8 *)0x1982540;
          break;
        case 0x30:
        case 0x68:
          puVar9 = (undefined8 *)0x1982a40;
          break;
        case 0x34:
          puVar9 = (undefined8 *)0x1982a10;
          break;
        case 0x38:
          puVar9 = (undefined8 *)0x19829d0;
          break;
        case 0x3a:
          puVar9 = (undefined8 *)0x19829a0;
          break;
        case 0x3b:
          puVar9 = (undefined8 *)0x1982910;
          break;
        case 0x3c:
          puVar9 = (undefined8 *)0x1982740;
          break;
        case 0x3d:
          puVar9 = (undefined8 *)0x1982740;
          break;
        case 0x3e:
          puVar9 = (undefined8 *)0x19828d0;
          break;
        case 0x6a:
        case 0x6c:
          puVar9 = (undefined8 *)0x1982960;
          break;
        case 0x7a:
          puVar9 = (undefined8 *)0x19829d0;
          break;
        case 0x7f:
          puVar9 = (undefined8 *)0x1982740;
          break;
        case 0xbd:
          puVar9 = (undefined8 *)0x1982740;
        }
        *(undefined8 **)((longlong)puVar5 + *(longlong *)(param_1 + 0x1c)) = puVar9;
        iVar2 = (**(code **)(*plVar4 + 200))(plVar4);
        *(int *)((ulonglong)(iVar2 - 1) * 4 + (longlong)*pplVar1) = (int)puVar6;
        uVar11 = (int)puVar6 + 1;
        puVar6 = (undefined8 *)(ulonglong)uVar11;
        puVar5 = puVar5 + 1;
      } while (uVar11 < param_7);
    }
  }
  return param_1;
}

