
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,undefined8 param_3)

{
  char cVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  code *pcVar4;
  undefined8 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  char cVar14;
  char cVar15;
  byte bVar16;
  ushort uVar17;
  ushort uVar18;
  short sVar19;
  int iVar20;
  longlong *plVar21;
  longlong lVar22;
  undefined8 uVar23;
  ulonglong uVar24;
  undefined4 *puVar25;
  uint uVar26;
  undefined8 *puVar27;
  longlong lVar28;
  undefined4 *puVar29;
  short sVar30;
  uint uVar31;
  uint uVar32;
  undefined4 *puVar33;
  undefined2 *puVar34;
  int iVar35;
  uint uVar36;
  ulonglong uVar37;
  longlong *plVar38;
  byte *pbVar39;
  ushort *puVar40;
  short *psVar41;
  undefined auStack_728 [64];
  undefined auStack_6e8 [16];
  undefined auStack_6d8 [8];
  undefined8 uStack_6d0;
  undefined8 uStack_6c8;
  undefined6 uStack_6c0;
  undefined2 uStack_6ba;
  undefined6 uStack_6b8;
  undefined2 uStack_6b2;
  undefined8 uStack_6b0;
  undefined auStack_6a8 [16];
  undefined auStack_698 [16];
  undefined auStack_688 [16];
  undefined8 uStack_678;
  undefined auStack_668 [8];
  undefined8 uStack_660;
  undefined2 auStack_658 [2];
  undefined4 uStack_654;
  undefined8 uStack_650;
  undefined8 uStack_648;
  undefined8 uStack_63a;
  undefined8 uStack_630;
  char cStack_618;
  char cStack_617;
  int iStack_614;
  uint uStack_610;
  undefined8 *puStack_608;
  ushort *puStack_600;
  undefined8 uStack_5f8;
  uint uStack_5f0;
  longlong lStack_5e8;
  longlong lStack_5e0;
  longlong *plStack_5d8;
  undefined4 uStack_5d0;
  undefined4 uStack_5cc;
  undefined *puStack_5c8;
  undefined8 uStack_5c0;
  undefined4 uStack_5b8;
  undefined2 uStack_5b4;
  undefined8 uStack_5b2;
  undefined2 uStack_5aa;
  undefined2 uStack_5a8;
  undefined6 uStack_5a6;
  undefined4 uStack_5a0;
  undefined4 *puStack_598;
  longlong *plStack_590;
  undefined4 *puStack_588;
  undefined2 *puStack_580;
  undefined *puStack_578;
  undefined4 uStack_570;
  undefined *puStack_568;
  undefined4 auStack_558 [64];
  undefined4 auStack_458 [64];
  undefined4 auStack_358 [64];
  undefined4 auStack_258 [64];
  undefined4 auStack_158 [64];
  undefined uStack_58;
  ushort *puStack_57;
  ulonglong uStack_48;
  
  puVar34 = auStack_658;
  uStack_48 = _DAT_ ^ (ulonglong)&cStack_618;
  uStack_5b2 = 0;
  uStack_5a8 = 0;
  uStack_5a6 = 0;
  uStack_5c0 = 0;
  iVar35 = *(int *)(*(longlong *)(**(longlong **)(param_1 + 0x28) + 8) + 0x100);
  puStack_580 = (undefined2 *)0x0;
  plVar38 = (longlong *)(*(longlong **)(param_1 + 0x28))[1];
  uStack_660 = 0x100075;
  uStack_5f8 = param_3;
  lStack_5e0 = param_1;
  cVar14 = (**(code **)(*plVar38 + 0x88))(plVar38);
  cStack_618 = cVar14 == '\0';
  uStack_660 = 0x100083;
  cVar14 = (**(code **)*plVar38)(plVar38);
  uStack_610 = (uint)(cVar14 == '\0');
  uStack_660 = 0x100096;
  cStack_617 = (**(code **)(*plVar38 + 8))(plVar38);
  lVar28 = param_1 + 0x30;
  uStack_660 = 0x1000a9;
  lStack_5e8 = lVar28;
  func_0x(lVar28);
  plVar38 = (longlong *)(param_1 + 0x2b0);
  uStack_660 = 0x1000bc;
  plStack_5d8 = plVar38;
  func_0x(plVar38);
  *(byte *)(param_1 + 0x531) = *(byte *)(param_1 + 0x531) & 0xfd;
  puVar33 = (undefined4 *)(param_1 + 0x530);
  *(byte *)puVar33 = *(byte *)puVar33 & 0xf9 | 1;
  puStack_598 = puVar33;
  if (*(longlong **)(param_2 + 0x28) == (longlong *)0x0) {
    if (*(int *)(param_2 + 0xc0) != 2) {
      uStack_660 = 0x100109;
      func_0x(param_2);
      if (*(int *)(param_2 + 0xc0) != 2) {
        lVar22 = **(longlong **)(param_2 + 0x28);
        goto LAB_;
      }
    }
    lVar22 = 0;
  }
  else {
    lVar22 = **(longlong **)(param_2 + 0x28);
  }
LAB_:
  puStack_600 = (ushort *)CONCAT26(*(undefined2 *)(param_2 + 0x20),*(undefined6 *)(lVar22 + 0x20));
  uStack_660 = 0x100141;
  func_0x(param_2);
  if ((iVar35 == 0) || (iVar35 - 3U < 2)) {
    uStack_5aa = 0;
    uStack_5a8 = 0;
    uStack_5b4 = 0;
    uStack_5d0 = 0;
    puStack_5c8 = &uStack_58;
    uStack_58 = 4;
    uStack_5c0 = 0x900000009;
    uStack_5cc = 9;
    uStack_5b8 = 9;
    uStack_660 = 0x1001dd;
    func_0x(&puStack_57,8,&puStack_600);
  }
  else {
    puStack_5c8 = &uStack_58;
    uStack_5b4 = 0;
    uStack_5aa = 0;
    puStack_57 = puStack_600;
    uStack_5d0 = 1;
    uStack_5b8 = 0;
    uStack_58 = 9;
    uStack_5cc = 9;
    uStack_5a0 = 0;
  }
  puStack_588 = &uStack_5d0;
  if (*(longlong *)(param_1 + 0x58) == 0) {
    uStack_660 = 0x1001f9;
    func_0x(lVar28);
  }
  if (*(int *)(param_1 + 0x270) == 0) {
    uStack_660 = 0x100212;
    func_0x(lVar28);
  }
  iVar35 = *(int *)(param_1 + 0x268);
  iStack_614 = iVar35;
  if (*(longlong **)(param_1 + 0x58) == (longlong *)0x0) {
    if (*(int *)(param_1 + 0xf0) != 2) {
      uStack_660 = 0x100246;
      func_0x(lVar28);
      if (*(int *)(param_1 + 0xf0) != 2) {
        lVar22 = **(longlong **)(param_1 + 0x58);
        goto LAB_;
      }
    }
    lVar22 = 0;
  }
  else {
    lVar22 = **(longlong **)(param_1 + 0x58);
  }
LAB_:
  if (*(char *)(lVar22 + 2) < '\0') {
    auStack_658[0] = 0xffff;
    uStack_650 = 0;
    uStack_654 = 0;
    uStack_63a = 0;
    uStack_630 = 0;
    uStack_648 = 0;
    puStack_578 = auStack_668;
    puVar34 = (undefined2 *)auStack_728;
    puStack_568 = auStack_6e8;
    auStack_6e8 = ZEXT816(0);
    uStack_6c0 = 0;
    uStack_6b2 = 0;
    auStack_698 = ZEXT816(0);
    stack0xfffffffffffff92a = SUB1614(ZEXT816(0),2);
    auStack_6d8._0_2_ = 0xffff;
    uStack_6d0 = 0;
    uStack_6ba = 0;
    uStack_6b8 = 0;
    uStack_6b0 = 0;
    uStack_6c8 = 0;
    auStack_6a8 = ZEXT816(0);
    auStack_688._0_12_ = ZEXT812(0);
    auStack_688._12_4_ = 0;
    uStack_678 = 0;
    uStack_570 = 9;
    puStack_580 = auStack_658;
    func_0x(&puStack_588);
  }
  uVar23 = uStack_5f8;
  if ((cStack_618 == '\0') || (iVar35 != 3)) goto LAB_;
  *(undefined8 *)((longlong)puVar34 + -8) = 0x10034d;
  func_0x(lVar28);
  plVar21 = *(longlong **)(*(longlong *)(param_1 + 0x28) + 8);
  plStack_590 = plVar21 + 5;
  pcVar4 = *(code **)(*plVar21 + 0x58);
  *(undefined8 *)((longlong)puVar34 + -8) = 0x100366;
  cVar14 = (*pcVar4)();
  uStack_5f0 = -(uint)(cVar14 != '\0') & 0x80;
  if (*(undefined8 **)(param_1 + 0x2d8) == (undefined8 *)0x0) {
    puVar27 = (undefined8 *)0x0;
    puStack_608 = puVar27;
    if (*(int *)(param_1 + 0x370) != 2) {
      *(undefined8 *)((longlong)puVar34 + -8) = 0x1003a9;
      func_0x(plVar38);
      puStack_608 = (undefined8 *)0x0;
      puVar27 = *(undefined8 **)(param_1 + 0x2d8);
      if (*(int *)(param_1 + 0x370) != 2) {
        puStack_608 = (undefined8 *)*puVar27;
      }
    }
    cVar14 = *(char *)(param_1 + 0x4f8);
    if (puVar27 == (undefined8 *)0x0) {
      *(undefined8 *)((longlong)puVar34 + -8) = 0x1003db;
      func_0x(plVar38);
    }
  }
  else {
    puStack_608 = (undefined8 *)**(undefined8 **)(param_1 + 0x2d8);
    cVar14 = *(char *)(param_1 + 0x4f8);
  }
  if (*(int *)(param_1 + 0x4f0) == 0) {
    *(undefined8 *)((longlong)puVar34 + -8) = 0x1003ef;
    func_0x(plVar38);
  }
  if (_DAT_ != 0) {
    plVar21 = *(longlong **)(param_1 + 0x380);
    puVar27 = *(undefined8 **)(*(longlong *)(param_1 + 0x2b8) + 8);
    iVar35 = *(int *)(plVar21 + 2);
    cVar1 = *(char *)(puVar27[6] + 0x1cde);
    pcVar4 = *(code **)*puVar27;
    *(undefined8 *)((longlong)puVar34 + -8) = 0x100429;
    cVar15 = (*pcVar4)(puVar27);
    if (cVar15 == '\0') {
      if (cVar1 == '\0') {
        if (iVar35 << 0x1f < 0) {
          if ((*(byte *)(plVar21 + 2) & 0x40) == 0) goto LAB_;
          lVar28 = puVar27[0x1a];
          if (((lVar28 != 0) && (*(char *)(lVar28 + 0x34) != '\0')) &&
             (*(longlong *)(lVar28 + 0x40) != 0)) {
            LOCK();
            lVar22 = *(longlong *)(lVar28 + 0x128);
            if (lVar22 == 0) {
              *(longlong *)(lVar28 + 0x128) = 0;
              lVar22 = 0;
            }
            UNLOCK();
            if (*(longlong *)(*plVar21 + 0x28) != lVar22) goto LAB_;
          }
        }
      }
      else {
LAB_:
        lVar28 = *(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x2b8) + 8) + 0x30);
        if (*(int *)(param_1 + 0x4f4) == 0) {
          if (*(int *)(*(longlong *)(lVar28 + 0x6b0) + 0x5ec) == 1) {
            lVar28 = lVar28 + 0x18;
            goto LAB_;
          }
        }
        else if (*(int *)(*(longlong *)(lVar28 + 0x6b0) + 0x5ec) == 1) {
          lVar28 = lVar28 + 0x28;
LAB_:
          *(undefined8 *)((longlong)puVar34 + -8) = 0x1004a9;
          plVar21 = (longlong *)func_0x(lVar28);
          *plVar21 = *plVar21 + 1;
        }
      }
    }
  }
  psVar41 = (short *)(param_1 + 0x438);
  if (cVar14 == '\0') {
    psVar41 = (short *)(param_1 + 0x388);
  }
  if (*psVar41 == 0) {
    uVar26 = *(uint *)(psVar41 + 2);
    if (uVar26 == 0) {
      pbVar39 = *(byte **)(psVar41 + 4);
      iVar35 = 0;
      uVar31 = *(uint *)(psVar41 + 8);
      uVar24 = (ulonglong)uVar31;
      psVar41[1] = 0;
      *(uint *)(psVar41 + 10) = uVar31;
      bVar16 = *pbVar39;
      if ((bVar16 & 0x10) != 0) {
        uVar31 = uVar31 + 2 + (*(ushort *)(pbVar39 + uVar24) + 7 >> 3);
        uVar24 = (ulonglong)uVar31;
        *(uint *)(psVar41 + 10) = uVar31;
        bVar16 = *pbVar39;
      }
      if ((bVar16 & 0x20) == 0) {
        *(int *)(psVar41 + 2) = (int)uVar24;
        psVar41[0xe] = 0;
        *(int *)(psVar41 + 0xc) = (int)uVar24;
      }
      else {
        puVar40 = (ushort *)(pbVar39 + uVar24);
        uVar17 = *puVar40;
        psVar41[0xe] = uVar17;
        puStack_600 = puVar40;
        if (uVar17 == 0) {
          *(undefined8 *)((longlong)puVar34 + -8) = 0x10053b;
          cVar14 = func_0x(0x1fbcc80);
          if (cVar14 != '\0') {
            *(undefined8 *)((longlong)puVar34 + -8) = 0x100544;
            lVar28 = func_0x();
            if ((lVar28 != 0) && (*(char *)(lVar28 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)puVar34 + -8) = 0x10055e;
              cVar14 = func_0x(0x1fbcc80);
              if (cVar14 == '\0') {
                *(undefined8 *)((longlong)puVar34 + -8) = 0x10057a;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)((longlong)puVar34 + 0x20) = 0;
                *(undefined8 *)((longlong)puVar34 + -8) = 0x1005a0;
                (*_DAT_)(1,0x18ac68c,0x19cc778,0x80f);
              }
            }
          }
          uVar23 = *(undefined8 *)(psVar41 + 4);
          *(undefined8 *)((longlong)puVar34 + -8) = 0x1005ae;
          func_0x(uVar23,3);
          uVar17 = psVar41[0xe];
          uVar24 = (ulonglong)*(uint *)(psVar41 + 10);
        }
        uVar26 = (uint)uVar17;
        uVar31 = (int)uVar24 + (uVar26 + 1) * 2;
        *(uint *)(psVar41 + 0xc) = uVar31;
        if (0x1f9e < uVar31) {
          *(undefined8 *)((longlong)puVar34 + -8) = 0x1005df;
          cVar14 = func_0x(0x1fbcc80);
          if (cVar14 != '\0') {
            *(undefined8 *)((longlong)puVar34 + -8) = 0x1005e8;
            lVar28 = func_0x();
            if ((lVar28 != 0) && (*(char *)(lVar28 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)puVar34 + -8) = 0x100602;
              cVar14 = func_0x(0x1fbcc80);
              if (cVar14 == '\0') {
                *(undefined8 *)((longlong)puVar34 + -8) = 0x10061e;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)((longlong)puVar34 + 0x20) = 0;
                *(undefined8 *)((longlong)puVar34 + -8) = 0x100644;
                (*_DAT_)(1,0x18ac68c,0x19cc778,0x816);
              }
            }
          }
          uVar23 = *(undefined8 *)(psVar41 + 4);
          *(undefined8 *)((longlong)puVar34 + -8) = 0x100652;
          func_0x(uVar23,4);
          uVar26 = (uint)(ushort)psVar41[0xe];
          uVar31 = *(uint *)(psVar41 + 0xc);
        }
        uVar32 = puVar40[uVar26] & 0x7fff;
        *(uint *)(psVar41 + 2) = uVar32;
        if (uVar32 < uVar31) {
          *(undefined8 *)((longlong)puVar34 + -8) = 0x100682;
          cVar14 = func_0x(0x1fbcc80);
          if (cVar14 != '\0') {
            *(undefined8 *)((longlong)puVar34 + -8) = 0x10068b;
            lVar28 = func_0x();
            if ((lVar28 != 0) && (*(char *)(lVar28 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)puVar34 + -8) = 0x1006a5;
              cVar14 = func_0x(0x1fbcc80);
              if (cVar14 == '\0') {
                *(undefined8 *)((longlong)puVar34 + -8) = 0x1006c1;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)((longlong)puVar34 + 0x20) = 0;
                *(undefined8 *)((longlong)puVar34 + -8) = 0x1006e7;
                (*_DAT_)(1,0x18ac68c,0x19cc778,0x81d);
              }
            }
          }
          uVar23 = *(undefined8 *)(psVar41 + 4);
          *(undefined8 *)((longlong)puVar34 + -8) = 0x1006f5;
          func_0x(uVar23,4);
          uVar31 = *(uint *)(psVar41 + 0xc);
          uVar26 = (uint)(ushort)psVar41[0xe];
          uVar32 = *(uint *)(psVar41 + 2);
        }
        if ((short)uVar26 != 0) {
          do {
            puVar40 = puVar40 + 1;
            uVar32 = *puVar40 & 0x7fff;
            if ((uVar32 < uVar31) || (*(uint *)(psVar41 + 2) < uVar32)) {
              *(undefined8 *)((longlong)puVar34 + -8) = 0x100741;
              cVar14 = func_0x(0x1fbcc80);
              if (cVar14 != '\0') {
                *(undefined8 *)((longlong)puVar34 + -8) = 0x10074a;
                lVar28 = func_0x();
                if ((lVar28 != 0) && (*(char *)(lVar28 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)puVar34 + -8) = 0x100764;
                  cVar14 = func_0x(0x1fbcc80);
                  if (cVar14 == '\0') {
                    *(undefined8 *)((longlong)puVar34 + -8) = 0x100780;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)((longlong)puVar34 + 0x20) = 0;
                    *(undefined8 *)((longlong)puVar34 + -8) = 0x1007a4;
                    (*_DAT_)(1,0x18ac68c,0x19cc778,0x82a);
                  }
                }
              }
              uVar23 = *(undefined8 *)(psVar41 + 4);
              *(undefined8 *)((longlong)puVar34 + -8) = 0x1007b2;
              func_0x(uVar23,4);
            }
            uVar26 = (uint)(ushort)psVar41[0xe];
            iVar35 = iVar35 + 1;
            uVar31 = uVar32;
          } while (iVar35 < (int)uVar26);
          uVar32 = *(uint *)(psVar41 + 2);
          plVar38 = plStack_5d8;
          puVar40 = puStack_600;
        }
        uVar24 = (ulonglong)uVar32;
        if ((short)puVar40[(ulonglong)(uVar26 - 1) + 1] < 0) {
          do {
            lVar28 = *(longlong *)(psVar41 + 4);
            lVar22 = (ulonglong)*(uint *)(psVar41 + 10) + lVar28;
            uVar31 = *(ushort *)(lVar22 + (ulonglong)uVar26 * 2) & 0x7fff;
            if (uVar26 == 1) {
              uVar32 = *(uint *)(psVar41 + 0xc);
              uVar37 = (ulonglong)uVar32;
LAB_:
              if ((uVar31 < (uint)uVar37) || (uVar26 = *(uint *)(psVar41 + 2), uVar26 < uVar31))
              goto LAB_;
            }
            else {
              uVar32 = *(uint *)(psVar41 + 0xc);
              uVar26 = *(ushort *)(lVar22 + -2 + (ulonglong)uVar26 * 2) & 0x7fff;
              uVar37 = (ulonglong)uVar26;
              if (uVar32 <= uVar26) goto LAB_;
LAB_:
              *(undefined8 *)((longlong)puVar34 + -8) = 0x100845;
              func_0x(lVar28,7);
              uVar32 = *(uint *)(psVar41 + 0xc);
              uVar26 = *(uint *)(psVar41 + 2);
            }
            uVar24 = (ulonglong)uVar26;
            uVar36 = (uint)uVar37;
            if ((uVar36 < uVar32) || (uVar26 < uVar36)) goto LAB_;
            if (*(ushort *)(uVar37 + *(longlong *)(psVar41 + 4)) == 5) {
              psVar41[1] = psVar41[1] | 2;
              psVar41[0xe] = psVar41[0xe] + -1;
              uVar24 = uVar37 & 0xffff;
              psVar41[0x15] = (short)uVar37;
              lVar28 = *(longlong *)(psVar41 + 4);
              uVar17 = psVar41[0x16] & 0xc7ffU;
              if ((*(ushort *)(lVar28 + 2 + uVar24) >> 0xe & 1) != 0) {
                uVar17 = *(ushort *)(lVar28 + 2 + uVar24) & 0x3800 | psVar41[0x16] & 0xc7ffU;
              }
              psVar41[0x16] = uVar17;
              uVar18 = (uVar17 ^ *(ushort *)(lVar28 + 2 + uVar24)) & 0x7ff ^ uVar17;
              psVar41[0x16] = uVar18;
              uVar37 = (ulonglong)((uVar18 & 0x7ff) * 2) + 4 +
                       (ulonglong)((uVar17 >> 0xb & 7) * 2) + lVar28 + uVar24;
              if (uVar37 < lVar28 + uVar24) {
                *(undefined8 *)((longlong)puVar34 + -8) = 0x100959;
                func_0x(lVar28 + uVar24,0x19);
                uVar18 = psVar41[0x16];
                uVar24 = (ulonglong)(ushort)psVar41[0x15];
              }
              if (uVar31 - uVar36 <
                  (((uVar18 & 0x7ff) * 2 - (int)uVar24) - *(int *)(psVar41 + 4)) + (int)uVar37) {
                lVar28 = *(longlong *)(psVar41 + 4);
                *(undefined8 *)((longlong)puVar34 + -8) = 0x10098f;
                func_0x(uVar24 + lVar28,0x19);
                uVar18 = psVar41[0x16];
              }
              if ((uVar18 & 0x3800) != 0) {
                puVar40 = (ushort *)
                          (*(longlong *)(psVar41 + 4) + (ulonglong)(ushort)psVar41[0x15] + 4);
                iVar35 = 0;
                if ((uVar18 & 0x3800) != 0) {
                  do {
                    if ((uVar18 & 0x7ff) < (*puVar40 & 0x7ff)) {
                      uVar17 = psVar41[0x15];
                      lVar28 = *(longlong *)(psVar41 + 4);
                      *(undefined8 *)((longlong)puVar34 + -8) = 0x1009e8;
                      func_0x((ulonglong)uVar17 + lVar28,0x1a);
                      uVar18 = psVar41[0x16];
                    }
                    iVar35 = iVar35 + 1;
                    puVar40 = puVar40 + 1;
                  } while (iVar35 < (int)(uVar18 >> 0xb & 7));
                }
              }
              uVar24 = (ulonglong)*(uint *)(psVar41 + 2);
              goto LAB_;
            }
            if (*(ushort *)(uVar37 + *(longlong *)(psVar41 + 4)) < 0x400) goto LAB_;
            psVar41[1] = psVar41[1] | 1;
            uVar17 = psVar41[0xe] - 1;
            psVar41[0xe] = uVar17;
            if (uVar17 == 0) goto LAB_;
            uVar26 = (uint)uVar17;
          } while ((short)puVar40[(ulonglong)(uVar17 - 1) + 1] < 0);
          pbVar39 = *(byte **)(psVar41 + 4);
        }
        else {
LAB_:
          pbVar39 = *(byte **)(psVar41 + 4);
        }
      }
      if ((*pbVar39 & 0x40) == 0) {
        *(undefined4 *)(psVar41 + 0x13) = 0;
      }
      else {
        *(int *)(psVar41 + 0x13) = (int)uVar24;
        *(int *)(psVar41 + 2) = (int)uVar24 + 0xe;
        *(undefined8 *)((longlong)puVar34 + -8) = 0x100a39;
        uVar23 = func_0x(psVar41 + 1);
        *(undefined8 *)((longlong)puVar34 + -8) = 0x100a45;
        func_0x(uVar23,&plStack_5d8);
        *(undefined8 *)((longlong)puVar34 + -8) = 0x100a4e;
        iVar35 = func_0x(&plStack_5d8);
        *(int *)(psVar41 + 2) = *(int *)(psVar41 + 2) + iVar35;
        uVar24 = (ulonglong)*(uint *)(psVar41 + 2);
      }
      if ((*(ulonglong *)(psVar41 + 0xf) != 0) &&
         (*(ulonglong *)(psVar41 + 0xf) < uVar24 + *(longlong *)(psVar41 + 4))) {
        *(undefined8 *)((longlong)puVar34 + -8) = 0x100a86;
        cVar14 = func_0x(0x1fbcc80);
        if (cVar14 != '\0') {
          *(undefined8 *)((longlong)puVar34 + -8) = 0x100a8f;
          lVar28 = func_0x();
          if ((lVar28 != 0) && (*(char *)(lVar28 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)puVar34 + -8) = 0x100aa9;
            cVar14 = func_0x(0x1fbcc80);
            if (cVar14 == '\0') {
              *(undefined8 *)((longlong)puVar34 + -8) = 0x100ac5;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)((longlong)puVar34 + 0x20) = 0;
              *(undefined8 *)((longlong)puVar34 + -8) = 0x100aeb;
              (*_DAT_)(1,0x18ac68c,0x19cc778,0x886);
            }
          }
        }
        uVar23 = *(undefined8 *)(psVar41 + 4);
        *(undefined8 *)((longlong)puVar34 + -8) = 0x100af9;
        func_0x(uVar23,0x12);
        uVar24 = (ulonglong)*(uint *)(psVar41 + 2);
      }
      uVar26 = (uint)uVar24;
      if ((uVar26 == 0) || (0x3f3c < uVar26)) {
        *(undefined8 *)((longlong)puVar34 + -8) = 0x100b19;
        cVar14 = func_0x(0x1fbcc80);
        if (cVar14 != '\0') {
          *(undefined8 *)((longlong)puVar34 + -8) = 0x100b22;
          lVar28 = func_0x();
          if ((lVar28 != 0) && (*(char *)(lVar28 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)puVar34 + -8) = 0x100b3c;
            cVar14 = func_0x(0x1fbcc80);
            if (cVar14 == '\0') {
              *(undefined8 *)((longlong)puVar34 + -8) = 0x100b58;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)((longlong)puVar34 + 0x20) = 0;
              *(undefined8 *)((longlong)puVar34 + -8) = 0x100b7e;
              (*_DAT_)(1,0x18ac68c,0x19cc778,0x88b);
            }
          }
        }
        uVar23 = *(undefined8 *)(psVar41 + 4);
        *(undefined8 *)((longlong)puVar34 + -8) = 0x100b8c;
        func_0x(uVar23,5);
        uVar26 = *(uint *)(psVar41 + 2);
      }
    }
LAB_:
    if ((uVar26 < 9) &&
       (((**(byte **)(psVar41 + 4) & 0xe) == 0 || ((**(byte **)(psVar41 + 4) & 0xe) == 0xc)))) {
LAB_:
      uVar26 = 9;
    }
  }
  else {
    uVar31 = *(uint *)(psVar41 + 2);
    if (uVar31 == 0) {
      *(undefined8 *)((longlong)puVar34 + -8) = 0x100bc2;
      func_0x(psVar41 + 1);
      uVar31 = *(uint *)(psVar41 + 2);
    }
    if (uVar31 < 9) {
      if ((**(byte **)(psVar41 + 4) & 0x1c) == 0) goto LAB_;
      uVar26 = 9;
      if ((**(byte **)(psVar41 + 4) & 0x1c) == 0xc) goto LAB_;
    }
    uVar26 = uVar31;
  }
LAB_:
  puVar33 = puStack_598;
  uVar23 = uStack_5f8;
  sVar30 = 1 << ((byte)*(undefined2 *)((longlong)puStack_608 + 4) & 2);
  sVar19 = 0x20;
  if (*psVar41 != 0) {
    sVar19 = 0x18;
  }
  iVar35 = (uint)(ushort)(sVar19 + -1 + sVar30 & -sVar30) -
           (uint)(ushort)(sVar30 + -1 + (short)uVar26 & -sVar30);
  if (0 < iVar35) {
    if (plStack_590 == (longlong *)0x0) {
      uVar31 = (uint)*(ushort *)((longlong)puStack_608 + 0x1c);
    }
    else {
      uVar31 = (uint)*(ushort *)((longlong)puStack_608 + 0x26);
      if (((*(short *)((longlong)plStack_590 + 4) == *(short *)(puStack_608 + 7)) &&
          (*(int *)plStack_590 == *(int *)((longlong)puStack_608 + 0x34))) && (uStack_5f0 == 0)) {
        uVar31 = (uint)*(ushort *)((longlong)puStack_608 + 0x26) -
                 (uint)*(ushort *)((longlong)puStack_608 + 0x32);
      }
      if (uVar31 < *(ushort *)((longlong)puStack_608 + 0x1c)) {
        uVar31 = *(ushort *)((longlong)puStack_608 + 0x1c) - uVar31;
      }
      else {
        uVar31 = 0;
      }
    }
    if ((int)uVar31 < iVar35) {
      if ((longlong *)plVar38[5] == (longlong *)0x0) {
        if (*(int *)(plVar38 + 0x18) != 2) {
          *(undefined8 *)((longlong)puVar34 + -8) = 0x100cb7;
          func_0x(plVar38,1);
          if (*(int *)(plVar38 + 0x18) != 2) {
            lVar28 = *(longlong *)plVar38[5];
            goto LAB_;
          }
        }
        lVar28 = 0;
      }
      else {
        lVar28 = *(longlong *)plVar38[5];
      }
LAB_:
      uVar2 = *(undefined2 *)(lVar28 + 0x24);
      sVar19 = *(short *)(plVar38 + 4);
      uVar3 = *(undefined4 *)(lVar28 + 0x20);
      bVar16 = **(byte **)(psVar41 + 4) >> 1;
      if (*psVar41 == 0) {
        bVar16 = **(byte **)(psVar41 + 4) >> 6;
      }
      *(uint *)((longlong)puVar34 + 0x30) = bVar16 & 1;
      *(uint *)((longlong)puVar34 + 0x28) = uVar26;
      *(int *)((longlong)puVar34 + 0x20) = iVar35;
      *(undefined8 *)((longlong)puVar34 + -8) = 0x100d11;
      func_0x(0x18b53e0,uVar2,uVar3,(int)sVar19);
      *(undefined8 *)((longlong)puVar34 + -8) = 0x100d19;
      func_0x(plVar38);
      puVar33 = puStack_598;
      param_1 = lStack_5e0;
      uVar23 = uStack_5f8;
      lVar28 = lStack_5e8;
      iVar35 = iStack_614;
      goto LAB_;
    }
  }
  lVar28 = 2;
  *(byte *)puStack_598 = *(byte *)puStack_598 & 0xfe;
  puVar25 = puStack_598;
  puVar29 = auStack_558;
  do {
    uVar3 = puVar25[1];
    uVar6 = puVar25[2];
    uVar7 = puVar25[3];
    uVar8 = puVar25[4];
    uVar9 = puVar25[5];
    uVar10 = puVar25[6];
    uVar11 = puVar25[7];
    *puVar29 = *puVar25;
    puVar29[1] = uVar3;
    puVar29[2] = uVar6;
    puVar29[3] = uVar7;
    uVar3 = puVar25[8];
    uVar6 = puVar25[9];
    uVar7 = puVar25[10];
    uVar12 = puVar25[0xb];
    puVar29[4] = uVar8;
    puVar29[5] = uVar9;
    puVar29[6] = uVar10;
    puVar29[7] = uVar11;
    uVar8 = puVar25[0xc];
    uVar9 = puVar25[0xd];
    uVar10 = puVar25[0xe];
    uVar11 = puVar25[0xf];
    puVar29[8] = uVar3;
    puVar29[9] = uVar6;
    puVar29[10] = uVar7;
    puVar29[0xb] = uVar12;
    uVar3 = puVar25[0x10];
    uVar6 = puVar25[0x11];
    uVar7 = puVar25[0x12];
    uVar12 = puVar25[0x13];
    puVar29[0xc] = uVar8;
    puVar29[0xd] = uVar9;
    puVar29[0xe] = uVar10;
    puVar29[0xf] = uVar11;
    uVar9 = puVar25[0x14];
    uVar10 = puVar25[0x15];
    uVar11 = puVar25[0x16];
    uVar13 = puVar25[0x17];
    puVar29[0x10] = uVar3;
    puVar29[0x11] = uVar6;
    puVar29[0x12] = uVar7;
    puVar29[0x13] = uVar12;
    uVar3 = puVar25[0x18];
    uVar6 = puVar25[0x19];
    uVar7 = puVar25[0x1a];
    uVar8 = puVar25[0x1b];
    puVar29[0x14] = uVar9;
    puVar29[0x15] = uVar10;
    puVar29[0x16] = uVar11;
    puVar29[0x17] = uVar13;
    uVar9 = puVar25[0x1c];
    uVar10 = puVar25[0x1d];
    uVar11 = puVar25[0x1e];
    uVar12 = puVar25[0x1f];
    puVar29[0x18] = uVar3;
    puVar29[0x19] = uVar6;
    puVar29[0x1a] = uVar7;
    puVar29[0x1b] = uVar8;
    puVar29[0x1c] = uVar9;
    puVar29[0x1d] = uVar10;
    puVar29[0x1e] = uVar11;
    puVar29[0x1f] = uVar12;
    lVar28 = lVar28 + -1;
    puVar25 = puVar25 + 0x20;
    puVar29 = puVar29 + 0x20;
  } while (lVar28 != 0);
  *(undefined8 *)((longlong)puVar34 + 0x20) = uStack_5f8;
  *(undefined8 *)((longlong)puVar34 + -8) = 0x100e8d;
  func_0x(plVar38,0,auStack_558,0);
  if ((plVar38[2] != CONCAT44(uRam0000000001fe872c,_DAT_)) ||
     (param_1 = lStack_5e0, lVar28 = lStack_5e8, iVar35 = iStack_614,
     plVar38[3] != CONCAT44(uRam0000000001fe8734,_DAT_))) {
    if ((*(byte *)(plVar38 + 0xe) & 2) != 0) {
      *(undefined8 *)((longlong)puVar34 + -8) = 0x100eba;
      iVar35 = func_0x(plVar38 + 0xf);
      if (iVar35 != 0) {
        *(longlong *)(*plVar38 + 0x30) = *(longlong *)(*plVar38 + 0x30) + -1;
      }
    }
    *(undefined *)(plVar38 + 0xe) = 0;
    *(undefined4 *)((longlong)plVar38 + 0x6c) = 0;
    *(undefined4 *)(plVar38 + 0x11) = 0;
    if ((*(byte *)(plVar38 + 0x14) & 2) != 0) {
      *(undefined8 *)((longlong)puVar34 + -8) = 0x100ee9;
      iVar35 = func_0x(plVar38 + 0x15);
      if (iVar35 != 0) {
        *(longlong *)(*plVar38 + 0x30) = *(longlong *)(*plVar38 + 0x30) + -1;
      }
    }
    *(undefined *)(plVar38 + 0x14) = 0;
    *(undefined4 *)((longlong)plVar38 + 0x9c) = 0;
    *(undefined4 *)(plVar38 + 0x17) = 0;
    if (plVar38[5] != 0) {
      *(undefined *)((longlong)plVar38 + 0x36) = 0;
      plVar38[5] = 0;
      *(undefined2 *)((longlong)plVar38 + 0x34) = 0;
      *(undefined4 *)(plVar38[2] + 0x48) = 0;
    }
    uVar5 = *(undefined8 *)*plVar38;
    *(undefined8 *)((longlong)puVar34 + -8) = 0x100f2f;
    func_0x(uVar5,plVar38 + 2);
    uVar8 = uRam0000000001fe8734;
    uVar7 = _DAT_;
    uVar6 = uRam0000000001fe872c;
    uVar3 = _DAT_;
    *(undefined4 *)(plVar38 + 0x4e) = 0xffffffff;
    *(undefined4 *)(plVar38 + 4) = 0xffffffff;
    *(undefined4 *)(plVar38 + 2) = uVar3;
    *(undefined4 *)((longlong)plVar38 + 0x14) = uVar6;
    *(undefined4 *)(plVar38 + 3) = uVar7;
    *(undefined4 *)((longlong)plVar38 + 0x1c) = uVar8;
    *(undefined4 *)(plVar38 + 0x48) = 0;
    plVar38[0x4b] = 0;
    plVar38[0x4a] = 0;
    plVar38[0x4c] = 0;
    *(undefined2 *)((longlong)plVar38 + 0x274) = 0xffff;
    *(undefined8 *)((longlong)plVar38 + 0x276) = 0;
    *(undefined4 *)(plVar38 + 0x18) = 2;
    param_1 = lStack_5e0;
    lVar28 = lStack_5e8;
    iVar35 = iStack_614;
  }
LAB_:
  cVar14 = cStack_617;
  *(byte *)puVar33 = *(byte *)puVar33 | 1;
  puVar33 = (undefined4 *)(param_1 + 0x530);
  lVar22 = 2;
  if (cStack_617 == '\0') {
    puVar25 = puVar33;
    puVar29 = auStack_358;
    do {
      uVar3 = puVar25[1];
      uVar6 = puVar25[2];
      uVar7 = puVar25[3];
      uVar8 = puVar25[4];
      uVar9 = puVar25[5];
      uVar10 = puVar25[6];
      uVar11 = puVar25[7];
      *puVar29 = *puVar25;
      puVar29[1] = uVar3;
      puVar29[2] = uVar6;
      puVar29[3] = uVar7;
      uVar3 = puVar25[8];
      uVar6 = puVar25[9];
      uVar7 = puVar25[10];
      uVar12 = puVar25[0xb];
      puVar29[4] = uVar8;
      puVar29[5] = uVar9;
      puVar29[6] = uVar10;
      puVar29[7] = uVar11;
      uVar8 = puVar25[0xc];
      uVar9 = puVar25[0xd];
      uVar10 = puVar25[0xe];
      uVar11 = puVar25[0xf];
      puVar29[8] = uVar3;
      puVar29[9] = uVar6;
      puVar29[10] = uVar7;
      puVar29[0xb] = uVar12;
      uVar3 = puVar25[0x10];
      uVar6 = puVar25[0x11];
      uVar7 = puVar25[0x12];
      uVar12 = puVar25[0x13];
      puVar29[0xc] = uVar8;
      puVar29[0xd] = uVar9;
      puVar29[0xe] = uVar10;
      puVar29[0xf] = uVar11;
      uVar9 = puVar25[0x14];
      uVar10 = puVar25[0x15];
      uVar11 = puVar25[0x16];
      uVar13 = puVar25[0x17];
      puVar29[0x10] = uVar3;
      puVar29[0x11] = uVar6;
      puVar29[0x12] = uVar7;
      puVar29[0x13] = uVar12;
      uVar3 = puVar25[0x18];
      uVar6 = puVar25[0x19];
      uVar7 = puVar25[0x1a];
      uVar8 = puVar25[0x1b];
      puVar29[0x14] = uVar9;
      puVar29[0x15] = uVar10;
      puVar29[0x16] = uVar11;
      puVar29[0x17] = uVar13;
      uVar9 = puVar25[0x1c];
      uVar10 = puVar25[0x1d];
      uVar11 = puVar25[0x1e];
      uVar12 = puVar25[0x1f];
      puVar29[0x18] = uVar3;
      puVar29[0x19] = uVar6;
      puVar29[0x1a] = uVar7;
      puVar29[0x1b] = uVar8;
      puVar29[0x1c] = uVar9;
      puVar29[0x1d] = uVar10;
      puVar29[0x1e] = uVar11;
      puVar29[0x1f] = uVar12;
      lVar22 = lVar22 + -1;
      puVar25 = puVar25 + 0x20;
      puVar29 = puVar29 + 0x20;
    } while (lVar22 != 0);
    *(undefined8 *)((longlong)puVar34 + 0x20) = uVar23;
    *(undefined8 *)((longlong)puVar34 + -8) = 0x101011;
    func_0x(lVar28,&puStack_588,auStack_358,0);
  }
  else {
    puVar25 = puVar33;
    puVar29 = auStack_458;
    do {
      uVar3 = puVar25[1];
      uVar6 = puVar25[2];
      uVar7 = puVar25[3];
      uVar8 = puVar25[4];
      uVar9 = puVar25[5];
      uVar10 = puVar25[6];
      uVar11 = puVar25[7];
      *puVar29 = *puVar25;
      puVar29[1] = uVar3;
      puVar29[2] = uVar6;
      puVar29[3] = uVar7;
      uVar3 = puVar25[8];
      uVar6 = puVar25[9];
      uVar7 = puVar25[10];
      uVar12 = puVar25[0xb];
      puVar29[4] = uVar8;
      puVar29[5] = uVar9;
      puVar29[6] = uVar10;
      puVar29[7] = uVar11;
      uVar8 = puVar25[0xc];
      uVar9 = puVar25[0xd];
      uVar10 = puVar25[0xe];
      uVar11 = puVar25[0xf];
      puVar29[8] = uVar3;
      puVar29[9] = uVar6;
      puVar29[10] = uVar7;
      puVar29[0xb] = uVar12;
      uVar3 = puVar25[0x10];
      uVar6 = puVar25[0x11];
      uVar7 = puVar25[0x12];
      uVar12 = puVar25[0x13];
      puVar29[0xc] = uVar8;
      puVar29[0xd] = uVar9;
      puVar29[0xe] = uVar10;
      puVar29[0xf] = uVar11;
      uVar9 = puVar25[0x14];
      uVar10 = puVar25[0x15];
      uVar11 = puVar25[0x16];
      uVar13 = puVar25[0x17];
      puVar29[0x10] = uVar3;
      puVar29[0x11] = uVar6;
      puVar29[0x12] = uVar7;
      puVar29[0x13] = uVar12;
      uVar3 = puVar25[0x18];
      uVar6 = puVar25[0x19];
      uVar7 = puVar25[0x1a];
      uVar8 = puVar25[0x1b];
      puVar29[0x14] = uVar9;
      puVar29[0x15] = uVar10;
      puVar29[0x16] = uVar11;
      puVar29[0x17] = uVar13;
      uVar9 = puVar25[0x1c];
      uVar10 = puVar25[0x1d];
      uVar11 = puVar25[0x1e];
      uVar12 = puVar25[0x1f];
      puVar29[0x18] = uVar3;
      puVar29[0x19] = uVar6;
      puVar29[0x1a] = uVar7;
      puVar29[0x1b] = uVar8;
      puVar29[0x1c] = uVar9;
      puVar29[0x1d] = uVar10;
      puVar29[0x1e] = uVar11;
      puVar29[0x1f] = uVar12;
      lVar22 = lVar22 + -1;
      puVar25 = puVar25 + 0x20;
      puVar29 = puVar29 + 0x20;
    } while (lVar22 != 0);
    *(undefined8 *)((longlong)puVar34 + -8) = 0x100dcc;
    iVar20 = func_0x(lVar28,&puStack_588,auStack_458,0);
    if (iVar20 != 0) {
      *(undefined8 *)((longlong)puVar34 + 0x20) = 0;
      *(undefined8 *)((longlong)puVar34 + -8) = 0x100dfa;
      (*_DAT_)(1,0x1a5b5e8,0x1a30fa8,0xf02);
    }
  }
  *(undefined8 *)((longlong)puVar34 + -8) = 0x10101c;
  func_0x(lVar28);
  if ((iVar35 == 3) && (cStack_618 == '\0')) {
    lVar28 = 2;
    if (cVar14 == '\0') {
      puVar25 = auStack_158;
      do {
        uVar3 = puVar33[1];
        uVar6 = puVar33[2];
        uVar7 = puVar33[3];
        uVar8 = puVar33[4];
        uVar9 = puVar33[5];
        uVar10 = puVar33[6];
        uVar11 = puVar33[7];
        *puVar25 = *puVar33;
        puVar25[1] = uVar3;
        puVar25[2] = uVar6;
        puVar25[3] = uVar7;
        uVar3 = puVar33[8];
        uVar6 = puVar33[9];
        uVar7 = puVar33[10];
        uVar12 = puVar33[0xb];
        puVar25[4] = uVar8;
        puVar25[5] = uVar9;
        puVar25[6] = uVar10;
        puVar25[7] = uVar11;
        uVar8 = puVar33[0xc];
        uVar9 = puVar33[0xd];
        uVar10 = puVar33[0xe];
        uVar11 = puVar33[0xf];
        puVar25[8] = uVar3;
        puVar25[9] = uVar6;
        puVar25[10] = uVar7;
        puVar25[0xb] = uVar12;
        uVar3 = puVar33[0x10];
        uVar6 = puVar33[0x11];
        uVar7 = puVar33[0x12];
        uVar12 = puVar33[0x13];
        puVar25[0xc] = uVar8;
        puVar25[0xd] = uVar9;
        puVar25[0xe] = uVar10;
        puVar25[0xf] = uVar11;
        uVar9 = puVar33[0x14];
        uVar10 = puVar33[0x15];
        uVar11 = puVar33[0x16];
        uVar13 = puVar33[0x17];
        puVar25[0x10] = uVar3;
        puVar25[0x11] = uVar6;
        puVar25[0x12] = uVar7;
        puVar25[0x13] = uVar12;
        uVar3 = puVar33[0x18];
        uVar6 = puVar33[0x19];
        uVar7 = puVar33[0x1a];
        uVar8 = puVar33[0x1b];
        puVar25[0x14] = uVar9;
        puVar25[0x15] = uVar10;
        puVar25[0x16] = uVar11;
        puVar25[0x17] = uVar13;
        uVar9 = puVar33[0x1c];
        uVar10 = puVar33[0x1d];
        uVar11 = puVar33[0x1e];
        uVar12 = puVar33[0x1f];
        puVar25[0x18] = uVar3;
        puVar25[0x19] = uVar6;
        puVar25[0x1a] = uVar7;
        puVar25[0x1b] = uVar8;
        puVar25[0x1c] = uVar9;
        puVar25[0x1d] = uVar10;
        puVar25[0x1e] = uVar11;
        puVar25[0x1f] = uVar12;
        lVar28 = lVar28 + -1;
        puVar25 = puVar25 + 0x20;
        puVar33 = puVar33 + 0x20;
      } while (lVar28 != 0);
      *(undefined8 *)((longlong)puVar34 + 0x20) = 0;
      *(undefined8 *)((longlong)puVar34 + -8) = 0x101160;
      func_0x(param_1 + 0x2b0,0,auStack_158,0);
    }
    else {
      puVar25 = auStack_258;
      do {
        uVar3 = puVar33[1];
        uVar6 = puVar33[2];
        uVar7 = puVar33[3];
        uVar8 = puVar33[4];
        uVar9 = puVar33[5];
        uVar10 = puVar33[6];
        uVar11 = puVar33[7];
        *puVar25 = *puVar33;
        puVar25[1] = uVar3;
        puVar25[2] = uVar6;
        puVar25[3] = uVar7;
        uVar3 = puVar33[8];
        uVar6 = puVar33[9];
        uVar7 = puVar33[10];
        uVar12 = puVar33[0xb];
        puVar25[4] = uVar8;
        puVar25[5] = uVar9;
        puVar25[6] = uVar10;
        puVar25[7] = uVar11;
        uVar8 = puVar33[0xc];
        uVar9 = puVar33[0xd];
        uVar10 = puVar33[0xe];
        uVar11 = puVar33[0xf];
        puVar25[8] = uVar3;
        puVar25[9] = uVar6;
        puVar25[10] = uVar7;
        puVar25[0xb] = uVar12;
        uVar3 = puVar33[0x10];
        uVar6 = puVar33[0x11];
        uVar7 = puVar33[0x12];
        uVar12 = puVar33[0x13];
        puVar25[0xc] = uVar8;
        puVar25[0xd] = uVar9;
        puVar25[0xe] = uVar10;
        puVar25[0xf] = uVar11;
        uVar9 = puVar33[0x14];
        uVar10 = puVar33[0x15];
        uVar11 = puVar33[0x16];
        uVar13 = puVar33[0x17];
        puVar25[0x10] = uVar3;
        puVar25[0x11] = uVar6;
        puVar25[0x12] = uVar7;
        puVar25[0x13] = uVar12;
        uVar3 = puVar33[0x18];
        uVar6 = puVar33[0x19];
        uVar7 = puVar33[0x1a];
        uVar8 = puVar33[0x1b];
        puVar25[0x14] = uVar9;
        puVar25[0x15] = uVar10;
        puVar25[0x16] = uVar11;
        puVar25[0x17] = uVar13;
        uVar9 = puVar33[0x1c];
        uVar10 = puVar33[0x1d];
        uVar11 = puVar33[0x1e];
        uVar12 = puVar33[0x1f];
        puVar25[0x18] = uVar3;
        puVar25[0x19] = uVar6;
        puVar25[0x1a] = uVar7;
        puVar25[0x1b] = uVar8;
        puVar25[0x1c] = uVar9;
        puVar25[0x1d] = uVar10;
        puVar25[0x1e] = uVar11;
        puVar25[0x1f] = uVar12;
        lVar28 = lVar28 + -1;
        puVar25 = puVar25 + 0x20;
        puVar33 = puVar33 + 0x20;
      } while (lVar28 != 0);
      *(undefined8 *)((longlong)puVar34 + -8) = 0x1010ad;
      iVar35 = func_0x(param_1 + 0x2b0,0,auStack_258,0);
      if (iVar35 != 0) {
        *(undefined8 *)((longlong)puVar34 + 0x20) = 0;
        *(undefined8 *)((longlong)puVar34 + -8) = 0x1010d9;
        (*_DAT_)(1,0x1a5b5e8,0x1a30fa8,0xf17);
      }
    }
    *(undefined8 *)((longlong)puVar34 + -8) = 0x101171;
    func_0x(param_1 + 0x2b0,0,0);
    if ((plVar38[2] != CONCAT44(uRam0000000001fe872c,_DAT_)) ||
       (plVar38[3] != CONCAT44(uRam0000000001fe8734,_DAT_))) {
      if ((*(byte *)(plVar38 + 0xe) & 2) != 0) {
        *(undefined8 *)((longlong)puVar34 + -8) = 0x10119e;
        iVar35 = func_0x(plVar38 + 0xf);
        if (iVar35 != 0) {
          *(longlong *)(*plVar38 + 0x30) = *(longlong *)(*plVar38 + 0x30) + -1;
        }
      }
      *(undefined *)(plVar38 + 0xe) = 0;
      *(undefined4 *)((longlong)plVar38 + 0x6c) = 0;
      *(undefined4 *)(plVar38 + 0x11) = 0;
      if ((*(byte *)(plVar38 + 0x14) & 2) != 0) {
        *(undefined8 *)((longlong)puVar34 + -8) = 0x1011cd;
        iVar35 = func_0x(plVar38 + 0x15);
        if (iVar35 != 0) {
          *(longlong *)(*plVar38 + 0x30) = *(longlong *)(*plVar38 + 0x30) + -1;
        }
      }
      *(undefined *)(plVar38 + 0x14) = 0;
      *(undefined4 *)((longlong)plVar38 + 0x9c) = 0;
      *(undefined4 *)(plVar38 + 0x17) = 0;
      if (plVar38[5] != 0) {
        *(undefined *)((longlong)plVar38 + 0x36) = 0;
        plVar38[5] = 0;
        *(undefined2 *)((longlong)plVar38 + 0x34) = 0;
        *(undefined4 *)(plVar38[2] + 0x48) = 0;
      }
      uVar23 = *(undefined8 *)*plVar38;
      *(undefined8 *)((longlong)puVar34 + -8) = 0x101218;
      func_0x(uVar23,plVar38 + 2);
      uVar8 = uRam0000000001fe8734;
      uVar7 = _DAT_;
      uVar6 = uRam0000000001fe872c;
      uVar3 = _DAT_;
      *(undefined4 *)(plVar38 + 0x4e) = 0xffffffff;
      *(undefined4 *)(plVar38 + 4) = 0xffffffff;
      *(undefined4 *)(plVar38 + 2) = uVar3;
      *(undefined4 *)((longlong)plVar38 + 0x14) = uVar6;
      *(undefined4 *)(plVar38 + 3) = uVar7;
      *(undefined4 *)((longlong)plVar38 + 0x1c) = uVar8;
      *(undefined4 *)(plVar38 + 0x48) = 0;
      plVar38[0x4b] = 0;
      plVar38[0x4a] = 0;
      plVar38[0x4c] = 0;
      *(undefined2 *)((longlong)plVar38 + 0x274) = 0xffff;
      *(undefined8 *)((longlong)plVar38 + 0x276) = 0;
      *(undefined4 *)(plVar38 + 0x18) = 2;
    }
  }
  puStack_608 = (undefined8 *)0x0;
  *(undefined8 *)((longlong)puVar34 + -8) = 0x10128b;
  iVar35 = func_0x(param_1,uStack_610,0,&puStack_608);
  if (iVar35 != 4) {
    *(undefined8 *)((longlong)puVar34 + 0x20) = 0;
    *(undefined8 *)((longlong)puVar34 + -8) = 0x1012b4;
    (*_DAT_)(1,0x1a5b938,0x1a30fa8,0xf30);
  }
  *(undefined8 *)((longlong)puVar34 + -8) = 0x1012c3;
  func_0x(uStack_48 ^ (ulonglong)&cStack_618);
  return;
}

