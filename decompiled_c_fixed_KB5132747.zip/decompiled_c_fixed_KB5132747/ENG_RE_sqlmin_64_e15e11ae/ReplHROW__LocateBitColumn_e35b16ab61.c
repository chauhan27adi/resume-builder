
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_(short *param_1,uint *param_2,undefined8 param_3,int *param_4)

{
  ushort *puVar1;
  longlong *plVar2;
  bool bVar3;
  byte bVar4;
  char cVar5;
  ushort uVar6;
  ushort uVar7;
  int iVar8;
  longlong lVar9;
  undefined8 uVar10;
  longlong lVar11;
  short sVar12;
  uint uVar13;
  uint uVar14;
  ulonglong uVar15;
  uint uVar16;
  ushort *puVar17;
  ushort *puVar18;
  ulonglong uVar19;
  int *piVar20;
  byte *pbVar21;
  longlong lVar22;
  ulonglong uVar23;
  int iVar24;
  ushort *puStackX_8;
  undefined auStackX_10 [8];
  uint auStackX_18 [2];
  
  auStackX_18[0] = (uint)param_3;
  puVar1 = (ushort *)(param_1 + 1);
  uVar6 = *(ushort *)(param_2 + 1);
  if (*param_1 != 0) {
    auStackX_18[0] = 0;
    piVar20 = (int *)func_0x(puVar1,param_2,param_3,param_4,auStackX_18);
    if (*param_1 == 0) {
      return piVar20;
    }
    plVar2 = *(longlong **)(param_1 + 8);
    if (plVar2 == (longlong *)0x0) {
      return piVar20;
    }
    if (*plVar2 == 0) {
      return piVar20;
    }
    if ((*(byte *)((longlong)param_2 + 6) & 8) != 0) {
      return piVar20;
    }
    if ((auStackX_18[0] & 1) != 0) {
      return piVar20;
    }
    if ((piVar20 != (int *)0x0) && (piVar20 != (int *)0x1812c70)) {
      piVar20 = (int *)func_0x(plVar2,param_2,piVar20,*param_4,0,0,param_4,auStackX_18[0]);
      return piVar20;
    }
LAB_:
    *param_4 = 0;
    return (int *)0x0;
  }
  uVar13 = *param_2;
  if ((uVar13 & 0xc0000000) == 0x80000000) {
    iVar8 = func_0x(puVar1);
    if (iVar8 != 0) {
      piVar20 = (int *)func_0x(param_1 + 0x15,param_2,param_4,&puStackX_8);
      return piVar20;
    }
    goto LAB_;
  }
  iVar8 = 0;
  uVar7 = 0;
  bVar3 = true;
  if ((uVar6 != 0) || ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0)) {
    pbVar21 = *(byte **)(param_1 + 4);
    if ((*pbVar21 & 0x10) == 0) {
      if ((1 << (*pbVar21 & 0xe) & 0x1105U) != 0) {
LAB_:
        uVar7 = ~(*(ushort *)((longlong)param_2 + 6) >> 4) & 1;
        bVar3 = false;
      }
      if (uVar6 != 0) goto LAB_;
    }
    else {
      uVar16 = *(uint *)(param_1 + 8);
      if (((int)uVar16 <= (int)uVar13) || (*(ushort *)(pbVar21 + uVar16) < uVar6))
      goto LAB_;
      if (uVar6 == 0) goto LAB_;
      uVar7 = pbVar21[(ulonglong)(uVar6 - 1 >> 3) + (ulonglong)uVar16 + 2] >>
              ((byte)(uVar6 - 1) & 7) & 1;
LAB_:
      if (uVar7 != 0) {
        *param_4 = 0;
        return (int *)0x0;
      }
    }
    if ((!bVar3) && ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0)) goto LAB_;
  }
LAB_:
  if (-1 < (int)uVar13) {
    uVar7 = *(ushort *)((longlong)param_2 + 6);
    if ((uVar7 & 8) != 0) {
      piVar20 = (int *)0x1812c70;
      bVar4 = *(byte *)((longlong)(int)uVar13 + *(longlong *)(param_1 + 4));
      *param_4 = 1;
      if ((bVar4 & (byte)(1 << ((byte)uVar7 & 7))) == 0) {
        piVar20 = (int *)0x1812c71;
      }
      return piVar20;
    }
    if ((uVar7 & 0x10) != 0) {
      bVar4 = **(byte **)(param_1 + 4);
      if ((bVar4 & 0x10) == 0) {
        if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
          piVar20 = *(int **)(param_2 + 2);
          iVar8 = *piVar20;
          if (iVar8 != 1) {
            (*_DAT_)(1,0x1c3c420,0x1c3ad88,0x381,0);
          }
          *param_4 = iVar8;
          return piVar20 + 1;
        }
      }
      else if (((int)*(uint *)(param_1 + 8) <= (int)uVar13) ||
              (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) < uVar6))
      goto LAB_;
    }
    *param_4 = 1;
    return (int *)((longlong)(int)*param_2 + *(longlong *)(param_1 + 4));
  }
  if (*(int *)(param_1 + 2) == 0) {
    pbVar21 = *(byte **)(param_1 + 4);
    uVar13 = *(uint *)(param_1 + 8);
    uVar15 = (ulonglong)uVar13;
    *puVar1 = 0;
    *(uint *)(param_1 + 10) = uVar13;
    bVar4 = *pbVar21;
    if ((bVar4 & 0x10) != 0) {
      uVar13 = uVar13 + 2 + (*(ushort *)(pbVar21 + uVar15) + 7 >> 3);
      uVar15 = (ulonglong)uVar13;
      *(uint *)(param_1 + 10) = uVar13;
      bVar4 = *pbVar21;
    }
    if ((bVar4 & 0x20) == 0) {
      *(int *)(param_1 + 2) = (int)uVar15;
      param_1[0xe] = 0;
      *(int *)(param_1 + 0xc) = (int)uVar15;
    }
    else {
      puVar17 = (ushort *)(pbVar21 + uVar15);
      uVar6 = *puVar17;
      param_1[0xe] = uVar6;
      puStackX_8 = puVar17;
      if (uVar6 == 0) {
        cVar5 = func_0x(0x219e5d0);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x219e5d0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x1a8dfdc,0x1bae0c8,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),3);
        uVar15 = (ulonglong)*(uint *)(param_1 + 10);
        uVar6 = param_1[0xe];
      }
      uVar13 = (int)uVar15 + (uVar6 + 1) * 2;
      *(uint *)(param_1 + 0xc) = uVar13;
      if (0x1f9e < uVar13) {
        cVar5 = func_0x(0x219e5d0);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x219e5d0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x1a8dfdc,0x1bae0c8,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar6 = param_1[0xe];
        uVar13 = *(uint *)(param_1 + 0xc);
      }
      uVar15 = (ulonglong)uVar6;
      uVar6 = puVar17[uVar15];
      *(uint *)(param_1 + 2) = uVar6 & 0x7fff;
      if ((uVar6 & 0x7fff) < uVar13) {
        cVar5 = func_0x(0x219e5d0);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x219e5d0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x1a8dfdc,0x1bae0c8,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar13 = *(uint *)(param_1 + 0xc);
        uVar15 = (ulonglong)(ushort)param_1[0xe];
      }
      puVar18 = puVar17;
      iVar24 = iVar8;
      if ((short)uVar15 != 0) {
        do {
          puVar17 = puVar17 + 1;
          uVar16 = *puVar17 & 0x7fff;
          if ((uVar16 < uVar13) || (*(uint *)(param_1 + 2) < uVar16)) {
            cVar5 = func_0x(0x219e5d0);
            if ((cVar5 != '\0') &&
               ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')
                ))) {
              cVar5 = func_0x(0x219e5d0);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x1a8dfdc,0x1bae0c8,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),4);
          }
          uVar15 = (ulonglong)(ushort)param_1[0xe];
          iVar24 = iVar24 + 1;
          puVar18 = puStackX_8;
          uVar13 = uVar16;
        } while (iVar24 < (int)(uint)(ushort)param_1[0xe]);
      }
      puVar17 = puStackX_8;
      if ((short)puVar18[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
        pbVar21 = *(byte **)(param_1 + 4);
        do {
          uVar13 = *(ushort *)(pbVar21 + uVar15 * 2 + (ulonglong)*(uint *)(param_1 + 10)) & 0x7fff;
          if ((int)uVar15 == 1) {
            uVar16 = *(uint *)(param_1 + 0xc);
            uVar14 = uVar16;
LAB_:
            if ((uVar13 < uVar16) || (*(uint *)(param_1 + 2) < uVar13)) goto LAB_;
          }
          else {
            uVar14 = *(uint *)(param_1 + 0xc);
            uVar16 = *(ushort *)(pbVar21 + uVar15 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2)) &
                     0x7fff;
            if (uVar14 <= uVar16) goto LAB_;
LAB_:
            func_0x(pbVar21,7);
            uVar14 = *(uint *)(param_1 + 0xc);
          }
          if ((uVar16 < uVar14) || (*(uint *)(param_1 + 2) < uVar16)) goto LAB_;
          pbVar21 = *(byte **)(param_1 + 4);
          if (*(ushort *)(pbVar21 + uVar16) == 5) {
            *puVar1 = *puVar1 | 2;
            param_1[0xe] = param_1[0xe] + -1;
            uVar23 = (ulonglong)(uVar16 & 0xffff);
            param_1[0x15] = (short)uVar16;
            uVar15 = *(ulonglong *)(param_1 + 4);
            uVar6 = param_1[0x16] & 0xc7ffU;
            if ((*(ushort *)(uVar23 + 2 + uVar15) >> 0xe & 1) != 0) {
              uVar6 = *(ushort *)(uVar23 + 2 + uVar15) & 0x3800 | param_1[0x16] & 0xc7ffU;
            }
            param_1[0x16] = uVar6;
            uVar7 = (uVar6 ^ *(ushort *)(uVar23 + 2 + uVar15)) & 0x7ff ^ uVar6;
            param_1[0x16] = uVar7;
            uVar19 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 + uVar15 + (uVar6 >> 0xb & 7) * 2 + uVar23
            ;
            if (uVar19 < uVar23 + uVar15) {
              func_0x(uVar23 + uVar15,0x19);
              uVar7 = param_1[0x16];
              uVar23 = (ulonglong)(ushort)param_1[0x15];
              uVar15 = (ulonglong)*(uint *)(param_1 + 4);
            }
            if (uVar13 - uVar16 < (((uVar7 & 0x7ff) * 2 - (int)uVar23) - (int)uVar15) + (int)uVar19)
            {
              func_0x(uVar23 + *(longlong *)(param_1 + 4),0x19);
              uVar7 = param_1[0x16];
            }
            if (((uVar7 & 0x3800) != 0) &&
               (puVar17 = (ushort *)
                          (*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]),
               (uVar7 & 0x3800) != 0)) {
              do {
                if ((uVar7 & 0x7ff) < (*puVar17 & 0x7ff)) {
                  func_0x((ulonglong)(ushort)param_1[0x15] + *(longlong *)(param_1 + 4),0x1a
                                 );
                  uVar7 = param_1[0x16];
                }
                iVar8 = iVar8 + 1;
                puVar17 = puVar17 + 1;
              } while (iVar8 < (int)(uVar7 >> 0xb & 7));
            }
            goto LAB_;
          }
          if (*(ushort *)(pbVar21 + uVar16) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar6 = param_1[0xe] - 1;
          param_1[0xe] = uVar6;
          if (uVar6 == 0) goto LAB_;
          uVar15 = (ulonglong)uVar6;
        } while ((short)puVar17[(ulonglong)(uVar6 - 1) + 1] < 0);
        uVar15 = (ulonglong)*(uint *)(param_1 + 2);
      }
      else {
LAB_:
        pbVar21 = *(byte **)(param_1 + 4);
        uVar15 = (ulonglong)*(uint *)(param_1 + 2);
      }
    }
    if ((*pbVar21 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x13) = 0;
    }
    else {
      *(int *)(param_1 + 0x13) = (int)uVar15;
      *(int *)(param_1 + 2) = (int)uVar15 + 0xe;
      uVar10 = func_0x(puVar1);
      func_0x(uVar10,auStackX_10);
      iVar8 = func_0x(auStackX_10);
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar8;
      uVar15 = (ulonglong)*(uint *)(param_1 + 2);
    }
    iVar8 = (int)uVar15;
    if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
       (*(ulonglong *)(param_1 + 0xf) < uVar15 + *(longlong *)(param_1 + 4))) {
      cVar5 = func_0x(0x219e5d0);
      if ((cVar5 != '\0') &&
         ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')))) {
        cVar5 = func_0x(0x219e5d0);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x1a8dfdc,0x1bae0c8,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),0x12);
      iVar8 = *(int *)(param_1 + 2);
    }
    if (0x3f3b < iVar8 - 1U) {
      cVar5 = func_0x(0x219e5d0);
      if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
         (*(char *)(lVar9 + 0x499) != '\0')) {
        cVar5 = func_0x(0x219e5d0);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x1a8dfdc,0x1bae0c8,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),5);
    }
  }
LAB_:
  sVar12 = -*(short *)param_2;
  if ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0) {
    bVar4 = **(byte **)(param_1 + 4);
    if ((bVar4 & 0x10) == 0) {
      if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
        piVar20 = *(int **)(param_2 + 2);
        *param_4 = *piVar20;
        return piVar20 + 1;
      }
    }
    else if (((int)*(uint *)(param_1 + 8) <= (int)*param_2) ||
            (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) <
             *(ushort *)(param_2 + 1))) goto LAB_;
  }
  lVar9 = (longlong)sVar12;
  if ((uint)(ushort)param_1[0xe] < (uint)(int)sVar12) {
    *param_4 = 0;
    return *(int **)(param_1 + 4);
  }
  lVar22 = *(longlong *)(param_1 + 4);
  lVar11 = (ulonglong)*(uint *)(param_1 + 10) + lVar22;
  if (sVar12 == 1) {
    uVar13 = *(uint *)(param_1 + 0xc);
    uVar16 = *(ushort *)(lVar11 + lVar9 * 2) & 0x7fff;
LAB_:
    if ((uVar13 <= uVar16) && (uVar16 <= *(uint *)(param_1 + 2))) goto LAB_;
  }
  else {
    uVar13 = *(ushort *)(lVar11 + -2 + lVar9 * 2) & 0x7fff;
    lVar22 = *(longlong *)(param_1 + 4);
    uVar16 = *(ushort *)(lVar11 + lVar9 * 2) & 0x7fff;
    if (*(uint *)(param_1 + 0xc) <= uVar13) goto LAB_;
  }
  func_0x(lVar22,7);
LAB_:
  *param_4 = uVar16 - uVar13;
  return (int *)((ulonglong)uVar13 + *(longlong *)(param_1 + 4));
}

