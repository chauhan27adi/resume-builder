
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint param_2,longlong param_3)

{
  ulonglong *puVar1;
  char *pcVar2;
  int *piVar3;
  longlong lVar4;
  ulonglong uVar5;
  uint uVar6;
  uint uVar7;
  longlong unaff_GS_OFFSET;
  undefined auStack_1d8 [32];
  undefined4 uStack_1b8;
  longlong alStack_190 [3];
  uint uStack_174;
  uint uStack_170;
  longlong lStack_160;
  ulonglong auStack_120 [27];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_1d8;
  uVar7 = 0;
  alStack_190[0] = 0;
  uVar5 = (ulonglong)param_2;
  uVar6 = 0;
  if (param_3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_170 = param_2;
  lStack_160 = param_1;
  if (*(int *)(param_1 + 0x1c) != 0) {
    do {
      func_0x(*(undefined8 *)(param_1 + 0x48),0,alStack_190);
      uVar6 = uVar7;
      if (alStack_190[0] == 0) break;
      uVar7 = uVar7 + 1;
      if (*(int *)(param_1 + 0x1c) - uVar7 < 8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar6 = uVar7;
      uStack_174 = uVar7;
    } while (uVar7 < *(uint *)(param_1 + 0x1c));
    uVar5 = (ulonglong)uStack_170;
  }
  if (alStack_190[0] == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  func_0x
            (**(undefined8 **)(param_1 + 8),*(undefined8 *)(param_1 + 0x60 + uVar5 * 8));
  uStack_1b8 = *(undefined4 *)(param_1 + 0x80);
  func_0x(*(undefined8 *)(param_1 + 0x48),alStack_190[0],
                  *(undefined8 *)(param_1 + uVar5 * 8 + 0x60),
                  *(undefined8 *)(param_1 + uVar5 * 8 + 0x70));
  func_0x(*(undefined8 *)(param_1 + 0x48));
  puVar1 = (ulonglong *)(param_1 + 0xc0);
  if (*(int *)puVar1 == 0) {
    LOCK();
    uVar5 = *puVar1;
    if (uVar5 == 0) {
      *puVar1 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
    }
    pcVar2 = _DAT_;
    UNLOCK();
    if (uVar5 == 0) {
      *(int *)(param_1 + 0xbc) = *(int *)(param_1 + 0xbc) + uVar6;
      piVar3 = _DAT_;
      if (*pcVar2 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *puVar1 = 0;
      *(int *)(param_1 + 0x28) = *(int *)(param_1 + 0x28) + uVar6;
      if (*piVar3 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      (*_DAT_)(auStack_120);
      if (auStack_120[0] < *(ulonglong *)(param_1 + 0x30)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      lVar4 = auStack_120[0] - *(ulonglong *)(param_1 + 0x30);
      if (lVar4 == -1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*_DAT_ == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (999 < (ulonglong)(lVar4 * 1000) / *_DAT_) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      func_0x(uStack_48 ^ (ulonglong)auStack_1d8);
      return;
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

