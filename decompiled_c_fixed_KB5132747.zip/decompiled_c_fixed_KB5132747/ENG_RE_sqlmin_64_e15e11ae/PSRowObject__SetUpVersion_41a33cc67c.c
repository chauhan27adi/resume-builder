
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_(undefined8 *param_1)

{
  undefined2 uVar1;
  longlong *plVar2;
  ushort *puVar3;
  char cVar4;
  ushort uVar5;
  int iVar6;
  short *psVar7;
  undefined8 uVar8;
  longlong lVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  longlong lVar12;
  undefined8 *puVar13;
  byte bVar14;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  undefined8 *puVar18;
  ushort *puVar19;
  ulonglong uVar20;
  short sVar21;
  ushort uVar22;
  byte *pbVar23;
  ulonglong uVar24;
  uint uVar25;
  ulonglong uVar26;
  longlong unaff_GS_OFFSET;
  bool bVar27;
  undefined8 uStackX_8;
  undefined8 uStackX_10;
  undefined8 *puStackX_18;
  ulonglong in_stack_ffffffffffffff18;
  ulonglong in_stack_ffffffffffffff20;
  ulonglong in_stack_ffffffffffffff38;
  undefined8 uStack_b0;
  undefined2 uStack_a8;
  undefined auStack_98 [96];
  
  uStackX_8 = param_1;
  if ((*(char *)((longlong)(longlong *)param_1[0x26] + 0xe) == '\0') &&
     (*(longlong *)(*(longlong *)param_1[0x26] + 0x18) == 0)) {
    psVar7 = (short *)(**(code **)*param_1)();
    pbVar23 = *(byte **)(psVar7 + 4);
    if (*psVar7 != 0) {
      return ((*pbVar23 & 0x1c) - 4 & 0xffffffe7) == 0;
    }
    bVar14 = *pbVar23 & 0xe;
    if (bVar14 == 2) {
      return (pbVar23[1] & 1) != 0;
    }
    if ((bVar14 - 10 & 0xf9) != 0) {
      return false;
    }
    if (bVar14 == 0x10) {
      return false;
    }
    return true;
  }
  if (param_1[0x28] == 0) {
    uVar8 = (*_DAT_)(0x1f9e,*(undefined8 *)param_1[3],0x9f2dd8,0x36f,5);
    param_1[0x28] = uVar8;
  }
  puVar13 = (undefined8 *)0x0;
  bVar27 = false;
  if (param_1[0x27] == 0) {
    uStackX_10 = (ushort *)CONCAT44(uStackX_10._4_4_,0x375);
    puStackX_18 = (undefined8 *)(*_DAT_)(0xb0,*(undefined8 *)param_1[3],0x9f2dd8,0x375,5);
    puVar18 = puVar13;
    if (puStackX_18 != (undefined8 *)0x0) {
      *(short *)puStackX_18 = -1;
      puStackX_18[1] = 0;
      *(undefined4 *)((longlong)puStackX_18 + 4) = 0;
      *(undefined8 *)((longlong)puStackX_18 + 0x1e) = 0;
      puStackX_18[5] = 0;
      puStackX_18[2] = 0;
      *(undefined4 *)((longlong)puStackX_18 + 0x34) = 0xffffffff;
      puVar18 = puStackX_18;
    }
    param_1[0x27] = puVar18;
    uStackX_8 = (undefined8 *)param_1[0x28];
    sVar21 = *(short *)(param_1 + 0xb);
    *(short *)puVar18 = sVar21;
    if (sVar21 == 0) {
      psVar7 = (short *)((longlong)puVar18 + 2);
      uVar16 = *(uint *)((longlong)param_1 + 0x5c);
      if (uVar16 == 0) {
        *(undefined2 *)((longlong)param_1 + 0x5a) = 0;
        uVar16 = *(uint *)(param_1 + 0xd);
        uVar10 = (ulonglong)uVar16;
        *(uint *)((longlong)param_1 + 0x6c) = uVar16;
        pbVar23 = (byte *)param_1[0xc];
        bVar14 = *pbVar23;
        if ((bVar14 & 0x10) != 0) {
          uVar16 = uVar16 + 2 + (*(ushort *)(pbVar23 + uVar10) + 7 >> 3);
          uVar10 = (ulonglong)uVar16;
          *(uint *)((longlong)param_1 + 0x6c) = uVar16;
          bVar14 = *pbVar23;
        }
        if ((bVar14 & 0x20) == 0) {
          *(int *)((longlong)param_1 + 0x5c) = (int)uVar10;
          *(undefined2 *)((longlong)param_1 + 0x74) = 0;
          *(int *)(param_1 + 0xe) = (int)uVar10;
        }
        else {
          puVar19 = (ushort *)(pbVar23 + uVar10);
          uVar22 = *puVar19;
          *(ushort *)((longlong)param_1 + 0x74) = uVar22;
          uStackX_10 = puVar19;
          if (uVar22 == 0) {
            cVar4 = func_0x(0xfd2cc0);
            if (((cVar4 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
               (*(char *)(lVar9 + 0x499) != '\0')) {
              cVar4 = func_0x(0xfd2cc0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0x8c26cc,0x9e27b8,0x80f,0);
              }
            }
            func_0x(param_1[0xc],3);
            uVar22 = *(ushort *)((longlong)param_1 + 0x74);
            uVar10 = (ulonglong)*(uint *)((longlong)param_1 + 0x6c);
            pbVar23 = (byte *)param_1[0xc];
          }
          uVar16 = (int)uVar10 + (uVar22 + 1) * 2;
          *(uint *)(param_1 + 0xe) = uVar16;
          if (0x1f9e < uVar16) {
            cVar4 = func_0x(0xfd2cc0);
            if (((cVar4 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
               (*(char *)(lVar9 + 0x499) != '\0')) {
              cVar4 = func_0x(0xfd2cc0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x8c26cc,0x9e27b8,0x816,0);
              }
            }
            func_0x(param_1[0xc],4);
            uVar22 = *(ushort *)((longlong)param_1 + 0x74);
            uVar16 = *(uint *)(param_1 + 0xe);
            pbVar23 = (byte *)param_1[0xc];
          }
          uVar20 = (ulonglong)uVar22;
          uVar17 = puVar19[uVar20] & 0x7fff;
          *(uint *)((longlong)param_1 + 0x5c) = uVar17;
          if (uVar17 < uVar16) {
            cVar4 = func_0x(0xfd2cc0);
            if (((cVar4 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
               (*(char *)(lVar9 + 0x499) != '\0')) {
              cVar4 = func_0x(0xfd2cc0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x8c26cc,0x9e27b8,0x81d,0);
              }
            }
            func_0x(param_1[0xc],4);
            uVar16 = *(uint *)(param_1 + 0xe);
            uVar20 = (ulonglong)*(ushort *)((longlong)param_1 + 0x74);
            uVar17 = *(uint *)((longlong)param_1 + 0x5c);
            pbVar23 = (byte *)param_1[0xc];
          }
          puVar11 = puVar13;
          if ((short)uVar20 != 0) {
            do {
              puVar19 = puVar19 + 1;
              uVar17 = *puVar19 & 0x7fff;
              if ((uVar17 < uVar16) || (*(uint *)((longlong)param_1 + 0x5c) < uVar17)) {
                cVar4 = func_0x(0xfd2cc0);
                if ((cVar4 != '\0') &&
                   ((lVar9 = func_0x(), lVar9 != 0 &&
                    (*(char *)(lVar9 + 0x499) != '\0')))) {
                  cVar4 = func_0x(0xfd2cc0);
                  if (cVar4 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    (*_DAT_)(1,0x8c26cc,0x9e27b8,0x82a,0);
                  }
                }
                func_0x(param_1[0xc],4);
              }
              uVar25 = (int)puVar11 + 1;
              uVar20 = (ulonglong)*(ushort *)((longlong)param_1 + 0x74);
              puVar11 = (undefined8 *)(ulonglong)uVar25;
              uVar16 = uVar17;
            } while ((int)uVar25 < (int)(uint)*(ushort *)((longlong)param_1 + 0x74));
            pbVar23 = (byte *)param_1[0xc];
            uVar17 = *(uint *)((longlong)param_1 + 0x5c);
            puVar19 = uStackX_10;
          }
          puVar3 = uStackX_10;
          uVar10 = (ulonglong)uVar17;
          uVar24 = uVar20;
          if ((short)puVar19[(ulonglong)((int)uVar20 - 1) + 1] < 0) {
LAB_:
            sVar21 = (short)uVar20;
            uVar17 = *(ushort *)
                      (pbVar23 + uVar24 * 2 + (ulonglong)*(uint *)((longlong)param_1 + 0x6c)) &
                     0x7fff;
            if ((int)uVar24 == 1) {
              uVar25 = *(uint *)(param_1 + 0xe);
              uVar15 = uVar25;
LAB_:
              if ((uVar17 < uVar25) ||
                 (uVar16 = *(uint *)((longlong)param_1 + 0x5c), uVar16 < uVar17)) goto LAB_;
            }
            else {
              uVar25 = *(ushort *)
                        (pbVar23 + uVar24 * 2 + ((ulonglong)*(uint *)((longlong)param_1 + 0x6c) - 2)
                        ) & 0x7fff;
              uVar15 = *(uint *)(param_1 + 0xe);
              if (uVar15 <= uVar25) goto LAB_;
LAB_:
              func_0x(pbVar23,7);
              uVar15 = *(uint *)(param_1 + 0xe);
              uVar16 = *(uint *)((longlong)param_1 + 0x5c);
              pbVar23 = (byte *)param_1[0xc];
              sVar21 = *(short *)((longlong)param_1 + 0x74);
            }
            uVar10 = (ulonglong)uVar16;
            if ((uVar15 <= uVar25) && (uVar25 <= uVar16)) {
              if (*(ushort *)(pbVar23 + uVar25) == 5) {
                *(ushort *)((longlong)param_1 + 0x5a) = *(ushort *)((longlong)param_1 + 0x5a) | 2;
                *(short *)((longlong)param_1 + 0x74) = sVar21 + -1;
                uVar24 = (ulonglong)(uVar25 & 0xffff);
                *(short *)((longlong)param_1 + 0x82) = (short)uVar25;
                uVar20 = param_1[0xc];
                uVar10 = uVar20 + uVar24;
                uVar22 = *(ushort *)((longlong)param_1 + 0x84) & 0xc7ff;
                if ((*(ushort *)(uVar10 + 2) >> 0xe & 1) != 0) {
                  uVar22 = *(ushort *)(uVar10 + 2) & 0x3800 | uVar22;
                }
                *(ushort *)((longlong)param_1 + 0x84) = uVar22;
                uVar5 = (uVar22 ^ *(ushort *)(uVar10 + 2)) & 0x7ff ^ uVar22;
                *(ushort *)((longlong)param_1 + 0x84) = uVar5;
                uVar26 = uVar20 + 4 + (ulonglong)((uVar22 >> 0xb & 7) * 2) +
                         (ulonglong)((uVar5 & 0x7ff) * 2) + uVar24;
                if (uVar26 < uVar10) {
                  func_0x(uVar10,0x19);
                  uVar5 = *(ushort *)((longlong)param_1 + 0x84);
                  uVar24 = (ulonglong)*(ushort *)((longlong)param_1 + 0x82);
                  uVar20 = (ulonglong)*(uint *)(param_1 + 0xc);
                }
                if (uVar17 - uVar25 <
                    (((uVar5 & 0x7ff) * 2 - (int)uVar24) - (int)uVar20) + (int)uVar26) {
                  func_0x(uVar24 + param_1[0xc],0x19);
                  uVar5 = *(ushort *)((longlong)param_1 + 0x84);
                }
                if (((uVar5 & 0x3800) != 0) &&
                   (puVar19 = (ushort *)
                              (param_1[0xc] + 4 + (ulonglong)*(ushort *)((longlong)param_1 + 0x82)),
                   puVar11 = puVar13, (uVar5 & 0x3800) != 0)) {
                  do {
                    if ((uVar5 & 0x7ff) < (*puVar19 & 0x7ff)) {
                      func_0x
                                ((ulonglong)*(ushort *)((longlong)param_1 + 0x82) + param_1[0xc],
                                 0x1a);
                      uVar5 = *(ushort *)((longlong)param_1 + 0x84);
                    }
                    uVar16 = (int)puVar11 + 1;
                    puVar11 = (undefined8 *)(ulonglong)uVar16;
                    puVar19 = puVar19 + 1;
                  } while ((int)uVar16 < (int)(uVar5 >> 0xb & 7));
                }
                pbVar23 = (byte *)param_1[0xc];
                uVar10 = (ulonglong)*(uint *)((longlong)param_1 + 0x5c);
              }
              else if (0x3ff < *(ushort *)(pbVar23 + uVar25)) {
                *(ushort *)((longlong)param_1 + 0x5a) = *(ushort *)((longlong)param_1 + 0x5a) | 1;
                uVar22 = sVar21 - 1;
                *(ushort *)((longlong)param_1 + 0x74) = uVar22;
                if (uVar22 != 0) goto code_r0x00100583;
              }
              goto LAB_;
            }
            goto LAB_;
          }
        }
LAB_:
        if ((*pbVar23 & 0x40) == 0) {
          *(undefined4 *)((longlong)param_1 + 0x7e) = 0;
        }
        else {
          *(int *)((longlong)param_1 + 0x7e) = (int)uVar10;
          *(int *)((longlong)param_1 + 0x5c) = (int)uVar10 + 0xe;
          uVar8 = func_0x((longlong)param_1 + 0x5a);
          func_0x(uVar8,&uStackX_10);
          iVar6 = func_0x(&uStackX_10);
          *(int *)((longlong)param_1 + 0x5c) = *(int *)((longlong)param_1 + 0x5c) + iVar6;
          uVar10 = (ulonglong)*(uint *)((longlong)param_1 + 0x5c);
          pbVar23 = (byte *)param_1[0xc];
        }
        if ((*(byte **)((longlong)param_1 + 0x76) != (byte *)0x0) &&
           (*(byte **)((longlong)param_1 + 0x76) < pbVar23 + uVar10)) {
          cVar4 = func_0x(0xfd2cc0);
          if ((cVar4 != '\0') &&
             ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')))
             ) {
            cVar4 = func_0x(0xfd2cc0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              (*_DAT_)(1,0x8c26cc,0x9e27b8,0x886,0);
            }
          }
          func_0x(param_1[0xc],0x12);
          uVar10 = (ulonglong)*(uint *)((longlong)param_1 + 0x5c);
        }
        uVar16 = (uint)uVar10;
        if ((uVar16 == 0) || (0x3f3c < uVar16)) {
          cVar4 = func_0x(0xfd2cc0);
          if ((cVar4 != '\0') &&
             ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')))
             ) {
            cVar4 = func_0x(0xfd2cc0);
            if (cVar4 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              (*_DAT_)(1,0x8c26cc,0x9e27b8,0x88b,0);
            }
          }
          func_0x(param_1[0xc],5);
          uVar16 = *(uint *)((longlong)param_1 + 0x5c);
        }
      }
LAB_:
      if ((uVar16 < 9) &&
         (((*(byte *)param_1[0xc] & 0xe) == 0 || ((*(byte *)param_1[0xc] & 0xe) == 0xc)))) {
        uVar16 = 9;
      }
      *(undefined4 *)(puVar18 + 2) = *(undefined4 *)(param_1 + 0xd);
      *psVar7 = *(short *)((longlong)param_1 + 0x5a);
      *(undefined4 *)((longlong)puVar18 + 4) = *(undefined4 *)((longlong)param_1 + 0x5c);
      *(short *)((longlong)puVar18 + 0x1c) = *(short *)((longlong)param_1 + 0x74);
      *(undefined4 *)((longlong)puVar18 + 0x14) = *(undefined4 *)((longlong)param_1 + 0x6c);
      *(undefined4 *)(puVar18 + 3) = *(undefined4 *)(param_1 + 0xe);
      *(undefined4 *)((longlong)puVar18 + 0x26) = *(undefined4 *)((longlong)param_1 + 0x7e);
      func_0x(uStackX_8,0x1f9e,param_1[0xc],uVar16);
      puVar18[1] = uStackX_8;
      iVar6 = func_0x(psVar7);
      if (iVar6 != 0) {
        puVar19 = (ushort *)((ulonglong)*(uint *)((longlong)puVar18 + 0x14) + puVar18[1]);
        uVar16 = *puVar19 - 1;
        if ((*(byte *)psVar7 & 1) == 0) {
          uVar16 = (uint)*puVar19;
        }
        uVar17 = puVar19[(int)uVar16] & 0x7fff;
        if (uVar16 == 1) {
          uVar16 = *(uint *)(puVar18 + 3);
LAB_:
          if ((uVar17 < uVar16) || (*(uint *)((longlong)puVar18 + 4) < uVar17)) goto LAB_;
        }
        else {
          uVar16 = puVar19[(longlong)(int)uVar16 + -1] & 0x7fff;
          if (*(uint *)(puVar18 + 3) <= uVar16) goto LAB_;
LAB_:
          func_0x(puVar18[1],7);
        }
        uVar24 = (ulonglong)(uVar16 & 0xffff);
        *(short *)((longlong)puVar18 + 0x2a) = (short)uVar16;
        uVar20 = puVar18[1];
        uVar10 = uVar20 + uVar24;
        uVar22 = *(ushort *)((longlong)puVar18 + 0x2c) & 0xc7ff;
        if ((*(ushort *)(uVar10 + 2) >> 0xe & 1) != 0) {
          uVar22 = *(ushort *)(uVar10 + 2) & 0x3800 | uVar22;
        }
        *(ushort *)((longlong)puVar18 + 0x2c) = uVar22;
        uVar5 = (uVar22 ^ *(ushort *)(uVar10 + 2)) & 0x7ff ^ uVar22;
        *(ushort *)((longlong)puVar18 + 0x2c) = uVar5;
        uVar26 = (ulonglong)((uVar5 & 0x7ff) * 2) + 4 + uVar20 + (uVar22 >> 0xb & 7) * 2 + uVar24;
        if (uVar26 < uVar10) {
          func_0x(uVar10,0x19);
          uVar5 = *(ushort *)((longlong)puVar18 + 0x2c);
          uVar24 = (ulonglong)*(ushort *)((longlong)puVar18 + 0x2a);
          uVar20 = (ulonglong)*(uint *)(puVar18 + 1);
        }
        if (uVar17 - uVar16 < (((uVar5 & 0x7ff) * 2 - (int)uVar24) - (int)uVar20) + (int)uVar26) {
          func_0x(uVar24 + puVar18[1],0x19);
          uVar5 = *(ushort *)((longlong)puVar18 + 0x2c);
        }
        if (((uVar5 & 0x3800) != 0) &&
           (puVar19 = (ushort *)(puVar18[1] + 4 + (ulonglong)*(ushort *)((longlong)puVar18 + 0x2a)),
           puVar11 = puVar13, (uVar5 & 0x3800) != 0)) {
          do {
            if ((uVar5 & 0x7ff) < (*puVar19 & 0x7ff)) {
              func_0x
                        ((ulonglong)*(ushort *)((longlong)puVar18 + 0x2a) + puVar18[1],0x1a);
              uVar5 = *(ushort *)((longlong)puVar18 + 0x2c);
            }
            uVar16 = (int)puVar11 + 1;
            puVar19 = puVar19 + 1;
            puVar11 = (undefined8 *)(ulonglong)uVar16;
          } while ((int)uVar16 < (int)(uVar5 >> 0xb & 7));
        }
      }
    }
    else if (((*(short *)(param_1 + 0xb) == 0) || ((longlong *)param_1[0xd] == (longlong *)0x0)) ||
            (*(longlong *)param_1[0xd] == 0)) {
      func_0x
                ((short *)((longlong)puVar18 + 2),uStackX_8,0x1f9e,(longlong)param_1 + 0x5a);
      puVar11 = puVar13;
      if (*(short *)(param_1 + 0xb) != 0) {
        puVar11 = (undefined8 *)param_1[0xd];
      }
      puVar18[2] = puVar11;
    }
    else {
      func_0x(puVar18,uStackX_8,0x1f9e,param_1 + 0xb);
    }
  }
  lVar9 = param_1[0x22];
  if (*(short *)(lVar9 + 0x24) == 0) {
LAB_:
    uStack_b0 = *(undefined8 *)(lVar9 + 0x28);
    uStack_a8 = *(undefined2 *)(lVar9 + 0x30);
  }
  else {
    cVar4 = *(char *)(lVar9 + 1);
    if (cVar4 == '\v') {
      if (*(int *)(lVar9 + 0x18) != 99) {
LAB_:
        if (cVar4 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar4 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar9 + 0x18) != 99) goto LAB_;
    }
    uStackX_8 = (undefined8 *)CONCAT26(uStackX_8._6_2_,*(undefined6 *)(lVar9 + 0x20));
    cVar4 = func_0x(&uStackX_8);
    if (cVar4 == '\0') goto LAB_;
    func_0x(lVar9,&uStack_b0);
  }
  puVar18 = (undefined8 *)((longlong)param_1 + 0xbd6);
  *puVar18 = uStack_b0;
  *(undefined2 *)((longlong)param_1 + 0xbde) = uStack_a8;
  uStackX_10 = (ushort *)param_1[0x26];
  puVar11 = param_1 + 0x2b;
  psVar7 = (short *)param_1[0x27];
  lVar9 = param_1[4];
  plVar2 = *(longlong **)(param_1[0x25] + 8);
  puStackX_18 = (undefined8 *)param_1[0x28];
  if ((*(char *)(plVar2[6] + 0x2050) != '\0') && ((*(byte *)(lVar9 + 0x10) & 1) != 0)) {
    iVar6 = (**(code **)(*plVar2 + 0xf0))(plVar2);
    if (iVar6 == 0) {
      lVar12 = plVar2[0x49];
    }
    else {
      lVar12 = (**(code **)(*plVar2 + 0x1e8))(plVar2);
      lVar12 = *(longlong *)(lVar12 + 0x248);
    }
    if (*(char *)(lVar12 + 0x16) == '\0') {
      (*_DAT_)(0x27,0x30,0x10,2);
    }
  }
  func_0x(psVar7,param_1 + 0xb);
  *(int *)puVar11 = 1;
  if (uStackX_10 == (ushort *)0x0) {
    if (((DAT_ & 8) != 0) ||
       (((lVar12 = *(longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
         lVar12 != 0 && (lVar12 = **(longlong **)(lVar12 + 0x38), lVar12 != 0)) &&
        (iVar6 = (*_DAT_)(lVar12,0xf73), iVar6 != 0)))) {
      puVar18 = puVar13;
      if (plVar2[0x1a] != 0) {
        puVar18 = *(undefined8 **)(plVar2[0x1a] + 0x40);
      }
      uVar1 = *(undefined2 *)(plVar2[6] + 0x6b8);
      uVar8 = (**(code **)(*(longlong *)plVar2[0x52] + 0x138))();
      func_0x(0x8cb770,uVar1,*(undefined8 *)(lVar9 + 0x28),uVar8,puVar18);
    }
  }
  else {
    bVar14 = **(byte **)(psVar7 + 4) >> 1;
    if (*psVar7 == 0) {
      bVar14 = **(byte **)(psVar7 + 4) >> 6;
    }
    if ((bVar14 & 1) != 0) {
      if (*psVar7 == 0) {
        func_0x();
      }
      else {
        func_0x(psVar7 + 1,&uStackX_8);
      }
      if ((uStackX_8._4_2_ != 0) || ((int)uStackX_8 != 0)) {
        if (*(short *)(param_1 + 0xb) == 1) {
          func_0x
                    (param_1 + 0xb,puStackX_18,0x1f9e,plVar2,lVar9,psVar7,puVar11,
                     in_stack_ffffffffffffff20 & 0xffffffffffffff00,0,uStackX_10,puVar18);
        }
        else {
          func_0x
                    (puStackX_18,0x1f9e,plVar2,lVar9,psVar7,puVar11,
                     in_stack_ffffffffffffff18 & 0xffffffffffffff00,0,uStackX_10,puVar18,
                     in_stack_ffffffffffffff38 & 0xffffffffffffff00,param_1 + 0x178);
        }
        goto LAB_;
      }
    }
  }
  if (((DAT_ & 8) != 0) ||
     (((lVar9 = *(longlong *)
                 ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
       lVar9 != 0 && (lVar9 = **(longlong **)(lVar9 + 0x38), lVar9 != 0)) &&
      (iVar6 = (*_DAT_)(lVar9,0xf73), iVar6 != 0)))) {
    (*_DAT_)(auStack_98);
    uVar8 = (*_DAT_)();
    uStackX_8 = (undefined8 *)(*_DAT_)(uVar8,0,0x6c0);
    if (uStackX_8 != (undefined8 *)0x0) {
      puVar13 = (undefined8 *)func_0x(uStackX_8,0);
    }
    if ((puVar13 != (undefined8 *)0x0) && (iVar6 = (*_DAT_)(auStack_98,puVar13), iVar6 == 0)
       ) {
      (**(code **)*puVar13)(puVar13,1);
    }
    func_0x(psVar7,auStack_98);
    (*_DAT_)(auStack_98);
  }
LAB_:
  if (*(int *)puVar11 != 0) {
    uVar16 = *(uint *)(param_1 + 2);
    uVar17 = uVar16 | 0x800;
    *(uint *)(param_1 + 2) = uVar17;
    if ((*(char *)(param_1 + 0x178) == '\0') || (*(char *)((longlong)param_1 + 0xbc1) == '\0')) {
      if ((uVar16 & 0x8000) == 0) {
        func_0x(param_1);
        uVar17 = *(uint *)(param_1 + 2);
      }
      if ((uVar17 >> 0xc & 1) == 0) {
        func_0x(param_1);
      }
      return (bool)2;
    }
    psVar7 = (short *)(**(code **)*param_1)(param_1);
    pbVar23 = *(byte **)(psVar7 + 4);
    if (*psVar7 == 0) {
      bVar14 = *pbVar23 & 0xe;
      if (bVar14 == 2) {
        bVar27 = (pbVar23[1] & 1) != 0;
      }
      else if (((bVar14 - 10 & 0xf9) == 0) && (bVar14 != 0x10)) {
        bVar27 = true;
      }
    }
    else {
      bVar27 = ((*pbVar23 & 0x1c) - 4 & 0xffffffe7) == 0;
    }
    if (!bVar27) {
      return false;
    }
  }
  return true;
code_r0x00100583:
  uVar20 = (ulonglong)uVar22;
  uVar24 = (ulonglong)(uint)uVar22;
  if (-1 < (short)puVar3[(ulonglong)(uVar22 - 1) + 1]) goto LAB_;
  goto LAB_;
}

