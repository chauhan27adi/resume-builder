
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined8 *param_3,undefined8 *param_4,
                 undefined4 *param_5,undefined8 *param_6)

{
  int *piVar1;
  byte *pbVar2;
  byte *pbVar3;
  undefined2 uVar4;
  longlong lVar5;
  longlong **pplVar6;
  char cVar7;
  short sVar8;
  int iVar9;
  uint uVar10;
  undefined8 uVar11;
  undefined8 *puVar12;
  byte **ppbVar13;
  ulonglong uVar14;
  code *UNRECOVERED_JUMPTABLE_00;
  undefined4 *puVar15;
  longlong *plVar16;
  undefined4 uVar17;
  longlong lVar18;
  longlong lVar19;
  undefined auStack_2c8 [32];
  undefined8 uStack_2a8;
  longlong *plStack_2a0;
  short sStack_288;
  uint uStack_280;
  undefined4 uStack_27c;
  undefined2 uStack_278;
  undefined8 uStack_270;
  longlong lStack_268;
  longlong *plStack_260;
  undefined8 uStack_248;
  undefined8 *puStack_240;
  undefined4 *puStack_238;
  undefined8 uStack_230;
  undefined2 uStack_228;
  undefined8 *puStack_210;
  undefined8 *puStack_208;
  undefined2 uStack_200;
  undefined4 uStack_1fc;
  byte *pbStack_1f8;
  undefined8 uStack_1f0;
  undefined8 uStack_1e2;
  undefined2 uStack_1da;
  undefined2 uStack_1d8;
  undefined6 uStack_1d6;
  int iStack_1cc;
  undefined auStack_1c8 [16];
  undefined auStack_1b8 [16];
  undefined auStack_1a8 [16];
  undefined auStack_198 [16];
  undefined auStack_188 [16];
  undefined auStack_178 [16];
  undefined auStack_168 [16];
  undefined8 uStack_158;
  short sStack_150;
  undefined4 uStack_14c;
  byte *pbStack_148;
  byte **ppbStack_140;
  undefined8 uStack_132;
  undefined2 uStack_12a;
  undefined2 uStack_128;
  undefined6 uStack_126;
  int iStack_11c;
  undefined auStack_118 [16];
  undefined auStack_108 [16];
  undefined auStack_f8 [16];
  undefined auStack_e8 [16];
  undefined auStack_d8 [16];
  undefined auStack_c8 [16];
  undefined auStack_b8 [16];
  undefined8 uStack_a8;
  ushort *apuStack_a0 [2];
  undefined auStack_90 [16];
  undefined auStack_80 [16];
  undefined auStack_70 [16];
  undefined auStack_60 [24];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_2c8;
  puStack_238 = param_5;
  uVar10 = *(uint *)(param_1 + 0xc);
  puStack_208 = param_6;
  lStack_268 = param_1;
  puStack_240 = param_3;
  puStack_210 = param_4;
  if ((uVar10 & 2) != 0) goto LAB_;
  plStack_260 = (longlong *)(param_1 + 0x30);
  if (*plStack_260 == 0) {
    uStack_2a8 = 0;
    plStack_2a0 = plStack_260;
    func_0x(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_1 + 0x20));
    lVar18 = *(longlong *)(param_1 + 0x18);
    sStack_150 = -1;
    pbStack_148 = (byte *)0x0;
    uStack_14c = 0;
    uStack_132 = 0;
    uStack_128 = 0;
    uStack_126 = 0;
    ppbStack_140 = (byte **)0x0;
    iStack_11c = 0xffffffff;
    lVar5 = **(longlong **)(lVar18 + 0x68);
    lVar19 = *(longlong *)(lVar18 + 0xd8);
    if (*(int *)(lVar19 + 0x20) == 0) {
      lVar19 = *(longlong *)(lVar19 + 0x18);
    }
    else {
      lVar19 = *(longlong *)(lVar19 + 0x10);
    }
    piVar1 = (int *)(lVar5 + 0x20);
    uStack_248 = **(undefined8 **)(lVar18 + 8);
    uStack_270 = lVar19;
    if (((*piVar1 == *(int *)(lVar18 + 0x118)) &&
        (*(short *)(lVar5 + 0x24) == *(short *)(lVar18 + 0x11c))) &&
       (iVar9 = func_0x(), iVar9 == 0)) {
      uVar11 = func_0x(lVar5,auStack_90);
      iVar9 = func_0x(uVar11,lVar18 + 0x124);
      if (iVar9 == 0) goto LAB_;
    }
    else {
LAB_:
      func_0x(lVar18 + 0x118);
      *(int *)(lVar18 + 0x118) = *piVar1;
      *(undefined2 *)(lVar18 + 0x11c) = *(undefined2 *)(lVar5 + 0x24);
      puVar12 = (undefined8 *)func_0x(lVar5,auStack_80);
      *(undefined8 *)(lVar18 + 0x124) = *puVar12;
      *(undefined2 *)(lVar18 + 300) = *(undefined2 *)(puVar12 + 1);
      *(undefined4 *)(lVar18 + 0x130) = 1;
      if (*(int *)(lVar19 + 0x10) == 0) {
        uStack_280 = (uint)*(ushort *)(**(longlong **)(lVar18 + 0x68) + 0x16);
        iStack_11c = uStack_280 - 1;
        if (*(char *)(lVar5 + 2) < '\0') {
          pbVar2 = (byte *)(lVar5 + 0x60);
          if ((sStack_150 == 0) || (ppbVar13 = ppbStack_140, ppbStack_140 == (byte **)0x0)) {
            auStack_118 = ZEXT816(0);
            uStack_a8 = 0;
            auStack_108 = ZEXT816(0);
            auStack_f8 = ZEXT816(0);
            auStack_e8 = ZEXT816(0);
            auStack_d8 = ZEXT816(0);
            auStack_c8 = ZEXT816(0);
            auStack_b8 = ZEXT816(0);
            ppbVar13 = (byte **)func_0x(auStack_118);
          }
          uVar11 = func_0x(lVar5,auStack_70,0);
          if (pbVar2 == *ppbVar13) {
            func_0x(uVar11,ppbVar13 + 0xc);
          }
          *ppbVar13 = pbVar2;
          func_0x(ppbVar13 + 0xc,uVar11);
          func_0x((longlong)ppbVar13 + 0x6c,piVar1);
          uStack_27c = *(undefined4 *)((ulonglong)*pbVar2 * 6 + 0x1732c30);
          sStack_288 = *(short *)((ulonglong)*pbVar2 * 6 + 0x1732c34);
          *(undefined2 *)(ppbVar13 + 2) = 0xffff;
          ppbVar13[3] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
          *(undefined8 *)((longlong)ppbVar13 + 0x2e) = 0;
          ppbVar13[7] = (byte *)0x0;
          ppbVar13[4] = (byte *)0x0;
          ppbVar13[9] = (byte *)0x0;
          ppbVar13[10] = (byte *)0x0;
          *(undefined2 *)(ppbVar13 + 0xb) = 0;
          if ((**ppbVar13 & 2) != 0) {
            pbVar3 = pbVar2 + sStack_288;
            if ((pbVar2[sStack_288] & 1) == 0) {
              *(undefined2 *)(ppbVar13 + 2) = 0;
              ppbVar13[3] = pbVar3;
              *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
              *(undefined4 *)((longlong)ppbVar13 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001004d6 */
                    /* WARNING: Treating indirect jump as call */
              (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x101f80) -
                        0xe661e0))();
              return;
            }
            *(undefined2 *)(ppbVar13 + 2) = 1;
            ppbVar13[3] = pbVar3;
            UNRECOVERED_JUMPTABLE_00 =
                 (code *)((ulonglong)
                          *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x101f60)
                                    * 4 + 0x101f50) - 0xe661e0);
                    /* WARNING: Could not emulate address calculation at 0x00100327 */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
            return;
          }
          if ((**ppbVar13 & 4) != 0) {
            uStack_27c._2_2_ = (short)((uint)uStack_27c >> 0x10);
            if (uStack_27c._2_2_ == 0) {
              uVar14 = (ulonglong)sStack_288;
            }
            else {
              uVar14 = (ulonglong)*(ushort *)(lVar5 + 0x61 + (longlong)uStack_27c._2_2_ * 2);
            }
            func_0x(ppbVar13 + 9,pbVar2 + uVar14);
          }
          if (ppbVar13[1] != (byte *)0x0) {
            func_0x(ppbVar13[1],ppbVar13);
          }
        }
        pbStack_148 = (byte *)((ulonglong)
                               *(ushort *)(lVar5 + (0x1000 - (longlong)(int)uStack_280) * 2) + lVar5
                              );
        if ((*pbStack_148 & 1) == 0) {
          sStack_150 = 0;
          uStack_14c = 0;
          uStack_12a = 0;
          uStack_128 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100760 */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_148 & 0xe) * 4 + 0x101fec) -
                    0xe661e0))();
          return;
        }
        sStack_150 = 1;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)
                                *(byte *)((longlong)(int)(*pbStack_148 & 0x1c) + 0x101fcc) * 4 +
                               0x101fbc) - 0xe661e0);
                    /* WARNING: Could not emulate address calculation at 0x001005df */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
        return;
      }
    }
    if (*(int *)(lVar18 + 0x130) == 0) {
      iVar9 = *(int *)(lVar18 + 0x80);
      uStack_280 = iVar9;
      iStack_11c = iVar9;
      if (*(char *)(lVar5 + 2) < '\0') {
        pbVar2 = (byte *)(lVar5 + 0x60);
        if ((sStack_150 == 0) || (ppbVar13 = ppbStack_140, ppbStack_140 == (byte **)0x0)) {
          auStack_118 = ZEXT816(0);
          uStack_a8 = 0;
          auStack_108 = ZEXT816(0);
          auStack_f8 = ZEXT816(0);
          auStack_e8 = ZEXT816(0);
          auStack_d8 = ZEXT816(0);
          auStack_c8 = ZEXT816(0);
          auStack_b8 = ZEXT816(0);
          ppbVar13 = (byte **)func_0x(auStack_118);
        }
        uVar11 = func_0x(lVar5,apuStack_a0,0,0);
        if (pbVar2 == *ppbVar13) {
          func_0x(uVar11,ppbVar13 + 0xc);
        }
        *ppbVar13 = pbVar2;
        func_0x(ppbVar13 + 0xc,uVar11);
        func_0x((longlong)ppbVar13 + 0x6c,piVar1);
        uStack_27c = *(undefined4 *)((ulonglong)*pbVar2 * 6 + 0x1732c30);
        sStack_288 = *(short *)((ulonglong)*pbVar2 * 6 + 0x1732c34);
        *(undefined2 *)(ppbVar13 + 2) = 0xffff;
        ppbVar13[3] = (byte *)0x0;
        *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
        *(undefined8 *)((longlong)ppbVar13 + 0x2e) = 0;
        ppbVar13[7] = (byte *)0x0;
        ppbVar13[4] = (byte *)0x0;
        ppbVar13[9] = (byte *)0x0;
        ppbVar13[10] = (byte *)0x0;
        *(undefined2 *)(ppbVar13 + 0xb) = 0;
        if ((**ppbVar13 & 2) != 0) {
          pbVar3 = pbVar2 + sStack_288;
          if ((pbVar2[sStack_288] & 1) == 0) {
            *(undefined2 *)(ppbVar13 + 2) = 0;
            ppbVar13[3] = pbVar3;
            *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
            *(undefined4 *)((longlong)ppbVar13 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100b03 */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x102058) -
                      0xe661e0))();
            return;
          }
          *(undefined2 *)(ppbVar13 + 2) = 1;
          ppbVar13[3] = pbVar3;
          UNRECOVERED_JUMPTABLE_00 =
               (code *)((ulonglong)
                        *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x102038) *
                                  4 + 0x102028) - 0xe661e0);
                    /* WARNING: Could not emulate address calculation at 0x0010096c */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
          return;
        }
        if ((**ppbVar13 & 4) != 0) {
          uStack_27c._2_2_ = (short)((uint)uStack_27c >> 0x10);
          if (uStack_27c._2_2_ == 0) {
            uVar14 = (ulonglong)sStack_288;
          }
          else {
            uVar14 = (ulonglong)*(ushort *)(lVar5 + 0x61 + (longlong)uStack_27c._2_2_ * 2);
          }
          func_0x(ppbVar13 + 9,pbVar2 + uVar14);
        }
        if (ppbVar13[1] != (byte *)0x0) {
          func_0x(ppbVar13[1],ppbVar13);
        }
      }
      pbStack_148 = (byte *)((ulonglong)*(ushort *)(lVar5 + (0xfff - (longlong)iVar9) * 2) + lVar5);
      if ((*pbStack_148 & 1) == 0) {
        sStack_150 = 0;
        uStack_14c = 0;
        uStack_12a = 0;
        uStack_128 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100d88 */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_148 & 0xe) * 4 + 0x1020c4) -
                  0xe661e0))();
        return;
      }
      sStack_150 = 1;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_148 & 0x1c) + 0x1020a4)
                              * 4 + 0x102094) - 0xe661e0);
                    /* WARNING: Could not emulate address calculation at 0x00100c05 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
    uVar10 = *(uint *)(param_1 + 0xc);
  }
  else if ((uVar10 & 8) == 0) {
    func_0x(*(undefined8 *)(param_1 + 0x18),0,plStack_260);
    uVar10 = *(uint *)(param_1 + 0xc);
  }
  *(uint *)(param_1 + 0xc) = uVar10 & 0xfffffff7;
  while (pplVar6 = *(longlong ***)(param_1 + 0x30), pplVar6 != (longlong **)0x0) {
    if (*(int *)(pplVar6 + 5) == 0) {
      iStack_1cc = *(int *)(pplVar6 + 3);
      lVar18 = **pplVar6;
      plStack_260 = (longlong *)
                    (*(longlong *)(**(longlong **)(*(longlong *)(param_1 + 0x18) + 8) + 8) + 0x210);
      apuStack_a0[0] = (ushort *)((0xfff - (longlong)iStack_1cc) * 2 + lVar18);
      if ((*(byte *)((ulonglong)*apuStack_a0[0] + lVar18) & 1) != 0) {
        uStack_200 = 0xffff;
        pbStack_1f8 = (byte *)0x0;
        uStack_1fc = 0;
        uStack_1e2 = 0;
        uStack_1d8 = 0;
        uStack_1d6 = 0;
        uStack_1f0 = 0;
        if (*(char *)(lVar18 + 2) < '\0') {
          pbVar2 = (byte *)(lVar18 + 0x60);
          auStack_1c8 = ZEXT816(0);
          uStack_158 = 0;
          auStack_1b8 = ZEXT816(0);
          auStack_1a8 = ZEXT816(0);
          auStack_198 = ZEXT816(0);
          auStack_188 = ZEXT816(0);
          auStack_178 = ZEXT816(0);
          auStack_168 = ZEXT816(0);
          ppbVar13 = (byte **)func_0x(auStack_1c8);
          uVar11 = func_0x(lVar18,auStack_60,0);
          if (pbVar2 == *ppbVar13) {
            func_0x(uVar11,ppbVar13 + 0xc);
          }
          *ppbVar13 = pbVar2;
          func_0x(ppbVar13 + 0xc,uVar11);
          func_0x((longlong)ppbVar13 + 0x6c,lVar18 + 0x20);
          uVar17 = *(undefined4 *)((ulonglong)*pbVar2 * 6 + 0x1732c30);
          uVar14 = (ulonglong)*(short *)((ulonglong)*pbVar2 * 6 + 0x1732c34);
          uStack_270 = CONCAT44(uStack_270._4_4_,uVar17);
          lVar5 = uStack_270;
          *(undefined2 *)(ppbVar13 + 2) = 0xffff;
          ppbVar13[3] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
          *(undefined8 *)((longlong)ppbVar13 + 0x2e) = 0;
          ppbVar13[7] = (byte *)0x0;
          ppbVar13[4] = (byte *)0x0;
          ppbVar13[9] = (byte *)0x0;
          ppbVar13[10] = (byte *)0x0;
          *(undefined2 *)(ppbVar13 + 0xb) = 0;
          if ((**ppbVar13 & 2) != 0) {
            pbVar3 = pbVar2 + uVar14;
            if ((pbVar2[uVar14] & 1) == 0) {
              *(undefined2 *)(ppbVar13 + 2) = 0;
              ppbVar13[3] = pbVar3;
              *(undefined4 *)((longlong)ppbVar13 + 0x14) = 0;
              *(undefined4 *)((longlong)ppbVar13 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001011b4 */
                    /* WARNING: Treating indirect jump as call */
              (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x102130) -
                        0xe661e0))();
              return;
            }
            *(undefined2 *)(ppbVar13 + 2) = 1;
            ppbVar13[3] = pbVar3;
            UNRECOVERED_JUMPTABLE_00 =
                 (code *)((ulonglong)
                          *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x102110)
                                    * 4 + 0x102100) - 0xe661e0);
                    /* WARNING: Could not emulate address calculation at 0x00101011 */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
            return;
          }
          if ((**ppbVar13 & 4) != 0) {
            uStack_270._2_2_ = (short)((uint)uVar17 >> 0x10);
            if (uStack_270._2_2_ != 0) {
              uVar14 = (ulonglong)*(ushort *)(lVar18 + 0x61 + (longlong)uStack_270._2_2_ * 2);
            }
            uStack_270 = lVar5;
            func_0x(ppbVar13 + 9,pbVar2 + uVar14);
          }
          if (ppbVar13[1] != (byte *)0x0) {
            func_0x(ppbVar13[1],ppbVar13);
          }
        }
        pbStack_1f8 = (byte *)((ulonglong)*apuStack_a0[0] + lVar18);
        if ((*pbStack_1f8 & 1) == 0) {
          uStack_200 = 0;
          uStack_1fc = 0;
          uStack_1da = 0;
          uStack_1d8 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010140e */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_1f8 & 0xe) * 4 + 0x10219c) -
                    0xe661e0))();
          return;
        }
        uStack_200 = 1;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)
                                *(byte *)((longlong)(int)(*pbStack_1f8 & 0x1c) + 0x10217c) * 4 +
                               0x10216c) - 0xe661e0);
                    /* WARNING: Could not emulate address calculation at 0x001012aa */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
        return;
      }
      puVar15 = (undefined4 *)((byte *)((ulonglong)*apuStack_a0[0] + lVar18) + *(int *)plStack_260);
      uVar17 = *puVar15;
      sVar8 = *(short *)(puVar15 + 1);
    }
    else {
      uVar17 = *(undefined4 *)((longlong)pplVar6 + 0x34);
      sVar8 = *(short *)(pplVar6 + 7);
    }
    if ((*(short *)(param_1 + 0x28) == 0) || (*(short *)(param_1 + 0x28) == sVar8)) {
      *(undefined4 *)(puStack_210 + 1) = uVar17;
      *(short *)((longlong)puStack_210 + 0xc) = sVar8;
      *(undefined2 *)((longlong)puStack_210 + 0xe) = 0;
      *puStack_210 = 0;
      *(undefined4 *)((longlong)puStack_210 + 0x1c) = 0;
      puStack_210[2] = 0;
      *(undefined2 *)(puStack_210 + 3) = 0;
      break;
    }
    func_0x(*(undefined8 *)(param_1 + 0x18),0,param_1 + 0x30);
  }
  plVar16 = (longlong *)(param_1 + 0x30);
  if (*plVar16 == 0) {
    *puStack_240 = 0;
    *puStack_238 = _DAT_;
    *(undefined2 *)(puStack_238 + 1) = _DAT_;
    func_0x(param_1);
    goto LAB_;
  }
  uStack_2a8 = CONCAT44(uStack_2a8._4_4_,*(undefined4 *)(param_1 + 0x88));
  func_0x
            (*(undefined8 *)(param_1 + 0x18),*plVar16,*(undefined8 *)(param_1 + 0x80),param_1 + 0x8c
            );
  *puStack_240 = *(undefined8 *)(param_1 + 0x80);
  lVar18 = **(longlong **)*plVar16;
  *puStack_238 = *(undefined4 *)(lVar18 + 0x34);
  *(undefined2 *)(puStack_238 + 1) = *(undefined2 *)(lVar18 + 0x38);
  lVar18 = **(longlong **)*plVar16;
  if (*(short *)(lVar18 + 0x24) != 0) {
    cVar7 = *(char *)(lVar18 + 1);
    if (cVar7 == '\v') {
      if (*(int *)(lVar18 + 0x18) != 99) {
LAB_:
        if (cVar7 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar7 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar18 + 0x18) != 99) goto LAB_;
    }
    uStack_27c = *(undefined4 *)(lVar18 + 0x20);
    uStack_278 = *(undefined2 *)(lVar18 + 0x24);
    cVar7 = func_0x(&uStack_27c);
    if (cVar7 != '\0') {
      func_0x(lVar18,&uStack_230);
      *puStack_208 = uStack_230;
      *(undefined2 *)(puStack_208 + 1) = uStack_228;
      goto LAB_;
    }
  }
LAB_:
  uVar4 = *(undefined2 *)(lVar18 + 0x30);
  *puStack_208 = *(undefined8 *)(lVar18 + 0x28);
  *(undefined2 *)(puStack_208 + 1) = uVar4;
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_2c8);
  return;
}

