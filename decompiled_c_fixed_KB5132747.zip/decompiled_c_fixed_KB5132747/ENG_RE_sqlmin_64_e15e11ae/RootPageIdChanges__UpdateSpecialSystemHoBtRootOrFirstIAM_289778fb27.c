
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong param_2,longlong param_3)

{
  byte bVar1;
  ushort uVar2;
  undefined4 uVar3;
  char cVar4;
  int iVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  ushort *puVar9;
  undefined8 uVar10;
  longlong lVar11;
  ulonglong uVar12;
  short *psVar13;
  uint uVar14;
  undefined2 *puVar15;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong *plVar16;
  undefined8 *puVar17;
  longlong lVar18;
  uint *puVar19;
  uint *puVar20;
  ulonglong uVar21;
  longlong **pplVar22;
  byte **ppbVar23;
  byte *pbVar24;
  ushort uVar25;
  undefined2 uVar26;
  short sVar27;
  longlong unaff_GS_OFFSET;
  undefined4 auStackX_8 [2];
  longlong *aplStackX_10 [3];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar6 = func_0x();
  lVar6 = -lVar6;
  *(undefined8 *)(&stack0x000006e0 + lVar6) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002b18 + lVar6) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar6);
  *(longlong *)(&stack0x00000268 + lVar6) = param_3;
  *(longlong *)(&stack0x00000370 + lVar6) = param_2;
  *(undefined8 *)(&stack0x00000380 + lVar6) = param_1;
  *(undefined (*) [16])(&stack0x00000298 + lVar6) = ZEXT816(0);
  plVar8 = (longlong *)0x0;
  *(undefined4 *)(&stack0x000002a8 + lVar6) = 0;
  *(undefined4 *)(&stack0x000000b8 + lVar6) = 0;
  *(undefined2 *)(&stack0x00000a20 + lVar6) = 0xffff;
  *(undefined8 *)(&stack0x00000a28 + lVar6) = 0;
  *(undefined4 *)(&stack0x00000a24 + lVar6) = 0;
  *(undefined8 *)(&stack0x00000a3e + lVar6) = 0;
  *(undefined8 *)(&stack0x00000a48 + lVar6) = 0;
  *(undefined8 *)(&stack0x00000a30 + lVar6) = 0;
  *(undefined4 *)(&stack0x00000a54 + lVar6) = 0xffffffff;
  *(undefined4 *)((longlong)auStackX_8 + lVar6) = 0;
  *(undefined4 *)(&stack0x000000bc + lVar6) = 1;
  uVar26 = *(undefined2 *)(param_3 + 0x3c4);
  *(undefined4 *)(&stack0x000000d8 + lVar6) = *(undefined4 *)(param_3 + 0x3c0);
  *(undefined2 *)(&stack0x000000dc + lVar6) = uVar26;
  *(undefined2 *)(&stack0x000000de + lVar6) = 0;
  lVar18 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar11 = *(longlong *)(lVar18 + 0x100);
  if (lVar11 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x10011c;
    (*_DAT_)(0);
    lVar11 = *(longlong *)(lVar18 + 0x100);
  }
  *(undefined8 *)(&stack0x000002b0 + lVar6) = *(undefined8 *)(lVar11 + 1000);
  *(longlong *)(&stack0x000002b8 + lVar6) = param_2;
  *(undefined8 *)(&stack0x000002c0 + lVar6) = 0;
  (&stack0x000002c8)[lVar6] = 0;
  if ((*(int *)(&stack0x000000d8 + lVar6) != 0) ||
     (plVar7 = plVar8, *(short *)(&stack0x000000dc + lVar6) != 0)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100171;
    plVar16 = (longlong *)func_0x(&stack0x000002b0 + lVar6);
    *(longlong **)(&stack0x000006e8 + lVar6) = plVar16;
    UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar16 + 0x18);
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100191;
    lVar11 = (*UNRECOVERED_JUMPTABLE_00)(plVar16,&stack0x000000d8 + lVar6,0);
    plVar7 = (longlong *)(lVar11 + 8);
    if (lVar11 == 0) {
      plVar7 = plVar8;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1001aa;
    lVar11 = func_0x(&stack0x000002b0 + lVar6,plVar7);
    plVar7 = (longlong *)(lVar11 + -8);
    if (lVar11 == 0) {
      plVar7 = plVar8;
    }
    UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar16 + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1001c2;
    (*UNRECOVERED_JUMPTABLE_00)(plVar16,1);
  }
  UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar7 + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1001d3;
  (*UNRECOVERED_JUMPTABLE_00)(plVar7,&stack0x00000ad0 + lVar6);
  *(undefined4 *)(&stack0x0000005c + lVar6) = *(undefined4 *)(&stack0x00000ad2 + lVar6);
  *(undefined2 *)(&stack0x00000060 + lVar6) = *(undefined2 *)(&stack0x00000ad6 + lVar6);
  *(undefined4 *)(&stack0x000001c8 + lVar6) = 0x654;
  lVar18 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar11 = *(longlong *)(lVar18 + 0x100);
  if (lVar11 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x10022f;
    (*_DAT_)(0);
    lVar11 = *(longlong *)(lVar18 + 0x100);
  }
  uVar10 = *(undefined8 *)(lVar11 + 1000);
  *(undefined8 *)(&stack0x00000278 + lVar6) = uVar10;
  (&stack0xffffffffffffffe8)[lVar6] = 5;
  *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100262;
  plVar7 = (longlong *)(*_DAT_)(0x18,uVar10,0x1114f78,0x654);
  *(longlong **)((longlong)aplStackX_10 + lVar6 + 0x10) = plVar7;
  *(longlong **)(&stack0x00000218 + lVar6) = plVar7;
  if (plVar7 == (longlong *)0x0) {
    *(undefined8 *)((longlong)aplStackX_10 + lVar6 + 0x10) = 0;
    plVar7 = plVar8;
  }
  else {
    *plVar7 = 0;
    *(undefined *)(plVar7 + 1) = 0;
    *(undefined4 *)((longlong)plVar7 + 0xc) = 0;
  }
  *(longlong **)((longlong)aplStackX_10 + lVar6) = plVar7;
  lVar11 = *(longlong *)(param_2 + 0x30);
  *(longlong *)(&stack0x00000050 + lVar6) = lVar11;
  *(undefined4 *)(&stack0x00000744 + lVar6) = 0;
  *(undefined4 *)(&stack0x00000748 + lVar6) = 0;
  cVar4 = *_DAT_;
  (&stack0x000000d0)[lVar6] = cVar4;
  if ((cVar4 == '\0') || ((&stack0x000000d1)[lVar6] = DAT_ >> 7, (char)DAT_ < '\0'))
  {
LAB_:
    pplVar22 = *(longlong ***)((longlong)aplStackX_10 + lVar6 + 0x10);
    goto LAB_;
  }
  *(undefined4 *)(&stack0x00000204 + lVar6) = 0;
  lVar11 = *(longlong *)(unaff_GS_OFFSET + 0x58);
  *(longlong *)(&stack0x000006f0 + lVar6) = lVar11;
  plVar7 = (longlong *)
           ((ulonglong)*_DAT_ + *(longlong *)(lVar11 + (ulonglong)*_DAT_ * 8));
  *(longlong **)(&stack0x000006f8 + lVar6) = plVar7;
  lVar11 = *plVar7;
  *(longlong *)(&stack0x00000700 + lVar6) = lVar11;
  if (lVar11 == 0) {
LAB_:
    *(undefined8 *)(&stack0x00000330 + lVar6) = 0;
  }
  else {
    lVar11 = **(longlong **)(lVar11 + 0x38);
    *(longlong *)(&stack0x00000708 + lVar6) = lVar11;
    if (lVar11 == 0) goto LAB_;
    *(longlong *)(&stack0x00000330 + lVar6) = lVar11;
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100355;
    iVar5 = (*_DAT_)(lVar11,0x337);
    *(int *)(&stack0x00000204 + lVar6) = iVar5;
    if (iVar5 != 0) {
      *(undefined8 *)((longlong)aplStackX_10 + lVar6 + 0x10) =
           *(undefined8 *)((longlong)aplStackX_10 + lVar6);
      lVar11 = *(longlong *)(&stack0x00000050 + lVar6);
      goto LAB_;
    }
  }
  lVar11 = *(longlong *)(unaff_GS_OFFSET + 0x58);
  *(longlong *)(&stack0x00000710 + lVar6) = lVar11;
  lVar11 = (ulonglong)*_DAT_ + *(longlong *)(lVar11 + (ulonglong)*_DAT_ * 8);
  *(longlong *)(&stack0x00000718 + lVar6) = lVar11;
  lVar18 = *(longlong *)(lVar11 + 8);
  *(longlong *)(&stack0x00000720 + lVar6) = lVar18;
  pplVar22 = *(longlong ***)((longlong)aplStackX_10 + lVar6);
  lVar11 = *(longlong *)(&stack0x00000050 + lVar6);
  *(longlong ***)((longlong)aplStackX_10 + lVar6 + 0x10) = pplVar22;
  if (lVar18 != 0) {
    plVar8 = *(longlong **)(lVar18 + 0x60);
  }
LAB_:
  *(longlong **)(&stack0x00000138 + lVar6) = plVar8;
  plVar8 = (longlong *)(lVar11 + 0x728);
  *(longlong *)(&stack0x00000278 + lVar6) = *plVar8;
  *(undefined **)(&stack0x00000218 + lVar6) = &stack0x00000740 + lVar6;
  do {
    *(undefined4 *)(&stack0x000000c0 + lVar6) = 0;
    if (*pplVar22 != (longlong *)0x0) {
      puVar9 = (ushort *)((longlong)*pplVar22 + 0x62);
      *(ushort **)(&stack0x00000728 + lVar6) = puVar9;
      uVar2 = *puVar9;
      *(ushort *)(&stack0x000000c8 + lVar6) = uVar2;
      pplVar22 = *(longlong ***)((longlong)aplStackX_10 + lVar6);
      if (((uVar2 & 0x400) == 0) ||
         (*(longlong ***)((longlong)aplStackX_10 + lVar6 + 0x10) = pplVar22,
         *(short *)((longlong)pplVar22 + 0xc) < 3)) {
        *(int *)(&stack0x00000038 + lVar6) = (int)*(short *)((longlong)pplVar22 + 0xc);
        plVar7 = *pplVar22;
        *(longlong **)(&stack0x00000100 + lVar6) = plVar7;
        puVar15 = (undefined2 *)((longlong)plVar7 + 0x62);
        *(undefined2 **)(&stack0x00000730 + lVar6) = puVar15;
        uVar26 = *puVar15;
        *(undefined2 *)(&stack0x00000080 + lVar6) = uVar26;
        if (((byte)uVar26 >> 3 & 1) != 0) {
          if (*(int *)(&stack0x00000038 + lVar6) == 3) {
            *(undefined4 *)(&stack0x00000038 + lVar6) = 4;
          }
          else if (*(int *)(&stack0x00000038 + lVar6) < 2) goto LAB_;
          *(uint **)(&stack0x00000738 + lVar6) =
               (uint *)(*(longlong *)(&stack0x00000100 + lVar6) + 100);
          uVar14 = *(uint *)(*(longlong *)(&stack0x00000100 + lVar6) + 100);
          *(uint *)(&stack0x00000208 + lVar6) = uVar14;
          if ((((uVar14 & 8) != 0) &&
              (lVar11 = *(longlong *)(*(longlong *)(&stack0x00000100 + lVar6) + 0x90), lVar11 != 0))
             && (*(longlong *)(&stack0x00000758 + lVar6) = lVar11,
                *(longlong *)(lVar11 + 0x758) != 0)) {
            uVar10 = *(undefined8 *)(lVar11 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100519;
            func_0x
                      (uVar10,*(undefined8 *)(&stack0x00000100 + lVar6),
                       *(undefined4 *)(&stack0x00000038 + lVar6));
          }
        }
LAB_:
        (&stack0x000000d2)[lVar6] = DAT_ >> 7;
        if ((char)DAT_ < '\0') {
          puVar19 = (uint *)(*(longlong *)(&stack0x00000100 + lVar6) + 100);
          *(uint **)(&stack0x000003e0 + lVar6) = puVar19;
          uVar14 = *puVar19;
          *(uint *)(&stack0x00000228 + lVar6) = uVar14;
          if (((uVar14 & 8) != 0) && (2 < *(int *)(&stack0x00000038 + lVar6))) {
            *(uint **)(&stack0x000003e8 + lVar6) = puVar19;
            uVar14 = *puVar19;
            *(uint *)(&stack0x00000230 + lVar6) = uVar14;
            if (((uVar14 & 0xc0000000) != 0x40000000) &&
               (lVar11 = **(longlong **)(&stack0x00000100 + lVar6), lVar11 != 0)) {
              *(undefined4 *)(&stack0x000003a8 + lVar6) = 2;
              *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1005a4;
              iVar5 = (*_DAT_)(lVar11,0x2000,2,&stack0x000003ac + lVar6);
              if (iVar5 != 0) {
                LOCK();
                *puVar19 = *puVar19 & 0x3fffffff;
                UNLOCK();
                LOCK();
                *puVar19 = *puVar19 | 0x40000000;
                UNLOCK();
              }
            }
          }
        }
        lVar11 = *(longlong *)(&stack0x00000100 + lVar6);
        uVar3 = *(undefined4 *)(&stack0x00000038 + lVar6);
        *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1005d0;
        func_0x(lVar11 + 0x98,uVar3);
        if ((_DAT_ != 0) &&
           ((&stack0x000000d3)[lVar6] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1005fa;
          func_0x(lVar11,0,uVar3);
        }
        *(uint *)((longlong)pplVar22 + 0xc) = *(uint *)((longlong)pplVar22 + 0xc) & 0xffff0000;
        pplVar22 = *(longlong ***)((longlong)aplStackX_10 + lVar6);
        *(longlong ***)((longlong)aplStackX_10 + lVar6 + 0x10) = pplVar22;
        *pplVar22 = (longlong *)0x0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100401;
        func_0x(pplVar22);
      }
      lVar11 = *(longlong *)(&stack0x00000050 + lVar6);
    }
    if (*plVar8 != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100638;
      func_0x(pplVar22,&stack0x0000005c + lVar6,lVar11);
      if (*pplVar22 != (longlong *)0x0) {
        puVar9 = (ushort *)((longlong)*pplVar22 + 0x62);
        *(ushort **)(&stack0x000003f0 + lVar6) = puVar9;
        uVar2 = *puVar9;
        *(ushort *)(&stack0x00000088 + lVar6) = uVar2;
        pplVar22 = *(longlong ***)((longlong)aplStackX_10 + lVar6);
        if (((uVar2 & 0x400) == 0) ||
           (*(longlong ***)((longlong)aplStackX_10 + lVar6 + 0x10) = pplVar22,
           *(short *)((longlong)pplVar22 + 0xc) < 3)) {
          *(int *)(&stack0x00000040 + lVar6) = (int)*(short *)((longlong)pplVar22 + 0xc);
          plVar7 = *pplVar22;
          *(longlong **)(&stack0x00000108 + lVar6) = plVar7;
          puVar15 = (undefined2 *)((longlong)plVar7 + 0x62);
          *(undefined2 **)(&stack0x000003f8 + lVar6) = puVar15;
          uVar26 = *puVar15;
          *(undefined2 *)(&stack0x00000090 + lVar6) = uVar26;
          if (((byte)uVar26 >> 3 & 1) != 0) {
            if (*(int *)(&stack0x00000040 + lVar6) == 3) {
              *(undefined4 *)(&stack0x00000040 + lVar6) = 4;
            }
            else if (*(int *)(&stack0x00000040 + lVar6) < 2) goto LAB_;
            *(uint **)(&stack0x00000400 + lVar6) =
                 (uint *)(*(longlong *)(&stack0x00000108 + lVar6) + 100);
            uVar14 = *(uint *)(*(longlong *)(&stack0x00000108 + lVar6) + 100);
            *(uint *)(&stack0x00000238 + lVar6) = uVar14;
            if ((((uVar14 & 8) != 0) &&
                (lVar11 = *(longlong *)(*(longlong *)(&stack0x00000108 + lVar6) + 0x90), lVar11 != 0
                )) && (*(longlong *)(&stack0x00000408 + lVar6) = lVar11,
                      *(longlong *)(lVar11 + 0x758) != 0)) {
              uVar10 = *(undefined8 *)(lVar11 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x10072b;
              func_0x
                        (uVar10,*(undefined8 *)(&stack0x00000108 + lVar6),
                         *(undefined4 *)(&stack0x00000040 + lVar6));
            }
          }
LAB_:
          (&stack0x000000d4)[lVar6] = DAT_ >> 7;
          if ((char)DAT_ < '\0') {
            puVar19 = (uint *)(*(longlong *)(&stack0x00000108 + lVar6) + 100);
            *(uint **)(&stack0x00000410 + lVar6) = puVar19;
            uVar14 = *puVar19;
            *(uint *)(&stack0x00000240 + lVar6) = uVar14;
            if (((uVar14 & 8) != 0) && (2 < *(int *)(&stack0x00000040 + lVar6))) {
              *(uint **)(&stack0x00000418 + lVar6) = puVar19;
              uVar14 = *puVar19;
              *(uint *)(&stack0x00000248 + lVar6) = uVar14;
              if (((uVar14 & 0xc0000000) != 0x40000000) &&
                 (lVar11 = **(longlong **)(&stack0x00000108 + lVar6), lVar11 != 0)) {
                *(undefined4 *)(&stack0x000003c4 + lVar6) = 2;
                *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1007b6;
                iVar5 = (*_DAT_)(lVar11,0x2000,2,&stack0x000002f0 + lVar6);
                if (iVar5 != 0) {
                  LOCK();
                  *puVar19 = *puVar19 & 0x3fffffff;
                  UNLOCK();
                  LOCK();
                  *puVar19 = *puVar19 | 0x40000000;
                  UNLOCK();
                }
              }
            }
          }
          lVar11 = *(longlong *)(&stack0x00000108 + lVar6);
          uVar3 = *(undefined4 *)(&stack0x00000040 + lVar6);
          *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1007e2;
          func_0x(lVar11 + 0x98,uVar3);
          if ((_DAT_ != 0) &&
             ((&stack0x000000d5)[lVar6] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x10080c;
            func_0x(lVar11,0,uVar3);
          }
          *(uint *)((longlong)pplVar22 + 0xc) = *(uint *)((longlong)pplVar22 + 0xc) & 0xffff0000;
          pplVar22 = *(longlong ***)((longlong)aplStackX_10 + lVar6);
          *(longlong ***)((longlong)aplStackX_10 + lVar6 + 0x10) = pplVar22;
          *pplVar22 = (longlong *)0x0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x10067a;
          func_0x(pplVar22);
        }
        lVar11 = *(longlong *)(&stack0x00000050 + lVar6);
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100838;
    func_0x(lVar11,&stack0x0000005c + lVar6);
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar6) = *(undefined8 *)(&stack0x00000218 + lVar6);
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar6) = 3;
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x10086c;
    plVar7 = (longlong *)
             func_0x
                       (_DAT_,lVar11,&stack0x0000005c + lVar6,&stack0x000000c0 + lVar6);
    *pplVar22 = plVar7;
    puVar19 = (uint *)((longlong)pplVar22 + 0xc);
    uVar14 = *puVar19 & 0xffff0003 | 3;
    *puVar19 = uVar14;
    if (*(longlong *)(&stack0x00000138 + lVar6) != 0) {
      lVar18 = **pplVar22;
      *(longlong *)(&stack0x00000420 + lVar6) = lVar18;
      plVar16 = (longlong *)(*(longlong *)(&stack0x00000138 + lVar6) + 0x500);
      *(longlong **)(&stack0x00000428 + lVar6) = plVar16;
      plVar7 = plVar16 + (ulonglong)(*(uint *)plVar16 & 0xf) + 1;
      *(longlong **)(&stack0x00000430 + lVar6) = plVar7;
      if (*plVar7 != lVar18) {
        *plVar7 = lVar18;
        *plVar16 = *plVar16 + 1;
        uVar14 = *puVar19;
      }
    }
    *puVar19 = (*(uint *)(&stack0x000000c0 + lVar6) >> 3 & 1) << 0x18 | uVar14 & 0xffffff;
    *(uint *)(pplVar22 + 2) =
         *(uint *)(&stack0x000000c0 + lVar6) >> 4 & 1 | *(uint *)(pplVar22 + 2) & 0xffffff00;
    lVar18 = *(longlong *)(&stack0x00000278 + lVar6);
    if (((lVar18 != 0) && (*(longlong *)(&stack0x00000138 + lVar6) != 0)) &&
       (*(longlong *)(&stack0x00000138 + lVar6) == *(longlong *)(lVar11 + 0x1c38))) {
      cVar4 = *(char *)((longlong)pplVar22 + 0xf);
      *(int *)(&stack0x000002f8 + lVar6) = (int)cVar4;
      *(longlong *)(&stack0x00000438 + lVar6) = lVar18 + 0x59b8;
      *(longlong *)(lVar18 + 0x5b28) = *(longlong *)(lVar18 + 0x5b28) + 1;
      puVar20 = *(uint **)(&stack0x00000218 + lVar6);
      if (puVar20[1] != 0) {
        *(longlong *)(lVar18 + 0x5b30) = *(longlong *)(lVar18 + 0x5b30) + 1;
        *(longlong *)(lVar18 + 0x5b38) = *(longlong *)(lVar18 + 0x5b38) + (ulonglong)*puVar20;
        if (cVar4 != '\0') {
          *(longlong *)(lVar18 + 0x5b40) = *(longlong *)(lVar18 + 0x5b40) + 1;
          *(longlong *)(lVar18 + 0x5b48) = *(longlong *)(lVar18 + 0x5b48) + (ulonglong)*puVar20;
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100982;
    cVar4 = func_0x(lVar11);
    if ((cVar4 == '\0') || (*(char *)(lVar11 + 0x2050) == '\0')) goto LAB_;
    if (*(int *)(&stack0x0000005c + lVar6) == 0) {
LAB_:
      (&stack0x0000002a)[lVar6] = 1;
      goto LAB_;
    }
    *(undefined4 *)(&stack0x000001c8 + lVar6) = 9;
    *(undefined2 *)(&stack0x000001cc + lVar6) = 1;
    if ((*(int *)(&stack0x0000005c + lVar6) == 9) && (*(short *)(&stack0x00000060 + lVar6) == 1))
    goto LAB_;
    (&stack0x0000002a)[lVar6] = 0;
    lVar18 = **pplVar22;
    *(longlong *)(&stack0x00000440 + lVar6) = lVar18;
    (&stack0x0000002c)[lVar6] = 0;
    if (*(short *)(lVar18 + 0x24) == 0) {
LAB_:
      *(undefined8 *)(&stack0x00000148 + lVar6) = *(undefined8 *)(lVar18 + 0x28);
      *(undefined2 *)(&stack0x00000150 + lVar6) = *(undefined2 *)(lVar18 + 0x30);
    }
    else {
      cVar4 = *(char *)(lVar18 + 1);
      if ((((cVar4 == '\v') || (cVar4 == '\b')) || (cVar4 == '\t')) &&
         (*(int *)(lVar18 + 0x18) == 99)) {
        *(undefined **)(&stack0x00000448 + lVar6) = &stack0x00000168 + lVar6;
        *(undefined4 **)(&stack0x00000450 + lVar6) = (undefined4 *)(lVar18 + 0x20);
        *(undefined4 *)(&stack0x00000168 + lVar6) = *(undefined4 *)(lVar18 + 0x20);
        *(undefined2 *)(&stack0x0000016c + lVar6) = *(undefined2 *)(lVar18 + 0x24);
        *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100a44;
        cVar4 = func_0x(&stack0x00000168 + lVar6);
        if (cVar4 == '\0') goto LAB_;
        cVar4 = '\x01';
      }
      else {
LAB_:
        cVar4 = '\0';
      }
      (&stack0x0000002c)[lVar6] = cVar4;
      if (cVar4 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100a66;
      func_0x(lVar18,&stack0x00000148 + lVar6);
    }
    *(undefined **)(&stack0x00000458 + lVar6) = &stack0x00000148 + lVar6;
    *(longlong *)(&stack0x00000340 + lVar6) = lVar11 + 0x20fc;
    *(undefined4 *)(&stack0x0000012c + lVar6) = 0;
    *(undefined4 *)(&stack0x00000130 + lVar6) = 0;
    *(undefined2 *)(&stack0x00000134 + lVar6) = 0;
    *(undefined2 *)(&stack0x00000136 + lVar6) = 0;
    puVar20 = (uint *)(lVar11 + 0x2108);
    *(uint **)(&stack0x00000460 + lVar6) = puVar20;
    uVar14 = *puVar20;
    *(uint *)(&stack0x0000011c + lVar6) = uVar14;
    *(uint **)(&stack0x00000348 + lVar6) = puVar20;
    do {
      *(uint *)(&stack0x00000250 + lVar6) = uVar14 & 0xfffffffe;
      *(undefined8 *)(&stack0x0000012c + lVar6) = **(undefined8 **)(&stack0x00000340 + lVar6);
      *(undefined4 *)(&stack0x00000134 + lVar6) =
           *(undefined4 *)(*(undefined8 **)(&stack0x00000340 + lVar6) + 1);
      LOCK();
      *(undefined4 *)(&stack0xffffffffffffffc8 + lVar6) =
           *(undefined4 *)(&stack0xffffffffffffffc8 + lVar6);
      UNLOCK();
      uVar14 = **(uint **)(&stack0x00000348 + lVar6);
      *(uint *)(&stack0x0000011c + lVar6) = uVar14;
    } while (*(uint *)(&stack0x00000250 + lVar6) != uVar14);
    if ((*(uint *)(&stack0x00000148 + lVar6) <= *(uint *)(&stack0x0000012c + lVar6)) &&
       ((*(uint *)(&stack0x0000012c + lVar6) != *(uint *)(&stack0x00000148 + lVar6) ||
        ((uVar14 = (uint)((ulonglong)*(undefined8 *)(&stack0x0000012c + lVar6) >> 0x20),
         *(uint *)(&stack0x0000014c + lVar6) <= uVar14 &&
         ((uVar14 != *(uint *)(&stack0x0000014c + lVar6) ||
          (*(ushort *)(&stack0x00000150 + lVar6) <= *(ushort *)(&stack0x00000134 + lVar6)))))))))
    break;
    if (*(char *)(*(longlong *)(&stack0x00000050 + lVar6) + 0x6ac8) == '\0') {
      lVar18 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      *(longlong *)(&stack0x00000468 + lVar6) = lVar18;
      lVar18 = (ulonglong)*_DAT_ + *(longlong *)(lVar18 + (ulonglong)*_DAT_ * 8);
      *(longlong *)(&stack0x00000470 + lVar6) = lVar18;
      lVar18 = *(longlong *)(lVar18 + 8);
      *(longlong *)(&stack0x00000478 + lVar6) = lVar18;
      lVar18 = *(longlong *)(lVar18 + 0x60);
      *(longlong *)(&stack0x00000480 + lVar6) = lVar18;
      if (lVar18 == *(longlong *)(*(longlong *)(&stack0x00000050 + lVar6) + 0x2120))
      goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100bfa;
      cVar4 = func_0x();
      if (cVar4 != '\0') goto LAB_;
      *(longlong *)(&stack0x00000280 + lVar6) = lVar11 + 0x20fc;
      *(undefined4 *)(&stack0x00000110 + lVar6) = 0;
      *(undefined4 *)(&stack0x00000114 + lVar6) = 0;
      *(undefined2 *)(&stack0x00000118 + lVar6) = 0;
      *(undefined2 *)(&stack0x0000011a + lVar6) = 0;
      *(uint **)(&stack0x00000488 + lVar6) = puVar20;
      uVar14 = *puVar20;
      *(uint *)(&stack0x00000144 + lVar6) = uVar14;
      puVar17 = *(undefined8 **)(&stack0x00000280 + lVar6);
      *(longlong *)(&stack0x00000220 + lVar6) = (longlong)puVar17 + 0xc;
      while( true ) {
        *(uint *)(&stack0x00000188 + lVar6) = uVar14 & 0xfffffffe;
        *(undefined8 *)(&stack0x00000110 + lVar6) = *puVar17;
        *(undefined4 *)(&stack0x00000118 + lVar6) = *(undefined4 *)(puVar17 + 1);
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar6) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar6);
        UNLOCK();
        uVar14 = **(uint **)(&stack0x00000220 + lVar6);
        *(uint *)(&stack0x00000144 + lVar6) = uVar14;
        if (*(uint *)(&stack0x00000188 + lVar6) == uVar14) break;
        puVar17 = *(undefined8 **)(&stack0x00000280 + lVar6);
      }
      *(undefined8 *)(&stack0x000002d0 + lVar6) = *(undefined8 *)(&stack0x00000110 + lVar6);
      uVar2 = *(ushort *)(&stack0x00000118 + lVar6);
      *(ushort *)(&stack0x000002d8 + lVar6) = uVar2;
      pplVar22 = *(longlong ***)((longlong)aplStackX_10 + lVar6);
      *(longlong ***)((longlong)aplStackX_10 + lVar6 + 0x10) = pplVar22;
      lVar11 = **pplVar22;
      (&stack0x00000028)[lVar6] = 0;
      if (*(short *)(lVar11 + 0x24) == 0) {
LAB_:
        *(undefined8 *)(&stack0x00000158 + lVar6) = *(undefined8 *)(lVar11 + 0x28);
        uVar25 = *(ushort *)(lVar11 + 0x30);
        *(ushort *)(&stack0x00000160 + lVar6) = uVar25;
      }
      else {
        cVar4 = *(char *)(lVar11 + 1);
        if ((((cVar4 == '\v') || (cVar4 == '\b')) || (cVar4 == '\t')) &&
           (*(int *)(lVar11 + 0x18) == 99)) {
          *(undefined **)(&stack0x00000490 + lVar6) = &stack0x00000170 + lVar6;
          *(undefined4 *)(&stack0x00000170 + lVar6) = *(undefined4 *)(lVar11 + 0x20);
          *(undefined2 *)(&stack0x00000174 + lVar6) = *(undefined2 *)(lVar11 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100d27;
          cVar4 = func_0x(&stack0x00000170 + lVar6);
          if (cVar4 == '\0') goto LAB_;
          cVar4 = '\x01';
        }
        else {
LAB_:
          cVar4 = '\0';
        }
        (&stack0x00000028)[lVar6] = cVar4;
        if (cVar4 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100d49;
        func_0x(lVar11,&stack0x00000158 + lVar6);
        uVar25 = *(ushort *)(&stack0x00000160 + lVar6);
      }
      if ((*(uint *)(&stack0x00000110 + lVar6) < *(uint *)(&stack0x00000158 + lVar6)) ||
         ((*(uint *)(&stack0x00000110 + lVar6) == *(uint *)(&stack0x00000158 + lVar6) &&
          ((uVar14 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000158 + lVar6) >> 0x20),
           *(uint *)(&stack0x00000114 + lVar6) < uVar14 ||
           ((*(uint *)(&stack0x00000114 + lVar6) == uVar14 && (uVar2 < uVar25)))))))) {
        lVar11 = *(longlong *)(&stack0x00000050 + lVar6);
        lVar18 = *(longlong *)(lVar11 + 0x6b0);
        *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100dd8;
        func_0x(&stack0x00000158 + lVar6,&stack0x00000b10 + lVar6,&stack0x0000018c + lVar6);
        *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x100df5;
        func_0x(&stack0x000002d0 + lVar6,&stack0x00000b40 + lVar6,&stack0x0000018c + lVar6);
        *(undefined4 *)(&stack0x00000220 + lVar6) = 0x1d;
        *(undefined4 *)(&stack0x00000224 + lVar6) = 0x10000;
        if ((_DAT_ & 0x10000) != 0) {
          *(undefined2 *)(&stack0x000001d0 + lVar6) = 6;
          *(undefined **)(&stack0x00000498 + lVar6) = &stack0x00000770 + lVar6;
          *(undefined2 *)(&stack0x00000770 + lVar6) = 0;
          *(undefined2 *)(&stack0x00000772 + lVar6) = 6;
          *(undefined4 *)(&stack0x00000778 + lVar6) = 0;
          *(undefined **)(&stack0x00000780 + lVar6) = &stack0x00000798 + lVar6;
          *(undefined **)(&stack0x00000788 + lVar6) = &stack0x000007f8 + lVar6;
          *(undefined4 *)(&stack0x000009b8 + lVar6) = 0;
          *(undefined4 *)(&stack0x000009bc + lVar6) = 0;
          *(undefined8 *)(&stack0x00000790 + lVar6) = 0;
          *(undefined8 *)(&stack0x000009c0 + lVar6) = 0;
          *(undefined **)(&stack0x000004a0 + lVar6) = &stack0x00000798 + lVar6;
          *(undefined **)(&stack0x00000798 + lVar6) = &stack0x000009c8 + lVar6;
          *(undefined4 *)(&stack0x000007a0 + lVar6) = 0x34;
          *(undefined2 *)(&stack0x000007a4 + lVar6) = 5;
          *(undefined2 *)(&stack0x000007a6 + lVar6) = 0;
          *(undefined **)(&stack0x000004a8 + lVar6) = &stack0x000007a8 + lVar6;
          *(undefined8 *)(&stack0x000007a8 + lVar6) = 0xfd4ef8;
          *(undefined4 *)(&stack0x000007b0 + lVar6) = 0x10;
          *(undefined2 *)(&stack0x000007b4 + lVar6) = 5;
          *(undefined2 *)(&stack0x000007b6 + lVar6) = 0;
          *(undefined **)(&stack0x000004b0 + lVar6) = &stack0x000007b8 + lVar6;
          *(undefined8 *)(&stack0x000007b8 + lVar6) = 0xfd4ef8;
          *(undefined4 *)(&stack0x000007c0 + lVar6) = 0x10;
          *(undefined2 *)(&stack0x000007c4 + lVar6) = 6;
          *(undefined2 *)(&stack0x000007c6 + lVar6) = 0;
          *(undefined **)(&stack0x000004b8 + lVar6) = &stack0x000007c8 + lVar6;
          *(undefined8 *)(&stack0x000007c8 + lVar6) = 0;
          *(undefined4 *)(&stack0x000007d0 + lVar6) = 0;
          *(undefined2 *)(&stack0x000007d4 + lVar6) = 7;
          *(undefined2 *)(&stack0x000007d6 + lVar6) = 0;
          *(undefined **)(&stack0x000004c0 + lVar6) = &stack0x000007d8 + lVar6;
          *(undefined8 *)(&stack0x000007d8 + lVar6) = 0;
          *(undefined4 *)(&stack0x000007e0 + lVar6) = 0;
          *(undefined2 *)(&stack0x000007e4 + lVar6) = 8;
          *(undefined2 *)(&stack0x000007e6 + lVar6) = 0;
          *(undefined **)(&stack0x000004c8 + lVar6) = &stack0x000007e8 + lVar6;
          *(undefined8 *)(&stack0x000007e8 + lVar6) = 0;
          *(undefined4 *)(&stack0x000007f0 + lVar6) = 0;
          *(undefined2 *)(&stack0x000007f4 + lVar6) = 9;
          *(undefined2 *)(&stack0x000007f6 + lVar6) = 0;
          *(uint *)(&stack0x000009c8 + lVar6) = (uint)*(ushort *)(lVar11 + 0x6b8);
          *(undefined2 *)(&stack0x000009cc + lVar6) = *(undefined2 *)(&stack0x00000060 + lVar6);
          *(undefined4 *)(&stack0x000009ce + lVar6) = *(undefined4 *)(&stack0x0000005c + lVar6);
          (&stack0x000009d2)[lVar6] = 1;
          (&stack0x000009d3)[lVar6] = *(undefined *)(**pplVar22 + 1);
          *(undefined **)(&stack0x000004d0 + lVar6) = &stack0x000007a8 + lVar6;
          *(longlong *)(&stack0x000007a8 + lVar6) = lVar18 + 0x254;
          *(undefined4 *)(&stack0x000007b0 + lVar6) = 0x10;
          *(undefined2 *)(&stack0x000007b4 + lVar6) = 5;
          *(undefined2 *)(&stack0x000007b6 + lVar6) = 0;
          *(undefined **)(&stack0x000004d8 + lVar6) = &stack0x000007b8 + lVar6;
          *(longlong *)(&stack0x000007b8 + lVar6) = lVar18 + 0x244;
          *(undefined4 *)(&stack0x000007c0 + lVar6) = 0x10;
          *(undefined2 *)(&stack0x000007c4 + lVar6) = 6;
          *(undefined2 *)(&stack0x000007c6 + lVar6) = 0;
          *(undefined **)(&stack0x000004e0 + lVar6) = &stack0x00000b10 + lVar6;
          lVar11 = -1;
          do {
            lVar11 = lVar11 + 1;
          } while (*(short *)(&stack0x00000b10 + lVar11 * 2 + lVar6) != 0);
          iVar5 = (int)lVar11 * 2;
          *(int *)(&stack0x00000300 + lVar6) = iVar5;
          *(undefined **)(&stack0x000004e8 + lVar6) = &stack0x000007c8 + lVar6;
          *(undefined **)(&stack0x000007c8 + lVar6) = &stack0x00000b10 + lVar6;
          *(int *)(&stack0x000007d0 + lVar6) = iVar5;
          *(undefined2 *)(&stack0x000007d4 + lVar6) = 7;
          *(undefined2 *)(&stack0x000007d6 + lVar6) = 0;
          *(undefined **)(&stack0x000004f0 + lVar6) = &stack0x00000b40 + lVar6;
          lVar11 = -1;
          do {
            lVar11 = lVar11 + 1;
          } while (*(short *)(&stack0x00000b40 + lVar11 * 2 + lVar6) != 0);
          iVar5 = (int)lVar11 * 2;
          *(int *)(&stack0x00000304 + lVar6) = iVar5;
          *(undefined **)(&stack0x000004f8 + lVar6) = &stack0x000007d8 + lVar6;
          *(undefined **)(&stack0x000007d8 + lVar6) = &stack0x00000b40 + lVar6;
          *(int *)(&stack0x000007e0 + lVar6) = iVar5;
          *(undefined2 *)(&stack0x000007e4 + lVar6) = 8;
          *(undefined2 *)(&stack0x000007e6 + lVar6) = 0;
          *(undefined4 *)(&stack0x00000190 + lVar6) = 0;
          UNRECOVERED_JUMPTABLE_00 = *(code **)(_DAT_ + 0x10);
          *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1011a8;
          lVar11 = (*UNRECOVERED_JUMPTABLE_00)(lVar18,&stack0x00000190 + lVar6);
          iVar5 = 0;
          if (lVar11 != 0) {
            lVar18 = -1;
            do {
              lVar18 = lVar18 + 1;
            } while (*(short *)(lVar11 + lVar18 * 2) != 0);
            iVar5 = (int)lVar18 * 2;
          }
          *(int *)(&stack0x00000308 + lVar6) = iVar5;
          lVar18 = *(longlong *)(&stack0x00000780 + lVar6);
          *(longlong *)(lVar18 + 0x50) = lVar11;
          *(int *)(lVar18 + 0x58) = iVar5;
          *(undefined2 *)(lVar18 + 0x5c) = 9;
          *(undefined2 *)(lVar18 + 0x5e) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1011f5;
          func_0x(&stack0x00000768 + lVar6);
        }
      }
      goto LAB_;
    }
LAB_:
    lVar11 = *(longlong *)(unaff_GS_OFFSET + 0x58);
    *(longlong *)(&stack0x00000500 + lVar6) = lVar11;
    lVar11 = (ulonglong)*_DAT_ + *(longlong *)(lVar11 + (ulonglong)*_DAT_ * 8);
    *(longlong *)(&stack0x00000508 + lVar6) = lVar11;
    lVar11 = *(longlong *)(lVar11 + 8);
    *(longlong *)(&stack0x00000510 + lVar6) = lVar11;
    lVar18 = *(longlong *)(lVar11 + 0x60);
    *(longlong *)(&stack0x00000518 + lVar6) = lVar18;
    lVar11 = *(longlong *)(&stack0x00000050 + lVar6);
    if (lVar18 == *(longlong *)(lVar11 + 0x2120)) break;
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x10125e;
    cVar4 = func_0x(lVar11);
    if (cVar4 != '\0') break;
    if (*(longlong *)(&stack0x00000138 + lVar6) == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x101276;
      uVar10 = func_0x();
      *(undefined8 *)(&stack0x00000138 + lVar6) = uVar10;
    }
    *(undefined **)(&stack0x00000520 + lVar6) = &stack0x00000068 + lVar6;
    pplVar22 = *(longlong ***)((longlong)aplStackX_10 + lVar6);
    *(longlong ***)((longlong)aplStackX_10 + lVar6 + 0x10) = pplVar22;
    lVar18 = **pplVar22;
    *(longlong *)(&stack0x00000528 + lVar6) = lVar18;
    (&stack0x00000029)[lVar6] = 0;
    if (*(short *)(lVar18 + 0x24) == 0) {
LAB_:
      uVar10 = *(undefined8 *)(lVar18 + 0x28);
      *(undefined8 *)(&stack0x00000068 + lVar6) = uVar10;
      uVar26 = *(undefined2 *)(lVar18 + 0x30);
      *(undefined2 *)(&stack0x00000070 + lVar6) = uVar26;
    }
    else {
      cVar4 = *(char *)(lVar18 + 1);
      if ((((cVar4 == '\v') || (cVar4 == '\b')) || (cVar4 == '\t')) &&
         (*(int *)(lVar18 + 0x18) == 99)) {
        *(undefined **)(&stack0x00000530 + lVar6) = &stack0x00000178 + lVar6;
        *(undefined4 **)(&stack0x00000538 + lVar6) = (undefined4 *)(lVar18 + 0x20);
        *(undefined4 *)(&stack0x00000178 + lVar6) = *(undefined4 *)(lVar18 + 0x20);
        *(undefined2 *)(&stack0x0000017c + lVar6) = *(undefined2 *)(lVar18 + 0x24);
        *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x10130d;
        cVar4 = func_0x(&stack0x00000178 + lVar6);
        if (cVar4 == '\0') goto LAB_;
        cVar4 = '\x01';
      }
      else {
LAB_:
        cVar4 = '\0';
      }
      (&stack0x00000029)[lVar6] = cVar4;
      if (cVar4 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x10132f;
      func_0x(lVar18,&stack0x00000068 + lVar6);
      uVar26 = *(undefined2 *)(&stack0x00000070 + lVar6);
      uVar10 = *(undefined8 *)(&stack0x00000068 + lVar6);
    }
    *(undefined **)(&stack0x00000540 + lVar6) = &stack0x00000068 + lVar6;
    *(undefined8 *)(&stack0x000003b8 + lVar6) = uVar10;
    *(undefined2 *)(&stack0x000003c0 + lVar6) = uVar26;
    *(undefined2 *)(&stack0x000003c2 + lVar6) = 0;
    if (*pplVar22 != (longlong *)0x0) {
      puVar9 = (ushort *)((longlong)*pplVar22 + 0x62);
      *(ushort **)(&stack0x00000548 + lVar6) = puVar9;
      uVar2 = *puVar9;
      *(ushort *)(&stack0x00000098 + lVar6) = uVar2;
      if (((uVar2 & 0x400) == 0) || (*(short *)puVar19 < 3)) {
        *(int *)(&stack0x00000048 + lVar6) = (int)*(short *)puVar19;
        lVar11 = **(longlong **)((longlong)aplStackX_10 + lVar6);
        *(longlong *)(&stack0x000000f8 + lVar6) = lVar11;
        puVar15 = (undefined2 *)(lVar11 + 0x62);
        *(undefined2 **)(&stack0x00000550 + lVar6) = puVar15;
        uVar26 = *puVar15;
        *(undefined2 *)(&stack0x000000a0 + lVar6) = uVar26;
        if (((byte)uVar26 >> 3 & 1) != 0) {
          if (*(int *)(&stack0x00000048 + lVar6) == 3) {
            *(undefined4 *)(&stack0x00000048 + lVar6) = 4;
          }
          else if (*(int *)(&stack0x00000048 + lVar6) < 2) goto LAB_;
          *(uint **)(&stack0x00000558 + lVar6) =
               (uint *)(*(longlong *)(&stack0x000000f8 + lVar6) + 100);
          uVar14 = *(uint *)(*(longlong *)(&stack0x000000f8 + lVar6) + 100);
          *(uint *)(&stack0x00000198 + lVar6) = uVar14;
          if ((((uVar14 & 8) != 0) &&
              (lVar11 = *(longlong *)(*(longlong *)(&stack0x000000f8 + lVar6) + 0x90), lVar11 != 0))
             && (*(longlong *)(&stack0x00000560 + lVar6) = lVar11,
                *(longlong *)(lVar11 + 0x758) != 0)) {
            uVar10 = *(undefined8 *)(lVar11 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x101494;
            func_0x
                      (uVar10,*(undefined8 *)(&stack0x000000f8 + lVar6),
                       *(undefined4 *)(&stack0x00000048 + lVar6));
          }
        }
LAB_:
        (&stack0x000000d6)[lVar6] = DAT_ >> 7;
        if ((char)DAT_ < '\0') {
          puVar20 = (uint *)(*(longlong *)(&stack0x000000f8 + lVar6) + 100);
          *(uint **)(&stack0x00000568 + lVar6) = puVar20;
          uVar14 = *puVar20;
          *(uint *)(&stack0x000001a0 + lVar6) = uVar14;
          if (((uVar14 & 8) != 0) && (2 < *(int *)(&stack0x00000048 + lVar6))) {
            *(uint **)(&stack0x00000570 + lVar6) = puVar20;
            uVar14 = *puVar20;
            *(uint *)(&stack0x000001a8 + lVar6) = uVar14;
            if (((uVar14 & 0xc0000000) != 0x40000000) &&
               (lVar11 = **(longlong **)(&stack0x000000f8 + lVar6), lVar11 != 0)) {
              *(undefined4 *)(&stack0x0000030c + lVar6) = 2;
              *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x101527;
              iVar5 = (*_DAT_)(lVar11,0x2000,2,&stack0x00000310 + lVar6);
              if (iVar5 != 0) {
                LOCK();
                *puVar20 = *puVar20 & 0x3fffffff;
                UNLOCK();
                LOCK();
                *puVar20 = *puVar20 | 0x40000000;
                UNLOCK();
              }
            }
          }
        }
        lVar11 = *(longlong *)(&stack0x000000f8 + lVar6);
        uVar3 = *(undefined4 *)(&stack0x00000048 + lVar6);
        *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x101556;
        func_0x(lVar11 + 0x98,uVar3);
        if ((_DAT_ != 0) &&
           ((&stack0x000000e0)[lVar6] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x101580;
          func_0x(lVar11,0,uVar3);
        }
        *puVar19 = *puVar19 & 0xffff0000;
        pplVar22 = *(longlong ***)((longlong)aplStackX_10 + lVar6);
        *(longlong ***)((longlong)aplStackX_10 + lVar6 + 0x10) = pplVar22;
        *pplVar22 = (longlong *)0x0;
      }
      else {
        pplVar22 = *(longlong ***)((longlong)aplStackX_10 + lVar6);
        *(longlong ***)((longlong)aplStackX_10 + lVar6 + 0x10) = pplVar22;
        *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1013cc;
        func_0x(pplVar22);
      }
      uVar10 = *(undefined8 *)(&stack0x00000068 + lVar6);
      uVar26 = *(undefined2 *)(&stack0x00000070 + lVar6);
      lVar11 = *(longlong *)(&stack0x00000050 + lVar6);
    }
    *(undefined **)(&stack0x00000578 + lVar6) = &stack0x000002e0 + lVar6;
    *(undefined8 *)(&stack0x000002e0 + lVar6) = uVar10;
    *(undefined2 *)(&stack0x000002e8 + lVar6) = uVar26;
    *(undefined **)(&stack0x00000580 + lVar6) = &stack0x00000258 + lVar6;
    *(undefined8 *)(&stack0x00000258 + lVar6) = uVar10;
    *(undefined2 *)(&stack0x00000260 + lVar6) = uVar26;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar6) = 0;
    lVar18 = *plVar8;
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x10160f;
    func_0x(lVar18,&stack0x00000258 + lVar6,4);
  } while( true );
  pplVar22 = *(longlong ***)((longlong)aplStackX_10 + lVar6);
  *(longlong ***)((longlong)aplStackX_10 + lVar6 + 0x10) = pplVar22;
LAB_:
  if ((1 < *(short *)((longlong)pplVar22 + 0xc)) && (*(char *)(**pplVar22 + 1) != '\x01')) {
    if (*(longlong *)(&stack0x00000138 + lVar6) != 0) {
      *(longlong *)(*(longlong *)(&stack0x00000138 + lVar6) + 0x588) = **pplVar22;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x10164a;
    lVar11 = func_0x();
    if (lVar11 == 0) {
LAB_:
      *(undefined4 *)(&stack0x000001b0 + lVar6) = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x101654;
      lVar11 = func_0x();
      if (*(longlong *)(lVar11 + 0x30) == 0) goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x101660;
      lVar11 = func_0x();
      uVar14 = *(uint *)(*(longlong *)(lVar11 + 0x30) + 0xc);
      *(uint *)(&stack0x00000314 + lVar6) = uVar14;
      if ((0xd < uVar14) || (iVar5 = 1, (0x2640U >> (uVar14 & 0x1f) & 1) == 0)) {
        iVar5 = 0;
      }
      *(int *)(&stack0x000001b0 + lVar6) = iVar5;
      if (iVar5 != 0) goto LAB_;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1016a1;
    func_0x(0,8);
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1016be;
  func_0x
            (&stack0x000002b0 + lVar6,&stack0x000000d8 + lVar6,&stack0x00000b00 + lVar6);
  lVar11 = **pplVar22;
  if (lVar11 == 0) {
    *(undefined (*) [16])(&stack0x00000298 + lVar6) = ZEXT816(0);
  }
  else {
    *(longlong *)(&stack0x00000298 + lVar6) = lVar11;
    *(longlong *)(&stack0x000002a0 + lVar6) = lVar11 + 0x2000;
  }
  *(undefined4 *)(&stack0x000002a8 + lVar6) = 0;
  lVar11 = -0x16f6410;
  *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x101717;
  uVar12 = func_0x(&stack0x00000298 + lVar6);
  if (uVar12 == 0) {
    lVar18 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar11 = *(longlong *)(lVar18 + 0x100);
    if (lVar11 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x10329d;
      (*_DAT_)();
      lVar11 = *(longlong *)(lVar18 + 0x100);
    }
    if (*(int *)(lVar11 + 0x22c) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1032b3;
      (*_DAT_)();
    }
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar6) = 0x126f2f0;
    uVar12 = 0x1232d7c;
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x1032dc;
    (*_DAT_)(1,0x1232d7c,0x122ed98,0x6ba);
    lVar11 = *(longlong *)(&stack0x000002c0 + lVar6);
    if (lVar11 != 0) {
      *(undefined8 *)(&stack0x00000388 + lVar6) = 0xe4c858;
      if (*(int *)(lVar11 + 8) != 0) {
        uVar12 = uVar12 & 0xffffffffffffff00;
        for (uVar14 = *(int *)(lVar11 + 8) - 1; uVar14 != 0; uVar14 = uVar14 >> 3) {
          uVar12 = CONCAT71((int7)(uVar12 >> 8),(char)uVar12 + '\x03');
        }
        *(undefined4 *)(lVar11 + 8) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x10332e;
        func_0x(lVar11,uVar12,&stack0x00000388 + lVar6);
        lVar11 = *(longlong *)(&stack0x000002c0 + lVar6);
      }
      if (lVar11 != 0) {
        if (*(int *)(lVar11 + 8) != 0) {
          uVar12 = uVar12 & 0xffffffffffffff00;
          for (uVar14 = *(int *)(lVar11 + 8) - 1; uVar14 != 0; uVar14 = uVar14 >> 3) {
            uVar12 = CONCAT71((int7)(uVar12 >> 8),(char)uVar12 + '\x03');
          }
          *(undefined4 *)(lVar11 + 8) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x103369;
          func_0x(lVar11,uVar12,0);
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x10337e;
        (*_DAT_)(lVar11,0x10);
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x10338e;
    func_0x
              (*(ulonglong *)(&stack0x00002b18 + lVar6) ^
               (ulonglong)(&stack0xffffffffffffffc8 + lVar6));
    return;
  }
  uVar21 = uVar12 & 0xffffffffffffe000;
  *(ulonglong *)(&stack0x00000588 + lVar6) = uVar21;
  iVar5 = (int)((longlong)((uVar21 - uVar12) + 0x1ffe) >> 1);
  *(int *)(&stack0x00000a54 + lVar6) = iVar5;
  if (-1 < *(char *)(uVar21 + 2)) {
    *(undefined8 *)(&stack0x00000210 + lVar6) = 0;
    goto LAB_;
  }
  pbVar24 = (byte *)(uVar21 + 0x60);
  if (*(short *)(&stack0x00000a20 + lVar6) == 0) {
    *(undefined8 *)(&stack0x00000210 + lVar6) = 0;
LAB_:
    *(undefined **)(&stack0x00000590 + lVar6) = &stack0x00000a58 + lVar6;
    *(undefined (*) [16])(&stack0x00000a58 + lVar6) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00000a68 + lVar6) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00000a78 + lVar6) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00000a88 + lVar6) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00000a98 + lVar6) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00000aa8 + lVar6) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00000ab8 + lVar6) = ZEXT816(0);
    *(undefined8 *)(&stack0x00000ac8 + lVar6) = 0;
    *(undefined **)(&stack0x00000598 + lVar6) = &stack0x00000a58 + lVar6;
    *(undefined (*) [16])(&stack0x00000a58 + lVar6) = ZEXT816(0);
    *(undefined **)(&stack0x000005a0 + lVar6) = &stack0x00000a68 + lVar6;
    *(undefined2 *)(&stack0x00000a68 + lVar6) = 0xffff;
    *(undefined8 *)(&stack0x00000a70 + lVar6) = 0;
    *(undefined4 *)(&stack0x00000a6c + lVar6) = 0;
    *(undefined8 *)(&stack0x00000a86 + lVar6) = 0;
    *(undefined8 *)(&stack0x00000a90 + lVar6) = 0;
    *(undefined8 *)(&stack0x00000a78 + lVar6) = 0;
    *(undefined **)(&stack0x000005a8 + lVar6) = &stack0x00000aa0 + lVar6;
    *(undefined8 *)(&stack0x00000aa0 + lVar6) = 0;
    *(undefined **)(&stack0x000005b0 + lVar6) = &stack0x00000ab8 + lVar6;
    *(undefined4 *)(&stack0x00000ab8 + lVar6) = 0;
    *(undefined4 *)(&stack0x00000abc + lVar6) = 0;
    *(undefined2 *)(&stack0x00000ac0 + lVar6) = 0;
    *(undefined2 *)(&stack0x00000ac2 + lVar6) = 0;
    *(undefined **)(&stack0x000005b8 + lVar6) = &stack0x00000ac4 + lVar6;
    *(undefined2 *)(&stack0x00000aca + lVar6) = 0;
    ppbVar23 = (byte **)(&stack0x00000a58 + lVar6);
    *(byte ***)(&stack0x00000210 + lVar6) = ppbVar23;
  }
  else {
    ppbVar23 = *(byte ***)(&stack0x00000a30 + lVar6);
    *(byte ***)(&stack0x00000210 + lVar6) = ppbVar23;
    if (ppbVar23 == (byte **)0x0) goto LAB_;
  }
  (&stack0x0000002b)[lVar6] = 0;
  if (*(short *)(uVar21 + 0x24) == 0) {
LAB_:
    *(undefined8 *)(&stack0x000000e8 + lVar6) = *(undefined8 *)(uVar21 + 0x28);
    sVar27 = *(short *)(uVar21 + 0x30);
    *(short *)(&stack0x000000f0 + lVar6) = sVar27;
  }
  else {
    cVar4 = *(char *)(uVar21 + 1);
    if ((((cVar4 == '\v') || (cVar4 == '\b')) || (cVar4 == '\t')) && (*(int *)(uVar21 + 0x18) == 99)
       ) {
      *(undefined **)(&stack0x000005c0 + lVar6) = &stack0x00000180 + lVar6;
      *(undefined4 *)(&stack0x00000180 + lVar6) = *(undefined4 *)(uVar21 + 0x20);
      *(undefined2 *)(&stack0x00000184 + lVar6) = *(undefined2 *)(uVar21 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x101914;
      cVar4 = func_0x(&stack0x00000180 + lVar6);
      if (cVar4 == '\0') goto LAB_;
      cVar4 = '\x01';
    }
    else {
LAB_:
      cVar4 = '\0';
    }
    (&stack0x0000002b)[lVar6] = cVar4;
    if (cVar4 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x101936;
    func_0x(uVar21,&stack0x000000e8 + lVar6);
    sVar27 = *(short *)(&stack0x000000f0 + lVar6);
  }
  *(undefined **)(&stack0x000005c8 + lVar6) = &stack0x000000e8 + lVar6;
  *(byte ***)(&stack0x000005d0 + lVar6) = ppbVar23;
  if (((pbVar24 == *ppbVar23) && (sVar27 == *(short *)(ppbVar23 + 0xd))) &&
     ((*(int *)(&stack0x000000e8 + lVar6) == *(int *)(ppbVar23 + 0xc) &&
      (*(int *)(&stack0x000000ec + lVar6) == *(int *)((longlong)ppbVar23 + 100))))) {
    *(longlong *)(&stack0x000005d8 + lVar6) = (longlong)ppbVar23 + 0x6c;
  }
  *ppbVar23 = pbVar24;
  uVar26 = *(undefined2 *)(&stack0x000000f0 + lVar6);
  uVar3 = *(undefined4 *)(&stack0x000000ec + lVar6);
  *(undefined4 *)(&stack0x00000318 + lVar6) = *(undefined4 *)(&stack0x000000e8 + lVar6);
  *(undefined4 *)(ppbVar23 + 0xc) = *(undefined4 *)(&stack0x000000e8 + lVar6);
  *(undefined4 *)((longlong)ppbVar23 + 100) = uVar3;
  *(undefined2 *)(ppbVar23 + 0xd) = uVar26;
  *(undefined4 *)((longlong)ppbVar23 + 0x6c) = *(undefined4 *)(uVar21 + 0x20);
  *(undefined2 *)(ppbVar23 + 0xe) = *(undefined2 *)(uVar21 + 0x24);
  *(undefined2 *)((longlong)ppbVar23 + 0x72) = 0;
  uVar12 = (ulonglong)*pbVar24;
  *(ushort *)(&stack0x000001d8 + lVar6) = (ushort)*pbVar24;
  *(undefined4 *)(&stack0x00000288 + lVar6) = *(undefined4 *)(uVar12 * 6 + 0xea2a00);
  *(undefined2 *)(&stack0x0000028c + lVar6) = *(undefined2 *)(uVar12 * 6 + 0xea2a04);
  *(undefined4 *)(&stack0x00000290 + lVar6) = *(undefined4 *)(uVar12 * 6 + 0xea2a00);
  uVar12 = (ulonglong)*(short *)(uVar12 * 6 + 0xea2a04);
  *(undefined2 *)(ppbVar23 + 2) = 0xffff;
  ppbVar23[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar23 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar23 + 0x2e) = 0;
  ppbVar23[7] = (byte *)0x0;
  ppbVar23[4] = (byte *)0x0;
  ppbVar23[9] = (byte *)0x0;
  ppbVar23[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar23 + 0xb) = 0;
  if ((**ppbVar23 & 2) != 0) {
    pbVar24 = pbVar24 + uVar12;
    bVar1 = *pbVar24;
    *(ushort *)(ppbVar23 + 2) = (ushort)(bVar1 & 1);
    if ((bVar1 & 1) != 0) {
      ppbVar23[3] = pbVar24;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar24 & 0x1c) + 0x1033f0) * 4
                             + 0x1033e0) - 0x16f6410);
                    /* WARNING: Could not emulate address calculation at 0x00101b69 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
    *(undefined4 *)(&stack0x000000a8 + lVar6) = 0;
    ppbVar23[3] = pbVar24;
    *(undefined4 *)((longlong)ppbVar23 + 0x14) = 0;
    *(undefined4 *)((longlong)ppbVar23 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101aa5 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*ppbVar23[3] & 0xe) * 4 + 0x1033a4) - 0x16f6410)
    )();
    return;
  }
  if ((**ppbVar23 & 4) != 0) {
    if (*(short *)(&stack0x00000292 + lVar6) != 0) {
      uVar12 = (ulonglong)
               *(ushort *)(uVar21 + 0x61 + (longlong)*(short *)(&stack0x00000292 + lVar6) * 2);
    }
    psVar13 = (short *)(pbVar24 + uVar12);
    *(short **)(&stack0x000005f8 + lVar6) = psVar13;
    ppbVar23[9] = (byte *)psVar13;
    sVar27 = *psVar13;
    *(short *)(&stack0x000001e0 + lVar6) = sVar27;
    ppbVar23[10] = (byte *)(psVar13 + 1);
    *(short *)(ppbVar23 + 0xb) = (sVar27 + 1) * 2;
  }
  pbVar24 = ppbVar23[1];
  if (pbVar24 != (byte *)0x0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar6) = 0x101dca;
    func_0x(pbVar24,ppbVar23);
  }
  lVar11 = -0x16f6410;
LAB_:
  uVar2 = *(ushort *)(uVar21 + 0xe);
  pbVar24 = (byte *)(*(ushort *)(uVar21 + (0xfff - (longlong)iVar5) * 2) + uVar21);
  bVar1 = *pbVar24;
  *(ushort *)(&stack0x00000a20 + lVar6) = (ushort)(bVar1 & 1);
  if ((bVar1 & 1) != 0) {
    *(undefined **)(&stack0x00000610 + lVar6) = &stack0x00000a22 + lVar6;
    *(byte **)(&stack0x00000a28 + lVar6) = pbVar24;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)(lVar11 + 0x17f985c +
                           (ulonglong)
                           *(byte *)(lVar11 + 0x17f986c + (longlong)(int)(*pbVar24 & 0x1c)) * 4) +
                 lVar11);
                    /* WARNING: Could not recover jumptable at 0x00101f1a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  *(uint *)(&stack0x000000b0 + lVar6) = (uint)uVar2;
  *(undefined **)(&stack0x00000600 + lVar6) = &stack0x00000a22 + lVar6;
  *(byte **)(&stack0x00000a28 + lVar6) = pbVar24;
  *(undefined4 *)(&stack0x00000a24 + lVar6) = 0;
  *(undefined4 *)(&stack0x00000a46 + lVar6) = 0;
  *(byte **)(&stack0x00000608 + lVar6) = pbVar24;
                    /* WARNING: Could not recover jumptable at 0x00101e5d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((ulonglong)*(uint *)(lVar11 + 0x17f9820 + (longlong)(int)(*pbVar24 & 0xe) * 4) + lVar11
            ))();
  return;
}

