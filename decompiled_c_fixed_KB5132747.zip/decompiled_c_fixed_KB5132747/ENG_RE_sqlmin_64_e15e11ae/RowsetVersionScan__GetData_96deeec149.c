
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong *param_3,longlong param_4)

{
  undefined8 *puVar1;
  ushort *puVar2;
  byte bVar3;
  char cVar4;
  short sVar5;
  ushort uVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong lVar9;
  longlong lVar10;
  longlong *plVar11;
  byte *pbVar12;
  code *UNRECOVERED_JUMPTABLE;
  ulonglong uVar13;
  ushort uVar14;
  uint uVar15;
  uint *puVar16;
  undefined *puVar17;
  int iVar18;
  uint uVar19;
  uint uVar20;
  uint *puVar21;
  ulonglong uVar22;
  byte *pbVar23;
  ulonglong uVar24;
  uint uVar25;
  uint *puVar26;
  ushort *puVar27;
  ushort *puVar28;
  bool bVar29;
  undefined8 uStack_460;
  undefined auStack_458 [32];
  undefined8 uStack_438;
  undefined8 uStack_430;
  longlong *plStack_428;
  longlong lStack_420;
  undefined8 uStack_410;
  undefined8 *puStack_408;
  undefined uStack_400;
  undefined *puStack_3f8;
  undefined8 uStack_3f0;
  ushort auStack_3e8 [12];
  undefined4 uStack_3d0;
  uint uStack_3cc;
  undefined4 uStack_3c8;
  longlong lStack_3c0;
  uint auStack_3b8 [6];
  undefined4 uStack_3a0;
  uint *puStack_398;
  longlong lStack_390;
  ushort *puStack_388;
  uint uStack_380;
  longlong lStack_378;
  longlong *plStack_368;
  uint *puStack_360;
  uint uStack_358;
  uint uStack_354;
  longlong lStack_350;
  longlong lStack_348;
  undefined8 uStack_340;
  undefined4 uStack_338;
  undefined8 uStack_330;
  undefined8 uStack_328;
  undefined8 uStack_320;
  undefined8 uStack_310;
  short *psStack_308;
  int iStack_300;
  int aiStack_2fc [8];
  int iStack_2dc;
  int iStack_2d8;
  uint uStack_2d4;
  int iStack_2d0;
  uint uStack_2cc;
  int aiStack_2c8 [17];
  uint uStack_284;
  undefined auStack_268 [60];
  int iStack_22c;
  undefined auStack_228 [4];
  undefined auStack_224 [4];
  int iStack_220;
  undefined auStack_21c [4];
  undefined auStack_218 [4];
  undefined auStack_214 [4];
  undefined auStack_210 [16];
  undefined auStack_200 [56];
  int aiStack_1c8 [4];
  undefined auStack_1b8 [24];
  undefined8 uStack_1a0;
  undefined2 uStack_198;
  ulonglong uStack_40;
  
  uStack_40 = _DAT_ ^ (ulonglong)auStack_3e8;
  puVar21 = (uint *)0x0;
  uVar15 = 0;
  uStack_354 = 0;
  uStack_340 = 0;
  uStack_338 = 0;
  lStack_3c0 = param_1;
  uVar25 = uStack_354;
  if (param_3 != (longlong *)0x0) {
    puVar1 = (undefined8 *)(param_1 + 0xf8);
    if ((*(int *)(param_1 + 0x120) == *(int *)(param_3 + 1)) &&
       (*param_3 == (ulonglong)*(uint6 *)(param_1 + 0x10c) * 0x10000)) {
      uStack_460 = 0x100093;
      sVar5 = (**(code **)*puVar1)(puVar1);
      if (*(short *)((longlong)param_3 + 0xc) != sVar5) goto LAB_;
      if (param_3[0x15] != 0) {
        LOCK();
        UNLOCK();
      }
    }
    else {
LAB_:
      uStack_460 = 0x1000b4;
      func_0x(param_3,puVar1);
    }
    uStack_358 = (uint)*(ushort *)((longlong)param_3 + 0x62);
    lStack_348 = 0;
    uStack_310 = 0;
    puStack_360 = (uint *)param_3[0xe];
    plStack_368 = param_3;
    lStack_350 = param_4;
    if ((*(ushort *)(param_3 + 7) & 0x400) == 0) {
      if (param_1 != -0xf8) {
        lVar7 = **(longlong **)(*(longlong *)(param_1 + 0x100) + 0x160);
        uStack_340 = *(undefined8 *)(lVar7 + 0xa8);
        uStack_338 = *(undefined4 *)(lVar7 + 0xb0);
      }
      uVar25 = uStack_354 | 0x10;
    }
    else {
      if (param_1 != -0xf8) {
        lVar7 = **(longlong **)(*(longlong *)(param_1 + 0x100) + 0x160);
        uStack_340 = *(undefined8 *)(lVar7 + 0xa8);
        uStack_338 = *(undefined4 *)(lVar7 + 0xb0);
      }
      uVar25 = uStack_354 | 0x10;
      if (param_4 != 0) {
        uStack_330 = 0;
        uStack_320 = 0;
        uStack_328 = 0;
        if ((uStack_354 & 4) == 0) {
          uVar25 = uStack_354 | 0x12;
        }
      }
    }
  }
  uStack_354 = uVar25;
  if (*(int *)(param_1 + 0x88) == 0) {
    uStack_1a0 = 0;
    uStack_198 = 0;
    plVar11 = *(longlong **)(param_1 + 0x48);
    plStack_428 = plVar11;
    if ((*(byte *)(plVar11 + 0x43) & 4) != 0) {
      uStack_460 = 0x1001cd;
      plStack_428 = (longlong *)(**(code **)(*plVar11 + 0x1e8))();
      plVar11 = *(longlong **)(param_1 + 0x48);
    }
    plStack_428 = plStack_428 + 5;
    uStack_438 = (int *)(param_1 + 0x138);
    uStack_3f0 = 0;
    puStack_3f8 = auStack_268;
    lStack_420 = param_1 + 0x6c;
    uStack_400 = 0;
    puStack_408 = &uStack_1a0;
    uStack_410 = 0;
    uStack_430 = *(undefined8 *)(param_1 + 0x30);
    uStack_460 = 0x100247;
    func_0x
              (plVar11[0x1a],param_1 + 0x8c,*(undefined8 *)(param_1 + 0xc0),
               *(undefined4 *)(param_1 + 200));
    *(undefined4 *)(param_1 + 0x88) = 1;
  }
  uVar25 = uStack_358;
  if ((*(short *)((longlong)param_3 + 0x3a) == 0) && (*(int *)(param_3 + 10) == 0)) {
    psStack_308 = (short *)(param_1 + 0x8c);
    lStack_390 = param_1 + 0xf8;
    lStack_378 = param_1 + 0xd0;
    if ((*(byte *)(plStack_368 + 6) & 1) != 0) {
      puVar2 = (ushort *)(param_1 + 0x8e);
      if (*psStack_308 == 0) {
        if ((**(byte **)(param_1 + 0x94) & 0x10) != 0) {
          uVar15 = (uint)*(ushort *)(*(byte **)(param_1 + 0x94) + *(uint *)(param_1 + 0x9c));
        }
      }
      else {
        uVar15 = (uint)*puVar2;
      }
      if (*(uint *)(plStack_368 + 3) <= uVar15) {
        *psStack_308 = 0;
        uStack_3cc = 0;
        uStack_380 = (uint)*(ushort *)((longlong)plStack_368 + 0x62);
        puVar17 = auStack_458;
        puVar16 = puStack_360;
        puVar26 = puVar21;
        if (uStack_380 != 0) {
LAB_:
          iVar18 = 0;
          uVar25 = (uint)puVar26;
          cVar4 = *(char *)(puVar16 + 0x10);
          if (cVar4 != '\x01') {
            if (cVar4 != '\x02') {
              if (cVar4 == '\x03') {
                if ((*(byte *)((longlong)puVar16 + 6) & 0x10) == 0) {
                  uVar15 = *(byte *)((ulonglong)(*(ushort *)(puVar16 + 1) - 1 >> 3) +
                                     (ulonglong)*(uint *)(param_1 + 0x9c) + 2 +
                                    *(longlong *)(param_1 + 0x94)) >>
                           ((byte)(*(ushort *)(puVar16 + 1) - 1) & 7) & 1;
                }
                else {
                  uStack_438 = &iStack_220;
                  uStack_460 = 0x100cac;
                  func_0x(puVar2,puVar16,1,&uStack_2d4);
                  uVar15 = uStack_2d4;
                }
                if (uVar15 != 0) goto LAB_;
              }
              else if (cVar4 != '\x04') {
                if (cVar4 == '\b') {
                  uVar14 = *(ushort *)(puVar16 + 0xf);
                  iVar18 = puVar16[0x10] << 0xc;
                  if ((*puVar16 & 0xc0000000) == 0x80000000) {
                    uStack_460 = 0x100c14;
                    iVar18 = func_0x(puVar2);
                    if (iVar18 == 0) {
                      puVar21 = (uint *)0x0;
                      auStack_3b8[0] = 0;
                      bVar29 = (*(ushort *)(*(longlong *)(puVar16 + 0x12) + 0x2a) & 0x10) == 0;
                      goto LAB_;
                    }
                    uStack_460 = 0x100c2f;
                    puVar21 = (uint *)func_0x(param_1 + 0xb6,puVar16,auStack_3b8,auStack_21c
                                                     );
                    uVar15 = auStack_3b8[0];
                  }
                  else {
                    if ((iVar18 < 0) || ((*(byte *)((longlong)puVar16 + 6) & 0x10) != 0)) {
                      uStack_438 = aiStack_2fc;
                      uStack_460 = 0x1003d1;
                      func_0x(puVar2,puVar16,iVar18 < 0,&iStack_300);
                      if ((iVar18 < 0) && (iStack_300 != 0)) {
                        puVar21 = (uint *)0x0;
                        auStack_3b8[0] = 0;
                        uVar15 = auStack_3b8[0];
                        goto LAB_;
                      }
                    }
                    else {
                      iStack_300 = 0;
                      aiStack_2fc[0] = 1;
                    }
                    iVar18 = 0;
                    if ((aiStack_2fc[0] == 0) && ((*(byte *)((longlong)puVar16 + 6) & 0x10) != 0)) {
                      puVar21 = *(uint **)(puVar16 + 2) + 1;
                      uVar15 = **(uint **)(puVar16 + 2);
                    }
                    else if ((int)*puVar16 < 0) {
                      if (*(int *)(param_1 + 0x90) == 0) {
                        *puVar2 = 0;
                        uVar15 = *(uint *)(param_1 + 0x9c);
                        uVar13 = (ulonglong)uVar15;
                        *(uint *)(param_1 + 0xa0) = uVar15;
                        pbVar23 = *(byte **)(param_1 + 0x94);
                        bVar3 = *pbVar23;
                        if ((bVar3 & 0x10) != 0) {
                          uVar15 = uVar15 + 2 + (*(ushort *)(pbVar23 + uVar13) + 7 >> 3);
                          uVar13 = (ulonglong)uVar15;
                          *(uint *)(param_1 + 0xa0) = uVar15;
                          bVar3 = *pbVar23;
                        }
                        if ((bVar3 & 0x20) == 0) {
                          *(int *)(param_1 + 0x90) = (int)uVar13;
                          *(undefined2 *)(param_1 + 0xa8) = 0;
                          *(uint *)(param_1 + 0xa4) = uVar15;
                        }
                        else {
                          puVar27 = (ushort *)(pbVar23 + uVar13);
                          uVar14 = *puVar27;
                          *(ushort *)(param_1 + 0xa8) = uVar14;
                          puStack_388 = puVar27;
                          if (uVar14 == 0) {
                            uStack_460 = 0x100529;
                            cVar4 = func_0x(0x11850c0);
                            if (cVar4 != '\0') {
                              uStack_460 = 0x100532;
                              lVar7 = func_0x();
                              if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                                uStack_460 = 0x10054c;
                                cVar4 = func_0x(0x11850c0);
                                if (cVar4 == '\0') {
                                  uStack_460 = 0x100568;
                                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                }
                                else {
                                  uStack_438 = (int *)0x0;
                                  uStack_460 = 0x10058e;
                                  (*_DAT_)(1,0xa74acc,0xb94bb8,0x80f);
                                }
                              }
                            }
                            uStack_460 = 0x100599;
                            func_0x(*(undefined8 *)(param_1 + 0x94),3);
                            uVar14 = *(ushort *)(param_1 + 0xa8);
                            uVar15 = *(uint *)(param_1 + 0xa0);
                          }
                          uVar15 = uVar15 + (uVar14 + 1) * 2;
                          *(uint *)(param_1 + 0xa4) = uVar15;
                          if (0x1f9e < uVar15) {
                            uStack_460 = 0x1005c8;
                            cVar4 = func_0x(0x11850c0);
                            if (cVar4 != '\0') {
                              uStack_460 = 0x1005d1;
                              lVar7 = func_0x();
                              if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                                uStack_460 = 0x1005eb;
                                cVar4 = func_0x(0x11850c0);
                                if (cVar4 == '\0') {
                                  uStack_460 = 0x100607;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  uStack_438 = (int *)0x0;
                                  uStack_460 = 0x10062d;
                                  (*_DAT_)(1,0xa74acc,0xb94bb8,0x816);
                                }
                              }
                            }
                            uStack_460 = 0x10063b;
                            func_0x(*(undefined8 *)(param_1 + 0x94),4);
                            uVar14 = *(ushort *)(param_1 + 0xa8);
                            uVar15 = *(uint *)(param_1 + 0xa4);
                          }
                          uVar13 = (ulonglong)uVar14;
                          uVar14 = puVar27[uVar13];
                          *(uint *)(param_1 + 0x90) = uVar14 & 0x7fff;
                          if ((uVar14 & 0x7fff) < uVar15) {
                            uStack_460 = 0x100669;
                            cVar4 = func_0x(0x11850c0);
                            if (cVar4 != '\0') {
                              uStack_460 = 0x100672;
                              lVar7 = func_0x();
                              if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                                uStack_460 = 0x10068c;
                                cVar4 = func_0x(0x11850c0);
                                if (cVar4 == '\0') {
                                  uStack_460 = 0x1006a8;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  uStack_438 = (int *)0x0;
                                  uStack_460 = 0x1006ce;
                                  (*_DAT_)(1,0xa74acc,0xb94bb8,0x81d);
                                }
                              }
                            }
                            uStack_460 = 0x1006dc;
                            func_0x(*(undefined8 *)(param_1 + 0x94),4);
                            uVar15 = *(uint *)(param_1 + 0xa4);
                            uVar13 = (ulonglong)*(ushort *)(param_1 + 0xa8);
                          }
                          puVar28 = puVar27;
                          if ((short)uVar13 != 0) {
                            do {
                              puVar27 = puVar27 + 1;
                              uVar19 = *puVar27 & 0x7fff;
                              if ((uVar19 < uVar15) || (*(uint *)(param_1 + 0x90) < uVar19)) {
                                uStack_460 = 0x10071f;
                                cVar4 = func_0x(0x11850c0);
                                if (cVar4 != '\0') {
                                  uStack_460 = 0x100728;
                                  lVar7 = func_0x();
                                  if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                                    uStack_460 = 0x100742;
                                    cVar4 = func_0x(0x11850c0);
                                    if (cVar4 == '\0') {
                                      uStack_460 = 0x10075e;
                                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                    }
                                    else {
                                      uStack_438 = (int *)0x0;
                                      uStack_460 = 0x100782;
                                      (*_DAT_)(1,0xa74acc,0xb94bb8,0x82a);
                                    }
                                  }
                                }
                                uStack_460 = 0x100790;
                                func_0x(*(undefined8 *)(param_1 + 0x94),4);
                              }
                              uVar13 = (ulonglong)*(ushort *)(param_1 + 0xa8);
                              iVar18 = iVar18 + 1;
                              puVar28 = puStack_388;
                              uVar25 = uStack_3cc;
                              uVar15 = uVar19;
                            } while (iVar18 < (int)(uint)*(ushort *)(param_1 + 0xa8));
                          }
                          if ((short)puVar28[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
                            do {
                              lVar7 = (ulonglong)*(uint *)(param_1 + 0xa0) +
                                      *(longlong *)(param_1 + 0x94);
                              uVar15 = *(ushort *)(lVar7 + uVar13 * 2) & 0x7fff;
                              if ((int)uVar13 == 1) {
                                uVar19 = *(uint *)(param_1 + 0xa4);
                                uVar13 = (ulonglong)uVar19;
LAB_:
                                if ((uVar15 < (uint)uVar13) || (*(uint *)(param_1 + 0x90) < uVar15))
                                goto LAB_;
                              }
                              else {
                                uVar19 = *(uint *)(param_1 + 0xa4);
                                uVar20 = *(ushort *)(lVar7 + -2 + uVar13 * 2) & 0x7fff;
                                uVar13 = (ulonglong)uVar20;
                                if (uVar19 <= uVar20) goto LAB_;
LAB_:
                                uStack_460 = 0x10080c;
                                func_0x(*(longlong *)(param_1 + 0x94),7);
                                uVar19 = *(uint *)(param_1 + 0xa4);
                              }
                              uVar20 = (uint)uVar13;
                              if ((uVar20 < uVar19) || (*(uint *)(param_1 + 0x90) < uVar20))
                              goto LAB_;
                              uVar14 = *(ushort *)(uVar13 + *(longlong *)(param_1 + 0x94));
                              if (uVar14 == 5) {
                                *puVar2 = *puVar2 | 2;
                                *(short *)(param_1 + 0xa8) = *(short *)(param_1 + 0xa8) + -1;
                                *(short *)(param_1 + 0xb6) = (short)uVar13;
                                uVar22 = *(ulonglong *)(param_1 + 0x94);
                                uVar6 = *(ushort *)(param_1 + 0xb8) & 0xc7ff;
                                uVar14 = *(ushort *)((uVar13 & 0xffff) + 2 + uVar22);
                                if ((uVar14 >> 0xe & 1) != 0) {
                                  uVar6 = uVar14 & 0x3800 | uVar6;
                                }
                                *(ushort *)(param_1 + 0xb8) = uVar6;
                                uVar14 = (uVar6 ^ *(ushort *)((uVar13 & 0xffff) + 2 + uVar22)) &
                                         0x7ff ^ uVar6;
                                *(ushort *)(param_1 + 0xb8) = uVar14;
                                uVar24 = (ulonglong)*(ushort *)(param_1 + 0xb6);
                                uVar13 = uVar22 + 4 +
                                         (ulonglong)((uVar14 & 0x7ff) * 2) +
                                         uVar24 + (uVar6 >> 0xb & 7) * 2;
                                if (uVar13 < uVar24 + uVar22) {
                                  uStack_460 = 0x100919;
                                  func_0x(uVar24 + uVar22,0x19);
                                  uVar14 = *(ushort *)(param_1 + 0xb8);
                                  uVar24 = (ulonglong)*(ushort *)(param_1 + 0xb6);
                                  uVar22 = (ulonglong)*(uint *)(param_1 + 0x94);
                                }
                                if (uVar15 - uVar20 <
                                    (((uVar14 & 0x7ff) * 2 - (int)uVar24) - (int)uVar22) +
                                    (int)uVar13) {
                                  uStack_460 = 0x100951;
                                  func_0x(uVar24 + *(longlong *)(param_1 + 0x94),0x19);
                                  uVar14 = *(ushort *)(param_1 + 0xb8);
                                }
                                if ((uVar14 & 0x3800) != 0) {
                                  puVar27 = (ushort *)
                                            (*(longlong *)(param_1 + 0x94) +
                                            (ulonglong)*(ushort *)(param_1 + 0xb6) + 4);
                                  iVar18 = 0;
                                  if ((uVar14 & 0x3800) != 0) {
                                    do {
                                      if ((uVar14 & 0x7ff) < (*puVar27 & 0x7ff)) {
                                        uStack_460 = 0x1009a7;
                                        func_0x((ulonglong)*(ushort *)(param_1 + 0xb6) +
                                                        *(longlong *)(param_1 + 0x94),0x1a);
                                        uVar14 = *(ushort *)(param_1 + 0xb8);
                                      }
                                      iVar18 = iVar18 + 1;
                                      puVar27 = puVar27 + 1;
                                    } while (iVar18 < (int)(uVar14 >> 0xb & 7));
                                  }
                                }
                                goto LAB_;
                              }
                              if (uVar14 < 0x400) goto LAB_;
                              *puVar2 = *puVar2 | 1;
                              uVar14 = *(short *)(param_1 + 0xa8) - 1;
                              *(ushort *)(param_1 + 0xa8) = uVar14;
                              if (uVar14 == 0) goto LAB_;
                              uVar13 = (ulonglong)uVar14;
                            } while ((short)puVar28[(ulonglong)(uVar14 - 1) + 1] < 0);
                            pbVar23 = *(byte **)(param_1 + 0x94);
                          }
                          else {
LAB_:
                            pbVar23 = *(byte **)(param_1 + 0x94);
                          }
                        }
                        if ((*pbVar23 & 0x40) == 0) {
                          *(undefined4 *)(param_1 + 0xb2) = 0;
                        }
                        else {
                          *(int *)(param_1 + 0xb2) = *(int *)(param_1 + 0x90);
                          *(int *)(param_1 + 0x90) = *(int *)(param_1 + 0x90) + 0xe;
                          uStack_460 = 0x1009ee;
                          uVar8 = func_0x(puVar2);
                          uStack_460 = 0x1009fd;
                          func_0x(uVar8,auStack_200);
                          uStack_460 = 0x100a09;
                          iVar18 = func_0x(auStack_200);
                          *(int *)(param_1 + 0x90) = *(int *)(param_1 + 0x90) + iVar18;
                        }
                        uVar15 = *(uint *)(param_1 + 0x90);
                        if ((*(ulonglong *)(param_1 + 0xaa) != 0) &&
                           (*(ulonglong *)(param_1 + 0xaa) <
                            (ulonglong)uVar15 + *(longlong *)(param_1 + 0x94))) {
                          uStack_460 = 0x100a3c;
                          cVar4 = func_0x(0x11850c0);
                          if (cVar4 != '\0') {
                            uStack_460 = 0x100a45;
                            lVar7 = func_0x();
                            if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                              uStack_460 = 0x100a5f;
                              cVar4 = func_0x(0x11850c0);
                              if (cVar4 == '\0') {
                                uStack_460 = 0x100a7b;
                                (*_DAT_)(0x22,0x44,0x15,0x3fa);
                              }
                              else {
                                uStack_438 = (int *)0x0;
                                uStack_460 = 0x100aa1;
                                (*_DAT_)(1,0xa74acc,0xb94bb8,0x886);
                              }
                            }
                          }
                          uStack_460 = 0x100aaf;
                          func_0x(*(undefined8 *)(param_1 + 0x94),0x12);
                          uVar15 = *(uint *)(param_1 + 0x90);
                        }
                        if (0x3f3b < uVar15 - 1) {
                          uStack_460 = 0x100ac8;
                          cVar4 = func_0x(0x11850c0);
                          if (cVar4 != '\0') {
                            uStack_460 = 0x100ad1;
                            lVar7 = func_0x();
                            if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                              uStack_460 = 0x100aeb;
                              cVar4 = func_0x(0x11850c0);
                              if (cVar4 == '\0') {
                                uStack_460 = 0x100b07;
                                (*_DAT_)(0x22,0x44,0x15,0x3ed);
                              }
                              else {
                                uStack_438 = (int *)0x0;
                                uStack_460 = 0x100b2d;
                                (*_DAT_)(1,0xa74acc,0xb94bb8,0x88b);
                              }
                            }
                          }
                          uStack_460 = 0x100b3b;
                          func_0x(*(undefined8 *)(param_1 + 0x94),5);
                        }
                      }
LAB_:
                      sVar5 = -*(short *)puVar16;
                      if ((*(byte *)((longlong)puVar16 + 6) & 0x10) != 0) {
                        uStack_438 = &iStack_2d8;
                        uStack_460 = 0x100b6c;
                        func_0x(puVar2,puVar16,0,auStack_218);
                        if (iStack_2d8 == 0) {
                          puVar21 = *(uint **)(puVar16 + 2) + 1;
                          uVar15 = **(uint **)(puVar16 + 2);
                          goto LAB_;
                        }
                      }
                      lVar7 = (longlong)sVar5;
                      if ((uint)*(ushort *)(param_1 + 0xa8) < (uint)(int)sVar5) {
                        auStack_3b8[0] = 0;
                        puVar21 = *(uint **)(param_1 + 0x94);
                        uVar15 = auStack_3b8[0];
                      }
                      else {
                        lVar10 = *(longlong *)(param_1 + 0x94);
                        lVar9 = (ulonglong)*(uint *)(param_1 + 0xa0) + lVar10;
                        if (sVar5 == 1) {
                          uVar15 = *(uint *)(param_1 + 0xa4);
                          uVar19 = *(ushort *)(lVar9 + lVar7 * 2) & 0x7fff;
LAB_:
                          if ((uVar19 < uVar15) || (*(uint *)(param_1 + 0x90) < uVar19))
                          goto LAB_;
                        }
                        else {
                          uVar15 = *(ushort *)(lVar9 + -2 + lVar7 * 2) & 0x7fff;
                          lVar10 = *(longlong *)(param_1 + 0x94);
                          uVar19 = *(ushort *)(lVar9 + lVar7 * 2) & 0x7fff;
                          if (*(uint *)(param_1 + 0xa4) <= uVar15) goto LAB_;
LAB_:
                          uStack_460 = 0x100bf1;
                          func_0x(lVar10,7);
                          lVar10 = *(longlong *)(param_1 + 0x94);
                        }
                        puVar21 = (uint *)((ulonglong)uVar15 + lVar10);
                        uVar15 = uVar19 - uVar15;
                      }
                    }
                    else if ((*(ushort *)((longlong)puVar16 + 6) & 8) == 0) {
                      if ((*(ushort *)((longlong)puVar16 + 6) & 0x10) != 0) {
                        uStack_438 = &iStack_2dc;
                        uStack_460 = 0x10044d;
                        func_0x(puVar2,puVar16,0,auStack_214);
                        if (iStack_2dc == 0) {
                          uVar15 = **(uint **)(puVar16 + 2);
                          puVar21 = *(uint **)(puVar16 + 2) + 1;
                          if ((uVar14 != 0) && (uVar15 != uVar14)) {
                            uStack_438 = (int *)0x0;
                            uStack_460 = 0x100493;
                            (*_DAT_)(1,0xc22f10,0xc21878,0x381);
                          }
                          goto LAB_;
                        }
                      }
                      puVar21 = (uint *)((longlong)(int)*puVar16 + *(longlong *)(param_1 + 0x94));
                      uVar15 = (uint)uVar14;
                    }
                    else {
                      uStack_460 = 0x1004bb;
                      puVar21 = (uint *)func_0x(puVar2,puVar16);
                      uVar15 = auStack_3b8[0];
                    }
                  }
LAB_:
                  auStack_3b8[0] = uVar15;
                  if (puVar21 == (uint *)0x0) {
                    bVar29 = (*(ushort *)(*(longlong *)(puVar16 + 0x12) + 0x2a) & 0x10) == 0;
                    goto LAB_;
                  }
                  lVar7 = lStack_350;
                  if ((*(ushort *)(*(longlong *)(puVar16 + 0x12) + 0x2a) & 0x10) != 0) {
                    lVar7 = lStack_348;
                  }
                  *(undefined *)(lVar7 + *(longlong *)(puVar16 + 0xc)) = 0;
                }
                else {
                  uStack_438 = (int *)0x7f0030;
                  uStack_460 = 0x100361;
                  (*_DAT_)(1,0xbf63c0,0xc22d88,0x27d);
                }
                goto LAB_;
              }
              if (*(int *)(param_1 + 0x90) == 0) {
                *puVar2 = 0;
                uVar15 = *(uint *)(param_1 + 0x9c);
                uVar13 = (ulonglong)uVar15;
                *(uint *)(param_1 + 0xa0) = uVar15;
                pbVar23 = *(byte **)(param_1 + 0x94);
                bVar3 = *pbVar23;
                pbVar12 = pbVar23;
                if ((bVar3 & 0x10) != 0) {
                  uVar15 = uVar15 + 2 + (*(ushort *)(pbVar23 + uVar13) + 7 >> 3);
                  uVar13 = (ulonglong)uVar15;
                  *(uint *)(param_1 + 0xa0) = uVar15;
                  bVar3 = *pbVar23;
                  pbVar12 = *(byte **)(param_1 + 0x94);
                }
                if ((bVar3 & 0x20) == 0) {
                  *(int *)(param_1 + 0x90) = (int)uVar13;
                  *(undefined2 *)(param_1 + 0xa8) = 0;
                  *(uint *)(param_1 + 0xa4) = uVar15;
                }
                else {
                  puVar27 = (ushort *)(pbVar23 + uVar13);
                  uVar14 = *puVar27;
                  *(ushort *)(param_1 + 0xa8) = uVar14;
                  puStack_388 = puVar27;
                  if (uVar14 == 0) {
                    uStack_460 = 0x100d5c;
                    cVar4 = func_0x(0x11850c0);
                    if (cVar4 != '\0') {
                      uStack_460 = 0x100d65;
                      lVar7 = func_0x();
                      if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                        uStack_460 = 0x100d7f;
                        cVar4 = func_0x(0x11850c0);
                        if (cVar4 == '\0') {
                          uStack_460 = 0x100d9b;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          uStack_438 = (int *)0x0;
                          uStack_460 = 0x100dc1;
                          (*_DAT_)(1,0xa74acc,0xb94bb8,0x80f);
                        }
                      }
                    }
                    uStack_460 = 0x100dcc;
                    func_0x(*(undefined8 *)(param_1 + 0x94),3);
                    uVar14 = *(ushort *)(param_1 + 0xa8);
                    uVar15 = *(uint *)(param_1 + 0xa0);
                  }
                  uVar15 = uVar15 + (uVar14 + 1) * 2;
                  *(uint *)(param_1 + 0xa4) = uVar15;
                  if (0x1f9e < uVar15) {
                    uStack_460 = 0x100dfc;
                    cVar4 = func_0x(0x11850c0);
                    if (cVar4 != '\0') {
                      uStack_460 = 0x100e05;
                      lVar7 = func_0x();
                      if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                        uStack_460 = 0x100e1f;
                        cVar4 = func_0x(0x11850c0);
                        if (cVar4 == '\0') {
                          uStack_460 = 0x100e3b;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_438 = (int *)0x0;
                          uStack_460 = 0x100e61;
                          (*_DAT_)(1,0xa74acc,0xb94bb8,0x816);
                        }
                      }
                    }
                    uStack_460 = 0x100e6f;
                    func_0x(*(undefined8 *)(param_1 + 0x94),4);
                    uVar14 = *(ushort *)(param_1 + 0xa8);
                    uVar15 = *(uint *)(param_1 + 0xa4);
                  }
                  uVar13 = (ulonglong)uVar14;
                  uVar14 = puVar27[uVar13];
                  *(uint *)(param_1 + 0x90) = uVar14 & 0x7fff;
                  if ((uVar14 & 0x7fff) < uVar15) {
                    uStack_460 = 0x100e9d;
                    cVar4 = func_0x(0x11850c0);
                    if (cVar4 != '\0') {
                      uStack_460 = 0x100ea6;
                      lVar7 = func_0x();
                      if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                        uStack_460 = 0x100ec0;
                        cVar4 = func_0x(0x11850c0);
                        if (cVar4 == '\0') {
                          uStack_460 = 0x100edc;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_438 = (int *)0x0;
                          uStack_460 = 0x100f02;
                          (*_DAT_)(1,0xa74acc,0xb94bb8,0x81d);
                        }
                      }
                    }
                    uStack_460 = 0x100f10;
                    func_0x(*(undefined8 *)(param_1 + 0x94),4);
                    uVar15 = *(uint *)(param_1 + 0xa4);
                    uVar13 = (ulonglong)*(ushort *)(param_1 + 0xa8);
                  }
                  puVar28 = puVar27;
                  if ((short)uVar13 != 0) {
                    do {
                      puVar27 = puVar27 + 1;
                      uVar19 = *puVar27 & 0x7fff;
                      if ((uVar19 < uVar15) || (*(uint *)(param_1 + 0x90) < uVar19)) {
                        uStack_460 = 0x100f4f;
                        cVar4 = func_0x(0x11850c0);
                        if (cVar4 != '\0') {
                          uStack_460 = 0x100f58;
                          lVar7 = func_0x();
                          if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                            uStack_460 = 0x100f72;
                            cVar4 = func_0x(0x11850c0);
                            if (cVar4 == '\0') {
                              uStack_460 = 0x100f8e;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              uStack_438 = (int *)0x0;
                              uStack_460 = 0x100fb2;
                              (*_DAT_)(1,0xa74acc,0xb94bb8,0x82a);
                            }
                          }
                        }
                        uStack_460 = 0x100fc0;
                        func_0x(*(undefined8 *)(param_1 + 0x94),4);
                      }
                      uVar13 = (ulonglong)*(ushort *)(param_1 + 0xa8);
                      iVar18 = iVar18 + 1;
                      puVar28 = puStack_388;
                      uVar25 = uStack_3cc;
                      uVar15 = uVar19;
                    } while (iVar18 < (int)(uint)*(ushort *)(param_1 + 0xa8));
                  }
                  if ((short)puVar28[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
                    do {
                      lVar7 = *(longlong *)(param_1 + 0x94);
                      lVar10 = (ulonglong)*(uint *)(param_1 + 0xa0) + lVar7;
                      uVar15 = *(ushort *)(lVar10 + uVar13 * 2) & 0x7fff;
                      if ((int)uVar13 == 1) {
                        uVar19 = *(uint *)(param_1 + 0xa4);
                        uVar20 = uVar19;
LAB_:
                        if ((uVar15 < uVar19) || (*(uint *)(param_1 + 0x90) < uVar15))
                        goto LAB_;
                      }
                      else {
                        uVar20 = *(uint *)(param_1 + 0xa4);
                        uVar19 = *(ushort *)(lVar10 + -2 + uVar13 * 2) & 0x7fff;
                        if (uVar20 <= uVar19) goto LAB_;
LAB_:
                        uStack_460 = 0x10103c;
                        func_0x(lVar7,7);
                        uVar20 = *(uint *)(param_1 + 0xa4);
                        lVar7 = *(longlong *)(param_1 + 0x94);
                      }
                      if ((uVar19 < uVar20) || (*(uint *)(param_1 + 0x90) < uVar19))
                      goto LAB_;
                      if (*(ushort *)((ulonglong)uVar19 + lVar7) == 5) {
                        *puVar2 = *puVar2 | 2;
                        *(short *)(param_1 + 0xa8) = *(short *)(param_1 + 0xa8) + -1;
                        *(short *)(param_1 + 0xb6) = (short)uVar19;
                        uVar13 = *(ulonglong *)(param_1 + 0x94);
                        uVar6 = *(ushort *)(param_1 + 0xb8) & 0xc7ff;
                        uVar14 = *(ushort *)((ulonglong)(uVar19 & 0xffff) + 2 + uVar13);
                        if ((uVar14 >> 0xe & 1) != 0) {
                          uVar6 = uVar14 & 0x3800 | uVar6;
                        }
                        *(ushort *)(param_1 + 0xb8) = uVar6;
                        uVar14 = (uVar6 ^ *(ushort *)((ulonglong)(uVar19 & 0xffff) + 2 + uVar13)) &
                                 0x7ff ^ uVar6;
                        *(ushort *)(param_1 + 0xb8) = uVar14;
                        uVar24 = (ulonglong)*(ushort *)(param_1 + 0xb6);
                        uVar22 = uVar24 + 4 +
                                 (ulonglong)((uVar14 & 0x7ff) * 2) + uVar13 + (uVar6 >> 0xb & 7) * 2
                        ;
                        if (uVar22 < uVar24 + uVar13) {
                          uStack_460 = 0x101143;
                          func_0x(uVar24 + uVar13,0x19);
                          uVar14 = *(ushort *)(param_1 + 0xb8);
                          uVar24 = (ulonglong)*(ushort *)(param_1 + 0xb6);
                          uVar13 = (ulonglong)*(uint *)(param_1 + 0x94);
                        }
                        if (uVar15 - uVar19 <
                            (((uVar14 & 0x7ff) * 2 - (int)uVar24) - (int)uVar13) + (int)uVar22) {
                          uStack_460 = 0x10117b;
                          func_0x(uVar24 + *(longlong *)(param_1 + 0x94),0x19);
                          uVar14 = *(ushort *)(param_1 + 0xb8);
                        }
                        if ((uVar14 & 0x3800) != 0) {
                          iVar18 = 0;
                          puVar27 = (ushort *)
                                    (*(longlong *)(param_1 + 0x94) + 4 +
                                    (ulonglong)*(ushort *)(param_1 + 0xb6));
                          if ((uVar14 & 0x3800) != 0) goto LAB_;
                        }
                        break;
                      }
                      if (*(ushort *)((ulonglong)uVar19 + lVar7) < 0x400) break;
                      *puVar2 = *puVar2 | 1;
                      uVar14 = *(short *)(param_1 + 0xa8) - 1;
                      *(ushort *)(param_1 + 0xa8) = uVar14;
                      if ((uVar14 == 0) ||
                         (uVar13 = (ulonglong)uVar14,
                         -1 < (short)puVar28[(ulonglong)(uVar14 - 1) + 1])) break;
                    } while( true );
                  }
                  pbVar12 = *(byte **)(param_1 + 0x94);
                }
                goto LAB_;
              }
              goto LAB_;
            }
LAB_:
            uVar14 = *(ushort *)(puVar16 + 0xf);
            if ((*(byte *)((longlong)puVar16 + 6) & 0x10) == 0) {
LAB_:
              puVar21 = (uint *)((longlong)(int)*puVar16 + *(longlong *)(param_1 + 0x94));
              uVar15 = (uint)uVar14;
            }
            else {
              uStack_438 = aiStack_2c8;
              uStack_460 = 0x101594;
              func_0x(puVar2,puVar16,0,auStack_210);
              if (aiStack_2c8[0] != 0) goto LAB_;
              uVar15 = **(uint **)(puVar16 + 2);
              puVar21 = *(uint **)(puVar16 + 2) + 1;
              if ((uVar14 != 0) && (uVar15 != uVar14)) {
                uStack_438 = (int *)0x0;
                uStack_460 = 0x1015d6;
                (*_DAT_)(1,0xc22f10,0xc21878,0x381);
              }
            }
            auStack_3b8[0] = uVar15;
            lVar7 = lStack_350;
            if ((*(byte *)(*(longlong *)(puVar16 + 0x12) + 0x2a) & 0x10) != 0) {
              lVar7 = lStack_348;
            }
            *(undefined *)(lVar7 + *(longlong *)(puVar16 + 0xc)) = 0;
            goto LAB_;
          }
          if ((*(byte *)((longlong)puVar16 + 6) & 0x10) == 0) {
            uVar15 = *(byte *)((ulonglong)(*(ushort *)(puVar16 + 1) - 1 >> 3) +
                               (ulonglong)*(uint *)(param_1 + 0x9c) + 2 +
                              *(longlong *)(param_1 + 0x94)) >>
                     ((byte)(*(ushort *)(puVar16 + 1) - 1) & 7) & 1;
          }
          else {
            uStack_438 = aiStack_1c8;
            uStack_460 = 0x101506;
            func_0x(puVar2,puVar16,1,&uStack_2cc);
            uVar15 = uStack_2cc;
          }
          if (uVar15 == 0) goto LAB_;
LAB_:
          bVar29 = (*(byte *)(*(longlong *)(puVar16 + 0x12) + 0x2a) & 0x10) == 0;
LAB_:
          lVar7 = lStack_350;
          if (!bVar29) {
            lVar7 = lStack_348;
          }
          *(undefined *)(lVar7 + *(longlong *)(puVar16 + 0xc)) = 3;
          goto LAB_;
        }
        goto LAB_;
      }
    }
    *(short **)(param_1 + 0xd8) = psStack_308;
    *(undefined8 *)(param_1 + 0xe0) = 0;
    if (*psStack_308 == 0) {
      *psStack_308 = 0;
      puVar17 = auStack_458;
      if ((uStack_354 & 0x10) != 0) {
        puStack_398 = puStack_360;
        uStack_380 = uStack_358;
        uStack_3cc = 0;
        puVar17 = auStack_458;
        puVar16 = puStack_360;
        if (uStack_358 != 0) {
          do {
            puStack_398 = puVar16;
            if (*(byte *)(puVar16 + 0x10) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(puVar16 + 0x10) * 4 + 0x107494) -
                           0x1d2a500);
                    /* WARNING: Could not emulate address calculation at 0x0010175f */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
              return;
            }
            uVar25 = puVar16[0x10];
            if ((uVar25 >> 10 & 1) != 0) {
              lVar7 = lStack_350;
              if ((*(byte *)(*(longlong *)(puVar16 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar7 = lStack_348;
              }
              *(undefined *)(lVar7 + *(longlong *)(puVar16 + 0xc)) = 3;
              uVar25 = puVar16[0x10];
            }
            if ((uVar25 >> 9 & 1) != 0) {
              uStack_438 = (int *)CONCAT44(uStack_438._4_4_,uStack_3c8);
              uStack_460 = 0x1020c3;
              func_0x(&plStack_368,lStack_390,puVar16,0);
            }
            uStack_3cc = (int)puVar21 + 1;
            puVar21 = (uint *)(ulonglong)uStack_3cc;
            puStack_398 = puVar16 + 0x14;
            puVar17 = auStack_458;
            puVar16 = puStack_398;
          } while (uStack_3cc < uStack_380);
        }
      }
    }
    else if (*(int *)(*(longlong *)(param_1 + 0x100) + 0x100) == 2) {
      uStack_284 = *(uint *)((longlong)plStack_368 + 0x34);
      uVar13 = (ulonglong)uStack_284 + 0xf;
      if (uVar13 <= uStack_284) {
        uVar13 = 0xffffffffffffff0;
      }
      uVar13 = uVar13 & 0xfffffffffffffff0;
      uStack_460 = 0x104871;
      func_0x();
      lVar7 = -uVar13;
      puStack_388 = (ushort *)((longlong)auStack_3e8 + lVar7);
      puVar17 = auStack_458 + lVar7;
      if ((uStack_354 & 0x10) != 0) {
        uStack_380 = uStack_358;
        puStack_398 = puStack_360;
        uStack_3cc = 0;
        puVar17 = auStack_458 + lVar7;
        puVar21 = puStack_360;
        if (uStack_358 != 0) {
          do {
            puStack_398 = puVar21;
            if (*(byte *)(puVar21 + 0x10) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(puVar21 + 0x10) * 4 + 0x1077e4) -
                           0x1d2a500);
                    /* WARNING: Could not emulate address calculation at 0x001048ce */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
              return;
            }
            uVar25 = puVar21[0x10];
            if ((uVar25 >> 10 & 1) != 0) {
              lVar10 = lStack_350;
              if ((*(byte *)(*(longlong *)(puVar21 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar10 = lStack_348;
              }
              *(undefined *)(lVar10 + *(longlong *)(puVar21 + 0xc)) = 3;
              uVar25 = puVar21[0x10];
            }
            if ((uVar25 >> 9 & 1) != 0) {
              *(undefined4 *)((longlong)&uStack_438 + lVar7) = uStack_3d0;
              *(undefined8 *)(auStack_458 + lVar7 + -8) = 0x1054f4;
              func_0x(&plStack_368,param_1 + 0xf8,puVar21,0);
            }
            puStack_398 = puVar21 + 0x14;
            uStack_3cc = uStack_3cc + 1;
            puVar17 = auStack_458 + lVar7;
            puVar21 = puStack_398;
          } while (uStack_3cc < uStack_380);
        }
      }
    }
    else {
      if (*psStack_308 == -1) {
        *psStack_308 = 1;
      }
      puVar17 = auStack_458;
      if (((uStack_354 & 0x10) != 0) &&
         (puVar16 = puStack_360, puVar17 = auStack_458, uStack_358 != 0)) {
        do {
          if (*(byte *)(puVar16 + 0x10) < 0x1c) {
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)((longlong)(char)*(byte *)(puVar16 + 0x10) * 4 + 0x10763c) -
                         0x1d2a500);
                    /* WARNING: Could not emulate address calculation at 0x00103f5e */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
            return;
          }
          uVar15 = puVar16[0x10];
          if ((uVar15 >> 10 & 1) != 0) {
            lVar7 = lStack_350;
            if ((*(byte *)(*(longlong *)(puVar16 + 0x12) + 0x2a) & 0x10) != 0) {
              lVar7 = lStack_348;
            }
            *(undefined *)(lVar7 + *(longlong *)(puVar16 + 0xc)) = 3;
            uVar15 = puVar16[0x10];
          }
          if ((uVar15 >> 9 & 1) != 0) {
            uStack_438 = (int *)CONCAT44(uStack_438._4_4_,uStack_3a0);
            uStack_460 = 0x10414e;
            func_0x(&plStack_368,lStack_390,puVar16,0);
          }
          uVar15 = (int)puVar21 + 1;
          puVar21 = (uint *)(ulonglong)uVar15;
          puVar16 = puVar16 + 0x14;
          puVar17 = auStack_458;
        } while (uVar15 < uVar25);
      }
    }
  }
  else {
    uStack_430 = 0;
    *(longlong *)(param_1 + 0xd8) = param_1 + 0x8c;
    uStack_438 = &iStack_22c;
    *(undefined8 *)(param_1 + 0xe0) = 0;
    uStack_460 = 0x107466;
    func_0x(param_1 + 400,&plStack_368,0,auStack_228);
    puVar17 = auStack_458;
  }
LAB_:
  uVar13 = uStack_40 ^ (ulonglong)auStack_3e8;
  *(undefined8 *)(puVar17 + -8) = 0x107477;
  func_0x(uVar13);
  return;
LAB_:
  do {
    if ((uVar14 & 0x7ff) < (*puVar27 & 0x7ff)) {
      uStack_460 = 0x1011e7;
      func_0x((ulonglong)*(ushort *)(param_1 + 0xb6) + *(longlong *)(param_1 + 0x94),0x1a);
      uVar14 = *(ushort *)(param_1 + 0xb8);
    }
    iVar18 = iVar18 + 1;
    puVar27 = puVar27 + 1;
  } while (iVar18 < (int)(uVar14 >> 0xb & 7));
  pbVar12 = *(byte **)(param_1 + 0x94);
LAB_:
  if ((*pbVar12 & 0x40) == 0) {
    *(undefined4 *)(param_1 + 0xb2) = 0;
  }
  else {
    *(int *)(param_1 + 0xb2) = *(int *)(param_1 + 0x90);
    *(int *)(param_1 + 0x90) = *(int *)(param_1 + 0x90) + 0xe;
    uStack_460 = 0x10122d;
    uVar8 = func_0x(puVar2);
    uStack_460 = 0x10123c;
    func_0x(uVar8,auStack_1b8);
    uStack_460 = 0x101248;
    iVar18 = func_0x(auStack_1b8);
    *(int *)(param_1 + 0x90) = *(int *)(param_1 + 0x90) + iVar18;
    pbVar12 = *(byte **)(param_1 + 0x94);
  }
  uVar15 = *(uint *)(param_1 + 0x90);
  if ((*(byte **)(param_1 + 0xaa) != (byte *)0x0) && (*(byte **)(param_1 + 0xaa) < pbVar12 + uVar15)
     ) {
    uStack_460 = 0x10127f;
    cVar4 = func_0x(0x11850c0);
    if (cVar4 != '\0') {
      uStack_460 = 0x101288;
      lVar7 = func_0x();
      if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
        uStack_460 = 0x1012a2;
        cVar4 = func_0x(0x11850c0);
        if (cVar4 == '\0') {
          uStack_460 = 0x1012be;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          uStack_438 = (int *)0x0;
          uStack_460 = 0x1012e4;
          (*_DAT_)(1,0xa74acc,0xb94bb8,0x886);
        }
      }
    }
    uStack_460 = 0x1012f2;
    func_0x(*(undefined8 *)(param_1 + 0x94),0x12);
    uVar15 = *(uint *)(param_1 + 0x90);
  }
  if (0x3f3b < uVar15 - 1) {
    uStack_460 = 0x10130b;
    cVar4 = func_0x(0x11850c0);
    if (cVar4 != '\0') {
      uStack_460 = 0x101314;
      lVar7 = func_0x();
      if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
        uStack_460 = 0x10132e;
        cVar4 = func_0x(0x11850c0);
        if (cVar4 == '\0') {
          uStack_460 = 0x10134a;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          uStack_438 = (int *)0x0;
          uStack_460 = 0x101370;
          (*_DAT_)(1,0xa74acc,0xb94bb8,0x88b);
        }
      }
    }
    uStack_460 = 0x10137e;
    func_0x(*(undefined8 *)(param_1 + 0x94),5);
  }
LAB_:
  sVar5 = -*(short *)puVar16;
  if ((*(byte *)((longlong)puVar16 + 6) & 0x10) == 0) {
LAB_:
    lVar7 = (longlong)sVar5;
    if ((uint)*(ushort *)(param_1 + 0xa8) < (uint)(int)sVar5) {
      auStack_3b8[0] = 0;
      puVar21 = *(uint **)(param_1 + 0x94);
    }
    else {
      lVar10 = *(longlong *)(param_1 + 0x94);
      lVar9 = (ulonglong)*(uint *)(param_1 + 0xa0) + lVar10;
      if (sVar5 == 1) {
        uVar13 = (ulonglong)*(uint *)(param_1 + 0xa4);
        uVar15 = *(ushort *)(lVar9 + lVar7 * 2) & 0x7fff;
LAB_:
        if ((uVar15 < (uint)uVar13) || (*(uint *)(param_1 + 0x90) < uVar15)) goto LAB_;
      }
      else {
        uVar19 = *(ushort *)(lVar9 + -2 + lVar7 * 2) & 0x7fff;
        uVar13 = (ulonglong)uVar19;
        lVar10 = *(longlong *)(param_1 + 0x94);
        uVar15 = *(ushort *)(lVar9 + lVar7 * 2) & 0x7fff;
        if (*(uint *)(param_1 + 0xa4) <= uVar19) goto LAB_;
LAB_:
        uStack_460 = 0x101434;
        func_0x(lVar10,7);
        lVar10 = *(longlong *)(param_1 + 0x94);
      }
      auStack_3b8[0] = uVar15 - (int)uVar13;
      puVar21 = (uint *)(uVar13 + lVar10);
    }
  }
  else {
    uStack_438 = &iStack_2d0;
    uStack_460 = 0x1013af;
    func_0x(puVar2,puVar16,0,auStack_224);
    if (iStack_2d0 != 0) goto LAB_;
    auStack_3b8[0] = **(uint **)(puVar16 + 2);
    puVar21 = *(uint **)(puVar16 + 2) + 1;
  }
  if (((puVar16[0x10] & 0x2000) != 0) && (auStack_3b8[0] == 0)) {
    auStack_3b8[0] = 4;
    puVar21 = (uint *)0x81b694;
  }
  lVar7 = lStack_350;
  if ((*(byte *)(*(longlong *)(puVar16 + 0x12) + 0x2a) & 0x10) != 0) {
    lVar7 = lStack_348;
  }
  *(undefined *)(lVar7 + *(longlong *)(puVar16 + 0xc)) = 0;
  if ((1 << (**(byte **)(param_1 + 0x94) & 0xe) & 0x440U) != 0) {
    uStack_460 = 0x1014ab;
    iVar18 = func_0x(puVar16);
    if (iVar18 != 0) goto LAB_;
  }
  if (*(ushort *)(puVar16 + 0xf) < auStack_3b8[0]) {
    uStack_460 = 0x1014d8;
    (*_DAT_)(6,0x52,0x16,0x91);
  }
LAB_:
  uVar13 = (ulonglong)auStack_3b8[0];
  lVar7 = *(longlong *)(puVar16 + 0x12);
  if ((puVar16[0x10] & 0x800) == 0) {
    lVar10 = lStack_350;
    if ((*(byte *)(lVar7 + 0x2a) & 0x10) != 0) {
      lVar10 = lStack_348;
    }
    uStack_460 = 0x10163f;
    func_0x(lVar10 + *(longlong *)(puVar16 + 10),puVar21);
  }
  else {
    uVar14 = *(ushort *)(lVar7 + 0x2a) & 0x10;
    if (*(int *)(lVar7 + 0x10) == 10) {
      lVar7 = lStack_350;
      if (uVar14 != 0) {
        lVar7 = lStack_348;
      }
      *(uint **)(lVar7 + *(longlong *)(puVar16 + 10)) = puVar21;
    }
    else {
      lVar7 = lStack_350;
      if (uVar14 != 0) {
        lVar7 = lStack_348;
      }
      uStack_460 = 0x101672;
      func_0x(*(undefined8 *)(*(longlong *)(puVar16 + 10) + lVar7),puVar21);
    }
  }
  if ((puVar16[0x10] & 0x100) != 0) {
    lVar7 = lStack_350;
    if ((*(byte *)(*(longlong *)(puVar16 + 0x12) + 0x2a) & 0x10) != 0) {
      lVar7 = lStack_348;
    }
    *(ulonglong *)(lVar7 + *(longlong *)(*(longlong *)(puVar16 + 0x12) + 0x18)) = uVar13;
  }
LAB_:
  uStack_3cc = uVar25 + 1;
  puVar17 = auStack_458;
  puVar16 = puVar16 + 0x14;
  puVar26 = (uint *)(ulonglong)uStack_3cc;
  if (uStack_380 <= uStack_3cc) goto LAB_;
  goto LAB_;
}

