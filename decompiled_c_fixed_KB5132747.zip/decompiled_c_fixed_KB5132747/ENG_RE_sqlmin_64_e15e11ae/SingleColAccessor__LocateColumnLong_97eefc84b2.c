
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 *param_2,undefined8 param_3,undefined8 param_4)

{
  ushort *puVar1;
  ulonglong *puVar2;
  uint uVar3;
  undefined4 uVar4;
  code *pcVar5;
  ushort *puVar6;
  char cVar7;
  byte bVar8;
  ushort uVar9;
  longlong lVar10;
  short *psVar11;
  longlong lVar12;
  undefined8 uVar13;
  longlong lVar14;
  ulonglong *puVar15;
  short *psVar16;
  int *piVar17;
  longlong lVar18;
  undefined4 *puVar19;
  longlong lVar20;
  undefined uVar21;
  byte bVar22;
  uint uVar23;
  byte *pbVar24;
  ushort uVar25;
  ulonglong uVar26;
  undefined *puVar27;
  short sVar28;
  int iVar29;
  longlong *plVar30;
  ulonglong uVar31;
  ulonglong uVar32;
  byte *pbVar33;
  ulonglong *puVar34;
  uint *puVar35;
  uint uVar36;
  longlong *plVar37;
  longlong *plVar38;
  uint uVar39;
  int iVar40;
  undefined8 *puVar41;
  undefined *puVar42;
  ushort *puVar43;
  undefined4 uVar44;
  undefined8 uStackX_8;
  undefined8 uStackX_10;
  uint auStackX_18 [2];
  short *psStackX_20;
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar10 = func_0x();
  lVar10 = -lVar10;
  puVar27 = &stack0xffffffffffffffc0 + lVar10;
  puVar2 = (ulonglong *)((longlong)&psStackX_20 + lVar10 + -0x20);
  *(undefined8 *)(&stack0x000002b0 + lVar10) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x000023e0 + lVar10) = _DAT_ ^ (ulonglong)puVar2;
  *(undefined8 *)(&stack0x00000298 + lVar10) = param_4;
  *(undefined8 *)(&stack0x00000160 + lVar10) = param_3;
  *(longlong *)(&stack0x00000290 + lVar10) = param_1;
  pcVar5 = *(code **)*param_2;
  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100064;
  cVar7 = (*pcVar5)(param_2);
  if (cVar7 != '\0') {
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100079;
    func_0x(param_1,param_2,param_3,param_4);
    puVar27 = &stack0xffffffffffffffc0 + lVar10;
    goto LAB_;
  }
  lVar20 = *(longlong *)(param_1 + 0x28);
  if (lVar20 == 0) {
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1000a9;
    (*_DAT_)(1,0x191be68,0x18eefb8,0x240);
    puVar27 = &stack0xffffffffffffffc0 + lVar10;
    goto LAB_;
  }
  lVar14 = param_2[1];
  *(longlong *)(&stack0x00000060 + lVar10) = lVar14;
  *(undefined8 *)(&stack0x00000170 + lVar10) = 0x150fe80;
  *(undefined (*) [16])(&stack0x00000178 + lVar10) = ZEXT816(0);
  plVar38 = (longlong *)0x0;
  *(undefined8 *)(&stack0x00000188 + lVar10) = 0;
  *(undefined (*) [16])(&stack0x00000190 + lVar10) = ZEXT816(0);
  *(undefined4 *)(&stack0x000001a0 + lVar10) = 1;
  *(undefined4 *)(&stack0x000001a4 + lVar10) = 1;
  *(undefined8 *)(&stack0x000001a8 + lVar10) = 0;
  *(undefined4 *)(&stack0x000001b0 + lVar10) = 0;
  *(undefined8 *)(&stack0x000001b8 + lVar10) = 0xffffffffffffffff;
  *(uint *)(&stack0x000001c4 + lVar10) = *(uint *)(&stack0x000001c4 + lVar10) & 0xfffffff8;
  *(undefined8 *)(&stack0x000001c8 + lVar10) = 0;
  *(undefined4 *)(&stack0x00000084 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000098 + lVar10) = 0;
  *(undefined4 *)(&stack0x000000a0 + lVar10) = 0;
  *(undefined4 *)(&stack0x000000f0 + lVar10) = 0;
  lVar12 = *(longlong *)(param_1 + 0x40);
  uVar25 = *(ushort *)(lVar20 + 0x62);
  *(longlong *)(&stack0x00000070 + lVar10) = lVar20;
  *(uint *)(&stack0x00000080 + lVar10) = (uint)uVar25;
  *(longlong *)(&stack0x00000088 + lVar10) = lVar12;
  *(undefined8 *)(&stack0x00000090 + lVar10) = 0;
  *(undefined8 *)(&stack0x000000c8 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000078 + lVar10) = *(undefined8 *)(lVar20 + 0x70);
  if (lVar14 != 0) {
    lVar18 = **(longlong **)(*(longlong *)(lVar14 + 8) + 0x160);
    *(undefined8 *)(&stack0x00000098 + lVar10) = *(undefined8 *)(lVar18 + 0xa8);
    *(undefined4 *)(&stack0x000000a0 + lVar10) = *(undefined4 *)(lVar18 + 0xb0);
  }
  *(undefined4 *)(&stack0x00000084 + lVar10) = 0x10;
  uVar26 = 0x10;
  if (((*(ushort *)(lVar20 + 0x38) & 0x400) != 0) && (lVar12 != 0)) {
    *(undefined4 *)(&stack0x00000084 + lVar10) = 0x12;
    *(undefined8 *)(&stack0x000000b0 + lVar10) = 0;
    *(undefined8 *)(&stack0x000000b8 + lVar10) = 0;
    *(undefined8 *)(&stack0x000000a8 + lVar10) = 0;
    uVar26 = 0x12;
  }
  plVar37 = (longlong *)param_2[3];
  *(longlong **)(&stack0x000000f8 + lVar10) = plVar37;
  if (plVar37 == (longlong *)0x0) {
    *(undefined8 *)(&stack0x000000f8 + lVar10) = 0;
    psVar11 = (short *)param_2[4];
    plVar37 = plVar38;
  }
  else {
    pcVar5 = *(code **)*plVar37;
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1001ef;
    psVar11 = (short *)(*pcVar5)(plVar37);
    uVar26 = (ulonglong)*(uint *)(&stack0x00000084 + lVar10);
    lVar20 = *(longlong *)(&stack0x00000070 + lVar10);
  }
  *(short **)((longlong)&psStackX_20 + lVar10) = psVar11;
  uVar36 = *(uint *)(param_1 + 0x24);
  if ((uVar36 & 0x10) == 0) {
    uVar23 = (uint)uVar26 & 0xfffffffd;
    uVar26 = (ulonglong)uVar23;
    *(uint *)(&stack0x00000084 + lVar10) = uVar23;
    *(uint *)(&stack0x000000f0 + lVar10) = uVar36 >> 6 & 1;
  }
  uVar36 = 0;
  if ((*(short *)(*(longlong *)(param_1 + 0x28) + 0x3a) == 0) &&
     (*(int *)(*(longlong *)(param_1 + 0x28) + 0x50) == 0)) {
    if ((*(byte *)(lVar20 + 0x30) & 1) != 0) {
      puVar1 = (ushort *)(psVar11 + 1);
      if (*psVar11 == 0) {
        if ((**(byte **)(psVar11 + 4) & 0x10) != 0) {
          uVar36 = (uint)*(ushort *)(*(byte **)(psVar11 + 4) + *(uint *)(psVar11 + 8));
        }
      }
      else {
        uVar36 = (uint)*puVar1;
      }
      if (*(uint *)(lVar20 + 0x18) <= uVar36) {
        *psVar11 = 0;
        uVar25 = *(ushort *)(*(longlong *)(&stack0x00000070 + lVar10) + 0x62);
        *(uint *)(&stack0x00000058 + lVar10) = (uint)uVar25;
        puVar35 = *(uint **)(&stack0x00000078 + lVar10);
        *(undefined4 *)((longlong)auStackX_18 + lVar10 + 4) = 0;
        plVar37 = plVar38;
        if (uVar25 != 0) {
          do {
            plVar30 = (longlong *)0x0;
            iVar40 = (int)plVar37;
            cVar7 = *(char *)(puVar35 + 0x10);
            if (cVar7 == '\x01') {
              if ((*(byte *)((longlong)puVar35 + 6) & 0x10) == 0) {
                uVar36 = *(byte *)((ulonglong)(*(ushort *)(puVar35 + 1) - 1 >> 3) +
                                   (ulonglong)*(uint *)(psVar11 + 8) + 2 +
                                  *(longlong *)(psVar11 + 4)) >>
                         ((byte)(*(ushort *)(puVar35 + 1) - 1) & 7) & 1;
              }
              else {
                *(undefined **)(&stack0xffffffffffffffe0 + lVar10) = &stack0x0000021c + lVar10;
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1014bb;
                func_0x(puVar1,puVar35,1,&stack0x00000150 + lVar10);
                uVar36 = *(uint *)(&stack0x00000150 + lVar10);
              }
              if (uVar36 == 0) goto LAB_;
LAB_:
              lVar20 = *(longlong *)(&stack0x00000088 + lVar10);
              if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar20 = *(longlong *)(&stack0x00000090 + lVar10);
              }
              *(undefined *)(lVar20 + *(longlong *)(puVar35 + 0xc)) = 3;
            }
            else {
              if (cVar7 == '\x02') {
LAB_:
                uVar25 = *(ushort *)(puVar35 + 0xf);
                if ((*(byte *)((longlong)puVar35 + 6) & 0x10) == 0) {
LAB_:
                  *(uint *)(&stack0x0000002c + lVar10) = (uint)uVar25;
                  plVar30 = (longlong *)((longlong)(int)*puVar35 + *(longlong *)(psVar11 + 4));
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe0 + lVar10) = &stack0x0000014c + lVar10;
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101549;
                  func_0x(puVar1,puVar35,0,&stack0x00000220 + lVar10);
                  if (*(int *)(&stack0x0000014c + lVar10) != 0) goto LAB_;
                  plVar30 = (longlong *)(*(uint **)(puVar35 + 2) + 1);
                  uVar36 = **(uint **)(puVar35 + 2);
                  if ((uVar25 != 0) && (uVar36 != uVar25)) {
                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10158f;
                    (*_DAT_)(1,0x1918a00,0x1917368,0x381);
                  }
                  *(uint *)(&stack0x0000002c + lVar10) = uVar36;
                }
                lVar20 = *(longlong *)(&stack0x00000088 + lVar10);
                if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar20 = *(longlong *)(&stack0x00000090 + lVar10);
                }
                *(undefined *)(lVar20 + *(longlong *)(puVar35 + 0xc)) = 0;
              }
              else {
                if (cVar7 == '\x03') {
                  if ((*(byte *)((longlong)puVar35 + 6) & 0x10) == 0) {
                    uVar36 = *(byte *)((ulonglong)(*(ushort *)(puVar35 + 1) - 1 >> 3) +
                                       (ulonglong)*(uint *)(psVar11 + 8) + 2 +
                                      *(longlong *)(psVar11 + 4)) >>
                             ((byte)(*(ushort *)(puVar35 + 1) - 1) & 7) & 1;
                  }
                  else {
                    *(undefined **)(&stack0xffffffffffffffe0 + lVar10) = &stack0x00000214 + lVar10;
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100c64;
                    func_0x(puVar1,puVar35,1,&stack0x00000168 + lVar10);
                    uVar36 = *(uint *)(&stack0x00000168 + lVar10);
                  }
                  if (uVar36 != 0) goto LAB_;
                }
                else if (cVar7 != '\x04') {
                  if (cVar7 == '\b') {
                    iVar29 = puVar35[0x10] << 0xc;
                    uVar25 = *(ushort *)(puVar35 + 0xf);
                    if ((*puVar35 & 0xc0000000) == 0x80000000) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100bb6;
                      iVar29 = func_0x(puVar1);
                      if (iVar29 != 0) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100bd1;
                        plVar30 = (longlong *)
                                  func_0x(psVar11 + 0x15,puVar35,&stack0x0000002c + lVar10,
                                                  &stack0x00000210 + lVar10);
                        goto LAB_;
                      }
                      *(undefined4 *)(&stack0x0000002c + lVar10) = 0;
                      uVar25 = *(ushort *)(*(longlong *)(puVar35 + 0x12) + 0x2a);
                    }
                    else {
                      if ((iVar29 < 0) || ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0)) {
                        *(undefined **)(&stack0xffffffffffffffe0 + lVar10) =
                             &stack0x000000d4 + lVar10;
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100373;
                        func_0x(puVar1,puVar35,iVar29 < 0,&stack0x000000d0 + lVar10)
                        ;
                        if ((iVar29 < 0) && (*(int *)(&stack0x000000d0 + lVar10) != 0)) {
                          *(undefined4 *)(&stack0x0000002c + lVar10) = 0;
                          plVar30 = (longlong *)0x0;
                          goto LAB_;
                        }
                        iVar29 = *(int *)(&stack0x000000d4 + lVar10);
                      }
                      else {
                        *(undefined4 *)(&stack0x000000d0 + lVar10) = 0;
                        iVar29 = 1;
                        *(undefined4 *)(&stack0x000000d4 + lVar10) = 1;
                      }
                      if ((iVar29 == 0) && ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0)) {
                        puVar19 = *(undefined4 **)(puVar35 + 2);
                        *(undefined4 *)(&stack0x0000002c + lVar10) = *puVar19;
                        plVar30 = (longlong *)(puVar19 + 1);
                      }
                      else if ((int)*puVar35 < 0) {
                        if (*(int *)(psVar11 + 2) == 0) {
                          *puVar1 = 0;
                          uVar36 = *(uint *)(psVar11 + 8);
                          uVar26 = (ulonglong)uVar36;
                          *(uint *)(psVar11 + 10) = uVar36;
                          pbVar33 = *(byte **)(psVar11 + 4);
                          bVar8 = *pbVar33;
                          if ((bVar8 & 0x10) != 0) {
                            uVar36 = uVar36 + (*(ushort *)(pbVar33 + uVar26) + 7 >> 3) + 2;
                            uVar26 = (ulonglong)uVar36;
                            *(uint *)(psVar11 + 10) = uVar36;
                            bVar8 = *pbVar33;
                          }
                          if ((bVar8 & 0x20) == 0) {
                            *(int *)(psVar11 + 2) = (int)uVar26;
                            psVar11[0xe] = 0;
                            *(uint *)(psVar11 + 0xc) = uVar36;
                          }
                          else {
                            puVar43 = (ushort *)(pbVar33 + uVar26);
                            *(ushort **)(&stack0x00000060 + lVar10) = puVar43;
                            uVar25 = *puVar43;
                            psVar11[0xe] = uVar25;
                            if (uVar25 == 0) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1004cf;
                              cVar7 = func_0x(0x1e7abb0);
                              if (cVar7 != '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1004d8;
                                lVar20 = func_0x();
                                if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1004f2;
                                  cVar7 = func_0x(0x1e7abb0);
                                  if (cVar7 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10050e;
                                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100531;
                                    (*_DAT_)(1,0x176a5bc,0x188a6a8,0x80f);
                                  }
                                }
                              }
                              uVar13 = *(undefined8 *)(psVar11 + 4);
                              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10053f;
                              func_0x(uVar13,3);
                              uVar25 = psVar11[0xe];
                              uVar36 = *(uint *)(psVar11 + 10);
                            }
                            uVar36 = uVar36 + (uVar25 + 1) * 2;
                            *(uint *)(psVar11 + 0xc) = uVar36;
                            if (0x1f9e < uVar36) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10056e;
                              cVar7 = func_0x(0x1e7abb0);
                              if (cVar7 != '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100577;
                                lVar20 = func_0x();
                                if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100591;
                                  cVar7 = func_0x(0x1e7abb0);
                                  if (cVar7 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1005ad;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1005d0;
                                    (*_DAT_)(1,0x176a5bc,0x188a6a8,0x816);
                                  }
                                }
                              }
                              uVar13 = *(undefined8 *)(psVar11 + 4);
                              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1005de;
                              func_0x(uVar13,4);
                              uVar25 = psVar11[0xe];
                              uVar36 = *(uint *)(psVar11 + 0xc);
                            }
                            uVar26 = (ulonglong)uVar25;
                            uVar25 = puVar43[uVar26];
                            *(uint *)(psVar11 + 2) = uVar25 & 0x7fff;
                            if ((uVar25 & 0x7fff) < uVar36) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10060c;
                              cVar7 = func_0x(0x1e7abb0);
                              if (cVar7 != '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100615;
                                lVar20 = func_0x();
                                if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10062f;
                                  cVar7 = func_0x(0x1e7abb0);
                                  if (cVar7 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10064b;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10066e;
                                    (*_DAT_)(1,0x176a5bc,0x188a6a8,0x81d);
                                  }
                                }
                              }
                              uVar13 = *(undefined8 *)(psVar11 + 4);
                              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10067c;
                              func_0x(uVar13,4);
                              uVar36 = *(uint *)(psVar11 + 0xc);
                              uVar26 = (ulonglong)(ushort)psVar11[0xe];
                            }
                            if ((short)uVar26 != 0) {
                              do {
                                puVar43 = puVar43 + 1;
                                uVar23 = *puVar43 & 0x7fff;
                                if ((uVar23 < uVar36) || (*(uint *)(psVar11 + 2) < uVar23)) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1006bf;
                                  cVar7 = func_0x(0x1e7abb0);
                                  if (cVar7 != '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1006c8;
                                    lVar20 = func_0x();
                                    if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1006e2;
                                      cVar7 = func_0x(0x1e7abb0);
                                      if (cVar7 == '\0') {
                                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1006fe;
                                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                      }
                                      else {
                                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100722;
                                        (*_DAT_)(1,0x176a5bc,0x188a6a8,0x82a);
                                      }
                                    }
                                  }
                                  uVar13 = *(undefined8 *)(psVar11 + 4);
                                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100730;
                                  func_0x(uVar13,4);
                                }
                                uVar39 = (int)plVar30 + 1;
                                plVar30 = (longlong *)(ulonglong)uVar39;
                                uVar26 = (ulonglong)(ushort)psVar11[0xe];
                                uVar36 = uVar23;
                              } while ((int)uVar39 < (int)(uint)(ushort)psVar11[0xe]);
                              puVar43 = *(ushort **)(&stack0x00000060 + lVar10);
                              iVar40 = *(int *)((longlong)auStackX_18 + lVar10 + 4);
                            }
                            if ((short)puVar43[(ulonglong)((int)uVar26 - 1) + 1] < 0) {
                              do {
                                lVar20 = *(longlong *)(psVar11 + 4);
                                lVar12 = (ulonglong)*(uint *)(psVar11 + 10) + lVar20;
                                uVar36 = *(ushort *)(lVar12 + uVar26 * 2) & 0x7fff;
                                if ((int)uVar26 == 1) {
                                  uVar23 = *(uint *)(psVar11 + 0xc);
                                  uVar39 = uVar23;
LAB_:
                                  if ((uVar36 < uVar23) || (*(uint *)(psVar11 + 2) < uVar36))
                                  goto LAB_;
                                }
                                else {
                                  uVar23 = *(ushort *)(lVar12 + -2 + uVar26 * 2) & 0x7fff;
                                  uVar39 = *(uint *)(psVar11 + 0xc);
                                  if (uVar39 <= uVar23) goto LAB_;
LAB_:
                                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1007ac;
                                  func_0x(lVar20,7);
                                  uVar39 = *(uint *)(psVar11 + 0xc);
                                }
                                if ((uVar23 < uVar39) || (*(uint *)(psVar11 + 2) < uVar23))
                                goto LAB_;
                                if (*(ushort *)((ulonglong)uVar23 + *(longlong *)(psVar11 + 4)) == 5
                                   ) {
                                  *puVar1 = *puVar1 | 2;
                                  psVar11[0xe] = psVar11[0xe] + -1;
                                  psVar11[0x15] = (short)uVar23;
                                  uVar26 = *(ulonglong *)(psVar11 + 4);
                                  uVar25 = *(ushort *)((ulonglong)(uVar23 & 0xffff) + 2 + uVar26);
                                  uVar9 = psVar11[0x16] & 0xc7ff;
                                  if ((uVar25 >> 0xe & 1) != 0) {
                                    uVar9 = uVar25 & 0x3800 | uVar9;
                                  }
                                  psVar11[0x16] = uVar9;
                                  uVar25 = (uVar9 ^ *(ushort *)
                                                     ((ulonglong)(uVar23 & 0xffff) + 2 + uVar26)) &
                                           0x7ff ^ uVar9;
                                  psVar11[0x16] = uVar25;
                                  uVar32 = (ulonglong)(ushort)psVar11[0x15];
                                  uVar31 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                                           uVar26 + (uVar9 >> 0xb & 7) * 2 + uVar32;
                                  if (uVar31 < uVar32 + uVar26) {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1008b9;
                                    func_0x(uVar32 + uVar26,0x19);
                                    uVar25 = psVar11[0x16];
                                    uVar32 = (ulonglong)(ushort)psVar11[0x15];
                                    uVar26 = (ulonglong)*(uint *)(psVar11 + 4);
                                  }
                                  if (uVar36 - uVar23 <
                                      (((uVar25 & 0x7ff) * 2 - (int)uVar32) - (int)uVar26) +
                                      (int)uVar31) {
                                    lVar20 = *(longlong *)(psVar11 + 4);
                                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1008f1;
                                    func_0x(uVar32 + lVar20,0x19);
                                    uVar25 = psVar11[0x16];
                                  }
                                  if ((uVar25 & 0x3800) != 0) {
                                    puVar43 = (ushort *)
                                              (*(longlong *)(psVar11 + 4) +
                                              (ulonglong)(ushort)psVar11[0x15] + 4);
                                    iVar29 = 0;
                                    if ((uVar25 & 0x3800) != 0) {
                                      do {
                                        if ((uVar25 & 0x7ff) < (*puVar43 & 0x7ff)) {
                                          uVar25 = psVar11[0x15];
                                          lVar20 = *(longlong *)(psVar11 + 4);
                                          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100947;
                                          func_0x((ulonglong)uVar25 + lVar20,0x1a);
                                          uVar25 = psVar11[0x16];
                                        }
                                        iVar29 = iVar29 + 1;
                                        puVar43 = puVar43 + 1;
                                      } while (iVar29 < (int)(uVar25 >> 0xb & 7));
                                    }
                                  }
                                  goto LAB_;
                                }
                                if (*(ushort *)((ulonglong)uVar23 + *(longlong *)(psVar11 + 4)) <
                                    0x400) goto LAB_;
                                *puVar1 = *puVar1 | 1;
                                uVar25 = psVar11[0xe] - 1;
                                psVar11[0xe] = uVar25;
                                if (uVar25 == 0) goto LAB_;
                                uVar26 = (ulonglong)uVar25;
                              } while ((short)puVar43[(ulonglong)(uVar25 - 1) + 1] < 0);
                              pbVar33 = *(byte **)(psVar11 + 4);
                            }
                            else {
LAB_:
                              pbVar33 = *(byte **)(psVar11 + 4);
                            }
                          }
                          if ((*pbVar33 & 0x40) == 0) {
                            *(undefined4 *)(psVar11 + 0x13) = 0;
                          }
                          else {
                            *(int *)(psVar11 + 0x13) = *(int *)(psVar11 + 2);
                            *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + 0xe;
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10098e;
                            uVar13 = func_0x(puVar1);
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10099d;
                            func_0x(uVar13,&stack0x00000228 + lVar10);
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1009a9;
                            iVar29 = func_0x(&stack0x00000228 + lVar10);
                            *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar29;
                          }
                          uVar36 = *(uint *)(psVar11 + 2);
                          if ((*(ulonglong *)(psVar11 + 0xf) != 0) &&
                             (*(ulonglong *)(psVar11 + 0xf) <
                              (ulonglong)uVar36 + *(longlong *)(psVar11 + 4))) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1009dc;
                            cVar7 = func_0x(0x1e7abb0);
                            if (cVar7 != '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1009e5;
                              lVar20 = func_0x();
                              if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1009ff;
                                cVar7 = func_0x(0x1e7abb0);
                                if (cVar7 == '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100a1b;
                                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                                }
                                else {
                                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100a41;
                                  (*_DAT_)(1,0x176a5bc,0x188a6a8,0x886);
                                }
                              }
                            }
                            uVar13 = *(undefined8 *)(psVar11 + 4);
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100a4f;
                            func_0x(uVar13,0x12);
                            uVar36 = *(uint *)(psVar11 + 2);
                          }
                          if (0x3f3b < uVar36 - 1) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100a68;
                            cVar7 = func_0x(0x1e7abb0);
                            if (cVar7 != '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100a71;
                              lVar20 = func_0x();
                              if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100a8b;
                                cVar7 = func_0x(0x1e7abb0);
                                if (cVar7 == '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100aa7;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                                }
                                else {
                                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100acd;
                                  (*_DAT_)(1,0x176a5bc,0x188a6a8,0x88b);
                                }
                              }
                            }
                            uVar13 = *(undefined8 *)(psVar11 + 4);
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100adb;
                            func_0x(uVar13,5);
                          }
                        }
LAB_:
                        sVar28 = -*(short *)puVar35;
                        if ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0) {
                          *(undefined **)(&stack0xffffffffffffffe0 + lVar10) =
                               &stack0x0000015c + lVar10;
                          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100b0c;
                          func_0x(puVar1,puVar35,0,&stack0x0000020c + lVar10);
                          if (*(int *)(&stack0x0000015c + lVar10) == 0) {
                            puVar19 = *(undefined4 **)(puVar35 + 2);
                            *(undefined4 *)(&stack0x0000002c + lVar10) = *puVar19;
                            plVar30 = (longlong *)(puVar19 + 1);
                            goto LAB_;
                          }
                        }
                        lVar20 = (longlong)sVar28;
                        if ((uint)(ushort)psVar11[0xe] < (uint)(int)sVar28) {
                          *(undefined4 *)(&stack0x0000002c + lVar10) = 0;
                          plVar30 = *(longlong **)(psVar11 + 4);
                        }
                        else {
                          lVar12 = *(longlong *)(psVar11 + 4);
                          lVar14 = (ulonglong)*(uint *)(psVar11 + 10) + lVar12;
                          if (sVar28 == 1) {
                            uVar26 = (ulonglong)
                                     *(uint *)(*(longlong *)((longlong)&psStackX_20 + lVar10) + 0x18
                                              );
                            uVar23 = *(ushort *)(lVar14 + lVar20 * 2) & 0x7fff;
LAB_:
                            if ((uVar23 < (uint)uVar26) || (*(uint *)(psVar11 + 2) < uVar23))
                            goto LAB_;
                          }
                          else {
                            uVar36 = *(ushort *)(lVar14 + -2 + lVar20 * 2) & 0x7fff;
                            uVar26 = (ulonglong)uVar36;
                            uVar23 = *(ushort *)(lVar14 + lVar20 * 2) & 0x7fff;
                            lVar12 = *(longlong *)(psVar11 + 4);
                            if (*(uint *)(*(longlong *)((longlong)&psStackX_20 + lVar10) + 0x18) <=
                                uVar36) goto LAB_;
LAB_:
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100b94;
                            func_0x(lVar12,7);
                          }
                          *(uint *)(&stack0x0000002c + lVar10) = uVar23 - (int)uVar26;
                          plVar30 = (longlong *)(uVar26 + *(longlong *)(psVar11 + 4));
                        }
                      }
                      else if ((*(ushort *)((longlong)puVar35 + 6) & 8) == 0) {
                        if ((*(ushort *)((longlong)puVar35 + 6) & 0x10) != 0) {
                          *(undefined **)(&stack0xffffffffffffffe0 + lVar10) =
                               &stack0x00000148 + lVar10;
                          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1003f3;
                          func_0x(puVar1,puVar35,0,&stack0x00000208 + lVar10);
                          if (*(int *)(&stack0x00000148 + lVar10) == 0) {
                            plVar30 = (longlong *)(*(uint **)(puVar35 + 2) + 1);
                            uVar36 = **(uint **)(puVar35 + 2);
                            if ((uVar25 != 0) && (uVar36 != uVar25)) {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100439;
                              (*_DAT_)(1,0x1918a00,0x1917368,0x381);
                            }
                            *(uint *)(&stack0x0000002c + lVar10) = uVar36;
                            goto LAB_;
                          }
                        }
                        *(uint *)(&stack0x0000002c + lVar10) = (uint)uVar25;
                        plVar30 = (longlong *)((longlong)(int)*puVar35 + *(longlong *)(psVar11 + 4))
                        ;
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100461;
                        plVar30 = (longlong *)func_0x(puVar1,puVar35);
                      }
LAB_:
                      uVar25 = *(ushort *)(*(longlong *)(puVar35 + 0x12) + 0x2a);
                      if (plVar30 != (longlong *)0x0) {
                        lVar20 = *(longlong *)(&stack0x00000088 + lVar10);
                        if ((uVar25 & 0x10) != 0) {
                          lVar20 = *(longlong *)(&stack0x00000090 + lVar10);
                        }
                        *(undefined *)(lVar20 + *(longlong *)(puVar35 + 0xc)) = 0;
                        goto LAB_;
                      }
                    }
                    lVar20 = *(longlong *)(&stack0x00000088 + lVar10);
                    if ((uVar25 & 0x10) != 0) {
                      lVar20 = *(longlong *)(&stack0x00000090 + lVar10);
                    }
                    *(undefined *)(lVar20 + *(longlong *)(puVar35 + 0xc)) = 3;
                    plVar38 = plVar30;
                    goto LAB_;
                  }
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0x14e5b20;
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100301;
                  (*_DAT_)(1,0x18ebeb0,0x1918878,0x27d);
                  plVar30 = plVar38;
                  goto LAB_;
                }
                if (*(int *)(psVar11 + 2) == 0) {
                  *puVar1 = 0;
                  uVar36 = *(uint *)(psVar11 + 8);
                  uVar26 = (ulonglong)uVar36;
                  *(uint *)(psVar11 + 10) = uVar36;
                  pbVar33 = *(byte **)(psVar11 + 4);
                  bVar8 = *pbVar33;
                  pbVar24 = pbVar33;
                  if ((bVar8 & 0x10) != 0) {
                    uVar36 = uVar36 + (*(ushort *)(pbVar33 + uVar26) + 7 >> 3) + 2;
                    uVar26 = (ulonglong)uVar36;
                    *(uint *)(psVar11 + 10) = uVar36;
                    bVar8 = *pbVar33;
                    pbVar24 = *(byte **)(psVar11 + 4);
                  }
                  if ((bVar8 & 0x20) == 0) {
                    *(int *)(psVar11 + 2) = (int)uVar26;
                    psVar11[0xe] = 0;
                    *(uint *)(psVar11 + 0xc) = uVar36;
                  }
                  else {
                    puVar43 = (ushort *)(pbVar33 + uVar26);
                    *(ushort **)(&stack0x00000060 + lVar10) = puVar43;
                    uVar25 = *puVar43;
                    psVar11[0xe] = uVar25;
                    if (uVar25 == 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100d13;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100d1c;
                        lVar20 = func_0x();
                        if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100d36;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100d52;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100d76;
                            (*_DAT_)(1,0x176a5bc,0x188a6a8,0x80f);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar11 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100d84;
                      func_0x(uVar13,3);
                      uVar25 = psVar11[0xe];
                      uVar36 = *(uint *)(psVar11 + 10);
                    }
                    uVar36 = uVar36 + (uVar25 + 1) * 2;
                    *(uint *)(psVar11 + 0xc) = uVar36;
                    if (0x1f9e < uVar36) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100db4;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100dbd;
                        lVar20 = func_0x();
                        if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100dd7;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100df3;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100e17;
                            (*_DAT_)(1,0x176a5bc,0x188a6a8,0x816);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar11 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100e25;
                      func_0x(uVar13,4);
                      uVar25 = psVar11[0xe];
                      uVar36 = *(uint *)(psVar11 + 0xc);
                    }
                    uVar26 = (ulonglong)uVar25;
                    uVar25 = puVar43[uVar26];
                    *(uint *)(psVar11 + 2) = uVar25 & 0x7fff;
                    if ((uVar25 & 0x7fff) < uVar36) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100e53;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100e5c;
                        lVar20 = func_0x();
                        if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100e76;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100e92;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100eb6;
                            (*_DAT_)(1,0x176a5bc,0x188a6a8,0x81d);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar11 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100ec4;
                      func_0x(uVar13,4);
                      uVar36 = *(uint *)(psVar11 + 0xc);
                      uVar26 = (ulonglong)(ushort)psVar11[0xe];
                    }
                    if ((short)uVar26 != 0) {
                      do {
                        puVar43 = puVar43 + 1;
                        uVar23 = *puVar43 & 0x7fff;
                        if ((uVar23 < uVar36) || (*(uint *)(psVar11 + 2) < uVar23)) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100f0f;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100f18;
                            lVar20 = func_0x();
                            if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100f32;
                              cVar7 = func_0x(0x1e7abb0);
                              if (cVar7 == '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100f4e;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100f72;
                                (*_DAT_)(1,0x176a5bc,0x188a6a8,0x82a);
                              }
                            }
                          }
                          uVar13 = *(undefined8 *)(psVar11 + 4);
                          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100f80;
                          func_0x(uVar13,4);
                        }
                        uVar39 = (int)plVar30 + 1;
                        plVar30 = (longlong *)(ulonglong)uVar39;
                        uVar26 = (ulonglong)(ushort)psVar11[0xe];
                        uVar36 = uVar23;
                      } while ((int)uVar39 < (int)(uint)(ushort)psVar11[0xe]);
                      puVar43 = *(ushort **)(&stack0x00000060 + lVar10);
                      iVar40 = *(int *)((longlong)auStackX_18 + lVar10 + 4);
                    }
                    if ((short)puVar43[(ulonglong)((int)uVar26 - 1) + 1] < 0) {
                      do {
                        lVar20 = *(longlong *)(psVar11 + 4);
                        uVar36 = *(ushort *)
                                  ((ulonglong)*(uint *)(psVar11 + 10) + lVar20 + uVar26 * 2) &
                                 0x7fff;
                        if ((int)uVar26 == 1) {
                          uVar23 = *(uint *)(psVar11 + 0xc);
                          uVar39 = uVar23;
LAB_:
                          if ((uVar36 < uVar23) || (*(uint *)(psVar11 + 2) < uVar36))
                          goto LAB_;
                        }
                        else {
                          uVar23 = *(ushort *)
                                    ((ulonglong)*(uint *)(psVar11 + 10) + lVar20 + -2 + uVar26 * 2)
                                   & 0x7fff;
                          uVar39 = *(uint *)(psVar11 + 0xc);
                          if (uVar39 <= uVar23) goto LAB_;
LAB_:
                          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100ffc;
                          func_0x(lVar20,7);
                          uVar39 = *(uint *)(psVar11 + 0xc);
                          lVar20 = *(longlong *)(psVar11 + 4);
                        }
                        if ((uVar23 < uVar39) || (*(uint *)(psVar11 + 2) < uVar23))
                        goto LAB_;
                        if (*(ushort *)((ulonglong)uVar23 + lVar20) == 5) {
                          *puVar1 = *puVar1 | 2;
                          psVar11[0xe] = psVar11[0xe] + -1;
                          psVar11[0x15] = (short)uVar23;
                          uVar26 = *(ulonglong *)(psVar11 + 4);
                          uVar25 = *(ushort *)((ulonglong)(uVar23 & 0xffff) + 2 + uVar26);
                          uVar9 = psVar11[0x16] & 0xc7ff;
                          if ((uVar25 >> 0xe & 1) != 0) {
                            uVar9 = uVar25 & 0x3800 | uVar9;
                          }
                          psVar11[0x16] = uVar9;
                          uVar25 = (uVar9 ^ *(ushort *)((ulonglong)(uVar23 & 0xffff) + 2 + uVar26))
                                   & 0x7ff ^ uVar9;
                          psVar11[0x16] = uVar25;
                          uVar32 = (ulonglong)(ushort)psVar11[0x15];
                          uVar31 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                                   uVar26 + (uVar9 >> 0xb & 7) * 2 + uVar32;
                          if (uVar31 < uVar32 + uVar26) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10110e;
                            func_0x(uVar32 + uVar26,0x19);
                            uVar25 = psVar11[0x16];
                            uVar32 = (ulonglong)(ushort)psVar11[0x15];
                            uVar26 = (ulonglong)*(uint *)(psVar11 + 4);
                          }
                          if (uVar36 - uVar23 <
                              (((uVar25 & 0x7ff) * 2 - (int)uVar32) - (int)uVar26) + (int)uVar31) {
                            lVar20 = *(longlong *)(psVar11 + 4);
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101146;
                            func_0x(uVar32 + lVar20,0x19);
                            uVar25 = psVar11[0x16];
                          }
                          if ((uVar25 & 0x3800) != 0) {
                            puVar43 = (ushort *)
                                      (*(longlong *)(psVar11 + 4) +
                                      (ulonglong)(ushort)psVar11[0x15] + 4);
                            iVar29 = 0;
                            if ((uVar25 & 0x3800) != 0) {
                              do {
                                if ((uVar25 & 0x7ff) < (*puVar43 & 0x7ff)) {
                                  uVar25 = psVar11[0x15];
                                  lVar20 = *(longlong *)(psVar11 + 4);
                                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101198;
                                  func_0x((ulonglong)uVar25 + lVar20,0x1a);
                                  uVar25 = psVar11[0x16];
                                }
                                iVar29 = iVar29 + 1;
                                puVar43 = puVar43 + 1;
                              } while (iVar29 < (int)(uVar25 >> 0xb & 7));
                            }
                          }
                          goto LAB_;
                        }
                        if (*(ushort *)((ulonglong)uVar23 + lVar20) < 0x400) goto LAB_;
                        *puVar1 = *puVar1 | 1;
                        uVar25 = psVar11[0xe] - 1;
                        psVar11[0xe] = uVar25;
                        if (uVar25 == 0) goto LAB_;
                        uVar26 = (ulonglong)uVar25;
                      } while ((short)puVar43[(ulonglong)(uVar25 - 1) + 1] < 0);
                      pbVar24 = *(byte **)(psVar11 + 4);
                    }
                    else {
LAB_:
                      pbVar24 = *(byte **)(psVar11 + 4);
                    }
                  }
                  if ((*pbVar24 & 0x40) == 0) {
                    *(undefined4 *)(psVar11 + 0x13) = 0;
                  }
                  else {
                    *(int *)(psVar11 + 0x13) = *(int *)(psVar11 + 2);
                    *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + 0xe;
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1011e3;
                    uVar13 = func_0x(puVar1);
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1011f2;
                    func_0x(uVar13,&stack0x00000230 + lVar10);
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1011fe;
                    iVar29 = func_0x(&stack0x00000230 + lVar10);
                    *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar29;
                    pbVar24 = *(byte **)(psVar11 + 4);
                  }
                  uVar36 = *(uint *)(psVar11 + 2);
                  if ((*(byte **)(psVar11 + 0xf) != (byte *)0x0) &&
                     (*(byte **)(psVar11 + 0xf) < pbVar24 + uVar36)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101234;
                    cVar7 = func_0x(0x1e7abb0);
                    if (cVar7 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10123d;
                      lVar20 = func_0x();
                      if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101257;
                        cVar7 = func_0x(0x1e7abb0);
                        if (cVar7 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101273;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101297;
                          (*_DAT_)(1,0x176a5bc,0x188a6a8,0x886);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar11 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1012a5;
                    func_0x(uVar13,0x12);
                    uVar36 = *(uint *)(psVar11 + 2);
                  }
                  if (0x3f3b < uVar36 - 1) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1012be;
                    cVar7 = func_0x(0x1e7abb0);
                    if (cVar7 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1012c7;
                      lVar20 = func_0x();
                      if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1012e1;
                        cVar7 = func_0x(0x1e7abb0);
                        if (cVar7 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1012fd;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101321;
                          (*_DAT_)(1,0x176a5bc,0x188a6a8,0x88b);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar11 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10132f;
                    func_0x(uVar13,5);
                  }
                }
LAB_:
                sVar28 = -*(short *)puVar35;
                if ((*(byte *)((longlong)puVar35 + 6) & 0x10) == 0) {
LAB_:
                  lVar20 = (longlong)sVar28;
                  if ((uint)(ushort)psVar11[0xe] < (uint)(int)sVar28) {
                    *(undefined4 *)(&stack0x0000002c + lVar10) = 0;
                    plVar30 = *(longlong **)(psVar11 + 4);
                    iVar29 = 0;
                  }
                  else {
                    lVar12 = *(longlong *)(psVar11 + 4);
                    lVar14 = (ulonglong)*(uint *)(psVar11 + 10) + lVar12;
                    if (sVar28 == 1) {
                      uVar26 = (ulonglong)
                               *(uint *)(*(longlong *)((longlong)&psStackX_20 + lVar10) + 0x18);
                      uVar36 = *(ushort *)(lVar14 + lVar20 * 2) & 0x7fff;
LAB_:
                      if ((uVar36 < (uint)uVar26) || (*(uint *)(psVar11 + 2) < uVar36))
                      goto LAB_;
                    }
                    else {
                      uVar23 = *(ushort *)(lVar14 + -2 + lVar20 * 2) & 0x7fff;
                      uVar26 = (ulonglong)uVar23;
                      uVar36 = *(ushort *)(lVar14 + lVar20 * 2) & 0x7fff;
                      lVar12 = *(longlong *)(psVar11 + 4);
                      if (*(uint *)(*(longlong *)((longlong)&psStackX_20 + lVar10) + 0x18) <= uVar23
                         ) goto LAB_;
LAB_:
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1013e8;
                      func_0x(lVar12,7);
                    }
                    iVar29 = uVar36 - (int)uVar26;
                    *(int *)(&stack0x0000002c + lVar10) = iVar29;
                    plVar30 = (longlong *)(uVar26 + *(longlong *)(psVar11 + 4));
                  }
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe0 + lVar10) = &stack0x00000158 + lVar10;
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101360;
                  func_0x(puVar1,puVar35,0,&stack0x00000218 + lVar10);
                  if (*(int *)(&stack0x00000158 + lVar10) != 0) goto LAB_;
                  piVar17 = *(int **)(puVar35 + 2);
                  iVar29 = *piVar17;
                  *(int *)(&stack0x0000002c + lVar10) = iVar29;
                  plVar30 = (longlong *)(piVar17 + 1);
                }
                if (((puVar35[0x10] & 0x2000) != 0) && (iVar29 == 0)) {
                  *(undefined4 *)(&stack0x0000002c + lVar10) = 4;
                  plVar30 = (longlong *)0x1511184;
                }
                lVar20 = *(longlong *)(&stack0x00000088 + lVar10);
                if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar20 = *(longlong *)(&stack0x00000090 + lVar10);
                }
                *(undefined *)(lVar20 + *(longlong *)(puVar35 + 0xc)) = 0;
                if ((1 << (**(byte **)(psVar11 + 4) & 0xe) & 0x440U) != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101460;
                  iVar29 = func_0x(puVar35);
                  if (iVar29 != 0) goto LAB_;
                }
                if ((uint)*(ushort *)(puVar35 + 0xf) < *(uint *)(&stack0x0000002c + lVar10)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10148d;
                  (*_DAT_)(6,0x52,0x16,0x91);
                }
              }
LAB_:
              uVar36 = *(uint *)(&stack0x0000002c + lVar10);
              lVar20 = *(longlong *)(puVar35 + 0x12);
              if ((puVar35[0x10] & 0x800) == 0) {
                lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
                if ((*(byte *)(lVar20 + 0x2a) & 0x10) != 0) {
                  lVar12 = *(longlong *)(&stack0x00000090 + lVar10);
                }
                lVar20 = *(longlong *)(puVar35 + 10);
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1015fe;
                func_0x(lVar12 + lVar20,plVar30);
              }
              else {
                uVar25 = *(ushort *)(lVar20 + 0x2a) & 0x10;
                if (*(int *)(lVar20 + 0x10) == 10) {
                  lVar20 = *(longlong *)(&stack0x00000088 + lVar10);
                  if (uVar25 != 0) {
                    lVar20 = *(longlong *)(&stack0x00000090 + lVar10);
                  }
                  *(longlong **)(lVar20 + *(longlong *)(puVar35 + 10)) = plVar30;
                }
                else {
                  lVar20 = *(longlong *)(&stack0x00000088 + lVar10);
                  if (uVar25 != 0) {
                    lVar20 = *(longlong *)(&stack0x00000090 + lVar10);
                  }
                  uVar13 = *(undefined8 *)(*(longlong *)(puVar35 + 10) + lVar20);
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101631;
                  func_0x(uVar13,plVar30);
                }
              }
              plVar38 = plVar30;
              if ((puVar35[0x10] & 0x100) != 0) {
                lVar20 = *(longlong *)(&stack0x00000088 + lVar10);
                if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar20 = *(longlong *)(&stack0x00000090 + lVar10);
                }
                *(ulonglong *)(lVar20 + *(longlong *)(*(longlong *)(puVar35 + 0x12) + 0x18)) =
                     (ulonglong)uVar36;
              }
            }
LAB_:
            uVar36 = iVar40 + 1;
            plVar37 = (longlong *)(ulonglong)uVar36;
            *(uint *)((longlong)auStackX_18 + lVar10 + 4) = uVar36;
            puVar35 = puVar35 + 0x14;
          } while (uVar36 < *(uint *)(&stack0x00000058 + lVar10));
        }
        plVar37 = *(longlong **)(&stack0x000000f8 + lVar10);
        goto LAB_;
      }
    }
    psVar16 = psVar11;
    if (plVar37 != (longlong *)0x0) {
      *(longlong **)(&stack0x00000180 + lVar10) = plVar37;
      pcVar5 = *(code **)*plVar37;
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1016fc;
      psVar16 = (short *)(*pcVar5)(plVar37);
      uVar26 = (ulonglong)*(uint *)(&stack0x00000084 + lVar10);
      psVar11 = *(short **)((longlong)&psStackX_20 + lVar10);
    }
    *(short **)(&stack0x00000178 + lVar10) = psVar16;
    *(short **)(&stack0x00000048 + lVar10) = psVar16;
    if (*psVar11 == 0) {
      *psVar11 = 0;
      puVar1 = (ushort *)(psVar11 + 1);
      puVar27 = &stack0xffffffffffffffc0 + lVar10;
      if (((&stack0x00000084)[lVar10] & 0x10) != 0) {
        iVar40 = *(int *)(&stack0x00000080 + lVar10);
        *(int *)(&stack0x00000058 + lVar10) = iVar40;
        puVar35 = *(uint **)(&stack0x00000078 + lVar10);
        *(uint **)(&stack0x00000050 + lVar10) = puVar35;
        *(undefined4 *)((longlong)auStackX_18 + lVar10 + 4) = 0;
        puVar27 = &stack0xffffffffffffffc0 + lVar10;
        psVar16 = psVar11;
        plVar37 = plVar38;
        if (iVar40 != 0) {
LAB_:
          iVar40 = (int)plVar38;
          switch(*(undefined *)(puVar35 + 0x10)) {
          case 0:
            goto code_r0x001020b4;
          case 1:
            *(undefined **)(&stack0xffffffffffffffe0 + lVar10) = &stack0x00000224 + lVar10;
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1017b0;
            func_0x(puVar1,puVar35,1,&stack0x00000144 + lVar10);
            if (*(int *)(&stack0x00000144 + lVar10) == 0) goto code_r0x001017c8;
          case 0xd:
          case 0x1b:
            plVar37 = (longlong *)0x0;
            *(undefined4 *)(&stack0x00000028 + lVar10) = 0;
            break;
          case 2:
code_r0x001017c8:
            uVar25 = *(ushort *)(puVar35 + 0xf);
            if ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0) {
              *(undefined **)(&stack0xffffffffffffffe0 + lVar10) = &stack0x0000013c + lVar10;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1017f7;
              func_0x(puVar1,puVar35,0,&stack0x00000250 + lVar10);
              if (*(int *)(&stack0x0000013c + lVar10) == 0) {
                plVar37 = (longlong *)(*(uint **)(puVar35 + 2) + 1);
                uVar36 = **(uint **)(puVar35 + 2);
                if ((uVar25 == 0) || (uVar36 == uVar25)) {
                  *(uint *)(&stack0x00000028 + lVar10) = uVar36;
                  iVar40 = *(int *)((longlong)auStackX_18 + lVar10 + 4);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101839;
                  (*_DAT_)(1,0x1918a00,0x1917368,0x381);
                  *(uint *)(&stack0x00000028 + lVar10) = uVar36;
                  iVar40 = *(int *)((longlong)auStackX_18 + lVar10 + 4);
                }
                break;
              }
            }
            *(uint *)(&stack0x00000028 + lVar10) = (uint)uVar25;
            plVar37 = (longlong *)((longlong)(int)*puVar35 + *(longlong *)(psVar11 + 4));
            break;
          case 3:
            *(undefined **)(&stack0xffffffffffffffe0 + lVar10) = &stack0x000002a0 + lVar10;
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101888;
            func_0x(puVar1,puVar35,1,&stack0x00000138 + lVar10);
            if (*(int *)(&stack0x00000138 + lVar10) == 0) goto code_r0x001018a5;
            plVar37 = (longlong *)0x0;
            *(undefined4 *)(&stack0x00000028 + lVar10) = 0;
            break;
          case 4:
code_r0x001018a5:
            iVar40 = 0;
            if (*(int *)(psVar11 + 2) == 0) {
              *puVar1 = 0;
              uVar36 = *(uint *)(psVar11 + 8);
              uVar26 = (ulonglong)uVar36;
              *(uint *)(psVar11 + 10) = uVar36;
              pbVar33 = *(byte **)(psVar11 + 4);
              bVar8 = *pbVar33;
              pbVar24 = pbVar33;
              if ((bVar8 & 0x10) != 0) {
                uVar36 = uVar36 + (*(ushort *)(pbVar33 + uVar26) + 7 >> 3) + 2;
                uVar26 = (ulonglong)uVar36;
                *(uint *)(psVar11 + 10) = uVar36;
                bVar8 = *pbVar33;
                pbVar24 = *(byte **)(psVar11 + 4);
              }
              if ((bVar8 & 0x20) == 0) {
                *(int *)(psVar11 + 2) = (int)uVar26;
                psVar11[0xe] = 0;
                *(uint *)(psVar11 + 0xc) = uVar36;
              }
              else {
                puVar43 = (ushort *)(pbVar33 + uVar26);
                uVar25 = *puVar43;
                psVar11[0xe] = uVar25;
                if (uVar25 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101915;
                  cVar7 = func_0x(0x1e7abb0);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10191e;
                    lVar20 = func_0x();
                    if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101938;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101954;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101977;
                        (*_DAT_)(1,0x176a5bc,0x188a6a8,0x80f);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar11 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101985;
                  func_0x(uVar13,3);
                  uVar25 = psVar11[0xe];
                  uVar36 = *(uint *)(psVar11 + 10);
                }
                uVar36 = uVar36 + (uVar25 + 1) * 2;
                *(uint *)(psVar11 + 0xc) = uVar36;
                if (0x1f9e < uVar36) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1019b4;
                  cVar7 = func_0x(0x1e7abb0);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1019bd;
                    lVar20 = func_0x();
                    if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1019d7;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1019f3;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101a16;
                        (*_DAT_)(1,0x176a5bc,0x188a6a8,0x816);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar11 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101a24;
                  func_0x(uVar13,4);
                  uVar25 = psVar11[0xe];
                  uVar36 = *(uint *)(psVar11 + 0xc);
                }
                uVar26 = (ulonglong)uVar25;
                uVar25 = puVar43[uVar26];
                *(uint *)(psVar11 + 2) = uVar25 & 0x7fff;
                if ((uVar25 & 0x7fff) < uVar36) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101a52;
                  cVar7 = func_0x(0x1e7abb0);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101a5b;
                    lVar20 = func_0x();
                    if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101a75;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101a91;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101ab4;
                        (*_DAT_)(1,0x176a5bc,0x188a6a8,0x81d);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar11 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101ac2;
                  func_0x(uVar13,4);
                  uVar36 = *(uint *)(psVar11 + 0xc);
                  uVar26 = (ulonglong)(ushort)psVar11[0xe];
                }
                puVar6 = puVar43;
                iVar29 = iVar40;
                if ((short)uVar26 != 0) {
                  do {
                    uVar23 = puVar6[1] & 0x7fff;
                    if ((uVar23 < uVar36) || (*(uint *)(psVar11 + 2) < uVar23)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101b00;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101b09;
                        lVar20 = func_0x();
                        if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101b23;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101b3f;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101b63;
                            (*_DAT_)(1,0x176a5bc,0x188a6a8,0x82a);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar11 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101b71;
                      func_0x(uVar13,4);
                    }
                    iVar29 = iVar29 + 1;
                    uVar26 = (ulonglong)(ushort)psVar11[0xe];
                    puVar6 = puVar6 + 1;
                    uVar36 = uVar23;
                  } while (iVar29 < (int)(uint)(ushort)psVar11[0xe]);
                  puVar35 = *(uint **)(&stack0x00000050 + lVar10);
                }
                if ((short)puVar43[(ulonglong)((int)uVar26 - 1) + 1] < 0) {
                  do {
                    lVar20 = *(longlong *)(psVar11 + 4);
                    lVar12 = *(longlong *)((longlong)&psStackX_20 + lVar10);
                    uVar36 = *(ushort *)((ulonglong)*(uint *)(psVar11 + 10) + lVar20 + uVar26 * 2) &
                             0x7fff;
                    if ((int)uVar26 == 1) {
                      uVar23 = *(uint *)(psVar11 + 0xc);
                      uVar39 = uVar23;
code_r0x00101bd7:
                      if ((uVar36 < uVar23) || (*(uint *)(psVar11 + 2) < uVar36))
                      goto code_r0x00101be0;
                    }
                    else {
                      uVar23 = *(ushort *)
                                ((ulonglong)*(uint *)(psVar11 + 10) + lVar20 + -2 + uVar26 * 2) &
                               0x7fff;
                      uVar39 = *(uint *)(lVar12 + 0x18);
                      if (uVar39 <= uVar23) goto code_r0x00101bd7;
code_r0x00101be0:
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101bed;
                      func_0x(lVar20,7);
                      uVar39 = *(uint *)(lVar12 + 0x18);
                      lVar20 = *(longlong *)(lVar12 + 8);
                    }
                    if ((uVar23 < uVar39) || (*(uint *)(psVar11 + 2) < uVar23))
                    goto code_r0x00101f29;
                    if (*(ushort *)((ulonglong)uVar23 + lVar20) == 5) {
                      *puVar1 = *puVar1 | 2;
                      psVar11[0xe] = psVar11[0xe] + -1;
                      psVar11[0x15] = (short)uVar23;
                      uVar26 = *(ulonglong *)(psVar11 + 4);
                      uVar25 = *(ushort *)((ulonglong)(uVar23 & 0xffff) + 2 + uVar26);
                      uVar9 = psVar11[0x16] & 0xc7ff;
                      if ((uVar25 >> 0xe & 1) != 0) {
                        uVar9 = uVar25 & 0x3800 | uVar9;
                      }
                      psVar11[0x16] = uVar9;
                      uVar25 = (uVar9 ^ *(ushort *)((ulonglong)(uVar23 & 0xffff) + 2 + uVar26)) &
                               0x7ff ^ uVar9;
                      psVar11[0x16] = uVar25;
                      uVar32 = (ulonglong)(ushort)psVar11[0x15];
                      uVar31 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                               uVar26 + (uVar9 >> 0xb & 7) * 2 + uVar32;
                      if (uVar31 < uVar32 + uVar26) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101cf9;
                        func_0x(uVar32 + uVar26,0x19);
                        uVar25 = psVar11[0x16];
                        uVar32 = (ulonglong)(ushort)psVar11[0x15];
                        uVar26 = (ulonglong)*(uint *)(psVar11 + 4);
                      }
                      if (uVar36 - uVar23 <
                          (((uVar25 & 0x7ff) * 2 - (int)uVar32) - (int)uVar26) + (int)uVar31) {
                        lVar20 = *(longlong *)(psVar11 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101d31;
                        func_0x(uVar32 + lVar20,0x19);
                        uVar25 = psVar11[0x16];
                      }
                      if (((uVar25 & 0x3800) != 0) &&
                         (puVar43 = (ushort *)
                                    (*(longlong *)(psVar11 + 4) + 4 +
                                    (ulonglong)(ushort)psVar11[0x15]), (uVar25 & 0x3800) != 0)) {
                        do {
                          if ((uVar25 & 0x7ff) < (*puVar43 & 0x7ff)) {
                            uVar25 = psVar11[0x15];
                            lVar20 = *(longlong *)(psVar11 + 4);
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101d87;
                            func_0x((ulonglong)uVar25 + lVar20,0x1a);
                            uVar25 = psVar11[0x16];
                          }
                          iVar40 = iVar40 + 1;
                          puVar43 = puVar43 + 1;
                        } while (iVar40 < (int)(uVar25 >> 0xb & 7));
                      }
                      goto code_r0x00101da2;
                    }
                    if (*(ushort *)((ulonglong)uVar23 + lVar20) < 0x400) goto code_r0x00101da2;
                    *puVar1 = *puVar1 | 1;
                    uVar25 = psVar11[0xe] - 1;
                    psVar11[0xe] = uVar25;
                    if (uVar25 == 0) goto code_r0x00101da2;
                    uVar26 = (ulonglong)uVar25;
                  } while ((short)puVar43[(ulonglong)(uVar25 - 1) + 1] < 0);
                  pbVar24 = *(byte **)(psVar11 + 4);
                }
                else {
code_r0x00101da2:
                  pbVar24 = *(byte **)(psVar11 + 4);
                }
              }
              if ((*pbVar24 & 0x40) == 0) {
                *(undefined4 *)(psVar11 + 0x13) = 0;
                lVar20 = *(longlong *)((longlong)&psStackX_20 + lVar10);
                uVar36 = *(uint *)(lVar20 + 4);
              }
              else {
                *(int *)(psVar11 + 0x13) = *(int *)(psVar11 + 2);
                *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + 0xe;
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101dcd;
                uVar13 = func_0x(puVar1);
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101ddc;
                func_0x(uVar13,&stack0x00000238 + lVar10);
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101de8;
                iVar40 = func_0x(&stack0x00000238 + lVar10);
                *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar40;
                uVar36 = *(uint *)(psVar11 + 2);
                pbVar24 = *(byte **)(psVar11 + 4);
                lVar20 = *(longlong *)((longlong)&psStackX_20 + lVar10);
              }
              if ((*(byte **)(psVar11 + 0xf) != (byte *)0x0) &&
                 (*(byte **)(psVar11 + 0xf) < pbVar24 + uVar36)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101e2a;
                cVar7 = func_0x(0x1e7abb0);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101e33;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101e4d;
                    cVar7 = func_0x(0x1e7abb0);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101e69;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101e8f;
                      (*_DAT_)(1,0x176a5bc,0x188a6a8,0x886);
                    }
                  }
                }
                uVar13 = *(undefined8 *)(psVar11 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101e9d;
                func_0x(uVar13);
                uVar36 = *(uint *)(lVar20 + 4);
              }
              if (0x3f3b < uVar36 - 1) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101eb6;
                cVar7 = func_0x(0x1e7abb0);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101ebf;
                  lVar20 = func_0x();
                  if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101ed9;
                    cVar7 = func_0x(0x1e7abb0);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101ef5;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101f1b;
                      (*_DAT_)(1,0x176a5bc,0x188a6a8,0x88b);
                    }
                  }
                }
                uVar13 = *(undefined8 *)(psVar11 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101f29;
                func_0x(uVar13);
              }
            }
code_r0x00101f29:
            sVar28 = -*(short *)puVar35;
            if ((*(byte *)((longlong)puVar35 + 6) & 0x10) == 0) {
code_r0x00101f73:
              lVar20 = (longlong)sVar28;
              if ((uint)(int)sVar28 <= (uint)(ushort)psVar11[0xe]) {
                lVar12 = *(longlong *)(psVar11 + 4);
                lVar14 = (ulonglong)*(uint *)(psVar11 + 10) + lVar12;
                if (sVar28 == 1) {
                  uVar36 = *(uint *)(psVar11 + 0xc);
                  uVar23 = *(ushort *)(lVar14 + lVar20 * 2) & 0x7fff;
code_r0x00101fc2:
                  if ((uVar23 < uVar36) || (*(uint *)(psVar11 + 2) < uVar23)) goto code_r0x00101fcb;
                }
                else {
                  uVar36 = *(ushort *)(lVar14 + -2 + lVar20 * 2) & 0x7fff;
                  uVar23 = *(ushort *)(lVar14 + lVar20 * 2) & 0x7fff;
                  lVar12 = *(longlong *)(*(longlong *)((longlong)&psStackX_20 + lVar10) + 8);
                  if (*(uint *)(*(longlong *)((longlong)&psStackX_20 + lVar10) + 0x18) <= uVar36)
                  goto code_r0x00101fc2;
code_r0x00101fcb:
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101fd8;
                  func_0x(lVar12);
                }
                iVar40 = uVar23 - uVar36;
                *(int *)(&stack0x00000028 + lVar10) = iVar40;
                plVar37 = (longlong *)((ulonglong)uVar36 + *(longlong *)(psVar11 + 4));
                goto code_r0x00101fe4;
              }
              *(undefined4 *)(&stack0x00000028 + lVar10) = 0;
              plVar37 = *(longlong **)(psVar11 + 4);
code_r0x00101ff2:
              if ((puVar35[0x10] & 0x2000) != 0) {
                *(undefined4 *)(&stack0x00000028 + lVar10) = 4;
                plVar37 = (longlong *)0x1511184;
              }
            }
            else {
              *(undefined **)(&stack0xffffffffffffffe0 + lVar10) = &stack0x00000154 + lVar10;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101f5a;
              func_0x(puVar1,puVar35,0,&stack0x000002a4 + lVar10);
              if (*(int *)(&stack0x00000154 + lVar10) != 0) goto code_r0x00101f73;
              piVar17 = *(int **)(puVar35 + 2);
              iVar40 = *piVar17;
              *(int *)(&stack0x00000028 + lVar10) = iVar40;
              plVar37 = (longlong *)(piVar17 + 1);
code_r0x00101fe4:
              if (iVar40 == 0) goto code_r0x00101ff2;
            }
            if ((1 << (**(byte **)(psVar11 + 4) & 0xe) & 0x440U) != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10202b;
              iVar40 = func_0x(puVar35);
              if (iVar40 != 0) goto code_r0x00102050;
            }
            if ((uint)*(ushort *)(puVar35 + 0xf) < *(uint *)(&stack0x00000028 + lVar10)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102050;
              (*_DAT_)(6,0x52,0x16,0x91);
            }
            goto code_r0x00102050;
          case 5:
            plVar37 = *(longlong **)(psVar11 + 4);
            uVar36 = *(uint *)(psVar11 + 2);
            if (uVar36 == 0) {
              iVar40 = 0;
              *puVar1 = 0;
              uVar36 = *(uint *)(psVar11 + 8);
              uVar26 = (ulonglong)uVar36;
              *(uint *)(psVar11 + 10) = uVar36;
              pbVar33 = *(byte **)(psVar11 + 4);
              bVar8 = *pbVar33;
              if ((bVar8 & 0x10) != 0) {
                uVar36 = uVar36 + (*(ushort *)(pbVar33 + uVar26) + 7 >> 3) + 2;
                uVar26 = (ulonglong)uVar36;
                *(uint *)(psVar11 + 10) = uVar36;
                bVar8 = *pbVar33;
              }
              if ((bVar8 & 0x20) == 0) {
                *(int *)(psVar11 + 2) = (int)uVar26;
                psVar11[0xe] = 0;
                *(uint *)(psVar11 + 0xc) = uVar36;
              }
              else {
                puVar43 = (ushort *)(pbVar33 + uVar26);
                *(ushort **)(&stack0x00000048 + lVar10) = puVar43;
                uVar25 = *puVar43;
                psVar11[0xe] = uVar25;
                if (uVar25 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102a75;
                  cVar7 = func_0x(0x1e7abb0);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102a7e;
                    lVar20 = func_0x();
                    if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102a98;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102ab4;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102ada;
                        (*_DAT_)(1,0x176a5bc,0x188a6a8,0x80f);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar11 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102ae5;
                  func_0x(uVar13,3);
                  uVar25 = psVar11[0xe];
                  uVar36 = *(uint *)(psVar11 + 10);
                }
                uVar36 = uVar36 + (uVar25 + 1) * 2;
                *(uint *)(psVar11 + 0xc) = uVar36;
                if (0x1f9e < uVar36) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102b14;
                  cVar7 = func_0x(0x1e7abb0);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102b1d;
                    lVar20 = func_0x();
                    if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102b37;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102b53;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102b79;
                        (*_DAT_)(1,0x176a5bc,0x188a6a8,0x816);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar11 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102b87;
                  func_0x(uVar13,4);
                  uVar25 = psVar11[0xe];
                  uVar36 = *(uint *)(psVar11 + 0xc);
                }
                uVar26 = (ulonglong)uVar25;
                uVar25 = puVar43[uVar26];
                *(uint *)(psVar11 + 2) = uVar25 & 0x7fff;
                if ((uVar25 & 0x7fff) < uVar36) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102bb5;
                  cVar7 = func_0x(0x1e7abb0);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102bbe;
                    lVar20 = func_0x();
                    if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102bd8;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102bf4;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102c1a;
                        (*_DAT_)(1,0x176a5bc,0x188a6a8,0x81d);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar11 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102c28;
                  func_0x(uVar13,4);
                  uVar36 = *(uint *)(*(longlong *)((longlong)&psStackX_20 + lVar10) + 0x18);
                  uVar26 = (ulonglong)(ushort)psVar11[0xe];
                }
                if ((short)uVar26 != 0) {
                  do {
                    puVar43 = puVar43 + 1;
                    uVar23 = *puVar43 & 0x7fff;
                    if ((uVar23 < uVar36) || (*(uint *)(psVar11 + 2) < uVar23)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102c6f;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102c78;
                        lVar20 = func_0x();
                        if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102c92;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102cae;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102cd2;
                            (*_DAT_)(1,0x176a5bc,0x188a6a8,0x82a);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar11 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102ce0;
                      func_0x(uVar13,4);
                    }
                    iVar40 = iVar40 + 1;
                    uVar26 = (ulonglong)(ushort)psVar11[0xe];
                    uVar36 = uVar23;
                  } while (iVar40 < (int)(uint)(ushort)psVar11[0xe]);
                  puVar43 = *(ushort **)(&stack0x00000048 + lVar10);
                  puVar35 = *(uint **)(&stack0x00000050 + lVar10);
                }
                psVar16 = *(short **)((longlong)&psStackX_20 + lVar10);
                if ((short)puVar43[(ulonglong)((int)uVar26 - 1) + 1] < 0) {
                  do {
                    lVar20 = *(longlong *)(psVar11 + 4);
                    lVar12 = (ulonglong)*(uint *)(psVar11 + 10) + lVar20;
                    uVar23 = *(ushort *)(lVar12 + uVar26 * 2) & 0x7fff;
                    if ((int)uVar26 == 1) {
                      uVar39 = *(uint *)(psVar11 + 0xc);
                      uVar3 = uVar39;
code_r0x00102d56:
                      if ((uVar23 < uVar39) || (uVar36 = *(uint *)(psVar11 + 2), uVar36 < uVar23))
                      goto code_r0x00102d61;
                    }
                    else {
                      uVar39 = *(ushort *)(lVar12 + -2 + uVar26 * 2) & 0x7fff;
                      uVar3 = *(uint *)(psVar16 + 0xc);
                      if (uVar3 <= uVar39) goto code_r0x00102d56;
code_r0x00102d61:
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102d6e;
                      func_0x(lVar20,7);
                      psVar16 = *(short **)((longlong)&psStackX_20 + lVar10);
                      uVar3 = *(uint *)(psVar16 + 0xc);
                      uVar36 = *(uint *)(psVar16 + 2);
                    }
                    if ((uVar39 < uVar3) || (uVar36 < uVar39)) goto code_r0x001030c6;
                    if (*(ushort *)((ulonglong)uVar39 + *(longlong *)(psVar11 + 4)) == 5) {
                      *puVar1 = *puVar1 | 2;
                      psVar11[0xe] = psVar11[0xe] + -1;
                      psVar11[0x15] = (short)uVar39;
                      uVar26 = *(ulonglong *)(psVar11 + 4);
                      uVar25 = *(ushort *)((ulonglong)(uVar39 & 0xffff) + 2 + uVar26);
                      uVar9 = psVar11[0x16] & 0xc7ff;
                      if ((uVar25 >> 0xe & 1) != 0) {
                        uVar9 = uVar25 & 0x3800 | uVar9;
                      }
                      psVar11[0x16] = uVar9;
                      uVar25 = (uVar9 ^ *(ushort *)((ulonglong)(uVar39 & 0xffff) + 2 + uVar26)) &
                               0x7ff ^ uVar9;
                      psVar11[0x16] = uVar25;
                      uVar32 = (ulonglong)(ushort)psVar11[0x15];
                      uVar31 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                               uVar32 + (uVar9 >> 0xb & 7) * 2 + uVar26;
                      if (uVar31 < uVar32 + uVar26) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102e83;
                        func_0x(uVar32 + uVar26,0x19);
                        uVar25 = psVar11[0x16];
                        uVar32 = (ulonglong)(ushort)psVar11[0x15];
                        uVar26 = (ulonglong)*(uint *)(psVar11 + 4);
                      }
                      if (uVar23 - uVar39 <
                          (((uVar25 & 0x7ff) * 2 - (int)uVar32) - (int)uVar26) + (int)uVar31) {
                        lVar20 = *(longlong *)(psVar11 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102ebb;
                        func_0x(uVar32 + lVar20,0x19);
                        uVar25 = psVar11[0x16];
                      }
                      if ((uVar25 & 0x3800) != 0) {
                        puVar43 = (ushort *)
                                  (*(longlong *)(psVar11 + 4) + (ulonglong)(ushort)psVar11[0x15] + 4
                                  );
                        iVar40 = 0;
                        if ((uVar25 & 0x3800) != 0) {
                          do {
                            if ((uVar25 & 0x7ff) < (*puVar43 & 0x7ff)) {
                              uVar25 = psVar11[0x15];
                              lVar20 = *(longlong *)(psVar11 + 4);
                              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102f17;
                              func_0x((ulonglong)uVar25 + lVar20,0x1a);
                              uVar25 = psVar11[0x16];
                            }
                            iVar40 = iVar40 + 1;
                            puVar43 = puVar43 + 1;
                          } while (iVar40 < (int)(uVar25 >> 0xb & 7));
                        }
                      }
                      psVar16 = *(short **)((longlong)&psStackX_20 + lVar10);
                      goto code_r0x00102f36;
                    }
                    if (*(ushort *)((ulonglong)uVar39 + *(longlong *)(psVar11 + 4)) < 0x400)
                    goto code_r0x00102f36;
                    *puVar1 = *puVar1 | 1;
                    uVar25 = psVar11[0xe] - 1;
                    psVar11[0xe] = uVar25;
                    if (uVar25 == 0) goto code_r0x00102f36;
                    uVar26 = (ulonglong)uVar25;
                  } while ((short)puVar43[(ulonglong)(uVar25 - 1) + 1] < 0);
                  pbVar33 = *(byte **)(psVar11 + 4);
                }
                else {
code_r0x00102f36:
                  pbVar33 = *(byte **)(psVar11 + 4);
                }
              }
              if ((*pbVar33 & 0x40) == 0) {
                *(undefined4 *)(psVar11 + 0x13) = 0;
                uVar36 = *(uint *)(psVar16 + 2);
              }
              else {
                *(int *)(psVar11 + 0x13) = *(int *)(psVar11 + 2);
                *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + 0xe;
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102f62;
                uVar13 = func_0x(puVar1);
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102f71;
                func_0x(uVar13,&stack0x00000248 + lVar10);
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102f7d;
                iVar40 = func_0x(&stack0x00000248 + lVar10);
                *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar40;
                uVar36 = *(uint *)(psVar11 + 2);
              }
              if ((*(ulonglong *)(psVar11 + 0xf) == 0) ||
                 ((ulonglong)uVar36 + *(longlong *)(psVar11 + 4) <= *(ulonglong *)(psVar11 + 0xf)))
              {
                lVar20 = *(longlong *)((longlong)&psStackX_20 + lVar10);
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102fb4;
                cVar7 = func_0x(0x1e7abb0);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102fbd;
                  lVar20 = func_0x();
                  if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102fd7;
                    cVar7 = func_0x(0x1e7abb0);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102ff3;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103019;
                      (*_DAT_)(1,0x176a5bc,0x188a6a8,0x886);
                    }
                  }
                }
                uVar13 = *(undefined8 *)(psVar11 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103027;
                func_0x(uVar13);
                lVar20 = *(longlong *)((longlong)&psStackX_20 + lVar10);
                uVar36 = *(uint *)(lVar20 + 4);
              }
              if ((uVar36 == 0) || (0x3f3c < uVar36)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103050;
                cVar7 = func_0x(0x1e7abb0);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103059;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103073;
                    cVar7 = func_0x(0x1e7abb0);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10308f;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1030b5;
                      (*_DAT_)(1,0x176a5bc,0x188a6a8,0x88b);
                    }
                  }
                }
                uVar13 = *(undefined8 *)(psVar11 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1030c3;
                func_0x(uVar13);
                uVar36 = *(uint *)(lVar20 + 4);
              }
            }
code_r0x001030c6:
            if ((uVar36 < 9) &&
               (((**(byte **)(psVar11 + 4) & 0xe) == 0 || ((**(byte **)(psVar11 + 4) & 0xe) == 0xc))
               )) {
              uVar36 = 9;
            }
            *(uint *)(&stack0x00000028 + lVar10) = uVar36;
code_r0x00102050:
            iVar40 = *(int *)((longlong)auStackX_18 + lVar10 + 4);
            break;
          case 6:
          case 7:
          case 9:
          case 10:
          case 0xb:
          case 0xe:
          case 0xf:
          case 0x19:
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1030fc;
            func_0x(&stack0x00000170 + lVar10);
            goto LAB_;
          case 8:
            iVar40 = puVar35[0x10] << 0xc;
            iVar29 = 0;
            uVar25 = *(ushort *)(puVar35 + 0xf);
            if ((*puVar35 & 0xc0000000) == 0x80000000) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1029d0;
              iVar40 = func_0x(puVar1);
              if (iVar40 == 0) {
                *(undefined4 *)(&stack0x00000028 + lVar10) = 0;
                plVar37 = (longlong *)0x0;
                iVar40 = *(int *)((longlong)auStackX_18 + lVar10 + 4);
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1029eb;
                plVar37 = (longlong *)
                          func_0x(psVar11 + 0x15,puVar35,&stack0x00000028 + lVar10,
                                          &stack0x000001d4 + lVar10);
                iVar40 = *(int *)((longlong)auStackX_18 + lVar10 + 4);
              }
              break;
            }
            if ((iVar40 < 0) || ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0)) {
              *(undefined **)(&stack0xffffffffffffffe0 + lVar10) = &stack0x000000f4 + lVar10;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10214b;
              func_0x(puVar1,puVar35,iVar40 < 0,&stack0x000000d8 + lVar10);
              if ((iVar40 < 0) && (*(int *)(&stack0x000000d8 + lVar10) != 0)) {
                *(undefined4 *)(&stack0x00000028 + lVar10) = 0;
                plVar37 = (longlong *)0x0;
                iVar40 = *(int *)((longlong)auStackX_18 + lVar10 + 4);
                break;
              }
              iVar40 = *(int *)(&stack0x000000f4 + lVar10);
            }
            else {
              *(undefined4 *)(&stack0x000000d8 + lVar10) = 0;
              iVar40 = 1;
              *(undefined4 *)(&stack0x000000f4 + lVar10) = 1;
            }
            if ((iVar40 == 0) && ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0)) {
              puVar19 = *(undefined4 **)(puVar35 + 2);
              *(undefined4 *)(&stack0x00000028 + lVar10) = *puVar19;
              plVar37 = (longlong *)(puVar19 + 1);
              iVar40 = *(int *)((longlong)auStackX_18 + lVar10 + 4);
              break;
            }
            if (-1 < (int)*puVar35) {
              if ((*(ushort *)((longlong)puVar35 + 6) & 8) == 0) {
                if ((*(ushort *)((longlong)puVar35 + 6) & 0x10) != 0) {
                  *(undefined **)(&stack0xffffffffffffffe0 + lVar10) = &stack0x00000100 + lVar10;
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1021d1;
                  func_0x(puVar1,puVar35,0,&stack0x000002a8 + lVar10);
                  if (*(int *)(&stack0x00000100 + lVar10) == 0) {
                    plVar37 = (longlong *)(*(uint **)(puVar35 + 2) + 1);
                    uVar36 = **(uint **)(puVar35 + 2);
                    if ((uVar25 != 0) && (uVar36 != uVar25)) {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102211;
                      (*_DAT_)(1,0x1918a00,0x1917368,0x381);
                    }
                    *(uint *)(&stack0x00000028 + lVar10) = uVar36;
                    iVar40 = *(int *)((longlong)auStackX_18 + lVar10 + 4);
                    break;
                  }
                }
                *(uint *)(&stack0x00000028 + lVar10) = (uint)uVar25;
                plVar37 = (longlong *)((longlong)(int)*puVar35 + *(longlong *)(psVar11 + 4));
                iVar40 = *(int *)((longlong)auStackX_18 + lVar10 + 4);
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10223e;
                plVar37 = (longlong *)func_0x(puVar1);
                iVar40 = *(int *)((longlong)auStackX_18 + lVar10 + 4);
              }
              break;
            }
            if (*(int *)(psVar11 + 2) == 0) {
              *puVar1 = 0;
              uVar36 = *(uint *)(psVar11 + 8);
              uVar26 = (ulonglong)uVar36;
              *(uint *)(psVar11 + 10) = uVar36;
              pbVar33 = *(byte **)(psVar11 + 4);
              bVar8 = *pbVar33;
              if ((bVar8 & 0x10) != 0) {
                uVar36 = uVar36 + (*(ushort *)(pbVar33 + uVar26) + 7 >> 3) + 2;
                uVar26 = (ulonglong)uVar36;
                *(uint *)(psVar11 + 10) = uVar36;
                bVar8 = *pbVar33;
              }
              if ((bVar8 & 0x20) == 0) {
                *(int *)(psVar11 + 2) = (int)uVar26;
                psVar11[0xe] = 0;
                *(uint *)(psVar11 + 0xc) = uVar36;
              }
              else {
                puVar43 = (ushort *)(pbVar33 + uVar26);
                uVar25 = *puVar43;
                psVar11[0xe] = uVar25;
                if (uVar25 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1022af;
                  cVar7 = func_0x(0x1e7abb0);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1022b8;
                    lVar20 = func_0x();
                    if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1022d2;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1022ee;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102311;
                        (*_DAT_)(1,0x176a5bc,0x188a6a8,0x80f);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar11 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10231f;
                  func_0x(uVar13,3);
                  uVar25 = psVar11[0xe];
                  uVar36 = *(uint *)(psVar11 + 10);
                }
                uVar36 = uVar36 + (uVar25 + 1) * 2;
                *(uint *)(psVar11 + 0xc) = uVar36;
                if (0x1f9e < uVar36) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10234e;
                  cVar7 = func_0x(0x1e7abb0);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102357;
                    lVar20 = func_0x();
                    if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102371;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10238d;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1023b0;
                        (*_DAT_)(1,0x176a5bc,0x188a6a8,0x816);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar11 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1023be;
                  func_0x(uVar13,4);
                  uVar25 = psVar11[0xe];
                  uVar36 = *(uint *)(psVar11 + 0xc);
                }
                uVar26 = (ulonglong)uVar25;
                uVar25 = puVar43[uVar26];
                *(uint *)(psVar11 + 2) = uVar25 & 0x7fff;
                if ((uVar25 & 0x7fff) < uVar36) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1023ec;
                  cVar7 = func_0x(0x1e7abb0);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1023f5;
                    lVar20 = func_0x();
                    if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10240f;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10242b;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10244e;
                        (*_DAT_)(1,0x176a5bc,0x188a6a8,0x81d);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar11 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10245c;
                  func_0x(uVar13,4);
                  lVar20 = *(longlong *)((longlong)&psStackX_20 + lVar10);
                  uVar36 = *(uint *)(lVar20 + 0x18);
                  uVar26 = (ulonglong)(ushort)psVar11[0xe];
                }
                else {
                  lVar20 = *(longlong *)((longlong)&psStackX_20 + lVar10);
                }
                puVar6 = puVar43;
                if ((short)uVar26 != 0) {
                  do {
                    uVar23 = puVar6[1] & 0x7fff;
                    if ((uVar23 < uVar36) || (*(uint *)(psVar11 + 2) < uVar23)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1024af;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1024b8;
                        lVar20 = func_0x();
                        if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1024d2;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1024ee;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102512;
                            (*_DAT_)(1,0x176a5bc,0x188a6a8,0x82a);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar11 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102520;
                      func_0x(uVar13,4);
                    }
                    iVar29 = iVar29 + 1;
                    uVar26 = (ulonglong)(ushort)psVar11[0xe];
                    puVar6 = puVar6 + 1;
                    uVar36 = uVar23;
                  } while (iVar29 < (int)(uint)(ushort)psVar11[0xe]);
                  puVar35 = *(uint **)(&stack0x00000050 + lVar10);
                  lVar20 = *(longlong *)((longlong)&psStackX_20 + lVar10);
                }
                if ((short)puVar43[(ulonglong)((int)uVar26 - 1) + 1] < 0) {
                  do {
                    lVar12 = *(longlong *)(psVar11 + 4);
                    lVar14 = (ulonglong)*(uint *)(psVar11 + 10) + lVar12;
                    uVar36 = *(ushort *)(lVar14 + uVar26 * 2) & 0x7fff;
                    if ((int)uVar26 == 1) {
                      uVar23 = *(uint *)(psVar11 + 0xc);
                      uVar39 = uVar23;
code_r0x00102587:
                      if ((uVar36 < uVar23) || (*(uint *)(psVar11 + 2) < uVar36))
                      goto code_r0x00102590;
                    }
                    else {
                      uVar23 = *(ushort *)(lVar14 + -2 + uVar26 * 2) & 0x7fff;
                      uVar39 = *(uint *)(lVar20 + 0x18);
                      if (uVar39 <= uVar23) goto code_r0x00102587;
code_r0x00102590:
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10259d;
                      func_0x(lVar12,7);
                      uVar39 = *(uint *)(lVar20 + 0x18);
                    }
                    if ((uVar23 < uVar39) || (*(uint *)(psVar11 + 2) < uVar23))
                    goto code_r0x001028e6;
                    if (*(ushort *)((ulonglong)uVar23 + *(longlong *)(psVar11 + 4)) == 5) {
                      *puVar1 = *puVar1 | 2;
                      psVar11[0xe] = psVar11[0xe] + -1;
                      psVar11[0x15] = (short)uVar23;
                      uVar26 = *(ulonglong *)(psVar11 + 4);
                      uVar25 = *(ushort *)((ulonglong)(uVar23 & 0xffff) + 2 + uVar26);
                      uVar9 = psVar11[0x16] & 0xc7ff;
                      if ((uVar25 >> 0xe & 1) != 0) {
                        uVar9 = uVar25 & 0x3800 | uVar9;
                      }
                      psVar11[0x16] = uVar9;
                      uVar25 = (uVar9 ^ *(ushort *)((ulonglong)(uVar23 & 0xffff) + 2 + uVar26)) &
                               0x7ff ^ uVar9;
                      psVar11[0x16] = uVar25;
                      uVar32 = (ulonglong)(ushort)psVar11[0x15];
                      uVar31 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                               uVar26 + (uVar9 >> 0xb & 7) * 2 + uVar32;
                      if (uVar31 < uVar32 + uVar26) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1026a4;
                        func_0x(uVar32 + uVar26,0x19);
                        uVar25 = psVar11[0x16];
                        uVar32 = (ulonglong)(ushort)psVar11[0x15];
                        uVar26 = (ulonglong)*(uint *)(psVar11 + 4);
                      }
                      if (uVar36 - uVar23 <
                          (((uVar25 & 0x7ff) * 2 - (int)uVar32) - (int)uVar26) + (int)uVar31) {
                        lVar20 = *(longlong *)(psVar11 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1026dc;
                        func_0x(uVar32 + lVar20,0x19);
                        uVar25 = psVar11[0x16];
                      }
                      iVar40 = 0;
                      if (((uVar25 & 0x3800) != 0) &&
                         (puVar43 = (ushort *)
                                    (*(longlong *)(psVar11 + 4) + 4 +
                                    (ulonglong)(ushort)psVar11[0x15]), (uVar25 & 0x3800) != 0))
                      goto code_r0x00102720;
                      break;
                    }
                    if (*(ushort *)((ulonglong)uVar23 + *(longlong *)(psVar11 + 4)) < 0x400) break;
                    *puVar1 = *puVar1 | 1;
                    uVar25 = psVar11[0xe] - 1;
                    psVar11[0xe] = uVar25;
                    if ((uVar25 == 0) ||
                       (uVar26 = (ulonglong)uVar25, -1 < (short)puVar43[(ulonglong)(uVar25 - 1) + 1]
                       )) break;
                  } while( true );
                }
                pbVar33 = *(byte **)(psVar11 + 4);
              }
              goto code_r0x00102773;
            }
            goto code_r0x001028e6;
          case 0x10:
            uVar13 = *(undefined8 *)(*(longlong *)(lVar14 + 8) + 0x160);
            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103113;
            piVar17 = (int *)func_0x(uVar13,0);
            *(int **)(&stack0x00000068 + lVar10) = piVar17;
            *(undefined4 *)(&stack0x00000034 + lVar10) = 8;
            iVar29 = *(int *)(*(longlong *)(lVar14 + 8) + 0x100);
            if (iVar29 != 2) {
              if (iVar29 == 0) {
                uVar25 = *(ushort *)(*(longlong *)(&stack0x00000050 + lVar10) + 0x3c);
                if ((*(byte *)((longlong)piVar17 + 6) & 0x10) == 0) {
code_r0x00103e85:
                  puVar34 = (ulonglong *)((longlong)*piVar17 + *(longlong *)(psVar11 + 4));
code_r0x00103e8d:
                  *puVar2 = *puVar34;
                  puVar35 = *(uint **)(&stack0x00000050 + lVar10);
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe0 + lVar10) = &stack0x0000010c + lVar10;
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103e33;
                  func_0x(puVar1,piVar17,0,&stack0x000001dc + lVar10);
                  if (*(int *)(&stack0x0000010c + lVar10) != 0) goto code_r0x00103e85;
                  puVar34 = (ulonglong *)(*(uint **)(piVar17 + 2) + 1);
                  if ((uVar25 == 0) || (**(uint **)(piVar17 + 2) == (uint)uVar25))
                  goto code_r0x00103e8d;
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103e75;
                  (*_DAT_)(1,0x1918a00,0x1917368,0x381);
                  *puVar2 = *puVar34;
                  puVar35 = *(uint **)(&stack0x00000050 + lVar10);
                }
                goto code_r0x00103b6c;
              }
              puVar35 = *(uint **)(&stack0x00000050 + lVar10);
              goto code_r0x00103b6f;
            }
            if (*(int *)(psVar11 + 2) == 0) {
              iVar40 = 0;
              *puVar1 = 0;
              uVar36 = *(uint *)(psVar11 + 8);
              uVar26 = (ulonglong)uVar36;
              *(uint *)(psVar11 + 10) = uVar36;
              pbVar33 = *(byte **)(psVar11 + 4);
              bVar8 = *pbVar33;
              if ((bVar8 & 0x10) != 0) {
                uVar36 = uVar36 + (*(ushort *)(pbVar33 + uVar26) + 7 >> 3) + 2;
                uVar26 = (ulonglong)uVar36;
                *(uint *)(psVar11 + 10) = uVar36;
                bVar8 = *pbVar33;
              }
              if ((bVar8 & 0x20) == 0) {
                *(int *)(psVar11 + 2) = (int)uVar26;
                psVar11[0xe] = 0;
                *(uint *)(psVar11 + 0xc) = uVar36;
              }
              else {
                puVar43 = (ushort *)(pbVar33 + uVar26);
                *(ushort **)(&stack0x00000048 + lVar10) = puVar43;
                uVar25 = *puVar43;
                psVar11[0xe] = uVar25;
                if (uVar25 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10319f;
                  cVar7 = func_0x(0x1e7abb0);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1031a8;
                    lVar20 = func_0x();
                    if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1031c2;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1031de;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103204;
                        (*_DAT_)(1,0x176a5bc,0x188a6a8,0x80f);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar11 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10320f;
                  func_0x(uVar13,3);
                  uVar25 = psVar11[0xe];
                  uVar36 = *(uint *)(psVar11 + 10);
                }
                uVar36 = uVar36 + (uVar25 + 1) * 2;
                *(uint *)(psVar11 + 0xc) = uVar36;
                if (0x1f9e < uVar36) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10323e;
                  cVar7 = func_0x(0x1e7abb0);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103247;
                    lVar20 = func_0x();
                    if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103261;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10327d;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1032a3;
                        (*_DAT_)(1,0x176a5bc,0x188a6a8,0x816);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar11 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1032b1;
                  func_0x(uVar13,4);
                  uVar25 = psVar11[0xe];
                  uVar36 = *(uint *)(psVar11 + 0xc);
                }
                uVar26 = (ulonglong)uVar25;
                uVar25 = puVar43[uVar26];
                *(uint *)(psVar11 + 2) = uVar25 & 0x7fff;
                if ((uVar25 & 0x7fff) < uVar36) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1032df;
                  cVar7 = func_0x(0x1e7abb0);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1032e8;
                    lVar20 = func_0x();
                    if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103302;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10331e;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103344;
                        (*_DAT_)(1,0x176a5bc,0x188a6a8,0x81d);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar11 + 4);
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103352;
                  func_0x(uVar13,4);
                  uVar36 = *(uint *)(*(longlong *)((longlong)&psStackX_20 + lVar10) + 0x18);
                  uVar26 = (ulonglong)(ushort)psVar11[0xe];
                }
                if ((short)uVar26 != 0) {
                  do {
                    puVar43 = puVar43 + 1;
                    uVar23 = *puVar43 & 0x7fff;
                    if ((uVar23 < uVar36) || (*(uint *)(psVar11 + 2) < uVar23)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10339f;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1033a8;
                        lVar20 = func_0x();
                        if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1033c2;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1033de;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103402;
                            (*_DAT_)(1,0x176a5bc,0x188a6a8,0x82a);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar11 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103410;
                      func_0x(uVar13,4);
                    }
                    iVar40 = iVar40 + 1;
                    uVar26 = (ulonglong)(ushort)psVar11[0xe];
                    uVar36 = uVar23;
                  } while (iVar40 < (int)(uint)(ushort)psVar11[0xe]);
                  puVar43 = *(ushort **)(&stack0x00000048 + lVar10);
                  piVar17 = *(int **)(&stack0x00000068 + lVar10);
                }
                if ((short)puVar43[(ulonglong)((int)uVar26 - 1) + 1] < 0) {
                  do {
                    lVar20 = *(longlong *)(psVar11 + 4);
                    lVar14 = (ulonglong)*(uint *)(psVar11 + 10) + lVar20;
                    lVar12 = *(longlong *)((longlong)&psStackX_20 + lVar10);
                    uVar36 = *(ushort *)(lVar14 + uVar26 * 2) & 0x7fff;
                    if ((int)uVar26 == 1) {
                      uVar23 = *(uint *)(psVar11 + 0xc);
                      uVar39 = uVar23;
code_r0x0010347b:
                      if ((uVar36 < uVar23) || (*(uint *)(psVar11 + 2) < uVar36))
                      goto code_r0x00103484;
                    }
                    else {
                      uVar23 = *(ushort *)(lVar14 + -2 + uVar26 * 2) & 0x7fff;
                      uVar39 = *(uint *)(lVar12 + 0x18);
                      if (uVar39 <= uVar23) goto code_r0x0010347b;
code_r0x00103484:
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103491;
                      func_0x(lVar20,7);
                      uVar39 = *(uint *)(lVar12 + 0x18);
                    }
                    if ((uVar23 < uVar39) || (*(uint *)(psVar11 + 2) < uVar23))
                    goto code_r0x001037d6;
                    if (*(ushort *)((ulonglong)uVar23 + *(longlong *)(psVar11 + 4)) == 5) {
                      *puVar1 = *puVar1 | 2;
                      psVar11[0xe] = psVar11[0xe] + -1;
                      psVar11[0x15] = (short)uVar23;
                      uVar26 = *(ulonglong *)(psVar11 + 4);
                      uVar25 = *(ushort *)((ulonglong)(uVar23 & 0xffff) + 2 + uVar26);
                      uVar9 = psVar11[0x16] & 0xc7ff;
                      if ((uVar25 >> 0xe & 1) != 0) {
                        uVar9 = uVar25 & 0x3800 | uVar9;
                      }
                      psVar11[0x16] = uVar9;
                      uVar25 = (uVar9 ^ *(ushort *)((ulonglong)(uVar23 & 0xffff) + 2 + uVar26)) &
                               0x7ff ^ uVar9;
                      psVar11[0x16] = uVar25;
                      uVar32 = (ulonglong)(ushort)psVar11[0x15];
                      uVar31 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                               uVar32 + (uVar9 >> 0xb & 7) * 2 + uVar26;
                      if (uVar31 < uVar32 + uVar26) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10359f;
                        func_0x(uVar32 + uVar26,0x19);
                        uVar25 = psVar11[0x16];
                        uVar32 = (ulonglong)(ushort)psVar11[0x15];
                        uVar26 = (ulonglong)*(uint *)(psVar11 + 4);
                      }
                      if (uVar36 - uVar23 <
                          (((uVar25 & 0x7ff) * 2 - (int)uVar32) - (int)uVar26) + (int)uVar31) {
                        lVar20 = *(longlong *)(psVar11 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1035d7;
                        func_0x(uVar32 + lVar20,0x19);
                        uVar25 = psVar11[0x16];
                      }
                      if ((uVar25 & 0x3800) != 0) {
                        puVar43 = (ushort *)
                                  (*(longlong *)(psVar11 + 4) + (ulonglong)(ushort)psVar11[0x15] + 4
                                  );
                        iVar40 = 0;
                        if ((uVar25 & 0x3800) != 0) {
                          do {
                            if ((uVar25 & 0x7ff) < (*puVar43 & 0x7ff)) {
                              uVar25 = psVar11[0x15];
                              lVar20 = *(longlong *)(psVar11 + 4);
                              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103637;
                              func_0x((ulonglong)uVar25 + lVar20,0x1a);
                              uVar25 = psVar11[0x16];
                            }
                            iVar40 = iVar40 + 1;
                            puVar43 = puVar43 + 1;
                          } while (iVar40 < (int)(uVar25 >> 0xb & 7));
                        }
                      }
                      goto code_r0x00103652;
                    }
                    if (*(ushort *)((ulonglong)uVar23 + *(longlong *)(psVar11 + 4)) < 0x400)
                    goto code_r0x00103652;
                    *puVar1 = *puVar1 | 1;
                    uVar25 = psVar11[0xe] - 1;
                    psVar11[0xe] = uVar25;
                    if (uVar25 == 0) goto code_r0x00103652;
                    uVar26 = (ulonglong)uVar25;
                  } while ((short)puVar43[(ulonglong)(uVar25 - 1) + 1] < 0);
                  pbVar33 = *(byte **)(psVar11 + 4);
                }
                else {
code_r0x00103652:
                  pbVar33 = *(byte **)(psVar11 + 4);
                }
              }
              if ((*pbVar33 & 0x40) == 0) {
                *(undefined4 *)(psVar11 + 0x13) = 0;
                lVar20 = *(longlong *)((longlong)&psStackX_20 + lVar10);
                uVar36 = *(uint *)(lVar20 + 4);
              }
              else {
                *(int *)(psVar11 + 0x13) = *(int *)(psVar11 + 2);
                *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + 0xe;
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10367e;
                uVar13 = func_0x(puVar1);
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10368d;
                func_0x(uVar13,&stack0x00000258 + lVar10);
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103699;
                iVar40 = func_0x(&stack0x00000258 + lVar10);
                *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar40;
                uVar36 = *(uint *)(psVar11 + 2);
                lVar20 = *(longlong *)((longlong)&psStackX_20 + lVar10);
              }
              if ((*(ulonglong *)(psVar11 + 0xf) != 0) &&
                 (*(ulonglong *)(psVar11 + 0xf) < (ulonglong)uVar36 + *(longlong *)(psVar11 + 4))) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1036d7;
                cVar7 = func_0x(0x1e7abb0);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1036e0;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1036fa;
                    cVar7 = func_0x(0x1e7abb0);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103716;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10373c;
                      (*_DAT_)(1,0x176a5bc,0x188a6a8,0x886);
                    }
                  }
                }
                uVar13 = *(undefined8 *)(psVar11 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10374a;
                func_0x(uVar13,0x12);
                uVar36 = *(uint *)(lVar20 + 4);
              }
              if (0x3f3b < uVar36 - 1) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103763;
                cVar7 = func_0x(0x1e7abb0);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10376c;
                  lVar20 = func_0x();
                  if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103786;
                    cVar7 = func_0x(0x1e7abb0);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1037a2;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
                      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1037c8;
                      (*_DAT_)(1,0x176a5bc,0x188a6a8,0x88b);
                    }
                  }
                }
                uVar13 = *(undefined8 *)(psVar11 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1037d6;
                func_0x(uVar13,5);
              }
            }
code_r0x001037d6:
            sVar28 = -*(short *)piVar17;
            if ((*(byte *)((longlong)piVar17 + 6) & 0x10) == 0) {
code_r0x00103823:
              lVar20 = (longlong)sVar28;
              if ((uint)(ushort)psVar11[0xe] < (uint)(int)sVar28) {
                iVar40 = 0;
                puVar34 = *(ulonglong **)(psVar11 + 4);
              }
              else {
                lVar14 = *(longlong *)(psVar11 + 4);
                lVar18 = (ulonglong)*(uint *)(psVar11 + 10) + lVar14;
                lVar12 = *(longlong *)((longlong)&psStackX_20 + lVar10);
                if (sVar28 == 1) {
                  uVar36 = *(uint *)(psVar11 + 0xc);
                  uVar23 = *(ushort *)(lVar18 + lVar20 * 2) & 0x7fff;
code_r0x00103876:
                  if ((uVar23 < uVar36) || (*(uint *)(psVar11 + 2) < uVar23)) goto code_r0x0010387f;
                }
                else {
                  uVar36 = *(ushort *)(lVar18 + -2 + lVar20 * 2) & 0x7fff;
                  uVar23 = *(ushort *)(lVar18 + lVar20 * 2) & 0x7fff;
                  lVar14 = *(longlong *)(lVar12 + 8);
                  if (*(uint *)(lVar12 + 0x18) <= uVar36) goto code_r0x00103876;
code_r0x0010387f:
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103889;
                  func_0x(lVar14,7);
                  lVar14 = *(longlong *)(lVar12 + 8);
                }
                iVar40 = uVar23 - uVar36;
                puVar34 = (ulonglong *)((ulonglong)uVar36 + lVar14);
              }
            }
            else {
              *(undefined **)(&stack0xffffffffffffffe0 + lVar10) = &stack0x00000108 + lVar10;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103807;
              func_0x(puVar1,piVar17,0,&stack0x000001d8 + lVar10);
              if (*(int *)(&stack0x00000108 + lVar10) != 0) goto code_r0x00103823;
              iVar40 = **(int **)(piVar17 + 2);
              puVar34 = (ulonglong *)(*(int **)(piVar17 + 2) + 1);
            }
            puVar35 = *(uint **)(&stack0x00000050 + lVar10);
            bVar8 = *(byte *)((longlong)puVar35 + 0x45);
            switch(*(undefined *)((longlong)puVar35 + 0x3e)) {
            case 0x30:
              if (iVar40 == 0) {
                *(undefined *)puVar2 = 0;
                *(undefined4 *)(&stack0x00000034 + lVar10) = 1;
              }
              else {
                *(byte *)puVar2 = *(byte *)puVar34;
                *(undefined4 *)(&stack0x00000034 + lVar10) = 1;
              }
              break;
            case 0x34:
              if (iVar40 == 0) {
                *(undefined2 *)puVar2 = 0;
code_r0x00103a10:
                *(undefined4 *)(&stack0x00000034 + lVar10) = 2;
              }
              else if (iVar40 == 1) {
                *(ushort *)puVar2 = (*(byte *)puVar34 >> 7) - 1;
                *(byte *)puVar2 = *(byte *)puVar34 ^ 0x80;
                *(undefined4 *)(&stack0x00000034 + lVar10) = 2;
              }
              else {
                if (iVar40 != 2) goto code_r0x00103a10;
                *(byte *)((longlong)&psStackX_20 + lVar10 + -0x1f) = *(byte *)puVar34 ^ 0x80;
                *(byte *)puVar2 = *(byte *)((longlong)puVar34 + 1);
                *(undefined4 *)(&stack0x00000034 + lVar10) = 2;
              }
              break;
            case 0x38:
            case 0x7a:
              if (iVar40 == 0) {
                *(undefined4 *)puVar2 = 0;
                *(undefined4 *)(&stack0x00000034 + lVar10) = 4;
              }
              else if (iVar40 == 1) {
                *(uint *)puVar2 = (*(byte *)puVar34 >> 7) - 1;
                *(byte *)puVar2 = *(byte *)puVar34 ^ 0x80;
                *(undefined4 *)(&stack0x00000034 + lVar10) = 4;
              }
              else if (iVar40 == 2) {
                *(uint *)puVar2 = (*(byte *)puVar34 >> 7) - 1;
                *(byte *)((longlong)&psStackX_20 + lVar10 + -0x1f) = *(byte *)puVar34 ^ 0x80;
                *(byte *)puVar2 = *(byte *)((longlong)puVar34 + 1);
                *(undefined4 *)(&stack0x00000034 + lVar10) = 4;
              }
              else if (iVar40 == 3) {
                *(uint *)puVar2 = (*(byte *)puVar34 >> 7) - 1;
                *(byte *)((longlong)&psStackX_20 + lVar10 + -0x1e) = *(byte *)puVar34 ^ 0x80;
                *(byte *)((longlong)&psStackX_20 + lVar10 + -0x1f) =
                     *(byte *)((longlong)puVar34 + 1);
                *(byte *)puVar2 = *(byte *)((longlong)puVar34 + 2);
                *(undefined4 *)(&stack0x00000034 + lVar10) = 4;
              }
              else {
                if (iVar40 != 4) goto code_r0x00103cf0;
                uVar36 = *(uint *)puVar34;
                *(uint *)puVar2 =
                     uVar36 >> 0x18 | (uVar36 & 0xff0000) >> 8 | (uVar36 & 0xff00) << 8 |
                     uVar36 << 0x18;
                *(byte *)((longlong)&psStackX_20 + lVar10 + -0x1d) = (byte)uVar36 ^ 0x80;
                *(undefined4 *)(&stack0x00000034 + lVar10) = 4;
              }
              break;
            case 0x3a:
              if (iVar40 == 4) {
                *(uint *)puVar2 = *(uint *)puVar34;
                *(undefined4 *)(&stack0x00000034 + lVar10) = 4;
              }
              else {
                *(undefined2 *)puVar2 = 0;
code_r0x00103c0f:
                *(undefined2 *)((longlong)&psStackX_20 + lVar10 + -0x1e) = *(undefined2 *)puVar34;
                *(undefined4 *)(&stack0x00000034 + lVar10) = 4;
              }
              break;
            case 0x3b:
              *(undefined4 *)puVar2 = 0;
              if (iVar40 == 1) {
                *(byte *)((longlong)&psStackX_20 + lVar10 + -0x1d) = *(byte *)puVar34;
code_r0x00103cf0:
                *(undefined4 *)(&stack0x00000034 + lVar10) = 4;
              }
              else {
                if (iVar40 == 2) goto code_r0x00103c0f;
                if (iVar40 == 3) {
                  *(undefined2 *)((longlong)&psStackX_20 + lVar10 + -0x1f) = *(undefined2 *)puVar34;
                  *(byte *)((longlong)&psStackX_20 + lVar10 + -0x1d) =
                       *(byte *)((longlong)puVar34 + 2);
                  *(undefined4 *)(&stack0x00000034 + lVar10) = 4;
                }
                else {
                  if (iVar40 != 4) goto code_r0x00103cf0;
                  *(uint *)puVar2 = *(uint *)puVar34;
                  *(undefined4 *)(&stack0x00000034 + lVar10) = 4;
                }
              }
              break;
            case 0x3c:
            case 0x3d:
            case 0x7f:
              switch(iVar40) {
              case 0:
                *puVar2 = 0;
                break;
              case 1:
                *puVar2 = (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                *(byte *)puVar2 = *(byte *)puVar34 ^ 0x80;
                break;
              case 2:
                *puVar2 = (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                *(byte *)((longlong)&psStackX_20 + lVar10 + -0x1f) = *(byte *)puVar34 ^ 0x80;
                *(byte *)puVar2 = *(byte *)((longlong)puVar34 + 1);
                break;
              case 3:
                *puVar2 = (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                *(byte *)((longlong)&psStackX_20 + lVar10 + -0x1e) = *(byte *)puVar34 ^ 0x80;
                *(byte *)((longlong)&psStackX_20 + lVar10 + -0x1f) =
                     *(byte *)((longlong)puVar34 + 1);
                *(byte *)puVar2 = *(byte *)((longlong)puVar34 + 2);
                break;
              case 4:
                *puVar2 = (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                uVar36 = *(uint *)puVar34;
                *(uint *)puVar2 =
                     uVar36 >> 0x18 | (uVar36 & 0xff0000) >> 8 | (uVar36 & 0xff00) << 8 |
                     uVar36 << 0x18;
                *(byte *)((longlong)&psStackX_20 + lVar10 + -0x1d) = *(byte *)puVar34 ^ 0x80;
                break;
              case 5:
                *puVar2 = (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                *(byte *)((longlong)&psStackX_20 + lVar10 + -0x1c) = *(byte *)puVar34 ^ 0x80;
                uVar36 = *(uint *)((longlong)puVar34 + 1);
                *(uint *)puVar2 =
                     uVar36 >> 0x18 | (uVar36 & 0xff0000) >> 8 | (uVar36 & 0xff00) << 8 |
                     uVar36 << 0x18;
                break;
              case 6:
                *puVar2 = (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                *(byte *)((longlong)&psStackX_20 + lVar10 + -0x1b) = *(byte *)puVar34 ^ 0x80;
                *(byte *)((longlong)&psStackX_20 + lVar10 + -0x1c) =
                     *(byte *)((longlong)puVar34 + 1);
                uVar36 = *(uint *)((longlong)puVar34 + 2);
                *(uint *)puVar2 =
                     uVar36 >> 0x18 | (uVar36 & 0xff0000) >> 8 | (uVar36 & 0xff00) << 8 |
                     uVar36 << 0x18;
                break;
              case 7:
                *puVar2 = (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                *(byte *)((longlong)&psStackX_20 + lVar10 + -0x1a) = *(byte *)puVar34 ^ 0x80;
                *(byte *)((longlong)&psStackX_20 + lVar10 + -0x1b) =
                     *(byte *)((longlong)puVar34 + 1);
                *(byte *)((longlong)&psStackX_20 + lVar10 + -0x1c) =
                     *(byte *)((longlong)puVar34 + 2);
                uVar36 = *(uint *)((longlong)puVar34 + 3);
                *(uint *)puVar2 =
                     uVar36 >> 0x18 | (uVar36 & 0xff0000) >> 8 | (uVar36 & 0xff00) << 8 |
                     uVar36 << 0x18;
                break;
              case 8:
                uVar26 = *puVar34;
                *puVar2 = uVar26 >> 0x38 | (uVar26 & 0xff000000000000) >> 0x28 |
                          (uVar26 & 0xff0000000000) >> 0x18 | (uVar26 & 0xff00000000) >> 8 |
                          (uVar26 & 0xff000000) << 8 | (uVar26 & 0xff0000) << 0x18 |
                          (uVar26 & 0xff00) << 0x28 | uVar26 << 0x38;
                bVar8 = (byte)uVar26 ^ 0x80;
                goto code_r0x00103b62;
              }
              goto code_r0x00103b65;
            case 0x3e:
              *puVar2 = 0;
              switch(iVar40) {
              case 1:
                bVar8 = *(byte *)puVar34;
                goto code_r0x00103b62;
              case 2:
                *(undefined2 *)((longlong)&psStackX_20 + lVar10 + -0x1a) = *(undefined2 *)puVar34;
                break;
              case 3:
                *(undefined2 *)((longlong)&psStackX_20 + lVar10 + -0x1b) = *(undefined2 *)puVar34;
                bVar8 = *(byte *)((longlong)puVar34 + 2);
                goto code_r0x00103b62;
              case 4:
                *(uint *)((longlong)&psStackX_20 + lVar10 + -0x1c) = *(uint *)puVar34;
                break;
              case 5:
                *(uint *)((longlong)&psStackX_20 + lVar10 + -0x1d) = *(uint *)puVar34;
                bVar8 = *(byte *)((longlong)puVar34 + 4);
                goto code_r0x00103b62;
              case 6:
                *(uint *)((longlong)&psStackX_20 + lVar10 + -0x1e) = *(uint *)puVar34;
                *(undefined2 *)((longlong)&psStackX_20 + lVar10 + -0x1a) =
                     *(undefined2 *)((longlong)puVar34 + 4);
                break;
              case 7:
                *(uint *)((longlong)&psStackX_20 + lVar10 + -0x1f) = *(uint *)puVar34;
                *(undefined2 *)((longlong)&psStackX_20 + lVar10 + -0x1b) =
                     *(undefined2 *)((longlong)puVar34 + 4);
                bVar8 = *(byte *)((longlong)puVar34 + 6);
code_r0x00103b62:
                *(byte *)((longlong)&psStackX_20 + lVar10 + -0x19) = bVar8;
                break;
              case 8:
                *puVar2 = *puVar34;
              }
code_r0x00103b65:
              *(undefined4 *)(&stack0x00000034 + lVar10) = 8;
              break;
            case 0x6a:
            case 0x6c:
              *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x00000034 + lVar10;
              *(ulonglong **)(&stack0xffffffffffffffe0 + lVar10) = puVar2;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103db1;
              cVar7 = (*pcRam00000000013e6340)(puVar34);
              if (cVar7 == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103dcf;
                (*_DAT_)(6,0x54,0x16,1);
              }
              break;
            case 0xad:
            case 0xaf:
              (&stack0xffffffffffffffe0)[lVar10] = *(undefined *)((longlong)puVar35 + 0x3e);
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103c3c;
              func_0x
                        (puVar34,iVar40,puVar2,*(undefined4 *)(&stack0x00000034 + lVar10));
              break;
            case 0xbd:
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103c72;
              func_0x(puVar34,iVar40,puVar2,bVar8 & 0x3f);
              goto code_r0x00103b65;
            case 0xe7:
              *(undefined4 *)(&stack0xffffffffffffffe0 + lVar10) =
                   *(undefined4 *)(&stack0x00000034 + lVar10);
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103df2;
              uVar44 = (*pcRam00000000013e6338)(&stack0x000002b8 + lVar10,puVar34,iVar40,puVar2);
              *(undefined4 *)(&stack0x00000034 + lVar10) = uVar44;
              break;
            case 0xef:
              *(undefined4 *)(&stack0xffffffffffffffe0 + lVar10) =
                   *(undefined4 *)(&stack0x00000034 + lVar10);
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103c5f;
              (*pcRam00000000013e6348)(&stack0x000003d0 + lVar10,puVar34,iVar40,puVar2);
            }
code_r0x00103b6c:
            iVar40 = *(int *)((longlong)auStackX_18 + lVar10 + 4);
code_r0x00103b6f:
            lVar20 = *(longlong *)(&stack0x00000088 + lVar10);
            if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) != 0) {
              lVar20 = *(longlong *)(&stack0x00000090 + lVar10);
            }
            lVar12 = *(longlong *)(puVar35 + 10);
            *(ulonglong *)(lVar12 + lVar20) = *puVar2;
            uVar36 = puVar35[0x10];
            if ((uVar36 >> 8 & 1) != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x103bb1;
              func_0x();
              uVar36 = puVar35[0x10];
            }
            psVar16 = *(short **)((longlong)&psStackX_20 + lVar10);
            if ((uVar36 >> 10 & 1) != 0) {
              lVar14 = *(longlong *)(&stack0x00000088 + lVar10);
              if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar14 = *(longlong *)(&stack0x00000090 + lVar10);
              }
              uVar21 = 0;
              if ((ulonglong *)(lVar12 + lVar20) == (ulonglong *)0x0) {
                uVar21 = 3;
              }
              *(undefined *)(lVar14 + *(longlong *)(puVar35 + 0xc)) = uVar21;
            }
            goto code_r0x001020b4;
          }
          goto code_r0x00102056;
        }
      }
    }
    else if (*(int *)(*(longlong *)(lVar14 + 8) + 0x100) == 2) {
      uVar32 = (ulonglong)*(uint *)(lVar20 + 0x34);
      *(uint *)((longlong)&psStackX_20 + lVar10) = *(uint *)(lVar20 + 0x34);
      uVar31 = uVar32 + 0xf;
      if (uVar31 <= uVar32) {
        uVar31 = 0xffffffffffffff0;
      }
      uVar31 = uVar31 & 0xfffffffffffffff0;
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1047d3;
      func_0x();
      lVar20 = -uVar31;
      puVar42 = (undefined *)((longlong)&psStackX_20 + lVar20 + lVar10 + -0x20);
      *(longlong *)(&stack0x00000288 + lVar10) = (longlong)&psStackX_20 + lVar20 + lVar10 + -0x20;
      puVar27 = &stack0xffffffffffffffc0 + lVar20 + lVar10;
      if ((uVar26 & 0x10) != 0) {
        iVar40 = *(int *)(&stack0x00000080 + lVar10);
        *(int *)(&stack0x00000058 + lVar10) = iVar40;
        puVar35 = *(uint **)(&stack0x00000078 + lVar10);
        *(uint **)(&stack0x00000050 + lVar10) = puVar35;
        *(undefined4 *)((longlong)auStackX_18 + lVar10 + 4) = 0;
        puVar27 = &stack0xffffffffffffffc0 + lVar20 + lVar10;
        if (iVar40 != 0) {
          do {
            plVar37 = (longlong *)0x0;
            switch(*(undefined *)(puVar35 + 0x10)) {
            case 0:
              goto code_r0x00105bc1;
            case 1:
              if (*psVar16 == 0) {
                *(undefined **)(&stack0xffffffffffffffe0 + lVar20 + lVar10) =
                     &stack0x000001e0 + lVar10;
                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104868;
                func_0x(psVar16 + 1,puVar35,1,&stack0x0000011c + lVar10);
                uVar36 = *(uint *)(&stack0x0000011c + lVar10);
              }
              else {
                uVar25 = *(ushort *)(puVar35 + 1);
                if ((ushort)psVar16[1] < uVar25) {
                  uVar36 = ~(uint)(*(ushort *)((longlong)puVar35 + 6) >> 4) & 1;
                }
                else {
                  bVar8 = *(byte *)((longlong)((int)(uVar25 - 1) / 2) +
                                    (ulonglong)(ushort)psVar16[0xc] + *(longlong *)(psVar16 + 4));
                  bVar22 = bVar8 >> 4;
                  if ((uVar25 & 1) != 0) {
                    bVar22 = bVar8 & 0xf;
                  }
                  uVar36 = (uint)(bVar22 == 0);
                }
              }
              if (uVar36 == 0) goto code_r0x001048ce;
code_r0x00105b57:
              *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x10) = 0;
              plVar38 = (longlong *)0x0;
              break;
            case 2:
code_r0x001048ce:
              uVar25 = *(ushort *)(puVar35 + 0xf);
              if ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0) {
                *(undefined **)(&stack0xffffffffffffffe0 + lVar20 + lVar10) =
                     &stack0x00000120 + lVar10;
                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1048fd;
                func_0x(psVar16 + 1,puVar35,0,&stack0x000001e4 + lVar10);
                if (*(int *)(&stack0x00000120 + lVar10) == 0) {
                  plVar38 = (longlong *)(*(uint **)(puVar35 + 2) + 1);
                  uVar36 = **(uint **)(puVar35 + 2);
                  if ((uVar25 != 0) && (uVar36 != uVar25)) {
                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10493c;
                    (*_DAT_)(1,0x1918a00,0x1917368,0x381);
                  }
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10) = uVar36;
                  break;
                }
              }
              *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10) = (uint)uVar25;
              plVar38 = (longlong *)((longlong)(int)*puVar35 + *(longlong *)(psVar16 + 4));
              break;
            case 3:
              if (*psVar16 == 0) {
                *(undefined **)(&stack0xffffffffffffffe0 + lVar20 + lVar10) =
                     &stack0x000001e8 + lVar10;
                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104982;
                func_0x(psVar16 + 1,puVar35,1,&stack0x00000124 + lVar10);
                uVar36 = *(uint *)(&stack0x00000124 + lVar10);
              }
              else {
                uVar25 = *(ushort *)(puVar35 + 1);
                if ((ushort)psVar16[1] < uVar25) {
                  uVar36 = ~(uint)(*(ushort *)((longlong)puVar35 + 6) >> 4) & 1;
                }
                else {
                  bVar8 = *(byte *)((longlong)((int)(uVar25 - 1) / 2) +
                                    (ulonglong)(ushort)psVar16[0xc] + *(longlong *)(psVar16 + 4));
                  bVar22 = bVar8 >> 4;
                  if ((uVar25 & 1) != 0) {
                    bVar22 = bVar8 & 0xf;
                  }
                  uVar36 = (uint)(bVar22 == 0);
                }
              }
              if (uVar36 != 0) goto code_r0x00105b57;
            case 4:
              puVar1 = (ushort *)(psVar16 + 1);
              if (*psVar16 == 0) {
                psVar11 = psVar16;
                if (*(int *)(psVar16 + 2) == 0) {
                  *puVar1 = 0;
                  uVar36 = *(uint *)(psVar16 + 8);
                  uVar26 = (ulonglong)uVar36;
                  *(uint *)(psVar16 + 10) = uVar36;
                  pbVar33 = *(byte **)(psVar16 + 4);
                  bVar8 = *pbVar33;
                  if ((bVar8 & 0x10) != 0) {
                    uVar36 = uVar36 + (*(ushort *)(pbVar33 + uVar26) + 7 >> 3) + 2;
                    uVar26 = (ulonglong)uVar36;
                    *(uint *)(psVar16 + 10) = uVar36;
                    bVar8 = *pbVar33;
                  }
                  if ((bVar8 & 0x20) == 0) {
                    *(int *)(psVar16 + 2) = (int)uVar26;
                    psVar16[0xe] = 0;
                    *(uint *)(psVar16 + 0xc) = uVar36;
                  }
                  else {
                    puVar43 = (ushort *)(pbVar33 + uVar26);
                    *(ushort **)(&stack0x00000068 + lVar10) = puVar43;
                    uVar25 = *puVar43;
                    psVar16[0xe] = uVar25;
                    if (uVar25 == 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104a62;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104a6b;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104a85;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104aa1;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104ac7;
                            (*_DAT_)(1,0x176a5bc,0x188a6a8,0x80f);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar16 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104ad5;
                      func_0x(uVar13,3);
                      uVar25 = psVar16[0xe];
                      uVar36 = *(uint *)(psVar16 + 10);
                    }
                    uVar36 = uVar36 + (uVar25 + 1) * 2;
                    *(uint *)(psVar16 + 0xc) = uVar36;
                    if (0x1f9e < uVar36) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104b04;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104b0d;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104b27;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104b43;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104b69;
                            (*_DAT_)(1,0x176a5bc,0x188a6a8,0x816);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar16 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104b77;
                      func_0x(uVar13,4);
                      uVar25 = psVar16[0xe];
                      uVar36 = *(uint *)(psVar16 + 0xc);
                    }
                    uVar26 = (ulonglong)uVar25;
                    uVar25 = puVar43[uVar26];
                    *(uint *)(psVar16 + 2) = uVar25 & 0x7fff;
                    if ((uVar25 & 0x7fff) < uVar36) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104ba5;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104bae;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104bc8;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104be4;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104c0a;
                            (*_DAT_)(1,0x176a5bc,0x188a6a8,0x81d);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar16 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104c18;
                      func_0x(uVar13,4);
                      uVar36 = *(uint *)(psVar16 + 0xc);
                      uVar26 = (ulonglong)(ushort)psVar16[0xe];
                    }
                    if ((short)uVar26 != 0) {
                      do {
                        puVar43 = puVar43 + 1;
                        uVar23 = *puVar43 & 0x7fff;
                        if ((uVar23 < uVar36) || (*(uint *)(psVar16 + 2) < uVar23)) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104c5f;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104c68;
                            lVar12 = func_0x();
                            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104c82;
                              cVar7 = func_0x(0x1e7abb0);
                              if (cVar7 == '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104c9e;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104cc2;
                                (*_DAT_)(1,0x176a5bc,0x188a6a8,0x82a);
                              }
                            }
                          }
                          uVar13 = *(undefined8 *)(psVar16 + 4);
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104cd0;
                          func_0x(uVar13,4);
                        }
                        uVar39 = (int)plVar37 + 1;
                        plVar37 = (longlong *)(ulonglong)uVar39;
                        uVar26 = (ulonglong)(ushort)psVar16[0xe];
                        uVar36 = uVar23;
                      } while ((int)uVar39 < (int)(uint)(ushort)psVar16[0xe]);
                      puVar43 = *(ushort **)(&stack0x00000068 + lVar10);
                      psVar11 = *(short **)(&stack0x00000048 + lVar10);
                    }
                    if ((short)puVar43[(ulonglong)((int)uVar26 - 1) + 1] < 0) {
                      do {
                        lVar12 = *(longlong *)(psVar16 + 4);
                        lVar14 = (ulonglong)*(uint *)(psVar16 + 10) + lVar12;
                        uVar36 = *(ushort *)(lVar14 + uVar26 * 2) & 0x7fff;
                        if ((int)uVar26 == 1) {
                          uVar23 = *(uint *)(psVar16 + 0xc);
                          uVar39 = uVar23;
code_r0x00104d36:
                          if ((uVar36 < uVar23) || (*(uint *)(psVar16 + 2) < uVar36))
                          goto code_r0x00104d3f;
                        }
                        else {
                          uVar23 = *(ushort *)(lVar14 + -2 + uVar26 * 2) & 0x7fff;
                          uVar39 = *(uint *)(psVar16 + 0xc);
                          if (uVar39 <= uVar23) goto code_r0x00104d36;
code_r0x00104d3f:
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104d4c;
                          func_0x(lVar12,7);
                          uVar39 = *(uint *)(psVar16 + 0xc);
                        }
                        if ((uVar23 < uVar39) || (*(uint *)(psVar16 + 2) < uVar23)) {
                          puVar35 = *(uint **)(&stack0x00000050 + lVar10);
                          goto code_r0x00105097;
                        }
                        if (*(ushort *)((ulonglong)uVar23 + *(longlong *)(psVar16 + 4)) == 5) {
                          *puVar1 = *puVar1 | 2;
                          psVar16[0xe] = psVar16[0xe] + -1;
                          psVar16[0x15] = (short)uVar23;
                          uVar26 = *(ulonglong *)(psVar16 + 4);
                          uVar25 = *(ushort *)((ulonglong)(uVar23 & 0xffff) + 2 + uVar26);
                          uVar9 = psVar16[0x16] & 0xc7ff;
                          if ((uVar25 >> 0xe & 1) != 0) {
                            uVar9 = uVar25 & 0x3800 | uVar9;
                          }
                          psVar16[0x16] = uVar9;
                          uVar25 = (uVar9 ^ *(ushort *)((ulonglong)(uVar23 & 0xffff) + 2 + uVar26))
                                   & 0x7ff ^ uVar9;
                          psVar16[0x16] = uVar25;
                          uVar32 = (ulonglong)(ushort)psVar16[0x15];
                          uVar31 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                                   uVar32 + (uVar9 >> 0xb & 7) * 2 + uVar26;
                          if (uVar31 < uVar32 + uVar26) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104e5d;
                            func_0x(uVar32 + uVar26,0x19);
                            uVar25 = psVar16[0x16];
                            uVar32 = (ulonglong)(ushort)psVar16[0x15];
                            uVar26 = (ulonglong)*(uint *)(psVar16 + 4);
                          }
                          if (uVar36 - uVar23 <
                              (((uVar25 & 0x7ff) * 2 - (int)uVar32) - (int)uVar26) + (int)uVar31) {
                            lVar12 = *(longlong *)(psVar16 + 4);
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104e95;
                            func_0x(uVar32 + lVar12,0x19);
                            uVar25 = psVar16[0x16];
                          }
                          if ((uVar25 & 0x3800) != 0) {
                            puVar43 = (ushort *)
                                      (*(longlong *)(psVar16 + 4) +
                                      (ulonglong)(ushort)psVar16[0x15] + 4);
                            iVar40 = 0;
                            if ((uVar25 & 0x3800) != 0) {
                              do {
                                if ((uVar25 & 0x7ff) < (*puVar43 & 0x7ff)) {
                                  uVar25 = psVar16[0x15];
                                  lVar12 = *(longlong *)(psVar16 + 4);
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104ee7
                                  ;
                                  func_0x((ulonglong)uVar25 + lVar12,0x1a);
                                  uVar25 = psVar16[0x16];
                                }
                                iVar40 = iVar40 + 1;
                                puVar43 = puVar43 + 1;
                              } while (iVar40 < (int)(uVar25 >> 0xb & 7));
                            }
                          }
                          goto code_r0x00104f02;
                        }
                        if (*(ushort *)((ulonglong)uVar23 + *(longlong *)(psVar16 + 4)) < 0x400)
                        goto code_r0x00104f02;
                        *puVar1 = *puVar1 | 1;
                        uVar25 = psVar16[0xe] - 1;
                        psVar16[0xe] = uVar25;
                        if (uVar25 == 0) goto code_r0x00104f02;
                        uVar26 = (ulonglong)uVar25;
                      } while ((short)puVar43[(ulonglong)(uVar25 - 1) + 1] < 0);
                      pbVar33 = *(byte **)(psVar16 + 4);
                      puVar35 = *(uint **)(&stack0x00000050 + lVar10);
                    }
                    else {
code_r0x00104f02:
                      pbVar33 = *(byte **)(psVar16 + 4);
                      puVar35 = *(uint **)(&stack0x00000050 + lVar10);
                    }
                  }
                  if ((*pbVar33 & 0x40) == 0) {
                    *(undefined4 *)(psVar16 + 0x13) = 0;
                  }
                  else {
                    *(int *)(psVar16 + 0x13) = *(int *)(psVar16 + 2);
                    *(int *)(psVar16 + 2) = *(int *)(psVar16 + 2) + 0xe;
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104f32;
                    uVar13 = func_0x(puVar1);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104f41;
                    func_0x(uVar13,&stack0x00000260 + lVar10);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104f4d;
                    iVar40 = func_0x(&stack0x00000260 + lVar10);
                    *(int *)(psVar16 + 2) = *(int *)(psVar16 + 2) + iVar40;
                  }
                  uVar36 = *(uint *)(psVar16 + 2);
                  if ((*(ulonglong *)(psVar16 + 0xf) != 0) &&
                     (*(ulonglong *)(psVar16 + 0xf) < (ulonglong)uVar36 + *(longlong *)(psVar16 + 4)
                     )) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104f80;
                    cVar7 = func_0x(0x1e7abb0);
                    if (cVar7 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104f89;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104fa3;
                        cVar7 = func_0x(0x1e7abb0);
                        if (cVar7 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104fbf;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104fe5;
                          (*_DAT_)(1,0x176a5bc,0x188a6a8,0x886);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar16 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x104ff3;
                    func_0x(uVar13);
                    uVar36 = *(uint *)(psVar16 + 2);
                  }
                  if (0x3f3b < uVar36 - 1) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105010;
                    cVar7 = func_0x(0x1e7abb0);
                    if (cVar7 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105019;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105033;
                        cVar7 = func_0x(0x1e7abb0);
                        if (cVar7 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10504f;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          uVar13 = *(undefined8 *)(psVar16 + 4);
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10505d;
                          func_0x(uVar13);
                          goto code_r0x00105097;
                        }
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105083;
                        (*_DAT_)(1,0x176a5bc,0x188a6a8,0x88b);
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar16 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105091;
                    func_0x(uVar13);
                  }
                }
code_r0x00105097:
                sVar28 = -*(short *)puVar35;
                if ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0) {
                  *(undefined **)(&stack0xffffffffffffffe0 + lVar20 + lVar10) =
                       &stack0x00000128 + lVar10;
                  *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1050c6;
                  func_0x(puVar1,puVar35,0,&stack0x000001ec + lVar10);
                  if (*(int *)(&stack0x00000128 + lVar10) == 0) {
                    puVar19 = *(undefined4 **)(puVar35 + 2);
                    *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x10) = *puVar19;
                    plVar38 = (longlong *)(puVar19 + 1);
                    psVar16 = psVar11;
                    goto code_r0x001051ea;
                  }
                }
                lVar12 = (longlong)sVar28;
                if ((uint)(ushort)psVar16[0xe] < (uint)(int)sVar28) {
                  *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x10) = 0;
                  plVar38 = *(longlong **)(psVar16 + 4);
                  psVar16 = psVar11;
                }
                else {
                  lVar14 = *(longlong *)(psVar16 + 4);
                  lVar18 = (ulonglong)*(uint *)(psVar16 + 10) + lVar14;
                  if (sVar28 == 1) {
                    uVar36 = *(uint *)(psVar16 + 0xc);
                    uVar23 = *(ushort *)(lVar18 + lVar12 * 2) & 0x7fff;
code_r0x0010512e:
                    if ((uVar23 < uVar36) || (*(uint *)(psVar16 + 2) < uVar23))
                    goto code_r0x00105137;
                  }
                  else {
                    uVar36 = *(ushort *)(lVar18 + -2 + lVar12 * 2) & 0x7fff;
                    uVar23 = *(ushort *)(lVar18 + lVar12 * 2) & 0x7fff;
                    lVar14 = *(longlong *)(psVar16 + 4);
                    if (*(uint *)(psVar16 + 0xc) <= uVar36) goto code_r0x0010512e;
code_r0x00105137:
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105144;
                    func_0x(lVar14);
                  }
                  *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10) = uVar23 - uVar36;
                  plVar38 = (longlong *)((ulonglong)uVar36 + *(longlong *)(psVar16 + 4));
                  psVar16 = psVar11;
                }
              }
              else {
                *(undefined4 *)(&stack0x000000dc + lVar10) = 0;
                *(undefined **)(&stack0xffffffffffffffe0 + lVar20 + lVar10) =
                     &stack0x000000dc + lVar10;
                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10518c;
                plVar38 = (longlong *)
                          func_0x(puVar1,puVar35,1,(longlong)&uStackX_8 + lVar10 + 0x10);
                if ((((*psVar16 != 0) &&
                     (plVar37 = *(longlong **)(psVar16 + 8), plVar37 != (longlong *)0x0)) &&
                    (*plVar37 != 0)) &&
                   (((*(byte *)((longlong)puVar35 + 6) & 8) == 0 &&
                    ((*(uint *)(&stack0x000000dc + lVar10) & 1) == 0)))) {
                  *(uint *)(&stack0xfffffffffffffff8 + lVar20 + lVar10) =
                       *(uint *)(&stack0x000000dc + lVar10);
                  *(longlong *)(&stack0xfffffffffffffff0 + lVar20 + lVar10) =
                       (longlong)&uStackX_8 + lVar10 + 0x10;
                  *(int *)(&stack0xffffffffffffffe8 + lVar20 + lVar10) = (int)uVar32;
                  *(undefined **)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = puVar42;
                  uVar44 = *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x10);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1051dd;
                  plVar38 = (longlong *)func_0x(plVar37,puVar35,plVar38,uVar44);
                }
                if (plVar38 == (longlong *)0x0) {
                  plVar38 = *(longlong **)(psVar16 + 4);
                }
              }
code_r0x001051ea:
              if ((*(int *)((longlong)&uStackX_8 + lVar10 + 0x10) == 0) &&
                 ((puVar35[0x10] & 0x2000) != 0)) {
                *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x10) = 4;
                plVar38 = (longlong *)0x1511184;
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105210;
              iVar40 = func_0x(psVar16);
              if (iVar40 != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10521c;
                iVar40 = func_0x(puVar35);
                if (iVar40 != 0) break;
              }
              if ((uint)*(ushort *)(puVar35 + 0xf) < *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10)
                 ) {
                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105248;
                (*_DAT_)(6,0x52,0x16,0x91);
              }
              break;
            case 5:
              plVar38 = *(longlong **)(psVar16 + 4);
              if (*psVar16 == 0) {
                puVar1 = (ushort *)(psVar16 + 1);
                uVar36 = *(uint *)(psVar16 + 2);
                if (uVar36 == 0) {
                  *puVar1 = 0;
                  uVar36 = *(uint *)(psVar16 + 8);
                  uVar26 = (ulonglong)uVar36;
                  *(uint *)(psVar16 + 10) = uVar36;
                  pbVar33 = *(byte **)(psVar16 + 4);
                  bVar8 = *pbVar33;
                  if ((bVar8 & 0x10) != 0) {
                    uVar36 = uVar36 + (*(ushort *)(pbVar33 + uVar26) + 7 >> 3) + 2;
                    uVar26 = (ulonglong)uVar36;
                    *(uint *)(psVar16 + 10) = uVar36;
                    bVar8 = *pbVar33;
                  }
                  psVar11 = psVar16;
                  if ((bVar8 & 0x20) == 0) {
                    *(int *)(psVar16 + 2) = (int)uVar26;
                    psVar16[0xe] = 0;
                    *(uint *)(psVar16 + 0xc) = uVar36;
                  }
                  else {
                    puVar43 = (ushort *)(pbVar33 + uVar26);
                    *(ushort **)(&stack0x00000068 + lVar10) = puVar43;
                    uVar25 = *puVar43;
                    psVar16[0xe] = uVar25;
                    if (uVar25 == 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105d1a;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105d23;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105d3d;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105d59;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105d7f;
                            (*_DAT_)(1,0x176a5bc,0x188a6a8,0x80f);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar16 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105d8d;
                      func_0x(uVar13,3);
                      uVar25 = psVar16[0xe];
                      uVar36 = *(uint *)(psVar16 + 10);
                    }
                    uVar36 = uVar36 + (uVar25 + 1) * 2;
                    *(uint *)(psVar16 + 0xc) = uVar36;
                    if (0x1f9e < uVar36) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105dbc;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105dc5;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105ddf;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105dfb;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105e21;
                            (*_DAT_)(1,0x176a5bc,0x188a6a8,0x816);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar16 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105e2f;
                      func_0x(uVar13,4);
                      uVar25 = psVar16[0xe];
                      uVar36 = *(uint *)(psVar16 + 0xc);
                    }
                    uVar26 = (ulonglong)uVar25;
                    uVar25 = puVar43[uVar26];
                    *(uint *)(psVar16 + 2) = uVar25 & 0x7fff;
                    if ((uVar25 & 0x7fff) < uVar36) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105e5d;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105e66;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105e80;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105e9c;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105ec2;
                            (*_DAT_)(1,0x176a5bc,0x188a6a8,0x81d);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar16 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105ed0;
                      func_0x(uVar13,4);
                      uVar36 = *(uint *)(psVar16 + 0xc);
                      uVar26 = (ulonglong)(ushort)psVar16[0xe];
                    }
                    if ((short)uVar26 != 0) {
                      do {
                        puVar43 = puVar43 + 1;
                        uVar23 = *puVar43 & 0x7fff;
                        if ((uVar23 < uVar36) || (*(uint *)(psVar16 + 2) < uVar23)) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105f0f;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105f18;
                            lVar12 = func_0x();
                            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105f32;
                              cVar7 = func_0x(0x1e7abb0);
                              if (cVar7 == '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105f4e;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105f72;
                                (*_DAT_)(1,0x176a5bc,0x188a6a8,0x82a);
                              }
                            }
                          }
                          uVar13 = *(undefined8 *)(psVar16 + 4);
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105f80;
                          func_0x(uVar13,4);
                        }
                        uVar39 = (int)plVar37 + 1;
                        plVar37 = (longlong *)(ulonglong)uVar39;
                        uVar26 = (ulonglong)(ushort)psVar16[0xe];
                        uVar36 = uVar23;
                      } while ((int)uVar39 < (int)(uint)(ushort)psVar16[0xe]);
                      puVar43 = *(ushort **)(&stack0x00000068 + lVar10);
                      psVar11 = *(short **)(&stack0x00000048 + lVar10);
                    }
                    if ((short)puVar43[(ulonglong)((int)uVar26 - 1) + 1] < 0) {
                      do {
                        lVar12 = *(longlong *)(psVar16 + 4);
                        lVar14 = (ulonglong)*(uint *)(psVar16 + 10) + lVar12;
                        uVar23 = *(ushort *)(lVar14 + uVar26 * 2) & 0x7fff;
                        if ((int)uVar26 == 1) {
                          uVar39 = *(uint *)(psVar16 + 0xc);
                          uVar3 = uVar39;
code_r0x00105ff7:
                          if ((uVar23 < uVar39) ||
                             (uVar36 = *(uint *)(psVar16 + 2), uVar36 < uVar23))
                          goto code_r0x00106002;
                        }
                        else {
                          uVar39 = *(ushort *)(lVar14 + -2 + uVar26 * 2) & 0x7fff;
                          uVar3 = *(uint *)(psVar11 + 0xc);
                          if (uVar3 <= uVar39) goto code_r0x00105ff7;
code_r0x00106002:
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10600f;
                          func_0x(lVar12,7);
                          uVar3 = *(uint *)(psVar11 + 0xc);
                          uVar36 = *(uint *)(psVar11 + 2);
                        }
                        if ((uVar39 < uVar3) || (uVar36 < uVar39)) goto code_r0x0010635d;
                        if (*(ushort *)((ulonglong)uVar39 + *(longlong *)(psVar16 + 4)) == 5) {
                          *puVar1 = *puVar1 | 2;
                          psVar16[0xe] = psVar16[0xe] + -1;
                          psVar16[0x15] = (short)uVar39;
                          uVar26 = *(ulonglong *)(psVar16 + 4);
                          uVar25 = *(ushort *)((ulonglong)(uVar39 & 0xffff) + 2 + uVar26);
                          uVar9 = psVar16[0x16] & 0xc7ff;
                          if ((uVar25 >> 0xe & 1) != 0) {
                            uVar9 = uVar25 & 0x3800 | uVar9;
                          }
                          psVar16[0x16] = uVar9;
                          uVar25 = (uVar9 ^ *(ushort *)((ulonglong)(uVar39 & 0xffff) + 2 + uVar26))
                                   & 0x7ff ^ uVar9;
                          psVar16[0x16] = uVar25;
                          uVar32 = (ulonglong)(ushort)psVar16[0x15];
                          uVar31 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                                   uVar32 + (uVar9 >> 0xb & 7) * 2 + uVar26;
                          if (uVar31 < uVar32 + uVar26) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106122;
                            func_0x(uVar32 + uVar26,0x19);
                            uVar25 = psVar16[0x16];
                            uVar32 = (ulonglong)(ushort)psVar16[0x15];
                            uVar26 = (ulonglong)*(uint *)(psVar16 + 4);
                          }
                          if (uVar23 - uVar39 <
                              (((uVar25 & 0x7ff) * 2 - (int)uVar32) - (int)uVar26) + (int)uVar31) {
                            lVar12 = *(longlong *)(psVar16 + 4);
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10615a;
                            func_0x(uVar32 + lVar12,0x19);
                            uVar25 = psVar16[0x16];
                          }
                          if ((uVar25 & 0x3800) != 0) {
                            puVar43 = (ushort *)
                                      (*(longlong *)(psVar16 + 4) +
                                      (ulonglong)(ushort)psVar16[0x15] + 4);
                            iVar40 = 0;
                            if ((uVar25 & 0x3800) != 0) {
                              do {
                                if ((uVar25 & 0x7ff) < (*puVar43 & 0x7ff)) {
                                  uVar25 = psVar16[0x15];
                                  lVar12 = *(longlong *)(psVar16 + 4);
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1061b7
                                  ;
                                  func_0x((ulonglong)uVar25 + lVar12,0x1a);
                                  uVar25 = psVar16[0x16];
                                }
                                iVar40 = iVar40 + 1;
                                puVar43 = puVar43 + 1;
                              } while (iVar40 < (int)(uVar25 >> 0xb & 7));
                            }
                          }
                          goto code_r0x001061d2;
                        }
                        if (*(ushort *)((ulonglong)uVar39 + *(longlong *)(psVar16 + 4)) < 0x400)
                        goto code_r0x001061d2;
                        *puVar1 = *puVar1 | 1;
                        uVar25 = psVar16[0xe] - 1;
                        psVar16[0xe] = uVar25;
                        if (uVar25 == 0) goto code_r0x001061d2;
                        uVar26 = (ulonglong)uVar25;
                      } while ((short)puVar43[(ulonglong)(uVar25 - 1) + 1] < 0);
                      pbVar33 = *(byte **)(psVar16 + 4);
                    }
                    else {
code_r0x001061d2:
                      pbVar33 = *(byte **)(psVar16 + 4);
                    }
                  }
                  if ((*pbVar33 & 0x40) == 0) {
                    *(undefined4 *)(psVar16 + 0x13) = 0;
                    uVar36 = *(uint *)(psVar11 + 2);
                  }
                  else {
                    *(int *)(psVar16 + 0x13) = *(int *)(psVar16 + 2);
                    *(int *)(psVar16 + 2) = *(int *)(psVar16 + 2) + 0xe;
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1061fe;
                    uVar13 = func_0x(puVar1);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10620d;
                    func_0x(uVar13,&stack0x00000270 + lVar10);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106219;
                    iVar40 = func_0x(&stack0x00000270 + lVar10);
                    *(int *)(psVar16 + 2) = *(int *)(psVar16 + 2) + iVar40;
                    uVar36 = *(uint *)(psVar16 + 2);
                  }
                  if ((*(ulonglong *)(psVar16 + 0xf) != 0) &&
                     (*(ulonglong *)(psVar16 + 0xf) < (ulonglong)uVar36 + *(longlong *)(psVar16 + 4)
                     )) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106251;
                    cVar7 = func_0x(0x1e7abb0);
                    if (cVar7 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10625a;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106274;
                        cVar7 = func_0x(0x1e7abb0);
                        if (cVar7 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106290;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1062b6;
                          (*_DAT_)(1,0x176a5bc,0x188a6a8,0x886);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar16 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1062c4;
                    func_0x(uVar13);
                    uVar36 = *(uint *)(psVar11 + 2);
                  }
                  if ((uVar36 == 0) || (0x3f3c < uVar36)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1062e5;
                    cVar7 = func_0x(0x1e7abb0);
                    if (cVar7 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1062ee;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106308;
                        cVar7 = func_0x(0x1e7abb0);
                        if (cVar7 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106324;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10634a;
                          (*_DAT_)(1,0x176a5bc,0x188a6a8,0x88b);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar16 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106358;
                    func_0x(uVar13);
                    uVar36 = *(uint *)(psVar11 + 2);
                  }
                }
code_r0x0010635d:
                if ((uVar36 < 9) &&
                   (((**(byte **)(psVar16 + 4) & 0xe) == 0 ||
                    ((**(byte **)(psVar16 + 4) & 0xe) == 0xc)))) {
                  uVar36 = 9;
                }
                puVar35 = *(uint **)(&stack0x00000050 + lVar10);
                *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10) = uVar36;
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106390;
                uVar44 = func_0x(psVar16 + 1);
                *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x10) = uVar44;
              }
              break;
            case 6:
            case 7:
            case 9:
            case 10:
            case 0xb:
            case 0xe:
            case 0xf:
            case 0x19:
              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1063ad;
              func_0x(&stack0x00000170 + lVar10,puVar35,&stack0x00000070 + lVar10);
              goto code_r0x00105bc1;
            case 8:
              iVar40 = puVar35[0x10] << 0xc;
              uVar25 = *(ushort *)(puVar35 + 0xf);
              if (*psVar16 == 0) {
                puVar1 = (ushort *)(psVar16 + 1);
                if ((*puVar35 & 0xc0000000) == 0x80000000) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105b33;
                  iVar40 = func_0x(puVar1);
                  if (iVar40 == 0) goto code_r0x00105b57;
                  *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105b4e;
                  plVar38 = (longlong *)
                            func_0x(psVar16 + 0x15,puVar35,
                                            (longlong)&uStackX_8 + lVar10 + 0x10,
                                            &stack0x000001f8 + lVar10);
                }
                else {
                  if ((iVar40 < 0) || ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0)) {
                    *(undefined **)(&stack0xffffffffffffffe0 + lVar20 + lVar10) =
                         &stack0x000000e4 + lVar10;
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1052cb;
                    func_0x(puVar1,puVar35,iVar40 < 0,&stack0x000000e0 + lVar10);
                    if ((iVar40 < 0) && (*(int *)(&stack0x000000e0 + lVar10) != 0)) {
                      *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x10) = 0;
                      plVar38 = (longlong *)0x0;
                      break;
                    }
                    iVar40 = *(int *)(&stack0x000000e4 + lVar10);
                  }
                  else {
                    *(undefined4 *)(&stack0x000000e0 + lVar10) = 0;
                    iVar40 = 1;
                    *(undefined4 *)(&stack0x000000e4 + lVar10) = 1;
                  }
                  iVar29 = 0;
                  if ((iVar40 == 0) && ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0)) {
                    puVar19 = *(undefined4 **)(puVar35 + 2);
                    *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x10) = *puVar19;
                    plVar38 = (longlong *)(puVar19 + 1);
                  }
                  else if ((int)*puVar35 < 0) {
                    psVar11 = psVar16;
                    if (*(int *)(psVar16 + 2) == 0) {
                      *puVar1 = 0;
                      uVar36 = *(uint *)(psVar16 + 8);
                      uVar26 = (ulonglong)uVar36;
                      *(uint *)(psVar16 + 10) = uVar36;
                      pbVar33 = *(byte **)(psVar16 + 4);
                      bVar8 = *pbVar33;
                      if ((bVar8 & 0x10) != 0) {
                        uVar36 = uVar36 + (*(ushort *)(pbVar33 + uVar26) + 7 >> 3) + 2;
                        uVar26 = (ulonglong)uVar36;
                        *(uint *)(psVar16 + 10) = uVar36;
                        bVar8 = *pbVar33;
                      }
                      if ((bVar8 & 0x20) == 0) {
                        *(int *)(psVar16 + 2) = (int)uVar26;
                        psVar16[0xe] = 0;
                        *(uint *)(psVar16 + 0xc) = uVar36;
                      }
                      else {
                        puVar43 = (ushort *)(pbVar33 + uVar26);
                        uVar25 = *puVar43;
                        psVar16[0xe] = uVar25;
                        if (uVar25 == 0) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105429;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105432;
                            lVar12 = func_0x();
                            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10544c;
                              cVar7 = func_0x(0x1e7abb0);
                              if (cVar7 == '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105468;
                                (*_DAT_)(0x22,0x44,0x15,0x3eb);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10548b;
                                (*_DAT_)(1,0x176a5bc,0x188a6a8,0x80f);
                              }
                            }
                          }
                          uVar13 = *(undefined8 *)(psVar16 + 4);
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105499;
                          func_0x(uVar13,3);
                          uVar25 = psVar16[0xe];
                          uVar36 = *(uint *)(psVar16 + 10);
                        }
                        uVar36 = uVar36 + (uVar25 + 1) * 2;
                        *(uint *)(psVar16 + 0xc) = uVar36;
                        if (0x1f9e < uVar36) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1054c8;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1054d1;
                            lVar12 = func_0x();
                            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1054eb;
                              cVar7 = func_0x(0x1e7abb0);
                              if (cVar7 == '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105507;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10552a;
                                (*_DAT_)(1,0x176a5bc,0x188a6a8,0x816);
                              }
                            }
                          }
                          uVar13 = *(undefined8 *)(psVar16 + 4);
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105538;
                          func_0x(uVar13,4);
                          uVar25 = psVar16[0xe];
                          uVar36 = *(uint *)(psVar16 + 0xc);
                        }
                        uVar26 = (ulonglong)uVar25;
                        uVar25 = puVar43[uVar26];
                        *(uint *)(psVar16 + 2) = uVar25 & 0x7fff;
                        if ((uVar25 & 0x7fff) < uVar36) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105566;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 != '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10556f;
                            lVar12 = func_0x();
                            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105589;
                              cVar7 = func_0x(0x1e7abb0);
                              if (cVar7 == '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1055a5;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1055c8;
                                (*_DAT_)(1,0x176a5bc,0x188a6a8,0x81d);
                              }
                            }
                          }
                          uVar13 = *(undefined8 *)(psVar16 + 4);
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1055d6;
                          func_0x(uVar13,4);
                          uVar36 = *(uint *)(psVar16 + 0xc);
                          uVar26 = (ulonglong)(ushort)psVar16[0xe];
                        }
                        puVar6 = puVar43;
                        iVar40 = iVar29;
                        if ((short)uVar26 != 0) {
                          do {
                            uVar23 = puVar6[1] & 0x7fff;
                            if ((uVar23 < uVar36) || (*(uint *)(psVar16 + 2) < uVar23)) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10561f;
                              cVar7 = func_0x(0x1e7abb0);
                              if (cVar7 != '\0') {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105628;
                                lVar12 = func_0x();
                                if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105642
                                  ;
                                  cVar7 = func_0x(0x1e7abb0);
                                  if (cVar7 == '\0') {
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) =
                                         0x10565e;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) =
                                         0x105682;
                                    (*_DAT_)(1,0x176a5bc,0x188a6a8,0x82a);
                                  }
                                }
                              }
                              uVar13 = *(undefined8 *)(psVar16 + 4);
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105690;
                              func_0x(uVar13,4);
                            }
                            iVar40 = iVar40 + 1;
                            uVar26 = (ulonglong)(ushort)psVar16[0xe];
                            puVar6 = puVar6 + 1;
                            uVar36 = uVar23;
                          } while (iVar40 < (int)(uint)(ushort)psVar16[0xe]);
                          psVar11 = *(short **)(&stack0x00000048 + lVar10);
                        }
                        if ((short)puVar43[(ulonglong)((int)uVar26 - 1) + 1] < 0) {
                          do {
                            lVar12 = *(longlong *)(psVar16 + 4);
                            lVar14 = (ulonglong)*(uint *)(psVar16 + 10) + lVar12;
                            uVar36 = *(ushort *)(lVar14 + uVar26 * 2) & 0x7fff;
                            if ((int)uVar26 == 1) {
                              uVar23 = *(uint *)(psVar16 + 0xc);
                              uVar39 = uVar23;
code_r0x001056f7:
                              if ((uVar36 < uVar23) || (*(uint *)(psVar16 + 2) < uVar36))
                              goto code_r0x00105700;
                            }
                            else {
                              uVar23 = *(ushort *)(lVar14 + -2 + uVar26 * 2) & 0x7fff;
                              uVar39 = *(uint *)(psVar11 + 0xc);
                              if (uVar39 <= uVar23) goto code_r0x001056f7;
code_r0x00105700:
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10570d;
                              func_0x(lVar12,7);
                              uVar39 = *(uint *)(psVar11 + 0xc);
                            }
                            if ((uVar23 < uVar39) || (*(uint *)(psVar16 + 2) < uVar23)) {
                              puVar35 = *(uint **)(&stack0x00000050 + lVar10);
                              goto code_r0x00105a5f;
                            }
                            if (*(ushort *)((ulonglong)uVar23 + *(longlong *)(psVar16 + 4)) == 5) {
                              *puVar1 = *puVar1 | 2;
                              psVar16[0xe] = psVar16[0xe] + -1;
                              psVar16[0x15] = (short)uVar23;
                              uVar26 = *(ulonglong *)(psVar16 + 4);
                              uVar25 = *(ushort *)((ulonglong)(uVar23 & 0xffff) + 2 + uVar26);
                              uVar9 = psVar16[0x16] & 0xc7ff;
                              if ((uVar25 >> 0xe & 1) != 0) {
                                uVar9 = uVar25 & 0x3800 | uVar9;
                              }
                              psVar16[0x16] = uVar9;
                              uVar25 = (uVar9 ^ *(ushort *)
                                                 ((ulonglong)(uVar23 & 0xffff) + 2 + uVar26)) &
                                       0x7ff ^ uVar9;
                              psVar16[0x16] = uVar25;
                              uVar32 = (ulonglong)(ushort)psVar16[0x15];
                              uVar31 = (ulonglong)((uVar25 & 0x7ff) * 2) + 4 +
                                       uVar32 + (uVar9 >> 0xb & 7) * 2 + uVar26;
                              if (uVar31 < uVar32 + uVar26) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10581e;
                                func_0x(uVar32 + uVar26,0x19);
                                uVar25 = psVar16[0x16];
                                uVar32 = (ulonglong)(ushort)psVar16[0x15];
                                uVar26 = (ulonglong)*(uint *)(psVar16 + 4);
                              }
                              if (uVar36 - uVar23 <
                                  (((uVar25 & 0x7ff) * 2 - (int)uVar32) - (int)uVar26) + (int)uVar31
                                 ) {
                                lVar12 = *(longlong *)(psVar16 + 4);
                                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105856;
                                func_0x(uVar32 + lVar12,0x19);
                                uVar25 = psVar16[0x16];
                              }
                              if (((uVar25 & 0x3800) != 0) &&
                                 (puVar43 = (ushort *)
                                            (*(longlong *)(psVar16 + 4) + 4 +
                                            (ulonglong)(ushort)psVar16[0x15]),
                                 (uVar25 & 0x3800) != 0)) {
                                do {
                                  if ((uVar25 & 0x7ff) < (*puVar43 & 0x7ff)) {
                                    uVar25 = psVar16[0x15];
                                    lVar12 = *(longlong *)(psVar16 + 4);
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) =
                                         0x1058a8;
                                    func_0x((ulonglong)uVar25 + lVar12,0x1a);
                                    uVar25 = psVar16[0x16];
                                  }
                                  iVar29 = iVar29 + 1;
                                  puVar43 = puVar43 + 1;
                                } while (iVar29 < (int)(uVar25 >> 0xb & 7));
                              }
                              goto code_r0x001058c3;
                            }
                            if (*(ushort *)((ulonglong)uVar23 + *(longlong *)(psVar16 + 4)) < 0x400)
                            goto code_r0x001058c3;
                            *puVar1 = *puVar1 | 1;
                            uVar25 = psVar16[0xe] - 1;
                            psVar16[0xe] = uVar25;
                            if (uVar25 == 0) goto code_r0x001058c3;
                            uVar26 = (ulonglong)uVar25;
                          } while ((short)puVar43[(ulonglong)(uVar25 - 1) + 1] < 0);
                          pbVar33 = *(byte **)(psVar16 + 4);
                          puVar35 = *(uint **)(&stack0x00000050 + lVar10);
                        }
                        else {
code_r0x001058c3:
                          pbVar33 = *(byte **)(psVar16 + 4);
                          puVar35 = *(uint **)(&stack0x00000050 + lVar10);
                        }
                      }
                      if ((*pbVar33 & 0x40) == 0) {
                        *(undefined4 *)(psVar16 + 0x13) = 0;
                        uVar36 = *(uint *)(psVar11 + 2);
                      }
                      else {
                        *(int *)(psVar16 + 0x13) = *(int *)(psVar16 + 2);
                        *(int *)(psVar16 + 2) = *(int *)(psVar16 + 2) + 0xe;
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1058f2;
                        uVar13 = func_0x(puVar1);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105901;
                        func_0x(uVar13,&stack0x00000268 + lVar10);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10590d;
                        iVar40 = func_0x(&stack0x00000268 + lVar10);
                        *(int *)(psVar16 + 2) = *(int *)(psVar16 + 2) + iVar40;
                        uVar36 = *(uint *)(psVar16 + 2);
                      }
                      if ((*(ulonglong *)(psVar16 + 0xf) != 0) &&
                         (*(ulonglong *)(psVar16 + 0xf) <
                          (ulonglong)uVar36 + *(longlong *)(psVar16 + 4))) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105946;
                        cVar7 = func_0x(0x1e7abb0);
                        if (cVar7 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10594f;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105969;
                            cVar7 = func_0x(0x1e7abb0);
                            if (cVar7 == '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105985;
                              (*_DAT_)(0x22,0x44,0x15,0x3fa);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1059ab;
                              (*_DAT_)(1,0x176a5bc,0x188a6a8,0x886);
                            }
                          }
                        }
                        uVar13 = *(undefined8 *)(psVar16 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1059b9;
                        func_0x(uVar13);
                        uVar36 = *(uint *)(psVar11 + 2);
                      }
                      if (0x3f3b < uVar36 - 1) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1059d8;
                        cVar7 = func_0x(0x1e7abb0);
                        if (cVar7 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1059e1;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1059fb;
                            cVar7 = func_0x(0x1e7abb0);
                            if (cVar7 == '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105a17;
                              (*_DAT_)(0x22,0x44,0x15,0x3ed);
                              uVar13 = *(undefined8 *)(psVar16 + 4);
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105a25;
                              func_0x(uVar13);
                              goto code_r0x00105a5f;
                            }
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105a4b;
                            (*_DAT_)(1,0x176a5bc,0x188a6a8,0x88b);
                          }
                        }
                        uVar13 = *(undefined8 *)(psVar16 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105a59;
                        func_0x(uVar13);
                      }
                    }
code_r0x00105a5f:
                    sVar28 = -*(short *)puVar35;
                    if ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0) {
                      *(undefined **)(&stack0xffffffffffffffe0 + lVar20 + lVar10) =
                           &stack0x00000130 + lVar10;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105a8e;
                      func_0x(puVar1,puVar35,0,&stack0x000001f4 + lVar10);
                      if (*(int *)(&stack0x00000130 + lVar10) == 0) {
                        puVar19 = *(undefined4 **)(puVar35 + 2);
                        *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x10) = *puVar19;
                        plVar38 = (longlong *)(puVar19 + 1);
                        break;
                      }
                    }
                    lVar12 = (longlong)sVar28;
                    if ((uint)(ushort)psVar16[0xe] < (uint)(int)sVar28) {
                      *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x10) = 0;
                      plVar38 = *(longlong **)(psVar16 + 4);
                    }
                    else {
                      lVar14 = *(longlong *)(psVar16 + 4);
                      lVar18 = (ulonglong)*(uint *)(psVar16 + 10) + lVar14;
                      if (sVar28 == 1) {
                        uVar36 = *(uint *)(psVar16 + 0xc);
                        uVar23 = *(ushort *)(lVar18 + lVar12 * 2) & 0x7fff;
code_r0x00105af9:
                        if ((uVar23 < uVar36) || (*(uint *)(psVar16 + 2) < uVar23))
                        goto code_r0x00105b02;
                      }
                      else {
                        uVar36 = *(ushort *)(lVar18 + -2 + lVar12 * 2) & 0x7fff;
                        uVar23 = *(ushort *)(lVar18 + lVar12 * 2) & 0x7fff;
                        lVar14 = *(longlong *)(psVar11 + 4);
                        if (*(uint *)(psVar11 + 0xc) <= uVar36) goto code_r0x00105af9;
code_r0x00105b02:
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105b0f;
                        func_0x(lVar14);
                      }
                      *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10) = uVar23 - uVar36;
                      plVar38 = (longlong *)((ulonglong)uVar36 + *(longlong *)(psVar16 + 4));
                    }
                  }
                  else if ((*(ushort *)((longlong)puVar35 + 6) & 8) == 0) {
                    if ((*(ushort *)((longlong)puVar35 + 6) & 0x10) != 0) {
                      *(undefined **)(&stack0xffffffffffffffe0 + lVar20 + lVar10) =
                           &stack0x0000012c + lVar10;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10534f;
                      func_0x(puVar1,puVar35,0,&stack0x000001f0 + lVar10);
                      if (*(int *)(&stack0x0000012c + lVar10) == 0) {
                        plVar38 = (longlong *)(*(uint **)(puVar35 + 2) + 1);
                        uVar36 = **(uint **)(puVar35 + 2);
                        if ((uVar25 != 0) && (uVar36 != uVar25)) {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10538f;
                          (*_DAT_)(1,0x1918a00,0x1917368,0x381);
                        }
                        *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10) = uVar36;
                        break;
                      }
                    }
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 0x10) = (uint)uVar25;
                    plVar38 = (longlong *)((longlong)(int)*puVar35 + *(longlong *)(psVar16 + 4));
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1053b9;
                    plVar38 = (longlong *)
                              func_0x
                                        (puVar1,puVar35,(longlong)&uStackX_8 + lVar10 + 0x10);
                  }
                }
              }
              else {
                *(undefined4 *)(&stack0x000000e8 + lVar10) = 0;
                *(undefined **)(&stack0xffffffffffffffe0 + lVar20 + lVar10) =
                     &stack0x000000e8 + lVar10;
                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105c2f;
                plVar38 = (longlong *)
                          func_0x(psVar16 + 1,puVar35,iVar40 < 0,
                                          (longlong)&uStackX_8 + lVar10 + 0x10);
                if ((((*psVar16 != 0) &&
                     (plVar37 = *(longlong **)(psVar16 + 8), plVar37 != (longlong *)0x0)) &&
                    (*plVar37 != 0)) &&
                   (((*(byte *)((longlong)puVar35 + 6) & 8) == 0 &&
                    ((*(uint *)(&stack0x000000e8 + lVar10) & 1) == 0)))) {
                  *(uint *)(&stack0xfffffffffffffff8 + lVar20 + lVar10) =
                       *(uint *)(&stack0x000000e8 + lVar10);
                  *(longlong *)(&stack0xfffffffffffffff0 + lVar20 + lVar10) =
                       (longlong)&uStackX_8 + lVar10 + 0x10;
                  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar20 + lVar10) = 0;
                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                  uVar44 = *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x10);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105c92;
                  plVar38 = (longlong *)func_0x(plVar37,puVar35,plVar38,uVar44);
                }
              }
              break;
            case 0xd:
            case 0x1b:
              *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x10) = 0;
              plVar38 = plVar37;
              break;
            case 0x10:
              uVar13 = *(undefined8 *)
                        (*(longlong *)(*(longlong *)(&stack0x00000060 + lVar10) + 8) + 0x160);
              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1063ce;
              piVar17 = (int *)func_0x(uVar13,0);
              *(int **)(&stack0x00000278 + lVar10) = piVar17;
              *(undefined4 *)(&stack0x0000003c + lVar10) = 0;
              *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
              iVar40 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000060 + lVar10) + 8) + 0x100)
              ;
              if (iVar40 == 2) {
                psVar11 = *(short **)(&stack0x00000048 + lVar10);
                if (*psVar11 == 0) {
                  puVar1 = (ushort *)(psVar11 + 1);
                  psVar16 = psVar11;
                  if (*(int *)(psVar11 + 2) == 0) {
                    iVar40 = 0;
                    *puVar1 = 0;
                    uVar36 = *(uint *)(psVar11 + 8);
                    uVar26 = (ulonglong)uVar36;
                    *(uint *)(psVar11 + 10) = uVar36;
                    pbVar33 = *(byte **)(psVar11 + 4);
                    bVar8 = *pbVar33;
                    if ((bVar8 & 0x10) != 0) {
                      uVar36 = uVar36 + 2 + (*(ushort *)(pbVar33 + uVar26) + 7 >> 3);
                      uVar26 = (ulonglong)uVar36;
                      *(uint *)(psVar11 + 10) = uVar36;
                      bVar8 = *pbVar33;
                    }
                    if ((bVar8 & 0x20) == 0) {
                      *(int *)(psVar11 + 2) = (int)uVar26;
                      psVar11[0xe] = 0;
                      *(uint *)(psVar11 + 0xc) = uVar36;
                    }
                    else {
                      puVar43 = (ushort *)(pbVar33 + uVar26);
                      *(ushort **)(&stack0x00000068 + lVar10) = puVar43;
                      uVar25 = *puVar43;
                      psVar11[0xe] = uVar25;
                      if (uVar25 == 0) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106476;
                        cVar7 = func_0x(0x1e7abb0);
                        if (cVar7 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10647f;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106499;
                            cVar7 = func_0x(0x1e7abb0);
                            if (cVar7 == '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1064b5;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1064db;
                              (*_DAT_)(1,0x176a5bc,0x188a6a8,0x80f);
                            }
                          }
                        }
                        uVar13 = *(undefined8 *)(psVar11 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1064e9;
                        func_0x(uVar13,3);
                        uVar25 = psVar11[0xe];
                        uVar36 = *(uint *)(psVar11 + 10);
                      }
                      uVar36 = uVar36 + (uVar25 + 1) * 2;
                      *(uint *)(psVar11 + 0xc) = uVar36;
                      if (0x1f9e < uVar36) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106518;
                        cVar7 = func_0x(0x1e7abb0);
                        if (cVar7 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106521;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10653b;
                            cVar7 = func_0x(0x1e7abb0);
                            if (cVar7 == '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106557;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10657d;
                              (*_DAT_)(1,0x176a5bc,0x188a6a8,0x816);
                            }
                          }
                        }
                        uVar13 = *(undefined8 *)(psVar11 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10658b;
                        func_0x(uVar13,4);
                        uVar25 = psVar11[0xe];
                        uVar36 = *(uint *)(psVar11 + 0xc);
                      }
                      uVar26 = (ulonglong)uVar25;
                      uVar25 = puVar43[uVar26];
                      *(uint *)(psVar11 + 2) = uVar25 & 0x7fff;
                      if ((uVar25 & 0x7fff) < uVar36) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1065b9;
                        cVar7 = func_0x(0x1e7abb0);
                        if (cVar7 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1065c2;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1065dc;
                            cVar7 = func_0x(0x1e7abb0);
                            if (cVar7 == '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1065f8;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10661e;
                              (*_DAT_)(1,0x176a5bc,0x188a6a8,0x81d);
                            }
                          }
                        }
                        uVar13 = *(undefined8 *)(psVar11 + 4);
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10662c;
                        func_0x(uVar13,4);
                        uVar36 = *(uint *)(psVar11 + 0xc);
                        uVar26 = (ulonglong)(ushort)psVar11[0xe];
                      }
                      if ((short)uVar26 != 0) {
                        do {
                          puVar43 = puVar43 + 1;
                          uVar23 = *puVar43 & 0x7fff;
                          if ((uVar23 < uVar36) || (*(uint *)(psVar11 + 2) < uVar23)) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10666f;
                            cVar7 = func_0x(0x1e7abb0);
                            if (cVar7 != '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106678;
                              lVar12 = func_0x();
                              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106692;
                                cVar7 = func_0x(0x1e7abb0);
                                if (cVar7 == '\0') {
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1066ae
                                  ;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                                  *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1066d2
                                  ;
                                  (*_DAT_)(1,0x176a5bc,0x188a6a8,0x82a);
                                }
                              }
                            }
                            uVar13 = *(undefined8 *)(psVar11 + 4);
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1066e0;
                            func_0x(uVar13,4);
                          }
                          iVar40 = iVar40 + 1;
                          uVar26 = (ulonglong)(ushort)psVar11[0xe];
                          uVar36 = uVar23;
                        } while (iVar40 < (int)(uint)(ushort)psVar11[0xe]);
                        puVar43 = *(ushort **)(&stack0x00000068 + lVar10);
                        piVar17 = *(int **)(&stack0x00000278 + lVar10);
                        psVar16 = *(short **)(&stack0x00000048 + lVar10);
                      }
                      if ((short)puVar43[(ulonglong)((int)uVar26 - 1) + 1] < 0) {
                        do {
                          lVar12 = *(longlong *)(psVar11 + 4);
                          lVar14 = (ulonglong)*(uint *)(psVar11 + 10) + lVar12;
                          if ((int)uVar26 == 1) {
                            uVar36 = *(uint *)(psVar11 + 0xc);
                            uVar31 = (ulonglong)uVar36;
                            uVar23 = *(ushort *)(lVar14 + uVar26 * 2) & 0x7fff;
code_r0x0010675f:
                            if ((uVar23 < (uint)uVar31) || (*(uint *)(psVar11 + 2) < uVar23))
                            goto code_r0x00106768;
                            psVar16 = *(short **)(&stack0x00000048 + lVar10);
                          }
                          else {
                            uVar39 = *(ushort *)(lVar14 + -2 + uVar26 * 2) & 0x7fff;
                            uVar31 = (ulonglong)uVar39;
                            uVar36 = *(uint *)(psVar16 + 0xc);
                            uVar23 = *(ushort *)(lVar14 + uVar26 * 2) & 0x7fff;
                            if (uVar36 <= uVar39) goto code_r0x0010675f;
code_r0x00106768:
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106775;
                            func_0x(lVar12,7);
                            psVar16 = *(short **)(&stack0x00000048 + lVar10);
                            uVar36 = *(uint *)(psVar16 + 0xc);
                          }
                          uVar39 = (uint)uVar31;
                          if ((uVar39 < uVar36) || (*(uint *)(psVar11 + 2) < uVar39))
                          goto code_r0x00106ac6;
                          if (*(ushort *)(uVar31 + *(longlong *)(psVar11 + 4)) == 5) {
                            *puVar1 = *puVar1 | 2;
                            psVar11[0xe] = psVar11[0xe] + -1;
                            psVar11[0x15] = (short)uVar31;
                            uVar26 = *(ulonglong *)(psVar11 + 4);
                            uVar25 = *(ushort *)((uVar31 & 0xffff) + 2 + uVar26);
                            uVar9 = psVar11[0x16] & 0xc7ff;
                            if ((uVar25 >> 0xe & 1) != 0) {
                              uVar9 = uVar25 & 0x3800 | uVar9;
                            }
                            psVar11[0x16] = uVar9;
                            uVar25 = (uVar9 ^ *(ushort *)((uVar31 & 0xffff) + 2 + uVar26)) & 0x7ff ^
                                     uVar9;
                            psVar11[0x16] = uVar25;
                            uVar32 = (ulonglong)(ushort)psVar11[0x15];
                            uVar31 = uVar26 + 4 +
                                     (ulonglong)((uVar25 & 0x7ff) * 2) +
                                     uVar32 + (uVar9 >> 0xb & 7) * 2;
                            if (uVar31 < uVar32 + uVar26) {
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106891;
                              func_0x(uVar32 + uVar26,0x19);
                              uVar25 = psVar11[0x16];
                              uVar32 = (ulonglong)(ushort)psVar11[0x15];
                              uVar26 = (ulonglong)*(uint *)(psVar11 + 4);
                            }
                            if (uVar23 - uVar39 <
                                (((uVar25 & 0x7ff) * 2 - (int)uVar32) - (int)uVar26) + (int)uVar31)
                            {
                              lVar12 = *(longlong *)(psVar11 + 4);
                              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1068c9;
                              func_0x(uVar32 + lVar12,0x19);
                              uVar25 = psVar11[0x16];
                            }
                            if ((uVar25 & 0x3800) != 0) {
                              puVar43 = (ushort *)
                                        (*(longlong *)(psVar11 + 4) +
                                        (ulonglong)(ushort)psVar11[0x15] + 4);
                              iVar40 = 0;
                              if ((uVar25 & 0x3800) != 0) {
                                do {
                                  if ((uVar25 & 0x7ff) < (*puVar43 & 0x7ff)) {
                                    uVar25 = psVar11[0x15];
                                    lVar12 = *(longlong *)(psVar11 + 4);
                                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) =
                                         0x106927;
                                    func_0x((ulonglong)uVar25 + lVar12,0x1a);
                                    uVar25 = psVar11[0x16];
                                  }
                                  iVar40 = iVar40 + 1;
                                  puVar43 = puVar43 + 1;
                                } while (iVar40 < (int)(uVar25 >> 0xb & 7));
                              }
                            }
                            goto code_r0x00106942;
                          }
                          if (*(ushort *)(uVar31 + *(longlong *)(psVar11 + 4)) < 0x400)
                          goto code_r0x00106942;
                          *puVar1 = *puVar1 | 1;
                          uVar25 = psVar11[0xe] - 1;
                          psVar11[0xe] = uVar25;
                          if (uVar25 == 0) goto code_r0x00106942;
                          uVar26 = (ulonglong)uVar25;
                          psVar16 = *(short **)(&stack0x00000048 + lVar10);
                        } while ((short)puVar43[(ulonglong)(uVar25 - 1) + 1] < 0);
                        pbVar33 = *(byte **)(psVar11 + 4);
                      }
                      else {
code_r0x00106942:
                        pbVar33 = *(byte **)(psVar11 + 4);
                        psVar16 = *(short **)(&stack0x00000048 + lVar10);
                      }
                    }
                    if ((*pbVar33 & 0x40) == 0) {
                      *(undefined4 *)(psVar11 + 0x13) = 0;
                      uVar36 = *(uint *)(psVar16 + 2);
                    }
                    else {
                      *(int *)(psVar11 + 0x13) = *(int *)(psVar11 + 2);
                      *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + 0xe;
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106972;
                      uVar13 = func_0x(puVar1);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106981;
                      func_0x(uVar13,&stack0x00000280 + lVar10);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10698d;
                      iVar40 = func_0x(&stack0x00000280 + lVar10);
                      *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar40;
                      uVar36 = *(uint *)(psVar11 + 2);
                    }
                    if ((*(ulonglong *)(psVar11 + 0xf) != 0) &&
                       (*(ulonglong *)(psVar11 + 0xf) <
                        (ulonglong)uVar36 + *(longlong *)(psVar11 + 4))) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1069c3;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1069cc;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1069e6;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106a02;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106a28;
                            (*_DAT_)(1,0x176a5bc,0x188a6a8,0x886);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar11 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106a36;
                      func_0x(uVar13,0x12);
                      uVar36 = *(uint *)(psVar16 + 2);
                    }
                    if (0x3f3b < uVar36 - 1) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106a4f;
                      cVar7 = func_0x(0x1e7abb0);
                      if (cVar7 != '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106a58;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106a72;
                          cVar7 = func_0x(0x1e7abb0);
                          if (cVar7 == '\0') {
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106a8e;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                            *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106ab4;
                            (*_DAT_)(1,0x176a5bc,0x188a6a8,0x88b);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar11 + 4);
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106ac2;
                      func_0x(uVar13,5);
                    }
                    psVar16 = *(short **)(&stack0x00000048 + lVar10);
                  }
code_r0x00106ac6:
                  sVar28 = -*(short *)piVar17;
                  if ((*(byte *)((longlong)piVar17 + 6) & 0x10) != 0) {
                    *(undefined **)(&stack0xffffffffffffffe0 + lVar20 + lVar10) =
                         &stack0x00000134 + lVar10;
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106af7;
                    func_0x(puVar1,piVar17,0,&stack0x000001fc + lVar10);
                    if (*(int *)(&stack0x00000134 + lVar10) == 0) {
                      piVar17 = *(int **)(piVar17 + 2);
                      iVar40 = *piVar17;
                      *(int *)(&stack0x0000003c + lVar10) = iVar40;
                      puVar34 = (ulonglong *)(piVar17 + 1);
                      puVar35 = *(uint **)(&stack0x00000050 + lVar10);
                      goto code_r0x00106c44;
                    }
                  }
                  lVar12 = (longlong)sVar28;
                  if ((uint)(ushort)psVar11[0xe] < (uint)(int)sVar28) {
                    iVar40 = 0;
                    *(undefined4 *)(&stack0x0000003c + lVar10) = 0;
                    puVar34 = *(ulonglong **)(psVar11 + 4);
                    puVar35 = *(uint **)(&stack0x00000050 + lVar10);
                  }
                  else {
                    lVar14 = *(longlong *)(psVar11 + 4);
                    lVar18 = (ulonglong)*(uint *)(psVar11 + 10) + lVar14;
                    if (sVar28 == 1) {
                      uVar26 = (ulonglong)*(uint *)(psVar11 + 0xc);
                      uVar23 = *(ushort *)(lVar18 + lVar12 * 2) & 0x7fff;
code_r0x00106b6f:
                      if ((uVar23 < (uint)uVar26) || (*(uint *)(psVar11 + 2) < uVar23))
                      goto code_r0x00106b78;
                    }
                    else {
                      uVar36 = *(ushort *)(lVar18 + -2 + lVar12 * 2) & 0x7fff;
                      uVar26 = (ulonglong)uVar36;
                      uVar23 = *(ushort *)(lVar18 + lVar12 * 2) & 0x7fff;
                      lVar14 = *(longlong *)(psVar16 + 4);
                      if (*(uint *)(psVar16 + 0xc) <= uVar36) goto code_r0x00106b6f;
code_r0x00106b78:
                      *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106b85;
                      func_0x(lVar14,7);
                    }
                    iVar40 = uVar23 - (int)uVar26;
                    *(int *)(&stack0x0000003c + lVar10) = iVar40;
                    puVar34 = (ulonglong *)(uVar26 + *(longlong *)(psVar11 + 4));
                    puVar35 = *(uint **)(&stack0x00000050 + lVar10);
                  }
                }
                else {
                  *(undefined4 *)(&stack0x000000ec + lVar10) = 0;
                  *(undefined **)(&stack0xffffffffffffffe0 + lVar20 + lVar10) =
                       &stack0x000000ec + lVar10;
                  *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106be6;
                  puVar34 = (ulonglong *)
                            func_0x(psVar11 + 1,piVar17,1,&stack0x0000003c + lVar10);
                  if ((((*psVar11 != 0) &&
                       (plVar37 = *(longlong **)(psVar11 + 8), plVar37 != (longlong *)0x0)) &&
                      (*plVar37 != 0)) &&
                     (((*(byte *)((longlong)piVar17 + 6) & 8) == 0 &&
                      ((*(uint *)(&stack0x000000ec + lVar10) & 1) == 0)))) {
                    *(uint *)(&stack0xfffffffffffffff8 + lVar20 + lVar10) =
                         *(uint *)(&stack0x000000ec + lVar10);
                    *(undefined **)(&stack0xfffffffffffffff0 + lVar20 + lVar10) =
                         &stack0x0000003c + lVar10;
                    *(int *)(&stack0xffffffffffffffe8 + lVar20 + lVar10) = (int)uVar32;
                    *(undefined **)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = puVar42;
                    uVar44 = *(undefined4 *)(&stack0x0000003c + lVar10);
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106c35;
                    puVar34 = (ulonglong *)func_0x(plVar37,piVar17,puVar34,uVar44);
                  }
                  iVar40 = *(int *)(&stack0x0000003c + lVar10);
                  if (puVar34 == (ulonglong *)0x0) {
                    puVar34 = *(ulonglong **)(psVar11 + 4);
                  }
                }
code_r0x00106c44:
                bVar8 = *(byte *)((longlong)puVar35 + 0x45);
                bVar22 = *(byte *)(puVar35 + 0x11);
                switch(*(undefined *)((longlong)puVar35 + 0x3e)) {
                case 0x30:
                  if (iVar40 == 0) {
                    *(undefined *)((longlong)&uStackX_8 + lVar10) = 0;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 1;
                  }
                  else {
                    *(byte *)((longlong)&uStackX_8 + lVar10) = *(byte *)puVar34;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 1;
                  }
                  break;
                case 0x34:
                  if (iVar40 == 0) {
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10) = 0;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 2;
                  }
                  else if (iVar40 == 1) {
                    *(ushort *)((longlong)&uStackX_8 + lVar10) = (*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10) = *(byte *)puVar34 ^ 0x80;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 2;
                  }
                  else {
                    if (iVar40 == 2) {
                      *(byte *)((longlong)&uStackX_8 + lVar10 + 1) = *(byte *)puVar34 ^ 0x80;
                      *(byte *)((longlong)&uStackX_8 + lVar10) = *(byte *)((longlong)puVar34 + 1);
                    }
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 2;
                  }
                  break;
                case 0x38:
                case 0x7a:
                  if (iVar40 == 0) {
                    *(undefined4 *)((longlong)&uStackX_8 + lVar10) = 0;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                  }
                  else if (iVar40 == 1) {
                    *(uint *)((longlong)&uStackX_8 + lVar10) = (*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10) = *(byte *)puVar34 ^ 0x80;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                  }
                  else if (iVar40 == 2) {
                    *(uint *)((longlong)&uStackX_8 + lVar10) = (*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 1) = *(byte *)puVar34 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10) = *(byte *)((longlong)puVar34 + 1);
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                  }
                  else if (iVar40 == 3) {
                    *(uint *)((longlong)&uStackX_8 + lVar10) = (*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 2) = *(byte *)puVar34 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 1) = *(byte *)((longlong)puVar34 + 1);
                    *(byte *)((longlong)&uStackX_8 + lVar10) = *(byte *)((longlong)puVar34 + 2);
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                  }
                  else {
                    if (iVar40 != 4) goto code_r0x0010706d;
                    uVar36 = *(uint *)puVar34;
                    *(uint *)((longlong)&uStackX_8 + lVar10) =
                         uVar36 >> 0x18 | (uVar36 & 0xff0000) >> 8 | (uVar36 & 0xff00) << 8 |
                         uVar36 << 0x18;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 3) = (byte)uVar36 ^ 0x80;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                  }
                  break;
                case 0x3a:
                  if (iVar40 == 4) {
                    *(uint *)((longlong)&uStackX_8 + lVar10) = *(uint *)puVar34;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                  }
                  else {
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10) = 0;
code_r0x00106f7c:
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 2) = *(undefined2 *)puVar34;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                  }
                  break;
                case 0x3b:
                  *(undefined4 *)((longlong)&uStackX_8 + lVar10) = 0;
                  if (iVar40 == 1) {
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 3) = *(byte *)puVar34;
code_r0x0010706d:
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                  }
                  else {
                    if (iVar40 == 2) goto code_r0x00106f7c;
                    if (iVar40 == 3) {
                      *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 1) = *(undefined2 *)puVar34;
                      *(byte *)((longlong)&uStackX_8 + lVar10 + 3) =
                           *(byte *)((longlong)puVar34 + 2);
                      *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                    }
                    else {
                      if (iVar40 != 4) goto code_r0x0010706d;
                      *(uint *)((longlong)&uStackX_8 + lVar10) = *(uint *)puVar34;
                      *(undefined4 *)(&stack0x00000040 + lVar10) = 4;
                    }
                  }
                  break;
                case 0x3c:
                case 0x3d:
                case 0x7f:
                  switch(iVar40) {
                  case 0:
                    *(undefined8 *)((longlong)&uStackX_8 + lVar10) = 0;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                    break;
                  case 1:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10) =
                         (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10) = *(byte *)puVar34 ^ 0x80;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                    break;
                  case 2:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10) =
                         (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 1) = *(byte *)puVar34 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10) = *(byte *)((longlong)puVar34 + 1);
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                    break;
                  case 3:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10) =
                         (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 2) = *(byte *)puVar34 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 1) = *(byte *)((longlong)puVar34 + 1);
                    *(byte *)((longlong)&uStackX_8 + lVar10) = *(byte *)((longlong)puVar34 + 2);
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                    break;
                  case 4:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10) =
                         (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                    uVar36 = *(uint *)puVar34;
                    *(uint *)((longlong)&uStackX_8 + lVar10) =
                         uVar36 >> 0x18 | (uVar36 & 0xff0000) >> 8 | (uVar36 & 0xff00) << 8 |
                         uVar36 << 0x18;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 3) = *(byte *)puVar34 ^ 0x80;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                    break;
                  case 5:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10) =
                         (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 4) = *(byte *)puVar34 ^ 0x80;
                    uVar36 = *(uint *)((longlong)puVar34 + 1);
                    *(uint *)((longlong)&uStackX_8 + lVar10) =
                         uVar36 >> 0x18 | (uVar36 & 0xff0000) >> 8 | (uVar36 & 0xff00) << 8 |
                         uVar36 << 0x18;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                    break;
                  case 6:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10) =
                         (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 5) = *(byte *)puVar34 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 4) = *(byte *)((longlong)puVar34 + 1);
                    uVar36 = *(uint *)((longlong)puVar34 + 2);
                    *(uint *)((longlong)&uStackX_8 + lVar10) =
                         uVar36 >> 0x18 | (uVar36 & 0xff0000) >> 8 | (uVar36 & 0xff00) << 8 |
                         uVar36 << 0x18;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                    break;
                  case 7:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10) =
                         (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 6) = *(byte *)puVar34 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 5) = *(byte *)((longlong)puVar34 + 1);
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 4) = *(byte *)((longlong)puVar34 + 2);
                    uVar36 = *(uint *)((longlong)puVar34 + 3);
                    *(uint *)((longlong)&uStackX_8 + lVar10) =
                         uVar36 >> 0x18 | (uVar36 & 0xff0000) >> 8 | (uVar36 & 0xff00) << 8 |
                         uVar36 << 0x18;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                    break;
                  case 8:
                    uVar26 = *puVar34;
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10) =
                         uVar26 >> 0x38 | (uVar26 & 0xff000000000000) >> 0x28 |
                         (uVar26 & 0xff0000000000) >> 0x18 | (uVar26 & 0xff00000000) >> 8 |
                         (uVar26 & 0xff000000) << 8 | (uVar26 & 0xff0000) << 0x18 |
                         (uVar26 & 0xff00) << 0x28 | uVar26 << 0x38;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 7) = (byte)uVar26 ^ 0x80;
                  default:
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  }
                  break;
                case 0x3e:
                  *(undefined8 *)((longlong)&uStackX_8 + lVar10) = 0;
                  switch(iVar40) {
                  case 1:
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 7) = *(byte *)puVar34;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                    break;
                  case 2:
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 6) = *(undefined2 *)puVar34;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                    break;
                  case 3:
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 5) = *(undefined2 *)puVar34;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 7) = *(byte *)((longlong)puVar34 + 2);
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                    break;
                  case 4:
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 4) = *(uint *)puVar34;
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                    break;
                  case 5:
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 3) = *(uint *)puVar34;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 7) = *(byte *)((longlong)puVar34 + 4);
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                    break;
                  case 6:
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 2) = *(uint *)puVar34;
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 6) =
                         *(undefined2 *)((longlong)puVar34 + 4);
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                    break;
                  case 7:
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 1) = *(uint *)puVar34;
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 5) =
                         *(undefined2 *)((longlong)puVar34 + 4);
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 7) = *(byte *)((longlong)puVar34 + 6);
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                    break;
                  case 8:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10) = *puVar34;
                  default:
                    *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  }
                  break;
                case 0x6a:
                case 0x6c:
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar20 + lVar10) =
                       &stack0x00000040 + lVar10;
                  *(longlong *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) =
                       (longlong)&uStackX_8 + lVar10;
                  *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x107173;
                  cVar7 = (*pcRam00000000013e6340)(puVar34,iVar40,bVar22 & 0x3f);
                  if (cVar7 == '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x107191;
                    (*_DAT_)(6,0x54,0x16,1);
                  }
                  break;
                case 0xad:
                case 0xaf:
                  (&stack0xffffffffffffffe0)[lVar20 + lVar10] =
                       *(undefined *)((longlong)puVar35 + 0x3e);
                  uVar44 = *(undefined4 *)(&stack0x00000040 + lVar10);
                  uVar4 = *(undefined4 *)(&stack0x0000003c + lVar10);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106fac;
                  func_0x(puVar34,uVar4,(longlong)&uStackX_8 + lVar10,uVar44);
                  break;
                case 0xbd:
                  *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106fe2;
                  func_0x(puVar34,iVar40,(longlong)&uStackX_8 + lVar10,bVar8 & 0x3f)
                  ;
                  *(undefined4 *)(&stack0x00000040 + lVar10) = 8;
                  break;
                case 0xe7:
                  *(undefined4 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) =
                       *(undefined4 *)(&stack0x00000040 + lVar10);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1071b4;
                  uVar44 = (*pcRam00000000013e6338)
                                     (&stack0x00000398 + lVar10,puVar34,iVar40,
                                      (longlong)&uStackX_8 + lVar10);
                  *(undefined4 *)(&stack0x00000040 + lVar10) = uVar44;
                  break;
                case 0xef:
                  *(undefined4 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) =
                       *(undefined4 *)(&stack0x00000040 + lVar10);
                  *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x106fcf;
                  (*pcRam00000000013e6348)
                            (&stack0x00000360 + lVar10,puVar34,iVar40,(longlong)&uStackX_8 + lVar10)
                  ;
                }
              }
              else if (iVar40 == 0) {
                uVar25 = *(ushort *)(puVar35 + 0xf);
                lVar12 = *(longlong *)(&stack0x00000048 + lVar10);
                if ((*(byte *)((longlong)piVar17 + 6) & 0x10) == 0) {
code_r0x00107240:
                  *(uint *)(&stack0x0000003c + lVar10) = (uint)uVar25;
                  puVar41 = (undefined8 *)((longlong)*piVar17 + *(longlong *)(lVar12 + 8));
                }
                else {
                  *(undefined **)(&stack0xffffffffffffffe0 + lVar20 + lVar10) =
                       &stack0x0000016c + lVar10;
                  *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x1071f7;
                  func_0x(lVar12 + 2,piVar17,0,&stack0x00000200 + lVar10);
                  if (*(int *)(&stack0x0000016c + lVar10) != 0) goto code_r0x00107240;
                  puVar41 = (undefined8 *)(*(uint **)(piVar17 + 2) + 1);
                  uVar36 = **(uint **)(piVar17 + 2);
                  if ((uVar25 != 0) && (uVar36 != uVar25)) {
                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) = 0;
                    *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x10723b;
                    (*_DAT_)(1,0x1918a00,0x1917368,0x381);
                  }
                  *(uint *)(&stack0x0000003c + lVar10) = uVar36;
                }
                *(undefined8 *)((longlong)&uStackX_8 + lVar10) = *puVar41;
              }
              lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
              if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar12 = *(longlong *)(&stack0x00000090 + lVar10);
              }
              lVar14 = *(longlong *)(puVar35 + 10);
              *(undefined8 *)(lVar14 + lVar12) = *(undefined8 *)((longlong)&uStackX_8 + lVar10);
              uVar36 = puVar35[0x10];
              if ((uVar36 >> 8 & 1) != 0) {
                uVar44 = *(undefined4 *)(&stack0x00000040 + lVar10);
                *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x107293;
                func_0x(&stack0x00000070 + lVar10,puVar35,uVar44);
                uVar36 = puVar35[0x10];
              }
              if ((uVar36 >> 10 & 1) != 0) {
                lVar18 = *(longlong *)(&stack0x00000088 + lVar10);
                if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) != 0) {
                  lVar18 = *(longlong *)(&stack0x00000090 + lVar10);
                }
                uVar21 = 0;
                if ((undefined8 *)(lVar14 + lVar12) == (undefined8 *)0x0) {
                  uVar21 = 3;
                }
                *(undefined *)(lVar18 + *(longlong *)(puVar35 + 0xc)) = uVar21;
              }
              goto code_r0x00105bc1;
            }
            uVar36 = puVar35[0x10];
            if ((uVar36 >> 10 & 1) != 0) {
              lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
              if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar12 = *(longlong *)(&stack0x00000090 + lVar10);
              }
              uVar21 = 0;
              if (plVar38 == (longlong *)0x0) {
                uVar21 = 3;
              }
              *(undefined *)(lVar12 + *(longlong *)(puVar35 + 0xc)) = uVar21;
              uVar36 = puVar35[0x10];
            }
            if ((uVar36 >> 9 & 1) != 0) {
              *(undefined4 *)(&stack0xffffffffffffffe0 + lVar20 + lVar10) =
                   *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 0x10);
              *(undefined8 *)((longlong)&uStack_48 + lVar20 + lVar10) = 0x105bb4;
              func_0x(&stack0x00000070 + lVar10);
            }
code_r0x00105bc1:
            uVar36 = *(int *)((longlong)auStackX_18 + lVar10 + 4) + 1;
            *(uint *)((longlong)auStackX_18 + lVar10 + 4) = uVar36;
            puVar35 = puVar35 + 0x14;
            *(uint **)(&stack0x00000050 + lVar10) = puVar35;
            psVar16 = *(short **)(&stack0x00000048 + lVar10);
            uVar32 = (ulonglong)*(uint *)((longlong)&psStackX_20 + lVar10);
            puVar42 = *(undefined **)(&stack0x00000288 + lVar10);
            puVar27 = &stack0xffffffffffffffc0 + lVar20 + lVar10;
          } while (uVar36 < *(uint *)(&stack0x00000058 + lVar10));
        }
      }
    }
    else {
      if (*psVar11 == -1) {
        *psVar11 = 1;
        uVar26 = (ulonglong)*(uint *)(&stack0x00000084 + lVar10);
      }
      puVar1 = (ushort *)(psVar11 + 1);
      puVar27 = &stack0xffffffffffffffc0 + lVar10;
      if ((uVar26 & 0x10) != 0) {
        uVar36 = *(uint *)(&stack0x00000080 + lVar10);
        lVar20 = *(longlong *)(&stack0x00000078 + lVar10);
        puVar27 = &stack0xffffffffffffffc0 + lVar10;
        plVar37 = plVar38;
        if (uVar36 != 0) {
          do {
            switch(*(undefined *)(lVar20 + 0x40)) {
            case 0:
              goto LAB_;
            case 1:
              uVar25 = *(ushort *)(lVar20 + 4);
              if (*puVar1 < uVar25) {
                uVar25 = ~(*(ushort *)(lVar20 + 6) >> 4) & 1;
              }
              else {
                bVar8 = *(byte *)((longlong)((int)(uVar25 - 1) / 2) +
                                  (ulonglong)(ushort)psVar11[0xc] + *(longlong *)(psVar11 + 4));
                bVar22 = bVar8 >> 4;
                if ((uVar25 & 1) != 0) {
                  bVar22 = bVar8 & 0xf;
                }
                uVar25 = (ushort)(bVar22 == 0);
              }
              if (uVar25 == 0) goto code_r0x00103f7c;
            case 0xd:
            case 0x1b:
              plVar37 = (longlong *)0x0;
              *(undefined4 *)(&stack0x00000044 + lVar10) = 0;
              break;
            case 2:
code_r0x00103f7c:
              plVar37 = (longlong *)0x0;
              break;
            case 3:
              uVar25 = *(ushort *)(lVar20 + 4);
              if (*puVar1 < uVar25) {
                uVar25 = ~(*(ushort *)(lVar20 + 6) >> 4) & 1;
              }
              else {
                bVar8 = *(byte *)((longlong)((int)(uVar25 - 1) / 2) +
                                  (ulonglong)(ushort)psVar11[0xc] + *(longlong *)(psVar11 + 4));
                bVar22 = bVar8 >> 4;
                if ((uVar25 & 1) != 0) {
                  bVar22 = bVar8 & 0xf;
                }
                uVar25 = (ushort)(bVar22 == 0);
              }
              if (uVar25 == 0) goto code_r0x00103fe2;
              plVar37 = (longlong *)0x0;
              *(undefined4 *)(&stack0x00000044 + lVar10) = 0;
              break;
            case 4:
code_r0x00103fe2:
              *(undefined4 *)(&stack0x00000110 + lVar10) = 0;
              *(undefined **)(&stack0xffffffffffffffe0 + lVar10) = &stack0x00000110 + lVar10;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10400d;
              plVar37 = (longlong *)func_0x(puVar1,lVar20,1,&stack0x00000044 + lVar10);
              if (plVar37 == (longlong *)0x0) {
                plVar37 = *(longlong **)(*(longlong *)((longlong)&psStackX_20 + lVar10) + 8);
              }
              if ((*(int *)(&stack0x00000044 + lVar10) == 0) &&
                 ((*(uint *)(lVar20 + 0x40) & 0x2000) != 0)) {
                *(undefined4 *)(&stack0x00000044 + lVar10) = 4;
                plVar37 = (longlong *)0x1511184;
              }
              if (((**(byte **)(*(longlong *)((longlong)&psStackX_20 + lVar10) + 8) & 0x1c) - 0x18 &
                  0xfffffffb) == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104057;
                iVar40 = func_0x();
                if (iVar40 != 0) break;
              }
              if ((uint)*(ushort *)(lVar20 + 0x3c) < *(uint *)(&stack0x00000044 + lVar10)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10407a;
                (*_DAT_)(6,0x52,0x16,0x91);
              }
              break;
            case 5:
              plVar37 = *(longlong **)(psVar11 + 4);
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104135;
              uVar44 = func_0x();
              *(undefined4 *)(&stack0x00000044 + lVar10) = uVar44;
              break;
            case 6:
            case 7:
            case 9:
            case 10:
            case 0xb:
            case 0xe:
            case 0xf:
            case 0x19:
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104150;
              func_0x(&stack0x00000170 + lVar10,lVar20,&stack0x00000070 + lVar10);
              goto LAB_;
            case 8:
              uVar23 = *(uint *)(lVar20 + 0x40);
              *(undefined4 *)(&stack0x00000114 + lVar10) = 0;
              *(undefined **)(&stack0xffffffffffffffe0 + lVar10) = &stack0x00000114 + lVar10;
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104121;
              plVar37 = (longlong *)
                        func_0x(puVar1,lVar20,(uVar23 & 0x80000) >> 0x13,
                                        &stack0x00000044 + lVar10);
              break;
            case 0x10:
              uVar13 = *(undefined8 *)
                        (*(longlong *)(*(longlong *)(&stack0x00000060 + lVar10) + 8) + 0x160);
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10416b;
              uVar13 = func_0x(uVar13,0);
              uVar21 = 0;
              *(undefined4 *)(&stack0x00000030 + lVar10) = 0;
              *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
              iVar40 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000060 + lVar10) + 8) + 0x100)
              ;
              if (iVar40 == 2) {
                *(undefined4 *)(&stack0x00000118 + lVar10) = 0;
                *(undefined **)(&stack0xffffffffffffffe0 + lVar10) = &stack0x00000118 + lVar10;
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1041b6;
                puVar34 = (ulonglong *)func_0x(puVar1,uVar13,1,&stack0x00000030 + lVar10);
                if (puVar34 == (ulonglong *)0x0) {
                  puVar34 = *(ulonglong **)(*(longlong *)((longlong)&psStackX_20 + lVar10) + 8);
                }
                bVar8 = *(byte *)(lVar20 + 0x45);
                bVar22 = *(byte *)(lVar20 + 0x44);
                switch(*(undefined *)(lVar20 + 0x3e)) {
                case 0x30:
                  if (*(int *)(&stack0x00000030 + lVar10) == 0) {
                    *(undefined *)((longlong)&uStackX_8 + lVar10 + 8) = 0;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 1;
                  }
                  else {
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)puVar34;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 1;
                  }
                  break;
                case 0x34:
                  iVar40 = *(int *)(&stack0x00000030 + lVar10);
                  if (iVar40 == 0) {
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 8) = 0;
code_r0x00104329:
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 2;
                  }
                  else if (iVar40 == 1) {
                    *(ushort *)((longlong)&uStackX_8 + lVar10 + 8) = (*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)puVar34 ^ 0x80;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 2;
                  }
                  else {
                    if (iVar40 != 2) goto code_r0x00104329;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 9) = *(byte *)puVar34 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)((longlong)puVar34 + 1);
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 2;
                  }
                  break;
                case 0x38:
                case 0x7a:
                  iVar40 = *(int *)(&stack0x00000030 + lVar10);
                  if (iVar40 == 0) {
                    *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 8) = 0;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 4;
                  }
                  else if (iVar40 == 1) {
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 8) = (*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)puVar34 ^ 0x80;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 4;
                  }
                  else if (iVar40 == 2) {
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 8) = (*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 9) = *(byte *)puVar34 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)((longlong)puVar34 + 1);
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 4;
                  }
                  else if (iVar40 == 3) {
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 8) = (*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 10) = *(byte *)puVar34 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 9) = *(byte *)((longlong)puVar34 + 1);
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)((longlong)puVar34 + 2);
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 4;
                  }
                  else {
                    if (iVar40 != 4) goto code_r0x001045da;
                    uVar23 = *(uint *)puVar34;
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 8) =
                         uVar23 >> 0x18 | (uVar23 & 0xff0000) >> 8 | (uVar23 & 0xff00) << 8 |
                         uVar23 << 0x18;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0xb) = (byte)uVar23 ^ 0x80;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 4;
                  }
                  break;
                case 0x3a:
                  if (*(int *)(&stack0x00000030 + lVar10) == 4) {
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 8) = *(uint *)puVar34;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 4;
                  }
                  else {
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 8) = 0;
code_r0x001044ea:
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 10) = *(undefined2 *)puVar34;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 4;
                  }
                  break;
                case 0x3b:
                  *(undefined4 *)((longlong)&uStackX_8 + lVar10 + 8) = 0;
                  iVar40 = *(int *)(&stack0x00000030 + lVar10);
                  if (iVar40 == 1) {
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0xb) = *(byte *)puVar34;
code_r0x001045da:
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 4;
                  }
                  else {
                    if (iVar40 == 2) goto code_r0x001044ea;
                    if (iVar40 == 3) {
                      *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 9) = *(undefined2 *)puVar34;
                      *(byte *)((longlong)&uStackX_8 + lVar10 + 0xb) =
                           *(byte *)((longlong)puVar34 + 2);
                      *(undefined4 *)(&stack0x00000038 + lVar10) = 4;
                    }
                    else {
                      if (iVar40 != 4) goto code_r0x001045da;
                      *(uint *)((longlong)&uStackX_8 + lVar10 + 8) = *(uint *)puVar34;
                      *(undefined4 *)(&stack0x00000038 + lVar10) = 4;
                    }
                  }
                  break;
                case 0x3c:
                case 0x3d:
                case 0x7f:
                  switch(*(undefined4 *)(&stack0x00000030 + lVar10)) {
                  case 0:
                    *(undefined8 *)((longlong)&uStackX_8 + lVar10 + 8) = 0;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                    break;
                  case 1:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) =
                         (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)puVar34 ^ 0x80;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                    break;
                  case 2:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) =
                         (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 9) = *(byte *)puVar34 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)((longlong)puVar34 + 1);
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                    break;
                  case 3:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) =
                         (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 10) = *(byte *)puVar34 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 9) = *(byte *)((longlong)puVar34 + 1);
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 8) = *(byte *)((longlong)puVar34 + 2);
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                    break;
                  case 4:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) =
                         (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                    uVar23 = *(uint *)puVar34;
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 8) =
                         uVar23 >> 0x18 | (uVar23 & 0xff0000) >> 8 | (uVar23 & 0xff00) << 8 |
                         uVar23 << 0x18;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0xb) = *(byte *)puVar34 ^ 0x80;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                    break;
                  case 5:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) =
                         (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0xc) = *(byte *)puVar34 ^ 0x80;
                    uVar23 = *(uint *)((longlong)puVar34 + 1);
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 8) =
                         uVar23 >> 0x18 | (uVar23 & 0xff0000) >> 8 | (uVar23 & 0xff00) << 8 |
                         uVar23 << 0x18;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                    break;
                  case 6:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) =
                         (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0xd) = *(byte *)puVar34 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0xc) =
                         *(byte *)((longlong)puVar34 + 1);
                    uVar23 = *(uint *)((longlong)puVar34 + 2);
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 8) =
                         uVar23 >> 0x18 | (uVar23 & 0xff0000) >> 8 | (uVar23 & 0xff00) << 8 |
                         uVar23 << 0x18;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                    break;
                  case 7:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) =
                         (ulonglong)(*(byte *)puVar34 >> 7) - 1;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0xe) = *(byte *)puVar34 ^ 0x80;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0xd) =
                         *(byte *)((longlong)puVar34 + 1);
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0xc) =
                         *(byte *)((longlong)puVar34 + 2);
                    uVar23 = *(uint *)((longlong)puVar34 + 3);
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 8) =
                         uVar23 >> 0x18 | (uVar23 & 0xff0000) >> 8 | (uVar23 & 0xff00) << 8 |
                         uVar23 << 0x18;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                    break;
                  case 8:
                    uVar26 = *puVar34;
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) =
                         uVar26 >> 0x38 | (uVar26 & 0xff000000000000) >> 0x28 |
                         (uVar26 & 0xff0000000000) >> 0x18 | (uVar26 & 0xff00000000) >> 8 |
                         (uVar26 & 0xff000000) << 8 | (uVar26 & 0xff0000) << 0x18 |
                         (uVar26 & 0xff00) << 0x28 | uVar26 << 0x38;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0xf) = (byte)uVar26 ^ 0x80;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                    break;
                  default:
                    goto code_r0x001046b6;
                  }
                  break;
                case 0x3e:
                  *(undefined8 *)((longlong)&uStackX_8 + lVar10 + 8) = 0;
                  switch(*(undefined4 *)(&stack0x00000030 + lVar10)) {
                  case 1:
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0xf) = *(byte *)puVar34;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                    break;
                  case 2:
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 0xe) = *(undefined2 *)puVar34;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                    break;
                  case 3:
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 0xd) = *(undefined2 *)puVar34;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0xf) =
                         *(byte *)((longlong)puVar34 + 2);
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                    break;
                  case 4:
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 0xc) = *(uint *)puVar34;
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                    break;
                  case 5:
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 0xb) = *(uint *)puVar34;
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0xf) =
                         *(byte *)((longlong)puVar34 + 4);
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                    break;
                  case 6:
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 10) = *(uint *)puVar34;
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 0xe) =
                         *(undefined2 *)((longlong)puVar34 + 4);
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                    break;
                  case 7:
                    *(uint *)((longlong)&uStackX_8 + lVar10 + 9) = *(uint *)puVar34;
                    *(undefined2 *)((longlong)&uStackX_8 + lVar10 + 0xd) =
                         *(undefined2 *)((longlong)puVar34 + 4);
                    *(byte *)((longlong)&uStackX_8 + lVar10 + 0xf) =
                         *(byte *)((longlong)puVar34 + 6);
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                    break;
                  case 8:
                    *(ulonglong *)((longlong)&uStackX_8 + lVar10 + 8) = *puVar34;
                  default:
code_r0x001046b6:
                    *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                  }
                  break;
                case 0x6a:
                case 0x6c:
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x00000038 + lVar10;
                  *(longlong *)(&stack0xffffffffffffffe0 + lVar10) =
                       (longlong)&uStackX_8 + lVar10 + 8;
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1046dd;
                  cVar7 = (*pcRam00000000013e6340)
                                    (puVar34,*(undefined4 *)(&stack0x00000030 + lVar10),
                                     bVar22 & 0x3f);
                  if (cVar7 == '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1046f7;
                    (*_DAT_)(6,0x54,0x16,1);
                  }
                  break;
                case 0xad:
                case 0xaf:
                  (&stack0xffffffffffffffe0)[lVar10] = *(undefined *)(lVar20 + 0x3e);
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104518;
                  func_0x
                            (puVar34,*(undefined4 *)(&stack0x00000030 + lVar10),
                             (longlong)&uStackX_8 + lVar10 + 8,
                             *(undefined4 *)(&stack0x00000038 + lVar10));
                  break;
                case 0xbd:
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104550;
                  func_0x
                            (puVar34,*(undefined4 *)(&stack0x00000030 + lVar10),
                             (longlong)&uStackX_8 + lVar10 + 8,bVar8 & 0x3f);
                  *(undefined4 *)(&stack0x00000038 + lVar10) = 8;
                  break;
                case 0xe7:
                  *(undefined4 *)(&stack0xffffffffffffffe0 + lVar10) =
                       *(undefined4 *)(&stack0x00000038 + lVar10);
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x104718;
                  uVar44 = (*pcRam00000000013e6338)
                                     (&stack0x00000328 + lVar10,puVar34,
                                      *(undefined4 *)(&stack0x00000030 + lVar10),
                                      (longlong)&uStackX_8 + lVar10 + 8);
                  *(undefined4 *)(&stack0x00000038 + lVar10) = uVar44;
                  break;
                case 0xef:
                  *(undefined4 *)(&stack0xffffffffffffffe0 + lVar10) =
                       *(undefined4 *)(&stack0x00000038 + lVar10);
                  *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10453c;
                  (*pcRam00000000013e6348)
                            (&stack0x000002f0 + lVar10,puVar34,
                             *(undefined4 *)(&stack0x00000030 + lVar10),
                             (longlong)&uStackX_8 + lVar10 + 8);
                }
              }
              else if (iVar40 == 0) {
                *(undefined8 *)((longlong)&uStackX_8 + lVar10 + 8) = uRam0000000000000000;
              }
              lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
              if ((*(byte *)(*(longlong *)(lVar20 + 0x48) + 0x2a) & 0x10) != 0) {
                lVar12 = *(longlong *)(&stack0x00000090 + lVar10);
              }
              puVar41 = (undefined8 *)(*(longlong *)(lVar20 + 0x28) + lVar12);
              *puVar41 = *(undefined8 *)((longlong)&uStackX_8 + lVar10 + 8);
              uVar23 = *(uint *)(lVar20 + 0x40);
              if ((uVar23 >> 8 & 1) != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10476b;
                func_0x(&stack0x00000070 + lVar10,lVar20,
                                *(undefined4 *)(&stack0x00000038 + lVar10));
                uVar23 = *(uint *)(lVar20 + 0x40);
              }
              if ((uVar23 >> 10 & 1) != 0) {
                lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
                if ((*(byte *)(*(longlong *)(lVar20 + 0x48) + 0x2a) & 0x10) != 0) {
                  lVar12 = *(longlong *)(&stack0x00000090 + lVar10);
                }
                if (puVar41 == (undefined8 *)0x0) {
                  uVar21 = 3;
                }
                *(undefined *)(lVar12 + *(longlong *)(lVar20 + 0x30)) = uVar21;
              }
              goto LAB_;
            }
            uVar23 = *(uint *)(lVar20 + 0x40);
            if ((uVar23 >> 10 & 1) != 0) {
              lVar12 = *(longlong *)(&stack0x00000088 + lVar10);
              if ((*(byte *)(*(longlong *)(lVar20 + 0x48) + 0x2a) & 0x10) != 0) {
                lVar12 = *(longlong *)(&stack0x00000090 + lVar10);
              }
              uVar21 = 0;
              if (plVar37 == (longlong *)0x0) {
                uVar21 = 3;
              }
              *(undefined *)(lVar12 + *(longlong *)(lVar20 + 0x30)) = uVar21;
              uVar23 = *(uint *)(lVar20 + 0x40);
            }
            if ((uVar23 >> 9 & 1) != 0) {
              *(undefined4 *)(&stack0xffffffffffffffe0 + lVar10) =
                   *(undefined4 *)(&stack0x00000044 + lVar10);
              *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1040cf;
              func_0x();
            }
LAB_:
            uVar23 = (int)plVar38 + 1;
            plVar38 = (longlong *)(ulonglong)uVar23;
            lVar20 = lVar20 + 0x50;
            psVar11 = *(short **)((longlong)&psStackX_20 + lVar10);
            puVar27 = &stack0xffffffffffffffc0 + lVar10;
          } while (uVar23 < uVar36);
        }
      }
    }
LAB_:
    plVar37 = *(longlong **)(&stack0x000000f8 + lVar10);
    if (plVar37 != (longlong *)0x0) {
      pcVar5 = *(code **)(**(longlong **)(&stack0x00000180 + lVar10) + 8);
      *(undefined8 *)(puVar27 + -8) = 0x105c05;
      (*pcVar5)();
      goto LAB_;
    }
  }
  else {
    *(undefined8 *)(&stack0x00000190 + lVar10) = param_2[2];
    *(undefined **)(&stack0x00000198 + lVar10) = &stack0x00000170 + lVar10;
    *(longlong *)(&stack0x000001a8 + lVar10) = lVar14;
    lVar20 = *(longlong *)(lVar14 + 8);
    lVar12 = lVar20;
    if (*(longlong *)(lVar20 + 0x478) != 0) {
      lVar12 = *(longlong *)(lVar20 + 0x478);
    }
    if ((*(short *)(lVar12 + 0x440) == 0) && (*(short *)(lVar20 + 0xce) == 0)) {
      uVar36 = *(uint *)(&stack0x000001c4 + lVar10);
    }
    else {
      uVar36 = *(uint *)(&stack0x000001c4 + lVar10) | 1;
      *(uint *)(&stack0x000001c4 + lVar10) = uVar36;
    }
    lVar20 = *(longlong *)(&stack0x000001a8 + lVar10);
    if ((0x1f7c < *(uint *)(*(longlong *)(lVar20 + 8) + 0xb0)) &&
       ((*(byte *)(*(longlong *)(lVar20 + 8) + 0x106) & 4) == 0)) {
      uVar36 = uVar36 | 2;
      *(uint *)(&stack0x000001c4 + lVar10) = uVar36;
    }
    *(undefined4 *)(&stack0x000001b0 + lVar10) =
         *(undefined4 *)(*(longlong *)(lVar20 + 0x20) + 0x664);
    *(ulonglong *)(&stack0x000001b8 + lVar10) = (ulonglong)*(uint6 *)(lVar20 + 0x14) << 0x10;
    *(undefined2 *)(&stack0x000001c0 + lVar10) =
         *(undefined2 *)(*(longlong *)(lVar20 + 0x20) + 0x660);
    *(uint *)(&stack0x000001c4 + lVar10) = uVar36 | 4;
    *(undefined8 *)(&stack0x00000410 + lVar10) = 0;
    *(undefined8 *)(&stack0x00000418 + lVar10) = 0;
    *(undefined4 *)(&stack0x00000420 + lVar10) = 0;
    *(undefined8 *)(&stack0x00000428 + lVar10) = 0;
    *(undefined4 *)(&stack0x00000430 + lVar10) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1073e7;
    func_0x(&stack0x00000434 + lVar10,0,0x1f9e);
    if (plVar37 == (longlong *)0x0) {
      *(undefined8 *)(&stack0x00000178 + lVar10) = *(undefined8 *)((longlong)&psStackX_20 + lVar10);
      *(undefined8 *)(&stack0x00000180 + lVar10) = 0;
    }
    else {
      *(undefined8 *)(&stack0x00000178 + lVar10) = 0;
      *(longlong **)(&stack0x00000180 + lVar10) = plVar37;
    }
    lVar20 = *(longlong *)(&stack0x00000070 + lVar10);
    puVar27 = &stack0xffffffffffffffc0 + lVar10;
    plVar30 = plVar38;
    if ((*(byte *)(lVar20 + 0x38) & 8) != 0) {
      plVar30 = (longlong *)(&stack0x00000410 + lVar10);
      uVar25 = *(ushort *)(lVar20 + 0x62);
      *(uint *)(&stack0x00000410 + lVar10) = (uint)uVar25;
      *(undefined4 *)(&stack0x00000430 + lVar10) = 0x1f9e;
      *(undefined **)(&stack0x00000428 + lVar10) = &stack0x00000434 + lVar10;
      uVar31 = (ulonglong)(uint)uVar25 * 0x40;
      uVar26 = uVar31 + 0xf;
      if (uVar26 <= uVar31) {
        uVar26 = 0xffffffffffffff0;
      }
      uVar26 = uVar26 & 0xfffffffffffffff0;
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10746b;
      func_0x();
      lVar12 = -uVar26;
      puVar27 = &stack0xffffffffffffffc0 + lVar12 + lVar10;
      *(longlong *)(&stack0x00000418 + lVar10) = (longlong)&psStackX_20 + lVar12 + lVar10 + -0x20;
      *(undefined8 *)((longlong)&uStack_48 + lVar12 + lVar10) = 0x107481;
      func_0x((longlong)&psStackX_20 + lVar12 + lVar10 + -0x20,0);
    }
    *(undefined8 *)(puVar27 + 0x28) = 0;
    *(undefined **)(puVar27 + 0x20) = &stack0x00000140 + lVar10;
    *(undefined8 *)(puVar27 + -8) = 0x1074ac;
    uVar44 = func_0x
                       (&stack0x00000190 + lVar10,&stack0x00000070 + lVar10,plVar30,
                        &stack0x00000204 + lVar10);
    if (*(int *)(&stack0x00000140 + lVar10) == 2) {
      pcVar5 = *(code **)(*plVar37 + 0x10);
      *(undefined8 *)(puVar27 + -8) = 0x1074bf;
      uVar44 = (*pcVar5)(plVar37);
    }
    if ((*(byte *)(lVar20 + 0x38) & 8) != 0) {
      *(undefined **)(puVar27 + 0x28) = &stack0x00000070 + lVar10;
      *(undefined8 *)(puVar27 + 0x20) = 0;
      *(undefined8 *)(puVar27 + -8) = 0x1074e0;
      func_0x(uVar44,0,0,plVar30);
    }
    lVar20 = *(longlong *)(&stack0x00000418 + lVar10);
    if ((lVar20 != 0) && (uVar36 = *(uint *)(&stack0x00000410 + lVar10), uVar36 != 0)) {
      do {
        lVar12 = (longlong)plVar38 * 0x40;
        if ((*(byte *)(lVar20 + 0x18 + lVar12) & 4) != 0) {
          uVar13 = *(undefined8 *)(lVar20 + 0x20 + lVar12);
          *(undefined8 *)(puVar27 + -8) = 0x107519;
          (*_DAT_)(uVar13);
          pbVar33 = (byte *)(*(longlong *)(&stack0x00000418 + lVar10) + 0x18 + lVar12);
          *pbVar33 = *pbVar33 & 0xfb;
          lVar20 = *(longlong *)(&stack0x00000418 + lVar10);
          uVar36 = *(uint *)(&stack0x00000410 + lVar10);
        }
        uVar23 = (int)plVar38 + 1;
        plVar38 = (longlong *)(ulonglong)uVar23;
      } while (uVar23 < uVar36);
    }
LAB_:
    if (plVar37 != (longlong *)0x0) {
      pcVar5 = *(code **)(*plVar37 + 8);
      *(undefined8 *)(puVar27 + -8) = 0x1016ab;
      (*pcVar5)(plVar37);
    }
  }
  lVar20 = *(longlong *)(&stack0x00000290 + lVar10);
  if (**(char **)(lVar20 + 0x40) == '\x03') {
    lVar20 = 0;
  }
  else {
    puVar15 = (ulonglong *)(*(char **)(lVar20 + 0x40) + 4);
    puVar34 = *(ulonglong **)(&stack0x00000160 + lVar10);
    if (puVar34 == (ulonglong *)0x0) {
LAB_:
      *(undefined8 *)(puVar27 + -8) = 0x107546;
      puVar19 = (undefined4 *)(*_DAT_)();
      *puVar19 = 0x16;
      *(undefined8 *)(puVar27 + -8) = 0x107552;
      (*_DAT_)();
      puVar34 = *(ulonglong **)(&stack0x00000160 + lVar10);
    }
    else {
      if (puVar15 == (ulonglong *)0x0) {
        *puVar34 = 0;
        goto LAB_;
      }
      *puVar34 = *puVar15;
    }
    lVar12 = *(longlong *)(*(longlong *)(lVar20 + 0x28) + 0x70);
    if ((*(byte *)(lVar20 + 0x24) & 4) == 0) {
      uVar25 = *(ushort *)(lVar12 + 0x3c);
    }
    else {
      lVar12 = *(longlong *)(lVar12 + 0x48);
      if ((*(ushort *)(lVar12 + 0xc) & 0x800) == 0) {
        uVar25 = *(ushort *)(lVar12 + 2);
      }
      else {
        uVar25 = 0x12;
      }
    }
    if ((ulonglong)uVar25 < *puVar34) {
      *(undefined8 *)(puVar27 + -8) = 0x1075a5;
      (*_DAT_)(6,0x52,0x16,0x9c);
    }
    lVar20 = *(longlong *)(lVar20 + 0x40) + 0xc;
  }
  **(longlong **)(&stack0x00000298 + lVar10) = lVar20;
LAB_:
  uVar26 = *(ulonglong *)(&stack0x000023e0 + lVar10);
  *(undefined8 *)(puVar27 + -8) = 0x1075d0;
  func_0x(uVar26 ^ (ulonglong)puVar2);
  return;
code_r0x00102720:
  do {
    if ((uVar25 & 0x7ff) < (*puVar43 & 0x7ff)) {
      uVar25 = psVar11[0x15];
      lVar20 = *(longlong *)(psVar11 + 4);
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102747;
      func_0x((ulonglong)uVar25 + lVar20,0x1a);
      uVar25 = psVar11[0x16];
    }
    iVar40 = iVar40 + 1;
    puVar43 = puVar43 + 1;
  } while (iVar40 < (int)(uVar25 >> 0xb & 7));
  pbVar33 = *(byte **)(psVar11 + 4);
code_r0x00102773:
  if ((*pbVar33 & 0x40) == 0) {
    *(undefined4 *)(psVar11 + 0x13) = 0;
    lVar20 = *(longlong *)((longlong)&psStackX_20 + lVar10);
    uVar36 = *(uint *)(lVar20 + 4);
  }
  else {
    *(int *)(psVar11 + 0x13) = *(int *)(psVar11 + 2);
    *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + 0xe;
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10278d;
    uVar13 = func_0x(puVar1);
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10279c;
    func_0x(uVar13,&stack0x00000240 + lVar10);
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1027a8;
    iVar40 = func_0x(&stack0x00000240 + lVar10);
    *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar40;
    uVar36 = *(uint *)(psVar11 + 2);
    lVar20 = *(longlong *)((longlong)&psStackX_20 + lVar10);
  }
  if ((*(ulonglong *)(psVar11 + 0xf) != 0) &&
     (*(ulonglong *)(psVar11 + 0xf) < (ulonglong)uVar36 + *(longlong *)(psVar11 + 4))) {
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1027e7;
    cVar7 = func_0x(0x1e7abb0);
    if (cVar7 != '\0') {
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1027f0;
      lVar12 = func_0x();
      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10280a;
        cVar7 = func_0x(0x1e7abb0);
        if (cVar7 == '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102826;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10284c;
          (*_DAT_)(1,0x176a5bc,0x188a6a8,0x886);
        }
      }
    }
    uVar13 = *(undefined8 *)(psVar11 + 4);
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10285a;
    func_0x(uVar13);
    uVar36 = *(uint *)(lVar20 + 4);
  }
  if (0x3f3b < uVar36 - 1) {
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102873;
    cVar7 = func_0x(0x1e7abb0);
    if (cVar7 != '\0') {
      *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10287c;
      lVar20 = func_0x();
      if ((lVar20 != 0) && (*(char *)(lVar20 + 0x499) != '\0')) {
        *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102896;
        cVar7 = func_0x(0x1e7abb0);
        if (cVar7 == '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1028b2;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1028d8;
          (*_DAT_)(1,0x176a5bc,0x188a6a8,0x88b);
        }
      }
    }
    uVar13 = *(undefined8 *)(psVar11 + 4);
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1028e6;
    func_0x(uVar13);
  }
code_r0x001028e6:
  sVar28 = -*(short *)puVar35;
  if ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0) {
    *(undefined **)(&stack0xffffffffffffffe0 + lVar10) = &stack0x00000104 + lVar10;
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x102917;
    func_0x(puVar1,puVar35,0,&stack0x000001d0 + lVar10);
    if (*(int *)(&stack0x00000104 + lVar10) == 0) {
      puVar19 = *(undefined4 **)(puVar35 + 2);
      *(undefined4 *)(&stack0x00000028 + lVar10) = *puVar19;
      plVar37 = (longlong *)(puVar19 + 1);
      iVar40 = *(int *)((longlong)auStackX_18 + lVar10 + 4);
      goto code_r0x00102056;
    }
  }
  lVar20 = (longlong)sVar28;
  if ((uint)(ushort)psVar11[0xe] < (uint)(int)sVar28) {
    *(undefined4 *)(&stack0x00000028 + lVar10) = 0;
    plVar37 = *(longlong **)(psVar11 + 4);
    iVar40 = *(int *)((longlong)auStackX_18 + lVar10 + 4);
    goto code_r0x00102056;
  }
  lVar12 = *(longlong *)(psVar11 + 4);
  lVar14 = (ulonglong)*(uint *)(psVar11 + 10) + lVar12;
  if (sVar28 == 1) {
    uVar36 = *(uint *)(psVar11 + 0xc);
    uVar23 = *(ushort *)(lVar14 + lVar20 * 2) & 0x7fff;
code_r0x00102988:
    if ((uVar23 < uVar36) || (*(uint *)(psVar11 + 2) < uVar23)) goto code_r0x00102991;
  }
  else {
    uVar36 = *(ushort *)(lVar14 + -2 + lVar20 * 2) & 0x7fff;
    uVar23 = *(ushort *)(lVar14 + lVar20 * 2) & 0x7fff;
    lVar12 = *(longlong *)(*(longlong *)((longlong)&psStackX_20 + lVar10) + 8);
    if (*(uint *)(*(longlong *)((longlong)&psStackX_20 + lVar10) + 0x18) <= uVar36)
    goto code_r0x00102988;
code_r0x00102991:
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x10299e;
    func_0x(lVar12);
  }
  *(uint *)(&stack0x00000028 + lVar10) = uVar23 - uVar36;
  plVar37 = (longlong *)((ulonglong)uVar36 + *(longlong *)(psVar11 + 4));
  iVar40 = *(int *)((longlong)auStackX_18 + lVar10 + 4);
code_r0x00102056:
  uVar36 = puVar35[0x10];
  if ((uVar36 >> 10 & 1) != 0) {
    lVar20 = *(longlong *)(&stack0x00000088 + lVar10);
    if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) != 0) {
      lVar20 = *(longlong *)(&stack0x00000090 + lVar10);
    }
    uVar21 = 0;
    if (plVar37 == (longlong *)0x0) {
      uVar21 = 3;
    }
    *(undefined *)(lVar20 + *(longlong *)(puVar35 + 0xc)) = uVar21;
    uVar36 = puVar35[0x10];
  }
  if ((uVar36 >> 9 & 1) != 0) {
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar10) = *(undefined4 *)(&stack0x00000028 + lVar10);
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1020b0;
    func_0x(&stack0x00000070 + lVar10);
  }
LAB_:
  psVar16 = *(short **)((longlong)&psStackX_20 + lVar10);
code_r0x001020b4:
  uVar36 = iVar40 + 1;
  plVar38 = (longlong *)(ulonglong)uVar36;
  *(uint *)((longlong)auStackX_18 + lVar10 + 4) = uVar36;
  puVar35 = puVar35 + 0x14;
  *(uint **)(&stack0x00000050 + lVar10) = puVar35;
  lVar14 = *(longlong *)(&stack0x00000060 + lVar10);
  puVar27 = &stack0xffffffffffffffc0 + lVar10;
  if (*(uint *)(&stack0x00000058 + lVar10) <= uVar36) goto LAB_;
  goto LAB_;
}

