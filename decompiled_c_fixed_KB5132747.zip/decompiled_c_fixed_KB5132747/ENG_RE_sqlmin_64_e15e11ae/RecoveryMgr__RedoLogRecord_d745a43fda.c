
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined4 *param_2,undefined param_3,ulonglong param_4)

{
  byte bVar1;
  ushort *puVar2;
  undefined2 uVar3;
  char cVar4;
  short sVar5;
  ushort uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  longlong *plVar12;
  longlong lVar13;
  undefined8 *puVar14;
  undefined4 *puVar15;
  ushort *puVar16;
  ulonglong *puVar17;
  undefined8 *puVar18;
  longlong *plVar19;
  ulonglong uVar20;
  undefined8 uVar21;
  undefined4 *puVar22;
  uint uVar23;
  byte *pbVar24;
  longlong lVar25;
  longlong *plVar26;
  longlong *plVar27;
  ushort uVar28;
  uint *puVar29;
  longlong *plVar30;
  undefined *puVar31;
  byte bVar32;
  uint uVar33;
  undefined6 *puVar34;
  longlong unaff_GS_OFFSET;
  bool bVar35;
  undefined auStack_ef8 [32];
  undefined8 uStack_ed8;
  undefined8 uStack_ed0;
  undefined8 uStack_ec8;
  undefined8 uStack_ec0;
  undefined4 uStack_eb8;
  undefined uStack_eb0;
  undefined2 uStack_ea8;
  undefined4 uStack_ea4;
  undefined2 uStack_ea0;
  short sStack_e98;
  ushort uStack_e96;
  uint uStack_e94;
  byte *pbStack_e90;
  undefined8 uStack_e88;
  uint uStack_e80;
  ushort uStack_e7c;
  byte *pbStack_e7a;
  undefined2 uStack_e72;
  undefined2 uStack_e70;
  ushort uStack_e6e;
  ushort uStack_e6c;
  undefined2 uStack_e6a;
  undefined4 uStack_e68;
  short sStack_e60;
  ushort uStack_e5e;
  uint uStack_e5c;
  byte *pbStack_e58;
  undefined8 uStack_e50;
  uint uStack_e48;
  ushort uStack_e44;
  byte *pbStack_e42;
  undefined2 uStack_e3a;
  undefined2 uStack_e38;
  ushort uStack_e36;
  ushort uStack_e34;
  undefined2 uStack_e32;
  undefined4 uStack_e30;
  ulonglong uStack_e28;
  undefined uStack_e20;
  longlong *plStack_e18;
  undefined4 *puStack_e10;
  undefined4 *puStack_e08;
  undefined8 uStack_e00;
  uint uStack_df0;
  longlong *plStack_de8;
  char cStack_de0;
  byte bStack_ddf;
  uint uStack_ddc;
  undefined8 uStack_dd8;
  uint uStack_dd0;
  int iStack_dcc;
  uint uStack_dc8;
  uint uStack_dc4;
  uint uStack_dc0;
  uint uStack_dbc;
  undefined8 uStack_db8;
  undefined4 uStack_db0;
  undefined4 uStack_dac;
  undefined4 *puStack_da8;
  undefined4 uStack_d58;
  uint uStack_d54;
  undefined4 uStack_d48;
  undefined2 uStack_d44;
  uint uStack_d38;
  undefined2 uStack_d34;
  uint uStack_d30;
  uint uStack_d24;
  ushort uStack_d20;
  undefined4 uStack_d1c;
  undefined4 auStack_d18 [4];
  undefined8 uStack_d08;
  undefined8 uStack_d00;
  longlong lStack_ce8;
  undefined uStack_ce0;
  undefined4 uStack_cdc;
  undefined8 uStack_cd0;
  longlong *plStack_cb0;
  uint uStack_ca8;
  undefined2 uStack_ca4;
  uint uStack_ca2;
  undefined2 uStack_c9e;
  undefined8 uStack_c98;
  undefined2 uStack_c90;
  undefined8 uStack_c88;
  undefined2 uStack_c80;
  undefined8 uStack_c68;
  undefined2 uStack_c60;
  undefined8 uStack_c58;
  undefined2 uStack_c50;
  undefined8 uStack_c48;
  undefined2 uStack_c40;
  longlong *plStack_c30;
  longlong *plStack_c28;
  longlong *plStack_c20;
  longlong *plStack_c18;
  longlong *plStack_c10;
  undefined auStack_c08 [8];
  longlong *plStack_c00;
  uint uStack_bf4;
  undefined auStack_bf0 [8];
  longlong lStack_be8;
  undefined8 *****pppppuStack_be0;
  undefined8 *****pppppuStack_bd8;
  undefined4 uStack_bd0;
  undefined8 uStack_bb8;
  longlong *plStack_bb0;
  undefined4 auStack_ba8 [2];
  undefined8 uStack_ba0;
  undefined8 uStack_b98;
  undefined8 uStack_b90;
  undefined8 uStack_b88;
  undefined4 auStack_b80 [2];
  undefined8 uStack_b78;
  undefined8 uStack_b70;
  undefined8 uStack_b68;
  undefined8 uStack_b60;
  undefined8 uStack_ae8;
  undefined6 *puStack_ae0;
  undefined8 uStack_ad8;
  longlong lStack_ad0;
  undefined4 *puStack_ac8;
  uint *puStack_ac0;
  longlong lStack_ab8;
  longlong lStack_ab0;
  uint *puStack_aa8;
  undefined4 *puStack_aa0;
  undefined8 uStack_a98;
  longlong lStack_a90;
  undefined auStack_a58 [48];
  undefined auStack_a28 [8];
  undefined2 uStack_a20;
  undefined2 uStack_a1e;
  undefined4 uStack_a18;
  uint **ppuStack_a10;
  undefined *puStack_a08;
  undefined8 uStack_a00;
  uint *puStack_9f8;
  undefined4 uStack_9f0;
  undefined2 uStack_9ec;
  undefined2 uStack_9ea;
  longlong lStack_9e8;
  uint uStack_9e0;
  undefined2 uStack_9dc;
  undefined2 uStack_9da;
  undefined auStack_9d8 [512];
  undefined4 uStack_7d8;
  undefined4 uStack_7d4;
  undefined8 uStack_7d0;
  uint uStack_7c8;
  undefined8 uStack_7c4;
  uint uStack_7bc;
  uint uStack_7b8;
  undefined auStack_7a8 [8];
  undefined4 uStack_7a0;
  undefined4 uStack_798;
  uint **ppuStack_790;
  undefined *puStack_788;
  undefined8 uStack_780;
  uint *puStack_778;
  undefined4 uStack_770;
  undefined4 uStack_76c;
  longlong *plStack_768;
  uint uStack_760;
  undefined4 uStack_75c;
  undefined auStack_758 [512];
  undefined8 uStack_558;
  undefined8 uStack_550;
  uint uStack_548;
  undefined8 uStack_544;
  uint uStack_53c;
  uint uStack_538;
  undefined auStack_528 [80];
  undefined8 uStack_4d8;
  undefined2 uStack_4d0;
  undefined8 uStack_4c8;
  undefined2 uStack_4c0;
  undefined4 uStack_4bc;
  undefined8 uStack_4b8;
  undefined2 uStack_4b0;
  undefined4 uStack_4ac;
  undefined auStack_4a8 [16];
  undefined auStack_498 [16];
  undefined4 uStack_488;
  undefined4 uStack_484;
  undefined4 uStack_480;
  undefined4 uStack_47c;
  undefined4 uStack_478;
  uint uStack_474;
  undefined4 uStack_470;
  undefined4 uStack_46c;
  undefined4 uStack_468;
  undefined4 uStack_464;
  undefined4 uStack_460;
  undefined4 uStack_45c;
  undefined auStack_458 [96];
  longlong alStack_3f8 [12];
  longlong alStack_398 [12];
  longlong alStack_338 [12];
  undefined auStack_2d8 [96];
  undefined auStack_278 [112];
  undefined auStack_208 [112];
  undefined auStack_198 [112];
  undefined auStack_128 [112];
  undefined auStack_b8 [112];
  ulonglong uStack_48;
  
  uStack_ae8 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_ef8;
  uStack_ea8 = CONCAT11(uStack_ea8._1_1_,param_3);
  plVar30 = (longlong *)0x0;
  uVar8 = 0;
  uVar10 = 0;
  iStack_dcc = 0;
  plStack_e18 = (longlong *)0x0;
  plVar12 = plVar30;
  uStack_e28 = param_4;
  plStack_de8 = param_1;
  uStack_dd8 = param_1;
  uStack_db8 = param_2;
  puStack_da8 = param_2;
  plStack_cb0 = param_1;
  if (((DAT_ & 0x10) != 0) ||
     (((lVar25 = *(longlong *)
                  ((ulonglong)*_DAT_ +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
       lVar25 != 0 && (**(longlong **)(lVar25 + 0x38) != 0)) &&
      (iVar7 = (*_DAT_)(), iVar7 != 0)))) {
    while (((DAT_ & 0x10) != 0 ||
           (((lVar25 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
             param_4 = uStack_e28, lVar25 != 0 && (**(longlong **)(lVar25 + 0x38) != 0)) &&
            (iVar7 = (*_DAT_)(), param_4 = uStack_e28, iVar7 != 0))))) {
      iVar7 = (int)plVar12;
      if (iVar7 == (iVar7 / 0xc) * 0xc) {
        func_0x(0xfb4c60,0xfb4c20,*(undefined4 *)(*(longlong *)(*param_1 + 0x6b0) + 0x3a0),
                        *(longlong *)(*param_1 + 0x6b0) + 0x3a8);
      }
      auStack_b80[0] = 0x400060;
      uStack_b78 = 0;
      uStack_b68 = 0;
      uStack_b70 = 0;
      uStack_b60 = 0;
      iVar11 = func_0x(5000,auStack_b80);
      plVar12 = (longlong *)(ulonglong)(iVar7 + 1);
      if (iVar11 == 2) {
        func_0x(0x86);
      }
    }
  }
  if ((((*(uint *)((longlong)param_1 + 0x24) >> 7 & 1) != 0) &&
      (bVar32 = *(byte *)((longlong)param_2 + 0x16), 0x7e < bVar32)) &&
     ((bVar32 != 0x99 && (bVar32 != 0x86)))) {
    uStack_ed8 = 0;
    (*_DAT_)(1,0x10ec380,0x10a3eb0,0x3081);
  }
  if ((_DAT_ & 0x20000000) != 0) {
    uStack_7a0 = 0x20000;
    uStack_798 = 0;
    ppuStack_790 = &puStack_778;
    puStack_788 = auStack_758;
    uStack_558 = 0;
    uStack_780 = 0;
    uStack_550 = 0;
    puStack_778 = &uStack_548;
    uStack_770 = 0x1c;
    uStack_76c = 1;
    uStack_75c = 4;
    uStack_548 = (uint)*(ushort *)(*(longlong *)(*param_1 + 0x6b0) + 0x28);
    uStack_544 = CONCAT44(*(undefined4 *)((longlong)param_1 + 0x5674),
                          *(undefined4 *)(param_1 + 0xacf));
    uStack_53c = (uint)*(ushort *)((longlong)param_1 + 0x567c);
    bVar32 = *(byte *)((longlong)param_2 + 0x16);
    uStack_538 = (uint)bVar32;
    pbVar24 = (byte *)0xd5db20;
    plVar12 = plVar30;
    do {
      uStack_760 = uVar10;
      if (*pbVar24 == bVar32) {
        plStack_768 = *(longlong **)(pbVar24 + 8);
        if (plStack_768 != (longlong *)0x0) {
          lVar25 = -1;
          do {
            lVar25 = lVar25 + 1;
          } while (*(short *)((longlong)plStack_768 + lVar25 * 2) != 0);
          uStack_760 = (int)lVar25 * 2;
        }
        break;
      }
      plStack_768 = plVar30;
      if (bVar32 < *pbVar24) break;
      plVar12 = (longlong *)((longlong)plVar12 + 1);
      pbVar24 = pbVar24 + 0x10;
    } while (plVar12 < (longlong *)0x57);
    func_0x(auStack_7a8);
  }
  pbVar24 = (byte *)0xd5db20;
  if (((((char)uStack_ea8 == '\0') && (param_4 != 0)) && (lVar25 = param_1[0x108a], lVar25 != 0)) &&
     ((*(byte *)(lVar25 + 0x210) & 1) != 0)) {
    plVar12 = (longlong *)(lVar25 + 0x200);
    if ((*(short *)((longlong)param_1 + 0x567c) == 1) || (*plVar12 == 0)) {
      lVar13 = func_0x(*(undefined8 *)(lVar25 + 0x1c8),uStack_e28);
      *plVar12 = lVar13;
      *(undefined *)(lVar25 + 0x208) = 0;
      if (lVar13 == 0) {
        func_0x(0xfac350,*(undefined4 *)((longlong)param_1 + 0x5674),
                        *(undefined4 *)(param_1 + 0xacf),*(undefined2 *)((longlong)param_1 + 0x567c)
                       );
        func_0x(param_1);
        *(undefined *)(*param_1 + 0x65f9) = 0;
        goto LAB_;
      }
    }
    func_0x(plVar12);
  }
LAB_:
  plVar12 = plVar30;
  if (((*(byte *)((longlong)param_2 + 0xe) & 2) == 0) ||
     (plVar12 = (longlong *)0x0, (*(uint *)((longlong)param_1 + 0x24) >> 7 & 1) != 0)) {
LAB_:
    plVar26 = plVar30;
    if (*(char *)(param_1 + 0xbfb) != '\0') goto LAB_;
    plVar27 = (longlong *)param_1[0xadc];
    if (plVar27 != (longlong *)0x0) goto LAB_;
  }
  else {
    uStack_d48 = param_2[4];
    uStack_d44 = *(undefined2 *)(param_2 + 5);
    plVar12 = (longlong *)func_0x(param_1 + 0xb74);
    plStack_e18 = plVar12;
    if ((plVar12 == (longlong *)0x0) ||
       (((*(int *)((longlong)plVar12 + 0x3c) - 10U & 0xfffffffd) == 0 ||
        ((*(byte *)(*param_1 + 0x1cd0) & 0x40) != 0)))) goto LAB_;
    plVar26 = (longlong *)plVar12[0x10];
    if (((((char)uStack_ea8 == '\0') || (param_1[0x108a] == 0)) ||
        ((*(uint *)((longlong)param_1 + 0x24) >> 7 & 1) != 0)) &&
       ((iVar7 = func_0x(), iVar7 != 0 &&
        ((*(uint *)((longlong)param_1 + 0x24) >> 7 & 1) == 0)))) {
      func_0x(auStack_528,param_2);
      if ((*(char *)(param_1 + 0x108e) != '\0') &&
         (cVar4 = func_0x(param_1,param_2 + 4), cVar4 == '\0')) {
        *(undefined4 *)((longlong)plVar12 + 0x11c) = 1;
      }
      uStack_bb8 = 0xf1b510;
      plVar27 = plVar30;
      if (*(int *)(plVar12 + 0xb) != 3) {
        plVar27 = (longlong *)(ulonglong)(*(int *)((longlong)plVar12 + 0x11c) != 0);
      }
      plStack_bb0 = plVar26;
      func_0x(auStack_528,*(undefined2 *)(plVar26[6] + 0x6b8),&uStack_bb8,plVar27);
    }
    if (*(int *)((longlong)plVar12 + 0x11c) == 0) {
      func_0x(plVar26,param_2,(longlong)param_1 + 0x5674);
    }
    plStack_e18 = plVar12;
    if ((((*(char *)(*param_1 + 0x1cde) != '\0') &&
         (cVar4 = func_0x(param_2), cVar4 != '\0')) &&
        ((plStack_e18 = plVar12, (*(ushort *)((longlong)param_2 + 0xe) & 0x100) != 0 &&
         ((*(uint *)((longlong)param_1 + 0x24) >> 7 & 1) == 0)))) &&
       ((param_1[0x108c] != 0 || ((char)uStack_ea8 == '\0')))) {
      func_0x(plVar26);
      lVar25 = *(longlong *)param_1[0x108c];
      if ((*(char *)(lVar25 + 0x16) == -0x21) ||
         (plStack_e18 = plVar12, *(char *)(lVar25 + 0x16) == -0x20)) {
        if ((*(byte *)(lVar25 + 0xe) & 1) == 0) {
          lVar25 = plVar26[0x488];
          plStack_e18 = plVar12;
          while (lVar25 != 0) {
            lVar25 = *(longlong *)(lVar25 + 8);
            (*_DAT_)(plVar26[0x488],0x10);
            plVar26[0x488] = lVar25;
            param_2 = puStack_da8;
          }
          plVar26[0x489] = 0;
          uVar21 = (**(code **)(**(longlong **)(plVar26[6] + 0x6d0) + 0x78))();
          uStack_ed8 = CONCAT71(uStack_ed8._1_7_,5);
          puVar14 = (undefined8 *)(*_DAT_)(0x10,uVar21,0xfc4b70,0x20c5);
          *puVar14 = 0;
          puVar14[1] = plVar26[0x48a];
          plVar26[0x48a] = (longlong)puVar14;
        }
        else {
          plVar27 = (longlong *)plVar26[0x48a];
          plVar26[0x48a] = plVar27[1];
          *plVar27 = lVar25;
          plVar27[1] = 0;
          if (plVar26[0x488] == 0) {
            plVar26[0x488] = (longlong)plVar27;
            plVar26[0x489] = (longlong)plVar27;
            plStack_e18 = plVar12;
          }
          else {
            *(longlong **)(plVar26[0x489] + 8) = plVar27;
            plVar26[0x489] = (longlong)plVar27;
            plStack_e18 = plVar12;
          }
        }
      }
      param_1[0x108c] = 0;
    }
    if ((*(byte *)((longlong)param_2 + 0xe) & 1) != 0) {
      if (1 < (ulonglong)param_1[0xb3c]) {
        param_1[0xb3c] = param_1[0xb3c] - 2;
      }
      if ((((DAT_ == '\0') && ((DAT_ & 8) == 0)) &&
          ((bool)(*(byte *)((longlong)param_2 + 0xf) & 1) !=
           ((*(uint *)(plVar12 + 7) & 0x240) == 0x40))) &&
         ((*(char *)((longlong)param_2 + 0x16) != -0xc &&
          (*(char *)((longlong)param_2 + 0x16) != -0x73)))) {
        uStack_ed8 = 0;
        (*_DAT_)(1,0x10ec290,0x10a3eb0,0x3137);
      }
    }
    if ((*(char *)(param_1 + 0xbfb) == '\0') &&
       (plVar27 = (longlong *)param_1[0xadc], plVar27 != (longlong *)0x0)) {
LAB_:
      (**(code **)(*plVar27 + 0x40))();
    }
    if (*(char *)(param_1 + 0xbfb) != '\0') {
LAB_:
      if ((plVar12 != (longlong *)0x0) && (lVar25 = plVar12[0x10], lVar25 != 0)) {
        *(undefined8 *)(lVar25 + 0x221c) = *(undefined8 *)((longlong)plVar12 + 0x4c);
        *(undefined2 *)(lVar25 + 0x2224) = *(undefined2 *)((longlong)plVar12 + 0x54);
      }
    }
  }
  bVar32 = *(byte *)((longlong)param_2 + 0x16);
  if (0x7e < bVar32) {
    func_0x(param_1,param_2,(char)uStack_ea8,plVar12);
    goto LAB_;
  }
  puStack_e10 = param_2;
  puStack_e08 = param_2;
  iVar7 = func_0x(*param_1);
  if (iVar7 == 0) {
    if (*(char *)((longlong)param_2 + 0x17) == '\v') {
      if (bVar32 == 4) {
        bVar35 = *(short *)((longlong)param_2 + 0x1e) == 0;
LAB_:
        if ((bVar35) && ((*(byte *)((longlong)param_2 + 0xe) & 1) == 0)) {
          func_0x(param_1,param_2,(longlong)param_1 + 0x5674);
        }
      }
    }
    else if ((*(char *)((longlong)param_2 + 0x17) == '\b') && (bVar32 == 7)) {
      bVar35 = *(short *)((longlong)param_2 + 0x1e) == 1;
      goto LAB_;
    }
  }
  puVar34 = (undefined6 *)(param_2 + 6);
  uStack_d38 = *(uint *)puVar34;
  uStack_d34 = *(undefined2 *)(param_2 + 7);
  uStack_e28 = func_0x(*(undefined8 *)
                                (*(longlong *)param_1[0xbf0] +
                                ((ulonglong)uStack_d38 %
                                (ulonglong)*(uint *)((longlong *)param_1[0xbf0] + 1)) * 8),
                               &uStack_d38);
  if ((_DAT_ != 0) &&
     (((uStack_e00 = *(undefined8 *)(*param_1 + 0x6a20), *(short *)(*param_1 + 0x6a28) != 0 ||
       ((uint)uStack_e00 != 0)) || ((int)((ulonglong)uStack_e00 >> 0x20) != 0)))) {
    bVar35 = false;
    plVar27 = plVar30;
    while( true ) {
      param_2 = puStack_da8;
      lVar25 = *param_1;
      uStack_e00 = *(undefined8 *)(lVar25 + 0x6a20);
      if (*(short *)(lVar25 + 0x6a28) != *(short *)((longlong)param_1 + 0x567c)) break;
      if (((uint)uStack_e00 != *(int *)((longlong)param_1 + 0x5674)) ||
         ((int)((ulonglong)uStack_e00 >> 0x20) != *(int *)(param_1 + 0xacf))) break;
      bVar35 = true;
      iVar7 = (int)plVar27;
      if (iVar7 == (iVar7 / 0xc) * 0xc) {
        uStack_ec8 = (longlong *)
                     CONCAT44(uStack_ec8._4_4_,(uint)*(ushort *)((longlong)param_1 + 0x567c));
        uStack_ed0 = (undefined8 *)CONCAT44(uStack_ed0._4_4_,*(undefined4 *)(param_1 + 0xacf));
        uStack_ed8 = CONCAT44(uStack_ed8._4_4_,*(int *)((longlong)param_1 + 0x5674));
        func_0x(0xfb4cf0,0xfb4c20,*(undefined4 *)(*(longlong *)(lVar25 + 0x6b0) + 0x3a0),
                        *(longlong *)(lVar25 + 0x6b0) + 0x3a8);
      }
      plVar27 = (longlong *)(ulonglong)(iVar7 + 1);
      auStack_ba8[0] = 0x400060;
      uStack_ba0 = 0;
      uStack_b90 = 0;
      uStack_b98 = 0;
      uStack_b88 = 0;
      iVar7 = func_0x(5000,auStack_ba8);
      if (iVar7 == 2) {
        func_0x(0x86);
      }
      func_0x(*param_1);
    }
    puVar34 = (undefined6 *)(puStack_da8 + 6);
    if (bVar35) {
      uStack_ec8 = (longlong *)
                   CONCAT44(uStack_ec8._4_4_,(uint)*(ushort *)((longlong)param_1 + 0x567c));
      uStack_ed0 = (undefined8 *)CONCAT44(uStack_ed0._4_4_,*(undefined4 *)(param_1 + 0xacf));
      uStack_ed8 = CONCAT44(uStack_ed8._4_4_,*(undefined4 *)((longlong)param_1 + 0x5674));
      func_0x(0xfb4d80,0xfb4c20,*(undefined4 *)(*(longlong *)(lVar25 + 0x6b0) + 0x3a0),
                      *(longlong *)(lVar25 + 0x6b0) + 0x3a8);
      goto LAB_;
    }
  }
  uVar20 = uStack_e28;
  if (uStack_e28 == 0) goto LAB_;
  iVar7 = func_0x(param_1,param_2);
  if (iVar7 == 0) {
LAB_:
    puVar22 = puStack_e10;
    if (*(char *)((longlong)param_2 + 0x16) != '\x10') goto LAB_;
  }
  else {
    uVar9 = *(uint *)(uVar20 + 0x30);
    do {
      uVar23 = uVar9 & 0xfffffffe;
      uStack_e00 = *(undefined8 *)(uVar20 + 0x24);
      LOCK();
      UNLOCK();
      uVar9 = *(uint *)(uVar20 + 0x30);
    } while (uVar23 != uVar9);
    if (((uint)uStack_e00 <= *(uint *)((longlong)param_1 + 0x5674)) &&
       ((*(uint *)((longlong)param_1 + 0x5674) != (uint)uStack_e00 ||
        ((uVar9 = (uint)((ulonglong)uStack_e00 >> 0x20), uVar9 <= *(uint *)(param_1 + 0xacf) &&
         ((*(uint *)(param_1 + 0xacf) != uVar9 ||
          (*(ushort *)(uVar20 + 0x2c) <= *(ushort *)((longlong)param_1 + 0x567c))))))))) {
LAB_:
      puStack_e10 = puStack_e08;
      goto LAB_;
    }
    if (((*(byte *)(*(longlong *)(*param_1 + 0x6b0) + 0x3c) & 1) == 0) ||
       ((*(longlong *)(*(longlong *)(*param_1 + 0x6b0) + 0x280) != 0 ||
        (*(char *)(param_1 + 0xbfb) == '\0')))) {
LAB_:
      if (((DAT_ & 8) != 0) ||
         (((lVar25 = *(longlong *)
                      ((ulonglong)*_DAT_ +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
           lVar25 != 0 && (lVar25 = **(longlong **)(lVar25 + 0x38), lVar25 != 0)) &&
          (iVar7 = (*_DAT_)(lVar25,0xd4b), uVar20 = uStack_e28, iVar7 != 0)))) {
        uStack_dc0 = 100;
        func_0x((longlong)param_1 + 0x5674,&uStack_dc0,auStack_b8);
        func_0x((longlong)param_1 + 0x5674,auStack_2d8,&plStack_cb0);
        uStack_eb8 = *(uint *)puVar34;
        bVar32 = *(byte *)((longlong)param_2 + 0x16);
        plVar12 = plVar30;
        do {
          bVar1 = *pbVar24;
          if (bVar1 == bVar32) {
            uStack_ec8 = *(longlong **)(pbVar24 + 8);
            break;
          }
          uStack_ec8 = plVar30;
          if (bVar32 <= bVar1 && bVar1 != bVar32) break;
          plVar12 = (longlong *)((longlong)plVar12 + 1);
          pbVar24 = pbVar24 + 0x10;
        } while (plVar12 < (longlong *)0x57);
        uStack_ec0 = CONCAT44(uStack_ec0._4_4_,(uint)*(ushort *)(param_2 + 7));
        uStack_ed0 = (undefined8 *)CONCAT44(uStack_ed0._4_4_,param_2[4]);
        uStack_ed8 = CONCAT44(uStack_ed8._4_4_,(uint)*(ushort *)(param_2 + 5));
        func_0x(0xfb4e00,uStack_dc0 >> 1,auStack_b8,auStack_2d8);
        uVar20 = uStack_e28;
      }
      if ((*(char *)(param_1 + 0xbfb) == '\0') && ((*(byte *)((longlong)param_2 + 0xe) & 1) == 0)) {
        if (uVar20 != 0) goto LAB_;
        if ((plVar26 != (longlong *)0x0) &&
           (cVar4 = (**(code **)(*plVar26 + 0x88))(plVar26), cVar4 != '\0')) {
          plVar12 = _DAT_;
          if (*_DAT_ != 0) {
            (*_DAT_)(&plStack_c10);
            plVar12 = plStack_c10;
          }
          uStack_dd8 = (longlong *)CONCAT26(uStack_dd8._6_2_,*puVar34);
          iVar7 = func_0x(_DAT_,*param_1,&uStack_dd8,0);
          plVar26 = _DAT_;
          if (*_DAT_ != 0) {
            (*_DAT_)(&plStack_c00);
            plVar26 = plStack_c00;
          }
          plVar27 = plVar30;
          if ((plVar26 < plVar12) ||
             (plVar27 = (longlong *)((longlong)plVar26 - (longlong)plVar12),
             plVar27 != (longlong *)0xffffffffffffffff)) {
            if (*_DAT_ == 0) {
              uVar20 = (ulonglong)plVar27 / 10000;
            }
            else {
              uVar20 = (ulonglong)((longlong)plVar27 * 1000) / *_DAT_;
            }
          }
          else {
            uVar20 = 0xffffffffffffffff;
          }
          param_1[0xb5b] = param_1[0xb5b] + 1;
          if (iVar7 == 0) {
            param_1[0xb5c] = param_1[0xb5c] + 1;
          }
          if (uVar20 != 0) {
            param_1[0xb5e] = param_1[0xb5e] + 1;
          }
          param_1[0xb5d] = param_1[0xb5d] + (longlong)plVar27;
        }
LAB_:
        uStack_4c8 = 0;
        uStack_4c0 = 0;
        uStack_4bc = 0;
        puVar14 = &uStack_4c8;
      }
      else {
        if (uVar20 == 0) goto LAB_;
LAB_:
        uStack_4b8 = *(undefined8 *)(uVar20 + 0x24);
        uStack_4b0 = *(undefined2 *)(uVar20 + 0x2c);
        uStack_4ac = *(undefined4 *)(uVar20 + 0x30);
        puVar14 = &uStack_4b8;
      }
      uVar10 = *(uint *)((longlong)puVar14 + 0xc);
      uStack_c68 = *puVar14;
      uStack_c60 = *(undefined2 *)(puVar14 + 1);
      do {
        uVar8 = uVar10 & 0xfffffffe;
        LOCK();
        UNLOCK();
        uVar10 = *(uint *)((longlong)puVar14 + 0xc);
      } while (uVar8 != uVar10);
      uStack_c58 = *(undefined8 *)((longlong)param_1 + 0x5674);
      uStack_c50 = *(undefined2 *)((longlong)param_1 + 0x567c);
      uStack_eb0 = 0;
      uStack_eb8 = CONCAT31(uStack_eb8._1_3_,1);
      uStack_ec0 = uStack_ec0 & 0xffffffffffffff00;
      uStack_ec8 = (longlong *)((ulonglong)uStack_ec8 & 0xffffffffffffff00);
      uStack_ed0 = (undefined8 *)((ulonglong)uStack_ed0 & 0xffffffffffffff00);
      uStack_ed8 = CONCAT71(uStack_ed8._1_7_,1);
      func_0x(param_1,param_2,&uStack_c58,&uStack_c68);
      lVar25 = *(longlong *)(*param_1 + 0x6b0);
      if ((((*(byte *)(lVar25 + 0x3c) & 1) != 0) && (*(longlong *)(lVar25 + 0x280) == 0)) &&
         (lVar25 = func_0x
                             (*(undefined8 *)(*param_1 + 0x6a0),*(undefined2 *)(param_2 + 7),0),
         (*(byte *)(lVar25 + 100) & 0x40) == 0)) {
        (**(code **)(**(longlong **)(*param_1 + 0x6c8) + 0x170))
                  (*(longlong **)(*param_1 + 0x6c8),auStack_4a8);
        if (*(char *)((longlong)param_2 + 0x16) == '\x10') {
          (*_DAT_)();
        }
        else {
          (*_DAT_)(lVar25,(longlong)param_1 + 0x5674,auStack_4a8,*(uint *)puVar34);
        }
      }
      if (uStack_e28 != 0) {
        plVar12 = (longlong *)param_1[0xbf0];
        if (plVar12 != (longlong *)0x0) {
          plVar30 = *(longlong **)
                     (*plVar12 +
                     ((ulonglong)*(uint *)(uStack_e28 + 0x10) % (ulonglong)*(uint *)(plVar12 + 1)) *
                     8);
        }
        uVar10 = *(uint *)(uStack_e28 + 0x30);
        do {
          uVar8 = uVar10 & 0xfffffffe;
          uStack_c48 = *(undefined8 *)(uStack_e28 + 0x24);
          uStack_c40 = *(undefined2 *)(uStack_e28 + 0x2c);
          LOCK();
          UNLOCK();
          uVar10 = *(uint *)(uStack_e28 + 0x30);
        } while (uVar8 != uVar10);
        func_0x(uStack_e28,&uStack_c48,plVar30);
      }
      goto LAB_;
    }
    if ((*(uint *)puVar34 == 0) ||
       ((*(uint *)puVar34 == 9 && (*(short *)((longlong)puVar34 + 4) == 1)))) goto LAB_;
    if (*(char *)((longlong)param_2 + 0x16) != '\x13') goto LAB_;
    puStack_e10 = puStack_e08;
LAB_:
    puVar22 = puStack_e10;
    if (((*(byte *)(*param_1 + 0x1cd0) & 1) != 0) || (*(int *)(*param_1 + 0x674) == 5)) {
      uStack_ed8 = 0;
      (*_DAT_)(1,0x10ec0b0,0x10a3eb0,0x3215);
      uVar20 = uStack_e28;
    }
  }
  uVar23 = 0;
  uVar9 = uVar10;
  if ((*(int *)(param_1 + 0xbfe) != 0) &&
     ((plVar12 == (longlong *)0x0 || (uVar9 = uVar23, *(int *)(plVar12 + 0xb) != 3)))) {
    uVar9 = 1;
  }
  *(uint *)((longlong)param_1 + 0x5ff4) = uVar9;
  uVar9 = *(uint *)(uVar20 + 0x38);
  if (*(int *)(uVar20 + 0x48) != 1) {
    uVar9 = uVar9 & 0xffff;
  }
  if ((uVar9 != 0) && (iVar7 = func_0x(param_1,(uint *)(uVar20 + 0x38),plVar12), iVar7 != 0)
     ) {
    if (((DAT_ & 8) != 0) ||
       (((lVar25 = *(longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
         lVar25 != 0 && (lVar25 = **(longlong **)(lVar25 + 0x38), lVar25 != 0)) &&
        (iVar7 = (*_DAT_)(lVar25,0xd4b), iVar7 != 0)))) {
      uStack_dd0 = 100;
      func_0x((longlong)param_1 + 0x5674,&uStack_dd0,auStack_278);
      func_0x((longlong)param_1 + 0x5674,auStack_458,auStack_bf0);
      uStack_eb8 = *(uint *)puVar34;
      bVar32 = *(byte *)((longlong)param_2 + 0x16);
      plVar12 = plVar30;
      do {
        bVar1 = *pbVar24;
        if (bVar1 == bVar32) {
          plVar30 = *(longlong **)(pbVar24 + 8);
          break;
        }
        if (bVar32 <= bVar1 && bVar1 != bVar32) break;
        plVar12 = (longlong *)((longlong)plVar12 + 1);
        pbVar24 = pbVar24 + 0x10;
      } while (plVar12 < (longlong *)0x57);
      uStack_ec0 = CONCAT44(uStack_ec0._4_4_,(uint)*(ushort *)(param_2 + 7));
      uStack_ed0 = (undefined8 *)CONCAT44(uStack_ed0._4_4_,param_2[4]);
      uStack_ed8 = CONCAT44(uStack_ed8._4_4_,(uint)*(ushort *)(param_2 + 5));
      uStack_ec8 = plVar30;
      func_0x(0xfb4ec0,uStack_dd0 >> 1,auStack_278,auStack_458);
    }
    uVar10 = *(uint *)(uStack_e28 + 0x30);
    do {
      uVar8 = uVar10 & 0xfffffffe;
      uStack_c98 = *(undefined8 *)(uStack_e28 + 0x24);
      uStack_c90 = *(undefined2 *)(uStack_e28 + 0x2c);
      LOCK();
      UNLOCK();
      uVar10 = *(uint *)(uStack_e28 + 0x30);
    } while (uVar8 != uVar10);
    uStack_c88 = *(undefined8 *)((longlong)param_1 + 0x5674);
    uStack_c80 = *(undefined2 *)((longlong)param_1 + 0x567c);
    uStack_eb0 = 0;
    uStack_eb8 = uStack_eb8 & 0xffffff00;
    uStack_ec0 = uStack_ec0 & 0xffffffffffffff00;
    uStack_ec8 = (longlong *)((ulonglong)uStack_ec8 & 0xffffffffffffff00);
    uStack_ed0 = (undefined8 *)((ulonglong)uStack_ed0 & 0xffffffffffffff00);
    uStack_ed8 = CONCAT71(uStack_ed8._1_7_,1);
    func_0x(param_1,param_2,&uStack_c88,&uStack_c98);
    goto LAB_;
  }
  uStack_ed8 = 0xe2cd0;
  if (*(int *)((longlong)param_1 + 0x5ff4) == 0) {
    uStack_ed8 = 0xe2ac0;
  }
  uStack_ed0 = (undefined8 *)0x0;
  func_0x(auStack_a58,0,0,0);
  if ((((*(uint *)((longlong)param_1 + 0x24) >> 7 & 1) == 0) &&
      (*(char *)(*plStack_de8 + 0x206c) == '\0')) || (*(char *)((longlong)param_2 + 0x16) != '\x10')
     ) {
    uStack_478 = 0;
    uStack_474 = uStack_474 & 0xffff0000;
    uStack_ea8 = CONCAT11(uStack_ea8._1_1_,DAT_);
    cStack_de0 = DAT_;
    if (DAT_ != '\0') {
      puVar15 = (undefined4 *)func_0x(param_1);
      uStack_488 = *param_2;
      uStack_484 = param_2[1];
      uStack_480 = param_2[2];
      uStack_47c = param_2[3];
      uStack_478 = param_2[4];
      uStack_474 = param_2[5];
      uStack_470 = param_2[6];
      uStack_46c = param_2[7];
      uStack_468 = param_2[8];
      uStack_464 = param_2[9];
      uStack_460 = param_2[10];
      uStack_45c = param_2[0xb];
      puStack_ac8 = puVar15;
      if (puVar15 != (undefined4 *)0x0) {
        uStack_d30 = func_0x(param_2);
        if ((*(char *)((longlong)param_2 + 0x16) == '\n') && (uStack_d30 < 0x34)) {
          uStack_d30 = 0x34;
        }
        func_0x(puVar15,0x6000,param_2,uStack_d30);
        puVar22 = puVar15;
        puStack_e10 = puVar15;
        puStack_e08 = puVar15;
      }
    }
    uStack_e20 = 0;
    lVar25 = param_1[0x108a];
    uVar20 = uStack_e28;
    if ((lVar25 == 0) || (iVar7 = func_0x(param_1,puVar22), uVar20 = uStack_e28, iVar7 != 0)
       ) {
LAB_:
      puVar22 = puStack_e10;
      uStack_ec0 = 0;
      uStack_ec8 = (longlong *)0x0;
      uStack_ed0 = (undefined8 *)((ulonglong)uStack_ed0 & 0xffffffffffffff00);
      uStack_ed8 = uStack_ed8 & 0xffffffffffffff00;
      uVar9 = func_0x(param_1,puStack_e10,(longlong)param_1 + 0x5674,uVar20);
      uStack_df0 = uVar9;
      uStack_bf4 = uVar9;
      if ((*(char *)((longlong)param_2 + 0x16) == '\x15') && (uVar9 == 0)) {
        puVar29 = puVar22 + 6;
        uStack_ca2 = *puVar29;
        uStack_c9e = *(undefined2 *)(puVar22 + 7);
        lStack_ab8 = *param_1;
        puStack_ac0 = puVar29;
        lStack_ab0 = func_0x(*(undefined8 *)(lStack_ab8 + 0x6a0),uStack_c9e,1);
        if (lStack_ab0 != 0) {
          uStack_ea4 = *puVar29;
          uStack_ea0 = *(undefined2 *)(puVar22 + 7);
          puStack_aa8 = puVar29;
          if (uStack_ea4 < *(uint *)(lStack_ab0 + 0x80)) {
            func_0x(param_1,puStack_e10,(longlong)param_1 + 0x5674);
          }
        }
      }
    }
    else {
      uStack_ed8 = uStack_e28;
      cVar4 = func_0x(lVar25,param_2,(longlong)param_1 + 0x5674,plVar12);
      if (cVar4 == '\0') {
        func_0x(param_1,0);
        goto LAB_;
      }
      uStack_df0 = 0;
      iStack_dcc = 1;
      uStack_e20 = 1;
      uVar9 = uVar23;
    }
    if (((char)uStack_ea8 != '\0') &&
       (iVar7 = func_0x(puStack_e10,&uStack_488,0x30), iVar7 != 0)) {
      uStack_cd0 = 0x4000000000000017;
      if ((_DAT_ & 0x40000000) != 0) {
        uStack_db0 = *(undefined4 *)((longlong)param_1 + 0x5674);
        uStack_dac = *(undefined4 *)(param_1 + 0xacf);
        uStack_e00 = 0x4000000000000017;
        uStack_a20 = 0;
        uStack_a1e = 2;
        uStack_a18 = 0;
        ppuStack_a10 = &puStack_9f8;
        puStack_a08 = auStack_9d8;
        uStack_7d8 = 0;
        uStack_7d4 = 0;
        uStack_a00 = 0;
        uStack_7d0 = 0;
        puStack_9f8 = &uStack_7c8;
        uStack_9f0 = 0x1c;
        uStack_9ec = 1;
        uStack_9ea = 0;
        lStack_9e8 = 0;
        uStack_9e0 = 0;
        uStack_9dc = 4;
        uStack_9da = 0;
        uStack_d20 = *(ushort *)(*(longlong *)(*param_1 + 0x6b0) + 0x28);
        uStack_7c8 = (uint)uStack_d20;
        uStack_a98 = CONCAT44(uStack_db0,uStack_dac);
        uStack_7bc = (uint)*(ushort *)((longlong)param_1 + 0x567c);
        uStack_7b8 = (uint)*(byte *)((longlong)param_2 + 0x16);
        puStack_aa0 = (undefined4 *)((longlong)param_1 + 0x5674);
        uStack_7c4 = uStack_a98;
        uVar3 = 4;
        lStack_a90 = func_0x(*(byte *)((longlong)param_2 + 0x16));
        uStack_9dc = uVar3;
        if (lStack_a90 != 0) {
          lVar25 = -1;
          do {
            lVar25 = lVar25 + 1;
          } while (*(short *)(lStack_a90 + lVar25 * 2) != 0);
          uVar10 = (int)lVar25 * 2;
        }
        uStack_9da = 0;
        uStack_d54 = uVar10;
        lStack_9e8 = lStack_a90;
        uStack_9e0 = uVar10;
        func_0x(auStack_a28);
      }
      cVar4 = func_0x(*param_1);
      if (cVar4 == '\0') {
        bStack_ddf = DAT_;
        if ((DAT_ & 1) == 0) goto LAB_;
        bVar32 = *(byte *)((longlong)param_2 + 0x16);
        uStack_ed8 = 0x10ec040;
        uVar21 = 0x32ce;
      }
      else {
        bVar32 = *(byte *)((longlong)param_2 + 0x16);
        uStack_ed8 = 0x10ec070;
        uVar21 = 0x32c4;
      }
      uStack_ed0 = (undefined8 *)CONCAT44(uStack_ed0._4_4_,(uint)bVar32);
      (*_DAT_)(1,0x10a7aa8,0x10a3eb0,uVar21);
    }
LAB_:
    if (uVar9 != 0) {
      param_1[0xbfc] = param_1[0xbfc] + 1;
    }
  }
  else {
    uStack_ca8 = *(uint *)puVar34;
    uStack_ca4 = *(undefined2 *)((longlong)puVar34 + 4);
    uStack_ad8 = *(undefined8 *)(*plStack_de8 + 0x6a0);
    puStack_ae0 = puVar34;
    lStack_ad0 = func_0x(uStack_ad8,uStack_ca4,1);
    if (((lStack_ad0 == 0) || ((*(byte *)(lStack_ad0 + 100) & 0x40) == 0)) && (param_1[0x108a] != 0)
       ) {
      func_0x(param_1[0x108a],0xd5e5e8,(longlong)param_1 + 0x5674);
    }
    func_0x(param_1,param_2,(longlong)param_1 + 0x5674,uStack_e28);
    uStack_df0 = 0;
  }
  func_0x(auStack_a58);
  lVar13 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar25 = *(longlong *)(lVar13 + 0x100);
  if (lVar25 == 0) {
    (*_DAT_)();
    lVar25 = *(longlong *)(lVar13 + 0x100);
  }
  if (*(int *)(lVar25 + 0x22c) != 0) {
    (*_DAT_)();
  }
  if (uStack_df0 == 0) {
    if (iStack_dcc == 0) {
      if (((DAT_ & 8) != 0) ||
         (((lVar25 = *(longlong *)
                      ((ulonglong)*_DAT_ +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
           lVar25 != 0 && (lVar25 = **(longlong **)(lVar25 + 0x38), lVar25 != 0)) &&
          (iVar7 = (*_DAT_)(lVar25,0xd4b), iVar7 != 0)))) {
        uStack_d1c = 0x5c;
        uStack_dc4 = 100;
        func_0x((longlong)param_1 + 0x5674,&uStack_dc4,auStack_128);
        func_0x((longlong)param_1 + 0x5674,alStack_338,&uStack_d1c);
        uStack_eb8 = puStack_e08[6];
        bVar32 = *(byte *)((longlong)param_2 + 0x16);
        plVar12 = plVar30;
        do {
          bVar1 = *pbVar24;
          if (bVar1 == bVar32) {
            uStack_ec8 = *(longlong **)(pbVar24 + 8);
            break;
          }
          uStack_ec8 = plVar30;
          if (bVar32 <= bVar1 && bVar1 != bVar32) break;
          plVar12 = (longlong *)((longlong)plVar12 + 1);
          pbVar24 = pbVar24 + 0x10;
        } while (plVar12 < (longlong *)0x57);
        uStack_ec0 = CONCAT44(uStack_ec0._4_4_,(uint)*(ushort *)(puStack_e08 + 7));
        uStack_ed0 = (undefined8 *)CONCAT44(uStack_ed0._4_4_,param_2[4]);
        uStack_ed8 = CONCAT44(uStack_ed8._4_4_,(uint)*(ushort *)(param_2 + 5));
        plVar12 = alStack_338;
        puVar31 = auStack_128;
        uVar21 = 0xfb3e50;
        uVar10 = uStack_dc4;
        goto LAB_;
      }
    }
    else if (((DAT_ & 8) != 0) ||
            (((lVar25 = *(longlong *)
                         ((ulonglong)*_DAT_ +
                         *(longlong *)
                          (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
              lVar25 != 0 && (lVar25 = **(longlong **)(lVar25 + 0x38), lVar25 != 0)) &&
             (iVar7 = (*_DAT_)(lVar25,0xd4b), iVar7 != 0)))) {
      auStack_d18[0] = 0x5c;
      uStack_dc8 = 100;
      func_0x((longlong)param_1 + 0x5674,&uStack_dc8,auStack_198);
      func_0x((longlong)param_1 + 0x5674,alStack_398,auStack_d18);
      uStack_eb8 = puStack_e08[6];
      bVar32 = *(byte *)((longlong)param_2 + 0x16);
      plVar12 = plVar30;
      do {
        bVar1 = *pbVar24;
        if (bVar1 == bVar32) {
          uStack_ec8 = *(longlong **)(pbVar24 + 8);
          break;
        }
        uStack_ec8 = plVar30;
        if (bVar32 <= bVar1 && bVar1 != bVar32) break;
        plVar12 = (longlong *)((longlong)plVar12 + 1);
        pbVar24 = pbVar24 + 0x10;
      } while (plVar12 < (longlong *)0x57);
      uStack_ec0 = CONCAT44(uStack_ec0._4_4_,(uint)*(ushort *)(puStack_e08 + 7));
      uStack_ed0 = (undefined8 *)CONCAT44(uStack_ed0._4_4_,param_2[4]);
      uStack_ed8 = CONCAT44(uStack_ed8._4_4_,(uint)*(ushort *)(param_2 + 5));
      plVar12 = alStack_398;
      puVar31 = auStack_198;
      uVar21 = 0xfb3db0;
      uVar10 = uStack_dc8;
LAB_:
      func_0x(uVar21,uVar10 >> 1,puVar31,plVar12);
    }
    if (*(int *)(param_1 + 4) != 3) goto LAB_;
  }
  else if (((DAT_ & 8) != 0) ||
          (((lVar25 = *(longlong *)
                       ((ulonglong)*_DAT_ +
                       *(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
            lVar25 != 0 && (lVar25 = **(longlong **)(lVar25 + 0x38), lVar25 != 0)) &&
           (iVar7 = (*_DAT_)(lVar25,0xd4b), iVar7 != 0)))) {
    uStack_d58 = 0x5c;
    uStack_dbc = 100;
    func_0x((longlong)param_1 + 0x5674,&uStack_dbc,auStack_208);
    func_0x((longlong)param_1 + 0x5674,alStack_3f8,&uStack_d58);
    uStack_eb8 = puStack_e08[6];
    bVar32 = *(byte *)((longlong)param_2 + 0x16);
    plVar12 = plVar30;
    do {
      bVar1 = *pbVar24;
      if (bVar1 == bVar32) {
        uStack_ec8 = *(longlong **)(pbVar24 + 8);
        break;
      }
      uStack_ec8 = plVar30;
      if (bVar32 <= bVar1 && bVar1 != bVar32) break;
      plVar12 = (longlong *)((longlong)plVar12 + 1);
      pbVar24 = pbVar24 + 0x10;
    } while (plVar12 < (longlong *)0x57);
    uStack_ec0 = CONCAT44(uStack_ec0._4_4_,(uint)*(ushort *)(puStack_e08 + 7));
    uStack_ed0 = (undefined8 *)CONCAT44(uStack_ed0._4_4_,param_2[4]);
    uStack_ed8 = CONCAT44(uStack_ed8._4_4_,(uint)*(ushort *)(param_2 + 5));
    func_0x(0xfb3d20,uStack_dbc >> 1,auStack_208,alStack_3f8);
  }
  if (*(char *)((longlong)param_2 + 0x16) == '\x04') {
    if (((*(char *)((longlong)param_2 + 0x17) == '\x14') ||
        (*(char *)((longlong)param_2 + 0x17) == '\x17')) &&
       ((*(uint *)((longlong)param_1 + 0x24) >> 7 & 1) == 0)) {
      uStack_ea8 = *(ushort *)(*param_1 + 0x67e);
      lVar25 = *(longlong *)(*param_1 + 0x6b0);
      uVar20 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
      if (*(int *)(lVar25 + 0x1500) == 0) {
        LOCK();
        bVar35 = *(ulonglong *)(lVar25 + 0x1500) == 0;
        if (bVar35) {
          *(ulonglong *)(lVar25 + 0x1500) = uVar20;
        }
        UNLOCK();
        if (!bVar35) goto LAB_;
      }
      else {
LAB_:
        plVar26 = plVar30;
        plVar12 = plVar30;
        if (((byte)*_DAT_ & 0x84) == 0x84) {
          lVar13 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          if ((lVar13 != 0) && (*(longlong *)(lVar13 + 0x110) == lVar13)) {
            plVar12 = *(longlong **)(lVar13 + 0x100);
          }
          if ((plVar12 != (longlong *)0x0) && (plVar26 = _DAT_, *_DAT_ != 0)) {
            (*_DAT_)(&plStack_c30);
            plVar26 = plStack_c30;
          }
        }
        if (*(char *)(_DAT_ + 199) < '\0') {
          func_0x(lVar25 + 0x1500,plVar12,uVar20);
        }
        else {
          func_0x(lVar25 + 0x1500,uVar20);
        }
        if (plVar12 != (longlong *)0x0) {
          plVar27 = _DAT_;
          if (*_DAT_ != 0) {
            (*_DAT_)(&plStack_c28);
            plVar27 = plStack_c28;
          }
          plVar19 = plVar30;
          if (plVar26 <= plVar27) {
            plVar19 = (longlong *)((longlong)plVar27 - (longlong)plVar26);
          }
          plVar12[399] = plVar12[399] + (longlong)plVar19;
        }
      }
      lVar25 = *param_1;
      uStack_cd0 = *(undefined8 *)(lVar25 + 0x8a8);
      uStack_ea4 = CONCAT22(uStack_ea4._2_2_,*(undefined2 *)(lVar25 + 0x8b0));
      lVar25 = *(longlong *)(lVar25 + 0x6b0);
      if ((*_DAT_ != '\0') && (iVar7 = (*_DAT_)(), iVar7 == (iVar7 / 5) * 5)) {
        func_0x();
      }
      *(undefined8 *)(lVar25 + 0x1500) = 0;
      func_0x(*param_1);
      lVar25 = *(longlong *)(*param_1 + 0x6b0);
      uVar20 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
      if (*(int *)(lVar25 + 0x1500) == 0) {
        LOCK();
        bVar35 = *(ulonglong *)(lVar25 + 0x1500) == 0;
        if (bVar35) {
          *(ulonglong *)(lVar25 + 0x1500) = uVar20;
        }
        UNLOCK();
        if (!bVar35) goto LAB_;
      }
      else {
LAB_:
        plVar26 = plVar30;
        plVar12 = plVar30;
        if (((byte)*_DAT_ & 0x84) == 0x84) {
          lVar13 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          if ((lVar13 != 0) && (*(longlong *)(lVar13 + 0x110) == lVar13)) {
            plVar12 = *(longlong **)(lVar13 + 0x100);
          }
          if ((plVar12 != (longlong *)0x0) && (plVar26 = _DAT_, *_DAT_ != 0)) {
            (*_DAT_)(&plStack_c20);
            plVar26 = plStack_c20;
          }
        }
        if (*(char *)(_DAT_ + 199) < '\0') {
          func_0x(lVar25 + 0x1500,plVar12,uVar20);
        }
        else {
          func_0x(lVar25 + 0x1500,uVar20);
        }
        if (plVar12 != (longlong *)0x0) {
          plVar27 = _DAT_;
          if (*_DAT_ != 0) {
            (*_DAT_)(&plStack_c18);
            plVar27 = plStack_c18;
          }
          plVar19 = plVar30;
          if (plVar26 <= plVar27) {
            plVar19 = (longlong *)((longlong)plVar27 - (longlong)plVar26);
          }
          plVar12[399] = plVar12[399] + (longlong)plVar19;
        }
      }
      lVar25 = *param_1;
      uStack_e00 = *(undefined8 *)(lVar25 + 0x8a8);
      uVar28 = *(ushort *)(lVar25 + 0x8b0);
      lVar25 = *(longlong *)(lVar25 + 0x6b0);
      if ((*_DAT_ != '\0') && (iVar7 = (*_DAT_)(), iVar7 == (iVar7 / 5) * 5)) {
        func_0x();
      }
      *(undefined8 *)(lVar25 + 0x1500) = 0;
      lVar25 = *param_1;
      if (uStack_ea8 != *(ushort *)(lVar25 + 0x67e)) {
        uStack_ed0 = (undefined8 *)CONCAT44(uStack_ed0._4_4_,(uint)*(ushort *)(lVar25 + 0x67e));
        uStack_ed8 = CONCAT44(uStack_ed8._4_4_,(uint)uStack_ea8);
        func_0x(lVar25,0x3e1,*(undefined4 *)(*(longlong *)(lVar25 + 0x6b0) + 0x3a0),
                        *(longlong *)(lVar25 + 0x6b0) + 0x3a8);
        lVar25 = *plStack_de8;
      }
      if ((*(char *)(lVar25 + 0x2050) != '\0') &&
         ((*(byte *)(*(longlong *)(lVar25 + 0x6b0) + 0x2ac) & 2) != 0)) {
        func_0x
                  (_DAT_,*(undefined2 *)(*(longlong *)(lVar25 + 0x6b0) + 0x28),0x7d35c1d,1);
        lVar25 = *param_1;
        if ((uint)uStack_cd0 < (uint)uStack_e00) {
LAB_:
          if (((*(byte *)(*(longlong *)(lVar25 + 0x6b0) + 0x2ac) & 2) != 0) ||
             ((*(byte *)(*(longlong *)(lVar25 + 0x6b0) + 0x38) & 8) == 0)) {
            plVar12 = plVar30;
            if (*(int *)(_DAT_ + 0x4c) != 0) {
              plVar12 = **(longlong ***)(_DAT_ + 0x28);
            }
            iVar7 = func_0x(plVar12[0x242]);
            if (iVar7 != 0) {
              func_0x(*(undefined8 *)(lVar25 + 0x6a0));
              func_0x(*(undefined8 *)(lVar25 + 0x6a8));
              (*_DAT_)(lVar25);
            }
          }
        }
        else if ((uint)uStack_e00 == (uint)uStack_cd0) {
          if ((uStack_cd0._4_4_ < uStack_e00._4_4_) ||
             ((uStack_e00._4_4_ == uStack_cd0._4_4_ && ((ushort)uStack_ea4 < uVar28))))
          goto LAB_;
        }
      }
    }
  }
  else if (*(char *)((longlong)param_2 + 0x16) == '\x10') {
    sStack_e98 = -1;
    pbStack_e90 = (byte *)0x0;
    uStack_e94 = 0;
    pbStack_e7a = (byte *)0x0;
    uStack_e70 = 0;
    uStack_e6e = 0;
    uStack_e6c = 0;
    uStack_e6a = 0;
    uStack_e88 = 0;
    uVar10 = 0;
    uStack_e5c = 0;
    pbStack_e42 = (byte *)0x0;
    uStack_e38 = 0;
    uStack_e36 = 0;
    uStack_e34 = 0;
    uStack_e32 = 0;
    uStack_e50 = 0;
    uStack_4d8 = 0;
    uStack_4d0 = 1;
    pbStack_e58 = (byte *)func_0x((longlong)param_2 + 0x3e,0,&uStack_ddc);
    if ((*pbStack_e58 & 1) == 0) {
      sStack_e60 = 0;
      uStack_e3a = 0;
      uStack_e38 = 0;
      uVar9 = 0;
      uVar10 = 0;
      switch(*pbStack_e58 & 0xe) {
      default:
        uVar28 = *(ushort *)(pbStack_e58 + 2);
        uVar9 = (uint)uVar28;
        uVar10 = 0;
        if (0x1f9d < uVar28 - 1) {
          func_0x(pbStack_e58,6);
          uVar9 = (uint)uVar28;
          uVar10 = uStack_e5c;
        }
        break;
      case 4:
        uVar9 = 9;
        uVar10 = 0;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar9 = 1;
        uVar10 = 0;
      }
      uStack_e50 = CONCAT44(uStack_e50._4_4_,uVar9);
    }
    else {
      sStack_e60 = 1;
      bVar32 = *pbStack_e58;
      uVar9 = uVar23;
      switch(bVar32 & 0x1c) {
      default:
        if ((char)pbStack_e58[1] < '\0') {
          uStack_e5e = (*(ushort *)(pbStack_e58 + 1) & 0x7f) << 8 |
                       *(ushort *)(pbStack_e58 + 1) >> 8;
          uStack_e48 = 3;
          sVar5 = 3;
        }
        else {
          uStack_e5e = (ushort)pbStack_e58[1];
          sVar5 = 2;
          uStack_e48 = 2;
        }
        uStack_e44 = (short)(uStack_e5e + 1 >> 1) + sVar5;
        if (uStack_e5e < 0x1f) {
          uStack_e30 = 0;
          uVar10 = 0;
        }
        else {
          iVar7 = uStack_e5e - 1;
          uStack_e48 = CONCAT22(((short)(iVar7 / 0x1e) + (short)(iVar7 >> 0x1f)) -
                                (short)((longlong)iVar7 * 0x88888889 >> 0x3f),(undefined2)uStack_e48
                               );
          uStack_e30 = 0;
        }
        break;
      case 4:
        if (((bVar32 & 0x1c) == 4) && ((bVar32 & 2) != 0)) {
          uStack_e48 = 0;
          uStack_e5e = 0;
          uStack_e44 = 0;
          uStack_e3a = 0;
          uVar10 = 0xf;
          uStack_e5c = 0xf;
          uStack_e30 = 1;
        }
        else {
          uStack_e48 = 0;
          uStack_e5e = 0;
          uStack_e44 = 0;
          uStack_e3a = 0;
          uVar10 = 1;
          uStack_e5c = 1;
          uStack_e30 = 0;
        }
        break;
      case 8:
        uStack_e48 = 0;
        uStack_e5e = 0;
        uStack_e44 = 0;
        uStack_e3a = 0;
        uVar10 = 9;
        uStack_e5c = 9;
        uStack_e30 = 0;
      }
    }
    uStack_ea4 = 9;
    if (sStack_e60 == 0) {
      if (uVar10 == 0) {
        uStack_e5e = 0;
        uStack_e50 = CONCAT44(uVar9,(undefined4)uStack_e50);
        pbVar24 = (byte *)func_0x(&uStack_e5e);
        if ((*pbVar24 & 0x10) != 0) {
          pbVar24 = (byte *)func_0x(&uStack_e5e);
          uVar10 = uVar23;
          if ((*pbVar24 & 0x10) != 0) {
            uVar10 = (uint)*(ushort *)(pbStack_e58 + (uStack_e50 & 0xffffffff));
          }
          uStack_e50 = CONCAT44((uVar10 + 7 >> 3) + uStack_e50._4_4_ + 2,(undefined4)uStack_e50);
        }
        pbVar24 = (byte *)func_0x(&uStack_e5e);
        if ((*pbVar24 & 0x20) == 0) {
          uStack_e5c = uStack_e50._4_4_;
          uStack_e44 = 0;
          uStack_e48 = uStack_e50._4_4_;
        }
        else {
          puVar16 = (ushort *)func_0x(&uStack_e5e);
          uStack_e44 = *puVar16;
          if (uStack_e44 == 0) {
            cVar4 = func_0x(0x162d700);
            if ((cVar4 != '\0') && (cVar4 = func_0x(), cVar4 != '\0')) {
              cVar4 = func_0x(0x162d700);
              if (cVar4 == '\0') {
                (*pcRam0000000000b9b288)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_ed8 = 0;
                (*_DAT_)(1,0xf1d10c,0x103d1f8,0x80f);
              }
            }
            func_0x(pbStack_e58,3);
          }
          uStack_e48 = uStack_e50._4_4_ + 2 + (uint)uStack_e44 * 2;
          if (0x1f9e < uStack_e48) {
            cVar4 = func_0x(0x162d700);
            if ((cVar4 != '\0') && (cVar4 = func_0x(), cVar4 != '\0')) {
              cVar4 = func_0x(0x162d700);
              if (cVar4 == '\0') {
                (*pcRam0000000000b9b288)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_ed8 = 0;
                (*_DAT_)(1,0xf1d10c,0x103d1f8,0x816);
              }
            }
            func_0x(pbStack_e58,4);
          }
          uVar20 = (ulonglong)uStack_e44;
          uStack_e5c = puVar16[uVar20] & 0x7fff;
          if (uStack_e5c < uStack_e48) {
            cVar4 = func_0x(0x162d700);
            if ((cVar4 != '\0') && (cVar4 = func_0x(), cVar4 != '\0')) {
              cVar4 = func_0x(0x162d700);
              if (cVar4 == '\0') {
                (*pcRam0000000000b9b288)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_ed8 = 0;
                (*_DAT_)(1,0xf1d10c,0x103d1f8,0x81d);
              }
            }
            func_0x(pbStack_e58,4);
            uVar20 = (ulonglong)uStack_e44;
          }
          plVar12 = plVar30;
          puVar2 = puVar16;
          uVar10 = uStack_e48;
          if ((short)uVar20 != 0) {
            do {
              uVar9 = puVar2[1] & 0x7fff;
              if ((uVar9 < uVar10) || (uStack_e5c < uVar9)) {
                cVar4 = func_0x(0x162d700);
                if ((cVar4 != '\0') && (cVar4 = func_0x(), cVar4 != '\0')) {
                  cVar4 = func_0x(0x162d700);
                  if (cVar4 == '\0') {
                    (*pcRam0000000000b9b288)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_ed8 = 0;
                    (*_DAT_)(1,0xf1d10c,0x103d1f8,0x82a);
                  }
                }
                func_0x(pbStack_e58,4);
                uVar20 = (ulonglong)uStack_e44;
              }
              uVar33 = (int)plVar12 + 1;
              plVar12 = (longlong *)(ulonglong)uVar33;
              param_2 = puStack_da8;
              puVar2 = puVar2 + 1;
              uVar10 = uVar9;
            } while ((int)uVar33 < (int)uVar20);
          }
          while (iVar7 = func_0x(puVar16 + 1,(int)uVar20 + -1), uVar28 = uStack_e44,
                iVar7 != 0) {
            uVar20 = (ulonglong)uStack_e44;
            lVar25 = func_0x(&uStack_e5e);
            uVar9 = uStack_e48;
            if (uVar28 != 1) {
              uVar9 = *(ushort *)(lVar25 + -2 + uVar20 * 2) & 0x7fff;
            }
            uVar33 = *(ushort *)(lVar25 + uVar20 * 2) & 0x7fff;
            if (((uVar9 < uStack_e48) || (uVar33 < uVar9)) || (uStack_e5c < uVar33)) {
              func_0x(pbStack_e58,7);
            }
            uVar10 = uStack_e5c;
            if ((uVar9 < uStack_e48) || (uStack_e5c < uVar9)) goto code_r0x0010223f;
            if (*(ushort *)(pbStack_e58 + uVar9) == 5) {
              uStack_e5e = uStack_e5e | 2;
              uStack_e44 = uStack_e44 - 1;
              uStack_e36 = (ushort)uVar9;
              pbVar24 = pbStack_e58 + (uVar9 & 0xffff);
              iVar7 = func_0x(pbVar24);
              if (iVar7 == 0) {
                uStack_e34 = uStack_e34 & 0xc7ff;
              }
              else {
                sVar5 = func_0x(pbVar24);
                uStack_e34 = uStack_e34 ^ (sVar5 << 0xb ^ uStack_e34) & 0x3800;
              }
              uVar28 = func_0x(pbVar24);
              uVar28 = uStack_e34 ^ (uVar28 ^ uStack_e34) & 0x7ff;
              uVar20 = (ulonglong)uStack_e36;
              pbVar24 = pbStack_e58 +
                        (ulonglong)((uVar28 & 0x7ff) * 2) + (uStack_e34 >> 0xb & 7) * 2 + uVar20 + 4
              ;
              uStack_e34 = uVar28;
              if (pbVar24 < pbStack_e58 + uVar20) {
                func_0x(pbStack_e58 + uVar20,0x19);
                uVar20 = (ulonglong)uStack_e36;
              }
              uVar28 = (ushort)uVar20;
              if (uVar33 - uVar9 <
                  (((uStack_e34 & 0x7ff) * 2 - (int)uVar20) - (int)pbStack_e58) + (int)pbVar24) {
                func_0x(pbStack_e58 + uVar20,0x19);
                uVar28 = uStack_e36;
              }
              pbVar24 = pbStack_e58;
              if (((uStack_e34 & 0x3800) != 0) && (plVar12 = plVar30, (uStack_e34 & 0x3800) != 0)) {
                do {
                  uVar6 = func_0x(pbVar24 + (ulonglong)uVar28 + 4,plVar12);
                  if ((uStack_e34 & 0x7ff) < uVar6) {
                    func_0x(pbStack_e58 + uStack_e36,0x1a);
                  }
                  uVar10 = (int)plVar12 + 1;
                  plVar12 = (longlong *)(ulonglong)uVar10;
                } while ((int)uVar10 < (int)((uStack_e34 & 0x3800) >> 0xb));
              }
              break;
            }
            if (*(ushort *)(pbStack_e58 + uVar9) < 0x400) break;
            uStack_e5e = uStack_e5e | 1;
            uStack_e44 = uStack_e44 - 1;
            uVar20 = (ulonglong)uStack_e44;
            if (uStack_e44 == 0) break;
          }
        }
        iVar7 = func_0x(&uStack_e5e);
        if (iVar7 == 0) {
          uStack_e3a = 0;
          uStack_e38 = 0;
        }
        else {
          uStack_e3a = (undefined2)uStack_e5c;
          uStack_e38 = (undefined2)(uStack_e5c >> 0x10);
          uStack_e5c = uStack_e5c + 0xe;
          puVar17 = (ulonglong *)func_0x(&uStack_e5e);
          uVar28 = (ushort)(*puVar17 >> 0x30);
          if ((((uint)(int)(short)uVar28 >> 1 ^ (int)(short)uVar28) & 0x2000) != 0) {
            if ((uVar28 >> 0xe & 1) == 0) {
              uVar28 = uVar28 & 0xdfff;
            }
            else {
              uVar28 = uVar28 | 0x2000;
            }
          }
          uVar10 = uVar23;
          if (uVar28 == 0xfffc) {
            uVar10 = (uint)((*puVar17 >> 0x20 & 0xffff) >> 5);
          }
          uStack_e5c = uStack_e5c + uVar10;
        }
        if ((pbStack_e42 != (byte *)0x0) && (pbStack_e42 < pbStack_e58 + uStack_e5c)) {
          cVar4 = func_0x(0x162d700);
          if ((cVar4 != '\0') && (cVar4 = func_0x(), cVar4 != '\0')) {
            cVar4 = func_0x(0x162d700);
            if (cVar4 == '\0') {
              (*pcRam0000000000b9b288)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uStack_ed8 = 0;
              (*_DAT_)(1,0xf1d10c,0x103d1f8,0x886);
            }
          }
          func_0x(pbStack_e58,0x12);
        }
        uVar10 = uStack_e5c;
        if (0x3f3b < uStack_e5c - 1) {
          cVar4 = func_0x(0x162d700);
          if ((cVar4 != '\0') && (cVar4 = func_0x(), cVar4 != '\0')) {
            cVar4 = func_0x(0x162d700);
            if (cVar4 == '\0') {
              (*pcRam0000000000b9b288)(0x22,0x44,0x15,0x3ed);
            }
            else {
              uStack_ed8 = 0;
              (*_DAT_)(1,0xf1d10c,0x103d1f8,0x88b);
            }
          }
          func_0x(pbStack_e58,5);
          uVar10 = uStack_e5c;
        }
      }
code_r0x0010223f:
      if ((uVar10 < 9) && (((*pbStack_e58 & 0xe) == 0 || ((*pbStack_e58 & 0xe) == 0xc)))) {
        uVar10 = 9;
      }
    }
    else {
      if (uVar10 == 0) {
        func_0x(&uStack_e5e);
        uVar10 = uStack_e5c;
      }
      if ((uVar10 < 9) && (((*pbStack_e58 & 0x1c) == 0 || ((*pbStack_e58 & 0x1c) == 0xc)))) {
        uVar10 = 9;
      }
    }
    if (uVar10 != uStack_ddc) {
      uStack_ed8 = 0;
      (*_DAT_)(1,0x10ec018,0x10a3eb0,0x33e7);
    }
    puVar16 = (ushort *)((longlong)param_2 + 0x3e);
    pbStack_e90 = (byte *)func_0x(puVar16,1,&uStack_ddc);
    if ((*pbStack_e90 & 1) == 0) {
      sStack_e98 = 0;
      uStack_e72 = 0;
      uStack_e70 = 0;
      switch(*pbStack_e90 & 0xe) {
      default:
        uVar8 = (uint)*(ushort *)(pbStack_e90 + 2);
        if (0x1f9d < *(ushort *)(pbStack_e90 + 2) - 1) {
          func_0x(pbStack_e90,6);
        }
        break;
      case 4:
        uVar8 = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar8 = 1;
      }
      uStack_e88 = CONCAT44(uStack_e88._4_4_,uVar8);
    }
    else {
      sStack_e98 = 1;
      bVar32 = *pbStack_e90;
      uVar8 = uVar23;
      switch(bVar32 & 0x1c) {
      default:
        if ((char)pbStack_e90[1] < '\0') {
          uStack_e96 = (*(ushort *)(pbStack_e90 + 1) & 0x7f) << 8 |
                       *(ushort *)(pbStack_e90 + 1) >> 8;
          uVar28 = 3;
          sVar5 = 3;
        }
        else {
          uStack_e96 = (ushort)pbStack_e90[1];
          uVar28 = 2;
          sVar5 = 2;
        }
        uStack_e7c = (short)(uStack_e96 + 1 >> 1) + sVar5;
        if (uStack_e96 < 0x1f) {
          uStack_e80 = (uint)uVar28;
          uStack_e68 = 0;
        }
        else {
          iVar7 = uStack_e96 - 1;
          uStack_e80 = CONCAT22(((short)(iVar7 / 0x1e) + (short)(iVar7 >> 0x1f)) -
                                (short)((longlong)iVar7 * 0x88888889 >> 0x3f),uVar28);
          uStack_e68 = 0;
        }
        break;
      case 4:
        if (((bVar32 & 0x1c) == 4) && ((bVar32 & 2) != 0)) {
          uStack_e80 = 0;
          uStack_e96 = 0;
          uStack_e7c = 0;
          uStack_e72 = 0;
          uStack_e94 = 0xf;
          uStack_e68 = 1;
        }
        else {
          uStack_e80 = 0;
          uStack_e96 = 0;
          uStack_e7c = 0;
          uStack_e72 = 0;
          uStack_e94 = 1;
          uStack_e68 = 0;
        }
        break;
      case 8:
        uStack_e80 = 0;
        uStack_e96 = 0;
        uStack_e7c = 0;
        uStack_e72 = 0;
        uStack_e94 = 9;
        uStack_e68 = 0;
      }
    }
    if (sStack_e98 == 0) {
      if (uStack_e94 == 0) {
        uStack_e96 = 0;
        uStack_e88 = CONCAT44(uVar8,(undefined4)uStack_e88);
        pbVar24 = (byte *)func_0x(&uStack_e96);
        if ((*pbVar24 & 0x10) != 0) {
          pbVar24 = (byte *)func_0x(&uStack_e96);
          uVar10 = uVar23;
          if ((*pbVar24 & 0x10) != 0) {
            uVar10 = (uint)*(ushort *)(pbStack_e90 + (uStack_e88 & 0xffffffff));
          }
          uStack_e88 = CONCAT44((uVar10 + 7 >> 3) + uStack_e88._4_4_ + 2,(undefined4)uStack_e88);
        }
        pbVar24 = (byte *)func_0x(&uStack_e96);
        if ((*pbVar24 & 0x20) == 0) {
          uStack_e94 = uStack_e88._4_4_;
          uStack_e7c = 0;
          uStack_e80 = uStack_e94;
        }
        else {
          puVar16 = (ushort *)func_0x(&uStack_e96);
          uStack_e7c = *puVar16;
          if (uStack_e7c == 0) {
            cVar4 = func_0x(0x162d700);
            if ((cVar4 != '\0') && (cVar4 = func_0x(), cVar4 != '\0')) {
              cVar4 = func_0x(0x162d700);
              if (cVar4 == '\0') {
                (*pcRam0000000000b9b288)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_ed8 = 0;
                (*_DAT_)(1,0xf1d10c,0x103d1f8,0x80f);
              }
            }
            func_0x(pbStack_e90,3);
          }
          uStack_e80 = uStack_e88._4_4_ + 2 + (uint)uStack_e7c * 2;
          if (0x1f9e < uStack_e80) {
            cVar4 = func_0x(0x162d700);
            if ((cVar4 != '\0') && (cVar4 = func_0x(), cVar4 != '\0')) {
              cVar4 = func_0x(0x162d700);
              if (cVar4 == '\0') {
                (*pcRam0000000000b9b288)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_ed8 = 0;
                (*_DAT_)(1,0xf1d10c,0x103d1f8,0x816);
              }
            }
            func_0x(pbStack_e90,4);
          }
          uVar20 = (ulonglong)uStack_e7c;
          uStack_e94 = puVar16[uVar20] & 0x7fff;
          if (uStack_e94 < uStack_e80) {
            cVar4 = func_0x(0x162d700);
            if ((cVar4 != '\0') && (cVar4 = func_0x(), cVar4 != '\0')) {
              cVar4 = func_0x(0x162d700);
              if (cVar4 == '\0') {
                (*pcRam0000000000b9b288)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_ed8 = 0;
                (*_DAT_)(1,0xf1d10c,0x103d1f8,0x81d);
              }
            }
            func_0x(pbStack_e90,4);
            uVar20 = (ulonglong)uStack_e7c;
          }
          plVar12 = plVar30;
          puVar2 = puVar16;
          uVar10 = uStack_e80;
          if ((short)uVar20 != 0) {
            do {
              uVar8 = puVar2[1] & 0x7fff;
              if ((uVar8 < uVar10) || (uStack_e94 < uVar8)) {
                cVar4 = func_0x(0x162d700);
                if ((cVar4 != '\0') && (cVar4 = func_0x(), cVar4 != '\0')) {
                  cVar4 = func_0x(0x162d700);
                  if (cVar4 == '\0') {
                    (*pcRam0000000000b9b288)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_ed8 = 0;
                    (*_DAT_)(1,0xf1d10c,0x103d1f8,0x82a);
                  }
                }
                func_0x(pbStack_e90,4);
                uVar20 = (ulonglong)uStack_e7c;
              }
              uVar9 = (int)plVar12 + 1;
              plVar12 = (longlong *)(ulonglong)uVar9;
              param_2 = puStack_da8;
              puVar2 = puVar2 + 1;
              uVar10 = uVar8;
            } while ((int)uVar9 < (int)uVar20);
          }
          while (iVar7 = func_0x(puVar16 + 1,(int)uVar20 + -1), uVar28 = uStack_e7c,
                iVar7 != 0) {
            uVar20 = (ulonglong)uStack_e7c;
            lVar25 = func_0x(&uStack_e96);
            uVar10 = uStack_e80;
            if (uVar28 != 1) {
              uVar10 = *(ushort *)(lVar25 + -2 + uVar20 * 2) & 0x7fff;
            }
            uVar8 = *(ushort *)(lVar25 + uVar20 * 2) & 0x7fff;
            if (((uVar10 < uStack_e80) || (uVar8 < uVar10)) || (uStack_e94 < uVar8)) {
              func_0x(pbStack_e90,7);
            }
            if ((uVar10 < uStack_e80) || (uStack_e94 < uVar10)) goto code_r0x00102c2a;
            if (*(ushort *)(pbStack_e90 + uVar10) == 5) {
              uStack_e96 = uStack_e96 | 2;
              uStack_e7c = uStack_e7c - 1;
              uStack_e6e = (ushort)uVar10;
              pbVar24 = pbStack_e90 + (uVar10 & 0xffff);
              iVar7 = func_0x(pbVar24);
              if (iVar7 == 0) {
                uStack_e6c = uStack_e6c & 0xc7ff;
              }
              else {
                sVar5 = func_0x(pbVar24);
                uStack_e6c = uStack_e6c ^ (sVar5 << 0xb ^ uStack_e6c) & 0x3800;
              }
              uVar28 = func_0x(pbVar24);
              uVar28 = uStack_e6c ^ (uStack_e6c ^ uVar28) & 0x7ff;
              uVar20 = (ulonglong)uStack_e6e;
              pbVar24 = pbStack_e90 +
                        uVar20 + 4 +
                        (ulonglong)((uVar28 & 0x7ff) * 2) + (ulonglong)((uStack_e6c >> 0xb & 7) * 2)
              ;
              uStack_e6c = uVar28;
              if (pbVar24 < pbStack_e90 + uVar20) {
                func_0x(pbStack_e90 + uVar20,0x19);
                uVar20 = (ulonglong)uStack_e6e;
              }
              uVar28 = (ushort)uVar20;
              if (uVar8 - uVar10 <
                  (((uStack_e6c & 0x7ff) * 2 - (int)uVar20) - (int)pbStack_e90) + (int)pbVar24) {
                func_0x(pbStack_e90 + uVar20,0x19);
                uVar28 = uStack_e6e;
              }
              pbVar24 = pbStack_e90;
              if (((uStack_e6c & 0x3800) != 0) && (plVar12 = plVar30, (uStack_e6c & 0x3800) != 0)) {
                do {
                  uVar6 = func_0x(pbVar24 + (ulonglong)uVar28 + 4,plVar12);
                  if ((uStack_e6c & 0x7ff) < uVar6) {
                    func_0x(pbStack_e90 + uStack_e6e,0x1a);
                  }
                  uVar10 = (int)plVar12 + 1;
                  plVar12 = (longlong *)(ulonglong)uVar10;
                } while ((int)uVar10 < (int)((uStack_e6c & 0x3800) >> 0xb));
              }
              break;
            }
            if (*(ushort *)(pbStack_e90 + uVar10) < 0x400) break;
            uStack_e96 = uStack_e96 | 1;
            uStack_e7c = uStack_e7c - 1;
            uVar20 = (ulonglong)uStack_e7c;
            if (uStack_e7c == 0) break;
          }
        }
        iVar7 = func_0x(&uStack_e96);
        if (iVar7 == 0) {
          uStack_e72 = 0;
          uStack_e70 = 0;
        }
        else {
          uStack_e72 = (undefined2)uStack_e94;
          uStack_e70 = (undefined2)(uStack_e94 >> 0x10);
          uStack_e94 = uStack_e94 + 0xe;
          puVar17 = (ulonglong *)func_0x(&uStack_e96);
          uVar28 = (ushort)(*puVar17 >> 0x30);
          if ((((uint)(int)(short)uVar28 >> 1 ^ (int)(short)uVar28) & 0x2000) != 0) {
            if ((uVar28 >> 0xe & 1) == 0) {
              uVar28 = uVar28 & 0xdfff;
            }
            else {
              uVar28 = uVar28 | 0x2000;
            }
          }
          uVar10 = uVar23;
          if (uVar28 == 0xfffc) {
            uVar10 = (uint)((*puVar17 >> 0x20 & 0xffff) >> 5);
          }
          uStack_e94 = uStack_e94 + uVar10;
        }
        if ((pbStack_e7a != (byte *)0x0) && (pbStack_e7a < pbStack_e90 + uStack_e94)) {
          cVar4 = func_0x(0x162d700);
          if ((cVar4 != '\0') && (cVar4 = func_0x(), cVar4 != '\0')) {
            cVar4 = func_0x(0x162d700);
            if (cVar4 == '\0') {
              (*pcRam0000000000b9b288)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uStack_ed8 = 0;
              (*_DAT_)(1,0xf1d10c,0x103d1f8,0x886);
            }
          }
          func_0x(pbStack_e90,0x12);
        }
        if (0x3f3b < uStack_e94 - 1) {
          cVar4 = func_0x(0x162d700);
          if ((cVar4 != '\0') && (cVar4 = func_0x(), cVar4 != '\0')) {
            cVar4 = func_0x(0x162d700);
            if (cVar4 == '\0') {
              (*pcRam0000000000b9b288)(0x22,0x44,0x15,0x3ed);
            }
            else {
              uStack_ed8 = 0;
              (*_DAT_)(1,0xf1d10c,0x103d1f8,0x88b);
            }
          }
          func_0x(pbStack_e90,5);
        }
code_r0x00102c2a:
        puVar16 = (ushort *)((longlong)param_2 + 0x3e);
      }
      if ((8 < uStack_e94) || (((*pbStack_e90 & 0xe) != 0 && ((*pbStack_e90 & 0xe) != 0xc)))) {
        uStack_ea4 = uStack_e94;
      }
    }
    else {
      if (uStack_e94 == 0) {
        func_0x(&uStack_e96);
      }
      if ((uStack_e94 < 9) && (((*pbStack_e90 & 0x1c) == 0 || ((*pbStack_e90 & 0x1c) == 0xc)))) {
        uStack_ea4 = 9;
      }
      else {
        uStack_ea4 = uStack_e94;
      }
    }
    if (uStack_ea4 != uStack_ddc) {
      uStack_ed8 = 0;
      (*_DAT_)(1,0x10ec248,0x10a3eb0,0x33ec);
    }
    puVar14 = (undefined8 *)func_0x(puVar16,3,&uStack_d24);
    if (*puVar16 < 3) {
      puVar18 = &uStack_4d8;
    }
    else {
      puVar18 = (undefined8 *)func_0x(puVar16,2,auStack_c08);
    }
    if ((*(int *)(param_1 + 4) == 3) || ((*(uint *)((longlong)param_1 + 0x24) >> 7 & 1) != 0)) {
      uVar23 = 1;
    }
    iVar7 = func_0x(&sStack_e60);
    puVar22 = puStack_e10;
    if (iVar7 == 2) {
      uStack_bd0 = 0;
      pppppuStack_bd8 = &pppppuStack_be0;
      pppppuStack_be0 = &pppppuStack_be0;
      uStack_d08 = 0;
      uStack_d00 = 0;
      uVar21 = func_0x
                         (*(undefined8 *)(*param_1 + 0x6a0),*(undefined2 *)(puStack_e10 + 7),
                          &uStack_d08,4);
      func_0x(uVar21,1);
      lStack_be8._0_4_ = 7;
      uStack_ec8 = &lStack_be8;
      uStack_ed8 = CONCAT44(uStack_ed8._4_4_,uStack_d24 >> 5);
      uStack_ed0 = puVar14;
      (**(code **)(**(longlong **)(*param_1 + 0x6c8) + 0x200))
                (*(longlong **)(*param_1 + 0x6c8),*(undefined2 *)(puVar22 + 7),&sStack_e60,
                 &sStack_e98);
      (**(code **)(**(longlong **)(*param_1 + 0x6c8) + 0x208))
                (*(longlong **)(*param_1 + 0x6c8),&lStack_be8);
      if ((int)uStack_d00 != 0) {
        func_0x(uStack_d08,uStack_d00._4_4_);
        uStack_d00 = uStack_d00 & 0xffffffff00000000;
      }
    }
    else {
      uStack_ec8 = (longlong *)((longlong)param_1 + 0x5674);
      uStack_ec0 = CONCAT44(uStack_ec0._4_4_,1);
      uStack_ed8 = CONCAT44(uStack_ed8._4_4_,uVar23);
      uStack_ed0 = puVar18;
      func_0x
                (*(undefined8 *)(*param_1 + 0x6a0),*(undefined2 *)(puStack_e10 + 7),&sStack_e60,
                 &sStack_e98);
    }
  }
  uVar21 = _DAT_;
  if (((((*(byte *)(uStack_e28 + 0x16) & 2) != 0) &&
       (*(short *)((longlong)param_1 + 0x567c) == *(short *)(uStack_e28 + 0x20))) &&
      (*(int *)((longlong)param_1 + 0x5674) == *(int *)(uStack_e28 + 0x18))) &&
     (*(int *)(param_1 + 0xacf) == *(int *)(uStack_e28 + 0x1c))) {
    uStack_db8 = (undefined4 *)
                 CONCAT26(uStack_db8._6_2_,*(undefined6 *)(*(longlong *)(uStack_e28 + 0x50) + 0x10))
    ;
    lStack_ce8 = 0;
    uStack_ce0 = 0;
    uStack_cdc = 0;
    iVar7 = func_0x
                      (_DAT_,&uStack_db8,*(undefined4 *)(*param_1 + 0x6b8),&lStack_ce8);
    if (((iVar7 != 0) && ((*(uint *)(lStack_ce8 + 100) >> 0xb & 1) == 0)) &&
       (((*(uint *)(lStack_ce8 + 100) & 2) != 0 &&
        (plVar30 = (longlong *)0x0, (*(uint *)(lStack_ce8 + 100) & 4) == 0)))) {
      uVar10 = func_0x(uVar21,lStack_ce8,3,0);
      plVar30 = (longlong *)(ulonglong)uVar10;
    }
    func_0x(&lStack_ce8);
    LOCK();
    plStack_de8[0xb5f] = plStack_de8[0xb5f] + 1;
    UNLOCK();
    LOCK();
    plStack_de8[0xb60] = plStack_de8[0xb60] + (longlong)plVar30;
    UNLOCK();
  }
LAB_:
  func_0x(param_1,(longlong)param_1 + 0x5674);
  func_0x(param_1 + 0xad2,(longlong)param_1 + 0x5674);
  func_0x(param_2,param_1 + 0xadd);
  if (((*(char *)(*param_1 + 0x2050) != '\0') &&
      (plVar30 = *(longlong **)(*param_1 + 0x65f0), *plVar30 != 0)) &&
     (*(char *)(plVar30 + 0x370) == '\0')) {
    if (*(uint *)(plVar30 + 0xa8) < 0x10001) {
      lVar25 = *(longlong *)plVar30[0xb];
      uVar21 = func_0x(param_1,auStack_498,0);
      (**(code **)(lVar25 + 0x18))(plVar30[0xb],uVar21);
    }
    else if (*(char *)((longlong)param_1 + 0x56c4) != '\0') {
      puVar22 = (undefined4 *)func_0x(param_1,auStack_498,0);
      if ((*plVar30 != 0) && (0x1ffff < *(uint *)(plVar30 + 0xa8))) {
        (*_DAT_)(*plVar30,CONCAT44(*puVar22,puVar22[1]));
      }
    }
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_ef8);
  return;
}

