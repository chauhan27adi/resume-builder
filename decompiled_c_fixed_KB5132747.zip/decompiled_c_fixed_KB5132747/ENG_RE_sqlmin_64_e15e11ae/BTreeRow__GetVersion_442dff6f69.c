
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x01061f5b) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  char cVar1;
  ushort uVar2;
  longlong lVar3;
  longlong lVar4;
  short *psVar5;
  uint *puVar6;
  int iVar7;
  longlong unaff_GS_OFFSET;
  undefined auStack_438 [32];
  short *psStack_418;
  longlong lStack_410;
  undefined uStack_408;
  undefined8 uStack_400;
  undefined8 uStack_3f8;
  undefined8 *puStack_3f0;
  undefined uStack_3e8;
  undefined8 uStack_3e0;
  undefined uStack_3d8;
  longlong lStack_3d0;
  undefined8 uStack_3c8;
  longlong lStack_3b8;
  longlong lStack_3b0;
  longlong lStack_3a0;
  undefined8 uStack_398;
  undefined2 uStack_390;
  int iStack_376;
  short sStack_372;
  longlong lStack_348;
  longlong lStack_2b0;
  undefined8 uStack_1c0;
  undefined8 uStack_48;
  undefined2 uStack_40;
  ulonglong uStack_38;
  
  uStack_1c0 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_438;
  if ((*(uint *)(param_1 + 0x10) & 4) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(uint *)(param_1 + 0x10) >> 0xd & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 0x158) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lStack_3b0 = param_1;
  lStack_2b0 = param_1;
  if (*(int *)(param_1 + 0x158) - 2U < 3) goto LAB_;
  lVar3 = *(longlong *)(*(longlong *)(param_1 + 0x28) + 8);
  lVar4 = *(longlong *)(lVar3 + 0x30);
  *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) & 0xfffffeff;
  if ((*(uint *)(param_1 + 0x10) & 0x10080) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lStack_3a0 = lVar4;
  lStack_348 = lVar3;
  iVar7 = func_0x(param_1,2);
  if (iVar7 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((~*(byte *)(param_1 + 0x34) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(char *)(lVar4 + 0x2050) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_48 = 0;
  uStack_40 = 0;
  if ((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar4 = *(longlong *)(param_1 + 0x20);
  uVar2 = *(ushort *)(lVar4 + 4);
  if ((*(uint *)(_DAT_ + 0x2c) >> 5 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(short *)(lVar4 + 0x24) != 0) {
    cVar1 = *(char *)(lVar4 + 1);
    if (cVar1 == '\v') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((cVar1 == '\b') || (cVar1 == '\t')) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  uStack_398 = *(undefined8 *)(lVar4 + 0x28);
  uStack_390 = *(undefined2 *)(lVar4 + 0x30);
  psVar5 = *(short **)(param_1 + 0x148);
  lStack_3d0 = *(longlong *)(*(longlong *)(param_1 + 0xf8) + 0x18);
  uStack_3c8 = *(undefined8 *)(param_1 + 0x150);
  lStack_3b8 = *(longlong *)(lVar3 + 0x30);
  uStack_3d8 = *(undefined *)(lStack_3b8 + 0x1cde);
  if (*(char *)(lStack_3b8 + 0x2050) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  func_0x(psVar5,param_1 + 0x48);
  *(undefined4 *)(param_1 + 0x158) = 1;
  if ((uVar2 & 0x2000) == 0) {
    if ((DAT_ & 8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar3 = *(longlong *)
             ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar3 != 0) && (**(longlong **)(lVar3 + 0x38) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
LAB_:
    if ((DAT_ & 8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar3 = *(longlong *)
             ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar3 != 0) && (**(longlong **)(lVar3 + 0x38) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  else {
    if (*(char *)(*(longlong *)(lVar3 + 0x30) + 0x1ad8) == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    puVar6 = *(uint **)(*(longlong *)(*(longlong *)(lVar3 + 0x30) + 0x6b0) + 0x2c0);
    if (*(short *)((longlong)puVar6 + 10) == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((uint)uStack_398 <= *puVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*psVar5 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (((**(byte **)(psVar5 + 4) >> 6 & 1) == 0) ||
       ((func_0x(psVar5 + 1,&iStack_376), sStack_372 == 0 && (iStack_376 == 0))))
    goto LAB_;
    if ((lStack_3d0 != 0) && ((*(byte *)(lStack_3d0 + 0x10) & 0x20) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uStack_3e0 = 0;
    puStack_3f0 = &uStack_48;
    if (*(short *)(param_1 + 0x48) == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uStack_3e8 = 0;
    uStack_3f8 = 0;
    uStack_400 = 0;
    uStack_408 = 0;
    lStack_410 = param_1 + 0x158;
    psStack_418 = psVar5;
    func_0x(uStack_3c8,0x1f9e,lVar3,lStack_3d0);
  }
  if (*(int *)(param_1 + 0x158) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
LAB_:
  func_0x(uStack_38 ^ (ulonglong)auStack_438);
  return;
}

