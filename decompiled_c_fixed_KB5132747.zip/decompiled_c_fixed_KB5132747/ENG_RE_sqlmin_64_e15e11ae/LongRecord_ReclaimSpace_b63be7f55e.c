
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,short *param_3,uint param_4,
                 undefined4 *param_5)

{
  ushort *puVar1;
  uint6 uVar2;
  byte bVar3;
  char cVar4;
  ushort uVar5;
  uint uVar6;
  int iVar7;
  uint6 *puVar8;
  longlong lVar9;
  undefined8 uVar10;
  int *piVar11;
  byte bVar12;
  uint uVar13;
  longlong lVar14;
  ushort uVar15;
  ushort uVar16;
  ulonglong uVar17;
  uint uVar18;
  uint uVar19;
  ulonglong uVar20;
  uint6 *puVar21;
  ulonglong uVar22;
  byte *pbVar23;
  int iVar24;
  ulonglong uVar25;
  int iVar26;
  ushort *puVar27;
  undefined8 in_stack_ffffffffffffff88;
  undefined4 uVar28;
  uint uStack_68;
  int iStack_64;
  longlong lStack_60;
  undefined auStack_58 [8];
  longlong lStack_50;
  int iStack_48;
  undefined2 uStack_44;
  ushort uStack_42;
  undefined8 uStack_40;
  
  uVar18 = 0;
  iStack_48 = 0;
  uStack_42 = uStack_42 & 0xffe0;
  uStack_44 = 0;
  *param_5 = 0;
  uStack_40 = 0;
  iStack_64 = -1;
  if ((param_4 & 0xd0) != 0) {
    if (*param_3 == 0) {
      uVar6 = func_0x(param_3 + 1);
    }
    else {
      uVar6 = (uint)(ushort)param_3[1];
    }
    if (0 < (int)uVar6) {
      do {
        uVar19 = ~uVar18;
        if ((uVar19 & 0xc0000000) == 0x80000000) {
          puVar8 = (uint6 *)func_0x
                                      (**(undefined8 **)(*(longlong *)(param_1 + 8) + 0x160),
                                       uVar19 & 0x1fffffff);
        }
        else {
          puVar8 = (uint6 *)func_0x
                                      (*(undefined8 *)(*(longlong *)(param_1 + 8) + 0x160));
        }
        uVar28 = (undefined4)((ulonglong)in_stack_ffffffffffffff88 >> 0x20);
        if (puVar8 == (uint6 *)0x0) {
          func_0x(param_1,uVar19,&iStack_48);
LAB_:
          in_stack_ffffffffffffff88 = CONCAT44(uVar28,param_4);
          func_0x(param_1,param_2,&iStack_48,param_3,in_stack_ffffffffffffff88,param_5);
        }
        else {
          iStack_48 = *(int *)puVar8;
          uVar2 = *puVar8;
          uStack_40 = *(undefined8 *)(puVar8 + 1);
          uStack_44 = (undefined2)*(int *)((longlong)puVar8 + 4);
          uStack_42 = (ushort)((uint)*(int *)((longlong)puVar8 + 4) >> 0x10);
          if ((*(byte *)(puVar8 + 4) & 0x40) != 0) {
            if (*param_3 == 0) {
              pbVar23 = *(byte **)(param_3 + 4);
              if ((*pbVar23 & 0x10) == 0) {
                if ((1 << (*pbVar23 & 0xe) & 0x1105U) == 0) {
                  uVar19 = 0;
                }
                else {
LAB_:
                  uVar19 = ~(uint)(((ulonglong)uStack_42 << 0x30) >> 0x34) & 1;
                }
              }
              else {
                uVar19 = *(uint *)(param_3 + 8);
                if ((int)uVar19 <= iStack_48) goto LAB_;
                uVar13 = (uint)(ushort)(*puVar8 >> 0x20);
                if (*(ushort *)(pbVar23 + uVar19) < uVar13) {
                  uVar19 = ~(uint)(CONCAT26(uStack_42,*puVar8) >> 0x34) & 1;
                }
                else {
                  uVar13 = uVar13 - 1;
                  uVar19 = pbVar23[(ulonglong)(uVar13 >> 3) + (ulonglong)uVar19 + 2] >>
                           ((byte)uVar13 & 7) & 1;
                }
              }
            }
            else {
              uVar19 = (uint)(CONCAT26(uStack_42,uVar2) >> 0x20);
              if ((ushort)param_3[1] < (ushort)(uVar2 >> 0x20)) {
                uVar19 = ~(uVar19 >> 0x14) & 1;
              }
              else {
                bVar3 = *(byte *)((longlong)((int)((uVar19 & 0xffff) - 1) / 2) +
                                  (ulonglong)(ushort)param_3[0xc] + *(longlong *)(param_3 + 4));
                bVar12 = bVar3 >> 4;
                if ((uVar2 & 0x100000000) != 0) {
                  bVar12 = bVar3 & 0xf;
                }
                uVar19 = (uint)(bVar12 == 0);
              }
            }
            if (uVar19 != 0) goto LAB_;
          }
        }
        uVar18 = uVar18 + 1;
      } while ((int)uVar18 < (int)uVar6);
    }
    uStack_68 = 0;
    iVar7 = func_0x(param_3);
    lStack_50 = (longlong)iVar7;
    if (0 < lStack_50) {
      lStack_60 = 0;
      do {
        iVar7 = 0;
        if (*(int *)(param_3 + 2) == 0) {
          pbVar23 = *(byte **)(param_3 + 4);
          uVar18 = *(uint *)(param_3 + 8);
          uVar17 = (ulonglong)uVar18;
          param_3[1] = 0;
          *(uint *)(param_3 + 10) = uVar18;
          bVar3 = *pbVar23;
          if ((bVar3 & 0x10) != 0) {
            uVar18 = uVar18 + 2 + (*(ushort *)(pbVar23 + uVar17) + 7 >> 3);
            uVar17 = (ulonglong)uVar18;
            *(uint *)(param_3 + 10) = uVar18;
            bVar3 = *pbVar23;
          }
          if ((bVar3 & 0x20) == 0) {
            *(int *)(param_3 + 2) = (int)uVar17;
            param_3[0xe] = 0;
            *(int *)(param_3 + 0xc) = (int)uVar17;
          }
          else {
            puVar27 = (ushort *)(pbVar23 + uVar17);
            uVar5 = *puVar27;
            param_3[0xe] = uVar5;
            if (uVar5 == 0) {
              cVar4 = func_0x(0x11c0aa0);
              if (((cVar4 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
                 (*(char *)(lVar9 + 0x499) != '\0')) {
                cVar4 = func_0x(0x11c0aa0);
                if (cVar4 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  (*_DAT_)(1,0xab04ac,0xbd0598,0x80f,0);
                }
              }
              func_0x(*(undefined8 *)(param_3 + 4),3);
              uVar17 = (ulonglong)*(uint *)(param_3 + 10);
              uVar5 = param_3[0xe];
            }
            uVar18 = (int)uVar17 + (uVar5 + 1) * 2;
            *(uint *)(param_3 + 0xc) = uVar18;
            if (0x1f9e < uVar18) {
              cVar4 = func_0x(0x11c0aa0);
              if (((cVar4 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
                 (*(char *)(lVar9 + 0x499) != '\0')) {
                cVar4 = func_0x(0x11c0aa0);
                if (cVar4 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0xab04ac,0xbd0598,0x816,0);
                }
              }
              func_0x(*(undefined8 *)(param_3 + 4),4);
              uVar5 = param_3[0xe];
              uVar18 = *(uint *)(param_3 + 0xc);
            }
            uVar17 = (ulonglong)uVar5;
            uVar5 = puVar27[uVar17];
            *(uint *)(param_3 + 2) = uVar5 & 0x7fff;
            if ((uVar5 & 0x7fff) < uVar18) {
              cVar4 = func_0x(0x11c0aa0);
              if (((cVar4 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
                 (*(char *)(lVar9 + 0x499) != '\0')) {
                cVar4 = func_0x(0x11c0aa0);
                if (cVar4 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0xab04ac,0xbd0598,0x81d,0);
                }
              }
              func_0x(*(undefined8 *)(param_3 + 4),4);
              uVar18 = *(uint *)(param_3 + 0xc);
              uVar17 = (ulonglong)(ushort)param_3[0xe];
            }
            puVar1 = puVar27;
            if ((short)uVar17 != 0) {
              do {
                uVar6 = puVar1[1] & 0x7fff;
                if ((uVar6 < uVar18) || (*(uint *)(param_3 + 2) < uVar6)) {
                  cVar4 = func_0x(0x11c0aa0);
                  if ((cVar4 != '\0') &&
                     ((lVar9 = func_0x(), lVar9 != 0 &&
                      (*(char *)(lVar9 + 0x499) != '\0')))) {
                    cVar4 = func_0x(0x11c0aa0);
                    if (cVar4 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      (*_DAT_)(1,0xab04ac,0xbd0598,0x82a,0);
                    }
                  }
                  func_0x(*(undefined8 *)(param_3 + 4),4);
                }
                uVar17 = (ulonglong)(ushort)param_3[0xe];
                iVar7 = iVar7 + 1;
                puVar1 = puVar1 + 1;
                uVar18 = uVar6;
              } while (iVar7 < (int)(uint)(ushort)param_3[0xe]);
            }
            if ((short)puVar27[(ulonglong)((int)uVar17 - 1) + 1] < 0) {
              pbVar23 = *(byte **)(param_3 + 4);
              do {
                uVar18 = *(ushort *)(pbVar23 + uVar17 * 2 + (ulonglong)*(uint *)(param_3 + 10)) &
                         0x7fff;
                if ((int)uVar17 == 1) {
                  uVar6 = *(uint *)(param_3 + 0xc);
                  uVar20 = (ulonglong)uVar6;
LAB_:
                  if ((uVar18 < (uint)uVar20) || (*(uint *)(param_3 + 2) < uVar18))
                  goto LAB_;
                }
                else {
                  uVar6 = *(uint *)(param_3 + 0xc);
                  uVar20 = (ulonglong)
                           (*(ushort *)
                             (pbVar23 + uVar17 * 2 + ((ulonglong)*(uint *)(param_3 + 10) - 2)) &
                           0x7fff);
                  if (uVar6 <= (*(ushort *)
                                 (pbVar23 + uVar17 * 2 + ((ulonglong)*(uint *)(param_3 + 10) - 2)) &
                               0x7fff)) goto LAB_;
LAB_:
                  func_0x(pbVar23,7);
                  uVar6 = *(uint *)(param_3 + 0xc);
                }
                uVar19 = (uint)uVar20;
                if ((uVar19 < uVar6) || (*(uint *)(param_3 + 2) < uVar19)) goto LAB_;
                pbVar23 = *(byte **)(param_3 + 4);
                if (*(ushort *)(pbVar23 + uVar20) == 5) {
                  param_3[1] = param_3[1] | 2;
                  param_3[0xe] = param_3[0xe] + -1;
                  uVar22 = uVar20 & 0xffff;
                  param_3[0x15] = (short)uVar20;
                  uVar17 = *(ulonglong *)(param_3 + 4);
                  uVar5 = param_3[0x16] & 0xc7ffU;
                  if ((*(ushort *)(uVar22 + 2 + uVar17) >> 0xe & 1) != 0) {
                    uVar5 = *(ushort *)(uVar22 + 2 + uVar17) & 0x3800 | param_3[0x16] & 0xc7ffU;
                  }
                  param_3[0x16] = uVar5;
                  uVar25 = (ulonglong)(ushort)param_3[0x15];
                  uVar16 = (uVar5 ^ *(ushort *)(uVar22 + 2 + uVar17)) & 0x7ff ^ uVar5;
                  param_3[0x16] = uVar16;
                  uVar20 = uVar25 + 4 +
                           (ulonglong)((uVar16 & 0x7ff) * 2) + uVar17 + (uVar5 >> 0xb & 7) * 2;
                  if (uVar20 < uVar25 + uVar17) {
                    func_0x(uVar25 + uVar17,0x19);
                    uVar16 = param_3[0x16];
                    uVar25 = (ulonglong)(ushort)param_3[0x15];
                    uVar17 = (ulonglong)*(uint *)(param_3 + 4);
                  }
                  if (uVar18 - uVar19 <
                      (((uVar16 & 0x7ff) * 2 - (int)uVar25) - (int)uVar17) + (int)uVar20) {
                    func_0x(uVar25 + *(longlong *)(param_3 + 4),0x19);
                    uVar16 = param_3[0x16];
                  }
                  if ((uVar16 & 0x3800) != 0) {
                    puVar27 = (ushort *)
                              (*(longlong *)(param_3 + 4) + (ulonglong)(ushort)param_3[0x15] + 4);
                    iVar7 = 0;
                    if ((uVar16 & 0x3800) != 0) {
                      do {
                        if ((uVar16 & 0x7ff) < (*puVar27 & 0x7ff)) {
                          func_0x((ulonglong)(ushort)param_3[0x15] +
                                          *(longlong *)(param_3 + 4),0x1a);
                          uVar16 = param_3[0x16];
                        }
                        iVar7 = iVar7 + 1;
                        puVar27 = puVar27 + 1;
                      } while (iVar7 < (int)(uVar16 >> 0xb & 7));
                    }
                  }
                  goto LAB_;
                }
                if (*(ushort *)(pbVar23 + uVar20) < 0x400) goto LAB_;
                param_3[1] = param_3[1] | 1;
                uVar5 = param_3[0xe] - 1;
                param_3[0xe] = uVar5;
                if (uVar5 == 0) goto LAB_;
                uVar17 = (ulonglong)uVar5;
              } while ((short)puVar27[(ulonglong)(uVar5 - 1) + 1] < 0);
              uVar17 = (ulonglong)*(uint *)(param_3 + 2);
            }
            else {
LAB_:
              pbVar23 = *(byte **)(param_3 + 4);
              uVar17 = (ulonglong)*(uint *)(param_3 + 2);
            }
          }
          if ((*pbVar23 & 0x40) == 0) {
            *(undefined4 *)(param_3 + 0x13) = 0;
          }
          else {
            *(int *)(param_3 + 0x13) = (int)uVar17;
            *(int *)(param_3 + 2) = (int)uVar17 + 0xe;
            uVar10 = func_0x(param_3 + 1);
            func_0x(uVar10,auStack_58);
            iVar7 = func_0x(auStack_58);
            *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + iVar7;
            uVar17 = (ulonglong)*(uint *)(param_3 + 2);
          }
          iVar7 = (int)uVar17;
          if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
             (*(ulonglong *)(param_3 + 0xf) < uVar17 + *(longlong *)(param_3 + 4))) {
            cVar4 = func_0x(0x11c0aa0);
            if ((cVar4 != '\0') &&
               ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')
                ))) {
              cVar4 = func_0x(0x11c0aa0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                (*_DAT_)(1,0xab04ac,0xbd0598,0x886,0);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 4),0x12);
            iVar7 = *(int *)(param_3 + 2);
          }
          if (0x3f3b < iVar7 - 1U) {
            cVar4 = func_0x(0x11c0aa0);
            if (((cVar4 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
               (*(char *)(lVar9 + 0x499) != '\0')) {
              cVar4 = func_0x(0x11c0aa0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                (*_DAT_)(1,0xab04ac,0xbd0598,0x88b,0);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 4),5);
          }
        }
LAB_:
        iVar7 = func_0x(param_3 + 1);
        if (iVar7 == 0) {
          iVar7 = func_0x(param_3 + 1);
          if (iVar7 == 0) {
            (*_DAT_)(1,0xc6c1c8,0xc5d258,0xd7a,0);
          }
        }
        else {
          uVar5 = param_3[0x16];
          if (uStack_68 < (uVar5 & 0x7ff)) {
            lVar14 = 0;
            uVar16 = 0;
            lVar9 = *(longlong *)(param_3 + 4) + (ulonglong)(ushort)param_3[0x15];
            if ((uVar5 & 0x3800) == 0) {
              uVar15 = *(ushort *)(lVar9 + 2);
LAB_:
              uVar16 = uVar15 >> 0xb & 7;
            }
            else if ((uVar5 >> 0xb & 7) != 0) {
              do {
                if (((lVar14 == 0) || ((*(ushort *)(lVar9 + 2 + lVar14 * 2) & 0x7ff) <= uStack_68))
                   && (uVar15 = *(ushort *)(lVar9 + 4 + lVar14 * 2),
                      (int)uStack_68 <= (int)((uVar15 & 0x7ff) - 1))) goto LAB_;
                lVar14 = lVar14 + 1;
              } while (lVar14 < (longlong)(ulonglong)(uVar5 >> 0xb & 7));
            }
            iStack_64 = (uint)*(ushort *)
                               ((ulonglong)((uVar5 >> 0xb & 7) * 2) + *(longlong *)(param_3 + 4) +
                                lStack_60 * 2 + 4 + (ulonglong)(ushort)param_3[0x15]) +
                        (uint)uVar16 * 0x10000;
          }
          else {
            (*_DAT_)(1,0xc6c198,0xc6c160,0x41a,0);
          }
        }
        piVar11 = (int *)func_0x
                                   (**(undefined8 **)(*(longlong *)(param_1 + 8) + 0x160),iStack_64)
        ;
        iStack_48 = *piVar11;
        uStack_40 = *(undefined8 *)(piVar11 + 2);
        uStack_44 = (undefined2)piVar11[1];
        uStack_42 = (ushort)((uint)piVar11[1] >> 0x10);
        if ((*(byte *)(piVar11 + 8) & 0x10) != 0) {
          func_0x(param_1,param_2,&iStack_48,param_3,param_4,param_5);
        }
        uStack_68 = uStack_68 + 1;
        lStack_60 = lStack_60 + 1;
      } while (lStack_60 < lStack_50);
    }
  }
  puVar8 = (uint6 *)0x0;
  if (((param_4 & 2) != 0) &&
     (lVar9 = *(longlong *)(param_1 + 8), puVar21 = puVar8,
     0 < *(int *)(**(longlong **)(lVar9 + 0x160) + 0x14))) {
    do {
      uVar10 = 0xffff;
      iVar7 = *(int *)(**(longlong **)(lVar9 + 0x160) + 0x14);
      if (iVar7 != 0) {
        if (puVar8 == (uint6 *)0x0) {
          iVar24 = 0;
        }
        else {
          iVar24 = *(int *)puVar8;
        }
        iVar24 = iVar24 + -1;
        iVar26 = -iVar24;
        if (iVar26 <= iVar7) {
          do {
            puVar8 = (uint6 *)func_0x(*(undefined8 *)(lVar9 + 0x160),iVar24);
            if ((puVar8 != (uint6 *)0x0) && ((*(byte *)(puVar8 + 4) & 0x10) == 0)) {
              if ((*(short *)(puVar8 + 7) == (short)uVar10) ||
                 (*(char *)((ulonglong)
                            *(byte *)((ulonglong)*(byte *)((longlong)puVar8 + 0x34) + 0x835760) +
                           0x11ec7f8) != '\0')) {
                iStack_48 = *(int *)puVar8;
                uVar2 = *puVar8;
                uStack_40 = *(undefined8 *)(puVar8 + 1);
                uStack_44 = (undefined2)*(int *)((longlong)puVar8 + 4);
                uStack_42 = (ushort)((uint)*(int *)((longlong)puVar8 + 4) >> 0x10);
                if ((*(byte *)(puVar8 + 4) & 0x40) != 0) {
                  if (*param_3 == 0) {
                    pbVar23 = *(byte **)(param_3 + 4);
                    if ((*pbVar23 & 0x10) == 0) {
                      if ((1 << (*pbVar23 & 0xe) & 0x1105U) == 0) {
                        uVar18 = 0;
                      }
                      else {
LAB_:
                        uVar18 = ~(uint)(((ulonglong)uStack_42 << 0x30) >> 0x34) & 1;
                      }
                    }
                    else {
                      uVar18 = *(uint *)(param_3 + 8);
                      if ((int)uVar18 <= iStack_48) goto LAB_;
                      uVar6 = (uint)(ushort)(*puVar8 >> 0x20);
                      if (*(ushort *)(pbVar23 + uVar18) < uVar6) {
                        uVar18 = ~(uint)(CONCAT26(uStack_42,*puVar8) >> 0x34) & 1;
                      }
                      else {
                        uVar6 = uVar6 - 1;
                        uVar18 = pbVar23[(ulonglong)uVar18 + (ulonglong)(uVar6 >> 3) + 2] >>
                                 ((byte)uVar6 & 7) & 1;
                      }
                    }
                  }
                  else {
                    uVar18 = (uint)(CONCAT26(uStack_42,uVar2) >> 0x20);
                    if ((ushort)param_3[1] < (ushort)(uVar2 >> 0x20)) {
                      uVar18 = ~(uVar18 >> 0x14) & 1;
                    }
                    else {
                      bVar3 = *(byte *)((longlong)((int)((uVar18 & 0xffff) - 1) / 2) +
                                        (ulonglong)(ushort)param_3[0xc] + *(longlong *)(param_3 + 4)
                                       );
                      bVar12 = bVar3 >> 4;
                      if ((uVar2 & 0x100000000) != 0) {
                        bVar12 = bVar3 & 0xf;
                      }
                      uVar18 = (uint)(bVar12 == 0);
                    }
                  }
                  if ((uVar18 != 0) &&
                     (iVar7 = func_0x(param_3,&iStack_48), iVar7 != 0)) {
                    func_0x(param_2,param_3,&iStack_48);
                    *param_5 = 1;
                  }
                }
              }
              goto LAB_;
            }
            lVar9 = *(longlong *)(param_1 + 8);
            iVar24 = iVar24 + -1;
            iVar26 = iVar26 + 1;
          } while (iVar26 <= *(int *)(**(longlong **)(lVar9 + 0x160) + 0x14));
        }
      }
      puVar8 = (uint6 *)0x0;
LAB_:
      lVar9 = *(longlong *)(param_1 + 8);
      uVar18 = (int)puVar21 + 1;
      puVar21 = (uint6 *)(ulonglong)uVar18;
    } while ((int)uVar18 < *(int *)(**(longlong **)(lVar9 + 0x160) + 0x14));
  }
  return;
}

