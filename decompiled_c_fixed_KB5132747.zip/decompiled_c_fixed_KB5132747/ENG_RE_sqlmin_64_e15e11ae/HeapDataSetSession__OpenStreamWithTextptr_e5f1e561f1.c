
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined8 param_2,int param_3,longlong param_4,
                 ulonglong param_5,uint param_6,longlong *param_7)

{
  ushort *puVar1;
  byte *pbVar2;
  longlong *plVar3;
  code *pcVar4;
  ushort *puVar5;
  byte bVar6;
  char cVar7;
  ushort uVar8;
  ushort uVar9;
  int iVar10;
  int iVar11;
  longlong lVar12;
  uint *puVar13;
  short *psVar14;
  longlong lVar15;
  uint *puVar16;
  undefined8 uVar17;
  longlong lVar18;
  uint *puVar19;
  ulonglong uVar20;
  short sVar21;
  undefined *puVar22;
  undefined *puVar23;
  uint uVar24;
  uint *puVar25;
  ulonglong uVar26;
  longlong lVar27;
  ulonglong uVar28;
  ushort *puVar29;
  longlong *plVar30;
  uint uVar31;
  uint uVar32;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_190;
  undefined auStack_188 [32];
  uint *puStack_168;
  undefined4 auStack_160 [2];
  uint *puStack_158;
  uint auStack_150 [10];
  uint uStack_128;
  uint uStack_124;
  uint uStack_120;
  undefined4 uStack_11c;
  longlong *plStack_118;
  int iStack_110;
  undefined4 uStack_10c;
  undefined2 uStack_108;
  undefined4 uStack_f8;
  undefined2 uStack_f4;
  longlong *plStack_e8;
  undefined auStack_e0 [8];
  short *psStack_d8;
  longlong lStack_d0;
  longlong *plStack_c8;
  ulonglong uStack_c0;
  longlong lStack_b8;
  longlong *plStack_b0;
  longlong *plStack_a8;
  undefined8 uStack_a0;
  longlong lStack_98;
  longlong *plStack_90;
  undefined8 uStack_78;
  undefined auStack_70 [32];
  undefined auStack_50 [16];
  ulonglong uStack_40;
  
  puVar23 = auStack_188;
  uStack_78 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)&uStack_128;
  plStack_a8 = param_7;
  plStack_90 = param_7;
  uStack_124 = param_6;
  uStack_120 = param_6;
  uStack_11c = 0x80004005;
  iVar10 = 0;
  plStack_118 = (longlong *)0x0;
  lVar15 = *(longlong *)param_1[0x5c];
  plVar30 = (longlong *)((longlong *)param_1[0x5c])[1];
  *param_7 = 0;
  puVar22 = auStack_188;
  plStack_c8 = plVar30;
  lStack_b8 = lVar15;
  plStack_b0 = param_1;
  uStack_a0 = param_2;
  if ((param_4 == 0) || (puVar22 = auStack_188, param_3 != 0x10)) goto LAB_;
  lVar12 = *(longlong *)(lVar15 + 8);
  if (*(longlong *)(lVar12 + 0x478) != 0) {
    lVar12 = *(longlong *)(lVar12 + 0x478);
  }
  if ((*(byte *)(lVar12 + 0x474) & 1) == 0) {
    puStack_168 = (uint *)auStack_50;
    uStack_190 = 0x100c5e;
    iVar11 = func_0x(lVar15,param_5 & 0xffffffff,0x10);
    puVar22 = auStack_188;
    if (iVar11 == 0) goto LAB_;
    uStack_128 = 0x10;
    puVar22 = auStack_50;
    uVar31 = uStack_120;
  }
  else {
    uStack_190 = 0x1000e1;
    iVar10 = func_0x(lVar15,plVar30);
    puVar22 = auStack_188;
    if (iVar10 == 0) goto LAB_;
    iStack_110 = (int)*(short *)(param_4 + 2);
    uStack_190 = 0x100105;
    lVar12 = (**(code **)(*plVar30 + 0xe0))(plVar30,iStack_110,auStack_70);
    puVar22 = auStack_188;
    lStack_d0 = lVar12;
    if (((*(byte *)(lVar12 + 4) & 2) != 0) ||
       (uStack_c0 = param_5, puVar22 = auStack_188,
       param_5 != *(uint *)(*(longlong *)(lVar12 + 8) + 4))) goto LAB_;
    uStack_190 = 0x100143;
    puVar13 = (uint *)func_0x
                                (*(undefined8 *)(*(longlong *)(lVar15 + 8) + 0x160),
                                 param_5 & 0xffffffff);
    uStack_190 = 0x10015f;
    (**(code **)(*param_1 + 0x80))(param_1,*(longlong *)(lVar12 + 8) + 0xc,&plStack_118);
    plStack_e8 = plStack_118;
    if (plStack_118 == (longlong *)0x0) {
      puStack_168 = (uint *)0x0;
      uStack_190 = 0x100190;
      (*_DAT_)(1,0x1964c30,0x1938528,0xcb1);
    }
    plVar30 = plStack_118;
    puVar25 = (uint *)0x0;
    uStack_190 = 0x1001ab;
    plStack_e8 = plStack_118;
    psVar14 = (short *)func_0x(plStack_118,1);
    uStack_190 = 0x1001bc;
    psStack_d8 = psVar14;
    lVar15 = func_0x();
    lVar15 = -lVar15;
    bVar6 = *(byte *)(puVar13 + 8);
    puVar1 = (ushort *)(psVar14 + 1);
    if (*psVar14 == 0) {
      uVar31 = *puVar13;
      if ((uVar31 & 0xc0000000) == 0x80000000) {
        *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100af5;
        iVar10 = func_0x(puVar1);
        if (iVar10 != 0) {
          *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100b11;
          puVar25 = (uint *)func_0x(psVar14 + 0x15,puVar13,&uStack_128,&uStack_10c);
          goto LAB_;
        }
LAB_:
        uStack_128 = 0;
      }
      else {
        if (((bVar6 & 2) != 0) || ((*(byte *)((longlong)puVar13 + 6) & 0x10) != 0)) {
          pbVar2 = *(byte **)(psVar14 + 4);
          if ((*pbVar2 & 0x10) == 0) {
            if ((1 << (*pbVar2 & 0xe) & 0x1105U) != 0) goto LAB_;
            puVar16 = puVar25;
            puVar19 = (uint *)0x1;
LAB_:
            uVar24 = (uint)puVar16;
            iVar10 = (int)puVar19;
            if ((bVar6 & 2) != 0) goto LAB_;
          }
          else {
            uVar24 = *(uint *)(psVar14 + 8);
            if ((int)uVar24 <= (int)uVar31) {
LAB_:
              puVar16 = (uint *)(ulonglong)(~(uint)(*(ushort *)((longlong)puVar13 + 6) >> 4) & 1);
              puVar19 = puVar25;
              goto LAB_;
            }
            if ((uint)*(ushort *)(pbVar2 + uVar24) < (uint)*(ushort *)(puVar13 + 1))
            goto LAB_;
            if ((bVar6 & 2) == 0) goto LAB_;
            uVar32 = *(ushort *)(puVar13 + 1) - 1;
            uVar24 = pbVar2[(ulonglong)(uVar32 >> 3) + (ulonglong)uVar24 + 2] >> ((byte)uVar32 & 7)
                     & 1;
            iVar10 = 1;
LAB_:
            if (uVar24 != 0) goto LAB_;
          }
          if ((iVar10 == 0) && ((*(byte *)((longlong)puVar13 + 6) & 0x10) != 0)) {
            puVar25 = *(uint **)(puVar13 + 2) + 1;
            uStack_128 = **(uint **)(puVar13 + 2);
            goto LAB_;
          }
        }
LAB_:
        if ((int)uVar31 < 0) {
          if (*(int *)(psVar14 + 2) == 0) {
            *puVar1 = 0;
            uVar31 = *(uint *)(psVar14 + 8);
            uVar20 = (ulonglong)uVar31;
            *(uint *)(psVar14 + 10) = uVar31;
            pbVar2 = *(byte **)(psVar14 + 4);
            bVar6 = *pbVar2;
            if ((bVar6 & 0x10) != 0) {
              uVar31 = uVar31 + (*(ushort *)(pbVar2 + uVar20) + 7 >> 3) + 2;
              uVar20 = (ulonglong)uVar31;
              *(uint *)(psVar14 + 10) = uVar31;
              bVar6 = *pbVar2;
            }
            if ((bVar6 & 0x20) == 0) {
              *(int *)(psVar14 + 2) = (int)uVar20;
              psVar14[0xe] = 0;
              *(int *)(psVar14 + 0xc) = (int)uVar20;
            }
            else {
              puVar29 = (ushort *)(pbVar2 + uVar20);
              uVar8 = *puVar29;
              psVar14[0xe] = uVar8;
              if (uVar8 == 0) {
                *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1003e4;
                cVar7 = func_0x(0x1ec4190);
                if (cVar7 != '\0') {
                  *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1003ed;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100407;
                    cVar7 = func_0x(0x1ec4190);
                    if (cVar7 == '\0') {
                      *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100423;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)((longlong)auStack_160 + lVar15 + -8) = 0;
                      *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100449;
                      (*_DAT_)(1,0x17b3b9c,0x18d3c88,0x80f);
                    }
                  }
                }
                uVar17 = *(undefined8 *)(psVar14 + 4);
                *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100457;
                func_0x(uVar17,3);
                uVar8 = psVar14[0xe];
                uVar20 = (ulonglong)*(uint *)(psVar14 + 10);
              }
              uVar31 = (int)uVar20 + (uVar8 + 1) * 2;
              *(uint *)(psVar14 + 0xc) = uVar31;
              if (0x1f9e < uVar31) {
                *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100487;
                cVar7 = func_0x(0x1ec4190);
                if (cVar7 != '\0') {
                  *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100490;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1004aa;
                    cVar7 = func_0x(0x1ec4190);
                    if (cVar7 == '\0') {
                      *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1004c6;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)((longlong)auStack_160 + lVar15 + -8) = 0;
                      *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1004ec;
                      (*_DAT_)(1,0x17b3b9c,0x18d3c88,0x816);
                    }
                  }
                }
                uVar17 = *(undefined8 *)(psVar14 + 4);
                *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1004fa;
                func_0x(uVar17,4);
                uVar8 = psVar14[0xe];
                uVar31 = *(uint *)(psVar14 + 0xc);
              }
              uVar20 = (ulonglong)uVar8;
              uVar8 = puVar29[uVar20];
              *(uint *)(psVar14 + 2) = uVar8 & 0x7fff;
              if ((uVar8 & 0x7fff) < uVar31) {
                *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100528;
                cVar7 = func_0x(0x1ec4190);
                if (cVar7 != '\0') {
                  *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100531;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x10054b;
                    cVar7 = func_0x(0x1ec4190);
                    if (cVar7 == '\0') {
                      *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100567;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)((longlong)auStack_160 + lVar15 + -8) = 0;
                      *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x10058d;
                      (*_DAT_)(1,0x17b3b9c,0x18d3c88,0x81d);
                    }
                  }
                }
                uVar17 = *(undefined8 *)(psVar14 + 4);
                *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x10059b;
                func_0x(uVar17,4);
                uVar31 = *(uint *)(psVar14 + 0xc);
                uVar20 = (ulonglong)(ushort)psVar14[0xe];
              }
              puVar5 = puVar29;
              if ((short)uVar20 != 0) {
                do {
                  uVar24 = puVar5[1] & 0x7fff;
                  if ((uVar24 < uVar31) || (*(uint *)(psVar14 + 2) < uVar24)) {
                    *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1005df;
                    cVar7 = func_0x(0x1ec4190);
                    if (cVar7 != '\0') {
                      *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1005e8;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100602;
                        cVar7 = func_0x(0x1ec4190);
                        if (cVar7 == '\0') {
                          *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x10061e;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)((longlong)auStack_160 + lVar15 + -8) = 0;
                          *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100644;
                          (*_DAT_)(1,0x17b3b9c,0x18d3c88,0x82a);
                        }
                      }
                    }
                    uVar17 = *(undefined8 *)(psVar14 + 4);
                    *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100652;
                    func_0x(uVar17,4);
                  }
                  uVar32 = (int)puVar25 + 1;
                  puVar25 = (uint *)(ulonglong)uVar32;
                  uVar20 = (ulonglong)(ushort)psVar14[0xe];
                  param_6 = uStack_124;
                  puVar5 = puVar5 + 1;
                  uVar31 = uVar24;
                } while ((int)uVar32 < (int)(uint)(ushort)psVar14[0xe]);
              }
              if ((short)puVar29[(ulonglong)((int)uVar20 - 1) + 1] < 0) {
                lVar12 = *(longlong *)(psVar14 + 4);
                do {
                  uVar31 = *(ushort *)((ulonglong)*(uint *)(psVar14 + 10) + lVar12 + uVar20 * 2) &
                           0x7fff;
                  if ((int)uVar20 == 1) {
                    uVar24 = *(uint *)(psVar14 + 0xc);
                    uVar20 = (ulonglong)uVar24;
LAB_:
                    if ((uVar31 < (uint)uVar20) || (*(uint *)(psVar14 + 2) < uVar31))
                    goto LAB_;
                  }
                  else {
                    uVar32 = *(ushort *)
                              ((ulonglong)*(uint *)(psVar14 + 10) + lVar12 + -2 + uVar20 * 2) &
                             0x7fff;
                    uVar20 = (ulonglong)uVar32;
                    uVar24 = *(uint *)(psVar14 + 0xc);
                    if (uVar24 <= uVar32) goto LAB_;
LAB_:
                    *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1006d7;
                    func_0x(lVar12,7);
                    uVar24 = *(uint *)(psVar14 + 0xc);
                  }
                  uVar32 = (uint)uVar20;
                  if ((uVar32 < uVar24) || (*(uint *)(psVar14 + 2) < uVar32)) goto LAB_;
                  lVar12 = *(longlong *)(psVar14 + 4);
                  if (*(ushort *)(uVar20 + lVar12) == 5) {
                    *puVar1 = *puVar1 | 2;
                    psVar14[0xe] = psVar14[0xe] + -1;
                    uVar28 = uVar20 & 0xffff;
                    psVar14[0x15] = (short)uVar20;
                    uVar8 = *(ushort *)(uVar28 + 2 + lVar12);
                    uVar9 = psVar14[0x16] & 0xc7ff;
                    if ((uVar8 >> 0xe & 1) != 0) {
                      uVar9 = uVar8 & 0x3800 | uVar9;
                    }
                    psVar14[0x16] = uVar9;
                    uVar8 = (uVar9 ^ *(ushort *)(uVar28 + 2 + lVar12)) & 0x7ff ^ uVar9;
                    psVar14[0x16] = uVar8;
                    uVar20 = *(ulonglong *)(psVar14 + 4);
                    uVar26 = (ulonglong)((uVar8 & 0x7ff) * 2) + 4 + uVar20 + (uVar9 >> 0xb & 7) * 2
                             + uVar28;
                    if (uVar26 < uVar28 + uVar20) {
                      *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1007dc;
                      func_0x(uVar28 + uVar20,0x19);
                      uVar8 = psVar14[0x16];
                      uVar28 = (ulonglong)(ushort)psVar14[0x15];
                      uVar20 = (ulonglong)*(uint *)(psVar14 + 4);
                    }
                    if (uVar31 - uVar32 <
                        (((uVar8 & 0x7ff) * 2 - (int)uVar28) - (int)uVar20) + (int)uVar26) {
                      lVar12 = *(longlong *)(psVar14 + 4);
                      *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100814;
                      func_0x(uVar28 + lVar12,0x19);
                      uVar8 = psVar14[0x16];
                    }
                    if ((uVar8 & 0x3800) != 0) {
                      puVar29 = (ushort *)
                                (*(longlong *)(psVar14 + 4) + (ulonglong)(ushort)psVar14[0x15] + 4);
                      iVar10 = 0;
                      if ((uVar8 & 0x3800) != 0) {
                        do {
                          if ((uVar8 & 0x7ff) < (*puVar29 & 0x7ff)) {
                            uVar8 = psVar14[0x15];
                            lVar12 = *(longlong *)(psVar14 + 4);
                            *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100867;
                            func_0x((ulonglong)uVar8 + lVar12,0x1a);
                            uVar8 = psVar14[0x16];
                          }
                          iVar10 = iVar10 + 1;
                          puVar29 = puVar29 + 1;
                        } while (iVar10 < (int)(uVar8 >> 0xb & 7));
                      }
                    }
                    goto LAB_;
                  }
                  if (*(ushort *)(uVar20 + lVar12) < 0x400) goto LAB_;
                  *puVar1 = *puVar1 | 1;
                  uVar8 = psVar14[0xe] - 1;
                  psVar14[0xe] = uVar8;
                  if (uVar8 == 0) goto LAB_;
                  uVar20 = (ulonglong)uVar8;
                } while ((short)puVar29[(ulonglong)(uVar8 - 1) + 1] < 0);
                uVar20 = (ulonglong)*(uint *)(psVar14 + 2);
              }
              else {
LAB_:
                uVar20 = (ulonglong)*(uint *)(psVar14 + 2);
              }
            }
            if ((**(byte **)(psVar14 + 4) & 0x40) == 0) {
              *(undefined4 *)(psVar14 + 0x13) = 0;
            }
            else {
              *(int *)(psVar14 + 0x13) = (int)uVar20;
              *(int *)(psVar14 + 2) = (int)uVar20 + 0xe;
              *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1008b2;
              uVar17 = func_0x(puVar1);
              *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1008be;
              func_0x(uVar17,auStack_e0);
              *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1008c7;
              iVar10 = func_0x(auStack_e0);
              *(int *)(psVar14 + 2) = *(int *)(psVar14 + 2) + iVar10;
              uVar20 = (ulonglong)*(uint *)(psVar14 + 2);
            }
            iVar10 = (int)uVar20;
            if ((*(ulonglong *)(psVar14 + 0xf) != 0) &&
               (*(ulonglong *)(psVar14 + 0xf) < uVar20 + *(longlong *)(psVar14 + 4))) {
              *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1008ff;
              cVar7 = func_0x(0x1ec4190);
              if (cVar7 != '\0') {
                *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100908;
                lVar12 = func_0x();
                if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                  *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100922;
                  cVar7 = func_0x(0x1ec4190);
                  if (cVar7 == '\0') {
                    *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x10093e;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)((longlong)auStack_160 + lVar15 + -8) = 0;
                    *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100964;
                    (*_DAT_)(1,0x17b3b9c,0x18d3c88,0x886);
                  }
                }
              }
              uVar17 = *(undefined8 *)(psVar14 + 4);
              *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100972;
              func_0x(uVar17,0x12);
              iVar10 = *(int *)(psVar14 + 2);
            }
            if (0x3f3b < iVar10 - 1U) {
              *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x10098b;
              cVar7 = func_0x(0x1ec4190);
              if (cVar7 != '\0') {
                *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100994;
                lVar12 = func_0x();
                if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                  *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1009ae;
                  cVar7 = func_0x(0x1ec4190);
                  if (cVar7 == '\0') {
                    *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1009ca;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)((longlong)auStack_160 + lVar15 + -8) = 0;
                    *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1009f0;
                    (*_DAT_)(1,0x17b3b9c,0x18d3c88,0x88b);
                  }
                }
              }
              uVar17 = *(undefined8 *)(psVar14 + 4);
              *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x1009fe;
              func_0x(uVar17,5);
            }
          }
LAB_:
          sVar21 = -*(short *)puVar13;
          plVar30 = plStack_e8;
          if ((*(byte *)((longlong)puVar13 + 6) & 0x10) != 0) {
            bVar6 = **(byte **)(psVar14 + 4);
            if ((bVar6 & 0x10) == 0) {
              if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
                puVar25 = *(uint **)(puVar13 + 2) + 1;
                psVar14 = psStack_d8;
                uStack_128 = **(uint **)(puVar13 + 2);
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(psVar14 + 8) <= (int)*puVar13) ||
                    (*(ushort *)(*(byte **)(psVar14 + 4) + *(uint *)(psVar14 + 8)) <
                     *(ushort *)(puVar13 + 1))) goto LAB_;
          }
          lVar12 = (longlong)sVar21;
          if ((uint)(ushort)psVar14[0xe] < (uint)(int)sVar21) {
            uStack_128 = 0;
            puVar25 = *(uint **)(psVar14 + 4);
            psVar14 = psStack_d8;
          }
          else {
            lVar27 = *(longlong *)(psVar14 + 4);
            lVar18 = (ulonglong)*(uint *)(psVar14 + 10) + lVar27;
            if (sVar21 == 1) {
              uVar31 = *(uint *)(psVar14 + 0xc);
              uVar24 = *(ushort *)(lVar18 + lVar12 * 2) & 0x7fff;
LAB_:
              if ((uVar24 < uVar31) || (*(uint *)(psVar14 + 2) < uVar24)) goto LAB_;
            }
            else {
              uVar31 = *(ushort *)(lVar18 + -2 + lVar12 * 2) & 0x7fff;
              uVar24 = *(ushort *)(lVar18 + lVar12 * 2) & 0x7fff;
              lVar27 = *(longlong *)(psVar14 + 4);
              if (*(uint *)(psVar14 + 0xc) <= uVar31) goto LAB_;
LAB_:
              *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100abf;
              func_0x(lVar27,7);
            }
            puVar25 = (uint *)((ulonglong)uVar31 + *(longlong *)(psVar14 + 4));
            plVar30 = plStack_e8;
            psVar14 = psStack_d8;
            uStack_128 = uVar24 - uVar31;
          }
        }
        else {
          uVar8 = *(ushort *)((longlong)puVar13 + 6);
          if ((uVar8 & 8) == 0) {
            if ((uVar8 & 0x10) != 0) {
              bVar6 = **(byte **)(psVar14 + 4);
              if ((bVar6 & 0x10) == 0) {
                if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
                  puVar25 = *(uint **)(puVar13 + 2) + 1;
                  uStack_128 = **(uint **)(puVar13 + 2);
                  if (uStack_128 != 0x1f9e) {
                    *(undefined8 *)((longlong)auStack_160 + lVar15 + -8) = 0;
                    *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x10033f;
                    (*_DAT_)(1,0x1961fe0,0x1960948,0x381);
                  }
                  goto LAB_;
                }
              }
              else if (((int)*(uint *)(psVar14 + 8) <= (int)uVar31) ||
                      (*(ushort *)(*(byte **)(psVar14 + 4) + *(uint *)(psVar14 + 8)) <
                       *(ushort *)(puVar13 + 1))) goto LAB_;
            }
            uStack_128 = 0x1f9e;
            puVar25 = (uint *)((longlong)(int)*puVar13 + *(longlong *)(psVar14 + 4));
          }
          else {
            uStack_128 = 1;
            puVar25 = (uint *)0x1538830;
            if ((*(byte *)((longlong)(int)uVar31 + *(longlong *)(psVar14 + 4)) &
                (byte)(1 << ((byte)uVar8 & 7))) == 0) {
              puVar25 = (uint *)0x1538831;
            }
          }
        }
      }
    }
    else {
      uStack_124 = 0;
      *(uint **)((longlong)auStack_160 + lVar15 + -8) = &uStack_124;
      *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100b31;
      puVar25 = (uint *)func_0x(puVar1,puVar13);
      if ((((*psVar14 != 0) && (plVar3 = *(longlong **)(psVar14 + 8), plVar3 != (longlong *)0x0)) &&
          (*plVar3 != 0)) &&
         (((*(byte *)((longlong)puVar13 + 6) & 8) == 0 && ((uStack_124 & 1) == 0)))) {
        if ((puVar25 == (uint *)0x0) || (puVar25 == (uint *)0x1538830)) {
          puVar25 = (uint *)0x0;
          uStack_128 = 0;
        }
        else {
          *(uint *)((longlong)auStack_150 + lVar15) = uStack_124;
          *(uint **)((longlong)&puStack_158 + lVar15) = &uStack_128;
          *(undefined4 *)((longlong)auStack_160 + lVar15) = 0x1f9e;
          *(longlong *)((longlong)auStack_160 + lVar15 + -8) = (longlong)&uStack_128 + lVar15;
          uVar31 = uStack_128;
          *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100b90;
          puVar25 = (uint *)func_0x(plVar3,puVar13,puVar25,uVar31);
        }
      }
    }
LAB_:
    if (puVar25 == (uint *)0x0) {
      uVar31 = param_6 | 8;
    }
    else {
      *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100bb3;
      iVar10 = func_0x(psVar14,puVar13);
      uVar31 = uStack_120;
      if (iVar10 == 0) {
        uVar31 = param_6 | 0x200;
      }
    }
    *(undefined8 *)(auStack_188 + lVar15 + -8) = 0x100be1;
    lVar12 = func_0x();
    lVar12 = -lVar12;
    puVar23 = auStack_188 + lVar12 + lVar15;
    puVar22 = (undefined *)((longlong)&uStack_128 + lVar12 + lVar15);
    *(undefined8 *)(auStack_188 + lVar12 + lVar15 + -8) = 0x100bf7;
    func_0x(puVar22);
    if (((*(byte *)(lStack_d0 + 4) & 1) == 0) &&
       ((*(uint *)(*(longlong *)(plStack_c8[6] + 0x6b0) + 0x278) & 0x1000) == 0)) {
      uVar31 = uVar31 | 0x10000;
    }
    pcVar4 = *(code **)(*plVar30 + 8);
    *(undefined8 *)(auStack_188 + lVar12 + lVar15 + -8) = 0x100c2b;
    (*pcVar4)(plVar30);
    lVar15 = lStack_b8;
    param_5 = uStack_c0;
    param_1 = plStack_b0;
    param_7 = plStack_a8;
    iVar10 = iStack_110;
  }
  uStack_10c = 0;
  uStack_108 = 0;
  uStack_f8 = 0;
  uStack_f4 = 0;
  *(undefined4 **)(puVar23 + 0x50) = &uStack_f8;
  *(int *)(puVar23 + 0x48) = iVar10;
  *(longlong **)(puVar23 + 0x40) = param_7;
  *(uint *)(puVar23 + 0x38) = uVar31 | 0x80;
  *(ulonglong *)(puVar23 + 0x30) = param_5;
  *(uint *)(puVar23 + 0x28) = uStack_128;
  *(undefined **)(puVar23 + 0x20) = puVar22;
  uVar17 = uStack_a0;
  lVar12 = param_1[0x3d];
  *(undefined8 *)(puVar23 + -8) = 0x100cd2;
  iVar10 = func_0x(param_1,uVar17,lVar12,1);
  if (iVar10 != 0) {
    uStack_11c = 0;
    lStack_98 = *(longlong *)(lVar15 + 8);
    lVar15 = lStack_98;
    if (*(longlong *)(lStack_98 + 0x478) != 0) {
      lVar15 = *(longlong *)(lStack_98 + 0x478);
    }
    if ((*(byte *)(lVar15 + 0x474) & 1) != 0) {
      lVar15 = *param_7;
      *(int *)((longlong)plStack_118 + 0xc) = *(int *)((longlong)plStack_118 + 0xc) + 1;
      *(longlong **)(lVar15 + 0x150) = plStack_118;
      *(undefined4 *)(lVar15 + 0x158) = 1;
      plStack_118 = (longlong *)0x0;
    }
  }
  lVar12 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar15 = *(longlong *)(lVar12 + 0x100);
  if (lVar15 == 0) {
    *(undefined8 *)(puVar23 + -8) = 0x100d5e;
    (*_DAT_)();
    lVar15 = *(longlong *)(lVar12 + 0x100);
  }
  puVar22 = puVar23;
  if (*(int *)(lVar15 + 0x22c) != 0) {
    *(undefined8 *)(puVar23 + -8) = 0x100d74;
    (*_DAT_)();
  }
LAB_:
  uVar20 = uStack_40 ^ (ulonglong)&uStack_128;
  *(undefined8 *)(puVar22 + -8) = 0x100d8d;
  func_0x(uVar20);
  return;
}

