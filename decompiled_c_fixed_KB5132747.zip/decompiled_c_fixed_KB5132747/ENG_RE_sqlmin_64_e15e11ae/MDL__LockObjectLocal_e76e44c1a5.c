
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x001021b5) */
/* WARNING: Removing unreachable block (ram,0x0070946a) */
/* WARNING: Removing unreachable block (ram,0x0070954c) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,uint param_2,int param_3,byte param_4,uint param_5,int param_6,
                 int param_7,int param_8,undefined4 *param_9)

{
  undefined4 *puVar1;
  longlong **pplVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  ushort uVar6;
  longlong lVar7;
  longlong *plVar8;
  ulonglong uVar9;
  longlong *plVar10;
  ushort uVar11;
  ushort uVar12;
  ushort uVar13;
  longlong unaff_GS_OFFSET;
  undefined auStack_df8 [32];
  undefined uStack_dd8;
  byte bStack_dc8;
  byte bStack_dc7;
  uint uStack_dc4;
  longlong **pplStack_dc0;
  int iStack_db8;
  uint uStack_db4;
  undefined2 uStack_db0;
  int iStack_dac;
  undefined4 *puStack_da8;
  longlong **pplStack_da0;
  longlong lStack_d98;
  undefined8 uStack_d90;
  undefined auStack_d88 [8];
  undefined4 uStack_d80;
  undefined4 uStack_d78;
  uint **ppuStack_d70;
  undefined *puStack_d68;
  undefined8 uStack_d60;
  uint *puStack_d58;
  undefined8 uStack_d50;
  undefined auStack_d48 [528];
  undefined8 uStack_b38;
  undefined8 uStack_b30;
  uint uStack_b28;
  uint uStack_b24;
  undefined uStack_b20;
  uint uStack_b1f;
  uint uStack_158;
  int iStack_154;
  undefined4 uStack_150;
  undefined2 uStack_14c;
  undefined uStack_14a;
  uint uStack_148;
  int iStack_144;
  undefined4 uStack_140;
  undefined2 uStack_13c;
  undefined uStack_13a;
  byte abStack_138 [4];
  int iStack_134;
  undefined4 uStack_130;
  undefined auStack_128 [16];
  undefined4 uStack_118;
  longlong lStack_108;
  undefined4 uStack_100;
  undefined8 uStack_f8;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  uint uStack_d8;
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined auStack_c0 [12];
  undefined4 uStack_b4;
  undefined uStack_b0;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  byte abStack_98 [4];
  int iStack_94;
  undefined4 uStack_90;
  undefined auStack_88 [16];
  undefined4 uStack_78;
  longlong *plStack_68;
  undefined4 uStack_60;
  undefined8 uStack_58;
  ulonglong uStack_48;
  
  uStack_d90 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_df8;
  puStack_da8 = param_9;
  uVar11 = 0;
  bStack_dc8 = param_4;
  bStack_dc7 = param_4;
  iStack_db8 = param_3;
  uStack_db4 = param_2;
  if (param_7 == 0) {
    if (param_8 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (param_6 == -2) {
      param_6 = *(int *)(*(longlong *)
                          (*(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8) + 0x68) + 0x18);
    }
    if (param_4 == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    pplStack_dc0 = (longlong **)((ulonglong)pplStack_dc0 & 0xffffffff00000000);
    param_1 = (longlong **)*param_1;
    uStack_db0 = *(undefined2 *)((longlong)param_1[6] + 0x6b8);
    param_5 = param_5 & 1;
    lStack_d98 = (ulonglong)param_2 << 0x10;
    iVar5 = 0;
    uVar12 = uVar11;
    uVar13 = 0xffff;
    uStack_dc4 = param_5;
    iStack_dac = param_6;
    pplStack_da0 = param_1;
    if (param_3 == 0) {
      uVar6 = (ushort)param_2 & 7;
      if (*(short *)(param_1 + 0x3b) == 0) {
        uVar12 = 8;
        uVar13 = uVar11;
        goto LAB_;
      }
      uVar9 = (ulonglong)uVar6;
      lVar7 = uVar9 + 0x1d;
      if (param_1[lVar7] != (longlong *)lStack_d98) {
        uVar9 = 0;
        do {
          if (param_1[uVar9 + 0x1d] == (longlong *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (param_1[uVar9 + 0x1d] == (longlong *)lStack_d98) goto LAB_;
          uVar12 = (short)uVar9 + 1;
          uVar9 = (ulonglong)uVar12;
        } while (uVar12 < 8);
        if (param_1[lVar7] == (longlong *)0x0) {
          uVar13 = uVar6;
        }
        goto LAB_;
      }
LAB_:
      uVar11 = *(ushort *)((longlong)param_1 + uVar9 * 2 + 0x1c8);
      if ((uVar11 & 2) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (param_1[(uVar9 + 4) * 2 + 0x1d] == (longlong *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      bStack_dc8 = *(byte *)((longlong)param_1[(uVar9 + 4) * 2 + 0x1d] + 0x36);
      if (param_9 != (undefined4 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(char *)((ulonglong)bStack_dc8 * 0x16 + (ulonglong)param_4 + 0x2f9e760) == '\0') ||
         ((param_5 != 0 && ((uVar11 & 1) == 0)))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      piVar3 = (int *)((longlong)param_1 + uVar9 * 4 + 0x1a8);
      *piVar3 = *piVar3 + 1;
    }
    else {
LAB_:
      uStack_b4 = 0;
      uStack_b0 = 0;
      uStack_a8 = 0;
      uStack_13a = 5;
      uStack_140 = 0;
      uStack_118 = 0;
      lStack_108 = 0;
      uStack_100 = 0;
      uStack_f8 = 0;
      auStack_128._8_8_ = 0;
      auStack_128._0_8_ = param_1 + 7;
      uStack_130 = 0;
      if (param_5 != 0) {
        uStack_130 = 0x2000000;
      }
      if (param_8 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((DAT_ & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uStack_148 = param_2;
      iStack_144 = param_3;
      uStack_13c = uStack_db0;
      abStack_138[0] = param_4;
      iStack_134 = param_6;
      iVar5 = func_0x(param_1,abStack_138,&uStack_148,auStack_c0);
      if (uStack_a8 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (lStack_108 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (puStack_da8 != (undefined4 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (iVar5 < 0) goto LAB_;
      if ((iStack_db8 == 0) && (*(ushort *)(param_1 + 0x3b) < 8)) {
        if (uVar12 < 8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (uVar13 != 0xffff) {
          lVar7 = (longlong)(short)uVar13;
          param_1[lVar7 + 0x1d] = (longlong *)lStack_d98;
          puVar1 = (undefined4 *)(param_1 + (lVar7 + 4) * 2 + 0x1d);
          *puVar1 = (undefined4)uStack_a8;
          puVar1[1] = uStack_a8._4_4_;
          puVar1[2] = uStack_a0;
          puVar1[3] = uStack_9c;
          *(undefined4 *)((longlong)param_1 + lVar7 * 4 + 0x1a8) = 0;
          *(ushort *)((longlong)param_1 + lVar7 * 2 + 0x1c8) = param_5 != 0 | 2;
          *(short *)(param_1 + 0x3b) = *(short *)(param_1 + 0x3b) + 1;
        }
      }
    }
    param_1 = pplStack_da0;
    if (((param_5 != 0) && ((~*(uint *)(pplStack_da0 + 0x43) & 1) == 0)) && ((int)pplStack_dc0 == 1)
       ) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  else {
    pplStack_da0 = param_1;
    if ((_DAT_ & 0x8000) != 0) {
      uStack_d80 = 0x10000;
      uStack_d78 = 0;
      ppuStack_d70 = &puStack_d58;
      puStack_d68 = auStack_d48;
      uStack_b38 = 0;
      uStack_d60 = 0;
      uStack_b30 = 0;
      puStack_d58 = &uStack_b28;
      uStack_d50 = 0xd;
      uStack_b28 = (uint)*(ushort *)((*param_1)[6] + 0x6b8);
      uStack_b20 = 0;
      uStack_b24 = param_2;
      uStack_b1f = (uint)param_4;
      func_0x(auStack_d88,0xffffffff);
    }
    if (((param_4 != 2) || (iStack_db8 != 0)) || (iStack_dac = 1, (param_5 & 1) == 0)) {
      iStack_dac = 0;
    }
    param_1 = (longlong **)*param_1;
    uStack_db0 = *(undefined2 *)(param_1[6] + 0xd7);
    uStack_dc4 = param_5 & 1;
    lStack_d98 = (ulonglong)param_2 << 0x10;
    uVar12 = uVar11;
    if (iStack_db8 == 0) {
      if (*(short *)(param_1 + 0x3b) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar12 = 8;
    }
    uStack_dc = 0;
    uStack_d8 = uStack_d8 & 0xffffff00;
    uStack_d0 = 0;
    uStack_14a = 5;
    uStack_158 = uStack_db4;
    iStack_154 = iStack_db8;
    uStack_150 = 0;
    uStack_78 = 0;
    plStack_68 = (longlong *)0x0;
    uStack_58 = 0;
    iStack_94 = param_7;
    auStack_88._8_8_ = 0;
    auStack_88._0_8_ = param_1 + 7;
    uStack_90 = 0;
    if (uStack_dc4 != 0) {
      uStack_90 = 0x2000000;
    }
    uStack_60 = 0x10;
    pplStack_dc0 = param_1;
    uStack_14c = uStack_db0;
    abStack_98[0] = param_4;
    iVar5 = func_0x(param_1,abStack_98,&uStack_158,&uStack_e8);
    if (uStack_d0 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    bStack_dc8 = *(byte *)(uStack_d0 + 0x36);
    if (plStack_68 != (longlong *)0x0) {
      plVar10 = plStack_68 + 1;
      LOCK();
      iVar4 = *(int *)plVar10;
      *(int *)plVar10 = *(int *)plVar10 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        plVar8 = plStack_68;
        if (plVar10 == (longlong *)0x0) {
          plVar8 = (longlong *)0x0;
        }
        (**(code **)(*plVar8 + 8))();
      }
    }
    if (param_9 != (undefined4 *)0x0) {
      *param_9 = uStack_e8;
      param_9[1] = uStack_e4;
      param_9[2] = uStack_e0;
      param_9[3] = uStack_dc;
      param_9[4] = uStack_d8;
      param_9[5] = uStack_d4;
      param_9[6] = (undefined4)uStack_d0;
      param_9[7] = uStack_d0._4_4_;
      *(ulonglong *)(param_9 + 8) = CONCAT44(uStack_c4,uStack_c8);
    }
    if (iVar5 < 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((iStack_db8 != 0) || (7 < *(ushort *)(param_1 + 0x3b))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (7 < uVar12) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar9 = (ulonglong)uVar12;
    uVar12 = *(ushort *)((longlong)param_1 + uVar9 * 2 + 0x1c8);
    if ((uVar12 & 2) == 0) {
      pplVar2 = param_1 + (uVar9 + 4) * 2 + 0x1d;
      *(undefined4 *)pplVar2 = (undefined4)uStack_d0;
      *(undefined4 *)((longlong)pplVar2 + 4) = uStack_d0._4_4_;
      *(undefined4 *)(pplVar2 + 1) = uStack_c8;
      *(undefined4 *)((longlong)pplVar2 + 0xc) = uStack_c4;
      if ((char)uStack_e0 == '\0') {
        *(undefined4 *)((longlong)param_1 + uVar9 * 4 + 0x1a8) = 0;
        uVar12 = uVar11;
      }
      uVar12 = uVar12 | 2;
      *(ushort *)((longlong)param_1 + uVar9 * 2 + 0x1c8) = uVar12;
    }
    if (((uStack_dc4 != 0) &&
        (*(ushort *)((longlong)param_1 + uVar9 * 2 + 0x1c8) = uVar12 | 1, uStack_dc4 != 0)) &&
       (((~*(uint *)(param_1 + 0x43) & 1) == 0 && (iStack_dac == 1)))) {
      uStack_dd8 = 0;
      func_0x(param_1,uStack_db4,bStack_dc8);
    }
  }
  func_0x(param_1,bStack_dc7,uStack_db4);
LAB_:
  if ((iStack_db8 == 0) && (iVar5 < 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_df8);
  return;
}

