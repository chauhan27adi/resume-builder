
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  ushort *puVar2;
  undefined auVar3 [16];
  longlong **pplVar4;
  char cVar5;
  byte bVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong lVar9;
  longlong lVar10;
  ulonglong *puVar11;
  ushort uVar12;
  ushort uVar13;
  ulonglong uVar14;
  byte *pbVar15;
  uint uVar16;
  ulonglong uVar17;
  byte *pbVar18;
  short sVar19;
  uint uVar20;
  uint uVar21;
  undefined *puVar22;
  undefined *puVar23;
  ulonglong uVar24;
  uint uVar25;
  undefined4 uVar26;
  ushort *puVar27;
  byte *pbVar28;
  int iVar29;
  ulonglong uVar30;
  byte *pbVar31;
  undefined8 auStack_260 [5];
  longlong lStack_238;
  undefined auStack_230 [8];
  undefined4 auStack_228 [4];
  longlong alStack_218 [2];
  undefined auStack_208 [8];
  undefined8 uStack_200;
  undefined4 auStack_1f8 [2];
  undefined8 uStack_1f0;
  undefined4 auStack_1e8 [2];
  undefined8 uStack_1e0;
  undefined4 auStack_1d8 [2];
  undefined auStack_1d0 [8];
  undefined8 auStack_1c8 [2];
  undefined8 uStack_1b8;
  undefined2 uStack_1b0;
  undefined2 uStack_1a8;
  ushort uStack_1a6;
  undefined4 uStack_1a4;
  byte *pbStack_1a0;
  undefined8 uStack_198;
  undefined4 uStack_190;
  short sStack_18c;
  undefined8 uStack_18a;
  undefined2 uStack_182;
  undefined2 uStack_180;
  undefined6 uStack_17e;
  undefined4 uStack_178;
  undefined4 uStack_170;
  byte *pbStack_168;
  longlong lStack_160;
  undefined8 uStack_158;
  longlong **pplStack_150;
  undefined auStack_148 [12];
  undefined4 uStack_13c;
  undefined4 uStack_138;
  uint uStack_134;
  int iStack_130;
  longlong lStack_128;
  int iStack_120;
  longlong lStack_118;
  longlong lStack_110;
  longlong lStack_108;
  longlong lStack_100;
  short sStack_f8;
  ushort uStack_f6;
  uint uStack_f4;
  byte *pbStack_f0;
  undefined8 uStack_e8;
  undefined4 uStack_e0;
  ushort uStack_dc;
  undefined2 uStack_da;
  undefined6 uStack_d8;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  ushort uStack_ce;
  ushort uStack_cc;
  undefined2 uStack_ca;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [2];
  undefined auStack_ae [2];
  undefined auStack_ac [12];
  uint uStack_a0;
  undefined4 uStack_9c;
  short sStack_98;
  short sStack_96;
  short sStack_94;
  undefined2 uStack_92;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined2 uStack_88;
  undefined6 uStack_86;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  short *psStack_78;
  short *psStack_70;
  short sStack_68;
  undefined6 uStack_66;
  undefined auStack_60 [10];
  undefined auStack_56 [6];
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)&uStack_1b8;
  puVar22 = (undefined *)0x0;
  pbVar31 = (byte *)**param_1;
  sStack_f8 = 0xffff;
  pbStack_f0 = (byte *)0x0;
  uVar26 = 0;
  uStack_f4 = 0;
  uStack_da = 0;
  uStack_d8 = 0;
  uStack_d0 = 0;
  uStack_ce = 0;
  uStack_cc = 0;
  uStack_ca = 0;
  uStack_e8 = (undefined *)0x0;
  uStack_1a8 = 0xffff;
  pbStack_1a0 = (byte *)0x0;
  uStack_1a4 = 0;
  uStack_18a = 0;
  uStack_180 = 0;
  uStack_17e = 0;
  uStack_198 = 0;
  uStack_c4 = 1;
  uStack_170 = 3;
  puVar23 = puVar22;
  pbStack_168 = pbVar31;
  lStack_160 = param_3;
  uStack_158 = param_2;
  pplStack_150 = param_1;
  if ((char)pbVar31[2] < '\0') {
    pbVar15 = pbVar31 + 0x60;
    _auStack_ae = SUB1614(ZEXT816(0),2);
    auStack_b0 = (undefined  [2])0xffff;
    sStack_98 = 0;
    sStack_96 = 0;
    sStack_94 = 0;
    uStack_8a = 0;
    auStack_ac._4_8_ = 0;
    uStack_80 = 0;
    uStack_7c = 0;
    uStack_92 = 0;
    uStack_90 = 0;
    uStack_88 = 0;
    uStack_86 = 0;
    uStack_a0 = 0;
    uStack_9c = 0;
    psStack_78 = (short *)0x0;
    _auStack_60 = ZEXT812(0);
    auStack_56._2_4_ = 0;
    uStack_50 = 0;
    psStack_70 = (short *)0x0;
    sStack_68 = 0;
    uStack_66 = 0;
    auStack_c0 = ZEXT816(0);
    uVar8 = 0;
    if (*(short *)(pbVar31 + 0x24) == 0) {
LAB_:
      auStack_c0._8_8_ = uVar8;
      uStack_1b8 = *(longlong *)(pbVar31 + 0x28);
      uStack_1b0 = *(undefined2 *)(pbVar31 + 0x30);
    }
    else {
      bVar6 = pbVar31[1];
      if (bVar6 == 0xb) {
        if (*(int *)(pbVar31 + 0x18) != 99) {
LAB_:
          if (bVar6 != 9) goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (bVar6 != 8) goto LAB_;
LAB_:
        if (*(int *)(pbVar31 + 0x18) != 99) goto LAB_;
      }
      uStack_1b8 = CONCAT26(uStack_1b8._6_2_,*(undefined6 *)(pbVar31 + 0x20));
      auStack_260[0] = 0x1001a5;
      cVar5 = func_0x(&uStack_1b8,0x10605c0);
      uVar8 = auStack_c0._8_8_;
      if (cVar5 == '\0') goto LAB_;
      auStack_260[0] = 0x1001b5;
      func_0x(pbVar31,&uStack_1b8);
    }
    auStack_60._8_2_ = uStack_1b0;
    auStack_60._0_8_ = uStack_1b8;
    auStack_c0._0_8_ = pbVar15;
    auStack_56._2_4_ = *(undefined4 *)(pbVar31 + 0x20);
    auStack_b0 = (undefined  [2])0xffff;
    _auStack_b0 = _auStack_b0 & 0xffffffff;
    auStack_ac._4_8_ = 0;
    uStack_92 = 0;
    uStack_90 = 0;
    uVar30 = (ulonglong)*(short *)((ulonglong)*pbVar15 * 6 + 0x10deea4);
    uStack_88 = 0;
    uStack_86 = 0;
    uStack_a0 = 0;
    uStack_9c = 0;
    psStack_78 = (short *)0x0;
    psStack_70 = (short *)0x0;
    sStack_68 = 0;
    uStack_1b8 = CONCAT44((int)((ulonglong)uStack_1b8 >> 0x20),
                          *(undefined4 *)((ulonglong)*pbVar15 * 6 + 0x10deea0));
    uVar20 = uStack_a0;
    if ((*pbVar15 & 2) != 0) {
      pbVar28 = pbVar15 + uVar30;
      auStack_ac._4_8_ = pbVar28;
      if ((pbVar15[uVar30] & 1) == 0) {
        auVar3._14_2_ = 0;
        auVar3._0_14_ = _auStack_ae;
        _auStack_b0 = auVar3 << 0x10;
        uStack_8a = 0;
        uStack_88 = 0;
        uVar20 = 0;
        switch(*pbVar28 & 0xe) {
        default:
          uVar12 = *(ushort *)(pbVar28 + 2);
          uVar20 = (uint)uVar12;
          if (0x1f9d < uVar12 - 1) {
            auStack_260[0] = 0x100497;
            func_0x(pbVar28,6);
          }
          break;
        case 4:
          uVar20 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar20 = 1;
        }
      }
      else {
        bVar6 = *pbVar28;
        switch(bVar6 & 0x1c) {
        default:
          if ((char)pbVar28[1] < '\0') {
            auStack_ae = (undefined  [2])
                         ((*(ushort *)(pbVar28 + 1) & 0x7f) << 8 | *(ushort *)(pbVar28 + 1) >> 8);
            sStack_98 = 3;
          }
          else {
            auStack_ae = (undefined  [2])(ushort)pbVar28[1];
            sStack_98 = 2;
          }
          auStack_b0 = (undefined  [2])0x1;
          sStack_94 = (short)((ushort)auStack_ae + 1 >> 1) + sStack_98;
          if ((ushort)auStack_ae < 0x1f) {
            uStack_80 = 0;
            sStack_96 = 0;
            uStack_88 = 0;
            uStack_86 = 0;
            uStack_a0 = 0;
            uStack_9c = 0;
            uVar20 = uStack_a0;
          }
          else {
            iVar29 = (ushort)auStack_ae - 1;
            uStack_80 = 0;
            uStack_88 = 0;
            uStack_86 = 0;
            uStack_a0 = 0;
            uStack_9c = 0;
            sStack_96 = ((short)(iVar29 / 0x1e) + (short)(iVar29 >> 0x1f)) -
                        (short)((longlong)iVar29 * 0x88888889 >> 0x3f);
            uVar20 = uStack_a0;
          }
          break;
        case 4:
          if (((bVar6 & 0x1c) == 4) && ((bVar6 & 2) != 0)) {
            uVar26 = 1;
            auStack_ac._0_4_ = 0xf;
          }
          else {
            auStack_ac._0_4_ = 1;
          }
          sStack_98 = 0;
          sStack_96 = 0;
          sStack_94 = 0;
          uStack_8a = 0;
          _auStack_b0 = 1;
          uStack_88 = 0;
          uStack_86 = 0;
          uStack_a0 = 0;
          uStack_9c = 0;
          uVar20 = uStack_a0;
          uStack_80 = uVar26;
          break;
        case 8:
          sStack_98 = 0;
          sStack_96 = 0;
          sStack_94 = 0;
          uStack_8a = 0;
          _auStack_b0 = 0x900000001;
          uStack_80 = 0;
          uStack_88 = 0;
          uStack_86 = 0;
          uStack_a0 = 0;
          uStack_9c = 0;
          uVar20 = uStack_a0;
        }
      }
    }
    uStack_a0 = uVar20;
    uStack_90 = 0;
    uStack_92 = 0;
    if ((*(byte *)auStack_c0._0_8_ & 4) != 0) {
      if (uStack_1b8._2_2_ != 0) {
        uVar30 = (ulonglong)*(ushort *)(pbVar31 + (longlong)uStack_1b8._2_2_ * 2 + 0x61);
      }
      psStack_78 = (short *)(pbVar15 + uVar30);
      psStack_70 = psStack_78 + 1;
      sStack_68 = (*psStack_78 + 1) * 2;
    }
    puVar23 = auStack_c0;
    if (auStack_c0._8_8_ != 0) {
      auStack_260[0] = 0x100543;
      func_0x(auStack_c0._8_8_,auStack_c0);
    }
  }
  pbStack_f0 = pbVar31 + *(ushort *)(pbVar31 + 0x1ffc);
  if ((*pbStack_f0 & 1) == 0) {
    sStack_f8 = 0;
    puVar23 = (undefined *)0x0;
    uStack_f4 = 0;
    uStack_d2 = 0;
    uStack_d0 = 0;
    uVar20 = (uint)*(ushort *)(pbVar31 + 0xe);
    switch(*pbStack_f0 & 0xe) {
    default:
      uVar20 = (uint)*(ushort *)(pbStack_f0 + 2);
      puVar22 = puVar23;
      if (0x1f9d < *(ushort *)(pbStack_f0 + 2) - 1) {
        auStack_260[0] = 0x1007fa;
        func_0x(pbStack_f0,6);
        puVar22 = (undefined *)(ulonglong)uStack_f4;
      }
      break;
    case 4:
      uVar20 = 9;
      puVar22 = puVar23;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      puVar22 = puVar23;
      uVar20 = 1;
    }
    uStack_e8 = (undefined *)CONCAT44(uStack_e8._4_4_,uVar20);
    uStack_da = SUB82(pbVar31 + 0x2000,0);
    uStack_d8 = (undefined6)((ulonglong)(pbVar31 + 0x2000) >> 0x10);
    puVar23 = (undefined *)(ulonglong)uVar20;
  }
  else {
    sStack_f8 = 1;
    bVar6 = *pbStack_f0;
    uStack_e8 = puVar23;
    switch(bVar6 & 0x1c) {
    default:
      if ((char)pbStack_f0[1] < '\0') {
        sVar19 = 3;
        uStack_e0._0_2_ = 3;
        uStack_f6 = (*(ushort *)(pbStack_f0 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_f0 + 1) >> 8;
      }
      else {
        uStack_f6 = (ushort)pbStack_f0[1];
        sVar19 = 2;
        uStack_e0._0_2_ = 2;
      }
      uStack_dc = ((ushort)(uStack_f6 + 1) >> 1) + sVar19;
      if (uStack_f6 < 0x1f) {
        pbVar15 = pbVar31 + 0x2000;
        uStack_e0._2_2_ = 0;
        uStack_d0 = SUB82(pbVar15,0);
        uStack_ce = (ushort)((ulonglong)pbVar15 >> 0x10);
        uStack_cc = (ushort)((ulonglong)pbVar15 >> 0x20);
        uStack_ca = (undefined2)((ulonglong)pbVar15 >> 0x30);
        uStack_f4 = 0;
        uStack_c8 = 0;
      }
      else {
        iVar29 = uStack_f6 - 1;
        uStack_f4 = 0;
        puVar22 = (undefined *)0x0;
        uStack_c8 = 0;
        uStack_e0._2_2_ =
             ((short)(iVar29 / 0x1e) + (short)(iVar29 >> 0x1f)) -
             (short)((longlong)iVar29 * 0x88888889 >> 0x3f);
        pbVar15 = pbVar31 + 0x2000;
        uStack_d0 = SUB82(pbVar15,0);
        uStack_ce = (ushort)((ulonglong)pbVar15 >> 0x10);
        uStack_cc = (ushort)((ulonglong)pbVar15 >> 0x20);
        uStack_ca = (undefined2)((ulonglong)pbVar15 >> 0x30);
      }
      break;
    case 4:
      if (((bVar6 & 0x1c) == 4) && ((bVar6 & 2) != 0)) {
        puVar22 = (undefined *)0xf;
        uStack_e0._0_2_ = 0;
        uStack_e0._2_2_ = 0;
        uStack_dc = 0;
        uStack_da = 0;
        pbVar15 = pbVar31 + 0x2000;
        uStack_f4 = 0xf;
        uStack_d0 = SUB82(pbVar15,0);
        uStack_ce = (ushort)((ulonglong)pbVar15 >> 0x10);
        uStack_cc = (ushort)((ulonglong)pbVar15 >> 0x20);
        uStack_ca = (undefined2)((ulonglong)pbVar15 >> 0x30);
        uStack_f6 = 0;
        uStack_d8 = 0;
        uStack_d2 = 0;
        uStack_c8 = 1;
      }
      else {
        pbVar15 = pbVar31 + 0x2000;
        uStack_e0._0_2_ = 0;
        uStack_e0._2_2_ = 0;
        uStack_dc = 0;
        uStack_da = 0;
        uStack_d0 = SUB82(pbVar15,0);
        uStack_ce = (ushort)((ulonglong)pbVar15 >> 0x10);
        uStack_cc = (ushort)((ulonglong)pbVar15 >> 0x20);
        uStack_ca = (undefined2)((ulonglong)pbVar15 >> 0x30);
        puVar22 = (undefined *)0x1;
        uStack_f6 = 0;
        uStack_d8 = 0;
        uStack_d2 = 0;
        uStack_f4 = 1;
        uStack_c8 = 0;
      }
      break;
    case 8:
      puVar22 = (undefined *)0x9;
      uStack_e0._0_2_ = 0;
      uStack_e0._2_2_ = 0;
      uStack_dc = 0;
      uStack_da = 0;
      pbVar15 = pbVar31 + 0x2000;
      uStack_f4 = 9;
      uStack_d0 = SUB82(pbVar15,0);
      uStack_ce = (ushort)((ulonglong)pbVar15 >> 0x10);
      uStack_cc = (ushort)((ulonglong)pbVar15 >> 0x20);
      uStack_ca = (undefined2)((ulonglong)pbVar15 >> 0x30);
      uStack_f6 = 0;
      uStack_d8 = 0;
      uStack_d2 = 0;
      uStack_c8 = 0;
    }
  }
  if (sStack_f8 == 0) {
    pbVar15 = pbStack_f0;
    uVar20 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0);
    if ((int)puVar22 == 0) {
      uStack_f6 = 0;
      uVar20 = (uint)puVar23;
      puVar22 = (undefined *)((ulonglong)puVar23 & 0xffffffff);
      if ((*pbStack_f0 & 0x10) != 0) {
        uVar20 = uVar20 + 2 + (*(ushort *)(pbStack_f0 + ((ulonglong)puVar23 & 0xffffffff)) + 7 >> 3)
        ;
        puVar22 = (undefined *)(ulonglong)uVar20;
      }
      uStack_e8 = (undefined *)CONCAT44(uVar20,(uint)uStack_e8);
      uVar20 = (uint)puVar22;
      if ((*pbStack_f0 & 0x20) == 0) {
        uStack_dc = 0;
        uStack_f4 = uVar20;
      }
      else {
        puVar27 = (ushort *)(puVar22 + (longlong)pbStack_f0);
        uStack_dc = *puVar27;
        if (uStack_dc == 0) {
          auStack_260[0] = 0x1008c5;
          cVar5 = func_0x(0x19f5650);
          if (cVar5 != '\0') {
            auStack_260[0] = 0x1008ce;
            lVar7 = func_0x();
            if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
              auStack_260[0] = 0x1008e8;
              cVar5 = func_0x(0x19f5650);
              if (cVar5 == '\0') {
                auStack_260[0] = 0x100904;
                (*pcRam0000000000f631d8)(0x22,0x44,0x15,0x3eb);
              }
              else {
                lStack_238 = 0;
                auStack_260[0] = 0x10092c;
                (*pcRam0000000000f631d0)(1,0x12e505c,0x1405148,0x80f);
              }
            }
          }
          auStack_260[0] = 0x10093b;
          func_0x(pbStack_f0,3);
        }
        uStack_e0 = uStack_e8._4_4_ + 2 + (uint)uStack_dc * 2;
        if (0x1f9e < uStack_e0) {
          auStack_260[0] = 0x10097a;
          cVar5 = func_0x(0x19f5650);
          if (cVar5 != '\0') {
            auStack_260[0] = 0x100983;
            lVar7 = func_0x();
            if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
              auStack_260[0] = 0x10099d;
              cVar5 = func_0x(0x19f5650);
              if (cVar5 == '\0') {
                auStack_260[0] = 0x1009b9;
                (*pcRam0000000000f631d8)(0x22,0x44,0x15,0x3ec);
              }
              else {
                lStack_238 = 0;
                auStack_260[0] = 0x1009e1;
                (*pcRam0000000000f631d0)(1,0x12e505c,0x1405148,0x816);
              }
            }
          }
          auStack_260[0] = 0x1009f2;
          func_0x(pbStack_f0,4);
        }
        uVar30 = (ulonglong)uStack_dc;
        uStack_f4 = puVar27[uVar30] & 0x7fff;
        uVar21 = uStack_e0;
        if (uStack_f4 < uStack_e0) {
          auStack_260[0] = 0x100a32;
          cVar5 = func_0x(0x19f5650);
          if (cVar5 != '\0') {
            auStack_260[0] = 0x100a3b;
            lVar7 = func_0x();
            if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
              auStack_260[0] = 0x100a55;
              cVar5 = func_0x(0x19f5650);
              if (cVar5 == '\0') {
                auStack_260[0] = 0x100a71;
                (*pcRam0000000000f631d8)(0x22,0x44,0x15,0x3ec);
              }
              else {
                lStack_238 = 0;
                auStack_260[0] = 0x100a99;
                (*pcRam0000000000f631d0)(1,0x12e505c,0x1405148,0x81d);
              }
            }
          }
          auStack_260[0] = 0x100aaa;
          func_0x(pbStack_f0,4);
          uVar30 = (ulonglong)uStack_dc;
          uVar21 = uStack_e0;
        }
        puVar22 = (undefined *)(ulonglong)uStack_f4;
        iVar29 = 0;
        pbVar15 = pbStack_f0;
        puVar2 = puVar27;
        uStack_e0 = uVar21;
        uVar20 = uVar21;
        if ((short)uVar30 != 0) {
          do {
            uVar20 = puVar2[1] & 0x7fff;
            if ((uVar20 < uVar21) || ((uint)puVar22 < uVar20)) {
              auStack_260[0] = 0x100b03;
              cVar5 = func_0x(0x19f5650);
              if (cVar5 != '\0') {
                auStack_260[0] = 0x100b0c;
                lVar7 = func_0x();
                if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                  auStack_260[0] = 0x100b26;
                  cVar5 = func_0x(0x19f5650);
                  if (cVar5 == '\0') {
                    auStack_260[0] = 0x100b42;
                    (*pcRam0000000000f631d8)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    lStack_238 = 0;
                    auStack_260[0] = 0x100b66;
                    (*pcRam0000000000f631d0)(1,0x12e505c,0x1405148,0x82a);
                  }
                }
              }
              auStack_260[0] = 0x100b77;
              func_0x(pbStack_f0,4);
              uVar30 = (ulonglong)uStack_dc;
              puVar22 = (undefined *)(ulonglong)uStack_f4;
              pbVar15 = pbStack_f0;
            }
            iVar29 = iVar29 + 1;
            puVar2 = puVar2 + 1;
            uVar21 = uVar20;
            uVar20 = uStack_e0;
            pbVar31 = pbStack_168;
          } while (iVar29 < (int)uVar30);
        }
        while( true ) {
          if (-1 < (short)puVar27[(ulonglong)((int)uVar30 - 1) + 1]) break;
          uVar21 = uStack_e0;
          if ((int)uVar30 != 1) {
            uVar21 = *(ushort *)(pbVar15 + uVar30 * 2 + (((ulonglong)uStack_e8 >> 0x20) - 2)) &
                     0x7fff;
          }
          uVar16 = *(ushort *)(pbVar15 + uVar30 * 2 + ((ulonglong)uStack_e8 >> 0x20)) & 0x7fff;
          if (((uVar21 < uStack_e0) || (uVar16 < uVar21)) ||
             (uVar12 = (ushort)uVar30, (uint)puVar22 < uVar16)) {
            auStack_260[0] = 0x100c1b;
            uStack_e0 = uVar20;
            func_0x(pbVar15,7);
            puVar22 = (undefined *)(ulonglong)uStack_f4;
            pbVar15 = pbStack_f0;
            uVar12 = uStack_dc;
            uVar20 = uStack_e0;
          }
          if ((uVar21 < uStack_e0) || ((uint)puVar22 < uVar21)) goto code_r0x00100fe8;
          if (*(ushort *)(pbVar15 + uVar21) == 5) {
            uStack_f6 = uStack_f6 | 2;
            uStack_dc = uVar12 - 1;
            uVar30 = (ulonglong)(uVar21 & 0xffff);
            pbVar28 = pbVar15 + uVar30;
            uStack_ce = (ushort)uVar21;
            if ((*(ushort *)(pbVar28 + 2) >> 0xe & 1) == 0) {
              uVar12 = uStack_cc & 0xc7ff;
            }
            else {
              uVar12 = uStack_cc ^ (uStack_cc ^ *(ushort *)(pbVar28 + 2)) & 0x3800;
            }
            uStack_cc = (uVar12 ^ *(ushort *)(pbVar28 + 2)) & 0x7ff ^ uVar12;
            uVar25 = (uint)uStack_cc;
            lVar7 = uVar30 + (uVar12 >> 0xb & 7) * 2;
            pbVar18 = pbVar15;
            uStack_e0 = uVar20;
            if (pbVar15 + (ulonglong)((uVar25 & 0x7ff) * 2) + 4 + lVar7 < pbVar28) {
              auStack_260[0] = 0x100d2c;
              func_0x(pbVar28,0x19);
              uVar30 = (ulonglong)uStack_ce;
              puVar22 = (undefined *)(ulonglong)uStack_f4;
              pbVar18 = pbStack_f0;
            }
            uVar20 = uStack_e0;
            if (uVar16 - uVar21 <
                (((uStack_cc & 0x7ff) * 2 - (int)uVar30) - (int)pbStack_f0) +
                (int)(pbVar15 + (ulonglong)((uVar25 & 0x7ff) * 2) + 4 + lVar7)) {
              auStack_260[0] = 0x100d78;
              func_0x(pbVar18 + uVar30,0x19);
              uVar30 = (ulonglong)uStack_ce;
              puVar22 = (undefined *)(ulonglong)uStack_f4;
              pbVar18 = pbStack_f0;
              uVar20 = uStack_e0;
            }
            iVar29 = 0;
            pbVar15 = pbVar18;
            if (((uStack_cc & 0x3800) != 0) &&
               (puVar27 = (ushort *)(pbVar18 + uVar30 + 4), uVar12 = uStack_cc,
               (uStack_cc & 0x3800) != 0)) {
              do {
                if ((uVar12 & 0x7ff) < (*puVar27 & 0x7ff)) {
                  auStack_260[0] = 0x100df5;
                  uStack_e0 = uVar20;
                  func_0x(pbVar18 + uVar30,0x1a);
                  uVar30 = (ulonglong)uStack_ce;
                  pbVar18 = pbStack_f0;
                  uVar20 = uStack_e0;
                  uVar12 = uStack_cc;
                }
                iVar29 = iVar29 + 1;
                puVar27 = puVar27 + 1;
              } while (iVar29 < (int)((uStack_cc & 0x3800) >> 0xb));
              puVar22 = (undefined *)(ulonglong)uStack_f4;
              pbVar15 = pbVar18;
            }
            break;
          }
          if (*(ushort *)(pbVar15 + uVar21) < 0x400) break;
          uStack_f6 = uStack_f6 | 1;
          uStack_dc = uVar12 - 1;
          uVar30 = (ulonglong)uStack_dc;
          if (uStack_dc == 0) break;
        }
      }
      if ((*pbVar15 & 0x40) == 0) {
        uStack_d2 = 0;
        uStack_d0 = 0;
      }
      else {
        uStack_d2 = SUB82(puVar22,0);
        uStack_d0 = (undefined2)((ulonglong)puVar22 >> 0x10);
        uStack_f4 = (int)puVar22 + 0xe;
        auStack_260[0] = 0x100e64;
        uStack_e0 = uVar20;
        uVar8 = func_0x(&uStack_f6);
        auStack_260[0] = 0x100e70;
        func_0x(uVar8,&pbStack_168);
        auStack_260[0] = 0x100e79;
        iVar29 = func_0x(&pbStack_168);
        uStack_f4 = uStack_f4 + iVar29;
        puVar22 = (undefined *)(ulonglong)uStack_f4;
        pbVar15 = pbStack_f0;
        uVar20 = uStack_e0;
      }
      uStack_e0 = uVar20;
      if (((undefined *)CONCAT62(uStack_d8,uStack_da) != (undefined *)0x0) &&
         ((undefined *)CONCAT62(uStack_d8,uStack_da) < puVar22 + (longlong)pbVar15)) {
        auStack_260[0] = 0x100ec5;
        cVar5 = func_0x(0x19f5650);
        if (cVar5 != '\0') {
          auStack_260[0] = 0x100ece;
          lVar7 = func_0x();
          if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
            auStack_260[0] = 0x100ee8;
            cVar5 = func_0x(0x19f5650);
            if (cVar5 == '\0') {
              auStack_260[0] = 0x100f04;
              (*pcRam0000000000f631d8)(0x22,0x44,0x15,0x3fa);
            }
            else {
              lStack_238 = 0;
              auStack_260[0] = 0x100f2a;
              (*pcRam0000000000f631d0)(1,0x12e505c,0x1405148,0x886);
            }
          }
        }
        auStack_260[0] = 0x100f3b;
        func_0x(pbStack_f0,0x12);
        puVar22 = (undefined *)(ulonglong)uStack_f4;
        pbVar15 = pbStack_f0;
      }
      uVar20 = uStack_e0;
      if (0x3f3b < (int)puVar22 - 1U) {
        auStack_260[0] = 0x100f64;
        cVar5 = func_0x(0x19f5650);
        if (cVar5 != '\0') {
          auStack_260[0] = 0x100f6d;
          lVar7 = func_0x();
          if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
            auStack_260[0] = 0x100f87;
            cVar5 = func_0x(0x19f5650);
            if (cVar5 == '\0') {
              auStack_260[0] = 0x100fa3;
              (*pcRam0000000000f631d8)(0x22,0x44,0x15,0x3ed);
            }
            else {
              lStack_238 = 0;
              auStack_260[0] = 0x100fc9;
              (*pcRam0000000000f631d0)(1,0x12e505c,0x1405148,0x88b);
            }
          }
        }
        auStack_260[0] = 0x100fda;
        func_0x(pbStack_f0,5);
        puVar22 = (undefined *)(ulonglong)uStack_f4;
        pbVar15 = pbStack_f0;
        uVar20 = uStack_e0;
      }
    }
code_r0x00100fe8:
    puVar23 = puVar22;
    if (8 < (uint)puVar22) goto code_r0x00101036;
    bVar6 = *pbVar15 & 0xe;
  }
  else {
    if ((int)puVar22 == 0) {
      auStack_260[0] = 0x10100a;
      func_0x(&uStack_f6);
      puVar22 = (undefined *)(ulonglong)uStack_f4;
    }
    uVar20 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0);
    pbVar15 = pbStack_f0;
    puVar23 = puVar22;
    if (8 < (uint)puVar22) goto code_r0x00101036;
    bVar6 = *pbStack_f0 & 0x1c;
  }
  if ((bVar6 == 0) || (puVar23 = puVar22, bVar6 == 0xc)) {
    puVar23 = (undefined *)0x9;
  }
code_r0x00101036:
  uVar21 = (uint)puVar22;
  uStack_138 = 1;
  iVar29 = (int)((ulonglong)puVar23 >> 4);
  uStack_134 = iVar29 + 4;
  iStack_130 = (iVar29 * 2 + 0xc + uStack_134 * 0xf) * 2 + 0x54;
  auStack_260[0] = 0x10108d;
  uStack_e0 = uVar20;
  lVar9 = func_0x();
  lVar9 = -lVar9;
  uVar30 = ((ulonglong)puVar23 & 0xffffffff) + 0xf;
  lVar7 = (longlong)&uStack_1b8 + lVar9;
  if (uVar30 <= ((ulonglong)puVar23 & 0xffffffff)) {
    uVar30 = 0xffffffffffffff0;
  }
  uVar30 = uVar30 & 0xfffffffffffffff0;
  uStack_1b8 = lVar7;
  *(undefined8 *)((longlong)auStack_260 + lVar9) = 0x1010b7;
  func_0x();
  lVar1 = -uVar30;
  pbVar28 = (byte *)((longlong)&uStack_1b8 + lVar1 + lVar9);
  pbStack_168 = pbVar28;
  uVar20 = uStack_e0;
  if (pbVar31[1] == 0x11) {
    uVar8 = *(undefined8 *)(*(longlong *)(lStack_160 + 0x30) + 0x7a8);
    *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1010e1;
    func_0x(uVar8);
    pbVar15 = pbStack_f0;
    uVar20 = uStack_e0;
    uVar21 = uStack_f4;
  }
  uStack_e0 = uVar20;
  if (sStack_f8 == 0) {
    if (uVar21 == 0) {
      uVar30 = (ulonglong)uStack_e8 & 0xffffffff;
      iVar29 = 0;
      uStack_f6 = 0;
      uVar21 = (uint)uStack_e8;
      if ((*pbVar15 & 0x10) != 0) {
        uVar21 = (uint)uStack_e8 + 2 + (*(ushort *)(pbVar15 + uVar30) + 7 >> 3);
        uVar30 = (ulonglong)uVar21;
      }
      uStack_e8 = (undefined *)CONCAT44(uVar21,(uint)uStack_e8);
      uStack_e0 = (uint)uVar30;
      if ((*pbVar15 & 0x20) == 0) {
        uStack_dc = 0;
        uStack_f4 = uStack_e0;
      }
      else {
        puVar27 = (ushort *)(pbVar15 + uVar30);
        uStack_dc = *puVar27;
        if (uStack_dc == 0) {
          uStack_e0 = uVar20;
          *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x10116a;
          cVar5 = func_0x(0x19f5650);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x101173;
            lVar10 = func_0x();
            if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x10118d;
              cVar5 = func_0x(0x19f5650);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1011a9;
                (*pcRam0000000000f631d8)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(auStack_230 + lVar1 + lVar9 + -8) = 0;
                *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1011cc;
                (*pcRam0000000000f631d0)(1,0x12e505c,0x1405148,0x80f);
              }
            }
          }
          pbVar31 = pbStack_f0;
          *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1011dd;
          func_0x(pbVar31,3);
          pbVar15 = pbStack_f0;
        }
        uStack_e0 = uStack_e8._4_4_ + 2 + (uint)uStack_dc * 2;
        if (0x1f9e < uStack_e0) {
          *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x10121c;
          cVar5 = func_0x(0x19f5650);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x101225;
            lVar10 = func_0x();
            if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x10123f;
              cVar5 = func_0x(0x19f5650);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x10125b;
                (*pcRam0000000000f631d8)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(auStack_230 + lVar1 + lVar9 + -8) = 0;
                *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x10127e;
                (*pcRam0000000000f631d0)(1,0x12e505c,0x1405148,0x816);
              }
            }
          }
          pbVar31 = pbStack_f0;
          *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x10128f;
          func_0x(pbVar31,4);
          pbVar15 = pbStack_f0;
        }
        uVar14 = (ulonglong)uStack_dc;
        uStack_f4 = puVar27[uVar14] & 0x7fff;
        if (uStack_f4 < uStack_e0) {
          *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1012cf;
          cVar5 = func_0x(0x19f5650);
          if (cVar5 != '\0') {
            *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1012d8;
            lVar10 = func_0x();
            if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1012f2;
              cVar5 = func_0x(0x19f5650);
              if (cVar5 == '\0') {
                *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x10130e;
                (*pcRam0000000000f631d8)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(auStack_230 + lVar1 + lVar9 + -8) = 0;
                *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x101331;
                (*pcRam0000000000f631d0)(1,0x12e505c,0x1405148,0x81d);
              }
            }
          }
          pbVar31 = pbStack_f0;
          *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x101342;
          func_0x(pbVar31,4);
          uVar14 = (ulonglong)uStack_dc;
          pbVar15 = pbStack_f0;
        }
        uVar24 = (ulonglong)uStack_e0;
        uVar30 = (ulonglong)uStack_f4;
        puVar2 = puVar27;
        if ((short)uVar14 != 0) {
          do {
            uVar20 = puVar2[1] & 0x7fff;
            if ((uVar20 < (uint)uVar24) || ((uint)uVar30 < uVar20)) {
              *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1013a3;
              cVar5 = func_0x(0x19f5650);
              if (cVar5 != '\0') {
                *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1013ac;
                lVar7 = func_0x();
                if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1013c6;
                  cVar5 = func_0x(0x19f5650);
                  if (cVar5 == '\0') {
                    *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1013e2;
                    (*pcRam0000000000f631d8)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(auStack_230 + lVar1 + lVar9 + -8) = 0;
                    *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x101406;
                    (*pcRam0000000000f631d0)(1,0x12e505c,0x1405148,0x82a);
                  }
                }
              }
              pbVar31 = pbStack_f0;
              *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x101417;
              func_0x(pbVar31,4);
              uVar14 = (ulonglong)uStack_dc;
              uVar30 = (ulonglong)uStack_f4;
              pbVar15 = pbStack_f0;
            }
            iVar29 = iVar29 + 1;
            uVar24 = (ulonglong)uVar20;
            puVar2 = puVar2 + 1;
          } while (iVar29 < (int)uVar14);
          uVar24 = (ulonglong)uStack_e0;
          pbVar28 = pbStack_168;
          lVar7 = uStack_1b8;
        }
        while( true ) {
          if (-1 < (short)puVar27[(ulonglong)((int)uVar14 - 1) + 1]) break;
          uVar17 = uVar24;
          if ((int)uVar14 != 1) {
            uVar17 = (ulonglong)
                     (*(ushort *)(pbVar15 + uVar14 * 2 + (((ulonglong)uStack_e8 >> 0x20) - 2)) &
                     0x7fff);
          }
          uVar20 = *(ushort *)(pbVar15 + uVar14 * 2 + ((ulonglong)uStack_e8 >> 0x20)) & 0x7fff;
          uVar21 = (uint)uVar17;
          if (((uVar21 < (uint)uVar24) || (uVar20 < uVar21)) ||
             (uVar12 = (ushort)uVar14, (uint)uVar30 < uVar20)) {
            *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1014bb;
            func_0x(pbVar15,7);
            uVar24 = (ulonglong)uStack_e0;
            uVar30 = (ulonglong)uStack_f4;
            pbVar15 = pbStack_f0;
            uVar12 = uStack_dc;
          }
          if ((uVar21 < (uint)uVar24) || ((uint)uVar30 < uVar21)) goto code_r0x00101911;
          if (*(ushort *)(pbVar15 + uVar17) == 5) {
            uStack_f6 = uStack_f6 | 2;
            uStack_dc = uVar12 - 1;
            uStack_ce = (ushort)uVar17;
            uVar17 = uVar17 & 0xffff;
            pbVar31 = pbVar15 + uVar17;
            if ((*(ushort *)(pbVar31 + 2) >> 0xe & 1) == 0) {
              uVar12 = uStack_cc & 0xc7ff;
            }
            else {
              uVar12 = uStack_cc ^ (uStack_cc ^ *(ushort *)(pbVar31 + 2)) & 0x3800;
            }
            uStack_cc = (uVar12 ^ *(ushort *)(pbVar31 + 2)) & 0x7ff ^ uVar12;
            pbVar18 = pbVar15 + uVar17 + (ulonglong)((uStack_cc & 0x7ff) * 2) + 4 +
                                         (ulonglong)((uVar12 >> 0xb & 7) * 2);
            if (pbVar18 < pbVar31) {
              *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1015d3;
              func_0x(pbVar31,0x19);
              uVar17 = (ulonglong)uStack_ce;
              uVar30 = (ulonglong)uStack_f4;
              pbVar15 = pbStack_f0;
            }
            if (uVar20 - uVar21 <
                (((uStack_cc & 0x7ff) * 2 - (int)uVar17) - (int)pbStack_f0) + (int)pbVar18) {
              *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x10161f;
              func_0x(pbVar15 + uVar17,0x19);
              uVar17 = (ulonglong)uStack_ce;
              uVar30 = (ulonglong)uStack_f4;
              pbVar15 = pbStack_f0;
            }
            if ((uStack_cc & 0x3800) != 0) {
              puVar27 = (ushort *)(pbVar15 + uVar17 + 4);
              iVar29 = 0;
              uVar12 = uStack_cc;
              if ((uStack_cc & 0x3800) != 0) {
                do {
                  if ((uVar12 & 0x7ff) < (*puVar27 & 0x7ff)) {
                    *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x101685;
                    func_0x(pbVar15 + uVar17,0x1a);
                    uVar17 = (ulonglong)uStack_ce;
                    pbVar15 = pbStack_f0;
                    uVar12 = uStack_cc;
                  }
                  iVar29 = iVar29 + 1;
                  puVar27 = puVar27 + 1;
                } while (iVar29 < (int)((uStack_cc & 0x3800) >> 0xb));
                uVar30 = (ulonglong)uStack_f4;
              }
            }
            break;
          }
          if (*(ushort *)(pbVar15 + uVar17) < 0x400) break;
          uStack_f6 = uStack_f6 | 1;
          uStack_dc = uVar12 - 1;
          uVar14 = (ulonglong)uStack_dc;
          if (uStack_dc == 0) break;
        }
      }
      iVar29 = 0;
      if ((*pbVar15 & 0x40) == 0) {
        uStack_d2 = 0;
        uStack_d0 = 0;
      }
      else {
        uStack_d2 = (undefined2)uVar30;
        uStack_d0 = (undefined2)(uVar30 >> 0x10);
        uStack_f4 = (int)uVar30 + 0xe;
        *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1016fc;
        puVar11 = (ulonglong *)func_0x(&uStack_f6);
        uVar13 = (ushort)(*puVar11 >> 0x30);
        uVar12 = uVar13;
        if ((((uint)(int)(short)uVar13 >> 1 ^ (int)(short)uVar13) & 0x2000) != 0) {
          uVar12 = uVar13 & 0xdfff;
          if ((uVar13 >> 0xe & 1) != 0) {
            uVar12 = uVar13 | 0x2000;
          }
        }
        if (uVar12 == 0xfffc) {
          iVar29 = (int)((*puVar11 >> 0x20 & 0xffff) >> 5);
        }
        uStack_f4 = uStack_f4 + iVar29;
        uVar30 = (ulonglong)uStack_f4;
        pbVar15 = pbStack_f0;
      }
      if (((byte *)CONCAT62(uStack_d8,uStack_da) != (byte *)0x0) &&
         ((byte *)CONCAT62(uStack_d8,uStack_da) < pbVar15 + uVar30)) {
        *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x10179e;
        cVar5 = func_0x(0x19f5650);
        if (cVar5 != '\0') {
          *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1017a7;
          lVar10 = func_0x();
          if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1017c1;
            cVar5 = func_0x(0x19f5650);
            if (cVar5 == '\0') {
              *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1017dd;
              (*pcRam0000000000f631d8)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(auStack_230 + lVar1 + lVar9 + -8) = 0;
              *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x101800;
              (*pcRam0000000000f631d0)(1,0x12e505c,0x1405148,0x886);
            }
          }
        }
        pbVar31 = pbStack_f0;
        *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x101811;
        func_0x(pbVar31,0x12);
        uVar30 = (ulonglong)uStack_f4;
        pbVar15 = pbStack_f0;
      }
      if (0x3f3b < (int)uVar30 - 1U) {
        *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x10183a;
        cVar5 = func_0x(0x19f5650);
        if (cVar5 != '\0') {
          *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x101843;
          lVar10 = func_0x();
          if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x10185d;
            cVar5 = func_0x(0x19f5650);
            if (cVar5 == '\0') {
              *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x101879;
              (*pcRam0000000000f631d8)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(auStack_230 + lVar1 + lVar9 + -8) = 0;
              *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x10189c;
              (*pcRam0000000000f631d0)(1,0x12e505c,0x1405148,0x88b);
            }
          }
        }
        pbVar31 = pbStack_f0;
        *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1018ad;
        func_0x(pbVar31,5);
        pbVar15 = pbStack_f0;
      }
    }
  }
  else if (uVar21 == 0) {
    *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x1018ea;
    func_0x(&uStack_f6);
    pbVar15 = pbStack_f0;
  }
code_r0x00101911:
  uVar8 = uStack_158;
  *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x101920;
  func_0x(uVar8,pbVar15);
  pbStack_1a0 = pbVar28;
  if ((*pbVar28 & 1) == 0) {
    uStack_1a8 = 0;
    uVar20 = 0;
    uStack_182 = 0;
    uStack_180 = 0;
    switch(*pbVar28 & 0xe) {
    default:
      uVar20 = (uint)*(ushort *)(pbVar28 + 2);
      if (0x1f9d < *(ushort *)(pbVar28 + 2) - 1) {
        *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x101abf;
        func_0x(pbVar28,6);
      }
      break;
    case 4:
      uVar20 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar20 = 1;
    }
    uStack_198 = CONCAT44(uStack_198._4_4_,uVar20);
  }
  else {
    uStack_1a8 = 1;
    bVar6 = *pbVar28;
    switch(bVar6 & 0x1c) {
    default:
      if ((char)pbVar28[1] < '\0') {
        uStack_1a6 = (*(ushort *)(pbVar28 + 1) & 0x7f) << 8 | *(ushort *)(pbVar28 + 1) >> 8;
        uStack_190 = 3;
      }
      else {
        uStack_1a6 = (ushort)pbVar28[1];
        uStack_190 = 2;
        uStack_170 = CONCAT22(uStack_170._2_2_,2);
      }
      sStack_18c = ((ushort)(uStack_1a6 + 1) >> 1) + (short)uStack_170;
      if (uStack_1a6 < 0x1f) {
        uStack_178 = 0;
      }
      else {
        iVar29 = uStack_1a6 - 1;
        uStack_190 = CONCAT22(((short)(iVar29 / 0x1e) + (short)(iVar29 >> 0x1f)) -
                              (short)((longlong)iVar29 * 0x88888889 >> 0x3f),(undefined2)uStack_190)
        ;
        uStack_178 = 0;
      }
      break;
    case 4:
      if (((bVar6 & 0x1c) == 4) && ((bVar6 & 2) != 0)) {
        uStack_1a4 = 0xf;
        uStack_190 = 0;
        uStack_1a6 = 0;
        sStack_18c = 0;
        uStack_182 = 0;
        uStack_178 = 1;
      }
      else {
        uStack_1a4 = 1;
        uStack_190 = 0;
        uStack_1a6 = 0;
        sStack_18c = 0;
        uStack_182 = 0;
        uStack_178 = 0;
      }
      break;
    case 8:
      uStack_1a4 = 9;
      uStack_190 = 0;
      uStack_1a6 = 0;
      sStack_18c = 0;
      uStack_182 = 0;
      uStack_178 = 0;
    }
  }
  uVar14 = 0;
  uVar30 = uVar14;
  do {
    uVar24 = uVar30 >> 3;
    if ((pbStack_f0[uVar24 + 4] >> ((byte)uVar14 & 7) & 1) != 0) {
      pbStack_1a0[uVar24 + 4] = pbStack_1a0[uVar24 + 4] | (byte)(1 << ((uint)uVar14 & 7));
    }
    uVar20 = (uint)uVar14 + 1;
    uVar14 = (ulonglong)uVar20;
    uVar30 = uVar30 + 1;
  } while (uVar20 < 0xf9a0);
  uVar30 = (ulonglong)uStack_134;
  iStack_120 = 0;
  lStack_108 = uVar30 * 0x10 + 0x38 + lVar7;
  uStack_138 = 2;
  lStack_118 = uVar30 * 8 + 0x1c + lStack_108;
  uStack_13c = 0;
  lStack_110 = lStack_118 + uVar30 * 4;
  lStack_128 = lStack_110 + uVar30 * 2;
  lStack_100 = lVar7;
  if (sStack_f8 == 0) {
    *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x101bbf;
    func_0x();
  }
  else {
    *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x101bc6;
    func_0x(&uStack_f6,&uStack_1a6,auStack_148);
  }
  pplVar4 = pplStack_150;
  lVar7 = lStack_160;
  if (iStack_120 != 0) {
    *(undefined8 *)((longlong)auStack_1c8 + lVar1 + lVar9) = 0;
    auStack_1d0[lVar1 + lVar9] = 0;
    *(undefined4 *)((longlong)auStack_1d8 + lVar1 + lVar9) = 0;
    *(undefined8 *)((longlong)&uStack_1e0 + lVar1 + lVar9) = 0;
    *(undefined4 *)((longlong)auStack_1e8 + lVar1 + lVar9) = 0;
    *(undefined8 *)((longlong)&uStack_1f0 + lVar1 + lVar9) = 0;
    *(undefined4 *)((longlong)auStack_1f8 + lVar1 + lVar9) = 0;
    *(undefined8 *)((longlong)&uStack_200 + lVar1 + lVar9) = 0;
    auStack_208[lVar1 + lVar9] = 0;
    *(undefined8 *)((longlong)alStack_218 + lVar1 + lVar9 + 8) = 0;
    *(longlong *)((longlong)alStack_218 + lVar1 + lVar9) = lVar7;
    *(undefined4 *)((longlong)auStack_228 + lVar1 + lVar9 + 8) = 0;
    *(undefined4 *)((longlong)auStack_228 + lVar1 + lVar9) = 0;
    auStack_230[lVar1 + lVar9] = 6;
    *(undefined **)(auStack_230 + lVar1 + lVar9 + -8) = auStack_148;
    *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x101c3b;
    func_0x(pplVar4,0,0x1a40f30,1);
  }
  uVar30 = uStack_48 ^ (ulonglong)&uStack_1b8;
  *(undefined8 *)((longlong)auStack_260 + lVar1 + lVar9) = 0x101c4a;
  func_0x(uVar30);
  return;
}

