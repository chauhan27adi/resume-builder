
/* WARNING: Control flow encountered bad instruction data */

undefined8
FUN_(longlong param_1,longlong param_2,uint param_3,uint param_4,uint param_5,uint param_6,
            undefined4 param_7,undefined4 param_8,undefined8 param_9)

{
  undefined4 uVar1;
  uint uVar2;
  undefined8 uVar3;
  char *pcVar4;
  ulonglong uVar5;
  longlong lVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  int iVar11;
  
  uVar2 = param_5;
  uVar8 = (ulonglong)param_3;
  iVar11 = param_5 - param_3;
  param_5 = 0;
  uVar7 = (ulonglong)uVar2;
  uVar5 = (ulonglong)param_4;
  do {
    if (uVar8 < uVar7) {
      lVar6 = uVar8 - uVar5;
      pcVar4 = (char *)(param_2 + uVar5);
      do {
        uVar9 = uVar8;
        if (param_6 <= uVar5) goto LAB_;
        if (pcVar4[(lVar6 - param_2) + param_1] != *pcVar4) break;
        uVar8 = uVar8 + 1;
        uVar5 = uVar5 + 1;
        pcVar4 = pcVar4 + 1;
      } while (uVar8 < uVar7);
    }
    uVar9 = uVar8;
    if ((uVar8 == uVar7) && (uVar5 == param_6)) {
      return 0;
    }
LAB_:
    if ((param_5 == 0) && (iVar11 != param_6 - param_4)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar8 = uVar9 + 1;
    uVar10 = uVar5 + 1;
    if (uVar8 < uVar7) {
      do {
        if ((param_6 <= uVar10) || (*(char *)(uVar8 + param_1) == *(char *)(param_2 + uVar10)))
        break;
        uVar8 = uVar8 + 1;
        uVar10 = uVar10 + 1;
      } while (uVar8 < uVar7);
    }
    uVar1 = param_8;
    if (param_5 == 0) {
      uVar1 = param_7;
    }
    uVar3 = func_0x(param_9,uVar9 & 0xffffffff,uVar5 & 0xffffffff,(int)uVar8 - (int)uVar9,
                            (int)uVar10 - (int)uVar5,uVar9 + param_1,uVar5 + param_2,uVar1);
    param_5 = param_5 + 1;
    uVar5 = uVar10;
    if ((int)uVar3 != 0) {
      return uVar3;
    }
  } while( true );
}

