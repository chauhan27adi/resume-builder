
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint param_2,longlong param_3)

{
  int *piVar1;
  byte bVar2;
  short sVar3;
  ushort uVar4;
  int iVar5;
  uint uVar6;
  undefined8 uVar7;
  char cVar8;
  short sVar9;
  longlong lVar10;
  ulonglong uVar11;
  short *psVar12;
  short sVar13;
  ulonglong uVar14;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar15;
  undefined8 unaff_RBX;
  undefined *puVar16;
  byte *pbVar17;
  longlong lVar18;
  short sVar19;
  undefined2 uVar20;
  int iVar21;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar10 = func_0x();
  lVar10 = -lVar10;
  piVar1 = (int *)(&stack0x00000078 + lVar10);
  *(undefined8 *)(&stack0x00001380 + lVar10) = unaff_RBX;
  *(ulonglong *)(&stack0x00001328 + lVar10) = _DAT_ ^ (ulonglong)piVar1;
  sVar3 = *(short *)(param_3 + 6);
  iVar21 = 0;
  iVar5 = *(int *)(param_3 + 0x18);
  *(ushort *)(&stack0x00000086 + lVar10) = *(ushort *)(&stack0x00000086 + lVar10) & 0xffe0;
  cVar8 = *(char *)(param_3 + 1);
  *(longlong *)(&stack0x00000148 + lVar10) = param_3;
  *(uint *)(&stack0x000000c0 + lVar10) = param_2;
  *(longlong *)(&stack0x00000128 + lVar10) = param_1;
  *(undefined4 *)(&stack0x000000e0 + lVar10) = 0;
  *(undefined4 *)(&stack0x000000e4 + lVar10) = 0xffffffff;
  *(undefined8 *)(&stack0x000000e8 + lVar10) = 0;
  *(undefined2 *)(&stack0x000000fa + lVar10) = 0;
  *(undefined8 *)(&stack0x000000fc + lVar10) = 0;
  *(int *)(&stack0x000000f0 + lVar10) = iVar5;
  *(short *)(&stack0x000000f4 + lVar10) = sVar3;
  *(undefined2 *)(&stack0x000000f6 + lVar10) = 0;
  sVar19 = (short)(param_2 >> 0x10);
  *(short *)(&stack0x000000f8 + lVar10) = sVar19;
  *(undefined4 *)(&stack0x00000080 + lVar10) = 0;
  *(undefined2 *)(&stack0x00000084 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000088 + lVar10) = 0;
  puVar16 = &stack0xffffffffffffffc8 + lVar10;
  if ((byte)(cVar8 - 1U) < 2) {
    uVar6 = iVar5 + (param_2 >> 0x10);
    lVar18 = (ulonglong)
             ((uVar6 >> 10) + (uVar6 >> 0x14) + uVar6 &
             *(uint *)(*(longlong *)(param_1 + 0x2b8) + 0x1c)) * 0x10 +
             *(longlong *)(*(longlong *)(param_1 + 0x2b8) + 0x10);
    lVar15 = *(longlong *)(lVar18 + 8);
LAB_:
    if ((lVar15 == lVar18) || (lVar15 == 0)) goto LAB_;
    if (*(int *)(lVar15 + 0x10) == iVar5) {
      sVar13 = 0;
      if (*(short *)(lVar15 + 0x14) != 1) {
        sVar13 = *(short *)(lVar15 + 0x14);
      }
      sVar9 = sVar3;
      if (sVar3 == 1) {
        sVar9 = 0;
      }
      if ((sVar13 == sVar9) && (*(short *)(lVar15 + 0x16) == sVar19)) {
        if (lVar15 != 0) {
          *(undefined4 *)(&stack0x000000e0 + lVar10) =
               *(undefined4 *)(*(longlong *)(lVar15 + 0x20) + 0x18);
          *(undefined4 *)(&stack0x000000e4 + lVar10) =
               *(undefined4 *)(*(longlong *)(lVar15 + 0x20) + 0x1c);
          uVar7 = *(undefined8 *)(*(longlong *)(lVar15 + 0x20) + 0x28);
          *(undefined4 *)(&stack0x000000fc + lVar10) =
               *(undefined4 *)(*(longlong *)(lVar15 + 0x20) + 0x20);
          *(undefined8 *)(&stack0x000000e8 + lVar10) = uVar7;
          *(undefined2 *)(&stack0x000000f8 + lVar10) =
               *(undefined2 *)(*(longlong *)(lVar15 + 0x20) + 0x30);
          *(undefined2 *)(&stack0x000000fa + lVar10) =
               *(undefined2 *)(*(longlong *)(lVar15 + 0x18) + 0x38);
          puVar16 = &stack0xffffffffffffffc8 + lVar10;
          if ((*(longlong *)(lVar15 + 0x30) == 0) ||
             (puVar16 = &stack0xffffffffffffffc8 + lVar10,
             (*(byte *)(*(longlong *)(lVar15 + 0x30) + 0x18) & 4) == 0)) goto LAB_;
          lVar15 = *(longlong *)(*(longlong *)(lVar15 + 0x20) + 0x80);
          *(longlong *)(&stack0x000000d8 + lVar10) = lVar15;
          lVar15 = *(longlong *)(lVar15 + 8);
          if ((*(byte *)(lVar15 + 0x42) & 4) == 0) {
            uVar6 = *(uint *)(lVar15 + 0xb0);
            uVar11 = (ulonglong)uVar6;
            if (0x1f9e < uVar6) {
              uVar11 = 0x1f9e;
            }
          }
          else {
            uVar11 = 0x1f9e;
          }
          uVar14 = uVar11 + 0xf;
          *(int *)(&stack0x0000009c + lVar10) = (int)uVar11;
          if (uVar14 <= uVar11) {
            uVar14 = 0xffffffffffffff0;
          }
          uVar14 = uVar14 & 0xfffffffffffffff0;
          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1001e6;
          func_0x();
          uVar4 = *(ushort *)(param_3 + 0x16);
          lVar15 = -uVar14;
          *piVar1 = 0;
          *(undefined **)(&stack0x00000158 + lVar10) = &stack0x00000078 + lVar15 + lVar10;
          puVar16 = &stack0xffffffffffffffc8 + lVar15 + lVar10;
          if ((ulonglong)uVar4 == 0) goto LAB_;
          psVar12 = (short *)(param_3 + 0x1ffe);
          lVar18 = 0;
          goto LAB_;
        }
LAB_:
        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10203e;
        func_0x(&stack0x000000e0 + lVar10);
        puVar16 = &stack0xffffffffffffffc8 + lVar10;
        goto LAB_;
      }
    }
    lVar15 = *(longlong *)(lVar15 + 8);
    goto LAB_;
  }
  goto LAB_;
  while( true ) {
    iVar21 = iVar21 + 1;
    lVar18 = lVar18 + 1;
    psVar12 = psVar12 + -1;
    *piVar1 = iVar21;
    puVar16 = &stack0xffffffffffffffc8 + lVar15 + lVar10;
    if ((longlong)(ulonglong)uVar4 <= lVar18) break;
LAB_:
    if (*psVar12 != 0) {
      puVar16 = &stack0xffffffffffffffc8 + lVar15 + lVar10;
      if (iVar21 != -1) {
        lVar18 = param_3 + 0x2000;
        if (param_3 == 0) {
          lVar18 = 0;
        }
        *(longlong *)(&stack0x00000090 + lVar10) = lVar18;
        cVar8 = *(char *)(param_3 + 2);
        *(undefined2 *)(&stack0x00000160 + lVar10) = 0xffff;
        *(undefined8 *)(&stack0x00000168 + lVar10) = 0;
        *(undefined4 *)(&stack0x00000164 + lVar10) = 0;
        *(undefined8 *)(&stack0x0000017e + lVar10) = 0;
        *(undefined8 *)(&stack0x00000188 + lVar10) = 0;
        *(undefined8 *)(&stack0x00000170 + lVar10) = 0;
        *(undefined4 *)(&stack0x00000194 + lVar10) = 0xffffffff;
        *(undefined2 *)(&stack0x00000210 + lVar10) = 0xffff;
        *(undefined8 *)(&stack0x00000218 + lVar10) = 0;
        *(undefined4 *)(&stack0x00000214 + lVar10) = 0;
        *(undefined8 *)(&stack0x0000022e + lVar10) = 0;
        *(undefined8 *)(&stack0x00000238 + lVar10) = 0;
        *(undefined8 *)(&stack0x00000220 + lVar10) = 0;
        *(int *)(&stack0x00000244 + lVar10) = iVar21;
        if (-1 < cVar8) goto LAB_;
        pbVar17 = (byte *)(param_3 + 0x60);
        *(undefined (*) [16])(&stack0x00000258 + lVar10) = ZEXT816(0);
        *(undefined8 *)(&stack0x000002b8 + lVar10) = 0;
        *(undefined (*) [16])(&stack0x00000268 + lVar10) = ZEXT816(0);
        *(undefined2 *)(&stack0x00000258 + lVar10) = 0xffff;
        *(undefined (*) [16])(&stack0x00000278 + lVar10) = ZEXT816(0);
        *(undefined8 *)(&stack0x00000260 + lVar10) = 0;
        *(undefined (*) [16])(&stack0x000002a8 + lVar10) = ZEXT816(0);
        *(undefined4 *)(&stack0x0000025c + lVar10) = 0;
        *(undefined (*) [16])(&stack0x00000288 + lVar10) = ZEXT816(0);
        *(undefined8 *)(&stack0x00000276 + lVar10) = 0;
        *(undefined8 *)(&stack0x00000280 + lVar10) = 0;
        *(undefined8 *)(&stack0x00000268 + lVar10) = 0;
        *(undefined8 *)(&stack0x00000290 + lVar10) = 0;
        *(undefined8 *)(&stack0x000002a8 + lVar10) = 0;
        *(undefined4 *)(&stack0x000002b0 + lVar10) = 0;
        *(undefined2 *)(&stack0x000002ba + lVar10) = 0;
        *(undefined (*) [16])(&stack0x00000298 + lVar10) = ZEXT816(0);
        *(undefined (*) [16])(&stack0x00000248 + lVar10) = ZEXT816(0);
        if (*(short *)(param_3 + 0x24) == 0) {
LAB_:
          uVar20 = *(undefined2 *)(param_3 + 0x30);
          *(undefined8 *)(&stack0x000000a0 + lVar10) = *(undefined8 *)(param_3 + 0x28);
          *(undefined2 *)(&stack0x000000a8 + lVar10) = uVar20;
        }
        else {
          cVar8 = *(char *)(param_3 + 1);
          if (cVar8 == '\v') {
            if (*(int *)(param_3 + 0x18) != 99) {
LAB_:
              if (cVar8 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar8 != '\b') goto LAB_;
LAB_:
            if (*(int *)(param_3 + 0x18) != 99) goto LAB_;
          }
          *(undefined4 *)(&stack0x000000c8 + lVar10) = *(undefined4 *)(param_3 + 0x20);
          *(undefined2 *)(&stack0x000000cc + lVar10) = *(undefined2 *)(param_3 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar15 + lVar10) = 0x1003a5;
          cVar8 = func_0x(&stack0x000000c8 + lVar10);
          if (cVar8 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar15 + lVar10) = 0x1003b5;
          func_0x(param_3,&stack0x000000a0 + lVar10);
          uVar20 = *(undefined2 *)(&stack0x000000a8 + lVar10);
        }
        bVar2 = *pbVar17;
        *(undefined4 *)(&stack0x000002a8 + lVar10) = *(undefined4 *)(&stack0x000000a0 + lVar10);
        *(int *)(&stack0x000002ac + lVar10) =
             (int)((ulonglong)*(undefined8 *)(&stack0x000000a0 + lVar10) >> 0x20);
        *(undefined4 *)(&stack0x000002b4 + lVar10) = *(undefined4 *)(param_3 + 0x20);
        *(undefined2 *)(&stack0x000002b8 + lVar10) = *(undefined2 *)(param_3 + 0x24);
        *(undefined2 *)(&stack0x000002b0 + lVar10) = uVar20;
        lVar18 = (ulonglong)bVar2 * 6;
        *(byte **)(&stack0x00000248 + lVar10) = pbVar17;
        uVar11 = (ulonglong)*(short *)(lVar18 + 0xb66aa4);
        *(undefined4 *)(&stack0x00000130 + lVar10) = *(undefined4 *)(lVar18 + 0xb66aa0);
        *(undefined2 *)(&stack0x000002ba + lVar10) = 0;
        *(undefined2 *)(&stack0x00000258 + lVar10) = 0xffff;
        *(undefined8 *)(&stack0x00000260 + lVar10) = 0;
        *(undefined4 *)(&stack0x0000025c + lVar10) = 0;
        *(undefined8 *)(&stack0x00000276 + lVar10) = 0;
        *(undefined8 *)(&stack0x00000280 + lVar10) = 0;
        *(undefined8 *)(&stack0x00000268 + lVar10) = 0;
        *(undefined2 *)(&stack0x000002a0 + lVar10) = 0;
        *(undefined (*) [16])(&stack0x00000290 + lVar10) = ZEXT816(0);
        if ((bVar2 & 2) != 0) {
          bVar2 = pbVar17[uVar11];
          pbVar17 = pbVar17 + uVar11;
          *(byte **)(&stack0x00000260 + lVar10) = pbVar17;
          if ((bVar2 & 1) == 0) {
            *(undefined2 *)(&stack0x00000258 + lVar10) = 0;
            *(undefined4 *)(&stack0x0000027e + lVar10) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100683 */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar17 & 0xe) * 4 + 0x102098) -
                      0x1a32370))();
            return;
          }
          *(undefined2 *)(&stack0x00000258 + lVar10) = 1;
          UNRECOVERED_JUMPTABLE_00 =
               (code *)((ulonglong)
                        *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar17 & 0x1c) + 0x102078)
                                  * 4 + 0x102068) - 0x1a32370);
                    /* WARNING: Could not emulate address calculation at 0x001004b2 */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
          return;
        }
        if ((**(byte **)(&stack0x00000248 + lVar10) & 4) != 0) {
          if (*(short *)(&stack0x00000132 + lVar10) != 0) {
            uVar11 = (ulonglong)
                     *(ushort *)
                      (param_3 + 0x61 + (longlong)*(short *)(&stack0x00000132 + lVar10) * 2);
          }
          psVar12 = (short *)(pbVar17 + uVar11);
          *(short **)(&stack0x00000290 + lVar10) = psVar12;
          sVar3 = *psVar12;
          *(short **)(&stack0x00000298 + lVar10) = psVar12 + 1;
          *(short *)(&stack0x000002a0 + lVar10) = (sVar3 + 1) * 2;
        }
        lVar18 = *(longlong *)(&stack0x00000250 + lVar10);
        if (lVar18 != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15 + lVar10) = 0x10075b;
          func_0x(lVar18,&stack0x00000248 + lVar10);
        }
        iVar21 = *piVar1;
LAB_:
        pbVar17 = (byte *)((ulonglong)*(ushort *)((0xfff - (longlong)iVar21) * 2 + param_3) +
                          param_3);
        bVar2 = *pbVar17;
        *(byte **)(&stack0x00000218 + lVar10) = pbVar17;
        if ((bVar2 & 1) == 0) {
          *(undefined2 *)(&stack0x00000210 + lVar10) = 0;
          *(undefined4 *)(&stack0x00000214 + lVar10) = 0;
          *(undefined4 *)(&stack0x00000236 + lVar10) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001009d3 */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar17 & 0xe) * 4 + 0x102104) -
                    0x1a32370))
                    (0xfff - (longlong)iVar21,(longlong)(int)(*pbVar17 & 0xe),pbVar17,pbVar17);
          return;
        }
        *(undefined2 *)(&stack0x00000210 + lVar10) = 1;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar17 & 0x1c) + 0x1020e4) *
                                4 + 0x1020d4) - 0x1a32370);
                    /* WARNING: Could not emulate address calculation at 0x001007b9 */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
        return;
      }
      break;
    }
  }
LAB_:
  uVar11 = *(ulonglong *)(&stack0x00001328 + lVar10);
  *(undefined8 *)(puVar16 + -8) = 0x10204d;
  func_0x(uVar11 ^ (ulonglong)piVar1);
  return;
}

