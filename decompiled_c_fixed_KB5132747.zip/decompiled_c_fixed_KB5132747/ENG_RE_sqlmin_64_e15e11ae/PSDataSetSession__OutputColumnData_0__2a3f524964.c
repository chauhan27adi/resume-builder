
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,undefined8 *param_3)

{
  ushort *puVar1;
  byte bVar2;
  char cVar3;
  ushort uVar4;
  ushort uVar5;
  short *psVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong lVar9;
  byte *pbVar10;
  code *UNRECOVERED_JUMPTABLE;
  ulonglong uVar11;
  uint uVar12;
  uint uVar13;
  undefined *puVar14;
  short sVar15;
  int iVar16;
  uint uVar17;
  uint *puVar18;
  ulonglong uVar19;
  byte *pbVar20;
  ulonglong uVar21;
  uint uVar22;
  uint *puVar23;
  uint *puVar24;
  ushort *puVar25;
  ushort *puVar26;
  longlong *plVar27;
  longlong lVar28;
  undefined8 uStack_3b0;
  undefined auStack_3a8 [32];
  undefined8 uStack_388;
  undefined auStack_368 [24];
  undefined4 uStack_350;
  uint uStack_34c;
  uint uStack_348;
  longlong *plStack_340;
  undefined4 uStack_338;
  uint uStack_334;
  undefined8 uStack_330;
  undefined4 uStack_314;
  undefined8 uStack_310;
  longlong lStack_308;
  ushort *puStack_300;
  longlong lStack_2f8;
  int iStack_2c8;
  int aiStack_2c4 [16];
  int iStack_284;
  uint uStack_280;
  int aiStack_27c [2];
  uint uStack_274;
  int iStack_270;
  int aiStack_26c [20];
  undefined auStack_21c [4];
  undefined auStack_218 [4];
  undefined auStack_214 [4];
  undefined auStack_210 [4];
  int iStack_20c;
  undefined auStack_208 [4];
  int iStack_204;
  undefined auStack_200 [8];
  undefined auStack_1f8 [8];
  undefined auStack_1f0 [88];
  undefined *puStack_198;
  ulonglong uStack_40;
  
  uStack_40 = _DAT_ ^ (ulonglong)auStack_368;
  plStack_340 = param_2;
  if ((*(short *)(*param_2 + 0x3a) == 0) && (*(int *)(*param_2 + 0x50) == 0)) {
    uStack_3b0 = 0x10005d;
    psVar6 = (short *)(**(code **)*param_3)(param_3);
    lVar7 = *param_2;
    puVar25 = (ushort *)(param_1 + 0x110);
    puVar18 = (uint *)0x0;
    lStack_2f8 = param_1 + 0xf68;
    uStack_330 = psVar6;
    puStack_300 = puVar25;
    if ((*(byte *)(lVar7 + 0x30) & 1) != 0) {
      puVar1 = (ushort *)(psVar6 + 1);
      uVar22 = 0;
      if (*psVar6 == 0) {
        if ((**(byte **)(psVar6 + 4) & 0x10) != 0) {
          uVar22 = (uint)*(ushort *)(*(byte **)(psVar6 + 4) + *(uint *)(psVar6 + 8));
        }
      }
      else {
        uVar22 = (uint)*puVar1;
      }
      if (*(uint *)(lVar7 + 0x18) <= uVar22) {
        *psVar6 = 0;
        uStack_34c = 0;
        puVar23 = (uint *)plStack_340[1];
        uStack_348 = (uint)*(ushort *)(*plStack_340 + 0x62);
        puVar14 = auStack_3a8;
        puVar24 = puVar18;
        plVar27 = plStack_340;
        if (uStack_348 != 0) {
          do {
            uVar22 = (uint)puVar24;
            cVar3 = *(char *)(puVar23 + 0x10);
            if (cVar3 == '\x01') {
              if ((*(byte *)((longlong)puVar23 + 6) & 0x10) == 0) {
                uVar12 = *(byte *)((ulonglong)(*(ushort *)(puVar23 + 1) - 1 >> 3) +
                                   (ulonglong)*(uint *)(psVar6 + 8) + 2 + *(longlong *)(psVar6 + 4))
                         >> ((byte)(*(ushort *)(puVar23 + 1) - 1) & 7) & 1;
              }
              else {
                uStack_388 = &iStack_204;
                uStack_3b0 = 0x10131d;
                func_0x(puVar1,puVar23,1,&uStack_280);
                uVar12 = uStack_280;
              }
              if (uVar12 == 0) goto LAB_;
LAB_:
              if ((*(byte *)(*(longlong *)(puVar23 + 0x12) + 0x2a) & 0x10) == 0) {
                *(undefined *)(plVar27[3] + *(longlong *)(puVar23 + 0xc)) = 3;
              }
              else {
                *(undefined *)(plVar27[4] + *(longlong *)(puVar23 + 0xc)) = 3;
              }
            }
            else {
              if (cVar3 == '\x02') {
LAB_:
                uVar5 = *(ushort *)(puVar23 + 0xf);
                if ((*(byte *)((longlong)puVar23 + 6) & 0x10) == 0) {
LAB_:
                  puVar18 = (uint *)((longlong)(int)*puVar23 + *(longlong *)(psVar6 + 4));
                  uVar12 = (uint)uVar5;
                }
                else {
                  uStack_388 = &iStack_284;
                  uStack_3b0 = 0x1013b4;
                  func_0x(puVar1,puVar23,0,auStack_200);
                  if (iStack_284 != 0) goto LAB_;
                  uVar12 = **(uint **)(puVar23 + 2);
                  puVar18 = *(uint **)(puVar23 + 2) + 1;
                  if ((uVar5 != 0) && (uVar12 != uVar5)) {
                    uStack_388 = (int *)0x0;
                    uStack_3b0 = 0x1013f6;
                    (*_DAT_)(1,0xa79b90,0xa784f8,0x381);
                  }
                }
                uStack_334 = uVar12;
                if ((*(byte *)(*(longlong *)(puVar23 + 0x12) + 0x2a) & 0x10) == 0) {
LAB_:
                  lVar7 = plVar27[3];
                }
                else {
                  lVar7 = plVar27[4];
                }
LAB_:
                *(undefined *)(lVar7 + *(longlong *)(puVar23 + 0xc)) = 0;
              }
              else {
                if (cVar3 == '\x03') {
                  if ((*(byte *)((longlong)puVar23 + 6) & 0x10) == 0) {
                    uVar12 = *(byte *)((ulonglong)(*(ushort *)(puVar23 + 1) - 1 >> 3) +
                                       (ulonglong)*(uint *)(psVar6 + 8) + 2 +
                                      *(longlong *)(psVar6 + 4)) >>
                             ((byte)(*(ushort *)(puVar23 + 1) - 1) & 7) & 1;
                  }
                  else {
                    uStack_388 = &iStack_20c;
                    uStack_3b0 = 0x100ab4;
                    func_0x(puVar1,puVar23,1,&uStack_274);
                    uVar12 = uStack_274;
                  }
                  if (uVar12 != 0) goto LAB_;
                }
                else if (cVar3 != '\x04') {
                  if (cVar3 == '\b') {
                    uVar5 = *(ushort *)(puVar23 + 0xf);
                    iVar16 = puVar23[0x10] << 0xc;
                    if ((*puVar23 & 0xc0000000) == 0x80000000) {
                      uStack_3b0 = 0x100a16;
                      iVar16 = func_0x(puVar1);
                      if (iVar16 != 0) {
                        uStack_3b0 = 0x100a31;
                        puVar18 = (uint *)func_0x
                                                    (psVar6 + 0x15,puVar23,&uStack_334,auStack_210);
                        uVar12 = uStack_334;
                        goto LAB_;
                      }
                      uStack_334 = 0;
                      puVar18 = (uint *)0x0;
                      uVar5 = *(ushort *)(*(longlong *)(puVar23 + 0x12) + 0x2a);
LAB_:
                      if ((uVar5 & 0x10) == 0) {
                        *(undefined *)(plVar27[3] + *(longlong *)(puVar23 + 0xc)) = 3;
                      }
                      else {
                        *(undefined *)(plVar27[4] + *(longlong *)(puVar23 + 0xc)) = 3;
                      }
                      goto LAB_;
                    }
                    if ((iVar16 < 0) || ((*(byte *)((longlong)puVar23 + 6) & 0x10) != 0)) {
                      uStack_388 = aiStack_2c4;
                      uStack_3b0 = 0x1001ae;
                      func_0x(puVar1,puVar23,iVar16 < 0,&iStack_2c8);
                      if ((iVar16 < 0) && (iStack_2c8 != 0)) {
                        puVar18 = (uint *)0x0;
                        uStack_334 = 0;
                        uVar12 = uStack_334;
                        goto LAB_;
                      }
                    }
                    else {
                      iStack_2c8 = 0;
                      aiStack_2c4[0] = 1;
                    }
                    if ((aiStack_2c4[0] == 0) && ((*(byte *)((longlong)puVar23 + 6) & 0x10) != 0)) {
                      puVar18 = *(uint **)(puVar23 + 2) + 1;
                      uVar12 = **(uint **)(puVar23 + 2);
                    }
                    else if ((int)*puVar23 < 0) {
                      if (*(int *)(psVar6 + 2) == 0) {
                        *puVar1 = 0;
                        uVar12 = *(uint *)(psVar6 + 8);
                        uVar11 = (ulonglong)uVar12;
                        *(uint *)(psVar6 + 10) = uVar12;
                        pbVar20 = *(byte **)(psVar6 + 4);
                        bVar2 = *pbVar20;
                        if ((bVar2 & 0x10) != 0) {
                          uVar12 = uVar12 + (*(ushort *)(pbVar20 + uVar11) + 7 >> 3) + 2;
                          uVar11 = (ulonglong)uVar12;
                          *(uint *)(psVar6 + 10) = uVar12;
                          bVar2 = *pbVar20;
                        }
                        if ((bVar2 & 0x20) == 0) {
                          *(int *)(psVar6 + 2) = (int)uVar11;
                          psVar6[0xe] = 0;
                          *(uint *)(psVar6 + 0xc) = uVar12;
                        }
                        else {
                          puVar25 = (ushort *)(pbVar20 + uVar11);
                          uVar5 = *puVar25;
                          psVar6[0xe] = uVar5;
                          puStack_300 = puVar25;
                          if (uVar5 == 0) {
                            uStack_3b0 = 0x100306;
                            cVar3 = func_0x(0xfdbd40);
                            if (cVar3 != '\0') {
                              uStack_3b0 = 0x10030f;
                              lVar7 = func_0x();
                              if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                                uStack_3b0 = 0x100329;
                                cVar3 = func_0x(0xfdbd40);
                                if (cVar3 == '\0') {
                                  uStack_3b0 = 0x100345;
                                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                }
                                else {
                                  uStack_388 = (int *)0x0;
                                  uStack_3b0 = 0x100383;
                                  (*_DAT_)(1,0x8cb74c,0x9eb838,0x80f);
                                }
                              }
                            }
                            uStack_3b0 = 0x100356;
                            func_0x(*(undefined8 *)(psVar6 + 4),3);
                            uVar5 = psVar6[0xe];
                            uVar12 = *(uint *)(psVar6 + 10);
                          }
                          uVar12 = uVar12 + (uVar5 + 1) * 2;
                          *(uint *)(psVar6 + 0xc) = uVar12;
                          if (0x1f9e < uVar12) {
                            uStack_3b0 = 0x1003b0;
                            cVar3 = func_0x(0xfdbd40);
                            if (cVar3 != '\0') {
                              uStack_3b0 = 0x1003b9;
                              lVar7 = func_0x();
                              if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                                uStack_3b0 = 0x1003d3;
                                cVar3 = func_0x(0xfdbd40);
                                if (cVar3 == '\0') {
                                  uStack_3b0 = 0x1003ef;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  uStack_388 = (int *)0x0;
                                  uStack_3b0 = 0x100412;
                                  (*_DAT_)(1,0x8cb74c,0x9eb838,0x816);
                                }
                              }
                            }
                            uStack_3b0 = 0x100420;
                            func_0x(*(undefined8 *)(psVar6 + 4),4);
                            uVar5 = psVar6[0xe];
                            uVar12 = *(uint *)(psVar6 + 0xc);
                          }
                          uVar11 = (ulonglong)uVar5;
                          uVar5 = puVar25[uVar11];
                          *(uint *)(psVar6 + 2) = uVar5 & 0x7fff;
                          if ((uVar5 & 0x7fff) < uVar12) {
                            uStack_3b0 = 0x10044e;
                            cVar3 = func_0x(0xfdbd40);
                            if (cVar3 != '\0') {
                              uStack_3b0 = 0x100457;
                              lVar7 = func_0x();
                              if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                                uStack_3b0 = 0x100471;
                                cVar3 = func_0x(0xfdbd40);
                                if (cVar3 == '\0') {
                                  uStack_3b0 = 0x10048d;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  uStack_388 = (int *)0x0;
                                  uStack_3b0 = 0x1004b0;
                                  (*_DAT_)(1,0x8cb74c,0x9eb838,0x81d);
                                }
                              }
                            }
                            uStack_3b0 = 0x1004be;
                            func_0x(*(undefined8 *)(psVar6 + 4),4);
                            uVar12 = *(uint *)(psVar6 + 0xc);
                            uVar11 = (ulonglong)(ushort)psVar6[0xe];
                          }
                          iVar16 = 0;
                          puVar26 = puVar25;
                          if ((short)uVar11 != 0) {
                            do {
                              puVar25 = puVar25 + 1;
                              uVar17 = *puVar25 & 0x7fff;
                              if ((uVar17 < uVar12) || (*(uint *)(psVar6 + 2) < uVar17)) {
                                uStack_3b0 = 0x1004ff;
                                cVar3 = func_0x(0xfdbd40);
                                if (cVar3 != '\0') {
                                  uStack_3b0 = 0x100508;
                                  lVar7 = func_0x();
                                  if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                                    uStack_3b0 = 0x100522;
                                    cVar3 = func_0x(0xfdbd40);
                                    if (cVar3 == '\0') {
                                      uStack_3b0 = 0x10053e;
                                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                    }
                                    else {
                                      uStack_388 = (int *)0x0;
                                      uStack_3b0 = 0x100562;
                                      (*_DAT_)(1,0x8cb74c,0x9eb838,0x82a);
                                    }
                                  }
                                }
                                uStack_3b0 = 0x100570;
                                func_0x(*(undefined8 *)(psVar6 + 4),4);
                              }
                              uVar11 = (ulonglong)(ushort)psVar6[0xe];
                              iVar16 = iVar16 + 1;
                              puVar26 = puStack_300;
                              uVar22 = uStack_34c;
                              uVar12 = uVar17;
                            } while (iVar16 < (int)(uint)(ushort)psVar6[0xe]);
                          }
                          if ((short)puVar26[(ulonglong)((int)uVar11 - 1) + 1] < 0) {
                            do {
                              lVar7 = (ulonglong)*(uint *)(psVar6 + 10) + *(longlong *)(psVar6 + 4);
                              uVar12 = *(ushort *)(lVar7 + uVar11 * 2) & 0x7fff;
                              if ((int)uVar11 == 1) {
                                uVar17 = *(uint *)(psVar6 + 0xc);
                                uVar13 = uVar17;
LAB_:
                                if ((uVar12 < uVar17) || (*(uint *)(psVar6 + 2) < uVar12))
                                goto LAB_;
                              }
                              else {
                                uVar13 = *(uint *)(psVar6 + 0xc);
                                uVar17 = *(ushort *)(lVar7 + -2 + uVar11 * 2) & 0x7fff;
                                if (uVar13 <= uVar17) goto LAB_;
LAB_:
                                uStack_3b0 = 0x1005ec;
                                func_0x(*(longlong *)(psVar6 + 4),7);
                                uVar13 = *(uint *)(psVar6 + 0xc);
                              }
                              if ((uVar17 < uVar13) || (*(uint *)(psVar6 + 2) < uVar17))
                              goto LAB_;
                              if (*(ushort *)((ulonglong)uVar17 + *(longlong *)(psVar6 + 4)) == 5) {
                                *puVar1 = *puVar1 | 2;
                                psVar6[0xe] = psVar6[0xe] + -1;
                                psVar6[0x15] = (short)uVar17;
                                uVar11 = *(ulonglong *)(psVar6 + 4);
                                uVar4 = psVar6[0x16] & 0xc7ff;
                                uVar5 = *(ushort *)((ulonglong)(uVar17 & 0xffff) + 2 + uVar11);
                                if ((uVar5 >> 0xe & 1) != 0) {
                                  uVar4 = uVar5 & 0x3800 | uVar4;
                                }
                                psVar6[0x16] = uVar4;
                                uVar5 = (uVar4 ^ *(ushort *)
                                                  ((ulonglong)(uVar17 & 0xffff) + 2 + uVar11)) &
                                        0x7ff ^ uVar4;
                                psVar6[0x16] = uVar5;
                                uVar21 = (ulonglong)(ushort)psVar6[0x15];
                                uVar19 = (ulonglong)((uVar5 & 0x7ff) * 2) + 4 +
                                         uVar21 + (uVar4 >> 0xb & 7) * 2 + uVar11;
                                if (uVar19 < uVar21 + uVar11) {
                                  uStack_3b0 = 0x1006fe;
                                  func_0x(uVar21 + uVar11,0x19);
                                  uVar5 = psVar6[0x16];
                                  uVar21 = (ulonglong)(ushort)psVar6[0x15];
                                  uVar11 = (ulonglong)*(uint *)(psVar6 + 4);
                                }
                                if (uVar12 - uVar17 <
                                    (((uVar5 & 0x7ff) * 2 - (int)uVar21) - (int)uVar11) +
                                    (int)uVar19) {
                                  uStack_3b0 = 0x100736;
                                  func_0x(uVar21 + *(longlong *)(psVar6 + 4),0x19);
                                  uVar5 = psVar6[0x16];
                                }
                                iVar16 = 0;
                                if (((uVar5 & 0x3800) != 0) &&
                                   (puVar25 = (ushort *)
                                              (*(longlong *)(psVar6 + 4) + 4 +
                                              (ulonglong)(ushort)psVar6[0x15]),
                                   (uVar5 & 0x3800) != 0)) {
                                  do {
                                    if ((uVar5 & 0x7ff) < (*puVar25 & 0x7ff)) {
                                      uStack_3b0 = 0x100797;
                                      func_0x
                                                ((ulonglong)(ushort)psVar6[0x15] +
                                                 *(longlong *)(psVar6 + 4),0x1a);
                                      uVar5 = psVar6[0x16];
                                    }
                                    iVar16 = iVar16 + 1;
                                    puVar25 = puVar25 + 1;
                                  } while (iVar16 < (int)(uVar5 >> 0xb & 7));
                                }
                                goto LAB_;
                              }
                              if (*(ushort *)((ulonglong)uVar17 + *(longlong *)(psVar6 + 4)) < 0x400
                                 ) goto LAB_;
                              *puVar1 = *puVar1 | 1;
                              uVar5 = psVar6[0xe] - 1;
                              psVar6[0xe] = uVar5;
                              if (uVar5 == 0) goto LAB_;
                              uVar11 = (ulonglong)uVar5;
                            } while ((short)puVar26[(ulonglong)(uVar5 - 1) + 1] < 0);
                            pbVar20 = *(byte **)(psVar6 + 4);
                          }
                          else {
LAB_:
                            pbVar20 = *(byte **)(psVar6 + 4);
                          }
                        }
                        if ((*pbVar20 & 0x40) == 0) {
                          *(undefined4 *)(psVar6 + 0x13) = 0;
                        }
                        else {
                          *(int *)(psVar6 + 0x13) = *(int *)(psVar6 + 2);
                          *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + 0xe;
                          uStack_3b0 = 0x1007e5;
                          uVar8 = func_0x(puVar1);
                          uStack_3b0 = 0x1007f4;
                          func_0x(uVar8,auStack_1f8);
                          uStack_3b0 = 0x100800;
                          iVar16 = func_0x(auStack_1f8);
                          *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + iVar16;
                        }
                        uVar12 = *(uint *)(psVar6 + 2);
                        if ((*(ulonglong *)(psVar6 + 0xf) != 0) &&
                           (*(ulonglong *)(psVar6 + 0xf) <
                            (ulonglong)uVar12 + *(longlong *)(psVar6 + 4))) {
                          uStack_3b0 = 0x100834;
                          cVar3 = func_0x(0xfdbd40);
                          if (cVar3 != '\0') {
                            uStack_3b0 = 0x10083d;
                            lVar7 = func_0x();
                            if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                              uStack_3b0 = 0x100857;
                              cVar3 = func_0x(0xfdbd40);
                              if (cVar3 == '\0') {
                                uStack_3b0 = 0x100873;
                                (*_DAT_)(0x22,0x44,0x15,0x3fa);
                              }
                              else {
                                uStack_388 = (int *)0x0;
                                uStack_3b0 = 0x100898;
                                (*_DAT_)(1,0x8cb74c,0x9eb838,0x886);
                              }
                            }
                          }
                          uStack_3b0 = 0x1008a6;
                          func_0x(*(undefined8 *)(psVar6 + 4),0x12);
                          uVar12 = *(uint *)(psVar6 + 2);
                        }
                        if (0x3f3b < uVar12 - 1) {
                          uStack_3b0 = 0x1008bf;
                          cVar3 = func_0x(0xfdbd40);
                          if (cVar3 != '\0') {
                            uStack_3b0 = 0x1008c8;
                            lVar7 = func_0x();
                            if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                              uStack_3b0 = 0x1008e2;
                              cVar3 = func_0x(0xfdbd40);
                              if (cVar3 == '\0') {
                                uStack_3b0 = 0x1008fe;
                                (*_DAT_)(0x22,0x44,0x15,0x3ed);
                              }
                              else {
                                uStack_388 = (int *)0x0;
                                uStack_3b0 = 0x100923;
                                (*_DAT_)(1,0x8cb74c,0x9eb838,0x88b);
                              }
                            }
                          }
                          uStack_3b0 = 0x100931;
                          func_0x(*(undefined8 *)(psVar6 + 4),5);
                        }
                      }
LAB_:
                      sVar15 = -*(short *)puVar23;
                      if ((*(byte *)((longlong)puVar23 + 6) & 0x10) != 0) {
                        uStack_388 = &iStack_270;
                        uStack_3b0 = 0x100962;
                        func_0x(puVar1,puVar23,0,auStack_214);
                        if (iStack_270 == 0) {
                          puVar18 = *(uint **)(puVar23 + 2) + 1;
                          plVar27 = plStack_340;
                          uVar12 = **(uint **)(puVar23 + 2);
                          goto LAB_;
                        }
                      }
                      lVar7 = (longlong)sVar15;
                      if ((uint)(ushort)psVar6[0xe] < (uint)(int)sVar15) {
                        uStack_334 = 0;
                        puVar18 = *(uint **)(psVar6 + 4);
                        plVar27 = plStack_340;
                        uVar12 = uStack_334;
                      }
                      else {
                        lVar28 = *(longlong *)(psVar6 + 4);
                        lVar9 = (ulonglong)*(uint *)(psVar6 + 10) + lVar28;
                        if (sVar15 == 1) {
                          uVar17 = *(ushort *)(lVar9 + lVar7 * 2) & 0x7fff;
                          uVar12 = *(uint *)(uStack_330 + 0xc);
LAB_:
                          if ((uVar17 < uVar12) || (*(uint *)(psVar6 + 2) < uVar17))
                          goto LAB_;
                        }
                        else {
                          uVar12 = *(ushort *)(lVar9 + -2 + lVar7 * 2) & 0x7fff;
                          uVar17 = *(ushort *)(lVar9 + lVar7 * 2) & 0x7fff;
                          lVar28 = *(longlong *)(psVar6 + 4);
                          if (*(uint *)(uStack_330 + 0xc) <= uVar12) goto LAB_;
LAB_:
                          uStack_3b0 = 0x1009ee;
                          func_0x(lVar28,7);
                        }
                        puVar18 = (uint *)((ulonglong)uVar12 + *(longlong *)(psVar6 + 4));
                        plVar27 = plStack_340;
                        uVar12 = uVar17 - uVar12;
                      }
                    }
                    else if ((*(ushort *)((longlong)puVar23 + 6) & 8) == 0) {
                      if ((*(ushort *)((longlong)puVar23 + 6) & 0x10) != 0) {
                        uStack_388 = aiStack_26c;
                        uStack_3b0 = 0x10022b;
                        func_0x(puVar1,puVar23,0,auStack_218);
                        if (aiStack_26c[0] == 0) {
                          uVar12 = **(uint **)(puVar23 + 2);
                          puVar18 = *(uint **)(puVar23 + 2) + 1;
                          if ((uVar5 != 0) && (uVar12 != uVar5)) {
                            uStack_388 = (int *)0x0;
                            uStack_3b0 = 0x10026f;
                            (*_DAT_)(1,0xa79b90,0xa784f8,0x381);
                          }
                          goto LAB_;
                        }
                      }
                      puVar18 = (uint *)((longlong)(int)*puVar23 + *(longlong *)(psVar6 + 4));
                      uVar12 = (uint)uVar5;
                    }
                    else {
                      uStack_3b0 = 0x100297;
                      puVar18 = (uint *)func_0x(puVar1,puVar23);
                      uVar12 = uStack_334;
                    }
LAB_:
                    uStack_334 = uVar12;
                    uVar5 = *(ushort *)(*(longlong *)(puVar23 + 0x12) + 0x2a);
                    if (puVar18 == (uint *)0x0) goto LAB_;
                    if ((uVar5 & 0x10) == 0) goto LAB_;
                    lVar7 = plVar27[4];
                    goto LAB_;
                  }
                  uStack_388 = (int *)0x646cb0;
                  uStack_3b0 = 0x100140;
                  (*_DAT_)(1,0xa4d040,0xa79a08,0x27d);
                  goto LAB_;
                }
                if (*(int *)(psVar6 + 2) == 0) {
                  *puVar1 = 0;
                  uVar12 = *(uint *)(psVar6 + 8);
                  uVar11 = (ulonglong)uVar12;
                  *(uint *)(psVar6 + 10) = uVar12;
                  pbVar20 = *(byte **)(psVar6 + 4);
                  bVar2 = *pbVar20;
                  pbVar10 = pbVar20;
                  if ((bVar2 & 0x10) != 0) {
                    uVar12 = uVar12 + (*(ushort *)(pbVar20 + uVar11) + 7 >> 3) + 2;
                    uVar11 = (ulonglong)uVar12;
                    *(uint *)(psVar6 + 10) = uVar12;
                    bVar2 = *pbVar20;
                    pbVar10 = *(byte **)(psVar6 + 4);
                  }
                  if ((bVar2 & 0x20) == 0) {
                    *(int *)(psVar6 + 2) = (int)uVar11;
                    psVar6[0xe] = 0;
                    *(uint *)(psVar6 + 0xc) = uVar12;
                  }
                  else {
                    puVar25 = (ushort *)(pbVar20 + uVar11);
                    uVar5 = *puVar25;
                    psVar6[0xe] = uVar5;
                    puStack_300 = puVar25;
                    if (uVar5 == 0) {
                      uStack_3b0 = 0x100b67;
                      cVar3 = func_0x(0xfdbd40);
                      if (cVar3 != '\0') {
                        uStack_3b0 = 0x100b70;
                        lVar7 = func_0x();
                        if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                          uStack_3b0 = 0x100b8a;
                          cVar3 = func_0x(0xfdbd40);
                          if (cVar3 == '\0') {
                            uStack_3b0 = 0x100ba6;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            uStack_388 = (int *)0x0;
                            uStack_3b0 = 0x100bcb;
                            (*_DAT_)(1,0x8cb74c,0x9eb838,0x80f);
                          }
                        }
                      }
                      uStack_3b0 = 0x100bd7;
                      func_0x(*(undefined8 *)(psVar6 + 4),3);
                      uVar5 = psVar6[0xe];
                      uVar12 = *(uint *)(psVar6 + 10);
                    }
                    uVar12 = uVar12 + (uVar5 + 1) * 2;
                    *(uint *)(psVar6 + 0xc) = uVar12;
                    if (0x1f9e < uVar12) {
                      uStack_3b0 = 0x100c07;
                      cVar3 = func_0x(0xfdbd40);
                      if (cVar3 != '\0') {
                        uStack_3b0 = 0x100c10;
                        lVar7 = func_0x();
                        if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                          uStack_3b0 = 0x100c2a;
                          cVar3 = func_0x(0xfdbd40);
                          if (cVar3 == '\0') {
                            uStack_3b0 = 0x100c46;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            uStack_388 = (int *)0x0;
                            uStack_3b0 = 0x100c6b;
                            (*_DAT_)(1,0x8cb74c,0x9eb838,0x816);
                          }
                        }
                      }
                      uStack_3b0 = 0x100c79;
                      func_0x(*(undefined8 *)(psVar6 + 4),4);
                      uVar5 = psVar6[0xe];
                      uVar12 = *(uint *)(psVar6 + 0xc);
                    }
                    uVar11 = (ulonglong)uVar5;
                    uVar5 = puVar25[uVar11];
                    *(uint *)(psVar6 + 2) = uVar5 & 0x7fff;
                    if ((uVar5 & 0x7fff) < uVar12) {
                      uStack_3b0 = 0x100ca7;
                      cVar3 = func_0x(0xfdbd40);
                      if (cVar3 != '\0') {
                        uStack_3b0 = 0x100cb0;
                        lVar7 = func_0x();
                        if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                          uStack_3b0 = 0x100cca;
                          cVar3 = func_0x(0xfdbd40);
                          if (cVar3 == '\0') {
                            uStack_3b0 = 0x100ce6;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            uStack_388 = (int *)0x0;
                            uStack_3b0 = 0x100d0b;
                            (*_DAT_)(1,0x8cb74c,0x9eb838,0x81d);
                          }
                        }
                      }
                      uStack_3b0 = 0x100d19;
                      func_0x(*(undefined8 *)(psVar6 + 4),4);
                      uVar12 = *(uint *)(psVar6 + 0xc);
                      uVar11 = (ulonglong)(ushort)psVar6[0xe];
                    }
                    iVar16 = 0;
                    puVar26 = puVar25;
                    if ((short)uVar11 != 0) {
                      do {
                        puVar25 = puVar25 + 1;
                        uVar17 = *puVar25 & 0x7fff;
                        if ((uVar17 < uVar12) || (*(uint *)(psVar6 + 2) < uVar17)) {
                          uStack_3b0 = 0x100d5f;
                          cVar3 = func_0x(0xfdbd40);
                          if (cVar3 != '\0') {
                            uStack_3b0 = 0x100d68;
                            lVar7 = func_0x();
                            if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                              uStack_3b0 = 0x100d82;
                              cVar3 = func_0x(0xfdbd40);
                              if (cVar3 == '\0') {
                                uStack_3b0 = 0x100d9e;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                uStack_388 = (int *)0x0;
                                uStack_3b0 = 0x100dc2;
                                (*_DAT_)(1,0x8cb74c,0x9eb838,0x82a);
                              }
                            }
                          }
                          uStack_3b0 = 0x100dd0;
                          func_0x(*(undefined8 *)(psVar6 + 4),4);
                        }
                        uVar11 = (ulonglong)(ushort)psVar6[0xe];
                        iVar16 = iVar16 + 1;
                        puVar26 = puStack_300;
                        uVar22 = uStack_34c;
                        uVar12 = uVar17;
                      } while (iVar16 < (int)(uint)(ushort)psVar6[0xe]);
                    }
                    if ((short)puVar26[(ulonglong)((int)uVar11 - 1) + 1] < 0) {
                      do {
                        lVar7 = *(longlong *)(psVar6 + 4);
                        uVar12 = *(ushort *)((ulonglong)*(uint *)(psVar6 + 10) + lVar7 + uVar11 * 2)
                                 & 0x7fff;
                        if ((int)uVar11 == 1) {
                          uVar17 = *(uint *)(psVar6 + 0xc);
                          uVar13 = uVar17;
LAB_:
                          if ((uVar12 < uVar17) || (*(uint *)(psVar6 + 2) < uVar12))
                          goto LAB_;
                        }
                        else {
                          uVar13 = *(uint *)(psVar6 + 0xc);
                          uVar17 = *(ushort *)
                                    ((ulonglong)*(uint *)(psVar6 + 10) + lVar7 + -2 + uVar11 * 2) &
                                   0x7fff;
                          if (uVar13 <= uVar17) goto LAB_;
LAB_:
                          uStack_3b0 = 0x100e4c;
                          func_0x(lVar7,7);
                          uVar13 = *(uint *)(psVar6 + 0xc);
                          lVar7 = *(longlong *)(psVar6 + 4);
                        }
                        if ((uVar17 < uVar13) || (*(uint *)(psVar6 + 2) < uVar17))
                        goto LAB_;
                        if (*(ushort *)((ulonglong)uVar17 + lVar7) == 5) {
                          *puVar1 = *puVar1 | 2;
                          psVar6[0xe] = psVar6[0xe] + -1;
                          psVar6[0x15] = (short)uVar17;
                          uVar11 = *(ulonglong *)(psVar6 + 4);
                          uVar4 = psVar6[0x16] & 0xc7ff;
                          uVar5 = *(ushort *)((ulonglong)(uVar17 & 0xffff) + 2 + uVar11);
                          if ((uVar5 >> 0xe & 1) != 0) {
                            uVar4 = uVar5 & 0x3800 | uVar4;
                          }
                          psVar6[0x16] = uVar4;
                          uVar5 = (uVar4 ^ *(ushort *)((ulonglong)(uVar17 & 0xffff) + 2 + uVar11)) &
                                  0x7ff ^ uVar4;
                          psVar6[0x16] = uVar5;
                          uVar21 = (ulonglong)(ushort)psVar6[0x15];
                          uVar19 = (ulonglong)((uVar5 & 0x7ff) * 2) + 4 +
                                   uVar11 + (uVar4 >> 0xb & 7) * 2 + uVar21;
                          if (uVar19 < uVar21 + uVar11) {
                            uStack_3b0 = 0x100f5f;
                            func_0x(uVar21 + uVar11,0x19);
                            uVar5 = psVar6[0x16];
                            uVar21 = (ulonglong)(ushort)psVar6[0x15];
                            uVar11 = (ulonglong)*(uint *)(psVar6 + 4);
                          }
                          if (uVar12 - uVar17 <
                              (((uVar5 & 0x7ff) * 2 - (int)uVar21) - (int)uVar11) + (int)uVar19) {
                            uStack_3b0 = 0x100f97;
                            func_0x(uVar21 + *(longlong *)(psVar6 + 4),0x19);
                            uVar5 = psVar6[0x16];
                          }
                          iVar16 = 0;
                          if (((uVar5 & 0x3800) != 0) &&
                             (puVar25 = (ushort *)
                                        (*(longlong *)(psVar6 + 4) + 4 +
                                        (ulonglong)(ushort)psVar6[0x15]), (uVar5 & 0x3800) != 0)) {
                            do {
                              if ((uVar5 & 0x7ff) < (*puVar25 & 0x7ff)) {
                                uStack_3b0 = 0x100ff7;
                                func_0x
                                          ((ulonglong)(ushort)psVar6[0x15] +
                                           *(longlong *)(psVar6 + 4),0x1a);
                                uVar5 = psVar6[0x16];
                              }
                              iVar16 = iVar16 + 1;
                              puVar25 = puVar25 + 1;
                            } while (iVar16 < (int)(uVar5 >> 0xb & 7));
                          }
                          goto LAB_;
                        }
                        if (*(ushort *)((ulonglong)uVar17 + lVar7) < 0x400) goto LAB_;
                        *puVar1 = *puVar1 | 1;
                        uVar5 = psVar6[0xe] - 1;
                        psVar6[0xe] = uVar5;
                        if (uVar5 == 0) goto LAB_;
                        uVar11 = (ulonglong)uVar5;
                      } while ((short)puVar26[(ulonglong)(uVar5 - 1) + 1] < 0);
                      pbVar10 = *(byte **)(psVar6 + 4);
                    }
                    else {
LAB_:
                      pbVar10 = *(byte **)(psVar6 + 4);
                    }
                  }
                  if ((*pbVar10 & 0x40) == 0) {
                    *(undefined4 *)(psVar6 + 0x13) = 0;
                  }
                  else {
                    *(int *)(psVar6 + 0x13) = *(int *)(psVar6 + 2);
                    *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + 0xe;
                    uStack_3b0 = 0x101045;
                    uVar8 = func_0x(puVar1);
                    uStack_3b0 = 0x101054;
                    func_0x(uVar8,auStack_1f0);
                    uStack_3b0 = 0x101060;
                    iVar16 = func_0x(auStack_1f0);
                    *(int *)(psVar6 + 2) = *(int *)(psVar6 + 2) + iVar16;
                    pbVar10 = *(byte **)(psVar6 + 4);
                  }
                  uVar12 = *(uint *)(psVar6 + 2);
                  if ((*(byte **)(psVar6 + 0xf) != (byte *)0x0) &&
                     (*(byte **)(psVar6 + 0xf) < pbVar10 + uVar12)) {
                    uStack_3b0 = 0x101097;
                    cVar3 = func_0x(0xfdbd40);
                    if (cVar3 != '\0') {
                      uStack_3b0 = 0x1010a0;
                      lVar7 = func_0x();
                      if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                        uStack_3b0 = 0x1010ba;
                        cVar3 = func_0x(0xfdbd40);
                        if (cVar3 == '\0') {
                          uStack_3b0 = 0x1010d6;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          uStack_388 = (int *)0x0;
                          uStack_3b0 = 0x1010fb;
                          (*_DAT_)(1,0x8cb74c,0x9eb838,0x886);
                        }
                      }
                    }
                    uStack_3b0 = 0x101109;
                    func_0x(*(undefined8 *)(psVar6 + 4),0x12);
                    uVar12 = *(uint *)(psVar6 + 2);
                  }
                  if (0x3f3b < uVar12 - 1) {
                    uStack_3b0 = 0x101122;
                    cVar3 = func_0x(0xfdbd40);
                    if (cVar3 != '\0') {
                      uStack_3b0 = 0x10112b;
                      lVar7 = func_0x();
                      if ((lVar7 != 0) && (*(char *)(lVar7 + 0x499) != '\0')) {
                        uStack_3b0 = 0x101145;
                        cVar3 = func_0x(0xfdbd40);
                        if (cVar3 == '\0') {
                          uStack_3b0 = 0x101161;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          uStack_388 = (int *)0x0;
                          uStack_3b0 = 0x101186;
                          (*_DAT_)(1,0x8cb74c,0x9eb838,0x88b);
                        }
                      }
                    }
                    uStack_3b0 = 0x101194;
                    func_0x(*(undefined8 *)(psVar6 + 4),5);
                  }
                }
LAB_:
                sVar15 = -*(short *)puVar23;
                if ((*(byte *)((longlong)puVar23 + 6) & 0x10) == 0) {
LAB_:
                  lVar7 = (longlong)sVar15;
                  if ((uint)(ushort)psVar6[0xe] < (uint)(int)sVar15) {
                    uStack_334 = 0;
                    puVar18 = *(uint **)(psVar6 + 4);
                  }
                  else {
                    lVar28 = *(longlong *)(psVar6 + 4);
                    lVar9 = (ulonglong)*(uint *)(psVar6 + 10) + lVar28;
                    if (sVar15 == 1) {
                      uVar12 = *(ushort *)(lVar9 + lVar7 * 2) & 0x7fff;
                      uVar11 = (ulonglong)*(uint *)(uStack_330 + 0xc);
LAB_:
                      if ((uVar12 < (uint)uVar11) || (*(uint *)(psVar6 + 2) < uVar12))
                      goto LAB_;
                    }
                    else {
                      uVar17 = *(ushort *)(lVar9 + -2 + lVar7 * 2) & 0x7fff;
                      uVar11 = (ulonglong)uVar17;
                      uVar12 = *(ushort *)(lVar9 + lVar7 * 2) & 0x7fff;
                      lVar28 = *(longlong *)(psVar6 + 4);
                      if (*(uint *)(uStack_330 + 0xc) <= uVar17) goto LAB_;
LAB_:
                      uStack_3b0 = 0x10124d;
                      func_0x(lVar28,7);
                    }
                    uStack_334 = uVar12 - (int)uVar11;
                    puVar18 = (uint *)(uVar11 + *(longlong *)(psVar6 + 4));
                  }
                }
                else {
                  uStack_388 = aiStack_27c;
                  uStack_3b0 = 0x1011c5;
                  func_0x(puVar1,puVar23,0,auStack_208);
                  if (aiStack_27c[0] != 0) goto LAB_;
                  uStack_334 = **(uint **)(puVar23 + 2);
                  puVar18 = *(uint **)(puVar23 + 2) + 1;
                }
                plVar27 = plStack_340;
                if (((puVar23[0x10] & 0x2000) != 0) && (uStack_334 == 0)) {
                  uStack_334 = 4;
                  puVar18 = (uint *)0x672314;
                }
                if ((*(byte *)(*(longlong *)(puVar23 + 0x12) + 0x2a) & 0x10) == 0) {
                  lVar7 = plStack_340[3];
                }
                else {
                  lVar7 = plStack_340[4];
                }
                *(undefined *)(lVar7 + *(longlong *)(puVar23 + 0xc)) = 0;
                if ((1 << (**(byte **)(psVar6 + 4) & 0xe) & 0x440U) != 0) {
                  uStack_3b0 = 0x1012c2;
                  iVar16 = func_0x(puVar23);
                  if (iVar16 != 0) goto LAB_;
                }
                if (*(ushort *)(puVar23 + 0xf) < uStack_334) {
                  uStack_3b0 = 0x1012ef;
                  (*_DAT_)(6,0x52,0x16,0x91);
                }
              }
LAB_:
              uVar11 = (ulonglong)uStack_334;
              lVar7 = *(longlong *)(puVar23 + 0x12);
              if ((puVar23[0x10] & 0x800) == 0) {
                if ((*(byte *)(lVar7 + 0x2a) & 0x10) == 0) {
                  lVar7 = plVar27[3];
                }
                else {
                  lVar7 = plVar27[4];
                }
                uStack_3b0 = 0x10145b;
                func_0x(lVar7 + *(longlong *)(puVar23 + 10),puVar18);
              }
              else {
                uVar5 = *(ushort *)(lVar7 + 0x2a) & 0x10;
                if (*(int *)(lVar7 + 0x10) == 10) {
                  if (uVar5 == 0) {
                    lVar7 = plVar27[3];
                  }
                  else {
                    lVar7 = plVar27[4];
                  }
                  *(uint **)(lVar7 + *(longlong *)(puVar23 + 10)) = puVar18;
                }
                else {
                  if (uVar5 == 0) {
                    lVar7 = plVar27[3];
                  }
                  else {
                    lVar7 = plVar27[4];
                  }
                  uStack_3b0 = 0x101491;
                  func_0x
                            (*(undefined8 *)(*(longlong *)(puVar23 + 10) + lVar7),puVar18);
                }
              }
              if ((puVar23[0x10] & 0x100) != 0) {
                if ((*(byte *)(*(longlong *)(puVar23 + 0x12) + 0x2a) & 0x10) == 0) {
                  lVar7 = plVar27[3];
                }
                else {
                  lVar7 = plVar27[4];
                }
                *(ulonglong *)(lVar7 + *(longlong *)(*(longlong *)(puVar23 + 0x12) + 0x18)) = uVar11
                ;
              }
            }
LAB_:
            uStack_34c = uVar22 + 1;
            puVar23 = puVar23 + 0x14;
            puVar14 = auStack_3a8;
            puVar24 = (uint *)(ulonglong)uStack_34c;
          } while (uStack_34c < uStack_348);
        }
        goto LAB_;
      }
    }
    *(undefined8 *)(param_1 + 0xf70) = 0;
    *(undefined8 **)(param_1 + 0xf78) = param_3;
    uStack_3b0 = 0x101516;
    uStack_310 = (**(code **)*param_3)(param_3);
    *(undefined8 *)(param_1 + 0xf70) = uStack_310;
    if (*psVar6 == 0) {
      *psVar6 = 0;
      puVar14 = auStack_3a8;
      if ((*(byte *)((longlong)plStack_340 + 0x14) & 0x10) != 0) {
        uVar22 = *(uint *)(plStack_340 + 2);
        lVar7 = plStack_340[1];
        uStack_348 = 0;
        puVar14 = auStack_3a8;
        uStack_34c = uVar22;
        lStack_308 = lVar7;
        if (uVar22 != 0) {
          do {
            uVar12 = uStack_348;
            lStack_308 = lVar7;
            if (*(byte *)(lVar7 + 0x40) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(lVar7 + 0x40) * 4 + 0x107328) -
                           0x1ed3880);
                    /* WARNING: Could not emulate address calculation at 0x0010158f */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,1);
              return;
            }
            uVar17 = *(uint *)(lVar7 + 0x40);
            if ((uVar17 >> 10 & 1) != 0) {
              if ((*(byte *)(*(longlong *)(lVar7 + 0x48) + 0x2a) & 0x10) == 0) {
                lVar28 = plStack_340[3];
              }
              else {
                lVar28 = plStack_340[4];
              }
              *(undefined *)(lVar28 + *(longlong *)(lVar7 + 0x30)) = 3;
              uVar17 = *(uint *)(lVar7 + 0x40);
            }
            if ((uVar17 >> 9 & 1) != 0) {
              uStack_388 = (int *)CONCAT44(uStack_388._4_4_,uStack_338);
              uStack_3b0 = 0x103d46;
              func_0x(plStack_340,puStack_300,lVar7,0);
            }
            uStack_348 = uVar12 + 1;
            lVar7 = lVar7 + 0x50;
          } while (uStack_348 < uVar22);
          uStack_3b0 = 0x103d84;
          lStack_308 = lVar7;
          (**(code **)(**(longlong **)(lStack_2f8 + 0x10) + 8))(*(longlong **)(lStack_2f8 + 0x10),1)
          ;
          puVar14 = auStack_3a8;
          goto LAB_;
        }
      }
    }
    else if (*(int *)(*(longlong *)(param_1 + 0x118) + 0x100) == 2) {
      uVar22 = *(uint *)(lVar7 + 0x34);
      uStack_330 = (short *)CONCAT44(uStack_330._4_4_,uVar22);
      uVar11 = (ulonglong)uVar22 + 0xf;
      if (uVar11 <= uVar22) {
        uVar11 = 0xffffffffffffff0;
      }
      uVar11 = uVar11 & 0xfffffffffffffff0;
      uStack_3b0 = 0x104740;
      func_0x();
      lVar7 = -uVar11;
      puStack_198 = auStack_368 + lVar7;
      puVar14 = auStack_3a8 + lVar7;
      if ((*(byte *)((longlong)plStack_340 + 0x14) & 0x10) != 0) {
        uStack_348 = *(uint *)(plStack_340 + 2);
        lVar28 = plStack_340[1];
        uStack_34c = 0;
        puVar14 = auStack_3a8 + lVar7;
        lStack_308 = lVar28;
        if (uStack_348 != 0) {
          do {
            puVar25 = puStack_300;
            plVar27 = plStack_340;
            lStack_308 = lVar28;
            if (*(byte *)(lVar28 + 0x40) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(lVar28 + 0x40) * 4 + 0x107678) -
                           0x1ed3880);
                    /* WARNING: Could not emulate address calculation at 0x0010479e */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
              return;
            }
            uVar22 = *(uint *)(lVar28 + 0x40);
            if ((uVar22 >> 10 & 1) != 0) {
              if ((*(byte *)(*(longlong *)(lVar28 + 0x48) + 0x2a) & 0x10) == 0) {
                lVar9 = plStack_340[3];
              }
              else {
                lVar9 = plStack_340[4];
              }
              *(undefined *)(lVar9 + *(longlong *)(lVar28 + 0x30)) = 3;
              uVar22 = *(uint *)(lVar28 + 0x40);
            }
            if ((uVar22 >> 9 & 1) != 0) {
              *(undefined4 *)((longlong)&uStack_388 + lVar7) = uStack_350;
              *(undefined8 *)(auStack_3a8 + lVar7 + -8) = 0x10729b;
              func_0x(plVar27,puVar25,lVar28,0);
            }
            lVar28 = lVar28 + 0x50;
            uStack_34c = uStack_34c + 1;
            puVar14 = auStack_3a8 + lVar7;
            lStack_308 = lVar28;
          } while (uStack_34c < uStack_348);
        }
      }
    }
    else {
      if (*psVar6 == -1) {
        *psVar6 = 1;
      }
      puVar14 = auStack_3a8;
      if ((*(byte *)((longlong)plStack_340 + 0x14) & 0x10) != 0) {
        uVar22 = *(uint *)(plStack_340 + 2);
        uVar12 = 0;
        lVar7 = plStack_340[1];
        puVar14 = auStack_3a8;
        if (uVar22 != 0) {
          do {
            if (*(byte *)(lVar7 + 0x40) < 0x1c) {
              UNRECOVERED_JUMPTABLE =
                   (code *)((ulonglong)
                            *(uint *)((longlong)(char)*(byte *)(lVar7 + 0x40) * 4 + 0x1074d0) -
                           0x1ed3880);
                    /* WARNING: Could not emulate address calculation at 0x00103def */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
              return;
            }
            uVar17 = *(uint *)(lVar7 + 0x40);
            if ((uVar17 >> 10 & 1) != 0) {
              if ((*(byte *)(*(longlong *)(lVar7 + 0x48) + 0x2a) & 0x10) == 0) {
                lVar28 = plStack_340[3];
              }
              else {
                lVar28 = plStack_340[4];
              }
              *(undefined *)(lVar28 + *(longlong *)(lVar7 + 0x30)) = 3;
              uVar17 = *(uint *)(lVar7 + 0x40);
            }
            if ((uVar17 >> 9 & 1) != 0) {
              uStack_388 = (int *)CONCAT44(uStack_388._4_4_,uStack_314);
              uStack_3b0 = 0x1046e4;
              func_0x(plStack_340,puVar25,lVar7,0);
            }
            uVar12 = uVar12 + 1;
            lVar7 = lVar7 + 0x50;
          } while (uVar12 < uVar22);
          uStack_3b0 = 0x104716;
          (**(code **)(**(longlong **)(lStack_2f8 + 0x10) + 8))(*(longlong **)(lStack_2f8 + 0x10),1)
          ;
          puVar14 = auStack_3a8;
          goto LAB_;
        }
      }
    }
    UNRECOVERED_JUMPTABLE = *(code **)(**(longlong **)(lStack_2f8 + 0x10) + 8);
    *(undefined8 *)(puVar14 + -8) = 0x1072e8;
    (*UNRECOVERED_JUMPTABLE)();
  }
  else {
    uStack_3b0 = 0x1072fc;
    func_0x(param_1,param_3,param_2,auStack_21c);
    puVar14 = auStack_3a8;
  }
LAB_:
  uVar11 = uStack_40 ^ (ulonglong)auStack_368;
  *(undefined8 *)(puVar14 + -8) = 0x10730b;
  func_0x(uVar11);
  return;
}

