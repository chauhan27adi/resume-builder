
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,ulonglong param_2,undefined8 param_3)

{
  code *pcVar1;
  longlong lVar2;
  char cVar3;
  int iVar4;
  longlong lVar5;
  longlong lVar6;
  undefined8 unaff_RBX;
  longlong lVar7;
  undefined8 unaff_RSI;
  undefined8 auStackX_10 [3];
  undefined8 uStack_30;
  
  uStack_30 = 0x100014;
  lVar5 = func_0x();
  lVar5 = -lVar5;
  *(undefined8 *)(&stack0x00000058 + lVar5) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000010c0 + lVar5) = unaff_RBX;
  *(undefined8 *)(&stack0x000010d0 + lVar5) = unaff_RSI;
  *(ulonglong *)(&stack0x00001078 + lVar5) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffd8 + lVar5);
  *(undefined8 *)((longlong)auStackX_10 + lVar5) = param_3;
  *(longlong **)(&stack0x00000028 + lVar5) = param_1;
  if (*(int *)((longlong)param_1 + 0xbc) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)((longlong)param_1 + 0xcc) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_1[0x24] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  pcVar1 = *(code **)(*param_1 + 0x168);
  *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x10008d;
  iVar4 = (*pcVar1)(param_1);
  if ((iVar4 != 0) || (lVar2 = param_1[9], _DAT_ != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar6 = *(longlong *)(lVar2 + 0x10);
  while (lVar6 != lVar2 + 8) {
    lVar7 = 0;
    if (lVar6 != 0) {
      lVar7 = lVar6 + -8;
    }
    if (lVar7 == 0) break;
    *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x100126;
    cVar3 = func_0x(lVar2,lVar7);
    if (cVar3 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar6 = *(longlong *)(lVar7 + 0x10);
  }
  if ((*(byte *)(param_1 + 0xd) & 4) == 0) {
    lVar2 = param_1[9];
    *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x1000db;
    func_0x(lVar2,1,param_2 & 0xffffffff,*(undefined8 *)((longlong)auStackX_10 + lVar5));
    *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x1000eb;
    func_0x(*(ulonglong *)(&stack0x00001078 + lVar5) ^
                    (ulonglong)(&stack0xffffffffffffffd8 + lVar5));
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

