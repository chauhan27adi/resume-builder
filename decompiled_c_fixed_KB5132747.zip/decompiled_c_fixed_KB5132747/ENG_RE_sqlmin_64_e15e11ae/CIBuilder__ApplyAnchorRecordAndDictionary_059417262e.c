
/* WARNING: Removing unreachable block (ram,0x00100206) */
/* WARNING: Heritage AFTER dead removal. Example location: s0xfffffffffffff4d0 : 0x0010021c */
/* WARNING: Removing unreachable block (ram,0x00100222) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_(longlong param_1,longlong param_2,longlong param_3,int param_4,longlong param_5,
                 undefined8 param_6,longlong *param_7)

{
  byte *pbVar1;
  ushort *puVar2;
  bool bVar3;
  char cVar4;
  short sVar5;
  ushort uVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  longlong lVar10;
  short *psVar11;
  byte **ppbVar12;
  longlong lVar13;
  undefined8 uVar14;
  ulonglong *puVar15;
  ushort uVar16;
  undefined4 uVar17;
  ulonglong uVar18;
  byte bVar19;
  uint uVar20;
  ulonglong uVar21;
  uint uVar22;
  undefined *puVar23;
  uint uVar24;
  ulonglong uVar25;
  ulonglong uVar26;
  uint uVar27;
  byte **ppbVar28;
  byte **ppbVar29;
  byte *pbVar30;
  byte *pbVar31;
  byte **ppbVar32;
  ushort *puVar33;
  ushort *puVar34;
  undefined auStack_ca8 [48];
  int aiStack_c78 [2];
  short *psStack_c70;
  short sStack_c68;
  ushort uStack_c66;
  uint uStack_c64;
  longlong lStack_c60;
  byte **ppbStack_c58;
  uint uStack_c50;
  ushort uStack_c4c;
  undefined8 uStack_c4a;
  undefined2 uStack_c42;
  undefined2 uStack_c40;
  ushort uStack_c3e;
  ushort uStack_c3c;
  undefined2 uStack_c3a;
  uint uStack_c30;
  longlong lStack_c28;
  longlong lStack_c20;
  undefined8 uStack_c18;
  short sStack_c10;
  uint uStack_c08;
  int iStack_c04;
  uint uStack_c00;
  undefined4 uStack_bfc;
  undefined2 uStack_bf8;
  longlong lStack_bf0;
  longlong lStack_be8;
  longlong lStack_be0;
  longlong *plStack_bd8;
  undefined4 uStack_bd0;
  ushort *puStack_bc8;
  undefined auStack_bc0 [8];
  longlong lStack_bb8;
  longlong lStack_bb0;
  short asStack_ba8 [2];
  undefined4 uStack_ba4;
  undefined8 uStack_ba0;
  undefined8 uStack_b98;
  undefined8 uStack_b8a;
  undefined8 uStack_b80;
  undefined8 uStack_b70;
  short sStack_b68;
  ushort uStack_b66;
  uint uStack_b64;
  byte *pbStack_b60;
  undefined8 uStack_b58;
  undefined4 uStack_b50;
  ushort uStack_b4c;
  undefined2 uStack_b4a;
  undefined6 uStack_b48;
  undefined2 uStack_b42;
  undefined2 uStack_b40;
  ushort uStack_b3e;
  ushort uStack_b3c;
  undefined2 uStack_b3a;
  undefined4 uStack_b38;
  uint uStack_b34;
  undefined auStack_b30 [16];
  undefined auStack_b20 [8];
  undefined8 uStack_b18;
  undefined8 uStack_b10;
  undefined6 uStack_b08;
  undefined2 uStack_b02;
  undefined6 uStack_b00;
  undefined2 uStack_afa;
  undefined8 uStack_af8;
  undefined auStack_af0 [16];
  undefined auStack_ae0 [16];
  undefined auStack_ad0 [16];
  undefined8 uStack_ac0;
  undefined auStack_ab8 [16];
  undefined auStack_aa8 [16];
  undefined8 uStack_a98;
  undefined8 uStack_a90;
  undefined8 uStack_a88;
  undefined4 uStack_60;
  ulonglong uStack_58;
  
  uStack_b70 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)aiStack_c78;
  lStack_bf0 = param_5;
  plStack_bd8 = param_7;
  asStack_ba8[0] = -1;
  ppbVar32 = (byte **)0x0;
  uStack_ba0 = 0;
  uStack_ba4 = 0;
  uStack_b8a = 0;
  uStack_b80 = 0;
  uStack_b98 = 0;
  sStack_b68 = -1;
  pbStack_b60 = (byte *)0x0;
  uStack_b64 = 0;
  uStack_b4a = 0;
  uStack_b48 = 0;
  uStack_b40 = 0;
  uStack_b3e = 0;
  uStack_b3c = 0;
  uStack_b3a = 0;
  uStack_b58 = (byte **)0x0;
  uStack_b34 = 0xffffffff;
  lStack_be0 = 0;
  sStack_c68 = -1;
  lStack_c60 = 0;
  uStack_c64 = 0;
  uStack_c4a = 0;
  uStack_c40 = 0;
  uStack_c3e = 0;
  uStack_c3c = 0;
  uStack_c3a = 0;
  ppbStack_c58 = (byte **)0x0;
  bVar19 = -(*(char *)(param_2 + 2) >> 7);
  uStack_c08 = (uint)bVar19;
  auStack_ab8 = ZEXT816(0);
  auStack_aa8 = ZEXT816(0);
  uStack_a98 = 0;
  uStack_a90 = 0;
  uStack_a88 = 0;
  uStack_60 = 0;
  puVar23 = auStack_ca8;
  aiStack_c78[0] = param_4;
  lStack_c28 = param_3;
  lStack_c20 = param_1;
  iStack_c04 = param_4;
  lStack_bb8 = param_3;
  lStack_bb0 = param_2;
  if ((bVar19 != 0) &&
     ((*(int *)(param_1 + 0x1fe4) != 0 || (puVar23 = auStack_ca8, *(int *)(param_1 + 0x1fe8) != 0)))
     ) {
    uStack_a98 = 0x100000000;
    uStack_b08 = 0;
    uStack_afa = auStack_ab8._6_2_;
    auStack_ae0 = auStack_ab8;
    auStack_b30 = auStack_ab8;
    stack0xfffffffffffff4e2 = auStack_ab8._2_14_;
    auStack_b20._0_2_ = 0xffff;
    uStack_b18 = 0;
    uStack_b02 = 0;
    uStack_b00 = 0;
    uStack_af8 = 0;
    uStack_b10 = 0;
    auStack_af0 = ZEXT816(0);
    auStack_ad0._0_12_ = ZEXT812(0);
    auStack_ad0._12_4_ = 0;
    uStack_ac0 = 0;
    uStack_b58 = (byte **)auStack_b30;
    uStack_60 = 0;
    uStack_a88 = 0;
    uStack_a90 = 0;
    uStack_a98 = 0x100000000;
    uStack_ac0 = 0;
    uStack_af8 = 0;
    uStack_afa = 0;
    uStack_b00 = 0;
    uStack_b02 = 0;
    uStack_b08 = 0;
    uStack_b10 = 0;
    uStack_b34 = 0xffffffff;
    uStack_b3a = 0;
    uStack_b3c = 0;
    uStack_b3e = 0;
    uStack_b40 = 0;
    uStack_b48 = 0;
    uStack_b4a = 0;
    pbStack_b60 = (byte *)0x0;
    uStack_b64 = 0;
    sStack_b68 = -1;
    uStack_b70 = 0xfffffffffffffffe;
    uStack_b80 = 0;
    uStack_b8a = 0;
    uStack_b98 = 0;
    uStack_ba0 = 0;
    uStack_ba4 = 0;
    asStack_ba8[0] = -1;
    lStack_be0 = 0;
    uStack_c3a = 0;
    uStack_c3c = 0;
    uStack_c3e = 0;
    uStack_c40 = 0;
    uStack_c4a = 0;
    ppbStack_c58 = (byte **)0x0;
    lStack_c60 = 0;
    uStack_c64 = 0;
    sStack_c68 = -1;
    lVar10 = func_0x();
    puVar23 = auStack_ca8 + -lVar10;
    lStack_be0 = (longlong)aiStack_c78 + -lVar10;
  }
  uStack_c30 = 0;
  if (0 < *(int *)(param_1 + 8)) {
    lStack_be8 = 0;
    ppbVar29 = ppbVar32;
    ppbVar28 = ppbVar32;
    iVar9 = param_4;
    do {
      lVar10 = 0xfff - lStack_be8;
      if (*(short *)(param_2 + lVar10 * 2) == 0) {
        *(undefined2 *)(param_5 + lStack_be8 * 2) = 0xffff;
        uStack_c30 = (uint)ppbVar28;
      }
      else {
        psStack_c70 = (short *)0x0;
        uStack_c00 = (int)ppbVar29 + 1;
        uStack_b34 = (uint)ppbVar28;
        uVar27 = 0;
        ppbVar29 = ppbVar32;
        if (*(char *)(param_2 + 2) < '\0') {
          pbVar30 = (byte *)(param_2 + 0x60);
          if ((sStack_b68 == 0) || (ppbVar29 = uStack_b58, uStack_b58 == (byte **)0x0)) {
            auStack_ae0 = ZEXT816(0);
            uStack_b08 = 0;
            uStack_afa = auStack_ae0._6_2_;
            uStack_afa = 0;
            auStack_b30 = auStack_ae0;
            stack0xfffffffffffff4e2 = auStack_ae0._2_14_;
            auStack_b20._0_2_ = 0xffff;
            uStack_b18 = 0;
            uStack_b02 = 0;
            uStack_b00 = 0;
            uStack_af8 = 0;
            uStack_b10 = 0;
            auStack_af0 = ZEXT816(0);
            auStack_ad0._0_12_ = ZEXT812(0);
            auStack_ad0._12_4_ = 0;
            uStack_ac0 = 0;
            ppbVar29 = (byte **)auStack_b30;
          }
          if (*(short *)(param_2 + 0x24) == 0) {
LAB_:
            uStack_c18 = *(undefined8 *)(param_2 + 0x28);
            sStack_c10 = *(short *)(param_2 + 0x30);
          }
          else {
            cVar4 = *(char *)(param_2 + 1);
            if (cVar4 == '\v') {
              if (*(int *)(param_2 + 0x18) != 99) {
LAB_:
                if (cVar4 != '\t') goto LAB_;
                goto LAB_;
              }
            }
            else {
              if (cVar4 != '\b') goto LAB_;
LAB_:
              if (*(int *)(param_2 + 0x18) != 99) goto LAB_;
            }
            uStack_bfc = *(undefined4 *)(param_2 + 0x20);
            uStack_bf8 = *(undefined2 *)(param_2 + 0x24);
            *(undefined8 *)(puVar23 + -8) = 0x1003e0;
            cVar4 = func_0x(&uStack_bfc);
            if (cVar4 == '\0') goto LAB_;
            *(undefined8 *)(puVar23 + -8) = 0x1003f0;
            func_0x(param_2,&uStack_c18);
          }
          iVar8 = (int)((ulonglong)uStack_c18 >> 0x20);
          if (((((pbVar30 != *ppbVar29) || (sStack_c10 != *(short *)(ppbVar29 + 0xd))) ||
               ((int)uStack_c18 != *(int *)(ppbVar29 + 0xc))) ||
              ((iVar8 != *(int *)((longlong)ppbVar29 + 100) ||
               (*(int *)(param_2 + 0x20) != *(int *)((longlong)ppbVar29 + 0x6c))))) ||
             (param_1 = lStack_c20, *(short *)(param_2 + 0x24) != *(short *)(ppbVar29 + 0xe))) {
            *ppbVar29 = pbVar30;
            *(int *)(ppbVar29 + 0xc) = (int)uStack_c18;
            *(int *)((longlong)ppbVar29 + 100) = iVar8;
            *(short *)(ppbVar29 + 0xd) = sStack_c10;
            *(undefined4 *)((longlong)ppbVar29 + 0x6c) = *(undefined4 *)(param_2 + 0x20);
            *(undefined2 *)(ppbVar29 + 0xe) = *(undefined2 *)(param_2 + 0x24);
            *(undefined2 *)((longlong)ppbVar29 + 0x72) = 0;
            uStack_bd0 = *(undefined4 *)((ulonglong)*pbVar30 * 6 + 0x1552a20);
            uVar18 = (ulonglong)*(short *)((ulonglong)*pbVar30 * 6 + 0x1552a24);
            *(undefined2 *)(ppbVar29 + 2) = 0xffff;
            ppbVar29[3] = (byte *)0x0;
            *(undefined4 *)((longlong)ppbVar29 + 0x14) = 0;
            *(undefined8 *)((longlong)ppbVar29 + 0x2e) = 0;
            ppbVar29[7] = (byte *)0x0;
            ppbVar29[4] = (byte *)0x0;
            ppbVar29[9] = (byte *)0x0;
            ppbVar29[10] = (byte *)0x0;
            *(undefined2 *)(ppbVar29 + 0xb) = 0;
            if ((**ppbVar29 & 2) != 0) {
              pbVar1 = pbVar30 + uVar18;
              if ((*pbVar1 & 1) == 0) {
                *(undefined2 *)(ppbVar29 + 2) = 0;
                ppbVar29[3] = pbVar1;
                *(undefined4 *)((longlong)ppbVar29 + 0x14) = 0;
                *(undefined4 *)((longlong)ppbVar29 + 0x36) = 0;
                uVar7 = uVar27;
                switch(*pbVar1 & 0xe) {
                default:
                  uVar7 = (uint)*(ushort *)(pbVar1 + 2);
                  if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
                    *(undefined8 *)(puVar23 + -8) = 0x1006b8;
                    func_0x(pbVar1,6);
                  }
                  break;
                case 4:
                  uVar7 = 9;
                  break;
                case 6:
                case 10:
                  break;
                case 0xe:
                  uVar7 = 1;
                }
                *(uint *)(ppbVar29 + 4) = uVar7;
                *(undefined8 *)((longlong)ppbVar29 + 0x2e) = 0;
              }
              else {
                *(undefined2 *)(ppbVar29 + 2) = 1;
                ppbVar29[3] = pbVar1;
                bVar19 = *pbVar1;
                switch(bVar19 & 0x1c) {
                default:
                  if ((char)pbVar1[1] < '\0') {
                    uVar16 = *(ushort *)(pbVar1 + 1);
                    *(ushort *)((longlong)ppbVar29 + 0x12) = uVar16;
                    sVar5 = 3;
                    uVar16 = (uVar16 & 0x7f) << 8 | uVar16 >> 8;
                  }
                  else {
                    sVar5 = 2;
                    uVar16 = (ushort)pbVar1[1];
                  }
                  *(ushort *)((longlong)ppbVar29 + 0x12) = uVar16;
                  *(short *)(ppbVar29 + 5) = sVar5;
                  uVar16 = *(ushort *)((longlong)ppbVar29 + 0x12);
                  *(short *)((longlong)ppbVar29 + 0x2c) = (short)(uVar16 + 1 >> 1) + sVar5;
                  if (uVar16 < 0x1f) {
                    *(undefined2 *)((longlong)ppbVar29 + 0x2a) = 0;
                    *(undefined4 *)((longlong)ppbVar29 + 0x14) = 0;
                    *(undefined4 *)(ppbVar29 + 8) = 0;
                    ppbVar29[7] = (byte *)0x0;
                    ppbVar29[4] = (byte *)0x0;
                  }
                  else {
                    iVar9 = uVar16 - 1;
                    *(short *)((longlong)ppbVar29 + 0x2a) =
                         ((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
                         (short)((longlong)iVar9 * 0x88888889 >> 0x3f);
                    *(undefined4 *)((longlong)ppbVar29 + 0x14) = 0;
                    *(undefined4 *)(ppbVar29 + 8) = 0;
                    ppbVar29[7] = (byte *)0x0;
                    ppbVar29[4] = (byte *)0x0;
                  }
                  break;
                case 4:
                  if (((bVar19 & 0x1c) != 4) || (bVar3 = true, (bVar19 & 2) == 0)) {
                    bVar3 = false;
                  }
                  if (!bVar3) {
                    uVar17 = 1;
                  }
                  else {
                    *(undefined4 *)(ppbVar29 + 8) = 0;
                    uVar17 = 0xf;
                  }
                  ppbVar29[5] = (byte *)0x0;
                  *(undefined2 *)((longlong)ppbVar29 + 0x12) = 0;
                  ppbVar29[6] = (byte *)0x0;
                  ppbVar29[4] = (byte *)0x0;
                  ppbVar29[7] = (byte *)0x0;
                  ppbVar29[3] = pbVar1;
                  *(undefined4 *)((longlong)ppbVar29 + 0x14) = uVar17;
                  *(uint *)(ppbVar29 + 8) = (uint)bVar3;
                  ppbVar29[7] = (byte *)0x0;
                  ppbVar29[4] = (byte *)0x0;
                  break;
                case 8:
                  ppbVar29[5] = (byte *)0x0;
                  *(undefined2 *)((longlong)ppbVar29 + 0x12) = 0;
                  ppbVar29[6] = (byte *)0x0;
                  ppbVar29[4] = (byte *)0x0;
                  ppbVar29[7] = (byte *)0x0;
                  ppbVar29[3] = pbVar1;
                  *(undefined4 *)((longlong)ppbVar29 + 0x14) = 9;
                  *(undefined4 *)(ppbVar29 + 8) = 0;
                  ppbVar29[7] = (byte *)0x0;
                  ppbVar29[4] = (byte *)0x0;
                }
              }
            }
            if ((**ppbVar29 & 4) != 0) {
              if (uStack_bd0._2_2_ != 0) {
                uVar18 = (ulonglong)*(ushort *)(param_2 + 0x61 + (longlong)uStack_bd0._2_2_ * 2);
              }
              psVar11 = (short *)(pbVar30 + uVar18);
              ppbVar29[9] = (byte *)psVar11;
              sVar5 = *psVar11;
              ppbVar29[10] = (byte *)(psVar11 + 1);
              *(short *)(ppbVar29 + 0xb) = (sVar5 + 1) * 2;
            }
            pbVar30 = ppbVar29[1];
            param_1 = lStack_c20;
            iVar9 = aiStack_c78[0];
            if (pbVar30 != (byte *)0x0) {
              *(undefined8 *)(puVar23 + -8) = 0x10074e;
              func_0x(pbVar30,ppbVar29);
              param_1 = lStack_c20;
              iVar9 = aiStack_c78[0];
            }
          }
        }
        uVar7 = (uint)*(ushort *)(param_2 + 0xe);
        pbVar30 = (byte *)((ulonglong)*(ushort *)(param_2 + lVar10 * 2) + param_2);
        pbStack_b60 = pbVar30;
        ppbVar28 = ppbVar32;
        if ((*pbVar30 & 1) == 0) {
          sStack_b68 = 0;
          ppbVar29 = (byte **)0x0;
          uStack_b64 = 0;
          uStack_b42 = 0;
          uStack_b40 = 0;
          switch(*pbVar30 & 0xe) {
          default:
            uVar7 = (uint)*(ushort *)(pbVar30 + 2);
            ppbVar28 = ppbVar29;
            if (0x1f9d < *(ushort *)(pbVar30 + 2) - 1) {
              *(undefined8 *)(puVar23 + -8) = 0x1009ad;
              func_0x(pbVar30,6);
              ppbVar28 = (byte **)(ulonglong)uStack_b64;
            }
            break;
          case 4:
            uVar7 = 9;
            ppbVar28 = ppbVar29;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar7 = 1;
            ppbVar28 = ppbVar29;
          }
          uStack_b58 = (byte **)CONCAT44(uStack_b58._4_4_,uVar7);
          ppbVar29 = (byte **)(param_2 + 0x2000);
          if (param_2 == 0) {
            ppbVar29 = ppbVar32;
          }
          uStack_b4a = SUB82(ppbVar29,0);
          uStack_b48 = (undefined6)((ulonglong)ppbVar29 >> 0x10);
        }
        else {
          sStack_b68 = 1;
          bVar19 = *pbVar30;
          switch(bVar19 & 0x1c) {
          default:
            if ((char)pbVar30[1] < '\0') {
              uStack_b66 = (*(ushort *)(pbVar30 + 1) & 0x7f) << 8 | *(ushort *)(pbVar30 + 1) >> 8;
              sVar5 = 3;
              uStack_b50._0_2_ = 3;
            }
            else {
              uStack_b66 = (ushort)pbVar30[1];
              sVar5 = 2;
              uStack_b50._0_2_ = 2;
            }
            uStack_b4c = (short)(uStack_b66 + 1 >> 1) + sVar5;
            if (uStack_b66 < 0x1f) {
              uStack_b50._2_2_ = 0;
              uStack_b64 = 0;
              uStack_b38 = 0;
            }
            else {
              iVar8 = uStack_b66 - 1;
              uStack_b50._2_2_ =
                   ((short)(iVar8 / 0x1e) + (short)(iVar8 >> 0x1f)) -
                   (short)((longlong)iVar8 * 0x88888889 >> 0x3f);
              ppbVar28 = (byte **)0x0;
              uStack_b64 = 0;
              uStack_b38 = 0;
            }
            break;
          case 4:
            if (((bVar19 & 0x1c) == 4) && ((bVar19 & 2) != 0)) {
              uStack_b50._0_2_ = 0;
              uStack_b50._2_2_ = 0;
              uStack_b4c = 0;
              uStack_b4a = 0;
              uStack_b66 = 0;
              uStack_b48 = 0;
              uStack_b42 = 0;
              ppbVar28 = (byte **)0xf;
              uStack_b64 = 0xf;
              uStack_b38 = 1;
            }
            else {
              uStack_b50._0_2_ = 0;
              uStack_b50._2_2_ = 0;
              uStack_b4c = 0;
              uStack_b4a = 0;
              uStack_b66 = 0;
              uStack_b48 = 0;
              uStack_b42 = 0;
              ppbVar28 = (byte **)0x1;
              uStack_b64 = 1;
              uStack_b38 = 0;
            }
            break;
          case 8:
            uStack_b50._0_2_ = 0;
            uStack_b50._2_2_ = 0;
            uStack_b4c = 0;
            uStack_b4a = 0;
            uStack_b66 = 0;
            uStack_b48 = 0;
            uStack_b42 = 0;
            ppbVar28 = (byte **)0x9;
            uStack_b64 = 9;
            uStack_b38 = 0;
          }
          ppbVar12 = (byte **)(param_2 + 0x2000);
          if (param_2 == 0) {
            ppbVar12 = ppbVar32;
          }
          uStack_b40 = SUB82(ppbVar12,0);
          uStack_b3e = (ushort)((ulonglong)ppbVar12 >> 0x10);
          uStack_b3c = (ushort)((ulonglong)ppbVar12 >> 0x20);
          uStack_b3a = (undefined2)((ulonglong)ppbVar12 >> 0x30);
          uStack_b58 = ppbVar29;
          uVar7 = (uint)ppbVar29;
        }
        if (uStack_c08 == 0) {
          psVar11 = &sStack_b68;
code_r0x00101550:
          *(longlong **)(puVar23 + 0x20) = plStack_bd8;
          lVar10 = lStack_c28;
          iVar9 = aiStack_c78[0];
          *(undefined8 *)(puVar23 + -8) = 0x101573;
          func_0x(asStack_ba8,lVar10,iVar9,psVar11);
          psStack_c70 = asStack_ba8;
        }
        else {
          if ((*(int *)(param_1 + 0x1fe4) == 0) && (*(int *)(param_1 + 0x1fe8) == 0)) {
            psStack_c70 = &sStack_c68;
            lVar10 = lStack_c28;
          }
          else {
            iVar9 = 0x1f9e;
            lVar10 = lStack_be0;
          }
          sStack_c68 = sStack_b68;
          if (sStack_b68 == 0) {
            pbVar30 = pbStack_b60;
            if ((int)ppbVar28 == 0) {
              uStack_b66 = 0;
              if ((*pbStack_b60 & 0x10) != 0) {
                uVar7 = (int)uStack_b58 + 2 +
                        (*(ushort *)(pbStack_b60 + ((ulonglong)uStack_b58 & 0xffffffff)) + 7 >> 3);
              }
              uStack_b58 = (byte **)CONCAT44(uVar7,(int)uStack_b58);
              if ((*pbStack_b60 & 0x20) == 0) {
                ppbVar28 = (byte **)(ulonglong)uVar7;
                uStack_b4c = 0;
                uStack_b64 = uVar7;
              }
              else {
                puVar33 = (ushort *)(pbStack_b60 + uVar7);
                uStack_b4c = *puVar33;
                puStack_bc8 = puVar33;
                if (uStack_b4c == 0) {
                  *(undefined8 *)(puVar23 + -8) = 0x100aed;
                  cVar4 = func_0x(0x1e691d0);
                  if (cVar4 != '\0') {
                    *(undefined8 *)(puVar23 + -8) = 0x100af6;
                    lVar13 = func_0x();
                    if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar23 + -8) = 0x100b10;
                      cVar4 = func_0x(0x1e691d0);
                      if (cVar4 == '\0') {
                        *(undefined8 *)(puVar23 + -8) = 0x100b2c;
                        (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar23 + 0x20) = 0;
                        *(undefined8 *)(puVar23 + -8) = 0x100b52;
                        (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x80f);
                      }
                    }
                  }
                  pbVar30 = pbStack_b60;
                  *(undefined8 *)(puVar23 + -8) = 0x100b63;
                  func_0x(pbVar30,3);
                }
                uStack_b50 = uStack_b58._4_4_ + (uStack_b4c + 1) * 2;
                if (0x1f9e < uStack_b50) {
                  *(undefined8 *)(puVar23 + -8) = 0x100b9a;
                  cVar4 = func_0x(0x1e691d0);
                  if (cVar4 != '\0') {
                    *(undefined8 *)(puVar23 + -8) = 0x100ba3;
                    lVar13 = func_0x();
                    if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar23 + -8) = 0x100bbd;
                      cVar4 = func_0x(0x1e691d0);
                      if (cVar4 == '\0') {
                        *(undefined8 *)(puVar23 + -8) = 0x100bd9;
                        (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar23 + 0x20) = 0;
                        *(undefined8 *)(puVar23 + -8) = 0x100bff;
                        (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x816);
                      }
                    }
                  }
                  pbVar30 = pbStack_b60;
                  *(undefined8 *)(puVar23 + -8) = 0x100c10;
                  func_0x(pbVar30,4);
                }
                uStack_b64 = puVar33[uStack_b4c] & 0x7fff;
                if (uStack_b64 < uStack_b50) {
                  *(undefined8 *)(puVar23 + -8) = 0x100c4a;
                  cVar4 = func_0x(0x1e691d0);
                  if (cVar4 != '\0') {
                    *(undefined8 *)(puVar23 + -8) = 0x100c53;
                    lVar13 = func_0x();
                    if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar23 + -8) = 0x100c6d;
                      cVar4 = func_0x(0x1e691d0);
                      if (cVar4 == '\0') {
                        *(undefined8 *)(puVar23 + -8) = 0x100c89;
                        (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar23 + 0x20) = 0;
                        *(undefined8 *)(puVar23 + -8) = 0x100caf;
                        (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x81d);
                      }
                    }
                  }
                  pbVar30 = pbStack_b60;
                  *(undefined8 *)(puVar23 + -8) = 0x100cc0;
                  func_0x(pbVar30,4);
                }
                ppbVar28 = (byte **)(ulonglong)uStack_b64;
                ppbVar29 = ppbVar32;
                pbVar30 = pbStack_b60;
                uVar7 = uStack_b50;
                puVar34 = puVar33;
                if (uStack_b4c != 0) {
                  do {
                    puVar33 = puVar33 + 1;
                    uVar22 = *puVar33 & 0x7fff;
                    if ((uVar22 < uStack_b50) || ((uint)ppbVar28 < uVar22)) {
                      uStack_b50 = uVar7;
                      *(undefined8 *)(puVar23 + -8) = 0x100d12;
                      cVar4 = func_0x(0x1e691d0);
                      if (cVar4 != '\0') {
                        *(undefined8 *)(puVar23 + -8) = 0x100d1b;
                        lVar13 = func_0x();
                        if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar23 + -8) = 0x100d35;
                          cVar4 = func_0x(0x1e691d0);
                          if (cVar4 == '\0') {
                            *(undefined8 *)(puVar23 + -8) = 0x100d51;
                            (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar23 + 0x20) = 0;
                            *(undefined8 *)(puVar23 + -8) = 0x100d75;
                            (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x82a);
                          }
                        }
                      }
                      pbVar30 = pbStack_b60;
                      *(undefined8 *)(puVar23 + -8) = 0x100d86;
                      func_0x(pbVar30,4);
                      ppbVar28 = (byte **)(ulonglong)uStack_b64;
                      pbVar30 = pbStack_b60;
                      uVar7 = uStack_b50;
                    }
                    uVar24 = (int)ppbVar29 + 1;
                    ppbVar29 = (byte **)(ulonglong)uVar24;
                    uStack_b50 = uVar22;
                    puVar34 = puStack_bc8;
                  } while ((int)uVar24 < (int)(uint)uStack_b4c);
                }
                while ((short)puVar34[(ulonglong)(uStack_b4c - 1) + 1] < 0) {
                  uVar22 = uVar7;
                  if (uStack_b4c != 1) {
                    uVar22 = *(ushort *)
                              (pbVar30 +
                              (ulonglong)uStack_b4c * 2 + (((ulonglong)uStack_b58 >> 0x20) - 2)) &
                             0x7fff;
                  }
                  uVar24 = *(ushort *)
                            (pbVar30 + (ulonglong)uStack_b4c * 2 + ((ulonglong)uStack_b58 >> 0x20))
                           & 0x7fff;
                  if (((uVar22 < uVar7) || (uVar24 < uVar22)) || ((uint)ppbVar28 < uVar24)) {
                    uStack_b50 = uVar7;
                    *(undefined8 *)(puVar23 + -8) = 0x100e20;
                    func_0x(pbVar30,7);
                    ppbVar28 = (byte **)(ulonglong)uStack_b64;
                    pbVar30 = pbStack_b60;
                    uVar7 = uStack_b50;
                  }
                  uStack_b50 = uVar7;
                  if ((uVar22 < uVar7) || ((uint)ppbVar28 < uVar22)) goto code_r0x001011e6;
                  if (*(ushort *)(pbVar30 + uVar22) == 5) {
                    uStack_b66 = uStack_b66 | 2;
                    uStack_b4c = uStack_b4c - 1;
                    uVar18 = (ulonglong)(uVar22 & 0xffff);
                    uStack_b3e = (ushort)uVar22;
                    pbVar1 = pbVar30 + uVar18;
                    if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
                      uVar16 = uStack_b3c & 0xc7ff;
                    }
                    else {
                      uVar16 = uStack_b3c ^ (uStack_b3c ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
                    }
                    uStack_b3c = (uVar16 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar16;
                    uVar25 = (ulonglong)uStack_b3c;
                    uVar21 = uVar25 & 0x7ff;
                    lVar13 = (ulonglong)((uVar16 >> 0xb & 7) * 2) + 4 + uVar18;
                    pbVar31 = pbVar30;
                    if (pbVar30 + lVar13 + uVar21 * 2 < pbVar1) {
                      *(undefined8 *)(puVar23 + -8) = 0x100f1e;
                      func_0x(pbVar1,0x19);
                      uVar25 = (ulonglong)uStack_b3c;
                      uVar18 = (ulonglong)uStack_b3e;
                      ppbVar28 = (byte **)(ulonglong)uStack_b64;
                      pbVar31 = pbStack_b60;
                    }
                    uVar7 = uStack_b50;
                    if (uVar24 - uVar22 <
                        (((uStack_b3c & 0x7ff) * 2 - (int)uVar18) - (int)pbStack_b60) +
                        (int)(pbVar30 + lVar13 + uVar21 * 2)) {
                      *(undefined8 *)(puVar23 + -8) = 0x100f6a;
                      func_0x(pbVar31 + uVar18,0x19);
                      uVar25 = (ulonglong)uStack_b3c;
                      uVar18 = (ulonglong)uStack_b3e;
                      ppbVar28 = (byte **)(ulonglong)uStack_b64;
                      pbVar31 = pbStack_b60;
                      uVar7 = uStack_b50;
                    }
                    pbVar30 = pbVar31;
                    if (((uVar25 & 0x3800) != 0) &&
                       (puVar33 = (ushort *)(pbVar31 + uVar18 + 4), ppbVar29 = ppbVar32,
                       (uVar25 & 0x3800) != 0)) {
                      do {
                        if (((ushort)uVar25 & 0x7ff) < (*puVar33 & 0x7ff)) {
                          uStack_b50 = uVar7;
                          *(undefined8 *)(puVar23 + -8) = 0x100fe5;
                          func_0x(pbVar31 + uVar18,0x1a);
                          uVar25 = (ulonglong)uStack_b3c;
                          uVar18 = (ulonglong)uStack_b3e;
                          pbVar31 = pbStack_b60;
                          uVar7 = uStack_b50;
                        }
                        uVar22 = (int)ppbVar29 + 1;
                        puVar33 = puVar33 + 1;
                        ppbVar29 = (byte **)(ulonglong)uVar22;
                      } while ((int)uVar22 < (int)((uStack_b3c & 0x3800) >> 0xb));
                      ppbVar28 = (byte **)(ulonglong)uStack_b64;
                      pbVar30 = pbVar31;
                    }
                    break;
                  }
                  if (*(ushort *)(pbVar30 + uVar22) < 0x400) break;
                  uStack_b66 = uStack_b66 | 1;
                  uStack_b4c = uStack_b4c - 1;
                  if (uStack_b4c == 0) break;
                }
              }
              if ((*pbVar30 & 0x40) == 0) {
                uStack_b42 = 0;
                uStack_b40 = 0;
              }
              else {
                uStack_b42 = SUB82(ppbVar28,0);
                uStack_b40 = (undefined2)((ulonglong)ppbVar28 >> 0x10);
                uStack_b64 = (int)ppbVar28 + 0xe;
                uStack_b50 = uVar7;
                *(undefined8 *)(puVar23 + -8) = 0x10105c;
                uVar14 = func_0x(&uStack_b66);
                *(undefined8 *)(puVar23 + -8) = 0x10106b;
                func_0x(uVar14,auStack_bc0);
                *(undefined8 *)(puVar23 + -8) = 0x101077;
                iVar8 = func_0x(auStack_bc0);
                uStack_b64 = uStack_b64 + iVar8;
                ppbVar28 = (byte **)(ulonglong)uStack_b64;
                pbVar30 = pbStack_b60;
                uVar7 = uStack_b50;
              }
              uStack_b50 = uVar7;
              if (((byte *)CONCAT62(uStack_b48,uStack_b4a) != (byte *)0x0) &&
                 ((byte *)CONCAT62(uStack_b48,uStack_b4a) <
                  (byte *)((longlong)ppbVar28 + (longlong)pbVar30))) {
                *(undefined8 *)(puVar23 + -8) = 0x1010c3;
                cVar4 = func_0x(0x1e691d0);
                if (cVar4 != '\0') {
                  *(undefined8 *)(puVar23 + -8) = 0x1010cc;
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar23 + -8) = 0x1010e6;
                    cVar4 = func_0x(0x1e691d0);
                    if (cVar4 == '\0') {
                      *(undefined8 *)(puVar23 + -8) = 0x101102;
                      (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar23 + 0x20) = 0;
                      *(undefined8 *)(puVar23 + -8) = 0x101128;
                      (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x886);
                    }
                  }
                }
                pbVar30 = pbStack_b60;
                *(undefined8 *)(puVar23 + -8) = 0x101139;
                func_0x(pbVar30,0x12);
                ppbVar28 = (byte **)(ulonglong)uStack_b64;
                pbVar30 = pbStack_b60;
              }
              uStack_b50 = uStack_b50;
              if (0x3f3b < (int)ppbVar28 - 1U) {
                *(undefined8 *)(puVar23 + -8) = 0x101162;
                cVar4 = func_0x(0x1e691d0);
                if (cVar4 != '\0') {
                  *(undefined8 *)(puVar23 + -8) = 0x10116b;
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar23 + -8) = 0x101185;
                    cVar4 = func_0x(0x1e691d0);
                    if (cVar4 == '\0') {
                      *(undefined8 *)(puVar23 + -8) = 0x1011a1;
                      (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar23 + 0x20) = 0;
                      *(undefined8 *)(puVar23 + -8) = 0x1011c7;
                      (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x88b);
                    }
                  }
                }
                pbVar30 = pbStack_b60;
                *(undefined8 *)(puVar23 + -8) = 0x1011d8;
                func_0x(pbVar30,5);
                ppbVar28 = (byte **)(ulonglong)uStack_b64;
                pbVar30 = pbStack_b60;
                uStack_b50 = uStack_b50;
              }
            }
code_r0x001011e6:
            uStack_c50 = uStack_b50;
            uStack_c64 = (uint)ppbVar28;
            uVar7 = uStack_c64;
            if ((uStack_c64 < 9) && (((*pbVar30 & 0xe) == 0 || ((*pbVar30 & 0xe) == 0xc)))) {
              uVar7 = 9;
            }
            uStack_c66 = uStack_b66;
            uStack_c4c = uStack_b4c;
            ppbStack_c58 = uStack_b58;
            uStack_c42 = uStack_b42;
            uStack_c40 = uStack_b40;
            uStack_b50 = uStack_c50;
            *(undefined8 *)(puVar23 + -8) = 0x101251;
            func_0x(lVar10,iVar9,pbVar30,uVar7);
            lStack_c60 = lVar10;
            *(undefined8 *)(puVar23 + -8) = 0x10125e;
            iVar9 = func_0x(&uStack_c66);
            lVar10 = lStack_c60;
            if (iVar9 != 0) {
              puVar33 = (ushort *)(((ulonglong)ppbStack_c58 >> 0x20) + lStack_c60);
              uVar7 = *puVar33 - 1;
              if ((uStack_c66 & 1) == 0) {
                uVar7 = (uint)*puVar33;
              }
              uVar22 = uStack_c50;
              if (uVar7 != 1) {
                uVar22 = puVar33[(longlong)(int)uVar7 + -1] & 0x7fff;
              }
              uVar7 = puVar33[(int)uVar7] & 0x7fff;
              if (((uVar22 < uStack_c50) || (uVar7 < uVar22)) || (uStack_c64 < uVar7)) {
                *(undefined8 *)(puVar23 + -8) = 0x1012be;
                func_0x(lVar10,7);
              }
              uVar21 = (ulonglong)(uVar22 & 0xffff);
              uStack_c3e = (ushort)uVar22;
              uVar18 = uVar21 + lStack_c60;
              if ((*(ushort *)(uVar18 + 2) & 0x4000) == 0) {
                uVar16 = uStack_c3c & 0xc7ff;
              }
              else {
                uVar16 = uStack_c3c ^ (uStack_c3c ^ *(ushort *)(uVar18 + 2)) & 0x3800;
              }
              uStack_c3c = (uVar16 ^ *(ushort *)(uVar18 + 2)) & 0x7ff ^ uVar16;
              uVar26 = (ulonglong)uStack_c3c;
              uVar25 = (ulonglong)((uVar16 >> 0xb & 7) * 2) + 4 + uVar21 + (uVar26 & 0x7ff) * 2 +
                       lStack_c60;
              if (uVar25 < uVar18) {
                *(undefined8 *)(puVar23 + -8) = 0x101352;
                func_0x(uVar18,0x19);
                uVar26 = (ulonglong)uStack_c3c;
                uVar21 = (ulonglong)uStack_c3e;
              }
              if (uVar7 - uVar22 <
                  (((uStack_c3c & 0x7ff) * 2 - (int)uVar21) - (int)lStack_c60) + (int)uVar25) {
                lVar10 = uVar21 + lStack_c60;
                *(undefined8 *)(puVar23 + -8) = 0x101388;
                func_0x(lVar10,0x19);
                uVar26 = (ulonglong)uStack_c3c;
                uVar21 = (ulonglong)uStack_c3e;
              }
              if (((uVar26 & 0x3800) != 0) &&
                 (puVar33 = (ushort *)(lStack_c60 + 4 + uVar21), ppbVar29 = ppbVar32,
                 lVar10 = lStack_c60, (uVar26 & 0x3800) != 0)) {
                do {
                  if (((ushort)uVar26 & 0x7ff) < (*puVar33 & 0x7ff)) {
                    *(undefined8 *)(puVar23 + -8) = 0x1013e5;
                    func_0x(uVar21 + lVar10,0x1a);
                    uVar26 = (ulonglong)uStack_c3c;
                    uVar21 = (ulonglong)uStack_c3e;
                    lVar10 = lStack_c60;
                  }
                  uVar7 = (int)ppbVar29 + 1;
                  ppbVar29 = (byte **)(ulonglong)uVar7;
                  puVar33 = puVar33 + 1;
                } while ((int)uVar7 < (int)((uStack_c3c & 0x3800) >> 0xb));
              }
            }
          }
          else if ((uStack_b58 == (byte **)0x0) || (*uStack_b58 == (byte *)0x0)) {
            *(undefined8 *)(puVar23 + -8) = 0x101441;
            func_0x(&uStack_c66,lVar10,iVar9,&uStack_b66);
            ppbStack_c58 = uStack_b58;
            if (sStack_b68 == 0) {
              ppbStack_c58 = ppbVar32;
            }
          }
          else {
            *(undefined8 *)(puVar23 + -8) = 0x101429;
            func_0x(&sStack_c68,lVar10,iVar9,&sStack_b68);
          }
          psVar11 = &sStack_c68;
          iVar9 = aiStack_c78[0];
          if (psStack_c70 == (short *)0x0) goto code_r0x00101550;
        }
        psVar11 = psStack_c70;
        *(short *)(lStack_bf0 + lStack_be8 * 2) = (short)lStack_c28 - (short)lStack_bb8;
        puVar33 = (ushort *)(psStack_c70 + 1);
        uVar7 = *(uint *)(psStack_c70 + 2);
        if (*psStack_c70 == 0) {
          if (uVar7 == 0) {
            *puVar33 = 0;
            uVar7 = *(uint *)(psStack_c70 + 8);
            uVar18 = (ulonglong)uVar7;
            *(uint *)(psStack_c70 + 10) = uVar7;
            pbVar30 = *(byte **)(psStack_c70 + 4);
            bVar19 = *pbVar30;
            if ((bVar19 & 0x10) != 0) {
              uVar7 = uVar7 + 2 + (*(ushort *)(pbVar30 + uVar18) + 7 >> 3);
              uVar18 = (ulonglong)uVar7;
              *(uint *)(psStack_c70 + 10) = uVar7;
              bVar19 = *pbVar30;
            }
            if ((bVar19 & 0x20) == 0) {
              *(int *)(psStack_c70 + 2) = (int)uVar18;
              psStack_c70[0xe] = 0;
              *(int *)(psStack_c70 + 0xc) = (int)uVar18;
            }
            else {
              puVar34 = (ushort *)(pbVar30 + uVar18);
              uVar16 = *puVar34;
              psStack_c70[0xe] = uVar16;
              if (uVar16 == 0) {
                *(undefined8 *)(puVar23 + -8) = 0x1014fc;
                cVar4 = func_0x(0x1e691d0);
                if (cVar4 != '\0') {
                  *(undefined8 *)(puVar23 + -8) = 0x101509;
                  lVar10 = func_0x();
                  if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar23 + -8) = 0x10152b;
                    cVar4 = func_0x(0x1e691d0);
                    if (cVar4 == '\0') {
                      *(undefined8 *)(puVar23 + -8) = 0x101547;
                      (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar23 + 0x20) = 0;
                      *(undefined8 *)(puVar23 + -8) = 0x1015a7;
                      (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x80f);
                    }
                  }
                }
                uVar14 = *(undefined8 *)(psVar11 + 4);
                *(undefined8 *)(puVar23 + -8) = 0x1015b5;
                func_0x(uVar14,3);
                uVar18 = (ulonglong)*(uint *)(psVar11 + 10);
                uVar16 = psVar11[0xe];
              }
              uVar7 = (int)uVar18 + (uVar16 + 1) * 2;
              *(uint *)(psVar11 + 0xc) = uVar7;
              if (0x1f9e < uVar7) {
                *(undefined8 *)(puVar23 + -8) = 0x1015e5;
                cVar4 = func_0x(0x1e691d0);
                if (cVar4 != '\0') {
                  *(undefined8 *)(puVar23 + -8) = 0x1015ee;
                  lVar10 = func_0x();
                  if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar23 + -8) = 0x101608;
                    cVar4 = func_0x(0x1e691d0);
                    if (cVar4 == '\0') {
                      *(undefined8 *)(puVar23 + -8) = 0x101624;
                      (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar23 + 0x20) = 0;
                      *(undefined8 *)(puVar23 + -8) = 0x10164a;
                      (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x816);
                    }
                  }
                }
                uVar14 = *(undefined8 *)(psVar11 + 4);
                *(undefined8 *)(puVar23 + -8) = 0x101658;
                func_0x(uVar14,4);
                uVar16 = psVar11[0xe];
                uVar7 = *(uint *)(psVar11 + 0xc);
              }
              uVar18 = (ulonglong)uVar16;
              uVar16 = puVar34[uVar18];
              *(uint *)(psVar11 + 2) = uVar16 & 0x7fff;
              if ((uVar16 & 0x7fff) < uVar7) {
                *(undefined8 *)(puVar23 + -8) = 0x101688;
                cVar4 = func_0x(0x1e691d0);
                if (cVar4 != '\0') {
                  *(undefined8 *)(puVar23 + -8) = 0x101691;
                  lVar10 = func_0x();
                  if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar23 + -8) = 0x1016ab;
                    cVar4 = func_0x(0x1e691d0);
                    if (cVar4 == '\0') {
                      *(undefined8 *)(puVar23 + -8) = 0x1016c7;
                      (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar23 + 0x20) = 0;
                      *(undefined8 *)(puVar23 + -8) = 0x1016ed;
                      (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x81d);
                    }
                  }
                }
                uVar14 = *(undefined8 *)(psVar11 + 4);
                *(undefined8 *)(puVar23 + -8) = 0x1016fb;
                func_0x(uVar14,4);
                uVar7 = *(uint *)(psVar11 + 0xc);
                uVar18 = (ulonglong)(ushort)psVar11[0xe];
              }
              ppbVar29 = ppbVar32;
              puVar2 = puVar34;
              if ((short)uVar18 != 0) {
                do {
                  uVar22 = puVar2[1] & 0x7fff;
                  if ((uVar22 < uVar7) || (*(uint *)(psVar11 + 2) < uVar22)) {
                    *(undefined8 *)(puVar23 + -8) = 0x10173f;
                    cVar4 = func_0x(0x1e691d0);
                    if (cVar4 != '\0') {
                      *(undefined8 *)(puVar23 + -8) = 0x101748;
                      lVar10 = func_0x();
                      if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar23 + -8) = 0x101762;
                        cVar4 = func_0x(0x1e691d0);
                        if (cVar4 == '\0') {
                          *(undefined8 *)(puVar23 + -8) = 0x10177e;
                          (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar23 + 0x20) = 0;
                          *(undefined8 *)(puVar23 + -8) = 0x1017a2;
                          (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x82a);
                        }
                      }
                    }
                    uVar14 = *(undefined8 *)(psVar11 + 4);
                    *(undefined8 *)(puVar23 + -8) = 0x1017b0;
                    func_0x(uVar14,4);
                  }
                  uVar24 = (int)ppbVar29 + 1;
                  uVar18 = (ulonglong)(ushort)psVar11[0xe];
                  ppbVar29 = (byte **)(ulonglong)uVar24;
                  iVar9 = aiStack_c78[0];
                  puVar2 = puVar2 + 1;
                  uVar7 = uVar22;
                } while ((int)uVar24 < (int)(uint)(ushort)psVar11[0xe]);
              }
              if ((short)puVar34[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
                pbVar30 = *(byte **)(psVar11 + 4);
                do {
                  uVar22 = *(ushort *)(pbVar30 + uVar18 * 2 + (ulonglong)*(uint *)(psVar11 + 10)) &
                           0x7fff;
                  if ((int)uVar18 == 1) {
                    uVar24 = *(uint *)(psVar11 + 0xc);
                    uVar20 = uVar24;
code_r0x00101822:
                    if ((uVar22 < uVar24) || (uVar7 = *(uint *)(psVar11 + 2), uVar7 < uVar22))
                    goto code_r0x0010182d;
                  }
                  else {
                    uVar24 = *(ushort *)
                              (pbVar30 + uVar18 * 2 + ((ulonglong)*(uint *)(psVar11 + 10) - 2)) &
                             0x7fff;
                    uVar20 = *(uint *)(psVar11 + 0xc);
                    if (uVar20 <= uVar24) goto code_r0x00101822;
code_r0x0010182d:
                    *(undefined8 *)(puVar23 + -8) = 0x10183a;
                    func_0x(pbVar30,7);
                    uVar20 = *(uint *)(psVar11 + 0xc);
                    uVar7 = *(uint *)(psVar11 + 2);
                  }
                  if ((uVar24 < uVar20) || (uVar7 < uVar24)) goto code_r0x00101bb6;
                  pbVar30 = *(byte **)(psVar11 + 4);
                  if (*(ushort *)(pbVar30 + uVar24) == 5) {
                    *puVar33 = *puVar33 | 2;
                    psVar11[0xe] = psVar11[0xe] + -1;
                    uVar25 = (ulonglong)(uVar24 & 0xffff);
                    psVar11[0x15] = (short)uVar24;
                    uVar21 = *(ulonglong *)(psVar11 + 4);
                    uVar18 = uVar21 + uVar25;
                    uVar16 = psVar11[0x16] & 0xc7ff;
                    if ((*(ushort *)(uVar18 + 2) >> 0xe & 1) != 0) {
                      uVar16 = *(ushort *)(uVar18 + 2) & 0x3800 | uVar16;
                    }
                    psVar11[0x16] = uVar16;
                    uVar6 = (uVar16 ^ *(ushort *)(uVar18 + 2)) & 0x7ff ^ uVar16;
                    psVar11[0x16] = uVar6;
                    uVar26 = uVar21 + (uVar16 >> 0xb & 7) * 2 + (ulonglong)((uVar6 & 0x7ff) * 2) + 4
                             + uVar25;
                    if (uVar26 < uVar18) {
                      *(undefined8 *)(puVar23 + -8) = 0x101948;
                      func_0x(uVar18,0x19);
                      uVar6 = psVar11[0x16];
                      uVar25 = (ulonglong)(ushort)psVar11[0x15];
                      uVar21 = (ulonglong)*(uint *)(psVar11 + 4);
                    }
                    if (uVar22 - uVar24 <
                        (((uVar6 & 0x7ff) * 2 - (int)uVar25) - (int)uVar21) + (int)uVar26) {
                      lVar10 = *(longlong *)(psVar11 + 4);
                      *(undefined8 *)(puVar23 + -8) = 0x101980;
                      func_0x(uVar25 + lVar10,0x19);
                      uVar6 = psVar11[0x16];
                    }
                    if (((uVar6 & 0x3800) != 0) &&
                       (puVar34 = (ushort *)
                                  (*(longlong *)(psVar11 + 4) + 4 + (ulonglong)(ushort)psVar11[0x15]
                                  ), ppbVar29 = ppbVar32, (uVar6 & 0x3800) != 0)) {
                      do {
                        if ((uVar6 & 0x7ff) < (*puVar34 & 0x7ff)) {
                          uVar16 = psVar11[0x15];
                          lVar10 = *(longlong *)(psVar11 + 4);
                          *(undefined8 *)(puVar23 + -8) = 0x1019d7;
                          func_0x((ulonglong)uVar16 + lVar10,0x1a);
                          uVar6 = psVar11[0x16];
                        }
                        uVar7 = (int)ppbVar29 + 1;
                        ppbVar29 = (byte **)(ulonglong)uVar7;
                        puVar34 = puVar34 + 1;
                      } while ((int)uVar7 < (int)(uVar6 >> 0xb & 7));
                    }
                    goto code_r0x001019f2;
                  }
                  if (*(ushort *)(pbVar30 + uVar24) < 0x400) goto code_r0x001019f2;
                  *puVar33 = *puVar33 | 1;
                  uVar16 = psVar11[0xe] - 1;
                  psVar11[0xe] = uVar16;
                  if (uVar16 == 0) goto code_r0x001019f2;
                  uVar18 = (ulonglong)uVar16;
                } while ((short)puVar34[(ulonglong)(uVar16 - 1) + 1] < 0);
                uVar18 = (ulonglong)*(uint *)(psVar11 + 2);
              }
              else {
code_r0x001019f2:
                pbVar30 = *(byte **)(psVar11 + 4);
                uVar18 = (ulonglong)*(uint *)(psVar11 + 2);
              }
            }
            if ((*pbVar30 & 0x40) == 0) {
              *(undefined4 *)(psVar11 + 0x13) = 0;
            }
            else {
              *(int *)(psVar11 + 0x13) = (int)uVar18;
              *(int *)(psVar11 + 2) = (int)uVar18 + 0xe;
              *(undefined8 *)(puVar23 + -8) = 0x101a1f;
              puVar15 = (ulonglong *)func_0x(puVar33);
              uVar6 = (ushort)(*puVar15 >> 0x30);
              uVar16 = uVar6;
              if ((((uint)(int)(short)uVar6 >> 1 ^ (int)(short)uVar6) & 0x2000) != 0) {
                uVar16 = uVar6 & 0xdfff;
                if ((uVar6 >> 0xe & 1) != 0) {
                  uVar16 = uVar6 | 0x2000;
                }
              }
              uVar7 = uVar27;
              if (uVar16 == 0xfffc) {
                uVar7 = (uint)((*puVar15 >> 0x20 & 0xffff) >> 5);
              }
              *(uint *)(psVar11 + 2) = *(int *)(psVar11 + 2) + uVar7;
              uVar18 = (ulonglong)*(uint *)(psVar11 + 2);
            }
            uVar7 = (uint)uVar18;
            if ((*(ulonglong *)(psVar11 + 0xf) != 0) &&
               (*(ulonglong *)(psVar11 + 0xf) < uVar18 + *(longlong *)(psVar11 + 4))) {
              *(undefined8 *)(puVar23 + -8) = 0x101aaa;
              cVar4 = func_0x(0x1e691d0);
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar23 + -8) = 0x101ab3;
                lVar10 = func_0x();
                if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar23 + -8) = 0x101acd;
                  cVar4 = func_0x(0x1e691d0);
                  if (cVar4 == '\0') {
                    *(undefined8 *)(puVar23 + -8) = 0x101ae9;
                    (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar23 + 0x20) = 0;
                    *(undefined8 *)(puVar23 + -8) = 0x101b0f;
                    (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x886);
                  }
                }
              }
              uVar14 = *(undefined8 *)(psVar11 + 4);
              *(undefined8 *)(puVar23 + -8) = 0x101b1d;
              func_0x(uVar14,0x12);
              uVar7 = *(uint *)(psVar11 + 2);
            }
            if ((uVar7 == 0) || (0x3f3c < uVar7)) {
              *(undefined8 *)(puVar23 + -8) = 0x101b3c;
              cVar4 = func_0x(0x1e691d0);
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar23 + -8) = 0x101b45;
                lVar10 = func_0x();
                if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar23 + -8) = 0x101b5f;
                  cVar4 = func_0x(0x1e691d0);
                  if (cVar4 == '\0') {
                    *(undefined8 *)(puVar23 + -8) = 0x101b7b;
                    (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar23 + 0x20) = 0;
                    *(undefined8 *)(puVar23 + -8) = 0x101ba1;
                    (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x88b);
                  }
                }
              }
              uVar14 = *(undefined8 *)(psVar11 + 4);
              *(undefined8 *)(puVar23 + -8) = 0x101baf;
              func_0x(uVar14,5);
              uVar7 = *(uint *)(psVar11 + 2);
            }
          }
code_r0x00101bb6:
          uVar22 = uVar7;
          if (uVar7 < 9) {
            bVar19 = **(byte **)(psVar11 + 4) & 0xe;
joined_r0x00101bee:
            if ((bVar19 == 0) || (uVar22 = uVar7, bVar19 == 0xc)) {
              uVar22 = 9;
            }
          }
        }
        else {
          if (uVar7 == 0) {
            *(undefined8 *)(puVar23 + -8) = 0x101bd8;
            func_0x(puVar33);
            uVar7 = *(uint *)(psVar11 + 2);
          }
          uVar22 = uVar7;
          if (uVar7 < 9) {
            bVar19 = **(byte **)(psVar11 + 4) & 0x1c;
            goto joined_r0x00101bee;
          }
        }
        iVar9 = iVar9 - uVar22;
        aiStack_c78[0] = iVar9;
        if (*psStack_c70 == 0) {
          if (uVar7 == 0) {
            *puVar33 = 0;
            uVar7 = *(uint *)(psVar11 + 8);
            uVar18 = (ulonglong)uVar7;
            *(uint *)(psVar11 + 10) = uVar7;
            pbVar30 = *(byte **)(psVar11 + 4);
            bVar19 = *pbVar30;
            if ((bVar19 & 0x10) != 0) {
              uVar7 = uVar7 + 2 + (*(ushort *)(pbVar30 + uVar18) + 7 >> 3);
              uVar18 = (ulonglong)uVar7;
              *(uint *)(psVar11 + 10) = uVar7;
              bVar19 = *pbVar30;
            }
            if ((bVar19 & 0x20) == 0) {
              *(int *)(psVar11 + 2) = (int)uVar18;
              psVar11[0xe] = 0;
              *(int *)(psVar11 + 0xc) = (int)uVar18;
            }
            else {
              puVar34 = (ushort *)(pbVar30 + uVar18);
              uVar16 = *puVar34;
              psVar11[0xe] = uVar16;
              if (uVar16 == 0) {
                *(undefined8 *)(puVar23 + -8) = 0x101c70;
                cVar4 = func_0x(0x1e691d0);
                if (cVar4 != '\0') {
                  *(undefined8 *)(puVar23 + -8) = 0x101c79;
                  lVar10 = func_0x();
                  if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar23 + -8) = 0x101c93;
                    cVar4 = func_0x(0x1e691d0);
                    if (cVar4 == '\0') {
                      *(undefined8 *)(puVar23 + -8) = 0x101caf;
                      (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar23 + 0x20) = 0;
                      *(undefined8 *)(puVar23 + -8) = 0x101cd5;
                      (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x80f);
                    }
                  }
                }
                uVar14 = *(undefined8 *)(psVar11 + 4);
                *(undefined8 *)(puVar23 + -8) = 0x101ce3;
                func_0x(uVar14,3);
                uVar18 = (ulonglong)*(uint *)(psVar11 + 10);
                uVar16 = psVar11[0xe];
              }
              uVar7 = (int)uVar18 + (uVar16 + 1) * 2;
              *(uint *)(psVar11 + 0xc) = uVar7;
              if (0x1f9e < uVar7) {
                *(undefined8 *)(puVar23 + -8) = 0x101d13;
                cVar4 = func_0x(0x1e691d0);
                if (cVar4 != '\0') {
                  *(undefined8 *)(puVar23 + -8) = 0x101d1c;
                  lVar10 = func_0x();
                  if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar23 + -8) = 0x101d36;
                    cVar4 = func_0x(0x1e691d0);
                    if (cVar4 == '\0') {
                      *(undefined8 *)(puVar23 + -8) = 0x101d52;
                      (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar23 + 0x20) = 0;
                      *(undefined8 *)(puVar23 + -8) = 0x101d78;
                      (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x816);
                    }
                  }
                }
                uVar14 = *(undefined8 *)(psVar11 + 4);
                *(undefined8 *)(puVar23 + -8) = 0x101d86;
                func_0x(uVar14,4);
                uVar16 = psVar11[0xe];
                uVar7 = *(uint *)(psVar11 + 0xc);
              }
              uVar18 = (ulonglong)uVar16;
              uVar16 = puVar34[uVar18];
              *(uint *)(psVar11 + 2) = uVar16 & 0x7fff;
              if ((uVar16 & 0x7fff) < uVar7) {
                *(undefined8 *)(puVar23 + -8) = 0x101db6;
                cVar4 = func_0x(0x1e691d0);
                if (cVar4 != '\0') {
                  *(undefined8 *)(puVar23 + -8) = 0x101dbf;
                  lVar10 = func_0x();
                  if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar23 + -8) = 0x101dd9;
                    cVar4 = func_0x(0x1e691d0);
                    if (cVar4 == '\0') {
                      *(undefined8 *)(puVar23 + -8) = 0x101df5;
                      (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar23 + 0x20) = 0;
                      *(undefined8 *)(puVar23 + -8) = 0x101e1b;
                      (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x81d);
                    }
                  }
                }
                uVar14 = *(undefined8 *)(psVar11 + 4);
                *(undefined8 *)(puVar23 + -8) = 0x101e29;
                func_0x(uVar14,4);
                uVar7 = *(uint *)(psVar11 + 0xc);
                uVar18 = (ulonglong)(ushort)psVar11[0xe];
              }
              ppbVar29 = ppbVar32;
              puVar2 = puVar34;
              if ((short)uVar18 != 0) {
                do {
                  uVar22 = puVar2[1] & 0x7fff;
                  if ((uVar22 < uVar7) || (*(uint *)(psVar11 + 2) < uVar22)) {
                    *(undefined8 *)(puVar23 + -8) = 0x101e6f;
                    cVar4 = func_0x(0x1e691d0);
                    if (cVar4 != '\0') {
                      *(undefined8 *)(puVar23 + -8) = 0x101e78;
                      lVar10 = func_0x();
                      if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar23 + -8) = 0x101e92;
                        cVar4 = func_0x(0x1e691d0);
                        if (cVar4 == '\0') {
                          *(undefined8 *)(puVar23 + -8) = 0x101eae;
                          (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar23 + 0x20) = 0;
                          *(undefined8 *)(puVar23 + -8) = 0x101ed2;
                          (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x82a);
                        }
                      }
                    }
                    uVar14 = *(undefined8 *)(psVar11 + 4);
                    *(undefined8 *)(puVar23 + -8) = 0x101ee0;
                    func_0x(uVar14,4);
                  }
                  uVar24 = (int)ppbVar29 + 1;
                  uVar18 = (ulonglong)(ushort)psVar11[0xe];
                  ppbVar29 = (byte **)(ulonglong)uVar24;
                  iVar9 = aiStack_c78[0];
                  puVar2 = puVar2 + 1;
                  uVar7 = uVar22;
                } while ((int)uVar24 < (int)(uint)(ushort)psVar11[0xe]);
              }
              if ((short)puVar34[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
                pbVar30 = *(byte **)(psVar11 + 4);
                do {
                  uVar22 = *(ushort *)(pbVar30 + uVar18 * 2 + (ulonglong)*(uint *)(psVar11 + 10)) &
                           0x7fff;
                  if ((int)uVar18 == 1) {
                    uVar24 = *(uint *)(psVar11 + 0xc);
                    uVar20 = uVar24;
code_r0x00101f52:
                    if ((uVar22 < uVar24) || (uVar7 = *(uint *)(psVar11 + 2), uVar7 < uVar22))
                    goto code_r0x00101f5d;
                  }
                  else {
                    uVar24 = *(ushort *)
                              (pbVar30 + uVar18 * 2 + ((ulonglong)*(uint *)(psVar11 + 10) - 2)) &
                             0x7fff;
                    uVar20 = *(uint *)(psVar11 + 0xc);
                    if (uVar20 <= uVar24) goto code_r0x00101f52;
code_r0x00101f5d:
                    *(undefined8 *)(puVar23 + -8) = 0x101f6a;
                    func_0x(pbVar30,7);
                    uVar20 = *(uint *)(psVar11 + 0xc);
                    uVar7 = *(uint *)(psVar11 + 2);
                  }
                  if ((uVar24 < uVar20) || (uVar7 < uVar24)) goto code_r0x001022e2;
                  pbVar30 = *(byte **)(psVar11 + 4);
                  if (*(ushort *)(pbVar30 + uVar24) == 5) {
                    *puVar33 = *puVar33 | 2;
                    psVar11[0xe] = psVar11[0xe] + -1;
                    uVar25 = (ulonglong)(uVar24 & 0xffff);
                    psVar11[0x15] = (short)uVar24;
                    uVar21 = *(ulonglong *)(psVar11 + 4);
                    uVar18 = uVar21 + uVar25;
                    uVar16 = psVar11[0x16] & 0xc7ff;
                    if ((*(ushort *)(uVar18 + 2) >> 0xe & 1) != 0) {
                      uVar16 = *(ushort *)(uVar18 + 2) & 0x3800 | uVar16;
                    }
                    psVar11[0x16] = uVar16;
                    uVar6 = (uVar16 ^ *(ushort *)(uVar18 + 2)) & 0x7ff ^ uVar16;
                    psVar11[0x16] = uVar6;
                    uVar26 = uVar21 + (ulonglong)((uVar6 & 0x7ff) * 2) + 4 +
                                      (uVar16 >> 0xb & 7) * 2 + uVar25;
                    if (uVar26 < uVar18) {
                      *(undefined8 *)(puVar23 + -8) = 0x102079;
                      func_0x(uVar18,0x19);
                      uVar6 = psVar11[0x16];
                      uVar25 = (ulonglong)(ushort)psVar11[0x15];
                      uVar21 = (ulonglong)*(uint *)(psVar11 + 4);
                    }
                    if (uVar22 - uVar24 <
                        (((uVar6 & 0x7ff) * 2 - (int)uVar25) - (int)uVar21) + (int)uVar26) {
                      lVar10 = *(longlong *)(psVar11 + 4);
                      *(undefined8 *)(puVar23 + -8) = 0x1020b1;
                      func_0x(uVar25 + lVar10,0x19);
                      uVar6 = psVar11[0x16];
                    }
                    if (((uVar6 & 0x3800) != 0) &&
                       (puVar34 = (ushort *)
                                  (*(longlong *)(psVar11 + 4) + 4 + (ulonglong)(ushort)psVar11[0x15]
                                  ), ppbVar29 = ppbVar32, (uVar6 & 0x3800) != 0)) {
                      do {
                        if ((uVar6 & 0x7ff) < (*puVar34 & 0x7ff)) {
                          uVar16 = psVar11[0x15];
                          lVar10 = *(longlong *)(psVar11 + 4);
                          *(undefined8 *)(puVar23 + -8) = 0x102107;
                          func_0x((ulonglong)uVar16 + lVar10,0x1a);
                          uVar6 = psVar11[0x16];
                        }
                        uVar7 = (int)ppbVar29 + 1;
                        ppbVar29 = (byte **)(ulonglong)uVar7;
                        puVar34 = puVar34 + 1;
                      } while ((int)uVar7 < (int)(uVar6 >> 0xb & 7));
                    }
                    goto code_r0x00102122;
                  }
                  if (*(ushort *)(pbVar30 + uVar24) < 0x400) goto code_r0x00102122;
                  *puVar33 = *puVar33 | 1;
                  uVar16 = psVar11[0xe] - 1;
                  psVar11[0xe] = uVar16;
                  if (uVar16 == 0) goto code_r0x00102122;
                  uVar18 = (ulonglong)uVar16;
                } while ((short)puVar34[(ulonglong)(uVar16 - 1) + 1] < 0);
                uVar18 = (ulonglong)*(uint *)(psVar11 + 2);
              }
              else {
code_r0x00102122:
                pbVar30 = *(byte **)(psVar11 + 4);
                uVar18 = (ulonglong)*(uint *)(psVar11 + 2);
              }
            }
            if ((*pbVar30 & 0x40) == 0) {
              *(undefined4 *)(psVar11 + 0x13) = 0;
            }
            else {
              *(int *)(psVar11 + 0x13) = (int)uVar18;
              *(int *)(psVar11 + 2) = (int)uVar18 + 0xe;
              *(undefined8 *)(puVar23 + -8) = 0x10214f;
              puVar15 = (ulonglong *)func_0x(puVar33);
              uVar6 = (ushort)(*puVar15 >> 0x30);
              uVar16 = uVar6;
              if ((((uint)(int)(short)uVar6 >> 1 ^ (int)(short)uVar6) & 0x2000) != 0) {
                uVar16 = uVar6 & 0xdfff;
                if ((uVar6 >> 0xe & 1) != 0) {
                  uVar16 = uVar6 | 0x2000;
                }
              }
              if (uVar16 == 0xfffc) {
                uVar27 = (uint)((*puVar15 >> 0x20 & 0xffff) >> 5);
              }
              *(uint *)(psVar11 + 2) = *(int *)(psVar11 + 2) + uVar27;
              uVar18 = (ulonglong)*(uint *)(psVar11 + 2);
            }
            uVar7 = (uint)uVar18;
            if ((*(ulonglong *)(psVar11 + 0xf) != 0) &&
               (*(ulonglong *)(psVar11 + 0xf) < uVar18 + *(longlong *)(psVar11 + 4))) {
              *(undefined8 *)(puVar23 + -8) = 0x1021da;
              cVar4 = func_0x(0x1e691d0);
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar23 + -8) = 0x1021e3;
                lVar10 = func_0x();
                if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar23 + -8) = 0x1021fd;
                  cVar4 = func_0x(0x1e691d0);
                  if (cVar4 == '\0') {
                    *(undefined8 *)(puVar23 + -8) = 0x102219;
                    (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar23 + 0x20) = 0;
                    *(undefined8 *)(puVar23 + -8) = 0x10223f;
                    (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x886);
                  }
                }
              }
              uVar14 = *(undefined8 *)(psVar11 + 4);
              *(undefined8 *)(puVar23 + -8) = 0x10224d;
              func_0x(uVar14,0x12);
              uVar7 = *(uint *)(psVar11 + 2);
            }
            if ((uVar7 == 0) || (0x3f3c < uVar7)) {
              *(undefined8 *)(puVar23 + -8) = 0x10226c;
              cVar4 = func_0x(0x1e691d0);
              if (cVar4 != '\0') {
                *(undefined8 *)(puVar23 + -8) = 0x102275;
                lVar10 = func_0x();
                if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar23 + -8) = 0x10228f;
                  cVar4 = func_0x(0x1e691d0);
                  if (cVar4 == '\0') {
                    *(undefined8 *)(puVar23 + -8) = 0x1022ab;
                    (*pcRam00000000013d6d58)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar23 + 0x20) = 0;
                    *(undefined8 *)(puVar23 + -8) = 0x1022d1;
                    (*pcRam00000000013d6d50)(1,0x1758bdc,0x1878cc8,0x88b);
                  }
                }
              }
              uVar14 = *(undefined8 *)(psVar11 + 4);
              *(undefined8 *)(puVar23 + -8) = 0x1022df;
              func_0x(uVar14,5);
              uVar7 = *(uint *)(psVar11 + 2);
            }
          }
code_r0x001022e2:
          if (uVar7 < 9) {
            bVar19 = **(byte **)(psVar11 + 4) & 0xe;
joined_r0x00102316:
            if ((bVar19 == 0) || (bVar19 == 0xc)) {
              uVar7 = 9;
            }
          }
        }
        else {
          if (uVar7 == 0) {
            *(undefined8 *)(puVar23 + -8) = 0x102304;
            func_0x(puVar33);
            uVar7 = *(uint *)(psVar11 + 2);
          }
          if (uVar7 < 9) {
            bVar19 = **(byte **)(psVar11 + 4) & 0x1c;
            goto joined_r0x00102316;
          }
        }
        lStack_c28 = lStack_c28 + (ulonglong)uVar7;
        if (0x1f9e < iStack_c04 - iVar9) goto LAB_;
        ppbVar29 = (byte **)(ulonglong)uStack_c00;
        param_5 = lStack_bf0;
        param_2 = lStack_bb0;
        param_1 = lStack_c20;
        param_4 = iStack_c04;
        iVar9 = aiStack_c78[0];
      }
      uStack_c30 = uStack_c30 + 1;
      ppbVar28 = (byte **)(ulonglong)uStack_c30;
      lStack_be8 = lStack_be8 + 1;
    } while ((int)uStack_c30 < *(int *)(param_1 + 8));
    iVar8 = (int)ppbVar29;
    if (iVar8 != 0) {
      *(double *)(param_1 + 0x1ff0) = (double)((param_4 - iVar9) / iVar8);
      lVar10 = *plStack_bd8;
      if (lVar10 != 0) {
        *(undefined8 *)(puVar23 + -8) = 0x1023b9;
        func_0x(lVar10,(longlong)(param_4 - iVar9) % (longlong)iVar8 & 0xffffffff);
      }
    }
  }
LAB_:
  uVar14 = uStack_a90;
  if (uStack_a98._2_2_ != 0) {
    *(undefined8 *)(puVar23 + -8) = 0x1023e1;
    (*_DAT_)(uVar14);
    uVar14 = uStack_a88;
    *(undefined8 *)(puVar23 + -8) = 0x1023ee;
    (*_DAT_)(uVar14);
  }
  uVar18 = uStack_58 ^ (ulonglong)aiStack_c78;
  *(undefined8 *)(puVar23 + -8) = 0x102400;
  func_0x(uVar18);
  return;
}

