
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2)

{
  ushort *puVar1;
  longlong *plVar2;
  ushort *puVar3;
  byte bVar4;
  char cVar5;
  ushort uVar6;
  ushort uVar7;
  uint uVar8;
  uint *puVar9;
  longlong lVar10;
  undefined8 uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  ulonglong uVar15;
  uint *puVar16;
  int iVar17;
  uint *puVar18;
  uint uVar19;
  ulonglong uVar20;
  short sVar21;
  byte *pbVar22;
  ulonglong uVar23;
  int iVar24;
  int iVar25;
  ushort *puVar26;
  uint uVar27;
  uint uVar28;
  uint auStackX_18 [2];
  uint uStackX_20;
  uint uStack_58;
  uint uStack_54;
  undefined auStack_50 [16];
  
  lVar10 = *(longlong *)(param_1 + 8);
  puVar16 = (uint *)0x0;
  uVar27 = 0;
  uStack_58 = 0;
  uStackX_20 = 0;
  uStack_54 = 0;
  puVar18 = puVar16;
  puVar9 = puVar16;
  uVar14 = 0;
  if (*(int *)(**(longlong **)(lVar10 + 0x160) + 0x14) == 0) {
LAB_:
    if ((*(int *)(lVar10 + 0xbc) < (int)uVar27) || (*(int *)(lVar10 + 0xc4) < (int)uVar14)) {
      iVar24 = uVar14 - *(int *)(lVar10 + 0xc4);
      iVar17 = uVar27 - *(int *)(lVar10 + 0xbc);
      if (iVar17 <= iVar24) {
        iVar17 = iVar24;
      }
      (*_DAT_)(6,0xb,0x10,1,iVar17);
    }
    return;
  }
LAB_:
  uVar28 = 0;
  uVar27 = (uint)puVar18;
  iVar17 = *(int *)(**(longlong **)(lVar10 + 0x160) + 0x14);
  uVar14 = (uint)puVar16;
  if (iVar17 != 0) {
    if (puVar9 == (uint *)0x0) {
      uVar19 = 0;
    }
    else {
      uVar19 = *puVar9;
    }
    iVar24 = uVar19 - 1;
    iVar25 = -iVar24;
    if (iVar25 <= iVar17) {
      while ((puVar9 = (uint *)func_0x(*(undefined8 *)(lVar10 + 0x160),iVar24),
             puVar9 == (uint *)0x0 || ((*(byte *)(puVar9 + 8) & 0x10) != 0))) {
        lVar10 = *(longlong *)(param_1 + 8);
        iVar24 = iVar24 + -1;
        iVar25 = iVar25 + 1;
        uVar14 = uStackX_20;
        if (*(int *)(**(longlong **)(lVar10 + 0x160) + 0x14) < iVar25) goto LAB_;
      }
      lVar10 = *(longlong *)(param_1 + 8);
      if (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(puVar9 + 0xd) + 0x14e0b10) + 0x14e1ca0
                   ) == '\x01') {
        puVar1 = (ushort *)(param_2 + 1);
        bVar4 = *(byte *)(puVar9 + 8);
        uVar14 = (uint)*(ushort *)(puVar9 + 0xe);
        if (*param_2 != 0) {
          uStack_58 = 0;
          lVar10 = func_0x(puVar1,puVar9,bVar4,auStackX_18,&uStack_58);
          uVar28 = auStackX_18[0];
          if ((((*param_2 != 0) && (plVar2 = *(longlong **)(param_2 + 8), plVar2 != (longlong *)0x0)
               ) && (*plVar2 != 0)) &&
             (((*(byte *)((longlong)puVar9 + 6) & 8) == 0 && ((uStack_58 & 1) == 0)))) {
            if ((lVar10 == 0) || (lVar10 == 0x14e04f0)) goto LAB_;
            func_0x(plVar2,puVar9,lVar10,auStackX_18[0],0,0,auStackX_18,uStack_58);
            uVar28 = auStackX_18[0];
          }
          goto LAB_;
        }
        uVar19 = *puVar9;
        if ((uVar19 & 0xc0000000) != 0x80000000) {
          if (((bVar4 & 2) != 0) || ((*(byte *)((longlong)puVar9 + 6) & 0x10) != 0)) {
            pbVar22 = *(byte **)(param_2 + 4);
            if ((*pbVar22 & 0x10) == 0) {
              if ((1 << (*pbVar22 & 0xe) & 0x1105U) != 0) goto LAB_;
              uVar13 = uVar28;
              uVar8 = 1;
LAB_:
              if ((bVar4 & 2) != 0) goto LAB_;
            }
            else {
              uVar13 = *(uint *)(param_2 + 8);
              if ((int)uVar13 <= (int)uVar19) {
LAB_:
                uVar13 = ~(uint)(*(ushort *)((longlong)puVar9 + 6) >> 4) & 1;
                uVar8 = uVar28;
                goto LAB_;
              }
              if ((uint)*(ushort *)(pbVar22 + uVar13) < (uint)*(ushort *)(puVar9 + 1))
              goto LAB_;
              if ((bVar4 & 2) == 0) goto LAB_;
              uVar12 = *(ushort *)(puVar9 + 1) - 1;
              uVar8 = 1;
              uVar13 = pbVar22[(ulonglong)(uVar12 >> 3) + (ulonglong)uVar13 + 2] >>
                       ((byte)uVar12 & 7) & 1;
LAB_:
              if (uVar13 != 0) goto LAB_;
            }
            if ((uVar8 == 0) && ((*(byte *)((longlong)puVar9 + 6) & 0x10) != 0)) {
              uVar28 = **(uint **)(puVar9 + 2);
              goto LAB_;
            }
          }
LAB_:
          if ((int)uVar19 < 0) {
            if (*(int *)(param_2 + 2) == 0) {
              pbVar22 = *(byte **)(param_2 + 4);
              uVar14 = *(uint *)(param_2 + 8);
              uVar15 = (ulonglong)uVar14;
              *puVar1 = 0;
              *(uint *)(param_2 + 10) = uVar14;
              bVar4 = *pbVar22;
              if ((bVar4 & 0x10) != 0) {
                uVar14 = uVar14 + 2 + (*(ushort *)(pbVar22 + uVar15) + 7 >> 3);
                uVar15 = (ulonglong)uVar14;
                *(uint *)(param_2 + 10) = uVar14;
                bVar4 = *pbVar22;
              }
              if ((bVar4 & 0x20) == 0) {
                *(int *)(param_2 + 2) = (int)uVar15;
                param_2[0xe] = 0;
                *(int *)(param_2 + 0xc) = (int)uVar15;
              }
              else {
                puVar26 = (ushort *)(pbVar22 + uVar15);
                uVar6 = *puVar26;
                param_2[0xe] = uVar6;
                if (uVar6 == 0) {
                  cVar5 = func_0x(0x1e6be50);
                  if (((cVar5 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
                     (*(char *)(lVar10 + 0x499) != '\0')) {
                    cVar5 = func_0x(0x1e6be50);
                    if (cVar5 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      (*_DAT_)(1,0x175b85c,0x187b948,0x80f,0);
                    }
                  }
                  func_0x(*(undefined8 *)(param_2 + 4),3);
                  uVar15 = (ulonglong)*(uint *)(param_2 + 10);
                  uVar6 = param_2[0xe];
                }
                uVar14 = (int)uVar15 + (uVar6 + 1) * 2;
                *(uint *)(param_2 + 0xc) = uVar14;
                if (0x1f9e < uVar14) {
                  cVar5 = func_0x(0x1e6be50);
                  if (((cVar5 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
                     (*(char *)(lVar10 + 0x499) != '\0')) {
                    cVar5 = func_0x(0x1e6be50);
                    if (cVar5 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      (*_DAT_)(1,0x175b85c,0x187b948,0x816,0);
                    }
                  }
                  func_0x(*(undefined8 *)(param_2 + 4),4);
                  uVar6 = param_2[0xe];
                  uVar14 = *(uint *)(param_2 + 0xc);
                }
                uVar15 = (ulonglong)uVar6;
                uVar6 = puVar26[uVar15];
                *(uint *)(param_2 + 2) = uVar6 & 0x7fff;
                if ((uVar6 & 0x7fff) < uVar14) {
                  cVar5 = func_0x(0x1e6be50);
                  if (((cVar5 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
                     (*(char *)(lVar10 + 0x499) != '\0')) {
                    cVar5 = func_0x(0x1e6be50);
                    if (cVar5 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      (*_DAT_)(1,0x175b85c,0x187b948,0x81d,0);
                    }
                  }
                  func_0x(*(undefined8 *)(param_2 + 4),4);
                  uVar14 = *(uint *)(param_2 + 0xc);
                  uVar15 = (ulonglong)(ushort)param_2[0xe];
                }
                puVar3 = puVar26;
                if ((short)uVar15 != 0) {
                  do {
                    uVar19 = puVar3[1] & 0x7fff;
                    if ((uVar19 < uVar14) || (*(uint *)(param_2 + 2) < uVar19)) {
                      cVar5 = func_0x(0x1e6be50);
                      if ((cVar5 != '\0') &&
                         ((lVar10 = func_0x(), lVar10 != 0 &&
                          (*(char *)(lVar10 + 0x499) != '\0')))) {
                        cVar5 = func_0x(0x1e6be50);
                        if (cVar5 == '\0') {
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          (*_DAT_)(1,0x175b85c,0x187b948,0x82a,0);
                        }
                      }
                      func_0x(*(undefined8 *)(param_2 + 4),4);
                    }
                    uVar15 = (ulonglong)(ushort)param_2[0xe];
                    uVar28 = uVar28 + 1;
                    puVar3 = puVar3 + 1;
                    uVar27 = uStack_58;
                    uVar14 = uVar19;
                  } while ((int)uVar28 < (int)(uint)(ushort)param_2[0xe]);
                }
                if ((short)puVar26[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
                  lVar10 = *(longlong *)(param_2 + 4);
                  do {
                    uVar14 = *(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar10 + uVar15 * 2) &
                             0x7fff;
                    if ((int)uVar15 == 1) {
                      uVar28 = *(uint *)(param_2 + 0xc);
                      uVar19 = uVar28;
LAB_:
                      if ((uVar14 < uVar28) || (*(uint *)(param_2 + 2) < uVar14)) goto LAB_;
                    }
                    else {
                      uVar19 = *(uint *)(param_2 + 0xc);
                      uVar28 = *(ushort *)
                                ((ulonglong)*(uint *)(param_2 + 10) + lVar10 + -2 + uVar15 * 2) &
                               0x7fff;
                      if (uVar19 <= uVar28) goto LAB_;
LAB_:
                      func_0x(lVar10,7);
                      uVar19 = *(uint *)(param_2 + 0xc);
                    }
                    if ((uVar28 < uVar19) || (*(uint *)(param_2 + 2) < uVar28)) goto LAB_;
                    lVar10 = *(longlong *)(param_2 + 4);
                    if (*(ushort *)(lVar10 + (ulonglong)uVar28) == 5) {
                      *puVar1 = *puVar1 | 2;
                      param_2[0xe] = param_2[0xe] + -1;
                      uVar23 = (ulonglong)(uVar28 & 0xffff);
                      param_2[0x15] = (short)uVar28;
                      uVar15 = *(ulonglong *)(param_2 + 4);
                      uVar6 = param_2[0x16] & 0xc7ffU;
                      if ((*(ushort *)(uVar23 + 2 + uVar15) >> 0xe & 1) != 0) {
                        uVar6 = *(ushort *)(uVar23 + 2 + uVar15) & 0x3800 | param_2[0x16] & 0xc7ffU;
                      }
                      param_2[0x16] = uVar6;
                      uVar7 = (uVar6 ^ *(ushort *)(uVar23 + 2 + uVar15)) & 0x7ff ^ uVar6;
                      param_2[0x16] = uVar7;
                      uVar20 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 +
                               uVar15 + (uVar6 >> 0xb & 7) * 2 + uVar23;
                      if (uVar20 < uVar23 + uVar15) {
                        func_0x(uVar23 + uVar15,0x19);
                        uVar7 = param_2[0x16];
                        uVar23 = (ulonglong)(ushort)param_2[0x15];
                        uVar15 = (ulonglong)*(uint *)(param_2 + 4);
                      }
                      if (uVar14 - uVar28 <
                          (((uVar7 & 0x7ff) * 2 - (int)uVar23) - (int)uVar15) + (int)uVar20) {
                        func_0x(uVar23 + *(longlong *)(param_2 + 4),0x19);
                        uVar7 = param_2[0x16];
                      }
                      iVar17 = 0;
                      if (((uVar7 & 0x3800) != 0) &&
                         (puVar26 = (ushort *)
                                    (*(longlong *)(param_2 + 4) + 4 +
                                    (ulonglong)(ushort)param_2[0x15]), (uVar7 & 0x3800) != 0))
                      goto LAB_;
                      break;
                    }
                    if (*(ushort *)(lVar10 + (ulonglong)uVar28) < 0x400) break;
                    *puVar1 = *puVar1 | 1;
                    uVar6 = param_2[0xe] - 1;
                    param_2[0xe] = uVar6;
                    if ((uVar6 == 0) ||
                       (uVar15 = (ulonglong)uVar6, -1 < (short)puVar26[(ulonglong)(uVar6 - 1) + 1]))
                    break;
                  } while( true );
                }
                pbVar22 = *(byte **)(param_2 + 4);
                uVar15 = (ulonglong)*(uint *)(param_2 + 2);
              }
              goto LAB_;
            }
            goto LAB_;
          }
          if ((*(ushort *)((longlong)puVar9 + 6) & 8) != 0) {
            auStackX_18[0] = 1;
            goto LAB_;
          }
          uVar28 = uVar14;
          if ((*(ushort *)((longlong)puVar9 + 6) & 0x10) != 0) {
            bVar4 = **(byte **)(param_2 + 4);
            if ((bVar4 & 0x10) == 0) {
              if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) goto LAB_;
            }
            else if (((int)*(uint *)(param_2 + 8) <= (int)uVar19) ||
                    (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
                     *(ushort *)(puVar9 + 1))) {
LAB_:
              uVar28 = **(uint **)(puVar9 + 2);
              if ((uVar14 != 0) && (uVar28 != uVar14)) {
                (*_DAT_)(1,0x1909ca0,0x1908608,0x381,0);
              }
            }
          }
          goto LAB_;
        }
        iVar17 = func_0x(puVar1);
        if (iVar17 != 0) {
          func_0x(param_2 + 0x15,puVar9,auStackX_18,&uStack_58);
          uVar28 = auStackX_18[0];
          goto LAB_;
        }
LAB_:
        auStackX_18[0] = 0;
        goto LAB_;
      }
      goto LAB_;
    }
  }
  goto LAB_;
LAB_:
  do {
    if ((uVar7 & 0x7ff) < (*puVar26 & 0x7ff)) {
      func_0x((ulonglong)(ushort)param_2[0x15] + *(longlong *)(param_2 + 4),0x1a);
      uVar7 = param_2[0x16];
    }
    iVar17 = iVar17 + 1;
    puVar26 = puVar26 + 1;
  } while (iVar17 < (int)(uVar7 >> 0xb & 7));
  pbVar22 = *(byte **)(param_2 + 4);
  uVar15 = (ulonglong)*(uint *)(param_2 + 2);
LAB_:
  if ((*pbVar22 & 0x40) == 0) {
    *(undefined4 *)(param_2 + 0x13) = 0;
  }
  else {
    *(int *)(param_2 + 0x13) = (int)uVar15;
    *(int *)(param_2 + 2) = (int)uVar15 + 0xe;
    uVar11 = func_0x(puVar1);
    func_0x(uVar11,auStack_50);
    iVar17 = func_0x(auStack_50);
    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar17;
    uVar15 = (ulonglong)*(uint *)(param_2 + 2);
  }
  iVar17 = (int)uVar15;
  if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
     (*(ulonglong *)(param_2 + 0xf) < uVar15 + *(longlong *)(param_2 + 4))) {
    cVar5 = func_0x(0x1e6be50);
    if ((cVar5 != '\0') &&
       ((lVar10 = func_0x(), lVar10 != 0 && (*(char *)(lVar10 + 0x499) != '\0')))) {
      cVar5 = func_0x(0x1e6be50);
      if (cVar5 == '\0') {
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        (*_DAT_)(1,0x175b85c,0x187b948,0x886,0);
      }
    }
    func_0x(*(undefined8 *)(param_2 + 4),0x12);
    iVar17 = *(int *)(param_2 + 2);
  }
  if (0x3f3b < iVar17 - 1U) {
    cVar5 = func_0x(0x1e6be50);
    if (((cVar5 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
       (*(char *)(lVar10 + 0x499) != '\0')) {
      cVar5 = func_0x(0x1e6be50);
      if (cVar5 == '\0') {
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        (*_DAT_)(1,0x175b85c,0x187b948,0x88b,0);
      }
    }
    func_0x(*(undefined8 *)(param_2 + 4),5);
  }
LAB_:
  sVar21 = -*(short *)puVar9;
  if ((*(byte *)((longlong)puVar9 + 6) & 0x10) == 0) {
LAB_:
    if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar21) {
      auStackX_18[0] = 0;
      goto LAB_;
    }
    lVar10 = (ulonglong)*(uint *)(param_2 + 10) + *(longlong *)(param_2 + 4);
    uVar14 = *(ushort *)(lVar10 + (longlong)sVar21 * 2) & 0x7fff;
    if (sVar21 == 1) {
      uVar28 = *(uint *)(param_2 + 0xc);
LAB_:
      if ((uVar14 < uVar28) || (*(uint *)(param_2 + 2) < uVar14)) goto LAB_;
    }
    else {
      uVar28 = *(ushort *)(lVar10 + -2 + (longlong)sVar21 * 2) & 0x7fff;
      if (*(uint *)(param_2 + 0xc) <= uVar28) goto LAB_;
LAB_:
      func_0x(*(longlong *)(param_2 + 4),7);
    }
    uVar28 = uVar14 - uVar28;
  }
  else {
    bVar4 = **(byte **)(param_2 + 4);
    if ((bVar4 & 0x10) != 0) {
      if (((int)*(uint *)(param_2 + 8) <= (int)*puVar9) ||
         (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) < *(ushort *)(puVar9 + 1)))
      goto LAB_;
      goto LAB_;
    }
    if ((1 << (bVar4 & 0xe) & 0x1105U) == 0) goto LAB_;
LAB_:
    uVar28 = **(uint **)(puVar9 + 2);
  }
LAB_:
  auStackX_18[0] = uVar28;
  if ((0x18 < auStackX_18[0]) && ((*(byte *)((longlong)puVar9 + 0x21) & 0x10) != 0)) {
    auStackX_18[0] = 0x18;
  }
LAB_:
  lVar10 = *(longlong *)(param_1 + 8);
  uStack_58 = uVar27 + 2 + auStackX_18[0];
  puVar18 = (uint *)(ulonglong)uStack_58;
  iVar17 = 0;
  if (8 < auStackX_18[0]) {
    iVar17 = 2;
  }
  uStackX_20 = uStackX_20 + iVar17 + auStackX_18[0];
LAB_:
  uVar27 = (uint)puVar18;
  puVar16 = (uint *)(ulonglong)uStackX_20;
  uStack_54 = uStack_54 + 1;
  uVar14 = uStackX_20;
  if (*(uint *)(**(longlong **)(lVar10 + 0x160) + 0x14) <= uStack_54) goto LAB_;
  goto LAB_;
}

