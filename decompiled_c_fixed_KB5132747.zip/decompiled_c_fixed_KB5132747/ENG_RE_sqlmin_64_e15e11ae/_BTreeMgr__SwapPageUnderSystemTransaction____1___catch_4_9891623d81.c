
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(undefined8 param_1,longlong param_2)

{
  ushort uVar1;
  undefined2 uVar2;
  uint uVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong lVar6;
  char cVar7;
  byte bVar8;
  int iVar9;
  ushort *puVar10;
  undefined2 *puVar11;
  uint *puVar12;
  undefined8 uVar13;
  
  (*_DAT_)(param_2 + 0x460,param_2 + 0x808);
  func_0x(*(undefined8 *)(param_2 + 0xe0));
  plVar5 = *(longlong **)(param_2 + 0x268);
  if (*plVar5 != 0) {
    puVar10 = (ushort *)(*plVar5 + 0x62);
    *(ushort **)(param_2 + 0x6f8) = puVar10;
    uVar1 = *puVar10;
    *(ushort *)(param_2 + 0x1c0) = uVar1;
    if (((uVar1 >> 10 & 1) == 0) || (*(short *)((longlong)plVar5 + 0xc) < 3)) {
      *(int *)(param_2 + 0xb0) = (int)*(short *)((longlong)plVar5 + 0xc);
      lVar6 = *plVar5;
      *(longlong *)(param_2 + 0xe0) = lVar6;
      puVar11 = (undefined2 *)(lVar6 + 0x62);
      *(undefined2 **)(param_2 + 0x700) = puVar11;
      uVar2 = *puVar11;
      *(undefined2 *)(param_2 + 0x1b8) = uVar2;
      if (((byte)uVar2 >> 3 & 1) != 0) {
        if (*(int *)(param_2 + 0xb0) == 3) {
          *(undefined4 *)(param_2 + 0xb0) = 4;
        }
        else if (*(int *)(param_2 + 0xb0) < 2) goto LAB_;
        puVar12 = (uint *)(*(longlong *)(param_2 + 0xe0) + 100);
        *(uint **)(param_2 + 0x708) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x318) = uVar3;
        if ((((uVar3 & 8) != 0) &&
            (lVar6 = *(longlong *)(*(longlong *)(param_2 + 0xe0) + 0x90), lVar6 != 0)) &&
           (*(longlong *)(param_2 + 0x710) = lVar6, *(longlong *)(lVar6 + 0x758) != 0)) {
          func_0x
                    (*(undefined8 *)(lVar6 + 0x758),*(undefined8 *)(param_2 + 0xe0),
                     *(undefined4 *)(param_2 + 0xb0));
        }
      }
LAB_:
      *(undefined4 *)(param_2 + 800) = 0x32f;
      cVar7 = DAT_ >> 7;
      *(char *)(param_2 + 0xf4) = -cVar7;
      if (-cVar7 != '\0') {
        puVar12 = (uint *)(*(longlong *)(param_2 + 0xe0) + 100);
        *(uint **)(param_2 + 0x718) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x328) = uVar3;
        if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0xb0))) {
          *(uint **)(param_2 + 0x720) = puVar12;
          uVar3 = *puVar12;
          *(uint *)(param_2 + 0x330) = uVar3;
          if (((uVar3 & 0xc0000000) != 0x40000000) &&
             (lVar6 = **(longlong **)(param_2 + 0xe0), lVar6 != 0)) {
            *(undefined4 *)(param_2 + 0x338) = 2;
            iVar9 = (*_DAT_)(lVar6,0x2000,2,param_2 + 0x33c);
            if (iVar9 != 0) {
              LOCK();
              *puVar12 = *puVar12 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar12 = *puVar12 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar6 = *(longlong *)(param_2 + 0xe0);
      uVar4 = *(undefined4 *)(param_2 + 0xb0);
      func_0x(lVar6 + 0x98,uVar4);
      if (_DAT_ != 0) {
        *(undefined4 *)(param_2 + 0x340) = 0xe79;
        bVar8 = DAT_ >> 1;
        *(byte *)(param_2 + 0xf5) = bVar8;
        if ((bVar8 & 1) != 0) {
          func_0x(lVar6,0,uVar4);
        }
      }
      *(uint *)((longlong)plVar5 + 0xc) = *(uint *)((longlong)plVar5 + 0xc) & 0xffff0000;
      *plVar5 = 0;
    }
    else {
      func_0x(plVar5);
    }
  }
  if (*(longlong *)(param_2 + 0x128) != 0) {
    puVar10 = (ushort *)(*(longlong *)(param_2 + 0x128) + 0x62);
    *(ushort **)(param_2 + 0x728) = puVar10;
    uVar1 = *puVar10;
    *(ushort *)(param_2 + 0x1b0) = uVar1;
    if (((uVar1 >> 10 & 1) == 0) || (*(short *)(param_2 + 0x134) < 3)) {
      *(int *)(param_2 + 0xb8) = (int)*(short *)(param_2 + 0x134);
      *(undefined8 *)(param_2 + 0x140) = *(undefined8 *)(param_2 + 0x128);
      *(ushort **)(param_2 + 0x730) = puVar10;
      uVar1 = *puVar10;
      *(ushort *)(param_2 + 0x1a8) = uVar1;
      if (((byte)uVar1 >> 3 & 1) != 0) {
        if (*(int *)(param_2 + 0xb8) == 3) {
          *(undefined4 *)(param_2 + 0xb8) = 4;
        }
        else if (*(int *)(param_2 + 0xb8) < 2) goto LAB_;
        puVar12 = (uint *)(*(longlong *)(param_2 + 0x128) + 100);
        *(uint **)(param_2 + 0x738) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x348) = uVar3;
        if ((((uVar3 & 8) != 0) &&
            (lVar6 = *(longlong *)(*(longlong *)(param_2 + 0x128) + 0x90), lVar6 != 0)) &&
           (*(longlong *)(param_2 + 0x740) = lVar6, *(longlong *)(lVar6 + 0x758) != 0)) {
          func_0x
                    (*(undefined8 *)(lVar6 + 0x758),*(undefined8 *)(param_2 + 0x128),
                     *(undefined4 *)(param_2 + 0xb8));
        }
      }
LAB_:
      *(undefined4 *)(param_2 + 0x350) = 0x32f;
      cVar7 = DAT_ >> 7;
      *(char *)(param_2 + 0xf6) = -cVar7;
      if (-cVar7 != '\0') {
        puVar12 = (uint *)(*(longlong *)(param_2 + 0x140) + 100);
        *(uint **)(param_2 + 0x748) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x358) = uVar3;
        if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0xb8))) {
          *(uint **)(param_2 + 0x750) = puVar12;
          uVar3 = *puVar12;
          *(uint *)(param_2 + 0x360) = uVar3;
          if (((uVar3 & 0xc0000000) != 0x40000000) &&
             (lVar6 = **(longlong **)(param_2 + 0x140), lVar6 != 0)) {
            *(undefined4 *)(param_2 + 0x368) = 2;
            iVar9 = (*_DAT_)(lVar6,0x2000,2,param_2 + 0x36c);
            if (iVar9 != 0) {
              LOCK();
              *puVar12 = *puVar12 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar12 = *puVar12 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar6 = *(longlong *)(param_2 + 0x140);
      uVar4 = *(undefined4 *)(param_2 + 0xb8);
      func_0x(lVar6 + 0x98,uVar4);
      if (_DAT_ != 0) {
        *(undefined4 *)(param_2 + 0x370) = 0xe79;
        bVar8 = DAT_ >> 1;
        *(byte *)(param_2 + 0xf7) = bVar8;
        if ((bVar8 & 1) != 0) {
          func_0x(lVar6,0,uVar4);
        }
      }
      *(uint *)(param_2 + 0x134) = *(uint *)(param_2 + 0x134) & 0xffff0000;
      *(undefined8 *)(param_2 + 0x128) = 0;
    }
    else {
      func_0x(param_2 + 0x128);
    }
  }
  plVar5 = *(longlong **)(param_2 + 0x3f0);
  if (*plVar5 != 0) {
    puVar10 = (ushort *)(*plVar5 + 0x62);
    *(ushort **)(param_2 + 0x758) = puVar10;
    uVar1 = *puVar10;
    *(ushort *)(param_2 + 0x230) = uVar1;
    if (((uVar1 >> 10 & 1) == 0) || (*(short *)((longlong)plVar5 + 0xc) < 3)) {
      *(int *)(param_2 + 0xc0) = (int)*(short *)((longlong)plVar5 + 0xc);
      lVar6 = *plVar5;
      *(longlong *)(param_2 + 0xe8) = lVar6;
      puVar11 = (undefined2 *)(lVar6 + 0x62);
      *(undefined2 **)(param_2 + 0x760) = puVar11;
      uVar2 = *puVar11;
      *(undefined2 *)(param_2 + 0x1a0) = uVar2;
      if (((byte)uVar2 >> 3 & 1) != 0) {
        if (*(int *)(param_2 + 0xc0) == 3) {
          *(undefined4 *)(param_2 + 0xc0) = 4;
        }
        else if (*(int *)(param_2 + 0xc0) < 2) goto LAB_;
        puVar12 = (uint *)(*(longlong *)(param_2 + 0xe8) + 100);
        *(uint **)(param_2 + 0x768) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x378) = uVar3;
        if ((((uVar3 & 8) != 0) &&
            (lVar6 = *(longlong *)(*(longlong *)(param_2 + 0xe8) + 0x90), lVar6 != 0)) &&
           (*(longlong *)(param_2 + 0x770) = lVar6, *(longlong *)(lVar6 + 0x758) != 0)) {
          func_0x
                    (*(undefined8 *)(lVar6 + 0x758),*(undefined8 *)(param_2 + 0xe8),
                     *(undefined4 *)(param_2 + 0xc0));
        }
      }
LAB_:
      *(undefined4 *)(param_2 + 0x380) = 0x32f;
      cVar7 = DAT_ >> 7;
      *(char *)(param_2 + 0xf8) = -cVar7;
      if (-cVar7 != '\0') {
        puVar12 = (uint *)(*(longlong *)(param_2 + 0xe8) + 100);
        *(uint **)(param_2 + 0x778) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x388) = uVar3;
        if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0xc0))) {
          *(uint **)(param_2 + 0x780) = puVar12;
          uVar3 = *puVar12;
          *(uint *)(param_2 + 0x390) = uVar3;
          if (((uVar3 & 0xc0000000) != 0x40000000) &&
             (lVar6 = **(longlong **)(param_2 + 0xe8), lVar6 != 0)) {
            *(undefined4 *)(param_2 + 0x398) = 2;
            iVar9 = (*_DAT_)(lVar6,0x2000,2,param_2 + 0x39c);
            if (iVar9 != 0) {
              LOCK();
              *puVar12 = *puVar12 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar12 = *puVar12 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar6 = *(longlong *)(param_2 + 0xe8);
      uVar4 = *(undefined4 *)(param_2 + 0xc0);
      func_0x(lVar6 + 0x98,uVar4);
      if (_DAT_ != 0) {
        *(undefined4 *)(param_2 + 0x3a0) = 0xe79;
        bVar8 = DAT_ >> 1;
        *(byte *)(param_2 + 0xf9) = bVar8;
        if ((bVar8 & 1) != 0) {
          func_0x(lVar6,0,uVar4);
        }
      }
      *(uint *)((longlong)plVar5 + 0xc) = *(uint *)((longlong)plVar5 + 0xc) & 0xffff0000;
      *plVar5 = 0;
    }
    else {
      func_0x(plVar5);
    }
  }
  plVar5 = *(longlong **)(param_2 + 0x3f8);
  if (*plVar5 != 0) {
    puVar10 = (ushort *)(*plVar5 + 0x62);
    *(ushort **)(param_2 + 0x788) = puVar10;
    uVar1 = *puVar10;
    *(ushort *)(param_2 + 0x198) = uVar1;
    if (((uVar1 >> 10 & 1) == 0) || (*(short *)((longlong)plVar5 + 0xc) < 3)) {
      *(int *)(param_2 + 0xa8) = (int)*(short *)((longlong)plVar5 + 0xc);
      lVar6 = *plVar5;
      *(longlong *)(param_2 + 0xd8) = lVar6;
      puVar11 = (undefined2 *)(lVar6 + 0x62);
      *(undefined2 **)(param_2 + 0x790) = puVar11;
      uVar2 = *puVar11;
      *(undefined2 *)(param_2 + 400) = uVar2;
      if (((byte)uVar2 >> 3 & 1) != 0) {
        if (*(int *)(param_2 + 0xa8) == 3) {
          *(undefined4 *)(param_2 + 0xa8) = 4;
        }
        else if (*(int *)(param_2 + 0xa8) < 2) goto LAB_;
        puVar12 = (uint *)(*(longlong *)(param_2 + 0xd8) + 100);
        *(uint **)(param_2 + 0x798) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x3a8) = uVar3;
        if ((((uVar3 & 8) != 0) &&
            (lVar6 = *(longlong *)(*(longlong *)(param_2 + 0xd8) + 0x90), lVar6 != 0)) &&
           (*(longlong *)(param_2 + 0x7a0) = lVar6, *(longlong *)(lVar6 + 0x758) != 0)) {
          func_0x
                    (*(undefined8 *)(lVar6 + 0x758),*(undefined8 *)(param_2 + 0xd8),
                     *(undefined4 *)(param_2 + 0xa8));
        }
      }
LAB_:
      *(undefined4 *)(param_2 + 0x3b0) = 0x32f;
      cVar7 = DAT_ >> 7;
      *(char *)(param_2 + 0xfa) = -cVar7;
      if (-cVar7 != '\0') {
        puVar12 = (uint *)(*(longlong *)(param_2 + 0xd8) + 100);
        *(uint **)(param_2 + 0x7a8) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x3b8) = uVar3;
        if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0xa8))) {
          *(uint **)(param_2 + 0x7b0) = puVar12;
          uVar3 = *puVar12;
          *(uint *)(param_2 + 0x3c0) = uVar3;
          if (((uVar3 & 0xc0000000) != 0x40000000) &&
             (lVar6 = **(longlong **)(param_2 + 0xd8), lVar6 != 0)) {
            *(undefined4 *)(param_2 + 0x3c8) = 2;
            iVar9 = (*_DAT_)(lVar6,0x2000,2,param_2 + 0x268);
            if (iVar9 != 0) {
              LOCK();
              *puVar12 = *puVar12 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar12 = *puVar12 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar6 = *(longlong *)(param_2 + 0xd8);
      uVar4 = *(undefined4 *)(param_2 + 0xa8);
      func_0x(lVar6 + 0x98,uVar4);
      if (_DAT_ != 0) {
        *(undefined4 *)(param_2 + 0x100) = 0xe79;
        bVar8 = DAT_ >> 1;
        *(byte *)(param_2 + 0xfb) = bVar8;
        if ((bVar8 & 1) != 0) {
          func_0x(lVar6,0,uVar4);
        }
      }
      *(uint *)((longlong)plVar5 + 0xc) = *(uint *)((longlong)plVar5 + 0xc) & 0xffff0000;
      *plVar5 = 0;
    }
    else {
      func_0x(plVar5);
    }
  }
  plVar5 = *(longlong **)(param_2 + 0x400);
  if (*plVar5 == 0) goto LAB_;
  puVar10 = (ushort *)(*plVar5 + 0x62);
  *(ushort **)(param_2 + 0x7b8) = puVar10;
  uVar1 = *puVar10;
  *(ushort *)(param_2 + 0x188) = uVar1;
  if (((uVar1 >> 10 & 1) != 0) && (2 < *(short *)((longlong)plVar5 + 0xc))) {
    func_0x(plVar5);
    goto LAB_;
  }
  *(int *)(param_2 + 0xa0) = (int)*(short *)((longlong)plVar5 + 0xc);
  lVar6 = *plVar5;
  *(longlong *)(param_2 + 0xd0) = lVar6;
  puVar11 = (undefined2 *)(lVar6 + 0x62);
  *(undefined2 **)(param_2 + 0x7c0) = puVar11;
  uVar2 = *puVar11;
  *(undefined2 *)(param_2 + 0x218) = uVar2;
  if (((byte)uVar2 >> 3 & 1) != 0) {
    if (*(int *)(param_2 + 0xa0) == 3) {
      *(undefined4 *)(param_2 + 0xa0) = 4;
    }
    else if (*(int *)(param_2 + 0xa0) < 2) goto LAB_;
    puVar12 = (uint *)(*(longlong *)(param_2 + 0xd0) + 100);
    *(uint **)(param_2 + 0x7c8) = puVar12;
    uVar3 = *puVar12;
    *(uint *)(param_2 + 0x240) = uVar3;
    if ((((uVar3 & 8) != 0) &&
        (lVar6 = *(longlong *)(*(longlong *)(param_2 + 0xd0) + 0x90), lVar6 != 0)) &&
       (*(longlong *)(param_2 + 2000) = lVar6, *(longlong *)(lVar6 + 0x758) != 0)) {
      func_0x
                (*(undefined8 *)(lVar6 + 0x758),*(undefined8 *)(param_2 + 0xd0),
                 *(undefined4 *)(param_2 + 0xa0));
    }
  }
LAB_:
  cVar7 = DAT_ >> 7;
  *(char *)(param_2 + 0x9a) = -cVar7;
  if (-cVar7 != '\0') {
    puVar12 = (uint *)(*(longlong *)(param_2 + 0xd0) + 100);
    *(uint **)(param_2 + 0x7d8) = puVar12;
    uVar3 = *puVar12;
    *(uint *)(param_2 + 0x248) = uVar3;
    if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0xa0))) {
      *(uint **)(param_2 + 0x7e0) = puVar12;
      uVar3 = *puVar12;
      *(uint *)(param_2 + 0x250) = uVar3;
      if (((uVar3 & 0xc0000000) != 0x40000000) && (**(longlong **)(param_2 + 0xd0) != 0)) {
        iVar9 = (*_DAT_)(**(longlong **)(param_2 + 0xd0),0x2000,2,param_2 + 600);
        if (iVar9 != 0) {
          LOCK();
          *puVar12 = *puVar12 & 0x3fffffff;
          UNLOCK();
          LOCK();
          *puVar12 = *puVar12 | 0x40000000;
          UNLOCK();
        }
      }
    }
  }
  lVar6 = *(longlong *)(param_2 + 0xd0);
  uVar4 = *(undefined4 *)(param_2 + 0xa0);
  func_0x(lVar6 + 0x98,uVar4);
  if ((_DAT_ != 0) && ((DAT_ >> 1 & 1) != 0)) {
    func_0x(lVar6,0,uVar4);
  }
  *(uint *)((longlong)plVar5 + 0xc) = *(uint *)((longlong)plVar5 + 0xc) & 0xffff0000;
  *plVar5 = 0;
LAB_:
  uVar13 = (*_DAT_)(param_2 + 0x460);
  (*_DAT_)(uVar13);
  (*_DAT_)(param_2 + 0x460);
  return 0xfffffffffed7ef2f;
}

