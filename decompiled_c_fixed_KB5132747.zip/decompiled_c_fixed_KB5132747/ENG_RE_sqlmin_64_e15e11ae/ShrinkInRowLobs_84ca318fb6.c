
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2)

{
  longlong lVar1;
  longlong lVar2;
  ushort *puVar3;
  byte bVar4;
  char cVar5;
  ushort uVar6;
  uint uVar7;
  int iVar8;
  longlong lVar9;
  longlong lVar10;
  undefined8 *puVar11;
  ushort uVar12;
  ushort uVar13;
  uint uVar14;
  ulonglong uVar15;
  ushort *puVar16;
  uint uVar17;
  uint uVar18;
  ulonglong uVar19;
  byte *pbVar20;
  ulonglong uVar21;
  int iVar22;
  ushort *puVar23;
  undefined8 uStack_58;
  longlong lStack_50;
  
  lVar2 = *(longlong *)(param_1 + 0x58);
  if (*param_2 == 0) {
    uVar7 = func_0x(param_2 + 1);
  }
  else {
    uVar7 = (uint)(ushort)param_2[1];
  }
  uVar17 = 0;
  if (0 < (int)uVar7) {
    do {
      if ((~uVar17 & 0xc0000000) == 0x80000000) {
        lVar9 = func_0x
                          (**(undefined8 **)(*(longlong *)(lVar2 + 8) + 0x160),~uVar17 & 0x1fffffff)
        ;
      }
      else {
        lVar9 = func_0x(*(undefined8 *)(*(longlong *)(lVar2 + 8) + 0x160));
      }
      if ((lVar9 != 0) &&
         ((*(short *)(lVar9 + 0x38) == -1 ||
          (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar9 + 0x34) + 0x833030) + 0x11ea0c8
                    ) != '\0')))) {
        func_0x(param_1,lVar9,param_2);
      }
      uVar17 = uVar17 + 1;
    } while ((int)uVar17 < (int)uVar7);
  }
  puVar16 = (ushort *)(param_2 + 1);
  uVar7 = 0;
  iVar22 = -1;
  iVar8 = func_0x(param_2);
  lStack_50 = (longlong)iVar8;
  if (lStack_50 < 1) {
    return;
  }
  lVar9 = 0;
LAB_:
  iVar8 = 0;
  if (*(int *)(param_2 + 2) == 0) {
    pbVar20 = *(byte **)(param_2 + 4);
    uVar17 = *(uint *)(param_2 + 8);
    uVar15 = (ulonglong)uVar17;
    *puVar16 = 0;
    *(uint *)(param_2 + 10) = uVar17;
    bVar4 = *pbVar20;
    if ((bVar4 & 0x10) != 0) {
      uVar17 = uVar17 + 2 + (*(ushort *)(pbVar20 + uVar15) + 7 >> 3);
      uVar15 = (ulonglong)uVar17;
      *(uint *)(param_2 + 10) = uVar17;
      bVar4 = *pbVar20;
    }
    if ((bVar4 & 0x20) == 0) {
      *(int *)(param_2 + 2) = (int)uVar15;
      param_2[0xe] = 0;
      *(int *)(param_2 + 0xc) = (int)uVar15;
    }
    else {
      puVar23 = (ushort *)(pbVar20 + uVar15);
      uVar6 = *puVar23;
      param_2[0xe] = uVar6;
      if (uVar6 == 0) {
        cVar5 = func_0x(0x11be370);
        if (((cVar5 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
           (*(char *)(lVar10 + 0x499) != '\0')) {
          cVar5 = func_0x(0x11be370);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0xaadd7c,0xbcde68,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),3);
        uVar15 = (ulonglong)*(uint *)(param_2 + 10);
        uVar6 = param_2[0xe];
      }
      uVar17 = (int)uVar15 + (uVar6 + 1) * 2;
      *(uint *)(param_2 + 0xc) = uVar17;
      if (0x1f9e < uVar17) {
        cVar5 = func_0x(0x11be370);
        if (((cVar5 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
           (*(char *)(lVar10 + 0x499) != '\0')) {
          cVar5 = func_0x(0x11be370);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xaadd7c,0xbcde68,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),4);
        uVar6 = param_2[0xe];
        uVar17 = *(uint *)(param_2 + 0xc);
      }
      uVar15 = (ulonglong)uVar6;
      uVar6 = puVar23[uVar15];
      *(uint *)(param_2 + 2) = uVar6 & 0x7fff;
      if ((uVar6 & 0x7fff) < uVar17) {
        cVar5 = func_0x(0x11be370);
        if (((cVar5 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
           (*(char *)(lVar10 + 0x499) != '\0')) {
          cVar5 = func_0x(0x11be370);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xaadd7c,0xbcde68,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),4);
        uVar17 = *(uint *)(param_2 + 0xc);
        uVar15 = (ulonglong)(ushort)param_2[0xe];
      }
      puVar3 = puVar23;
      if ((short)uVar15 != 0) {
        do {
          uVar18 = puVar3[1] & 0x7fff;
          if ((uVar18 < uVar17) || (*(uint *)(param_2 + 2) < uVar18)) {
            cVar5 = func_0x(0x11be370);
            if ((cVar5 != '\0') &&
               ((lVar10 = func_0x(), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              cVar5 = func_0x(0x11be370);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0xaadd7c,0xbcde68,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
          }
          uVar15 = (ulonglong)(ushort)param_2[0xe];
          iVar8 = iVar8 + 1;
          puVar3 = puVar3 + 1;
          uVar17 = uVar18;
        } while (iVar8 < (int)(uint)(ushort)param_2[0xe]);
      }
      if ((short)puVar23[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
        lVar10 = *(longlong *)(param_2 + 4);
        do {
          uVar17 = *(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar10 + uVar15 * 2) & 0x7fff;
          if ((int)uVar15 == 1) {
            uVar18 = *(uint *)(param_2 + 0xc);
            uVar14 = uVar18;
LAB_:
            if ((uVar17 < uVar18) || (*(uint *)(param_2 + 2) < uVar17)) goto LAB_;
          }
          else {
            uVar14 = *(uint *)(param_2 + 0xc);
            uVar18 = *(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar10 + -2 + uVar15 * 2) &
                     0x7fff;
            if (uVar14 <= uVar18) goto LAB_;
LAB_:
            func_0x(lVar10,7);
            uVar14 = *(uint *)(param_2 + 0xc);
          }
          if ((uVar18 < uVar14) || (*(uint *)(param_2 + 2) < uVar18)) goto LAB_;
          lVar10 = *(longlong *)(param_2 + 4);
          if (*(ushort *)(lVar10 + (ulonglong)uVar18) == 5) {
            *puVar16 = *puVar16 | 2;
            param_2[0xe] = param_2[0xe] + -1;
            uVar21 = (ulonglong)(uVar18 & 0xffff);
            param_2[0x15] = (short)uVar18;
            uVar15 = *(ulonglong *)(param_2 + 4);
            uVar6 = param_2[0x16] & 0xc7ffU;
            if ((*(ushort *)(uVar21 + 2 + uVar15) >> 0xe & 1) != 0) {
              uVar6 = *(ushort *)(uVar21 + 2 + uVar15) & 0x3800 | param_2[0x16] & 0xc7ffU;
            }
            param_2[0x16] = uVar6;
            uVar13 = (uVar6 ^ *(ushort *)(uVar21 + 2 + uVar15)) & 0x7ff ^ uVar6;
            param_2[0x16] = uVar13;
            uVar19 = (ulonglong)((uVar13 & 0x7ff) * 2) + 4 + uVar21 + (uVar6 >> 0xb & 7) * 2 +
                     uVar15;
            if (uVar19 < uVar21 + uVar15) {
              func_0x(uVar21 + uVar15,0x19);
              uVar13 = param_2[0x16];
              uVar21 = (ulonglong)(ushort)param_2[0x15];
              uVar15 = (ulonglong)*(uint *)(param_2 + 4);
            }
            if (uVar17 - uVar18 < (((uVar13 & 0x7ff) * 2 - (int)uVar21) - (int)uVar15) + (int)uVar19
               ) {
              func_0x(uVar21 + *(longlong *)(param_2 + 4),0x19);
              uVar13 = param_2[0x16];
            }
            iVar8 = 0;
            if (((uVar13 & 0x3800) != 0) &&
               (puVar23 = (ushort *)
                          (*(longlong *)(param_2 + 4) + 4 + (ulonglong)(ushort)param_2[0x15]),
               (uVar13 & 0x3800) != 0)) goto LAB_;
            break;
          }
          if (*(ushort *)(lVar10 + (ulonglong)uVar18) < 0x400) break;
          *puVar16 = *puVar16 | 1;
          uVar6 = param_2[0xe] - 1;
          param_2[0xe] = uVar6;
          if ((uVar6 == 0) ||
             (uVar15 = (ulonglong)uVar6, -1 < (short)puVar23[(ulonglong)(uVar6 - 1) + 1])) break;
        } while( true );
      }
      pbVar20 = *(byte **)(param_2 + 4);
      uVar15 = (ulonglong)*(uint *)(param_2 + 2);
    }
    goto LAB_;
  }
  goto LAB_;
LAB_:
  do {
    if ((uVar13 & 0x7ff) < (*puVar23 & 0x7ff)) {
      func_0x((ulonglong)(ushort)param_2[0x15] + *(longlong *)(param_2 + 4),0x1a);
      uVar13 = param_2[0x16];
    }
    iVar8 = iVar8 + 1;
    puVar23 = puVar23 + 1;
  } while (iVar8 < (int)(uVar13 >> 0xb & 7));
  pbVar20 = *(byte **)(param_2 + 4);
  uVar15 = (ulonglong)*(uint *)(param_2 + 2);
LAB_:
  if ((*pbVar20 & 0x40) == 0) {
    *(undefined4 *)(param_2 + 0x13) = 0;
  }
  else {
    *(int *)(param_2 + 0x13) = (int)uVar15;
    *(int *)(param_2 + 2) = (int)uVar15 + 0xe;
    puVar11 = (undefined8 *)func_0x(puVar16);
    uStack_58 = *puVar11;
    iVar8 = func_0x(&uStack_58);
    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar8;
    uVar15 = (ulonglong)*(uint *)(param_2 + 2);
  }
  iVar8 = (int)uVar15;
  if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
     (*(ulonglong *)(param_2 + 0xf) < uVar15 + *(longlong *)(param_2 + 4))) {
    cVar5 = func_0x(0x11be370);
    if ((cVar5 != '\0') &&
       ((lVar10 = func_0x(), lVar10 != 0 && (*(char *)(lVar10 + 0x499) != '\0')))) {
      cVar5 = func_0x(0x11be370);
      if (cVar5 == '\0') {
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        (*_DAT_)(1,0xaadd7c,0xbcde68,0x886,0);
      }
    }
    func_0x(*(undefined8 *)(param_2 + 4),0x12);
    iVar8 = *(int *)(param_2 + 2);
  }
  if (0x3f3b < iVar8 - 1U) {
    cVar5 = func_0x(0x11be370);
    if (((cVar5 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
       (*(char *)(lVar10 + 0x499) != '\0')) {
      cVar5 = func_0x(0x11be370);
      if (cVar5 == '\0') {
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        (*_DAT_)(1,0xaadd7c,0xbcde68,0x88b,0);
      }
    }
    func_0x(*(undefined8 *)(param_2 + 4),5);
  }
LAB_:
  iVar8 = func_0x(puVar16);
  if (iVar8 == 0) {
    iVar8 = func_0x(puVar16);
    if (iVar8 == 0) {
      (*_DAT_)(1,0xc69a98,0xc5ab28,0xd7a,0);
    }
  }
  else {
    uVar6 = param_2[0x16];
    lVar10 = 0;
    if (uVar7 < (uVar6 & 0x7ff)) {
      uVar13 = 0;
      lVar1 = *(longlong *)(param_2 + 4) + (ulonglong)(ushort)param_2[0x15];
      if ((uVar6 & 0x3800) == 0) {
        uVar12 = *(ushort *)(lVar1 + 2);
LAB_:
        uVar13 = uVar12 >> 0xb & 7;
      }
      else if ((uVar6 >> 0xb & 7) != 0) {
        do {
          if (((lVar10 == 0) || ((*(ushort *)(lVar1 + 2 + lVar10 * 2) & 0x7ff) <= uVar7)) &&
             (uVar12 = *(ushort *)(lVar1 + 4 + lVar10 * 2),
             (int)uVar7 <= (int)((uVar12 & 0x7ff) - 1))) goto LAB_;
          lVar10 = lVar10 + 1;
        } while (lVar10 < (longlong)(ulonglong)(uVar6 >> 0xb & 7));
      }
      iVar22 = (uint)*(ushort *)
                      ((ulonglong)((uVar6 >> 0xb & 7) * 2) + *(longlong *)(param_2 + 4) + lVar9 * 2
                       + 4 + (ulonglong)(ushort)param_2[0x15]) + (uint)uVar13 * 0x10000;
    }
    else {
      (*_DAT_)(1,0xc69a68,0xc69a30,0x41a,0);
    }
  }
  lVar10 = func_0x(**(undefined8 **)(*(longlong *)(lVar2 + 8) + 0x160),iVar22);
  if ((lVar10 != 0) &&
     ((*(short *)(lVar10 + 0x38) == -1 ||
      (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar10 + 0x34) + 0x833030) + 0x11ea0c8)
       != '\0')))) {
    func_0x(param_1,lVar10,param_2);
  }
  uVar7 = uVar7 + 1;
  lVar9 = lVar9 + 1;
  if (lStack_50 <= lVar9) {
    return;
  }
  goto LAB_;
}

