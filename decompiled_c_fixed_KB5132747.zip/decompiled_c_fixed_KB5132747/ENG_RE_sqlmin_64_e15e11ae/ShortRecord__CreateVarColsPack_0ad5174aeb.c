
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,ulonglong param_3,uint param_4,ushort *param_5)

{
  ushort *puVar1;
  code *pcVar2;
  longlong lVar3;
  byte bVar4;
  char cVar5;
  ushort uVar6;
  uint uVar7;
  int iVar8;
  short *psVar9;
  uint *puVar10;
  uint *puVar11;
  longlong lVar12;
  undefined8 uVar13;
  longlong lVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  undefined *puVar17;
  uint uVar18;
  uint uVar19;
  ulonglong uVar20;
  short sVar21;
  ushort uVar22;
  uint uVar23;
  byte *pbVar24;
  ushort uVar25;
  ushort *puVar26;
  ushort *puVar27;
  undefined auStack_e8 [64];
  uint uStack_a8;
  ushort uStack_a4;
  uint uStack_a0;
  undefined4 uStack_9c;
  uint *puStack_98;
  uint uStack_90;
  uint uStack_8c;
  uint uStack_88;
  uint uStack_84;
  int iStack_80;
  longlong lStack_78;
  longlong lStack_70;
  longlong lStack_68;
  longlong lStack_60;
  uint uStack_58;
  ushort *puStack_50;
  undefined auStack_48 [8];
  longlong lStack_40;
  ulonglong uStack_38;
  
  puVar17 = auStack_e8;
  uStack_38 = _DAT_ ^ (ulonglong)&uStack_a8;
  uVar20 = 0;
  uStack_a0 = 0;
  uStack_9c = (uStack_9c >> 0x10 & 0xffe0) << 0x10;
  lVar12 = *(longlong *)(param_2 + 8);
  puStack_98 = (uint *)0x0;
  uStack_84 = 0;
  lStack_60 = 0;
  iStack_80 = -1;
  uVar16 = uVar20;
  uStack_8c = param_4;
  lStack_70 = param_2;
  lStack_40 = param_1;
  if (*(int *)(lVar12 + 0x100) == 2) {
    if ((*(byte *)(lVar12 + 0x42) & 4) == 0) {
      uVar16 = (ulonglong)*(uint *)(lVar12 + 0xb0);
      if (0x1f9e < *(uint *)(lVar12 + 0xb0)) {
        uVar16 = 0x1f9e;
      }
    }
    else {
      uVar16 = 0x1f9e;
    }
    uStack_84 = (uint)uVar16;
    uVar15 = uVar16 + 0xf;
    if (uVar15 <= uVar16) {
      uVar15 = 0xffffffffffffff0;
    }
    uVar15 = uVar15 & 0xfffffffffffffff0;
    func_0x();
    puVar17 = auStack_e8 + -uVar15;
    lStack_60 = (longlong)&uStack_a8 + -uVar15;
  }
  lVar12 = lStack_60;
  psVar9 = *(short **)(param_1 + 8);
  if (*(undefined8 **)(param_1 + 0x10) != (undefined8 *)0x0) {
    pcVar2 = *(code **)**(undefined8 **)(param_1 + 0x10);
    *(undefined8 *)(puVar17 + -8) = 0x1000e8;
    psVar9 = (short *)(*pcVar2)();
  }
  if ((uint)param_3 != 0) {
    if (param_4 == 0) {
      *(undefined8 *)(puVar17 + 0x20) = 0;
      *(undefined8 *)(puVar17 + -8) = 0x100119;
      (*_DAT_)(1,0xbdbc10,0xb85f98,0x596);
    }
    uStack_a4 = 0;
    *param_5 = (ushort)param_3;
    puVar1 = (ushort *)(psVar9 + 1);
    lStack_68 = (longlong)param_5 +
                (param_3 & 0xffff) * 2 + (ulonglong)((~((uint)param_3 & 0xffff) & 1) * 2) + 2;
    while( true ) {
      uVar23 = (uint)uVar20;
      uStack_90 = uVar23;
      if (*psVar9 == 0) {
        *(undefined8 *)(puVar17 + -8) = 0x10015e;
        uVar7 = func_0x(puVar1);
      }
      else {
        uVar7 = (uint)*puVar1;
      }
      if ((int)uVar7 <= (int)uVar23) break;
      uVar7 = ~uVar23;
      uStack_58 = uVar7;
      if ((int)uVar23 < 0) {
LAB_:
        lVar14 = lStack_70;
        *(undefined8 *)(puVar17 + -8) = 0x1001e0;
        func_0x(lVar14,uVar7,&uStack_a0);
      }
      else {
        if ((uVar7 & 0xc0000000) == 0x80000000) {
          uVar13 = **(undefined8 **)(*(longlong *)(lStack_70 + 8) + 0x160);
          *(undefined8 *)(puVar17 + -8) = 0x1001c2;
          puVar10 = (uint *)func_0x(uVar13,uVar7 & 0x1fffffff);
        }
        else {
          uVar13 = *(undefined8 *)(*(longlong *)(lStack_70 + 8) + 0x160);
          *(undefined8 *)(puVar17 + -8) = 0x1001a7;
          puVar10 = (uint *)func_0x(uVar13);
        }
        if (puVar10 == (uint *)0x0) goto LAB_;
        uStack_a0 = *puVar10;
        uStack_9c = puVar10[1];
        puStack_98 = *(uint **)(puVar10 + 2);
      }
      *(undefined8 *)(puVar17 + -8) = 0x1001ec;
      iVar8 = func_0x(psVar9,&uStack_a0);
      uVar25 = uStack_a4;
      if (iVar8 == 0) {
        uVar16 = (ulonglong)uStack_a4;
        if (uStack_a4 == 0) {
          uVar6 = ((~*param_5 & 1) + *param_5 * 3 + 1) * 2;
        }
        else {
          uVar6 = param_5[uVar16] & 0x7fff;
        }
        param_5[uVar16 + 1] = uVar6 & 0x7fff;
        *(uint *)(lStack_68 + uVar16 * 4) = uVar7;
        if ((ushort)param_4 < uVar6) {
          *(undefined8 *)(puVar17 + 0x20) = 0;
          *(undefined8 *)(puVar17 + -8) = 0x100d20;
          (*_DAT_)(1,0xbdbc28,0xb85f98,0x5c5);
        }
      }
      else {
        if (*psVar9 == 0) {
          if ((uStack_a0 & 0xc0000000) == 0x80000000) {
            *(undefined8 *)(puVar17 + -8) = 0x100ae8;
            iVar8 = func_0x(puVar1);
            if (iVar8 == 0) {
LAB_:
              puVar11 = (uint *)0x0;
              puVar10 = puVar11;
LAB_:
              uVar18 = (uint)puVar11;
            }
            else {
              *(undefined8 *)(puVar17 + -8) = 0x100b04;
              puVar10 = (uint *)func_0x(psVar9 + 0x15,&uStack_a0,&uStack_a8,&lStack_78);
              uVar18 = uStack_a8;
            }
          }
          else {
            uVar25 = uStack_9c._2_2_ >> 4 & 1;
            if (uVar25 != 0) {
              bVar4 = **(byte **)(psVar9 + 4);
              if ((bVar4 & 0x10) == 0) {
                if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
                  puVar11 = (uint *)(ulonglong)*puStack_98;
                  puVar10 = puStack_98 + 1;
                  goto LAB_;
                }
              }
              else if (((int)*(uint *)(psVar9 + 8) <= (int)uStack_a0) ||
                      (*(ushort *)(*(byte **)(psVar9 + 4) + *(uint *)(psVar9 + 8)) <
                       (ushort)uStack_9c)) goto LAB_;
            }
            if ((int)uStack_a0 < 0) {
              if (*(int *)(psVar9 + 2) == 0) {
                pbVar24 = *(byte **)(psVar9 + 4);
                iVar8 = 0;
                uVar23 = *(uint *)(psVar9 + 8);
                uVar16 = (ulonglong)uVar23;
                *puVar1 = 0;
                *(uint *)(psVar9 + 10) = uVar23;
                bVar4 = *pbVar24;
                if ((bVar4 & 0x10) != 0) {
                  uVar23 = uVar23 + 2 + (*(ushort *)(pbVar24 + uVar16) + 7 >> 3);
                  uVar16 = (ulonglong)uVar23;
                  *(uint *)(psVar9 + 10) = uVar23;
                  bVar4 = *pbVar24;
                }
                if ((bVar4 & 0x20) == 0) {
                  *(int *)(psVar9 + 2) = (int)uVar16;
                  psVar9[0xe] = 0;
                  *(int *)(psVar9 + 0xc) = (int)uVar16;
                }
                else {
                  puVar26 = (ushort *)(pbVar24 + uVar16);
                  uVar25 = *puVar26;
                  psVar9[0xe] = uVar25;
                  if (uVar25 == 0) {
                    *(undefined8 *)(puVar17 + -8) = 0x1003a6;
                    cVar5 = func_0x(0x110e8a0);
                    if (cVar5 != '\0') {
                      *(undefined8 *)(puVar17 + -8) = 0x1003af;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar17 + -8) = 0x1003c9;
                        cVar5 = func_0x(0x110e8a0);
                        if (cVar5 == '\0') {
                          *(undefined8 *)(puVar17 + -8) = 0x1003e5;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(puVar17 + 0x20) = 0;
                          *(undefined8 *)(puVar17 + -8) = 0x10040b;
                          (*_DAT_)(1,0x9fe2ac,0xb1e398,0x80f);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar9 + 4);
                    *(undefined8 *)(puVar17 + -8) = 0x100419;
                    func_0x(uVar13,3);
                    uVar16 = (ulonglong)*(uint *)(psVar9 + 10);
                    uVar25 = psVar9[0xe];
                  }
                  uVar23 = (int)uVar16 + (uint)uVar25 * 2 + 2;
                  *(uint *)(psVar9 + 0xc) = uVar23;
                  if (0x1f9e < uVar23) {
                    *(undefined8 *)(puVar17 + -8) = 0x100449;
                    cVar5 = func_0x(0x110e8a0);
                    if (cVar5 != '\0') {
                      *(undefined8 *)(puVar17 + -8) = 0x100452;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar17 + -8) = 0x10046c;
                        cVar5 = func_0x(0x110e8a0);
                        if (cVar5 == '\0') {
                          *(undefined8 *)(puVar17 + -8) = 0x100488;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar17 + 0x20) = 0;
                          *(undefined8 *)(puVar17 + -8) = 0x1004ae;
                          (*_DAT_)(1,0x9fe2ac,0xb1e398,0x816);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar9 + 4);
                    *(undefined8 *)(puVar17 + -8) = 0x1004bc;
                    func_0x(uVar13,4);
                    uVar25 = psVar9[0xe];
                    uVar23 = *(uint *)(psVar9 + 0xc);
                  }
                  uVar16 = (ulonglong)uVar25;
                  uVar25 = puVar26[uVar16];
                  *(uint *)(psVar9 + 2) = uVar25 & 0x7fff;
                  if ((uVar25 & 0x7fff) < uVar23) {
                    *(undefined8 *)(puVar17 + -8) = 0x1004ed;
                    cVar5 = func_0x(0x110e8a0);
                    if (cVar5 != '\0') {
                      *(undefined8 *)(puVar17 + -8) = 0x1004f6;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar17 + -8) = 0x100510;
                        cVar5 = func_0x(0x110e8a0);
                        if (cVar5 == '\0') {
                          *(undefined8 *)(puVar17 + -8) = 0x10052c;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar17 + 0x20) = 0;
                          *(undefined8 *)(puVar17 + -8) = 0x100552;
                          (*_DAT_)(1,0x9fe2ac,0xb1e398,0x81d);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar9 + 4);
                    *(undefined8 *)(puVar17 + -8) = 0x100560;
                    func_0x(uVar13,4);
                    uVar23 = *(uint *)(psVar9 + 0xc);
                    uVar16 = (ulonglong)(ushort)psVar9[0xe];
                  }
                  puVar27 = puVar26;
                  if ((short)uVar16 != 0) {
                    do {
                      uVar18 = puVar27[1] & 0x7fff;
                      if ((uVar18 < uVar23) || (*(uint *)(psVar9 + 2) < uVar18)) {
                        *(undefined8 *)(puVar17 + -8) = 0x1005a0;
                        cVar5 = func_0x(0x110e8a0);
                        if (cVar5 != '\0') {
                          *(undefined8 *)(puVar17 + -8) = 0x1005a9;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar17 + -8) = 0x1005c3;
                            cVar5 = func_0x(0x110e8a0);
                            if (cVar5 == '\0') {
                              *(undefined8 *)(puVar17 + -8) = 0x1005df;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar17 + 0x20) = 0;
                              *(undefined8 *)(puVar17 + -8) = 0x100605;
                              (*_DAT_)(1,0x9fe2ac,0xb1e398,0x82a);
                            }
                          }
                        }
                        uVar13 = *(undefined8 *)(psVar9 + 4);
                        *(undefined8 *)(puVar17 + -8) = 0x100613;
                        func_0x(uVar13,4);
                      }
                      uVar16 = (ulonglong)(ushort)psVar9[0xe];
                      iVar8 = iVar8 + 1;
                      uVar7 = uStack_58;
                      puVar27 = puVar27 + 1;
                      uVar23 = uVar18;
                    } while (iVar8 < (int)(uint)(ushort)psVar9[0xe]);
                  }
                  if ((short)puVar26[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
                    lVar12 = *(longlong *)(psVar9 + 4);
                    do {
                      uVar23 = *(ushort *)((ulonglong)*(uint *)(psVar9 + 10) + lVar12 + uVar16 * 2)
                               & 0x7fff;
                      if ((int)uVar16 == 1) {
                        uVar18 = *(uint *)(psVar9 + 0xc);
                        uVar19 = uVar18;
LAB_:
                        if ((uVar23 < uVar18) || (*(uint *)(psVar9 + 2) < uVar23))
                        goto LAB_;
                      }
                      else {
                        uVar19 = *(uint *)(psVar9 + 0xc);
                        uVar18 = *(ushort *)
                                  ((ulonglong)*(uint *)(psVar9 + 10) + lVar12 + -2 + uVar16 * 2) &
                                 0x7fff;
                        if (uVar19 <= uVar18) goto LAB_;
LAB_:
                        *(undefined8 *)(puVar17 + -8) = 0x100691;
                        func_0x(lVar12,7);
                        uVar19 = *(uint *)(psVar9 + 0xc);
                      }
                      if ((uVar18 < uVar19) || (*(uint *)(psVar9 + 2) < uVar18)) goto LAB_;
                      lVar12 = *(longlong *)(psVar9 + 4);
                      if (*(ushort *)((ulonglong)uVar18 + lVar12) == 5) {
                        *puVar1 = *puVar1 | 2;
                        psVar9[0xe] = psVar9[0xe] + -1;
                        uVar20 = (ulonglong)(uVar18 & 0xffff);
                        psVar9[0x15] = (short)uVar18;
                        uVar16 = *(ulonglong *)(psVar9 + 4);
                        uVar25 = psVar9[0x16] & 0xc7ffU;
                        if ((*(ushort *)(uVar20 + 2 + uVar16) >> 0xe & 1) != 0) {
                          uVar25 = *(ushort *)(uVar20 + 2 + uVar16) & 0x3800 |
                                   psVar9[0x16] & 0xc7ffU;
                        }
                        psVar9[0x16] = uVar25;
                        uVar6 = (uVar25 ^ *(ushort *)(uVar20 + 2 + uVar16)) & 0x7ff ^ uVar25;
                        psVar9[0x16] = uVar6;
                        uVar15 = (ulonglong)((uVar6 & 0x7ff) * 2) + 4 +
                                 uVar20 + (uVar25 >> 0xb & 7) * 2 + uVar16;
                        if (uVar15 < uVar20 + uVar16) {
                          *(undefined8 *)(puVar17 + -8) = 0x1007d7;
                          func_0x(uVar20 + uVar16,0x19);
                          uVar6 = psVar9[0x16];
                          uVar20 = (ulonglong)(ushort)psVar9[0x15];
                          uVar16 = (ulonglong)*(uint *)(psVar9 + 4);
                        }
                        if (uVar23 - uVar18 <
                            (((uVar6 & 0x7ff) * 2 - (int)uVar20) - (int)uVar16) + (int)uVar15) {
                          lVar12 = *(longlong *)(psVar9 + 4);
                          *(undefined8 *)(puVar17 + -8) = 0x10080f;
                          func_0x(uVar20 + lVar12,0x19);
                          uVar6 = psVar9[0x16];
                        }
                        iVar8 = 0;
                        if (((uVar6 & 0x3800) != 0) &&
                           (puVar26 = (ushort *)
                                      (*(longlong *)(psVar9 + 4) + 4 +
                                      (ulonglong)(ushort)psVar9[0x15]), (uVar6 & 0x3800) != 0)) {
                          do {
                            if ((uVar6 & 0x7ff) < (*puVar26 & 0x7ff)) {
                              uVar25 = psVar9[0x15];
                              lVar12 = *(longlong *)(psVar9 + 4);
                              *(undefined8 *)(puVar17 + -8) = 0x100877;
                              func_0x((ulonglong)uVar25 + lVar12,0x1a);
                              uVar6 = psVar9[0x16];
                            }
                            iVar8 = iVar8 + 1;
                            puVar26 = puVar26 + 1;
                          } while (iVar8 < (int)(uVar6 >> 0xb & 7));
                        }
                        break;
                      }
                      if (*(ushort *)((ulonglong)uVar18 + lVar12) < 0x400) break;
                      *puVar1 = *puVar1 | 1;
                      uVar25 = psVar9[0xe] - 1;
                      psVar9[0xe] = uVar25;
                      if ((uVar25 == 0) ||
                         (uVar16 = (ulonglong)uVar25,
                         -1 < (short)puVar26[(ulonglong)(uVar25 - 1) + 1])) break;
                    } while( true );
                  }
                }
                if ((**(byte **)(psVar9 + 4) & 0x40) == 0) {
                  *(undefined4 *)(psVar9 + 0x13) = 0;
                }
                else {
                  *(int *)(psVar9 + 0x13) = *(int *)(psVar9 + 2);
                  *(int *)(psVar9 + 2) = *(int *)(psVar9 + 2) + 0xe;
                  *(undefined8 *)(puVar17 + -8) = 0x100719;
                  uVar13 = func_0x(puVar1);
                  *(undefined8 *)(puVar17 + -8) = 0x100725;
                  func_0x(uVar13,&puStack_50);
                  *(undefined8 *)(puVar17 + -8) = 0x10072e;
                  iVar8 = func_0x(&puStack_50);
                  *(int *)(psVar9 + 2) = *(int *)(psVar9 + 2) + iVar8;
                }
                if ((*(ulonglong *)(psVar9 + 0xf) != 0) &&
                   (*(ulonglong *)(psVar9 + 0xf) <
                    (ulonglong)*(uint *)(psVar9 + 2) + *(longlong *)(psVar9 + 4))) {
                  *(undefined8 *)(puVar17 + -8) = 0x1008d9;
                  cVar5 = func_0x(0x110e8a0);
                  if (cVar5 != '\0') {
                    *(undefined8 *)(puVar17 + -8) = 0x1008e2;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar17 + -8) = 0x1008fc;
                      cVar5 = func_0x(0x110e8a0);
                      if (cVar5 == '\0') {
                        *(undefined8 *)(puVar17 + -8) = 0x100918;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(puVar17 + 0x20) = 0;
                        *(undefined8 *)(puVar17 + -8) = 0x10093e;
                        (*_DAT_)(1,0x9fe2ac,0xb1e398,0x886);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar9 + 4);
                  *(undefined8 *)(puVar17 + -8) = 0x10094c;
                  func_0x(uVar13,0x12);
                }
                if (0x3f3b < *(int *)(psVar9 + 2) - 1U) {
                  *(undefined8 *)(puVar17 + -8) = 0x10096b;
                  cVar5 = func_0x(0x110e8a0);
                  if (cVar5 != '\0') {
                    *(undefined8 *)(puVar17 + -8) = 0x100974;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar17 + -8) = 0x10098e;
                      cVar5 = func_0x(0x110e8a0);
                      if (cVar5 == '\0') {
                        *(undefined8 *)(puVar17 + -8) = 0x1009aa;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(puVar17 + 0x20) = 0;
                        *(undefined8 *)(puVar17 + -8) = 0x1009d0;
                        (*_DAT_)(1,0x9fe2ac,0xb1e398,0x88b);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar9 + 4);
                  *(undefined8 *)(puVar17 + -8) = 0x1009de;
                  func_0x(uVar13,5);
                }
              }
LAB_:
              sVar21 = -(short)uStack_a0;
              uVar23 = uStack_90;
              if ((uStack_9c & 0x100000) == 0) {
LAB_:
                lVar12 = (longlong)sVar21;
                if ((uint)(ushort)psVar9[0xe] < (uint)(int)sVar21) {
                  uStack_a8 = 0;
                  puVar10 = *(uint **)(psVar9 + 4);
                  uVar18 = uStack_a8;
                }
                else {
                  lVar14 = (ulonglong)*(uint *)(psVar9 + 10) + *(longlong *)(psVar9 + 4);
                  if (sVar21 == 1) {
                    uVar18 = *(uint *)(psVar9 + 0xc);
                    uVar19 = *(ushort *)(lVar14 + lVar12 * 2) & 0x7fff;
LAB_:
                    if ((uVar19 < uVar18) || (*(uint *)(psVar9 + 2) < uVar19))
                    goto code_r0x00100aaf;
                  }
                  else {
                    uVar18 = *(ushort *)(lVar14 + -2 + lVar12 * 2) & 0x7fff;
                    uVar19 = *(ushort *)(lVar14 + lVar12 * 2) & 0x7fff;
                    if (*(uint *)(psVar9 + 0xc) <= uVar18) goto LAB_;
code_r0x00100aaf:
                    uVar13 = *(undefined8 *)(psVar9 + 4);
                    *(undefined8 *)(puVar17 + -8) = 0x100abd;
                    func_0x(uVar13,7);
                  }
                  puVar10 = (uint *)((ulonglong)uVar18 + *(longlong *)(psVar9 + 4));
                  uVar23 = uStack_90;
                  uVar18 = uVar19 - uVar18;
                }
              }
              else {
                if ((**(byte **)(psVar9 + 4) & 0x10) == 0) {
                  if ((1 << (**(byte **)(psVar9 + 4) & 0xe) & 0x1105U) == 0) goto LAB_;
                }
                else if ((int)uStack_a0 < *(int *)(psVar9 + 8)) {
                  if ((**(byte **)(psVar9 + 4) & 0x10) == 0) {
                    uVar18 = 0;
                  }
                  else {
                    uVar18 = (uint)*(ushort *)
                                    ((ulonglong)*(uint *)(psVar9 + 8) + *(longlong *)(psVar9 + 4));
                  }
                  if ((uStack_9c & 0xffff) <= uVar18) goto LAB_;
                }
                puVar10 = puStack_98 + 1;
                uVar18 = *puStack_98;
              }
            }
            else if ((uStack_9c & 0x80000) == 0) {
              if (uVar25 != 0) {
                bVar4 = **(byte **)(psVar9 + 4);
                if ((bVar4 & 0x10) == 0) {
                  if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
                    uVar18 = *puStack_98;
                    puVar10 = puStack_98 + 1;
                    if (uVar18 != 0x1f9e) {
                      *(undefined8 *)(puVar17 + 0x20) = 0;
                      *(undefined8 *)(puVar17 + -8) = 0x100300;
                      (*_DAT_)(1,0xbac6f0,0xbab058,0x381);
                    }
                    goto LAB_;
                  }
                }
                else if (((int)*(uint *)(psVar9 + 8) <= (int)uStack_a0) ||
                        (*(ushort *)(*(byte **)(psVar9 + 4) + *(uint *)(psVar9 + 8)) <
                         (ushort)uStack_9c)) goto LAB_;
              }
              uStack_a8 = 0x1f9e;
              puVar10 = (uint *)((longlong)(int)uStack_a0 + *(longlong *)(psVar9 + 4));
              uVar18 = uStack_a8;
            }
            else {
              puVar10 = (uint *)0x782f40;
              uStack_a8 = 1;
              uVar18 = uStack_a8;
              if ((*(byte *)(*(longlong *)(psVar9 + 4) + (longlong)(int)uStack_a0) &
                  (byte)(1 << (uStack_9c._2_1_ & 7))) == 0) {
                puVar10 = (uint *)0x782f41;
              }
            }
          }
        }
        else {
          uStack_88 = 0;
          *(uint **)(puVar17 + 0x20) = &uStack_88;
          *(undefined8 *)(puVar17 + -8) = 0x100b5e;
          puVar10 = (uint *)func_0x(puVar1,&uStack_a0);
          uVar18 = uStack_a8;
          if (((*psVar9 != 0) && (*(longlong *)(psVar9 + 8) != 0)) &&
             ((**(longlong **)(psVar9 + 8) != 0 &&
              (((uStack_9c & 0x80000) == 0 && ((uStack_88 & 1) == 0)))))) {
            uVar13 = 0;
            if (*psVar9 != 0) {
              uVar13 = *(undefined8 *)(psVar9 + 8);
            }
            if ((puVar10 == (uint *)0x0) || (puVar10 == (uint *)0x782f40)) goto LAB_;
            *(uint *)(puVar17 + 0x38) = uStack_88;
            *(uint **)(puVar17 + 0x30) = &uStack_a8;
            *(int *)(puVar17 + 0x28) = (int)uVar16;
            *(longlong *)(puVar17 + 0x20) = lVar12;
            *(undefined8 *)(puVar17 + -8) = 0x100be2;
            puVar10 = (uint *)func_0x(uVar13,&uStack_a0,puVar10,uVar18);
            uVar18 = uStack_a8;
          }
        }
LAB_:
        uStack_a8 = uVar18;
        uVar16 = (ulonglong)uStack_a4;
        if (uStack_a4 == 0) {
          uVar25 = ((~*param_5 & 1) + *param_5 * 3 + 1) * 2;
        }
        else {
          uVar25 = param_5[uVar16] & 0x7fff;
        }
        param_5[uVar16 + 1] = (short)uStack_a8 + uVar25 & 0x7fff;
        *(uint *)(lStack_68 + uVar16 * 4) = uVar7;
        if ((uStack_8c & 0xffff) < (uint)uVar25 + (uStack_a8 & 0xffff)) {
          *(undefined8 *)(puVar17 + 0x20) = 0;
          *(undefined8 *)(puVar17 + -8) = 0x100c66;
          (*_DAT_)(1,0xbdbc28,0xb85f98,0x5c5);
        }
        uVar7 = uStack_a8;
        param_5[uVar16 + 1] = param_5[uVar16 + 1] | 0x8000;
        *(undefined8 *)(puVar17 + -8) = 0x100c88;
        func_0x((ulonglong)uVar25 + (longlong)param_5,uVar7,puVar10,uVar7);
        uVar25 = uStack_a4;
        param_4 = uStack_8c;
      }
      uVar20 = (ulonglong)(uVar23 + 1);
      uStack_a4 = uVar25 + 1;
      uVar16 = (ulonglong)uStack_84;
      lVar12 = lStack_60;
    }
    uVar23 = 0;
    *(undefined8 *)(puVar17 + -8) = 0x100d43;
    iVar8 = func_0x(psVar9);
    lStack_60 = (longlong)iVar8;
    if (0 < lStack_60) {
      lStack_78 = 0;
      uStack_90 = 0;
      do {
        iVar8 = 0;
        lVar12 = 0;
        if (*(int *)(psVar9 + 2) == 0) {
          pbVar24 = *(byte **)(psVar9 + 4);
          uVar7 = *(uint *)(psVar9 + 8);
          uVar16 = (ulonglong)uVar7;
          *puVar1 = 0;
          *(uint *)(psVar9 + 10) = uVar7;
          bVar4 = *pbVar24;
          if ((bVar4 & 0x10) != 0) {
            uVar7 = uVar7 + 2 + (*(ushort *)(pbVar24 + uVar16) + 7 >> 3);
            uVar16 = (ulonglong)uVar7;
            *(uint *)(psVar9 + 10) = uVar7;
            bVar4 = *pbVar24;
          }
          if ((bVar4 & 0x20) == 0) {
            *(int *)(psVar9 + 2) = (int)uVar16;
            psVar9[0xe] = 0;
            *(int *)(psVar9 + 0xc) = (int)uVar16;
          }
          else {
            puVar26 = (ushort *)(pbVar24 + uVar16);
            uVar25 = *puVar26;
            psVar9[0xe] = uVar25;
            puStack_50 = puVar26;
            if (uVar25 == 0) {
              *(undefined8 *)(puVar17 + -8) = 0x100dc8;
              cVar5 = func_0x(0x110e8a0);
              if (cVar5 != '\0') {
                *(undefined8 *)(puVar17 + -8) = 0x100dd1;
                lVar14 = func_0x();
                if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar17 + -8) = 0x100deb;
                  cVar5 = func_0x(0x110e8a0);
                  if (cVar5 == '\0') {
                    *(undefined8 *)(puVar17 + -8) = 0x100e07;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar17 + 0x20) = 0;
                    *(undefined8 *)(puVar17 + -8) = 0x100e2d;
                    (*_DAT_)(1,0x9fe2ac,0xb1e398,0x80f);
                  }
                }
              }
              uVar13 = *(undefined8 *)(psVar9 + 4);
              *(undefined8 *)(puVar17 + -8) = 0x100e3b;
              func_0x(uVar13,3);
              uVar16 = (ulonglong)*(uint *)(psVar9 + 10);
              uVar25 = psVar9[0xe];
            }
            uVar7 = (int)uVar16 + (uVar25 + 1) * 2;
            *(uint *)(psVar9 + 0xc) = uVar7;
            if (0x1f9e < uVar7) {
              *(undefined8 *)(puVar17 + -8) = 0x100e6b;
              cVar5 = func_0x(0x110e8a0);
              if (cVar5 != '\0') {
                *(undefined8 *)(puVar17 + -8) = 0x100e74;
                lVar14 = func_0x();
                if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar17 + -8) = 0x100e8e;
                  cVar5 = func_0x(0x110e8a0);
                  if (cVar5 == '\0') {
                    *(undefined8 *)(puVar17 + -8) = 0x100eaa;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar17 + 0x20) = 0;
                    *(undefined8 *)(puVar17 + -8) = 0x100ed0;
                    (*_DAT_)(1,0x9fe2ac,0xb1e398,0x816);
                  }
                }
              }
              uVar13 = *(undefined8 *)(psVar9 + 4);
              *(undefined8 *)(puVar17 + -8) = 0x100ede;
              func_0x(uVar13,4);
              uVar25 = psVar9[0xe];
              uVar7 = *(uint *)(psVar9 + 0xc);
            }
            uVar16 = (ulonglong)uVar25;
            uVar25 = puVar26[uVar16];
            *(uint *)(psVar9 + 2) = uVar25 & 0x7fff;
            if ((uVar25 & 0x7fff) < uVar7) {
              *(undefined8 *)(puVar17 + -8) = 0x100f11;
              cVar5 = func_0x(0x110e8a0);
              if (cVar5 != '\0') {
                *(undefined8 *)(puVar17 + -8) = 0x100f1a;
                lVar14 = func_0x();
                if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar17 + -8) = 0x100f34;
                  cVar5 = func_0x(0x110e8a0);
                  if (cVar5 == '\0') {
                    *(undefined8 *)(puVar17 + -8) = 0x100f50;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar17 + 0x20) = 0;
                    *(undefined8 *)(puVar17 + -8) = 0x100f76;
                    (*_DAT_)(1,0x9fe2ac,0xb1e398,0x81d);
                  }
                }
              }
              uVar13 = *(undefined8 *)(psVar9 + 4);
              *(undefined8 *)(puVar17 + -8) = 0x100f84;
              func_0x(uVar13,4);
              uVar7 = *(uint *)(psVar9 + 0xc);
              uVar16 = (ulonglong)(ushort)psVar9[0xe];
            }
            puVar27 = puVar26;
            if ((short)uVar16 != 0) {
              do {
                puVar26 = puVar26 + 1;
                uVar18 = *puVar26 & 0x7fff;
                if ((uVar18 < uVar7) || (*(uint *)(psVar9 + 2) < uVar18)) {
                  *(undefined8 *)(puVar17 + -8) = 0x100fd0;
                  cVar5 = func_0x(0x110e8a0);
                  if (cVar5 != '\0') {
                    *(undefined8 *)(puVar17 + -8) = 0x100fd9;
                    lVar14 = func_0x();
                    if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar17 + -8) = 0x100ff3;
                      cVar5 = func_0x(0x110e8a0);
                      if (cVar5 == '\0') {
                        *(undefined8 *)(puVar17 + -8) = 0x10100f;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar17 + 0x20) = 0;
                        *(undefined8 *)(puVar17 + -8) = 0x101035;
                        (*_DAT_)(1,0x9fe2ac,0xb1e398,0x82a);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(psVar9 + 4);
                  *(undefined8 *)(puVar17 + -8) = 0x101043;
                  func_0x(uVar13,4);
                }
                uVar16 = (ulonglong)(ushort)psVar9[0xe];
                iVar8 = iVar8 + 1;
                puVar27 = puStack_50;
                uVar7 = uVar18;
              } while (iVar8 < (int)(uint)(ushort)psVar9[0xe]);
            }
            if ((short)puVar27[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
              pbVar24 = *(byte **)(psVar9 + 4);
              do {
                uVar7 = *(ushort *)(pbVar24 + uVar16 * 2 + (ulonglong)*(uint *)(psVar9 + 10)) &
                        0x7fff;
                if ((int)uVar16 == 1) {
                  uVar18 = *(uint *)(psVar9 + 0xc);
                  uVar19 = uVar18;
LAB_:
                  if ((uVar7 < uVar18) || (*(uint *)(psVar9 + 2) < uVar7)) goto LAB_;
                }
                else {
                  uVar19 = *(uint *)(psVar9 + 0xc);
                  uVar18 = *(ushort *)
                            (pbVar24 + uVar16 * 2 + ((ulonglong)*(uint *)(psVar9 + 10) - 2)) &
                           0x7fff;
                  if (uVar19 <= uVar18) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar17 + -8) = 0x1010c2;
                  func_0x(pbVar24,7);
                  uVar19 = *(uint *)(psVar9 + 0xc);
                }
                if ((uVar18 < uVar19) || (*(uint *)(psVar9 + 2) < uVar18)) goto LAB_;
                pbVar24 = *(byte **)(psVar9 + 4);
                if (*(ushort *)(pbVar24 + uVar18) == 5) {
                  *puVar1 = *puVar1 | 2;
                  psVar9[0xe] = psVar9[0xe] + -1;
                  uVar16 = *(ulonglong *)(psVar9 + 4);
                  uVar20 = (ulonglong)(uVar18 & 0xffff);
                  psVar9[0x15] = (short)uVar18;
                  uVar25 = psVar9[0x16] & 0xc7ffU;
                  if ((*(ushort *)(uVar20 + 2 + uVar16) >> 0xe & 1) != 0) {
                    uVar25 = *(ushort *)(uVar20 + 2 + uVar16) & 0x3800 | psVar9[0x16] & 0xc7ffU;
                  }
                  psVar9[0x16] = uVar25;
                  uVar15 = (ulonglong)(ushort)psVar9[0x15];
                  uVar6 = (uVar25 ^ *(ushort *)(uVar20 + 2 + uVar16)) & 0x7ff ^ uVar25;
                  psVar9[0x16] = uVar6;
                  uVar20 = (ulonglong)((uVar6 & 0x7ff) * 2) + 4 + uVar16 + (uVar25 >> 0xb & 7) * 2 +
                           uVar15;
                  if (uVar20 < uVar15 + uVar16) {
                    *(undefined8 *)(puVar17 + -8) = 0x1011d9;
                    func_0x(uVar15 + uVar16,0x19);
                    uVar6 = psVar9[0x16];
                    uVar15 = (ulonglong)(ushort)psVar9[0x15];
                    uVar16 = (ulonglong)*(uint *)(psVar9 + 4);
                  }
                  if (uVar7 - uVar18 <
                      (((uVar6 & 0x7ff) * 2 - (int)uVar15) - (int)uVar16) + (int)uVar20) {
                    lVar14 = *(longlong *)(psVar9 + 4);
                    *(undefined8 *)(puVar17 + -8) = 0x101211;
                    func_0x(uVar15 + lVar14,0x19);
                    uVar6 = psVar9[0x16];
                  }
                  if ((uVar6 & 0x3800) != 0) {
                    puVar26 = (ushort *)
                              (*(longlong *)(psVar9 + 4) + (ulonglong)(ushort)psVar9[0x15] + 4);
                    iVar8 = 0;
                    if ((uVar6 & 0x3800) != 0) {
                      do {
                        if ((uVar6 & 0x7ff) < (*puVar26 & 0x7ff)) {
                          uVar25 = psVar9[0x15];
                          lVar14 = *(longlong *)(psVar9 + 4);
                          *(undefined8 *)(puVar17 + -8) = 0x101267;
                          func_0x((ulonglong)uVar25 + lVar14,0x1a);
                          uVar6 = psVar9[0x16];
                        }
                        iVar8 = iVar8 + 1;
                        puVar26 = puVar26 + 1;
                      } while (iVar8 < (int)(uVar6 >> 0xb & 7));
                    }
                  }
                  goto LAB_;
                }
                if (*(ushort *)(pbVar24 + uVar18) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar25 = psVar9[0xe] - 1;
                psVar9[0xe] = uVar25;
                if (uVar25 == 0) goto LAB_;
                uVar16 = (ulonglong)uVar25;
              } while ((short)puVar27[(ulonglong)(uVar25 - 1) + 1] < 0);
              uVar16 = (ulonglong)*(uint *)(psVar9 + 2);
            }
            else {
LAB_:
              pbVar24 = *(byte **)(psVar9 + 4);
              uVar16 = (ulonglong)*(uint *)(psVar9 + 2);
            }
          }
          if ((*pbVar24 & 0x40) == 0) {
            *(undefined4 *)(psVar9 + 0x13) = 0;
          }
          else {
            *(int *)(psVar9 + 0x13) = (int)uVar16;
            *(int *)(psVar9 + 2) = (int)uVar16 + 0xe;
            *(undefined8 *)(puVar17 + -8) = 0x1012ae;
            uVar13 = func_0x(puVar1);
            *(undefined8 *)(puVar17 + -8) = 0x1012ba;
            func_0x(uVar13,auStack_48);
            *(undefined8 *)(puVar17 + -8) = 0x1012c3;
            iVar8 = func_0x(auStack_48);
            *(int *)(psVar9 + 2) = *(int *)(psVar9 + 2) + iVar8;
            uVar16 = (ulonglong)*(uint *)(psVar9 + 2);
          }
          iVar8 = (int)uVar16;
          if ((*(ulonglong *)(psVar9 + 0xf) != 0) &&
             (*(ulonglong *)(psVar9 + 0xf) < uVar16 + *(longlong *)(psVar9 + 4))) {
            *(undefined8 *)(puVar17 + -8) = 0x1012f8;
            cVar5 = func_0x(0x110e8a0);
            if (cVar5 != '\0') {
              *(undefined8 *)(puVar17 + -8) = 0x101301;
              lVar14 = func_0x();
              if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                *(undefined8 *)(puVar17 + -8) = 0x10131b;
                cVar5 = func_0x(0x110e8a0);
                if (cVar5 == '\0') {
                  *(undefined8 *)(puVar17 + -8) = 0x101337;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar17 + 0x20) = 0;
                  *(undefined8 *)(puVar17 + -8) = 0x10135d;
                  (*_DAT_)(1,0x9fe2ac,0xb1e398,0x886);
                }
              }
            }
            uVar13 = *(undefined8 *)(psVar9 + 4);
            *(undefined8 *)(puVar17 + -8) = 0x10136b;
            func_0x(uVar13,0x12);
            iVar8 = *(int *)(psVar9 + 2);
          }
          if (0x3f3b < iVar8 - 1U) {
            *(undefined8 *)(puVar17 + -8) = 0x101384;
            cVar5 = func_0x(0x110e8a0);
            if (cVar5 != '\0') {
              *(undefined8 *)(puVar17 + -8) = 0x10138d;
              lVar14 = func_0x();
              if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                *(undefined8 *)(puVar17 + -8) = 0x1013a7;
                cVar5 = func_0x(0x110e8a0);
                if (cVar5 == '\0') {
                  *(undefined8 *)(puVar17 + -8) = 0x1013c3;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar17 + 0x20) = 0;
                  *(undefined8 *)(puVar17 + -8) = 0x1013e9;
                  (*_DAT_)(1,0x9fe2ac,0xb1e398,0x88b);
                }
              }
            }
            uVar13 = *(undefined8 *)(psVar9 + 4);
            *(undefined8 *)(puVar17 + -8) = 0x1013f7;
            func_0x(uVar13,5);
          }
        }
LAB_:
        *(undefined8 *)(puVar17 + -8) = 0x1013ff;
        iVar8 = func_0x();
        if (iVar8 == 0) {
          *(undefined8 *)(puVar17 + -8) = 0x101541;
          iVar8 = func_0x(puVar1);
          if (iVar8 == 0) {
            *(undefined8 *)(puVar17 + 0x20) = 0;
            *(undefined8 *)(puVar17 + -8) = 0x101569;
            (*_DAT_)(1,0xbb9fc8,0xbab058,0xd7a);
          }
        }
        else {
          uVar25 = psVar9[0x16];
          lVar12 = 0;
          if (uVar23 < (uVar25 & 0x7ff)) {
            uVar16 = (ulonglong)(ushort)psVar9[0x15];
            lVar3 = *(longlong *)(psVar9 + 4);
            uVar6 = 0;
            lVar14 = lVar3 + uVar16;
            if ((uVar25 & 0x3800) == 0) {
              uVar22 = *(ushort *)(lVar14 + 2);
LAB_:
              uVar6 = uVar22 >> 0xb & 7;
            }
            else if ((uVar25 >> 0xb & 7) != 0) {
              do {
                if (((lVar12 == 0) || ((*(ushort *)(lVar14 + 2 + lVar12 * 2) & 0x7ff) <= uVar23)) &&
                   (uVar22 = *(ushort *)(lVar14 + 4 + lVar12 * 2),
                   (int)uVar23 <= (int)((uVar22 & 0x7ff) - 1))) goto LAB_;
                lVar12 = lVar12 + 1;
              } while (lVar12 < (longlong)(ulonglong)(uVar25 >> 0xb & 7));
            }
            uVar18 = uVar25 >> 0xb & 7;
            uVar20 = (ulonglong)(uVar18 * 2);
            uVar7 = (uVar25 & 0x7ff) * 2;
            iStack_80 = (uint)*(ushort *)(uVar20 + (lStack_78 + 2) * 2 + lVar3 + uVar16) +
                        (uint)uVar6 * 0x10000;
            lVar12 = uVar7 + uVar20 + lVar3 + uVar16;
            if (lStack_78 == 0) {
              uVar7 = (uVar7 + uVar18) * 2 + 4;
            }
            else {
              uVar7 = *(ushort *)(lVar12 + 2 + lStack_78 * 2) & 0x7fff;
            }
            uStack_a8 = (*(ushort *)(lVar12 + 4 + lStack_78 * 2) & 0x7fff) - uVar7;
            uStack_90 = (uint)(*(ushort *)(lVar12 + 4 + lStack_78 * 2) >> 0xf);
            lVar12 = (ulonglong)uVar7 + lVar14;
          }
          else {
            *(undefined8 *)(puVar17 + 0x20) = 0;
            *(undefined8 *)(puVar17 + -8) = 0x101537;
            (*_DAT_)(1,0xbb9f98,0xbb9f60,0x41a);
          }
        }
        iVar8 = iStack_80;
        uVar13 = **(undefined8 **)(*(longlong *)(lStack_70 + 8) + 0x160);
        *(undefined8 *)(puVar17 + -8) = 0x101583;
        puVar10 = (uint *)func_0x(uVar13,iVar8);
        uVar25 = uStack_a4;
        uVar16 = (ulonglong)uStack_a4;
        uStack_a0 = *puVar10;
        uStack_9c = puVar10[1];
        puStack_98 = *(uint **)(puVar10 + 2);
        if (uStack_90 == 0) {
          if (uStack_a4 == 0) {
            uVar6 = ((~*param_5 & 1) + *param_5 * 3 + 1) * 2;
          }
          else {
            uVar6 = param_5[uVar16] & 0x7fff;
          }
          param_5[uVar16 + 1] = uVar6 & 0x7fff;
          *(uint *)(lStack_68 + uVar16 * 4) = uStack_a0;
          if ((uStack_8c & 0xffff) < (uint)uVar6) {
            *(undefined8 *)(puVar17 + 0x20) = 0;
            *(undefined8 *)(puVar17 + -8) = 0x1016c7;
            (*_DAT_)(1,0xbdbc28,0xb85f98,0x5c5);
          }
        }
        else {
          if (uStack_a4 == 0) {
            uVar6 = ((~*param_5 & 1) + *param_5 * 3 + 1) * 2;
          }
          else {
            uVar6 = param_5[uVar16] & 0x7fff;
          }
          param_5[uVar16 + 1] = (short)uStack_a8 + uVar6 & 0x7fff;
          *(uint *)(lStack_68 + uVar16 * 4) = uStack_a0;
          if ((uStack_8c & 0xffff) < (uint)uVar6 + (uStack_a8 & 0xffff)) {
            *(undefined8 *)(puVar17 + 0x20) = 0;
            *(undefined8 *)(puVar17 + -8) = 0x10162a;
            (*_DAT_)(1,0xbdbc28,0xb85f98,0x5c5);
          }
          uVar7 = uStack_a8;
          param_5[uVar16 + 1] = param_5[uVar16 + 1] | 0x8000;
          *(undefined8 *)(puVar17 + -8) = 0x101647;
          func_0x((ulonglong)uVar6 + (longlong)param_5,uVar7,lVar12,uVar7);
        }
        uStack_a4 = uVar25 + 1;
        lStack_78 = lStack_78 + 1;
        uVar23 = uVar23 + 1;
      } while (lStack_78 < lStack_60);
    }
  }
  if (*(longlong **)(lStack_40 + 0x10) != (longlong *)0x0) {
    pcVar2 = *(code **)(**(longlong **)(lStack_40 + 0x10) + 8);
    *(undefined8 *)(puVar17 + -8) = 0x101700;
    (*pcVar2)();
  }
  uVar16 = uStack_38 ^ (ulonglong)&uStack_a8;
  *(undefined8 *)(puVar17 + -8) = 0x10170c;
  func_0x(uVar16);
  return;
}

