
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong *param_2)

{
  byte bVar1;
  ushort uVar2;
  longlong lVar3;
  byte *pbVar4;
  longlong lVar5;
  code *UNRECOVERED_JUMPTABLE;
  undefined8 unaff_RBX;
  byte *apbStackX_8 [2];
  undefined8 uStackX_1e;
  undefined auStack_1fe8 [8096];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar5 = func_0x();
  lVar5 = -lVar5;
  *(undefined8 *)(&stack0x00002110 + lVar5) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar5);
  lVar3 = *param_2;
  *(undefined4 *)((longlong)&uStackX_1e + lVar5 + -0x1a) = 0;
  *(undefined8 *)((longlong)&uStackX_1e + lVar5) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar5) = 0;
  *(undefined8 *)((longlong)apbStackX_8 + lVar5 + 8) = 0;
  *(undefined4 *)(&stack0x00000044 + lVar5) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar5) = 0x10008c;
  func_0x(auStack_1fe8,0,0x1f9e);
  (&stack0xfffffffffffffff8)[lVar5] = 0;
  uVar2 = *(ushort *)(lVar3 + 0x18);
  if (0x1f7c < uVar2) {
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar5) = 0x1f7c;
    *(uint *)(&stack0xffffffffffffffe8 + lVar5) = (uint)uVar2;
    *(undefined8 *)((longlong)&uStack_40 + lVar5) = 0x1000c3;
    (*_DAT_)(5,0xb,0x10,0);
  }
  pbVar4 = *(byte **)(lVar3 + 8);
  bVar1 = *pbVar4;
  *(byte **)((longlong)apbStackX_8 + lVar5) = pbVar4;
  if ((bVar1 & 1) != 0) {
    *(undefined2 *)((longlong)&uStackX_1e + lVar5 + -0x1e) = 1;
    UNRECOVERED_JUMPTABLE =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar4 & 0x1c) + 0x100ed8) * 4 +
                           0x100ec8) - 0xf650a0);
                    /* WARNING: Could not emulate address calculation at 0x0010010f */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
    return;
  }
  *(undefined2 *)((longlong)&uStackX_1e + lVar5 + -0x1e) = 0;
  *(undefined4 *)(&stack0x00000026 + lVar5) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100282 */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar4 & 0xe) * 4 + 0x100ef8) - 0xf650a0))
            ((longlong)(int)(*pbVar4 & 0xe),0xffffffffff09af60,pbVar4);
  return;
}

