
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint param_2,undefined4 param_3,undefined8 param_4)

{
  byte *pbVar1;
  undefined4 uVar2;
  undefined auVar3 [16];
  longlong lVar4;
  char cVar5;
  longlong lVar6;
  code *UNRECOVERED_JUMPTABLE_00;
  undefined *puVar7;
  ulonglong uVar8;
  undefined auStack_328 [48];
  longlong lStack_2f8;
  undefined4 uStack_2f0;
  uint uStack_2e8;
  undefined4 uStack_2d8;
  undefined2 uStack_2d4;
  ushort *puStack_2d0;
  undefined4 uStack_2c8;
  undefined8 uStack_2a8;
  undefined2 uStack_2a0;
  undefined auStack_298 [8];
  undefined8 uStack_290;
  undefined auStack_288 [8];
  undefined auStack_280 [280];
  undefined auStack_168 [8];
  undefined auStack_160 [8];
  undefined auStack_158 [8];
  undefined8 uStack_150;
  undefined2 uStack_148;
  undefined4 uStack_144;
  byte *pbStack_140;
  undefined8 uStack_138;
  undefined8 uStack_12a;
  undefined2 uStack_122;
  undefined2 uStack_120;
  undefined6 uStack_11e;
  uint uStack_114;
  undefined auStack_110 [16];
  undefined auStack_100 [8];
  undefined8 uStack_f8;
  undefined8 uStack_f0;
  undefined6 uStack_e8;
  undefined2 uStack_e2;
  undefined6 uStack_e0;
  undefined2 uStack_da;
  undefined2 uStack_d8;
  undefined6 uStack_d6;
  undefined8 uStack_d0;
  short *psStack_c8;
  short *psStack_c0;
  short sStack_b8;
  undefined6 uStack_b6;
  undefined auStack_b0 [10];
  undefined auStack_a6 [6];
  undefined8 uStack_a0;
  undefined8 uStack_98;
  undefined8 uStack_90;
  undefined8 uStack_88;
  undefined8 uStack_80;
  undefined8 uStack_78;
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  ulonglong uStack_48;
  
  uStack_150 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_328;
  uStack_148 = 0xffff;
  pbStack_140 = (byte *)0x0;
  uStack_144 = 0;
  uStack_12a = 0;
  uStack_120 = 0;
  uStack_11e = 0;
  uStack_138 = 0;
  uStack_98 = 0x156e788;
  uStack_90 = 0x156e708;
  uStack_88 = 0x156e718;
  uStack_80 = 0x156e7c4;
  uStack_78 = 0x156e7d0;
  uStack_70 = 0x156e798;
  uStack_68 = 0x156e7b0;
  uStack_60 = 0x12fb690;
  uStack_58 = 0x1300654;
  cVar5 = *(char *)(param_1 + 1);
  lStack_2f8 = param_1;
  uStack_2e8 = param_2;
  uStack_2c8 = param_3;
  uStack_290 = param_4;
  if (1 < (byte)(cVar5 - 3U)) {
    (*_DAT_)(auStack_298,0x1e61960);
    lVar6 = (*_DAT_)(auStack_298);
    (*_DAT_)(auStack_158,lVar6);
    func_0x(lVar6 + 0x10,0x156e808);
    (*_DAT_)(auStack_158);
    (*_DAT_)(auStack_280,lVar6);
    (*_DAT_)(lVar6 + 0x10,cVar5);
    (*_DAT_)(auStack_280);
    (*_DAT_)(&puStack_2d0,lVar6);
    func_0x(lVar6);
    (*_DAT_)(&puStack_2d0);
    puVar7 = auStack_298;
LAB_:
    (*_DAT_)(puVar7);
    func_0x(uStack_48 ^ (ulonglong)auStack_328);
    return;
  }
  if ((*(ushort *)(param_1 + 0x16) <= param_2) ||
     (puStack_2d0 = (ushort *)(param_1 + (0xfff - (longlong)(int)param_2) * 2), *puStack_2d0 == 0))
  {
    (*_DAT_)(auStack_288,0x1e61960);
    lVar6 = (*_DAT_)(auStack_288);
    (*_DAT_)(auStack_168,lVar6);
    func_0x(lVar6 + 0x10,0x156e820);
    (*_DAT_)(auStack_168);
    (*_DAT_)(auStack_160,lVar6);
    func_0x(lVar6);
    (*_DAT_)(auStack_160);
    puVar7 = auStack_288;
    goto LAB_;
  }
  uStack_2f0 = 9;
  uStack_114 = param_2;
  if (-1 < *(char *)(param_1 + 2)) goto LAB_;
  pbVar1 = (byte *)(param_1 + 0x60);
  uStack_e8 = 0;
  uStack_da = 0;
  uStack_d0 = 0;
  psStack_c0 = (short *)0x0;
  sStack_b8 = 0;
  uStack_b6 = 0;
  auStack_110._8_8_ = 0;
  stack0xffffffffffffff02 = SUB1614(ZEXT816(0),2);
  auStack_100._0_2_ = 0xffff;
  uStack_f8 = 0;
  uStack_e2 = 0;
  uStack_e0 = 0;
  uStack_d8 = 0;
  uStack_d6 = 0;
  uStack_f0 = 0;
  psStack_c8 = (short *)0x0;
  _auStack_b0 = ZEXT812(0);
  auStack_a6._2_4_ = 0;
  uStack_a0 = 0;
  lVar6 = param_1;
  lVar4 = 0;
  if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
    auStack_110._8_8_ = lVar4;
    uStack_2a8 = *(undefined8 *)(lVar6 + 0x28);
    uStack_2a0 = *(undefined2 *)(lVar6 + 0x30);
  }
  else {
    if (cVar5 == '\v') {
      if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
        if (cVar5 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar5 != '\b') goto LAB_;
LAB_:
      lVar4 = auStack_110._8_8_;
      if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
    }
    uStack_2d8 = *(undefined4 *)(param_1 + 0x20);
    uStack_2d4 = *(undefined2 *)(param_1 + 0x24);
    auStack_110 = ZEXT816(0);
    cVar5 = func_0x(&uStack_2d8);
    lVar4 = auStack_110._8_8_;
    if (cVar5 == '\0') goto LAB_;
    func_0x(lVar6,&uStack_2a8);
  }
  auStack_110._0_8_ = pbVar1;
  auStack_b0._8_2_ = uStack_2a0;
  auStack_b0._0_8_ = uStack_2a8;
  auStack_a6._2_4_ = *(undefined4 *)(lStack_2f8 + 0x20);
  lVar6 = (ulonglong)*pbVar1 * 6;
  uVar2 = *(undefined4 *)(lVar6 + 0x1350f40);
  uVar8 = (ulonglong)*(short *)(lVar6 + 0x1350f44);
  auStack_100._0_2_ = 0xffff;
  auStack_100 = (undefined  [8])((ulonglong)auStack_100 & 0xffffffff);
  uStack_f8 = 0;
  uStack_e2 = 0;
  uStack_e0 = 0;
  uStack_d8 = 0;
  uStack_d6 = 0;
  uStack_f0 = 0;
  psStack_c8 = (short *)0x0;
  psStack_c0 = (short *)0x0;
  sStack_b8 = 0;
  uStack_2d8 = uVar2;
  if ((*pbVar1 & 2) != 0) {
    pbVar1 = pbVar1 + uVar8;
    uStack_f8 = pbVar1;
    if ((*pbVar1 & 1) == 0) {
      auVar3._14_2_ = 0;
      auVar3._0_14_ = stack0xffffffffffffff02;
      _auStack_100 = auVar3 << 0x10;
      uStack_da = 0;
      uStack_d8 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001005a0 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x1021a8) - 0x1247ed0))()
      ;
      return;
    }
    auStack_100._0_2_ = 1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x102188) * 4 +
                           0x102178) - 0x1247ed0);
                    /* WARNING: Could not emulate address calculation at 0x001003f0 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((*pbVar1 & 4) != 0) {
    uStack_2d8._2_2_ = (short)((uint)uVar2 >> 0x10);
    if (uStack_2d8._2_2_ != 0) {
      uVar8 = (ulonglong)*(ushort *)(param_1 + 0x61 + (longlong)uStack_2d8._2_2_ * 2);
    }
    psStack_c8 = (short *)(pbVar1 + uVar8);
    psStack_c0 = psStack_c8 + 1;
    sStack_b8 = (*psStack_c8 + 1) * 2;
  }
  if (auStack_110._8_8_ != 0) {
    func_0x(auStack_110._8_8_,auStack_110);
  }
LAB_:
  pbStack_140 = (byte *)((ulonglong)*puStack_2d0 + lStack_2f8);
  if ((*pbStack_140 & 1) == 0) {
    uStack_148 = 0;
    uStack_144 = 0;
    uStack_122 = 0;
    uStack_120 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100895 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_140 & 0xe) * 4 + 0x102214) - 0x1247ed0)
    )(0x12d2660);
    return;
  }
  uStack_148 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_140 & 0x1c) + 0x1021f4) * 4
                         + 0x1021e4) - 0x1247ed0);
                    /* WARNING: Could not emulate address calculation at 0x001006d1 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

