
/* WARNING: Removing unreachable block (ram,0x00100fc4) */
/* WARNING: Removing unreachable block (ram,0x00100fd3) */
/* WARNING: Removing unreachable block (ram,0x00100fe3) */
/* WARNING: Removing unreachable block (ram,0x00100fed) */
/* WARNING: Removing unreachable block (ram,0x00100ff6) */
/* WARNING: Removing unreachable block (ram,0x00101020) */
/* WARNING: Removing unreachable block (ram,0x00101006) */
/* WARNING: Removing unreachable block (ram,0x00101044) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,longlong param_3)

{
  undefined4 uVar1;
  byte *pbVar2;
  code *pcVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  ushort *puVar6;
  char cVar7;
  int iVar8;
  longlong lVar9;
  undefined8 uVar10;
  longlong *plVar11;
  longlong lVar12;
  ulonglong *puVar13;
  ushort uVar14;
  ulonglong uVar15;
  short sVar16;
  ushort uVar17;
  uint uVar18;
  uint uVar19;
  int iVar20;
  ulonglong uVar21;
  uint uVar22;
  longlong lVar23;
  uint uVar24;
  ulonglong uVar25;
  ushort uVar26;
  ushort *puVar27;
  byte *pbVar28;
  undefined8 unaff_R15;
  undefined8 uStackX_8;
  uint uStackX_10;
  ushort uStackX_14;
  byte *pbStackX_16;
  undefined auStackX_1e [4];
  ushort uStackX_22;
  uint uStackX_24;
  ushort uStack_1664;
  undefined auStack_1648 [8];
  longlong *plStack_1640;
  undefined2 auStack_1638 [2];
  undefined4 uStack_1634;
  undefined8 uStack_1630;
  undefined8 uStack_1628;
  undefined8 uStack_161a;
  undefined8 uStack_1610;
  undefined auStack_15f8 [2];
  undefined2 uStack_15f6;
  undefined2 uStack_15ea;
  undefined4 uStack_15e8;
  undefined2 uStack_15e4;
  undefined2 uStack_15e2;
  undefined4 uStack_15e0;
  longlong lStack_15dc;
  ushort uStack_15d4;
  undefined2 auStack_15d2 [69];
  undefined auStack_1548 [16];
  int iStack_1538;
  uint uStack_1534;
  uint uStack_1530;
  undefined *puStack_1528;
  byte *pbStack_1520;
  byte *pbStack_1518;
  undefined auStack_1508 [2656];
  undefined auStack_aa8 [2656];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001d;
  lVar9 = func_0x();
  lVar9 = -lVar9;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar9);
  plVar11 = (longlong *)param_2[1];
  uVar21 = 0;
  uStack_15e8 = 0;
  uStack_15e4 = 0;
  *(undefined2 *)(&stack0xfffffffffffffff8 + lVar9) = 0xffff;
  *(undefined2 *)(&stack0x00000030 + lVar9) = 0xffff;
  auStack_1638[0] = 0xffff;
  uStack_15d4 = 0;
  *(undefined8 *)(auStackX_1e + lVar9 + -0x1e) = 0;
  *(undefined4 *)(&stack0xfffffffffffffffc + lVar9) = 0;
  *(undefined8 *)((longlong)&uStackX_14 + lVar9 + 2) = 0;
  *(undefined8 *)(auStackX_1e + lVar9 + 2) = 0;
  *(undefined8 *)((longlong)&uStackX_8 + lVar9) = 0;
  *(undefined8 *)(&stack0x00000038 + lVar9) = 0;
  *(undefined4 *)(&stack0x00000034 + lVar9) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar9) = 0;
  uStack_1630 = 0;
  uStack_1634 = 0;
  uStack_161a = 0;
  uStack_1610 = 0;
  uStack_1628 = 0;
  uVar19 = *(uint *)(**(longlong **)(*(longlong *)(*param_2 + 8) + 0x160) + 0x1c);
  lVar12 = *(longlong *)(param_1 + 0x58);
  plStack_1640 = plVar11;
  if ((lVar12 == 0) || (*(uint *)(lVar12 + 0xc) < uVar19)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1000d0;
    (*_DAT_)(lVar12,0x18);
    *(undefined8 *)(param_1 + 0x58) = 0;
    uVar10 = *(undefined8 *)(param_3 + 8);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1000e3;
    func_0x(uVar10,uVar19,param_1 + 0x58);
    uVar10 = *(undefined8 *)(param_1 + 0x58);
    lVar12 = *param_2;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1000f0;
    func_0x(lVar12,uVar10);
  }
  if (*(int *)(param_1 + 0x68) == 0) {
    uVar10 = *(undefined8 *)(param_3 + 8);
    (&stack0xffffffffffffffe8)[lVar9] = 5;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100117;
    uVar10 = (*_DAT_)(0xa58,uVar10,0x157b520,0x71c8);
    *(undefined8 *)(param_1 + 0x60) = uVar10;
    *(undefined4 *)(param_1 + 0x68) = 0xa58;
  }
  if (*(char *)(param_1 + 0x6c) != '\0') {
    plVar11 = *(longlong **)(param_1 + 0x58);
    if (*(int *)(plVar11 + 2) == *(int *)(*(longlong *)(param_1 + 0x28) + 0x10)) {
      if (((*(int *)(plVar11 + 2) != 2) &&
          (*(int *)(plVar11 + 1) == *(int *)(*(longlong *)(param_1 + 0x28) + 8))) &&
         (*(int *)(plVar11 + 1) != 0)) {
        do {
          lVar23 = *plVar11 + uVar21 * 0x10;
          uVar1 = *(undefined4 *)(lVar23 + 8);
          uVar10 = **(undefined8 **)(*(longlong *)(*param_2 + 8) + 0x160);
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100186;
          uVar10 = func_0x(uVar10,uVar1);
          lVar12 = **(longlong **)(param_1 + 0x28);
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10019b;
          iVar8 = func_0x(lVar23,lVar12 + uVar21 * 0x10,uVar10);
          if (iVar8 != 1) goto LAB_;
          plVar11 = *(longlong **)(param_1 + 0x58);
          uVar19 = (int)uVar21 + 1;
          uVar21 = (ulonglong)uVar19;
        } while (uVar19 < *(uint *)(plVar11 + 1));
      }
      goto LAB_;
    }
  }
LAB_:
  iVar8 = 0;
  lVar12 = *param_2;
  uVar10 = *(undefined8 *)(param_1 + 0x40);
  *(undefined8 *)(&stack0x000016d0 + lVar9) = unaff_R15;
  uStack_15ea = 0;
  lStack_15dc = (ulonglong)*(uint6 *)(lVar12 + 0x14) << 0x10;
  uStack_15e0 = 3;
  if (*(char *)(param_1 + 0x3c) != '\0') {
    uStack_15e0 = 1;
  }
  uStack_15e2 = 0xdc;
  uStack_15f6 = 0x24;
  *(undefined **)(&stack0xfffffffffffffff0 + lVar9) = &stack0xfffffffffffffff8 + lVar9;
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10021f;
  func_0x(lVar12,auStack_1638,uVar10,auStack_1508);
  uStack_1534 = *(uint *)(&stack0xfffffffffffffffc + lVar9);
  if (*(short *)(&stack0xfffffffffffffff8 + lVar9) == 0) {
    pbStack_1520 = *(byte **)(auStackX_1e + lVar9 + -0x1e);
    if (uStack_1534 == 0) {
      uVar19 = *(uint *)((longlong)&uStackX_8 + lVar9);
      uVar21 = (ulonglong)uVar19;
      *(uint *)((longlong)&uStackX_8 + lVar9 + 4) = uVar19;
      *(undefined2 *)(&stack0xfffffffffffffffa + lVar9) = 0;
      if ((*pbStack_1520 & 0x10) != 0) {
        uVar19 = uVar19 + 2 + (*(ushort *)(pbStack_1520 + uVar21) + 7 >> 3);
        uVar21 = (ulonglong)uVar19;
        *(uint *)((longlong)&uStackX_8 + lVar9 + 4) = uVar19;
      }
      if ((*pbStack_1520 & 0x20) == 0) {
        *(int *)(&stack0xfffffffffffffffc + lVar9) = (int)uVar21;
        *(undefined2 *)((longlong)&uStackX_14 + lVar9) = 0;
        *(int *)((longlong)&uStackX_10 + lVar9) = (int)uVar21;
      }
      else {
        puVar27 = (ushort *)(pbStack_1520 + uVar21);
        uVar17 = *puVar27;
        *(ushort *)((longlong)&uStackX_14 + lVar9) = uVar17;
        if (uVar17 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100298;
          cVar7 = func_0x(0x1ef4c80);
          if (cVar7 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1002a1;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1002bb;
              cVar7 = func_0x(0x1ef4c80);
              if (cVar7 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1002d7;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1002fa;
                (*_DAT_)(1,0x17e468c,0x1904778,0x80f);
              }
            }
          }
          uVar10 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100309;
          func_0x(uVar10,3);
          uVar17 = *(ushort *)((longlong)&uStackX_14 + lVar9);
          pbStack_1520 = *(byte **)(auStackX_1e + lVar9 + -0x1e);
        }
        uVar19 = *(int *)((longlong)&uStackX_8 + lVar9 + 4) + 2 + (uint)uVar17 * 2;
        *(uint *)((longlong)&uStackX_10 + lVar9) = uVar19;
        if (0x1f9e < uVar19) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100340;
          cVar7 = func_0x(0x1ef4c80);
          if (cVar7 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100349;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100363;
              cVar7 = func_0x(0x1ef4c80);
              if (cVar7 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10037f;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003a2;
                (*_DAT_)(1,0x17e468c,0x1904778,0x816);
              }
            }
          }
          uVar10 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003b1;
          func_0x(uVar10,4);
          uVar17 = *(ushort *)((longlong)&uStackX_14 + lVar9);
          uVar19 = *(uint *)((longlong)&uStackX_10 + lVar9);
          pbStack_1520 = *(byte **)(auStackX_1e + lVar9 + -0x1e);
        }
        uVar15 = (ulonglong)uVar17;
        uVar24 = puVar27[uVar15] & 0x7fff;
        *(uint *)(&stack0xfffffffffffffffc + lVar9) = uVar24;
        if (uVar24 < uVar19) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003e9;
          cVar7 = func_0x(0x1ef4c80);
          if (cVar7 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003f2;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10040c;
              cVar7 = func_0x(0x1ef4c80);
              if (cVar7 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100428;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10044b;
                (*_DAT_)(1,0x17e468c,0x1904778,0x81d);
              }
            }
          }
          uVar10 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10045a;
          func_0x(uVar10,4);
          uVar15 = (ulonglong)*(ushort *)((longlong)&uStackX_14 + lVar9);
          uVar19 = *(uint *)((longlong)&uStackX_10 + lVar9);
          pbStack_1520 = *(byte **)(auStackX_1e + lVar9 + -0x1e);
          uVar24 = *(uint *)(&stack0xfffffffffffffffc + lVar9);
        }
        uVar21 = (ulonglong)uVar24;
        puVar6 = puVar27;
        if ((short)uVar15 != 0) {
          do {
            uVar24 = puVar6[1] & 0x7fff;
            if ((uVar24 < uVar19) || ((uint)uVar21 < uVar24)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1004a3;
              cVar7 = func_0x(0x1ef4c80);
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1004ac;
                lVar12 = func_0x();
                if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1004c6;
                  cVar7 = func_0x(0x1ef4c80);
                  if (cVar7 == '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1004e2;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100508;
                    (*_DAT_)(1,0x17e468c,0x1904778,0x82a);
                  }
                }
              }
              uVar10 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100517;
              func_0x(uVar10,4);
              uVar15 = (ulonglong)*(ushort *)((longlong)&uStackX_14 + lVar9);
              pbStack_1520 = *(byte **)(auStackX_1e + lVar9 + -0x1e);
              uVar21 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar9);
            }
            iVar8 = iVar8 + 1;
            puVar6 = puVar6 + 1;
            uVar19 = uVar24;
          } while (iVar8 < (int)uVar15);
          uVar19 = *(uint *)((longlong)&uStackX_10 + lVar9);
        }
        while( true ) {
          sVar16 = (short)uVar15;
          if (-1 < (short)puVar27[(ulonglong)((int)uVar15 - 1) + 1]) break;
          uVar24 = *(uint *)((longlong)&uStackX_8 + lVar9 + 4);
          if ((int)uVar15 == 1) {
            uVar15 = 1;
            uVar18 = uVar19;
          }
          else {
            uVar18 = *(ushort *)(pbStack_1520 + uVar15 * 2 + ((ulonglong)uVar24 - 2)) & 0x7fff;
          }
          uVar24 = *(ushort *)(pbStack_1520 + uVar15 * 2 + (ulonglong)uVar24) & 0x7fff;
          if (((uVar18 < uVar19) || (uVar24 < uVar18)) || ((uint)uVar21 < uVar24)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1005ae;
            func_0x(pbStack_1520,7);
            sVar16 = *(short *)((longlong)&uStackX_14 + lVar9);
            uVar19 = *(uint *)((longlong)&uStackX_10 + lVar9);
            pbStack_1520 = *(byte **)(auStackX_1e + lVar9 + -0x1e);
            uVar21 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar9);
          }
          if ((uVar18 < uVar19) || ((uint)uVar21 < uVar18)) goto LAB_;
          if (*(ushort *)(pbStack_1520 + uVar18) == 5) {
            *(ushort *)(&stack0xfffffffffffffffa + lVar9) =
                 *(ushort *)(&stack0xfffffffffffffffa + lVar9) | 2;
            uVar15 = (ulonglong)(uVar18 & 0xffff);
            pbVar2 = pbStack_1520 + uVar15;
            *(short *)((longlong)&uStackX_14 + lVar9) = sVar16 + -1;
            *(short *)(auStackX_1e + lVar9 + 4) = (short)uVar18;
            uVar17 = *(ushort *)(auStackX_1e + lVar9 + 6);
            if ((*(ushort *)(pbVar2 + 2) & 0x4000) == 0) {
              uVar17 = uVar17 & 0xc7ff;
            }
            else {
              uVar17 = uVar17 ^ (*(ushort *)(pbVar2 + 2) ^ uVar17) & 0x3800;
            }
            *(ushort *)(auStackX_1e + lVar9 + 6) = uVar17;
            uVar14 = (uVar17 ^ *(ushort *)(pbVar2 + 2)) & 0x7ff ^ uVar17;
            uVar25 = (ulonglong)uVar14;
            *(ushort *)(auStackX_1e + lVar9 + 6) = uVar14;
            pbVar28 = pbStack_1520 +
                      uVar15 + (uVar25 & 0x7ff) * 2 + (ulonglong)((uVar17 >> 0xb & 7) * 2) + 4;
            if (pbVar28 < pbVar2) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1006eb;
              func_0x(pbVar2,0x19);
              uVar25 = (ulonglong)*(ushort *)(auStackX_1e + lVar9 + 6);
              uVar15 = (ulonglong)*(ushort *)(auStackX_1e + lVar9 + 4);
              pbStack_1520 = *(byte **)(auStackX_1e + lVar9 + -0x1e);
              uVar21 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar9);
            }
            if (uVar24 - uVar18 <
                (((*(uint *)(auStackX_1e + lVar9 + 6) & 0x7ff) * 2 - (int)uVar15) -
                *(int *)(auStackX_1e + lVar9 + -0x1e)) + (int)pbVar28) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10072b;
              func_0x(pbStack_1520 + uVar15,0x19);
              uVar25 = (ulonglong)*(ushort *)(auStackX_1e + lVar9 + 6);
              uVar15 = (ulonglong)*(ushort *)(auStackX_1e + lVar9 + 4);
              pbStack_1520 = *(byte **)(auStackX_1e + lVar9 + -0x1e);
              uVar21 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar9);
            }
            iVar8 = 0;
            if (((uVar25 & 0x3800) != 0) &&
               (puVar27 = (ushort *)(pbStack_1520 + uVar15 + 4), (uVar25 & 0x3800) != 0)) {
              do {
                if (((ushort)uVar25 & 0x7ff) < (*puVar27 & 0x7ff)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100795;
                  func_0x(pbStack_1520 + uVar15,0x1a);
                  uVar25 = (ulonglong)*(ushort *)(auStackX_1e + lVar9 + 6);
                  uVar15 = (ulonglong)*(ushort *)(auStackX_1e + lVar9 + 4);
                  pbStack_1520 = *(byte **)(auStackX_1e + lVar9 + -0x1e);
                }
                iVar8 = iVar8 + 1;
                puVar27 = puVar27 + 1;
              } while (iVar8 < (int)(*(uint *)(auStackX_1e + lVar9 + 6) >> 0xb & 7));
              uVar21 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar9);
            }
            break;
          }
          if (*(ushort *)(pbStack_1520 + uVar18) < 0x400) break;
          *(ushort *)(&stack0xfffffffffffffffa + lVar9) =
               *(ushort *)(&stack0xfffffffffffffffa + lVar9) | 1;
          uVar17 = sVar16 - 1;
          uVar15 = (ulonglong)uVar17;
          *(ushort *)((longlong)&uStackX_14 + lVar9) = uVar17;
          if (uVar17 == 0) break;
        }
      }
      if ((*pbStack_1520 & 0x40) == 0) {
        *(undefined4 *)(auStackX_1e + lVar9) = 0;
      }
      else {
        *(int *)(auStackX_1e + lVar9) = (int)uVar21;
        *(int *)(&stack0xfffffffffffffffc + lVar9) = (int)uVar21 + 0xe;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100621;
        uVar10 = func_0x(&stack0xfffffffffffffffa + lVar9);
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10062d;
        func_0x(uVar10,auStack_1648);
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100636;
        iVar8 = func_0x(auStack_1648);
        pbStack_1520 = *(byte **)(auStackX_1e + lVar9 + -0x1e);
        uVar21 = (ulonglong)(uint)(*(int *)(&stack0xfffffffffffffffc + lVar9) + iVar8);
        *(int *)(&stack0xfffffffffffffffc + lVar9) =
             *(int *)(&stack0xfffffffffffffffc + lVar9) + iVar8;
      }
      pbVar2 = *(byte **)((longlong)&uStackX_14 + lVar9 + 2);
      if ((pbVar2 != (byte *)0x0) && (pbVar2 < pbStack_1520 + uVar21)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100805;
        cVar7 = func_0x(0x1ef4c80);
        if (cVar7 != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10080e;
          lVar12 = func_0x();
          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100828;
            cVar7 = func_0x(0x1ef4c80);
            if (cVar7 == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100844;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10086a;
              (*_DAT_)(1,0x17e468c,0x1904778,0x886);
            }
          }
        }
        uVar10 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100879;
        func_0x(uVar10,0x12);
        pbStack_1520 = *(byte **)(auStackX_1e + lVar9 + -0x1e);
        uVar21 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar9);
      }
      if ((int)uVar21 - 1U < 0x3f3c) {
LAB_:
        uStack_1534 = (uint)uVar21;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10089e;
        cVar7 = func_0x(0x1ef4c80);
        if (cVar7 != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1008a7;
          lVar12 = func_0x();
          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1008c1;
            cVar7 = func_0x(0x1ef4c80);
            if (cVar7 == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1008dd;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100923;
              (*_DAT_)(1,0x17e468c,0x1904778,0x88b);
            }
          }
        }
        uVar10 = *(undefined8 *)(auStackX_1e + lVar9 + -0x1e);
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1008f1;
        func_0x(uVar10,5);
        pbStack_1520 = *(byte **)(auStackX_1e + lVar9 + -0x1e);
        uStack_1534 = *(uint *)(&stack0xfffffffffffffffc + lVar9);
      }
    }
    if ((uStack_1534 < 9) && (((*pbStack_1520 & 0xe) == 0 || ((*pbStack_1520 & 0xe) == 0xc)))) {
      uStack_1534 = 9;
    }
  }
  else {
    if (uStack_1534 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100957;
      func_0x(&stack0xfffffffffffffffa + lVar9);
      uStack_1534 = *(uint *)(&stack0xfffffffffffffffc + lVar9);
    }
    pbStack_1520 = *(byte **)(auStackX_1e + lVar9 + -0x1e);
    if ((uStack_1534 < 9) && (((*pbStack_1520 & 0x1c) == 0 || ((*pbStack_1520 & 0x1c) == 0xc)))) {
      uStack_1534 = 9;
    }
  }
  iVar8 = 0;
  uVar19 = 9;
  uVar10 = 2;
  auStack_15d2[uStack_15d4] = (short)uStack_1534;
  uStack_15d4 = uStack_15d4 + 1;
  if (*(char *)(param_1 + 0x3c) == '\0') {
    uVar10 = *(undefined8 *)(param_1 + 0x28);
    lVar12 = *param_2;
    *(undefined **)(&stack0xfffffffffffffff0 + lVar9) = &stack0x00000030 + lVar9;
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1009d2;
    func_0x(lVar12,auStack_1638,uVar10,auStack_aa8);
    uStack_1530 = uVar19;
    if (*(short *)(&stack0x00000030 + lVar9) == 0) {
      uVar19 = *(uint *)(&stack0x00000034 + lVar9);
      pbStack_1518 = *(byte **)(&stack0x00000038 + lVar9);
      if (uVar19 == 0) {
        uVar19 = *(uint *)(&stack0x00000040 + lVar9);
        uVar21 = (ulonglong)uVar19;
        *(uint *)(&stack0x00000044 + lVar9) = uVar19;
        *(undefined2 *)(&stack0x00000032 + lVar9) = 0;
        if ((*pbStack_1518 & 0x10) != 0) {
          uVar19 = uVar19 + 2 + (*(ushort *)(pbStack_1518 + uVar21) + 7 >> 3);
          uVar21 = (ulonglong)uVar19;
          *(uint *)(&stack0x00000044 + lVar9) = uVar19;
        }
        if ((*pbStack_1518 & 0x20) == 0) {
          *(int *)(&stack0x00000034 + lVar9) = (int)uVar21;
        }
        else {
          puVar27 = (ushort *)(pbStack_1518 + uVar21);
          uStack_1664 = *puVar27;
          if (uStack_1664 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100a4a;
            cVar7 = func_0x(0x1ef4c80);
            if (cVar7 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100a53;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100a6d;
                cVar7 = func_0x(0x1ef4c80);
                if (cVar7 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100a89;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100aac;
                  (*_DAT_)(1,0x17e468c,0x1904778,0x80f);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100abb;
            func_0x(*(undefined8 *)(&stack0x00000038 + lVar9),3);
            pbStack_1518 = *(byte **)(&stack0x00000038 + lVar9);
          }
          uVar24 = *(int *)(&stack0x00000044 + lVar9) + 2 + (uint)uStack_1664 * 2;
          if (0x1f9e < uVar24) {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100af0;
            cVar7 = func_0x(0x1ef4c80);
            if (cVar7 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100af9;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100b13;
                cVar7 = func_0x(0x1ef4c80);
                if (cVar7 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100b2f;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100b52;
                  (*_DAT_)(1,0x17e468c,0x1904778,0x816);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100b61;
            func_0x(*(undefined8 *)(&stack0x00000038 + lVar9),4);
            pbStack_1518 = *(byte **)(&stack0x00000038 + lVar9);
          }
          uVar19 = puVar27[uStack_1664] & 0x7fff;
          *(uint *)(&stack0x00000034 + lVar9) = uVar19;
          if (uVar19 < uVar24) {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100b97;
            cVar7 = func_0x(0x1ef4c80);
            if (cVar7 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100ba0;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100bba;
                cVar7 = func_0x(0x1ef4c80);
                if (cVar7 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100bd6;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100bf9;
                  (*_DAT_)(1,0x17e468c,0x1904778,0x81d);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c08;
            func_0x(*(undefined8 *)(&stack0x00000038 + lVar9),4);
            pbStack_1518 = *(byte **)(&stack0x00000038 + lVar9);
            uVar19 = *(uint *)(&stack0x00000034 + lVar9);
          }
          uVar21 = (ulonglong)uVar19;
          iVar20 = 0;
          puVar6 = puVar27;
          uVar19 = uVar24;
          if (uStack_1664 != 0) {
            do {
              uVar18 = puVar6[1] & 0x7fff;
              if ((uVar18 < uVar19) || ((uint)uVar21 < uVar18)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c53;
                cVar7 = func_0x(0x1ef4c80);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c5c;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c76;
                    cVar7 = func_0x(0x1ef4c80);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c92;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100cb8;
                      (*_DAT_)(1,0x17e468c,0x1904778,0x82a);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100cc7;
                func_0x(*(undefined8 *)(&stack0x00000038 + lVar9),4);
                pbStack_1518 = *(byte **)(&stack0x00000038 + lVar9);
                uVar21 = (ulonglong)*(uint *)(&stack0x00000034 + lVar9);
              }
              iVar8 = iVar8 + 1;
              puVar6 = puVar6 + 1;
              uVar19 = uVar18;
            } while (iVar8 < (int)(uint)uStack_1664);
          }
          while( true ) {
            uVar15 = (ulonglong)uStack_1664;
            if (-1 < (short)puVar27[(ulonglong)(uStack_1664 - 1) + 1]) break;
            if (uStack_1664 == 1) {
              uVar15 = 1;
              uVar18 = uVar24;
            }
            else {
              uVar18 = *(ushort *)
                        (pbStack_1518 +
                        uVar15 * 2 + ((ulonglong)*(uint *)(&stack0x00000044 + lVar9) - 2)) & 0x7fff;
            }
            uVar22 = *(ushort *)
                      (pbStack_1518 + uVar15 * 2 + (ulonglong)*(uint *)(&stack0x00000044 + lVar9)) &
                     0x7fff;
            if (((uVar18 < uVar24) || (uVar22 < uVar18)) || ((uint)uVar21 < uVar22)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100d4f;
              func_0x(pbStack_1518,7);
              pbStack_1518 = *(byte **)(&stack0x00000038 + lVar9);
              uVar21 = (ulonglong)*(uint *)(&stack0x00000034 + lVar9);
            }
            uVar19 = (uint)uVar21;
            if ((uVar18 < uVar24) || (uVar19 < uVar18)) goto LAB_;
            if (*(ushort *)(pbStack_1518 + uVar18) == 5) {
              *(ushort *)(&stack0x00000032 + lVar9) = *(ushort *)(&stack0x00000032 + lVar9) | 2;
              uVar15 = (ulonglong)(uVar18 & 0xffff);
              pbVar2 = pbStack_1518 + uVar15;
              uVar17 = (ushort)uVar18;
              if ((*(ushort *)(pbVar2 + 2) & 0x4000) == 0) {
                uVar14 = 0;
              }
              else {
                uVar14 = *(ushort *)(pbVar2 + 2) & 0x3800;
              }
              uVar26 = *(ushort *)(pbVar2 + 2) & 0x7ff ^ uVar14;
              pbVar28 = pbStack_1518 +
                        (ulonglong)((uint)(uVar14 >> 0xb) * 2) + 4 + uVar15 +
                        ((ulonglong)uVar26 & 0x7ff) * 2;
              if (pbVar28 < pbVar2) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100ec8;
                func_0x(pbVar2,0x19);
                pbStack_1518 = *(byte **)(&stack0x00000038 + lVar9);
                uVar21 = (ulonglong)*(uint *)(&stack0x00000034 + lVar9);
                uVar15 = (ulonglong)uVar17;
              }
              if (uVar22 - uVar18 <
                  (((uVar26 & 0x7ff) * 2 - (int)uVar15) - *(int *)(&stack0x00000038 + lVar9)) +
                  (int)pbVar28) {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100f07;
                func_0x(pbStack_1518 + uVar15,0x19);
                pbStack_1518 = *(byte **)(&stack0x00000038 + lVar9);
                uVar21 = (ulonglong)*(uint *)(&stack0x00000034 + lVar9);
                uVar15 = (ulonglong)uVar17;
              }
              if (((uVar26 & 0x3800) != 0) &&
                 (puVar27 = (ushort *)(pbStack_1518 + uVar15 + 4), (uVar26 & 0x3800) != 0)) {
                do {
                  if ((uVar26 & 0x7ff) < (*puVar27 & 0x7ff)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100f72;
                    func_0x(pbStack_1518 + uVar15,0x1a);
                    pbStack_1518 = *(byte **)(&stack0x00000038 + lVar9);
                    uVar15 = (ulonglong)uVar17;
                  }
                  iVar20 = iVar20 + 1;
                  puVar27 = puVar27 + 1;
                } while (iVar20 < (int)(uint)(uVar14 >> 0xb));
                uVar21 = (ulonglong)*(uint *)(&stack0x00000034 + lVar9);
              }
              break;
            }
            if (*(ushort *)(pbStack_1518 + uVar18) < 0x400) break;
            *(ushort *)(&stack0x00000032 + lVar9) = *(ushort *)(&stack0x00000032 + lVar9) | 1;
            uStack_1664 = uStack_1664 - 1;
            if (uStack_1664 == 0) break;
          }
        }
        uVar19 = (uint)uVar21;
        iVar8 = 0;
        if ((*pbStack_1518 & 0x40) != 0) {
          *(uint *)(&stack0x00000034 + lVar9) = uVar19 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100dc6;
          puVar13 = (ulonglong *)func_0x(&stack0x00000032 + lVar9);
          uVar14 = (ushort)(*puVar13 >> 0x30);
          uVar17 = uVar14;
          if ((((uint)(int)(short)uVar14 >> 1 ^ (int)(short)uVar14) & 0x2000) != 0) {
            uVar17 = uVar14 & 0xdfff;
            if ((uVar14 >> 0xe & 1) != 0) {
              uVar17 = uVar14 | 0x2000;
            }
          }
          if (uVar17 == 0xfffc) {
            iVar8 = (int)((*puVar13 >> 0x20 & 0xffff) >> 5);
          }
          pbStack_1518 = *(byte **)(&stack0x00000038 + lVar9);
          uVar19 = *(int *)(&stack0x00000034 + lVar9) + iVar8;
          *(uint *)(&stack0x00000034 + lVar9) = uVar19;
        }
        if (0x3f3b < uVar19 - 1) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101078;
          cVar7 = func_0x(0x1ef4c80);
          if (cVar7 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x101081;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10109b;
              cVar7 = func_0x(0x1ef4c80);
              if (cVar7 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1010b7;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1010dd;
                (*_DAT_)(1,0x17e468c,0x1904778,0x88b);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1010ec;
          func_0x(*(undefined8 *)(&stack0x00000038 + lVar9),5);
          pbStack_1518 = *(byte **)(&stack0x00000038 + lVar9);
          uVar19 = *(uint *)(&stack0x00000034 + lVar9);
        }
      }
LAB_:
      if ((8 < uVar19) || (((*pbStack_1518 & 0xe) != 0 && ((*pbStack_1518 & 0xe) != 0xc)))) {
        uStack_1530 = uVar19;
      }
    }
    else {
      uVar19 = *(uint *)(&stack0x00000034 + lVar9);
      if (uVar19 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10111f;
        func_0x(&stack0x00000032 + lVar9);
        uVar19 = *(uint *)(&stack0x00000034 + lVar9);
      }
      pbStack_1518 = *(byte **)(&stack0x00000038 + lVar9);
      if ((8 < uVar19) || (((*pbStack_1518 & 0x1c) != 0 && ((*pbStack_1518 & 0x1c) != 0xc)))) {
        uStack_1530 = uVar19;
      }
    }
    uVar10 = 3;
    auStack_15d2[uStack_15d4] = (short)uStack_1530;
    uStack_15d4 = uStack_15d4 + 1;
  }
  *(undefined **)(&stack0xffffffffffffffe8 + lVar9) = auStack_1548;
  iStack_1538 = (uint)uStack_15d4 * 2 + 0x26;
  puStack_1528 = auStack_15f8;
  pcVar3 = *(code **)(*plStack_1640 + 0x288);
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1011a8;
  (*pcVar3)(plStack_1640,uVar10,&iStack_1538,&puStack_1528);
  uVar1 = *(undefined4 *)(param_1 + 0x68);
  uVar10 = *(undefined8 *)(param_1 + 0x60);
  uVar4 = *(undefined8 *)(param_1 + 0x28);
  uVar5 = *(undefined8 *)(param_1 + 0x58);
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1011bd;
  func_0x(uVar5,uVar4,uVar10,uVar1);
  *(undefined *)(param_1 + 0x6c) = 1;
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1011d9;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar9));
  return;
}

