
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong **param_2,int *param_3,uint param_4,uint param_5,
                 int param_6,undefined8 param_7,uint param_8,int param_9,longlong param_10)

{
  byte *pbVar1;
  undefined uVar2;
  longlong lVar3;
  code *pcVar4;
  ushort *puVar5;
  int *piVar6;
  byte bVar7;
  char cVar8;
  short sVar9;
  undefined2 uVar10;
  int iVar11;
  uint uVar12;
  int iVar13;
  int iVar14;
  short *psVar15;
  longlong lVar16;
  undefined8 uVar17;
  byte bVar18;
  ushort uVar19;
  undefined4 uVar20;
  undefined4 *puVar21;
  ulonglong uVar22;
  longlong *plVar23;
  ulonglong uVar24;
  uint uVar25;
  uint uVar26;
  undefined *puVar27;
  uint uVar28;
  longlong **pplVar29;
  byte **ppbVar30;
  byte *pbVar31;
  uint uVar32;
  byte bVar33;
  ushort *puVar34;
  longlong lVar35;
  byte *pbVar36;
  undefined4 uVar37;
  undefined4 uVar38;
  undefined4 uVar39;
  undefined4 uVar40;
  undefined8 uStack_440;
  undefined auStack_438 [32];
  undefined4 *puStack_418;
  int iStack_410;
  uint uStack_408;
  uint uStack_400;
  int iStack_3f8;
  undefined8 uStack_3f0;
  undefined4 *puStack_3e8;
  byte abStack_3d8 [4];
  uint uStack_3d4;
  uint uStack_3d0;
  uint uStack_3cc;
  longlong lStack_3c8;
  undefined4 uStack_3c0;
  undefined2 uStack_3bc;
  undefined2 uStack_3ba;
  int *piStack_3b8;
  undefined4 uStack_3b0;
  undefined2 uStack_3ac;
  undefined2 uStack_3aa;
  undefined4 uStack_3a8;
  undefined2 uStack_3a4;
  undefined2 uStack_3a2;
  undefined4 uStack_3a0;
  undefined2 uStack_39c;
  undefined2 uStack_39a;
  undefined4 uStack_398;
  undefined2 uStack_394;
  undefined2 uStack_392;
  uint uStack_390;
  undefined4 uStack_388;
  undefined4 uStack_384;
  undefined4 uStack_380;
  undefined4 uStack_37c;
  byte bStack_378;
  undefined7 uStack_377;
  undefined8 uStack_370;
  undefined2 uStack_368;
  undefined4 uStack_360;
  undefined2 uStack_35c;
  undefined2 uStack_35a;
  undefined4 uStack_358;
  undefined2 uStack_354;
  undefined4 uStack_350;
  undefined2 uStack_34c;
  undefined4 uStack_348;
  undefined2 uStack_344;
  undefined2 uStack_342;
  undefined4 uStack_340;
  undefined2 uStack_33c;
  undefined2 uStack_33a;
  longlong lStack_338;
  undefined4 uStack_330;
  undefined2 uStack_32c;
  undefined2 uStack_32a;
  undefined4 uStack_328;
  undefined2 uStack_324;
  undefined2 uStack_322;
  undefined4 uStack_320;
  undefined2 uStack_31c;
  undefined2 uStack_31a;
  longlong **pplStack_318;
  undefined4 uStack_310;
  undefined2 uStack_30c;
  undefined2 uStack_30a;
  undefined4 uStack_308;
  undefined2 uStack_304;
  undefined2 uStack_302;
  undefined4 uStack_300;
  undefined2 uStack_2fc;
  undefined2 uStack_2fa;
  undefined4 uStack_2f8;
  undefined2 uStack_2f4;
  undefined2 uStack_2f2;
  undefined4 uStack_2f0;
  undefined2 uStack_2ec;
  undefined2 uStack_2ea;
  undefined4 uStack_2e8;
  undefined2 uStack_2e4;
  undefined8 uStack_2e0;
  undefined4 uStack_2d8;
  undefined8 uStack_2d0;
  undefined8 uStack_2c8;
  undefined8 uStack_2c0;
  undefined4 *puStack_2b8;
  undefined4 *puStack_2b0;
  undefined4 *puStack_2a8;
  undefined2 uStack_2a0;
  char cStack_29e;
  longlong lStack_298;
  undefined8 uStack_290;
  undefined4 uStack_288;
  undefined auStack_280 [8];
  longlong *plStack_278;
  undefined auStack_270 [8];
  longlong lStack_268;
  undefined auStack_260 [8];
  undefined auStack_258 [4];
  undefined8 uStack_254;
  undefined4 uStack_238;
  undefined4 uStack_234;
  undefined4 uStack_230;
  undefined4 uStack_22c;
  undefined8 uStack_228;
  undefined auStack_218 [16];
  undefined8 uStack_208;
  undefined auStack_1f8 [16];
  undefined8 uStack_1e8;
  undefined auStack_1d8 [16];
  undefined8 uStack_1c8;
  undefined auStack_1b8 [16];
  ulonglong uStack_1a8;
  undefined4 uStack_198;
  uint uStack_194;
  byte *pbStack_190;
  undefined8 uStack_188;
  undefined4 uStack_180;
  ushort uStack_17c;
  undefined2 uStack_17a;
  undefined6 uStack_178;
  undefined2 uStack_172;
  undefined2 uStack_170;
  ushort uStack_16e;
  ushort uStack_16c;
  undefined2 uStack_16a;
  uint uStack_168;
  int iStack_164;
  undefined auStack_160 [16];
  undefined auStack_150 [8];
  undefined8 uStack_148;
  undefined8 uStack_140;
  undefined6 uStack_138;
  undefined2 uStack_132;
  undefined6 uStack_130;
  undefined2 uStack_12a;
  undefined8 uStack_128;
  undefined auStack_120 [16];
  undefined auStack_110 [16];
  undefined auStack_100 [16];
  undefined8 uStack_f0;
  undefined4 auStack_e8 [32];
  ulonglong uStack_68;
  
  uStack_68 = _DAT_ ^ (ulonglong)abStack_3d8;
  uStack_3d4 = param_5;
  uStack_290 = param_7;
  puStack_2b8 = auStack_e8;
  lStack_3c8 = param_10;
  uStack_2e8 = 0;
  uStack_2e4 = 0;
  uStack_2e0 = 0;
  uStack_2d8 = 0;
  uStack_2d0 = 0;
  uStack_2c8 = 0x78;
  uStack_2a0 = 0;
  cStack_29e = '\0';
  auStack_e8[0] = 0x4000000;
  if ((((*(uint *)((longlong)param_1 + 0x34) & 0x8200) == 0) ||
      ((*(uint *)((longlong)param_1 + 0x34) >> 0xd & 1) != 0)) || (param_9 != 1)) {
    bVar33 = 0;
  }
  else {
    bVar33 = 1;
  }
  uStack_254 = 0;
  if (param_10 == 0) {
    lStack_3c8 = *param_1;
  }
  lVar16 = param_1[0x14];
  uStack_440 = 0x10011e;
  abStack_3d8[0] = bVar33;
  uStack_3cc = param_4;
  piStack_3b8 = param_3;
  pplStack_318 = param_2;
  lStack_298 = lVar16;
  plStack_278 = param_1;
  bVar7 = func_0x(param_1);
  uVar37 = *(undefined4 *)(param_1 + 10);
  uVar38 = *(undefined4 *)((longlong)param_1 + 0x54);
  uVar39 = *(undefined4 *)(param_1 + 0xb);
  uVar40 = *(undefined4 *)((longlong)param_1 + 0x5c);
  bVar18 = 0;
  if (*(int *)(param_1[1] + 0x38) == 3) {
    bVar18 = 4;
  }
  bStack_378 = bVar18 | (bVar7 & 1) * '\x02' | bStack_378 & 0xe0 | bVar33;
  uStack_388 = uVar37;
  uStack_384 = uVar38;
  uStack_380 = uVar39;
  uStack_37c = uVar40;
  if ((bVar33 != 0) && ((*(uint *)((longlong)param_1 + 0x34) & 0x1000) == 0)) {
    puStack_418 = (undefined4 *)0x0;
    uStack_440 = 0x100188;
    (*_DAT_)(1,0x1717f68,0x16e7ad8,0x3d3);
  }
  puStack_2b0 = puStack_2b8;
  *puStack_2b8 = 0x4000000;
  puStack_2a8 = puStack_2b8 + 1;
  uStack_2c0 = 0;
  if ((*(byte *)(param_1 + 0xc) & 2) == 0) {
    if ((*(byte *)((longlong)param_1 + 0x8c) & 1) != 0) {
      plVar23 = param_1 + 0x12;
      goto LAB_;
    }
  }
  else {
    plVar23 = (longlong *)((longlong)param_1 + 0x3c);
LAB_:
    uStack_440 = 0x1001e2;
    func_0x(param_1,plVar23,&uStack_2e8);
  }
  uStack_440 = 0x1001f4;
  func_0x(param_1,**param_2,*param_3);
  uStack_228 = CONCAT71(uStack_377,bStack_378);
  if ((*(longlong *)(lVar16 + 8) == 0) ||
     (lVar35 = *(longlong *)(*(longlong *)(lVar16 + 8) + 8), *(char *)(lVar35 + 0x3f) != '\0')) {
    if (*(int *)(lVar16 + 0x40) == 2) {
      uStack_342 = 0;
      uStack_348 = **(undefined4 **)(lVar16 + 0x30);
      puVar21 = &uStack_348;
      uStack_344 = *(undefined2 *)(*(undefined4 **)(lVar16 + 0x30) + 1);
    }
    else {
      uStack_33a = 0;
      uStack_340 = **(undefined4 **)(lVar16 + 0x28);
      puVar21 = &uStack_340;
      uStack_33c = *(undefined2 *)(*(undefined4 **)(lVar16 + 0x28) + 1);
    }
    uStack_3a8 = *puVar21;
    uStack_3a4 = *(undefined2 *)(puVar21 + 1);
  }
  else {
    uStack_3a8 = *(undefined4 *)(lVar35 + 8);
    uStack_3a4 = *(undefined2 *)(lVar35 + 0xc);
  }
  puStack_3e8 = &uStack_238;
  uStack_3f0 = uStack_290;
  iStack_3f8 = param_6;
  uStack_400 = uStack_3d4;
  iStack_410 = *param_3;
  puStack_418 = &uStack_2e8;
  uStack_3a2 = 0;
  uStack_440 = 0x1002e3;
  uStack_408 = param_4;
  uStack_238 = uVar37;
  uStack_234 = uVar38;
  uStack_230 = uVar39;
  uStack_22c = uVar40;
  iVar11 = func_0x
                     (param_2,*(undefined8 *)(param_1[1] + 0x58),&uStack_3a8,lStack_3c8);
  if (iVar11 == 0) {
    *(uint *)(param_1 + 0xc) = *(uint *)(param_1 + 0xc) & 0xfffffffd;
    *(uint *)((longlong)param_1 + 0x8c) = *(uint *)((longlong)param_1 + 0x8c) & 0xfffffffe;
    puVar27 = auStack_438;
    if (cStack_29e != '\0') {
      *(undefined *)(param_1[1] + 0x188) = 0;
      puVar27 = auStack_438;
    }
    goto LAB_;
  }
  uStack_390 = param_4 + 0xe;
  pbStack_190 = (byte *)0x0;
  uStack_198 = CONCAT22(uStack_198._2_2_,0xffff);
  uStack_194 = 0;
  uStack_17a = 0;
  uStack_178 = 0;
  uStack_170 = 0;
  uStack_16e = 0;
  uStack_16c = 0;
  uStack_16a = 0;
  uStack_188 = (byte **)0x0;
  sVar9 = -1;
  if (uStack_390 < param_4) {
    uStack_390 = 0xffffffff;
    uStack_440 = 0x10036e;
    func_0x(0x80070216,param_4,0xe);
    uVar37 = uStack_388;
    uVar38 = uStack_384;
    uVar39 = uStack_380;
    uVar40 = uStack_37c;
    sVar9 = (short)uStack_198;
  }
  ppbVar30 = (byte **)0x0;
  iStack_164 = *param_3;
  lVar35 = (longlong)iStack_164;
  uVar25 = 0xf;
  lVar16 = **param_2;
  lStack_338 = lVar16;
  if (*(char *)(lVar16 + 2) < '\0') {
    pbVar36 = (byte *)(lVar16 + 0x60);
    if ((sVar9 == 0) || (ppbVar30 = uStack_188, uStack_188 == (byte **)0x0)) {
      ppbVar30 = (byte **)auStack_160;
      uStack_138 = 0;
      stack0xfffffffffffffeb2 = SUB1614(ZEXT816(0),2);
      auStack_150._0_2_ = 0xffff;
      uStack_12a = 0;
      uStack_148 = 0;
      uStack_132 = 0;
      uStack_130 = 0;
      uStack_128 = 0;
      uStack_140 = 0;
      auStack_120 = ZEXT816(0);
      auStack_100._0_12_ = ZEXT812(0);
      auStack_100._12_4_ = 0;
      uStack_f0 = 0;
      auStack_110 = ZEXT816(0);
      auStack_160 = ZEXT816(0);
    }
    if (*(short *)(lVar16 + 0x24) == 0) {
LAB_:
      uStack_370 = *(undefined8 *)(lVar16 + 0x28);
      uStack_368 = *(undefined2 *)(lVar16 + 0x30);
    }
    else {
      cVar8 = *(char *)(lVar16 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(lVar16 + 0x18) != 99) {
LAB_:
          if (cVar8 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar8 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar16 + 0x18) != 99) goto LAB_;
      }
      uStack_358 = *(undefined4 *)(lVar16 + 0x20);
      uStack_354 = *(undefined2 *)(lVar16 + 0x24);
      uStack_440 = 0x1004b9;
      cVar8 = func_0x(&uStack_358);
      if (cVar8 == '\0') goto LAB_;
      uStack_440 = 0x1004c9;
      func_0x(lVar16,&uStack_370);
    }
    *ppbVar30 = pbVar36;
    *(undefined4 *)(ppbVar30 + 0xc) = (undefined4)uStack_370;
    *(undefined2 *)(ppbVar30 + 0xd) = uStack_368;
    *(int *)((longlong)ppbVar30 + 100) = (int)((ulonglong)uStack_370 >> 0x20);
    *(undefined4 *)((longlong)ppbVar30 + 0x6c) = *(undefined4 *)(lVar16 + 0x20);
    *(undefined2 *)(ppbVar30 + 0xe) = *(undefined2 *)(lVar16 + 0x24);
    *(undefined2 *)((longlong)ppbVar30 + 0x72) = 0;
    uStack_288 = *(undefined4 *)((ulonglong)*pbVar36 * 6 + 0x135c6c0);
    uVar22 = (ulonglong)*(short *)((ulonglong)*pbVar36 * 6 + 0x135c6c4);
    *(undefined2 *)(ppbVar30 + 2) = 0xffff;
    ppbVar30[3] = (byte *)0x0;
    uVar32 = 0;
    *(undefined4 *)((longlong)ppbVar30 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar30 + 0x2e) = 0;
    ppbVar30[7] = (byte *)0x0;
    ppbVar30[4] = (byte *)0x0;
    ppbVar30[9] = (byte *)0x0;
    ppbVar30[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar30 + 0xb) = 0;
    if ((**ppbVar30 & 2) != 0) {
      pbVar1 = pbVar36 + uVar22;
      if ((pbVar36[uVar22] & 1) == 0) {
        *(undefined2 *)(ppbVar30 + 2) = 0;
        ppbVar30[3] = pbVar1;
        *(undefined4 *)((longlong)ppbVar30 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar30 + 0x36) = 0;
        switch(*pbVar1 & 0xe) {
        default:
          uVar32 = (uint)*(ushort *)(pbVar1 + 2);
          if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
            uStack_440 = 0x100761;
            func_0x(pbVar1,6);
          }
          break;
        case 4:
          uVar32 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar32 = 1;
        }
        *(uint *)(ppbVar30 + 4) = uVar32;
        *(undefined8 *)((longlong)ppbVar30 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar30 + 2) = 1;
        ppbVar30[3] = pbVar1;
        bVar33 = *pbVar1;
        switch(bVar33 & 0x1c) {
        default:
          if ((char)pbVar1[1] < '\0') {
            uVar19 = *(ushort *)(pbVar1 + 1);
            sVar9 = 3;
            *(ushort *)((longlong)ppbVar30 + 0x12) = uVar19;
            uVar19 = (uVar19 & 0x7f) << 8 | uVar19 >> 8;
          }
          else {
            sVar9 = 2;
            uVar19 = (ushort)pbVar1[1];
          }
          *(ushort *)((longlong)ppbVar30 + 0x12) = uVar19;
          *(short *)(ppbVar30 + 5) = sVar9;
          uVar19 = *(ushort *)((longlong)ppbVar30 + 0x12);
          *(short *)((longlong)ppbVar30 + 0x2c) = (short)(uVar19 + 1 >> 1) + sVar9;
          if (uVar19 < 0x1f) {
            *(undefined2 *)((longlong)ppbVar30 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar30 + 0x14) = 0;
            *(undefined4 *)(ppbVar30 + 8) = 0;
            ppbVar30[7] = (byte *)0x0;
            ppbVar30[4] = (byte *)0x0;
          }
          else {
            iVar11 = uVar19 - 1;
            *(short *)((longlong)ppbVar30 + 0x2a) =
                 ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                 (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar30 + 0x14) = 0;
            *(undefined4 *)(ppbVar30 + 8) = 0;
            ppbVar30[7] = (byte *)0x0;
            ppbVar30[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar33 & 0x1c) != 4) || (uVar12 = 1, (bVar33 & 2) == 0)) {
            uVar12 = uVar32;
          }
          if (uVar12 == 0) {
            uVar20 = 1;
          }
          else {
            *(undefined4 *)(ppbVar30 + 8) = 0;
            uVar20 = 0xf;
          }
          ppbVar30[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar30 + 0x12) = 0;
          ppbVar30[6] = (byte *)0x0;
          ppbVar30[4] = (byte *)0x0;
          ppbVar30[7] = (byte *)0x0;
          ppbVar30[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar30 + 0x14) = uVar20;
          *(uint *)(ppbVar30 + 8) = (uint)(uVar12 != 0);
          ppbVar30[7] = (byte *)0x0;
          ppbVar30[4] = (byte *)0x0;
          break;
        case 8:
          ppbVar30[7] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar30 + 0x14) = 9;
          ppbVar30[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar30 + 0x12) = 0;
          ppbVar30[6] = (byte *)0x0;
          ppbVar30[4] = (byte *)0x0;
          ppbVar30[3] = pbVar1;
          *(undefined4 *)(ppbVar30 + 8) = 0;
          ppbVar30[7] = (byte *)0x0;
          ppbVar30[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar30 & 4) != 0) {
      if (uStack_288._2_2_ != 0) {
        uVar22 = (ulonglong)*(ushort *)(lVar16 + 0x61 + (longlong)uStack_288._2_2_ * 2);
      }
      psVar15 = (short *)(pbVar36 + uVar22);
      ppbVar30[9] = (byte *)psVar15;
      sVar9 = *psVar15;
      ppbVar30[10] = (byte *)(psVar15 + 1);
      *(short *)(ppbVar30 + 0xb) = (sVar9 + 1) * 2;
    }
    if (ppbVar30[1] != (byte *)0x0) {
      uStack_440 = 0x1007fa;
      func_0x(ppbVar30[1],ppbVar30);
    }
  }
  lVar16 = lStack_338;
  uVar32 = 9;
  pbStack_190 = (byte *)((ulonglong)*(ushort *)(lStack_338 + (0xfff - lVar35) * 2) + lStack_338);
  if ((*pbStack_190 & 1) == 0) {
    uStack_198 = uStack_198 & 0xffff0000;
    uStack_194 = 0;
    uStack_172 = 0;
    uStack_170 = 0;
    uVar25 = (uint)*(ushort *)(lStack_338 + 0xe);
    switch(*pbStack_190 & 0xe) {
    default:
      uVar19 = *(ushort *)(pbStack_190 + 2);
      uVar25 = (uint)uVar19;
      if (0x1f9d < uVar19 - 1) {
        uStack_440 = 0x100a5a;
        func_0x(pbStack_190,6);
      }
      break;
    case 4:
      uVar25 = uVar32;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar25 = 1;
    }
    uStack_188 = (byte **)CONCAT44(uStack_188._4_4_,uVar25);
    ppbVar30 = (byte **)(ulonglong)uVar25;
    uStack_17a = (undefined2)(lVar16 + 0x2000);
    uStack_178 = (undefined6)((ulonglong)(lVar16 + 0x2000) >> 0x10);
    uVar25 = uStack_194;
  }
  else {
    bVar33 = *pbStack_190;
    switch(bVar33 & 0x1c) {
    default:
      bVar33 = pbStack_190[1];
      if ((char)bVar33 < '\0') {
        uVar19 = (*(ushort *)(pbStack_190 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_190 + 1) >> 8;
        uStack_180._0_2_ = 3;
        sVar9 = 3;
        uStack_198 = CONCAT22(uVar19,1);
      }
      else {
        uVar19 = (ushort)bVar33;
        uStack_198 = (uint)CONCAT12(bVar33,1);
        uStack_180._0_2_ = 2;
        sVar9 = 2;
      }
      uStack_17c = ((ushort)(uVar19 + 1) >> 1) + sVar9;
      uVar25 = 0;
      if (uVar19 < 0x1f) {
        uStack_180._2_2_ = 0;
        uStack_194 = 0;
        uStack_168 = 0;
      }
      else {
        iVar11 = uVar19 - 1;
        uStack_168 = 0;
        uStack_194 = 0;
        uStack_180._2_2_ =
             ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
             (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
      }
      break;
    case 4:
      if (((bVar33 & 0x1c) == 4) && ((bVar33 & 2) != 0)) {
        uStack_180._0_2_ = 0;
        uStack_180._2_2_ = 0;
        uStack_17c = 0;
        uStack_17a = 0;
        uStack_198 = 1;
        uStack_178 = 0;
        uStack_172 = 0;
        uStack_194 = 0xf;
        uStack_168 = 1;
      }
      else {
        uVar25 = 1;
        uStack_180._0_2_ = 0;
        uStack_180._2_2_ = 0;
        uStack_17c = 0;
        uStack_17a = 0;
        uStack_194 = 1;
        uStack_198 = 1;
        uStack_178 = 0;
        uStack_172 = 0;
        uStack_168 = 0;
      }
      break;
    case 8:
      uVar25 = 9;
      uStack_180._0_2_ = 0;
      uStack_180._2_2_ = 0;
      uStack_17c = 0;
      uStack_17a = 0;
      uStack_194 = 9;
      uStack_198 = 1;
      uStack_178 = 0;
      uStack_172 = 0;
      uStack_168 = 0;
    }
    lVar35 = lStack_338 + 0x2000;
    uStack_170 = (undefined2)lVar35;
    uStack_16e = (ushort)((ulonglong)lVar35 >> 0x10);
    uStack_16c = (ushort)((ulonglong)lVar35 >> 0x20);
    uStack_16a = (undefined2)((ulonglong)lVar35 >> 0x30);
    uStack_188 = ppbVar30;
  }
  if ((short)uStack_198 == 0) {
    pbVar36 = pbStack_190;
    uStack_180 = CONCAT22(uStack_180._2_2_,(undefined2)uStack_180);
    if (uVar25 == 0) {
      uStack_198 = uStack_198 & 0xffff;
      uVar25 = (uint)ppbVar30;
      uVar22 = (ulonglong)ppbVar30 & 0xffffffff;
      if ((*pbStack_190 & 0x10) != 0) {
        uVar25 = uVar25 + 2 +
                 (*(ushort *)(pbStack_190 + ((ulonglong)ppbVar30 & 0xffffffff)) + 7 >> 3);
        uVar22 = (ulonglong)uVar25;
      }
      uStack_188 = (byte **)CONCAT44(uVar25,(undefined4)uStack_188);
      uVar32 = (uint)uVar22;
      if ((*pbStack_190 & 0x20) == 0) {
        uStack_17c = 0;
        uStack_194 = uVar32;
      }
      else {
        puVar34 = (ushort *)(pbStack_190 + uVar22);
        uStack_17c = *puVar34;
        if (uStack_17c == 0) {
          uStack_440 = 0x100b34;
          cVar8 = func_0x(0x1c72e70);
          if (cVar8 != '\0') {
            uStack_440 = 0x100b3d;
            lVar16 = func_0x();
            if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
              uStack_440 = 0x100b57;
              cVar8 = func_0x(0x1c72e70);
              if (cVar8 == '\0') {
                uStack_440 = 0x100b73;
                (*pcRam00000000011e09f8)(0x22,0x44,0x15,0x3eb);
              }
              else {
                puStack_418 = (undefined4 *)0x0;
                uStack_440 = 0x100b9a;
                (*_DAT_)(1,0x156287c,0x1682968,0x80f);
              }
            }
          }
          uStack_440 = 0x100bab;
          func_0x(pbStack_190,3);
        }
        uStack_180 = uStack_188._4_4_ + 2 + (uint)uStack_17c * 2;
        if (0x1f9e < uStack_180) {
          uStack_440 = 0x100bea;
          cVar8 = func_0x(0x1c72e70);
          if (cVar8 != '\0') {
            uStack_440 = 0x100bf3;
            lVar16 = func_0x();
            if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
              uStack_440 = 0x100c0d;
              cVar8 = func_0x(0x1c72e70);
              if (cVar8 == '\0') {
                uStack_440 = 0x100c29;
                (*pcRam00000000011e09f8)(0x22,0x44,0x15,0x3ec);
              }
              else {
                puStack_418 = (undefined4 *)0x0;
                uStack_440 = 0x100c50;
                (*_DAT_)(1,0x156287c,0x1682968,0x816);
              }
            }
          }
          uStack_440 = 0x100c63;
          func_0x(pbStack_190,4);
        }
        uVar24 = (ulonglong)uStack_17c;
        uStack_194 = puVar34[uVar24] & 0x7fff;
        if (uStack_194 < uStack_180) {
          uStack_440 = 0x100ca8;
          cVar8 = func_0x(0x1c72e70);
          if (cVar8 != '\0') {
            uStack_440 = 0x100cb1;
            lVar16 = func_0x();
            if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
              uStack_440 = 0x100ccb;
              cVar8 = func_0x(0x1c72e70);
              if (cVar8 == '\0') {
                uStack_440 = 0x100ce7;
                (*pcRam00000000011e09f8)(0x22,0x44,0x15,0x3ec);
              }
              else {
                puStack_418 = (undefined4 *)0x0;
                uStack_440 = 0x100d0e;
                (*_DAT_)(1,0x156287c,0x1682968,0x81d);
              }
            }
          }
          uStack_440 = 0x100d1c;
          func_0x(pbStack_190,4);
          uVar24 = (ulonglong)uStack_17c;
        }
        uVar22 = (ulonglong)uStack_194;
        iVar11 = 0;
        pbVar36 = pbStack_190;
        puVar5 = puVar34;
        uVar12 = uStack_180;
        uVar32 = uStack_180;
        if ((short)uVar24 != 0) {
          do {
            uVar25 = puVar5[1] & 0x7fff;
            if ((uVar25 < uStack_180) || ((uint)uVar22 < uVar25)) {
              uStack_440 = 0x100d73;
              uStack_180 = uVar12;
              cVar8 = func_0x(0x1c72e70);
              if (cVar8 != '\0') {
                uStack_440 = 0x100d7c;
                lVar16 = func_0x();
                if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                  uStack_440 = 0x100d96;
                  cVar8 = func_0x(0x1c72e70);
                  if (cVar8 == '\0') {
                    uStack_440 = 0x100db2;
                    (*pcRam00000000011e09f8)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    puStack_418 = (undefined4 *)0x0;
                    uStack_440 = 0x100dd6;
                    (*_DAT_)(1,0x156287c,0x1682968,0x82a);
                  }
                }
              }
              uStack_440 = 0x100de7;
              func_0x(pbStack_190,4);
              uVar24 = (ulonglong)uStack_17c;
              uVar22 = (ulonglong)uStack_194;
              pbVar36 = pbStack_190;
              uVar12 = uStack_180;
            }
            iVar11 = iVar11 + 1;
            puVar5 = puVar5 + 1;
            uStack_180 = uVar25;
            uVar32 = uVar12;
            param_1 = plStack_278;
          } while (iVar11 < (int)uVar24);
        }
        while( true ) {
          if (-1 < (short)puVar34[(ulonglong)((int)uVar24 - 1) + 1]) break;
          uVar26 = uVar12;
          if ((int)uVar24 != 1) {
            uVar26 = *(ushort *)(pbVar36 + uVar24 * 2 + (((ulonglong)uStack_188 >> 0x20) - 2)) &
                     0x7fff;
          }
          uVar28 = *(ushort *)(pbVar36 + uVar24 * 2 + ((ulonglong)uStack_188 >> 0x20)) & 0x7fff;
          if (((uVar26 < uVar12) || (uVar28 < uVar26)) ||
             (uVar19 = (ushort)uVar24, (uint)uVar22 < uVar28)) {
            uStack_440 = 0x100e8a;
            uStack_180 = uVar32;
            func_0x(pbVar36,7);
            uVar22 = (ulonglong)uStack_194;
            pbVar36 = pbStack_190;
            uVar19 = uStack_17c;
            uVar12 = uStack_180;
            uVar32 = uStack_180;
          }
          uVar25 = (uint)uVar22;
          uStack_180 = uVar32;
          if ((uVar26 < uVar12) || (uVar25 < uVar26)) goto code_r0x00101245;
          if (*(ushort *)(pbVar36 + uVar26) == 5) {
            uStack_198 = uStack_198 | 0x20000;
            uStack_17c = uVar19 - 1;
            uVar24 = (ulonglong)(uVar26 & 0xffff);
            pbVar1 = pbVar36 + uVar24;
            uStack_16e = (ushort)uVar26;
            if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
              uVar19 = uStack_16c & 0xc7ff;
            }
            else {
              uVar19 = uStack_16c ^ (*(ushort *)(pbVar1 + 2) ^ uStack_16c) & 0x3800;
            }
            uStack_16c = (uVar19 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar19;
            pbVar31 = pbVar36 + (ulonglong)((uStack_16c & 0x7ff) * 2) + 4 +
                                uVar24 + (uVar19 >> 0xb & 7) * 2;
            if (pbVar31 < pbVar1) {
              uStack_440 = 0x100f9e;
              func_0x(pbVar1,0x19);
              uVar24 = (ulonglong)uStack_16e;
              uVar22 = (ulonglong)uStack_194;
              pbVar36 = pbStack_190;
            }
            uVar32 = uStack_180;
            if (uVar28 - uVar26 <
                (((uStack_16c & 0x7ff) * 2 - (int)uVar24) - (int)pbStack_190) + (int)pbVar31) {
              uStack_440 = 0x100fe9;
              func_0x(pbVar36 + uVar24,0x19);
              uVar24 = (ulonglong)uStack_16e;
              uVar22 = (ulonglong)uStack_194;
              pbVar36 = pbStack_190;
              uVar32 = uStack_180;
            }
            iVar11 = 0;
            if (((uStack_16c & 0x3800) != 0) &&
               (puVar34 = (ushort *)(pbVar36 + uVar24 + 4), uVar19 = uStack_16c,
               (uStack_16c & 0x3800) != 0)) {
              do {
                if ((uVar19 & 0x7ff) < (*puVar34 & 0x7ff)) {
                  uStack_440 = 0x101055;
                  uStack_180 = uVar32;
                  func_0x(pbVar36 + uVar24,0x1a);
                  uVar24 = (ulonglong)uStack_16e;
                  pbVar36 = pbStack_190;
                  uVar32 = uStack_180;
                  uVar19 = uStack_16c;
                }
                iVar11 = iVar11 + 1;
                puVar34 = puVar34 + 1;
              } while (iVar11 < (int)((uStack_16c & 0x3800) >> 0xb));
              uVar22 = (ulonglong)uStack_194;
            }
            break;
          }
          if (*(ushort *)(pbVar36 + uVar26) < 0x400) break;
          uStack_198 = uStack_198 | 0x10000;
          uStack_17c = uVar19 - 1;
          uVar24 = (ulonglong)uStack_17c;
          if (uStack_17c == 0) break;
        }
      }
      if ((*pbVar36 & 0x40) == 0) {
        uStack_172 = 0;
        uStack_170 = 0;
      }
      else {
        uStack_172 = (undefined2)uVar22;
        uStack_170 = (undefined2)(uVar22 >> 0x10);
        uStack_194 = (int)uVar22 + 0xe;
        uStack_440 = 0x1010c2;
        uStack_180 = uVar32;
        uVar17 = func_0x((longlong)&uStack_198 + 2);
        uStack_440 = 0x1010d1;
        func_0x(uVar17,auStack_270);
        uStack_440 = 0x1010dd;
        iVar11 = func_0x(auStack_270);
        uStack_194 = uStack_194 + iVar11;
        uVar22 = (ulonglong)uStack_194;
        pbVar36 = pbStack_190;
        uVar32 = uStack_180;
      }
      uVar25 = (uint)uVar22;
      uStack_180 = uVar32;
      if (((byte *)CONCAT62(uStack_178,uStack_17a) != (byte *)0x0) &&
         ((byte *)CONCAT62(uStack_178,uStack_17a) < pbVar36 + uVar22)) {
        uStack_440 = 0x101125;
        cVar8 = func_0x(0x1c72e70);
        if (cVar8 != '\0') {
          uStack_440 = 0x10112e;
          lVar16 = func_0x();
          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
            uStack_440 = 0x101148;
            cVar8 = func_0x(0x1c72e70);
            if (cVar8 == '\0') {
              uStack_440 = 0x101164;
              (*pcRam00000000011e09f8)(0x22,0x44,0x15,0x3fa);
            }
            else {
              puStack_418 = (undefined4 *)0x0;
              uStack_440 = 0x10118a;
              (*_DAT_)(1,0x156287c,0x1682968,0x886);
            }
          }
        }
        uStack_440 = 0x10119b;
        func_0x(pbStack_190,0x12);
        pbVar36 = pbStack_190;
        uVar25 = uStack_194;
      }
      if (0x3f3b < uVar25 - 1) {
        uStack_440 = 0x1011c2;
        cVar8 = func_0x(0x1c72e70);
        if (cVar8 != '\0') {
          uStack_440 = 0x1011cb;
          lVar16 = func_0x();
          if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
            uStack_440 = 0x1011e5;
            cVar8 = func_0x(0x1c72e70);
            if (cVar8 == '\0') {
              uStack_440 = 0x101201;
              (*pcRam00000000011e09f8)(0x22,0x44,0x15,0x3ed);
            }
            else {
              puStack_418 = (undefined4 *)0x0;
              uStack_440 = 0x101227;
              (*_DAT_)(1,0x156287c,0x1682968,0x88b);
            }
          }
        }
        uStack_440 = 0x101238;
        func_0x(pbStack_190,5);
        pbVar36 = pbStack_190;
        uVar25 = uStack_194;
      }
    }
code_r0x00101245:
    lVar16 = lStack_338;
    if ((uVar25 < 9) && (((*pbVar36 & 0xe) == 0 || ((*pbVar36 & 0xe) == 0xc)))) {
      uVar12 = CONCAT22(uStack_170,uStack_172);
      if ((*pbVar36 & 0x40) == 0) {
        uVar12 = 9;
      }
    }
    else {
      uVar12 = CONCAT22(uStack_170,uStack_172);
      if ((*pbVar36 & 0x40) == 0) {
        uVar12 = uVar25;
      }
    }
  }
  else {
    if (uVar25 == 0) {
      uStack_440 = 0x101299;
      func_0x((longlong)&uStack_198 + 2);
      uVar25 = uStack_194;
      if (uStack_194 == 0) {
        uStack_440 = 0x1012af;
        func_0x((longlong)&uStack_198 + 2);
        uVar25 = uStack_194;
      }
    }
    if ((8 < uVar25) || (((*pbStack_190 & 0x1c) != 0 && ((*pbStack_190 & 0x1c) != 0xc)))) {
      uVar32 = uVar25;
    }
    uVar12 = uStack_168;
    uStack_180 = CONCAT22(uStack_180._2_2_,(undefined2)uStack_180);
    if ((*pbStack_190 & 2) == 0) {
      uVar12 = uVar32;
      uStack_180 = CONCAT22(uStack_180._2_2_,(undefined2)uStack_180);
    }
  }
  uVar25 = uStack_390;
  uVar22 = (ulonglong)uStack_390 + 0xf;
  if (uVar22 <= uStack_390) {
    uVar22 = 0xffffffffffffff0;
  }
  uVar22 = uVar22 & 0xfffffffffffffff0;
  uStack_440 = 0x101305;
  func_0x();
  uVar32 = uStack_3cc;
  uStack_198 = 0;
  lVar35 = -uVar22;
  puVar27 = auStack_438 + lVar35;
  uStack_172 = 0;
  uStack_170 = 0;
  iVar11 = uStack_3cc - 4;
  pbStack_190 = abStack_3d8 + lVar35;
  *pbStack_190 = 8;
  pbStack_190[1] = 0;
  *(short *)(pbStack_190 + 2) = (short)iVar11 + 4;
  uStack_17c = 0;
  uStack_188 = (byte **)CONCAT44(uVar32,uVar32);
  uStack_194 = uVar32;
  uStack_180._0_2_ = (undefined2)uVar32;
  uStack_180._2_2_ = (short)(uVar32 >> 0x10);
  uVar19 = *(ushort *)(lVar16 + (0xfff - (longlong)*piStack_3b8) * 2);
  *(undefined8 *)(auStack_438 + lVar35 + -8) = 0x101393;
  func_0x
            ((longlong)&uStack_3d4 + lVar35,uVar25 - 4,(ulonglong)uVar19 + lVar16 + 4,iVar11);
  uVar25 = uStack_3d4;
  uVar26 = uVar32 + uStack_3d4;
  if (uVar26 < uStack_3d4) {
    uVar26 = 0xffffffff;
    *(undefined8 *)(auStack_438 + lVar35 + -8) = 0x1013b8;
    func_0x(0x80070216,uVar25,uVar32);
    uVar37 = uStack_388;
    uVar38 = uStack_384;
    uVar39 = uStack_380;
    uVar40 = uStack_37c;
  }
  if (uVar12 < uVar26) {
    iVar11 = -1;
    *(undefined8 *)(auStack_438 + lVar35 + -8) = 0x1013ea;
    func_0x(0x80070216,uVar12,uVar26);
    uVar37 = uStack_388;
    uVar38 = uStack_384;
    uVar39 = uStack_380;
    uVar40 = uStack_37c;
code_r0x001013f0:
    *(undefined8 *)(auStack_438 + lVar35 + -8) = 0x10140f;
    lVar16 = func_0x();
    lVar16 = -lVar16;
    puVar27 = auStack_438 + lVar16 + lVar35;
    pbVar36 = abStack_3d8 + lVar16 + lVar35;
    *(undefined8 *)(auStack_438 + lVar16 + lVar35 + -8) = 0x10142c;
    func_0x(pbVar36);
  }
  else {
    iVar11 = uVar12 - uVar26;
    pbVar36 = (byte *)0x0;
    if (iVar11 != 0) goto code_r0x001013f0;
  }
  pplVar29 = pplStack_318;
  uStack_330 = *(undefined4 *)(**pplStack_318 + 0x20);
  uStack_32c = *(undefined2 *)(**pplStack_318 + 0x24);
  uStack_32a = *(undefined2 *)piStack_3b8;
  *(undefined8 *)(puVar27 + -8) = 0x101463;
  func_0x(pplVar29);
  if (*(char *)(*(longlong *)(*(longlong *)(param_1[1] + 0x58) + 8) + 0x751) == '\0') {
    puVar27[0x28] = 0;
    *(undefined4 *)(puVar27 + 0x20) = 4;
    *(undefined8 *)(puVar27 + -8) = 0x10149e;
    func_0x(param_1,auStack_260,&uStack_330,5);
  }
  puVar27[0x30] = 1;
  *(undefined8 *)(puVar27 + 0x28) = 0;
  *(undefined4 *)(puVar27 + 0x20) = 0;
  *(undefined8 *)(puVar27 + -8) = 0x1014c6;
  func_0x(pplVar29,4,0xffffffff,auStack_258);
  if ((int)uStack_254 != 0) {
    uVar17 = *(undefined8 *)(param_1[1] + 0x58);
    uVar2 = *(undefined *)(**pplVar29 + 1);
    *(undefined8 *)(puVar27 + -8) = 0x1014f3;
    func_0x(uVar17,uVar2,auStack_258,0xffffffff);
  }
  bVar33 = 0;
  if (*(int *)(param_1[1] + 0x38) == 3) {
    bVar33 = 4;
  }
  bVar33 = bVar33 | bStack_378 & 0xea;
  puStack_2b0 = puStack_2b8;
  *puStack_2b8 = 0x4000000;
  puStack_2a8 = puStack_2b8 + 1;
  uStack_2c0 = 0;
  bStack_378 = bVar33;
  *(undefined8 *)(puVar27 + -8) = 0x101552;
  func_0x(param_1,0,&uStack_2e8);
  if ((*(byte *)(param_1 + 0xc) & 2) == 0) {
    if ((*(byte *)((longlong)param_1 + 0x8c) & 1) != 0) {
      *(undefined8 *)(puVar27 + -8) = 0x101593;
      func_0x(param_1,param_1 + 0x12,&uStack_2e8);
      *(uint *)((longlong)param_1 + 0x8c) = *(uint *)((longlong)param_1 + 0x8c) & 0xfffffffe;
    }
  }
  else {
    *(undefined8 *)(puVar27 + -8) = 0x10156c;
    func_0x(param_1,(longlong)param_1 + 0x3c,&uStack_2e8);
    *(uint *)(param_1 + 0xc) = *(uint *)(param_1 + 0xc) & 0xfffffffd;
  }
  lVar35 = lStack_298;
  lVar16 = lStack_3c8;
  uStack_208 = CONCAT71(uStack_377,bStack_378);
  auStack_218._4_4_ = uVar38;
  auStack_218._0_4_ = uVar37;
  auStack_218._8_4_ = uVar39;
  auStack_218._12_4_ = uVar40;
  if ((*(longlong *)(lStack_298 + 8) == 0) ||
     (lVar3 = *(longlong *)(*(longlong *)(lStack_298 + 8) + 8), *(char *)(lVar3 + 0x3f) != '\0')) {
    if (*(int *)(lStack_298 + 0x40) == 2) {
      uStack_328 = **(undefined4 **)(lStack_298 + 0x30);
      puVar21 = &uStack_328;
      uStack_324 = *(undefined2 *)(*(undefined4 **)(lStack_298 + 0x30) + 1);
      uStack_322 = 0;
    }
    else {
      uStack_320 = **(undefined4 **)(lStack_298 + 0x28);
      puVar21 = &uStack_320;
      uStack_31c = *(undefined2 *)(*(undefined4 **)(lStack_298 + 0x28) + 1);
      uStack_31a = 0;
    }
    uStack_3a0 = *puVar21;
    uStack_39c = *(undefined2 *)(puVar21 + 1);
  }
  else {
    uStack_3a0 = *(undefined4 *)(lVar3 + 8);
    uStack_39c = *(undefined2 *)(lVar3 + 0xc);
  }
  uStack_39a = 0;
  uVar17 = *(undefined8 *)(param_1[1] + 0x58);
  *(undefined **)(puVar27 + 0x30) = auStack_218;
  *(int *)(puVar27 + 0x28) = *piStack_3b8;
  *(undefined4 **)(puVar27 + 0x20) = &uStack_2e8;
  *(undefined8 *)(puVar27 + -8) = 0x101678;
  func_0x(pplVar29,uVar17,&uStack_3a0,lVar16);
  if (*pplVar29 != (longlong *)0x0) {
    if (((*(ushort *)((longlong)*pplVar29 + 0x62) >> 10 & 1) == 0) ||
       (*(short *)((longlong)pplVar29 + 0xc) < 3)) {
      iVar14 = (int)*(short *)((longlong)pplVar29 + 0xc);
      plVar23 = *pplStack_318;
      if (((byte)*(undefined2 *)((longlong)plVar23 + 0x62) >> 3 & 1) != 0) {
        if (iVar14 == 3) {
          iVar14 = 4;
        }
        else if (iVar14 < 2) goto code_r0x001017e5;
        if ((((*(uint *)((longlong)plVar23 + 100) & 8) != 0) &&
            (lVar16 = plVar23[0x12], lVar16 != 0)) && (*(longlong *)(lVar16 + 0x758) != 0)) {
          uVar17 = *(undefined8 *)(lVar16 + 0x758);
          *(undefined8 *)(puVar27 + -8) = 0x1017e5;
          func_0x(uVar17,plVar23,iVar14);
        }
      }
code_r0x001017e5:
      if ((((bRam0000000001c7f515 & 0x80) != 0) && ((*(uint *)((longlong)plVar23 + 100) & 8) != 0))
         && ((2 < iVar14 &&
             (((*(uint *)((longlong)plVar23 + 100) & 0xc0000000) != 0x40000000 &&
              (lVar16 = *plVar23, lVar16 != 0)))))) {
        *(undefined8 *)(puVar27 + -8) = 0x101829;
        iVar13 = (*pcRam00000000011ddad8)(lVar16,0x2000,2,auStack_280);
        if (iVar13 != 0) {
          LOCK();
          *(uint *)((longlong)plVar23 + 100) = *(uint *)((longlong)plVar23 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar23 + 100) = *(uint *)((longlong)plVar23 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)(puVar27 + -8) = 0x10184b;
      func_0x(plVar23 + 0x13);
      if ((iRam0000000001c85750 != 0) && ((bRam0000000001c7f67f & 2) != 0)) {
        *(undefined8 *)(puVar27 + -8) = 0x10186a;
        func_0x(plVar23,0,iVar14);
      }
      *(undefined2 *)((longlong)pplStack_318 + 0xc) = 0;
      *pplStack_318 = (longlong *)0x0;
      lVar35 = lStack_298;
      pplVar29 = pplStack_318;
      uVar37 = uStack_388;
      uVar38 = uStack_384;
      uVar39 = uStack_380;
      uVar40 = uStack_37c;
    }
    else {
      *(undefined8 *)(puVar27 + -8) = 0x1016a2;
      func_0x(pplVar29);
      uVar37 = uStack_388;
      uVar38 = uStack_384;
      uVar39 = uStack_380;
      uVar40 = uStack_37c;
    }
  }
  uStack_3d0 = uStack_3d0 & 0xfffffff8;
  uVar25 = (uVar12 - uStack_3d4) + param_6;
  plVar23 = *(longlong **)(lVar35 + 0x50);
  if (uVar25 < param_8) {
    uVar25 = param_8;
  }
  uVar32 = *(uint *)((longlong)param_1 + 0x34);
  *(undefined4 *)(puVar27 + 0x40) = 0;
  piVar6 = piStack_3b8;
  lVar16 = *plVar23;
  uStack_350 = 0;
  uStack_34c = 0;
  uVar12 = uVar25 + 0xe;
  if ((uVar32 & 0x10000) == 0) {
    uVar12 = uVar25;
  }
  *(uint **)(puVar27 + 0x38) = &uStack_3d0;
  *(undefined4 **)(puVar27 + 0x30) = &uStack_350;
  *(uint *)(puVar27 + 0x28) = uVar12;
  puVar27[0x20] = 3;
  pcVar4 = *(code **)(lVar16 + 0x10);
  *(undefined8 *)(puVar27 + -8) = 0x10171b;
  (*pcVar4)(plVar23,param_1 + 0x14,pplVar29,piVar6);
  *(undefined8 *)(puVar27 + -8) = 0x10172e;
  func_0x(param_1,&uStack_3d0,&uStack_2e8);
  lVar16 = lStack_3c8;
  uStack_1e8 = CONCAT71(uStack_377,bStack_378);
  auStack_1f8._4_4_ = uVar38;
  auStack_1f8._0_4_ = uVar37;
  auStack_1f8._8_4_ = uVar39;
  auStack_1f8._12_4_ = uVar40;
  lStack_268 = (ulonglong)*(uint6 *)(*(longlong *)(lVar35 + 0x10) + 0x14) << 0x10;
  if ((*(longlong *)(lVar35 + 8) == 0) ||
     (lVar3 = *(longlong *)(*(longlong *)(lVar35 + 8) + 8), *(char *)(lVar3 + 0x3f) != '\0')) {
    if (*(int *)(lVar35 + 0x40) == 2) {
      uStack_310 = **(undefined4 **)(lVar35 + 0x30);
      puVar21 = &uStack_310;
      uStack_30c = *(undefined2 *)(*(undefined4 **)(lVar35 + 0x30) + 1);
      uStack_30a = 0;
    }
    else {
      uStack_308 = **(undefined4 **)(lVar35 + 0x28);
      puVar21 = &uStack_308;
      uStack_304 = *(undefined2 *)(*(undefined4 **)(lVar35 + 0x28) + 1);
      uStack_302 = 0;
    }
    uStack_398 = *puVar21;
    uStack_394 = *(undefined2 *)(puVar21 + 1);
  }
  else {
    uStack_398 = *(undefined4 *)(lVar3 + 8);
    uStack_394 = *(undefined2 *)(lVar3 + 0xc);
  }
  uStack_392 = 0;
  *(undefined4 **)(puVar27 + 0x38) = &uStack_198;
  *(undefined **)(puVar27 + 0x30) = auStack_1f8;
  *(int *)(puVar27 + 0x28) = *piVar6;
  *(undefined4 **)(puVar27 + 0x20) = &uStack_2e8;
  *(undefined8 *)(puVar27 + -8) = 0x101934;
  func_0x(pplVar29,&lStack_268,&uStack_398,lVar16);
  lVar16 = lStack_3c8;
  uVar25 = uStack_3cc;
  bVar18 = abStack_3d8[0];
  bVar7 = abStack_3d8[0] | bVar33;
  uStack_1c8 = CONCAT71(uStack_377,bVar7);
  auStack_1d8._4_4_ = uVar38;
  auStack_1d8._0_4_ = uVar37;
  auStack_1d8._8_4_ = uVar39;
  auStack_1d8._12_4_ = uVar40;
  if ((*(longlong *)(lVar35 + 8) == 0) ||
     (lVar3 = *(longlong *)(*(longlong *)(lVar35 + 8) + 8), *(char *)(lVar3 + 0x3f) != '\0')) {
    if (*(int *)(lVar35 + 0x40) == 2) {
      uStack_300 = **(undefined4 **)(lVar35 + 0x30);
      puVar21 = &uStack_300;
      uStack_2fc = *(undefined2 *)(*(undefined4 **)(lVar35 + 0x30) + 1);
      uStack_2fa = 0;
    }
    else {
      uStack_2f8 = **(undefined4 **)(lVar35 + 0x28);
      puVar21 = &uStack_2f8;
      uStack_2f4 = *(undefined2 *)(*(undefined4 **)(lVar35 + 0x28) + 1);
      uStack_2f2 = 0;
    }
    uStack_3c0 = *puVar21;
    uStack_3bc = *(undefined2 *)(puVar21 + 1);
  }
  else {
    uStack_3c0 = *(undefined4 *)(lVar3 + 8);
    uStack_3bc = *(undefined2 *)(lVar3 + 0xc);
  }
  lVar3 = param_1[1];
  abStack_3d8[0] = bVar7;
  bStack_378 = bVar7;
  *(undefined **)(puVar27 + 0x50) = auStack_1d8;
  *(undefined8 *)(puVar27 + 0x48) = uStack_290;
  *(int *)(puVar27 + 0x40) = param_6;
  piVar6 = piStack_3b8;
  *(undefined4 *)(puVar27 + 0x38) = 0;
  uStack_3ba = 0;
  uVar17 = *(undefined8 *)(lVar3 + 0x58);
  iVar14 = *piVar6;
  *(uint *)(puVar27 + 0x30) = uVar25;
  *(int *)(puVar27 + 0x28) = iVar14;
  *(undefined8 *)(puVar27 + 0x20) = 0;
  *(undefined8 *)(puVar27 + -8) = 0x101a31;
  iVar14 = func_0x(pplVar29,uVar17,&uStack_3c0,lVar16);
  if (iVar14 != 0) {
    *(undefined8 *)(puVar27 + 0x20) = 0;
    *(undefined8 *)(puVar27 + -8) = 0x101a59;
    (*_DAT_)(1,0x1717ba8,0x16e7ad8,0x499);
  }
  lVar16 = lStack_3c8;
  if (iVar11 != 0) {
    bStack_378 = bVar18 & 0xfe | bVar33;
    uStack_1a8 = CONCAT71(uStack_377,bVar7) & 0xfffffffffffffffe;
    auStack_1b8._4_4_ = uVar38;
    auStack_1b8._0_4_ = uVar37;
    auStack_1b8._8_4_ = uVar39;
    auStack_1b8._12_4_ = uVar40;
    if ((*(longlong *)(lVar35 + 8) == 0) ||
       (lVar3 = *(longlong *)(*(longlong *)(lVar35 + 8) + 8), *(char *)(lVar3 + 0x3f) != '\0')) {
      if (*(int *)(lVar35 + 0x40) == 2) {
        uStack_2f0 = **(undefined4 **)(lVar35 + 0x30);
        puVar21 = &uStack_2f0;
        uStack_2ec = *(undefined2 *)(*(undefined4 **)(lVar35 + 0x30) + 1);
        uStack_2ea = 0;
      }
      else {
        uStack_360 = **(undefined4 **)(lVar35 + 0x28);
        puVar21 = &uStack_360;
        uStack_35c = *(undefined2 *)(*(undefined4 **)(lVar35 + 0x28) + 1);
        uStack_35a = 0;
      }
      uStack_3b0 = *puVar21;
      uVar10 = *(undefined2 *)(puVar21 + 1);
    }
    else {
      uStack_3b0 = *(undefined4 *)(lVar3 + 8);
      uVar10 = *(undefined2 *)(lVar3 + 0xc);
    }
    lVar35 = param_1[1];
    *(undefined **)(puVar27 + 0x50) = auStack_1b8;
    uStack_3ac = uVar10;
    *(byte **)(puVar27 + 0x48) = pbVar36;
    uStack_3aa = 0;
    uVar17 = *(undefined8 *)(lVar35 + 0x58);
    *(int *)(puVar27 + 0x40) = iVar11;
    *(undefined4 *)(puVar27 + 0x38) = 0;
    *(uint *)(puVar27 + 0x30) = param_6 + uVar25;
    *(int *)(puVar27 + 0x28) = *piStack_3b8;
    *(undefined8 *)(puVar27 + 0x20) = 0;
    *(undefined8 *)(puVar27 + -8) = 0x101b4c;
    iVar11 = func_0x(pplVar29,uVar17,&uStack_3b0,lVar16);
    if (iVar11 != 0) {
      *(undefined8 *)(puVar27 + 0x20) = 0;
      *(undefined8 *)(puVar27 + -8) = 0x101b72;
      (*_DAT_)(1,0x1717ba8,0x16e7ad8,0x4ab);
    }
  }
  if (*(char *)(param_1[1] + 0x17c) != '\0') {
    plVar23 = *pplVar29;
    *(undefined8 *)(puVar27 + -8) = 0x101b94;
    func_0x(plVar23 + 0xe,lVar16);
  }
  if (cStack_29e != '\0') {
    *(undefined *)(param_1[1] + 0x188) = 0;
  }
LAB_:
  uVar22 = uStack_68 ^ (ulonglong)abStack_3d8;
  *(undefined8 *)(puVar27 + -8) = 0x101bb7;
  func_0x(uVar22);
  return;
}

