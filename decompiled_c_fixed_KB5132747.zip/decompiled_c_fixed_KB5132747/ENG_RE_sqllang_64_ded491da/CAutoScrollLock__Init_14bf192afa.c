
void FUN_(longlong *param_1,longlong *param_2,int param_3,int param_4,longlong param_5)

{
  bool bVar1;
  int iVar2;
  longlong lVar3;
  
  lVar3 = (**(code **)(*param_2 + 0xf8))(param_2);
  param_1[3] = param_5;
  *param_1 = lVar3;
  *(undefined4 *)(param_1 + 2) = 0;
  if (((lVar3 == 0) || (param_4 != 0)) ||
     ((param_3 == 0 && (iVar2 = (**(code **)(*param_2 + 0x30))(param_2), iVar2 == 0)))) {
    bVar1 = false;
    *(undefined4 *)(param_1 + 1) = 0;
    if (param_4 == 0) goto LAB_;
LAB_:
    lVar3 = *param_1;
    *(undefined4 *)((longlong)param_1 + 0xc) = 0;
    if (lVar3 == 0) goto LAB_;
  }
  else {
    bVar1 = true;
    *(undefined4 *)(param_1 + 1) = 1;
LAB_:
    if (((param_3 != 0) || (lVar3 = *param_1, lVar3 == 0)) || (*(int *)(lVar3 + 100) == 0))
    goto LAB_;
    *(undefined4 *)((longlong)param_1 + 0xc) = 1;
  }
  *(undefined4 *)((longlong)param_1 + 0x14) = *(undefined4 *)(lVar3 + 0x88);
LAB_:
  if (bVar1) {
    if (param_3 == 0) {
      *(undefined4 *)(lVar3 + 0xd8) = 1;
      lVar3 = *param_1;
    }
    *(longlong *)(param_1[3] + 0x40) = lVar3;
  }
  return;
}

