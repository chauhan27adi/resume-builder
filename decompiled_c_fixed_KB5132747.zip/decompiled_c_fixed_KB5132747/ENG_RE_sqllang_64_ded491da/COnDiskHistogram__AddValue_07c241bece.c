
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,char *param_2,char param_3)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  longlong *plVar4;
  undefined auStack_108 [80];
  undefined8 uStack_b8;
  ulonglong uStack_38;
  
  uStack_b8 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_108;
  if (*(longlong *)(param_1 + 0x60) != 0) {
    plVar4 = (longlong *)(param_2 + 8);
    if (*(char *)((ulonglong)*(byte *)((ulonglong)(byte)param_2[1] + 0x1f48250) + 0x1f7d350) != '\0'
       ) {
      plVar4 = (longlong *)*plVar4;
    }
    uVar1 = (*_DAT_)(param_2,param_1 + 0x18);
    if (*param_2 == '\x03') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(param_1 + 0x6c) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    func_0x(*(undefined8 *)(param_1 + 0x60),plVar4,uVar1,param_3);
  }
  if (*param_2 == '\x03') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(char *)(param_1 + 0x120) != '\0') && (2 < *(int *)(param_1 + 0xf8))) {
    if (param_3 == '\0') {
      if (0 < *(longlong *)(param_1 + 0x108)) {
        if (*(char *)(param_1 + 0xb0 + (ulonglong)*(ushort *)(param_1 + 0xf2) * 0x28) == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        plVar4 = (longlong *)(param_1 + ((ulonglong)*(ushort *)(param_1 + 0xf2) + 4) * 0x28);
        iVar3 = 4;
        if ((*(byte *)(param_1 + 0x130) & 1) == 0) {
          iVar3 = 1;
        }
        if (plVar4 != (longlong *)0x0) {
          iVar2 = (*_DAT_)(*(undefined8 *)(*plVar4 + 0x10),param_1 + 0x18,param_1 + 0x18,
                                   param_2);
          if (iVar2 != iVar3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
        }
      }
      func_0x(param_1,param_2);
      goto LAB_;
    }
    if (*(char *)(param_1 + 0xb0 + (ulonglong)*(ushort *)(param_1 + 0xf2) * 0x28) == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    plVar4 = (longlong *)
             (*(longlong *)(param_1 + 0xa0 + (ulonglong)*(ushort *)(param_1 + 0xf2) * 0x28) + 0x28);
    *plVar4 = *plVar4 + 1;
  }
  *(longlong *)(param_1 + 0x108) = *(longlong *)(param_1 + 0x108) + 1;
LAB_:
  func_0x(uStack_38 ^ (ulonglong)auStack_108);
  return;
}

