
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_(int *param_1,longlong param_2)

{
  byte bVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  longlong lVar6;
  longlong unaff_GS_OFFSET;
  
  if ((*(byte *)(param_2 + 0x5b0) & 4) != 0) {
    *(undefined2 *)(param_2 + 0x120) = 0;
    *(byte *)(param_2 + 0x5b0) = *(byte *)(param_2 + 0x5b0) & 0xfb;
    iVar3 = *(int *)(param_2 + 0x1c);
    *param_1 = iVar3;
    return iVar3;
  }
  if (*(int *)(param_2 + 0x124) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(int *)(param_2 + 0x5e4) = *(int *)(param_2 + 0x25c) + *(int *)(param_2 + 600);
  if (*(char *)(param_2 + 0x121) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(char *)(param_2 + 0x120) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar3 = func_0x(param_1,param_2,param_2 + 0x130);
  if (*(int *)(param_2 + 0x14) == 4) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar3 != 0) {
    *(undefined4 *)(param_2 + 0x588) = *(undefined4 *)(param_2 + 0x248);
    *(undefined4 *)
     (*(longlong *)
       (*(longlong *)
         (*(longlong *)
           ((ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
         0xa0) + 8) + 0x1d4) = *(undefined4 *)(param_2 + 0x248);
  }
  func_0x(param_2,iVar3,param_2 + 0x130,0);
  iVar5 = *(int *)(param_2 + 0x14);
  if (iVar5 == 4) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar5 != 10) {
    *(undefined4 *)(param_2 + 0x14) = 0;
  }
  bVar1 = *(byte *)(param_2 + 0x5b0);
  if (((bVar1 & 1) != 0) || (iVar5 == 9)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (((iVar3 == 0x3b) || (iVar3 == 0x152)) || (iVar3 == 0x134)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(byte *)(param_2 + 0x5b0) = ((bVar1 * '\x02' ^ bVar1) & 2 ^ bVar1) & 0xfe;
  if (iVar3 == 0x1aa) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar3 == 0x175) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar3 == 0x1a6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar3 == 0x134) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(int *)(*(longlong *)(param_2 + 0x110) + 0x1c) - 6U & 0xfffffffd) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (((DAT_ != '\0') && (-1 < *(char *)(_DAT_ + 0x56c))) &&
     (*(int *)(*(longlong *)(param_2 + 0x110) + 0x1c) == 6)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar3 == 0x10f) {
    iVar4 = (*_DAT_)(1,0,*(undefined8 *)(param_2 + 0x130),
                             (ulonglong)(longlong)*(int *)(param_2 + 0x138) >> 1,0x21210f0,4);
    if (iVar4 == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(param_2 + 0x10) < 0x6e) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    iVar4 = (*_DAT_)(1,0,*(undefined8 *)(param_2 + 0x130),
                             (ulonglong)(longlong)*(int *)(param_2 + 0x138) >> 1,0x2121258,6);
    if (iVar4 == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (DAT_ == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(byte *)(_DAT_ + 0x52d) & 1) == 0) {
      if (*(int *)(param_2 + 0x10) < 0x82) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(int *)(*(longlong *)(param_2 + 0x110) + 0x1c) == 6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    if ((DAT_ != '\0') &&
       ((iVar4 = *(int *)(*(longlong *)(param_2 + 0x110) + 0x1c), iVar4 == 4 ||
        (((DAT_ != '\0' && ((*(byte *)(_DAT_ + 0x56c) & 4) == 0)) && (iVar4 == 5))))
       )) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (DAT_ != '\0') {
      if ((-1 < *(char *)(_DAT_ + 0x56c)) &&
         ((*(uint *)(*(longlong *)(param_2 + 0x110) + 0x18) >> 0x10 & 1) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (((DAT_ != '\0') && (-1 < *(char *)(_DAT_ + 0x56c))) &&
         ((*(uint *)(*(longlong *)(param_2 + 0x110) + 0x18) & 0x10000) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    if (((DAT_ != '\0') && ((*(byte *)(_DAT_ + 0x56c) & 2) == 0)) &&
       (*(int *)(*(longlong *)(param_2 + 0x110) + 0x1c) == 8)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iVar5 == 5) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iVar5 == 6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iVar5 == 7) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iVar5 == 8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iVar5 == 3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iVar5 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iVar5 == 10) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iVar5 == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(uint *)(*(longlong *)(param_2 + 0x110) + 0x18) & 0x120) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(uint *)(*(longlong *)(param_2 + 0x110) + 0x18) & 0x200) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar2 = *(uint *)(*(longlong *)(param_2 + 0x110) + 0x18);
    if (((uVar2 >> 0xb & 1) != 0) || ((uVar2 >> 0xe & 1) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(uint *)(*(longlong *)(param_2 + 0x110) + 0x18) & 0x3000) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(uint *)(*(longlong *)(param_2 + 0x110) + 0x18) & 0x2000) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(uint *)(*(longlong *)(param_2 + 0x110) + 0x18) & 0x2000) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    iVar5 = (*_DAT_)(1,0,*(undefined8 *)(param_2 + 0x130),
                             (ulonglong)(longlong)*(int *)(param_2 + 0x138) >> 1,0x21210e4,2);
    if (iVar5 == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(_DAT_ + 0x38a8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar6 = (*_DAT_)();
    if (*(char *)(lVar6 + 0x2ee4) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar6 = (*_DAT_)();
    if (*(char *)(lVar6 + 0x2ee4) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (DAT_ == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (((*(byte *)(_DAT_ + 0x669) & 4) == 0) &&
       (iVar5 = (*_DAT_)(1,0,*(undefined8 *)(param_2 + 0x130),
                                 (ulonglong)(longlong)*(int *)(param_2 + 0x138) >> 1,0x2121148,6),
       iVar5 == 2)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (DAT_ == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (((*(byte *)(_DAT_ + 0x669) & 4) == 0) &&
       (iVar5 = (*_DAT_)(1,0,*(undefined8 *)(param_2 + 0x130),
                                 (ulonglong)(longlong)*(int *)(param_2 + 0x138) >> 1,0x2121128,7),
       iVar5 == 2)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (DAT_ != '\0') {
      if (((*(byte *)(_DAT_ + 0x15) & 0x10) == 0) && (0x9f < *(int *)(param_2 + 0x10))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (((DAT_ != '\0') && ((*(byte *)(_DAT_ + 0x15) & 0x10) == 0)) &&
         (0x9f < *(int *)(param_2 + 0x10))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    if ((((DAT_ != '\0') && ((*(byte *)(_DAT_ + 0x451) & 0x20) == 0)) &&
        ((0x9f < *(int *)(param_2 + 0x10) &&
         ((iVar5 = (*_DAT_)(1,0,*(undefined8 *)(param_2 + 0x130),
                                    (ulonglong)(longlong)*(int *)(param_2 + 0x138) >> 1,0x214e4e8,4)
          , iVar5 == 2 && (iVar5 = func_0x(param_2), iVar5 == 0x28)))))) &&
       (iVar5 = func_0x(param_2), iVar5 == 0x10f)) {
      iVar3 = (*_DAT_)(1,0,*(undefined8 *)(param_2 + 0x3f8),
                               (ulonglong)(longlong)*(int *)(param_2 + 0x400) >> 1,0x2439218,7);
      if (iVar3 != 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      func_0x(param_2);
      func_0x(param_2);
      iVar3 = 0x213;
      *param_1 = 0x213;
    }
  }
  return iVar3;
}

