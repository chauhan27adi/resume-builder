
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong param_2,ulonglong param_3,undefined param_4,
                 undefined4 param_5,undefined4 param_6)

{
  longlong lVar1;
  longlong lVar2;
  char cVar3;
  longlong lVar4;
  code *UNRECOVERED_JUMPTABLE;
  undefined8 unaff_RBX;
  undefined auStack_2618 [28];
  int iStack_25fc;
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar4 = func_0x();
  lVar4 = -lVar4;
  *(undefined8 *)(&stack0x00000038 + lVar4) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002678 + lVar4) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar4);
  if (*(longlong *)(*(longlong *)(param_2 + 0xa0) + 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar1 = *(longlong *)(param_2 + 0xa0);
  lVar2 = *(longlong *)(lVar1 + 8);
  if (((*(uint *)(lVar2 + 0x20) >> 1 & 1) != 0) && (*(longlong *)(lVar2 + 0x370) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined4 *)(&stack0x00000000 + lVar4) = param_6;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar4) = param_5;
  (&stack0xfffffffffffffff0)[lVar4] = param_4;
  (&stack0xffffffffffffffe8)[lVar4] = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar4) = 0x1000ba;
  func_0x(auStack_2618,param_1,param_2,param_3 & 0xffffffff);
  *(undefined8 *)((longlong)&uStack_40 + lVar4) = 0x1000c4;
  cVar3 = func_0x(auStack_2618);
  if ((cVar3 == '\0') && ((*(uint *)(*(longlong *)(lVar1 + 8) + 0x240) >> 4 & 1) == 0)) {
    if (iStack_25fc - 0x101U < 0xe) {
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)*(uint *)((longlong)(int)(iStack_25fc - 0x101U) * 4 + 0x100254) +
                   0x1040);
                    /* WARNING: Could not emulate address calculation at 0x001000fd */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
      return;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

