
void FUN_(longlong param_1,int param_2,undefined4 param_3)

{
  longlong lVar1;
  int iVar2;
  longlong *plVar3;
  char cVar4;
  longlong lVar5;
  longlong lVar6;
  undefined8 uVar7;
  undefined8 in_stack_ffffffffffffffd8;
  undefined4 uVar8;
  
  uVar8 = (undefined4)((ulonglong)in_stack_ffffffffffffffd8 >> 0x20);
  plVar3 = *(longlong **)(param_1 + 0x10);
  lVar5 = (**(code **)(*plVar3 + 0x588))(plVar3);
  iVar2 = *(int *)(plVar3[8] + 0xc);
  if (299 < iVar2) {
    if (iVar2 < 0x230) {
      if (iVar2 == 0x22f) {
        return;
      }
      switch(iVar2) {
      case 0x130:
      case 0x139:
      case 0x13c:
      case 0x141:
      case 0x150:
      case 0x151:
      case 0x159:
      case 0x15d:
      case 0x171:
      case 0x186:
      case 0x18b:
      case 0x19e:
      case 0x1a1:
      case 0x1a4:
      case 0x1b2:
      case 0x1b6:
      case 0x1de:
      case 0x1e1:
      case 0x1e2:
      case 0x1e3:
      case 0x1e5:
      case 0x1e6:
      case 0x1f0:
      case 0x1f1:
      case 0x221:
      case 0x222:
        goto LAB_;
      case 0x13f:
      case 0x155:
      case 0x156:
      case 0x158:
      case 0x163:
      case 0x19b:
      case 0x1c8:
        goto code_r0x001002a3;
      case 0x14b:
      case 0x196:
      case 0x1bc:
      case 0x1c1:
        goto LAB_;
      case 0x152:
        goto code_r0x00100226;
      case 0x1a6:
        goto code_r0x00100114;
      case 0x1e0:
        if (cRam0000000001e1198b != '\0') {
          return;
        }
        lVar6 = -1;
        do {
          lVar1 = lVar6 * 2;
          lVar6 = lVar6 + 1;
        } while (*(short *)(lVar5 + 2 + lVar1) != 0);
        goto LAB_;
      case 0x217:
      case 0x218:
      case 0x219:
      case 0x21a:
      case 0x21b:
LAB_:
        if (DAT_ != '\0') {
          return;
        }
        lVar6 = -1;
        do {
          lVar1 = lVar6 * 2;
          lVar6 = lVar6 + 1;
        } while (*(short *)(lVar5 + 2 + lVar1) != 0);
        goto LAB_;
      }
    }
    else if (iVar2 == 0x252) goto LAB_;
LAB_:
    lVar6 = -1;
    do {
      lVar1 = lVar6 * 2;
      lVar6 = lVar6 + 1;
    } while (*(short *)(lVar5 + 2 + lVar1) != 0);
    goto LAB_;
  }
  if (iVar2 == 299) {
LAB_:
    if (param_2 != 0) {
      return;
    }
    lVar6 = -1;
    do {
      lVar1 = lVar6 * 2;
      lVar6 = lVar6 + 1;
    } while (*(short *)(lVar5 + 2 + lVar1) != 0);
    param_2 = 0;
  }
  else {
    switch(iVar2) {
    case 0x21:
    case 0x41:
    case 0x4d:
    case 0x81:
    case 0x8a:
    case 0x92:
    case 0x95:
    case 0x96:
    case 0x9f:
    case 0xa2:
    case 0xa4:
    case 0xb3:
    case 0xb9:
    case 0xcb:
    case 0xcc:
    case 0xdd:
    case 0xe2:
    case 0xed:
    case 0xf1:
    case 0x100:
    case 0x101:
    case 0x108:
    case 0x10b:
    case 0x11a:
      goto LAB_;
    case 0x22:
    case 0x86:
    case 0x8d:
      lVar6 = *(longlong *)(**(longlong **)(param_1 + 0x20) + 0x10);
      if ((*(short *)(lVar6 + 0x28) != -1) &&
         (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar6 + 0x18) + 0x134f770) + 0x1e2cf18
                   ) == '\0')) {
        return;
      }
      if (cRam0000000001e11992 != '\0') {
        return;
      }
      lVar6 = -1;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
      } while (*(short *)(lVar5 + 2 + lVar1) != 0);
      param_2 = 0xb;
      break;
    default:
      goto LAB_;
    case 0x7c:
      goto LAB_;
    case 0x7d:
    case 0x91:
    case 0x9b:
    case 0xff:
    case 0x10f:
code_r0x001002a3:
      if (cRam0000000001e11b18 != '\0') {
        return;
      }
      lVar6 = -1;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
      } while (*(short *)(lVar5 + 2 + lVar1) != 0);
      break;
    case 0xe4:
    case 0xe9:
code_r0x00100226:
      if (cRam0000000001e1198e != '\0') {
        if (iVar2 != 0xe4) {
          return;
        }
        if (*(int *)(param_1 + 0x18) < 2) {
          return;
        }
        func_0x(0x8a,2,param_3);
        return;
      }
      lVar6 = -1;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
      } while (*(short *)(lVar5 + 2 + lVar1) != 0);
      break;
    case 0xf0:
code_r0x00100114:
      lVar6 = *(longlong *)(**(longlong **)(param_1 + 0x20) + 0x10);
      if ((*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar6 + 0x18) + 0x134f770) +
                    0x13848c0) != '\0') &&
         (cVar4 = (*pcRam00000000011f7b80)(*(undefined4 *)(lVar6 + 0x2c)), cVar4 != '\0')) {
        uVar7 = CONCAT44(uVar8,0x8a91);
        (*pcRam00000000011f6b20)(0x7b,0x38,0x10,0x9a,uVar7);
        uVar8 = (undefined4)((ulonglong)uVar7 >> 0x20);
      }
      if (((*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar6 + 0x18) + 0x134f770) +
                     0x1384898) != '\0') &&
          (cVar4 = (*pcRam00000000011f7dd0)(*(undefined4 *)(lVar6 + 0x2c)), cVar4 != '\0')) &&
         (*(char *)(lRam00000000011f7090 + 0x37) == '\0')) {
        uVar7 = 0x17679c8;
        if (*(int *)(plVar3[8] + 0xc) == 0xf0) {
          uVar7 = 0x17679c0;
        }
        (*pcRam00000000011f6b20)(0x7b,0x36,0x10,0x6b,uVar7,0x8a91);
        uVar8 = (undefined4)((ulonglong)uVar7 >> 0x20);
      }
      if ((*(short *)(lVar6 + 0x28) != -1) &&
         (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar6 + 0x18) + 0x134f770) + 0x1e2cf18
                   ) == '\0')) {
        return;
      }
      if (cRam0000000001e11992 != '\0') {
        return;
      }
      lVar6 = -1;
      do {
        lVar1 = lVar6 * 2;
        lVar6 = lVar6 + 1;
      } while (*(short *)(lVar5 + 2 + lVar1) != 0);
      param_2 = 0xb;
    }
  }
LAB_:
  func_0x(0x5c,param_2,lVar5,(int)lVar6 * 2,CONCAT44(uVar8,param_3));
LAB_:
  return;
}

