
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2)

{
  longlong *plVar1;
  longlong lVar2;
  char cVar3;
  ushort uVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  longlong lVar10;
  longlong unaff_GS_OFFSET;
  ushort auStack_58 [2];
  undefined4 uStack_54;
  longlong lStack_50;
  longlong lStack_48;
  longlong lStack_40;
  uint uStack_38;
  
  uStack_54 = 1;
  auStack_58[0] = 0x16;
  lVar10 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  if ((lVar10 == 0) || (*(longlong *)(lVar10 + 0x110) != lVar10)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lStack_50 = *(longlong *)(lVar10 + 0x100);
  if (lStack_50 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lStack_48 = *(longlong *)(lStack_50 + 0x3e0);
  lStack_40 = 0;
  uStack_38 = 0;
  if (((*_DAT_ & 1) != 0) && (lStack_48 != 0)) {
    uVar6 = (*_DAT_)();
    lStack_40 = (*_DAT_)(uVar6,*(undefined2 *)(lStack_48 + 0xa0));
  }
  uVar5 = uStack_54;
  uVar4 = auStack_58[0];
  uVar9 = (ulonglong)*_DAT_;
  if (0x3c < *_DAT_) {
    uVar9 = 0x3c;
  }
  if (lStack_40 != 0) {
    func_0x(lStack_40,auStack_58[0],uStack_54);
    uVar7 = (*_DAT_)(lStack_40);
    uVar8 = (*_DAT_)(lStack_40,uVar4,uVar5);
    if ((uVar7 != 0) && (uVar8 != 0)) {
      uVar8 = uVar7 / uVar8 >> 1;
      uVar7 = uVar9;
      if (uVar9 < uVar8) {
        uVar7 = uVar8;
      }
      uVar9 = uVar9 * 100;
      if (uVar7 < uVar9 * 100) {
        uVar9 = uVar7;
      }
    }
  }
  cVar3 = *_DAT_;
  lVar10 = *_DAT_;
  while( true ) {
    uVar7 = 0;
    if (cVar3 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (uVar9 != 0) {
      do {
        uVar7 = uVar7 + lVar10;
      } while (uVar7 < uVar9);
    }
    if (lStack_40 != 0) {
      plVar1 = (longlong *)(*(longlong *)(lStack_40 + 8) + 0x4d0);
      *plVar1 = *plVar1 + uVar7;
    }
    if (*(int *)param_1 == 0) {
      LOCK();
      lVar2 = *param_1;
      if (lVar2 == 0) {
        *param_1 = param_2;
      }
      UNLOCK();
      if (lVar2 == 0) {
        return;
      }
    }
    uStack_38 = uStack_38 + 1;
    if (lStack_40 != 0) {
      if ((short)uStack_54 != 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      plVar1 = (longlong *)((ulonglong)auStack_58[0] * 0x38 + 0x18 + *(longlong *)(lStack_40 + 8));
      *plVar1 = *plVar1 + 1;
    }
    (*_DAT_)(param_1,auStack_58);
    if ((uStack_38 & 0x1f) == 0) break;
    uVar9 = uVar9 * 2;
    if (2500000 < uVar9) {
      uVar9 = 2500000;
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

