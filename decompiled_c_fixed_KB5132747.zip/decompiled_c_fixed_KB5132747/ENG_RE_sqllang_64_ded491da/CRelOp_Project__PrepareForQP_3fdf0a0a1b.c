
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,longlong param_3)

{
  int iVar1;
  longlong lVar2;
  undefined8 uVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  uint uVar7;
  int iVar8;
  ulonglong uVar10;
  longlong lVar11;
  ulonglong uVar9;
  
  lVar2 = *(longlong *)(*(longlong *)(param_2 + 0x20) + 8);
  lVar11 = 0;
  if ((*(byte *)(param_1 + 0x30) & 1) == 0) {
    iVar1 = *(int *)(lVar2 + 0x18);
    uVar3 = *(undefined8 *)(param_3 + 0x160);
    puVar5 = (undefined8 *)(*_DAT_)(0x30,*(undefined8 *)(param_1 + 0x10),0x20ed770,0x1023,1)
    ;
    if (puVar5 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    puVar5[2] = uVar3;
    *(undefined *)(puVar5 + 3) = 0;
    *(undefined4 *)((longlong)puVar5 + 0x1c) = 0;
    iVar8 = 1;
    if (iVar1 != 0) {
      iVar8 = iVar1;
    }
    *(int *)(puVar5 + 4) = iVar8;
    puVar5[5] = 0;
    *puVar5 = 0x20d1c48;
    *(undefined4 *)(puVar5 + 1) = 1;
    *puVar5 = 0x2199030;
    *(undefined8 **)(param_1 + 0x28) = puVar5;
    if (0 < iVar1) {
      do {
        uVar3 = *(undefined8 *)
                 (*(longlong *)
                   (*(longlong *)(*(longlong *)(*(longlong *)(lVar2 + 0x20) + lVar11 * 8) + 0x10) +
                   0x40) + 0x58);
        lVar4 = *(longlong *)(param_1 + 0x28);
        uVar7 = *(uint *)(lVar4 + 0x20);
        if (*(longlong *)(lVar4 + 0x28) == 0) {
          uVar6 = func_0x(lVar4 + 0x10,uVar7);
          *(undefined8 *)(lVar4 + 0x28) = uVar6;
          *(uint *)(lVar4 + 0x20) = uVar7;
        }
        if (uVar7 <= *(uint *)(lVar4 + 0x1c)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *(undefined8 *)(*(longlong *)(lVar4 + 0x28) + (ulonglong)*(uint *)(lVar4 + 0x1c) * 8) =
             uVar3;
        *(int *)(lVar4 + 0x1c) = *(int *)(lVar4 + 0x1c) + 1;
        lVar11 = lVar11 + 1;
      } while (lVar11 < iVar1);
    }
  }
  uVar9 = 0;
  uVar10 = uVar9;
  if (0 < *(int *)(lVar2 + 0x18)) {
    do {
      if ((*(byte *)(*(longlong *)
                      (*(longlong *)(*(longlong *)(*(longlong *)(lVar2 + 0x20) + uVar10) + 0x10) +
                      0x40) + 0x88) & 2) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar7 = (int)uVar9 + 1;
      uVar9 = (ulonglong)uVar7;
      uVar10 = uVar10 + 8;
    } while ((int)uVar7 < *(int *)(lVar2 + 0x18));
  }
  *(undefined4 *)(lVar2 + 0x18) = 0;
  uVar3 = *(undefined8 *)(param_3 + 0x160);
  if ((*(byte *)(param_1 + 0x30) & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar5 = (undefined8 *)(*_DAT_)(0x20,uVar3,0x20ed770,0x1033,1);
  if (puVar5 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar6 = *(undefined8 *)(param_1 + 0x28);
  *puVar5 = 0x20d1c48;
  *(undefined4 *)(puVar5 + 1) = 1;
  *puVar5 = 0x2045500;
  puVar5[2] = uVar3;
  *puVar5 = 0x20090f8;
  *puVar5 = 0x2019220;
  puVar5[3] = uVar6;
  *(undefined8 **)(param_2 + 0x10) = puVar5;
  return;
}

