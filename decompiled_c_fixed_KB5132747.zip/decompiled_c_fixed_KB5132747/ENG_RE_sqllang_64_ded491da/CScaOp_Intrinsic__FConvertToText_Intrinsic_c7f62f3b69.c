
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00a7a73c) */
/* WARNING: Removing unreachable block (ram,0x00a7a6a6) */
/* WARNING: Removing unreachable block (ram,0x002f33e2) */
/* WARNING: Removing unreachable block (ram,0x00a7a777) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(undefined8 *param_1,longlong param_2,longlong param_3,longlong **param_4)

{
  short sVar1;
  undefined8 uVar2;
  short *psVar3;
  longlong lVar4;
  int *piVar5;
  longlong *plVar6;
  undefined auVar7 [16];
  bool bVar8;
  short *psVar9;
  bool bVar10;
  char cVar11;
  int iVar12;
  uint uVar13;
  undefined8 uVar14;
  longlong **pplVar15;
  ulonglong uVar16;
  longlong *plVar17;
  short **ppsVar18;
  ulonglong uVar19;
  uint uVar20;
  ulonglong uVar21;
  int iVar22;
  ulonglong uVar23;
  
  uVar2 = *param_1;
  uVar13 = *(uint *)(param_3 + 0x18);
  iVar12 = (**(code **)(**(longlong **)(param_3 + 0x10) + 0x18))();
  if (iVar12 == 0x58) {
    ppsVar18 = *(short ***)(*(longlong *)(param_3 + 0x10) + 0x40);
  }
  else {
    ppsVar18 = *(short ***)(*(longlong *)(param_3 + 0x10) + 0x50);
  }
  if ((*(uint *)(param_2 + 0x90) & 0x202) == 0) {
    bVar10 = false;
LAB_:
    bVar8 = false;
  }
  else {
    bVar10 = true;
    bVar8 = true;
    if ((*(uint *)(ppsVar18 + 2) >> 0x13 & 1) == 0) goto LAB_;
  }
  if ((*(uint *)(param_2 + 0x90) >> 5 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar21 = 0;
  uVar20 = 0;
  if (*(int *)((longlong)ppsVar18 + 0xc) - 0x30U < 0xf) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)((longlong)ppsVar18 + 0xc) == 0x43) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar19 = CONCAT44(0,uVar13);
  auVar7._8_8_ = 0;
  auVar7._0_8_ = uVar19;
  uVar14 = SUB168(ZEXT816(8) * auVar7,0);
  if (SUB168(ZEXT816(8) * auVar7,8) != 0) {
    uVar14 = 0xffffffffffffffff;
  }
  pplVar15 = (longlong **)(*_DAT_)(uVar14,uVar2,0x20da430,0x1c9b,3);
  func_0x(pplVar15,0);
  psVar3 = *ppsVar18;
  if (*(int *)((longlong)ppsVar18 + 0xc) == 0x1a7) {
    lVar4 = **(longlong **)(param_3 + 0x20);
    uVar19 = func_0x();
    if (uVar19 < 0x34e20) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    plVar17 = *(longlong **)(lVar4 + 0x10);
    cVar11 = (**(code **)(*plVar17 + 0x1b8))(plVar17,param_1,param_2,lVar4,pplVar15,0);
    if (cVar11 != '\0') {
      lVar4 = *(longlong *)(*(longlong *)(param_3 + 0x20) + 8);
      uVar19 = func_0x();
      if (uVar19 < 0x34e20) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      plVar17 = *(longlong **)(lVar4 + 0x10);
      cVar11 = (**(code **)(*plVar17 + 0x1b8))(plVar17,param_1,param_2,lVar4,pplVar15 + 1,0);
      if (cVar11 != '\0') {
        if ((((2 < uVar13) &&
             (lVar4 = *(longlong *)(*(longlong *)(param_3 + 0x20) + 0x10), lVar4 != 0)) &&
            (iVar12 = (**(code **)(**(longlong **)(lVar4 + 0x10) + 0x18))(), iVar12 == 0x62)) &&
           ((*(char *)(*(longlong *)(*(longlong *)(*(longlong *)(param_3 + 0x20) + 0x10) + 0x10) +
                      0x40) + 1U & 0xfb) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (*(int *)(param_2 + 0x8c) - 3U < 5) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        piVar5 = *(int **)(param_2 + 200);
        if (*piVar5 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        plVar17 = *(longlong **)(piVar5 + 4);
        *piVar5 = *piVar5 + -1;
        *(longlong **)(piVar5 + 4) = plVar17 + 3;
        *plVar17 = 0;
        plVar17[1] = 0;
        *(undefined4 *)(plVar17 + 2) = 0;
        *param_4 = plVar17;
        plVar6 = *pplVar15;
        if (*plVar17 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *plVar17 = *plVar6;
        plVar17[1] = plVar6[1];
        *(int *)(plVar17 + 2) = *(int *)(plVar17 + 2) + *(int *)(plVar6 + 2);
        func_0x(*param_4,uVar2,0x2022e98,1);
        sVar1 = *psVar3;
        psVar9 = psVar3;
        while (sVar1 != 0) {
          psVar9 = psVar9 + 1;
          uVar20 = (int)uVar21 + 1;
          uVar21 = (ulonglong)uVar20;
          sVar1 = *psVar9;
        }
        func_0x(*param_4,uVar2,psVar3,uVar20);
        func_0x(*param_4,uVar2,0x2022e98,1);
        plVar17 = *param_4;
        plVar6 = pplVar15[1];
        if (*plVar17 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *(longlong *)(plVar17[1] + 0x10) = *plVar6;
        plVar17[1] = plVar6[1];
        uVar13 = *(uint *)(plVar6 + 2);
        *(uint *)(plVar17 + 2) = *(int *)(plVar17 + 2) + uVar13;
        goto LAB_;
      }
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)((longlong)ppsVar18 + 0xc) == 0xa3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (!bVar10) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(uint *)(param_2 + 0x90) >> 9 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar23 = uVar21;
  if (uVar13 != 0) {
    do {
      iVar22 = (int)uVar23;
      iVar12 = *(int *)((longlong)ppsVar18 + 0xc);
      if (iVar22 == 0) {
        if (iVar12 == 0xdd) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (iVar12 - 0x96U < 0x32) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (iVar12 == 0x240) {
          return;
        }
      }
      else if ((iVar22 == 1) && (iVar12 == 0x217)) {
        if (*(int *)(*(longlong *)(*(longlong *)(*(longlong *)(param_3 + 0x20) + 8) + 0x10) + 0x48)
            - 1U < 4) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (!bVar8) {
        lVar4 = *(longlong *)(*(longlong *)(param_3 + 0x20) + (longlong)iVar22 * 8);
        uVar16 = func_0x();
        if (uVar16 < 0x34e20) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        plVar17 = *(longlong **)(lVar4 + 0x10);
        cVar11 = (**(code **)(*plVar17 + 0x1b8))(plVar17,param_1,param_2,lVar4,pplVar15 + uVar23,0);
        if (cVar11 == '\0') {
          return;
        }
      }
      uVar23 = (ulonglong)(iVar22 + 1U);
    } while (iVar22 + 1U < uVar13);
  }
  piVar5 = *(int **)(param_2 + 200);
  if (*piVar5 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  plVar17 = *(longlong **)(piVar5 + 4);
  *piVar5 = *piVar5 + -1;
  *(longlong **)(piVar5 + 4) = plVar17 + 3;
  *plVar17 = 0;
  plVar17[1] = 0;
  *(undefined4 *)(plVar17 + 2) = 0;
  *param_4 = plVar17;
  if ((*(uint *)(ppsVar18 + 2) >> 0x11 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  sVar1 = *psVar3;
  psVar9 = psVar3;
  while (sVar1 != 0) {
    psVar9 = psVar9 + 1;
    uVar20 = (int)uVar21 + 1;
    uVar21 = (ulonglong)uVar20;
    sVar1 = *psVar9;
  }
  func_0x(*param_4,uVar2,psVar3,uVar20);
  if (*psVar3 == 0x40) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  func_0x(*param_4,uVar2,0x2022924,1);
  if (*(int *)((longlong)ppsVar18 + 0xc) == 0x59) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)((longlong)ppsVar18 + 0xc) == 0x221) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  bVar8 = false;
  if (uVar13 != 0) {
    do {
      plVar17 = *pplVar15;
      if ((plVar17 != (longlong *)0x0) && (*(int *)(plVar17 + 2) != 0)) {
        if (bVar8) {
          func_0x(*param_4,uVar2,0x20dc644,1);
          plVar17 = *pplVar15;
        }
        plVar6 = *param_4;
        if (*plVar6 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *(longlong *)(plVar6[1] + 0x10) = *plVar17;
        plVar6[1] = plVar17[1];
        *(int *)(plVar6 + 2) = *(int *)(plVar6 + 2) + *(int *)(plVar17 + 2);
        bVar8 = true;
      }
      pplVar15 = pplVar15 + 1;
      uVar19 = uVar19 - 1;
    } while (uVar19 != 0);
  }
  func_0x(*param_4,uVar2,0x2022920,1);
  uVar13 = *(uint *)(ppsVar18 + 2) >> 0x11;
  if ((uVar13 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
LAB_:
  return CONCAT71((uint7)(uint3)(uVar13 >> 8),1);
}

