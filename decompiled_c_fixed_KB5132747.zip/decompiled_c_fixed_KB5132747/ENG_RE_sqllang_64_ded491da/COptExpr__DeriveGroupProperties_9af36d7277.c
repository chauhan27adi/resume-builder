
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1,undefined8 param_2,undefined param_3,char param_4)

{
  char cVar1;
  ulonglong uVar2;
  uint *puVar3;
  longlong *plVar4;
  
  uVar2 = func_0x();
  if (uVar2 < 0x18000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar3 = (uint *)func_0x(0x2bc1740);
  *puVar3 = *puVar3 + 1;
  if (*puVar3 < 10) {
    if (*(longlong *)(param_1 + 0x50) == 0) {
      plVar4 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x10) + 0x1e8))
                         (*(longlong **)(param_1 + 0x10),param_2);
      *(longlong **)(param_1 + 0x50) = plVar4;
      if (param_4 != '\0') {
        (**(code **)(*plVar4 + 0xa8))(plVar4);
      }
    }
    cVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x40))
                      (*(longlong **)(param_1 + 0x50),param_3);
    if (cVar1 == '\0') {
      return;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

