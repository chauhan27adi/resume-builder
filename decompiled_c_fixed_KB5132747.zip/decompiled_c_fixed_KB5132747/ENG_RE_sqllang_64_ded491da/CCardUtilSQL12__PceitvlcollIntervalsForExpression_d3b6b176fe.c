
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x0180d9fc) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_(undefined8 param_1,longlong param_2,longlong param_3,undefined8 param_4,
                     longlong param_5,undefined *param_6)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong lVar6;
  uint uVar7;
  ulonglong uVar8;
  uint uVar9;
  ulonglong uVar10;
  longlong unaff_GS_OFFSET;
  uint uStackX_8;
  undefined8 uStackX_10;
  undefined8 uStackX_18;
  undefined8 uStackX_20;
  longlong lStack_108;
  undefined8 uStack_100;
  undefined4 uStack_f8;
  undefined8 uStack_f0;
  undefined uStack_e8;
  uint uStack_e4;
  uint uStack_e0;
  longlong lStack_d8;
  undefined8 *puStack_d0;
  longlong *plStack_c8;
  undefined8 uStack_c0;
  undefined8 uStack_b8;
  undefined4 uStack_b0;
  undefined8 uStack_a8;
  undefined uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_90;
  longlong lStack_88;
  undefined8 uStack_80;
  longlong lStack_78;
  undefined8 uStack_70;
  longlong lStack_68;
  undefined auStack_60 [32];
  
  uStack_70 = 0xfffffffffffffffe;
  uStackX_10 = (undefined8 *)param_2;
  uStackX_20 = param_4;
  plStack_c8 = (longlong *)(**(code **)(**(longlong **)(param_2 + 0x108) + 0xa8))();
  puStack_d0 = &uStack_a8;
  uStack_a0 = 0;
  uVar8 = 0;
  uStack_9c = 0;
  uStack_98 = 1;
  uStack_90 = 0;
  uStack_b0 = 1;
  uStack_b8 = 0x1f5e2a8;
  uStack_a8 = param_1;
  func_0x(&uStack_a8,&uStackX_10);
  uStackX_18 = CONCAT44(uStackX_18._4_4_,0x1123);
  lStack_108 = (*_DAT_)(0x68,param_1,0x202f6e0,0x1123,1);
  if (lStack_108 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar4 = func_0x(lStack_108,param_1);
  uStackX_10 = &uStack_f0;
  uStack_e8 = 0;
  uStack_e4 = 0;
  uStack_e0 = 1;
  if (*(uint *)(param_3 + 0x18) != 0) {
    uStack_e0 = *(uint *)(param_3 + 0x18);
  }
  lStack_d8 = 0;
  uStack_f8 = 1;
  uStack_100 = 0x1f5dc70;
  plVar5 = *(longlong **)(param_3 + 0x10);
  uStack_f0 = param_1;
  puStack_d0 = (undefined8 *)param_3;
  iVar3 = (**(code **)(*plVar5 + 0x18))(plVar5);
  if ((iVar3 != 0x59) || (*(int *)(plVar5 + 8) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar10 = uVar8;
  if (*(int *)(param_3 + 0x18) < 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  do {
    if (lStack_d8 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (uStack_e0 <= uStack_e4) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined8 *)(lStack_d8 + (ulonglong)uStack_e4 * 8) =
         *(undefined8 *)(uVar8 + *(longlong *)(param_3 + 0x20));
    uVar7 = uStack_e4 + 1;
    uVar9 = (int)uVar10 + 1;
    uVar8 = uVar8 + 8;
    uVar10 = (ulonglong)uVar9;
    uStack_e4 = uVar7;
  } while ((int)uVar9 < *(int *)(param_3 + 0x18));
  uVar10 = 0;
  uStackX_10 = (undefined8 *)CONCAT44(uStackX_10._4_4_,uVar7);
  uVar8 = uVar10;
  if (uVar7 != 0) {
    do {
      if (uStack_e4 <= (uint)uVar10) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      plVar5 = *(longlong **)(*(longlong *)(uVar8 + lStack_d8) + 0x10);
      lStack_108 = 0;
      uStackX_18 = 0;
      iVar3 = (**(code **)(*plVar5 + 0x510))
                        (plVar5,param_1,*(longlong *)(uVar8 + lStack_d8),&uStack_b8,&lStack_108,
                         &uStackX_18);
      if (iVar3 != 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      lStack_68 = (**(code **)(*plStack_c8 + 200))(plStack_c8,lStack_108);
      if (lStack_68 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      func_0x(lVar4,lStack_108,uStackX_18);
      if (uStackX_18 != 0) {
        piVar1 = (int *)(uStackX_18 + 8);
        *piVar1 = *piVar1 + -1;
        if (*piVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
      }
      uVar9 = (uint)uVar10 + 1;
      uVar10 = (ulonglong)uVar9;
      uVar8 = uVar8 + 8;
    } while (uVar9 < uVar7);
  }
  if ((param_5 != 0) && (lVar4 != -0x40)) {
    if (*(longlong *)(lVar4 + 0x58) != 0) {
      uStack_80 = 0;
      lVar6 = *(longlong *)
               (*(longlong *)
                 ((ulonglong)*_DAT_ +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8) +
               0x48);
      plVar5 = (longlong *)(lVar6 + 0x2b0);
      if (lVar6 == 0) {
        plVar5 = (longlong *)0x2b8;
      }
      lStack_78 = *plVar5;
      lStack_88 = *(longlong *)(lVar4 + 0x58);
    }
    while (((lVar4 != -0x40 && (*(longlong *)(lVar4 + 0x58) != 0)) &&
           (cVar2 = func_0x(), cVar2 != '\0'))) {
      uStackX_8 = (uint)param_1;
      if (*(uint *)(*(longlong *)(lStack_78 + 0x10) + 0xc) <= uStackX_8 >> 8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      plVar5 = *(longlong **)
                (*(longlong *)
                  (*(longlong *)(*(longlong *)(lStack_78 + 0x10) + 0x18) +
                  (ulonglong)(uStackX_8 >> 8) * 8) + (ulonglong)(uStackX_8 & 0xff) * 8);
      uStack_c0 = 0;
      plStack_c8 = plVar5;
      lVar6 = func_0x(lVar4 + 0x18,auStack_60,&plStack_c8);
      if (*(char *)(*(longlong *)(lVar6 + 8) + 0x20) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      lVar6 = *(longlong *)(*(longlong *)(lVar6 + 8) + 0x18);
      if (((lVar6 != 0) && (*(int *)(lVar6 + 0x1c) == 1)) &&
         (*(int *)(**(longlong **)(lVar6 + 0x28) + 0x18) == 2)) {
        func_0x(param_5,plVar5);
      }
    }
  }
  if (param_6 != (undefined *)0x0) {
    *param_6 = *(undefined *)(lVar4 + 0x60);
  }
  uStack_100 = 0x1f43d68;
  uStackX_10 = &uStack_f0;
  func_0x(&uStack_f0);
  if (lStack_d8 != 0) {
    (*_DAT_)();
    lStack_d8 = 0;
  }
  uStack_e0 = 0;
  uStack_b8 = 0x1f43d68;
  uStackX_10 = &uStack_a8;
  func_0x(&uStack_a8);
  return lVar4;
}

