
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8
FUN_(undefined8 param_1,longlong *param_2,longlong *param_3,longlong param_4,
            longlong param_5)

{
  undefined8 *puVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  longlong lVar5;
  undefined8 *puVar6;
  double dVar7;
  longlong lVar8;
  double adStack_c0 [2];
  undefined8 uStack_b0;
  undefined8 *puStack_a8;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined8 uStack_90;
  longlong *plStack_88;
  
  uStack_b0 = 0xfffffffffffffffe;
  if ((*(char *)(param_4 + 0x81) != '\0') ||
     (iVar4 = (**(code **)(*param_3 + 8))(param_3), iVar4 != 2)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar5 = (**(code **)(*param_3 + 0x10))(param_3);
  if (*(double *)(param_4 + 0x60) <= *(double *)(param_4 + 0x68) &&
      *(double *)(param_4 + 0x68) != *(double *)(param_4 + 0x60)) {
    param_4 = (**(code **)(*param_2 + 0xf8))(param_2,lVar5,0,0);
    if (param_4 == 0) goto LAB_;
  }
  else {
    *(int *)(param_4 + 8) = *(int *)(param_4 + 8) + 1;
  }
  if (*(double *)(param_4 + 0x60) == *(double *)(param_4 + 0x68)) {
    dVar7 = *(double *)(param_4 + 0x60) * _DAT_;
    if (_DAT_ < dVar7) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (dVar7 < _DAT_) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(double *)(param_4 + 0x58) <= dVar7) {
      uStack_98 = 1;
      uStack_a0 = 0x1f9d988;
      plStack_88 = (longlong *)0x0;
      lVar8 = param_4;
      uStack_90 = param_1;
      if (lVar5 != 0) {
        uVar3 = *(undefined4 *)(lVar5 + 8);
        puStack_a8 = (undefined8 *)(*_DAT_)(0x30,param_1,0x1f9ef90,0xe5,1);
        if (puStack_a8 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        plStack_88 = (longlong *)func_0x(puStack_a8);
        func_0x(plStack_88,uStack_90,uVar3);
      }
      puVar6 = (undefined8 *)(*_DAT_)(0x30,param_1,0x206f3f0,0x1652,1);
      if (puVar6 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *puVar6 = 0x1f83a78;
      *(undefined4 *)(puVar6 + 1) = 1;
      *puVar6 = 0x206f320;
      puVar6[2] = 0;
      puVar6[3] = 0;
      *(undefined4 *)(puVar6 + 4) = 0;
      puVar6[5] = param_1;
      puStack_a8 = puVar6;
      (**(code **)(*param_2 + 0x160))(param_2,adStack_c0,&uStack_a0,puVar6,0,0,lVar8);
      if ((0.0 < adStack_c0[0]) && (*(double *)(param_5 + 0x68) < adStack_c0[0])) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (puVar6 != (undefined8 *)0x0) {
        puVar1 = puVar6 + 1;
        *(int *)puVar1 = *(int *)puVar1 + -1;
        if (*(int *)puVar1 == 0) {
          (**(code **)*puVar6)(puVar6,1);
        }
      }
      uStack_a0 = 0x1f9d988;
      if (plStack_88 != (longlong *)0x0) {
        if (*plStack_88 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        (*_DAT_)(plStack_88,0x30);
      }
    }
  }
LAB_:
  if (param_4 != 0) {
    piVar2 = (int *)(param_4 + 8);
    *piVar2 = *piVar2 + -1;
    if (*piVar2 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  return 0;
}

