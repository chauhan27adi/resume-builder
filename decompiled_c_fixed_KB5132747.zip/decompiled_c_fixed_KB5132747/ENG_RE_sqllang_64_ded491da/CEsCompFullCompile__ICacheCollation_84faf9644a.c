
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_(longlong param_1,undefined8 param_2,byte *param_3,int param_4)

{
  int *piVar1;
  ulonglong uVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong unaff_GS_OFFSET;
  
  piVar1 = (int *)(*_DAT_)(*(undefined2 *)
                                    (*(longlong *)
                                      (*(longlong *)
                                        ((ulonglong)*_DAT_ +
                                        *(longlong *)
                                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                         (ulonglong)*_DAT_ * 8)) + 0x50) + 8));
  if (*(int *)(param_3 + 0x14) != *piVar1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_4 == 0) {
    uVar4 = 0;
    uVar2 = (ulonglong)
            (*(char *)((ulonglong)*(byte *)((ulonglong)*param_3 + 0x2005fa0) + 0x203b0c8) != '\0');
    if (*(longlong *)(*(longlong *)(param_1 + 0x88) + uVar2 * 8) == 0) {
      lVar3 = (*_DAT_)(0x80,param_2,0x2055a18,0x125a,2);
      if (lVar3 != 0) {
        uVar4 = (*_DAT_)(lVar3);
      }
      (*_DAT_)(param_3,uVar4);
      *(undefined8 *)(*(longlong *)(param_1 + 0x88) + uVar2 * 8) = uVar4;
    }
    return uVar2;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

