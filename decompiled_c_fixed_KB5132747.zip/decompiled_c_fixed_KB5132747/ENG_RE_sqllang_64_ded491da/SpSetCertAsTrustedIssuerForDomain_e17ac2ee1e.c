
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,ulonglong **param_2,longlong param_3,longlong param_4)

{
  ulonglong uVar1;
  byte *pbVar2;
  undefined4 *puVar3;
  undefined auVar4 [16];
  byte bVar5;
  undefined4 **ppuVar6;
  char cVar7;
  char cVar8;
  int iVar9;
  uint uVar10;
  undefined4 uVar11;
  undefined8 uVar12;
  longlong *plVar13;
  longlong *plVar14;
  longlong lVar15;
  undefined8 *puVar16;
  uint uVar17;
  longlong lVar18;
  longlong lVar19;
  longlong unaff_GS_OFFSET;
  undefined auStack_6a8 [32];
  undefined8 uStack_688;
  undefined8 uStack_680;
  undefined8 uStack_678;
  undefined4 *puStack_670;
  undefined8 uStack_668;
  undefined4 *puStack_660;
  undefined8 uStack_658;
  ulonglong uStack_650;
  undefined8 uStack_648;
  undefined4 uStack_640;
  byte bStack_638;
  byte abStack_634 [4];
  undefined8 uStack_630;
  undefined4 uStack_628;
  undefined8 uStack_620;
  undefined4 uStack_618;
  undefined auStack_610 [16];
  undefined auStack_600 [16];
  undefined4 uStack_5f0;
  char *pcStack_5e8;
  longlong lStack_5e0;
  undefined uStack_5d8;
  undefined8 uStack_5d0;
  longlong *plStack_5c8;
  undefined4 uStack_5b8;
  undefined4 uStack_5b4;
  undefined4 uStack_5b0;
  undefined4 uStack_5ac;
  undefined auStack_5a8 [24];
  undefined8 uStack_590;
  int aiStack_580 [6];
  longlong lStack_568;
  undefined auStack_558 [24];
  longlong lStack_540;
  undefined auStack_528 [8];
  undefined4 uStack_520;
  undefined4 uStack_518;
  undefined4 **ppuStack_510;
  undefined *puStack_508;
  undefined8 uStack_500;
  undefined4 *puStack_4f8;
  undefined4 uStack_4f0;
  undefined4 uStack_4ec;
  undefined8 uStack_4e8;
  undefined4 uStack_4e0;
  undefined4 uStack_4dc;
  undefined auStack_4d8 [512];
  undefined8 uStack_2d8;
  undefined8 uStack_2d0;
  undefined4 auStack_2c8 [4];
  char acStack_2b8 [8];
  longlong lStack_2b0;
  undefined4 uStack_2a8;
  undefined8 uStack_2a0;
  short asStack_88 [32];
  ulonglong uStack_48;
  
  uStack_5d0 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_6a8;
  uStack_628 = 0;
  *(undefined4 *)(param_4 + 8) = 1;
  uVar1 = **param_2;
  uVar17 = (uint)*(ushort *)(*param_2 + 1);
  if ((param_3 == 0) ||
     (iVar9 = *(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28),
     *(int *)(param_3 + 0x1c) == *(int *)(param_3 + 0x28))) {
    puStack_670 = (undefined4 *)0x14dc658;
    uStack_678 = CONCAT44(uStack_678._4_4_,0x1a);
  }
  else {
    if (iVar9 != 1) {
      if (2 < iVar9) {
        *(undefined4 *)(param_4 + 8) = 0x1fd0;
        uStack_688 = CONCAT44(uStack_688._4_4_,uVar17);
        uStack_680 = uVar1;
        (*_DAT_)(0x51,0x2c,0x10,1);
      }
      goto LAB_;
    }
    puStack_670 = (undefined4 *)0x14dc648;
    uStack_678 = CONCAT44(uStack_678._4_4_,0xe);
  }
  *(undefined4 *)(param_4 + 8) = 0xc9;
  uStack_688 = CONCAT44(uStack_688._4_4_,uVar17);
  uStack_680 = uVar1;
  (*_DAT_)(2,1,0x10,1);
LAB_:
  lVar15 = *(longlong *)(*(longlong *)(param_3 + 0x10) + (longlong)*(int *)(param_3 + 0x28) * 8);
  if (**(char **)(lVar15 + 0x18) == '8') {
    if (**(char **)(lVar15 + 8) == '\x03') {
      uStack_678 = 0x14dc708;
      uStack_680 = CONCAT44(uStack_680._4_4_,0x1c);
      uStack_688 = 0x1081498;
      (*_DAT_)(2,0x19,0x10,1);
    }
  }
  else {
    uStack_680 = (*_DAT_)(CONCAT71((int7)(int3)((uint)*(int *)(param_3 + 0x28) >> 8),0x38));
    uStack_688 = 0x14dc708;
    (*_DAT_)(2,0xe,0x10,0xd4);
  }
  lVar19 = *(longlong *)(*(longlong *)(param_3 + 0x10) + 8 + (longlong)*(int *)(param_3 + 0x28) * 8)
  ;
  if (**(char **)(lVar19 + 0x18) == -0x19) {
    if (**(char **)(lVar19 + 8) == '\x03') {
      uStack_678 = 0x14dc6f0;
      uStack_680 = CONCAT44(uStack_680._4_4_,0x10);
      uStack_688 = 0x1081498;
      (*_DAT_)(2,0x19,0x10,1);
    }
  }
  else {
    uStack_680 = (*_DAT_)(0x14dc6e7);
    uStack_688 = 0x14dc6f0;
    (*_DAT_)(2,0xe,0x10,0xd4);
  }
  pbVar2 = *(byte **)(lVar19 + 0x18);
  if ((*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar2 + 0x1090f60) + 0x10df720) != '\0') &&
     (*(short *)(pbVar2 + 0x10) == -1)) {
    uStack_680 = (*_DAT_)(CONCAT71((int7)((ulonglong)pbVar2 >> 8),0xe7));
    uStack_688 = 0x14dc6f0;
    (*_DAT_)(2,0xe,0x10,2);
  }
  puVar3 = *(undefined4 **)(*(longlong *)(lVar19 + 8) + 8);
  uVar17 = *(uint *)(*(longlong *)(lVar19 + 8) + 0x10);
  if (0x1fa < (uVar17 & 0xfffffffe)) {
    *(undefined4 *)(param_4 + 8) = 0x3b2f;
    (*_DAT_)(0x176,0x33,0x10,1);
  }
  uStack_620 = 0;
  uVar1 = **param_2;
  uStack_630 = (undefined *)CONCAT44(uStack_630._4_4_,(uint)*(ushort *)(*param_2 + 1));
  uStack_618 = 1;
  auStack_610._0_8_ =
       *(longlong **)
        (*(longlong *)
          ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
        0x90);
  auStack_610._8_8_ = 0;
  cVar8 = *(char *)(*(longlong *)
                     ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
                   0x98);
  cVar7 = (**(code **)(*(longlong *)auStack_610._0_8_ + 0x1d0))();
  if (cVar7 == '\0') {
    uStack_668 = CONCAT44(uStack_668._4_4_,(uint)(cVar8 != '\0'));
    puStack_670 = (undefined4 *)0x0;
    uStack_678 = uStack_678 & 0xffffffffffffff00;
    uStack_680 = CONCAT44(uStack_680._4_4_,1);
    uStack_688 = CONCAT44(uStack_688._4_4_,2);
    (**(code **)(*(longlong *)auStack_610._0_8_ + 8))
              (auStack_610._0_8_,uVar1,(ulonglong)uStack_630 & 0xffffffff,1);
    uStack_620 = CONCAT44(uStack_620._4_4_,1);
  }
  else {
    if ((cVar8 != '\0') &&
       (cVar8 = (**(code **)(*(longlong *)auStack_610._0_8_ + 0x1e8))(), cVar8 != '\0')) {
      uStack_688 = 0;
      (*_DAT_)(1,0x15928c0,0x15814a8,0xeb);
    }
    (**(code **)(*(longlong *)auStack_610._0_8_ + 0xe8))
              (auStack_610._0_8_,2,1,(longlong)&uStack_620 + 4);
    uStack_618 = 1;
    uStack_620 = CONCAT44(uStack_620._4_4_,3);
  }
  uVar12 = (**(code **)(*(longlong *)auStack_610._0_8_ + 0x1b0))();
  lVar18 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar19 = *(longlong *)(lVar18 + 0x100);
  if (lVar19 == 0) {
    (*_DAT_)();
    lVar19 = *(longlong *)(lVar18 + 0x100);
  }
  plVar13 = (longlong *)(**_DAT_)(*(undefined8 *)(lVar19 + 1000),uVar12,0x14dc4e0,0xba0);
  uVar10 = (uint)*(ushort *)
                  (*(longlong *)
                    (*(longlong *)
                      ((ulonglong)*_DAT_ +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
                    0x50) + 8);
  uStack_630 = (undefined *)CONCAT44(uStack_630._4_4_,uVar10);
  uStack_680 = uStack_680 & 0xffffffff00000000;
  uStack_688 = uStack_688 & 0xffffffff00000000;
  plStack_5c8 = plVar13;
  plVar14 = (longlong *)(**(code **)(*plVar13 + 0x38))(plVar13,uVar10,0,0);
  plVar14 = (longlong *)
            (**(code **)(*plVar14 + 0x328))
                      (plVar14,*(undefined4 *)(*(longlong *)(lVar15 + 8) + 8),1);
  if (plVar14 == (longlong *)0x0) {
    asStack_88[0] = 0;
    func_0x
              (asStack_88,0x20,0x10cce50,*(undefined4 *)(*(longlong *)(lVar15 + 8) + 8));
    *(undefined4 *)(param_4 + 8) = 0x3b2f;
    lVar15 = -1;
    do {
      lVar15 = lVar15 + 1;
    } while (asStack_88[lVar15] != 0);
    uStack_678 = lVar15 * 2;
    puStack_670 = (undefined4 *)asStack_88;
    uStack_680 = CONCAT44(uStack_680._4_4_,0x8ac9);
    uStack_688 = CONCAT44(uStack_688._4_4_,0x333e);
    (*_DAT_)(0x97,0x33,0x10,1);
  }
  lVar19 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar15 = *(longlong *)(lVar19 + 0x100);
  if (lVar15 == 0) {
    (*_DAT_)(0);
    lVar15 = *(longlong *)(lVar19 + 0x100);
  }
  uVar12 = *(undefined8 *)(lVar15 + 1000);
  uVar11 = (**(code **)(*plVar14 + 8))();
  uStack_650 = 0;
  uStack_658 = 0;
  puStack_660 = (undefined4 *)((ulonglong)puStack_660 & 0xffffffffffffff00);
  uStack_668 = CONCAT71(uStack_668._1_7_,1);
  puStack_670 = (undefined4 *)((ulonglong)puStack_670 & 0xffffffff00000000);
  uStack_678 = CONCAT44(uStack_678._4_4_,0xffffffff);
  uStack_680 = uStack_680 & 0xffffffff00000000;
  uStack_688 = CONCAT44(uStack_688._4_4_,uVar11);
  cVar8 = func_0x(0x4c414358,uVar12,plVar13,(ulonglong)uStack_630 & 0xffffffff);
  bStack_638 = cVar8 != '\0';
  uStack_5b8 = _DAT_;
  uStack_5b4 = uRam0000000000f5ea14;
  uStack_5b0 = uRam0000000000f5ea18;
  uStack_5ac = uRam0000000000f5ea1c;
  lVar19 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar15 = *(longlong *)(lVar19 + 0x100);
  if (lVar15 == 0) {
    (*_DAT_)(0);
    lVar15 = *(longlong *)(lVar19 + 0x100);
  }
  bVar5 = bStack_638;
  uVar12 = *(undefined8 *)(lVar15 + 1000);
  uVar11 = (**(code **)(*plVar14 + 8))();
  uStack_640 = 0xffffffff;
  uStack_648 = 0;
  uStack_650 = uStack_650 & 0xffffffff00000000;
  uStack_658 = 0;
  puStack_660 = &uStack_5b8;
  uStack_668 = 0;
  puStack_670 = (undefined4 *)0x0;
  uStack_678 = uStack_678 & 0xffffffff00000000;
  uStack_680 = CONCAT44(uStack_680._4_4_,(uint)bVar5);
  uStack_688 = CONCAT44(uStack_688._4_4_,uVar11);
  func_0x(0x4c414358,uVar12,plVar13,(ulonglong)uStack_630 & 0xffffffff);
  if (bStack_638 == 0) {
    (*_DAT_)(0x98,0x2f,0x10,0x6a);
  }
  if ((_DAT_ & 0x1000000) != 0) {
    uStack_520 = 0x20000;
    uStack_518 = 0;
    ppuStack_510 = &puStack_4f8;
    puStack_508 = auStack_4d8;
    uStack_2d8 = 0;
    uStack_500 = 0;
    uStack_2d0 = 0;
    puStack_4f8 = auStack_2c8;
    uStack_4f0 = 0xc;
    uStack_4ec = 1;
    uStack_4e8 = 0;
    uStack_4e0 = 0;
    uStack_4dc = 1;
    auStack_2c8[0] = (**(code **)(*plVar14 + 8))(plVar14);
    ppuVar6 = ppuStack_510;
    ppuStack_510[2] = puVar3;
    *(uint *)(ppuVar6 + 3) = uVar17 & 0xfffffffe;
    *(undefined4 *)((longlong)ppuVar6 + 0x1c) = 1;
    func_0x(auStack_528);
  }
  cVar8 = (**(code **)(*plVar14 + 0xc0))(plVar14,puVar3,uVar17);
  if (cVar8 == '\0') {
    acStack_2b8[0] = '\x01';
    lStack_2b0 = 0;
    uStack_2a8 = 0;
    uStack_2a0 = 0;
    uStack_688 = 0;
    func_0x(acStack_2b8,auStack_558,3,0xf0000040);
    uStack_628 = 0;
    if (lStack_540 != 0) {
      (*_DAT_)();
    }
    auStack_600 = ZEXT816(0);
    uStack_5f0 = 0;
    pcStack_5e8 = acStack_2b8;
    lStack_5e0 = 0;
    uStack_5d8 = 0;
    lVar19 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar15 = *(longlong *)(lVar19 + 0x100);
    if (lVar15 == 0) {
      (*_DAT_)(0);
      lVar15 = *(longlong *)(lVar19 + 0x100);
    }
    func_0x(auStack_600,aiStack_580,*(undefined8 *)(lVar15 + 1000),plVar14);
    if (aiStack_580[0] != 0) {
      uStack_590 = 0;
      uStack_630 = auStack_5a8;
      func_0x(auStack_5a8,aiStack_580);
      func_0x(auStack_5a8,0);
    }
    if (lStack_568 != 0) {
      (*_DAT_)();
    }
    iVar9 = func_0x(lStack_5e0,0,0,0);
    if (iVar9 != 0) {
      func_0x(0x9249,10,1);
    }
    iVar9 = (*_DAT_)(0x10001,*(undefined8 *)(lStack_5e0 + 0x18),abStack_634,2);
    if ((iVar9 != 0) && ((abStack_634[0] & 4) == 0)) {
      *(undefined4 *)(param_4 + 8) = 0x3b2e;
      puVar16 = (undefined8 *)(**(code **)*plVar14)(plVar14);
      lVar15 = (**(code **)*plVar14)(plVar14);
      uStack_680 = *puVar16;
      uStack_688 = CONCAT44(uStack_688._4_4_,*(undefined4 *)(lVar15 + 8));
      (*_DAT_)(0x176,0x32,0x10,1);
    }
    (**(code **)(*plVar14 + 0xa0))(plVar14,puVar3,uVar17);
    if (lStack_5e0 != 0) {
      (*_DAT_)();
      lStack_5e0 = 0;
    }
    if (auStack_600._0_8_ != 0) {
      (*_DAT_)(auStack_600._0_8_,0);
      auVar4._8_8_ = 0;
      auVar4._0_8_ = auStack_600._8_8_;
      auStack_600 = auVar4 << 0x40;
    }
    if ((lStack_2b0 != 0) && (acStack_2b8[0] != '\0')) {
      (*_DAT_)(lStack_2b0,0);
    }
    lStack_2b0 = 0;
    uStack_2a8 = 0;
  }
  else {
    puVar16 = (undefined8 *)(**(code **)*plVar14)(plVar14);
    lVar15 = (**(code **)*plVar14)(plVar14);
    uStack_678 = CONCAT44(uStack_678._4_4_,uVar17);
    uStack_680 = *puVar16;
    uStack_688 = CONCAT44(uStack_688._4_4_,*(undefined4 *)(lVar15 + 8));
    puStack_670 = puVar3;
    (*_DAT_)(0x176,0x2f,0x10,1);
  }
  (**(code **)*plVar13)(plVar13,1);
  func_0x(&uStack_620,0);
  *(undefined4 *)(param_4 + 8) = 0;
  if ((int)uStack_620 != 0) {
    func_0x(&uStack_620,0);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_6a8);
  return;
}

