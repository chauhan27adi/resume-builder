
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_(longlong param_1,int *param_2)

{
  undefined2 uVar1;
  undefined auVar2 [16];
  undefined8 uVar3;
  int iVar4;
  longlong lVar5;
  longlong lVar6;
  int iVar7;
  int iVar8;
  longlong unaff_GS_OFFSET;
  undefined8 uVar9;
  
  uVar9 = 0xfffffffffffffffe;
  iVar7 = 0;
  iVar8 = (int)((ulonglong)(longlong)*param_2 >> 1);
  if (0 < iVar8) {
    lVar6 = 0;
    do {
      switch(*(undefined2 *)(param_1 + lVar6 * 2)) {
      case 7:
      case 8:
      case 9:
      case 10:
      case 0xb:
      case 0xc:
      case 0xd:
      case 0x22:
      case 0x27:
        iVar7 = iVar7 + 1;
      }
      lVar6 = lVar6 + 1;
    } while (lVar6 < iVar8);
    if (iVar7 != 0) {
      iVar7 = (iVar8 + iVar7) * 2;
      lVar5 = (ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar6 = *(longlong *)(lVar5 + 0x100);
      if (lVar6 == 0) {
        (*_DAT_)(0);
        lVar6 = *(longlong *)(lVar5 + 0x100);
      }
      auVar2._8_8_ = 0;
      auVar2._0_8_ = (ulonglong)(longlong)iVar7 >> 1;
      uVar3 = SUB168(ZEXT816(2) * auVar2,0);
      if (SUB168(ZEXT816(2) * auVar2,8) != 0) {
        uVar3 = 0xffffffffffffffff;
      }
      lVar6 = (*_DAT_)(uVar3,*(undefined8 *)(lVar6 + 1000),1,0x19ea438,0x1e72,3,uVar9);
      iVar4 = 0;
      lVar5 = 0;
      do {
        uVar1 = *(undefined2 *)(param_1 + lVar5 * 2);
        switch(uVar1) {
        case 7:
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x5c;
          iVar4 = iVar4 + 1;
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x61;
          break;
        case 8:
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x5c;
          iVar4 = iVar4 + 1;
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x62;
          break;
        case 9:
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x5c;
          iVar4 = iVar4 + 1;
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x74;
          break;
        case 10:
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x5c;
          iVar4 = iVar4 + 1;
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x6e;
          break;
        case 0xb:
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x5c;
          iVar4 = iVar4 + 1;
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x76;
          break;
        case 0xc:
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x5c;
          iVar4 = iVar4 + 1;
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x66;
          break;
        case 0xd:
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x5c;
          iVar4 = iVar4 + 1;
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x72;
          break;
        default:
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = uVar1;
          break;
        case 0x22:
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x5c;
          iVar4 = iVar4 + 1;
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x22;
          break;
        case 0x27:
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x5c;
          iVar4 = iVar4 + 1;
          *(undefined2 *)(lVar6 + (longlong)iVar4 * 2) = 0x27;
        }
        lVar5 = lVar5 + 1;
        iVar4 = iVar4 + 1;
      } while (lVar5 < iVar8);
      *param_2 = iVar7;
      (*_DAT_)(0,2);
      return lVar6;
    }
  }
  return 0;
}

