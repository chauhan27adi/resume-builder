
void FUN_(longlong *param_1,uint param_2)

{
  double dVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  uint uVar6;
  longlong lVar7;
  bool bVar8;
  bool bVar9;
  
  lVar7 = *param_1;
  lVar2 = *(longlong *)(lVar7 + (ulonglong)param_2 * 8);
  if (1 < param_2) {
    lVar3 = *(longlong *)(lVar2 + 0x10);
    lVar4 = *(longlong *)(*(longlong *)(lVar7 + (ulonglong)(param_2 >> 1) * 8) + 0x10);
    bVar9 = SBORROW8(lVar3,lVar4);
    lVar5 = lVar3 - lVar4;
    bVar8 = lVar3 == lVar4;
    uVar6 = param_2;
    while ((bVar9 != lVar5 < 0 ||
           ((param_2 = uVar6, bVar8 &&
            (dVar1 = *(double *)(*(longlong *)(lVar7 + (ulonglong)(uVar6 >> 1) * 8) + 8),
            *(double *)(lVar2 + 8) <= dVar1 && dVar1 != *(double *)(lVar2 + 8)))))) {
      *(undefined8 *)(lVar7 + (ulonglong)uVar6 * 8) =
           *(undefined8 *)(lVar7 + (ulonglong)(uVar6 >> 1) * 8);
      *(uint *)(*(longlong *)((ulonglong)uVar6 * 8 + *param_1) + 0x18) = uVar6;
      lVar7 = *param_1;
      param_2 = uVar6 >> 1;
      if (param_2 < 2) break;
      lVar5 = *(longlong *)(*(longlong *)(lVar7 + (ulonglong)(uVar6 >> 2) * 8) + 0x10);
      bVar9 = SBORROW8(*(longlong *)(lVar2 + 0x10),lVar5);
      lVar5 = *(longlong *)(lVar2 + 0x10) - lVar5;
      bVar8 = lVar5 == 0;
      uVar6 = param_2;
    }
  }
  *(longlong *)(lVar7 + (ulonglong)param_2 * 8) = lVar2;
  *(uint *)(*(longlong *)(*param_1 + (ulonglong)param_2 * 8) + 0x18) = param_2;
  return;
}

