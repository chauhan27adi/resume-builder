
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2,longlong param_3)

{
  longlong *plVar1;
  undefined8 uVar2;
  char cVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined8 uVar6;
  undefined4 uVar7;
  longlong unaff_GS_OFFSET;
  
  if ((((*(byte *)(param_1 + 2) & 1) == 0) && (*param_1 == 0)) && (*param_1 = param_3, param_3 == 0)
     ) {
    cVar3 = (**(code **)(*(longlong *)(*(longlong *)(param_2 + 0x80) + 0x150) + 0x78))
                      (*(longlong *)(param_2 + 0x80) + 0x150);
    if (cVar3 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar5 = *(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             0x100);
    if (lVar5 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    puVar4 = (undefined8 *)(*_DAT_)(0x20,*(undefined8 *)(lVar5 + 1000),0x205edc8,0x3ee4,3);
    if (puVar4 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *puVar4 = 0;
    *(undefined4 *)(puVar4 + 1) = 1;
    puVar4[2] = 0;
    puVar4[3] = 0;
    param_1[1] = (longlong)puVar4;
    *(undefined4 *)(puVar4 + 1) = 1;
    plVar1 = *(longlong **)
              (*(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                ) + 0x90);
    puVar4[2] = plVar1;
    cVar3 = (**(code **)(*plVar1 + 0x1d0))();
    plVar1 = (longlong *)puVar4[2];
    if (cVar3 == '\0') {
      uVar7 = 2;
      (**(code **)(*plVar1 + 8))(plVar1,0x20794a0,0x26,1,1,2,0,0,0);
    }
    else {
      (**(code **)(*plVar1 + 0xe8))(plVar1,1,1,(longlong)puVar4 + 4);
      *(undefined4 *)(puVar4 + 1) = 1;
      uVar7 = 4;
    }
    *(undefined4 *)puVar4 = uVar7;
    *(byte *)(param_1 + 2) = *(byte *)(param_1 + 2) | 1;
    lVar5 = (*_DAT_)();
    if (*(char *)(lVar5 + 0x2ee4) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar5 = *(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             0x100);
    if (lVar5 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar2 = *(undefined8 *)(lVar5 + 1000);
    uVar6 = (**(code **)(**(longlong **)(param_2 + 0x90) + 0x1b0))(*(longlong **)(param_2 + 0x90));
    lVar5 = (**_DAT_)(uVar2,uVar6,0x205edc8,0x3ef4);
    *(byte *)(param_1 + 2) = *(byte *)(param_1 + 2) | 2;
    *param_1 = lVar5;
    if ((*(uint *)(*(longlong *)(param_2 + 0x80) + 0x50) >> 0xf & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  return;
}

