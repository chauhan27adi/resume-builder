
/* WARNING: Control flow encountered bad instruction data */

ulonglong FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                      undefined8 param_5)

{
  longlong *plVar1;
  ulonglong uVar2;
  undefined8 uStackX_10;
  
  uStackX_10 = param_2;
  plVar1 = (longlong *)func_0x(*(undefined8 *)(param_1 + 0x50),&uStackX_10);
  if (plVar1 == (longlong *)0x0) {
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(*(longlong *)(param_1 + 0x48) + 0x108) + 0xa8))();
    uVar2 = (**(code **)(*plVar1 + 0xe0))(plVar1,param_2,param_3,param_4,param_5);
  }
  else {
    uVar2 = (**(code **)(*plVar1 + 0x28))(plVar1,param_5);
    if ((char)uVar2 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar2 = uVar2 & 0xffffffffffffff00;
  }
  return uVar2;
}

