
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_(undefined8 *param_1,undefined8 param_2,longlong param_3,longlong *param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  bool bVar7;
  bool bVar8;
  bool bVar9;
  char cVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  undefined4 uVar14;
  longlong lVar15;
  longlong lVar16;
  longlong *plVar17;
  longlong *plVar18;
  undefined4 *puVar19;
  longlong *plVar20;
  longlong *plVar21;
  longlong *plVar22;
  longlong unaff_GS_OFFSET;
  longlong *plStack_98;
  undefined4 auStack_90 [2];
  undefined auStack_88 [16];
  undefined4 uStack_78;
  undefined4 auStack_70 [2];
  undefined auStack_68 [16];
  undefined4 uStack_58;
  undefined8 uStack_50;
  
  uStack_50 = 0xfffffffffffffffe;
  *param_1 = 0xde07c8;
  plVar18 = (longlong *)0x0;
  param_1[1] = 0;
  param_1[2] = 0;
  *(undefined2 *)(param_1 + 3) = 0;
  *(undefined (*) [16])(param_1 + 4) = ZEXT816(0);
  *(undefined (*) [16])(param_1 + 6) = ZEXT816(0);
  *(undefined4 *)((longlong)param_1 + 0x24) = 0;
  param_1[5] = 0xffffffffffffffff;
  *(undefined4 *)(param_1 + 6) = 0;
  param_1[7] = 0;
  uVar14 = *(undefined4 *)(*(longlong *)(param_3 + 0x10) + 0x40);
  plVar17 = **(longlong ***)(param_3 + 0x20);
  plVar20 = (*(longlong ***)(param_3 + 0x20))[1];
  plVar22 = (longlong *)plVar17[2];
  plVar1 = (longlong *)plVar20[2];
  iVar11 = (**(code **)(*plVar22 + 0x18))(plVar22);
  iVar12 = (**(code **)(*plVar1 + 0x18))(plVar1);
  bVar8 = false;
  plStack_98 = (longlong *)0x0;
  bVar7 = false;
  bVar9 = false;
  plVar21 = plVar18;
  if (iVar11 == 99) {
    plVar21 = (longlong *)plVar22[8];
    if ((plVar21 != (longlong *)0x0) &&
       ((*(char *)((longlong)plVar21 + 0xc) == 'E' || (*(char *)((longlong)plVar21 + 0xc) == '1'))))
    {
      cVar10 = (**(code **)(*plVar21 + 0x220))(plVar21);
      bVar9 = true;
      if (cVar10 != '\0') goto LAB_;
    }
    bVar9 = false;
  }
LAB_:
  plVar22 = plVar18;
  if ((((iVar12 == 99) && (plVar22 = (longlong *)plVar1[8], plVar22 != (longlong *)0x0)) &&
      ((*(char *)((longlong)plVar22 + 0xc) == 'E' || (*(char *)((longlong)plVar22 + 0xc) == '1'))))
     && (cVar10 = (**(code **)(*plVar22 + 0x220))(plVar22), cVar10 != '\0')) {
    bVar7 = true;
  }
  lVar15 = (**(code **)(*param_4 + 0x160))(param_4);
  if ((*(byte *)(lVar15 + 0xd2) & 1) != 0) {
    if (plVar22 == (longlong *)0x0) {
      lVar15 = (**(code **)(*param_4 + 0x160))(param_4);
      plVar1 = (longlong *)plVar20[2];
      iVar13 = (**(code **)(*plVar1 + 0x18))(plVar1);
      if (iVar13 == 0x60) {
        plVar2 = *(longlong **)(*(longlong *)plVar20[4] + 0x10);
        iVar13 = (**(code **)(*plVar2 + 0x18))(plVar2);
        if ((iVar13 == 99) && (cVar10 = (*_DAT_)(plVar2 + 3,plVar1 + 3), cVar10 != '\0')) {
          plVar1 = (longlong *)plVar2[8];
          lVar16 = (**(code **)(*plVar1 + 0x160))(plVar1);
          if (lVar16 == lVar15) {
            plVar22 = plVar1;
          }
        }
      }
    }
    if (plVar21 == (longlong *)0x0) {
      lVar15 = (**(code **)(*param_4 + 0x160))(param_4);
      plVar1 = (longlong *)plVar17[2];
      iVar13 = (**(code **)(*plVar1 + 0x18))(plVar1);
      if (iVar13 == 0x60) {
        plVar2 = *(longlong **)(*(longlong *)plVar17[4] + 0x10);
        iVar13 = (**(code **)(*plVar2 + 0x18))(plVar2);
        if ((iVar13 == 99) && (cVar10 = (*_DAT_)(plVar2 + 3,plVar1 + 3), cVar10 != '\0')) {
          plVar1 = (longlong *)plVar2[8];
          lVar16 = (**(code **)(*plVar1 + 0x160))(plVar1);
          if (lVar16 == lVar15) {
            plVar21 = plVar1;
          }
        }
      }
    }
  }
  if ((plVar21 == param_4) &&
     ((iVar12 == 0x62 ||
      (((plVar22 != (longlong *)0x0 && (*(char *)((longlong)plVar22 + 0xc) == '1')) || (bVar7))))))
  {
    plStack_98 = plVar21;
    if (bVar7) {
      auStack_90[0] = 3;
      auStack_88 = ZEXT816(0);
      uStack_78 = 0;
      (**(code **)(*plVar22 + 0x228))(plVar22,auStack_90);
      plVar17 = (longlong *)(*_DAT_)(0xa8,param_2,0xde0798,0x69,1);
      if (plVar17 != (longlong *)0x0) {
        lVar15 = (*_DAT_)(0x70,param_2,0xde0798,0x69,1);
        if (lVar15 != 0) {
          puVar3 = *(undefined8 **)
                    (*(longlong *)
                      (*(longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
                      0x80) + 0x108);
          if (puVar3[2] == 0) {
            (**(code **)*puVar3)(puVar3);
          }
          (**(code **)*plVar22)(plVar22);
          plVar18 = (longlong *)func_0x(lVar15,param_2);
        }
        *plVar17 = 0x982348;
        *(undefined4 *)(plVar17 + 1) = 1;
        *plVar17 = 0x99c208;
        plVar17[0xc] = 0;
        plVar17[0xd] = 0;
        plVar17[0xe] = 0;
        plVar17[0xf] = 0;
        plVar17[0x11] = _DAT_;
        plVar17[0x12] = 0;
        plVar17[0x13] = 0;
        plVar17[0x14] = 0;
        *(undefined4 *)(plVar17 + 3) = 0;
        plVar17[4] = 0;
        plVar17[5] = 0;
        plVar17[2] = (longlong)plVar18;
        plVar17[10] = 0;
        plVar17[0xb] = 0;
        plVar17[0x10] = 0;
        plVar18 = plVar17;
      }
      bVar8 = true;
      plVar20 = plVar18;
    }
  }
  else {
    plVar20 = plVar18;
    if ((plVar22 == param_4) &&
       (((iVar11 == 0x62 ||
         ((plVar21 != (longlong *)0x0 && (*(char *)((longlong)plVar21 + 0xc) == '1')))) || (bVar9)))
       ) {
      plStack_98 = plVar22;
      if (bVar9) {
        auStack_70[0] = 3;
        auStack_68 = ZEXT816(0);
        uStack_58 = 0;
        (**(code **)(*plVar21 + 0x228))(plVar21,auStack_70);
        plVar17 = (longlong *)(*_DAT_)(0xa8,param_2,0xde0798,0x80,1);
        if (plVar17 != (longlong *)0x0) {
          lVar15 = (*_DAT_)(0x70,param_2,0xde0798,0x80,1);
          if (lVar15 != 0) {
            puVar3 = *(undefined8 **)
                      (*(longlong *)
                        (*(longlong *)
                          ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
                        + 0x80) + 0x108);
            if (puVar3[2] == 0) {
              (**(code **)*puVar3)(puVar3);
            }
            (**(code **)*plVar21)(plVar21);
            plVar18 = (longlong *)func_0x(lVar15,param_2);
          }
          *plVar17 = 0x982348;
          *(undefined4 *)(plVar17 + 1) = 1;
          *plVar17 = 0x99c208;
          plVar17[0xc] = 0;
          plVar17[0xd] = 0;
          plVar17[0xe] = 0;
          plVar17[0xf] = 0;
          plVar17[0x11] = _DAT_;
          plVar17[0x12] = 0;
          plVar17[0x13] = 0;
          plVar17[0x14] = 0;
          *(undefined4 *)(plVar17 + 3) = 0;
          plVar17[4] = 0;
          plVar17[5] = 0;
          plVar17[2] = (longlong)plVar18;
          plVar17[10] = 0;
          plVar17[0xb] = 0;
          plVar17[0x10] = 0;
          plVar18 = plVar17;
        }
        bVar8 = true;
        uVar14 = func_0x(uVar14);
        plVar20 = plVar18;
      }
      else {
        uVar14 = func_0x(uVar14);
        plVar20 = plVar17;
      }
    }
  }
  puVar19 = (undefined4 *)(**(code **)*plStack_98)(plStack_98);
  uVar4 = puVar19[1];
  uVar5 = puVar19[2];
  uVar6 = puVar19[3];
  *(undefined4 *)(param_1 + 4) = *puVar19;
  *(undefined4 *)((longlong)param_1 + 0x24) = uVar4;
  *(undefined4 *)(param_1 + 5) = uVar5;
  *(undefined4 *)((longlong)param_1 + 0x2c) = uVar6;
  uVar4 = puVar19[5];
  uVar5 = puVar19[6];
  uVar6 = puVar19[7];
  *(undefined4 *)(param_1 + 6) = puVar19[4];
  *(undefined4 *)((longlong)param_1 + 0x34) = uVar4;
  *(undefined4 *)(param_1 + 7) = uVar5;
  *(undefined4 *)((longlong)param_1 + 0x3c) = uVar6;
  if (!bVar8) {
    *(int *)(plVar20 + 1) = *(int *)(plVar20 + 1) + 1;
  }
  switch(uVar14) {
  case 1:
    *(undefined *)(param_1 + 3) = 1;
    break;
  case 2:
  case 0x42:
  case 0xc0:
    param_1[1] = plVar20;
    *(int *)(plVar20 + 1) = *(int *)(plVar20 + 1) + 1;
  case 3:
    *(undefined2 *)(param_1 + 3) = 0x101;
    break;
  case 4:
    param_1[1] = plVar20;
    *(undefined *)((longlong)param_1 + 0x19) = 1;
    return param_1;
  default:
    goto LAB_;
  case 6:
    param_1[1] = plVar20;
    *(undefined2 *)(param_1 + 3) = 0x101;
    return param_1;
  case 0x25:
    param_1[1] = plVar20;
    *(int *)(plVar20 + 1) = *(int *)(plVar20 + 1) + 1;
    *(undefined2 *)(param_1 + 3) = 0;
  }
  param_1[2] = plVar20;
LAB_:
  return param_1;
}

