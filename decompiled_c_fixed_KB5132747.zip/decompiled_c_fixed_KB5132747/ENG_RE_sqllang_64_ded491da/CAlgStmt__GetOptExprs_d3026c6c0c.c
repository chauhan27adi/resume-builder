
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_(longlong param_1,uint *param_2,undefined8 param_3)

{
  undefined auVar1 [16];
  undefined8 uVar2;
  longlong lVar3;
  
  lVar3 = 0;
  *param_2 = 0;
  if (*(longlong *)(param_1 + 0x18) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(longlong *)(param_1 + 0x10) != 0) || (*(longlong *)(param_1 + 0xf0) != 0)) {
    auVar1 = ZEXT816(8) * ZEXT416(*param_2 + 2);
    uVar2 = auVar1._0_8_;
    if (auVar1._8_8_ != 0) {
      uVar2 = 0xffffffffffffffff;
    }
    lVar3 = (*_DAT_)(uVar2,param_3,0x1e1d4d8,0xe2,3);
    if (*param_2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    (*_DAT_)(0);
    *(undefined8 *)(lVar3 + (ulonglong)*param_2 * 8) = *(undefined8 *)(param_1 + 0x10);
    *param_2 = *param_2 + 1;
    *(undefined8 *)(lVar3 + (ulonglong)*param_2 * 8) = *(undefined8 *)(param_1 + 0xf0);
    *param_2 = *param_2 + 1;
  }
  return lVar3;
}

