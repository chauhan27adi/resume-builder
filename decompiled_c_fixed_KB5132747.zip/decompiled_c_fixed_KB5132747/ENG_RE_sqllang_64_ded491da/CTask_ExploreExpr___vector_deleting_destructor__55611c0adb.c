
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_(undefined8 *param_1,uint param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  int *piVar2;
  undefined8 *puVar3;
  
  *param_1 = 0x208a3a8;
  if ((*(char *)(param_1 + 7) != '\0') &&
     (puVar3 = (undefined8 *)param_1[6], puVar3 != (undefined8 *)0x0)) {
    puVar1 = puVar3 + 1;
    *(int *)puVar1 = *(int *)puVar1 + -1;
    if (*(int *)puVar1 == 0) {
      (**(code **)*puVar3)(puVar3,1,param_3,param_4,0xfffffffffffffffe);
    }
  }
  *param_1 = 0x215bf58;
  piVar2 = (int *)(param_1[2] + 8);
  *piVar2 = *piVar2 + -1;
  if (*piVar2 != 0) {
    if ((param_2 & 1) != 0) {
      (*_DAT_)(param_1,0x40);
    }
    return param_1;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

