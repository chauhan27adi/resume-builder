
/* WARNING: Control flow encountered bad instruction data */

ulonglong FUN_(longlong param_1,longlong param_2,longlong param_3,undefined8 param_4,
                      undefined8 param_5,undefined8 param_6,undefined8 param_7)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  ulonglong uVar4;
  uint *puVar5;
  longlong lVar6;
  
  if (*(int *)(param_3 + 0x2f8) < 100) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  plVar1 = *(longlong **)(param_2 + 0x10);
  iVar3 = (**(code **)(*plVar1 + 0x18))(plVar1);
  if ((iVar3 != 0x59) || (*(int *)(plVar1 + 8) != 0)) {
    iVar3 = (**(code **)(**(longlong **)(param_2 + 0x10) + 0x18))(*(longlong **)(param_2 + 0x10));
    if (iVar3 == 0x59) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar4 = (**(code **)(**(longlong **)(param_2 + 0x10) + 0x18))();
    if ((int)uVar4 != 100) {
      return uVar4 & 0xffffffffffffff00;
    }
  }
  if ((*(longlong *)(param_1 + 0x18) == 0) &&
     (iVar3 = (**(code **)(**(longlong **)(param_2 + 0x10) + 0x18))(*(longlong **)(param_2 + 0x10)),
     iVar3 == 0x59)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  cVar2 = func_0x(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  if (cVar2 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar3 = 0;
  if (0 < *(int *)(param_2 + 0x18)) {
    lVar6 = 0;
    do {
      puVar5 = (uint *)func_0x(0x2a817f0);
      *puVar5 = *puVar5 + 1;
      if (9 < *puVar5) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      cVar2 = FUN_(param_1,*(undefined8 *)(lVar6 + *(longlong *)(param_2 + 0x20)),param_3,
                           param_4,param_5,param_6,param_7);
      if (cVar2 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      iVar3 = iVar3 + 1;
      lVar6 = lVar6 + 8;
    } while (iVar3 < *(int *)(param_2 + 0x18));
  }
  return 0;
}

