
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00f8e436) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  int *piVar1;
  byte *pbVar2;
  longlong lVar3;
  code *pcVar4;
  int iVar5;
  longlong lVar6;
  longlong lVar7;
  longlong *plVar8;
  undefined8 unaff_RBX;
  undefined8 unaff_RBP;
  longlong unaff_GS_OFFSET;
  longlong alStackX_10 [3];
  undefined8 uStack_20;
  
  uStack_20 = 0x10000f;
  lVar6 = func_0x();
  lVar6 = -lVar6;
  *(undefined8 *)((longlong)alStackX_10 + lVar6) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00001260 + lVar6) = unaff_RBX;
  *(undefined8 *)(&stack0x00001268 + lVar6) = unaff_RBP;
  *(ulonglong *)(&stack0x00001228 + lVar6) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffe8 + lVar6);
  *(undefined8 *)((longlong)&uStack_20 + lVar6) = 0x100051;
  lVar7 = func_0x(0,0,0);
  *(longlong *)((longlong)alStackX_10 + lVar6 + 8) = lVar7;
  if (lVar7 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)((longlong)&uStack_20 + lVar6) = 0x100072;
  plVar8 = (longlong *)func_0x(lVar7,0,0,1);
  if (plVar8 == (longlong *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar3 = plVar8[4];
  *(undefined8 *)((longlong)&uStack_20 + lVar6) = 0x100092;
  func_0x(&stack0x00000028 + lVar6,plVar8,lVar7,lVar3);
  LOCK();
  *(int *)(lVar7 + 0x40) = *(int *)(lVar7 + 0x40) + 1;
  UNLOCK();
  LOCK();
  *(int *)(lVar7 + 8) = *(int *)(lVar7 + 8) + 1;
  UNLOCK();
  *param_1 = lVar7;
  if (*(char *)(_DAT_ + 0x1cc) < '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)((longlong)&uStack_20 + lVar6) = 0x1000b9;
  iVar5 = func_0x(0);
  if (iVar5 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  pbVar2 = (byte *)(*(longlong *)
                     (*(longlong *)
                       ((ulonglong)*_DAT_ +
                       *(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
                     0x48) + 0x10d);
  *pbVar2 = *pbVar2 | 1;
  *(undefined8 *)((longlong)&uStack_20 + lVar6) = 0x1000f8;
  func_0x(&stack0x00000028 + lVar6);
  if (*(char *)(_DAT_ + 0x1cc) < '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (plVar8 != (longlong *)0x0) {
    lVar3 = plVar8[3];
    pcVar4 = *(code **)(*(longlong *)(lVar3 + 0x50) + 0x20);
    *(undefined8 *)((longlong)&uStack_20 + lVar6) = 0x100136;
    (*pcVar4)((longlong *)(lVar3 + 0x50),plVar8,0,0);
    *(undefined8 *)((longlong)&uStack_20 + lVar6) = 0x10013e;
    func_0x(plVar8);
    pcVar4 = *(code **)(*plVar8 + 0x10);
    *(undefined8 *)((longlong)&uStack_20 + lVar6) = 0x100149;
    (*pcVar4)(plVar8,0);
  }
  if (lVar7 != 0) {
    LOCK();
    *(int *)(lVar7 + 0x40) = *(int *)(lVar7 + 0x40) + -1;
    UNLOCK();
    LOCK();
    piVar1 = (int *)(lVar7 + 8);
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  *(undefined8 *)((longlong)&uStack_20 + lVar6) = 0x100173;
  func_0x(*(ulonglong *)(&stack0x00001228 + lVar6) ^
                  (ulonglong)(&stack0xffffffffffffffe8 + lVar6));
  return;
}

