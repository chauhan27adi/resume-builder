
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00100486) */
/* WARNING: Removing unreachable block (ram,0x0150f87f) */
/* WARNING: Removing unreachable block (ram,0x001004a0) */
/* WARNING: Removing unreachable block (ram,0x0150f891) */
/* WARNING: Removing unreachable block (ram,0x001004ae) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  uint *puVar1;
  undefined8 **ppuVar2;
  undefined8 *puVar3;
  uint *puVar4;
  uint *puVar5;
  undefined8 **ppuVar6;
  int *piVar7;
  char cVar8;
  ulonglong uVar9;
  int iVar10;
  uint uVar11;
  undefined8 **ppuVar12;
  undefined8 *puVar13;
  bool bVar15;
  undefined8 **ppuVar16;
  ulonglong uVar17;
  int *piVar18;
  uint uVar19;
  undefined8 **ppuVar20;
  int iVar21;
  int iVar22;
  int iVar23;
  longlong lVar24;
  uint uVar25;
  longlong lVar26;
  ulonglong uVar27;
  undefined8 uVar28;
  undefined8 extraout_XMM0_Qa;
  undefined8 uVar29;
  undefined8 extraout_XMM0_Qa_00;
  undefined auStack_208 [32];
  uint uStack_1e8;
  undefined auStack_1e4 [4];
  undefined8 **ppuStack_1e0;
  undefined8 uStack_1d8;
  uint uStack_1d0;
  uint uStack_1cc;
  longlong lStack_1c8;
  longlong lStack_1c0;
  undefined8 **ppuStack_1b8;
  undefined8 uStack_1b0;
  longlong lStack_1a8;
  int *piStack_1a0;
  undefined4 uStack_198;
  undefined8 uStack_190;
  undefined8 *apuStack_188 [6];
  undefined8 uStack_158;
  undefined8 *apuStack_150 [6];
  undefined8 uStack_120;
  undefined8 *apuStack_118 [6];
  undefined8 uStack_e8;
  undefined8 *apuStack_e0 [6];
  undefined8 uStack_b0;
  undefined8 *apuStack_a8 [6];
  undefined8 uStack_78;
  longlong lStack_70;
  uint uStack_68;
  uint auStack_64 [9];
  undefined8 uStack_40;
  ulonglong uStack_38;
  ulonglong uVar14;
  
  uStack_190 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_208;
  lVar26 = *(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x18) + 0xa8) + 8);
  lStack_1c8 = *(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x40) + 0xa8) + 8);
  uVar29 = *(undefined8 *)(param_1 + 0x10);
  lStack_1c0 = param_1;
  lStack_1a8 = lVar26;
  func_0x(&lStack_70);
  uStack_1e8 = 0;
  uVar19 = *(uint *)(lVar26 + 0xc);
  uStack_40 = uVar29;
  if (uVar19 != 0) {
    do {
      uVar25 = uStack_1e8;
      uVar9 = 0;
      if (uVar19 <= uStack_1e8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      puVar4 = *(uint **)(*(longlong *)(lVar26 + 0x18) + (ulonglong)uStack_1e8 * 8);
      uVar29 = *(undefined8 *)(param_1 + 0x10);
      func_0x(apuStack_188);
      uVar28 = *(undefined8 *)(param_1 + 0x10);
      uStack_158 = uVar29;
      func_0x(apuStack_e0);
      uVar29 = *(undefined8 *)(param_1 + 0x10);
      uStack_b0 = uVar28;
      func_0x(apuStack_118);
      uStack_e8 = uVar29;
      func_0x(apuStack_118,uVar29,*puVar4);
      uVar19 = *(uint *)(lStack_1c8 + 0xc);
      if (uVar19 != 0) {
        do {
          uVar17 = 0;
          uVar11 = (uint)uVar9;
          if ((ulonglong)uStack_68 + 0x100 <= uVar9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((uVar11 < uStack_68) ||
             ((auStack_64[uVar11 - uStack_68 >> 5] & 1 << ((byte)(uVar11 - uStack_68) & 0x1f)) == 0)
             ) {
            if (uVar19 <= uVar11) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            puVar5 = *(uint **)(*(longlong *)(lStack_1c8 + 0x18) + uVar9 * 8);
            uVar29 = *(undefined8 *)(param_1 + 0x10);
            uVar28 = func_0x(apuStack_150);
            uVar14 = uVar17;
            uVar27 = uVar17;
            uStack_120 = uVar29;
            do {
              puVar13 = (undefined8 *)(*(longlong *)(puVar4 + 2) + uVar17 * 0x18);
              puVar3 = (undefined8 *)(*(longlong *)(puVar5 + 2) + uVar14 * 0x18);
              iVar22 = (int)((ulonglong)*puVar3 >> 0x20);
              iVar23 = (int)((ulonglong)*puVar13 >> 0x20);
              if (iVar23 != iVar22) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
              iVar10 = (int)*puVar3;
              iVar21 = (int)*puVar13;
              if (iVar21 != iVar10) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
              if (*(int *)(puVar13 + 1) != *(int *)(puVar3 + 1)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
              if ((ulonglong)puVar13[2] < (ulonglong)puVar3[2]) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
              if ((((iVar23 == iVar22) && (iVar21 == iVar10)) &&
                  (*(int *)(puVar13 + 1) == *(int *)(puVar3 + 1))) && (puVar13[2] == puVar3[2])) {
                uVar28 = func_0x(apuStack_150,uStack_120,uVar17);
                uVar27 = (ulonglong)((int)uVar27 + 1);
                uVar17 = (ulonglong)((int)uVar17 + 1);
              }
              param_1 = lStack_1c0;
              uVar19 = (int)uVar14 + 1;
              uVar14 = (ulonglong)uVar19;
            } while ((uVar19 < *puVar5) && ((uint)uVar17 < *puVar4));
            uVar29 = *(undefined8 *)(lStack_1c0 + 0x20);
            ppuStack_1b8 = apuStack_150;
            uStack_1b0 = 0;
            cVar8 = func_0x(uVar28,&ppuStack_1b8,&uStack_1d0);
            while (cVar8 != '\0') {
              uVar28 = func_0x(uVar29,uVar9,
                                       *(longlong *)(puVar4 + 2) + (ulonglong)uStack_1d0 * 0x18);
              cVar8 = func_0x(uVar28,&ppuStack_1b8,&uStack_1d0);
            }
            func_0x(apuStack_e0,uStack_b0,apuStack_150);
            if ((uint)uVar27 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            puVar13 = apuStack_150[0];
            if (*puVar5 != (uint)uVar27) goto joined_r0x00100710;
            func_0x(apuStack_188,uStack_158,uVar9);
            uVar19 = func_0x(apuStack_e0);
            puVar13 = apuStack_150[0];
            if (*puVar4 == uVar19) {
              uVar25 = uStack_1e8;
              if (apuStack_150[0] != (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
              break;
            }
            while (apuStack_150[0] = puVar13, puVar13 != (undefined8 *)0x0) {
              apuStack_150[0] = (undefined8 *)*puVar13;
              (*_DAT_)(puVar13,0x30);
              puVar13 = apuStack_150[0];
            }
          }
          uVar9 = (ulonglong)(uVar11 + 1);
          uVar19 = *(uint *)(lStack_1c8 + 0xc);
          uVar25 = uStack_1e8;
        } while (uVar11 + 1 < uVar19);
      }
      param_1 = lStack_1c0;
      ppuVar16 = apuStack_188;
      do {
        piVar18 = (int *)((longlong)ppuVar16 + 0xc);
        ppuVar12 = (undefined8 **)0x0;
        do {
          if (*piVar18 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          uVar19 = (int)ppuVar12 + 1;
          ppuVar12 = (undefined8 **)(ulonglong)uVar19;
          piVar18 = piVar18 + 1;
        } while (uVar19 < 8);
        ppuVar16 = (undefined8 **)*ppuVar16;
      } while (ppuVar16 != (undefined8 **)0x0);
      ppuVar16 = apuStack_e0;
      bVar15 = false;
      ppuVar12 = (undefined8 **)0x0;
      ppuVar20 = apuStack_118;
      do {
        if (ppuVar16 == (undefined8 **)0x0) break;
        if (*(uint *)(ppuVar16 + 1) < *(uint *)(ppuVar20 + 1)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((ppuVar16 != (undefined8 **)0x0) && (*(uint *)(ppuVar20 + 1) == *(uint *)(ppuVar16 + 1))
           ) {
          *(uint *)((longlong)ppuVar20 + 0xc) =
               *(uint *)((longlong)ppuVar20 + 0xc) & ~*(uint *)((longlong)ppuVar16 + 0xc);
          *(uint *)(ppuVar20 + 2) = *(uint *)(ppuVar20 + 2) & ~*(uint *)(ppuVar16 + 2);
          puVar5 = (uint *)((longlong)ppuVar20 + 0x14);
          *puVar5 = *puVar5 & ~*(uint *)((longlong)ppuVar16 + 0x14);
          ppuVar6 = ppuVar20 + 3;
          *(uint *)ppuVar6 = *(uint *)ppuVar6 & ~*(uint *)(ppuVar16 + 3);
          puVar1 = (uint *)((longlong)ppuVar20 + 0x1c);
          *puVar1 = *puVar1 & ~*(uint *)((longlong)ppuVar16 + 0x1c);
          ppuVar2 = ppuVar20 + 4;
          *(uint *)ppuVar2 = *(uint *)ppuVar2 & ~*(uint *)(ppuVar16 + 4);
          bVar15 = *(uint *)ppuVar2 != 0 ||
                   (*puVar1 != 0 ||
                   (*(uint *)ppuVar6 != 0 ||
                   (*puVar5 != 0 ||
                   (*(int *)(ppuVar20 + 2) != 0 || *(int *)((longlong)ppuVar20 + 0xc) != 0))));
          *(uint *)((longlong)ppuVar20 + 0x24) =
               *(uint *)((longlong)ppuVar20 + 0x24) & ~*(uint *)((longlong)ppuVar16 + 0x24);
          *(uint *)(ppuVar20 + 5) = *(uint *)(ppuVar20 + 5) & ~*(uint *)(ppuVar16 + 5);
          ppuVar16 = (undefined8 **)*ppuVar16;
        }
        if (ppuVar12 != (undefined8 **)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        ppuVar6 = (undefined8 **)*ppuVar20;
        ppuVar12 = ppuVar20;
        ppuVar20 = ppuVar6;
      } while (ppuVar6 != (undefined8 **)0x0);
      ppuStack_1e0 = apuStack_118;
      uStack_1d8 = 0;
      uVar29 = *(undefined8 *)(lStack_1c0 + 0x10);
      uVar28 = func_0x(apuStack_a8,bVar15);
      uStack_78 = uVar29;
      cVar8 = func_0x(uVar28,&ppuStack_1e0,&uStack_1cc);
      uVar29 = extraout_XMM0_Qa;
      if (cVar8 != '\0') {
LAB_:
        uVar9 = (ulonglong)uStack_1cc;
        piVar18 = (int *)(*(longlong *)(puVar4 + 2) + uVar9 * 0x18);
        lVar26 = *(longlong *)(param_1 + 0x40);
        lVar24 = *(longlong *)(*(longlong *)(lVar26 + 0xa8) + 0x18);
        uStack_198 = 0xffffffff;
        piStack_1a0 = piVar18;
        uVar19 = func_0x();
        puVar13 = *(undefined8 **)
                   (*(longlong *)(lVar24 + 0x10) +
                   ((ulonglong)uVar19 % (ulonglong)*(uint *)(lVar24 + 0xc)) * 8);
        do {
          if (puVar13 == (undefined8 *)0x0) goto LAB_;
          if (uVar19 == *(uint *)(puVar13 + 3)) {
            piVar7 = (int *)puVar13[1];
            if ((((piVar18[1] == piVar7[1]) && (*piVar18 == *piVar7)) && (piVar18[2] == piVar7[2]))
               && (*(longlong *)(piVar18 + 4) == *(longlong *)(piVar7 + 4))) goto code_r0x0010065c;
          }
          puVar13 = (undefined8 *)*puVar13;
        } while( true );
      }
LAB_:
      ppuStack_1e0 = apuStack_a8;
      uStack_1d8 = 0;
      cVar8 = func_0x(uVar29,&ppuStack_1e0,auStack_1e4);
      if (cVar8 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      func_0x(&lStack_70,uStack_40,apuStack_188);
      if (apuStack_a8[0] != (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (apuStack_118[0] != (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (apuStack_e0[0] != (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (apuStack_188[0] != (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uStack_1e8 = uVar25 + 1;
      uVar19 = *(uint *)(lStack_1a8 + 0xc);
      lVar26 = lStack_1a8;
    } while (uStack_1e8 < uVar19);
  }
  func_0x(&lStack_70);
LAB_:
  if (lStack_70 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_208);
  return;
joined_r0x00100710:
  while (puVar13 != (undefined8 *)0x0) {
    apuStack_150[0] = (undefined8 *)*puVar13;
    (*_DAT_)(puVar13,0x30);
    puVar13 = apuStack_150[0];
  }
  apuStack_150[0] = (undefined8 *)0x0;
  puVar13 = apuStack_118[0];
  while (puVar13 != (undefined8 *)0x0) {
    apuStack_118[0] = (undefined8 *)*puVar13;
    (*_DAT_)(puVar13,0x30);
    puVar13 = apuStack_118[0];
  }
  apuStack_118[0] = (undefined8 *)0x0;
  puVar13 = apuStack_e0[0];
  while (puVar13 != (undefined8 *)0x0) {
    apuStack_e0[0] = (undefined8 *)*puVar13;
    (*_DAT_)(puVar13,0x30);
    puVar13 = apuStack_e0[0];
  }
  apuStack_e0[0] = (undefined8 *)0x0;
  puVar13 = apuStack_188[0];
  while (apuStack_188[0] = puVar13, puVar13 != (undefined8 *)0x0) {
    apuStack_188[0] = (undefined8 *)*puVar13;
    (*_DAT_)(puVar13,0x30);
    puVar13 = apuStack_188[0];
  }
  goto LAB_;
code_r0x0010065c:
  if ((int **)(puVar13 + 1) != (int **)0x0) {
    uVar17 = puVar13[2];
    if ((int)uVar17 != -1) {
      lVar26 = *(longlong *)(lVar26 + 0x98);
      uVar19 = *(uint *)(lVar26 + 0x1c);
      if (uVar19 != 0) {
        uVar14 = 0;
        while (*(int *)(*(longlong *)(lVar26 + 0x28) + uVar14 * 4) != (int)uVar17) {
          uVar11 = (int)uVar14 + 1;
          uVar14 = (ulonglong)uVar11;
          if (uVar19 <= uVar11) goto LAB_;
        }
        if ((int)uVar14 != -1) {
          func_0x(apuStack_a8,uStack_78,uVar17 & 0xffffffff);
          param_1 = lStack_1c0;
          uVar29 = func_0x(*(undefined8 *)(lStack_1c0 + 0x20),uVar17 & 0xffffffff,
                                   *(longlong *)(puVar4 + 2) + uVar9 * 0x18);
          cVar8 = func_0x(uVar29,&ppuStack_1e0,&uStack_1cc);
          uVar29 = extraout_XMM0_Qa_00;
          if (cVar8 == '\0') goto LAB_;
          goto LAB_;
        }
      }
    }
  }
LAB_:
  if (apuStack_a8[0] != (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (apuStack_118[0] != (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar13 = apuStack_188[0];
  if (apuStack_e0[0] != (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  while (apuStack_188[0] = puVar13, puVar13 != (undefined8 *)0x0) {
    apuStack_188[0] = (undefined8 *)*puVar13;
    (*_DAT_)(puVar13,0x30);
    puVar13 = apuStack_188[0];
  }
  goto LAB_;
}

