
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong param_1)

{
  longlong lVar1;
  int iVar2;
  undefined8 uVar3;
  longlong unaff_GS_OFFSET;
  undefined8 auStackX_8 [4];
  
  if ((((*(byte *)(_DAT_ + 0x1f8) & 1) != 0) ||
      (((lVar1 = *(longlong *)
                  (*(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                  (ulonglong)*_DAT_), lVar1 != 0 &&
        (lVar1 = **(longlong **)(lVar1 + 0x38), lVar1 != 0)) &&
       (iVar2 = (*_DAT_)(lVar1,0xfc0), iVar2 != 0)))) ||
     (((*(byte *)(_DAT_ + 0x1fa) & 0x40) != 0 ||
      (((lVar1 = *(longlong *)
                  ((ulonglong)*_DAT_ +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
        lVar1 != 0 && (lVar1 = **(longlong **)(lVar1 + 0x38), lVar1 != 0)) &&
       (iVar2 = (*_DAT_)(lVar1,0xfd6), iVar2 != 0)))))) {
    func_0x(0x19adf50,(int)*(short *)(param_1 + 0x2ac));
  }
  uVar3 = _DAT_;
  if (*_DAT_ != 0) {
    (*_DAT_)(auStackX_8);
    uVar3 = auStackX_8[0];
  }
  *(undefined8 *)(param_1 + 0x2a0) = uVar3;
  func_0x(param_1,0x12);
  (**(code **)(**(longlong **)(param_1 + 0x1c8) + 0x30))(*(longlong **)(param_1 + 0x1c8),1);
  return 0;
}

