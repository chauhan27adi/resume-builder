
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,ulonglong param_3)

{
  undefined4 uVar1;
  longlong lVar2;
  longlong lVar3;
  
  if ((param_3 & 1) != 0) {
    if ((param_2 == 0) || (lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x360) + 0x18), lVar2 == 0)
       ) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    func_0x(lVar2,*(undefined4 *)(param_2 + 8));
    lVar2 = *(longlong *)(param_1 + 0x370);
    uVar1 = *(undefined4 *)(param_2 + 8);
    lVar3 = *(longlong *)(lVar2 + 0x18);
    if (lVar3 == 0) {
      lVar3 = (*_DAT_)(0x30,*(undefined8 *)(lVar2 + 0x10),0x1eacb30,0xe5,1);
      if (lVar3 != 0) {
        lVar3 = func_0x(lVar3);
      }
      *(longlong *)(lVar2 + 0x18) = lVar3;
    }
    func_0x(lVar3,*(undefined8 *)(lVar2 + 0x10),uVar1);
  }
  if ((param_3 & 2) == 0) {
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

