
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_(undefined8 *param_1,undefined8 param_2)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  undefined8 *puVar10;
  undefined8 *puVar11;
  undefined8 *puVar12;
  undefined4 extraout_XMM0_Da;
  longlong *plStackX_20;
  ulonglong in_stack_fffffffffffffef8;
  longlong *plStack_f8;
  undefined8 uStack_f0;
  longlong *plStack_e8;
  longlong *plStack_e0;
  undefined8 *puStack_d8;
  undefined8 *puStack_d0;
  undefined8 *puStack_c8;
  undefined8 *puStack_c0;
  undefined8 *puStack_b8;
  undefined8 uStack_b0;
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  int iStack_98;
  undefined auStack_90 [16];
  undefined8 uStack_80;
  int iStack_78;
  undefined auStack_70 [16];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  
  uStack_b0 = 0xfffffffffffffffe;
  uStack_f0 = *param_1;
  uStack_a8 = uStack_f0;
  func_0x(&plStackX_20,param_2,0x14e);
  uVar1 = func_0x(plStackX_20,0x18a,0xffffffff);
  puVar12 = (undefined8 *)0x0;
  puVar10 = puVar12;
  switch(uVar1) {
  case 0:
    puVar10 = (undefined8 *)0x13b0368;
    break;
  case 1:
  case 3:
  case 5:
  case 7:
  case 9:
  case 0xb:
  case 0x21:
  case 0x24:
  case 0x27:
  case 0x28:
  case 0x29:
    break;
  case 2:
    puVar10 = (undefined8 *)0x13b0338;
    break;
  case 4:
    puVar10 = (undefined8 *)0x13a87d8;
    break;
  case 6:
    puVar10 = (undefined8 *)0x13a8758;
    break;
  case 8:
    puVar10 = (undefined8 *)0x13a8740;
    break;
  case 10:
    puVar10 = (undefined8 *)0x13ac0b8;
    break;
  case 0xc:
    puVar10 = (undefined8 *)0x13a9a50;
    break;
  case 0xd:
    puVar10 = (undefined8 *)0x14327a8;
    break;
  case 0xe:
    puVar10 = (undefined8 *)0x1432b98;
    break;
  case 0xf:
    puVar10 = (undefined8 *)0x143e2d8;
    break;
  case 0x10:
    puVar10 = (undefined8 *)0x14330f8;
    break;
  case 0x11:
    puVar10 = (undefined8 *)0x14334b8;
    break;
  case 0x12:
    puVar10 = (undefined8 *)0x14366d8;
    break;
  case 0x13:
    puVar10 = (undefined8 *)0x1436ec0;
    break;
  case 0x14:
    puVar10 = (undefined8 *)0x14378e8;
    break;
  case 0x15:
    puVar10 = (undefined8 *)0x1438250;
    break;
  case 0x16:
    puVar10 = (undefined8 *)0x14383e8;
    break;
  case 0x17:
    puVar10 = (undefined8 *)0x1438520;
    break;
  case 0x18:
    puVar10 = (undefined8 *)0x143b8b0;
    break;
  case 0x19:
    puVar10 = (undefined8 *)0x143cdb0;
    break;
  case 0x1a:
    puVar10 = (undefined8 *)0x143c160;
    break;
  case 0x1b:
    puVar10 = (undefined8 *)0x143d890;
    break;
  case 0x1c:
    puVar10 = (undefined8 *)0x1390898;
    break;
  case 0x1d:
    puVar10 = (undefined8 *)0x1435130;
    break;
  case 0x1e:
    puVar10 = (undefined8 *)0x13b1138;
    break;
  case 0x1f:
    puVar10 = (undefined8 *)0x13b1150;
    break;
  case 0x20:
    puVar10 = (undefined8 *)0x1434798;
    break;
  case 0x22:
    puVar10 = (undefined8 *)0x1434d70;
    break;
  case 0x23:
    puVar10 = (undefined8 *)0x13a8710;
    break;
  case 0x25:
    puVar10 = (undefined8 *)0x143dcf0;
    break;
  case 0x26:
    puVar10 = (undefined8 *)0x13a8680;
    break;
  case 0x2a:
    puVar10 = (undefined8 *)0x1438698;
    break;
  case 0x2b:
    puVar10 = (undefined8 *)0x142fad8;
    break;
  case 0x2c:
    puVar10 = (undefined8 *)0x1430b28;
    break;
  case 0x2d:
    puVar10 = (undefined8 *)0x143e918;
    break;
  case 0x2e:
    puVar10 = (undefined8 *)0x143ed70;
    break;
  case 0x2f:
    puVar10 = (undefined8 *)0x142ec38;
    break;
  case 0x30:
    puVar10 = (undefined8 *)0x142f0a0;
    break;
  case 0x31:
    puVar10 = (undefined8 *)0x1436660;
    break;
  case 0x32:
    puVar10 = (undefined8 *)0x142f568;
    break;
  case 0x33:
    puVar10 = (undefined8 *)0x143f380;
    break;
  case 0x34:
    puVar10 = (undefined8 *)0x143f998;
    break;
  case 0x35:
    puVar10 = (undefined8 *)0x143fdf8;
    break;
  case 0x36:
    puVar10 = (undefined8 *)0x1438b30;
    break;
  case 0x37:
    puVar10 = (undefined8 *)0x1439048;
    break;
  case 0x38:
    puVar10 = (undefined8 *)0x1439700;
    break;
  case 0x39:
    puVar10 = (undefined8 *)0x1440020;
    break;
  case 0x3a:
    puVar10 = (undefined8 *)0x14408b0;
    break;
  default:
    in_stack_fffffffffffffef8 = 0;
    (*_DAT_)(1,0xd86960,0xd794f0,0xc0f,0);
  }
  iVar2 = func_0x(plStackX_20,0x18b,0);
  iVar3 = func_0x(plStackX_20,0x18c,0);
  func_0x(extraout_XMM0_Da,&uStack_60,param_2);
  puVar6 = (undefined8 *)
           func_0x(param_1,plStackX_20,0x1ad,0x1ae,
                           in_stack_fffffffffffffef8 & 0xffffffffffffff00);
  puStack_d8 = puVar6;
  puStack_d0 = puVar6;
  puVar7 = (undefined8 *)func_0x(param_1,plStackX_20,0x103);
  puStack_c8 = puVar7;
  puStack_c0 = puVar7;
  func_0x(&plStack_f8,plStackX_20,399);
  puVar8 = puVar12;
  if (plStack_f8 != (longlong *)0x0) {
    iVar4 = func_0x(plStack_f8,0x195,0xffffffff);
    if (iVar4 == -1) {
      (*_DAT_)(1,0xd86948,0xd794f0,0xc25,0);
    }
    func_0x(&plStack_e0,plStack_f8,0x192);
    iVar5 = func_0x(plStack_e0,0x195,0xffffffff);
    if (iVar5 == -1) {
      (*_DAT_)(1,0xd86930,0xd794f0,0xc2b,0);
    }
    func_0x(&plStack_e8,plStack_f8,0x193);
    iStack_98 = func_0x(plStack_e8,0x195,0xffffffff);
    if (iStack_98 == -1) {
      (*_DAT_)(1,0xd86918,0xd794f0,0xc32,0);
    }
    uStack_80 = 0xc7ed18;
    auStack_70 = ZEXT816(0);
    uStack_a0 = 0xc7ed18;
    auStack_90 = ZEXT816(0);
    iStack_78 = iVar5;
    puStack_b8 = (undefined8 *)(*_DAT_)(0x58,uStack_f0,0xd230c0,0xc39,1);
    if (puStack_b8 != (undefined8 *)0x0) {
      puVar8 = (undefined8 *)func_0x(puStack_b8,iVar4,&uStack_80,&uStack_a0);
    }
    if (plStack_e8 != (longlong *)0x0) {
      (**(code **)(*plStack_e8 + 0x10))();
    }
    if (plStack_e0 != (longlong *)0x0) {
      (**(code **)(*plStack_e0 + 0x10))();
    }
  }
  puVar9 = (undefined8 *)(*_DAT_)(0x68,uStack_f0,0xd230c0,0xc3c,1);
  puStack_b8 = puVar9;
  if (puVar9 != (undefined8 *)0x0) {
    puVar11 = puVar12;
    if (*(int *)((longlong)puStack_d8 + 0x1c) != 0) {
      puStack_d0 = (undefined8 *)0x0;
      puVar6 = puVar12;
      puVar11 = puStack_d8;
    }
    if (*(int *)((longlong)puStack_c8 + 0x1c) != 0) {
      puStack_c0 = (undefined8 *)0x0;
      puVar7 = puVar12;
      puVar12 = puStack_c8;
    }
    *puVar9 = 0x8bddb8;
    *(undefined4 *)(puVar9 + 1) = 1;
    *puVar9 = 0x831670;
    puVar9[2] = uStack_f0;
    *puVar9 = 0x828068;
    *(undefined4 *)(puVar9 + 3) = uStack_60;
    *(undefined4 *)((longlong)puVar9 + 0x1c) = uStack_5c;
    *(undefined4 *)(puVar9 + 4) = uStack_58;
    *(undefined4 *)((longlong)puVar9 + 0x24) = uStack_54;
    *(undefined4 *)(puVar9 + 5) = uStack_50;
    *(undefined4 *)((longlong)puVar9 + 0x2c) = uStack_4c;
    *(undefined4 *)(puVar9 + 6) = uStack_48;
    *(undefined4 *)((longlong)puVar9 + 0x34) = uStack_44;
    *(byte *)((longlong)puVar9 + 0x3e) = *(byte *)((longlong)puVar9 + 0x3e) & 0xfc;
    *(undefined2 *)((longlong)puVar9 + 0x3c) = 5;
    uVar1 = func_0x();
    *(undefined4 *)(puVar9 + 7) = uVar1;
    *puVar9 = 0x826898;
    puVar9[8] = puVar11;
    puVar9[9] = puVar12;
    *puVar9 = 0x823e58;
    puVar9[0xb] = puVar8;
    puVar9[0xc] = puVar10;
    *(byte *)(puVar9 + 10) = *(byte *)(puVar9 + 10) & 0xac;
    *(byte *)(puVar9 + 10) = (iVar2 != 0) << 4 | *(byte *)(puVar9 + 10) & 0xd3 | (iVar3 != 0) << 5;
    puVar12 = puVar9;
  }
  if (plStack_f8 != (longlong *)0x0) {
    (**(code **)(*plStack_f8 + 0x10))();
  }
  if (puVar7 != (undefined8 *)0x0) {
    puVar10 = puVar7 + 1;
    *(int *)puVar10 = *(int *)puVar10 + -1;
    if (*(int *)puVar10 == 0) {
      (**(code **)*puVar7)(puVar7,1);
    }
  }
  if (puVar6 != (undefined8 *)0x0) {
    puVar10 = puVar6 + 1;
    *(int *)puVar10 = *(int *)puVar10 + -1;
    if (*(int *)puVar10 == 0) {
      (**(code **)*puVar6)(puVar6,1);
    }
  }
  if (plStackX_20 != (longlong *)0x0) {
    (**(code **)(*plStackX_20 + 0x10))();
  }
  return puVar12;
}

