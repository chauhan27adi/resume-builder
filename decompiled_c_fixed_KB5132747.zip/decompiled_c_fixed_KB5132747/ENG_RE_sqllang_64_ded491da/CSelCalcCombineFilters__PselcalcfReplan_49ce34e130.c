
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong *param_1,undefined8 param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  longlong *plVar2;
  undefined4 uVar3;
  undefined8 *puVar4;
  uint *puVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  uint uVar8;
  uint uVar10;
  ulonglong uVar11;
  undefined8 uStackX_8;
  undefined8 uStackX_10;
  ulonglong uVar9;
  
  uVar9 = 0;
  uVar10 = 0;
  if (param_1[2] != 0) {
    uVar10 = *(uint *)(param_1[2] + 0xc);
  }
  uStackX_8 = (undefined8 *)CONCAT44(uStackX_8._4_4_,0x4e9);
  uStackX_10 = param_2;
  puVar4 = (undefined8 *)(*_DAT_)(0x20,param_2,0x203ddc8,0x4e9,1);
  if (puVar4 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar4 = param_2;
  *(undefined4 *)((longlong)puVar4 + 0xc) = 0;
  uVar8 = 1;
  if (uVar10 != 0) {
    uVar8 = uVar10;
  }
  *(uint *)(puVar4 + 2) = uVar8;
  puVar4[3] = 0;
  uVar11 = uVar9;
  if (uVar10 != 0) {
    do {
      puVar5 = (uint *)func_0x(0x2a2a4a0);
      *puVar5 = *puVar5 + 1;
      if (9 < *puVar5) {
        func_0x(0x7c);
        *puVar5 = 0;
      }
      if (*(uint *)(param_1[2] + 0xc) <= (uint)uVar9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      plVar2 = *(longlong **)(uVar11 + *(longlong *)(param_1[2] + 0x18));
      uStackX_8 = (undefined8 *)(**(code **)(*plVar2 + 0x88))(plVar2,param_2,param_3);
      func_0x(puVar4,&uStackX_8);
      uVar8 = (uint)uVar9 + 1;
      uVar9 = (ulonglong)uVar8;
      uVar11 = uVar11 + 8;
    } while (uVar8 < uVar10);
  }
  if (*(char *)(param_1 + 4) == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStackX_8 = (undefined8 *)CONCAT44(uStackX_8._4_4_,0x4f8);
  puVar6 = (undefined8 *)(*_DAT_)(0x20,param_2,0x203ddc8,0x4f8,1);
  if (puVar6 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar6 = 0x1f524e8;
  *(undefined4 *)(puVar6 + 1) = 1;
  *puVar6 = 0x1f6c3f8;
  puVar6[2] = param_2;
  puVar6[3] = 0;
  uStackX_8 = puVar6;
  uVar3 = (**(code **)(*param_1 + 0xa8))(param_1);
  uVar7 = func_0x(param_2,puVar4,param_1[3],uVar3,puVar6);
  if (puVar6 != (undefined8 *)0x0) {
    puVar1 = puVar6 + 1;
    *(int *)puVar1 = *(int *)puVar1 + -1;
    if (*(int *)puVar1 == 0) {
      (**(code **)*puVar6)(puVar6,1);
    }
  }
  if (puVar4 != (undefined8 *)0x0) {
    uStackX_8 = puVar4;
    func_0x(puVar4);
    if (puVar4[3] != 0) {
      (*_DAT_)();
      puVar4[3] = 0;
    }
    *(undefined4 *)(puVar4 + 2) = 0;
    (*_DAT_)(puVar4,0x20);
  }
  return uVar7;
}

