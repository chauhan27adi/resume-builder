
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2,longlong param_3)

{
  longlong *plVar1;
  char cVar2;
  bool bVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  longlong lVar6;
  uint uVar7;
  uint uVar8;
  ulonglong uVar9;
  uint uVar10;
  ulonglong uVar11;
  longlong unaff_GS_OFFSET;
  ushort auStack_58 [2];
  uint uStack_54;
  longlong lStack_50;
  ulonglong uStack_48;
  longlong lStack_40;
  int iStack_38;
  
  uVar11 = 0;
  bVar3 = false;
  uVar9 = 0;
  cVar2 = *_DAT_;
  auStack_58[0] = 0xfe;
  uStack_54 = 3;
  lVar6 = (ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  uStack_48 = uVar11;
  if ((lVar6 == 0) || (*(longlong *)(lVar6 + 0x110) != lVar6)) {
    lStack_50 = 0;
  }
  else {
    lStack_50 = *(longlong *)(lVar6 + 0x100);
    if (lStack_50 != 0) {
      uStack_48 = *(ulonglong *)(lStack_50 + 0x3e0);
    }
  }
  lStack_40 = 0;
  iStack_38 = 0;
  if (((*_DAT_ & 1) != 0) && (uStack_48 != 0)) {
    uVar4 = (*_DAT_)();
    lStack_40 = (*_DAT_)(uVar4,*(undefined2 *)(uStack_48 + 0xa0));
    if (lStack_40 != 0) {
      plVar1 = (longlong *)(*(longlong *)(lStack_40 + 0x18) + 0x3798);
      *plVar1 = *plVar1 + 1;
    }
  }
  if ((param_2 == 0) ||
     (((((*(uint *)(param_2 + 0x268) & 0x40) == 0 && ((*(uint *)(param_2 + 800) & 0x202000) == 0))
       && ((*(uint *)(param_2 + 0x268) >> 10 & 1) == 0)) &&
      ((*(uint *)(param_2 + 800) >> 0x14 & 1) == 0)))) {
    uVar10 = *_DAT_;
    if (uVar10 == 0) {
      uVar10 = 1;
    }
  }
  else {
    uVar10 = 10000;
    uVar9 = uVar11;
  }
  do {
    uVar5 = uVar11;
    if (cVar2 == '\0') {
      uVar5 = uVar9;
    }
    uVar8 = (uint)uVar5;
    while (uVar7 = (uint)uVar5, uVar8 < uVar10) {
      if (bVar3) {
        bVar3 = false;
      }
      else if ((uVar7 != 0) && (*(int *)param_1 == 0)) break;
      uVar8 = uVar7 + 1;
      uVar5 = (ulonglong)uVar8;
    }
    if (lStack_40 != 0) {
      plVar1 = (longlong *)(*(longlong *)(lStack_40 + 0x18) + 0x3790);
      *plVar1 = *plVar1 + uVar5;
    }
    if (uVar7 < uVar10) {
      LOCK();
      lVar6 = *param_1;
      if (lVar6 == 0) {
        *param_1 = param_3;
      }
      UNLOCK();
      if (lVar6 == 0) {
        return;
      }
      bVar3 = true;
      iStack_38 = 0;
      uVar9 = uVar5;
    }
    else {
      iStack_38 = iStack_38 + 1;
      if (lStack_40 != 0) {
        uVar8 = uStack_54 & 0xffff;
        if (uVar8 == 1) {
          uVar9 = *(ulonglong *)(lStack_40 + 8);
        }
        else if (uVar8 == 2) {
          uVar9 = *(ulonglong *)(lStack_40 + 0x10);
        }
        else if (uVar8 == 3) {
          uVar9 = *(ulonglong *)(lStack_40 + 0x18);
        }
        else {
          uVar9 = uVar11;
          if (uVar8 == 4) {
            uVar9 = *(ulonglong *)(lStack_40 + 0x20);
          }
        }
        plVar1 = (longlong *)((ulonglong)auStack_58[0] * 0x38 + 0x18 + uVar9);
        *plVar1 = *plVar1 + 1;
      }
      (*_DAT_)(param_1,auStack_58);
      uVar9 = uVar11;
    }
  } while( true );
}

