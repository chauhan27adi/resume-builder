
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x0067a383) */
/* WARNING: Removing unreachable block (ram,0x0067a36b) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_(longlong param_1,undefined8 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  int iVar2;
  undefined8 uVar3;
  longlong lVar4;
  longlong lVar5;
  longlong unaff_GS_OFFSET;
  
  lVar5 = 0;
  if (*(int *)(param_1 + 0x24) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar2 = *(int *)(*(longlong *)
                    (*(longlong *)
                      ((ulonglong)*_DAT_ +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
                    0x78) + 0x11c);
  iVar1 = *(int *)(*(longlong *)
                    (*(longlong *)
                      ((ulonglong)*_DAT_ +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
                    0x80) + 0x20c);
  func_0x(param_1);
  lVar4 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == param_1) {
    lVar4 = lVar5;
  }
  if (param_4 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(byte *)(*(longlong *)
                  (*(longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) + 0xa0
                  ) + 0x2d) & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar3 = (*_DAT_)();
  if (lVar4 != 0) {
    if ((((*(int *)(param_1 + 0x24) != 0) || (*(int *)(lVar4 + 0x130) == iVar1)) &&
        (*(int *)(lVar4 + 0x11c) == iVar2 + 1)) &&
       (iVar2 = (*_DAT_)(uVar3,param_2,param_3,lVar4 + 0x18,*(undefined4 *)(lVar4 + 0x118)),
       iVar2 == 0)) {
      lVar5 = lVar4;
    }
    if (*(longlong *)(lVar4 + 8) != param_1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  if (param_1 != 0) {
    func_0x();
  }
  return lVar5;
}

