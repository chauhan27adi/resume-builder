
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_(undefined8 param_1,undefined8 param_2,byte *param_3,byte *param_4,
                     longlong param_5,int *param_6)

{
  byte bVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  longlong lVar5;
  code *UNRECOVERED_JUMPTABLE;
  longlong lVar6;
  longlong unaff_GS_OFFSET;
  bool bVar7;
  ulonglong uVar8;
  undefined uStack_b0;
  byte bStack_af;
  undefined2 uStack_ae;
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined8 uStack_90;
  undefined auStack_60 [40];
  
  uStack_90 = 0xfffffffffffffffe;
  lVar5 = param_5;
  if ((param_5 == 0) &&
     ((((*(short *)(param_3 + 0x10) == -1 ||
        (*(char *)((ulonglong)*(byte *)((ulonglong)*param_3 + 0x7ed580) + 0x12cad28) != '\0')) ||
       (*(short *)(param_4 + 0x10) == -1)) ||
      (*(char *)((ulonglong)*(byte *)((ulonglong)*param_4 + 0x7ed580) + 0x12cad28) != '\0')))) {
    lVar6 = *(longlong *)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
             + 0x80);
    lVar5 = *(longlong *)(lVar6 + 0x120);
    if (lVar5 == 0) {
      (***(code ***)(lVar6 + 0x110))(lVar6 + 0x110);
      lVar5 = *(longlong *)(lVar6 + 0x120);
    }
  }
  param_5 = func_0x(param_1,param_2,param_3);
  uVar8 = 0xfffffffffe829240;
  func_0x(auStack_60,0,0,0,0xfffffffffe829240,0);
  bVar7 = false;
  if (*param_3 == 0x2b) {
    bVar7 = *param_4 != 0x2b;
  }
  iVar4 = (*_DAT_)(param_5,param_3,param_4,0,uVar8 & 0xffffffff00000000,param_1,bVar7,0,0,0,
                           0,lVar5,bVar7);
  if (iVar4 == 1) {
    bVar1 = *param_4;
    cVar3 = (*_DAT_)(bVar1);
    if (((cVar3 != '\0') && (bVar1 != 0x3e)) && (3 < (byte)(bVar1 - 0x28))) {
      bStack_af = *param_4;
      uStack_ae = 0;
      uStack_b0 = 3;
      uStack_a8 = 0;
      uStack_a0 = 0;
      uStack_98 = 0;
      (*_DAT_)(&uStack_b0,param_4,1);
      iVar4 = (*_DAT_)(param_2,param_3,param_4,&uStack_b0);
      (*_DAT_)(param_5,param_4,iVar4 == 4);
      goto LAB_;
    }
LAB_:
    cVar3 = '\0';
  }
  else {
    if ((iVar4 != 0) && (iVar4 != 7)) goto LAB_;
    cVar3 = '\x01';
  }
  if (iVar4 == 6) {
    cVar3 = *(char *)((ulonglong)*(byte *)((ulonglong)*param_4 + 0x7ed580) + 0x8eb920);
  }
  if (cVar3 == '\0') {
    func_0x(&param_5,0);
  }
LAB_:
  func_0x(auStack_60);
  lVar6 = (ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar5 = *(longlong *)(lVar6 + 0x100);
  if (lVar5 == 0) {
    (*_DAT_)();
    lVar5 = *(longlong *)(lVar6 + 0x100);
  }
  if (*(int *)(lVar5 + 0x22c) != 0) {
    (*_DAT_)();
  }
  piVar2 = param_6;
  lVar5 = param_5;
  if (((param_5 != 0) && (param_6 != (int *)0x0)) &&
     (iVar4 = (*_DAT_)(param_5,param_4,param_3,param_2), iVar4 != 2)) {
    if (*piVar2 - 1U < 6) {
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)*(uint *)((ulonglong)(*piVar2 - 1U) * 4 + 0x10036c) - 0x18365c0);
                    /* WARNING: Could not emulate address calculation at 0x00100317 */
                    /* WARNING: Treating indirect jump as call */
      lVar5 = (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,iVar4 == 1);
      return lVar5;
    }
  }
  return lVar5;
}

