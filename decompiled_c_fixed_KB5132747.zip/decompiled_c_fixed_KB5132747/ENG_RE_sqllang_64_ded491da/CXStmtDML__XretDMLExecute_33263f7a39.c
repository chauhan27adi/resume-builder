
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x0102df48) */
/* WARNING: Removing unreachable block (ram,0x0102e2a8) */
/* WARNING: Removing unreachable block (ram,0x0102e2d9) */
/* WARNING: Removing unreachable block (ram,0x0102de51) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong *param_1,longlong param_2,undefined4 param_3,char param_4)

{
  byte bVar1;
  char cVar2;
  int iVar3;
  longlong lVar4;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_c8;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined auStack_68 [16];
  undefined auStack_58 [16];
  
  uStack_a8 = 0xfffffffffffffffe;
  cVar2 = func_0x(0x2bd2070,1);
  if (cVar2 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_4 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1[4] + 0x978) == 0x5445) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_a0 = 0;
  auStack_68 = ZEXT816(0);
  auStack_58 = ZEXT816(0);
  lVar4 = param_1[4];
  if (*(int *)(lVar4 + 0x60) == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(char *)(lVar4 + 0x8ad) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_c8 = CONCAT44(uRam000000000212fb64,_DAT_);
  uStack_c0 = uRam000000000212fb68;
  uStack_bc = uRam000000000212fb6c;
  cVar2 = (**(code **)(**(longlong **)(lVar4 + 0x890) + 0xb0))
                    (*(longlong **)(lVar4 + 0x890),&uStack_c8);
  if (cVar2 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_c8 = *(undefined8 *)(param_2 + 0xa0);
  bVar1 = *(byte *)((longlong)param_1 + 0x1a9);
  if (param_1[0x18] == 0) {
    cVar2 = func_0x();
    if (cVar2 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    (**(code **)(*param_1 + 0x68))(param_1);
    if (*(char *)(param_1[4] + 0x8ab) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  if (*(longlong *)(param_1[0x17] + 0x918) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_1[0x18] == 0) {
    iVar3 = (**(code **)(*param_1 + 0x90))(param_1,param_2,0xffffffff);
    if (iVar3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    cVar2 = func_0x(param_1,param_2);
    if (cVar2 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(byte *)(param_1[4] + 0x920) & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar4 = param_1[4];
    if (((*(uint *)(lVar4 + 0x8a0) >> 2 & 1) == 0) &&
       (((((*(byte *)(lVar4 + 0x8b0) & 1) != 0 || (*(char *)(lVar4 + 0x920) < '\0')) &&
         ((*(byte *)(lVar4 + 0x920) & 2) == 0)) &&
        (((*(uint *)(lVar4 + 0x8a0) >> 0x1a & 1) != 0 &&
         (cVar2 = func_0x(lVar4,param_2), cVar2 == '\0')))))) {
      if ((*(byte *)(param_1 + 0x16) & 0x20) == 0) {
        return 0;
      }
      (**(code **)(*param_1 + 0x10))(param_1,0);
      return 0;
    }
  }
  *(undefined4 *)(param_1 + 0x107) = 1;
  if (param_1[0x18] == 0) {
    *(longlong *)(param_1[0x1c] + 0x48) = param_1[0x108];
    if ((*(byte *)(param_1[4] + 0x921) & 8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(byte *)(param_1[4] + 0x920) & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  if ((bVar1 & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar3 = func_0x(param_1,param_2,0,param_3);
  *(int *)((longlong)param_1 + 0x83c) = iVar3;
  if (iVar3 != 9) {
    (**(code **)(**(longlong **)(param_1[4] + 0x890) + 0x218))
              (*(longlong **)(param_1[4] + 0x890),
               *(undefined2 *)
                (*(longlong *)
                  (*(longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) + 0x50
                  ) + 8));
    if (*(int *)(param_1[4] + 0x978) == 0x2053) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(int *)(param_1[4] + 0x978) != 0x2055) || (iVar3 != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(char *)(_DAT_ + 0x677) != '\0') || ((*(byte *)(_DAT_ + 0x5fe) & 2) != 0))
    {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*_DAT_ != '\0') && ((*(byte *)(_DAT_ + 0x48) & 8) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar4 = *(longlong *)(param_1[4] + 0x70) + 0xb0;
    if (*(longlong *)(param_1[4] + 0x70) == 0) {
      lVar4 = 0;
    }
    if ((*(byte *)(lVar4 + 0x60) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined4 *)(param_1 + 0x107) = 2;
    (**(code **)(*param_1 + 0x70))(param_1);
    if ((*(byte *)(param_1[0xb] + 0xb0) & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined4 *)(param_1 + 0x107) = 3;
    lVar4 = param_1[4];
    if (((*(uint *)(lVar4 + 0x8a0) >> 2 & 1) == 0) &&
       (((*(byte *)(lVar4 + 0x8b0) & 3) != 0 || (*(char *)(lVar4 + 0x8ad) != '\0')))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    cVar2 = (**(code **)(**(longlong **)(param_1[0x17] + 0x890) + 0x1b8))();
    if (cVar2 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(*(longlong *)(param_1[4] + 0x958) + 0x68) == 0) {
      (**(code **)(*param_1 + 0x88))(param_1,param_2,0,**(undefined8 **)(param_2 + 0x40));
      if (param_1[0x10a] == 0) {
        func_0x(param_1[4],param_2,param_1,param_1[5]);
        return 0;
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

