
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  ulonglong uVar10;
  ulonglong uVar9;
  
  uVar8 = 0;
  uVar10 = 0;
  for (uVar9 = uVar10;
      (lVar2 = *(longlong *)(param_1 + 8), lVar2 != 0 && ((uint)uVar9 < *(uint *)(lVar2 + 0xc)));
      uVar9 = (ulonglong)((uint)uVar9 + 1)) {
    lVar2 = *(longlong *)(*(longlong *)(lVar2 + 0x18) + uVar9 * 8);
    if (lVar2 != 0) {
      (*_DAT_)(*(undefined8 *)(lVar2 + 8));
      (*_DAT_)(lVar2,0x10);
    }
  }
  if (lVar2 != 0) {
    *(undefined4 *)(lVar2 + 0xc) = 0;
    if (*(longlong *)(lVar2 + 0x18) != 0) {
      (*_DAT_)();
      *(undefined8 *)(lVar2 + 0x18) = 0;
    }
    *(undefined4 *)(lVar2 + 0x10) = 0;
    (*_DAT_)(lVar2,0x20);
  }
  lVar2 = *(longlong *)(param_1 + 0x20);
  uVar7 = *(uint *)(lVar2 + 0xc);
  uVar9 = uVar10;
  if (uVar7 != 0) {
    do {
      if (*(longlong *)(*(longlong *)(lVar2 + 0x10) + uVar9 * 8) != 0) break;
      uVar6 = (int)uVar9 + 1;
      uVar9 = (ulonglong)uVar6;
    } while (uVar6 < uVar7);
  }
  if ((uint)uVar9 != uVar7) {
    plVar3 = *(longlong **)(*(longlong *)(lVar2 + 0x10) + uVar9 * 8);
    while (plVar3 != (longlong *)0x0) {
      plVar4 = (longlong *)plVar3[2];
      if (plVar4 != (longlong *)0x0) {
        puVar5 = (undefined8 *)*plVar4;
        if (puVar5 != (undefined8 *)0x0) {
          puVar1 = puVar5 + 1;
          *(int *)puVar1 = *(int *)puVar1 + -1;
          if (*(int *)puVar1 == 0) {
            (**(code **)*puVar5)(puVar5,1);
          }
        }
        (*_DAT_)(plVar4,0x10);
      }
      plVar3 = (longlong *)*plVar3;
      if (plVar3 == (longlong *)0x0) {
        do {
          uVar7 = (int)uVar9 + 1;
          uVar9 = (ulonglong)uVar7;
          if (*(uint *)(lVar2 + 0xc) <= uVar7) {
            if (uVar7 == *(uint *)(lVar2 + 0xc)) goto LAB_;
            break;
          }
        } while (*(longlong *)(*(longlong *)(lVar2 + 0x10) + uVar9 * 8) == 0);
        plVar3 = *(longlong **)(*(longlong *)(lVar2 + 0x10) + uVar9 * 8);
      }
    }
  }
LAB_:
  lVar2 = *(longlong *)(param_1 + 0x20);
  if (lVar2 != 0) {
    func_0x(lVar2);
    (*_DAT_)(lVar2,0x28);
  }
  uVar7 = *(uint *)(*(longlong *)(param_1 + 0x28) + 0xc);
  if (uVar7 != 0) {
    uVar9 = uVar10;
    do {
      uVar8 = (uint)uVar9;
      if (*(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x28) + 0x10) + uVar9 * 8) != 0)
      break;
      uVar8 = uVar8 + 1;
      uVar9 = (ulonglong)uVar8;
    } while (uVar8 < uVar7);
  }
  if (uVar8 != uVar7) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar2 = *(longlong *)(param_1 + 0x28);
  if (lVar2 != 0) {
    func_0x(lVar2);
    (*_DAT_)(lVar2,0x28);
  }
  lVar2 = *(longlong *)(param_1 + 0x18);
  uVar8 = *(uint *)(lVar2 + 0xc);
  if (uVar8 != 0) {
    do {
      if (*(longlong *)(*(longlong *)(lVar2 + 0x10) + uVar10 * 8) != 0) break;
      uVar7 = (int)uVar10 + 1;
      uVar10 = (ulonglong)uVar7;
    } while (uVar7 < uVar8);
  }
  if ((uint)uVar10 != uVar8) {
    plVar3 = *(longlong **)(*(longlong *)(lVar2 + 0x10) + uVar10 * 8);
    while (plVar3 != (longlong *)0x0) {
      (*_DAT_)(plVar3[1],0x18);
      plVar3 = (longlong *)*plVar3;
      if (plVar3 == (longlong *)0x0) {
        do {
          uVar8 = (int)uVar10 + 1;
          uVar10 = (ulonglong)uVar8;
          if (*(uint *)(lVar2 + 0xc) <= uVar8) {
            if (uVar8 == *(uint *)(lVar2 + 0xc)) goto LAB_;
            break;
          }
        } while (*(longlong *)(*(longlong *)(lVar2 + 0x10) + (ulonglong)uVar8 * 8) == 0);
        plVar3 = *(longlong **)(*(longlong *)(lVar2 + 0x10) + (ulonglong)uVar8 * 8);
      }
    }
  }
LAB_:
  lVar2 = *(longlong *)(param_1 + 0x18);
  if (lVar2 != 0) {
    func_0x(lVar2);
    (*_DAT_)(lVar2,0x28);
  }
  return;
}

