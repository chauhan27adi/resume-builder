
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8
FUN_(uint param_1,longlong param_2,uint *param_3,longlong *param_4,uint param_5,
            longlong param_6)

{
  uint *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  longlong lVar8;
  undefined8 *puVar9;
  longlong lVar10;
  ulonglong uVar11;
  undefined8 *puVar12;
  ulonglong uVar13;
  uint uVar14;
  uint uVar15;
  uint uStack_58;
  
  if ((((param_1 != 0) && (param_2 == 0)) || (param_3 == (uint *)0x0)) ||
     (param_4 == (longlong *)0x0)) {
    return 0x80070057;
  }
  if (param_1 == 0) {
    *param_3 = 1;
    lVar8 = (*_DAT_)(0x20);
    *param_4 = lVar8;
    uVar7 = uRam00000000010080ec;
    uVar6 = _DAT_;
    uVar3 = uRam00000000010080e4;
    if (lVar8 != 0) {
      *(undefined4 *)(lVar8 + 0xc) = _DAT_;
      *(undefined4 *)(lVar8 + 0x10) = uVar3;
      *(undefined4 *)(lVar8 + 0x14) = uVar6;
      *(undefined4 *)(lVar8 + 0x18) = uVar7;
      *(undefined4 *)(*param_4 + 8) = 6;
      puVar9 = (undefined8 *)(*_DAT_)((ulonglong)*(uint *)(*param_4 + 8) * 0x48);
      if (puVar9 == (undefined8 *)0x0) {
        (*_DAT_)((undefined8 *)*param_4);
        *param_4 = 0;
        *param_3 = 0;
        return 0x8007000e;
      }
      *(undefined8 *)*param_4 = puVar9;
      *puVar9 = 1;
      *(undefined4 *)(puVar9 + 1) = 0;
      *(undefined2 *)(puVar9 + 6) = 0xb;
      puVar9[9] = 2;
      *(undefined2 *)(puVar9 + 7) = 0xffff;
      *(ushort *)(puVar9 + 0x22) = -(ushort)((param_5 & 1) != 0);
      *(undefined4 *)(puVar9 + 10) = 0;
      *(undefined2 *)(puVar9 + 0x2a) = 5;
      *(undefined2 *)(puVar9 + 0xf) = 0xb;
      *(undefined2 *)(puVar9 + 0x10) = 0xffff;
      *(ushort *)(puVar9 + 0x34) = -(ushort)((param_5 & 2) != 0);
      puVar9[0x12] = 3;
      *(undefined4 *)(puVar9 + 0x13) = 0;
      puVar9[0x2b] = (double)param_6;
      *(undefined2 *)(puVar9 + 0x18) = 0xb;
      *(undefined2 *)(puVar9 + 0x19) = 0xffff;
      puVar9[0x1b] = 0x11;
      *(undefined4 *)(puVar9 + 0x1c) = 0;
      *(undefined2 *)(puVar9 + 0x21) = 0xb;
      puVar9[0x24] = 0x13;
      *(undefined4 *)(puVar9 + 0x25) = 0;
      puVar9[0x2d] = 0x12;
      *(undefined4 *)(puVar9 + 0x2e) = 0;
      *(undefined2 *)(puVar9 + 0x33) = 0xb;
      return 0;
    }
  }
  else {
    *param_3 = param_1;
    puVar9 = (undefined8 *)(*_DAT_)((ulonglong)param_1 << 5);
    *param_4 = (longlong)puVar9;
    if (puVar9 != (undefined8 *)0x0) {
      uVar11 = 0;
      uStack_58 = 0;
      if (param_1 != 0) {
        puVar12 = puVar9 + 1;
        lVar8 = param_2 - (longlong)puVar9;
        uVar13 = uVar11;
        do {
          puVar1 = (uint *)(lVar8 + 4 + (longlong)puVar12);
          uVar15 = puVar1[1];
          uVar14 = puVar1[2];
          uVar5 = puVar1[3];
          *(uint *)((longlong)puVar12 + 4) = *puVar1;
          *(uint *)(puVar12 + 1) = uVar15;
          *(uint *)((longlong)puVar12 + 0xc) = uVar14;
          *(uint *)(puVar12 + 2) = uVar5;
          uVar15 = *(uint *)(lVar8 + (longlong)puVar12);
          *(uint *)puVar12 = uVar15;
          lVar10 = (*_DAT_)((ulonglong)uVar15 * 0x48);
          uVar15 = (uint)uVar13;
          if (lVar10 == 0) {
            if (uVar15 != 0) {
              do {
                (*_DAT_)(*puVar9);
                puVar9 = puVar9 + 4;
                uVar13 = uVar13 - 1;
              } while (uVar13 != 0);
            }
            (*_DAT_)(*param_4);
            *param_4 = 0;
            *param_3 = 0;
            return 0x8007000e;
          }
          puVar12[-1] = lVar10;
          if ((CONCAT44(uRam00000000010080e4,_DAT_) ==
               *(longlong *)(uVar13 * 0x20 + 0xc + param_2)) &&
             (CONCAT44(uRam00000000010080ec,_DAT_) ==
              *(longlong *)(uVar13 * 0x20 + 0x14 + param_2))) {
            uVar13 = uVar11;
            if (*(uint *)puVar12 != 0) {
              do {
                uVar3 = *(undefined4 *)(*(longlong *)((longlong)puVar12 + lVar8 + -8) + uVar13 * 4);
                switch(uVar3) {
                case 1:
                  *(undefined8 *)(lVar10 + uVar13 * 0x48) = 1;
                  goto code_r0x001002e9;
                case 2:
                  *(undefined8 *)(lVar10 + uVar13 * 0x48) = 2;
                  goto code_r0x001002e9;
                case 3:
                  *(undefined8 *)(lVar10 + uVar13 * 0x48) = 3;
code_r0x001002e9:
                  *(undefined4 *)(lVar10 + 8 + uVar13 * 0x48) = 0;
                  *(undefined2 *)(lVar10 + 0x30 + uVar13 * 0x48) = 0xb;
                  *(undefined2 *)(lVar10 + 0x38 + uVar13 * 0x48) = 0xffff;
                  break;
                default:
                  *(undefined4 *)(lVar10 + uVar13 * 0x48) = uVar3;
                  *(undefined4 *)(lVar10 + 4 + uVar13 * 0x48) = 0;
                  *(undefined4 *)(lVar10 + 8 + uVar13 * 0x48) = 1;
                  *(undefined2 *)(lVar10 + 0x30 + uVar13 * 0x48) = 0;
                  break;
                case 0x11:
                  *(undefined8 *)(lVar10 + uVar13 * 0x48) = 0x11;
                  *(undefined4 *)(lVar10 + 8 + uVar13 * 0x48) = 0;
                  *(undefined2 *)(lVar10 + 0x30 + uVar13 * 0x48) = 0xb;
                  *(ushort *)(lVar10 + 0x38 + uVar13 * 0x48) = -(ushort)((param_5 & 1) != 0);
                  break;
                case 0x12:
                  *(undefined8 *)(lVar10 + uVar13 * 0x48) = 0x12;
                  *(undefined4 *)(lVar10 + 8 + uVar13 * 0x48) = 0;
                  *(undefined2 *)(lVar10 + 0x30 + uVar13 * 0x48) = 0xb;
                  *(ushort *)(lVar10 + 0x38 + uVar13 * 0x48) = -(ushort)((param_5 & 2) != 0);
                  break;
                case 0x13:
                  *(undefined8 *)(lVar10 + uVar13 * 0x48) = 0x13;
                  *(undefined4 *)(lVar10 + 8 + uVar13 * 0x48) = 0;
                  *(undefined2 *)(lVar10 + 0x30 + uVar13 * 0x48) = 5;
                  *(double *)(lVar10 + 0x38 + uVar13 * 0x48) = (double)param_6;
                }
                uVar14 = (int)uVar13 + 1;
                uVar13 = (ulonglong)uVar14;
                uVar15 = uStack_58;
              } while (uVar14 < *(uint *)puVar12);
            }
          }
          else {
            uVar13 = uVar11;
            if (*(uint *)puVar12 != 0) {
              do {
                iVar4 = *(int *)(*(longlong *)((longlong)puVar12 + lVar8 + -8) + uVar13 * 4);
                *(undefined4 *)(lVar10 + 4 + uVar13 * 0x48) = 0;
                if (iVar4 == 0x88) {
                  *(undefined4 *)(lVar10 + uVar13 * 0x48) = 0x88;
                  *(undefined4 *)(lVar10 + 8 + uVar13 * 0x48) = 0;
                  *(undefined2 *)(lVar10 + 0x30 + uVar13 * 0x48) = 0xb;
                  *(undefined2 *)(lVar10 + 0x38 + uVar13 * 0x48) = 0xffff;
                  uVar7 = uRam0000000000eb6d24;
                  uVar6 = uRam0000000000eb6d20;
                  uVar3 = uRam0000000000eb6d1c;
                  puVar2 = (undefined4 *)(lVar10 + 0x10 + uVar13 * 0x48);
                  *puVar2 = _DAT_;
                  puVar2[1] = uVar3;
                  puVar2[2] = uVar6;
                  puVar2[3] = uVar7;
                  uVar7 = uRam0000000000eb6d34;
                  uVar6 = uRam0000000000eb6d30;
                  uVar3 = uRam0000000000eb6d2c;
                  puVar2 = (undefined4 *)(lVar10 + 0x20 + uVar13 * 0x48);
                  *puVar2 = _DAT_;
                  puVar2[1] = uVar3;
                  puVar2[2] = uVar6;
                  puVar2[3] = uVar7;
                }
                else {
                  *(int *)(lVar10 + uVar13 * 0x48) = iVar4;
                  *(undefined4 *)(lVar10 + 8 + uVar13 * 0x48) = 1;
                  *(undefined2 *)(lVar10 + 0x30 + uVar13 * 0x48) = 0;
                }
                uVar14 = (int)uVar13 + 1;
                uVar13 = (ulonglong)uVar14;
              } while (uVar14 < *(uint *)puVar12);
            }
          }
          uStack_58 = uVar15 + 1;
          uVar13 = (ulonglong)uStack_58;
          puVar12 = puVar12 + 4;
        } while (uStack_58 < param_1);
      }
      return 0;
    }
  }
  *param_3 = 0;
  return 0x8007000e;
}

