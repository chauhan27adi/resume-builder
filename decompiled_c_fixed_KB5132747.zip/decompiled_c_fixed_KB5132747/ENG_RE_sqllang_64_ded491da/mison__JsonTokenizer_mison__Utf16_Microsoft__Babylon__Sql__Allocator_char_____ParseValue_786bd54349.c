
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  ushort *puVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longlong lVar6;
  undefined4 *puVar7;
  longlong *plVar8;
  undefined8 uVar9;
  ushort uVar10;
  longlong lVar11;
  longlong lVar12;
  undefined auStack_318 [32];
  longlong *plStack_2f8;
  undefined8 uStack_2f0;
  longlong lStack_2e8;
  longlong lStack_2d8;
  undefined8 uStack_2d0;
  undefined *puStack_2c8;
  undefined *puStack_2c0;
  undefined *puStack_2b8;
  undefined4 uStack_2a8;
  undefined4 uStack_2a4;
  undefined4 uStack_2a0;
  undefined4 uStack_29c;
  undefined auStack_298 [24];
  undefined auStack_280 [32];
  undefined auStack_260 [40];
  undefined auStack_238 [40];
  undefined auStack_210 [40];
  undefined auStack_1e8 [48];
  longlong alStack_1b8 [16];
  undefined auStack_138 [40];
  undefined auStack_110 [40];
  undefined auStack_e8 [40];
  undefined auStack_c0 [40];
  undefined auStack_98 [40];
  undefined auStack_70 [40];
  undefined auStack_48 [40];
  undefined auStack_20 [8];
  ulonglong uStack_18;
  
  uStack_2d0 = 0xfffffffffffffffe;
  uStack_18 = _DAT_ ^ (ulonglong)auStack_318;
  lVar6 = param_1[4];
  lVar12 = param_1[2];
  if (lVar12 <= lVar6) {
LAB_:
    uVar9 = func_0x();
    func_0x(alStack_1b8,uVar9,*param_1);
    func_0x(alStack_1b8,0x146d948);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
  }
  param_1[0x1a] = lVar6;
  puVar1 = (ushort *)(param_1[1] + lVar6 * 2);
  uVar10 = *puVar1;
  switch(uVar10) {
  case 0x22:
    *(undefined4 *)(param_1 + 5) = 9;
    uStack_2f0 = param_1 + 0x1b;
    plStack_2f8 = &lStack_2d8;
    puVar7 = (undefined4 *)func_0x(auStack_298,puVar1,lVar12 - lVar6,param_1[3] + lVar6);
    uVar3 = puVar7[1];
    uVar4 = puVar7[2];
    uVar5 = puVar7[3];
    *(undefined4 *)(param_1 + 0x14) = *puVar7;
    *(undefined4 *)((longlong)param_1 + 0xa4) = uVar3;
    *(undefined4 *)(param_1 + 0x15) = uVar4;
    *(undefined4 *)((longlong)param_1 + 0xac) = uVar5;
    param_1[0x16] = *(longlong *)(puVar7 + 4);
    param_1[4] = param_1[4] + lStack_2d8;
    break;
  default:
    if ((0x39 < uVar10) || ((0x3ff280000000000U >> ((ulonglong)uVar10 & 0x3f) & 1) == 0)) {
      func_0x(auStack_1e8,puVar1,lVar12 - lVar6,*param_1);
      lVar6 = *param_1;
      func_0x(&lStack_2d8,lVar6);
      func_0x(auStack_138,0x13c9cf8,lVar6);
      func_0x(auStack_110,0x13c8cb0,*param_1);
      func_0x(auStack_e8,0x13c9d08,*param_1);
      func_0x(auStack_c0,0x13c9d18,*param_1);
      func_0x(auStack_98,0x13cad60,*param_1);
      func_0x(auStack_70,0x13cad58,*param_1);
      func_0x(auStack_48,0x1275a34,*param_1);
      puVar7 = (undefined4 *)func_0x(auStack_298,auStack_138,auStack_20);
      uStack_2a8 = *puVar7;
      uStack_2a4 = puVar7[1];
      uStack_2a0 = puVar7[2];
      uStack_29c = puVar7[3];
      func_0x(auStack_280,&uStack_2a8,&lStack_2d8);
      func_0x(auStack_138,0x28,7,0xdd590);
      puStack_2c8 = auStack_260;
      puStack_2c0 = auStack_210;
      puStack_2b8 = auStack_238;
      plVar8 = (longlong *)func_0x(auStack_260,0x1072941,*param_1);
      uVar9 = func_0x(auStack_238,auStack_1e8);
      uVar9 = func_0x(auStack_210,uVar9,*param_1);
      func_0x(param_1,uVar9);
      uStack_2f0 = (longlong *)*param_1;
      plStack_2f8 = plVar8;
      func_0x(alStack_1b8);
      param_1 = alStack_1b8;
      func_0x(param_1,0x146da68);
      goto LAB_;
    }
    lVar12 = lVar12 - lVar6;
    if (lVar12 == 0) {
      func_0x(alStack_1b8,param_1[3] + lVar6,*param_1);
      func_0x(alStack_1b8,0x146d948);
      pcVar2 = (code *)swi(3);
      (*pcVar2)();
      return;
    }
    lVar11 = 0;
    if ((0 < lVar12) && ((uVar10 != 0x2d || (lVar11 = 1, 1 < lVar12)))) {
      do {
        if (9 < (ushort)(puVar1[lVar11] - 0x30)) {
          uVar10 = *(short *)(param_1[1] + (lVar11 + lVar6) * 2) - 0x2e;
          if ((uVar10 < 0x38) && ((0x80000000800001U >> ((ulonglong)uVar10 & 0x3f) & 1) != 0)) {
            lStack_2e8 = *param_1;
            uStack_2f0 = (longlong *)CONCAT71(uStack_2f0._1_7_,1);
            plStack_2f8 = &lStack_2d8;
            lVar6 = func_0x(puVar1,lVar12,lVar12,param_1[3] + lVar6);
            param_1[0x18] = lVar6;
            param_1[4] = param_1[4] + lStack_2d8;
            *(undefined4 *)(param_1 + 5) = 0xb;
            goto LAB_;
          }
          break;
        }
        lVar11 = lVar11 + 1;
      } while (lVar11 < lVar12);
    }
    lStack_2e8 = *param_1;
    uStack_2f0 = (longlong *)CONCAT71(uStack_2f0._1_7_,1);
    plStack_2f8 = &lStack_2d8;
    lVar6 = func_0x(puVar1,lVar12,lVar12,param_1[3] + lVar6);
    param_1[0x17] = lVar6;
    param_1[4] = param_1[4] + lStack_2d8;
    *(undefined4 *)(param_1 + 5) = 10;
    break;
  case 0x5b:
    func_0x(param_1);
    break;
  case 0x66:
    func_0x(param_1);
    break;
  case 0x6e:
    func_0x(param_1);
    break;
  case 0x74:
    func_0x(param_1);
    break;
  case 0x7b:
    func_0x(param_1);
  }
LAB_:
  func_0x(uStack_18 ^ (ulonglong)auStack_318);
  return;
}

