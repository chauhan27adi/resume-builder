
/* WARNING: Removing unreachable block (ram,0x00c248a5) */
/* WARNING: Removing unreachable block (ram,0x00c248d0) */
/* WARNING: Removing unreachable block (ram,0x00c248dd) */
/* WARNING: Removing unreachable block (ram,0x00c248f2) */
/* WARNING: Removing unreachable block (ram,0x00c248fb) */
/* WARNING: Removing unreachable block (ram,0x00c24912) */

void FUN_(undefined8 param_1,undefined8 param_2,int param_3,undefined4 param_4)

{
  code *pcVar1;
  longlong lVar2;
  
  if (param_3 != -1) {
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
  }
  lVar2 = func_0x(param_1,param_4);
  if (lVar2 != 0) {
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
  }
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}

