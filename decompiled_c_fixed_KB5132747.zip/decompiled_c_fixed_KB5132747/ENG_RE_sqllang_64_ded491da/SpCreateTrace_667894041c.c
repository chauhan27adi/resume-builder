
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong *param_2,longlong param_3,longlong param_4)

{
  undefined auVar1 [16];
  ushort uVar2;
  char *pcVar3;
  undefined (*pauVar4) [16];
  undefined4 uVar5;
  undefined4 uVar6;
  char cVar7;
  undefined2 uVar8;
  uint uVar9;
  uint uVar10;
  longlong lVar11;
  byte *pbVar12;
  undefined8 uVar13;
  uint uVar14;
  longlong lVar15;
  uint uVar16;
  int iVar17;
  undefined8 unaff_RBX;
  byte *pbVar18;
  undefined4 uVar19;
  byte *pbVar20;
  bool bVar21;
  undefined4 auStackX_8 [2];
  undefined4 auStackX_10 [2];
  undefined8 auStackX_18 [2];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  *(undefined8 *)(&stack0x00000060 + lVar11) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000010c8 + lVar11) = unaff_RBX;
  *(ulonglong *)(&stack0x00001078 + lVar11) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar11);
  pbVar12 = (byte *)0x0;
  uVar9 = 0;
  uVar10 = uVar9;
  if (param_3 != 0) {
    uVar10 = *(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28);
  }
  *(undefined8 *)(&stack0x00000030 + lVar11) = 5;
  *(undefined4 *)(&stack0x00000028 + lVar11) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100079;
  uVar8 = (*_DAT_)();
  *(undefined8 *)((longlong)auStackX_18 + lVar11 + 8) = 0;
  *(undefined8 *)((longlong)auStackX_18 + lVar11) = 0;
  *(undefined *)((longlong)auStackX_10 + lVar11) = 0;
  *(undefined *)((longlong)auStackX_8 + lVar11) = 1;
  *(undefined4 *)((longlong)auStackX_18 + lVar11 + -0x18) = 0;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar11) = 0xffffffff;
  *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0;
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1000b5;
  cVar7 = func_0x(0x54415253,0,0,uVar8);
  if (cVar7 == '\0') {
    lVar15 = 0x11d4090;
    if (_DAT_ != 0) {
      lVar15 = _DAT_;
    }
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = lVar15;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1000e9;
    (*_DAT_)(0x51,0x59,0xe,6);
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1000fa;
  func_0x(0x100,_DAT_);
  *(undefined4 *)(param_4 + 8) = 0xf;
  pbVar18 = pbVar12;
  pbVar20 = pbVar12;
  uVar14 = 0;
  switch(uVar10) {
  case 0:
    uVar13 = *(undefined8 *)*param_2;
    uVar2 = *(ushort *)((undefined8 *)*param_2 + 1);
    *(undefined8 *)((longlong)auStackX_18 + lVar11 + -0x18) = 0x1258988;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar11) = 0x10;
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = uVar13;
    *(uint *)(&stack0xffffffffffffffe8 + lVar11) = (uint)uVar2;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100416;
    (*_DAT_)(2,1,0x10);
    break;
  case 1:
    uVar13 = *(undefined8 *)*param_2;
    uVar2 = *(ushort *)((undefined8 *)*param_2 + 1);
    *(undefined8 *)((longlong)auStackX_18 + lVar11 + -0x18) = 0x11fa378;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar11) = 0x10;
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = uVar13;
    *(uint *)(&stack0xffffffffffffffe8 + lVar11) = (uint)uVar2;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1003d5;
    (*_DAT_)(2,1,0x10);
    break;
  case 2:
    goto code_r0x00100311;
  case 3:
    goto code_r0x001002de;
  case 4:
    goto code_r0x001002a9;
  case 5:
    goto code_r0x0010015a;
  case 6:
    lVar15 = *(longlong *)
              (*(longlong *)(param_3 + 0x10) + 0x28 + (longlong)*(int *)(param_3 + 0x28) * 8);
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10014a;
    func_0x(lVar15,0x18bc758,0x1258920);
    pcVar3 = *(char **)(lVar15 + 8);
    if (*pcVar3 != '\x03') {
      *(undefined4 *)(&stack0x00000028 + lVar11) = *(undefined4 *)(pcVar3 + 8);
    }
code_r0x0010015a:
    lVar15 = *(longlong *)
              (*(longlong *)(param_3 + 0x10) + 0x20 + (longlong)*(int *)(param_3 + 0x28) * 8);
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10017d;
    func_0x(lVar15,0x18dfe90,0x1258938);
    pauVar4 = *(undefined (**) [16])(lVar15 + 8);
    if ((*pauVar4)[0] == '\x03') {
code_r0x001002a9:
      lVar15 = *(longlong *)
                (*(longlong *)(param_3 + 0x10) + 0x18 + (longlong)*(int *)(param_3 + 0x28) * 8);
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1002cc;
      func_0x(lVar15,0x18bcb10,0x1258950);
      pcVar3 = *(char **)(lVar15 + 8);
      if (*pcVar3 != '\x03') {
        *(undefined8 *)(&stack0x00000030 + lVar11) = *(undefined8 *)(pcVar3 + 8);
      }
code_r0x001002de:
      lVar15 = *(longlong *)
                (*(longlong *)(param_3 + 0x10) + 0x10 + (longlong)*(int *)(param_3 + 0x28) * 8);
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100301;
      func_0x(lVar15,uRam000000000105ee30,0x1258970);
      pbVar20 = *(byte **)(lVar15 + 8);
      bVar21 = *pbVar20 != 3;
      if (!bVar21) {
        pbVar20 = pbVar12;
      }
      uVar14 = (uint)bVar21;
      goto code_r0x00100311;
    }
    auVar1 = *pauVar4;
    *(undefined (*) [16])(&stack0x00000040 + lVar11) = auVar1;
    uVar19 = *(undefined4 *)(pauVar4[1] + 4);
    uVar5 = *(undefined4 *)(pauVar4[1] + 8);
    uVar6 = *(undefined4 *)(pauVar4[1] + 0xc);
    *(undefined4 *)(&stack0x00000050 + lVar11) = *(undefined4 *)pauVar4[1];
    *(undefined4 *)(&stack0x00000054 + lVar11) = uVar19;
    *(undefined4 *)(&stack0x00000058 + lVar11) = uVar5;
    *(undefined4 *)(&stack0x0000005c + lVar11) = uVar6;
    *(ushort *)(&stack0x00000042 + lVar11) = auVar1._2_2_ & 0xfffe;
    (&stack0xfffffffffffffff0)[lVar11] = 0;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
    uVar13 = *(undefined8 *)(lVar15 + 0x18);
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1001d0;
    func_0x(&stack0x00000040 + lVar11,uVar13,0,0);
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1001e0;
    (*pcRam00000000018931f8)(&stack0x00000038 + lVar11,0,0);
    pbVar18 = *(byte **)(&stack0x00000048 + lVar11);
    if ((pbVar18 == (byte *)0x0) || (*(longlong *)(&stack0x00000038 + lVar11) <= (longlong)pbVar18))
    goto code_r0x001002a9;
    uVar10 = 0x80fc4a78;
    goto code_r0x00100206;
  default:
    uVar2 = *(ushort *)((undefined8 *)*param_2 + 1);
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = *(undefined8 *)*param_2;
    *(uint *)(&stack0xffffffffffffffe8 + lVar11) = (uint)uVar2;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100442;
    (*_DAT_)(0x51,0x2c,0x10,4);
  }
  uVar19 = *(undefined4 *)(&stack0x00000028 + lVar11);
code_r0x00100446:
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100456;
  (*_DAT_)(&stack0x00000068 + lVar11);
  if (((uVar9 == 0) || (pbVar20 == (byte *)0x0)) || (*pbVar20 == 3)) {
    *(undefined4 *)((longlong)auStackX_10 + lVar11) = 0;
    *(undefined4 *)((longlong)auStackX_8 + lVar11) = *(undefined4 *)(&stack0x00000028 + lVar11);
    *(byte **)((longlong)auStackX_18 + lVar11 + -0x18) = pbVar18;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar11) = 0;
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = *(undefined8 *)(&stack0x00000030 + lVar11);
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
    uVar13 = 0;
  }
  else {
    *(undefined4 *)((longlong)auStackX_10 + lVar11) = 0;
    *(undefined4 *)((longlong)auStackX_8 + lVar11) = *(undefined4 *)(&stack0x00000028 + lVar11);
    *(byte **)((longlong)auStackX_18 + lVar11 + -0x18) = pbVar18;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar11) = 0;
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = *(undefined8 *)(&stack0x00000030 + lVar11);
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = *(undefined4 *)(pbVar20 + 0x10);
    uVar13 = *(undefined8 *)(pbVar20 + 8);
  }
  lVar15 = *(longlong *)(pbVar12 + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1004d4;
  uVar10 = func_0x(_DAT_ + 0x38,lVar15 + 8,uVar19,uVar13);
  **(undefined **)(pbVar12 + 8) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1004eb;
  (*_DAT_)(&stack0x00000068 + lVar11);
  if ((int)uVar10 < 0) {
code_r0x00100206:
    uVar16 = uVar10 & 0xffff;
    uVar14 = uVar16;
    if ((uVar10 & 0x1fff0000) != 0xfc0000) {
      uVar14 = 0;
    }
    if (((uVar14 == 0) || ((uVar10 & 0x1fff0000) != 0xfc0000)) ||
       ((uVar16 / 100 != 0xbe || (iVar17 = uVar16 - 0x4a6a, 0x14 < uVar16 - 0x4a6b)))) {
      iVar17 = 0xc;
      if (uVar9 == 0) {
        iVar17 = 1;
      }
      lVar15 = 0x11d4090;
      if (_DAT_ != 0) {
        lVar15 = _DAT_;
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10028c;
      uVar13 = (*_DAT_)(uVar10,&stack0x00000078 + lVar11,0,0);
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = uVar13;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1002a4;
      func_0x(0x4a99,10,1,lVar15);
    }
    *(int *)(param_4 + 8) = iVar17;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100519;
    (*_DAT_)(0xbe,iVar17 + 0x32,0x10,1);
  }
  else {
    *(undefined4 *)(param_4 + 8) = 0;
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100529;
  func_0x
            (*(ulonglong *)(&stack0x00001078 + lVar11) ^
             (ulonglong)(&stack0xffffffffffffffc8 + lVar11));
  return;
code_r0x00100311:
  uVar9 = uVar14;
  lVar15 = *(longlong *)(*(longlong *)(param_3 + 0x10) + 8 + (longlong)*(int *)(param_3 + 0x28) * 8)
  ;
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100334;
  func_0x(lVar15,0x18dff10,0x11fa378);
  uVar19 = *(undefined4 *)(*(longlong *)(lVar15 + 8) + 8);
  pbVar12 = *(byte **)(*(longlong *)(param_3 + 0x10) + (longlong)*(int *)(param_3 + 0x28) * 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100360;
  func_0x(pbVar12,0x18bc758,0x1258988);
  if ((*pbVar12 & 1) == 0) {
    uVar13 = *(undefined8 *)*param_2;
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = 0x1258988;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = uVar13;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100391;
    (*_DAT_)(5,0x5b,0x10,0x39);
  }
  goto code_r0x00100446;
}

