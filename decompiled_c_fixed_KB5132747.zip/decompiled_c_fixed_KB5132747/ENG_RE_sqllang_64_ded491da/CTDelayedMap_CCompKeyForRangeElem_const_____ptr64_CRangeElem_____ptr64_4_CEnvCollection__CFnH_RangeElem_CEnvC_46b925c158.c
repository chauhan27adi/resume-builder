
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(uint *param_1,longlong *param_2)

{
  int iVar1;
  int iVar2;
  longlong lVar3;
  longlong lVar4;
  char cVar5;
  undefined8 uVar6;
  uint uVar7;
  
  if (*(longlong *)(param_1 + 0x14) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar7 = 0;
  if (*param_1 != 0) {
    do {
      lVar3 = *param_2;
      lVar4 = *(longlong *)(param_1 + (ulonglong)uVar7 * 4 + 2);
      if ((*(int *)(lVar4 + 8) == *(int *)(lVar3 + 8)) &&
         (*(int *)(lVar4 + 0x18) == *(int *)(lVar3 + 0x18))) {
        if (*(int *)(lVar4 + 0x18) == 0xb) {
          iVar1 = *(int *)(lVar4 + 0x28);
          iVar2 = *(int *)(lVar3 + 0x28);
          if (iVar1 == iVar2) {
            uVar6 = (*_DAT_)();
            cVar5 = (*_DAT_)(uVar6,*(undefined8 *)(lVar4 + 0x20),iVar1,
                                     *(undefined8 *)(lVar3 + 0x20),iVar2);
            if (cVar5 != '\0') goto LAB_;
          }
          if (*(int *)(lVar4 + 0x18) == 0xb) goto LAB_;
        }
        if (*(int *)(lVar4 + 0xc) == *(int *)(lVar3 + 0xc)) {
LAB_:
          return *(undefined8 *)(param_1 + (ulonglong)uVar7 * 4 + 4);
        }
      }
LAB_:
      uVar7 = uVar7 + 1;
    } while (uVar7 < *param_1);
  }
  return 0;
}

