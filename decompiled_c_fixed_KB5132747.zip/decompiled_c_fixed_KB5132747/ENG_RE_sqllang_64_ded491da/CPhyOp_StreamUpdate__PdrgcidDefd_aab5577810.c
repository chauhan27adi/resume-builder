
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = *(longlong *)(param_1 + 0xd8);
  if (lVar1 == 0) {
    lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x90) + 0x28);
    if ((lVar1 == 0) || ((*(int *)(lVar1 + 0x70) != 0 && ((*(uint *)(lVar1 + 0x1c) >> 2 & 1) == 0)))
       ) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar1 = (*_DAT_)(0x30,*(undefined8 *)(param_1 + 0x10),0x1fe0f88,0x8b7,1);
    if (lVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar2 = func_0x(lVar1,*(undefined8 *)(param_1 + 0x10),*(undefined8 *)(param_1 + 0x98),
                            *(longlong *)(*(longlong *)(param_1 + 0x90) + 0x28) + 0xb0);
    *(undefined8 *)(param_1 + 0xd8) = uVar2;
    func_0x(*(undefined8 *)(param_1 + 0xd8),*(undefined8 *)(param_1 + 0x60));
    if (*(longlong *)(param_1 + 0x50) != 0) {
      func_0x(*(undefined8 *)(param_1 + 0xd8));
    }
    if (*(longlong *)(param_1 + 0x70) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x90) + 0x28);
    if ((lVar1 != 0) && (*(int *)(lVar1 + 0x70) == 0xfe)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(longlong *)(param_1 + 0xf0) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar1 = *(longlong *)(param_1 + 0xd8);
  }
  return lVar1;
}

