
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_(longlong *param_1,undefined8 *param_2,longlong param_3,longlong param_4,
                     longlong param_5,char param_6)

{
  int *piVar1;
  undefined8 *puVar2;
  char cVar3;
  int iVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong lVar8;
  longlong unaff_GS_OFFSET;
  undefined uStack_d8;
  byte bStack_d7;
  longlong *plStack_d0;
  longlong lStack_c8;
  longlong lStack_c0;
  undefined8 *puStack_b8;
  undefined uStack_b0;
  undefined2 uStack_af;
  char cStack_ad;
  longlong lStack_a8;
  undefined8 *puStack_a0;
  undefined8 uStack_98;
  byte abStack_90 [16];
  short sStack_80;
  undefined8 uStack_70;
  undefined auStack_68 [8];
  longlong *plStack_60;
  undefined8 *puStack_50;
  
  uStack_70 = 0xfffffffffffffffe;
  if (param_4 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_5 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar5 = (**(code **)(*param_1 + 0x1d0))();
  cVar3 = func_0x(uVar5,param_2);
  if ((cVar3 != '\0') && (*(longlong *)(param_1[0x1e] + 0x48) != 0)) {
    uVar5 = (**(code **)*param_2)(param_2);
    abStack_90[0] = 0;
    sStack_80 = 0;
    func_0x(uVar5,abStack_90);
    if ((sStack_80 != -1) &&
       (*(char *)((ulonglong)*(byte *)((ulonglong)abStack_90[0] + 0x1f64390) + 0x2a41b38) == '\0'))
    {
      if (param_3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      lVar7 = *(longlong *)
               (*(longlong *)
                 ((ulonglong)*_DAT_ +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8) +
               0x48);
      plVar6 = (longlong *)(lVar7 + 0x310);
      if (lVar7 == 0) {
        plVar6 = (longlong *)0x318;
      }
      lStack_a8 = *plVar6;
      if ((param_6 != '\0') && ((*(uint *)(lStack_a8 + 0x20) >> 10 & 1) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uStack_98 = 0;
      puStack_a0 = param_2;
      lVar7 = func_0x(param_1 + 10,abStack_90,&puStack_a0);
      lVar7 = *(longlong *)(lVar7 + 8);
      if (lVar7 != 0) {
        *(int *)(lVar7 + 8) = *(int *)(lVar7 + 8) + 1;
LAB_:
        cVar3 = func_0x(param_1[0x1e]);
        if (cVar3 == '\0') {
          return lVar7;
        }
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(char *)((longlong)param_2 + 0xc) == '0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar5 = *(undefined8 *)(lStack_a8 + 0x10);
      lStack_c8 = param_1[0x1e];
      uStack_d8 = 0;
      plStack_d0 = (longlong *)0x0;
      lVar8 = *(longlong *)
               (*(longlong *)
                 ((ulonglong)*_DAT_ +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8) +
               0x48);
      lStack_c0 = lVar8 + -8;
      if (lVar8 == 0) {
        lStack_c0 = 0;
      }
      bStack_d7 = (byte)(*(uint *)(**(longlong **)
                                     (*(longlong *)(*(longlong *)(lStack_c0 + 0x28) + 0x20) + 0x40)
                                  + 8) >> 4) & 1;
      uStack_af = 0x100;
      cStack_ad = 0;
      if (*(char *)(param_1 + 0x1f) != '\0') {
        puStack_b8 = param_2;
        cVar3 = func_0x(param_2);
        if (cVar3 != '\0') {
          uStack_b0 = 1;
          uStack_af = 0x100;
          cStack_ad = '\0';
          iVar4 = -1;
          do {
            plVar6 = (longlong *)func_0x(&uStack_d8);
            if (plVar6 == (longlong *)0x0) break;
            iVar4 = (**(code **)(*plVar6 + 8))(plVar6);
            lVar7 = *(longlong *)(param_1[0x1e] + 0xa8);
            if (lVar7 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            func_0x(auStack_68,param_1[9],plVar6,*(undefined8 *)(lVar7 + 0x38),param_1[0x1e]
                           );
            param_5._0_1_ = '\0';
            lVar7 = func_0x(uVar5,param_1[0x1e],auStack_68,&param_5,0);
            if ((char)param_5 != '\0') {
              uStack_b0 = 0;
            }
            if (plStack_60 != (longlong *)0x0) {
              (**(code **)(*plStack_60 + 0x68))();
            }
            puVar2 = puStack_50;
            if (puStack_50 != (undefined8 *)0x0) {
              *puStack_50 = 0x1f96800;
              (*_DAT_)(puStack_50[2]);
              (*_DAT_)(puVar2,0x58);
            }
            puStack_50 = (undefined8 *)0x0;
          } while (lVar7 == 0);
          if (cStack_ad != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (plStack_d0 != (longlong *)0x0) {
            (**(code **)(*plStack_d0 + 0x10))(plStack_d0,1);
          }
          if (lVar7 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (iVar4 != -1) {
            lVar8 = func_0x(param_1[9],param_1,iVar4);
            lVar7 = func_0x(lVar7,param_1[9],lVar8,0);
            if (lVar8 != 0) {
              piVar1 = (int *)(lVar8 + 8);
              *piVar1 = *piVar1 + -1;
              if (*piVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
            }
          }
          func_0x(param_1 + 10,param_2,lVar7);
          goto LAB_;
        }
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

