
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1,undefined8 param_2,longlong param_3)

{
  char cVar1;
  int iVar2;
  
  if (param_3 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar2 = func_0x(param_3);
  if (*(longlong *)(param_1 + 0x28) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(uint *)(param_1 + 0x20) < (uint)(iVar2 + *(int *)(param_1 + 0x1c))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  cVar1 = func_0x();
  if (cVar1 == '\0') {
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

