
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2)

{
  undefined4 uVar1;
  longlong lVar2;
  int *piVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  longlong lVar8;
  longlong lVar9;
  longlong unaff_GS_OFFSET;
  undefined8 uStackX_8;
  ulonglong uStackX_10;
  ulonglong uStackX_18;
  undefined auStack_2a8 [8];
  undefined4 uStack_2a0;
  undefined4 uStack_298;
  ulonglong **ppuStack_290;
  undefined *puStack_288;
  undefined8 uStack_280;
  ulonglong *puStack_278;
  undefined8 uStack_270;
  undefined auStack_268 [528];
  undefined8 uStack_58;
  undefined8 uStack_50;
  ulonglong uStack_48;
  undefined4 uStack_40;
  
  lVar9 = *(longlong *)(param_1 + 0x20);
  if (((DAT_ != '\0') || ((*(byte *)(_DAT_ + 0x5c4) & 8) != 0)) &&
     (*(longlong *)(param_1 + 0x18) != 0)) {
    func_0x(0x65e7,(int)*(short *)(*(longlong *)(param_1 + 0x18) + 0x10));
  }
  lVar2 = *(longlong *)(lVar9 + 0x30);
  if ((lVar2 == 0) || (*(longlong *)(lVar9 + 0x28) == 0)) {
    *(undefined8 *)(param_2 + 0x2a0) = 0;
  }
  else {
    lVar8 = (ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    *(longlong *)(lVar8 + 8) = lVar2;
    *(longlong *)(*(longlong *)(*(longlong *)(lVar8 + 0x100) + 0x40) + 8) = lVar2;
    func_0x(*(undefined8 *)(lVar9 + 0x28));
    lVar2 = *(longlong *)
             (*(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
              0x50 + (ulonglong)*_DAT_);
    (*_DAT_)(&uStackX_8,0,0);
    *(undefined8 *)(lVar2 + 0xe8) = uStackX_8;
    uVar7 = 0;
    uVar4 = 0xffffffffffffffff;
    if ((_DAT_ & 0x20000) != 0) {
      ppuStack_290 = &puStack_278;
      uStack_2a0 = 0x10000;
      puStack_288 = auStack_268;
      puStack_278 = &uStack_48;
      uStack_298 = 0;
      uStack_58 = 0;
      uStack_280 = 0;
      uStack_50 = 0;
      uStack_270 = 0xc;
      uVar6 = _DAT_;
      if (*_DAT_ != 0) {
        (*_DAT_)(&uStackX_10);
        uVar6 = uStackX_10;
      }
      uVar5 = uVar7;
      if ((uVar6 < *(ulonglong *)(param_2 + 0x2a0)) ||
         (uVar5 = uVar6 - *(ulonglong *)(param_2 + 0x2a0), uStack_48 = uVar4,
         uVar5 != 0xffffffffffffffff)) {
        if (*_DAT_ == 0) {
          uStack_48 = uVar5 / 10;
        }
        else {
          uStack_48 = (uVar5 * 1000000) / *_DAT_;
        }
      }
      uStack_40 = *(undefined4 *)(lVar9 + 0x54);
      func_0x(auStack_2a8);
    }
    if ((*_DAT_ != '\0') && ((*(uint *)(_DAT_ + 0x3c) & 0x10000) != 0)) {
      lVar2 = *(longlong *)
               (*(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                + 8 + (ulonglong)*_DAT_);
      if ((lVar2 != 0) &&
         ((piVar3 = *(int **)(lVar2 + 0x30), piVar3 != (int *)0x0 && (*piVar3 == 0)))) {
        lVar2 = *(longlong *)
                 (*(longlong *)
                   (*(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                   (ulonglong)*_DAT_) + 0x30);
        uVar6 = _DAT_;
        if (*_DAT_ != 0) {
          (*_DAT_)(&uStackX_18);
          uVar6 = uStackX_18;
        }
        if ((uVar6 < *(ulonglong *)(param_2 + 0x2a0)) ||
           (uVar7 = uVar6 - *(ulonglong *)(param_2 + 0x2a0), uVar7 != 0xffffffffffffffff)) {
          if (*_DAT_ == 0) {
            uVar4 = uVar7 / 10;
          }
          else {
            uVar4 = (uVar7 * 1000000) / *_DAT_;
          }
        }
        *(uint *)(lVar2 + 0xc) = *(uint *)(lVar2 + 0xc) | 0x2000;
        *(ulonglong *)(lVar2 + 0x4f8) = uVar4;
        uVar1 = *(undefined4 *)(lVar9 + 0x54);
        *(uint *)(lVar2 + 0x10) = *(uint *)(lVar2 + 0x10) | 0x20000;
        *(undefined4 *)(lVar2 + 0x78) = uVar1;
        func_0x(_DAT_ + 0x38,0x10);
      }
    }
    func_0x(*(undefined8 *)(lVar9 + 0x28));
    lVar9 = (ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    *(undefined8 *)(lVar9 + 8) = 0;
    *(undefined8 *)(*(longlong *)(*(longlong *)(lVar9 + 0x100) + 0x40) + 8) = 0;
    if (*_DAT_ != '\0') {
      (*_DAT_)(_DAT_,0xf,0x40,1,0);
    }
    *(undefined8 *)(param_2 + 0x2a0) = 0;
  }
  return;
}

