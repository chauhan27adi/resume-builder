
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x002a81f3) */
/* WARNING: Removing unreachable block (ram,0x01688085) */
/* WARNING: Removing unreachable block (ram,0x00100730) */
/* WARNING: Removing unreachable block (ram,0x00100736) */
/* WARNING: Removing unreachable block (ram,0x00100743) */
/* WARNING: Removing unreachable block (ram,0x00100749) */
/* WARNING: Removing unreachable block (ram,0x00100756) */
/* WARNING: Removing unreachable block (ram,0x0010075f) */
/* WARNING: Removing unreachable block (ram,0x00100765) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8
FUN_(undefined8 param_1,longlong param_2,undefined8 *param_3,undefined8 param_4,
            longlong param_5)

{
  undefined8 *puVar1;
  undefined uVar2;
  undefined4 uVar3;
  longlong *plVar4;
  longlong lVar5;
  int iVar6;
  longlong lVar7;
  longlong lVar8;
  undefined8 *puVar9;
  undefined8 *puVar10;
  undefined8 *puVar11;
  undefined8 uVar12;
  int iVar13;
  uint uVar14;
  uint uVar15;
  uint uVar16;
  undefined8 *puStackX_18;
  undefined8 uStack_d8;
  undefined8 uStack_b8;
  undefined4 uStack_b0;
  undefined8 uStack_a8;
  undefined uStack_a0;
  uint uStack_9c;
  uint uStack_98;
  longlong lStack_90;
  longlong *plStack_88;
  longlong lStack_80;
  longlong lStack_78;
  undefined8 *puStack_70;
  longlong lStack_68;
  longlong lStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  
  uStack_48 = 0xfffffffffffffffe;
  plVar4 = (longlong *)param_3[2];
  lStack_60 = *(longlong *)param_3[4];
  lVar5 = ((longlong *)param_3[4])[1];
  puStackX_18 = param_3;
  plStack_88 = plVar4;
  puStack_70 = (undefined8 *)param_1;
  lVar7 = (**(code **)(*plVar4 + 0x420))(plVar4);
  lStack_78 = lVar7;
  lVar8 = (**(code **)(*plVar4 + 0x2b0))(plVar4);
  lStack_68 = plVar4[9];
  uVar15 = 0;
  if (*(uint *)(lVar5 + 0x18) != 0) {
    do {
      if ((*(byte *)(*(longlong *)
                      (**(longlong **)
                         (*(longlong *)(*(longlong *)(lVar5 + 0x20) + (longlong)(int)uVar15 * 8) +
                         0x20) + 0x10) + 0x50) & 0x10) != 0) {
        return 0;
      }
      uVar15 = uVar15 + 1;
    } while (uVar15 < *(uint *)(lVar5 + 0x18));
  }
  if (lStack_68 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_d8 = 0;
  lStack_80 = 0;
  (**(code **)(*plStack_88 + 0x2b0))();
  func_0x(param_1,lVar5);
  uStack_58 = 0;
  uStack_50 = 0;
  uStack_a0 = 0;
  uStack_9c = 0;
  uStack_98 = 4;
  lStack_90 = 0;
  uStack_b0 = 1;
  uStack_b8 = 0x210b490;
  uStack_a8 = param_1;
  puVar9 = (undefined8 *)func_0x(param_1,lVar5);
  lVar5 = lStack_78;
  uVar15 = *(uint *)(lVar7 + 0x1c);
  uVar16 = 0;
  if (uVar15 != 0) {
    lVar7 = 0;
    uVar14 = uStack_9c;
    do {
      if (*(uint *)(lVar5 + 0x1c) <= uVar16) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar12 = *(undefined8 *)(lVar7 + *(longlong *)(lVar5 + 0x28));
      iVar6 = func_0x(lVar8,uVar12,0);
      if ((iVar6 == -1) && (iVar6 = func_0x(puVar9,uVar12,0), iVar6 == -1)) {
        if (lStack_90 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (uStack_98 <= uVar14) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *(undefined8 *)(lStack_90 + (ulonglong)uVar14 * 8) = uVar12;
        uVar14 = uStack_9c + 1;
        uStack_9c = uVar14;
      }
      uVar16 = uVar16 + 1;
      lVar7 = lVar7 + 8;
      uStack_d8 = uStack_58;
      param_1 = puStack_70;
    } while (uVar16 < uVar15);
  }
  puVar10 = puVar9 + 1;
  *(int *)puVar10 = *(int *)puVar10 + -1;
  if (*(int *)puVar10 == 0) {
    (**(code **)*puVar9)(puVar9,1);
  }
  uVar3 = *(undefined4 *)((longlong)plStack_88 + 0x5c);
  lVar5 = plStack_88[0xc];
  puVar9 = (undefined8 *)func_0x(param_1,uStack_d8);
  puVar10 = (undefined8 *)(*_DAT_)(0x30,param_1,0x210bda8,0x192b,1);
  if (puVar10 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar13 = *(int *)((longlong)puVar9 + 0x1c) + *(int *)(lVar8 + 0x1c) + uStack_9c;
  puVar10[2] = param_1;
  *(undefined *)(puVar10 + 3) = 0;
  *(undefined4 *)((longlong)puVar10 + 0x1c) = 0;
  iVar6 = 1;
  if (iVar13 != 0) {
    iVar6 = iVar13;
  }
  *(int *)(puVar10 + 4) = iVar6;
  puVar10[5] = 0;
  *puVar10 = 0x20440a8;
  *(undefined4 *)(puVar10 + 1) = 1;
  *puVar10 = 0x210b490;
  puStack_70 = puVar10;
  func_0x(puVar10,puVar9);
  puVar1 = puVar9 + 1;
  *(int *)puVar1 = *(int *)puVar1 + -1;
  if (*(int *)puVar1 == 0) {
    (**(code **)*puVar9)(puVar9,1);
  }
  func_0x(puVar10,lVar8);
  func_0x(puVar10,&uStack_b8);
  *(int *)(lVar8 + 8) = *(int *)(lVar8 + 8) + 1;
  if (lStack_68 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(byte *)(param_2 + 0x6a) & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (lVar5 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar9 = (undefined8 *)(*_DAT_)(0x68,param_1,0x210bda8,0x1945,1);
  lVar5 = lStack_60;
  if (puVar9 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar9 = 0x20440a8;
  *(undefined4 *)(puVar9 + 1) = 1;
  *puVar9 = 0x1fb7960;
  puVar9[2] = param_1;
  *puVar9 = 0x1f7b558;
  *puVar9 = 0x1f8a2a0;
  puVar9[3] = puVar10;
  puVar9[4] = lVar8;
  puVar9[5] = 0;
  *(undefined *)(puVar9 + 6) = 0;
  *puVar9 = 0x1f898b0;
  *(undefined *)(puVar9 + 7) = 0;
  *(undefined4 *)((longlong)puVar9 + 0x3c) = 1;
  *(undefined2 *)(puVar9 + 8) = 0;
  puVar9[9] = lStack_68;
  puVar9[10] = 0;
  *(undefined *)(puVar9 + 0xb) = 0;
  *(undefined4 *)((longlong)puVar9 + 0x5c) = uVar3;
  puVar9[0xc] = 0;
  *(int *)(lStack_60 + 8) = *(int *)(lStack_60 + 8) + 1;
  puVar10 = (undefined8 *)(*_DAT_)(0xa8,param_1,0x210bda8,0x1952,1);
  lVar7 = lStack_78;
  if (puVar10 != (undefined8 *)0x0) {
    *puVar10 = 0x20440a8;
    *(undefined4 *)(puVar10 + 1) = 1;
    *puVar10 = 0x205df68;
    puVar10[0xc] = 0;
    puVar10[0xd] = 0;
    puVar10[0xe] = 0;
    puVar10[0xf] = 0;
    puVar10[0x11] = _DAT_;
    puVar10[0x12] = 0;
    puVar10[0x13] = 0;
    puVar10[0x14] = 0;
    *(undefined4 *)(puVar10 + 3) = 2;
    puVar10[4] = puVar10 + 5;
    puVar10[5] = lVar5;
    *(undefined8 *)(puVar10[4] + 8) = uStack_58;
    puVar10[2] = puVar9;
    puVar10[10] = 0;
    puVar10[0xb] = 0;
    puVar10[0x10] = 0;
    if (param_5 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (lStack_80 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(int *)(lStack_78 + 8) = *(int *)(lStack_78 + 8) + 1;
    *(int *)(lVar8 + 8) = *(int *)(lVar8 + 8) + 1;
    iVar6 = 2;
    if ((*(int *)((longlong)plStack_88 + 0x3c) - 1U & 0xfffffffd) == 0) {
      iVar6 = *(int *)((longlong)plStack_88 + 0x3c);
    }
    puVar9 = (undefined8 *)(*_DAT_)(0x68,param_1,0x210bda8,0x1976,1);
    if (puVar9 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar2 = *(undefined *)(plStack_88 + 7);
    *puVar9 = 0x20440a8;
    *(undefined4 *)(puVar9 + 1) = 1;
    *puVar9 = 0x1fb7960;
    puVar9[2] = param_1;
    *puVar9 = 0x1f7b558;
    *puVar9 = 0x1f8a2a0;
    puVar9[3] = lVar7;
    puVar9[4] = lVar8;
    puVar9[5] = 0;
    *(undefined *)(puVar9 + 6) = 0;
    *puVar9 = 0x1f898b0;
    *(undefined *)(puVar9 + 7) = uVar2;
    *(int *)((longlong)puVar9 + 0x3c) = iVar6;
    *(undefined2 *)(puVar9 + 8) = 0;
    puVar9[9] = 0;
    puVar9[10] = 0;
    *(undefined *)(puVar9 + 0xb) = 0;
    *(undefined4 *)((longlong)puVar9 + 0x5c) = uVar3;
    puVar9[0xc] = 0;
    puVar11 = (undefined8 *)(*_DAT_)(0xa8,param_1,0x210bda8,0x1983,1);
    puVar1 = puStackX_18;
    if (puVar11 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *puVar11 = 0x20440a8;
    *(undefined4 *)(puVar11 + 1) = 1;
    *puVar11 = 0x205df68;
    puVar11[0xc] = 0;
    puVar11[0xd] = 0;
    puVar11[0xe] = 0;
    puVar11[0xf] = 0;
    puVar11[0x11] = _DAT_;
    puVar11[0x12] = 0;
    puVar11[0x13] = 0;
    puVar11[0x14] = 0;
    *(undefined4 *)(puVar11 + 3) = 2;
    puVar11[4] = puVar11 + 5;
    puVar11[5] = puVar10;
    *(undefined8 *)(puVar11[4] + 8) = uStack_50;
    puVar11[2] = puVar9;
    puVar11[10] = 0;
    puVar11[0xb] = 0;
    puVar11[0x10] = 0;
    func_0x(puVar11,puStackX_18[0xe]);
    plVar4 = *(longlong **)(puVar1[10] + 0x108);
    if (plVar4 != (longlong *)0x0) {
      (**(code **)(*plVar4 + 8))(plVar4,&puStackX_18);
      puVar11[0x11] = puStackX_18;
      uVar12 = func_0x(param_1,puVar11,lStack_78);
      uStack_b8 = 0x20440a8;
      puStackX_18 = &uStack_a8;
      func_0x(&uStack_a8);
      if (lStack_90 != 0) {
        (*_DAT_)();
      }
      return uVar12;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

