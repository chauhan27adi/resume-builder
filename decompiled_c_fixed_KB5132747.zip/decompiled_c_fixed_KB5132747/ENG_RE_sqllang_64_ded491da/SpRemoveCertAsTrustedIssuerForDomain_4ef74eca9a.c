
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,ulonglong **param_2,longlong param_3,longlong param_4)

{
  ulonglong uVar1;
  byte *pbVar2;
  undefined4 *puVar3;
  byte bVar4;
  undefined4 **ppuVar5;
  char cVar6;
  char cVar7;
  int iVar8;
  undefined4 uVar9;
  undefined8 uVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong lVar13;
  undefined8 *puVar14;
  longlong lVar15;
  longlong lVar16;
  uint uVar17;
  longlong unaff_GS_OFFSET;
  undefined auStack_3b8 [32];
  undefined8 uStack_398;
  undefined8 uStack_390;
  undefined8 uStack_388;
  undefined4 *puStack_380;
  undefined8 uStack_378;
  undefined4 *puStack_370;
  undefined8 uStack_368;
  ulonglong uStack_360;
  undefined8 uStack_358;
  undefined4 uStack_350;
  byte bStack_348;
  uint uStack_344;
  undefined8 uStack_340;
  undefined4 uStack_338;
  undefined auStack_330 [16];
  undefined8 uStack_320;
  longlong *plStack_318;
  undefined4 uStack_308;
  undefined4 uStack_304;
  undefined4 uStack_300;
  undefined4 uStack_2fc;
  undefined auStack_2f8 [8];
  undefined4 uStack_2f0;
  undefined4 uStack_2e8;
  undefined4 **ppuStack_2e0;
  undefined *puStack_2d8;
  undefined8 uStack_2d0;
  undefined4 *puStack_2c8;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined8 uStack_2b8;
  undefined4 uStack_2b0;
  undefined4 uStack_2ac;
  undefined auStack_2a8 [512];
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined4 auStack_98 [4];
  short asStack_88 [32];
  ulonglong uStack_48;
  
  uStack_320 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_3b8;
  *(undefined4 *)(param_4 + 8) = 1;
  uVar1 = **param_2;
  uVar17 = (uint)*(ushort *)(*param_2 + 1);
  if ((param_3 == 0) ||
     (iVar8 = *(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28),
     *(int *)(param_3 + 0x1c) == *(int *)(param_3 + 0x28))) {
    puStack_380 = (undefined4 *)0x14dbc68;
    uStack_388 = CONCAT44(uStack_388._4_4_,0x1a);
  }
  else {
    if (iVar8 != 1) {
      if (2 < iVar8) {
        *(undefined4 *)(param_4 + 8) = 0x1fd0;
        uStack_398 = CONCAT44(uStack_398._4_4_,uVar17);
        uStack_390 = uVar1;
        (*_DAT_)(0x51,0x2c,0x10,1);
      }
      goto LAB_;
    }
    puStack_380 = (undefined4 *)0x14dbc58;
    uStack_388 = CONCAT44(uStack_388._4_4_,0xe);
  }
  *(undefined4 *)(param_4 + 8) = 0xc9;
  uStack_398 = CONCAT44(uStack_398._4_4_,uVar17);
  uStack_390 = uVar1;
  (*_DAT_)(2,1,0x10,1);
LAB_:
  lVar13 = *(longlong *)(*(longlong *)(param_3 + 0x10) + (longlong)*(int *)(param_3 + 0x28) * 8);
  if (**(char **)(lVar13 + 0x18) == '8') {
    if (**(char **)(lVar13 + 8) == '\x03') {
      uStack_388 = 0x14dbd18;
      uStack_390 = CONCAT44(uStack_390._4_4_,0x1c);
      uStack_398 = 0x1080aa8;
      (*_DAT_)(2,0x19,0x10,1);
    }
  }
  else {
    uStack_390 = (*_DAT_)(CONCAT71((int7)(int3)((uint)*(int *)(param_3 + 0x28) >> 8),0x38));
    uStack_398 = 0x14dbd18;
    (*_DAT_)(2,0xe,0x10,0xd4);
  }
  lVar16 = *(longlong *)(*(longlong *)(param_3 + 0x10) + 8 + (longlong)*(int *)(param_3 + 0x28) * 8)
  ;
  if (**(char **)(lVar16 + 0x18) == -0x19) {
    if (**(char **)(lVar16 + 8) == '\x03') {
      uStack_388 = 0x14dbd00;
      uStack_390 = CONCAT44(uStack_390._4_4_,0x10);
      uStack_398 = 0x1080aa8;
      (*_DAT_)(2,0x19,0x10,1);
    }
  }
  else {
    uStack_390 = (*_DAT_)(CONCAT71((int7)(int3)((uint)*(int *)(param_3 + 0x28) >> 8),0xe7));
    uStack_398 = 0x14dbd00;
    (*_DAT_)(2,0xe,0x10,0xd4);
  }
  pbVar2 = *(byte **)(lVar16 + 0x18);
  if ((*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar2 + 0x1090570) + 0x10ded30) != '\0') &&
     (*(short *)(pbVar2 + 0x10) == -1)) {
    uStack_390 = (*_DAT_)(CONCAT71((int7)((ulonglong)pbVar2 >> 8),0xe7));
    uStack_398 = 0x14dbd00;
    (*_DAT_)(2,0xe,0x10,2);
  }
  puVar3 = *(undefined4 **)(*(longlong *)(lVar16 + 8) + 8);
  uVar17 = *(uint *)(*(longlong *)(lVar16 + 8) + 0x10);
  if (0x1fa < (uVar17 & 0xfffffffe)) {
    *(undefined4 *)(param_4 + 8) = 0x3b2f;
    (*_DAT_)(0x176,0x33,0x10,1);
  }
  uStack_340 = 0;
  uVar1 = **param_2;
  uStack_344 = (uint)*(ushort *)(*param_2 + 1);
  uStack_338 = 1;
  auStack_330._0_8_ =
       *(longlong **)
        (*(longlong *)
          ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
        0x90);
  auStack_330._8_8_ = 0;
  cVar7 = *(char *)(*(longlong *)
                     ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
                   0x98);
  cVar6 = (**(code **)(*(longlong *)auStack_330._0_8_ + 0x1d0))();
  if (cVar6 == '\0') {
    uStack_378 = CONCAT44(uStack_378._4_4_,(uint)(cVar7 != '\0'));
    puStack_380 = (undefined4 *)0x0;
    uStack_388 = uStack_388 & 0xffffffffffffff00;
    uStack_390 = CONCAT44(uStack_390._4_4_,1);
    uStack_398 = CONCAT44(uStack_398._4_4_,2);
    (**(code **)(*(longlong *)auStack_330._0_8_ + 8))(auStack_330._0_8_,uVar1,uStack_344,1);
    uStack_340 = CONCAT44(uStack_340._4_4_,1);
  }
  else {
    if ((cVar7 != '\0') &&
       (cVar7 = (**(code **)(*(longlong *)auStack_330._0_8_ + 0x1e8))(), cVar7 != '\0')) {
      uStack_398 = 0;
      (*_DAT_)(1,0x1591ed0,0x1580ab8,0xeb);
    }
    (**(code **)(*(longlong *)auStack_330._0_8_ + 0xe8))
              (auStack_330._0_8_,2,1,(longlong)&uStack_340 + 4);
    uStack_338 = 1;
    uStack_340 = CONCAT44(uStack_340._4_4_,3);
  }
  uVar10 = (**(code **)(*(longlong *)auStack_330._0_8_ + 0x1b0))();
  lVar15 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar16 = *(longlong *)(lVar15 + 0x100);
  if (lVar16 == 0) {
    (*_DAT_)();
    lVar16 = *(longlong *)(lVar15 + 0x100);
  }
  plVar11 = (longlong *)(**_DAT_)(*(undefined8 *)(lVar16 + 1000),uVar10,0x14dbaf0,0xc5d);
  uStack_344 = (uint)*(ushort *)
                      (*(longlong *)
                        (*(longlong *)
                          ((ulonglong)*_DAT_ +
                          *(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
                        + 0x50) + 8);
  uStack_390 = uStack_390 & 0xffffffff00000000;
  uStack_398 = uStack_398 & 0xffffffff00000000;
  plStack_318 = plVar11;
  plVar12 = (longlong *)(**(code **)(*plVar11 + 0x38))(plVar11,uStack_344,0,0);
  plVar12 = (longlong *)
            (**(code **)(*plVar12 + 0x328))
                      (plVar12,*(undefined4 *)(*(longlong *)(lVar13 + 8) + 8),1);
  if (plVar12 == (longlong *)0x0) {
    asStack_88[0] = 0;
    func_0x
              (asStack_88,0x20,0x10cc460,*(undefined4 *)(*(longlong *)(lVar13 + 8) + 8));
    *(undefined4 *)(param_4 + 8) = 0x3b2f;
    lVar13 = -1;
    do {
      lVar13 = lVar13 + 1;
    } while (asStack_88[lVar13] != 0);
    uStack_388 = lVar13 * 2;
    puStack_380 = (undefined4 *)asStack_88;
    uStack_390 = CONCAT44(uStack_390._4_4_,0x8ac9);
    uStack_398 = CONCAT44(uStack_398._4_4_,0x333e);
    (*_DAT_)(0x97,0x33,0x10,1);
  }
  lVar16 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar13 = *(longlong *)(lVar16 + 0x100);
  if (lVar13 == 0) {
    (*_DAT_)(0);
    lVar13 = *(longlong *)(lVar16 + 0x100);
  }
  uVar10 = *(undefined8 *)(lVar13 + 1000);
  uVar9 = (**(code **)(*plVar12 + 8))();
  uStack_360 = 0;
  uStack_368 = 0;
  puStack_370 = (undefined4 *)((ulonglong)puStack_370 & 0xffffffffffffff00);
  uStack_378 = CONCAT71(uStack_378._1_7_,1);
  puStack_380 = (undefined4 *)((ulonglong)puStack_380 & 0xffffffff00000000);
  uStack_388 = CONCAT44(uStack_388._4_4_,0xffffffff);
  uStack_390 = uStack_390 & 0xffffffff00000000;
  uStack_398 = CONCAT44(uStack_398._4_4_,uVar9);
  cVar7 = func_0x(0x4c414358,uVar10,plVar11,uStack_344);
  bStack_348 = cVar7 != '\0';
  uStack_308 = _DAT_;
  uStack_304 = uRam0000000000f5e024;
  uStack_300 = uRam0000000000f5e028;
  uStack_2fc = uRam0000000000f5e02c;
  lVar16 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar13 = *(longlong *)(lVar16 + 0x100);
  if (lVar13 == 0) {
    (*_DAT_)(0);
    lVar13 = *(longlong *)(lVar16 + 0x100);
  }
  bVar4 = bStack_348;
  uVar10 = *(undefined8 *)(lVar13 + 1000);
  uVar9 = (**(code **)(*plVar12 + 8))();
  uStack_350 = 0xffffffff;
  uStack_358 = 0;
  uStack_360 = uStack_360 & 0xffffffff00000000;
  uStack_368 = 0;
  puStack_370 = &uStack_308;
  uStack_378 = 0;
  puStack_380 = (undefined4 *)0x0;
  uStack_388 = uStack_388 & 0xffffffff00000000;
  uStack_390 = CONCAT44(uStack_390._4_4_,(uint)bVar4);
  uStack_398 = CONCAT44(uStack_398._4_4_,uVar9);
  func_0x(0x4c414358,uVar10,plVar11,uStack_344);
  if (bStack_348 == 0) {
    (*_DAT_)(0x98,0x2f,0x10,0x6b);
  }
  if ((_DAT_ & 0x2000000) != 0) {
    uStack_2f0 = 0x20000;
    uStack_2e8 = 0;
    ppuStack_2e0 = &puStack_2c8;
    puStack_2d8 = auStack_2a8;
    uStack_a8 = 0;
    uStack_2d0 = 0;
    uStack_a0 = 0;
    puStack_2c8 = auStack_98;
    uStack_2c0 = 0xc;
    uStack_2bc = 1;
    uStack_2b8 = 0;
    uStack_2b0 = 0;
    uStack_2ac = 1;
    auStack_98[0] = (**(code **)(*plVar12 + 8))(plVar12);
    ppuVar5 = ppuStack_2e0;
    ppuStack_2e0[2] = puVar3;
    *(uint *)(ppuVar5 + 3) = uVar17 & 0xfffffffe;
    *(undefined4 *)((longlong)ppuVar5 + 0x1c) = 1;
    func_0x(auStack_2f8);
  }
  cVar7 = (**(code **)(*plVar12 + 0xc0))(plVar12,puVar3,uVar17);
  if (cVar7 == '\0') {
    puVar14 = (undefined8 *)(**(code **)*plVar12)(plVar12);
    lVar13 = (**(code **)*plVar12)(plVar12);
    uStack_378 = CONCAT44(uStack_378._4_4_,uVar17);
    uStack_388 = CONCAT44(uStack_388._4_4_,uVar17);
    uStack_390 = *puVar14;
    uStack_398 = CONCAT44(uStack_398._4_4_,*(undefined4 *)(lVar13 + 8));
    puStack_380 = puVar3;
    puStack_370 = puVar3;
    (*_DAT_)(0x176,0x30,0x10,1);
  }
  else {
    (*((code **)*plVar12)[0x15])(plVar12,puVar3,uVar17);
  }
  (**(code **)*plVar11)(plVar11);
  func_0x(&uStack_340);
  *(undefined4 *)(param_4 + 8) = 0;
  if ((int)uStack_340 != 0) {
    func_0x(&uStack_340);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_3b8);
  return;
}

