
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x01337c50) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_(undefined8 param_1,double *param_2,double *param_3,double *param_4,
                     double *param_5,double param_6,double **param_7,undefined4 param_8,
                     undefined4 param_9,double *param_10)

{
  double dVar1;
  double dVar2;
  double dVar3;
  undefined4 *puVar4;
  longlong lVar5;
  ulonglong uVar6;
  double dVar7;
  double dVar8;
  double *pdVar9;
  char cVar10;
  char cVar11;
  longlong lVar12;
  undefined8 *puVar13;
  double *pdVar14;
  undefined8 *puVar15;
  double **ppdVar16;
  undefined8 uVar17;
  uint uVar18;
  ulonglong uVar19;
  double dVar20;
  double dVar21;
  double dVar22;
  double dVar23;
  undefined4 uVar24;
  undefined4 uVar25;
  double dVar26;
  undefined unaff_XMM6 [16];
  undefined auVar27 [16];
  undefined4 uVar28;
  undefined4 uVar29;
  undefined4 uVar30;
  undefined4 uVar31;
  undefined4 uVar32;
  double *pdStackX_10;
  double *pdStackX_18;
  double *pdStackX_20;
  double *pdVar33;
  undefined8 uVar34;
  undefined4 uVar35;
  undefined8 uVar36;
  undefined uVar37;
  double dStack_128;
  double dStack_120;
  undefined8 uStack_118;
  longlong lStack_110;
  undefined8 uStack_108;
  undefined auStack_100 [16];
  undefined8 *puStack_f0;
  
  dVar22 = _DAT_;
  dVar8 = _DAT_;
  dVar7 = _DAT_;
  uStack_108 = 0xfffffffffffffffe;
  puVar15 = (undefined8 *)0x0;
  if (*param_3 < 0.0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  auVar27._8_8_ = 0;
  auVar27._0_8_ = *param_3;
  auVar27 = sqrtpd(unaff_XMM6,auVar27);
  dVar26 = auVar27._0_8_;
  if (_DAT_ < dVar26) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar26 < _DAT_) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  cVar11 = (char)param_9;
  if ((char)param_9 == '\0') {
    if (_DAT_ < *param_2 + _DAT_) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*param_2 + _DAT_ < _DAT_) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  pdStackX_10 = param_2;
  pdStackX_18 = param_3;
  pdStackX_20 = param_4;
  dVar20 = (double)func_0x();
  if (dVar7 < dVar20) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar20 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  cVar10 = (char)param_8;
  if ((char)param_8 != '\0') {
    dVar23 = (double)func_0x(*param_4);
    if (dVar7 < dVar23) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (dVar23 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *param_4 = dVar23;
    dVar23 = (double)func_0x(*param_5);
    if (dVar7 < dVar23) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (dVar23 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *param_5 = dVar23;
  }
  dVar23 = _DAT_;
  dVar26 = dVar26 * _DAT_;
  if (dVar7 < dVar26) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar26 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  dVar1 = *pdStackX_10;
  dVar21 = dVar1 - dVar26;
  if (dVar7 < dVar21) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar21 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  dVar2 = *param_4;
  if (dVar2 <= dVar21) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (cVar10 != '\0') {
    if (cVar11 == '\0') {
      dVar21 = dVar2 + dVar22;
      if (dVar7 < dVar21) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (dVar21 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    dVar21 = (double)func_0x();
    if (dVar7 < dVar21) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (dVar21 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    dVar3 = dVar20 - dVar23;
    if (dVar7 < dVar3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (dVar3 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (dVar3 <= dVar21) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (dVar2 <= dVar21) {
      if (dVar7 < dVar3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (dVar3 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      dVar2 = dVar21;
      if (dVar3 <= dVar21) {
        if (dVar7 < dVar3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        dVar2 = dVar3;
        if (dVar3 < dVar8) {
          dVar2 = dVar8;
        }
      }
    }
  }
  if (dVar7 < dVar26) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar26 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  dVar21 = dVar1 + dVar26;
  if (dVar7 < dVar21) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar21 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  dVar3 = *param_5;
  if (dVar3 < dVar21) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar7 < dVar26) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar26 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  dVar1 = dVar1 + dVar26;
  if (dVar7 < dVar1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar1 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (cVar10 != '\0') {
    if (cVar11 == '\0') {
      dVar1 = dVar1 + dVar22;
      if (dVar7 < dVar1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (dVar1 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    dVar22 = (double)func_0x(dVar1);
    if (dVar7 < dVar22) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (dVar22 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    dVar20 = dVar20 + dVar23;
    if (dVar7 < dVar20) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (dVar20 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (dVar22 <= dVar20) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    dVar1 = dVar3;
    if (dVar22 <= dVar3) {
      if (dVar7 < dVar20) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (dVar20 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      dVar1 = dVar22;
      if (dVar22 <= dVar20) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
  }
  dVar1 = dVar1 - dVar2;
  if (dVar7 < dVar1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar1 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar1 < 0.0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar7 < dVar1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (dVar1 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  param_8 = 0x2806;
  lStack_110 = (*_DAT_)(0x108,param_1,0x1f4ba98,0x2806,1);
  ppdVar16 = param_7;
  if (lStack_110 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (((double)*param_7 == _DAT_) || (*param_3 == 0.0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  param_6 = _DAT_;
  dStack_128 = 0.0;
  dStack_120 = _DAT_;
  uVar17 = 0x29425b0;
  if (cVar10 != '\0') {
    uVar17 = 0x291f6b8;
  }
  uVar37 = 1;
  uVar36 = 0;
  uVar35 = 200;
  puVar13 = &param_6;
  uVar34 = 0;
  pdVar14 = &dStack_128;
  pdVar33 = &dStack_120;
  lVar12 = func_0x(lStack_110,param_1,uVar17);
  pdVar9 = pdStackX_10;
  *(char *)(lVar12 + 0x58) = cVar10;
  if (((double)*ppdVar16 == _DAT_) || (*pdStackX_18 == 0.0)) {
    *(undefined4 *)(lVar12 + 0xa8) = 0x3e00;
    *(undefined8 *)(lVar12 + 0xb0) = 0;
    *(undefined8 *)(lVar12 + 0xb8) = 0;
    *(undefined4 *)(lVar12 + 0xc0) = 0;
    if (cVar10 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(double *)(lVar12 + 0xb0) = *pdStackX_10;
    *(byte *)(lVar12 + 0xa0) = *(byte *)(lVar12 + 0xa0) | 2;
    param_9 = 0x2822;
    pdVar14 = (double *)
              (*_DAT_)(0x30,param_1,0x1f4ba98,0x2822,1,pdVar14,uVar34,puVar13,uVar35,uVar36,
                               uVar37);
    if (pdVar14 == (double *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    pdStackX_10 = pdVar14;
    func_0x(pdVar14,param_1);
    *pdVar14 = 1.621316732584751e-316;
    pdVar14[3] = 0.0;
    pdVar14[4] = 0.0;
    pdVar14[5] = _DAT_;
    pdVar14[3] = 0.0;
    pdVar14[4] = _DAT_;
    pdVar14[5] = _DAT_;
    puVar4 = (undefined4 *)pdVar14[2];
    *puVar4 = 0x3e03;
    *(undefined8 *)(puVar4 + 2) = 0;
    *(undefined8 *)(puVar4 + 4) = 0;
    puVar4[6] = 0;
    *(undefined *)pdVar14[2] = 0;
    *(double *)((longlong)pdVar14[2] + 8) = *pdVar9;
    lVar5 = *(longlong *)(lVar12 + 0x60);
    uVar18 = *(uint *)(lVar5 + 0x20);
    if (*(longlong *)(lVar5 + 0x28) == 0) {
      uVar17 = func_0x(lVar5 + 0x10,uVar18);
      *(undefined8 *)(lVar5 + 0x28) = uVar17;
      *(uint *)(lVar5 + 0x20) = uVar18;
    }
    if (uVar18 <= *(uint *)(lVar5 + 0x1c)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(double **)(*(longlong *)(lVar5 + 0x28) + (ulonglong)*(uint *)(lVar5 + 0x1c) * 8) = pdVar14;
    *(int *)(lVar5 + 0x1c) = *(int *)(lVar5 + 0x1c) + 1;
  }
  else {
    *(undefined4 *)(lVar12 + 0xa8) = 0x3e00;
    *(undefined8 *)(lVar12 + 0xb0) = 0;
    *(undefined8 *)(lVar12 + 0xb8) = 0;
    *(undefined4 *)(lVar12 + 0xc0) = 0;
    *(double *)(lVar12 + 0xb0) = *param_4;
    *(byte *)(lVar12 + 0xa0) = *(byte *)(lVar12 + 0xa0) | 2;
    param_6 = *param_4;
    uVar35 = SUB84(param_6,0);
    uVar6 = (ulonglong)param_6 >> 0x20;
    dStack_120 = *pdStackX_18;
    dStack_128 = *pdStackX_10;
    puVar13 = (undefined8 *)func_0x(&lStack_110,&dStack_128,&dStack_120,&param_6,pdVar33);
    uVar19 = 0;
    dVar1 = dVar1 / _DAT_;
    uVar29 = (int)uVar6;
    uVar31 = (int)*puVar13;
    uVar32 = (int)((ulonglong)*puVar13 >> 0x20);
    do {
      if (dVar7 < dVar1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (dVar1 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      dVar22 = (double)uVar19 * dVar1;
      if (dVar7 < dVar22) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (dVar22 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      dVar22 = dVar2 + dVar22;
      if (dVar7 < dVar22) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (dVar22 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (cVar10 != '\0') {
        if (cVar11 == '\0') {
          dVar22 = dVar22 + _DAT_;
          if (dVar7 < dVar22) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (dVar22 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
        }
        dVar22 = (double)func_0x(dVar22);
        if (dVar7 < dVar22) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (dVar22 < dVar8) {
          dVar22 = dVar8;
        }
      }
      if (dVar22 < *pdStackX_20) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*param_5 < dVar22) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((puVar15 == (undefined8 *)0x0) ||
         (uVar28 = uVar35, uVar30 = uVar29, uVar24 = uVar31, uVar25 = uVar32,
         dVar22 != (double)CONCAT44(uVar29,uVar35))) {
        if (cVar10 == '\0') {
          param_6 = 0.0;
        }
        else {
          param_6 = _DAT_;
          if (cVar11 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
        }
        param_6 = param_6 + dVar22;
        if (dVar7 < param_6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (param_6 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        dStack_120 = *pdStackX_18;
        dStack_128 = *pdStackX_10;
        pdVar14 = (double *)func_0x(auStack_100,&dStack_128,&dStack_120,&param_6,pdVar33);
        dStack_128 = *pdVar14;
        uVar24 = SUB84(dStack_128,0);
        uVar25 = (undefined4)((ulonglong)dStack_128 >> 0x20);
        dStack_128 = dStack_128 - (double)CONCAT44(uVar32,uVar31);
        if (dVar7 < dStack_128) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (dStack_128 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (dStack_128 <= 0.0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        pdVar14 = &dStack_128;
        if (_DAT_ <= dStack_128) {
          pdVar14 = (double *)&DAT_;
        }
        dVar26 = *pdVar14;
        if (dVar26 == 0.0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (0.0 < *param_10) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        param_8 = 0x28a2;
        pdVar33 = (double *)0x1;
        dStack_128 = dVar26;
        puVar15 = (undefined8 *)(*_DAT_)(0x30,param_1,0x1f4ba98);
        if (puVar15 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        puStack_f0 = puVar15;
        func_0x(puVar15,param_1);
        *puVar15 = 0x1f4bac8;
        uVar17 = 0;
        puVar15[3] = 0;
        puVar15[4] = 0;
        puVar15[5] = _DAT_;
        puVar4 = (undefined4 *)puVar15[2];
        *puVar4 = 0x3e03;
        *(undefined8 *)(puVar4 + 2) = 0;
        *(undefined8 *)(puVar4 + 4) = 0;
        puVar4[6] = 0;
        *(undefined *)puVar15[2] = 0;
        *(double *)(puVar15[2] + 8) = dVar22;
        uVar28 = SUB84(dVar22,0);
        uVar30 = (undefined4)((ulonglong)dVar22 >> 0x20);
        if (dVar22 == (double)CONCAT44(uVar29,uVar35)) {
LAB_:
          puVar15[3] = uVar17;
          dVar22 = _DAT_;
          puVar15[4] = dVar26;
LAB_:
          puVar15[5] = dVar22;
        }
        else {
          dVar22 = dVar22 - (double)CONCAT44(uVar29,uVar35);
          if (cVar10 == '\0') {
            puVar15[3] = dVar26;
            dVar22 = _DAT_;
            puVar15[4] = 0;
            goto LAB_;
          }
          lStack_110 = _DAT_;
          uStack_118 = _DAT_;
          if (dVar7 < dVar22) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (dVar22 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          param_6 = dVar22;
          cVar11 = func_0x(&param_6,&uStack_118,&lStack_110);
          if (cVar11 != '\0') goto LAB_;
          puVar15[3] = dVar26;
          param_6 = _DAT_;
          if (dVar7 < dVar22) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (dVar22 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          dVar20 = dVar26 * (double)*ppdVar16;
          if (dVar7 < dVar20) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (dVar20 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          dVar20 = dVar20 / dVar22;
          if (dVar7 < dVar20) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (dVar20 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (_DAT_ <= dVar20) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          puVar15[5] = _DAT_;
          param_6 = param_6 / (double)*ppdVar16;
          if (dVar7 < param_6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (param_6 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          dVar22 = dVar26 - param_6;
          if (dVar7 < dVar22) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (dVar22 < dVar8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (0.0 < dVar22) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          puVar15[3] = 0;
          pdVar14 = &param_6;
          if (dVar26 <= param_6) {
            pdVar14 = &dStack_128;
          }
          puVar15[4] = *pdVar14;
        }
        lVar5 = *(longlong *)(lVar12 + 0x60);
        if (*(longlong *)(lVar5 + 0x28) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (*(uint *)(lVar5 + 0x20) <= *(uint *)(lVar5 + 0x1c)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *(undefined8 **)(*(longlong *)(lVar5 + 0x28) + (ulonglong)*(uint *)(lVar5 + 0x1c) * 8) =
             puVar15;
        *(int *)(lVar5 + 0x1c) = *(int *)(lVar5 + 0x1c) + 1;
        ppdVar16 = param_7;
        cVar11 = (char)param_9;
      }
      uVar18 = (int)uVar19 + 1;
      uVar19 = (ulonglong)uVar18;
      uVar35 = uVar28;
      uVar29 = uVar30;
      uVar31 = uVar24;
      uVar32 = uVar25;
    } while (uVar18 < 199);
  }
  pdStackX_10 = _DAT_;
  func_0x(lVar12,&pdStackX_10);
  ppdVar16 = param_7;
  if (cVar10 != '\0') {
    pdStackX_10 = *param_7;
    func_0x(lVar12,&pdStackX_10);
  }
  pdStackX_10 = *ppdVar16;
  func_0x(lVar12,&pdStackX_10);
  *(undefined4 *)(lVar12 + 0xd8) = 10;
  pdStackX_10 = (double *)0x0;
  func_0x(lVar12 + 0xe0,&pdStackX_10);
  *(undefined8 *)(lVar12 + 0x78) = 0;
  return lVar12;
}

