
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1,longlong *param_2,longlong param_3,longlong *param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  
  lVar2 = func_0x(param_1,param_3,1);
  if (lVar2 != 0) {
    if (*(char *)(lVar2 + 0x84) == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(int *)(param_2 + 1) = *(int *)(param_2 + 1) + (*(int *)(lVar2 + 0x68) - *(int *)(param_3 + 8))
    ;
    if (0xffffffff < (ulonglong)*(uint *)(param_2 + 1) * 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar3 = func_0x(param_1 + 0x1a0,*param_2,
                            (ulonglong)*(uint *)(param_2 + 1) * 2 & 0xffffffff);
    *param_4 = lVar3;
    *param_2 = lVar3;
    if (*(int *)(param_2 + 1) - *(uint *)(param_4 + 1) < *(uint *)(lVar2 + 0x68)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar1 = (ulonglong)*(uint *)(lVar2 + 0x68) * 2;
    if (0xffffffff < uVar1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    func_0x
              (*param_4 + (ulonglong)*(uint *)(param_4 + 1) * 2,*(undefined8 *)(lVar2 + 0x60),
               uVar1 & 0xffffffff);
    *(int *)(param_4 + 1) = *(int *)(param_4 + 1) + *(int *)(lVar2 + 0x68);
  }
  return;
}

