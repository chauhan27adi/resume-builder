
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_(longlong param_1,longlong param_2,int param_3,undefined8 param_4)

{
  int iVar1;
  undefined8 uVar2;
  char cVar3;
  uint uVar4;
  undefined8 *puVar5;
  uint uVar6;
  uint uVar7;
  longlong lVar8;
  
  if (*(longlong *)(param_2 + 8) == 0) {
    iVar1 = *(int *)(*(longlong *)(*(longlong *)(param_2 + 0x10) + 0x30) + (longlong)param_3 * 4);
    uVar7 = iVar1 >> 0x1f & 0xff;
    uVar4 = iVar1 + uVar7;
    uVar6 = (int)uVar4 >> 8;
    lVar8 = *(longlong *)
             (*(longlong *)
               (*(longlong *)(*(longlong *)(*(longlong *)(param_2 + 0x10) + 0x18) + 0x10) + 0x130) +
             0x60);
    if (*(uint *)(lVar8 + 0xc) <= uVar6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar8 = *(longlong *)
             (*(longlong *)
               (*(longlong *)(*(longlong *)(lVar8 + 0x18) + (ulonglong)uVar6 * 8) +
               (ulonglong)((uVar4 & 0xff) - uVar7) * 8) + 8);
  }
  else {
    lVar8 = *(longlong *)
             (*(longlong *)
               (*(longlong *)(*(longlong *)(param_2 + 8) + 0x20) + (longlong)param_3 * 8) + 0x50);
  }
  cVar3 = func_0x(param_4,param_2,lVar8 + 0x68,*(undefined8 *)(lVar8 + 0xd0),0);
  if (cVar3 == '\0') {
    puVar5 = (undefined8 *)(*_DAT_)(0x38,*(undefined8 *)(param_1 + 0x10),0x2097060,0xca,1);
    if (puVar5 != (undefined8 *)0x0) {
      uVar2 = *(undefined8 *)(param_1 + 0x10);
      *puVar5 = 0x207a418;
      *(undefined4 *)(puVar5 + 1) = 1;
      *puVar5 = 0x2095928;
      _DAT_ = _DAT_ + 1;
      puVar5[2] = uVar2;
      puVar5[3] = 0;
      *(undefined *)(puVar5 + 4) = 2;
      puVar5[5] = 0;
      puVar5[6] = 0;
      func_0x(puVar5);
      *(byte *)(puVar5 + 4) = *(byte *)(puVar5 + 4) | 2;
      return puVar5;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

