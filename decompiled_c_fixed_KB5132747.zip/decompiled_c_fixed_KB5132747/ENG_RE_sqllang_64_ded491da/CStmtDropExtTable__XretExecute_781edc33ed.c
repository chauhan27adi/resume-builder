
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong param_3,longlong param_4)

{
  code **ppcVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  ulonglong *puVar10;
  undefined8 *puVar11;
  longlong lVar12;
  longlong lVar13;
  undefined8 uVar14;
  longlong lVar15;
  longlong lVar16;
  ulonglong uVar17;
  int iVar18;
  longlong unaff_GS_OFFSET;
  undefined auStack_158 [32];
  undefined8 uStack_138;
  undefined8 uStack_130;
  undefined8 uStack_128;
  undefined8 uStack_120;
  undefined8 uStack_118;
  undefined8 uStack_110;
  ulonglong *puStack_108;
  ulonglong uStack_100;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  ulonglong *puStack_e8;
  ulonglong uStack_e0;
  longlong *plStack_d8;
  undefined8 uStack_c8;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  longlong lStack_b8;
  undefined8 uStack_b0;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined auStack_88 [48];
  undefined auStack_58 [16];
  ulonglong uStack_48;
  
  uStack_b0 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_158;
  uVar14 = *(undefined8 *)(param_4 + 0x78);
  plVar9 = *(longlong **)(param_3 + 0x38);
  iVar5 = 0;
  puStack_e8 = (ulonglong *)((ulonglong)puStack_e8 & 0xffffffff00000000);
  plStack_d8 = (longlong *)0x0;
  uStack_c8 = uVar14;
  lStack_b8 = param_3;
  func_0x
            (auStack_88,*(undefined8 *)(param_1 + 0x8a0),*(undefined4 *)(param_1 + 0x8a8));
  puStack_108 = (ulonglong *)((ulonglong)puStack_108 & 0xffffffffffffff00);
  uStack_110 = (undefined4 *)((ulonglong)uStack_110._4_4_ << 0x20);
  uStack_118 = (ulonglong)uStack_118._4_4_ << 0x20;
  uStack_120 = 0;
  uStack_128 = 0;
  uStack_130 = 0;
  uStack_138 = 0;
  plVar6 = (longlong *)(**(code **)(*plVar9 + 0x28))(plVar9,auStack_88,1,0);
  if (plVar6 == (longlong *)0x0) {
    func_0x(0x19f4718,0x1d757d0,0x19f3d38);
    uStack_120 = *(ulonglong *)(param_1 + 0x8a0);
    uStack_128 = CONCAT44(uStack_128._4_4_,*(undefined4 *)(param_1 + 0x8a8));
    uStack_130 = CONCAT44(uStack_130._4_4_,0xb619);
    uStack_138 = CONCAT44(uStack_138._4_4_,0x331f);
    (*_DAT_)(0x97,0x33,0x10,1);
  }
  uVar3 = (**(code **)*plVar6)(plVar6);
  uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
  uStack_100 = 0;
  puStack_108 = (ulonglong *)0x0;
  uStack_110 = (undefined4 *)CONCAT71(uStack_110._1_7_,1);
  uStack_118 = CONCAT71(uStack_118._1_7_,1);
  uStack_120 = uStack_120 & 0xffffffff00000000;
  uStack_128 = CONCAT44(uStack_128._4_4_,0xffffffff);
  uStack_130 = CONCAT44(uStack_130._4_4_,uVar4);
  uStack_138 = CONCAT44(uStack_138._4_4_,uVar3);
  cVar2 = func_0x(0x52445445,uVar14,plVar9,uVar3);
  if (cVar2 == '\0') {
    uStack_a8 = _DAT_;
    uStack_a4 = uRam000000000188c9b4;
    uStack_a0 = uRam000000000188c9b8;
    uStack_9c = uRam000000000188c9bc;
    uStack_f0 = 0xffffffff;
    uStack_f8 = 0;
    uStack_100 = uStack_100 & 0xffffffff00000000;
    puStack_108 = (ulonglong *)0x0;
    uStack_110 = &uStack_a8;
    uStack_118 = 0;
    uStack_120 = 0;
    uStack_128 = uStack_128 & 0xffffffff00000000;
    uStack_130 = uStack_130 & 0xffffffff00000000;
    uStack_138 = CONCAT44(uStack_138._4_4_,uVar3);
    func_0x(0x52445445,uVar14,plVar9,uVar3);
    func_0x(0x19f4718,0x1d755a8,0x19f3d38);
    (*_DAT_)(0x98,0x2f,0x10,1);
  }
  lVar13 = *plVar9;
  uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
  uStack_138 = uStack_138 & 0xffffffffffffff00;
  plVar7 = (longlong *)(**(code **)(lVar13 + 0x120))(plVar9,uVar4,uVar3,1);
  if (plVar7 == (longlong *)0x0) {
    func_0x(0x19f4718,0x1d757d0,0x19f3d38);
    uStack_120 = *(ulonglong *)(param_1 + 0x8a0);
    uStack_128 = CONCAT44(uStack_128._4_4_,*(undefined4 *)(param_1 + 0x8a8));
    uStack_130 = CONCAT44(uStack_130._4_4_,0xb619);
    uStack_138 = CONCAT44(uStack_138._4_4_,0x331f);
    (*_DAT_)(0x97,0x33,0x10,2);
  }
  lVar13 = *plVar9;
  uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
  uStack_138 = uStack_138 & 0xffffffffffffff00;
  plVar8 = (longlong *)(**(code **)(lVar13 + 0x108))(plVar9,uVar4,uVar3,0);
  uVar17 = 6;
  if (plVar8 == (longlong *)0x0) {
    func_0x(0x19f4718,0x1d75a40,0x19f3d38);
    uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
    uStack_130 = CONCAT44(uStack_130._4_4_,uVar4);
    uStack_138 = CONCAT44(uStack_138._4_4_,0xb60e);
    (*_DAT_)(0x1d1,0xb,0x12,6);
  }
  uVar4 = (**(code **)(*plVar8 + 0x10))(plVar8);
  iVar18 = 0;
  switch(uVar4) {
  case 0:
    cVar2 = func_0x();
    iVar18 = iVar5;
    if (cVar2 == '\0') {
      if (*(int *)(_DAT_ + 0x38a8) != 0) {
        puVar11 = (undefined8 *)(*pcRam0000000002473818)();
        cVar2 = (**(code **)*puVar11)(puVar11);
        if (cVar2 != '\0') break;
      }
      cVar2 = func_0x(0x249c750,1);
      if (cVar2 != '\0') {
        cVar2 = (*pcRam000000000246f788)();
        if (cVar2 == '\0') {
          lVar13 = _DAT_ + 0x3a10;
        }
        else {
          lVar13 = _DAT_ + 0x6f68;
        }
        if (((*(char *)(lVar13 + 0x354d) != '\0') &&
            (*(char *)(lRam0000000002497a70 + 0x4b5) == '\0')) &&
           ((*(byte *)(lRam0000000002474050 + 0x6b0) & 0x10) == 0)) {
          func_0x(0x19f4718,0x1d75a40,0x19f3d38);
          (*_DAT_)(0x1d1,0x1f,0x10,0xb);
          break;
        }
      }
      func_0x(0x19f4718,0x1d75a40,0x19f3d38);
      uStack_138 = CONCAT44(uStack_138._4_4_,0xb61a);
      (*_DAT_)(0x1d1,0x19,0x10,10);
    }
    break;
  case 1:
  case 2:
  case 3:
  case 4:
  case 5:
    break;
  case 6:
    puVar11 = (undefined8 *)(**(code **)(*plVar8 + 0x20))(plVar8);
    uVar4 = func_0x(*puVar11);
    switch(uVar4) {
    case 1:
    case 2:
    case 5:
    case 6:
    case 7:
    case 0xff:
      if (*(char *)(_DAT_ + 0xbe80) == '\0') {
        cVar2 = func_0x();
        iVar18 = iVar5;
        if ((cVar2 != '\0') ||
           ((*(int *)(_DAT_ + 0x38a8) != 0 && (cRam0000000002481022 != '\0')))) break;
        uVar14 = 0x19;
      }
      else {
        cVar2 = (**(code **)(*plVar7 + 0x98))(plVar7);
        if (cVar2 != '\0') {
          cVar2 = (**(code **)(**(longlong **)
                                 (*(longlong *)
                                   ((ulonglong)*puRam0000000001866340 +
                                   *(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*puRam0000000001866338 * 8)) + 0x90) + 0x1f0))();
          if (cVar2 != '\0') {
            if (*(char *)(_DAT_ + 0xbe80) == '\0') {
              uStack_138 = 0;
              (*_DAT_)(1,0x1eb2ab0,0x1ead5d8,0x905);
            }
            uStack_130 = 0x4e;
            uStack_138 = 0x1d759f0;
            (*_DAT_)(5,0x4a,0x10,0x15);
          }
          plStack_d8 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8);
          iVar18 = 1;
          break;
        }
        cVar2 = func_0x();
        iVar18 = iVar5;
        if (cVar2 != '\0') break;
        uVar14 = 0x1a;
      }
      uStack_138 = CONCAT44(uStack_138._4_4_,0xb642);
      (*_DAT_)(0x1d1,uVar14,0x10);
      iVar18 = iVar5;
      break;
    case 3:
    case 4:
      uStack_138._0_4_ = 0xb642;
      (*_DAT_)(0x1d1,0x19,0x10,0xb);
      uStack_130 = uStack_130 & 0xffffffff00000000;
      uStack_138 = (ulonglong)uStack_138._4_4_ << 0x20;
      plVar8 = (longlong *)(**(code **)(*plVar9 + 0x38))(plVar9,uVar3,0,0);
      lVar13 = *plVar8;
      uVar4 = (**(code **)(*plVar7 + 0xb8))(plVar7);
      uStack_120 = uStack_120 & 0xffffffff00000000;
      uStack_128 = uStack_128 & 0xffffffff00000000;
      uStack_130 = CONCAT71(uStack_130._1_7_,1);
      uStack_138 = uStack_138 & 0xffffffffffffff00;
      plVar8 = (longlong *)(**(code **)(lVar13 + 0x78))(plVar8,uVar4,2,0);
      func_0x(plVar9,plVar8);
      lVar13 = *plVar9;
      uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
      (**(code **)(lVar13 + 0x298))(plVar9,uVar3,uVar4,0);
      iVar18 = (int)puStack_e8;
      break;
    default:
      uStack_138 = 0x1af38e8;
      (*_DAT_)(1,0x1eafe00,0x1ead5d8,0x91d);
      iVar18 = iVar5;
    }
    break;
  default:
    uStack_138 = 0x1af38e8;
    (*_DAT_)(1,0x1eafe00,0x1ead5d8,0x923);
    iVar18 = iVar5;
  }
  iVar5 = (**(code **)(*plVar7 + 0x10))(plVar7);
  if (iVar5 != 0) {
    uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
    uStack_100 = 0;
    puStack_108 = (ulonglong *)0x0;
    uStack_110 = (undefined4 *)((ulonglong)uStack_110 & 0xffffffffffffff00);
    uStack_118 = CONCAT71(uStack_118._1_7_,1);
    uStack_120 = uStack_120 & 0xffffffff00000000;
    uStack_128 = CONCAT44(uStack_128._4_4_,0xffffffff);
    uStack_130 = CONCAT44(uStack_130._4_4_,uVar4);
    uStack_138 = CONCAT44(uStack_138._4_4_,uVar3);
    cVar2 = func_0x(0x44465445,uStack_c8,plVar9,uVar3);
    if (cVar2 == '\0') {
      func_0x(0x19f4718,0x1d755a8,0x19f3d38);
      (*_DAT_)(0x98,0x2f,0x10,2);
    }
  }
  if ((*(char *)(_DAT_ + 0xbe80) != '\0') && (iVar18 != 0)) {
    uStack_130 = uStack_130 & 0xffffffff00000000;
    uStack_138 = uStack_138 & 0xffffffff00000000;
    plVar9 = (longlong *)(**(code **)(*plVar9 + 0x38))(plVar9,uVar3,0,0);
    puVar10 = (ulonglong *)(**(code **)(*plVar9 + 8))(plVar9);
    uVar4 = (**(code **)(*plVar6 + 0x18))(plVar6);
    puVar11 = (undefined8 *)(**(code **)(*plVar9 + 0xd8))(plVar9,uVar4,0,1);
    puStack_e8 = (ulonglong *)(**(code **)*puVar11)(puVar11);
    plVar9 = (longlong *)(**(code **)(*plVar6 + 0x28))(plVar6);
    lVar15 = *plStack_d8;
    lVar16 = -1;
    lVar13 = -1;
    do {
      lVar13 = lVar13 + 1;
    } while (*(short *)(lVar15 + lVar13 * 2) != 0);
    iVar5 = (*_DAT_)(lVar15 + (ulonglong)((int)lVar13 - 8) * 2,0x1d74e20,8);
    if (iVar5 == 0) {
      lVar13 = 0;
    }
    else {
      lVar13 = (*_DAT_)(lVar15,0x2f);
      if (lVar13 == 0) {
        (*_DAT_)(0x1d1,0x21,0x10,0x3b);
      }
      lVar13 = lVar13 + 2;
    }
    iVar5 = (*_DAT_)(auStack_58);
    if (iVar5 < 0) {
      uStack_138 = 0;
      (*_DAT_)(1,0x1eb19c0,0x1ead5d8,0x964);
    }
    uStack_e0 = 0;
    if (lVar13 != 0) {
      uVar17 = 0xffffffffffffffff;
      do {
        uVar17 = uVar17 + 1;
      } while (*(short *)(lVar13 + uVar17 * 2) != 0);
    }
    uStack_118 = *plVar9;
    uStack_128 = *puStack_e8;
    uStack_138 = *puVar10;
    lVar15 = -1;
    do {
      lVar15 = lVar15 + 1;
    } while (*(short *)(uStack_118 + lVar15 * 2) != 0);
    lVar12 = -1;
    do {
      lVar12 = lVar12 + 1;
    } while (*(short *)(uStack_128 + lVar12 * 2) != 0);
    do {
      lVar16 = lVar16 + 1;
    } while (*(short *)(uStack_138 + lVar16 * 2) != 0);
    if (lVar13 == 0) {
      lVar13 = 0x1d74d78;
    }
    puStack_108 = &uStack_e0;
    uStack_110 = (undefined4 *)CONCAT44(uStack_110._4_4_,(int)lVar15);
    uStack_120 = CONCAT44(uStack_120._4_4_,(int)lVar12);
    uStack_130 = CONCAT44(uStack_130._4_4_,(int)lVar16);
    iVar5 = func_0x(uStack_c8,auStack_58,lVar13,uVar17 & 0xffffffff);
    if (iVar5 < 0) {
      if (uStack_e0 == 0) {
        uStack_138 = CONCAT44(uStack_138._4_4_,iVar5);
        (*_DAT_)(0x1d1,0x25);
      }
      else {
        uStack_130 = uStack_e0;
        uStack_138 = CONCAT44(uStack_138._4_4_,0xb648);
        (*_DAT_)(0x1d1,0x2a,0x10);
      }
    }
    (*_DAT_)(uStack_e0);
  }
  cVar2 = (**(code **)(*plVar7 + 0xe0))(plVar7);
  if (cVar2 != '\0') {
    (*_DAT_)(0xc4,4,0x10,2);
  }
  puStack_108 = (ulonglong *)0x0;
  uStack_110 = (undefined4 *)0x0;
  uStack_118 = 0;
  uStack_120 = 0;
  uStack_128 = 0;
  uStack_130 = 0;
  uStack_138 = 0;
  func_0x
            (*(undefined8 *)(param_1 + 0x8a0),*(undefined4 *)(param_1 + 0x8a8),0x5445,0);
  uVar14 = *(undefined8 *)(param_1 + 0x8a0);
  uStack_c0 = *(undefined4 *)(param_1 + 0x8a8);
  uStack_c8._0_4_ = (undefined4)uVar14;
  uStack_c8._4_4_ = (undefined4)((ulonglong)uVar14 >> 0x20);
  uStack_98 = (undefined4)uStack_c8;
  uStack_94 = uStack_c8._4_4_;
  uStack_8c = uStack_bc;
  ppcVar1 = (code **)*plVar7;
  uStack_c8 = uVar14;
  uStack_90 = uStack_c0;
  uVar4 = (**ppcVar1)(plVar7);
  (*ppcVar1[0xb])(plVar7,&uStack_98,uVar4,uVar3);
  *(byte *)(lStack_b8 + 0xb0) = *(byte *)(lStack_b8 + 0xb0) | 0x10;
  func_0x(uStack_48 ^ (ulonglong)auStack_158);
  return;
}

