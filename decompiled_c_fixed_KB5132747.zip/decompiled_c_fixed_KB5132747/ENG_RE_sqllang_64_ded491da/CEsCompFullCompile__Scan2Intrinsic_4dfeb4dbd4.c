
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Switch with 1 destination removed at 0x0010012f */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Exceeded maximum restarts with more pending */

void FUN_(undefined8 param_1,longlong param_2,longlong param_3,undefined4 param_4)

{
  code *pcVar1;
  longlong lVar2;
  int iVar3;
  longlong lVar4;
  longlong lVar5;
  undefined8 unaff_RBX;
  longlong unaff_GS_OFFSET;
  int aiStackX_10 [2];
  longlong lStackX_18;
  undefined4 uStackX_20;
  undefined8 uStack_40;
  
  uStack_40 = 0x100027;
  lStackX_18 = param_3;
  uStackX_20 = param_4;
  lVar4 = func_0x();
  lVar4 = -lVar4;
  *(undefined8 *)(&stack0x00001528 + lVar4) = unaff_RBX;
  if (*(char *)(*(longlong *)
                 ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) + 0x99)
      != '\0') {
    *(undefined8 *)((longlong)&uStack_40 + lVar4) = 0x100077;
    lVar5 = func_0x();
    if (*(int *)(*(longlong *)(lVar5 + 0xa0) + 0x30) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  pcVar1 = *(code **)(**(longlong **)(param_2 + 0x10) + 0x18);
  *(undefined8 *)((longlong)&uStack_40 + lVar4) = 0x100093;
  iVar3 = (*pcVar1)();
  lVar5 = *(longlong *)(param_2 + 0x10);
  *(longlong *)((longlong)&lStackX_18 + lVar4) = lVar5;
  if (iVar3 != 0x58) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar2 = *(longlong *)(lVar5 + 0x40);
  *(longlong *)(&stack0x00000030 + lVar4) = lVar5 + 0x48;
  *(longlong *)((longlong)&uStackX_20 + lVar4) = lVar2;
  iVar3 = *(int *)(lVar2 + 0xc);
  *(int *)((longlong)aiStackX_10 + lVar4) = iVar3;
  *(undefined8 *)(&stack0x00000028 + lVar4) = 0;
  if (*(char *)((longlong)iVar3 + 0x2b1d980) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (0x117 < iVar3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar3 == 0x117) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (0xea < iVar3 - 0xfU) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

