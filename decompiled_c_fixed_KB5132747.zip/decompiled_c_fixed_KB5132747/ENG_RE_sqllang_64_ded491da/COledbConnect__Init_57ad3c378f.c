
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4,
                 char param_5)

{
  byte bVar1;
  undefined uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined8 uVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong lVar9;
  ulonglong uVar10;
  int iVar11;
  longlong unaff_GS_OFFSET;
  undefined8 in_stack_ffffffffffffff68;
  undefined8 in_stack_ffffffffffffff70;
  undefined4 uVar12;
  undefined auStack_70 [8];
  undefined8 uStack_68;
  undefined4 uStack_60;
  code **ppcStack_58;
  longlong *plStack_50;
  longlong *aplStack_48 [2];
  
  uVar12 = (undefined4)((ulonglong)in_stack_ffffffffffffff70 >> 0x20);
  uVar3 = (undefined4)((ulonglong)in_stack_ffffffffffffff68 >> 0x20);
  ppcStack_58 = (code **)0xe9a2f0;
  iVar11 = 0;
  plStack_50 = (longlong *)0x0;
  aplStack_48[0] = (longlong *)0x0;
  lVar9 = (ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar8 = *(longlong *)(lVar9 + 0x100);
  if (lVar8 == 0) {
    (*_DAT_)(0);
    lVar8 = *(longlong *)(lVar9 + 0x100);
  }
  uVar5 = *(undefined8 *)(lVar8 + 1000);
  func_0x(aplStack_48,0x12bc670,0x26);
  (**ppcStack_58)(&ppcStack_58,uVar5);
  uVar5 = (*_DAT_)(param_2,param_3,param_4);
  *(undefined8 *)(param_1 + 0x80) = uVar5;
  uStack_68 = param_3;
  uStack_60 = param_4;
  plVar6 = (longlong *)(**(code **)(*plStack_50 + 0x88))(plStack_50,&uStack_68,0);
  if (plVar6 == (longlong *)0x0) {
    uVar5 = param_3;
    (*_DAT_)(0x48,2,0xb,2,CONCAT44(uVar3,param_4),param_3);
    uVar12 = (undefined4)((ulonglong)uVar5 >> 0x20);
  }
  uVar2 = 0xc1;
  if (param_5 != '\0') {
    uVar2 = 0xe0;
  }
  *(undefined *)(param_1 + 0x78) = uVar2;
  uVar3 = (**(code **)*plVar6)(plVar6);
  *(undefined4 *)(param_1 + 0x50) = uVar3;
  (**(code **)(*plVar6 + 0x10))(plVar6,param_1 + 0x5c);
  if ((*(byte *)(param_1 + 0x69) & 4) != 0) {
    lVar8 = *(longlong *)
             ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    iVar4 = (**(code **)**(undefined8 **)(*(longlong *)(lVar8 + 0x78) + 0x108))();
    if (iVar4 == 0) {
      lVar8 = *(longlong *)(lVar8 + 0x80);
      if (lVar8 != 0) {
        for (puVar7 = *(undefined8 **)(lVar8 + 0x1f0); puVar7 != (undefined8 *)0x0;
            puVar7 = (undefined8 *)*puVar7) {
          if ((((*(int *)(puVar7 + 1) != 0) && ((*(uint *)(puVar7 + 3) >> 4 & 1) == 0)) &&
              ((*(uint *)(puVar7 + 3) & 1) != 0)) && (*(int *)(puVar7 + 1) != -0x185e98be))
          goto LAB_;
        }
      }
      (*_DAT_)(0x98,0x2f,0x10,0x70);
    }
  }
LAB_:
  *(byte *)(param_1 + 0x8e) = *(byte *)(param_1 + 0x8e) & 0xfe;
  *(byte *)(param_1 + 0x8e) = *(byte *)(param_1 + 0x8e) | *(int *)(param_1 + 0x5c) != 0;
  puVar7 = (undefined8 *)(**(code **)(*plVar6 + 0x18))(plVar6,auStack_70);
  *(undefined8 *)(param_1 + 0x70) = *puVar7;
  puVar7 = (undefined8 *)(**(code **)(*plVar6 + 0x28))(plVar6);
  func_0x(param_1,param_2,*puVar7);
  lVar8 = *(longlong *)(param_1 + 8);
  lVar9 = -1;
  do {
    lVar9 = lVar9 + 1;
  } while (*(short *)(lVar8 + lVar9 * 2) != 0);
  uVar10 = (ulonglong)(longlong)((int)lVar9 * 2) >> 1;
  iVar4 = (*_DAT_)(1,0,lVar8,uVar10 & 0xffffffff,0x10e74e8,CONCAT44(uVar12,8));
  if (iVar4 == 2) {
LAB_:
    uVar3 = 0;
    (*_DAT_)(1,0x13427a0,0x1337e08,0x38b,0);
  }
  else {
    uVar3 = 0;
    iVar4 = (*_DAT_)(1,0,lVar8,uVar10 & 0xffffffff,0x10e7500,10);
    if (iVar4 == 2) goto LAB_;
  }
  (**(code **)(*plVar6 + 0x30))(plVar6,param_2,param_1 + 0x28);
  (**(code **)(*plVar6 + 0x40))(plVar6,param_2,param_1 + 0x30);
  (**(code **)(*plVar6 + 0x50))(plVar6,param_2,param_1 + 0x20);
  (**(code **)(*plVar6 + 0x60))(plVar6,param_2,param_1 + 0x38);
  if (*(int *)(param_1 + 0x60) == 0) {
    lVar8 = (**(code **)(**_DAT_ + 0x1f8))();
    *(undefined4 *)(param_1 + 0x60) = *(undefined4 *)(lVar8 + 0x44);
  }
  if (*(int *)(param_1 + 100) == 0) {
    lVar8 = (**(code **)(**_DAT_ + 0x1f8))();
    *(undefined4 *)(param_1 + 100) = *(undefined4 *)(lVar8 + 0x6c);
  }
  if (plStack_50 != (longlong *)0x0) {
    (**(code **)*plStack_50)(plStack_50,1);
  }
  plStack_50 = (undefined8 *)0x0;
  if (((aplStack_48[0] != (longlong *)0x0) &&
      (lVar8 = (**(code **)(*aplStack_48[0] + 0x48))(), lVar8 != 0)) &&
     (aplStack_48[0] != (longlong *)0x0)) {
    (**(code **)(*aplStack_48[0] + 0x20))();
  }
  bVar1 = *(byte *)(param_1 + 0x68);
  if ((char)bVar1 < '\0') {
    for (puVar7 = *(undefined8 **)
                   (*(longlong *)
                     (*(longlong *)
                       ((ulonglong)*_DAT_ +
                       *(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
                     0x80) + 0x1f0); puVar7 != (undefined8 *)0x0; puVar7 = (undefined8 *)*puVar7) {
      if ((*(int *)(puVar7 + 1) != 0) && ((*(uint *)(puVar7 + 3) >> 4 & 1) == 0)) {
        if (iVar11 == 0) {
          if ((*(uint *)(puVar7 + 3) & 1) != 0) goto LAB_;
          break;
        }
        iVar11 = iVar11 + -1;
      }
    }
  }
  else {
LAB_:
    if (param_5 == '\0') {
      bVar1 = bVar1 & 2;
    }
    else {
      bVar1 = bVar1 & 0x10;
    }
    if (bVar1 != 0) goto LAB_;
  }
  uVar5 = 0x12bc698;
  if (param_5 != '\0') {
    uVar5 = 0xf5d068;
  }
  (*_DAT_)(0x4a,0xb,0x10,1,CONCAT44(uVar3,param_4),param_3,uVar5);
LAB_:
  func_0x(param_1);
  ppcStack_58 = (code **)0xe9a2f0;
  if (plStack_50 != (undefined8 *)0x0) {
    (**(code **)*plStack_50)(plStack_50,1);
  }
  if (aplStack_48[0] != (longlong *)0x0) {
    (**(code **)*aplStack_48[0])(aplStack_48[0],1);
  }
  return;
}

