
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(int param_1,undefined4 param_2,int param_3,longlong param_4)

{
  undefined4 uVar1;
  longlong lVar2;
  longlong lVar3;
  undefined8 in_stack_ffffffffffffffe0;
  undefined4 uVar4;
  undefined8 in_stack_ffffffffffffffe8;
  undefined4 uVar5;
  
  uVar5 = (undefined4)((ulonglong)in_stack_ffffffffffffffe8 >> 0x20);
  uVar4 = (undefined4)((ulonglong)in_stack_ffffffffffffffe0 >> 0x20);
  lVar2 = (longlong)param_1 * 0x10;
  uVar1 = 0xffffffff;
  lVar3 = *(longlong *)(lVar2 + 0x14513b0);
  if (*(longlong *)(lVar2 + 0x14513b0) == 0) {
    lVar3 = param_4;
  }
  switch(param_2) {
  case 0:
    uVar1 = 0x8a90;
    break;
  case 1:
    uVar1 = 0x8a99;
    break;
  case 2:
    uVar1 = 0x8a91;
    break;
  case 3:
    uVar1 = 0x8a92;
    break;
  case 4:
    uVar1 = 0x8a93;
    break;
  case 5:
    uVar1 = 0x8a94;
    break;
  case 6:
    uVar1 = 0x8a95;
    break;
  case 7:
    uVar1 = 0x8a9e;
    break;
  case 8:
    uVar1 = 0x8aa0;
    break;
  case 9:
    uVar1 = 0x8aa1;
    break;
  case 10:
    uVar1 = 0x8aa2;
    break;
  case 0xb:
    uVar1 = 0x8aa3;
    break;
  case 0xc:
    uVar1 = 0x8aab;
    break;
  case 0xd:
    uVar1 = 0x8aad;
    break;
  default:
    (*_DAT_)(1,0x1841a58,0x183fc18,0x72,0);
  }
  if (*(int *)(lVar2 + 0x14513b8) == 0) {
    if (param_3 == 0) {
      (*_DAT_)(0x7b,*(undefined4 *)(lVar2 + 0x14513bc),0x10,param_1,uVar1);
    }
    else {
      func_0x
                (param_3,0x7b,*(undefined4 *)(lVar2 + 0x14513bc),0x10,param_1,CONCAT44(uVar4,uVar1))
      ;
    }
  }
  else {
    if (lVar3 == 0) {
      (*_DAT_)(1,0x1844790,0x183fc18,0x7a,0);
    }
    if (*(int *)(lVar2 + 0x14513bc) != 0) {
      (*_DAT_)(1,0x1848aa0,0x183fc18,0x7b,0);
    }
    if (param_3 == 0) {
      (*_DAT_)(0x6b,0x5e,0x10,param_1,*(undefined4 *)(lVar2 + 0x14513b8),lVar3,
                       CONCAT44(uVar5,uVar1));
    }
    else {
      func_0x
                (param_3,0x6b,0x5e,0x10,param_1,CONCAT44(uVar4,*(undefined4 *)(lVar2 + 0x14513b8)),
                 lVar3,uVar1);
    }
  }
  return;
}

