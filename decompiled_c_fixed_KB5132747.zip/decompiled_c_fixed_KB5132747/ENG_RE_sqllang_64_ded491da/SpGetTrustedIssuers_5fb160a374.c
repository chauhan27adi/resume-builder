
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,ulonglong **param_2,longlong param_3,undefined *param_4)

{
  ushort uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  char cVar4;
  undefined2 uVar5;
  undefined4 uVar6;
  uint uVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong lVar12;
  int iVar13;
  uint uVar14;
  longlong lVar15;
  longlong lVar16;
  undefined4 *puVar17;
  longlong unaff_GS_OFFSET;
  undefined auStack_258 [32];
  undefined8 uStack_238;
  undefined8 uStack_230;
  undefined8 uStack_228;
  short *psStack_220;
  undefined8 uStack_218;
  uint uStack_210;
  undefined8 uStack_208;
  undefined8 uStack_200;
  undefined4 uStack_1f8;
  undefined4 uStack_1f0;
  undefined4 uStack_1e8;
  undefined4 uStack_1e0;
  undefined4 uStack_1d8;
  undefined4 uStack_1d0;
  undefined uStack_1c8;
  undefined4 uStack_1c0;
  undefined4 uStack_1b8;
  undefined8 uStack_1b0;
  undefined8 uStack_1a8;
  undefined8 uStack_1a0;
  undefined4 auStack_198 [2];
  int aiStack_190 [4];
  longlong lStack_180;
  uint uStack_178;
  uint uStack_174;
  int aiStack_170 [4];
  longlong lStack_160;
  uint uStack_158;
  uint uStack_154;
  undefined8 uStack_150;
  undefined4 uStack_148;
  undefined auStack_140 [16];
  undefined *puStack_130;
  longlong *plStack_128;
  undefined8 uStack_120;
  undefined auStack_118 [144];
  short asStack_88 [32];
  ulonglong uStack_48;
  
  uStack_120 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_258;
  *(undefined4 *)(param_4 + 8) = 1;
  uVar2 = **param_2;
  uVar1 = *(ushort *)(*param_2 + 1);
  iVar13 = 0;
  if (param_3 != 0) {
    iVar13 = *(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28);
  }
  uStack_150 = 0;
  uVar3 = **param_2;
  uVar5 = *(undefined2 *)(*param_2 + 1);
  uStack_148 = 1;
  auStack_140._0_8_ =
       *(longlong **)
        (*(longlong *)
          ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
        0x90);
  auStack_140._8_8_ = 0;
  puStack_130 = param_4;
  cVar4 = (**(code **)(*(longlong *)auStack_140._0_8_ + 0x1d0))();
  if (cVar4 == '\0') {
    uStack_218 = uStack_218 & 0xffffffff00000000;
    psStack_220 = (short *)0x0;
    uStack_228 = uStack_228 & 0xffffffffffffff00;
    uStack_230 = CONCAT44(uStack_230._4_4_,2);
    uStack_238 = CONCAT44(uStack_238._4_4_,1);
    (**(code **)(*(longlong *)auStack_140._0_8_ + 8))(auStack_140._0_8_,uVar3,uVar5,1);
    uStack_150 = CONCAT44(uStack_150._4_4_,2);
  }
  else {
    (**(code **)(*(longlong *)auStack_140._0_8_ + 0xe8))
              (auStack_140._0_8_,1,1,(longlong)&uStack_150 + 4);
    uStack_148 = 1;
    uStack_150 = CONCAT44(uStack_150._4_4_,4);
  }
  if (iVar13 == 0) {
    uVar8 = (**(code **)(*(longlong *)auStack_140._0_8_ + 0x1b0))();
    lVar15 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar12 = *(longlong *)(lVar15 + 0x100);
    if (lVar12 == 0) {
      (*_DAT_)();
      lVar12 = *(longlong *)(lVar15 + 0x100);
    }
    plVar9 = (longlong *)(**_DAT_)(*(undefined8 *)(lVar12 + 1000),uVar8,0x14db330,0xccd);
    uVar1 = *(ushort *)
             (*(longlong *)
               (*(longlong *)
                 ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) + 0x50) +
             8);
    uStack_230 = uStack_230 & 0xffffffff00000000;
    uStack_238 = uStack_238 & 0xffffffff00000000;
    plStack_128 = plVar9;
    plVar10 = (longlong *)(**(code **)(*plVar9 + 0x38))(plVar9,uVar1,0,0);
    auStack_198[0] = 0;
    (*_DAT_)(auStack_118,0,2,0);
    (*_DAT_)(auStack_118,0x14db4a8,7,0);
    (*_DAT_)(auStack_118,0x14db498,0xd,0x1fc);
    cVar4 = (**(code **)(*plVar10 + 0x340))(plVar10,auStack_198);
    while (cVar4 != '\0') {
      uVar14 = 0;
      plVar11 = (longlong *)(**(code **)(*plVar10 + 0x328))(plVar10,auStack_198[0],0);
      uVar5 = (*_DAT_)();
      uStack_1a0 = 0;
      uStack_1a8 = 0;
      uStack_1b0 = 0;
      uStack_1b8 = 0;
      uStack_1c0 = 0;
      uStack_1c8 = 0;
      uStack_1d0 = 0;
      uStack_1d8 = 0;
      uStack_1e0 = 0;
      uStack_1e8 = 0xffffffff;
      uStack_1f0 = 0;
      uStack_1f8 = 0;
      uStack_200 = 0;
      uStack_208 = uStack_208 & 0xffffffff00000000;
      uStack_210 = 0x1e;
      uStack_218 = 0;
      psStack_220 = (short *)0x0;
      uStack_228 = CONCAT71(uStack_228._1_7_,1);
      uStack_238 = CONCAT44(uStack_238._4_4_,0x33);
      cVar4 = func_0x(0,uVar5,0,0x18);
      if (cVar4 == '\0') {
        lVar15 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        lVar12 = *(longlong *)(lVar15 + 0x100);
        if (lVar12 == 0) {
          (*_DAT_)(0);
          lVar12 = *(longlong *)(lVar15 + 0x100);
        }
        uVar8 = *(undefined8 *)(lVar12 + 1000);
        uVar6 = (**(code **)(*plVar11 + 8))(plVar11);
        uStack_200 = 0;
        uStack_208 = 0;
        uStack_210 = uStack_210 & 0xffffff00;
        uStack_218 = CONCAT71(uStack_218._1_7_,1);
        psStack_220 = (short *)((ulonglong)psStack_220 & 0xffffffff00000000);
        uStack_228 = CONCAT44(uStack_228._4_4_,0xffffffff);
        uStack_230 = CONCAT44(uStack_230._4_4_,(uint)uVar1);
        uStack_238 = CONCAT44(uStack_238._4_4_,uVar6);
        cVar4 = func_0x(0x52454356,uVar8,plVar9,uVar1);
        if (cVar4 == '\0') {
          (*_DAT_)(0x98,0x2f,0x10,0x6c);
        }
      }
      lVar15 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar12 = *(longlong *)(lVar15 + 0x100);
      if (lVar12 == 0) {
        (*_DAT_)(0);
        lVar12 = *(longlong *)(lVar15 + 0x100);
      }
      func_0x(aiStack_190,*(undefined8 *)(lVar12 + 1000),0,8);
      lVar15 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar12 = *(longlong *)(lVar15 + 0x100);
      if (lVar12 == 0) {
        (*_DAT_)(0);
        lVar12 = *(longlong *)(lVar15 + 0x100);
      }
      func_0x(aiStack_170,*(undefined8 *)(lVar12 + 1000),0,4);
      lVar15 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar12 = *(longlong *)(lVar15 + 0x100);
      if (lVar12 == 0) {
        (*_DAT_)(0);
        lVar12 = *(longlong *)(lVar15 + 0x100);
      }
      uVar7 = (**(code **)(*plVar11 + 200))
                        (plVar11,*(undefined8 *)(lVar12 + 1000),aiStack_190,aiStack_170);
      if (uVar7 != 0) {
        do {
          uVar8 = (*_DAT_)(auStack_118);
          (*_DAT_)(uVar8,auStack_198[0]);
          if (uStack_154 <= uVar14) {
            if (uStack_158 <= uVar14) {
              func_0x(aiStack_170,uVar14 + 1);
            }
            uStack_154 = uVar14 + 1;
          }
          if (uStack_174 <= uVar14) {
            if (uStack_178 <= uVar14) {
              func_0x(aiStack_190,uVar14 + 1);
            }
            uStack_174 = uVar14 + 1;
          }
          (*_DAT_)(uVar8,*(undefined8 *)((ulonglong)(aiStack_190[0] * uVar14) + lStack_180))
          ;
          (*_DAT_)(auStack_118,uVar8);
          if (uStack_174 <= uVar14) {
            if (uStack_178 <= uVar14) {
              func_0x(aiStack_190,uVar14 + 1);
            }
            uStack_174 = uVar14 + 1;
          }
          (*_DAT_)(*(undefined8 *)((ulonglong)(aiStack_190[0] * uVar14) + lStack_180));
          uVar14 = uVar14 + 1;
        } while (uVar14 < uVar7);
      }
      if (lStack_160 != 0) {
        (*_DAT_)();
      }
      if (lStack_180 != 0) {
        (*_DAT_)();
      }
      cVar4 = (**(code **)(*plVar10 + 0x340))(plVar10,auStack_198);
    }
    (*_DAT_)(auStack_118,0);
    (*_DAT_)(auStack_118);
    (**(code **)*plVar9)(plVar9,1);
    param_4 = puStack_130;
    goto LAB_;
  }
  if (iVar13 != 1) {
    if (1 < iVar13) {
      *(undefined4 *)(param_4 + 8) = 0x1fd0;
      uStack_238 = CONCAT44(uStack_238._4_4_,(uint)uVar1);
      uStack_230 = uVar2;
      (*_DAT_)(0x51,0x2c,0x10,1);
    }
    goto LAB_;
  }
  lVar12 = *(longlong *)(*(longlong *)(param_3 + 0x10) + (longlong)*(int *)(param_3 + 0x28) * 8);
  if (**(char **)(lVar12 + 0x18) == '8') {
    if (**(char **)(lVar12 + 8) == '\x03') {
      uStack_228 = 0x14db520;
      uStack_230 = CONCAT44(uStack_230._4_4_,0x1e);
      uStack_238 = 0x10802e8;
      (*_DAT_)(2,0x19,0x10,1);
    }
  }
  else {
    uStack_230 = (*_DAT_)(CONCAT71((int7)(int3)((uint)*(int *)(param_3 + 0x28) >> 8),0x38));
    uStack_238 = 0x14db520;
    (*_DAT_)(2,0xe,0x10,0xd4);
  }
  uVar8 = (**(code **)(*(longlong *)auStack_140._0_8_ + 0x1b0))();
  lVar16 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar15 = *(longlong *)(lVar16 + 0x100);
  if (lVar15 == 0) {
    (*_DAT_)();
    lVar15 = *(longlong *)(lVar16 + 0x100);
  }
  plVar9 = (longlong *)(**_DAT_)(*(undefined8 *)(lVar15 + 1000),uVar8,0x14db330,0xd12);
  uVar1 = *(ushort *)
           (*(longlong *)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
             + 0x50) + 8);
  uStack_230 = uStack_230 & 0xffffffff00000000;
  uStack_238 = uStack_238 & 0xffffffff00000000;
  plStack_128 = plVar9;
  plVar10 = (longlong *)(**(code **)(*plVar9 + 0x38))(plVar9,uVar1,0,0);
  plVar10 = (longlong *)
            (**(code **)(*plVar10 + 0x328))
                      (plVar10,*(undefined4 *)(*(longlong *)(lVar12 + 8) + 8),0);
  uVar5 = (*_DAT_)();
  uStack_1a0 = 0;
  uStack_1a8 = 0;
  uStack_1b0 = 0;
  uStack_1b8 = 0;
  uStack_1c0 = 0;
  uStack_1c8 = 0;
  uStack_1d0 = 0;
  uStack_1d8 = 0;
  uStack_1e0 = 0;
  uStack_1e8 = 0xffffffff;
  uStack_1f0 = 0;
  uStack_1f8 = 0;
  uStack_200 = 0;
  uStack_208 = (ulonglong)uStack_208._4_4_ << 0x20;
  uStack_210 = 0x1e;
  uStack_218 = 0;
  psStack_220 = (short *)0x0;
  uStack_228 = CONCAT71(uStack_228._1_7_,1);
  uStack_238 = CONCAT44(uStack_238._4_4_,0x33);
  cVar4 = func_0x(0,uVar5,0,0x18);
  if (plVar10 == (longlong *)0x0) {
LAB_:
    asStack_88[0] = 0;
    func_0x
              (asStack_88,0x20,0x10cbca0,*(undefined4 *)(*(longlong *)(lVar12 + 8) + 8));
    *(undefined4 *)(param_4 + 8) = 0x3b2f;
    lVar15 = -1;
    do {
      lVar15 = lVar15 + 1;
    } while (asStack_88[lVar15] != 0);
    uStack_228 = lVar15 * 2;
    psStack_220 = asStack_88;
    uStack_230 = CONCAT44(uStack_230._4_4_,0x8ac9);
    uStack_238 = CONCAT44(uStack_238._4_4_,0x333e);
    (*_DAT_)(0x97,0x33,0x10,1);
  }
  else if (cVar4 == '\0') {
    lVar16 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar15 = *(longlong *)(lVar16 + 0x100);
    if (lVar15 == 0) {
      (*_DAT_)(0);
      lVar15 = *(longlong *)(lVar16 + 0x100);
    }
    uVar8 = *(undefined8 *)(lVar15 + 1000);
    uVar6 = (**(code **)(*plVar10 + 8))(plVar10);
    uStack_200 = 0;
    uStack_208 = 0;
    uStack_210 = uStack_210 & 0xffffff00;
    uStack_218 = CONCAT71(uStack_218._1_7_,1);
    psStack_220 = (short *)((ulonglong)psStack_220 & 0xffffffff00000000);
    uStack_228 = CONCAT44(uStack_228._4_4_,0xffffffff);
    uStack_230 = CONCAT44(uStack_230._4_4_,(uint)uVar1);
    uStack_238 = CONCAT44(uStack_238._4_4_,uVar6);
    cVar4 = func_0x(0x52454356,uVar8,plVar9,uVar1);
    if (cVar4 == '\0') goto LAB_;
  }
  lVar16 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar15 = *(longlong *)(lVar16 + 0x100);
  if (lVar15 == 0) {
    (*_DAT_)(0);
    lVar15 = *(longlong *)(lVar16 + 0x100);
  }
  func_0x(aiStack_190,*(undefined8 *)(lVar15 + 1000),0,8);
  lVar16 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar15 = *(longlong *)(lVar16 + 0x100);
  if (lVar15 == 0) {
    (*_DAT_)(0);
    lVar15 = *(longlong *)(lVar16 + 0x100);
  }
  func_0x(aiStack_170,*(undefined8 *)(lVar15 + 1000),0,4);
  lVar16 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar15 = *(longlong *)(lVar16 + 0x100);
  if (lVar15 == 0) {
    (*_DAT_)(0);
    lVar15 = *(longlong *)(lVar16 + 0x100);
  }
  uVar14 = (**(code **)(*plVar10 + 200))
                     (plVar10,*(undefined8 *)(lVar15 + 1000),aiStack_190,aiStack_170);
  (*_DAT_)(auStack_118,0,2);
  (*_DAT_)(auStack_118,0x14db4a8,7);
  (*_DAT_)(auStack_118,0x14db498,0xd,0x1fc);
  uVar7 = 0;
  if (uVar14 != 0) {
    do {
      uVar8 = (*_DAT_)(auStack_118);
      (*_DAT_)(uVar8,*(undefined4 *)(*(longlong *)(lVar12 + 8) + 8));
      if (uStack_154 <= uVar7) {
        if (uStack_158 <= uVar7) {
          func_0x(aiStack_170,uVar7 + 1);
        }
        uStack_154 = uVar7 + 1;
      }
      puVar17 = (undefined4 *)((ulonglong)(aiStack_170[0] * uVar7) + lStack_160);
      if (uStack_174 <= uVar7) {
        if (uStack_178 <= uVar7) {
          func_0x(aiStack_190,uVar7 + 1);
        }
        uStack_174 = uVar7 + 1;
      }
      (*_DAT_)(uVar8,*(undefined8 *)((ulonglong)(aiStack_190[0] * uVar7) + lStack_180),
                       *puVar17);
      (*_DAT_)(auStack_118,uVar8);
      if (uStack_174 <= uVar7) {
        if (uStack_178 <= uVar7) {
          func_0x(aiStack_190,uVar7 + 1);
        }
        uStack_174 = uVar7 + 1;
      }
      (*_DAT_)(*(undefined8 *)((ulonglong)(aiStack_190[0] * uVar7) + lStack_180));
      uVar7 = uVar7 + 1;
    } while (uVar7 < uVar14);
  }
  (*_DAT_)(auStack_118,0);
  (*_DAT_)(auStack_118);
  if (lStack_160 != 0) {
    (*_DAT_)();
  }
  if (lStack_180 != 0) {
    (*_DAT_)();
  }
  (**(code **)*plVar9)(plVar9,1);
LAB_:
  func_0x(&uStack_150,0);
  *(undefined4 *)(param_4 + 8) = 0;
  *param_4 = 0;
  if ((int)uStack_150 != 0) {
    func_0x(&uStack_150,0);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_258);
  return;
}

