
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong *param_2,longlong param_3,undefined *param_4)

{
  ushort uVar1;
  int iVar2;
  byte *pbVar3;
  undefined8 uVar4;
  int iVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  undefined8 in_stack_ffffffffffffffb8;
  
  lVar7 = 0;
  if (param_3 == 0) {
    *(undefined4 *)(param_4 + 8) = 0;
LAB_:
    in_stack_ffffffffffffffb8 = CONCAT44((int)((ulonglong)in_stack_ffffffffffffffb8 >> 0x20),4);
    (*_DAT_)(0x1d8,1,0x10,1,in_stack_ffffffffffffffb8);
    if (param_3 != 0) goto LAB_;
    in_stack_ffffffffffffffb8 = 0;
    (*_DAT_)(1,0x171a5e4,0x1710ca0,0x1ec,0);
LAB_:
    in_stack_ffffffffffffffb8 =
         CONCAT44((int)((ulonglong)in_stack_ffffffffffffffb8 >> 0x20),
                  (uint)*(ushort *)((undefined8 *)*param_2 + 1));
    (*_DAT_)(2,1,0x10,1,in_stack_ffffffffffffffb8,*(undefined8 *)*param_2,0xe,0x15d84a8);
    lVar9 = lVar7;
    if (param_3 != 0) goto LAB_;
  }
  else {
    iVar5 = *(int *)(param_3 + 0x1c);
    iVar2 = *(int *)(param_3 + 0x28);
    *(undefined4 *)(param_4 + 8) = 0;
    if (iVar5 - iVar2 != 4) goto LAB_;
LAB_:
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 1) goto LAB_;
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      in_stack_ffffffffffffffb8 = 0x15d84a8;
      (*_DAT_)(2,0xe,0x10,1,0x15d84a8,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      in_stack_ffffffffffffffb8 = 0x15d84a8;
      (*_DAT_)(2,0xe,0x10,1,0x15d84a8,uVar4);
    }
    if ((*pbVar3 & 1) == 0) {
      in_stack_ffffffffffffffb8 = *(undefined8 *)*param_2;
      (*_DAT_)(5,0x5b,0x10,1,in_stack_ffffffffffffffb8,0x15d84a8);
    }
    lVar9 = *(longlong *)(pbVar3 + 8);
LAB_:
    if (1 < *(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28)) {
      pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 8 + (longlong)*(int *)(param_3 + 0x28) * 8
                         );
      if (**(char **)(pbVar3 + 0x18) != DAT_) {
        uVar4 = (*_DAT_)();
        in_stack_ffffffffffffffb8 = 0x1653208;
        (*_DAT_)(2,0xe,0x10,1,0x1653208,uVar4);
      }
      if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
        uVar4 = (*_DAT_)(DAT_);
        in_stack_ffffffffffffffb8 = 0x1653208;
        (*_DAT_)(2,0xe,0x10,1,0x1653208,uVar4);
      }
      if ((*pbVar3 & 1) == 0) {
        in_stack_ffffffffffffffb8 = *(undefined8 *)*param_2;
        (*_DAT_)(5,0x5b,0x10,1,in_stack_ffffffffffffffb8,0x1653208);
      }
      lVar8 = *(longlong *)(pbVar3 + 8);
      goto LAB_;
    }
  }
  in_stack_ffffffffffffffb8 =
       CONCAT44((int)((ulonglong)in_stack_ffffffffffffffb8 >> 0x20),
                (uint)*(ushort *)((undefined8 *)*param_2 + 1));
  (*_DAT_)(2,1,0x10,1,in_stack_ffffffffffffffb8,*(undefined8 *)*param_2,0x1c,0x1653208);
  lVar8 = lVar7;
LAB_:
  iVar5 = *(int *)(param_3 + 0x28);
  pbVar3 = *(byte **)(*(longlong *)(*(longlong *)(param_3 + 0x10) + 8 + (longlong)iVar5 * 8) + 0x18)
  ;
  uVar1 = *(ushort *)(pbVar3 + 0x10);
  if (((uVar1 != 0xffff) &&
      (*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar3 + 0x12219d0) + 0x1cff178) == '\0')) &&
     (uVar1 < 8000)) {
    (*_DAT_)(0x51,0x34,0x10,0x28);
    iVar5 = *(int *)(param_3 + 0x28);
  }
  if (*(int *)(param_3 + 0x1c) - iVar5 < 3) {
    in_stack_ffffffffffffffb8 =
         CONCAT44((int)((ulonglong)in_stack_ffffffffffffffb8 >> 0x20),
                  (uint)*(ushort *)((undefined8 *)*param_2 + 1));
    (*_DAT_)(2,1,0x10,1,in_stack_ffffffffffffffb8,*(undefined8 *)*param_2,0x10,0x1653118);
    lVar6 = lVar7;
  }
  else {
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x10 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      in_stack_ffffffffffffffb8 = 0x1653118;
      (*_DAT_)(2,0xe,0x10,1,0x1653118,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      in_stack_ffffffffffffffb8 = 0x1653118;
      (*_DAT_)(2,0xe,0x10,1,0x1653118,uVar4);
    }
    if ((*pbVar3 & 1) != 0) {
      in_stack_ffffffffffffffb8 = CONCAT44((int)((ulonglong)in_stack_ffffffffffffffb8 >> 0x20),0x10)
      ;
      (*_DAT_)(0x51,0x3e,0x10,1,in_stack_ffffffffffffffb8,0x1653118);
    }
    lVar6 = *(longlong *)(pbVar3 + 8);
  }
  if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 4) {
    in_stack_ffffffffffffffb8 =
         CONCAT44((int)((ulonglong)in_stack_ffffffffffffffb8 >> 0x20),
                  (uint)*(ushort *)((undefined8 *)*param_2 + 1));
    (*_DAT_)(2,1,0x10,1,in_stack_ffffffffffffffb8,*(undefined8 *)*param_2,0x10,0x1653228);
  }
  else {
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x18 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      in_stack_ffffffffffffffb8 = 0x1653228;
      (*_DAT_)(2,0xe,0x10,1,0x1653228,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      in_stack_ffffffffffffffb8 = 0x1653228;
      (*_DAT_)(2,0xe,0x10,1,0x1653228,uVar4);
    }
    if ((*pbVar3 & 1) == 0) {
      in_stack_ffffffffffffffb8 = *(undefined8 *)*param_2;
      (*_DAT_)(5,0x5b,0x10,1,in_stack_ffffffffffffffb8,0x1653228);
    }
    lVar7 = *(longlong *)(pbVar3 + 8);
  }
  pbVar3 = *(byte **)(*(longlong *)
                       (*(longlong *)(param_3 + 0x10) + 0x18 +
                       (longlong)*(int *)(param_3 + 0x28) * 8) + 0x18);
  uVar1 = *(ushort *)(pbVar3 + 0x10);
  if (((uVar1 != 0xffff) &&
      (*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar3 + 0x12219d0) + 0x1cff178) == '\0')) &&
     (uVar1 < 8000)) {
    (*_DAT_)(0x51,0x34,0x10,0x28);
  }
  (*_DAT_)(lVar9,lVar8,*(undefined4 *)(lVar6 + 8),lVar7,
                   CONCAT71((int7)((ulonglong)in_stack_ffffffffffffffb8 >> 8),
                            (char)((uint)*(undefined4 *)(param_3 + 0x20) >> 8)) & 0xffffffffffffff01
                  );
  *param_4 = 0;
  return;
}

