
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x01689046) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong param_2,longlong param_3,int param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 *param_7,undefined8 *param_8)

{
  longlong lVar1;
  undefined auVar2 [16];
  uint uVar3;
  undefined8 uVar4;
  longlong lVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  uint uVar9;
  longlong *plVar10;
  uint uVar11;
  ulonglong uVar12;
  ulonglong uVar13;
  uint uVar14;
  undefined8 uStack_c8;
  undefined4 uStack_c0;
  undefined8 uStack_b8;
  undefined uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  longlong lStack_a0;
  int iStack_98;
  undefined8 uStack_90;
  undefined8 *puStack_88;
  longlong lStack_80;
  ulonglong uStack_78;
  longlong lStack_70;
  undefined8 *puStack_68;
  undefined8 *puStack_60;
  undefined8 uStack_58;
  
  uStack_58 = 0xfffffffffffffffe;
  if (param_4 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar13 = 0;
  iStack_98 = 0;
  uVar14 = *(uint *)(param_3 + 0x18);
  uStack_b0 = 0;
  uStack_ac = 0;
  uStack_a8 = 1;
  if (uVar14 != 0) {
    uStack_a8 = uVar14;
  }
  lStack_a0 = 0;
  uStack_c0 = 1;
  uStack_c8 = 0x1ffef80;
  uVar4 = SUB168(ZEXT816(8) * ZEXT416(uVar14),0);
  if (SUB168(ZEXT816(8) * ZEXT416(uVar14),8) != 0) {
    uVar4 = 0xffffffffffffffff;
  }
  uStack_b8 = param_1;
  uStack_90 = param_1;
  lVar5 = (*_DAT_)(uVar4,param_1,0x20ace80,0x647,1);
  uVar3 = uStack_a8;
  uVar9 = 0;
  uVar12 = uVar13;
  lStack_80 = lVar5;
  if (uVar14 != 0) {
    do {
      lVar1 = *(longlong *)(*(longlong *)(param_3 + 0x20) + (longlong)(int)uVar12 * 8);
      if ((*(byte *)(*(longlong *)(lVar1 + 0x50) + 0x28) & 1) == 0) {
        if (lStack_a0 == 0) {
          uStack_a8 = uVar3;
          lStack_a0 = func_0x(&uStack_b8,uVar3);
        }
        if (uVar3 <= uStack_ac) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *(longlong *)(lStack_a0 + (ulonglong)uStack_ac * 8) = lVar1;
        uStack_ac = uStack_ac + 1;
        lVar5 = lStack_80;
      }
      else {
        *(longlong *)(lVar5 + uVar13 * 8) = lVar1;
        uVar9 = (int)uVar13 + 1;
      }
      uVar13 = (ulonglong)uVar9;
      uVar11 = (int)uVar12 + 1;
      param_1 = uStack_90;
      uVar12 = (ulonglong)uVar11;
    } while (uVar11 < uVar14);
  }
  if ((param_4 != 0) || (uStack_ac == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(int *)(param_2 + 8) = *(int *)(param_2 + 8) + 1;
  uStack_a8 = uVar3;
  puVar6 = (undefined8 *)(*_DAT_)(0x28,param_1,0x20ace80,0x671,1);
  if (puVar6 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar6 = 0x1fe5078;
  *(undefined4 *)(puVar6 + 1) = 1;
  *puVar6 = 0x1f58930;
  puVar6[2] = param_1;
  *puVar6 = 0x1f1c528;
  *puVar6 = 0x1f1f910;
  puVar6[3] = 0;
  *(undefined *)(puVar6 + 4) = 1;
  puStack_60 = puVar6;
  uVar4 = func_0x(1,param_1,&uStack_c8);
  puVar7 = (undefined8 *)(*_DAT_)(0xa8,param_1,0x20ace80,0x674,1);
  if (puVar7 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar7 = 0x1fe5078;
  *(undefined4 *)(puVar7 + 1) = 1;
  *puVar7 = 0x1ffef38;
  puVar7[0xc] = 0;
  puVar7[0xd] = 0;
  puVar7[0xe] = 0;
  puVar7[0xf] = 0;
  puVar7[0x11] = _DAT_;
  puVar7[0x12] = 0;
  puVar7[0x13] = 0;
  puVar7[0x14] = 0;
  *(undefined4 *)(puVar7 + 3) = 2;
  puVar7[4] = puVar7 + 5;
  puVar7[5] = param_2;
  *(undefined8 *)(puVar7[4] + 8) = uVar4;
  puVar7[2] = puVar6;
  puVar7[10] = 0;
  puVar7[0xb] = 0;
  puVar7[0x10] = 0;
  puStack_88 = puVar7;
  puStack_60 = puVar7;
  func_0x(&uStack_b8);
  uVar13 = CONCAT44(0,uVar9);
  auVar2._8_8_ = 0;
  auVar2._0_8_ = uVar13;
  uVar4 = SUB168(ZEXT816(8) * auVar2,0);
  if (SUB168(ZEXT816(8) * auVar2,8) != 0) {
    uVar4 = 0xffffffffffffffff;
  }
  uStack_78 = uVar13;
  plVar8 = (longlong *)(*_DAT_)(uVar4,uStack_90,0x20ace80,0x683,1);
  *(int *)(puVar7 + 1) = *(int *)(puVar7 + 1) + 1;
  puVar6 = puVar7;
  uVar12 = uVar13;
  if (uVar9 != 0) {
    lVar5 = lStack_80 - (longlong)plVar8;
    plVar10 = plVar8;
    do {
      func_0x(uStack_90,puVar6,*(undefined8 *)(lVar5 + (longlong)plVar10),0,param_5,param_6,
                      &puStack_68,&lStack_70);
      *plVar10 = lStack_70;
      puVar6 = puVar6 + 1;
      *(int *)puVar6 = *(int *)puVar6 + -1;
      if (*(int *)puVar6 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      plVar10 = plVar10 + 1;
      uVar13 = uVar13 - 1;
      puVar7 = puStack_88;
      puVar6 = puStack_68;
      uVar12 = uStack_78;
    } while (uVar13 != 0);
  }
  *param_7 = puVar6;
  puVar7 = puVar7 + 1;
  *(int *)puVar7 = *(int *)puVar7 + -1;
  if (*(int *)puVar7 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar13 = 0;
  if (uVar9 != 0) {
    do {
      if (plVar8[uVar13] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar14 = (int)uVar13 + 1;
      uVar13 = (ulonglong)uVar14;
    } while (uVar14 < uVar9);
  }
  if (uStack_ac != 0) {
    uVar4 = func_0x(1,uStack_90,&uStack_c8);
    *param_8 = uVar4;
    plVar10 = plVar8;
    if (uVar9 != 0) {
      do {
        if (*plVar10 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        uVar12 = uVar12 - 1;
        plVar10 = plVar10 + 1;
      } while (uVar12 != 0);
    }
    if (iStack_98 == 0) {
      (*_DAT_)(lStack_80);
      (*_DAT_)(plVar8);
      uStack_c8 = 0x1fe5078;
      func_0x(&uStack_b8);
      if (lStack_a0 != 0) {
        (*_DAT_)();
      }
      return;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

