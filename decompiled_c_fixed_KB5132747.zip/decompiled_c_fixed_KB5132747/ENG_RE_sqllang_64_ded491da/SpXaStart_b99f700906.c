
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong *param_2,longlong param_3,undefined *param_4)

{
  ushort uVar1;
  int iVar2;
  byte *pbVar3;
  undefined8 uVar4;
  int iVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  undefined8 uStackX_18;
  undefined8 uStack_68;
  longlong lStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  
  lVar6 = 0;
  if (param_3 == 0) {
    *(undefined4 *)(param_4 + 8) = 0;
LAB_:
    (*_DAT_)(0x1d8,3,0x10,1,9,0x10);
    if (param_3 != 0) goto LAB_;
    (*_DAT_)(1,0x171b6e4,0x1711da0,0x75,0);
LAB_:
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     0xe,0x15d95a8);
    uStackX_18 = 0;
    if (param_3 != 0) goto LAB_;
    uStackX_18 = 0;
  }
  else {
    iVar5 = *(int *)(param_3 + 0x1c);
    iVar2 = *(int *)(param_3 + 0x28);
    *(undefined4 *)(param_4 + 8) = 0;
    if (7 < (iVar5 - iVar2) - 9U) goto LAB_;
LAB_:
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 1) goto LAB_;
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x15d95a8,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x15d95a8,uVar4);
    }
    if ((*pbVar3 & 1) == 0) {
      (*_DAT_)(5,0x5b,0x10,1,*(undefined8 *)*param_2,0x15d95a8);
    }
    uStackX_18 = *(undefined8 *)(pbVar3 + 8);
LAB_:
    if (1 < *(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28)) {
      pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 8 + (longlong)*(int *)(param_3 + 0x28) * 8
                         );
      if (**(char **)(pbVar3 + 0x18) != DAT_) {
        uVar4 = (*_DAT_)();
        (*_DAT_)(2,0xe,0x10,1,0x1654308,uVar4);
      }
      if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
        uVar4 = (*_DAT_)(DAT_);
        (*_DAT_)(2,0xe,0x10,1,0x1654308,uVar4);
      }
      if ((*pbVar3 & 1) == 0) {
        (*_DAT_)(5,0x5b,0x10,1,*(undefined8 *)*param_2,0x1654308);
      }
      uStack_48 = *(undefined8 *)(pbVar3 + 8);
      goto LAB_;
    }
  }
  (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                   0x1c,0x1654308);
  uStack_48 = 0;
LAB_:
  iVar5 = *(int *)(param_3 + 0x28);
  pbVar3 = *(byte **)(*(longlong *)(*(longlong *)(param_3 + 0x10) + 8 + (longlong)iVar5 * 8) + 0x18)
  ;
  uVar1 = *(ushort *)(pbVar3 + 0x10);
  if (((uVar1 != 0xffff) &&
      (*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar3 + 0x1222ad0) + 0x1d00278) == '\0')) &&
     (uVar1 < 8000)) {
    (*_DAT_)(0x51,0x34,0x10,0x28);
    iVar5 = *(int *)(param_3 + 0x28);
  }
  if (*(int *)(param_3 + 0x1c) - iVar5 < 3) {
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     8,0x16542f8);
    uStack_50 = 0;
  }
  else {
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x10 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x16542f8,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x16542f8,uVar4);
    }
    if ((*pbVar3 & 1) != 0) {
      (*_DAT_)(0x51,0x3e,0x10,1,8,0x16542f8);
    }
    uStack_50 = *(undefined8 *)(pbVar3 + 8);
  }
  if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 4) {
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     8,0x1654230);
    uStack_58 = 0;
  }
  else {
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x18 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x1654230,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1654230,uVar4);
    }
    if ((*pbVar3 & 1) != 0) {
      (*_DAT_)(0x51,0x3e,0x10,1,8,0x1654230);
    }
    uStack_58 = *(undefined8 *)(pbVar3 + 8);
  }
  if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 5) {
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     0x10,0x1654218);
    lStack_60 = 0;
  }
  else {
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x20 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x1654218,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1654218,uVar4);
    }
    if ((*pbVar3 & 1) != 0) {
      (*_DAT_)(0x51,0x3e,0x10,1,0x10,0x1654218);
    }
    lStack_60 = *(longlong *)(pbVar3 + 8);
  }
  if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 6) {
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     0x18,0x1654260);
    uStack_68 = 0;
  }
  else {
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x28 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x1654260,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1654260,uVar4);
    }
    if ((*pbVar3 & 1) == 0) {
      (*_DAT_)(5,0x5b,0x10,1,*(undefined8 *)*param_2,0x1654260);
    }
    uStack_68 = *(undefined8 *)(pbVar3 + 8);
  }
  iVar5 = *(int *)(param_3 + 0x28);
  pbVar3 = *(byte **)(*(longlong *)(*(longlong *)(param_3 + 0x10) + 0x28 + (longlong)iVar5 * 8) +
                     0x18);
  uVar1 = *(ushort *)(pbVar3 + 0x10);
  if (((uVar1 != 0xffff) &&
      (*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar3 + 0x1222ad0) + 0x1d00278) == '\0')) &&
     (uVar1 < 8000)) {
    (*_DAT_)(0x51,0x34,0x10,0x28);
    iVar5 = *(int *)(param_3 + 0x28);
  }
  if (*(int *)(param_3 + 0x1c) - iVar5 < 7) {
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     0x1e,0x1654240);
    lVar8 = lVar6;
  }
  else {
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x30 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x1654240,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1654240,uVar4);
    }
    if ((*pbVar3 & 1) != 0) {
      (*_DAT_)(0x51,0x3e,0x10,1,0x1e,0x1654240);
    }
    lVar8 = *(longlong *)(pbVar3 + 8);
  }
  if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 8) {
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     0x12,0x1654298);
    lVar10 = lVar6;
  }
  else {
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x38 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x1654298,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1654298,uVar4);
    }
    if ((*pbVar3 & 1) != 0) {
      (*_DAT_)(0x51,0x3e,0x10,1,0x12,0x1654298);
    }
    lVar10 = *(longlong *)(pbVar3 + 8);
  }
  if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 9) {
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     0x16,0x1654280);
    lVar9 = lVar6;
  }
  else {
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x40 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar3 + 0x18) != DAT_) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x1654280,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1654280,uVar4);
    }
    if ((*pbVar3 & 1) == 0) {
      (*_DAT_)(5,0x5b,0x10,1,*(undefined8 *)*param_2,0x1654280);
    }
    lVar9 = *(longlong *)(pbVar3 + 8);
  }
  iVar5 = *(int *)(param_3 + 0x28);
  pbVar3 = *(byte **)(*(longlong *)(*(longlong *)(param_3 + 0x10) + 0x40 + (longlong)iVar5 * 8) +
                     0x18);
  uVar1 = *(ushort *)(pbVar3 + 0x10);
  if (((uVar1 != 0xffff) &&
      (*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar3 + 0x1222ad0) + 0x1d00278) == '\0')) &&
     (uVar1 < 8000)) {
    (*_DAT_)(0x51,0x34,0x10,0x28);
    iVar5 = *(int *)(param_3 + 0x28);
  }
  lVar7 = lVar6;
  if (0xe < *(int *)(param_3 + 0x1c) - iVar5) {
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x70 + (longlong)iVar5 * 8);
    if ((**(char **)(pbVar3 + 0x18) != DAT_) && (**(char **)(pbVar3 + 0x18) != '\x1f')) {
      uVar4 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x16542c0,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x16542c0,uVar4);
    }
    if ((*pbVar3 & 1) != 0) {
      (*_DAT_)(0x51,0x3e,0x10,1,0x30,0x16542c0);
    }
    lVar7 = *(longlong *)(pbVar3 + 8);
  }
  if (0xf < *(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28)) {
    pbVar3 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x78 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if ((**(char **)(pbVar3 + 0x18) != DAT_) && (**(char **)(pbVar3 + 0x18) != '\x1f')) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x16542b0,uVar4);
    }
    if ((**(char **)(pbVar3 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x16542b0,uVar4);
    }
    if ((*pbVar3 & 1) == 0) {
      (*_DAT_)(5,0x5b,0x10,1,*(undefined8 *)*param_2,0x16542b0);
    }
    lVar6 = *(longlong *)(pbVar3 + 8);
    if (lVar6 != 0) {
      pbVar3 = *(byte **)(*(longlong *)
                           (*(longlong *)(param_3 + 0x10) + 0x78 +
                           (longlong)*(int *)(param_3 + 0x28) * 8) + 0x18);
      uVar1 = *(ushort *)(pbVar3 + 0x10);
      if (((uVar1 != 0xffff) &&
          (*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar3 + 0x1222ad0) + 0x1d00278) == '\0')) &&
         (uVar1 < 8000)) {
        (*_DAT_)(0x51,0x34,0x10,0x28);
      }
    }
  }
  (*_DAT_)(uStackX_18,uStack_48,uStack_50,uStack_58,*(undefined4 *)(lStack_60 + 8),uStack_68
                   ,*(undefined4 *)(lVar8 + 8),*(undefined4 *)(lVar10 + 8),lVar9,lVar7,lVar6,
                   (byte)((uint)*(undefined4 *)(param_3 + 0x20) >> 8) & 1);
  *param_4 = 0;
  return;
}

