
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong *param_2,longlong param_3)

{
  ushort uVar1;
  byte *pbVar2;
  undefined8 uVar3;
  int iVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  
  lVar6 = 0;
  if (((param_3 == 0) || (1 < (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28)) - 2U)) &&
     ((*_DAT_)(0x1d8,2,0x10,1,2,3), param_3 == 0)) {
    (*_DAT_)(1,0x171a014,0x17106d0,0x23d,0);
LAB_:
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     0xe,0x15d7ed8);
    lVar7 = lVar6;
    if (param_3 != 0) goto LAB_;
  }
  else {
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 1) goto LAB_;
    pbVar2 = *(byte **)(*(longlong *)(param_3 + 0x10) + (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar2 + 0x18) != DAT_) {
      uVar3 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x15d7ed8,uVar3);
    }
    if ((**(char **)(pbVar2 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar3 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x15d7ed8,uVar3);
    }
    if ((*pbVar2 & 1) == 0) {
      (*_DAT_)(5,0x5b,0x10,1,*(undefined8 *)*param_2,0x15d7ed8);
    }
    lVar7 = *(longlong *)(pbVar2 + 8);
LAB_:
    if (1 < *(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28)) {
      pbVar2 = *(byte **)(*(longlong *)(param_3 + 0x10) + 8 + (longlong)*(int *)(param_3 + 0x28) * 8
                         );
      if (**(char **)(pbVar2 + 0x18) != DAT_) {
        uVar3 = (*_DAT_)();
        (*_DAT_)(2,0xe,0x10,1,0x1652c38,uVar3);
      }
      if ((**(char **)(pbVar2 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
        uVar3 = (*_DAT_)(DAT_);
        (*_DAT_)(2,0xe,0x10,1,0x1652c38,uVar3);
      }
      if ((*pbVar2 & 1) == 0) {
        (*_DAT_)(5,0x5b,0x10,1,*(undefined8 *)*param_2,0x1652c38);
      }
      lVar5 = *(longlong *)(pbVar2 + 8);
      goto LAB_;
    }
  }
  (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                   0x1c,0x1652c38);
  lVar5 = lVar6;
LAB_:
  iVar4 = *(int *)(param_3 + 0x28);
  pbVar2 = *(byte **)(*(longlong *)(*(longlong *)(param_3 + 0x10) + 8 + (longlong)iVar4 * 8) + 0x18)
  ;
  uVar1 = *(ushort *)(pbVar2 + 0x10);
  if (((uVar1 != 0xffff) &&
      (*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar2 + 0x1221400) + 0x1cfeba8) == '\0')) &&
     (uVar1 < 8000)) {
    (*_DAT_)(0x51,0x34,0x10,0x28);
    iVar4 = *(int *)(param_3 + 0x28);
  }
  if (2 < *(int *)(param_3 + 0x1c) - iVar4) {
    pbVar2 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x10 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if ((**(char **)(pbVar2 + 0x18) != DAT_) && (**(char **)(pbVar2 + 0x18) != '\x1f')) {
      uVar3 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1652bb0,uVar3);
    }
    if ((**(char **)(pbVar2 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar3 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1652bb0,uVar3);
    }
    if ((*pbVar2 & 1) == 0) {
      (*_DAT_)(5,0x5b,0x10,1,*(undefined8 *)*param_2,0x1652bb0);
    }
    lVar6 = *(longlong *)(pbVar2 + 8);
    if (lVar6 != 0) {
      pbVar2 = *(byte **)(*(longlong *)
                           (*(longlong *)(param_3 + 0x10) + 0x10 +
                           (longlong)*(int *)(param_3 + 0x28) * 8) + 0x18);
      uVar1 = *(ushort *)(pbVar2 + 0x10);
      if (((uVar1 != 0xffff) &&
          (*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar2 + 0x1221400) + 0x1cfeba8) == '\0')) &&
         (uVar1 < 8000)) {
        (*_DAT_)(0x51,0x34,0x10,0x28);
      }
    }
  }
                    /* WARNING: Could not recover jumptable at 0x00100475. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*_DAT_)(lVar7,lVar5,lVar6,*(uint *)(param_3 + 0x20) >> 8 & 0xffffff01);
  return;
}

