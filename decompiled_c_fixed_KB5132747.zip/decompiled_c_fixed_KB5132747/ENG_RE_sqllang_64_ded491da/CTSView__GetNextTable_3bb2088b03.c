
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1)

{
  longlong lVar1;
  longlong *plVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x50) == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 0x50) != 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar1 = *(longlong *)(param_1 + 0x38);
  iVar3 = *(int *)(param_1 + 0x54);
  if (*(int *)(param_1 + 0x58) == *(int *)(lVar1 + (longlong)iVar3 * 4)) {
    do {
      iVar3 = *(int *)(param_1 + 0x54);
      *(int *)(param_1 + 0x54) = iVar3 + 1;
      plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8 + (longlong)iVar3 * 8);
      (**(code **)(*plVar2 + 0x10))(plVar2,*(undefined4 *)(param_1 + 0x50));
      *(undefined4 *)(param_1 + 0x58) = 0;
      iVar3 = *(int *)(param_1 + 0x54);
    } while (*(int *)(lVar1 + (longlong)iVar3 * 4) == 0);
  }
  (**(code **)(**(longlong **)(*(longlong *)(param_1 + 0x30) + (longlong)iVar3 * 8) + 0x18))();
  *(int *)(param_1 + 0x58) = *(int *)(param_1 + 0x58) + 1;
  return;
}

