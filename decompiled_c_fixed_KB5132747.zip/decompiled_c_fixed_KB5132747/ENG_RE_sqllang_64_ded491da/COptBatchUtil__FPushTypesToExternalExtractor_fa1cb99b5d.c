
bool FUN_(byte *param_1,byte *param_2)

{
  byte bVar1;
  uint uVar2;
  char cVar3;
  byte bVar4;
  ulonglong uVar5;
  uint uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  
  if (*(short *)(param_2 + 0x10) != -1) {
    bVar1 = *param_2;
    uVar8 = (ulonglong)*(byte *)((ulonglong)bVar1 + 0xb658c0);
    if (*(char *)(uVar8 + 0x1643068) == '\0') {
      bVar4 = *param_1;
      uVar7 = (ulonglong)bVar4;
      uVar6 = (uint)bVar4;
      if ((((bVar4 != bVar1) &&
           ((uVar5 = (ulonglong)*(byte *)(uVar7 + 0xb658c0), *(char *)(uVar5 + 0xba27e0) == '\0' ||
            (*(char *)(uVar8 + 0xba27e0) == '\0')))) &&
          ((*(char *)(uVar5 + 0xba2890) == '\0' || (*(char *)(uVar8 + 0xba2890) == '\0')))) &&
         (((*(char *)(uVar5 + 0xbb4080) == '\0' || (*(char *)(uVar8 + 0xbb4080) == '\0')) &&
          ((*(char *)(uVar5 + 0xb9a730) == '\0' || (*(char *)(uVar8 + 0xb9a730) == '\0')))))) {
        if ((bVar4 == 0xf0) || (uVar2 = uVar6, bVar4 == 0xf3)) {
          uVar2 = *(uint *)(param_1 + 4);
        }
        if (uVar2 != 0x7f) {
          return false;
        }
        if (*(char *)(uVar8 + 0xb9a730) == '\0') {
          return false;
        }
      }
      if ((bVar4 == 0xf0) || (bVar4 == 0xf3)) {
        uVar6 = *(uint *)(param_1 + 4);
      }
      switch(uVar6 - 0x24) {
      case 0:
      case 4:
      case 0xc:
      case 0x10:
      case 0x14:
      case 0x17:
      case 0x1a:
      case 0x44:
      case 0x81:
      case 0x89:
        return true;
      case 5:
      case 6:
        if ((byte)(bVar4 + 0x10) < 2) {
          return *(char *)((ulonglong)*(byte *)(uVar7 + 0xb658c0) * 4 + 0xb659c3) == '\a';
        }
        return param_1[0x13] == 7;
      case 0x46:
      case 0x48:
        if ((byte)(bVar4 + 0x10) < 2) {
          bVar4 = *(byte *)((ulonglong)*(byte *)(uVar7 + 0xb658c0) * 4 + 0xb659c3);
        }
        else {
          bVar4 = param_1[0x13];
        }
        if ((byte)(bVar1 + 0x10) < 2) {
          return bVar4 == *(byte *)(uVar8 * 4 + 0xb659c3);
        }
        return bVar4 == param_2[0x13];
      case 0x5b:
        if (*(char *)(uVar8 + 0xb9a730) == '\0') {
          return true;
        }
        if ((byte)(bVar1 + 0x10) < 2) {
          return *(char *)(uVar8 * 4 + 0xb659c3) == '\0';
        }
        return param_2[0x13] == 0;
      case 0x83:
      case 0x8b:
      case 0xc3:
      case 0xcb:
        cVar3 = (*pcRam0000000000a0d370)(param_1);
        if (cVar3 != '\0') {
          return true;
        }
        cVar3 = (*pcRam0000000000a0dbe8)(param_1);
        if ((cVar3 != '\0') && (cRam0000000001627a8a == '\0')) {
          return true;
        }
        cVar3 = (*pcRam0000000000a0d368)(param_1);
        if (((cVar3 != '\0') || (cVar3 = (*pcRam0000000000a0d360)(param_1), cVar3 != '\0')) &&
           (cRam0000000001627a89 != '\0')) {
          return true;
        }
        func_0x(0x40ba,10,1);
      }
    }
  }
  return false;
}

