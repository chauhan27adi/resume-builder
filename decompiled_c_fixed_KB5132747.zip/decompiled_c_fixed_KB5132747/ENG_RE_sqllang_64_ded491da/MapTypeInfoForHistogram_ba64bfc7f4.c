
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(uint *param_1,uint *param_2)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  char cVar5;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  uint uStack_10;
  uint uStack_c;
  
  cVar1 = *(char *)param_1;
  cVar5 = (*_DAT_)(cVar1);
  if (cVar5 == cVar1) {
    if ((cVar5 + 0x5bU & 0xbd) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar2 = param_1[1];
    uVar3 = param_1[2];
    uVar4 = param_1[3];
    *param_2 = *param_1;
    param_2[1] = uVar2;
    param_2[2] = uVar3;
    param_2[3] = uVar4;
    uVar2 = param_1[5];
    uVar3 = param_1[6];
    uVar4 = param_1[7];
    param_2[4] = param_1[4];
    param_2[5] = uVar2;
    param_2[6] = uVar3;
    param_2[7] = uVar4;
  }
  if (cVar5 == '>') {
    func_0x(&uStack_28,0x3e);
    if ((~*(byte *)((longlong)param_1 + 1) & 1) == 0) {
      uStack_28 = uStack_28 | 0x100;
    }
    *param_2 = uStack_28;
    param_2[1] = uStack_24;
    param_2[2] = uStack_20;
    param_2[3] = uStack_1c;
    param_2[4] = uStack_18;
    param_2[5] = uStack_14;
    param_2[6] = uStack_10;
    param_2[7] = uStack_c;
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

