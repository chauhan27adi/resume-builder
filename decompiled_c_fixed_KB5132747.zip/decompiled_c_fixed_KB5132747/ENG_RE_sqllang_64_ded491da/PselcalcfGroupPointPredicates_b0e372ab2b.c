
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(undefined8 param_1,longlong param_2,undefined8 param_3,undefined param_4)

{
  longlong lVar1;
  undefined8 *puVar2;
  longlong lVar3;
  char cVar4;
  uint uVar5;
  int iVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  longlong lVar9;
  int *piVar10;
  longlong *plVar11;
  int iVar12;
  ulonglong uVar13;
  uint uVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  longlong unaff_GS_OFFSET;
  undefined8 extraout_XMM0_Qa;
  undefined8 uVar17;
  undefined4 uStackX_20;
  undefined8 uStack_e0;
  undefined2 uStack_d8;
  uint uStack_d4;
  longlong lStack_d0;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  longlong lStack_b8;
  undefined8 *puStack_b0;
  longlong *plStack_a8;
  longlong lStack_a0;
  longlong lStack_98;
  undefined8 uStack_90;
  longlong lStack_88;
  longlong lStack_68;
  uint uStack_60;
  undefined8 uStack_58;
  undefined8 *puStack_50;
  
  uStackX_20 = CONCAT31(uStackX_20._1_3_,param_4);
  uStack_58 = 0xfffffffffffffffe;
  uVar5 = *(uint *)(param_2 + 0xc);
  puVar7 = (undefined8 *)(*_DAT_)(0x20,param_1,0x202e120,0xa07,1);
  if (puVar7 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar7 = 0x1f42748;
  *(undefined4 *)(puVar7 + 1) = 1;
  *puVar7 = 0x1f5c658;
  puVar7[2] = param_1;
  uVar15 = 0;
  puVar7[3] = 0;
  uStack_d8 = (undefined2)uStackX_20;
  uStack_d4 = 0;
  lStack_d0 = 0;
  uStack_c8 = 0;
  uStack_c4 = 0;
  uStack_c0 = 0;
  uVar14 = uVar5;
  if (uVar5 < 5) {
    uVar14 = 5;
  }
  uStack_e0 = param_1;
  puStack_50 = puVar7;
  func_0x(&uStack_e0,uVar14,0);
  puVar8 = (undefined8 *)(*_DAT_)(0x20,param_1,0x202e120,0xa0e,1);
  if (puVar8 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar8 = param_1;
  *(undefined4 *)((longlong)puVar8 + 0xc) = 0;
  uVar14 = 1;
  if (uVar5 != 0) {
    uVar14 = uVar5;
  }
  *(uint *)(puVar8 + 2) = uVar14;
  puVar8[3] = 0;
  uVar13 = uVar15;
  uVar16 = uVar15;
  puStack_b0 = puVar8;
  if (uVar5 != 0) {
    do {
      uVar14 = (uint)uVar13;
      if (*(uint *)(param_2 + 0xc) <= uVar14) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      plStack_a8 = *(longlong **)(uVar16 + *(longlong *)(param_2 + 0x18));
      cVar4 = (**(code **)(*plStack_a8 + 0x60))(plStack_a8,&lStack_b8);
      if (cVar4 == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((lStack_b8 != 0) && (puVar7[3] != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      func_0x(puVar7,lStack_b8);
      lStack_68 = lStack_b8;
      uStack_60 = uVar14;
      func_0x(&uStack_e0,&lStack_68,0);
      uVar13 = (ulonglong)(uVar14 + 1);
      uVar16 = uVar16 + 8;
    } while (uVar14 + 1 < uVar5);
  }
  if (((puVar7[3] == 0) || (uVar5 = func_0x(), uVar5 < 2)) ||
     (lVar9 = func_0x(param_1,param_3,puVar7,5), lVar9 == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar1 = *(longlong *)(lVar9 + 0x10);
  if (((lVar1 != 0) && (puVar7[3] != 0)) && (*(longlong *)(lVar1 + 0x18) != 0)) {
    func_0x();
  }
  if ((char)uStackX_20 == '\0') {
    for (puVar2 = (undefined8 *)puVar7[3]; puVar2 != (undefined8 *)0x0;
        puVar2 = (undefined8 *)*puVar2) {
      piVar10 = (int *)((longlong)puVar2 + 0xc);
      uVar13 = uVar15;
      do {
        if (*piVar10 != 0) goto LAB_;
        uVar5 = (int)uVar13 + 1;
        uVar13 = (ulonglong)uVar5;
        piVar10 = piVar10 + 1;
      } while (uVar5 < 8);
    }
    if (*(int *)((longlong)puVar8 + 0xc) != 0) {
LAB_:
      if (lVar9 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (puVar8 != (undefined8 *)0x0) {
        func_0x(puVar8);
        if (puVar8[3] != 0) {
          (*_DAT_)();
          puVar8[3] = 0;
        }
        *(undefined4 *)(puVar8 + 2) = 0;
        (*_DAT_)(puVar8,0x20);
      }
      func_0x(&uStack_e0);
      puVar8 = puVar7 + 1;
      *(int *)puVar8 = *(int *)puVar8 + -1;
      if (*(int *)puVar8 == 0) {
        (**(code **)*puVar7)(puVar7,1);
      }
      return 0;
    }
  }
  if (lVar9 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong *)(lVar1 + 0x18) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar6 = func_0x();
  uStackX_20 = 0xa58;
  puVar7 = (undefined8 *)(*_DAT_)(0x20,param_1,0x202e120,0xa58,1);
  if (puVar7 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar7 = param_1;
  *(undefined4 *)((longlong)puVar7 + 0xc) = 0;
  iVar12 = 1;
  if (iVar6 != 0) {
    iVar12 = iVar6;
  }
  *(int *)(puVar7 + 2) = iVar12;
  puVar7[3] = 0;
  uVar17 = extraout_XMM0_Qa;
  if (*(longlong *)(lVar1 + 0x18) != 0) {
    uStack_90 = 0;
    lVar9 = *(longlong *)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
               + 8) + 0x48);
    plVar11 = (longlong *)(lVar9 + 0x2b0);
    if (lVar9 == 0) {
      plVar11 = (longlong *)0x2b8;
    }
    lStack_88 = *plVar11;
    lStack_98 = *(longlong *)(lVar1 + 0x18);
  }
  while( true ) {
    if ((*(longlong *)(lVar1 + 0x18) == 0) ||
       (cVar4 = func_0x(uVar17,&lStack_98,&uStackX_20), cVar4 == '\0')) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(uint *)(*(longlong *)(lStack_88 + 0x10) + 0xc) <= uStackX_20 >> 8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar9 = *(longlong *)
             (*(longlong *)
               (*(longlong *)(*(longlong *)(lStack_88 + 0x10) + 0x18) +
               (ulonglong)(uStackX_20 >> 8) * 8) + (ulonglong)(uStackX_20 & 0xff) * 8);
    uVar5 = ((int)(char)lVar9 +
             (((int)(char)((ulonglong)lVar9 >> 8) +
              (((int)(char)((ulonglong)lVar9 >> 0x10) +
               (((char)((ulonglong)lVar9 >> 0x20) * 0x20 + (int)(char)((ulonglong)lVar9 >> 0x18)) *
                0x10 + (int)(char)((ulonglong)lVar9 >> 0x38)) * 2) * 0x10 +
              (int)(char)((ulonglong)lVar9 >> 0x30)) * 2) * 0x10 +
             (char)((ulonglong)lVar9 >> 0x28) + 0xe3c4ebc) * 2 & 0x7fffffffU) * -0x3e39b195 + 0x3039
    ;
    lVar3 = *(longlong *)
             (lStack_d0 + (((ulonglong)uVar5 & 0xffffffff7fffffff) % (ulonglong)uStack_d4) * 8);
    if (lVar3 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (((uVar5 & 0x7fffffff) != *(uint *)(lVar3 + 0x18)) || (lVar9 != *(longlong *)(lVar3 + 8))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (lVar3 == -8) {
      return;
    }
    if (*(uint *)(param_2 + 0xc) <= (uint)*(ulonglong *)(lVar3 + 0x10)) break;
    lStack_a0 = *(longlong *)
                 (*(longlong *)(param_2 + 0x18) + (*(ulonglong *)(lVar3 + 0x10) & 0xffffffff) * 8);
    *(int *)(lStack_a0 + 8) = *(int *)(lStack_a0 + 8) + 1;
    uVar17 = func_0x(puVar7,&lStack_a0);
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

