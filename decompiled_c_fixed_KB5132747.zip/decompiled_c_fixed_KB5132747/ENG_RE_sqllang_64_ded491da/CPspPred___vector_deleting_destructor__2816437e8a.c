
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_(undefined8 *param_1,uint param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  uint uVar3;
  ulonglong uVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  
  uVar6 = 0xfffffffffffffffe;
  *param_1 = 0x2097668;
  uVar4 = 0;
  puVar5 = (undefined8 *)param_1[6];
  if (*(int *)((longlong)puVar5 + 0x1c) != 0) {
    do {
      puVar2 = *(undefined8 **)(puVar5[5] + uVar4 * 8);
      if (puVar2 != (undefined8 *)0x0) {
        puVar1 = puVar2 + 1;
        *(int *)puVar1 = *(int *)puVar1 + -1;
        if (*(int *)puVar1 == 0) {
          (**(code **)*puVar2)(puVar2,1,puVar5,param_4,uVar6);
        }
      }
      uVar3 = (int)uVar4 + 1;
      uVar4 = (ulonglong)uVar3;
      puVar5 = (undefined8 *)param_1[6];
    } while (uVar3 < *(uint *)((longlong)puVar5 + 0x1c));
  }
  if (puVar5 != (undefined8 *)0x0) {
    puVar2 = puVar5 + 1;
    *(int *)puVar2 = *(int *)puVar2 + -1;
    if (*(int *)puVar2 == 0) {
      (**(code **)*puVar5)(puVar5,1);
    }
  }
  *param_1 = 0x1fa9158;
  if ((param_2 & 1) != 0) {
    (*_DAT_)(param_1,0x38);
  }
  return param_1;
}

