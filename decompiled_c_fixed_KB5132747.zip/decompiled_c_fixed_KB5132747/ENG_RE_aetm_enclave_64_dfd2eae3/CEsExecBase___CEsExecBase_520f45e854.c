
void FUN_(undefined8 *param_1)

{
  longlong **pplVar1;
  undefined8 *puVar2;
  longlong lVar3;
  longlong lVar4;
  ulonglong uVar5;
  uint uVar6;
  longlong **pplVar7;
  ulonglong uVar8;
  
  uVar8 = 0;
  *param_1 = 0x136938;
  if (param_1[2] != 0) {
    lVar4 = param_1[7];
    if ((lVar4 != 0) && (uVar5 = uVar8, *(short *)(param_1[2] + 0x14) != 0)) {
      do {
        func_0x(*(undefined8 *)(param_1[7] + uVar5 * 8));
        uVar6 = (int)uVar5 + 1;
        uVar5 = (ulonglong)uVar6;
      } while (uVar6 < *(ushort *)(param_1[2] + 0x14));
      lVar4 = param_1[7];
    }
    func_0x(lVar4);
    pplVar1 = (longlong **)param_1[5];
    lVar4 = param_1[2];
    if (param_1[6] != 0) {
      func_0x();
    }
    if (pplVar1 != (longlong **)0x0) {
      if (*(uint *)(lVar4 + 0x30) != 0) {
        uVar5 = (ulonglong)*(uint *)(lVar4 + 0x30);
        pplVar7 = pplVar1;
        do {
          if (*pplVar7 != (longlong *)0x0) {
            (**(code **)(**pplVar7 + 0x70))();
          }
          pplVar7 = pplVar7 + 1;
          uVar5 = uVar5 - 1;
        } while (uVar5 != 0);
      }
      func_0x(pplVar1);
    }
    lVar4 = param_1[8];
    if (lVar4 != 0) {
      lVar3 = lVar4;
      uVar5 = uVar8;
      if (*(int *)(param_1[2] + 0x78) != 0) {
        do {
          puVar2 = *(undefined8 **)(lVar3 + uVar5 * 8);
          if (puVar2 != (undefined8 *)0x0) {
            (**(code **)*puVar2)(puVar2,1);
            lVar3 = param_1[8];
            lVar4 = lVar3;
          }
          uVar6 = (int)uVar5 + 1;
          uVar5 = (ulonglong)uVar6;
        } while (uVar6 < *(uint *)(param_1[2] + 0x78));
      }
      func_0x(lVar4);
    }
  }
  lVar4 = param_1[0xb];
  if (lVar4 != 0) {
    if (*(short *)(param_1 + 0xc) != 0) {
      do {
        lVar4 = param_1[0xb];
        lVar3 = *(longlong *)(lVar4 + uVar8 * 8);
        if (lVar3 != 0) {
          func_0x(lVar3);
          lVar4 = param_1[0xb];
        }
        uVar6 = (int)uVar8 + 1;
        uVar8 = (ulonglong)uVar6;
      } while (uVar6 < *(ushort *)(param_1 + 0xc));
    }
    func_0x(lVar4);
    param_1[0xb] = 0;
    *(undefined2 *)(param_1 + 0xc) = 0;
  }
  return;
}

