
void FUN_(longlong **param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = param_1[1];
  if (plVar1 != (longlong *)0x0) {
    plVar2 = (longlong *)plVar1[0x13];
    if (plVar2 != (longlong *)0x0) {
      (**(code **)(*plVar2 + 0x10))(plVar2,1,param_3,param_4,0xfffffffffffffffe);
    }
    plVar2 = (longlong *)plVar1[0x12];
    if (plVar2 != (longlong *)0x0) {
      (**(code **)(*plVar2 + 0x10))(plVar2,1);
    }
    (**(code **)(**param_1 + 0x28))(*param_1,plVar1);
  }
  return;
}

