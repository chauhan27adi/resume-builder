
undefined8
FUN_(undefined8 param_1,longlong param_2,longlong param_3,uint param_4,undefined4 *param_5,
            int param_6,int param_7,undefined *param_8,longlong *param_9)

{
  uint *puVar1;
  byte bVar2;
  byte bVar3;
  undefined4 uVar4;
  bool bVar5;
  uint3 uVar6;
  bool bVar7;
  bool bVar8;
  bool bVar9;
  byte bVar10;
  undefined2 uVar11;
  ushort uVar12;
  uint uVar13;
  int iVar14;
  ulonglong uVar15;
  int iVar16;
  longlong lVar17;
  int iVar18;
  ushort *puVar19;
  byte bVar20;
  ushort uVar21;
  ushort *puVar22;
  int iStackX_18;
  uint uStackX_20;
  undefined4 uStack_58;
  uint uStack_50;
  int iStack_4c;
  undefined4 uStack_44;
  
  bVar9 = false;
  bVar8 = false;
  iStack_4c = 0;
  iStackX_18 = 0;
  if (*(int *)(param_3 + 0x84) < *(int *)(param_3 + 0x88)) {
    return 0;
  }
  if (param_8 != (undefined *)0x0) {
    *param_8 = 0;
  }
  uStack_50 = 0;
  iVar18 = iStackX_18;
  uStackX_20 = param_4;
LAB_:
  iVar14 = *(int *)(param_3 + 0x5c);
  puVar22 = (ushort *)(param_3 + 0x3c);
  bVar7 = true;
  if (iVar14 < 4) {
    lVar17 = *(longlong *)(param_3 + 0x30);
    do {
      if (lVar17 == 0) {
        *(undefined2 *)(param_3 + 0x3c + (longlong)iVar14 * 2) = 0;
        iVar14 = *(int *)(param_3 + 0x5c);
        goto LAB_;
      }
      if (*(code **)(param_3 + 0x18) == (code *)0x0) {
        uVar11 = *(undefined2 *)
                  (*(longlong *)(param_3 + 0x28) + (longlong)*(int *)(param_3 + 0x38) * 2);
        *(int *)(param_3 + 0x38) = *(int *)(param_3 + 0x38) + 1;
      }
      else {
        uVar11 = (**(code **)(param_3 + 0x18))(*(undefined8 *)(param_3 + 0x20));
      }
      *(undefined2 *)(param_3 + 0x3c + (longlong)*(int *)(param_3 + 0x5c) * 2) = uVar11;
      *(longlong *)(param_3 + 0x30) = *(longlong *)(param_3 + 0x30) + -1;
      iVar14 = *(int *)(param_3 + 0x5c) + 1;
      lVar17 = *(longlong *)(param_3 + 0x30);
      *(int *)(param_3 + 0x5c) = iVar14;
    } while (iVar14 < 4);
  }
  else {
LAB_:
    if (iVar14 == 0) {
      iVar18 = *(int *)(param_3 + 0x88);
      if (bVar8) {
        *(undefined2 *)(*(longlong *)(param_3 + 0x68) + (longlong)iVar18 * 4) = 0xfffb;
        *(int *)(param_3 + 0x88) = *(int *)(param_3 + 0x88) + 1;
        return 0;
      }
      if (*(int *)(param_3 + 0x84) != iVar18) {
        return 0;
      }
      if (((*(uint *)(param_3 + 0x10) & 0x8000000) != 0) &&
         (*(uint *)(*(longlong *)(param_3 + 0x68) + (longlong)iVar18 * 4) =
               *(uint *)(*(longlong *)(param_2 + 8) + 0x80) & *(uint *)(param_3 + 0x14),
         param_7 != 0)) {
        *(undefined4 *)(*(longlong *)(param_3 + 0x70) + (longlong)*(int *)(param_3 + 0x88) * 4) = 0;
      }
      return 1;
    }
  }
  if (((*(int *)(param_3 + 4) != 0) && (*(short *)(param_3 + 0x3c) == *(short *)(param_3 + 0xc))) &&
     (iVar14 == 1)) {
    return 3;
  }
  if (*(int *)(param_3 + 0x80) <= *(int *)(param_3 + 0x88)) {
    return 2;
  }
  *(uint *)(*(longlong *)(param_3 + 0x68) + (longlong)*(int *)(param_3 + 0x88) * 4) =
       *(uint *)(*(longlong *)(param_2 + 8) + (ulonglong)*(ushort *)(param_3 + 0x3c) * 4) &
       *(uint *)(param_3 + 0x14);
  if (param_7 != 0) {
    *(undefined4 *)(*(longlong *)(param_3 + 0x70) + (longlong)*(int *)(param_3 + 0x88) * 4) = 0;
  }
  if (iVar18 != 0) goto LAB_;
  if (((*(int *)(param_3 + 4) == 0) || (*(short *)(param_3 + 0x3c) != *(short *)(param_3 + 0xc))) ||
     (*(int *)(param_3 + 0x5c) < 2)) {
    if (((param_6 != 0) && (bVar8)) ||
       ((*(int *)(param_2 + 0x14) == 0 ||
        ((iVar14 = *(int *)(param_3 + 0x5c), iVar14 < 2 ||
         ((*(byte *)(*(longlong *)(param_3 + 0x68) + 3 + (longlong)*(int *)(param_3 + 0x88) * 4) &
          0xc0) == 0)))))) goto LAB_;
    if ((*(int *)(param_2 + 0x18) != 0) &&
       (((bVar9 = false, 2 < iVar14 && (*(ushort *)(param_3 + 0x3e) != *(ushort *)(param_3 + 0xc)))
        && (((*(uint *)(*(longlong *)(param_2 + 8) + (ulonglong)*(ushort *)(param_3 + 0x3e) * 4) &
              *(uint *)(param_3 + 0x14) ^
             *(uint *)(*(longlong *)(param_3 + 0x68) + (longlong)*(int *)(param_3 + 0x88) * 4)) &
            0xe7ffffff) == 0)))) {
      bVar9 = true;
      puVar22 = (ushort *)(param_3 + 0x3e);
      iVar14 = iVar14 + -1;
    }
    uVar12 = puVar22[1];
    if (uVar12 != *(ushort *)(param_3 + 0xc)) {
      lVar17 = *(longlong *)(param_2 + 0x20);
      uVar13 = (uint)*(ushort *)(lVar17 + 4);
      if (*(ushort *)(lVar17 + 4) != 0) {
        do {
          if (*(ushort *)(lVar17 + 6) <= *puVar22) {
            if (((*(ushort *)(lVar17 + 6) == *puVar22) && (*(ushort *)(lVar17 + 0xc) <= uVar12)) &&
               (uVar12 <= *(ushort *)(lVar17 + 0xe))) {
              uVar13 = (uint)*(ushort *)(lVar17 + 10);
              puVar19 = (ushort *)
                        (*(longlong *)(param_2 + 0x28) + (ulonglong)*(ushort *)(lVar17 + 8) * 8);
              iVar18 = iStackX_18;
              if (*(ushort *)(lVar17 + 10) != 0) goto LAB_;
            }
            break;
          }
          lVar17 = lVar17 + 0x10;
          uVar13 = uVar13 - 1;
        } while (uVar13 != 0);
      }
    }
    goto LAB_;
  }
  func_0x(param_3 + 0x3c,param_3 + 0x3e,0x1e);
  *(int *)(param_3 + 0x5c) = *(int *)(param_3 + 0x5c) + -1;
  *(uint *)(*(longlong *)(param_3 + 0x68) + (longlong)*(int *)(param_3 + 0x88) * 4) =
       *(uint *)(*(longlong *)(param_2 + 8) + (ulonglong)*(ushort *)(param_3 + 0x3c) * 4) &
       *(uint *)(param_3 + 0x14);
  goto code_r0x001001e2;
  while( true ) {
    puVar19 = puVar19 + 4;
    uVar13 = uVar13 - 1;
    if (uVar13 == 0) break;
LAB_:
    uVar21 = *puVar19;
    if (uVar21 <= uVar12) goto LAB_;
  }
LAB_:
  if (bVar9) {
    puVar22 = puVar22 + -1;
  }
LAB_:
  if ((*(int *)(param_3 + 4) != 0) && (iVar18 == 0)) {
    iStack_4c = iStack_4c + 1;
    switch(*puVar22) {
    case 0x21:
      if ((bVar8) && (iStack_4c == 1)) {
        uVar13 = *(uint *)(param_3 + 0x10) & 0x10000000;
code_r0x0010046d:
        if (uVar13 != 0) {
          iStack_4c = 0;
          *(undefined2 *)(*(longlong *)(param_3 + 0x68) + (longlong)*(int *)(param_3 + 0x88) * 4) =
               0xfff9;
        }
      }
      break;
    case 0x23:
      if ((!bVar8) && ((*(uint *)(param_3 + 0x10) & 0x10000000) != 0)) {
        *(undefined2 *)(*(longlong *)(param_3 + 0x68) + (longlong)*(int *)(param_3 + 0x88) * 4) =
             0xfffd;
      }
      break;
    case 0x25:
      if (!bVar8) {
        uVar13 = *(uint *)(param_3 + 0x10) & 0x20000000;
code_r0x00100514:
        if (uVar13 != 0) {
          *(undefined2 *)(*(longlong *)(param_3 + 0x68) + (longlong)*(int *)(param_3 + 0x88) * 4) =
               0xfff7;
        }
      }
      break;
    case 0x2a:
      if (!bVar8) {
        uVar13 = *(uint *)(param_3 + 0x10) & 0x10000000;
        goto code_r0x00100514;
      }
      break;
    case 0x2d:
      if ((((bVar8) && (iStack_4c != 1)) && (1 < *(int *)(param_3 + 0x5c))) && (puVar22[1] != 0x5d))
      {
        bVar7 = false;
        *(undefined2 *)(*(longlong *)(param_3 + 0x68) + (longlong)*(int *)(param_3 + 0x88) * 4) =
             0xfffa;
      }
      break;
    case 0x3f:
      if (!bVar8) {
        uVar13 = *(uint *)(param_3 + 0x10) & 0x10000000;
code_r0x00100598:
        if (uVar13 != 0) {
          *(undefined2 *)(*(longlong *)(param_3 + 0x68) + (longlong)*(int *)(param_3 + 0x88) * 4) =
               0xfffe;
        }
      }
      break;
    case 0x5b:
      if (!bVar8) {
        bVar7 = false;
        bVar8 = true;
        iStack_4c = 0;
        uStackX_20 = 0;
        *(undefined2 *)(*(longlong *)(param_3 + 0x68) + (longlong)*(int *)(param_3 + 0x88) * 4) =
             0xfffc;
      }
      break;
    case 0x5d:
      if (bVar8) {
        bVar8 = false;
        *(undefined2 *)(*(longlong *)(param_3 + 0x68) + (longlong)*(int *)(param_3 + 0x88) * 4) =
             0xfffb;
      }
      break;
    case 0x5e:
      if ((bVar8) && (iStack_4c == 1)) {
        uVar13 = *(uint *)(param_3 + 0x10) & 0x20000000;
        goto code_r0x0010046d;
      }
      break;
    case 0x5f:
      if (!bVar8) {
        uVar13 = *(uint *)(param_3 + 0x10) & 0x20000000;
        goto code_r0x00100598;
      }
    }
  }
code_r0x001001e2:
  bVar5 = false;
  iVar14 = *(int *)(param_3 + 0x88);
  lVar17 = *(longlong *)(param_3 + 0x68);
  uVar12 = *(ushort *)(lVar17 + (longlong)iVar14 * 4);
  switch(uVar12 >> 8) {
  case 0:
    break;
  case 1:
    if (((*(uint *)(param_3 + 0x10) & 2) == 0) &&
       ((((*(uint *)(param_3 + 0x10) >> 0x1e & 1) == 0 ||
         (*(int *)(param_3 + 0x38) != *(int *)(param_3 + 0x5c))) || (iVar14 != 0))))
    goto code_r0x0010066a;
    break;
  case 2:
    *param_5 = 0;
    if ((param_6 == 0) || ((bVar5 = false, *(int *)(param_3 + 8) != 0 && (!bVar8)))) {
      func_0x(puVar22 + 1,puVar22,(longlong)*(int *)(param_3 + 0x5c) * 2);
      uVar15 = (ulonglong)
               *(byte *)(*(longlong *)(param_3 + 0x68) + (longlong)*(int *)(param_3 + 0x88) * 4);
      *puVar22 = *(ushort *)(uVar15 * 4 + 0x4154f0);
      puVar22[1] = *(ushort *)(uVar15 * 4 + 0x4154f2);
      *(undefined4 *)(param_3 + 0x60) = 1;
      iVar16 = *(int *)(param_3 + 0x5c) + 1;
      *(int *)(param_3 + 0x5c) = iVar16;
      uVar12 = puVar22[1];
      lVar17 = *(longlong *)(param_2 + 8);
      iVar14 = iVar18 + 3;
      if (*(char *)(lVar17 + 1 + (ulonglong)uVar12 * 4) == '\x02') {
        func_0x(puVar22 + 2,puVar22 + 1,(longlong)iVar16 * 2);
        uVar15 = (ulonglong)*(byte *)(lVar17 + (ulonglong)uVar12 * 4);
        puVar22[1] = *(ushort *)(uVar15 * 4 + 0x4154f0);
        puVar22[2] = *(ushort *)(uVar15 * 4 + 0x4154f2);
        *(int *)(param_3 + 0x5c) = *(int *)(param_3 + 0x5c) + 1;
        *(int *)(param_3 + 0x60) = *(int *)(param_3 + 0x60) + 1;
        iVar14 = iVar18 + 4;
      }
      iVar18 = iVar14;
      bVar5 = true;
      iStackX_18 = iVar18;
    }
    goto code_r0x0010066a;
  case 3:
    if ((param_8 != (undefined *)0x0) && ((byte)uVar12 < 2)) {
      *param_8 = 1;
      iVar14 = *(int *)(param_3 + 0x88);
      lVar17 = *(longlong *)(param_3 + 0x68);
    }
    if (1 < *(byte *)(lVar17 + (longlong)iVar14 * 4)) {
      *param_5 = *(undefined4 *)(*(longlong *)(param_2 + 8) + (ulonglong)*puVar22 * 4);
      iVar14 = *(int *)(param_3 + 0x88);
      lVar17 = *(longlong *)(param_3 + 0x68);
    }
    bVar2 = *(byte *)(lVar17 + (longlong)iVar14 * 4);
    puVar1 = (uint *)(lVar17 + (longlong)iVar14 * 4);
    bVar3 = *(byte *)((longlong)puVar1 + 3);
    uStack_58 = 0;
    if (bVar2 < 2) {
      if (uStackX_20 == 0) {
code_r0x001008d3:
        uVar13 = 0xffff;
      }
      else {
        uVar13 = uStackX_20 & *(uint *)(param_3 + 0x14);
        bVar20 = (byte)(uVar13 >> 8);
        if (bVar20 < 3) goto code_r0x001008d3;
        if (bVar20 == 3) {
          if ((byte)uVar13 < 2) goto code_r0x001008d3;
          uStack_44._3_1_ = (byte)(uVar13 >> 0x18);
          bVar20 = uStack_44._3_1_;
          uVar12 = *(short *)(param_2 + 0x40) << 8;
          uVar21 = uVar12 | (ushort)uVar13 & 0xff;
          bVar10 = uStack_44._3_1_ & 6;
          uStack_50 = (uint)uVar21;
          uStack_44 = CONCAT22((short)(uVar13 >> 0x10),uVar21);
          uStack_58._0_2_ = (ushort)bVar10;
          uVar6 = CONCAT12(bVar20,(ushort)uStack_58);
          uStack_58._0_3_ = uVar6 & 0x24ffff;
          if (bVar2 == 0) {
            uStack_58 = CONCAT13(bVar20,uVar6) & 0x524ffff;
            uStack_58._0_2_ = CONCAT11(4,(undefined)uStack_58);
            uVar13 = uStack_44;
          }
          else {
            uVar6 = (uint3)uStack_58 >> 0x10;
            uStack_58._0_2_ = CONCAT11(5,(undefined)uStack_58);
            uStack_50 = (uint)(uVar12 | (ushort)uVar13 & 0x87);
            uStack_58 = CONCAT13(bVar3,CONCAT12((char)uVar6,(ushort)uStack_58)) & 0x5ffffff;
            uVar13 = uStack_44;
          }
        }
        else {
          uStack_50 = uVar13 & 0xffff;
        }
      }
      uVar12 = (ushort)uStack_50;
      if (uVar13 != 0xffff) goto code_r0x00100927;
      uStack_58 = 0;
      *puVar1 = 0xffff;
      uStack_50 = 0xffff;
    }
    else {
      uStackX_20 = *puVar1;
      uVar12 = (ushort)bVar2 | *(short *)(param_2 + 0x40) << 8;
      uStack_50 = (uint)uVar12;
      uStack_58._0_2_ = CONCAT11(3,bVar3 & 6);
      uStack_58 = CONCAT13(bVar3,CONCAT12(bVar3,(ushort)uStack_58)) & 0x524ffff;
code_r0x00100927:
      *(ushort *)puVar1 = uVar12;
      *(undefined *)((longlong)puVar1 + 3) = 2;
    }
    if (param_7 != 0) {
      *(uint *)(*(longlong *)(param_3 + 0x70) + (longlong)*(int *)(param_3 + 0x88) * 4) = uStack_58;
    }
    goto code_r0x0010066a;
  default:
    *param_5 = *(undefined4 *)(*(longlong *)(param_2 + 8) + (ulonglong)*puVar22 * 4);
    goto code_r0x0010066a;
  case 6:
  case 7:
  case 8:
  case 9:
  case 10:
  case 0xb:
    *param_5 = *(undefined4 *)(*(longlong *)(param_2 + 8) + (ulonglong)*puVar22 * 4);
    if ((*(byte *)(param_3 + 0x10) & 4) == 0) goto code_r0x0010066a;
  }
  func_0x(param_3 + 0x3c,param_3 + 0x3e,0x1e);
  bVar5 = true;
  *(int *)(param_3 + 0x5c) = *(int *)(param_3 + 0x5c) + -1;
  if (param_9 != (longlong *)0x0) {
    *param_9 = *param_9 + 1;
  }
code_r0x0010066a:
  if (0 < iVar18) {
    iVar18 = iVar18 + -1;
    *param_5 = 0;
    iStackX_18 = iVar18;
  }
  if (!bVar5) {
    func_0x(param_3 + 0x3c,param_3 + 0x3e,0x1e);
    iVar18 = iStackX_18;
    if (iStackX_18 == 0) {
      iVar14 = *(int *)(param_3 + 0x5c) + -1;
      *(int *)(param_3 + 0x5c) = iVar14;
      if (bVar7) {
        do {
          if (iVar14 == 0) {
            if (*(longlong *)(param_3 + 0x30) == 0) break;
            if (*(code **)(param_3 + 0x18) == (code *)0x0) {
              uVar12 = *(ushort *)
                        (*(longlong *)(param_3 + 0x28) + (longlong)*(int *)(param_3 + 0x38) * 2);
              *(int *)(param_3 + 0x38) = *(int *)(param_3 + 0x38) + 1;
              iVar14 = 0;
            }
            else {
              uVar12 = (**(code **)(param_3 + 0x18))(*(undefined8 *)(param_3 + 0x20));
              iVar14 = *(int *)(param_3 + 0x5c);
            }
            puVar22[iVar14] = uVar12;
            *(int *)(param_3 + 0x5c) = *(int *)(param_3 + 0x5c) + 1;
            *(longlong *)(param_3 + 0x30) = *(longlong *)(param_3 + 0x30) + -1;
          }
          uVar12 = *(ushort *)
                    (*(longlong *)(param_3 + 0x68) + (longlong)*(int *)(param_3 + 0x88) * 4);
          lVar17 = *(longlong *)(param_3 + 0x68) + (longlong)*(int *)(param_3 + 0x88) * 4;
          if ((uVar12 != 0xfff7) || (*puVar22 != 0x25)) {
            uVar4 = *(undefined4 *)(*(longlong *)(param_2 + 8) + (ulonglong)*puVar22 * 4);
            if ((char)((uint)uVar4 >> 8) != '\x01') break;
            if (uVar12 < 0xfff7) {
              uVar12 = ((ushort)((uint)uVar4 >> 0x10) & 0xff) + (ushort)*(byte *)(lVar17 + 2);
              if (0xff < uVar12) {
                uVar12 = 0xff;
              }
              *(char *)(lVar17 + 2) = (char)uVar12;
            }
          }
          func_0x(param_3 + 0x3c,param_3 + 0x3e,0x1e);
          *(int *)(param_3 + 0x5c) = *(int *)(param_3 + 0x5c) + -1;
          iVar14 = *(int *)(param_3 + 0x5c);
        } while( true );
      }
      *(int *)(param_3 + 0x88) = *(int *)(param_3 + 0x88) + 1;
      if (!bVar8) {
        return 0;
      }
    }
    else {
      *(int *)(param_3 + 0x5c) = *(int *)(param_3 + 0x5c) + -1;
      *(int *)(param_3 + 0x88) = *(int *)(param_3 + 0x88) + 1;
    }
  }
  goto LAB_;
LAB_:
  if (uVar21 != uVar12) goto LAB_;
  if (puVar19[1] == 0) {
    if (!bVar9) {
      func_0x(param_3 + 0x3c,param_3 + 0x3e,0x1e);
      *(int *)(param_3 + 0x5c) = *(int *)(param_3 + 0x5c) + -1;
    }
LAB_:
    *(uint *)(*(longlong *)(param_3 + 0x68) + (longlong)*(int *)(param_3 + 0x88) * 4) =
         *(uint *)(puVar19 + 2) & *(uint *)(param_3 + 0x14);
    goto LAB_;
  }
  if (((2 < iVar14) && (puVar19[1] == puVar22[2])) && (*(ushort *)(param_3 + 0xc) != puVar22[2])) {
    if (!bVar9) {
      func_0x(param_3 + 0x3c,param_3 + 0x40,0x1c);
      *(int *)(param_3 + 0x5c) = *(int *)(param_3 + 0x5c) + -2;
    }
    goto LAB_;
  }
  puVar19 = puVar19 + 4;
  uVar13 = uVar13 - 1;
  if (uVar13 == 0) goto LAB_;
  uVar21 = *puVar19;
  goto LAB_;
}

