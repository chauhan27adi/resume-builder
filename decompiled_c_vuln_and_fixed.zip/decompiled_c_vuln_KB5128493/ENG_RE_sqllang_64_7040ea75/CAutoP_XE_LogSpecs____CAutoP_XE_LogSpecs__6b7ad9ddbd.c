
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar2 = *param_1;
  if (lVar2 != 0) {
    plVar1 = (longlong *)(lVar2 + 8);
    if (*plVar1 != 0) {
      (*_DAT_)();
    }
    *plVar1 = 0;
    (*_DAT_)(*plVar1);
    (*_DAT_)(lVar2,0x640,param_3,param_4,uVar3);
  }
  return;
}

