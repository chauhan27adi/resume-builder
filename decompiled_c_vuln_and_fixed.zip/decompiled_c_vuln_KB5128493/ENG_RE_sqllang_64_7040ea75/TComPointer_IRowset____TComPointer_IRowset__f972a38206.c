
void FUN_(longlong **param_1)

{
  if (*param_1 != (longlong *)0x0) {
    (**(code **)(**param_1 + 0x10))();
  }
  *param_1 = (longlong *)0x0;
  return;
}

