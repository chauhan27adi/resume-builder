
void FUN_(undefined8 *param_1)

{
  *param_1 = 0x6033e8;
  *param_1 = 0x6032e0;
  return;
}

