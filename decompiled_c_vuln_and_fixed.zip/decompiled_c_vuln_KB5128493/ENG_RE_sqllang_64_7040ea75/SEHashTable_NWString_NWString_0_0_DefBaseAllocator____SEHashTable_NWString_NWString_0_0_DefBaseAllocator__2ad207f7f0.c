
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  if (*param_1 != 0) {
    (*_DAT_)();
    *param_1 = 0;
    *(undefined4 *)(param_1 + 1) = 0;
  }
  return;
}

