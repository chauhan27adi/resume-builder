
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1)

{
  undefined8 *puVar1;
  int iVar2;
  
  puVar1 = (undefined8 *)*param_1;
  if ((puVar1 != (undefined8 *)0x0) && (*(int *)(param_1 + 1) != 0)) {
    if (*_DAT_ != '\0') {
      iVar2 = (*_DAT_)();
      if (iVar2 == (iVar2 / 5) * 5) {
        func_0x();
      }
    }
    *puVar1 = 0;
    *param_1 = 0;
    *(undefined4 *)(param_1 + 1) = 0;
  }
  return;
}

