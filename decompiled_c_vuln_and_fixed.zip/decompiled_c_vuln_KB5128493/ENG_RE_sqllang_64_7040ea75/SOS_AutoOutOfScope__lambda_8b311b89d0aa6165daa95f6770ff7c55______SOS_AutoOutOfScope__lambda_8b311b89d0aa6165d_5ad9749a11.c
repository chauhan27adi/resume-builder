
void FUN_(undefined8 *param_1)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar2 = **(longlong **)*param_1;
  while (lVar2 != 0) {
    lVar1 = *(longlong *)(lVar2 + 0xd0);
    *(undefined8 *)(lVar2 + 0xd0) = 0;
    func_0x();
    lVar2 = lVar1;
  }
  return;
}

