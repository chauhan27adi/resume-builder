
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  (*_DAT_)(*(undefined8 *)(param_1 + 0x40));
  (*_DAT_)(*(undefined8 *)(param_1 + 0x38));
  if (*(longlong *)(param_1 + 0x30) != 0) {
    (*_DAT_)();
  }
  if (*(longlong *)(param_1 + 0x28) != 0) {
                    /* WARNING: Could not recover jumptable at 0x0010004a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*_DAT_)();
    return;
  }
  return;
}

