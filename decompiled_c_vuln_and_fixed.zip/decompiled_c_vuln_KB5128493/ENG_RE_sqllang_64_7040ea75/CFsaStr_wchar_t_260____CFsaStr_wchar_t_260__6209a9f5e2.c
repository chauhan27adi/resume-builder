
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  if ((longlong *)*param_1 != param_1 + 3) {
    (*_DAT_)();
    *param_1 = (longlong)(param_1 + 3);
    param_1[2] = 0x104;
  }
  return;
}

