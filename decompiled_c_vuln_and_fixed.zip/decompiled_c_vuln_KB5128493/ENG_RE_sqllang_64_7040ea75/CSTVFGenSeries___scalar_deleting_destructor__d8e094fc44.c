
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 *
FUN_(undefined8 *param_1,ulonglong param_2,undefined8 param_3,undefined8 param_4)

{
  *param_1 = 0x17c6a98;
  *param_1 = 0x17bfd90;
  *param_1 = 0x1854610;
  if ((param_2 & 1) != 0) {
    (*_DAT_)(param_1,0x98,param_3,param_4,0xfffffffffffffffe);
  }
  return param_1;
}

