
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong lVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  lVar1 = *(longlong *)(param_1 + 0x28);
  if (lVar1 != 0) {
    *(undefined4 *)(lVar1 + 0xc) = 0;
    if (*(longlong *)(lVar1 + 0x18) != 0) {
      (*_DAT_)();
      *(undefined8 *)(lVar1 + 0x18) = 0;
    }
    *(undefined4 *)(lVar1 + 0x10) = 0;
    (*_DAT_)(lVar1,0x20,param_3,param_4,uVar2);
  }
  lVar1 = *(longlong *)(param_1 + 0x20);
  if (lVar1 != 0) {
    *(undefined4 *)(lVar1 + 0xc) = 0;
    if (*(longlong *)(lVar1 + 0x18) != 0) {
      (*_DAT_)();
      *(undefined8 *)(lVar1 + 0x18) = 0;
    }
    *(undefined4 *)(lVar1 + 0x10) = 0;
    (*_DAT_)(lVar1,0x20);
  }
  lVar1 = *(longlong *)(param_1 + 0x18);
  if (lVar1 != 0) {
    *(undefined4 *)(lVar1 + 0xc) = 0;
    if (*(longlong *)(lVar1 + 0x18) != 0) {
      (*_DAT_)();
      *(undefined8 *)(lVar1 + 0x18) = 0;
    }
    *(undefined4 *)(lVar1 + 0x10) = 0;
    (*_DAT_)(lVar1,0x20);
  }
  return;
}

