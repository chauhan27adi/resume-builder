
/* WARNING: Control flow encountered bad instruction data */

void FUN_(undefined8 *param_1)

{
  *param_1 = 0x1b67ce8;
  if (param_1[0x112] != 0) {
    func_0x();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

