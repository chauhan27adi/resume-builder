
/* WARNING: Control flow encountered bad instruction data */

ulonglong FUN_(undefined8 param_1,longlong param_2)

{
  longlong *plVar1;
  int iVar2;
  ulonglong uVar3;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  iVar2 = (**(code **)(*plVar1 + 0x18))(plVar1);
  if (iVar2 == 0xb) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar3 = (**(code **)(*plVar1 + 0x18))(plVar1);
  if ((int)uVar3 != 0x1f) {
    return uVar3 & 0xffffffffffffff00;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

