
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined4 *param_1)

{
  (*_DAT_)(0x10f3320);
  *param_1 = 0;
  (*_DAT_)(0x10f3320);
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

