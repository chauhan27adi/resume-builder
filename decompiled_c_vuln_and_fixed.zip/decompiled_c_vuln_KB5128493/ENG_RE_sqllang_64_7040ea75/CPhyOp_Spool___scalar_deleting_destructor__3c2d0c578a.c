
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 *
FUN_(undefined8 *param_1,ulonglong param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  uVar1 = 0xfffffffffffffffe;
  *param_1 = 0x1d28790;
  if (param_1[9] == 0) {
    func_0x(param_1);
    if ((param_2 & 1) != 0) {
      (*_DAT_)(param_1,0x78,param_3,param_4,uVar1);
    }
    return param_1;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

