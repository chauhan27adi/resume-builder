
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,ulonglong *param_2,longlong *param_3)

{
  longlong *plVar1;
  char cVar2;
  bool bVar3;
  ulonglong uVar4;
  undefined8 uVar5;
  uint uVar6;
  ulonglong uVar7;
  longlong lVar8;
  ulonglong uVar9;
  longlong unaff_GS_OFFSET;
  ushort auStack_48 [2];
  uint uStack_44;
  longlong lStack_40;
  ulonglong uStack_38;
  longlong lStack_30;
  int iStack_28;
  
  uVar9 = 0;
  uStack_44 = 4;
  auStack_48[0] = 0;
  lVar8 = (ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  uStack_38 = uVar9;
  if ((lVar8 == 0) || (*(longlong *)(lVar8 + 0x110) != lVar8)) {
    lStack_40 = 0;
  }
  else {
    lStack_40 = *(longlong *)(lVar8 + 0x100);
    if (lStack_40 != 0) {
      uStack_38 = *(ulonglong *)(lStack_40 + 0x3e0);
    }
  }
  lStack_30 = 0;
  iStack_28 = 0;
  if (((*_DAT_ & 1) != 0) && (uStack_38 != 0)) {
    uVar5 = (*_DAT_)();
    lStack_30 = (*_DAT_)(uVar5,*(undefined2 *)(uStack_38 + 0xa0));
  }
  bVar3 = false;
  cVar2 = *_DAT_;
  uVar7 = uVar9;
  if (lStack_30 != 0) {
    plVar1 = (longlong *)(*(longlong *)(lStack_30 + 0x20) + 8);
    *plVar1 = *plVar1 + 1;
  }
  do {
    uVar4 = uVar9;
    if (cVar2 == '\0') {
      uVar4 = uVar7;
    }
    for (; uVar4 < 10000; uVar4 = uVar4 + 1) {
      if (bVar3) {
        bVar3 = false;
      }
      else if ((uVar4 != 0) && (-1 < *param_3)) break;
    }
    if (lStack_30 != 0) {
      **(longlong **)(lStack_30 + 0x20) = **(longlong **)(lStack_30 + 0x20) + uVar4;
    }
    if (uVar4 < 10000) {
      LOCK();
      uVar7 = *param_2;
      *param_2 = *param_2 | 0x8000000000000000;
      UNLOCK();
      if (-1 < (longlong)uVar7) {
        return;
      }
      iStack_28 = 0;
      bVar3 = true;
      uVar7 = uVar4;
    }
    else {
      iStack_28 = iStack_28 + 1;
      if (lStack_30 != 0) {
        uVar6 = uStack_44 & 0xffff;
        if (uVar6 == 1) {
          uVar7 = *(ulonglong *)(lStack_30 + 8);
        }
        else if (uVar6 == 2) {
          uVar7 = *(ulonglong *)(lStack_30 + 0x10);
        }
        else if (uVar6 == 3) {
          uVar7 = *(ulonglong *)(lStack_30 + 0x18);
        }
        else {
          uVar7 = uVar9;
          if (uVar6 == 4) {
            uVar7 = *(ulonglong *)(lStack_30 + 0x20);
          }
        }
        plVar1 = (longlong *)((ulonglong)auStack_48[0] * 0x38 + 0x18 + uVar7);
        *plVar1 = *plVar1 + 1;
      }
      (*_DAT_)(param_1,auStack_48);
      uVar7 = uVar9;
    }
  } while( true );
}

