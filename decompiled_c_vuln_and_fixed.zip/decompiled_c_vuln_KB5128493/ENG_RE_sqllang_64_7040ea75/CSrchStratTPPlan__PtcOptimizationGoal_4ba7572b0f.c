
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_(undefined8 param_1,longlong param_2,longlong param_3,uint *param_4)

{
  longlong lVar1;
  undefined8 uVar2;
  char cVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  
  lVar1 = *(longlong *)(param_2 + 0x50);
  uVar2 = *(undefined8 *)(lVar1 + 0x20);
  if (1 < *param_4) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(lVar1 + 0x420) == 3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*param_4 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  plVar4 = *(longlong **)(lVar1 + 0x170);
  plVar4 = (longlong *)(**(code **)(*plVar4 + 0x18))(plVar4,uVar2,0,plVar4[2],0);
  if (*param_4 == 0) {
    *(undefined4 *)(plVar4 + 0xd) = 0;
    if ((*(byte *)(lVar1 + 0x6a) & 8) != 0) {
      cVar3 = func_0x(lVar1);
      if (cVar3 != '\0') {
        *(undefined4 *)((longlong)plVar4 + 0xbc) = 0;
        *(undefined4 *)(plVar4 + 0x1b) = 0;
        puVar5 = (undefined8 *)(*_DAT_)(0x48,uVar2,0x1ea7ad8,0x568,1);
        if (puVar5 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *puVar5 = 0x1de1fe0;
        *(undefined4 *)(puVar5 + 1) = 1;
        *puVar5 = 0x1ea7b08;
        puVar5[2] = lVar1;
        puVar5[3] = 0;
        puVar5[4] = 0;
        puVar5[5] = _DAT_;
        puVar5[6] = 0;
        *(undefined2 *)(puVar5 + 7) = 0;
        *(undefined4 *)((longlong)puVar5 + 0x3c) = 0;
        _DAT_ = _DAT_ + 1;
        puVar5[4] = 0;
        puVar5[3] = param_3;
        if (param_3 != 0) {
          *(int *)(param_3 + 8) = *(int *)(param_3 + 8) + 1;
        }
        if (*(longlong *)(lVar1 + 0x130) != 0) {
          *(undefined4 *)(puVar5 + 8) = *(undefined4 *)(*(longlong *)(lVar1 + 0x130) + 0xf4);
          *(undefined4 *)((longlong)puVar5 + 0x44) = 0;
          (**(code **)(*plVar4 + 0x10))(plVar4,uVar2);
          puVar5[4] = plVar4;
          return puVar5;
        }
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

