
/* WARNING: Control flow encountered bad instruction data */

void FUN_(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  *param_1 = 0xaeff98;
  puVar2 = (undefined8 *)param_1[8];
  if (puVar2 != (undefined8 *)0x0) {
    puVar1 = puVar2 + 1;
    *(int *)puVar1 = *(int *)puVar1 + -1;
    if (*(int *)puVar1 == 0) {
      (**(code **)*puVar2)(puVar2,1,param_3,param_4,0xfffffffffffffffe);
    }
  }
  puVar2 = (undefined8 *)param_1[9];
  if (puVar2 != (undefined8 *)0x0) {
    puVar1 = puVar2 + 1;
    *(int *)puVar1 = *(int *)puVar1 + -1;
    if (*(int *)puVar1 == 0) {
      (**(code **)*puVar2)(puVar2,1);
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

