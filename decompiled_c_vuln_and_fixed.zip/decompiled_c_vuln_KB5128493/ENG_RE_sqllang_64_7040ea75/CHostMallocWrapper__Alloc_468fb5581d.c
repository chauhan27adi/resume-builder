
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_(undefined8 param_1,undefined8 param_2,int param_3,undefined8 param_4)

{
  undefined4 uVar1;
  ulonglong uVar2;
  longlong lVar3;
  longlong lVar4;
  uint uVar5;
  longlong unaff_GS_OFFSET;
  undefined4 auStack_38 [2];
  undefined8 uStack_30;
  uint uStack_28;
  longlong lStack_20;
  
  uStack_30 = 0xfffffffffffffffe;
  uVar2 = func_0x();
  if (uVar2 < 0x30000) {
    uVar1 = 0x800703e9;
  }
  else {
    func_0x(auStack_38);
    uVar5 = 0;
    uStack_28 = 0;
    lVar3 = (ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar4 = *(longlong *)(lVar3 + 0x100);
    if (lVar4 == 0) {
      (*_DAT_)(0);
      lVar4 = *(longlong *)(lVar3 + 0x100);
    }
    if (param_3 != 0) {
      uVar5 = *(uint *)(lVar4 + 0x268) & 0x20 ^ 0x20;
      *(uint *)(lVar4 + 0x268) = *(uint *)(lVar4 + 0x268) | 0x20;
      uStack_28 = uVar5;
    }
    lStack_20 = lVar4;
    uVar1 = func_0x(param_1,param_2,param_3,0xb08fe8,0x143,param_4);
    *(uint *)(lVar4 + 0x268) = *(uint *)(lVar4 + 0x268) & ~uVar5;
    func_0x(auStack_38[0]);
  }
  return uVar1;
}

