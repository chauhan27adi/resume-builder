
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  undefined8 *puVar1;
  uint uVar2;
  ulonglong uVar3;
  
  uVar3 = 0;
  if (*(int *)(param_1 + 0xc) != 0) {
    do {
      puVar1 = *(undefined8 **)(*(longlong *)(param_1 + 0x18) + uVar3 * 8);
      if (puVar1 != (undefined8 *)0x0) {
        (*_DAT_)(*puVar1);
        (*_DAT_)(puVar1[2]);
        (*_DAT_)(puVar1,0xa0);
      }
      uVar2 = (int)uVar3 + 1;
      uVar3 = (ulonglong)uVar2;
    } while (uVar2 < *(uint *)(param_1 + 0xc));
  }
  *(undefined4 *)(param_1 + 0xc) = 0;
  if (*(longlong *)(param_1 + 0x18) != 0) {
    (*_DAT_)();
    *(undefined8 *)(param_1 + 0x18) = 0;
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  return;
}

