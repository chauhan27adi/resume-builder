
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(void)

{
                    /* WARNING: Could not recover jumptable at 0x00100016. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*_DAT_)();
  return;
}

