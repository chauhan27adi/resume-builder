
void FUN_(longlong *param_1)

{
  longlong lVar1;
  
  if (*(char *)(param_1 + 1) == '\0') {
    lVar1 = *param_1;
    *(undefined8 *)(lVar1 + 0x30) = 0;
    func_0x(lVar1,0);
    *(undefined *)(param_1 + 1) = 1;
  }
  return;
}

