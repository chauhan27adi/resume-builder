
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_(undefined8 *param_1,uint param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  *param_1 = 0xa9bdb0;
  puVar2 = (undefined8 *)param_1[7];
  puVar1 = puVar2 + 1;
  *(int *)puVar1 = *(int *)puVar1 + -1;
  if (*(int *)puVar1 == 0) {
    (**(code **)*puVar2)(puVar2,1,param_3,param_4,0xfffffffffffffffe);
  }
  if ((param_2 & 1) != 0) {
    (*_DAT_)(param_1,0x48);
  }
  return param_1;
}

