
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Possible PIC construction at 0x0010002a: Changing call to branch */
/* WARNING: Possible PIC construction at 0x00100044: Changing call to branch */
/* WARNING: Possible PIC construction at 0x00100058: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0010004a) */
/* WARNING: Removing unreachable block (ram,0x00100030) */
/* WARNING: Removing unreachable block (ram,0x0010005e) */

void FUN_(longlong param_1)

{
  func_0x(param_1 + 0xe0);
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

