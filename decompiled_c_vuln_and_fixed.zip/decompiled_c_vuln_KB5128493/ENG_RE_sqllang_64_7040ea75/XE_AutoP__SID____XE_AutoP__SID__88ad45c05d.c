
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  if (*param_1 != 0) {
    (*_DAT_)();
  }
  *param_1 = 0;
                    /* WARNING: Could not recover jumptable at 0x00100038. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*_DAT_)(*param_1,0xc);
  return;
}

