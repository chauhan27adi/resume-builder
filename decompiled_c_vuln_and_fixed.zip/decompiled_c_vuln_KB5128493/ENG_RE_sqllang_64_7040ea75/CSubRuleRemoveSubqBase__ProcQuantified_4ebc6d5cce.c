
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined8 param_2,longlong param_3,undefined4 param_4,
                 undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8)

{
  int *piVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 uVar9;
  undefined8 uVar10;
  undefined8 *puVar11;
  undefined8 *puVar12;
  undefined4 *puVar13;
  uint uVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  undefined8 *puStack_148;
  int iStack_140;
  undefined8 uStack_138;
  undefined4 uStack_130;
  undefined8 uStack_128;
  undefined uStack_120;
  uint uStack_11c;
  uint uStack_118;
  longlong lStack_110;
  longlong lStack_108;
  undefined8 uStack_100;
  longlong alStack_f8 [5];
  undefined8 auStack_d0 [17];
  longlong lStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0xfffffffffffffffe;
  lVar3 = (*(longlong **)(param_3 + 0x20))[1];
  lVar4 = *(longlong *)(lVar3 + 0x50);
  lVar5 = **(longlong **)(param_3 + 0x20);
  iStack_140 = (**(code **)(**(longlong **)(param_3 + 0x10) + 0x18))();
  puVar11 = *(undefined8 **)(*(longlong *)(param_3 + 0x10) + 0x40);
  uVar2 = *(undefined4 *)(*(longlong *)(param_3 + 0x10) + 0x48);
  if ((((_DAT_ == *(double *)(lVar4 + 0x18)) && (_DAT_ == *(double *)(lVar4 + 0x20))
       ) && (*(longlong *)(*(longlong *)(lVar4 + 0x58) + 0x18) != 0)) &&
     (iVar8 = func_0x(), iVar8 == 1)) {
    iStack_140 = 0x4f0;
    puVar12 = (undefined8 *)(*_DAT_)(0x50,param_1,0x1e87f48,0x4f0,1);
    if (puVar12 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    puStack_148 = puVar12;
    puVar13 = (undefined4 *)(**(code **)*puVar11)(puVar11);
    *puVar12 = 0x1dbeae0;
    *(undefined4 *)(puVar12 + 1) = 1;
    *puVar12 = 0x1d39ed0;
    puVar12[2] = param_1;
    *puVar12 = 0x1d32b50;
    uVar9 = puVar13[1];
    uVar6 = puVar13[2];
    uVar7 = puVar13[3];
    *(undefined4 *)(puVar12 + 3) = *puVar13;
    *(undefined4 *)((longlong)puVar12 + 0x1c) = uVar9;
    *(undefined4 *)(puVar12 + 4) = uVar6;
    *(undefined4 *)((longlong)puVar12 + 0x24) = uVar7;
    uVar9 = puVar13[5];
    uVar6 = puVar13[6];
    uVar7 = puVar13[7];
    *(undefined4 *)(puVar12 + 5) = puVar13[4];
    *(undefined4 *)((longlong)puVar12 + 0x2c) = uVar9;
    *(undefined4 *)(puVar12 + 6) = uVar6;
    *(undefined4 *)((longlong)puVar12 + 0x34) = uVar7;
    *(byte *)((longlong)puVar12 + 0x3e) = *(byte *)((longlong)puVar12 + 0x3e) & 0xfc;
    *(undefined2 *)((longlong)puVar12 + 0x3c) = 5;
    uVar9 = func_0x();
    *(undefined4 *)(puVar12 + 7) = uVar9;
    *puVar12 = 0x1cd0cc8;
    puVar12[8] = puVar11;
    *(undefined *)(puVar12 + 9) = 0;
    *(int *)(lVar3 + 8) = *(int *)(lVar3 + 8) + 1;
    iStack_140 = 0x4f2;
    puVar11 = (undefined8 *)(*_DAT_)(0xa8,param_1,0x1e87f48,0x4f2,1);
    if (puVar11 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *puVar11 = 0x1dbeae0;
    *(undefined4 *)(puVar11 + 1) = 1;
    *puVar11 = 0x1e83c50;
    puVar11[0xc] = 0;
    puVar11[0xd] = 0;
    puVar11[0xe] = 0;
    puVar11[0xf] = 0;
    puVar11[0x11] = _DAT_;
    puVar11[0x12] = 0;
    puVar11[0x13] = 0;
    puVar11[0x14] = 0;
    *(undefined4 *)(puVar11 + 3) = 1;
    puVar11[4] = puVar11 + 5;
    puVar11[5] = lVar3;
    puVar11[2] = puVar12;
    puVar11[10] = 0;
    puVar11[0xb] = 0;
    puVar11[0x10] = 0;
    iStack_140 = 0x4f4;
    puStack_148 = puVar11;
    puStack_148 = (undefined8 *)(*_DAT_)(0x48,param_1,0x1e87f48,0x4f4,1);
    if (puStack_148 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar10 = func_0x(puStack_148,param_1,uVar2);
    *(int *)(lVar5 + 8) = *(int *)(lVar5 + 8) + 1;
    puVar12 = (undefined8 *)(*_DAT_)(0xa8,param_1,0x1e87f48,0x4f6,1);
    if (puVar12 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *puVar12 = 0x1dbeae0;
    *(undefined4 *)(puVar12 + 1) = 1;
    *puVar12 = 0x1e83c50;
    puVar12[0xc] = 0;
    puVar12[0xd] = 0;
    puVar12[0xe] = 0;
    puVar12[0xf] = 0;
    puVar12[0x11] = _DAT_;
    puVar12[0x12] = 0;
    puVar12[0x13] = 0;
    puVar12[0x14] = 0;
    *(undefined4 *)(puVar12 + 3) = 2;
    puVar12[4] = puVar12 + 5;
    puVar12[5] = lVar5;
    *(undefined8 **)(puVar12[4] + 8) = puVar11;
    puVar12[2] = uVar10;
    puVar12[10] = 0;
    puVar12[0xb] = 0;
    puVar12[0x10] = 0;
    puStack_148 = puVar12;
    func_0x(puVar12,param_1,1,0);
    func_0x(param_1,param_2,puVar12,param_4,param_5,param_6,param_7,param_8);
    puVar11 = puVar12 + 1;
    *(int *)puVar11 = *(int *)puVar11 + -1;
    if (*(int *)puVar11 == 0) {
      (**(code **)*puVar12)(puVar12,1);
    }
  }
  else {
    func_0x(param_1,lVar3,1,&lStack_108,auStack_d0,puVar11,1);
    func_0x(param_1,param_2,lVar5,2,param_5,param_6,alStack_f8,&uStack_100);
    lVar3 = lStack_108;
    puStack_148 = &uStack_128;
    uStack_120 = 0;
    uVar16 = 0;
    uStack_11c = 0;
    uStack_118 = 4;
    lStack_110 = 0;
    uStack_130 = 1;
    uStack_138 = 0x1e83d18;
    uStack_128 = param_1;
    iVar8 = (**(code **)(**(longlong **)(lStack_108 + 0x10) + 0x18))();
    if (iVar8 == 0x20) {
      puVar11 = (undefined8 *)(*(longlong **)(lVar3 + 0x20))[1];
      lVar3 = **(longlong **)(lVar3 + 0x20);
      puStack_148 = puVar11;
      lStack_48 = lVar3;
      iVar8 = (**(code **)(*(longlong *)puVar11[2] + 0x18))((longlong *)puVar11[2]);
      if (iVar8 == 0x59) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      iVar8 = (**(code **)(*(longlong *)puVar11[2] + 0x18))((longlong *)puVar11[2]);
      if (iVar8 == 0x62) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      func_0x(&uStack_128,&puStack_148);
      uVar15 = uVar16;
      uVar17 = uVar16;
      if (uStack_11c != 0) {
        do {
          if (((uint)uVar15 < uStack_11c) && (*(longlong *)(lStack_110 + uVar17) != 0)) {
            piVar1 = (int *)(*(longlong *)(lStack_110 + uVar17) + 8);
            *piVar1 = *piVar1 + 1;
          }
          uVar14 = (uint)uVar15 + 1;
          uVar15 = (ulonglong)uVar14;
          uVar17 = uVar17 + 8;
        } while (uVar14 < uStack_11c);
      }
      *(int *)(lVar3 + 8) = *(int *)(lVar3 + 8) + 1;
      piVar1 = (int *)(lStack_108 + 8);
      *piVar1 = *piVar1 + -1;
      lStack_108 = lVar3;
      if (*piVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    if (iStack_140 == 0x7e) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    iStack_140 = 0x57f;
    puStack_148 = (undefined8 *)(*_DAT_)(0x48,param_1,0x1e87f48,0x57f,1);
    if (puStack_148 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar10 = func_0x(puStack_148,param_1,uVar2);
    puStack_148 = (undefined8 *)(*_DAT_)(0xa8,param_1,0x1e87f48,0x580,1);
    if (puStack_148 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *puStack_148 = 0x1dbeae0;
    *(undefined4 *)(puStack_148 + 1) = 1;
    *puStack_148 = 0x1e83c50;
    puStack_148[0xc] = 0;
    puStack_148[0xd] = 0;
    puStack_148[0xe] = 0;
    puStack_148[0xf] = 0;
    puStack_148[0x11] = _DAT_;
    puStack_148[0x12] = 0;
    puStack_148[0x13] = 0;
    puStack_148[0x14] = 0;
    *(undefined4 *)(puStack_148 + 3) = 2;
    puStack_148[4] = puStack_148 + 5;
    puStack_148[5] = uStack_100;
    *(undefined8 *)(puStack_148[4] + 8) = auStack_d0[0];
    puStack_148[2] = uVar10;
    puStack_148[10] = 0;
    puStack_148[0xb] = 0;
    puStack_148[0x10] = 0;
    if (lStack_110 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (uStack_118 <= uStack_11c) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined8 **)(lStack_110 + (ulonglong)uStack_11c * 8) = puStack_148;
    uStack_11c = uStack_11c + 1;
    uVar10 = func_0x(1,param_1,&uStack_138);
    puVar11 = (undefined8 *)(*_DAT_)(0x28,param_1,0x1e87f48,0x590,1);
    if (puVar11 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *puVar11 = 0x1dbeae0;
    *(undefined4 *)(puVar11 + 1) = 1;
    *puVar11 = 0x1d39ed0;
    puVar11[2] = param_1;
    *puVar11 = 0x1d0f9f8;
    *puVar11 = 0x1d10620;
    puVar11[3] = 0;
    *(undefined *)(puVar11 + 4) = 1;
    puStack_148 = puVar11;
    puVar12 = (undefined8 *)(*_DAT_)(0xa8,param_1,0x1e87f48,0x591,1);
    if (puVar12 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *puVar12 = 0x1dbeae0;
    *(undefined4 *)(puVar12 + 1) = 1;
    *puVar12 = 0x1e83c50;
    puVar12[0xc] = 0;
    puVar12[0xd] = 0;
    puVar12[0xe] = 0;
    puVar12[0xf] = 0;
    puVar12[0x11] = _DAT_;
    puVar12[0x12] = 0;
    puVar12[0x13] = 0;
    puVar12[0x14] = 0;
    *(undefined4 *)(puVar12 + 3) = 2;
    puVar12[4] = puVar12 + 5;
    puVar12[5] = lStack_108;
    *(undefined8 *)(puVar12[4] + 8) = uVar10;
    puVar12[2] = puVar11;
    puVar12[10] = 0;
    puVar12[0xb] = 0;
    puVar12[0x10] = 0;
    puStack_148 = puVar12;
    puStack_148 = (undefined8 *)(*_DAT_)(0x40,param_1,0x1e87f48,0x593,1);
    if (puStack_148 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar10 = func_0x(puStack_148,param_1);
    puVar11 = (undefined8 *)(*_DAT_)(0xa8,param_1,0x1e87f48,0x594,1);
    if (puVar11 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *puVar11 = 0x1dbeae0;
    *(undefined4 *)(puVar11 + 1) = 1;
    *puVar11 = 0x1e83c50;
    puVar11[0xc] = 0;
    puVar11[0xd] = 0;
    puVar11[0xe] = 0;
    puVar11[0xf] = 0;
    puVar11[0x11] = _DAT_;
    puVar11[0x12] = 0;
    puVar11[0x13] = 0;
    puVar11[0x14] = 0;
    *(undefined4 *)(puVar11 + 3) = 1;
    puVar11[4] = puVar11 + 5;
    puVar11[5] = puVar12;
    puVar11[2] = uVar10;
    puVar11[10] = 0;
    puVar11[0xb] = 0;
    puVar11[0x10] = 0;
    uVar15 = uVar16;
    if (uStack_11c != 0) {
      do {
        if (((uint)uVar16 < uStack_11c) && (*(longlong *)(uVar15 + lStack_110) != 0)) {
          piVar1 = (int *)(*(longlong *)(uVar15 + lStack_110) + 8);
          *piVar1 = *piVar1 + -1;
          if (*piVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
        }
        uVar14 = (uint)uVar16 + 1;
        uVar16 = (ulonglong)uVar14;
        uVar15 = uVar15 + 8;
      } while (uVar14 < uStack_11c);
    }
    puStack_148 = puVar11;
    func_0x(param_1,alStack_f8[0],puVar11,param_4,param_5,param_6,param_7,param_8);
    piVar1 = (int *)(alStack_f8[0] + 8);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    puVar12 = puVar11 + 1;
    *(int *)puVar12 = *(int *)puVar12 + -1;
    if (*(int *)puVar12 == 0) {
      (**(code **)*puVar11)(puVar11,1);
    }
    uStack_138 = 0x1dbeae0;
    func_0x(&uStack_128);
    if (lStack_110 != 0) {
      (*_DAT_)();
    }
  }
  return;
}

