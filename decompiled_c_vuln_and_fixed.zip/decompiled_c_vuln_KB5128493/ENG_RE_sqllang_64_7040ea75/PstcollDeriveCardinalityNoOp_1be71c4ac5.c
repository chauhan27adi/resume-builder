
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1)

{
  longlong lVar1;
  
  if (*(longlong *)(param_1 + 8) != 0) {
    lVar1 = (**(code **)(**(longlong **)
                           (*(longlong *)(**(longlong **)(*(longlong *)(param_1 + 8) + 0x20) + 0x50)
                           + 0x108) + 0xa8))();
    *(int *)(lVar1 + 8) = *(int *)(lVar1 + 8) + 1;
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

