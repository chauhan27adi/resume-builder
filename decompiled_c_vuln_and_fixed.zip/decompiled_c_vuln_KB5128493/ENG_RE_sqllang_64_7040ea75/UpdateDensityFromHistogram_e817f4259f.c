// NOTE: 6 cold fragment(s) of this function could not be laid out for the decompiler; branches into them appear unresolved.

/* WARNING: Control flow encountered bad instruction data */

void FUN_(void)

{
  longlong in_R9;
  
  if (in_R9 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

