
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong lVar3;
  uint uVar4;
  ulonglong uVar5;
  
  uVar5 = 0;
  if (*(int *)(param_1 + 0xc) != 0) {
    do {
      puVar1 = (undefined8 *)(*(longlong *)(param_1 + 0x10) + uVar5 * 8);
      puVar2 = *(undefined8 **)(*(longlong *)(param_1 + 0x10) + uVar5 * 8);
      while (puVar2 != (undefined8 *)0x0) {
        *puVar1 = *puVar2;
        lVar3 = puVar2[2];
        if (lVar3 != 0) {
          func_0x(lVar3);
          (*_DAT_)(lVar3,400);
        }
        (*_DAT_)(puVar2);
        puVar2 = (undefined8 *)*puVar1;
      }
      uVar4 = (int)uVar5 + 1;
      uVar5 = (ulonglong)uVar4;
    } while (uVar4 < *(uint *)(param_1 + 0xc));
  }
  if (*(longlong *)(param_1 + 0x10) != 0) {
                    /* WARNING: Could not recover jumptable at 0x001000a5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*_DAT_)();
    return;
  }
  return;
}

