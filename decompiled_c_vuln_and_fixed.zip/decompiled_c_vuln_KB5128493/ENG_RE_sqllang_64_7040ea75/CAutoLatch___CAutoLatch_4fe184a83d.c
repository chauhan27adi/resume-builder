
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1)

{
  if (*(int *)(param_1 + 1) != 0) {
    (*_DAT_)(*param_1,*(undefined4 *)((longlong)param_1 + 0xc));
    *(undefined4 *)(param_1 + 1) = 0;
  }
  return;
}

