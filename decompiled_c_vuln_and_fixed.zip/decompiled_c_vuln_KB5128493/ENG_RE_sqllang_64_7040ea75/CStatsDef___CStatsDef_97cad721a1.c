
void FUN_(undefined8 *param_1)

{
  *param_1 = 0x1a98368;
  if (param_1[0xb] != 0) {
    func_0x(param_1[0xb],1);
    param_1[0xb] = 0;
  }
  return;
}

