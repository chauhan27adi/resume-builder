
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2)

{
  longlong lVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong unaff_GS_OFFSET;
  undefined2 auStackX_10 [4];
  
  lVar1 = **(longlong **)(param_2 + 0x40);
  if (((~(byte)(*(uint *)(param_1 + 0x48) >> 10) & 1) == 0) ||
     ((*(uint *)(param_1 + 0x48) >> 8 & 1) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar2 = param_1[0xa8];
  if (lVar2 == 0) {
    if ((*(byte *)(*(longlong *)
                    (*(longlong *)
                      ((ulonglong)*_DAT_ +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
                    0x48) + 0x10e) & 4) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    auStackX_10[0] = 0;
    lVar2 = func_0x(_DAT_ +
                            (longlong)(int)(*(uint *)((longlong)param_1 + 0x53c) % _DAT_) *
                            0x28,param_1,*(uint *)((longlong)param_1 + 0x53c),auStackX_10);
    param_1[0xa8] = lVar2;
  }
  if ((lVar2 != 0) && ((*(uint *)(lVar1 + 0x30) & 0x1ff) == 0)) {
    if (param_1[0x47] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    plVar3 = (longlong *)func_0x(param_2,param_1 + 0xf,param_1,0);
    if (plVar3 != (longlong *)0x0) {
      if ((*(byte *)((longlong)param_1 + 0x246) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (param_1[2] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      func_0x(param_1,plVar3);
      (**(code **)(*plVar3 + 0x50))(plVar3,2);
      param_1[0x4c] = (longlong)plVar3;
      func_0x(plVar3,param_1,param_2,1);
      LOCK();
      *(int *)(plVar3 + 1) = *(int *)(plVar3 + 1) + 1;
      UNLOCK();
      if (*_DAT_ != '\0') {
        if (*(int *)(plVar3[3] + 0x88) == 8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        func_0x(1);
      }
      *(byte *)((longlong)param_1 + 0x1bd) = *(byte *)((longlong)param_1 + 0x1bd) & 0xef;
      if (*(int *)(plVar3[3] + 0x88) != 8) {
        if (((*(uint *)(param_1 + 3) >> 2 & 1) != 0) && ((*(uint *)(param_1 + 3) >> 3 & 1) == 0)) {
          (**(code **)(*param_1 + 0xa0))(param_1);
        }
        return;
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

