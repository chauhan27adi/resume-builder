
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  ulonglong uVar1;
  uint uVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  uVar1 = 0;
  if (*(int *)(param_1 + 0xc) != 0) {
    do {
      (*_DAT_)(*(undefined8 *)(*(longlong *)(param_1 + 0x18) + uVar1 * 8),0xc0,param_3,
                       param_4,uVar3);
      uVar2 = (int)uVar1 + 1;
      uVar1 = (ulonglong)uVar2;
    } while (uVar2 < *(uint *)(param_1 + 0xc));
  }
  *(undefined4 *)(param_1 + 0xc) = 0;
  if (*(longlong *)(param_1 + 0x18) != 0) {
    (*_DAT_)();
    *(undefined8 *)(param_1 + 0x18) = 0;
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  return;
}

