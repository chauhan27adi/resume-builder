
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  ulonglong uVar4;
  uint uVar5;
  
  *param_1 = 0x1e9a5f8;
  uVar4 = 0;
  if (param_1[0xe] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  plVar1 = (longlong *)param_1[2];
  if (plVar1 != (longlong *)0x0) {
    (**(code **)(*plVar1 + 0x88))(plVar1,1);
    param_1[2] = 0;
  }
  if (param_1[5] != 0) {
    (*_DAT_)();
    param_1[5] = 0;
  }
  if (param_1[8] != 0) {
    (*_DAT_)();
    param_1[8] = 0;
  }
  lVar3 = param_1[7];
  if (lVar3 != 0) {
    if (*(int *)(param_1[9] + 0xc) != 0) {
      do {
        lVar3 = param_1[7];
        lVar2 = *(longlong *)(uVar4 * 8 + lVar3);
        if (lVar2 != 0) {
          (*_DAT_)(lVar2);
          *(undefined8 *)(uVar4 * 8 + param_1[7]) = 0;
          lVar3 = param_1[7];
        }
        uVar5 = (int)uVar4 + 1;
        uVar4 = (ulonglong)uVar5;
      } while (uVar5 < *(uint *)(param_1[9] + 0xc));
    }
    (*_DAT_)(lVar3);
    param_1[7] = 0;
  }
  if (param_1[9] != 0) {
    func_0x(param_1[9],1);
    param_1[9] = 0;
  }
  return;
}

