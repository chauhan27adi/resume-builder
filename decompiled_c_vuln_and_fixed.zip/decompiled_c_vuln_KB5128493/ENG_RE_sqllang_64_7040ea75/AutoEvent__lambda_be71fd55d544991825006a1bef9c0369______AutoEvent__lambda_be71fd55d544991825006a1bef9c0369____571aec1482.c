
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  longlong lVar1;
  ulonglong *puVar2;
  uint *puVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  longlong unaff_GS_OFFSET;
  ulonglong uStackX_8;
  undefined auStack_288 [8];
  undefined4 uStack_280;
  undefined4 uStack_278;
  uint **ppuStack_270;
  undefined *puStack_268;
  undefined8 uStack_260;
  uint *puStack_258;
  undefined8 uStack_250;
  undefined auStack_248 [528];
  undefined8 uStack_38;
  undefined8 uStack_30;
  uint uStack_28;
  undefined uStack_24;
  ulonglong uStack_23;
  uint uStack_1b;
  uint uStack_17;
  
  lVar1 = *param_1;
  if ((_DAT_ & 0x200000) != 0) {
    uVar5 = 0;
    ppuStack_270 = &puStack_258;
    puStack_268 = auStack_248;
    puStack_258 = &uStack_28;
    uStack_280 = 0x10000;
    uStack_278 = 0;
    uStack_38 = 0;
    uStack_260 = 0;
    uStack_30 = 0;
    uStack_250 = 0x15;
    puVar2 = *(ulonglong **)(lVar1 + 0x10);
    uStack_28 = (uint)*(ushort *)
                       (*(longlong *)
                         (*(longlong *)
                           ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
                         + 0x50) + 8);
    uStack_24 = **(int **)(lVar1 + 8) == 0;
    uVar4 = _DAT_;
    if (*_DAT_ != 0) {
      (*_DAT_)(&uStackX_8);
      uVar4 = uStackX_8;
    }
    if ((uVar4 < *puVar2) || (uVar5 = uVar4 - *puVar2, uVar5 != 0xffffffffffffffff)) {
      if (*_DAT_ == 0) {
        uStack_23 = uVar5 / 10000;
      }
      else {
        uStack_23 = (uVar5 * 1000) / *_DAT_;
      }
    }
    else {
      uStack_23 = 0xffffffffffffffff;
    }
    puVar3 = *(uint **)(lVar1 + 8);
    uStack_1b = *puVar3;
    if (puVar3[4] != 1) {
      uStack_1b = *puVar3 & 0xffff;
    }
    uStack_17 = puVar3[3];
    func_0x(auStack_288);
  }
  return;
}

