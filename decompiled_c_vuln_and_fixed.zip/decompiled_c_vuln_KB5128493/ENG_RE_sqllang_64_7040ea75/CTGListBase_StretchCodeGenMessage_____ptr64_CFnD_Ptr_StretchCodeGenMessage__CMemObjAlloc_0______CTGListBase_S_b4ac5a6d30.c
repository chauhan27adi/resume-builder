
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong **pplVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  plVar3 = *param_1;
  while (plVar3 != (longlong *)0x0) {
    pplVar1 = (longlong **)*param_1;
    if (pplVar1 != (longlong **)0x0) {
      if (*pplVar1 != (longlong *)0x0) {
        *(longlong **)((longlong)*pplVar1 + 8) = pplVar1[1];
      }
      if (pplVar1[1] != (longlong *)0x0) {
        *pplVar1[1] = (longlong)*pplVar1;
      }
      if ((longlong **)*param_1 == pplVar1) {
        *param_1 = pplVar1[1];
      }
      if ((longlong **)param_1[1] == pplVar1) {
        param_1[1] = *pplVar1;
      }
      *pplVar1 = (longlong *)0x0;
      pplVar1[1] = (longlong *)0x0;
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + -1;
    }
    plVar3 = pplVar1[2];
    if (plVar3 != (longlong *)0x0) {
      if (plVar3[3] != 0) {
        (*_DAT_)();
      }
      (*_DAT_)(plVar3,0x20,param_3,param_4,uVar4);
    }
    (*_DAT_)(pplVar1);
    plVar3 = *param_1;
  }
  plVar3 = *param_1;
  while (plVar3 != (longlong *)0x0) {
    plVar2 = (longlong *)plVar3[1];
    (*_DAT_)(plVar3);
    plVar3 = plVar2;
  }
  return;
}

