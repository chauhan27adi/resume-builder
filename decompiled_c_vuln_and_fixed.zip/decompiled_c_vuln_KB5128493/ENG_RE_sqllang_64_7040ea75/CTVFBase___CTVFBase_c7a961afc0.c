
void FUN_(undefined8 *param_1)

{
  *param_1 = 0x1c867b0;
  *param_1 = 0x1d1b030;
  return;
}

