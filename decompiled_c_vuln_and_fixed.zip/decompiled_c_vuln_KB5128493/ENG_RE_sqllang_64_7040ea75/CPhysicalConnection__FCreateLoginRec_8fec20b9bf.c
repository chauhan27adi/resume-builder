
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x000a58e7) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,longlong *param_3,uint param_4,
                 undefined8 param_5,undefined *param_6,char param_7)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  uint uVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  char cVar6;
  int iVar7;
  longlong lVar8;
  byte *pbVar9;
  ulonglong uVar10;
  undefined *puVar11;
  undefined auStack_268 [32];
  undefined8 uStack_248;
  undefined8 uStack_240;
  undefined4 uStack_238;
  undefined8 uStack_230;
  undefined4 uStack_228;
  undefined4 uStack_220;
  undefined *puStack_218;
  char cStack_208;
  longlong lStack_200;
  undefined auStack_1f8 [2];
  undefined uStack_1f6;
  undefined4 uStack_1f4;
  uint uStack_1f0;
  longlong lStack_1e8;
  undefined4 uStack_1d8;
  undefined *puStack_1d0;
  longlong lStack_1c8;
  undefined8 uStack_1a8;
  undefined auStack_198 [128];
  undefined4 uStack_118;
  ulonglong uStack_58;
  
  uStack_1a8 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)auStack_268;
  puStack_1d0 = param_6;
  uVar2 = *(undefined4 *)(*param_3 + 4);
  lStack_200 = 0;
  *param_6 = 1;
  lStack_1c8 = 0;
  uStack_1f6 = 0;
  lStack_1e8 = 0;
  uStack_1f4 = 0;
  if ((DAT_ != '\0') || (cStack_208 = '\0', (*(byte *)(_DAT_ + 0x5a3) & 8) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_1f0 = param_4;
  uStack_1d8 = uVar2;
  if (((*(int *)(param_1 + 0x3dc) == 0xff) || (DAT_ == '\0')) &&
     (*(int *)(param_1 + 0x3dc) == 0xff)) {
    lVar8 = *param_3;
    if (*(short *)(lVar8 + 0x2a) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    pbVar9 = (byte *)((ulonglong)*(ushort *)(lVar8 + 0x2c) + lVar8);
    uVar3 = (uint)*(ushort *)(lVar8 + 0x2e) * 2;
    if (*(ushort *)(lVar8 + 0x2e) != 0) {
      uVar10 = (ulonglong)uVar3;
      do {
        *pbVar9 = (*pbVar9 ^ 0xaf) >> 4 | (*pbVar9 ^ 5) << 4;
        pbVar9 = pbVar9 + 1;
        uVar10 = uVar10 - 1;
      } while (uVar10 != 0);
      lVar8 = *param_3;
    }
    puVar11 = (undefined *)((ulonglong)*(ushort *)(lVar8 + 0x2c) + lVar8);
    auStack_1f8[0] = 0;
    plVar4 = *(longlong **)(*(longlong *)(param_2 + 0x170) + 0x18);
    cVar6 = (**(code **)(*plVar4 + 0x48))(plVar4,puVar11,uVar3,auStack_1f8);
    for (uVar10 = (ulonglong)uVar3; uVar10 != 0; uVar10 = uVar10 - 1) {
      *puVar11 = 0;
      puVar11 = puVar11 + 1;
    }
    if (cVar6 == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined2 *)(*param_3 + 0x2e) = 0;
    if (param_7 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar8 = *param_3;
    if ((*(uint *)(lVar8 + 0x18) & 0x1000000) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(short *)(lVar8 + 0x58) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (0xfffe < *(ushort *)(lVar8 + 0x50)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(lVar8 + 0x5a) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((4 < *(ushort *)(param_1 + 0x3c0)) && (*(short *)(lVar8 + 0x3e) == 0x1c)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(ushort *)(lVar8 + 0x50) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (cStack_208 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(uint *)(param_1 + 0x3c4) & 0x8000) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(uint *)(param_1 + 0x3c4) & 0x10000000) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar8 = *param_3;
    if (*(ushort *)(lVar8 + 0x3a) < 4) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar3 = *(uint *)((ulonglong)*(ushort *)(lVar8 + 0x38) + lVar8);
    if (uVar3 != 0) {
      if ((uStack_1f0 <= uVar3) || (uVar3 < 0x5e)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uStack_238 = CONCAT31(uStack_238._1_3_,0xff);
      uStack_240 = CONCAT44(uStack_240._4_4_,uStack_1f4);
      uStack_248 = lStack_1e8;
      cVar6 = func_0x(param_1,(ulonglong)uVar3 + *param_3,uStack_1f0 - uVar3);
      if (cVar6 == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    if ((*(byte *)(param_1 + 0x31) & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (lStack_1e8 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    cVar6 = (**(code **)(**(longlong **)(param_1 + 0x18) + 0x58))
                      (*(longlong **)(param_1 + 0x18),*param_3,uStack_1f0,
                       *(undefined2 *)(param_1 + 0x3c0));
    if (cVar6 == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *param_3 = 0;
    iVar7 = func_0x(param_2);
    lVar8 = lStack_200;
    if (iVar7 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((_DAT_ != 0) || (_DAT_ != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(uint *)(param_1 + 0x3c4) & 0x1008000) == 0x1008000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(uint *)(param_1 + 0x3c4) >> 0xf & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    cVar6 = (**(code **)(**(longlong **)(*(longlong *)(param_2 + 0x170) + 0x18) + 0x30))();
    if (((cVar6 == '\0') && (*(int *)(param_2 + 0x1dc) == 0)) &&
       ((*(byte *)(param_2 + 0x200) & 2) == 0)) {
      *(byte *)(*(longlong *)(param_2 + 0xa0) + 0x4c) =
           1 < *(ushort *)(param_1 + 0x3c0) | *(byte *)(*(longlong *)(param_2 + 0xa0) + 0x4c) & 0xfe
      ;
      lVar8 = *(longlong *)(param_2 + 0xa0);
      if (*(int *)(param_1 + 0x3dc) != 0xff) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      puVar5 = *(undefined8 **)(lVar8 + 0x40);
      if (puVar5 != (undefined8 *)0x0) {
        LOCK();
        puVar1 = puVar5 + 3;
        iVar7 = *(int *)puVar1;
        *(int *)puVar1 = *(int *)puVar1 + -1;
        UNLOCK();
        if (iVar7 < 2) {
          (**(code **)*puVar5)();
        }
        *(undefined8 *)(lVar8 + 0x40) = 0;
        *(undefined8 *)(lVar8 + 0x30) = 0;
        *(undefined4 *)(lVar8 + 0x38) = 0;
      }
      lVar8 = func_0x(*(undefined8 *)(param_2 + 0x170),2);
      if (lVar8 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(byte *)(param_1 + 0x30) = *(byte *)(param_1 + 0x30) & 0xef | 0x40;
      goto LAB_;
    }
  }
  else {
    iVar7 = func_0x(uVar2,param_1 + 0x3c0,param_2);
    if (iVar7 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    func_0x(auStack_198,*(undefined8 *)(param_2 + 0x1c0));
    puStack_218 = auStack_198;
    uStack_220 = uStack_118;
    uStack_230 = 0;
    uStack_238 = 1;
    uStack_240 = *(undefined8 *)(param_2 + 0x1c0);
    uStack_248 = CONCAT71(uStack_248._1_7_,*(int *)(*(longlong *)(param_2 + 0x170) + 0x3dc) != 0xff)
    ;
    uStack_228 = uVar2;
    (*_DAT_)(0,0,0,0x458a);
    func_0x(param_2,0,0x458a,2);
    lVar8 = 0;
  }
  if ((undefined *)*param_3 != (undefined *)0x0) {
    puVar11 = (undefined *)*param_3;
    for (uVar10 = (ulonglong)uStack_1f0; uVar10 != 0; uVar10 = uVar10 - 1) {
      *puVar11 = 0;
      puVar11 = puVar11 + 1;
    }
    (*_DAT_)(*param_3);
    *param_3 = 0;
  }
  if (lVar8 != 0) {
    (*_DAT_)(lVar8);
  }
  if (lStack_1e8 != 0) {
    (*_DAT_)(lStack_1e8);
  }
LAB_:
  if (lStack_1c8 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  func_0x(uStack_58 ^ (ulonglong)auStack_268);
  return;
}

