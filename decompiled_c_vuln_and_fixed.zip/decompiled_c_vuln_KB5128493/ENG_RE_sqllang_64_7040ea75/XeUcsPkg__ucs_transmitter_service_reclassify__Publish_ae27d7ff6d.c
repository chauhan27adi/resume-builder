
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined2 *param_1)

{
  int iVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  uint uStack_28;
  longlong lStack_20;
  longlong lStack_18;
  undefined4 uStack_10;
  
  (*_DAT_)();
  lVar7 = 0;
  uStack_28 = 0;
  plVar2 = (longlong *)(*_DAT_)();
  if (plVar2 == (longlong *)0x0) {
    *(undefined8 *)(param_1 + 0x124) = 0;
  }
  else {
    if (*plVar2 != 0) {
      uStack_10 = *(undefined4 *)(plVar2 + 2);
      lStack_20 = *plVar2;
      lStack_18 = plVar2[1];
      *(undefined4 *)(plVar2 + 2) = 1;
    }
    do {
      lVar5 = lVar7;
      if (_DAT_ != 0) {
        lVar5 = _DAT_ + -0x38;
      }
      *plVar2 = lVar5;
      lVar3 = lVar7;
      if (_DAT_ != 0) {
        lVar3 = _DAT_ + -0x38;
      }
    } while (lVar3 != lVar5);
    *(longlong *)(param_1 + 0x124) = lVar5;
    if (lVar5 != 0) {
      do {
        iVar1 = func_0x(param_1);
        if (iVar1 != 0) {
          param_1[6] = 0;
          *(undefined4 *)(param_1 + 10) = 0;
          *param_1 = 0;
          func_0x(param_1,0x27efbd8);
        }
        lVar5 = *(longlong *)(param_1 + 0x124);
        uStack_28 = uStack_28 - 1 & 1;
        do {
          lVar3 = *(longlong *)(lVar5 + 0x38);
          lVar4 = lVar7;
          if (lVar3 != 0) {
            lVar4 = lVar3 + -0x38;
          }
          plVar2[uStack_28] = lVar4;
          lVar3 = *(longlong *)(lVar5 + 0x38);
          lVar6 = lVar7;
          if (lVar3 != 0) {
            lVar6 = lVar3 + -0x38;
          }
        } while (lVar6 != lVar4);
        *(longlong *)(param_1 + 0x124) = lVar4;
      } while (lVar4 != 0);
      goto LAB_;
    }
  }
  *(undefined4 *)(param_1 + 0x12a) = 2;
LAB_:
  if (plVar2 != (longlong *)0x0) {
    if (*(int *)(plVar2 + 2) != 0) {
      *plVar2 = lStack_20;
      plVar2[1] = lStack_18;
      *(undefined4 *)(plVar2 + 2) = uStack_10;
      return;
    }
    *plVar2 = 0;
    plVar2[1] = 0;
  }
  return;
}

