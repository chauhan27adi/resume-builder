
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  longlong lVar1;
  
  if (*(longlong *)(param_1 + 0xc0) != 0) {
    (*_DAT_)();
  }
  if (*(longlong *)(param_1 + 0xb8) != 0) {
    (*_DAT_)();
  }
  if (*(longlong *)(param_1 + 0xb0) != 0) {
    (*_DAT_)();
  }
  if (*(longlong *)(param_1 + 0xa8) != 0) {
    (*_DAT_)();
  }
  if (*(longlong *)(param_1 + 0x28) != 0) {
    (*_DAT_)();
  }
  if (*(longlong *)(param_1 + 0x20) != 0) {
    (*_DAT_)();
  }
  if (*(longlong *)(param_1 + 0x18) != 0) {
    (*_DAT_)();
  }
  lVar1 = *(longlong *)(param_1 + 0x10);
  if (lVar1 != 0) {
    if (*(longlong *)(lVar1 + 0xe0) != 0) {
      (*_DAT_)();
    }
    *(undefined8 *)(lVar1 + 0x98) = 0x4d34e8;
                    /* WARNING: Could not recover jumptable at 0x001000ce. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*_DAT_)(lVar1,0x100);
    return;
  }
  return;
}

