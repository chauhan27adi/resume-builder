
void FUN_(undefined8 *param_1)

{
  longlong *plVar1;
  
  *param_1 = 0x1e255b8;
  plVar1 = (longlong *)param_1[5];
  if ((plVar1 != (longlong *)0x0) && (param_1[6] != 0)) {
                    /* WARNING: Could not recover jumptable at 0x00100038. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*plVar1 + 0x18))(plVar1);
    return;
  }
  return;
}

