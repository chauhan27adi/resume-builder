
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong *param_1)

{
  longlong lVar1;
  
  lVar1 = *param_1;
  if (lVar1 != 0) {
    func_0x(lVar1,0x30,*(undefined8 *)(lVar1 + -8),0xff4f0);
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  return;
}

