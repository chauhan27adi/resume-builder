
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  (*_DAT_)(param_1[0xf],0x14,param_3,param_4,0xfffffffffffffffe);
  *param_1 = 0x7cffe8;
  return;
}

