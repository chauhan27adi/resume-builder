
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1)

{
  (*_DAT_)(*param_1);
                    /* WARNING: Could not recover jumptable at 0x0010001b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*_DAT_)(param_1[1]);
  return;
}

