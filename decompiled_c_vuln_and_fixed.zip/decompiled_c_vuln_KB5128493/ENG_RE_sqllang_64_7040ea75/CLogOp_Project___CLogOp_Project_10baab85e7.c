
/* WARNING: Control flow encountered bad instruction data */

void FUN_(undefined8 *param_1)

{
  *param_1 = 0x1f79bc0;
  if (param_1[3] == 0) {
    *param_1 = 0x1fd21a8;
    *param_1 = 0x1ffc680;
    *param_1 = 0x2081290;
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

