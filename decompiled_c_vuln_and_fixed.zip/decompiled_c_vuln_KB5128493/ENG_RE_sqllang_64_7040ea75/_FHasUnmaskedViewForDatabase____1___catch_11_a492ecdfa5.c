
undefined8 FUN_(void)

{
  return 0xfffd5;
}

