
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 *
FUN_(undefined8 *param_1,ulonglong param_2,undefined8 param_3,undefined8 param_4)

{
  param_1[6] = 0x1871a90;
  *param_1 = 0x1760b10;
  *param_1 = 0x1761cb0;
  if ((param_2 & 1) != 0) {
    (*_DAT_)(param_1,0x400,param_3,param_4,0xfffffffffffffffe);
  }
  return param_1;
}

