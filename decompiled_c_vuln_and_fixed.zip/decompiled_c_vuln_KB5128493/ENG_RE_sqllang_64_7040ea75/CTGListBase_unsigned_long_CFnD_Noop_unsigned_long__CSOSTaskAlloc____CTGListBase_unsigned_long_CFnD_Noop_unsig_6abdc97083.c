
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  longlong lVar1;
  longlong lVar2;
  
  func_0x();
  lVar2 = *param_1;
  while (lVar2 != 0) {
    lVar1 = *(longlong *)(lVar2 + 8);
    (*_DAT_)(lVar2);
    lVar2 = lVar1;
  }
  return;
}

