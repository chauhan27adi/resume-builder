
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1)

{
  longlong **pplVar1;
  
  if (*param_1 != (longlong *)0x0) {
    do {
      pplVar1 = (longlong **)*param_1;
      *param_1 = *pplVar1;
      (*_DAT_)(pplVar1,0x18);
    } while (*param_1 != (longlong *)0x0);
    *param_1 = (longlong *)0x0;
    param_1[1] = (longlong *)param_1;
    return;
  }
  *param_1 = (longlong *)0x0;
  param_1[1] = (longlong *)param_1;
  return;
}

