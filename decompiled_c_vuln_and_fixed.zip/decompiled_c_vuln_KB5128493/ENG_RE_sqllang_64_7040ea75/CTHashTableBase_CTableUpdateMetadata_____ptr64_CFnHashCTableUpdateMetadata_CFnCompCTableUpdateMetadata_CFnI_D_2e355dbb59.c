
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  func_0x();
  if (*(longlong *)(param_1 + 0x10) != 0) {
                    /* WARNING: Could not recover jumptable at 0x0010001c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*_DAT_)();
    return;
  }
  return;
}

