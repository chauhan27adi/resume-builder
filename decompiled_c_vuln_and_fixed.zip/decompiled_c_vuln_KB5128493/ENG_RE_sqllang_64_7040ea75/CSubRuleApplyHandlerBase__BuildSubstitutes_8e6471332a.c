
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined8 param_2,longlong param_3,longlong param_4)

{
  undefined8 uVar1;
  longlong lVar2;
  longlong *plVar3;
  
  uVar1 = *(undefined8 *)(param_3 + 0x10);
  lVar2 = func_0x(uVar1,param_2,*(undefined8 *)(param_3 + 0x20));
  if (lVar2 != 0) {
    plVar3 = (longlong *)(*_DAT_)(0x10,uVar1,0x1e8aed8,0x191,1);
    plVar3[1] = 0;
    *plVar3 = lVar2;
    plVar3[1] = *(longlong *)(param_4 + 8);
    *(longlong **)(param_4 + 8) = plVar3;
    if (*(longlong *)(param_4 + 0x10) == 0) {
      *(longlong **)(param_4 + 0x10) = plVar3;
    }
  }
  return;
}

