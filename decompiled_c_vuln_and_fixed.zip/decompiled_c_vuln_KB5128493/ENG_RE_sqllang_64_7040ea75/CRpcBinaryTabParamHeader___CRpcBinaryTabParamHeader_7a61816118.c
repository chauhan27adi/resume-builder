
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  (*_DAT_)(*(undefined8 *)(param_1 + 0x10));
                    /* WARNING: Could not recover jumptable at 0x0010001c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*_DAT_)(*(undefined8 *)(param_1 + 8));
  return;
}

