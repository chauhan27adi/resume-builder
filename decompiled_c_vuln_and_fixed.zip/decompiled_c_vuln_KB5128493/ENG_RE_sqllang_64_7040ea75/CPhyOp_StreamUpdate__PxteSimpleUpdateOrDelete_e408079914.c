
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8
FUN_(longlong param_1,longlong *param_2,undefined8 param_3,undefined8 param_4,
            ulonglong param_5,uint *param_6,longlong param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  bool bVar4;
  char cVar5;
  undefined uVar6;
  int iVar7;
  undefined4 uVar8;
  uint uVar9;
  longlong *plVar10;
  undefined8 uVar11;
  undefined8 uVar12;
  longlong lVar13;
  ulonglong uVar14;
  undefined8 *puVar15;
  longlong unaff_GS_OFFSET;
  longlong **pplVar16;
  undefined4 uVar17;
  ulonglong uVar18;
  ulonglong in_stack_fffffffffffffd38;
  char cVar19;
  undefined8 uVar20;
  undefined8 uStack_290;
  undefined uStack_288;
  uint uStack_284;
  uint uStack_280;
  undefined8 *puStack_278;
  uint uStack_270;
  uint uStack_26c;
  longlong *plStack_268;
  longlong lStack_260;
  longlong lStack_258;
  undefined8 uStack_250;
  longlong lStack_248;
  undefined8 uStack_240;
  undefined4 uStack_238;
  undefined8 uStack_230;
  undefined uStack_228;
  undefined4 uStack_224;
  undefined4 uStack_220;
  longlong lStack_218;
  longlong lStack_210;
  undefined8 uStack_208;
  undefined8 uStack_200;
  undefined8 *puStack_1f8;
  longlong **pplStack_1f0;
  longlong lStack_1e8;
  undefined8 uStack_1e0;
  undefined8 *puStack_1d8;
  longlong lStack_1d0;
  undefined8 uStack_1c8;
  longlong lStack_1c0;
  undefined8 uStack_1b8;
  undefined uStack_1b0;
  undefined auStack_1a8 [16];
  undefined8 uStack_198;
  undefined4 uStack_190;
  undefined8 uStack_188;
  undefined8 *puStack_180;
  undefined8 uStack_178;
  undefined auStack_168 [48];
  longlong lStack_138;
  char cStack_75;
  undefined8 *puStack_50;
  
  uStack_188 = 0xfffffffffffffffe;
  lVar13 = param_2[2];
  lStack_1d0 = *(longlong *)(lVar13 + 0x80);
  if ((lStack_1d0 != 0) && ((double)param_2[0x1a] < *(double *)(lStack_1d0 + 0x30))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_1e0 = *(undefined8 *)(*param_2 + 0x48);
  puStack_1d8 = *(undefined8 **)(*param_2 + 8);
  lStack_1e8 = param_2[1];
  uStack_208 = 0;
  uStack_230 = *(undefined8 *)(param_1 + 0x10);
  puStack_1f8 = &uStack_230;
  uStack_228 = 0;
  uStack_224 = 0;
  uStack_220 = 4;
  lStack_218 = 0;
  uStack_238 = 1;
  uStack_240 = 0x1fce1e8;
  lStack_210 = 0;
  cVar19 = '\0';
  pplStack_1f0 = (longlong **)(lVar13 + 0x20);
  plVar10 = *pplStack_1f0;
  while( true ) {
    lVar1 = *plVar10;
    if (lVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    iVar7 = (**(code **)(**(longlong **)(lVar1 + 0x10) + 0x18))();
    if (iVar7 == 0x9a) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iVar7 == 0xa9) break;
    if (iVar7 == 0xb7) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iVar7 != 0xaa) {
      return;
    }
    plVar10 = *(longlong **)(lVar1 + 0x20);
    lVar13 = lVar1;
  }
  lStack_260 = *(longlong *)(*(longlong *)(lVar1 + 0x10) + 0x40);
  uVar9 = *(uint *)(*(longlong *)(lVar1 + 0x10) + 0x48);
  if (*(uint *)(*(longlong *)(lStack_260 + 0x90) + 0x1c) <= uVar9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar2 = *(longlong *)
           (*(longlong *)(*(longlong *)(lStack_260 + 0x90) + 0x28) + (ulonglong)uVar9 * 8);
  if ((*(uint *)(lVar2 + 0x1c) >> 2 & 1) == 0) {
    return;
  }
  if (*(int *)(lStack_260 + 0x2fc) != *(int *)(*(longlong *)(param_1 + 0x90) + 0x18)) {
    return;
  }
  if (*(int *)(lStack_260 + 0x2f8) != *(int *)(*(longlong *)(param_1 + 0x90) + 0x1c)) {
    return;
  }
  lVar3 = *(longlong *)(lVar1 + 0x10);
  if (*(int *)(lVar1 + 0x18) != 1) {
    return;
  }
  uVar12 = **(undefined8 **)(lVar1 + 0x20);
  cVar5 = func_0x(uVar12);
  if (cVar5 == '\0') {
    return;
  }
  if (*(int *)(lVar3 + 0x50) - 4U < 2) {
    return;
  }
  if (cVar19 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong *)(lVar2 + 0x160) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong *)(lVar2 + 0x160) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(char *)(lVar3 + 0x4c) != '\0') {
    return;
  }
  uVar6 = func_0x
                    (*(undefined8 *)(param_1 + 0x10),uVar12,lStack_260,uVar9,
                     *(undefined *)(lVar3 + 0x55));
  plStack_268 = (longlong *)0x0;
  if (*(longlong *)(lVar13 + 0x70) == 0) {
    lVar1 = *(longlong *)(lVar1 + 0x58);
    uStack_1c8 = 0x1fce760;
    uStack_1b8 = 0;
    uStack_1b0 = 1;
    auStack_1a8 = ZEXT816(0);
    uStack_198 = 0;
    uStack_190 = 0;
    pplVar16 = &plStack_268;
    lStack_1c0 = lVar13;
    (**(code **)(**(longlong **)(lVar13 + 0x10) + 0x10))
              (*(longlong **)(lVar13 + 0x10),&uStack_1c8,*(undefined8 *)(lVar13 + 0x60),0,pplVar16);
    uVar8 = (undefined4)((ulonglong)pplVar16 >> 0x20);
    if (lStack_1c0 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (plStack_268 != (longlong *)0x0) {
      (**(code **)(*plStack_268 + 0x10))
                (plStack_268,*(undefined8 *)(*(longlong *)(lStack_1c0 + 0x10) + 0x10));
    }
    plVar10 = plStack_268;
    func_0x(*(undefined8 *)(lVar1 + 200));
    func_0x(*(undefined8 *)(lVar1 + 200),plVar10[0x1a]);
    lVar13 = *(longlong *)(lVar1 + 200);
    uVar18 = 0;
    puStack_180 = (undefined8 *)
                  func_0x
                            (*(undefined8 *)(param_1 + 0x10),lStack_260,(ulonglong)uVar9,
                             *(undefined *)(lVar3 + 0x55),
                             CONCAT44(uVar8,*(undefined4 *)(lVar3 + 0x50)),param_2,uVar12,0);
    if (*(int *)((longlong)puStack_180 + 0x1c) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar12 = *(undefined8 *)puStack_180[5];
    if (puStack_180 != (undefined8 *)0x0) {
      puVar15 = puStack_180 + 1;
      *(int *)puVar15 = *(int *)puVar15 + -1;
      if (*(int *)puVar15 == 0) {
        (**(code **)*puStack_180)(puStack_180,1);
      }
    }
    uStack_1c8 = 0x1fce760;
    (*_DAT_)(auStack_1a8._8_8_,0x68);
    (*_DAT_)(uStack_198,0xc0);
    lVar1 = lStack_210;
    if (lStack_210 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar20 = *(undefined8 *)(*(longlong *)(lStack_210 + 0x20) + 8);
    func_0x(auStack_168,*param_2,0,lStack_210);
    uStack_208 = func_0x(auStack_168,uVar20,0);
    if (cStack_75 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (lStack_138 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (puStack_50 != (undefined8 *)0x0) {
      puVar15 = puStack_50 + 1;
      *(int *)puVar15 = *(int *)puVar15 + -1;
      if (*(int *)puVar15 == 0) {
        (**(code **)*puStack_50)(puStack_50,1);
      }
    }
    uVar14 = **(ulonglong **)(lVar1 + 0x20);
    lVar1 = *(longlong *)(*(longlong *)(uVar14 + 0x58) + 200);
    if ((lVar1 != 0) && (*(longlong *)(lVar1 + 0x18) != 0)) {
      uStack_250 = 0;
      uVar14 = *(ulonglong *)
                (*(longlong *)
                  ((ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8) +
                0x48);
      plVar10 = (longlong *)(uVar14 + 0x2b0);
      if (uVar14 == 0) {
        plVar10 = (longlong *)0x2b8;
      }
      lStack_248 = *plVar10;
      lStack_258 = *(longlong *)(lVar1 + 0x18);
    }
    while (((lVar1 != 0 && (*(longlong *)(lVar1 + 0x18) != 0)) &&
           (cVar19 = func_0x(uVar14,&lStack_258,&uStack_270), cVar19 != '\0'))) {
      if (*(uint *)(*(longlong *)(lStack_248 + 0x10) + 0xc) <= uStack_270 >> 8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar20 = *(undefined8 *)
                (*(longlong *)
                  (*(longlong *)(*(longlong *)(lStack_248 + 0x10) + 0x18) +
                  (ulonglong)(uStack_270 >> 8) * 8) + (ulonglong)(uStack_270 & 0xff) * 8);
      if (*(longlong *)(param_7 + 0x28) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar9 = *(uint *)(param_7 + 0x1c);
      if (*(uint *)(param_7 + 0x20) <= uVar9) {
        if (uVar9 == 0xffffffff) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        func_0x(param_7 + 0x10,uVar9 + 1);
      }
      uVar14 = (ulonglong)*(uint *)(param_7 + 0x1c);
      *(undefined8 *)(*(longlong *)(param_7 + 0x28) + uVar14 * 8) = uVar20;
      *(int *)(param_7 + 0x1c) = *(int *)(param_7 + 0x1c) + 1;
    }
    uVar8 = func_0x(*(undefined8 *)(param_1 + 0x10),lVar13,lStack_260);
    (**(code **)(**(longlong **)(*param_2 + 0x50) + 0x28))(*(longlong **)(*param_2 + 0x50),uVar8);
    lVar1 = *(longlong *)(lVar13 + 0x18);
    if (lVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(lVar1 + 0xc) != 0) {
      uVar9 = func_0x(lVar1);
      uStack_290 = *(undefined8 *)(param_1 + 0x10);
      uStack_288 = 0;
      uStack_284 = 0;
      uStack_280 = 1;
      if (uVar9 != 0) {
        uStack_280 = uVar9;
      }
      puStack_278 = (undefined8 *)0x0;
      uVar8 = 1;
      uVar20 = 0x1fce1e8;
      puVar15 = &uStack_290;
      if (*(longlong *)(lVar13 + 0x18) != 0) {
        uStack_250 = 0;
        lVar1 = *(longlong *)
                 (*(longlong *)
                   ((ulonglong)*_DAT_ +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8) +
                 0x48);
        plVar10 = (longlong *)(lVar1 + 0x2b0);
        if (lVar1 == 0) {
          plVar10 = (longlong *)0x2b8;
        }
        lStack_248 = *plVar10;
        puVar15 = (undefined8 *)0x2b8;
        lStack_258 = *(longlong *)(lVar13 + 0x18);
      }
      while ((*(longlong *)(lVar13 + 0x18) != 0 &&
             (cVar19 = func_0x(puVar15,&lStack_258,&uStack_26c), uVar9 = uStack_280,
             cVar19 != '\0'))) {
        if (*(uint *)(*(longlong *)(lStack_248 + 0x10) + 0xc) <= uStack_26c >> 8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        uVar11 = *(undefined8 *)
                  (*(longlong *)
                    (*(longlong *)(*(longlong *)(lStack_248 + 0x10) + 0x18) +
                    (ulonglong)(uStack_26c >> 8) * 8) + (ulonglong)(uStack_26c & 0xff) * 8);
        if (puStack_278 == (undefined8 *)0x0) {
          puStack_278 = (undefined8 *)func_0x(&uStack_290,uStack_280);
        }
        if (uVar9 <= uStack_284) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        puStack_278[uStack_284] = uVar11;
        uStack_284 = uStack_284 + 1;
        puVar15 = puStack_278;
        uStack_280 = uVar9;
      }
      lVar13 = lStack_1e8;
      *param_6 = *param_6 | 0x20000;
      if (_DAT_ < *(double *)(*(longlong *)(lStack_1e8 + 0x10) + 0x20)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(longlong *)(param_1 + 0xe0) == 0) {
        func_0x(param_1,param_6,uStack_1e0);
      }
      uVar11 = func_0x
                         (*(undefined8 *)(param_1 + 0x10),
                          *(undefined8 *)
                           (*(longlong *)(*(longlong *)(param_1 + 0x90) + 0x28) + 0x130));
      bVar4 = *(double *)(*(longlong *)(lVar13 + 0x10) + 0x20) <= _DAT_;
      uStack_178 = uVar11;
      uVar20 = func_0x(param_1,param_2,param_7,param_4,param_5,uStack_208,param_6,
                               uVar18 & 0xffffffffffffff00,
                               in_stack_fffffffffffffd38 & 0xffffffffffffff00,param_8,param_9,
                               param_10,uVar6,uVar20,uVar8);
      uVar17 = (undefined4)((ulonglong)param_6 >> 0x20);
      uVar8 = 0;
      uStack_200 = 0;
      if (uStack_284 != 0) {
        puStack_1f8 = puStack_1d8;
        uVar8 = func_0x(&uStack_290,&puStack_1f8,&uStack_200,0xffffffff);
      }
      lVar13 = lStack_1d0;
      if (*(longlong *)(param_1 + 0xa0) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar12 = (**(code **)(**(longlong **)(*param_2 + 0x58) + 0x178))
                         (*(longlong **)(*param_2 + 0x58),param_3,lStack_1d0,param_2[0x14],
                          param_5 & 0xffffffffffffff00,uVar20,CONCAT44(uVar17,uVar8),uStack_200,
                          uVar12,bVar4,uVar6,uVar11);
      if (((_DAT_ < *(double *)(lVar13 + 0x30)) &&
          (*(longlong *)(*(longlong *)(param_2[2] + 0x50) + 0x48) != 0)) &&
         (lVar13 = func_0x(), lVar13 != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      (*_DAT_)(uVar11);
      func_0x(&uStack_290);
      if (puStack_278 != (undefined8 *)0x0) {
        (*_DAT_)();
        puStack_278 = (undefined8 *)0x0;
      }
      uStack_280 = 0;
      uStack_240 = 0x1f08ec0;
      func_0x(&uStack_230);
      if (lStack_218 == 0) {
        return uVar12;
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

