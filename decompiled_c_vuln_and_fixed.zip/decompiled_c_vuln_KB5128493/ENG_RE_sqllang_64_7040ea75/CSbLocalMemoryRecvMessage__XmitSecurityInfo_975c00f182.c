
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(void)

{
  (*_DAT_)(1,0x20c8f18,0x20ca850,0x81e,0x20cac20);
  return 0;
}

