
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2,longlong param_3,longlong param_4)

{
  undefined8 uVar1;
  longlong lVar2;
  longlong lVar3;
  int iVar4;
  longlong lVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  longlong unaff_GS_OFFSET;
  
  uVar1 = *(undefined8 *)(param_3 + 0x10);
  if (*(longlong *)(param_3 + 0x28) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar2 = *(longlong *)(*(longlong *)(param_3 + 0x28) + 0x10);
  lVar5 = func_0x(param_2,param_3);
  if (lVar5 != 0) {
    if ((*(byte *)(lVar2 + 0xb0) & 8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    iVar4 = func_0x();
    if (iVar4 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (2 < *(int *)(param_2 + 0x18) - 1U) {
      iVar4 = (**(code **)(*param_1 + 0x38))(param_1);
      if (iVar4 == 0x16c) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      lVar3 = *(longlong *)
               (*(longlong *)
                 (*(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8 +
                 (ulonglong)*_DAT_) + 0x48);
      puVar7 = (undefined8 *)(lVar3 + 0x70);
      if (lVar3 == 0) {
        puVar7 = (undefined8 *)0x78;
      }
      for (; puVar7 != (undefined8 *)0x0; puVar7 = (undefined8 *)*puVar7) {
        if (0x2397 < (ulonglong)*(uint *)(puVar7 + 1) + 0x100) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
      }
      iVar4 = (**(code **)(*param_1 + 0x38))(param_1);
      if (iVar4 == 0x16e) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      func_0x(uVar1,lVar5,param_4,0);
      if ((*(byte *)(lVar2 + 0x6a) & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    uVar6 = func_0x(lVar5);
    puVar7 = (undefined8 *)(*_DAT_)(0x10,uVar1,0x1f385f8,0x191,1);
    puVar7[1] = 0;
    *puVar7 = uVar6;
    puVar7[1] = *(undefined8 *)(param_4 + 8);
    *(undefined8 **)(param_4 + 8) = puVar7;
    if (*(longlong *)(param_4 + 0x10) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    (*_DAT_)(lVar5,0x68);
  }
  return;
}

