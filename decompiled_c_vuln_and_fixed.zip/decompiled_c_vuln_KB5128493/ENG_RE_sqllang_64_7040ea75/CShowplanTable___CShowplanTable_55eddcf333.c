
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1)

{
  *param_1 = 0xf52330;
  *(undefined4 *)((longlong)param_1 + 0x1c) = 0;
  if (param_1[5] != 0) {
    (*_DAT_)();
    param_1[5] = 0;
  }
  *(undefined4 *)(param_1 + 4) = 0;
  return;
}

