
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x010d1e2f) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  int *piVar1;
  int iVar2;
  longlong lVar3;
  longlong lVar4;
  undefined auStack_188 [32];
  longlong lStack_168;
  undefined8 uStack_158;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined8 uStack_148;
  undefined8 uStack_140;
  undefined4 uStack_138;
  undefined2 uStack_134;
  undefined8 uStack_f0;
  ulonglong uStack_38;
  
  uStack_f0 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_188;
  uStack_158 = *(undefined8 *)(param_1 + 0x50);
  uStack_150 = 0;
  uStack_14c = _DAT_;
  uStack_148 = 0;
  uStack_140 = 0;
  uStack_138 = 0;
  uStack_134 = 0;
  lVar3 = func_0x(&uStack_158);
  while( true ) {
    lStack_168 = lVar3;
    if (lVar3 == 0) {
      func_0x(&uStack_158,0);
      (*_DAT_)(uStack_148);
      uStack_148 = 0;
      func_0x(uStack_38 ^ (ulonglong)auStack_188);
      return;
    }
    if (*(int *)(lVar3 + 0xb4) != 0) break;
    lVar4 = func_0x(&uStack_158);
    LOCK();
    piVar1 = (int *)(lVar3 + 0x18);
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    lVar3 = lVar4;
    if (iVar2 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

