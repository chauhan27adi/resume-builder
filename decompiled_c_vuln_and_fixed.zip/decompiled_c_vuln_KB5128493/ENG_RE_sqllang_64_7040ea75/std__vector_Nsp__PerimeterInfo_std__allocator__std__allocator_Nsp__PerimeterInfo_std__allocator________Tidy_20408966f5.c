
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  code *pcVar1;
  longlong lVar2;
  longlong lVar3;
  
  lVar2 = *param_1;
  if (lVar2 != 0) {
    lVar3 = param_1[1];
    if (lVar2 != lVar3) {
      do {
        func_0x(lVar2 + 0x10);
        lVar2 = lVar2 + 0x40;
      } while (lVar2 != lVar3);
      lVar2 = *param_1;
    }
    lVar3 = lVar2;
    if ((0xfff < (param_1[2] - lVar2 & 0xffffffffffffffc0U)) &&
       (lVar3 = *(longlong *)(lVar2 + -8), 0x1f < (lVar2 - lVar3) - 8U)) {
      (*_DAT_)();
      pcVar1 = (code *)swi(3);
      (*pcVar1)();
      return;
    }
    (*_DAT_)(lVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}

