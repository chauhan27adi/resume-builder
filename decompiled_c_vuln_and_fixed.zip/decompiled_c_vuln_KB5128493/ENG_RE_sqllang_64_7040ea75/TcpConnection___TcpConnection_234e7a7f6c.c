
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined8 in_stack_ffffffffffffffe8;
  undefined4 uVar3;
  
  uVar3 = (undefined4)((ulonglong)in_stack_ffffffffffffffe8 >> 0x20);
  func_0x();
  if (*(char *)(param_1 + 4) != '\0') {
    iVar1 = (*_DAT_)(param_1[2],0xffffffff);
    if (iVar1 != 0) {
      if (iVar1 == -1) {
        uVar2 = (*_DAT_)();
        if ((DAT_ & 1) != 0) {
          func_0x(0x1cf86a8,0x1fe3a88,0xc9f,0x1fe3a10,CONCAT44(uVar3,uVar2));
        }
      }
      else if ((DAT_ & 1) != 0) {
        func_0x(0x1cf86a8,0x1fe3a88,0xca6,0x1fe3990,CONCAT44(uVar3,iVar1));
      }
      *param_1 = 0;
    }
  }
  if (*param_1 != 0) {
    (*_DAT_)(*param_1,0x20);
    *param_1 = 0;
  }
  param_1[1] = 0;
  if (param_1[2] != 0) {
    (*_DAT_)();
    param_1[2] = 0;
  }
  if ((*(int *)((longlong)param_1 + 0x2c) != 0) && ((DAT_ & 0x10) != 0)) {
    func_0x(*(int *)((longlong)param_1 + 0x2c),0x1cf86a8,0x1fe3a88,0xcbf,0x1fd097c);
  }
  return;
}

