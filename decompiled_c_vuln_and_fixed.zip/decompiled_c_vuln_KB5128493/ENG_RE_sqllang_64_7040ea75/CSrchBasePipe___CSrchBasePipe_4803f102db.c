
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1)

{
  *param_1 = 0xaffec0;
  param_1[0x21] = 0xaffdc8;
  if (((undefined8 *)param_1[0x22] != (undefined8 *)0x0) &&
     ((undefined8 *)param_1[0x22] != param_1 + 0x24)) {
    (*_DAT_)();
  }
  param_1[0x21] = 0xaffd90;
  param_1[0x1c] = 0xaffe00;
  if (param_1[0x1d] != -1) {
    (*_DAT_)();
  }
  param_1[0x1d] = 0xffffffffffffffff;
  param_1[0x14] = 0x4e5d18;
  return;
}

