
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(void)

{
  undefined8 uVar1;
  longlong lVar2;
  longlong *plVar3;
  uint uVar4;
  longlong lVar5;
  longlong unaff_GS_OFFSET;
  
  lVar2 = (ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar5 = *(longlong *)(lVar2 + 0x100);
  if (lVar5 == 0) {
    (*_DAT_)(0);
    lVar5 = *(longlong *)(lVar2 + 0x100);
  }
  lVar5 = *(longlong *)(lVar5 + 600);
  uVar4 = 0;
  plVar3 = (longlong *)(lVar5 + 0x1c8);
  do {
    lVar2 = *plVar3;
    if (lVar2 != 0) {
      uVar1 = (*_DAT_)(uVar4);
      (*_DAT_)(uVar1,(longlong)((ulonglong)((uint)(lVar2 >> 0x3f) & 0x1fff) + lVar2) >> 0xd,
                       6);
      *(longlong *)(lVar5 + 0x1b0) = *(longlong *)(lVar5 + 0x1b0) - lVar2;
      *plVar3 = *plVar3 - lVar2;
      *(longlong *)(lVar5 + 0x1c0) = *(longlong *)(lVar5 + 0x1c0) - lVar2;
    }
    uVar4 = uVar4 + 1;
    plVar3 = plVar3 + 1;
  } while (uVar4 < 0x40);
  if (*(longlong *)
       ((ulonglong)*_DAT_ +
        *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 0x100
       ) == 0) {
    (*_DAT_)();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

