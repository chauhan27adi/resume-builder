
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong param_2)

{
  (*_DAT_)(*(undefined8 *)(param_2 + 0x98),0x10);
  return;
}

