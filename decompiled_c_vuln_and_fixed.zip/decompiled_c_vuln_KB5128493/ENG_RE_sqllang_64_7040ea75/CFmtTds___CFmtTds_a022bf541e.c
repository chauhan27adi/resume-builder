
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1)

{
  longlong *plVar1;
  
  plVar1 = *param_1;
  if (plVar1 != (longlong *)0x0) {
    (**(code **)(*plVar1 + 0x10))(plVar1,1);
  }
  plVar1 = param_1[1];
  if (plVar1 != (longlong *)0x0) {
    func_0x(plVar1);
                    /* WARNING: Could not recover jumptable at 0x0010003a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*_DAT_)(plVar1,0x48);
    return;
  }
  return;
}

