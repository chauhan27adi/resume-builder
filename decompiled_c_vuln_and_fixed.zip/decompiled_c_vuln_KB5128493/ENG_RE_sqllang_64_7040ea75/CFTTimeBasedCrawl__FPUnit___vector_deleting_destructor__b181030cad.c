
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(undefined8 param_1,ulonglong param_2)

{
  func_0x();
  if ((param_2 & 1) != 0) {
    (*_DAT_)(param_1,0x78);
  }
  return param_1;
}

