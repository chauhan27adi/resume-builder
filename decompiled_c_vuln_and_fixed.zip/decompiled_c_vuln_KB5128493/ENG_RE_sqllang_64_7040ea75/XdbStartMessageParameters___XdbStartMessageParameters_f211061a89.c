
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x1428) != 0) {
    (*_DAT_)();
    *(undefined8 *)(param_1 + 0x1428) = 0;
  }
  return;
}

