
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(undefined8 param_1,longlong param_2)

{
  uint uVar1;
  
  (*_DAT_)(param_2 + 0x50,param_2 + 0x30);
  *(undefined4 *)(param_2 + 0x60) = *(undefined4 *)(param_2 + 0x30);
  *(undefined4 *)(param_2 + 100) = *(undefined4 *)(param_2 + 0x34);
  *(undefined4 *)(param_2 + 0x68) = *(undefined4 *)(param_2 + 0x38);
  *(undefined4 *)(param_2 + 0x6c) = *(undefined4 *)(param_2 + 0x3c);
  *(int *)(param_2 + 0x70) = *(int *)(param_2 + 0x40);
  if (*(int *)(param_2 + 0x40) == 1) {
    uVar1 = *(uint *)(param_2 + 0x30);
  }
  else {
    uVar1 = (uint)*(ushort *)(param_2 + 0x30);
  }
  func_0x(uVar1,*(ulonglong *)(param_2 + 0x38) >> 0x20,0,0);
  (*_DAT_)(param_2 + 0x50);
  return 0xffffffffffc1c5a2;
}

