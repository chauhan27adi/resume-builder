
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  longlong lVar1;
  
  lVar1 = *param_1;
  if (lVar1 != 0) {
    func_0x(lVar1);
                    /* WARNING: Could not recover jumptable at 0x00100023. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*_DAT_)(lVar1,400);
    return;
  }
  return;
}

