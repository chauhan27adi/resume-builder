
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  uVar1 = 0xfffffffffffffffe;
  *param_1 = 0x1f665b8;
  func_0x();
  if ((longlong *)param_1[0x88] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[0x88] + 0x38))();
  }
  if ((longlong *)param_1[0x87] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[0x87] + 0xb0))();
  }
  func_0x(param_1 + 0x77);
  if (*(char *)(param_1 + 0x7f) != '\0') {
    *(undefined *)(param_1 + 0x7f) = 0;
    if ((*(byte *)((longlong)param_1 + 0x402) & 1) != 0) {
      (*_DAT_)(param_1 + 0x80,_DAT_,param_3,param_4,uVar1);
    }
    *(undefined4 *)(param_1 + 0x80) = 0xa503;
    param_1[0x81] = 0;
    param_1[0x82] = 0;
    *(undefined4 *)(param_1 + 0x83) = 0;
  }
  func_0x(param_1 + 0x10);
  if (*(char *)(param_1 + 7) != '\0') {
    *(undefined *)(param_1 + 7) = 0;
    if ((*(byte *)((longlong)param_1 + 0x42) & 1) != 0) {
      (*_DAT_)(param_1 + 8,_DAT_);
    }
    *(undefined4 *)(param_1 + 8) = 0xa503;
    param_1[9] = 0;
    param_1[10] = 0;
    *(undefined4 *)(param_1 + 0xb) = 0;
  }
  return;
}

