
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_(undefined4 *param_1,longlong param_2)

{
  byte bVar1;
  uint uVar2;
  longlong lVar3;
  longlong lVar4;
  int iVar5;
  ulonglong uVar6;
  undefined8 uVar7;
  uint7 uVar9;
  longlong *plVar8;
  uint uVar10;
  undefined auStack_2a8 [8];
  undefined4 uStack_2a0;
  undefined4 uStack_298;
  undefined4 **ppuStack_290;
  undefined *puStack_288;
  undefined8 uStack_280;
  undefined4 *puStack_278;
  undefined8 uStack_270;
  undefined auStack_268 [528];
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  byte bStack_3c;
  uint uStack_3b;
  
  uVar6 = (**(code **)(**(longlong **)(param_2 + 0x10) + 0x18))();
  if (((int)uVar6 == 0x1f) && (*(int *)(param_2 + 0x18) == 2)) {
    lVar3 = *(longlong *)(*(longlong *)(param_2 + 0x20) + 8);
    iVar5 = (**(code **)(**(longlong **)(lVar3 + 0x10) + 0x18))();
    uVar10 = 0;
    if (iVar5 != 0x89) {
      (*_DAT_)(1,0x113df00,0x1132da0,0x7f4,0);
    }
    uVar7 = (**(code **)(**(longlong **)(lVar3 + 0x10) + 0x18))();
    uVar9 = (uint7)((ulonglong)uVar7 >> 8);
    if ((int)uVar7 == 0x89) {
      uVar2 = *(uint *)(lVar3 + 0x18);
      if (uVar2 == 0) {
        uVar6 = (ulonglong)uVar9;
      }
      else {
        do {
          lVar4 = *(longlong *)(*(longlong *)(lVar3 + 0x20) + (longlong)(int)uVar10 * 8);
          plVar8 = (longlong *)(**(code **)(**(longlong **)(lVar4 + 0x10) + 0x18))();
          if ((int)plVar8 == 0x8a) {
            lVar4 = **(longlong **)(lVar4 + 0x20);
            plVar8 = (longlong *)(**(code **)(**(longlong **)(lVar4 + 0x10) + 0x18))();
            if (((int)plVar8 == 0x5a) &&
               (plVar8 = (longlong *)
                         (**(code **)(**(longlong **)(*(longlong *)(lVar4 + 0x10) + 0x60) + 0x40))()
               , (char)plVar8 != '\0')) {
              plVar8 = *(longlong **)(lVar4 + 0x20);
              lVar4 = *(longlong *)(*plVar8 + 0x10);
              if ((_DAT_ & 0x400000) != 0) {
                bVar1 = *(byte *)(lVar4 + 0x18);
                ppuStack_290 = &puStack_278;
                puStack_288 = auStack_268;
                puStack_278 = &uStack_48;
                uStack_48 = *param_1;
                uStack_2a0 = 0x10000;
                uStack_298 = 0;
                uStack_58 = 0;
                uStack_280 = 0;
                uStack_50 = 0;
                uStack_270 = 0x11;
                uStack_44 = (uint)bVar1;
                uStack_40 = 0;
                if (1 < (byte)(bVar1 + 0x10)) {
                  uStack_40 = *(undefined4 *)(lVar4 + 0x2c);
                }
                uStack_3b = (uint)*(ushort *)(lVar4 + 0x28);
                bStack_3c = ~*(byte *)(lVar4 + 0x19) & 1;
                if ((*(ushort *)(lVar4 + 0x28) == 0xffff) ||
                   (*(char *)((ulonglong)*(byte *)((ulonglong)bVar1 + 0xc41040) + 0x1704fc8) != '\0'
                   )) {
                  uStack_3b = 0x1fa4;
                }
                plVar8 = (longlong *)func_0x(auStack_2a8);
              }
            }
          }
          uVar10 = uVar10 + 1;
        } while (uVar10 < uVar2);
        uVar6 = (ulonglong)plVar8 >> 8;
      }
    }
    else {
      uVar6 = (ulonglong)uVar9;
    }
    return uVar6 << 8;
  }
  return uVar6 & 0xffffffffffffff00;
}

