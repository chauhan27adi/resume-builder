
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  int *piVar1;
  
  *param_1 = 0x2572830;
  if (param_1[0x48] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_1[0x21] != 0) {
    piVar1 = (int *)(param_1[0x21] + 0x1c4);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  if (param_1[0x2e] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_1[0x49] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  param_1[0x49] = 0;
  if (param_1[0x4a] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  param_1[0x4a] = 0;
  (*_DAT_)(param_1[0x2e],0x18,param_3,param_4,0xfffffffffffffffe);
  param_1[0x2e] = 0;
  (*_DAT_)(param_1[0x30]);
  param_1[0x30] = 0;
  (*_DAT_)(param_1[0x2f]);
  param_1[0x2f] = 0;
  if (param_1[0x3d] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  param_1[0x3d] = 0;
  if (param_1[0x3c] != 0) {
    func_0x();
    param_1[0x3c] = 0;
  }
  if ((longlong *)param_1[0x3e] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[0x3e] + 0x10))();
    param_1[0x3e] = 0;
  }
  *(undefined4 *)(param_1 + 1) = 0;
  if (param_1[0x58] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)((longlong)param_1 + 0x2ac) == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_1[0x4f] == 0) {
    if ((param_1[0x46] & 0x40) == 0) {
      param_1[0x22] = 0x2585620;
      if (*(int *)(param_1 + 0x24) == 3) {
        *(undefined4 *)(param_1 + 0x24) = 0;
        func_0x(param_1[0x23] + 0x530,1);
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

