
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_(longlong param_1,ulonglong param_2)

{
  int3 iVar1;
  uint uVar2;
  int7 iVar4;
  ulonglong uVar3;
  
  uVar3 = **(ulonglong **)(param_1 + 8);
  uVar2 = *(byte *)(param_1 + 4) - 0x81;
  if (uVar2 < 6) {
    iVar1 = (int3)(uVar2 >> 8);
    iVar4 = (int7)iVar1;
    switch(uVar2) {
    case 0:
      return CONCAT71((int7)iVar1,param_2 == uVar3);
    case 1:
      return CONCAT71((int7)iVar1,param_2 < uVar3);
    case 2:
      return CONCAT71(iVar4,param_2 <= uVar3);
    case 3:
      return CONCAT71(iVar4,uVar3 < param_2);
    case 4:
      return CONCAT71(iVar4,uVar3 <= param_2);
    case 5:
      return CONCAT71(iVar4,param_2 != uVar3);
    }
  }
  uVar3 = (*_DAT_)(1,0,0x23497c8,0xd2,0x2160310);
  return uVar3 & 0xffffffffffffff00;
}

