
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 *
FUN_(undefined8 *param_1,ulonglong param_2,undefined8 param_3,undefined8 param_4)

{
  *param_1 = 0x171e2e8;
  param_1[0xc] = 0x16f9128;
  param_1[0xc] = 0x16f9168;
  *param_1 = 0x16f9168;
  if ((param_2 & 1) != 0) {
    (*_DAT_)(param_1,0xd8,param_3,param_4,0xfffffffffffffffe);
  }
  return param_1;
}

