
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  longlong lVar1;
  longlong lVar2;
  longlong unaff_GS_OFFSET;
  
  if (*(longlong *)
       (*(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 0x88
       + (ulonglong)*_DAT_) == 0) {
    (*_DAT_)(1,0xa1c550,0x9bed28,0x6f,0);
  }
  lVar1 = (ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  *(undefined8 *)(lVar1 + 0x88) = 0;
  *(undefined8 *)(*(longlong *)(*(longlong *)(lVar1 + 0x100) + 0x40) + 0x88) = 0;
  lVar1 = *(longlong *)(param_1 + 0x10);
  if (lVar1 != 0) {
    if (*(longlong *)
         (*(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
          0x88 + (ulonglong)*_DAT_) != 0) {
      (*_DAT_)(1,0xa1c530,0x9bed28,0x5a,0);
    }
    lVar2 = (ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    *(longlong *)(lVar2 + 0x88) = lVar1;
    *(longlong *)(*(longlong *)(*(longlong *)(lVar2 + 0x100) + 0x40) + 0x88) = lVar1;
  }
  return;
}

