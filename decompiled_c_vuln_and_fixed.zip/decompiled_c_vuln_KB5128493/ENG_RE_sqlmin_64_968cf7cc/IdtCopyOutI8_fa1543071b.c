
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong param_1,undefined8 *param_2,uint param_3)

{
  undefined8 uVar1;
  
  if (param_3 < 8) {
    (*_DAT_)(1,0x255d2c0,0x25517d0,0x1716,0);
  }
  uVar1 = *(undefined8 *)(param_1 + 8);
  *param_2 = uVar1;
  return CONCAT71((int7)((ulonglong)uVar1 >> 8),8);
}

