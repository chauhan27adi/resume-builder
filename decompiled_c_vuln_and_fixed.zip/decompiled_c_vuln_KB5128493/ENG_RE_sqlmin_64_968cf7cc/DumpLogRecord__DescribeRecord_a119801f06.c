
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,longlong param_2,longlong param_3,short *param_4,uint param_5)

{
  byte bVar1;
  undefined2 uVar2;
  uint uVar3;
  char cVar4;
  byte bVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 uVar9;
  int iVar10;
  longlong lVar11;
  longlong lVar12;
  byte *pbVar13;
  undefined8 uVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  undefined4 *puVar18;
  ushort *puVar19;
  int *piVar20;
  short sVar21;
  short *psVar22;
  code *UNRECOVERED_JUMPTABLE_00;
  ulonglong uVar23;
  longlong lVar24;
  ulonglong uVar25;
  longlong lVar26;
  undefined *puVar27;
  longlong lVar28;
  longlong lVar29;
  undefined *puVar30;
  ushort uVar31;
  undefined *puVar32;
  ushort uVar33;
  undefined8 uVar34;
  longlong lVar35;
  short *psVar36;
  longlong lVar37;
  uint uVar38;
  undefined8 extraout_XMM0_Qa;
  undefined8 extraout_XMM0_Qa_00;
  undefined8 uVar39;
  undefined8 extraout_XMM0_Qa_01;
  undefined8 extraout_XMM0_Qa_02;
  undefined8 extraout_XMM0_Qa_03;
  undefined8 extraout_XMM0_Qa_04;
  undefined8 extraout_XMM0_Qa_05;
  undefined8 extraout_XMM0_Qa_06;
  undefined8 extraout_XMM0_Qa_07;
  undefined8 extraout_XMM0_Qa_08;
  undefined8 extraout_XMM0_Qa_09;
  undefined8 extraout_XMM0_Qa_10;
  undefined8 extraout_XMM0_Qa_11;
  undefined8 extraout_XMM0_Qa_12;
  undefined8 extraout_XMM0_Qa_13;
  undefined8 extraout_XMM0_Qa_14;
  undefined8 extraout_XMM0_Qa_15;
  undefined8 extraout_XMM0_Qa_16;
  undefined8 extraout_XMM0_Qa_17;
  undefined8 extraout_XMM0_Qa_18;
  undefined8 extraout_XMM0_Qa_19;
  undefined8 extraout_XMM0_Qa_20;
  undefined8 extraout_XMM0_Qa_21;
  undefined8 extraout_XMM0_Qa_22;
  undefined8 extraout_XMM0_Qa_23;
  undefined8 extraout_XMM0_Qa_24;
  undefined8 extraout_XMM0_Qa_25;
  undefined8 extraout_XMM0_Qa_26;
  undefined8 extraout_XMM0_Qa_27;
  undefined8 extraout_XMM0_Qa_28;
  undefined8 extraout_XMM0_Qa_29;
  undefined8 extraout_XMM0_Qa_30;
  undefined8 extraout_XMM0_Qa_31;
  undefined8 extraout_XMM0_Qa_32;
  undefined8 extraout_XMM0_Qa_33;
  undefined8 extraout_XMM0_Qa_34;
  undefined8 extraout_XMM0_Qa_35;
  undefined8 extraout_XMM0_Qa_36;
  undefined8 extraout_XMM0_Qa_37;
  undefined8 extraout_XMM0_Qa_38;
  undefined8 extraout_XMM0_Qa_39;
  undefined8 extraout_XMM0_Qa_40;
  undefined8 extraout_XMM0_Qa_41;
  undefined8 extraout_XMM0_Qa_42;
  undefined8 extraout_XMM0_Qa_43;
  undefined8 extraout_XMM0_Qa_44;
  undefined8 extraout_XMM0_Qa_45;
  undefined8 extraout_XMM0_Qa_46;
  undefined8 extraout_XMM0_Qa_47;
  undefined8 extraout_XMM0_Qa_48;
  undefined8 extraout_XMM0_Qa_49;
  undefined8 extraout_XMM0_Qa_50;
  undefined8 extraout_XMM0_Qa_51;
  undefined8 extraout_XMM0_Qa_52;
  undefined8 extraout_XMM0_Qa_53;
  undefined8 extraout_XMM0_Qa_54;
  undefined8 extraout_XMM0_Qa_55;
  undefined8 extraout_XMM0_Qa_56;
  undefined8 extraout_XMM0_Qa_57;
  undefined8 extraout_XMM0_Qa_58;
  undefined8 extraout_XMM0_Qa_59;
  undefined8 extraout_XMM0_Qa_60;
  undefined8 extraout_XMM0_Qa_61;
  undefined8 extraout_XMM0_Qa_62;
  undefined8 extraout_XMM0_Qa_63;
  undefined8 extraout_XMM0_Qa_64;
  undefined8 extraout_XMM0_Qa_65;
  undefined8 extraout_XMM0_Qa_66;
  undefined8 extraout_XMM0_Qa_67;
  undefined8 extraout_XMM0_Qa_68;
  undefined8 extraout_XMM0_Qa_69;
  undefined8 extraout_XMM0_Qa_70;
  undefined8 extraout_XMM0_Qa_71;
  undefined8 extraout_XMM0_Qa_72;
  undefined8 extraout_XMM0_Qa_73;
  undefined8 extraout_XMM0_Qa_74;
  undefined8 extraout_XMM0_Qa_75;
  undefined8 extraout_XMM0_Qa_76;
  undefined8 extraout_XMM0_Qa_77;
  undefined8 extraout_XMM0_Qa_78;
  ulonglong uStackX_8;
  undefined4 auStackX_10 [4];
  int aiStackX_20 [2];
  longlong lStack_43b8;
  uint uStack_43a0;
  uint uStack_439c;
  undefined4 uStack_4398;
  undefined2 uStack_4394;
  uint uStack_4390;
  uint uStack_438c;
  undefined auStack_4388 [4];
  undefined4 uStack_4384;
  undefined4 uStack_4380;
  undefined4 uStack_437c;
  undefined auStack_4378 [4];
  undefined auStack_4374 [4];
  undefined auStack_4370 [4];
  uint uStack_436c;
  undefined8 uStack_4368;
  ushort uStack_4360;
  undefined4 uStack_4358;
  undefined2 uStack_4354;
  undefined auStack_4344 [4];
  uint uStack_4340;
  undefined auStack_433c [4];
  short *psStack_4338;
  undefined auStack_4330 [4];
  undefined auStack_432c [4];
  uint uStack_4328;
  undefined4 uStack_4324;
  uint uStack_4320;
  int iStack_431c;
  int iStack_4318;
  int iStack_4314;
  int iStack_4310;
  uint uStack_430c;
  longlong lStack_4308;
  undefined4 uStack_4300;
  undefined2 uStack_42fc;
  undefined2 uStack_42fa;
  uint auStack_42f8 [2];
  int iStack_42f0;
  undefined2 uStack_42ec;
  undefined auStack_42e8 [8];
  undefined8 uStack_42e0;
  short *psStack_42d8;
  undefined auStack_42c8 [92];
  undefined auStack_426c [4];
  undefined auStack_4268 [4];
  undefined auStack_4264 [4];
  undefined auStack_4260 [4];
  undefined auStack_425c [4];
  undefined auStack_4258 [4];
  undefined auStack_4254 [4];
  undefined auStack_4250 [4];
  undefined auStack_424c [4];
  undefined auStack_4248 [8];
  ulonglong uStack_4240;
  uint uStack_4238;
  int iStack_4234;
  ulonglong uStack_4230;
  uint uStack_4228;
  int iStack_4224;
  ulonglong uStack_4220;
  ulonglong uStack_4218;
  ulonglong uStack_4210;
  uint uStack_4208;
  int iStack_4204;
  ulonglong uStack_4200;
  uint uStack_41f8;
  int iStack_41f4;
  undefined4 uStack_41f0;
  int iStack_41ec;
  undefined4 uStack_41e8;
  undefined4 uStack_41dc;
  undefined4 uStack_41d8;
  undefined4 uStack_41d4;
  undefined4 uStack_41d0;
  undefined uStack_41cc;
  undefined auStack_41c0 [6];
  undefined auStack_41ba [6];
  undefined auStack_41b4 [6];
  undefined auStack_41ae [6];
  undefined auStack_41a8 [6];
  undefined auStack_41a2 [6];
  undefined auStack_419c [6];
  undefined auStack_4196 [14];
  undefined auStack_4188 [128];
  undefined8 uStack_4108;
  undefined auStack_3fc8 [192];
  undefined8 uStack_3f08;
  uint uStack_3f00;
  undefined4 uStack_3efc;
  undefined8 uStack_3ef8;
  undefined2 uStack_3ef0;
  undefined8 uStack_3eee;
  ushort uStack_3ee6;
  undefined8 uStack_3ee4;
  ushort uStack_3edc;
  undefined4 uStack_3eda;
  undefined2 uStack_3ed6;
  undefined4 uStack_3ed4;
  undefined8 uStack_3ed0;
  undefined8 uStack_3ec8;
  undefined8 uStack_3ec0;
  undefined8 uStack_3eb8;
  undefined auStack_3eb0 [1048];
  undefined8 uStack_3a98;
  undefined4 uStack_3a90;
  undefined4 uStack_3a8c;
  undefined8 uStack_3a88;
  undefined2 uStack_3a80;
  undefined auStack_3a7e [1046];
  short asStack_3668 [4];
  short sStack_3660;
  short sStack_365e;
  short sStack_365c;
  short sStack_365a;
  undefined2 uStack_3658;
  short sStack_3656;
  short sStack_3654;
  short sStack_3652;
  short sStack_3650;
  short sStack_364e;
  short sStack_364c;
  short sStack_364a;
  short sStack_3648;
  undefined2 uStack_3646;
  short sStack_3644;
  short sStack_3642;
  short sStack_3640;
  short sStack_363e;
  undefined2 uStack_363c;
  undefined auStack_3638 [32];
  short asStack_3618 [40];
  undefined auStack_35c8 [32];
  undefined auStack_35a8 [48];
  undefined auStack_3578 [32];
  short asStack_3558 [24];
  short asStack_3528 [24];
  short asStack_34f8 [32];
  short asStack_34b8 [72];
  short asStack_3428 [20];
  undefined auStack_3400 [32];
  undefined auStack_33e0 [32];
  undefined auStack_33c0 [32];
  undefined auStack_33a0 [32];
  undefined auStack_3380 [32];
  short asStack_3360 [24];
  undefined auStack_3330 [40];
  undefined auStack_3308 [40];
  undefined auStack_32e0 [48];
  undefined auStack_32b0 [48];
  undefined auStack_3280 [56];
  undefined auStack_3248 [208];
  undefined auStack_3178 [528];
  undefined auStack_2f68 [74];
  undefined auStack_2f1e [86];
  undefined auStack_2ec8 [816];
  undefined auStack_2b98 [256];
  undefined auStack_2a98 [256];
  undefined auStack_2998 [400];
  undefined auStack_2808 [208];
  undefined auStack_2738 [2048];
  undefined auStack_1f38 [256];
  short asStack_1e38 [200];
  short asStack_1ca8 [200];
  undefined auStack_1b18 [912];
  undefined auStack_1788 [400];
  undefined auStack_15f8 [736];
  undefined auStack_1318 [800];
  undefined auStack_ff8 [800];
  undefined auStack_cd8 [800];
  undefined auStack_9b8 [1200];
  undefined auStack_508 [1200];
  ulonglong uStack_58;
  undefined8 uStack_48;
  
  uStack_48 = 0x10001f;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  uStack_4108 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar11);
  lVar29 = 0;
  *param_4 = 0;
  *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 1;
  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10007b;
  uStack_4368 = param_2;
  psStack_4338 = param_4;
  psStack_42d8 = param_1;
  iVar6 = func_0x(param_3,auStack_42e8);
  lVar12 = -1;
  uVar39 = extraout_XMM0_Qa;
  uVar38 = param_5;
  lStack_43b8 = param_3;
  if (iVar6 != 0) {
    uStack_41cc = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1000a9;
    (*_DAT_)(auStack_42e8,&uStack_41f0);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1000bd;
    (*_DAT_)(auStack_42e8,&uStack_41f0);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1000cb;
    (*_DAT_)();
    *(undefined4 *)((longlong)auStackX_10 + lVar11) = uStack_41d0;
    *(undefined4 *)((longlong)&uStackX_8 + lVar11) = uStack_41d4;
    *(undefined4 *)((longlong)aiStackX_20 + lVar11 + -0x20) = uStack_41d8;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar11) = uStack_41dc;
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = uStack_41e8;
    *(int *)(&stack0xffffffffffffffe8 + lVar11) = iStack_41ec + 1;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = uStack_41f0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100124;
    iVar6 = func_0x(asStack_3360,0x18,0xdafa10);
    uVar39 = extraout_XMM0_Qa_00;
    if (iVar6 < 0) {
      *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0xc4f;
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100154;
      uVar39 = (*_DAT_)(4,7,0x10);
    }
    uVar38 = param_5;
    if (param_5 != 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10017b;
      iVar6 = func_0x(param_4,0x100,asStack_3360);
      uVar39 = extraout_XMM0_Qa_01;
      if (-1 < iVar6) {
        do {
          lVar12 = lVar12 + 1;
        } while (asStack_3360[lVar12] != 0);
        uVar38 = uVar38 - (int)lVar12;
        param_5 = uVar38;
        *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
      }
    }
  }
  if (((*(byte *)(param_3 + 0xe) & 4) != 0) && (uVar38 != 0)) {
    if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
      lVar12 = 0x100;
      psVar36 = param_4;
      do {
        if (*psVar36 == 0) break;
        psVar36 = psVar36 + 1;
        lVar12 = lVar12 + -1;
      } while (lVar12 != 0);
      if (lVar12 != 0) {
        lVar35 = 1;
        psVar36 = (short *)0xc284a0;
        lVar28 = lVar12 + -0x100;
        if (lVar12 == 0) {
          lVar28 = lVar29;
        }
        lVar24 = (0x100 - lVar12) * 2;
        if (lVar12 == 0) {
          lVar24 = lVar29;
        }
        psVar22 = (short *)(lVar24 + (longlong)param_4);
        lVar28 = lVar28 + 0x100;
        for (; ((lVar28 != 0 && (lVar35 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
          *psVar22 = *psVar36;
          psVar22 = psVar22 + 1;
          lVar35 = lVar35 + -1;
          lVar28 = lVar28 + -1;
        }
        psVar36 = psVar22 + -1;
        if (lVar28 != 0) {
          psVar36 = psVar22;
        }
        *psVar36 = 0;
        if (lVar28 != 0) {
          uVar38 = uVar38 - 1;
          param_5 = uVar38;
          goto LAB_;
        }
      }
    }
    else {
LAB_:
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100277;
      iVar6 = func_0x(param_4,0x100,0xdb18d8);
      uVar39 = extraout_XMM0_Qa_02;
      if (-1 < iVar6) {
        uVar38 = uVar38 - 9;
        param_5 = uVar38;
        *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
      }
    }
  }
  if (((*(byte *)(param_3 + 0xe) & 1) != 0) && (uVar38 != 0)) {
    if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
      lVar12 = 0x100;
      psVar36 = param_4;
      do {
        if (*psVar36 == 0) break;
        psVar36 = psVar36 + 1;
        lVar12 = lVar12 + -1;
      } while (lVar12 != 0);
      if (lVar12 != 0) {
        lVar35 = 1;
        psVar36 = (short *)0xc284a0;
        lVar28 = lVar12 + -0x100;
        if (lVar12 == 0) {
          lVar28 = lVar29;
        }
        lVar24 = (0x100 - lVar12) * 2;
        if (lVar12 == 0) {
          lVar24 = lVar29;
        }
        psVar22 = (short *)(lVar24 + (longlong)param_4);
        lVar28 = lVar28 + 0x100;
        for (; ((lVar28 != 0 && (lVar35 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
          *psVar22 = *psVar36;
          psVar22 = psVar22 + 1;
          lVar35 = lVar35 + -1;
          lVar28 = lVar28 + -1;
        }
        psVar36 = psVar22 + -1;
        if (lVar28 != 0) {
          psVar36 = psVar22;
        }
        *psVar36 = 0;
        if (lVar28 != 0) {
          uVar38 = uVar38 - 1;
          param_5 = uVar38;
          goto LAB_;
        }
      }
    }
    else {
LAB_:
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100347;
      iVar6 = func_0x(param_4,0x100,0xdb18f0);
      uVar39 = extraout_XMM0_Qa_03;
      if (-1 < iVar6) {
        uVar38 = uVar38 - 0xc;
        param_5 = uVar38;
        *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
      }
    }
  }
  if ((*(char *)(param_3 + 0x16) == '\x05') &&
     (uVar7 = *(ushort *)(param_3 + 0x38) - 1, uVar7 < 0x3a)) {
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)uVar7 + 0x1099fc) * 4 + 0x1099c4) -
                 0x1a77ca0);
                    /* WARNING: Could not emulate address calculation at 0x0010037e */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((*(char *)(param_3 + 0x16) == '\x10') && (1 < *(ushort *)(param_3 + 0x3e))) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x100528;
    pbVar13 = (byte *)func_0x(param_3 + 0x3e,0,auStack_4388);
    if ((*pbVar13 & 1) != 0) {
      uVar23 = (ulonglong)*(byte *)((longlong)(int)(*pbVar13 & 0x1c) + 0x109a48);
      UNRECOVERED_JUMPTABLE_00 = (code *)((ulonglong)*(uint *)(uVar23 * 4 + 0x109a38) - 0x1a77ca0);
                    /* WARNING: Could not emulate address calculation at 0x00100557 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(uVar23,UNRECOVERED_JUMPTABLE_00);
      return;
    }
                    /* WARNING: Could not emulate address calculation at 0x001006b5 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar13 & 0xe) * 4 + 0x109a68) - 0x1a77ca0))
              ((longlong)(int)(*pbVar13 & 0xe),0xfffffffffe588360,pbVar13);
    return;
  }
  if (*(char *)(param_3 + 0x16) == -0x80) {
    if (*(short *)(param_3 + 0x4c) != 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102979;
      uVar14 = func_0x(param_3 + 0x4c,0,&uStack_4328);
      uVar39 = extraout_XMM0_Qa_04;
      if (uVar38 != 0) {
        if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
          lVar12 = 0x100;
          psVar36 = param_4;
          do {
            if (*psVar36 == 0) break;
            psVar36 = psVar36 + 1;
            lVar12 = lVar12 + -1;
          } while (lVar12 != 0);
          if (lVar12 != 0) {
            lVar35 = 1;
            psVar36 = (short *)0xc284a0;
            lVar29 = lVar12 + -0x100;
            if (lVar12 == 0) {
              lVar29 = 0;
            }
            lVar28 = (0x100 - lVar12) * 2;
            if (lVar12 == 0) {
              lVar28 = 0;
            }
            psVar22 = (short *)(lVar28 + (longlong)param_4);
            lVar29 = lVar29 + 0x100;
            for (; ((lVar29 != 0 && (lVar35 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
              *psVar22 = *psVar36;
              psVar22 = psVar22 + 1;
              lVar35 = lVar35 + -1;
              lVar29 = lVar29 + -1;
            }
            psVar36 = psVar22 + -1;
            if (lVar29 != 0) {
              psVar36 = psVar22;
            }
            *psVar36 = 0;
            if (lVar29 != 0) {
              uVar38 = uVar38 - 1;
              param_5 = uVar38;
              goto LAB_;
            }
          }
        }
        else {
LAB_:
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102a47;
          iVar6 = func_0x(param_4,0x100,uVar14,uStack_4328 >> 1);
          uVar39 = extraout_XMM0_Qa_05;
          if (-1 < iVar6) {
            uVar38 = uVar38 - (uStack_4328 >> 1);
            param_5 = uVar38;
            *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
          }
        }
      }
    }
    if (1 < *(ushort *)(param_3 + 0x4c)) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102a7a;
      uVar39 = func_0x(param_3 + 0x4c,1,&uStack_4324);
      *(longlong *)(&stack0xfffffffffffffff0 + lVar11) = (longlong)aiStackX_20 + lVar11;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 1;
      *(uint **)(&stack0xffffffffffffffe0 + lVar11) = &param_5;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102aa6;
      uVar39 = func_0x(&param_5,param_4,uVar39,uStack_4324);
      uVar38 = param_5;
    }
  }
  if (*(char *)(param_3 + 0x16) == -0x7f) {
    uVar9 = *(undefined4 *)(psStack_42d8 + 10);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102ac8;
    (*_DAT_)(uVar9);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102add;
    lVar12 = func_0x(param_3 + 0x50,3,&uStack_4320);
    uVar39 = extraout_XMM0_Qa_06;
    if (((lVar12 != 0) && (uStack_4320 != 0)) && (uVar38 != 0)) {
      if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
        lVar29 = 0x100;
        psVar36 = param_4;
        do {
          if (*psVar36 == 0) break;
          psVar36 = psVar36 + 1;
          lVar29 = lVar29 + -1;
        } while (lVar29 != 0);
        if (lVar29 != 0) {
          lVar28 = 1;
          psVar36 = (short *)0xc284a0;
          lVar35 = lVar29 + -0x100;
          if (lVar29 == 0) {
            lVar35 = 0;
          }
          lVar24 = (0x100 - lVar29) * 2;
          if (lVar29 == 0) {
            lVar24 = 0;
          }
          psVar22 = (short *)(lVar24 + (longlong)param_4);
          lVar35 = lVar35 + 0x100;
          for (; ((lVar35 != 0 && (lVar28 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
            *psVar22 = *psVar36;
            psVar22 = psVar22 + 1;
            lVar28 = lVar28 + -1;
            lVar35 = lVar35 + -1;
          }
          psVar36 = psVar22 + -1;
          if (lVar35 != 0) {
            psVar36 = psVar22;
          }
          *psVar36 = 0;
          if (lVar35 != 0) {
            uVar38 = uVar38 - 1;
            param_5 = uVar38;
            goto LAB_;
          }
        }
      }
      else {
LAB_:
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102bb9;
        iVar6 = func_0x(param_4,0x100,lVar12,uStack_4320 >> 1);
        uVar39 = extraout_XMM0_Qa_07;
        if (-1 < iVar6) {
          uVar38 = uVar38 - (uStack_4320 >> 1);
          param_5 = uVar38;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
      }
    }
  }
  if (*(char *)(param_3 + 0x16) == '}') {
    uVar25 = 0;
    uStack_43a0 = 0;
    param_3 = param_3 + 0x38;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102bf4;
    lStack_4308 = param_3;
    uVar15 = func_0x(param_3,0,&uStack_43a0);
    uVar7 = uStack_43a0;
    uVar23 = uVar25;
    if (uStack_43a0 != 0) {
      uVar23 = uVar15;
    }
    uStack_4390 = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102c14;
    uVar15 = func_0x(param_3,2,&uStack_4390);
    uStack_4220 = uVar25;
    if (uStack_4390 != 0) {
      uStack_4220 = uVar15;
    }
    uStack_438c = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102c36;
    uVar15 = func_0x(param_3,1,&uStack_438c);
    uStack_4218 = uVar25;
    if (uStack_438c != 0) {
      uStack_4218 = uVar15;
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102c4c;
    uVar39 = (*_DAT_)();
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined4 *)(lStack_43b8 + 0x30);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102c70;
    iVar6 = func_0x(asStack_34b8,0x46,0xdb1860,uVar39);
    uVar39 = extraout_XMM0_Qa_08;
    if (iVar6 < 0) {
      *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0x1f96;
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102ca3;
      uVar39 = (*_DAT_)(4,7,0x10,1);
      uVar38 = param_5;
      uVar7 = uStack_43a0;
    }
    if (uVar38 != 0) {
      if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
        lVar12 = 0x100;
        psVar36 = param_4;
        do {
          if (*psVar36 == 0) break;
          psVar36 = psVar36 + 1;
          lVar12 = lVar12 + -1;
        } while (lVar12 != 0);
        if (lVar12 != 0) {
          lVar29 = 1;
          psVar36 = (short *)0xc284a0;
          uVar15 = lVar12 - 0x100;
          if (lVar12 == 0) {
            uVar15 = uVar25;
          }
          uVar16 = (0x100 - lVar12) * 2;
          if (lVar12 == 0) {
            uVar16 = uVar25;
          }
          psVar22 = (short *)(uVar16 + (longlong)param_4);
          lVar12 = uVar15 + 0x100;
          for (; ((lVar12 != 0 && (lVar29 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
            *psVar22 = *psVar36;
            psVar22 = psVar22 + 1;
            lVar29 = lVar29 + -1;
            lVar12 = lVar12 + -1;
          }
          psVar36 = psVar22 + -1;
          if (lVar12 != 0) {
            psVar36 = psVar22;
          }
          *psVar36 = 0;
          if (lVar12 != 0) {
            uVar38 = uVar38 - 1;
            param_5 = uVar38;
            goto LAB_;
          }
        }
      }
      else {
LAB_:
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102d70;
        iVar6 = func_0x(param_4,0x100,asStack_34b8);
        uVar39 = extraout_XMM0_Qa_09;
        if (-1 < iVar6) {
          lVar12 = -1;
          do {
            lVar12 = lVar12 + 1;
          } while (asStack_34b8[lVar12] != 0);
          uVar38 = uVar38 - (int)lVar12;
          param_5 = uVar38;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
      }
    }
    if (uVar23 != 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102db6;
      uVar16 = func_0x(param_3,2,&iStack_431c);
      uVar15 = uVar25;
      if (iStack_431c != 0) {
        uVar15 = uVar16;
      }
      if (uVar15 != 0) {
        iStack_4224 = iStack_431c * 8;
        uStack_4228 = iStack_4224 + 7U >> 3;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102df6;
        uStack_4230 = uVar15;
        uVar8 = func_0x(&uStack_4230);
        uVar25 = (ulonglong)uVar8;
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102e0c;
      uVar16 = func_0x(param_3,1);
      uVar17 = 0;
      uVar15 = uVar17;
      if (iStack_4318 != 0) {
        uVar15 = uVar16;
      }
      if (uVar15 != 0) {
        iStack_4204 = iStack_4318 * 8;
        uStack_4208 = iStack_4204 + 7U >> 3;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102e54;
        uStack_4210 = uVar15;
        uVar8 = func_0x(&uStack_4210);
        uVar17 = (ulonglong)uVar8;
      }
      uVar8 = *(uint *)(lStack_43b8 + 0x34);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102e65;
      uVar39 = (*_DAT_)();
      *(ulonglong *)(&stack0xffffffffffffffe0 + lVar11) = (uVar8 - uVar17) - uVar25;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102e85;
      iVar6 = func_0x(asStack_34b8,0x46,0xdb1878,uVar39);
      uVar39 = extraout_XMM0_Qa_10;
      if (iVar6 < 0) {
        *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0x1fa4;
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102ebc;
        uVar39 = (*_DAT_)(4,7,0x10,1);
        uVar38 = param_5;
        uVar7 = uStack_43a0;
      }
      if (uVar38 != 0) {
        if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
          lVar12 = 0x100;
          psVar36 = param_4;
          do {
            if (*psVar36 == 0) break;
            psVar36 = psVar36 + 1;
            lVar12 = lVar12 + -1;
          } while (lVar12 != 0);
          if (lVar12 != 0) {
            lVar35 = 1;
            psVar36 = (short *)0xc284a0;
            lVar29 = lVar12 + -0x100;
            if (lVar12 == 0) {
              lVar29 = 0;
            }
            lVar28 = (0x100 - lVar12) * 2;
            if (lVar12 == 0) {
              lVar28 = 0;
            }
            psVar22 = (short *)(lVar28 + (longlong)param_4);
            lVar29 = lVar29 + 0x100;
            for (; ((lVar29 != 0 && (lVar35 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
              *psVar22 = *psVar36;
              psVar22 = psVar22 + 1;
              lVar35 = lVar35 + -1;
              lVar29 = lVar29 + -1;
            }
            psVar36 = psVar22 + -1;
            if (lVar29 != 0) {
              psVar36 = psVar22;
            }
            *psVar36 = 0;
            if (lVar29 != 0) {
              uVar38 = uVar38 - 1;
              param_5 = uVar38;
              goto LAB_;
            }
          }
        }
        else {
LAB_:
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x102f95;
          iVar6 = func_0x(param_4,0x100,asStack_34b8);
          uVar39 = extraout_XMM0_Qa_11;
          if (-1 < iVar6) {
            lVar12 = -1;
            do {
              lVar12 = lVar12 + 1;
            } while (asStack_34b8[lVar12] != 0);
            uVar38 = uVar38 - (int)lVar12;
            param_5 = uVar38;
            *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
          }
        }
      }
      uVar8 = 0;
      param_3 = lStack_4308;
      if (uVar7 != 0) {
        do {
          uVar7 = uVar8 * 8;
          lVar12 = 8;
          do {
            if ((*(byte *)((uVar7 >> 3) + uVar23) >> ((byte)uVar7 & 7) & 1) == 0) {
              if (uVar38 != 0) {
                uVar39 = 0xc20324;
                goto LAB_;
              }
            }
            else if (uVar38 != 0) {
              uVar39 = 0xc1fa94;
LAB_:
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10302f;
              iVar6 = func_0x(param_4,0x100,uVar39);
              uVar39 = extraout_XMM0_Qa_12;
              if (-1 < iVar6) {
                uVar38 = uVar38 - 1;
                *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
                param_5 = uVar38;
              }
            }
            uVar3 = uStack_43a0;
            uVar7 = uVar7 + 1;
            lVar12 = lVar12 + -1;
          } while (lVar12 != 0);
          if (uVar38 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103067;
            iVar6 = func_0x(param_4,0x100,0xc27d74);
            uVar39 = extraout_XMM0_Qa_13;
            if (-1 < iVar6) {
              uVar38 = uVar38 - 1;
              param_5 = uVar38;
              *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
            }
          }
          uVar8 = uVar8 + 1;
          param_3 = lStack_4308;
        } while (uVar8 < uVar3);
      }
    }
    uVar23 = uStack_4220;
    uVar15 = 0;
    if (uStack_4220 != 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1030b3;
      uVar16 = func_0x(param_3,2,&iStack_4314);
      uVar25 = uVar15;
      if (iStack_4314 != 0) {
        uVar25 = uVar16;
      }
      uVar16 = uVar15;
      if (uVar25 != 0) {
        iStack_41f4 = iStack_4314 * 8;
        uStack_41f8 = iStack_41f4 + 7U >> 3;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1030f8;
        uStack_4200 = uVar25;
        uVar7 = func_0x(&uStack_4200);
        uVar16 = (ulonglong)uVar7;
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103100;
      uVar39 = (*_DAT_)();
      *(ulonglong *)(&stack0xffffffffffffffe0 + lVar11) = uVar16;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103120;
      iVar6 = func_0x(asStack_34b8,0x46,0xdb1730,uVar39);
      if (iVar6 < 0) {
        *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0x1fcd;
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103157;
        (*_DAT_)(4,7,0x10,1);
        uVar38 = param_5;
      }
      if (uVar38 != 0) {
        if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
          lVar12 = 0x100;
          psVar36 = param_4;
          do {
            if (*psVar36 == 0) break;
            psVar36 = psVar36 + 1;
            lVar12 = lVar12 + -1;
          } while (lVar12 != 0);
          if (lVar12 != 0) {
            lVar29 = 1;
            psVar36 = (short *)0xc284a0;
            uVar25 = lVar12 - 0x100;
            if (lVar12 == 0) {
              uVar25 = uVar15;
            }
            uVar16 = (0x100 - lVar12) * 2;
            if (lVar12 == 0) {
              uVar16 = uVar15;
            }
            psVar22 = (short *)(uVar16 + (longlong)param_4);
            lVar12 = uVar25 + 0x100;
            for (; ((lVar12 != 0 && (lVar29 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
              *psVar22 = *psVar36;
              psVar22 = psVar22 + 1;
              lVar29 = lVar29 + -1;
              lVar12 = lVar12 + -1;
            }
            psVar36 = psVar22 + -1;
            if (lVar12 != 0) {
              psVar36 = psVar22;
            }
            *psVar36 = 0;
            if (lVar12 != 0) {
              uVar38 = uVar38 - 1;
              param_5 = uVar38;
              goto LAB_;
            }
          }
        }
        else {
LAB_:
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103220;
          iVar6 = func_0x(param_4,0x100,asStack_34b8);
          if (-1 < iVar6) {
            lVar12 = -1;
            do {
              lVar12 = lVar12 + 1;
            } while (asStack_34b8[lVar12] != 0);
            uVar38 = uVar38 - (int)lVar12;
            param_5 = uVar38;
            *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
          }
        }
      }
      uVar7 = 0;
      if (uStack_4390 != 0) {
        do {
          uVar8 = uVar7 * 8;
          lVar12 = 8;
          do {
            if ((*(byte *)((uVar8 >> 3) + uVar23) >> ((byte)uVar8 & 7) & 1) == 0) {
              if (uVar38 != 0) {
                uVar39 = 0xc20324;
                goto LAB_;
              }
            }
            else if (uVar38 != 0) {
              uVar39 = 0xc1fa94;
LAB_:
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1032af;
              iVar6 = func_0x(param_4,0x100,uVar39);
              if (-1 < iVar6) {
                uVar38 = uVar38 - 1;
                *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
                param_5 = uVar38;
              }
            }
            uVar3 = uStack_4390;
            uVar8 = uVar8 + 1;
            lVar12 = lVar12 + -1;
          } while (lVar12 != 0);
          if (uVar38 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1032e7;
            iVar6 = func_0x(param_4,0x100,0xc27d74);
            if (-1 < iVar6) {
              uVar38 = uVar38 - 1;
              param_5 = uVar38;
              *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
            }
          }
          uVar7 = uVar7 + 1;
        } while (uVar7 < uVar3);
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103314;
      lVar12 = func_0x(lStack_43b8);
      uVar39 = extraout_XMM0_Qa_14;
      if (lVar12 != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103325;
        uVar9 = func_0x(lStack_43b8);
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10332e;
        uVar39 = (*_DAT_)();
        *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = uVar9;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10334d;
        iVar6 = func_0x(asStack_34b8,0x46,0xdb1760,uVar39);
        uVar39 = extraout_XMM0_Qa_15;
        if (iVar6 < 0) {
          *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
          *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0x1ff7;
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103384;
          uVar39 = (*_DAT_)(4,7,0x10,1);
          uVar38 = param_5;
        }
        if (uVar38 != 0) {
          if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
            lVar12 = 0x100;
            psVar36 = param_4;
            do {
              if (*psVar36 == 0) break;
              psVar36 = psVar36 + 1;
              lVar12 = lVar12 + -1;
            } while (lVar12 != 0);
            if (lVar12 != 0) {
              lVar29 = 1;
              psVar36 = (short *)0xc284a0;
              lVar35 = lVar12 + -0x100;
              if (lVar12 == 0) {
                lVar35 = 0;
              }
              lVar28 = (0x100 - lVar12) * 2;
              if (lVar12 == 0) {
                lVar28 = 0;
              }
              psVar22 = (short *)(lVar28 + (longlong)param_4);
              lVar35 = lVar35 + 0x100;
              for (; ((lVar35 != 0 && (lVar29 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
                *psVar22 = *psVar36;
                psVar22 = psVar22 + 1;
                lVar29 = lVar29 + -1;
                lVar35 = lVar35 + -1;
              }
              psVar36 = psVar22 + -1;
              if (lVar35 != 0) {
                psVar36 = psVar22;
              }
              *psVar36 = 0;
              if (lVar35 != 0) {
                uVar38 = uVar38 - 1;
                param_5 = uVar38;
                goto LAB_;
              }
            }
          }
          else {
LAB_:
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103450;
            iVar6 = func_0x(param_4,0x100,asStack_34b8);
            uVar39 = extraout_XMM0_Qa_16;
            if (-1 < iVar6) {
              lVar12 = -1;
              do {
                lVar12 = lVar12 + 1;
              } while (asStack_34b8[lVar12] != 0);
              uVar38 = uVar38 - (int)lVar12;
              param_5 = uVar38;
              *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
            }
          }
        }
      }
    }
    uVar23 = uStack_4218;
    uVar15 = 0;
    param_3 = lStack_43b8;
    if (uStack_4218 != 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1034b0;
      uVar16 = func_0x(lStack_4308,1,&iStack_4310);
      uVar25 = uVar15;
      if (iStack_4310 != 0) {
        uVar25 = uVar16;
      }
      uVar16 = uVar15;
      if (uVar25 != 0) {
        iStack_4234 = iStack_4310 * 8;
        uStack_4238 = iStack_4234 + 7U >> 3;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1034f5;
        uStack_4240 = uVar25;
        uVar7 = func_0x(&uStack_4240);
        uVar16 = (ulonglong)uVar7;
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1034fd;
      uVar39 = (*_DAT_)();
      *(ulonglong *)(&stack0xffffffffffffffe0 + lVar11) = uVar16;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10351d;
      iVar6 = func_0x(asStack_34b8,0x46,0xdb1798,uVar39);
      uVar39 = extraout_XMM0_Qa_17;
      if (iVar6 < 0) {
        *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0x2006;
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103551;
        uVar39 = (*_DAT_)(4,7,0x10,1);
        uVar38 = param_5;
      }
      if (uVar38 != 0) {
        if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
          lVar12 = 0x100;
          psVar36 = param_4;
          do {
            if (*psVar36 == 0) break;
            psVar36 = psVar36 + 1;
            lVar12 = lVar12 + -1;
          } while (lVar12 != 0);
          if (lVar12 != 0) {
            lVar29 = 1;
            psVar36 = (short *)0xc284a0;
            uVar25 = lVar12 - 0x100;
            if (lVar12 == 0) {
              uVar25 = uVar15;
            }
            uVar16 = (0x100 - lVar12) * 2;
            if (lVar12 == 0) {
              uVar16 = uVar15;
            }
            psVar22 = (short *)(uVar16 + (longlong)param_4);
            lVar12 = uVar25 + 0x100;
            for (; ((lVar12 != 0 && (lVar29 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
              *psVar22 = *psVar36;
              psVar22 = psVar22 + 1;
              lVar29 = lVar29 + -1;
              lVar12 = lVar12 + -1;
            }
            psVar36 = psVar22 + -1;
            if (lVar12 != 0) {
              psVar36 = psVar22;
            }
            *psVar36 = 0;
            if (lVar12 != 0) {
              uVar38 = uVar38 - 1;
              param_5 = uVar38;
              goto LAB_;
            }
          }
        }
        else {
LAB_:
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10360f;
          iVar6 = func_0x(param_4,0x100,asStack_34b8);
          uVar39 = extraout_XMM0_Qa_18;
          if (-1 < iVar6) {
            lVar12 = -1;
            do {
              lVar12 = lVar12 + 1;
            } while (asStack_34b8[lVar12] != 0);
            uVar38 = uVar38 - (int)lVar12;
            param_5 = uVar38;
            *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
          }
        }
      }
      uStack_439c = 0;
      if (uStack_438c != 0) {
        do {
          uVar7 = uStack_439c * 8;
          lVar12 = 8;
          do {
            if ((*(byte *)((uVar7 >> 3) + uVar23) >> ((byte)uVar7 & 7) & 1) == 0) {
              if (uVar38 != 0) {
                uVar39 = 0xc20324;
                goto LAB_;
              }
            }
            else if (uVar38 != 0) {
              uVar39 = 0xc1fa94;
LAB_:
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10369f;
              iVar6 = func_0x(param_4,0x100,uVar39);
              uVar39 = extraout_XMM0_Qa_19;
              if (-1 < iVar6) {
                uVar38 = uVar38 - 1;
                *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
                param_5 = uVar38;
              }
            }
            uVar8 = uStack_439c;
            uVar7 = uVar7 + 1;
            lVar12 = lVar12 + -1;
          } while (lVar12 != 0);
          if (uVar38 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1036d5;
            iVar6 = func_0x(param_4,0x100,0xc27d74);
            uVar39 = extraout_XMM0_Qa_20;
            if (-1 < iVar6) {
              uVar38 = uVar38 - 1;
              param_5 = uVar38;
              *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
            }
          }
          uStack_439c = uVar8 + 1;
        } while (uStack_439c < uStack_438c);
      }
    }
  }
  lVar12 = -1;
  if ((byte)(*(char *)(param_3 + 0x16) + 0x7aU) < 2) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10371c;
    lVar35 = func_0x(param_3 + 0x1c,0,auStack_426c);
    lVar29 = lVar12;
    do {
      lVar29 = lVar29 + 1;
    } while (*(short *)(lVar35 + 0x210 + lVar29 * 2) != 0);
    uVar39 = extraout_XMM0_Qa_21;
    if (uVar38 != 0) {
      if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
        lVar28 = 0x100;
        psVar36 = param_4;
        do {
          if (*psVar36 == 0) break;
          psVar36 = psVar36 + 1;
          lVar28 = lVar28 + -1;
        } while (lVar28 != 0);
        if (lVar28 != 0) {
          lVar37 = 1;
          psVar36 = (short *)0xc284a0;
          lVar24 = lVar28 + -0x100;
          if (lVar28 == 0) {
            lVar24 = 0;
          }
          lVar26 = (0x100 - lVar28) * 2;
          if (lVar28 == 0) {
            lVar26 = 0;
          }
          psVar22 = (short *)(lVar26 + (longlong)param_4);
          lVar24 = lVar24 + 0x100;
          for (; ((lVar24 != 0 && (lVar37 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
            *psVar22 = *psVar36;
            psVar22 = psVar22 + 1;
            lVar37 = lVar37 + -1;
            lVar24 = lVar24 + -1;
          }
          psVar36 = psVar22 + -1;
          if (lVar24 != 0) {
            psVar36 = psVar22;
          }
          *psVar36 = 0;
          if (lVar24 != 0) {
            uVar38 = uVar38 - 1;
            param_5 = uVar38;
            goto LAB_;
          }
        }
      }
      else {
LAB_:
        iVar10 = (int)lVar29;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103803;
        iVar6 = func_0x(param_4,0x100,lVar35 + 0x210);
        uVar39 = extraout_XMM0_Qa_22;
        if (-1 < iVar6) {
          uVar38 = uVar38 - iVar10;
          param_5 = uVar38;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
      }
    }
  }
  if (*(char *)(param_3 + 0x16) == -0xd) {
    uVar33 = *(ushort *)(param_3 + 0x18);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10382b;
    uVar39 = (*_DAT_)();
    *(uint *)(&stack0xffffffffffffffe0 + lVar11) = (uint)uVar33;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10384a;
    iVar6 = func_0x(asStack_3428,0x14,0xdb17d0,uVar39);
    uVar39 = extraout_XMM0_Qa_23;
    if (iVar6 < 0) {
      *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0x2050;
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103881;
      uVar39 = (*_DAT_)(4,7,0x10,1);
      uVar38 = param_5;
    }
    if (uVar38 != 0) {
      if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
        lVar29 = 0x100;
        psVar36 = param_4;
        do {
          if (*psVar36 == 0) break;
          psVar36 = psVar36 + 1;
          lVar29 = lVar29 + -1;
        } while (lVar29 != 0);
        if (lVar29 != 0) {
          lVar28 = 1;
          psVar36 = (short *)0xc284a0;
          lVar35 = lVar29 + -0x100;
          if (lVar29 == 0) {
            lVar35 = 0;
          }
          lVar24 = (0x100 - lVar29) * 2;
          if (lVar29 == 0) {
            lVar24 = 0;
          }
          psVar22 = (short *)(lVar24 + (longlong)param_4);
          lVar35 = lVar35 + 0x100;
          for (; ((lVar35 != 0 && (lVar28 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
            *psVar22 = *psVar36;
            psVar22 = psVar22 + 1;
            lVar28 = lVar28 + -1;
            lVar35 = lVar35 + -1;
          }
          psVar36 = psVar22 + -1;
          if (lVar35 != 0) {
            psVar36 = psVar22;
          }
          *psVar36 = 0;
          if (lVar35 != 0) {
            uVar38 = uVar38 - 1;
            param_5 = uVar38;
            goto LAB_;
          }
        }
      }
      else {
LAB_:
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103955;
        iVar6 = func_0x(param_4,0x100,asStack_3428);
        uVar39 = extraout_XMM0_Qa_24;
        if (-1 < iVar6) {
          do {
            lVar12 = lVar12 + 1;
          } while (asStack_3428[lVar12] != 0);
          uVar38 = uVar38 - (int)lVar12;
          param_5 = uVar38;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
      }
    }
  }
  if (*(char *)(param_3 + 0x16) == -0x77) {
    uVar23 = *(ulonglong *)(param_3 + 0x18);
    uVar33 = *(ushort *)(param_3 + 0x20);
    if (uVar33 == 1) {
      uVar39 = 0xdb1660;
    }
    else if (uVar33 == 2) {
      uVar39 = 0xdb1678;
    }
    else if (uVar33 == 3) {
      uVar39 = 0xdb1690;
    }
    else {
      uVar39 = 0xb13700;
    }
    uVar31 = *(ushort *)(lStack_43b8 + 0x22);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1039ef;
    uVar14 = (*_DAT_)();
    *(ulonglong *)((longlong)&uStackX_8 + lVar11) =
         ((uVar23 >> 0x20 & 0xffff) << 0x20 | uVar23 & 0xffffffff) << 0x10 | (ulonglong)uVar31;
    *(uint *)((longlong)aiStackX_20 + lVar11 + -0x20) = (uint)uVar31;
    *(uint *)(&stack0xfffffffffffffff8 + lVar11) = (uint)(uVar23 >> 0x20) & 0xffff;
    *(int *)(&stack0xfffffffffffffff0 + lVar11) = (int)uVar23;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = uVar39;
    *(uint *)(&stack0xffffffffffffffe0 + lVar11) = (uint)uVar33;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103a26;
    iVar6 = func_0x(asStack_1e38,200,0xdb16b0,uVar14);
    uVar39 = extraout_XMM0_Qa_25;
    if (iVar6 < 0) {
      *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0x207d;
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103a5d;
      uVar39 = (*_DAT_)(4,7,0x10,1);
      uVar38 = param_5;
    }
    param_4 = psStack_4338;
    param_3 = lStack_43b8;
    if (uVar38 != 0) {
      if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
        lVar12 = 0x100;
        psVar36 = psStack_4338;
        do {
          if (*psVar36 == 0) break;
          psVar36 = psVar36 + 1;
          lVar12 = lVar12 + -1;
        } while (lVar12 != 0);
        if (lVar12 != 0) {
          lVar35 = 1;
          psVar36 = (short *)0xc284a0;
          lVar29 = lVar12 + -0x100;
          if (lVar12 == 0) {
            lVar29 = 0;
          }
          lVar28 = (0x100 - lVar12) * 2;
          if (lVar12 == 0) {
            lVar28 = 0;
          }
          psVar22 = (short *)(lVar28 + (longlong)psStack_4338);
          lVar29 = lVar29 + 0x100;
          for (; ((lVar29 != 0 && (lVar35 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
            *psVar22 = *psVar36;
            psVar22 = psVar22 + 1;
            lVar35 = lVar35 + -1;
            lVar29 = lVar29 + -1;
          }
          psVar36 = psVar22 + -1;
          if (lVar29 != 0) {
            psVar36 = psVar22;
          }
          *psVar36 = 0;
          if (lVar29 != 0) {
            uVar38 = uVar38 - 1;
            param_5 = uVar38;
            goto LAB_;
          }
        }
      }
      else {
LAB_:
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103b35;
        iVar6 = func_0x(psStack_4338,0x100,asStack_1e38);
        uVar39 = extraout_XMM0_Qa_26;
        if (-1 < iVar6) {
          lVar12 = -1;
          do {
            lVar12 = lVar12 + 1;
          } while (asStack_1e38[lVar12] != 0);
          uVar38 = uVar38 - (int)lVar12;
          param_5 = uVar38;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
      }
    }
  }
  if (*(char *)(param_3 + 0x16) == -0x66) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103b9b;
    func_0x(param_3 + 0x18,asStack_3558,auStack_4268);
    if (uVar38 != 0) {
      if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
        lVar12 = 0x100;
        psVar36 = param_4;
        do {
          if (*psVar36 == 0) break;
          psVar36 = psVar36 + 1;
          lVar12 = lVar12 + -1;
        } while (lVar12 != 0);
        if (lVar12 != 0) {
          lVar35 = 1;
          psVar36 = (short *)0xc284a0;
          lVar29 = lVar12 + -0x100;
          if (lVar12 == 0) {
            lVar29 = 0;
          }
          lVar28 = (0x100 - lVar12) * 2;
          if (lVar12 == 0) {
            lVar28 = 0;
          }
          psVar22 = (short *)(lVar28 + (longlong)param_4);
          lVar29 = lVar29 + 0x100;
          for (; ((lVar29 != 0 && (lVar35 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
            *psVar22 = *psVar36;
            psVar22 = psVar22 + 1;
            lVar35 = lVar35 + -1;
            lVar29 = lVar29 + -1;
          }
          psVar36 = psVar22 + -1;
          if (lVar29 != 0) {
            psVar36 = psVar22;
          }
          *psVar36 = 0;
          if (lVar29 != 0) {
            uVar38 = uVar38 - 1;
            param_5 = uVar38;
            goto LAB_;
          }
        }
      }
      else {
LAB_:
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103c64;
        iVar6 = func_0x(param_4,0x100,0xdb0fe8);
        if (-1 < iVar6) {
          uVar38 = uVar38 - 10;
          param_5 = uVar38;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
      }
      if (uVar38 != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103c94;
        iVar6 = func_0x(param_4,0x100,asStack_3558);
        if (-1 < iVar6) {
          lVar12 = -1;
          do {
            lVar12 = lVar12 + 1;
          } while (asStack_3558[lVar12] != 0);
          uVar38 = uVar38 - (int)lVar12;
          param_5 = uVar38;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
        if (uVar38 != 0) {
          if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
            lVar12 = 0x100;
            psVar36 = param_4;
            do {
              if (*psVar36 == 0) break;
              psVar36 = psVar36 + 1;
              lVar12 = lVar12 + -1;
            } while (lVar12 != 0);
            if (lVar12 != 0) {
              lVar29 = 1;
              psVar36 = (short *)0xc284a0;
              lVar35 = lVar12 + -0x100;
              if (lVar12 == 0) {
                lVar35 = 0;
              }
              lVar28 = (0x100 - lVar12) * 2;
              if (lVar12 == 0) {
                lVar28 = 0;
              }
              psVar22 = (short *)(lVar28 + (longlong)param_4);
              lVar35 = lVar35 + 0x100;
              for (; ((lVar35 != 0 && (lVar29 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
                *psVar22 = *psVar36;
                psVar22 = psVar22 + 1;
                lVar29 = lVar29 + -1;
                lVar35 = lVar35 + -1;
              }
              psVar36 = psVar22 + -1;
              if (lVar35 != 0) {
                psVar36 = psVar22;
              }
              *psVar36 = 0;
              if (lVar35 != 0) {
                uVar38 = uVar38 - 1;
                param_5 = uVar38;
                goto LAB_;
              }
            }
          }
          else {
LAB_:
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103d80;
            iVar6 = func_0x(param_4,0x100,0xdb1000);
            if (-1 < iVar6) {
              uVar38 = uVar38 - 0xb;
              param_5 = uVar38;
              *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
            }
          }
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103da5;
    func_0x(param_3 + 0x22,0,&uStack_430c);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103dc5;
    uVar39 = (*_DAT_)();
    *(uint *)(&stack0xffffffffffffffe0 + lVar11) = uStack_430c / 6;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103de4;
    iVar6 = func_0x(asStack_3558,0x16,0xa766b8,uVar39);
    if (iVar6 < 0) {
      *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0x2097;
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103e19;
      (*_DAT_)(4,7,0x10,1);
      uVar38 = param_5;
    }
    if (uVar38 != 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103e39;
      iVar6 = func_0x(param_4,0x100,asStack_3558);
      if (-1 < iVar6) {
        lVar12 = -1;
        do {
          lVar12 = lVar12 + 1;
        } while (asStack_3558[lVar12] != 0);
        uVar38 = uVar38 - (int)lVar12;
        param_5 = uVar38;
        *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
      }
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103e80;
    uVar39 = func_0x(param_3 + 0x22,0,auStack_42f8);
    if (auStack_42f8[0] / 6 == 1) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103eb2;
      puVar18 = (undefined4 *)func_0x(param_3 + 0x22,0,auStack_4264);
      uVar9 = *puVar18;
      uVar33 = *(ushort *)(puVar18 + 1);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103ebe;
      uVar39 = (*_DAT_)();
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = uVar9;
      *(uint *)(&stack0xffffffffffffffe0 + lVar11) = (uint)uVar33;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103ee1;
      iVar6 = func_0x(asStack_34f8,0xe,0xdaf9f0,uVar39);
      uVar39 = extraout_XMM0_Qa_27;
      if (iVar6 < 0) {
        *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0xbff;
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103f18;
        uVar39 = (*_DAT_)(4,7,0x10,1);
        uVar38 = param_5;
      }
      if (uVar38 != 0) {
        if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
          lVar12 = 0x100;
          psVar36 = param_4;
          do {
            if (*psVar36 == 0) break;
            psVar36 = psVar36 + 1;
            lVar12 = lVar12 + -1;
          } while (lVar12 != 0);
          if (lVar12 != 0) {
            lVar29 = 1;
            psVar36 = (short *)0xc284a0;
            lVar35 = lVar12 + -0x100;
            if (lVar12 == 0) {
              lVar35 = 0;
            }
            lVar28 = (0x100 - lVar12) * 2;
            if (lVar12 == 0) {
              lVar28 = 0;
            }
            psVar22 = (short *)(lVar28 + (longlong)param_4);
            lVar35 = lVar35 + 0x100;
            for (; ((lVar35 != 0 && (lVar29 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
              *psVar22 = *psVar36;
              psVar22 = psVar22 + 1;
              lVar29 = lVar29 + -1;
              lVar35 = lVar35 + -1;
            }
            psVar36 = psVar22 + -1;
            if (lVar35 != 0) {
              psVar36 = psVar22;
            }
            *psVar36 = 0;
            if (lVar35 != 0) {
              uVar38 = uVar38 - 1;
              param_5 = uVar38;
              goto LAB_;
            }
          }
        }
        else {
LAB_:
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x103fe0;
          iVar6 = func_0x(param_4,0x100,0xdb1018);
          uVar39 = extraout_XMM0_Qa_28;
          if (-1 < iVar6) {
            uVar38 = uVar38 - 5;
            param_5 = uVar38;
            *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
          }
        }
        if (uVar38 != 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10400c;
          iVar6 = func_0x(param_4,0x100,asStack_34f8);
          uVar39 = extraout_XMM0_Qa_29;
          if (-1 < iVar6) {
            lVar12 = -1;
            do {
              lVar12 = lVar12 + 1;
            } while (asStack_34f8[lVar12] != 0);
            uVar38 = uVar38 - (int)lVar12;
            param_5 = uVar38;
            *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
          }
        }
      }
    }
  }
  if ((*(char *)(param_3 + 0x16) + 0x72U & 0xfd) == 0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104059;
    lVar12 = func_0x(param_3 + 0x1c,0,auStack_4260);
    lVar29 = -1;
    do {
      lVar29 = lVar29 + 1;
    } while (*(short *)(lVar12 + 0x21a + lVar29 * 2) != 0);
    uVar39 = extraout_XMM0_Qa_30;
    if (uVar38 != 0) {
      if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
        lVar35 = 0x100;
        psVar36 = param_4;
        do {
          if (*psVar36 == 0) break;
          psVar36 = psVar36 + 1;
          lVar35 = lVar35 + -1;
        } while (lVar35 != 0);
        if (lVar35 != 0) {
          lVar24 = 1;
          psVar36 = (short *)0xc284a0;
          lVar28 = lVar35 + -0x100;
          if (lVar35 == 0) {
            lVar28 = 0;
          }
          lVar37 = (0x100 - lVar35) * 2;
          if (lVar35 == 0) {
            lVar37 = 0;
          }
          psVar22 = (short *)(lVar37 + (longlong)param_4);
          lVar28 = lVar28 + 0x100;
          for (; ((lVar28 != 0 && (lVar24 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
            *psVar22 = *psVar36;
            psVar22 = psVar22 + 1;
            lVar24 = lVar24 + -1;
            lVar28 = lVar28 + -1;
          }
          psVar36 = psVar22 + -1;
          if (lVar28 != 0) {
            psVar36 = psVar22;
          }
          *psVar36 = 0;
          if (lVar28 != 0) {
            uVar38 = uVar38 - 1;
            param_5 = uVar38;
            goto LAB_;
          }
        }
      }
      else {
LAB_:
        iVar10 = (int)lVar29;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104133;
        iVar6 = func_0x(param_4,0x100,lVar12 + 0x21a);
        uVar39 = extraout_XMM0_Qa_31;
        if (-1 < iVar6) {
          uVar38 = uVar38 - iVar10;
          param_5 = uVar38;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
      }
    }
  }
  puVar32 = (undefined *)0x0;
  if (*(char *)(param_3 + 0x16) == -0x6f) {
    uStack_4384 = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104168;
    puVar19 = (ushort *)func_0x(param_3 + 0x18,0,&uStack_4384);
    uStack_3a98 = 0;
    uStack_3a90 = 1;
    uStack_3a8c = 0x80000000;
    uStack_3a88 = 0;
    uStack_3a80 = 0;
    uStack_3f08 = 0;
    uStack_3f00 = 2;
    uStack_3efc = 0x80000000;
    uStack_3ef8 = 0;
    uStack_3ef0 = 0;
    uStack_3eee = 0;
    uStack_3ee6 = 0;
    uStack_3ee4 = 0;
    uStack_3edc = 0;
    uStack_3eda = _DAT_;
    uStack_3ed6 = _DAT_;
    uStack_3ed4 = 0;
    uStack_3ed0 = 0;
    uStack_3ec8 = 0;
    uStack_3ec0 = 0;
    uStack_3eb8 = 0;
    if (puVar19[4] == 1) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10429d;
      func_0x(&uStack_3a98,puVar19,uStack_4384,uStack_4368);
    }
    else if (puVar19[4] == 2) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104281;
      func_0x(&uStack_3f08,puVar19,uStack_4384);
    }
    else {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xa41b88;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10426c;
      (*_DAT_)(1,0xe469e0,0xe4c3a8,0x20df);
    }
    if (*puVar19 - 1 < 7) {
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)*(uint *)((longlong)(int)(*puVar19 - 1) * 4 + 0x109b10) - 0x1a77ca0);
                    /* WARNING: Could not emulate address calculation at 0x001042b4 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xa41b88;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10443e;
    (*_DAT_)(1,0xe469e0,0xe4c3a8,0x2100);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104448;
    uVar39 = (*_DAT_)();
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined4 *)(puVar19 + 6);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10446a;
    iVar6 = func_0x(asStack_3618,0x28,0xdb0fc0,uVar39);
    uVar39 = extraout_XMM0_Qa_32;
    if (iVar6 < 0) {
      *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0x2115;
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10449f;
      uVar39 = (*_DAT_)(4,7,0x10,1);
      uVar38 = param_5;
    }
    if (uVar38 != 0) {
      if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
        lVar12 = 0x100;
        psVar36 = param_4;
        do {
          if (*psVar36 == 0) break;
          psVar36 = psVar36 + 1;
          lVar12 = lVar12 + -1;
        } while (lVar12 != 0);
        if (lVar12 != 0) {
          lVar29 = 1;
          psVar36 = (short *)0xc284a0;
          puVar27 = (undefined *)(lVar12 + -0x100);
          if (lVar12 == 0) {
            puVar27 = puVar32;
          }
          puVar30 = (undefined *)((0x100 - lVar12) * 2);
          if (lVar12 == 0) {
            puVar30 = puVar32;
          }
          psVar22 = (short *)(puVar30 + (longlong)param_4);
          puVar27 = puVar27 + 0x100;
          for (; ((puVar27 != (undefined *)0x0 && (lVar29 != 0)) && (*psVar36 != 0));
              psVar36 = psVar36 + 1) {
            *psVar22 = *psVar36;
            psVar22 = psVar22 + 1;
            lVar29 = lVar29 + -1;
            puVar27 = puVar27 + -1;
          }
          psVar36 = psVar22 + -1;
          if (puVar27 != (undefined *)0x0) {
            psVar36 = psVar22;
          }
          *psVar36 = 0;
          if (puVar27 != (undefined *)0x0) {
            uVar38 = uVar38 - 1;
            param_5 = uVar38;
            goto LAB_;
          }
        }
      }
      else {
LAB_:
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104561;
        iVar6 = func_0x(param_4,0x100,asStack_3618);
        uVar39 = extraout_XMM0_Qa_33;
        if (-1 < iVar6) {
          lVar12 = -1;
          do {
            lVar12 = lVar12 + 1;
          } while (asStack_3618[lVar12] != 0);
          uVar38 = uVar38 - (int)lVar12;
          param_5 = uVar38;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
      }
      if (uVar38 != 0) {
        if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
          lVar12 = 0x100;
          psVar36 = param_4;
          do {
            if (*psVar36 == 0) break;
            psVar36 = psVar36 + 1;
            lVar12 = lVar12 + -1;
          } while (lVar12 != 0);
          if (lVar12 != 0) {
            lVar29 = 1;
            psVar36 = (short *)0xc284a0;
            puVar27 = (undefined *)(lVar12 + -0x100);
            if (lVar12 == 0) {
              puVar27 = puVar32;
            }
            puVar30 = (undefined *)((0x100 - lVar12) * 2);
            if (lVar12 == 0) {
              puVar30 = puVar32;
            }
            psVar22 = (short *)(puVar30 + (longlong)param_4);
            puVar27 = puVar27 + 0x100;
            for (; ((puVar27 != (undefined *)0x0 && (lVar29 != 0)) && (*psVar36 != 0));
                psVar36 = psVar36 + 1) {
              *psVar22 = *psVar36;
              psVar22 = psVar22 + 1;
              lVar29 = lVar29 + -1;
              puVar27 = puVar27 + -1;
            }
            psVar36 = psVar22 + -1;
            if (puVar27 != (undefined *)0x0) {
              psVar36 = psVar22;
            }
            *psVar36 = 0;
            if (puVar27 != (undefined *)0x0) {
              uVar38 = uVar38 - 1;
              param_5 = uVar38;
              goto LAB_;
            }
          }
        }
        else {
LAB_:
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10464e;
          iVar6 = func_0x(param_4,0x100,0xdb0fd8);
          uVar39 = extraout_XMM0_Qa_34;
          if (-1 < iVar6) {
            uVar38 = uVar38 - 5;
            param_5 = uVar38;
            *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
          }
        }
      }
    }
    if (puVar19[4] == 1) {
      if (uStack_3a98._6_2_ != 0) {
        puVar32 = auStack_3a7e + (uStack_3a98 >> 0x20 & 0xffff);
      }
      uVar33 = uStack_3a98._6_2_ >> 1;
      if (uVar38 != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10473b;
        iVar6 = func_0x(param_4,0x100,puVar32,(uint)uVar33);
        uVar39 = extraout_XMM0_Qa_36;
        if (-1 < iVar6) {
          uVar38 = uVar38 - uVar33;
          param_5 = uVar38;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
      }
    }
    else if (puVar19[4] == 2) {
      if (uStack_3f08._6_2_ != 0) {
        puVar32 = auStack_3eb0 + (uStack_3f08 >> 0x20 & 0xffff);
      }
      uVar33 = uStack_3f08._6_2_ >> 1;
      if (uVar38 != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1046e4;
        iVar6 = func_0x(param_4,0x100,puVar32,(uint)uVar33);
        uVar39 = extraout_XMM0_Qa_35;
        if (-1 < iVar6) {
          uVar38 = uVar38 - uVar33;
          param_5 = uVar38;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
      }
    }
    else {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xa41b88;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1046a0;
      uVar39 = (*_DAT_)(1,0xe469e0,0xe4c3a8,0x2134);
    }
    lVar12 = 1;
    if (((*puVar19 - 4 & 0xfffc) == 0) && (*puVar19 != 6)) {
      if (uVar38 != 0) {
        if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
          lVar29 = 0x100;
          psVar36 = param_4;
          do {
            if (*psVar36 == 0) break;
            psVar36 = psVar36 + 1;
            lVar29 = lVar29 + -1;
          } while (lVar29 != 0);
          if (lVar29 != 0) {
            psVar36 = (short *)0xc284a0;
            lVar35 = lVar29 + -0x100;
            if (lVar29 == 0) {
              lVar35 = 0;
            }
            lVar28 = (0x100 - lVar29) * 2;
            if (lVar29 == 0) {
              lVar28 = 0;
            }
            psVar22 = (short *)(lVar28 + (longlong)param_4);
            lVar35 = lVar35 + 0x100;
            for (; ((lVar35 != 0 && (lVar12 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
              *psVar22 = *psVar36;
              psVar22 = psVar22 + 1;
              lVar12 = lVar12 + -1;
              lVar35 = lVar35 + -1;
            }
            psVar36 = psVar22 + -1;
            if (lVar35 != 0) {
              psVar36 = psVar22;
            }
            *psVar36 = 0;
            if (lVar35 != 0) {
              uVar38 = uVar38 - 1;
              param_5 = uVar38;
              goto LAB_;
            }
          }
        }
        else {
LAB_:
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10483f;
          iVar6 = func_0x(param_4,0x100,0xdb0f28);
          if (-1 < iVar6) {
            param_5 = uVar38 - 6;
            *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
          }
        }
      }
      uVar33 = uStack_3ee6;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10486b;
      uVar39 = (*_DAT_)();
      *(uint *)(&stack0xfffffffffffffff0 + lVar11) = (uint)uVar33;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = uStack_3eee._4_4_;
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = (undefined4)uStack_3eee;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10489e;
      func_0x(asStack_3528,0x17,0xda6280,uVar39);
      uVar38 = param_5;
      if (param_5 != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1048c0;
        iVar10 = func_0x(param_4,0x100,asStack_3528);
        iVar6 = 0;
        if (iVar10 < 0) {
          iVar6 = *(int *)((longlong)aiStackX_20 + lVar11);
        }
        else {
          lVar12 = -1;
          do {
            lVar12 = lVar12 + 1;
          } while (asStack_3528[lVar12] != 0);
          uVar38 = uVar38 - (int)lVar12;
          param_5 = uVar38;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
        if (uVar38 != 0) {
          if (iVar6 == 0) {
            lVar12 = 0x100;
            psVar36 = param_4;
            do {
              if (*psVar36 == 0) break;
              psVar36 = psVar36 + 1;
              lVar12 = lVar12 + -1;
            } while (lVar12 != 0);
            if (lVar12 != 0) {
              lVar29 = 1;
              psVar36 = (short *)0xc284a0;
              lVar35 = lVar12 + -0x100;
              if (lVar12 == 0) {
                lVar35 = 0;
              }
              lVar28 = (0x100 - lVar12) * 2;
              if (lVar12 == 0) {
                lVar28 = 0;
              }
              psVar22 = (short *)(lVar28 + (longlong)param_4);
              lVar35 = lVar35 + 0x100;
              for (; ((lVar35 != 0 && (lVar29 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
                *psVar22 = *psVar36;
                psVar22 = psVar22 + 1;
                lVar29 = lVar29 + -1;
                lVar35 = lVar35 + -1;
              }
              psVar36 = psVar22 + -1;
              if (lVar35 != 0) {
                psVar36 = psVar22;
              }
              *psVar36 = 0;
              if (lVar35 != 0) {
                uVar38 = uVar38 - 1;
                param_5 = uVar38;
                goto LAB_;
              }
            }
          }
          else {
LAB_:
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1049a3;
            iVar6 = func_0x(param_4,0x100,0xdb0f38);
            if (-1 < iVar6) {
              param_5 = uVar38 - 6;
              *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
            }
          }
        }
      }
      uVar33 = uStack_3edc;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1049c5;
      uVar39 = (*_DAT_)();
      *(uint *)(&stack0xfffffffffffffff0 + lVar11) = (uint)uVar33;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = uStack_3ee4._4_4_;
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = (undefined4)uStack_3ee4;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1049f8;
      uVar39 = func_0x(asStack_3528,0x17,0xda6280,uVar39);
      uVar38 = param_5;
      if (param_5 != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104a18;
        iVar6 = func_0x(param_4,0x100,asStack_3528);
        uVar39 = extraout_XMM0_Qa_37;
        if (-1 < iVar6) {
          lVar12 = -1;
          do {
            lVar12 = lVar12 + 1;
          } while (asStack_3528[lVar12] != 0);
          uVar38 = uVar38 - (int)lVar12;
          param_5 = uVar38;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
      }
      lVar12 = 0;
      if (*puVar19 != 7) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104a54;
        uVar39 = (*_DAT_)();
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = uStack_3ed0;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104a7b;
        iVar6 = func_0x(asStack_3618,0x28,0xdb0f48,uVar39);
        if (iVar6 < 0) {
          *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
          *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0x2159;
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104ab0;
          (*_DAT_)(4,7,0x10,1);
          uVar38 = param_5;
        }
        if (uVar38 != 0) {
          if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
            lVar29 = 0x100;
            psVar36 = param_4;
            do {
              if (*psVar36 == 0) break;
              psVar36 = psVar36 + 1;
              lVar29 = lVar29 + -1;
            } while (lVar29 != 0);
            if (lVar29 != 0) {
              lVar35 = 1;
              psVar36 = (short *)0xc284a0;
              lVar28 = lVar29 + -0x100;
              if (lVar29 == 0) {
                lVar28 = lVar12;
              }
              lVar24 = (0x100 - lVar29) * 2;
              if (lVar29 == 0) {
                lVar24 = lVar12;
              }
              psVar22 = (short *)(lVar24 + (longlong)param_4);
              lVar28 = lVar28 + 0x100;
              for (; ((lVar28 != 0 && (lVar35 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
                *psVar22 = *psVar36;
                psVar22 = psVar22 + 1;
                lVar35 = lVar35 + -1;
                lVar28 = lVar28 + -1;
              }
              psVar36 = psVar22 + -1;
              if (lVar28 != 0) {
                psVar36 = psVar22;
              }
              *psVar36 = 0;
              if (lVar28 != 0) {
                uVar38 = uVar38 - 1;
                param_5 = uVar38;
                goto LAB_;
              }
            }
          }
          else {
LAB_:
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104b70;
            iVar6 = func_0x(param_4,0x100,asStack_3618);
            if (-1 < iVar6) {
              lVar29 = -1;
              do {
                lVar29 = lVar29 + 1;
              } while (asStack_3618[lVar29] != 0);
              uVar38 = uVar38 - (int)lVar29;
              param_5 = uVar38;
              *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
            }
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104b9e;
        uVar39 = (*_DAT_)();
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = uStack_3ec8;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104bc5;
        iVar6 = func_0x(asStack_3618,0x28,0xdb0f68,uVar39);
        if (iVar6 < 0) {
          *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
          *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0x2162;
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104bfa;
          (*_DAT_)(4,7,0x10,1);
          uVar38 = param_5;
        }
        if (uVar38 != 0) {
          if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
            lVar29 = 0x100;
            psVar36 = param_4;
            do {
              if (*psVar36 == 0) break;
              psVar36 = psVar36 + 1;
              lVar29 = lVar29 + -1;
            } while (lVar29 != 0);
            if (lVar29 != 0) {
              lVar35 = 1;
              psVar36 = (short *)0xc284a0;
              lVar28 = lVar29 + -0x100;
              if (lVar29 == 0) {
                lVar28 = lVar12;
              }
              lVar24 = (0x100 - lVar29) * 2;
              if (lVar29 == 0) {
                lVar24 = lVar12;
              }
              psVar22 = (short *)(lVar24 + (longlong)param_4);
              lVar28 = lVar28 + 0x100;
              for (; ((lVar28 != 0 && (lVar35 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
                *psVar22 = *psVar36;
                psVar22 = psVar22 + 1;
                lVar35 = lVar35 + -1;
                lVar28 = lVar28 + -1;
              }
              psVar36 = psVar22 + -1;
              if (lVar28 != 0) {
                psVar36 = psVar22;
              }
              *psVar36 = 0;
              if (lVar28 != 0) {
                uVar38 = uVar38 - 1;
                param_5 = uVar38;
                goto LAB_;
              }
            }
          }
          else {
LAB_:
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104cbe;
            iVar6 = func_0x(param_4,0x100,asStack_3618);
            if (-1 < iVar6) {
              lVar29 = -1;
              do {
                lVar29 = lVar29 + 1;
              } while (asStack_3618[lVar29] != 0);
              uVar38 = uVar38 - (int)lVar29;
              param_5 = uVar38;
              *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
            }
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104cee;
        uVar39 = (*_DAT_)();
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = uStack_3ec0;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104d15;
        iVar6 = func_0x(asStack_3618,0x28,0xdb0ec0,uVar39);
        if (iVar6 < 0) {
          *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
          *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0x216b;
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104d4a;
          (*_DAT_)(4,7,0x10,1);
          uVar38 = param_5;
        }
        if (uVar38 != 0) {
          if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
            lVar29 = 0x100;
            psVar36 = param_4;
            do {
              if (*psVar36 == 0) break;
              psVar36 = psVar36 + 1;
              lVar29 = lVar29 + -1;
            } while (lVar29 != 0);
            if (lVar29 != 0) {
              lVar35 = 1;
              psVar36 = (short *)0xc284a0;
              lVar28 = lVar29 + -0x100;
              if (lVar29 == 0) {
                lVar28 = lVar12;
              }
              lVar24 = (0x100 - lVar29) * 2;
              if (lVar29 == 0) {
                lVar24 = lVar12;
              }
              psVar22 = (short *)(lVar24 + (longlong)param_4);
              lVar28 = lVar28 + 0x100;
              for (; ((lVar28 != 0 && (lVar35 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
                *psVar22 = *psVar36;
                psVar22 = psVar22 + 1;
                lVar35 = lVar35 + -1;
                lVar28 = lVar28 + -1;
              }
              psVar36 = psVar22 + -1;
              if (lVar28 != 0) {
                psVar36 = psVar22;
              }
              *psVar36 = 0;
              if (lVar28 != 0) {
                uVar38 = uVar38 - 1;
                param_5 = uVar38;
                goto LAB_;
              }
            }
          }
          else {
LAB_:
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104e0e;
            iVar6 = func_0x(param_4,0x100,asStack_3618);
            if (-1 < iVar6) {
              lVar29 = -1;
              do {
                lVar29 = lVar29 + 1;
              } while (asStack_3618[lVar29] != 0);
              uVar38 = uVar38 - (int)lVar29;
              param_5 = uVar38;
              *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
            }
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104e3e;
        uVar39 = (*_DAT_)();
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = uStack_3eb8;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104e65;
        iVar6 = func_0x(asStack_3618,0x28,0xdb0ed8,uVar39);
        if (iVar6 < 0) {
          *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
          *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0x2174;
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104e9a;
          (*_DAT_)(4,7,0x10,1);
          uVar38 = param_5;
        }
        if (uVar38 != 0) {
          if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
            lVar29 = 0x100;
            psVar36 = param_4;
            do {
              if (*psVar36 == 0) break;
              psVar36 = psVar36 + 1;
              lVar29 = lVar29 + -1;
            } while (lVar29 != 0);
            if (lVar29 != 0) {
              lVar35 = 1;
              psVar36 = (short *)0xc284a0;
              lVar28 = lVar29 + -0x100;
              if (lVar29 == 0) {
                lVar28 = lVar12;
              }
              lVar24 = (0x100 - lVar29) * 2;
              if (lVar29 == 0) {
                lVar24 = lVar12;
              }
              psVar22 = (short *)(lVar24 + (longlong)param_4);
              lVar28 = lVar28 + 0x100;
              for (; ((lVar28 != 0 && (lVar35 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
                *psVar22 = *psVar36;
                psVar22 = psVar22 + 1;
                lVar35 = lVar35 + -1;
                lVar28 = lVar28 + -1;
              }
              psVar36 = psVar22 + -1;
              if (lVar28 != 0) {
                psVar36 = psVar22;
              }
              *psVar36 = 0;
              if (lVar28 != 0) {
                uVar38 = uVar38 - 1;
                param_5 = uVar38;
                goto LAB_;
              }
            }
          }
          else {
LAB_:
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104f5e;
            iVar6 = func_0x(param_4,0x100,asStack_3618);
            if (-1 < iVar6) {
              lVar12 = -1;
              do {
                lVar12 = lVar12 + 1;
              } while (asStack_3618[lVar12] != 0);
              uVar38 = uVar38 - (int)lVar12;
              param_5 = uVar38;
              *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
            }
          }
        }
        uVar7 = uStack_3f00 >> 0x10;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104f95;
        uVar39 = (*_DAT_)();
        *(uint *)(&stack0xffffffffffffffe0 + lVar11) = uVar7;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104fb4;
        iVar6 = func_0x(asStack_3618,0x28,0xdb0ef0,uVar39);
        uVar39 = extraout_XMM0_Qa_38;
        if (iVar6 < 0) {
          *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
          *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0x217d;
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x104feb;
          uVar39 = (*_DAT_)(4,7,0x10,1);
          uVar38 = param_5;
        }
        if (uVar38 != 0) {
          if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
            lVar12 = 0x100;
            psVar36 = param_4;
            do {
              if (*psVar36 == 0) break;
              psVar36 = psVar36 + 1;
              lVar12 = lVar12 + -1;
            } while (lVar12 != 0);
            if (lVar12 != 0) {
              lVar35 = 1;
              psVar36 = (short *)0xc284a0;
              lVar29 = lVar12 + -0x100;
              if (lVar12 == 0) {
                lVar29 = 0;
              }
              lVar28 = (0x100 - lVar12) * 2;
              if (lVar12 == 0) {
                lVar28 = 0;
              }
              psVar22 = (short *)(lVar28 + (longlong)param_4);
              lVar29 = lVar29 + 0x100;
              for (; ((lVar29 != 0 && (lVar35 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
                *psVar22 = *psVar36;
                psVar22 = psVar22 + 1;
                lVar35 = lVar35 + -1;
                lVar29 = lVar29 + -1;
              }
              psVar36 = psVar22 + -1;
              if (lVar29 != 0) {
                psVar36 = psVar22;
              }
              *psVar36 = 0;
              if (lVar29 != 0) {
                uVar38 = uVar38 - 1;
                param_5 = uVar38;
                goto LAB_;
              }
            }
          }
          else {
LAB_:
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1050b8;
            iVar6 = func_0x(param_4,0x100,asStack_3618);
            uVar39 = extraout_XMM0_Qa_39;
            if (-1 < iVar6) {
              lVar12 = -1;
              do {
                lVar12 = lVar12 + 1;
              } while (asStack_3618[lVar12] != 0);
              uVar38 = uVar38 - (int)lVar12;
              param_5 = uVar38;
              *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
            }
          }
        }
      }
    }
    if ((*puVar19 == 3) && (puVar19[4] == 2)) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1050f8;
      uVar39 = (*_DAT_)();
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = uStack_3ec8;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10511f;
      iVar6 = func_0x(asStack_3618,0x28,0xdb0f08,uVar39);
      uVar39 = extraout_XMM0_Qa_40;
      if (iVar6 < 0) {
        *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0x218d;
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x105156;
        uVar39 = (*_DAT_)(4,7,0x10,1);
        uVar38 = param_5;
      }
      if (uVar38 != 0) {
        if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
          lVar12 = 0x100;
          psVar36 = param_4;
          do {
            if (*psVar36 == 0) break;
            psVar36 = psVar36 + 1;
            lVar12 = lVar12 + -1;
          } while (lVar12 != 0);
          if (lVar12 != 0) {
            lVar35 = 1;
            psVar36 = (short *)0xc284a0;
            lVar29 = lVar12 + -0x100;
            if (lVar12 == 0) {
              lVar29 = 0;
            }
            lVar28 = (0x100 - lVar12) * 2;
            if (lVar12 == 0) {
              lVar28 = 0;
            }
            psVar22 = (short *)(lVar28 + (longlong)param_4);
            lVar29 = lVar29 + 0x100;
            for (; ((lVar29 != 0 && (lVar35 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
              *psVar22 = *psVar36;
              psVar22 = psVar22 + 1;
              lVar35 = lVar35 + -1;
              lVar29 = lVar29 + -1;
            }
            psVar36 = psVar22 + -1;
            if (lVar29 != 0) {
              psVar36 = psVar22;
            }
            *psVar36 = 0;
            if (lVar29 != 0) {
              uVar38 = uVar38 - 1;
              param_5 = uVar38;
              goto LAB_;
            }
          }
        }
        else {
LAB_:
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x105221;
          iVar6 = func_0x(param_4,0x100,asStack_3618);
          uVar39 = extraout_XMM0_Qa_41;
          if (-1 < iVar6) {
            lVar12 = -1;
            do {
              lVar12 = lVar12 + 1;
            } while (asStack_3618[lVar12] != 0);
            uVar38 = uVar38 - (int)lVar12;
            param_5 = uVar38;
            *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
          }
        }
      }
    }
  }
  if (*(char *)(param_3 + 0x16) == -0x6e) {
    uStack_437c = 0;
    uStack_4380 = 0;
    param_3 = param_3 + 0x20;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10527b;
    lVar12 = func_0x(param_3,0,&uStack_437c);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10528f;
    func_0x(param_3,1,&uStack_4380);
    *(undefined4 *)(&stack0x0000002c + lVar11) = 0;
    *(undefined8 *)(&stack0x00000038 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1052bf;
    func_0x(param_3,0,&uStack_437c);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1052d0;
    func_0x(param_3,1,&uStack_4380);
    pbVar13 = (byte *)(lVar12 + 8);
    bVar5 = *pbVar13;
    *(byte **)(&stack0x00000030 + lVar11) = pbVar13;
    if ((bVar5 & 1) != 0) {
      *(undefined2 *)((longlong)&param_5 + lVar11) = 1;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar13 & 0x1c) + 0x109b3c) * 4
                             + 0x109b2c) - 0x1a77ca0);
                    /* WARNING: Could not emulate address calculation at 0x00105300 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
    *(undefined2 *)((longlong)&param_5 + lVar11) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00105469 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar13 & 0xe) * 4 + 0x109b5c) - 0x1a77ca0))();
    return;
  }
  if (*(char *)(param_3 + 0x16) == -0x6d) {
    if ((undefined8 *)(param_3 + 0x1c) == (undefined8 *)0x0) {
      uStack_42e0 = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10695a;
      puVar18 = (undefined4 *)(*_DAT_)();
      *puVar18 = 0x16;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x106966;
      (*_DAT_)();
    }
    else {
      uStack_42e0 = *(undefined8 *)(param_3 + 0x1c);
    }
    uVar39 = uStack_42e0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x106973;
    uVar14 = (*_DAT_)();
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = uVar39;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined4 *)(param_3 + 0x18);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10699b;
    iVar6 = func_0x(asStack_1ca8,200,0xdb1310,uVar14);
    uVar39 = extraout_XMM0_Qa_42;
    if (iVar6 < 0) {
      *(int *)(&stack0xfffffffffffffff0 + lVar11) = iVar6;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0x21f7;
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xdaf840;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1069d2;
      uVar39 = (*_DAT_)(4,7,0x10,1);
      uVar38 = param_5;
    }
    if (uVar38 != 0) {
      if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
        lVar12 = 0x100;
        psVar36 = param_4;
        do {
          if (*psVar36 == 0) break;
          psVar36 = psVar36 + 1;
          lVar12 = lVar12 + -1;
        } while (lVar12 != 0);
        if (lVar12 != 0) {
          lVar35 = 1;
          psVar36 = (short *)0xc284a0;
          lVar29 = lVar12 + -0x100;
          if (lVar12 == 0) {
            lVar29 = 0;
          }
          lVar28 = (0x100 - lVar12) * 2;
          if (lVar12 == 0) {
            lVar28 = 0;
          }
          psVar22 = (short *)(lVar28 + (longlong)param_4);
          lVar29 = lVar29 + 0x100;
          for (; ((lVar29 != 0 && (lVar35 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
            *psVar22 = *psVar36;
            psVar22 = psVar22 + 1;
            lVar35 = lVar35 + -1;
            lVar29 = lVar29 + -1;
          }
          psVar36 = psVar22 + -1;
          if (lVar29 != 0) {
            psVar36 = psVar22;
          }
          *psVar36 = 0;
          if (lVar29 != 0) {
            uVar38 = uVar38 - 1;
            param_5 = uVar38;
            goto LAB_;
          }
        }
      }
      else {
LAB_:
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x106aa5;
        iVar6 = func_0x(param_4,0x100,asStack_1ca8);
        uVar39 = extraout_XMM0_Qa_43;
        if (-1 < iVar6) {
          lVar12 = -1;
          do {
            lVar12 = lVar12 + 1;
          } while (asStack_1ca8[lVar12] != 0);
          uVar38 = uVar38 - (int)lVar12;
          param_5 = uVar38;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
      }
    }
  }
  if (*(char *)(param_3 + 0x16) == -0x68) {
    if (*(byte *)(param_3 + 0x17) < 0x29) {
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((ulonglong)*(byte *)(param_3 + 0x17) + 0x109c10)
                              * 4 + 0x109c04) - 0x1a77ca0);
                    /* WARNING: Could not emulate address calculation at 0x00106aeb */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xa41b88;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x106d58;
    uVar39 = (*_DAT_)(1,0xe469e0,0xe4c3a8,0x2241);
  }
  lVar12 = 0;
  cVar4 = *(char *)(param_3 + 0x16);
  if (cVar4 == -0x67) {
    lVar29 = *(longlong *)(param_3 + 0x20);
    uStack_4360 = *(ushort *)(param_3 + 0x28);
    uStack_363c = 0;
    sStack_363e = (short)*(char *)((ulonglong)(uStack_4360 & 0xf) + 0xb061f8);
    sStack_3640 = (short)*(char *)((ulonglong)(uStack_4360 >> 4 & 0xf) + 0xb061f8);
    sStack_3642 = (short)*(char *)((ulonglong)(uStack_4360 >> 8 & 0xf) + 0xb061f8);
    sStack_3644 = (short)*(char *)((ulonglong)(uStack_4360 >> 0xc) + 0xb061f8);
    uStack_3646 = 0x3a;
    uStack_4368._4_4_ = (uint)((ulonglong)lVar29 >> 0x20);
    sStack_3648 = (short)*(char *)((ulonglong)(uStack_4368._4_4_ & 0xf) + 0xb061f8);
    sStack_364a = (short)*(char *)((ulonglong)(uStack_4368._4_4_ >> 4 & 0xf) + 0xb061f8);
    sStack_364c = (short)*(char *)((ulonglong)(uStack_4368._4_4_ >> 8 & 0xf) + 0xb061f8);
    sStack_364e = (short)*(char *)((ulonglong)(uStack_4368._4_4_ >> 0xc & 0xf) + 0xb061f8);
    sStack_3650 = (short)*(char *)((ulonglong)(uStack_4368._4_4_ >> 0x10 & 0xf) + 0xb061f8);
    sStack_3652 = (short)*(char *)((ulonglong)(uStack_4368._4_4_ >> 0x14 & 0xf) + 0xb061f8);
    sStack_3654 = (short)*(char *)((ulonglong)(uStack_4368._4_4_ >> 0x18 & 0xf) + 0xb061f8);
    sStack_3656 = (short)*(char *)((ulonglong)(uStack_4368._4_4_ >> 0x1c) + 0xb061f8);
    uStack_3658 = 0x3a;
    uVar7 = (uint)lVar29;
    sStack_365a = (short)*(char *)((ulonglong)(uVar7 & 0xf) + 0xb061f8);
    sStack_365c = (short)*(char *)((ulonglong)(uVar7 >> 4 & 0xf) + 0xb061f8);
    sStack_365e = (short)*(char *)((ulonglong)(uVar7 >> 8 & 0xf) + 0xb061f8);
    sStack_3660 = (short)*(char *)((ulonglong)(uVar7 >> 0xc & 0xf) + 0xb061f8);
    asStack_3668[3] = (short)*(char *)((ulonglong)(uVar7 >> 0x10 & 0xf) + 0xb061f8);
    asStack_3668[2] = (short)*(char *)((ulonglong)(uVar7 >> 0x14 & 0xf) + 0xb061f8);
    asStack_3668[1] = (short)*(char *)((ulonglong)(uVar7 >> 0x18 & 0xf) + 0xb061f8);
    asStack_3668[0] = (short)*(char *)((ulonglong)(uVar7 >> 0x1c) + 0xb061f8);
    uStack_4368 = lVar29;
    if (uVar38 != 0) {
      if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
        lVar29 = 0x100;
        psVar36 = param_4;
        do {
          if (*psVar36 == 0) break;
          psVar36 = psVar36 + 1;
          lVar29 = lVar29 + -1;
        } while (lVar29 != 0);
        if (lVar29 != 0) {
          lVar35 = 1;
          psVar36 = (short *)0xc284a0;
          lVar28 = lVar29 + -0x100;
          if (lVar29 == 0) {
            lVar28 = lVar12;
          }
          lVar24 = (0x100 - lVar29) * 2;
          if (lVar29 == 0) {
            lVar24 = lVar12;
          }
          psVar22 = (short *)(lVar24 + (longlong)param_4);
          lVar28 = lVar28 + 0x100;
          for (; ((lVar28 != 0 && (lVar35 != 0)) && (*psVar36 != 0)); psVar36 = psVar36 + 1) {
            *psVar22 = *psVar36;
            psVar22 = psVar22 + 1;
            lVar35 = lVar35 + -1;
            lVar28 = lVar28 + -1;
          }
          psVar36 = psVar22 + -1;
          if (lVar28 != 0) {
            psVar36 = psVar22;
          }
          *psVar36 = 0;
          if (lVar28 != 0) {
            uVar38 = uVar38 - 1;
            param_5 = uVar38;
            goto LAB_;
          }
        }
      }
      else {
LAB_:
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107060;
        iVar6 = func_0x(param_4,0x100,0xdb13a0);
        if (-1 < iVar6) {
          uVar38 = uVar38 - 0x13;
          param_5 = uVar38;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
      }
      if (uVar38 != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10708c;
        iVar6 = func_0x(param_4,0x100,asStack_3668);
        if (-1 < iVar6) {
          lVar29 = -1;
          do {
            lVar29 = lVar29 + 1;
          } while (asStack_3668[lVar29] != 0);
          uVar38 = uVar38 - (int)lVar29;
          param_5 = uVar38;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
      }
    }
    lVar29 = -1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1070d6;
    func_0x(param_3 + 0x34,asStack_3668,auStack_4378);
    if (uVar38 != 0) {
      if (*(int *)((longlong)aiStackX_20 + lVar11) == 0) {
        lVar35 = 0x100;
        psVar36 = param_4;
        do {
          if (*psVar36 == 0) break;
          psVar36 = psVar36 + 1;
          lVar35 = lVar35 + -1;
        } while (lVar35 != 0);
        if (lVar35 != 0) {
          lVar24 = 1;
          lVar28 = lVar35 + -0x100;
          if (lVar35 == 0) {
            lVar28 = lVar12;
          }
          lVar37 = (0x100 - lVar35) * 2;
          if (lVar35 == 0) {
            lVar37 = lVar12;
          }
          psVar36 = (short *)(lVar37 + (longlong)param_4);
          lVar28 = lVar28 + 0x100;
          if (lVar28 != 0) {
            psVar22 = (short *)0xc284a0;
            do {
              if ((lVar24 == 0) || (*psVar22 == 0)) break;
              *psVar36 = *psVar22;
              psVar36 = psVar36 + 1;
              psVar22 = psVar22 + 1;
              lVar24 = lVar24 + -1;
              lVar28 = lVar28 + -1;
            } while (lVar28 != 0);
          }
          psVar22 = psVar36 + -1;
          if (lVar28 != 0) {
            psVar22 = psVar36;
          }
          *psVar22 = 0;
          if (lVar28 != 0) {
            uVar38 = uVar38 - 1;
            param_5 = uVar38;
            goto LAB_;
          }
        }
      }
      else {
LAB_:
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107190;
        iVar6 = func_0x(param_4,0x100,0xdb1190);
        if (-1 < iVar6) {
          uVar38 = uVar38 - 0x11;
          param_5 = uVar38;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
      }
      if (uVar38 != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1071bc;
        iVar6 = func_0x(param_4,0x100,asStack_3668);
        if (-1 < iVar6) {
          do {
            lVar29 = lVar29 + 1;
          } while (asStack_3668[lVar29] != 0);
          param_5 = uVar38 - (int)lVar29;
          *(undefined4 *)((longlong)aiStackX_20 + lVar11) = 0;
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1071fc;
    uVar39 = func_0x(param_3 + 0x40,asStack_3668,auStack_4378);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107225;
    uVar39 = func_0x(uVar39,param_4,0xdb11b8,&param_5);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10724e;
    func_0x(uVar39,param_4,asStack_3668,&param_5);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107262;
    uVar39 = func_0x(param_3 + 0x4c,asStack_3668,auStack_4378);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10728b;
    uVar39 = func_0x(uVar39,param_4,0xdb11e0,&param_5);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1072b4;
    func_0x(uVar39,param_4,asStack_3668,&param_5);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1072c8;
    uVar39 = func_0x(param_3 + 0x58,asStack_3668,auStack_4378);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1072f1;
    uVar39 = func_0x(uVar39,param_4,0xdb1208,&param_5);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10731a;
    uVar39 = func_0x(uVar39,param_4,asStack_3668,&param_5);
    cVar4 = *(char *)(param_3 + 0x16);
  }
  if (cVar4 == -0x4c) {
    uVar33 = *(ushort *)(param_3 + 0x1a);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107332;
    uVar39 = func_0x(param_3);
    *(longlong *)(&stack0xfffffffffffffff0 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 1;
    *(uint **)(&stack0xffffffffffffffe0 + lVar11) = &param_5;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10735a;
    func_0x(extraout_XMM0_Qa_44,param_4,uVar39,uVar33 >> 1);
    uVar33 = *(ushort *)(param_3 + 0x1c);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107369;
    uVar39 = func_0x(param_3);
    *(longlong *)(&stack0xfffffffffffffff0 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 1;
    *(uint **)(&stack0xffffffffffffffe0 + lVar11) = &param_5;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107391;
    uVar39 = func_0x(extraout_XMM0_Qa_45,param_4,uVar39,uVar33 >> 1);
    cVar4 = *(char *)(param_3 + 0x16);
  }
  if (cVar4 == -0x4b) {
    uVar33 = *(ushort *)(param_3 + 0x1a);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1073a9;
    uVar39 = func_0x(param_3);
    *(longlong *)(&stack0xfffffffffffffff0 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 1;
    *(uint **)(&stack0xffffffffffffffe0 + lVar11) = &param_5;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1073d1;
    func_0x(extraout_XMM0_Qa_46,param_4,uVar39,uVar33 >> 1);
    uVar33 = *(ushort *)(param_3 + 0x1c);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1073e0;
    uVar39 = func_0x(param_3);
    *(longlong *)(&stack0xfffffffffffffff0 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 1;
    *(uint **)(&stack0xffffffffffffffe0 + lVar11) = &param_5;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107408;
    uVar39 = func_0x(extraout_XMM0_Qa_47,param_4,uVar39,uVar33 >> 1);
    cVar4 = *(char *)(param_3 + 0x16);
  }
  if (cVar4 == -0x71) {
    uVar33 = *(ushort *)(param_3 + 0x20) >> 3;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107426;
    lVar12 = func_0x(param_3);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107440;
    uVar39 = func_0x(auStack_33e0,param_3 + 0x18,auStack_4344);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10746e;
    uVar39 = func_0x(uVar39,param_4,0xdb1018,&param_5);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107497;
    func_0x(uVar39,param_4,auStack_33e0,&param_5);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10749f;
    lVar29 = func_0x(param_3);
    uVar39 = extraout_XMM0_Qa_48;
    if (lVar29 != 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1074ba;
      uVar39 = func_0x(auStack_3280,lVar29,auStack_4344);
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
      *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1074e3;
      uVar39 = func_0x(uVar39,param_4,0xdb1158,&param_5);
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
      *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10750c;
      uVar39 = func_0x(uVar39,param_4,auStack_3280,&param_5);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107535;
    uVar39 = func_0x(uVar39,param_4,0xdb1168,&param_5);
    uVar23 = 0;
    if (uVar33 != 0) {
      do {
        lVar29 = lVar12 + uVar23 * 8;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10756d;
        uVar39 = func_0x(auStack_3400,lVar29,auStack_4344);
        if ((short)uVar23 != 0) {
          *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
          *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
          *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10759c;
          uVar39 = func_0x(uVar39,param_4,0xc20454,&param_5);
        }
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
        *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
        *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1075c6;
        uVar14 = func_0x(uVar39,param_4,auStack_3400,&param_5);
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
        *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
        *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
        uVar39 = 0xdb117c;
        if ((*(byte *)(lVar29 + 6) & 1) == 0) {
          uVar39 = 0xdb1188;
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1075fd;
        uVar39 = func_0x(uVar14,param_4,uVar39,&param_5);
        param_3 = lStack_43b8;
      } while ((0x11 < param_5) &&
              (uVar31 = (short)uVar23 + 1, uVar23 = (ulonglong)uVar31, uVar31 < uVar33));
    }
  }
  if ((*(char *)(param_3 + 0x16) == -0x2d) && (*(char *)(param_3 + 0x17) == '\a')) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10763e;
    piVar20 = (int *)func_0x(param_3 + 0x18,0,&uStack_4340);
    if (*piVar20 == 1) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107686;
      uVar39 = func_0x(param_3 + 0x18,1,&uStack_4340);
      uVar38 = uStack_4340 >> 1;
      if (0xff < uStack_4340 >> 1) {
        uVar38 = 0xff;
      }
      *(longlong *)(&stack0xfffffffffffffff0 + lVar11) = (longlong)aiStackX_20 + lVar11;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 1;
      *(uint **)(&stack0xffffffffffffffe0 + lVar11) = &param_5;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1076bc;
      uVar39 = func_0x(&param_5,param_4,uVar39,uVar38);
    }
    else {
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
      *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107672;
      uVar39 = func_0x(extraout_XMM0_Qa_49,param_4,0xdb1050,&param_5);
    }
  }
  if (*(char *)(param_3 + 0x16) == -0x2a) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1076d7;
    uVar39 = func_0x(auStack_4374);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107700;
    func_0x(uVar39,param_4,0xdb1080,&param_5);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10770c;
    func_0x(param_3,auStack_4374);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107718;
    lVar12 = func_0x(param_3,auStack_4374);
    uVar39 = extraout_XMM0_Qa_50;
    while (lVar12 != 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107736;
      uVar39 = func_0x(auStack_33c0,lVar12,auStack_425c);
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
      *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10775f;
      uVar39 = func_0x(uVar39,param_4,0xa76048,&param_5);
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
      *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107788;
      func_0x(uVar39,param_4,auStack_33c0,&param_5);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107794;
      lVar12 = func_0x(param_3,auStack_4374);
      uVar39 = extraout_XMM0_Qa_51;
    }
  }
  uVar23 = 0;
  cVar4 = *(char *)(param_3 + 0x16);
  uVar14 = 0xb13e98;
  if (cVar4 == -0x74) {
    iVar6 = *(int *)(param_3 + 0x20);
    if (iVar6 == 0) {
      uVar34 = 0xdb1098;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10793f;
      uVar39 = (*_DAT_)();
      *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = *(undefined8 *)(param_3 + 0x30);
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = *(undefined8 *)(param_3 + 0x38);
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined8 *)(param_3 + 0x28);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107975;
      iVar6 = func_0x(auStack_2998,200,0xdb10c0,uVar39);
      if (iVar6 < 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107993;
        func_0x(0xdaf840,0x2339,iVar6);
      }
    }
    else if (iVar6 == 1) {
      uVar34 = 0xdb2128;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1078e5;
      uVar39 = (*_DAT_)();
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = *(undefined8 *)(param_3 + 0x28);
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined8 *)(param_3 + 0x30);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107912;
      iVar6 = func_0x(auStack_2998,200,0xdb2150,uVar39);
      if (iVar6 < 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107930;
        func_0x(0xdaf840,0x2347,iVar6);
      }
    }
    else if (iVar6 == 2) {
      uVar34 = 0xdb21b8;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10788d;
      uVar39 = (*_DAT_)();
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined8 *)(param_3 + 0x28);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1078b1;
      iVar6 = func_0x(auStack_2998,200,0xdb21e0,uVar39);
      if (iVar6 < 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1078d3;
        func_0x(0xdaf840,0x2354,iVar6);
      }
    }
    else if (iVar6 == 3) {
      uVar34 = 0xdb1ff8;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10782c;
      uVar39 = (*_DAT_)();
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = *(undefined8 *)(param_3 + 0x28);
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined8 *)(param_3 + 0x30);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107859;
      iVar6 = func_0x(auStack_2998,200,0xdb2150,uVar39);
      if (iVar6 < 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10787b;
        func_0x(0xdaf840,0x2363,iVar6);
      }
    }
    else {
      uVar34 = 0xb13e98;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1077dd;
      uVar39 = (*_DAT_)();
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1077f8;
      iVar6 = func_0x(auStack_2998,200,0xa4a410,uVar39);
      if (iVar6 < 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10781a;
        func_0x(0xdaf840,0x236e,iVar6);
      }
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1079a2;
    uVar39 = (*_DAT_)();
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = *(undefined8 *)(param_3 + 0x18);
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = uVar34;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined4 *)(param_3 + 0x20);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1079d3;
    iVar6 = func_0x(auStack_1b18,200,0xdb2020,uVar39);
    uVar39 = extraout_XMM0_Qa_52;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1079ea;
      uVar39 = func_0x(0xdaf840,0x237b,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107a18;
    uVar39 = func_0x(uVar39,param_4,auStack_1b18,&param_5);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107a41;
    uVar39 = func_0x(uVar39,param_4,auStack_2998,&param_5);
    cVar4 = *(char *)(param_3 + 0x16);
  }
  if (cVar4 == '\x12') {
    iVar6 = *(int *)(param_3 + 0x30);
    if (iVar6 == 0) {
      uVar14 = 0xd319b0;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107c42;
      uVar39 = (*_DAT_)();
      *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = *(undefined8 *)(param_3 + 0x60);
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = *(undefined8 *)(param_3 + 0x70);
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined8 *)(param_3 + 0x50);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107c78;
      iVar6 = func_0x(auStack_2ec8,200,0xdb2070,uVar39);
      if (iVar6 < 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107c96;
        func_0x(0xdaf840,0x2396,iVar6);
      }
    }
    else if (iVar6 == 1) {
      uVar14 = 0xd31980;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107bf1;
      uVar39 = (*_DAT_)();
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined8 *)(param_3 + 0x50);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107c15;
      iVar6 = func_0x(auStack_2ec8,200,0xdb1f38,uVar39);
      if (iVar6 < 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107c33;
        func_0x(0xdaf840,0x23b1,iVar6);
      }
    }
    else if (iVar6 == 2) {
      uVar14 = 0xd31958;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107b91;
      uVar39 = (*_DAT_)();
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = *(undefined8 *)(param_3 + 0x58);
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined4 *)(param_3 + 0x50);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107bbd;
      iVar6 = func_0x(auStack_2ec8,200,0xdb1f60,uVar39);
      if (iVar6 < 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107bdf;
        func_0x(0xdaf840,0x23ce,iVar6);
      }
    }
    else if (iVar6 == 3) {
      uVar14 = 0xdb2108;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107b30;
      uVar39 = (*_DAT_)();
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = *(undefined8 *)(param_3 + 0x50);
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined8 *)(param_3 + 0x60);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107b5d;
      iVar6 = func_0x(auStack_2ec8,200,0xdb1ed0,uVar39);
      if (iVar6 < 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107b7f;
        func_0x(0xdaf840,0x23a4,iVar6);
      }
    }
    else if (iVar6 == 4) {
      uVar14 = 0xd31998;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107acf;
      uVar39 = (*_DAT_)();
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = *(undefined8 *)(param_3 + 0x50);
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined8 *)(param_3 + 0x60);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107afc;
      iVar6 = func_0x(auStack_2ec8,200,0xdb1ed0,uVar39);
      if (iVar6 < 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107b1e;
        func_0x(0xdaf840,0x23c0,iVar6);
      }
    }
    else {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107a80;
      uVar39 = (*_DAT_)();
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107a9b;
      iVar6 = func_0x(auStack_2ec8,200,0xa4a410,uVar39);
      if (iVar6 < 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107abd;
        func_0x(0xdaf840,0x23d9,iVar6);
      }
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107ca5;
    uVar39 = (*_DAT_)();
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = *(undefined8 *)(param_3 + 0x38);
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = uVar14;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined4 *)(param_3 + 0x30);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107cd6;
    iVar6 = func_0x(auStack_1788,200,0xdb2020,uVar39);
    uVar39 = extraout_XMM0_Qa_53;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107ced;
      uVar39 = func_0x(0xdaf840,0x23e6,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107d16;
    uVar39 = func_0x(uVar39,param_4,auStack_1788,&param_5);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107d3f;
    uVar39 = func_0x(uVar39,param_4,auStack_2ec8,&param_5);
    cVar4 = *(char *)(param_3 + 0x16);
  }
  if (cVar4 == -0x23) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107d61;
    func_0x(param_3,auStack_1318,400);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107d69;
    uVar39 = func_0x(param_3);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107d72;
    uVar14 = (*_DAT_)();
    *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = auStack_1318;
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = uVar39;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107d9e;
    iVar6 = func_0x(auStack_9b8,600,0xdb1fa0,uVar14);
    uVar39 = extraout_XMM0_Qa_54;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107db9;
      uVar39 = func_0x(0xdaf840,0x23fc,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107de2;
    uVar39 = func_0x(uVar39,param_4,auStack_9b8,&param_5);
    cVar4 = *(char *)(param_3 + 0x16);
  }
  if (cVar4 == -0x21) {
    uVar9 = *(undefined4 *)(param_3 + 0x28);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107df9;
    uVar39 = (*_DAT_)();
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = uVar9;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = *(undefined4 *)(param_3 + 0x18);
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined8 *)(param_3 + 0x20);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107e29;
    iVar6 = func_0x(auStack_2738,0x400,0xdb1d90,uVar39);
    uVar39 = extraout_XMM0_Qa_55;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107e47;
      uVar39 = func_0x(0xdaf840,0x2410,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107e79;
    func_0x(uVar39,param_4,auStack_2738,&param_5);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107e85;
    func_0x(auStack_3fc8);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107e92;
    func_0x(auStack_4188);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107e9e;
    func_0x(auStack_42c8);
    if (*psStack_42d8 != 0) {
      UNRECOVERED_JUMPTABLE_00 = *(code **)(_DAT_ + 0x20);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x107ebb;
      (*UNRECOVERED_JUMPTABLE_00)();
      uVar38 = *(int *)(param_3 + 0x18) - 0x11;
      if (uVar38 < 0x23) {
        uVar23 = (ulonglong)*(byte *)((longlong)(int)uVar38 + 0x109c58);
        UNRECOVERED_JUMPTABLE_00 = (code *)((ulonglong)*(uint *)(uVar23 * 4 + 0x109c3c) - 0x1a77ca0)
        ;
                    /* WARNING: Could not emulate address calculation at 0x00107ed8 */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(uVar23,UNRECOVERED_JUMPTABLE_00);
        return;
      }
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10856e;
    uVar39 = func_0x(auStack_3fc8);
    cVar4 = *(char *)(param_3 + 0x16);
  }
  if (cVar4 == -0x20) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10857d;
    uVar39 = (*_DAT_)();
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108598;
    iVar6 = func_0x(auStack_ff8,400,0xdb2480,uVar39);
    uVar39 = extraout_XMM0_Qa_56;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1085b3;
      uVar39 = func_0x(0xdaf840,0x24de,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1085dc;
    uVar39 = func_0x(uVar39,param_4,auStack_ff8,&param_5);
    cVar4 = *(char *)(param_3 + 0x16);
  }
  if (cVar4 == -0x1f) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1085ed;
    uVar39 = func_0x(param_3);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1085f6;
    uVar14 = (*_DAT_)();
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = uVar39;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108616;
    iVar6 = func_0x(auStack_508,600,0xdb2500,uVar14);
    uVar39 = extraout_XMM0_Qa_57;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108631;
      uVar39 = func_0x(0xdaf840,0x24f0,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10865a;
    uVar39 = func_0x(uVar39,param_4,auStack_508,&param_5);
    cVar4 = *(char *)(param_3 + 0x16);
  }
  if (cVar4 == -0x19) {
    sVar21 = *(short *)(param_3 + 0x18);
    if ((sVar21 != 3) && (sVar21 != 4)) {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10869c;
      (*_DAT_)(1,0xe9ad50,0xe4c3a8,0x24fb);
      sVar21 = *(short *)(param_3 + 0x18);
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1086bd;
    iVar6 = func_0x(auStack_2b98,0x80,0xdb2570,sVar21);
    uVar39 = extraout_XMM0_Qa_58;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1086db;
      uVar39 = func_0x(0xdaf840,0x250c,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10870d;
    func_0x(uVar39,param_4,auStack_2b98,&param_5);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108721;
    uVar39 = func_0x(param_3 + 0x2c,auStack_35a8,auStack_4370);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10874a;
    uVar39 = func_0x(uVar39,param_4,auStack_35a8,&param_5);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108773;
    func_0x(uVar39,param_4,0xdb25d0,&param_5);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108787;
    uVar39 = func_0x(param_3 + 0x38,auStack_35a8,auStack_4370);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1087b0;
    uVar39 = func_0x(uVar39,param_4,auStack_35a8,&param_5);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1087d9;
    func_0x(uVar39,param_4,0xdb22c8,&param_5);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1087ed;
    uVar39 = func_0x(param_3 + 0x44,auStack_35a8,auStack_4370);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108816;
    func_0x(uVar39,param_4,auStack_35a8,&param_5);
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined8 *)(param_3 + 0x24);
    uVar39 = *(undefined8 *)(param_3 + 0x1c);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10883b;
    iVar6 = func_0x(auStack_2b98,0x80,0xdb22f0,uVar39);
    uVar39 = extraout_XMM0_Qa_59;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108852;
      uVar39 = func_0x(0xdaf840,0x2527,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10887b;
    func_0x(uVar39,param_4,auStack_2b98,&param_5);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108891;
    func_0x(param_3 + 0x74,auStack_2f68,0x25);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1088aa;
    func_0x(param_3 + 0x84,auStack_2f1e,0x25);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1088be;
    func_0x(param_3 + 0x50,auStack_35a8,auStack_4370);
    *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = auStack_35a8;
    *(undefined **)(&stack0xffffffffffffffe0 + lVar11) = auStack_2f1e;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1088f5;
    iVar6 = func_0x(auStack_15f8,0x16c,0xdb2360,auStack_2f68);
    uVar39 = extraout_XMM0_Qa_60;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10890c;
      uVar39 = func_0x(0xdaf840,0x2540,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108935;
    uVar39 = func_0x(uVar39,param_4,auStack_15f8,&param_5);
  }
  if (*(char *)(param_3 + 0x16) == -0x18) {
    if (*(short *)(param_3 + 0x18) != 3) {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108969;
      (*_DAT_)(1,0xe9adc8,0xe4c3a8,0x2549);
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10897b;
    func_0x(param_3 + 0x1e,0,auStack_4258);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108992;
    func_0x(param_3 + 4,auStack_32e0,auStack_4254);
    sVar21 = *(short *)(param_3 + 0x1c);
    uVar2 = *(undefined2 *)(param_3 + 0x18);
    *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = auStack_32e0;
    *(int *)(&stack0xffffffffffffffe0 + lVar11) = (int)sVar21;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1089c4;
    iVar6 = func_0x(auStack_1f38,0x80,0xdb23e0,uVar2);
    uVar39 = extraout_XMM0_Qa_61;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1089df;
      uVar39 = func_0x(0xdaf840,0x255b,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108a08;
    uVar39 = func_0x(uVar39,param_4,auStack_1f38,&param_5);
  }
  bVar5 = *(byte *)(param_3 + 0x16);
  if (bVar5 == 0xa2) {
    uVar33 = *(ushort *)(param_3 + 0x30);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108a1c;
    uVar39 = (*_DAT_)();
    *(uint *)(&stack0xffffffffffffffe0 + lVar11) = (uint)uVar33;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108a3b;
    iVar6 = func_0x(auStack_cd8,400,0xdb2210,uVar39);
    uVar39 = extraout_XMM0_Qa_62;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108a56;
      uVar39 = func_0x(0xdaf840,0x2579,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108a7f;
    uVar39 = func_0x(uVar39,param_4,auStack_cd8,&param_5);
    bVar5 = *(byte *)(param_3 + 0x16);
  }
  if (bVar5 == 0xd9) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108a99;
    uVar39 = func_0x(param_3,1,auStack_4250);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108abe;
    uVar39 = func_0x((longlong)aiStackX_20 + lVar11,param_4,uVar39,&param_5);
    bVar5 = *(byte *)(param_3 + 0x16);
  }
  if (bVar5 == 0xf1) {
    uVar14 = *(undefined8 *)(param_3 + 0x28);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108af8;
    func_0x(uVar39,param_4,0xdb2238,&param_5);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108afe;
    uVar39 = (*_DAT_)();
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = uVar14;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108b1e;
    iVar6 = func_0x(auStack_3330,0xe,0xc1faa0,uVar39);
    uVar39 = extraout_XMM0_Qa_63;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108b39;
      uVar39 = func_0x(0xdaf840,0x259c,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108b62;
    uVar39 = func_0x(uVar39,param_4,auStack_3330,&param_5);
    bVar5 = *(byte *)(param_3 + 0x16);
  }
  if (bVar5 == 0xf4) {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108b75;
    uVar39 = (*_DAT_)();
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined4 *)(param_3 + 0x18);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108b98;
    iVar6 = func_0x(auStack_2a98,0x80,0xdb2278,uVar39);
    uVar39 = extraout_XMM0_Qa_64;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108bb6;
      uVar39 = func_0x(0xdaf840,0x25b4,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108be8;
    func_0x(uVar39,param_4,auStack_2a98,&param_5);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108bee;
    uVar39 = (*_DAT_)();
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined4 *)(param_3 + 0x1c);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108c11;
    iVar6 = func_0x(auStack_2a98,0x80,0xdb22a0,uVar39);
    uVar39 = extraout_XMM0_Qa_65;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108c28;
      uVar39 = func_0x(0xdaf840,0x25bf,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108c51;
    func_0x(uVar39,param_4,auStack_2a98,&param_5);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108c68;
    uVar39 = func_0x(param_3 + 0x20,auStack_32b0,auStack_424c);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108c91;
    uVar39 = func_0x(uVar39,param_4,0xdb1ad8,&param_5);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108cba;
    uVar39 = func_0x(uVar39,param_4,auStack_32b0,&param_5);
    bVar5 = *(byte *)(param_3 + 0x16);
  }
  if (0x7e < bVar5) goto LAB_;
  if (bVar5 == 0x14) {
    iVar6 = *(int *)(param_3 + 0x30);
    if (iVar6 == 0) {
      uVar39 = 0xdb1af8;
      iVar6 = 0;
    }
    else if (iVar6 == 1) {
      uVar39 = 0xdb1b50;
      iVar6 = 0;
    }
    else {
      iVar6 = iVar6 + -2;
      if (iVar6 == 0) {
        uVar39 = 0xdb1a60;
      }
      else {
        if (iVar6 != 1) {
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xa41b88;
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108d0e;
          uVar39 = (*_DAT_)(1,0xe469e0,0xe4c3a8,0x25f7);
          goto LAB_;
        }
        uVar39 = 0xdb1b20;
      }
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108d54;
    uVar39 = func_0x(iVar6,param_4,uVar39,&param_5);
  }
LAB_:
  cVar4 = *(char *)(param_3 + 0x16);
  if ((cVar4 == '\v') || (cVar4 == '\f')) {
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108d8e;
    func_0x(uVar39,param_4,0xdb1a88,&param_5);
    uVar33 = *(ushort *)(param_3 + 0x36);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108d99;
    uVar39 = (*_DAT_)();
    *(uint *)(&stack0xffffffffffffffe0 + lVar11) = (uint)uVar33;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108db8;
    iVar6 = func_0x(auStack_3638,0xe,0xa766b8,uVar39);
    uVar39 = extraout_XMM0_Qa_66;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108dd6;
      uVar39 = func_0x(0xdaf840,0x2616,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108e08;
    uVar39 = func_0x(uVar39,param_4,auStack_3638,&param_5);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108e31;
    func_0x(uVar39,param_4,0xdb1a98,&param_5);
    sVar21 = *(short *)(param_3 + 0x1e);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108e3c;
    uVar39 = (*_DAT_)();
    *(int *)(&stack0xffffffffffffffe0 + lVar11) = (int)sVar21;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108e5b;
    iVar6 = func_0x(auStack_3638,0xe,0xa766b8,uVar39);
    uVar39 = extraout_XMM0_Qa_67;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108e72;
      uVar39 = func_0x(0xdaf840,0x262b,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108e9b;
    uVar39 = func_0x(uVar39,param_4,auStack_3638,&param_5);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108ec4;
    func_0x(uVar39,param_4,0xdb1ac0,&param_5);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108ed3;
    uVar39 = func_0x(param_3,auStack_41c0);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108ee9;
    uVar39 = func_0x(auStack_3638,uVar39,auStack_4330);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108f12;
    uVar39 = func_0x(uVar39,param_4,auStack_3638,&param_5);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108f3b;
    func_0x(uVar39,param_4,0xdb19e8,&param_5);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108f52;
    uVar39 = func_0x(auStack_3638,param_3 + 0x30,auStack_4330);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108f7b;
    uVar39 = func_0x(uVar39,param_4,auStack_3638,&param_5);
    cVar4 = *(char *)(param_3 + 0x16);
  }
  if (cVar4 == '\x13') {
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108fb1;
    uVar39 = func_0x(uVar39,param_4,0xdb1a00,&param_5);
    uVar38 = *(uint *)(param_3 + 0x30);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    if (uVar38 < 9) {
      uVar14 = *(undefined8 *)((longlong)(int)uVar38 * 8 + 0xad9da0);
    }
    else {
      uVar14 = 0xdb1a20;
    }
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108ff7;
    func_0x(uVar39,param_4,uVar14,&param_5);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x108ffd;
    uVar39 = (*_DAT_)();
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = *(undefined4 *)(param_3 + 0x30);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109020;
    iVar6 = func_0x(auStack_3248,100,0xdb1a40,uVar39);
    uVar39 = extraout_XMM0_Qa_68;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10903e;
      uVar39 = func_0x(0xdaf840,0x267b,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109070;
    func_0x(uVar39,param_4,auStack_3248,&param_5);
    uStack_4300 = *(undefined4 *)(param_3 + 0x40);
    uStack_42fc = *(undefined2 *)(param_3 + 0x44);
    uStack_42fa = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109099;
    uVar39 = func_0x(&uStack_4300);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1090a2;
    uVar14 = (*_DAT_)();
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = uVar39;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1090c2;
    iVar6 = func_0x(auStack_3248,100,0xc1faa0,uVar14);
    uVar39 = extraout_XMM0_Qa_69;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1090d9;
      uVar39 = func_0x(0xdaf840,0x268a,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109102;
    uVar39 = func_0x(uVar39,param_4,auStack_3248,&param_5);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10912b;
    func_0x(uVar39,param_4,0xdb1948,&param_5);
    uVar39 = *(undefined8 *)(param_3 + 0x38);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109135;
    uVar14 = (*_DAT_)();
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = uVar39;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109155;
    iVar6 = func_0x(auStack_3248,100,0xc1faa0,uVar14);
    uVar39 = extraout_XMM0_Qa_70;
    if (iVar6 < 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10916c;
      uVar39 = func_0x(0xdaf840,0x26a1,iVar6);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109195;
    uVar39 = func_0x(uVar39,param_4,auStack_3248,&param_5);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1091be;
    func_0x(uVar39,param_4,0xdb1ac0,&param_5);
    uStack_4358 = *(undefined4 *)(param_3 + 0x50);
    uStack_4354 = *(undefined2 *)(param_3 + 0x54);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1091ee;
    uVar39 = func_0x(auStack_3578,&uStack_4358,auStack_432c);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109217;
    uVar39 = func_0x(uVar39,param_4,auStack_3578,&param_5);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109240;
    func_0x(uVar39,param_4,0xdb19e8,&param_5);
    uStack_4358 = *(undefined4 *)(param_3 + 0x48);
    uStack_4354 = *(undefined2 *)(param_3 + 0x4c);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109270;
    uVar39 = func_0x(auStack_3578,&uStack_4358,auStack_432c);
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109299;
    uVar39 = func_0x(uVar39,param_4,auStack_3578,&param_5);
    cVar4 = *(char *)(param_3 + 0x16);
  }
  if (cVar4 == '\x02') {
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1092ae;
    uVar33 = func_0x(param_3);
    cVar4 = '\x02';
    uVar39 = extraout_XMM0_Qa_71;
    if (1 < uVar33) {
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
      *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1092e8;
      func_0x(extraout_XMM0_Qa_71,param_4,0xdb1960,&param_5);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1092ee;
      uVar39 = (*_DAT_)();
      *(uint *)(&stack0xffffffffffffffe0 + lVar11) = (uint)uVar33;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10930d;
      iVar6 = func_0x(auStack_33a0,0xe,0xa766b8,uVar39);
      uVar39 = extraout_XMM0_Qa_72;
      if (iVar6 < 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109328;
        uVar39 = func_0x(0xdaf840,0x26e5,iVar6);
      }
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
      *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109351;
      uVar39 = func_0x(uVar39,param_4,auStack_33a0,&param_5);
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
      *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10937a;
      uVar39 = func_0x(uVar39,param_4,0xdb1978,&param_5);
      cVar4 = *(char *)(param_3 + 0x16);
    }
  }
  if (cVar4 == '|') {
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1093ac;
    uVar39 = func_0x(uVar39,param_4,0xdb19a0,&param_5);
    cVar4 = *(char *)(param_3 + 0x16);
  }
  if (cVar4 == '\x16') {
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
    uVar14 = 0xdb1d08;
    if (*(char *)(param_3 + 0x30) == '\0') {
      uVar14 = 0xdb1d30;
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1093ec;
    func_0x(uVar39,param_4,uVar14,&param_5);
  }
  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1093f4;
  iVar6 = func_0x(param_3);
  if ((iVar6 == 0) &&
     ((((cVar4 = *(char *)(param_3 + 0x17), cVar4 != '\t' && (1 < (byte)(cVar4 - 0x18U))) ||
       (*(char *)(param_3 + 0x16) != '\a')) || (*(short *)(param_3 + 0x1e) != 1)))) {
    if ((cVar4 != '\v') || (*(char *)(param_3 + 0x16) != '\a')) goto LAB_;
    iStack_42f0 = (*(ushort *)(param_3 + 0x30) >> 3) - 4;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109454;
    lVar12 = func_0x(param_3,auStack_41ba);
    uStack_42ec = *(undefined2 *)(lVar12 + 4);
    uVar33 = *(ushort *)(param_3 + 0x32);
    uVar39 = extraout_XMM0_Qa_73;
    if (uVar33 != 0) {
      do {
        iVar6 = (*(ushort *)(param_3 + 0x30) & 7) + (int)uVar23;
        bVar5 = *(byte *)(param_3 + 0x34);
        if (iVar6 == 3) {
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10950a;
          uVar39 = (*_DAT_)();
          *(uint *)(&stack0xffffffffffffffe0 + lVar11) = (uint)bVar5;
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109529;
          iVar6 = func_0x(auStack_3178,100,0xdb1bf8,uVar39);
          uVar39 = extraout_XMM0_Qa_76;
          if (iVar6 < 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109544;
            uVar39 = func_0x(0xdaf840,0x27f4,iVar6);
          }
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10948c;
          uVar39 = (*_DAT_)();
          if (iVar6 == 7) {
            *(uint *)(&stack0xffffffffffffffe0 + lVar11) = (uint)bVar5;
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1094e5;
            iVar6 = func_0x(auStack_3178,100,0xdb1bd0,uVar39);
            uVar39 = extraout_XMM0_Qa_75;
            if (iVar6 < 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109500;
              uVar39 = func_0x(0xdaf840,0x27e2,iVar6);
            }
          }
          else {
            *(uint *)(&stack0xffffffffffffffe8 + lVar11) = (uint)bVar5;
            *(int *)(&stack0xffffffffffffffe0 + lVar11) = iVar6;
            *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1094b4;
            iVar6 = func_0x(auStack_3178,100,0xdb1c20,uVar39);
            uVar39 = extraout_XMM0_Qa_74;
            if (iVar6 < 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1094d3;
              uVar39 = func_0x(0xdaf840,0x2808,iVar6);
            }
          }
        }
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
        *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
        *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109572;
        uVar39 = func_0x(uVar39,param_4,auStack_3178,&param_5);
        uVar38 = (int)uVar23 + 1;
        uVar23 = (ulonglong)uVar38;
      } while (uVar38 < uVar33);
    }
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
    *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1095a8;
    func_0x(uVar39,param_4,0xdb1c68,&param_5);
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1095c2;
    uVar39 = func_0x(auStack_3380,&iStack_42f0,auStack_4248);
    puVar32 = auStack_3380;
  }
  else {
    cVar4 = *(char *)(param_3 + 0x17);
    if (cVar4 == '\b') {
      uVar2 = *(undefined2 *)(param_3 + 0x30);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10986e;
      uVar39 = func_0x(param_3,auStack_419c,uVar2);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109883;
      puVar18 = (undefined4 *)func_0x(auStack_4196,uVar39);
      uStack_4398 = *puVar18;
      uStack_4394 = *(undefined2 *)(puVar18 + 1);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1098a7;
      func_0x(auStack_35c8,&uStack_4398,auStack_433c);
      uVar33 = *(ushort *)(param_3 + 0x32);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1098b2;
      uVar39 = (*_DAT_)();
      *(uint *)(&stack0xffffffffffffffe0 + lVar11) = (uint)uVar33;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1098d1;
      iVar6 = func_0x(auStack_3308,0x14,0xa766b8,uVar39);
      uVar39 = extraout_XMM0_Qa_78;
      if (iVar6 < 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1098ec;
        uVar39 = func_0x(0xdaf840,0x2770,iVar6);
      }
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
      *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
      uVar14 = 0xdb1d78;
      if (*(char *)(param_3 + 0x34) != '\0') {
        uVar14 = 0xdb1c80;
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109923;
      uVar39 = func_0x(uVar39,param_4,uVar14,&param_5);
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
      *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10994c;
      uVar14 = func_0x(uVar39,param_4,auStack_3308,&param_5);
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
      *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
      uVar39 = 0xdb1ca0;
    }
    else {
      if (cVar4 != '\t') {
        if (cVar4 == '\v') {
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109637;
          lVar12 = func_0x(param_3,0,&uStack_436c);
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109648;
          uStack_4368 = func_0x(param_3,1,&uStack_436c);
          uVar38 = uStack_436c;
          if (uStack_436c != 0) {
            do {
              lVar29 = uStack_4368;
              uVar33 = *(ushort *)(param_3 + 0x38);
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109677;
              uVar39 = func_0x(param_3,auStack_41b4,(uint)uVar33 + (int)uVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109686;
              puVar18 = (undefined4 *)func_0x(auStack_41ae,uVar39);
              uStack_4398 = *puVar18;
              uStack_4394 = *(undefined2 *)(puVar18 + 1);
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1096aa;
              func_0x(auStack_35c8,&uStack_4398,auStack_433c);
              pbVar13 = (byte *)(uVar23 + lVar12);
              bVar5 = *(byte *)(uVar23 + lVar29);
              bVar1 = *pbVar13;
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1096c2;
              uVar39 = (*_DAT_)();
              *(uint *)(&stack0xffffffffffffffe8 + lVar11) = (uint)bVar5;
              *(uint *)(&stack0xffffffffffffffe0 + lVar11) = (uint)bVar1;
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1096e5;
              iVar6 = func_0x(auStack_2808,100,0xdb1d58,uVar39);
              uVar39 = extraout_XMM0_Qa_77;
              if (iVar6 < 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109700;
                uVar39 = func_0x(0xdaf840,0x2738,iVar6);
                uVar38 = uStack_436c;
              }
              psVar36 = psStack_4338;
              *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
              *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
              *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10973c;
              uVar39 = func_0x(uVar39,psStack_4338,auStack_2808,&param_5);
              bVar5 = *(byte *)(uVar23 + lVar29) & 0x40;
              if (bVar5 == 0) {
                if ((*pbVar13 & 0x40) != 0) goto LAB_;
              }
              else {
                if ((*pbVar13 & 0x40) == 0) {
                  uVar14 = 0xdb1d78;
                }
                else {
LAB_:
                  if (bVar5 != 0) goto LAB_;
                  uVar14 = 0xdb1c80;
                }
                *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
                *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
                *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
                *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109789;
                uVar39 = func_0x(uVar39,psVar36,uVar14,&param_5);
              }
LAB_:
              *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
              *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
              *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1097b7;
              func_0x(uVar39,psVar36,auStack_35c8,&param_5);
              uVar7 = (int)uVar23 + 1;
              uVar23 = (ulonglong)uVar7;
              param_3 = lStack_43b8;
            } while (uVar7 < uVar38);
          }
          goto LAB_;
        }
        if ((cVar4 != '\x18') && (cVar4 != '\x19')) {
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar11) = 0xa41b88;
          *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109624;
          (*_DAT_)(1,0xe469e0,0xe4c3a8,0x27be);
          goto LAB_;
        }
      }
      uVar2 = *(undefined2 *)(param_3 + 0x30);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1097e6;
      uVar39 = func_0x(param_3,auStack_41a8,uVar2);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1097fb;
      puVar18 = (undefined4 *)func_0x(auStack_41a2,uVar39);
      uStack_4398 = *puVar18;
      uStack_4394 = *(undefined2 *)(puVar18 + 1);
      *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10981f;
      uVar14 = func_0x(auStack_35c8,&uStack_4398,auStack_433c);
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
      *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 1;
      uVar39 = 0xdb1ce0;
      if (*(char *)(param_3 + 0x34) != '\0') {
        uVar39 = 0xdb1cf8;
      }
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x109975;
    uVar39 = func_0x(uVar14,param_4,uVar39,&param_5);
    puVar32 = auStack_35c8;
  }
  *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0xff;
  *(longlong *)(&stack0xffffffffffffffe8 + lVar11) = (longlong)aiStackX_20 + lVar11;
  *(undefined4 *)(&stack0xffffffffffffffe0 + lVar11) = 0;
  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x10999e;
  func_0x(uVar39,param_4,puVar32,&param_5);
LAB_:
  *(undefined8 *)((longlong)&uStack_48 + lVar11) = 0x1099ad;
  func_0x(uStack_58 ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar11));
  return;
}

