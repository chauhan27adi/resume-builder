
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong lVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  func_0x();
  lVar1 = param_1[1];
  if (lVar1 != 0) {
    lVar2 = *(longlong *)(lVar1 + 8);
    if (lVar2 != 0) {
      (**(code **)(*(longlong *)(lVar2 + 8 + (longlong)*(int *)(*(longlong *)(lVar2 + 8) + 4)) +
                  0x10))();
    }
    (*_DAT_)(lVar1,0x10,param_3,param_4,uVar3);
  }
  lVar1 = *param_1;
  if (lVar1 != 0) {
    (**(code **)(*(longlong *)((longlong)*(int *)(*(longlong *)(lVar1 + 8) + 4) + lVar1 + 8) + 0x10)
    )();
  }
  return;
}

