
/* WARNING: Control flow encountered bad instruction data */

void FUN_(undefined8 *param_1)

{
  *param_1 = 0x2558d00;
  if (param_1[10] == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)((longlong)param_1 + 0xf4) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  (**(code **)(*(longlong *)param_1[10] + 0x20))
            ((longlong *)param_1[10],3 - (uint)(*(int *)(param_1 + 0x1f) != 0));
  if ((*(uint *)(param_1 + 0xd) & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(uint *)(param_1 + 0xd) & 0x40) == 0) {
    if (param_1[9] != 0) {
      func_0x();
      param_1[9] = 0;
    }
    func_0x(param_1 + 0x1a);
    *param_1 = 0x25598c8;
    *param_1 = 0x2594028;
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

