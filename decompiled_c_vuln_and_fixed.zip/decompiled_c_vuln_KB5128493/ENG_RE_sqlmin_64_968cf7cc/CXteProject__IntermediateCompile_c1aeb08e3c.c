
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  uint uVar1;
  uint uVar2;
  
  if ((*(int *)(param_1 + 0x14) != 2) || (*(longlong *)(*(longlong *)(param_1 + 0x18) + 8) == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(byte *)(param_1 + 0x50) & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong *)(param_1 + 0x98) == 0) {
    func_0x(param_1,*(undefined8 *)(*(longlong *)(param_1 + 0x18) + 8),
                    *(undefined8 *)(param_1 + 0x28),param_2,1,0,(uint *)(param_1 + 100),
                    (uint *)(param_1 + 0x68),param_4,0,*(undefined4 *)(param_1 + 0x60));
    uVar1 = *(uint *)(param_1 + 0x68);
    uVar2 = *(uint *)(param_1 + 100);
    if ((uVar2 == 0) != (uVar1 == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (uVar1 <= uVar2) {
      if (uVar2 == 0) {
        return;
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

