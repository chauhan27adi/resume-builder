
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_(longlong param_1)

{
  int *piVar1;
  int iVar2;
  
  if (*(int *)(param_1 + 0x10) == 0) {
    (*_DAT_)(1,0xa26878,0xa025d0,0x330,0);
  }
  LOCK();
  piVar1 = (int *)(param_1 + 0x10);
  iVar2 = *piVar1;
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  return iVar2 + 1;
}

