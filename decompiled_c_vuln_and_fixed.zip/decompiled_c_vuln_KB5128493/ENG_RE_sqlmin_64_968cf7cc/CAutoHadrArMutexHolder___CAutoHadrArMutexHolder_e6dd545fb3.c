
void FUN_(longlong *param_1)

{
  longlong lVar1;
  undefined auStack_278 [8];
  undefined4 uStack_270;
  undefined4 uStack_268;
  undefined4 **ppuStack_260;
  undefined *puStack_258;
  undefined8 uStack_250;
  undefined4 *puStack_248;
  undefined8 uStack_240;
  undefined auStack_238 [528];
  undefined8 uStack_28;
  undefined8 uStack_20;
  undefined4 auStack_18 [4];
  
  lVar1 = *param_1;
  if (lVar1 != 0) {
    *(undefined8 *)(lVar1 + 0x30) = 0;
    func_0x(lVar1,0);
    if ((DAT_ & 0x40) != 0) {
      ppuStack_260 = &puStack_248;
      uStack_270 = 0x10000;
      puStack_258 = auStack_238;
      uStack_268 = 0;
      puStack_248 = auStack_18;
      uStack_28 = 0;
      uStack_250 = 0;
      uStack_20 = 0;
      uStack_240 = 4;
      auStack_18[0] = 2;
      func_0x(auStack_278);
    }
  }
  return;
}

