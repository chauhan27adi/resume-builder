
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  *param_1 = 0x72a070;
  (*_DAT_)(param_1[0x90],2,param_3,param_4,0xfffffffffffffffe);
  param_1[0x58] = 0xaec2b0;
  func_0x(param_1 + 0x58,1);
  if (param_1[0x55] != 0) {
    (*_DAT_)();
  }
  func_0x(param_1 + 0x46);
  if (*(int *)(param_1 + 0x3d) == 1) {
    func_0x(param_1 + 0x3b,1);
  }
  param_1[0x3b] = 0x739b90;
  if (*(int *)(param_1 + 0x3d) == 3) {
    *(undefined4 *)(param_1 + 0x3d) = 0;
    func_0x(param_1[0x3c] + 0x530,1);
  }
  if (param_1[0x39] != 0) {
    (*_DAT_)();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

