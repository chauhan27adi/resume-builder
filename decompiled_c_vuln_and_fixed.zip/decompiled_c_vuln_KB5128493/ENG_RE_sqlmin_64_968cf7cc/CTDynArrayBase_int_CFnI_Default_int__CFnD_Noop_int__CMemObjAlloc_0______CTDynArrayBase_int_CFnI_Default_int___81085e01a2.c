
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  *(undefined4 *)(param_1 + 0xc) = 0;
  if (*(longlong *)(param_1 + 0x18) != 0) {
    (*_DAT_)();
    *(undefined8 *)(param_1 + 0x18) = 0;
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  return;
}

