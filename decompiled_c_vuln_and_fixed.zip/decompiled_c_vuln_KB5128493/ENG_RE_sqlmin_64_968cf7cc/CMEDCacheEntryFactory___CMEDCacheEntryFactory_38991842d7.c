
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  longlong lVar1;
  longlong unaff_GS_OFFSET;
  undefined auStack_38 [48];
  
  if (*(longlong *)(param_1 + 0x28) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  func_0x(auStack_38,0,0,0,_DAT_,0,0xfffffffffffffffe);
  func_0x(param_1);
  func_0x(auStack_38);
  lVar1 = *(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
           0x100);
  if (lVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(lVar1 + 0x22c) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong *)(param_1 + 0x38) == 0) {
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

