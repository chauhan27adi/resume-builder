
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  puVar1 = (undefined8 *)*param_1;
  if (puVar1 != (undefined8 *)0x0) {
    (*_DAT_)(puVar1[3]);
    (*_DAT_)(*puVar1,1,param_3,param_4,uVar2);
                    /* WARNING: Could not recover jumptable at 0x00100042. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*_DAT_)(puVar1,0x30);
    return;
  }
  return;
}

