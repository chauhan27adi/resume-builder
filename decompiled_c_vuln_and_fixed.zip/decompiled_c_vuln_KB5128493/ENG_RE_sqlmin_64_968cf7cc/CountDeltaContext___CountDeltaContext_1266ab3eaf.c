
void FUN_(longlong *param_1)

{
  if (*param_1 != 0) {
    if (*(int *)(param_1 + 1) != 0) {
      func_0x(*(longlong *)(*param_1 + 8) + 0x630,2);
      *(undefined4 *)(param_1 + 1) = 0;
    }
    *param_1 = 0;
  }
  return;
}

