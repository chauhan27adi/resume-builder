
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 *
FUN_(undefined8 *param_1,ulonglong param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  uVar1 = 0xfffffffffffffffe;
  *param_1 = 0x21077f0;
  (*_DAT_)();
  if ((param_2 & 1) != 0) {
    (*_DAT_)(param_1,0x48,param_3,param_4,uVar1);
  }
  return param_1;
}

