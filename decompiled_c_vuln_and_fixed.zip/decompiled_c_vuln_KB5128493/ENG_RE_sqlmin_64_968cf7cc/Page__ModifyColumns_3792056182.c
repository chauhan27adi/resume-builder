
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,longlong param_3,undefined4 param_4)

{
  longlong lVar1;
  undefined4 uVar2;
  uint uVar3;
  byte bVar4;
  uint uVar5;
  byte *pbVar6;
  int in_stack_00000040;
  undefined auStack_d8 [56];
  int iStack_a0;
  undefined4 uStack_9c;
  undefined8 uStack_90;
  ushort *puStack_88;
  int iStack_48;
  byte *pbStack_40;
  ulonglong uStack_38;
  
  uStack_38 = _DAT_ ^ (ulonglong)auStack_d8;
  uVar5 = 0;
  uStack_90 = 0;
  if (in_stack_00000040 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puStack_88 = (ushort *)(param_1 + (0xfff - (longlong)param_2) * 2);
  pbVar6 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - (longlong)param_2) * 2) + param_1);
  if ((*pbVar6 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  bVar4 = *pbVar6 & 0xe;
  iStack_a0 = 0;
  if (bVar4 == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((bVar4 - 10 & 0xf9) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_3 + 8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_9c = param_4;
  iStack_48 = param_2;
  pbStack_40 = pbVar6;
  if (*(int *)(param_3 + 0x28) != 0) {
    do {
      uVar3 = uVar5 * 2 + 1;
      lVar1 = (ulonglong)uVar3 + 6;
      uVar2 = *(undefined4 *)(*(longlong *)(param_3 + 0x40) + lVar1 * 4);
      func_0x(pbVar6 + *(ushort *)(*(longlong *)(param_3 + 0x30) + (ulonglong)uVar3 * 2),
                      uVar2,*(undefined8 *)(*(longlong *)(param_3 + 0x48) + lVar1 * 8),uVar2);
      uVar5 = uVar5 + 1;
    } while (uVar5 < *(uint *)(param_3 + 0x28));
  }
  bVar4 = *(byte *)((ulonglong)*puStack_88 + param_1);
  if ((bVar4 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  bVar4 = bVar4 & 0xe;
  if (bVar4 == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((bVar4 - 10 & 0xf9) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iStack_a0 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  bVar4 = *(byte *)((ulonglong)*puStack_88 + param_1);
  if ((bVar4 & 1) == 0) {
    if ((bVar4 >> 6 & 1) == 0) {
      func_0x(uStack_38 ^ (ulonglong)auStack_d8);
      return;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

