
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x188) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined8 *)(param_1 + 0x188) = 0;
  *(undefined8 *)(param_1 + 400) = 0;
  *(undefined4 *)(param_1 + 0x198) = 0;
  if (*(longlong *)(param_1 + 0x188) == 0) {
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

