
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(void)

{
  (*_DAT_)(1,0,0x234f8b8,0x56c,0x2166460);
  return;
}

