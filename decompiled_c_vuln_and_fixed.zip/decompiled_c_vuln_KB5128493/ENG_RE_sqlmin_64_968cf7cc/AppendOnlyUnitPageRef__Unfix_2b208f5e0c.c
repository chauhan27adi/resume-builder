
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  longlong lVar1;
  int iVar2;
  undefined8 uStack_18;
  undefined2 uStack_10;
  
  lVar1 = *param_1;
  if (lVar1 != 0) {
    func_0x(lVar1 + 0x98,(int)*(short *)((longlong)param_1 + 0xc),0);
    iVar2 = func_0x(lVar1);
    if (iVar2 != 0) {
      uStack_18 = 0;
      uStack_10 = 0;
      func_0x(_DAT_,*param_1,0,&uStack_18);
    }
  }
  if (*param_1 != 0) {
    if ((*(ushort *)(*param_1 + 0x62) >> 10 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (((byte)*(undefined2 *)(*param_1 + 0x62) >> 3 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((DAT_ & 0x80) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    func_0x(*param_1 + 0x98,(int)*(short *)((longlong)param_1 + 0xc));
    if (_DAT_ != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined2 *)((longlong)param_1 + 0xc) = 0;
    *param_1 = 0;
  }
  return;
}

