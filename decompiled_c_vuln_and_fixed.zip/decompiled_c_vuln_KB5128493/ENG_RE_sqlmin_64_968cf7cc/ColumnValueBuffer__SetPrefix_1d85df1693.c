
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2)

{
  byte *pbVar1;
  longlong *plVar2;
  bool bVar3;
  byte bVar4;
  ushort uVar5;
  int iVar6;
  int *piVar7;
  ulonglong *puVar8;
  longlong lVar9;
  ushort uVar10;
  uint uVar11;
  longlong lVar12;
  uint uVar13;
  ushort *puVar14;
  ulonglong uVar15;
  short sVar16;
  longlong lVar17;
  int iVar18;
  int *piVar19;
  longlong unaff_GS_OFFSET;
  undefined auStack_b28 [32];
  ulonglong *puStack_b08;
  undefined4 uStack_b00;
  int *piStack_af8;
  undefined4 uStack_af0;
  undefined auStack_ae8 [6];
  byte bStack_ae2;
  int *piStack_ae0;
  ulonglong uStack_ad8;
  short sStack_ad0;
  short sStack_ace;
  short sStack_ac8;
  short sStack_ac6;
  short sStack_ac4;
  ushort uStack_ac2;
  undefined8 uStack_ac0;
  longlong lStack_ab8;
  undefined8 uStack_ab0;
  undefined auStack_aa8 [16];
  undefined auStack_a98 [16];
  undefined8 uStack_a88;
  undefined8 uStack_a80;
  undefined8 uStack_a78;
  undefined4 uStack_50;
  ulonglong uStack_48;
  
  uStack_ab0 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_b28;
  iVar18 = 0;
  auStack_aa8 = ZEXT816(0);
  auStack_a98 = ZEXT816(0);
  uStack_a80 = 0;
  uStack_a78 = 0;
  uStack_50 = 0;
  uStack_a88 = 0x100000000;
  param_2[1] = (longlong)auStack_aa8;
  lStack_ab8 = param_1;
  if (*param_2 != 0) {
    func_0x(auStack_aa8);
  }
  if (*(int *)((longlong)param_2 + 0x14) == 0) {
    func_0x((longlong)param_2 + 0x12);
  }
  sStack_ad0 = *(short *)((longlong)param_2 + 0x12);
  sStack_ace = 0;
  sStack_ac8 = 0;
  sStack_ac6 = 0;
  uStack_ac2 = uStack_ac2 & 0xffe0;
  uVar15 = 0;
  uStack_ac0 = 0;
  while (uStack_ad8 = uVar15, sStack_ace != sStack_ad0) {
    sStack_ace = sStack_ace + 1;
    sStack_ac8 = sStack_ac8 + -1;
    sStack_ac6 = sStack_ac8 >> 0xf;
    sStack_ac4 = sStack_ace;
    if ((int)(uint)*(ushort *)(param_1 + 0x100) <= iVar18) break;
    lVar17 = uVar15 * 0x10;
    piVar19 = (int *)(lVar17 + 8 + *(longlong *)(param_1 + 0x108));
    _auStack_ae8 = CONCAT26(uStack_ac2,CONCAT24(sStack_ace,(int)sStack_ac8));
    piStack_ae0 = (int *)uStack_ac0;
    uVar5 = uStack_ac2;
    if ((uStack_ac2 & 0x10) != 0) {
      _auStack_ae8 = _auStack_ae8 & 0xffefffffffffffff;
      piStack_ae0 = (int *)0x0;
      uVar5 = 0;
    }
    if (param_2[1] == 0) {
      if (*(short *)(param_2 + 2) == 0) {
        if ((auStack_ae8._0_4_ & 0xc0000000) == 0x80000000) {
          iVar6 = func_0x((longlong)param_2 + 0x12);
          if (iVar6 == 0) goto LAB_;
          piVar7 = (int *)func_0x((longlong)param_2 + 0x3a,auStack_ae8,piVar19,&uStack_ad8);
        }
        else {
          pbVar1 = (byte *)param_2[3];
          bVar4 = *pbVar1;
          if ((bVar4 & 0x10) == 0) {
            if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) goto LAB_;
LAB_:
            if ((int)auStack_ae8._0_4_ < 0) {
              if (*(int *)((longlong)param_2 + 0x14) == 0) {
                *(undefined2 *)((longlong)param_2 + 0x12) = 0;
                uVar11 = *(uint *)(param_2 + 4);
                uVar15 = (ulonglong)uVar11;
                *(uint *)((longlong)param_2 + 0x24) = uVar11;
                bVar4 = *pbVar1;
                if ((bVar4 & 0x10) != 0) {
                  uVar11 = uVar11 + 2 + (*(ushort *)(pbVar1 + uVar15) + 7 >> 3);
                  uVar15 = (ulonglong)uVar11;
                  *(uint *)((longlong)param_2 + 0x24) = uVar11;
                  bVar4 = *pbVar1;
                }
                if ((bVar4 & 0x20) == 0) {
                  *(int *)((longlong)param_2 + 0x14) = (int)uVar15;
                  *(undefined2 *)((longlong)param_2 + 0x2c) = 0;
                  *(int *)(param_2 + 5) = (int)uVar15;
                }
                else {
                  puVar14 = (ushort *)(pbVar1 + uVar15);
                  uVar5 = *puVar14;
                  *(ushort *)((longlong)param_2 + 0x2c) = uVar5;
                  if (uVar5 == 0) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar9 = *(longlong *)
                                  (*(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                        lVar9 != 0)) &&
                       ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                        (*(char *)(lVar9 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        puStack_b08 = (ulonglong *)0x0;
                        (*_DAT_)(1,0x1726008,0x1845cd8,0x80f);
                      }
                    }
                    func_0x(param_2[3],3);
                    uVar15 = (ulonglong)*(uint *)((longlong)param_2 + 0x24);
                    uVar5 = *(ushort *)((longlong)param_2 + 0x2c);
                  }
                  uVar11 = (int)uVar15 + (uVar5 + 1) * 2;
                  *(uint *)(param_2 + 5) = uVar11;
                  if (0x1f9e < uVar11) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar9 = *(longlong *)
                                  (*(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                        lVar9 != 0 &&
                        ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                         (*(char *)(lVar9 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        puStack_b08 = (ulonglong *)0x0;
                        (*_DAT_)(1,0x1726008,0x1845cd8,0x816);
                      }
                    }
                    func_0x(param_2[3],4);
                    uVar5 = *(ushort *)((longlong)param_2 + 0x2c);
                    uVar11 = *(uint *)(param_2 + 5);
                  }
                  uVar15 = (ulonglong)uVar5;
                  uVar5 = puVar14[uVar15];
                  *(uint *)((longlong)param_2 + 0x14) = uVar5 & 0x7fff;
                  if ((uVar5 & 0x7fff) < uVar11) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar9 = *(longlong *)
                                  (*(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                        lVar9 != 0)) &&
                       ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                        (*(char *)(lVar9 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        puStack_b08 = (ulonglong *)0x0;
                        (*_DAT_)(1,0x1726008,0x1845cd8,0x81d);
                      }
                    }
                    func_0x(param_2[3],4);
                    uVar15 = (ulonglong)*(ushort *)((longlong)param_2 + 0x2c);
                  }
                  if ((short)puVar14[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
                    lVar9 = param_2[3];
                    do {
                      lVar12 = (ulonglong)*(uint *)((longlong)param_2 + 0x24) + lVar9;
                      if ((int)uVar15 == 1) {
                        uVar11 = *(uint *)(param_2 + 5);
                        uVar13 = uVar11;
LAB_:
                        if ((*(ushort *)(lVar12 + uVar15 * 2) & 0x7fff) < uVar11) goto LAB_;
                      }
                      else {
                        uVar11 = *(ushort *)(lVar12 + -2 + uVar15 * 2) & 0x7fff;
                        uVar13 = *(uint *)(param_2 + 5);
                        if (uVar13 <= uVar11) goto LAB_;
LAB_:
                        func_0x(lVar9,7);
                        uVar13 = *(uint *)(param_2 + 5);
                      }
                      if ((uVar11 < uVar13) || (*(uint *)((longlong)param_2 + 0x14) < uVar11))
                      goto LAB_;
                      lVar9 = param_2[3];
                      if (*(ushort *)(lVar9 + (ulonglong)uVar11) == 5) {
                        *(ushort *)((longlong)param_2 + 0x12) =
                             *(ushort *)((longlong)param_2 + 0x12) | 2;
                        *(short *)((longlong)param_2 + 0x2c) =
                             *(short *)((longlong)param_2 + 0x2c) + -1;
                        *(short *)((longlong)param_2 + 0x3a) = (short)uVar11;
                        lVar9 = (ulonglong)(uVar11 & 0xffff) + param_2[3];
                        uVar5 = *(ushort *)((longlong)param_2 + 0x3c) & 0xc7ff;
                        if ((*(ushort *)(lVar9 + 2) >> 0xe & 1) != 0) {
                          uVar5 = *(ushort *)(lVar9 + 2) & 0x3800 | uVar5;
                        }
                        *(ushort *)((longlong)param_2 + 0x3c) = uVar5;
                        *(ushort *)((longlong)param_2 + 0x3c) =
                             (uVar5 ^ *(ushort *)(lVar9 + 2)) & 0x7ff ^ uVar5;
                        uVar15 = (ulonglong)*(uint *)((longlong)param_2 + 0x14);
                        goto LAB_;
                      }
                      if (*(ushort *)(lVar9 + (ulonglong)uVar11) < 0x400) break;
                      *(ushort *)((longlong)param_2 + 0x12) =
                           *(ushort *)((longlong)param_2 + 0x12) | 1;
                      uVar5 = *(short *)((longlong)param_2 + 0x2c) - 1;
                      *(ushort *)((longlong)param_2 + 0x2c) = uVar5;
                      if ((uVar5 == 0) ||
                         (uVar15 = (ulonglong)uVar5, -1 < (short)puVar14[(ulonglong)(uVar5 - 1) + 1]
                         )) break;
                    } while( true );
                  }
                  uVar15 = (ulonglong)*(uint *)((longlong)param_2 + 0x14);
                }
LAB_:
                iVar6 = 0;
                if ((*(byte *)param_2[3] & 0x40) == 0) {
                  *(undefined4 *)((longlong)param_2 + 0x36) = 0;
                }
                else {
                  *(int *)((longlong)param_2 + 0x36) = (int)uVar15;
                  *(int *)((longlong)param_2 + 0x14) = (int)uVar15 + 0xe;
                  puVar8 = (ulonglong *)func_0x((longlong)param_2 + 0x12);
                  uVar10 = (ushort)(*puVar8 >> 0x30);
                  uVar5 = uVar10;
                  if ((((uint)(int)(short)uVar10 >> 1 ^ (int)(short)uVar10) & 0x2000) != 0) {
                    uVar5 = uVar10 & 0xdfff;
                    if ((uVar10 >> 0xe & 1) != 0) {
                      uVar5 = uVar10 | 0x2000;
                    }
                  }
                  if (uVar5 == 0xfffc) {
                    iVar6 = (int)((*puVar8 >> 0x20 & 0xffff) >> 5);
                  }
                  *(int *)((longlong)param_2 + 0x14) = *(int *)((longlong)param_2 + 0x14) + iVar6;
                  uVar15 = (ulonglong)*(uint *)((longlong)param_2 + 0x14);
                }
                iVar6 = (int)uVar15;
                if ((*(ulonglong *)((longlong)param_2 + 0x2e) != 0) &&
                   (*(ulonglong *)((longlong)param_2 + 0x2e) < uVar15 + param_2[3])) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     (((lVar9 = *(longlong *)
                                 (*(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                       lVar9 != 0 && (lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0)) &&
                      (*(char *)(lVar9 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      puStack_b08 = (ulonglong *)0x0;
                      (*_DAT_)(1,0x1726008,0x1845cd8,0x877);
                    }
                  }
                  func_0x(param_2[3],0x12);
                  iVar6 = *(int *)((longlong)param_2 + 0x14);
                }
                if (0x3f3b < iVar6 - 1U) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar9 = *(longlong *)
                                (*(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8 + (ulonglong)*_DAT_),
                      lVar9 != 0 &&
                      ((lVar9 = *(longlong *)(lVar9 + 0x60), lVar9 != 0 &&
                       (*(char *)(lVar9 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      puStack_b08 = (ulonglong *)0x0;
                      (*_DAT_)(1,0x1726008,0x1845cd8,0x87c);
                    }
                  }
                  func_0x(param_2[3],5);
                }
              }
LAB_:
              sVar16 = -auStack_ae8._0_2_;
              param_1 = lStack_ab8;
              uVar15 = uStack_ad8;
              if ((_auStack_ae8 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0) {
                bVar4 = *(byte *)param_2[3];
                if ((bVar4 & 0x10) == 0) {
                  if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
                    *piVar19 = *piStack_ae0;
                    piVar7 = piStack_ae0 + 1;
                    goto LAB_;
                  }
                }
                else if (((int)*(uint *)(param_2 + 4) <= (int)auStack_ae8._0_4_) ||
                        (*(ushort *)((byte *)param_2[3] + *(uint *)(param_2 + 4)) <
                         (ushort)auStack_ae8._4_2_)) goto LAB_;
              }
              if ((uint)*(ushort *)((longlong)param_2 + 0x2c) < (uint)(int)sVar16) {
                *piVar19 = 0;
                piVar7 = (int *)param_2[3];
              }
              else {
                lVar9 = (ulonglong)*(uint *)((longlong)param_2 + 0x24) + param_2[3];
                uVar11 = *(ushort *)(lVar9 + (longlong)sVar16 * 2) & 0x7fff;
                if (sVar16 == 1) {
                  uVar13 = *(uint *)(param_2 + 5);
LAB_:
                  if (uVar11 < uVar13) goto LAB_;
                }
                else {
                  uVar13 = *(ushort *)(lVar9 + -2 + (longlong)sVar16 * 2) & 0x7fff;
                  if (*(uint *)(param_2 + 5) <= uVar13) goto LAB_;
LAB_:
                  func_0x(param_2[3],7);
                }
                *piVar19 = uVar11 - uVar13;
                piVar7 = (int *)((ulonglong)uVar13 + param_2[3]);
                param_1 = lStack_ab8;
                uVar15 = uStack_ad8;
              }
            }
            else if ((_auStack_ae8 & (undefined  [16])0x8000000000000) == (undefined  [16])0x0) {
              if ((_auStack_ae8 & (undefined  [16])0x10000000000000) == (undefined  [16])0x0) {
LAB_:
                *piVar19 = 0;
                piVar7 = (int *)((longlong)(int)auStack_ae8._0_4_ + param_2[3]);
              }
              else {
                if ((bVar4 & 0x10) == 0) {
                  if ((1 << (bVar4 & 0xe) & 0x1105U) == 0) goto LAB_;
                }
                else if (((int)auStack_ae8._0_4_ < (int)*(uint *)(param_2 + 4)) &&
                        ((ushort)auStack_ae8._4_2_ <= *(ushort *)(pbVar1 + *(uint *)(param_2 + 4))))
                goto LAB_;
LAB_:
                *piVar19 = *piStack_ae0;
                piVar7 = piStack_ae0 + 1;
              }
            }
            else {
              bVar4 = pbVar1[(int)auStack_ae8._0_4_];
              *piVar19 = 1;
              piVar7 = (int *)0x14aaa44;
              if ((bVar4 & (byte)(1 << (bStack_ae2 & 7))) == 0) {
                piVar7 = (int *)0x14ab068;
              }
            }
          }
          else {
            uVar11 = *(uint *)(param_2 + 4);
            if ((int)auStack_ae8._0_4_ < (int)uVar11) {
              if ((uint)*(ushort *)(pbVar1 + uVar11) < (uint)(ushort)auStack_ae8._4_2_)
              goto LAB_;
              uVar13 = (ushort)auStack_ae8._4_2_ - 1;
              uVar5 = (ushort)(pbVar1[(ulonglong)(uVar13 >> 3) + (ulonglong)uVar11 + 2] >>
                              ((byte)uVar13 & 7));
              bVar3 = true;
            }
            else {
LAB_:
              uVar5 = ~(uVar5 >> 4);
              bVar3 = false;
            }
            piVar7 = (int *)0x0;
            if ((uVar5 & 1) == 0) {
              if ((bVar3) ||
                 ((_auStack_ae8 & (undefined  [16])0x10000000000000) == (undefined  [16])0x0))
              goto LAB_;
              goto LAB_;
            }
            *piVar19 = 0;
          }
        }
      }
      else {
        uStack_ad8 = uVar15 & 0xffffffff00000000;
        puStack_b08 = &uStack_ad8;
        piVar7 = (int *)func_0x((longlong)param_2 + 0x12,auStack_ae8,0,piVar19);
        if ((((*(short *)(param_2 + 2) != 0) &&
             (plVar2 = (longlong *)param_2[4], plVar2 != (longlong *)0x0)) && (*plVar2 != 0)) &&
           (((_auStack_ae8 & (undefined  [16])0x8000000000000) == (undefined  [16])0x0 &&
            ((uStack_ad8 & 1) == 0)))) {
          if ((piVar7 == (int *)0x0) || (piVar7 == (int *)0x14aaa44)) {
LAB_:
            piVar7 = (int *)0x0;
            *piVar19 = 0;
          }
          else {
            uStack_af0 = (undefined4)uStack_ad8;
            uStack_b00 = 0;
            puStack_b08 = (ulonglong *)0x0;
            piStack_af8 = piVar19;
            piVar7 = (int *)func_0x(plVar2,auStack_ae8,piVar7,*piVar19);
          }
        }
      }
    }
    else {
      piVar7 = (int *)func_0x(param_2[1] + 0x18,auStack_ae8,piVar19);
    }
LAB_:
    *(int **)(lVar17 + *(longlong *)(param_1 + 0x108)) = piVar7;
    iVar18 = iVar18 + 1;
    uVar15 = uVar15 + 1;
  }
  param_2[1] = 0;
  if (uStack_a88._2_2_ != 0) {
    (*_DAT_)(uStack_a80);
    (*_DAT_)(uStack_a78);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_b28);
  return;
}

