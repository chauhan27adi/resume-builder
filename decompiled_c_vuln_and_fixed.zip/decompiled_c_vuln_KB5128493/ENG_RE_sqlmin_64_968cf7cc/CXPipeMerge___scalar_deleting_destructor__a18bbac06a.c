
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_(undefined8 *param_1,uint param_2,undefined8 param_3,undefined8 param_4)

{
  *param_1 = 0x1c478a8;
  *param_1 = 0x1c654d0;
  if ((param_1[0xf] != 0) && (0x20 < *(int *)(param_1 + 0xe))) {
    (*_DAT_)(param_1[0xd],4,param_3,param_4,0xfffffffffffffffe);
    param_1[0xd] = 0;
  }
  if ((param_2 & 1) != 0) {
    (*_DAT_)(param_1,0xb8);
  }
  return param_1;
}

