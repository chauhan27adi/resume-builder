
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00173b64) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_(undefined8 *param_1,undefined8 param_2,longlong param_3)

{
  undefined8 uVar1;
  
  func_0x();
  *param_1 = 0x242b808;
  *(undefined4 *)(param_1 + 0xf) = *(undefined4 *)(param_3 + 0x60);
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  *(undefined4 *)(param_1 + 0x13) = *(undefined4 *)(param_3 + 0x70);
  *(undefined4 *)((longlong)param_1 + 0x9c) = *(undefined4 *)(param_3 + 0x74);
  *(undefined4 *)(param_1 + 0x14) = 0;
  uVar1 = (*_DAT_)(8,param_1[0xc],0x24a3228,0x4a,1);
  param_1[8] = uVar1;
  uVar1 = (**(code **)(***(longlong ***)(param_3 + 0x18) + 0x150))
                    (**(longlong ***)(param_3 + 0x18),param_2);
  *(undefined8 *)param_1[8] = uVar1;
  *(int *)(param_1 + 0xb) = *(int *)(param_1 + 0xb) + 1;
  *(int *)((longlong)param_1 + 0x7c) = *(int *)(param_1 + 0xf);
  if (*(int *)(param_1 + 0xf) == 0) {
    *(undefined4 *)(param_1 + 0x15) = 0x6803;
    param_1[0x16] = 0;
    param_1[0x17] = 0;
    *(undefined4 *)(param_1 + 0x18) = 0;
    return param_1;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

