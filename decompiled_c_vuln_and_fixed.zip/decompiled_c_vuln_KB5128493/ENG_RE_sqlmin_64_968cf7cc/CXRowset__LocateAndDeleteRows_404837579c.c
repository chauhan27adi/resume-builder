
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(void)

{
  (*_DAT_)(1,0x20d2764,0x20e9a88,0x350,0);
  return 0;
}

