
void FUN_(longlong *param_1)

{
  longlong lVar1;
  longlong lVar2;
  int iVar3;
  longlong lStack_20;
  int iStack_18;
  
  lVar1 = *param_1;
  if (lVar1 != 0) {
    lVar2 = param_1[1];
    iStack_18 = 0;
    lStack_20 = lVar2;
    func_0x(param_1,&lStack_20,*(undefined *)(lVar2 + 0x47),0x1a7adb0,0xfffffffffffffffe);
    (**(code **)(lVar2 + 200))(lVar1);
    lVar1 = lStack_20;
    for (iVar3 = iStack_18; iVar3 != 0; iVar3 = iVar3 + -1) {
      *(undefined8 *)(lVar1 + 0x30) = 0;
      iStack_18 = iVar3;
      func_0x(lVar1,0);
    }
  }
  return;
}

