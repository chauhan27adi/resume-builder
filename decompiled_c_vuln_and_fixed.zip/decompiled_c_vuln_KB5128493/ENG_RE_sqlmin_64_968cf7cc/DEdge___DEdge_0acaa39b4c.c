
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  longlong **pplVar1;
  undefined8 *puVar2;
  ulonglong *puVar3;
  longlong *plVar4;
  longlong *plVar5;
  ulonglong *puVar6;
  undefined8 *puVar7;
  char cVar8;
  uint uVar9;
  int iVar10;
  ulonglong uVar11;
  longlong **pplVar12;
  undefined8 uVar13;
  ulonglong uVar14;
  longlong lVar15;
  longlong lVar16;
  ulonglong *puVar17;
  ulonglong uVar18;
  longlong unaff_GS_OFFSET;
  bool bVar19;
  undefined auStackX_10 [8];
  ulonglong uStackX_18;
  ulonglong uStackX_20;
  ulonglong uStack_78;
  ulonglong uStack_70;
  undefined8 uStack_68;
  ulonglong *puStack_60;
  undefined4 uStack_58;
  
  uStack_68 = 0xfffffffffffffffe;
  plVar4 = *(longlong **)(param_1 + 0x30);
  if (plVar4 == (longlong *)0x0) goto LAB_;
  LOCK();
  plVar5 = plVar4 + 5;
  iVar10 = *(int *)plVar5;
  *(int *)plVar5 = *(int *)plVar5 + -1;
  UNLOCK();
  if (iVar10 != 1) goto LAB_;
  if (plVar4[3] != 0) {
    func_0x();
    goto LAB_;
  }
  uVar13 = 1;
  if (*(int *)(plVar4 + 0x17) == 2) {
    puVar17 = (ulonglong *)(plVar4[0x14] + 0x1358);
    uStack_58 = 0;
    uVar11 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
    puStack_60 = puVar17;
    if (*(int *)puVar17 == 0) {
      LOCK();
      uVar18 = *puVar17;
      if (uVar18 == 0) {
        *puVar17 = uVar11;
      }
      UNLOCK();
      if (uVar18 != 0) goto LAB_;
    }
    else {
LAB_:
      lVar15 = 0;
      uVar18 = 0;
      if (((byte)*_DAT_ & 0x84) == 0x84) {
        lVar16 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        if ((lVar16 != 0) && (*(longlong *)(lVar16 + 0x110) == lVar16)) {
          lVar15 = *(longlong *)(lVar16 + 0x100);
        }
        uVar18 = 0;
        if ((lVar15 != 0) && (uVar18 = _DAT_, *_DAT_ != 0)) {
          (*_DAT_)(&uStackX_18);
          uVar18 = uStackX_18;
        }
      }
      if (*(char *)(_DAT_ + 199) < '\0') {
        func_0x(puVar17,lVar15,uVar11);
      }
      else {
        func_0x(puVar17,uVar11);
      }
      if (lVar15 != 0) {
        uVar11 = _DAT_;
        if (*_DAT_ != 0) {
          (*_DAT_)(&uStackX_20);
          uVar11 = uStackX_20;
        }
        lVar16 = uVar11 - uVar18;
        if (uVar11 < uVar18) {
          lVar16 = 0;
        }
        *(longlong *)(lVar15 + 0xc78) = *(longlong *)(lVar15 + 0xc78) + lVar16;
      }
    }
    uStack_58 = 1;
    plVar5 = (longlong *)plVar4[1];
    lVar15 = *plVar4;
    *(longlong **)(lVar15 + 8) = plVar5;
    *plVar5 = lVar15;
    plVar4[1] = 0;
    *plVar4 = 0;
    func_0x(&puStack_60);
  }
  uVar11 = 0;
  lVar15 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  if ((((lVar15 == 0) || (*(longlong *)(lVar15 + 0x110) != lVar15)) ||
      (*(longlong *)(lVar15 + 0x100) == 0)) ||
     (*(longlong **)(*(longlong *)(lVar15 + 0x100) + 0x210) != plVar4)) {
    if (((plVar4[0x15] != 0) && (*(longlong *)(plVar4[0x15] + 0xf0) != 0)) &&
       (cVar8 = (*_DAT_)(), cVar8 == '\0')) {
      lVar15 = *(longlong *)(plVar4[0x15] + 0xf0);
      pplVar1 = (longlong **)(plVar4 + -1);
      func_0x(pplVar1,0);
      puVar17 = *(ulonglong **)(lVar15 + 0x7e0);
      uVar18 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
      if (*(int *)(puVar17 + 5) == 0) {
        LOCK();
        bVar19 = puVar17[5] == 0;
        if (bVar19) {
          puVar17[5] = uVar18;
        }
        UNLOCK();
        if (!bVar19) goto LAB_;
      }
      else {
LAB_:
        uVar14 = uVar11;
        if (((byte)*_DAT_ & 0x84) == 0x84) {
          lVar15 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          if ((lVar15 != 0) && (*(longlong *)(lVar15 + 0x110) == lVar15)) {
            uVar14 = *(ulonglong *)(lVar15 + 0x100);
          }
          if ((uVar14 != 0) && (uVar11 = _DAT_, *_DAT_ != 0)) {
            (*_DAT_)(&uStack_78);
            uVar11 = uStack_78;
          }
        }
        if (*(char *)(_DAT_ + 199) < '\0') {
          func_0x(puVar17 + 5,uVar14,uVar18);
        }
        else {
          func_0x(puVar17 + 5,uVar18);
        }
        if (uVar14 != 0) {
          uVar18 = _DAT_;
          if (*_DAT_ != 0) {
            (*_DAT_)(&uStack_70);
            uVar18 = uStack_70;
          }
          lVar15 = uVar18 - uVar11;
          if (uVar18 < uVar11) {
            lVar15 = 0;
          }
          *(longlong *)(uVar14 + 0xc78) = *(longlong *)(uVar14 + 0xc78) + lVar15;
        }
      }
      if (puVar17[1] < *puVar17) {
        if (*(char *)(puVar17[4] + 0x16bc) == '\0') {
          *pplVar1 = (longlong *)puVar17[0x10];
          if (puVar17[0x10] == 0) {
            puVar17[0x11] = (ulonglong)pplVar1;
          }
          puVar17[0x10] = (ulonglong)pplVar1;
        }
        else {
          pplVar12 = (longlong **)
                     (puVar17 + ((ulonglong)(*(uint *)(puVar17 + 0x93) & 0x3f) + 9) * 2);
          *pplVar1 = *pplVar12;
          if (*pplVar12 == (longlong *)0x0) {
            pplVar12[1] = (longlong *)pplVar1;
          }
          *pplVar12 = (longlong *)pplVar1;
          puVar17[0x93] = puVar17[0x93] + 1;
          (*_DAT_)(pplVar1,0x1000,1,auStackX_10);
        }
        uVar11 = puVar17[0x92] + 1;
        puVar17[1] = puVar17[1] + 1;
        if ((*(char *)(puVar17[4] + 0x16bc) == '\0') && (0x1f < uVar11)) {
          uVar9 = func_0x(puVar17[4],pplVar1);
          puVar3 = puVar17 + 0x10;
          uVar11 = *puVar3;
          puVar6 = (ulonglong *)puVar17[0x11];
          if ((puVar6 != puVar3) && (puVar6 != (ulonglong *)0x0)) {
            *puVar6 = puVar17[(ulonglong)uVar9 + 0x94];
            puVar17[(ulonglong)uVar9 + 0x94] = uVar11;
          }
          *puVar3 = 0;
          puVar17[0x11] = (ulonglong)puVar3;
          uVar18 = 1L << ((byte)uVar9 & 0x3f);
          uVar11 = 0;
          if ((puVar17[0xd4] & uVar18) == 0) {
            puVar17[0xd4] = uVar18 | puVar17[0xd4];
          }
        }
        puVar17[0x92] = uVar11;
        if ((*_DAT_ != '\0') && (iVar10 = (*_DAT_)(), iVar10 == (iVar10 / 5) * 5)) {
          func_0x();
        }
        puVar17[5] = 0;
      }
      else {
        if ((*_DAT_ != '\0') && (iVar10 = (*_DAT_)(), iVar10 == (iVar10 / 5) * 5)) {
          func_0x();
        }
        puVar17[5] = 0;
        (*(code *)puVar17[6])(pplVar1);
      }
      goto LAB_;
    }
    if ((*_DAT_ & 0x1000) != 0) {
      (*_DAT_)(plVar4 + -1,0,0x8000);
      goto LAB_;
    }
    if (plVar4 + -1 == (longlong *)0x0) goto LAB_;
  }
  else {
    uVar13 = 0;
  }
  func_0x(plVar4 + -1,uVar13);
LAB_:
  puVar7 = *(undefined8 **)(param_1 + 0x28);
  if (puVar7 != (undefined8 *)0x0) {
    puVar2 = puVar7 + 3;
    *(int *)puVar2 = *(int *)puVar2 + -1;
    if (*(int *)puVar2 == 0) {
      (**(code **)*puVar7)();
    }
  }
  return;
}

