
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Possible PIC construction at 0x0010001a: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x00100020) */

void FUN_(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

