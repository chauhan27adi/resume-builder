
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1)

{
  undefined8 *puVar1;
  int iVar2;
  longlong lVar3;
  
  iVar2 = 0;
  *param_1 = 0x1cbf720;
  if (0 < *(int *)((longlong)param_1 + 0x14)) {
    lVar3 = 0;
    do {
      puVar1 = *(undefined8 **)(lVar3 + param_1[3]);
      if (puVar1 != (undefined8 *)0x0) {
        (**(code **)*puVar1)(puVar1,1);
      }
      iVar2 = iVar2 + 1;
      lVar3 = lVar3 + 8;
    } while (iVar2 < *(int *)((longlong)param_1 + 0x14));
  }
                    /* WARNING: Could not recover jumptable at 0x00100065. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*_DAT_)(param_1[3]);
  return;
}

