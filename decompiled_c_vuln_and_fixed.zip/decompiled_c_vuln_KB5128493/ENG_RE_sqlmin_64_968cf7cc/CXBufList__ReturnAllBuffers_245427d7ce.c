
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  int iVar3;
  int iVar4;
  longlong *plVar5;
  undefined8 uStackX_8;
  
  iVar4 = 0;
  plVar5 = (longlong *)0x0;
  while( true ) {
    do {
      if (*(int *)(param_1 + 0x18) <= iVar4) {
        return;
      }
      while ((plVar5 == (longlong *)0x0 &&
             (plVar5 = *(longlong **)(*(longlong *)(param_1 + 0x20) + (longlong)iVar4 * 8),
             plVar5 == (longlong *)0x0))) {
        iVar4 = iVar4 + 1;
        if (*(int *)(param_1 + 0x18) <= iVar4) {
          return;
        }
      }
      plVar1 = plVar5 + 1;
      plVar5 = (longlong *)*plVar5;
      iVar3 = iVar4 + 1;
      if (plVar5 != (longlong *)0x0) {
        iVar3 = iVar4;
      }
      iVar4 = iVar3;
    } while (*plVar1 == 0);
    lVar2 = *(longlong *)(*(longlong *)(*(longlong *)(param_1 + 8) + 0x20) + 0xb0);
    if (lVar2 == 0) break;
    (**(code **)(*(longlong *)(*(longlong *)(lVar2 + 0x5e8) + 0x40) + 0x50))
              (*(longlong *)(lVar2 + 0x5e8) + 0x40,*plVar1,1,1);
    uStackX_8 = 1;
    func_0x(lVar2,1,&uStackX_8);
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

