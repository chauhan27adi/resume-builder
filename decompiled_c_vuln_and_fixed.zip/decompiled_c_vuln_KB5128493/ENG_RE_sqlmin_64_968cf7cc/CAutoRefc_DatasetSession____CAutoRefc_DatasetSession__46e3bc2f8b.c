
void FUN_(longlong **param_1)

{
  longlong *plVar1;
  int iVar2;
  longlong *plVar3;
  
  plVar3 = *param_1;
  if (plVar3 != (longlong *)0x0) {
    (**(code **)(*plVar3 + 0x198))(plVar3);
    LOCK();
    plVar1 = plVar3 + 0x4b;
    iVar2 = *(int *)plVar1;
    *(int *)plVar1 = *(int *)plVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      if (*(int *)(plVar3 + 1) != 0) {
        func_0x(plVar3);
      }
                    /* WARNING: Could not recover jumptable at 0x0010004a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)*plVar3)(plVar3,1);
      return;
    }
  }
  return;
}

