
void FUN_(longlong param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  puVar2 = *(undefined8 **)(param_1 + 8);
  if (puVar2 != (undefined8 *)0x0) {
    puVar1 = puVar2 + 3;
    *(int *)puVar1 = *(int *)puVar1 + -1;
    if (*(int *)puVar1 == 0) {
      (**(code **)*puVar2)();
    }
  }
  *(undefined8 *)(param_1 + 8) = 0;
  return;
}

