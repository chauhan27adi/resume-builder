
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 *
FUN_(undefined8 *param_1,ulonglong param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  uVar1 = 0xfffffffffffffffe;
  *param_1 = 0x1f61350;
  param_1[0xb0] = 0x1ca8238;
  if ((longlong *)param_1[0xb4] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[0xb4] + 0x30))();
  }
  param_1[0xb0] = 0x1d29cc8;
  if ((param_2 & 1) != 0) {
    (*_DAT_)(param_1,0x5c0,param_3,param_4,uVar1);
  }
  return param_1;
}

