
void FUN_(undefined8 *param_1)

{
  if (param_1[1] != 0) {
    func_0x(*param_1);
    param_1[1] = 0;
  }
  return;
}

