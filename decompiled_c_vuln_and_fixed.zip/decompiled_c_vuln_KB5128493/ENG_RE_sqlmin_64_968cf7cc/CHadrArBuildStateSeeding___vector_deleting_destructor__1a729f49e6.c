
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 *
FUN_(undefined8 *param_1,ulonglong param_2,undefined8 param_3,undefined8 param_4)

{
  longlong lVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  if ((longlong *)param_1[5] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[5] + 8))();
  }
  lVar1 = param_1[4];
  if (lVar1 != 0) {
    (**(code **)(*(longlong *)((longlong)*(int *)(*(longlong *)(lVar1 + 0x30) + 4) + lVar1 + 0x30) +
                0x10))();
  }
  *param_1 = 0x1f87338;
  if ((param_2 & 1) != 0) {
    (*_DAT_)(param_1,0x30,param_3,param_4,uVar2);
  }
  return param_1;
}

