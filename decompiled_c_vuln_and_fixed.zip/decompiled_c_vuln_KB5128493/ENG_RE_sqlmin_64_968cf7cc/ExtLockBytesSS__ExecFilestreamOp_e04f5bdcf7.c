
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(void)

{
  (*_DAT_)(1,0x1c9f6c0,0x1cc5188,0x7e,0x1cc4ee8);
  return 0x80004001;
}

