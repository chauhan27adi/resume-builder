
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,ulonglong param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (ulonglong)*(uint *)(param_1 + 0x6c) * 0x124 +
          *(longlong *)(*(longlong *)(param_1 + 0x30) + 8);
  switch(param_3) {
  case 1:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 4;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar1;
    return;
  case 2:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 2;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar1 + 0x18;
    return;
  case 3:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 4;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar1 + 4;
    return;
  case 4:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) =
         *(undefined4 *)(lVar1 + 0x14);
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar1 + 0x22;
    return;
  case 5:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 1;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar1 + 0x1e;
    return;
  case 6:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 4;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar1 + 8;
    return;
  case 7:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 2;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar1 + 0x1a;
    return;
  case 8:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 1;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar1 + 0x1f;
    return;
  case 9:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 1;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar1 + 0x20;
    return;
  case 10:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 4;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar1 + 0xc;
    return;
  case 0xb:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 4;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar1 + 0x10;
    return;
  case 0xc:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 2;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar1 + 0x1c;
    return;
  case 0xd:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 4;
    *(undefined8 *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = 0x2018e90;
    return;
  case 0xe:
  case 0xf:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 4;
    *(undefined8 *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = 0x2018e90;
    return;
  case 0x10:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 0;
    *(undefined8 *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = 0;
    return;
  default:
    (*_DAT_)(1,0,0x2350998,0x337,0x2167350);
    return;
  }
}

