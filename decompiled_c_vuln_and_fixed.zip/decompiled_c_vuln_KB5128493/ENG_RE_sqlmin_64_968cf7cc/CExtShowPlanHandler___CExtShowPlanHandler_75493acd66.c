
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong **pplVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  pplVar1 = (longlong **)(param_1 + 0x10);
  plVar2 = *pplVar1;
  while (plVar2 != (longlong *)0x0) {
    puVar3 = (undefined8 *)plVar2[2];
    plVar2 = *pplVar1;
    if (plVar2 != (longlong *)0x0) {
      if (*plVar2 != 0) {
        *(longlong *)(*plVar2 + 8) = plVar2[1];
      }
      if ((longlong *)plVar2[1] != (longlong *)0x0) {
        *(longlong *)plVar2[1] = *plVar2;
      }
      if (*pplVar1 == plVar2) {
        *pplVar1 = (longlong *)plVar2[1];
      }
      if (*(longlong **)(param_1 + 0x18) == plVar2) {
        *(longlong *)(param_1 + 0x18) = *plVar2;
      }
      *plVar2 = 0;
      plVar2[1] = 0;
      *(int *)(param_1 + 0x20) = *(int *)(param_1 + 0x20) + -1;
    }
    (*_DAT_)();
    if (puVar3 != (undefined8 *)0x0) {
      if (*(char *)((longlong)puVar3 + 0xe) != '\0') {
        func_0x(puVar3);
      }
      *puVar3 = 0;
      (*_DAT_)(puVar3,0x10,param_3,param_4,uVar4);
    }
    plVar2 = *pplVar1;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

