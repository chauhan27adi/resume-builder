
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong param_1,undefined8 *param_2)

{
  if (param_2 == (undefined8 *)0x0) {
    (*_DAT_)(1,0xb91d88,0xbb3880,0x122,0);
  }
  *param_2 = *(undefined8 *)(param_1 + 0xe50);
  return 0;
}

