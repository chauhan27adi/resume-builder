
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong param_1,longlong param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  if (*(char *)(param_2 + 0xc) == 'T') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(char *)(param_1 + 0x228) != '\0') {
    lVar1 = (*_DAT_)(0x80,*(undefined8 *)(param_1 + 0x60),0x2430d68,0x262,1);
    uVar2 = 0;
    if (lVar1 != 0) {
      uVar2 = func_0x
                        (lVar1,*(undefined8 *)(param_1 + 0x108),param_1 + 0x218,
                         *(undefined8 *)(param_1 + 0x50),*(undefined8 *)(param_1 + 0x100),param_2,
                         param_1 + 0xa8,*(undefined8 *)(param_1 + 0x60),
                         *(undefined4 *)(param_1 + 0x90),0);
    }
    return uVar2;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

