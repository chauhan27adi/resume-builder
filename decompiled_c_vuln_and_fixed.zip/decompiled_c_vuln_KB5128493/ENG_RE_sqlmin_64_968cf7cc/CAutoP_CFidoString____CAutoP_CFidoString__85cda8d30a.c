
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)*param_1;
  if (puVar1 != (undefined8 *)0x0) {
    (*_DAT_)(*puVar1);
                    /* WARNING: Could not recover jumptable at 0x00100032. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*_DAT_)(puVar1,0x18);
    return;
  }
  return;
}

