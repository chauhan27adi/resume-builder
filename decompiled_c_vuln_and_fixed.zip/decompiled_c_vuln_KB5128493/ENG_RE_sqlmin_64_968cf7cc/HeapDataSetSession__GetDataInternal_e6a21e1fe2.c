
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,longlong *param_3)

{
  code *pcVar1;
  longlong *plVar2;
  longlong lVar3;
  uint7 uVar4;
  char cVar5;
  byte bVar6;
  ushort uVar7;
  ushort uVar8;
  ushort uVar9;
  longlong *plVar10;
  short *psVar11;
  longlong lVar12;
  undefined8 uVar13;
  short *psVar14;
  uint *puVar15;
  uint *puVar16;
  int *piVar17;
  longlong lVar18;
  byte bVar19;
  undefined uVar20;
  byte *pbVar21;
  ulonglong uVar22;
  longlong lVar23;
  ulonglong uVar24;
  longlong lVar25;
  undefined *puVar26;
  ushort *puVar27;
  ushort *puVar28;
  short sVar29;
  int iVar30;
  uint uVar31;
  uint *puVar32;
  ulonglong *puVar33;
  uint uVar34;
  uint *puVar35;
  uint uVar36;
  undefined8 uStack_3a0;
  undefined auStack_398 [32];
  undefined8 uStack_378;
  uint *apuStack_370 [2];
  uint auStack_360 [2];
  undefined8 uStack_358;
  undefined8 uStack_350;
  undefined8 uStack_348;
  uint uStack_340;
  uint uStack_33c;
  uint uStack_338;
  longlong *plStack_330;
  uint uStack_328;
  uint uStack_324;
  uint uStack_320;
  uint uStack_31c;
  uint uStack_318;
  uint uStack_314;
  uint auStack_310 [2];
  undefined8 uStack_308;
  longlong lStack_300;
  longlong lStack_2f8;
  int iStack_2f0;
  int iStack_2ec;
  int iStack_2e8;
  int iStack_2e4;
  uint uStack_2e0;
  uint uStack_2dc;
  int iStack_2d8;
  uint uStack_2d4;
  uint uStack_2d0;
  uint uStack_2cc;
  longlong *plStack_2c8;
  longlong lStack_2c0;
  int iStack_2b8;
  int iStack_2b4;
  int iStack_2b0;
  int iStack_2ac;
  int iStack_2a8;
  undefined4 uStack_2a4;
  undefined4 uStack_2a0;
  undefined4 uStack_29c;
  uint uStack_298;
  int iStack_294;
  uint uStack_290;
  int iStack_28c;
  int iStack_288;
  int iStack_284;
  int iStack_280;
  int iStack_27c;
  int iStack_278;
  int iStack_274;
  uint uStack_270;
  int iStack_26c;
  int iStack_268;
  uint uStack_264;
  int iStack_260;
  int iStack_25c;
  int iStack_258;
  int iStack_254;
  undefined auStack_250 [4];
  undefined8 uStack_24c;
  undefined auStack_244 [4];
  undefined auStack_240 [8];
  undefined auStack_238 [4];
  undefined auStack_234 [4];
  undefined auStack_230 [4];
  undefined auStack_22c [4];
  undefined auStack_228 [4];
  undefined auStack_224 [4];
  undefined auStack_220 [4];
  undefined auStack_21c [4];
  undefined auStack_218 [4];
  undefined auStack_214 [8];
  undefined auStack_20c [4];
  undefined auStack_208 [4];
  undefined auStack_204 [4];
  undefined8 uStack_200;
  undefined8 uStack_1f8;
  undefined8 uStack_1f0;
  undefined auStack_1e8 [8];
  undefined auStack_1e0 [8];
  undefined auStack_1d8 [8];
  undefined auStack_1d0 [8];
  undefined auStack_1c8 [8];
  undefined auStack_1c0 [8];
  undefined auStack_1b8 [8];
  undefined auStack_1b0 [8];
  undefined auStack_1a8 [8];
  undefined auStack_1a0 [8];
  undefined auStack_198 [56];
  undefined auStack_160 [56];
  undefined auStack_128 [56];
  undefined auStack_f0 [56];
  undefined auStack_b8 [56];
  undefined auStack_80 [56];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)&uStack_358;
  lVar12 = *param_3;
  plVar10 = param_2;
  if ((*(uint *)(param_1 + 0x2e8) & 0x800) == 0) {
    plVar10 = (longlong *)0x0;
  }
  plStack_330 = param_3;
  plStack_2c8 = param_2;
  if ((plVar10 != (longlong *)0x0) && (*(char *)(plVar10 + 199) != '\0')) {
    lVar23 = plVar10[200];
    lVar18 = param_3[3];
    uVar13 = *(undefined8 *)(lVar12 + 0x100);
    if (lVar23 == 0) {
      uStack_378 = (undefined8 *)0x0;
      uStack_3a0 = 0x1000a4;
      (*_DAT_)(1,0x1930fc8,0x19058b8,0x3b);
    }
    uStack_3a0 = 0x1000b2;
    func_0x(lVar23,uVar13,lVar18);
    puVar26 = auStack_398;
    goto LAB_;
  }
  if ((*(short *)(lVar12 + 0x3a) != 0) || (*(int *)(lVar12 + 0x50) != 0)) {
    uStack_3a0 = 0x10615a;
    func_0x(param_1,param_2,param_3,&iStack_274);
    puVar26 = auStack_398;
    if (iStack_274 != 1) {
      lVar12 = *(longlong *)(*(longlong *)(param_1 + 0x108) + 0x70);
      puVar26 = auStack_398;
      if ((lVar12 != 0) &&
         (puVar26 = auStack_398, (*(uint *)(*(longlong *)(param_1 + 0x108) + 0x120) & 0x100) != 0))
      {
        uStack_3a0 = 0x10618b;
        func_0x(param_2 + 6,lVar12);
        puVar26 = auStack_398;
        if (*(int *)(param_2 + 0x6e) == 4) {
          uStack_3a0 = 0x1061a3;
          func_0x(param_2 + 0x56,lVar12);
          puVar26 = auStack_398;
        }
      }
    }
    goto LAB_;
  }
  uStack_3a0 = 0x1000e0;
  psVar11 = (short *)func_0x(param_2,1,0);
  lVar12 = *param_3;
  lStack_2f8 = param_1 + 0x110;
  lStack_300 = param_1 + 0xa60;
  uStack_308 = psVar11;
  if ((*(byte *)(lVar12 + 0x30) & 1) == 0) {
LAB_:
    if (plStack_2c8 == (longlong *)0x0) {
      *(undefined8 *)(param_1 + 0xa70) = 0;
      psVar14 = psVar11;
    }
    else {
      *(undefined8 *)(param_1 + 0xa68) = 0;
      *(longlong **)(param_1 + 0xa70) = plStack_2c8;
      uStack_3a0 = 0x101212;
      psVar14 = (short *)(**(code **)*plStack_2c8)();
    }
    puVar32 = (uint *)0x0;
    *(short **)(lStack_300 + 8) = psVar14;
    if (*psVar11 == 0) {
      *psVar11 = 0;
      puVar28 = (ushort *)(psVar11 + 1);
      puVar26 = auStack_398;
      if ((*(byte *)((longlong)param_3 + 0x14) & 0x10) != 0) {
        uVar34 = *(uint *)(param_3 + 2);
        puVar35 = (uint *)param_3[1];
        puVar26 = auStack_398;
        psVar14 = psVar11;
        puVar15 = puVar32;
        uStack_340 = uVar34;
        if (uVar34 != 0) {
          do {
            uVar36 = uStack_338;
            switch(*(undefined *)(puVar35 + 0x10)) {
            case 0:
              goto code_r0x00103337;
            case 1:
              uStack_378 = &uStack_1f0;
              uStack_3a0 = 0x1012b0;
              func_0x(puVar28,puVar35,1,&iStack_284);
              if (iStack_284 == 0) goto code_r0x001012c3;
              uStack_338 = 0;
              puVar15 = (uint *)0x0;
              uVar36 = uStack_338;
              break;
            case 2:
code_r0x001012c3:
              uVar9 = *(ushort *)(puVar35 + 0xf);
              if ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0) {
                uStack_378 = (undefined8 *)&iStack_26c;
                uStack_3a0 = 0x1012f6;
                func_0x(puVar28,puVar35,0,auStack_250);
                if (iStack_26c == 0) {
                  uVar36 = **(uint **)(puVar35 + 2);
                  puVar15 = *(uint **)(puVar35 + 2) + 1;
                  param_3 = plStack_330;
                  uVar34 = uStack_340;
                  if ((uVar9 != 0) && (uVar36 != uVar9)) {
                    uStack_378 = (undefined8 *)0x0;
                    uStack_3a0 = 0x101336;
                    (*_DAT_)();
                    param_3 = plStack_330;
                    uVar34 = uStack_340;
                  }
                  break;
                }
              }
              puVar15 = (uint *)((longlong)(int)*puVar35 + *(longlong *)(psVar11 + 4));
              uVar34 = uStack_340;
              uVar36 = (uint)uVar9;
              break;
            case 3:
              uStack_378 = &uStack_24c;
              uStack_3a0 = 0x10139d;
              func_0x(puVar28,puVar35,1,&iStack_258);
              if (iStack_258 == 0) goto code_r0x001013ba;
              uStack_338 = 0;
              puVar15 = (uint *)0x0;
              uVar36 = uStack_338;
              break;
            case 4:
code_r0x001013ba:
              if (*(int *)(psVar11 + 2) == 0) {
                pbVar21 = *(byte **)(psVar11 + 4);
                uVar34 = *(uint *)(psVar11 + 8);
                uVar24 = (ulonglong)uVar34;
                *puVar28 = 0;
                *(uint *)(psVar11 + 10) = uVar34;
                bVar6 = *pbVar21;
                if ((bVar6 & 0x10) != 0) {
                  uVar34 = uVar34 + 2 + (*(ushort *)(pbVar21 + uVar24) + 7 >> 3);
                  uVar24 = (ulonglong)uVar34;
                  *(uint *)(psVar11 + 10) = uVar34;
                  bVar6 = *pbVar21;
                }
                iVar30 = (int)uVar24;
                if ((bVar6 & 0x20) == 0) {
                  *(int *)(psVar11 + 2) = iVar30;
                  psVar11[0xe] = 0;
                  *(int *)(psVar11 + 0xc) = iVar30;
                }
                else {
                  puVar27 = (ushort *)(pbVar21 + uVar24);
                  uVar9 = *puVar27;
                  psVar11[0xe] = uVar9;
                  if (uVar9 == 0) {
                    uStack_3a0 = 0x10141f;
                    cVar5 = func_0x(0x1e90760);
                    if (cVar5 != '\0') {
                      uStack_3a0 = 0x101428;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        uStack_3a0 = 0x101442;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 == '\0') {
                          uStack_3a0 = 0x10145e;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          uStack_378 = (undefined8 *)0x0;
                          uStack_3a0 = 0x101484;
                          (*_DAT_)(1,0x17814e8,0x18a11b8,0x80f);
                        }
                      }
                    }
                    uStack_3a0 = 0x101492;
                    func_0x(*(undefined8 *)(psVar11 + 4),3);
                    iVar30 = *(int *)(psVar11 + 10);
                    pbVar21 = *(byte **)(psVar11 + 4);
                    uVar9 = psVar11[0xe];
                  }
                  uVar34 = iVar30 + (uVar9 + 1) * 2;
                  *(uint *)(psVar11 + 0xc) = uVar34;
                  if (0x1f9e < uVar34) {
                    uStack_3a0 = 0x1014c6;
                    cVar5 = func_0x(0x1e90760);
                    if (cVar5 != '\0') {
                      uStack_3a0 = 0x1014cf;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        uStack_3a0 = 0x1014e9;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 == '\0') {
                          uStack_3a0 = 0x101505;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_378 = (undefined8 *)0x0;
                          uStack_3a0 = 0x10152b;
                          (*_DAT_)(1,0x17814e8,0x18a11b8,0x816);
                        }
                      }
                    }
                    uStack_3a0 = 0x101539;
                    func_0x(*(undefined8 *)(psVar11 + 4),4);
                    uVar9 = psVar11[0xe];
                    pbVar21 = *(byte **)(psVar11 + 4);
                    uVar34 = *(uint *)(psVar11 + 0xc);
                  }
                  uVar24 = (ulonglong)uVar9;
                  uVar9 = puVar27[uVar24];
                  *(uint *)(psVar11 + 2) = uVar9 & 0x7fff;
                  if ((uVar9 & 0x7fff) < uVar34) {
                    uStack_3a0 = 0x10156a;
                    cVar5 = func_0x(0x1e90760);
                    if (cVar5 != '\0') {
                      uStack_3a0 = 0x101573;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        uStack_3a0 = 0x10158d;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 == '\0') {
                          uStack_3a0 = 0x1015a9;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_378 = (undefined8 *)0x0;
                          uStack_3a0 = 0x1015cf;
                          (*_DAT_)(1,0x17814e8,0x18a11b8,0x81d);
                        }
                      }
                    }
                    uStack_3a0 = 0x1015dd;
                    func_0x(*(undefined8 *)(psVar11 + 4),4);
                    uVar24 = (ulonglong)(ushort)psVar11[0xe];
                    pbVar21 = *(byte **)(psVar11 + 4);
                  }
                  if ((short)puVar27[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                    do {
                      if ((int)uVar24 == 1) {
                        uVar34 = *(uint *)(psVar11 + 0xc);
                        uVar36 = uVar34;
code_r0x00101627:
                        if ((*(ushort *)(pbVar21 + uVar24 * 2 + (ulonglong)*(uint *)(psVar11 + 10))
                            & 0x7fff) < uVar34) goto code_r0x00101637;
                      }
                      else {
                        uVar36 = *(uint *)(psVar11 + 0xc);
                        uVar34 = *(ushort *)
                                  (pbVar21 + uVar24 * 2 + ((ulonglong)*(uint *)(psVar11 + 10) - 2))
                                 & 0x7fff;
                        if (uVar36 <= uVar34) goto code_r0x00101627;
code_r0x00101637:
                        uStack_3a0 = 0x101644;
                        func_0x(pbVar21,7);
                        uVar36 = *(uint *)(psVar11 + 0xc);
                        pbVar21 = *(byte **)(psVar11 + 4);
                      }
                      if ((uVar34 < uVar36) || (*(uint *)(psVar11 + 2) < uVar34))
                      goto code_r0x00101892;
                      if (*(ushort *)(pbVar21 + uVar34) == 5) {
                        *puVar28 = *puVar28 | 2;
                        psVar11[0xe] = psVar11[0xe] + -1;
                        uVar8 = psVar11[0x16] & 0xc7ff;
                        psVar11[0x15] = (short)uVar34;
                        lVar12 = (ulonglong)(uVar34 & 0xffff) + *(longlong *)(psVar11 + 4);
                        uVar9 = *(ushort *)(lVar12 + 2);
                        if ((uVar9 >> 0xe & 1) != 0) {
                          uVar8 = uVar9 & 0x3800 | uVar8;
                        }
                        psVar11[0x16] = uVar8;
                        psVar11[0x16] = (uVar8 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar8;
                        pbVar21 = *(byte **)(psVar11 + 4);
                        goto code_r0x0010170d;
                      }
                      if (*(ushort *)(pbVar21 + uVar34) < 0x400) goto code_r0x0010170d;
                      *puVar28 = *puVar28 | 1;
                      uVar9 = psVar11[0xe] - 1;
                      psVar11[0xe] = uVar9;
                      if (uVar9 == 0) goto code_r0x0010170d;
                      uVar24 = (ulonglong)uVar9;
                    } while ((short)puVar27[(ulonglong)(uVar9 - 1) + 1] < 0);
                    uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                  }
                  else {
code_r0x0010170d:
                    uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                  }
                }
                if ((*pbVar21 & 0x40) == 0) {
                  *(undefined4 *)(psVar11 + 0x13) = 0;
                }
                else {
                  *(int *)(psVar11 + 0x13) = (int)uVar24;
                  *(int *)(psVar11 + 2) = (int)uVar24 + 0xe;
                  uStack_3a0 = 0x10173d;
                  uVar13 = func_0x(puVar28);
                  uStack_3a0 = 0x10174c;
                  func_0x(uVar13,auStack_1d8);
                  uStack_3a0 = 0x101758;
                  iVar30 = func_0x(auStack_1d8);
                  *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar30;
                  uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                  pbVar21 = *(byte **)(psVar11 + 4);
                }
                iVar30 = (int)uVar24;
                if ((*(byte **)(psVar11 + 0xf) != (byte *)0x0) &&
                   (*(byte **)(psVar11 + 0xf) < pbVar21 + uVar24)) {
                  uStack_3a0 = 0x101793;
                  cVar5 = func_0x(0x1e90760);
                  if (cVar5 != '\0') {
                    uStack_3a0 = 0x10179c;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      uStack_3a0 = 0x1017b6;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 == '\0') {
                        uStack_3a0 = 0x1017d2;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        uStack_378 = (undefined8 *)0x0;
                        uStack_3a0 = 0x1017f8;
                        (*_DAT_)(1,0x17814e8,0x18a11b8,0x877);
                      }
                    }
                  }
                  uStack_3a0 = 0x101806;
                  func_0x(*(undefined8 *)(psVar11 + 4));
                  iVar30 = *(int *)(psVar11 + 2);
                }
                if (0x3f3b < iVar30 - 1U) {
                  uStack_3a0 = 0x10181f;
                  cVar5 = func_0x(0x1e90760);
                  if (cVar5 != '\0') {
                    uStack_3a0 = 0x101828;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      uStack_3a0 = 0x101842;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 == '\0') {
                        uStack_3a0 = 0x10185e;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        uStack_378 = (undefined8 *)0x0;
                        uStack_3a0 = 0x101884;
                        (*_DAT_)(1,0x17814e8,0x18a11b8,0x87c);
                      }
                    }
                  }
                  uStack_3a0 = 0x101892;
                  func_0x(*(undefined8 *)(psVar11 + 4));
                }
              }
code_r0x00101892:
              sVar29 = -*(short *)puVar35;
              if ((*(byte *)((longlong)puVar35 + 6) & 0x10) == 0) {
code_r0x001018d9:
                puVar15 = *(uint **)(psVar11 + 4);
                lVar12 = (longlong)sVar29;
                if ((uint)(int)sVar29 <= (uint)(ushort)psVar11[0xe]) {
                  uVar34 = *(uint *)(psVar11 + 10);
                  if (sVar29 == 1) {
                    uVar36 = *(uint *)(psVar14 + 0xc);
                    uVar34 = *(ushort *)((longlong)puVar15 + lVar12 * 2 + (ulonglong)uVar34) &
                             0x7fff;
code_r0x00101926:
                    if (uVar34 < uVar36) goto code_r0x0010192d;
                  }
                  else {
                    puVar27 = (ushort *)((longlong)puVar15 + lVar12 * 2 + (ulonglong)uVar34);
                    uVar36 = *(ushort *)((longlong)puVar15 + lVar12 * 2 + ((ulonglong)uVar34 - 2)) &
                             0x7fff;
                    puVar15 = *(uint **)(psVar11 + 4);
                    uVar34 = *puVar27 & 0x7fff;
                    if (*(uint *)(psVar14 + 0xc) <= uVar36) goto code_r0x00101926;
code_r0x0010192d:
                    uStack_3a0 = 0x10193a;
                    func_0x(puVar15);
                    puVar15 = *(uint **)(psVar11 + 4);
                  }
                  puVar15 = (uint *)((ulonglong)uVar36 + (longlong)puVar15);
                  uStack_338 = uVar34 - uVar36;
                  goto code_r0x00101946;
                }
                uStack_338 = 0;
code_r0x00101954:
                if ((puVar35[0x10] & 0x2000) != 0) {
                  uStack_338 = 4;
                  puVar15 = (uint *)0x152788c;
                }
              }
              else {
                uStack_378 = (undefined8 *)&iStack_2b8;
                uStack_3a0 = 0x1018c3;
                func_0x(puVar28,puVar35,0,(longlong)&uStack_24c + 4);
                if (iStack_2b8 != 0) goto code_r0x001018d9;
                uStack_338 = **(uint **)(puVar35 + 2);
                puVar15 = *(uint **)(puVar35 + 2) + 1;
code_r0x00101946:
                if (uStack_338 == 0) goto code_r0x00101954;
              }
              if ((1 << (**(byte **)(psVar11 + 4) & 0xe) & 0x440U) != 0) {
                uStack_3a0 = 0x10198d;
                iVar30 = func_0x();
                param_3 = plStack_330;
                uVar34 = uStack_340;
                uVar36 = uStack_338;
                if (iVar30 != 0) break;
              }
              param_3 = plStack_330;
              uVar34 = uStack_340;
              uVar36 = uStack_338;
              if (*(ushort *)(puVar35 + 0xf) < uStack_338) {
                uStack_3a0 = 0x1019ba;
                (*_DAT_)();
                param_3 = plStack_330;
                uVar34 = uStack_340;
                uVar36 = uStack_338;
              }
              break;
            case 5:
              puVar15 = *(uint **)(psVar11 + 4);
              if (*(int *)(psVar11 + 2) == 0) {
                *puVar28 = 0;
                uVar34 = *(uint *)(psVar11 + 8);
                uVar24 = (ulonglong)uVar34;
                *(uint *)(psVar11 + 10) = uVar34;
                bVar6 = *(byte *)puVar15;
                if ((bVar6 & 0x10) != 0) {
                  uVar34 = uVar34 + 2 + (*(ushort *)(uVar24 + (longlong)puVar15) + 7 >> 3);
                  uVar24 = (ulonglong)uVar34;
                  *(uint *)(psVar11 + 10) = uVar34;
                  bVar6 = *(byte *)puVar15;
                }
                if ((bVar6 & 0x20) == 0) {
                  *(int *)(psVar11 + 2) = (int)uVar24;
                  psVar11[0xe] = 0;
                  *(int *)(psVar11 + 0xc) = (int)uVar24;
                  puVar16 = puVar15;
                }
                else {
                  puVar27 = (ushort *)(uVar24 + (longlong)puVar15);
                  uVar9 = *puVar27;
                  psVar11[0xe] = uVar9;
                  if (uVar9 == 0) {
                    uStack_3a0 = 0x102172;
                    cVar5 = func_0x(0x1e90760);
                    if (cVar5 != '\0') {
                      uStack_3a0 = 0x10217b;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        uStack_3a0 = 0x102195;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 == '\0') {
                          uStack_3a0 = 0x1021b1;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          uStack_378 = (undefined8 *)0x0;
                          uStack_3a0 = 0x1021d7;
                          (*_DAT_)(1,0x17814e8,0x18a11b8,0x80f);
                        }
                      }
                    }
                    uStack_3a0 = 0x1021e5;
                    func_0x(*(undefined8 *)(psVar11 + 4),3);
                    uVar24 = (ulonglong)*(uint *)(psVar11 + 10);
                    uVar9 = psVar11[0xe];
                  }
                  uVar34 = (int)uVar24 + (uVar9 + 1) * 2;
                  *(uint *)(psVar11 + 0xc) = uVar34;
                  if (0x1f9e < uVar34) {
                    uStack_3a0 = 0x102214;
                    cVar5 = func_0x(0x1e90760);
                    if (cVar5 != '\0') {
                      uStack_3a0 = 0x10221d;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        uStack_3a0 = 0x102237;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 == '\0') {
                          uStack_3a0 = 0x102253;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_378 = (undefined8 *)0x0;
                          uStack_3a0 = 0x102279;
                          (*_DAT_)(1,0x17814e8,0x18a11b8,0x816);
                        }
                      }
                    }
                    uStack_3a0 = 0x102287;
                    func_0x(*(undefined8 *)(psVar11 + 4),4);
                    uVar9 = psVar11[0xe];
                    uVar34 = *(uint *)(psVar11 + 0xc);
                  }
                  uVar22 = (ulonglong)uVar9;
                  uVar36 = puVar27[uVar22] & 0x7fff;
                  *(uint *)(psVar11 + 2) = uVar36;
                  if (uVar36 < uVar34) {
                    uStack_3a0 = 0x1022b4;
                    cVar5 = func_0x(0x1e90760);
                    if (cVar5 != '\0') {
                      uStack_3a0 = 0x1022bd;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        uStack_3a0 = 0x1022d7;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 == '\0') {
                          uStack_3a0 = 0x1022f3;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_378 = (undefined8 *)0x0;
                          uStack_3a0 = 0x102319;
                          (*_DAT_)(1,0x17814e8,0x18a11b8,0x81d);
                        }
                      }
                    }
                    uStack_3a0 = 0x102327;
                    func_0x(*(undefined8 *)(psVar11 + 4),4);
                    uVar22 = (ulonglong)(ushort)psVar11[0xe];
                    uVar36 = *(uint *)(psVar11 + 2);
                  }
                  uVar24 = (ulonglong)uVar36;
                  if ((short)puVar27[(ulonglong)((int)uVar22 - 1) + 1] < 0) {
                    puVar16 = *(uint **)(psVar11 + 4);
                    do {
                      if ((int)uVar22 == 1) {
                        uVar34 = *(uint *)(psVar11 + 0xc);
                        uVar36 = uVar34;
code_r0x00102377:
                        if ((*(ushort *)
                              ((longlong)puVar16 + uVar22 * 2 + (ulonglong)*(uint *)(psVar11 + 10))
                            & 0x7fff) < uVar34) goto code_r0x00102384;
                      }
                      else {
                        uVar36 = *(uint *)(psVar11 + 0xc);
                        uVar34 = *(ushort *)
                                  ((longlong)puVar16 +
                                  uVar22 * 2 + ((ulonglong)*(uint *)(psVar11 + 10) - 2)) & 0x7fff;
                        if (uVar36 <= uVar34) goto code_r0x00102377;
code_r0x00102384:
                        uStack_3a0 = 0x102391;
                        func_0x(puVar16,7);
                        uVar36 = *(uint *)(psVar11 + 0xc);
                      }
                      if ((uVar34 < uVar36) ||
                         (uVar24 = (ulonglong)*(uint *)(psVar11 + 2),
                         *(uint *)(psVar11 + 2) < uVar34)) goto code_r0x001025d0;
                      puVar16 = *(uint **)(psVar11 + 4);
                      if (*(ushort *)((ulonglong)uVar34 + (longlong)puVar16) == 5) {
                        *puVar28 = *puVar28 | 2;
                        psVar11[0xe] = psVar11[0xe] + -1;
                        uVar8 = psVar11[0x16] & 0xc7ff;
                        psVar11[0x15] = (short)uVar34;
                        lVar12 = (ulonglong)(uVar34 & 0xffff) + *(longlong *)(psVar11 + 4);
                        uVar9 = *(ushort *)(lVar12 + 2);
                        if ((uVar9 >> 0xe & 1) != 0) {
                          uVar8 = uVar9 & 0x3800 | uVar8;
                        }
                        psVar11[0x16] = uVar8;
                        psVar11[0x16] = (uVar8 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar8;
                        uVar24 = (ulonglong)*(uint *)(psVar14 + 2);
                        goto code_r0x00102454;
                      }
                      if (*(ushort *)((ulonglong)uVar34 + (longlong)puVar16) < 0x400)
                      goto code_r0x00102454;
                      *puVar28 = *puVar28 | 1;
                      uVar9 = psVar11[0xe] - 1;
                      psVar11[0xe] = uVar9;
                      if (uVar9 == 0) goto code_r0x00102454;
                      uVar22 = (ulonglong)uVar9;
                    } while ((short)puVar27[(ulonglong)(uVar9 - 1) + 1] < 0);
                  }
                  else {
code_r0x00102454:
                    puVar16 = *(uint **)(psVar11 + 4);
                  }
                }
                if ((*(byte *)puVar16 & 0x40) == 0) {
                  *(undefined4 *)(psVar11 + 0x13) = 0;
                }
                else {
                  *(int *)(psVar11 + 0x13) = (int)uVar24;
                  *(int *)(psVar11 + 2) = (int)uVar24 + 0xe;
                  uStack_3a0 = 0x102481;
                  uVar13 = func_0x(puVar28);
                  uStack_3a0 = 0x102490;
                  func_0x(uVar13,auStack_1c8);
                  uStack_3a0 = 0x10249c;
                  iVar30 = func_0x(auStack_1c8);
                  *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar30;
                  uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                }
                if ((*(ulonglong *)(psVar11 + 0xf) != 0) &&
                   (*(ulonglong *)(psVar11 + 0xf) < uVar24 + *(longlong *)(psVar11 + 4))) {
                  uStack_3a0 = 0x1024d1;
                  cVar5 = func_0x(0x1e90760);
                  if (cVar5 != '\0') {
                    uStack_3a0 = 0x1024da;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      uStack_3a0 = 0x1024f4;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 == '\0') {
                        uStack_3a0 = 0x102510;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        uStack_378 = (undefined8 *)0x0;
                        uStack_3a0 = 0x102536;
                        (*_DAT_)(1,0x17814e8,0x18a11b8,0x877);
                      }
                    }
                  }
                  uStack_3a0 = 0x102544;
                  func_0x(*(undefined8 *)(psVar11 + 4),0x12);
                  uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                }
                if (0x3f3b < (int)uVar24 - 1U) {
                  uStack_3a0 = 0x10255d;
                  cVar5 = func_0x(0x1e90760);
                  if (cVar5 != '\0') {
                    uStack_3a0 = 0x102566;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      uStack_3a0 = 0x102580;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 == '\0') {
                        uStack_3a0 = 0x10259c;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        uStack_378 = (undefined8 *)0x0;
                        uStack_3a0 = 0x1025c2;
                        (*_DAT_)(1,0x17814e8,0x18a11b8,0x87c);
                      }
                    }
                  }
                  uStack_3a0 = 0x1025d0;
                  func_0x(*(undefined8 *)(psVar11 + 4),5);
                }
              }
code_r0x001025d0:
              uVar36 = *(uint *)(psVar11 + 2);
              param_3 = plStack_330;
              uVar34 = uStack_340;
              if ((uVar36 < 9) &&
                 (((**(byte **)(psVar11 + 4) & 0xe) == 0 ||
                  ((**(byte **)(psVar11 + 4) & 0xe) == 0xc)))) {
                uVar36 = 9;
              }
              break;
            case 6:
            case 7:
            case 9:
            case 10:
            case 0xb:
            case 0xe:
            case 0xf:
            case 0x19:
              uStack_3a0 = 0x102604;
              func_0x();
              goto code_r0x00103337;
            case 8:
              uVar9 = *(ushort *)(puVar35 + 0xf);
              iVar30 = puVar35[0x10] << 0xc;
              if ((*puVar35 & 0xc0000000) == 0x80000000) {
                uStack_3a0 = 0x1020dc;
                iVar30 = func_0x();
                if (iVar30 == 0) {
                  uStack_338 = 0;
                  param_3 = plStack_330;
                  puVar15 = (uint *)0x0;
                  uVar34 = uStack_340;
                  uVar36 = uStack_338;
                }
                else {
                  uStack_3a0 = 0x1020f7;
                  puVar15 = (uint *)func_0x();
                  param_3 = plStack_330;
                  uVar34 = uStack_340;
                  uVar36 = uStack_338;
                }
              }
              else {
                if ((iVar30 < 0) || ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0)) {
                  uStack_378 = (undefined8 *)&iStack_2e4;
                  uStack_3a0 = 0x101a22;
                  func_0x(puVar28,puVar35,iVar30 < 0,&iStack_2e8);
                  if ((iVar30 < 0) && (iStack_2e8 != 0)) {
                    uStack_338 = 0;
                    param_3 = plStack_330;
                    puVar15 = (uint *)0x0;
                    uVar34 = uStack_340;
                    uVar36 = uStack_338;
                    break;
                  }
                }
                else {
                  iStack_2e8 = 0;
                  iStack_2e4 = 1;
                }
                if ((iStack_2e4 == 0) && ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0)) {
                  param_3 = plStack_330;
                  puVar15 = *(uint **)(puVar35 + 2) + 1;
                  uVar34 = uStack_340;
                  uVar36 = **(uint **)(puVar35 + 2);
                }
                else if ((int)*puVar35 < 0) {
                  if (*(int *)(psVar11 + 2) == 0) {
                    uVar34 = *(uint *)(psVar11 + 8);
                    uVar24 = (ulonglong)uVar34;
                    *puVar28 = 0;
                    pbVar21 = *(byte **)(psVar11 + 4);
                    *(uint *)(psVar11 + 10) = uVar34;
                    bVar6 = *pbVar21;
                    if ((bVar6 & 0x10) != 0) {
                      uVar34 = uVar34 + 2 + (*(ushort *)(pbVar21 + uVar24) + 7 >> 3);
                      uVar24 = (ulonglong)uVar34;
                      *(uint *)(psVar11 + 10) = uVar34;
                      bVar6 = *pbVar21;
                    }
                    if ((bVar6 & 0x20) == 0) {
                      *(int *)(psVar11 + 2) = (int)uVar24;
                      psVar11[0xe] = 0;
                      *(int *)(psVar11 + 0xc) = (int)uVar24;
                    }
                    else {
                      puVar27 = (ushort *)(pbVar21 + uVar24);
                      uVar9 = *puVar27;
                      psVar11[0xe] = uVar9;
                      if (uVar9 == 0) {
                        uStack_3a0 = 0x101b9c;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 != '\0') {
                          uStack_3a0 = 0x101ba5;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            uStack_3a0 = 0x101bbf;
                            cVar5 = func_0x(0x1e90760);
                            if (cVar5 == '\0') {
                              uStack_3a0 = 0x101bdb;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              uStack_378 = (undefined8 *)0x0;
                              uStack_3a0 = 0x101c01;
                              (*_DAT_)(1,0x17814e8,0x18a11b8,0x80f);
                            }
                          }
                        }
                        uStack_3a0 = 0x101c0f;
                        func_0x(*(undefined8 *)(psVar11 + 4),3);
                        uVar24 = (ulonglong)*(uint *)(psVar11 + 10);
                        uVar9 = psVar11[0xe];
                      }
                      uVar34 = (int)uVar24 + (uVar9 + 1) * 2;
                      *(uint *)(psVar11 + 0xc) = uVar34;
                      if (0x1f9e < uVar34) {
                        uStack_3a0 = 0x101c3f;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 != '\0') {
                          uStack_3a0 = 0x101c48;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            uStack_3a0 = 0x101c62;
                            cVar5 = func_0x(0x1e90760);
                            if (cVar5 == '\0') {
                              uStack_3a0 = 0x101c7e;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              uStack_378 = (undefined8 *)0x0;
                              uStack_3a0 = 0x101ca4;
                              (*_DAT_)(1,0x17814e8,0x18a11b8,0x816);
                            }
                          }
                        }
                        uStack_3a0 = 0x101cb2;
                        func_0x(*(undefined8 *)(psVar11 + 4),4);
                        uVar9 = psVar11[0xe];
                        uVar34 = *(uint *)(psVar11 + 0xc);
                      }
                      uVar24 = (ulonglong)uVar9;
                      uVar9 = puVar27[uVar24];
                      *(uint *)(psVar11 + 2) = uVar9 & 0x7fff;
                      if ((uVar9 & 0x7fff) < uVar34) {
                        uStack_3a0 = 0x101cdf;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 != '\0') {
                          uStack_3a0 = 0x101ce8;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            uStack_3a0 = 0x101d02;
                            cVar5 = func_0x(0x1e90760);
                            if (cVar5 == '\0') {
                              uStack_3a0 = 0x101d1e;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              uStack_378 = (undefined8 *)0x0;
                              uStack_3a0 = 0x101d44;
                              (*_DAT_)(1,0x17814e8,0x18a11b8,0x81d);
                            }
                          }
                        }
                        uStack_3a0 = 0x101d52;
                        func_0x(*(undefined8 *)(psVar11 + 4),4);
                        uVar24 = (ulonglong)(ushort)psVar11[0xe];
                      }
                      if ((short)puVar27[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                        pbVar21 = *(byte **)(psVar11 + 4);
                        do {
                          if ((int)uVar24 == 1) {
                            uVar34 = *(uint *)(psVar11 + 0xc);
                            uVar36 = uVar34;
code_r0x00101d92:
                            if ((*(ushort *)
                                  (pbVar21 + uVar24 * 2 + (ulonglong)*(uint *)(psVar11 + 10)) &
                                0x7fff) < uVar34) goto code_r0x00101d9f;
                          }
                          else {
                            uVar36 = *(uint *)(psVar11 + 0xc);
                            uVar34 = *(ushort *)
                                      (pbVar21 +
                                      uVar24 * 2 + ((ulonglong)*(uint *)(psVar11 + 10) - 2)) &
                                     0x7fff;
                            if (uVar36 <= uVar34) goto code_r0x00101d92;
code_r0x00101d9f:
                            uStack_3a0 = 0x101dac;
                            func_0x(pbVar21);
                            uVar36 = *(uint *)(psVar11 + 0xc);
                          }
                          if ((uVar34 < uVar36) || (*(uint *)(psVar11 + 2) < uVar34))
                          goto code_r0x00101fed;
                          pbVar21 = *(byte **)(psVar11 + 4);
                          if (*(ushort *)(pbVar21 + uVar34) == 5) {
                            *puVar28 = *puVar28 | 2;
                            psVar11[0xe] = psVar11[0xe] + -1;
                            uVar8 = psVar11[0x16] & 0xc7ff;
                            psVar11[0x15] = (short)uVar34;
                            lVar12 = (ulonglong)(uVar34 & 0xffff) + *(longlong *)(psVar11 + 4);
                            uVar9 = *(ushort *)(lVar12 + 2);
                            if ((uVar9 >> 0xe & 1) != 0) {
                              uVar8 = uVar9 & 0x3800 | uVar8;
                            }
                            psVar11[0x16] = uVar8;
                            psVar11[0x16] = (uVar8 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar8;
                            goto code_r0x00101e6d;
                          }
                          if (*(ushort *)(pbVar21 + uVar34) < 0x400) goto code_r0x00101e6d;
                          *puVar28 = *puVar28 | 1;
                          uVar9 = psVar11[0xe] - 1;
                          psVar11[0xe] = uVar9;
                          if (uVar9 == 0) goto code_r0x00101e6d;
                          uVar24 = (ulonglong)uVar9;
                        } while ((short)puVar27[(ulonglong)(uVar9 - 1) + 1] < 0);
                        uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                      }
                      else {
code_r0x00101e6d:
                        pbVar21 = *(byte **)(psVar11 + 4);
                        uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                      }
                    }
                    if ((*pbVar21 & 0x40) == 0) {
                      *(undefined4 *)(psVar11 + 0x13) = 0;
                    }
                    else {
                      *(int *)(psVar11 + 0x13) = (int)uVar24;
                      *(int *)(psVar11 + 2) = (int)uVar24 + 0xe;
                      uStack_3a0 = 0x101e9f;
                      uVar13 = func_0x(puVar28);
                      uStack_3a0 = 0x101eae;
                      func_0x(uVar13,auStack_1d0);
                      uStack_3a0 = 0x101eba;
                      iVar30 = func_0x(auStack_1d0);
                      *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar30;
                      uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                    }
                    iVar30 = (int)uVar24;
                    if ((*(ulonglong *)(psVar11 + 0xf) != 0) &&
                       (*(ulonglong *)(psVar11 + 0xf) < uVar24 + *(longlong *)(psVar11 + 4))) {
                      uStack_3a0 = 0x101ef2;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 != '\0') {
                        uStack_3a0 = 0x101efb;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          uStack_3a0 = 0x101f15;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 == '\0') {
                            uStack_3a0 = 0x101f31;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            uStack_378 = (undefined8 *)0x0;
                            uStack_3a0 = 0x101f55;
                            (*_DAT_)(1,0x17814e8,0x18a11b8,0x877);
                          }
                        }
                      }
                      uStack_3a0 = 0x101f63;
                      func_0x(*(undefined8 *)(psVar11 + 4));
                      iVar30 = *(int *)(psVar11 + 2);
                    }
                    if (0x3f3b < iVar30 - 1U) {
                      uStack_3a0 = 0x101f7c;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 != '\0') {
                        uStack_3a0 = 0x101f85;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          uStack_3a0 = 0x101f9f;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 == '\0') {
                            uStack_3a0 = 0x101fbb;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            uStack_378 = (undefined8 *)0x0;
                            uStack_3a0 = 0x101fdf;
                            (*_DAT_)(1,0x17814e8,0x18a11b8,0x87c);
                          }
                        }
                      }
                      uStack_3a0 = 0x101fed;
                      func_0x(*(undefined8 *)(psVar11 + 4));
                    }
                  }
code_r0x00101fed:
                  sVar29 = -*(short *)puVar35;
                  if ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0) {
                    uStack_378 = (undefined8 *)&iStack_2b0;
                    uStack_3a0 = 0x10201e;
                    func_0x(puVar28,puVar35,0,auStack_240);
                    if (iStack_2b0 == 0) {
                      param_3 = plStack_330;
                      puVar15 = *(uint **)(puVar35 + 2) + 1;
                      uVar34 = uStack_340;
                      uVar36 = **(uint **)(puVar35 + 2);
                      break;
                    }
                  }
                  puVar15 = *(uint **)(psVar11 + 4);
                  lVar12 = (longlong)sVar29;
                  if ((uint)(ushort)psVar11[0xe] < (uint)(int)sVar29) {
                    uStack_338 = 0;
                    param_3 = plStack_330;
                    uVar34 = uStack_340;
                    uVar36 = uStack_338;
                  }
                  else {
                    uVar34 = *(uint *)(psVar11 + 10);
                    if (sVar29 == 1) {
                      uVar36 = *(uint *)(psVar14 + 0xc);
                      uVar31 = *(ushort *)((longlong)puVar15 + lVar12 * 2 + (ulonglong)uVar34) &
                               0x7fff;
code_r0x00102090:
                      if (uVar31 < uVar36) goto code_r0x00102097;
                    }
                    else {
                      puVar27 = (ushort *)((longlong)puVar15 + lVar12 * 2 + (ulonglong)uVar34);
                      uVar36 = *(ushort *)((longlong)puVar15 + lVar12 * 2 + ((ulonglong)uVar34 - 2))
                               & 0x7fff;
                      puVar15 = *(uint **)(psVar11 + 4);
                      uVar31 = *puVar27 & 0x7fff;
                      if (*(uint *)(psVar14 + 0xc) <= uVar36) goto code_r0x00102090;
code_r0x00102097:
                      uStack_3a0 = 0x1020a4;
                      func_0x();
                      puVar15 = *(uint **)(psVar11 + 4);
                    }
                    param_3 = plStack_330;
                    puVar15 = (uint *)((ulonglong)uVar36 + (longlong)puVar15);
                    uVar34 = uStack_340;
                    uVar36 = uVar31 - uVar36;
                  }
                }
                else if ((*(ushort *)((longlong)puVar35 + 6) & 8) == 0) {
                  if ((*(ushort *)((longlong)puVar35 + 6) & 0x10) != 0) {
                    uStack_378 = (undefined8 *)&iStack_2b4;
                    uStack_3a0 = 0x101aaf;
                    func_0x(puVar28,puVar35,0,auStack_244);
                    if (iStack_2b4 == 0) {
                      uVar36 = **(uint **)(puVar35 + 2);
                      puVar15 = *(uint **)(puVar35 + 2) + 1;
                      param_3 = plStack_330;
                      uVar34 = uStack_340;
                      if ((uVar9 != 0) && (uVar36 != uVar9)) {
                        uStack_378 = (undefined8 *)0x0;
                        uStack_3a0 = 0x101aef;
                        (*_DAT_)();
                        param_3 = plStack_330;
                        uVar34 = uStack_340;
                      }
                      break;
                    }
                  }
                  param_3 = plStack_330;
                  puVar15 = (uint *)((longlong)(int)*puVar35 + *(longlong *)(psVar11 + 4));
                  uVar34 = uStack_340;
                  uVar36 = (uint)uVar9;
                }
                else {
                  uStack_3a0 = 0x101b28;
                  puVar15 = (uint *)func_0x();
                  param_3 = plStack_330;
                  uVar34 = uStack_340;
                  uVar36 = uStack_338;
                }
              }
              break;
            case 0xd:
            case 0x1b:
              uStack_338 = 0;
              puVar15 = (uint *)0x0;
              uVar36 = uStack_338;
              break;
            case 0x10:
              uStack_3a0 = 0x10261e;
              piVar17 = (int *)func_0x(**(undefined8 **)
                                                 (*(longlong *)(lStack_2f8 + 8) + 0x160),0);
              uStack_320 = 8;
              iVar30 = *(int *)(*(longlong *)(lStack_2f8 + 8) + 0x100);
              if (iVar30 == 2) {
                if (*(int *)(psVar11 + 2) == 0) {
                  pbVar21 = *(byte **)(psVar11 + 4);
                  uVar34 = *(uint *)(psVar11 + 8);
                  uVar24 = (ulonglong)uVar34;
                  *puVar28 = 0;
                  *(uint *)(psVar11 + 10) = uVar34;
                  bVar6 = *pbVar21;
                  if ((bVar6 & 0x10) != 0) {
                    uVar34 = uVar34 + 2 + (*(ushort *)(pbVar21 + uVar24) + 7 >> 3);
                    uVar24 = (ulonglong)uVar34;
                    *(uint *)(psVar11 + 10) = uVar34;
                    bVar6 = *pbVar21;
                  }
                  if ((bVar6 & 0x20) == 0) {
                    *(int *)(psVar11 + 2) = (int)uVar24;
                    psVar11[0xe] = 0;
                    *(int *)(psVar11 + 0xc) = (int)uVar24;
                  }
                  else {
                    puVar27 = (ushort *)(pbVar21 + uVar24);
                    uVar9 = *puVar27;
                    psVar11[0xe] = uVar9;
                    if (uVar9 == 0) {
                      uStack_3a0 = 0x1026a4;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 != '\0') {
                        uStack_3a0 = 0x1026ad;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          uStack_3a0 = 0x1026c7;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 == '\0') {
                            uStack_3a0 = 0x1026e3;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            uStack_378 = (undefined8 *)0x0;
                            uStack_3a0 = 0x102709;
                            (*_DAT_)(1,0x17814e8,0x18a11b8,0x80f);
                          }
                        }
                      }
                      uStack_3a0 = 0x102717;
                      func_0x(*(undefined8 *)(psVar11 + 4),3);
                      uVar24 = (ulonglong)*(uint *)(psVar11 + 10);
                      uVar9 = psVar11[0xe];
                    }
                    uVar34 = (int)uVar24 + (uVar9 + 1) * 2;
                    *(uint *)(psVar11 + 0xc) = uVar34;
                    if (0x1f9e < uVar34) {
                      uStack_3a0 = 0x102747;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 != '\0') {
                        uStack_3a0 = 0x102750;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          uStack_3a0 = 0x10276a;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 == '\0') {
                            uStack_3a0 = 0x102786;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            uStack_378 = (undefined8 *)0x0;
                            uStack_3a0 = 0x1027ac;
                            (*_DAT_)(1,0x17814e8,0x18a11b8,0x816);
                          }
                        }
                      }
                      uStack_3a0 = 0x1027ba;
                      func_0x(*(undefined8 *)(psVar11 + 4),4);
                      uVar9 = psVar11[0xe];
                      uVar34 = *(uint *)(psVar11 + 0xc);
                    }
                    uVar24 = (ulonglong)uVar9;
                    uVar9 = puVar27[uVar24];
                    *(uint *)(psVar11 + 2) = uVar9 & 0x7fff;
                    if ((uVar9 & 0x7fff) < uVar34) {
                      uStack_3a0 = 0x1027e7;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 != '\0') {
                        uStack_3a0 = 0x1027f0;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          uStack_3a0 = 0x10280a;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 == '\0') {
                            uStack_3a0 = 0x102826;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            uStack_378 = (undefined8 *)0x0;
                            uStack_3a0 = 0x10284c;
                            (*_DAT_)(1,0x17814e8,0x18a11b8,0x81d);
                          }
                        }
                      }
                      uStack_3a0 = 0x10285a;
                      func_0x(*(undefined8 *)(psVar11 + 4),4);
                      uVar24 = (ulonglong)(ushort)psVar11[0xe];
                    }
                    if ((short)puVar27[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                      pbVar21 = *(byte **)(psVar11 + 4);
                      do {
                        if ((int)uVar24 == 1) {
                          uVar34 = *(uint *)(psVar11 + 0xc);
                          uVar36 = uVar34;
code_r0x00102899:
                          if ((*(ushort *)
                                (pbVar21 + uVar24 * 2 + (ulonglong)*(uint *)(psVar11 + 10)) & 0x7fff
                              ) < uVar34) goto code_r0x001028a6;
                        }
                        else {
                          uVar36 = *(uint *)(psVar11 + 0xc);
                          uVar34 = *(ushort *)
                                    (pbVar21 + uVar24 * 2 + ((ulonglong)*(uint *)(psVar11 + 10) - 2)
                                    ) & 0x7fff;
                          if (uVar36 <= uVar34) goto code_r0x00102899;
code_r0x001028a6:
                          uStack_3a0 = 0x1028b3;
                          func_0x(pbVar21,7);
                          uVar36 = *(uint *)(psVar11 + 0xc);
                        }
                        if ((uVar34 < uVar36) || (*(uint *)(psVar11 + 2) < uVar34))
                        goto code_r0x00102af6;
                        pbVar21 = *(byte **)(psVar11 + 4);
                        if (*(ushort *)(pbVar21 + uVar34) == 5) {
                          *puVar28 = *puVar28 | 2;
                          psVar11[0xe] = psVar11[0xe] + -1;
                          uVar8 = psVar11[0x16] & 0xc7ff;
                          psVar11[0x15] = (short)uVar34;
                          lVar12 = (ulonglong)(uVar34 & 0xffff) + *(longlong *)(psVar11 + 4);
                          uVar9 = *(ushort *)(lVar12 + 2);
                          if ((uVar9 >> 0xe & 1) != 0) {
                            uVar8 = uVar9 & 0x3800 | uVar8;
                          }
                          psVar11[0x16] = uVar8;
                          psVar11[0x16] = (uVar8 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar8;
                          goto code_r0x00102976;
                        }
                        if (*(ushort *)(pbVar21 + uVar34) < 0x400) goto code_r0x00102976;
                        *puVar28 = *puVar28 | 1;
                        uVar9 = psVar11[0xe] - 1;
                        psVar11[0xe] = uVar9;
                        if (uVar9 == 0) goto code_r0x00102976;
                        uVar24 = (ulonglong)uVar9;
                      } while ((short)puVar27[(ulonglong)(uVar9 - 1) + 1] < 0);
                      uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                    }
                    else {
code_r0x00102976:
                      pbVar21 = *(byte **)(psVar11 + 4);
                      uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                    }
                  }
                  if ((*pbVar21 & 0x40) == 0) {
                    *(undefined4 *)(psVar11 + 0x13) = 0;
                  }
                  else {
                    *(int *)(psVar11 + 0x13) = (int)uVar24;
                    *(int *)(psVar11 + 2) = (int)uVar24 + 0xe;
                    uStack_3a0 = 0x1029a4;
                    uVar13 = func_0x(puVar28);
                    uStack_3a0 = 0x1029b3;
                    func_0x(uVar13,auStack_1c0);
                    uStack_3a0 = 0x1029bf;
                    iVar30 = func_0x(auStack_1c0);
                    *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar30;
                    uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                  }
                  iVar30 = (int)uVar24;
                  if ((*(ulonglong *)(psVar11 + 0xf) != 0) &&
                     (*(ulonglong *)(psVar11 + 0xf) < uVar24 + *(longlong *)(psVar11 + 4))) {
                    uStack_3a0 = 0x1029f7;
                    cVar5 = func_0x(0x1e90760);
                    if (cVar5 != '\0') {
                      uStack_3a0 = 0x102a00;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        uStack_3a0 = 0x102a1a;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 == '\0') {
                          uStack_3a0 = 0x102a36;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          uStack_378 = (undefined8 *)0x0;
                          uStack_3a0 = 0x102a5c;
                          (*_DAT_)(1,0x17814e8,0x18a11b8,0x877);
                        }
                      }
                    }
                    uStack_3a0 = 0x102a6a;
                    func_0x(*(undefined8 *)(psVar11 + 4),0x12);
                    iVar30 = *(int *)(psVar11 + 2);
                  }
                  if (0x3f3b < iVar30 - 1U) {
                    uStack_3a0 = 0x102a83;
                    cVar5 = func_0x(0x1e90760);
                    if (cVar5 != '\0') {
                      uStack_3a0 = 0x102a8c;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        uStack_3a0 = 0x102aa6;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 == '\0') {
                          uStack_3a0 = 0x102ac2;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          uStack_378 = (undefined8 *)0x0;
                          uStack_3a0 = 0x102ae8;
                          (*_DAT_)(1,0x17814e8,0x18a11b8,0x87c);
                        }
                      }
                    }
                    uStack_3a0 = 0x102af6;
                    func_0x(*(undefined8 *)(psVar11 + 4),5);
                  }
                }
code_r0x00102af6:
                sVar29 = -*(short *)piVar17;
                if ((*(byte *)((longlong)piVar17 + 6) & 0x10) == 0) {
code_r0x00102b3c:
                  lVar12 = (longlong)sVar29;
                  if ((uint)(ushort)psVar11[0xe] < (uint)(int)sVar29) {
                    puVar33 = *(ulonglong **)(psVar11 + 4);
                    iVar30 = 0;
                  }
                  else {
                    lVar23 = *(longlong *)(psVar11 + 4);
                    lVar18 = (ulonglong)*(uint *)(psVar11 + 10) + lVar23;
                    if (sVar29 == 1) {
                      uVar34 = *(uint *)(uStack_308 + 0xc);
                      uVar36 = *(ushort *)(lVar18 + lVar12 * 2) & 0x7fff;
code_r0x00102b90:
                      if (uVar36 < uVar34) goto code_r0x00102b94;
                    }
                    else {
                      uVar34 = *(ushort *)(lVar18 + -2 + lVar12 * 2) & 0x7fff;
                      lVar23 = *(longlong *)(psVar11 + 4);
                      uVar36 = *(ushort *)(lVar18 + lVar12 * 2) & 0x7fff;
                      if (*(uint *)(uStack_308 + 0xc) <= uVar34) goto code_r0x00102b90;
code_r0x00102b94:
                      uStack_3a0 = 0x102b9e;
                      func_0x(lVar23,7);
                      lVar23 = *(longlong *)(psVar11 + 4);
                    }
                    iVar30 = uVar36 - uVar34;
                    puVar33 = (ulonglong *)((ulonglong)uVar34 + lVar23);
                  }
                }
                else {
                  uStack_378 = (undefined8 *)&iStack_2ac;
                  uStack_3a0 = 0x102b25;
                  func_0x(puVar28,piVar17,0,auStack_238);
                  if (iStack_2ac != 0) goto code_r0x00102b3c;
                  iVar30 = **(int **)(piVar17 + 2);
                  puVar33 = (ulonglong *)(*(int **)(piVar17 + 2) + 1);
                }
                uVar36 = uStack_350._4_4_;
                param_3 = plStack_330;
                uVar34 = uStack_340;
                switch(*(undefined *)((longlong)puVar35 + 0x3e)) {
                case 0x30:
                  if (iVar30 == 0) {
                    uStack_350 = (ulonglong)uStack_350._1_7_ << 8;
                    uStack_320 = 1;
                  }
                  else {
                    uStack_350 = CONCAT71(uStack_350._1_7_,*(byte *)puVar33);
                    uStack_320 = 1;
                  }
                  break;
                case 0x34:
                  if (iVar30 == 0) {
                    uStack_350 = (ulonglong)uStack_350._2_6_ << 0x10;
code_r0x00102d3c:
                    uStack_320 = 2;
                  }
                  else if (iVar30 == 1) {
                    uStack_350 = CONCAT62(uStack_350._2_6_,(*(byte *)puVar33 >> 7) - 1);
                    uStack_320 = 2;
                    uStack_350 = CONCAT71(uStack_350._1_7_,*(byte *)puVar33) ^ 0x80;
                  }
                  else {
                    if (iVar30 != 2) goto code_r0x00102d3c;
                    uStack_350 = CONCAT71(CONCAT61(uStack_350._2_6_,*(byte *)puVar33),
                                          *(byte *)((longlong)puVar33 + 1)) ^ 0x8000;
                    uStack_320 = 2;
                  }
                  break;
                case 0x38:
                case 0x7a:
                  if (iVar30 == 0) {
                    uStack_350 = (ulonglong)uVar36 << 0x20;
                    uStack_320 = 4;
                  }
                  else if (iVar30 == 1) {
                    uStack_350 = CONCAT44(uVar36,(*(byte *)puVar33 >> 7) - 1);
                    uStack_320 = 4;
                    uStack_350 = CONCAT71(uStack_350._1_7_,*(byte *)puVar33) ^ 0x80;
                  }
                  else if (iVar30 == 2) {
                    uStack_350 = CONCAT44(uVar36,(*(byte *)puVar33 >> 7) - 1);
                    uStack_350 = CONCAT71(CONCAT61(uStack_350._2_6_,*(byte *)puVar33),
                                          *(byte *)((longlong)puVar33 + 1)) ^ 0x8000;
                    uStack_320 = 4;
                  }
                  else {
                    if (iVar30 != 3) {
                      if (iVar30 != 4) goto code_r0x0010303b;
                      uVar31 = *(uint *)puVar33;
                      uStack_350 = CONCAT44(uVar36,uVar31 >> 0x18 | (uVar31 & 0xff0000) >> 8 |
                                                   (uVar31 & 0xff00) << 8);
                      bVar6 = (byte)uVar31 ^ 0x80;
                      goto code_r0x00103038;
                    }
                    uStack_350 = CONCAT44(uVar36,(*(byte *)puVar33 >> 7) - 1);
                    uStack_350 = CONCAT71(CONCAT61(CONCAT51(uStack_350._3_5_,*(byte *)puVar33),
                                                   *(byte *)((longlong)puVar33 + 1)),
                                          *(byte *)((longlong)puVar33 + 2)) ^ 0x800000;
                    uStack_320 = 4;
                  }
                  break;
                case 0x3a:
                  if (iVar30 == 4) {
                    uStack_350 = CONCAT44(uVar36,*(uint *)puVar33);
                    uStack_320 = 4;
                  }
                  else {
                    uStack_350 = (ulonglong)uStack_350._2_6_ << 0x10;
code_r0x00102f44:
                    uStack_350 = (ulonglong)CONCAT42(uStack_350._4_4_,*(ushort *)puVar33) << 0x10;
                    uStack_320 = 4;
                  }
                  break;
                case 0x3b:
                  uStack_350 = (ulonglong)uVar36 << 0x20;
                  if (iVar30 == 1) {
                    bVar6 = *(byte *)puVar33;
code_r0x00103038:
                  }
                  else {
                    if (iVar30 == 2) goto code_r0x00102f44;
                    if (iVar30 == 3) {
                      uStack_350 = (ulonglong)CONCAT52(uStack_350._3_5_,*(ushort *)puVar33) << 8;
                      bVar6 = *(byte *)((longlong)puVar33 + 2);
                      goto code_r0x00103038;
                    }
                    if (iVar30 == 4) {
                      uStack_350 = CONCAT44(uVar36,*(uint *)puVar33);
                      uStack_320 = 4;
                      break;
                    }
                  }
code_r0x0010303b:
                  uStack_320 = 4;
                  break;
                case 0x3c:
                case 0x3d:
                case 0x7f:
                  switch(iVar30) {
                  case 0:
                    uStack_350 = 0;
                    uStack_320 = 8;
                    break;
                  case 1:
                    uStack_320 = 8;
                    uStack_350._1_7_ = (uint7)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 8);
                    uStack_350 = CONCAT71(uStack_350._1_7_,*(byte *)puVar33) ^ 0x80;
                    break;
                  case 2:
                    uStack_350._2_6_ = (uint6)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x10);
                    uStack_350 = CONCAT71(CONCAT61(uStack_350._2_6_,*(byte *)puVar33),
                                          *(byte *)((longlong)puVar33 + 1)) ^ 0x8000;
                    uStack_320 = 8;
                    break;
                  case 3:
                    uStack_350._3_5_ = (undefined5)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x18);
                    uStack_350 = CONCAT71(CONCAT61(CONCAT51(uStack_350._3_5_,*(byte *)puVar33),
                                                   *(byte *)((longlong)puVar33 + 1)),
                                          *(byte *)((longlong)puVar33 + 2)) ^ 0x800000;
                    uStack_320 = 8;
                    break;
                  case 4:
                    uVar36 = *(uint *)puVar33;
                    uStack_350._0_3_ =
                         (uint3)(byte)(uVar36 >> 0x18) | (uint3)(uVar36 >> 8) & 0xff00 |
                         (uint3)((uVar36 & 0xff00) << 8);
                    uStack_350._4_4_ = (uint)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x20);
                    uStack_320 = 8;
                    uStack_350 = CONCAT44(uStack_350._4_4_,
                                          CONCAT13(*(byte *)puVar33,(uint3)uStack_350)) ^ 0x80000000
                    ;
                    break;
                  case 5:
                    uStack_350._5_3_ = (undefined3)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x28);
                    uVar36 = *(uint *)((longlong)puVar33 + 1);
                    uStack_350 = CONCAT44(CONCAT31(uStack_350._5_3_,*(byte *)puVar33),
                                          uVar36 >> 0x18 | (uVar36 & 0xff0000) >> 8 |
                                          (uVar36 & 0xff00) << 8 | uVar36 << 0x18) ^ 0x8000000000;
                    uStack_320 = 8;
                    break;
                  case 6:
                    uStack_350._6_2_ = (undefined2)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x30);
                    uVar36 = *(uint *)((longlong)puVar33 + 2);
                    uStack_350 = CONCAT44(CONCAT31(CONCAT21(uStack_350._6_2_,*(byte *)puVar33),
                                                   *(byte *)((longlong)puVar33 + 1)),
                                          uVar36 >> 0x18 | (uVar36 & 0xff0000) >> 8 |
                                          (uVar36 & 0xff00) << 8 | uVar36 << 0x18) ^ 0x800000000000;
                    uStack_320 = 8;
                    break;
                  case 7:
                    uStack_350._7_1_ = (undefined)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x38);
                    uVar36 = *(uint *)((longlong)puVar33 + 3);
                    uStack_350 = CONCAT44(CONCAT31(CONCAT21(CONCAT11(uStack_350._7_1_,
                                                                     *(byte *)puVar33),
                                                            *(byte *)((longlong)puVar33 + 1)),
                                                   *(byte *)((longlong)puVar33 + 2)),
                                          uVar36 >> 0x18 | (uVar36 & 0xff0000) >> 8 |
                                          (uVar36 & 0xff00) << 8 | uVar36 << 0x18) ^
                                 0x80000000000000;
                    uStack_320 = 8;
                    break;
                  case 8:
                    uVar24 = *puVar33;
                    uVar4 = (uint7)(uVar24 >> 8);
                    uStack_350._0_7_ =
                         (uint7)(byte)(uVar24 >> 0x38) | (uVar4 & 0xff0000000000) >> 0x20 |
                         (uVar4 & 0xff00000000) >> 0x10 | uVar4 & 0xff000000 |
                         (uint7)((uVar24 & 0xff000000) << 8) | (uint7)((uVar24 & 0xff0000) << 0x18)
                         | (uint7)((uVar24 & 0xff00) << 0x28);
                    uStack_320 = 8;
                    uStack_350 = CONCAT17((char)uVar24,(uint7)uStack_350) ^ 0x8000000000000000;
                    break;
                  default:
                    goto code_r0x0010314f;
                  }
                  break;
                case 0x3e:
                  uStack_350 = 0;
                  switch(iVar30) {
                  case 1:
                    uStack_350 = (ulonglong)*(byte *)puVar33 << 0x38;
                    uStack_320 = 8;
                    break;
                  case 2:
                    uStack_350 = (ulonglong)*(ushort *)puVar33 << 0x30;
                    uStack_320 = 8;
                    break;
                  case 3:
                    uStack_350 = (ulonglong)*(uint3 *)puVar33 << 0x28;
                    uStack_320 = 8;
                    break;
                  case 4:
                    uStack_350 = (ulonglong)*(uint *)puVar33 << 0x20;
                    uStack_320 = 8;
                    break;
                  case 5:
                    uStack_350 = (ulonglong)*(uint5 *)puVar33 << 0x18;
                    uStack_320 = 8;
                    break;
                  case 6:
                    uStack_350 = (ulonglong)*(uint6 *)puVar33 << 0x10;
                    uStack_320 = 8;
                    break;
                  case 7:
                    uStack_350 = (ulonglong)*(uint7 *)puVar33 << 8;
                    uStack_320 = 8;
                    break;
                  case 8:
                    uStack_350 = *puVar33;
                  default:
code_r0x0010314f:
                    uStack_320 = 8;
                  }
                  break;
                case 0x6a:
                case 0x6c:
                  apuStack_370[0] = &uStack_320;
                  uStack_378 = &uStack_350;
                  uStack_3a0 = 0x10317f;
                  cVar5 = (*pcRam00000000013fcef0)(puVar33,iVar30,*(byte *)(puVar35 + 0x11) & 0x3f);
                  param_3 = plStack_330;
                  uVar34 = uStack_340;
                  if (cVar5 == '\0') {
                    uStack_3a0 = 0x10319d;
                    (*_DAT_)(6,0x54,0x16,1);
                    param_3 = plStack_330;
                    uVar34 = uStack_340;
                  }
                  break;
                case 0xad:
                case 0xaf:
                  uStack_378 = (undefined8 *)
                               CONCAT71(uStack_378._1_7_,*(undefined *)((longlong)puVar35 + 0x3e));
                  uStack_3a0 = 0x102f78;
                  func_0x(puVar33,iVar30,&uStack_350,uStack_320);
                  param_3 = plStack_330;
                  uVar34 = uStack_340;
                  break;
                case 0xbd:
                  uStack_3a0 = 0x102fae;
                  func_0x
                            (puVar33,iVar30,&uStack_350,*(byte *)((longlong)puVar35 + 0x45) & 0x3f);
                  uStack_320 = 8;
                  param_3 = plStack_330;
                  uVar34 = uStack_340;
                  break;
                case 0xe7:
                  uStack_378 = (undefined8 *)CONCAT44(uStack_378._4_4_,uStack_320);
                  uStack_3a0 = 0x1031c0;
                  uStack_320 = (*pcRam00000000013fcee8)(auStack_160,puVar33,iVar30,&uStack_350);
                  param_3 = plStack_330;
                  uVar34 = uStack_340;
                  break;
                case 0xef:
                  uStack_378 = (undefined8 *)CONCAT44(uStack_378._4_4_,uStack_320);
                  uStack_3a0 = 0x102f9b;
                  (*pcRam00000000013fcef8)(auStack_198,puVar33,iVar30,&uStack_350);
                  param_3 = plStack_330;
                  uVar34 = uStack_340;
                }
              }
              else if (iVar30 == 0) {
                uVar9 = *(ushort *)(puVar35 + 0xf);
                if ((*(byte *)((longlong)piVar17 + 6) & 0x10) == 0) {
code_r0x0010323c:
                  puVar33 = (ulonglong *)((longlong)*piVar17 + *(longlong *)(psVar11 + 4));
                }
                else {
                  uStack_378 = (undefined8 *)&iStack_2a8;
                  uStack_3a0 = 0x1031fd;
                  func_0x(puVar28,piVar17,0,auStack_234);
                  if (iStack_2a8 != 0) goto code_r0x0010323c;
                  puVar33 = (ulonglong *)(*(uint **)(piVar17 + 2) + 1);
                  if ((uVar9 != 0) && (**(uint **)(piVar17 + 2) != (uint)uVar9)) {
                    uStack_378 = (undefined8 *)0x0;
                    uStack_3a0 = 0x10323a;
                    (*_DAT_)(1,0x192f258,0x192dc58,0x381);
                  }
                }
                uStack_350 = *puVar33;
                param_3 = plStack_330;
                uVar34 = uStack_340;
              }
              if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) == 0) {
                lVar12 = param_3[3];
              }
              else {
                lVar12 = param_3[4];
              }
              lVar23 = *(longlong *)(puVar35 + 10);
              *(ulonglong *)(lVar23 + lVar12) = uStack_350;
              uVar36 = puVar35[0x10];
              if ((uVar36 >> 8 & 1) != 0) {
                if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) == 0) {
                  lVar18 = param_3[3];
                }
                else {
                  lVar18 = param_3[4];
                }
                *(ulonglong *)(lVar18 + *(longlong *)(*(longlong *)(puVar35 + 0x12) + 0x18)) =
                     (ulonglong)uStack_320;
                uVar36 = puVar35[0x10];
              }
              psVar14 = uStack_308;
              if ((uVar36 >> 10 & 1) != 0) {
                if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) == 0) {
                  lVar18 = param_3[3];
                }
                else {
                  lVar18 = param_3[4];
                }
                uVar20 = 0;
                if ((ulonglong *)(lVar23 + lVar12) == (ulonglong *)0x0) {
                  uVar20 = 3;
                }
                *(undefined *)(lVar18 + *(longlong *)(puVar35 + 0xc)) = uVar20;
              }
              goto code_r0x00103337;
            }
            uStack_338 = uVar36;
            uVar20 = 0;
            uVar36 = puVar35[0x10];
            if ((uVar36 >> 10 & 1) != 0) {
              if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) == 0) {
                lVar12 = param_3[3];
              }
              else {
                lVar12 = param_3[4];
              }
              if (puVar15 == (uint *)0x0) {
                uVar20 = 3;
              }
              *(undefined *)(lVar12 + *(longlong *)(puVar35 + 0xc)) = uVar20;
              uVar36 = puVar35[0x10];
            }
            if ((uVar36 >> 9 & 1) != 0) {
              uStack_378 = (undefined8 *)CONCAT44(uStack_378._4_4_,uStack_338);
              uStack_3a0 = 0x10332a;
              func_0x();
            }
code_r0x00103337:
            uVar36 = (int)puVar32 + 1;
            puVar32 = (uint *)(ulonglong)uVar36;
            puVar35 = puVar35 + 0x14;
            puVar26 = auStack_398;
          } while (uVar36 < uVar34);
        }
      }
    }
    else if (*(int *)(*(longlong *)(lStack_2f8 + 8) + 0x100) == 2) {
      uStack_340 = *(uint *)(lVar12 + 0x34);
      uVar22 = (ulonglong)uStack_340;
      uVar24 = uVar22 + 0xf;
      if (uVar24 <= uVar22) {
        uVar24 = 0xffffffffffffff0;
      }
      uVar24 = uVar24 & 0xfffffffffffffff0;
      uStack_3a0 = 0x103cef;
      lVar18 = lStack_300;
      func_0x();
      lVar23 = -uVar24;
      psVar11 = *(short **)(lVar18 + 8);
      lVar12 = (longlong)&uStack_358 + lVar23;
      puVar26 = auStack_398 + lVar23;
      lStack_2c0 = lVar12;
      if ((*(byte *)((longlong)plStack_330 + 0x14) & 0x10) != 0) {
        puVar35 = (uint *)plStack_330[1];
        uStack_308 = (short *)CONCAT44(uStack_308._4_4_,*(int *)(plStack_330 + 2));
        uStack_2cc = (uint)puVar32;
        puVar26 = auStack_398 + lVar23;
        plVar10 = plStack_330;
        puVar15 = puVar32;
        if (*(int *)(plStack_330 + 2) != 0) {
          do {
            lVar3 = lStack_2f8;
            uVar36 = (uint)puVar32;
            uVar34 = uStack_33c;
            switch(*(undefined *)(puVar35 + 0x10)) {
            case 0:
              goto code_r0x00106107;
            case 1:
              if (*psVar11 == 0) {
                *(undefined **)((longlong)&uStack_378 + lVar23) = auStack_230;
                *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x103d89;
                func_0x(psVar11 + 1,puVar35,1,&uStack_298);
                uVar34 = uStack_298;
              }
              else {
                uVar9 = *(ushort *)(puVar35 + 1);
                if ((ushort)psVar11[1] < uVar9) {
                  uVar34 = ~(uint)(*(ushort *)((longlong)puVar35 + 6) >> 4) & 1;
                }
                else {
                  bVar6 = *(byte *)((longlong)((int)(uVar9 - 1) / 2) +
                                    (ulonglong)(ushort)psVar11[0xc] + *(longlong *)(psVar11 + 4));
                  bVar19 = bVar6 >> 4;
                  if ((uVar9 & 1) != 0) {
                    bVar19 = bVar6 & 0xf;
                  }
                  uVar34 = (uint)(bVar19 == 0);
                }
              }
              if (uVar34 == 0) goto code_r0x00103df8;
              uStack_33c = 0;
              puVar15 = (uint *)0x0;
              uVar34 = uStack_33c;
              break;
            case 2:
code_r0x00103df8:
              uVar9 = *(ushort *)(puVar35 + 0xf);
              if ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0) {
                *(int **)((longlong)&uStack_378 + lVar23) = &iStack_294;
                *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x103e2c;
                func_0x(psVar11 + 1,puVar35,0,auStack_22c);
                if (iStack_294 == 0) {
                  uVar34 = **(uint **)(puVar35 + 2);
                  puVar15 = *(uint **)(puVar35 + 2) + 1;
                  if ((uVar9 != 0) && (uVar34 != uVar9)) {
                    *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x103e6c;
                    (*_DAT_)(1,0x192f258,0x192dc58,0x381);
                  }
                  break;
                }
              }
              puVar15 = (uint *)((longlong)(int)*puVar35 + *(longlong *)(psVar11 + 4));
              uVar34 = (uint)uVar9;
              break;
            case 3:
              if (*psVar11 == 0) {
                *(undefined **)((longlong)&uStack_378 + lVar23) = auStack_228;
                *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x103ed8;
                func_0x(psVar11 + 1,puVar35,1,&uStack_290);
                uVar34 = uStack_290;
              }
              else {
                uVar9 = *(ushort *)(puVar35 + 1);
                if ((ushort)psVar11[1] < uVar9) {
                  uVar34 = ~(uint)(*(ushort *)((longlong)puVar35 + 6) >> 4) & 1;
                }
                else {
                  bVar6 = *(byte *)((longlong)((int)(uVar9 - 1) / 2) +
                                    (ulonglong)(ushort)psVar11[0xc] + *(longlong *)(psVar11 + 4));
                  bVar19 = bVar6 >> 4;
                  if ((uVar9 & 1) != 0) {
                    bVar19 = bVar6 & 0xf;
                  }
                  uVar34 = (uint)(bVar19 == 0);
                }
              }
              if (uVar34 == 0) {
                puVar32 = (uint *)0x0;
                goto code_r0x00103f4c;
              }
              uStack_33c = 0;
              puVar15 = (uint *)0x0;
              uVar34 = uStack_33c;
              break;
            case 4:
code_r0x00103f4c:
              if (*psVar11 == 0) {
                if (*(int *)(psVar11 + 2) == 0) {
                  uVar34 = *(uint *)(psVar11 + 8);
                  uVar24 = (ulonglong)uVar34;
                  psVar11[1] = (short)puVar32;
                  pbVar21 = *(byte **)(psVar11 + 4);
                  *(uint *)(psVar11 + 10) = uVar34;
                  bVar6 = *pbVar21;
                  if ((bVar6 & 0x10) != 0) {
                    uVar34 = uVar34 + 2 + (*(ushort *)(pbVar21 + uVar24) + 7 >> 3);
                    uVar24 = (ulonglong)uVar34;
                    *(uint *)(psVar11 + 10) = uVar34;
                    bVar6 = *pbVar21;
                  }
                  if ((bVar6 & 0x20) == 0) {
                    *(int *)(psVar11 + 2) = (int)uVar24;
                    psVar11[0xe] = 0;
                    *(int *)(psVar11 + 0xc) = (int)uVar24;
                  }
                  else {
                    puVar28 = (ushort *)(pbVar21 + uVar24);
                    uVar9 = *puVar28;
                    psVar11[0xe] = uVar9;
                    if (uVar9 == 0) {
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x103fbf;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 != '\0') {
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x103fc8;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x103fe2;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 == '\0') {
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x103ffe;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104024;
                            (*_DAT_)(1,0x17814e8,0x18a11b8,0x80f);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar11 + 4);
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104032;
                      func_0x(uVar13,3);
                      uVar24 = (ulonglong)*(uint *)(psVar11 + 10);
                      uVar9 = psVar11[0xe];
                    }
                    uVar34 = (int)uVar24 + (uVar9 + 1) * 2;
                    *(uint *)(psVar11 + 0xc) = uVar34;
                    if (0x1f9e < uVar34) {
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104063;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 != '\0') {
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10406c;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104086;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 == '\0') {
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1040a2;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1040c8;
                            (*_DAT_)(1,0x17814e8,0x18a11b8,0x816);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar11 + 4);
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1040d6;
                      func_0x(uVar13,4);
                      uVar9 = psVar11[0xe];
                      uVar34 = *(uint *)(psVar11 + 0xc);
                    }
                    uVar24 = (ulonglong)uVar9;
                    uVar9 = puVar28[uVar24];
                    *(uint *)(psVar11 + 2) = uVar9 & 0x7fff;
                    if ((uVar9 & 0x7fff) < uVar34) {
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104105;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 != '\0') {
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10410e;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104128;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 == '\0') {
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104144;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10416a;
                            (*_DAT_)(1,0x17814e8,0x18a11b8,0x81d);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar11 + 4);
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104178;
                      func_0x(uVar13,4);
                      uVar24 = (ulonglong)(ushort)psVar11[0xe];
                    }
                    if ((short)puVar28[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                      pbVar21 = *(byte **)(psVar11 + 4);
                      do {
                        if ((int)uVar24 == 1) {
                          uVar34 = *(uint *)(psVar11 + 0xc);
                          uVar22 = (ulonglong)uVar34;
code_r0x001041ca:
                          if ((*(ushort *)
                                (pbVar21 + uVar24 * 2 + (ulonglong)*(uint *)(psVar11 + 10)) & 0x7fff
                              ) < (uint)uVar22) goto code_r0x001041d7;
                        }
                        else {
                          uVar34 = *(uint *)(psVar11 + 0xc);
                          uVar22 = (ulonglong)
                                   (*(ushort *)
                                     (pbVar21 +
                                     uVar24 * 2 + ((ulonglong)*(uint *)(psVar11 + 10) - 2)) & 0x7fff
                                   );
                          if (uVar34 <= (*(ushort *)
                                          (pbVar21 +
                                          uVar24 * 2 + ((ulonglong)*(uint *)(psVar11 + 10) - 2)) &
                                        0x7fff)) goto code_r0x001041ca;
code_r0x001041d7:
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1041e4;
                          func_0x(pbVar21);
                          uVar34 = *(uint *)(psVar11 + 0xc);
                        }
                        if (((uint)uVar22 < uVar34) || (*(uint *)(psVar11 + 2) < (uint)uVar22))
                        goto code_r0x0010443f;
                        pbVar21 = *(byte **)(psVar11 + 4);
                        if (*(ushort *)(pbVar21 + uVar22) == 5) {
                          psVar11[1] = psVar11[1] | 2;
                          psVar11[0xe] = psVar11[0xe] + -1;
                          psVar11[0x15] = (short)uVar22;
                          uVar9 = psVar11[0x16] & 0xc7ff;
                          if ((*(ushort *)(pbVar21 + (uVar22 & 0xffff) + 2) >> 0xe & 1) != 0) {
                            uVar9 = *(ushort *)(pbVar21 + (uVar22 & 0xffff) + 2) & 0x3800 | uVar9;
                          }
                          psVar11[0x16] = uVar9;
                          psVar11[0x16] =
                               (uVar9 ^ *(ushort *)(pbVar21 + (uVar22 & 0xffff) + 2)) & 0x7ff ^
                               uVar9;
                          goto code_r0x001042b5;
                        }
                        if (*(ushort *)(pbVar21 + uVar22) < 0x400) goto code_r0x001042b5;
                        psVar11[1] = psVar11[1] | 1;
                        uVar9 = psVar11[0xe] - 1;
                        psVar11[0xe] = uVar9;
                        if (uVar9 == 0) goto code_r0x001042b5;
                        uVar24 = (ulonglong)uVar9;
                      } while ((short)puVar28[(ulonglong)(uVar9 - 1) + 1] < 0);
                      uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                    }
                    else {
code_r0x001042b5:
                      pbVar21 = *(byte **)(psVar11 + 4);
                      uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                    }
                  }
                  if ((*pbVar21 & 0x40) == 0) {
                    *(undefined4 *)(psVar11 + 0x13) = 0;
                  }
                  else {
                    *(int *)(psVar11 + 0x13) = (int)uVar24;
                    *(int *)(psVar11 + 2) = (int)uVar24 + 0xe;
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1042ea;
                    uVar13 = func_0x(psVar11 + 1);
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1042f9;
                    func_0x(uVar13,auStack_1b8);
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104305;
                    iVar30 = func_0x(auStack_1b8);
                    *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar30;
                    uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                  }
                  iVar30 = (int)uVar24;
                  if ((*(ulonglong *)(psVar11 + 0xf) != 0) &&
                     (*(ulonglong *)(psVar11 + 0xf) < uVar24 + *(longlong *)(psVar11 + 4))) {
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10433f;
                    cVar5 = func_0x(0x1e90760);
                    if (cVar5 != '\0') {
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104348;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104362;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 == '\0') {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10437e;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1043a4;
                          (*_DAT_)(1,0x17814e8,0x18a11b8,0x877);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar11 + 4);
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1043b2;
                    func_0x(uVar13);
                    iVar30 = *(int *)(psVar11 + 2);
                  }
                  if (0x3f3b < iVar30 - 1U) {
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1043cc;
                    cVar5 = func_0x(0x1e90760);
                    if (cVar5 != '\0') {
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1043d5;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1043ef;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 == '\0') {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10440b;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104431;
                          (*_DAT_)(1,0x17814e8,0x18a11b8,0x87c);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar11 + 4);
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10443f;
                    func_0x(uVar13);
                  }
                }
code_r0x0010443f:
                sVar29 = -*(short *)puVar35;
                if ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0) {
                  *(int **)((longlong)&uStack_378 + lVar23) = &iStack_28c;
                  *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104471;
                  func_0x(psVar11 + 1,puVar35,0,auStack_224);
                  if (iStack_28c == 0) {
                    uStack_33c = **(uint **)(puVar35 + 2);
                    puVar15 = *(uint **)(puVar35 + 2) + 1;
                    goto code_r0x00104589;
                  }
                }
                puVar15 = *(uint **)(psVar11 + 4);
                lVar12 = (longlong)sVar29;
                if ((uint)(ushort)psVar11[0xe] < (uint)(int)sVar29) {
                  uStack_33c = 0;
                }
                else {
                  uVar34 = *(uint *)(psVar11 + 10);
                  if (sVar29 == 1) {
                    uVar36 = *(uint *)(psVar11 + 0xc);
                    uVar34 = *(ushort *)((longlong)puVar15 + lVar12 * 2 + (ulonglong)uVar34) &
                             0x7fff;
code_r0x001044dc:
                    if (uVar34 < uVar36) goto code_r0x001044e3;
                  }
                  else {
                    puVar28 = (ushort *)((longlong)puVar15 + lVar12 * 2 + (ulonglong)uVar34);
                    uVar36 = *(ushort *)((longlong)puVar15 + lVar12 * 2 + ((ulonglong)uVar34 - 2)) &
                             0x7fff;
                    puVar15 = *(uint **)(psVar11 + 4);
                    uVar34 = *puVar28 & 0x7fff;
                    if (*(uint *)(psVar11 + 0xc) <= uVar36) goto code_r0x001044dc;
code_r0x001044e3:
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1044f0;
                    func_0x(puVar15);
                    puVar15 = *(uint **)(psVar11 + 4);
                  }
                  puVar15 = (uint *)((ulonglong)uVar36 + (longlong)puVar15);
                  uStack_33c = uVar34 - uVar36;
                }
              }
              else {
                uStack_2e0 = (uint)puVar32;
                *(uint **)((longlong)&uStack_378 + lVar23) = &uStack_2e0;
                *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10452f;
                puVar15 = (uint *)func_0x(psVar11 + 1,puVar35,1,&uStack_33c);
                uVar34 = uStack_33c;
                if ((((*psVar11 != 0) &&
                     (plVar2 = *(longlong **)(psVar11 + 8), plVar2 != (longlong *)0x0)) &&
                    (*plVar2 != 0)) &&
                   (((*(byte *)((longlong)puVar35 + 6) & 8) == 0 && ((uStack_2e0 & 1) == 0)))) {
                  *(uint *)((longlong)auStack_360 + lVar23) = uStack_2e0;
                  *(uint **)((longlong)apuStack_370 + lVar23 + 8) = &uStack_33c;
                  *(int *)((longlong)apuStack_370 + lVar23) = (int)uVar22;
                  *(longlong *)((longlong)&uStack_378 + lVar23) = lVar12;
                  *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10457d;
                  puVar15 = (uint *)func_0x(plVar2,puVar35,puVar15,uVar34);
                }
                if (puVar15 == (uint *)0x0) {
                  puVar15 = *(uint **)(psVar11 + 4);
                }
              }
code_r0x00104589:
              if ((uStack_33c == 0) && ((puVar35[0x10] & 0x2000) != 0)) {
                uStack_33c = 4;
                puVar15 = (uint *)0x152788c;
              }
              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1045b0;
              iVar30 = func_0x(psVar11);
              if (iVar30 != 0) {
                *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1045bc;
                iVar30 = func_0x(puVar35);
                uVar34 = uStack_33c;
                if (iVar30 != 0) break;
              }
              uVar34 = uStack_33c;
              if (*(ushort *)(puVar35 + 0xf) < uStack_33c) {
                *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1045e9;
                (*_DAT_)(6,0x52,0x16,0x91);
                uVar34 = uStack_33c;
              }
              break;
            case 5:
              puVar15 = *(uint **)(psVar11 + 4);
              if (*psVar11 == 0) {
                if (*(int *)(psVar11 + 2) == 0) {
                  uVar34 = *(uint *)(psVar11 + 8);
                  uVar24 = (ulonglong)uVar34;
                  psVar11[1] = (short)puVar32;
                  pbVar21 = *(byte **)(psVar11 + 4);
                  *(uint *)(psVar11 + 10) = uVar34;
                  bVar6 = *pbVar21;
                  if ((bVar6 & 0x10) != 0) {
                    uVar34 = uVar34 + 2 + (*(ushort *)(pbVar21 + uVar24) + 7 >> 3);
                    uVar24 = (ulonglong)uVar34;
                    *(uint *)(psVar11 + 10) = uVar34;
                    bVar6 = *pbVar21;
                  }
                  if ((bVar6 & 0x20) == 0) {
                    *(int *)(psVar11 + 2) = (int)uVar24;
                    psVar11[0xe] = 0;
                    *(int *)(psVar11 + 0xc) = (int)uVar24;
                  }
                  else {
                    puVar28 = (ushort *)(pbVar21 + uVar24);
                    uVar9 = *puVar28;
                    psVar11[0xe] = uVar9;
                    if (uVar9 == 0) {
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104e86;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 != '\0') {
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104e8f;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104ea9;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 == '\0') {
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104ec5;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104eeb;
                            (*_DAT_)(1,0x17814e8,0x18a11b8,0x80f);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar11 + 4);
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104ef9;
                      func_0x(uVar13,3);
                      uVar24 = (ulonglong)*(uint *)(psVar11 + 10);
                      uVar9 = psVar11[0xe];
                    }
                    uVar34 = (int)uVar24 + (uVar9 + 1) * 2;
                    *(uint *)(psVar11 + 0xc) = uVar34;
                    if (0x1f9e < uVar34) {
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104f2a;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 != '\0') {
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104f33;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104f4d;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 == '\0') {
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104f69;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104f8f;
                            (*_DAT_)(1,0x17814e8,0x18a11b8,0x816);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar11 + 4);
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104f9d;
                      func_0x(uVar13,4);
                      uVar9 = psVar11[0xe];
                      uVar34 = *(uint *)(psVar11 + 0xc);
                    }
                    uVar24 = (ulonglong)uVar9;
                    uVar9 = puVar28[uVar24];
                    *(uint *)(psVar11 + 2) = uVar9 & 0x7fff;
                    if ((uVar9 & 0x7fff) < uVar34) {
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104fcc;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 != '\0') {
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104fd5;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104fef;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 == '\0') {
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10500b;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105031;
                            (*_DAT_)(1,0x17814e8,0x18a11b8,0x81d);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar11 + 4);
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10503f;
                      func_0x(uVar13,4);
                      uVar24 = (ulonglong)(ushort)psVar11[0xe];
                    }
                    if ((short)puVar28[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                      pbVar21 = *(byte **)(psVar11 + 4);
                      do {
                        if ((int)uVar24 == 1) {
                          uVar34 = *(uint *)(psVar11 + 0xc);
                          uVar22 = (ulonglong)uVar34;
code_r0x0010508a:
                          if ((*(ushort *)
                                (pbVar21 + uVar24 * 2 + (ulonglong)*(uint *)(psVar11 + 10)) & 0x7fff
                              ) < (uint)uVar22) goto code_r0x00105097;
                        }
                        else {
                          uVar34 = *(uint *)(psVar11 + 0xc);
                          uVar22 = (ulonglong)
                                   (*(ushort *)
                                     (pbVar21 +
                                     uVar24 * 2 + ((ulonglong)*(uint *)(psVar11 + 10) - 2)) & 0x7fff
                                   );
                          if (uVar34 <= (*(ushort *)
                                          (pbVar21 +
                                          uVar24 * 2 + ((ulonglong)*(uint *)(psVar11 + 10) - 2)) &
                                        0x7fff)) goto code_r0x0010508a;
code_r0x00105097:
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1050a4;
                          func_0x(pbVar21,7);
                          uVar34 = *(uint *)(psVar11 + 0xc);
                        }
                        if (((uint)uVar22 < uVar34) || (*(uint *)(psVar11 + 2) < (uint)uVar22))
                        goto code_r0x001052ff;
                        pbVar21 = *(byte **)(psVar11 + 4);
                        if (*(ushort *)(pbVar21 + uVar22) == 5) {
                          psVar11[1] = psVar11[1] | 2;
                          psVar11[0xe] = psVar11[0xe] + -1;
                          psVar11[0x15] = (short)uVar22;
                          uVar9 = psVar11[0x16] & 0xc7ff;
                          if ((*(ushort *)(pbVar21 + (uVar22 & 0xffff) + 2) >> 0xe & 1) != 0) {
                            uVar9 = *(ushort *)(pbVar21 + (uVar22 & 0xffff) + 2) & 0x3800 | uVar9;
                          }
                          psVar11[0x16] = uVar9;
                          psVar11[0x16] =
                               (uVar9 ^ *(ushort *)(pbVar21 + (uVar22 & 0xffff) + 2)) & 0x7ff ^
                               uVar9;
                          goto code_r0x00105175;
                        }
                        if (*(ushort *)(pbVar21 + uVar22) < 0x400) goto code_r0x00105175;
                        psVar11[1] = psVar11[1] | 1;
                        uVar9 = psVar11[0xe] - 1;
                        psVar11[0xe] = uVar9;
                        if (uVar9 == 0) goto code_r0x00105175;
                        uVar24 = (ulonglong)uVar9;
                      } while ((short)puVar28[(ulonglong)(uVar9 - 1) + 1] < 0);
                      uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                    }
                    else {
code_r0x00105175:
                      pbVar21 = *(byte **)(psVar11 + 4);
                      uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                    }
                  }
                  if ((*pbVar21 & 0x40) == 0) {
                    *(undefined4 *)(psVar11 + 0x13) = 0;
                  }
                  else {
                    *(int *)(psVar11 + 0x13) = (int)uVar24;
                    *(int *)(psVar11 + 2) = (int)uVar24 + 0xe;
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1051aa;
                    uVar13 = func_0x(psVar11 + 1);
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1051b9;
                    func_0x(uVar13,auStack_1a8);
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1051c5;
                    iVar30 = func_0x(auStack_1a8);
                    *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar30;
                    uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                  }
                  iVar30 = (int)uVar24;
                  if ((*(ulonglong *)(psVar11 + 0xf) != 0) &&
                     (*(ulonglong *)(psVar11 + 0xf) < uVar24 + *(longlong *)(psVar11 + 4))) {
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1051ff;
                    cVar5 = func_0x(0x1e90760);
                    if (cVar5 != '\0') {
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105208;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105222;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 == '\0') {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10523e;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105264;
                          (*_DAT_)(1,0x17814e8,0x18a11b8,0x877);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar11 + 4);
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105272;
                    func_0x(uVar13,0x12);
                    iVar30 = *(int *)(psVar11 + 2);
                  }
                  if (0x3f3b < iVar30 - 1U) {
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10528c;
                    cVar5 = func_0x(0x1e90760);
                    if (cVar5 != '\0') {
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105295;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1052af;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 == '\0') {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1052cb;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1052f1;
                          (*_DAT_)(1,0x17814e8,0x18a11b8,0x87c);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(psVar11 + 4);
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1052ff;
                    func_0x(uVar13,5);
                  }
                }
code_r0x001052ff:
                uVar34 = *(uint *)(psVar11 + 2);
                if ((uVar34 < 9) &&
                   (((**(byte **)(psVar11 + 4) & 0xe) == 0 ||
                    ((**(byte **)(psVar11 + 4) & 0xe) == 0xc)))) {
                  uStack_33c = 9;
                  uVar34 = uStack_33c;
                }
              }
              else {
                *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10532f;
                uVar34 = func_0x(psVar11 + 1);
              }
              break;
            case 6:
            case 7:
            case 9:
            case 10:
            case 0xb:
            case 0xe:
            case 0xf:
            case 0x19:
              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105347;
              func_0x(lVar18,puVar35,plVar10);
              goto code_r0x00106101;
            case 8:
              uVar9 = *(ushort *)(puVar35 + 0xf);
              iVar30 = puVar35[0x10] << 0xc;
              uVar24 = CONCAT71((int7)((ulonglong)puVar32 >> 8),iVar30 < 0) & 0xffffffff;
              if (*psVar11 == 0) {
                if ((*puVar35 & 0xc0000000) == 0x80000000) {
                  *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104d47;
                  iVar30 = func_0x(psVar11 + 1);
                  if (iVar30 == 0) {
                    uStack_33c = 0;
                    puVar15 = (uint *)0x0;
                    uVar34 = uStack_33c;
                  }
                  else {
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104d62;
                    puVar15 = (uint *)func_0x(psVar11 + 0x15,puVar35,&uStack_33c,auStack_218
                                                     );
                    uVar34 = uStack_33c;
                  }
                }
                else {
                  if ((iVar30 < 0) || ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0)) {
                    *(int **)((longlong)&uStack_378 + lVar23) = &iStack_2d8;
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104664;
                    func_0x(psVar11 + 1,puVar35,uVar24,&uStack_2dc);
                    if ((iVar30 < 0) && (uStack_2dc != 0)) {
                      uStack_33c = 0;
                      puVar15 = (uint *)0x0;
                      uVar34 = uStack_33c;
                      break;
                    }
                    puVar32 = (uint *)0x0;
                  }
                  else {
                    iStack_2d8 = 1;
                    uStack_2dc = uVar36;
                  }
                  if ((iStack_2d8 == 0) && ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0)) {
                    puVar15 = *(uint **)(puVar35 + 2) + 1;
                    uVar34 = **(uint **)(puVar35 + 2);
                  }
                  else if ((int)*puVar35 < 0) {
                    if (*(int *)(psVar11 + 2) == 0) {
                      uVar34 = *(uint *)(psVar11 + 8);
                      uVar24 = (ulonglong)uVar34;
                      psVar11[1] = (short)puVar32;
                      pbVar21 = *(byte **)(psVar11 + 4);
                      *(uint *)(psVar11 + 10) = uVar34;
                      bVar6 = *pbVar21;
                      if ((bVar6 & 0x10) != 0) {
                        uVar34 = uVar34 + 2 + (*(ushort *)(pbVar21 + uVar24) + 7 >> 3);
                        uVar24 = (ulonglong)uVar34;
                        *(uint *)(psVar11 + 10) = uVar34;
                        bVar6 = *pbVar21;
                      }
                      if ((bVar6 & 0x20) == 0) {
                        *(int *)(psVar11 + 2) = (int)uVar24;
                        psVar11[0xe] = 0;
                        *(int *)(psVar11 + 0xc) = (int)uVar24;
                      }
                      else {
                        puVar28 = (ushort *)(pbVar21 + uVar24);
                        uVar9 = *puVar28;
                        psVar11[0xe] = uVar9;
                        if (uVar9 == 0) {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1047e2;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 != '\0') {
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1047eb;
                            lVar12 = func_0x();
                            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104805;
                              cVar5 = func_0x(0x1e90760);
                              if (cVar5 == '\0') {
                                *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104821;
                                (*_DAT_)(0x22,0x44,0x15,0x3eb);
                              }
                              else {
                                *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                                *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104847;
                                (*_DAT_)(1,0x17814e8,0x18a11b8,0x80f);
                              }
                            }
                          }
                          uVar13 = *(undefined8 *)(psVar11 + 4);
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104855;
                          func_0x(uVar13,3);
                          uVar24 = (ulonglong)*(uint *)(psVar11 + 10);
                          uVar9 = psVar11[0xe];
                        }
                        uVar34 = (int)uVar24 + (uVar9 + 1) * 2;
                        *(uint *)(psVar11 + 0xc) = uVar34;
                        if (0x1f9e < uVar34) {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104886;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 != '\0') {
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10488f;
                            lVar12 = func_0x();
                            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1048a9;
                              cVar5 = func_0x(0x1e90760);
                              if (cVar5 == '\0') {
                                *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1048c5;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                                *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1048eb;
                                (*_DAT_)(1,0x17814e8,0x18a11b8,0x816);
                              }
                            }
                          }
                          uVar13 = *(undefined8 *)(psVar11 + 4);
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1048f9;
                          func_0x(uVar13,4);
                          uVar9 = psVar11[0xe];
                          uVar34 = *(uint *)(psVar11 + 0xc);
                        }
                        uVar24 = (ulonglong)uVar9;
                        uVar9 = puVar28[uVar24];
                        *(uint *)(psVar11 + 2) = uVar9 & 0x7fff;
                        if ((uVar9 & 0x7fff) < uVar34) {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104928;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 != '\0') {
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104931;
                            lVar12 = func_0x();
                            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10494b;
                              cVar5 = func_0x(0x1e90760);
                              if (cVar5 == '\0') {
                                *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104967;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                                *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10498d;
                                (*_DAT_)(1,0x17814e8,0x18a11b8,0x81d);
                              }
                            }
                          }
                          uVar13 = *(undefined8 *)(psVar11 + 4);
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10499b;
                          func_0x(uVar13,4);
                          uVar24 = (ulonglong)(ushort)psVar11[0xe];
                        }
                        if ((short)puVar28[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                          pbVar21 = *(byte **)(psVar11 + 4);
                          do {
                            if ((int)uVar24 == 1) {
                              uVar34 = *(uint *)(psVar11 + 0xc);
                              uVar36 = uVar34;
code_r0x001049ea:
                              if ((*(ushort *)
                                    (pbVar21 + uVar24 * 2 + (ulonglong)*(uint *)(psVar11 + 10)) &
                                  0x7fff) < uVar34) goto code_r0x001049f7;
                            }
                            else {
                              uVar36 = *(uint *)(psVar11 + 0xc);
                              uVar34 = *(ushort *)
                                        (pbVar21 +
                                        uVar24 * 2 + ((ulonglong)*(uint *)(psVar11 + 10) - 2)) &
                                       0x7fff;
                              if (uVar36 <= uVar34) goto code_r0x001049ea;
code_r0x001049f7:
                              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104a04;
                              func_0x(pbVar21);
                              uVar36 = *(uint *)(psVar11 + 0xc);
                            }
                            if ((uVar34 < uVar36) || (*(uint *)(psVar11 + 2) < uVar34))
                            goto code_r0x00104c5b;
                            pbVar21 = *(byte **)(psVar11 + 4);
                            if (*(ushort *)(pbVar21 + uVar34) == 5) {
                              psVar11[1] = psVar11[1] | 2;
                              psVar11[0xe] = psVar11[0xe] + -1;
                              psVar11[0x15] = (short)uVar34;
                              uVar9 = psVar11[0x16] & 0xc7ff;
                              if ((*(ushort *)(pbVar21 + (ulonglong)(uVar34 & 0xffff) + 2) >> 0xe &
                                  1) != 0) {
                                uVar9 = *(ushort *)(pbVar21 + (ulonglong)(uVar34 & 0xffff) + 2) &
                                        0x3800 | uVar9;
                              }
                              psVar11[0x16] = uVar9;
                              psVar11[0x16] =
                                   (uVar9 ^ *(ushort *)(pbVar21 + (ulonglong)(uVar34 & 0xffff) + 2))
                                   & 0x7ff ^ uVar9;
                              goto code_r0x00104ad5;
                            }
                            if (*(ushort *)(pbVar21 + uVar34) < 0x400) goto code_r0x00104ad5;
                            psVar11[1] = psVar11[1] | 1;
                            uVar9 = psVar11[0xe] - 1;
                            psVar11[0xe] = uVar9;
                            if (uVar9 == 0) goto code_r0x00104ad5;
                            uVar24 = (ulonglong)uVar9;
                          } while ((short)puVar28[(ulonglong)(uVar9 - 1) + 1] < 0);
                          uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                        }
                        else {
code_r0x00104ad5:
                          pbVar21 = *(byte **)(psVar11 + 4);
                          uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                        }
                      }
                      if ((*pbVar21 & 0x40) == 0) {
                        *(undefined4 *)(psVar11 + 0x13) = 0;
                      }
                      else {
                        *(int *)(psVar11 + 0x13) = (int)uVar24;
                        *(int *)(psVar11 + 2) = (int)uVar24 + 0xe;
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104b0a;
                        uVar13 = func_0x(psVar11 + 1);
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104b19;
                        func_0x(uVar13,auStack_1b0);
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104b25;
                        iVar30 = func_0x(auStack_1b0);
                        *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar30;
                        uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                      }
                      iVar30 = (int)uVar24;
                      if ((*(ulonglong *)(psVar11 + 0xf) != 0) &&
                         (*(ulonglong *)(psVar11 + 0xf) < uVar24 + *(longlong *)(psVar11 + 4))) {
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104b5f;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 != '\0') {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104b68;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104b82;
                            cVar5 = func_0x(0x1e90760);
                            if (cVar5 == '\0') {
                              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104b9e;
                              (*_DAT_)(0x22,0x44,0x15,0x3fa);
                            }
                            else {
                              *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104bc2;
                              (*_DAT_)(1,0x17814e8,0x18a11b8,0x877);
                            }
                          }
                        }
                        uVar13 = *(undefined8 *)(psVar11 + 4);
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104bd0;
                        func_0x(uVar13);
                        iVar30 = *(int *)(psVar11 + 2);
                      }
                      if (0x3f3b < iVar30 - 1U) {
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104bea;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 != '\0') {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104bf3;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104c0d;
                            cVar5 = func_0x(0x1e90760);
                            if (cVar5 == '\0') {
                              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104c29;
                              (*_DAT_)(0x22,0x44,0x15,0x3ed);
                            }
                            else {
                              *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104c4d;
                              (*_DAT_)(1,0x17814e8,0x18a11b8,0x87c);
                            }
                          }
                        }
                        uVar13 = *(undefined8 *)(psVar11 + 4);
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104c5b;
                        func_0x(uVar13);
                      }
                    }
code_r0x00104c5b:
                    sVar29 = -*(short *)puVar35;
                    if ((*(byte *)((longlong)puVar35 + 6) & 0x10) != 0) {
                      *(int **)((longlong)&uStack_378 + lVar23) = &iStack_254;
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104c8d;
                      func_0x(psVar11 + 1,puVar35,0,auStack_21c);
                      if (iStack_254 == 0) {
                        puVar15 = *(uint **)(puVar35 + 2) + 1;
                        uVar34 = **(uint **)(puVar35 + 2);
                        break;
                      }
                    }
                    puVar15 = *(uint **)(psVar11 + 4);
                    lVar12 = (longlong)sVar29;
                    if ((uint)(ushort)psVar11[0xe] < (uint)(int)sVar29) {
                      uVar34 = 0;
                    }
                    else {
                      uVar34 = *(uint *)(psVar11 + 10);
                      if (sVar29 == 1) {
                        uVar36 = *(uint *)(psVar11 + 0xc);
                        uVar34 = *(ushort *)((longlong)puVar15 + lVar12 * 2 + (ulonglong)uVar34) &
                                 0x7fff;
code_r0x00104cfe:
                        if (uVar34 < uVar36) goto code_r0x00104d05;
                      }
                      else {
                        puVar28 = (ushort *)((longlong)puVar15 + lVar12 * 2 + (ulonglong)uVar34);
                        uVar36 = *(ushort *)
                                  ((longlong)puVar15 + lVar12 * 2 + ((ulonglong)uVar34 - 2)) &
                                 0x7fff;
                        puVar15 = *(uint **)(psVar11 + 4);
                        uVar34 = *puVar28 & 0x7fff;
                        if (*(uint *)(psVar11 + 0xc) <= uVar36) goto code_r0x00104cfe;
code_r0x00104d05:
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104d12;
                        func_0x(puVar15);
                        puVar15 = *(uint **)(psVar11 + 4);
                      }
                      puVar15 = (uint *)((ulonglong)uVar36 + (longlong)puVar15);
                      uVar34 = uVar34 - uVar36;
                    }
                  }
                  else if ((*(ushort *)((longlong)puVar35 + 6) & 8) == 0) {
                    if ((*(ushort *)((longlong)puVar35 + 6) & 0x10) != 0) {
                      *(int **)((longlong)&uStack_378 + lVar23) = &iStack_288;
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1046f1;
                      func_0x(psVar11 + 1,puVar35,0,auStack_220);
                      if (iStack_288 == 0) {
                        uVar34 = **(uint **)(puVar35 + 2);
                        puVar15 = *(uint **)(puVar35 + 2) + 1;
                        if ((uVar9 != 0) && (uVar34 != uVar9)) {
                          *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104739;
                          (*_DAT_)(1,0x192f258,0x192dc58,0x381);
                        }
                        break;
                      }
                    }
                    puVar15 = (uint *)((longlong)(int)*puVar35 + *(longlong *)(psVar11 + 4));
                    uVar34 = (uint)uVar9;
                  }
                  else {
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10476d;
                    puVar15 = (uint *)func_0x(psVar11 + 1,puVar35,&uStack_33c);
                    uVar34 = uStack_33c;
                  }
                }
              }
              else {
                uStack_2d4 = uVar36;
                *(uint **)((longlong)&uStack_378 + lVar23) = &uStack_2d4;
                *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104da3;
                puVar15 = (uint *)func_0x(psVar11 + 1,puVar35,uVar24,&uStack_33c);
                uVar34 = uStack_33c;
                if ((((*psVar11 != 0) &&
                     (plVar2 = *(longlong **)(psVar11 + 8), plVar2 != (longlong *)0x0)) &&
                    (*plVar2 != 0)) &&
                   (((*(byte *)((longlong)puVar35 + 6) & 8) == 0 && ((uStack_2d4 & 1) == 0)))) {
                  *(uint *)((longlong)auStack_360 + lVar23) = uStack_2d4;
                  *(uint **)((longlong)apuStack_370 + lVar23 + 8) = &uStack_33c;
                  *(undefined4 *)((longlong)apuStack_370 + lVar23) = 0;
                  *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                  *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x104df6;
                  puVar15 = (uint *)func_0x(plVar2,puVar35,puVar15,uVar34);
                  uVar34 = uStack_33c;
                }
              }
              break;
            case 0xd:
            case 0x1b:
              puVar15 = puVar32;
              uVar34 = uVar36;
              break;
            case 0x10:
              uVar13 = **(undefined8 **)(*(longlong *)(lStack_2f8 + 8) + 0x160);
              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10536b;
              piVar17 = (int *)func_0x(uVar13,0);
              auStack_310[0] = 0;
              uStack_318 = 8;
              iVar30 = *(int *)(*(longlong *)(lVar3 + 8) + 0x100);
              if (iVar30 == 2) {
                if (*psVar11 == 0) {
                  if (*(int *)(psVar11 + 2) == 0) {
                    pbVar21 = *(byte **)(psVar11 + 4);
                    uVar34 = *(uint *)(psVar11 + 8);
                    uVar24 = (ulonglong)uVar34;
                    psVar11[1] = 0;
                    *(uint *)(psVar11 + 10) = uVar34;
                    bVar6 = *pbVar21;
                    if ((bVar6 & 0x10) != 0) {
                      uVar34 = uVar34 + 2 + (*(ushort *)(pbVar21 + uVar24) + 7 >> 3);
                      uVar24 = (ulonglong)uVar34;
                      *(uint *)(psVar11 + 10) = uVar34;
                      bVar6 = *pbVar21;
                    }
                    if ((bVar6 & 0x20) == 0) {
                      *(int *)(psVar11 + 2) = (int)uVar24;
                      psVar11[0xe] = 0;
                      *(int *)(psVar11 + 0xc) = (int)uVar24;
                    }
                    else {
                      puVar28 = (ushort *)(pbVar21 + uVar24);
                      uVar9 = *puVar28;
                      psVar11[0xe] = uVar9;
                      if (uVar9 == 0) {
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105402;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 != '\0') {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10540b;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105424;
                            cVar5 = func_0x(0x1e90760);
                            if (cVar5 == '\0') {
                              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105440;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105466;
                              (*_DAT_)(1,0x17814e8,0x18a11b8,0x80f);
                            }
                          }
                        }
                        uVar13 = *(undefined8 *)(psVar11 + 4);
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105474;
                        func_0x(uVar13,3);
                        uVar24 = (ulonglong)*(uint *)(psVar11 + 10);
                        uVar9 = psVar11[0xe];
                      }
                      uVar34 = (int)uVar24 + (uVar9 + 1) * 2;
                      *(uint *)(psVar11 + 0xc) = uVar34;
                      if (0x1f9e < uVar34) {
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1054a5;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 != '\0') {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1054ae;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1054c7;
                            cVar5 = func_0x(0x1e90760);
                            if (cVar5 == '\0') {
                              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1054e3;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105509;
                              (*_DAT_)(1,0x17814e8,0x18a11b8,0x816);
                            }
                          }
                        }
                        uVar13 = *(undefined8 *)(psVar11 + 4);
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105517;
                        func_0x(uVar13,4);
                        uVar9 = psVar11[0xe];
                        uVar34 = *(uint *)(psVar11 + 0xc);
                      }
                      uVar24 = (ulonglong)uVar9;
                      uVar9 = puVar28[uVar24];
                      *(uint *)(psVar11 + 2) = uVar9 & 0x7fff;
                      if ((uVar9 & 0x7fff) < uVar34) {
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105546;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 != '\0') {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10554f;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105568;
                            cVar5 = func_0x(0x1e90760);
                            if (cVar5 == '\0') {
                              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105584;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1055aa;
                              (*_DAT_)(1,0x17814e8,0x18a11b8,0x81d);
                            }
                          }
                        }
                        uVar13 = *(undefined8 *)(psVar11 + 4);
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1055b8;
                        func_0x(uVar13,4);
                        uVar24 = (ulonglong)(ushort)psVar11[0xe];
                      }
                      if ((short)puVar28[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                        pbVar21 = *(byte **)(psVar11 + 4);
                        do {
                          if ((int)uVar24 == 1) {
                            uVar34 = *(uint *)(psVar11 + 0xc);
                            uVar36 = uVar34;
code_r0x001055fb:
                            if ((*(ushort *)
                                  (pbVar21 + uVar24 * 2 + (ulonglong)*(uint *)(psVar11 + 10)) &
                                0x7fff) < uVar34) goto code_r0x00105608;
                          }
                          else {
                            uVar36 = *(uint *)(psVar11 + 0xc);
                            uVar34 = *(ushort *)
                                      (pbVar21 +
                                      uVar24 * 2 + ((ulonglong)*(uint *)(psVar11 + 10) - 2)) &
                                     0x7fff;
                            if (uVar36 <= uVar34) goto code_r0x001055fb;
code_r0x00105608:
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105615;
                            func_0x(pbVar21,7);
                            uVar36 = *(uint *)(psVar11 + 0xc);
                          }
                          if ((uVar34 < uVar36) || (*(uint *)(psVar11 + 2) < uVar34))
                          goto code_r0x0010586e;
                          pbVar21 = *(byte **)(psVar11 + 4);
                          if (*(ushort *)(pbVar21 + uVar34) == 5) {
                            psVar11[1] = psVar11[1] | 2;
                            psVar11[0xe] = psVar11[0xe] + -1;
                            psVar11[0x15] = (short)uVar34;
                            uVar9 = psVar11[0x16] & 0xc7ff;
                            if ((*(ushort *)(pbVar21 + (ulonglong)(uVar34 & 0xffff) + 2) >> 0xe & 1)
                                != 0) {
                              uVar9 = *(ushort *)(pbVar21 + (ulonglong)(uVar34 & 0xffff) + 2) &
                                      0x3800 | uVar9;
                            }
                            psVar11[0x16] = uVar9;
                            psVar11[0x16] =
                                 (uVar9 ^ *(ushort *)(pbVar21 + (ulonglong)(uVar34 & 0xffff) + 2)) &
                                 0x7ff ^ uVar9;
                            goto code_r0x001056e8;
                          }
                          if (*(ushort *)(pbVar21 + uVar34) < 0x400) goto code_r0x001056e8;
                          psVar11[1] = psVar11[1] | 1;
                          uVar9 = psVar11[0xe] - 1;
                          psVar11[0xe] = uVar9;
                          if (uVar9 == 0) goto code_r0x001056e8;
                          uVar24 = (ulonglong)uVar9;
                        } while ((short)puVar28[(ulonglong)(uVar9 - 1) + 1] < 0);
                        uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                      }
                      else {
code_r0x001056e8:
                        pbVar21 = *(byte **)(psVar11 + 4);
                        uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                      }
                    }
                    if ((*pbVar21 & 0x40) == 0) {
                      *(undefined4 *)(psVar11 + 0x13) = 0;
                    }
                    else {
                      *(int *)(psVar11 + 0x13) = (int)uVar24;
                      *(int *)(psVar11 + 2) = (int)uVar24 + 0xe;
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105719;
                      uVar13 = func_0x(psVar11 + 1);
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105728;
                      func_0x(uVar13,auStack_1a0);
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105734;
                      iVar30 = func_0x(auStack_1a0);
                      *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar30;
                      uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                    }
                    iVar30 = (int)uVar24;
                    if ((*(ulonglong *)(psVar11 + 0xf) != 0) &&
                       (*(ulonglong *)(psVar11 + 0xf) < uVar24 + *(longlong *)(psVar11 + 4))) {
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10576e;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 != '\0') {
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105777;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105791;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 == '\0') {
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1057ad;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1057d3;
                            (*_DAT_)(1,0x17814e8,0x18a11b8,0x877);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar11 + 4);
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1057e1;
                      func_0x(uVar13,0x12);
                      iVar30 = *(int *)(psVar11 + 2);
                    }
                    if (0x3f3b < iVar30 - 1U) {
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1057fb;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 != '\0') {
                        *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105804;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10581e;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 == '\0') {
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10583a;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                            *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105860;
                            (*_DAT_)(1,0x17814e8,0x18a11b8,0x87c);
                          }
                        }
                      }
                      uVar13 = *(undefined8 *)(psVar11 + 4);
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10586e;
                      func_0x(uVar13,5);
                    }
                  }
code_r0x0010586e:
                  sVar29 = -*(short *)piVar17;
                  if ((*(byte *)((longlong)piVar17 + 6) & 0x10) != 0) {
                    *(int **)((longlong)&uStack_378 + lVar23) = &iStack_280;
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10589e;
                    func_0x(psVar11 + 1,piVar17,0,auStack_214);
                    if (iStack_280 == 0) {
                      auStack_310[0] = **(uint **)(piVar17 + 2);
                      puVar33 = (ulonglong *)(*(uint **)(piVar17 + 2) + 1);
                      goto code_r0x001059c4;
                    }
                  }
                  puVar33 = *(ulonglong **)(psVar11 + 4);
                  lVar12 = (longlong)sVar29;
                  if ((uint)(ushort)psVar11[0xe] < (uint)(int)sVar29) {
                    auStack_310[0] = 0;
                  }
                  else {
                    uVar34 = *(uint *)(psVar11 + 10);
                    if (sVar29 == 1) {
                      uVar36 = *(uint *)(psVar11 + 0xc);
                      uVar34 = *(ushort *)((longlong)puVar33 + lVar12 * 2 + (ulonglong)uVar34) &
                               0x7fff;
code_r0x00105908:
                      if (uVar34 < uVar36) goto code_r0x0010590f;
                    }
                    else {
                      puVar28 = (ushort *)((longlong)puVar33 + lVar12 * 2 + (ulonglong)uVar34);
                      uVar36 = *(ushort *)((longlong)puVar33 + lVar12 * 2 + ((ulonglong)uVar34 - 2))
                               & 0x7fff;
                      puVar33 = *(ulonglong **)(psVar11 + 4);
                      uVar34 = *puVar28 & 0x7fff;
                      if (*(uint *)(psVar11 + 0xc) <= uVar36) goto code_r0x00105908;
code_r0x0010590f:
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x10591c;
                      func_0x(puVar33,7);
                      puVar33 = *(ulonglong **)(psVar11 + 4);
                    }
                    puVar33 = (ulonglong *)((ulonglong)uVar36 + (longlong)puVar33);
                    auStack_310[0] = uVar34 - uVar36;
                  }
                }
                else {
                  uStack_2d0 = 0;
                  *(uint **)((longlong)&uStack_378 + lVar23) = &uStack_2d0;
                  *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105965;
                  puVar33 = (ulonglong *)func_0x(psVar11 + 1,piVar17,1,auStack_310);
                  uVar34 = auStack_310[0];
                  if ((((*psVar11 != 0) &&
                       (plVar10 = *(longlong **)(psVar11 + 8), plVar10 != (longlong *)0x0)) &&
                      (*plVar10 != 0)) &&
                     (((*(byte *)((longlong)piVar17 + 6) & 8) == 0 && ((uStack_2d0 & 1) == 0)))) {
                    *(uint *)((longlong)auStack_360 + lVar23) = uStack_2d0;
                    *(uint **)((longlong)apuStack_370 + lVar23 + 8) = auStack_310;
                    *(int *)((longlong)apuStack_370 + lVar23) = (int)uVar22;
                    *(longlong *)((longlong)&uStack_378 + lVar23) = lVar12;
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1059b5;
                    puVar33 = (ulonglong *)func_0x(plVar10,piVar17,puVar33,uVar34);
                  }
                  if (puVar33 == (ulonglong *)0x0) {
                    puVar33 = *(ulonglong **)(psVar11 + 4);
                  }
                }
code_r0x001059c4:
                uVar36 = auStack_310[0];
                bVar6 = *(byte *)(puVar35 + 0x11);
                uVar34 = uStack_358._4_4_;
                switch(*(undefined *)((longlong)puVar35 + 0x3e)) {
                case 0x30:
                  if (auStack_310[0] == 0) {
                    uStack_358 = (ulonglong)uStack_358._1_7_ << 8;
                    uStack_318 = 1;
                  }
                  else {
                    uStack_358 = CONCAT71(uStack_358._1_7_,*(byte *)puVar33);
                    uStack_318 = 1;
                  }
                  break;
                case 0x34:
                  if (auStack_310[0] == 0) {
                    uStack_318 = 2;
                    uStack_358 = (ulonglong)uStack_358._2_6_ << 0x10;
                  }
                  else if (auStack_310[0] == 1) {
                    uStack_358 = CONCAT62(uStack_358._2_6_,(*(byte *)puVar33 >> 7) - 1);
                    uStack_318 = 2;
                    uStack_358 = CONCAT71(uStack_358._1_7_,*(byte *)puVar33) ^ 0x80;
                  }
                  else {
                    if (auStack_310[0] == 2) {
                      uStack_358 = CONCAT71(CONCAT61(uStack_358._2_6_,*(byte *)puVar33),
                                            *(byte *)((longlong)puVar33 + 1)) ^ 0x8000;
                    }
                    uStack_318 = 2;
                  }
                  break;
                case 0x38:
                case 0x7a:
                  if (auStack_310[0] == 0) {
                    uStack_318 = 4;
                    uStack_358 = (ulonglong)uVar34 << 0x20;
                  }
                  else if (auStack_310[0] == 1) {
                    uStack_358 = CONCAT44(uVar34,(*(byte *)puVar33 >> 7) - 1);
                    uStack_318 = 4;
                    uStack_358 = CONCAT71(uStack_358._1_7_,*(byte *)puVar33) ^ 0x80;
                  }
                  else if (auStack_310[0] == 2) {
                    uStack_358 = CONCAT44(uVar34,(*(byte *)puVar33 >> 7) - 1);
                    uStack_358 = CONCAT71(CONCAT61(uStack_358._2_6_,*(byte *)puVar33),
                                          *(byte *)((longlong)puVar33 + 1)) ^ 0x8000;
                    uStack_318 = 4;
                  }
                  else if (auStack_310[0] == 3) {
                    uStack_358 = CONCAT44(uVar34,(*(byte *)puVar33 >> 7) - 1);
                    uStack_358 = CONCAT71(CONCAT61(CONCAT51(uStack_358._3_5_,*(byte *)puVar33),
                                                   *(byte *)((longlong)puVar33 + 1)),
                                          *(byte *)((longlong)puVar33 + 2)) ^ 0x800000;
                    uStack_318 = 4;
                  }
                  else {
                    if (auStack_310[0] != 4) goto code_r0x00105e1b;
                    uVar36 = *(uint *)puVar33;
                    uStack_358._0_3_ =
                         (uint3)(byte)(uVar36 >> 0x18) | (uint3)(uVar36 >> 8) & 0xff00 |
                         (uint3)((uVar36 & 0xff00) << 8);
                    uStack_318 = 4;
                    uStack_358 = CONCAT44(uVar34,CONCAT13((char)uVar36,(uint3)uStack_358)) ^
                                 0x80000000;
                  }
                  break;
                case 0x3a:
                  if (auStack_310[0] == 4) {
                    uStack_358 = CONCAT44(uVar34,*(uint *)puVar33);
                    uStack_318 = 4;
                  }
                  else {
                    uStack_358 = (ulonglong)uStack_358._2_6_ << 0x10;
code_r0x00105d14:
                    uStack_358 = (ulonglong)CONCAT42(uStack_358._4_4_,*(ushort *)puVar33) << 0x10;
                    uStack_318 = 4;
                  }
                  break;
                case 0x3b:
                  uStack_358 = (ulonglong)uVar34 << 0x20;
                  if (auStack_310[0] == 1) {
                    uStack_358 = (ulonglong)CONCAT41(uVar34,*(byte *)puVar33) << 0x18;
code_r0x00105e1b:
                    uStack_318 = 4;
                  }
                  else {
                    if (auStack_310[0] == 2) goto code_r0x00105d14;
                    if (auStack_310[0] == 3) {
                      uStack_358 = (ulonglong)CONCAT43(uVar34,*(undefined3 *)puVar33) << 8;
                      uStack_318 = 4;
                    }
                    else {
                      if (auStack_310[0] != 4) goto code_r0x00105e1b;
                      uStack_358 = CONCAT44(uVar34,*(uint *)puVar33);
                      uStack_318 = 4;
                    }
                  }
                  break;
                case 0x3c:
                case 0x3d:
                case 0x7f:
                  switch(auStack_310[0]) {
                  case 0:
                    uStack_318 = 8;
                    uStack_358 = 0;
                    break;
                  case 1:
                    uStack_318 = 8;
                    uStack_358._1_7_ = (uint7)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 8);
                    uStack_358 = CONCAT71(uStack_358._1_7_,*(byte *)puVar33) ^ 0x80;
                    break;
                  case 2:
                    uStack_358._2_6_ = (uint6)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x10);
                    uStack_358 = CONCAT71(CONCAT61(uStack_358._2_6_,*(byte *)puVar33),
                                          *(byte *)((longlong)puVar33 + 1)) ^ 0x8000;
                    uStack_318 = 8;
                    break;
                  case 3:
                    uStack_358._3_5_ = (undefined5)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x18);
                    uStack_358 = CONCAT71(CONCAT61(CONCAT51(uStack_358._3_5_,*(byte *)puVar33),
                                                   *(byte *)((longlong)puVar33 + 1)),
                                          *(byte *)((longlong)puVar33 + 2)) ^ 0x800000;
                    uStack_318 = 8;
                    break;
                  case 4:
                    uVar34 = *(uint *)puVar33;
                    uStack_358._0_3_ =
                         (uint3)(byte)(uVar34 >> 0x18) | (uint3)(uVar34 >> 8) & 0xff00 |
                         (uint3)((uVar34 & 0xff00) << 8);
                    uStack_358._4_4_ = (uint)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x20);
                    uStack_318 = 8;
                    uStack_358 = CONCAT44(uStack_358._4_4_,
                                          CONCAT13(*(byte *)puVar33,(uint3)uStack_358)) ^ 0x80000000
                    ;
                    break;
                  case 5:
                    uStack_358._5_3_ = (undefined3)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x28);
                    uVar34 = *(uint *)((longlong)puVar33 + 1);
                    uStack_358 = CONCAT44(CONCAT31(uStack_358._5_3_,*(byte *)puVar33),
                                          uVar34 >> 0x18 | (uVar34 & 0xff0000) >> 8 |
                                          (uVar34 & 0xff00) << 8 | uVar34 << 0x18) ^ 0x8000000000;
                    uStack_318 = 8;
                    break;
                  case 6:
                    uStack_358._6_2_ = (undefined2)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x30);
                    uVar34 = *(uint *)((longlong)puVar33 + 2);
                    uStack_358 = CONCAT44(CONCAT31(CONCAT21(uStack_358._6_2_,*(byte *)puVar33),
                                                   *(byte *)((longlong)puVar33 + 1)),
                                          uVar34 >> 0x18 | (uVar34 & 0xff0000) >> 8 |
                                          (uVar34 & 0xff00) << 8 | uVar34 << 0x18) ^ 0x800000000000;
                    uStack_318 = 8;
                    break;
                  case 7:
                    uStack_358._7_1_ = (undefined)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x38);
                    uVar34 = *(uint *)((longlong)puVar33 + 3);
                    uStack_358 = CONCAT44(CONCAT31(CONCAT21(CONCAT11(uStack_358._7_1_,
                                                                     *(byte *)puVar33),
                                                            *(byte *)((longlong)puVar33 + 1)),
                                                   *(byte *)((longlong)puVar33 + 2)),
                                          uVar34 >> 0x18 | (uVar34 & 0xff0000) >> 8 |
                                          (uVar34 & 0xff00) << 8 | uVar34 << 0x18) ^
                                 0x80000000000000;
                    uStack_318 = 8;
                    break;
                  case 8:
                    uVar24 = *puVar33;
                    uVar4 = (uint7)(uVar24 >> 8);
                    uStack_358._0_7_ =
                         (uint7)(byte)(uVar24 >> 0x38) | (uVar4 & 0xff0000000000) >> 0x20 |
                         (uVar4 & 0xff00000000) >> 0x10 | uVar4 & 0xff000000 |
                         (uint7)((uVar24 & 0xff000000) << 8) | (uint7)((uVar24 & 0xff0000) << 0x18)
                         | (uint7)((uVar24 & 0xff00) << 0x28);
                    uStack_358 = CONCAT17((char)uVar24,(uint7)uStack_358) ^ 0x8000000000000000;
                  default:
                    uStack_318 = 8;
                  }
                  break;
                case 0x3e:
                  uStack_358 = 0;
                  switch(auStack_310[0]) {
                  case 1:
                    uStack_358 = (ulonglong)*(byte *)puVar33 << 0x38;
                    uStack_318 = 8;
                    break;
                  case 2:
                    uStack_358 = (ulonglong)*(ushort *)puVar33 << 0x30;
                    uStack_318 = 8;
                    break;
                  case 3:
                    uStack_358 = (ulonglong)*(uint3 *)puVar33 << 0x28;
                    uStack_318 = 8;
                    break;
                  case 4:
                    uStack_358 = (ulonglong)*(uint *)puVar33 << 0x20;
                    uStack_318 = 8;
                    break;
                  case 5:
                    uStack_358 = (ulonglong)*(uint5 *)puVar33 << 0x18;
                    uStack_318 = 8;
                    break;
                  case 6:
                    uStack_358 = (ulonglong)*(uint6 *)puVar33 << 0x10;
                    uStack_318 = 8;
                    break;
                  case 7:
                    uStack_358 = (ulonglong)*(uint7 *)puVar33 << 8;
                    uStack_318 = 8;
                    break;
                  case 8:
                    uStack_358 = *puVar33;
                  default:
                    uStack_318 = 8;
                  }
                  break;
                case 0x6a:
                case 0x6c:
                  *(uint **)((longlong)apuStack_370 + lVar23) = &uStack_318;
                  *(undefined8 **)((longlong)&uStack_378 + lVar23) = &uStack_358;
                  *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105f23;
                  cVar5 = (*pcRam00000000013fcef0)(puVar33,uVar36,bVar6 & 0x3f);
                  if (cVar5 == '\0') {
                    *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105f41;
                    (*_DAT_)(6,0x54,0x16);
                  }
                  break;
                case 0xad:
                case 0xaf:
                  *(undefined *)((longlong)&uStack_378 + lVar23) =
                       *(undefined *)((longlong)puVar35 + 0x3e);
                  uVar34 = auStack_310[0];
                  *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105d42;
                  func_0x(puVar33,uVar34,&uStack_358);
                  break;
                case 0xbd:
                  *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105d96;
                  func_0x(puVar33,uVar36,&uStack_358);
                  uStack_318 = 8;
                  break;
                case 0xe7:
                  *(uint *)((longlong)&uStack_378 + lVar23) = uStack_318;
                  *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105f64;
                  uStack_318 = (*pcRam00000000013fcee8)(auStack_80,puVar33,uVar36);
                  break;
                case 0xef:
                  *(uint *)((longlong)&uStack_378 + lVar23) = uStack_318;
                  *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105d86;
                  (*pcRam00000000013fcef8)(auStack_b8,puVar33,uVar36);
                }
              }
              else if (iVar30 == 0) {
                uVar9 = *(ushort *)(puVar35 + 0xf);
                if ((*(byte *)((longlong)piVar17 + 6) & 0x10) != 0) {
                  *(int **)((longlong)&uStack_378 + lVar23) = &iStack_27c;
                  *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105fa2;
                  func_0x(psVar11 + 1,piVar17,0);
                  if (iStack_27c == 0) {
                    puVar32 = *(uint **)(piVar17 + 2);
                    uVar34 = *puVar32;
                    if ((uVar9 != 0) && (uVar34 != uVar9)) {
                      *(undefined8 *)((longlong)&uStack_378 + lVar23) = 0;
                      *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x105fe1;
                      (*_DAT_)(1,0x192f258,0x192dc58);
                    }
                    uStack_358 = *(ulonglong *)(puVar32 + 1);
                    auStack_310[0] = uVar34;
                    goto code_r0x00105d4c;
                  }
                }
                uStack_358 = *(ulonglong *)((longlong)*piVar17 + *(longlong *)(psVar11 + 4));
                auStack_310[0] = (uint)uVar9;
              }
code_r0x00105d4c:
              if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) == 0) {
                lVar18 = plStack_330[3];
              }
              else {
                lVar18 = plStack_330[4];
              }
              lVar3 = *(longlong *)(puVar35 + 10);
              *(ulonglong *)(lVar3 + lVar18) = uStack_358;
              uVar34 = puVar35[0x10];
              if ((uVar34 >> 8 & 1) != 0) {
                if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) == 0) {
                  lVar12 = plStack_330[3];
                }
                else {
                  lVar12 = plStack_330[4];
                }
                *(ulonglong *)(lVar12 + *(longlong *)(*(longlong *)(puVar35 + 0x12) + 0x18)) =
                     (ulonglong)uStack_318;
                uVar34 = puVar35[0x10];
              }
              lVar12 = lStack_2c0;
              plVar10 = plStack_330;
              if ((uVar34 >> 10 & 1) == 0) {
                uVar22 = (ulonglong)uStack_340;
              }
              else {
                if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) == 0) {
                  lVar25 = plStack_330[3];
                }
                else {
                  lVar25 = plStack_330[4];
                }
                uVar22 = (ulonglong)uStack_340;
                uVar20 = 0;
                if ((ulonglong *)(lVar3 + lVar18) == (ulonglong *)0x0) {
                  uVar20 = 3;
                }
                *(undefined *)(lVar25 + *(longlong *)(puVar35 + 0xc)) = uVar20;
              }
              goto code_r0x00106101;
            }
            uStack_33c = uVar34;
            lVar12 = lStack_2f8;
            uVar34 = puVar35[0x10];
            if ((uVar34 >> 10 & 1) != 0) {
              if ((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0x2a) & 0x10) == 0) {
                lVar18 = plVar10[3];
              }
              else {
                lVar18 = plVar10[4];
              }
              uVar20 = 0;
              if (puVar15 == (uint *)0x0) {
                uVar20 = 3;
              }
              *(undefined *)(lVar18 + *(longlong *)(puVar35 + 0xc)) = uVar20;
              uVar34 = puVar35[0x10];
            }
            if ((uVar34 >> 9 & 1) != 0) {
              *(uint *)((longlong)&uStack_378 + lVar23) = uStack_33c;
              *(undefined8 *)(auStack_398 + lVar23 + -8) = 0x1060ea;
              func_0x(plVar10,lVar12,puVar35,puVar15);
            }
            uVar22 = (ulonglong)uStack_340;
            lVar12 = lStack_2c0;
code_r0x00106101:
            puVar32 = (uint *)0x0;
            lVar18 = lStack_300;
code_r0x00106107:
            puVar35 = puVar35 + 0x14;
            uStack_2cc = uStack_2cc + 1;
            puVar26 = auStack_398 + lVar23;
          } while (uStack_2cc < (uint)uStack_308);
        }
      }
    }
    else {
      if (*psVar11 == -1) {
        *psVar11 = 1;
      }
      puVar28 = (ushort *)(psVar11 + 1);
      puVar26 = auStack_398;
      if ((*(byte *)((longlong)param_3 + 0x14) & 0x10) != 0) {
        uVar34 = *(uint *)(param_3 + 2);
        lVar12 = param_3[1];
        puVar26 = auStack_398;
        puVar15 = puVar32;
        if (uVar34 != 0) {
          do {
            switch(*(undefined *)(lVar12 + 0x40)) {
            case 0:
              goto code_r0x00103cae;
            case 1:
              uVar9 = *(ushort *)(lVar12 + 4);
              if (*puVar28 < uVar9) {
                uVar9 = ~(*(ushort *)(lVar12 + 6) >> 4) & 1;
              }
              else {
                bVar6 = *(byte *)((longlong)((int)(uVar9 - 1) / 2) +
                                  (ulonglong)(ushort)uStack_308[0xc] + *(longlong *)(uStack_308 + 4)
                                 );
                bVar19 = bVar6 >> 4;
                if ((uVar9 & 1) != 0) {
                  bVar19 = bVar6 & 0xf;
                }
                uVar9 = (ushort)(bVar19 == 0);
              }
              if (uVar9 == 0) goto code_r0x00103420;
            case 0xd:
            case 0x1b:
              puVar15 = (uint *)0x0;
              uStack_314 = 0;
              break;
            case 2:
code_r0x00103420:
              puVar15 = (uint *)0x0;
              break;
            case 3:
              uVar9 = *(ushort *)(lVar12 + 4);
              if (*puVar28 < uVar9) {
                uVar9 = ~(*(ushort *)(lVar12 + 6) >> 4) & 1;
              }
              else {
                bVar6 = *(byte *)((longlong)((int)(uVar9 - 1) / 2) +
                                  (ulonglong)(ushort)uStack_308[0xc] + *(longlong *)(uStack_308 + 4)
                                 );
                bVar19 = bVar6 >> 4;
                if ((uVar9 & 1) != 0) {
                  bVar19 = bVar6 & 0xf;
                }
                uVar9 = (ushort)(bVar19 == 0);
              }
              puVar15 = (uint *)0x0;
              if (uVar9 == 0) goto code_r0x0010348d;
              uStack_314 = 0;
              break;
            case 4:
code_r0x0010348d:
              uStack_2a4 = 0;
              uStack_378 = (undefined8 *)&uStack_2a4;
              uStack_3a0 = 0x1034b4;
              puVar15 = (uint *)func_0x(puVar28,lVar12,1,&uStack_314);
              if (puVar15 == (uint *)0x0) {
                puVar15 = *(uint **)(uStack_308 + 4);
              }
              if ((uStack_314 == 0) && ((*(uint *)(lVar12 + 0x40) & 0x2000) != 0)) {
                uStack_314 = 4;
                puVar15 = (uint *)0x152788c;
              }
              if (((**(byte **)(uStack_308 + 4) & 0x1c) - 0x18 & 0xfffffffb) == 0) {
                uStack_3a0 = 0x1034fe;
                iVar30 = func_0x(lVar12);
                if (iVar30 != 0) break;
              }
              if (*(ushort *)(lVar12 + 0x3c) < uStack_314) {
                uStack_3a0 = 0x103521;
                (*_DAT_)(6,0x52,0x16,0x91);
              }
              break;
            case 5:
              puVar15 = *(uint **)(uStack_308 + 4);
              uStack_3a0 = 0x103598;
              uStack_314 = func_0x(puVar28);
              break;
            case 6:
            case 7:
            case 9:
            case 10:
            case 0xb:
            case 0xe:
            case 0xf:
            case 0x19:
              uStack_3a0 = 0x1035ac;
              func_0x(lStack_300,lVar12,plStack_330);
              goto code_r0x00103cae;
            case 8:
              uStack_378 = (undefined8 *)&uStack_2a0;
              uStack_2a0 = 0;
              uStack_3a0 = 0x103583;
              puVar15 = (uint *)func_0x(puVar28,lVar12,
                                                (*(uint *)(lVar12 + 0x40) & 0x80000) >> 0x13,
                                                &uStack_314);
              break;
            case 0x10:
              uStack_3a0 = 0x1035c6;
              uVar13 = func_0x(**(undefined8 **)(*(longlong *)(lStack_2f8 + 8) + 0x160),0);
              uStack_324 = 0;
              uStack_31c = 8;
              iVar30 = *(int *)(*(longlong *)(lStack_2f8 + 8) + 0x100);
              if (iVar30 == 2) {
                uStack_378 = (undefined8 *)&uStack_29c;
                uStack_29c = 0;
                uStack_3a0 = 0x103611;
                puVar33 = (ulonglong *)func_0x(puVar28,uVar13,1,&uStack_324);
                if (puVar33 == (ulonglong *)0x0) {
                  puVar33 = *(ulonglong **)(uStack_308 + 4);
                }
                uVar36 = uStack_348._4_4_;
                switch(*(undefined *)(lVar12 + 0x3e)) {
                case 0x30:
                  if (uStack_324 == 0) {
                    uStack_348 = (ulonglong)uStack_348._1_7_ << 8;
                    uStack_31c = 1;
                  }
                  else {
                    uStack_348 = CONCAT71(uStack_348._1_7_,*(byte *)puVar33);
                    uStack_31c = 1;
                  }
                  break;
                case 0x34:
                  if (uStack_324 == 0) {
                    uStack_31c = 2;
                    uStack_348 = (ulonglong)uStack_348._2_6_ << 0x10;
                  }
                  else if (uStack_324 == 1) {
                    uStack_348 = CONCAT62(uStack_348._2_6_,(*(byte *)puVar33 >> 7) - 1);
                    uStack_31c = 2;
                    uStack_348 = CONCAT71(uStack_348._1_7_,*(byte *)puVar33) ^ 0x80;
                  }
                  else {
                    if (uStack_324 == 2) {
                      uStack_348 = CONCAT71(CONCAT61(uStack_348._2_6_,*(byte *)puVar33),
                                            *(byte *)((longlong)puVar33 + 1)) ^ 0x8000;
                    }
                    uStack_31c = 2;
                  }
                  break;
                case 0x38:
                case 0x7a:
                  if (uStack_324 == 0) {
                    uStack_31c = 4;
                    uStack_348 = (ulonglong)uVar36 << 0x20;
                  }
                  else if (uStack_324 == 1) {
                    uStack_348 = CONCAT44(uVar36,(*(byte *)puVar33 >> 7) - 1);
                    uStack_31c = 4;
                    uStack_348 = CONCAT71(uStack_348._1_7_,*(byte *)puVar33) ^ 0x80;
                  }
                  else if (uStack_324 == 2) {
                    uStack_348 = CONCAT44(uVar36,(*(byte *)puVar33 >> 7) - 1);
                    uStack_348 = CONCAT71(CONCAT61(uStack_348._2_6_,*(byte *)puVar33),
                                          *(byte *)((longlong)puVar33 + 1)) ^ 0x8000;
                    uStack_31c = 4;
                  }
                  else if (uStack_324 == 3) {
                    uStack_348 = CONCAT44(uVar36,(*(byte *)puVar33 >> 7) - 1);
                    uStack_348 = CONCAT71(CONCAT61(CONCAT51(uStack_348._3_5_,*(byte *)puVar33),
                                                   *(byte *)((longlong)puVar33 + 1)),
                                          *(byte *)((longlong)puVar33 + 2)) ^ 0x800000;
                    uStack_31c = 4;
                  }
                  else {
                    if (uStack_324 != 4) goto code_r0x00103a75;
                    uVar31 = *(uint *)puVar33;
                    uStack_348._0_3_ =
                         (uint3)(byte)(uVar31 >> 0x18) | (uint3)(uVar31 >> 8) & 0xff00 |
                         (uint3)((uVar31 & 0xff00) << 8);
                    uStack_31c = 4;
                    uStack_348 = CONCAT44(uVar36,CONCAT13((char)uVar31,(uint3)uStack_348)) ^
                                 0x80000000;
                  }
                  break;
                case 0x3a:
                  if (uStack_324 == 4) {
                    uStack_348 = CONCAT44(uVar36,*(uint *)puVar33);
                    uStack_31c = 4;
                  }
                  else {
                    uStack_348 = (ulonglong)uStack_348._2_6_ << 0x10;
code_r0x00103972:
                    uStack_348 = (ulonglong)CONCAT42(uStack_348._4_4_,*(ushort *)puVar33) << 0x10;
                    uStack_31c = 4;
                  }
                  break;
                case 0x3b:
                  uStack_348 = (ulonglong)uVar36 << 0x20;
                  if (uStack_324 == 1) {
                    uStack_348 = (ulonglong)CONCAT41(uVar36,*(byte *)puVar33) << 0x18;
code_r0x00103a75:
                    uStack_31c = 4;
                  }
                  else {
                    if (uStack_324 == 2) goto code_r0x00103972;
                    if (uStack_324 == 3) {
                      uStack_348 = (ulonglong)CONCAT43(uVar36,*(undefined3 *)puVar33) << 8;
                      uStack_31c = 4;
                    }
                    else {
                      if (uStack_324 != 4) goto code_r0x00103a75;
                      uStack_348 = CONCAT44(uVar36,*(uint *)puVar33);
                      uStack_31c = 4;
                    }
                  }
                  break;
                case 0x3c:
                case 0x3d:
                case 0x7f:
                  switch(uStack_324) {
                  case 0:
                    uStack_31c = 8;
                    uStack_348 = 0;
                    break;
                  case 1:
                    uStack_31c = 8;
                    uStack_348._1_7_ = (uint7)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 8);
                    uStack_348 = CONCAT71(uStack_348._1_7_,*(byte *)puVar33) ^ 0x80;
                    break;
                  case 2:
                    uStack_348._2_6_ = (uint6)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x10);
                    uStack_348 = CONCAT71(CONCAT61(uStack_348._2_6_,*(byte *)puVar33),
                                          *(byte *)((longlong)puVar33 + 1)) ^ 0x8000;
                    uStack_31c = 8;
                    break;
                  case 3:
                    uStack_348._3_5_ = (undefined5)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x18);
                    uStack_348 = CONCAT71(CONCAT61(CONCAT51(uStack_348._3_5_,*(byte *)puVar33),
                                                   *(byte *)((longlong)puVar33 + 1)),
                                          *(byte *)((longlong)puVar33 + 2)) ^ 0x800000;
                    uStack_31c = 8;
                    break;
                  case 4:
                    uVar36 = *(uint *)puVar33;
                    uStack_348._0_3_ =
                         (uint3)(byte)(uVar36 >> 0x18) | (uint3)(uVar36 >> 8) & 0xff00 |
                         (uint3)((uVar36 & 0xff00) << 8);
                    uStack_348._4_4_ = (uint)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x20);
                    uStack_31c = 8;
                    uStack_348 = CONCAT44(uStack_348._4_4_,
                                          CONCAT13(*(byte *)puVar33,(uint3)uStack_348)) ^ 0x80000000
                    ;
                    break;
                  case 5:
                    uStack_348._5_3_ = (undefined3)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x28);
                    uVar36 = *(uint *)((longlong)puVar33 + 1);
                    uStack_348 = CONCAT44(CONCAT31(uStack_348._5_3_,*(byte *)puVar33),
                                          uVar36 >> 0x18 | (uVar36 & 0xff0000) >> 8 |
                                          (uVar36 & 0xff00) << 8 | uVar36 << 0x18) ^ 0x8000000000;
                    uStack_31c = 8;
                    break;
                  case 6:
                    uStack_348._6_2_ = (undefined2)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x30);
                    uVar36 = *(uint *)((longlong)puVar33 + 2);
                    uStack_348 = CONCAT44(CONCAT31(CONCAT21(uStack_348._6_2_,*(byte *)puVar33),
                                                   *(byte *)((longlong)puVar33 + 1)),
                                          uVar36 >> 0x18 | (uVar36 & 0xff0000) >> 8 |
                                          (uVar36 & 0xff00) << 8 | uVar36 << 0x18) ^ 0x800000000000;
                    uStack_31c = 8;
                    break;
                  case 7:
                    uStack_348._7_1_ = (undefined)((ulonglong)(*(byte *)puVar33 >> 7) - 1 >> 0x38);
                    uVar36 = *(uint *)((longlong)puVar33 + 3);
                    uStack_348 = CONCAT44(CONCAT31(CONCAT21(CONCAT11(uStack_348._7_1_,
                                                                     *(byte *)puVar33),
                                                            *(byte *)((longlong)puVar33 + 1)),
                                                   *(byte *)((longlong)puVar33 + 2)),
                                          uVar36 >> 0x18 | (uVar36 & 0xff0000) >> 8 |
                                          (uVar36 & 0xff00) << 8 | uVar36 << 0x18) ^
                                 0x80000000000000;
                    uStack_31c = 8;
                    break;
                  case 8:
                    uVar24 = *puVar33;
                    uVar4 = (uint7)(uVar24 >> 8);
                    uStack_348._0_7_ =
                         (uint7)(byte)(uVar24 >> 0x38) | (uVar4 & 0xff0000000000) >> 0x20 |
                         (uVar4 & 0xff00000000) >> 0x10 | uVar4 & 0xff000000 |
                         (uint7)((uVar24 & 0xff000000) << 8) | (uint7)((uVar24 & 0xff0000) << 0x18)
                         | (uint7)((uVar24 & 0xff00) << 0x28);
                    uStack_31c = 8;
                    uStack_348 = CONCAT17((char)uVar24,(uint7)uStack_348) ^ 0x8000000000000000;
                    break;
                  default:
                    goto code_r0x00103b6e;
                  }
                  break;
                case 0x3e:
                  uStack_348 = 0;
                  switch(uStack_324) {
                  case 1:
                    uStack_348 = (ulonglong)*(byte *)puVar33 << 0x38;
                    uStack_31c = 8;
                    break;
                  case 2:
                    uStack_348 = (ulonglong)*(ushort *)puVar33 << 0x30;
                    uStack_31c = 8;
                    break;
                  case 3:
                    uStack_348 = (ulonglong)*(uint3 *)puVar33 << 0x28;
                    uStack_31c = 8;
                    break;
                  case 4:
                    uStack_348 = (ulonglong)*(uint *)puVar33 << 0x20;
                    uStack_31c = 8;
                    break;
                  case 5:
                    uStack_348 = (ulonglong)*(uint5 *)puVar33 << 0x18;
                    uStack_31c = 8;
                    break;
                  case 6:
                    uStack_348 = (ulonglong)*(uint6 *)puVar33 << 0x10;
                    uStack_31c = 8;
                    break;
                  case 7:
                    uStack_348 = (ulonglong)*(uint7 *)puVar33 << 8;
                    uStack_31c = 8;
                    break;
                  case 8:
                    uStack_348 = *puVar33;
                  default:
code_r0x00103b6e:
                    uStack_31c = 8;
                  }
                  break;
                case 0x6a:
                case 0x6c:
                  apuStack_370[0] = &uStack_31c;
                  uStack_378 = &uStack_348;
                  uStack_3a0 = 0x103b9b;
                  cVar5 = (*pcRam00000000013fcef0)
                                    (puVar33,uStack_324,*(byte *)(lVar12 + 0x44) & 0x3f);
                  if (cVar5 == '\0') {
                    uStack_3a0 = 0x103bb9;
                    (*_DAT_)(6,0x54,0x16,1);
                  }
                  break;
                case 0xad:
                case 0xaf:
                  uStack_378 = (undefined8 *)
                               CONCAT71(uStack_378._1_7_,*(undefined *)(lVar12 + 0x3e));
                  uStack_3a0 = 0x1039a0;
                  func_0x(puVar33,uStack_324,&uStack_348,uStack_31c);
                  break;
                case 0xbd:
                  uStack_3a0 = 0x1039ee;
                  func_0x
                            (puVar33,uStack_324,&uStack_348,*(byte *)(lVar12 + 0x45) & 0x3f);
                  uStack_31c = 8;
                  break;
                case 0xe7:
                  uStack_378 = (undefined8 *)CONCAT44(uStack_378._4_4_,uStack_31c);
                  uStack_3a0 = 0x103bdd;
                  uStack_31c = (*pcRam00000000013fcee8)(auStack_f0,puVar33,uStack_324,&uStack_348);
                  break;
                case 0xef:
                  uStack_378 = (undefined8 *)CONCAT44(uStack_378._4_4_,uStack_31c);
                  uStack_3a0 = 0x1039dd;
                  (*pcRam00000000013fcef8)(auStack_128,puVar33,uStack_324,&uStack_348);
                }
              }
              else if (iVar30 == 0) {
                uStack_348 = uRam0000000000000000;
              }
              if ((*(byte *)(*(longlong *)(lVar12 + 0x48) + 0x2a) & 0x10) == 0) {
                lVar23 = plStack_330[3];
              }
              else {
                lVar23 = plStack_330[4];
              }
              puVar33 = (ulonglong *)(*(longlong *)(lVar12 + 0x28) + lVar23);
              *puVar33 = uStack_348;
              uVar36 = *(uint *)(lVar12 + 0x40);
              if ((uVar36 >> 8 & 1) != 0) {
                if ((*(byte *)(*(longlong *)(lVar12 + 0x48) + 0x2a) & 0x10) == 0) {
                  lVar23 = plStack_330[3];
                }
                else {
                  lVar23 = plStack_330[4];
                }
                *(ulonglong *)(lVar23 + *(longlong *)(*(longlong *)(lVar12 + 0x48) + 0x18)) =
                     (ulonglong)uStack_31c;
                uVar36 = *(uint *)(lVar12 + 0x40);
              }
              if ((uVar36 >> 10 & 1) != 0) {
                if ((*(byte *)(*(longlong *)(lVar12 + 0x48) + 0x2a) & 0x10) == 0) {
                  lVar23 = plStack_330[3];
                }
                else {
                  lVar23 = plStack_330[4];
                }
                uVar20 = 0;
                if (puVar33 == (ulonglong *)0x0) {
                  uVar20 = 3;
                }
                *(undefined *)(lVar23 + *(longlong *)(lVar12 + 0x30)) = uVar20;
              }
              goto code_r0x00103cae;
            }
            uVar36 = *(uint *)(lVar12 + 0x40);
            if ((uVar36 >> 10 & 1) != 0) {
              if ((*(byte *)(*(longlong *)(lVar12 + 0x48) + 0x2a) & 0x10) == 0) {
                lVar23 = plStack_330[3];
              }
              else {
                lVar23 = plStack_330[4];
              }
              uVar20 = 0;
              if (puVar15 == (uint *)0x0) {
                uVar20 = 3;
              }
              *(undefined *)(lVar23 + *(longlong *)(lVar12 + 0x30)) = uVar20;
              uVar36 = *(uint *)(lVar12 + 0x40);
            }
            if ((uVar36 >> 9 & 1) != 0) {
              uStack_378 = (undefined8 *)CONCAT44(uStack_378._4_4_,uStack_314);
              uStack_3a0 = 0x103ca6;
              func_0x(plStack_330,lStack_2f8,lVar12,puVar15);
            }
code_r0x00103cae:
            uVar36 = (int)puVar32 + 1;
            puVar32 = (uint *)(ulonglong)uVar36;
            lVar12 = lVar12 + 0x50;
            puVar26 = auStack_398;
          } while (uVar36 < uVar34);
        }
      }
    }
    plVar10 = plStack_2c8;
    if (plStack_2c8 != (longlong *)0x0) {
      pcVar1 = *(code **)(**(longlong **)(lStack_300 + 0x10) + 8);
      *(undefined8 *)(puVar26 + -8) = 0x106140;
      (*pcVar1)();
      pcVar1 = *(code **)(*plVar10 + 8);
      *(undefined8 *)(puVar26 + -8) = 0x106149;
      (*pcVar1)(plVar10);
      goto LAB_;
    }
  }
  else {
    puVar32 = (uint *)0x0;
    puVar28 = (ushort *)(psVar11 + 1);
    uVar34 = 0;
    if (*psVar11 == 0) {
      if ((**(byte **)(psVar11 + 4) & 0x10) != 0) {
        uVar34 = (uint)*(ushort *)(*(byte **)(psVar11 + 4) + *(uint *)(psVar11 + 8));
      }
    }
    else {
      uVar34 = (uint)*puVar28;
    }
    if (uVar34 < *(uint *)(lVar12 + 0x18)) goto LAB_;
    *psVar11 = 0;
    puVar15 = (uint *)param_3[1];
    uVar9 = *(ushort *)(*param_3 + 0x62);
    puVar26 = auStack_398;
    puVar35 = puVar32;
    psVar14 = psVar11;
    if (uVar9 != 0) {
      do {
        cVar5 = *(char *)(puVar15 + 0x10);
        if (cVar5 == '\x01') {
          if ((*(byte *)((longlong)puVar15 + 6) & 0x10) == 0) {
            uVar34 = *(byte *)((ulonglong)(*(ushort *)(puVar15 + 1) - 1 >> 3) +
                               (ulonglong)*(uint *)(psVar11 + 8) + 2 + *(longlong *)(psVar11 + 4))
                     >> ((byte)(*(ushort *)(puVar15 + 1) - 1) & 7) & 1;
          }
          else {
            uStack_378 = &uStack_1f8;
            uStack_3a0 = 0x10100f;
            func_0x(puVar28,puVar15,1,&uStack_270);
            uVar34 = uStack_270;
          }
          if (uVar34 == 0) goto LAB_;
LAB_:
          if ((*(byte *)(*(longlong *)(puVar15 + 0x12) + 0x2a) & 0x10) == 0) {
            *(undefined *)(param_3[3] + *(longlong *)(puVar15 + 0xc)) = 3;
          }
          else {
            *(undefined *)(param_3[4] + *(longlong *)(puVar15 + 0xc)) = 3;
          }
        }
        else {
          if (cVar5 == '\x02') {
LAB_:
            uVar8 = *(ushort *)(puVar15 + 0xf);
            if ((*(byte *)((longlong)puVar15 + 6) & 0x10) == 0) {
LAB_:
              puVar32 = (uint *)((longlong)(int)*puVar15 + *(longlong *)(psVar11 + 4));
              uVar34 = (uint)uVar8;
            }
            else {
              uStack_378 = (undefined8 *)&iStack_278;
              uStack_3a0 = 0x1010a0;
              func_0x(puVar28,puVar15,0,(longlong)&uStack_1f8 + 4);
              if (iStack_278 != 0) goto LAB_;
              uVar34 = **(uint **)(puVar15 + 2);
              puVar32 = *(uint **)(puVar15 + 2) + 1;
              if ((uVar8 != 0) && (uVar34 != uVar8)) {
                uStack_378 = (undefined8 *)0x0;
                uStack_3a0 = 0x1010e1;
                (*_DAT_)(1,0x192f258,0x192dc58,0x381);
              }
            }
            uStack_328 = uVar34;
            param_3 = plStack_330;
            if ((*(byte *)(*(longlong *)(puVar15 + 0x12) + 0x2a) & 0x10) == 0) {
LAB_:
              lVar12 = param_3[3];
            }
            else {
              lVar12 = plStack_330[4];
            }
LAB_:
            *(undefined *)(lVar12 + *(longlong *)(puVar15 + 0xc)) = 0;
          }
          else {
            if (cVar5 == '\x03') {
              if ((*(byte *)((longlong)puVar15 + 6) & 0x10) == 0) {
                uVar34 = *(byte *)((ulonglong)(*(ushort *)(puVar15 + 1) - 1 >> 3) +
                                   (ulonglong)*(uint *)(psVar11 + 8) + 2 +
                                  *(longlong *)(psVar11 + 4)) >>
                         ((byte)(*(ushort *)(puVar15 + 1) - 1) & 7) & 1;
              }
              else {
                uStack_378 = &uStack_200;
                uStack_3a0 = 0x100981;
                func_0x(puVar28,puVar15,1,&uStack_264);
                uVar34 = uStack_264;
              }
              if (uVar34 != 0) goto LAB_;
            }
            else if (cVar5 != '\x04') {
              if (cVar5 == '\b') {
                uVar8 = *(ushort *)(puVar15 + 0xf);
                iVar30 = puVar15[0x10] << 0xc;
                if ((*puVar15 & 0xc0000000) == 0x80000000) {
                  uStack_3a0 = 0x1008e3;
                  iVar30 = func_0x(puVar28);
                  if (iVar30 != 0) {
                    uStack_3a0 = 0x1008fe;
                    puVar32 = (uint *)func_0x(psVar11 + 0x15,puVar15,&uStack_328,auStack_204
                                                     );
                    uVar34 = uStack_328;
                    goto LAB_;
                  }
                  uStack_328 = 0;
                  puVar32 = (uint *)0x0;
                  uVar8 = *(ushort *)(*(longlong *)(puVar15 + 0x12) + 0x2a);
LAB_:
                  psVar14 = uStack_308;
                  if ((uVar8 & 0x10) == 0) {
                    *(undefined *)(param_3[3] + *(longlong *)(puVar15 + 0xc)) = 3;
                  }
                  else {
                    *(undefined *)(param_3[4] + *(longlong *)(puVar15 + 0xc)) = 3;
                  }
                  goto LAB_;
                }
                if ((iVar30 < 0) || ((*(byte *)((longlong)puVar15 + 6) & 0x10) != 0)) {
                  uStack_378 = (undefined8 *)&iStack_2ec;
                  uStack_3a0 = 0x100215;
                  func_0x(puVar28,puVar15,iVar30 < 0,&iStack_2f0);
                  if ((iVar30 < 0) && (iStack_2f0 != 0)) {
                    uStack_328 = 0;
                    puVar32 = (uint *)0x0;
                    param_3 = plStack_330;
                    uVar34 = uStack_328;
                    goto LAB_;
                  }
                }
                else {
                  iStack_2f0 = 0;
                  iStack_2ec = 1;
                }
                if ((iStack_2ec == 0) && ((*(byte *)((longlong)puVar15 + 6) & 0x10) != 0)) {
                  puVar32 = *(uint **)(puVar15 + 2) + 1;
                  param_3 = plStack_330;
                  uVar34 = **(uint **)(puVar15 + 2);
                }
                else if ((int)*puVar15 < 0) {
                  if (*(int *)(psVar11 + 2) == 0) {
                    pbVar21 = *(byte **)(psVar11 + 4);
                    uVar34 = *(uint *)(psVar11 + 8);
                    uVar24 = (ulonglong)uVar34;
                    *puVar28 = 0;
                    *(uint *)(psVar11 + 10) = uVar34;
                    bVar6 = *pbVar21;
                    if ((bVar6 & 0x10) != 0) {
                      uVar34 = uVar34 + 2 + (*(ushort *)(pbVar21 + uVar24) + 7 >> 3);
                      uVar24 = (ulonglong)uVar34;
                      *(uint *)(psVar11 + 10) = uVar34;
                      bVar6 = *pbVar21;
                    }
                    if ((bVar6 & 0x20) == 0) {
                      *(int *)(psVar11 + 2) = (int)uVar24;
                      psVar11[0xe] = 0;
                      *(int *)(psVar11 + 0xc) = (int)uVar24;
                    }
                    else {
                      puVar27 = (ushort *)(pbVar21 + uVar24);
                      uVar8 = *puVar27;
                      psVar11[0xe] = uVar8;
                      if (uVar8 == 0) {
                        uStack_3a0 = 0x10037d;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 != '\0') {
                          uStack_3a0 = 0x100386;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            uStack_3a0 = 0x1003a0;
                            cVar5 = func_0x(0x1e90760);
                            if (cVar5 == '\0') {
                              uStack_3a0 = 0x1003bc;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              uStack_378 = (undefined8 *)0x0;
                              uStack_3a0 = 0x1003fa;
                              (*_DAT_)(1,0x17814e8,0x18a11b8,0x80f);
                            }
                          }
                        }
                        uStack_3a0 = 0x1003cd;
                        func_0x(*(undefined8 *)(psVar11 + 4),3);
                        uVar24 = (ulonglong)*(uint *)(psVar11 + 10);
                        uVar8 = psVar11[0xe];
                      }
                      uVar34 = (int)uVar24 + (uVar8 + 1) * 2;
                      *(uint *)(psVar11 + 0xc) = uVar34;
                      if (0x1f9e < uVar34) {
                        uStack_3a0 = 0x100428;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 != '\0') {
                          uStack_3a0 = 0x100431;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            uStack_3a0 = 0x10044b;
                            cVar5 = func_0x(0x1e90760);
                            if (cVar5 == '\0') {
                              uStack_3a0 = 0x100467;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              uStack_378 = (undefined8 *)0x0;
                              uStack_3a0 = 0x10048a;
                              (*_DAT_)(1,0x17814e8,0x18a11b8,0x816);
                            }
                          }
                        }
                        uStack_3a0 = 0x100498;
                        func_0x(*(undefined8 *)(psVar11 + 4),4);
                        uVar8 = psVar11[0xe];
                        uVar34 = *(uint *)(psVar11 + 0xc);
                      }
                      uVar24 = (ulonglong)uVar8;
                      uVar8 = puVar27[uVar24];
                      *(uint *)(psVar11 + 2) = uVar8 & 0x7fff;
                      if ((uVar8 & 0x7fff) < uVar34) {
                        uStack_3a0 = 0x1004c7;
                        cVar5 = func_0x(0x1e90760);
                        if (cVar5 != '\0') {
                          uStack_3a0 = 0x1004d0;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            uStack_3a0 = 0x1004ea;
                            cVar5 = func_0x(0x1e90760);
                            if (cVar5 == '\0') {
                              uStack_3a0 = 0x100506;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              uStack_378 = (undefined8 *)0x0;
                              uStack_3a0 = 0x100529;
                              (*_DAT_)(1,0x17814e8,0x18a11b8,0x81d);
                            }
                          }
                        }
                        uStack_3a0 = 0x100537;
                        func_0x(*(undefined8 *)(psVar11 + 4),4);
                        uVar24 = (ulonglong)(ushort)psVar11[0xe];
                      }
                      if ((short)puVar27[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                        pbVar21 = *(byte **)(psVar11 + 4);
                        do {
                          if ((int)uVar24 == 1) {
                            uVar34 = *(uint *)(psVar11 + 0xc);
                            uVar36 = uVar34;
LAB_:
                            if ((*(ushort *)
                                  (pbVar21 + uVar24 * 2 + (ulonglong)*(uint *)(psVar11 + 10)) &
                                0x7fff) < uVar34) goto LAB_;
                          }
                          else {
                            uVar36 = *(uint *)(psVar11 + 0xc);
                            uVar34 = *(ushort *)
                                      (pbVar21 +
                                      uVar24 * 2 + ((ulonglong)*(uint *)(psVar11 + 10) - 2)) &
                                     0x7fff;
                            if (uVar36 <= uVar34) goto LAB_;
LAB_:
                            uStack_3a0 = 0x1005a2;
                            func_0x(pbVar21,7);
                            uVar36 = *(uint *)(psVar11 + 0xc);
                          }
                          if ((uVar34 < uVar36) || (*(uint *)(psVar11 + 2) < uVar34))
                          goto LAB_;
                          pbVar21 = *(byte **)(psVar11 + 4);
                          if (*(ushort *)(pbVar21 + uVar34) == 5) {
                            *puVar28 = *puVar28 | 2;
                            psVar11[0xe] = psVar11[0xe] + -1;
                            uVar7 = psVar11[0x16] & 0xc7ff;
                            psVar11[0x15] = (short)uVar34;
                            lVar12 = (ulonglong)(uVar34 & 0xffff) + *(longlong *)(psVar11 + 4);
                            uVar8 = *(ushort *)(lVar12 + 2);
                            if ((uVar8 >> 0xe & 1) != 0) {
                              uVar7 = uVar8 & 0x3800 | uVar7;
                            }
                            psVar11[0x16] = uVar7;
                            psVar11[0x16] = (uVar7 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar7;
                            goto LAB_;
                          }
                          if (*(ushort *)(pbVar21 + uVar34) < 0x400) goto LAB_;
                          *puVar28 = *puVar28 | 1;
                          uVar8 = psVar11[0xe] - 1;
                          psVar11[0xe] = uVar8;
                          if (uVar8 == 0) goto LAB_;
                          uVar24 = (ulonglong)uVar8;
                        } while ((short)puVar27[(ulonglong)(uVar8 - 1) + 1] < 0);
                        uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                      }
                      else {
LAB_:
                        pbVar21 = *(byte **)(psVar11 + 4);
                        uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                      }
                    }
                    if ((*pbVar21 & 0x40) == 0) {
                      *(undefined4 *)(psVar11 + 0x13) = 0;
                    }
                    else {
                      *(int *)(psVar11 + 0x13) = (int)uVar24;
                      *(int *)(psVar11 + 2) = (int)uVar24 + 0xe;
                      uStack_3a0 = 0x100692;
                      uVar13 = func_0x(puVar28);
                      uStack_3a0 = 0x1006a1;
                      func_0x(uVar13,auStack_1e8);
                      uStack_3a0 = 0x1006ad;
                      iVar30 = func_0x(auStack_1e8);
                      *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar30;
                      uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                    }
                    iVar30 = (int)uVar24;
                    if ((*(ulonglong *)(psVar11 + 0xf) != 0) &&
                       (*(ulonglong *)(psVar11 + 0xf) < uVar24 + *(longlong *)(psVar11 + 4))) {
                      uStack_3a0 = 0x1006e3;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 != '\0') {
                        uStack_3a0 = 0x1006ec;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          uStack_3a0 = 0x100706;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 == '\0') {
                            uStack_3a0 = 0x100722;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            uStack_378 = (undefined8 *)0x0;
                            uStack_3a0 = 0x10075e;
                            (*_DAT_)(1,0x17814e8,0x18a11b8,0x877);
                          }
                        }
                      }
                      uStack_3a0 = 0x100733;
                      func_0x(*(undefined8 *)(psVar11 + 4),0x12);
                      iVar30 = *(int *)(psVar11 + 2);
                    }
                    if (0x3f3b < iVar30 - 1U) {
                      uStack_3a0 = 0x10077d;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 != '\0') {
                        uStack_3a0 = 0x100786;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          uStack_3a0 = 0x1007a0;
                          cVar5 = func_0x(0x1e90760);
                          if (cVar5 == '\0') {
                            uStack_3a0 = 0x1007bc;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                            uStack_3a0 = 0x1007ca;
                            func_0x(*(undefined8 *)(psVar11 + 4),5);
                            goto LAB_;
                          }
                          uStack_378 = (undefined8 *)0x0;
                          uStack_3a0 = 0x1007f0;
                          (*_DAT_)(1,0x17814e8,0x18a11b8,0x87c);
                        }
                      }
                      uStack_3a0 = 0x1007fe;
                      func_0x(*(undefined8 *)(psVar11 + 4),5);
                    }
                  }
LAB_:
                  sVar29 = -*(short *)puVar15;
                  if ((*(byte *)((longlong)puVar15 + 6) & 0x10) != 0) {
                    uStack_378 = (undefined8 *)&iStack_260;
                    uStack_3a0 = 0x100832;
                    func_0x(puVar28,puVar15,0,auStack_208);
                    if (iStack_260 == 0) {
                      puVar32 = *(uint **)(puVar15 + 2) + 1;
                      param_3 = plStack_330;
                      uVar34 = **(uint **)(puVar15 + 2);
                      goto LAB_;
                    }
                  }
                  lVar12 = (longlong)sVar29;
                  puVar32 = *(uint **)(psVar11 + 4);
                  if ((uint)(ushort)psVar11[0xe] < (uint)(int)sVar29) {
                    param_3 = plStack_330;
                    uVar34 = 0;
                  }
                  else {
                    uVar34 = *(uint *)(psVar11 + 10);
                    if (sVar29 == 1) {
                      uVar36 = *(uint *)(uStack_308 + 0xc);
                      uVar34 = *(ushort *)((longlong)puVar32 + lVar12 * 2 + (ulonglong)uVar34) &
                               0x7fff;
LAB_:
                      if (uVar34 < uVar36) goto LAB_;
                    }
                    else {
                      puVar27 = (ushort *)((longlong)puVar32 + lVar12 * 2 + (ulonglong)uVar34);
                      uVar36 = *(ushort *)((longlong)puVar32 + lVar12 * 2 + ((ulonglong)uVar34 - 2))
                               & 0x7fff;
                      puVar32 = *(uint **)(psVar11 + 4);
                      uVar34 = *puVar27 & 0x7fff;
                      if (*(uint *)(uStack_308 + 0xc) <= uVar36) goto LAB_;
LAB_:
                      uStack_3a0 = 0x1008b9;
                      func_0x(puVar32,7);
                      puVar32 = *(uint **)(psVar11 + 4);
                    }
                    puVar32 = (uint *)((ulonglong)uVar36 + (longlong)puVar32);
                    param_3 = plStack_330;
                    uVar34 = uVar34 - uVar36;
                  }
                }
                else if ((*(ushort *)((longlong)puVar15 + 6) & 8) == 0) {
                  if ((*(ushort *)((longlong)puVar15 + 6) & 0x10) != 0) {
                    uStack_378 = (undefined8 *)&iStack_25c;
                    uStack_3a0 = 0x100297;
                    func_0x(puVar28,puVar15,0,auStack_20c);
                    if (iStack_25c == 0) {
                      uVar34 = **(uint **)(puVar15 + 2);
                      puVar32 = *(uint **)(puVar15 + 2) + 1;
                      param_3 = plStack_330;
                      if ((uVar8 != 0) && (uVar34 != uVar8)) {
                        uStack_378 = (undefined8 *)0x0;
                        uStack_3a0 = 0x1002e2;
                        (*_DAT_)(1,0x192f258,0x192dc58,0x381);
                        param_3 = plStack_330;
                      }
                      goto LAB_;
                    }
                  }
                  puVar32 = (uint *)((longlong)(int)*puVar15 + *(longlong *)(psVar11 + 4));
                  param_3 = plStack_330;
                  uVar34 = (uint)uVar8;
                }
                else {
                  uStack_3a0 = 0x100311;
                  puVar32 = (uint *)func_0x(puVar28,puVar15);
                  param_3 = plStack_330;
                  uVar34 = uStack_328;
                }
LAB_:
                uStack_328 = uVar34;
                uVar8 = *(ushort *)(*(longlong *)(puVar15 + 0x12) + 0x2a);
                if (puVar32 == (uint *)0x0) goto LAB_;
                if ((uVar8 & 0x10) == 0) goto LAB_;
                lVar12 = param_3[4];
                goto LAB_;
              }
              uStack_378 = (undefined8 *)0x14fd9c8;
              uStack_3a0 = 0x1001b2;
              (*_DAT_)(1,0x1902820,0x192f160,0x27d);
              goto LAB_;
            }
            if (*(int *)(psVar11 + 2) == 0) {
              pbVar21 = *(byte **)(psVar11 + 4);
              uVar34 = *(uint *)(psVar11 + 8);
              uVar24 = (ulonglong)uVar34;
              *puVar28 = 0;
              *(uint *)(psVar11 + 10) = uVar34;
              bVar6 = *pbVar21;
              if ((bVar6 & 0x10) != 0) {
                uVar34 = uVar34 + 2 + (*(ushort *)(pbVar21 + uVar24) + 7 >> 3);
                uVar24 = (ulonglong)uVar34;
                *(uint *)(psVar11 + 10) = uVar34;
                bVar6 = *pbVar21;
              }
              if ((bVar6 & 0x20) == 0) {
                *(int *)(psVar11 + 2) = (int)uVar24;
                psVar11[0xe] = 0;
                *(int *)(psVar11 + 0xc) = (int)uVar24;
              }
              else {
                puVar27 = (ushort *)(pbVar21 + uVar24);
                uVar8 = *puVar27;
                psVar11[0xe] = uVar8;
                if (uVar8 == 0) {
                  uStack_3a0 = 0x100a20;
                  cVar5 = func_0x(0x1e90760);
                  if (cVar5 != '\0') {
                    uStack_3a0 = 0x100a29;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      uStack_3a0 = 0x100a43;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 == '\0') {
                        uStack_3a0 = 0x100a5f;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        uStack_378 = (undefined8 *)0x0;
                        uStack_3a0 = 0x100a85;
                        (*_DAT_)(1,0x17814e8,0x18a11b8,0x80f);
                      }
                    }
                  }
                  uStack_3a0 = 0x100a93;
                  func_0x(*(undefined8 *)(psVar11 + 4),3);
                  uVar24 = (ulonglong)*(uint *)(psVar11 + 10);
                  pbVar21 = *(byte **)(psVar11 + 4);
                  uVar8 = psVar11[0xe];
                }
                uVar34 = (int)uVar24 + (uVar8 + 1) * 2;
                *(uint *)(psVar11 + 0xc) = uVar34;
                if (0x1f9e < uVar34) {
                  uStack_3a0 = 0x100ac7;
                  cVar5 = func_0x(0x1e90760);
                  if (cVar5 != '\0') {
                    uStack_3a0 = 0x100ad0;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      uStack_3a0 = 0x100aea;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 == '\0') {
                        uStack_3a0 = 0x100b06;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        uStack_378 = (undefined8 *)0x0;
                        uStack_3a0 = 0x100b2c;
                        (*_DAT_)(1,0x17814e8,0x18a11b8,0x816);
                      }
                    }
                  }
                  uStack_3a0 = 0x100b3a;
                  func_0x(*(undefined8 *)(psVar11 + 4),4);
                  uVar8 = psVar11[0xe];
                  pbVar21 = *(byte **)(psVar11 + 4);
                  uVar34 = *(uint *)(psVar11 + 0xc);
                }
                uVar24 = (ulonglong)uVar8;
                uVar8 = puVar27[uVar24];
                *(uint *)(psVar11 + 2) = uVar8 & 0x7fff;
                if ((uVar8 & 0x7fff) < uVar34) {
                  uStack_3a0 = 0x100b6d;
                  cVar5 = func_0x(0x1e90760);
                  if (cVar5 != '\0') {
                    uStack_3a0 = 0x100b76;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      uStack_3a0 = 0x100b90;
                      cVar5 = func_0x(0x1e90760);
                      if (cVar5 == '\0') {
                        uStack_3a0 = 0x100bac;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        uStack_378 = (undefined8 *)0x0;
                        uStack_3a0 = 0x100bd2;
                        (*_DAT_)(1,0x17814e8,0x18a11b8,0x81d);
                      }
                    }
                  }
                  uStack_3a0 = 0x100be0;
                  func_0x(*(undefined8 *)(psVar11 + 4),4);
                  uVar24 = (ulonglong)(ushort)psVar11[0xe];
                  pbVar21 = *(byte **)(psVar11 + 4);
                }
                if ((short)puVar27[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                  do {
                    if ((int)uVar24 == 1) {
                      uVar34 = *(uint *)(psVar11 + 0xc);
                      uVar36 = uVar34;
LAB_:
                      if ((*(ushort *)(pbVar21 + uVar24 * 2 + (ulonglong)*(uint *)(psVar11 + 10)) &
                          0x7fff) < uVar34) goto LAB_;
                    }
                    else {
                      uVar36 = *(uint *)(psVar11 + 0xc);
                      uVar34 = *(ushort *)
                                (pbVar21 + uVar24 * 2 + ((ulonglong)*(uint *)(psVar11 + 10) - 2)) &
                               0x7fff;
                      if (uVar36 <= uVar34) goto LAB_;
LAB_:
                      uStack_3a0 = 0x100c48;
                      func_0x(pbVar21,7);
                      uVar36 = *(uint *)(psVar11 + 0xc);
                      pbVar21 = *(byte **)(psVar11 + 4);
                    }
                    if ((uVar34 < uVar36) || (*(uint *)(psVar11 + 2) < uVar34)) goto LAB_;
                    if (*(ushort *)(pbVar21 + uVar34) == 5) {
                      *puVar28 = *puVar28 | 2;
                      psVar11[0xe] = psVar11[0xe] + -1;
                      uVar7 = psVar11[0x16] & 0xc7ff;
                      psVar11[0x15] = (short)uVar34;
                      lVar12 = (ulonglong)(uVar34 & 0xffff) + *(longlong *)(psVar11 + 4);
                      uVar8 = *(ushort *)(lVar12 + 2);
                      if ((uVar8 >> 0xe & 1) != 0) {
                        uVar7 = uVar8 & 0x3800 | uVar7;
                      }
                      psVar11[0x16] = uVar7;
                      psVar11[0x16] = (uVar7 ^ *(ushort *)(lVar12 + 2)) & 0x7ff ^ uVar7;
                      pbVar21 = *(byte **)(psVar11 + 4);
                      goto LAB_;
                    }
                    if (*(ushort *)(pbVar21 + uVar34) < 0x400) goto LAB_;
                    *puVar28 = *puVar28 | 1;
                    uVar8 = psVar11[0xe] - 1;
                    psVar11[0xe] = uVar8;
                    if (uVar8 == 0) goto LAB_;
                    uVar24 = (ulonglong)uVar8;
                  } while ((short)puVar27[(ulonglong)(uVar8 - 1) + 1] < 0);
                  uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                }
                else {
LAB_:
                  uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                }
              }
              if ((*pbVar21 & 0x40) == 0) {
                *(undefined4 *)(psVar11 + 0x13) = 0;
              }
              else {
                *(int *)(psVar11 + 0x13) = (int)uVar24;
                *(int *)(psVar11 + 2) = (int)uVar24 + 0xe;
                uStack_3a0 = 0x100d3f;
                uVar13 = func_0x(puVar28);
                uStack_3a0 = 0x100d4e;
                func_0x(uVar13,auStack_1e0);
                uStack_3a0 = 0x100d5a;
                iVar30 = func_0x(auStack_1e0);
                *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar30;
                uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
                pbVar21 = *(byte **)(psVar11 + 4);
              }
              if ((*(byte **)(psVar11 + 0xf) != (byte *)0x0) &&
                 (*(byte **)(psVar11 + 0xf) < pbVar21 + uVar24)) {
                uStack_3a0 = 0x100d94;
                cVar5 = func_0x(0x1e90760);
                if (cVar5 != '\0') {
                  uStack_3a0 = 0x100d9d;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    uStack_3a0 = 0x100db7;
                    cVar5 = func_0x(0x1e90760);
                    if (cVar5 == '\0') {
                      uStack_3a0 = 0x100dd3;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      uStack_378 = (undefined8 *)0x0;
                      uStack_3a0 = 0x100df9;
                      (*_DAT_)(1,0x17814e8,0x18a11b8,0x877);
                    }
                  }
                }
                uStack_3a0 = 0x100e07;
                func_0x(*(undefined8 *)(psVar11 + 4),0x12);
                uVar24 = (ulonglong)*(uint *)(psVar11 + 2);
              }
              if (0x3f3b < (int)uVar24 - 1U) {
                uStack_3a0 = 0x100e22;
                cVar5 = func_0x(0x1e90760);
                if (cVar5 != '\0') {
                  uStack_3a0 = 0x100e2b;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    uStack_3a0 = 0x100e45;
                    cVar5 = func_0x(0x1e90760);
                    if (cVar5 == '\0') {
                      uStack_3a0 = 0x100e61;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      uStack_378 = (undefined8 *)0x0;
                      uStack_3a0 = 0x100e87;
                      (*_DAT_)(1,0x17814e8,0x18a11b8,0x87c);
                    }
                  }
                }
                uStack_3a0 = 0x100e95;
                func_0x(*(undefined8 *)(psVar11 + 4),5);
              }
            }
LAB_:
            sVar29 = -*(short *)puVar15;
            if ((*(byte *)((longlong)puVar15 + 6) & 0x10) == 0) {
LAB_:
              lVar12 = (longlong)sVar29;
              puVar32 = *(uint **)(psVar11 + 4);
              if ((uint)(ushort)psVar11[0xe] < (uint)(int)sVar29) {
                uStack_328 = 0;
              }
              else {
                uVar34 = *(uint *)(psVar11 + 10);
                if (sVar29 == 1) {
                  uVar36 = *(uint *)(psVar14 + 0xc);
                  uVar34 = *(ushort *)((longlong)puVar32 + lVar12 * 2 + (ulonglong)uVar34) & 0x7fff;
LAB_:
                  if (uVar34 < uVar36) goto LAB_;
                }
                else {
                  puVar27 = (ushort *)((longlong)puVar32 + lVar12 * 2 + (ulonglong)uVar34);
                  uVar36 = *(ushort *)((longlong)puVar32 + lVar12 * 2 + ((ulonglong)uVar34 - 2)) &
                           0x7fff;
                  puVar32 = *(uint **)(psVar11 + 4);
                  uVar34 = *puVar27 & 0x7fff;
                  if (*(uint *)(uStack_308 + 0xc) <= uVar36) goto LAB_;
LAB_:
                  uStack_3a0 = 0x100f41;
                  func_0x(puVar32,7);
                  puVar32 = *(uint **)(psVar11 + 4);
                }
                puVar32 = (uint *)((ulonglong)uVar36 + (longlong)puVar32);
                uStack_328 = uVar34 - uVar36;
              }
            }
            else {
              uStack_378 = (undefined8 *)&iStack_268;
              uStack_3a0 = 0x100ec4;
              func_0x(puVar28,puVar15,0,(longlong)&uStack_200 + 4);
              if (iStack_268 != 0) goto LAB_;
              uStack_328 = **(uint **)(puVar15 + 2);
              puVar32 = *(uint **)(puVar15 + 2) + 1;
            }
            param_3 = plStack_330;
            if (((puVar15[0x10] & 0x2000) != 0) && (uStack_328 == 0)) {
              uStack_328 = 4;
              puVar32 = (uint *)0x152788c;
            }
            if ((*(byte *)(*(longlong *)(puVar15 + 0x12) + 0x2a) & 0x10) == 0) {
              lVar12 = plStack_330[3];
            }
            else {
              lVar12 = plStack_330[4];
            }
            *(undefined *)(lVar12 + *(longlong *)(puVar15 + 0xc)) = 0;
            if ((1 << (**(byte **)(psVar11 + 4) & 0xe) & 0x440U) != 0) {
              uStack_3a0 = 0x100fb3;
              iVar30 = func_0x(puVar15);
              if (iVar30 != 0) goto LAB_;
            }
            if (*(ushort *)(puVar15 + 0xf) < uStack_328) {
              uStack_3a0 = 0x100fdf;
              (*_DAT_)(6,0x52,0x16,0x91);
            }
          }
LAB_:
          uVar24 = (ulonglong)uStack_328;
          lVar12 = *(longlong *)(puVar15 + 0x12);
          if ((puVar15[0x10] & 0x800) == 0) {
            if ((*(byte *)(lVar12 + 0x2a) & 0x10) == 0) {
              lVar12 = param_3[3];
            }
            else {
              lVar12 = param_3[4];
            }
            uStack_3a0 = 0x101144;
            func_0x(lVar12 + *(longlong *)(puVar15 + 10),puVar32);
          }
          else {
            uVar8 = *(ushort *)(lVar12 + 0x2a) & 0x10;
            if (*(int *)(lVar12 + 0x10) == 10) {
              if (uVar8 == 0) {
                lVar12 = param_3[3];
              }
              else {
                lVar12 = param_3[4];
              }
              *(uint **)(lVar12 + *(longlong *)(puVar15 + 10)) = puVar32;
            }
            else {
              if (uVar8 == 0) {
                lVar12 = param_3[3];
              }
              else {
                lVar12 = param_3[4];
              }
              uStack_3a0 = 0x101179;
              func_0x(*(undefined8 *)(*(longlong *)(puVar15 + 10) + lVar12),puVar32)
              ;
            }
          }
          param_3 = plStack_330;
          psVar14 = uStack_308;
          if ((puVar15[0x10] & 0x100) != 0) {
            if ((*(byte *)(*(longlong *)(puVar15 + 0x12) + 0x2a) & 0x10) == 0) {
              lVar12 = plStack_330[3];
            }
            else {
              lVar12 = plStack_330[4];
            }
            *(ulonglong *)(lVar12 + *(longlong *)(*(longlong *)(puVar15 + 0x12) + 0x18)) = uVar24;
          }
        }
LAB_:
        uVar34 = (int)puVar35 + 1;
        puVar15 = puVar15 + 0x14;
        puVar26 = auStack_398;
        puVar35 = (uint *)(ulonglong)uVar34;
      } while (uVar34 < uVar9);
    }
  }
  plVar10 = plStack_2c8;
  pcVar1 = *(code **)(*plStack_2c8 + 8);
  *(undefined8 *)(puVar26 + -8) = 0x1011f4;
  (*pcVar1)(plVar10);
LAB_:
  uVar24 = uStack_48 ^ (ulonglong)&uStack_358;
  *(undefined8 *)(puVar26 + -8) = 0x1061b2;
  func_0x(uVar24);
  return;
}

