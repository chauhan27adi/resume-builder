
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(void)

{
  (*_DAT_)(1,0x1c9f840,0x1cc5308,0x78,0x1cc5068);
  return 0x80004001;
}

