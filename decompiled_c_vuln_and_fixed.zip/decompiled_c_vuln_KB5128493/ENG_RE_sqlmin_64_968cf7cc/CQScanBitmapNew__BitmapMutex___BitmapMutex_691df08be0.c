
void FUN_(longlong *param_1)

{
  longlong lVar1;
  code *pcVar2;
  
  if (*param_1 == 0) {
    *param_1 = 0;
    *(undefined4 *)(param_1 + 1) = 0xffffffff;
    return;
  }
  if (*(int *)(param_1 + 1) == -1) {
    lVar1 = *(longlong *)(*param_1 + 0x80);
    *(undefined8 *)(lVar1 + 0x100) = 0;
    func_0x(lVar1 + 0xd0,0);
    *param_1 = 0;
    *(undefined4 *)(param_1 + 1) = 0xffffffff;
    return;
  }
  pcVar2 = (code *)swi(3);
  (*pcVar2)();
  return;
}

