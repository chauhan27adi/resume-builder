
int FUN_(int *param_1)

{
  int iVar1;
  longlong *plVar2;
  uint uVar3;
  ulonglong uVar4;
  
  LOCK();
  iVar1 = *param_1;
  *param_1 = *param_1 + -1;
  UNLOCK();
  if (iVar1 + -1 == 0) {
    uVar4 = 0;
    if (param_1[0x10] != 0) {
      do {
        plVar2 = *(longlong **)(uVar4 * 8 + *(longlong *)(param_1 + 0x12));
        if (plVar2 != (longlong *)0x0) {
          (**(code **)(*plVar2 + 0x10))();
          *(undefined8 *)(uVar4 * 8 + *(longlong *)(param_1 + 0x12)) = 0;
        }
        uVar3 = (int)uVar4 + 1;
        uVar4 = (ulonglong)uVar3;
      } while (uVar3 < (uint)param_1[0x10]);
    }
    param_1[0x10] = 0;
  }
  return iVar1 + -1;
}

