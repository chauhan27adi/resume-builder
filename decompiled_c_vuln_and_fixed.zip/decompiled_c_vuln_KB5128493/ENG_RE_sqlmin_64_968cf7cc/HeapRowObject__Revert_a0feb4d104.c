
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2,ulonglong param_3,undefined4 param_4)

{
  ushort *puVar1;
  short *psVar2;
  byte *pbVar3;
  uint *puVar4;
  byte *pbVar5;
  short sVar6;
  undefined4 uVar7;
  code *pcVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  longlong lVar11;
  uint6 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  byte bVar15;
  char cVar16;
  char cVar17;
  char cVar18;
  ushort uVar19;
  undefined2 uVar20;
  int iVar21;
  int iVar22;
  longlong lVar23;
  longlong lVar24;
  undefined8 uVar25;
  longlong lVar26;
  ulonglong *puVar27;
  undefined4 *puVar28;
  undefined8 uVar29;
  int *piVar30;
  undefined2 *puVar31;
  undefined (*pauVar32) [16];
  undefined4 *puVar33;
  byte bVar34;
  ushort uVar35;
  undefined4 uVar36;
  longlong lVar37;
  byte bVar38;
  ushort uVar39;
  uint uVar40;
  ulonglong uVar41;
  undefined8 unaff_RBX;
  short **ppsVar42;
  undefined *puVar43;
  ushort *puVar44;
  uint uVar45;
  uint uVar46;
  uint uVar47;
  uint uVar48;
  short *psVar49;
  short **ppsVar50;
  longlong *plVar51;
  undefined *puVar52;
  short **ppsVar53;
  short **ppsVar54;
  ushort *puVar55;
  byte **ppbVar56;
  short *psVar57;
  short **ppsVar58;
  longlong unaff_GS_OFFSET;
  bool bVar59;
  bool bVar60;
  byte abStackX_18 [8];
  uint auStackX_20 [2];
  undefined8 uStack_100;
  undefined auStack_f8 [32];
  undefined8 auStack_d8 [6];
  undefined auStack_a8 [16];
  undefined auStack_98 [16];
  undefined auStack_88 [8];
  undefined8 uStack_80;
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  undefined auStack_58 [16];
  undefined auStack_48 [8];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar23 = func_0x();
  lVar23 = -lVar23;
  puVar43 = &stack0xffffffffffffffc8 + lVar23;
  pbVar5 = abStackX_18 + lVar23;
  *(undefined8 *)(&stack0x000000f0 + lVar23) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00004ce8 + lVar23) = unaff_RBX;
  *(ulonglong *)(&stack0x00004c88 + lVar23) = _DAT_ ^ (ulonglong)pbVar5;
  *(undefined4 *)(&stack0x00000030 + lVar23) = param_4;
  *(int *)(&stack0x00000034 + lVar23) = (int)param_3;
  *(short **)(&stack0x000000e0 + lVar23) = param_2;
  *(longlong *)(&stack0x000000e8 + lVar23) = param_1;
  *(undefined2 *)(&stack0x00000438 + lVar23) = 0xffff;
  *(undefined8 *)(&stack0x00000440 + lVar23) = 0;
  *(undefined4 *)(&stack0x0000043c + lVar23) = 0;
  *(undefined8 *)(&stack0x00000456 + lVar23) = 0;
  *(undefined8 *)(&stack0x00000460 + lVar23) = 0;
  *(undefined8 *)(&stack0x00000448 + lVar23) = 0;
  *(undefined2 *)(&stack0x00000470 + lVar23) = 0xffff;
  *(undefined8 *)(&stack0x00000478 + lVar23) = 0;
  *(undefined4 *)(&stack0x00000474 + lVar23) = 0;
  *(undefined8 *)(&stack0x0000048e + lVar23) = 0;
  *(undefined8 *)(&stack0x00000498 + lVar23) = 0;
  *(undefined8 *)(&stack0x00000480 + lVar23) = 0;
  if (param_2 != (short *)0x0) {
    if (*param_2 == 0) {
      if ((**(byte **)(param_2 + 4) & 0xe) == 2) {
        *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x1000de;
        func_0x(param_2 + 1);
      }
    }
    else if (((**(byte **)(param_2 + 4) & 0x1c) - 0x10 & 0xfffffffb) == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x1000f8;
      func_0x(param_2 + 1);
    }
  }
  *(uint *)(param_1 + 0x634) = *(uint *)(param_1 + 0x634) & 0xfffffffe;
  if (*(int *)(param_1 + 0x370) == 4) {
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x100114;
    func_0x(param_1 + 0x2b0);
  }
  pbVar3 = (byte *)(param_1 + 0x530);
  *(byte **)(&stack0x00000070 + lVar23) = pbVar3;
  bVar34 = *pbVar3 & 0xfe ^ ((char)param_3 << 2 ^ *pbVar3 & 0xfe) & 4;
  bVar38 = (char)(param_3 >> 1) << 7;
  *pbVar3 = bVar38 | bVar34 & 0x7f;
  *(undefined4 *)(param_1 + 0x54c) = *(undefined4 *)(*(longlong *)(param_1 + 0x28) + 0x20);
  if (param_2 == (short *)0x0) {
    bVar15 = 0;
    if (*(char *)(*(longlong *)(*(longlong *)(param_1 + 0x20) + 0x20) + 1) == '\x05') {
      bVar15 = 0x40;
    }
    *pbVar3 = bVar15 | bVar38 | bVar34 & 0x3f;
  }
  lVar37 = param_1 + 0x30;
  *(longlong *)(&stack0x000000f8 + lVar23) = lVar37;
  if (*(longlong *)(param_1 + 0x58) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10018f;
    func_0x(lVar37,0);
  }
  if (*(int *)(param_1 + 0x270) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x1001a2;
    func_0x(lVar37,0);
  }
  if (*(int *)(param_1 + 0x268) == 3) {
    *(undefined4 *)(&stack0x000001e8 + lVar23) = 0;
    *(undefined2 *)(&stack0x000001ec + lVar23) = 0;
    *(undefined2 *)(&stack0x000001ee + lVar23) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10a369;
    iVar21 = func_0x(param_1,0,0);
    if (iVar21 != 4) {
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar23) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10a392;
      (*_DAT_)(1,0x1a26700,0x19fbd78);
    }
    lVar37 = param_1 + 0x2b0;
    *(longlong *)(&stack0x00000078 + lVar23) = lVar37;
    *(undefined4 *)((longlong)auStackX_20 + lVar23) = 0;
    *(undefined8 *)(&stack0x00000068 + lVar23) = 0;
    plVar51 = *(longlong **)(*(longlong *)(param_1 + 0x28) + 8);
    *(longlong **)(&stack0x00000060 + lVar23) = plVar51;
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10a3bd;
    func_0x(&stack0x000001f0 + lVar23);
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10a3ca;
    func_0x(&stack0x000001f8 + lVar23);
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10a3d7;
    func_0x(&stack0x00000410 + lVar23);
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10a3df;
    func_0x(plVar51);
    pcVar8 = *(code **)*plVar51;
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10a3e8;
    bVar34 = (*pcVar8)(plVar51);
    abStackX_18[lVar23 + 2] = bVar34;
    pcVar8 = *(code **)(*plVar51 + 8);
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10a3f8;
    bVar38 = (*pcVar8)(plVar51);
    abStackX_18[lVar23 + 1] = bVar38;
    uVar40 = (uint)(bVar34 == 0);
    *(uint *)((longlong)auStackX_20 + lVar23 + 4) = (uint)(bVar34 == 0);
    *(undefined4 *)(&stack0x00000038 + lVar23) = 0;
    bVar59 = false;
    puVar43 = &stack0xffffffffffffffc8 + lVar23;
    if (*(longlong *)(&stack0x000000e0 + lVar23) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10a434;
      func_0x(&stack0x00000410 + lVar23,*(longlong *)(&stack0x000000e0 + lVar23));
      uVar25 = **(undefined8 **)(param_1 + 0x28);
      *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x10a440;
      iVar21 = func_0x(uVar25);
      puVar43 = &stack0xffffffffffffffc8 + lVar23;
      if (iVar21 != 0) {
        *(undefined8 *)((longlong)&uStack_80 + lVar23) = 0x10a45f;
        puVar31 = (undefined2 *)func_0x();
        *puVar31 = 0xffff;
        *(undefined8 *)(puVar31 + 4) = 0;
        *(undefined4 *)(puVar31 + 2) = 0;
        *(undefined8 *)(puVar31 + 0xf) = 0;
        *(undefined8 *)(puVar31 + 0x14) = 0;
        *(undefined8 *)(puVar31 + 8) = 0;
        *(undefined8 *)((longlong)&uStack_80 + lVar23) = 0x10a48b;
        func_0x(&stack0x000001f0 + lVar23,puVar31);
        *(undefined8 *)((longlong)&uStack_80 + lVar23) = 0x10a495;
        lVar26 = func_0x();
        lVar26 = -lVar26;
        puVar43 = auStack_f8 + lVar26 + lVar23;
        *(undefined8 *)((longlong)&uStack_100 + lVar26 + lVar23) = 0x10a4b3;
        pauVar32 = (undefined (*) [16])func_0x();
        *pauVar32 = ZEXT816(0);
        pauVar32[1] = ZEXT816(0);
        pauVar32[2] = ZEXT816(0);
        pauVar32[3] = ZEXT816(0);
        pauVar32[4] = ZEXT816(0);
        pauVar32[5] = ZEXT816(0);
        pauVar32[6] = ZEXT816(0);
        *(undefined8 *)pauVar32[7] = 0;
        *(undefined8 *)((longlong)&uStack_100 + lVar26 + lVar23) = 0x10a4df;
        uVar25 = func_0x(pauVar32);
        *(undefined8 *)((longlong)&uStack_100 + lVar26 + lVar23) = 0x10a4ee;
        func_0x(&stack0x000001f8 + lVar23,uVar25);
        *(undefined8 *)((longlong)&uStack_100 + lVar26 + lVar23) = 0x10a4fa;
        uVar25 = func_0x(&stack0x000001f8 + lVar23);
        *(undefined8 *)((longlong)&uStack_100 + lVar26 + lVar23) = 0x10a509;
        uVar29 = func_0x(&stack0x000001f0 + lVar23);
        *(undefined8 *)((longlong)auStack_d8 + lVar26 + lVar23) = uVar25;
        *(undefined8 *)((longlong)&uStack_100 + lVar26 + lVar23) = 0x10a526;
        func_0x(&stack0x00000410 + lVar23,uVar29,&stack0xffffffffffffffd8 + lVar26 + lVar23)
        ;
        param_1 = *(longlong *)(&stack0x000000e8 + lVar23);
      }
    }
    *(undefined8 *)(puVar43 + -8) = 0x10a535;
    uVar25 = func_0x(lVar37);
    *(undefined8 *)(&stack0x00000058 + lVar23) = uVar25;
    if (*(longlong *)(param_1 + 0x2d8) == 0) {
      *(undefined8 *)(puVar43 + -8) = 0x10a54d;
      func_0x(lVar37,0);
    }
    if (*(int *)(param_1 + 0x4f0) == 0) {
      *(undefined8 *)(puVar43 + -8) = 0x10a561;
      func_0x(lVar37,uVar40);
    }
    iVar21 = *(int *)(param_1 + 0x4e8);
    *(int *)(&stack0x0000002c + lVar23) = iVar21;
    *(undefined4 *)(&stack0x0000003c + lVar23) = 9;
    if (iVar21 != 1) {
      lVar26 = *(longlong *)(&stack0x000000e8 + lVar23);
      uVar25 = **(undefined8 **)(lVar26 + 0x28);
      *(undefined8 *)(puVar43 + -8) = 0x10a594;
      uVar25 = func_0x(uVar25);
      *(undefined8 *)(puVar43 + -8) = 0x10a59f;
      lVar24 = func_0x(lVar37,uVar25);
      if (lVar24 != 0) {
        *(undefined8 *)(puVar43 + -8) = 0x10a5ac;
        uVar25 = func_0x(lVar37);
        *(undefined8 *)(&stack0x00000058 + lVar23) = uVar25;
      }
      *(undefined8 *)(puVar43 + -8) = 0x10a5b8;
      cVar18 = func_0x(lVar37);
      if (*(longlong *)(lVar26 + 0x2d8) == 0) {
        *(undefined8 *)(puVar43 + -8) = 0x10a5d0;
        func_0x(lVar37,0);
      }
      if (*(int *)(lVar26 + 0x4f0) == 0) {
        *(undefined8 *)(puVar43 + -8) = 0x10a5e4;
        func_0x(lVar37,uVar40);
      }
      *(undefined8 *)(puVar43 + -8) = 0x10a5e9;
      iVar21 = func_0x();
      if (iVar21 != 0) {
        uVar25 = *(undefined8 *)(lVar26 + 0x380);
        puVar10 = *(undefined8 **)(*(longlong *)(lVar26 + 0x2b8) + 8);
        *(undefined8 *)(puVar43 + -8) = 0x10a607;
        iVar21 = func_0x(uVar25);
        uVar29 = puVar10[6];
        *(undefined8 *)(puVar43 + -8) = 0x10a61a;
        cVar17 = func_0x(uVar29);
        pcVar8 = *(code **)*puVar10;
        *(undefined8 *)(puVar43 + -8) = 0x10a625;
        cVar16 = (*pcVar8)(puVar10);
        if (cVar16 == '\0') {
          if (iVar21 == 0) {
            if (cVar17 == '\0') goto LAB_;
          }
          else {
            if (cVar17 == '\0') {
              *(undefined8 *)(puVar43 + -8) = 0x10a670;
              iVar21 = func_0x(uVar25);
              if (iVar21 != 0) {
                *(undefined8 *)(puVar43 + -8) = 0x10a67c;
                lVar37 = func_0x(puVar10);
                if (lVar37 != 0) {
                  *(undefined8 *)(puVar43 + -8) = 0x10a68c;
                  cVar17 = func_0x(lVar37);
                  if (cVar17 != '\0') {
                    *(undefined8 *)(puVar43 + -8) = 0x10a698;
                    uVar25 = func_0x(uVar25);
                    *(undefined8 *)(puVar43 + -8) = 0x10a6a0;
                    lVar26 = func_0x(uVar25);
                    *(undefined8 *)(puVar43 + -8) = 0x10a6ab;
                    lVar37 = func_0x(lVar37);
                    if (lVar26 != lVar37) goto LAB_;
                  }
                }
                goto LAB_;
              }
            }
LAB_:
            *(undefined8 *)(puVar43 + -8) = 0x10a6b8;
            func_0x(puVar10);
          }
          lVar26 = *(longlong *)(&stack0x000000e8 + lVar23);
          uVar25 = *(undefined8 *)(*(longlong *)(lVar26 + 0x2b8) + 8);
          if (*(int *)(lVar26 + 0x4f4) == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x10a6e2;
            func_0x(uVar25);
          }
          else {
            *(undefined8 *)(puVar43 + -8) = 0x10a6d8;
            func_0x();
          }
        }
        else {
LAB_:
          lVar26 = *(longlong *)(&stack0x000000e8 + lVar23);
        }
      }
      if (cVar18 == '\0') {
        psVar57 = (short *)(lVar26 + 0x388);
        ppbVar56 = (byte **)(lVar26 + 0x390);
        puVar55 = (ushort *)(lVar26 + 0x38a);
      }
      else {
        psVar57 = (short *)(lVar26 + 0x438);
        ppbVar56 = (byte **)(lVar26 + 0x440);
        puVar55 = (ushort *)(lVar26 + 0x43a);
      }
      *(short **)(&stack0x00000068 + lVar23) = psVar57;
      uVar40 = *(uint *)(puVar55 + 1);
      *(uint *)((longlong)auStackX_20 + lVar23) = uVar40;
      if (*psVar57 == 0) {
        if (uVar40 == 0) {
          *puVar55 = 0;
          uVar40 = *(uint *)(puVar55 + 7);
          uVar41 = (ulonglong)uVar40;
          *(uint *)(puVar55 + 9) = uVar40;
          pbVar3 = *(byte **)(puVar55 + 3);
          bVar34 = *pbVar3;
          if ((bVar34 & 0x10) != 0) {
            uVar40 = uVar40 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3) + 2;
            uVar41 = (ulonglong)uVar40;
            *(uint *)(puVar55 + 9) = uVar40;
            bVar34 = *pbVar3;
          }
          if ((bVar34 & 0x20) == 0) {
            *(int *)(puVar55 + 1) = (int)uVar41;
            puVar55[0xd] = 0;
            *(uint *)(puVar55 + 0xb) = uVar40;
          }
          else {
            puVar44 = (ushort *)(pbVar3 + uVar41);
            uVar39 = *puVar44;
            puVar55[0xd] = uVar39;
            if (uVar39 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10a7e4;
                  (*_DAT_)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10a80a;
                  (*_DAT_)(1,0x1877a18,0x19976e8);
                }
              }
              uVar25 = *(undefined8 *)(puVar55 + 3);
              *(undefined8 *)(puVar43 + -8) = 0x10a818;
              func_0x(uVar25,3);
              uVar39 = puVar55[0xd];
            }
            uVar40 = *(int *)(puVar55 + 9) + (uVar39 + 1) * 2;
            *(uint *)(puVar55 + 0xb) = uVar40;
            if (0x1f9e < uVar40) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10a8b3;
                  (*_DAT_)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10a8d9;
                  (*_DAT_)(1,0x1877a18,0x19976e8);
                }
              }
              uVar25 = *(undefined8 *)(puVar55 + 3);
              *(undefined8 *)(puVar43 + -8) = 0x10a8e7;
              func_0x(uVar25,4);
            }
            uVar39 = puVar44[puVar55[0xd]];
            *(uint *)(puVar55 + 1) = uVar39 & 0x7fff;
            if ((uVar39 & 0x7fff) < *(uint *)(puVar55 + 0xb)) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10a97b;
                  (*_DAT_)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10a9a1;
                  (*_DAT_)(1,0x1877a18,0x19976e8);
                }
              }
              uVar25 = *(undefined8 *)(puVar55 + 3);
              *(undefined8 *)(puVar43 + -8) = 0x10a9af;
              func_0x(uVar25,4);
            }
            do {
              uVar39 = puVar55[0xd];
              if (-1 < (short)puVar44[(ulonglong)(uVar39 - 1) + 1]) break;
              lVar37 = *(longlong *)(puVar55 + 3);
              lVar26 = (ulonglong)*(uint *)(puVar55 + 9) + lVar37;
              uVar40 = (uint)uVar39;
              if (uVar40 == 1) {
                uVar48 = *(uint *)(puVar55 + 0xb);
                uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar40 * 2);
                uVar40 = uVar48;
LAB_:
                if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
              }
              else {
                uVar48 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                uVar40 = *(uint *)(puVar55 + 0xb);
                uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                if (uVar40 <= uVar48) goto LAB_;
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x10aa14;
                func_0x(lVar37,7);
                uVar40 = *(uint *)(puVar55 + 0xb);
              }
              if ((uVar48 < uVar40) || (*(uint *)(puVar55 + 1) < uVar48)) goto LAB_;
              if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(puVar55 + 3)) == 5) {
                *puVar55 = *puVar55 | 2;
                puVar55[0xd] = puVar55[0xd] - 1;
                puVar55[0x14] = (ushort)uVar48;
                lVar37 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(puVar55 + 3);
                uVar39 = puVar55[0x15] & 0xc7ff;
                if ((*(ushort *)(lVar37 + 2) & 0x4000) != 0) {
                  uVar39 = *(ushort *)(lVar37 + 2) & 0x3800 | puVar55[0x15] & 0xc7ff;
                }
                puVar55[0x15] = uVar39;
                puVar55[0x15] = (uVar39 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar39;
                break;
              }
              if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(puVar55 + 3)) < 0x400) break;
              *puVar55 = *puVar55 | 1;
              puVar1 = puVar55 + 0xd;
              *puVar1 = *puVar1 - 1;
            } while (*puVar1 != 0);
          }
          if ((**(byte **)(puVar55 + 3) & 0x40) == 0) {
            *(undefined4 *)(puVar55 + 0x12) = 0;
          }
          else {
            *(int *)(puVar55 + 0x12) = *(int *)(puVar55 + 1);
            *(int *)(puVar55 + 1) = *(int *)(puVar55 + 1) + 0xe;
            *(undefined8 *)(puVar43 + -8) = 0x10aaff;
            puVar27 = (ulonglong *)func_0x(puVar55);
            uVar41 = *puVar27;
            *(ulonglong *)(&stack0x00000200 + lVar23) = uVar41;
            iVar21 = 0;
            uVar35 = (ushort)(uVar41 >> 0x30);
            uVar39 = uVar35;
            if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
              uVar39 = uVar35 & 0xdfff;
              if ((uVar41 & 0x4000000000000000) != 0) {
                uVar39 = uVar35 | 0x2000;
              }
            }
            if (uVar39 == 0xfffc) {
              iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(puVar55 + 1) = *(int *)(puVar55 + 1) + iVar21;
          }
          uVar40 = *(uint *)(puVar55 + 1);
          if ((*(ulonglong *)(puVar55 + 0xe) != 0) &&
             (*(ulonglong *)(puVar55 + 0xe) < (ulonglong)uVar40 + *(longlong *)(puVar55 + 3))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar37 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8), lVar37 != 0 &&
                 (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                (*(char *)(lVar37 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x10ac00;
                (*_DAT_)(0x22,0x44,0x15);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x10ac26;
                (*_DAT_)(1,0x1877a18,0x19976e8);
              }
            }
            uVar25 = *(undefined8 *)(puVar55 + 3);
            *(undefined8 *)(puVar43 + -8) = 0x10ac34;
            func_0x(uVar25,0x12);
            uVar40 = *(uint *)(puVar55 + 1);
          }
          if (0x3f3b < uVar40 - 1) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar37 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar37 != 0 &&
                ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                 (*(char *)(lVar37 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x10acbf;
                (*_DAT_)(0x22,0x44,0x15);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x10ace5;
                (*_DAT_)(1,0x1877a18,0x19976e8);
              }
            }
            uVar25 = *(undefined8 *)(puVar55 + 3);
            *(undefined8 *)(puVar43 + -8) = 0x10acf3;
            func_0x(uVar25,5);
          }
        }
LAB_:
        uVar40 = *(uint *)(puVar55 + 1);
        *(uint *)((longlong)auStackX_20 + lVar23) = uVar40;
        if ((uVar40 < 9) &&
           (((**(byte **)(puVar55 + 3) & 0xe) == 0 || ((**(byte **)(puVar55 + 3) & 0xe) == 0xc)))) {
          *(undefined4 *)((longlong)auStackX_20 + lVar23) = 9;
        }
      }
      else {
        if (uVar40 == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x10ad24;
          func_0x(puVar55);
          uVar40 = *(uint *)(puVar55 + 1);
          *(uint *)((longlong)auStackX_20 + lVar23) = uVar40;
        }
        if ((uVar40 < 9) &&
           (((**(byte **)(puVar55 + 3) & 0x1c) == 0 || ((**(byte **)(puVar55 + 3) & 0x1c) == 0xc))))
        {
          *(undefined4 *)((longlong)auStackX_20 + lVar23) = 9;
        }
      }
      if (*psVar57 == 0) {
        if ((**ppbVar56 & 0xe) == 2) goto LAB_;
LAB_:
        lVar37 = *(longlong *)(&stack0x00000078 + lVar23);
        *(undefined8 *)(puVar43 + -8) = 0x10add7;
        func_0x(lVar37,&stack0x00000208 + lVar23,0);
      }
      else {
        if (((**ppbVar56 & 0x1c) - 0x10 & 0xfffffffb) != 0) goto LAB_;
LAB_:
        *(undefined8 *)(puVar43 + -8) = 0x10ad60;
        lVar37 = func_0x(psVar57);
        if (lVar37 == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x10ad7d;
          (*_DAT_)(6,0x55,0x10);
        }
        *(undefined8 *)(puVar43 + -8) = 0x10ad8c;
        func_0x(&stack0x00000208 + lVar23,lVar37);
        psVar57 = *(short **)(&stack0x000000e0 + lVar23);
        if (psVar57 != (short *)0x0) {
          if (*psVar57 == 0) {
            bVar60 = (**(byte **)(psVar57 + 4) & 0xe) == 2;
          }
          else {
            bVar60 = ((**(byte **)(psVar57 + 4) & 0x1c) - 0x10 & 0xfffffffb) == 0;
          }
          if (!bVar60) {
            *(undefined8 *)(puVar43 + -8) = 0x10adfe;
            func_0x(psVar57,&stack0x00000208 + lVar23);
            if (abStackX_18[lVar23 + 2] != 0) {
              if (*psVar57 == 0) {
                if (*(int *)(psVar57 + 2) == 0) {
                  psVar57[1] = 0;
                  uVar40 = *(uint *)(psVar57 + 8);
                  uVar41 = (ulonglong)uVar40;
                  *(uint *)(psVar57 + 10) = uVar40;
                  pbVar3 = *(byte **)(psVar57 + 4);
                  bVar34 = *pbVar3;
                  if ((bVar34 & 0x10) != 0) {
                    uVar40 = uVar40 + 2 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3);
                    uVar41 = (ulonglong)uVar40;
                    *(uint *)(psVar57 + 10) = uVar40;
                    bVar34 = *pbVar3;
                  }
                  if ((bVar34 & 0x20) == 0) {
                    *(int *)(psVar57 + 2) = (int)uVar41;
                    psVar57[0xe] = 0;
                    *(uint *)(psVar57 + 0xc) = uVar40;
                  }
                  else {
                    puVar55 = (ushort *)(pbVar3 + uVar41);
                    uVar39 = *puVar55;
                    psVar57[0xe] = uVar39;
                    if (uVar39 == 0) {
                      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                          (lVar37 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                         ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                          (*(char *)(lVar37 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar43 + -8) = 0x10aeee;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x10af14;
                          (*_DAT_)(1,0x1877a18,0x19976e8);
                        }
                      }
                      uVar25 = *(undefined8 *)(psVar57 + 4);
                      *(undefined8 *)(puVar43 + -8) = 0x10af22;
                      func_0x(uVar25,3);
                      uVar39 = psVar57[0xe];
                    }
                    uVar40 = *(int *)(psVar57 + 10) + 2 + (uint)uVar39 * 2;
                    *(uint *)(psVar57 + 0xc) = uVar40;
                    if (0x1f9e < uVar40) {
                      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                         ((lVar37 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                          ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                           (*(char *)(lVar37 + 0x499) != '\0')))))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar43 + -8) = 0x10afbe;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x10afe4;
                          (*_DAT_)(1,0x1877a18,0x19976e8);
                        }
                      }
                      uVar25 = *(undefined8 *)(psVar57 + 4);
                      *(undefined8 *)(puVar43 + -8) = 0x10aff2;
                      func_0x(uVar25,4);
                    }
                    uVar39 = puVar55[(ushort)psVar57[0xe]];
                    *(uint *)(psVar57 + 2) = uVar39 & 0x7fff;
                    if ((uVar39 & 0x7fff) < *(uint *)(psVar57 + 0xc)) {
                      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                          (lVar37 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                         ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                          (*(char *)(lVar37 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar43 + -8) = 0x10b089;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x10b0af;
                          (*_DAT_)(1,0x1877a18,0x19976e8);
                        }
                      }
                      uVar25 = *(undefined8 *)(psVar57 + 4);
                      *(undefined8 *)(puVar43 + -8) = 0x10b0bd;
                      func_0x(uVar25,4);
                    }
                    do {
                      uVar39 = psVar57[0xe];
                      if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                      lVar37 = *(longlong *)(psVar57 + 4);
                      lVar26 = (ulonglong)*(uint *)(psVar57 + 10) + lVar37;
                      uVar40 = (uint)uVar39;
                      if (uVar40 == 1) {
                        uVar48 = *(uint *)(psVar57 + 0xc);
                        uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar40 * 2);
                        uVar40 = uVar48;
LAB_:
                        if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
                      }
                      else {
                        uVar48 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                        uVar40 = *(uint *)(psVar57 + 0xc);
                        uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                        if (uVar40 <= uVar48) goto LAB_;
LAB_:
                        *(undefined8 *)(puVar43 + -8) = 0x10b137;
                        func_0x(lVar37,7);
                        uVar40 = *(uint *)(psVar57 + 0xc);
                      }
                      if ((uVar48 < uVar40) || (*(uint *)(psVar57 + 2) < uVar48)) goto LAB_;
                      uVar39 = *(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar57 + 4));
                      if (uVar39 == 5) {
                        psVar57[1] = psVar57[1] | 2;
                        psVar57[0xe] = psVar57[0xe] + -1;
                        psVar57[0x15] = (short)uVar48;
                        lVar37 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(psVar57 + 4);
                        uVar39 = psVar57[0x16] & 0xc7ffU;
                        if ((*(ushort *)(lVar37 + 2) & 0x4000) != 0) {
                          uVar39 = *(ushort *)(lVar37 + 2) & 0x3800 | psVar57[0x16] & 0xc7ffU;
                        }
                        psVar57[0x16] = uVar39;
                        psVar57[0x16] = (uVar39 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar39;
                        break;
                      }
                      if (uVar39 < 0x400) break;
                      psVar57[1] = psVar57[1] | 1;
                      psVar49 = psVar57 + 0xe;
                      *psVar49 = *psVar49 + -1;
                    } while (*psVar49 != 0);
                  }
                  iVar21 = 0;
                  if ((**(byte **)(psVar57 + 4) & 0x40) == 0) {
                    *(undefined4 *)(psVar57 + 0x13) = 0;
                  }
                  else {
                    *(int *)(psVar57 + 0x13) = *(int *)(psVar57 + 2);
                    *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + 0xe;
                    *(undefined8 *)(puVar43 + -8) = 0x10b227;
                    puVar27 = (ulonglong *)func_0x(psVar57 + 1);
                    uVar41 = *puVar27;
                    *(ulonglong *)(&stack0x00000210 + lVar23) = uVar41;
                    uVar35 = (ushort)(uVar41 >> 0x30);
                    uVar39 = uVar35;
                    if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                      uVar39 = uVar35 & 0xdfff;
                      if ((uVar41 & 0x4000000000000000) != 0) {
                        uVar39 = uVar35 | 0x2000;
                      }
                    }
                    if (uVar39 == 0xfffc) {
                      iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                    }
                    *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + iVar21;
                  }
                  uVar40 = *(uint *)(psVar57 + 2);
                  if ((*(ulonglong *)(psVar57 + 0xf) != 0) &&
                     (*(ulonglong *)(psVar57 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar57 + 4)
                     )) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       (((lVar37 = *(longlong *)
                                    ((ulonglong)*_DAT_ +
                                     *(longlong *)
                                      (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                      (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                         (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                        (*(char *)(lVar37 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x10b324;
                        (*_DAT_)(0x22,0x44,0x15);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10b34a;
                        (*_DAT_)(1,0x1877a18,0x19976e8);
                      }
                    }
                    uVar25 = *(undefined8 *)(psVar57 + 4);
                    *(undefined8 *)(puVar43 + -8) = 0x10b358;
                    func_0x(uVar25,0x12);
                    uVar40 = *(uint *)(psVar57 + 2);
                  }
                  if (0x3f3b < uVar40 - 1) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                        ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                         (*(char *)(lVar37 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x10b3e4;
                        (*_DAT_)(0x22,0x44,0x15);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10b40a;
                        (*_DAT_)(1,0x1877a18,0x19976e8);
                      }
                    }
                    uVar25 = *(undefined8 *)(psVar57 + 4);
                    *(undefined8 *)(puVar43 + -8) = 0x10b418;
                    func_0x(uVar25,5);
                  }
                }
LAB_:
                uVar40 = *(uint *)(psVar57 + 2);
                if (uVar40 < 9) {
                  bVar34 = **(byte **)(psVar57 + 4) & 0xe;
joined_r0x0010b456:
                  if ((bVar34 == 0) || (bVar34 == 0xc)) {
                    uVar40 = 9;
                  }
                }
              }
              else {
                uVar40 = *(uint *)(psVar57 + 2);
                if (uVar40 == 0) {
                  *(undefined8 *)(puVar43 + -8) = 0x10b443;
                  func_0x(psVar57 + 1);
                  uVar40 = *(uint *)(psVar57 + 2);
                }
                if (uVar40 < 9) {
                  bVar34 = **(byte **)(psVar57 + 4) & 0x1c;
                  goto joined_r0x0010b456;
                }
              }
              *(undefined8 *)(puVar43 + -8) = 0x10b46a;
              uVar20 = func_0x(psVar57);
              *(undefined8 *)(puVar43 + -8) = 0x10b472;
              uVar48 = func_0x(uVar20);
              if (uVar40 < uVar48) {
                *(undefined4 *)(&stack0x00000218 + lVar23) = 0;
                *(undefined2 *)(&stack0x0000021c + lVar23) = 0;
                *(undefined2 *)(&stack0x0000021e + lVar23) = 0;
                *(undefined8 *)(&stack0x00000b88 + lVar23) =
                     *(undefined8 *)(&stack0x00000218 + lVar23);
                *(undefined4 *)(&stack0x00000b90 + lVar23) = 0;
                *(undefined2 *)(&stack0x00000b94 + lVar23) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x10b4b9;
                func_0x(psVar57,&stack0x00000b88 + lVar23);
              }
              lVar37 = *(longlong *)(&stack0x00000078 + lVar23);
              uVar40 = *(uint *)((longlong)auStackX_20 + lVar23 + 4);
              goto LAB_;
            }
          }
        }
        lVar37 = *(longlong *)(&stack0x00000078 + lVar23);
      }
      uVar40 = *(uint *)((longlong)auStackX_20 + lVar23 + 4);
    }
LAB_:
    *(undefined8 *)(puVar43 + -8) = 0x10b4e1;
    cVar18 = func_0x(lVar37);
    if (cVar18 != '\0') {
      lVar26 = *(longlong *)(&stack0x000000e8 + lVar23);
      if (*(longlong *)(lVar26 + 0x2d8) == 0) {
        *(undefined8 *)(puVar43 + -8) = 0x10b505;
        func_0x(lVar37,0);
      }
      if (*(int *)(lVar26 + 0x4f0) == 0) {
        *(undefined8 *)(puVar43 + -8) = 0x10b51b;
        func_0x(lVar37,uVar40);
      }
      *(undefined8 *)(puVar43 + -8) = 0x10b520;
      iVar21 = func_0x();
      if (iVar21 != 0) {
        uVar25 = *(undefined8 *)(lVar26 + 0x380);
        puVar10 = *(undefined8 **)(*(longlong *)(lVar26 + 0x2b8) + 8);
        *(undefined8 *)(puVar43 + -8) = 0x10b544;
        iVar21 = func_0x(uVar25);
        uVar29 = puVar10[6];
        *(undefined8 *)(puVar43 + -8) = 0x10b555;
        cVar18 = func_0x(uVar29);
        pcVar8 = *(code **)*puVar10;
        *(undefined8 *)(puVar43 + -8) = 0x10b560;
        cVar17 = (*pcVar8)(puVar10);
        if (cVar17 == '\0') {
          if (iVar21 == 0) {
            if (cVar18 == '\0') goto LAB_;
          }
          else {
            if (cVar18 == '\0') {
              *(undefined8 *)(puVar43 + -8) = 0x10b57e;
              iVar21 = func_0x(uVar25);
              if (iVar21 != 0) {
                *(undefined8 *)(puVar43 + -8) = 0x10b58a;
                lVar37 = func_0x(puVar10);
                if (lVar37 != 0) {
                  *(undefined8 *)(puVar43 + -8) = 0x10b59a;
                  cVar18 = func_0x(lVar37);
                  if (cVar18 != '\0') {
                    *(undefined8 *)(puVar43 + -8) = 0x10b5a6;
                    uVar25 = func_0x(uVar25);
                    *(undefined8 *)(puVar43 + -8) = 0x10b5ae;
                    lVar24 = func_0x(uVar25);
                    *(undefined8 *)(puVar43 + -8) = 0x10b5b9;
                    lVar37 = func_0x(lVar37);
                    if (lVar24 != lVar37) goto LAB_;
                  }
                }
                goto LAB_;
              }
            }
LAB_:
            *(undefined8 *)(puVar43 + -8) = 0x10b5c6;
            func_0x(puVar10);
          }
          uVar25 = *(undefined8 *)(*(longlong *)(lVar26 + 0x2b8) + 8);
          if (*(int *)(lVar26 + 0x4f4) == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x10b5e9;
            func_0x(uVar25);
          }
          else {
            *(undefined8 *)(puVar43 + -8) = 0x10b5e2;
            func_0x();
          }
        }
      }
LAB_:
      psVar57 = (short *)(lVar26 + 0x388);
      bVar59 = true;
      sVar6 = *psVar57;
      *(short *)(&stack0x00000470 + lVar23) = sVar6;
      if (sVar6 == 0) {
        if (*(int *)(lVar26 + 0x38c) == 0) {
          *(undefined2 *)(lVar26 + 0x38a) = 0;
          uVar40 = *(uint *)(lVar26 + 0x398);
          uVar41 = (ulonglong)uVar40;
          *(uint *)(lVar26 + 0x39c) = uVar40;
          pbVar3 = *(byte **)(lVar26 + 0x390);
          bVar34 = *pbVar3;
          if ((bVar34 & 0x10) != 0) {
            uVar40 = uVar40 + 2 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3);
            uVar41 = (ulonglong)uVar40;
            *(uint *)(lVar26 + 0x39c) = uVar40;
            bVar34 = *pbVar3;
          }
          if ((bVar34 & 0x20) == 0) {
            *(int *)(lVar26 + 0x38c) = (int)uVar41;
            *(undefined2 *)(lVar26 + 0x3a4) = 0;
            *(uint *)(lVar26 + 0x3a0) = uVar40;
          }
          else {
            puVar55 = (ushort *)(pbVar3 + uVar41);
            uVar39 = *puVar55;
            *(ushort *)(lVar26 + 0x3a4) = uVar39;
            if (uVar39 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10b6df;
                  (*_DAT_)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10b705;
                  (*_DAT_)(1,0x1877a18,0x19976e8);
                }
              }
              uVar25 = *(undefined8 *)(lVar26 + 0x390);
              *(undefined8 *)(puVar43 + -8) = 0x10b713;
              func_0x(uVar25,3);
              uVar39 = *(ushort *)(lVar26 + 0x3a4);
            }
            uVar40 = *(int *)(lVar26 + 0x39c) + 2 + (uint)uVar39 * 2;
            *(uint *)(lVar26 + 0x3a0) = uVar40;
            if (0x1f9e < uVar40) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10b7af;
                  (*_DAT_)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10b7d5;
                  (*_DAT_)(1,0x1877a18,0x19976e8);
                }
              }
              uVar25 = *(undefined8 *)(lVar26 + 0x390);
              *(undefined8 *)(puVar43 + -8) = 0x10b7e3;
              func_0x(uVar25,4);
            }
            uVar39 = puVar55[*(ushort *)(lVar26 + 0x3a4)];
            *(uint *)(lVar26 + 0x38c) = uVar39 & 0x7fff;
            if ((uVar39 & 0x7fff) < *(uint *)(lVar26 + 0x3a0)) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10b878;
                  (*_DAT_)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10b89e;
                  (*_DAT_)(1,0x1877a18,0x19976e8);
                }
              }
              uVar25 = *(undefined8 *)(lVar26 + 0x390);
              *(undefined8 *)(puVar43 + -8) = 0x10b8ac;
              func_0x(uVar25,4);
            }
            do {
              uVar39 = *(ushort *)(lVar26 + 0x3a4);
              if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
              lVar37 = *(longlong *)(lVar26 + 0x390);
              lVar24 = (ulonglong)*(uint *)(lVar26 + 0x39c) + lVar37;
              uVar40 = (uint)uVar39;
              if (uVar40 == 1) {
                uVar48 = *(uint *)(lVar26 + 0x3a0);
                uVar39 = *(ushort *)(lVar24 + (longlong)(int)uVar40 * 2);
LAB_:
                if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
              }
              else {
                uVar48 = *(ushort *)(lVar24 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                uVar39 = *(ushort *)(lVar24 + (ulonglong)uVar39 * 2);
                if (*(uint *)(lVar26 + 0x3a0) <= uVar48) goto LAB_;
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x10b90e;
                func_0x(lVar37,7);
                if (uVar48 < *(uint *)(lVar26 + 0x3a0)) goto LAB_;
              }
              if (*(uint *)(lVar26 + 0x38c) < uVar48) goto LAB_;
              uVar39 = *(ushort *)((ulonglong)uVar48 + *(longlong *)(lVar26 + 0x390));
              if (uVar39 == 5) {
                *(ushort *)(lVar26 + 0x38a) = *(ushort *)(lVar26 + 0x38a) | 2;
                *(short *)(lVar26 + 0x3a4) = *(short *)(lVar26 + 0x3a4) + -1;
                *(short *)(lVar26 + 0x3b2) = (short)uVar48;
                lVar37 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(lVar26 + 0x390);
                uVar39 = *(ushort *)(lVar26 + 0x3b4) & 0xc7ff;
                if ((*(ushort *)(lVar37 + 2) & 0x4000) != 0) {
                  uVar39 = *(ushort *)(lVar37 + 2) & 0x3800 | uVar39;
                }
                *(ushort *)(lVar26 + 0x3b4) = uVar39;
                *(ushort *)(lVar26 + 0x3b4) = (uVar39 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar39;
                break;
              }
              if (uVar39 < 0x400) break;
              *(ushort *)(lVar26 + 0x38a) = *(ushort *)(lVar26 + 0x38a) | 1;
              psVar57 = (short *)(lVar26 + 0x3a4);
              *psVar57 = *psVar57 + -1;
            } while (*psVar57 != 0);
          }
          if ((**(byte **)(lVar26 + 0x390) & 0x40) == 0) {
            *(undefined4 *)(lVar26 + 0x3ae) = 0;
          }
          else {
            *(int *)(lVar26 + 0x3ae) = *(int *)(lVar26 + 0x38c);
            *(int *)(lVar26 + 0x38c) = *(int *)(lVar26 + 0x38c) + 0xe;
            *(undefined8 *)(puVar43 + -8) = 0x10b9ef;
            puVar27 = (ulonglong *)func_0x(lVar26 + 0x38a);
            uVar41 = *puVar27;
            *(ulonglong *)(&stack0x00000220 + lVar23) = uVar41;
            uVar40 = 0;
            uVar35 = (ushort)(uVar41 >> 0x30);
            uVar39 = uVar35;
            if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
              uVar39 = uVar35 & 0xdfff;
              if ((uVar41 & 0x4000000000000000) != 0) {
                uVar39 = uVar35 | 0x2000;
              }
            }
            if (uVar39 == 0xfffc) {
              uVar40 = ((uint)(uVar41 >> 0x20) & 0xffff) >> 5;
            }
            *(int *)(lVar26 + 0x38c) = *(int *)(lVar26 + 0x38c) + uVar40;
          }
          uVar40 = *(uint *)(lVar26 + 0x38c);
          if ((*(ulonglong *)(lVar26 + 0x3a6) != 0) &&
             (*(ulonglong *)(lVar26 + 0x3a6) < (ulonglong)uVar40 + *(longlong *)(lVar26 + 0x390))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar37 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8), lVar37 != 0 &&
                 (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                (*(char *)(lVar37 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x10baf0;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x10bb16;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
              }
            }
            uVar25 = *(undefined8 *)(lVar26 + 0x390);
            *(undefined8 *)(puVar43 + -8) = 0x10bb24;
            func_0x(uVar25,0x12);
            uVar40 = *(uint *)(lVar26 + 0x38c);
          }
          if (0x3f3b < uVar40 - 1) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar37 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar37 != 0 &&
                ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                 (*(char *)(lVar37 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x10bbaf;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x10bbd5;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
              }
            }
            uVar25 = *(undefined8 *)(lVar26 + 0x390);
            *(undefined8 *)(puVar43 + -8) = 0x10bbe3;
            func_0x(uVar25,5);
          }
        }
LAB_:
        uVar40 = *(uint *)(lVar26 + 0x38c);
        uVar48 = uVar40;
        if ((uVar40 < 9) &&
           ((bVar34 = **(byte **)(lVar26 + 0x390) & 0xe, bVar34 == 0 || (bVar34 == 0xc)))) {
          uVar48 = 9;
        }
        *(undefined4 *)(&stack0x00000480 + lVar23) = *(undefined4 *)(lVar26 + 0x398);
        *(undefined2 *)(&stack0x00000472 + lVar23) = *(undefined2 *)(lVar26 + 0x38a);
        *(uint *)(&stack0x00000474 + lVar23) = uVar40;
        *(undefined2 *)(&stack0x0000048c + lVar23) = *(undefined2 *)(lVar26 + 0x3a4);
        *(undefined4 *)(&stack0x00000484 + lVar23) = *(undefined4 *)(lVar26 + 0x39c);
        *(undefined4 *)(&stack0x00000488 + lVar23) = *(undefined4 *)(lVar26 + 0x3a0);
        *(undefined4 *)(&stack0x00000496 + lVar23) = *(undefined4 *)(lVar26 + 0x3ae);
        *(undefined8 *)(puVar43 + -8) = 0x10bc50;
        uVar25 = func_0x(lVar26 + 0x38a);
        *(undefined8 *)(puVar43 + -8) = 0x10bc67;
        func_0x(&stack0x00000d48 + lVar23,0x1f9e,uVar25,uVar48);
        *(undefined **)(&stack0x00000478 + lVar23) = &stack0x00000d48 + lVar23;
        *(undefined8 *)(puVar43 + -8) = 0x10bc81;
        iVar21 = func_0x(&stack0x00000472 + lVar23);
        if (iVar21 != 0) {
          *(undefined8 *)(puVar43 + -8) = 0x10bc99;
          uVar19 = func_0x(&stack0x00000472 + lVar23,&stack0x00000050 + lVar23);
          *(ushort *)(&stack0x0000049a + lVar23) = uVar19;
          uVar39 = *(ushort *)((ulonglong)uVar19 + *(longlong *)(&stack0x00000478 + lVar23) + 2);
          uVar35 = *(ushort *)(&stack0x0000049c + lVar23);
          if ((uVar39 >> 0xe & 1) == 0) {
            uVar35 = uVar35 & 0xc7ff;
          }
          else {
            uVar35 = uVar35 ^ (uVar39 ^ uVar35) & 0x3800;
          }
          *(ushort *)(&stack0x0000049c + lVar23) = uVar35;
          *(ushort *)(&stack0x0000049c + lVar23) =
               (uVar35 ^ *(ushort *)
                          ((ulonglong)uVar19 + *(longlong *)(&stack0x00000478 + lVar23) + 2)) &
               0x7ff ^ uVar35;
        }
      }
      else {
        *(undefined8 *)(puVar43 + -8) = 0x10bd04;
        lVar37 = func_0x(lVar26 + 0x38a);
        if (lVar37 != 0) {
          if (*psVar57 == 0) {
            uVar25 = 0;
          }
          else {
            *(undefined8 *)(puVar43 + -8) = 0x10bd1c;
            uVar25 = func_0x(lVar26 + 0x38a);
          }
          *(undefined8 *)(puVar43 + -8) = 0x10bd24;
          iVar21 = func_0x(uVar25);
          if (iVar21 != 0) {
            *(undefined8 *)(puVar43 + -8) = 0x10bd44;
            func_0x(&stack0x00000470 + lVar23,&stack0x00000d48 + lVar23,0x1f9e,psVar57);
            goto LAB_;
          }
        }
        *(undefined8 *)(puVar43 + -8) = 0x10bd63;
        func_0x(&stack0x00000472 + lVar23,&stack0x00000d48 + lVar23,0x1f9e,lVar26 + 0x38a);
        if (*psVar57 == 0) {
          uVar25 = 0;
        }
        else {
          *(undefined8 *)(puVar43 + -8) = 0x10bd76;
          uVar25 = func_0x(lVar26 + 0x38a);
        }
        *(undefined8 *)(&stack0x00000480 + lVar23) = uVar25;
      }
    }
LAB_:
    pcVar8 = *(code **)(*plVar51 + 0x58);
    *(undefined8 *)(puVar43 + -8) = 0x10bd87;
    cVar18 = (*pcVar8)(plVar51);
    ppsVar53 = (short **)0x0;
    uVar36 = 0;
    if (cVar18 != '\0') {
      uVar36 = 0x80;
    }
    *(undefined4 *)(&stack0x00000028 + lVar23) = uVar36;
    puVar28 = *(undefined4 **)(&stack0x00000070 + lVar23);
    lVar37 = 2;
    puVar33 = (undefined4 *)(&stack0x000004a8 + lVar23);
    do {
      uVar36 = puVar28[1];
      uVar7 = puVar28[2];
      uVar13 = puVar28[3];
      *puVar33 = *puVar28;
      puVar33[1] = uVar36;
      puVar33[2] = uVar7;
      puVar33[3] = uVar13;
      uVar36 = puVar28[5];
      uVar7 = puVar28[6];
      uVar13 = puVar28[7];
      puVar33[4] = puVar28[4];
      puVar33[5] = uVar36;
      puVar33[6] = uVar7;
      puVar33[7] = uVar13;
      uVar36 = puVar28[9];
      uVar7 = puVar28[10];
      uVar13 = puVar28[0xb];
      puVar33[8] = puVar28[8];
      puVar33[9] = uVar36;
      puVar33[10] = uVar7;
      puVar33[0xb] = uVar13;
      uVar36 = puVar28[0xd];
      uVar7 = puVar28[0xe];
      uVar13 = puVar28[0xf];
      puVar33[0xc] = puVar28[0xc];
      puVar33[0xd] = uVar36;
      puVar33[0xe] = uVar7;
      puVar33[0xf] = uVar13;
      uVar36 = puVar28[0x11];
      uVar7 = puVar28[0x12];
      uVar13 = puVar28[0x13];
      puVar33[0x10] = puVar28[0x10];
      puVar33[0x11] = uVar36;
      puVar33[0x12] = uVar7;
      puVar33[0x13] = uVar13;
      uVar36 = puVar28[0x15];
      uVar7 = puVar28[0x16];
      uVar13 = puVar28[0x17];
      puVar33[0x14] = puVar28[0x14];
      puVar33[0x15] = uVar36;
      puVar33[0x16] = uVar7;
      puVar33[0x17] = uVar13;
      uVar36 = puVar28[0x19];
      uVar7 = puVar28[0x1a];
      uVar13 = puVar28[0x1b];
      puVar33[0x18] = puVar28[0x18];
      puVar33[0x19] = uVar36;
      puVar33[0x1a] = uVar7;
      puVar33[0x1b] = uVar13;
      uVar36 = puVar28[0x1d];
      uVar7 = puVar28[0x1e];
      uVar13 = puVar28[0x1f];
      puVar33[0x1c] = puVar28[0x1c];
      puVar33[0x1d] = uVar36;
      puVar33[0x1e] = uVar7;
      puVar33[0x1f] = uVar13;
      puVar28 = puVar28 + 0x20;
      lVar37 = lVar37 + -1;
      puVar33 = puVar33 + 0x20;
    } while (lVar37 != 0);
    ppsVar50 = (short **)(&stack0x00000470 + lVar23);
    if (!bVar59) {
      ppsVar50 = ppsVar53;
    }
    *(short ***)(&stack0x00000228 + lVar23) = ppsVar50;
    ppsVar58 = ppsVar53;
    if (*(int *)((longlong)auStackX_20 + lVar23) != 0) {
      ppsVar58 = *(short ***)(&stack0x00000068 + lVar23);
    }
    ppsVar42 = (short **)(&stack0x00000410 + lVar23);
    if (*(longlong *)(&stack0x000000e0 + lVar23) == 0) {
      ppsVar42 = ppsVar53;
    }
    *(short ***)(&stack0x00000230 + lVar23) = ppsVar42;
    *(undefined8 *)(puVar43 + -8) = 0x10be3f;
    func_0x(&stack0x00000368 + lVar23);
    *(undefined4 *)(&stack0x00000370 + lVar23) = *(undefined4 *)(&stack0x000004b0 + lVar23);
    *(undefined4 *)(&stack0x00000374 + lVar23) = *(undefined4 *)(&stack0x000004b4 + lVar23);
    *(undefined4 *)(&stack0x00000378 + lVar23) = *(undefined4 *)(&stack0x000004b8 + lVar23);
    *(undefined4 *)(&stack0x0000037c + lVar23) = *(undefined4 *)(&stack0x000004bc + lVar23);
    bVar34 = (byte)(&stack0x000004a8)[lVar23] >> 6 & 2 | (&stack0x000004a8)[lVar23] & 1 |
             (&stack0x00000368)[lVar23] & 0xfc;
    (&stack0x00000368)[lVar23] = bVar34;
    if (((ppsVar42 != (short **)0x0) &&
        (lVar37 = *(longlong *)(&stack0x00000058 + lVar23), ppsVar53 = (short **)0x0, lVar37 != 0))
       && (*(char *)(lVar37 + 2) < '\0')) {
      *(undefined8 *)(puVar43 + -8) = 0x10be92;
      func_0x(ppsVar42,lVar37);
      ppsVar53 = (short **)0x1;
      bVar34 = (&stack0x00000368)[lVar23];
    }
    uVar36 = *(undefined4 *)(&stack0x00000368 + lVar23);
    uVar7 = *(undefined4 *)(&stack0x0000036c + lVar23);
    uVar13 = *(undefined4 *)(&stack0x00000370 + lVar23);
    uVar14 = *(undefined4 *)(&stack0x00000374 + lVar23);
    uVar25 = *(undefined8 *)(&stack0x00000378 + lVar23);
    if (ppsVar58 == (short **)0x0) {
      *(undefined4 *)(&stack0x00000388 + lVar23) = uVar36;
      *(undefined4 *)(&stack0x0000038c + lVar23) = uVar7;
      *(undefined4 *)(&stack0x00000390 + lVar23) = uVar13;
      *(undefined4 *)(&stack0x00000394 + lVar23) = uVar14;
      *(undefined8 *)(&stack0x00000398 + lVar23) = uVar25;
      if ((int)ppsVar53 == 0) {
        psVar57 = *ppsVar42;
      }
      else {
        psVar57 = ppsVar42[1];
      }
      puVar55 = (ushort *)(psVar57 + 1);
      if (*psVar57 == 0) {
        if (*(int *)(psVar57 + 2) == 0) {
          *puVar55 = 0;
          uVar40 = *(uint *)(psVar57 + 8);
          uVar41 = (ulonglong)uVar40;
          *(uint *)(psVar57 + 10) = uVar40;
          pbVar3 = *(byte **)(psVar57 + 4);
          bVar34 = *pbVar3;
          if ((bVar34 & 0x10) != 0) {
            uVar40 = uVar40 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3) + 2;
            uVar41 = (ulonglong)uVar40;
            *(uint *)(psVar57 + 10) = uVar40;
            bVar34 = *pbVar3;
          }
          if ((bVar34 & 0x20) == 0) {
            *(int *)(psVar57 + 2) = (int)uVar41;
            psVar57[0xe] = 0;
            *(uint *)(psVar57 + 0xc) = uVar40;
          }
          else {
            puVar44 = (ushort *)(pbVar3 + uVar41);
            uVar39 = *puVar44;
            psVar57[0xe] = uVar39;
            if (uVar39 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10bfaf;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10bfd5;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x10bfe3;
              func_0x(uVar25,3);
              uVar39 = psVar57[0xe];
            }
            uVar40 = *(int *)(psVar57 + 10) + (uVar39 + 1) * 2;
            *(uint *)(psVar57 + 0xc) = uVar40;
            if (0x1f9e < uVar40) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10c07b;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10c0a1;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x10c0af;
              func_0x(uVar25,4);
            }
            uVar39 = puVar44[(ushort)psVar57[0xe]];
            *(uint *)(psVar57 + 2) = uVar39 & 0x7fff;
            if ((uVar39 & 0x7fff) < *(uint *)(psVar57 + 0xc)) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10c143;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10c169;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x10c177;
              func_0x(uVar25,4);
            }
            do {
              uVar39 = psVar57[0xe];
              if (-1 < (short)puVar44[(ulonglong)(uVar39 - 1) + 1]) break;
              lVar37 = *(longlong *)(psVar57 + 4);
              lVar26 = (ulonglong)*(uint *)(psVar57 + 10) + lVar37;
              uVar40 = (uint)uVar39;
              if (uVar40 == 1) {
                uVar48 = *(uint *)(psVar57 + 0xc);
                uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar40 * 2);
                uVar40 = uVar48;
LAB_:
                if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
              }
              else {
                uVar48 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                uVar40 = *(uint *)(psVar57 + 0xc);
                uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                if (uVar40 <= uVar48) goto LAB_;
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x10c1e4;
                func_0x(lVar37,7);
                uVar40 = *(uint *)(psVar57 + 0xc);
                lVar37 = *(longlong *)(psVar57 + 4);
              }
              if ((uVar48 < uVar40) || (*(uint *)(psVar57 + 2) < uVar48)) goto LAB_;
              if (*(ushort *)(lVar37 + (ulonglong)uVar48) == 5) {
                *puVar55 = *puVar55 | 2;
                psVar57[0xe] = psVar57[0xe] + -1;
                psVar57[0x15] = (short)uVar48;
                lVar37 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(psVar57 + 4);
                uVar39 = psVar57[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar37 + 2) & 0x4000) != 0) {
                  uVar39 = *(ushort *)(lVar37 + 2) & 0x3800 | psVar57[0x16] & 0xc7ffU;
                }
                psVar57[0x16] = uVar39;
                psVar57[0x16] = (uVar39 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar39;
                break;
              }
              if (*(ushort *)(lVar37 + (ulonglong)uVar48) < 0x400) break;
              *puVar55 = *puVar55 | 1;
              psVar49 = psVar57 + 0xe;
              *psVar49 = *psVar49 + -1;
            } while (*psVar49 != 0);
          }
          iVar21 = 0;
          if ((**(byte **)(psVar57 + 4) & 0x40) == 0) {
            *(undefined4 *)(psVar57 + 0x13) = 0;
          }
          else {
            *(int *)(psVar57 + 0x13) = *(int *)(psVar57 + 2);
            *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + 0xe;
            *(undefined8 *)(puVar43 + -8) = 0x10c2c5;
            puVar27 = (ulonglong *)func_0x(puVar55);
            uVar41 = *puVar27;
            *(ulonglong *)(&stack0x00000238 + lVar23) = uVar41;
            uVar35 = (ushort)(uVar41 >> 0x30);
            uVar39 = uVar35;
            if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
              uVar39 = uVar35 & 0xdfff;
              if ((uVar41 & 0x4000000000000000) != 0) {
                uVar39 = uVar35 | 0x2000;
              }
            }
            if (uVar39 == 0xfffc) {
              iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + iVar21;
          }
          uVar40 = *(uint *)(psVar57 + 2);
          if ((*(ulonglong *)(psVar57 + 0xf) != 0) &&
             (*(ulonglong *)(psVar57 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar57 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar37 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8), lVar37 != 0 &&
                 (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                (*(char *)(lVar37 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x10c3c0;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x10c3e6;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
              }
            }
            uVar25 = *(undefined8 *)(psVar57 + 4);
            *(undefined8 *)(puVar43 + -8) = 0x10c3f4;
            func_0x(uVar25,0x12);
            uVar40 = *(uint *)(psVar57 + 2);
          }
          if (0x3f3b < uVar40 - 1) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar37 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar37 != 0 &&
                ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                 (*(char *)(lVar37 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x10c47f;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x10c4a5;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
              }
            }
            uVar25 = *(undefined8 *)(psVar57 + 4);
            *(undefined8 *)(puVar43 + -8) = 0x10c4b3;
            func_0x(uVar25,5);
          }
        }
LAB_:
        uVar40 = *(uint *)(psVar57 + 2);
        *(uint *)(&stack0x00000044 + lVar23) = uVar40;
        if (uVar40 < 9) {
          bVar34 = **(byte **)(psVar57 + 4);
          if (((bVar34 & 0xe) != 0) && ((bVar34 & 0xe) != 0xc)) goto LAB_;
          uVar40 = 9;
          *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
        }
        else {
LAB_:
          bVar34 = **(byte **)(psVar57 + 4);
        }
        if ((bVar34 & 0x40) != 0) {
          uVar40 = *(uint *)(psVar57 + 0x13);
LAB_:
          *(uint *)(&stack0x00000044 + lVar23) = uVar40;
        }
      }
      else {
        uVar40 = *(uint *)(psVar57 + 2);
        *(uint *)(&stack0x00000044 + lVar23) = uVar40;
        if (uVar40 == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x10c4fd;
          func_0x(puVar55);
          uVar40 = *(uint *)(psVar57 + 2);
          *(uint *)(&stack0x00000044 + lVar23) = uVar40;
          if (uVar40 == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x10c50f;
            func_0x(puVar55);
            uVar40 = *(uint *)(psVar57 + 2);
            *(uint *)(&stack0x00000044 + lVar23) = uVar40;
          }
        }
        if (uVar40 < 9) {
          bVar34 = **(byte **)(psVar57 + 4);
          if (((bVar34 & 0x1c) != 0) && ((bVar34 & 0x1c) != 0xc)) goto LAB_;
          uVar40 = 9;
          *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
        }
        else {
LAB_:
          bVar34 = **(byte **)(psVar57 + 4);
        }
        if ((bVar34 & 2) != 0) {
          uVar40 = *(uint *)(psVar57 + 0x18);
          goto LAB_;
        }
      }
      pcVar8 = *(code **)*plVar51;
      *(undefined8 *)(puVar43 + -8) = 0x10c552;
      cVar18 = (*pcVar8)(plVar51);
      if (cVar18 == '\0') {
        if (((&stack0x00000388)[lVar23] & 1) == 0) {
LAB_:
          *(undefined8 *)(puVar43 + -8) = 0x10cba1;
          lVar37 = func_0x(plVar51);
          if (((&stack0x00000390)[lVar23] & 1) == 0) {
            pcVar8 = *(code **)*plVar51;
            *(undefined8 *)(puVar43 + -8) = 0x10cbba;
            cVar18 = (*pcVar8)(plVar51);
            if (cVar18 == '\0') {
              pcVar8 = *(code **)(*plVar51 + 0x88);
              *(undefined8 *)(puVar43 + -8) = 0x10cbcf;
              cVar18 = (*pcVar8)(plVar51);
              if (cVar18 != '\0') {
                if ((&stack0x00000391)[lVar23] != '\0') goto LAB_;
                if (lVar37 == 0) {
                  pcVar8 = *(code **)(*plVar51 + 0x18);
                  *(undefined8 *)(puVar43 + -8) = 0x10cbf3;
                  cVar18 = (*pcVar8)(plVar51);
                  if (cVar18 == '\0') goto LAB_;
                }
                if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
                  if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
                    if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                      *(undefined8 *)(puVar43 + -8) = 0x10cc29;
                      lVar26 = func_0x(plVar51);
                      if (lVar26 == 0) {
                        pcVar8 = *(code **)(*plVar51 + 0x88);
                        *(undefined8 *)(puVar43 + -8) = 0x10cc3b;
                        cVar18 = (*pcVar8)(plVar51);
                        if (cVar18 != '\0') {
                          pcVar8 = *(code **)(*plVar51 + 0x18);
                          *(undefined8 *)(puVar43 + -8) = 0x10cc49;
                          cVar18 = (*pcVar8)(plVar51);
                          if (cVar18 == '\0') {
                            *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                            goto LAB_;
                          }
                        }
                      }
                      lVar26 = plVar51[6];
                      *(undefined8 *)(puVar43 + -8) = 0x10cc63;
                      func_0x(lVar26);
                      *(undefined8 *)(puVar43 + -8) = 0x10cc6b;
                      iVar21 = func_0x(plVar51);
                      if (iVar21 == 0) {
                        pcVar8 = *(code **)(*plVar51 + 0x270);
                        *(undefined8 *)(puVar43 + -8) = 0x10cc7c;
                        (*pcVar8)(plVar51);
                      }
                      if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                        if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                          *(undefined8 *)(puVar43 + -8) = 0x10ccb3;
                          uVar25 = func_0x(plVar51);
                          *(undefined8 *)(puVar43 + -8) = 0x10ccbb;
                          cVar18 = func_0x(uVar25);
                          if (cVar18 != '\0') {
                            *(undefined8 *)(puVar43 + -8) = 0x10ccc7;
                            uVar25 = func_0x(plVar51);
                            *(undefined8 *)(puVar43 + -8) = 0x10cccf;
                            cVar18 = func_0x(uVar25);
                            if ((cVar18 != '\0') && (*_DAT_ != '\0')) {
                              *(undefined8 *)(puVar43 + -8) = 0x10cce4;
                              uVar25 = func_0x();
                              *(undefined8 *)(puVar43 + 0x20) = 0;
                              *(undefined8 *)(puVar43 + -8) = 0x10ccfe;
                              func_0x(uVar25,0x1c,0x10,1);
                            }
                          }
                        }
                        uVar48 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                      }
                      else {
                        pcVar8 = *(code **)(*plVar51 + 0x1e8);
                        *(undefined8 *)(puVar43 + -8) = 0x10cc93;
                        uVar25 = (*pcVar8)(plVar51);
                        *(undefined8 *)(puVar43 + -8) = 0x10cc9b;
                        uVar48 = func_0x(uVar25);
                      }
                      if (uVar48 != 0) goto LAB_;
                    }
                  }
                  else {
LAB_:
                    if (((*(byte *)(plVar51 + 0x4a) & 0x40) != 0) &&
                       ((&stack0x00000392)[lVar23] != '\0')) goto LAB_;
                  }
                }
              }
LAB_:
              if (((&stack0x00000390)[lVar23] & 0x1c) != 0) goto LAB_;
              if (*(longlong *)(&stack0x00000398 + lVar23) != 0) {
                *(undefined8 *)(puVar43 + -8) = 0x10cd4b;
                iVar21 = func_0x();
                if (iVar21 != 0) {
                  uVar25 = *(undefined8 *)(&stack0x00000398 + lVar23);
                  *(undefined8 *)(puVar43 + -8) = 0x10cd5b;
                  iVar21 = func_0x(uVar25);
                  if (iVar21 != 0) {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x10cd85;
                    (*_DAT_)(1,0x1a263c0,0x1a26410,0x116);
                  }
                }
                uVar25 = *(undefined8 *)(&stack0x00000398 + lVar23);
                *(undefined8 *)(puVar43 + -8) = 0x10cd96;
                iVar21 = func_0x(uVar25);
                if (iVar21 != 0) {
                  uVar25 = *(undefined8 *)(&stack0x00000398 + lVar23);
                  *(undefined8 *)(puVar43 + -8) = 0x10cda6;
                  iVar21 = func_0x(uVar25);
                  if (iVar21 == 0) {
                    uVar25 = *(undefined8 *)(&stack0x00000398 + lVar23);
                    *(undefined8 *)(puVar43 + -8) = 0x10cdb6;
                    iVar21 = func_0x(uVar25);
                    if (iVar21 != 0) {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x10cdde;
                      (*_DAT_)(1,0x1a26440,0x1a26410,0x119);
                    }
                  }
                }
              }
              if (lVar37 == 0) {
LAB_:
                if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
                  if ((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0) {
LAB_:
                    if (lVar37 != 0) goto LAB_;
                    goto LAB_;
                  }
                  if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                    *(undefined8 *)(puVar43 + -8) = 0x10ce19;
                    lVar26 = func_0x(plVar51);
                    if (lVar26 == 0) {
                      pcVar8 = *(code **)(*plVar51 + 0x88);
                      *(undefined8 *)(puVar43 + -8) = 0x10ce2f;
                      cVar18 = (*pcVar8)(plVar51);
                      if (cVar18 != '\0') {
                        pcVar8 = *(code **)(*plVar51 + 0x18);
                        *(undefined8 *)(puVar43 + -8) = 0x10ce41;
                        cVar18 = (*pcVar8)(plVar51);
                        if (cVar18 == '\0') {
                          *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                          goto LAB_;
                        }
                      }
                    }
                    lVar26 = plVar51[6];
                    *(undefined8 *)(puVar43 + -8) = 0x10cf63;
                    func_0x(lVar26);
                    *(undefined8 *)(puVar43 + -8) = 0x10cf6b;
                    iVar21 = func_0x(plVar51);
                    if (iVar21 == 0) {
                      pcVar8 = *(code **)(*plVar51 + 0x270);
                      *(undefined8 *)(puVar43 + -8) = 0x10cf7c;
                      (*pcVar8)(plVar51);
                    }
                    if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                      if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                        *(undefined8 *)(puVar43 + -8) = 0x10cfb3;
                        uVar25 = func_0x(plVar51);
                        *(undefined8 *)(puVar43 + -8) = 0x10cfbb;
                        cVar18 = func_0x(uVar25);
                        if (cVar18 != '\0') {
                          *(undefined8 *)(puVar43 + -8) = 0x10cfc7;
                          uVar25 = func_0x(plVar51);
                          *(undefined8 *)(puVar43 + -8) = 0x10cfcf;
                          cVar18 = func_0x(uVar25);
                          if ((cVar18 != '\0') && (*_DAT_ != '\0')) {
                            *(undefined8 *)(puVar43 + -8) = 0x10cfe4;
                            uVar25 = func_0x();
                            *(undefined8 *)(puVar43 + 0x20) = 0;
                            *(undefined8 *)(puVar43 + -8) = 0x10cffe;
                            func_0x(uVar25,0x1c,0x10,1);
                          }
                        }
                      }
                      uVar48 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                    }
                    else {
                      pcVar8 = *(code **)(*plVar51 + 0x1e8);
                      *(undefined8 *)(puVar43 + -8) = 0x10cf93;
                      uVar25 = (*pcVar8)(plVar51);
                      *(undefined8 *)(puVar43 + -8) = 0x10cf9b;
                      uVar48 = func_0x(uVar25);
                    }
                    if (uVar48 != 0) goto LAB_;
                  }
                }
              }
              else {
                *(undefined8 *)(puVar43 + -8) = 0x10cdeb;
                cVar18 = func_0x(lVar37);
                if (cVar18 == '\0') goto LAB_;
LAB_:
                if (((&stack0x00000390)[lVar23] & 0x1c) == 0) {
                  if (*(longlong *)(&stack0x00000398 + lVar23) != 0) {
                    *(undefined8 *)(puVar43 + -8) = 0x10d041;
                    iVar21 = func_0x();
                    if (iVar21 != 0) {
                      uVar25 = *(undefined8 *)(&stack0x00000398 + lVar23);
                      *(undefined8 *)(puVar43 + -8) = 0x10d051;
                      iVar21 = func_0x(uVar25);
                      if (iVar21 != 0) {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10d07b;
                        (*_DAT_)(1,0x1a263c0,0x1a26410,0x116);
                      }
                    }
                    uVar25 = *(undefined8 *)(&stack0x00000398 + lVar23);
                    *(undefined8 *)(puVar43 + -8) = 0x10d08c;
                    iVar21 = func_0x(uVar25);
                    if (iVar21 != 0) {
                      uVar25 = *(undefined8 *)(&stack0x00000398 + lVar23);
                      *(undefined8 *)(puVar43 + -8) = 0x10d09c;
                      iVar21 = func_0x(uVar25);
                      if (iVar21 == 0) {
                        uVar25 = *(undefined8 *)(&stack0x00000398 + lVar23);
                        *(undefined8 *)(puVar43 + -8) = 0x10d0ac;
                        iVar21 = func_0x(uVar25);
                        if (iVar21 != 0) {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x10d0d4;
                          (*_DAT_)(1,0x1a26440,0x1a26410,0x119);
                        }
                      }
                    }
                  }
                  *(undefined8 *)(puVar43 + -8) = 0x10d0dc;
                  cVar18 = func_0x(lVar37);
                  if (cVar18 == '\0') {
                    if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
                      if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
                        if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                          *(undefined8 *)(puVar43 + -8) = 0x10d112;
                          lVar26 = func_0x(plVar51);
                          if (lVar26 == 0) {
                            pcVar8 = *(code **)(*plVar51 + 0x88);
                            *(undefined8 *)(puVar43 + -8) = 0x10d124;
                            cVar18 = (*pcVar8)(plVar51);
                            if (cVar18 != '\0') {
                              pcVar8 = *(code **)(*plVar51 + 0x18);
                              *(undefined8 *)(puVar43 + -8) = 0x10d132;
                              cVar18 = (*pcVar8)(plVar51);
                              if (cVar18 == '\0') {
                                *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                                goto LAB_;
                              }
                            }
                          }
                          lVar26 = plVar51[6];
                          *(undefined8 *)(puVar43 + -8) = 0x10d14c;
                          func_0x(lVar26);
                          *(undefined8 *)(puVar43 + -8) = 0x10d154;
                          iVar21 = func_0x(plVar51);
                          if (iVar21 == 0) {
                            pcVar8 = *(code **)(*plVar51 + 0x270);
                            *(undefined8 *)(puVar43 + -8) = 0x10d165;
                            (*pcVar8)(plVar51);
                          }
                          if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                            if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                              *(undefined8 *)(puVar43 + -8) = 0x10d19c;
                              uVar25 = func_0x(plVar51);
                              *(undefined8 *)(puVar43 + -8) = 0x10d1a4;
                              cVar18 = func_0x(uVar25);
                              if (cVar18 != '\0') {
                                *(undefined8 *)(puVar43 + -8) = 0x10d1b0;
                                uVar25 = func_0x(plVar51);
                                *(undefined8 *)(puVar43 + -8) = 0x10d1b8;
                                cVar18 = func_0x(uVar25);
                                if ((cVar18 != '\0') && (*_DAT_ != '\0')) {
                                  *(undefined8 *)(puVar43 + -8) = 0x10d1cd;
                                  uVar25 = func_0x();
                                  *(undefined8 *)(puVar43 + 0x20) = 0;
                                  *(undefined8 *)(puVar43 + -8) = 0x10d1e7;
                                  func_0x(uVar25,0x1c,0x10,1);
                                }
                              }
                            }
                            uVar48 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                          }
                          else {
                            pcVar8 = *(code **)(*plVar51 + 0x1e8);
                            *(undefined8 *)(puVar43 + -8) = 0x10d17c;
                            uVar25 = (*pcVar8)(plVar51);
                            *(undefined8 *)(puVar43 + -8) = 0x10d184;
                            uVar48 = func_0x(uVar25);
                          }
                          if (uVar48 != 0) goto LAB_;
                        }
                      }
                      else {
LAB_:
                        if ((*(byte *)(plVar51 + 0x4a) & 0x10) != 0) goto LAB_;
                      }
                    }
LAB_:
                    if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
                      if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
                        if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                          *(undefined8 *)(puVar43 + -8) = 0x10d237;
                          lVar26 = func_0x(plVar51);
                          if (lVar26 == 0) {
                            pcVar8 = *(code **)(*plVar51 + 0x88);
                            *(undefined8 *)(puVar43 + -8) = 0x10d249;
                            cVar18 = (*pcVar8)(plVar51);
                            if (cVar18 != '\0') {
                              pcVar8 = *(code **)(*plVar51 + 0x18);
                              *(undefined8 *)(puVar43 + -8) = 0x10d257;
                              cVar18 = (*pcVar8)(plVar51);
                              if (cVar18 == '\0') {
                                *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                                goto LAB_;
                              }
                            }
                          }
                          lVar26 = plVar51[6];
                          *(undefined8 *)(puVar43 + -8) = 0x10d271;
                          func_0x(lVar26);
                          *(undefined8 *)(puVar43 + -8) = 0x10d279;
                          iVar21 = func_0x(plVar51);
                          if (iVar21 == 0) {
                            pcVar8 = *(code **)(*plVar51 + 0x270);
                            *(undefined8 *)(puVar43 + -8) = 0x10d28a;
                            (*pcVar8)(plVar51);
                          }
                          if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                            if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                              *(undefined8 *)(puVar43 + -8) = 0x10d2c1;
                              uVar25 = func_0x(plVar51);
                              *(undefined8 *)(puVar43 + -8) = 0x10d2c9;
                              cVar18 = func_0x(uVar25);
                              if (cVar18 != '\0') {
                                *(undefined8 *)(puVar43 + -8) = 0x10d2d5;
                                uVar25 = func_0x(plVar51);
                                *(undefined8 *)(puVar43 + -8) = 0x10d2dd;
                                cVar18 = func_0x(uVar25);
                                if ((cVar18 != '\0') && (*_DAT_ != '\0')) {
                                  *(undefined8 *)(puVar43 + -8) = 0x10d2f2;
                                  uVar25 = func_0x();
                                  *(undefined8 *)(puVar43 + 0x20) = 0;
                                  *(undefined8 *)(puVar43 + -8) = 0x10d30c;
                                  func_0x(uVar25,0x1c,0x10,1);
                                }
                              }
                            }
                            uVar48 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                          }
                          else {
                            pcVar8 = *(code **)(*plVar51 + 0x1e8);
                            *(undefined8 *)(puVar43 + -8) = 0x10d2a1;
                            uVar25 = (*pcVar8)(plVar51);
                            *(undefined8 *)(puVar43 + -8) = 0x10d2a9;
                            uVar48 = func_0x(uVar25);
                          }
                          if (uVar48 != 0) goto LAB_;
                        }
                      }
                      else {
LAB_:
                        if ((*(byte *)(plVar51 + 0x4a) & 0x40) != 0) goto LAB_;
                      }
                    }
                  }
                }
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x10d334;
                func_0x(lVar37,0);
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x10d33c;
                iVar21 = func_0x(plVar51);
                if (iVar21 == 0) {
                  pcVar8 = *(code **)(*plVar51 + 0x270);
                  *(undefined8 *)(puVar43 + -8) = 0x10d34d;
                  (*pcVar8)(plVar51);
                }
                *(undefined8 *)(puVar43 + -8) = 0x10d355;
                lVar37 = func_0x(plVar51);
                if (((&stack0x00000390)[lVar23] & 0x24) != 0) {
LAB_:
                  *(undefined8 *)(puVar43 + -8) = 0x10d49f;
                  iVar21 = func_0x(psVar57);
                  if (iVar21 != 0) {
                    *(undefined8 *)(puVar43 + -8) = 0x10d4b2;
                    func_0x(psVar57,&stack0x00000248 + lVar23);
                    uVar48 = 0;
                    uVar39 = *(ushort *)(&stack0x0000024e + lVar23);
                    uVar35 = uVar39;
                    if ((((uint)(int)(short)uVar39 >> 1 ^ (int)(short)uVar39) & 0x2000) != 0) {
                      uVar35 = uVar39 & 0xdfff;
                      if ((uVar39 >> 0xe & 1) != 0) {
                        uVar35 = uVar39 | 0x2000;
                      }
                    }
                    if (uVar35 == 0xfffc) {
                      uVar48 = (uint)(*(ushort *)(&stack0x0000024c + lVar23) >> 5);
                    }
                    uVar40 = uVar40 + uVar48;
                  }
                  *(undefined8 *)(puVar43 + -8) = 0x10d50d;
                  lVar37 = func_0x(plVar51);
                  pcVar8 = *(code **)(*plVar51 + 0x88);
                  *(undefined8 *)(puVar43 + -8) = 0x10d51d;
                  cVar18 = (*pcVar8)(plVar51);
                  if ((cVar18 == '\0') && (lVar37 != 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10d52e;
                    cVar18 = func_0x(lVar37);
                    if ((cVar18 != '\0') && (uVar40 < 0x1f74)) {
                      uVar40 = uVar40 + 8;
                    }
                  }
                  *(uint *)(&stack0x00000044 + lVar23) = uVar40 + 0xe;
                  uVar36 = *(undefined4 *)(&stack0x00000028 + lVar23);
                  uVar25 = *(undefined8 *)(&stack0x00000058 + lVar23);
                  bVar38 = 0;
                  goto LAB_;
                }
                if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
                  if ((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0) goto LAB_;
                  if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                    *(undefined8 *)(puVar43 + -8) = 0x10d395;
                    lVar26 = func_0x(plVar51);
                    if (lVar26 == 0) {
                      pcVar8 = *(code **)(*plVar51 + 0x88);
                      *(undefined8 *)(puVar43 + -8) = 0x10d3a7;
                      cVar18 = (*pcVar8)(plVar51);
                      if (cVar18 != '\0') {
                        pcVar8 = *(code **)(*plVar51 + 0x18);
                        *(undefined8 *)(puVar43 + -8) = 0x10d3b5;
                        cVar18 = (*pcVar8)(plVar51);
                        if (cVar18 == '\0') {
                          *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                          goto LAB_;
                        }
                      }
                    }
                    lVar26 = plVar51[6];
                    *(undefined8 *)(puVar43 + -8) = 0x10d3cf;
                    func_0x(lVar26);
                    *(undefined8 *)(puVar43 + -8) = 0x10d3d7;
                    iVar21 = func_0x(plVar51);
                    if (iVar21 == 0) {
                      pcVar8 = *(code **)(*plVar51 + 0x270);
                      *(undefined8 *)(puVar43 + -8) = 0x10d3e8;
                      (*pcVar8)(plVar51);
                    }
                    if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                      if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                        *(undefined8 *)(puVar43 + -8) = 0x10d41f;
                        uVar25 = func_0x(plVar51);
                        *(undefined8 *)(puVar43 + -8) = 0x10d427;
                        cVar18 = func_0x(uVar25);
                        if (cVar18 != '\0') {
                          *(undefined8 *)(puVar43 + -8) = 0x10d433;
                          uVar25 = func_0x(plVar51);
                          *(undefined8 *)(puVar43 + -8) = 0x10d43b;
                          cVar18 = func_0x(uVar25);
                          if ((cVar18 != '\0') && (*_DAT_ != '\0')) {
                            *(undefined8 *)(puVar43 + -8) = 0x10d450;
                            uVar25 = func_0x();
                            *(undefined8 *)(puVar43 + 0x20) = 0;
                            *(undefined8 *)(puVar43 + -8) = 0x10d46a;
                            func_0x(uVar25,0x1c,0x10,1);
                          }
                        }
                      }
                      uVar48 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                    }
                    else {
                      pcVar8 = *(code **)(*plVar51 + 0x1e8);
                      *(undefined8 *)(puVar43 + -8) = 0x10d3ff;
                      uVar25 = (*pcVar8)(plVar51);
                      *(undefined8 *)(puVar43 + -8) = 0x10d407;
                      uVar48 = func_0x(uVar25);
                    }
                    if (uVar48 != 0) goto LAB_;
                  }
                }
LAB_:
                if (lVar37 != 0) {
                  *(undefined8 *)(puVar43 + -8) = 0x10d48f;
                  cVar18 = func_0x(lVar37);
                  if (cVar18 != '\0') goto LAB_;
                }
              }
            }
          }
        }
        else {
          pcVar8 = *(code **)(*plVar51 + 0x88);
          *(undefined8 *)(puVar43 + -8) = 0x10cb83;
          cVar18 = (*pcVar8)(plVar51);
          if (cVar18 == '\0') goto LAB_;
          pcVar8 = *(code **)(*plVar51 + 0x18);
          *(undefined8 *)(puVar43 + -8) = 0x10cb91;
          cVar18 = (*pcVar8)(plVar51);
          if (cVar18 != '\0') goto LAB_;
        }
LAB_:
        *(undefined8 *)(puVar43 + -8) = 0x10ce59;
        iVar21 = func_0x(psVar57);
        if (iVar21 != 0) {
          if (*psVar57 != 0) goto LAB_;
          if (*(int *)(psVar57 + 2) == 0) {
            *puVar55 = 0;
            uVar40 = *(uint *)(psVar57 + 8);
            uVar41 = (ulonglong)uVar40;
            *(uint *)(psVar57 + 10) = uVar40;
            pbVar3 = *(byte **)(psVar57 + 4);
            bVar34 = *pbVar3;
            if ((bVar34 & 0x10) != 0) {
              uVar40 = uVar40 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3) + 2;
              uVar41 = (ulonglong)uVar40;
              *(uint *)(psVar57 + 10) = uVar40;
              bVar34 = *pbVar3;
            }
            if ((bVar34 & 0x20) == 0) {
              *(int *)(psVar57 + 2) = (int)uVar41;
              psVar57[0xe] = 0;
              *(uint *)(psVar57 + 0xc) = uVar40;
            }
            else {
              puVar44 = (ushort *)(pbVar3 + uVar41);
              uVar39 = *puVar44;
              psVar57[0xe] = uVar39;
              if (uVar39 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10cf55;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x10d576;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                  }
                }
                uVar25 = *(undefined8 *)(psVar57 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x10d584;
                func_0x(uVar25,3);
                uVar39 = psVar57[0xe];
              }
              uVar40 = *(int *)(psVar57 + 10) + (uVar39 + 1) * 2;
              *(uint *)(psVar57 + 0xc) = uVar40;
              if (0x1f9e < uVar40) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                    ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                     (*(char *)(lVar37 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10d61c;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x10d642;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                  }
                }
                uVar25 = *(undefined8 *)(psVar57 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x10d650;
                func_0x(uVar25,4);
              }
              uVar39 = puVar44[(ushort)psVar57[0xe]];
              *(uint *)(psVar57 + 2) = uVar39 & 0x7fff;
              if ((uVar39 & 0x7fff) < *(uint *)(psVar57 + 0xc)) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10d6e4;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x10d70a;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                  }
                }
                uVar25 = *(undefined8 *)(psVar57 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x10d718;
                func_0x(uVar25,4);
              }
              do {
                uVar39 = psVar57[0xe];
                if (-1 < (short)puVar44[(ulonglong)(uVar39 - 1) + 1]) break;
                lVar37 = *(longlong *)(psVar57 + 4);
                lVar26 = (ulonglong)*(uint *)(psVar57 + 10) + lVar37;
                uVar40 = (uint)uVar39;
                if (uVar40 == 1) {
                  uVar48 = *(uint *)(psVar57 + 0xc);
                  uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar40 * 2);
                  uVar40 = uVar48;
LAB_:
                  if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
                }
                else {
                  uVar48 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                  uVar40 = *(uint *)(psVar57 + 0xc);
                  uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                  if (uVar40 <= uVar48) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar43 + -8) = 0x10d784;
                  func_0x(lVar37,7);
                  uVar40 = *(uint *)(psVar57 + 0xc);
                }
                if ((uVar48 < uVar40) || (*(uint *)(psVar57 + 2) < uVar48)) goto LAB_;
                if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar57 + 4)) == 5) {
                  *puVar55 = *puVar55 | 2;
                  psVar57[0xe] = psVar57[0xe] + -1;
                  psVar57[0x15] = (short)uVar48;
                  lVar37 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(psVar57 + 4);
                  uVar39 = psVar57[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar37 + 2) & 0x4000) != 0) {
                    uVar39 = *(ushort *)(lVar37 + 2) & 0x3800 | psVar57[0x16] & 0xc7ffU;
                  }
                  psVar57[0x16] = uVar39;
                  psVar57[0x16] = (uVar39 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar39;
                  break;
                }
                if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar57 + 4)) < 0x400) break;
                *puVar55 = *puVar55 | 1;
                psVar49 = psVar57 + 0xe;
                *psVar49 = *psVar49 + -1;
              } while (*psVar49 != 0);
            }
            iVar21 = 0;
            if ((**(byte **)(psVar57 + 4) & 0x40) == 0) {
              *(undefined4 *)(psVar57 + 0x13) = 0;
            }
            else {
              *(int *)(psVar57 + 0x13) = *(int *)(psVar57 + 2);
              *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + 0xe;
              *(undefined8 *)(puVar43 + -8) = 0x10d867;
              puVar27 = (ulonglong *)func_0x(puVar55);
              uVar41 = *puVar27;
              *(ulonglong *)(&stack0x00000250 + lVar23) = uVar41;
              uVar35 = (ushort)(uVar41 >> 0x30);
              uVar39 = uVar35;
              if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                uVar39 = uVar35 & 0xdfff;
                if ((uVar41 & 0x4000000000000000) != 0) {
                  uVar39 = uVar35 | 0x2000;
                }
              }
              if (uVar39 == 0xfffc) {
                iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + iVar21;
            }
            uVar40 = *(uint *)(psVar57 + 2);
            if ((*(ulonglong *)(psVar57 + 0xf) != 0) &&
               (*(ulonglong *)(psVar57 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar57 + 4))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar37 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                   (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10d963;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10d989;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x10d997;
              func_0x(uVar25,0x12);
              uVar40 = *(uint *)(psVar57 + 2);
            }
            if (0x3f3b < uVar40 - 1) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10da22;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10da48;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x10da56;
              func_0x(uVar25,5);
            }
          }
LAB_:
          uVar40 = *(uint *)(psVar57 + 2);
          *(uint *)(&stack0x00000044 + lVar23) = uVar40;
          if (uVar40 < 9) {
            if ((**(byte **)(psVar57 + 4) & 0xe) != 0) {
              bVar59 = (**(byte **)(psVar57 + 4) & 0xe) == 0xc;
              goto LAB_;
            }
            goto LAB_;
          }
        }
      }
      else if (*psVar57 == 0) {
        if (*(int *)(psVar57 + 2) == 0) {
          *puVar55 = 0;
          uVar40 = *(uint *)(psVar57 + 8);
          uVar41 = (ulonglong)uVar40;
          *(uint *)(psVar57 + 10) = uVar40;
          pbVar3 = *(byte **)(psVar57 + 4);
          bVar34 = *pbVar3;
          if ((bVar34 & 0x10) != 0) {
            uVar40 = uVar40 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3) + 2;
            uVar41 = (ulonglong)uVar40;
            *(uint *)(psVar57 + 10) = uVar40;
            bVar34 = *pbVar3;
          }
          if ((bVar34 & 0x20) == 0) {
            *(int *)(psVar57 + 2) = (int)uVar41;
            psVar57[0xe] = 0;
            *(uint *)(psVar57 + 0xc) = uVar40;
          }
          else {
            puVar44 = (ushort *)(pbVar3 + uVar41);
            uVar39 = *puVar44;
            psVar57[0xe] = uVar39;
            if (uVar39 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10c63a;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10c660;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x10c66e;
              func_0x(uVar25,3);
              uVar39 = psVar57[0xe];
            }
            uVar40 = *(int *)(psVar57 + 10) + (uVar39 + 1) * 2;
            *(uint *)(psVar57 + 0xc) = uVar40;
            if (0x1f9e < uVar40) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10c706;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10c72c;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x10c73a;
              func_0x(uVar25,4);
            }
            uVar39 = puVar44[(ushort)psVar57[0xe]];
            *(uint *)(psVar57 + 2) = uVar39 & 0x7fff;
            if ((uVar39 & 0x7fff) < *(uint *)(psVar57 + 0xc)) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10c7ce;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10c7f4;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x10c802;
              func_0x(uVar25,4);
            }
            do {
              uVar39 = psVar57[0xe];
              if (-1 < (short)puVar44[(ulonglong)(uVar39 - 1) + 1]) break;
              lVar37 = *(longlong *)(psVar57 + 4);
              lVar26 = (ulonglong)*(uint *)(psVar57 + 10) + lVar37;
              uVar40 = (uint)uVar39;
              if (uVar40 == 1) {
                uVar48 = *(uint *)(psVar57 + 0xc);
                uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar40 * 2);
                uVar40 = uVar48;
LAB_:
                if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
              }
              else {
                uVar48 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                uVar40 = *(uint *)(psVar57 + 0xc);
                uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                if (uVar40 <= uVar48) goto LAB_;
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x10c874;
                func_0x(lVar37,7);
                uVar40 = *(uint *)(psVar57 + 0xc);
              }
              if ((uVar48 < uVar40) || (*(uint *)(psVar57 + 2) < uVar48)) goto LAB_;
              if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar57 + 4)) == 5) {
                *puVar55 = *puVar55 | 2;
                psVar57[0xe] = psVar57[0xe] + -1;
                psVar57[0x15] = (short)uVar48;
                lVar37 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(psVar57 + 4);
                uVar39 = psVar57[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar37 + 2) & 0x4000) != 0) {
                  uVar39 = *(ushort *)(lVar37 + 2) & 0x3800 | psVar57[0x16] & 0xc7ffU;
                }
                psVar57[0x16] = uVar39;
                psVar57[0x16] = (uVar39 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar39;
                break;
              }
              if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar57 + 4)) < 0x400) break;
              *puVar55 = *puVar55 | 1;
              psVar49 = psVar57 + 0xe;
              *psVar49 = *psVar49 + -1;
            } while (*psVar49 != 0);
          }
          iVar21 = 0;
          if ((**(byte **)(psVar57 + 4) & 0x40) == 0) {
            *(undefined4 *)(psVar57 + 0x13) = 0;
          }
          else {
            *(int *)(psVar57 + 0x13) = *(int *)(psVar57 + 2);
            *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + 0xe;
            *(undefined8 *)(puVar43 + -8) = 0x10c957;
            puVar27 = (ulonglong *)func_0x(puVar55);
            uVar41 = *puVar27;
            *(ulonglong *)(&stack0x00000240 + lVar23) = uVar41;
            uVar35 = (ushort)(uVar41 >> 0x30);
            uVar39 = uVar35;
            if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
              uVar39 = uVar35 & 0xdfff;
              if ((uVar41 & 0x4000000000000000) != 0) {
                uVar39 = uVar35 | 0x2000;
              }
            }
            if (uVar39 == 0xfffc) {
              iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + iVar21;
          }
          uVar40 = *(uint *)(psVar57 + 2);
          if ((*(ulonglong *)(psVar57 + 0xf) != 0) &&
             (*(ulonglong *)(psVar57 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar57 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar37 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8), lVar37 != 0 &&
                 (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                (*(char *)(lVar37 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x10ca53;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x10ca79;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
              }
            }
            uVar25 = *(undefined8 *)(psVar57 + 4);
            *(undefined8 *)(puVar43 + -8) = 0x10ca87;
            func_0x(uVar25,0x12);
            uVar40 = *(uint *)(psVar57 + 2);
          }
          if (0x3f3b < uVar40 - 1) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar37 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar37 != 0 &&
                ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                 (*(char *)(lVar37 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x10cb12;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x10cb38;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
              }
            }
            uVar25 = *(undefined8 *)(psVar57 + 4);
            *(undefined8 *)(puVar43 + -8) = 0x10cb46;
            func_0x(uVar25,5);
          }
        }
LAB_:
        uVar40 = *(uint *)(psVar57 + 2);
        *(uint *)(&stack0x00000044 + lVar23) = uVar40;
        if (uVar40 < 9) {
          if ((**(byte **)(psVar57 + 4) & 0xe) != 0) {
            bVar59 = (**(byte **)(psVar57 + 4) & 0xe) == 0xc;
LAB_:
            if (!bVar59) goto LAB_;
          }
LAB_:
          *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
        }
      }
      else {
LAB_:
        uVar40 = *(uint *)(psVar57 + 2);
        *(uint *)(&stack0x00000044 + lVar23) = uVar40;
        if (uVar40 == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x10da84;
          func_0x(puVar55);
          uVar40 = *(uint *)(psVar57 + 2);
          *(uint *)(&stack0x00000044 + lVar23) = uVar40;
        }
        if (uVar40 < 9) {
          if ((**(byte **)(psVar57 + 4) & 0x1c) != 0) {
            bVar59 = (**(byte **)(psVar57 + 4) & 0x1c) == 0xc;
            goto LAB_;
          }
          goto LAB_;
        }
      }
LAB_:
      uVar36 = *(undefined4 *)(&stack0x00000028 + lVar23);
      uVar25 = *(undefined8 *)(&stack0x00000058 + lVar23);
      bVar38 = 0;
    }
    else if (ppsVar42 == (short **)0x0) {
      *(undefined4 *)(&stack0x000003a8 + lVar23) = uVar36;
      *(undefined4 *)(&stack0x000003ac + lVar23) = uVar7;
      *(undefined4 *)(&stack0x000003b0 + lVar23) = uVar13;
      *(undefined4 *)(&stack0x000003b4 + lVar23) = uVar14;
      *(undefined8 *)(&stack0x000003b8 + lVar23) = uVar25;
      ppsVar53 = ppsVar58;
      if (ppsVar50 != (short **)0x0) {
        ppsVar53 = ppsVar50;
      }
      bVar38 = 0;
      if ((bVar34 & 3) == 0) {
        *(undefined8 *)(puVar43 + -8) = 0x10daec;
        lVar37 = func_0x(plVar51);
        if (((&stack0x000003b0)[lVar23] & 1) == 0) {
          pcVar8 = *(code **)*plVar51;
          *(undefined8 *)(puVar43 + -8) = 0x10db05;
          cVar18 = (*pcVar8)(plVar51);
          if (cVar18 != '\0') goto LAB_;
          pcVar8 = *(code **)(*plVar51 + 0x88);
          *(undefined8 *)(puVar43 + -8) = 0x10db1a;
          cVar18 = (*pcVar8)(plVar51);
          if (cVar18 != '\0') {
            if ((&stack0x000003b1)[lVar23] != '\0') goto LAB_;
            if (lVar37 == 0) {
              pcVar8 = *(code **)(*plVar51 + 0x18);
              *(undefined8 *)(puVar43 + -8) = 0x10db3e;
              cVar18 = (*pcVar8)(plVar51);
              if (cVar18 == '\0') goto LAB_;
            }
            if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
                if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                  *(undefined8 *)(puVar43 + -8) = 0x10db74;
                  lVar26 = func_0x(plVar51);
                  if (lVar26 == 0) {
                    pcVar8 = *(code **)(*plVar51 + 0x88);
                    *(undefined8 *)(puVar43 + -8) = 0x10db86;
                    cVar18 = (*pcVar8)(plVar51);
                    if (cVar18 != '\0') {
                      pcVar8 = *(code **)(*plVar51 + 0x18);
                      *(undefined8 *)(puVar43 + -8) = 0x10db94;
                      cVar18 = (*pcVar8)(plVar51);
                      if (cVar18 == '\0') {
                        *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                        goto LAB_;
                      }
                    }
                  }
                  lVar26 = plVar51[6];
                  *(undefined8 *)(puVar43 + -8) = 0x10dbae;
                  func_0x(lVar26);
                  *(undefined8 *)(puVar43 + -8) = 0x10dbb6;
                  iVar21 = func_0x(plVar51);
                  if (iVar21 == 0) {
                    pcVar8 = *(code **)(*plVar51 + 0x270);
                    *(undefined8 *)(puVar43 + -8) = 0x10dbc7;
                    (*pcVar8)(plVar51);
                  }
                  if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                    if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                      *(undefined8 *)(puVar43 + -8) = 0x10dbfe;
                      uVar25 = func_0x(plVar51);
                      *(undefined8 *)(puVar43 + -8) = 0x10dc06;
                      cVar18 = func_0x(uVar25);
                      if (cVar18 != '\0') {
                        *(undefined8 *)(puVar43 + -8) = 0x10dc12;
                        uVar25 = func_0x(plVar51);
                        *(undefined8 *)(puVar43 + -8) = 0x10dc1a;
                        cVar18 = func_0x(uVar25);
                        if ((cVar18 != '\0') && (*_DAT_ != '\0')) {
                          *(undefined8 *)(puVar43 + -8) = 0x10dc2f;
                          uVar25 = func_0x();
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x10dc49;
                          func_0x(uVar25,0x1c,0x10,1);
                        }
                      }
                    }
                    uVar40 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                  }
                  else {
                    pcVar8 = *(code **)(*plVar51 + 0x1e8);
                    *(undefined8 *)(puVar43 + -8) = 0x10dbde;
                    uVar25 = (*pcVar8)(plVar51);
                    *(undefined8 *)(puVar43 + -8) = 0x10dbe6;
                    uVar40 = func_0x(uVar25);
                  }
                  if (uVar40 != 0) goto LAB_;
                }
              }
              else {
LAB_:
                if (((*(byte *)(plVar51 + 0x4a) & 0x40) != 0) &&
                   ((&stack0x000003b2)[lVar23] != '\0')) goto LAB_;
              }
            }
          }
LAB_:
          if (((&stack0x000003b0)[lVar23] & 0x1c) != 0) goto LAB_;
          if (*(longlong *)(&stack0x000003b8 + lVar23) != 0) {
            *(undefined8 *)(puVar43 + -8) = 0x10dc93;
            iVar21 = func_0x();
            if (iVar21 != 0) {
              uVar25 = *(undefined8 *)(&stack0x000003b8 + lVar23);
              *(undefined8 *)(puVar43 + -8) = 0x10dca3;
              iVar21 = func_0x(uVar25);
              if (iVar21 != 0) {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x10dccb;
                (*_DAT_)(1,0x1a263c0,0x1a26410,0x116);
              }
            }
            uVar25 = *(undefined8 *)(&stack0x000003b8 + lVar23);
            *(undefined8 *)(puVar43 + -8) = 0x10dcd7;
            iVar21 = func_0x(uVar25);
            if (iVar21 != 0) {
              uVar25 = *(undefined8 *)(&stack0x000003b8 + lVar23);
              *(undefined8 *)(puVar43 + -8) = 0x10dce7;
              iVar21 = func_0x(uVar25);
              if (iVar21 == 0) {
                uVar25 = *(undefined8 *)(&stack0x000003b8 + lVar23);
                *(undefined8 *)(puVar43 + -8) = 0x10dcf7;
                iVar21 = func_0x(uVar25);
                if (iVar21 != 0) {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10dd1f;
                  (*_DAT_)(1,0x1a26440,0x1a26410,0x119);
                }
              }
            }
          }
          if (lVar37 == 0) {
LAB_:
            if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0) {
LAB_:
                if (lVar37 != 0) goto LAB_;
                goto LAB_;
              }
              if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                *(undefined8 *)(puVar43 + -8) = 0x10dd62;
                lVar26 = func_0x(plVar51);
                if (lVar26 == 0) {
                  pcVar8 = *(code **)(*plVar51 + 0x88);
                  *(undefined8 *)(puVar43 + -8) = 0x10dd74;
                  cVar18 = (*pcVar8)(plVar51);
                  if (cVar18 != '\0') {
                    pcVar8 = *(code **)(*plVar51 + 0x18);
                    *(undefined8 *)(puVar43 + -8) = 0x10dd82;
                    cVar18 = (*pcVar8)(plVar51);
                    if (cVar18 == '\0') {
                      *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                      goto LAB_;
                    }
                  }
                }
                lVar26 = plVar51[6];
                *(undefined8 *)(puVar43 + -8) = 0x10dd9c;
                func_0x(lVar26);
                *(undefined8 *)(puVar43 + -8) = 0x10dda4;
                iVar21 = func_0x(plVar51);
                if (iVar21 == 0) {
                  pcVar8 = *(code **)(*plVar51 + 0x270);
                  *(undefined8 *)(puVar43 + -8) = 0x10ddb5;
                  (*pcVar8)(plVar51);
                }
                if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                  if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                    *(undefined8 *)(puVar43 + -8) = 0x10ddec;
                    uVar25 = func_0x(plVar51);
                    *(undefined8 *)(puVar43 + -8) = 0x10ddf4;
                    cVar18 = func_0x(uVar25);
                    if (cVar18 != '\0') {
                      *(undefined8 *)(puVar43 + -8) = 0x10de00;
                      uVar25 = func_0x(plVar51);
                      *(undefined8 *)(puVar43 + -8) = 0x10de08;
                      cVar18 = func_0x(uVar25);
                      if ((cVar18 != '\0') && (*_DAT_ != '\0')) {
                        *(undefined8 *)(puVar43 + -8) = 0x10de1d;
                        uVar25 = func_0x();
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10de37;
                        func_0x(uVar25,0x1c,0x10,1);
                      }
                    }
                  }
                  uVar40 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                }
                else {
                  pcVar8 = *(code **)(*plVar51 + 0x1e8);
                  *(undefined8 *)(puVar43 + -8) = 0x10ddcc;
                  uVar25 = (*pcVar8)(plVar51);
                  *(undefined8 *)(puVar43 + -8) = 0x10ddd4;
                  uVar40 = func_0x(uVar25);
                }
                if (uVar40 != 0) goto LAB_;
              }
            }
            goto LAB_;
          }
          *(undefined8 *)(puVar43 + -8) = 0x10dd2c;
          cVar18 = func_0x(lVar37);
          if (cVar18 == '\0') goto LAB_;
LAB_:
          if (((&stack0x000003b0)[lVar23] & 0x1c) == 0) {
            if (*(longlong *)(&stack0x000003b8 + lVar23) != 0) {
              *(undefined8 *)(puVar43 + -8) = 0x10de77;
              iVar21 = func_0x();
              if (iVar21 != 0) {
                uVar25 = *(undefined8 *)(&stack0x000003b8 + lVar23);
                *(undefined8 *)(puVar43 + -8) = 0x10de87;
                iVar21 = func_0x(uVar25);
                if (iVar21 != 0) {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10deaf;
                  (*_DAT_)(1,0x1a263c0,0x1a26410,0x116);
                }
              }
              uVar25 = *(undefined8 *)(&stack0x000003b8 + lVar23);
              *(undefined8 *)(puVar43 + -8) = 0x10debb;
              iVar21 = func_0x(uVar25);
              if (iVar21 != 0) {
                uVar25 = *(undefined8 *)(&stack0x000003b8 + lVar23);
                *(undefined8 *)(puVar43 + -8) = 0x10decb;
                iVar21 = func_0x(uVar25);
                if (iVar21 == 0) {
                  uVar25 = *(undefined8 *)(&stack0x000003b8 + lVar23);
                  *(undefined8 *)(puVar43 + -8) = 0x10dedb;
                  iVar21 = func_0x(uVar25);
                  if (iVar21 != 0) {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x10df03;
                    (*_DAT_)(1,0x1a26440,0x1a26410,0x119);
                  }
                }
              }
            }
            *(undefined8 *)(puVar43 + -8) = 0x10df0b;
            cVar18 = func_0x(lVar37);
            if (cVar18 == '\0') {
              if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
                if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
                  if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                    *(undefined8 *)(puVar43 + -8) = 0x10df41;
                    lVar26 = func_0x(plVar51);
                    if (lVar26 == 0) {
                      pcVar8 = *(code **)(*plVar51 + 0x88);
                      *(undefined8 *)(puVar43 + -8) = 0x10df53;
                      cVar18 = (*pcVar8)(plVar51);
                      if (cVar18 != '\0') {
                        pcVar8 = *(code **)(*plVar51 + 0x18);
                        *(undefined8 *)(puVar43 + -8) = 0x10df61;
                        cVar18 = (*pcVar8)(plVar51);
                        if (cVar18 == '\0') {
                          *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                          goto LAB_;
                        }
                      }
                    }
                    lVar26 = plVar51[6];
                    *(undefined8 *)(puVar43 + -8) = 0x10df7b;
                    func_0x(lVar26);
                    *(undefined8 *)(puVar43 + -8) = 0x10df83;
                    iVar21 = func_0x(plVar51);
                    if (iVar21 == 0) {
                      pcVar8 = *(code **)(*plVar51 + 0x270);
                      *(undefined8 *)(puVar43 + -8) = 0x10df94;
                      (*pcVar8)(plVar51);
                    }
                    if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                      if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                        *(undefined8 *)(puVar43 + -8) = 0x10dfcb;
                        uVar25 = func_0x(plVar51);
                        *(undefined8 *)(puVar43 + -8) = 0x10dfd3;
                        cVar18 = func_0x(uVar25);
                        if (cVar18 != '\0') {
                          *(undefined8 *)(puVar43 + -8) = 0x10dfdf;
                          uVar25 = func_0x(plVar51);
                          *(undefined8 *)(puVar43 + -8) = 0x10dfe7;
                          cVar18 = func_0x(uVar25);
                          if ((cVar18 != '\0') && (*_DAT_ != '\0')) {
                            *(undefined8 *)(puVar43 + -8) = 0x10dffc;
                            uVar25 = func_0x();
                            *(undefined8 *)(puVar43 + 0x20) = 0;
                            *(undefined8 *)(puVar43 + -8) = 0x10e016;
                            func_0x(uVar25,0x1c,0x10,1);
                          }
                        }
                      }
                      uVar40 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                    }
                    else {
                      pcVar8 = *(code **)(*plVar51 + 0x1e8);
                      *(undefined8 *)(puVar43 + -8) = 0x10dfab;
                      uVar25 = (*pcVar8)(plVar51);
                      *(undefined8 *)(puVar43 + -8) = 0x10dfb3;
                      uVar40 = func_0x(uVar25);
                    }
                    if (uVar40 != 0) goto LAB_;
                  }
                }
                else {
LAB_:
                  if ((*(byte *)(plVar51 + 0x4a) & 0x10) != 0) goto LAB_;
                }
              }
LAB_:
              if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
                if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
                  if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                    *(undefined8 *)(puVar43 + -8) = 0x10e063;
                    lVar26 = func_0x(plVar51);
                    if (lVar26 == 0) {
                      pcVar8 = *(code **)(*plVar51 + 0x88);
                      *(undefined8 *)(puVar43 + -8) = 0x10e075;
                      cVar18 = (*pcVar8)(plVar51);
                      if (cVar18 != '\0') {
                        pcVar8 = *(code **)(*plVar51 + 0x18);
                        *(undefined8 *)(puVar43 + -8) = 0x10e083;
                        cVar18 = (*pcVar8)(plVar51);
                        if (cVar18 == '\0') {
                          *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                          goto LAB_;
                        }
                      }
                    }
                    lVar26 = plVar51[6];
                    *(undefined8 *)(puVar43 + -8) = 0x10e09d;
                    func_0x(lVar26);
                    *(undefined8 *)(puVar43 + -8) = 0x10e0a5;
                    iVar21 = func_0x(plVar51);
                    if (iVar21 == 0) {
                      pcVar8 = *(code **)(*plVar51 + 0x270);
                      *(undefined8 *)(puVar43 + -8) = 0x10e0b6;
                      (*pcVar8)(plVar51);
                    }
                    if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                      if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                        *(undefined8 *)(puVar43 + -8) = 0x10e0ed;
                        uVar25 = func_0x(plVar51);
                        *(undefined8 *)(puVar43 + -8) = 0x10e0f5;
                        cVar18 = func_0x(uVar25);
                        if (cVar18 != '\0') {
                          *(undefined8 *)(puVar43 + -8) = 0x10e101;
                          uVar25 = func_0x(plVar51);
                          *(undefined8 *)(puVar43 + -8) = 0x10e109;
                          cVar18 = func_0x(uVar25);
                          if ((cVar18 != '\0') && (*_DAT_ != '\0')) {
                            *(undefined8 *)(puVar43 + -8) = 0x10e11e;
                            uVar25 = func_0x();
                            *(undefined8 *)(puVar43 + 0x20) = 0;
                            *(undefined8 *)(puVar43 + -8) = 0x10e138;
                            func_0x(uVar25,0x1c,0x10,1);
                          }
                        }
                      }
                      uVar40 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                    }
                    else {
                      pcVar8 = *(code **)(*plVar51 + 0x1e8);
                      *(undefined8 *)(puVar43 + -8) = 0x10e0cd;
                      uVar25 = (*pcVar8)(plVar51);
                      *(undefined8 *)(puVar43 + -8) = 0x10e0d5;
                      uVar40 = func_0x(uVar25);
                    }
                    if (uVar40 != 0) goto LAB_;
                  }
                }
                else {
LAB_:
                  if ((*(byte *)(plVar51 + 0x4a) & 0x40) != 0) goto LAB_;
                }
              }
            }
          }
LAB_:
          *(undefined8 *)(puVar43 + -8) = 0x10e15d;
          func_0x(lVar37,0);
LAB_:
          *(undefined8 *)(puVar43 + -8) = 0x10e165;
          iVar21 = func_0x(plVar51);
          if (iVar21 == 0) {
            pcVar8 = *(code **)(*plVar51 + 0x270);
            *(undefined8 *)(puVar43 + -8) = 0x10e176;
            (*pcVar8)(plVar51);
          }
          *(undefined8 *)(puVar43 + -8) = 0x10e17e;
          lVar37 = func_0x(plVar51);
          if (((&stack0x000003b0)[lVar23] & 0x24) == 0) {
            if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0) goto LAB_;
              if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                *(undefined8 *)(puVar43 + -8) = 0x10e1be;
                lVar26 = func_0x(plVar51);
                if (lVar26 == 0) {
                  pcVar8 = *(code **)(*plVar51 + 0x88);
                  *(undefined8 *)(puVar43 + -8) = 0x10e1d0;
                  cVar18 = (*pcVar8)(plVar51);
                  if (cVar18 != '\0') {
                    pcVar8 = *(code **)(*plVar51 + 0x18);
                    *(undefined8 *)(puVar43 + -8) = 0x10e1de;
                    cVar18 = (*pcVar8)(plVar51);
                    if (cVar18 == '\0') {
                      *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                      goto LAB_;
                    }
                  }
                }
                lVar26 = plVar51[6];
                *(undefined8 *)(puVar43 + -8) = 0x10e1f8;
                func_0x(lVar26);
                *(undefined8 *)(puVar43 + -8) = 0x10e200;
                iVar21 = func_0x(plVar51);
                if (iVar21 == 0) {
                  pcVar8 = *(code **)(*plVar51 + 0x270);
                  *(undefined8 *)(puVar43 + -8) = 0x10e211;
                  (*pcVar8)(plVar51);
                }
                if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                  if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                    *(undefined8 *)(puVar43 + -8) = 0x10e248;
                    uVar25 = func_0x(plVar51);
                    *(undefined8 *)(puVar43 + -8) = 0x10e250;
                    cVar18 = func_0x(uVar25);
                    if (cVar18 != '\0') {
                      *(undefined8 *)(puVar43 + -8) = 0x10e25c;
                      uVar25 = func_0x(plVar51);
                      *(undefined8 *)(puVar43 + -8) = 0x10e264;
                      cVar18 = func_0x(uVar25);
                      if ((cVar18 != '\0') && (*_DAT_ != '\0')) {
                        *(undefined8 *)(puVar43 + -8) = 0x10e279;
                        uVar25 = func_0x();
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10e293;
                        func_0x(uVar25,0x1c,0x10,1);
                      }
                    }
                  }
                  uVar40 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                }
                else {
                  pcVar8 = *(code **)(*plVar51 + 0x1e8);
                  *(undefined8 *)(puVar43 + -8) = 0x10e228;
                  uVar25 = (*pcVar8)(plVar51);
                  *(undefined8 *)(puVar43 + -8) = 0x10e230;
                  uVar40 = func_0x(uVar25);
                }
                if (uVar40 != 0) goto LAB_;
              }
            }
LAB_:
            if (lVar37 != 0) {
              *(undefined8 *)(puVar43 + -8) = 0x10e2b1;
              cVar18 = func_0x(lVar37);
              if (cVar18 != '\0') goto LAB_;
            }
            goto LAB_;
          }
        }
        else {
LAB_:
          if (ppsVar50 == (short **)0x0) goto LAB_;
        }
LAB_:
        if (*(short *)ppsVar53 == 0) {
          bVar59 = (*(byte *)ppsVar53[1] & 0xe) == 2;
        }
        else {
          bVar59 = ((*(byte *)ppsVar53[1] & 0x1c) - 0x10 & 0xfffffffb) == 0;
        }
        if (!bVar59) {
          if (*(short *)ppsVar58 == 0) {
            bVar59 = (*(byte *)ppsVar58[1] & 0xe) == 2;
          }
          else {
            bVar59 = ((*(byte *)ppsVar58[1] & 0x1c) - 0x10 & 0xfffffffb) == 0;
          }
          if (bVar59) goto LAB_;
          if (*(short *)ppsVar53 == 0) {
            if (*(int *)((longlong)ppsVar53 + 4) == 0) {
              *(undefined2 *)((longlong)ppsVar53 + 2) = 0;
              uVar40 = *(uint *)(ppsVar53 + 2);
              uVar41 = (ulonglong)uVar40;
              *(uint *)((longlong)ppsVar53 + 0x14) = uVar40;
              psVar57 = ppsVar53[1];
              bVar34 = *(byte *)psVar57;
              if ((bVar34 & 0x10) != 0) {
                uVar40 = uVar40 + (*(ushort *)(uVar41 + (longlong)psVar57) + 7 >> 3) + 2;
                uVar41 = (ulonglong)uVar40;
                *(uint *)((longlong)ppsVar53 + 0x14) = uVar40;
                bVar34 = *(byte *)psVar57;
              }
              if ((bVar34 & 0x20) == 0) {
                *(int *)((longlong)ppsVar53 + 4) = (int)uVar41;
                *(undefined2 *)((longlong)ppsVar53 + 0x1c) = 0;
                *(uint *)(ppsVar53 + 3) = uVar40;
              }
              else {
                puVar55 = (ushort *)(uVar41 + (longlong)psVar57);
                uVar39 = *puVar55;
                *(ushort *)((longlong)ppsVar53 + 0x1c) = uVar39;
                if (uVar39 == 0) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                     ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x10e3f1;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x10e417;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                    }
                  }
                  psVar57 = ppsVar53[1];
                  *(undefined8 *)(puVar43 + -8) = 0x10e425;
                  func_0x(psVar57,3);
                  uVar39 = *(ushort *)((longlong)ppsVar53 + 0x1c);
                }
                uVar40 = *(int *)((longlong)ppsVar53 + 0x14) + (uVar39 + 1) * 2;
                *(uint *)(ppsVar53 + 3) = uVar40;
                if (0x1f9e < uVar40) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                      ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                       (*(char *)(lVar37 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x10e4c0;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x10e4e6;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                    }
                  }
                  psVar57 = ppsVar53[1];
                  *(undefined8 *)(puVar43 + -8) = 0x10e4f4;
                  func_0x(psVar57,4);
                }
                uVar39 = puVar55[*(ushort *)((longlong)ppsVar53 + 0x1c)];
                *(uint *)((longlong)ppsVar53 + 4) = uVar39 & 0x7fff;
                if ((uVar39 & 0x7fff) < *(uint *)(ppsVar53 + 3)) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                     ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x10e58b;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x10e5b1;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                    }
                  }
                  psVar57 = ppsVar53[1];
                  *(undefined8 *)(puVar43 + -8) = 0x10e5bf;
                  func_0x(psVar57,4);
                }
                do {
                  uVar39 = *(ushort *)((longlong)ppsVar53 + 0x1c);
                  if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                  psVar57 = ppsVar53[1];
                  uVar40 = *(uint *)((longlong)ppsVar53 + 0x14);
                  uVar48 = (uint)uVar39;
                  if (uVar48 == 1) {
                    uVar45 = *(uint *)(ppsVar53 + 3);
                    uVar39 = *(ushort *)
                              ((longlong)psVar57 + (longlong)(int)uVar48 * 2 + (ulonglong)uVar40);
                    uVar48 = uVar45;
LAB_:
                    if ((uVar39 & 0x7fff) < uVar45) goto LAB_;
                  }
                  else {
                    uVar45 = *(ushort *)
                              ((longlong)psVar57 +
                              (longlong)(int)uVar48 * 2 + ((ulonglong)uVar40 - 2)) & 0x7fff;
                    uVar48 = *(uint *)(ppsVar53 + 3);
                    uVar39 = *(ushort *)
                              ((longlong)psVar57 + (ulonglong)uVar39 * 2 + (ulonglong)uVar40);
                    if (uVar48 <= uVar45) goto LAB_;
LAB_:
                    *(undefined8 *)(puVar43 + -8) = 0x10e627;
                    func_0x(psVar57,7);
                    uVar48 = *(uint *)(ppsVar53 + 3);
                  }
                  if ((uVar45 < uVar48) || (*(uint *)((longlong)ppsVar53 + 4) < uVar45))
                  goto LAB_;
                  if (*(ushort *)((ulonglong)uVar45 + (longlong)ppsVar53[1]) == 5) {
                    *(ushort *)((longlong)ppsVar53 + 2) = *(ushort *)((longlong)ppsVar53 + 2) | 2;
                    *(short *)((longlong)ppsVar53 + 0x1c) =
                         *(short *)((longlong)ppsVar53 + 0x1c) + -1;
                    uVar40 = uVar45 & 0xffff;
                    *(short *)((longlong)ppsVar53 + 0x2a) = (short)uVar45;
                    psVar57 = ppsVar53[1];
                    uVar39 = *(ushort *)((longlong)ppsVar53 + 0x2c) & 0xc7ff;
                    if ((*(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x4000) != 0) {
                      uVar39 = *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x3800 |
                               uVar39;
                    }
                    *(ushort *)((longlong)ppsVar53 + 0x2c) = uVar39;
                    *(ushort *)((longlong)ppsVar53 + 0x2c) =
                         (uVar39 ^ *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2)) & 0x7ff ^
                         uVar39;
                    break;
                  }
                  if (*(ushort *)((ulonglong)uVar45 + (longlong)ppsVar53[1]) < 0x400) break;
                  *(ushort *)((longlong)ppsVar53 + 2) = *(ushort *)((longlong)ppsVar53 + 2) | 1;
                  psVar57 = (short *)((longlong)ppsVar53 + 0x1c);
                  *psVar57 = *psVar57 + -1;
                } while (*psVar57 != 0);
              }
              iVar21 = 0;
              if ((*(byte *)ppsVar53[1] & 0x40) == 0) {
                *(undefined4 *)((longlong)ppsVar53 + 0x26) = 0;
              }
              else {
                *(int *)((longlong)ppsVar53 + 0x26) = *(int *)((longlong)ppsVar53 + 4);
                *(int *)((longlong)ppsVar53 + 4) = *(int *)((longlong)ppsVar53 + 4) + 0xe;
                *(undefined8 *)(puVar43 + -8) = 0x10e723;
                puVar27 = (ulonglong *)func_0x((longlong)ppsVar53 + 2);
                uVar41 = *puVar27;
                *(ulonglong *)(&stack0x00000258 + lVar23) = uVar41;
                uVar35 = (ushort)(uVar41 >> 0x30);
                uVar39 = uVar35;
                if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                  uVar39 = uVar35 & 0xdfff;
                  if ((uVar41 & 0x4000000000000000) != 0) {
                    uVar39 = uVar35 | 0x2000;
                  }
                }
                if (uVar39 == 0xfffc) {
                  iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                }
                *(int *)((longlong)ppsVar53 + 4) = *(int *)((longlong)ppsVar53 + 4) + iVar21;
              }
              uVar40 = *(uint *)((longlong)ppsVar53 + 4);
              if ((*(ulonglong *)((longlong)ppsVar53 + 0x1e) != 0) &&
                 (*(ulonglong *)((longlong)ppsVar53 + 0x1e) <
                  (ulonglong)uVar40 + (longlong)ppsVar53[1])) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   (((lVar37 = *(longlong *)
                                ((ulonglong)*_DAT_ +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                     (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10e820;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x10e846;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                  }
                }
                psVar57 = ppsVar53[1];
                *(undefined8 *)(puVar43 + -8) = 0x10e854;
                func_0x(psVar57,0x12);
                uVar40 = *(uint *)((longlong)ppsVar53 + 4);
              }
              if (0x3f3b < uVar40 - 1) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                    ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                     (*(char *)(lVar37 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10e8e0;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    psVar57 = ppsVar53[1];
                    *(undefined8 *)(puVar43 + -8) = 0x10e8ee;
                    func_0x(psVar57,5);
                    goto LAB_;
                  }
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10e914;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                }
                psVar57 = ppsVar53[1];
                *(undefined8 *)(puVar43 + -8) = 0x10e922;
                func_0x(psVar57,5);
              }
            }
LAB_:
            uVar40 = *(uint *)((longlong)ppsVar53 + 4);
            *(uint *)(&stack0x00000044 + lVar23) = uVar40;
            if ((uVar40 < 9) &&
               (((*(byte *)ppsVar53[1] & 0xe) == 0 || ((*(byte *)ppsVar53[1] & 0xe) == 0xc)))) {
              *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
            }
            ppsVar50 = *(short ***)(&stack0x00000228 + lVar23);
          }
          else {
            uVar40 = *(uint *)((longlong)ppsVar53 + 4);
            *(uint *)(&stack0x00000044 + lVar23) = uVar40;
            if (uVar40 == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x10e967;
              func_0x((longlong)ppsVar53 + 2);
              uVar40 = *(uint *)((longlong)ppsVar53 + 4);
              *(uint *)(&stack0x00000044 + lVar23) = uVar40;
            }
            if ((uVar40 < 9) &&
               (((*(byte *)ppsVar53[1] & 0x1c) == 0 || ((*(byte *)ppsVar53[1] & 0x1c) == 0xc)))) {
              *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
            }
          }
          uVar25 = 0;
          if (ppsVar50 != (short **)0x0) {
            *(undefined8 *)(puVar43 + -8) = 0x10e9a3;
            uVar29 = func_0x(ppsVar58,&stack0x00000260 + lVar23);
            *(undefined8 *)(puVar43 + -8) = 0x10e9ab;
            cVar18 = func_0x(uVar29);
            if (cVar18 != '\0') {
              if (*(short *)ppsVar58 == 0) {
                if (*(int *)((longlong)ppsVar58 + 4) == 0) {
                  *(undefined2 *)((longlong)ppsVar58 + 2) = 0;
                  uVar40 = *(uint *)(ppsVar58 + 2);
                  uVar41 = (ulonglong)uVar40;
                  *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
                  psVar57 = ppsVar58[1];
                  bVar34 = *(byte *)psVar57;
                  if ((bVar34 & 0x10) != 0) {
                    uVar40 = uVar40 + 2 + (*(ushort *)(uVar41 + (longlong)psVar57) + 7 >> 3);
                    uVar41 = (ulonglong)uVar40;
                    *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
                    bVar34 = *(byte *)psVar57;
                  }
                  if ((bVar34 & 0x20) == 0) {
                    *(int *)((longlong)ppsVar58 + 4) = (int)uVar41;
                    *(undefined2 *)((longlong)ppsVar58 + 0x1c) = 0;
                    *(uint *)(ppsVar58 + 3) = uVar40;
                  }
                  else {
                    puVar55 = (ushort *)(uVar41 + (longlong)psVar57);
                    uVar39 = *puVar55;
                    *(ushort *)((longlong)ppsVar58 + 0x1c) = uVar39;
                    if (uVar39 == 0) {
                      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                          (lVar37 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                         ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                          (*(char *)(lVar37 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar43 + -8) = 0x10ea96;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x10eabc;
                          (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                        }
                      }
                      psVar57 = ppsVar58[1];
                      *(undefined8 *)(puVar43 + -8) = 0x10eaca;
                      func_0x(psVar57,3);
                      uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
                    }
                    uVar40 = *(int *)((longlong)ppsVar58 + 0x14) + 2 + (uint)uVar39 * 2;
                    *(uint *)(ppsVar58 + 3) = uVar40;
                    if (0x1f9e < uVar40) {
                      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                         ((lVar37 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                          ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                           (*(char *)(lVar37 + 0x499) != '\0')))))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar43 + -8) = 0x10eb66;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x10eb8c;
                          (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                        }
                      }
                      psVar57 = ppsVar58[1];
                      *(undefined8 *)(puVar43 + -8) = 0x10eb9a;
                      func_0x(psVar57,4);
                    }
                    uVar39 = puVar55[*(ushort *)((longlong)ppsVar58 + 0x1c)];
                    *(uint *)((longlong)ppsVar58 + 4) = uVar39 & 0x7fff;
                    if ((uVar39 & 0x7fff) < *(uint *)(ppsVar58 + 3)) {
                      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                          (lVar37 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                         ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                          (*(char *)(lVar37 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar43 + -8) = 0x10ec31;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x10ec57;
                          (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                        }
                      }
                      psVar57 = ppsVar58[1];
                      *(undefined8 *)(puVar43 + -8) = 0x10ec65;
                      func_0x(psVar57,4);
                    }
                    do {
                      uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
                      if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                      psVar57 = ppsVar58[1];
                      uVar40 = *(uint *)((longlong)ppsVar58 + 0x14);
                      uVar48 = (uint)uVar39;
                      if (uVar48 == 1) {
                        uVar45 = *(uint *)(ppsVar58 + 3);
                        uVar39 = *(ushort *)
                                  ((longlong)psVar57 + (longlong)(int)uVar48 * 2 + (ulonglong)uVar40
                                  );
                        uVar48 = uVar45;
LAB_:
                        if ((uVar39 & 0x7fff) < uVar45) goto LAB_;
                      }
                      else {
                        uVar45 = *(ushort *)
                                  ((longlong)psVar57 +
                                  (longlong)(int)uVar48 * 2 + ((ulonglong)uVar40 - 2)) & 0x7fff;
                        uVar48 = *(uint *)(ppsVar58 + 3);
                        uVar39 = *(ushort *)
                                  ((longlong)psVar57 + (ulonglong)uVar39 * 2 + (ulonglong)uVar40);
                        if (uVar48 <= uVar45) goto LAB_;
LAB_:
                        *(undefined8 *)(puVar43 + -8) = 0x10ecd7;
                        func_0x(psVar57,7);
                        uVar48 = *(uint *)(ppsVar58 + 3);
                      }
                      if ((uVar45 < uVar48) || (*(uint *)((longlong)ppsVar58 + 4) < uVar45))
                      goto LAB_;
                      psVar57 = ppsVar58[1];
                      if (*(ushort *)((ulonglong)uVar45 + (longlong)psVar57) == 5) {
                        *(ushort *)((longlong)ppsVar58 + 2) =
                             *(ushort *)((longlong)ppsVar58 + 2) | 2;
                        *(short *)((longlong)ppsVar58 + 0x1c) =
                             *(short *)((longlong)ppsVar58 + 0x1c) + -1;
                        uVar40 = uVar45 & 0xffff;
                        *(short *)((longlong)ppsVar58 + 0x2a) = (short)uVar45;
                        uVar39 = *(ushort *)((longlong)ppsVar58 + 0x2c) & 0xc7ff;
                        if ((*(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x4000) != 0)
                        {
                          uVar39 = *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x3800 |
                                   uVar39;
                        }
                        *(ushort *)((longlong)ppsVar58 + 0x2c) = uVar39;
                        *(ushort *)((longlong)ppsVar58 + 0x2c) =
                             (uVar39 ^ *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2)) &
                             0x7ff ^ uVar39;
                        break;
                      }
                      if (*(ushort *)((ulonglong)uVar45 + (longlong)psVar57) < 0x400) break;
                      *(ushort *)((longlong)ppsVar58 + 2) = *(ushort *)((longlong)ppsVar58 + 2) | 1;
                      psVar57 = (short *)((longlong)ppsVar58 + 0x1c);
                      *psVar57 = *psVar57 + -1;
                    } while (*psVar57 != 0);
                  }
                  iVar21 = 0;
                  if ((*(byte *)ppsVar58[1] & 0x40) == 0) {
                    *(undefined4 *)((longlong)ppsVar58 + 0x26) = 0;
                  }
                  else {
                    *(int *)((longlong)ppsVar58 + 0x26) = *(int *)((longlong)ppsVar58 + 4);
                    *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + 0xe;
                    *(undefined8 *)(puVar43 + -8) = 0x10edc5;
                    puVar27 = (ulonglong *)func_0x((longlong)ppsVar58 + 2);
                    uVar41 = *puVar27;
                    *(ulonglong *)(&stack0x00000268 + lVar23) = uVar41;
                    uVar35 = (ushort)(uVar41 >> 0x30);
                    uVar39 = uVar35;
                    if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                      uVar39 = uVar35 & 0xdfff;
                      if ((uVar41 & 0x4000000000000000) != 0) {
                        uVar39 = uVar35 | 0x2000;
                      }
                    }
                    if (uVar39 == 0xfffc) {
                      iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                    }
                    *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + iVar21;
                  }
                  uVar40 = *(uint *)((longlong)ppsVar58 + 4);
                  if ((*(ulonglong *)((longlong)ppsVar58 + 0x1e) != 0) &&
                     (*(ulonglong *)((longlong)ppsVar58 + 0x1e) <
                      (ulonglong)uVar40 + (longlong)ppsVar58[1])) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       (((lVar37 = *(longlong *)
                                    ((ulonglong)*_DAT_ +
                                     *(longlong *)
                                      (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                      (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                         (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                        (*(char *)(lVar37 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x10eec2;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10eee8;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                      }
                    }
                    psVar57 = ppsVar58[1];
                    *(undefined8 *)(puVar43 + -8) = 0x10eef6;
                    func_0x(psVar57,0x12);
                    uVar40 = *(uint *)((longlong)ppsVar58 + 4);
                  }
                  if (0x3f3b < uVar40 - 1) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                        ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                         (*(char *)(lVar37 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x10ef82;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10efa8;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                      }
                    }
                    psVar57 = ppsVar58[1];
                    *(undefined8 *)(puVar43 + -8) = 0x10efb6;
                    func_0x(psVar57,5);
                  }
                }
LAB_:
                uVar40 = *(uint *)((longlong)ppsVar58 + 4);
                *(uint *)(&stack0x00000044 + lVar23) = uVar40;
                if ((uVar40 < 9) &&
                   (((*(byte *)ppsVar58[1] & 0xe) == 0 || ((*(byte *)ppsVar58[1] & 0xe) == 0xc)))) {
LAB_:
                  *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
                }
              }
              else {
                uVar40 = *(uint *)((longlong)ppsVar58 + 4);
                *(uint *)(&stack0x00000044 + lVar23) = uVar40;
                if (uVar40 == 0) {
                  *(undefined8 *)(puVar43 + -8) = 0x10effa;
                  func_0x((longlong)ppsVar58 + 2);
                  uVar40 = *(uint *)((longlong)ppsVar58 + 4);
                  *(uint *)(&stack0x00000044 + lVar23) = uVar40;
                }
                if (uVar40 < 9) {
                  if ((*(byte *)ppsVar58[1] & 0x1c) == 0) goto LAB_;
                  if ((*(byte *)ppsVar58[1] & 0x1c) == 0xc) {
                    *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
                    uVar36 = *(undefined4 *)(&stack0x00000028 + lVar23);
                    uVar25 = *(undefined8 *)(&stack0x00000058 + lVar23);
                    goto LAB_;
                  }
                }
              }
              uVar36 = *(undefined4 *)(&stack0x00000028 + lVar23);
              uVar25 = *(undefined8 *)(&stack0x00000058 + lVar23);
              bVar38 = 0;
              goto LAB_;
            }
          }
          pcVar8 = *(code **)(*plVar51 + 0x20);
          *(undefined8 *)(puVar43 + -8) = 0x10f034;
          cVar18 = (*pcVar8)(plVar51);
          if (cVar18 == '\0') {
LAB_:
            *(undefined4 *)(&stack0x00000044 + lVar23) = 0xf;
            bVar38 = 1;
            uVar36 = *(undefined4 *)(&stack0x00000028 + lVar23);
            uVar25 = *(undefined8 *)(&stack0x00000058 + lVar23);
            goto LAB_;
          }
          if (*(short *)ppsVar58 != 0) {
            *(undefined8 *)(puVar43 + -8) = 0x10f04c;
            lVar37 = func_0x((longlong)ppsVar58 + 2);
            if (lVar37 != 0) {
              if (*(short *)ppsVar58 != 0) {
                *(undefined8 *)(puVar43 + -8) = 0x10f066;
                uVar25 = func_0x((longlong)ppsVar58 + 2);
              }
              *(undefined8 *)(puVar43 + -8) = 0x10f06e;
              iVar21 = func_0x(uVar25);
              if (iVar21 != 0) goto LAB_;
            }
          }
          if (2000 < *(uint *)(&stack0x00000044 + lVar23)) {
            *(undefined8 *)(puVar43 + -8) = 0x10f084;
            cVar18 = func_0x();
            if (cVar18 == '\0') goto LAB_;
          }
          *(undefined8 *)(puVar43 + -8) = 0x10f09b;
          puVar28 = (undefined4 *)func_0x(ppsVar53,&stack0x000000d4 + lVar23);
          *(undefined4 *)(&stack0x00000088 + lVar23) = *puVar28;
          *(undefined2 *)(&stack0x0000008c + lVar23) = *(undefined2 *)(puVar28 + 1);
          *(undefined8 *)(puVar43 + -8) = 0x10f0b7;
          uVar25 = func_0x(ppsVar53,&stack0x00000270 + lVar23);
          lVar37 = plVar51[6];
          *(undefined8 *)(puVar43 + -8) = 0x10f0c3;
          uVar29 = func_0x(lVar37);
          *(undefined8 *)(puVar43 + -8) = 0x10f0d2;
          cVar18 = func_0x(uVar29,&stack0x00000088 + lVar23,uVar25);
          if (cVar18 != '\0') goto LAB_;
          *(undefined8 *)(puVar43 + -8) = 0x10f0e2;
          iVar21 = func_0x(ppsVar53);
          if (iVar21 == 0) {
            iVar21 = *(int *)(&stack0x00000044 + lVar23);
            *(int *)(&stack0x00000044 + lVar23) = iVar21 + 0xe;
            puVar55 = (ushort *)((longlong)ppsVar58 + 2);
            if (*(short *)ppsVar58 == 0) {
              if (*(int *)((longlong)ppsVar58 + 4) == 0) {
                *puVar55 = 0;
                uVar40 = *(uint *)(ppsVar58 + 2);
                uVar41 = (ulonglong)uVar40;
                *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
                psVar57 = ppsVar58[1];
                bVar34 = *(byte *)psVar57;
                if ((bVar34 & 0x10) != 0) {
                  uVar40 = uVar40 + 2 + (*(ushort *)(uVar41 + (longlong)psVar57) + 7 >> 3);
                  uVar41 = (ulonglong)uVar40;
                  *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
                  bVar34 = *(byte *)psVar57;
                }
                if ((bVar34 & 0x20) == 0) {
                  *(int *)((longlong)ppsVar58 + 4) = (int)uVar41;
                  *(undefined2 *)((longlong)ppsVar58 + 0x1c) = 0;
                  *(uint *)(ppsVar58 + 3) = uVar40;
                }
                else {
                  puVar44 = (ushort *)(uVar41 + (longlong)psVar57);
                  uVar39 = *puVar44;
                  *(ushort *)((longlong)ppsVar58 + 0x1c) = uVar39;
                  if (uVar39 == 0) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                       ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                        (*(char *)(lVar37 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x10f1d4;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10f1fa;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                      }
                    }
                    psVar57 = ppsVar58[1];
                    *(undefined8 *)(puVar43 + -8) = 0x10f208;
                    func_0x(psVar57,3);
                    uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
                  }
                  uVar40 = *(int *)((longlong)ppsVar58 + 0x14) + 2 + (uint)uVar39 * 2;
                  *(uint *)(ppsVar58 + 3) = uVar40;
                  if (0x1f9e < uVar40) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                        ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                         (*(char *)(lVar37 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x10f2a1;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10f2c7;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                      }
                    }
                    psVar57 = ppsVar58[1];
                    *(undefined8 *)(puVar43 + -8) = 0x10f2d5;
                    func_0x(psVar57,4);
                  }
                  uVar39 = puVar44[*(ushort *)((longlong)ppsVar58 + 0x1c)];
                  *(uint *)((longlong)ppsVar58 + 4) = uVar39 & 0x7fff;
                  if ((uVar39 & 0x7fff) < *(uint *)(ppsVar58 + 3)) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                       ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                        (*(char *)(lVar37 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x10f369;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10f38f;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                      }
                    }
                    psVar57 = ppsVar58[1];
                    *(undefined8 *)(puVar43 + -8) = 0x10f39d;
                    func_0x(psVar57,4);
                  }
                  do {
                    uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
                    if (-1 < (short)puVar44[(ulonglong)(uVar39 - 1) + 1]) break;
                    psVar57 = ppsVar58[1];
                    uVar40 = *(uint *)((longlong)ppsVar58 + 0x14);
                    uVar48 = (uint)uVar39;
                    if (uVar48 == 1) {
                      uVar45 = *(uint *)(ppsVar58 + 3);
                      uVar39 = *(ushort *)
                                ((longlong)psVar57 + (longlong)(int)uVar48 * 2 + (ulonglong)uVar40);
                      uVar48 = uVar45;
LAB_:
                      if ((uVar39 & 0x7fff) < uVar45) goto LAB_;
                    }
                    else {
                      uVar45 = *(ushort *)
                                ((longlong)psVar57 +
                                (longlong)(int)uVar48 * 2 + ((ulonglong)uVar40 - 2)) & 0x7fff;
                      uVar48 = *(uint *)(ppsVar58 + 3);
                      uVar39 = *(ushort *)
                                ((longlong)psVar57 + (ulonglong)uVar39 * 2 + (ulonglong)uVar40);
                      if (uVar48 <= uVar45) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar43 + -8) = 0x10f407;
                      func_0x(psVar57,7);
                      uVar48 = *(uint *)(ppsVar58 + 3);
                    }
                    if ((uVar45 < uVar48) || (*(uint *)((longlong)ppsVar58 + 4) < uVar45))
                    goto LAB_;
                    psVar57 = ppsVar58[1];
                    if (*(ushort *)((ulonglong)uVar45 + (longlong)psVar57) == 5) {
                      *puVar55 = *puVar55 | 2;
                      *(short *)((longlong)ppsVar58 + 0x1c) =
                           *(short *)((longlong)ppsVar58 + 0x1c) + -1;
                      uVar40 = uVar45 & 0xffff;
                      *(short *)((longlong)ppsVar58 + 0x2a) = (short)uVar45;
                      uVar39 = *(ushort *)((longlong)ppsVar58 + 0x2c) & 0xc7ff;
                      if ((*(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x4000) != 0) {
                        uVar39 = *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x3800 |
                                 uVar39;
                      }
                      *(ushort *)((longlong)ppsVar58 + 0x2c) = uVar39;
                      *(ushort *)((longlong)ppsVar58 + 0x2c) =
                           (uVar39 ^ *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2)) & 0x7ff
                           ^ uVar39;
                      break;
                    }
                    if (*(ushort *)((ulonglong)uVar45 + (longlong)psVar57) < 0x400) break;
                    *puVar55 = *puVar55 | 1;
                    psVar57 = (short *)((longlong)ppsVar58 + 0x1c);
                    *psVar57 = *psVar57 + -1;
                  } while (*psVar57 != 0);
                }
                iVar22 = 0;
                if ((*(byte *)ppsVar58[1] & 0x40) == 0) {
                  *(undefined4 *)((longlong)ppsVar58 + 0x26) = 0;
                }
                else {
                  *(int *)((longlong)ppsVar58 + 0x26) = *(int *)((longlong)ppsVar58 + 4);
                  *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + 0xe;
                  *(undefined8 *)(puVar43 + -8) = 0x10f4e6;
                  puVar27 = (ulonglong *)func_0x(puVar55);
                  uVar41 = *puVar27;
                  *(ulonglong *)(&stack0x00000278 + lVar23) = uVar41;
                  uVar35 = (ushort)(uVar41 >> 0x30);
                  uVar39 = uVar35;
                  if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                    uVar39 = uVar35 & 0xdfff;
                    if ((uVar41 & 0x4000000000000000) != 0) {
                      uVar39 = uVar35 | 0x2000;
                    }
                  }
                  if (uVar39 == 0xfffc) {
                    iVar22 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                  }
                  *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + iVar22;
                }
                uVar40 = *(uint *)((longlong)ppsVar58 + 4);
                if ((*(ulonglong *)((longlong)ppsVar58 + 0x1e) != 0) &&
                   (*(ulonglong *)((longlong)ppsVar58 + 0x1e) <
                    (ulonglong)uVar40 + (longlong)ppsVar58[1])) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     (((lVar37 = *(longlong *)
                                  ((ulonglong)*_DAT_ +
                                   *(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                       (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x10f5e1;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x10f607;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                    }
                  }
                  psVar57 = ppsVar58[1];
                  *(undefined8 *)(puVar43 + -8) = 0x10f615;
                  func_0x(psVar57,0x12);
                  uVar40 = *(uint *)((longlong)ppsVar58 + 4);
                }
                if (0x3f3b < uVar40 - 1) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                      ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                       (*(char *)(lVar37 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x10f6a0;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x10f6c6;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                    }
                  }
                  psVar57 = ppsVar58[1];
                  *(undefined8 *)(puVar43 + -8) = 0x10f6d4;
                  func_0x(psVar57,5);
                }
              }
LAB_:
              uVar40 = *(uint *)((longlong)ppsVar58 + 4);
              if (uVar40 < 9) {
                bVar34 = *(byte *)ppsVar58[1] & 0xe;
joined_r0x0010f714:
                if ((bVar34 == 0) || (bVar34 == 0xc)) {
                  uVar40 = 9;
                }
              }
            }
            else {
              uVar40 = *(uint *)((longlong)ppsVar58 + 4);
              if (uVar40 == 0) {
                *(undefined8 *)(puVar43 + -8) = 0x10f700;
                func_0x(puVar55);
                uVar40 = *(uint *)((longlong)ppsVar58 + 4);
              }
              if (uVar40 < 9) {
                bVar34 = *(byte *)ppsVar58[1] & 0x1c;
                goto joined_r0x0010f714;
              }
            }
            *(int *)(puVar43 + 0x20) = iVar21 + 0xe;
            uVar36 = *(undefined4 *)(&stack0x00000028 + lVar23);
            uVar25 = *(undefined8 *)(&stack0x00000058 + lVar23);
            *(undefined8 *)(puVar43 + -8) = 0x10f73b;
            cVar18 = func_0x(plVar51,uVar25,uVar36,uVar40);
            if (cVar18 == '\0') {
              *(undefined4 *)(&stack0x00000044 + lVar23) = 0xf;
              bVar38 = 1;
            }
            goto LAB_;
          }
          goto LAB_;
        }
LAB_:
        *(undefined8 *)(puVar43 + -8) = 0x10f770;
        uVar20 = func_0x(ppsVar58);
        *(undefined8 *)(puVar43 + -8) = 0x10f778;
        uVar40 = func_0x(uVar20);
        *(uint *)(&stack0x00000044 + lVar23) = uVar40;
        if (*(short *)ppsVar58 == 0) {
          if (*(int *)((longlong)ppsVar58 + 4) == 0) {
            *(undefined2 *)((longlong)ppsVar58 + 2) = 0;
            uVar48 = *(uint *)(ppsVar58 + 2);
            uVar41 = (ulonglong)uVar48;
            *(uint *)((longlong)ppsVar58 + 0x14) = uVar48;
            psVar57 = ppsVar58[1];
            bVar34 = *(byte *)psVar57;
            if ((bVar34 & 0x10) != 0) {
              uVar48 = uVar48 + 2 + (*(ushort *)(uVar41 + (longlong)psVar57) + 7 >> 3);
              uVar41 = (ulonglong)uVar48;
              *(uint *)((longlong)ppsVar58 + 0x14) = uVar48;
              bVar34 = *(byte *)psVar57;
            }
            if ((bVar34 & 0x20) == 0) {
              *(int *)((longlong)ppsVar58 + 4) = (int)uVar41;
              *(undefined2 *)((longlong)ppsVar58 + 0x1c) = 0;
              *(uint *)(ppsVar58 + 3) = uVar48;
            }
            else {
              puVar55 = (ushort *)(uVar41 + (longlong)psVar57);
              uVar39 = *puVar55;
              *(ushort *)((longlong)ppsVar58 + 0x1c) = uVar39;
              if (uVar39 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10f85f;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x10f885;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                  }
                }
                psVar57 = ppsVar58[1];
                *(undefined8 *)(puVar43 + -8) = 0x10f893;
                func_0x(psVar57,3);
                uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
              }
              uVar48 = *(int *)((longlong)ppsVar58 + 0x14) + 2 + (uint)uVar39 * 2;
              *(uint *)(ppsVar58 + 3) = uVar48;
              if (0x1f9e < uVar48) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                    ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                     (*(char *)(lVar37 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10f92f;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x10f955;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                  }
                }
                psVar57 = ppsVar58[1];
                *(undefined8 *)(puVar43 + -8) = 0x10f963;
                func_0x(psVar57,4);
              }
              uVar39 = puVar55[*(ushort *)((longlong)ppsVar58 + 0x1c)];
              *(uint *)((longlong)ppsVar58 + 4) = uVar39 & 0x7fff;
              if ((uVar39 & 0x7fff) < *(uint *)(ppsVar58 + 3)) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10f9fa;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x10fa20;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                  }
                }
                psVar57 = ppsVar58[1];
                *(undefined8 *)(puVar43 + -8) = 0x10fa2e;
                func_0x(psVar57,4);
              }
              do {
                uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
                if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                psVar57 = ppsVar58[1];
                uVar48 = *(uint *)((longlong)ppsVar58 + 0x14);
                uVar45 = (uint)uVar39;
                if (uVar45 == 1) {
                  uVar46 = *(uint *)(ppsVar58 + 3);
                  uVar39 = *(ushort *)
                            ((longlong)psVar57 + (longlong)(int)uVar45 * 2 + (ulonglong)uVar48);
                  uVar45 = uVar46;
LAB_:
                  if ((uVar39 & 0x7fff) < uVar46) goto LAB_;
                }
                else {
                  uVar46 = *(ushort *)
                            ((longlong)psVar57 + (longlong)(int)uVar45 * 2 + ((ulonglong)uVar48 - 2)
                            ) & 0x7fff;
                  uVar45 = *(uint *)(ppsVar58 + 3);
                  uVar39 = *(ushort *)
                            ((longlong)psVar57 + (ulonglong)uVar39 * 2 + (ulonglong)uVar48);
                  if (uVar45 <= uVar46) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar43 + -8) = 0x10fa97;
                  func_0x(psVar57,7);
                  uVar45 = *(uint *)(ppsVar58 + 3);
                }
                if ((uVar46 < uVar45) || (*(uint *)((longlong)ppsVar58 + 4) < uVar46))
                goto LAB_;
                if (*(ushort *)((ulonglong)uVar46 + (longlong)ppsVar58[1]) == 5) {
                  *(ushort *)((longlong)ppsVar58 + 2) = *(ushort *)((longlong)ppsVar58 + 2) | 2;
                  *(short *)((longlong)ppsVar58 + 0x1c) = *(short *)((longlong)ppsVar58 + 0x1c) + -1
                  ;
                  uVar48 = uVar46 & 0xffff;
                  *(short *)((longlong)ppsVar58 + 0x2a) = (short)uVar46;
                  psVar57 = ppsVar58[1];
                  uVar39 = *(ushort *)((longlong)ppsVar58 + 0x2c) & 0xc7ff;
                  if ((*(ushort *)((longlong)psVar57 + (ulonglong)uVar48 + 2) & 0x4000) != 0) {
                    uVar39 = *(ushort *)((longlong)psVar57 + (ulonglong)uVar48 + 2) & 0x3800 |
                             uVar39;
                  }
                  *(ushort *)((longlong)ppsVar58 + 0x2c) = uVar39;
                  *(ushort *)((longlong)ppsVar58 + 0x2c) =
                       (uVar39 ^ *(ushort *)((longlong)psVar57 + (ulonglong)uVar48 + 2)) & 0x7ff ^
                       uVar39;
                  break;
                }
                if (*(ushort *)((ulonglong)uVar46 + (longlong)ppsVar58[1]) < 0x400) break;
                *(ushort *)((longlong)ppsVar58 + 2) = *(ushort *)((longlong)ppsVar58 + 2) | 1;
                psVar57 = (short *)((longlong)ppsVar58 + 0x1c);
                *psVar57 = *psVar57 + -1;
              } while (*psVar57 != 0);
            }
            iVar21 = 0;
            if ((*(byte *)ppsVar58[1] & 0x40) == 0) {
              *(undefined4 *)((longlong)ppsVar58 + 0x26) = 0;
            }
            else {
              *(int *)((longlong)ppsVar58 + 0x26) = *(int *)((longlong)ppsVar58 + 4);
              *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + 0xe;
              *(undefined8 *)(puVar43 + -8) = 0x10fb93;
              puVar27 = (ulonglong *)func_0x((longlong)ppsVar58 + 2);
              uVar41 = *puVar27;
              *(ulonglong *)(&stack0x00000280 + lVar23) = uVar41;
              uVar35 = (ushort)(uVar41 >> 0x30);
              uVar39 = uVar35;
              if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                uVar39 = uVar35 & 0xdfff;
                if ((uVar41 & 0x4000000000000000) != 0) {
                  uVar39 = uVar35 | 0x2000;
                }
              }
              if (uVar39 == 0xfffc) {
                iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + iVar21;
            }
            uVar48 = *(uint *)((longlong)ppsVar58 + 4);
            if ((*(ulonglong *)((longlong)ppsVar58 + 0x1e) != 0) &&
               (*(ulonglong *)((longlong)ppsVar58 + 0x1e) <
                (ulonglong)uVar48 + (longlong)ppsVar58[1])) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar37 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                   (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10fc90;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10fcb6;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                }
              }
              psVar57 = ppsVar58[1];
              *(undefined8 *)(puVar43 + -8) = 0x10fcc4;
              func_0x(psVar57,0x12);
              uVar48 = *(uint *)((longlong)ppsVar58 + 4);
            }
            if (0x3f3b < uVar48 - 1) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10fd50;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  psVar57 = ppsVar58[1];
                  *(undefined8 *)(puVar43 + -8) = 0x10fd5e;
                  func_0x(psVar57,5);
                  goto LAB_;
                }
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x10fd84;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
              }
              psVar57 = ppsVar58[1];
              *(undefined8 *)(puVar43 + -8) = 0x10fd92;
              func_0x(psVar57,5);
            }
          }
LAB_:
          uVar48 = *(uint *)((longlong)ppsVar58 + 4);
          if (uVar48 < 9) {
            bVar34 = *(byte *)ppsVar58[1] & 0xe;
joined_r0x0010fdd4:
            if ((bVar34 == 0) || (bVar34 == 0xc)) {
              uVar48 = 9;
            }
          }
        }
        else {
          uVar48 = *(uint *)((longlong)ppsVar58 + 4);
          if (uVar48 == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x10fdc1;
            func_0x((longlong)ppsVar58 + 2);
            uVar48 = *(uint *)((longlong)ppsVar58 + 4);
          }
          if (uVar48 < 9) {
            bVar34 = *(byte *)ppsVar58[1] & 0x1c;
            goto joined_r0x0010fdd4;
          }
        }
        if (uVar40 <= uVar48) {
          if (*(short *)ppsVar58 == 0) {
            if (*(int *)((longlong)ppsVar58 + 4) == 0) {
              *(undefined2 *)((longlong)ppsVar58 + 2) = 0;
              uVar40 = *(uint *)(ppsVar58 + 2);
              uVar41 = (ulonglong)uVar40;
              *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
              psVar57 = ppsVar58[1];
              bVar34 = *(byte *)psVar57;
              if ((bVar34 & 0x10) != 0) {
                uVar40 = uVar40 + 2 + (*(ushort *)(uVar41 + (longlong)psVar57) + 7 >> 3);
                uVar41 = (ulonglong)uVar40;
                *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
                bVar34 = *(byte *)psVar57;
              }
              if ((bVar34 & 0x20) == 0) {
                *(int *)((longlong)ppsVar58 + 4) = (int)uVar41;
                *(undefined2 *)((longlong)ppsVar58 + 0x1c) = 0;
                *(uint *)(ppsVar58 + 3) = uVar40;
              }
              else {
                puVar55 = (ushort *)(uVar41 + (longlong)psVar57);
                uVar39 = *puVar55;
                *(ushort *)((longlong)ppsVar58 + 0x1c) = uVar39;
                if (uVar39 == 0) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                     ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x10fecf;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x10fef5;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                    }
                  }
                  psVar57 = ppsVar58[1];
                  *(undefined8 *)(puVar43 + -8) = 0x10ff03;
                  func_0x(psVar57,3);
                  uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
                }
                uVar40 = *(int *)((longlong)ppsVar58 + 0x14) + 2 + (uint)uVar39 * 2;
                *(uint *)(ppsVar58 + 3) = uVar40;
                if (0x1f9e < uVar40) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                      ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                       (*(char *)(lVar37 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x10ff9f;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x10ffc5;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                    }
                  }
                  psVar57 = ppsVar58[1];
                  *(undefined8 *)(puVar43 + -8) = 0x10ffd3;
                  func_0x(psVar57,4);
                }
                uVar39 = puVar55[*(ushort *)((longlong)ppsVar58 + 0x1c)];
                *(uint *)((longlong)ppsVar58 + 4) = uVar39 & 0x7fff;
                if ((uVar39 & 0x7fff) < *(uint *)(ppsVar58 + 3)) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                     ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x11006a;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x110090;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                    }
                  }
                  psVar57 = ppsVar58[1];
                  *(undefined8 *)(puVar43 + -8) = 0x11009e;
                  func_0x(psVar57,4);
                }
                do {
                  uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
                  if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                  psVar57 = ppsVar58[1];
                  uVar40 = *(uint *)((longlong)ppsVar58 + 0x14);
                  uVar48 = (uint)uVar39;
                  if (uVar48 == 1) {
                    uVar45 = *(uint *)(ppsVar58 + 3);
                    uVar39 = *(ushort *)
                              ((longlong)psVar57 + (longlong)(int)uVar48 * 2 + (ulonglong)uVar40);
                    uVar48 = uVar45;
LAB_:
                    if ((uVar39 & 0x7fff) < uVar45) goto LAB_;
                  }
                  else {
                    uVar45 = *(ushort *)
                              ((longlong)psVar57 +
                              (longlong)(int)uVar48 * 2 + ((ulonglong)uVar40 - 2)) & 0x7fff;
                    uVar48 = *(uint *)(ppsVar58 + 3);
                    uVar39 = *(ushort *)
                              ((longlong)psVar57 + (ulonglong)uVar39 * 2 + (ulonglong)uVar40);
                    if (uVar48 <= uVar45) goto LAB_;
LAB_:
                    *(undefined8 *)(puVar43 + -8) = 0x110117;
                    func_0x(psVar57,7);
                    uVar48 = *(uint *)(ppsVar58 + 3);
                  }
                  if ((uVar45 < uVar48) || (*(uint *)((longlong)ppsVar58 + 4) < uVar45))
                  goto LAB_;
                  if (*(ushort *)((ulonglong)uVar45 + (longlong)ppsVar58[1]) == 5) {
                    *(ushort *)((longlong)ppsVar58 + 2) = *(ushort *)((longlong)ppsVar58 + 2) | 2;
                    *(short *)((longlong)ppsVar58 + 0x1c) =
                         *(short *)((longlong)ppsVar58 + 0x1c) + -1;
                    uVar40 = uVar45 & 0xffff;
                    *(short *)((longlong)ppsVar58 + 0x2a) = (short)uVar45;
                    psVar57 = ppsVar58[1];
                    uVar39 = *(ushort *)((longlong)ppsVar58 + 0x2c) & 0xc7ff;
                    if ((*(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x4000) != 0) {
                      uVar39 = *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x3800 |
                               uVar39;
                    }
                    *(ushort *)((longlong)ppsVar58 + 0x2c) = uVar39;
                    *(ushort *)((longlong)ppsVar58 + 0x2c) =
                         (uVar39 ^ *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2)) & 0x7ff ^
                         uVar39;
                    break;
                  }
                  if (*(ushort *)((ulonglong)uVar45 + (longlong)ppsVar58[1]) < 0x400) break;
                  *(ushort *)((longlong)ppsVar58 + 2) = *(ushort *)((longlong)ppsVar58 + 2) | 1;
                  psVar57 = (short *)((longlong)ppsVar58 + 0x1c);
                  *psVar57 = *psVar57 + -1;
                } while (*psVar57 != 0);
              }
              iVar21 = 0;
              if ((*(byte *)ppsVar58[1] & 0x40) == 0) {
                *(undefined4 *)((longlong)ppsVar58 + 0x26) = 0;
              }
              else {
                *(int *)((longlong)ppsVar58 + 0x26) = *(int *)((longlong)ppsVar58 + 4);
                *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + 0xe;
                *(undefined8 *)(puVar43 + -8) = 0x110212;
                puVar27 = (ulonglong *)func_0x((longlong)ppsVar58 + 2);
                uVar41 = *puVar27;
                *(ulonglong *)(&stack0x00000288 + lVar23) = uVar41;
                uVar35 = (ushort)(uVar41 >> 0x30);
                uVar39 = uVar35;
                if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                  uVar39 = uVar35 & 0xdfff;
                  if ((uVar41 & 0x4000000000000000) != 0) {
                    uVar39 = uVar35 | 0x2000;
                  }
                }
                if (uVar39 == 0xfffc) {
                  iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                }
                *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + iVar21;
              }
              uVar40 = *(uint *)((longlong)ppsVar58 + 4);
              if ((*(ulonglong *)((longlong)ppsVar58 + 0x1e) != 0) &&
                 (*(ulonglong *)((longlong)ppsVar58 + 0x1e) <
                  (ulonglong)uVar40 + (longlong)ppsVar58[1])) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   (((lVar37 = *(longlong *)
                                ((ulonglong)*_DAT_ +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                     (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x110312;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x110338;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                  }
                }
                psVar57 = ppsVar58[1];
                *(undefined8 *)(puVar43 + -8) = 0x110346;
                func_0x(psVar57,0x12);
                uVar40 = *(uint *)((longlong)ppsVar58 + 4);
              }
              if (0x3f3b < uVar40 - 1) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                    ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                     (*(char *)(lVar37 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1103d5;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1103fb;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                  }
                }
                psVar57 = ppsVar58[1];
                *(undefined8 *)(puVar43 + -8) = 0x110409;
                func_0x(psVar57,5);
              }
            }
LAB_:
            if (*(uint *)((longlong)ppsVar58 + 4) < 9) {
              bVar34 = *(byte *)ppsVar58[1] & 0xe;
joined_r0x0011044e:
              if ((bVar34 == 0) || (bVar34 == 0xc)) {
                *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
                uVar36 = *(undefined4 *)(&stack0x00000028 + lVar23);
                uVar25 = *(undefined8 *)(&stack0x00000058 + lVar23);
                goto LAB_;
              }
            }
          }
          else {
            uVar40 = *(uint *)((longlong)ppsVar58 + 4);
            if (uVar40 == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x110438;
              func_0x((longlong)ppsVar58 + 2);
              uVar40 = *(uint *)((longlong)ppsVar58 + 4);
            }
            if (uVar40 < 9) {
              bVar34 = *(byte *)ppsVar58[1] & 0x1c;
              goto joined_r0x0011044e;
            }
          }
          *(undefined4 *)(&stack0x00000044 + lVar23) = *(undefined4 *)((longlong)ppsVar58 + 4);
        }
        uVar36 = *(undefined4 *)(&stack0x00000028 + lVar23);
        uVar25 = *(undefined8 *)(&stack0x00000058 + lVar23);
      }
      else {
LAB_:
        lVar37 = plVar51[6];
        *(undefined8 *)(puVar43 + -8) = 0x110487;
        cVar18 = func_0x(lVar37);
        if ((cVar18 == '\0') || (((&stack0x000003a8)[lVar23] & 1) == 0)) {
LAB_:
          *(undefined4 *)(&stack0x00000044 + lVar23) = 0;
          uVar36 = *(undefined4 *)(&stack0x00000028 + lVar23);
          uVar25 = *(undefined8 *)(&stack0x00000058 + lVar23);
        }
        else {
          pcVar8 = *(code **)*plVar51;
          *(undefined8 *)(puVar43 + -8) = 0x11049d;
          cVar18 = (*pcVar8)(plVar51);
          if (cVar18 != '\0') goto LAB_;
          *(undefined4 *)(&stack0x00000044 + lVar23) = 0xf;
          uVar36 = *(undefined4 *)(&stack0x00000028 + lVar23);
          uVar25 = *(undefined8 *)(&stack0x00000058 + lVar23);
        }
      }
    }
    else {
      ppsVar54 = ppsVar58;
      if (ppsVar50 != (short **)0x0) {
        ppsVar54 = ppsVar50;
      }
      *(undefined4 *)(&stack0x000003c8 + lVar23) = uVar36;
      *(undefined4 *)(&stack0x000003cc + lVar23) = uVar7;
      *(undefined4 *)(&stack0x000003d0 + lVar23) = uVar13;
      *(undefined4 *)(&stack0x000003d4 + lVar23) = uVar14;
      *(undefined8 *)(&stack0x000003d8 + lVar23) = uVar25;
      if ((int)ppsVar53 == 0) {
        psVar57 = *ppsVar42;
      }
      else {
        psVar57 = ppsVar42[1];
      }
      puVar55 = (ushort *)((longlong)ppsVar58 + 2);
      if (*(short *)ppsVar58 == 0) {
        if (*(int *)((longlong)ppsVar58 + 4) == 0) {
          *puVar55 = 0;
          uVar40 = *(uint *)(ppsVar58 + 2);
          uVar41 = (ulonglong)uVar40;
          *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
          psVar49 = ppsVar58[1];
          bVar34 = *(byte *)psVar49;
          if ((bVar34 & 0x10) != 0) {
            uVar40 = uVar40 + 2 + (*(ushort *)(uVar41 + (longlong)psVar49) + 7 >> 3);
            uVar41 = (ulonglong)uVar40;
            *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
            bVar34 = *(byte *)psVar49;
          }
          if ((bVar34 & 0x20) == 0) {
            *(int *)((longlong)ppsVar58 + 4) = (int)uVar41;
            *(undefined2 *)((longlong)ppsVar58 + 0x1c) = 0;
            *(uint *)(ppsVar58 + 3) = uVar40;
          }
          else {
            puVar44 = (ushort *)(uVar41 + (longlong)psVar49);
            uVar39 = *puVar44;
            *(ushort *)((longlong)ppsVar58 + 0x1c) = uVar39;
            if (uVar39 == 0) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x1105c6;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x1105ec;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                }
              }
              psVar49 = ppsVar58[1];
              *(undefined8 *)(puVar43 + -8) = 0x1105fa;
              func_0x(psVar49,3);
              uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
            }
            uVar40 = *(int *)((longlong)ppsVar58 + 0x14) + 2 + (uint)uVar39 * 2;
            *(uint *)(ppsVar58 + 3) = uVar40;
            if (0x1f9e < uVar40) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x110693;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x1106b9;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                }
              }
              psVar49 = ppsVar58[1];
              *(undefined8 *)(puVar43 + -8) = 0x1106c7;
              func_0x(psVar49,4);
            }
            uVar39 = puVar44[*(ushort *)((longlong)ppsVar58 + 0x1c)];
            *(uint *)((longlong)ppsVar58 + 4) = uVar39 & 0x7fff;
            if ((uVar39 & 0x7fff) < *(uint *)(ppsVar58 + 3)) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x11075b;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x110781;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                }
              }
              psVar49 = ppsVar58[1];
              *(undefined8 *)(puVar43 + -8) = 0x11078f;
              func_0x(psVar49,4);
            }
            do {
              uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
              if (-1 < (short)puVar44[(ulonglong)(uVar39 - 1) + 1]) break;
              psVar49 = ppsVar58[1];
              uVar40 = *(uint *)((longlong)ppsVar58 + 0x14);
              uVar48 = (uint)uVar39;
              if (uVar48 == 1) {
                uVar45 = *(uint *)(ppsVar58 + 3);
                uVar39 = *(ushort *)
                          ((longlong)psVar49 + (longlong)(int)uVar48 * 2 + (ulonglong)uVar40);
                uVar48 = uVar45;
LAB_:
                if ((uVar39 & 0x7fff) < uVar45) goto LAB_;
              }
              else {
                uVar45 = *(ushort *)
                          ((longlong)psVar49 + (longlong)(int)uVar48 * 2 + ((ulonglong)uVar40 - 2))
                         & 0x7fff;
                uVar48 = *(uint *)(ppsVar58 + 3);
                uVar39 = *(ushort *)((longlong)psVar49 + (ulonglong)uVar39 * 2 + (ulonglong)uVar40);
                if (uVar48 <= uVar45) goto LAB_;
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x110804;
                func_0x(psVar49,7);
                uVar48 = *(uint *)(ppsVar58 + 3);
              }
              if ((uVar45 < uVar48) || (*(uint *)((longlong)ppsVar58 + 4) < uVar45))
              goto LAB_;
              psVar49 = ppsVar58[1];
              if (*(ushort *)((ulonglong)uVar45 + (longlong)psVar49) == 5) {
                *puVar55 = *puVar55 | 2;
                *(short *)((longlong)ppsVar58 + 0x1c) = *(short *)((longlong)ppsVar58 + 0x1c) + -1;
                uVar40 = uVar45 & 0xffff;
                *(short *)((longlong)ppsVar58 + 0x2a) = (short)uVar45;
                uVar39 = *(ushort *)((longlong)ppsVar58 + 0x2c) & 0xc7ff;
                if ((*(ushort *)((longlong)psVar49 + (ulonglong)uVar40 + 2) & 0x4000) != 0) {
                  uVar39 = *(ushort *)((longlong)psVar49 + (ulonglong)uVar40 + 2) & 0x3800 | uVar39;
                }
                *(ushort *)((longlong)ppsVar58 + 0x2c) = uVar39;
                *(ushort *)((longlong)ppsVar58 + 0x2c) =
                     (uVar39 ^ *(ushort *)((longlong)psVar49 + (ulonglong)uVar40 + 2)) & 0x7ff ^
                     uVar39;
                break;
              }
              if (*(ushort *)((ulonglong)uVar45 + (longlong)psVar49) < 0x400) break;
              *puVar55 = *puVar55 | 1;
              psVar49 = (short *)((longlong)ppsVar58 + 0x1c);
              *psVar49 = *psVar49 + -1;
            } while (*psVar49 != 0);
          }
          iVar21 = 0;
          if ((*(byte *)ppsVar58[1] & 0x40) == 0) {
            *(undefined4 *)((longlong)ppsVar58 + 0x26) = 0;
          }
          else {
            *(int *)((longlong)ppsVar58 + 0x26) = *(int *)((longlong)ppsVar58 + 4);
            *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + 0xe;
            *(undefined8 *)(puVar43 + -8) = 0x1108e3;
            puVar27 = (ulonglong *)func_0x(puVar55);
            uVar41 = *puVar27;
            *(ulonglong *)(&stack0x00000290 + lVar23) = uVar41;
            uVar35 = (ushort)(uVar41 >> 0x30);
            uVar39 = uVar35;
            if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
              uVar39 = uVar35 & 0xdfff;
              if ((uVar41 & 0x4000000000000000) != 0) {
                uVar39 = uVar35 | 0x2000;
              }
            }
            if (uVar39 == 0xfffc) {
              iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + iVar21;
          }
          uVar40 = *(uint *)((longlong)ppsVar58 + 4);
          if ((*(ulonglong *)((longlong)ppsVar58 + 0x1e) != 0) &&
             (*(ulonglong *)((longlong)ppsVar58 + 0x1e) < (ulonglong)uVar40 + (longlong)ppsVar58[1])
             ) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar37 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8), lVar37 != 0 &&
                 (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                (*(char *)(lVar37 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x1109de;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x110a04;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
              }
            }
            psVar49 = ppsVar58[1];
            *(undefined8 *)(puVar43 + -8) = 0x110a12;
            func_0x(psVar49,0x12);
            uVar40 = *(uint *)((longlong)ppsVar58 + 4);
          }
          if (0x3f3b < uVar40 - 1) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar37 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar37 != 0 &&
                ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                 (*(char *)(lVar37 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x110a9d;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
                psVar49 = ppsVar58[1];
                *(undefined8 *)(puVar43 + -8) = 0x110aab;
                func_0x(psVar49,5);
                goto LAB_;
              }
              *(undefined8 *)(puVar43 + 0x20) = 0;
              *(undefined8 *)(puVar43 + -8) = 0x110ad1;
              (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
            }
            psVar49 = ppsVar58[1];
            *(undefined8 *)(puVar43 + -8) = 0x110adf;
            func_0x(psVar49,5);
          }
        }
LAB_:
        uVar40 = *(uint *)((longlong)ppsVar58 + 4);
        if (uVar40 < 9) {
          bVar34 = *(byte *)ppsVar58[1] & 0xe;
joined_r0x00110b23:
          if ((bVar34 == 0) || (bVar34 == 0xc)) {
            uVar40 = 9;
          }
        }
      }
      else {
        uVar40 = *(uint *)((longlong)ppsVar58 + 4);
        if (uVar40 == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x110b0f;
          func_0x(puVar55);
          uVar40 = *(uint *)((longlong)ppsVar58 + 4);
        }
        if (uVar40 < 9) {
          bVar34 = *(byte *)ppsVar58[1] & 0x1c;
          goto joined_r0x00110b23;
        }
      }
      *pbVar5 = 0;
      puVar55 = (ushort *)(psVar57 + 1);
      if (*psVar57 == 0) {
        if (*(int *)(psVar57 + 2) == 0) {
          *puVar55 = 0;
          uVar48 = *(uint *)(psVar57 + 8);
          uVar41 = (ulonglong)uVar48;
          *(uint *)(psVar57 + 10) = uVar48;
          pbVar3 = *(byte **)(psVar57 + 4);
          bVar34 = *pbVar3;
          if ((bVar34 & 0x10) != 0) {
            uVar48 = uVar48 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3) + 2;
            uVar41 = (ulonglong)uVar48;
            *(uint *)(psVar57 + 10) = uVar48;
            bVar34 = *pbVar3;
          }
          if ((bVar34 & 0x20) == 0) {
            *(int *)(psVar57 + 2) = (int)uVar41;
            psVar57[0xe] = 0;
            *(uint *)(psVar57 + 0xc) = uVar48;
          }
          else {
            puVar44 = (ushort *)(pbVar3 + uVar41);
            uVar39 = *puVar44;
            psVar57[0xe] = uVar39;
            if (uVar39 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x110c14;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x110c3a;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x110c48;
              func_0x(uVar25,3);
              uVar39 = psVar57[0xe];
            }
            uVar48 = *(int *)(psVar57 + 10) + (uVar39 + 1) * 2;
            *(uint *)(psVar57 + 0xc) = uVar48;
            if (0x1f9e < uVar48) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x110ce0;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x110d06;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x110d14;
              func_0x(uVar25,4);
            }
            uVar39 = puVar44[(ushort)psVar57[0xe]];
            *(uint *)(psVar57 + 2) = uVar39 & 0x7fff;
            if ((uVar39 & 0x7fff) < *(uint *)(psVar57 + 0xc)) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x110da8;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x110dce;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x110ddc;
              func_0x(uVar25,4);
            }
            do {
              uVar39 = psVar57[0xe];
              if (-1 < (short)puVar44[(ulonglong)(uVar39 - 1) + 1]) break;
              lVar37 = *(longlong *)(psVar57 + 4);
              lVar26 = (ulonglong)*(uint *)(psVar57 + 10) + lVar37;
              uVar48 = (uint)uVar39;
              if (uVar48 == 1) {
                uVar45 = *(uint *)(psVar57 + 0xc);
                uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar48 * 2);
                uVar48 = uVar45;
LAB_:
                if ((uVar39 & 0x7fff) < uVar45) goto LAB_;
              }
              else {
                uVar45 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar48 * 2) & 0x7fff;
                uVar48 = *(uint *)(psVar57 + 0xc);
                uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                if (uVar48 <= uVar45) goto LAB_;
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x110e46;
                func_0x(lVar37,7);
                uVar48 = *(uint *)(psVar57 + 0xc);
                lVar37 = *(longlong *)(psVar57 + 4);
              }
              if ((uVar45 < uVar48) || (*(uint *)(psVar57 + 2) < uVar45)) goto LAB_;
              if (*(ushort *)(lVar37 + (ulonglong)uVar45) == 5) {
                *puVar55 = *puVar55 | 2;
                psVar57[0xe] = psVar57[0xe] + -1;
                psVar57[0x15] = (short)uVar45;
                lVar37 = (ulonglong)(uVar45 & 0xffff) + *(longlong *)(psVar57 + 4);
                uVar39 = psVar57[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar37 + 2) & 0x4000) != 0) {
                  uVar39 = *(ushort *)(lVar37 + 2) & 0x3800 | psVar57[0x16] & 0xc7ffU;
                }
                psVar57[0x16] = uVar39;
                psVar57[0x16] = (uVar39 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar39;
                break;
              }
              if (*(ushort *)(lVar37 + (ulonglong)uVar45) < 0x400) break;
              *puVar55 = *puVar55 | 1;
              psVar49 = psVar57 + 0xe;
              *psVar49 = *psVar49 + -1;
            } while (*psVar49 != 0);
          }
          iVar21 = 0;
          if ((**(byte **)(psVar57 + 4) & 0x40) == 0) {
            *(undefined4 *)(psVar57 + 0x13) = 0;
          }
          else {
            *(int *)(psVar57 + 0x13) = *(int *)(psVar57 + 2);
            *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + 0xe;
            *(undefined8 *)(puVar43 + -8) = 0x110f27;
            puVar27 = (ulonglong *)func_0x(puVar55);
            uVar41 = *puVar27;
            *(ulonglong *)(&stack0x00000298 + lVar23) = uVar41;
            uVar35 = (ushort)(uVar41 >> 0x30);
            uVar39 = uVar35;
            if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
              uVar39 = uVar35 & 0xdfff;
              if ((uVar41 & 0x4000000000000000) != 0) {
                uVar39 = uVar35 | 0x2000;
              }
            }
            if (uVar39 == 0xfffc) {
              iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + iVar21;
          }
          uVar48 = *(uint *)(psVar57 + 2);
          if ((*(ulonglong *)(psVar57 + 0xf) != 0) &&
             (*(ulonglong *)(psVar57 + 0xf) < (ulonglong)uVar48 + *(longlong *)(psVar57 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar37 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8), lVar37 != 0 &&
                 (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                (*(char *)(lVar37 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x111022;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x111048;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
              }
            }
            uVar25 = *(undefined8 *)(psVar57 + 4);
            *(undefined8 *)(puVar43 + -8) = 0x111056;
            func_0x(uVar25,0x12);
            uVar48 = *(uint *)(psVar57 + 2);
          }
          if (0x3f3b < uVar48 - 1) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar37 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar37 != 0 &&
                ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                 (*(char *)(lVar37 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x1110e1;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x111107;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
              }
            }
            uVar25 = *(undefined8 *)(psVar57 + 4);
            *(undefined8 *)(puVar43 + -8) = 0x111115;
            func_0x(uVar25,5);
          }
        }
LAB_:
        uVar48 = *(uint *)(psVar57 + 2);
        *(uint *)(&stack0x00000044 + lVar23) = uVar48;
        if (uVar48 < 9) {
          bVar34 = **(byte **)(psVar57 + 4);
          if (((bVar34 & 0xe) != 0) && ((bVar34 & 0xe) != 0xc)) goto LAB_;
          uVar48 = 9;
          *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
        }
        else {
LAB_:
          bVar34 = **(byte **)(psVar57 + 4);
        }
        if ((bVar34 & 0x40) != 0) {
          uVar48 = *(uint *)(psVar57 + 0x13);
LAB_:
          *(uint *)(&stack0x00000044 + lVar23) = uVar48;
        }
      }
      else {
        uVar48 = *(uint *)(psVar57 + 2);
        *(uint *)(&stack0x00000044 + lVar23) = uVar48;
        if (uVar48 == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x11115f;
          func_0x(puVar55);
          uVar48 = *(uint *)(psVar57 + 2);
          *(uint *)(&stack0x00000044 + lVar23) = uVar48;
          if (uVar48 == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x111171;
            func_0x(puVar55);
            uVar48 = *(uint *)(psVar57 + 2);
            *(uint *)(&stack0x00000044 + lVar23) = uVar48;
          }
        }
        if (uVar48 < 9) {
          bVar34 = **(byte **)(psVar57 + 4);
          if (((bVar34 & 0x1c) != 0) && ((bVar34 & 0x1c) != 0xc)) goto LAB_;
          uVar48 = 9;
          *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
        }
        else {
LAB_:
          bVar34 = **(byte **)(psVar57 + 4);
        }
        if ((bVar34 & 2) != 0) {
          uVar48 = *(uint *)(psVar57 + 0x18);
          goto LAB_;
        }
      }
      plVar51 = *(longlong **)(&stack0x00000060 + lVar23);
      pcVar8 = *(code **)*plVar51;
      *(undefined8 *)(puVar43 + -8) = 0x1111ba;
      cVar18 = (*pcVar8)(plVar51);
      if (cVar18 == '\0') {
        if (((&stack0x000003c8)[lVar23] & 1) != 0) {
          if (*psVar57 == 0) {
            bVar59 = (**(byte **)(psVar57 + 4) & 0xe) == 2;
          }
          else {
            bVar59 = ((**(byte **)(psVar57 + 4) & 0x1c) - 0x10 & 0xfffffffb) == 0;
          }
          if (!bVar59) goto LAB_;
        }
        *(undefined8 *)(puVar43 + -8) = 0x1118b2;
        lVar37 = func_0x(plVar51);
        if (((&stack0x000003d0)[lVar23] & 1) != 0) goto LAB_;
        pcVar8 = *(code **)*plVar51;
        *(undefined8 *)(puVar43 + -8) = 0x1118ca;
        cVar18 = (*pcVar8)(plVar51);
        if (cVar18 != '\0') goto LAB_;
        pcVar8 = *(code **)(*plVar51 + 0x88);
        *(undefined8 *)(puVar43 + -8) = 0x1118de;
        cVar18 = (*pcVar8)(plVar51);
        if (cVar18 != '\0') {
          if ((&stack0x000003d1)[lVar23] != '\0') goto LAB_;
          if (lVar37 == 0) {
            pcVar8 = *(code **)(*plVar51 + 0x18);
            *(undefined8 *)(puVar43 + -8) = 0x111901;
            cVar18 = (*pcVar8)(plVar51);
            if (cVar18 == '\0') goto LAB_;
          }
          if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
            if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
              if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                *(undefined8 *)(puVar43 + -8) = 0x111935;
                lVar26 = func_0x(plVar51);
                if (lVar26 == 0) {
                  pcVar8 = *(code **)(*plVar51 + 0x88);
                  *(undefined8 *)(puVar43 + -8) = 0x111946;
                  cVar18 = (*pcVar8)(plVar51);
                  if (cVar18 != '\0') {
                    pcVar8 = *(code **)(*plVar51 + 0x18);
                    *(undefined8 *)(puVar43 + -8) = 0x111953;
                    cVar18 = (*pcVar8)(plVar51);
                    if (cVar18 == '\0') {
                      *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                      goto LAB_;
                    }
                  }
                }
                lVar26 = plVar51[6];
                *(undefined8 *)(puVar43 + -8) = 0x11196c;
                func_0x(lVar26);
                *(undefined8 *)(puVar43 + -8) = 0x111974;
                iVar21 = func_0x(plVar51);
                if (iVar21 == 0) {
                  pcVar8 = *(code **)(*plVar51 + 0x270);
                  *(undefined8 *)(puVar43 + -8) = 0x111984;
                  (*pcVar8)(plVar51);
                }
                if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                  if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                    *(undefined8 *)(puVar43 + -8) = 0x1119b8;
                    uVar25 = func_0x(plVar51);
                    *(undefined8 *)(puVar43 + -8) = 0x1119c0;
                    cVar18 = func_0x(uVar25);
                    if (cVar18 != '\0') {
                      *(undefined8 *)(puVar43 + -8) = 0x1119cc;
                      uVar25 = func_0x(plVar51);
                      *(undefined8 *)(puVar43 + -8) = 0x1119d4;
                      cVar18 = func_0x(uVar25);
                      if ((cVar18 != '\0') && (*_DAT_ != '\0')) {
                        *(undefined8 *)(puVar43 + -8) = 0x1119e9;
                        uVar25 = func_0x();
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x111a03;
                        func_0x(uVar25,0x1c,0x10,1);
                      }
                    }
                  }
                  uVar45 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                }
                else {
                  pcVar8 = *(code **)(*plVar51 + 0x1e8);
                  *(undefined8 *)(puVar43 + -8) = 0x111999;
                  uVar25 = (*pcVar8)(plVar51);
                  *(undefined8 *)(puVar43 + -8) = 0x1119a1;
                  uVar45 = func_0x(uVar25);
                }
                if (uVar45 != 0) goto LAB_;
              }
            }
            else {
LAB_:
              if (((*(byte *)(plVar51 + 0x4a) & 0x40) != 0) && ((&stack0x000003d2)[lVar23] != '\0'))
              goto LAB_;
            }
          }
        }
LAB_:
        if (((&stack0x000003d0)[lVar23] & 0x1c) != 0) goto LAB_;
        if (*(longlong *)(&stack0x000003d8 + lVar23) != 0) {
          *(undefined8 *)(puVar43 + -8) = 0x111a4e;
          iVar21 = func_0x();
          if (iVar21 != 0) {
            uVar25 = *(undefined8 *)(&stack0x000003d8 + lVar23);
            *(undefined8 *)(puVar43 + -8) = 0x111a5e;
            iVar21 = func_0x(uVar25);
            if (iVar21 != 0) {
              *(undefined8 *)(puVar43 + 0x20) = 0;
              *(undefined8 *)(puVar43 + -8) = 0x111a86;
              (*_DAT_)(1,0x1a263c0,0x1a26410,0x116);
            }
          }
          uVar25 = *(undefined8 *)(&stack0x000003d8 + lVar23);
          *(undefined8 *)(puVar43 + -8) = 0x111a92;
          iVar21 = func_0x(uVar25);
          if (iVar21 != 0) {
            uVar25 = *(undefined8 *)(&stack0x000003d8 + lVar23);
            *(undefined8 *)(puVar43 + -8) = 0x111aa2;
            iVar21 = func_0x(uVar25);
            if (iVar21 == 0) {
              uVar25 = *(undefined8 *)(&stack0x000003d8 + lVar23);
              *(undefined8 *)(puVar43 + -8) = 0x111ab2;
              iVar21 = func_0x(uVar25);
              if (iVar21 != 0) {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x111ada;
                (*_DAT_)(1,0x1a26440,0x1a26410,0x119);
              }
            }
          }
        }
        if (lVar37 == 0) {
LAB_:
          if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
            if ((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0) {
LAB_:
              if (lVar37 != 0) goto LAB_;
              goto LAB_;
            }
            if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
              *(undefined8 *)(puVar43 + -8) = 0x111b1b;
              lVar26 = func_0x(plVar51);
              if (lVar26 == 0) {
                pcVar8 = *(code **)(*plVar51 + 0x88);
                *(undefined8 *)(puVar43 + -8) = 0x111b2c;
                cVar18 = (*pcVar8)(plVar51);
                if (cVar18 != '\0') {
                  pcVar8 = *(code **)(*plVar51 + 0x18);
                  *(undefined8 *)(puVar43 + -8) = 0x111b39;
                  cVar18 = (*pcVar8)(plVar51);
                  if (cVar18 == '\0') {
                    *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                    goto LAB_;
                  }
                }
              }
              lVar26 = plVar51[6];
              *(undefined8 *)(puVar43 + -8) = 0x111b55;
              func_0x(lVar26);
              *(undefined8 *)(puVar43 + -8) = 0x111b5d;
              iVar21 = func_0x(plVar51);
              if (iVar21 == 0) {
                pcVar8 = *(code **)(*plVar51 + 0x270);
                *(undefined8 *)(puVar43 + -8) = 0x111b6d;
                (*pcVar8)(plVar51);
              }
              if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                  *(undefined8 *)(puVar43 + -8) = 0x111ba1;
                  uVar25 = func_0x(plVar51);
                  *(undefined8 *)(puVar43 + -8) = 0x111ba9;
                  cVar18 = func_0x(uVar25);
                  if (cVar18 != '\0') {
                    *(undefined8 *)(puVar43 + -8) = 0x111bb5;
                    uVar25 = func_0x(plVar51);
                    *(undefined8 *)(puVar43 + -8) = 0x111bbd;
                    cVar18 = func_0x(uVar25);
                    if ((cVar18 != '\0') && (*_DAT_ != '\0')) {
                      *(undefined8 *)(puVar43 + -8) = 0x111bd2;
                      uVar25 = func_0x();
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x111bec;
                      func_0x(uVar25,0x1c,0x10,1);
                    }
                  }
                }
                uVar45 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
              }
              else {
                pcVar8 = *(code **)(*plVar51 + 0x1e8);
                *(undefined8 *)(puVar43 + -8) = 0x111b82;
                uVar25 = (*pcVar8)(plVar51);
                *(undefined8 *)(puVar43 + -8) = 0x111b8a;
                uVar45 = func_0x(uVar25);
              }
              if (uVar45 != 0) goto LAB_;
            }
          }
          goto LAB_;
        }
        *(undefined8 *)(puVar43 + -8) = 0x111ae7;
        cVar18 = func_0x(lVar37);
        if (cVar18 == '\0') goto LAB_;
LAB_:
        if (((&stack0x000003d0)[lVar23] & 0x1c) == 0) {
          if (*(longlong *)(&stack0x000003d8 + lVar23) != 0) {
            *(undefined8 *)(puVar43 + -8) = 0x111c2e;
            iVar21 = func_0x();
            if (iVar21 != 0) {
              uVar25 = *(undefined8 *)(&stack0x000003d8 + lVar23);
              *(undefined8 *)(puVar43 + -8) = 0x111c3e;
              iVar21 = func_0x(uVar25);
              if (iVar21 != 0) {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x111c66;
                (*_DAT_)(1,0x1a263c0,0x1a26410,0x116);
              }
            }
            uVar25 = *(undefined8 *)(&stack0x000003d8 + lVar23);
            *(undefined8 *)(puVar43 + -8) = 0x111c72;
            iVar21 = func_0x(uVar25);
            if (iVar21 != 0) {
              uVar25 = *(undefined8 *)(&stack0x000003d8 + lVar23);
              *(undefined8 *)(puVar43 + -8) = 0x111c82;
              iVar21 = func_0x(uVar25);
              if (iVar21 == 0) {
                uVar25 = *(undefined8 *)(&stack0x000003d8 + lVar23);
                *(undefined8 *)(puVar43 + -8) = 0x111c92;
                iVar21 = func_0x(uVar25);
                if (iVar21 != 0) {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x111cba;
                  (*_DAT_)(1,0x1a26440,0x1a26410,0x119);
                }
              }
            }
          }
          *(undefined8 *)(puVar43 + -8) = 0x111cc2;
          cVar18 = func_0x(lVar37);
          if (cVar18 == '\0') {
            if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
                if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                  *(undefined8 *)(puVar43 + -8) = 0x111cf6;
                  lVar26 = func_0x(plVar51);
                  if (lVar26 == 0) {
                    pcVar8 = *(code **)(*plVar51 + 0x88);
                    *(undefined8 *)(puVar43 + -8) = 0x111d07;
                    cVar18 = (*pcVar8)(plVar51);
                    if (cVar18 != '\0') {
                      pcVar8 = *(code **)(*plVar51 + 0x18);
                      *(undefined8 *)(puVar43 + -8) = 0x111d14;
                      cVar18 = (*pcVar8)(plVar51);
                      if (cVar18 == '\0') {
                        *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                        goto LAB_;
                      }
                    }
                  }
                  lVar26 = plVar51[6];
                  *(undefined8 *)(puVar43 + -8) = 0x111d2d;
                  func_0x(lVar26);
                  *(undefined8 *)(puVar43 + -8) = 0x111d35;
                  iVar21 = func_0x(plVar51);
                  if (iVar21 == 0) {
                    pcVar8 = *(code **)(*plVar51 + 0x270);
                    *(undefined8 *)(puVar43 + -8) = 0x111d45;
                    (*pcVar8)(plVar51);
                  }
                  if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                    if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                      *(undefined8 *)(puVar43 + -8) = 0x111d79;
                      uVar25 = func_0x(plVar51);
                      *(undefined8 *)(puVar43 + -8) = 0x111d81;
                      cVar18 = func_0x(uVar25);
                      if (cVar18 != '\0') {
                        *(undefined8 *)(puVar43 + -8) = 0x111d8d;
                        uVar25 = func_0x(plVar51);
                        *(undefined8 *)(puVar43 + -8) = 0x111d95;
                        cVar18 = func_0x(uVar25);
                        if ((cVar18 != '\0') && (*_DAT_ != '\0')) {
                          *(undefined8 *)(puVar43 + -8) = 0x111daa;
                          uVar25 = func_0x();
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x111dc4;
                          func_0x(uVar25,0x1c,0x10,1);
                        }
                      }
                    }
                    uVar45 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                  }
                  else {
                    pcVar8 = *(code **)(*plVar51 + 0x1e8);
                    *(undefined8 *)(puVar43 + -8) = 0x111d5a;
                    uVar25 = (*pcVar8)(plVar51);
                    *(undefined8 *)(puVar43 + -8) = 0x111d62;
                    uVar45 = func_0x(uVar25);
                  }
                  if (uVar45 != 0) goto LAB_;
                }
              }
              else {
LAB_:
                if ((*(byte *)(plVar51 + 0x4a) & 0x10) != 0) goto LAB_;
              }
            }
LAB_:
            if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
                if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                  *(undefined8 *)(puVar43 + -8) = 0x111e10;
                  lVar26 = func_0x(plVar51);
                  if (lVar26 == 0) {
                    pcVar8 = *(code **)(*plVar51 + 0x88);
                    *(undefined8 *)(puVar43 + -8) = 0x111e21;
                    cVar18 = (*pcVar8)(plVar51);
                    if (cVar18 != '\0') {
                      pcVar8 = *(code **)(*plVar51 + 0x18);
                      *(undefined8 *)(puVar43 + -8) = 0x111e2e;
                      cVar18 = (*pcVar8)(plVar51);
                      if (cVar18 == '\0') {
                        *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                        goto LAB_;
                      }
                    }
                  }
                  lVar26 = plVar51[6];
                  *(undefined8 *)(puVar43 + -8) = 0x111e47;
                  func_0x(lVar26);
                  *(undefined8 *)(puVar43 + -8) = 0x111e4f;
                  iVar21 = func_0x(plVar51);
                  if (iVar21 == 0) {
                    pcVar8 = *(code **)(*plVar51 + 0x270);
                    *(undefined8 *)(puVar43 + -8) = 0x111e5f;
                    (*pcVar8)(plVar51);
                  }
                  if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                    if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                      *(undefined8 *)(puVar43 + -8) = 0x111e93;
                      uVar25 = func_0x(plVar51);
                      *(undefined8 *)(puVar43 + -8) = 0x111e9b;
                      cVar18 = func_0x(uVar25);
                      if (cVar18 != '\0') {
                        *(undefined8 *)(puVar43 + -8) = 0x111ea7;
                        uVar25 = func_0x(plVar51);
                        *(undefined8 *)(puVar43 + -8) = 0x111eaf;
                        cVar18 = func_0x(uVar25);
                        if ((cVar18 != '\0') && (*_DAT_ != '\0')) {
                          *(undefined8 *)(puVar43 + -8) = 0x111ec4;
                          uVar25 = func_0x();
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x111ede;
                          func_0x(uVar25,0x1c,0x10,1);
                        }
                      }
                    }
                    uVar45 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                  }
                  else {
                    pcVar8 = *(code **)(*plVar51 + 0x1e8);
                    *(undefined8 *)(puVar43 + -8) = 0x111e74;
                    uVar25 = (*pcVar8)(plVar51);
                    *(undefined8 *)(puVar43 + -8) = 0x111e7c;
                    uVar45 = func_0x(uVar25);
                  }
                  if (uVar45 != 0) goto LAB_;
                }
              }
              else {
LAB_:
                if ((*(byte *)(plVar51 + 0x4a) & 0x40) != 0) goto LAB_;
              }
            }
          }
        }
LAB_:
        *(undefined8 *)(puVar43 + -8) = 0x111f04;
        func_0x(lVar37,0);
LAB_:
        *(undefined8 *)(puVar43 + -8) = 0x111f0c;
        iVar21 = func_0x(plVar51);
        if (iVar21 == 0) {
          pcVar8 = *(code **)(*plVar51 + 0x270);
          *(undefined8 *)(puVar43 + -8) = 0x111f1c;
          (*pcVar8)(plVar51);
        }
        *(undefined8 *)(puVar43 + -8) = 0x111f24;
        lVar37 = func_0x(plVar51);
        if (((&stack0x000003d0)[lVar23] & 0x24) == 0) {
          if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
            if ((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0) goto LAB_;
            if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
              *(undefined8 *)(puVar43 + -8) = 0x111f62;
              lVar26 = func_0x(plVar51);
              if (lVar26 == 0) {
                pcVar8 = *(code **)(*plVar51 + 0x88);
                *(undefined8 *)(puVar43 + -8) = 0x111f73;
                cVar18 = (*pcVar8)(plVar51);
                if (cVar18 != '\0') {
                  pcVar8 = *(code **)(*plVar51 + 0x18);
                  *(undefined8 *)(puVar43 + -8) = 0x111f80;
                  cVar18 = (*pcVar8)(plVar51);
                  if (cVar18 == '\0') {
                    *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                    goto LAB_;
                  }
                }
              }
              lVar26 = plVar51[6];
              *(undefined8 *)(puVar43 + -8) = 0x111f99;
              func_0x(lVar26);
              *(undefined8 *)(puVar43 + -8) = 0x111fa1;
              iVar21 = func_0x(plVar51);
              if (iVar21 == 0) {
                pcVar8 = *(code **)(*plVar51 + 0x270);
                *(undefined8 *)(puVar43 + -8) = 0x111fb1;
                (*pcVar8)(plVar51);
              }
              if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                  *(undefined8 *)(puVar43 + -8) = 0x111fe5;
                  uVar25 = func_0x(plVar51);
                  *(undefined8 *)(puVar43 + -8) = 0x111fed;
                  cVar18 = func_0x(uVar25);
                  if (cVar18 != '\0') {
                    *(undefined8 *)(puVar43 + -8) = 0x111ff9;
                    uVar25 = func_0x(plVar51);
                    *(undefined8 *)(puVar43 + -8) = 0x112001;
                    cVar18 = func_0x(uVar25);
                    if ((cVar18 != '\0') && (*_DAT_ != '\0')) {
                      *(undefined8 *)(puVar43 + -8) = 0x112016;
                      uVar25 = func_0x();
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x112030;
                      func_0x(uVar25,0x1c,0x10,1);
                    }
                  }
                }
                uVar45 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
              }
              else {
                pcVar8 = *(code **)(*plVar51 + 0x1e8);
                *(undefined8 *)(puVar43 + -8) = 0x111fc6;
                uVar25 = (*pcVar8)(plVar51);
                *(undefined8 *)(puVar43 + -8) = 0x111fce;
                uVar45 = func_0x(uVar25);
              }
              if (uVar45 != 0) goto LAB_;
            }
          }
LAB_:
          if (lVar37 != 0) {
            *(undefined8 *)(puVar43 + -8) = 0x112054;
            cVar18 = func_0x(lVar37);
            if (cVar18 != '\0') goto LAB_;
          }
          goto LAB_;
        }
LAB_:
        pcVar8 = *(code **)(*plVar51 + 0x20);
        *(undefined8 *)(puVar43 + -8) = 0x112065;
        cVar18 = (*pcVar8)(plVar51);
        if (cVar18 == '\0') {
LAB_:
          iVar21 = *(int *)(&stack0x00000044 + lVar23);
          uVar36 = *(undefined4 *)(&stack0x00000028 + lVar23);
          uVar25 = *(undefined8 *)(&stack0x00000058 + lVar23);
LAB_:
          *(int *)(&stack0x00000044 + lVar23) = iVar21 + 0xe;
        }
        else {
          if (*psVar57 != 0) {
            *(undefined8 *)(puVar43 + -8) = 0x11207c;
            lVar37 = func_0x(puVar55);
            if (lVar37 != 0) {
              if (*psVar57 == 0) {
                uVar25 = 0;
              }
              else {
                *(undefined8 *)(puVar43 + -8) = 0x112094;
                uVar25 = func_0x(puVar55);
              }
              *(undefined8 *)(puVar43 + -8) = 0x11209c;
              iVar21 = func_0x(uVar25);
              if (iVar21 != 0) goto LAB_;
            }
          }
          if (*psVar57 == 0) {
            bVar59 = (**(byte **)(psVar57 + 4) & 0xe) == 2;
          }
          else {
            bVar59 = ((**(byte **)(psVar57 + 4) & 0x1c) - 0x10 & 0xfffffffb) == 0;
          }
          if (!bVar59) {
            if (*(short *)ppsVar54 == 0) {
              bVar59 = (*(byte *)ppsVar54[1] & 0xe) == 2;
            }
            else {
              bVar59 = ((*(byte *)ppsVar54[1] & 0x1c) - 0x10 & 0xfffffffb) == 0;
            }
            if ((bVar59) || (2000 < *(uint *)(&stack0x00000044 + lVar23))) goto LAB_;
            if (*(short *)ppsVar54 == 0) {
              if (*(int *)((longlong)ppsVar54 + 4) == 0) {
                *(undefined2 *)((longlong)ppsVar54 + 2) = 0;
                uVar45 = *(uint *)(ppsVar54 + 2);
                uVar41 = (ulonglong)uVar45;
                *(uint *)((longlong)ppsVar54 + 0x14) = uVar45;
                psVar57 = ppsVar54[1];
                bVar34 = *(byte *)psVar57;
                if ((bVar34 & 0x10) != 0) {
                  uVar45 = uVar45 + (*(ushort *)(uVar41 + (longlong)psVar57) + 7 >> 3) + 2;
                  uVar41 = (ulonglong)uVar45;
                  *(uint *)((longlong)ppsVar54 + 0x14) = uVar45;
                  bVar34 = *(byte *)psVar57;
                }
                if ((bVar34 & 0x20) == 0) {
                  *(int *)((longlong)ppsVar54 + 4) = (int)uVar41;
                  *(undefined2 *)((longlong)ppsVar54 + 0x1c) = 0;
                  *(uint *)(ppsVar54 + 3) = uVar45;
                }
                else {
                  puVar55 = (ushort *)(uVar41 + (longlong)psVar57);
                  uVar39 = *puVar55;
                  *(ushort *)((longlong)ppsVar54 + 0x1c) = uVar39;
                  if (uVar39 == 0) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                       ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                        (*(char *)(lVar37 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x1121ea;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x112210;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                      }
                    }
                    psVar57 = ppsVar54[1];
                    *(undefined8 *)(puVar43 + -8) = 0x11221e;
                    func_0x(psVar57,3);
                    uVar39 = *(ushort *)((longlong)ppsVar54 + 0x1c);
                  }
                  uVar45 = *(int *)((longlong)ppsVar54 + 0x14) + (uVar39 + 1) * 2;
                  *(uint *)(ppsVar54 + 3) = uVar45;
                  if (0x1f9e < uVar45) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                        ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                         (*(char *)(lVar37 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x1122b9;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x1122df;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                      }
                    }
                    psVar57 = ppsVar54[1];
                    *(undefined8 *)(puVar43 + -8) = 0x1122ed;
                    func_0x(psVar57,4);
                  }
                  uVar39 = puVar55[*(ushort *)((longlong)ppsVar54 + 0x1c)];
                  *(uint *)((longlong)ppsVar54 + 4) = uVar39 & 0x7fff;
                  if ((uVar39 & 0x7fff) < *(uint *)(ppsVar54 + 3)) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                       ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                        (*(char *)(lVar37 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x112384;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x1123aa;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                      }
                    }
                    psVar57 = ppsVar54[1];
                    *(undefined8 *)(puVar43 + -8) = 0x1123b8;
                    func_0x(psVar57,4);
                  }
                  do {
                    uVar39 = *(ushort *)((longlong)ppsVar54 + 0x1c);
                    if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                    psVar57 = ppsVar54[1];
                    uVar45 = *(uint *)((longlong)ppsVar54 + 0x14);
                    uVar46 = (uint)uVar39;
                    if (uVar46 == 1) {
                      uVar47 = *(uint *)(ppsVar54 + 3);
                      uVar39 = *(ushort *)
                                ((longlong)psVar57 + (longlong)(int)uVar46 * 2 + (ulonglong)uVar45);
                      uVar46 = uVar47;
LAB_:
                      if ((uVar39 & 0x7fff) < uVar47) goto LAB_;
                    }
                    else {
                      uVar47 = *(ushort *)
                                ((longlong)psVar57 +
                                (longlong)(int)uVar46 * 2 + ((ulonglong)uVar45 - 2)) & 0x7fff;
                      uVar46 = *(uint *)(ppsVar54 + 3);
                      uVar39 = *(ushort *)
                                ((longlong)psVar57 + (ulonglong)uVar39 * 2 + (ulonglong)uVar45);
                      if (uVar46 <= uVar47) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar43 + -8) = 0x112425;
                      func_0x(psVar57,7);
                      uVar46 = *(uint *)(ppsVar54 + 3);
                    }
                    if ((uVar47 < uVar46) || (*(uint *)((longlong)ppsVar54 + 4) < uVar47))
                    goto LAB_;
                    if (*(ushort *)((ulonglong)uVar47 + (longlong)ppsVar54[1]) == 5) {
                      *(ushort *)((longlong)ppsVar54 + 2) = *(ushort *)((longlong)ppsVar54 + 2) | 2;
                      *(short *)((longlong)ppsVar54 + 0x1c) =
                           *(short *)((longlong)ppsVar54 + 0x1c) + -1;
                      uVar45 = uVar47 & 0xffff;
                      *(short *)((longlong)ppsVar54 + 0x2a) = (short)uVar47;
                      psVar57 = ppsVar54[1];
                      uVar39 = *(ushort *)((longlong)ppsVar54 + 0x2c) & 0xc7ff;
                      if ((*(ushort *)((longlong)psVar57 + (ulonglong)uVar45 + 2) & 0x4000) != 0) {
                        uVar39 = *(ushort *)((longlong)psVar57 + (ulonglong)uVar45 + 2) & 0x3800 |
                                 uVar39;
                      }
                      *(ushort *)((longlong)ppsVar54 + 0x2c) = uVar39;
                      *(ushort *)((longlong)ppsVar54 + 0x2c) =
                           (uVar39 ^ *(ushort *)((longlong)psVar57 + (ulonglong)uVar45 + 2)) & 0x7ff
                           ^ uVar39;
                      break;
                    }
                    if (*(ushort *)((ulonglong)uVar47 + (longlong)ppsVar54[1]) < 0x400) break;
                    *(ushort *)((longlong)ppsVar54 + 2) = *(ushort *)((longlong)ppsVar54 + 2) | 1;
                    psVar57 = (short *)((longlong)ppsVar54 + 0x1c);
                    *psVar57 = *psVar57 + -1;
                  } while (*psVar57 != 0);
                }
                iVar21 = 0;
                if ((*(byte *)ppsVar54[1] & 0x40) == 0) {
                  *(undefined4 *)((longlong)ppsVar54 + 0x26) = 0;
                }
                else {
                  *(int *)((longlong)ppsVar54 + 0x26) = *(int *)((longlong)ppsVar54 + 4);
                  *(int *)((longlong)ppsVar54 + 4) = *(int *)((longlong)ppsVar54 + 4) + 0xe;
                  *(undefined8 *)(puVar43 + -8) = 0x112519;
                  puVar27 = (ulonglong *)func_0x((longlong)ppsVar54 + 2);
                  uVar41 = *puVar27;
                  *(ulonglong *)(&stack0x000002a8 + lVar23) = uVar41;
                  uVar35 = (ushort)(uVar41 >> 0x30);
                  uVar39 = uVar35;
                  if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                    uVar39 = uVar35 & 0xdfff;
                    if ((uVar41 & 0x4000000000000000) != 0) {
                      uVar39 = uVar35 | 0x2000;
                    }
                  }
                  if (uVar39 == 0xfffc) {
                    iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                  }
                  *(int *)((longlong)ppsVar54 + 4) = *(int *)((longlong)ppsVar54 + 4) + iVar21;
                }
                uVar45 = *(uint *)((longlong)ppsVar54 + 4);
                if ((*(ulonglong *)((longlong)ppsVar54 + 0x1e) != 0) &&
                   (*(ulonglong *)((longlong)ppsVar54 + 0x1e) <
                    (ulonglong)uVar45 + (longlong)ppsVar54[1])) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     (((lVar37 = *(longlong *)
                                  ((ulonglong)*_DAT_ +
                                   *(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                       (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x112616;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x11263c;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                    }
                  }
                  psVar57 = ppsVar54[1];
                  *(undefined8 *)(puVar43 + -8) = 0x11264a;
                  func_0x(psVar57,0x12);
                  uVar45 = *(uint *)((longlong)ppsVar54 + 4);
                }
                if (0x3f3b < uVar45 - 1) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                      ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                       (*(char *)(lVar37 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x1126d6;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x1126fc;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                    }
                  }
                  psVar57 = ppsVar54[1];
                  *(undefined8 *)(puVar43 + -8) = 0x11270a;
                  func_0x(psVar57,5);
                }
              }
LAB_:
              uVar45 = *(uint *)((longlong)ppsVar54 + 4);
              uVar46 = uVar45;
              if (uVar45 < 9) {
                bVar34 = *(byte *)ppsVar54[1] & 0xe;
joined_r0x00112748:
                if ((bVar34 == 0) || (uVar46 = uVar45, bVar34 == 0xc)) {
                  uVar46 = 9;
                }
              }
            }
            else {
              uVar45 = *(uint *)((longlong)ppsVar54 + 4);
              if (uVar45 == 0) {
                *(undefined8 *)(puVar43 + -8) = 0x112735;
                func_0x((longlong)ppsVar54 + 2);
                uVar45 = *(uint *)((longlong)ppsVar54 + 4);
              }
              uVar46 = uVar45;
              if (uVar45 < 9) {
                bVar34 = *(byte *)ppsVar54[1] & 0x1c;
                goto joined_r0x00112748;
              }
            }
            if (2000 < uVar46) goto LAB_;
            if (*(short *)ppsVar54 == 0) {
              if (uVar45 == 0) {
                *(undefined2 *)((longlong)ppsVar54 + 2) = 0;
                uVar45 = *(uint *)(ppsVar54 + 2);
                uVar41 = (ulonglong)uVar45;
                *(uint *)((longlong)ppsVar54 + 0x14) = uVar45;
                psVar57 = ppsVar54[1];
                bVar34 = *(byte *)psVar57;
                if ((bVar34 & 0x10) != 0) {
                  uVar45 = uVar45 + (*(ushort *)(uVar41 + (longlong)psVar57) + 7 >> 3) + 2;
                  uVar41 = (ulonglong)uVar45;
                  *(uint *)((longlong)ppsVar54 + 0x14) = uVar45;
                  bVar34 = *(byte *)psVar57;
                }
                if ((bVar34 & 0x20) == 0) {
                  *(int *)((longlong)ppsVar54 + 4) = (int)uVar41;
                  *(undefined2 *)((longlong)ppsVar54 + 0x1c) = 0;
                  *(uint *)(ppsVar54 + 3) = uVar45;
                }
                else {
                  puVar55 = (ushort *)(uVar41 + (longlong)psVar57);
                  uVar39 = *puVar55;
                  *(ushort *)((longlong)ppsVar54 + 0x1c) = uVar39;
                  if (uVar39 == 0) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                       ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                        (*(char *)(lVar37 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x112847;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x11286d;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                      }
                    }
                    psVar57 = ppsVar54[1];
                    *(undefined8 *)(puVar43 + -8) = 0x11287b;
                    func_0x(psVar57,3);
                    uVar39 = *(ushort *)((longlong)ppsVar54 + 0x1c);
                  }
                  uVar45 = *(int *)((longlong)ppsVar54 + 0x14) + (uVar39 + 1) * 2;
                  *(uint *)(ppsVar54 + 3) = uVar45;
                  if (0x1f9e < uVar45) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                        ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                         (*(char *)(lVar37 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x112916;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x11293c;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                      }
                    }
                    psVar57 = ppsVar54[1];
                    *(undefined8 *)(puVar43 + -8) = 0x11294a;
                    func_0x(psVar57,4);
                  }
                  uVar39 = puVar55[*(ushort *)((longlong)ppsVar54 + 0x1c)];
                  *(uint *)((longlong)ppsVar54 + 4) = uVar39 & 0x7fff;
                  if ((uVar39 & 0x7fff) < *(uint *)(ppsVar54 + 3)) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                       ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                        (*(char *)(lVar37 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x1129e1;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x112a07;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                      }
                    }
                    psVar57 = ppsVar54[1];
                    *(undefined8 *)(puVar43 + -8) = 0x112a15;
                    func_0x(psVar57,4);
                  }
                  do {
                    uVar39 = *(ushort *)((longlong)ppsVar54 + 0x1c);
                    if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                    psVar57 = ppsVar54[1];
                    uVar45 = *(uint *)((longlong)ppsVar54 + 0x14);
                    uVar46 = (uint)uVar39;
                    if (uVar46 == 1) {
                      uVar47 = *(uint *)(ppsVar54 + 3);
                      uVar39 = *(ushort *)
                                ((longlong)psVar57 + (longlong)(int)uVar46 * 2 + (ulonglong)uVar45);
                      uVar46 = uVar47;
LAB_:
                      if ((uVar39 & 0x7fff) < uVar47) goto LAB_;
                    }
                    else {
                      uVar47 = *(ushort *)
                                ((longlong)psVar57 +
                                (longlong)(int)uVar46 * 2 + ((ulonglong)uVar45 - 2)) & 0x7fff;
                      uVar46 = *(uint *)(ppsVar54 + 3);
                      uVar39 = *(ushort *)
                                ((longlong)psVar57 + (ulonglong)uVar39 * 2 + (ulonglong)uVar45);
                      if (uVar46 <= uVar47) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar43 + -8) = 0x112a82;
                      func_0x(psVar57,7);
                      uVar46 = *(uint *)(ppsVar54 + 3);
                    }
                    if ((uVar47 < uVar46) || (*(uint *)((longlong)ppsVar54 + 4) < uVar47))
                    goto LAB_;
                    if (*(ushort *)((ulonglong)uVar47 + (longlong)ppsVar54[1]) == 5) {
                      *(ushort *)((longlong)ppsVar54 + 2) = *(ushort *)((longlong)ppsVar54 + 2) | 2;
                      *(short *)((longlong)ppsVar54 + 0x1c) =
                           *(short *)((longlong)ppsVar54 + 0x1c) + -1;
                      uVar45 = uVar47 & 0xffff;
                      *(short *)((longlong)ppsVar54 + 0x2a) = (short)uVar47;
                      psVar57 = ppsVar54[1];
                      uVar39 = *(ushort *)((longlong)ppsVar54 + 0x2c) & 0xc7ff;
                      if ((*(ushort *)((longlong)psVar57 + (ulonglong)uVar45 + 2) & 0x4000) != 0) {
                        uVar39 = *(ushort *)((longlong)psVar57 + (ulonglong)uVar45 + 2) & 0x3800 |
                                 uVar39;
                      }
                      *(ushort *)((longlong)ppsVar54 + 0x2c) = uVar39;
                      *(ushort *)((longlong)ppsVar54 + 0x2c) =
                           (uVar39 ^ *(ushort *)((longlong)psVar57 + (ulonglong)uVar45 + 2)) & 0x7ff
                           ^ uVar39;
                      break;
                    }
                    if (*(ushort *)((ulonglong)uVar47 + (longlong)ppsVar54[1]) < 0x400) break;
                    *(ushort *)((longlong)ppsVar54 + 2) = *(ushort *)((longlong)ppsVar54 + 2) | 1;
                    psVar57 = (short *)((longlong)ppsVar54 + 0x1c);
                    *psVar57 = *psVar57 + -1;
                  } while (*psVar57 != 0);
                }
                iVar21 = 0;
                if ((*(byte *)ppsVar54[1] & 0x40) == 0) {
                  *(undefined4 *)((longlong)ppsVar54 + 0x26) = 0;
                }
                else {
                  *(undefined4 *)((longlong)ppsVar54 + 0x26) =
                       *(undefined4 *)((longlong)ppsVar54 + 4);
                  *(int *)((longlong)ppsVar54 + 4) = *(int *)((longlong)ppsVar54 + 4) + 0xe;
                  *(undefined8 *)(puVar43 + -8) = 0x112b74;
                  puVar27 = (ulonglong *)func_0x((longlong)ppsVar54 + 2);
                  uVar41 = *puVar27;
                  *(ulonglong *)(&stack0x000002b0 + lVar23) = uVar41;
                  uVar35 = (ushort)(uVar41 >> 0x30);
                  uVar39 = uVar35;
                  if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                    uVar39 = uVar35 & 0xdfff;
                    if ((uVar41 & 0x4000000000000000) != 0) {
                      uVar39 = uVar35 | 0x2000;
                    }
                  }
                  if (uVar39 == 0xfffc) {
                    iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                  }
                  *(int *)((longlong)ppsVar54 + 4) = *(int *)((longlong)ppsVar54 + 4) + iVar21;
                }
                uVar45 = *(uint *)((longlong)ppsVar54 + 4);
                if ((*(ulonglong *)((longlong)ppsVar54 + 0x1e) != 0) &&
                   (*(ulonglong *)((longlong)ppsVar54 + 0x1e) <
                    (ulonglong)uVar45 + (longlong)ppsVar54[1])) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     (((lVar37 = *(longlong *)
                                  ((ulonglong)*_DAT_ +
                                   *(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                       (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x112c71;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x112c97;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                    }
                  }
                  psVar57 = ppsVar54[1];
                  *(undefined8 *)(puVar43 + -8) = 0x112ca5;
                  func_0x(psVar57,0x12);
                  uVar45 = *(uint *)((longlong)ppsVar54 + 4);
                }
                if (0x3f3b < uVar45 - 1) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                      ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                       (*(char *)(lVar37 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x112d31;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x112d57;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                    }
                  }
                  psVar57 = ppsVar54[1];
                  *(undefined8 *)(puVar43 + -8) = 0x112d65;
                  func_0x(psVar57,5);
                }
              }
LAB_:
              uVar45 = *(uint *)((longlong)ppsVar54 + 4);
              if (uVar45 < 9) {
                bVar34 = *(byte *)ppsVar54[1] & 0xe;
joined_r0x00112d9f:
                if ((bVar34 == 0) || (bVar34 == 0xc)) {
                  uVar45 = 9;
                }
              }
            }
            else {
              if (uVar45 == 0) {
                *(undefined8 *)(puVar43 + -8) = 0x112d8c;
                func_0x((longlong)ppsVar54 + 2);
                uVar45 = *(uint *)((longlong)ppsVar54 + 4);
              }
              if (uVar45 < 9) {
                bVar34 = *(byte *)ppsVar54[1] & 0x1c;
                goto joined_r0x00112d9f;
              }
            }
            if (uVar45 < 0x15) goto LAB_;
            iVar21 = *(int *)(&stack0x00000044 + lVar23) + 200;
            *(int *)(puVar43 + 0x20) = iVar21;
            uVar36 = *(undefined4 *)(&stack0x00000028 + lVar23);
            uVar25 = *(undefined8 *)(&stack0x00000058 + lVar23);
            plVar51 = *(longlong **)(&stack0x00000060 + lVar23);
            *(undefined8 *)(puVar43 + -8) = 0x112ddc;
            cVar18 = func_0x(plVar51,uVar25,uVar36,uVar40);
            if (cVar18 == '\0') {
              *pbVar5 = 1;
              *(uint *)(&stack0x00000044 + lVar23) = uVar48 + 0xe;
              goto LAB_;
            }
            goto LAB_;
          }
LAB_:
          *(undefined8 *)(puVar43 + -8) = 0x112dfe;
          iVar21 = func_0x(ppsVar54);
          if (iVar21 != 0) {
LAB_:
            plVar51 = *(longlong **)(&stack0x00000060 + lVar23);
            goto LAB_;
          }
          *(undefined4 *)(&stack0x00000098 + lVar23) = 0;
          *(undefined2 *)(&stack0x0000009c + lVar23) = 0;
          *(undefined8 *)(puVar43 + -8) = 0x112e27;
          uVar25 = func_0x(ppsVar54,&stack0x0000009e + lVar23);
          *(undefined8 *)(puVar43 + -8) = 0x112e36;
          iVar21 = func_0x(&stack0x00000098 + lVar23,uVar25);
          if (iVar21 == 0) goto LAB_;
          *(undefined8 *)(puVar43 + -8) = 0x112e4d;
          lVar37 = func_0x(ppsVar54,&stack0x000002b8 + lVar23);
          uVar39 = *(ushort *)(lVar37 + 6);
          uVar35 = uVar39;
          if (((((uint)(int)(short)uVar39 >> 1 ^ (int)(short)uVar39) & 0x2000) != 0) &&
             (uVar35 = uVar39 & 0xdfff, (uVar39 & 0x4000) != 0)) {
            uVar35 = uVar39 | 0x2000;
          }
          if (uVar35 == 0xfffc) goto LAB_;
          if (*(short *)ppsVar54 == 0) {
            if (*(int *)((longlong)ppsVar54 + 4) == 0) {
              *(undefined2 *)((longlong)ppsVar54 + 2) = 0;
              uVar40 = *(uint *)(ppsVar54 + 2);
              uVar41 = (ulonglong)uVar40;
              *(uint *)((longlong)ppsVar54 + 0x14) = uVar40;
              psVar57 = ppsVar54[1];
              bVar34 = *(byte *)psVar57;
              if ((bVar34 & 0x10) != 0) {
                uVar40 = uVar40 + (*(ushort *)(uVar41 + (longlong)psVar57) + 7 >> 3) + 2;
                uVar41 = (ulonglong)uVar40;
                *(uint *)((longlong)ppsVar54 + 0x14) = uVar40;
                bVar34 = *(byte *)psVar57;
              }
              if ((bVar34 & 0x20) == 0) {
                *(int *)((longlong)ppsVar54 + 4) = (int)uVar41;
                *(undefined2 *)((longlong)ppsVar54 + 0x1c) = 0;
                *(uint *)(ppsVar54 + 3) = uVar40;
              }
              else {
                puVar55 = (ushort *)(uVar41 + (longlong)psVar57);
                uVar39 = *puVar55;
                *(ushort *)((longlong)ppsVar54 + 0x1c) = uVar39;
                if (uVar39 == 0) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                     ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x112f71;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x112f97;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                    }
                  }
                  psVar57 = ppsVar54[1];
                  *(undefined8 *)(puVar43 + -8) = 0x112fa5;
                  func_0x(psVar57,3);
                  uVar39 = *(ushort *)((longlong)ppsVar54 + 0x1c);
                }
                uVar40 = *(int *)((longlong)ppsVar54 + 0x14) + (uVar39 + 1) * 2;
                *(uint *)(ppsVar54 + 3) = uVar40;
                if (0x1f9e < uVar40) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                      ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                       (*(char *)(lVar37 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x113040;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x113066;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                    }
                  }
                  psVar57 = ppsVar54[1];
                  *(undefined8 *)(puVar43 + -8) = 0x113074;
                  func_0x(psVar57,4);
                }
                uVar39 = puVar55[*(ushort *)((longlong)ppsVar54 + 0x1c)];
                *(uint *)((longlong)ppsVar54 + 4) = uVar39 & 0x7fff;
                if ((uVar39 & 0x7fff) < *(uint *)(ppsVar54 + 3)) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                     ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x11310b;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x113131;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                    }
                  }
                  psVar57 = ppsVar54[1];
                  *(undefined8 *)(puVar43 + -8) = 0x11313f;
                  func_0x(psVar57,4);
                }
                do {
                  uVar39 = *(ushort *)((longlong)ppsVar54 + 0x1c);
                  if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                  psVar57 = ppsVar54[1];
                  uVar40 = *(uint *)((longlong)ppsVar54 + 0x14);
                  uVar48 = (uint)uVar39;
                  if (uVar48 == 1) {
                    uVar45 = *(uint *)(ppsVar54 + 3);
                    uVar39 = *(ushort *)
                              ((longlong)psVar57 + (longlong)(int)uVar48 * 2 + (ulonglong)uVar40);
                    uVar48 = uVar45;
LAB_:
                    if ((uVar39 & 0x7fff) < uVar45) goto LAB_;
                  }
                  else {
                    uVar45 = *(ushort *)
                              ((longlong)psVar57 +
                              (longlong)(int)uVar48 * 2 + ((ulonglong)uVar40 - 2)) & 0x7fff;
                    uVar48 = *(uint *)(ppsVar54 + 3);
                    uVar39 = *(ushort *)
                              ((longlong)psVar57 + (ulonglong)uVar39 * 2 + (ulonglong)uVar40);
                    if (uVar48 <= uVar45) goto LAB_;
LAB_:
                    *(undefined8 *)(puVar43 + -8) = 0x1131ac;
                    func_0x(psVar57,7);
                    uVar48 = *(uint *)(ppsVar54 + 3);
                  }
                  if ((uVar45 < uVar48) || (*(uint *)((longlong)ppsVar54 + 4) < uVar45))
                  goto LAB_;
                  psVar57 = ppsVar54[1];
                  if (*(ushort *)((ulonglong)uVar45 + (longlong)psVar57) == 5) {
                    *(ushort *)((longlong)ppsVar54 + 2) = *(ushort *)((longlong)ppsVar54 + 2) | 2;
                    *(short *)((longlong)ppsVar54 + 0x1c) =
                         *(short *)((longlong)ppsVar54 + 0x1c) + -1;
                    uVar40 = uVar45 & 0xffff;
                    *(short *)((longlong)ppsVar54 + 0x2a) = (short)uVar45;
                    uVar39 = *(ushort *)((longlong)ppsVar54 + 0x2c) & 0xc7ff;
                    if ((*(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x4000) != 0) {
                      uVar39 = *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x3800 |
                               uVar39;
                    }
                    *(ushort *)((longlong)ppsVar54 + 0x2c) = uVar39;
                    *(ushort *)((longlong)ppsVar54 + 0x2c) =
                         (uVar39 ^ *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2)) & 0x7ff ^
                         uVar39;
                    break;
                  }
                  if (*(ushort *)((ulonglong)uVar45 + (longlong)psVar57) < 0x400) break;
                  *(ushort *)((longlong)ppsVar54 + 2) = *(ushort *)((longlong)ppsVar54 + 2) | 1;
                  psVar57 = (short *)((longlong)ppsVar54 + 0x1c);
                  *psVar57 = *psVar57 + -1;
                } while (*psVar57 != 0);
              }
              iVar21 = 0;
              if ((*(byte *)ppsVar54[1] & 0x40) == 0) {
                *(undefined4 *)((longlong)ppsVar54 + 0x26) = 0;
              }
              else {
                *(int *)((longlong)ppsVar54 + 0x26) = *(int *)((longlong)ppsVar54 + 4);
                *(int *)((longlong)ppsVar54 + 4) = *(int *)((longlong)ppsVar54 + 4) + 0xe;
                *(undefined8 *)(puVar43 + -8) = 0x113223;
                puVar27 = (ulonglong *)func_0x((longlong)ppsVar54 + 2);
                uVar41 = *puVar27;
                *(ulonglong *)(&stack0x000002c0 + lVar23) = uVar41;
                uVar35 = (ushort)(uVar41 >> 0x30);
                uVar39 = uVar35;
                if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                  uVar39 = uVar35 & 0xdfff;
                  if ((uVar41 & 0x4000000000000000) != 0) {
                    uVar39 = uVar35 | 0x2000;
                  }
                }
                if (uVar39 == 0xfffc) {
                  iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                }
                *(int *)((longlong)ppsVar54 + 4) = *(int *)((longlong)ppsVar54 + 4) + iVar21;
              }
              uVar40 = *(uint *)((longlong)ppsVar54 + 4);
              if ((*(ulonglong *)((longlong)ppsVar54 + 0x1e) != 0) &&
                 (*(ulonglong *)((longlong)ppsVar54 + 0x1e) <
                  (ulonglong)uVar40 + (longlong)ppsVar54[1])) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   (((lVar37 = *(longlong *)
                                ((ulonglong)*_DAT_ +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                     (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x113384;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1133aa;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                  }
                }
                psVar57 = ppsVar54[1];
                *(undefined8 *)(puVar43 + -8) = 0x1133b8;
                func_0x(psVar57,0x12);
                uVar40 = *(uint *)((longlong)ppsVar54 + 4);
              }
              if (0x3f3b < uVar40 - 1) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                    ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                     (*(char *)(lVar37 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x113444;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x11346a;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                  }
                }
                psVar57 = ppsVar54[1];
                *(undefined8 *)(puVar43 + -8) = 0x113478;
                func_0x(psVar57,5);
              }
            }
LAB_:
            uVar40 = *(uint *)((longlong)ppsVar54 + 4);
            if (uVar40 < 9) {
              bVar34 = *(byte *)ppsVar54[1] & 0xe;
joined_r0x001134b6:
              if ((bVar34 == 0) || (bVar34 == 0xc)) {
                uVar40 = 9;
              }
            }
          }
          else {
            uVar40 = *(uint *)((longlong)ppsVar54 + 4);
            if (uVar40 == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x1134a3;
              func_0x((longlong)ppsVar54 + 2);
              uVar40 = *(uint *)((longlong)ppsVar54 + 4);
            }
            if (uVar40 < 9) {
              bVar34 = *(byte *)ppsVar54[1] & 0x1c;
              goto joined_r0x001134b6;
            }
          }
          iVar21 = *(int *)(&stack0x00000044 + lVar23);
          plVar51 = *(longlong **)(&stack0x00000060 + lVar23);
          uVar36 = *(undefined4 *)(&stack0x00000028 + lVar23);
          uVar25 = *(undefined8 *)(&stack0x00000058 + lVar23);
          if (0x14 < uVar40) goto LAB_;
          *(int *)(&stack0x00000044 + lVar23) = iVar21 + 0x22;
        }
      }
      else {
        if (*psVar57 == 0) {
          if (*(int *)(psVar57 + 2) == 0) {
            *puVar55 = 0;
            uVar40 = *(uint *)(psVar57 + 8);
            uVar41 = (ulonglong)uVar40;
            *(uint *)(psVar57 + 10) = uVar40;
            pbVar3 = *(byte **)(psVar57 + 4);
            bVar34 = *pbVar3;
            if ((bVar34 & 0x10) != 0) {
              uVar40 = uVar40 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3) + 2;
              uVar41 = (ulonglong)uVar40;
              *(uint *)(psVar57 + 10) = uVar40;
              bVar34 = *pbVar3;
            }
            if ((bVar34 & 0x20) == 0) {
              *(int *)(psVar57 + 2) = (int)uVar41;
              psVar57[0xe] = 0;
              *(uint *)(psVar57 + 0xc) = uVar40;
            }
            else {
              puVar44 = (ushort *)(pbVar3 + uVar41);
              uVar39 = *puVar44;
              psVar57[0xe] = uVar39;
              if (uVar39 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1112a2;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1112c8;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                  }
                }
                uVar25 = *(undefined8 *)(psVar57 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x1112d6;
                func_0x(uVar25,3);
                uVar39 = psVar57[0xe];
              }
              uVar40 = *(int *)(psVar57 + 10) + (uVar39 + 1) * 2;
              *(uint *)(psVar57 + 0xc) = uVar40;
              if (0x1f9e < uVar40) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                    ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                     (*(char *)(lVar37 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x11136e;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x111394;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                  }
                }
                uVar25 = *(undefined8 *)(psVar57 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x1113a2;
                func_0x(uVar25,4);
              }
              uVar39 = puVar44[(ushort)psVar57[0xe]];
              *(uint *)(psVar57 + 2) = uVar39 & 0x7fff;
              if ((uVar39 & 0x7fff) < *(uint *)(psVar57 + 0xc)) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x111436;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x11145c;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                  }
                }
                uVar25 = *(undefined8 *)(psVar57 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x11146a;
                func_0x(uVar25,4);
              }
              do {
                uVar39 = psVar57[0xe];
                if (-1 < (short)puVar44[(ulonglong)(uVar39 - 1) + 1]) break;
                lVar37 = *(longlong *)(psVar57 + 4);
                lVar26 = (ulonglong)*(uint *)(psVar57 + 10) + lVar37;
                uVar40 = (uint)uVar39;
                if (uVar40 == 1) {
                  uVar48 = *(uint *)(psVar57 + 0xc);
                  uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar40 * 2);
                  uVar40 = uVar48;
LAB_:
                  if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
                }
                else {
                  uVar48 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                  uVar40 = *(uint *)(psVar57 + 0xc);
                  uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                  if (uVar40 <= uVar48) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar43 + -8) = 0x1114d4;
                  func_0x(lVar37,7);
                  uVar40 = *(uint *)(psVar57 + 0xc);
                }
                if ((uVar48 < uVar40) || (*(uint *)(psVar57 + 2) < uVar48)) goto LAB_;
                if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar57 + 4)) == 5) {
                  *puVar55 = *puVar55 | 2;
                  psVar57[0xe] = psVar57[0xe] + -1;
                  psVar57[0x15] = (short)uVar48;
                  lVar37 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(psVar57 + 4);
                  uVar39 = psVar57[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar37 + 2) & 0x4000) != 0) {
                    uVar39 = *(ushort *)(lVar37 + 2) & 0x3800 | psVar57[0x16] & 0xc7ffU;
                  }
                  psVar57[0x16] = uVar39;
                  psVar57[0x16] = (uVar39 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar39;
                  break;
                }
                if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar57 + 4)) < 0x400) break;
                *puVar55 = *puVar55 | 1;
                psVar49 = psVar57 + 0xe;
                *psVar49 = *psVar49 + -1;
              } while (*psVar49 != 0);
            }
            iVar21 = 0;
            if ((**(byte **)(psVar57 + 4) & 0x40) == 0) {
              *(undefined4 *)(psVar57 + 0x13) = 0;
            }
            else {
              *(int *)(psVar57 + 0x13) = *(int *)(psVar57 + 2);
              *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + 0xe;
              *(undefined8 *)(puVar43 + -8) = 0x1115b7;
              puVar27 = (ulonglong *)func_0x(puVar55);
              uVar41 = *puVar27;
              *(ulonglong *)(&stack0x000002a0 + lVar23) = uVar41;
              uVar35 = (ushort)(uVar41 >> 0x30);
              uVar39 = uVar35;
              if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                uVar39 = uVar35 & 0xdfff;
                if ((uVar41 & 0x4000000000000000) != 0) {
                  uVar39 = uVar35 | 0x2000;
                }
              }
              if (uVar39 == 0xfffc) {
                iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + iVar21;
            }
            uVar40 = *(uint *)(psVar57 + 2);
            if ((*(ulonglong *)(psVar57 + 0xf) != 0) &&
               (*(ulonglong *)(psVar57 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar57 + 4))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar37 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                   (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x1116b3;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x1116d9;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x1116e7;
              func_0x(uVar25,0x12);
              uVar40 = *(uint *)(psVar57 + 2);
            }
            if (0x3f3b < uVar40 - 1) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x111772;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x111798;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x1117a6;
              func_0x(uVar25,5);
            }
          }
LAB_:
          uVar40 = *(uint *)(psVar57 + 2);
          *(uint *)(&stack0x00000044 + lVar23) = uVar40;
          if ((uVar40 < 9) &&
             (((**(byte **)(psVar57 + 4) & 0xe) == 0 || ((**(byte **)(psVar57 + 4) & 0xe) == 0xc))))
          {
            *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
          }
          plVar51 = *(longlong **)(&stack0x00000060 + lVar23);
        }
        else {
          uVar40 = *(uint *)(psVar57 + 2);
          *(uint *)(&stack0x00000044 + lVar23) = uVar40;
          if (uVar40 == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x1117e1;
            func_0x(puVar55);
            uVar40 = *(uint *)(psVar57 + 2);
            *(uint *)(&stack0x00000044 + lVar23) = uVar40;
          }
          if ((uVar40 < 9) &&
             (((**(byte **)(psVar57 + 4) & 0x1c) == 0 || ((**(byte **)(psVar57 + 4) & 0x1c) == 0xc))
             )) {
            *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
          }
        }
LAB_:
        uVar36 = *(undefined4 *)(&stack0x00000028 + lVar23);
        uVar25 = *(undefined8 *)(&stack0x00000058 + lVar23);
      }
LAB_:
      bVar38 = *pbVar5;
    }
LAB_:
    lVar37 = *(longlong *)(&stack0x000000e8 + lVar23);
    *(byte *)(lVar37 + 0x531) = *(byte *)(lVar37 + 0x531) & 0xfe;
    *(byte *)(lVar37 + 0x531) = *(byte *)(lVar37 + 0x531) | bVar38;
    *(undefined4 *)(puVar43 + 0x20) = *(undefined4 *)(&stack0x00000044 + lVar23);
    uVar7 = *(undefined4 *)((longlong)auStackX_20 + lVar23);
    *(undefined8 *)(puVar43 + -8) = 0x111841;
    cVar18 = func_0x(plVar51,uVar25,uVar36,uVar7);
    psVar57 = *(short **)(&stack0x000000e0 + lVar23);
    if (cVar18 == '\0') {
LAB_:
      *(undefined4 *)(&stack0x00000038 + lVar23) = 1;
      uVar36 = *(undefined4 *)((longlong)auStackX_20 + lVar23 + 4);
      plVar51 = *(longlong **)(&stack0x00000078 + lVar23);
      *(undefined8 *)(puVar43 + -8) = 0x113652;
      func_0x(plVar51,uVar36);
      psVar49 = *(short **)(&stack0x00000068 + lVar23);
      *(undefined8 *)(puVar43 + -8) = 0x11365e;
      cVar18 = func_0x(psVar49);
      if (cVar18 == '\0') {
LAB_:
        sVar6 = *psVar49;
        *(short *)(&stack0x00000438 + lVar23) = sVar6;
        if (sVar6 == 0) {
          if (*(int *)(psVar49 + 2) == 0) {
            psVar49[1] = 0;
            uVar40 = *(uint *)(psVar49 + 8);
            uVar41 = (ulonglong)uVar40;
            *(uint *)(psVar49 + 10) = uVar40;
            pbVar3 = *(byte **)(psVar49 + 4);
            bVar34 = *pbVar3;
            if ((bVar34 & 0x10) != 0) {
              uVar40 = uVar40 + 2 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3);
              uVar41 = (ulonglong)uVar40;
              *(uint *)(psVar49 + 10) = uVar40;
              bVar34 = *pbVar3;
            }
            if ((bVar34 & 0x20) == 0) {
              *(int *)(psVar49 + 2) = (int)uVar41;
              psVar49[0xe] = 0;
              *(uint *)(psVar49 + 0xc) = uVar40;
            }
            else {
              puVar55 = (ushort *)(pbVar3 + uVar41);
              uVar39 = *puVar55;
              psVar49[0xe] = uVar39;
              if (uVar39 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1137f6;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x11381c;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                  }
                }
                uVar25 = *(undefined8 *)(psVar49 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x11382a;
                func_0x(uVar25,3);
                uVar39 = psVar49[0xe];
              }
              uVar40 = *(int *)(psVar49 + 10) + 2 + (uint)uVar39 * 2;
              *(uint *)(psVar49 + 0xc) = uVar40;
              if (0x1f9e < uVar40) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                    ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                     (*(char *)(lVar37 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1138c6;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1138ec;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                  }
                }
                uVar25 = *(undefined8 *)(psVar49 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x1138fa;
                func_0x(uVar25,4);
              }
              uVar39 = puVar55[(ushort)psVar49[0xe]];
              *(uint *)(psVar49 + 2) = uVar39 & 0x7fff;
              if ((uVar39 & 0x7fff) < *(uint *)(psVar49 + 0xc)) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x113991;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1139b7;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                  }
                }
                uVar25 = *(undefined8 *)(psVar49 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x1139c5;
                func_0x(uVar25,4);
              }
              do {
                uVar39 = psVar49[0xe];
                if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                lVar37 = *(longlong *)(psVar49 + 4);
                lVar26 = (ulonglong)*(uint *)(psVar49 + 10) + lVar37;
                uVar40 = (uint)uVar39;
                if (uVar40 == 1) {
                  uVar48 = *(uint *)(psVar49 + 0xc);
                  uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar40 * 2);
LAB_:
                  if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
                }
                else {
                  uVar48 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                  uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                  if (*(uint *)(psVar49 + 0xc) <= uVar48) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar43 + -8) = 0x113a31;
                  func_0x(lVar37,7);
                  if (uVar48 < *(uint *)(psVar49 + 0xc)) goto LAB_;
                }
                if (*(uint *)(psVar49 + 2) < uVar48) goto LAB_;
                if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar49 + 4)) == 5) {
                  psVar49[1] = psVar49[1] | 2;
                  psVar49[0xe] = psVar49[0xe] + -1;
                  psVar49[0x15] = (short)uVar48;
                  lVar37 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(psVar49 + 4);
                  uVar39 = *(ushort *)(lVar37 + 2);
                  uVar35 = psVar49[0x16] & 0xc7ff;
                  if ((uVar39 & 0x4000) != 0) {
                    uVar35 = uVar39 & 0x3800 | uVar35;
                  }
                  psVar49[0x16] = uVar35;
                  psVar49[0x16] = (uVar35 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar35;
                  break;
                }
                if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar49 + 4)) < 0x400) break;
                psVar49[1] = psVar49[1] | 1;
                psVar2 = psVar49 + 0xe;
                *psVar2 = *psVar2 + -1;
              } while (*psVar2 != 0);
            }
            iVar21 = 0;
            if ((**(byte **)(psVar49 + 4) & 0x40) == 0) {
              *(undefined4 *)(psVar49 + 0x13) = 0;
            }
            else {
              *(int *)(psVar49 + 0x13) = *(int *)(psVar49 + 2);
              *(int *)(psVar49 + 2) = *(int *)(psVar49 + 2) + 0xe;
              *(undefined8 *)(puVar43 + -8) = 0x113b32;
              puVar27 = (ulonglong *)func_0x(psVar49 + 1);
              uVar41 = *puVar27;
              *(ulonglong *)(&stack0x000002d0 + lVar23) = uVar41;
              uVar39 = (ushort)(uVar41 >> 0x30);
              if ((((uint)(int)(short)uVar39 >> 1 ^ (int)(short)uVar39) & 0x2000) != 0) {
                if ((uVar41 & 0x4000000000000000) == 0) {
                  uVar39 = uVar39 & 0xdfff;
                }
                else {
                  uVar39 = uVar39 | 0x2000;
                }
              }
              if (uVar39 == 0xfffc) {
                iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(psVar49 + 2) = *(int *)(psVar49 + 2) + iVar21;
            }
            uVar40 = *(uint *)(psVar49 + 2);
            if ((*(ulonglong *)(psVar49 + 0xf) != 0) &&
               (*(ulonglong *)(psVar49 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar49 + 4))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar37 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                   (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x113c24;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x113c4a;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                }
              }
              uVar25 = *(undefined8 *)(psVar49 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x113c58;
              func_0x(uVar25,0x12);
              uVar40 = *(uint *)(psVar49 + 2);
            }
            if (0x3f3b < uVar40 - 1) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x113ce4;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  uVar25 = *(undefined8 *)(psVar49 + 4);
                  *(undefined8 *)(puVar43 + -8) = 0x113cf2;
                  func_0x(uVar25,5);
                  goto LAB_;
                }
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x113d18;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
              }
              uVar25 = *(undefined8 *)(psVar49 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x113d26;
              func_0x(uVar25,5);
            }
          }
LAB_:
          uVar40 = *(uint *)(psVar49 + 2);
          if ((uVar40 < 9) &&
             (((**(byte **)(psVar49 + 4) & 0xe) == 0 || ((**(byte **)(psVar49 + 4) & 0xe) == 0xc))))
          {
            uVar40 = 9;
          }
          *(undefined4 *)(&stack0x00000448 + lVar23) = *(undefined4 *)(psVar49 + 8);
          *(short *)(&stack0x0000043a + lVar23) = psVar49[1];
          *(undefined4 *)(&stack0x0000043c + lVar23) = *(undefined4 *)(psVar49 + 2);
          *(short *)(&stack0x00000454 + lVar23) = psVar49[0xe];
          *(undefined4 *)(&stack0x0000044c + lVar23) = *(undefined4 *)(psVar49 + 10);
          *(undefined4 *)(&stack0x00000450 + lVar23) = *(undefined4 *)(psVar49 + 0xc);
          *(undefined4 *)(&stack0x0000045e + lVar23) = *(undefined4 *)(psVar49 + 0x13);
          *(undefined8 *)(puVar43 + -8) = 0x113da4;
          uVar25 = func_0x(psVar49 + 1);
          *(undefined8 *)(puVar43 + -8) = 0x113dbb;
          func_0x(&stack0x00002ce8 + lVar23,0x1f9e,uVar25,uVar40);
          *(undefined **)(&stack0x00000440 + lVar23) = &stack0x00002ce8 + lVar23;
          *(undefined8 *)(puVar43 + -8) = 0x113dd5;
          iVar21 = func_0x(&stack0x0000043a + lVar23);
          if (iVar21 != 0) {
            *(undefined8 *)(puVar43 + -8) = 0x113ded;
            uVar19 = func_0x(&stack0x0000043a + lVar23,&stack0x00000054 + lVar23);
            *(ushort *)(&stack0x00000462 + lVar23) = uVar19;
            uVar39 = *(ushort *)((ulonglong)uVar19 + *(longlong *)(&stack0x00000440 + lVar23) + 2);
            uVar35 = *(ushort *)(&stack0x00000464 + lVar23);
            if ((uVar39 & 0x4000) == 0) {
              uVar35 = uVar35 & 0xc7ff;
            }
            else {
              uVar35 = uVar35 ^ (uVar35 ^ uVar39) & 0x3800;
            }
            *(ushort *)(&stack0x00000464 + lVar23) = uVar35;
            *(ushort *)(&stack0x00000464 + lVar23) =
                 (uVar35 ^ *(ushort *)
                            ((ulonglong)uVar19 + *(longlong *)(&stack0x00000440 + lVar23) + 2)) &
                 0x7ff ^ uVar35;
          }
        }
        else {
          if (*psVar49 != 0) {
            *(undefined8 *)(puVar43 + -8) = 0x113e69;
            lVar37 = func_0x(psVar49 + 1);
            if (lVar37 != 0) {
              if (*psVar49 == 0) {
                uVar25 = 0;
              }
              else {
                *(undefined8 *)(puVar43 + -8) = 0x113e84;
                uVar25 = func_0x(psVar49 + 1);
              }
              *(undefined8 *)(puVar43 + -8) = 0x113e8e;
              iVar21 = func_0x(uVar25);
              if (iVar21 != 0) {
                *(undefined8 *)(puVar43 + -8) = 0x113eae;
                func_0x(&stack0x00000438 + lVar23,&stack0x00002ce8 + lVar23,0x1f9e,psVar49);
                goto LAB_;
              }
            }
          }
          *(undefined8 *)(puVar43 + -8) = 0x113eed;
          func_0x(&stack0x0000043a + lVar23,&stack0x00002ce8 + lVar23,0x1f9e,psVar49 + 1);
          if (*psVar49 == 0) {
            *(undefined8 *)(&stack0x00000448 + lVar23) = 0;
          }
          else {
            *(undefined8 *)(puVar43 + -8) = 0x113f0a;
            uVar25 = func_0x(psVar49 + 1);
            *(undefined8 *)(&stack0x00000448 + lVar23) = uVar25;
          }
        }
      }
      else {
        if (*psVar49 == 0) {
          bVar59 = (**(byte **)(psVar49 + 4) & 0xe) == 2;
        }
        else {
          bVar59 = ((**(byte **)(psVar49 + 4) & 0x1c) - 0x10 & 0xfffffffb) == 0;
        }
        if (bVar59) goto LAB_;
        *(undefined8 *)(puVar43 + -8) = 0x113693;
        uVar20 = func_0x(psVar49);
        *(undefined2 *)(puVar43 + 0x30) = uVar20;
        puVar43[0x28] = 0;
        *(undefined4 *)(puVar43 + 0x20) = 0;
        *(undefined8 *)(puVar43 + -8) = 0x1136bf;
        func_0x(&stack0x00000438 + lVar23,&stack0x00002ce8 + lVar23,0x1f9e,0);
        if (abStackX_18[lVar23 + 1] != 0) {
          *(undefined8 *)(puVar43 + -8) = 0x1136d8;
          uVar25 = func_0x(psVar49,&stack0x000000a4 + lVar23);
          *(undefined8 *)(puVar43 + -8) = 0x1136e7;
          func_0x(&stack0x00000438 + lVar23,uVar25);
          *(undefined8 *)(puVar43 + -8) = 0x1136f6;
          uVar25 = func_0x(psVar49,&stack0x000002c8 + lVar23);
          *(undefined8 *)(puVar43 + -8) = 0x113705;
          func_0x(&stack0x00000438 + lVar23,uVar25);
        }
      }
LAB_:
      if (*psVar49 == 0) {
        bVar59 = (**(byte **)(psVar49 + 4) & 0xe) == 2;
      }
      else {
        bVar59 = ((**(byte **)(psVar49 + 4) & 0x1c) - 0x10 & 0xfffffffb) == 0;
      }
      if (!bVar59) {
        *(undefined8 *)(puVar43 + -8) = 0x113f3b;
        func_0x(&stack0x00000438 + lVar23,&stack0x00000208 + lVar23);
        *(undefined8 *)(puVar43 + -8) = 0x113f43;
        cVar18 = func_0x(psVar49);
        if (cVar18 != '\0') {
          *(undefined8 *)(puVar43 + -8) = 0x113f53;
          func_0x(&stack0x00000438 + lVar23);
        }
        if (psVar57 == (short *)0x0) {
          uVar36 = *(undefined4 *)(&stack0x00000030 + lVar23);
          goto LAB_;
        }
        if (*psVar57 == 0) {
          bVar59 = (**(byte **)(psVar57 + 4) & 0xe) == 2;
        }
        else {
          bVar59 = ((**(byte **)(psVar57 + 4) & 0x1c) - 0x10 & 0xfffffffb) == 0;
        }
        if (!bVar59) {
          *(undefined8 *)(puVar43 + -8) = 0x113f96;
          func_0x(psVar57,&stack0x00000208 + lVar23);
          if (abStackX_18[lVar23 + 2] != 0) {
            if (*psVar57 == 0) {
              if (*(int *)(psVar57 + 2) == 0) {
                psVar57[1] = 0;
                uVar40 = *(uint *)(psVar57 + 8);
                uVar41 = (ulonglong)uVar40;
                *(uint *)(psVar57 + 10) = uVar40;
                pbVar3 = *(byte **)(psVar57 + 4);
                bVar34 = *pbVar3;
                if ((bVar34 & 0x10) != 0) {
                  uVar40 = uVar40 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3) + 2;
                  uVar41 = (ulonglong)uVar40;
                  *(uint *)(psVar57 + 10) = uVar40;
                  bVar34 = *pbVar3;
                }
                if ((bVar34 & 0x20) == 0) {
                  *(int *)(psVar57 + 2) = (int)uVar41;
                  psVar57[0xe] = 0;
                  *(uint *)(psVar57 + 0xc) = uVar40;
                }
                else {
                  puVar55 = (ushort *)(pbVar3 + uVar41);
                  uVar39 = *puVar55;
                  psVar57[0xe] = uVar39;
                  if (uVar39 == 0) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                       ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                        (*(char *)(lVar37 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x11408a;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x1140b0;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                      }
                    }
                    uVar25 = *(undefined8 *)(psVar57 + 4);
                    *(undefined8 *)(puVar43 + -8) = 0x1140bf;
                    func_0x(uVar25,3);
                    uVar39 = psVar57[0xe];
                  }
                  uVar40 = *(int *)(psVar57 + 10) + (uVar39 + 1) * 2;
                  *(uint *)(psVar57 + 0xc) = uVar40;
                  if (0x1f9e < uVar40) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                        ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                         (*(char *)(lVar37 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x11415d;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x114183;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                      }
                    }
                    uVar25 = *(undefined8 *)(psVar57 + 4);
                    *(undefined8 *)(puVar43 + -8) = 0x114192;
                    func_0x(uVar25,4);
                  }
                  uVar39 = puVar55[(ushort)psVar57[0xe]];
                  *(uint *)(psVar57 + 2) = uVar39 & 0x7fff;
                  if ((uVar39 & 0x7fff) < *(uint *)(psVar57 + 0xc)) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                       ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                        (*(char *)(lVar37 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x11422c;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x114252;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                      }
                    }
                    uVar25 = *(undefined8 *)(psVar57 + 4);
                    *(undefined8 *)(puVar43 + -8) = 0x114261;
                    func_0x(uVar25,4);
                  }
                  do {
                    uVar39 = psVar57[0xe];
                    if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                    lVar37 = *(longlong *)(psVar57 + 4);
                    lVar26 = (ulonglong)*(uint *)(psVar57 + 10) + lVar37;
                    uVar40 = (uint)uVar39;
                    if (uVar40 == 1) {
                      uVar48 = *(uint *)(psVar57 + 0xc);
                      uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar40 * 2);
                      uVar40 = uVar48;
LAB_:
                      if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
                    }
                    else {
                      uVar48 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                      uVar40 = *(uint *)(psVar57 + 0xc);
                      uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                      if (uVar40 <= uVar48) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar43 + -8) = 0x1142dc;
                      func_0x(lVar37,7);
                      uVar40 = *(uint *)(psVar57 + 0xc);
                    }
                    if ((uVar48 < uVar40) || (*(uint *)(psVar57 + 2) < uVar48)) goto LAB_;
                    uVar39 = *(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar57 + 4));
                    if (uVar39 == 5) {
                      psVar57[1] = psVar57[1] | 2;
                      psVar57[0xe] = psVar57[0xe] + -1;
                      psVar57[0x15] = (short)uVar48;
                      lVar37 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(psVar57 + 4);
                      uVar39 = *(ushort *)(lVar37 + 2);
                      uVar35 = psVar57[0x16] & 0xc7ff;
                      if ((uVar39 & 0x4000) != 0) {
                        uVar35 = uVar39 & 0x3800 | uVar35;
                      }
                      psVar57[0x16] = uVar35;
                      psVar57[0x16] = (uVar35 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar35;
                      break;
                    }
                    if (uVar39 < 0x400) break;
                    psVar57[1] = psVar57[1] | 1;
                    psVar49 = psVar57 + 0xe;
                    *psVar49 = *psVar49 + -1;
                  } while (*psVar49 != 0);
                }
                iVar21 = 0;
                if ((**(byte **)(psVar57 + 4) & 0x40) == 0) {
                  *(undefined4 *)(psVar57 + 0x13) = 0;
                }
                else {
                  *(int *)(psVar57 + 0x13) = *(int *)(psVar57 + 2);
                  *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + 0xe;
                  *(undefined8 *)(puVar43 + -8) = 0x114353;
                  puVar27 = (ulonglong *)func_0x(psVar57 + 1);
                  uVar41 = *puVar27;
                  *(ulonglong *)(&stack0x000002d8 + lVar23) = uVar41;
                  uVar39 = (ushort)(uVar41 >> 0x30);
                  if ((((uint)(int)(short)uVar39 >> 1 ^ (int)(short)uVar39) & 0x2000) != 0) {
                    if ((uVar41 & 0x4000000000000000) == 0) {
                      uVar39 = uVar39 & 0xdfff;
                    }
                    else {
                      uVar39 = uVar39 | 0x2000;
                    }
                  }
                  if (uVar39 == 0xfffc) {
                    iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                  }
                  *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + iVar21;
                }
                uVar40 = *(uint *)(psVar57 + 2);
                if ((*(ulonglong *)(psVar57 + 0xf) != 0) &&
                   (*(ulonglong *)(psVar57 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar57 + 4)))
                {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     (((lVar37 = *(longlong *)
                                  ((ulonglong)*_DAT_ +
                                   *(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                       (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x1144c6;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x1144ec;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                    }
                  }
                  uVar25 = *(undefined8 *)(psVar57 + 4);
                  *(undefined8 *)(puVar43 + -8) = 0x1144fb;
                  func_0x(uVar25,0x12);
                  uVar40 = *(uint *)(psVar57 + 2);
                }
                if (0x3f3b < uVar40 - 1) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                      ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                       (*(char *)(lVar37 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x114588;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x1145ae;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                    }
                  }
                  uVar25 = *(undefined8 *)(psVar57 + 4);
                  *(undefined8 *)(puVar43 + -8) = 0x1145bd;
                  func_0x(uVar25,5);
                }
              }
LAB_:
              if ((8 < *(uint *)(psVar57 + 2)) ||
                 (((**(byte **)(psVar57 + 4) & 0xe) != 0 &&
                  ((**(byte **)(psVar57 + 4) & 0xe) != 0xc)))) {
                *(uint *)(&stack0x0000003c + lVar23) = *(uint *)(psVar57 + 2);
              }
            }
            else {
              uVar40 = *(uint *)(psVar57 + 2);
              if (uVar40 == 0) {
                *(undefined8 *)(puVar43 + -8) = 0x1145f1;
                func_0x(psVar57 + 1);
                uVar40 = *(uint *)(psVar57 + 2);
              }
              if ((uVar40 < 9) &&
                 (((**(byte **)(psVar57 + 4) & 0x1c) == 0 ||
                  ((**(byte **)(psVar57 + 4) & 0x1c) == 0xc)))) {
                *(undefined4 *)(&stack0x0000003c + lVar23) = 9;
              }
              else {
                *(uint *)(&stack0x0000003c + lVar23) = uVar40;
              }
            }
            *(undefined8 *)(puVar43 + -8) = 0x114621;
            uVar20 = func_0x(psVar57);
            *(undefined8 *)(puVar43 + -8) = 0x114629;
            uVar40 = func_0x(uVar20);
            if (*(uint *)(&stack0x0000003c + lVar23) < uVar40) {
              *(undefined4 *)(&stack0x000002e0 + lVar23) = 0;
              *(undefined2 *)(&stack0x000002e4 + lVar23) = 0;
              *(undefined2 *)(&stack0x000002e6 + lVar23) = 0;
              *(undefined8 *)(&stack0x00000c68 + lVar23) =
                   *(undefined8 *)(&stack0x000002e0 + lVar23);
              *(undefined4 *)(&stack0x00000c70 + lVar23) = 0;
              *(undefined2 *)(&stack0x00000c74 + lVar23) = 0;
              *(undefined8 *)(puVar43 + -8) = 0x114677;
              func_0x(psVar57,&stack0x00000c68 + lVar23);
              plVar51 = *(longlong **)(&stack0x00000078 + lVar23);
              uVar36 = *(undefined4 *)(&stack0x00000030 + lVar23);
            }
            else {
              plVar51 = *(longlong **)(&stack0x00000078 + lVar23);
              uVar36 = *(undefined4 *)(&stack0x00000030 + lVar23);
            }
            goto LAB_;
          }
        }
      }
      uVar36 = *(undefined4 *)(&stack0x00000030 + lVar23);
    }
    else {
      if (psVar57 != (short *)0x0) {
        if (*psVar57 == 0) {
          bVar59 = (**(byte **)(psVar57 + 4) & 0xe) == 2;
        }
        else {
          bVar59 = ((**(byte **)(psVar57 + 4) & 0x1c) - 0x10 & 0xfffffffb) == 0;
        }
        if ((bVar59) && (*(int *)(&stack0x0000002c + lVar23) == 2)) goto LAB_;
      }
      puVar28 = (undefined4 *)(lVar37 + 0x530);
      if (abStackX_18[lVar23 + 1] == 0) {
        lVar37 = 2;
        puVar33 = (undefined4 *)(&stack0x000007a8 + lVar23);
        do {
          uVar36 = puVar28[1];
          uVar7 = puVar28[2];
          uVar13 = puVar28[3];
          *puVar33 = *puVar28;
          puVar33[1] = uVar36;
          puVar33[2] = uVar7;
          puVar33[3] = uVar13;
          uVar36 = puVar28[5];
          uVar7 = puVar28[6];
          uVar13 = puVar28[7];
          puVar33[4] = puVar28[4];
          puVar33[5] = uVar36;
          puVar33[6] = uVar7;
          puVar33[7] = uVar13;
          uVar36 = puVar28[9];
          uVar7 = puVar28[10];
          uVar13 = puVar28[0xb];
          puVar33[8] = puVar28[8];
          puVar33[9] = uVar36;
          puVar33[10] = uVar7;
          puVar33[0xb] = uVar13;
          uVar36 = puVar28[0xd];
          uVar7 = puVar28[0xe];
          uVar13 = puVar28[0xf];
          puVar33[0xc] = puVar28[0xc];
          puVar33[0xd] = uVar36;
          puVar33[0xe] = uVar7;
          puVar33[0xf] = uVar13;
          uVar36 = puVar28[0x11];
          uVar7 = puVar28[0x12];
          uVar13 = puVar28[0x13];
          puVar33[0x10] = puVar28[0x10];
          puVar33[0x11] = uVar36;
          puVar33[0x12] = uVar7;
          puVar33[0x13] = uVar13;
          uVar36 = puVar28[0x15];
          uVar7 = puVar28[0x16];
          uVar13 = puVar28[0x17];
          puVar33[0x14] = puVar28[0x14];
          puVar33[0x15] = uVar36;
          puVar33[0x16] = uVar7;
          puVar33[0x17] = uVar13;
          uVar36 = puVar28[0x19];
          uVar7 = puVar28[0x1a];
          uVar13 = puVar28[0x1b];
          puVar33[0x18] = puVar28[0x18];
          puVar33[0x19] = uVar36;
          puVar33[0x1a] = uVar7;
          puVar33[0x1b] = uVar13;
          uVar36 = puVar28[0x1d];
          uVar7 = puVar28[0x1e];
          uVar13 = puVar28[0x1f];
          puVar33[0x1c] = puVar28[0x1c];
          puVar33[0x1d] = uVar36;
          puVar33[0x1e] = uVar7;
          puVar33[0x1f] = uVar13;
          puVar28 = puVar28 + 0x20;
          lVar37 = lVar37 + -1;
          puVar33 = puVar33 + 0x20;
        } while (lVar37 != 0);
        *(undefined8 *)(puVar43 + 0x20) = *(undefined8 *)(&stack0x00000228 + lVar23);
        uVar36 = *(undefined4 *)(&stack0x00000030 + lVar23);
        uVar25 = *(undefined8 *)(&stack0x00000230 + lVar23);
        plVar51 = *(longlong **)(&stack0x00000078 + lVar23);
        *(undefined8 *)(puVar43 + -8) = 0x113637;
        func_0x(plVar51,uVar25,&stack0x000007a8 + lVar23,uVar36);
      }
      else {
        lVar37 = 2;
        puVar33 = (undefined4 *)(&stack0x000006a8 + lVar23);
        do {
          uVar36 = puVar28[1];
          uVar7 = puVar28[2];
          uVar13 = puVar28[3];
          *puVar33 = *puVar28;
          puVar33[1] = uVar36;
          puVar33[2] = uVar7;
          puVar33[3] = uVar13;
          uVar36 = puVar28[5];
          uVar7 = puVar28[6];
          uVar13 = puVar28[7];
          puVar33[4] = puVar28[4];
          puVar33[5] = uVar36;
          puVar33[6] = uVar7;
          puVar33[7] = uVar13;
          uVar36 = puVar28[9];
          uVar7 = puVar28[10];
          uVar13 = puVar28[0xb];
          puVar33[8] = puVar28[8];
          puVar33[9] = uVar36;
          puVar33[10] = uVar7;
          puVar33[0xb] = uVar13;
          uVar36 = puVar28[0xd];
          uVar7 = puVar28[0xe];
          uVar13 = puVar28[0xf];
          puVar33[0xc] = puVar28[0xc];
          puVar33[0xd] = uVar36;
          puVar33[0xe] = uVar7;
          puVar33[0xf] = uVar13;
          uVar36 = puVar28[0x11];
          uVar7 = puVar28[0x12];
          uVar13 = puVar28[0x13];
          puVar33[0x10] = puVar28[0x10];
          puVar33[0x11] = uVar36;
          puVar33[0x12] = uVar7;
          puVar33[0x13] = uVar13;
          uVar36 = puVar28[0x15];
          uVar7 = puVar28[0x16];
          uVar13 = puVar28[0x17];
          puVar33[0x14] = puVar28[0x14];
          puVar33[0x15] = uVar36;
          puVar33[0x16] = uVar7;
          puVar33[0x17] = uVar13;
          uVar36 = puVar28[0x19];
          uVar7 = puVar28[0x1a];
          uVar13 = puVar28[0x1b];
          puVar33[0x18] = puVar28[0x18];
          puVar33[0x19] = uVar36;
          puVar33[0x1a] = uVar7;
          puVar33[0x1b] = uVar13;
          uVar36 = puVar28[0x1d];
          uVar7 = puVar28[0x1e];
          uVar13 = puVar28[0x1f];
          puVar33[0x1c] = puVar28[0x1c];
          puVar33[0x1d] = uVar36;
          puVar33[0x1e] = uVar7;
          puVar33[0x1f] = uVar13;
          puVar28 = puVar28 + 0x20;
          lVar37 = lVar37 + -1;
          puVar33 = puVar33 + 0x20;
        } while (lVar37 != 0);
        uVar36 = *(undefined4 *)(&stack0x00000030 + lVar23);
        uVar25 = *(undefined8 *)(&stack0x00000230 + lVar23);
        plVar51 = *(longlong **)(&stack0x00000078 + lVar23);
        *(undefined8 *)(puVar43 + -8) = 0x1135ab;
        func_0x(plVar51,uVar25,&stack0x000006a8 + lVar23,uVar36);
      }
    }
LAB_:
    lVar37 = 2;
    *(undefined8 *)(puVar43 + -8) = 0x1146cc;
    func_0x(&stack0x000001f8 + lVar23);
    *(undefined8 *)(puVar43 + -8) = 0x1146d9;
    func_0x(&stack0x000001f0 + lVar23);
    if (plVar51[5] == 0) {
      *(undefined8 *)(puVar43 + -8) = 0x1146ea;
      func_0x(plVar51,0);
    }
    if (*(int *)(plVar51 + 0x48) == 0) {
      *(undefined8 *)(puVar43 + -8) = 0x1146fd;
      func_0x(plVar51,0);
    }
    if (*(int *)(plVar51 + 0x47) == 1) {
      iVar21 = *(int *)(&stack0x00000038 + lVar23);
      if (iVar21 != 0) {
        *(undefined8 *)(puVar43 + 0x20) = 0;
        *(undefined8 *)(puVar43 + -8) = 0x114737;
        (*_DAT_)(1,0x1a266f0,0x19fbd78,0xd68);
      }
      *(undefined8 *)(puVar43 + -8) = 0x114744;
      func_0x(plVar51,0,0);
      if ((plVar51[2] != CONCAT44(uRam0000000001f97fac,_DAT_)) ||
         (plVar51[3] != CONCAT44(uRam0000000001f97fb4,_DAT_))) {
        if ((*(byte *)(plVar51 + 0xe) & 2) != 0) {
          *(undefined8 *)(puVar43 + -8) = 0x114771;
          iVar22 = func_0x(plVar51 + 0xf);
          if (iVar22 != 0) {
            *(longlong *)(*plVar51 + 0x30) = *(longlong *)(*plVar51 + 0x30) + -1;
          }
        }
        *(undefined *)(plVar51 + 0xe) = 0;
        *(undefined4 *)((longlong)plVar51 + 0x6c) = 0;
        *(undefined4 *)(plVar51 + 0x11) = 0;
        if ((*(byte *)(plVar51 + 0x14) & 2) != 0) {
          *(undefined8 *)(puVar43 + -8) = 0x1147a0;
          iVar22 = func_0x(plVar51 + 0x15);
          if (iVar22 != 0) {
            *(longlong *)(*plVar51 + 0x30) = *(longlong *)(*plVar51 + 0x30) + -1;
          }
        }
        *(undefined *)(plVar51 + 0x14) = 0;
        *(undefined4 *)((longlong)plVar51 + 0x9c) = 0;
        *(undefined4 *)(plVar51 + 0x17) = 0;
        if (plVar51[5] != 0) {
          *(undefined *)((longlong)plVar51 + 0x36) = 0;
          plVar51[5] = 0;
          *(undefined2 *)((longlong)plVar51 + 0x34) = 0;
          *(undefined4 *)(plVar51[2] + 0x48) = 0;
        }
        uVar25 = *(undefined8 *)*plVar51;
        *(undefined8 *)(puVar43 + -8) = 0x1147eb;
        func_0x(uVar25,plVar51 + 2);
        uVar14 = uRam0000000001f97fb4;
        uVar13 = _DAT_;
        uVar7 = uRam0000000001f97fac;
        *(undefined4 *)(plVar51 + 2) = _DAT_;
        *(undefined4 *)((longlong)plVar51 + 0x14) = uVar7;
        *(undefined4 *)(plVar51 + 3) = uVar13;
        *(undefined4 *)((longlong)plVar51 + 0x1c) = uVar14;
        *(undefined4 *)(plVar51 + 4) = 0xffffffff;
        *(undefined4 *)(plVar51 + 0x48) = 0;
        plVar51[0x4b] = 0;
        plVar51[0x4a] = 0;
        plVar51[0x4c] = 0;
        *(undefined4 *)(plVar51 + 0x4e) = 0xffffffff;
        *(undefined2 *)((longlong)plVar51 + 0x274) = 0xffff;
        *(undefined4 *)((longlong)plVar51 + 0x276) = 0;
        *(undefined2 *)((longlong)plVar51 + 0x27a) = 0;
        *(undefined2 *)((longlong)plVar51 + 0x27c) = 0;
        *(undefined4 *)(plVar51 + 0x18) = 2;
      }
      puVar28 = *(undefined4 **)(&stack0x00000070 + lVar23);
      *(byte *)puVar28 = *(byte *)puVar28 & 0xfb | 1;
      puVar33 = (undefined4 *)(&stack0x000008a8 + lVar23);
      do {
        uVar7 = puVar28[1];
        uVar13 = puVar28[2];
        uVar14 = puVar28[3];
        *puVar33 = *puVar28;
        puVar33[1] = uVar7;
        puVar33[2] = uVar13;
        puVar33[3] = uVar14;
        uVar7 = puVar28[5];
        uVar13 = puVar28[6];
        uVar14 = puVar28[7];
        puVar33[4] = puVar28[4];
        puVar33[5] = uVar7;
        puVar33[6] = uVar13;
        puVar33[7] = uVar14;
        uVar7 = puVar28[9];
        uVar13 = puVar28[10];
        uVar14 = puVar28[0xb];
        puVar33[8] = puVar28[8];
        puVar33[9] = uVar7;
        puVar33[10] = uVar13;
        puVar33[0xb] = uVar14;
        uVar7 = puVar28[0xd];
        uVar13 = puVar28[0xe];
        uVar14 = puVar28[0xf];
        puVar33[0xc] = puVar28[0xc];
        puVar33[0xd] = uVar7;
        puVar33[0xe] = uVar13;
        puVar33[0xf] = uVar14;
        uVar7 = puVar28[0x11];
        uVar13 = puVar28[0x12];
        uVar14 = puVar28[0x13];
        puVar33[0x10] = puVar28[0x10];
        puVar33[0x11] = uVar7;
        puVar33[0x12] = uVar13;
        puVar33[0x13] = uVar14;
        uVar7 = puVar28[0x15];
        uVar13 = puVar28[0x16];
        uVar14 = puVar28[0x17];
        puVar33[0x14] = puVar28[0x14];
        puVar33[0x15] = uVar7;
        puVar33[0x16] = uVar13;
        puVar33[0x17] = uVar14;
        uVar7 = puVar28[0x19];
        uVar13 = puVar28[0x1a];
        uVar14 = puVar28[0x1b];
        puVar33[0x18] = puVar28[0x18];
        puVar33[0x19] = uVar7;
        puVar33[0x1a] = uVar13;
        puVar33[0x1b] = uVar14;
        uVar7 = puVar28[0x1d];
        uVar13 = puVar28[0x1e];
        uVar14 = puVar28[0x1f];
        puVar33[0x1c] = puVar28[0x1c];
        puVar33[0x1d] = uVar7;
        puVar33[0x1e] = uVar13;
        puVar33[0x1f] = uVar14;
        puVar28 = puVar28 + 0x20;
        lVar37 = lVar37 + -1;
        puVar33 = puVar33 + 0x20;
      } while (lVar37 != 0);
      uVar25 = *(undefined8 *)(&stack0x000000f8 + lVar23);
      *(undefined8 *)(puVar43 + -8) = 0x1148c3;
      iVar22 = func_0x(uVar25,0,&stack0x000008a8 + lVar23,uVar36);
      if (iVar22 != 0) {
        *(undefined8 *)(puVar43 + 0x20) = 0;
        *(undefined8 *)(puVar43 + -8) = 0x1148ed;
        (*_DAT_)(1,0x1a266e0,0x19fbd78,0xd7f);
      }
      goto LAB_;
    }
  }
  else {
    *(undefined4 *)(&stack0x00000028 + lVar23) = 0;
    *(undefined8 *)(&stack0x00000058 + lVar23) = 0;
    plVar51 = *(longlong **)(*(longlong *)(param_1 + 0x28) + 8);
    *(longlong **)(&stack0x00000060 + lVar23) = plVar51;
    *(undefined8 *)(&stack0x00000100 + lVar23) = 0;
    *(undefined8 *)(&stack0x00000108 + lVar23) = 0;
    *(undefined (*) [16])(&stack0x000003e8 + lVar23) = ZEXT816(0);
    pcVar8 = *(code **)*plVar51;
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x1001e5;
    bVar34 = (*pcVar8)(plVar51);
    *pbVar5 = bVar34;
    pcVar8 = *(code **)(*plVar51 + 8);
    *(undefined8 *)((longlong)&uStack_40 + lVar23) = 0x1001f5;
    bVar38 = (*pcVar8)(plVar51);
    abStackX_18[lVar23 + 1] = bVar38;
    uVar40 = (uint)(bVar34 == 0);
    *(uint *)(&stack0x0000002c + lVar23) = (uint)(bVar34 == 0);
    *(undefined4 *)(&stack0x00000038 + lVar23) = 0;
    bVar59 = false;
    if (param_2 == (short *)0x0) {
      lVar26 = *(longlong *)(&stack0x000000e8 + lVar23);
    }
    else {
      *(short **)(&stack0x000003e8 + lVar23) = param_2;
      lVar26 = *(longlong *)(&stack0x000000e8 + lVar23);
      puVar43 = &stack0xffffffffffffffc8 + lVar23;
      if (*(int *)(*(longlong *)(**(longlong **)(lVar26 + 0x28) + 8) + 0x100) == 2) {
        *(undefined2 *)(&stack0xffffffffffffffd8 + lVar23) = 0xffff;
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar23) = 0;
        *(undefined4 *)(&stack0xffffffffffffffdc + lVar23) = 0;
        *(undefined8 *)(&stack0xfffffffffffffff6 + lVar23) = 0;
        *(undefined8 *)((longlong)auStackX_20 + lVar23 + -0x20) = 0;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar23) = 0;
        *(undefined **)(&stack0x00000100 + lVar23) = &stack0xffffffffffffffd8 + lVar23;
        *(undefined8 *)((longlong)&uStack_80 + lVar23) = 0x10027c;
        lVar24 = func_0x();
        lVar24 = -lVar24;
        puVar52 = &stack0xffffffffffffffd8 + lVar24 + lVar23;
        puVar43 = auStack_f8 + lVar24 + lVar23;
        *(undefined (*) [16])(auStack_a8 + lVar24 + lVar23) = ZEXT816(0);
        *(undefined (*) [16])(auStack_98 + lVar24 + lVar23) = ZEXT816(0);
        *(undefined (*) [16])(auStack_88 + lVar24 + lVar23) = ZEXT816(0);
        *(undefined (*) [16])(auStack_78 + lVar24 + lVar23) = ZEXT816(0);
        *(undefined (*) [16])(auStack_68 + lVar24 + lVar23) = ZEXT816(0);
        *(undefined (*) [16])(auStack_58 + lVar24 + lVar23) = ZEXT816(0);
        *(undefined (*) [16])(auStack_48 + lVar24 + lVar23) = ZEXT816(0);
        *(undefined8 *)(&stack0xffffffffffffffc8 + lVar24 + lVar23) = 0;
        *(undefined8 *)((longlong)&uStack_100 + lVar24 + lVar23) = 0x1002ba;
        uVar25 = func_0x();
        *(undefined8 *)(&stack0x00000108 + lVar23) = uVar25;
        *(undefined8 *)(&stack0x000003f0 + lVar23) = *(undefined8 *)(&stack0x00000100 + lVar23);
        *(undefined **)(&stack0x000003f8 + lVar23) = puVar52;
        *(undefined4 *)(&stack0x00000400 + lVar23) = 0x473c;
        *(undefined8 *)(&stack0x00000408 + lVar23) = uVar25;
      }
    }
    *(undefined8 *)(puVar43 + -8) = 0x1002f8;
    uVar25 = func_0x(lVar37);
    *(undefined8 *)(&stack0x00000068 + lVar23) = uVar25;
    if (*(longlong *)(param_1 + 0x58) == 0) {
      *(undefined8 *)(puVar43 + -8) = 0x10030d;
      func_0x(lVar37,0);
    }
    if (*(int *)(param_1 + 0x270) == 0) {
      *(undefined8 *)(puVar43 + -8) = 0x100320;
      func_0x(lVar37,uVar40);
    }
    iVar21 = *(int *)(param_1 + 0x268);
    *(int *)((longlong)auStackX_20 + lVar23 + 4) = iVar21;
    *(undefined4 *)(&stack0x0000003c + lVar23) = 9;
    if (iVar21 != 1) {
      uVar12 = *(uint6 *)(**(longlong **)(lVar26 + 0x28) + 0x14);
      *(undefined8 *)(puVar43 + -8) = 0x100361;
      lVar26 = func_0x(lVar37,(ulonglong)uVar12 << 0x10);
      if (lVar26 != 0) {
        *(undefined8 *)(puVar43 + -8) = 0x10036e;
        uVar25 = func_0x(lVar37);
        *(undefined8 *)(&stack0x00000068 + lVar23) = uVar25;
      }
      cVar18 = *(char *)(param_1 + 0x278);
      if (*(longlong *)(param_1 + 0x58) == 0) {
        *(undefined8 *)(puVar43 + -8) = 0x10038b;
        func_0x(lVar37,0);
      }
      if (*(int *)(param_1 + 0x270) == 0) {
        *(undefined8 *)(puVar43 + -8) = 0x10039e;
        func_0x(lVar37,uVar40);
      }
      if (_DAT_ != 0) {
        plVar9 = *(longlong **)(param_1 + 0x100);
        puVar10 = *(undefined8 **)(*(longlong *)(*(longlong *)(&stack0x000000f8 + lVar23) + 8) + 8);
        iVar21 = *(int *)(plVar9 + 2);
        cVar17 = *(char *)(puVar10[6] + 0x1cde);
        pcVar8 = *(code **)*puVar10;
        *(undefined8 *)(puVar43 + -8) = 0x1003de;
        cVar16 = (*pcVar8)(puVar10);
        if (cVar16 == '\0') {
          if (cVar17 != '\0') {
LAB_:
            lVar37 = *(longlong *)(&stack0x000000f8 + lVar23);
            uVar25 = *(undefined8 *)(*(longlong *)(lVar37 + 8) + 8);
            if (*(int *)(lVar37 + 0x244) == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x100447;
              func_0x(uVar25);
            }
            else {
              *(undefined8 *)(puVar43 + -8) = 0x100440;
              func_0x();
            }
            goto LAB_;
          }
          if (iVar21 << 0x1f < 0) {
            if ((*(byte *)(plVar9 + 2) & 0x40) == 0) goto LAB_;
            lVar37 = puVar10[0x1a];
            if ((lVar37 != 0) && (*(char *)(lVar37 + 0x34) != '\0')) {
              if (*(longlong *)(lVar37 + 0x40) != 0) {
                lVar24 = *(longlong *)(*plVar9 + 0x28);
                LOCK();
                lVar26 = *(longlong *)(lVar37 + 0x128);
                if (lVar26 == 0) {
                  *(longlong *)(lVar37 + 0x128) = 0;
                  lVar26 = 0;
                }
                UNLOCK();
                if (lVar24 != lVar26) goto LAB_;
              }
              lVar37 = *(longlong *)(&stack0x000000f8 + lVar23);
              goto LAB_;
            }
          }
        }
        lVar37 = *(longlong *)(&stack0x000000f8 + lVar23);
      }
LAB_:
      if (cVar18 == '\0') {
        psVar57 = (short *)(lVar37 + 0xd8);
        ppbVar56 = (byte **)(lVar37 + 0xe0);
        puVar55 = (ushort *)(lVar37 + 0xda);
      }
      else {
        psVar57 = (short *)(lVar37 + 0x188);
        ppbVar56 = (byte **)(lVar37 + 400);
        puVar55 = (ushort *)(lVar37 + 0x18a);
      }
      *(short **)(&stack0x00000058 + lVar23) = psVar57;
      uVar40 = *(uint *)(puVar55 + 1);
      *(uint *)(&stack0x00000028 + lVar23) = uVar40;
      if (*psVar57 == 0) {
        if (uVar40 == 0) {
          *puVar55 = 0;
          uVar40 = *(uint *)(puVar55 + 7);
          uVar41 = (ulonglong)uVar40;
          *(uint *)(puVar55 + 9) = uVar40;
          pbVar3 = *(byte **)(puVar55 + 3);
          bVar34 = *pbVar3;
          if ((bVar34 & 0x10) != 0) {
            uVar40 = uVar40 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3) + 2;
            uVar41 = (ulonglong)uVar40;
            *(uint *)(puVar55 + 9) = uVar40;
            bVar34 = *pbVar3;
          }
          if ((bVar34 & 0x20) == 0) {
            *(int *)(puVar55 + 1) = (int)uVar41;
            puVar55[0xd] = 0;
            *(uint *)(puVar55 + 0xb) = uVar40;
          }
          else {
            puVar44 = (ushort *)(pbVar3 + uVar41);
            uVar39 = *puVar44;
            puVar55[0xd] = uVar39;
            if (uVar39 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10057c;
                  (*_DAT_)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x1005a2;
                  (*_DAT_)(1,0x1877a18,0x19976e8);
                }
              }
              uVar25 = *(undefined8 *)(puVar55 + 3);
              *(undefined8 *)(puVar43 + -8) = 0x1005b0;
              func_0x(uVar25,3);
              uVar39 = puVar55[0xd];
            }
            uVar40 = *(int *)(puVar55 + 9) + (uVar39 + 1) * 2;
            *(uint *)(puVar55 + 0xb) = uVar40;
            if (0x1f9e < uVar40) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10064b;
                  (*_DAT_)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x100671;
                  (*_DAT_)(1,0x1877a18,0x19976e8);
                }
              }
              uVar25 = *(undefined8 *)(puVar55 + 3);
              *(undefined8 *)(puVar43 + -8) = 0x10067f;
              func_0x(uVar25,4);
            }
            uVar39 = puVar44[puVar55[0xd]];
            *(uint *)(puVar55 + 1) = uVar39 & 0x7fff;
            if ((uVar39 & 0x7fff) < *(uint *)(puVar55 + 0xb)) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x100713;
                  (*_DAT_)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10073b;
                  (*_DAT_)(1,0x1877a18,0x19976e8);
                }
              }
              uVar25 = *(undefined8 *)(puVar55 + 3);
              *(undefined8 *)(puVar43 + -8) = 0x100749;
              func_0x(uVar25,4);
            }
            do {
              uVar39 = puVar55[0xd];
              if (-1 < (short)puVar44[(ulonglong)(uVar39 - 1) + 1]) break;
              lVar37 = *(longlong *)(puVar55 + 3);
              lVar26 = (ulonglong)*(uint *)(puVar55 + 9) + lVar37;
              uVar40 = (uint)uVar39;
              if (uVar40 == 1) {
                uVar48 = *(uint *)(puVar55 + 0xb);
                uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar40 * 2);
                uVar40 = uVar48;
LAB_:
                if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
              }
              else {
                uVar48 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                uVar40 = *(uint *)(puVar55 + 0xb);
                uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                if (uVar40 <= uVar48) goto LAB_;
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x1007b4;
                func_0x(lVar37,7);
                uVar40 = *(uint *)(puVar55 + 0xb);
              }
              if ((uVar48 < uVar40) || (*(uint *)(puVar55 + 1) < uVar48)) goto LAB_;
              if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(puVar55 + 3)) == 5) {
                *puVar55 = *puVar55 | 2;
                puVar55[0xd] = puVar55[0xd] - 1;
                puVar55[0x14] = (ushort)uVar48;
                lVar37 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(puVar55 + 3);
                uVar39 = puVar55[0x15] & 0xc7ff;
                if ((*(ushort *)(lVar37 + 2) & 0x4000) != 0) {
                  uVar39 = *(ushort *)(lVar37 + 2) & 0x3800 | puVar55[0x15] & 0xc7ff;
                }
                puVar55[0x15] = uVar39;
                puVar55[0x15] = (uVar39 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar39;
                break;
              }
              if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(puVar55 + 3)) < 0x400) break;
              *puVar55 = *puVar55 | 1;
              puVar1 = puVar55 + 0xd;
              *puVar1 = *puVar1 - 1;
            } while (*puVar1 != 0);
          }
          if ((**(byte **)(puVar55 + 3) & 0x40) == 0) {
            *(undefined4 *)(puVar55 + 0x12) = 0;
          }
          else {
            *(int *)(puVar55 + 0x12) = *(int *)(puVar55 + 1);
            *(int *)(puVar55 + 1) = *(int *)(puVar55 + 1) + 0xe;
            *(undefined8 *)(puVar43 + -8) = 0x10089f;
            puVar27 = (ulonglong *)func_0x();
            uVar41 = *puVar27;
            *(ulonglong *)(&stack0x00000110 + lVar23) = uVar41;
            iVar21 = 0;
            uVar35 = (ushort)(uVar41 >> 0x30);
            uVar39 = uVar35;
            if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
              uVar39 = uVar35 & 0xdfff;
              if ((uVar41 & 0x4000000000000000) != 0) {
                uVar39 = uVar35 | 0x2000;
              }
            }
            if (uVar39 == 0xfffc) {
              iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(puVar55 + 1) = *(int *)(puVar55 + 1) + iVar21;
          }
          uVar40 = *(uint *)(puVar55 + 1);
          if ((*(ulonglong *)(puVar55 + 0xe) != 0) &&
             (*(ulonglong *)(puVar55 + 0xe) < (ulonglong)uVar40 + *(longlong *)(puVar55 + 3))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar37 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8), lVar37 != 0 &&
                 (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                (*(char *)(lVar37 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x1009a0;
                (*_DAT_)(0x22,0x44,0x15);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x1009c6;
                (*_DAT_)(1,0x1877a18,0x19976e8);
              }
            }
            uVar25 = *(undefined8 *)(puVar55 + 3);
            *(undefined8 *)(puVar43 + -8) = 0x1009d4;
            func_0x(uVar25,0x12);
            uVar40 = *(uint *)(puVar55 + 1);
          }
          if (0x3f3b < uVar40 - 1) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar37 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar37 != 0 &&
                ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                 (*(char *)(lVar37 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x100a5f;
                (*_DAT_)(0x22,0x44,0x15);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x100a87;
                (*_DAT_)(1,0x1877a18,0x19976e8);
              }
            }
            uVar25 = *(undefined8 *)(puVar55 + 3);
            *(undefined8 *)(puVar43 + -8) = 0x100a95;
            func_0x(uVar25,5);
          }
        }
LAB_:
        uVar40 = *(uint *)(puVar55 + 1);
        *(uint *)(&stack0x00000028 + lVar23) = uVar40;
        if ((uVar40 < 9) &&
           (((**(byte **)(puVar55 + 3) & 0xe) == 0 || ((**(byte **)(puVar55 + 3) & 0xe) == 0xc)))) {
          *(undefined4 *)(&stack0x00000028 + lVar23) = 9;
        }
        lVar37 = *(longlong *)(&stack0x000000f8 + lVar23);
      }
      else {
        if (uVar40 == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x100acd;
          func_0x(puVar55);
          uVar40 = *(uint *)(puVar55 + 1);
          *(uint *)(&stack0x00000028 + lVar23) = uVar40;
        }
        if ((uVar40 < 9) &&
           (((**(byte **)(puVar55 + 3) & 0x1c) == 0 || ((**(byte **)(puVar55 + 3) & 0x1c) == 0xc))))
        {
          *(undefined4 *)(&stack0x00000028 + lVar23) = 9;
        }
      }
      if (*psVar57 == 0) {
        if ((**ppbVar56 & 0xe) == 2) goto LAB_;
LAB_:
        *(undefined8 *)(puVar43 + -8) = 0x100baf;
        func_0x(lVar37,&stack0x00000118 + lVar23,0);
      }
      else {
        if (((**ppbVar56 & 0x1c) - 0x10 & 0xfffffffb) != 0) goto LAB_;
LAB_:
        *(undefined8 *)(puVar43 + -8) = 0x100b11;
        puVar28 = (undefined4 *)func_0x(psVar57);
        if (puVar28 == (undefined4 *)0x0) {
          *(undefined8 *)(puVar43 + -8) = 0x100b2e;
          (*_DAT_)(6,0x55,0x10);
        }
        *(undefined4 *)(&stack0x00000118 + lVar23) = *puVar28;
        *(undefined2 *)(&stack0x0000011c + lVar23) = *(undefined2 *)(puVar28 + 1);
        *(undefined2 *)(&stack0x0000011e + lVar23) = *(undefined2 *)((longlong)puVar28 + 6);
        psVar57 = *(short **)(&stack0x000000e0 + lVar23);
        if (psVar57 != (short *)0x0) {
          if (*psVar57 == 0) {
            if ((**(byte **)(psVar57 + 4) & 0xe) != 2) {
              *(undefined8 *)(puVar43 + -8) = 0x100b88;
              func_0x(psVar57 + 1,&stack0x00000118 + lVar23);
LAB_:
              puVar55 = (ushort *)(psVar57 + 1);
              if (*pbVar5 != 0) {
                psVar49 = psVar57;
                if (*psVar57 == 0) {
                  if (*(int *)(psVar57 + 2) == 0) {
                    *puVar55 = 0;
                    uVar40 = *(uint *)(psVar57 + 8);
                    uVar41 = (ulonglong)uVar40;
                    *(uint *)(psVar57 + 10) = uVar40;
                    pbVar3 = *(byte **)(psVar57 + 4);
                    bVar34 = *pbVar3;
                    if ((bVar34 & 0x10) != 0) {
                      uVar40 = uVar40 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3) + 2;
                      uVar41 = (ulonglong)uVar40;
                      *(uint *)(psVar57 + 10) = uVar40;
                      bVar34 = *pbVar3;
                    }
                    if ((bVar34 & 0x20) == 0) {
                      *(int *)(psVar57 + 2) = (int)uVar41;
                      psVar57[0xe] = 0;
                      *(uint *)(psVar57 + 0xc) = uVar40;
                    }
                    else {
                      puVar44 = (ushort *)(pbVar3 + uVar41);
                      uVar39 = *puVar44;
                      psVar57[0xe] = uVar39;
                      if (uVar39 == 0) {
                        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                            (lVar37 = *(longlong *)
                                       ((ulonglong)*_DAT_ +
                                        *(longlong *)
                                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                         (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                           ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                            (*(char *)(lVar37 + 0x499) != '\0')))) {
                          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                            *(undefined8 *)(puVar43 + -8) = 0x100cc3;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar43 + 0x20) = 0;
                            *(undefined8 *)(puVar43 + -8) = 0x100ce9;
                            (*_DAT_)(1,0x1877a18,0x19976e8);
                          }
                        }
                        uVar25 = *(undefined8 *)(psVar57 + 4);
                        *(undefined8 *)(puVar43 + -8) = 0x100cf7;
                        func_0x(uVar25,3);
                        uVar39 = psVar57[0xe];
                      }
                      uVar40 = *(int *)(psVar57 + 10) + (uVar39 + 1) * 2;
                      *(uint *)(psVar57 + 0xc) = uVar40;
                      if (0x1f9e < uVar40) {
                        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                           ((lVar37 = *(longlong *)
                                       ((ulonglong)*_DAT_ +
                                        *(longlong *)
                                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                         (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                            ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                             (*(char *)(lVar37 + 0x499) != '\0')))))) {
                          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                            *(undefined8 *)(puVar43 + -8) = 0x100d8f;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar43 + 0x20) = 0;
                            *(undefined8 *)(puVar43 + -8) = 0x100db5;
                            (*_DAT_)(1,0x1877a18,0x19976e8);
                          }
                        }
                        uVar25 = *(undefined8 *)(psVar57 + 4);
                        *(undefined8 *)(puVar43 + -8) = 0x100dc3;
                        func_0x(uVar25,4);
                      }
                      uVar39 = puVar44[(ushort)psVar57[0xe]];
                      *(uint *)(psVar57 + 2) = uVar39 & 0x7fff;
                      if ((uVar39 & 0x7fff) < *(uint *)(psVar57 + 0xc)) {
                        if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                            (lVar37 = *(longlong *)
                                       ((ulonglong)*_DAT_ +
                                        *(longlong *)
                                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                         (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                           ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                            (*(char *)(lVar37 + 0x499) != '\0')))) {
                          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                            *(undefined8 *)(puVar43 + -8) = 0x100e57;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar43 + 0x20) = 0;
                            *(undefined8 *)(puVar43 + -8) = 0x100e7d;
                            (*_DAT_)(1,0x1877a18,0x19976e8);
                          }
                        }
                        uVar25 = *(undefined8 *)(psVar57 + 4);
                        *(undefined8 *)(puVar43 + -8) = 0x100e8b;
                        func_0x(uVar25,4);
                      }
                      do {
                        uVar39 = psVar57[0xe];
                        if (-1 < (short)puVar44[(ulonglong)(uVar39 - 1) + 1]) break;
                        lVar37 = *(longlong *)(psVar57 + 4);
                        lVar26 = (ulonglong)*(uint *)(psVar57 + 10) + lVar37;
                        uVar40 = (uint)uVar39;
                        if (uVar40 == 1) {
                          uVar48 = *(uint *)(psVar57 + 0xc);
                          uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar40 * 2);
                          uVar40 = uVar48;
LAB_:
                          if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
                        }
                        else {
                          uVar48 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                          uVar40 = *(uint *)(psVar57 + 0xc);
                          uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                          if (uVar40 <= uVar48) goto LAB_;
LAB_:
                          *(undefined8 *)(puVar43 + -8) = 0x100ef5;
                          func_0x(lVar37,7);
                          uVar40 = *(uint *)(psVar57 + 0xc);
                        }
                        if ((uVar48 < uVar40) || (*(uint *)(psVar57 + 2) < uVar48))
                        goto LAB_;
                        uVar39 = *(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar57 + 4));
                        if (uVar39 == 5) {
                          *puVar55 = *puVar55 | 2;
                          psVar57[0xe] = psVar57[0xe] + -1;
                          psVar57[0x15] = (short)uVar48;
                          lVar37 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(psVar57 + 4);
                          uVar39 = psVar57[0x16] & 0xc7ffU;
                          if ((*(ushort *)(lVar37 + 2) & 0x4000) != 0) {
                            uVar39 = *(ushort *)(lVar37 + 2) & 0x3800 | psVar57[0x16] & 0xc7ffU;
                          }
                          psVar57[0x16] = uVar39;
                          psVar57[0x16] = (uVar39 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar39;
                          break;
                        }
                        if (uVar39 < 0x400) break;
                        *puVar55 = *puVar55 | 1;
                        psVar49 = psVar57 + 0xe;
                        *psVar49 = *psVar49 + -1;
                      } while (*psVar49 != 0);
                    }
                    iVar21 = 0;
                    if ((**(byte **)(psVar57 + 4) & 0x40) == 0) {
                      *(undefined4 *)(psVar57 + 0x13) = 0;
                    }
                    else {
                      *(int *)(psVar57 + 0x13) = *(int *)(psVar57 + 2);
                      *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + 0xe;
                      *(undefined8 *)(puVar43 + -8) = 0x100fd7;
                      puVar27 = (ulonglong *)func_0x(puVar55);
                      uVar41 = *puVar27;
                      *(ulonglong *)(&stack0x00000120 + lVar23) = uVar41;
                      uVar35 = (ushort)(uVar41 >> 0x30);
                      uVar39 = uVar35;
                      if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                        uVar39 = uVar35 & 0xdfff;
                        if ((uVar41 & 0x4000000000000000) != 0) {
                          uVar39 = uVar35 | 0x2000;
                        }
                      }
                      if (uVar39 == 0xfffc) {
                        iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                      }
                      *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + iVar21;
                    }
                    uVar40 = *(uint *)(psVar57 + 2);
                    if ((*(ulonglong *)(psVar57 + 0xf) != 0) &&
                       (*(ulonglong *)(psVar57 + 0xf) <
                        (ulonglong)uVar40 + *(longlong *)(psVar57 + 4))) {
                      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                         (((lVar37 = *(longlong *)
                                      ((ulonglong)*_DAT_ +
                                       *(longlong *)
                                        (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                        (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                           (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                          (*(char *)(lVar37 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar43 + -8) = 0x1010d3;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x1010f9;
                          (*_DAT_)(1,0x1877a18,0x19976e8);
                        }
                      }
                      uVar25 = *(undefined8 *)(psVar57 + 4);
                      *(undefined8 *)(puVar43 + -8) = 0x101107;
                      func_0x(uVar25,0x12);
                      uVar40 = *(uint *)(psVar57 + 2);
                    }
                    if (0x3f3b < uVar40 - 1) {
                      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                         ((lVar37 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                          ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                           (*(char *)(lVar37 + 0x499) != '\0')))))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar43 + -8) = 0x101192;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x1011b8;
                          (*_DAT_)(1,0x1877a18,0x19976e8);
                        }
                      }
                      uVar25 = *(undefined8 *)(psVar57 + 4);
                      *(undefined8 *)(puVar43 + -8) = 0x1011c6;
                      func_0x(uVar25,5);
                    }
LAB_:
                    psVar49 = *(short **)(&stack0x000000e0 + lVar23);
                  }
                  uVar40 = *(uint *)(psVar57 + 2);
                  if (uVar40 < 9) {
                    bVar34 = **(byte **)(psVar57 + 4) & 0xe;
joined_r0x00101207:
                    if ((bVar34 == 0) || (bVar34 == 0xc)) {
                      uVar40 = 9;
                    }
                  }
                }
                else {
                  uVar40 = *(uint *)(psVar57 + 2);
                  if (uVar40 == 0) {
                    *(undefined8 *)(puVar43 + -8) = 0x1011f5;
                    func_0x(puVar55);
                    uVar40 = *(uint *)(psVar57 + 2);
                  }
                  if (uVar40 < 9) {
                    bVar34 = **(byte **)(psVar57 + 4) & 0x1c;
                    goto joined_r0x00101207;
                  }
                }
                sVar6 = *psVar49;
                uVar48 = 0x20;
                if (sVar6 != 0) {
                  uVar48 = 0x18;
                }
                if (uVar40 < uVar48) {
                  *(undefined4 *)(&stack0x00000128 + lVar23) = 0;
                  *(undefined2 *)(&stack0x0000012c + lVar23) = 0;
                  *(undefined2 *)(&stack0x0000012e + lVar23) = 0;
                  *(undefined8 *)(&stack0x000009a8 + lVar23) =
                       *(undefined8 *)(&stack0x00000128 + lVar23);
                  *(undefined4 *)(&stack0x000009b0 + lVar23) = 0;
                  *(undefined2 *)(&stack0x000009b4 + lVar23) = 0;
                  if (sVar6 == 0) {
                    *(undefined8 *)(puVar43 + -8) = 0x101271;
                    func_0x();
                  }
                  else {
                    *(undefined8 *)(puVar43 + -8) = 0x101278;
                    func_0x(puVar55,&stack0x000009a8 + lVar23);
                  }
                }
              }
            }
          }
          else if (((**(byte **)(psVar57 + 4) & 0x1c) - 0x10 & 0xfffffffb) != 0) {
            *(undefined8 *)(puVar43 + -8) = 0x100bda;
            func_0x(psVar57 + 1,&stack0x00000118 + lVar23);
            goto LAB_;
          }
        }
      }
      uVar40 = *(uint *)(&stack0x0000002c + lVar23);
    }
    lVar37 = *(longlong *)(&stack0x000000f8 + lVar23);
    if (*(char *)(lVar37 + 0x248) != '\0') {
      if (*(longlong *)(lVar37 + 0x28) == 0) {
        *(undefined8 *)(puVar43 + -8) = 0x1012a9;
        func_0x(lVar37,0);
      }
      if (*(int *)(lVar37 + 0x240) == 0) {
        *(undefined8 *)(puVar43 + -8) = 0x1012be;
        func_0x(lVar37,uVar40);
      }
      if (_DAT_ != 0) {
        plVar9 = *(longlong **)(lVar37 + 0xd0);
        puVar10 = *(undefined8 **)(*(longlong *)(lVar37 + 8) + 8);
        iVar21 = *(int *)(plVar9 + 2);
        cVar18 = *(char *)(puVar10[6] + 0x1cde);
        pcVar8 = *(code **)*puVar10;
        *(undefined8 *)(puVar43 + -8) = 0x1012f9;
        cVar17 = (*pcVar8)(puVar10);
        if (cVar17 == '\0') {
          if (cVar18 == '\0') {
            if (iVar21 << 0x1f < 0) {
              if ((*(byte *)(plVar9 + 2) & 0x40) == 0) goto LAB_;
              lVar26 = puVar10[0x1a];
              if (((lVar26 != 0) && (*(char *)(lVar26 + 0x34) != '\0')) &&
                 (*(longlong *)(lVar26 + 0x40) != 0)) {
                lVar11 = *(longlong *)(*plVar9 + 0x28);
                LOCK();
                lVar24 = *(longlong *)(lVar26 + 0x128);
                if (lVar24 == 0) {
                  *(longlong *)(lVar26 + 0x128) = 0;
                  lVar24 = 0;
                }
                UNLOCK();
                if (lVar11 != lVar24) goto LAB_;
              }
            }
          }
          else {
LAB_:
            uVar25 = *(undefined8 *)(*(longlong *)(lVar37 + 8) + 8);
            if (*(int *)(lVar37 + 0x244) == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x10135e;
              func_0x(uVar25);
            }
            else {
              *(undefined8 *)(puVar43 + -8) = 0x101357;
              func_0x();
            }
          }
        }
      }
      psVar57 = (short *)(lVar37 + 0xd8);
      bVar59 = true;
      sVar6 = *psVar57;
      *(short *)(&stack0x00000470 + lVar23) = sVar6;
      if (sVar6 == 0) {
        if (*(int *)(lVar37 + 0xdc) == 0) {
          *(undefined2 *)(lVar37 + 0xda) = 0;
          uVar40 = *(uint *)(lVar37 + 0xe8);
          uVar41 = (ulonglong)uVar40;
          *(uint *)(lVar37 + 0xec) = uVar40;
          pbVar3 = *(byte **)(lVar37 + 0xe0);
          bVar34 = *pbVar3;
          if ((bVar34 & 0x10) != 0) {
            uVar40 = uVar40 + 2 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3);
            uVar41 = (ulonglong)uVar40;
            *(uint *)(lVar37 + 0xec) = uVar40;
            bVar34 = *pbVar3;
          }
          if ((bVar34 & 0x20) == 0) {
            *(int *)(lVar37 + 0xdc) = (int)uVar41;
            *(undefined2 *)(lVar37 + 0xf4) = 0;
            *(uint *)(lVar37 + 0xf0) = uVar40;
          }
          else {
            puVar55 = (ushort *)(pbVar3 + uVar41);
            uVar39 = *puVar55;
            *(ushort *)(lVar37 + 0xf4) = uVar39;
            if (uVar39 == 0) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar26 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar26 != 0 &&
                  ((lVar26 = *(longlong *)(lVar26 + 0x60), lVar26 != 0 &&
                   (*(char *)(lVar26 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x101453;
                  (*_DAT_)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x101479;
                  (*_DAT_)(1,0x1877a18,0x19976e8);
                }
              }
              uVar25 = *(undefined8 *)(lVar37 + 0xe0);
              *(undefined8 *)(puVar43 + -8) = 0x101487;
              func_0x(uVar25,3);
              uVar39 = *(ushort *)(lVar37 + 0xf4);
            }
            uVar40 = *(int *)(lVar37 + 0xec) + 2 + (uint)uVar39 * 2;
            *(uint *)(lVar37 + 0xf0) = uVar40;
            if (0x1f9e < uVar40) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar26 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar26 != 0)) &&
                 ((lVar26 = *(longlong *)(lVar26 + 0x60), lVar26 != 0 &&
                  (*(char *)(lVar26 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x101523;
                  (*_DAT_)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x101549;
                  (*_DAT_)(1,0x1877a18,0x19976e8);
                }
              }
              uVar25 = *(undefined8 *)(lVar37 + 0xe0);
              *(undefined8 *)(puVar43 + -8) = 0x101557;
              func_0x(uVar25,4);
            }
            uVar39 = puVar55[*(ushort *)(lVar37 + 0xf4)];
            *(uint *)(lVar37 + 0xdc) = uVar39 & 0x7fff;
            if ((uVar39 & 0x7fff) < *(uint *)(lVar37 + 0xf0)) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar26 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar26 != 0 &&
                  ((lVar26 = *(longlong *)(lVar26 + 0x60), lVar26 != 0 &&
                   (*(char *)(lVar26 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x1015ec;
                  (*_DAT_)(0x22,0x44,0x15);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x101614;
                  (*_DAT_)(1,0x1877a18,0x19976e8);
                }
              }
              uVar25 = *(undefined8 *)(lVar37 + 0xe0);
              *(undefined8 *)(puVar43 + -8) = 0x101622;
              func_0x(uVar25,4);
            }
            do {
              uVar39 = *(ushort *)(lVar37 + 0xf4);
              if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
              lVar26 = *(longlong *)(lVar37 + 0xe0);
              lVar24 = (ulonglong)*(uint *)(lVar37 + 0xec) + lVar26;
              uVar40 = (uint)uVar39;
              if (uVar40 == 1) {
                uVar48 = *(uint *)(lVar37 + 0xf0);
                uVar39 = *(ushort *)(lVar24 + (longlong)(int)uVar40 * 2);
LAB_:
                if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
              }
              else {
                uVar48 = *(ushort *)(lVar24 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                uVar39 = *(ushort *)(lVar24 + (ulonglong)uVar39 * 2);
                if (*(uint *)(lVar37 + 0xf0) <= uVar48) goto LAB_;
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x101680;
                func_0x(lVar26,7);
                lVar26 = *(longlong *)(lVar37 + 0xe0);
                if (uVar48 < *(uint *)(lVar37 + 0xf0)) goto LAB_;
              }
              if (*(uint *)(lVar37 + 0xdc) < uVar48) goto LAB_;
              if (*(ushort *)((ulonglong)uVar48 + lVar26) == 5) {
                *(ushort *)(lVar37 + 0xda) = *(ushort *)(lVar37 + 0xda) | 2;
                *(short *)(lVar37 + 0xf4) = *(short *)(lVar37 + 0xf4) + -1;
                *(short *)(lVar37 + 0x102) = (short)uVar48;
                lVar26 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(lVar37 + 0xe0);
                uVar39 = *(ushort *)(lVar37 + 0x104) & 0xc7ff;
                if ((*(ushort *)(lVar26 + 2) & 0x4000) != 0) {
                  uVar39 = *(ushort *)(lVar26 + 2) & 0x3800 | uVar39;
                }
                *(ushort *)(lVar37 + 0x104) = uVar39;
                *(ushort *)(lVar37 + 0x104) = (uVar39 ^ *(ushort *)(lVar26 + 2)) & 0x7ff ^ uVar39;
                break;
              }
              if (*(ushort *)((ulonglong)uVar48 + lVar26) < 0x400) break;
              *(ushort *)(lVar37 + 0xda) = *(ushort *)(lVar37 + 0xda) | 1;
              psVar57 = (short *)(lVar37 + 0xf4);
              *psVar57 = *psVar57 + -1;
            } while (*psVar57 != 0);
          }
          if ((**(byte **)(lVar37 + 0xe0) & 0x40) == 0) {
            *(undefined4 *)(lVar37 + 0xfe) = 0;
          }
          else {
            *(int *)(lVar37 + 0xfe) = *(int *)(lVar37 + 0xdc);
            *(int *)(lVar37 + 0xdc) = *(int *)(lVar37 + 0xdc) + 0xe;
            *(undefined8 *)(puVar43 + -8) = 0x101763;
            puVar27 = (ulonglong *)func_0x();
            uVar41 = *puVar27;
            *(ulonglong *)(&stack0x00000130 + lVar23) = uVar41;
            uVar40 = 0;
            uVar35 = (ushort)(uVar41 >> 0x30);
            uVar39 = uVar35;
            if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
              uVar39 = uVar35 & 0xdfff;
              if ((uVar41 & 0x4000000000000000) != 0) {
                uVar39 = uVar35 | 0x2000;
              }
            }
            if (uVar39 == 0xfffc) {
              uVar40 = ((uint)(uVar41 >> 0x20) & 0xffff) >> 5;
            }
            *(int *)(lVar37 + 0xdc) = *(int *)(lVar37 + 0xdc) + uVar40;
          }
          uVar40 = *(uint *)(lVar37 + 0xdc);
          if ((*(ulonglong *)(lVar37 + 0xf6) != 0) &&
             (*(ulonglong *)(lVar37 + 0xf6) < (ulonglong)uVar40 + *(longlong *)(lVar37 + 0xe0))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar26 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8), lVar26 != 0 &&
                 (lVar26 = *(longlong *)(lVar26 + 0x60), lVar26 != 0)) &&
                (*(char *)(lVar26 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x101864;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x10188a;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
              }
            }
            uVar25 = *(undefined8 *)(lVar37 + 0xe0);
            *(undefined8 *)(puVar43 + -8) = 0x101898;
            func_0x(uVar25,0x12);
            uVar40 = *(uint *)(lVar37 + 0xdc);
          }
          if (0x3f3b < uVar40 - 1) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar26 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar26 != 0 &&
                ((lVar26 = *(longlong *)(lVar26 + 0x60), lVar26 != 0 &&
                 (*(char *)(lVar26 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x101923;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x10194b;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
              }
            }
            uVar25 = *(undefined8 *)(lVar37 + 0xe0);
            *(undefined8 *)(puVar43 + -8) = 0x101959;
            func_0x(uVar25,5);
          }
        }
LAB_:
        uVar40 = *(uint *)(lVar37 + 0xdc);
        uVar48 = uVar40;
        if ((uVar40 < 9) &&
           ((bVar34 = **(byte **)(lVar37 + 0xe0) & 0xe, bVar34 == 0 || (bVar34 == 0xc)))) {
          uVar48 = 9;
        }
        *(undefined4 *)(&stack0x00000480 + lVar23) = *(undefined4 *)(lVar37 + 0xe8);
        *(undefined2 *)(&stack0x00000472 + lVar23) = *(undefined2 *)(lVar37 + 0xda);
        *(uint *)(&stack0x00000474 + lVar23) = uVar40;
        *(undefined2 *)(&stack0x0000048c + lVar23) = *(undefined2 *)(lVar37 + 0xf4);
        *(undefined4 *)(&stack0x00000484 + lVar23) = *(undefined4 *)(lVar37 + 0xec);
        *(undefined4 *)(&stack0x00000488 + lVar23) = *(undefined4 *)(lVar37 + 0xf0);
        *(undefined4 *)(&stack0x00000496 + lVar23) = *(undefined4 *)(lVar37 + 0xfe);
        uVar25 = *(undefined8 *)(lVar37 + 0xe0);
        *(undefined8 *)(puVar43 + -8) = 0x1019d3;
        func_0x(&stack0x00000d48 + lVar23,0x1f9e,uVar25,uVar48);
        *(undefined **)(&stack0x00000478 + lVar23) = &stack0x00000d48 + lVar23;
        *(undefined8 *)(puVar43 + -8) = 0x1019ed;
        iVar21 = func_0x(&stack0x00000472 + lVar23);
        if (iVar21 != 0) {
          *(undefined8 *)(puVar43 + -8) = 0x101a05;
          uVar19 = func_0x(&stack0x00000472 + lVar23,&stack0x00000040 + lVar23);
          *(ushort *)(&stack0x0000049a + lVar23) = uVar19;
          uVar39 = *(ushort *)((ulonglong)uVar19 + *(longlong *)(&stack0x00000478 + lVar23) + 2);
          uVar35 = *(ushort *)(&stack0x0000049c + lVar23);
          if ((uVar39 >> 0xe & 1) == 0) {
            uVar35 = uVar35 & 0xc7ff;
          }
          else {
            uVar35 = uVar35 ^ (uVar39 ^ uVar35) & 0x3800;
          }
          *(ushort *)(&stack0x0000049c + lVar23) = uVar35;
          *(ushort *)(&stack0x0000049c + lVar23) =
               (uVar35 ^ *(ushort *)
                          ((ulonglong)uVar19 + *(longlong *)(&stack0x00000478 + lVar23) + 2)) &
               0x7ff ^ uVar35;
        }
      }
      else if ((*(longlong **)(lVar37 + 0xe8) == (longlong *)0x0) ||
              (**(longlong **)(lVar37 + 0xe8) == 0)) {
        *(undefined8 *)(puVar43 + -8) = 0x101aae;
        func_0x(&stack0x00000472 + lVar23,&stack0x00000d48 + lVar23,0x1f9e,lVar37 + 0xda);
        if (*psVar57 == 0) {
          uVar25 = 0;
        }
        else {
          uVar25 = *(undefined8 *)(lVar37 + 0xe8);
        }
        *(undefined8 *)(&stack0x00000480 + lVar23) = uVar25;
      }
      else {
        *(undefined8 *)(puVar43 + -8) = 0x101a8f;
        func_0x(&stack0x00000470 + lVar23,&stack0x00000d48 + lVar23,0x1f9e,psVar57);
      }
    }
    pcVar8 = *(code **)(*plVar51 + 0x58);
    *(undefined8 *)(puVar43 + -8) = 0x101acf;
    cVar18 = (*pcVar8)(plVar51);
    ppsVar53 = (short **)0x0;
    uVar36 = 0;
    if (cVar18 != '\0') {
      uVar36 = 0x80;
    }
    *(undefined4 *)((longlong)auStackX_20 + lVar23) = uVar36;
    lVar37 = 2;
    puVar28 = *(undefined4 **)(&stack0x00000070 + lVar23);
    puVar33 = (undefined4 *)(&stack0x000009a8 + lVar23);
    do {
      uVar36 = puVar28[1];
      uVar7 = puVar28[2];
      uVar13 = puVar28[3];
      *puVar33 = *puVar28;
      puVar33[1] = uVar36;
      puVar33[2] = uVar7;
      puVar33[3] = uVar13;
      uVar36 = puVar28[5];
      uVar7 = puVar28[6];
      uVar13 = puVar28[7];
      puVar33[4] = puVar28[4];
      puVar33[5] = uVar36;
      puVar33[6] = uVar7;
      puVar33[7] = uVar13;
      uVar36 = puVar28[9];
      uVar7 = puVar28[10];
      uVar13 = puVar28[0xb];
      puVar33[8] = puVar28[8];
      puVar33[9] = uVar36;
      puVar33[10] = uVar7;
      puVar33[0xb] = uVar13;
      uVar36 = puVar28[0xd];
      uVar7 = puVar28[0xe];
      uVar13 = puVar28[0xf];
      puVar33[0xc] = puVar28[0xc];
      puVar33[0xd] = uVar36;
      puVar33[0xe] = uVar7;
      puVar33[0xf] = uVar13;
      uVar36 = puVar28[0x11];
      uVar7 = puVar28[0x12];
      uVar13 = puVar28[0x13];
      puVar33[0x10] = puVar28[0x10];
      puVar33[0x11] = uVar36;
      puVar33[0x12] = uVar7;
      puVar33[0x13] = uVar13;
      uVar36 = puVar28[0x15];
      uVar7 = puVar28[0x16];
      uVar13 = puVar28[0x17];
      puVar33[0x14] = puVar28[0x14];
      puVar33[0x15] = uVar36;
      puVar33[0x16] = uVar7;
      puVar33[0x17] = uVar13;
      uVar36 = puVar28[0x19];
      uVar7 = puVar28[0x1a];
      uVar13 = puVar28[0x1b];
      puVar33[0x18] = puVar28[0x18];
      puVar33[0x19] = uVar36;
      puVar33[0x1a] = uVar7;
      puVar33[0x1b] = uVar13;
      uVar36 = puVar28[0x1d];
      uVar7 = puVar28[0x1e];
      uVar13 = puVar28[0x1f];
      puVar33[0x1c] = puVar28[0x1c];
      puVar33[0x1d] = uVar36;
      puVar33[0x1e] = uVar7;
      puVar33[0x1f] = uVar13;
      puVar28 = puVar28 + 0x20;
      lVar37 = lVar37 + -1;
      puVar33 = puVar33 + 0x20;
    } while (lVar37 != 0);
    ppsVar50 = (short **)(&stack0x00000470 + lVar23);
    if (!bVar59) {
      ppsVar50 = ppsVar53;
    }
    *(short ***)(&stack0x00000070 + lVar23) = ppsVar50;
    ppsVar58 = ppsVar53;
    if (*(int *)(&stack0x00000028 + lVar23) != 0) {
      ppsVar58 = *(short ***)(&stack0x00000058 + lVar23);
    }
    ppsVar42 = (short **)(&stack0x000003e8 + lVar23);
    if (*(longlong *)(&stack0x000000e0 + lVar23) == 0) {
      ppsVar42 = ppsVar53;
    }
    *(short ***)(&stack0x00000078 + lVar23) = ppsVar42;
    (&stack0x000002e8)[lVar23] = (&stack0x000002e8)[lVar23] & 0xfc;
    *(undefined8 *)(puVar43 + -8) = 0x101b80;
    func_0x(&stack0x000002f0 + lVar23);
    *(undefined4 *)(&stack0x000002f0 + lVar23) = *(undefined4 *)(&stack0x000009b0 + lVar23);
    *(undefined4 *)(&stack0x000002f4 + lVar23) = *(undefined4 *)(&stack0x000009b4 + lVar23);
    *(undefined4 *)(&stack0x000002f8 + lVar23) = *(undefined4 *)(&stack0x000009b8 + lVar23);
    *(undefined4 *)(&stack0x000002fc + lVar23) = *(undefined4 *)(&stack0x000009bc + lVar23);
    bVar34 = (byte)(&stack0x000009a8)[lVar23] >> 6 & 2 | (&stack0x000002e8)[lVar23] & 0xfc |
             (&stack0x000009a8)[lVar23] & 1;
    (&stack0x000002e8)[lVar23] = bVar34;
    if (((ppsVar42 != (short **)0x0) &&
        (lVar37 = *(longlong *)(&stack0x00000068 + lVar23), ppsVar53 = (short **)0x0, lVar37 != 0))
       && (*(char *)(lVar37 + 2) < '\0')) {
      *(undefined8 *)(puVar43 + -8) = 0x101bd6;
      func_0x(ppsVar42,lVar37);
      ppsVar53 = (short **)0x1;
      bVar34 = (&stack0x000002e8)[lVar23];
    }
    uVar36 = *(undefined4 *)(&stack0x000002e8 + lVar23);
    uVar7 = *(undefined4 *)(&stack0x000002ec + lVar23);
    uVar13 = *(undefined4 *)(&stack0x000002f0 + lVar23);
    uVar14 = *(undefined4 *)(&stack0x000002f4 + lVar23);
    uVar25 = *(undefined8 *)(&stack0x000002f8 + lVar23);
    if (ppsVar58 == (short **)0x0) {
      *(undefined4 *)(&stack0x00000308 + lVar23) = uVar36;
      *(undefined4 *)(&stack0x0000030c + lVar23) = uVar7;
      *(undefined4 *)(&stack0x00000310 + lVar23) = uVar13;
      *(undefined4 *)(&stack0x00000314 + lVar23) = uVar14;
      *(undefined8 *)(&stack0x00000318 + lVar23) = uVar25;
      if ((int)ppsVar53 == 0) {
        psVar57 = *ppsVar42;
      }
      else {
        psVar57 = ppsVar42[1];
      }
      puVar55 = (ushort *)(psVar57 + 1);
      if (*psVar57 == 0) {
        if (*(int *)(psVar57 + 2) == 0) {
          *puVar55 = 0;
          uVar40 = *(uint *)(psVar57 + 8);
          uVar41 = (ulonglong)uVar40;
          *(uint *)(psVar57 + 10) = uVar40;
          pbVar3 = *(byte **)(psVar57 + 4);
          bVar34 = *pbVar3;
          if ((bVar34 & 0x10) != 0) {
            uVar40 = uVar40 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3) + 2;
            uVar41 = (ulonglong)uVar40;
            *(uint *)(psVar57 + 10) = uVar40;
            bVar34 = *pbVar3;
          }
          if ((bVar34 & 0x20) == 0) {
            *(int *)(psVar57 + 2) = (int)uVar41;
            psVar57[0xe] = 0;
            *(uint *)(psVar57 + 0xc) = uVar40;
          }
          else {
            puVar44 = (ushort *)(pbVar3 + uVar41);
            uVar39 = *puVar44;
            psVar57[0xe] = uVar39;
            if (uVar39 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x101cf5;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x101d1d;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x101d2b;
              func_0x(uVar25,3);
              uVar39 = psVar57[0xe];
            }
            uVar40 = *(int *)(psVar57 + 10) + (uVar39 + 1) * 2;
            *(uint *)(psVar57 + 0xc) = uVar40;
            if (0x1f9e < uVar40) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x101dc3;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x101de9;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x101df7;
              func_0x(uVar25,4);
            }
            uVar39 = puVar44[(ushort)psVar57[0xe]];
            *(uint *)(psVar57 + 2) = uVar39 & 0x7fff;
            if ((uVar39 & 0x7fff) < *(uint *)(psVar57 + 0xc)) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x101e8b;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x101eb1;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x101ebf;
              func_0x(uVar25,4);
            }
            do {
              uVar39 = psVar57[0xe];
              if (-1 < (short)puVar44[(ulonglong)(uVar39 - 1) + 1]) break;
              lVar37 = *(longlong *)(psVar57 + 4);
              lVar26 = (ulonglong)*(uint *)(psVar57 + 10) + lVar37;
              uVar40 = (uint)uVar39;
              if (uVar40 == 1) {
                uVar48 = *(uint *)(psVar57 + 0xc);
                uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar40 * 2);
                uVar40 = uVar48;
LAB_:
                if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
              }
              else {
                uVar48 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                uVar40 = *(uint *)(psVar57 + 0xc);
                uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                if (uVar40 <= uVar48) goto LAB_;
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x101f34;
                func_0x(lVar37,7);
                uVar40 = *(uint *)(psVar57 + 0xc);
                lVar37 = *(longlong *)(psVar57 + 4);
              }
              if ((uVar48 < uVar40) || (*(uint *)(psVar57 + 2) < uVar48)) goto LAB_;
              if (*(ushort *)(lVar37 + (ulonglong)uVar48) == 5) {
                *puVar55 = *puVar55 | 2;
                psVar57[0xe] = psVar57[0xe] + -1;
                psVar57[0x15] = (short)uVar48;
                lVar37 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(psVar57 + 4);
                uVar39 = psVar57[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar37 + 2) & 0x4000) != 0) {
                  uVar39 = *(ushort *)(lVar37 + 2) & 0x3800 | psVar57[0x16] & 0xc7ffU;
                }
                psVar57[0x16] = uVar39;
                psVar57[0x16] = (uVar39 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar39;
                break;
              }
              if (*(ushort *)(lVar37 + (ulonglong)uVar48) < 0x400) break;
              *puVar55 = *puVar55 | 1;
              psVar49 = psVar57 + 0xe;
              *psVar49 = *psVar49 + -1;
            } while (*psVar49 != 0);
          }
          iVar21 = 0;
          if ((**(byte **)(psVar57 + 4) & 0x40) == 0) {
            *(undefined4 *)(psVar57 + 0x13) = 0;
          }
          else {
            *(int *)(psVar57 + 0x13) = *(int *)(psVar57 + 2);
            *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + 0xe;
            *(undefined8 *)(puVar43 + -8) = 0x102015;
            puVar27 = (ulonglong *)func_0x(puVar55);
            uVar41 = *puVar27;
            *(ulonglong *)(&stack0x00000138 + lVar23) = uVar41;
            uVar35 = (ushort)(uVar41 >> 0x30);
            uVar39 = uVar35;
            if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
              uVar39 = uVar35 & 0xdfff;
              if ((uVar41 & 0x4000000000000000) != 0) {
                uVar39 = uVar35 | 0x2000;
              }
            }
            if (uVar39 == 0xfffc) {
              iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + iVar21;
          }
          uVar40 = *(uint *)(psVar57 + 2);
          if ((*(ulonglong *)(psVar57 + 0xf) != 0) &&
             (*(ulonglong *)(psVar57 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar57 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar37 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8), lVar37 != 0 &&
                 (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                (*(char *)(lVar37 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x102110;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x102136;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
              }
            }
            uVar25 = *(undefined8 *)(psVar57 + 4);
            *(undefined8 *)(puVar43 + -8) = 0x102144;
            func_0x(uVar25,0x12);
            uVar40 = *(uint *)(psVar57 + 2);
          }
          if (0x3f3b < uVar40 - 1) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar37 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar37 != 0 &&
                ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                 (*(char *)(lVar37 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x1021cf;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x1021f5;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
              }
            }
            uVar25 = *(undefined8 *)(psVar57 + 4);
            *(undefined8 *)(puVar43 + -8) = 0x102203;
            func_0x(uVar25,5);
          }
        }
LAB_:
        uVar40 = *(uint *)(psVar57 + 2);
        *(uint *)(&stack0x00000044 + lVar23) = uVar40;
        if (uVar40 < 9) {
          bVar34 = **(byte **)(psVar57 + 4);
          if (((bVar34 & 0xe) != 0) && ((bVar34 & 0xe) != 0xc)) goto LAB_;
          uVar40 = 9;
          *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
        }
        else {
LAB_:
          bVar34 = **(byte **)(psVar57 + 4);
        }
        if ((bVar34 & 0x40) != 0) {
          uVar40 = *(uint *)(psVar57 + 0x13);
LAB_:
          *(uint *)(&stack0x00000044 + lVar23) = uVar40;
        }
      }
      else {
        uVar40 = *(uint *)(psVar57 + 2);
        *(uint *)(&stack0x00000044 + lVar23) = uVar40;
        if (uVar40 == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x10224d;
          func_0x(puVar55);
          uVar40 = *(uint *)(psVar57 + 2);
          *(uint *)(&stack0x00000044 + lVar23) = uVar40;
          if (uVar40 == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x10225f;
            func_0x(puVar55);
            uVar40 = *(uint *)(psVar57 + 2);
            *(uint *)(&stack0x00000044 + lVar23) = uVar40;
          }
        }
        if (uVar40 < 9) {
          bVar34 = **(byte **)(psVar57 + 4);
          if (((bVar34 & 0x1c) != 0) && ((bVar34 & 0x1c) != 0xc)) goto LAB_;
          uVar40 = 9;
          *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
        }
        else {
LAB_:
          bVar34 = **(byte **)(psVar57 + 4);
        }
        if ((bVar34 & 2) != 0) {
          uVar40 = *(uint *)(psVar57 + 0x18);
          goto LAB_;
        }
      }
      pcVar8 = *(code **)*plVar51;
      *(undefined8 *)(puVar43 + -8) = 0x1022a2;
      cVar18 = (*pcVar8)(plVar51);
      if (cVar18 == '\0') {
        if (((&stack0x00000308)[lVar23] & 1) == 0) {
LAB_:
          lVar37 = plVar51[0x1a];
          if (((&stack0x00000310)[lVar23] & 1) == 0) {
            pcVar8 = *(code **)*plVar51;
            *(undefined8 *)(puVar43 + -8) = 0x102906;
            cVar18 = (*pcVar8)(plVar51);
            if (cVar18 == '\0') {
              pcVar8 = *(code **)(*plVar51 + 0x88);
              *(undefined8 *)(puVar43 + -8) = 0x10291b;
              cVar18 = (*pcVar8)(plVar51);
              if (cVar18 != '\0') {
                if ((&stack0x00000311)[lVar23] != '\0') goto LAB_;
                if (lVar37 == 0) {
                  pcVar8 = *(code **)(*plVar51 + 0x18);
                  *(undefined8 *)(puVar43 + -8) = 0x10293f;
                  cVar18 = (*pcVar8)(plVar51);
                  if (cVar18 == '\0') goto LAB_;
                }
                if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
                  if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
                    if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                      if (plVar51[0x1a] == 0) {
                        pcVar8 = *(code **)(*plVar51 + 0x88);
                        *(undefined8 *)(puVar43 + -8) = 0x102984;
                        cVar18 = (*pcVar8)(plVar51);
                        if (cVar18 != '\0') {
                          pcVar8 = *(code **)(*plVar51 + 0x18);
                          *(undefined8 *)(puVar43 + -8) = 0x102992;
                          cVar18 = (*pcVar8)(plVar51);
                          if (cVar18 == '\0') {
                            *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                            goto LAB_;
                          }
                        }
                      }
                      *(undefined8 *)(puVar43 + -8) = 0x1029ab;
                      iVar21 = func_0x(plVar51);
                      if (iVar21 == 0) {
                        pcVar8 = *(code **)(*plVar51 + 0x270);
                        *(undefined8 *)(puVar43 + -8) = 0x1029bc;
                        (*pcVar8)(plVar51);
                      }
                      if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                        if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                          lVar26 = plVar51[0x1a];
                          *(undefined8 *)(puVar43 + -8) = 0x1029f7;
                          cVar18 = func_0x(lVar26);
                          if (((cVar18 != '\0') && (*(char *)(plVar51[0x1a] + 0x130) == '\0')) &&
                             (*(undefined *)(plVar51[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                            *(undefined8 *)(puVar43 + 0x20) = 0;
                            *(undefined8 *)(puVar43 + -8) = 0x102a3c;
                            func_0x(0x1f8b450,0x1c,0x10,1);
                          }
                        }
                        uVar48 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                      }
                      else {
                        pcVar8 = *(code **)(*plVar51 + 0x1e8);
                        *(undefined8 *)(puVar43 + -8) = 0x1029d3;
                        uVar25 = (*pcVar8)(plVar51);
                        *(undefined8 *)(puVar43 + -8) = 0x1029db;
                        uVar48 = func_0x(uVar25);
                      }
                      if (uVar48 != 0) goto LAB_;
                    }
                  }
                  else {
LAB_:
                    if (((*(byte *)(plVar51 + 0x4a) & 0x40) != 0) &&
                       ((&stack0x00000312)[lVar23] != '\0')) goto LAB_;
                  }
                }
              }
LAB_:
              if (((&stack0x00000310)[lVar23] & 0x1c) != 0) {
LAB_:
                if (lVar37 != 0) {
LAB_:
                  if (((&stack0x00000310)[lVar23] & 0x1c) == 0) {
                    if (*(longlong *)(&stack0x00000318 + lVar23) != 0) {
                      *(undefined8 *)(puVar43 + -8) = 0x102c77;
                      iVar21 = func_0x();
                      if (((iVar21 != 0) &&
                          (iVar21 = *(int *)(*(longlong *)
                                              (*(longlong *)(&stack0x00000318 + lVar23) + 8) + 0x100
                                            ), iVar21 != 0)) && (1 < iVar21 - 3U)) {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x102cbe;
                        (*_DAT_)(1,0x1a263c0,0x1a26410,0x116);
                      }
                      uVar25 = *(undefined8 *)(&stack0x00000318 + lVar23);
                      *(undefined8 *)(puVar43 + -8) = 0x102ccf;
                      iVar21 = func_0x(uVar25);
                      if (((iVar21 != 0) &&
                          ((*(byte *)(*(longlong *)(*(longlong *)(&stack0x00000318 + lVar23) + 8) +
                                     0x109) & 1) == 0)) &&
                         ((iVar21 = *(int *)(*(longlong *)
                                              (*(longlong *)(&stack0x00000318 + lVar23) + 8) + 0x100
                                            ), iVar21 != 0 && (1 < iVar21 - 3U)))) {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x102d1d;
                        (*_DAT_)(1,0x1a26440,0x1a26410,0x119);
                      }
                    }
                    if ((*(int *)(lVar37 + 0x78) < 1) && (*(int *)(lVar37 + 0x74) < 1)) {
                      if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
                        if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
                          if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                            if (plVar51[0x1a] == 0) {
                              pcVar8 = *(code **)(*plVar51 + 0x88);
                              *(undefined8 *)(puVar43 + -8) = 0x102d6e;
                              cVar18 = (*pcVar8)(plVar51);
                              if (cVar18 != '\0') {
                                pcVar8 = *(code **)(*plVar51 + 0x18);
                                *(undefined8 *)(puVar43 + -8) = 0x102d7c;
                                cVar18 = (*pcVar8)(plVar51);
                                if (cVar18 == '\0') {
                                  *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                                  goto LAB_;
                                }
                              }
                            }
                            *(undefined8 *)(puVar43 + -8) = 0x102d95;
                            iVar21 = func_0x(plVar51);
                            if (iVar21 == 0) {
                              pcVar8 = *(code **)(*plVar51 + 0x270);
                              *(undefined8 *)(puVar43 + -8) = 0x102da6;
                              (*pcVar8)(plVar51);
                            }
                            if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                              if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                                lVar26 = plVar51[0x1a];
                                *(undefined8 *)(puVar43 + -8) = 0x102de1;
                                cVar18 = func_0x(lVar26);
                                if (((cVar18 != '\0') && (*(char *)(plVar51[0x1a] + 0x130) == '\0'))
                                   && (*(undefined *)(plVar51[0x1a] + 0x130) = 1,
                                      *_DAT_ != '\0')) {
                                  *(undefined8 *)(puVar43 + 0x20) = 0;
                                  *(undefined8 *)(puVar43 + -8) = 0x102e26;
                                  func_0x(0x1f8b450,0x1c,0x10,1);
                                }
                              }
                              uVar48 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                            }
                            else {
                              pcVar8 = *(code **)(*plVar51 + 0x1e8);
                              *(undefined8 *)(puVar43 + -8) = 0x102dbd;
                              uVar25 = (*pcVar8)(plVar51);
                              *(undefined8 *)(puVar43 + -8) = 0x102dc5;
                              uVar48 = func_0x(uVar25);
                            }
                            if (uVar48 != 0) goto LAB_;
                          }
                        }
                        else {
LAB_:
                          if ((*(byte *)(plVar51 + 0x4a) & 0x10) != 0) goto LAB_;
                        }
                      }
LAB_:
                      if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
                        if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
                          if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                            if (plVar51[0x1a] == 0) {
                              pcVar8 = *(code **)(*plVar51 + 0x88);
                              *(undefined8 *)(puVar43 + -8) = 0x102e85;
                              cVar18 = (*pcVar8)(plVar51);
                              if (cVar18 != '\0') {
                                pcVar8 = *(code **)(*plVar51 + 0x18);
                                *(undefined8 *)(puVar43 + -8) = 0x102e93;
                                cVar18 = (*pcVar8)(plVar51);
                                if (cVar18 == '\0') {
                                  *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                                  goto LAB_;
                                }
                              }
                            }
                            *(undefined8 *)(puVar43 + -8) = 0x102eac;
                            iVar21 = func_0x(plVar51);
                            if (iVar21 == 0) {
                              pcVar8 = *(code **)(*plVar51 + 0x270);
                              *(undefined8 *)(puVar43 + -8) = 0x102ebd;
                              (*pcVar8)(plVar51);
                            }
                            if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                              if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                                lVar26 = plVar51[0x1a];
                                *(undefined8 *)(puVar43 + -8) = 0x102ef8;
                                cVar18 = func_0x(lVar26);
                                if (((cVar18 != '\0') && (*(char *)(plVar51[0x1a] + 0x130) == '\0'))
                                   && (*(undefined *)(plVar51[0x1a] + 0x130) = 1,
                                      *_DAT_ != '\0')) {
                                  *(undefined8 *)(puVar43 + 0x20) = 0;
                                  *(undefined8 *)(puVar43 + -8) = 0x102f3d;
                                  func_0x(0x1f8b450,0x1c,0x10,1);
                                }
                              }
                              uVar48 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                            }
                            else {
                              pcVar8 = *(code **)(*plVar51 + 0x1e8);
                              *(undefined8 *)(puVar43 + -8) = 0x102ed4;
                              uVar25 = (*pcVar8)(plVar51);
                              *(undefined8 *)(puVar43 + -8) = 0x102edc;
                              uVar48 = func_0x(uVar25);
                            }
                            if (uVar48 != 0) goto LAB_;
                          }
                        }
                        else {
LAB_:
                          if ((*(byte *)(plVar51 + 0x4a) & 0x40) != 0) goto LAB_;
                        }
                      }
                    }
                  }
LAB_:
                  *(undefined8 *)(puVar43 + -8) = 0x102f65;
                  func_0x(lVar37,0);
                }
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x102f6d;
                iVar21 = func_0x(plVar51);
                if (iVar21 == 0) {
                  pcVar8 = *(code **)(*plVar51 + 0x270);
                  *(undefined8 *)(puVar43 + -8) = 0x102f7e;
                  (*pcVar8)(plVar51);
                }
                lVar37 = plVar51[0x1a];
                if (((&stack0x00000310)[lVar23] & 0x24) == 0) {
                  if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
                    if ((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0) goto LAB_;
                    if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                      if (lVar37 == 0) {
                        pcVar8 = *(code **)(*plVar51 + 0x88);
                        *(undefined8 *)(puVar43 + -8) = 0x102fca;
                        cVar18 = (*pcVar8)(plVar51);
                        if (cVar18 != '\0') {
                          pcVar8 = *(code **)(*plVar51 + 0x18);
                          *(undefined8 *)(puVar43 + -8) = 0x102fd8;
                          cVar18 = (*pcVar8)(plVar51);
                          if (cVar18 == '\0') goto LAB_;
                        }
                      }
                      *(undefined8 *)(puVar43 + -8) = 0x102fe8;
                      iVar21 = func_0x(plVar51);
                      if (iVar21 == 0) {
                        pcVar8 = *(code **)(*plVar51 + 0x270);
                        *(undefined8 *)(puVar43 + -8) = 0x102ff9;
                        (*pcVar8)(plVar51);
                      }
                      if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                        if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                          lVar26 = plVar51[0x1a];
                          *(undefined8 *)(puVar43 + -8) = 0x103034;
                          cVar18 = func_0x(lVar26);
                          if (((cVar18 != '\0') && (*(char *)(plVar51[0x1a] + 0x130) == '\0')) &&
                             (*(undefined *)(plVar51[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                            *(undefined8 *)(puVar43 + 0x20) = 0;
                            *(undefined8 *)(puVar43 + -8) = 0x103079;
                            func_0x(0x1f8b450,0x1c,0x10,1);
                          }
                        }
                        uVar48 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                      }
                      else {
                        pcVar8 = *(code **)(*plVar51 + 0x1e8);
                        *(undefined8 *)(puVar43 + -8) = 0x103010;
                        uVar25 = (*pcVar8)(plVar51);
                        *(undefined8 *)(puVar43 + -8) = 0x103018;
                        uVar48 = func_0x(uVar25);
                      }
                      if (uVar48 != 0) goto LAB_;
                    }
                  }
                  if ((lVar37 == 0) || (*(int *)(lVar37 + 0x74) < 1)) goto LAB_;
                }
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x1030a8;
                iVar21 = func_0x(psVar57);
                if (iVar21 != 0) {
                  *(undefined8 *)(puVar43 + -8) = 0x1030bb;
                  func_0x(psVar57,&stack0x00000148 + lVar23);
                  uVar48 = 0;
                  uVar39 = *(ushort *)(&stack0x0000014e + lVar23);
                  uVar35 = uVar39;
                  if ((((uint)(int)(short)uVar39 >> 1 ^ (int)(short)uVar39) & 0x2000) != 0) {
                    uVar35 = uVar39 & 0xdfff;
                    if ((uVar39 >> 0xe & 1) != 0) {
                      uVar35 = uVar39 | 0x2000;
                    }
                  }
                  if (uVar35 == 0xfffc) {
                    uVar48 = (uint)(*(ushort *)(&stack0x0000014c + lVar23) >> 5);
                  }
                  uVar40 = uVar40 + uVar48;
                }
                lVar37 = plVar51[0x1a];
                pcVar8 = *(code **)(*plVar51 + 0x88);
                *(undefined8 *)(puVar43 + -8) = 0x103122;
                cVar18 = (*pcVar8)(plVar51);
                if ((((cVar18 == '\0') && (lVar37 != 0)) &&
                    ((0 < *(int *)(lVar37 + 0x78) || (0 < *(int *)(lVar37 + 0x74))))) &&
                   (uVar40 < 0x1f74)) {
                  uVar40 = uVar40 + 8;
                }
                *(uint *)(&stack0x00000044 + lVar23) = uVar40 + 0xe;
                bVar38 = 0;
                uVar36 = *(undefined4 *)((longlong)auStackX_20 + lVar23);
                uVar25 = *(undefined8 *)(&stack0x00000068 + lVar23);
                goto LAB_;
              }
              if (*(longlong *)(&stack0x00000318 + lVar23) != 0) {
                *(undefined8 *)(puVar43 + -8) = 0x102a89;
                iVar21 = func_0x();
                if (((iVar21 != 0) &&
                    (iVar21 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000318 + lVar23) + 8) +
                                      0x100), iVar21 != 0)) && (1 < iVar21 - 3U)) {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x102ad0;
                  (*_DAT_)(1,0x1a263c0,0x1a26410,0x116);
                }
                uVar25 = *(undefined8 *)(&stack0x00000318 + lVar23);
                *(undefined8 *)(puVar43 + -8) = 0x102ae1;
                iVar21 = func_0x(uVar25);
                if ((((iVar21 != 0) &&
                     ((*(byte *)(*(longlong *)(*(longlong *)(&stack0x00000318 + lVar23) + 8) + 0x109
                                ) & 1) == 0)) &&
                    (iVar21 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000318 + lVar23) + 8) +
                                      0x100), iVar21 != 0)) && (1 < iVar21 - 3U)) {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x102b2f;
                  (*_DAT_)(1,0x1a26440,0x1a26410,0x119);
                }
              }
              if ((lVar37 != 0) && ((0 < *(int *)(lVar37 + 0x78) || (0 < *(int *)(lVar37 + 0x74)))))
              goto LAB_;
              if ((*(byte *)(plVar51 + 0x4a) & 4) != 0) goto LAB_;
              if ((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0) goto LAB_;
              if ((*(byte *)(plVar51 + 0x43) & 1) == 0) goto LAB_;
              if (plVar51[0x1a] != 0) {
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x102ba3;
                iVar21 = func_0x(plVar51);
                if (iVar21 == 0) {
                  pcVar8 = *(code **)(*plVar51 + 0x270);
                  *(undefined8 *)(puVar43 + -8) = 0x102bb4;
                  (*pcVar8)(plVar51);
                }
                if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                  if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                    lVar26 = plVar51[0x1a];
                    *(undefined8 *)(puVar43 + -8) = 0x102bef;
                    cVar18 = func_0x(lVar26);
                    if (((cVar18 != '\0') && (*(char *)(plVar51[0x1a] + 0x130) == '\0')) &&
                       (*(undefined *)(plVar51[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x102c34;
                      func_0x(0x1f8b450,0x1c,0x10,1);
                    }
                  }
                  uVar48 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                }
                else {
                  pcVar8 = *(code **)(*plVar51 + 0x1e8);
                  *(undefined8 *)(puVar43 + -8) = 0x102bcb;
                  uVar25 = (*pcVar8)(plVar51);
                  *(undefined8 *)(puVar43 + -8) = 0x102bd3;
                  uVar48 = func_0x(uVar25);
                }
                if (uVar48 == 0) goto LAB_;
                goto LAB_;
              }
              pcVar8 = *(code **)(*plVar51 + 0x88);
              *(undefined8 *)(puVar43 + -8) = 0x102b85;
              cVar18 = (*pcVar8)(plVar51);
              if (cVar18 == '\0') goto LAB_;
              pcVar8 = *(code **)(*plVar51 + 0x18);
              *(undefined8 *)(puVar43 + -8) = 0x102b93;
              cVar18 = (*pcVar8)(plVar51);
              if (cVar18 != '\0') goto LAB_;
LAB_:
              *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
            }
          }
        }
        else {
          pcVar8 = *(code **)(*plVar51 + 0x88);
          *(undefined8 *)(puVar43 + -8) = 0x1028d3;
          cVar18 = (*pcVar8)(plVar51);
          if (cVar18 == '\0') goto LAB_;
          pcVar8 = *(code **)(*plVar51 + 0x18);
          *(undefined8 *)(puVar43 + -8) = 0x1028e1;
          cVar18 = (*pcVar8)(plVar51);
          if (cVar18 != '\0') goto LAB_;
        }
LAB_:
        *(undefined8 *)(puVar43 + -8) = 0x103167;
        iVar21 = func_0x(psVar57);
        if (iVar21 != 0) {
          if (*psVar57 != 0) goto LAB_;
          if (*(int *)(psVar57 + 2) == 0) {
            *puVar55 = 0;
            uVar40 = *(uint *)(psVar57 + 8);
            uVar41 = (ulonglong)uVar40;
            *(uint *)(psVar57 + 10) = uVar40;
            pbVar3 = *(byte **)(psVar57 + 4);
            bVar34 = *pbVar3;
            if ((bVar34 & 0x10) != 0) {
              uVar40 = uVar40 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3) + 2;
              uVar41 = (ulonglong)uVar40;
              *(uint *)(psVar57 + 10) = uVar40;
              bVar34 = *pbVar3;
            }
            if ((bVar34 & 0x20) == 0) {
              *(int *)(psVar57 + 2) = (int)uVar41;
              psVar57[0xe] = 0;
              *(uint *)(psVar57 + 0xc) = uVar40;
            }
            else {
              puVar44 = (ushort *)(pbVar3 + uVar41);
              uVar39 = *puVar44;
              psVar57[0xe] = uVar39;
              if (uVar39 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10324f;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x103275;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                  }
                }
                uVar25 = *(undefined8 *)(psVar57 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x103283;
                func_0x(uVar25,3);
                uVar39 = psVar57[0xe];
              }
              uVar40 = *(int *)(psVar57 + 10) + (uVar39 + 1) * 2;
              *(uint *)(psVar57 + 0xc) = uVar40;
              if (0x1f9e < uVar40) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                    ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                     (*(char *)(lVar37 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x10331b;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x103341;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                  }
                }
                uVar25 = *(undefined8 *)(psVar57 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x10334f;
                func_0x(uVar25,4);
              }
              uVar39 = puVar44[(ushort)psVar57[0xe]];
              *(uint *)(psVar57 + 2) = uVar39 & 0x7fff;
              if ((uVar39 & 0x7fff) < *(uint *)(psVar57 + 0xc)) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1033e3;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x103409;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                  }
                }
                uVar25 = *(undefined8 *)(psVar57 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x103417;
                func_0x(uVar25,4);
              }
              do {
                uVar39 = psVar57[0xe];
                if (-1 < (short)puVar44[(ulonglong)(uVar39 - 1) + 1]) break;
                lVar37 = *(longlong *)(psVar57 + 4);
                lVar26 = (ulonglong)*(uint *)(psVar57 + 10) + lVar37;
                uVar40 = (uint)uVar39;
                if (uVar40 == 1) {
                  uVar48 = *(uint *)(psVar57 + 0xc);
                  uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar40 * 2);
                  uVar40 = uVar48;
LAB_:
                  if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
                }
                else {
                  uVar48 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                  uVar40 = *(uint *)(psVar57 + 0xc);
                  uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                  if (uVar40 <= uVar48) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar43 + -8) = 0x103484;
                  func_0x(lVar37,7);
                  uVar40 = *(uint *)(psVar57 + 0xc);
                }
                if ((uVar48 < uVar40) || (*(uint *)(psVar57 + 2) < uVar48)) goto LAB_;
                if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar57 + 4)) == 5) {
                  *puVar55 = *puVar55 | 2;
                  psVar57[0xe] = psVar57[0xe] + -1;
                  psVar57[0x15] = (short)uVar48;
                  lVar37 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(psVar57 + 4);
                  uVar39 = psVar57[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar37 + 2) & 0x4000) != 0) {
                    uVar39 = *(ushort *)(lVar37 + 2) & 0x3800 | psVar57[0x16] & 0xc7ffU;
                  }
                  psVar57[0x16] = uVar39;
                  psVar57[0x16] = (uVar39 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar39;
                  break;
                }
                if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar57 + 4)) < 0x400) break;
                *puVar55 = *puVar55 | 1;
                psVar49 = psVar57 + 0xe;
                *psVar49 = *psVar49 + -1;
              } while (*psVar49 != 0);
            }
            iVar21 = 0;
            if ((**(byte **)(psVar57 + 4) & 0x40) == 0) {
              *(undefined4 *)(psVar57 + 0x13) = 0;
            }
            else {
              *(int *)(psVar57 + 0x13) = *(int *)(psVar57 + 2);
              *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + 0xe;
              *(undefined8 *)(puVar43 + -8) = 0x103567;
              puVar27 = (ulonglong *)func_0x(puVar55);
              uVar41 = *puVar27;
              *(ulonglong *)(&stack0x00000150 + lVar23) = uVar41;
              uVar35 = (ushort)(uVar41 >> 0x30);
              uVar39 = uVar35;
              if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                uVar39 = uVar35 & 0xdfff;
                if ((uVar41 & 0x4000000000000000) != 0) {
                  uVar39 = uVar35 | 0x2000;
                }
              }
              if (uVar39 == 0xfffc) {
                iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + iVar21;
            }
            uVar40 = *(uint *)(psVar57 + 2);
            if ((*(ulonglong *)(psVar57 + 0xf) != 0) &&
               (*(ulonglong *)(psVar57 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar57 + 4))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar37 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                   (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x103663;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x103689;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x103697;
              func_0x(uVar25,0x12);
              uVar40 = *(uint *)(psVar57 + 2);
            }
            if (0x3f3b < uVar40 - 1) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x103722;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x103748;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x103756;
              func_0x(uVar25,5);
            }
          }
LAB_:
          uVar40 = *(uint *)(psVar57 + 2);
          *(uint *)(&stack0x00000044 + lVar23) = uVar40;
          if (uVar40 < 9) {
            if ((**(byte **)(psVar57 + 4) & 0xe) != 0) {
              bVar59 = (**(byte **)(psVar57 + 4) & 0xe) == 0xc;
              goto LAB_;
            }
            goto LAB_;
          }
        }
      }
      else if (*psVar57 == 0) {
        if (*(int *)(psVar57 + 2) == 0) {
          *puVar55 = 0;
          uVar40 = *(uint *)(psVar57 + 8);
          uVar41 = (ulonglong)uVar40;
          *(uint *)(psVar57 + 10) = uVar40;
          pbVar3 = *(byte **)(psVar57 + 4);
          bVar34 = *pbVar3;
          if ((bVar34 & 0x10) != 0) {
            uVar40 = uVar40 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3) + 2;
            uVar41 = (ulonglong)uVar40;
            *(uint *)(psVar57 + 10) = uVar40;
            bVar34 = *pbVar3;
          }
          if ((bVar34 & 0x20) == 0) {
            *(int *)(psVar57 + 2) = (int)uVar41;
            psVar57[0xe] = 0;
            *(uint *)(psVar57 + 0xc) = uVar40;
          }
          else {
            puVar44 = (ushort *)(pbVar3 + uVar41);
            uVar39 = *puVar44;
            psVar57[0xe] = uVar39;
            if (uVar39 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10238a;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x1023b0;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x1023be;
              func_0x(uVar25,3);
              uVar39 = psVar57[0xe];
            }
            uVar40 = *(int *)(psVar57 + 10) + (uVar39 + 1) * 2;
            *(uint *)(psVar57 + 0xc) = uVar40;
            if (0x1f9e < uVar40) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x102456;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10247c;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x10248a;
              func_0x(uVar25,4);
            }
            uVar39 = puVar44[(ushort)psVar57[0xe]];
            *(uint *)(psVar57 + 2) = uVar39 & 0x7fff;
            if ((uVar39 & 0x7fff) < *(uint *)(psVar57 + 0xc)) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10251e;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x102544;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x102552;
              func_0x(uVar25,4);
            }
            do {
              uVar39 = psVar57[0xe];
              if (-1 < (short)puVar44[(ulonglong)(uVar39 - 1) + 1]) break;
              lVar37 = *(longlong *)(psVar57 + 4);
              lVar26 = (ulonglong)*(uint *)(psVar57 + 10) + lVar37;
              uVar40 = (uint)uVar39;
              if (uVar40 == 1) {
                uVar48 = *(uint *)(psVar57 + 0xc);
                uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar40 * 2);
                uVar40 = uVar48;
LAB_:
                if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
              }
              else {
                uVar48 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                uVar40 = *(uint *)(psVar57 + 0xc);
                uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                if (uVar40 <= uVar48) goto LAB_;
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x1025c4;
                func_0x(lVar37,7);
                uVar40 = *(uint *)(psVar57 + 0xc);
              }
              if ((uVar48 < uVar40) || (*(uint *)(psVar57 + 2) < uVar48)) goto LAB_;
              if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar57 + 4)) == 5) {
                *puVar55 = *puVar55 | 2;
                psVar57[0xe] = psVar57[0xe] + -1;
                psVar57[0x15] = (short)uVar48;
                lVar37 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(psVar57 + 4);
                uVar39 = psVar57[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar37 + 2) & 0x4000) != 0) {
                  uVar39 = *(ushort *)(lVar37 + 2) & 0x3800 | psVar57[0x16] & 0xc7ffU;
                }
                psVar57[0x16] = uVar39;
                psVar57[0x16] = (uVar39 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar39;
                break;
              }
              if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar57 + 4)) < 0x400) break;
              *puVar55 = *puVar55 | 1;
              psVar49 = psVar57 + 0xe;
              *psVar49 = *psVar49 + -1;
            } while (*psVar49 != 0);
          }
          iVar21 = 0;
          if ((**(byte **)(psVar57 + 4) & 0x40) == 0) {
            *(undefined4 *)(psVar57 + 0x13) = 0;
          }
          else {
            *(int *)(psVar57 + 0x13) = *(int *)(psVar57 + 2);
            *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + 0xe;
            *(undefined8 *)(puVar43 + -8) = 0x1026a7;
            puVar27 = (ulonglong *)func_0x(puVar55);
            uVar41 = *puVar27;
            *(ulonglong *)(&stack0x00000140 + lVar23) = uVar41;
            uVar35 = (ushort)(uVar41 >> 0x30);
            uVar39 = uVar35;
            if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
              uVar39 = uVar35 & 0xdfff;
              if ((uVar41 & 0x4000000000000000) != 0) {
                uVar39 = uVar35 | 0x2000;
              }
            }
            if (uVar39 == 0xfffc) {
              iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + iVar21;
          }
          uVar40 = *(uint *)(psVar57 + 2);
          if ((*(ulonglong *)(psVar57 + 0xf) != 0) &&
             (*(ulonglong *)(psVar57 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar57 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar37 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8), lVar37 != 0 &&
                 (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                (*(char *)(lVar37 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x1027a3;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x1027c9;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
              }
            }
            uVar25 = *(undefined8 *)(psVar57 + 4);
            *(undefined8 *)(puVar43 + -8) = 0x1027d7;
            func_0x(uVar25,0x12);
            uVar40 = *(uint *)(psVar57 + 2);
          }
          if (0x3f3b < uVar40 - 1) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar37 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar37 != 0 &&
                ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                 (*(char *)(lVar37 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x102862;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x102888;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
              }
            }
            uVar25 = *(undefined8 *)(psVar57 + 4);
            *(undefined8 *)(puVar43 + -8) = 0x102896;
            func_0x(uVar25,5);
          }
        }
LAB_:
        uVar40 = *(uint *)(psVar57 + 2);
        *(uint *)(&stack0x00000044 + lVar23) = uVar40;
        if (uVar40 < 9) {
          if ((**(byte **)(psVar57 + 4) & 0xe) != 0) {
            bVar59 = (**(byte **)(psVar57 + 4) & 0xe) == 0xc;
LAB_:
            if (!bVar59) goto LAB_;
          }
LAB_:
          *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
        }
      }
      else {
LAB_:
        uVar40 = *(uint *)(psVar57 + 2);
        *(uint *)(&stack0x00000044 + lVar23) = uVar40;
        if (uVar40 == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x103784;
          func_0x(puVar55);
          uVar40 = *(uint *)(psVar57 + 2);
          *(uint *)(&stack0x00000044 + lVar23) = uVar40;
        }
        if (uVar40 < 9) {
          if ((**(byte **)(psVar57 + 4) & 0x1c) != 0) {
            bVar59 = (**(byte **)(psVar57 + 4) & 0x1c) == 0xc;
            goto LAB_;
          }
          goto LAB_;
        }
      }
LAB_:
      bVar38 = 0;
      uVar36 = *(undefined4 *)((longlong)auStackX_20 + lVar23);
      uVar25 = *(undefined8 *)(&stack0x00000068 + lVar23);
    }
    else if (ppsVar42 == (short **)0x0) {
      *(undefined4 *)(&stack0x00000328 + lVar23) = uVar36;
      *(undefined4 *)(&stack0x0000032c + lVar23) = uVar7;
      *(undefined4 *)(&stack0x00000330 + lVar23) = uVar13;
      *(undefined4 *)(&stack0x00000334 + lVar23) = uVar14;
      *(undefined8 *)(&stack0x00000338 + lVar23) = uVar25;
      ppsVar53 = ppsVar58;
      if (ppsVar50 != (short **)0x0) {
        ppsVar53 = ppsVar50;
      }
      bVar38 = 0;
      if ((bVar34 & 3) == 0) {
        lVar37 = plVar51[0x1a];
        if (((&stack0x000002f0)[lVar23] & 1) == 0) {
          pcVar8 = *(code **)*plVar51;
          *(undefined8 *)(puVar43 + -8) = 0x103801;
          cVar18 = (*pcVar8)(plVar51);
          if (cVar18 != '\0') goto LAB_;
          pcVar8 = *(code **)(*plVar51 + 0x88);
          *(undefined8 *)(puVar43 + -8) = 0x103816;
          cVar18 = (*pcVar8)(plVar51);
          if (cVar18 != '\0') {
            if ((&stack0x00000331)[lVar23] != '\0') goto LAB_;
            if (lVar37 == 0) {
              pcVar8 = *(code **)(*plVar51 + 0x18);
              *(undefined8 *)(puVar43 + -8) = 0x10383a;
              cVar18 = (*pcVar8)(plVar51);
              if (cVar18 == '\0') goto LAB_;
            }
            if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
                if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                  if (plVar51[0x1a] == 0) {
                    pcVar8 = *(code **)(*plVar51 + 0x88);
                    *(undefined8 *)(puVar43 + -8) = 0x10387e;
                    cVar18 = (*pcVar8)(plVar51);
                    if (cVar18 != '\0') {
                      pcVar8 = *(code **)(*plVar51 + 0x18);
                      *(undefined8 *)(puVar43 + -8) = 0x10388c;
                      cVar18 = (*pcVar8)(plVar51);
                      if (cVar18 == '\0') {
                        *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                        goto LAB_;
                      }
                    }
                  }
                  *(undefined8 *)(puVar43 + -8) = 0x1038a5;
                  iVar21 = func_0x(plVar51);
                  if (iVar21 == 0) {
                    pcVar8 = *(code **)(*plVar51 + 0x270);
                    *(undefined8 *)(puVar43 + -8) = 0x1038b6;
                    (*pcVar8)(plVar51);
                  }
                  if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                    if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                      lVar26 = plVar51[0x1a];
                      *(undefined8 *)(puVar43 + -8) = 0x1038f1;
                      cVar18 = func_0x(lVar26);
                      if (((cVar18 != '\0') && (*(char *)(plVar51[0x1a] + 0x130) == '\0')) &&
                         (*(undefined *)(plVar51[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x103936;
                        func_0x(0x1f8b450,0x1c,0x10,1);
                      }
                    }
                    uVar40 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                  }
                  else {
                    pcVar8 = *(code **)(*plVar51 + 0x1e8);
                    *(undefined8 *)(puVar43 + -8) = 0x1038cd;
                    uVar25 = (*pcVar8)(plVar51);
                    *(undefined8 *)(puVar43 + -8) = 0x1038d5;
                    uVar40 = func_0x(uVar25);
                  }
                  if (uVar40 != 0) goto LAB_;
                }
              }
              else {
LAB_:
                if (((*(byte *)(plVar51 + 0x4a) & 0x40) != 0) &&
                   ((&stack0x00000332)[lVar23] != '\0')) goto LAB_;
              }
            }
          }
LAB_:
          if (((&stack0x00000330)[lVar23] & 0x1c) != 0) goto LAB_;
          if (*(longlong *)(&stack0x00000338 + lVar23) != 0) {
            *(undefined8 *)(puVar43 + -8) = 0x103980;
            iVar21 = func_0x();
            if (((iVar21 != 0) &&
                (iVar21 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000338 + lVar23) + 8) +
                                  0x100), iVar21 != 0)) && (1 < iVar21 - 3U)) {
              *(undefined8 *)(puVar43 + 0x20) = 0;
              *(undefined8 *)(puVar43 + -8) = 0x1039c5;
              (*_DAT_)(1,0x1a263c0,0x1a26410,0x116);
            }
            uVar25 = *(undefined8 *)(&stack0x00000338 + lVar23);
            *(undefined8 *)(puVar43 + -8) = 0x1039d1;
            iVar21 = func_0x(uVar25);
            if ((((iVar21 != 0) &&
                 ((*(byte *)(*(longlong *)(*(longlong *)(&stack0x00000338 + lVar23) + 8) + 0x109) &
                  1) == 0)) &&
                (iVar21 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000338 + lVar23) + 8) +
                                  0x100), iVar21 != 0)) && (1 < iVar21 - 3U)) {
              *(undefined8 *)(puVar43 + 0x20) = 0;
              *(undefined8 *)(puVar43 + -8) = 0x103a1f;
              (*_DAT_)(1,0x1a26440,0x1a26410,0x119);
            }
          }
          if ((lVar37 == 0) || ((*(int *)(lVar37 + 0x78) < 1 && (*(int *)(lVar37 + 0x74) < 1)))) {
            if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0) {
LAB_:
                if (lVar37 != 0) goto LAB_;
                goto LAB_;
              }
              if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                if (plVar51[0x1a] == 0) {
                  pcVar8 = *(code **)(*plVar51 + 0x88);
                  *(undefined8 *)(puVar43 + -8) = 0x103a72;
                  cVar18 = (*pcVar8)(plVar51);
                  if (cVar18 != '\0') {
                    pcVar8 = *(code **)(*plVar51 + 0x18);
                    *(undefined8 *)(puVar43 + -8) = 0x103a80;
                    cVar18 = (*pcVar8)(plVar51);
                    if (cVar18 == '\0') {
                      *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                      goto LAB_;
                    }
                  }
                }
                *(undefined8 *)(puVar43 + -8) = 0x103a99;
                iVar21 = func_0x(plVar51);
                if (iVar21 == 0) {
                  pcVar8 = *(code **)(*plVar51 + 0x270);
                  *(undefined8 *)(puVar43 + -8) = 0x103aaa;
                  (*pcVar8)(plVar51);
                }
                if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                  if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                    lVar26 = plVar51[0x1a];
                    *(undefined8 *)(puVar43 + -8) = 0x103ae5;
                    cVar18 = func_0x(lVar26);
                    if (((cVar18 != '\0') && (*(char *)(plVar51[0x1a] + 0x130) == '\0')) &&
                       (*(undefined *)(plVar51[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x103b2a;
                      func_0x(0x1f8b450,0x1c,0x10,1);
                    }
                  }
                  uVar40 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                }
                else {
                  pcVar8 = *(code **)(*plVar51 + 0x1e8);
                  *(undefined8 *)(puVar43 + -8) = 0x103ac1;
                  uVar25 = (*pcVar8)(plVar51);
                  *(undefined8 *)(puVar43 + -8) = 0x103ac9;
                  uVar40 = func_0x(uVar25);
                }
                if (uVar40 != 0) goto LAB_;
              }
            }
            goto LAB_;
          }
LAB_:
          if (((&stack0x00000330)[lVar23] & 0x1c) == 0) {
            if (*(longlong *)(&stack0x00000338 + lVar23) != 0) {
              *(undefined8 *)(puVar43 + -8) = 0x103b6a;
              iVar21 = func_0x();
              if (((iVar21 != 0) &&
                  (iVar21 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000338 + lVar23) + 8) +
                                    0x100), iVar21 != 0)) && (1 < iVar21 - 3U)) {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x103baf;
                (*_DAT_)(1,0x1a263c0,0x1a26410,0x116);
              }
              uVar25 = *(undefined8 *)(&stack0x00000338 + lVar23);
              *(undefined8 *)(puVar43 + -8) = 0x103bbb;
              iVar21 = func_0x(uVar25);
              if (((iVar21 != 0) &&
                  ((*(byte *)(*(longlong *)(*(longlong *)(&stack0x00000338 + lVar23) + 8) + 0x109) &
                   1) == 0)) &&
                 ((iVar21 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000338 + lVar23) + 8) +
                                    0x100), iVar21 != 0 && (1 < iVar21 - 3U)))) {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x103c09;
                (*_DAT_)(1,0x1a26440,0x1a26410,0x119);
              }
            }
            if ((*(int *)(lVar37 + 0x78) < 1) && (*(int *)(lVar37 + 0x74) < 1)) {
              if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
                if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
                  if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                    if (plVar51[0x1a] == 0) {
                      pcVar8 = *(code **)(*plVar51 + 0x88);
                      *(undefined8 *)(puVar43 + -8) = 0x103c57;
                      cVar18 = (*pcVar8)(plVar51);
                      if (cVar18 != '\0') {
                        pcVar8 = *(code **)(*plVar51 + 0x18);
                        *(undefined8 *)(puVar43 + -8) = 0x103c65;
                        cVar18 = (*pcVar8)(plVar51);
                        if (cVar18 == '\0') {
                          *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                          goto LAB_;
                        }
                      }
                    }
                    *(undefined8 *)(puVar43 + -8) = 0x103c7e;
                    iVar21 = func_0x(plVar51);
                    if (iVar21 == 0) {
                      pcVar8 = *(code **)(*plVar51 + 0x270);
                      *(undefined8 *)(puVar43 + -8) = 0x103c8f;
                      (*pcVar8)(plVar51);
                    }
                    if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                      if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                        lVar26 = plVar51[0x1a];
                        *(undefined8 *)(puVar43 + -8) = 0x103cca;
                        cVar18 = func_0x(lVar26);
                        if (((cVar18 != '\0') && (*(char *)(plVar51[0x1a] + 0x130) == '\0')) &&
                           (*(undefined *)(plVar51[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x103d0f;
                          func_0x(0x1f8b450,0x1c,0x10,1);
                        }
                      }
                      uVar40 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                    }
                    else {
                      pcVar8 = *(code **)(*plVar51 + 0x1e8);
                      *(undefined8 *)(puVar43 + -8) = 0x103ca6;
                      uVar25 = (*pcVar8)(plVar51);
                      *(undefined8 *)(puVar43 + -8) = 0x103cae;
                      uVar40 = func_0x(uVar25);
                    }
                    if (uVar40 != 0) goto LAB_;
                  }
                }
                else {
LAB_:
                  if ((*(byte *)(plVar51 + 0x4a) & 0x10) != 0) goto LAB_;
                }
              }
LAB_:
              if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
                if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
                  if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                    if (plVar51[0x1a] == 0) {
                      pcVar8 = *(code **)(*plVar51 + 0x88);
                      *(undefined8 *)(puVar43 + -8) = 0x103d6a;
                      cVar18 = (*pcVar8)(plVar51);
                      if (cVar18 != '\0') {
                        pcVar8 = *(code **)(*plVar51 + 0x18);
                        *(undefined8 *)(puVar43 + -8) = 0x103d78;
                        cVar18 = (*pcVar8)(plVar51);
                        if (cVar18 == '\0') {
                          *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                          goto LAB_;
                        }
                      }
                    }
                    *(undefined8 *)(puVar43 + -8) = 0x103d91;
                    iVar21 = func_0x(plVar51);
                    if (iVar21 == 0) {
                      pcVar8 = *(code **)(*plVar51 + 0x270);
                      *(undefined8 *)(puVar43 + -8) = 0x103da2;
                      (*pcVar8)(plVar51);
                    }
                    if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                      if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                        lVar26 = plVar51[0x1a];
                        *(undefined8 *)(puVar43 + -8) = 0x103ddd;
                        cVar18 = func_0x(lVar26);
                        if (((cVar18 != '\0') && (*(char *)(plVar51[0x1a] + 0x130) == '\0')) &&
                           (*(undefined *)(plVar51[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x103e22;
                          func_0x(0x1f8b450,0x1c,0x10,1);
                        }
                      }
                      uVar40 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                    }
                    else {
                      pcVar8 = *(code **)(*plVar51 + 0x1e8);
                      *(undefined8 *)(puVar43 + -8) = 0x103db9;
                      uVar25 = (*pcVar8)(plVar51);
                      *(undefined8 *)(puVar43 + -8) = 0x103dc1;
                      uVar40 = func_0x(uVar25);
                    }
                    if (uVar40 != 0) goto LAB_;
                  }
                }
                else {
LAB_:
                  if ((*(byte *)(plVar51 + 0x4a) & 0x40) != 0) goto LAB_;
                }
              }
            }
          }
LAB_:
          *(undefined8 *)(puVar43 + -8) = 0x103e47;
          func_0x(lVar37,0);
LAB_:
          *(undefined8 *)(puVar43 + -8) = 0x103e4f;
          iVar21 = func_0x(plVar51);
          if (iVar21 == 0) {
            pcVar8 = *(code **)(*plVar51 + 0x270);
            *(undefined8 *)(puVar43 + -8) = 0x103e60;
            (*pcVar8)(plVar51);
          }
          lVar37 = plVar51[0x1a];
          if (((&stack0x00000330)[lVar23] & 0x24) == 0) {
            if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0) goto LAB_;
              if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                if (lVar37 == 0) {
                  pcVar8 = *(code **)(*plVar51 + 0x88);
                  *(undefined8 *)(puVar43 + -8) = 0x103eac;
                  cVar18 = (*pcVar8)(plVar51);
                  if (cVar18 != '\0') {
                    pcVar8 = *(code **)(*plVar51 + 0x18);
                    *(undefined8 *)(puVar43 + -8) = 0x103eba;
                    cVar18 = (*pcVar8)(plVar51);
                    if (cVar18 == '\0') {
                      *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                      goto LAB_;
                    }
                  }
                }
                *(undefined8 *)(puVar43 + -8) = 0x103ed3;
                iVar21 = func_0x(plVar51);
                if (iVar21 == 0) {
                  pcVar8 = *(code **)(*plVar51 + 0x270);
                  *(undefined8 *)(puVar43 + -8) = 0x103ee4;
                  (*pcVar8)(plVar51);
                }
                if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                  if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                    lVar26 = plVar51[0x1a];
                    *(undefined8 *)(puVar43 + -8) = 0x103f1f;
                    cVar18 = func_0x(lVar26);
                    if (((cVar18 != '\0') && (*(char *)(plVar51[0x1a] + 0x130) == '\0')) &&
                       (*(undefined *)(plVar51[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x103f64;
                      func_0x(0x1f8b450,0x1c,0x10,1);
                    }
                  }
                  uVar40 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                }
                else {
                  pcVar8 = *(code **)(*plVar51 + 0x1e8);
                  *(undefined8 *)(puVar43 + -8) = 0x103efb;
                  uVar25 = (*pcVar8)(plVar51);
                  *(undefined8 *)(puVar43 + -8) = 0x103f03;
                  uVar40 = func_0x(uVar25);
                }
                if (uVar40 != 0) goto LAB_;
              }
            }
            if ((lVar37 == 0) || (*(int *)(lVar37 + 0x74) < 1)) goto LAB_;
          }
        }
        else {
LAB_:
          if (ppsVar50 == (short **)0x0) goto LAB_;
        }
LAB_:
        if (*(short *)ppsVar53 == 0) {
          bVar59 = (*(byte *)ppsVar53[1] & 0xe) == 2;
        }
        else {
          bVar59 = ((*(byte *)ppsVar53[1] & 0x1c) - 0x10 & 0xfffffffb) == 0;
        }
        if (!bVar59) {
          if (*(short *)ppsVar58 == 0) {
            bVar59 = (*(byte *)ppsVar58[1] & 0xe) == 2;
          }
          else {
            bVar59 = ((*(byte *)ppsVar58[1] & 0x1c) - 0x10 & 0xfffffffb) == 0;
          }
          if (bVar59) goto LAB_;
          if (*(short *)ppsVar53 == 0) {
            if (*(int *)((longlong)ppsVar53 + 4) == 0) {
              *(undefined2 *)((longlong)ppsVar53 + 2) = 0;
              uVar40 = *(uint *)(ppsVar53 + 2);
              uVar41 = (ulonglong)uVar40;
              *(uint *)((longlong)ppsVar53 + 0x14) = uVar40;
              psVar57 = ppsVar53[1];
              bVar34 = *(byte *)psVar57;
              if ((bVar34 & 0x10) != 0) {
                uVar40 = uVar40 + (*(ushort *)(uVar41 + (longlong)psVar57) + 7 >> 3) + 2;
                uVar41 = (ulonglong)uVar40;
                *(uint *)((longlong)ppsVar53 + 0x14) = uVar40;
                bVar34 = *(byte *)psVar57;
              }
              if ((bVar34 & 0x20) == 0) {
                *(int *)((longlong)ppsVar53 + 4) = (int)uVar41;
                *(undefined2 *)((longlong)ppsVar53 + 0x1c) = 0;
                *(uint *)(ppsVar53 + 3) = uVar40;
              }
              else {
                puVar55 = (ushort *)(uVar41 + (longlong)psVar57);
                uVar39 = *puVar55;
                *(ushort *)((longlong)ppsVar53 + 0x1c) = uVar39;
                if (uVar39 == 0) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                     ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x1040bb;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x1040e1;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                    }
                  }
                  psVar57 = ppsVar53[1];
                  *(undefined8 *)(puVar43 + -8) = 0x1040ef;
                  func_0x(psVar57,3);
                  uVar39 = *(ushort *)((longlong)ppsVar53 + 0x1c);
                }
                uVar40 = *(int *)((longlong)ppsVar53 + 0x14) + (uVar39 + 1) * 2;
                *(uint *)(ppsVar53 + 3) = uVar40;
                if (0x1f9e < uVar40) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                      ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                       (*(char *)(lVar37 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x10418a;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x1041b0;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                    }
                  }
                  psVar57 = ppsVar53[1];
                  *(undefined8 *)(puVar43 + -8) = 0x1041be;
                  func_0x(psVar57,4);
                }
                uVar39 = puVar55[*(ushort *)((longlong)ppsVar53 + 0x1c)];
                *(uint *)((longlong)ppsVar53 + 4) = uVar39 & 0x7fff;
                if ((uVar39 & 0x7fff) < *(uint *)(ppsVar53 + 3)) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                     ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x104255;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x10427b;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                    }
                  }
                  psVar57 = ppsVar53[1];
                  *(undefined8 *)(puVar43 + -8) = 0x104289;
                  func_0x(psVar57,4);
                }
                do {
                  uVar39 = *(ushort *)((longlong)ppsVar53 + 0x1c);
                  if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                  psVar57 = ppsVar53[1];
                  uVar40 = *(uint *)((longlong)ppsVar53 + 0x14);
                  uVar48 = (uint)uVar39;
                  if (uVar48 == 1) {
                    uVar45 = *(uint *)(ppsVar53 + 3);
                    uVar39 = *(ushort *)
                              ((longlong)psVar57 + (longlong)(int)uVar48 * 2 + (ulonglong)uVar40);
                    uVar48 = uVar45;
LAB_:
                    if ((uVar39 & 0x7fff) < uVar45) goto LAB_;
                  }
                  else {
                    uVar45 = *(ushort *)
                              ((longlong)psVar57 +
                              (longlong)(int)uVar48 * 2 + ((ulonglong)uVar40 - 2)) & 0x7fff;
                    uVar48 = *(uint *)(ppsVar53 + 3);
                    uVar39 = *(ushort *)
                              ((longlong)psVar57 + (ulonglong)uVar39 * 2 + (ulonglong)uVar40);
                    if (uVar48 <= uVar45) goto LAB_;
LAB_:
                    *(undefined8 *)(puVar43 + -8) = 0x1042f7;
                    func_0x(psVar57,7);
                    uVar48 = *(uint *)(ppsVar53 + 3);
                  }
                  if ((uVar45 < uVar48) || (*(uint *)((longlong)ppsVar53 + 4) < uVar45))
                  goto LAB_;
                  if (*(ushort *)((ulonglong)uVar45 + (longlong)ppsVar53[1]) == 5) {
                    *(ushort *)((longlong)ppsVar53 + 2) = *(ushort *)((longlong)ppsVar53 + 2) | 2;
                    *(short *)((longlong)ppsVar53 + 0x1c) =
                         *(short *)((longlong)ppsVar53 + 0x1c) + -1;
                    uVar40 = uVar45 & 0xffff;
                    *(short *)((longlong)ppsVar53 + 0x2a) = (short)uVar45;
                    psVar57 = ppsVar53[1];
                    uVar39 = *(ushort *)((longlong)ppsVar53 + 0x2c) & 0xc7ff;
                    if ((*(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x4000) != 0) {
                      uVar39 = *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x3800 |
                               uVar39;
                    }
                    *(ushort *)((longlong)ppsVar53 + 0x2c) = uVar39;
                    *(ushort *)((longlong)ppsVar53 + 0x2c) =
                         (uVar39 ^ *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2)) & 0x7ff ^
                         uVar39;
                    break;
                  }
                  if (*(ushort *)((ulonglong)uVar45 + (longlong)ppsVar53[1]) < 0x400) break;
                  *(ushort *)((longlong)ppsVar53 + 2) = *(ushort *)((longlong)ppsVar53 + 2) | 1;
                  psVar57 = (short *)((longlong)ppsVar53 + 0x1c);
                  *psVar57 = *psVar57 + -1;
                } while (*psVar57 != 0);
              }
              iVar21 = 0;
              if ((*(byte *)ppsVar53[1] & 0x40) == 0) {
                *(undefined4 *)((longlong)ppsVar53 + 0x26) = 0;
              }
              else {
                *(int *)((longlong)ppsVar53 + 0x26) = *(int *)((longlong)ppsVar53 + 4);
                *(int *)((longlong)ppsVar53 + 4) = *(int *)((longlong)ppsVar53 + 4) + 0xe;
                *(undefined8 *)(puVar43 + -8) = 0x1043f3;
                puVar27 = (ulonglong *)func_0x((longlong)ppsVar53 + 2);
                uVar41 = *puVar27;
                *(ulonglong *)(&stack0x00000158 + lVar23) = uVar41;
                uVar35 = (ushort)(uVar41 >> 0x30);
                uVar39 = uVar35;
                if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                  uVar39 = uVar35 & 0xdfff;
                  if ((uVar41 & 0x4000000000000000) != 0) {
                    uVar39 = uVar35 | 0x2000;
                  }
                }
                if (uVar39 == 0xfffc) {
                  iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                }
                *(int *)((longlong)ppsVar53 + 4) = *(int *)((longlong)ppsVar53 + 4) + iVar21;
              }
              uVar40 = *(uint *)((longlong)ppsVar53 + 4);
              if ((*(ulonglong *)((longlong)ppsVar53 + 0x1e) != 0) &&
                 (*(ulonglong *)((longlong)ppsVar53 + 0x1e) <
                  (ulonglong)uVar40 + (longlong)ppsVar53[1])) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   (((lVar37 = *(longlong *)
                                ((ulonglong)*_DAT_ +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                     (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1044f0;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x104516;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                  }
                }
                psVar57 = ppsVar53[1];
                *(undefined8 *)(puVar43 + -8) = 0x104524;
                func_0x(psVar57,0x12);
                uVar40 = *(uint *)((longlong)ppsVar53 + 4);
              }
              if (0x3f3b < uVar40 - 1) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                    ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                     (*(char *)(lVar37 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1045b0;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    psVar57 = ppsVar53[1];
                    *(undefined8 *)(puVar43 + -8) = 0x1045be;
                    func_0x(psVar57,5);
                    goto LAB_;
                  }
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x1045e4;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                }
                psVar57 = ppsVar53[1];
                *(undefined8 *)(puVar43 + -8) = 0x1045f2;
                func_0x(psVar57,5);
              }
            }
LAB_:
            uVar40 = *(uint *)((longlong)ppsVar53 + 4);
            *(uint *)(&stack0x00000044 + lVar23) = uVar40;
            if ((uVar40 < 9) &&
               (((*(byte *)ppsVar53[1] & 0xe) == 0 || ((*(byte *)ppsVar53[1] & 0xe) == 0xc)))) {
              *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
            }
            ppsVar50 = *(short ***)(&stack0x00000070 + lVar23);
          }
          else {
            uVar40 = *(uint *)((longlong)ppsVar53 + 4);
            *(uint *)(&stack0x00000044 + lVar23) = uVar40;
            if (uVar40 == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x104634;
              func_0x((longlong)ppsVar53 + 2);
              uVar40 = *(uint *)((longlong)ppsVar53 + 4);
              *(uint *)(&stack0x00000044 + lVar23) = uVar40;
            }
            if ((uVar40 < 9) &&
               (((*(byte *)ppsVar53[1] & 0x1c) == 0 || ((*(byte *)ppsVar53[1] & 0x1c) == 0xc)))) {
              *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
            }
          }
          if (ppsVar50 != (short **)0x0) {
            *(undefined8 *)(puVar43 + -8) = 0x104670;
            uVar25 = func_0x(ppsVar58,&stack0x00000160 + lVar23);
            *(undefined8 *)(puVar43 + -8) = 0x104678;
            cVar18 = func_0x(uVar25);
            if (cVar18 == '\0') goto LAB_;
            if (*(short *)ppsVar58 != 0) {
              uVar40 = *(uint *)((longlong)ppsVar58 + 4);
              goto LAB_;
            }
            if (*(int *)((longlong)ppsVar58 + 4) == 0) {
              *(undefined2 *)((longlong)ppsVar58 + 2) = 0;
              uVar40 = *(uint *)(ppsVar58 + 2);
              uVar41 = (ulonglong)uVar40;
              *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
              psVar57 = ppsVar58[1];
              bVar34 = *(byte *)psVar57;
              if ((bVar34 & 0x10) != 0) {
                uVar40 = uVar40 + 2 + (*(ushort *)(uVar41 + (longlong)psVar57) + 7 >> 3);
                uVar41 = (ulonglong)uVar40;
                *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
                bVar34 = *(byte *)psVar57;
              }
              if ((bVar34 & 0x20) == 0) {
                *(int *)((longlong)ppsVar58 + 4) = (int)uVar41;
                *(undefined2 *)((longlong)ppsVar58 + 0x1c) = 0;
                *(uint *)(ppsVar58 + 3) = uVar40;
              }
              else {
                puVar55 = (ushort *)(uVar41 + (longlong)psVar57);
                uVar39 = *puVar55;
                *(ushort *)((longlong)ppsVar58 + 0x1c) = uVar39;
                if (uVar39 == 0) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                     ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x104763;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x104789;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                    }
                  }
                  psVar57 = ppsVar58[1];
                  *(undefined8 *)(puVar43 + -8) = 0x104797;
                  func_0x(psVar57,3);
                  uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
                }
                uVar40 = *(int *)((longlong)ppsVar58 + 0x14) + 2 + (uint)uVar39 * 2;
                *(uint *)(ppsVar58 + 3) = uVar40;
                if (0x1f9e < uVar40) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                      ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                       (*(char *)(lVar37 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x104833;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x104859;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                    }
                  }
                  psVar57 = ppsVar58[1];
                  *(undefined8 *)(puVar43 + -8) = 0x104867;
                  func_0x(psVar57,4);
                }
                uVar39 = puVar55[*(ushort *)((longlong)ppsVar58 + 0x1c)];
                *(uint *)((longlong)ppsVar58 + 4) = uVar39 & 0x7fff;
                if ((uVar39 & 0x7fff) < *(uint *)(ppsVar58 + 3)) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                     ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x1048fe;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x104924;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                    }
                  }
                  psVar57 = ppsVar58[1];
                  *(undefined8 *)(puVar43 + -8) = 0x104932;
                  func_0x(psVar57,4);
                }
                do {
                  uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
                  if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                  psVar57 = ppsVar58[1];
                  uVar40 = *(uint *)((longlong)ppsVar58 + 0x14);
                  uVar48 = (uint)uVar39;
                  if (uVar48 == 1) {
                    uVar45 = *(uint *)(ppsVar58 + 3);
                    uVar39 = *(ushort *)
                              ((longlong)psVar57 + (longlong)(int)uVar48 * 2 + (ulonglong)uVar40);
                    uVar48 = uVar45;
LAB_:
                    if ((uVar39 & 0x7fff) < uVar45) goto LAB_;
                  }
                  else {
                    uVar45 = *(ushort *)
                              ((longlong)psVar57 +
                              (longlong)(int)uVar48 * 2 + ((ulonglong)uVar40 - 2)) & 0x7fff;
                    uVar48 = *(uint *)(ppsVar58 + 3);
                    uVar39 = *(ushort *)
                              ((longlong)psVar57 + (ulonglong)uVar39 * 2 + (ulonglong)uVar40);
                    if (uVar48 <= uVar45) goto LAB_;
LAB_:
                    *(undefined8 *)(puVar43 + -8) = 0x1049a7;
                    func_0x(psVar57,7);
                    uVar48 = *(uint *)(ppsVar58 + 3);
                  }
                  if ((uVar45 < uVar48) || (*(uint *)((longlong)ppsVar58 + 4) < uVar45))
                  goto LAB_;
                  psVar57 = ppsVar58[1];
                  if (*(ushort *)((ulonglong)uVar45 + (longlong)psVar57) == 5) {
                    *(ushort *)((longlong)ppsVar58 + 2) = *(ushort *)((longlong)ppsVar58 + 2) | 2;
                    *(short *)((longlong)ppsVar58 + 0x1c) =
                         *(short *)((longlong)ppsVar58 + 0x1c) + -1;
                    uVar40 = uVar45 & 0xffff;
                    *(short *)((longlong)ppsVar58 + 0x2a) = (short)uVar45;
                    uVar39 = *(ushort *)((longlong)ppsVar58 + 0x2c) & 0xc7ff;
                    if ((*(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x4000) != 0) {
                      uVar39 = *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x3800 |
                               uVar39;
                    }
                    *(ushort *)((longlong)ppsVar58 + 0x2c) = uVar39;
                    *(ushort *)((longlong)ppsVar58 + 0x2c) =
                         (uVar39 ^ *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2)) & 0x7ff ^
                         uVar39;
                    break;
                  }
                  if (*(ushort *)((ulonglong)uVar45 + (longlong)psVar57) < 0x400) break;
                  *(ushort *)((longlong)ppsVar58 + 2) = *(ushort *)((longlong)ppsVar58 + 2) | 1;
                  psVar57 = (short *)((longlong)ppsVar58 + 0x1c);
                  *psVar57 = *psVar57 + -1;
                } while (*psVar57 != 0);
              }
              iVar21 = 0;
              if ((*(byte *)ppsVar58[1] & 0x40) == 0) {
                *(undefined4 *)((longlong)ppsVar58 + 0x26) = 0;
              }
              else {
                *(int *)((longlong)ppsVar58 + 0x26) = *(int *)((longlong)ppsVar58 + 4);
                *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + 0xe;
                *(undefined8 *)(puVar43 + -8) = 0x104a95;
                puVar27 = (ulonglong *)func_0x((longlong)ppsVar58 + 2);
                uVar41 = *puVar27;
                *(ulonglong *)(&stack0x00000168 + lVar23) = uVar41;
                uVar35 = (ushort)(uVar41 >> 0x30);
                uVar39 = uVar35;
                if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                  uVar39 = uVar35 & 0xdfff;
                  if ((uVar41 & 0x4000000000000000) != 0) {
                    uVar39 = uVar35 | 0x2000;
                  }
                }
                if (uVar39 == 0xfffc) {
                  iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                }
                *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + iVar21;
              }
              uVar40 = *(uint *)((longlong)ppsVar58 + 4);
              if ((*(ulonglong *)((longlong)ppsVar58 + 0x1e) != 0) &&
                 (*(ulonglong *)((longlong)ppsVar58 + 0x1e) <
                  (ulonglong)uVar40 + (longlong)ppsVar58[1])) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   (((lVar37 = *(longlong *)
                                ((ulonglong)*_DAT_ +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                     (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x104b92;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x104bb8;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                  }
                }
                psVar57 = ppsVar58[1];
                *(undefined8 *)(puVar43 + -8) = 0x104bc6;
                func_0x(psVar57,0x12);
                uVar40 = *(uint *)((longlong)ppsVar58 + 4);
              }
              if (0x3f3b < uVar40 - 1) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                    ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                     (*(char *)(lVar37 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x104c52;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x104c78;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                  }
                }
                psVar57 = ppsVar58[1];
                *(undefined8 *)(puVar43 + -8) = 0x104c86;
                func_0x(psVar57,5);
              }
            }
LAB_:
            uVar40 = *(uint *)((longlong)ppsVar58 + 4);
            *(uint *)(&stack0x00000044 + lVar23) = uVar40;
            if (8 < uVar40) goto LAB_;
            if ((*(byte *)ppsVar58[1] & 0xe) != 0) {
              if ((*(byte *)ppsVar58[1] & 0xe) == 0xc) {
                *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
                uVar36 = *(undefined4 *)((longlong)auStackX_20 + lVar23);
                uVar25 = *(undefined8 *)(&stack0x00000068 + lVar23);
                goto LAB_;
              }
              goto LAB_;
            }
LAB_:
            *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
            goto LAB_;
          }
LAB_:
          pcVar8 = *(code **)(*plVar51 + 0x20);
          *(undefined8 *)(puVar43 + -8) = 0x104cd7;
          cVar18 = (*pcVar8)(plVar51);
          if ((cVar18 == '\0') ||
             (((*(short *)ppsVar58 != 0 && ((longlong *)ppsVar58[2] != (longlong *)0x0)) &&
              (*(longlong *)ppsVar58[2] != 0)))) {
LAB_:
            *(undefined4 *)(&stack0x00000044 + lVar23) = 0xf;
            bVar38 = 1;
            uVar36 = *(undefined4 *)((longlong)auStackX_20 + lVar23);
            uVar25 = *(undefined8 *)(&stack0x00000068 + lVar23);
            goto LAB_;
          }
          if (2000 < *(uint *)(&stack0x00000044 + lVar23)) {
            *(undefined8 *)(puVar43 + -8) = 0x104d07;
            cVar18 = func_0x();
            if (cVar18 == '\0') goto LAB_;
          }
          *(undefined8 *)(puVar43 + -8) = 0x104d1e;
          puVar28 = (undefined4 *)func_0x(ppsVar53,&stack0x000000aa + lVar23);
          uVar36 = *puVar28;
          uVar20 = *(undefined2 *)(puVar28 + 1);
          uVar25 = *(undefined8 *)(plVar51[6] + 0x6b0);
          *(undefined8 *)(puVar43 + -8) = 0x104d3e;
          uVar29 = func_0x(ppsVar53,&stack0x00000170 + lVar23);
          *(undefined4 *)(&stack0x00000048 + lVar23) = 0;
          *(undefined4 *)(&stack0x000000b8 + lVar23) = uVar36;
          *(undefined2 *)(&stack0x000000bc + lVar23) = uVar20;
          puVar43[0x40] = 0;
          puVar43[0x38] = 0;
          puVar43[0x30] = 0;
          puVar43[0x28] = 0;
          puVar43[0x20] = 0;
          *(undefined8 *)(puVar43 + -8) = 0x104d7a;
          cVar18 = func_0x
                             (uVar25,&stack0x000000b8 + lVar23,uVar29,&stack0x00000048 + lVar23);
          if (cVar18 != '\0') goto LAB_;
          *(undefined8 *)(puVar43 + -8) = 0x104d8a;
          iVar21 = func_0x(ppsVar53);
          if (iVar21 == 0) {
            iVar21 = *(int *)(&stack0x00000044 + lVar23);
            *(int *)(&stack0x00000044 + lVar23) = iVar21 + 0xe;
            puVar55 = (ushort *)((longlong)ppsVar58 + 2);
            if (*(short *)ppsVar58 == 0) {
              if (*(int *)((longlong)ppsVar58 + 4) == 0) {
                *puVar55 = 0;
                uVar40 = *(uint *)(ppsVar58 + 2);
                uVar41 = (ulonglong)uVar40;
                *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
                psVar57 = ppsVar58[1];
                bVar34 = *(byte *)psVar57;
                if ((bVar34 & 0x10) != 0) {
                  uVar40 = uVar40 + 2 + (*(ushort *)(uVar41 + (longlong)psVar57) + 7 >> 3);
                  uVar41 = (ulonglong)uVar40;
                  *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
                  bVar34 = *(byte *)psVar57;
                }
                if ((bVar34 & 0x20) == 0) {
                  *(int *)((longlong)ppsVar58 + 4) = (int)uVar41;
                  *(undefined2 *)((longlong)ppsVar58 + 0x1c) = 0;
                  *(uint *)(ppsVar58 + 3) = uVar40;
                }
                else {
                  puVar44 = (ushort *)(uVar41 + (longlong)psVar57);
                  uVar39 = *puVar44;
                  *(ushort *)((longlong)ppsVar58 + 0x1c) = uVar39;
                  if (uVar39 == 0) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                        ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                         (*(char *)(lVar37 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x104e80;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x104ea6;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                      }
                    }
                    psVar57 = ppsVar58[1];
                    *(undefined8 *)(puVar43 + -8) = 0x104eb4;
                    func_0x(psVar57,3);
                    uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
                  }
                  uVar40 = *(int *)((longlong)ppsVar58 + 0x14) + 2 + (uint)uVar39 * 2;
                  *(uint *)(ppsVar58 + 3) = uVar40;
                  if (0x1f9e < uVar40) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                       ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                        (*(char *)(lVar37 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x104f4d;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x104f73;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                      }
                    }
                    psVar57 = ppsVar58[1];
                    *(undefined8 *)(puVar43 + -8) = 0x104f81;
                    func_0x(psVar57,4);
                  }
                  uVar39 = puVar44[*(ushort *)((longlong)ppsVar58 + 0x1c)];
                  *(uint *)((longlong)ppsVar58 + 4) = uVar39 & 0x7fff;
                  if ((uVar39 & 0x7fff) < *(uint *)(ppsVar58 + 3)) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                        ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                         (*(char *)(lVar37 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x105015;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10503b;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                      }
                    }
                    psVar57 = ppsVar58[1];
                    *(undefined8 *)(puVar43 + -8) = 0x105049;
                    func_0x(psVar57,4);
                  }
                  do {
                    uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
                    if (-1 < (short)puVar44[(ulonglong)(uVar39 - 1) + 1]) break;
                    psVar57 = ppsVar58[1];
                    uVar40 = *(uint *)((longlong)ppsVar58 + 0x14);
                    uVar48 = (uint)uVar39;
                    if (uVar48 == 1) {
                      uVar45 = *(uint *)(ppsVar58 + 3);
                      uVar39 = *(ushort *)
                                ((longlong)psVar57 + (longlong)(int)uVar48 * 2 + (ulonglong)uVar40);
                      uVar48 = uVar45;
LAB_:
                      if ((uVar39 & 0x7fff) < uVar45) goto LAB_;
                    }
                    else {
                      uVar45 = *(ushort *)
                                ((longlong)psVar57 +
                                (longlong)(int)uVar48 * 2 + ((ulonglong)uVar40 - 2)) & 0x7fff;
                      uVar48 = *(uint *)(ppsVar58 + 3);
                      uVar39 = *(ushort *)
                                ((longlong)psVar57 + (ulonglong)uVar39 * 2 + (ulonglong)uVar40);
                      if (uVar48 <= uVar45) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar43 + -8) = 0x1050b4;
                      func_0x(psVar57,7);
                      uVar48 = *(uint *)(ppsVar58 + 3);
                    }
                    if ((uVar45 < uVar48) || (*(uint *)((longlong)ppsVar58 + 4) < uVar45))
                    goto LAB_;
                    psVar57 = ppsVar58[1];
                    if (*(ushort *)((ulonglong)uVar45 + (longlong)psVar57) == 5) {
                      *puVar55 = *puVar55 | 2;
                      *(short *)((longlong)ppsVar58 + 0x1c) =
                           *(short *)((longlong)ppsVar58 + 0x1c) + -1;
                      uVar40 = uVar45 & 0xffff;
                      *(short *)((longlong)ppsVar58 + 0x2a) = (short)uVar45;
                      uVar39 = *(ushort *)((longlong)ppsVar58 + 0x2c) & 0xc7ff;
                      if ((*(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x4000) != 0) {
                        uVar39 = *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x3800 |
                                 uVar39;
                      }
                      *(ushort *)((longlong)ppsVar58 + 0x2c) = uVar39;
                      *(ushort *)((longlong)ppsVar58 + 0x2c) =
                           (uVar39 ^ *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2)) & 0x7ff
                           ^ uVar39;
                      break;
                    }
                    if (*(ushort *)((ulonglong)uVar45 + (longlong)psVar57) < 0x400) break;
                    *puVar55 = *puVar55 | 1;
                    psVar57 = (short *)((longlong)ppsVar58 + 0x1c);
                    *psVar57 = *psVar57 + -1;
                  } while (*psVar57 != 0);
                }
                iVar22 = 0;
                if ((*(byte *)ppsVar58[1] & 0x40) == 0) {
                  *(undefined4 *)((longlong)ppsVar58 + 0x26) = 0;
                }
                else {
                  *(int *)((longlong)ppsVar58 + 0x26) = *(int *)((longlong)ppsVar58 + 4);
                  *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + 0xe;
                  *(undefined8 *)(puVar43 + -8) = 0x105196;
                  puVar27 = (ulonglong *)func_0x(puVar55);
                  uVar41 = *puVar27;
                  *(ulonglong *)(&stack0x00000178 + lVar23) = uVar41;
                  uVar35 = (ushort)(uVar41 >> 0x30);
                  uVar39 = uVar35;
                  if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                    uVar39 = uVar35 & 0xdfff;
                    if ((uVar41 & 0x4000000000000000) != 0) {
                      uVar39 = uVar35 | 0x2000;
                    }
                  }
                  if (uVar39 == 0xfffc) {
                    iVar22 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                  }
                  *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + iVar22;
                }
                uVar40 = *(uint *)((longlong)ppsVar58 + 4);
                if ((*(ulonglong *)((longlong)ppsVar58 + 0x1e) != 0) &&
                   (*(ulonglong *)((longlong)ppsVar58 + 0x1e) <
                    (ulonglong)uVar40 + (longlong)ppsVar58[1])) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     (((lVar37 = *(longlong *)
                                  ((ulonglong)*_DAT_ +
                                   *(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                       (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x105292;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x1052b8;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                    }
                  }
                  psVar57 = ppsVar58[1];
                  *(undefined8 *)(puVar43 + -8) = 0x1052c6;
                  func_0x(psVar57,0x12);
                  uVar40 = *(uint *)((longlong)ppsVar58 + 4);
                }
                if (0x3f3b < uVar40 - 1) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                      ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                       (*(char *)(lVar37 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x105351;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x105377;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                    }
                  }
                  psVar57 = ppsVar58[1];
                  *(undefined8 *)(puVar43 + -8) = 0x105385;
                  func_0x(psVar57,5);
                }
              }
LAB_:
              uVar40 = *(uint *)((longlong)ppsVar58 + 4);
              if (uVar40 < 9) {
                bVar34 = *(byte *)ppsVar58[1] & 0xe;
joined_r0x001053c5:
                if ((bVar34 == 0) || (bVar34 == 0xc)) {
                  uVar40 = 9;
                }
              }
            }
            else {
              uVar40 = *(uint *)((longlong)ppsVar58 + 4);
              if (uVar40 == 0) {
                *(undefined8 *)(puVar43 + -8) = 0x1053b1;
                func_0x(puVar55);
                uVar40 = *(uint *)((longlong)ppsVar58 + 4);
              }
              if (uVar40 < 9) {
                bVar34 = *(byte *)ppsVar58[1] & 0x1c;
                goto joined_r0x001053c5;
              }
            }
            *(int *)(puVar43 + 0x20) = iVar21 + 0xe;
            uVar36 = *(undefined4 *)((longlong)auStackX_20 + lVar23);
            uVar25 = *(undefined8 *)(&stack0x00000068 + lVar23);
            *(undefined8 *)(puVar43 + -8) = 0x1053ec;
            cVar18 = func_0x(plVar51,uVar25,uVar36,uVar40);
            if (cVar18 == '\0') {
              *(undefined4 *)(&stack0x00000044 + lVar23) = 0xf;
              bVar38 = 1;
            }
            goto LAB_;
          }
          goto LAB_;
        }
LAB_:
        sVar6 = *(short *)ppsVar58;
        uVar48 = 0x20;
        if (sVar6 != 0) {
          uVar48 = 0x18;
        }
        *(uint *)(&stack0x00000044 + lVar23) = uVar48;
        if (sVar6 != 0) {
          uVar40 = *(uint *)((longlong)ppsVar58 + 4);
          if (uVar40 == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x105a71;
            func_0x((longlong)ppsVar58 + 2);
            uVar40 = *(uint *)((longlong)ppsVar58 + 4);
          }
          uVar45 = uVar40;
          if (uVar40 < 9) {
            bVar34 = *(byte *)ppsVar58[1] & 0x1c;
            goto joined_r0x00105a84;
          }
        }
        else {
          if (*(int *)((longlong)ppsVar58 + 4) == 0) {
            *(undefined2 *)((longlong)ppsVar58 + 2) = 0;
            uVar40 = *(uint *)(ppsVar58 + 2);
            uVar41 = (ulonglong)uVar40;
            *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
            psVar57 = ppsVar58[1];
            bVar34 = *(byte *)psVar57;
            if ((bVar34 & 0x10) != 0) {
              uVar40 = uVar40 + 2 + (*(ushort *)(uVar41 + (longlong)psVar57) + 7 >> 3);
              uVar41 = (ulonglong)uVar40;
              *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
              bVar34 = *(byte *)psVar57;
            }
            if ((bVar34 & 0x20) == 0) {
              *(int *)((longlong)ppsVar58 + 4) = (int)uVar41;
              *(undefined2 *)((longlong)ppsVar58 + 0x1c) = 0;
              *(uint *)(ppsVar58 + 3) = uVar40;
            }
            else {
              puVar55 = (ushort *)(uVar41 + (longlong)psVar57);
              uVar39 = *puVar55;
              *(ushort *)((longlong)ppsVar58 + 0x1c) = uVar39;
              if (uVar39 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x105510;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x105536;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                  }
                }
                psVar57 = ppsVar58[1];
                *(undefined8 *)(puVar43 + -8) = 0x105544;
                func_0x(psVar57,3);
                uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
              }
              uVar40 = *(int *)((longlong)ppsVar58 + 0x14) + 2 + (uint)uVar39 * 2;
              *(uint *)(ppsVar58 + 3) = uVar40;
              if (0x1f9e < uVar40) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                    ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                     (*(char *)(lVar37 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1055e0;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x105606;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                  }
                }
                psVar57 = ppsVar58[1];
                *(undefined8 *)(puVar43 + -8) = 0x105614;
                func_0x(psVar57,4);
              }
              uVar39 = puVar55[*(ushort *)((longlong)ppsVar58 + 0x1c)];
              *(uint *)((longlong)ppsVar58 + 4) = uVar39 & 0x7fff;
              if ((uVar39 & 0x7fff) < *(uint *)(ppsVar58 + 3)) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1056ab;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1056d1;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                  }
                }
                psVar57 = ppsVar58[1];
                *(undefined8 *)(puVar43 + -8) = 0x1056df;
                func_0x(psVar57,4);
              }
              do {
                uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
                if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                psVar57 = ppsVar58[1];
                uVar40 = *(uint *)((longlong)ppsVar58 + 0x14);
                uVar45 = (uint)uVar39;
                if (uVar45 == 1) {
                  uVar46 = *(uint *)(ppsVar58 + 3);
                  uVar39 = *(ushort *)
                            ((longlong)psVar57 + (longlong)(int)uVar45 * 2 + (ulonglong)uVar40);
                  uVar45 = uVar46;
LAB_:
                  if ((uVar39 & 0x7fff) < uVar46) goto LAB_;
                }
                else {
                  uVar46 = *(ushort *)
                            ((longlong)psVar57 + (longlong)(int)uVar45 * 2 + ((ulonglong)uVar40 - 2)
                            ) & 0x7fff;
                  uVar45 = *(uint *)(ppsVar58 + 3);
                  uVar39 = *(ushort *)
                            ((longlong)psVar57 + (ulonglong)uVar39 * 2 + (ulonglong)uVar40);
                  if (uVar45 <= uVar46) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar43 + -8) = 0x105747;
                  func_0x(psVar57,7);
                  uVar45 = *(uint *)(ppsVar58 + 3);
                }
                if ((uVar46 < uVar45) || (*(uint *)((longlong)ppsVar58 + 4) < uVar46))
                goto LAB_;
                if (*(ushort *)((ulonglong)uVar46 + (longlong)ppsVar58[1]) == 5) {
                  *(ushort *)((longlong)ppsVar58 + 2) = *(ushort *)((longlong)ppsVar58 + 2) | 2;
                  *(short *)((longlong)ppsVar58 + 0x1c) = *(short *)((longlong)ppsVar58 + 0x1c) + -1
                  ;
                  uVar40 = uVar46 & 0xffff;
                  *(short *)((longlong)ppsVar58 + 0x2a) = (short)uVar46;
                  psVar57 = ppsVar58[1];
                  uVar39 = *(ushort *)((longlong)ppsVar58 + 0x2c) & 0xc7ff;
                  if ((*(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x4000) != 0) {
                    uVar39 = *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x3800 |
                             uVar39;
                  }
                  *(ushort *)((longlong)ppsVar58 + 0x2c) = uVar39;
                  *(ushort *)((longlong)ppsVar58 + 0x2c) =
                       (uVar39 ^ *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2)) & 0x7ff ^
                       uVar39;
                  break;
                }
                if (*(ushort *)((ulonglong)uVar46 + (longlong)ppsVar58[1]) < 0x400) break;
                *(ushort *)((longlong)ppsVar58 + 2) = *(ushort *)((longlong)ppsVar58 + 2) | 1;
                psVar57 = (short *)((longlong)ppsVar58 + 0x1c);
                *psVar57 = *psVar57 + -1;
              } while (*psVar57 != 0);
            }
            iVar21 = 0;
            if ((*(byte *)ppsVar58[1] & 0x40) == 0) {
              *(undefined4 *)((longlong)ppsVar58 + 0x26) = 0;
            }
            else {
              *(int *)((longlong)ppsVar58 + 0x26) = *(int *)((longlong)ppsVar58 + 4);
              *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + 0xe;
              *(undefined8 *)(puVar43 + -8) = 0x105843;
              puVar27 = (ulonglong *)func_0x((longlong)ppsVar58 + 2);
              uVar41 = *puVar27;
              *(ulonglong *)(&stack0x00000180 + lVar23) = uVar41;
              uVar35 = (ushort)(uVar41 >> 0x30);
              uVar39 = uVar35;
              if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                uVar39 = uVar35 & 0xdfff;
                if ((uVar41 & 0x4000000000000000) != 0) {
                  uVar39 = uVar35 | 0x2000;
                }
              }
              if (uVar39 == 0xfffc) {
                iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + iVar21;
            }
            uVar40 = *(uint *)((longlong)ppsVar58 + 4);
            if ((*(ulonglong *)((longlong)ppsVar58 + 0x1e) != 0) &&
               (*(ulonglong *)((longlong)ppsVar58 + 0x1e) <
                (ulonglong)uVar40 + (longlong)ppsVar58[1])) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar37 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                   (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x105940;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x105966;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                }
              }
              psVar57 = ppsVar58[1];
              *(undefined8 *)(puVar43 + -8) = 0x105974;
              func_0x(psVar57,0x12);
              uVar40 = *(uint *)((longlong)ppsVar58 + 4);
            }
            if (0x3f3b < uVar40 - 1) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x105a00;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  psVar57 = ppsVar58[1];
                  *(undefined8 *)(puVar43 + -8) = 0x105a0e;
                  func_0x(psVar57,5);
                  goto LAB_;
                }
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x105a34;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
              }
              psVar57 = ppsVar58[1];
              *(undefined8 *)(puVar43 + -8) = 0x105a42;
              func_0x(psVar57,5);
            }
          }
LAB_:
          uVar40 = *(uint *)((longlong)ppsVar58 + 4);
          uVar45 = uVar40;
          if (uVar40 < 9) {
            bVar34 = *(byte *)ppsVar58[1] & 0xe;
joined_r0x00105a84:
            if ((bVar34 == 0) || (uVar45 = uVar40, bVar34 == 0xc)) {
              uVar45 = 9;
            }
          }
        }
        if (uVar48 <= uVar45) {
          if (*(short *)ppsVar58 == 0) {
            if (uVar40 == 0) {
              *(undefined2 *)((longlong)ppsVar58 + 2) = 0;
              uVar40 = *(uint *)(ppsVar58 + 2);
              uVar41 = (ulonglong)uVar40;
              *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
              psVar57 = ppsVar58[1];
              bVar34 = *(byte *)psVar57;
              if ((bVar34 & 0x10) != 0) {
                uVar40 = uVar40 + 2 + (*(ushort *)(uVar41 + (longlong)psVar57) + 7 >> 3);
                uVar41 = (ulonglong)uVar40;
                *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
                bVar34 = *(byte *)psVar57;
              }
              if ((bVar34 & 0x20) == 0) {
                *(int *)((longlong)ppsVar58 + 4) = (int)uVar41;
                *(undefined2 *)((longlong)ppsVar58 + 0x1c) = 0;
                *(uint *)(ppsVar58 + 3) = uVar40;
              }
              else {
                puVar55 = (ushort *)(uVar41 + (longlong)psVar57);
                uVar39 = *puVar55;
                *(ushort *)((longlong)ppsVar58 + 0x1c) = uVar39;
                if (uVar39 == 0) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                     ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x105b7d;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x105ba3;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                    }
                  }
                  psVar57 = ppsVar58[1];
                  *(undefined8 *)(puVar43 + -8) = 0x105bb1;
                  func_0x(psVar57,3);
                  uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
                }
                uVar40 = *(int *)((longlong)ppsVar58 + 0x14) + 2 + (uint)uVar39 * 2;
                *(uint *)(ppsVar58 + 3) = uVar40;
                if (0x1f9e < uVar40) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                      ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                       (*(char *)(lVar37 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x105c4d;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x105c73;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                    }
                  }
                  psVar57 = ppsVar58[1];
                  *(undefined8 *)(puVar43 + -8) = 0x105c81;
                  func_0x(psVar57,4);
                }
                uVar39 = puVar55[*(ushort *)((longlong)ppsVar58 + 0x1c)];
                *(uint *)((longlong)ppsVar58 + 4) = uVar39 & 0x7fff;
                if ((uVar39 & 0x7fff) < *(uint *)(ppsVar58 + 3)) {
                  if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                      (lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                     ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x105d18;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x105d3e;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                    }
                  }
                  psVar57 = ppsVar58[1];
                  *(undefined8 *)(puVar43 + -8) = 0x105d4c;
                  func_0x(psVar57,4);
                }
                do {
                  uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
                  if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                  psVar57 = ppsVar58[1];
                  uVar40 = *(uint *)((longlong)ppsVar58 + 0x14);
                  uVar48 = (uint)uVar39;
                  if (uVar48 == 1) {
                    uVar45 = *(uint *)(ppsVar58 + 3);
                    uVar39 = *(ushort *)
                              ((longlong)psVar57 + (longlong)(int)uVar48 * 2 + (ulonglong)uVar40);
                    uVar48 = uVar45;
LAB_:
                    if ((uVar39 & 0x7fff) < uVar45) goto LAB_;
                  }
                  else {
                    uVar45 = *(ushort *)
                              ((longlong)psVar57 +
                              (longlong)(int)uVar48 * 2 + ((ulonglong)uVar40 - 2)) & 0x7fff;
                    uVar48 = *(uint *)(ppsVar58 + 3);
                    uVar39 = *(ushort *)
                              ((longlong)psVar57 + (ulonglong)uVar39 * 2 + (ulonglong)uVar40);
                    if (uVar48 <= uVar45) goto LAB_;
LAB_:
                    *(undefined8 *)(puVar43 + -8) = 0x105db9;
                    func_0x(psVar57,7);
                    uVar48 = *(uint *)(ppsVar58 + 3);
                  }
                  if ((uVar45 < uVar48) || (*(uint *)((longlong)ppsVar58 + 4) < uVar45))
                  goto LAB_;
                  if (*(ushort *)((ulonglong)uVar45 + (longlong)ppsVar58[1]) == 5) {
                    *(ushort *)((longlong)ppsVar58 + 2) = *(ushort *)((longlong)ppsVar58 + 2) | 2;
                    *(short *)((longlong)ppsVar58 + 0x1c) =
                         *(short *)((longlong)ppsVar58 + 0x1c) + -1;
                    uVar40 = uVar45 & 0xffff;
                    *(short *)((longlong)ppsVar58 + 0x2a) = (short)uVar45;
                    psVar57 = ppsVar58[1];
                    uVar39 = *(ushort *)((longlong)ppsVar58 + 0x2c) & 0xc7ff;
                    if ((*(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x4000) != 0) {
                      uVar39 = *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x3800 |
                               uVar39;
                    }
                    *(ushort *)((longlong)ppsVar58 + 0x2c) = uVar39;
                    *(ushort *)((longlong)ppsVar58 + 0x2c) =
                         (uVar39 ^ *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2)) & 0x7ff ^
                         uVar39;
                    break;
                  }
                  if (*(ushort *)((ulonglong)uVar45 + (longlong)ppsVar58[1]) < 0x400) break;
                  *(ushort *)((longlong)ppsVar58 + 2) = *(ushort *)((longlong)ppsVar58 + 2) | 1;
                  psVar57 = (short *)((longlong)ppsVar58 + 0x1c);
                  *psVar57 = *psVar57 + -1;
                } while (*psVar57 != 0);
              }
              iVar21 = 0;
              if ((*(byte *)ppsVar58[1] & 0x40) == 0) {
                *(undefined4 *)((longlong)ppsVar58 + 0x26) = 0;
              }
              else {
                *(undefined4 *)((longlong)ppsVar58 + 0x26) = *(undefined4 *)((longlong)ppsVar58 + 4)
                ;
                *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + 0xe;
                *(undefined8 *)(puVar43 + -8) = 0x105ea6;
                puVar27 = (ulonglong *)func_0x((longlong)ppsVar58 + 2);
                uVar41 = *puVar27;
                *(ulonglong *)(&stack0x00000188 + lVar23) = uVar41;
                uVar35 = (ushort)(uVar41 >> 0x30);
                uVar39 = uVar35;
                if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                  uVar39 = uVar35 & 0xdfff;
                  if ((uVar41 & 0x4000000000000000) != 0) {
                    uVar39 = uVar35 | 0x2000;
                  }
                }
                if (uVar39 == 0xfffc) {
                  iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                }
                *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + iVar21;
              }
              uVar40 = *(uint *)((longlong)ppsVar58 + 4);
              if ((*(ulonglong *)((longlong)ppsVar58 + 0x1e) != 0) &&
                 (*(ulonglong *)((longlong)ppsVar58 + 0x1e) <
                  (ulonglong)uVar40 + (longlong)ppsVar58[1])) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   (((lVar37 = *(longlong *)
                                ((ulonglong)*_DAT_ +
                                 *(longlong *)
                                  (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                  (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                     (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x105fa3;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x105fc9;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                  }
                }
                psVar57 = ppsVar58[1];
                *(undefined8 *)(puVar43 + -8) = 0x105fd7;
                func_0x(psVar57,0x12);
                uVar40 = *(uint *)((longlong)ppsVar58 + 4);
              }
              if (0x3f3b < uVar40 - 1) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                    ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                     (*(char *)(lVar37 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x106063;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x106089;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                  }
                }
                psVar57 = ppsVar58[1];
                *(undefined8 *)(puVar43 + -8) = 0x106097;
                func_0x(psVar57,5);
              }
            }
LAB_:
            uVar40 = *(uint *)((longlong)ppsVar58 + 4);
            *(uint *)(&stack0x00000044 + lVar23) = uVar40;
            if (uVar40 < 9) {
              bVar34 = *(byte *)ppsVar58[1] & 0xe;
joined_r0x001060dc:
              if ((bVar34 == 0) || (bVar34 == 0xc)) goto LAB_;
            }
          }
          else {
LAB_:
            *(uint *)(&stack0x00000044 + lVar23) = uVar40;
            if (uVar40 == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x1060c6;
              func_0x((longlong)ppsVar58 + 2);
              uVar40 = *(uint *)((longlong)ppsVar58 + 4);
              *(uint *)(&stack0x00000044 + lVar23) = uVar40;
            }
            if (uVar40 < 9) {
              bVar34 = *(byte *)ppsVar58[1] & 0x1c;
              goto joined_r0x001060dc;
            }
          }
        }
LAB_:
        uVar36 = *(undefined4 *)((longlong)auStackX_20 + lVar23);
        uVar25 = *(undefined8 *)(&stack0x00000068 + lVar23);
      }
      else {
LAB_:
        if ((*(char *)(plVar51[6] + 0x1cde) == '\0') || (((&stack0x00000328)[lVar23] & 1) == 0)) {
LAB_:
          *(undefined4 *)(&stack0x00000044 + lVar23) = 0;
          uVar36 = *(undefined4 *)((longlong)auStackX_20 + lVar23);
          uVar25 = *(undefined8 *)(&stack0x00000068 + lVar23);
        }
        else {
          pcVar8 = *(code **)*plVar51;
          *(undefined8 *)(puVar43 + -8) = 0x106115;
          cVar18 = (*pcVar8)(plVar51);
          if (cVar18 != '\0') goto LAB_;
          *(undefined4 *)(&stack0x00000044 + lVar23) = 0xf;
          uVar36 = *(undefined4 *)((longlong)auStackX_20 + lVar23);
          uVar25 = *(undefined8 *)(&stack0x00000068 + lVar23);
        }
      }
    }
    else {
      ppsVar54 = ppsVar58;
      if (ppsVar50 != (short **)0x0) {
        ppsVar54 = ppsVar50;
      }
      *(undefined4 *)(&stack0x00000348 + lVar23) = uVar36;
      *(undefined4 *)(&stack0x0000034c + lVar23) = uVar7;
      *(undefined4 *)(&stack0x00000350 + lVar23) = uVar13;
      *(undefined4 *)(&stack0x00000354 + lVar23) = uVar14;
      *(undefined8 *)(&stack0x00000358 + lVar23) = uVar25;
      if ((int)ppsVar53 == 0) {
        psVar57 = *ppsVar42;
      }
      else {
        psVar57 = ppsVar42[1];
      }
      puVar55 = (ushort *)((longlong)ppsVar58 + 2);
      if (*(short *)ppsVar58 == 0) {
        if (*(int *)((longlong)ppsVar58 + 4) == 0) {
          *puVar55 = 0;
          uVar40 = *(uint *)(ppsVar58 + 2);
          uVar41 = (ulonglong)uVar40;
          *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
          psVar49 = ppsVar58[1];
          bVar34 = *(byte *)psVar49;
          if ((bVar34 & 0x10) != 0) {
            uVar40 = uVar40 + 2 + (*(ushort *)(uVar41 + (longlong)psVar49) + 7 >> 3);
            uVar41 = (ulonglong)uVar40;
            *(uint *)((longlong)ppsVar58 + 0x14) = uVar40;
            bVar34 = *(byte *)psVar49;
          }
          if ((bVar34 & 0x20) == 0) {
            *(int *)((longlong)ppsVar58 + 4) = (int)uVar41;
            *(undefined2 *)((longlong)ppsVar58 + 0x1c) = 0;
            *(uint *)(ppsVar58 + 3) = uVar40;
          }
          else {
            puVar44 = (ushort *)(uVar41 + (longlong)psVar49);
            uVar39 = *puVar44;
            *(ushort *)((longlong)ppsVar58 + 0x1c) = uVar39;
            if (uVar39 == 0) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10623f;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x106265;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                }
              }
              psVar49 = ppsVar58[1];
              *(undefined8 *)(puVar43 + -8) = 0x106273;
              func_0x(psVar49,3);
              uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
            }
            uVar40 = *(int *)((longlong)ppsVar58 + 0x14) + 2 + (uint)uVar39 * 2;
            *(uint *)(ppsVar58 + 3) = uVar40;
            if (0x1f9e < uVar40) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10630c;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x106332;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                }
              }
              psVar49 = ppsVar58[1];
              *(undefined8 *)(puVar43 + -8) = 0x106340;
              func_0x(psVar49,4);
            }
            uVar39 = puVar44[*(ushort *)((longlong)ppsVar58 + 0x1c)];
            *(uint *)((longlong)ppsVar58 + 4) = uVar39 & 0x7fff;
            if ((uVar39 & 0x7fff) < *(uint *)(ppsVar58 + 3)) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x1063d4;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x1063fa;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                }
              }
              psVar49 = ppsVar58[1];
              *(undefined8 *)(puVar43 + -8) = 0x106408;
              func_0x(psVar49,4);
            }
            do {
              uVar39 = *(ushort *)((longlong)ppsVar58 + 0x1c);
              if (-1 < (short)puVar44[(ulonglong)(uVar39 - 1) + 1]) break;
              psVar49 = ppsVar58[1];
              uVar40 = *(uint *)((longlong)ppsVar58 + 0x14);
              uVar48 = (uint)uVar39;
              if (uVar48 == 1) {
                uVar45 = *(uint *)(ppsVar58 + 3);
                uVar39 = *(ushort *)
                          ((longlong)psVar49 + (longlong)(int)uVar48 * 2 + (ulonglong)uVar40);
                uVar48 = uVar45;
LAB_:
                if ((uVar39 & 0x7fff) < uVar45) goto LAB_;
              }
              else {
                uVar45 = *(ushort *)
                          ((longlong)psVar49 + (longlong)(int)uVar48 * 2 + ((ulonglong)uVar40 - 2))
                         & 0x7fff;
                uVar48 = *(uint *)(ppsVar58 + 3);
                uVar39 = *(ushort *)((longlong)psVar49 + (ulonglong)uVar39 * 2 + (ulonglong)uVar40);
                if (uVar48 <= uVar45) goto LAB_;
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x106472;
                func_0x(psVar49,7);
                uVar48 = *(uint *)(ppsVar58 + 3);
              }
              if ((uVar45 < uVar48) || (*(uint *)((longlong)ppsVar58 + 4) < uVar45))
              goto LAB_;
              psVar49 = ppsVar58[1];
              if (*(ushort *)((ulonglong)uVar45 + (longlong)psVar49) == 5) {
                *puVar55 = *puVar55 | 2;
                *(short *)((longlong)ppsVar58 + 0x1c) = *(short *)((longlong)ppsVar58 + 0x1c) + -1;
                uVar40 = uVar45 & 0xffff;
                *(short *)((longlong)ppsVar58 + 0x2a) = (short)uVar45;
                uVar39 = *(ushort *)((longlong)ppsVar58 + 0x2c) & 0xc7ff;
                if ((*(ushort *)((longlong)psVar49 + (ulonglong)uVar40 + 2) & 0x4000) != 0) {
                  uVar39 = *(ushort *)((longlong)psVar49 + (ulonglong)uVar40 + 2) & 0x3800 | uVar39;
                }
                *(ushort *)((longlong)ppsVar58 + 0x2c) = uVar39;
                *(ushort *)((longlong)ppsVar58 + 0x2c) =
                     (uVar39 ^ *(ushort *)((longlong)psVar49 + (ulonglong)uVar40 + 2)) & 0x7ff ^
                     uVar39;
                break;
              }
              if (*(ushort *)((ulonglong)uVar45 + (longlong)psVar49) < 0x400) break;
              *puVar55 = *puVar55 | 1;
              psVar49 = (short *)((longlong)ppsVar58 + 0x1c);
              *psVar49 = *psVar49 + -1;
            } while (*psVar49 != 0);
          }
          iVar21 = 0;
          if ((*(byte *)ppsVar58[1] & 0x40) == 0) {
            *(undefined4 *)((longlong)ppsVar58 + 0x26) = 0;
          }
          else {
            *(int *)((longlong)ppsVar58 + 0x26) = *(int *)((longlong)ppsVar58 + 4);
            *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + 0xe;
            *(undefined8 *)(puVar43 + -8) = 0x106551;
            puVar27 = (ulonglong *)func_0x(puVar55);
            uVar41 = *puVar27;
            *(ulonglong *)(&stack0x00000190 + lVar23) = uVar41;
            uVar35 = (ushort)(uVar41 >> 0x30);
            uVar39 = uVar35;
            if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
              uVar39 = uVar35 & 0xdfff;
              if ((uVar41 & 0x4000000000000000) != 0) {
                uVar39 = uVar35 | 0x2000;
              }
            }
            if (uVar39 == 0xfffc) {
              iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)((longlong)ppsVar58 + 4) = *(int *)((longlong)ppsVar58 + 4) + iVar21;
          }
          uVar40 = *(uint *)((longlong)ppsVar58 + 4);
          if ((*(ulonglong *)((longlong)ppsVar58 + 0x1e) != 0) &&
             (*(ulonglong *)((longlong)ppsVar58 + 0x1e) < (ulonglong)uVar40 + (longlong)ppsVar58[1])
             ) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar37 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8), lVar37 != 0 &&
                 (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                (*(char *)(lVar37 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x10664c;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x106672;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
              }
            }
            psVar49 = ppsVar58[1];
            *(undefined8 *)(puVar43 + -8) = 0x106680;
            func_0x(psVar49,0x12);
            uVar40 = *(uint *)((longlong)ppsVar58 + 4);
          }
          if (0x3f3b < uVar40 - 1) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar37 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar37 != 0 &&
                ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                 (*(char *)(lVar37 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x10670b;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
                psVar49 = ppsVar58[1];
                *(undefined8 *)(puVar43 + -8) = 0x106719;
                func_0x(psVar49,5);
                goto LAB_;
              }
              *(undefined8 *)(puVar43 + 0x20) = 0;
              *(undefined8 *)(puVar43 + -8) = 0x10673f;
              (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
            }
            psVar49 = ppsVar58[1];
            *(undefined8 *)(puVar43 + -8) = 0x10674d;
            func_0x(psVar49,5);
          }
        }
LAB_:
        uVar40 = *(uint *)((longlong)ppsVar58 + 4);
        if (uVar40 < 9) {
          bVar34 = *(byte *)ppsVar58[1] & 0xe;
joined_r0x00106791:
          if ((bVar34 == 0) || (bVar34 == 0xc)) {
            uVar40 = 9;
          }
        }
      }
      else {
        uVar40 = *(uint *)((longlong)ppsVar58 + 4);
        if (uVar40 == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x10677d;
          func_0x(puVar55);
          uVar40 = *(uint *)((longlong)ppsVar58 + 4);
        }
        if (uVar40 < 9) {
          bVar34 = *(byte *)ppsVar58[1] & 0x1c;
          goto joined_r0x00106791;
        }
      }
      abStackX_18[lVar23 + 2] = 0;
      puVar55 = (ushort *)(psVar57 + 1);
      if (*psVar57 == 0) {
        if (*(int *)(psVar57 + 2) == 0) {
          *puVar55 = 0;
          uVar48 = *(uint *)(psVar57 + 8);
          uVar41 = (ulonglong)uVar48;
          *(uint *)(psVar57 + 10) = uVar48;
          pbVar3 = *(byte **)(psVar57 + 4);
          bVar34 = *pbVar3;
          if ((bVar34 & 0x10) != 0) {
            uVar48 = uVar48 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3) + 2;
            uVar41 = (ulonglong)uVar48;
            *(uint *)(psVar57 + 10) = uVar48;
            bVar34 = *pbVar3;
          }
          if ((bVar34 & 0x20) == 0) {
            *(int *)(psVar57 + 2) = (int)uVar41;
            psVar57[0xe] = 0;
            *(uint *)(psVar57 + 0xc) = uVar48;
          }
          else {
            puVar44 = (ushort *)(pbVar3 + uVar41);
            uVar39 = *puVar44;
            psVar57[0xe] = uVar39;
            if (uVar39 == 0) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x106882;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x1068a8;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x1068b6;
              func_0x(uVar25,3);
              uVar39 = psVar57[0xe];
            }
            uVar48 = *(int *)(psVar57 + 10) + (uVar39 + 1) * 2;
            *(uint *)(psVar57 + 0xc) = uVar48;
            if (0x1f9e < uVar48) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x10694e;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x106974;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x106982;
              func_0x(uVar25,4);
            }
            uVar39 = puVar44[(ushort)psVar57[0xe]];
            *(uint *)(psVar57 + 2) = uVar39 & 0x7fff;
            if ((uVar39 & 0x7fff) < *(uint *)(psVar57 + 0xc)) {
              if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                  (lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                 ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x106a16;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x106a3c;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x106a4a;
              func_0x(uVar25,4);
            }
            do {
              uVar39 = psVar57[0xe];
              if (-1 < (short)puVar44[(ulonglong)(uVar39 - 1) + 1]) break;
              lVar37 = *(longlong *)(psVar57 + 4);
              lVar26 = (ulonglong)*(uint *)(psVar57 + 10) + lVar37;
              uVar48 = (uint)uVar39;
              if (uVar48 == 1) {
                uVar45 = *(uint *)(psVar57 + 0xc);
                uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar48 * 2);
                uVar48 = uVar45;
LAB_:
                if ((uVar39 & 0x7fff) < uVar45) goto LAB_;
              }
              else {
                uVar45 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar48 * 2) & 0x7fff;
                uVar48 = *(uint *)(psVar57 + 0xc);
                uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                if (uVar48 <= uVar45) goto LAB_;
LAB_:
                *(undefined8 *)(puVar43 + -8) = 0x106ab4;
                func_0x(lVar37,7);
                uVar48 = *(uint *)(psVar57 + 0xc);
                lVar37 = *(longlong *)(psVar57 + 4);
              }
              if ((uVar45 < uVar48) || (*(uint *)(psVar57 + 2) < uVar45)) goto LAB_;
              if (*(ushort *)(lVar37 + (ulonglong)uVar45) == 5) {
                *puVar55 = *puVar55 | 2;
                psVar57[0xe] = psVar57[0xe] + -1;
                psVar57[0x15] = (short)uVar45;
                lVar37 = (ulonglong)(uVar45 & 0xffff) + *(longlong *)(psVar57 + 4);
                uVar39 = psVar57[0x16] & 0xc7ffU;
                if ((*(ushort *)(lVar37 + 2) & 0x4000) != 0) {
                  uVar39 = *(ushort *)(lVar37 + 2) & 0x3800 | psVar57[0x16] & 0xc7ffU;
                }
                psVar57[0x16] = uVar39;
                psVar57[0x16] = (uVar39 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar39;
                break;
              }
              if (*(ushort *)(lVar37 + (ulonglong)uVar45) < 0x400) break;
              *puVar55 = *puVar55 | 1;
              psVar49 = psVar57 + 0xe;
              *psVar49 = *psVar49 + -1;
            } while (*psVar49 != 0);
          }
          iVar21 = 0;
          if ((**(byte **)(psVar57 + 4) & 0x40) == 0) {
            *(undefined4 *)(psVar57 + 0x13) = 0;
          }
          else {
            *(int *)(psVar57 + 0x13) = *(int *)(psVar57 + 2);
            *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + 0xe;
            *(undefined8 *)(puVar43 + -8) = 0x106b95;
            puVar27 = (ulonglong *)func_0x(puVar55);
            uVar41 = *puVar27;
            *(ulonglong *)(&stack0x00000198 + lVar23) = uVar41;
            uVar35 = (ushort)(uVar41 >> 0x30);
            uVar39 = uVar35;
            if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
              uVar39 = uVar35 & 0xdfff;
              if ((uVar41 & 0x4000000000000000) != 0) {
                uVar39 = uVar35 | 0x2000;
              }
            }
            if (uVar39 == 0xfffc) {
              iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + iVar21;
          }
          uVar48 = *(uint *)(psVar57 + 2);
          if ((*(ulonglong *)(psVar57 + 0xf) != 0) &&
             (*(ulonglong *)(psVar57 + 0xf) < (ulonglong)uVar48 + *(longlong *)(psVar57 + 4))) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               (((lVar37 = *(longlong *)
                            ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8), lVar37 != 0 &&
                 (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                (*(char *)(lVar37 + 0x499) != '\0')))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x106c90;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x106cb6;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
              }
            }
            uVar25 = *(undefined8 *)(psVar57 + 4);
            *(undefined8 *)(puVar43 + -8) = 0x106cc4;
            func_0x(uVar25,0x12);
            uVar48 = *(uint *)(psVar57 + 2);
          }
          if (0x3f3b < uVar48 - 1) {
            if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
               ((lVar37 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                            *(longlong *)
                             (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                           + 8), lVar37 != 0 &&
                ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                 (*(char *)(lVar37 + 0x499) != '\0')))))) {
              if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x106d4f;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x106d75;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
              }
            }
            uVar25 = *(undefined8 *)(psVar57 + 4);
            *(undefined8 *)(puVar43 + -8) = 0x106d83;
            func_0x(uVar25,5);
          }
        }
LAB_:
        uVar48 = *(uint *)(psVar57 + 2);
        *(uint *)(&stack0x00000044 + lVar23) = uVar48;
        if (uVar48 < 9) {
          bVar34 = **(byte **)(psVar57 + 4);
          if (((bVar34 & 0xe) != 0) && ((bVar34 & 0xe) != 0xc)) goto LAB_;
          uVar48 = 9;
          *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
        }
        else {
LAB_:
          bVar34 = **(byte **)(psVar57 + 4);
        }
        if ((bVar34 & 0x40) != 0) {
          uVar48 = *(uint *)(psVar57 + 0x13);
LAB_:
          *(uint *)(&stack0x00000044 + lVar23) = uVar48;
        }
      }
      else {
        uVar48 = *(uint *)(psVar57 + 2);
        *(uint *)(&stack0x00000044 + lVar23) = uVar48;
        if (uVar48 == 0) {
          *(undefined8 *)(puVar43 + -8) = 0x106dcd;
          func_0x(puVar55);
          uVar48 = *(uint *)(psVar57 + 2);
          *(uint *)(&stack0x00000044 + lVar23) = uVar48;
          if (uVar48 == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x106ddf;
            func_0x(puVar55);
            uVar48 = *(uint *)(psVar57 + 2);
            *(uint *)(&stack0x00000044 + lVar23) = uVar48;
          }
        }
        if (uVar48 < 9) {
          bVar34 = **(byte **)(psVar57 + 4);
          if (((bVar34 & 0x1c) != 0) && ((bVar34 & 0x1c) != 0xc)) goto LAB_;
          uVar48 = 9;
          *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
        }
        else {
LAB_:
          bVar34 = **(byte **)(psVar57 + 4);
        }
        if ((bVar34 & 2) != 0) {
          uVar48 = *(uint *)(psVar57 + 0x18);
          goto LAB_;
        }
      }
      plVar51 = *(longlong **)(&stack0x00000060 + lVar23);
      pcVar8 = *(code **)*plVar51;
      *(undefined8 *)(puVar43 + -8) = 0x106e28;
      cVar18 = (*pcVar8)(plVar51);
      if (cVar18 == '\0') {
        if (((&stack0x00000348)[lVar23] & 1) != 0) {
          if (*psVar57 == 0) {
            bVar59 = (**(byte **)(psVar57 + 4) & 0xe) == 2;
          }
          else {
            bVar59 = ((**(byte **)(psVar57 + 4) & 0x1c) - 0x10 & 0xfffffffb) == 0;
          }
          if (!bVar59) goto LAB_;
        }
        lVar37 = plVar51[0x1a];
        if (((&stack0x00000350)[lVar23] & 1) != 0) goto LAB_;
        pcVar8 = *(code **)*plVar51;
        *(undefined8 *)(puVar43 + -8) = 0x107536;
        cVar18 = (*pcVar8)(plVar51);
        if (cVar18 != '\0') goto LAB_;
        pcVar8 = *(code **)(*plVar51 + 0x88);
        *(undefined8 *)(puVar43 + -8) = 0x10754a;
        cVar18 = (*pcVar8)(plVar51);
        if (cVar18 != '\0') {
          if ((&stack0x00000351)[lVar23] != '\0') goto LAB_;
          if (lVar37 == 0) {
            pcVar8 = *(code **)(*plVar51 + 0x18);
            *(undefined8 *)(puVar43 + -8) = 0x10756d;
            cVar18 = (*pcVar8)(plVar51);
            if (cVar18 == '\0') goto LAB_;
          }
          if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
            if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
              if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                if (plVar51[0x1a] == 0) {
                  pcVar8 = *(code **)(*plVar51 + 0x88);
                  *(undefined8 *)(puVar43 + -8) = 0x1075af;
                  cVar18 = (*pcVar8)(plVar51);
                  if (cVar18 != '\0') {
                    pcVar8 = *(code **)(*plVar51 + 0x18);
                    *(undefined8 *)(puVar43 + -8) = 0x1075bc;
                    cVar18 = (*pcVar8)(plVar51);
                    if (cVar18 == '\0') {
                      *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                      goto LAB_;
                    }
                  }
                }
                *(undefined8 *)(puVar43 + -8) = 0x1075d4;
                iVar21 = func_0x(plVar51);
                if (iVar21 == 0) {
                  pcVar8 = *(code **)(*plVar51 + 0x270);
                  *(undefined8 *)(puVar43 + -8) = 0x1075e4;
                  (*pcVar8)(plVar51);
                }
                if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                  if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                    lVar26 = plVar51[0x1a];
                    *(undefined8 *)(puVar43 + -8) = 0x10761c;
                    cVar18 = func_0x(lVar26);
                    if (((cVar18 != '\0') && (*(char *)(plVar51[0x1a] + 0x130) == '\0')) &&
                       (*(undefined *)(plVar51[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x107661;
                      func_0x(0x1f8b450,0x1c,0x10,1);
                    }
                  }
                  uVar45 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                }
                else {
                  pcVar8 = *(code **)(*plVar51 + 0x1e8);
                  *(undefined8 *)(puVar43 + -8) = 0x1075f9;
                  uVar25 = (*pcVar8)(plVar51);
                  *(undefined8 *)(puVar43 + -8) = 0x107601;
                  uVar45 = func_0x(uVar25);
                }
                if (uVar45 != 0) goto LAB_;
              }
            }
            else {
LAB_:
              if (((*(byte *)(plVar51 + 0x4a) & 0x40) != 0) && ((&stack0x00000352)[lVar23] != '\0'))
              goto LAB_;
            }
          }
        }
LAB_:
        if (((&stack0x00000350)[lVar23] & 0x1c) != 0) goto LAB_;
        if (*(longlong *)(&stack0x00000358 + lVar23) != 0) {
          *(undefined8 *)(puVar43 + -8) = 0x1076ac;
          iVar21 = func_0x();
          if (((iVar21 != 0) &&
              (iVar21 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000358 + lVar23) + 8) + 0x100
                                ), iVar21 != 0)) && (1 < iVar21 - 3U)) {
            *(undefined8 *)(puVar43 + 0x20) = 0;
            *(undefined8 *)(puVar43 + -8) = 0x1076f1;
            (*_DAT_)(1,0x1a263c0,0x1a26410,0x116);
          }
          uVar25 = *(undefined8 *)(&stack0x00000358 + lVar23);
          *(undefined8 *)(puVar43 + -8) = 0x1076fd;
          iVar21 = func_0x(uVar25);
          if ((((iVar21 != 0) &&
               ((*(byte *)(*(longlong *)(*(longlong *)(&stack0x00000358 + lVar23) + 8) + 0x109) & 1)
                == 0)) &&
              (iVar21 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000358 + lVar23) + 8) + 0x100
                                ), iVar21 != 0)) && (1 < iVar21 - 3U)) {
            *(undefined8 *)(puVar43 + 0x20) = 0;
            *(undefined8 *)(puVar43 + -8) = 0x10774b;
            (*_DAT_)(1,0x1a26440,0x1a26410,0x119);
          }
        }
        if ((lVar37 == 0) || ((*(int *)(lVar37 + 0x78) < 1 && (*(int *)(lVar37 + 0x74) < 1)))) {
          if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
            if ((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0) {
LAB_:
              if (lVar37 != 0) goto LAB_;
              goto LAB_;
            }
            if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
              if (plVar51[0x1a] == 0) {
                pcVar8 = *(code **)(*plVar51 + 0x88);
                *(undefined8 *)(puVar43 + -8) = 0x10779e;
                cVar18 = (*pcVar8)(plVar51);
                if (cVar18 != '\0') {
                  pcVar8 = *(code **)(*plVar51 + 0x18);
                  *(undefined8 *)(puVar43 + -8) = 0x1077ab;
                  cVar18 = (*pcVar8)(plVar51);
                  if (cVar18 == '\0') {
                    *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                    goto LAB_;
                  }
                }
              }
              *(undefined8 *)(puVar43 + -8) = 0x1077c6;
              iVar21 = func_0x(plVar51);
              if (iVar21 == 0) {
                pcVar8 = *(code **)(*plVar51 + 0x270);
                *(undefined8 *)(puVar43 + -8) = 0x1077d6;
                (*pcVar8)(plVar51);
              }
              if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                  lVar26 = plVar51[0x1a];
                  *(undefined8 *)(puVar43 + -8) = 0x10780e;
                  cVar18 = func_0x(lVar26);
                  if (((cVar18 != '\0') && (*(char *)(plVar51[0x1a] + 0x130) == '\0')) &&
                     (*(undefined *)(plVar51[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x107853;
                    func_0x(0x1f8b450,0x1c,0x10,1);
                  }
                }
                uVar45 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
              }
              else {
                pcVar8 = *(code **)(*plVar51 + 0x1e8);
                *(undefined8 *)(puVar43 + -8) = 0x1077eb;
                uVar25 = (*pcVar8)(plVar51);
                *(undefined8 *)(puVar43 + -8) = 0x1077f3;
                uVar45 = func_0x(uVar25);
              }
              if (uVar45 != 0) goto LAB_;
            }
          }
          goto LAB_;
        }
LAB_:
        if (((&stack0x00000350)[lVar23] & 0x1c) == 0) {
          if (*(longlong *)(&stack0x00000358 + lVar23) != 0) {
            *(undefined8 *)(puVar43 + -8) = 0x107895;
            iVar21 = func_0x();
            if (((iVar21 != 0) &&
                (iVar21 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000358 + lVar23) + 8) +
                                  0x100), iVar21 != 0)) && (1 < iVar21 - 3U)) {
              *(undefined8 *)(puVar43 + 0x20) = 0;
              *(undefined8 *)(puVar43 + -8) = 0x1078da;
              (*_DAT_)(1,0x1a263c0,0x1a26410,0x116);
            }
            uVar25 = *(undefined8 *)(&stack0x00000358 + lVar23);
            *(undefined8 *)(puVar43 + -8) = 0x1078e6;
            iVar21 = func_0x(uVar25);
            if (((iVar21 != 0) &&
                ((*(byte *)(*(longlong *)(*(longlong *)(&stack0x00000358 + lVar23) + 8) + 0x109) & 1
                 ) == 0)) &&
               ((iVar21 = *(int *)(*(longlong *)(*(longlong *)(&stack0x00000358 + lVar23) + 8) +
                                  0x100), iVar21 != 0 && (1 < iVar21 - 3U)))) {
              *(undefined8 *)(puVar43 + 0x20) = 0;
              *(undefined8 *)(puVar43 + -8) = 0x107934;
              (*_DAT_)(1,0x1a26440,0x1a26410,0x119);
            }
          }
          if ((*(int *)(lVar37 + 0x78) < 1) && (*(int *)(lVar37 + 0x74) < 1)) {
            if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
                if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                  if (plVar51[0x1a] == 0) {
                    pcVar8 = *(code **)(*plVar51 + 0x88);
                    *(undefined8 *)(puVar43 + -8) = 0x107982;
                    cVar18 = (*pcVar8)(plVar51);
                    if (cVar18 != '\0') {
                      pcVar8 = *(code **)(*plVar51 + 0x18);
                      *(undefined8 *)(puVar43 + -8) = 0x10798f;
                      cVar18 = (*pcVar8)(plVar51);
                      if (cVar18 == '\0') {
                        *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                        goto LAB_;
                      }
                    }
                  }
                  *(undefined8 *)(puVar43 + -8) = 0x1079a7;
                  iVar21 = func_0x(plVar51);
                  if (iVar21 == 0) {
                    pcVar8 = *(code **)(*plVar51 + 0x270);
                    *(undefined8 *)(puVar43 + -8) = 0x1079b7;
                    (*pcVar8)(plVar51);
                  }
                  if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                    if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                      lVar26 = plVar51[0x1a];
                      *(undefined8 *)(puVar43 + -8) = 0x1079ef;
                      cVar18 = func_0x(lVar26);
                      if (((cVar18 != '\0') && (*(char *)(plVar51[0x1a] + 0x130) == '\0')) &&
                         (*(undefined *)(plVar51[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x107a34;
                        func_0x(0x1f8b450,0x1c,0x10,1);
                      }
                    }
                    uVar45 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                  }
                  else {
                    pcVar8 = *(code **)(*plVar51 + 0x1e8);
                    *(undefined8 *)(puVar43 + -8) = 0x1079cc;
                    uVar25 = (*pcVar8)(plVar51);
                    *(undefined8 *)(puVar43 + -8) = 0x1079d4;
                    uVar45 = func_0x(uVar25);
                  }
                  if (uVar45 != 0) goto LAB_;
                }
              }
              else {
LAB_:
                if ((*(byte *)(plVar51 + 0x4a) & 0x10) != 0) goto LAB_;
              }
            }
LAB_:
            if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar51 + 0x4a) & 0x5a) == 0) {
                if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
                  if (plVar51[0x1a] == 0) {
                    pcVar8 = *(code **)(*plVar51 + 0x88);
                    *(undefined8 *)(puVar43 + -8) = 0x107a8e;
                    cVar18 = (*pcVar8)(plVar51);
                    if (cVar18 != '\0') {
                      pcVar8 = *(code **)(*plVar51 + 0x18);
                      *(undefined8 *)(puVar43 + -8) = 0x107a9b;
                      cVar18 = (*pcVar8)(plVar51);
                      if (cVar18 == '\0') {
                        *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                        goto LAB_;
                      }
                    }
                  }
                  *(undefined8 *)(puVar43 + -8) = 0x107ab3;
                  iVar21 = func_0x(plVar51);
                  if (iVar21 == 0) {
                    pcVar8 = *(code **)(*plVar51 + 0x270);
                    *(undefined8 *)(puVar43 + -8) = 0x107ac3;
                    (*pcVar8)(plVar51);
                  }
                  if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                    if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                      lVar26 = plVar51[0x1a];
                      *(undefined8 *)(puVar43 + -8) = 0x107afb;
                      cVar18 = func_0x(lVar26);
                      if (((cVar18 != '\0') && (*(char *)(plVar51[0x1a] + 0x130) == '\0')) &&
                         (*(undefined *)(plVar51[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x107b40;
                        func_0x(0x1f8b450,0x1c,0x10,1);
                      }
                    }
                    uVar45 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
                  }
                  else {
                    pcVar8 = *(code **)(*plVar51 + 0x1e8);
                    *(undefined8 *)(puVar43 + -8) = 0x107ad8;
                    uVar25 = (*pcVar8)(plVar51);
                    *(undefined8 *)(puVar43 + -8) = 0x107ae0;
                    uVar45 = func_0x(uVar25);
                  }
                  if (uVar45 != 0) goto LAB_;
                }
              }
              else {
LAB_:
                if ((*(byte *)(plVar51 + 0x4a) & 0x40) != 0) goto LAB_;
              }
            }
          }
        }
LAB_:
        *(undefined8 *)(puVar43 + -8) = 0x107b66;
        func_0x(lVar37,0);
LAB_:
        *(undefined8 *)(puVar43 + -8) = 0x107b6e;
        iVar21 = func_0x(plVar51);
        if (iVar21 == 0) {
          pcVar8 = *(code **)(*plVar51 + 0x270);
          *(undefined8 *)(puVar43 + -8) = 0x107b7e;
          (*pcVar8)(plVar51);
        }
        lVar37 = plVar51[0x1a];
        if (((&stack0x00000350)[lVar23] & 0x24) == 0) {
          if ((*(byte *)(plVar51 + 0x4a) & 4) == 0) {
            if ((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0) goto LAB_;
            if ((*(byte *)(plVar51 + 0x43) & 1) != 0) {
              if (lVar37 == 0) {
                pcVar8 = *(code **)(*plVar51 + 0x88);
                *(undefined8 *)(puVar43 + -8) = 0x107bc7;
                cVar18 = (*pcVar8)(plVar51);
                if (cVar18 != '\0') {
                  pcVar8 = *(code **)(*plVar51 + 0x18);
                  *(undefined8 *)(puVar43 + -8) = 0x107bd4;
                  cVar18 = (*pcVar8)(plVar51);
                  if (cVar18 == '\0') {
                    *(byte *)(plVar51 + 0x4a) = *(byte *)(plVar51 + 0x4a) | 4;
                    goto LAB_;
                  }
                }
              }
              *(undefined8 *)(puVar43 + -8) = 0x107bef;
              iVar21 = func_0x(plVar51);
              if (iVar21 == 0) {
                pcVar8 = *(code **)(*plVar51 + 0x270);
                *(undefined8 *)(puVar43 + -8) = 0x107bff;
                (*pcVar8)(plVar51);
              }
              if ((*(byte *)(plVar51 + 0x43) & 4) == 0) {
                if ((*(byte *)(plVar51 + 0x4a) & 0x52) == 2) {
                  lVar26 = plVar51[0x1a];
                  *(undefined8 *)(puVar43 + -8) = 0x107c37;
                  cVar18 = func_0x(lVar26);
                  if (((cVar18 != '\0') && (*(char *)(plVar51[0x1a] + 0x130) == '\0')) &&
                     (*(undefined *)(plVar51[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x107c7c;
                    func_0x(0x1f8b450,0x1c,0x10,1);
                  }
                }
                uVar45 = (uint)((*(byte *)(plVar51 + 0x4a) & 0x5a) != 0);
              }
              else {
                pcVar8 = *(code **)(*plVar51 + 0x1e8);
                *(undefined8 *)(puVar43 + -8) = 0x107c14;
                uVar25 = (*pcVar8)(plVar51);
                *(undefined8 *)(puVar43 + -8) = 0x107c1c;
                uVar45 = func_0x(uVar25);
              }
              if (uVar45 != 0) goto LAB_;
            }
          }
          if ((lVar37 == 0) || (*(int *)(lVar37 + 0x74) < 1)) goto LAB_;
        }
LAB_:
        pcVar8 = *(code **)(*plVar51 + 0x20);
        *(undefined8 *)(puVar43 + -8) = 0x107cab;
        cVar18 = (*pcVar8)(plVar51);
        if (cVar18 == '\0') {
LAB_:
          uVar25 = *(undefined8 *)(&stack0x00000068 + lVar23);
          uVar36 = *(undefined4 *)((longlong)auStackX_20 + lVar23);
          *(uint *)(&stack0x00000044 + lVar23) = uVar48 + 0xe;
        }
        else {
          if (*psVar57 == 0) {
            bVar59 = (**(byte **)(psVar57 + 4) & 0xe) == 2;
          }
          else {
            if ((*(longlong **)(psVar57 + 8) != (longlong *)0x0) &&
               (**(longlong **)(psVar57 + 8) != 0)) goto LAB_;
            bVar59 = ((**(byte **)(psVar57 + 4) & 0x1c) - 0x10 & 0xfffffffb) == 0;
          }
          if (bVar59) {
LAB_:
            if (*(short *)ppsVar54 == 0) {
              psVar57 = ppsVar54[1];
              *(undefined8 *)(puVar43 + -8) = 0x108a3c;
              iVar21 = func_0x(psVar57);
            }
            else {
              *(undefined8 *)(puVar43 + -8) = 0x108a47;
              iVar21 = func_0x((longlong)ppsVar54 + 2);
            }
            if (iVar21 == 0) {
              *(undefined8 *)(puVar43 + -8) = 0x108a5e;
              piVar30 = (int *)func_0x(ppsVar54,&stack0x000000c8 + lVar23);
              if ((*(short *)(piVar30 + 1) == 0) && (*piVar30 == 0)) {
                *(undefined8 *)(puVar43 + -8) = 0x108a84;
                lVar37 = func_0x(ppsVar54,&stack0x000001b8 + lVar23);
                uVar39 = *(ushort *)(lVar37 + 6);
                uVar35 = uVar39;
                if (((((uint)(int)(short)uVar39 >> 1 ^ (int)(short)uVar39) & 0x2000) != 0) &&
                   (uVar35 = uVar39 & 0xdfff, (uVar39 & 0x4000) != 0)) {
                  uVar35 = uVar39 | 0x2000;
                }
                if (uVar35 != 0xfffc) {
                  if (*(short *)ppsVar54 == 0) {
                    if (*(int *)((longlong)ppsVar54 + 4) == 0) {
                      *(undefined2 *)((longlong)ppsVar54 + 2) = 0;
                      uVar40 = *(uint *)(ppsVar54 + 2);
                      uVar41 = (ulonglong)uVar40;
                      *(uint *)((longlong)ppsVar54 + 0x14) = uVar40;
                      psVar57 = ppsVar54[1];
                      bVar34 = *(byte *)psVar57;
                      if ((bVar34 & 0x10) != 0) {
                        uVar40 = uVar40 + (*(ushort *)(uVar41 + (longlong)psVar57) + 7 >> 3) + 2;
                        uVar41 = (ulonglong)uVar40;
                        *(uint *)((longlong)ppsVar54 + 0x14) = uVar40;
                        bVar34 = *(byte *)psVar57;
                      }
                      if ((bVar34 & 0x20) == 0) {
                        *(int *)((longlong)ppsVar54 + 4) = (int)uVar41;
                        *(undefined2 *)((longlong)ppsVar54 + 0x1c) = 0;
                        *(uint *)(ppsVar54 + 3) = uVar40;
                      }
                      else {
                        puVar55 = (ushort *)(uVar41 + (longlong)psVar57);
                        uVar39 = *puVar55;
                        *(ushort *)((longlong)ppsVar54 + 0x1c) = uVar39;
                        if (uVar39 == 0) {
                          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                              (lVar37 = *(longlong *)
                                         ((ulonglong)*_DAT_ +
                                          *(longlong *)
                                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                           (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                             ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                              (*(char *)(lVar37 + 0x499) != '\0')))) {
                            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                              *(undefined8 *)(puVar43 + -8) = 0x108ba8;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar43 + 0x20) = 0;
                              *(undefined8 *)(puVar43 + -8) = 0x108bce;
                              (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                            }
                          }
                          psVar57 = ppsVar54[1];
                          *(undefined8 *)(puVar43 + -8) = 0x108bdc;
                          func_0x(psVar57,3);
                          uVar39 = *(ushort *)((longlong)ppsVar54 + 0x1c);
                        }
                        uVar40 = *(int *)((longlong)ppsVar54 + 0x14) + (uVar39 + 1) * 2;
                        *(uint *)(ppsVar54 + 3) = uVar40;
                        if (0x1f9e < uVar40) {
                          if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                             ((lVar37 = *(longlong *)
                                         ((ulonglong)*_DAT_ +
                                          *(longlong *)
                                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                           (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                              ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                               (*(char *)(lVar37 + 0x499) != '\0')))))) {
                            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                              *(undefined8 *)(puVar43 + -8) = 0x108c77;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar43 + 0x20) = 0;
                              *(undefined8 *)(puVar43 + -8) = 0x108c9d;
                              (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                            }
                          }
                          psVar57 = ppsVar54[1];
                          *(undefined8 *)(puVar43 + -8) = 0x108cab;
                          func_0x(psVar57,4);
                        }
                        uVar39 = puVar55[*(ushort *)((longlong)ppsVar54 + 0x1c)];
                        *(uint *)((longlong)ppsVar54 + 4) = uVar39 & 0x7fff;
                        if ((uVar39 & 0x7fff) < *(uint *)(ppsVar54 + 3)) {
                          if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                              (lVar37 = *(longlong *)
                                         ((ulonglong)*_DAT_ +
                                          *(longlong *)
                                           (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                           (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                             ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                              (*(char *)(lVar37 + 0x499) != '\0')))) {
                            if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                              *(undefined8 *)(puVar43 + -8) = 0x108d42;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar43 + 0x20) = 0;
                              *(undefined8 *)(puVar43 + -8) = 0x108d68;
                              (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                            }
                          }
                          psVar57 = ppsVar54[1];
                          *(undefined8 *)(puVar43 + -8) = 0x108d76;
                          func_0x(psVar57,4);
                        }
                        do {
                          uVar39 = *(ushort *)((longlong)ppsVar54 + 0x1c);
                          if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                          psVar57 = ppsVar54[1];
                          uVar40 = *(uint *)((longlong)ppsVar54 + 0x14);
                          uVar48 = (uint)uVar39;
                          if (uVar48 == 1) {
                            uVar45 = *(uint *)(ppsVar54 + 3);
                            uVar39 = *(ushort *)
                                      ((longlong)psVar57 +
                                      (longlong)(int)uVar48 * 2 + (ulonglong)uVar40);
                            uVar48 = uVar45;
LAB_:
                            if ((uVar39 & 0x7fff) < uVar45) goto LAB_;
                          }
                          else {
                            uVar45 = *(ushort *)
                                      ((longlong)psVar57 +
                                      (longlong)(int)uVar48 * 2 + ((ulonglong)uVar40 - 2)) & 0x7fff;
                            uVar48 = *(uint *)(ppsVar54 + 3);
                            uVar39 = *(ushort *)
                                      ((longlong)psVar57 + (ulonglong)uVar39 * 2 + (ulonglong)uVar40
                                      );
                            if (uVar48 <= uVar45) goto LAB_;
LAB_:
                            *(undefined8 *)(puVar43 + -8) = 0x108de7;
                            func_0x(psVar57,7);
                            uVar48 = *(uint *)(ppsVar54 + 3);
                          }
                          if ((uVar45 < uVar48) || (*(uint *)((longlong)ppsVar54 + 4) < uVar45))
                          goto LAB_;
                          psVar57 = ppsVar54[1];
                          if (*(ushort *)((ulonglong)uVar45 + (longlong)psVar57) == 5) {
                            *(ushort *)((longlong)ppsVar54 + 2) =
                                 *(ushort *)((longlong)ppsVar54 + 2) | 2;
                            *(short *)((longlong)ppsVar54 + 0x1c) =
                                 *(short *)((longlong)ppsVar54 + 0x1c) + -1;
                            uVar40 = uVar45 & 0xffff;
                            *(short *)((longlong)ppsVar54 + 0x2a) = (short)uVar45;
                            uVar39 = *(ushort *)((longlong)ppsVar54 + 0x2c) & 0xc7ff;
                            if ((*(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) & 0x4000) !=
                                0) {
                              uVar39 = *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2) &
                                       0x3800 | uVar39;
                            }
                            *(ushort *)((longlong)ppsVar54 + 0x2c) = uVar39;
                            *(ushort *)((longlong)ppsVar54 + 0x2c) =
                                 (uVar39 ^ *(ushort *)((longlong)psVar57 + (ulonglong)uVar40 + 2)) &
                                 0x7ff ^ uVar39;
                            break;
                          }
                          if (*(ushort *)((ulonglong)uVar45 + (longlong)psVar57) < 0x400) break;
                          *(ushort *)((longlong)ppsVar54 + 2) =
                               *(ushort *)((longlong)ppsVar54 + 2) | 1;
                          psVar57 = (short *)((longlong)ppsVar54 + 0x1c);
                          *psVar57 = *psVar57 + -1;
                        } while (*psVar57 != 0);
                      }
                      iVar21 = 0;
                      if ((*(byte *)ppsVar54[1] & 0x40) == 0) {
                        *(undefined4 *)((longlong)ppsVar54 + 0x26) = 0;
                      }
                      else {
                        *(int *)((longlong)ppsVar54 + 0x26) = *(int *)((longlong)ppsVar54 + 4);
                        *(int *)((longlong)ppsVar54 + 4) = *(int *)((longlong)ppsVar54 + 4) + 0xe;
                        *(undefined8 *)(puVar43 + -8) = 0x108e5e;
                        puVar27 = (ulonglong *)func_0x((longlong)ppsVar54 + 2);
                        uVar41 = *puVar27;
                        *(ulonglong *)(&stack0x000001c0 + lVar23) = uVar41;
                        uVar35 = (ushort)(uVar41 >> 0x30);
                        uVar39 = uVar35;
                        if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                          uVar39 = uVar35 & 0xdfff;
                          if ((uVar41 & 0x4000000000000000) != 0) {
                            uVar39 = uVar35 | 0x2000;
                          }
                        }
                        if (uVar39 == 0xfffc) {
                          iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                        }
                        *(int *)((longlong)ppsVar54 + 4) = *(int *)((longlong)ppsVar54 + 4) + iVar21
                        ;
                      }
                      uVar40 = *(uint *)((longlong)ppsVar54 + 4);
                      if ((*(ulonglong *)((longlong)ppsVar54 + 0x1e) != 0) &&
                         (*(ulonglong *)((longlong)ppsVar54 + 0x1e) <
                          (ulonglong)uVar40 + (longlong)ppsVar54[1])) {
                        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                           (((lVar37 = *(longlong *)
                                        ((ulonglong)*_DAT_ +
                                         *(longlong *)
                                          (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                          (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                             (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                            (*(char *)(lVar37 + 0x499) != '\0')))) {
                          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                            *(undefined8 *)(puVar43 + -8) = 0x108fbf;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            *(undefined8 *)(puVar43 + 0x20) = 0;
                            *(undefined8 *)(puVar43 + -8) = 0x108fe5;
                            (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                          }
                        }
                        psVar57 = ppsVar54[1];
                        *(undefined8 *)(puVar43 + -8) = 0x108ff3;
                        func_0x(psVar57,0x12);
                        uVar40 = *(uint *)((longlong)ppsVar54 + 4);
                      }
                      if (0x3f3b < uVar40 - 1) {
                        if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                           ((lVar37 = *(longlong *)
                                       ((ulonglong)*_DAT_ +
                                        *(longlong *)
                                         (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                         (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                            ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                             (*(char *)(lVar37 + 0x499) != '\0')))))) {
                          if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                            *(undefined8 *)(puVar43 + -8) = 0x10907f;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            *(undefined8 *)(puVar43 + 0x20) = 0;
                            *(undefined8 *)(puVar43 + -8) = 0x1090a5;
                            (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                          }
                        }
                        psVar57 = ppsVar54[1];
                        *(undefined8 *)(puVar43 + -8) = 0x1090b3;
                        func_0x(psVar57,5);
                      }
                    }
LAB_:
                    uVar40 = *(uint *)((longlong)ppsVar54 + 4);
                    if (uVar40 < 9) {
                      bVar34 = *(byte *)ppsVar54[1] & 0xe;
joined_r0x001090f1:
                      if ((bVar34 == 0) || (bVar34 == 0xc)) {
                        uVar40 = 9;
                      }
                    }
                  }
                  else {
                    uVar40 = *(uint *)((longlong)ppsVar54 + 4);
                    if (uVar40 == 0) {
                      *(undefined8 *)(puVar43 + -8) = 0x1090de;
                      func_0x((longlong)ppsVar54 + 2);
                      uVar40 = *(uint *)((longlong)ppsVar54 + 4);
                    }
                    if (uVar40 < 9) {
                      bVar34 = *(byte *)ppsVar54[1] & 0x1c;
                      goto joined_r0x001090f1;
                    }
                  }
                  iVar21 = *(int *)(&stack0x00000044 + lVar23);
                  plVar51 = *(longlong **)(&stack0x00000060 + lVar23);
                  uVar36 = *(undefined4 *)((longlong)auStackX_20 + lVar23);
                  uVar25 = *(undefined8 *)(&stack0x00000068 + lVar23);
                  if (uVar40 < 0x15) {
                    *(int *)(&stack0x00000044 + lVar23) = iVar21 + 0x22;
                    goto LAB_;
                  }
                  goto LAB_;
                }
              }
            }
            iVar21 = *(int *)(&stack0x00000044 + lVar23);
            plVar51 = *(longlong **)(&stack0x00000060 + lVar23);
            uVar25 = *(undefined8 *)(&stack0x00000068 + lVar23);
            uVar36 = *(undefined4 *)((longlong)auStackX_20 + lVar23);
          }
          else {
            if (*(short *)ppsVar54 == 0) {
              bVar59 = (*(byte *)ppsVar54[1] & 0xe) == 2;
            }
            else {
              bVar59 = ((*(byte *)ppsVar54[1] & 0x1c) - 0x10 & 0xfffffffb) == 0;
            }
            if ((bVar59) || (2000 < uVar48)) goto LAB_;
            if (*(short *)ppsVar54 == 0) {
              if (*(int *)((longlong)ppsVar54 + 4) == 0) {
                *(undefined2 *)((longlong)ppsVar54 + 2) = 0;
                uVar45 = *(uint *)(ppsVar54 + 2);
                uVar41 = (ulonglong)uVar45;
                *(uint *)((longlong)ppsVar54 + 0x14) = uVar45;
                psVar57 = ppsVar54[1];
                bVar34 = *(byte *)psVar57;
                if ((bVar34 & 0x10) != 0) {
                  uVar45 = uVar45 + (*(ushort *)(uVar41 + (longlong)psVar57) + 7 >> 3) + 2;
                  uVar41 = (ulonglong)uVar45;
                  *(uint *)((longlong)ppsVar54 + 0x14) = uVar45;
                  bVar34 = *(byte *)psVar57;
                }
                if ((bVar34 & 0x20) == 0) {
                  *(int *)((longlong)ppsVar54 + 4) = (int)uVar41;
                  *(undefined2 *)((longlong)ppsVar54 + 0x1c) = 0;
                  *(uint *)(ppsVar54 + 3) = uVar45;
                }
                else {
                  puVar55 = (ushort *)(uVar41 + (longlong)psVar57);
                  uVar39 = *puVar55;
                  *(ushort *)((longlong)ppsVar54 + 0x1c) = uVar39;
                  if (uVar39 == 0) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                       ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                        (*(char *)(lVar37 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x107e11;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x107e37;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                      }
                    }
                    psVar57 = ppsVar54[1];
                    *(undefined8 *)(puVar43 + -8) = 0x107e45;
                    func_0x(psVar57,3);
                    uVar39 = *(ushort *)((longlong)ppsVar54 + 0x1c);
                  }
                  uVar45 = *(int *)((longlong)ppsVar54 + 0x14) + (uVar39 + 1) * 2;
                  *(uint *)(ppsVar54 + 3) = uVar45;
                  if (0x1f9e < uVar45) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                        ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                         (*(char *)(lVar37 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x107ee0;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x107f06;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                      }
                    }
                    psVar57 = ppsVar54[1];
                    *(undefined8 *)(puVar43 + -8) = 0x107f14;
                    func_0x(psVar57,4);
                  }
                  uVar39 = puVar55[*(ushort *)((longlong)ppsVar54 + 0x1c)];
                  *(uint *)((longlong)ppsVar54 + 4) = uVar39 & 0x7fff;
                  if ((uVar39 & 0x7fff) < *(uint *)(ppsVar54 + 3)) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                       ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                        (*(char *)(lVar37 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x107fab;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x107fd1;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                      }
                    }
                    psVar57 = ppsVar54[1];
                    *(undefined8 *)(puVar43 + -8) = 0x107fdf;
                    func_0x(psVar57,4);
                  }
                  do {
                    uVar39 = *(ushort *)((longlong)ppsVar54 + 0x1c);
                    if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                    psVar57 = ppsVar54[1];
                    uVar45 = *(uint *)((longlong)ppsVar54 + 0x14);
                    uVar46 = (uint)uVar39;
                    if (uVar46 == 1) {
                      uVar47 = *(uint *)(ppsVar54 + 3);
                      uVar39 = *(ushort *)
                                ((longlong)psVar57 + (longlong)(int)uVar46 * 2 + (ulonglong)uVar45);
                      uVar46 = uVar47;
LAB_:
                      if ((uVar39 & 0x7fff) < uVar47) goto LAB_;
                    }
                    else {
                      uVar47 = *(ushort *)
                                ((longlong)psVar57 +
                                (longlong)(int)uVar46 * 2 + ((ulonglong)uVar45 - 2)) & 0x7fff;
                      uVar46 = *(uint *)(ppsVar54 + 3);
                      uVar39 = *(ushort *)
                                ((longlong)psVar57 + (ulonglong)uVar39 * 2 + (ulonglong)uVar45);
                      if (uVar46 <= uVar47) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar43 + -8) = 0x108057;
                      func_0x(psVar57,7);
                      uVar46 = *(uint *)(ppsVar54 + 3);
                    }
                    if ((uVar47 < uVar46) || (*(uint *)((longlong)ppsVar54 + 4) < uVar47))
                    goto LAB_;
                    if (*(ushort *)((ulonglong)uVar47 + (longlong)ppsVar54[1]) == 5) {
                      *(ushort *)((longlong)ppsVar54 + 2) = *(ushort *)((longlong)ppsVar54 + 2) | 2;
                      *(short *)((longlong)ppsVar54 + 0x1c) =
                           *(short *)((longlong)ppsVar54 + 0x1c) + -1;
                      uVar45 = uVar47 & 0xffff;
                      *(short *)((longlong)ppsVar54 + 0x2a) = (short)uVar47;
                      psVar57 = ppsVar54[1];
                      uVar39 = *(ushort *)((longlong)ppsVar54 + 0x2c) & 0xc7ff;
                      if ((*(ushort *)((longlong)psVar57 + (ulonglong)uVar45 + 2) & 0x4000) != 0) {
                        uVar39 = *(ushort *)((longlong)psVar57 + (ulonglong)uVar45 + 2) & 0x3800 |
                                 uVar39;
                      }
                      *(ushort *)((longlong)ppsVar54 + 0x2c) = uVar39;
                      *(ushort *)((longlong)ppsVar54 + 0x2c) =
                           (uVar39 ^ *(ushort *)((longlong)psVar57 + (ulonglong)uVar45 + 2)) & 0x7ff
                           ^ uVar39;
                      break;
                    }
                    if (*(ushort *)((ulonglong)uVar47 + (longlong)ppsVar54[1]) < 0x400) break;
                    *(ushort *)((longlong)ppsVar54 + 2) = *(ushort *)((longlong)ppsVar54 + 2) | 1;
                    psVar57 = (short *)((longlong)ppsVar54 + 0x1c);
                    *psVar57 = *psVar57 + -1;
                  } while (*psVar57 != 0);
                }
                iVar21 = 0;
                if ((*(byte *)ppsVar54[1] & 0x40) == 0) {
                  *(undefined4 *)((longlong)ppsVar54 + 0x26) = 0;
                }
                else {
                  *(int *)((longlong)ppsVar54 + 0x26) = *(int *)((longlong)ppsVar54 + 4);
                  *(int *)((longlong)ppsVar54 + 4) = *(int *)((longlong)ppsVar54 + 4) + 0xe;
                  *(undefined8 *)(puVar43 + -8) = 0x10814b;
                  puVar27 = (ulonglong *)func_0x((longlong)ppsVar54 + 2);
                  uVar41 = *puVar27;
                  *(ulonglong *)(&stack0x000001a8 + lVar23) = uVar41;
                  uVar35 = (ushort)(uVar41 >> 0x30);
                  uVar39 = uVar35;
                  if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                    uVar39 = uVar35 & 0xdfff;
                    if ((uVar41 & 0x4000000000000000) != 0) {
                      uVar39 = uVar35 | 0x2000;
                    }
                  }
                  if (uVar39 == 0xfffc) {
                    iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                  }
                  *(int *)((longlong)ppsVar54 + 4) = *(int *)((longlong)ppsVar54 + 4) + iVar21;
                }
                uVar45 = *(uint *)((longlong)ppsVar54 + 4);
                if ((*(ulonglong *)((longlong)ppsVar54 + 0x1e) != 0) &&
                   (*(ulonglong *)((longlong)ppsVar54 + 0x1e) <
                    (ulonglong)uVar45 + (longlong)ppsVar54[1])) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     (((lVar37 = *(longlong *)
                                  ((ulonglong)*_DAT_ +
                                   *(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                       (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x108248;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x10826e;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                    }
                  }
                  psVar57 = ppsVar54[1];
                  *(undefined8 *)(puVar43 + -8) = 0x10827c;
                  func_0x(psVar57,0x12);
                  uVar45 = *(uint *)((longlong)ppsVar54 + 4);
                }
                if (0x3f3b < uVar45 - 1) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                      ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                       (*(char *)(lVar37 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x108308;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x10832e;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                    }
                  }
                  psVar57 = ppsVar54[1];
                  *(undefined8 *)(puVar43 + -8) = 0x10833c;
                  func_0x(psVar57,5);
                }
              }
LAB_:
              uVar45 = *(uint *)((longlong)ppsVar54 + 4);
              uVar46 = uVar45;
              if (uVar45 < 9) {
                bVar34 = *(byte *)ppsVar54[1] & 0xe;
joined_r0x0010837a:
                if ((bVar34 == 0) || (uVar46 = uVar45, bVar34 == 0xc)) {
                  uVar46 = 9;
                }
              }
            }
            else {
              uVar45 = *(uint *)((longlong)ppsVar54 + 4);
              if (uVar45 == 0) {
                *(undefined8 *)(puVar43 + -8) = 0x108367;
                func_0x((longlong)ppsVar54 + 2);
                uVar45 = *(uint *)((longlong)ppsVar54 + 4);
              }
              uVar46 = uVar45;
              if (uVar45 < 9) {
                bVar34 = *(byte *)ppsVar54[1] & 0x1c;
                goto joined_r0x0010837a;
              }
            }
            if (2000 < uVar46) goto LAB_;
            if (*(short *)ppsVar54 == 0) {
              if (uVar45 == 0) {
                *(undefined2 *)((longlong)ppsVar54 + 2) = 0;
                uVar45 = *(uint *)(ppsVar54 + 2);
                uVar41 = (ulonglong)uVar45;
                *(uint *)((longlong)ppsVar54 + 0x14) = uVar45;
                psVar57 = ppsVar54[1];
                bVar34 = *(byte *)psVar57;
                if ((bVar34 & 0x10) != 0) {
                  uVar45 = uVar45 + (*(ushort *)(uVar41 + (longlong)psVar57) + 7 >> 3) + 2;
                  uVar41 = (ulonglong)uVar45;
                  *(uint *)((longlong)ppsVar54 + 0x14) = uVar45;
                  bVar34 = *(byte *)psVar57;
                }
                if ((bVar34 & 0x20) == 0) {
                  *(int *)((longlong)ppsVar54 + 4) = (int)uVar41;
                  *(undefined2 *)((longlong)ppsVar54 + 0x1c) = 0;
                  *(uint *)(ppsVar54 + 3) = uVar45;
                }
                else {
                  puVar55 = (ushort *)(uVar41 + (longlong)psVar57);
                  uVar39 = *puVar55;
                  *(ushort *)((longlong)ppsVar54 + 0x1c) = uVar39;
                  if (uVar39 == 0) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                       ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                        (*(char *)(lVar37 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x108479;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10849f;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                      }
                    }
                    psVar57 = ppsVar54[1];
                    *(undefined8 *)(puVar43 + -8) = 0x1084ad;
                    func_0x(psVar57,3);
                    uVar39 = *(ushort *)((longlong)ppsVar54 + 0x1c);
                  }
                  uVar45 = *(int *)((longlong)ppsVar54 + 0x14) + (uVar39 + 1) * 2;
                  *(uint *)(ppsVar54 + 3) = uVar45;
                  if (0x1f9e < uVar45) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                        ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                         (*(char *)(lVar37 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x108548;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10856e;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                      }
                    }
                    psVar57 = ppsVar54[1];
                    *(undefined8 *)(puVar43 + -8) = 0x10857c;
                    func_0x(psVar57,4);
                  }
                  uVar39 = puVar55[*(ushort *)((longlong)ppsVar54 + 0x1c)];
                  *(uint *)((longlong)ppsVar54 + 4) = uVar39 & 0x7fff;
                  if ((uVar39 & 0x7fff) < *(uint *)(ppsVar54 + 3)) {
                    if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                        (lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                       ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                        (*(char *)(lVar37 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x108613;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x108639;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                      }
                    }
                    psVar57 = ppsVar54[1];
                    *(undefined8 *)(puVar43 + -8) = 0x108647;
                    func_0x(psVar57,4);
                  }
                  do {
                    uVar39 = *(ushort *)((longlong)ppsVar54 + 0x1c);
                    if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                    psVar57 = ppsVar54[1];
                    uVar45 = *(uint *)((longlong)ppsVar54 + 0x14);
                    uVar46 = (uint)uVar39;
                    if (uVar46 == 1) {
                      uVar47 = *(uint *)(ppsVar54 + 3);
                      uVar39 = *(ushort *)
                                ((longlong)psVar57 + (longlong)(int)uVar46 * 2 + (ulonglong)uVar45);
                      uVar46 = uVar47;
LAB_:
                      if ((uVar39 & 0x7fff) < uVar47) goto LAB_;
                    }
                    else {
                      uVar47 = *(ushort *)
                                ((longlong)psVar57 +
                                (longlong)(int)uVar46 * 2 + ((ulonglong)uVar45 - 2)) & 0x7fff;
                      uVar46 = *(uint *)(ppsVar54 + 3);
                      uVar39 = *(ushort *)
                                ((longlong)psVar57 + (ulonglong)uVar39 * 2 + (ulonglong)uVar45);
                      if (uVar46 <= uVar47) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar43 + -8) = 0x1086b7;
                      func_0x(psVar57,7);
                      uVar46 = *(uint *)(ppsVar54 + 3);
                    }
                    if ((uVar47 < uVar46) || (*(uint *)((longlong)ppsVar54 + 4) < uVar47))
                    goto LAB_;
                    if (*(ushort *)((ulonglong)uVar47 + (longlong)ppsVar54[1]) == 5) {
                      *(ushort *)((longlong)ppsVar54 + 2) = *(ushort *)((longlong)ppsVar54 + 2) | 2;
                      *(short *)((longlong)ppsVar54 + 0x1c) =
                           *(short *)((longlong)ppsVar54 + 0x1c) + -1;
                      uVar45 = uVar47 & 0xffff;
                      *(short *)((longlong)ppsVar54 + 0x2a) = (short)uVar47;
                      psVar57 = ppsVar54[1];
                      uVar39 = *(ushort *)((longlong)ppsVar54 + 0x2c) & 0xc7ff;
                      if ((*(ushort *)((longlong)psVar57 + (ulonglong)uVar45 + 2) & 0x4000) != 0) {
                        uVar39 = *(ushort *)((longlong)psVar57 + (ulonglong)uVar45 + 2) & 0x3800 |
                                 uVar39;
                      }
                      *(ushort *)((longlong)ppsVar54 + 0x2c) = uVar39;
                      *(ushort *)((longlong)ppsVar54 + 0x2c) =
                           (uVar39 ^ *(ushort *)((longlong)psVar57 + (ulonglong)uVar45 + 2)) & 0x7ff
                           ^ uVar39;
                      break;
                    }
                    if (*(ushort *)((ulonglong)uVar47 + (longlong)ppsVar54[1]) < 0x400) break;
                    *(ushort *)((longlong)ppsVar54 + 2) = *(ushort *)((longlong)ppsVar54 + 2) | 1;
                    psVar57 = (short *)((longlong)ppsVar54 + 0x1c);
                    *psVar57 = *psVar57 + -1;
                  } while (*psVar57 != 0);
                }
                iVar21 = 0;
                if ((*(byte *)ppsVar54[1] & 0x40) == 0) {
                  *(undefined4 *)((longlong)ppsVar54 + 0x26) = 0;
                }
                else {
                  *(undefined4 *)((longlong)ppsVar54 + 0x26) =
                       *(undefined4 *)((longlong)ppsVar54 + 4);
                  *(int *)((longlong)ppsVar54 + 4) = *(int *)((longlong)ppsVar54 + 4) + 0xe;
                  *(undefined8 *)(puVar43 + -8) = 0x1087a9;
                  puVar27 = (ulonglong *)func_0x((longlong)ppsVar54 + 2);
                  uVar41 = *puVar27;
                  *(ulonglong *)(&stack0x000001b0 + lVar23) = uVar41;
                  uVar35 = (ushort)(uVar41 >> 0x30);
                  uVar39 = uVar35;
                  if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                    uVar39 = uVar35 & 0xdfff;
                    if ((uVar41 & 0x4000000000000000) != 0) {
                      uVar39 = uVar35 | 0x2000;
                    }
                  }
                  if (uVar39 == 0xfffc) {
                    iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                  }
                  *(int *)((longlong)ppsVar54 + 4) = *(int *)((longlong)ppsVar54 + 4) + iVar21;
                }
                uVar45 = *(uint *)((longlong)ppsVar54 + 4);
                if ((*(ulonglong *)((longlong)ppsVar54 + 0x1e) != 0) &&
                   (*(ulonglong *)((longlong)ppsVar54 + 0x1e) <
                    (ulonglong)uVar45 + (longlong)ppsVar54[1])) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     (((lVar37 = *(longlong *)
                                  ((ulonglong)*_DAT_ +
                                   *(longlong *)
                                    (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                    (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                       (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                      (*(char *)(lVar37 + 0x499) != '\0')))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x1088a6;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x1088cc;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                    }
                  }
                  psVar57 = ppsVar54[1];
                  *(undefined8 *)(puVar43 + -8) = 0x1088da;
                  func_0x(psVar57,0x12);
                  uVar45 = *(uint *)((longlong)ppsVar54 + 4);
                }
                if (0x3f3b < uVar45 - 1) {
                  if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                     ((lVar37 = *(longlong *)
                                 ((ulonglong)*_DAT_ +
                                  *(longlong *)
                                   (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                   (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                      ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                       (*(char *)(lVar37 + 0x499) != '\0')))))) {
                    if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                      *(undefined8 *)(puVar43 + -8) = 0x108966;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar43 + 0x20) = 0;
                      *(undefined8 *)(puVar43 + -8) = 0x10898c;
                      (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                    }
                  }
                  psVar57 = ppsVar54[1];
                  *(undefined8 *)(puVar43 + -8) = 0x10899a;
                  func_0x(psVar57,5);
                }
              }
LAB_:
              uVar45 = *(uint *)((longlong)ppsVar54 + 4);
              if (uVar45 < 9) {
                bVar34 = *(byte *)ppsVar54[1] & 0xe;
joined_r0x001089d4:
                if ((bVar34 == 0) || (bVar34 == 0xc)) {
                  uVar45 = 9;
                }
              }
            }
            else {
              if (uVar45 == 0) {
                *(undefined8 *)(puVar43 + -8) = 0x1089c1;
                func_0x((longlong)ppsVar54 + 2);
                uVar45 = *(uint *)((longlong)ppsVar54 + 4);
              }
              if (uVar45 < 9) {
                bVar34 = *(byte *)ppsVar54[1] & 0x1c;
                goto joined_r0x001089d4;
              }
            }
            if (uVar45 < 0x15) goto LAB_;
            iVar21 = *(int *)(&stack0x00000044 + lVar23) + 200;
            *(int *)(puVar43 + 0x20) = iVar21;
            uVar36 = *(undefined4 *)((longlong)auStackX_20 + lVar23);
            uVar25 = *(undefined8 *)(&stack0x00000068 + lVar23);
            plVar51 = *(longlong **)(&stack0x00000060 + lVar23);
            *(undefined8 *)(puVar43 + -8) = 0x108a11;
            cVar18 = func_0x(plVar51,uVar25,uVar36,uVar40);
            if (cVar18 == '\0') {
              abStackX_18[lVar23 + 2] = 1;
              *(uint *)(&stack0x00000044 + lVar23) = uVar48 + 0xe;
              goto LAB_;
            }
          }
LAB_:
          *(int *)(&stack0x00000044 + lVar23) = iVar21 + 0xe;
        }
      }
      else {
        if (*psVar57 == 0) {
          if (*(int *)(psVar57 + 2) == 0) {
            *puVar55 = 0;
            uVar40 = *(uint *)(psVar57 + 8);
            uVar41 = (ulonglong)uVar40;
            *(uint *)(psVar57 + 10) = uVar40;
            pbVar3 = *(byte **)(psVar57 + 4);
            bVar34 = *pbVar3;
            if ((bVar34 & 0x10) != 0) {
              uVar40 = uVar40 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3) + 2;
              uVar41 = (ulonglong)uVar40;
              *(uint *)(psVar57 + 10) = uVar40;
              bVar34 = *pbVar3;
            }
            if ((bVar34 & 0x20) == 0) {
              *(int *)(psVar57 + 2) = (int)uVar41;
              psVar57[0xe] = 0;
              *(uint *)(psVar57 + 0xc) = uVar40;
            }
            else {
              puVar44 = (ushort *)(pbVar3 + uVar41);
              uVar39 = *puVar44;
              psVar57[0xe] = uVar39;
              if (uVar39 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x106f10;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x106f36;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                  }
                }
                uVar25 = *(undefined8 *)(psVar57 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x106f44;
                func_0x(uVar25,3);
                uVar39 = psVar57[0xe];
              }
              uVar40 = *(int *)(psVar57 + 10) + (uVar39 + 1) * 2;
              *(uint *)(psVar57 + 0xc) = uVar40;
              if (0x1f9e < uVar40) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                    ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                     (*(char *)(lVar37 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x106fdc;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x107002;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                  }
                }
                uVar25 = *(undefined8 *)(psVar57 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x107010;
                func_0x(uVar25,4);
              }
              uVar39 = puVar44[(ushort)psVar57[0xe]];
              *(uint *)(psVar57 + 2) = uVar39 & 0x7fff;
              if ((uVar39 & 0x7fff) < *(uint *)(psVar57 + 0xc)) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1070a4;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x1070ca;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                  }
                }
                uVar25 = *(undefined8 *)(psVar57 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x1070d8;
                func_0x(uVar25,4);
              }
              do {
                uVar39 = psVar57[0xe];
                if (-1 < (short)puVar44[(ulonglong)(uVar39 - 1) + 1]) break;
                lVar37 = *(longlong *)(psVar57 + 4);
                lVar26 = (ulonglong)*(uint *)(psVar57 + 10) + lVar37;
                uVar40 = (uint)uVar39;
                if (uVar40 == 1) {
                  uVar48 = *(uint *)(psVar57 + 0xc);
                  uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar40 * 2);
                  uVar40 = uVar48;
LAB_:
                  if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
                }
                else {
                  uVar48 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                  uVar40 = *(uint *)(psVar57 + 0xc);
                  uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                  if (uVar40 <= uVar48) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar43 + -8) = 0x107144;
                  func_0x(lVar37,7);
                  uVar40 = *(uint *)(psVar57 + 0xc);
                }
                if ((uVar48 < uVar40) || (*(uint *)(psVar57 + 2) < uVar48)) goto LAB_;
                if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar57 + 4)) == 5) {
                  *puVar55 = *puVar55 | 2;
                  psVar57[0xe] = psVar57[0xe] + -1;
                  psVar57[0x15] = (short)uVar48;
                  lVar37 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(psVar57 + 4);
                  uVar39 = psVar57[0x16] & 0xc7ffU;
                  if ((*(ushort *)(lVar37 + 2) & 0x4000) != 0) {
                    uVar39 = *(ushort *)(lVar37 + 2) & 0x3800 | psVar57[0x16] & 0xc7ffU;
                  }
                  psVar57[0x16] = uVar39;
                  psVar57[0x16] = (uVar39 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar39;
                  break;
                }
                if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar57 + 4)) < 0x400) break;
                *puVar55 = *puVar55 | 1;
                psVar49 = psVar57 + 0xe;
                *psVar49 = *psVar49 + -1;
              } while (*psVar49 != 0);
            }
            iVar21 = 0;
            if ((**(byte **)(psVar57 + 4) & 0x40) == 0) {
              *(undefined4 *)(psVar57 + 0x13) = 0;
            }
            else {
              *(int *)(psVar57 + 0x13) = *(int *)(psVar57 + 2);
              *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + 0xe;
              *(undefined8 *)(puVar43 + -8) = 0x107227;
              puVar27 = (ulonglong *)func_0x(puVar55);
              uVar41 = *puVar27;
              *(ulonglong *)(&stack0x000001a0 + lVar23) = uVar41;
              uVar35 = (ushort)(uVar41 >> 0x30);
              uVar39 = uVar35;
              if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
                uVar39 = uVar35 & 0xdfff;
                if ((uVar41 & 0x4000000000000000) != 0) {
                  uVar39 = uVar35 | 0x2000;
                }
              }
              if (uVar39 == 0xfffc) {
                iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + iVar21;
            }
            uVar40 = *(uint *)(psVar57 + 2);
            if ((*(ulonglong *)(psVar57 + 0xf) != 0) &&
               (*(ulonglong *)(psVar57 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar57 + 4))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar37 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                   (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x107323;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x107349;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x107357;
              func_0x(uVar25,0x12);
              uVar40 = *(uint *)(psVar57 + 2);
            }
            if (0x3f3b < uVar40 - 1) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x1073e2;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x107408;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                }
              }
              uVar25 = *(undefined8 *)(psVar57 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x107416;
              func_0x(uVar25,5);
            }
          }
LAB_:
          uVar40 = *(uint *)(psVar57 + 2);
          *(uint *)(&stack0x00000044 + lVar23) = uVar40;
          if ((uVar40 < 9) &&
             (((**(byte **)(psVar57 + 4) & 0xe) == 0 || ((**(byte **)(psVar57 + 4) & 0xe) == 0xc))))
          {
            *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
          }
          plVar51 = *(longlong **)(&stack0x00000060 + lVar23);
        }
        else {
          uVar40 = *(uint *)(psVar57 + 2);
          *(uint *)(&stack0x00000044 + lVar23) = uVar40;
          if (uVar40 == 0) {
            *(undefined8 *)(puVar43 + -8) = 0x107451;
            func_0x(puVar55);
            uVar40 = *(uint *)(psVar57 + 2);
            *(uint *)(&stack0x00000044 + lVar23) = uVar40;
          }
          if ((uVar40 < 9) &&
             (((**(byte **)(psVar57 + 4) & 0x1c) == 0 || ((**(byte **)(psVar57 + 4) & 0x1c) == 0xc))
             )) {
            *(undefined4 *)(&stack0x00000044 + lVar23) = 9;
          }
        }
LAB_:
        uVar25 = *(undefined8 *)(&stack0x00000068 + lVar23);
        uVar36 = *(undefined4 *)((longlong)auStackX_20 + lVar23);
      }
LAB_:
      bVar38 = abStackX_18[lVar23 + 2];
    }
LAB_:
    lVar37 = *(longlong *)(&stack0x000000e8 + lVar23);
    *(byte *)(lVar37 + 0x531) = *(byte *)(lVar37 + 0x531) & 0xfe;
    *(byte *)(lVar37 + 0x531) = *(byte *)(lVar37 + 0x531) | bVar38;
    *(undefined4 *)(puVar43 + 0x20) = *(undefined4 *)(&stack0x00000044 + lVar23);
    uVar7 = *(undefined4 *)(&stack0x00000028 + lVar23);
    *(undefined8 *)(puVar43 + -8) = 0x1074b1;
    cVar18 = func_0x(plVar51,uVar25,uVar36,uVar7);
    psVar57 = *(short **)(&stack0x000000e0 + lVar23);
    if (cVar18 == '\0') {
LAB_:
      *(undefined4 *)(&stack0x00000038 + lVar23) = 1;
      uVar36 = *(undefined4 *)(&stack0x0000002c + lVar23);
      uVar25 = *(undefined8 *)(&stack0x000000f8 + lVar23);
      *(undefined8 *)(puVar43 + -8) = 0x10929d;
      func_0x(uVar25,uVar36);
      psVar49 = *(short **)(&stack0x00000058 + lVar23);
      *(undefined8 *)(puVar43 + -8) = 0x1092a9;
      cVar18 = func_0x(psVar49);
      if (cVar18 == '\0') {
LAB_:
        sVar6 = *psVar49;
        *(short *)(&stack0x00000438 + lVar23) = sVar6;
        if (sVar6 == 0) {
          if (*(int *)(psVar49 + 2) == 0) {
            psVar49[1] = 0;
            uVar40 = *(uint *)(psVar49 + 8);
            uVar41 = (ulonglong)uVar40;
            *(uint *)(psVar49 + 10) = uVar40;
            pbVar3 = *(byte **)(psVar49 + 4);
            bVar34 = *pbVar3;
            if ((bVar34 & 0x10) != 0) {
              uVar40 = uVar40 + 2 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3);
              uVar41 = (ulonglong)uVar40;
              *(uint *)(psVar49 + 10) = uVar40;
              bVar34 = *pbVar3;
            }
            if ((bVar34 & 0x20) == 0) {
              *(int *)(psVar49 + 2) = (int)uVar41;
              psVar49[0xe] = 0;
              *(uint *)(psVar49 + 0xc) = uVar40;
            }
            else {
              puVar55 = (ushort *)(pbVar3 + uVar41);
              uVar39 = *puVar55;
              psVar49[0xe] = uVar39;
              if (uVar39 == 0) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x109441;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x109467;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                  }
                }
                uVar25 = *(undefined8 *)(psVar49 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x109475;
                func_0x(uVar25,3);
                uVar39 = psVar49[0xe];
              }
              uVar40 = *(int *)(psVar49 + 10) + 2 + (uint)uVar39 * 2;
              *(uint *)(psVar49 + 0xc) = uVar40;
              if (0x1f9e < uVar40) {
                if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                   ((lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                    ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                     (*(char *)(lVar37 + 0x499) != '\0')))))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x109511;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x109537;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                  }
                }
                uVar25 = *(undefined8 *)(psVar49 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x109545;
                func_0x(uVar25,4);
              }
              uVar39 = puVar55[(ushort)psVar49[0xe]];
              *(uint *)(psVar49 + 2) = uVar39 & 0x7fff;
              if ((uVar39 & 0x7fff) < *(uint *)(psVar49 + 0xc)) {
                if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                    (lVar37 = *(longlong *)
                               ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                   ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                    (*(char *)(lVar37 + 0x499) != '\0')))) {
                  if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                    *(undefined8 *)(puVar43 + -8) = 0x1095dc;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar43 + 0x20) = 0;
                    *(undefined8 *)(puVar43 + -8) = 0x109602;
                    (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                  }
                }
                uVar25 = *(undefined8 *)(psVar49 + 4);
                *(undefined8 *)(puVar43 + -8) = 0x109610;
                func_0x(uVar25,4);
              }
              do {
                uVar39 = psVar49[0xe];
                if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                lVar37 = *(longlong *)(psVar49 + 4);
                lVar26 = (ulonglong)*(uint *)(psVar49 + 10) + lVar37;
                uVar40 = (uint)uVar39;
                if (uVar40 == 1) {
                  uVar48 = *(uint *)(psVar49 + 0xc);
                  uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar40 * 2);
LAB_:
                  if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
                }
                else {
                  uVar48 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                  uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                  if (*(uint *)(psVar49 + 0xc) <= uVar48) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar43 + -8) = 0x109681;
                  func_0x(lVar37,7);
                  if (uVar48 < *(uint *)(psVar49 + 0xc)) goto LAB_;
                }
                if (*(uint *)(psVar49 + 2) < uVar48) goto LAB_;
                if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar49 + 4)) == 5) {
                  psVar49[1] = psVar49[1] | 2;
                  psVar49[0xe] = psVar49[0xe] + -1;
                  psVar49[0x15] = (short)uVar48;
                  lVar37 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(psVar49 + 4);
                  uVar39 = *(ushort *)(lVar37 + 2);
                  uVar35 = psVar49[0x16] & 0xc7ff;
                  if ((uVar39 & 0x4000) != 0) {
                    uVar35 = uVar39 & 0x3800 | uVar35;
                  }
                  psVar49[0x16] = uVar35;
                  psVar49[0x16] = (uVar35 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar35;
                  break;
                }
                if (*(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar49 + 4)) < 0x400) break;
                psVar49[1] = psVar49[1] | 1;
                psVar2 = psVar49 + 0xe;
                *psVar2 = *psVar2 + -1;
              } while (*psVar2 != 0);
            }
            iVar21 = 0;
            if ((**(byte **)(psVar49 + 4) & 0x40) == 0) {
              *(undefined4 *)(psVar49 + 0x13) = 0;
            }
            else {
              *(int *)(psVar49 + 0x13) = *(int *)(psVar49 + 2);
              *(int *)(psVar49 + 2) = *(int *)(psVar49 + 2) + 0xe;
              *(undefined8 *)(puVar43 + -8) = 0x109782;
              puVar27 = (ulonglong *)func_0x(psVar49 + 1);
              uVar41 = *puVar27;
              *(ulonglong *)(&stack0x000001d0 + lVar23) = uVar41;
              uVar39 = (ushort)(uVar41 >> 0x30);
              if ((((uint)(int)(short)uVar39 >> 1 ^ (int)(short)uVar39) & 0x2000) != 0) {
                if ((uVar41 & 0x4000000000000000) == 0) {
                  uVar39 = uVar39 & 0xdfff;
                }
                else {
                  uVar39 = uVar39 | 0x2000;
                }
              }
              if (uVar39 == 0xfffc) {
                iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(psVar49 + 2) = *(int *)(psVar49 + 2) + iVar21;
            }
            uVar40 = *(uint *)(psVar49 + 2);
            if ((*(ulonglong *)(psVar49 + 0xf) != 0) &&
               (*(ulonglong *)(psVar49 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar49 + 4))) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 (((lVar37 = *(longlong *)
                              ((ulonglong)*_DAT_ +
                               *(longlong *)
                                (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                   (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                  (*(char *)(lVar37 + 0x499) != '\0')))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x109874;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar43 + 0x20) = 0;
                  *(undefined8 *)(puVar43 + -8) = 0x10989a;
                  (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                }
              }
              uVar25 = *(undefined8 *)(psVar49 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x1098a8;
              func_0x(uVar25,0x12);
              uVar40 = *(uint *)(psVar49 + 2);
            }
            if (0x3f3b < uVar40 - 1) {
              if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                 ((lVar37 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                              *(longlong *)
                               (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                               (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                  ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                   (*(char *)(lVar37 + 0x499) != '\0')))))) {
                if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                  *(undefined8 *)(puVar43 + -8) = 0x109934;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  uVar25 = *(undefined8 *)(psVar49 + 4);
                  *(undefined8 *)(puVar43 + -8) = 0x109942;
                  func_0x(uVar25,5);
                  goto LAB_;
                }
                *(undefined8 *)(puVar43 + 0x20) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x109968;
                (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
              }
              uVar25 = *(undefined8 *)(psVar49 + 4);
              *(undefined8 *)(puVar43 + -8) = 0x109976;
              func_0x(uVar25,5);
            }
          }
LAB_:
          uVar40 = *(uint *)(psVar49 + 2);
          if ((uVar40 < 9) &&
             (((**(byte **)(psVar49 + 4) & 0xe) == 0 || ((**(byte **)(psVar49 + 4) & 0xe) == 0xc))))
          {
            uVar40 = 9;
          }
          *(undefined4 *)(&stack0x00000448 + lVar23) = *(undefined4 *)(psVar49 + 8);
          *(short *)(&stack0x0000043a + lVar23) = psVar49[1];
          *(undefined4 *)(&stack0x0000043c + lVar23) = *(undefined4 *)(psVar49 + 2);
          *(short *)(&stack0x00000454 + lVar23) = psVar49[0xe];
          *(undefined4 *)(&stack0x0000044c + lVar23) = *(undefined4 *)(psVar49 + 10);
          *(undefined4 *)(&stack0x00000450 + lVar23) = *(undefined4 *)(psVar49 + 0xc);
          *(undefined4 *)(&stack0x0000045e + lVar23) = *(undefined4 *)(psVar49 + 0x13);
          *(undefined8 *)(puVar43 + -8) = 0x1099f4;
          uVar25 = func_0x(psVar49 + 1);
          *(undefined8 *)(puVar43 + -8) = 0x109a0b;
          func_0x(&stack0x00002ce8 + lVar23,0x1f9e,uVar25,uVar40);
          *(undefined **)(&stack0x00000440 + lVar23) = &stack0x00002ce8 + lVar23;
          *(undefined8 *)(puVar43 + -8) = 0x109a25;
          iVar21 = func_0x(&stack0x0000043a + lVar23);
          if (iVar21 != 0) {
            *(undefined8 *)(puVar43 + -8) = 0x109a3d;
            uVar19 = func_0x(&stack0x0000043a + lVar23,&stack0x0000004c + lVar23);
            *(ushort *)(&stack0x00000462 + lVar23) = uVar19;
            uVar39 = *(ushort *)((ulonglong)uVar19 + *(longlong *)(&stack0x00000440 + lVar23) + 2);
            uVar35 = *(ushort *)(&stack0x00000464 + lVar23);
            if ((uVar39 & 0x4000) == 0) {
              uVar35 = uVar35 & 0xc7ff;
            }
            else {
              uVar35 = uVar35 ^ (uVar35 ^ uVar39) & 0x3800;
            }
            *(ushort *)(&stack0x00000464 + lVar23) = uVar35;
            *(ushort *)(&stack0x00000464 + lVar23) =
                 (uVar35 ^ *(ushort *)
                            ((ulonglong)uVar19 + *(longlong *)(&stack0x00000440 + lVar23) + 2)) &
                 0x7ff ^ uVar35;
          }
        }
        else {
          if (*psVar49 != 0) {
            *(undefined8 *)(puVar43 + -8) = 0x109abc;
            lVar37 = func_0x(psVar49 + 1);
            if (lVar37 != 0) {
              if (*psVar49 == 0) {
                uVar25 = 0;
              }
              else {
                *(undefined8 *)(puVar43 + -8) = 0x109ad7;
                uVar25 = func_0x(psVar49 + 1);
              }
              *(undefined8 *)(puVar43 + -8) = 0x109ae1;
              iVar21 = func_0x(uVar25);
              if (iVar21 != 0) {
                *(undefined8 *)(puVar43 + -8) = 0x109b01;
                func_0x(&stack0x00000438 + lVar23,&stack0x00002ce8 + lVar23,0x1f9e,psVar49);
                goto LAB_;
              }
            }
          }
          *(undefined8 *)(puVar43 + -8) = 0x109b20;
          func_0x(&stack0x0000043a + lVar23,&stack0x00002ce8 + lVar23,0x1f9e,psVar49 + 1);
          if (*psVar49 == 0) {
            uVar25 = 0;
          }
          else {
            *(undefined8 *)(puVar43 + -8) = 0x109b36;
            uVar25 = func_0x(psVar49 + 1);
          }
          *(undefined8 *)(&stack0x00000448 + lVar23) = uVar25;
        }
      }
      else {
        if (*psVar49 == 0) {
          bVar59 = (**(byte **)(psVar49 + 4) & 0xe) == 2;
        }
        else {
          bVar59 = ((**(byte **)(psVar49 + 4) & 0x1c) - 0x10 & 0xfffffffb) == 0;
        }
        if (bVar59) goto LAB_;
        *(undefined8 *)(puVar43 + -8) = 0x1092de;
        uVar20 = func_0x(psVar49);
        *(undefined2 *)(puVar43 + 0x30) = uVar20;
        puVar43[0x28] = 0;
        *(undefined4 *)(puVar43 + 0x20) = 0;
        *(undefined8 *)(puVar43 + -8) = 0x10930a;
        func_0x(&stack0x00000438 + lVar23,&stack0x00002ce8 + lVar23,0x1f9e,0);
        if (abStackX_18[lVar23 + 1] != 0) {
          *(undefined8 *)(puVar43 + -8) = 0x109323;
          uVar25 = func_0x(psVar49,&stack0x000000ce + lVar23);
          *(undefined8 *)(puVar43 + -8) = 0x109332;
          func_0x(&stack0x00000438 + lVar23,uVar25);
          *(undefined8 *)(puVar43 + -8) = 0x109341;
          uVar25 = func_0x(psVar49,&stack0x000001c8 + lVar23);
          *(undefined8 *)(puVar43 + -8) = 0x109350;
          func_0x(&stack0x00000438 + lVar23,uVar25);
        }
      }
LAB_:
      if (*psVar49 == 0) {
        bVar59 = (**(byte **)(psVar49 + 4) & 0xe) == 2;
      }
      else {
        bVar59 = ((**(byte **)(psVar49 + 4) & 0x1c) - 0x10 & 0xfffffffb) == 0;
      }
      if (!bVar59) {
        *(undefined8 *)(puVar43 + -8) = 0x109b87;
        func_0x(&stack0x00000438 + lVar23,&stack0x00000118 + lVar23);
        *(undefined8 *)(puVar43 + -8) = 0x109b8f;
        cVar18 = func_0x(psVar49);
        if (cVar18 != '\0') {
          *(undefined8 *)(puVar43 + -8) = 0x109b9f;
          func_0x(&stack0x00000438 + lVar23);
        }
        if (psVar57 != (short *)0x0) {
          if (*psVar57 == 0) {
            bVar59 = (**(byte **)(psVar57 + 4) & 0xe) == 2;
          }
          else {
            bVar59 = ((**(byte **)(psVar57 + 4) & 0x1c) - 0x10 & 0xfffffffb) == 0;
          }
          if (!bVar59) {
            *(undefined8 *)(puVar43 + -8) = 0x109be2;
            func_0x(psVar57,&stack0x00000118 + lVar23);
            if (*pbVar5 != 0) {
              if (*psVar57 == 0) {
                if (*(int *)(psVar57 + 2) == 0) {
                  psVar57[1] = 0;
                  uVar40 = *(uint *)(psVar57 + 8);
                  uVar41 = (ulonglong)uVar40;
                  *(uint *)(psVar57 + 10) = uVar40;
                  pbVar3 = *(byte **)(psVar57 + 4);
                  bVar34 = *pbVar3;
                  if ((bVar34 & 0x10) != 0) {
                    uVar40 = uVar40 + (*(ushort *)(pbVar3 + uVar41) + 7 >> 3) + 2;
                    uVar41 = (ulonglong)uVar40;
                    *(uint *)(psVar57 + 10) = uVar40;
                    bVar34 = *pbVar3;
                  }
                  if ((bVar34 & 0x20) == 0) {
                    *(int *)(psVar57 + 2) = (int)uVar41;
                    psVar57[0xe] = 0;
                    *(uint *)(psVar57 + 0xc) = uVar40;
                  }
                  else {
                    puVar55 = (ushort *)(pbVar3 + uVar41);
                    uVar39 = *puVar55;
                    psVar57[0xe] = uVar39;
                    if (uVar39 == 0) {
                      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                          (lVar37 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                         ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                          (*(char *)(lVar37 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar43 + -8) = 0x109cd6;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x109cfc;
                          (*_DAT_)(1,0x1877a18,0x19976e8,0x80f);
                        }
                      }
                      uVar25 = *(undefined8 *)(psVar57 + 4);
                      *(undefined8 *)(puVar43 + -8) = 0x109d0b;
                      func_0x(uVar25,3);
                      uVar39 = psVar57[0xe];
                    }
                    uVar40 = *(int *)(psVar57 + 10) + (uVar39 + 1) * 2;
                    *(uint *)(psVar57 + 0xc) = uVar40;
                    if (0x1f9e < uVar40) {
                      if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                         ((lVar37 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                          ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                           (*(char *)(lVar37 + 0x499) != '\0')))))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar43 + -8) = 0x109da9;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x109dcf;
                          (*_DAT_)(1,0x1877a18,0x19976e8,0x816);
                        }
                      }
                      uVar25 = *(undefined8 *)(psVar57 + 4);
                      *(undefined8 *)(puVar43 + -8) = 0x109dde;
                      func_0x(uVar25,4);
                    }
                    uVar39 = puVar55[(ushort)psVar57[0xe]];
                    *(uint *)(psVar57 + 2) = uVar39 & 0x7fff;
                    if ((uVar39 & 0x7fff) < *(uint *)(psVar57 + 0xc)) {
                      if ((((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                          (lVar37 = *(longlong *)
                                     ((ulonglong)*_DAT_ +
                                      *(longlong *)
                                       (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                       (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0)) &&
                         ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                          (*(char *)(lVar37 + 0x499) != '\0')))) {
                        if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                          *(undefined8 *)(puVar43 + -8) = 0x109e78;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar43 + 0x20) = 0;
                          *(undefined8 *)(puVar43 + -8) = 0x109e9e;
                          (*_DAT_)(1,0x1877a18,0x19976e8,0x81d);
                        }
                      }
                      uVar25 = *(undefined8 *)(psVar57 + 4);
                      *(undefined8 *)(puVar43 + -8) = 0x109ead;
                      func_0x(uVar25,4);
                    }
                    do {
                      uVar39 = psVar57[0xe];
                      if (-1 < (short)puVar55[(ulonglong)(uVar39 - 1) + 1]) break;
                      lVar37 = *(longlong *)(psVar57 + 4);
                      lVar26 = (ulonglong)*(uint *)(psVar57 + 10) + lVar37;
                      uVar40 = (uint)uVar39;
                      if (uVar40 == 1) {
                        uVar48 = *(uint *)(psVar57 + 0xc);
                        uVar39 = *(ushort *)(lVar26 + (longlong)(int)uVar40 * 2);
                        uVar40 = uVar48;
LAB_:
                        if ((uVar39 & 0x7fff) < uVar48) goto LAB_;
                      }
                      else {
                        uVar48 = *(ushort *)(lVar26 + -2 + (longlong)(int)uVar40 * 2) & 0x7fff;
                        uVar40 = *(uint *)(psVar57 + 0xc);
                        uVar39 = *(ushort *)(lVar26 + (ulonglong)uVar39 * 2);
                        if (uVar40 <= uVar48) goto LAB_;
LAB_:
                        *(undefined8 *)(puVar43 + -8) = 0x109f2c;
                        func_0x(lVar37,7);
                        uVar40 = *(uint *)(psVar57 + 0xc);
                      }
                      if ((uVar48 < uVar40) || (*(uint *)(psVar57 + 2) < uVar48)) goto LAB_;
                      uVar39 = *(ushort *)((ulonglong)uVar48 + *(longlong *)(psVar57 + 4));
                      if (uVar39 == 5) {
                        psVar57[1] = psVar57[1] | 2;
                        psVar57[0xe] = psVar57[0xe] + -1;
                        psVar57[0x15] = (short)uVar48;
                        lVar37 = (ulonglong)(uVar48 & 0xffff) + *(longlong *)(psVar57 + 4);
                        uVar39 = *(ushort *)(lVar37 + 2);
                        uVar35 = psVar57[0x16] & 0xc7ff;
                        if ((uVar39 & 0x4000) != 0) {
                          uVar35 = uVar39 & 0x3800 | uVar35;
                        }
                        psVar57[0x16] = uVar35;
                        psVar57[0x16] = (uVar35 ^ *(ushort *)(lVar37 + 2)) & 0x7ff ^ uVar35;
                        break;
                      }
                      if (uVar39 < 0x400) break;
                      psVar57[1] = psVar57[1] | 1;
                      psVar49 = psVar57 + 0xe;
                      *psVar49 = *psVar49 + -1;
                    } while (*psVar49 != 0);
                  }
                  iVar21 = 0;
                  if ((**(byte **)(psVar57 + 4) & 0x40) == 0) {
                    *(undefined4 *)(psVar57 + 0x13) = 0;
                  }
                  else {
                    *(int *)(psVar57 + 0x13) = *(int *)(psVar57 + 2);
                    *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + 0xe;
                    *(undefined8 *)(puVar43 + -8) = 0x109fa3;
                    puVar27 = (ulonglong *)func_0x(psVar57 + 1);
                    uVar41 = *puVar27;
                    *(ulonglong *)(&stack0x000001d8 + lVar23) = uVar41;
                    uVar39 = (ushort)(uVar41 >> 0x30);
                    if ((((uint)(int)(short)uVar39 >> 1 ^ (int)(short)uVar39) & 0x2000) != 0) {
                      if ((uVar41 & 0x4000000000000000) == 0) {
                        uVar39 = uVar39 & 0xdfff;
                      }
                      else {
                        uVar39 = uVar39 | 0x2000;
                      }
                    }
                    if (uVar39 == 0xfffc) {
                      iVar21 = (int)((uVar41 >> 0x20 & 0xffff) >> 5);
                    }
                    *(int *)(psVar57 + 2) = *(int *)(psVar57 + 2) + iVar21;
                  }
                  uVar40 = *(uint *)(psVar57 + 2);
                  if ((*(ulonglong *)(psVar57 + 0xf) != 0) &&
                     (*(ulonglong *)(psVar57 + 0xf) < (ulonglong)uVar40 + *(longlong *)(psVar57 + 4)
                     )) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       (((lVar37 = *(longlong *)
                                    ((ulonglong)*_DAT_ +
                                     *(longlong *)
                                      (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                      (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                         (lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0)) &&
                        (*(char *)(lVar37 + 0x499) != '\0')))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x10a116;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10a13c;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x877);
                      }
                    }
                    uVar25 = *(undefined8 *)(psVar57 + 4);
                    *(undefined8 *)(puVar43 + -8) = 0x10a14b;
                    func_0x(uVar25,0x12);
                    uVar40 = *(uint *)(psVar57 + 2);
                  }
                  if (0x3f3b < uVar40 - 1) {
                    if (((DAT_ != '\0') || ((DAT_ & 1) != 0)) &&
                       ((lVar37 = *(longlong *)
                                   ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8) + 8), lVar37 != 0 &&
                        ((lVar37 = *(longlong *)(lVar37 + 0x60), lVar37 != 0 &&
                         (*(char *)(lVar37 + 0x499) != '\0')))))) {
                      if ((DAT_ == '\0') && ((DAT_ & 2) == 0)) {
                        *(undefined8 *)(puVar43 + -8) = 0x10a1d8;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(puVar43 + 0x20) = 0;
                        *(undefined8 *)(puVar43 + -8) = 0x10a1fe;
                        (*_DAT_)(1,0x1877a18,0x19976e8,0x87c);
                      }
                    }
                    uVar25 = *(undefined8 *)(psVar57 + 4);
                    *(undefined8 *)(puVar43 + -8) = 0x10a20d;
                    func_0x(uVar25,5);
                  }
                }
LAB_:
                if ((8 < *(uint *)(psVar57 + 2)) ||
                   (((**(byte **)(psVar57 + 4) & 0xe) != 0 &&
                    ((**(byte **)(psVar57 + 4) & 0xe) != 0xc)))) {
                  *(uint *)(&stack0x0000003c + lVar23) = *(uint *)(psVar57 + 2);
                }
              }
              else {
                uVar40 = *(uint *)(psVar57 + 2);
                if (uVar40 == 0) {
                  *(undefined8 *)(puVar43 + -8) = 0x10a241;
                  func_0x(psVar57 + 1);
                  uVar40 = *(uint *)(psVar57 + 2);
                }
                if ((uVar40 < 9) &&
                   (((**(byte **)(psVar57 + 4) & 0x1c) == 0 ||
                    ((**(byte **)(psVar57 + 4) & 0x1c) == 0xc)))) {
                  *(undefined4 *)(&stack0x0000003c + lVar23) = 9;
                }
                else {
                  *(uint *)(&stack0x0000003c + lVar23) = uVar40;
                }
              }
              *(undefined8 *)(puVar43 + -8) = 0x10a271;
              func_0x(psVar57);
              *(undefined8 *)(puVar43 + -8) = 0x10a279;
              uVar40 = func_0x();
              if (*(uint *)(&stack0x0000003c + lVar23) < uVar40) {
                *(undefined4 *)(&stack0x000001e0 + lVar23) = 0;
                *(undefined2 *)(&stack0x000001e4 + lVar23) = 0;
                *(undefined2 *)(&stack0x000001e6 + lVar23) = 0;
                *(undefined8 *)(&stack0x00000aa8 + lVar23) =
                     *(undefined8 *)(&stack0x000001e0 + lVar23);
                *(undefined4 *)(&stack0x00000ab0 + lVar23) = 0;
                *(undefined2 *)(&stack0x00000ab4 + lVar23) = 0;
                *(undefined8 *)(puVar43 + -8) = 0x10a2c1;
                func_0x(psVar57,&stack0x00000aa8 + lVar23);
              }
            }
          }
        }
      }
      uVar36 = *(undefined4 *)(&stack0x00000030 + lVar23);
    }
    else {
      if (psVar57 != (short *)0x0) {
        if (*psVar57 == 0) {
          bVar59 = (**(byte **)(psVar57 + 4) & 0xe) == 2;
        }
        else {
          bVar59 = ((**(byte **)(psVar57 + 4) & 0x1c) - 0x10 & 0xfffffffb) == 0;
        }
        if ((bVar59) && (*(int *)((longlong)auStackX_20 + lVar23 + 4) == 2)) goto LAB_;
      }
      puVar28 = (undefined4 *)(lVar37 + 0x530);
      if (abStackX_18[lVar23 + 1] == 0) {
        lVar37 = 2;
        puVar33 = (undefined4 *)(&stack0x000004a8 + lVar23);
        do {
          uVar36 = puVar28[1];
          uVar7 = puVar28[2];
          uVar13 = puVar28[3];
          *puVar33 = *puVar28;
          puVar33[1] = uVar36;
          puVar33[2] = uVar7;
          puVar33[3] = uVar13;
          uVar36 = puVar28[5];
          uVar7 = puVar28[6];
          uVar13 = puVar28[7];
          puVar33[4] = puVar28[4];
          puVar33[5] = uVar36;
          puVar33[6] = uVar7;
          puVar33[7] = uVar13;
          uVar36 = puVar28[9];
          uVar7 = puVar28[10];
          uVar13 = puVar28[0xb];
          puVar33[8] = puVar28[8];
          puVar33[9] = uVar36;
          puVar33[10] = uVar7;
          puVar33[0xb] = uVar13;
          uVar36 = puVar28[0xd];
          uVar7 = puVar28[0xe];
          uVar13 = puVar28[0xf];
          puVar33[0xc] = puVar28[0xc];
          puVar33[0xd] = uVar36;
          puVar33[0xe] = uVar7;
          puVar33[0xf] = uVar13;
          uVar36 = puVar28[0x11];
          uVar7 = puVar28[0x12];
          uVar13 = puVar28[0x13];
          puVar33[0x10] = puVar28[0x10];
          puVar33[0x11] = uVar36;
          puVar33[0x12] = uVar7;
          puVar33[0x13] = uVar13;
          uVar36 = puVar28[0x15];
          uVar7 = puVar28[0x16];
          uVar13 = puVar28[0x17];
          puVar33[0x14] = puVar28[0x14];
          puVar33[0x15] = uVar36;
          puVar33[0x16] = uVar7;
          puVar33[0x17] = uVar13;
          uVar36 = puVar28[0x19];
          uVar7 = puVar28[0x1a];
          uVar13 = puVar28[0x1b];
          puVar33[0x18] = puVar28[0x18];
          puVar33[0x19] = uVar36;
          puVar33[0x1a] = uVar7;
          puVar33[0x1b] = uVar13;
          uVar36 = puVar28[0x1d];
          uVar7 = puVar28[0x1e];
          uVar13 = puVar28[0x1f];
          puVar33[0x1c] = puVar28[0x1c];
          puVar33[0x1d] = uVar36;
          puVar33[0x1e] = uVar7;
          puVar33[0x1f] = uVar13;
          puVar28 = puVar28 + 0x20;
          lVar37 = lVar37 + -1;
          puVar33 = puVar33 + 0x20;
        } while (lVar37 != 0);
        *(undefined8 *)(puVar43 + 0x20) = *(undefined8 *)(&stack0x00000070 + lVar23);
        uVar36 = *(undefined4 *)(&stack0x00000030 + lVar23);
        uVar25 = *(undefined8 *)(&stack0x00000078 + lVar23);
        uVar29 = *(undefined8 *)(&stack0x000000f8 + lVar23);
        *(undefined8 *)(puVar43 + -8) = 0x109282;
        func_0x(uVar29,uVar25,&stack0x000004a8 + lVar23,uVar36);
      }
      else {
        lVar37 = 2;
        puVar33 = (undefined4 *)(&stack0x000005a8 + lVar23);
        do {
          uVar36 = puVar28[1];
          uVar7 = puVar28[2];
          uVar13 = puVar28[3];
          *puVar33 = *puVar28;
          puVar33[1] = uVar36;
          puVar33[2] = uVar7;
          puVar33[3] = uVar13;
          uVar36 = puVar28[5];
          uVar7 = puVar28[6];
          uVar13 = puVar28[7];
          puVar33[4] = puVar28[4];
          puVar33[5] = uVar36;
          puVar33[6] = uVar7;
          puVar33[7] = uVar13;
          uVar36 = puVar28[9];
          uVar7 = puVar28[10];
          uVar13 = puVar28[0xb];
          puVar33[8] = puVar28[8];
          puVar33[9] = uVar36;
          puVar33[10] = uVar7;
          puVar33[0xb] = uVar13;
          uVar36 = puVar28[0xd];
          uVar7 = puVar28[0xe];
          uVar13 = puVar28[0xf];
          puVar33[0xc] = puVar28[0xc];
          puVar33[0xd] = uVar36;
          puVar33[0xe] = uVar7;
          puVar33[0xf] = uVar13;
          uVar36 = puVar28[0x11];
          uVar7 = puVar28[0x12];
          uVar13 = puVar28[0x13];
          puVar33[0x10] = puVar28[0x10];
          puVar33[0x11] = uVar36;
          puVar33[0x12] = uVar7;
          puVar33[0x13] = uVar13;
          uVar36 = puVar28[0x15];
          uVar7 = puVar28[0x16];
          uVar13 = puVar28[0x17];
          puVar33[0x14] = puVar28[0x14];
          puVar33[0x15] = uVar36;
          puVar33[0x16] = uVar7;
          puVar33[0x17] = uVar13;
          uVar36 = puVar28[0x19];
          uVar7 = puVar28[0x1a];
          uVar13 = puVar28[0x1b];
          puVar33[0x18] = puVar28[0x18];
          puVar33[0x19] = uVar36;
          puVar33[0x1a] = uVar7;
          puVar33[0x1b] = uVar13;
          uVar36 = puVar28[0x1d];
          uVar7 = puVar28[0x1e];
          uVar13 = puVar28[0x1f];
          puVar33[0x1c] = puVar28[0x1c];
          puVar33[0x1d] = uVar36;
          puVar33[0x1e] = uVar7;
          puVar33[0x1f] = uVar13;
          puVar28 = puVar28 + 0x20;
          lVar37 = lVar37 + -1;
          puVar33 = puVar33 + 0x20;
        } while (lVar37 != 0);
        uVar36 = *(undefined4 *)(&stack0x00000030 + lVar23);
        uVar25 = *(undefined8 *)(&stack0x00000078 + lVar23);
        uVar29 = *(undefined8 *)(&stack0x000000f8 + lVar23);
        *(undefined8 *)(puVar43 + -8) = 0x109200;
        func_0x(uVar29,uVar25,&stack0x000005a8 + lVar23,uVar36);
      }
    }
    *(undefined8 *)(puVar43 + -8) = 0x10a2d1;
    func_0x(&stack0x00000108 + lVar23);
    *(undefined8 *)(puVar43 + -8) = 0x10a2de;
    func_0x(&stack0x00000100 + lVar23);
  }
  iVar21 = *(int *)(&stack0x00000038 + lVar23);
LAB_:
  lVar37 = *(longlong *)(&stack0x000000e8 + lVar23);
  if (iVar21 != 0) {
    *(undefined4 *)(puVar43 + 0x20) = uVar36;
    uVar36 = *(undefined4 *)(&stack0x00000034 + lVar23);
    uVar25 = *(undefined8 *)(&stack0x000000e0 + lVar23);
    *(undefined8 *)(puVar43 + -8) = 0x10a30d;
    func_0x(lVar37,&stack0x00000438 + lVar23,uVar25,uVar36);
  }
  puVar4 = (uint *)(lVar37 + 0x634);
  *puVar4 = *puVar4 | 1;
  uVar41 = *(ulonglong *)(&stack0x00004c88 + lVar23);
  *(undefined8 *)(puVar43 + -8) = 0x10a324;
  func_0x(uVar41 ^ (ulonglong)pbVar5);
  return;
}

