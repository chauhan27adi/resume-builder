
void FUN_(undefined8 *param_1)

{
  *param_1 = 0x1e61e40;
  *param_1 = 0x1e45388;
  *param_1 = 0x20699d8;
  return;
}

