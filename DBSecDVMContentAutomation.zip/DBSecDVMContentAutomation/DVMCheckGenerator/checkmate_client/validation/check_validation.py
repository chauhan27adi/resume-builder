import re
import json
import logging
from typing import Sequence, Dict
from os.path import join, dirname
from xml.etree.ElementTree import Element


DEFAULT_TAG_ATTRIBUTES = {}  # no attributes
DEFAULT_TAG_CHILDREN = []  # no children
DEFAULT_TAG_TEXT_VALUE = "^$"  # empty string regex
DEFAULT_TAG_TEXT_LENGTH = 0  # character count of 0
DEFAULT_PATCH_VALIDATION_JSON = "validation_patch.json"
DEFAULT_VULNERABILITY_VALIDATION_JSON = "validation_vulnerability.json"


class ValidationError(Exception):
	"""
	An Exception to raise if an error occurred when validating a check
	"""
	pass


class CheckValidator:
	"""
	This should hold logic only that is common to validation of all check types
	(Patches and Vulnerabilities)
	"""
	def __init__(self, check: Element, check_type: str):
		"""
		The check validator constructor
		:param check: the check of type Element (xml), not a string
		:param check_type: the type of check to validate (patch, vulnerability)
		"""
		self.__check = check
		self.__validation_json = dict()
		self.__logger = logging.getLogger('CheckGenerator')
		supported_checks = ["patch", "vulnerability"]
		if check_type.lower() == 'patch':
			validation_file = join(
				dirname(__file__), DEFAULT_PATCH_VALIDATION_JSON)
		elif check_type.lower() == 'vulnerability':
			validation_file = join(
				dirname(__file__), DEFAULT_VULNERABILITY_VALIDATION_JSON)
		else:
			raise ValidationError(
				f"Invalid check_type ({check_type}), "
				f"should be one of {supported_checks}"
			)
		self.__validation_json = self.__read_validation_json(validation_file)
		self.__reason = None

	@property
	def reason(self):
		return self.__reason

	def __read_validation_json(self, file_path: str):
		"""
		Static method to read a file as json
		:param file_path: the path of the json file to read
		:return: a dictionary object
		"""
		with open(file_path) as file_handle:
			try: return json.load(file_handle)
			# handle bad paths (directory or bad file)
			except FileNotFoundError: msg = "File not found"
			except (PermissionError, TypeError) as error_msg: msg = error_msg
			self.__logger.error(msg)
			return dict()

	def __validate_tag_has_children(
			self, child_tags: Sequence, tag: (Element, None) = None) -> bool:
		"""
		Validate if the provided tag has all the specified child tags.
		Order does not matter, child tag names are case-SENSITIVE
		If no tag is provided, validate against the root xml Element
		:param child_tags: the sequence of child tag names in any order
		:param tag: the tag to check, if None, uses the check root
		:return: a bool, true if valid, else false
		"""
		if tag is None: tag = self.__check
		try:
			return sorted(t.tag for t in tag) == sorted(child_tags)
		except Exception as error_message:
			raise ValidationError(error_message)

	def __validate_tag_has_attributes(
			self, attributes: (Dict, Sequence), tag: (Element, None) = None
	) -> bool:
		"""
		Validate if the provided tag has the provided attributes.
		If no tag is provided, validate against the root xml Element
		If a dictionary of attributes is supplied, validate the dict keys as
		attribute names and the dict values as attribute values respectively
		:param attributes: a sequence of attributes to validate
		:param tag: the tag to check
		:return: a bool, true if valid, else false
		"""
		if tag is None: tag = self.__check
		is_valid = sorted(tag.attrib) == sorted(attributes)
		try:
			if is_valid:
				if isinstance(attributes, dict):
					for attrib, expected_value in attributes.items():
						actual_value = tag.attrib[attrib]
						is_valid = bool(re.match(expected_value, actual_value))
						if not is_valid: break
			return is_valid
		except Exception as error_message:
			raise ValidationError(error_message)

	def __validate_tag_has_text(
			self, regex: str, tag: (Element, None) = None) -> bool:
		"""
		Validate if a tag has text matched entirely to regex
		:param regex: a regex to match the entire text against
		:param tag: the tag to check
		:return: a bool, true if valid, else false
		"""
		if tag is None: tag = self.__check
		text = tag.text
		if text is None: text = ""
		try:
			return bool(re.match(regex, text))
		except Exception as error_message:
			raise ValidationError(error_message)

	def __validate_tag_text_length(
			self, length: int, tag: (Element, None) = None) -> bool:
		"""
		Validate the length of tag texts against character count limitations
		in the checkmate DB
		:param length: the acceptable character count
		:param tag: the tag to validate
		:return: a bool, true if less than or equal to length, else false
		"""
		if tag is None: tag = self.__check
		text = tag.text
		if text is None:
			return 0 <= length
		return len(text) <= length

	def __validate_tag(
			self, tag: Element, attributes: (Sequence, Dict),
			children: Sequence, text: str, char_count: int) -> bool:
		"""
		Validate a tab based on content found in the json validation file.
		Validate the attributes on the tag, the children below the tag and
		the text of the tag
		:param tag: the XML Element tag to validate
		:param attributes: the expected attributes to find on the tag
		:param children: the expected children to find below the tag
		:param text: the expected text/regex to find
		:param char_count: the accepted character count length of the tag text
		:return: a bool, true if valid, else false
		"""
		fail_msg = f"Failed to validate tag '{tag.tag}' on"
		is_valid = self.__validate_tag_has_attributes(attributes, tag)
		if not is_valid:
			self.__reason = f"{fail_msg} attributes: {attributes}"
		else:
			is_valid = self.__validate_tag_has_children(children, tag)
			if not is_valid:
				self.__reason = f"{fail_msg} children: {children}"
			else:
				is_valid = self.__validate_tag_has_text(text, tag)
				if not is_valid:
					self.__reason = f"{fail_msg} text: {text}"
				else:
					is_valid = self.__validate_tag_text_length(char_count, tag)
					if not is_valid:
						self.__reason = f"{fail_msg} text length: {char_count}"
		return is_valid

	def validate(self) -> bool:
		"""
		Validate the current patch check based on the supplied json
		If all the json items are not found, check is invalid
		if the check has extra items not defined in the json, check is invalid
		:return: a boolean, true if valid, false if invalid
		"""
		is_valid = False
		for tag_name in self.__validation_json:
			item = self.__validation_json.get(tag_name, dict())
			if tag_name == "vatest": tag = self.__check
			else: tag = self.__check.find(tag_name)
			attributes = item.get("attributes", DEFAULT_TAG_ATTRIBUTES)
			children = item.get("children", DEFAULT_TAG_CHILDREN)
			text = item.get("text", dict())
			text_value = text.get("value", DEFAULT_TAG_TEXT_VALUE)
			text_length = text.get("length", DEFAULT_TAG_TEXT_LENGTH)
			is_valid = self.__validate_tag(
				tag, attributes, children, text_value, text_length)
			if not is_valid: break
		return is_valid