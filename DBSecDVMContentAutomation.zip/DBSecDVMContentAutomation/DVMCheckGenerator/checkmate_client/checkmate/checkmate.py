import re
import logging
import configparser
import os
import time
from bs4 import BeautifulSoup
from typing import Sequence, Dict
from os.path import join, dirname
from xml.etree.ElementTree import Element
from selenium.common.exceptions import ElementNotInteractableException
from checkmate_client.checkmate.web_driver import Driver


# Severity mapping based on the dropdown on the checkmate frontend
SEVERITY_MAP = {
	0: "Custom",
	1: "High",
	2: "Medium",
	3: "Low",
	4: "Notice",
	5: "Info"
}

DEFAULT_PROTOCOL = "http"
DEFAULT_PORT = 8080


class CheckmateUI:
	def __init__(self):
		"""
		Constructor for the Checkmate class that interfaces with the checkmate
		frontend via a selenium driver instance
		Set instance attributes and login to the provided checkmate application
		"""
		config_file_path = join(dirname(dirname(dirname(__file__))), "config.ini")
		self.__config_parser = configparser.ConfigParser()
		self.__config_parser.read(config_file_path)

		self.__logger = logging.getLogger('CheckGenerator')
		self.__checkmate_url = ""
		self.__checkmate_username = ""
		self.__checkmate_password = ""
		self.__xpaths = dict()
		self.__headless_browsing = True

		self.__read_checkmate_config()
		try:
			self.__driver = Driver(headless=self.__headless_browsing)
		except Exception as error_message:
			self.__logger.exception(error_message)

		self.__login()
		self.__logger.info(f"Finish login into checkmate at {self.__checkmate_url}")

	def __read_checkmate_config(self) -> None:
		"""
		Read the configuration data from config.ini for the checkmate frontend
		:return: None, this updates instance level attributes
		"""
		checkmate_config = self.__config_parser["checkmate_frontend"]
		host = checkmate_config.get("host")
		port = checkmate_config.getint("port", DEFAULT_PORT)
		protocol = checkmate_config.get("protocol", DEFAULT_PROTOCOL)
		self.__checkmate_url = f"{protocol}://{host}:{port}/"
		self.__checkmate_username = checkmate_config.get("username")
		self.__checkmate_password = checkmate_config.get("password")
		self.__xpaths = dict(self.__config_parser["checkmate_frontend_xpaths"])
		self.__headless_browsing = checkmate_config.getboolean("headless")

	def __login(self) -> bool:
		"""
		Logs into the checkmate frontend with details from config.ini
		:return: a bool, if login worked or not
		"""
		self.__logger.info(f"Start login into checkmate at {self.__checkmate_url}")
		self.__driver.get(self.__checkmate_url)
		username_field = self.__xpaths["input_login_username"]
		self.__driver.type_string(username_field, self.__checkmate_username)
		password_field = self.__xpaths["input_login_password"]
		self.__driver.type_string(password_field, self.__checkmate_password)
		submit = self.__xpaths["input_login_submit"]
		confirmation = self.__xpaths["div_logged_in"]
		return self.__driver.click(element=submit, confirmation=confirmation)

	def open_page(self, name: str, title: str = None) -> bool:
		"""
		Open a specific page within checkmate from the nav bar on the left
		:param name: the case-sensitive name of the page to open
		:param title: the title of a section on the expected page
		:return: a bool, true if page opens, else false
		"""
		self.__logger.info(f"Opening checkmate page: {name}")
		page = self.__xpaths["anchor_page"].replace("PAGE_NAME", name)
		if title:
			section = self.__xpaths["span_section"].replace(
				"SECTION_NAME", title)
		else:
			section = None
		clicked = self.__driver.click(page, confirmation=section)
		return clicked

	def __expand_expandable_section(self, name: str) -> bool:
		"""
		Expand an expandable section on the UI by clicking it
		:param name: the name of the expandable item
		:return: a bool, true if clicked, else false
		"""
		xpath = self.__xpaths["span_expandable"]
		xpath = xpath.replace("EXPANDABLE_NAME", name)
		confirm = xpath + f"/following-sibling::div[(@style='' or not(@style))]"
		if self.__driver.wait_for_presence(confirm): return True
		return self.__driver.click(xpath, confirmation=confirm)

	def __enable_html_long_desc(self) -> bool:
		"""
		Click on the long description text area to allow HTML in the long desc
		:return: a bool, true if clicked, else false
		"""
		xpath = self.__xpaths["btn_text_area_markup"]
		return self.__driver.click(xpath)

	@staticmethod
	def __get_external_reference_for_db(long_description: str) -> str:
		"""
		Parse the external reference URL from the html-like long description
		for a check
		:param long_description: the check's long description
		:return: a string, a URL if found, else the empty string
		"""
		soup = BeautifulSoup(long_description, "html.parser")
		anchor = soup.select_one("a")
		return anchor.get("href", "")

	@staticmethod
	def __get_severity_from_priority(priority: int) -> str:
		"""
		Convert a priority integer into a severity string based on the severity
		map
		:param priority: a priority integer
		:return: a severity string
		"""
		severity_text = SEVERITY_MAP.get(priority, "Custom")
		return f"{priority} - {severity_text}"

	@staticmethod
	def __get_result_type(result_type: str) -> str:
		"""
		Convert the "type" of the query into a valid resultType string for the
		checkmate UI
		:param result_type: a "type" of query (yes_no, processed, etc)
		:return: the correctly formatted string for the checkmate frontend
		"""
		result_type_components = result_type.split("_")
		result_type = "_".join(c.title() for c in result_type_components)
		# Unfortunately there is one that does not follow the above convention
		return result_type.replace("Empty", "empty")

	@classmethod
	def __build_checkmate_ui_map_from_check(
			cls, check: Element, tags_ids: str, platforms_ids: str
	) -> Dict:
		"""
		Build a mapping of check content to UI
		:param check: the XML check Element
		:param tags_ids: the string of comma-separated tag ids
		:param platforms_ids: the string of comma-separated platform ids
		:return: a dictionary of checkmate UI element name attribute values
		(will be used to create x-paths) mapped to the values to be sent to them
		"""
		priority = int(check.get("priority"))
		query = check.find("query")
		name = check.find("hhName")
		if "cve" in name.text.lower():
			ext_ref_name = f"{name.text.split()[-1]}"
			cve = ext_ref_name
		else:
			ext_ref_name = f"{' '.join(name.text.split()[:-2])} availability"
			cve = ""
		long_desc = check.find("longDescription").text
		ui_dict = {
			"itemId": check.get("name"),
			"category": check.find("category").text,
			"severity": cls.__get_severity_from_priority(priority),
			"name": name.text,
			"type": query.get("type").lower(),
			"body": query.text,
			"resultType": cls.__get_result_type(query.get("rule")),
			"cve": cve,
			"tags": tags_ids.split(","),
			"platforms": platforms_ids.split(","),
			"minEPOVersion": check.find("epoMinversion").text,
			"maxEPOVersion": check.find("epoMaxversion").text,
			"descriptions[0].shortDescription": check.find("hhmessage").text,
			"descriptions[0].longDescription": long_desc,
			"refs[0].name": ext_ref_name,
			"refs[0].address": cls.__get_external_reference_for_db(long_desc)
		}
		return ui_dict

	def fill_check_fields(self, check: Element, *args, **kwargs) -> bool:
		"""
		Fill all provided fields for a new check using the checkmate
		"Create new Checks" page
		:param check: an XML check Element
		:return: a bool, true if the check was added, else false
		"""
		self.__expand_expandable_section("Descriptions")
		self.__enable_html_long_desc()
		self.__expand_expandable_section("External References")
		ui_dict = self.__build_checkmate_ui_map_from_check(
			check, *args, **kwargs)
		results = []
		for name, value in ui_dict.items():
			xpath = self.__xpaths["input_field_by_name"]
			xpath = xpath.replace("ELEMENT_NAME", name)
			if isinstance(value, list):
				results.append(self.__handle_list_input(xpath, value))
			else:
				results.append(self.__handle_string_input(xpath, value))
		return len(results) > 0 and all(results)

	def save(self) -> bool:
		"""
		Click the save button on the page
		:return: bool, true if clicked, else false
		"""
		xpath = self.__xpaths["input_save_button"]
		new_check_section = self.__xpaths["span_expandable"]
		new_check_section = new_check_section.replace(
			"EXPANDABLE_NAME", "Show Check")
		saved = self.__driver.click(xpath, confirmation=new_check_section)
		if saved:
			self.__logger.info("Check Saved")
		else:

			# attempt to parse an exception message from the checkmate frontend
			if self.__expand_expandable_section("Exception Message"):
				xpath = self.__xpaths["div_exception_message"]
				exception_message = self.__driver.parse_text_from_element(xpath)
				if exception_message:
					message = f"Error seen: {exception_message}"
				else:
					message = "Unhandled error when creating check, "
					message += "could not confirm success"
				self.__logger.error(message)
			else:
				self.__logger.error("Unable to save new check")
				screenshot_file = "test.png"
				self.__driver.save_screenshot(screenshot_file)
				self.__logger.debug(f"Screenshot saved: {screenshot_file}")
		return saved

	def open_check_for_update(self, check_name: str, **kwargs) -> bool:
		"""
		Search for a check where the keywords in the arguments are the "names"
		of UI input fields and the values are the values to send to those fields
		:return: a bool, true if the check is found, else false
		"""
		# add filter
		for key, value in kwargs.items():
			filter_xpath = self.__xpaths["input_search_field"]
			filter_xpath = filter_xpath.replace("NAME", key)
			self.__driver.type_string(filter_xpath, str(value))
		# apply filter and open check
		search_xpath = self.__xpaths["btn_search_checks"]
		update_check_xpath = self.__xpaths["btn_update_check"]
		update_check_xpath = update_check_xpath.replace("CHECK", check_name)
		self.__driver.click(search_xpath, confirmation=update_check_xpath)
		check_open = self.__xpaths["input_item_id_populated"]
		check_open = check_open.replace("CHECK", check_name)
		# amazingly, this can take over 2 minutes to open the page -_-
		return self.__driver.click(
			update_check_xpath, confirmation=check_open, timeout=180)

	def __handle_string_input(self, xpath: str, value: str) -> bool:
		"""
		Attempt to enter a string value into all fields matching the xpath
		:param xpath: the element xpath to target
		:param value: the string value to send to the element
		:return: a bool, true if value sent, else false
		"""
		result = False
		try:
			try:
				if "longDescription" in xpath:
					# Don't write external refs to long desc field
					value = value.split("<")[0]
				# try to send the value to the element
				result = self.__driver.type_string(xpath, value, multi=True)
			except ElementNotInteractableException:
				# if a problem is encountered...
				if "longDescription" in xpath:
					# ...then it is either the long description element...
					xpath += "/preceding-sibling::*/iframe"
				else:
					# ...or it is a hidden element after the actual input
					xpath += "/preceding-sibling::input"
				result = self.__driver.type_string(xpath, value, multi=True)
		except Exception as error_message:
			self.__logger.exception(error_message)
			self.__logger.debug(f"xpath: {xpath}, value: {value}")
		return result

	def __handle_list_input(self, xpath: str, values: Sequence) -> bool:
		"""
		Attempt to select all elements with value value attributes in values
		from the dropdown/list identified by xpath
		:param xpath: the element xpath to target
		:param value: the list of element IDs to click
		:return: a bool, true if value sent, else false
		"""
		xpaths = [f"{xpath}//*[@value='{value}']" for value in values]
		return self.__driver.multi_click(xpaths)

	def choose_import_file_btn_and_submit(self, file_path: str) -> bool:
		"""
		Choose the xml file to import
		:param file_path: the path of the file to be imported
		:return: a bool, true if operation is successful, else false
		"""
		# Convert to absolute path for Selenium
		absolute_path = os.path.abspath(file_path)
		self.__logger.info(f"Absolute file path to import: {absolute_path}")
		try:
			# Check if the file exists
			if not os.path.isfile(absolute_path):
				self.__logger.error(f"File does not exist: {absolute_path}")
				return False

			self.__logger.info(f"Choosing xml file to import: {absolute_path}")

			# Find the hidden file input behind the "Choose File" button
			file_input = self.__driver.find_element_by_xpath(self.__xpaths["import_choose_file_btn"])

			# Send the file path directly (this uploads the file)
			file_input.send_keys(absolute_path)

			isCheckboxSelected = self.select_checkbox(self.__xpaths["checkbox_in_import_checks"])
			if isCheckboxSelected:
				# Press submit
				submit_button = self.__driver.find_element_by_xpath(self.__xpaths["submit_button_for_import"])
				submit_button.click()
				time.sleep(24)
				return True
			else:
				return False

		except Exception as e:
			self.__logger.error(f"Exception in import and submit xml file: {absolute_path}: {str(e)}")
			return False

	def select_checkbox(self, checkbox_xpath):
		try:
			checkbox = self.__driver.find_element_by_xpath(checkbox_xpath)
			# Only click if it's not already selected
			if not checkbox.is_selected():
				checkbox.click()
				print("Checkbox selected.")
			else:
				print("Checkbox was already selected.")
			return True
		except Exception as e:
			print(f"Error interacting with checkbox: {e}")
			return False

	def cleanup(self):
		"""
		Clean up the checkmate class and the associated web driver
		:return: None
		"""
		self.__driver.clean_up()