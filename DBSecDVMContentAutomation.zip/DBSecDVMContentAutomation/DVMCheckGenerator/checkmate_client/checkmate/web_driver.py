import logging
import os
import re
import signal
import psutil
from typing import List, Sequence, overload
from os.path import join, dirname
from selenium.webdriver.firefox.webdriver import WebDriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import (
	InvalidElementStateException,
	MoveTargetOutOfBoundsException,
	ElementNotInteractableException,
	TimeoutException,
	NoSuchElementException
)


# Checkmate is seriously slow :(
DEFAULT_WAIT_SECONDS = 90


class Driver(WebDriver):
	def __init__(self, headless: bool = True):
		"""
		Constructor for Driver class (inherits Selenium's Firefox WebDriver)
		:param headless: a boolean whether to use a headless (invisible) browser
		or not (usually only for debugging)
		"""
		options = Options()
		options.headless = headless
		driver_path = join(
			dirname(dirname(dirname(__file__))), "geckodriver.exe")
		super().__init__(
			options=options,
			executable_path=driver_path
		)
		self.__logger = logging.getLogger('CheckGenerator')
		self.__pid = self.service.process.pid
		self.__existing_pids = self.__get_non_selenium_firefox_process_list()
		self.set_page_load_timeout(60 * 10)

	@staticmethod
	def __get_non_selenium_firefox_process_list() -> List[int]:
		"""
		Get a list of PIDs for any currently running Firefox web browsers
		:return: a list of PIDs integers
		"""
		output = []
		for proc in psutil.process_iter():
			try:
				if proc.name().lower() == "firefox.exe":
					output += [proc.pid]
			except (
				psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess
			): pass
		return output

	def __find(
			self, element: str, element_type, multi: bool = False
	) -> [List[WebElement], WebElement]:
		"""
		Find an element in the DOM
		:param element: the element string to search for
		:param element_type: the type of element to search for
		:param multi: search for more than one elements or not
		:return: a list of elements or an element
		"""
		if multi:
			elements = self.find_elements(by=element_type, value=element)
			if len(elements) == 1:
				return elements[0]
			return elements
		return self.find_element(by=element_type, value=element)

	def click(
			self, element: str, element_type: By = By.XPATH,
			confirmation: str = None, confirmation_type: By = By.XPATH,
			**kwargs
	) -> bool:
		"""
		Send a mouse click to an element
		:param element: the element string to search for
		:param element_type: the type of element to search for
		:param confirmation: the element to search for to confirm click worked
		:param confirmation_type: the confirmation element type to search
		:return: a boolean, true if click succeeded, else false
		"""
		self.__logger.debug(f"Clicking element: {element}")
		if self.wait_for_presence(element, element_type, **kwargs):
			self.__logger.debug("Element found, clicking...")
			self.__find(element, element_type).click()
		if confirmation and confirmation_type:
			if self.wait_for_presence(
					confirmation, confirmation_type, **kwargs):
				return bool(self.__find(confirmation, confirmation_type))
		return True

	def multi_click(self, xpaths: Sequence[str], hold: bool = True) -> bool:
		"""
		Click each of the element x-paths in the elements list. If hold is
		specified as true (default) this is the equivalent of CTRL + click
		NOTE: Currently only elements referenced with x-paths are supported
		:param xpaths: a list of xpath strings to click
		:param hold: bool,hold the CTRL key as clicks are being made or not
		:return: a bool, true if all clicks made, else false
		"""
		results = []
		try:
			for xpath in xpaths:
				try:
					already_selected = self.__find(
						f"{xpath[:-1]} and @selected]", By.XPATH)
				except NoSuchElementException:
					already_selected = False
				if already_selected:
					results.append(True)
				else:
					element = self.__find(xpath, By.XPATH)
					if element:
						parent_xpath = f"{xpath}/parent::*"
						self.__scroll_element(parent_xpath)
						clicked = False
						i = 0
						while not clicked:
							try:
								element.click()
								clicked = True
							except MoveTargetOutOfBoundsException:
								# Item is currently not clickable as it is out
								# of sight, scroll until it is visible, 17 is
								# the "magic number" here i.e. the height of
								# each list item
								i += 1
								self.__scroll_element(
									f"{parent_xpath}/parent::*", 17 * i)
							# No idea what other exceptions could crop up here,
							# they'll be handled as they become apparent
						if hold: element.send_keys(Keys.CONTROL)
						results.append(True)
					else:
						results.append(False)
		except Exception as error_message:
			self.__logger.error(error_message)
			results.append(False)
		return all(results)

	def __scroll_element(
			self, xpath: str, scroll_to_y: int = 0, scroll_to_x: int = 0
	) -> None:
		"""
		Scroll within an element identified by x-path to the scroll location
		:param xpath: the element to scroll within
		:param scroll_to: the place to scroll to, I think it's in pixels
		:return:
		"""
		script = f"document.evaluate(\"{xpath}\", document)"
		script += ".iterateNext()"
		script += f".scrollTo({scroll_to_x}, {scroll_to_y});"
		self.execute_script(script)

	@staticmethod
	def __check_element_text(element: WebElement, text: str) -> bool:
		"""
		Check if an element of type WebElement has the text as it's current
		value. Regex is supported.
		:param element: the WebElement to interact with
		:param text: the string of text to compare against
		:return: bool, true if matches, else false
		"""
		current_text = element.text
		if not current_text or element.tag_name == "select":
			current_text = element.get_attribute("value")
			if current_text is None: current_text = ""
		if element.tag_name == "select":
			xpath = f"./option[@value='{current_text}']"
			current_text = element.find_element_by_xpath(xpath).text
		return bool(re.match(text, current_text))

	@staticmethod
	def __clear_field(field: WebElement) -> None:
		try:
			field.clear()
		except InvalidElementStateException:
			# this will actually work on some fields where the clear method
			# doesn't
			# On other fields it raises the same exception (Invalid State)
			try:
				field.send_keys(Keys.CONTROL, "a")
			except InvalidElementStateException:
				pass

	def type_string(
			self, element: str, text: str, element_type: By = By.XPATH,
			clear_field: bool = True, **kw
	) -> bool:
		"""
		Send a string of text to an element(s) (of type input)
		:param element: the element string to search for
		:param text: the text to send to the element
		:param element_type: the type of element to search for
		:param clear_field: bool, whether to clear the field before sending keys
		or not
		:return: a boolean, true if send succeeded, else false
		"""
		self.__logger.debug(
			f"Sending string to element: string={text}; element={element}")
		issue = False
		if self.wait_for_presence(element, element_type):
			fields = self.__find(element, element_type, **kw)
			# handle multiple fields
			if isinstance(fields, WebElement): fields = [fields]
			for field in fields:
				if not self.__check_element_text(field, text):
					try:
						if clear_field:
							self.__clear_field(field)
						# sometimes send_keys can be finicky, more reliable to
						# send the chars separately and verify after
						for char in text:
							field.send_keys(char)
					except ElementNotInteractableException:
						issue = True
						continue
		if issue:
			raise ElementNotInteractableException
		return self.__verify_element_text(element, text, element_type)

	def __verify_element_text(
			self, element: str, text: str, element_type: By = By.XPATH) -> bool:
		"""
		Verify that an input element contains a certain string of text
		:param element: the element string to search for
		:param text: the text to search the element for
		:param element_type: the type of element to search for
		:return: a boolean, true if text is verified, else false
		"""
		element = self.__find(element, element_type)
		actual = str(element.get_attribute("value")).replace("\n", "\\n")
		value = str(text).replace("\n", "")
		verified = actual == value
		return verified

	def wait_for_presence(
			self, element: str, element_type: By = By.XPATH,
			timeout: int = DEFAULT_WAIT_SECONDS
	) -> bool:
		"""
		A wait function to halt interaction with the web-driver based on
		detection of an element or a timeout
		:param element: an item to wait for presence of
		:param element_type: the type of element to eait for
		:param timeout: a timeout to wait for
		:return: a boolean, true if the item is found
		"""
		waiting = WebDriverWait(self, timeout)
		try:
			result = waiting.until(
				expected_conditions.presence_of_element_located(
					(element_type, element)
				)
			)
			if result:
				return bool(self.find_element(by=element_type, value=element))
		except (TimeoutError, TimeoutException): pass
		return False

	def parse_text_from_element(
			self, element: str, element_type: By = By.XPATH) -> str:
		"""
		Wait for, find and parse the text from an element on the browser
		:param element: the element to interact with
		:param element_type: the type of element to interact with
		:return: a string, the text or an empty string
		"""
		return self.__find(element, element_type).text

	def clean_up(self):
		"""
		Driver class cleaner upper
		:return: None
		"""
		# the geckodriver children, don't actually include the Firefox
		# application processes, only the geckodriver processes
		children = psutil.Process(self.__pid).children()
		# use selenium quit method
		self.quit()

		process_list = [self.__pid] + [child.pid for child in children]
		self.__logger.debug(f"Cleaning up web driver processes: {process_list}")
		try:
			for child in children:
				os.kill(child.pid, signal.SIGTERM)
			os.kill(self.__pid, signal.SIGTERM)
		except (psutil.NoSuchProcess, PermissionError, OSError):
			pass

		# kill any remaining Firefox processes
		# Not the ideal solution as if a FF window is opened by the user
		# mid-run then this will kill that also...
		for proc in psutil.process_iter():
			try:
				if "firefox" in proc.name().lower():
					if proc.pid not in self.__existing_pids:
						proc.kill()
			except (
				psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess
			): pass