import os
import re
import json
import time
import requests
import logging
from typing import Tuple
from itertools import count
from configparser import ConfigParser
from flask import Flask, jsonify, request
from flaskext.mysql import MySQL
from flask_httpauth import HTTPBasicAuth


app = Flask(__name__)
mysql = MySQL()

USER_DATA = {
    "admin": "admin"
}

log_format = "%(asctime)s %(levelname)s - %(message)s"
logging.basicConfig(
    filename="checkmateapi.log",
    level=logging.DEBUG,
    format=log_format
)
logger = logging.getLogger()


cfg = ConfigParser()
cfg.read("config.ini")
checkmate_host = cfg.get('DB', 'host')
checkmate_user = cfg.get('DB', 'user')
checkmate_password = cfg.get('DB', 'password')
checkmate_database = cfg.get('DB', 'database')
checkmate_port = cfg.get('DB', 'port')
checkmate_port = int(checkmate_port)


app.config['MYSQL_DATABASE_USER'] = checkmate_user
app.config['MYSQL_DATABASE_PASSWORD'] = checkmate_password
app.config['MYSQL_DATABASE_DB'] = checkmate_database
app.config['MYSQL_DATABASE_HOST'] = checkmate_host
app.config['MYSQL_DATABASE_PORT'] = checkmate_port

auth = HTTPBasicAuth()
mysql.init_app(app)


@auth.verify_password
def verify(username, password):
    try:
        if not (username and password):
            return False
        return USER_DATA.get(username) == password
    except Exception as err:
        logger.error(f"Authentication failed: {err}")

def get_current_MySQL_user():
    try:
        cur = mysql.connect().cursor()
        # Query to get the current MySQL user
        cur.execute("SELECT USER();")
        # Fetch the result
        current_user = cur.fetchone()[0].split('@')[0]
        cur.close()
        return current_user
    except Exception as err:
        logger.error(f"Failed to query database: {err}")

def get_next_item_id():
    try:
        cur = mysql.connect().cursor()
        query = "select id from item order by id desc limit 1;"
        cur.execute(query)
        id_value = int(list(cur.fetchone())[0]) + 1
        cur.close()
        return id_value
    except Exception as err:
        logger.error(f"Failed to query database: {err}")


def get_next_id_for_custom_revision_entity():
    try:
        cur = mysql.connect().cursor()
        query = "select id from custom_revision_entity order by id desc limit 1;"
        cur.execute(query)
        id_value = int(list(cur.fetchone())[0]) + 1
        cur.close()
        return id_value
    except Exception as err:
        logger.error(f"Failed to query database: {err}")

def get_rev_value():
    try:
        cur = mysql.connect().cursor()
        query = "select rev from item_aud order by rev desc limit 1;"
        cur.execute(query)
        rev_val = int(list(cur.fetchone())[0]) + 1
        cur.close()
        return rev_val
    except Exception as err:
        logger.error(f"Unable to get rev values: {err}")


def get_xml_item_id():
    cur = mysql.connect().cursor()
    query = "select id from xml_item order by id desc limit 1;"
    cur.execute(query)
    id_val = int(list(cur.fetchone())[0]) + 1
    cur.close()
    return id_val


def conversion_to_int(severity):
    if severity == 'Medium':
        return 2
    elif severity == 'Low':
        return 1
    else:
        return 3


@app.route('/api/v1/get/<new_id>/', methods=['GET'])
@auth.login_required
def get_db_values(new_id):
    try:
        cur = mysql.connect().cursor()
        query = f"select * from testrepo.item where item_id = '{new_id}';"
        cur.execute(query)
        details = str(cur.fetchone())
        if details:
            cur.close()
            return jsonify(new_id, details)
        else:
            return jsonify(new_id, 'not found')
    except Exception as err:
        return {"message": f"bad request: {err}"}, 404


@app.route('/api/v1/item', methods=['GET'])
@auth.login_required
def get_item_id() -> Tuple:
    """
    Return the item_id field value from the item table where the name is like
    the value of the "name" in the passed payload
    In the absence of a result, if the "id_prefix" (e.g. MSPATCH) is passed in
    the payload, then the next free item_id will be identified and returned
    :return: a tuple consisting of a json response and a response code
    """
    cur = mysql.connect().cursor()
    try:
        query = "select item_id from item where name like %s"
        payload = request.get_json()
        name = payload.get("name")
        cur.execute(query, f"%{name}%")
        details = cur.fetchone()
        if details:
            return {"item_id": details[0]}, 200
        else:
            # if there is no item_id found, then return the message or calculate
            # the next free item_id based on the current max in the table
            id_prefix = payload.get("id_prefix")
            if id_prefix:
                logger.info(f"No entry found for: {name}")
                logger.info("Returning next free item_id")
                query = "select max(item_id) from item where item_id like %s"
                cur.execute(query, f"{id_prefix}%")
                item_id = cur.fetchone()[0]
                max_item_id = re.findall("\d+", item_id)[0]
                id_num = str(int(max_item_id) + 1).zfill(3)
                output = {"item_id": f"{id_prefix}{id_num}"}, 200
            else:
                output = {"message", f"name not found: '{name}'"}, 404
    except Exception as err:
        output = {"message": f"Exception: {err}"}, 500
    finally:
        cur.close()
    return output


@app.route('/api/v1/tag/<tag_string>/', methods=['GET'])
@auth.login_required
def get_tag_id(tag_string: str) -> Tuple:
    """
    Return the integer ID for the provided tag_string
    :param tag_string: a string to search in the tag table
    :return: a tuple consisting of a json response and response code
    """
    # get the ID of a tag given the tag name
    try:
        cur = mysql.connect().cursor()
        query = "SELECT DISTINCT ID FROM tag WHERE NAME = %s"
        cur.execute(query, tag_string)
        details = str(cur.fetchone())
        cur.close()
        if details:
            return jsonify(tag_string, details), 200
        else:
            return jsonify(tag_string, 'not found'), 404
    except Exception as error_msg:
        return {"message": str(error_msg)}, 504


@app.route("/api/v1/item/<item_id>", methods=["GET"])
@auth.login_required
def get_item_table_row(item_id: str) -> Tuple:
    """
    Return the row data for the item_id
    :param item_id: the item_id to lookup in the item table
    :return: a tuple consisting of the json response and a response code
    """
    db = mysql.connect()
    output = []
    with db.cursor() as cursor:
        cursor.execute("desc item")
        cols = [col[0] for col in cursor.fetchall()]
        query = "SELECT * FROM item WHERE item_id = %s"
        cursor.execute(query, item_id)
        data = cursor.fetchall()
        for row in data:
            datapoint = []
            for i in row:
                if isinstance(i, bytes):
                    datapoint += [i.decode()]
                elif i is None:
                    datapoint += [""]
                else:
                    datapoint += [i]
            output += [dict(zip(cols, datapoint))]
    db.close()
    return {"items": output}, 200


@app.route("/api/v1/item_aud/<item_id>", methods=["GET"])
@auth.login_required
def get_item_aud_table_row(item_id: str) -> Tuple:
    """
    Return the row data for the item_id from item_aud table
    :param item_id: the item_id to lookup in the item_aud table
    :return: a tuple consisting of the json response and a response code
    """
    db = mysql.connect()
    output = []
    with db.cursor() as cursor:
        cursor.execute("desc item_aud")
        cols = [col[0] for col in cursor.fetchall()]
        query = "SELECT * FROM item_aud WHERE item_id = %s"
        cursor.execute(query, item_id)
        data = cursor.fetchall()
        for row in data:
            datapoint = []
            for i in row:
                if isinstance(i, bytes):
                    datapoint += [i.decode()]
                elif i is None:
                    datapoint += [""]
                else:
                    datapoint += [i]
            output += [dict(zip(cols, datapoint))]
    db.close()
    return {"items": output}, 200


@app.route('/api/v1/tag', methods=['POST'])
@auth.login_required
def add_tag() -> Tuple:
    """
    Add a new tag and return the id
    :return: a tuple consisting of the json response and a response code
    """
    try:
        data = request.get_json()
        db = mysql.connect()
        cur = db.cursor()
        cols = ','.join(data.keys())
        vals = ','.join('%s' for _ in data)
        query = f"INSERT INTO tag ({cols}) VALUES ({vals})"
        cur.execute(query, list(data.values()))
        query = f"SELECT id FROM tag WHERE "
        query += " AND ".join(f"{k}=%s" for k in data)
        cur.execute(query, list(data.values()))
        new_id = cur.fetchone()[0]
        db.commit()
        db.close()
        return {"new_id": new_id}, 201
    except Exception as error_msg:
        return {"message": str(error_msg)}, 504


@app.route('/api/v1/platform/<platform_string>/', methods=['GET'])
@auth.login_required
def get_platform_id(platform_string: str) -> Tuple:
    """
    Return the integer ID for the provided platform_string
    :param platform_string: a string to search in the platform table
    :return: a tuple consisting of a json response and response code
    """
    try:
        cur = mysql.connect().cursor()
        query = "SELECT DISTINCT ID FROM platform WHERE NAME = %s"
        cur.execute(query, platform_string)
        details = str(cur.fetchone())
        cur.close()
        if details:
            return jsonify(platform_string, details), 200
        else:
            return jsonify(platform_string, 'not found'), 404
    except Exception as error_msg:
        return {"message": str(error_msg)}, 504


@app.route('/api/v1/platform', methods=['POST'])
@auth.login_required
def add_platform() -> Tuple:
    """
    Add a new platform and return the id
    :return: a tuple consisting of the json response and a response code
    """
    try:
        data = request.get_json()
        db = mysql.connect()
        cur = db.cursor()
        cols = ','.join(data.keys())
        vals = ','.join('%s' for _ in data)
        query = f"INSERT INTO platform ({cols}) VALUES ({vals})"
        cur.execute(query, list(data.values()))
        query = f"SELECT id FROM platform WHERE "
        query += " AND ".join(f"{k}=%s" for k in data)
        cur.execute(query, list(data.values()))
        new_id = cur.fetchone()[0]
        db.commit()
        db.close()
        return {"new_id": new_id}, 201
    except Exception as error_msg:
        return {"message": str(error_msg)}, 504


def get_mysql_query(keys):
    with open('query.json', 'r') as file:
        value = json.loads(file.read())
        return str(value[keys])


'''
This function handles a POST request to add a new vulnerability check. 
It reads data from a JSON file, formats an SQL query, and inserts the data into the MySQL database while managing the session and transaction. 
It ensures proper handling of the request, and the data is inserted securely, avoiding foreign key issues by disabling checks during the process.
'''


@app.route('/api/v1/new_vuln/<item_id>', methods=['POST'])
@auth.login_required
def api_vuln_call_to_checkmate(item_id):
    logger.info(f"Attempting to add vulnerability check: {item_id}")
    db = mysql.connect()
    cur = db.cursor()
    try:
        cur.execute('SET autocommit=0;')
        cur.execute('set FOREIGN_KEY_CHECKS=0;')
        new_id = get_next_item_id()
        next_id_for_custom_revision_entity = get_next_id_for_custom_revision_entity()
        rev = get_rev_value()
        revend = 0
        res = request.get_json()
        test_id = get_xml_item_id()
        cur_mysql_user = get_current_MySQL_user()
        severity = res['severity']
        severity = conversion_to_int(severity)
        name_db = res['platform'].split(' ')[0]

        # Get non-fractional epoch timestamp (seconds only)
        epoch_time_int = int(time.time())

        # Get external reference link for cve details
        base_address = "http://cve.mitre.org/cgi-bin/cvename.cgi?name="
        cve_number = res['cve']
        address = f"{base_address}{cve_number}"

        item_cols = get_mysql_query("ITEM_QUERY_COLS")
        item_vals = get_mysql_query("ITEM_QUERY_VALS")
        item_query = f"insert into item {item_cols} values {item_vals}"

        item_aud_cols = get_mysql_query("ITEM_AUD_QUERY_COLS")
        item_aud_vals = get_mysql_query("ITEM_AUD_QUERY_VALS")
        item_aud_query = f"insert into item_aud {item_aud_cols} values {item_aud_vals}"

        item_xml_cols = get_mysql_query("ITEM_XML_QUERY_COLS")
        item_xml_vals = get_mysql_query("ITEM_XML_QUERY_VALS")
        xml_item_query = f"insert into xml_item {item_xml_cols} values {item_xml_vals}"

        item_xml_aud_cols = get_mysql_query("ITEM_XML_AUD_QUERY_COLS")
        item_xml_aud_vals = get_mysql_query("ITEM_XML_AUD_QUERY_VALS")
        xml_item_aud_query = f"insert into xml_item_aud {item_xml_aud_cols}"
        xml_item_aud_query += f" values {item_xml_aud_vals}"

        # Fill the following description table column values in this order:
        #   "long_description", "message", "short_description", "item"
        # "message" and "short_description" should be the same.
        description_query = get_mysql_query('description_query')

        # Fill the following description_aud table column values in this order:
        #   "rev", "long_description", "message", "short_description"
        # "message" and "short_description" should be the same.
        description_aud_query = get_mysql_query('description_aud_query')

        external_ref_cols = get_mysql_query("external_ref_query_cols")
        external_ref_vals = get_mysql_query("external_ref_query_values")
        external_ref_query = f"insert into external_ref {external_ref_cols} values {external_ref_vals}"

        external_ref_aud_cols = get_mysql_query("external_ref_aud_query_cols")
        external_ref_aud_values = get_mysql_query("external_ref_aud_query_values")
        external_ref_aud_query = f"insert into external_ref_aud {external_ref_aud_cols} values {external_ref_aud_values}"

        custom_revision_entity_cols = get_mysql_query("custom_revision_entity_query_cols")
        custom_revision_entity_values = get_mysql_query("custom_revision_entity_query_values")
        custom_revision_entity_query = f"insert into custom_revision_entity {custom_revision_entity_cols} values {custom_revision_entity_values}"

        if res['body'] != 'null':

            '''
            auto-incremented primary key
            (id, body, category, cve, encrypted, encryption, exclude_fromdss, exclude_fromdvm, item_id, legacy_lang, 
            legacy_version, name, obsolete, platforms, result_type, run_fix, severity, status, tags, type, version, query_rule)
            '''
            cur.execute(
                item_query,
                (
                    new_id, res['body'], res['cve'], res['item_id'],
                    res['name'], res['platform'], severity, res['tags']
                )
            )

            '''
            (id, rev, revtype, body, category, cve, encrypted, encryption, exclude_fromdss, exclude_fromdvm, item_id, 
            legacy_lang, legacy_version, name, obsolete, platforms, result_type, run_fix, severity, status, tags, type, query_rule)
            '''
            cur.execute(
                item_aud_query,
                (
                    new_id, rev, res['body'], res['cve'], res['item_id'],
                    res['name'], res['platform'], severity, res['tags']
                )
            )

            '''
            (id , version, xml, item)
            auto-incremented primary key
            '''
            cur.execute(
                xml_item_query,
                (test_id, res['item_id'], severity, res['platform'],
                 res['body'], res['long_description'], res['long_description'],
                 res['link'], name_db, res['cve'], res['cve'], res['cve'],
                 new_id)
            )

            '''
            (id, rev, revtype, xml, item)
            '''
            cur.execute(
                xml_item_aud_query,
                (test_id, rev, res['item_id'], severity, res['platform'],
                 res['body'], res['long_description'], res['long_description'],
                 res['link'], name_db, res['cve'], res['cve'], res['cve'],
                 new_id)
            )

            '''
            (id, locale, long_description, message, short_description, version, item)
            auto-incremented primary key
            '''
            cur.execute(
                description_query,
                (test_id, res['long_description'], res['name'], res['name'], new_id)
            )

            '''
            (id, rev, revtype, locale, long_description, message, short_description, item)
            '''
            cur.execute(
                description_aud_query,
                (test_id, rev, res['long_description'], res['name'], res['name'], new_id)
            )

            '''
            (id, address, locale, name, version, item)
            '''
            cur.execute(
                external_ref_query,
                (test_id, address, 'en', name_db, 0, new_id)
            )

            '''
            (id, rev, revtype, revend, address, locale, name, item)
            '''
            cur.execute(
                external_ref_aud_query,
                (test_id, rev, 0, revend, address, 'en', name_db, new_id)
            )

            '''
            (id, timestamp, modified_by)
            '''
            cur.execute(
                custom_revision_entity_query,
                (next_id_for_custom_revision_entity, epoch_time_int, cur_mysql_user)
            )

            db.commit()
        db.close()
        logger.info('insertion to db completed' + str(new_id))
        return jsonify('insertion to db completed', new_id), 200
    except Exception as e:
        logger.error(f"Failed to update the database for item {item_id}")
        logger.debug(f"Exception: {e}")
        # noinspection PyProtectedMember
        logger.debug(f"last query: {cur._last_executed}")
        db.rollback()
        db.close()
        return jsonify('insertion to db failed reason : Duplicate ID'), 504


@app.route('/api/v1/new_patch/<item_id>', methods=['POST'])
@auth.login_required
def api_patch_call_to_checkmate(item_id):
    db = mysql.connect()
    cur = db.cursor()
    try:
        rev = get_rev_value()
        res = request.get_json()
        query = get_mysql_query('patch_item_query').format(
            res['body'], res['name'], res['new_id'])
        query1 = get_mysql_query('patch_item_aud_query').format(
            res['new_id'], rev, res['body'], res['item_id'],
            res['name'], res['platform'], res['tag'])
        query2 = get_mysql_query('patch_item_xml_query').format(
            res['check'].replace('"', '\\"'), res['new_id'])
        query3 = get_mysql_query('patch_item_aud_xml_query').format(
            res['new_id'], rev, res['check'].replace('"', '\\"'), res['new_id'])

        cur.execute('set FOREIGN_KEY_CHECKS=0;')
        cur.execute('SET autocommit=0;')
        cur.execute(query)
        cur.execute(query1)
        cur.execute(query2)
        cur.execute(query3)
        db.commit()
        return jsonify('insertion to db completed', res['new_id']), 200
    except Exception as error_msg:
        db.rollback()
        cur.close()
        logger.error(f"failed to write to db: {error_msg}")
        logger.debug(f"item_id: {item_id}")
        return jsonify(f'insertion to db failed reason: {error_msg}'), 504


if __name__ == '__main__':
    app.run(debug=True)