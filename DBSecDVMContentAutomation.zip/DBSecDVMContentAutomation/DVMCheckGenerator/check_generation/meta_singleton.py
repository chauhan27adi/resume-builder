from typing import Dict


class SingletonDuplicationException(Exception):
	"""totes awky mo mo"""
	pass


class Singleton(type):
	"""
	Singleton metaclass to be used for singleton classes by
	way of the metaclass keyword argument in the class definition:
	e.g. class MyNewClass(superClass, metaclass=Singleton)
	"""
	_instances = {}

	def __call__(cls, *args, **kwargs) -> Dict:
		"""
		create an instance of the singleton class or raise exception
		:param args: any positional arguments to be passed to the class
		:param kwargs: any key word arguments to be passed to the class
		:return: the instances dict
		"""
		if cls not in cls._instances:
			cls._instances[cls] = super().__call__(*args, **kwargs)
		else:
			raise SingletonDuplicationException(
				f"You cannot create another {cls.__name__} class")
		return cls._instances[cls]