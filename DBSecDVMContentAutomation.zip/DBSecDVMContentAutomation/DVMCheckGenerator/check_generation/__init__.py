import logging
from typing import Sequence
from check_generation.vulnerabilities.check_generation_mssql_vulnerability import *


logging.getLogger("requests").setLevel(logging.ERROR)
logging.getLogger("urllib3").setLevel(logging.ERROR)
logging.getLogger("selenium").setLevel(logging.ERROR)


class CheckGenerator:
	logger = logging.getLogger('CheckGenerator')

	@classmethod
	def generate_checks(cls, dbs: Sequence, check_type: str) -> bool:
		"""
		Generate the certain checks for a list of DBMSs
		:param dbs: the list of DBMSs to generate checks for
		:param check_type: the type of checks to generate
		(i.e. patches or vulnerabilities)
		:return:
		"""
		results = []
		for db in dbs:
			result = False
			if "mssql" in db:
				if check_type.lower() == "patch":
					#result = CheckGeneratorMssqlPatch().generate()
					pass
				else:
					result = CheckGeneratorMssqlVuln().generate()
			else:
				cls.logger.error(f"Unsupported db type: {db}")
			results += [result]
		return all(results)