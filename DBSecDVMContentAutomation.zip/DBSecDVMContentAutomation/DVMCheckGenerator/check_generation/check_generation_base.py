import re
import json
import urllib
import logging
import requests
import configparser
import lxml.etree as xml_tree
from time import strptime
from xml.etree.ElementTree import tostring
from os.path import dirname, join

from bs4 import BeautifulSoup
from pymongo import MongoClient
from datetime import datetime
from typing import List, Iterable, Dict, Tuple
from xml.etree.ElementTree import Element, SubElement
from checkmate_client.validation.check_validation import CheckValidator
from checkmate_client.checkmate.checkmate import CheckmateUI


DEFAULT_MONGO_HOST = "localhost"
DEFAULT_MONGO_PORT = "27017"
DEFAULT_MONGO_DB = "admin"

PROTOCOLS = ["http", "https"]

MIN_EPO_VERSION = "5.0.0"
MAX_EPO_VERSION = "9999.9999.9999"

DEFAULT_CHECK_RULE = "YES_NO"
DEFAULT_CHECK_TYPE = "SINGLE"
DEFAULT_CHECK_ENCRYPTION = "N"

class CheckGeneratorBase:
	"""
	The base Check Generator class
	This should hold logic common to all check generation,
	Patches or Vulnerabilities
	"""
	def __init__(self, dbms: str) -> None:
		"""
		CheckGeneratorBase constructor
		read config file
		determine mongo connection details
		determine API details
		"""
		self.logger = logging.getLogger('CheckGenerator')
		self.__dbms = dbms
		self.__mongo = None
		self.__mongo_db_name = ""
		self.__api_url = ""
		self.__api_auth = tuple()
		self.__proxies = {protocol: "" for protocol in PROTOCOLS}

		# config details
		config_file_path = join(dirname(dirname(__file__)), "config.ini")
		self.config_parser = configparser.ConfigParser()
		self.config_parser.read(config_file_path)
		self.config_values_path = join(dirname(dirname(__file__)), 'check_generation_prod', 'resources')
		self._check_gen_source = self.config_parser.get('source', 'check_gen_source', fallback='mongodb')
		self._chunk_size = self.config_parser.getint('source', 'chunk_size', fallback=5)

		self.read_config_mongo()
		self.read_config_checkmate_api()
		if self.need_to_use_proxy():
			self.read_config_proxy()
			self.config_urlib_with_proxy()

	@property
	def records(self) -> List:
		"""
		getter for the records protected attribute
		:return: the records from the data source (MongoDB or SQLite)
		"""
		if self._check_gen_source == 'sqlite':
			return self.parse_sqlite_table(self.mongo_collection)
		return self.parse_mongo_collection(self.mongo_collection)

	@property
	def dbms(self):
		return self.__dbms

	@property
	def api_url(self):
		return self.__api_url

	def read_config_mongo(self) -> None:
		"""
		create an instance level mongo client from the config or defaults
		:return: None
		"""
		mongo_config = self.config_parser["mongo"]
		mongo_host = mongo_config.get("host", DEFAULT_MONGO_HOST)
		mongo_port = mongo_config.get("port", DEFAULT_MONGO_PORT)
		mongo_uri = f"mongodb://{mongo_host}:{mongo_port}/?"
		mongo_uri += f"readPreference=primary"
		mongo_uri += f"&appname=MongoDB%20Compass%20Community&"
		mongo_uri += f"ssl=false"
		self.__mongo = MongoClient(mongo_uri)
		self.__mongo_db_name = mongo_config.get("database", DEFAULT_MONGO_DB)

	def read_config_checkmate_api(self) -> None:
		"""
		set the checkmate API URL root credentials
		:return: None
		"""
		checkmate_api_config = self.config_parser["checkmate_api"]
		api_host = checkmate_api_config.get("host")
		api_port = checkmate_api_config.get("port")
		api_protocol = checkmate_api_config.get("protocol")
		api_username = checkmate_api_config.get("username")
		api_password = checkmate_api_config.get("password")
		self.__api_auth = (api_username, api_password)
		self.__api_url = f"{api_protocol}://{api_host}:{api_port}"

	def read_config_proxy(self) -> None:
		"""
		Read proxy detail from the config file to the private proxies attribute
		:return: None
		"""
		proxyData = self.config_parser["proxy_data"]
		self.__proxies = {
			protocol: f"{proxyData['url']}:{proxyData['port']}"
			for protocol in PROTOCOLS
		}

	def need_to_use_proxy(self) -> bool:
		"""
		Determine if a proxy is needed to make requests
		:return: a bool, true if needed else false
		"""
		try:
			kwargs = {
				"url": self.__api_url,
				"auth": self.__api_auth,
				"proxies": self.__proxies
			}
			requests.get(**kwargs)
			requests.post(**kwargs)
			return False
		except requests.exceptions.ProxyError:
			self.logger.debug("Configuring proxy")
			return True

	def config_urlib_with_proxy(self) -> None:
		"""
		Configure URL lib to use a proxy for connections
		:return: None
		"""
		self.logger.info(f"Configuring proxy for connection: {self.__proxies}")
		proxy = urllib.request.ProxyHandler(self.__proxies)
		opener = urllib.request.build_opener(proxy)
		urllib.request.install_opener(opener)

	def parse_mongo_collection(self, collection_name: str) -> List:
		"""
		parses from the "output_web_crawler_details" mongo database
		all records are parsed for the given db_name
		:param collection_name: the name of the collection to read from
		:return: a list of records from the DB collection
		"""
		try:
			db = self.__mongo.get_database(self.__mongo_db_name)
			collection = db[collection_name]
			return [record for record in collection.find()]
		except Exception as err:
			self.logger.exception(
				f"Unable to fetch from collection for {collection_name}: {err}")
		return []

	def parse_sqlite_table(self, table_name: str) -> List:
		"""
		parses all records from a SQLite table as an alternative to MongoDB
		:param table_name: the name of the SQLite table to read from
		:return: a list of records as dicts
		"""
		import sqlite3
		db_path = join(dirname(dirname(dirname(__file__))), 'DVMCrawler', 'cve_data.db')
		try:
			conn = sqlite3.connect(db_path)
			conn.row_factory = sqlite3.Row
			cursor = conn.cursor()
			cursor.execute(f"SELECT * FROM {table_name}")
			records = [dict(row) for row in cursor.fetchall()]
			conn.close()
			return records
		except Exception as err:
			self.logger.exception(
				f"Unable to fetch from SQLite table {table_name}: {err}")
			return []

	def delete_single_record_from_mongo_collection(
			self, collection_name: str, query: Dict) -> bool:
		"""
		Remove a single record from a collection in MongoDB based on the MongoDB
		query which look like a dictionary for collection filtering
		:param collection_name: a string, the name of the collection to remove
		from
		:param query: the dictionary-like filter to apply to the collection
		:return: a boolean, true if removed, else false
		"""
		try:
			self.logger.info(
				f"Deleting single item from MongoDB collection"
				f" '{collection_name}': {query}")
			db = self.__mongo.get_database(self.__mongo_db_name)
			collection = db[collection_name]
			return collection.delete_one(query)
		except Exception as err:
			self.logger.exception(
				f"Unable to delete single item from MongoDB: {err}")

	def read_from_json(self, key: str, file_path: str) -> str:
		"""
		read the value for a provided key in a provided json-formatted file
		:param key: the key to read from the json file
		:param file_path: the path of the json file
		:return: the value of the key in the json file
		"""
		try:
			with open(file_path, "r") as handle:
				value = json.loads(handle.read())
				return value[key]
		except Exception as err:
			self.logger.exception(
				f"Unable to fetch by key '{key}' from {file_path}: {err}")
		return ""

	def read_from_regex_values_file(self, key: str) -> str:
		"""
		:param key: the key to read from the json file
		:return: the value of the key in the json file
		"""
		file_path = join(self.config_values_path, "regex.json")
		return self.read_from_json(key, file_path)

	def read_from_static_values_file(self, key: str) -> str:
		"""
		:param key: the key to read from the json file
		:return: the value of the key in the json file
		"""
		file_path = join(self.config_values_path, "static_values.json")
		return self.read_from_json(key, file_path)

	def read_from_db_credential_values_file(self, key: str) -> str:
		"""
		:param key: the key to read from the json file
		:return: the value of the key in the json file
		"""
		file_path = join(self.config_values_path, "db_credential.json")
		return self.read_from_json(key, file_path)

	def checkmate_api_request(
			self, url: str, method: str = "get", **kwargs: Dict) -> Iterable:
		"""
		Make a request to the checkmate API
		"checkmate_post_request" or "checkmate_get_request"
		should be called instead if this method
		:param url: the API url for the request
		:param method: whether a get or post request is to be made
		:param kwargs: any keyword arguments to be passed with the request
		:return: Json response from API call
		"""
		if method.lower() == "get": method = requests.get
		elif method.lower() == "post": method = requests.post
		else:
			self.logger.error(f"Unsupported API method: {method}")
		try:
			resp = method(url, auth=self.__api_auth, **kwargs)
			useProxy = resp.status_code == 502
			if useProxy:
				kwargs["proxies"] = self.__proxies
				resp = method(url, auth=self.__api_auth, **kwargs)
		except requests.exceptions.ProxyError:
			kwargs["proxies"] = self.__proxies
			resp = method(url, auth=self.__api_auth, **kwargs)
		return resp.json()

	def checkmate_post_request(self, url: str, **kwargs: Dict) -> Iterable:
		"""
		Make a post request to the checkmate API
		:param url: the API url for the request
		:param kwargs: any keyword arguments to be passed with the request
		:return: Json response from API call
		"""
		return self.checkmate_api_request(url, "post", **kwargs)

	def checkmate_get_request(self, url: str, **kwargs: Dict) -> Iterable:
		"""
		Make a post request to the checkmate API
		:param url: the API url for the request
		:param kwargs: any keyword arguments to be passed with the request
		:return: Json response from API call
		"""
		return self.checkmate_api_request(url, "get", **kwargs)

	def get_tag_id_from_checkmate(self, tag_name: str, payload: Dict) -> str:
		"""
		Get the id of a tag from checkmate, given the tag name
		:param tag_name: the name of a tag e.g. MSSQL 2017
		:param payload: the payload of content to create the tag if absent
		:return: the id of the tag
		"""
		return self.set_tag_or_platform_id(tag_name, payload=payload)

	def get_platform_id_from_checkmate(
			self, platform_name: str, payload: Dict) -> str:
		"""
		Get the id of a platform from checkmate, given the platform name
		:param platform_name: the name of a platform e.g. MSSQL 2017
		:param payload: the payload of content to create the platform if absent
		:return: the id of the platform
		"""
		return self.set_tag_or_platform_id(
			platform_name, is_platform=True, payload=payload)

	def get_tag_or_platform_id(
			self, lookup_string: str, is_platform: bool = False) -> str:
		"""
		Retried a tag or platform ID from the relevant checkmate API call.
		"get_tag_id_from_checkmate" or "get_platform_id_from_checkmate"
		should be called in stead of this method
		:param lookup_string: the tag name or the platform name to look up
		:param is_platform: If this is a platform lookup (default=False)
		:return: string, the ID if found, or else an empty string
		"""
		# Check if the tag/platform exists and get it's ID
		endpoint = "platform" if is_platform else "tag"
		url = f"{self.__api_url}/api/v1/{endpoint}/{lookup_string}"
		resp_json = self.checkmate_api_request(url)
		# response will be like one of the following:
		#  ["<lookup_string>", "(<id>,)"]
		#  ["<lookup_string>", "None"]
		id_value = resp_json[1]
		if re.search("\d+", str(id_value)):
			return re.findall("\d+", id_value)[0]
		return ""

	def add_tag_or_platform(
			self, is_platform: bool = False, **kwargs: Dict) -> str:
		"""
		Create a new tag or platform in the checkmate backend
		:param is_platform: If this is a platform lookup (default=False)
		:param kwargs: any keyword arguments to pass to the checkmate API call
		:return: string, the ID of the new entry or else an empty string
		"""
		endpoint = "platform" if is_platform else "tag"
		url = f"{self.__api_url}/api/v1/{endpoint}"
		resp_json = self.checkmate_post_request(url, json=kwargs)
		return resp_json.get("new_id", "")

	def get_item_id(self, name: str, id_prefix: str) -> str:
		"""
		Return an item_id if it exists, otherwise return the next available
		This will not create any new rows in the database
		:param name: the name of the item as it appears in checkmate
		:param id_prefix: the item_id prefix (e.g. MSPATCH, MSVULN, etc.)
		:return: string, the item_id (existing or new)
		"""
		url = f"{self.__api_url}/api/v1/item"
		payload = {"name": name, "id_prefix": id_prefix}
		resp_json = self.checkmate_get_request(url, json=payload)
		return resp_json.get("item_id")

	def set_tag_or_platform_id(
			self, name: str, is_platform: bool = False,
			payload: (Dict, None) = None
	) -> str:
		"""
		Get the ID for a tag or platform from the checkmate DB.
		If the tag or platform does not exist, create it and return the ID
		of the same
		:param name: the name of the tag or platform as it appears in the DB
		:param is_platform: boolean if this is a platform lookup or not
		:param payload: payload to be used to write to the tag/platform table
		:return:
		"""
		if payload is None: payload = dict()
		output_id = self.get_tag_or_platform_id(name, is_platform=is_platform)
		if not output_id and name.lower() not in ["patches", "vulnerabilities"]:
			# if it doesn't exist, create a new entry and return it's ID
			output_id = self.add_tag_or_platform(is_platform, **payload)
		return output_id

	@staticmethod
	def create_generic_xml_check() -> Element:
		"""
		Generate a generic check without the DBMS specific values
		Also omit, patch-specific and vulnerability-specific check content
		:return: the generalised Element (Element type)
		"""
		# The name and the priority will be added to this tag later
		check_xml_root = Element("vatest")
		# add the static elements - these do not change on a DBMS basis
		# add empty elements
		SubElement(check_xml_root, "parameters")
		SubElement(check_xml_root, "minversion")
		# add empty elements with attributes
		SubElement(check_xml_root, "sqlfix", {"querySqlfix": "false"})
		# add other static elements
		alertOnEmpty = SubElement(check_xml_root, "alertOnEmpty")
		alertOnEmpty.text = "false"
		epoMinversion = SubElement(check_xml_root, "epoMinversion")
		epoMinversion.text = MIN_EPO_VERSION
		epoMaxversion = SubElement(check_xml_root, "epoMaxversion")
		epoMaxversion.text = MAX_EPO_VERSION
		return check_xml_root

	def does_check_exist(self, check: Element) -> Tuple[bool, int]:
		"""
		Check if a check exists by checking for the item_id in the item
		and item_aud tables
		Invalid results are
		- where ID in item is not equal to the ID in item_aud
		- where the IDs are "-1" indicates API did not find a row by item_id
		:param check: an XML check of type Element
		:return: a tuple, a boolean "exists" and a dictionary of the
		discovered IDs
		"""
		item_id = check.get("name")
		output_dict = dict()
		for suffix in ["", "_aud"]:
			url = f"{self.__api_url}/api/v1/item{suffix}/{item_id}"
			resp_json = self.checkmate_api_request(url)
			if resp_json:
				ids = [i.get("id", -1) for i in resp_json["items"]]
				max_id = -1 if not len(ids) else max(ids)
				output_dict[f"item{suffix}_table_id"] = max_id
		# ensure ids are the same
		are_ids_identical = len(set(output_dict.values())) == 1
		# ensure ids are not == -1
		are_ids_valid = list(set(output_dict.values()))[0] != -1
		exists = are_ids_identical and are_ids_valid
		return exists, list(set(output_dict.values()))[0]

	@staticmethod
	def validate_check(check: Element, checkType: str) -> tuple:
		"""
		A validation to see if the check was generated correctly
		:param check: the xml check to validate
		:param checkType: the type of check, either "patch", "vulnerability"
		:return: a boolean, whether the check was valid or not
		"""
		validator = CheckValidator(check, checkType)
		return validator.validate(), validator.reason

	@staticmethod
	def fill_mail_body_csv_file(check):
		name = check.find("hhName")
		cve_no = ""
		if "cve" in name.text.lower():
			ext_ref_name = f"{name.text.split()[-1]}"
			cve_no = ext_ref_name
		timestamp = datetime.now()
		with open(join(dirname(dirname(__file__)), 'check_generation_prod', 'resources', 'mail_body.csv'), 'a') as file:
			file.write(
				f'\n\tDatabase : "MSSQL" , status : "success", cve/patch_id : {cve_no}, timestamp: {timestamp}')

	def write_check_to_checkmate(self, check: Element) -> bool:
		"""
		Write/update a check in checkmate
		:param check: the XML check to write
		:return: a boolean, whether the write was a success or not
		"""
		check_exists, _ = self.does_check_exist(check)
		platforms = self.get_platform_ids(check)
		tags = self.get_tag_ids(check)
		checkmate = CheckmateUI()
		if check_exists:
			self.logger.info("Updating existing check")
			opened = checkmate.open_page("List all Checks", "List all Checks")
			if opened:
				checkmate.open_check_for_update(
					check_name=check.get("name"), itemId=check.get("name"))
			else:
				self.logger.error(
					"Unable to confirm CheckMate page opened, either rerun "
					"automation or add the check manually.")
		else:
			self.logger.info("Creating new check")
			checkmate.open_page("Create new Check", "Check")
		# The approach here is that all checks will get updated/added even if
		# the same content is already there.  This is not ideal but as the
		# CheckMate application is so slow, to check the content of the checks
		# first would take longer than to just update them with the latest
		# scraped content
		checkmate.fill_check_fields(
			check, tags_ids=tags, platforms_ids=platforms)
		result = checkmate.save()
		if result and not check_exists:
			self.fill_mail_body_csv_file(check)
		checkmate.cleanup()
		return result

    # @classmethod
	# def format_severity(cls, priority):
	#     try:
	#         severity = re.findall(cls.get_regex_values("check_gen_base_severity"), priority)
	#         return severity[0].upper() + ''.join(severity[1:]).lower()
	#     except ValueError as Ve:
	#         self.logger.exception("Severity parameter should be string", + str(Ve))

	# @staticmethod
	# def check_for_success(item):
	#     if type(item) is dict:
	#         if 'success' in list(item.values()):
	#             if item['security_fixes'] == 'Patch':
	#                 return f'{item["name"]} : {item["current_patch_version"]} All ready generated', True
	#             else:
	#                 return f'{item["name"]} : {item["cve_no"]} All ready generated', True
	#         else:
	#             return item, False

	# def convert_nearest_tens(self, x: int):
	#     try:
	#         if x % 10 == 0:
	#             return str(x).zfill(3)
	#         else:
	#             if x < 10:
	#                 return str(0).zfill(3)
	#             else:
	#                 x = x // 10
	#                 x = x * 10
	#                 return str(x).zfill(3)
	#     except (AttributeError, ValueError) as Ae:
	#         self.logger.exception("Value of 'x' should be integer" + str(Ae))

	# def parse_xml_template(self, path_to_file):
	#     try:
	#         my_tree = ET.parse(path_to_file)
	#         my_root = my_tree.getroot()
	#         return my_root
	#     except (ET.ParseError, Exception) as Pe:
	#         self.logger.exception("Invalid Xml" + str(Pe))

	# @classmethod
	# def get_test_id_from_checkmate_db(cls, search_key):
	#     try:
	#         with open('CheckGeneration_Prod/Mail_Properties/db_credential.json', 'r') as file:
	#             db_cred = json.loads(file.read())
	#             mydb = mysql.connector.connect(
	#                 host=db_cred['uri'],
	#                 user=db_cred['user'],
	#                 password=db_cred['password'],
	#                 database=db_cred['database'],
	#                 port=db_cred['port']
	#             )
	#             my_cursor = mydb.cursor()
	#
	#             query = "SELECT item_id FROM item where item_id like '{0}%' order by id desc limit 1;".format(
	#                 search_key)
	#
	#             my_cursor.execute(query)
	#             my_result = list(my_cursor.fetchone())[0]
	#
	#             if 'DB2' in str(my_result):
	#                 my_result = str(re.findall(cls.get_regex_values("check_gen_base_get_id_db2"), my_result)[0])
	#                 my_cursor.close()
	#                 return search_key + str(int(my_result) + 1)
	#
	#             elif search_key == 'SYVULN':
	#                 query_Query = "select body from item where body like '%sybase%' order by id desc limit 1;"
	#                 my_cursor.execute(query_Query)
	#                 base_query = my_cursor.fetchone()[0]
	#                 my_result = str(re.findall(r'\d+', my_result)[0])
	#                 my_cursor.close()
	#                 return search_key + str(int(my_result) + 1).zfill(3), base_query
	#
	#             else:
	#                 my_result = str(re.findall(r'\d+', my_result)[0])
	#                 my_cursor.close()
	#                 return search_key+str(int(my_result)+1)
	#
	#     except IndexError as Ie:
	#         self.logger.exception(str(Ie))
	#     except AttributeError as Ae:
	#         self.logger.exception("ID search key should be String" + str(Ae))
	#     except (ConnectionError, Exception) as Ce:
	#         self.logger.exception("Connection to Mysql was failed", str(Ce))

	# @staticmethod
	# def xml_update_with_tags(tag, my_root, values, status_flag):
	#     try:
	#         if not status_flag and tag not in ['Platforms', 'Tags']:
	#             for tests in my_root.iter(tag):
	#                 tests.text = str(values)
	#                 tests.set('updated', 'no')
	#                 del tests.attrib["updated"]
	#                 # return tests
	#         elif not status_flag and tag in ['Platforms', 'Tags']:
	#             for plat in my_root.findall(tag)[-1]:
	#                 for val in plat.iter('Value'):
	#                     val.text = values
	#                     val.set('updated', 'yes')
	#                     del val.attrib["updated"]
	#                     # return val
	#     except (NameError, TypeError) as Ne:
	#         self.logger.exception("Tag is not getting any value to set" + str(Ne))

	# def set_tags_in_checks(self, query, item_id, my_root, item, status, affected_version):
	#     # not ideal to lump it in here but this will get the DBMS
	#     # in the correct format for the platform and Tag elements
	#     dbms = item.get("name", "")
	#     if dbms.startswith("db"): dbms = "DB2"
	#     elif dbms.startswith("maria"): dbms = "MariaDB"
	#     elif dbms.startswith("mssql"): dbms = "MSSQL"
	#     elif dbms.startswith("mysql"): dbms = "MySQL"
	#     elif dbms.startswith("oracle"): dbms = "Oracle"
	#     elif dbms.startswith("hana"): dbms = "SAP HANA"
	#     elif dbms.startswith("post"): dbms = "PGSQL"
	#     if isinstance(affected_version, str):
	#         affected_version = f"{dbms} {affected_version}"
	#     elif isinstance(affected_version, list):
	#         affected_version = [f"{dbms} {i}" for i in affected_version]
	#
	#     try:
	#         self.xml_update_with_tags('ID', my_root, item_id, status)
	#         self.xml_update_with_tags('Test_x0020_Name', my_root, 'Vulnerability to ' + str(item['cve_no']), status)
	#         self.xml_update_with_tags('Severity', my_root, self.format_severity(str(item['severity'])), status)
	#         self.xml_update_with_tags('Query', my_root, query, status)
	#         for tags in ['Short_x0020_Description', 'Long_x0020_Description', 'message']:
	#             self.xml_update_with_tags(tags, my_root, item['long_description'], status)
	#         self.xml_update_with_tags('LINKS', my_root, item['link'], status)
	#         self.xml_update_with_tags('CVE', my_root, item['cve_no'], status)
	#         if item['name'] not in ['hanadb', 'mssqldb', 'sybasedb', 'oracledb']:
	#             self.xml_update_with_tags('Platforms', my_root, affected_version, status)
	#             self.xml_update_with_tags('Tags', my_root, affected_version, status)
	#         if item['name'] in ['mssqldb', 'sybasedb']:
	#             list_years = sorted(affected_version)
	#             set_tag = self.setting_tag_in_xml(my_root, list_years, status, len(list_years))
	#             # set_platform = self.base_class_obj.platform_set_xml(myroot, list_years)
	#             my_root = set_tag
	#             if not isinstance(my_root, ET.Element):
	#                 raise Exception("Failed to generate affected version tags")
	#             self.set_platform_with_multiple_values(my_root, list_years)
	#             self.set_tag_with_multiple_values(my_root, list_years)
	#             # update_tags = self.base_class_obj.set_tag_in_sybase(my_root, list_years)
	#         xml = ET.tostring(my_root, encoding="unicode")
	#         obj = XmlValueValidation(xml)
	#         if obj.validation_result == 'valid':
	#             self.write_vulnerability_check_to_checkmate(query, affected_version, item, item_id)
	#             return my_root, 200
	#         else:
	#             self.logger.error("Validation failed for cve no {0}".format(item['cve_no']))
	#             return my_root, 201
	#
	#     except (AttributeError, IndexError, NameError, ET.ParseError) as Ae:
	#         self.logger.exception("Error while setting xml tags for details " + str(Ae) + " " + str(201))
	#         return 'Failed to generate check', 201
	#     except Exception as e:
	#         self.logger.exception("Error while setting xml tags for details " + str(e) + " " + str(201))
	#         return 'Failed to generate check', 201

	# @classmethod
	# def get_query_general_db(cls, affected_ver, item):
	#     try:
	#         if item['name'] == 'mariadb':
	#             query = cls.get_static_values('maria_query').format(
	#                 item['cve_no'], ''.join(affected_ver.split('.')))
	#             return query, item['affected_version']
	#
	#         elif item['name'] == 'mysqldb':
	#             fixed_version = affected_ver.split('.')[-1]
	#             query = cls.get_static_values('mysql_query').format(
	#                 item['cve_no'], fixed_version)
	#             return query, item['affected_version']
	#
	#         elif item['name'] == 'postgredb':
	#             ver = re.findall(cls.get_regex_values("postgre_vuln_affected_version"), affected_ver)[0]
	#             if ver:
	#                 static_name = f"postgre_{ver.replace('.', '_')}_query"
	#                 query = cls.get_static_values(static_name)
	#                 query = query.format(item['cve_no'], affected_ver.split(".")[0])
	#                 return query, str(re.findall(cls.get_regex_values("postgre_vuln_affected_version"), ver)[0])
	#     except IndexError as Ie:
	#         cls.logger.exception("Failed to get the query" + str(Ie))
	#     except TypeError as Te:
	#         cls.logger.exception("Mismatch of Type" + str(Te))
	#     except AttributeError as Ae:
	#         cls.logger.exception(
	#             "Affected version should be list or string and item should be dictionary" + str(Ae))

	# @classmethod
	# def get_query_db2(cls, cve, affected_version):
	#     try:
	#         fixed_pack = str(affected_version[0]).split(' ')[-1]
	#         if re.findall(r'\d+', fixed_pack):
	#             fixed_pack = re.findall(r'\d+', fixed_pack)[0]
	#         build_lvl = 'special_' + str(affected_version[-1]).split(' ')[-1]
	#         if re.match(r'^V9.7', affected_version[0]):
	#             query = cls.get_static_values('db2_9_7_query').format(
	#                 cve, build_lvl, fixed_pack)
	#             return query, '9.7'
	#         elif re.match(r'^V10.1', affected_version[0]):
	#             query = cls.get_static_values('db2_10_1_query').format(
	#                 cve, build_lvl, fixed_pack)
	#             return query, '10.1'
	#         elif re.match(r'^V10.5', affected_version[0]):
	#             query = cls.get_static_values('db2_10_5_query').format(
	#                 cve, build_lvl, fixed_pack)
	#             return query, '10.5'
	#         elif re.match(r'^V11.1', affected_version[0]):
	#             query = cls.get_static_values('db2_11_1_query').format(
	#                 cve, fixed_pack, build_lvl)
	#             return query, '11.1'
	#         else:
	#             query = 'null'
	#             return query, 'null'
	#
	#     except (IndexError, AttributeError, NameError) as Ie:
	#         cls.logger.exception(str(Ie))
	#
	# @staticmethod
	# def db2_get_version_list(affected_version):
	#     try:
	#         index = 2
	#         new_list = [
	#             affected_version[i * index:(i + 1) * index] for i in range((len(affected_version) + index - 1) //
	#                                                                        index)
	#         ]
	#         return new_list
	#     except AttributeError as Ae:
	#         self.logger.exception("Affected version should be list" + str(Ae))
	#
	# @classmethod
	# def get_query_mssql(cls, affected_versions, query_mssql):
	#     try:
	#         query_list = []
	#         year = []
	#         for affected in affected_versions:
	#
	#             split_value = affected[2].split('-')
	#             val1, val2 = split_value[0].split('.')[-2], split_value[1].split('.')[-2]
	#             val3 = re.findall(cls.get_regex_values("mssql_chk_gen_base_query_gen"), affected[-1])[0]
	#             for mssql_year in cls.get_regex_values("mssql_list_year"):
	#                 if mssql_year in affected[1]:
	#                     query_string = cls.get_static_values(f'mssql_{mssql_year}').format(val1, val2, val3)
	#                     year.append(mssql_year)
	#                     query_list.append(query_string)
	#         subquery = "\n or ".join(query_list)
	#         year = list(set(year))
	#         return query_mssql + subquery, year
	#     except (IndexError, AttributeError) as Ie:
	#         cls.logger.exception(str(Ie))
	#
	# @classmethod
	# def set_tag_with_multiple_values(cls, my_roots, affected):
	#     try:
	#         my_root = None
	#         count = 0
	#         for my_root in my_roots.findall('Tags')[1:]:
	#             new = ET.SubElement(my_root, 'Value')
	#             new.text = affected[count]
	#             count = count + 1
	#         return my_root
	#     except AttributeError as Ae:
	#         cls.logger.exception(str(Ae))

	# @staticmethod
	# def setting_tag_in_xml(myroots, values, status_flag, no_of_values_in_tag):
	#     try:
	#         value_in_xml = None
	#         myroots = ET.tostring(myroots)
	#         val = xml_tree.fromstring(myroots)
	#         myroot = val
	#         for i in range(no_of_values_in_tag):
	#             myroot.insert(8 + i, xml_tree.Element("Platforms"))
	#
	#             myroot.insert(10 + i, xml_tree.Element("Tags"))
	#             convert_lxml = (xml_tree.tostring(myroot))
	#             value_in_xml = ET.fromstring(convert_lxml)
	#         return value_in_xml
	#     except (AttributeError, TypeError, ET.ParseError) as err:
	#         self.logger.exception(str(err))

	# @staticmethod
	# def set_platform_with_multiple_values(my_roots, affected):
	#     my_root = None
	#     count = 0
	#     for my_root in my_roots.iter('Platforms'):
	#         new = ET.SubElement(my_root, 'Value')
	#         new.text = affected[count]
	#         count = count + 1
	#     return my_root

	# @staticmethod
	# def sub_query_construct_15_7(affected_versions, query):
	#     try:
	#         for affected_version in affected_versions:
	#             affected_version = affected_version.strip('SAP').split(' ')[1:]
	#             flag = all(x in affected_version for x in ['SP', 'CE', 'HF1', '15.7'])
	#             flag1 = all(x in affected_version for x in ['SP', 'CE', '15.7'])
	#             flag2 = all(x in affected_version for x in ['SP', 'HF1', '15.7'])
	#             if flag:
	#
	#                 sub_query = " or \ncharindex('{0}{1} {2}',@@version) > 0 and charindex('{3}',@@version)".format(
	#                     affected_version[2],
	#                     affected_version[3], affected_version[4], affected_version[5])
	#                 query = query + sub_query
	#             elif flag1:
	#                 sub_query = " or \ncharindex('{0}{1} {2}',@@version) > 0".format(
	#                     affected_version[2], affected_version[3], affected_version[4]
	#                 )
	#                 query = query + sub_query
	#
	#             elif flag2:
	#                 sub_query = " and charindex('{0}',@@version) ".format(
	#                     affected_version[-1]
	#                 )
	#                 query = query + sub_query
	#
	#             return query
	#     except (IndexError, AttributeError, NameError) as err:
	#         self.logger.exception("Unable to construct query 15.7 " + str(err))
	#
	# @staticmethod
	# def sub_query_construct_16_sp03(affected_versions, query):
	#     try:
	#         query = query.split("))\n    )\n)\nthen 0 else 1 end  as result")[0]
	#         for affected_version in affected_versions:
	#             affected_version = affected_version.strip('SAP').split(' ')[1:]
	#             if 'SP03' in affected_version and re.findall(r'PL\d+', str(affected_version)) and re.findall(r'HF\d+',
	#                                                                                                          str(
	#                                                                                                                  affected_version)):
	#                 sub_query = "\ncharindex('{0}',@@version)> 0 and charindex('{1}',@@version) = 0 ) or".format(
	#                     affected_version[3], affected_version[4]
	#                 )
	#                 query = query + sub_query
	#
	#             elif 'SP03' in affected_version:
	#                 sub_query = "charindex('0',@@version)> 0 or".format(affected_version[3])
	#                 query = query + sub_query
	#
	#         return query + "))\n    )\n)\nthen 0 else 1 end  as result"
	#     except (IndexError, AttributeError, NameError) as err:
	#         self.logger.exception("Unable to construct query 16_sp03 " + str(err))
	#
	# @staticmethod
	# def sub_query_construct_16_sp02(affected_versions, query):
	#     try:
	#         for affected_version in affected_versions:
	#             affected_version = affected_version.strip('SAP').split(' ')[1:]
	#
	#             if 'SP02' in affected_version and re.findall(
	#                     r'PL\d+', str(affected_version)) and re.findall(r'HF\d+', str(affected_version)):
	#
	#                 sub_query = "\ncharindex('{0}',@@version)> 0 and charindex('{1}',@@version) = 0 ) or".format(
	#                     affected_version[3], affected_version[4]
	#                 )
	#                 query = query + sub_query
	#
	#             elif 'SP02' in affected_version:
	#                 sub_query = "charindex('0',@@version)> 0 or".format(affected_version[3])
	#                 query = query + sub_query
	#
	#         return query
	#     except (IndexError, AttributeError, NameError) as err:
	#         self.logger.exception("Unable to construct query 16_sp02 " + str(err))
	#
	# def query_construct(self, previous_query, item):
	#     try:
	#         query_15_7 = previous_query.split('  \n        )\n)\nor')[0]
	#         query_15_7 = self.sub_query_construct_15_7(item['affected_version'], query_15_7)
	#         query_16_0 = (previous_query.split('  \n        )\n)\nor')[1]).split("(charindex('SP03',@@version)> 0")
	#         query_16_0_sp03 = "(charindex('SP03',@@version)> 0" + query_16_0[1]
	#         query_16_0_sp02 = query_16_0[0]
	#         query_16_0_sp03 = self.sub_query_construct_16_sp03(item['affected_version'], query_16_0_sp03)
	#         query_16_0_sp02 = self.sub_query_construct_16_sp02(item['affected_version'], query_16_0_sp02)
	#         consolidated_query = query_15_7 + "  \n        )\n)\nor" + query_16_0_sp02 + '\n' + query_16_0_sp03
	#         return re.sub("\'", "\\'", consolidated_query)
	#
	#     except (IndexError, AttributeError, NameError, TypeError) as err:
	#         self.logger.exception("Unable to construct query sybase " + str(err))
	
    # def get_hana_query(self, affected_version):
	#     try:
	#         index = 3
	#         newlist = [affected_version[i * index:(i + 1) * index] for i in
	#                    range((len(affected_version) + index - 1) // index)]
	#         newlist = sorted(newlist)
	#         if newlist:
	#             nested_list = newlist[0]
	#             first_val = re.findall(r'[1-9]+', nested_list[0])[0]
	#             second_val = re.findall(r'\d+', nested_list[1])[0]
	#             third_val = re.findall(r'[1-9]+', nested_list[2])[0]
	#             fouth_value = self.convert_nearest_tens(int(second_val))
	#             if third_val == '':
	#                 third_val = '00'
	#             query = self.get_static_values('hana_base_query').format(
	#                 first_val, second_val, third_val, fouth_value)
	#             newlist.pop(0)
	#             len_of_newlist = len(newlist)
	#             for _ in range(len_of_newlist + 1):
	#                 if newlist:
	#                     nested_list = newlist[0]
	#                     first_val = re.findall(r'[1-9]+', nested_list[0])[0]
	#                     second_val = re.findall(r'\d+', nested_list[1])[0]
	#                     third_val = re.findall(self.get_regex_values("hana_chk_gen_base_val3"), nested_list[2])[0]
	#                     fouth_value = self.convert_nearest_tens(int(second_val))
	#                     query = query + self.get_static_values('hana_incr_query').format(
	#                         first_val, second_val, third_val, fouth_value)
	#                     newlist.pop(0)
	#                 else:
	#                     return query
	#     except (IndexError, AttributeError, NameError) as err:
	#         self.logger.exception("Unable to get Hana query " + str(err))

	# @staticmethod
	# def construct_platform(affected, name):
	#     temp_list = []
	#     if name == 'mariadb':
	#         return 'MariaDB ' + affected
	#     elif name == 'postgredb':
	#         return affected
	#     elif name == 'mysqldb':
	#         return 'MySQL ' + affected
	#     elif name == 'db2db':
	#         return 'DB2 ' + affected
	#     elif name == 'sybasedb':
	#         for affected_ver in affected:
	#             temp_list.append('Sybase ' + affected_ver)
	#         return ';'.join(temp_list)
	#     elif name == 'mssqldb':
	#         for affected_ver in affected:
	#             temp_list.append('MSSQL ' + affected_ver)
	#         return ';'.join(temp_list)
	#     else:
	#         return 'ALL SAP HANA'

	# def write_vulnerability_check_to_checkmate(self, query, affected_version, item, item_id):
	#     try:
	#         # its ok to hard code the "Vulnerabilities" tag here as this method
	#         # is specific to vulnerability check generation
	#         tags = [affected_version, "Vulnerabilities"]
	#         tags = ",".join(self.get_tag_or_platform_id(t) for t in tags)
	#         platform = self.construct_platform(affected_version, item["name"])
	#         platform = self.get_tag_or_platform_id(platform, True)
	#         url = f"{self.api_url}/api/v1/new_vuln/{item_id}"
	#         create_row_data = {
	#             'body': query,
	#             'cve': item['cve_no'],
	#             'item_id': item_id,
	#             'name': 'Vulnerability to ' + item['cve_no'],
	#             'platform': platform,
	#             'severity': item['severity'],
	#             'long_description': item['long_description'],
	#             'link': item['link'],
	#             'tags': tags
	#         }
	#         self.logger.info(
	#             f"Check {item_id} successfully generated for {item['cve_no']}")
	#         try:
	#             response = requests.post(
	#                 url=url, json=create_row_data, auth=self.api_auth,
	#             )
	#             if response.status_code == 200:
	#                 self.logger.info(f"Written {item_id} to checkmate")
	#                 self.append_db_with_check_generation_status(
	#                     'success', datetime.now(),
	#                     item['cve_no'], item['name'], 'cve_no'
	#                 )
	#                 self.update_log_file_with_check(item, "success")
	#             else:
	#                 self.update_log_file_with_check(item, response.status_code)
	#                 self.logger.error(f"Unable to write {item_id} to checkmate")
	#                 self.logger.debug(f"Status: {response.status_code}")
	#         except requests.exceptions.ConnectionError as err:
	#             self.logger.error(
	#                 f"Unable to write to checkmate: ConnectionError ({err})")
	#     except (IndexError, AttributeError, NameError, ValueError) as e:
	#         self.logger.exception(f"Unable to write to checkmate: {e}")
	#
	# def write_patch_check_to_checkmate(self, check, severity, new_id, platform, tag, version, item):
	#     try:
	#         body = self.get_patch_query('query', check)
	#         name = self.get_patch_query('hhmessage', check)
	#         if item['name'] == 'db2_patch':
	#             item_id = re.findall(self.get_regex_values("db2_checkmate_vuln_id"), str(check))[0]
	#         else:
	#             item_id = re.findall(self.get_regex_values("db2_checkmate_patch_id"), str(check))[0]
	#         create_row_data = {
	#             'body': body, 'item_id': item_id, 'name': name,
	#             'platform': platform, 'severity': severity, 'new_id': new_id,
	#             'tag': tag, 'version': version, 'check': check
	#         }
	#
	#         url = f"{self.api_url}/api/v1/new_patch/{item_id}"
	#         try:
	#             response = requests.post(
	#                 url=url, json=create_row_data, auth=self.api_auth,
	#             )
	#
	#             if response.status_code == 200:
	#                 self.logger.info("Patch Check successfully generated for {0} : status: {1}".format(
	#                     item_id, response.status_code))
	#                 self.append_db_with_check_generation_status(
	#                     'success', datetime.now(), item['current_patch_version'], item['name'], 'current_patch_version')
	#             else:
	#                 self.update_log_file_with_check(item_id, response.status_code)
	#                 self.logger.exception(
	#                     '''Check Generated with {0} but unable
	#                     to write to checkmate : Satus :{1}'''.format(item_id, response.status_code))
	#         except requests.exceptions.ConnectionError as err:
	#             self.logger.error(f"Unable to write to checkmate: ConnectionError ({err})")
	#     except (ConnectionError, ConnectionRefusedError) as Ce:
	#         self.logger.exception("Checkmate api may not be running: " + str(Ce))
	#     except (IndexError, AttributeError, NameError) as e:
	#         self.logger.exception("Unable to write to checkmate database: " + str(e))
	#     except Exception as e:
	#         self.logger.exception(f"Generic Exception caught: {e}")

	# @staticmethod
	# def get_patch_query(tag, check):
	#     check = ET.fromstring(check)
	#     for value in check.iter(tag):
	#         return value.text
	#
	# @staticmethod
	# def update_log_file_with_check(item, status):
	#     timestamp = datetime.now()
	#     with open('CheckGeneration_Prod/Mail_Properties/mail_body.csv', 'a') as file:
	#         file.write(f'\n\tDatabase : {item["name"]} , status : {status}, cve/patch_id : {item["cve_no"]}, timestamp: {timestamp}')
	#
	# def append_db_with_check_generation_status(self, status, check_generation_timestamp, unique_id_value, name,
	#                                            unique_id):
	#     try:
	#         client = MongoClient(self.get_mongo_uri('mongo_db_uri'))
	#         db = client.output_web_crawler_details
	#         coll_name = db[name]
	#         for x in coll_name.find({f"{unique_id}": unique_id_value}):
	#             filter_db = {f'{unique_id}': unique_id_value}
	#             set_query_status = {"$set": {"Progress": status}}
	#             coll_name.update_one(filter_db, set_query_status)
	#             set_query_generated_timestamp = {"$set": {"TimeStamp_for_Check_generation": check_generation_timestamp}}
	#             coll_name.update_one(filter_db, set_query_generated_timestamp)
	#             self.logger.info("Mongo DB updated")
	#     except ConnectionError as Ce:
	#         self.logger.exception("Update of Mongodb with success response failed due to Connection error" + str(Ce))

	# @classmethod
	# def oracle_set_id(cls, item, version):
	#     try:
	#         link_to_id = str(item['link'].split('/')[-1]).split('.')
	#         if version == 12 and re.findall(cls.get_regex_values("oracle_vuln_ver11_2"), item['affected_version']):
	#             first_part_id = 'ORA' + link_to_id[0].upper() + '_DB' + str(item['count']).zfill(2) + '_SP'
	#             return first_part_id
	#         elif version == 12 and not re.findall(cls.get_regex_values("oracle_vuln_ver11_2"), item['affected_version']):
	#             first_part_id = 'ORA' + link_to_id[0].upper() + '_DB' + str(item['count']).zfill(2) + '_SP'
	#             return first_part_id
	#         elif version == 11:
	#             first_part_id = 'ORA' + link_to_id[0].upper() + '_DB' + str(item['count']).zfill(2)
	#             return first_part_id
	#     except IndexError as Ie:
	#         self.logger.exception(f"Id generation of oracle failed {item['cve_no']}" + str(Ie))
	#     except AttributeError as Ae:
	#         self.logger.exception(f"Id generation of oracle failed {item['cve_no']}" + str(Ae))
	#
	# def oracle_java_vm_processing(self, affected_version, item):
	#     try:
	#         list_11 = []
	#         list_12 = []
	#         for split_version in affected_version:
	#             if '11' in split_version:
	#                 list_11.append(split_version)
	#             elif '12' in split_version:
	#                 list_12.append(split_version)
	#
	#         list_12 = list(set(list_12))
	#         list_11 = list(set(list_11))
	#         if list_12:
	#             new_id = self.oracle_set_id(item, 12)
	#             query_12, length = self.set_query_jvm(new_id, item['cve_no'], list_12, item['initial_mod_date'])
	#             return query_12, new_id, length, '12'
	#
	#         if list_11:
	#             new_id = self.oracle_set_id(item, 11)
	#             query_11, length = self.set_query_jvm(new_id, item['cve_no'], list_11, item['initial_mod_date'])
	#             return query_11, new_id, length, '11'
	#     except IndexError as Ie:
	#         self.logger.exception("Affected version" + str(Ie))
	#     except AttributeError as Ae:
	#         self.logger.exception("Expect Affected as list and item as dictionary"+str(Ae))
	#
	# def oracle_no_java_vm_processing(self, affected_version, item):
	#     try:
	#         list_11 = []
	#         list_12 = []
	#         for split_version in affected_version:
	#             if '11' in split_version:
	#                 list_11.append(split_version)
	#             elif '12' in split_version:
	#
	#                 list_12.append(split_version)
	#         list_12 = list(set(list_12))
	#         list_11 = list(set(list_11))
	#
	#         if list_12:
	#             new_id = self.oracle_set_id(item, 12)
	#             query_12, length = self.set_query_no_jvm_12(item['cve_no'], list_12, item['initial_mod_date'], new_id)
	#             return query_12, new_id, length, '12'
	#         if list_11:
	#             new_id = self.oracle_set_id(item, 11)
	#             query_11, length = self.set_query_no_jvm_11(item['cve_no'], list_11, item['initial_mod_date'], new_id)
	#             return query_11, new_id, length, '11'
	#     except AttributeError as Ae:
	#         self.logger.exception("Expect Affected version as list and item as dictionary" + str(Ae))
	#
	# @classmethod
	# def convert_mon_to_number(cls, oracle_rel_date):
	#     try:
	#         month_number = strptime(oracle_rel_date, '%b').tm_mon
	#         return month_number
	#     except AttributeError as Ae:
	#         cls.logger.exception("Expect month name as string" + str(Ae))

	# def set_query_jvm(self, new_id, cve, affected, mod_date):
	#     try:
	#
	#         if len(affected) == 1:
	#             affected_without_dot = re.subn(r'\.', '', affected[0])[0]
	#             mod_date = mod_date.split('-')
	#             month = self.convert_mon_to_number(mod_date[1][0:3])
	#             day = mod_date[-1]
	#             year = (mod_date[0])[2:]
	#             formated_mod_date = "{0}{1}{2}".format(year, str(month).zfill(2), day)
	#             query_jmv_11 = self.get_static_values("query_for_java_vm11").format(
	#                 new_id, cve, affected_without_dot, formated_mod_date, affected)
	#
	#             return re.sub("\'", "\'\'", query_jmv_11), 1
	#
	#         else:
	#             affected_without_dot1 = re.subn(r'\.', '', affected[0])[0]
	#             affected_without_dot2 = re.subn(r'\.', '', affected[1])[0]
	#             mod_date = mod_date.split('-')
	#             month = self.convert_mon_to_number(mod_date[1][0:3])
	#             day = mod_date[-1]
	#             year = (mod_date[0])[2:]
	#             formated_mod_date = "{0}{1}{2}".format(year, str(month).zfill(2), day)
	#             query_jvm_12 = self.get_static_values("query_for_java_vm12").format(new_id, cve, affected_without_dot1,
	#                                                                                 affected_without_dot2,
	#                                                                                 formated_mod_date,
	#                                                                                 affected[1], affected[0])
	#             return re.sub("\'", "\'\'", query_jvm_12), 2
	#     except IndexError as Ie:
	#         self.logger.exception("Affected version" + str(Ie))
	#     except AttributeError as Ae:
	#         self.logger.exception("Expect Affected as list and item as dictionary"+str(Ae))
	#
	# def set_query_no_jvm_11(self, cve, affected, mod_date, new_id):
	#     try:
	#         affected_without_dot = re.subn(r'\.', '', affected[0])[0]
	#         mod_date = mod_date.split('-')
	#         month = self.convert_mon_to_number(mod_date[1][0:3])
	#         day = mod_date[-1]
	#         year = (mod_date[0])[2:]
	#         formated_mod_date = "{0}{1}{2}".format(year, str(month).zfill(2), day)
	#         query = self.get_static_values("query_for_nonjvm_11").format(
	#             cve, affected_without_dot, formated_mod_date, affected[0], new_id)
	#         return re.sub("\'", "\'\'", query), 1
	#     except IndexError as Ie:
	#         self.logger.exception("Affected version" + str(Ie))
	#     except AttributeError as Ae:
	#         self.logger.exception("Expect Affected as list "+str(Ae))
	#
	# def set_query_no_jvm_12(self, cve, affected, mod_date, new_id):
	#     try:
	#
	#         if len(affected) == 1:
	#
	#             affected_without_dot = re.subn(r'\.', '', affected[0])[0]
	#             mod_date = mod_date.split('-')
	#             month = self.convert_mon_to_number(mod_date[1][0:3])
	#             day = mod_date[-1]
	#
	#             year = (mod_date[0])[2:]
	#             query = re.subn(r',\'\{5\}\'', '', self.get_static_values("query_for_nonjvm_12"))[0]
	#             query = re.subn(r',\'\{2\}\'', '', str(query))[0]
	#             query = re.subn(r'\{3\}', "{2}", str(query))[0]
	#             query = re.subn(r"\'\{4\}\'", "'{3}'", str(query))[0]
	#             formated_mod_date = "{0}{1}{2}".format(year, str(month).zfill(2), day)
	#             query = query.format(cve, affected_without_dot, formated_mod_date, affected[0], new_id)
	#             return re.sub("\'", "\'\'", query), 1
	#         elif len(affected) == 2:
	#             affected_without_dot1 = re.subn(r'\.', '', affected[0])[0]
	#             affected_without_dot2 = re.subn(r'\.', '', affected[1])[0]
	#             mod_date = mod_date.split('-')
	#             month = self.convert_mon_to_number(mod_date[1][0:3])
	#             day = mod_date[-1]
	#             year = (mod_date[0])[2:]
	#             formated_mod_date = "{0}{1}{2}".format(year, str(month).zfill(2), day)
	#             query = self.get_static_values('query_for_nonjvm_12').format(
	#                 cve, affected_without_dot1, affected_without_dot2, formated_mod_date, affected[0], affected[1])
	#             return re.sub("\'", "\'\'", query), 2
	#     except IndexError as Ie:
	#         self.logger.exception("Affected version" + str(Ie))
	#     except AttributeError as Ae:
	#         self.logger.exception("Expect Affected as list and item as dictionary"+str(Ae))

	# def get_mssql_query_from_checmate(self, test_id):
	#     try:
	#         with open('CheckGeneration_Prod/Mail_Properties/db_credential.json', 'r') as file:
	#             db_cred = json.loads(file.read())
	#             mydb = mysql.connector.connect(
	#                 host=db_cred['uri'],
	#                 user=db_cred['user'],
	#                 password=db_cred['password'],
	#                 database=db_cred['database'],
	#                 port=db_cred['port']
	#             )
	#             my_cursor = mydb.cursor()
	#
	#             query = "select body from item where item_id = '{0}'".format(test_id)
	#
	#             my_cursor.execute(query)
	#             return my_cursor.fetchone()[0]
	#     except Exception as e:
	#         self.logger.exception(str(e))
	# def get_mssql_query(self):
	#     pass