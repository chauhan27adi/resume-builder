import re
import logging
from typing import List, Tuple

logger = logging.getLogger('CheckGenerator')


class MySQLVulnerabilityQueryBuilder:
    @staticmethod
    def generate_list_from_affected_versions(affected_versions: str) -> List[str]:
        """
        Parse a string of affected versions into a list of version segments.

        Supports multiple formats separated by commas, such as:
        - "x.y.z"
        - "x.y.z and prior"
        - "x.y.z-x.y.z"
        - "x.y.z, a.b.c and prior"

        Args:
            affected_versions (str): A string representing one or more affected version specifications.

        Returns:
            List[str]: A list of cleaned version segments.
        """
        segments: List[str] = [seg.strip() for seg in affected_versions.split(",")]
        return segments

    @staticmethod
    def extract_minor_versions(version_range):
        """
        Extracts minor version(s) from a version string or version range.

        Supported formats:
            - 'X.Y.Z and prior'         → returns 'X.Y'
            - 'X.Y.Z'                   → returns 'X.Y'
            - 'X.Y.A-X.Y.B'             → returns 'X.Y'
            - 'X.Y.A-X.Z.B' (multi-minor) → returns list of 'X.Y', 'X.Y+1', ..., 'X.Z'

        Parameters:
            version_range (str): A version specifier (e.g., '8.0.21 and prior', '9.0.0-9.2.0')

        Returns:
            Union[str, List[str]]: A string (for single minor) or a list of minor versions (if spanning multiple minors).
        """
        version_range = version_range.strip()

        # Case 1: 'X.Y.Z and prior' → 'X.Y'
        if "and prior" in version_range:
            version = version_range.replace("and prior", "").strip()
            parts = version.split('.')
            return f"{parts[0]}.{parts[1]}"

        # Case 2: 'X.Y.Z' → 'X.Y'
        if '-' not in version_range:
            parts = version_range.strip().split('.')
            return f"{parts[0]}.{parts[1]}"

        # Case 3: version range 'X.Y.Z - X.Z.W'
        start_str, end_str = version_range.split('-')
        start_parts = list(map(int, start_str.strip().split('.')))
        end_parts = list(map(int, end_str.strip().split('.')))

        start_major, start_minor = start_parts[0], start_parts[1]
        end_major, end_minor = end_parts[0], end_parts[1]

        if start_major == end_major and start_minor == end_minor:
            return f"{start_major}.{start_minor}"

        # UNREACHABLE UNDER CURRENT CONDITIONS: generate_mysqldb_checks() applies
        # is_same_minor_range before calling this function, which guarantees that
        # only ranges where both major AND minor are identical ever reach this point.
        # Consequently the early-return above always fires and the loop below is
        # never executed in practice.
        #
        # If cross-minor support is added in the future (by removing or relaxing
        # the is_same_minor_range guard), two issues in this loop should be fixed:
        #   1. The failsafe rollover at current_minor > 99 is fragile — it assumes
        #      no MySQL minor version ever reaches 100, which may not hold forever.
        #      Use explicit major/minor enumeration based on known MySQL release branches
        #      instead of an arithmetic rollover.
        #   2. get_query_general_db() uses lexicographic version() string comparison
        #      for cross-minor ranges, which is incorrect for multi-digit major versions
        #      (e.g. "10.0.1" < "9.0.99" lexicographically). Use INET_ATON-style numeric
        #      comparison or a semver-aware SQL expression instead.
        minor_versions = []
        current_minor = start_minor
        current_major = start_major

        while (current_major < end_major) or (current_major == end_major and current_minor <= end_minor):
            minor_versions.append(f"{current_major}.{current_minor}")
            current_minor += 1
            if current_minor > 99:
                current_major += 1
                current_minor = 0

        return minor_versions

    @staticmethod
    def get_query_general_db(cve_id: str, affected_ver: str) -> Tuple[str, str]:
        """
        Generate a MySQL query string to check if the current MySQL version
        falls within the specified affected version(s) for a given CVE.

        The query returns 0 if vulnerable, 1 otherwise.

        Args:
            cve_id (str): The CVE identifier.
            affected_ver (str): A string representing the affected version, which may be:
                - Single version (e.g., "8.0.23")
                - Range of versions (e.g., "8.0.20-8.0.22")
                - Version with 'and prior' (e.g., "8.0.41 and prior")

        Returns:
            Tuple[str, str]: A tuple containing:
                - The SQL query string.
                - The cleaned affected version string.
        """
        affected_ver = affected_ver.strip()

        if "and prior" in affected_ver:
            # Extract patch number from version like "8.0.41 and prior"
            affected_ver = affected_ver.replace("and prior", "").strip()
            patch = affected_ver.split(".")[-1]
            condition = f"replace(substr(version(),5,2),'-','')<={patch}"

        elif "-" in affected_ver:
            # Handle version range e.g. "8.0.20 - 8.0.22"
            start, end = map(str.strip, affected_ver.split("-"))
            start_parts = start.split(".")
            end_parts = end.split(".")

            if len(start_parts) >= 3 and len(end_parts) >= 3:
                major_start, minor_start = start_parts[0], start_parts[1]
                major_end, minor_end = end_parts[0], end_parts[1]
                patch_start, patch_end = start_parts[2], end_parts[2]

                if major_start == major_end and minor_start == minor_end:
                    expr = f"replace(substr(version(),5,2),'-','')"
                    condition = f"({expr}>={patch_start} and {expr}<={patch_end})"
                else:
                    # For different major.minor, compare full version strings
                    condition = f"(version() >= '{start}' and version() <= '{end}')"
            else:
                # Fallback for unexpected format: compare patch only
                patch_start = start_parts[-1]
                patch_end = end_parts[-1]
                condition = (
                    f"(replace(substr(version(),5,2),'-','')>={patch_start} and "
                    f"replace(substr(version(),5,2),'-','')<={patch_end})"
                )
        else:
            # Single patch version exact match
            patch = affected_ver.split(".")[-1]
            condition = f"replace(substr(version(),5,2),'-','')={patch}"

        query = (
            f"select 'MySQL vulnerable against {cve_id}', "
            f"case when {condition} then 0 else 1 end as result"
        )

        logger.debug(f"MySQL query for {cve_id} (affected: {affected_ver}): {query}")
        return query, affected_ver