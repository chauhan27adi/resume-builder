import os
from os.path import join, dirname
from xml.etree import ElementTree as ET
from pymongo import MongoClient
import re
from time import strptime
import lxml.etree as xml_tree
import mysql.connector
import json
import sqlite3
import configparser
import requests
from check_generation_prod.vulnerability_validation import XmlValueValidation
from datetime import datetime
import logging


logging.getLogger("requests").setLevel(logging.ERROR)
logging.getLogger("urllib3").setLevel(logging.ERROR)


class CheckGenerationBase:

    logger = logging.getLogger('CheckGenerator')

    def __init__(self, list_db_name):
        self.list_db_name = list_db_name
        self._run_suffix = None
        api_username = self.get_static_values("api_username")
        api_password = self.get_static_values("api_password")
        self.api_auth = (api_username, api_password)
        self.api_url = self.get_static_values("api_url")
        _cfg = configparser.ConfigParser()
        _cfg.read(join(dirname(dirname(__file__)), 'config.ini'))
        self._check_gen_source = _cfg.get('source', 'check_gen_source', fallback='mongodb')
        self._chunk_size = _cfg.getint('source', 'chunk_size', fallback=20)
        self._oracle_target_versions = _cfg.get('source', 'oracle_target_versions', fallback='19|21|23|26')

    @staticmethod
    def get_mongo_uri(keys):
        try:
            with open(join(dirname(__file__), 'resources', 'db_credential.json'), 'r') as file:
                value = json.loads(file.read())
                return str(value[keys])
        except FileNotFoundError as Fe:
            CheckGenerationBase.logger.exception("Database Credentials file is missing " + str(Fe))
        except ValueError as Ve:
            CheckGenerationBase.logger.exception("Not able get mongodb credentials " + str(Ve))
        except AttributeError as Ae:
            CheckGenerationBase.logger.exception("Attribute error" + str(Ae))
        except KeyError as Ke:
            CheckGenerationBase.logger.exception(f"Keys {keys} not found " + str(Ke))

    @staticmethod
    def format_severity(priority):
        try:
            # Convert to lower case to make the comparison case-insensitive
            priority_lower = priority.lower()

            # Check if 'high' or 'low' is in the string
            if "high" in priority_lower or priority == "1":
                return "High"
            elif "low" in priority_lower or priority == "3":
                return "Low"
            elif "medium" in priority_lower or priority == "2":
                return "Medium"
            else:
                # Handle the case when neither is found
                raise ValueError(f"Invalid priority value: {priority}")
        except Exception as Ve:
            # Log the exception if any error occurs
            CheckGenerationBase.logger.exception(f"Severity parameter should be string. Error: {str(Ve)}")

    @classmethod
    def get_static_values(cls, keys):
        try:
            with open(join(dirname(__file__), 'resources', 'static_values.json'), 'r') as file:
                value = json.loads(file.read())
                return value[keys]
        except FileNotFoundError as Fe:
            cls.logger.exception("static_values.json file not found " + str(Fe))
        except AttributeError as Ae:
            cls.logger.exception("Key value should be string" + str(Ae))
        except KeyError as Ke:
            cls.logger.exception("Keys to get static value not found" + str(Ke))

    def read_cve_records_from_local_db(self):
        for database in self.list_db_name:
            if self._check_gen_source == 'sqlite':
                yield self.read_sqlite_db(database)
            else:
                yield self.read_mongo_db(database)

    def read_sqlite_db(self, db_name):
        db_path = join(dirname(dirname(dirname(__file__))), 'DVMCrawler', 'cve_data.db')
        try:
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute(
                f'SELECT * FROM "{db_name}" WHERE Progress IS NULL OR Progress NOT IN (\'success\', \'reported\')'
            )
            records = []
            for row in cursor.fetchall():
                r = dict(row)
                av = r.get('affected_version')
                if isinstance(av, str) and (av.startswith('[') or av.startswith('{')):
                    try:
                        r['affected_version'] = json.loads(av)
                    except (json.JSONDecodeError, TypeError):
                        pass
                cpv = r.get('current_patch_version')
                if isinstance(cpv, str) and (cpv.startswith('[') or cpv.startswith('{')):
                    try:
                        r['current_patch_version'] = json.loads(cpv)
                    except (json.JSONDecodeError, TypeError):
                        pass
                records.append(r)
            conn.close()
            return db_name, records
        except Exception as e:
            self.logger.exception(f"Failed to read SQLite table {db_name}: {e}")
            return db_name, []

    def read_mongo_db(self, db_name):
        client = None
        try:
            client = MongoClient(self.get_mongo_uri('mongo_db_uri'))
            db = client.output_web_crawler_details
            coll_val = db[db_name]
            progress_filter = {
                '$or': [
                    {'Progress': {'$exists': False}},
                    {'Progress': None},
                    {'Progress': {'$nin': ['success', 'reported']}},
                ]
            }
            records = list(coll_val.find(progress_filter))
            for rec in records:
                av = rec.get('affected_version')
                if isinstance(av, str) and (av.startswith('[') or av.startswith('{')):
                    try:
                        rec['affected_version'] = json.loads(av)
                    except (json.JSONDecodeError, TypeError):
                        pass
                cpv = rec.get('current_patch_version')
                if isinstance(cpv, str) and (cpv.startswith('[') or cpv.startswith('{')):
                    try:
                        rec['current_patch_version'] = json.loads(cpv)
                    except (json.JSONDecodeError, TypeError):
                        pass
            return db_name, records
        except ConnectionError as Ce:
            self.logger.exception("Connection was not established with mongodb database" + str(Ce))
            return db_name, []
        except IndexError as Ie:
            self.logger.exception("Not able find the collection" + str(Ie))
            return db_name, []
        except (KeyError, Exception) as Ke:
            self.logger.exception("Not able to find with collection name" + str(Ke))
            return db_name, []
        finally:
            if client:
                client.close()

    @staticmethod
    def check_for_success(item):
        if type(item) is dict:
            if 'success' in list(item.values()) or 'reported' in list(item.values()):
                if item['security_fixes'] == 'Patch':
                    return f'{item["name"]} : {item["current_patch_version"]} All ready generated', True
                else:
                    return f'{item["name"]} : {item["cve_no"]} All ready generated', True
            else:
                return item, False
        else:
            CheckGenerationBase.logger.warning('check_for_success received non-dict item of type %s; skipping', type(item).__name__)
            return str(item), True

    @staticmethod
    def convert_nearest_tens(x):
        try:
            if x % 10 == 0:
                return str(x).zfill(3)
            else:
                if x < 10:
                    return str(0).zfill(3)
                else:
                    x = x // 10
                    x = x * 10
                    return str(x).zfill(3)
        except (AttributeError, ValueError) as Ae:
            CheckGenerationBase.logger.exception("Value of 'x' should be integer" + str(Ae))

    @staticmethod
    def parse_xml_template(path_to_file):
        try:
            my_tree = ET.parse(path_to_file)
            my_root = my_tree.getroot()
            return my_root
        except (ET.ParseError, Exception) as Pe:
            CheckGenerationBase.logger.exception("Invalid Xml" + str(Pe))

    '''
    This code connects to a MySQL database, retrieves the most recent item_id that starts with "search_key", 
    extracts the numeric part, increments it by 1, and returns the next possible item_id in sequence.
    '''
    @classmethod
    def get_test_id_from_checkmate_db(cls, search_key):
        try:
            with open(join(dirname(__file__), 'resources', 'db_credential.json'), 'r') as file:
                db_cred = json.loads(file.read())
                mydb = mysql.connector.connect(
                    host=db_cred['uri'],
                    user=db_cred['user'],
                    password=db_cred['password'],
                    database=db_cred['database'],
                    port=db_cred['port']
                )
                my_cursor = mydb.cursor()
                query = (
                    "SELECT item_id FROM item "
                    "WHERE item_id LIKE '{0}%' "
                    "ORDER BY CAST(SUBSTRING(item_id, LENGTH('{0}') + 1) AS UNSIGNED) DESC "
                    "LIMIT 1;"
                ).format(search_key)

                my_cursor.execute(query)
                my_result = list(my_cursor.fetchone())[0]

                if 'DB2' in str(my_result):
                    my_result = str(re.findall(cls.get_regex_values("check_gen_base_get_id_db2"), my_result)[0])
                    my_cursor.close()
                    return search_key + str(int(my_result) + 1)

                elif search_key == 'SYVULN':
                    query_Query = "select body from item where body like '%sybase%' order by id desc limit 1;"
                    my_cursor.execute(query_Query)
                    base_query = my_cursor.fetchone()[0]
                    my_result = str(re.findall(r'\d+', my_result)[0])
                    my_cursor.close()
                    return search_key + str(int(my_result) + 1).zfill(3), base_query

                else:
                    my_result = str(re.findall(r'\d+', my_result)[0])
                    my_cursor.close()
                    return search_key+str(int(my_result)+1)

        except IndexError as Ie:
            CheckGenerationBase.logger.exception(str(Ie))
        except AttributeError as Ae:
            CheckGenerationBase.logger.exception("ID search key should be String" + str(Ae))
        except (ConnectionError, Exception) as Ce:
            CheckGenerationBase.logger.exception("Connection to Mysql was failed" + str(Ce))

    @staticmethod
    def xml_update_with_tags(tag, my_root, values, status_flag):
        try:
            if not status_flag and tag not in ['Platforms', 'Tags']:
                for tests in my_root.iter(tag):
                    tests.text = str(values)
                    tests.set('updated', 'no')
                    del tests.attrib["updated"]
                    # return tests
            elif not status_flag and tag in ['Platforms', 'Tags']:
                for plat in my_root.findall(tag)[-1]:
                    for val in plat.iter('Value'):
                        val.text = values
                        val.set('updated', 'yes')
                        del val.attrib["updated"]
                        # return val
        except (NameError, TypeError) as Ne:
            CheckGenerationBase.logger.exception("Tag is not getting any value to set" + str(Ne))

    def _db_output_dir(self, db_name):
        return join(dirname(dirname(__file__)), 'check_outputs', 'cves', db_name)

    def set_tags_in_checks(self, query, item_id, my_root, item, status, affected_version):
        # not ideal to lump it in here but this will get the DBMS
        # in the correct format for the platform and Tag elements
        dbms = item.get("name", "")
        if dbms.startswith("db"): dbms = "DB2"
        elif dbms.startswith("maria"): dbms = "MariaDB"
        elif dbms.startswith("mssql"): dbms = "MSSQL"
        elif dbms.startswith("mysql"): dbms = "MySQL"
        elif dbms.startswith("oracle"): dbms = "Oracle"
        elif dbms.startswith("hana"): dbms = "SAP HANA"
        elif dbms.startswith("post"): dbms = "PGSQL"
        elif dbms.startswith("mongo"): dbms = "MongoDB"
        if isinstance(affected_version, str):
            affected_version = f"{dbms} {affected_version}"
        elif isinstance(affected_version, list):
            affected_version = [f"{dbms} {i}" for i in affected_version]

        try:
            self.xml_update_with_tags('ID', my_root, item_id, status)
            self.xml_update_with_tags('Test_x0020_Name', my_root, 'Vulnerability to ' + str(item['cve_no']), status)
            self.xml_update_with_tags('Severity', my_root, self.format_severity(str(item['severity'])), status)
            self.xml_update_with_tags('Query', my_root, query, status)
            for tags in ['Short_x0020_Description', 'Long_x0020_Description', 'message']:
                self.xml_update_with_tags(tags, my_root, item['long_description'], status)
            self.xml_update_with_tags('LINKS', my_root, item['link'], status)
            self.xml_update_with_tags('CVE', my_root, item['cve_no'], status)
            if item['name'] not in ['hanadb', 'mssqldb', 'sybasedb']:
                self.xml_update_with_tags('Platforms', my_root, affected_version, status)
                self.xml_update_with_tags('Tags', my_root, affected_version, status)
            if item['name'] in ['mssqldb', 'sybasedb']:
                list_years = sorted(affected_version)
                set_tag = self.setting_tag_in_xml(my_root, list_years, status, len(list_years))
                # set_platform = self.base_class_obj.platform_set_xml(myroot, list_years)
                my_root = set_tag
                if not isinstance(my_root, ET.Element):
                    raise Exception("Failed to generate affected version tags")
                self.set_platform_with_multiple_values(my_root, list_years)
                self.set_tag_with_multiple_values(my_root, list_years)
                # update_tags = self.base_class_obj.set_tag_in_sybase(my_root, list_years)
            xml = ET.tostring(my_root, encoding="unicode")
            obj = XmlValueValidation(xml)
            db_output_dir = self._db_output_dir(item.get('name'))
            os.makedirs(db_output_dir, exist_ok=True)
            run_ts = self._run_suffix or datetime.now().strftime('%Y%m%d_%H%M%S')
            raw_bulletin = str(item.get('link', '').split('/')[-1]).split('.')[0].lower()
            bulletin = (raw_bulletin + '_') if (raw_bulletin and raw_bulletin != 'cvename' and not raw_bulletin.isdigit()) else ''
            file_name = join(db_output_dir, f"tests_output_{item.get('name')}_{bulletin}{run_ts}.xml")
            if obj.validation_result == 'valid':
                # Write the XML string to a file
                # Check if the file exists
                file_exists = os.path.exists(file_name)
                # Always write UTF-8 so downstream XML splitting/import logic can safely
                # read the file with the same encoding on all platforms.
                with open(file_name, "a", encoding="utf-8") as file:
                    if file_exists:
                        file.write("\n")  # Add a newline before appending if the file already exists
                    file.write(xml)

                self.logger.debug(f"XML written to {file_name}")
                #self.write_vulnerability_check_to_checkmate(query, affected_version, item, item_id)
                return my_root, 200
            else:
                self.logger.error("Validation failed for cve no {0}".format(item['cve_no']))
                return my_root, 201

        except (AttributeError, IndexError, NameError, ET.ParseError) as Ae:
            self.logger.exception("Error while setting xml tags for details " + str(Ae) + " " + str(201))
            return 'Failed to generate check', 201
        except Exception as e:
            self.logger.exception("Error while setting xml tags for details " + str(e) + " " + str(201))
            return 'Failed to generate check', 201

    @classmethod
    def is_integer_part_greater_than(cls, real_number, num):
        """
        Check if integer part in real_number is greater than num
        """
        number_str = str(real_number)
        # Split the string at the dot and check the first part
        integral_part = number_str.split('.')[0]
        if integral_part.isdigit() and int(integral_part) > num:
            return True
        return False

    @classmethod
    def get_integer_part(cls, real_number):
        """
        Return only the major version (part before the dot).
        """
        number_str = str(real_number)
        integral_part = number_str.split('.')[0]
        return integral_part

    @classmethod
    def get_query_general_db(cls, affected_ver, item):
        try:
            if item['name'] == 'mariadb':
                query = cls.get_static_values('maria_query').format(
                    item['cve_no'], ''.join(affected_ver.split('.')))
                return query, item['affected_version']

            elif item['name'] == 'mysqldb':
                # DEAD CODE — this branch is never reached. generate_mysqldb_checks()
                # calls MySQLVulnerabilityQueryBuilder.get_query_general_db() directly
                # and never calls CheckGenerationBase.get_query_general_db() for MySQL.
                # The corresponding "mysql_query" key in static_values.json is also
                # dead config as a result.
                # If this branch were ever activated: it would also return
                # item['affected_version'] (the raw comma-separated multi-version string)
                # as the second return value instead of the individual parsed version,
                # which differs from what MySQLVulnerabilityQueryBuilder returns.
                # Fix: remove this branch and the "mysql_query" static_values entry once
                # MySQLVulnerabilityQueryBuilder is confirmed as the sole MySQL path.
                fixed_version = affected_ver.split('.')[-1]
                query = cls.get_static_values('mysql_query').format(
                    item['cve_no'], fixed_version)
                return query, item['affected_version']

            elif item['name'] == 'postgredb':
                ver = re.findall(cls.get_regex_values("postgre_vuln_affected_version"), affected_ver)[0]
                if ver:
                    if cls.is_integer_part_greater_than(affected_ver, 9):
                        static_name = f"postgre_{str(ver).split('.')[0]}_query"
                    else:
                        static_name = f"postgre_{ver.replace('.', '_')}_query"
                    query = cls.get_static_values(static_name)
                    # KNOWN: If affected_ver is a bare major version (e.g. "16" with no dot),
                    # split(".")[1] raises IndexError caught below; get_query_general_db returns
                    # None and the caller skips check generation for that version. Normally the
                    # spider always returns major.minor strings from the "Fixed" column.
                    query = query.format(item['cve_no'], affected_ver.split(".")[1])
                    return query, ver
        except IndexError as Ie:
            cls.logger.exception("Failed to get the query" + str(Ie))
        except TypeError as Te:
            cls.logger.exception("Mismatch of Type" + str(Te))
        except AttributeError as Ae:
            cls.logger.exception(
                "Affected version should be list or string and item should be dictionary" + str(Ae))

    @classmethod
    def get_query_db2(cls, cve, affected_version):
        """
            Build DB2 vulnerability query when remediation data is available.

            Supported input pair format:
                ["Vx.y", "Special Build <n> Fix Pack <m>"]
                ["Vx.y", "Fix Pack <m>"]
                ["Vx.y", "Special Build <n>"]

            Rules:
            1) If both Special Build and Fix Pack exist -> use the full DB2 template.
            2) If only Fix Pack exists -> use fixpack-only DB2 template.
            3) If only Special Build exists -> use build-only DB2 template.
            4) If neither value exists -> return ('null', 'null') and caller skips check.
        """
        try:
            # affected_version is expected as a 2-item pair after db2_get_version_list().
            release = str(affected_version[0]) if affected_version else ''
            build_details = str(affected_version[1]) if len(affected_version) > 1 else ''

            # Parse both remediation signals from bulletin text.
            fixed_pack_match = re.search(r'Fix\s*Pack\s*(\d+)', build_details, re.IGNORECASE)
            build_lvl_match = re.search(r'Special\s*Build\s*(\d+)', build_details, re.IGNORECASE)

            # At least one threshold is required to build a meaningful DB2 vulnerability query.
            if not fixed_pack_match and not build_lvl_match:
                return 'null', 'null'

            fixed_pack = fixed_pack_match.group(1) if fixed_pack_match else None
            build_lvl = build_lvl_match.group(1) if build_lvl_match else None

            # Select template per DB2 release and available remediation values.
            if re.match(r'^V9.7', release):
                if fixed_pack and build_lvl:
                    query = cls.get_static_values('db2_9_7_query').format(cve, fixed_pack, build_lvl)
                elif fixed_pack:
                    query = cls.get_static_values('db2_9_7_fixpack_only_query').format(cve, fixed_pack)
                else:
                    query = cls.get_static_values('db2_9_7_build_only_query').format(cve, build_lvl)
                return query, '9.7'
            elif re.match(r'^V10.1', release):
                if fixed_pack and build_lvl:
                    query = cls.get_static_values('db2_10_1_query').format(cve, fixed_pack, build_lvl)
                elif fixed_pack:
                    query = cls.get_static_values('db2_10_1_fixpack_only_query').format(cve, fixed_pack)
                else:
                    query = cls.get_static_values('db2_10_1_build_only_query').format(cve, build_lvl)
                return query, '10.1'
            elif re.match(r'^V10.5', release):
                if fixed_pack and build_lvl:
                    query = cls.get_static_values('db2_10_5_query').format(cve, fixed_pack, build_lvl)
                elif fixed_pack:
                    query = cls.get_static_values('db2_10_5_fixpack_only_query').format(cve, fixed_pack)
                else:
                    query = cls.get_static_values('db2_10_5_build_only_query').format(cve, build_lvl)
                return query, '10.5'
            elif re.match(r'^V11.1', release):
                if fixed_pack and build_lvl:
                    query = cls.get_static_values('db2_11_1_query').format(cve, fixed_pack, build_lvl)
                elif fixed_pack:
                    query = cls.get_static_values('db2_11_1_fixpack_only_query').format(cve, fixed_pack)
                else:
                    query = cls.get_static_values('db2_11_1_build_only_query').format(cve, build_lvl)
                return query, '11.1'
            elif re.match(r'^V11.5', release):
                if fixed_pack and build_lvl:
                    query = cls.get_static_values('db2_11_5_query').format(cve, fixed_pack, build_lvl)
                elif fixed_pack:
                    query = cls.get_static_values('db2_11_5_fixpack_only_query').format(cve, fixed_pack)
                else:
                    query = cls.get_static_values('db2_11_5_build_only_query').format(cve, build_lvl)
                return query, '11.5'
            elif re.match(r'^V12.1', release):
                if fixed_pack and build_lvl:
                    query = cls.get_static_values('db2_12_1_query').format(cve, fixed_pack, build_lvl)
                elif fixed_pack:
                    query = cls.get_static_values('db2_12_1_fixpack_only_query').format(cve, fixed_pack)
                else:
                    query = cls.get_static_values('db2_12_1_build_only_query').format(cve, build_lvl)
                return query, '12.1'

            return 'null', 'null'

        except (IndexError, AttributeError, NameError) as Ie:
            cls.logger.exception(str(Ie))

    @staticmethod
    def db2_get_version_list(affected_version):
        try:
            index = 2
            new_list = [
                affected_version[i * index:(i + 1) * index] for i in range((len(affected_version) + index - 1) //
                                                                           index)
            ]
            return new_list
        except AttributeError as Ae:
            CheckGenerationBase.logger.exception("Affected version should be list" + str(Ae))
        except Exception as e:
            CheckGenerationBase.logger.exception("Exception in db2_get_version_list : " + str(e))

    @classmethod
    def get_query_mssql(cls, affected_versions, query_mssql):
        """
        Build the MSSQL SQL WHERE-clause for a CVE's affected version list.

        Version allowlist — mssql_list_year (regex.json):
          Only SQL Server years present in mssql_list_year generate a query clause.
          To suppress checks for a year (e.g. 2025 until Checkmate supports it),
          remove that year from mssql_list_year. To re-enable, add it back.
          If ALL affected years are excluded, query_entries stays empty, this method
          returns (None, []), and the caller skips writing the check entirely.

        Args:
            affected_versions: list of (product_name, version_range) tuples,
                               e.g. [("MSSQL 2019", "15.0.2000.5 - 15.0.2080.9")]
            query_mssql:       the base SQL string (SELECT … WHERE) to prepend

        Returns:
            (full_query_string, year_list) on success, (None, []) if no year matched.
        """
        try:
            query_entries = []  # list of (sort_key, query_string) for deterministic clause order
            year = []

            for affected in affected_versions:
                product_name = affected[0]  # e.g., "MSSQL 2019"
                version_range = affected[1].replace('–', '-').replace('—', '-')  # normalize en/em-dash

                # Handle both version ranges and single versions
                if '-' in version_range:
                    split_value = version_range.split('-')
                    start_version = split_value[0].strip()
                    end_version = split_value[1].strip()
                else:
                    start_version = end_version = version_range.strip()

                try:
                    # Get second-to-last number as build number
                    val1 = start_version.split('.')[-2]
                    val2 = end_version.split('.')[-2]
                except IndexError:
                    continue  # Skip if malformed version

                try:
                    # Match CU/SP/RTM using regex
                    val3 = re.findall(cls.get_regex_values("mssql_chk_gen_base_query_gen"), version_range)[0]
                except IndexError:
                    val3 = "RTM"  # default if no match

                # mssql_list_year is the version allowlist: only years in it get
                # a query clause. Remove a year to stop check generation for it.
                for mssql_year in cls.get_regex_values("mssql_list_year"):
                    if mssql_year in product_name:
                        query_template = cls.get_static_values(f'mssql_{mssql_year}')
                        query_string = query_template.format(val1, val2, val3)
                        year.append(mssql_year)
                        # Deterministic clause order: SQL year descending (2022 -> 2019 ->
                        # 2017 -> ...), then start build descending so the CU band (higher
                        # build) precedes the GDR band within the same year. val1 is the
                        # start build's third octet; mssql_year is numeric per mssql_list_year.
                        try:
                            year_num = int(mssql_year)
                        except (TypeError, ValueError):
                            year_num = 0
                        try:
                            start_build = int(val1)
                        except (TypeError, ValueError):
                            start_build = 0
                        query_entries.append(((-year_num, -start_build), query_string))

            # query_entries is empty when either:
            #   (a) All CVE-affected years are intentionally absent from mssql_list_year
            #       (e.g. a 2025-only CVE while "2025" is excluded from the allowlist).
            #       This is expected — returning (None, []) tells the caller to skip the check.
            #   (b) product_name format changed (e.g. "Microsoft SQL Server 2019" instead of
            #       "MSSQL 2019") so no token matched. Fix: align mssql_list_year tokens
            #       with the product_name prefix used by the spider, or broaden the match.
            if not query_entries:
                cls.logger.warning(
                    "get_query_mssql: no mssql_list_year token matched any product name in "
                    "affected_versions=%s — if all affected years are in the allowlist this "
                    "indicates a product_name format mismatch; otherwise this is expected "
                    "when the CVE only affects versions excluded from mssql_list_year (regex.json)",
                    affected_versions
                )
                return None, []
            # Emit clauses in the stable order defined by the sort key above so
            # regenerated checks are consistent across runs and diff-friendly.
            query_entries.sort(key=lambda entry: entry[0])
            subquery = "\n or ".join(qs for _, qs in query_entries)
            year = list(set(year))
            return query_mssql + subquery, year
        except (IndexError, AttributeError) as Ie:
            cls.logger.exception(str(Ie))
        except Exception as e:
            cls.logger.error(f"Exception in get_query_mssql: {str(e)}")

    @classmethod
    def set_tag_with_multiple_values(cls, my_roots, affected):
        try:
            my_root = None
            count = 0
            for my_root in my_roots.findall('Tags')[1:]:
                new = ET.SubElement(my_root, 'Value')
                new.text = affected[count]
                count = count + 1
            return my_root
        except AttributeError as Ae:
            cls.logger.exception(str(Ae))

    @staticmethod
    def setting_tag_in_xml(myroots, values, status_flag, no_of_values_in_tag):
        try:
            value_in_xml = None
            myroots = ET.tostring(myroots)
            val = xml_tree.fromstring(myroots)
            myroot = val
            for i in range(no_of_values_in_tag):
                myroot.insert(8 + i, xml_tree.Element("Platforms"))

                myroot.insert(10 + i, xml_tree.Element("Tags"))
                convert_lxml = (xml_tree.tostring(myroot))
                value_in_xml = ET.fromstring(convert_lxml)
            return value_in_xml
        except (AttributeError, TypeError, ET.ParseError) as err:
            CheckGenerationBase.logger.exception(str(err))

    @staticmethod
    def set_platform_with_multiple_values(my_roots, affected):
        my_root = None
        count = 0
        for my_root in my_roots.iter('Platforms'):
            new = ET.SubElement(my_root, 'Value')
            new.text = affected[count]
            count = count + 1
        return my_root

    @staticmethod
    def sub_query_construct_15_7(affected_versions, query):
        try:
            for affected_version in affected_versions:
                affected_version = affected_version.strip('SAP').split(' ')[1:]
                flag = all(x in affected_version for x in ['SP', 'CE', 'HF1', '15.7'])
                flag1 = all(x in affected_version for x in ['SP', 'CE', '15.7'])
                flag2 = all(x in affected_version for x in ['SP', 'HF1', '15.7'])
                if flag:

                    sub_query = " or \ncharindex('{0}{1} {2}',@@version) > 0 and charindex('{3}',@@version)".format(
                        affected_version[2],
                        affected_version[3], affected_version[4], affected_version[5])
                    query = query + sub_query
                elif flag1:
                    sub_query = " or \ncharindex('{0}{1} {2}',@@version) > 0".format(
                        affected_version[2], affected_version[3], affected_version[4]
                    )
                    query = query + sub_query

                elif flag2:
                    sub_query = " and charindex('{0}',@@version) ".format(
                        affected_version[-1]
                    )
                    query = query + sub_query

                return query
        except (IndexError, AttributeError, NameError) as err:
            CheckGenerationBase.logger.exception("Unable to construct query 15.7 " + str(err))

    @staticmethod
    def sub_query_construct_16_sp03(affected_versions, query):
        try:
            query = query.split("))\n    )\n)\nthen 0 else 1 end  as result")[0]
            for affected_version in affected_versions:
                affected_version = affected_version.strip('SAP').split(' ')[1:]
                if 'SP03' in affected_version and re.findall(r'PL\d+', str(affected_version)) and re.findall(r'HF\d+',
                                                                                                             str(
                                                                                                                     affected_version)):
                    sub_query = "\ncharindex('{0}',@@version)> 0 and charindex('{1}',@@version) = 0 ) or".format(
                        affected_version[3], affected_version[4]
                    )
                    query = query + sub_query

                elif 'SP03' in affected_version:
                    sub_query = "charindex('0',@@version)> 0 or".format(affected_version[3])
                    query = query + sub_query

            return query + "))\n    )\n)\nthen 0 else 1 end  as result"
        except (IndexError, AttributeError, NameError) as err:
            CheckGenerationBase.logger.exception("Unable to construct query 16_sp03 " + str(err))

    @staticmethod
    def sub_query_construct_16_sp02(affected_versions, query):
        try:
            for affected_version in affected_versions:
                affected_version = affected_version.strip('SAP').split(' ')[1:]

                if 'SP02' in affected_version and re.findall(
                        r'PL\d+', str(affected_version)) and re.findall(r'HF\d+', str(affected_version)):

                    sub_query = "\ncharindex('{0}',@@version)> 0 and charindex('{1}',@@version) = 0 ) or".format(
                        affected_version[3], affected_version[4]
                    )
                    query = query + sub_query

                elif 'SP02' in affected_version:
                    sub_query = "charindex('0',@@version)> 0 or".format(affected_version[3])
                    query = query + sub_query

            return query
        except (IndexError, AttributeError, NameError) as err:
            CheckGenerationBase.logger.exception("Unable to construct query 16_sp02 " + str(err))

    def query_construct(self, previous_query, item):
        try:
            query_15_7 = previous_query.split('  \n        )\n)\nor')[0]
            query_15_7 = self.sub_query_construct_15_7(item['affected_version'], query_15_7)
            query_16_0 = (previous_query.split('  \n        )\n)\nor')[1]).split("(charindex('SP03',@@version)> 0")
            query_16_0_sp03 = "(charindex('SP03',@@version)> 0" + query_16_0[1]
            query_16_0_sp02 = query_16_0[0]
            query_16_0_sp03 = self.sub_query_construct_16_sp03(item['affected_version'], query_16_0_sp03)
            query_16_0_sp02 = self.sub_query_construct_16_sp02(item['affected_version'], query_16_0_sp02)
            consolidated_query = query_15_7 + "  \n        )\n)\nor" + query_16_0_sp02 + '\n' + query_16_0_sp03
            return re.sub("\\'", "\\\\'", consolidated_query)

        except (IndexError, AttributeError, NameError, TypeError) as err:
            CheckGenerationBase.logger.exception("Unable to construct query sybase " + str(err))

    def get_hana_query(self, affected_version):
        try:
            if not affected_version:
                return None

            if not isinstance(affected_version, list):
                affected_version = [affected_version]

            index = 3
            triplets = [
                affected_version[i * index:(i + 1) * index]
                for i in range((len(affected_version) + index - 1) // index)
            ]

            parsed = []
            for nested_list in triplets:
                if len(nested_list) < 3:
                    continue

                product, sp_token, build_token = [str(x).strip() for x in nested_list]

                major_match = re.search(r'\b([12])(?:\.0)?\b', product)
                sp_match = re.search(r'\d+', sp_token)
                build_match = re.search(r'\d+', build_token)
                if not (major_match and sp_match and build_match):
                    continue

                major = major_match.group(1)
                sp_num = int(sp_match.group(0))
                sp_str = str(sp_num).zfill(3)
                lower_sp = self.convert_nearest_tens(sp_num)

                build_raw = build_match.group(0)
                if int(build_raw) == 0:
                    build_str = '00'
                elif build_raw.startswith('0') and len(build_raw) > 1:
                    build_str = build_raw
                else:
                    build_str = str(int(build_raw))

                parsed.append((int(major), sp_num, sp_str, lower_sp, build_str))

            if not parsed:
                return None

            # De-duplicate and order predictably for stable query generation.
            parsed = sorted(set(parsed), key=lambda x: (x[0], x[1], int(x[4]) if x[4].isdigit() else 0))

            clauses = []
            for major, _, sp_str, lower_sp, build_str in parsed:
                clauses.append(
                    "(version < '{0}.00.{1}.{2}' and version >= '{0}.00.{3}.00')".format(
                        major, sp_str, build_str, lower_sp
                    )
                )

            if not clauses:
                return None

            return "select version CONTEXT, 0 RESULT from M_DATABASE where " + " or ".join(clauses)
        except (IndexError, AttributeError, NameError) as err:
            CheckGenerationBase.logger.exception("Unable to get Hana query " + str(err))

    @staticmethod
    def construct_platform(affected, name):
        temp_list = []
        if name == 'mariadb':
            return 'MariaDB ' + affected
        elif name == 'postgredb':
            return affected
        elif name == 'mysqldb':
            return 'MySQL ' + affected
        elif name == 'db2db':
            return affected
        elif name == 'sybasedb':
            for affected_ver in affected:
                temp_list.append('Sybase ' + affected_ver)
            return ';'.join(temp_list)
        elif name == 'mssqldb':
            for affected_ver in affected:
                temp_list.append('MSSQL ' + affected_ver)
            return ';'.join(temp_list)
        else:
            return 'ALL SAP HANA'

    @staticmethod
    def request(post=False, **kwargs):
        method = [requests.get, requests.post][post == True]
        response = None
        try:
            response = method(**kwargs)
            retry = response.status_code == 502
        except requests.exceptions.ProxyError:
            retry = True
        if retry:
            kwargs["proxies"] = {"http": "", "https": ""}
            response = method(**kwargs)
        return response

    def get_tag_or_platform_id(
            self, lookup_string: str, is_platform: bool=False) -> str:
        # Check if the tag/platform exists and get it's ID
        endpoint = "platform" if is_platform else "tag"
        url = f"{self.api_url}/api/v1/{endpoint}/{lookup_string}"
        kwargs = {"url": url, "auth": self.api_auth}
        response = self.request(**kwargs)
        resp_json = response.json()
        # response will be like one of the following:
        #  ["<lookup_string>", "(<id>,)"]
        #  ["<lookup_string>", "None"]
        id_value = resp_json[1]
        if re.search("\d+", id_value):
            return re.findall("\d+", id_value)[0]
        msg = f"{endpoint.title()} '{lookup_string}' not in {endpoint} table"
        msg += ", please create it."
        raise ValueError(msg)

    def write_vulnerability_check_to_checkmate(self, query, affected_version, item, item_id):
        try:
            # its ok to hard code the "Vulnerabilities" tag here as this method
            # is specific to vulnerability check generation
            affected_major_version = affected_version.split(".")[0]
            tags = [affected_major_version, "Vulnerabilities"]
            tags = ",".join(self.get_tag_or_platform_id(t) for t in tags)
            platform = self.construct_platform(affected_major_version, item["name"])
            platform = self.get_tag_or_platform_id(platform, True)
            url = f"{self.api_url}/api/v1/new_vuln/{item_id}"
            create_row_data = {
                'body': query,
                'cve': item['cve_no'],
                'item_id': item_id,
                'name': 'Vulnerability to ' + item['cve_no'],
                'platform': platform,
                'severity': item['severity'],
                'long_description': item['long_description'],
                'link': item['link'],
                'tags': tags
            }
            self.logger.info(
                f"Check {item_id} successfully generated for {item['cve_no']}")
            try:
                kwargs = {"url": url, "auth": self.api_auth, "json": create_row_data}
                response = self.request(post=True, **kwargs)
                if response.status_code == 200:
                    self.logger.info(f"Written {item_id} to checkmate")
                    self.append_db_with_check_generation_status(
                        'success', datetime.now(),
                        item['cve_no'], item['name'], 'cve_no'
                    )
                    self.update_log_file_with_check(item, "success")
                else:
                    self.update_log_file_with_check(item, response.status_code)
                    self.logger.error(f"Unable to write {item_id} to checkmate")
                    self.logger.debug(f"Status: {response.status_code}")
            except requests.exceptions.ConnectionError as err:
                self.logger.error(
                    f"Unable to write to checkmate: ConnectionError ({err})")
        except (IndexError, AttributeError, NameError, ValueError) as e:
            self.logger.exception(f"Unable to write to checkmate: {e}")
        except Exception as Ge:
            self.logger.exception(f"General exception: {Ge}")

    def write_patch_check_to_file(self, check_xml, item):
        try:
            db_name = item.get('name', 'unknown') if isinstance(item, dict) else 'unknown'
            output_dir = join(dirname(dirname(__file__)), 'check_outputs', 'patches', db_name)
            os.makedirs(output_dir, exist_ok=True)
            run_ts = self._run_suffix or datetime.now().strftime('%Y%m%d_%H%M%S')
            file_name = join(output_dir, f"patch_output_{db_name}_{run_ts}.xml")
            file_exists = os.path.exists(file_name)
            with open(file_name, "a", encoding="utf-8") as f:
                if file_exists:
                    f.write("\n")
                f.write(check_xml)
            self.logger.debug(f"Patch XML written to {file_name}")
        except Exception as e:
            self.logger.exception(f"Failed to write patch XML to file: {e}")

    def write_patch_check_to_checkmate(self, check, severity, new_id, platform, tag, version, item):
        try:
            print("######################### New Line ####################### ", str(check), sep='\n')
            body = self.get_patch_query('query', check)
            name = self.get_patch_query('hhmessage', check)
            if item['name'] == 'db2_patch':
                item_id = re.findall(self.get_regex_values("db2_checkmate_vuln_id"), str(check))[0]
            else:
                item_id = re.findall(self.get_regex_values("db2_checkmate_patch_id"), str(check))[0]
            create_row_data = {
                'body': body, 'item_id': item_id, 'name': name,
                'platform': platform, 'severity': severity, 'new_id': new_id,
                'tag': tag, 'version': version, 'check': check
            }

            url = f"{self.api_url}/api/v1/new_patch/{item_id}"
            try:
                kwargs = {"url": url, "auth": self.api_auth, "json": create_row_data}
                response = self.request(post=True, **kwargs)
                if response.status_code == 200:
                    self.logger.info("Patch Check successfully generated for {0} : status: {1}".format(
                        item_id, response.status_code))
                    self.append_db_with_check_generation_status(
                        'success', datetime.now(), item['current_patch_version'], item['name'], 'current_patch_version')
                else:
                    self.update_log_file_with_check(item, response.status_code)
                    self.logger.exception(
                        '''Check Generated with {0} but unable 
                        to write to checkmate : Satus :{1}'''.format(item_id, response.status_code))
            except requests.exceptions.ConnectionError as err:
                self.logger.error(f"Unable to write to checkmate: ConnectionError ({err})")
            except TypeError as Te:
                self.logger.exception("Type error while writing to checkmate server: " + str(Te))
            except Exception as e:
                self.logger.exception(f"Generic Exception caught in RestAPI call to checkmate server: {e}")
        except (ConnectionError, ConnectionRefusedError) as Ce:
            self.logger.exception("Checkmate api may not be running: " + str(Ce))
        except (IndexError, AttributeError, NameError) as e:
            self.logger.exception("Unable to write to checkmate database: " + str(e))
        except Exception as e:
            self.logger.exception(f"Generic Exception caught in write_patch_check_to_checkmate: {e}")

    @staticmethod
    def get_patch_query(tag, check):
        check = ET.fromstring(check)
        for value in check.iter(tag):
            return value.text

    @staticmethod
    def update_log_file_with_check(item, status):
        timestamp = datetime.now()
        with open(join(dirname(__file__), 'resources', 'mail_body.csv'), 'a') as file:
            #file.write(f'\n\tDatabase : {item["name"]} , status : {status}, cve/patch_id : {item["cve_no"]}, timestamp: {timestamp}')
            if item['security_fixes'] == 'Patch':
                file.write(f'\n\tDatabase : {item["name"]} , status : {status}, cve/patch_id : {item["current_patch_version"]}, timestamp: {timestamp}')
            else:
                file.write(f'\n\tDatabase : {item["name"]} , status : {status}, cve/patch_id : {item["cve_no"]}, severity : {item["severity"]}, timestamp: {timestamp}')

    @staticmethod
    def update_email_file_with_check(security_fixe_type, db_name, cve_no, severity, status):
        timestamp = datetime.now()
        with open(join(dirname(__file__), 'resources', 'mail_body.csv'), 'a') as file:
            if security_fixe_type == 'Vulnerabilities':
                file.write(
                    f'\n\tDatabase : {db_name} , status : {status}, cve : {cve_no}, severity : {severity}, timestamp: {timestamp}')
            else:
                file.write(
                    f'\n\tDatabase : {db_name} , status : {status}, patch_id : "<patch_ver">, timestamp: {timestamp}')

    def append_db_with_check_generation_status(self, status, check_generation_timestamp, unique_id_value, name,
                                               unique_id):
        if self._check_gen_source == 'sqlite':
            try:
                db_path = join(dirname(dirname(dirname(__file__))), 'DVMCrawler', 'cve_data.db')
                conn = sqlite3.connect(db_path)
                # Migrate columns that may not exist in older databases
                for col, definition in [
                    ('"Progress"', 'TEXT DEFAULT NULL'),
                    ('check_generation_timestamp', 'TEXT DEFAULT NULL'),
                ]:
                    try:
                        conn.execute(f'ALTER TABLE "{name}" ADD COLUMN {col} {definition}')
                    except sqlite3.OperationalError:
                        pass  # column already exists
                conn.execute(
                    f'UPDATE "{name}" SET "Progress" = ?, check_generation_timestamp = ? WHERE "{unique_id}" = ?',
                    (status, str(check_generation_timestamp), unique_id_value),
                )
                conn.commit()
                conn.close()
                self.logger.info("SQLite DB updated")
            except Exception as e:
                self.logger.exception(f"Update of SQLite with check generation status failed: {e}")
        else:
            client = None
            try:
                client = MongoClient(self.get_mongo_uri('mongo_db_uri'))
                db = client.output_web_crawler_details
                coll_name = db[name]
                result = coll_name.update_one(
                    {f'{unique_id}': unique_id_value},
                    {'$set': {
                        'Progress': status,
                        'TimeStamp_for_Check_generation': str(check_generation_timestamp),
                    }},
                )
                if result.matched_count:
                    self.logger.info("Mongo DB updated")
                else:
                    self.logger.warning("Mongo DB update: no document matched %s=%s", unique_id, unique_id_value)
            except ConnectionError as Ce:
                self.logger.exception("Update of Mongodb with success response failed due to Connection error" + str(Ce))
            except Exception as Ge:
                self.logger.exception("Update of Mongodb with success response failed" + str(Ge))
            finally:
                if client:
                    client.close()

    def get_next_check_id(self, prefix, default):
        path = join(dirname(__file__), 'resources', 'next_check_ids.json')
        try:
            with open(path, 'r') as f:
                data = json.load(f)
            return data.get(prefix, default)
        except (FileNotFoundError, json.JSONDecodeError):
            return default

    def save_next_check_id(self, prefix, next_id):
        path = join(dirname(__file__), 'resources', 'next_check_ids.json')
        try:
            with open(path, 'r') as f:
                data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            data = {}
        data[prefix] = next_id
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)

    # REVERTED / NOT IN USE: the two temporary ID rules below (CSPU->CPU, and Aug/Sep CSPU -> CPUOCT2026) are disabled.
    # Kept commented out for later reuse; to re-enable, uncomment this block and the 'Temporary version' lines in
    # oracle_set_id, oracle_java_vm_processing and oracle_no_java_vm_processing.
    # # TEMPORARY: advisory (uppercased URL file name) -> bulletin used in Oracle check IDs. See _oracle_bulletin_id_part.
    # # Remove this mapping (and the lookup in the helper) to go back to per-advisory IDs.
    # _ORACLE_TEMP_QUARTERLY_BULLETIN = {
    #     'CSPUAUG2026': 'CPUOCT2026',
    #     'CSPUSEP2026': 'CPUOCT2026',
    #     'CPUOCT2026': 'CPUOCT2026',
    # }
    # 
    # @staticmethod
    # def _oracle_bulletin_id_part(link):
    #     """
    #     TEMPORARY: returns the bulletin part of an Oracle check ID (e.g. 'CPUJUL2026').
    #     Original behaviour (kept for later reuse): the bulletin name taken from the advisory
    #     URL as-is, so a CSPU advisory (cspuaug2026.html) produced 'CSPUAUG2026' and therefore
    #     IDs like ORACSPUAUG2026_DB_19C_01, distinct from CPU IDs.
    #     Temporary requirement: CSPU check IDs must look like CPU ones (ORACPU<MON><YEAR>_DB_<N>C_<NN>),
    #     so a leading 'CSPU' is hardcoded to 'CPU'. To restore the CPU/CSPU distinction, return the
    #     commented original expression instead of the substituted one.
    #     """
    #     # Original (commented out temporarily):
    #     # return str(link.split('/')[-1]).split('.')[0].upper()
    #     bulletin = str(link.split('/')[-1]).split('.')[0].upper()
    #     # TEMPORARY (backfill of Aug/Sep CSPU + Oct CPU 2026): every check from these three advisories must
    #     # carry the quarterly CPU bulletin in its ID (ORACPUOCT2026_...), so that the shared per-major counter
    #     # runs on continuously across the three advisories. Any other bulletin falls back to the rule below.
    #     if bulletin in CheckGenerationBase._ORACLE_TEMP_QUARTERLY_BULLETIN:
    #         return CheckGenerationBase._ORACLE_TEMP_QUARTERLY_BULLETIN[bulletin]
    #     return re.sub(r'^CSPU', 'CPU', bulletin)  # hardcoded: CSPU -> CPU

    # TEMPORARY switch: True = every Oracle check uses the date/month of the QUARTERLY CPU that covers its
    # advisory month (see _oracle_effective_mod_date). Set to False to go back to the advisory's own date.
    _ORACLE_TEMP_USE_QUARTERLY_DATE = True

    @classmethod
    def _oracle_effective_mod_date(cls, mod_date):
        """
        TEMPORARY: maps the advisory's initial_mod_date ('YYYY-Mon-DD', e.g. '2026-Aug-18') to the date of the
        quarterly CPU that covers it, in the same format, so the SQL threshold (YYMMDD) and the text
        ('Oracle CPU <Month> <Year> installed') both refer to the quarterly update:
            Aug/Sep/Oct -> October  (e.g. 2026-Oct-20 -> 261020)
            Nov/Dec/Jan -> January  (Nov/Dec roll to the NEXT year)
            Feb/Mar/Apr -> April
            May/Jun/Jul -> July
        A month that is already a quarterly month (Jan/Apr/Jul/Oct) keeps its stored date unchanged. Other months
        get the third Tuesday of the quarterly month (Oracle's CPU release day, same rule the crawler uses when it
        derives a date from the URL). Anything unparsable is returned unchanged (never raises), so behaviour for
        unexpected values is exactly the original one.
        """
        if not cls._ORACLE_TEMP_USE_QUARTERLY_DATE:
            return mod_date
        try:
            from datetime import date, timedelta
            parts = str(mod_date).split('-')
            if len(parts) != 3:
                return mod_date
            year = int(parts[0])
            month = cls.convert_mon_to_number(parts[1][0:3])
            if not month:
                return mod_date
            if month in (1, 4, 7, 10):
                return mod_date                       # already a quarterly CPU month: keep the stored date
            target_month = next(m for m in (1, 4, 7, 10, 13) if m >= month)   # 13 = January of next year
            if target_month == 13:
                target_month, year = 1, year + 1
            first = date(year, target_month, 1)
            third_tuesday = first + timedelta(days=(1 - first.weekday()) % 7 + 14)
            return "{0}-{1}-{2}".format(year, third_tuesday.strftime('%b'), str(third_tuesday.day).zfill(2))
        except Exception as e:
            cls.logger.exception("Quarterly date mapping failed, using the original date " + str(mod_date) + ": " + str(e))
            return mod_date

    @classmethod
    def oracle_set_id(cls, item, version):
        try:
            # REVERTED: original ID logic restored (per-advisory bulletin, CSPU stays CSPU). The temporary CSPU->CPU / quarterly-ID mapping is kept commented out below for later reuse.
            # Temporary version (commented out):
            # bulletin_id = cls._oracle_bulletin_id_part(item['link'])
            # if version == 11:
            #     first_part_id = 'ORA' + bulletin_id + '_DB' + str(item['count']).zfill(2)
            # else:
            #     first_part_id = 'ORA' + bulletin_id + '_DB' + str(item['count']).zfill(2) + '_SP'
            link_to_id = str(item['link'].split('/')[-1]).split('.')
            if version == 11:
                first_part_id = 'ORA' + link_to_id[0].upper() + '_DB' + str(item['count']).zfill(2)
            else:
                first_part_id = 'ORA' + link_to_id[0].upper() + '_DB' + str(item['count']).zfill(2) + '_SP'
            return first_part_id
        except IndexError as Ie:
            CheckGenerationBase.logger.exception(f"Id generation of oracle failed {item['cve_no']}" + str(Ie))
        except AttributeError as Ae:
            CheckGenerationBase.logger.exception(f"Id generation of oracle failed {item['cve_no']}" + str(Ae))

    def oracle_java_vm_processing(self, affected_version, item, target_majors, version_counters):
        try:
            results = []
            list_11 = [v for v in affected_version if re.match(r'^11\.', v.strip())]
            for major in target_majors:
                if major == 11:
                    continue
                major_ranges = [v for v in affected_version if re.match(r'^{0}\.'.format(major), v.strip())]
                if not major_ranges:
                    continue
                version_counters[major] = version_counters.get(major, 0) + 1
                # REVERTED: original ID logic restored (per-advisory bulletin, CSPU stays CSPU). The temporary CSPU->CPU / quarterly-ID mapping is kept commented out below for later reuse.
                # Temporary version (commented out):
                # new_id = 'ORA' + self._oracle_bulletin_id_part(item['link']) + '_DB_' + str(major) + 'C_' + str(version_counters[major]).zfill(2)
                link_to_id = str(item['link'].split('/')[-1]).split('.')
                new_id = 'ORA' + link_to_id[0].upper() + '_DB_' + str(major) + 'C_' + str(version_counters[major]).zfill(2)
                # TEMPORARY: use the quarterly CPU date (see _oracle_effective_mod_date); original line kept below.
                # query = self.set_query_jvm(new_id, item['cve_no'], major_ranges[0], major, item['initial_mod_date'])
                query = self.set_query_jvm(new_id, item['cve_no'], major_ranges[0], major, self._oracle_effective_mod_date(item['initial_mod_date']))
                results.append((query, new_id, str(major)))
            if list_11 and not results:
                new_id = self.oracle_set_id(item, 11)
                # TEMPORARY: use the quarterly CPU date (see _oracle_effective_mod_date); original line kept below.
                # query_11, length = self._set_query_jvm_11(new_id, item['cve_no'], list_11, item['initial_mod_date'])
                query_11, length = self._set_query_jvm_11(new_id, item['cve_no'], list_11, self._oracle_effective_mod_date(item['initial_mod_date']))
                results.append((query_11, new_id, '11'))
            return results
        except IndexError as Ie:
            self.logger.exception("Affected version" + str(Ie))
            return []
        except AttributeError as Ae:
            self.logger.exception("Expect Affected as list and item as dictionary" + str(Ae))
            return []

    def oracle_no_java_vm_processing(self, affected_version, item, major, version_counters):
        try:
            version_counters[major] = version_counters.get(major, 0) + 1
            # REVERTED: original ID logic restored (per-advisory bulletin, CSPU stays CSPU). The temporary CSPU->CPU / quarterly-ID mapping is kept commented out below for later reuse.
            # Temporary version (commented out):
            # new_id = 'ORA' + self._oracle_bulletin_id_part(item['link']) + '_DB_' + str(major) + 'C_' + str(version_counters[major]).zfill(2)
            link_to_id = str(item['link'].split('/')[-1]).split('.')
            new_id = 'ORA' + link_to_id[0].upper() + '_DB_' + str(major) + 'C_' + str(version_counters[major]).zfill(2)
            if major == 11:
                # TEMPORARY: use the quarterly CPU date (see _oracle_effective_mod_date); original line kept below.
                # query, _ = self.set_query_no_jvm_11(item['cve_no'], affected_version, item['initial_mod_date'], new_id)
                query, _ = self.set_query_no_jvm_11(item['cve_no'], affected_version, self._oracle_effective_mod_date(item['initial_mod_date']), new_id)
            else:
                # TEMPORARY: use the quarterly CPU date (see _oracle_effective_mod_date); original line kept below.
                # query = self.set_query_no_jvm_12(item['cve_no'], affected_version, item['initial_mod_date'], new_id, major)
                query = self.set_query_no_jvm_12(item['cve_no'], affected_version, self._oracle_effective_mod_date(item['initial_mod_date']), new_id, major)
            return query, new_id, len(affected_version)
        except AttributeError as Ae:
            self.logger.exception("Expect Affected version as list and item as dictionary" + str(Ae))

    @classmethod
    def convert_mon_to_number(cls, oracle_rel_date):
        try:
            month_number = strptime(oracle_rel_date, '%b').tm_mon
            return month_number
        except AttributeError as Ae:
            cls.logger.exception("Expect month name as string" + str(Ae))

    @classmethod
    def convert_mon_to_full_name(cls, abbr):
        return datetime.strptime(abbr, '%b').strftime('%B')

    def set_query_jvm(self, new_id, cve, version_range, major, mod_date):
        try:
            mod_date_parts = mod_date.split('-')
            month = self.convert_mon_to_number(mod_date_parts[1][0:3])
            day = mod_date_parts[-1]
            year = mod_date_parts[0][2:]
            year_full = mod_date_parts[0]
            full_month = self.convert_mon_to_full_name(mod_date_parts[1][0:3])
            formated_mod_date = "{0}{1}{2}".format(year, str(month).zfill(2), day)

            if major == 19:
                parts_split = version_range.split('-')
                upper_bound = parts_split[1] if len(parts_split) >= 2 else parts_split[0]
                ver_parts = upper_bound.split('.')
                ver_parts[1] = str(int(ver_parts[1]) + 1)
                lower_bound = '.'.join(ver_parts[:2])
                lower_bound_no_dots = lower_bound.replace('.', '')
                return self.get_static_values("query_for_java_vm_19c").format(
                    new_id, cve, lower_bound_no_dots, formated_mod_date, '19.3',
                    full_month, year_full)

            elif major == 21:
                return self.get_static_values("query_for_java_vm_21c").format(
                    new_id, cve, formated_mod_date, full_month, year_full)

        except IndexError as Ie:
            self.logger.exception("Affected version" + str(Ie))
        except AttributeError as Ae:
            self.logger.exception("Expect Affected as list and item as dictionary" + str(Ae))

    def _set_query_jvm_11(self, new_id, cve, affected, mod_date):
        try:
            affected_without_dot = re.subn(r'\.', '', affected[0])[0]
            mod_date = mod_date.split('-')
            month = self.convert_mon_to_number(mod_date[1][0:3])
            day = mod_date[-1]
            year = (mod_date[0])[2:]
            formated_mod_date = "{0}{1}{2}".format(year, str(month).zfill(2), day)
            query_jvm_11 = self.get_static_values("query_for_java_vm11").format(
                new_id, cve, affected_without_dot, formated_mod_date, affected)
            return re.sub("\\'", "\\'\\'", query_jvm_11), 1
        except IndexError as Ie:
            self.logger.exception("Affected version" + str(Ie))
        except AttributeError as Ae:
            self.logger.exception("Expect Affected as list and item as dictionary" + str(Ae))

    def set_query_no_jvm_11(self, cve, affected, mod_date, new_id):
        try:
            affected_without_dot = re.subn(r'\.', '', affected[0])[0]
            mod_date = mod_date.split('-')
            month = self.convert_mon_to_number(mod_date[1][0:3])
            day = mod_date[-1]
            year = (mod_date[0])[2:]
            formated_mod_date = "{0}{1}{2}".format(year, str(month).zfill(2), day)
            query = self.get_static_values("query_for_nonjvm_11").format(
                cve, affected_without_dot, formated_mod_date, affected[0], new_id)
            return re.sub("\\'", "\\'\\'", query), 1
        except IndexError as Ie:
            self.logger.exception("Affected version" + str(Ie))
        except AttributeError as Ae:
            self.logger.exception("Expect Affected as list "+str(Ae))

    def set_query_no_jvm_12(self, cve, affected_version, mod_date, new_id, major):
        try:
            parts = mod_date.split('-')
            year_full = parts[0]
            month_abbr = parts[1][0:3]
            day = parts[2]
            yymmdd = year_full[2:] + str(self.convert_mon_to_number(month_abbr)).zfill(2) + day.zfill(2)
            full_month = self.convert_mon_to_full_name(month_abbr)
            query = self.get_static_values('query_for_nonjvm_modern').format(
                new_id, cve, str(major), yymmdd, full_month, year_full)
            return query
        except IndexError as Ie:
            self.logger.exception("Affected version" + str(Ie))
        except AttributeError as Ae:
            self.logger.exception("Expect Affected as list and item as dictionary" + str(Ae))

    def get_mssql_query_from_checmate(self, test_id):
        try:
            with open(join(dirname(__file__), 'resources', 'db_credential.json'), 'r') as file:
                db_cred = json.loads(file.read())
                mydb = mysql.connector.connect(
                    host=db_cred['uri'],
                    user=db_cred['user'],
                    password=db_cred['password'],
                    database=db_cred['database'],
                    port=db_cred['port']
                )
                my_cursor = mydb.cursor()

                query = "select body from item where item_id = '{0}'".format(test_id)

                my_cursor.execute(query)
                return my_cursor.fetchone()[0]
        except Exception as e:
            self.logger.exception(str(e))

    @classmethod
    def get_regex_values(cls, keys):
        try:
            with open(join(dirname(__file__), 'resources', 'regex.json'), 'r') as file:
                value = json.loads(file.read())
                return value[keys]
        except FileNotFoundError as Fe:
            cls.logger.exception("static_values.json file not found " + str(Fe))

    def get_db_name_from_testid(self, test_id):
        # Mapping substrings to db names
        db_mapping = {
            "MSVULN": "mssqldb", "DB2VULN": "db2db", "HANAVULN": "hanadb", "MARIAVULN": "mariadb",
            "MYVULN": "mysqldb", "PGVULN": "postgredb", "SYVULN": "sybasedb",
            "ORVULN": "oracledb", "ORACPU": "oracledb", "ORACSPU": "oracledb",
            "MDBVULN": "mongodb"
        }
        # Check if any substring exists in test_id
        for key, value in db_mapping.items():
            if key in test_id:
                return value
        return None  # No match found
