import os
from os.path import join, dirname

from check_generation_prod.check_generation_base import CheckGenerationBase
import re
from xml.etree import ElementTree
from datetime import datetime
import glob
from checkmate_client.checkmate.checkmate import CheckmateUI
from check_generation_prod.mysql_vuln_query_builder import MySQLVulnerabilityQueryBuilder


class AllDatabaseCheckGeneration(CheckGenerationBase):

    def __init__(self, list_db_name):
        super().__init__(list_db_name)

    def get_all_mongo_values(self):
        all_records = self.read_cve_records_from_local_db()
        dbs = ["hanadb", "mariadb", "mysqldb", "postgredb", "db2db", "mssqldb", "sybasedb", "oracledb", "mongodb"]

        for record in all_records:
            try:
                if record[0] in dbs:
                    if record[0] == 'hanadb':
                        self.logger.info(15 * "#" + " Hanadb Check Generation Starts " + 15 * "#")
                        self.generate_hanadb_checks(record[1])
                    if record[0] == 'mariadb':
                        self.logger.info(15 * "#" + "Mariadb Check Generation Starts " + 15 * "#")
                        self.generate_mariadb_checks(record[1])
                    if record[0] == 'mysqldb':
                        self.logger.info(15 * "#" + " MySQLdb Check Generation Starts " + 15 * "#")
                        self.generate_mysqldb_checks(record[1])
                    if record[0] == 'postgredb':
                        self.logger.info(15 * "#" + " Postgredb Check Generation Starts " + 15 * "#")
                        self.generate_postgredb_checks(record[1])
                    if record[0] == 'db2db':
                        self.logger.info(15 * "#" + " DB2db Check Generation Starts " + 15 * "#")
                        self.generate_db2db_checks(record[1])
                    if record[0] == 'mssqldb':
                        self.logger.info(15 * "#" + " MSsqldb Check Generation Starts " + 15 * "#")
                        self.generate_mssqldb_checks(record[1])
                    if record[0] == 'sybasedb':
                        self.logger.info(15 * "#" + " Sybasedb Check Generation Starts " + 15 * "#")
                        self.generate_sybasedb_checks(record[1])
                    if record[0] == 'oracledb':
                        self.logger.info(15 * "#" + " Oracledb Check Generation Starts " + 15 * "#")
                        self.generate_oracledb_checks(record[1])
                    if record[0] == 'mongodb':
                        self.logger.info(15 * "#" + " MongoDB Check Generation Starts " + 15 * "#")
                        self.generate_mongodb_checks(record[1])
                else:
                    if "patch" not in record[0]:
                        self.logger.error(f"Unhandled record DBMS type: {record}")
            except IndexError:
                self.logger.error(f"Unable to determine record DBMS type: {record}")

    @staticmethod
    def etree_to_string(content):
        if isinstance(content, (ElementTree.ElementTree, ElementTree.Element)):
            return ElementTree.tostring(content)
        return str(content)

    @staticmethod
    def _normalize_hana_affected_versions(affected_version):
        """
        Convert heterogeneous HANA affected-version payloads into the strict
        triplet list expected by `get_hana_query`:
        ["SAP HANA DATABASE 1.0", "SP000", "118", ...]
        """
        if not affected_version:
            return []

        # Flatten mixed payloads to text chunks.
        if isinstance(affected_version, list):
            chunks = [str(v) for v in affected_version if v is not None]
        else:
            chunks = [str(affected_version)]

        merged_text = " ".join(chunks)
        triples = []

        # Case 1: Already in legacy triplet format from SAP note parsing.
        if isinstance(affected_version, list) and len(affected_version) >= 3:
            for i in range(0, len(affected_version), 3):
                grp = affected_version[i:i + 3]
                if len(grp) < 3:
                    continue
                product, sp_token, build_token = [str(x).strip() for x in grp]
                if (
                        'SAP HANA DATABASE' in product.upper()
                        and re.search(r'\bSP\d{1,3}\b', sp_token.upper())
                        and re.search(r'\d+', build_token)
                ):
                    sp_digits = int(re.findall(r'\d+', sp_token)[0])
                    build_digits = re.findall(r'\d+', build_token)[0]
                    major_match = re.search(r'([12](?:\.0)?)', product)
                    major = major_match.group(1) if major_match else '1.0'
                    if major in ('1', '2'):
                        major = major + '.0'

                    if int(build_digits) == 0:
                        normalized_build = '00'
                    elif build_digits.startswith('0') and len(build_digits) <= 2:
                        normalized_build = build_digits
                    else:
                        normalized_build = str(int(build_digits))

                    triples.append((
                        f"SAP HANA DATABASE {major}",
                        f"SP{sp_digits:03d}",
                        normalized_build
                    ))

        # Case 2: Dotted versions from NVD/CVE descriptions, e.g. 1.00.122.24
        # or from fallback keys like versionEndExcluding=2.00.037.00.
        dotted_matches = re.findall(r'\b([12])\.00\.(\d{2,3})\.(\d{1,4})\b', merged_text)
        for major, sp_raw, build_raw in dotted_matches:
            if int(build_raw) == 0:
                normalized_build = '00'
            elif build_raw.startswith('0') and len(build_raw) <= 2:
                normalized_build = build_raw
            else:
                normalized_build = str(int(build_raw))

            triples.append((
                f"SAP HANA DATABASE {major}.0",
                f"SP{int(sp_raw):03d}",
                normalized_build
            ))

        # De-duplicate and flatten back to expected legacy list format.
        dedup = []
        seen = set()
        for t in triples:
            if t not in seen:
                seen.add(t)
                dedup.append(t)

        normalized = []
        for product, sp_token, build_token in dedup:
            normalized.extend([product, sp_token, build_token])

        return normalized

    @staticmethod
    def _oracle_advisory_sort_key(record):
        """
        TEMPORARY: chronological sort key (year, month) taken from the advisory URL, e.g. cspuaug2026.html -> (2026, 8).
        Records whose link cannot be parsed sort last (and keep their relative order, sorted() is stable).
        """
        months = {'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6,
                  'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12}
        link = record.get('link') if isinstance(record, dict) else None
        # Original (commented out temporarily): only matched advisory URLs, i.e. '...cspuaug2026.html':
        # match = re.search(r'c(?:s)?pu([a-z]{3})(\d{4})\.html', str(link or ''), re.IGNORECASE)
        # TEMPORARY: also accept the intermediate file name form '...cspuaug2026_<timestamp>.xml' (merge-order sort).
        match = re.search(r'c(?:s)?pu([a-z]{3})(\d{4})(?:\.html|_)', str(link or ''), re.IGNORECASE)
        if not match or match.group(1).lower() not in months:
            return 9999, 99
        return int(match.group(2)), months[match.group(1).lower()]

    def generate_oracledb_checks(self, oracle_records):
        # TEMPORARY: the crawl of several advisories is concurrent, so rows reach SQLite (and therefore this loop)
        # in arbitrary order. The per-major ID counter must follow Aug -> Sep -> Oct, so process the records in
        # chronological advisory order. Original behaviour (commented out): iterate in storage order.
        # oracle_records = oracle_records
        oracle_records = sorted(oracle_records, key=self._oracle_advisory_sort_key)
        self._run_suffix = datetime.now().strftime('%Y%m%d_%H%M%S')
        version_regex = r'(?:{0})\.\d+(?:\.\d+)?(?:\.\d+)?(?:-\d+\.\d+(?:\.\d+)?(?:\.\d+)?)?'.format(
            self._oracle_target_versions)
        target_majors = [int(m) for m in self._oracle_target_versions.split('|') if m.isdigit()]
        version_counters = {}
        for oracle_record in oracle_records:
            item, status = self.check_for_success(oracle_record)
            if not status:
                try:
                    affected_version = re.findall(version_regex, item['affected_version'])
                    if 'Java VM' in item['component']:
                        jvm_results = self.oracle_java_vm_processing(affected_version, item, target_majors, version_counters)
                        for query, new_id, major_str in jvm_results:
                            if int(major_str) == 11:
                                my_root = self.parse_xml_template(join(dirname(__file__), 'template', 'oracle_template', 'Oracle_JavaVM_11.xml'))
                            else:
                                my_root = self.parse_xml_template(join(dirname(__file__), 'template', 'oracle_template', 'Oracle_nonjvm_modern.xml'))
                            response = self.set_tags_in_checks(query, new_id, my_root, item, status, major_str + 'c')
                            self.logger.debug(self.etree_to_string(response[0]))
                    else:
                        for major in target_majors:
                            major_ranges = [v for v in affected_version
                                            if re.match(r'^{0}\.'.format(major), v.strip())]
                            if not major_ranges:
                                continue
                            query, new_id, length = self.oracle_no_java_vm_processing(
                                major_ranges, item, major, version_counters)
                            if major == 11:
                                my_root = self.parse_xml_template(join(dirname(__file__), 'template', 'oracle_template', 'Oracle_nonjvm_11.xml'))
                            else:
                                my_root = self.parse_xml_template(join(dirname(__file__), 'template', 'oracle_template', 'Oracle_nonjvm_modern.xml'))
                            response = self.set_tags_in_checks(query, new_id, my_root, item, status, str(major) + 'c')
                            self.logger.debug(self.etree_to_string(response[0]))
                    self.append_db_with_check_generation_status(
                        'reported', datetime.now(), item['cve_no'], item['name'], 'cve_no')
                except (AttributeError, IndexError) as Ae:
                    self.logger.exception("Check generation for cve {0} failed".format(item['cve_no']), str(Ae))
                except TypeError as Te:
                    self.logger.exception("Check generation for cve {0} failed".format(item['cve_no']), str(Te))
            else:
                self.logger.info("No new Check found for {0}".format(oracle_record['name']))

        self.initiate_checkmate_server_update("oracledb")

    def generate_sybasedb_checks(self, sybase_records):
        self._run_suffix = datetime.now().strftime('%Y%m%d_%H%M%S')
        for sybase_record in sybase_records:
            item, status = self.check_for_success(sybase_record)
            try:
                if not status:
                    item_id, previous_query = self.get_test_id_from_checkmate_db('SYVULN')
                    query = self.query_construct(previous_query, item)
                    my_root = self.parse_xml_template(join(dirname(__file__), 'template', 'MSSQL.xml'))
                    affected_version_to_string = ' '.join(item['affected_version'])
                    non_duplicate_list = sorted(list(
                        set(re.findall(self.get_regex_values("sybase_vuln_no_duplicate"), affected_version_to_string))))
                    response = self.set_tags_in_checks(query, item_id, my_root, item, status, non_duplicate_list)
                    self.logger.debug(self.etree_to_string(response[0]))
                else:
                    self.logger.info("Check already generated for {0}".format(sybase_record['cve_no']))
            except (AttributeError, IndexError) as Ae:
                self.logger.exception('Failed to generate check for cve no {0} and affected version {1}: {2}'.format(
                    item['cve_no'], item['affected_version']), str(Ae))

    def generate_mssqldb_checks(self, mssql_records):
        self._run_suffix = datetime.now().strftime('%Y%m%d_%H%M%S')
        #item_id = self.get_test_id_from_checkmate_db('MSVULN')
        item_id = self.get_next_check_id('MSVULN', 'MSVULN245')
        for mssql_record in mssql_records:
            item, status = self.check_for_success(mssql_record)

            if not status:
                try:
                    query_mssql = self.get_static_values('mssql_base_query').format(item['cve_no'])
                    if item['affected_version']:
                        item["long_description"] = item["long_description"].replace("\\'", "\\\\'")
                        query, years = self.get_query_mssql(item['affected_version'], query_mssql)
                        my_root = self.parse_xml_template(join(dirname(__file__), 'template', 'MSSQL.xml'))
                        response = self.set_tags_in_checks(query, item_id, my_root, item, status, years)
                        if len(response) > 1:
                            if response[1] == 200:
                                self.logger.info(
                                    f"Checks are generated successfully for {item_id} and {item['cve_no']}")
                                item_id = self.increment_Tests_ID(item_id)
                            else:
                                self.logger.info(
                                    f"Check generation failed for {item_id} and {item['cve_no']}")
                        else:
                            self.logger.error("status not available.")

                        if not isinstance(response[0], ElementTree.Element):
                            self.logger.debug(response[0])
                        else:
                            self.logger.debug(ElementTree.tostring(response[0]))
                    self.append_db_with_check_generation_status(
                        'reported', datetime.now(), item['cve_no'], item['name'], 'cve_no')
                except Exception as Ge:
                    self.logger.error(
                        f"xml tags are not generated for mssql: {Ge}")
            else:
                self.logger.info(
                    f"{mssql_record['cve_no']} already exist in {mssql_record['name']}. Checking next cve in record.")

        self.save_next_check_id('MSVULN', item_id)
        self.initiate_checkmate_server_update("mssqldb")

    def generate_db2db_checks(self, db2_records):
        self._run_suffix = datetime.now().strftime('%Y%m%d_%H%M%S')
        #item_id = self.get_test_id_from_checkmate_db('DB2VULN')
        item_id = self.get_next_check_id('DB2VULN', 'DB2VULN572')
        for db2_record in db2_records:
            item, status = self.check_for_success(db2_record)
            if not status:
                try:
                    affected_versions = self.db2_get_version_list(item['affected_version'])
                    if affected_versions and item_id:
                        for affected_ver in affected_versions:
                            # Each entry is expected as [release, build_details] after chunking.
                            if all(item is not None for item in affected_ver):
                                affected_text = ' '.join([str(af) for af in affected_ver if af])
                                # Generate DB2 vuln check when either remediation signal is present.
                                has_any_sb_or_fp = (
                                        re.search(r'Special\s*Build\s*\d+', affected_text, re.IGNORECASE)
                                        or re.search(r'Fix\s*Pack\s*\d+', affected_text, re.IGNORECASE)
                                )
                                if has_any_sb_or_fp:
                                    my_root = self.parse_xml_template(join(dirname(__file__), 'template', 'DB2.xml'))
                                    query, version = self.get_query_db2(item['cve_no'], affected_ver)
                                    if query and version and query != 'null' and version != 'null':
                                        response = self.set_tags_in_checks(query, item_id, my_root, item, status,
                                                                           version)
                                        item_id = self.increment_Tests_ID(item_id)
                                        self.logger.debug(self.etree_to_string(response[0]))
                                    else:
                                        self.logger.warning(
                                            f"Failed to generate a check for DB2 {item['cve_no']} due to invalid release/build data")
                                else:
                                    self.logger.warning(
                                        f"Failed to generate a check for DB2 {item['cve_no']} Special build and Fix pack missing")
                            else:
                                self.logger.warning(
                                    f"Failed to generate a check for DB2 {item['cve_no']} i.e. {str(affected_ver)}. Invalid affected_versions or item_id")
                    else:
                        self.logger.warning(
                            f"Failed to generate check for DB2 {item['cve_no']}. Invalid affected_versions or item_id")
                except (AttributeError, IndexError) as Ae:
                    self.logger.exception(
                        'Failed to generate check for cve no {0} and affected version {1}: {2}'.format(
                            item['cve_no'], item['affected_version']), str(Ae))
            else:
                self.logger.info(
                    f"{db2_record['cve_no']} already exist in {db2_record['name']}. Checking next cve in record.")

        self.save_next_check_id('DB2VULN', item_id)
        self.initiate_checkmate_server_update("db2db")

    def generate_postgredb_checks(self, postgre_records):
        self._run_suffix = datetime.now().strftime('%Y%m%d_%H%M%S')
        #item_id = self.get_test_id_from_checkmate_db('PGVULN')
        item_id = self.get_next_check_id('PGVULN', 'PGVULN613')
        for postgre_record in postgre_records:
            self.logger.debug(f"current cve: {postgre_record.get('cve_no')}")
            item, status = self.check_for_success(postgre_record)
            if not status:
                try:
                    affected_versions = item.get("affected_version", "")
                    af_list = [af.strip() for af in affected_versions.split(",")]
                    supported_vers_re = self.get_regex_values("postgre_vuln_affected_version")
                    # KNOWN: If affected_version contains bare major versions (e.g. "16, 15")
                    # instead of major.minor (e.g. "16.8, 15.11"), all entries fail this regex
                    # and no checks are generated for the CVE. The spider guarantees major.minor
                    # format via its "Fixed" column extraction; this only fails if the upstream
                    # page structure changes. Fix: add a format-validation step in the spider
                    # and raise a warning when bare major versions are returned.
                    af_list = [af for af in af_list if re.match(supported_vers_re, af)]
                    if af_list and item_id:
                        for affected_ver in af_list:
                            if affected_ver:
                                # KNOWN ISSUE: parse_xml_template re-reads the XML template from
                                # disk on every affected_ver iteration because set_tags_in_checks
                                # mutates my_root in place. Fix: parse once before the loop and
                                # use copy.deepcopy(template_root) per iteration to avoid the I/O.
                                my_root = self.parse_xml_template(join(dirname(__file__), 'template', 'PGSQL.xml'))
                                query, affected = self.get_query_general_db(affected_ver, item)
                                is_ver_gt_9 = self.__class__.is_integer_part_greater_than(affected, 9)
                                major_affected_ver = self.__class__.get_integer_part(affected) if is_ver_gt_9 else affected
                                response = self.set_tags_in_checks(query, item_id, my_root, item, status, major_affected_ver)
                                if len(response) > 1:
                                    if response[1] == 200:
                                        self.logger.info(
                                            f"Checks are generated successfully for {item_id} and {item['cve_no']}")
                                        item_id = self.increment_Tests_ID(item_id)
                                    else:
                                        self.logger.info(
                                            f"Check generation failed for {item_id} and {item['cve_no']}")
                                else:
                                    self.logger.error("status not available.")
                                self.logger.debug(self.etree_to_string(response[0]))
                            else:
                                self.logger.warning(
                                    f"Failed to generate one check for PostgreSQL {item['cve_no']}. Invalid affected_versions {str(affected_ver)}")
                    else:
                        self.logger.warning(f"No supported affected versions detected ({item['affected_version']}), unable to generate check")
                    self.append_db_with_check_generation_status(
                        'reported', datetime.now(), item['cve_no'], item['name'], 'cve_no')
                except (AttributeError, IndexError) as Ae:
                    self.logger.exception(
                        'Failed to generate check for cve no {0} and affected version {1}: {2}'.format(
                            item['cve_no'], item['affected_version'], str(Ae)))
                except TypeError as Te:
                    self.logger.exception("TypeError in generate_postgredb_checks" + str(Te))
                except Exception as e:
                    self.logger.exception("Exception in generate_postgredb_checks" + str(e))
            else:
                self.logger.info(f"{postgre_record['cve_no']} already exist in {postgre_record['name']}. Checking next cve in record.")

        self.save_next_check_id('PGVULN', item_id)
        self.initiate_checkmate_server_update("postgredb")
        
    def generate_mysqldb_checks(self, mysql_records):
        self._run_suffix = datetime.now().strftime('%Y%m%d_%H%M%S')
        #item_id = self.get_test_id_from_checkmate_db('MYVULN')
        item_id = self.get_next_check_id('MYVULN', 'MYVULN2446')
        for mysql_record in mysql_records:
            item, status = self.check_for_success(mysql_record)
            if not status:
                try:
                    #affected_versions = re.findall(self.get_regex_values("mysql_vuln_affected_version"), item['affected_version'])
                    affected_versions = MySQLVulnerabilityQueryBuilder.generate_list_from_affected_versions(item['affected_version']) if item else []
                    if affected_versions:
                        for affected_ver in affected_versions:
                            # Skip MySQL 9.x — check generation for major version 9 is not yet
                            # supported. The major version is the first dot-separated component,
                            # e.g. "9.7.0-9.7.1" → "9", "8.4.0-8.4.10" → "8".
                            if affected_ver.split(".")[0].strip() == "9":
                                self.logger.info(
                                    f"Skipping MySQL 9.x '{affected_ver}' for {item['cve_no']} — not yet supported.")
                                continue

                            # Guard: only process same-minor version ranges (e.g. "8.4.0-8.4.10").
                            # Cross-minor ranges (e.g. "8.0.0-8.4.10") are skipped because the
                            # SQL query compares only the patch number and cannot safely span minors.
                            # Non-range strings ("8.0.36 and prior", single versions) always pass.
                            # KNOWN ISSUE: whitespace-sensitive — "8.0.20 - 8.0.22" (spaces around
                            # hyphen) yields " 8.0.22" from split("-")[1], making split(".")[:2]
                            # return [" 8", "0"] ≠ ["8", "0"] and silently skips a valid range.
                            is_same_minor_range = (
                                        "-" in affected_ver and affected_ver.split("-")[0].split(".")[:2] ==
                                        affected_ver.split("-")[1].split(".")[:2])
                            if not is_same_minor_range and "-" in affected_ver:
                                continue

                            # Load the MySQL XML check template.
                            my_root = self.parse_xml_template(join(dirname(__file__), 'template', 'MySQL.xml'))

                            # Build the vulnerability SQL query and normalise affected_ver to
                            # major.minor (e.g. "8.4.0-8.4.10" → "8.4") for check tagging.
                            query, affected = MySQLVulnerabilityQueryBuilder.get_query_general_db(item['cve_no'], affected_ver)
                            affected_ver = MySQLVulnerabilityQueryBuilder.extract_minor_versions(affected)
                            response = self.set_tags_in_checks(query, item_id, my_root, item, status, affected_ver)
                            if len(response) > 1:
                                if response[1] == 200:
                                    self.logger.info(
                                        f"Checks are generated successfully for {item_id} and {item['cve_no']}")
                                    item_id = self.increment_Tests_ID(item_id)
                                else:
                                    self.logger.info(
                                        f"Check generation failed for {item_id} and {item['cve_no']}")
                            else:
                                self.logger.error("status not available.")
                            self.logger.debug(self.etree_to_string(response[0]))
                    self.append_db_with_check_generation_status(
                        'reported', datetime.now(), item['cve_no'], item['name'], 'cve_no')
                except (AttributeError, IndexError) as Ae:
                    self.logger.exception(
                        'Failed to generate MySQL check for cve no {0} and affected version {1}: {2}'.format(
                            item['cve_no'], item['affected_version'], str(Ae)))
            else:
                self.logger.info(
                    f"{mysql_record['cve_no']} already exist in {mysql_record['name']}. Checking next cve in record.")

        self.save_next_check_id('MYVULN', item_id)
        self.initiate_checkmate_server_update("mysqldb")

    def generate_mariadb_checks(self, maria_records):
        self._run_suffix = datetime.now().strftime('%Y%m%d_%H%M%S')
        #item_id = self.get_test_id_from_checkmate_db('MARIAVULN')
        item_id = self.get_next_check_id('MARIAVULN', 'MARIAVULN505')
        for maria_record in maria_records:
            item, status = self.check_for_success(maria_record)
            if not status:
                try:
                    affected_versions = re.findall(self.get_regex_values("maria_vuln_affected_version"),
                                                   item['affected_version'])
                    if affected_versions and item_id:
                        for affected_ver in affected_versions:
                            my_root = self.parse_xml_template(join(dirname(__file__), 'template', 'MariaDB.xml'))
                            query, affected = self.get_query_general_db(affected_ver, item)
                            affected_ver = '.'.join(affected_ver.split('.')[0:2])
                            response = self.set_tags_in_checks(query, item_id, my_root, item, status, affected_ver)
                            if len(response) > 1:
                                if response[1] == 200:
                                    self.logger.info(
                                        f"Checks are generated successfully for {item_id} and {item['cve_no']}")
                                    item_id = self.increment_Tests_ID(item_id)
                                else:
                                    self.logger.info(
                                        f"Check generation failed for {item_id} and {item['cve_no']}")
                            else:
                                self.logger.error("status not available.")
                            self.logger.debug(self.etree_to_string(response[0]))
                except (AttributeError, IndexError) as Ae:
                    self.logger.exception(
                        'Failed to generate MariaDB check for cve no {0} and affected version {1}: {2}'.format(
                            item['cve_no'], item['affected_version']), str(Ae))
            else:
                self.logger.info(
                    f"{maria_record['cve_no']} already exist in {maria_record['name']}. Checking next cve in record.")

        self.save_next_check_id('MARIAVULN', item_id)
        self.initiate_checkmate_server_update("mariadb")

    def generate_mongodb_checks(self, mongodb_records):
        """
        Generate Checkmate XML checks for MongoDB Server vulnerability records.

        Each CVE in ``mongodb_records`` produces one XML check containing all
        supported affected version ranges extracted by the MongoDB spider.

        The ``affected_version`` field is a semicolon-separated string of
        version span tokens produced by the spider, e.g.::

            "8.3.0 affects 8.3.3 and prior; 6.0.0 affects 6.0.18 and prior"

        Each token is parsed with one of two patterns:
        - hyphen range:  "X.Y.Z - X.Y.W"  (lower_bound, fixed_version explicit)
        - affects prose: "X.Y.Z affects X.Y.W and prior"
          (fixed_version = W+1, as the query uses an exclusive upper bound)

        The generated query evaluates semver ranges with this logic:
            installed_version >= lower_bound AND installed_version < fixed_version

        This avoids lexicographical string comparisons and aligns with NVD
        CPE range semantics (end version is exclusive).
        """
        self._run_suffix = datetime.now().strftime('%Y%m%d_%H%M%S')
        # item_id = self.get_test_id_from_checkmate_db('MDBVULN')
        item_id = self.get_next_check_id('MDBVULN', 'MDBVULN001')
        for mongodb_record in mongodb_records:
            item, status = self.check_for_success(mongodb_record)
            if not status:
                try:
                    raw_affected = item.get('affected_version', '')
                    # Split the comma-separated version range string produced
                    # by the spider into individual tokens.
                    affected_versions = [
                        v.strip() for v in str(raw_affected).split(';')
                        if v.strip()
                    ]
                    # Filter to tokens that look like MongoDB version strings
                    # (Major.Minor or Major.Minor.Patch or a range thereof).
                    supported_re = self.get_regex_values('mongodb_vuln_affected_version')
                    affected_versions = [
                        v for v in affected_versions
                        if re.search(supported_re, v)
                    ]

                    if not affected_versions:
                        self.logger.warning(
                            'No supported affected versions detected (%s), '
                            'unable to generate check for %s',
                            raw_affected, item.get('cve_no'),
                        )
                        continue

                    parsed_ranges = []
                    for affected_ver in affected_versions:
                        if not affected_ver:
                            continue

                        range_match = re.search(
                            r'(\d+\.\d+\.\d+)\s*-\s*(\d+\.\d+\.\d+)',
                            str(affected_ver)
                        )
                        affects_match = None
                        if not range_match:
                            # Spider format: "8.3.0 affects 8.3.3 and prior"
                            affects_match = re.search(
                                r'(\d+\.\d+\.\d+)\s+affects\s+(\d+\.\d+\.\d+)\s+and\s+prior',
                                str(affected_ver),
                                re.IGNORECASE,
                            )

                        if not range_match and not affects_match:
                            self.logger.warning(
                                'Skipping unsupported MongoDB affected range token for %s: %s',
                                item.get('cve_no', '<unknown>'), affected_ver
                            )
                            continue

                        if range_match:
                            lower_bound, fixed_version = range_match.groups()
                        else:
                            # "X.Y.Z affects X.Y.W and prior" — last vulnerable is W (inclusive);
                            # the query uses an exclusive upper bound, so fixed_version = W+1.
                            lower_bound = affects_match.group(1)
                            last_vuln = affects_match.group(2)
                            parts = last_vuln.rsplit('.', 1)
                            try:
                                fixed_version = '{}.{}'.format(parts[0], int(parts[1]) + 1)
                            except (ValueError, IndexError):
                                fixed_version = last_vuln

                        # Keep checks aligned to supported branch coverage only.
                        # Legacy open-ended branches (e.g. 3.6/4.0/4.2) are not
                        # generated as check ranges in this flow.
                        major_minor = '.'.join(lower_bound.split('.')[:2])
                        if major_minor not in ['4.4', '5.0', '6.0', '7.0', '8.0', '8.2']:
                            self.logger.info(
                                'Skipping unsupported MongoDB branch range for %s: %s - %s',
                                item.get('cve_no', '<unknown>'),
                                lower_bound,
                                fixed_version
                            )
                            continue

                        normalized_lower = '{}.0'.format(major_minor)
                        parsed_ranges.append((normalized_lower, fixed_version))

                    # De-duplicate while preserving order.
                    dedup_ranges = []
                    seen_ranges = set()
                    for lower_bound, fixed_version in parsed_ranges:
                        key = (lower_bound, fixed_version)
                        if key not in seen_ranges:
                            seen_ranges.add(key)
                            dedup_ranges.append(key)

                    if not dedup_ranges:
                        self.logger.warning(
                            'No supported MongoDB branch ranges found (%s), unable to generate check for %s',
                            raw_affected, item.get('cve_no'),
                        )
                        continue

                    ranges_js = ','.join(
                        "['{0}','{1}']".format(lower_bound, fixed_version)
                        for lower_bound, fixed_version in dedup_ranges
                    )
                    normalized_affected_ver = ', '.join(
                        '{0} - {1}'.format(lower_bound, fixed_version)
                        for lower_bound, fixed_version in dedup_ranges
                    )

                    my_root = self.parse_xml_template(
                        join(dirname(__file__), 'template', 'MongoDB.xml')
                    )
                    query = self.get_static_values('mongodb_query').format(
                        item['cve_no'], ranges_js
                    )
                    response = self.set_tags_in_checks(
                        query, item_id, my_root, item, status, normalized_affected_ver
                    )
                    if len(response) > 1:
                        if response[1] == 200:
                            self.logger.info(
                                f"Checks are generated successfully for {item_id} and {item['cve_no']}")
                            item_id = self.increment_Tests_ID(item_id)
                        else:
                            self.logger.info(
                                f"Check generation failed for {item_id} and {item['cve_no']}")
                    else:
                        self.logger.error("status not available.")
                    self.logger.debug(self.etree_to_string(response[0]))
                    self.append_db_with_check_generation_status(
                        'reported', datetime.now(), item['cve_no'], item['name'], 'cve_no')

                except (AttributeError, IndexError) as exc:
                    self.logger.exception(
                        'Failed to generate MongoDB check for CVE %s: %s',
                        item.get('cve_no', '<unknown>'), str(exc),
                    )
                except Exception as exc:
                    self.logger.exception(
                        'Unexpected error generating MongoDB check for CVE %s: %s',
                        item.get('cve_no', '<unknown>'), str(exc),
                    )
            else:
                self.logger.info(
                    '%s already exists in %s. Checking next CVE.',
                    mongodb_record.get('cve_no', '<unknown>'),
                    mongodb_record.get('name', 'mongodb'),
                )

        self.save_next_check_id('MDBVULN', item_id)
        self.initiate_checkmate_server_update('mongodb')

    def generate_hanadb_checks(self, hana_records):
        self._run_suffix = datetime.now().strftime('%Y%m%d_%H%M%S')
        item_id = self.get_next_check_id('HANAVULN', 'HANAVULN083')
        for hana_record in hana_records:
            item, status = self.check_for_success(hana_record)
            try:
                if not status:
                    # query = self.get_hana_query(item['affected_version'])
                    normalized_affected = self._normalize_hana_affected_versions(item.get('affected_version'))
                    if not normalized_affected:
                        self.logger.warning(
                            "Skipping HANA CVE %s due to unsupported affected_version format: %s",
                            item.get('cve_no'),
                            item.get('affected_version')
                        )
                        continue

                    # Keep the payload consistent for tags/check metadata too.
                    item['affected_version'] = normalized_affected
                    query = self.get_hana_query(normalized_affected)
                    if not query:
                        self.logger.warning(
                            "Skipping HANA CVE %s due to empty generated query from affected_version=%s",
                            item.get('cve_no'),
                            normalized_affected
                        )
                        continue
                    my_root = self.parse_xml_template(join(dirname(__file__), 'template', 'Hana.xml'))
                    response = self.set_tags_in_checks(query, item_id, my_root, item, status, item['affected_version'])
                    self.logger.debug(self.etree_to_string(response[0]))
                    item_id = self.increment_Tests_ID(item_id)
                else:
                    self.logger.info("No new Check found for {0}".format(hana_record['name']))
            except (AttributeError, IndexError) as Ae:
                self.logger.exception("Failed to generate check: " + str(Ae))

        self.save_next_check_id('HANAVULN', item_id)
        self.initiate_checkmate_server_update("hanadb")

    def increment_Tests_ID(self, testID):
        # Find the numeric part at the end of the current Tests ID
        number = re.search(r'(\d+)$', testID).group(1)
        # Increment the number and return the new Tests ID
        return testID[:-len(number)] + str(int(number) + 1)

    def decrement_Tests_ID(self, testID):
        # Find the numeric part at the end of the current Tests ID
        number = re.search(r'(\d+)$', testID).group(1)
        # Increment the number and return the new Tests ID
        return testID[:-len(number)] + str(int(number) - 1)

    def initiate_checkmate_server_update(self, db_name):
        # Generate a timestamp string for filenames
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        is_success = self.generate_importable_smaller_files(db_name, timestamp)
        if not is_success:
            self.logger.error(f"Failed to generate importable files for {db_name}.")
            return
        # Delete all intermediate tests_output files for this db (may have bulletin/timestamp suffixes)
        output_dir = self._db_output_dir(db_name)
        for intermediate_file in glob.glob(join(output_dir, f"tests_output_{db_name}*.xml")):
            is_deleted = self.delete_file(intermediate_file)
            if not is_deleted:
                self.logger.error(f"Failed to delete {intermediate_file}")
        self.upload_files_to_checkmate(db_name, timestamp)

    def generate_importable_smaller_files(self, db_name, timestamp):
        try:
            output_dir = self._db_output_dir(db_name)
            os.makedirs(output_dir, exist_ok=True)

            # Collect all intermediate tests_output files for this db.
            # The writer may append a bulletin name and/or timestamp suffix
            # (e.g. tests_output_oracledb_cpujul2026_20260826_123300.xml), so
            # use a glob pattern to find all matching files rather than a fixed name.
            # Original (commented out temporarily): plain alphabetical order of the file names. For Oracle the file
            # names carry the advisory (tests_output_oracledb_<cpuoct2026|cspuaug2026|cspusep2026>_<ts>.xml), so this
            # put October before August and September in the final chunk file even though the IDs were numbered
            # Aug -> Sep -> Oct.
            # db_xml_files = sorted(glob.glob(join(output_dir, f"tests_output_{db_name}*.xml")))
            # TEMPORARY: for Oracle only, merge the intermediate files in chronological advisory order (year, month
            # taken from the file name), then by file name; every other DBMS keeps the original alphabetical order.
            db_xml_files = glob.glob(join(output_dir, f"tests_output_{db_name}*.xml"))
            if db_name == 'oracledb':
                db_xml_files = sorted(db_xml_files, key=lambda f: (
                    self._oracle_advisory_sort_key({'link': os.path.basename(f)}), os.path.basename(f)))
            else:
                db_xml_files = sorted(db_xml_files)
            if not db_xml_files:
                self.logger.info(f"No new checks to chunk for {db_name} (no tests_output files found).")
                return True

            # Read and combine all intermediate files into one XML string.
            # New files are written as UTF-8; keep a cp1252 fallback for older Windows-encoded files.
            xml_parts = []
            for db_xml_file in db_xml_files:
                try:
                    with open(db_xml_file, "r", encoding="utf-8") as f:
                        xml_parts.append(f.read())
                except UnicodeDecodeError:
                    with open(db_xml_file, "r", encoding="cp1252") as f:
                        xml_parts.append(f.read())
            raw_xml = "\n".join(xml_parts)

            # Wrap with a root element to parse multiple <Tests> entries
            wrapped_content = f"<root>{raw_xml}</root>"
            new_root = ElementTree.fromstring(wrapped_content)
            new_tests = new_root.findall("Tests")

            # Collect existing check IDs from retained chunk files in this DB's output folder.
            # Deduplicate by ID (not CVE) so that multiple checks for the same CVE (e.g. one
            # per Oracle major version: 19c, 21c) are each retained as distinct entries.
            existing_ids = set()
            for filename in os.listdir(output_dir):
                if filename.startswith("dataroot_output_") and filename.endswith(".xml"):
                    try:
                        tree = ElementTree.parse(join(output_dir, filename))
                        dataroot = tree.getroot()
                        for test in dataroot.findall("Tests"):
                            id_elem = test.find("ID")
                            if id_elem is not None:
                                existing_ids.add(id_elem.text)
                    except Exception:
                        continue  # Skip malformed or unreadable files

            # Filter new <Tests> by check ID — deduplicate against existing chunks AND within
            # new_tests itself.  Using ID (not CVE) means a CVE covered by both 19c and 21c
            # checks produces two distinct entries rather than one.
            seen_ids = set(existing_ids)
            unique_new_tests = []
            for test in new_tests:
                id_elem = test.find("ID")
                if id_elem is not None and id_elem.text not in seen_ids:
                    seen_ids.add(id_elem.text)
                    unique_new_tests.append(test)

            # Split the unique tests into chunks
            def chunk_tests(tests, chunk_size):
                for i in range(0, len(tests), chunk_size):
                    yield tests[i:i + chunk_size]

            # Write each chunk to a timestamped XML file in the DB's output folder
            for idx, chunk in enumerate(chunk_tests(unique_new_tests, self._chunk_size), start=1):
                dataroot = ElementTree.Element("dataroot")
                for test in chunk:
                    dataroot.append(test)
                tree = ElementTree.ElementTree(dataroot)
                output_filename = join(output_dir, f"dataroot_output_{db_name}_{timestamp}_{idx}.xml")
                tree.write(output_filename, encoding="utf-8", xml_declaration=True)

            # If all goes well, return True
            return True

        except Exception as e:
            self.logger.error(f"Failed to generate importable files for {db_name}: {e}")
            return False

    def upload_files_to_checkmate(self, db_name, timestamp):
        # Look for all files matching the pattern with the correct timestamp
        output_dir = self._db_output_dir(db_name)
        files_to_upload = sorted(glob.glob(join(output_dir, f"dataroot_output_{db_name}_{timestamp}_*.xml")))
        if not files_to_upload:
            self.logger.warning("No files found to import.")
        else:
            for file in files_to_upload:
                checkmate = None
                try:
                    #checkmate = CheckmateUI()
                    #opened = checkmate.open_page("Import Checks", "Import")
                    opened = True  # Temporary code to skip actual opening of Checkmate page
                    if opened:
                        #isFileImported = checkmate.choose_import_file_btn_and_submit(file) # Temporary skip file upload to server
                        """This is temporary code to skip actual upload to checkmate"""
                        isFileImported = False
                        self.updateCrawlerDB(isFileImported, file)
                    else:
                        self.logger.error(f"Unable to open Import page when attempting to upload {db_name} files")
                except Exception as e:
                    self.logger.error(f"Failed to upload {file}: {e}")
                finally:
                    if checkmate:
                        checkmate.cleanup()

    def updateCrawlerDB(self, isFileImported, file):
        items = self.parse_tests_from_xml(file)
        if items:
            # Proceed if items is not empty or None
            for item in items:
                Test_ID = item.get("ID")
                CVE = item.get("CVE")
                Type = item.get("Type")
                Severity = item.get("Severity")
                # uncomment below code to see all item values
                '''Test_x0020_Name = item.get("Test_x0020_Name")
                Query = item.get("Query")

                # Handle list or string values for Platforms and Tags
                platforms = item.get("Platforms")
                tags = item.get("Tags")
                Platforms = ", ".join(platforms) if isinstance(platforms, list) else platforms
                Tags = ", ".join(tags) if isinstance(tags, list) else tags

                Short_x0020_Description = item.get("Short_x0020_Description")
                Long_x0020_Description = item.get("Long_x0020_Description")
                LINKS = item.get("LINKS")

                # Optional fields (safe fallback to None if not present)
                TimeStamp_for_Check_generation = item.get("TimeStamp_for_Check_generation")
                Progress = item.get("Progress")'''
                db_name = self.get_db_name_from_testid(Test_ID)
                if isFileImported:
                    self.logger.info(f"Imported {Test_ID} in checkmate")
                    self.append_db_with_check_generation_status('success', datetime.now(), CVE, db_name, 'cve_no')
                    self.update_email_file_with_check(Type, db_name, CVE, Severity, "success")
                else:
                    self.update_email_file_with_check(Type, db_name, CVE, Severity, "reported")
                    self.append_db_with_check_generation_status('reported', datetime.now(), CVE, db_name, 'cve_no')
                    self.logger.info(f"Check {Test_ID} prepared for manual upload to checkmate")

            if isFileImported:
                self.delete_file(file)
            # else: keep file in check_outputs/{db_name}/ for manual upload and future reference
        else:
            self.logger.debug("Parsing failed or returned no items.")

    def parse_tests_from_xml(self, file):
        try:
            tree = ElementTree.parse(file)
            root = tree.getroot()
            db_items = []
            for test_elem in root.findall("Tests"):
                db_item = {}
                for child in test_elem:
                    # If multiple entries for same tag (like <Platforms> or <Tags>)
                    if child.tag in db_item:
                        if not isinstance(db_item[child.tag], list):
                            db_item[child.tag] = [db_item[child.tag]]
                        db_item[child.tag].append(child.text)
                    else:
                        # Handle nested <Value> inside Tags/Platforms/etc.
                        if list(child):  # has sub-elements
                            values = [sub.text for sub in child.findall("Value")]
                            db_item[child.tag] = values if values else child.text
                        else:
                            db_item[child.tag] = child.text
                db_items.append(db_item)

            return db_items
        except Exception as e:
            self.logger.error(f"Unable to parse Tests elements from  {file} : {e}")
            return []

    def rename_file_with_failed_import(self, file):
        # Check if the file exists
        if os.path.isfile(file):
            # Get the directory and file name from the file
            directory, file_name = os.path.split(file)

            # Split the file name into name and extension
            name, ext = os.path.splitext(file_name)

            # Create the new file name by appending 'import_failed'
            new_file_name = f"{name}_import_failed{ext}"

            # Create the new file path
            new_file = os.path.join(directory, new_file_name)

            # Rename the file
            os.rename(file, new_file)
            return new_file
        else:
            raise FileNotFoundError(f"The file {file} does not exist.")

    def delete_file(self, file_name):
        if os.path.exists(file_name):
            os.remove(file_name)
            print(f"{file_name} has been deleted.")
            return True
        else:
            print(f"{file_name} does not exist.")
            return False
