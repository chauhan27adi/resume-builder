import re
from check_generation_prod.check_generation_base import CheckGenerationBase
import calendar

_YEAR_STR = {'14.0': '2017', '15.0': '2019', '16.0': '2022'}


class AllDatabasePatchGeneration(CheckGenerationBase):

    def __init__(self, list_db_name=None):
        if list_db_name is None:
            list_db_name = self.get_static_values('supported_database_patch')
        super().__init__(list_db_name)
        self.severity = 1

    def get_all_patch_mongo_values(self):
        try:
            all_records = self.read_cve_records_from_local_db()
            for record in all_records:
                if record[0] == 'hanadb_patch':
                    self.generate_hanadb_patch_checks(record[1])
                elif record[0] == 'mariadb_patch':
                    self.generate_mariadb_patch_checks(record[1])
                elif record[0] == 'mysql_patch':
                    self.generate_mysqldb_patch_check(record[1])
                elif record[0] == 'postgre_patch':
                    self.generate_postgre_db_patch_check(record[1])
                elif record[0] == 'db2_patch':
                    self.generate_db2_db_patch_checks(record[1])
                elif record[0] == 'mssql_patch':
                    self.generate_mssql_db_patch_checks(record[1])
                elif record[0] == 'sybase_patch':
                    self.generate_sybase_db_patch_checks(record[1])
                elif record[0] == 'oracle_patch':
                    self.generate_oracle_db_patch_checks(record[1])

        except (AttributeError, IndexError, NameError) as err:
            self.logger.exception(str(err))

    def generate_mssql_db_patch_checks(self, mssql_records):
        for mssql_record in mssql_records:
            try:
                items, status = self.check_for_success(mssql_record)
                if not status:
                    cpv = str(items['current_patch_version'])
                    av = str(items['affected_version'])
                    # cpv format: "RTM:CU32:15.0.4420.2"
                    ver_prefix = cpv.split(':')[2][:4]  # "14.0" / "15.0" / "16.0"
                    if ver_prefix == '14.0':
                        static_value = self.get_static_values("MSSQL14")
                        template = self.get_static_values("mssql_patch_17")
                    elif ver_prefix == '15.0':
                        static_value = self.get_static_values("MSSQL15")
                        template = self.get_static_values("mssql_patch_19")
                    elif ver_prefix == '16.0':
                        static_value = self.get_static_values("MSSQL16")
                        template = self.get_static_values("mssql_patch_22")
                    else:
                        self.logger.warning('Unknown MSSQL version prefix %s', ver_prefix)
                        continue
                    if not static_value or not template:
                        self.logger.warning('Missing static values or template for MSSQL %s', ver_prefix)
                        continue
                    try:
                        av_cu_str = av.split(':')[2]
                    except IndexError:
                        self.logger.error('Invalid affected_version format: %s', av)
                        continue
                    versions = av_cu_str.split(';')
                    cu_number = cpv.split(':')[1][2:]  # "CU32" → "32"
                    year_str = _YEAR_STR[ver_prefix]
                    version_list = []
                    full_list = []
                    for v in versions[1:]:  # skip index 0 (latest CU — handled by else 'other')
                        parts = v.split('_')
                        if len(parts) != 2:
                            continue
                        build_short, cu_label = parts[0], parts[1]
                        version_list.append("when '{}' then '_{}'" .format(build_short, cu_label))
                        full_list.append("'{}_RTM_{}'".format(year_str, cu_label))
                    if not full_list:
                        self.logger.warning('No older CU entries for MSSQL %s', ver_prefix)
                        continue
                    patch = template.format(cu_number, "\n".join(version_list), ",".join(full_list))
                    # self.write_patch_check_to_checkmate(patch, self.severity, static_value[0],
                    #                                     static_value[1], static_value[2],
                    #                                     static_value[3], items)
                    self.write_patch_check_to_file(patch, items)
            except Exception as Ex:
                self.logger.exception(str(Ex))

    def get_patch_check_mssql(self, patch_id, regex, cu_fix_value, items, full_list_pattern):
        try:
            body = self.get_mssql_query_from_checmate(patch_id)
            full_list = re.findall(regex, str(body))
            versions_list = re.findall(self.get_regex_values("mssql_patch_version_list"), body)
            CU_version = re.findall(r"CU\d+", cu_fix_value)[0]
            CU_version_fix = cu_fix_value.split('.')[-2]
            string_builder_CU = "when '{0}' then '_{1}'".format(CU_version_fix, CU_version)
            versions_list.append(string_builder_CU)
            string_builder_full_list = full_list_pattern.format(re.findall(r'\d+', CU_version)[0])
            full_list.append(string_builder_full_list)
            return full_list, versions_list, re.findall(r'\d+', CU_version)[0]
        except IndexError as Ie:
            self.logger.exception(str(Ie))
        except (AttributeError, NameError) as Ae:
            self.logger.exception(str(Ae))

    def generate_oracle_db_patch_checks(self, oracle_records):

        for oracle_record in oracle_records:
            items, status = self.check_for_success(oracle_record)
            for item in items['current_patch_version']:
                if item:
                    try:
                        if '11.2.0.4' in str(item) and 'UNIX' in str(item):
                            patch_body = self.get_static_values('oracle_patch_11_unix')
                            patch = self.get_oracle_patch(item, patch_body, 'ora_unix_11')
                            static_value = self.get_static_values("ORACLE_patch_11_unix_static")

                        elif '11.2.0.4' in str(item) and 'Windows'.lower() in str(item).lower():
                            patch_body = self.get_static_values('oracle_patch_11_win')
                            patch = self.get_oracle_patch(item, patch_body, 'ora_win_11')
                            static_value = self.get_static_values("ORACLE_patch_11_win_static")

                        elif '12.1.0.2' in str(item) and 'UNIX'.lower() in str(item).lower():
                            patch_body = self.get_static_values('oracle_patch_12_unix')
                            patch = self.get_oracle_patch(item, patch_body, 'ora_unix_12')
                            static_value = self.get_static_values("ORACLE_patch_12_1_unix_static")

                        elif '12.1.0.2' in str(item) and 'Windows'.lower() in str(item).lower():
                            patch_body = self.get_static_values('oracle_patch_12_win')
                            patch = self.get_oracle_patch(item, patch_body, 'ora_win_12')
                            static_value = self.get_static_values("ORACLE_patch_12_1_win_static")

                        elif '12.2.0.1' in str(item) and 'UNIX'.lower() in str(item).lower():
                            patch_body = self.get_static_values('oracle_patch_12_2_unix')
                            patch = self.get_oracle_patch(item, patch_body, 'ora_unix_12_2')
                            static_value = self.get_static_values("ORACLE_patch_12_2_unix_static")

                        elif '12.2.0.1' in str(item) and 'Windows'.lower() in str(item).lower():
                            patch_body = self.get_static_values('oracle_patch_12_2_win')
                            patch = self.get_oracle_patch(item, patch_body, 'ora_win_12_2')
                            static_value = self.get_static_values("ORACLE_patch_12_2_win_static")
                        # self.write_patch_check_to_checkmate(patch, self.severity, static_value[0], static_value[1],
                        #                                     static_value[2], static_value[3], items)
                        self.write_patch_check_to_file(patch, items)

                    except (AttributeError, Exception) as Ae:
                        self.logger.exception(str(Ae))

    @classmethod
    def get_oracle_patch(cls, item, patch_oracle, version):
        patch_list = []

        date_without_dots = (re.findall(cls.get_regex_values("oracle_patch_dates"), str(item)))[0].split('.')[-1]
        month = calendar.month_name[int(date_without_dots[2:4])]
        year = '20' + date_without_dots[0:2]
        short_month = month[0:3]
        patches = re.findall(cls.get_regex_values("oracle_patch_patches"), str(item))
        for patch in patches:
            only_patch_number = patch.split(' ')[1]
            if re.findall(r'^2', only_patch_number):
                cls.logger.info(f"{only_patch_number} is not a supported patch")
            elif len(only_patch_number) > 5:
                patch_list.append(only_patch_number)

        patch_number_string = '/'.join(patch_list)
        month_year = month + " " + year
        if version == 'ora_unix_11':
            return str(patch_oracle).format(month_year, date_without_dots, short_month, patch_number_string)
        # elif version == 'ora_win_11':
        else:
            return str(patch_oracle).format(month_year, date_without_dots, patch_number_string)
        # elif version == 'ora_unix_12':
        #     return str(patch_oracle).format(month_year, date_without_dots, patch_number_string)
        # elif version == 'ora_win_12':
        #     return str(patch_oracle).format(month_year, date_without_dots, patch_number_string)
        # elif version == 'ora_unix_12_2':
        #     return str(patch_oracle).format(month_year, date_without_dots, patch_number_string)
        # elif version == 'ora_win_12_2':
        #     return str(patch_oracle).format(month_year, date_without_dots, patch_number_string)

    def generate_sybase_db_patch_checks(self, sybase_records):
        for sybase_record in sybase_records:
            item, status = self.check_for_success(sybase_record)
            if not status:
                patch_15_7 = item['current_patch_version'][0]
                patch_16 = item['current_patch_version'][1]
                check_15_7 = self.generate_check_15_7(patch_15_7)
                if isinstance(check_15_7, tuple):
                    self.write_patch_check_to_file(check_15_7[0], item)
                check_16_02 = self.generate_check_16_02(patch_16)
                if isinstance(check_16_02, tuple):
                    self.write_patch_check_to_file(check_16_02[0], item)
                check_16_03 = self.generate_check_16_03(patch_16)
                if isinstance(check_16_03, tuple):
                    self.write_patch_check_to_file(check_16_03[0], item)
                check_16_04 = self.generate_check_16_04(patch_16)
                if isinstance(check_16_04, tuple):
                    self.write_patch_check_to_file(check_16_04[0], item)

    @classmethod
    def generate_check_15_7(cls, patch_15_7):
        try:
            count = 0
            list_version = []
            query = []
            for i in range(len(patch_15_7)):
                if 'None' not in (patch_15_7[i]):
                    list_version.append(patch_15_7[i][1])
            list_version = list_version[::-1]
            for patch in list_version:
                count = count + 1
                if count < len(list_version):
                    if 'HF' in list_version[count]:
                        query.append("charindex(' {0} /',@@version) &gt; 0".format(patch))
                    else:
                        query.append("charindex(' {0} ',@@version) &gt; 0".format(patch))
                else:
                    query.append("charindex(' {0} ',@@version) &gt; 0".format(patch))

            query_tag_text = "charindex('ESD#',@@version) &gt; 0 or\n" + (' or \n '.join(query))
            check = CheckGenerationBase.get_static_values("sybase_patch")
            check = (check.format(query_tag_text, '15.7', 'SYPATCH011'))
            return check, 200

        except IndexError as err:
            cls.logger.exception(str(err))
            return 'Check generation failed {0} '.format(str(err))

    @classmethod
    def generate_check_16_02(cls, patch_16_02):
        try:
            count = 0
            query = []
            list_version = []
            for ver in patch_16_02:
                if 'SP02' in str(ver):
                    list_version.append(ver)
            list_version = list_version[::-1]
            for ver in list_version:
                count = count + 1
                if count < len(list_version):
                    if 'HF' in str(list_version[count]):
                        query.append("charindex(' {0} /',@@version) &gt; 0".format(ver[1]))
                    else:
                        query.append("charindex(' {0} ',@@version) &gt; 0".format(ver[1]))
                else:
                    query.append("charindex(' {0} ',@@version) &gt; 0".format(ver[1]))

            check = str(CheckGenerationBase.get_static_values('sybase_patch')).format(' or \n'.join(query), '16.0', 'SYPATCH012')

            return check, 200
        except IndexError as err:
            cls.logger.exception(str(err))
            return 'Check generation failed {0} '.format(str(err))

    @classmethod
    def generate_check_16_03(cls, patch_16_02):
        try:
            count = 0
            query = []
            list_version = []
            for ver in patch_16_02:
                if 'SP03' in str(ver):
                    list_version.append(ver)
            list_version = list_version[::-1]
            for ver in list_version:
                count = count + 1
                if count < len(list_version):
                    if 'HF' in str(list_version[count]):
                        query.append("charindex(' {0} /',@@version) &gt; 0".format(ver[1]))
                    else:
                        query.append("charindex(' {0} ',@@version) &gt; 0".format(ver[1]))
                else:
                    query.append("charindex(' {0} ',@@version) &gt; 0".format(ver[1]))

            check = str(CheckGenerationBase.get_static_values('sybase_patch')).format(' or \n'.join(query), '16.0', 'SYPATCH013')

            return check, 200
        except IndexError as err:
            cls.logger.exception(str(err))
            return 'Check generation failed {0} '.format(str(err))

    @classmethod
    def generate_check_16_04(cls, patch_16_02):
        try:
            count = 0
            query = []
            list_version = []
            for ver in patch_16_02:
                if 'SP04' in str(ver):
                    list_version.append(ver)
            list_version = list_version[::-1]
            for ver in list_version:
                count = count + 1
                if count < len(list_version):
                    if 'HF' in str(list_version[count]):
                        query.append("charindex(' {0} /',@@version) &gt; 0".format(ver[1]))
                    else:
                        query.append("charindex(' {0} ',@@version) &gt; 0".format(ver[1]))
                else:
                    query.append("charindex(' {0} ',@@version) &gt; 0".format(ver[1]))

            check = str(CheckGenerationBase.get_static_values('sybase_patch')).format(' or \n'.join(query), '16.0', 'SYPATCH014')

            return check, 200
        except IndexError as err:
            cls.logger.exception(str(err))
            return 'Check generation failed {0} '.format(str(err))

    def generate_mariadb_patch_checks(self, maria_records):
        for maria_record in maria_records:
            item, status = self.check_for_success(maria_record)
            if not status:
                maria_xml = self.get_static_values('maria_patch')
                try:
                    current_patch_without_dots = ''.join(item['current_patch_version'].split('.'))
                    current_base_patch = \
                    re.findall(self.get_regex_values("maria_patch_base"), item['current_patch_version'])[0]
                    static_values = self.get_static_values("MARIA" + str(current_base_patch))
                    patch_xml = maria_xml.format(static_values[-1], current_base_patch, item['current_patch_version'],
                                                 current_patch_without_dots)
                    # self.write_patch_check_to_checkmate(patch_xml, self.severity, static_values[0],
                    #                                     static_values[1], static_values[2],
                    #                                     static_values[3], item)
                    self.write_patch_check_to_file(patch_xml, item)

                except IndexError as Ie:
                    self.logger.exception(str(Ie))
                    return 'Failed to get xml', ''
                except ValueError as Ve:
                    self.logger.exception(str(Ve))
                    return 'Exception occurred while filling value in xml', ''

    def generate_mysqldb_patch_check(self, mysql_records):
        mysql_xml = self.get_static_values('mysql_patch')
        if not mysql_xml:
            self.logger.error('Missing mysql_patch template; skipping MySQL patch generation')
            return
        for mysql_record in mysql_records:
            item, status = self.check_for_success(mysql_record)
            if not status:
                try:
                    cpv = str(item['current_patch_version'])
                    parts = cpv.split('.')
                    if len(parts) < 3:
                        self.logger.warning('Unexpected MySQL cpv format: %s', cpv)
                        continue
                    family = '{}.{}'.format(parts[0], parts[1])
                    last_z = parts[2]
                    static_values = self.get_static_values('MYSQL' + family)
                    if not static_values:
                        self.logger.warning('No static_values entry for MySQL family %s', family)
                        continue
                    patch_xml = mysql_xml.format(static_values[-1], family, last_z, cpv)
                    # self.write_patch_check_to_checkmate(patch_xml, self.severity,
                    #                                     static_values[0], static_values[1],
                    #                                     static_values[2], static_values[3], item)
                    self.write_patch_check_to_file(patch_xml, item)
                except (IndexError, KeyError) as e:
                    self.logger.exception(str(e))

    def generate_postgre_db_patch_check(self, postgre_records):
        for postgre_record in postgre_records:
            item, status = self.check_for_success(postgre_record)
            if not status:
                try:
                    cpv = str(item['current_patch_version'])
                    last_value_of_version = cpv.split('.')
                    if len(last_value_of_version):
                        last_value_of_version = last_value_of_version[-1]
                    base_patch = re.findall(self.get_regex_values("postgre_patch_base"), cpv)[0]
                    static_values = self.get_static_values("POSTGRE" + base_patch)
                    if not static_values:
                        self.logger.warning('No static_values entry for PostgreSQL %s', base_patch)
                        continue
                    if '.' in base_patch:
                        postgre_xml = self.get_static_values('postgre_patch')
                    else:
                        postgre_xml = self.get_static_values('postgre_patch_10plus')
                    if not postgre_xml:
                        self.logger.warning('No template for PostgreSQL base_patch=%s', base_patch)
                        continue
                    patch_xml = postgre_xml.format(static_values[-1], base_patch,
                                                   last_value_of_version, cpv)
                    # self.write_patch_check_to_checkmate(patch_xml, self.severity, static_values[0], static_values[1],
                    #                                     static_values[2], static_values[3], item)
                    self.write_patch_check_to_file(patch_xml, item)
                except IndexError as Ie:
                    self.logger.exception(str(Ie))
                    continue

    def generate_db2_db_patch_checks(self, db2_records):
        for db2_record in db2_records:
            item, status = self.check_for_success(db2_record)
            if not status:
                template_for_9_7 = self.get_static_values('db2_9_7_patch')
                template_for_10_1 = self.get_static_values('db2_10_1_patch')
                template_for_10_5 = self.get_static_values('db2_10_5_patch')
                template_for_11_1 = self.get_static_values('db2_11_1_patch')
                try:
                    fix_pack = item['current_patch_version'].split(':')[0]
                    fix_pack = re.findall(r'\d+', fix_pack)[0]
                    if '9.7' in item['current_patch_version']:
                        query_xml = template_for_9_7.format('9.7', fix_pack)
                        static_value = self.get_static_values("DB2_patch_9_7_static")

                    elif '10.1' in item['current_patch_version']:
                        query_xml = template_for_10_1.format(10.1, fix_pack)
                        static_value = self.get_static_values("DB2_patch_10_1_static")

                    elif '10.5' in item['current_patch_version']:
                        fix = item['current_patch_version'].split(':')
                        fix_pack = re.findall(r'\d+', fix[0])[0]
                        version = fix[1]

                        query_xml = template_for_10_5.format(version, fix_pack)
                        static_value = self.get_static_values("DB2_patch_10_5_static")

                    else:
                        fix = item['current_patch_version'].split(':')

                        fix_pack = re.findall(self.get_regex_values("db2_patch_fix_pack"), fix[0])
                        version = fix[1]
                        build_level = fix[-1]
                        query_xml = template_for_11_1.format(version, fix_pack[0], re.findall(r'\d+', fix_pack[0])[-1], build_level)
                        static_value = self.get_static_values("DB2_patch_11_1_static")
                    # self.write_patch_check_to_checkmate(query_xml, self.severity, static_value[0], static_value[1],
                    #                                     static_value[2], static_value[3], item)
                    self.write_patch_check_to_file(query_xml, item)

                except IndexError as Ie:
                    self.logger.exception(str(Ie))
                    return 'failed to generate check checks due to index out of bound', 201

    def generate_mssql_2014_patch_checks(self, items):
        try:
            for current_patch in items['current_patch_version']:
                if re.findall("SP1", current_patch):
                    static_value = self.get_static_values("MSSQL12_SP1")
                    full_list, version_list, cu_version = self.get_patch_check_mssql(
                        static_value[-1], self.get_regex_values("mssql_patch_2014_SP1_arg1"),
                        current_patch, items, self.get_regex_values("mssql_patch_2014_SP1_arg2"))
                    patch = self.get_static_values("mssql_patch_14_SP1").format(
                        cu_version, "\n".join(version_list), ", ".join(full_list)
                    )

                elif re.findall("SP2", str(current_patch)):
                    static_value = self.get_static_values("MSSQL12_SP2")
                    full_list, version_list, cu_version = self.get_patch_check_mssql(
                        "MSPATCH025", self.get_regex_values("mssql_patch_2014_SP2_arg1"),
                        current_patch, items, self.get_regex_values("mssql_patch_2014_SP2_arg2"))
                    patch = self.get_static_values("mssql_patch_14_SP2").format(
                        cu_version, "\n".join(version_list), ", ".join(full_list)
                    )
                else:
                    static_value = self.get_static_values("MSSQL12_SP3")
                    full_list, version_list, cu_version = self.get_patch_check_mssql(
                        static_value[-1], self.get_regex_values("mssql_patch_2014_SP3_arg1"),
                        current_patch, items, self.get_regex_values("mssql_patch_2014_SP3_arg2"))

                    patch = self.get_static_values("mssql_patch_14_SP3").format(
                        cu_version, "\n".join(version_list), ", ".join(full_list)
                    )
                # self.write_patch_check_to_checkmate(patch, self.severity, static_value[0], static_value[1],
                #                                     static_value[2], static_value[3],
                #                                     items)
                self.write_patch_check_to_file(patch, items)
        except Exception as Ex:
            self.logger.exception(str(Ex))

    def generate_hanadb_patch_checks(self, hana_records):
        for hana_record in hana_records:
            item, status = self.check_for_success(hana_record)
            try:
                if not status:
                    if 'str' in str(type(item['current_patch_version'])):
                        static_value = self.get_static_values("hana_patch_static")
                        version = re.findall(self.get_regex_values("hana_version1_0"), item['current_patch_version'])[0]
                        version = version.split('.')
                        query_xml = self.get_static_values('hana_patch_1').format(version[0], version[1])
                        # self.write_patch_check_to_checkmate(query_xml, self.severity, static_value[0], static_value[1], static_value[2], static_value[3], item)
                        self.write_patch_check_to_file(query_xml, item)

                    elif 'list' in str(type(item['current_patch_version'])):

                        for response1 in item['current_patch_version']:
                            if 'SPS 04' in str(response1):
                                static_value = self.get_static_values("hana_patch_static_2_04")
                                version = re.findall(self.get_regex_values("hana_version2_04"), str(response1))[0].split(' ')[-1]
                                query_xml = self.get_static_values('hana_patch_2_04').format(version)

                            else:
                                static_value = self.get_static_values("hana_patch_static_2_03")
                                version = response1.split(' ')[-1]
                                query_xml = self.get_static_values('hana_patch_2_03').format(version)

                            # self.write_patch_check_to_checkmate(query_xml, self.severity, static_value[0], static_value[1],
                            #                                     static_value[2], static_value[3], item)
                            self.write_patch_check_to_file(query_xml, item)

            except Exception as Ex:
                self.logger.exception(str(Ex))

    def generate_mssql_2016_patch_checks(self, items):
        try:
            for current_patch in items['current_patch_version']:
                if re.findall("SP1", current_patch):
                    static_value = self.get_static_values("MSSQL13_SP1")
                    full_list, version_list, cu_version = self.get_patch_check_mssql(
                        static_value[-1], self.get_regex_values("mssql_patch_2016_SP1_arg1"),
                        current_patch, items, self.get_regex_values("mssql_patch_2016_SP1_arg2"))
                    patch = self.get_static_values("mssql_patch_16_sp1").format(
                        cu_version, "\n".join(version_list), ", ".join(full_list)
                    )

                elif re.findall("SP2", current_patch):
                    static_value = self.get_static_values("MSSQL13_SP2")
                    full_list, version_list, cu_version = self.get_patch_check_mssql(
                        static_value[-1], self.get_regex_values("mssql_patch_2016_SP2_arg1"),
                        current_patch, items, self.get_regex_values("mssql_patch_2016_SP2_arg2"))
                    patch = self.get_static_values("mssql_patch_16_sp2").format(
                        cu_version, "\n".join(version_list), ", ".join(full_list)
                    )
                else:
                    static_value = self.get_static_values("MSSQL13_CU")
                    full_list, version_list, cu_version = self.get_patch_check_mssql(
                        static_value[-1], self.get_regex_values("mssql_patch_2016_CU_arg1"),
                        current_patch, items, self.get_regex_values("mssql_patch_2016_CU_arg2"))
                    patch = self.get_static_values("mssql_patch_16_rtm").replace("\"", "\\").format(
                        cu_version, '\n'.join(version_list), ', '.join(full_list)
                    )
                # self.write_patch_check_to_checkmate(patch, self.severity, static_value[0], static_value[1],
                #                                     static_value[2], static_value[3],
                #                                     items)
                self.write_patch_check_to_file(patch, items)
        except Exception as Ex:
            self.logger.exception(str(Ex))