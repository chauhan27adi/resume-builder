import json
import logging
import os
import smtplib
from email.message import EmailMessage

logger = logging.getLogger('CheckGenerator')

_MAIL_PATH = os.path.join(os.path.dirname(__file__), 'check_generation_prod', 'resources', 'mail_properties.json')
_CSV_PATH  = os.path.join(os.path.dirname(__file__), 'check_generation_prod', 'resources', 'mail_body.csv')


class MailNotificationToUser:

    def __init__(self):
        with open(_MAIL_PATH, 'r') as f:
            mail = json.load(f)
        self._smtp      = mail['smtp']
        self._sender    = mail['sender']
        self._receivers = mail['receivers']

    def send_mail(self):
        with open(_CSV_PATH, 'r') as f:
            body = f.read().strip()

        msg = EmailMessage()
        msg['From'] = self._sender
        msg['To']   = ', '.join(self._receivers)

        if body:
            msg['Subject'] = 'DVM — Check Generation Complete'
            msg.set_content(f"Check generation status:\n\n{body}")
        else:
            msg['Subject'] = 'DVM — Check Generation Complete (no new checks)'
            msg.set_content('No new checks were generated in this run.')

        try:
            with smtplib.SMTP(self._smtp, 25) as smtp:
                smtp.send_message(msg)
            logger.info('Check generation mail sent successfully.')
        except (smtplib.SMTPException, OSError) as e:
            logger.error(f'Unable to send check generation mail: {e}')
        finally:
            open(_CSV_PATH, 'w').close()