# DBSecDVMContentAutomation

**DBSecDVMContentAutomation** is an automated pipeline that monitors database vendor security pages for new CVEs and generates SQL-based security checks for the CheckMate platform — eliminating manual process of researching advisories and hand-coding checks for each release.

## Overview

The project has two components that run in sequence:

- **DVMCrawler** — Scrapy spiders crawl the security advisory pages for each supported database (MSSQL, MySQL, PostgreSQL, Oracle, DB2, MariaDB, MongoDB, SAP HANA, Sybase ASE), extract CVE IDs, affected versions, and descriptions, and store the results in a local SQLite database and MongoDB.
- **DVMCheckGenerator** — Reads the CVEs stored by DVMCrawler and generates XML check files in the format expected by CheckMate, the internal tool used to test whether a customer database instance is vulnerable or already patched.

An email notification is sent after crawling (new CVEs found) and again after check generation (check status summary).

---

# Setup & Run Guide — DBSecDVMContentAutomation

## Prerequisites (common)

- **Python 3.13.1** — pinned version; verify with `python --version` (minimum supported: 3.8)
- **Firefox 151.0.1 (64-bit)** — pinned version; do not upgrade without verifying geckodriver compatibility. The bundled geckodriver (`DVMCrawler/geckodriver.exe`) is version 0.37.0 which requires Firefox 115 as the minimum — 151.0.1 is fully compatible.
- **MongoDB 8.3.4** (`mongodb-windows-x86_64-8.3.4-signed`) — pinned version; running locally or reachable via the connection string in `DVMCrawler/credentials/credentials.json`. pymongo 4.17.0 requires MongoDB 4.2 minimum — 8.3.4 is fully compatible.
- **MongoDB Compass 1.49.8** (`mongodb-compass-1.49.8-win32-x64`) — optional GUI for inspecting `cve_data.db`-equivalent MongoDB collections. Not required to run the pipeline.

---

## Option 1 — Setup with a virtual environment (recommended)

> All commands in this section must be run from the **project root** (`DBSecDVMContentAutomation/`).

### Step 1 — Create the virtual environment

```powershell
python -m venv venv
```

This creates a `venv/` folder inside the project root.

### Step 2 — Activate the virtual environment

**Windows (PowerShell):**
```powershell
.\venv\Scripts\Activate.ps1
```

**Windows (Command Prompt):**
```cmd
venv\Scripts\activate.bat
```

**Linux / macOS:**
```bash
source venv/bin/activate
```

You will see `(venv)` prefixed in your terminal prompt when activated.

### Step 3 — Install dependencies

```powershell
pip install -r requirements.txt
```

### Step 4 — Verify the setup

```powershell
python -c "import scrapy, bs4, lxml, selenium, pymongo, requests; print('All dependencies OK')"
```

Expected output:
```
All dependencies OK
```

Also confirm the Python being used is the one inside venv:

**Windows:**
```powershell
where python
# Should show: <project-root>\venv\Scripts\python.exe
```

> **Note:** `where` can behave inconsistently in PowerShell and may return no output even when the venv is correctly activated. If that happens, use `Get-Command` instead — it reliably resolves the venv path:
> ```powershell
> Get-Command python | Select-Object -ExpandProperty Source
> # Should show: <project-root>\venv\Scripts\python.exe
> ```

**Linux / macOS:**
```bash
which python
# Should show: <project-root>/venv/bin/python
```

---

## Option 2 — Setup without a virtual environment

> All commands in this section must be run from the **project root** (`DBSecDVMContentAutomation/`).

### Prerequisites

- Python 3.8+ installed system-wide
- `pip` available (`python -m pip --version`)
- No conflicting package versions from other projects (use venv if unsure)

### Step 1 — Install dependencies globally

```powershell
pip install -r requirements.txt
```

### Step 2 — Verify

```powershell
python -c "import scrapy, bs4, lxml, selenium, pymongo, requests; print('All dependencies OK')"
```

---

## Running the project

All commands below must be run from the **project root** (the folder containing `Run_DVMAutomation.py`).

### Full run — all databases, crawl + check generation

```powershell
python Run_DVMAutomation.py
```

Or double-click `run_dvm.bat` (kills any running Firefox first, then runs the above).

### Single database only

```powershell
python Run_DVMAutomation.py -d mssql
python Run_DVMAutomation.py -d mysql
python Run_DVMAutomation.py -d postgres
python Run_DVMAutomation.py -d oracle
python Run_DVMAutomation.py -d db2
python Run_DVMAutomation.py -d mariadb
python Run_DVMAutomation.py -d saphana
python Run_DVMAutomation.py -d mongodb
```

### Skip patches or vulnerabilities

```powershell
python Run_DVMAutomation.py -op   # crawl + vulnerabilities only, no patches
python Run_DVMAutomation.py -ov   # crawl + patches only, no vulnerability checks
```

To exclude patches directly in code, pass `patches=False`:

```python
run_check_generation(spider_names, patches=False, vulnerabilities=inc_vulns)
```

To exclude vulnerabilities directly in code, pass `vulnerabilities=False`:

```python
run_check_generation(spider_names, patches=inc_patches, vulnerabilities=False)
```

---

## What runs in sequence

```
Run_DVMAutomation.py
    │
    ├─ 1. run_crawlers()          → DVMCrawler spiders → writes to DVMCrawler/cve_data.db + MongoDB
    ├─ 2. send_cve_notification() → sends CVE email (MailNotificationToUser)
    └─ 3. run_check_generation()  → reads DB → generates XML checks → clears mail_body.csv
```

---

## Outputs

### Crawled CVE data

| Storage | Location | Notes |
|---|---|---|
| SQLite | `DVMCrawler/cve_data.db` | Written by DVMCrawler; read by DVMCheckGenerator |
| MongoDB | database `output_web_crawler_details` | One collection per DB type — see table below |

MongoDB collections:

| Database | Collection |
|---|---|
| MSSQL | `mssqldb` |
| MySQL | `mysqldb` |
| PostgreSQL | `postgredb` |
| Oracle | `oracle_db` |
| DB2 | `db2db` |
| MariaDB | `mariadb` |
| MongoDB | `mongodb` |
| SAP HANA | `hanadb` |
| Sybase ASE | `sybasedb` |

Patch variants follow the same names with a `_patch` suffix (e.g. `hanadb_patch`).

### Generated check files

XML check files are written to `DVMCheckGenerator/` during check generation. Both file types are **transient** — they do not persist after a successful run.

| File pattern | Description |
|---|---|
| `DVMCheckGenerator/tests_output_{db_name}.xml` | Intermediate aggregate XML per DB — deleted after it is split into chunks |
| `DVMCheckGenerator/dataroot_output_{db_name}_{timestamp}_{n}.xml` | Importable chunk — uploaded to CheckMate, then deleted |

For patch checks, no intermediate XML is written; patch data is sent directly to the CheckMate REST API.

### Check generation status log

`DVMCheckGenerator/check_generation_prod/resources/mail_body.csv` — populated with a status entry for each check generated during the run. Cleared at the end of every run by `Run_DVMAutomation.py`.

### Application logs

| File | Contents |
|---|---|
| `DVMAutomation.log` | Top-level orchestrator log (at project root) |
| `DVMCrawler/Crawler.log` | Per-spider crawl activity |
| `DVMCheckGenerator/Crawler.log` | Check generation activity |

---

## Monitor progress

Log output goes to two places:

- `DVMAutomation.log` — top-level orchestrator log (at project root)
- `DVMCrawler/Crawler.log` — per-spider crawl log

Watch the crawler log live during a run:

**Windows (PowerShell):**
```powershell
Get-Content "DVMCrawler\Crawler.log" -Wait
```

**Linux / macOS:**
```bash
tail -f DVMCrawler/Crawler.log
```