import os
import sys
import json
import logging
import argparse
import subprocess

project_root  = os.path.dirname(os.path.abspath(__file__))
CRAWLER_ROOT  = os.path.join(project_root, 'DVMCrawler')
CHECKGEN_ROOT = os.path.join(project_root, 'DVMCheckGenerator')

parser = argparse.ArgumentParser()
parser.add_argument('-d', '--dbms', type=str, default='all',
    help='Database to run (all, db2, mysql, mariadb, mssql, oracle, postgres, sybase, saphana)')
parser.add_argument('-op', '--omit-patches', action='store_false')
parser.add_argument('-ov', '--omit-vulnerabilities', action='store_false')

_dvm_handler = logging.FileHandler(os.path.join(project_root, 'DVMAutomation.log'))
_dvm_handler.setFormatter(logging.Formatter('%(asctime)s %(name)s %(levelname)s - %(message)s'))
logger = logging.getLogger('DVMAutomation')
logger.setLevel(logging.DEBUG)
logger.addHandler(_dvm_handler)
logger.propagate = False

checkgen_handler = logging.FileHandler(os.path.join(CHECKGEN_ROOT, 'CheckGenerator.log'))
checkgen_handler.setFormatter(logging.Formatter('%(asctime)s %(name)s %(levelname)s - %(message)s'))
checkgen_logger = logging.getLogger('CheckGenerator')
checkgen_logger.setLevel(logging.DEBUG)
checkgen_logger.addHandler(checkgen_handler)
checkgen_logger.propagate = False
LOG_SPACER = 15 * '#'


def get_supported_db():
    cred_path = os.path.join(CRAWLER_ROOT, 'credentials', 'credentials.json')
    with open(cred_path) as f:
        creds = json.load(f)
    vuln_spiders  = creds[3]['list_db']
    patch_spiders = creds[3]['supported_database_patch']
    labels        = creds[3]['list_db_name']
    patch_labels  = creds[3].get('list_db_name_patch', [])
    return vuln_spiders + patch_spiders, labels + patch_labels


def _switch_to_crawler_context():
    os.chdir(CRAWLER_ROOT)
    if CRAWLER_ROOT not in sys.path:
        sys.path.insert(0, CRAWLER_ROOT)


def _switch_to_checkgen_context():
    os.chdir(CHECKGEN_ROOT)
    if CHECKGEN_ROOT not in sys.path:
        sys.path.insert(0, CHECKGEN_ROOT)


def kill_stale_browser_processes():
    try:
        for exe in ('geckodriver.exe', 'firefox.exe', 'plugin-container.exe'):
            subprocess.run(['taskkill', '/F', '/IM', exe], capture_output=True)
    except Exception as err:
        logger.warning(f'Could not kill stale browser processes: {err}')


def run_crawlers(spider_names, display_names):
    _switch_to_crawler_context()
    from scrapy.crawler import CrawlerProcess
    from scrapy.utils.project import get_project_settings

    logger.info(f'{LOG_SPACER} DVMCrawler: Web Crawling Starts {LOG_SPACER}')
    crawler = CrawlerProcess(get_project_settings())
    for spider, label in zip(spider_names, display_names):
        try:
            logger.info(f'Running {label} spider')
            crawler.crawl(spider)
        except Exception as err:
            logger.exception(f'Failed crawling {label}: {err}')
    crawler.start()
    logger.info(f'{LOG_SPACER} DVMCrawler: Web Crawling Completed {LOG_SPACER}')


def send_cve_notification():
    _switch_to_crawler_context()
    from mail_notification_to_user import MailNotificationToUser
    logger.info('DVMCrawler: Sending CVE notification email')
    MailNotificationToUser().send_mail()


def send_check_generation_notification():
    _switch_to_checkgen_context()
    from mail_notification_to_user import MailNotificationToUser
    logger.info('DVMCheckGenerator: Sending check generation notification email')
    MailNotificationToUser().send_mail()


def run_check_generation(db_names, patches=True, vulnerabilities=True):
    _switch_to_checkgen_context()
    from check_generation_prod.databases_check_generation import AllDatabaseCheckGeneration
    from check_generation_prod.databases_patch_check_generation import AllDatabasePatchGeneration

    logger.info(f'{LOG_SPACER} DVMCheckGenerator: Check Generation Starts {LOG_SPACER}')
    if vulnerabilities:
        vuln_dbs = [d for d in db_names if 'patch' not in d.lower()]
        AllDatabaseCheckGeneration(vuln_dbs).get_all_mongo_values()
    if patches:
        patch_dbs = [d for d in db_names if 'patch' in d.lower()]
        AllDatabasePatchGeneration(patch_dbs).get_all_patch_mongo_values()
    logger.info(f'{LOG_SPACER} DVMCheckGenerator: Check Generation Completed {LOG_SPACER}')


# --- Main ---
args        = vars(parser.parse_args())
dbms        = args['dbms']
inc_patches = args['omit_patches']        # True by default; False when -op passed
inc_vulns   = args['omit_vulnerabilities']

all_spiders, all_labels = get_supported_db()

if dbms.upper() != 'ALL':
    target = dbms.lower().replace('postgres', 'postgre')
    pairs  = [(s, d) for s, d in zip(all_spiders, all_labels)
              if target in s.lower()]
    spider_names  = [p[0] for p in pairs]
    display_names = [p[1] for p in pairs]
else:
    spider_names, display_names = all_spiders, all_labels

kill_stale_browser_processes()
run_crawlers(spider_names, display_names)
#send_cve_notification()
run_check_generation(spider_names, patches=False, vulnerabilities=inc_vulns)
#send_check_generation_notification()