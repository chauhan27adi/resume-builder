@echo off
set SCRIPT_PATH=%~dp0
cd "%SCRIPT_PATH%"
python "%SCRIPT_PATH%Run_DVMAutomation.py"