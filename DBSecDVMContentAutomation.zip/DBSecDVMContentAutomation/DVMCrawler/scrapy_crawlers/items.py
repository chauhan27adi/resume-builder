# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class DvmautomationItem(scrapy.Item):

    long_description=scrapy.Field()
    severity=scrapy.Field()
    cve_no=scrapy.Field()
    affected_version=scrapy.Field()
    link = scrapy.Field()
    name = scrapy.Field()
    timestamp = scrapy.Field()
    current_patch_version = scrapy.Field()
    security_fixes = scrapy.Field()
    initial_mod_date = scrapy.Field()   # Used for Oracle CVEs
    component = scrapy.Field()          # Used for Oracle CVEs
    protocol = scrapy.Field()           # Used for Oracle CVEs
    count = scrapy.Field()              # Used for Oracle CVEs