BOT_NAME = 'DVMAutomation'

# Storage backend: 'sqlite' | 'mongodb' | 'both'
STORAGE_BACKEND = 'sqlite'

SPIDER_MODULES = ['scrapy_crawlers.spiders']
NEWSPIDER_MODULE = 'scrapy_crawlers.spiders'

ROBOTSTXT_OBEY = False

LOG_PROPAGATE = False

DEFAULT_REQUEST_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
}

DOWNLOADER_MIDDLEWARES = {
    'scrapy_crawlers.middlewares.CustomProxyMiddleware': 350,
    'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 400,
}

ITEM_PIPELINES = {
    'scrapy_crawlers.pipelines.DvmautomationPipeline': 300,
}