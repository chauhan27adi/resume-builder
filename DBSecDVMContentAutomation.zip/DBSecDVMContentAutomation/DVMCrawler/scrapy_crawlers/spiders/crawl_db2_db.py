import scrapy
import os
from ..items import DvmautomationItem
from bs4 import BeautifulSoup as bs
from time import gmtime, strftime
import re                                         # to open a browser and scraping dynamic pages
from selenium.webdriver import Firefox
from selenium.webdriver.firefox.options import Options                  # to enable headless option in firefox browser
import json
from urllib.parse import urljoin
from scrapy.spidermiddlewares.httperror import HttpError                     # handling http related exceptions
from twisted.internet.error import DNSLookupError                                   # handling connection lost related exceptions
from twisted.internet.error import TimeoutError, TCPTimedOutError
from twisted.internet import threads, defer
import utility
from .spider import Spider


class CrawlDb2Db(Spider):

    name = 'db2db'                      # unique name to the spider
    # Configurable limit for number of most recent CVEs to fetch
    max_cves = 100
    custom_settings = {
        'LOG_FILE': 'Crawler.log',
        'LOG_LEVEL': 'DEBUG',
    }

    @staticmethod
    def cve_sort_key(cve_no):
        """
        Return sortable key for CVE strings so newest CVEs come first
        when sorting in reverse order.
        """
        if not cve_no:
            return 0, 0
        match = re.search(r'CVE-(\d{4})-(\d+)', str(cve_no), re.IGNORECASE)
        if not match:
            return 0, 0
        return int(match.group(1)), int(match.group(2))

    @staticmethod
    def extract_ibm_vulnerability_entries(html_content, base_url):
        """
        Extract CVEs and bulletin links from IBM official DB2 vulnerability page.
        """
        entries = []
        try:
            soup = bs(html_content, 'html.parser')
            for row in soup.select('table tr'):
                row_text = ' '.join(row.stripped_strings)
                if 'Security Bulletin' not in row_text or 'Db2' not in row_text:
                    continue
                cves = re.findall(r'CVE-\d{4}-\d+', row_text, re.IGNORECASE)
                if not cves:
                    continue
                anchor = row.select_one('a[href]')
                bulletin_link = ""
                if anchor and anchor.get('href'):
                    bulletin_link = urljoin(base_url, anchor.get('href'))
                for cve in cves:
                    entries.append(
                        {
                            "cve_no": cve.upper(),
                            "bulletin_title": row_text,
                            "bulletin_link": bulletin_link
                        }
                    )

            # Fallback for unexpected markup changes: keep CVE discovery alive.
            if not entries:
                cves = re.findall(r'CVE-\d{4}-\d+', html_content, re.IGNORECASE)
                for cve in cves:
                    entries.append(
                        {
                            "cve_no": cve.upper(),
                            "bulletin_title": f"Security Bulletin for {cve.upper()}",
                            "bulletin_link": base_url
                        }
                    )
        except Exception:
            cves = re.findall(r'CVE-\d{4}-\d+', html_content, re.IGNORECASE)
            for cve in cves:
                entries.append(
                    {
                        "cve_no": cve.upper(),
                        "bulletin_title": f"Security Bulletin for {cve.upper()}",
                        "bulletin_link": base_url
                    }
                )

        # Preserve order and deduplicate by CVE.
        deduped = []
        seen = set()
        for entry in entries:
            cve_no = entry.get("cve_no")
            if cve_no in seen:
                continue
            seen.add(cve_no)
            deduped.append(entry)
        return deduped

    @staticmethod
    def base_score_to_severity(score):
        try:
            score = float(score)
            if score < 4.0:
                return "LOW"
            elif 4.0 <= score < 7.0:
                return "MEDIUM"
            else:
                return "HIGH"
        except (ValueError, TypeError):
            return "MEDIUM"

    @classmethod
    def format_severity(cls, score):
        severity_label = cls.base_score_to_severity(score)
        if score in [None, '']:
            return severity_label
        return '{} {}'.format(str(score).strip(), severity_label)

    @staticmethod
    def extract_cvss_score_for_cve(page_text, cve_no):
        """
        Try to extract CVSS Base Score specific to a CVE from a bulletin page.
        Falls back to page-level extraction when CVE-scoped extraction is unavailable.
        """
        if not page_text:
            return None

        cvss_patterns = [
            r'CVSS[^\n]{0,120}?Base(?:\s+Score)?[^\d]{0,10}([0-9]+(?:\.[0-9]+)?)',
            r'Base\s+Score[^\d]{0,10}([0-9]+(?:\.[0-9]+)?)'
        ]

        # CVE-scoped extraction first.
        if cve_no:
            escaped_cve = re.escape(cve_no)
            cve_matches = list(re.finditer(escaped_cve, page_text, re.IGNORECASE))
            for match in cve_matches:
                # Search around the CVE mention only, to avoid mixing scores from other CVEs.
                start = max(0, match.start() - 100)
                end = min(len(page_text), match.end() + 1800)
                cve_window = page_text[start:end]

                for pattern in cvss_patterns:
                    score_match = re.search(pattern, cve_window, re.IGNORECASE)
                    if score_match:
                        return score_match.group(1)

            # Secondary CVE-block extraction bounded by the next CVE marker.
            block_pattern = re.compile(
                r'({cve}[\s\S]{{0,3000}}?)(?:CVE-\d{{4}}-\d+|$)'.format(cve=escaped_cve),
                re.IGNORECASE
            )
            for block_match in block_pattern.finditer(page_text):
                cve_block = block_match.group(1)
                for pattern in cvss_patterns:
                    score_match = re.search(pattern, cve_block, re.IGNORECASE)
                    if score_match:
                        return score_match.group(1)

        # Fallback to page-level score if CVE-scoped score is not available.
        for pattern in cvss_patterns:
            score_match = re.search(pattern, page_text, re.IGNORECASE)
            if score_match:
                return score_match.group(1)

        return None

    @staticmethod
    def normalize_release_name(release_text):
        if not release_text:
            return ''

        release_match = re.search(r'V\d+(?:\.\d+)+', release_text, re.IGNORECASE)
        if release_match:
            return release_match.group(0).upper()

        release_match = re.search(r'\d+(?:\.\d+)+', release_text)
        if release_match:
            return 'V' + release_match.group(0)

        return ''

    @staticmethod
    def extract_fix_pack_number(text):
        if not text:
            return ''

        fix_pack_match = re.search(r'Fix\s*Pack\s*#?\s*(\d+)', text, re.IGNORECASE)
        return fix_pack_match.group(1) if fix_pack_match else ''

    @classmethod
    def build_special_build_value(cls, release_name, build_number, row_text=''):
        if not release_name or not build_number:
            return ''

        # Preserve only remediation data explicitly published by IBM.
        # Do not inject default Fix Pack values for build-only advisories,
        # otherwise downstream check generation incorrectly treats them as
        # full Fix Pack + Special Build remediations.
        fix_pack = ''
        row_text = row_text or ''
        fix_pack = cls.extract_fix_pack_number(row_text)

        if fix_pack:
            return 'Special Build {} Fix Pack {}'.format(build_number, fix_pack)

        return 'Special Build {}'.format(build_number)

    @classmethod
    def extract_affected_versions_from_tables(cls, soup):
        affected_versions = []
        seen = set()

        for table in soup.select('table'):
            headers = [
                ' '.join(header.stripped_strings).strip().lower()
                for header in table.select('tr th')
            ]
            if not headers:
                continue

            if 'release' not in headers[0] or 'download url' not in ' '.join(headers):
                continue

            for row in table.select('tr'):
                columns = row.select('td')
                if len(columns) < 4:
                    continue

                release_text = ' '.join(columns[0].stripped_strings).strip()
                download_text = ' '.join(columns[-1].stripped_strings).strip()
                row_text = ' '.join(row.stripped_strings).strip()

                release_name = cls.normalize_release_name(release_text)
                if not release_name:
                    continue

                build_numbers = re.findall(r'Special\s+Build\s*#?\s*(\d+)', download_text, re.IGNORECASE)
                if not build_numbers:
                    build_numbers = re.findall(r'Special\s+Build\s*#?\s*(\d+)', row_text, re.IGNORECASE)
                fix_pack = cls.extract_fix_pack_number(row_text)

                # Prefer explicit Special Build when present; otherwise keep Fix Pack only
                # rows as Fix Pack only values (do not synthesize Special Build data).
                if build_numbers:
                    build_value = cls.build_special_build_value(release_name, build_numbers[0], row_text)
                elif fix_pack:
                    build_value = 'Fix Pack {}'.format(fix_pack)
                else:
                    continue

                for value in [release_name, build_value]:
                    if value and value not in seen:
                        affected_versions.append(value)
                        seen.add(value)

        return affected_versions

    def start_requests(self):
        with open('credentials/urls.json', 'r') as file:
            json_content = json.loads(file.read())
            db2_vuln = json_content['db2_vuln']

        self.logger.info('DB2 start_requests() - Spider started, seed URL: %s', db2_vuln)
        self.logger.info('DB2 start_requests() - max_cves=%d', self.max_cves)
        yield scrapy.Request(
            url=db2_vuln,
            callback=self.parse,
            errback=self.errback_httpbin,
            dont_filter=True
        )

    def parse(self, response):
        self.logger.info('DB2 parse() - Got HTTP %d from %s', response.status, response.url)
        try:
            entries = self.extract_ibm_vulnerability_entries(response.text, response.url)
            self.logger.info('DB2 parse() - Extracted %d CVE entries from vulnerability index', len(entries))

            if not entries:
                self.logger.warning('DB2 parse() - No CVEs parsed from IBM DB2 vulnerability page; check page structure at %s', response.url)
                return

            capped = entries[0:self.max_cves]
            self.logger.info('DB2 parse() - Processing top %d entries (max_cves=%d)', len(capped), self.max_cves)

            grouped_entries = {}
            for entry in capped:
                bulletin_link = entry.get("bulletin_link") or response.url
                grouped_entries.setdefault(bulletin_link, []).append(entry)

            self.logger.info('DB2 parse() - Queuing %d bulletin requests', len(grouped_entries))
            for bulletin_link, bulletin_entries in grouped_entries.items():
                cve_labels = [e.get('cve_no', '?') for e in bulletin_entries]
                self.logger.info('DB2 parse() - Queuing bulletin %s for CVEs: %s', bulletin_link, cve_labels)
                yield scrapy.Request(
                    url=bulletin_link,
                    callback=self.intermediate_from_ibm,
                    dont_filter=True,
                    meta={"entries": bulletin_entries}
                )

        except FileNotFoundError as e:
            self.logger.error('DB2 parse() - File not found Exception ' + str(e))
        except IndexError as e:
            self.logger.error('DB2 parse() - Index not in range ' + str(e))

    @defer.inlineCallbacks
    def intermediate_from_ibm(self, response):
        self.logger.info('DB2 intermediate_from_ibm() - HTTP %d from %s', response.status, response.url)
        try:
            entries = response.meta.get('entries')
            if not entries:
                entry = response.meta.get('entry', {})
                entries = [entry] if entry else []

            if not entries:
                self.logger.warning('DB2 intermediate_from_ibm() - No CVE entries in meta for %s', response.url)
                defer.returnValue([])
                return

            self.logger.info('DB2 intermediate_from_ibm() - Processing %d CVE(s) from bulletin %s', len(entries), response.url)

            soup = bs(response.text, 'html.parser')
            page_text = ' '.join(soup.stripped_strings)

            # Run the blocking urlopen + Selenium calls in a thread so the reactor is not blocked.
            self.logger.info('DB2 intermediate_from_ibm() - Dispatching affected_version() to thread for %s', response.url)
            affected_versions = yield threads.deferToThread(self.affected_version, response.url)
            self.logger.info('DB2 intermediate_from_ibm() - affected_versions result for %s: %s', response.url, affected_versions)

            meta_description = soup.select_one('meta[name="description"]')
            meta_page_description = ''
            if meta_description and meta_description.get('content'):
                meta_page_description = meta_description.get('content').strip()

            items_list = []
            for entry in entries:
                cve_no = entry.get('cve_no', '')
                default_description = entry.get('bulletin_title', '')
                description = meta_page_description or default_description

                cve_score = self.extract_cvss_score_for_cve(page_text, cve_no)
                severity = self.format_severity(cve_score)

                items = DvmautomationItem()
                items['cve_no'] = cve_no
                items['long_description'] = description
                items['name'] = self.name
                items['timestamp'] = strftime("%Y-%m-%d %H:%M:%S", gmtime())
                items['severity'] = severity
                items['security_fixes'] = 'Vulnerability'
                items['affected_version'] = affected_versions
                items['link'] = response.url
                self.logger.info('DB2 intermediate_from_ibm() - Built item: %s', str(items))
                items_list.append(items)

            self.logger.info('DB2 intermediate_from_ibm() - Returning %d item(s) for bulletin %s', len(items_list), response.url)
            defer.returnValue(items_list)
        except AttributeError as Ae:
            self.logger.error('DB2 intermediate_from_ibm() - AttributeError for %s: %s', response.url, str(Ae))
        except IndexError as Ie:
            self.logger.error('DB2 intermediate_from_ibm() - IndexError for %s: %s', response.url, str(Ie))

    def affected_version(self, response):
        browser = None
        try:
            self.logger.info('DB2 affected_version() - START fetching version data from: %s', response)
            page = self.urlopen(response)
            self.logger.info('DB2 affected_version() - urlopen succeeded for %s', response)
            soup = bs(page, 'html.parser')
            affected_versions = self.extract_affected_versions_from_tables(soup)
            seen = set()

            if affected_versions:
                self.logger.info('DB2 affected_version() - Table parser found %d version(s): %s', len(affected_versions), affected_versions)
                return affected_versions

            self.logger.info('DB2 affected_version() - Table parser found nothing; trying row-level selectors for %s', response)

            # Primary selector from config, then resilient table-row fallbacks.
            row_selectors = [
                utility.get_xpath('db2_build_link'),
                'table tbody tr',
                'table tr'
            ]

            rows = []
            for selector in row_selectors:
                selected_rows = soup.select(selector)
                if selected_rows:
                    rows = selected_rows
                    self.logger.info('DB2 affected_version() - Selector "%s" matched %d rows', selector, len(selected_rows))
                    break
                else:
                    self.logger.debug('DB2 affected_version() - Selector "%s" matched 0 rows', selector)

            if not rows:
                self.logger.warning('DB2 affected_version() - No rows matched any selector for %s', response)

            for row in rows:
                # Skip header rows.
                if row.select('th'):
                    continue

                row_text = ' '.join(row.stripped_strings).strip()
                if not row_text:
                    continue

                release_name = self.normalize_release_name(row_text)
                if release_name and release_name not in seen:
                    affected_versions.append(release_name)
                    seen.add(release_name)

                # If row has explicit Fix Pack and no Special Build, keep it as fixpack-only
                # remediation and skip link-based special-build extraction to avoid false data.
                has_special_build_in_row = bool(re.search(r'Special\s+Build\s*#?\s*\d+', row_text, re.IGNORECASE))
                fix_pack_in_row = self.extract_fix_pack_number(row_text)
                if fix_pack_in_row and not has_special_build_in_row:
                    fix_pack_value = 'Fix Pack {}'.format(fix_pack_in_row)
                    if fix_pack_value not in seen:
                        affected_versions.append(fix_pack_value)
                        seen.add(fix_pack_value)
                    continue

                row_links = row.select('a[href]')
                if not row_links:
                    continue

                build_link = ''
                for anchor in row_links:
                    href = anchor.get('href')
                    if not href:
                        continue
                    href_lower = href.lower()
                    if 'support/pages' in href_lower or 'special' in href_lower or 'fix' in href_lower:
                        build_link = href
                        break

                if not build_link:
                    build_link = row_links[-1].get('href')

                if not build_link:
                    continue

                build_link = urljoin(response, build_link)

                # Lazily create one shared browser for all build-link lookups on this page.
                if browser is None:
                    self.logger.info('DB2 affected_version() - Initializing shared headless Firefox for bulletin: %s', response)
                    opts = Options()
                    opts.add_argument('-headless')
                    browser = Firefox(options=opts)
                    self.logger.info('DB2 affected_version() - Firefox started successfully')

                self.logger.info('DB2 affected_version() - Calling build_version_extractor for %s', build_link)
                build_version = self.build_version_extractor(build_link, release_name, browser=browser)
                self.logger.info('DB2 affected_version() - build_version_extractor returned: %s', build_version)
                if build_version and build_version not in seen:
                    affected_versions.append(build_version)
                    seen.add(build_version)

            self.logger.info('DB2 affected_version() - Row-level extraction found %d version(s) for %s: %s', len(affected_versions), response, affected_versions)

            # Fallback: extract any special build references from the whole bulletin text.
            if not affected_versions:
                self.logger.warning('DB2 affected_version() - No versions via table/row methods; using bulletin text fallback for: %s', response)
                page_text = ' '.join(soup.stripped_strings)
                releases = re.findall(r'V\d+(?:\.\d+)+', page_text, re.IGNORECASE)
                build_numbers = re.findall(r'Special\s+Build\s*#?\s*(\d+)', page_text, re.IGNORECASE)
                self.logger.info('DB2 affected_version() - Fallback found %d release(s), %d special build(s) in page text', len(releases), len(build_numbers))
                if build_numbers:
                    for release_name, build_number in zip(releases, build_numbers):
                        normalized_release = self.normalize_release_name(release_name)
                        normalized = self.build_special_build_value(normalized_release, build_number, page_text)
                        if normalized_release and normalized_release not in seen:
                            affected_versions.append(normalized_release)
                            seen.add(normalized_release)
                        if normalized and normalized not in seen:
                            affected_versions.append(normalized)
                            seen.add(normalized)
                else:
                    # No Special Build — capture unique version numbers and Fix Pack info.
                    fix_packs = re.findall(r'Fix\s*Pack\s*#?\s*(\d+)', page_text, re.IGNORECASE)
                    for release in releases:
                        normalized_release = self.normalize_release_name(release)
                        if normalized_release and normalized_release not in seen:
                            affected_versions.append(normalized_release)
                            seen.add(normalized_release)
                    if fix_packs:
                        fix_pack_value = 'Fix Pack {}'.format(fix_packs[0])
                        if fix_pack_value not in seen:
                            affected_versions.append(fix_pack_value)
                            seen.add(fix_pack_value)

            self.logger.info('DB2 affected_version() - FINAL result for %s: %s', response, affected_versions)
            return affected_versions
        except Exception as ex:
            self.logger.error('DB2 affected_version() - Exception for %s: %s', response, str(ex))
            return []
        finally:
            if browser:
                self.logger.info('DB2 affected_version() - Quitting shared Firefox browser')
                browser.quit()
                
    def build_version_extractor(self, urls, release_name='', browser=None):
        owns_browser = False
        try:
            if not urls:
                self.logger.warning('DB2 build_version_extractor() - Called with empty URL, skipping')
                return None

            if browser is None:
                self.logger.info('DB2 build_version_extractor() - Creating standalone Firefox for %s', urls)
                opts = Options()
                opts.add_argument('-headless')
                browser = Firefox(options=opts)
                owns_browser = True
                self.logger.info('DB2 build_version_extractor() - Standalone Firefox started')
            else:
                self.logger.info('DB2 build_version_extractor() - Using shared browser, navigating to %s', urls)

            delay = 20
            browser.get(urls)
            utility.wait_until_page_reloads(delay, browser, 'result0')
            self.logger.info('DB2 build_version_extractor() - Page loaded: %s', urls)
            html = browser.page_source
            soup = bs(html, "html.parser")

            # Prefer visible text from the page, then fallback to meta description.
            page_text = ' '.join(soup.stripped_strings)
            special_build = re.findall(r'Special\s+Build\s*#?\s*(\d+)', page_text, re.IGNORECASE)

            if not special_build:
                meta_desc = soup.select_one(utility.get_xpath('db2_build_no'))
                if meta_desc:
                    special_build = re.findall(
                        r'Special\s+Build\s*#?\s*(\d+)',
                        str(meta_desc),
                        re.IGNORECASE
                    )

            if not special_build:
                self.logger.info('DB2 build_version_extractor() - No special build number found at %s', urls)
                return None

            # If release_name wasn't determined from the bulletin page, infer it
            # from the CSB page title (e.g. "Db2 v11.5.9 Published Cumulative ...").
            if not release_name:
                title_tag = soup.select_one('title')
                if title_tag:
                    release_name = self.normalize_release_name(title_tag.get_text())
            if not release_name:
                release_matches = re.findall(r'V\d+(?:\.\d+)+', page_text, re.IGNORECASE)
                if release_matches:
                    release_name = self.normalize_release_name(release_matches[0])

            result = self.build_special_build_value(release_name, special_build[0], page_text)
            self.logger.info('DB2 build_version_extractor() - Found special build %s for release %s at %s -> %s', special_build[0], release_name, urls, result)
            return result
        except Exception as ex:
            self.logger.error('DB2 build_version_extractor() - Exception for %s: %s', urls, str(ex))
            return None
        finally:
            if owns_browser and browser:
                self.logger.info('DB2 build_version_extractor() - Closing standalone Firefox')
                browser.quit()

    def temp_files(self, name):  # logic for creating temp files. It checks for db2db.log if not then creates it
        file_name = ''
        if os.path.exists(os.getcwd()):
            if os.path.isdir(os.path.join(os.getcwd(), name)):
                self.logger.debug('exist')
                filepath = os.path.join(os.getcwd(), name)
                file_name = os.path.join(filepath, name) + '.log'
            else:
                os.makedirs(name)
                filepath = os.path.join(os.getcwd(), name)
                with open(os.path.join(filepath, name) + '.log', 'w') as file:
                    file_name = os.path.join(filepath, name) + '.log'
                    file.close()
        return file_name

    def errback_httpbin(self, failure):  # catching exception of parser.
        # log all failures
        obj = self.temp_files(self.name)
        self.logger.error(repr(failure))

        # in case you want to do something special for some errors,
        # you may need the failure's type:

        if failure.check(HttpError):  # catches any http errors like like invalid urls
            # these exceptions come from HttpError spider middleware
            # you can get the non-200 response
            response = failure.value.response
            self.logger.error('HttpError on %s', response.url)  # logging errors in console
            with open(obj, 'w') as file:
                file.write('HttpError' + ' Error Code 101')  # writing the error code and error message to log files

        elif failure.check(DNSLookupError):  # catches connection lost exceptions
            request = failure.request
            self.logger.error('DNSLookupError on %s', request.url)  # logging errors in console
            with open(obj, 'w') as file:
                file.write('DNSLookupError' + ' Error Code 102')  # writting the error code and error message to log files

        elif failure.check(TimeoutError, TCPTimedOutError):  # catches timeout exceptions
            request = failure.request
            self.logger.error('TimeoutError on %s', request.url)  # logging errors in console
            with open(obj, 'w') as file:
                file.write('TimeoutError' + ' Error Code 103')  # writting the error code and error message to log files