from time import gmtime, strftime
from collections import OrderedDict
import scrapy                                                                       # to import scrapy framework
from bs4 import BeautifulSoup as bs                                                 # for parsing html contents
import os
from ..items import DvmautomationItem                                               # creates a container like to store the output.
import re                                                                           # for pattern matching
from scrapy.spidermiddlewares.httperror import HttpError                            # handling http related exceptions
from twisted.internet.error import DNSLookupError                                   # handling connection lost related exceptions
from twisted.internet.error import TimeoutError, TCPTimedOutError
import sqlite3
import json
from .spider import Spider


class CrawlMariaDb(Spider):          # class should inherit base class of scrapy

    name = 'mariadb'                        # name of the crawler should be unique for each crawler.
                                            # no. of retries should be made before giving error
    # Configurable limit for number of most recent CVEs to fetch
    max_cves = 100
    custom_settings = {
        'LOG_FILE': 'Crawler.log',          # path to the log files
        'LOG_LEVEL': 'DEBUG',
        'DOWNLOAD_TIMEOUT': 30,
        'RETRY_ENABLED': True,
        'RETRY_TIMES': 3,
        'RETRY_HTTP_CODES': [408, 429, 500, 502, 503, 504, 522, 524],
        'AUTOTHROTTLE_ENABLED': True,
        'AUTOTHROTTLE_START_DELAY': 0.25,
        'AUTOTHROTTLE_MAX_DELAY': 5,
        'AUTOTHROTTLE_TARGET_CONCURRENCY': 2.0,
        'DOWNLOAD_DELAY': 0.1
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.feed_urls = {}
        self.xpaths = {}
        self.cve_records = OrderedDict()
        self.existing_cves = set()
        self.pending_series_pages = 0
        self.enrichment_cache = OrderedDict()
        self.max_enrichment_cache_size = 5000
        self.metrics = {
            'rows_with_cve': 0,
            'deduped_cves': 0,
            'skipped_existing_cves': 0,
            'nvd_requests': 0,
            'cve_org_fallback_requests': 0,
            'cache_hits': 0,
            'minimal_items_emitted': 0
        }
        self.logger.info('MariaDB spider initialized; max_cves=%d', self.max_cves)

    def closed(self, reason):
        # Emit a compact run summary for observability.
        self.logger.info(
            'MariaDB crawl summary | reason=%s | rows_with_cve=%s | deduped_cves=%s | '
            'nvd_requests=%s | cve_org_fallback_requests=%s | cache_hits=%s | skipped_existing_cves=%s | minimal_items_emitted=%s',
            reason,
            self.metrics['rows_with_cve'],
            self.metrics['deduped_cves'],
            self.metrics['nvd_requests'],
            self.metrics['cve_org_fallback_requests'],
            self.metrics['cache_hits'],
            self.metrics['skipped_existing_cves'],
            self.metrics['minimal_items_emitted']
        )

    def cache_enrichment(self, cve_no, long_description, severity):
        # Keep bounded in-run cache for enrichment payloads.
        self.logger.debug('Caching enrichment for %s: severity=%s', cve_no, severity)
        if cve_no in self.enrichment_cache:
            self.enrichment_cache.pop(cve_no)

        self.enrichment_cache[cve_no] = {
            'long_description': long_description or '',
            'severity': severity or ''
        }

        if len(self.enrichment_cache) > self.max_enrichment_cache_size:
            self.logger.warning('Enrichment cache exceeded max size (%d); evicting oldest entry', self.max_enrichment_cache_size)
            self.enrichment_cache.popitem(last=False)

    def _load_existing_cves_from_db(self):
        # Preload all existing CVE numbers from SQLite cve_data.db to skip
        # processing CVEs that are already stored.
        db_path = os.path.join(os.path.dirname(__file__), '..', '..', 'cve_data.db')
        try:
            conn = sqlite3.connect(db_path)
            try:
                cursor = conn.execute(f'SELECT cve_no FROM "{self.name}"')
                self.existing_cves = {
                    str(row[0]).strip().upper()
                    for row in cursor.fetchall()
                    if row[0]
                }
                self.logger.info('Loaded %d existing MariaDB CVEs from SQLite', len(self.existing_cves))
            except sqlite3.OperationalError:
                self.existing_cves = set()
                self.logger.info('MariaDB table not yet in SQLite; no existing CVEs to skip')
            finally:
                conn.close()
        except Exception as e:
            self.logger.warning('Unable to preload existing MariaDB CVEs from SQLite: %s', e)
            self.existing_cves = set()

    @staticmethod
    def normalize_severity(raw_severity):
        if not raw_severity:
            return ''

        severity = ' '.join(str(raw_severity).strip().split())

        score_match = re.search(r'(\d+(?:\.\d+)?)', severity)
        label_match = re.search(r'\b(LOW|MEDIUM|HIGH|CRITICAL)\b', severity, flags=re.IGNORECASE)

        if score_match and label_match:
            return '{} {}'.format(score_match.group(1), label_match.group(1).upper())
        if score_match:
            return score_match.group(1)
        if label_match:
            return label_match.group(1).upper()

        return severity.upper()

    @staticmethod
    def split_affected_versions(affected_version):
        if not affected_version:
            return ['Unknown']

        versions = [segment.strip() for segment in str(affected_version).split(',') if segment.strip()]
        return versions if versions else ['Unknown']

    @staticmethod
    def clean_affected_version_text(raw_text):
        if not raw_text:
            return 'Unknown'

        text = str(raw_text)
        # Remove common UI/markdown artifacts from scraped docs snippets.
        text = re.sub(r'arrow-up-right', ' ', text, flags=re.IGNORECASE)
        text = re.sub(r'https?://\S+', ' ', text)
        text = re.sub(r'\[[^\]]*\]\([^)]*\)', ' ', text)
        text = re.sub(r'\[[^\]]*\]', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip(' ,;:-')

        # Keep only normalized version tokens used by check generation.
        # This avoids carrying mixed CVE/link text into affected_version.
        version_tokens = re.findall(r'(?:12|11|10)\.\d+\.\d+|5\.5\.\d+', text)
        if version_tokens:
            # Preserve order while removing duplicates.
            ordered_unique = []
            for token in version_tokens:
                if token not in ordered_unique:
                    ordered_unique.append(token)
            return ', '.join(ordered_unique)

        return text if text else 'Unknown'

    def extract_cve_affected_pairs(self, payload_text):
        # Some pages may contain concatenated CVE rows in one HTML fragment.
        # Parse all CVE->affected_version pairs from the text block.
        pairs = []
        normalized = re.sub(r'\s+', ' ', str(payload_text)).strip()
        cve_positions = list(re.finditer(r'CVE-\d{4}-\d{4,7}', normalized))

        for index, cve_match in enumerate(cve_positions):
            cve_no = cve_match.group(0)
            start = cve_match.start()
            end = cve_positions[index + 1].start() if index + 1 < len(cve_positions) else len(normalized)
            segment = normalized[start:end]

            if ':' in segment:
                affected_version = segment.split(':', 1)[-1].strip()
            else:
                affected_version = segment[cve_match.end() - start:].strip(" -–:\t")

            affected_version = self.clean_affected_version_text(affected_version)
            if not affected_version:
                affected_version = 'Unknown'

            pairs.append((cve_no, affected_version))

        self.logger.debug('Extracted %d CVE-version pair(s) from payload', len(pairs))
        return pairs

    def merge_cve_record(self, cve_no, affected_version, source_link):
        # Aggregate all affected versions for a CVE across multiple MariaDB series pages.
        # Update an existing record only when the incoming page contributes
        # different version data.
        versions = self.split_affected_versions(affected_version)
        record = self.cve_records.setdefault(
            cve_no,
            {
                'affected_versions': [],
                'source_link': source_link
            }
        )
        has_changed = False

        if not record.get('source_link'):
            record['source_link'] = source_link
            has_changed = True

        existing_versions = record['affected_versions']
        existing_snapshot = list(existing_versions)

        # Replace placeholder Unknown once concrete versions are discovered.
        if versions != ['Unknown'] and existing_versions == ['Unknown']:
            existing_versions.clear()
            has_changed = True

        for version in versions:
            if version == 'Unknown' and existing_versions:
                continue
            if version not in existing_versions:
                existing_versions.append(version)
                has_changed = True

        # Keep insertion order stable; if nothing actually changed, preserve
        # the original record exactly as it was.
        if not has_changed:
            record['affected_versions'] = existing_snapshot
        else:
            self.logger.debug('Merged CVE record for %s: versions now=%s', cve_no, record['affected_versions'])

        return has_changed

    def get_affected_version_string(self, cve_no):
        record = self.cve_records.get(cve_no, {})
        versions = record.get('affected_versions', [])
        if not versions:
            self.logger.debug('No affected versions recorded for %s; returning Unknown', cve_no)
            return 'Unknown'
        result = ', '.join(versions)
        self.logger.debug('Affected version string for %s: %s', cve_no, result)
        return result

    def dispatch_enrichment_requests(self):
        # Once all series pages are parsed, enrich each unique CVE exactly once
        # using the aggregated affected_version string.
        cve_items = list(self.cve_records.items())[:self.max_cves]
        for cve_no, record in cve_items:
            # Skip CVE if already exists in MongoDB to prevent duplicates
            cve_key = str(cve_no).strip().upper()
            if cve_key in self.existing_cves:
                self.metrics['skipped_existing_cves'] += 1
                self.logger.info('Skipping already-existing MariaDB CVE: %s', cve_key)
                continue
            affected_version = self.get_affected_version_string(cve_no)
            source_link = record.get('source_link', self.get_feed_url('maria_vuln'))

            cached_enrichment = self.enrichment_cache.get(cve_no)
            if cached_enrichment:
                self.metrics['cache_hits'] += 1
                yield self.build_item(
                    cve_no,
                    affected_version,
                    source_link,
                    cached_enrichment.get('long_description', ''),
                    cached_enrichment.get('severity', '')
                )
                continue

            nvd_url = self.get_feed_url('nvd_uri') + cve_no
            self.metrics['nvd_requests'] += 1
            yield scrapy.Request(
                url=nvd_url,
                callback=self.parse_nvd,
                errback=self.errback_enrichment,
                dont_filter=True,
                meta={
                    'cve_no': cve_no,
                    'affected_version': affected_version,
                    'source_link': source_link,
                    'retry_stage': 'nvd'
                }
            )

    @staticmethod
    def safe_log_text(value, max_len=300):
        """Return console-safe text for logging on cp1252 terminals."""
        text = re.sub(r'\s+', ' ', str(value))
        text = text[:max_len]
        # Avoid UnicodeEncodeError on Windows cp1252 consoles.
        return text.encode('cp1252', errors='replace').decode('cp1252', errors='replace')

    def _load_configs(self):
        # Load JSON configs once and reuse across the spider lifecycle.
        if not self.feed_urls:
            self.logger.debug('Loading feed URLs from Credentials/urls.json')
            with open('credentials/urls.json', 'r') as file:
                self.feed_urls = json.loads(file.read())

        if not self.xpaths:
            self.logger.debug('Loading XPaths from Credentials/database_xpaths.json')
            with open('credentials/database_xpaths.json', 'r') as file:
                self.xpaths = json.loads(file.read())

    # Entry point for spider requests.
    # Reads crawler source URLs from config and starts crawl with the
    # vulnerability source URL.
    def start_requests(self):
        # Preload existing CVEs from SQLite before starting the crawl
        self._load_existing_cves_from_db()
        self._load_configs()
        maria_vuln = self.feed_urls.get('maria_vuln', '')
        self.logger.info('Starting MariaDB vulnerability crawl: %s', maria_vuln)

        yield scrapy.Request(url=maria_vuln, callback=self.parse_cve_index, errback=self.errback_httpbin, dont_filter=True)

    # Parses the community-server CVE index page to discover individual
    # per-series "changes and improvements" pages that contain static CVE lists.
    # The index page itself has a JS-rendered table (empty in raw HTML), so
    # we follow the sidebar links to the static series pages instead.
    def parse_cve_index(self, response):
        self.logger.info('Parsing CVE index page: {}'.format(response.url))

        # Collect all links pointing to release-notes series pages.
        # Series pages use URL slugs like 'what-is-mariadb-106' or
        # 'mariadb-12.3-changes-and-improvements'.
        all_links = response.css(
            "a[href*='/release-notes/community-server/']::attr(href)"
        ).getall()

        seen = set()
        series_links = []
        for link in all_links:
            page_name = link.rstrip('/').split('/')[-1]
            # Only follow series-level summary pages, not individual point-releases
            # (e.g. skip '10.6.25'). Series pages contain 'what-is-mariadb' or
            # 'changes' in their slug.
            if 'what-is-mariadb' in page_name or 'changes' in page_name:
                if link not in seen:
                    seen.add(link)
                    series_links.append(link)

        self.pending_series_pages = len(series_links)
        for link in series_links:
            self.logger.debug('Following series page: %s', link)
            yield scrapy.Request(
                url=response.urljoin(link),
                callback=self.parse,
                errback=self.errback_httpbin,
                dont_filter=False  # Scrapy dedup handles repeated links
            )

    # Parses vulnerability listing rows and emits one normalized item per CVE.
    # Flow: extract row text -> parse CVE + affected_version -> enrich from NVD.

    def parse(self, response):

        self.logger.info('Got successful response from {}'.format(response.url))                        # logging the status to Crawler.log file
        try:
            # cve_list is an XPath expression that selects every <li> containing
            # a link to cve.mitre.org, matching the new MariaDB docs site structure.
            payloads = response.xpath(self.get_xpath('cve_list')).getall()                               # searches and Extract the list of cves from the series page
            if not payloads:
                # Defensive fallback: if upstream HTML structure shifts again,
                # parse the whole page text instead of returning zero rows.
                self.logger.warning('No CVE payload rows matched selector on %s; using full-page fallback parser', response.url)
                payloads = [response.text]
            for payload in payloads:
                details = bs(payload, 'html.parser')
                payload_text = details.text.strip()

                cve_pairs = self.extract_cve_affected_pairs(payload_text)
                if not cve_pairs:
                    self.logger.warning(
                        'Skipping malformed row without CVE token. Preview: %s',
                        self.safe_log_text(payload_text)
                    )
                    continue

                for cve_no, affected_version in cve_pairs:
                    self.metrics['rows_with_cve'] += 1
                    cve_exists = cve_no in self.cve_records
                    record_changed = self.merge_cve_record(cve_no, affected_version.strip(), response.url)
                    if cve_exists and record_changed:
                        self.metrics['deduped_cves'] += 1

        except FileNotFoundError as e:
            self.logger.error('No temp folder with db name exist ' + str(e))
        except (IndexError, KeyError, AttributeError, TypeError, ValueError) as e:
            # Parsing exceptions are logged and processing continues in next run.
            self.error_logging('Failed to parse the html page' + str(e))
            self.logger.exception('Failed to parse payloads in parse()')
        finally:
            if self.pending_series_pages > 0:
                self.pending_series_pages -= 1

            if self.pending_series_pages == 0 and self.cve_records:
                for request in self.dispatch_enrichment_requests():
                    yield request

    # NVD-first enrichment step.
    # Parses description/severity from NVD HTML and falls back to CVE.org API
    # when one or both fields are unavailable.
    def parse_nvd(self, response):
        cve_no = response.meta.get('cve_no', '')
        affected_version = response.meta.get('affected_version', 'Unknown')
        source_link = response.meta.get('source_link', response.url)

        long_description = ''
        severity = ''

        soup = bs(response.text, 'html.parser')
        try:
            long_description, severity = self.extract_nvd_details(soup)
        except (KeyError, AttributeError, TypeError, ValueError) as e:
            self.logger.warning('NVD parse failed for %s: %s', cve_no, str(e))

        # Fallback/augment from CVE.org API only if NVD did not provide full data.
        if not long_description or not severity:
            cve_org_url = self.get_feed_url('cve_org_api_uri') + cve_no
            self.metrics['cve_org_fallback_requests'] += 1
            yield scrapy.Request(
                url=cve_org_url,
                callback=self.parse_cve_org,
                errback=self.errback_enrichment,
                dont_filter=True,
                headers={'Accept': 'application/json'},
                meta={
                    'cve_no': cve_no,
                    'affected_version': affected_version,
                    'source_link': source_link,
                    'retry_stage': 'cve_org',
                    'long_description': long_description,
                    'severity': severity
                }
            )
            return

        self.cache_enrichment(cve_no, long_description, severity)
        yield self.build_item(cve_no, affected_version, source_link, long_description, severity)

    # Extracts description and severity from parsed NVD HTML document.
    def extract_nvd_details(self, nvd_soup):
        long_description = ''
        severity = ''

        description_node = nvd_soup.select_one(self.get_xpath('maria_long_description'))
        if description_node:
            long_description = description_node.text
            if 'CVSS Vector' in long_description:
                long_description = str(long_description).split(' CVSS Vector')[0]
        else:
            self.logger.debug('NVD description node not found; description will be empty')

        severity_node = nvd_soup.select_one(self.get_xpath('maria_severity'))
        if severity_node is None:
            self.logger.debug('NVD CNA severity not found; trying NIST CVSSv3 selector')
            severity_node = nvd_soup.select_one(self.get_xpath('maria_severity_without_cna'))
        if severity_node is None:
            # Pre-2015 CVEs only have CVSSv2 scores on NVD; no CVSSv3 panel exists.
            self.logger.debug('NVD CVSSv3 severity not found; trying CVSSv2 selector')
            severity_node = nvd_soup.select_one(self.get_xpath('maria_severity_cvss2'))
        if severity_node:
            severity = self.normalize_severity(severity_node.text)
        else:
            self.logger.debug('NVD severity not found in CVSSv3 or CVSSv2 selectors')

        self.logger.debug('NVD extract result: severity=%s description_len=%d', severity, len(long_description))
        return long_description, severity

    # CVE.org fallback/augmentation step.
    # Fills only missing fields and keeps already-extracted NVD values as primary.
    def parse_cve_org(self, response):
        cve_no = response.meta.get('cve_no', '')
        affected_version = response.meta.get('affected_version', 'Unknown')
        source_link = response.meta.get('source_link', response.url)
        long_description = response.meta.get('long_description', '')
        severity = response.meta.get('severity', '')

        try:
            payload = json.loads(response.text)
            cve_org_long_description, cve_org_severity = self.extract_cve_org_details(payload)
            if not long_description and cve_org_long_description:
                long_description = cve_org_long_description
            if not severity and cve_org_severity:
                severity = cve_org_severity
        except (KeyError, AttributeError, TypeError, ValueError, json.JSONDecodeError) as e:
            self.logger.warning('CVE.org parse failed for %s: %s', cve_no, str(e))

        severity = self.normalize_severity(severity)
        self.cache_enrichment(cve_no, long_description, severity)
        yield self.build_item(cve_no, affected_version, source_link, long_description, severity)

    # Centralized item construction for vulnerability records.
    def build_item(self, cve_no, affected_version, source_link, long_description='', severity=''):
        items = DvmautomationItem()                                                                 # Initializing the container
        items['long_description'] = long_description
        items['severity'] = self.normalize_severity(severity)
        items['cve_no'] = cve_no
        items['affected_version'] = affected_version if affected_version else 'Unknown'
        items['name'] = self.name
        items['timestamp'] = strftime("%Y-%m-%d %H:%M:%S", gmtime())
        items['security_fixes'] = 'Vulnerability'
        items['link'] = source_link
        self.logger.info(items)
        return items
    
    # Extracts description and severity from CVE.org API payload.
    def extract_cve_org_details(self, payload):
        long_description = ''
        severity = ''

        cna = payload.get('containers', {}).get('cna', {})

        descriptions = cna.get('descriptions', [])
        for description in descriptions:
            lang = str(description.get('lang', '')).lower()
            if lang.startswith('en') and description.get('value'):
                long_description = description.get('value', '').strip()
                break

        # CNA metrics first; fall back to ADP metrics (e.g. NVD as ADP provides
        # CVSS scores for old CVEs that pre-date CNA score submission).
        all_metrics = list(cna.get('metrics', []))
        for adp_entry in payload.get('containers', {}).get('adp', []):
            all_metrics.extend(adp_entry.get('metrics', []))

        for metric in all_metrics:
            cvss = metric.get('cvssV3_1') or metric.get('cvssV3_0') or metric.get('cvssV4_0')
            if cvss:
                base_score = cvss.get('baseScore')
                base_severity = cvss.get('baseSeverity')
                if base_score is not None and base_severity:
                    severity = '{} {}'.format(base_score, base_severity)
                elif base_score is not None:
                    severity = str(base_score)
                elif base_severity:
                    severity = str(base_severity)
                if severity:
                    break
            # CVSSv2 (pre-2015 CVEs): no baseSeverity field; derive label from score range.
            cvss2 = metric.get('cvssV2_0')
            if cvss2 and not severity:
                base_score = cvss2.get('baseScore')
                if base_score is not None:
                    score = float(base_score)
                    label = 'HIGH' if score >= 7.0 else ('MEDIUM' if score >= 4.0 else 'LOW')
                    severity = '{} {}'.format(base_score, label)
                    break

        if not severity and long_description:
            severity_match = re.search(
                r'CVSS\s*\d(?:\.\d)?\s*Base\s*Score\s*([0-9]+(?:\.[0-9]+)?)\s*\(([^)]+)\)',
                long_description,
                flags=re.IGNORECASE
            )
            if severity_match:
                severity = '{} {}'.format(severity_match.group(1), severity_match.group(2).strip().upper())

        return long_description, severity

    # Enrichment errback that preserves pipeline continuity.
    # On NVD failure, it still attempts CVE.org fallback.
    # On CVE.org failure, it yields a minimal item so CVE is not dropped.
    def errback_enrichment(self, failure):
        self.logger.warning('Enrichment request failed: %s', repr(failure))
        request = failure.request
        cve_no = request.meta.get('cve_no', '')
        affected_version = request.meta.get('affected_version', 'Unknown')
        source_link = request.meta.get('source_link', request.url)
        retry_stage = request.meta.get('retry_stage', '')

        if retry_stage == 'nvd':
            cve_org_url = self.get_feed_url('cve_org_api_uri') + cve_no
            self.metrics['cve_org_fallback_requests'] += 1
            yield scrapy.Request(
                url=cve_org_url,
                callback=self.parse_cve_org,
                errback=self.errback_enrichment,
                dont_filter=True,
                headers={'Accept': 'application/json'},
                meta={
                    'cve_no': cve_no,
                    'affected_version': affected_version,
                    'source_link': source_link,
                    'retry_stage': 'cve_org',
                    'long_description': request.meta.get('long_description', ''),
                    'severity': request.meta.get('severity', '')
                }
            )
            return

        # CVE.org also failed; emit minimal record instead of dropping the CVE.
        self.metrics['minimal_items_emitted'] += 1
        yield self.build_item(
            cve_no=cve_no,
            affected_version=affected_version,
            source_link=source_link,
            long_description=request.meta.get('long_description', ''),
            severity=request.meta.get('severity', '')
        )

    def get_xpath(self, keys):
        # Centralized selector lookup from in-memory config cache.
        self._load_configs()
        return self.xpaths[keys]

    def get_feed_url(self, keys):
        # Centralized URL lookup from in-memory config cache.
        self._load_configs()
        return self.feed_urls[keys]

    @staticmethod
    def error_logging(error_msg):
        # Writes parser/runtime issues to MariaDB-specific log file.
        os.makedirs('mariadb', exist_ok=True)
        with open('mariadb/mariadb.log', 'a') as file:
            file.write(error_msg)

    @staticmethod
    def temp_files(name):  # logic for creating temp files. It checks for mariadb.log if not then creates it
        file_name = ''
        if os.path.exists(os.getcwd()):
            if os.path.isdir(os.path.join(os.getcwd(), name)):
                filepath = os.path.join(os.getcwd(), name)
                file_name = os.path.join(filepath, name) + '.log'
            else:
                os.makedirs(name)
                filepath = os.path.join(os.getcwd(), name)
                with open(os.path.join(filepath, name) + '.log', 'w') as file:
                    file_name = os.path.join(filepath, name) + '.log'
                    file.close()
        return file_name

    def errback_httpbin(self, failure):  # catching exception of parser.
        # Common errback for request-level HTTP/DNS/timeout failures.
        obj = self.temp_files(self.name)
        self.logger.error(repr(failure))

        # in case you want to do something special for some errors,
        # you may need the failure's type:

        if failure.check(HttpError):  # catches any http errors like like invalid urls
            # these exceptions come from HttpError spider middleware
            # you can get the non-200 response
            response = failure.value.response
            self.logger.error('HttpError on %s', response.url)  # logging errors in console
            with open(obj, 'w') as file:
                file.write('HttpError' + ' Error Code 101')  # writting the error code and error message to log files

        elif failure.check(DNSLookupError):  # catches connection lost exceptions
            # this is the original request
            request = failure.request

            self.logger.error('DNSLookupError on %s', request.url)  # logging errors in console
            with open(obj, 'w') as file:
                file.write('DNSLookupError' + ' Error Code 102')  # writting the error code and error message to log files

        elif failure.check(TimeoutError, TCPTimedOutError):  # catches timeout exceptions
            request = failure.request
            self.logger.error('TimeoutError on %s', request.url)  # logging errors in console
            with open(obj, 'w') as file:
                file.write('TimeoutError' + ' Error Code 103')  # writting the error code and error message to log files

        # If this errback fired for a series page request, the page will never
        # call parse(), so we must decrement the counter here and trigger
        # enrichment dispatch if all remaining pages are now accounted for.
        if self.pending_series_pages > 0:
            self.pending_series_pages -= 1

        if self.pending_series_pages == 0 and self.cve_records:
            for request in self.dispatch_enrichment_requests():
                yield request