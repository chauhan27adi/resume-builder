import scrapy
import re
from bs4 import BeautifulSoup as bs
from ..items import DvmautomationItem
from time import gmtime, strftime
from scrapy.spidermiddlewares.httperror import HttpError
from twisted.internet.error import DNSLookupError, TimeoutError, TCPTimedOutError
import utility
from .spider import Spider


# Major versions covered by the postgre_patch_base regex (9.5 through 18).
# 9.x versions use three-part versioning; 10+ use two-part (major.minor).
_SUPPORTED_MAJOR_VERSIONS = {
    '9.5', '9.6',
    '10', '11', '12', '13', '14', '15', '16', '17', '18',
}

# Matches the current-release cell: either "14.23" (10+) or "9.6.24" (9.x).
_PG_VERSION_RE = re.compile(r'\b(\d+(?:\.\d+){1,2})\b')


class CrawlPostgrePatch(Spider):
    name = 'postgre_patch'
    custom_settings = {
        'LOG_FILE': 'Crawler.log',
        'LOG_LEVEL': 'INFO',
    }

    def start_requests(self):
        url = utility.get_feed_urls('postgre_patch')
        self.logger.info('Starting PostgreSQL patch crawl: %s', url)
        yield scrapy.Request(url=url, callback=self.parse_versioning_page,
                             errback=self.errback_httpbin, dont_filter=True)

    def parse_versioning_page(self, response):
        """
        Parse the PostgreSQL versioning support page to extract the current
        release for each active major version.

        The page at postgresql.org/support/versioning/ contains a table whose
        rows list: major version, current minor release, first release date, and
        EOL date. For PostgreSQL 10+, the current-release column contains a
        two-part version (e.g. "16.9"); for 9.x it is three-part ("9.6.24").

        One DvmautomationItem is yielded per recognised major version.
        """
        self.logger.info('Got PostgreSQL versioning page: %s', response.url)
        soup = bs(response.text, 'html.parser')

        # Find a table whose first column contains known PostgreSQL major versions.
        target_table = None
        for table in soup.find_all('table'):
            first_col_vals = {
                tr.select('td')[0].get_text(strip=True)
                for tr in table.select('tr')
                if tr.select('td')
            }
            if first_col_vals & _SUPPORTED_MAJOR_VERSIONS:
                target_table = table
                break

        if target_table is None:
            self.logger.error('PostgreSQL versioning table not found at %s', response.url)
            return

        # Identify which column holds the current-release version.
        # Default is column 1 (index 1); override if a "current" header is found.
        current_col = 1
        th_els = target_table.select('thead th') or target_table.select('tr th')
        for i, th in enumerate(th_els):
            h = th.get_text(strip=True).lower()
            if 'current' in h or 'minor' in h or 'release' in h:
                current_col = i
                break

        ts = strftime('%Y-%m-%d %H:%M:%S', gmtime())
        seen = set()

        body_rows = target_table.select('tbody tr') or target_table.select('tr')[1:]
        for tr in body_rows:
            tds = tr.select('td')
            if not tds:
                continue

            major = tds[0].get_text(strip=True)
            if major not in _SUPPORTED_MAJOR_VERSIONS:
                continue
            if major in seen:
                continue

            current_cell = tds[current_col].get_text(strip=True) if len(tds) > current_col else ''

            # Extract the version number from the cell (may include surrounding text).
            ver_match = _PG_VERSION_RE.search(current_cell)
            if not ver_match:
                self.logger.warning('No version found in current-release cell for %s: %r',
                                    major, current_cell)
                continue

            cpv = ver_match.group(1)

            # Sanity-check: the extracted version should start with the major prefix.
            major_prefix = major.split('.')[0]  # "9" for "9.6", "14" for "14"
            if not cpv.split('.')[0] == major_prefix:
                self.logger.warning('Version %s does not match major %s; skipping', cpv, major)
                continue

            seen.add(major)

            item = DvmautomationItem()
            item['current_patch_version'] = cpv   # "16.9" for 10+, "9.6.24" for 9.x
            item['affected_version'] = cpv         # not used by postgre patch generator
            item['name'] = self.name
            item['timestamp'] = ts
            item['security_fixes'] = 'Patch'
            self.logger.info('PostgreSQL %s patch cpv: %s', major, cpv)
            yield item

    def errback_httpbin(self, failure):
        self.logger.error(repr(failure))
        if failure.check(HttpError):
            self.logger.error('HttpError on %s', failure.value.response.url)
        elif failure.check(DNSLookupError):
            self.logger.error('DNSLookupError on %s', failure.request.url)
        elif failure.check(TimeoutError, TCPTimedOutError):
            self.logger.error('TimeoutError on %s', failure.request.url)