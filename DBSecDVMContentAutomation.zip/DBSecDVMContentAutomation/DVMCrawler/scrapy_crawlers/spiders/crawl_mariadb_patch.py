import re
import scrapy
from bs4 import BeautifulSoup as bs
from time import gmtime, strftime

from scrapy.spidermiddlewares.httperror import HttpError
from twisted.internet.error import DNSLookupError, TimeoutError, TCPTimedOutError

import utility
from ..items import DvmautomationItem
from .spider import Spider

# MariaDB major families tracked by static_values.json.
# Ordered so the regex match picks the longest prefix first (10.11 before 10.1).
_FAMILIES = ['5.5', '10.1', '10.2', '10.3', '10.4', '10.5', '10.6', '10.11']

# Compiled pattern: full three-part version string, e.g. "10.11.8" or "5.5.68".
_VERSION_RE = re.compile(r'\b(\d+\.\d+\.\d+)\b')


def _major(version_str):
    """Return the major.minor prefix, e.g. '10.11' from '10.11.8'."""
    parts = version_str.split('.')
    # Handle three-part versions: major is parts[0], minor is parts[1].
    # For "10.11.8" → "10.11"; for "5.5.68" → "5.5".
    return '{}.{}'.format(parts[0], parts[1])


class CrawlMariadbPatch(Spider):
    name = 'mariadb_patch'
    custom_settings = {
        'LOG_FILE': 'Crawler.log',
        'LOG_LEVEL': 'INFO',
    }

    def start_requests(self):
        url = utility.get_feed_urls('maria_patch')
        self.logger.info('Starting MariaDB patch crawl: %s', url)
        yield scrapy.Request(url=url, callback=self.parse_releases_page,
                             errback=self.errback_httpbin, dont_filter=True)

    def parse_releases_page(self, response):
        """
        Parse the MariaDB +releases/ page.

        The page lists all releases in a table, newest first. Each row's link
        text is a full version string like "10.11.8" or "5.5.68". One item is
        yielded per tracked major family, using the first (newest) match.
        """
        self.logger.info('Got MariaDB releases page: %s', response.url)

        # The xpath key 'maria_list_patch' → CSS "table#download tr td a::text"
        # returns link texts from the releases table.
        texts = response.css(utility.get_xpath('maria_list_patch')).getall()

        if not texts:
            self.logger.error('No version links found on MariaDB releases page: %s', response.url)
            return

        # Build a map: family → newest full version (table is newest-first so
        # first match per family wins).
        family_cpv = {}
        for text in texts:
            text = text.strip()
            m = _VERSION_RE.search(text)
            if not m:
                continue
            ver = m.group(1)
            fam = _major(ver)
            if fam in _FAMILIES and fam not in family_cpv:
                family_cpv[fam] = ver

        if not family_cpv:
            self.logger.error('No recognised MariaDB family versions found at %s', response.url)
            return

        ts = strftime('%Y-%m-%d %H:%M:%S', gmtime())
        for fam in _FAMILIES:
            if fam not in family_cpv:
                self.logger.info('MariaDB family %s: no release found (EOL or not listed)', fam)
                continue
            cpv = family_cpv[fam]
            item = DvmautomationItem()
            item['name'] = self.name
            item['current_patch_version'] = cpv
            item['affected_version'] = cpv
            item['timestamp'] = ts
            item['security_fixes'] = 'Patch'
            self.logger.info('MariaDB %s patch cpv: %s', fam, cpv)
            yield item

    def errback_httpbin(self, failure):
        self.logger.error(repr(failure))
        if failure.check(HttpError):
            self.logger.error('HttpError on %s', failure.value.response.url)
        elif failure.check(DNSLookupError):
            self.logger.error('DNSLookupError on %s', failure.request.url)
        elif failure.check(TimeoutError, TCPTimedOutError):
            self.logger.error('TimeoutError on %s', failure.request.url)