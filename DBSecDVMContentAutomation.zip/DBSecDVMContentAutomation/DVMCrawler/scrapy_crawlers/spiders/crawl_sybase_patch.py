import re
import scrapy
from bs4 import BeautifulSoup as bs
from time import gmtime, strftime
from scrapy.spidermiddlewares.httperror import HttpError
from twisted.internet.error import DNSLookupError, TimeoutError, TCPTimedOutError
import utility
from ..items import DvmautomationItem
from .spider import Spider


class CrawlSybasePatch(Spider):
    name = 'sybase_patch'
    custom_settings = {'LOG_FILE': 'Crawler.log', 'LOG_LEVEL': 'INFO'}

    def start_requests(self):
        urls = utility.get_feed_urls('sybase_patch')
        self.logger.info('Starting Sybase patch crawl; 15.7=%s  16.0=%s', urls[0], urls[1])
        yield scrapy.Request(
            url=urls[0],
            callback=self.parse_15_7_page,
            errback=self.errback_httpbin,
            meta={'url_16_0': urls[1]},
            dont_filter=True,
        )

    def parse_15_7_page(self, response):
        """
        Parse the ASE 15.x release schedule page.

        Each table row is expected to contain a fix label matching
        sybase_patch_fixes ("SP\\d+ HF\\d?|SP\\d+") and optionally a date
        matching sybase_patch_date_list ("None|[A-Za-z]+, \\d+").

        Yields a request to the 16.0 page with patch_15_7 in meta so a
        single combined item can be produced there.

        CPV element format: ['15.7', fix_label, date]
        (tuples become lists through JSON round-trip; generation code uses
        indexed access so this is identical.)
        """
        fixes_pattern = utility.get_web_crawler_regex('sybase_patch_fixes')
        date_pattern = utility.get_web_crawler_regex('sybase_patch_date_list')

        selector = utility.get_xpath('sybase_patch')
        rows_html = response.css(selector).getall()
        self.logger.info('Sybase 15.7: found %d table rows at %s', len(rows_html), response.url)

        patch_15_7 = []
        for row_html in rows_html:
            soup = bs(row_html, 'html.parser')
            cells = soup.find_all('td')
            fix_label = None
            date = None
            for cell in cells:
                text = cell.get_text(separator=' ', strip=True)
                if fix_label is None:
                    m = re.search(fixes_pattern, text)
                    if m:
                        fix_label = m.group()
                if date is None:
                    m = re.search(date_pattern, text)
                    if m:
                        date = m.group()
            if fix_label:
                date = date if date else 'None'
                patch_15_7.append(['15.7', fix_label, date])

        self.logger.info('Sybase 15.7: extracted %d fix pack entries', len(patch_15_7))
        if not patch_15_7:
            self.logger.error('Sybase 15.7: no fix pack entries found — check page structure at %s', response.url)

        ts = strftime('%Y-%m-%d %H:%M:%S', gmtime())
        yield scrapy.Request(
            url=response.meta['url_16_0'],
            callback=self.parse_16_0_page,
            errback=self.errback_httpbin,
            meta={'patch_15_7': patch_15_7, 'ts': ts},
            dont_filter=True,
        )

    def parse_16_0_page(self, response):
        """
        Parse the ASE 16.0 release schedule page.

        Each table row is expected to contain a version matching
        sybase_patch_version_16 ("16.\\d.\\d\\d.\\d\\d") and a fix level
        matching sybase_patch_version_16_fixes.

        Combines the 15.7 data from meta and yields ONE item with:
          current_patch_version = [patch_15_7, patch_16]

        CPV element format: [version_string, fix_level]
        generate_check_16_02/03/04 check 'SP02'/'SP03'/'SP04' in str(ver),
        then use ver[1] as the fix level in the SQL query.
        """
        patch_15_7 = response.meta.get('patch_15_7', [])
        ts = response.meta.get('ts', strftime('%Y-%m-%d %H:%M:%S', gmtime()))

        ver16_pattern = utility.get_web_crawler_regex('sybase_patch_version_16')
        fixes16_pattern = utility.get_web_crawler_regex('sybase_patch_version_16_fixes')

        selector = utility.get_xpath('sybase_patch')
        rows_html = response.css(selector).getall()
        self.logger.info('Sybase 16.0: found %d table rows at %s', len(rows_html), response.url)

        patch_16 = []
        for row_html in rows_html:
            soup = bs(row_html, 'html.parser')
            cells = soup.find_all('td')
            version = None
            fix_level = None
            for cell in cells:
                text = cell.get_text(separator=' ', strip=True)
                if version is None:
                    m = re.search(ver16_pattern, text)
                    if m:
                        version = m.group()
                if fix_level is None:
                    m = re.search(fixes16_pattern, text)
                    if m:
                        fix_level = m.group()
            if version and fix_level:
                patch_16.append([version, fix_level])

        self.logger.info('Sybase 16.0: extracted %d fix pack entries', len(patch_16))
        if not patch_16:
            self.logger.error('Sybase 16.0: no fix pack entries found — check page structure at %s', response.url)

        item = DvmautomationItem()
        item['name'] = self.name
        item['current_patch_version'] = [patch_15_7, patch_16]
        item['affected_version'] = [patch_15_7, patch_16]
        item['timestamp'] = ts
        item['security_fixes'] = 'Patch'
        self.logger.info('Sybase patch item: 15.7 entries=%d, 16.0 entries=%d',
                         len(patch_15_7), len(patch_16))
        yield item

    def errback_httpbin(self, failure):
        self.logger.error(repr(failure))
        if failure.check(HttpError):
            self.logger.error('HttpError on %s', failure.value.response.url)
        elif failure.check(DNSLookupError):
            self.logger.error('DNSLookupError on %s', failure.request.url)
        elif failure.check(TimeoutError, TCPTimedOutError):
            self.logger.error('TimeoutError on %s', failure.request.url)