import scrapy                                       # to import scrapy framework
from ..items import DvmautomationItem               # importing the container classs
from bs4 import BeautifulSoup as bs                 # to parse html contents
from time import gmtime, strftime
from selenium import webdriver                      # to open browser
from selenium.webdriver.common.by import By
from io import BytesIO
import re
from selenium.webdriver.firefox.options import Options          # To make the browser headless
import json
import utility
import time
from datetime import datetime, timezone
from collections import OrderedDict
from urllib.parse import urljoin
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from .spider import Spider

try:
    from pypdf import PdfReader
except ImportError:
    PdfReader = None


class CrawlHanaDb(Spider):

    name = 'hanadb'                     # name of the spider

    # Configurable limit for number of most recent CVEs to fetch
    max_cves = 100

    _MONTH_MAP = {
        'january': 1, 'february': 2, 'march': 3, 'april': 4,
        'may': 5, 'june': 6, 'july': 7, 'august': 8,
        'september': 9, 'october': 10, 'november': 11, 'december': 12
    }
    _HANA_CONTEXT_KEYWORDS = (
        'hana', 'hdb', 'hdb_client', 'sap hana',
        'xs advanced', 'xs classic', 'extended application services'
    )
    custom_settings = {
        'LOG_FILE': 'Crawler.log',
        'LOG_LEVEL': 'DEBUG',
        'ROBOTSTXT_OBEY': False,
    }
    # Default lookback window (years) for SAP bulletin crawling.
    # Can be overridden when running spider via argument: -a sap_bulletin_years_back=<N>
    sap_bulletin_years_back = 1
    with open('credentials/credentials.json', 'r') as file:  # gets credentials from credential.json file
        json_content = json.loads(file.read())
        user = json_content[1]['sap_hana_username']
        passwd = json_content[1]['sap_hana_password']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.sap_cve_records = OrderedDict()
        self.seen_cves = set()
        self.pending_sap_pages = 0
        self.latest_sap_bulletin_date = None
        self.login_cache = {}  # note link -> affected_version list, avoids duplicate browser sessions
        self.affected_version_cache = {}  # cve_no -> affected_version list (external fallback cache)
        try:
            self.sap_bulletin_years_back = max(0, int(kwargs.get('sap_bulletin_years_back', self.sap_bulletin_years_back)))
        except (TypeError, ValueError):
            self.logger.warning(
                "Invalid sap_bulletin_years_back value '%s'; using default %d",
                kwargs.get('sap_bulletin_years_back'),
                self.sap_bulletin_years_back
            )

    def start_requests(self):           # Request is being sent to the url

        with open('credentials/urls.json', 'r') as file:  # gets Url from url.json file
            json_content = json.loads(file.read())
            hana_vuln = json_content['hana_vuln']
        self.logger.info("Dispatching official SAP vulnerability source url: %s", hana_vuln)
        yield scrapy.Request(url=hana_vuln, callback=self.parse)

    @staticmethod
    def get_archive_index_url(base_url):
        # Default archive path is nested under security-notes-news.
        # Example: .../knowledge-base/security-notes-news/security-patch-day-archives.html
        return urljoin(base_url, 'security-notes-news/security-patch-day-archives.html')

    @staticmethod
    def resolve_archive_index_url(response):
        # Prefer exact archive href from index page when present,
        # then fall back to known path patterns.
        for href in response.css('a::attr(href)').extract():
            abs_url = urljoin(response.url, href)
            if 'security-patch-day-archives' in abs_url:
                return abs_url

        return CrawlHanaDb.get_archive_index_url(response.url)

    @staticmethod
    def utcnow_naive():
        # Future-proof replacement for datetime.utcnow() while keeping
        # existing naive-UTC behavior used across this spider.
        return datetime.now(timezone.utc).replace(tzinfo=None)

    @staticmethod
    def extract_month_year_from_url(url):
        match = re.search(
            r'/(january|february|march|april|may|june|july|august|september|october|november|december)-(\d{4})\.html',
            url,
            re.IGNORECASE
        )
        if not match:
            return None
        month = CrawlHanaDb._MONTH_MAP[match.group(1).lower()]
        year = int(match.group(2))
        return datetime(year, month, 1)

    @classmethod
    def generate_bulletin_urls(cls, base_url, cutoff, now):
        urls = []
        bulletin_root = urljoin(base_url, 'security-notes-news/')
        # Path 1 (independent): 2026/current-year monthly HTML pages.
        # We intentionally generate only current-year month pages here.
        # Older years are discovered separately via archive index parsing
        # so changes to this path do not impact 2025/2024 HTML archives
        # or 2023-and-older PDF archives.
        current_year = now.year
        current_month = 1

        while current_month <= now.month:
            month_name = [name for name, month_number in cls._MONTH_MAP.items() if month_number == current_month][0]
            urls.append(urljoin(bulletin_root, f"{month_name}-{current_year}.html"))

            current_month += 1

        return urls

    @staticmethod
    def extract_year_from_archive_url(url):
        year_match = re.search(r'(?:bulletin-|/)(20\d{2})(?:\.html|%20Patch%20Day%20Bulletin(?:_new)?\.pdf|\sPatch\sDay\sBulletin(?:_new)?\.pdf)', url, re.IGNORECASE)
        if year_match:
            return int(year_match.group(1))
        return None

    def dispatch_prepared_bulletins(self, bulletin_links, cutoff):
        bulletin_links = sorted(bulletin_links, key=lambda item: item['url'])
        self.pending_sap_pages = len(bulletin_links)
        self.logger.info(
            "Prepared %d SAP bulletin links (%d-year window from %s)",
            self.pending_sap_pages,
            self.sap_bulletin_years_back,
            cutoff.strftime('%Y-%m')
        )
        if bulletin_links:
            self.logger.debug("Sample SAP bulletin links: first=%s, last=%s", bulletin_links[0]['url'], bulletin_links[-1]['url'])

        if self.pending_sap_pages == 0:
            self.logger.warning("No SAP bulletin links discovered; using MITRE fallback")
            fallback_url = utility.get_feed_urls("mitre_cve").format('hana')
            yield scrapy.Request(url=fallback_url, callback=self.parse_mitre_fallback)
            return

        kind_counts = OrderedDict()
        for item in bulletin_links:
            kind_counts[item['kind']] = kind_counts.get(item['kind'], 0) + 1
            callback = self.parse_pdf_bulletin if item['kind'] == 'archive_pdf' else self.parse_sap_bulletin
            self.logger.debug("Dispatching SAP bulletin request (%s): %s", item['kind'], item['url'])
            yield scrapy.Request(url=item['url'], callback=callback, errback=self.handle_sap_bulletin_error)
        self.logger.info("SAP bulletin discovery split: %s", dict(kind_counts))

    def parse_archive_index(self, response, current_year_links=None, cutoff=None):
        current_year_links = set(tuple(entry) for entry in (current_year_links or []))
        now_utc = self.utcnow_naive()
        cutoff = cutoff or datetime(now_utc.year - self.sap_bulletin_years_back, now_utc.month, 1)
        archive_links = set(current_year_links)

        for href in response.css('a::attr(href)').extract():
            abs_url = urljoin(response.url, href)
            year = self.extract_year_from_archive_url(abs_url)
            if not year or year < cutoff.year:
                continue
            # Path 2 and Path 3 (independent):
            # - 2025 and 2024 -> yearly archive HTML pages (archive_html)
            # - 2023 and older -> mostly PDF archives (archive_pdf)
            # We keep the type marker in `kind` so each parser is routed
            # independently and one flow cannot break the other.
            kind = 'archive_pdf' if abs_url.lower().endswith('.pdf') else 'archive_html'
            archive_links.add((abs_url, kind))

        prepared_links = [{'url': url, 'kind': kind} for url, kind in archive_links]
        self.logger.info("Archive index contributed %d archive links", max(0, len(prepared_links) - len(current_year_links)))
        yield from self.dispatch_prepared_bulletins(prepared_links, cutoff)

    def handle_archive_index_error(self, failure):
        archive_url = getattr(getattr(failure, 'request', None), 'url', '<unknown-url>')
        request = getattr(failure, 'request', None)
        cb_kwargs = getattr(request, 'cb_kwargs', {}) or {}
        current_year_links = set(tuple(entry) for entry in cb_kwargs.get('current_year_links', []))
        now_utc = self.utcnow_naive()
        cutoff = cb_kwargs.get('cutoff') or datetime(now_utc.year - self.sap_bulletin_years_back, now_utc.month, 1)
        self.logger.warning("Archive index request failed for %s; proceeding with current-year monthly pages only", archive_url)
        yield from self.dispatch_prepared_bulletins(
            [{'url': url, 'kind': kind} for url, kind in current_year_links],
            cutoff
        )

    @classmethod
    def is_hana_context(cls, text):
        lowered = (text or '').lower()
        return any(keyword in lowered for keyword in cls._HANA_CONTEXT_KEYWORDS)

    def merge_cves_from_text(self, text, source_url, context_window=350):
        normalized = re.sub(r'\s+', ' ', text or '').strip()
        if not normalized:
            self.logger.debug("No bulletin text found for parsing: %s", source_url)
            return 0, 0

        row_hits = 0
        cve_hits = 0
        for match in re.finditer(r'CVE-\d{4}-\d{4,7}', normalized):
            start = max(0, match.start() - context_window)
            end = min(len(normalized), match.end() + context_window)
            context = normalized[start:end]
            if not self.is_hana_context(context):
                continue
            row_hits += 1
            cve_hits += 1
            self.merge_sap_cve_record(match.group(0), sap_row=context)

        self.logger.debug("Text merge stats for %s => row_hits=%d, cve_hits=%d", source_url, row_hits, cve_hits)
        return row_hits, cve_hits

    def finalize_sap_progress(self):
        self.pending_sap_pages -= 1
        self.logger.info("SAP bulletin parse progress: %d pages remaining", self.pending_sap_pages)
        if self.pending_sap_pages == 0:
            if not self.sap_cve_records:
                self.logger.warning("No SAP-derived CVEs found. Falling back to MITRE keyword discovery")
                fallback_url = utility.get_feed_urls("mitre_cve").format('hana')
                yield scrapy.Request(url=fallback_url, callback=self.parse_mitre_fallback)
                return
            yield from self.dispatch_from_sap_records()

    def source_stale(self):
        if not self.latest_sap_bulletin_date:
            return True
        age_days = (self.utcnow_naive() - self.latest_sap_bulletin_date).days
        return age_days > 45

    def merge_sap_cve_record(self, cve_no, sap_row=None):
        if cve_no not in self.sap_cve_records:
            self.sap_cve_records[cve_no] = {
                'cve_no': cve_no,
                'severity': None,
                'long_description': None,
                'link': None,
            }
            self.logger.debug("Created SAP seed record for CVE: %s", cve_no)

        record = self.sap_cve_records[cve_no]
        if sap_row:
            if not record['link']:
                note_match = re.search(r'\b(\d{7})\b', sap_row)
                if note_match:
                    record['link'] = f"https://launchpad.support.sap.com/#/notes/{note_match.group(1)}"
                    self.logger.debug("Mapped %s to SAP note link: %s", cve_no, record['link'])

            if not record['severity']:
                sev_match = re.search(r'\b(Critical|High|Medium|Low)\b', sap_row, re.IGNORECASE)
                if sev_match:
                    record['severity'] = sev_match.group(1).upper()
                    self.logger.debug("Seeded severity for %s from SAP row: %s", cve_no, record['severity'])

            if not record['long_description']:
                cleaned = re.sub(r'\s+', ' ', sap_row).strip()
                record['long_description'] = cleaned[:1200]
                self.logger.debug("Seeded long description for %s (len=%d)", cve_no, len(record['long_description']))

    def dispatch_from_sap_records(self):
        self.logger.info("SAP discovery complete. Unique CVEs collected: %d", len(self.sap_cve_records))
        if self.source_stale():
            self.logger.warning("SAP upstream feed may be stale: latest bulletin is older than 45 days")

        nvd_base_url = utility.get_feed_urls("nvd_uri")
        cve_items = list(self.sap_cve_records.items())[:self.max_cves]
        self.logger.info("Emitting top %d CVEs (page order) from %d collected", self.max_cves, len(self.sap_cve_records))
        for cve_no, record in cve_items:
            needs_nvd = not (record.get('severity') and record.get('long_description') and record.get('link'))
            if needs_nvd:
                nvd_url = nvd_base_url + cve_no
                self.logger.debug("Enriching missing data from NVD for %s", cve_no)
                yield scrapy.Request(
                    url=nvd_url,
                    callback=self.intermediate_navigate,
                    cb_kwargs={'seed_record': record}
                )
            else:
                yield from self.build_and_yield_item(cve_no, seed_record=record)

    def parse_sap_bulletin(self, response):
        self.logger.info("Parsing SAP bulletin page: %s", response.url)
        bulletin_date = self.extract_month_year_from_url(response.url)
        if bulletin_date and (not self.latest_sap_bulletin_date or bulletin_date > self.latest_sap_bulletin_date):
            self.latest_sap_bulletin_date = bulletin_date
            self.logger.debug("Updated latest SAP bulletin date to: %s", bulletin_date.strftime('%Y-%m'))

        soup = bs(response.text, 'html.parser')
        rows = soup.select('table tr')
        row_hits = 0
        cve_hits = 0

        for row in rows:
            row_text = ' '.join(row.stripped_strings)
            cves = re.findall(r'CVE-\d{4}-\d{4,7}', row_text)
            if not cves:
                continue
            if 'hana' not in row_text.lower():
                continue

            row_hits += 1
            for cve_no in cves:
                cve_hits += 1
                self.merge_sap_cve_record(cve_no, sap_row=row_text)

        self.logger.debug("SAP bulletin parse stats for %s => rows_with_hana_cves=%d, cve_mentions=%d", response.url, row_hits, cve_hits)

        if row_hits == 0:
            plain_text = soup.get_text(' ', strip=True)
            _, fallback_cve_hits = self.merge_cves_from_text(plain_text, response.url, context_window=250)
            self.logger.debug("SAP bulletin fallback context scan found %d HANA CVE mentions for %s", fallback_cve_hits, response.url)

        yield from self.finalize_sap_progress()

    def parse_pdf_bulletin(self, response):
        # Path 3 (independent): 2023 and older bulletin archives are mostly PDFs.
        # This parser only handles PDF links and does not modify monthly/yearly
        # HTML discovery behavior.
        self.logger.info("Parsing SAP PDF bulletin archive: %s", response.url)
        if PdfReader is None:
            self.logger.error("pypdf is unavailable; cannot parse PDF: %s", response.url)
            yield from self.finalize_sap_progress()
            return

        try:
            reader = PdfReader(BytesIO(response.body))
            pages = []
            for page in reader.pages:
                try:
                    pages.append(page.extract_text() or '')
                except Exception as page_err:
                    self.logger.debug("PDF page extraction issue for %s: %s", response.url, str(page_err))
            full_text = '\n'.join(pages)
            self.logger.info("PDF pages parsed: %d for %s", len(pages), response.url)
            self.merge_cves_from_text(full_text, response.url, context_window=500)
        except Exception as err:
            self.logger.error("Failed to parse PDF bulletin %s: %s", response.url, str(err))

        yield from self.finalize_sap_progress()

    def parse_mitre_fallback(self, response):
        payloads = response.xpath(utility.get_xpath("hana_payload")).extract()
        self.logger.info("MITRE fallback found %d CVE ids on page: %s", len(payloads), response.url)
        queued = 0
        duplicates = 0
        for payload in payloads:
            if payload in self.seen_cves:
                duplicates += 1
                continue
            self.seen_cves.add(payload)
            actual_link = utility.get_feed_urls("nvd_uri") + payload
            queued += 1
            yield scrapy.Request(
                url=actual_link,
                callback=self.intermediate_navigate,
                cb_kwargs={'seed_record': None}
            )
        self.logger.debug("MITRE fallback queue summary => queued=%d, skipped_duplicates=%d", queued, duplicates)
# This function gets the vulnerability link extract the cves from it and construct
# the nvd link and send it to intermediate navigate function.

    def parse(self, response):
        self.logger.info("Parsing SAP official index page: %s", response.url)
        now = self.utcnow_naive()
        cutoff = datetime(now.year - self.sap_bulletin_years_back, now.month, 1)
        links = response.css('a::attr(href)').extract()
        bulletin_links = set()
        for href in links:
            abs_url = urljoin(response.url, href)
            if 'support.sap.com/en/my-support/knowledge-base/security-notes-news/' not in abs_url:
                continue
            bdate = self.extract_month_year_from_url(abs_url)
            # Path 1 (independent): current-year monthly HTML entries from index page.
            if bdate and bdate.year == now.year and bdate >= datetime(now.year, 1, 1):
                bulletin_links.add((abs_url, 'monthly_html'))

        # Path 1 (independent): current-year monthly HTML generated deterministically,
        # even when index page misses one or more month links.
        bulletin_links.update((url, 'monthly_html') for url in self.generate_bulletin_urls(response.url, cutoff, now))
        archive_index_url = self.resolve_archive_index_url(response)
        # Path 2 + Path 3 (independent): archive index is parsed separately to
        # collect yearly HTML archive pages (2025/2024) and PDF archives (2023/older).
        self.logger.info("Dispatching archive index request: %s", archive_index_url)
        yield scrapy.Request(
            url=archive_index_url,
            callback=self.parse_archive_index,
            errback=self.handle_archive_index_error,
            cb_kwargs={'current_year_links': sorted(bulletin_links), 'cutoff': cutoff}
        )

    def handle_sap_bulletin_error(self, failure):
        request_url = getattr(getattr(failure, 'request', None), 'url', '<unknown-url>')
        self.pending_sap_pages -= 1
        self.logger.debug("SAP bulletin request failed for %s; remaining pages: %d", request_url, self.pending_sap_pages)
        if self.pending_sap_pages == 0:
            if not self.sap_cve_records:
                self.logger.warning("No SAP-derived CVEs found after bulletin requests. Falling back to MITRE keyword discovery")
                fallback_url = utility.get_feed_urls("mitre_cve").format('hana')
                yield scrapy.Request(url=fallback_url, callback=self.parse_mitre_fallback)
                return
            yield from self.dispatch_from_sap_records()

# function to collect the long description

    def long_description(self, response):
        description = response.css(utility.get_xpath('hana_description')).extract()
        if not description:
            self.logger.warning("No long description found for: %s", response.url)
            return None
        self.logger.debug("Long description extracted for %s (len=%d)", response.url, len(description[0]))
        return description[0]
# function to collect the severity

    def severity(self, response):
        try:
            basescore = response.css(utility.get_xpath('hana_basescore')).extract()
            if basescore:
                self.logger.debug("Severity found with primary selector for: %s", response.url)
                return basescore
            else:
                basescore = response.css(utility.get_xpath('hana_basescore_case2')).extract()
                if basescore:
                    self.logger.debug("Severity found with fallback selector for: %s", response.url)
                else:
                    self.logger.warning("Severity not found for: %s", response.url)
                return basescore
        except Exception:
            self.logger.error("Failed to get Sap hana Severity")

# function to collect the url where affected version is available
    def url_for_affected_version(self, response):
        for case_key in ('hana_url_case1', 'hana_url_case2', 'hana_url_case3'):
            hrefs = response.css(utility.get_xpath(case_key)).extract()
            if hrefs and 'launchpad.support' in hrefs[0]:
                self.logger.debug("Using affected-version link (%s) for: %s", case_key, response.url)
                return hrefs[0]
        self.logger.warning("No launchpad.support reference found on NVD page: %s", response.url)
        return None

    @staticmethod
    def _dedupe_preserve_order(values):
        deduped = []
        seen = set()
        for value in values:
            normalized = str(value or '').strip()
            if not normalized:
                continue
            key = normalized.lower()
            if key in seen:
                continue
            seen.add(key)
            deduped.append(normalized)
        return deduped

    def _fetch_json(self, url, timeout=12):
        try:
            req = Request(url, headers={
                'User-Agent': 'Mozilla/5.0 (compatible; DBSecDVMContentAutomation/1.0)'
            })
            with urlopen(req, timeout=timeout) as resp:
                payload = resp.read().decode('utf-8', errors='ignore')
            return json.loads(payload)
        except HTTPError as err:
            self.logger.debug("HTTP error while fetching %s: %s", url, str(err))
        except URLError as err:
            self.logger.debug("URL error while fetching %s: %s", url, str(err))
        except Exception as err:
            self.logger.debug("Unexpected error while fetching %s: %s", url, str(err))
        return None

    def _extract_affected_from_nvd_api(self, payload):
        results = []
        if not isinstance(payload, dict):
            return results

        vulnerabilities = payload.get('vulnerabilities') or []
        if not vulnerabilities:
            return results

        cve = vulnerabilities[0].get('cve') or {}
        configurations = cve.get('configurations') or []

        def walk_nodes(nodes):
            for node in nodes or []:
                for match in node.get('cpeMatch') or []:
                    criteria = match.get('criteria') or ''
                    parts = criteria.split(':')
                    vendor = parts[3] if len(parts) > 3 else ''
                    product = parts[4] if len(parts) > 4 else ''
                    cpe_version = parts[5] if len(parts) > 5 else ''

                    if vendor and product:
                        label = "%s:%s" % (vendor, product)
                        if cpe_version and cpe_version not in ('*', '-'):
                            label = "%s:%s" % (label, cpe_version)
                        results.append(label)

                    vsi = match.get('versionStartIncluding')
                    vse = match.get('versionStartExcluding')
                    vei = match.get('versionEndIncluding')
                    vee = match.get('versionEndExcluding')
                    if vsi:
                        results.append("versionStartIncluding=%s" % vsi)
                    if vse:
                        results.append("versionStartExcluding=%s" % vse)
                    if vei:
                        results.append("versionEndIncluding=%s" % vei)
                    if vee:
                        results.append("versionEndExcluding=%s" % vee)

                walk_nodes(node.get('nodes') or [])

        walk_nodes(configurations)
        return self._dedupe_preserve_order(results)

    def _extract_affected_from_cve_org(self, payload):
        results = []
        if not isinstance(payload, dict):
            return results

        containers = payload.get('containers') or {}
        cna = containers.get('cna') or {}
        affected = cna.get('affected') or []

        for product_item in affected:
            vendor = str(product_item.get('vendor') or '').strip()
            product = str(product_item.get('product') or '').strip()
            product_label = ':'.join([val for val in (vendor, product) if val])

            versions = product_item.get('versions') or []
            if not versions and product_label:
                results.append(product_label)
                continue

            for version_obj in versions:
                version = str(version_obj.get('version') or '').strip()
                status = str(version_obj.get('status') or '').strip()
                less_than = str(version_obj.get('lessThan') or '').strip()
                less_than_or_equal = str(version_obj.get('lessThanOrEqual') or '').strip()

                parts = []
                if product_label:
                    parts.append(product_label)
                if version:
                    parts.append("version=%s" % version)
                if status:
                    parts.append("status=%s" % status)
                if less_than:
                    parts.append("lessThan=%s" % less_than)
                if less_than_or_equal:
                    parts.append("lessThanOrEqual=%s" % less_than_or_equal)

                if parts:
                    results.append(' | '.join(parts))

        return self._dedupe_preserve_order(results)

    def _extract_versions_from_text(self, text):
        text = text or ''
        tokens = []
        for version in re.findall(r'\b(?:[12]\.\d{1,2}(?:\.\d{1,3}){1,3}|\d{1,2}\.\d{1,2}\.\d{1,3})\b', text):
            tokens.append("version=%s" % version)

        for rng in re.findall(r'\b(?:before|through|up to|prior to)\s+([0-9]+(?:\.[0-9]+){1,3})\b', text, re.IGNORECASE):
            tokens.append("versionBoundary=%s" % rng)

        return self._dedupe_preserve_order(tokens)

    def _extract_versions_from_sap_bulletin(self, text):
        """
        Extract the version string from SAP security bulletin long_description.
        SAP bulletins consistently follow the format:
          '...Product - <name> Version(s) - <versions> Critical 9.1'
        Returns a single-element list with the version substring, e.g.
          ['S4CORE 102, 103, 104, 105, 106, 107, 108, 109']
          ['HANABPC 810, BPC4HANA 300, SAP_BW 750, 752, 753, 816']
          ['HDB 2.00']
        """
        if not text:
            return []
        match = re.search(
            r'Version\(?s\)?\s*[-–]\s*(.+?)\s+(?:Critical|High|Medium|Low)\s+\d+(?:\.\d+)?',
            text, re.IGNORECASE
        )
        if match:
            return [match.group(1).strip()]
        return []

    @staticmethod
    def _format_cpe_as_readable(s):
        """
        Convert raw NVD CPE and CVE.org version strings into readable form.
          'sap:s\\/4_hana:102'                              → 'S/4Hana 102'
          'sap:hana_database:2.00'                          → 'Hana Database 2.00'
          'SAP_SE:SAP S/4HANA | version=S4FND 102 | ...'   → 'SAP S/4HANA S4FND 102'
        Returns None for pure version-range helper entries (versionStartIncluding= etc.)
        that carry no extra information when per-version CPE entries are already present.
        """
        if not s:
            return None
        # Drop pure version-range helper entries — they duplicate CPE per-version rows.
        for skip_prefix in ('versionStartIncluding=', 'versionStartExcluding=',
                            'versionEndIncluding=', 'versionEndExcluding='):
            if s.startswith(skip_prefix):
                return None
        # CVE.org pipe format: "vendor:Product Name | version=X | status=Y | ..."
        if '|' in s:
            parts = [p.strip() for p in s.split('|')]
            product = parts[0].split(':', 1)[-1].strip() if parts else ''
            version = ''
            for part in parts[1:]:
                if part.startswith('version='):
                    version = part[len('version='):].strip()
                    break
            if product and version:
                return '%s %s' % (product, version)
            return product or None
        # NVD CPE format: "sap:product_name:version"
        if ':' in s:
            cpe_parts = s.split(':')
            product = cpe_parts[1].replace('\\/', '/').replace('_', ' ').title() if len(cpe_parts) > 1 else ''
            version = cpe_parts[2] if len(cpe_parts) > 2 and cpe_parts[2] not in ('*', '-', '') else ''
            if product and version:
                return '%s %s' % (product, version)
            return product.strip() or None
        return s

    def normalize_hana_affected_versions(self, raw_values):
        """
        Normalize heterogeneous values into the strict legacy HANA format
        consumed by check generation: flat triplets of
        ["SAP HANA DATABASE {major}.0", "SPxxx", "build"].
        """
        if not raw_values:
            return []

        if isinstance(raw_values, list):
            chunks = [str(v) for v in raw_values if v is not None]
        else:
            chunks = [str(raw_values)]

        merged_text = ' '.join(chunks)
        triples = []

        # 1) Already-internal triplets from SAP note parsing path.
        if isinstance(raw_values, list) and len(raw_values) >= 3:
            for i in range(0, len(raw_values), 3):
                grp = raw_values[i:i + 3]
                if len(grp) < 3:
                    continue

                product = str(grp[0]).strip()
                sp_token = str(grp[1]).strip().upper()
                build_token = str(grp[2]).strip()

                if 'SAP HANA DATABASE' not in product.upper():
                    continue
                if not re.search(r'\bSP\d{1,3}\b', sp_token):
                    continue
                if not re.search(r'\d{1,4}', build_token):
                    continue

                major_match = re.search(r'([12](?:\.0)?)', product)
                major = major_match.group(1) if major_match else '1.0'
                if major in ('1', '2'):
                    major = major + '.0'

                sp_num = int(re.findall(r'\d+', sp_token)[0])
                build_num = int(re.findall(r'\d{1,4}', build_token)[0])

                triples.append((
                    "SAP HANA DATABASE %s" % major,
                    "SP%03d" % sp_num,
                    str(build_num)
                ))

        # 2) Dotted forms from fallback APIs/text:
        #    1.00.122.24, 2.00.037.00, 1.00.000.1063, etc.
        for major, sp_raw, build_raw in re.findall(r'\b([12])\.00\.(\d{2,3})\.(\d{1,4})\b', merged_text):
            triples.append((
                "SAP HANA DATABASE %s.0" % major,
                "SP%03d" % int(sp_raw),
                str(int(build_raw))
            ))

        # De-duplicate while preserving order.
        unique = []
        seen = set()
        for t in triples:
            if t in seen:
                continue
            seen.add(t)
            unique.append(t)

        normalized = []
        for product, sp_token, build_token in unique:
            normalized.extend([product, sp_token, build_token])

        # No HANA DATABASE patterns matched — return raw API strings so callers
        # get real data (e.g. S4CORE version ranges from NVD/CVE.org) instead of [].
        if not normalized and chunks:
            return chunks

        return normalized

    def fetch_affected_versions_external(self, cve_no, description=None):
        if not cve_no:
            return []

        if cve_no in self.affected_version_cache:
            self.logger.debug("External affected-version cache hit for %s", cve_no)
            return self.affected_version_cache[cve_no]

        resolved = []

        # Source 0: SAP bulletin text already in long_description — no network call needed.
        # Format: '...Version(s) - S4CORE 102, 103 Critical 9.1'  → ['S4CORE 102, 103']
        bulletin_versions = self._extract_versions_from_sap_bulletin(description)
        if bulletin_versions:
            self.logger.info("Resolved affected versions from SAP bulletin text for %s", cve_no)
            resolved.extend(bulletin_versions)

        # Source 1: NVD REST API 2.0
        if not resolved:
            nvd_api_url = "https://services.nvd.nist.gov/rest/json/cves/2.0?cveId=%s" % cve_no
            nvd_payload = self._fetch_json(nvd_api_url)
            if nvd_payload:
                raw = self._extract_affected_from_nvd_api(nvd_payload)
                nvd_versions = [self._format_cpe_as_readable(s) for s in raw]
                nvd_versions = [v for v in nvd_versions if v]
                if nvd_versions:
                    self.logger.info("Resolved affected versions from NVD API for %s (count=%d)", cve_no, len(nvd_versions))
                    resolved.extend(nvd_versions)

        # Source 2: CVE.org API (CNA provided affected versions)
        if not resolved:
            cve_org_url = "https://cveawg.mitre.org/api/cve/%s" % cve_no
            cve_org_payload = self._fetch_json(cve_org_url)
            if cve_org_payload:
                raw = self._extract_affected_from_cve_org(cve_org_payload)
                cve_org_versions = [self._format_cpe_as_readable(s) for s in raw]
                cve_org_versions = [v for v in cve_org_versions if v]
                if cve_org_versions:
                    self.logger.info("Resolved affected versions from CVE.org API for %s (count=%d)", cve_no, len(cve_org_versions))
                    resolved.extend(cve_org_versions)

        # Source 3: Fallback regex parse from description text
        if not resolved:
            description_versions = self._extract_versions_from_text(description)
            if description_versions:
                self.logger.info("Resolved affected versions from description parsing for %s (count=%d)", cve_no, len(description_versions))
                resolved.extend(description_versions)

        resolved = self._dedupe_preserve_order(resolved)
        resolved = self.normalize_hana_affected_versions(resolved)
        self.affected_version_cache[cve_no] = resolved
        if not resolved:
            self.logger.warning("External affected-version resolution returned empty for %s", cve_no)
        return resolved

# calls all the funtion and store it into the container
# pipe line those contain for insertion into the mongo db data base

    def intermediate_navigate(self, response, seed_record=None):
        try:
            items = DvmautomationItem()
            self.logger.info("Processing vulnerability details for: %s", response.url)
            seed_record = seed_record or {}
            cve_no = response.url.split('/')[-1]

            nvd_severity = self.severity(response)
            nvd_desc = self.long_description(response)
            link = seed_record.get('link') or self.url_for_affected_version(response)

            resolved_severity = seed_record.get('severity')
            if not resolved_severity and nvd_severity:
                resolved_severity = str(nvd_severity[0]).strip().split(' ')[-1]

            if not resolved_severity:
                self.logger.error("Could not retrieve severity for %s", response.url)
                return

            resolved_description = seed_record.get('long_description') or nvd_desc
            items['severity'] = resolved_severity
            items['long_description'] = resolved_description
            self.logger.debug(
                "Resolved fields for %s => severity=%s, description_source=%s, link_source=%s",
                response.url.split('/')[-1],
                items['severity'],
                'SAP' if seed_record.get('long_description') else 'NVD',
                'SAP' if seed_record.get('link') else 'NVD'
            )
            if not link:
                self.logger.warning("Affected-version link not found for %s; continuing with link=unknown", response.url)
                link = 'unknown'
            affected_version = self.fetch_affected_versions_external(cve_no, items['long_description'])

            items['cve_no'] = cve_no
            items['affected_version'] = self.normalize_hana_affected_versions(affected_version)
            items['timestamp'] = strftime("%Y-%m-%d %H:%M:%S", gmtime())
            items['link'] = link
            items['security_fixes'] = 'Vulnerability'
            if items['affected_version']:
                items['name'] = self.name
                self.logger.info("Checks: %s", items)
            else:
                items['affected_version'] = 'unknown'
                items['name'] = self.name
                self.logger.warning(
                    "Affected version is empty; yielding record for %s with marker affected_version=unknown",
                    items['cve_no']
                )
            yield items
        except (AttributeError, TypeError) as Ae:
            self.logger.error("Failed to collect details: %s", str(Ae))
            
    def build_and_yield_item(self, cve_no, seed_record=None):
        try:
            seed_record = seed_record or {}
            link = seed_record.get('link')
            if not link:
                self.logger.warning("No SAP note link available for %s; continuing with link=unknown", cve_no)
                link = 'unknown'

            self.logger.debug("Building SAP-seeded item for %s using link=%s", cve_no, link)
            items = DvmautomationItem()
            items['severity'] = (seed_record.get('severity') or 'MEDIUM').upper()
            items['long_description'] = seed_record.get('long_description')
            items['cve_no'] = cve_no
            items['affected_version'] = self.fetch_affected_versions_external(cve_no, items['long_description'])
            items['affected_version'] = self.normalize_hana_affected_versions(items['affected_version'])
            items['timestamp'] = strftime("%Y-%m-%d %H:%M:%S", gmtime())
            items['link'] = link
            items['security_fixes'] = 'Vulnerability'

            if items['affected_version']:
                items['name'] = self.name
                self.logger.info("Checks: %s", items)
            else:
                items['affected_version'] = 'unknown'
                items['name'] = self.name
                self.logger.warning(
                    "Affected version is empty; yielding record for %s with marker affected_version=unknown",
                    cve_no
                )
            yield items
        except (AttributeError, TypeError) as err:
            self.logger.error("Failed to build SAP-seeded vulnerability item for %s: %s", cve_no, str(err))
        except Exception as err:
            self.logger.error("Unexpected error while building SAP-seeded vulnerability item for %s: %s", cve_no, str(err))

# login to sap hana page and extract affected version
    def login(self, link):
        if link in self.login_cache:
            self.logger.debug("Affected-version cache hit for note: %s", link)
            return self.login_cache[link]
        browser = None
        try:
            delay = 10
            opts = Options()
            opts.add_argument('-headless')
            self.logger.info("Launching browser to fetch affected versions from: %s", link)
            browser = webdriver.Firefox(options=opts)
            browser.get(link)
            utility.wait_until_page_reloads(delay, browser, 'ids-login-container')
            username = browser.find_element(By.ID, "j_username")
            username.send_keys(self.user)
            browser.find_element(By.XPATH, "//*[@type='submit']").click()
            utility.wait_until_page_reloads(delay, browser, "j_password")
            password = browser.find_element(By.ID, "j_password")
            password.send_keys(self.passwd)
            browser.find_element(By.XPATH, "//*[@type='submit']").click()

            browser.maximize_window()
            time.sleep(3)
            self.logger.info("Post-login landing URL: %s", browser.current_url)

            # New SAP SSO flow: account picker page appears after password submit.
            if 'accounts.sap.com' in browser.current_url:
                self.logger.info("SAP account selection page detected; attempting to choose the default account")
                clicked = False
                for sel in (
                    "//button[contains(@class,'tile')]",
                    "//li//button",
                    "//button[contains(@class,'account')]",
                    "//button[@type='submit']",
                    "//button",
                ):
                    try:
                        options = browser.find_elements(By.XPATH, sel)
                        if options:
                            options[0].click()
                            clicked = True
                            self.logger.info("Clicked account selector using xpath: %s", sel)
                            break
                    except Exception:
                        pass
                if not clicked:
                    self.logger.warning("Unable to find a clickable account selector on SAP SSO page")

            # Wait until SAP launchpad page is reached.
            reached_launchpad = False
            for _ in range(30):
                if 'launchpad.support.sap.com' in browser.current_url:
                    reached_launchpad = True
                    break
                time.sleep(1)

            self.logger.info("Launchpad reached=%s, current_url=%s", reached_launchpad, browser.current_url)
            if not reached_launchpad:
                self.logger.warning("Could not reach SAP launchpad note page; skipping affected-version extraction")
                return []

            # Wait for dynamic table rendering in SAP UI.
            affected_ver = []
            for _ in range(20):
                try:
                    affected_ver = browser.find_elements(By.CSS_SELECTOR, 'tbody tr')
                except Exception:
                    affected_ver = []
                if affected_ver:
                    break
                time.sleep(1)

            self.logger.info("Selenium affected-version rows fetched: %d", len(affected_ver))
            val = browser.page_source.encode('utf-8')
            val_soup = bs(val, 'html.parser')
            affected_rows = [str(r) for r in val_soup.select('tbody tr')]
            if affected_rows:
                self.logger.info("BS4 parsed affected-version rows fetched: %d", len(affected_rows))
            else:
                self.logger.info("BS4 parsed affected-version rows fetched: 0")

            aff_regex = utility.get_web_crawler_regex("hana_vuln_affected_val1")
            triples = []
            for row_str in affected_rows:
                row_text = bs(row_str, 'html.parser').get_text(' ', strip=True)
                normalized = ' '.join(row_text.split())
                upper = normalized.upper()

                # Ignore CVSS metric rows and unrelated UI rows.
                if any(skip_key in upper for skip_key in (
                    "ATTACK VECTOR", "PRIVILEGES REQUIRED", "USER INTERACTION",
                    "CONFIDENTIALITY", "INTEGRITY", "AVAILABILITY", "BASE SCORE"
                )):
                    continue

                # Product token (prefer exact match; fallback to HDB token or generic HANA).
                product = None
                val1 = re.findall(aff_regex, upper, re.IGNORECASE)
                if val1:
                    product = val1[0].upper()
                else:
                    hdb_match = re.search(r'\bHDB\s*(\d+(?:\.\d+)?)\b', upper)
                    if hdb_match:
                        hdb_ver = hdb_match.group(1)
                        product = f"SAP HANA DATABASE {hdb_ver}"
                    elif "SAP EXTENDED APP SERVICES" in upper:
                        product = "SAP EXTENDED APP SERVICES 1"

                sp_vals = [f"SP{int(v):03d}" for v in re.findall(r'\bSP\s*0*(\d{1,3})\b', upper)]
                if not sp_vals:
                    sp_vals = [f"SP{int(v):03d}" for v in re.findall(r'\bSPS\s*0*(\d{1,3})\b', upper)]
                if not sp_vals:
                    sp_vals = [f"SP{int(v):03d}" for v in re.findall(r'\bREV(?:ISION)?\s*0*(\d{1,3})\b', upper)]

                build_vals = re.findall(r'\b\d{6}\b', upper)
                if not build_vals:
                    rev_build = re.findall(r'\b\d+\.\d+\.\d+\.(\d{1,6})\b', upper)
                    build_vals = [v.zfill(6) for v in rev_build]

                if product and sp_vals and build_vals:
                    for sp in sp_vals:
                        for build in build_vals:
                            triples.append((product, sp, build))

            # De-duplicate while preserving order.
            unique_triples = []
            seen = set()
            for triple in triples:
                if triple not in seen:
                    seen.add(triple)
                    unique_triples.append(triple)

            list_aff = []
            for product, sp, build in unique_triples:
                list_aff.extend([product, sp, build])

            # Fallback parser: some notes render version data outside table rows
            # or in flattened text like "2.00.079.007".
            if not list_aff:
                page_text = val_soup.get_text(' ', strip=True)
                dotted_versions = re.findall(r'\b([12])\.00\.(\d{2,3})\.(\d{1,3})\b', page_text)
                dotted_triples = []
                for major, sp_raw, build_raw in dotted_versions:
                    product = f"SAP HANA DATABASE {major}.0"
                    sp = f"SP{int(sp_raw):03d}"
                    build = f"{int(build_raw):06d}"
                    dotted_triples.append((product, sp, build))

                dedup_dotted = []
                seen_dotted = set()
                for triple in dotted_triples:
                    if triple not in seen_dotted:
                        seen_dotted.add(triple)
                        dedup_dotted.append(triple)

                if dedup_dotted:
                    self.logger.info("Fallback dotted-version parser extracted %d triples", len(dedup_dotted))
                    for product, sp, build in dedup_dotted:
                        list_aff.extend([product, sp, build])

            if not list_aff and affected_rows:
                self.logger.debug("No tokens matched. Sample affected row text: %s", bs(affected_rows[0], 'html.parser').get_text(' ', strip=True))
            self.logger.info("Extracted %d affected-version tokens", len(list_aff))
            self.login_cache[link] = list_aff
            self.logger.debug("Cached affected-version tokens for link: %s", link)
            return list_aff
        except IndexError as Ie:
            self.logger.error("Xpath of Affected version may be wrong: %s", str(Ie))
            return []
        except AttributeError as Ae:
            self.logger.error("Failed to get the affected version: %s", str(Ae))
            return []
        except ConnectionRefusedError as Cr:
            self.logger.error("Connection is refused by the server: %s", str(Cr))
            return []
        except Exception as err:
            self.logger.error("Unexpected error while extracting affected versions from %s: %s", link, str(err))
            return []
        finally:
            if browser:
                try:
                    browser.quit()
                except Exception:
                    pass
