import scrapy
import os
import re
import time
import json
import urllib.request
import urllib.error
import urllib.parse
import xml.etree.ElementTree as ET
import utility
from twisted.internet import threads, defer
from typing import Set, Dict, List, Tuple
from datetime import date
from ..items import DvmautomationItem
from time import gmtime, strftime
from bs4 import BeautifulSoup
from selenium.webdriver import Firefox
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.firefox.options import Options
from selenium.common.exceptions import \
    InvalidSessionIdException, NoSuchElementException, TimeoutException, \
    StaleElementReferenceException


DEFAULT_PAGE_WAIT_TIMEOUT = 30
YEAR_OF_CVE_SELECTION = date.today().year
# ── MSSQL affected_version flow ──────────────────────────────────────────────
#
# Phase 1 — CVE Discovery (always runs)
#   _fetch_sql_server_cves_from_api() calls the MSRC CVRF REST API once per
#   monthly bulletin to get CVRF XML, then parses out all SQL Server CVE URLs
#   for the year. Result: a set of MSRC CVE page URLs.
#
# Phase 2 — Per-CVE Scraping (scrape_affected_versions_vuln, runs for every CVE)
#   USE_CVRF_FOR_AFFECTED_VERSIONS = True  (default):
#     • _fetch_affected_versions_for_cve() queries the MSRC Security Update Guide
#       (SuG) API per-CVE (filter: cveNumber eq '...'). Each row is one affected
#       SQL Server branch, converted into an affected-version range as follows:
#
#       Data sources (links):
#         • SuG API (fix build per CVE) —
#             https://api.msrc.microsoft.com/sug/v2.0/en-US/affectedProduct
#               ?$filter=cveNumber eq '{CVE}'
#         • Build-versions pages (real predecessor build for the range end) —
#             https://learn.microsoft.com/en-us/troubleshoot/sql/releases/
#               sqlserver-{year}/build-versions
#           where {year} ∈ 2016 / 2017 / 2019 / 2022 / 2025 (see
#           _MSSQL_BUILD_LIST_YEAR, _MSSQL_BUILD_LIST_URL).
#         • Selenium fallback (older CVEs still carrying the FAQ table) —
#             https://msrc.microsoft.com/update-guide/vulnerability/{CVE}
#         • Phase 1 CVE discovery (separate) — MSRC CVRF API
#           (base "mssql_api_base" in credentials/urls.json):
#             https://api.msrc.microsoft.com/cvrf/v3.0/updates/{year}   (bulletin index)
#             https://api.msrc.microsoft.com/cvrf/v3.0/cvrf/{YYYY-mmm}  (CVRF XML per bulletin)
#         • Severity + description (unchanged) — NVD page scraped via Selenium.
#
#       Affected-version extraction (per SuG row):
#         1. Year / label — regex "SQL Server (\d{4})" on the product name gives
#            the year → label "MSSQL {year}".
#         2. Fix build — kbArticles[].fixedBuildNumber is the patched build, e.g.
#            "16.0.4275.2"; major = 16, third octet = 4275 (the third octet alone
#            identifies a SQL Server release; minor and revision are ignored).
#         3. start (range lower bound) — highest branch floor <= 4275 from
#            _MSSQL_BRANCH_FLOORS[16] → 4003. The floor also picks the servicing
#            track: low floor = GDR band, high floor = CU band, so no label parsing.
#         4. end (range upper bound) — the real build released immediately before
#            the fix on that same track: highest build in [start, fix) taken from
#            Microsoft's build-versions page (_fetch_build_list) → 4265. NOT
#            fix - 1: MS build gaps are irregular (…4255→4262→4265→4275…), so
#            fix - 1 names a build that never shipped. If the build list can't be
#            fetched, fall back to end = fix - 1 (a safe over-approximation).
#         5. Emit ("MSSQL {year}", "16.0.4003.0 - 16.0.4265.0"); rows are deduped
#            (x86/x64 collapse to one range).
#
#     • If the API returns nothing (CVE absent, network error, or no usable SQL
#       Server row) → Selenium fallback: open the MSRC CVE page in headless Firefox
#       and scrape the affected versions table (//td[2], //td[4]), which still
#       exists on older CVE pages.
#   USE_CVRF_FOR_AFFECTED_VERSIONS = False:
#     • Selenium always, unconditionally (original behaviour).
#   In all cases NVD is always scraped via Selenium for severity + description.
#
USE_CVRF_FOR_AFFECTED_VERSIONS = True

# Lower-bound (start) of each currently-supported SQL Server servicing branch,
# expressed as the THIRD octet of ProductVersion, keyed by internal major version.
# These floors are stable Microsoft branch bases derived from historical affected
# ranges in cve_data.db (GDR occupies a low build band, CU a high band). For a
# given fixedBuildNumber third octet F, the affected range is:
#     start = max(floor for floor in floors if floor <= F)   # selects GDR vs CU
#     end   = highest real released build (third octet) in that band < F
# The build number alone selects the branch, so no branch-label parsing is needed.
_MSSQL_BRANCH_FLOORS = {
    '13': [7000, 6300],   # SQL 2016: SP3 Azure Connect (7000) / SP3 GDR (6300)
    '14': [3006, 1000],   # SQL 2017: CU (3006) / GDR (1000)
    '15': [4003, 2000],   # SQL 2019: CU (4003) / GDR (2000)
    '16': [4003, 1000],   # SQL 2022: CU (4003) / GDR (1000)
    '17': [4006, 1000],   # SQL 2025: CU (4006) / GDR (1000)
}

# Microsoft "build versions" pages list every CU and GDR build ever shipped for a
# major version, in a scrapeable table. The affected range's upper bound must be
# the build released IMMEDIATELY BEFORE the fix on the same branch — and Microsoft
# build gaps are irregular (e.g. 2022 CU: 4255→4262→4265→4275, gaps of 7 and 10),
# so no fixed arithmetic offset is correct. We fetch and parse these pages to learn
# the real predecessor build. Keyed by internal major version → release-year slug.
_MSSQL_BUILD_LIST_YEAR = {
    '13': '2016', '14': '2017', '15': '2019', '16': '2022', '17': '2025',
}
_MSSQL_BUILD_LIST_URL = (
    "https://learn.microsoft.com/en-us/troubleshoot/sql/releases/"
    "sqlserver-{year}/build-versions")


class CrawlMsSqlDb(scrapy.Spider):

    custom_settings = {
        'LOG_FILE': 'Crawler.log',
        'LOG_LEVEL': 'INFO',
        'DOWNLOAD_TIMEOUT': 30
    }

    name = 'mssqldb'

    # Configurable limit for number of most recent CVEs to fetch
    max_cves = 100

    @staticmethod
    def extract_cve_no_from_url(cve_url: str) -> str:
        return (cve_url or '').split('/')[-1].upper()

    @classmethod
    def extract_cve_year_from_url(cls, cve_url: str):
        cve_no = cls.extract_cve_no_from_url(cve_url)
        match = re.search(r'^CVE-(\d{4})-\d+$', cve_no, re.IGNORECASE)
        return int(match.group(1)) if match else None

    @classmethod
    def cve_sort_key(cls, cve_url: str):
        cve_no = cls.extract_cve_no_from_url(cve_url)
        match = re.search(r'^CVE-(\d{4})-(\d+)$', cve_no, re.IGNORECASE)
        if not match:
            return 0, 0
        return int(match.group(1)), int(match.group(2))

    async def start(self):
        for request in self.start_requests():
            yield request

    def start_requests(self):
        mssql_vuln = utility.get_feed_urls('mssql_vuln')
        self.logger.info('Starting MSSQL vulnerability crawl: %s', mssql_vuln)
        yield scrapy.Request(url=mssql_vuln, callback=self.parse)

    def __del__(self):
        try:
            if self._browser is not None:
                self._browser.quit()
        except Exception:
            pass

    def __init__(self):
        super().__init__()
        self._browser = None  # initialized lazily on first use
        # major version -> sorted list of third octets of every released build,
        # fetched once per major from the MS build-versions page (memoized).
        self._build_list_cache: Dict[str, List[int]] = {}

    @property
    def browser(self) -> Firefox:
        """Return the shared Firefox instance, creating it on first access."""
        if self._browser is None:
            from selenium.webdriver.firefox.service import Service
            self.logger.info('Initializing headless Firefox browser for MSSQL crawler')
            opts = Options()
            opts.add_argument('--headless')
            gd_path = os.path.join(
                os.path.dirname(__file__), '..', '..', 'geckodriver.exe')
            gd_log = os.path.join(
                os.path.dirname(__file__), '..', '..', 'geckodriver.log')
            service = Service(executable_path=os.path.normpath(gd_path),
                              log_output=os.path.normpath(gd_log))
            self._browser = Firefox(service=service, options=opts)
            self.logger.info('Headless Firefox browser ready')
        return self._browser

    @defer.inlineCallbacks
    def parse(self, response, **_):
        # Selenium work runs in a thread pool so it does not block the asyncio reactor.
        cves = yield threads.deferToThread(self.scrape_unique_cves, response.url)
        cves_for_selected_year = [
            cve for cve in cves
            if self.extract_cve_year_from_url(cve) == YEAR_OF_CVE_SELECTION
        ]
        cves_list = cves_for_selected_year[:self.max_cves]
        print(f"MSSQL unique CVEs found for selected year {YEAR_OF_CVE_SELECTION}: "
              f"{[c.split('/')[-1] for c in cves_for_selected_year]} (limit: {self.max_cves})")
        self.logger.info(
            f"MSSQL unique CVEs found for selected year {YEAR_OF_CVE_SELECTION}: "
            f"{[c.split('/')[-1] for c in cves_for_selected_year]} (limit: {self.max_cves})")

        if not cves_list:
            self.logger.warning(
                f"No CVEs found for year {YEAR_OF_CVE_SELECTION} after applying strict year filter")

        # Collect all items in a list; @inlineCallbacks uses yield only for Deferreds,
        # not to stream Scrapy items — return the full list so the engine processes them.
        items = []
        for cve in cves_list:
            item = yield threads.deferToThread(self.scrape_affected_versions_vuln, cve)
            self.logger.info("Checks\n" + str(item))
            if not item["affected_version"]:
                print(f"MSSQL affected version not found, eliminating {cve.split('/')[-1]}")
                self.logger.info(f"MSSQL affected version not found, eliminating {cve.split('/')[-1]}")
            else:
                items.append(item)
        defer.returnValue(items)

    def scrape_unique_cves(self, url: str) -> Set:
        """
        Fetch SQL Server CVEs for the current year.

        Primary path: MSRC CVRF REST API — deterministic, no browser required,
        immune to SPA timing issues.  Falls back to the hardened Selenium UI
        path only if the API raises an exception.
        """
        try:
            cve_ids = self._fetch_sql_server_cves_from_api()
            self.logger.info(
                "MSRC API: %d SQL Server CVEs found for %d",
                len(cve_ids), YEAR_OF_CVE_SELECTION)
            print(f"Total mssql cves found for year {YEAR_OF_CVE_SELECTION} = {len(cve_ids)}")
            self.logger.info(
                "Total mssql cves found for year %d = %d",
                YEAR_OF_CVE_SELECTION, len(cve_ids))
            if not USE_CVRF_FOR_AFFECTED_VERSIONS:
                # Pre-warm the browser by loading the MSRC main page so the SPA JS bundle
                # is cached before the first CVE page request. Without this, the first 1-2
                # CVEs hit a cold browser (no cached bundle), load the full 500 KB+ SPA JS
                # in headless mode, and routinely time out before //td[2] appears in the DOM.
                # The Selenium fallback path already does this implicitly via browser.get(url);
                # the API path skips it, leaving the browser cold.
                # When USE_CVRF_FOR_AFFECTED_VERSIONS=True, MSRC CVE pages are not visited,
                # so this warm-up is unnecessary (NVD pages are much lighter to load cold).
                self.logger.info("MSRC API path: pre-warming browser with MSRC main page")
                try:
                    self.browser.get(url)
                    WebDriverWait(self.browser, 30).until(
                        lambda d: d.execute_script("return document.readyState") == "complete"
                    )
                    self.logger.info("Browser warm-up complete — SPA bundle cached for CVE scraping")
                except Exception as warmup_err:
                    self.logger.warning(
                        "Browser warm-up failed (%s) — proceeding anyway; first CVE(s) may be slow",
                        warmup_err)
            return cve_ids
        except Exception as api_err:
            self.logger.warning(
                "MSRC API approach failed (%s); falling back to Selenium UI scraping",
                api_err)

        # --- Selenium fallback ---
        try:
            self.browser.get(url)
            WebDriverWait(self.browser, 20).until(
                lambda d: d.execute_script("return document.readyState") == "complete"
            )
            self.logger.info("MSRC page loaded (Selenium fallback path)")
        except TimeoutException as e:
            self.logger.error("MSSQL Vuln timeout loading MSRC page: %s", e)
        except (NoSuchElementException, InvalidSessionIdException) as e:
            self.logger.error("MSSQL Vuln error loading MSRC page: %s", e)

        total_cves_found = set()
        try:
            total_cves_found = self.filter_mssql_vulns_table()
        except Exception as e:
            self.logger.error("Exception in filtering MSSQL vulnerability tables: %s", e)

        print(f"Total mssql cves found for year {YEAR_OF_CVE_SELECTION} = {len(total_cves_found)}")
        self.logger.info(
            "Total mssql cves found for year %d = %d",
            YEAR_OF_CVE_SELECTION, len(total_cves_found))
        return total_cves_found

    # ──────────────────────────────────────────────────────────────────────────
    # MSRC CVRF API helpers
    # ──────────────────────────────────────────────────────────────────────────

    def _fetch_sql_server_cves_from_api(self) -> Set[str]:
        """
        Query the public MSRC CVRF REST API to retrieve all SQL Server CVEs for
        the current year without any browser interaction.

        Algorithm:
          1. GET /updates/{year}  → JSON list of monthly security bulletins
          2. For each bulletin, GET its CvrfUrl → CVRF XML document
          3. Parse the XML to find ProductIDs whose name contains "SQL Server"
          4. Collect CVE IDs whose ProductStatuses include a SQL Server product
          5. Return MSRC vulnerability detail URLs for those CVEs

        Raises on any network or parse failure so the caller can trigger the
        Selenium fallback.  Per-month fetch errors are logged and skipped so a
        single bad month does not abort the whole year.
        """
        year = YEAR_OF_CVE_SELECTION
        msrc_api_base = utility.get_feed_urls('mssql_api_base')

        # Step 1: monthly bulletin index
        updates_url = f"{msrc_api_base}/updates/{year}"
        self.logger.info("MSRC API: fetching bulletin list — %s", updates_url)
        req = urllib.request.Request(
            updates_url,
            headers={"Accept": "application/json", "User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            bulletins = json.loads(resp.read().decode("utf-8")).get("value", [])
        self.logger.info(
            "MSRC API: %d bulletin(s) for %d — %s",
            len(bulletins), year, [b["ID"] for b in bulletins])

        cve_urls: Set[str] = set()

        # Step 2-4: per-bulletin CVRF fetch + parse
        # Process most-recent month first so the limit is filled from the latest
        # patch Tuesdays before falling back to older months.
        for bulletin in reversed(bulletins):
            if len(cve_urls) >= self.max_cves:
                break
            bid = bulletin["ID"]
            cvrf_url = bulletin.get("CvrfUrl", f"{msrc_api_base}/cvrf/{bid}")
            self.logger.info("MSRC API: fetching CVRF for %s", bid)
            try:
                req = urllib.request.Request(
                    cvrf_url,
                    headers={"Accept": "application/xml", "User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=90) as resp:
                    xml_bytes = resp.read()
            except urllib.error.URLError as e:
                self.logger.error(
                    "MSRC API: network error fetching CVRF for %s: %s — skipping", bid, e)
                continue

            try:
                month_cves = self._parse_cvrf_for_sql_server(xml_bytes)
            except Exception as e:
                self.logger.error(
                    "MSRC API: parse error for %s: %s — skipping", bid, e)
                continue

            if month_cves:
                self.logger.info("MSRC API: %s → %d SQL Server CVE(s)", bid, len(month_cves))
            cve_urls.update(month_cves)

        # Affected version ranges are fetched per-CVE in Phase 2
        # (scrape_affected_versions_vuln → _fetch_affected_versions_for_cve),
        # which is immune to the SuG API's year-wide pagination limits.
        return cve_urls

    @staticmethod
    def _parse_cvrf_for_sql_server(xml_bytes: bytes) -> Set[str]:
        """
        Parse a CVRF XML document and return MSRC URLs for every CVE that has
        at least one SQL Server product listed under its ProductStatuses.

        Uses local-name tag matching (strips namespace prefix) so the parser is
        namespace-agnostic and tolerates both CVRF 1.1 and any future Microsoft
        namespace variants.
        """
        def local(tag: str) -> str:
            return tag.split("}")[-1] if "}" in tag else tag

        root = ET.fromstring(xml_bytes)

        # Collect ProductIDs whose FullProductName text contains "SQL Server"
        sql_ids: Set[str] = set()
        for elem in root.iter():
            if local(elem.tag) == "FullProductName" and "SQL Server" in (elem.text or ""):
                pid = elem.get("ProductID")
                if pid:
                    sql_ids.add(pid)

        if not sql_ids:
            return set()

        cve_urls: Set[str] = set()
        for vuln in root.iter():
            if local(vuln.tag) != "Vulnerability":
                continue

            cve_id: str = ""
            affected_sql: bool = False

            for child in vuln:
                cl = local(child.tag)
                if cl == "CVE":
                    cve_id = (child.text or "").strip()
                elif cl == "ProductStatuses":
                    # Each Status child contains ProductID children
                    for status in child:
                        for pid_el in status:
                            if (local(pid_el.tag) == "ProductID"
                                    and (pid_el.text or "").strip() in sql_ids):
                                affected_sql = True

            if cve_id and affected_sql:
                cve_urls.add(
                    f"https://msrc.microsoft.com/update-guide/vulnerability/{cve_id}")

        return cve_urls

    @staticmethod
    def _fixed_build_from_row(item: Dict) -> str:
        """
        Extract the patched build (fixedBuildNumber, e.g. "16.0.4262.2") from a
        SuG affectedProduct row. MSRC nests it under kbArticles; return the first
        non-empty value found, or "" if the row carries no fixed build.
        """
        for kb in (item.get("kbArticles") or []):
            fbn = (kb.get("fixedBuildNumber") or "").strip()
            if fbn:
                return fbn
        return ""

    def _fetch_build_list(self, major: str) -> List[int]:
        """
        Fetch and parse the Microsoft build-versions page for a major version,
        returning the sorted list of THIRD octets of every CU/GDR build ever
        released for it (e.g. [1000, 1050, ..., 4265, 4275, 4295] for 2022).

        Memoized per major: the page is fetched at most once per crawl run. On any
        fetch/parse failure an empty list is cached, and the caller falls back to
        the (arithmetically safe) end = fixed - 1 rule.
        """
        if major in self._build_list_cache:
            return self._build_list_cache[major]

        octets: List[int] = []
        year = _MSSQL_BUILD_LIST_YEAR.get(major)
        if year:
            url = _MSSQL_BUILD_LIST_URL.format(year=year)
            headers = {"Accept": "text/html", "User-Agent": "Mozilla/5.0"}
            try:
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=30) as resp:
                    html = resp.read().decode("utf-8", "replace")
                # Every engine build appears as "<major>.0.<third>.<n>" in the tables.
                # This also matches the Analysis Services build column (e.g.
                # "16.0.43.252"), but those third octets are always < 1000 while every
                # real engine build (and every branch floor) is >= 1000, so the
                # `start <= b` filter in _build_range_from_fixed_build discards them.
                found = re.findall(rf"\b{re.escape(major)}\.0\.(\d+)\.\d+\b", html)
                octets = sorted({int(t) for t in found})
                self.logger.info(
                    "Build list: %d build(s) parsed for SQL %s from %s",
                    len(octets), year, url)
            except Exception as e:
                self.logger.warning(
                    "Build list: fetch/parse failed for SQL %s (%s) — "
                    "falling back to fixed-1 end rule", year, e)
                octets = []

        self._build_list_cache[major] = octets
        return octets

    def _build_range_from_fixed_build(self, fixed_build: str):
        """
        Convert a patched build (e.g. "16.0.4275.2") into an affected-version
        range string using the per-branch base-build floor table for the start and
        the real released-build list for the end.

            major = "16", third octet = 4275
            start = max floor <= 4275 from _MSSQL_BRANCH_FLOORS["16"]       → 4003
            end   = highest real build in [start, 4275) from the build list → 4265
            result = "16.0.4003.0 - 16.0.4265.0"

        The end is the build released IMMEDIATELY BEFORE the fix on the same branch
        (>= start, so GDR and CU bands never cross). It is NOT fixed - 1: MS build
        gaps are irregular, so fixed - 1 names a build that never shipped. When the
        build list is unavailable (fetch failed) we fall back to end = fixed - 1,
        which is arithmetically safe (over-approximates the last vulnerable build).

        Returns "" when the build cannot be parsed, the major version is unknown,
        the third octet falls below every supported branch floor (unsupported
        branch — MSRC does not list these), or the fix is the branch baseline
        itself (nothing below it is vulnerable in-band). No check should be
        generated in any of these cases.
        """
        m = re.match(r"^(\d+)\.\d+\.(\d+)\.\d+$", fixed_build.strip())
        if not m:
            return ""
        major, third = m.group(1), int(m.group(2))
        floors = _MSSQL_BRANCH_FLOORS.get(major)
        if not floors:
            return ""
        candidates = [f for f in floors if f <= third]
        if not candidates:
            return ""
        start = max(candidates)
        # Prefer the real predecessor build (in-band, below the fix); fall back to
        # fixed - 1 only when the build list could not be fetched/parsed.
        build_list = self._fetch_build_list(major)
        prior = [b for b in build_list if start <= b < third]
        end = max(prior) if prior else third - 1
        if end < start:
            return ""
        return f"{major}.0.{start}.0 - {major}.0.{end}.0"
    
    def _fetch_affected_versions_for_cve(self, cve_no: str):
        """
        Query the MSRC Security Update Guide (SuG) API for a single CVE and build
        the list of affected SQL Server version ranges.

        The per-CVE filter (cveNumber eq '...') returns every affected product for
        the CVE in one page (no pagination), unlike the year-wide releaseDate query
        which is truncated to 50 rows. For each SQL Server row the patched build
        (kbArticles[].fixedBuildNumber) is turned into an affected range via the
        per-branch base-build floor table.

        Returns: [(mssql_str, version_range), ...], deduped; empty list on error or
        when no usable SQL Server row is found (caller then falls back to Selenium).
        """
        sug_base   = "https://api.msrc.microsoft.com/sug/v2.0/en-US"
        filter_val = f"cveNumber eq '{cve_no}'"
        url = (f"{sug_base}/affectedProduct"
               f"?$filter={urllib.parse.quote(filter_val)}")
        self.logger.info("SuG API: fetching affected products for %s — %s", cve_no, url)

        headers = {"Accept": "application/json", "User-Agent": "Mozilla/5.0"}
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except Exception as e:
            self.logger.warning(
                "SuG API: fetch failed for %s: %s — falling back to Selenium", cve_no, e)
            return []

        result: List[Tuple[str, str]] = []
        seen: Set[Tuple[str, str]] = set()
        for item in data.get("value", []):
            # SuG rows carry the human-readable name in `product` (e.g.
            # "Microsoft SQL Server 2017 for x64-based Systems (GDR)"); `productName`
            # is usually null. `productFamily` == "SQL Server" is the reliable filter.
            pname = item.get("product") or item.get("productName") or ""
            if item.get("productFamily") != "SQL Server" and "SQL Server" not in pname:
                continue
            year_match = re.search(r"SQL Server (\d{4})", pname)
            if not year_match:
                continue
            fixed_build = self._fixed_build_from_row(item)
            if not fixed_build:
                continue
            version_range = self._build_range_from_fixed_build(fixed_build)
            if not version_range:
                continue
            entry = (f"MSSQL {year_match.group(1)}", version_range)
            if entry not in seen:
                seen.add(entry)
                result.append(entry)

        self.logger.info(
            "SuG API: %d affected version entrie(s) for %s", len(result), cve_no)
        return result

    # ──────────────────────────────────────────────────────────────────────────
    # Selenium fallback helpers
    # ──────────────────────────────────────────────────────────────────────────

    def _click_with_retry(self, xpath: str, label: str,
                          max_attempts: int = 3, delay: float = 0.8) -> None:
        """
        Click an element, re-finding it on each attempt via WebDriverWait so
        that SPA re-renders between attempts do not cause permanent stale-element
        failures.  Uses a JS click to bypass elements hidden by animation.
        """
        for attempt in range(max_attempts):
            try:
                el = WebDriverWait(self.browser, 10).until(
                    ec.element_to_be_clickable((By.XPATH, xpath))
                )
                self.browser.execute_script("arguments[0].click();", el)
                return
            except StaleElementReferenceException:
                self.logger.warning(
                    "%s: stale element on attempt %d/%d", label, attempt + 1, max_attempts)
                if attempt == max_attempts - 1:
                    raise
                time.sleep(delay)

    def filter_mssql_vulns_table(self) -> Set[str]:
        """
        Apply Product Family → SQL Server, date-range, and keyword filters on
        the MSRC SPA, then scroll the result list collecting all CVE URLs.

        Invoked only when the CVRF API fallback path is active.  Every major
        filter interaction is followed by a settle sleep to let the React SPA
        finish re-rendering before the next DOM lookup, preventing stale-element
        and zero-results race conditions.
        """
        mssql_vuln_prod_family_btn_xpath           = utility.get_xpath("mssql_vuln_prod_family_btn_xpath")
        mssql_vuln_prod_family_SQL_Server_xpath     = utility.get_xpath("mssql_vuln_prod_family_SQL_Server_value_xpath")
        mssql_vuln_MSSQL_Server_keyword_input_xpath = utility.get_xpath("mssql_vuln_MSSQL_Server_keyword_input_xpath")
        mssql_vuln_calendar_btn_xpath              = utility.get_xpath("mssql_vuln_calendar_btn_xpath")
        mssql_vuln_start_date_input_xpath          = utility.get_xpath("mssql_vuln_start_date_input_xpath")
        mssql_vuln_end_date_input_xpath            = utility.get_xpath("mssql_vuln_end_date_input_xpath")
        mssql_vuln_vulnerabilities_btn_xpath       = utility.get_xpath("mssql_vuln_vulnerabilities_btn_xpath")
        mssql_vuln_calendar_ok_btn_xpath           = utility.get_xpath("mssql_vuln_calendar_ok_btn_xpath")
        mssql_vuln_cve_scrollable_element_xpath    = utility.get_xpath("mssql_vuln_cve_scrollable_element_xpath")
        mssql_vuln_table_row_count_xpath           = utility.get_xpath("mssql_vuln_table_row_count")
        mssql_vuln_cve_text_xpath                  = utility.get_xpath("mssql_vuln_cve_text_xpath")

        # ── Wait for the SPA's initial data load ──────────────────────────────
        # document.readyState completes when scripts finish downloading — not
        # when React finishes its first API call and renders CVE rows.  Waiting
        # for actual CVE links to appear guarantees the DOM is fully settled
        # before we touch any filter control.
        self.logger.info("MSSQL filter: waiting for initial CVE data to load")
        try:
            WebDriverWait(self.browser, 45).until(
                ec.presence_of_element_located((By.XPATH, mssql_vuln_cve_text_xpath))
            )
            self.logger.info("MSSQL filter: initial CVE data visible — DOM is stable")
            time.sleep(1)  # let trailing animations settle before touching controls
        except TimeoutException:
            self.logger.warning(
                "MSSQL filter: initial CVE links did not appear in 45 s; proceeding anyway")

        # ── Product Family toolbar button ─────────────────────────────────────
        utility.wait_until_page_reloads(
            DEFAULT_PAGE_WAIT_TIMEOUT, self.browser,
            mssql_vuln_prod_family_btn_xpath, By.XPATH)

        # ── Product Family → SQL Server ───────────────────────────────────────
        self.logger.info("MSSQL filter: clicking Product Family button")
        self._click_with_retry(mssql_vuln_prod_family_btn_xpath, "Product Family btn")

        for attempt in range(3):
            try:
                self.logger.info(
                    "MSSQL filter: selecting SQL Server option (attempt %d)", attempt + 1)
                sql_el = WebDriverWait(self.browser, 10).until(
                    ec.element_to_be_clickable(
                        (By.XPATH, mssql_vuln_prod_family_SQL_Server_xpath))
                )
                self.browser.execute_script("arguments[0].click();", sql_el)
                self.logger.info("MSSQL filter: SQL Server selected")
                break
            except StaleElementReferenceException:
                self.logger.warning(
                    "MSSQL filter: SQL Server option stale on attempt %d", attempt + 1)
                if attempt == 2:
                    raise
                time.sleep(0.5)

        # ── Vulnerabilities tab ───────────────────────────────────────────────
        # Clicking the tab triggers a full toolbar re-render.  Without a settle
        # delay the calendar button lookup races against the in-progress render
        # and the element reference goes stale immediately after .click().
        self.logger.info("MSSQL filter: clicking Vulnerabilities tab")
        WebDriverWait(self.browser, 10).until(
            ec.element_to_be_clickable((By.XPATH, mssql_vuln_vulnerabilities_btn_xpath))
        ).click()
        self.logger.info(
            "MSSQL filter: Vulnerabilities tab clicked — waiting for toolbar to settle")
        time.sleep(2)

        # ── Date range: open calendar ─────────────────────────────────────────
        self.logger.info("MSSQL filter: opening date range calendar")
        self._click_with_retry(mssql_vuln_calendar_btn_xpath, "Calendar btn")

        # ── Start date ────────────────────────────────────────────────────────
        start_date = f"Jan 1, {YEAR_OF_CVE_SELECTION}"
        self.logger.info("MSSQL filter: setting start date to %s", start_date)
        WebDriverWait(self.browser, 15).until(
            ec.element_to_be_clickable((By.XPATH, mssql_vuln_start_date_input_xpath))
        ).click()
        WebDriverWait(self.browser, 15).until(
            ec.element_to_be_clickable((By.XPATH, mssql_vuln_start_date_input_xpath))
        ).clear()
        time.sleep(2)
        WebDriverWait(self.browser, 15).until(
            ec.element_to_be_clickable((By.XPATH, mssql_vuln_start_date_input_xpath))
        ).send_keys(start_date)

        # ── End date ──────────────────────────────────────────────────────────
        end_date = f"Dec 31, {YEAR_OF_CVE_SELECTION}"
        self.logger.info("MSSQL filter: setting end date to %s", end_date)
        WebDriverWait(self.browser, 15).until(
            ec.element_to_be_clickable((By.XPATH, mssql_vuln_end_date_input_xpath))
        ).click()
        WebDriverWait(self.browser, 15).until(
            ec.element_to_be_clickable((By.XPATH, mssql_vuln_end_date_input_xpath))
        ).clear()
        time.sleep(2)
        WebDriverWait(self.browser, 15).until(
            ec.element_to_be_clickable((By.XPATH, mssql_vuln_end_date_input_xpath))
        ).send_keys(end_date)
        self.logger.info(
            "MSSQL filter: date range set — start=%s end=%s", start_date, end_date)

        # ── Calendar OK ───────────────────────────────────────────────────────
        self.logger.info("MSSQL filter: clicking calendar OK")
        self._click_with_retry(mssql_vuln_calendar_ok_btn_xpath, "Calendar OK btn")
        self.logger.info(
            "MSSQL filter: calendar OK clicked — waiting for table to start re-rendering")
        time.sleep(2)

        # ── Keyword: SQL Server ───────────────────────────────────────────────
        # Re-find the element for click, send_keys, AND Keys.ENTER separately.
        # The SPA may re-render the toolbar between each interaction; reusing a
        # stored WebElement reference across two send_keys calls risks a stale-
        # element exception on the second call.
        self.logger.info("MSSQL filter: entering keyword 'SQL Server'")
        WebDriverWait(self.browser, 10).until(
            ec.element_to_be_clickable((By.XPATH, mssql_vuln_MSSQL_Server_keyword_input_xpath))
        ).click()
        WebDriverWait(self.browser, 10).until(
            ec.element_to_be_clickable((By.XPATH, mssql_vuln_MSSQL_Server_keyword_input_xpath))
        ).send_keys("SQL Server")
        WebDriverWait(self.browser, 10).until(
            ec.element_to_be_clickable((By.XPATH, mssql_vuln_MSSQL_Server_keyword_input_xpath))
        ).send_keys(Keys.ENTER)
        self.logger.info(
            "MSSQL filter: keyword submitted — waiting for table to settle")
        time.sleep(2)

        # ── Reapply date range after keyword (SPA resets it on keyword submit) ──
        # Must re-enter start/end dates — clicking OK on the reset picker would
        # confirm the SPA's default (current month only) instead of Jan–Dec.
        self.logger.info("MSSQL filter: reapplying calendar filter after keyword submit")
        self._click_with_retry(mssql_vuln_calendar_btn_xpath, "Calendar btn (reapply)")
        WebDriverWait(self.browser, 15).until(
            ec.element_to_be_clickable((By.XPATH, mssql_vuln_start_date_input_xpath))
        ).click()
        WebDriverWait(self.browser, 15).until(
            ec.element_to_be_clickable((By.XPATH, mssql_vuln_start_date_input_xpath))
        ).clear()
        time.sleep(2)
        WebDriverWait(self.browser, 15).until(
            ec.element_to_be_clickable((By.XPATH, mssql_vuln_start_date_input_xpath))
        ).send_keys(start_date)
        WebDriverWait(self.browser, 15).until(
            ec.element_to_be_clickable((By.XPATH, mssql_vuln_end_date_input_xpath))
        ).click()
        WebDriverWait(self.browser, 15).until(
            ec.element_to_be_clickable((By.XPATH, mssql_vuln_end_date_input_xpath))
        ).clear()
        time.sleep(2)
        WebDriverWait(self.browser, 15).until(
            ec.element_to_be_clickable((By.XPATH, mssql_vuln_end_date_input_xpath))
        ).send_keys(end_date)
        self._click_with_retry(mssql_vuln_calendar_ok_btn_xpath, "Calendar OK btn (reapply)")
        self.logger.info("MSSQL filter: all filters applied (date range %s to %s)", start_date, end_date)

        # ── Wait for all rows to finish loading ───────────────────────────────
        try:
            row_count_el = WebDriverWait(self.browser, 30).until(
                ec.presence_of_element_located((By.XPATH, mssql_vuln_table_row_count_xpath))
            )
            self.logger.info("MSRC table ready: %s", row_count_el.text)
        except TimeoutException:
            self.logger.warning(
                "Timed out waiting for 'Loaded all rows' indicator — proceeding anyway")

        # ── Scroll-and-collect loop ───────────────────────────────────────────
        # Re-find the scrollable container on every iteration: the SPA may have
        # replaced the DOM node during a re-render triggered by a filter change.
        total_cves: Set[str] = set()
        previous_scroll_height = None
        self.logger.info("MSSQL filter: starting scroll loop to collect CVE links")
        while True:
            total_cves.update(self.fetch_cves())
            self.logger.debug("MSSQL scroll: %d unique CVEs so far", len(total_cves))
            try:
                scrollable = WebDriverWait(self.browser, 10).until(
                    ec.presence_of_element_located(
                        (By.XPATH, mssql_vuln_cve_scrollable_element_xpath))
                )
                self.browser.execute_script(
                    "arguments[0].scrollTop += 1000;", scrollable)
                time.sleep(1)
                new_scroll_height = self.browser.execute_script(
                    "return arguments[0].scrollHeight;", scrollable)
            except StaleElementReferenceException:
                self.logger.warning(
                    "MSSQL scroll: scrollable element stale — stopping scroll")
                break
            except TimeoutException:
                self.logger.warning(
                    "MSSQL scroll: scrollable element not found — stopping scroll")
                break
            if new_scroll_height == previous_scroll_height:
                break
            previous_scroll_height = new_scroll_height

        # Final collect after reaching the bottom
        total_cves.update(self.fetch_cves())
        print("Reached the bottom of the mssql vuln scrollable table.")
        self.logger.info(
            "MSSQL scroll: finished — %d total unique CVEs collected", len(total_cves))
        return total_cves

    def fetch_cves(self):
        mssql_vuln_cve_text_xpath = utility.get_xpath("mssql_vuln_cve_text_xpath")
        # Wait for at least one CVE link to appear
        try:
            WebDriverWait(self.browser, DEFAULT_PAGE_WAIT_TIMEOUT).until(
                ec.presence_of_all_elements_located((By.XPATH, mssql_vuln_cve_text_xpath))
            )
        except TimeoutException:
            self.logger.warning("fetch_cves: timed out waiting for CVE links — returning empty set")
            return set()
        cve_elements = self.browser.find_elements(By.XPATH, mssql_vuln_cve_text_xpath)
        cves = set()
        for cve in cve_elements:
            try:
                href = cve.get_attribute("href")
                if href:
                    cves.add(href)
            except StaleElementReferenceException:
                pass  # element re-rendered mid-iteration; skip and continue
        self.logger.debug('fetch_cves: found %d CVE link(s) in current page state', len(cves))
        return cves

    def scrape_affected_versions_vuln(self, cve_url: str) -> DvmautomationItem:
        """
        Phase 2 — per-CVE scraping. Build a DvmautomationItem for one MSRC CVE URL.

        Affected versions come from the MSRC SuG API, queried per-CVE
        (_fetch_affected_versions_for_cve), when USE_CVRF_FOR_AFFECTED_VERSIONS is
        True. If the API returns nothing (CVE absent, network error, or no usable
        SQL Server row) it falls back to Selenium: opens the MSRC CVE page in
        headless Firefox and scrapes the affected versions table (//td[2], //td[4]),
        which still exists on older CVE pages.

        NVD is always scraped via Selenium for severity and long_description.
        """
        cve_no = cve_url.split('/')[-1]
        self.logger.info(f"Scraping data for MSSQL CVE: {cve_no}")

        versions: List = []
        builds: List = []

        if USE_CVRF_FOR_AFFECTED_VERSIONS:
            sug_entries = self._fetch_affected_versions_for_cve(cve_no)
            if sug_entries:
                versions, builds = map(list, zip(*sug_entries))
            else:
                self.logger.warning(
                    "SuG API data absent for %s — falling back to Selenium MSRC page scraping",
                    cve_no)
                versions, builds = self._scrape_affected_versions_from_msrc_page(cve_url, cve_no)
        else:
            versions, builds = self._scrape_affected_versions_from_msrc_page(cve_url, cve_no)

        nvd_url = f"{utility.get_feed_urls('nvd_uri')}{cve_no}"
        mitre_url = f"{utility.get_feed_urls('mitre_url_base')}{cve_no}"
        nvd_data = {"long_description": "", "severity": "Unknown"}
        try:
            nvd_data = self.scrape_cve_data_from_nvd(nvd_url)
        except Exception as e:
            self.logger.error(f"Exception in scraping cve data from nvd url: {str(e)}")

        item = DvmautomationItem()
        builds = [b.replace('–', '-').replace('—', '-') for b in builds]
        item['name'] = self.name
        item["cve_no"] = cve_no
        item["link"] = mitre_url
        item["affected_version"] = list(zip(versions, builds))
        item['timestamp'] = strftime("%Y-%m-%d %H:%M:%S", gmtime())
        item['security_fixes'] = 'Vulnerability'
        item['long_description'] = nvd_data["long_description"]
        item['severity'] = self.base_score_calculator(nvd_data["severity"])
        return item

    def _scrape_affected_versions_from_msrc_page(
            self, cve_url: str, cve_no: str) -> Tuple[List, List]:
        """
        Original Selenium path: navigate to the MSRC CVE detail page and extract
        affected SQL Server versions and build ranges from //td[2] and //td[4].

        Retries once on first-load failure: Firefox's JS watchdog can kill the
        MSRC SPA table renderer in headless mode, leaving //td[2] absent. A reload
        resets the JS execution context and succeeds on the second attempt in most
        observed cases. Note: some CVE pages (e.g. CVE-2026-20803) render affected
        products using Fluent UI grid divs instead of <table>/<td> — //td[2] is
        permanently absent for those pages regardless of retry count.
        """
        mssql_vuln_affected_db_name_in_table_xpath = utility.get_xpath(
            "mssql_vuln_affected_db_name_in_table_xpath")
        mssql_vuln_affected_db_builds_in_table_xpath = utility.get_xpath(
            "mssql_vuln_affected_db_builds_in_table_xpath")

        self.browser.get(cve_url)
        found = utility.wait_until_page_reloads(
            DEFAULT_PAGE_WAIT_TIMEOUT, self.browser,
            mssql_vuln_affected_db_name_in_table_xpath, By.XPATH)
        if not found:
            self.logger.warning(
                f"Affected versions table not found for {cve_no} on first load; "
                f"reloading page and retrying")
            self.browser.get(cve_url)
            found = utility.wait_until_page_reloads(
                DEFAULT_PAGE_WAIT_TIMEOUT, self.browser,
                mssql_vuln_affected_db_name_in_table_xpath, By.XPATH)

        if not found:
            self.logger.info(
                f"Affected versions info not extracted for msrc.microsoft CVE: {cve_no}")
            return [], []

        self.logger.info(f"Scraping affected versions data from table for MSSQL CVE: {cve_no}")
        versions_els = self.browser.find_elements(
            By.XPATH, mssql_vuln_affected_db_name_in_table_xpath)
        versions = self.__parse_versions(versions_els)
        builds_els = self.browser.find_elements(
            By.XPATH, mssql_vuln_affected_db_builds_in_table_xpath)
        # TODO: td[4] ("Apply if current product version is...") has two formats:
        #   Format A — numeric version range, e.g. "17.0.4006.2 - 17.0.4035.5" (handled by DVMCheckGenerator)
        #   Format B — KB article reference, e.g. "KB5075211 - Previous SQL2025 RTM CU2" (NOT handled;
        #              DVMCheckGenerator silently skips these tuples and returns None — no check is generated).
        #   To fix Format B: also store td[3] (fixedBuildNumber) so DVMCheckGenerator can derive
        #   the numeric range from it when td[4] is a KB-style string.
        builds = [(el.get_attribute('textContent') or el.text).strip().replace('\xa0', ' ')
                  for el in builds_els]
        return versions, builds

    @staticmethod
    def __parse_versions(versions: List) -> List:
        """
        Parse MSSQL Server alias names to a simple MSSQL year version.
        e.g. MSSQL 2019
        :param versions: the list of strings to parse
        :return: the list of parsed MSSQL versions
        """
        output = list()
        versions = [(v.get_attribute('textContent') or v.text).strip().replace("SQL Server", "MSSQL") for v in versions]
        for version in versions:
            v = re.search(r"(MSSQL|SQL Server) \d{4}", version)
            if v:
                version = v.group(0)  # If match found, replace version with the matched substring.
            output.append(version)
        return output

    def scrape_cve_data_from_nvd(self, url: str) -> Dict:
        """
        Scrape the severity and the description for the passed CVE from NVD
        :param url: the NVD URL for the CVE number
        :return: a dictionary containing the severity and long description
        """
        severity_xpath = utility.get_xpath("mssql_vuln_nvd_cna_severity_xpath")
        severity_element = None
        try:
            self.browser.get(f"{url}")
            severity_element = WebDriverWait(self.browser, DEFAULT_PAGE_WAIT_TIMEOUT).until(
                ec.presence_of_element_located((By.XPATH, severity_xpath)))
        except (TimeoutException, NoSuchElementException) as e:
            self.logger.error(f"Severity element with cna not found after waiting : {str(e)}")
            try:
                severity_xpath = utility.get_xpath("mssql_vuln_nvd_nist_severity_xpath")
                severity_element = WebDriverWait(self.browser, DEFAULT_PAGE_WAIT_TIMEOUT).until(
                    ec.presence_of_element_located((By.XPATH, severity_xpath)))
            except (TimeoutException, NoSuchElementException) as nse:
                self.logger.error(f"Severity element with nist not found, may have an incorrect xpath : {str(nse)}")
                try:
                    severity_xpath = utility.get_xpath("mssql_vuln_nvd_adp_severity_xpath")
                    severity_element = WebDriverWait(self.browser, DEFAULT_PAGE_WAIT_TIMEOUT).until(
                        ec.presence_of_element_located((By.XPATH, severity_xpath)))
                except (TimeoutException, NoSuchElementException) as nse:
                    self.logger.error(f"Severity element with adp not found, may have an incorrect xpath : {str(nse)}")

        description_xpath = utility.get_xpath("mssql_vuln_nvd_description_xpath")
        try:
            WebDriverWait(self.browser, DEFAULT_PAGE_WAIT_TIMEOUT).until(
                ec.presence_of_element_located((By.XPATH, description_xpath)))
        except TimeoutException as Te:
            self.logger.error(f"Description not found : {str(Te)}")
        raw_severity = severity_element.text.split()[0] if severity_element is not None else "Unknown"
        try:
            description_text = self.browser.find_element(By.XPATH, description_xpath).text
        except NoSuchElementException:
            description_text = ""
        output = {
            "severity": raw_severity,
            "long_description": description_text,
        }
        return output

    def base_score_calculator(self, base_score) -> str:
        try:
            score = float(base_score)
            if score < 4.0:
                return "Low"
            elif score < 7.0:
                return "Medium"
            elif score < 9.0:
                return "High"
            else:
                return "High"
        except (ValueError, TypeError) as Ve:
            utility.logging_to_file(str(Ve))
            self.logger.error(f"Unable to calculate base score: {str(Ve)}")
            return "Unknown"