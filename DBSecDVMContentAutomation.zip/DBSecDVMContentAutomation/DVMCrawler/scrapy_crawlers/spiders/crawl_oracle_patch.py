import json
import re
import scrapy
import time
from bs4 import BeautifulSoup as bs
from time import gmtime, strftime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.options import Options
from scrapy.spidermiddlewares.httperror import HttpError
from twisted.internet.error import DNSLookupError, TimeoutError, TCPTimedOutError
import utility
from ..items import DvmautomationItem
from .spider import Spider

# Matches version+date segments present in Oracle patch strings, e.g. "12.2.0.1.200120"
_VERSION_DATE_RE = re.compile(r'(?:11\.2\.0\.4|12\.1\.0\.2|12\.2\.0\.1)\.\d+')
# Matches patch number tokens; capture group isolates the digit sequence
_PATCH_NUM_RE = re.compile(r'Patch\s+(\d+)')


class CrawlOraclePatch(Spider):
    name = 'oracle_patch'
    custom_settings = {'LOG_FILE': 'Crawler.log', 'LOG_LEVEL': 'INFO'}

    with open('credentials/credentials.json', 'r') as file:
        json_content = json.loads(file.read())
        user = json_content[0]['oracle_patch_username']
        passwd = json_content[0]['oracle_patch_password']

    def start_requests(self):
        oracle_vuln = utility.get_feed_urls('oracle_vuln')
        self.logger.info('Starting Oracle patch crawl: %s', oracle_vuln)
        yield scrapy.Request(url=oracle_vuln, callback=self.parse,
                             errback=self.errback_httpbin, dont_filter=True)

    def parse(self, response):
        """Find the latest CPU advisory link on the Oracle alerts index page."""
        payloads = response.xpath(utility.get_xpath('oracle_payload')).extract()
        payloads_text = response.xpath(utility.get_xpath('oracle_payload_text')).extract()
        if not payloads:
            self.logger.error('No Oracle advisory links found at %s', response.url)
            return
        if payloads_text and 'Announcement' in payloads_text[0]:
            self.logger.info('Oracle advisory announced but not yet released')
            return
        advisory_url = response.urljoin(payloads[0])
        self.logger.info('Navigating to latest CPU advisory: %s', advisory_url)
        yield scrapy.Request(url=advisory_url, callback=self.patch_intermediate_navigate,
                             errback=self.errback_httpbin, dont_filter=True)

    def patch_intermediate_navigate(self, response):
        """
        Find the Oracle Database patch section link on the CPU advisory page,
        then invoke Selenium login to extract patch tables from Oracle Support.

        CPV format: flat list of strings, one per (version, OS) combination.
        Each string contains the Oracle version+date (e.g. '12.2.0.1.200120'),
        OS type ('UNIX' or 'Windows'), and patch tokens ('Patch NNNNNNNN').
        Example: '12.2.0.1.200120 UNIX Patch 30869156 Patch 30869104'

        Generation code iterates the list, branches on version substring
        ('11.2.0.4' / '12.1.0.2' / '12.2.0.1') and OS substring ('UNIX' /
        'Windows') to select the correct SQL check template.
        """
        # Fallback chain: new table structure (Jul 2026+) → old <p> structure → bullet list.
        # oracle_description is reserved for CVE spider; use oracle_patch_db_link here.
        links = (
            response.xpath(utility.get_xpath('oracle_patch_db_link')).extract()
            or response.xpath(utility.get_xpath('oracle_description')).extract()
            or response.xpath(utility.get_xpath('oracle_detail_url_desc')).extract()
        )
        if not links:
            self.logger.error('No Oracle Database patch link found at %s', response.url)
            return
        db_patch_url = links[0]
        if not db_patch_url.startswith('http'):
            db_patch_url = response.urljoin(db_patch_url)
        self.logger.info('Oracle Database patch link: %s', db_patch_url)
        ts = strftime('%Y-%m-%d %H:%M:%S', gmtime())
        cpv_list = self.login(db_patch_url)
        if not cpv_list:
            self.logger.error('Oracle patch login/extraction returned empty list')
            return
        item = DvmautomationItem()
        item['name'] = self.name
        item['current_patch_version'] = cpv_list
        item['affected_version'] = cpv_list
        item['timestamp'] = ts
        item['security_fixes'] = 'Patch'
        self.logger.info('Oracle patch item: %d CPV entries', len(cpv_list))
        yield item

    def _extract_table_entries(self, browser, xpath_key):
        """
        Find the Oracle patch table via absolute XPath, parse each row into a
        CPV string of the form '{version_date} {OS} {Patch N1} {Patch N2}'.

        version_date matches oracle_patch_dates regex ({ver}.{YYMMDD}).
        OS is 'UNIX' or 'Windows'.
        Patch tokens match oracle_patch_patches regex (literal 'Patch' followed by digits).
        """
        xpath = utility.get_xpath(xpath_key)
        entries = []
        try:
            table_el = browser.find_element(By.XPATH, xpath)
            soup = bs(table_el.get_attribute('outerHTML').encode('utf-8'), 'html.parser')
            for row in soup.find_all('tr'):
                text = row.get_text(separator=' ', strip=True)
                if not text:
                    continue
                ver_match = _VERSION_DATE_RE.search(text)
                if not ver_match:
                    continue
                version_date = ver_match.group()
                text_upper = text.upper()
                if 'WINDOWS' in text_upper:
                    os_type = 'Windows'
                else:
                    os_type = 'UNIX'
                patch_nums = _PATCH_NUM_RE.findall(text)
                patch_tokens = ['Patch ' + p for p in patch_nums]
                entry = '{} {} {}'.format(version_date, os_type, ' '.join(patch_tokens)).strip()
                entries.append(entry)
                self.logger.info('Oracle %s row: %s', xpath_key, entry)
        except Exception as err:
            self.logger.warning('Oracle table extraction failed for %s: %s', xpath_key, str(err))
        return entries

    def login(self, url):
        """
        Open the Oracle Support URL with Selenium, authenticate, wait for the patch
        article to load, then extract all three version tables.
        Returns a flat list of CPV strings (empty on failure).

        Handles two login flows:
        - Old Oracle SSO: id="sso_username" / id="sso_password" appear directly.
        - New Oracle Support SPA: a login-selection page with oj-button#loginwithidcs
          appears first; clicking it navigates to the Oracle IDCS credentials form.
        """
        browser = None
        try:
            delay = 20
            opts = Options()
            opts.add_argument('-headless')
            browser = webdriver.Firefox(options=opts)
            browser.get(url)
            self.logger.info('Oracle login: navigated to %s', browser.current_url)

            if utility.wait_until_page_reloads(delay, browser, 'sso_username'):
                # Old Oracle SSO single-page flow (kept for backward compatibility)
                browser.find_element(By.ID, 'sso_username').send_keys(self.user)
                browser.find_element(By.XPATH, "//*[@type='submit']").click()
                utility.wait_until_page_reloads(delay, browser, 'sso_password')
                browser.find_element(By.ID, 'sso_password').send_keys(self.passwd)
                browser.find_element(By.XPATH, "//*[@type='submit']").click()
            else:
                self.logger.info(
                    'Oracle login: old SSO not found; waiting up to %ds for '
                    'login-selection page at %s', delay, browser.current_url)
                # New Oracle Support SPA: wait for Oracle JET to render the login
                # selection buttons (oj-button custom elements).
                if not utility.wait_until_page_reloads(delay, browser, 'loginwithidcs'):
                    self.logger.error(
                        'Oracle login: selection page not rendered after %ds; '
                        'URL=%s title="%s" source_snippet=%s',
                        delay, browser.current_url, browser.title,
                        browser.page_source[:400].replace('\n', ' '))
                    return []
                self.logger.info('Oracle login: found loginwithidcs button at %s', browser.current_url)
                btn = browser.find_element(By.ID, 'loginwithidcs')
                browser.execute_script('arguments[0].click();', btn)
                self.logger.info('Oracle login: clicked loginwithidcs; current URL=%s', browser.current_url)

                # Wait for the IDCS username/email field.
                # Try the standard Oracle IDCS element ID first, then generic CSS selectors.
                username_located = False
                for selector, by in [
                    ('idcs-signin-basic-signin-form-username', By.ID),
                    ("input[type='email']", By.CSS_SELECTOR),
                    ("input[type='text']", By.CSS_SELECTOR),
                ]:
                    if utility.wait_until_page_reloads(delay, browser, selector, by=by):
                        browser.find_element(by, selector).send_keys(self.user)
                        username_located = True
                        self.logger.info('Oracle login: username entered via selector "%s"', selector)
                        break
                if not username_located:
                    self.logger.error(
                        'Oracle login: no username field found; URL=%s title="%s"',
                        browser.current_url, browser.title)
                    return []

                browser.find_element(By.XPATH, "//button[@type='submit'] | //*[@type='submit']").click()

                # Wait for the password field (IDCS two-step: Next → password page).
                password_located = False
                for selector, by in [
                    ('idcs-signin-basic-signin-form-password', By.ID),
                    ("input[type='password']", By.CSS_SELECTOR),
                ]:
                    if utility.wait_until_page_reloads(delay, browser, selector, by=by):
                        browser.find_element(by, selector).send_keys(self.passwd)
                        password_located = True
                        self.logger.info('Oracle login: password entered via selector "%s"', selector)
                        break
                if not password_located:
                    self.logger.error(
                        'Oracle login: no password field found; URL=%s title="%s"',
                        browser.current_url, browser.title)
                    return []

                browser.find_element(By.XPATH, "//button[@type='submit'] | //*[@type='submit']").click()

            browser.maximize_window()
            # Wait for Oracle Support article tables to load
            utility.wait_until_page_reloads(30, browser, 'r1c3-t3')
            self.logger.info('Oracle Support article loaded: %s', browser.current_url)
            cpv_list = []
            for xpath_key in ('oracle_patch_12_2', 'oracle_patch_12_1', 'oracle_patch_11'):
                entries = self._extract_table_entries(browser, xpath_key)
                cpv_list.extend(entries)
            self.logger.info('Oracle patch: %d total CPV entries extracted', len(cpv_list))
            return cpv_list
        except Exception as err:
            self.logger.error('Oracle patch login/extraction error: %s', str(err))
            return []
        finally:
            if browser:
                try:
                    browser.quit()
                except Exception:
                    pass

    def errback_httpbin(self, failure):
        self.logger.error(repr(failure))
        if failure.check(HttpError):
            self.logger.error('HttpError on %s', failure.value.response.url)
        elif failure.check(DNSLookupError):
            self.logger.error('DNSLookupError on %s', failure.request.url)
        elif failure.check(TimeoutError, TCPTimedOutError):
            self.logger.error('TimeoutError on %s', failure.request.url)