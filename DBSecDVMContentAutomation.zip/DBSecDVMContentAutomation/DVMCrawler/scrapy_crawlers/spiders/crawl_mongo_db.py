import scrapy
import re
import json
from bs4 import BeautifulSoup
from datetime import date
from time import gmtime, strftime
from ..items import DvmautomationItem
from .spider import Spider


YEAR_OF_CVE_SELECTION = date.today().year

_CVE_RE = re.compile(r'^CVE-(\d{4})-\d+$', re.IGNORECASE)
_CVSS_RE = re.compile(r'^\d+\.\d+$')

# Non-server MongoDB components to skip
_SKIP_PRODUCTS = (
    'compass', 'driver', 'connector', 'ops manager',
    'atlas', 'kafka', 'spark', 'bi connector',
)


class CrawlMongoDb(Spider):

    name = 'mongodb'
    max_cves = 100
    custom_settings = {
        'LOG_FILE': 'Crawler.log',
        'LOG_LEVEL': 'INFO',
    }

    def start_requests(self):
        with open('credentials/urls.json', 'r') as f:
            urls = json.load(f)
        self._cve_org_url = urls.get('cve_org_api_uri', '')
        url = urls['mongodb_vuln']
        self.logger.info('Starting MongoDB vulnerability crawl: %s', url)
        yield scrapy.Request(url, callback=self.parse, errback=self.errback)

    def parse(self, response):
        self.logger.info('Got response from %s (status=%d, size=%d bytes)',
                         response.url, response.status, len(response.body))

        soup = BeautifulSoup(response.text, 'lxml')
        pending = []   # list of raw-data dicts for accepted CVEs
        seen = set()

        # Each CVE lives in a card whose header has:
        #   <strong>CVE-YYYY-NNNNN</strong>   (CVE ID)
        #   <small><b>N.N</b></small>          (CVSS score in ScoreBox)
        # and whose body has:
        #   <h4>...</h4>                        (title)
        #   div "Affects:" → <p><b>product</b></p>
        #   div "Versions:" → <p><span>ver range</span>...</p>
        #
        # Strategy: find every <strong> matching a CVE ID, walk up the DOM
        # until we reach the div that contains both <small> and <h4> — that
        # is the card container.

        for strong_tag in soup.find_all('strong'):
            text = strong_tag.get_text(strip=True)
            m = _CVE_RE.match(text)
            if not m or int(m.group(1)) != YEAR_OF_CVE_SELECTION:
                continue

            cve_no = text.upper()
            if cve_no in seen:
                continue
            seen.add(cve_no)

            # Walk up to the card container
            card = None
            node = strong_tag
            for _ in range(10):
                if node.parent is None:
                    break
                node = node.parent
                # The card container is the first ancestor <div> that holds
                # both the ScoreBox (<small>) and the title (<h4>)
                if node.name == 'div' and node.find('small') and node.find('h4'):
                    card = node
                    break

            if card is None:
                self.logger.warning('%s: could not locate card container in DOM', cve_no)
                continue

            # ── CVSS score ────────────────────────────────────────────────
            # Lives in <small><b>8.8</b></small> inside the ScoreBox div.
            cvss_raw = ''
            small_tag = card.find('small')
            if small_tag:
                b_tag = small_tag.find('b')
                if b_tag:
                    candidate = b_tag.get_text(strip=True)
                    if _CVSS_RE.match(candidate):
                        cvss_raw = candidate

            # ── Title ─────────────────────────────────────────────────────
            title = ''
            h4 = card.find('h4')
            if h4:
                title = h4.get_text(strip=True)

            # ── Product ───────────────────────────────────────────────────
            # The "Affects:" label is a <div> whose text is exactly "Affects:".
            # The <p> that immediately follows it contains <b>Product Name</b>.
            product = ''
            affects_node = card.find(string=re.compile(r'^\s*Affects:\s*$', re.I))
            if affects_node:
                p_tag = affects_node.parent.find_next_sibling('p')
                if p_tag:
                    b_tag = p_tag.find('b')
                    if b_tag:
                        product = b_tag.get_text(strip=True)

            # ── Affected versions ─────────────────────────────────────────
            # The "Versions:" label is a <div>; the following <p> contains
            # one <span> per version range (e.g. "8.3.0 affects 8.3.3 and prior").
            versions_text = ''
            ver_node = card.find(string=re.compile(r'^\s*Versions:\s*$', re.I))
            if ver_node:
                p_tag = ver_node.parent.find_next_sibling('p')
                if p_tag:
                    spans = [
                        s.get_text(separator=' ', strip=True)
                        for s in p_tag.find_all('span')
                        if s.get_text(strip=True)
                    ]
                    if spans:
                        versions_text = '; '.join(spans)

            self.logger.info('%s: cvss=%s, product=%r, versions_found=%s',
                             cve_no, cvss_raw or '(none)', product, bool(versions_text))

            # Skip non-server components
            if product and any(skip in product.lower() for skip in _SKIP_PRODUCTS):
                self.logger.info('%s: skipping non-server product "%s"', cve_no, product)
                continue

            pending.append({
                'cve_no': cve_no,
                'cvss_raw': cvss_raw,
                'versions_text': versions_text or product or '',
                'title': title,
            })

        self.logger.info('Total current-year CVEs accepted: %d, emitting up to %d',
                         len(pending), self.max_cves)
        if not pending:
            self.logger.warning('No MongoDB CVEs found for year %d. '
                                'Page structure may have changed.', YEAR_OF_CVE_SELECTION)

        for entry in pending[:self.max_cves]:
            cve_no = entry['cve_no']
            if entry['cvss_raw']:
                # CVSS available on the page — emit directly
                item = self._build_item(cve_no, entry['cvss_raw'],
                                        entry['versions_text'], entry['title'])
                self.logger.info('Emitting direct: %s severity=%s', cve_no, item['severity'])
                yield item
            else:
                # CVSS missing — request CVE.org API for enrichment
                self.logger.info('%s: no CVSS on page, fetching from CVE.org API', cve_no)
                yield scrapy.Request(
                    url=self._cve_org_url + cve_no,
                    callback=self.parse_cve_org,
                    errback=self.errback_enrichment,
                    dont_filter=True,
                    headers={'Accept': 'application/json'},
                    meta={
                        'cve_no': cve_no,
                        'versions_text': entry['versions_text'],
                        'title': entry['title'],
                    }
                )

    def parse_cve_org(self, response):
        """Fill in CVSS score from CVE.org JSON API when the MongoDB page has none."""
        cve_no = response.meta['cve_no']
        versions_text = response.meta['versions_text']
        title = response.meta['title']

        cvss_raw = ''
        try:
            payload = json.loads(response.text)
            cna = payload.get('containers', {}).get('cna', {})
            all_metrics = list(cna.get('metrics', []))
            for adp in payload.get('containers', {}).get('adp', []):
                all_metrics.extend(adp.get('metrics', []))

            for metric in all_metrics:
                # Prefer CVSSv3.1 → v3.0 → v4.0 → v2.0
                cvss = (metric.get('cvssV3_1') or metric.get('cvssV3_0')
                        or metric.get('cvssV4_0'))
                if cvss and cvss.get('baseScore') is not None:
                    cvss_raw = str(cvss['baseScore'])
                    break
                cvss2 = metric.get('cvssV2_0')
                if cvss2 and cvss2.get('baseScore') is not None:
                    cvss_raw = str(cvss2['baseScore'])
                    break
        except (json.JSONDecodeError, KeyError, TypeError, AttributeError) as e:
            self.logger.warning('%s: CVE.org parse failed: %s', cve_no, e)

        self.logger.info('%s: CVE.org enrichment: cvss=%s → severity=%s',
                         cve_no, cvss_raw or '(none)', self._cvss_to_severity(cvss_raw))
        yield self._build_item(cve_no, cvss_raw, versions_text, title)

    def errback_enrichment(self, failure):
        """Emit a minimal item when CVE.org enrichment request fails."""
        request = failure.request
        cve_no = request.meta.get('cve_no', '')
        self.logger.warning('%s: CVE.org enrichment request failed: %s', cve_no, repr(failure))
        yield self._build_item(
            cve_no,
            '',
            request.meta.get('versions_text', ''),
            request.meta.get('title', ''),
        )

    def _build_item(self, cve_no, cvss_raw, versions_text, title):
        item = DvmautomationItem()
        item['name'] = self.name
        item['cve_no'] = cve_no
        item['severity'] = self._cvss_to_severity(cvss_raw)
        item['affected_version'] = versions_text or 'Unknown'
        item['long_description'] = title
        item['link'] = 'https://cve.mitre.org/cgi-bin/cvename.cgi?name={}'.format(cve_no)
        item['security_fixes'] = 'Vulnerability'
        item['timestamp'] = strftime("%Y-%m-%d %H:%M:%S", gmtime())
        return item

    @staticmethod
    def _cvss_to_severity(score_str):
        try:
            score = float(score_str)
            if score < 4.0:
                return 'Low'
            elif score < 7.0:
                return 'Medium'
            elif score < 9.0:
                return 'High'
            else:
                return 'High'
        except (ValueError, TypeError):
            return 'Unknown'

    def errback(self, failure):
        self.logger.error('MongoDB request failed: %s', failure)