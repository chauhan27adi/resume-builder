import scrapy
from bs4 import BeautifulSoup as bs
import os
from ..items import DvmautomationItem
import re
from time import gmtime, strftime
from scrapy.spidermiddlewares.httperror import HttpError                            # handling http related exceptions
from twisted.internet.error import DNSLookupError                                   # handling connection lost related exceptions
from twisted.internet.error import TimeoutError, TCPTimedOutError
import utility
from .spider import Spider

class CrawlPostgreDb(Spider):                                                 # class should inherit base class of scrapy

    name='postgredb'                                                                 # name of the crawler should be unique for each crawler.
    # custom_settings = {'DOWNLOAD_TIMEOUT': 3}                                      # no. of retries should be made before giving error

    # Configurable limit for number of most recent CVEs to fetch
    max_cves = 100

    custom_settings = {
        'LOG_FILE': 'Crawler.log',
        'LOG_LEVEL': 'INFO',
    }

    def start_requests(self):
        postgre_vuln = utility.get_feed_urls('postgre_vuln')
        self.logger.info('Starting PostgreSQL vulnerability crawl: %s', postgre_vuln)
        yield scrapy.Request(url=postgre_vuln, callback=self.parse, errback=self.errback_httpbin, dont_filter=True)

    @staticmethod
    def _get_affected_version_column_index(table_element):
        """
        Identify which column index in the table contains the fixed version.

        Despite the name, this targets the "Fixed" column (not "Affected") because
        DVMCheckGenerator needs major.minor version strings (e.g. "16.8", "15.11")
        to extract the patch threshold for its SQL query (e.g. `ver < 8`). The
        "Affected" column only lists bare major versions (e.g. "16, 15, 14") which
        are useless for threshold calculation. The "Fixed" column always contains
        the exact build at which each major-version line was patched.

        Returns the column index (0-based), or None if not found.
        """
        if table_element is None:
            return None

        ths = table_element.select('thead tr th') or table_element.select('tr:first th')
        if not ths:
            return None

        for idx, th in enumerate(ths):
            text = ' '.join(th.stripped_strings).lower()
            # Intentionally match "Fixed", not "Affected": see docstring above.
            if 'fixed' in text:
                return idx

        return None

    @staticmethod
    def _get_severity_column_index(table_element):
        """
        Identify which column index contains the CVSS base score.

        The PostgreSQL security table uses the column header
        "Component & CVSS v3 Base Score". Matches any header whose text
        contains 'cvss' or both 'component' and 'score' (case-insensitive).

        Returns the 0-based column index, or None if not found.
        """
        if table_element is None:
            return None

        ths = table_element.select('thead tr th') or table_element.select('tr:first th')
        if not ths:
            return None

        for idx, th in enumerate(ths):
            text = ' '.join(th.stripped_strings).lower()
            if 'cvss' in text or ('component' in text and 'score' in text):
                return idx

        return None

    def extract_postgre_affected_version(self, payload_bs, table_element=None):
        """
        Extract the fixed-version text from a PostgreSQL security table row.

        Despite the name, this extracts from the "Fixed" column (not "Affected").
        DVMCheckGenerator requires major.minor strings (e.g. "16.8, 15.11, 14.15")
        to compute the patch-level threshold in its SQL query (`ver < minor`). The
        "Affected" column only provides bare major versions (e.g. "16, 15, 14") which
        cannot be used to fill the `< N` placeholder. The "Fixed" column is the
        authoritative source for that threshold.

        First attempts to use table headers to identify the fixed-version column
        (via _get_affected_version_column_index). Falls back to heuristic matching
        if headers are unavailable.

        Args:
            payload_bs: BeautifulSoup row element (<tr>)
            table_element: Optional parent <table> element for header lookup
        """
        tds = payload_bs.select('td')
        if not tds:
            return ''

        def _clean_text(td_tag):
            return ' '.join(td_tag.stripped_strings).strip()

        # Try header-based column identification first.
        col_idx = None
        if table_element:
            col_idx = self._get_affected_version_column_index(table_element)

        if col_idx is not None and col_idx < len(tds):
            result = _clean_text(tds[col_idx])
            if result and not re.search(r'cve-\d{4}-\d+', result.lower()):
                return result

        # Fallback to heuristic matching.
        candidates = []
        for idx, td in enumerate(tds):
            text = _clean_text(td)
            if not text:
                continue

            lower_txt = text.lower()

            # Skip obvious non-affected-version cells.
            if re.search(r'cve-\d{4}-\d+', lower_txt):
                continue
            if lower_txt in {'none', 'low', 'medium', 'high', 'critical'}:
                continue
            if re.fullmatch(r'\d+(?:\.\d+)?', text):
                continue

            # Prefer cells with PostgreSQL version-like patterns.
            has_version_pattern = bool(re.search(r'\b\d{1,2}\.\d{1,2}(?:\.\d{1,3})?\b', text))
            has_supported_phrase = 'supported version' in lower_txt
            has_pg_hint = 'postgres' in lower_txt or 'version' in lower_txt

            if has_version_pattern or has_supported_phrase or has_pg_hint:
                # Bias to traditional affected-version columns.
                weight = 1
                if idx == 1:
                    weight += 3
                elif idx == 2:
                    weight += 1
                if has_version_pattern:
                    weight += 3
                if has_supported_phrase:
                    weight += 2
                candidates.append((weight, text))

        if candidates:
            candidates.sort(key=lambda x: x[0], reverse=True)
            result = candidates[0][1]
            self.logger.debug('Affected version extracted via heuristic: %s', result)
            return result

        # Fallback for unexpected row shapes.
        self.logger.warning('No version-like candidate found in row; using positional fallback')
        if len(tds) > 1:
            return _clean_text(tds[1])
        return _clean_text(tds[0])

    # This function reads and extarct all the fields, i.e longdescription, severity, cve, affected version, link etc
    def parse(self, response):
        """
        Parses PostgreSQL CVE vulnerability page responses and yields structured CVE items.

        This function extracts CVE-related information from the HTML response of a
        PostgreSQL security page. For each CVE listed on the page, it collects:

        - CVE ID (`cve_no`)
        - Affected version(s) (`affected_version`)
        - Severity score (`severity`), converted via `base_score_calculator`
        - Detailed description (`long_description`) from MITRE or PostgreSQL pages
        - Security fix type (`security_fixes`)
        - Link to PostgreSQL security page
        - Name of the spider and timestamp of extraction

        Extracted data is stored in `DvmautomationItem` instances, which are then yielded
        one by one for further processing in the Scrapy pipeline.

        Args:
            response (scrapy.http.Response): The HTTP response object from the requested CVE URL.

        Yields:
            DvmautomationItem: Structured item containing CVE details such as CVE ID, severity,
                               affected version, description, timestamp, and related links.

        Logs:
            - Successful retrieval of the response URL.
            - Errors for missing files (`FileNotFoundError`) or incorrect XPaths (`IndexError`).
        """

        self.logger.info('Got successful response from {}'.format(response.url))
        try:
            # ASSUMPTION: The first <table> on the PostgreSQL security page is the CVE
            # advisory table. This holds for the current page structure at
            # https://www.postgresql.org/support/security/ but will break silently if
            # PostgreSQL adds any preceding table (e.g. navigation, filter, or announcement).
            # POTENTIAL FIX: derive table_element from the same ancestor table as the
            # payload rows, making column detection immune to page structure changes:
            #   table_xpath = utility.get_xpath('postgre_payload') + '/ancestor::table[1]'
            #   table = response.xpath(table_xpath).get()
            table = response.xpath('//table[1]').get()
            table_element = bs(table, 'html.parser') if table else None
            severity_col_idx = self._get_severity_column_index(table_element)
            payloads = response.xpath(utility.get_xpath('postgre_payload')).extract()[:self.max_cves]
            for payload in payloads:
                payload_bs = bs(payload, 'html.parser')

                nobr = payload_bs.select_one('.nobr')
                if nobr is None:
                    self.logger.warning("No CVE element (.nobr) found in row, skipping")
                    continue
                cve_no_with_link = nobr.extract()
                cve_no = cve_no_with_link.get_text(strip=True)                # logic to extract cve_no
                # affected_version = payload_bs.select('td')[2].text
                affected_version = self.extract_postgre_affected_version(payload_bs, table_element)
                if not affected_version:
                    self.logger.warning(f"Unable to extract affected_version for {cve_no}; skipping row")
                    continue
                row_tds = payload_bs.select('td')
                raw_score = ''
                if severity_col_idx is not None and severity_col_idx < len(row_tds):
                    cell_text = ' '.join(row_tds[severity_col_idx].stripped_strings)
                    score_match = re.search(r'\b(\d+\.\d+)\b', cell_text)
                    raw_score = score_match.group(1) if score_match else cell_text
                if not raw_score:
                    links = payload_bs.select('td a')
                    raw_score = links[-2].text if len(links) >= 2 else ''
                severity = self.base_score_calculator(raw_score)
                mitre_link = utility.get_feed_urls("mitre_cve").format(cve_no)
                pgsql_link = utility.get_feed_urls("pgsql_cve_more_details").format(cve_no)
                long_description = self.long_description_collector(mitre_link, pgsql_link)             # logic to extract long description
                items = DvmautomationItem()
                items['long_description'] = long_description
                items['severity'] = severity
                items['cve_no'] = cve_no
                items['affected_version'] = affected_version
                items['name'] = self.name
                items['timestamp'] = strftime("%Y-%m-%d %H:%M:%S", gmtime())
                items['security_fixes'] = 'Vulnerability'
                items['link'] = pgsql_link
                self.logger.info("Checks\n" + str(items))
                yield items

        except FileNotFoundError as e:
            self.logger.error('File not found Exception ' + str(e))
        except IndexError as e:
            self.logger.error('One or fes details may have wrong xpath ' + str(e))

    @staticmethod
    def temp_files(name):                # logic for creating tem files
        """
        Creates a temporary directory and log file for storing data, and returns the file path.

        This function checks if a directory with the given `name` exists in the current working
        directory. If the directory does not exist, it is created. Inside this directory, a log
        file named `<name>.log` is created (or reused if it already exists). The function then
        returns the full path to this log file.

        Args:
            name (str): The name of the directory and log file to create.

        Returns:
            str: Full file path of the log file (e.g., `/current/working/directory/<name>/<name>.log`).

        Example:
            "">>> file_path = temp_files("postgredb")""
            "">>> print(file_path)""
            /home/user/project/postgredb/postgredb.log
        """
        file_name = ''
        if os.path.isdir(os.path.join(os.getcwd(), name)):
            filepath = os.path.join(os.getcwd(), name)
            file_name = os.path.join(filepath, name) + '.log'
        else:
            os.makedirs(name)
            filepath = os.path.join(os.getcwd(), name)
            file_name = os.path.join(filepath, name) + '.log'
            with open(file_name, 'w'):
                pass
        return file_name

    def errback_httpbin(self, failure):  # catching exception of parser.
        """
        Handles errors and exceptions encountered during Scrapy requests, logging them
        both to the console and to a temporary log file.

        This function is intended to be used as an `errback` for Scrapy requests. It logs
        all types of failures and provides special handling for HTTP errors, DNS lookup
        errors, and timeout errors. Corresponding error codes are written to a log file
        created using `self.temp_files(self.name)`.

        Args:
            failure (Failure): A Scrapy Failure object representing the exception
                               encountered during a request.

        Error Handling:
            - HttpError: Logs the URL that caused the HTTP error and writes "HttpError
                         Error Code 101" to the log file.
            - DNSLookupError: Logs the URL that caused the DNS lookup error and writes
                              "DNSLookupError Error Code 102" to the log file.
            - TimeoutError / TCPTimedOutError: Logs the URL that caused the timeout
                                               and writes "TimeoutError Error Code 103"
                                               to the log file.

        Example:
            "">>> yield scrapy.Request(url, callback=self.parse, errback=self.errback_httpbin)""
        """
        # log all failures
        obj = self.temp_files(self.name)
        self.logger.error(repr(failure))

        # in case you want to do something special for some errors,
        # you may need the failure's type:

        if failure.check(HttpError):  # catches any http errors like like invalid urls
            # these exceptions come from HttpError spider middleware
            # you can get the non-200 response
            response = failure.value.response
            self.logger.error('HttpError on %s', response.url)  # logging errors in console
            with open(obj, 'w') as file:
                file.write('HttpError' + ' Error Code 101')  # writting the error code and error message to log files

        elif failure.check(DNSLookupError):  # catches connection lost exceptions
            # this is the original request
            request = failure.request

            self.logger.error('DNSLookupError on %s', request.url)  # logging errors in console
            with open(obj, 'w') as file:
                file.write('DNSLookupError' + ' Error Code 102')  # writting the error code and error message to log files

        elif failure.check(TimeoutError, TCPTimedOutError):  # catches timeout exceptions
            request = failure.request
            self.logger.error('TimeoutError on %s', request.url)  # logging errors in console
            with open(obj, 'w') as file:
                file.write('TimeoutError' + ' Error Code 103')  # writting the error code and error message to log files

    def base_score_calculator(self, base_score):
        """
        Converts a numeric CVSS base score into a human-readable severity category.

        The function maps the CVSS base score to severity levels as follows:
            - 0.1 to 3.9   -> "Low"  (0.0 is classified as "None")
            - 4.0 to 6.9   -> "Medium"
            - 7.0 to 8.9   -> "High"
            - 9.0 to 10.0  -> "High"  (intentional: downstream format_severity() in checkgenerator 
                                        or checkmate server doesn't support "Critical" branch, 
                                        so Critical CVEs are stored as "High" to ensure checks are still generated)

        Args:
            base_score (str or float): The CVSS base score to convert. It can be a string
                                       or a numeric value.

        Returns:
            str: A severity category as "Low", "Medium", or "High". Returns "Unknown" if
                 conversion of `base_score` to float fails.

        Logs:
            If the conversion of `base_score` to float fails, an error is logged using
            `self.logger.error`.

        Example:
            "">>> self.base_score_calculator("5.6")""
            'Medium'
            "">>> self.base_score_calculator(9.5)""
            'High'
        """
        try:
            score = float(base_score)
            if score < 4.0:
                return "Low"        # Low: 0.1 to 3.9, 0.0 is classified as "None"
            elif score < 7.0:
                return "Medium"     # Medium: 4.0 to 6.9
            elif score < 9.0:
                return "High"       # High: 7.0 to 8.9
            else:
                return "High"       # Critical: 9.0 to 10.0
        except (ValueError, TypeError) as ve:
            self.logger.error("Unable to convert base score: " + str(ve))
            return "Unknown"

# This function responsible for collection of long description.

    def long_description_collector(self, mitre_url, pgsql_url):
        """
            Collects the detailed description of a CVE from MITRE or PostgreSQL official pages.

            This function first tries to extract the description from the MITRE CVE page.
            If the description is not found (common for newly published CVEs), it falls back
            to the PostgreSQL official security page.

            Args:
                mitre_url (str): URL of the MITRE CVE page.
                pgsql_url (str): URL of the PostgreSQL official CVE page.

            Returns:
                str: The CVE description text, stripped of leading/trailing whitespace.
                     Returns None if the description cannot be found on either page.
        """
        import urllib.error
        description = None
        try:
            self.logger.debug('Fetching description from MITRE: %s', mitre_url)
            soup = bs(self.urlopen(mitre_url), "html.parser")
            tags = soup.select(utility.get_xpath("postgre_mitre_description"))
            description = tags[-1].get_text(strip=True) if tags else None
        except (urllib.error.URLError, urllib.error.HTTPError, Exception) as e:
            self.logger.warning('MITRE fetch failed for %s: %s', mitre_url, e)
        if not description:
            try:
                self.logger.debug('Falling back to PostgreSQL page: %s', pgsql_url)
                soup = bs(self.urlopen(pgsql_url), "html.parser")
                el = soup.select_one(utility.get_xpath("postgre_official_description"))
                description = el.get_text(strip=True) if el else None
            except (urllib.error.URLError, urllib.error.HTTPError, Exception) as e:
                self.logger.warning('PostgreSQL page fetch failed for %s: %s', pgsql_url, e)
        if not description:
            self.logger.warning('Description not found on MITRE or PostgreSQL page for: %s', mitre_url)
        return description