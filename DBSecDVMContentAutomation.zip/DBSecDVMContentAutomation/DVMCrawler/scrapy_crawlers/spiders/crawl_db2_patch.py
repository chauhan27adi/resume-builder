import re
import scrapy
from time import gmtime, strftime
from scrapy.spidermiddlewares.httperror import HttpError
from twisted.internet.error import DNSLookupError, TimeoutError, TCPTimedOutError
import utility
from ..items import DvmautomationItem
from .spider import Spider


# "Fix Pack 6" or "FP6" in link text
_FP_RE = re.compile(r'(?:Fix Pack|FP)\s*(\d+)', re.IGNORECASE)
# Full DB2 version string e.g. "11.1.4060.6787"
_VERSION_RE = re.compile(r'\b(\d+\.\d+\.\d+\.\d+)\b')
# Build level e.g. "s20201030"
_BUILD_RE = re.compile(r'\b(s\d{8})\b', re.IGNORECASE)

# Simple families: fix pack number is extractable from the main page link text.
# CPV format: "{fp_num}:{version}"
_SIMPLE_FAMILIES = [
    ('9.7',  'db2_patch_9_7'),
    ('10.1', 'db2_patch_10_1'),
    ('10.5', 'db2_patch_10_5'),
]


class CrawlDb2Patch(Spider):
    name = 'db2_patch'
    custom_settings = {'LOG_FILE': 'Crawler.log', 'LOG_LEVEL': 'INFO'}

    def start_requests(self):
        url = utility.get_feed_urls('db2_patch')
        self.logger.info('Starting DB2 patch crawl: %s', url)
        yield scrapy.Request(url=url, callback=self.parse_main_page,
                             errback=self.errback_httpbin, dont_filter=True)

    def _make_item(self, cpv, ts):
        item = DvmautomationItem()
        item['name'] = self.name
        item['current_patch_version'] = cpv
        item['affected_version'] = cpv
        item['timestamp'] = ts
        item['security_fixes'] = 'Patch'
        return item

    def _extract_fp_num(self, link_text, version_label):
        m = _FP_RE.search(link_text)
        if m:
            return m.group(1)
        nums = re.findall(r'\d+', link_text)
        if nums:
            return nums[-1]
        self.logger.warning('DB2 %s: cannot extract FP number from %r', version_label, link_text)
        return None

    def parse_main_page(self, response):
        ts = strftime('%Y-%m-%d %H:%M:%S', gmtime())

        # 9.7, 10.1, 10.5 — extract fix pack number from first link on main page.
        # CPV "{fp_num}:{version}" satisfies generate_db2_db_patch_checks detection:
        #   '9.7' in "{fp_num}:9.7" → True, fix_pack = re.findall(r'\d+', "{fp_num}")[0] ✓
        for version, xpath_key in _SIMPLE_FAMILIES:
            links = response.css(utility.get_xpath(xpath_key))
            if not links:
                self.logger.warning('DB2 %s: no fix pack links found on %s', version, response.url)
                continue
            link_text = (links[0].css('::text').get() or '').strip()
            fp_num = self._extract_fp_num(link_text, version)
            if fp_num is None:
                continue
            cpv = '{}:{}'.format(fp_num, version)
            self.logger.info('DB2 %s patch cpv: %s', version, cpv)
            yield self._make_item(cpv, ts)

        # 11.1 — follow first fix pack link to sub-page to get version string and build level.
        # CPV "11.1 Fix Pack {N}:{version_string}:{build_level}" required by else branch:
        #   re.findall(db2_patch_fix_pack_regex, "11.1 Fix Pack N") → ["1 Fix Pack N"]
        #   re.findall(r'\d+', "1 Fix Pack N")[-1] → fp number ✓
        links_11_1 = response.css(utility.get_xpath('db2_patch_11_1'))
        if not links_11_1:
            self.logger.warning('DB2 11.1: no fix pack links found on %s', response.url)
            return
        first_link = links_11_1[0]
        link_text_11_1 = (first_link.css('::text').get() or '').strip()
        href = first_link.attrib.get('href', '')
        if href:
            yield scrapy.Request(
                url=response.urljoin(href),
                callback=self.parse_11_1_subpage,
                errback=self.errback_httpbin,
                meta={'link_text': link_text_11_1, 'ts': ts},
                dont_filter=True,
            )
        else:
            self.logger.warning('DB2 11.1: no href on first fix pack link %r', link_text_11_1)

    def parse_11_1_subpage(self, response):
        link_text = response.meta.get('link_text', '')
        ts = response.meta.get('ts', strftime('%Y-%m-%d %H:%M:%S', gmtime()))

        fp_num = self._extract_fp_num(link_text, '11.1')
        if fp_num is None:
            fp_num = '0'

        # Fix Pack INFO table headers: first th = "11.1 Fix Pack N", second = version, third = build level
        th_texts = response.css(utility.get_xpath('db2_patch_build_no') + '::text').getall()
        version_str = ''
        build_level = ''
        for th in th_texts:
            th = th.strip()
            if not version_str:
                mv = _VERSION_RE.search(th)
                if mv:
                    version_str = mv.group(1)
            if not build_level:
                mb = _BUILD_RE.search(th)
                if mb:
                    build_level = mb.group(1).lower()

        if not version_str or not build_level:
            # Fallback: meta description tag
            meta_content = response.css('meta[name="description"]::attr(content)').get() or ''
            if not version_str:
                mv = _VERSION_RE.search(meta_content)
                if mv:
                    version_str = mv.group(1)
            if not build_level:
                mb = _BUILD_RE.search(meta_content)
                if mb:
                    build_level = mb.group(1).lower()

        fp_segment = '11.1 Fix Pack {}'.format(fp_num)
        cpv = '{}:{}:{}'.format(fp_segment, version_str, build_level)
        self.logger.info('DB2 11.1 patch cpv: %s', cpv)
        yield self._make_item(cpv, ts)

    def errback_httpbin(self, failure):
        self.logger.error(repr(failure))
        if failure.check(HttpError):
            self.logger.error('HttpError on %s', failure.value.response.url)
        elif failure.check(DNSLookupError):
            self.logger.error('DNSLookupError on %s', failure.request.url)
        elif failure.check(TimeoutError, TCPTimedOutError):
            self.logger.error('TimeoutError on %s', failure.request.url)