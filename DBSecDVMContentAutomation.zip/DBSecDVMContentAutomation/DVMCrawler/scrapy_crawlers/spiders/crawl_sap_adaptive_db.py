import scrapy  # to import scrapy framework
from ..items import DvmautomationItem
import re
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.options import Options
from time import gmtime, strftime
import json
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
import utility
from .spider import Spider

nvd_base_url = utility.get_feed_urls("nvd_uri")  # nvd url to crawl for severity.

"""
SAP Adaptive Server Enterprise (SAP ASE) and Sybase ASE refer to the same database product, under different names.
- Sybase ASE: The original product name.
- SAP ASE: The name after SAP acquired Sybase in 2010.
- SAP Adaptive Server Enterprise: The full product name.
For database identification and vulnerability research, you can generally treat SAP ASE and Sybase ASE as the same product lineage, 
while checking the exact version and patch level.
"""


class CrawlSybaseDb(Spider):
    """
    Sybase ASE vulnerability crawler.

    Current primary flow:
        1) Pull CVE candidates from NVD JSON API.
        2) Filter CVEs to Sybase ASE-relevant records.
        3) Resolve SAP note URL from CVE references.
        4) Login to SAP Launchpad and extract affected versions.
        5) Emit vulnerability item for check generation.

    Patch flow is intentionally kept out of the active crawl path.

    Generic and fallback flow summary:
        Generic flow:
            NVD API -> filter Sybase ASE CVEs -> extract severity/description/reference URLs
            -> resolve SAP Launchpad note link -> login to SAP Launchpad -> extract affected
            versions from note content -> normalize versions -> emit MongoDB item.

        Fallback flow for legacy CVEs:
            If the NVD record has no direct SAP note link, try to rebuild one from older SAP
            reference URLs or note-number-style links. If SAP note content is still unavailable
            after login (common for older notes or Launchpad shell-only rendering), fall back to
            deriving base affected versions from the NVD description text itself.

        Why fallback is needed:
            Older CVEs often have incomplete NVD references, legacy SAP URL formats, or SAP note
            pages that no longer expose usable content through Launchpad automation. The fallback
            path prevents those CVEs from being dropped when the description still contains enough
            Sybase ASE version information to build a useful record.

        In short:
            preferred path: NVD API → SAP note URL → SAP Launchpad note → normalized affected versions
            fallback path: NVD API → legacy/alternate reference or NVD description → description-derived affected versions
    """

    name = 'sybasedb'
    max_cves = 100
    custom_settings = {
        'LOG_FILE': 'Crawler.log',
        'LOG_LEVEL': 'INFO',
    }

    # NVD keyword coverage for Sybase ASE records.
    # "SAP Adaptive" alone misses some recent records that are tagged as "SAP ASE" or "Sybase ASE".
    vulnerability_keywords = [
        'SAP Adaptive',
        'SAP ASE',
        'Adaptive Server Enterprise',
        'Sybase ASE',
    ]

    with open('credentials/urls.json', 'r') as file:  # gets Url from url.json file
        json_content = json.loads(file.read())
        sybase_vuln = json_content.get('sybase_vuln', 'https://cve.mitre.org/cgi-bin/cvekey.cgi?keyword=SAP+Adaptive')
        sybase_vuln_api = json_content.get(
            'sybase_vuln_api',
            'https://services.nvd.nist.gov/rest/json/cves/2.0?keywordSearch=SAP%20Adaptive&resultsPerPage=2000'
        )

    with open('credentials/credentials.json', 'r') as file:  # gets credentials from credential.json file
        json_content = json.loads(file.read())
        user = json_content[1]['sap_hana_username']
        passwd = json_content[1]['sap_hana_password']

    def start_requests(self):
        """
        Entry point for spider execution.

        Purpose: Initialize the crawler and dispatch requests to fetch Sybase ASE vulnerabilities.
        Patch flow is intentionally skipped for now; only vulnerability flow is dispatched.

        Flow:
          1. Load NVD JSON API URL from configuration
          2. Dispatch initial request to parse_vuln_api callback
          3. parse_vuln_api processes JSON and builds items directly
        """
        self.logger.info("=" * 80)
        self.logger.info("SYBASE CRAWLER STARTED: Beginning vulnerability collection cycle")
        self.logger.info("=" * 80)

        # Track CVEs successfully emitted across multiple NVD keyword queries.
        # Important: do not mark a CVE as handled before item creation succeeds,
        # otherwise a transient extraction failure in the first keyword response
        # can suppress valid duplicates from later keyword responses.
        self._emitted_cve_ids = set()

        request_urls = self.get_vulnerability_query_urls()
        self.logger.info("Dispatching %d Sybase vulnerability API request(s)", len(request_urls))
        self.logger.info("Keywords covered: %s", ', '.join(self.vulnerability_keywords))

        for request_url in request_urls:
            self.logger.info("Dispatching Sybase vulnerability API url: %s", request_url)
            yield scrapy.Request(request_url, callback=self.parse_vuln_api, dont_filter=True)

    def get_vulnerability_query_urls(self):
        """
        Build NVD API query URLs for all configured Sybase keywords.

        This keeps the configured API endpoint as the base and generates one request per keyword
        while preserving `resultsPerPage` from config (defaults to 2000).
        """
        base_url = str(self.sybase_vuln_api).strip()
        parsed = urlparse(base_url)

        # Use configured endpoint path if valid; fallback to official NVD v2 endpoint.
        endpoint = '{0}://{1}{2}'.format(parsed.scheme, parsed.netloc,
                                         parsed.path) if parsed.scheme and parsed.netloc else 'https://services.nvd.nist.gov/rest/json/cves/2.0'

        query_params = parse_qs(parsed.query)
        results_per_page = str(query_params.get('resultsPerPage', ['2000'])[0])

        urls = []
        for keyword in self.vulnerability_keywords:
            query = urlencode({
                'keywordSearch': keyword,
                'resultsPerPage': results_per_page,
            })
            urls.append(urlunparse(
                (urlparse(endpoint).scheme, urlparse(endpoint).netloc, urlparse(endpoint).path, '', query, '')))

        # Deduplicate while preserving order.
        return list(dict.fromkeys(urls))

    def parse_vuln_api(self, response):
        """
        Main source parser: reads JSON payload from NVD API and builds final items directly.

        This is the PRIMARY vulnerability extraction path. Each vulnerability from NVD is:
          1. Checked if it's a Sybase ASE-relevant record
          2. Processed for severity, SAP note links, and affected versions
          3. Normalized and validated
          4. Emitted as a DvmautomationItem to MongoDB pipeline

        Key Metrics:
          - Candidate CVEs: Total records returned by NVD API
          - Valid CVEs: Records passing Sybase ASE filtering
          - Emitted items: CVEs with complete required fields (severity, SAP link, versions)
          - Skipped CVEs: Records missing required fields (logged with reasons)

        Performance Note: Selenium authentication + page load takes ~20s per valid CVE
        """
        try:
            self.logger.info("-" * 80)
            self.logger.info("PARSE_VULN_API: Processing NVD JSON response")
            self.logger.info("-" * 80)
            self.logger.info("API Response URL: %s", response.url)

            data = json.loads(response.text)
            vulnerabilities = data.get('vulnerabilities', [])
            self.logger.info("NVD API Response Statistics: Total CVE records received: %d", len(vulnerabilities))

            if not vulnerabilities:
                self.logger.warning(
                    "ALERT: NVD API returned 0 vulnerabilities - check API connectivity or keyword match")
                return

            generated_items = 0
            skipped_items = 0

            for idx, vulnerability in enumerate(vulnerabilities, 1):
                if len(getattr(self, '_emitted_cve_ids', set())) >= self.max_cves:
                    self.logger.info(
                        "Reached max_cves limit (%d); stopping further CVE processing for this keyword response",
                        self.max_cves
                    )
                    break

                self.logger.debug("Processing CVE record %d of %d", idx, len(vulnerabilities))

                cve_no = str(vulnerability.get('cve', {}).get('id', '')).upper().strip()
                if cve_no:
                    if cve_no in getattr(self, '_emitted_cve_ids', set()):
                        self.logger.debug("Skipping duplicate CVE across keyword queries: %s", cve_no)
                        skipped_items += 1
                        continue

                try:
                    item = self.build_item_from_api_record(vulnerability)
                    if item:
                        generated_items += 1
                        if cve_no:
                            self._emitted_cve_ids.add(cve_no)
                        self.logger.info("[SUCCESS] Emitted CVE item #%d: %s", generated_items, item.get('cve_no'))
                        yield item
                    else:
                        skipped_items += 1
                        self.logger.debug("Record %d was skipped (failed validation or extraction)", idx)
                except Exception as record_exc:
                    skipped_items += 1
                    self.logger.error(
                        "Failed to build item for CVE %s from response %s: %s",
                        cve_no if cve_no else '<missing-cve-id>',
                        response.url,
                        str(record_exc)
                    )
                    self.logger.exception("Per-record exception traceback:")
                    continue

            self.logger.info("-" * 80)
            self.logger.info("PARSE_VULN_API SUMMARY:")
            self.logger.info("  Total input CVEs:     %d", len(vulnerabilities))
            self.logger.info("  Successfully emitted: %d items", generated_items)
            self.logger.info("  Skipped CVEs:         %d records", skipped_items)
            self.logger.info("  Success rate:         %.1f%%",
                             (generated_items / len(vulnerabilities) * 100) if vulnerabilities else 0)
            self.logger.info("-" * 80)

        except Exception as exc:
            self.logger.error("CRITICAL: Failed to parse Sybase vulnerability API response: %s", str(exc))
            self.logger.exception("Exception traceback:")

    def build_item_from_api_record(self, vulnerability):
        """
        Convert a single NVD vulnerability object into the project output item format.

        This method performs extensive validation and extraction:
          1. Extract CVE ID and validate non-empty
          2. Filter to Sybase ASE-relevant records only
          3. Extract vulnerability metadata (description, severity)
          4. Locate SAP note link from CVE references (stored as reference URL; not fetched)
          5. Extract affected versions: CPE data first, then description text fallback
          6. Validate all required fields are non-empty
          7. Create output item for MongoDB

        Validation Pipeline:
          - CVE ID: Must exist and be non-empty
          - Is Sybase: Must match Sybase ASE product names in description or CPE
          - Severity: Must be determinable from CVSS metrics
                    - Reference Link: Prefer SAP note URL, otherwise use best available reference/NVD link
                    - Versions: Prefer SAP note extraction, fallback to NVD description-derived versions

        Returns:
          DvmautomationItem if all validations pass, None if any validation fails
        """
        cve = vulnerability.get('cve', {})
        cve_no = str(cve.get('id', '')).upper().strip()
        if not cve_no:
            self.logger.debug("Validation failed: Record has no CVE ID")
            return None

        self.logger.debug("=" * 80)
        self.logger.info("BUILDING ITEM: Starting extraction for CVE record: %s", cve_no)
        self.logger.debug("=" * 80)

        if not self.is_sybase_ase_record(cve):
            self.logger.info("SKIP [%s]: Not a Sybase ASE-relevant record (product name mismatch)", cve_no)
            return None

        long_description = self.extract_description(cve)
        self.logger.debug("[%s] Description extracted: %s...", cve_no,
                          long_description[:100] if long_description else "<empty>")
        description_versions = self.extract_versions_from_description(cve_no, long_description)
        self.logger.debug("[%s] Description-derived versions: %d", cve_no, len(description_versions))

        severity = self.extract_api_severity(cve)
        self.logger.debug("[%s] Severity extracted: %s", cve_no, severity if severity else "<empty>")

        link_to_sap = self.extract_sap_note_link(cve)
        self.logger.debug("[%s] SAP note link extracted: %s", cve_no, link_to_sap if link_to_sap else "<not found>")
        final_link = self.build_reference_link(cve, cve_no, preferred_link=link_to_sap)
        self.logger.debug("[%s] Final reference link selected: %s", cve_no, final_link if final_link else "<not found>")

        # Primary: CPE (Common Platform Enumeration) data is already in the NVD API response —
        # structured version info with no extra HTTP request or browser session.
        # SAP note Selenium extraction is bypassed: me.sap.com requires support entitlement that
        # the configured credentials do not have, so the SAP API always returns
        # "Unable to fetch data at the moment." CPE + description give better results at no cost.
        cpe_versions = self.extract_versions_from_cpe(cve_no, cve)
        affected_version = self.normalize_affected_versions(cpe_versions) if cpe_versions else []

        if not affected_version and description_versions:
            self.logger.warning(
                "[%s] CPE extraction returned no versions; using description-derived fallback",
                cve_no
            )
            affected_version = description_versions

        self.logger.debug("[%s] Affected versions extracted: %d total", cve_no, len(affected_version))

        self.logger.info(
            "[%s] CVE Extraction Summary -> Severity: %s | SAP Link: %s | Versions: %d",
            cve_no,
            severity if severity else "<empty>",
            "FOUND" if link_to_sap else "NONE",
            len(affected_version)
        )

        if not severity:
            self.logger.warning("SKIP [%s]: Severity could not be determined from CVSS metrics", cve_no)
            return None

        if not final_link:
            self.logger.warning("SKIP [%s]: No reference link could be built for this CVE", cve_no)
            return None

        if not affected_version:
            self.logger.warning(
                "SKIP [%s]: No affected versions could be extracted from either SAP note or CVE description",
                cve_no
            )
            return None

        # All validations passed - create and populate output item
        self.logger.info("=" * 80)
        self.logger.info("PASS [%s]: All validations successful - creating output item", cve_no)
        self.logger.info("=" * 80)

        items = DvmautomationItem()
        items['long_description'] = long_description
        items['severity'] = severity
        items['cve_no'] = cve_no
        items['affected_version'] = affected_version
        items['name'] = self.name
        items['timestamp'] = strftime("%Y-%m-%d %H:%M:%S", gmtime())
        items['link'] = final_link
        items['security_fixes'] = 'Vulnerability'

        self.logger.info("[%s] FINAL ITEM: %s", cve_no, str(items))
        return items

    def is_sybase_ase_record(self, cve):
        """
        Filter to keep only Sybase ASE-relevant records.

        Filters are applied in order of reliability:
          1. Description contains "Adaptive Server Enterprise"
          2. Description contains "SAP ASE"
          3. Description contains "Sybase ASE" (e.g. multi-product CVEs like
             Progress DataDirect JDBC driver CVEs that list Sybase ASE as one
             of many affected products — NVD often has no CPE data for these)
          4. CPE Match contains "adaptive_server_enterprise" (specific product identifier)

        This filtering is critical because NVD API keyword searches return
        many false positives (other SAP products, unrelated software, etc.).

        Returns: True if record is Sybase ASE, False otherwise
        """
        self.logger.debug("FILTER: Checking if CVE is Sybase ASE-relevant")

        # Filter 1: Check description for Sybase ASE product names
        description = self.extract_description(cve).lower()
        if 'adaptive server enterprise' in description:
            self.logger.debug("FILTER MATCH: Found 'Adaptive Server Enterprise' in description")
            return True

        if 'sap ase' in description:
            self.logger.debug("FILTER MATCH: Found 'SAP ASE' in description")
            return True

        if 'sybase ase' in description:
            self.logger.debug("FILTER MATCH: Found 'Sybase ASE' in description")
            return True

        # Filter 2: Check CPE (Common Platform Enumeration) for exact product match
        self.logger.debug("FILTER: Checking CVE configurations and CPE matches")
        for config in cve.get('configurations', []):
            for node in config.get('nodes', []):
                for cpe_match in node.get('cpeMatch', []):
                    criteria = str(cpe_match.get('criteria', '')).lower()
                    if 'adaptive_server_enterprise' in criteria:
                        self.logger.debug("FILTER MATCH: Found 'adaptive_server_enterprise' in CPE criteria")
                        return True

        self.logger.debug("FILTER FAIL: CVE does not match Sybase ASE product identifiers")
        return False

    def extract_description(self, cve):
        """
        Extract vulnerability description from CVE record.

        Strategy:
          1. Prefer English descriptions for consistency with check generation
          2. Fallback to first available description if no English version exists
          3. Return empty string if no descriptions are available

        Returns: Description string or empty string
        """
        self.logger.debug("EXTRACT: Retrieving CVE description")
        descriptions = cve.get('descriptions', [])

        # Prefer English description for consistency
        for description in descriptions:
            if description.get('lang') == 'en' and description.get('value'):
                desc_text = str(description.get('value')).strip()
                self.logger.debug("EXTRACT: Found English description (%d chars)", len(desc_text))
                return desc_text

        # Fallback to first available description
        if descriptions:
            desc_text = str(descriptions[0].get('value', '')).strip()
            self.logger.debug("EXTRACT: Using first available description (lang=%s, %d chars)",
                              descriptions[0].get('lang', 'unknown'), len(desc_text))
            return desc_text

        self.logger.debug("EXTRACT: No descriptions found in CVE record")
        return ''

    def extract_api_severity(self, cve):
        """
        Extract CVSS severity from CVE metrics.

        Strategy:
          1. Search metrics for CVSS v3.1, v3.0, then v2.0 in priority order
          2. Prefer explicit baseSeverity field (e.g., "High", "Medium", "Low")
          3. Fallback to baseScore (numeric 0-10) and calculate severity bucket
          4. Return empty string if no severity metrics found

        CVSS Severity Buckets:
          - baseScore < 4.0    -> "Low"
          - baseScore 4.0-6.9  -> "Medium"
          - baseScore >= 7.0   -> "High"

        Returns: "Low" | "Medium" | "High" | ""
        """
        self.logger.debug("EXTRACT: Retrieving CVE severity from CVSS metrics")
        metrics = cve.get('metrics', {})

        # Check CVSS metrics in priority order (v3.1 -> v3.0 -> v2.0)
        for metric_key in ['cvssMetricV31', 'cvssMetricV30', 'cvssMetricV2']:
            metric_list = metrics.get(metric_key, [])
            self.logger.debug("EXTRACT: Checking %s (%d entries)", metric_key, len(metric_list))

            for metric in metric_list:
                cvss_data = metric.get('cvssData', {})

                # Try baseSeverity first (explicit severity string)
                base_severity = cvss_data.get('baseSeverity') or metric.get('baseSeverity')
                if base_severity:
                    severity = str(base_severity).title()
                    self.logger.debug("EXTRACT: Found explicit baseSeverity: %s from %s", severity, metric_key)
                    return severity

                # Fallback to baseScore (numeric CVSS score)
                base_score = cvss_data.get('baseScore')
                if base_score is not None:
                    severity = self.base_score_calculator(base_score)
                    self.logger.debug("EXTRACT: Calculated severity from baseScore %.1f -> %s", base_score, severity)
                    return severity

        self.logger.debug("EXTRACT: No CVSS metrics found in CVE record")
        return ''

    def extract_sap_note_link(self, cve):
        """
        Extract SAP Launchpad note link from CVE references.

        Why SAP Launchpad:
          - SAP note pages contain detailed affected version information
          - Versions in CVE configurations are often incomplete or incorrect
          - Launchpad notes are maintained by SAP and provide authoritative data

        Link Criteria:
          - Must contain 'launchpad.support.sap.com' domain
          - Must contain '/notes/' path (indicates SAP note URL)

        Returns: Full URL to SAP note or empty string if not found
        """
        self.logger.debug("EXTRACT: Searching CVE references for SAP Launchpad note link")

        references = self.extract_reference_urls(cve)
        self.logger.debug("EXTRACT: CVE has %d reference URLs", len(references))

        for ref_idx, url in enumerate(references):
            # Check if this is a SAP Launchpad note URL
            if 'launchpad.support.sap.com' in url and '/notes/' in url:
                self.logger.debug("EXTRACT: Found SAP Launchpad note URL at reference #%d: %s", ref_idx, url)
                return url

        for ref_idx, url in enumerate(references):
            note_match = re.search(r'(?:/notes/|[?&]note=|\b)(\d{7,10})(?:\b|$)', url, flags=re.IGNORECASE)
            if note_match and 'sap' in url.lower():
                normalized_url = 'https://launchpad.support.sap.com/#/notes/{0}'.format(note_match.group(1))
                self.logger.debug(
                    "EXTRACT: Built SAP Launchpad note URL from legacy SAP reference #%d: %s -> %s",
                    ref_idx,
                    url,
                    normalized_url
                )
                return normalized_url

        self.logger.debug("EXTRACT: No SAP Launchpad note link found in %d references", len(references))
        return ''

    def extract_reference_urls(self, cve):
        """
        Extract and normalize non-empty reference URLs from a CVE record.

        Returns: list[str]
        """
        references = cve.get('references', [])
        urls = []
        for reference in references:
            url = str(reference.get('url', '')).strip()
            if url:
                urls.append(url)
        return urls

    def build_reference_link(self, cve, cve_no, preferred_link=''):
        """
        Build the best available reference link for downstream storage/check generation.

        Preference order:
          1. Direct SAP Launchpad note link
          2. Any SAP-related reference URL
          3. First reference URL from NVD
          4. NVD detail page for the CVE itself
        """
        if preferred_link:
            return preferred_link

        references = self.extract_reference_urls(cve)
        for url in references:
            if 'sap' in url.lower():
                return url

        if references:
            return references[0]

        return nvd_base_url + cve_no

    def extract_versions_from_description(self, cve_no, long_description):
        """
        Best-effort fallback: derive affected versions from the NVD description text.

        This is used when:
          - SAP note link is missing from NVD references, or
          - SAP Launchpad login succeeds but note content never renders.
        """
        if not long_description:
            return []

        self.logger.info("[%s] Attempting description-based version extraction fallback", cve_no)
        versions = self.normalize_affected_versions([long_description])
        self.logger.info("[%s] Description-based version extraction produced %d version(s)", cve_no, len(versions))
        return versions

    def extract_versions_from_cpe(self, cve_no, cve):
        """
        Extract affected versions from NVD CPE data already present in the API response.

        CPE (Common Platform Enumeration) entries in `configurations[].nodes[].cpeMatch[]`
        contain structured version info — no additional HTTP request or browser session needed.

        CPE format: cpe:2.3:part:vendor:product:VERSION:UPDATE:edition:lang:...
        Only processes entries where vulnerable=True and product=adaptive_server_enterprise.
        Also reads versionStart/EndIncluding/Excluding range fields when the CPE version is '*'.

        Returns: list of 'SAP ASE X.Y ...' strings for normalize_affected_versions()
        """
        self.logger.info("[%s] Attempting CPE-based version extraction", cve_no)
        version_strings = []

        for config in cve.get('configurations', []):
            for node in config.get('nodes', []):
                for cpe_match in node.get('cpeMatch', []):
                    if not cpe_match.get('vulnerable', False):
                        continue
                    criteria = cpe_match.get('criteria', '')
                    if 'adaptive_server_enterprise' not in criteria.lower():
                        continue

                    parts = criteria.split(':')
                    cpe_version = parts[5] if len(parts) > 5 else '*'
                    cpe_update = parts[6] if len(parts) > 6 else '*'

                    ver_start = (cpe_match.get('versionStartIncluding') or
                                 cpe_match.get('versionStartExcluding') or '')
                    ver_end = (cpe_match.get('versionEndIncluding') or
                               cpe_match.get('versionEndExcluding') or '')

                    version_str = self._format_cpe_version(cpe_version, cpe_update, ver_start, ver_end)
                    if version_str:
                        version_strings.append(version_str)
                        self.logger.debug("[%s] CPE version extracted: %s", cve_no, version_str)

        self.logger.info("[%s] CPE extraction produced %d version string(s)", cve_no, len(version_strings))
        return version_strings

    def _format_cpe_version(self, cpe_version, cpe_update, ver_start, ver_end):
        """
        Format CPE components into a 'SAP ASE X.Y ...' string for normalize_affected_versions.

        Returns None when all fields are wildcards or contain no recognisable version number.
        """
        wildcards = ('*', '-', '')

        # Walk candidate fields in preference order to find the major version family.
        base_ver = None
        for candidate in (cpe_version, ver_start, ver_end):
            if candidate in wildcards:
                continue
            for known in ('16.0', '15.7', '15.5', '15.0.3'):
                if re.search(r'\b' + re.escape(known) + r'\b', candidate):
                    base_ver = known
                    break
            if base_ver:
                break
            # Fall back to the raw string if it looks like a version number.
            if re.match(r'^\d+\.\d+', candidate):
                base_ver = candidate
                break

        if not base_ver:
            return None

        tokens = ['SAP', 'ASE', base_ver]

        # Append SP/PL info from the CPE update field if present.
        if cpe_update not in wildcards:
            # "sp03_pl08" -> "SP03 PL08", "sp142" -> "SP142"
            tokens.append(cpe_update.upper().replace('_', ' '))

        # Append the upper end of the version range when it adds precision.
        if ver_end and ver_end != base_ver:
            tokens.extend(['up to', ver_end])

        return ' '.join(tokens)

    def base_score_calculator(self, base_score):
        """
        Convert numeric CVSS score to severity bucket used by existing pipeline.

        CVSS Score Mapping:
          - 0.0 to 3.9    -> "Low"      (Minimal impact)
          - 4.0 to 6.9    -> "Medium"   (Moderate impact)
          - 7.0 to 10.0   -> "High"     (Significant impact)

        Args:
          base_score: Numeric CVSS v2.0 or v3.x base score (0.0-10.0)

        Returns:
          "Low" | "Medium" | "High"
        """
        try:
            score_float = float(base_score)
            self.logger.debug("SCORE_CALC: Converting baseScore %.1f", score_float)

            if score_float < 4.0:
                severity = "Low"
            elif score_float < 7.0:
                severity = "Medium"
            else:
                severity = "High"

            self.logger.debug("SCORE_CALC: Mapped baseScore %.1f -> %s", score_float, severity)
            return severity

        except (ValueError, TypeError) as Ve:
            self.logger.error("SCORE_CALC: Invalid baseScore format '%s': %s", base_score, str(Ve))
            return ""

    def normalize_affected_versions(self, affected_versions):
        """
        Normalize and retain only query-relevant Sybase version signatures.

        This is a CRITICAL step: raw version strings from SAP notes contain noise,
        extra text, multiple formats, and need to be standardized.

        Processing Steps:
          1. Normalize whitespace (replace non-breaking spaces, collapse multiple spaces)
          2. Apply comprehensive regex patterns to extract version signatures:
             - "SAP ASE 15.7 SP 141" -> "SAP ASE 15.7 SP 141"
             - "SAP Adaptive Server Enterprise 15.7 SP 142" -> "SAP Adaptive Server Enterprise 15.7 SP 142"
             - "ASE 16.0 SP 3" -> "ASE 16.0 SP 3"
             - Captures anything after version number until natural delimiters (comma, semicolon, newline)
          3. Filter out unrealistic strings (>100 chars - likely HTML noise)
          4. Deduplicate and sort for consistency

        Regex Patterns (6 total for comprehensive coverage):
          1. SAP ASE 15.7[^,;\\n]* -> "SAP ASE 15.7" plus following text
          2. SAP ASE 16.0[^,;\\n]* -> "SAP ASE 16.0" plus following text
          3. SAP Adaptive Server (Enterprise) 15.7[^,;\\n]* -> Full product name 15.7
          4. SAP Adaptive Server (Enterprise) 16.0[^,;\\n]* -> Full product name 16.0
          5. ASE 15.7[^,;\\n]* -> Short product code 15.7
          6. ASE 16.0[^,;\\n]* -> Short product code 16.0

        Returns: List of deduplicated, sorted version strings
        """
        self.logger.info("=" * 80)
        self.logger.info("NORMALIZE: Processing %d raw version entries", len(affected_versions))
        self.logger.info("=" * 80)

        # Log sample of input for debugging
        if affected_versions:
            sample_input = str(affected_versions[0])[:200] if affected_versions else ""
            self.logger.debug("Sample input for normalization: %s", sample_input)

        cleaned_versions = []
        for idx, affected_version in enumerate(affected_versions):
            # Normalize whitespace: replace non-breaking space (chr 160) with regular space, collapse multiple spaces
            raw_value = re.sub(r'\s+', ' ', str(affected_version).replace(chr(160), ' ')).strip()
            if not raw_value:
                self.logger.debug("Entry %d: Skipping empty value after normalization", idx)
                continue

            self.logger.debug("Entry %d: Processing raw value: %s...", idx, raw_value[:100])

            # Comprehensive regex patterns to capture various Sybase ASE version formats
            # [^,;\\n]* = capture until comma, semicolon, or newline (natural delimiters in SAP notes)
            matches = re.findall(
                r'SAP\s+ASE\s+15\.7[^,;\n]*|'  # SAP ASE 15.7 with anything after
                r'SAP\s+ASE\s+16\.0[^,;\n]*|'  # SAP ASE 16.0 with anything after
                r'SAP\s+Adaptive\s+Server\s+(?:Enterprise\s+)?15\.7[^,;\n]*|'  # SAP Adaptive Server (Enterprise) 15.7
                r'SAP\s+Adaptive\s+Server\s+(?:Enterprise\s+)?16\.0[^,;\n]*|'  # SAP Adaptive Server (Enterprise) 16.0
                r'ASE\s+15\.7[^,;\n]*|'  # Just ASE 15.7 format
                r'ASE\s+16\.0[^,;\n]*',  # Just ASE 16.0 format
                raw_value,
                flags=re.IGNORECASE
            )

            if matches:
                self.logger.debug("Entry %d: Found %d regex matches", idx, len(matches))
                for match_idx, match in enumerate(matches):
                    # Clean up each match to extract just version info
                    cleaned_match = re.sub(r'\s+', ' ', match).strip()

                    # Keep only realistic version strings (max 100 chars - filters out HTML noise)
                    if len(cleaned_match) < 100:
                        cleaned_versions.append(cleaned_match)
                        self.logger.debug("Entry %d, Match %d: Captured version: %s", idx, match_idx + 1, cleaned_match)
                    else:
                        self.logger.debug("Entry %d, Match %d: Skipping unrealistic string (%d chars): %s...",
                                          idx, match_idx + 1, len(cleaned_match), cleaned_match[:50])
            else:
                self.logger.debug("Entry %d: No regex patterns matched", idx)

                # Description fallback: if NVD text clearly refers to Sybase ASE but does not include
                # SAP note formatting, at least recover the major affected version family.
                if any(term in raw_value.lower() for term in (
                        'adaptive server enterprise',
                        'sap ase',
                        'sybase ase',
                        'sap sybase adaptive server enterprise',
                )):
                    for base_version in ('15.0.3', '15.5', '15.7', '16.0'):
                        if re.search(r'\b{0}\b'.format(re.escape(base_version)), raw_value):
                            fallback_version = 'SAP ASE {0}'.format(base_version)
                            cleaned_versions.append(fallback_version)
                            self.logger.debug(
                                "Entry %d: Description fallback captured base version: %s",
                                idx,
                                fallback_version
                            )

        # Deduplicate and sort for consistency in output
        normalized = sorted(list(set(cleaned_versions)))

        self.logger.info("=" * 80)
        self.logger.info("NORMALIZE SUMMARY:")
        self.logger.info("  Input entries:        %d", len(affected_versions))
        self.logger.info("  Regex matches:        %d total", len(cleaned_versions))
        self.logger.info("  Unique versions:      %d (after deduplication)", len(normalized))
        self.logger.info("=" * 80)

        if normalized:
            self.logger.info("Final normalized versions:")
            for v_idx, v in enumerate(normalized, 1):
                self.logger.info("  %d. %s", v_idx, v)
        else:
            self.logger.warning("WARNING: No versions were successfully normalized!")

        return normalized

    def affected_version_processing(self, link):
        """
        Open SAP note in browser, authenticate, and parse affected version strings.

        This is the MOST CRITICAL and TIME-CONSUMING step:
          - Launches Firefox browser in headless mode
          - Authenticates to SAP Launchpad using SAP credentials
          - Navigates through account selection if required
          - Waits for page load and handles multi-step authentication
          - Extracts version information from note content
          - Returns normalized version list for check generation

        Performance:
          - Browser launch: ~2-3 seconds
          - Authentication flow: ~10-15 seconds (includes delays)
          - Page load wait: ~3-5 seconds
          - Total per CVE: ~20 seconds with Selenium delays

        Text Extraction Strategy (3-tier fallback):
          TIER 1 - Primary XPath selector: Looks for structured list elements
          TIER 2 - Fallback XPath selector: Secondary version string locations
          TIER 3 - Full page text: Most reliable but includes noise
                   Filters full page by lines containing version keywords
                   Keywords: 'SAP ASE', 'SP', 'HF', 'PL', '15.7', '16.0'

        Returns:
          - List of normalized version strings if extraction successful
          - Empty list if link is empty or extraction fails
        """
        browser = None
        try:
            if not link:
                self.logger.warning("AFFECTED-VERSION: SAP note link is empty; cannot fetch affected versions")
                self.logger.warning("AFFECTED-VERSION: This CVE will be skipped due to missing version information")
                return []

            self.logger.info("=" * 80)
            self.logger.info("AFFECTED-VERSION: Starting Selenium-based extraction")
            self.logger.info("=" * 80)
            self.logger.info("Target SAP Launchpad note: %s", link)

            delay = 20
            opts = Options()
            opts.add_argument('-headless')
            self.logger.info("AFFECTED-VERSION: Launching Firefox browser in headless mode")
            browser = webdriver.Firefox(options=opts)

            self.logger.info("AFFECTED-VERSION: Opening SAP Launchpad note URL")
            browser.get(link)
            self.logger.info("AFFECTED-VERSION: Page opened; waiting for login container (timeout: 3s)")

            # ids-login-container no longer exists on me.sap.com; use a short timeout so we
            # don't waste 20s before falling through to the j_username login flow.
            utility.wait_until_page_reloads(3, browser, 'ids-login-container')
            self.logger.info("AFFECTED-VERSION: Proceeding to credential entry")

            # Submit username
            username = browser.find_element(By.ID, "j_username")
            username.send_keys(self.user)
            self.logger.debug("AFFECTED-VERSION: Username sent")

            browser.find_element(By.XPATH, "//*[@type='submit']").click()
            self.logger.info("AFFECTED-VERSION: Username submitted; waiting for password field (timeout: %ds)", delay)

            # Wait for password field and submit password
            utility.wait_until_page_reloads(delay, browser, "j_password")
            password = browser.find_element(By.ID, "j_password")
            password.send_keys(self.passwd)
            self.logger.debug("AFFECTED-VERSION: Password sent")

            browser.find_element(By.XPATH, "//*[@type='submit']").click()
            browser.maximize_window()
            self.logger.info("AFFECTED-VERSION: Password submitted; waiting for post-login redirect")

            # Handle account selection page if present
            time.sleep(3)
            if 'accounts.sap.com' in browser.current_url:
                self.logger.info("AFFECTED-VERSION: Account selection page detected; attempting auto-select")
                for sel_idx, sel in enumerate((
                        "//button[contains(@class,'tile')]",
                        "//li//button",
                        "//button[contains(@class,'account')]",
                        "//button[@type='submit']",
                        "//button",
                ), 1):
                    try:
                        options = browser.find_elements(By.XPATH, sel)
                        if options:
                            self.logger.info("AFFECTED-VERSION: Found %d candidates using selector %d; clicking first",
                                             len(options), sel_idx)
                            options[0].click()
                            break
                    except Exception as e:
                        self.logger.debug("AFFECTED-VERSION: Selector %d failed: %s", sel_idx, str(e))
                        pass

            # Wait for successful Launchpad redirect
            # SAP migrated launchpad.support.sap.com to me.sap.com — accept either.
            reached_launchpad = False
            self.logger.info("AFFECTED-VERSION: Waiting for SAP portal redirect (max 30s)")
            for wait_iter in range(30):
                current_url = browser.current_url
                if 'launchpad.support.sap.com' in current_url or 'me.sap.com' in current_url:
                    reached_launchpad = True
                    break
                time.sleep(1)
                if wait_iter % 5 == 0:
                    self.logger.debug("AFFECTED-VERSION: Waiting... current URL: %s", current_url[:80])

            if not reached_launchpad:
                self.logger.error("AFFECTED-VERSION: Failed to reach SAP portal after 30s")
                self.logger.error("AFFECTED-VERSION: Final URL was: %s", browser.current_url)
                return []

            self.logger.info("AFFECTED-VERSION: Successfully reached SAP Launchpad note page")
            self.logger.info("AFFECTED-VERSION: Final URL: %s", browser.current_url)

            # IMPORTANT: me.sap.com is a SPA — browser.page_source only contains the static HTML
            # shell (>2000 chars of framework JS/CSS), not the JavaScript-rendered note content.
            # We must poll document.body.innerText via execute_script to read the live DOM.
            self.logger.info("AFFECTED-VERSION: Waiting for note content to render (max 45s)")
            content_ready = False
            for ready_wait in range(45):
                try:
                    rendered_text = browser.execute_script(
                        "return document.body ? document.body.innerText : '';"
                    ) or ''
                except Exception:
                    rendered_text = ''

                page_title = browser.title or ''
                has_note_hint = any(
                    hint in rendered_text for hint in (
                        'Affected Product Versions',
                        'SAP Note',
                        'Software Component',
                        'Symptom',
                        'Resolution',
                    )
                )

                # Rendered text >500 chars means meaningful content has loaded (shell is <50 chars).
                if len(rendered_text) > 500 or has_note_hint:
                    content_ready = True
                    self.logger.info(
                        "AFFECTED-VERSION: Note content detected (title='%s', rendered_text_length=%d)",
                        page_title,
                        len(rendered_text),
                    )
                    break

                if ready_wait % 5 == 0:
                    self.logger.debug(
                        "AFFECTED-VERSION: Waiting for note content... title='%s', rendered_text_length=%d",
                        page_title,
                        len(rendered_text),
                    )
                time.sleep(1)

            if not content_ready:
                self.logger.warning(
                    "AFFECTED-VERSION: Note body did not render after 45s (title='%s')",
                    browser.title,
                )

            candidate_text = []
            self.logger.info("AFFECTED-VERSION: Extracting version information from live DOM")

            # TIER 1: Live DOM — primary CSS selector for SAP note affected-version list items.
            # Uses browser.find_elements so results come from the JavaScript-rendered DOM, not
            # the static HTML snapshot that page_source/BeautifulSoup would read.
            try:
                ver_elements = browser.find_elements(By.CSS_SELECTOR, utility.get_xpath('sybase_ver'))
                self.logger.info("TIER 1 (Primary selector): Found %d live DOM nodes", len(ver_elements))
                for av_idx, el in enumerate(ver_elements):
                    value = (el.text or '').strip()
                    if value:
                        self.logger.debug("TIER 1 entry %d: %s", av_idx + 1, value[:100])
                        candidate_text.append(value)
            except Exception as e:
                self.logger.debug("TIER 1 selector failed: %s", str(e))

            # TIER 2: Live DOM — fallback CSS selector for version strings.
            try:
                ver_str_elements = browser.find_elements(By.CSS_SELECTOR, utility.get_xpath('sybase_version_str'))
                self.logger.info("TIER 2 (Fallback selector): Found %d live DOM nodes", len(ver_str_elements))
                for vs_idx, el in enumerate(ver_str_elements):
                    value = (el.text or '').strip()
                    if value:
                        self.logger.debug("TIER 2 entry %d: %s", vs_idx + 1, value[:100])
                        candidate_text.append(value)
            except Exception as e:
                self.logger.debug("TIER 2 selector failed: %s", str(e))

            # TIER 3: Full rendered page text via JavaScript — captures all dynamic content
            # that the static HTML snapshot would miss.
            try:
                full_page_text = browser.execute_script(
                    "return document.body ? document.body.innerText : '';"
                ) or ''
            except Exception:
                full_page_text = ''

            if full_page_text:
                self.logger.info("TIER 3 (Rendered DOM text): Extracted %d total characters", len(full_page_text))
                self.logger.debug("TIER 3: Page text sample (first 500 chars): %s", full_page_text[:500])

                if len(full_page_text.strip()) <= 50:
                    self.logger.warning(
                        "AFFECTED-VERSION: Rendered text is still a shell (%d chars). "
                        "Note content may require additional entitlement or a longer render wait. "
                        "title='%s', url='%s', text='%s'",
                        len(full_page_text.strip()),
                        browser.title,
                        browser.current_url,
                        full_page_text.strip(),
                    )

                lines = [line.strip() for line in full_page_text.split('\n') if line.strip()]
                self.logger.debug("TIER 3: Split into %d lines", len(lines))

                version_keywords = ['SAP ASE', 'SP', 'HF', 'PL', '15.7', '16.0']
                version_lines = [
                    line for line in lines
                    if any(kw in line.upper() for kw in version_keywords)
                ]

                if version_lines:
                    self.logger.info("TIER 3: Found %d lines containing version keywords", len(version_lines))
                    for vl_idx, line in enumerate(version_lines[:5]):
                        self.logger.debug("TIER 3 version line %d: %s", vl_idx + 1, line[:150])
                    candidate_text.extend(version_lines)
                else:
                    self.logger.info("TIER 3: No version keyword lines found — using full text as last resort")

                candidate_text.append(full_page_text)
            else:
                self.logger.warning("AFFECTED-VERSION: execute_script returned empty text for this note")

            self.logger.info("=" * 80)
            self.logger.info("AFFECTED-VERSION: Text extraction complete")
            self.logger.info("  Total candidate text entries: %d", len(candidate_text))
            self.logger.info("=" * 80)

            # Normalize and return versions
            normalized_versions = self.normalize_affected_versions(candidate_text)

            self.logger.info("=" * 80)
            self.logger.info("AFFECTED-VERSION: Extraction complete")
            self.logger.info("  Normalized version count: %d", len(normalized_versions))
            self.logger.info("=" * 80)

            return normalized_versions

        except (AttributeError, TypeError) as Ae:
            self.logger.error("AFFECTED-VERSION: Attribute/Type error during extraction: %s", str(Ae))
            self.logger.exception("AFFECTED-VERSION: Exception traceback:")
            return []

        except IndexError as Ie:
            self.logger.error("AFFECTED-VERSION: Index error during extraction: %s", str(Ie))
            self.logger.exception("AFFECTED-VERSION: Exception traceback:")
            return []

        finally:
            if browser:
                try:
                    self.logger.info("AFFECTED-VERSION: Closing browser session")
                    browser.quit()
                    self.logger.debug("AFFECTED-VERSION: Browser closed successfully")
                except Exception as e:
                    self.logger.error("AFFECTED-VERSION: Error closing browser: %s", str(e))
                    pass