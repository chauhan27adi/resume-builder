import scrapy
import re
from bs4 import BeautifulSoup as bs
from ..items import DvmautomationItem
from time import gmtime, strftime
from scrapy.spidermiddlewares.httperror import HttpError
from twisted.internet.error import DNSLookupError, TimeoutError, TCPTimedOutError
import utility
from .spider import Spider


_YEAR_URL_KEYS = [
    ('2017', 'mssql_patch_2017'),
    ('2019', 'mssql_patch_2019'),
    ('2022', 'mssql_patch_2022'),
]

# Version-string prefix patterns that identify the correct year's build table.
# SQL Server 2017=14.0.x, 2019=15.0.x, 2022=16.0.x
_YEAR_VERSION_PREFIX = {
    '2017': r'\b14\.\d+\.\d{4}\.\d',
    '2019': r'\b15\.\d+\.\d{4}\.\d',
    '2022': r'\b16\.\d+\.\d{4}\.\d',
}

# Maps marketing year to the internal major version prefix used in Microsoft build tables.
# Used to select only the correct internal version string from each row.
_YEAR_MAJOR = {'2017': '14', '2019': '15', '2022': '16'}


class CrawlMssqlPatch(Spider):
    name = 'mssql_patch'
    custom_settings = {
        'LOG_FILE': 'Crawler.log',
        'LOG_LEVEL': 'INFO',
    }

    def start_requests(self):
        for year, url_key in _YEAR_URL_KEYS:
            url = utility.get_feed_urls(url_key)
            self.logger.info('Requesting SQL Server %s build page: %s', year, url)
            yield scrapy.Request(
                url=url,
                callback=self.parse_build_page,
                errback=self.errback_httpbin,
                meta={'year': year},
                dont_filter=True,
            )

    def parse_build_page(self, response):
        year = response.meta['year']
        self.logger.info('Got response for SQL Server %s: %s', year, response.url)

        soup = bs(response.text, 'html.parser')
        ver_pattern = _YEAR_VERSION_PREFIX[year]

        # Find the CU build table by locating a <table> whose text contains the
        # expected SQL Server version prefix (14.0.x / 15.0.x / 16.0.x).
        target_table = None
        for table in soup.find_all('table'):
            if re.search(ver_pattern, table.get_text()):
                target_table = table
                break

        if target_table is None:
            self.logger.error('No build table found for SQL Server %s at %s', year, response.url)
            return

        # Determine column indices from table headers. Default 0=name, 1=build.
        name_col, build_col = 0, 1
        th_els = target_table.select('thead th') or target_table.select('tr th')
        for i, th in enumerate(th_els):
            h = th.get_text(strip=True).lower()
            if 'cumulative' in h or h in ('name', 'cu', 'update name'):
                name_col = i
            elif 'build' in h or 'version' in h:
                build_col = i

        entries = []      # ordered list of "BUILD_CUxx" strings, latest first
        current_patch = None  # (cu_label, full_version) for the most recent CU

        body_rows = target_table.select('tbody tr')
        if not body_rows:
            all_rows = target_table.select('tr')
            body_rows = all_rows[1:] if len(all_rows) > 1 else []

        for tr in body_rows:
            tds = tr.select('td')
            if not tds:
                continue

            cu_text = tds[name_col].get_text(strip=True) if len(tds) > name_col else ''
            build_text = tds[build_col].get_text(strip=True) if len(tds) > build_col else ''

            # Only keep rows that have an explicit CU number; skip RTM, GDR-only rows.
            cu_match = re.search(r'\bCU\s*(\d+)\b', cu_text, re.IGNORECASE)
            if not cu_match:
                continue

            cu_label = 'CU{}'.format(cu_match.group(1))

            # Extract the internal build version (e.g. "15.0.4420.2") using a year-specific
            # prefix so year-prefixed strings like "2022.160.43.252" are rejected ("160" != "16.").
            # Fall back to the full row text if the build column no longer contains the
            # internal format (page layout change: the version lives in another column).
            major = _YEAR_MAJOR[year]
            _internal_re = re.compile(r'\b({major}\.\d+\.(\d+)\.\d+)\b'.format(major=major))
            ver_match = _internal_re.search(build_text) or _internal_re.search(tr.get_text())
            if not ver_match:
                continue

            full_version = ver_match.group(1)
            build_short = ver_match.group(2)   # e.g. "4420"

            if current_patch is None:
                current_patch = (cu_label, full_version)

            entries.append('{}_{}'.format(build_short, cu_label))

        if not entries or current_patch is None:
            self.logger.error('No CU rows parsed for SQL Server %s', year)
            return

        cu_label, full_version = current_patch

        item = DvmautomationItem()
        # Format: "RTM:CUxx:x.x.xxxx.x"  (used by check generator for version dispatch)
        item['current_patch_version'] = 'RTM:{}:{}'.format(cu_label, full_version)
        # Format: "YEAR:RTM:BUILD_CUxx;BUILD_CUxx-1;..."  (latest CU first)
        item['affected_version'] = '{}:RTM:{}'.format(year, ';'.join(entries))
        item['name'] = self.name
        item['timestamp'] = strftime('%Y-%m-%d %H:%M:%S', gmtime())
        item['security_fixes'] = 'Patch'

        self.logger.info('SQL Server %s: cpv=%s entries=%d',
                         year, item['current_patch_version'], len(entries))
        yield item

    def errback_httpbin(self, failure):
        self.logger.error(repr(failure))
        if failure.check(HttpError):
            self.logger.error('HttpError on %s', failure.value.response.url)
        elif failure.check(DNSLookupError):
            self.logger.error('DNSLookupError on %s', failure.request.url)
        elif failure.check(TimeoutError, TCPTimedOutError):
            self.logger.error('TimeoutError on %s', failure.request.url)