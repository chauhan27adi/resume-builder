import socket
import ssl
import scrapy
from urllib.request import ProxyHandler
from urllib.request import build_opener
from urllib.request import install_opener
from urllib.request import Request
from urllib.request import urlopen as openUrl


ssl._create_default_https_context = ssl._create_unverified_context

_PROXY_HOST = "webgateway.itm.mcafee.com"
_PROXY_PORT = 9090

def _proxy_reachable():
    try:
        s = socket.create_connection((_PROXY_HOST, _PROXY_PORT), timeout=2)
        s.close()
        return True
    except (socket.timeout, OSError):
        return False


class Spider(scrapy.Spider):
    PROXIES = {
        "http": f"http://{_PROXY_HOST}:{_PROXY_PORT}",
        "https": f"http://{_PROXY_HOST}:{_PROXY_PORT}",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if _proxy_reachable():
            proxy = ProxyHandler(self.PROXIES)
            opener = build_opener(proxy)
            install_opener(opener)

    async def start(self):
        for request in self.start_requests():
            yield request

    def urlopen(self, url):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        req = Request(url, headers=headers)
        response = openUrl(req)
        return response