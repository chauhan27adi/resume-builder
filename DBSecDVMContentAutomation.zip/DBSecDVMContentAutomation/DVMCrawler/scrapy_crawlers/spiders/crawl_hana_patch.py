import json
import re
import time
import scrapy
from time import gmtime, strftime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.options import Options
from scrapy.spidermiddlewares.httperror import HttpError
from twisted.internet.error import DNSLookupError, TimeoutError, TCPTimedOutError
import utility
from ..items import DvmautomationItem
from .spider import Spider


class CrawlHanaPatch(Spider):
    name = 'hanadb_patch'
    custom_settings = {'LOG_FILE': 'Crawler.log', 'LOG_LEVEL': 'INFO'}

    with open('credentials/credentials.json', 'r') as file:
        json_content = json.loads(file.read())
        user = json_content[1]['sap_hana_username']
        passwd = json_content[1]['sap_hana_password']

    def start_requests(self):
        urls = utility.get_feed_urls('hana_patch')
        self.logger.info('HANA patch URLs: 1.0=%s  2.0=%s', urls[0], urls[1])
        yield scrapy.Request(
            url=urls[0],
            callback=self.parse,
            errback=self.errback_httpbin,
            dont_filter=True,
            meta={'hana_10_url': urls[0], 'hana_20_url': urls[1]},
        )

    def _sap_login(self, browser, url):
        """Open SAP Launchpad note URL, authenticate, and return True when ready."""
        delay = 10
        browser.get(url)
        utility.wait_until_page_reloads(delay, browser, 'ids-login-container')
        browser.find_element(By.ID, 'j_username').send_keys(self.user)
        browser.find_element(By.XPATH, "//*[@type='submit']").click()
        utility.wait_until_page_reloads(delay, browser, 'j_password')
        browser.find_element(By.ID, 'j_password').send_keys(self.passwd)
        browser.find_element(By.XPATH, "//*[@type='submit']").click()
        browser.maximize_window()
        time.sleep(3)
        # New SAP SSO flow: account picker appears after password submit.
        if 'accounts.sap.com' in browser.current_url:
            self.logger.info('SAP account picker detected; attempting first option')
            for sel in (
                "//button[contains(@class,'tile')]",
                "//li//button",
                "//button[contains(@class,'account')]",
                "//button[@type='submit']",
                "//button",
            ):
                try:
                    els = browser.find_elements(By.XPATH, sel)
                    if els:
                        els[0].click()
                        break
                except Exception:
                    pass
        for _ in range(30):
            if 'launchpad.support.sap.com' in browser.current_url or 'me.sap.com' in browser.current_url:
                self.logger.info('SAP portal reached: %s', browser.current_url)
                return True
            time.sleep(1)
        self.logger.warning('Could not reach SAP portal; current url=%s', browser.current_url)
        return False

    def _wait_for_table(self, browser, css_selector, timeout=45):
        for _ in range(timeout):
            if browser.find_elements(By.CSS_SELECTOR, css_selector):
                return True
            time.sleep(1)
        return False

    def _extract_hana_1_0(self, browser):
        """
        Extract HANA 1.0 CPV: string like '122.17' (SPS.revision).

        Scans table.myNNFV2-table rows from bottom, finds the last link whose
        text contains a dotted number (e.g. 'SPS 12 Rev 122.17'). Takes the
        last digit.digit match from the link text as the CPV string.

        Uses live DOM elements (not page_source) so it works on both server-rendered
        and SPA pages (me.sap.com renders dynamically; page_source returns only the shell).

        Generation code: re.findall(hana_version1_0, cpv)[0].split('.') gives ['122','17']
        """
        selector = utility.get_xpath('hana_patch_version1')
        if not self._wait_for_table(browser, selector):
            self.logger.warning('HANA 1.0: table %r not found within timeout', selector)
            return None
        rows = browser.find_elements(By.CSS_SELECTOR, selector)
        for row in reversed(rows):
            links = row.find_elements(By.TAG_NAME, 'a')
            for link in reversed(links):
                text = (link.text or '').strip()
                matches = re.findall(r'\d+\.\d+', text)
                if matches:
                    cpv = matches[-1]
                    self.logger.info('HANA 1.0 patch cpv: %s (from link text %r)', cpv, text)
                    return cpv
        self.logger.warning('HANA 1.0: no revision number found in table')
        return None

    def _extract_hana_2_0(self, browser):
        """
        Extract HANA 2.0 CPV: list of revision strings.

        Scans table.myNNFV2-table rows looking for:
          - An SPS 04 entry: link text containing 'SPS 04' and 'Revision X.XX'
            e.g. 'SPS 04 Revision 45.00'
          - An SPS 03 entry: link text containing 'Revision X.XX' but not 'SPS 04'
            e.g. 'Revision 38.00'

        Uses live DOM elements (not page_source) so it works on both server-rendered
        and SPA pages (me.sap.com renders dynamically; page_source returns only the shell).

        Generation code iterates the list:
          'SPS 04' in str(entry) → hana_patch_2_04.format(entry.split(' ')[-1])
          else                   → hana_patch_2_03.format(entry.split(' ')[-1])
        """
        selector = utility.get_xpath('hana_patch_version2')
        if not self._wait_for_table(browser, selector):
            self.logger.warning('HANA 2.0: table %r not found within timeout', selector)
            return None
        rows = browser.find_elements(By.CSS_SELECTOR, selector)
        sps03_entry = None
        sps04_entry = None
        for row in reversed(rows):
            links = row.find_elements(By.TAG_NAME, 'a')
            for link in reversed(links):
                text = (link.text or '').strip()
                if not re.search(r'Revision\s+\d+\.\d+', text, re.IGNORECASE):
                    continue
                if 'SPS 04' in text:
                    if sps04_entry is None:
                        sps04_entry = text
                        self.logger.info('HANA 2.0 SPS 04 entry: %r', text)
                elif sps03_entry is None:
                    sps03_entry = text
                    self.logger.info('HANA 2.0 SPS 03 entry: %r', text)
            if sps03_entry and sps04_entry:
                break
        cpv_list = [e for e in [sps03_entry, sps04_entry] if e is not None]
        if not cpv_list:
            self.logger.warning('HANA 2.0: no SPS 03/04 revision entries found in table')
        else:
            self.logger.info('HANA 2.0 patch cpv list: %s', cpv_list)
        return cpv_list if cpv_list else None

    def parse(self, response):
        hana_10_url = response.meta['hana_10_url']
        hana_20_url = response.meta['hana_20_url']
        ts = strftime('%Y-%m-%d %H:%M:%S', gmtime())
        browser = None
        try:
            opts = Options()
            opts.add_argument('-headless')
            browser = webdriver.Firefox(options=opts)

            # --- HANA 1.0 ---
            if self._sap_login(browser, hana_10_url):
                cpv_10 = self._extract_hana_1_0(browser)
                if cpv_10:
                    item = DvmautomationItem()
                    item['name'] = self.name
                    item['current_patch_version'] = cpv_10
                    item['affected_version'] = cpv_10
                    item['timestamp'] = ts
                    item['security_fixes'] = 'Patch'
                    yield item
            else:
                self.logger.error('SAP login failed for HANA 1.0 URL: %s', hana_10_url)

            # --- HANA 2.0 --- navigate to second note (session cookie still active)
            browser.get(hana_20_url)
            for _ in range(30):
                if 'launchpad.support.sap.com' in browser.current_url or 'me.sap.com' in browser.current_url:
                    break
                time.sleep(1)

            cpv_20 = self._extract_hana_2_0(browser)
            if cpv_20:
                item = DvmautomationItem()
                item['name'] = self.name
                item['current_patch_version'] = cpv_20
                item['affected_version'] = cpv_20
                item['timestamp'] = ts
                item['security_fixes'] = 'Patch'
                yield item

        except ConnectionRefusedError as err:
            self.logger.error('HANA patch: connection refused (check proxy/WebDriver): %s', str(err))
        except Exception as err:
            self.logger.error('HANA patch spider error: %s', str(err))
        finally:
            if browser:
                try:
                    browser.quit()
                except Exception:
                    pass

    def errback_httpbin(self, failure):
        self.logger.error(repr(failure))
        if failure.check(HttpError):
            self.logger.error('HttpError on %s', failure.value.response.url)
        elif failure.check(DNSLookupError):
            self.logger.error('DNSLookupError on %s', failure.request.url)
        elif failure.check(TimeoutError, TCPTimedOutError):
            self.logger.error('TimeoutError on %s', failure.request.url)