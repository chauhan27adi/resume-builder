import scrapy
import re
from bs4 import BeautifulSoup as bs
from ..items import DvmautomationItem
from time import gmtime, strftime
from scrapy.spidermiddlewares.httperror import HttpError
from twisted.internet.error import DNSLookupError, TimeoutError, TCPTimedOutError
import utility
from .spider import Spider


# Recognized MySQL families matching the static_values.json entries.
_KNOWN_FAMILIES = {'5.6', '5.7', '8.0', '8.4', '9.0'}

# Regex to find "X.Y.Z and prior" or "X.Y.Z" standalone version strings.
_VERSION_RE = re.compile(r'\b(\d+\.\d+)\.(\d+)\b')


class CrawlMysqlPatch(Spider):
    name = 'mysql_patch'
    custom_settings = {
        'LOG_FILE': 'Crawler.log',
        'LOG_LEVEL': 'INFO',
    }

    def start_requests(self):
        url = utility.get_feed_urls('mysql_patch')
        self.logger.info('Starting MySQL patch crawl: %s', url)
        yield scrapy.Request(url=url, callback=self.parse,
                             errback=self.errback_httpbin, dont_filter=True)

    def parse(self, response):
        """Navigate the Oracle security-alerts page to find the latest CPU advisory."""
        self.logger.info('Got security-alerts page: %s', response.url)
        try:
            hrefs = response.css(utility.get_xpath('mysql_payload')).extract()
            texts = response.css(utility.get_xpath('mysql_announcement')).extract()

            # Skip pre-release announcements (same logic as MySQL CVE spider).
            target_href = None
            for href, text in zip(hrefs, texts):
                if 'Announcement' not in text:
                    target_href = href
                    break

            if target_href is None:
                self.logger.warning('No published CPU advisory found on %s', response.url)
                return

            cpu_url = response.urljoin(target_href) + '#AppendixMSQL'
            yield scrapy.Request(url=cpu_url, callback=self.parse_mysql_versions,
                                 errback=self.errback_httpbin, dont_filter=True)
        except (FileNotFoundError, IndexError) as e:
            self.logger.error('Error navigating security-alerts page: %s', e)

    def parse_mysql_versions(self, response):
        """
        Extract the last-affected version per MySQL family from the CPU advisory table.

        The Oracle CPU advisory shows "X.Y.Z and prior" for each CVE. Across all MySQL
        CVEs in the bulletin, the maximum Z per family (X.Y) is the last version that
        Oracle delivered a fix for in this CPU. The check generator will use this Z to
        set the SQL patch-check threshold (Z itself, strict less-than); machines at Z are not alerted.
        """
        self.logger.info('Parsing MySQL versions from: %s', response.url)
        try:
            payloads = response.css('tbody').getall()
            pattern = utility.get_web_crawler_regex('mssql_parse_cve')

            # family -> max patch-Z seen across all MySQL CVE rows
            family_max_patch = {}

            for payload in payloads:
                if not re.search(pattern, payload):
                    continue

                soup = bs(payload, 'html.parser')
                for tr in soup.select('tr'):
                    tds = tr.select('td')
                    if not tds:
                        continue
                    if not any('mysql server' in td.get_text(strip=True).lower()
                               for td in tds):
                        continue

                    # Column 13 contains the affected version string.
                    raw = tds[13].get_text(separator='\n', strip=True) if len(tds) > 13 else ''

                    # Normalise "MySQL Server: X.Y.Z ..." prefix (July 2026+ format).
                    if 'mysql server:' in raw.lower():
                        after = re.split(r'(?i)MySQL Server:\s*', raw, maxsplit=1)
                        raw = after[1] if len(after) > 1 else raw

                    for m in _VERSION_RE.finditer(raw):
                        family = m.group(1)   # e.g. "8.0"
                        patch_z = int(m.group(2))
                        if family in _KNOWN_FAMILIES:
                            if patch_z > family_max_patch.get(family, -1):
                                family_max_patch[family] = patch_z

            if not family_max_patch:
                self.logger.warning('No MySQL version data found on %s', response.url)
                return

            ts = strftime('%Y-%m-%d %H:%M:%S', gmtime())
            for family, last_z in sorted(family_max_patch.items()):
                cpv = '{}.{}'.format(family, last_z)
                item = DvmautomationItem()
                # current_patch_version is the last-affected version (Z).
                # Check generator passes Z directly as the SQL threshold ({2});
                # the SQL uses strict less-than (< Z), so machines at Z are not alerted.
                item['current_patch_version'] = cpv
                item['affected_version'] = cpv   # mirrors cpv; not used by mysql patch generator
                item['name'] = self.name
                item['timestamp'] = ts
                item['security_fixes'] = 'Patch'
                self.logger.info('MySQL %s patch cpv: %s', family, cpv)
                yield item

        except Exception as e:
            self.logger.error('Error parsing MySQL versions: %s', e)

    def errback_httpbin(self, failure):
        self.logger.error(repr(failure))
        if failure.check(HttpError):
            self.logger.error('HttpError on %s', failure.value.response.url)
        elif failure.check(DNSLookupError):
            self.logger.error('DNSLookupError on %s', failure.request.url)
        elif failure.check(TimeoutError, TCPTimedOutError):
            self.logger.error('TimeoutError on %s', failure.request.url)