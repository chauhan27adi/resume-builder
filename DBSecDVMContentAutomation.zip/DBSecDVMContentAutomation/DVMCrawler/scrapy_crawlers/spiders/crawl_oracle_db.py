import scrapy    # to import scrapy framework
from bs4 import BeautifulSoup
import re
from ..items import DvmautomationItem
from time import gmtime, strftime
from datetime import date, timedelta
import os
import json
from scrapy.spidermiddlewares.httperror import HttpError                            # handling http related exceptions
from twisted.internet.error import DNSLookupError                                   # handling connection lost related exceptions
from twisted.internet.error import TimeoutError, TCPTimedOutError
import utility
from .spider import Spider


class CrawlOracleDb(Spider):

    name = 'oracledb'  # name of the crawler should be unique for each crawler.
    max_cves = 100
    custom_settings = {
        'LOG_FILE': 'Crawler.log',
        'LOG_LEVEL': 'INFO',
        'DOWNLOAD_TIMEOUT': 30
    }
# Start of the spider

    def start_requests(self):

        with open('credentials/urls.json', 'r') as file:  # gets Url from url.json file
            json_content = json.loads(file.read())
            # TEMPORARY (commented out, not removed): normally the single Oracle alerts index page is read from
            # urls.json and parse() then picks only the latest CPU and latest CSPU advisory links.
            # oracle_vuln = json_content['oracle_vuln']
            pass
        # TEMPORARY: one-off backfill of three specific advisories (oldest -> newest). The hardcoded list replaces
        # the index-page URL, so parse() (which discovers advisory links from the index page) cannot be used here;
        # each advisory page is sent straight to intermediate_navigate(), exactly what parse() does after it has
        # found a link (it appends '#AppendixDB' and uses callback=self.intermediate_navigate).
        oracle_vuln = list(self.TEMP_BACKFILL_ADVISORIES)
        self.logger.info('Starting Oracle vulnerability crawl (TEMPORARY hardcoded advisories): %s', oracle_vuln)
        # Original (commented out temporarily):
        # for url in (oracle_vuln,):  # sends request to open urls
        #     yield scrapy.Request(url, callback=self.parse, errback=self.errback_httpbin, dont_filter=True)
        # Previous temporary version (commented out): all three requests were fired at once, so the responses -
        # and therefore the rows inserted into SQLite - arrived in arbitrary order (a slow August page could be
        # stored after October). That makes "which advisory's row wins for a CVE listed twice" and the storage order
        # non-deterministic:
        # for url in oracle_vuln:
        #     yield scrapy.Request(url + '#AppendixDB', callback=self.intermediate_navigate,
        #                          errback=self.errback_httpbin, dont_filter=True)
        # TEMPORARY: sequential crawl. Only the first advisory is requested here; each following advisory is requested
        # by _temp_sequential_navigate / _temp_sequential_errback after the previous one has been fully processed,
        # so rows are stored strictly in the order of TEMP_BACKFILL_ADVISORIES (Aug -> Sep -> Oct).
        if oracle_vuln:
            yield self._temp_build_request(oracle_vuln)

    # TEMPORARY: advisories to backfill, oldest first. The crawl order (and thus SQLite insertion order) follows this list.
    TEMP_BACKFILL_ADVISORIES = (
        'https://www.oracle.com/security-alerts/cspuaug2026.html',
        'https://www.oracle.com/security-alerts/cspusep2026.html',
        'https://www.oracle.com/security-alerts/cpuoct2026.html',
    )

    def _temp_build_request(self, urls):
        """TEMPORARY: request for urls[0]; the rest of the list travels in meta so the chain can continue."""
        return scrapy.Request(urls[0] + '#AppendixDB', callback=self._temp_sequential_navigate,
                              errback=self._temp_sequential_errback, dont_filter=True,
                              meta={'oracle_temp_remaining': list(urls[1:])})

    def _temp_sequential_navigate(self, response):
        """TEMPORARY: run the unchanged intermediate_navigate() for this advisory, then request the next one."""
        remaining = response.meta.get('oracle_temp_remaining') or []
        try:
            yield from self.intermediate_navigate(response)
        except Exception as e:  # a failure on one advisory must not stop the remaining ones
            self.logger.error('Oracle advisory %s failed while processing: %s', response.url, str(e))
        if remaining:
            yield self._temp_build_request(remaining)

    def _temp_sequential_errback(self, failure):
        """TEMPORARY: unchanged errback_httpbin() handling, then carry on with the next advisory."""
        request = getattr(failure, 'request', None)
        if request is None and hasattr(failure.value, 'response'):
            request = failure.value.response.request
        remaining = (request.meta.get('oracle_temp_remaining') if request is not None else None) or []
        try:
            self.errback_httpbin(failure)
        except Exception as e:
            self.logger.error('errback_httpbin failed: %s', str(e))
        if remaining:
            yield self._temp_build_request(remaining)
# parser function parses the and filters out the link for latest vulnerability link.

    def parse(self, response):
        self.logger.info('Got successful response from {}'.format(response.url))
        try:
            payloads = response.xpath(utility.get_xpath("oracle_payload")).extract()
            payloads_text = response.xpath(utility.get_xpath("oracle_payload_text")).extract()
            self.logger.info('Oracle CPU advisory payloads found: %d', len(payloads))
            cpu_announced = False
            for payload in payloads[0:1]:
                if "Announcement" in (payloads_text[0]):
                    self.logger.info("Oracle Vulnerability are announced but not released:")
                    cpu_announced = True
                else:
                    actual_link = response.urljoin(payload)
                    actual_link = str(actual_link)+'#AppendixDB'
                    self.logger.info('Navigating to Oracle CPU advisory: %s', actual_link)
                    yield scrapy.Request(url=actual_link, callback=self.intermediate_navigate)

            if cpu_announced:
                self.logger.info('Skipping Oracle CSPU advisory: CPU is in announcement state')
            else:
                cspu_payloads = response.xpath(utility.get_xpath("oracle_cspu_payload")).extract()
                cspu_payloads_text = response.xpath(utility.get_xpath("oracle_cspu_payload_text")).extract()
                self.logger.info('Oracle CSPU advisory payloads found: %d', len(cspu_payloads))
                for cspu_payload in cspu_payloads[0:1]:
                    if cspu_payloads_text and "Announcement" in cspu_payloads_text[0]:
                        self.logger.info("Oracle CSPU Vulnerability are announced but not released:")
                    else:
                        cspu_link = response.urljoin(cspu_payload)
                        cspu_link = str(cspu_link) + '#AppendixDB'
                        self.logger.info('Navigating to Oracle CSPU advisory: %s', cspu_link)
                        yield scrapy.Request(url=cspu_link, callback=self.intermediate_navigate)

        except FileNotFoundError as e:
            self.logger.error('File not found Exception ' + str(e))
        except IndexError as e:
            self.logger.error('Index not in range ' + str(e))

# Function that collects all the details corresponding to the checks, it uses xpath to access the table
# where the cve, long_description, severity ,  affected_versions are published.
    def getcvelist(self, response):
        try:
            # Oracle risk matrix rows: CVE number is plain text in
            # <th class="otable-col-sticky">, NOT an anchor link.
            # Limit to the first otable-sticky div after AppendixDB so we only
            # collect Oracle Database CVEs, not every product on the page.
            cve_rows = response.xpath(
                '//*[@id="AppendixDB"]'
                '/following::div[contains(@class,"otable-sticky")][1]'
                '//tr[th[contains(@class,"otable-col-sticky") and contains(text(),"CVE-")]]'
            ).extract()
            if cve_rows:
                self.logger.info('Oracle DB risk matrix rows found: %d', len(cve_rows))
                return cve_rows

            self.logger.warning(
                'Oracle DB risk matrix not found under #AppendixDB at %s; '
                'returning no rows to avoid capturing CVEs from other products',
                response.url
            )
            return []
        except IndexError as Ie:
            self.logger.error(str(Ie))
            return []

    def intermediate_navigate(self, response):
        cve_no_lists = self.getcvelist(response)
        self.logger.info('Oracle CVE table rows found: %d from %s', len(cve_no_lists), response.url)
        self.logger.info('Oracle CVE limit: emitting up to %d CVEs (page order)', self.max_cves)
        count = 0
        date_nodes = response.xpath(utility.get_xpath("oracle_initial_mod_date")).extract()
        initial_mod_date = date_nodes[-2] if len(date_nodes) >= 2 else ''
        if initial_mod_date:
            self.logger.info('Oracle initial_mod_date from page xpath: %s', initial_mod_date)
        if not initial_mod_date:
            initial_mod_date = self._derive_mod_date_from_url(response.url)
        self.logger.info('Oracle initial_mod_date: %s', initial_mod_date)
        if len(cve_no_lists) > self.max_cves:
            self.logger.info('Oracle CVE rows capped: %d found, emitting first %d', len(cve_no_lists), self.max_cves)
        col_indices = self._get_column_indices(response)
        component_col_idx = col_indices['component']
        base_score_col_idx = col_indices['base_score']
        protocol_col_idx = col_indices['protocol']
        for i in cve_no_lists[:self.max_cves]:
            try:
                # CVE number is plain text in <th class="otable-col-sticky">.
                # Search the raw row HTML directly — no anchor link present.
                cve_nos = list(dict.fromkeys(re.findall(r'CVE-\d+-\d+', i)))
                if not cve_nos:
                    self.logger.warning('No CVE pattern in row: %.300s', i)
                    continue

                parsed_html1 = BeautifulSoup(i, "html.parser")
                # CVE# is in <th>; all data columns are <td>. Both component_col_idx
                # and base_score_col_idx are resolved from the table header by
                # _get_column_indices() — adapts automatically if Oracle adds columns.
                # Rowspan row (Product absent, 1 fewer td): subtract 1 from each index.
                td_cells = parsed_html1.select('td')
                self.logger.info('Oracle row td count: %d for %s', len(td_cells), cve_nos)
                if len(td_cells) >= 15:
                    component = td_cells[component_col_idx].text.strip() if component_col_idx < len(td_cells) else ''
                    base_score = td_cells[base_score_col_idx].text.strip() if base_score_col_idx < len(td_cells) else ''
                    protocol = td_cells[protocol_col_idx].text.strip() if protocol_col_idx < len(td_cells) else ''
                elif len(td_cells) == 14:
                    rowspan_comp = component_col_idx - 1
                    rowspan_score = base_score_col_idx - 1
                    rowspan_proto = protocol_col_idx - 1
                    component = td_cells[rowspan_comp].text.strip() if 0 <= rowspan_comp < len(td_cells) else ''
                    base_score = td_cells[rowspan_score].text.strip() if 0 <= rowspan_score < len(td_cells) else ''
                    protocol = td_cells[rowspan_proto].text.strip() if 0 <= rowspan_proto < len(td_cells) else ''
                else:
                    rowspan_score = base_score_col_idx - 1
                    rowspan_proto = protocol_col_idx - 1
                    component = ''
                    base_score = td_cells[rowspan_score].text.strip() if 0 <= rowspan_score < len(td_cells) else ''
                    protocol = td_cells[rowspan_proto].text.strip() if 0 <= rowspan_proto < len(td_cells) else ''
                affected_version = td_cells[-2].text.strip() if len(td_cells) >= 2 else ''
                severity = self.base_score_calculator(base_score)
                self.logger.info('Oracle base_score: %s -> severity: %s for %s', base_score, severity, cve_nos)

                for cve_no in cve_nos:
                    long_description = ''
                    try:
                        details_url = utility.get_feed_urls("cve_org_api_uri") + cve_no
                        self.logger.info('Fetching CVE.org description for %s', cve_no)
                        url_object = self.urlopen(details_url)
                        data = json.loads(url_object.read())
                        descriptions = data.get('containers', {}).get('cna', {}).get('descriptions', [])
                        long_description = next(
                            (d['value'] for d in descriptions if d.get('lang', '').startswith('en')), ''
                        )
                        if long_description:
                            self.logger.info('Description fetched for %s from CVE.org (%d chars)', cve_no, len(long_description))
                    except Exception as desc_err:
                        self.logger.warning('Could not fetch description for %s from CVE.org API: %s', cve_no, str(desc_err))
                    if not long_description:
                        self.logger.info('CVE.org returned no description for %s — trying page-based fallback', cve_no)
                        updated = self.get_longdescription('', cve_no, response)
                        if updated:
                            long_description = updated
                    if not long_description:
                        self.logger.info(
                            'No public description for %s — CVE likely RESERVED on CVE.org', cve_no
                        )
                    items = DvmautomationItem()
                    count += 1
                    items['long_description'] = long_description
                    items['severity'] = severity
                    items['cve_no'] = cve_no
                    items['affected_version'] = affected_version
                    items['name'] = CrawlOracleDb.name
                    items['link'] = response.url
                    items['timestamp'] = strftime("%Y-%m-%d %H:%M:%S", gmtime())
                    items['security_fixes'] = 'Vulnerability'
                    items['component'] = component
                    items['protocol'] = protocol
                    items['initial_mod_date'] = initial_mod_date
                    items['count'] = count
                    self.logger.info("Checks\n" + str(items))
                    yield items
            except Exception as e:
                self.logger.error(f"Error processing Oracle CVE row: {str(e)}")
                continue

    def get_longdescription(self, long_description, cve_no, response):
        self.logger.info('Trying page-based description fallback for %s', cve_no)
        try:
            des = []
            if response.xpath(utility.get_xpath("oracle_description")).extract():
                self.logger.info('Using primary oracle_description xpath for %s', cve_no)
                detail_url = response.xpath(
                    utility.get_xpath("oracle_description")).extract()
                detail_url = response.urljoin(detail_url[0])
                self.logger.info('Fetching Oracle description detail page: %s', detail_url)
                obj1 = self.urlopen(detail_url)
                soup = BeautifulSoup(obj1, 'html.parser')
                for i in soup.find_all('tr'):
                    if cve_no in str(i):
                        b = i.text
                        des.append(re.findall(r'Vulnerability.+|Security-in-Depth.+', b)[0])
                if des:
                    long_description = des[0]
                    self.logger.info('Description found for %s via primary page fallback', cve_no)
                else:
                    self.logger.info('No matching description row in primary detail page for %s', cve_no)
            elif response.xpath(utility.get_xpath("oracle_description_alternate")):
                self.logger.info('Using alternate oracle_description_alternate xpath for %s', cve_no)
                detail_url = (response.xpath(
                    utility.get_xpath("oracle_detail_url_desc")).extract())
                detail_url = response.urljoin(detail_url[0])
                self.logger.info('Fetching Oracle alternate description detail page: %s', detail_url)
                obj1 = self.urlopen(detail_url)
                soup = BeautifulSoup(obj1, 'html.parser')
                for i in soup.find_all('tr'):
                    if cve_no in str(i):
                        b = i.text
                        des.append(re.findall(r'Vulnerability.+', b)[0])
                if des:
                    long_description = des[0]
                    self.logger.info('Description found for %s via alternate page fallback', cve_no)
                else:
                    self.logger.info('No matching description row in alternate detail page for %s', cve_no)
            else:
                self.logger.info('No oracle_description xpath matched for %s — returning empty', cve_no)
        except Exception as Ex:
            self.logger.error(str(Ex))
        return long_description

    def base_score_calculator(self, base_score):
        try:
            score = float(base_score)
        except (ValueError, TypeError):
            self.logger.warning('Unable to parse Oracle base score: %r; returning Unknown', base_score)
            return "Unknown"
        if score < 4.0:
            severity = "Low"
        elif 4.0 <= score < 7.0:
            severity = "Medium"
        else:
            severity = "High"
        self.logger.debug('Oracle score %.1f -> %s', score, severity)
        return severity


    def _derive_mod_date_from_url(self, url):
        """Derive Oracle advisory date from URL pattern c(s)pu{mon}{year}.html → 'YYYY-Mon-DD'.

        Matches both CPU (cpujul2026.html) and CSPU (cspuaug2026.html) URL patterns.
        Used as a fallback when the page metadata table xpath returns nothing.
        """
        try:
            match = re.search(r'c(?:pu|spu)([a-z]+)(\d{4})\.html', url, re.IGNORECASE)
            if not match:
                self.logger.warning('Could not parse advisory month/year from URL: %s', url)
                return ''
            month_str = match.group(1).lower()
            year_int = int(match.group(2))
            month_map = {
                'jan': (1, 'Jan'), 'feb': (2, 'Feb'), 'mar': (3, 'Mar'),
                'apr': (4, 'Apr'), 'may': (5, 'May'), 'jun': (6, 'Jun'),
                'jul': (7, 'Jul'), 'aug': (8, 'Aug'), 'sep': (9, 'Sep'),
                'oct': (10, 'Oct'), 'nov': (11, 'Nov'), 'dec': (12, 'Dec'),
            }
            if month_str not in month_map:
                self.logger.warning('Unrecognised month %r in Oracle URL: %s', month_str, url)
                return ''
            month_num, month_abbr = month_map[month_str]
            first_day = date(year_int, month_num, 1)
            # weekday(): Mon=0, Tue=1, ..., Sun=6
            days_to_first_tuesday = (1 - first_day.weekday()) % 7
            third_tuesday = first_day + timedelta(days=days_to_first_tuesday + 14)
            derived = f"{year_int}-{month_abbr}-{third_tuesday.day:02d}"
            self.logger.info('Derived Oracle mod_date from advisory URL: %s', derived)
            return derived
        except Exception as e:
            self.logger.warning('Could not derive mod_date from URL %s: %s', url, str(e))
            return ''

    def _get_column_indices(self, response):
        base_xpath = (
            '//*[@id="AppendixDB"]'
            '/following::div[contains(@class,"otable-sticky")][1]'
        )
        header_ths = response.xpath(base_xpath + '//thead//th').getall()
        if not header_ths:
            header_ths = response.xpath(base_xpath + '//tr[1]//th').getall()

        defaults = {'component': 1, 'base_score': 4, 'protocol': 2}

        if not header_ths:
            self.logger.warning(
                'Oracle DB risk matrix header not found; using default column indices %s', defaults
            )
            return defaults

        # th[0] is the CVE# sticky column — subtract 1 to align th position with td index
        header_map = {
            BeautifulSoup(h, 'html.parser').get_text(strip=True).lower(): i - 1
            for i, h in enumerate(header_ths)
        }
        self.logger.info('Oracle risk matrix column map: %s', header_map)

        result = {}

        if 'component' in header_map:
            result['component'] = header_map['component']
            self.logger.info('Oracle risk matrix: Component -> td[%d]', result['component'])
        else:
            result['component'] = defaults['component']
            self.logger.warning(
                'Component header not found in Oracle risk matrix; defaulting to td[%d]',
                defaults['component']
            )

        # Base Score is always at td[4]. Oracle's two-row thead structure (group header
        # row + sub-header row) makes header-based resolution unreliable for this column.
        result['base_score'] = defaults['base_score']
        self.logger.info('Oracle risk matrix: Base Score -> td[%d] (fixed index)', result['base_score'])

        if 'protocol' in header_map:
            result['protocol'] = header_map['protocol']
            self.logger.info('Oracle risk matrix: Protocol -> td[%d]', result['protocol'])
        else:
            result['protocol'] = defaults['protocol']
            self.logger.warning(
                'Protocol header not found in Oracle risk matrix; defaulting to td[%d]',
                defaults['protocol']
            )

        return result

    def errback_httpbin(self, failure):  # catching exception of parser.
        # log all failures

        obj = self.temp_files(self.name)
        self.logger.error(repr(failure))

        # in case you want to do something special for some errors,
        # you may need the failure's type:

        if failure.check(HttpError):  # catches any http errors like like invalid urls
            # these exceptions come from HttpError spider middleware
            # you can get the non-200 response
            response = failure.value.response
            self.logger.error('HttpError on %s', response.url)  # logging errors in console
            with open(obj, 'w') as file:
                file.write('HttpError' + ' Error Code 101')  # writting the error code and error message to log files

        elif failure.check(DNSLookupError):  # catches connection lost exceptions
            # this is the original request
            request = failure.request

            self.logger.error('DNSLookupError on %s', request.url)  # logging errors in console
            with open(obj, 'w') as file:
                file.write('DNSLookupError' + ' Error Code 102')  # writting the error code and error message to log files

        elif failure.check(TimeoutError, TCPTimedOutError):  # catches timeout exceptions
            request = failure.request
            self.logger.error('TimeoutError on %s', request.url)  # logging errors in console
            with open(obj, 'w') as file:
                file.write('TimeoutError' + ' Error Code 103')  # writting the error code and error message to log files

    @classmethod
    def temp_files(cls, name):  # logic for creating tem files
        file_name = ''
        if os.path.exists(os.getcwd()):
            if os.path.isdir(os.path.join(os.getcwd(), name)):
                filepath = os.path.join(os.getcwd(), name)
                file_name = os.path.join(filepath, name) + '.log'
            else:
                os.makedirs(name)
                filepath = os.path.join(os.getcwd(), name)
                with open(os.path.join(filepath, name) + '.log', 'w') as file:
                    file_name = os.path.join(filepath, name) + '.log'
                    file.close()
        return file_name