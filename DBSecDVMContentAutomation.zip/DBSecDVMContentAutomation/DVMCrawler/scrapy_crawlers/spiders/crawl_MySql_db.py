import scrapy                                                                       # to import scrapy framework
from bs4 import BeautifulSoup as bs                                                 # for parsing html contents                                                               # for dealing with os related operations like creating directory or file
import os                                                     # creating an instance of timestamp
from ..items import DvmautomationItem                                               # creates a container like to store the output.
import re
from time import gmtime, strftime
from scrapy.spidermiddlewares.httperror import HttpError                            # handling http related exceptions
from twisted.internet.error import DNSLookupError                                   # handling connection lost related exceptions
from twisted.internet.error import TimeoutError, TCPTimedOutError
import utility
from .spider import Spider


class CrawlMySqlDb(Spider):

    name = 'mysqldb'                                        # name of the spider
    # Configurable limit for number of most recent CVEs to fetch
    max_cves = 100
    custom_settings = {
        'LOG_FILE': 'Crawler.log',                          # log file location
        'LOG_LEVEL': 'INFO',
    }

# This is the first function which gets called once the spider start crawling
    def start_requests(self):
        mysql_vuln = utility.get_feed_urls('mysql_vuln')
        self.logger.info('Starting MySQL vulnerability crawl: %s', mysql_vuln)
        for url in [mysql_vuln]:
            yield scrapy.Request(url, callback=self.parse, errback=self.errback_httpbin, dont_filter=True)

    def parse(self, response):
        self.logger.info('Got successful response from {}'.format(response.url))
        try:
            hrefs = response.css(utility.get_xpath("mysql_payload")).extract()
            texts = response.css(utility.get_xpath("mysql_announcement")).extract()

            # Walk the list to find the first published (non-pre-release) CPU advisory.
            # Oracle prepends a "Pre-Release Announcement" entry several weeks before each
            # quarterly CPU is released; skipping it ensures we always land on real data.
            target_href = None
            for href, text in zip(hrefs, texts):
                if "Announcement" not in text:
                    target_href = href
                    break

            if target_href is None:
                self.logger.info("No published CPU advisory found (only pre-release announcements listed).")
            else:
                actual_link = response.urljoin(target_href) + '#AppendixMSQL'
                yield scrapy.Request(url=actual_link, callback=self.intermediate_navigate)

        except FileNotFoundError as e:
            self.logger.error('File not found Exception ' + str(e))
        except IndexError as e:
            self.logger.error('Index not in range ' + str(e))

    def intermediate_navigate(self, response):
        try:
            payloads = response.css("tbody").getall()
            pattern = utility.get_web_crawler_regex("mssql_parse_cve")
            month_year = (response.url.split('/')[-1].replace(".html", ""))

            # Collect all CVE items first, then limit to max_cves
            cve_items = []
            for payload in payloads:  # process all tbody elements
                # skip entire tbody quickly if it doesn't match the expected CVE pattern
                if not re.search(pattern, payload):
                    continue

                soup = bs(payload, "html.parser")

                for tr in soup.select("tr"):
                    tds = tr.select("td")
                    if not tds:
                        continue

                    # accept row if any cell contains "MySQL Server" (handles both
                    # "MySQL Server" alone and "MySQL Server, MySQL Cluster" combined cells)
                    if not any("mysql server" in td.get_text(strip=True).lower() for td in tds):
                            continue

                    # safe per-row extraction
                    cve_node = tr.select_one(utility.get_xpath("mysql_cve_list"))
                    cve_no = cve_node.get_text(strip=True) if cve_node else ""
                    if not cve_no:
                        # skip rows without a CVE identifier
                        continue

                    severity_raw = tds[4].get_text(strip=True) if len(tds) > 4 else ""
                    raw_version = tds[13].get_text(separator='\n', strip=True) if len(tds) > 13 else ""
                    affected_version = CrawlMySqlDb._extract_mysql_server_version(raw_version)

                    # get long description from verbose page
                    relative_link = response.urljoin(f"{month_year}verbose.html#MSQL")
                    long_description = self.get_long_description(cve_no, relative_link) or ""
                    long_description = re.sub(r"[\n\t\r]", "",
                                              long_description.split("CVSS")[0]) if long_description else ""

                    # Oracle's verbose advisory page uses per-CVE anchors in the format
                    # cpuYYYYMMverbose.html#MSQL-CVE-YYYY-NNNNN, giving a direct link to
                    # the exact row for this CVE rather than the top of the advisory page.
                    per_cve_link = response.urljoin(f"{month_year}verbose.html#MSQL-{cve_no}")

                    items = DvmautomationItem()
                    items['long_description'] = long_description
                    items['severity'] = self.severity_to_string(severity_raw)
                    items['link'] = per_cve_link
                    items['cve_no'] = cve_no
                    items['affected_version'] = affected_version
                    items['security_fixes'] = 'Vulnerability'
                    items['name'] = self.name
                    items['timestamp'] = strftime("%Y-%m-%d %H:%M:%S", gmtime())

                    cve_items.append(items)

            self.logger.info('MySQL CVEs collected: %d total, emitting up to %d (page order)', len(cve_items), self.max_cves)
            for item in cve_items[:self.max_cves]:
                self.logger.info("Checks %s", item)
                yield item

        except (IndexError, AttributeError, Exception) as Ie:
            self.logger.error("Error in intermediate_navigate: %s", Ie)

    def get_long_description(self, cve_no, url):
        self.logger.debug('Fetching long description for %s from: %s', cve_no, url)
        try:
            response = self.urlopen(url)
            soup = bs(response, 'html.parser')
            payloads = soup.select("tbody")
            for payload in payloads:
                if cve_no in str(payload) and "MySQL" in str(payload):
                    # Each iteration variable is a <tr> element (not <td> — renamed to tr_elem
                    # for clarity). Index accesses are guarded to skip header/colspan rows that
                    # have fewer than 2 <td> children; without the guard an IndexError from any
                    # single short row would abort the entire list comprehension and wipe out the
                    # long description for this CVE.
                    long_description_list = [
                        tr_elem.select('td')[1].text.replace("\n", "")
                        for tr_elem in payload.select("tr")
                        if len(tr_elem.select('td')) > 1
                    ]

                    if not long_description_list:
                        long_description_list = [
                            tr_elem.select('td p')[1].text
                            for tr_elem in payload.select("tr")
                            if len(tr_elem.select('td p')) > 1
                        ]
                    cve_list = [
                        tr_elem.select('td')[0].text.replace("\n", "")
                        for tr_elem in payload.select("tr")
                        if tr_elem.select('td')
                    ]

                    if not cve_list:
                        cve_list = [
                            tr_elem.select('td p')[0].text
                            for tr_elem in payload.select("tr")
                            if tr_elem.select('td p')
                        ]

                    details = list(zip(cve_list, long_description_list))
                    for cve, long_description in details:
                        if cve == cve_no:
                            return long_description
        except (IndexError, AttributeError) as Ie:
            self.logger.error("Error in either fetching CVE list or Description list" + str(Ie))

    def temp_files(self, name):                # logic for creating tem files
        file_name = ''
        if os.path.isdir(os.path.join(os.getcwd(), name)):
            filepath = os.path.join(os.getcwd(), name)
            file_name = os.path.join(filepath, name) + '.log'
        else:
            os.makedirs(name)
            filepath = os.path.join(os.getcwd(), name)
            with open(os.path.join(filepath, name) + '.log', 'w') as file:
                file_name = os.path.join(filepath, name) + '.log'
        return file_name

    @staticmethod
    def _extract_mysql_server_version(cell_text: str) -> str:
        if "mysql server:" not in cell_text.lower():
            return cell_text
        after = re.split(r'(?i)MySQL Server:\s*', cell_text, maxsplit=1)[1]
        return re.split(r'(?:\n|;)\s*[A-Z][A-Za-z ]+:', after)[0].strip()

    def errback_httpbin(self, failure):  # catching exception of parser.
        # log all failures
        obj = self.temp_files(self.name)
        self.logger.error(repr(failure))

        # in case you want to do something special for some errors,
        # you may need the failure's type:

        if failure.check(HttpError):  # catches any http errors like like invalid urls
            # these exceptions come from HttpError spider middleware
            # you can get the non-200 response
            response = failure.value.response
            self.logger.error('HttpError on %s', response.url)  # logging errors in console
            with open(obj, 'w') as file:
                file.write('HttpError' + ' Error Code 101')  # writing the error code and error message to log files

        elif failure.check(DNSLookupError):  # catches connection lost exceptions
            # this is the original request
            request = failure.request

            self.logger.error('DNSLookupError on %s', request.url)  # logging errors in console
            with open(obj, 'w') as file:
                file.write('DNSLookupError' + ' Error Code 102')  # writing the error code and error message to log files

        elif failure.check(TimeoutError, TCPTimedOutError):  # catches timeout exceptions
            request = failure.request
            self.logger.error('TimeoutError on %s', request.url)  # logging errors in console
            with open(obj, 'w') as file:
                file.write('TimeoutError' + ' Error Code 103')  # writing the error code and error message to log files

    @staticmethod
    def severity_to_string(base_score):
        try:
            score = float(base_score)
            if score < 4.0:
                return "Low"
            elif score < 7.0:
                return "Medium"
            elif score < 9.0:
                return "High"
            else:
                return "High"
        except (ValueError, TypeError):
            return "Unknown"