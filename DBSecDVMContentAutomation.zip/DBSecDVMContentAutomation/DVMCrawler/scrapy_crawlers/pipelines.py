import json
import sqlite3
import os
import logging

_DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'cve_data.db')
_CRED_PATH = os.path.join(os.path.dirname(__file__), '..', 'credentials', 'credentials.json')
_logger = logging.getLogger(__name__)


def _load_mongo_creds():
    with open(_CRED_PATH) as f:
        creds = json.load(f)
    return creds[2]['mongo_db_uri'], int(creds[2]['mongo_db_port'])


class DvmautomationPipeline:

    @classmethod
    def from_crawler(cls, crawler):
        o = cls()
        o.crawler = crawler
        return o

    def open_spider(self, spider):
        backend = self.crawler.settings.get('STORAGE_BACKEND', 'sqlite').lower()
        self.use_sqlite = backend in ('sqlite', 'both')
        self.use_mongo = backend in ('mongodb', 'both')

        self._sqlite_conn = None
        self._sqlite_migrated_tables = set()
        self._mongo_client = None
        self._mongo_db = None
        self._mongo_cols_init = set()

        if self.use_sqlite:
            self._sqlite_conn = sqlite3.connect(_DB_PATH, check_same_thread=False)

        if self.use_mongo:
            from pymongo import MongoClient
            uri, port = _load_mongo_creds()
            self._mongo_client = MongoClient(uri, port)
            self._mongo_db = self._mongo_client['output_web_crawler_details']

        _logger.info(
            'DvmautomationPipeline: storage backend=%s (sqlite=%s, mongo=%s)',
            backend, self.use_sqlite, self.use_mongo,
        )

    def _ensure_sqlite_table(self, table_name):
        self._sqlite_conn.execute(f'''
            CREATE TABLE IF NOT EXISTS "{table_name}" (
                cve_no TEXT PRIMARY KEY,
                severity TEXT,
                affected_version TEXT,
                long_description TEXT,
                name TEXT,
                timestamp TEXT,
                security_fixes TEXT,
                link TEXT,
                reported INTEGER DEFAULT 0,
                "Progress" TEXT DEFAULT NULL,
                check_generation_timestamp TEXT DEFAULT NULL,
                component TEXT,
                initial_mod_date TEXT,
                protocol TEXT,
                count INTEGER
            )
        ''')
        # Migrate tables created before these columns were added (once per table per session)
        if table_name not in self._sqlite_migrated_tables:
            for col, definition in [
                ('"Progress"', 'TEXT DEFAULT NULL'),
                ('check_generation_timestamp', 'TEXT DEFAULT NULL'),
            ]:
                try:
                    self._sqlite_conn.execute(f'ALTER TABLE "{table_name}" ADD COLUMN {col} {definition}')
                except sqlite3.OperationalError:
                    pass  # column already exists
            self._sqlite_migrated_tables.add(table_name)
        self._sqlite_conn.commit()

    def _ensure_mongo_collection(self, col_name):
        if col_name not in self._mongo_cols_init:
            self._mongo_db[col_name].create_index('cve_no', unique=True)
            self._mongo_cols_init.add(col_name)

    def _ensure_sqlite_patch_table(self, table_name):
        self._sqlite_conn.execute(f'''
            CREATE TABLE IF NOT EXISTS "{table_name}" (
                current_patch_version TEXT PRIMARY KEY,
                affected_version TEXT,
                name TEXT,
                timestamp TEXT,
                security_fixes TEXT,
                "Progress" TEXT DEFAULT NULL,
                check_generation_timestamp TEXT DEFAULT NULL
            )
        ''')
        self._sqlite_conn.commit()

    def _ensure_mongo_patch_collection(self, col_name):
        patch_key = col_name + '__patch'
        if patch_key not in self._mongo_cols_init:
            self._mongo_db[col_name].create_index('current_patch_version', unique=True)
            self._mongo_cols_init.add(patch_key)

    def process_item(self, item, spider):
        sf = item.get('security_fixes')

        if sf == 'Vulnerability':
            table = item.get('name')
            if not table:
                _logger.error(
                    'process_item: item missing "name" field; dropping item: %s', dict(item)
                )
                return item
            affected = item.get('affected_version')
            if not isinstance(affected, str):
                if affected is None:
                    _logger.warning(
                        'process_item: affected_version is None for cve_no=%s; storing as null string',
                        item.get('cve_no'),
                    )
                affected = json.dumps(affected)

            if self.use_sqlite:
                self._ensure_sqlite_table(table)
                self._sqlite_conn.execute(
                    f'''INSERT OR IGNORE INTO "{table}"
                        (cve_no, severity, affected_version, long_description,
                         name, timestamp, security_fixes, link, reported,
                         component, initial_mod_date, protocol, count)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?)''',
                    (
                        item.get('cve_no'), item.get('severity'),
                        affected, item.get('long_description'),
                        item.get('name'), item.get('timestamp'),
                        item.get('security_fixes'), item.get('link'),
                        item.get('component'), item.get('initial_mod_date'),
                        item.get('protocol'), item.get('count'),
                    )
                )
                self._sqlite_conn.commit()

            if self.use_mongo:
                self._ensure_mongo_collection(table)
                doc = {
                    'cve_no': item.get('cve_no'),
                    'severity': item.get('severity'),
                    'affected_version': affected,
                    'long_description': item.get('long_description'),
                    'name': item.get('name'),
                    'timestamp': item.get('timestamp'),
                    'security_fixes': item.get('security_fixes'),
                    'link': item.get('link'),
                    'reported': 0,
                    'component': item.get('component'),
                    'initial_mod_date': item.get('initial_mod_date'),
                    'protocol': item.get('protocol'),
                    'count': item.get('count'),
                }
                self._mongo_db[table].update_one(
                    {'cve_no': doc['cve_no']},
                    {'$setOnInsert': doc},
                    upsert=True,
                )

        elif sf == 'Patch':
            table = item.get('name')
            if not table:
                _logger.error(
                    'process_item: item missing "name" field; dropping item: %s', dict(item)
                )
                return item
            cpv = item.get('current_patch_version')
            if not isinstance(cpv, str):
                if cpv is None:
                    _logger.warning(
                        'process_item: current_patch_version is None for name=%s; storing as null string',
                        item.get('name'),
                    )
                cpv = json.dumps(cpv)
            affected = item.get('affected_version')
            if not isinstance(affected, str):
                if affected is None:
                    _logger.warning(
                        'process_item: affected_version is None for name=%s; storing as null string',
                        item.get('name'),
                    )
                affected = json.dumps(affected)

            if self.use_sqlite:
                self._ensure_sqlite_patch_table(table)
                self._sqlite_conn.execute(
                    f'INSERT OR IGNORE INTO "{table}" '
                    '(current_patch_version, affected_version, name, timestamp, security_fixes) '
                    'VALUES (?, ?, ?, ?, ?)',
                    (cpv, affected, item.get('name'), item.get('timestamp'), sf)
                )
                self._sqlite_conn.commit()

            if self.use_mongo:
                self._ensure_mongo_patch_collection(table)
                doc = {
                    'current_patch_version': cpv,
                    'affected_version': affected,
                    'name': item.get('name'),
                    'timestamp': item.get('timestamp'),
                    'security_fixes': sf,
                }
                self._mongo_db[table].update_one(
                    {'current_patch_version': cpv},
                    {'$setOnInsert': doc},
                    upsert=True,
                )

        else:
            _logger.error(
                'process_item: unrecognised security_fixes value %r for item name=%s; item not stored',
                sf, item.get('name'),
            )

        return item

    def close_spider(self, spider):
        if self._sqlite_conn:
            self._sqlite_conn.close()
        if self._mongo_client:
            self._mongo_client.close()