import socket

_PROXY_URL = "http://webgateway.itm.mcafee.com:9090"
_proxy_ok = None


def _proxy_reachable():
    global _proxy_ok
    if _proxy_ok is None:
        try:
            s = socket.create_connection(("webgateway.itm.mcafee.com", 9090), timeout=2)
            s.close()
            _proxy_ok = True
        except (socket.timeout, OSError):
            _proxy_ok = False
    return _proxy_ok


class CustomProxyMiddleware(object):
    @classmethod
    def from_crawler(cls, crawler):
        return cls()

    def process_request(self, request):
        if _proxy_reachable():
            request.meta["proxy"] = _PROXY_URL