import os
import json
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException


def get_xpath(keys):
    with open(os.path.join(os.path.dirname(__file__), 'credentials', 'database_xpaths.json'), 'r') as file:
        value = json.loads(file.read())
        return value[keys]


def get_feed_urls(keys):
    with open(os.path.join(os.path.dirname(__file__), 'credentials', 'urls.json'), 'r') as file:
        value = json.loads(file.read())
        return value[keys]


def get_web_crawler_regex(keys):
    with open(os.path.join(os.path.dirname(__file__), 'credentials', 'web_crawler_regex.json'), 'r') as file:
        value = json.loads(file.read())
        return value[keys]


def wait_until_page_reloads(delay, browser, item, by=By.ID):
    try:
        WebDriverWait(browser, delay).until(
            expected_conditions.presence_of_element_located((by, item)))
        return True
    except TimeoutException:
        return False


def logging_to_file(message):
    with open(os.path.join(os.path.dirname(__file__), 'Crawler.log'), 'a') as file:
        file.write(message)