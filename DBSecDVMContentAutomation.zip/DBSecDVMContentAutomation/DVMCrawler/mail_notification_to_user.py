import json
import os
import sqlite3
import smtplib
from datetime import datetime, timezone
from email.message import EmailMessage

_CRED_PATH = os.path.join(os.path.dirname(__file__), 'credentials', 'credentials.json')
_MAIL_PATH = os.path.join(os.path.dirname(__file__), 'credentials', 'mail_properties.json')
_DB_PATH = os.path.join(os.path.dirname(__file__), 'cve_data.db')


class MailNotificationToUser:

    def __init__(self):
        with open(_CRED_PATH, 'r') as f:
            creds = json.load(f)
        self._vuln_collections = {
            db: name for db, name in zip(creds[3]['list_db'], creds[3]['list_db_name'])
        }

        with open(_MAIL_PATH, 'r') as f:
            mail = json.load(f)
        self._smtp = mail['smtp']
        self._sender = mail['sender']
        self._receivers = mail['receivers']

    def _fetch_unreported(self):
        """Return {collection_name: [doc, ...]} for all unreported CVEs."""
        unreported = {}
        conn = sqlite3.connect(_DB_PATH)
        conn.row_factory = sqlite3.Row
        try:
            for collection_name in self._vuln_collections:
                try:
                    rows = conn.execute(
                        f'SELECT * FROM "{collection_name}" WHERE reported = 0'
                    ).fetchall()
                    if rows:
                        unreported[collection_name] = [dict(r) for r in rows]
                except sqlite3.OperationalError:
                    # Table doesn't exist yet — spider has not run for this DB
                    pass
        finally:
            conn.close()
        return unreported

    def _mark_reported(self, unreported):
        conn = sqlite3.connect(_DB_PATH)
        try:
            for collection_name, docs in unreported.items():
                cve_nos = [doc['cve_no'] for doc in docs]
                placeholders = ','.join('?' * len(cve_nos))
                conn.execute(
                    f'UPDATE "{collection_name}" SET reported = 1 WHERE cve_no IN ({placeholders})',
                    cve_nos
                )
            conn.commit()
        finally:
            conn.close()

    def _build_body(self, unreported):
        lines = [
            f"New CVEs found on {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}",
            '',
        ]
        for collection_name, docs in unreported.items():
            db_label = self._vuln_collections.get(collection_name, collection_name.upper())
            lines.append(f"=== {db_label} ({len(docs)} CVE(s)) ===")
            for doc in docs:
                lines.append(f"  CVE       : {doc.get('cve_no', 'N/A')}")
                lines.append(f"  Severity  : {doc.get('severity', 'N/A')}")
                lines.append(f"  Affected  : {doc.get('affected_version', 'N/A')}")
                lines.append(f"  Link      : {doc.get('link', 'N/A')}")
                lines.append('')
        return '\n'.join(lines)

    def send_mail(self):
        unreported = self._fetch_unreported()

        msg = EmailMessage()
        msg['From'] = self._sender
        msg['To'] = ', '.join(self._receivers)

        if unreported:
            msg['Subject'] = '⚠️ New CVEs Found'
            msg.set_content(self._build_body(unreported))
        else:
            msg['Subject'] = 'No New CVEs Found - DVM Automation'
            msg.set_content('No new CVEs found in this run.')

        try:
            with smtplib.SMTP(self._smtp, 25) as smtp:
                smtp.send_message(msg)
            print('Mail sent successfully.')
            if unreported:
                self._mark_reported(unreported)
        except (smtplib.SMTPException, OSError) as e:
            print(f'Unable to send mail: {e}')