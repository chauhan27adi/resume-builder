"""Source-level 'does this change look like a security FIX?' for Stage-1 diffs.

The binary `_x86diff.fix_signature` scores newly-inserted x86 instructions; this is its text
analog for Oracle's PRIMARY signal — changed PL/SQL packages (`.plb` unwrapped) and decompiled
OJVM Java classes. A security fix in source is a small block of NEW code that adds a guard:

  * input validation / sanitisation — the classic Oracle case is a newly-added `DBMS_ASSERT.*`
    call (SQL-name / injection guard), or a Java validate/canonicalise/requireNonNull;
  * an authorization / permission check — PL/SQL privilege test + `RAISE_APPLICATION_ERROR`,
    or Java `checkPermission`/`SecurityManager`/`AccessController`/a new `*Permission`;
  * a raise/throw on invalid or unauthorized input;
  * a bounds / length clamp.

We score only the lines difflib marks as inserted/replaced on the FIXED side, so reformatting
or a wholesale rewrite doesn't inflate the score. Returns (score, reasons) exactly like the
binary fix_signature, so the same "Likely fixes" shortlist + `🔧 fix-shaped` chip render for
Stage 1. Deterministic, no AI — pure pattern match over the diff.
"""
import difflib
import re

# (regex, weight, reason). Weight is added ONCE if the pattern appears anywhere in the
# changed (inserted/replaced) FIXED-side lines — presence, not per-line, so a big rewrite
# can't run the score up. Ordered strongest-first only for readability.
_PLSQL = [
    (re.compile(r"\bdbms_assert\b|simple_sql_name|enquote_name|enquote_literal|"
                r"qualified_sql_name|\bschema_name\b|sql_object_name", re.I),
     8, "added DBMS_ASSERT / SQL-name validation (injection guard)"),
    (re.compile(r"check_?priv|has_?priv|is_?authoriz|verify_?(priv|auth|access)|"
                r"dbms_session\.|sys_context\s*\(\s*'userenv'|insufficient\s+privile|check_?access",
                re.I),
     8, "added privilege / authorization check"),
    (re.compile(r"raise_application_error|(^|\W)raise(\W|$)", re.I),
     5, "added RAISE on invalid / unauthorized"),
    (re.compile(r"\bif\b[^\n]*\b(is\s+null|length\w*|nvl|instr)\b", re.I),
     3, "added null / length guard"),
    (re.compile(r"length\w*\s*\(|\bsubstrb?\s*\(|nls_length", re.I),
     3, "added length / bound handling"),
    (re.compile(r"(^|\W)(if|elsif|case)\b", re.I),
     2, "added conditional guard"),
]
_JAVA = [
    (re.compile(r"checkPermission|SecurityManager|AccessController|doPrivileged|"
                r"\w*Permission\b|checkRead|checkWrite|checkConnect|checkExec|checkGuard"),
     8, "added permission / SecurityManager check"),
    (re.compile(r"validate|sanitiz|canonical|normaliz|isValid|checkArg|requireNonNull|"
                r"verif(y|ied)", re.I),
     6, "added validation / sanitisation"),
    (re.compile(r"throw\s+new\s+\w*(Security|Access|IllegalArgument|IllegalState|"
                r"IllegalAccess)\w*Exception"),
     6, "added throw on invalid / unauthorized"),
    (re.compile(r"\.length\b|\.size\s*\(\)|Math\.(min|max)|\bclamp\b|\bbound\b|MAX_\w+|_LIMIT\b"),
     3, "added length / bound handling"),
    (re.compile(r"^\s*if\s*\("),
     2, "added conditional guard"),
]


def _changed_fixed_lines(prior_lines, fixed_lines):
    """Lines difflib marks inserted or replaced on the FIXED side (the genuinely new code)."""
    out = []
    for tag, _i1, _i2, j1, j2 in difflib.SequenceMatcher(
            a=prior_lines, b=fixed_lines, autojunk=False).get_opcodes():
        if tag in ("insert", "replace"):
            out += fixed_lines[j1:j2]
    return out


def fix_signature(prior_lines, fixed_lines, lang="plsql"):
    """(score, reasons) — higher = more fix-shaped. `lang` selects the PL/SQL or Java pattern
    set (Java for decompiled OJVM classes; PL/SQL for everything else incl .sql)."""
    if not fixed_lines:
        return 0, []
    changed = _changed_fixed_lines(prior_lines, fixed_lines)
    if not changed:
        return 0, []
    pats = _JAVA if lang == "java" else _PLSQL
    score, reasons = 0, []
    for rx, w, why in pats:
        if any(rx.search(l) for l in changed):
            score += w
            reasons.append(why)
    if not score:
        return 0, []
    # A real fix is a LOCALISED edit to an existing unit. A newly-added or wholesale-regenerated
    # file (e.g. an install .sql rewritten end-to-end) trips every security keyword without being
    # a targeted guard — cap it so it can't outrank a surgical change. `frac` = share of the
    # fixed file that changed.
    n = len(changed)
    frac = n / max(1, len(fixed_lines))
    localised = any(prior_lines) and frac <= 0.6
    if not localised:
        if reasons:
            reasons[0] = "large/regenerated file — " + reasons[0]
        return min(score, 4), reasons[:2]
    if n <= 15:
        score += 3
        reasons.append("small surgical change")
    elif n > 300:
        score = max(0, score - 3)
    return score, reasons