"""Completion + source-identity bookkeeping for acquired/extracted build trees.

Acquisition used to treat "the output directory exists and looks populated" as "this build
is already extracted". That reused (a) a tree left half-written by an interrupted run, and
(b) a fully extracted tree for a DIFFERENT requested source (another DB2 tag, another MSSQL
KB, another dropped installer) — silently diffing the wrong builds.

Each extracted tree now gets a sidecar `<dir>.source.json` written only after extraction
fully succeeds, recording what it was extracted from. A tree is reused only when that
sidecar exists and its source matches the current request. New extractions go into a fresh
`<dir>.partial` and are swapped in only on success; a tree being replaced is moved aside to
`<dir>.stale-<timestamp>` (never deleted), so a failed re-acquire can't destroy a working
tree and nothing the user might want back is lost.

The sidecar lives NEXT TO the tree, not inside it: triage walks the tree itself (MSSQL
walks engine/ directly), and a marker file inside would show up as a changed file.
"""
import json
import os
import shutil
import time
import uuid

from .db2._paths import lp


def _sidecar(final_dir):
    return str(final_dir) + ".source.json"


def read(final_dir):
    """The sidecar record for `final_dir`, or None if absent/unreadable/incomplete."""
    try:
        with open(lp(_sidecar(final_dir)), encoding="utf-8") as fh:
            rec = json.load(fh)
    except (OSError, ValueError):
        return None
    if not isinstance(rec, dict) or rec.get("complete") is not True:
        return None
    return rec


def is_complete(final_dir, source, match=None):
    """True if `final_dir` exists and was fully extracted from `source`. `match(recorded,
    requested)` overrides plain equality for sources with optional parts."""
    if not os.path.isdir(lp(final_dir)):
        return False
    rec = read(final_dir)
    if rec is None:
        return False
    recorded = rec.get("source")
    return match(recorded, source) if match else recorded == source


def begin(final_dir):
    """A fresh, empty staging dir for a new extraction of `final_dir`. A leftover staging dir
    is only ever our own incomplete output, so it is safe to clear."""
    partial = str(final_dir) + ".partial"
    if os.path.lexists(lp(partial)):
        shutil.rmtree(lp(partial), ignore_errors=True)
    os.makedirs(lp(partial), exist_ok=True)
    return partial


def abandon(partial):
    shutil.rmtree(lp(partial), ignore_errors=True)


def discard(final_dir):
    """Remove a tool-generated CACHE dir and its sidecar (never use on acquired trees)."""
    shutil.rmtree(lp(final_dir), ignore_errors=True)
    try:
        os.remove(lp(_sidecar(final_dir)))
    except OSError:
        pass


def commit(final_dir, partial, source, keep_old=True):
    """Swap a successfully-extracted `partial` in as `final_dir` and record its source.
    Any existing `final_dir` (stale/incomplete/other source) is moved aside, not deleted —
    unless keep_old=False, for regenerable tool caches. Returns the new extraction id."""
    final_dir = str(final_dir)
    side = _sidecar(final_dir)
    if not keep_old:
        discard(final_dir)
    if os.path.lexists(lp(final_dir)):
        stale = f"{final_dir}.stale-{time.strftime('%Y%m%dT%H%M%S')}-{uuid.uuid4().hex[:6]}"
        os.replace(lp(final_dir), lp(stale))
        if os.path.exists(lp(side)):
            os.replace(lp(side), lp(stale + ".source.json"))
    elif os.path.exists(lp(side)):
        os.remove(lp(side))
    os.replace(lp(partial), lp(final_dir))
    ext_id = uuid.uuid4().hex
    tmp = side + ".tmp"
    with open(lp(tmp), "w", encoding="utf-8") as fh:
        json.dump({"source": source, "complete": True, "extraction_id": ext_id,
                   "time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}, fh)
    os.replace(lp(tmp), lp(side))
    return ext_id


def annotate(final_dir, **fields):
    """Merge extra fields into an existing complete sidecar (atomic rewrite)."""
    rec = read(final_dir)
    if rec is None:
        return
    rec.update(fields)
    side = _sidecar(final_dir)
    tmp = side + ".tmp"
    with open(lp(tmp), "w", encoding="utf-8") as fh:
        json.dump(rec, fh)
    os.replace(lp(tmp), lp(side))


def file_fingerprint(path):
    """Identity of a large local source file (an installer or fixpack): name, size and a
    SHA-256 of its content (mtime is left out: a touched but unchanged file is the same
    source, and needn't be re-extracted).

    bugs.md #22: this used to be name + size + mtime only, so an installer replaced by
    different bytes with the same size and preserved timestamp was taken for the old one
    and its old extracted tree reused. Hashing costs one sequential read of the file (a few
    seconds per GB) per check — small next to the extraction it guards. Deliberately not
    memoized by file stats: a same-size, same-timestamp replacement leaves every stat
    unchanged (Windows keeps the creation time on overwrite), which is exactly the case
    this identity has to catch."""
    import hashlib
    st = os.stat(lp(path))
    h = hashlib.sha256()
    with open(lp(path), "rb") as fh:
        for blk in iter(lambda: fh.read(4 << 20), b""):
            h.update(blk)
    return {"name": os.path.basename(path), "size": st.st_size, "sha256": h.hexdigest()}


def _norm(path):
    p = str(path)
    if p.startswith("\\\\?\\"):          # lp()'s Windows extended-length prefix
        p = p[4:]
    return os.path.normcase(os.path.realpath(os.path.abspath(p)))


def manifest_applies(manifest, prior_dir, fixed_dir):
    """True only if an acquire member-diff manifest describes EXACTLY these two trees, as
    they are now. bugs.md #14: Stage 0 used to apply any acquire/manifest.json it found —
    to manually supplied dirs, to a side re-acquired since, or (Oracle) to a DB2 run's
    manifest left in a reused output dir — and walk neither tree, so real changes vanished.
    A manifest without tree bindings (written by an older version) never applies."""
    trees = manifest.get("trees") if isinstance(manifest, dict) else None
    if not isinstance(trees, dict):
        return False
    for side, given in (("vuln", prior_dir), ("fixed", fixed_dir)):
        t = trees.get(side)
        if not isinstance(t, dict) or not t.get("vdir") or not t.get("root"):
            return False
        if _norm(t["vdir"]) != _norm(given):
            return False
        rec = read(t["root"])
        if rec is None or rec.get("extraction_id") != t.get("extraction_id"):
            return False
    return True


def _tree_sizes(root):
    out = {}
    base = lp(os.path.abspath(str(root)))
    for dp, _dn, files in os.walk(base):
        for fn in files:
            ap = os.path.join(dp, fn)
            try:
                out[os.path.relpath(ap, base).replace("\\", "/")] = (ap, os.path.getsize(ap))
            except OSError:
                out[os.path.relpath(ap, base).replace("\\", "/")] = (ap, None)
    return out


def _sha256_file(path):
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for blk in iter(lambda: fh.read(4 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def tree_snapshot(root):
    """{relpath: [size, sha256]} for every file under `root` — what an acquisition manifest
    records of the (pruned) trees it describes (bugs.md #48). By CONTENT, not mtime: a
    same-length edit inside one filesystem timestamp tick leaves size and mtime unchanged.
    A pruned tree holds only the files that differ from its partner, so this stays cheap."""
    return {rel: [size, _sha256_file(ap) if size is not None else None]
            for rel, (ap, size) in _tree_sizes(root).items()}


def _tree_matches(root, snap):
    """True if `root` holds exactly the files in `snap` with that content (names and sizes
    first, so an obvious mismatch costs no hashing)."""
    if not isinstance(snap, dict):
        return False
    now = _tree_sizes(root)
    if set(now) != set(snap):
        return False
    for rel, (ap, size) in now.items():
        rec = snap[rel]
        if not (isinstance(rec, list) and len(rec) == 2) or size is None or rec[0] != size:
            return False
    return all(_sha256_file(ap) == snap[rel][1] for rel, (ap, _s) in now.items())


def manifest_snapshot_matches(manifest, prior_dir, fixed_dir):
    """True only if both trees are still exactly as the manifest recorded them after
    pruning (bugs.md #48): manifest_applies() checks WHICH trees a manifest describes, not
    whether they've been modified since — a file edited, added or removed afterwards was
    hidden by the manifest's stale change list. A manifest without a snapshot (written by an
    older version) can't be verified, so it doesn't match."""
    snap = manifest.get("snapshot") if isinstance(manifest, dict) else None
    if not isinstance(snap, dict):
        return False
    return _tree_matches(prior_dir, snap.get("vuln")) and _tree_matches(fixed_dir, snap.get("fixed"))


def mutually_pruned(prior_dir, fixed_dir):
    """True if the two trees were pruned against EACH OTHER: their identical files were
    deleted from both, so a full walk of them is still a sound comparison."""
    rp, rf = pruned_tree_record(prior_dir), pruned_tree_record(fixed_dir)
    return bool(rp and rf and rp.get("extraction_id") and rf.get("extraction_id")
                and rp.get("pruned_with") == rf["extraction_id"]
                and rf.get("pruned_with") == rp["extraction_id"])


def pruned_tree_record(path, max_up=8):
    """If `path` lies inside an acquired tree that was pruned against a partner (identical
    files deleted to save space), that tree's sidecar record, else None."""
    cur = _norm(path)
    for _ in range(max_up):
        rec = read(cur)
        if rec is not None and rec.get("pruned_with"):
            return rec
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    return None

