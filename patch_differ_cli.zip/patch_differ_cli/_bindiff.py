"""BinDiff integration for patch_differ_cli Stage 2 (opt-in via --use-bindiff).

Responsibilities:
  1. Tool discovery: delegated to tool_paths.py (single source of truth for every
     bundled tool path — see that module's docstring)
  2. Ghidra BinExport export: ghidra_binexport() — imports binary with full analysis,
     then exports a .BinExport file via the BinExport Ghidra extension
  3. differ execution: run_differ() — invokes the BinDiff differ CLI
  4. Match parsing: parse_matches() — reads the .BinDiff SQLite result
  5. Public entry point: diff_pair() — orchestrates all four steps with caching

Each backend (MSSQL, DB2, Oracle) calls diff_pair() and maps the returned
{prior_va: FuncMatch} dict to its own {name: chunks} function map.

Address space notes
-------------------
MSSQL PE: BinDiff VAs == pefile ImageBase + RVA. Caller must add ImageBase when
  building the addr→name index from _func_map() RVAs.
DB2 ELF PIE: BinDiff VAs == st_value + _GHIDRA_ELF_PIE_BASE (Ghidra's PIE load
  address, typically 0x100000). Caller must add that constant.
"""
import fnmatch
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import tempfile
from collections import Counter
from dataclasses import dataclass

from .db2._paths import lp
from . import tool_paths as tp

_TIMEOUT_IMPORT   = 3600   # seconds — floor for the full Ghidra analysis of one binary
_TIMEOUT_EXPORT   = 600    # seconds — floor for the BinExport postScript on the analysed project
_TIMEOUT_DIFFER   = 300    # seconds — floor for the differ matching step
# db2_bugs.md DB2-15 / bugs.md MSSQL-2: fixed limits were below the real cost of a large
# binary, so its finished analysis was thrown away as "timed out". Each limit now grows with
# the input; the floors above still apply to small inputs. Live MSSQL run: sqlmin.dll
# (49.8 MiB) took 7,284-8,121 s to analyse (~163 s/MiB) after ~7 minutes of loading, so
# 240 s/MiB leaves about 1.5x headroom.
_IMPORT_SECONDS_PER_MIB = 240
_EXPORT_SECONDS_PER_MIB = 60   # the export re-opens the analysed program, then walks it
_DIFFER_SECONDS_PER_MIB = 30   # per MiB of the two .BinExport files
_STEPS = {"import": (_TIMEOUT_IMPORT, _IMPORT_SECONDS_PER_MIB, "PATCHDIFF_GHIDRA_IMPORT_TIMEOUT"),
          "export": (_TIMEOUT_EXPORT, _EXPORT_SECONDS_PER_MIB, "PATCHDIFF_BINEXPORT_TIMEOUT"),
          "differ": (_TIMEOUT_DIFFER, _DIFFER_SECONDS_PER_MIB, "PATCHDIFF_BINDIFF_TIMEOUT")}


def bindiff_selected(rel, patterns):
    """--bindiff-only (db2_bugs.md DB2-12): True when no patterns were given, or when the
    binary's path `rel` or its file name matches one of the glob `patterns` (case-
    insensitive). A binary that isn't selected is name-matched, as without --use-bindiff."""
    if not patterns:
        return True
    r = rel.replace("\\", "/").lower()
    base = r.rsplit("/", 1)[-1]
    return any(fnmatch.fnmatchcase(r, p.lower()) or fnmatch.fnmatchcase(base, p.lower())
               for p in patterns)


def _short_input(binary_path, project_dir):
    """`binary_path` itself, or — when it is over Windows' path limit for Ghidra — a hard
    link (a copy when linking fails) under the project's parent with the SAME file name, so
    the Ghidra program name, the export and its cache key are unchanged (db2_bugs.md DB2-3:
    a binary deep inside an extracted tree used to be rejected outright). The alias is
    refreshed when the source changed; None when even the alias would be too long."""
    if os.name != "nt" or len(os.path.abspath(binary_path)) <= _MAX_WINDOWS_PATH:
        return binary_path
    tag = hashlib.sha256(os.path.abspath(binary_path).lower().encode("utf-8")).hexdigest()[:10]
    alias = os.path.join(os.path.dirname(os.path.abspath(project_dir)), "_in", tag,
                         os.path.basename(binary_path))
    if len(os.path.abspath(alias)) > _MAX_WINDOWS_PATH:
        return None
    os.makedirs(lp(os.path.dirname(alias)), exist_ok=True)
    if os.path.isfile(lp(alias)):
        try:
            if os.path.samefile(lp(alias), lp(binary_path)):
                return alias
        except OSError:
            pass
        if _sha256(alias) == _sha256(binary_path):
            return alias
        os.remove(lp(alias))
    try:
        os.link(lp(binary_path), lp(alias))
    except OSError:
        part = alias + ".partial"
        try:
            shutil.copyfile(lp(binary_path), lp(part))
            os.replace(lp(part), lp(alias))
        except BaseException:
            try:
                os.remove(lp(part))
            except OSError:
                pass
            raise
    return alias


def step_timeout(step, size_bytes=0):
    """Seconds allowed for one `step` ("import", "export" or "differ") over `size_bytes`
    of input, or None for no limit. The step's PATCHDIFF_*_TIMEOUT env var wins (whole
    seconds, 0 = no limit); ValueError for an unusable value."""
    floor, per_mib, name = _STEPS[step]
    v = os.environ.get(name, "").strip()
    if v:
        n = int(v) if v.isascii() and v.isdigit() else -1
        if n < 0:
            raise ValueError(f"{name}={v!r}: expected a whole number of seconds (0 = no limit)")
        return n or None
    return max(floor, int(per_mib * size_bytes / (1 << 20)))


def _run_tool(cmd, timeout=None, env=None, log_path=None, heartbeat=None):
    """The one place this module launches Ghidra or BinDiff (tests replace it). Kills the
    whole process tree on timeout — see tool_paths.run_tool()."""
    return tp.run_tool(cmd, timeout=timeout, env=env, log_path=log_path, heartbeat=heartbeat)


_HEARTBEAT_SECONDS = 15
_QUIET_SECONDS = 300
_ESTIMATE_SECONDS_PER_MIB = 160     # measured on the large MSSQL DLLs (see _parallel.py)


def _heartbeat(progress, what, name, size, lo, hi):
    """A run_tool() heartbeat for one long Ghidra step (db2_bugs.md DB2-20): moves the
    progress bar from `lo` toward `hi` against a size-based estimate (never reaching `hi`
    before the step ends) and, every _HEARTBEAT_SECONDS, says how long it has run, how
    much Ghidra has logged and, after _QUIET_SECONDS of silence, for how long it has been
    quiet — so a hung JVM no longer looks like a slow one. None without `progress`."""
    if not progress:
        return None
    expected = max(60.0, size / (1 << 20) * _ESTIMATE_SECONDS_PER_MIB)
    last = [-_HEARTBEAT_SECONDS]

    def beat(elapsed, logged, idle):
        if elapsed - last[0] < _HEARTBEAT_SECONDS:
            return
        last[0] = elapsed
        pct = lo + int((hi - lo) * min(0.95, elapsed / expected))
        size_txt = (f"{logged / (1 << 20):.1f} MiB" if logged >= 1 << 20
                    else f"{logged >> 10} KiB")
        msg = f"Ghidra: {what} {name} — {int(elapsed // 60)} min, log {size_txt}"
        if idle >= _QUIET_SECONDS:
            msg += f", no output for {int(idle // 60)} min"
        progress(pct, msg)
    return beat


_OOM_MARKER = b"java.lang.OutOfMemoryError"


def _oom_failure(proc, step, binary_path, heap):
    """A reason string if Ghidra ran out of heap in this run, else None. An analyzer that
    runs out of memory can be caught inside Ghidra, which then exits normally with the
    analysis incomplete — so this is checked on success too (db2_bugs.md DB2-11)."""
    if _OOM_MARKER not in (proc.stdout or b""):
        return None
    return (f"Ghidra ran out of Java heap during the {step} of "
            f"{os.path.basename(binary_path)} (max heap {heap >> 20} MiB); set "
            f"{tp.HEAP_ENV} to a larger size, e.g. {max(4, 2 * (heap >> 30))}G")


# Which program each Ghidra project currently holds, and from what input/tools. The prior and
# fixed builds share one project and usually one program name, so importing the fixed side
# replaces the prior's analysis; this record says when an analysis is still the right one.
_PROJECT_RECORD = "pdff_imports.json"


def _project_imports(project_dir):
    try:
        with open(lp(os.path.join(project_dir, _PROJECT_RECORD)), encoding="utf-8") as fh:
            rec = json.load(fh)
        return rec if isinstance(rec, dict) else {}
    except (OSError, ValueError):
        return {}


def _set_project_import(project_dir, binary_name, hexdigest):
    """Record (or, with None, forget) that the project holds `binary_name` analysed from
    `hexdigest`. Forgotten BEFORE an import starts, recorded only after it succeeds, so
    a killed or failed import never looks reusable."""
    rec = _project_imports(project_dir)
    if hexdigest is None:
        rec.pop(binary_name, None)
    else:
        rec[binary_name] = hexdigest
    path = os.path.join(project_dir, _PROJECT_RECORD)
    tmp = path + ".tmp"
    with open(lp(tmp), "w", encoding="utf-8") as fh:
        json.dump(rec, fh, indent=1, sort_keys=True)
    os.replace(lp(tmp), lp(path))


# ---------------------------------------------------------------------------
# Caching helpers
# ---------------------------------------------------------------------------

# Our headless export script (bugs.md #54) — see db2/ghidra/PdffBinExport.java.
_EXPORT_SCRIPT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "db2", "ghidra")
_EXPORT_SCRIPT = "PdffBinExport.java"

# Bump when the import/export command lines below change in a way that alters the export.
_EXPORT_OPTS = "import-overwrite;postScript-PdffBinExport-noopts;noanalysis-v2"


def _sha256(path):
    h = hashlib.sha256()
    with open(lp(path), "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _cache_hit(out_path):
    """Return True if out_path exists and its .sha256 sidecar is present."""
    sha_path = out_path + ".sha256"
    return os.path.isfile(lp(out_path)) and os.path.isfile(lp(sha_path))


def _write_sha(out_path, hexdigest):
    with open(lp(out_path + ".sha256"), "w", encoding="ascii") as f:
        f.write(hexdigest)


def _read_sha(out_path):
    try:
        with open(lp(out_path + ".sha256"), "r", encoding="ascii") as f:
            return f.read().strip()
    except OSError:
        return None


def _discard_export(out_path, sidecar_only=False):
    """Remove a BinExport's .sha256 sidecar (and, unless sidecar_only, the export itself)."""
    for p in (out_path + ".sha256",) + (() if sidecar_only else (out_path,)):
        try:
            os.remove(lp(p))
        except OSError:
            pass


# Ghidra's HeadlessAnalyzer logs these when a -postScript throws or the run aborts — it can
# still exit 0 in those cases (CRIT-T2-1), so the exit code alone isn't enough.
_HEADLESS_FAILURE_MARKERS = (b"REPORT SCRIPT ERROR", b"Abort due to Headless analyzer error")


def _export_failure(proc):
    """Why a BinExport export run failed, or None if it didn't report a failure."""
    if proc.returncode not in (0, 1):      # Ghidra exits 1 on warnings — tolerate
        return f"failed (rc={proc.returncode})"
    out = proc.stdout or b""
    for marker in _HEADLESS_FAILURE_MARKERS:
        if marker in out:
            return f"failed ({marker.decode()})"
    return None


# Windows' legacy MAX_PATH limit (260 chars incl. the null terminator -> 259 usable).
_MAX_WINDOWS_PATH = 259


def _check_subprocess_path(path, what):
    """Raise a clear RuntimeError if `path` is over Windows' legacy path-length limit,
    BEFORE handing it to an external process on the command line.

    This module's own file I/O already uses lp()'s `\\?\\` extended-length prefix
    throughout (see db2/_paths.py), which lifts that limit for US. It does NOT lift it
    for Ghidra (a JVM process) or BinDiff — prefixing the arguments we pass to THEM the
    same way is not a safe fix: Java's legacy file APIs do not reliably honor the `\\?\\`
    prefix (support has varied across JDK versions and is not something to assume works
    for whatever JDK is bundled), so doing that risks turning a rare long-path failure
    into every-invocation breakage instead. Failing fast here, before the subprocess ever
    runs, turns an otherwise-opaque Ghidra/BinDiff failure deep inside a Java or C++
    exception into one clear, actionable Python-level error.
    """
    if os.name != "nt":
        return
    ap = os.path.abspath(path)
    if len(ap) > _MAX_WINDOWS_PATH:
        raise RuntimeError(
            f"{what} path is {len(ap)} characters long, over Windows' "
            f"{_MAX_WINDOWS_PATH}-character legacy path limit — Ghidra/BinDiff are not "
            f"guaranteed to handle a longer one:\n  {ap}\n"
            "Move --out closer to the drive root (e.g. C:\\pdiff\\out) and re-run.")


# ---------------------------------------------------------------------------
# Ghidra BinExport export
# ---------------------------------------------------------------------------

def ghidra_binexport(binary_path, project_dir, out_path,
                     ghidra_home=None, progress=None):
    """Import binary_path into Ghidra with full analysis and export a .BinExport file.

    Two-phase approach to separate analysis (slow, cached) from export (fast):

      Phase 1 — Import + full analysis (skipped when .sha256 sidecar matches, and also when
        no export exists but the project still holds this input's finished analysis, e.g.
        after an export that failed or timed out — see _PROJECT_RECORD):
        analyzeHeadless <project_dir> bindiff_proj
          -import <binary_path> -overwrite

      Each step's time limit scales with the input (step_timeout()) and its output is kept
      next to the export as <out_path>.import.log / .export.log. The JVM heap scales too
      (tool_paths.ghidra_heap()). An out-of-memory run is reported as a failure.

      Phase 2 — Export BinExport from the existing project (always runs when Phase 1 ran;
        skipped only if out_path already exists with a matching sidecar):
        analyzeHeadless <project_dir> bindiff_proj
          -process <binary_name>
          -postScript BinExport.java <out_path> ""
          -noanalysis

    Uses -postScript (not -preScript): BinExport documentation requires postScript so
    all analysis data is loaded before the export script runs. With -noanalysis both
    behave identically (program opened from project), but -postScript matches the spec.

    Returns out_path. Raises GhidraNotConfigured when Ghidra is absent, or RuntimeError
    on timeout / missing output.
    """
    headless = tp.analyze_headless()
    if not headless:
        raise GhidraNotConfigured(
            "Ghidra not found. Set GHIDRA_HOME (expects support/analyzeHeadless).")

    # DB2-T1-8: this only checks the extension is INSTALLED (its BinExport2Builder classes);
    # the export itself runs our PdffBinExport.java below, not the returned path.
    script_path = tp.locate_binexport_script(ghidra_home)
    if not script_path:
        raise BinExportNotInstalled(
            "The BinExport Ghidra extension was not found. "
            "Install it from the BinDiff release package: "
            "https://github.com/google/bindiff/releases\n"
            "Expected location: <GHIDRA_HOME>/Ghidra/Extensions/BinExport/ "
            "(its lib/ BinExport jar, and normally ghidra_scripts/BinExport.java)")

    # IMP-T2-1: BinExport.java (like DecompileFunc.java) is a custom GhidraScript Ghidra
    # dynamically compiles into a per-user OSGi bundle cache keyed implicitly to whichever
    # JDK Ghidra last ran under. A JDK switch since the last run leaves that cache stale,
    # failing with an opaque BundleException while Ghidra itself exits 0. Best-effort,
    # never raises — see tool_paths.py for the full explanation.
    tp.clear_stale_ghidra_script_cache()
    tp.warn_if_unsupported_java()          # bugs.md #56

    # bugs.md #55: mixed protobuf-java versions in one Ghidra install make every export
    # crash inside BinExport2Builder (IllegalAccessError) — fail fast with the reason.
    conflict = tp.protobuf_conflict(ghidra_home)
    if conflict:
        raise BinExportNotInstalled(
            "The Ghidra install has conflicting protobuf-java versions on its class path; "
            "BinExport export would crash with IllegalAccessError. Make them one version "
            "(see docs/PREREQUISITES.md):\n  "
            + "\n  ".join(f"{v}: {p}" for v, p in conflict))

    _check_subprocess_path(project_dir, "Ghidra project directory")
    _check_subprocess_path(out_path, "BinExport output file")
    os.makedirs(lp(project_dir), exist_ok=True)
    binary_path = _short_input(binary_path, project_dir) or binary_path
    _check_subprocess_path(binary_path, "input binary")

    # Use the full filename (with extension) because Ghidra stores imported programs under
    # their complete name (e.g. "sqlmin.dll", not "sqlmin").  Stripping the extension with
    # splitext caused -process to find nothing in the project and Phase 2 to silently produce
    # no output.
    binary_name = os.path.basename(binary_path)
    os.makedirs(lp(project_dir), exist_ok=True)
    os.makedirs(lp(os.path.dirname(os.path.abspath(out_path))), exist_ok=True)

    # bugs.md #26: the cache record used to be the input binary's SHA-256 alone, so after a
    # Ghidra / BinExport / JDK update the previous tool's export kept being reused. It now
    # also carries the tool identity (by content) and the export options used below.
    script_id = tp.content_identity([os.path.join(_EXPORT_SCRIPT_DIR, _EXPORT_SCRIPT)])
    hexdigest = (f"{_sha256(binary_path)} tool={tp.binexport_identity(ghidra_home)} "
                 f"script={script_id} "
                 f"opts={_EXPORT_OPTS}")
    needs_export = not _cache_hit(out_path) or _read_sha(out_path) != hexdigest

    # db2_bugs.md DB2-11: the heap (and, through it, the env) scales with the input size.
    size = os.path.getsize(lp(binary_path))
    heap = tp.ghidra_heap(size)
    env = tp.ghidra_env(size)

    if needs_export:
        # DB2-15: when an earlier run analysed this same input with these same tools but its
        # export failed or timed out, the project still holds that analysis — export from it
        # instead of paying for the whole import again. Only then: a failed export always
        # removed the sidecar first, while a sidecar that is present but disagrees (an older
        # version's, or another input's) is not evidence enough, so that re-imports.
        if (not os.path.isfile(lp(out_path + ".sha256"))
                and _project_imports(project_dir).get(binary_name) == hexdigest):
            if progress:
                progress(55, f"Ghidra: reusing the analysis of {binary_name}")
        else:
            if progress:
                progress(5, f"Ghidra: importing {binary_name}")
            _set_project_import(project_dir, binary_name, None)
            cmd_import = [headless, project_dir, "bindiff_proj",
                          "-import", binary_path, "-overwrite"]
            proc = _run_tool(cmd_import, timeout=step_timeout("import", size), env=env,
                             log_path=out_path + ".import.log",
                             heartbeat=_heartbeat(progress, "analysing", binary_name, size,
                                                  5, 55))
            if proc.returncode not in (0, 1):  # Ghidra exits 1 on warnings — tolerate
                tail = (proc.stdout or b"")[-2000:].decode("utf-8", "replace")
                raise RuntimeError(
                    f"Ghidra import failed (rc={proc.returncode}).\n{tail}")
            oom = _oom_failure(proc, "import", binary_path, heap)
            if oom:
                raise RuntimeError(oom)
            _set_project_import(project_dir, binary_name, hexdigest)

        if progress:
            progress(60, f"Ghidra: exporting BinExport for {os.path.basename(binary_path)}")
        # bugs.md #54: the export runs our PdffBinExport.java (db2/ghidra/), not the
        # extension's BinExport.java. That script also needs an IDA-compatibility option
        # list, which headless Ghidra can't answer with "none" (parseChoices() throws on an
        # empty selection) — and the "" placeholder passed for it never arrived anyway:
        # analyzeHeadless.bat stops parsing at the first empty argument, dropping it AND the
        # -noanalysis after it, so every export failed with "looking for script argument #2".
        # PdffBinExport takes only the output path and exports with no options, i.e. the
        # Ghidra addresses the backends map matches back with. The extension (its
        # BinExport2Builder) must still be installed — checked by locate_binexport_script().
        # bugs.md #46: the sidecar is what makes an export a cache hit, so it goes BEFORE
        # the export runs and is only rewritten once the new export is known good. A stale
        # output file goes too, so a failed run can't leave the old export looking new.
        _discard_export(out_path)
        cmd_export = [headless, project_dir, "bindiff_proj",
                      "-process", binary_name,
                      "-scriptPath", _EXPORT_SCRIPT_DIR,
                      "-postScript", _EXPORT_SCRIPT, out_path,
                      "-noanalysis"]
        # every argument must be non-empty: analyzeHeadless.bat ends its argument list at
        # the first empty one, silently dropping the rest
        if not all(cmd_export):
            raise RuntimeError(f"BinExport command has an empty argument: {cmd_export}")
        try:
            proc2 = _run_tool(cmd_export, timeout=step_timeout("export", size), env=env,
                              log_path=out_path + ".export.log",
                              heartbeat=_heartbeat(progress, "exporting", binary_name,
                                                   size // 4, 60, 95))
        except BaseException:
            # timeout/interrupt: never leave a partial file. The project record is kept: the
            # analysis is complete, so a re-run (e.g. with a longer export limit) reuses it.
            _discard_export(out_path)
            raise
        # Success is a NON-EMPTY file from an export that did not report failure — one that
        # threw, timed out, or wrote nothing leaves no file or a 0-byte one. bugs.md #46: a
        # failing export that had already written SOME bytes used to pass the size check and
        # get cached as valid, so the exit code and Ghidra's script-error report are checked
        # too, and on any failure the output is removed so it can't be mistaken for (or
        # cached as) a real export on the next run.
        tail = (proc2.stdout or b"")[-2000:].decode("utf-8", "replace")
        failure = _export_failure(proc2)
        if failure is None and not (os.path.isfile(lp(out_path))
                                    and os.path.getsize(lp(out_path)) > 0):
            failure = "produced no output"
        oom = _oom_failure(proc2, "export", binary_path, heap)
        if oom:
            failure = f"failed ({oom})"
        if failure is not None:
            _discard_export(out_path)
            # The project may not hold a usable program (e.g. it was deleted, or the export
            # cannot open it): analyse again next time rather than repeat this failure.
            _set_project_import(project_dir, binary_name, None)
            raise RuntimeError(f"Ghidra BinExport {failure} at {out_path}.\n{tail}")
        _write_sha(out_path, hexdigest)

    if progress:
        progress(100, f"Ghidra: BinExport ready — {os.path.basename(out_path)}")
    return out_path


# ---------------------------------------------------------------------------
# differ execution
# ---------------------------------------------------------------------------

def run_differ(primary, secondary, out_dir):
    """Run the BinDiff differ CLI and return the path to the resulting .BinDiff file.

    Command: differ --primary=<primary> --secondary=<secondary> --output_dir=<out_dir>

    differ names its output <stem1>_vs_<stem2>.BinDiff. After the subprocess exits this
    function globs for *.BinDiff in out_dir and expects exactly one match.

    Raises RuntimeError if differ is not found, if the glob is empty (silent failure),
    or if the glob returns more than one file (unexpected).
    """
    differ = tp.locate_differ()
    if not differ:
        raise RuntimeError(
            "BinDiff CLI not found. Install BinDiff from "
            "https://github.com/google/bindiff/releases (bindiff.exe in BinDiff 8+, "
            "differ.exe in older versions), or set BINDIFF_PATH to the executable.")

    for _p, _what in ((primary, "primary .BinExport file"),
                      (secondary, "secondary .BinExport file"),
                      (out_dir, "BinDiff output directory")):
        _check_subprocess_path(_p, _what)

    os.makedirs(lp(out_dir), exist_ok=True)

    # Remove any stale .BinDiff files left by a previous run in this directory before
    # invoking differ.  Without this, re-running over the same output directory (e.g. to
    # refresh after a new patch) leaves the old file in place; the glob below then either
    # returns the stale result (silent wrong answer) or raises "multiple files" when the
    # new run writes a differently-named file alongside it.
    try:
        _bd_stale = [os.path.join(out_dir, f)
                     for f in os.listdir(lp(out_dir)) if f.endswith(".BinDiff")]
    except OSError:
        _bd_stale = []
    for stale in _bd_stale:
        try:
            os.remove(lp(stale))
        except OSError:
            pass

    cmd = [differ,
           f"--primary={primary}",
           f"--secondary={secondary}",
           f"--output_dir={out_dir}"]
    limit = step_timeout("differ", os.path.getsize(lp(primary)) + os.path.getsize(lp(secondary)))
    try:
        proc = _run_tool(cmd, timeout=limit, log_path=os.path.join(out_dir, "differ.log"))
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"BinDiff differ timed out after {limit}s") from None
    if proc.returncode != 0:
        tail = (proc.stdout or b"")[-2000:].decode("utf-8", "replace")
        raise RuntimeError(f"BinDiff differ failed (rc={proc.returncode}).\n{tail}")

    try:
        results = [os.path.join(out_dir, f)
                   for f in os.listdir(lp(out_dir)) if f.endswith(".BinDiff")]
    except OSError:
        results = []
    if not results:
        raise RuntimeError(
            f"BinDiff differ completed but produced no .BinDiff file in {out_dir}.")
    if len(results) > 1:
        raise RuntimeError(
            f"BinDiff differ produced multiple .BinDiff files in {out_dir}: {results}")
    return results[0]


# ---------------------------------------------------------------------------
# Match parsing
# ---------------------------------------------------------------------------

@dataclass
class FuncMatch:
    addr1: int        # primary (prior) function virtual address
    addr2: int        # secondary (fixed) function virtual address
    similarity: float  # 0.0–1.0 (CFG-based)
    confidence: float  # 0.0–1.0
    name1: str = None  # Ghidra's function name on each side (BinDiff >= 8; may be None)
    name2: str = None


def parse_matches(bindiff_path):
    """Read function match records from a .BinDiff SQLite file.

    Returns {addr1: FuncMatch} keyed by the primary-side (prior build) address.
    Only rows present in the `function` table are returned; unmatched functions
    have no row. Similarity == 1.0 rows are included (callers decide whether to skip).

    Schema: BinDiff >= 8 uses a `function` table with columns
    (address1, address2, similarity, confidence). If the table is absent a
    RuntimeError is raised with a version hint; callers should surface it to the user.
    """
    try:
        con = sqlite3.connect(lp(bindiff_path))
        try:
            try:
                # name1/name2 = Ghidra's function names, used to MEASURE each side's
                # address offset (map_matches(), bugs.md #60/#61)
                rows = con.execute("SELECT address1, address2, similarity, confidence, "
                                   "name1, name2 FROM function").fetchall()
            except sqlite3.OperationalError:
                rows = [r + (None, None) for r in con.execute(
                    "SELECT address1, address2, similarity, confidence FROM function"
                ).fetchall()]
        except sqlite3.OperationalError as exc:
            raise RuntimeError(
                f"BinDiff SQLite schema unexpected: {exc}\n"
                "Expected a 'function' table (BinDiff >= 8). "
                "Upgrade BinDiff or check the .BinDiff file format."
            ) from exc
        finally:
            con.close()
    except sqlite3.DatabaseError as exc:
        raise RuntimeError(f"Cannot open BinDiff file {bindiff_path}: {exc}") from exc

    return {addr1: FuncMatch(addr1=addr1, addr2=addr2, similarity=similarity,
                             confidence=confidence, name1=name1, name2=name2)
            for addr1, addr2, similarity, confidence, name1, name2 in rows}


def _measured_offset(pairs, fmap, default):
    """The dominant (BinDiff address - symbol address) over `pairs` of (address, Ghidra
    name) whose name is one of `fmap`'s unique, unqualified symbol names; `default` when
    nothing can be measured or no offset holds a majority."""
    uniq = {k: v[0] for k, v in fmap.items() if not k.startswith("sub_") and " [" not in k}
    deltas = Counter(addr - uniq[name] for addr, name in pairs if name in uniq)
    if not deltas:
        return default
    off, n = deltas.most_common(1)[0]
    return off if n * 2 > sum(deltas.values()) else default


def map_matches(matches, P, F, default_p, default_f):
    """(addr_to_name_P, addr_to_name_F): each side's function map keyed by the address
    BinDiff reports for it.

    bugs.md #60/#61: the backends used to add a fixed, assumed load base to every symbol
    value. Ghidra's real placement depends on the binary type (live-verified: ET_DYN at
    +0x100000, ET_EXEC at its own absolute addresses, ET_REL at +0x100000 — not the
    0x10000000 Oracle assumed), so non-PIE DB2 executables and every Oracle object mapped
    to nothing and came out as phantom added/removed functions. The offset is now MEASURED
    per side from BinDiff's own (address, Ghidra function name) pairs against the backend's
    symbol values, with `default_*` (the best per-type estimate) only when no name lines up
    (e.g. C++ names Ghidra demangled, or a PE without PDB names in Ghidra).

    Raises RuntimeError when both sides have functions but no BinDiff match resolves to
    one: the mapping is wrong, and the caller must fall back to name matching (recorded as
    a bindiff fallback, #57) rather than report every function as added/removed."""
    off_p = _measured_offset(((va, getattr(m, "name1", None)) for va, m in matches.items()),
                             P, default_p)
    off_f = _measured_offset(((m.addr2, getattr(m, "name2", None)) for m in matches.values()),
                             F, default_f)
    a_p = {v[0] + off_p: k for k, v in P.items()}
    a_f = {v[0] + off_f: k for k, v in F.items()}
    if a_p and a_f and not any(va in a_p or m.addr2 in a_f for va, m in matches.items()):
        raise RuntimeError(
            f"none of BinDiff's {len(matches)} match(es) resolved to a known function "
            f"(address offsets prior=0x{off_p:x}, fixed=0x{off_f:x}) — not using a "
            f"mis-mapped BinDiff result")
    return a_p, a_f


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def diff_pair(prior_binary, fixed_binary, workdir, progress=None):
    """Run the full BinDiff pipeline for one (prior, fixed) binary pair.

    Steps:
      1. ghidra_binexport(prior) → <workdir>/bindiff/prior_<stem>.BinExport
      2. ghidra_binexport(fixed) → <workdir>/bindiff/fixed_<stem>.BinExport
      3. run_differ(prior.BinExport, fixed.BinExport) → <workdir>/bindiff/<...>.BinDiff
      4. parse_matches(.BinDiff) → {prior_va: FuncMatch}

    .BinExport files are cached by binary SHA-256 (via _write_sha / _cache_hit) so
    re-runs skip the expensive Ghidra analysis for unchanged binaries.

    Returns: dict mapping prior-side virtual address → FuncMatch.

    Raises: GhidraNotConfigured, BinExportNotInstalled, or RuntimeError on failure.
    """
    bd_dir = os.path.join(workdir, "bindiff")
    os.makedirs(lp(bd_dir), exist_ok=True)

    proj_dir = os.path.join(bd_dir, "ghidra_proj")
    os.makedirs(lp(proj_dir), exist_ok=True)

    prior_stem = os.path.splitext(os.path.basename(prior_binary))[0]
    fixed_stem = os.path.splitext(os.path.basename(fixed_binary))[0]

    # Prefix with "prior_"/"fixed_" so the two .BinExport files have distinct paths
    # even when both sides share the same filename (sqlmin.dll vs sqlmin.dll, the
    # common case for a patch pair).  Without the prefix, prior_be == fixed_be and
    # the second ghidra_binexport() call silently overwrites the first; run_differ
    # then compares the binary to itself (all similarities == 1.0, zero changed).
    prior_be = os.path.join(bd_dir, "prior_" + prior_stem + ".BinExport")
    fixed_be = os.path.join(bd_dir, "fixed_" + fixed_stem + ".BinExport")

    def _prog(pct, msg):
        if progress:
            progress(pct, msg)

    _prog(0, f"BinExport: {os.path.basename(prior_binary)} (prior)")
    ghidra_binexport(prior_binary, proj_dir, prior_be, progress=lambda p, m: _prog(p // 4, m))

    _prog(25, f"BinExport: {os.path.basename(fixed_binary)} (fixed)")
    ghidra_binexport(fixed_binary, proj_dir, fixed_be, progress=lambda p, m: _prog(25 + p // 4, m))

    _prog(50, "BinDiff: matching functions")
    bindiff_path = run_differ(prior_be, fixed_be, bd_dir)

    _prog(90, "BinDiff: parsing matches")
    matches = parse_matches(bindiff_path)

    _prog(100, f"BinDiff: {len(matches)} function matches")
    return matches


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

# GhidraNotConfigured is defined in tool_paths.py (imported as `tp` above) and re-exported
# here so existing `from ._bindiff import GhidraNotConfigured`-style access keeps working,
# while callers that catch it from _decompile.py now catch the SAME class.
GhidraNotConfigured = tp.GhidraNotConfigured


class BinExportNotInstalled(RuntimeError):
    """Raised when the BinExport Ghidra extension / script is not found."""