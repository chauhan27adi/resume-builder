"""Shared Stage-2 result post-processing (both backends).

Signals that only make sense across the *whole* result set (not per-function), applied
after a run aggregates its `readable_files` and before the final ranking sort:

  mark_cross_binary  — a symbol changed in >1 library is a stronger "real fix" signal
                       (the client+server fix pattern; DB2 CVE-2026-10534 lived in both
                       libdb2.so and libdb2e.so). Modestly boosts fix-shaped functions.

  mark_cross_patch   — subtract the recompilation baseline: a function that ALSO changed in
                       an adjacent patch's delta is recompilation-prone (down-weight); a
                       function unique to THIS patch's delta is a better candidate (flag).
                       The caller supplies the baseline set of names from a sibling patch.
"""
import os
from collections import defaultdict

MAX_FUNC_BYTES_ENV = "PATCHDIFF_MAX_FUNC_BYTES"


def max_func_bytes(default):
    """The Stage 2 per-function size limit: PATCHDIFF_MAX_FUNC_BYTES when set (a positive
    whole number of bytes), else the backend's `default` (db2_bugs.md DB2-2). A function
    over the limit is not diffed but reported (skipped_oversized): normalising and
    sequence-matching a huge "function" (often a jump table) is very slow. Raises
    ValueError for an unusable value."""
    v = os.environ.get(MAX_FUNC_BYTES_ENV, "").strip()
    if not v:
        return default
    if not (v.isascii() and v.isdigit()) or int(v) <= 0:
        raise ValueError(f"{MAX_FUNC_BYTES_ENV}={v!r}: expected a positive whole number "
                         "of bytes")
    return int(v)


def skipped_oversized(P, F, one_sided=None):
    """Changed functions the Stage 2 function maps skipped as over _MAX_FUNC_BYTES (bugs.md
    #28). The maps used to drop them silently, so a large function's change vanished from a
    result that looked complete. Each map records its skipped functions as
    `.oversized = {name: [(size, sha256), ...]}`; one counts as CHANGED (and is returned) if
    its byte digests differ between the sides or it exists on one side only — an unchanged
    giant function stays quiet. An unnamed sub_<addr> one present on only one side is
    ignored in a two-sided diff (no identity across builds — same rule as indexed sub_ keys).

    A function that crossed the limit (small on one side, oversized on the other) is also
    removed from the map where it's small, so it isn't misreported as added/removed.
    Returns [{"name", "prior_size", "fixed_size"}] (size None = not oversized on that side)."""
    po = getattr(P, "oversized", None) or {}
    fo = getattr(F, "oversized", None) or {}
    out = []
    for name in sorted(set(po) | set(fo)):
        pd = sorted(d for _s, d in po.get(name, ()))
        fd = sorted(d for _s, d in fo.get(name, ()))
        if pd == fd:
            continue
        if name.startswith("sub_") and not one_sided and not (pd and fd):
            continue
        for m, have in ((P, pd), (F, fd)):
            if not have and name in m:
                del m[name]
        out.append({"name": name,
                    "prior_size": max((s for s, _d in po.get(name, ())), default=None),
                    "fixed_size": max((s for s, _d in fo.get(name, ())), default=None)})
    return out


def _bare(obj):
    return (obj or "").split("::")[-1].strip()


def _func_key(obj):
    """Cross-binary identity of a card: the FULL function name after the "<binary> :: "
    prefix (e.g. "CAlterLogin::CheckAuthorization"), or None when it has no stable identity.

    CRIT-NT-8: this used to be _bare() — the last "::" segment only — so two unrelated
    methods that merely shared a name (CAlterLogin::CheckAuthorization in sqlmin.dll vs
    CBackupJob::CheckAuthorization in sqllang.dll; Execute/Init/Release are everywhere)
    "corroborated" each other, and since cross_binary feeds resolve(), that asserted CVE
    claims nothing supported. Unnamed sub_<addr> placeholders (no symbol) are excluded:
    an address is not an identity across different binaries."""
    s = (obj or "")
    s = s.split(" :: ", 1)[1] if " :: " in s else s
    s = s.strip()
    if not s or s.startswith("sub_"):
        return None
    return s


def mark_cross_binary(readable):
    # Cards from a one-sided inventory (a whole binary added/removed — bugs.md #3) are not a
    # CHANGE to that function, just its presence in a new/gone library; a helper that also
    # exists in a newly added DLL must not "corroborate" an unrelated change elsewhere.
    by_name = defaultdict(set)
    for r in readable:
        k = _func_key(r.get("object"))
        if k is not None and not r.get("binary_change"):
            by_name[k].add(r.get("group") or r.get("src") or "")
    for r in readable:
        if r.get("binary_change"):
            continue
        k = _func_key(r.get("object"))
        libs = by_name.get(k, set()) if k is not None else set()
        if len(libs) > 1:
            r["multi_lib"] = len(libs)
            # a symbol changed in >1 library is an independent "real fix" signal (client+server
            # shared code) — flag it so it counts toward attribution corroboration, not just the
            # fix_score boost below. (The resolve() gate reads r["cross_binary"].)
            r["cross_binary"] = True
            if r.get("fix_score", 0) > 0:      # only boost fix-shaped — avoid CRT helpers
                r["fix_score"] = r.get("fix_score", 0) + 2 * min(len(libs) - 1, 2)
                extra = f"also changed in {len(libs)} libs"
                r["fix_why"] = (r["fix_why"] + "; " + extra) if r.get("fix_why") else extra


def refresh_cross_binary(readable):
    """Recompute mark_cross_binary() on an already-saved result (e.g. --reattribute on a
    functions_diff.json written by an older version whose grouping was the buggy last-"::"-
    segment key — CRIT-NT-8). Undoes the previous marks first so it is idempotent: drops
    cross_binary/multi_lib and reverses the fix_score boost + "also changed in N libs"
    fix_why suffix exactly where mark_cross_binary applied them (the suffix is only ever
    added together with the boost), then re-marks with the current key."""
    for r in readable:
        n = r.pop("multi_lib", None)
        r.pop("cross_binary", None)
        if not n:
            continue
        extra = f"also changed in {n} libs"
        why = r.get("fix_why") or ""
        if why == extra or why.endswith("; " + extra):
            r["fix_why"] = why[:-len(extra)].rstrip().rstrip(";").rstrip() if why != extra else ""
            r["fix_score"] = max(0, (r.get("fix_score") or 0) - 2 * min(n - 1, 2))
    mark_cross_binary(readable)


def mark_cross_patch(readable, baseline_names):
    """baseline_names = set of bare function names that changed in an adjacent patch's delta
    (recompilation baseline). Flag/boost functions unique to THIS patch; down-weight the
    ones the baseline also touched. No-op if baseline is empty/unavailable."""
    if not baseline_names:
        return
    for r in readable:
        nm = _bare(r.get("object"))
        if nm in baseline_names:
            r["also_baseline"] = True
            if r.get("fix_score", 0) > 0:
                r["fix_score"] = max(0, r.get("fix_score", 0) - 3)   # recompilation-prone
        else:
            r["patch_unique"] = True
            if r.get("fix_score", 0) > 0:
                r["fix_score"] = r.get("fix_score", 0) + 2           # unique to this delta


def baseline_names_from_result(stage2_result):
    """Extract the set of changed bare function names from a prior patch's stage2 result
    (its functions_diff.json), for use as a mark_cross_patch baseline."""
    if not stage2_result:
        return set()
    return {_bare(r.get("object")) for r in (stage2_result.get("readable_files") or [])}