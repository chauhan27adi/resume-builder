"""Stage 0 — file triage for the DB2 install tree.

Walks the two extracted `.../opt/ibm/db2/V<x>` trees and classifies every file:
  * ELF shared objects -> compare EXECUTABLE section hashes (the ELF analog of the
    MSSQL PE `.text` compare). Differ => real code change (route Stage 2); same-code
    but different bytes => rebuild-only noise.
  * JARs / scripts / added / removed -> route Stage 1 (bundled-dependency version
    bumps show up as an add+remove pair on different filenames, so we track those).
  * everything else -> size compare, best-effort.

Output: <workdir>/stage0/changed_files.json — same shape the detail template renders
(counts + code_changed[route stage2] + content_changed[route stage1] + rebuild_only),
plus added/removed lists that Stage 1 uses to pair version-bumped dependencies.
"""
import hashlib
import json
import os

from . import _elf
from ._paths import lp
from .. import _acquire_state as _state

_SKIP_TOP = ("samples/", "java/jdk64/", "java/jre/", "infopop/", "doc/")   # noise
_SCRIPT_EXT = (".py", ".sh", ".pl", ".ksh", ".awk")
_TEXTY_EXT = (".sql", ".properties", ".xml", ".json", ".cfg", ".conf")


def _rel_files(root, failed=None):
    """Relative posix paths of every regular file under root. A directory os.walk() can't
    list is appended to `failed` as (relpath, error) — "." is the root itself. bugs.md #24:
    it used to be skipped silently, so its files looked absent from that side."""
    out = {}

    def _fail(exc):
        rel = (os.path.relpath(exc.filename, lp(root)).replace("\\", "/")
               if exc.filename else ".")
        if failed is not None and _relevant(rel + "/"):    # noise dirs are skipped anyway
            failed.append((rel, f"{type(exc).__name__}: {exc.strerror or exc}"))

    for dp, _dn, fn in os.walk(lp(root), onerror=_fail):
        for f in fn:
            full = os.path.join(dp, f)
            # os.walk(lp(root)) yields \\?\-prefixed dirpaths on Windows; the relpath
            # `start` must carry the same prefix or relpath raises ValueError (mount
            # mismatch). lp() is a no-op off Windows and idempotent, so this is safe.
            rel = os.path.relpath(full, lp(root)).replace("\\", "/")
            out[rel] = full
    return out


def _under(rel, prefixes):
    """True if `rel` is, or lies beneath, one of the (relative) paths in `prefixes`."""
    return any(p == "." or rel == p or rel.startswith(p + "/") for p in prefixes)


def _sha(path):
    h = hashlib.sha256()
    with open(lp(path), "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _kind(rel):
    low = rel.lower()
    if low.endswith(".jar"):
        return "dependency"
    if low.endswith(_SCRIPT_EXT):
        return "script"
    if low.endswith(_TEXTY_EXT):
        return "text"
    return "content"


def _relevant(rel):
    """A file whose change is worth surfacing (skip JRE/doc/sample noise)."""
    return not any(rel.startswith(p) for p in _SKIP_TOP)


def _noise_entry(rel, path, change="changed"):
    """db2_bugs.md DB2-21: a file under a noise folder (_SKIP_TOP: the bundled JDK/JRE,
    samples, docs) is not analyzed, but a changed one is listed, never counted identical
    — and a changed ELF there no longer goes to Stage 2 (a JDK libjvm.so was sent to two
    full Ghidra analyses)."""
    native = os.path.isfile(lp(path)) and _elf.is_elf(path)
    return {"name": rel, "pretty": rel, "change": change,
            "kind": "native" if native else _kind(rel),
            "size": os.path.getsize(lp(path)) if os.path.isfile(lp(path)) else 0}


def _noise_one_sided(rels, base_dir, tag):
    return [_noise_entry(rel, os.path.join(base_dir, rel), tag)
            for rel in rels if not _relevant(rel)]


def _same_code(rel, pa, pb, entry):
    """Classify an ELF pair with identical code: ("data", entry) when its loaded data
    differs (db2_bugs.md DB2-22: a constant or table fix used to be "rebuild only"), else
    ("rebuild", None)."""
    dd = _elf.data_section_diff(pa, pb)
    if dd:
        return "data", {**entry, **dd}
    return "rebuild", None


_SYMBOL_ORDER = ("symtab", "dynsym", "none", "unsupported")


def _code_entry(entry, pa, pb):
    """A code-changed ELF routed to Stage 2, with the weaker of its two sides' function
    symbols (db2_bugs.md DB2-2): "dynsym" = exported functions only, "none" /
    "unsupported" = Stage 2 can't diff it. Known before Stage 2 runs, not hours into it."""
    entry["route"] = "stage2"
    entry["symbols"] = max((_elf.symbol_source(pa), _elf.symbol_source(pb)),
                           key=_SYMBOL_ORDER.index)
    return entry


def _symbol_counts(code_changed):
    return {"code_changed_exported_symbols_only":
                sum(1 for e in code_changed if e.get("symbols") == "dynsym"),
            "code_changed_without_symbols":
                sum(1 for e in code_changed if e.get("symbols") in ("none", "unsupported"))}


def _data_rank(e):
    """Changes that look like real data first: not strings-only, then most bytes changed."""
    return (e["strings_only"], -(e["data_bytes_changed"] or 0), e["name"])


def _classify_changed(rel, pa, pb):
    """Route one byte-changed file: noise folder -> listed only; ELF -> exec-section
    (code vs data vs rebuild); else kind."""
    if not _relevant(rel):
        return "noise", _noise_entry(rel, pb if os.path.isfile(lp(pb)) else pa)
    entry = {"name": rel, "pretty": rel, "size": os.path.getsize(lp(pb)) if os.path.isfile(lp(pb)) else 0}
    if os.path.isfile(lp(pa)) and os.path.isfile(lp(pb)) and _elf.is_elf(pa) and _elf.is_elf(pb):
        ca, cb = _elf.exec_section_sigs(pa), _elf.exec_section_sigs(pb)
        if ca is not None and cb is not None:
            if ca != cb:
                return "code", _code_entry(entry, pa, pb)
            return _same_code(rel, pa, pb, entry)
    kind = _kind(rel)
    entry["kind"] = kind
    entry["route"] = "stage1" if kind in ("dependency", "script", "text") else "other"
    return "content", entry


def _one_sided(rels, base_dir, tag, errors):
    """Every relevant file present on only one side (bugs.md #3): triage used to record only
    added/removed jars and scripts (for Stage 1), so an added or removed library/binary
    vanished from the result without a trace. Informational — Stage 2 needs both sides."""
    out = []
    for rel in rels:
        if not _relevant(rel):
            continue
        p = os.path.join(base_dir, rel)
        try:
            if not os.path.isfile(lp(p)):
                continue
            kind = "native" if _elf.is_elf(p) else _kind(rel)
            out.append({"name": rel, "pretty": rel, "kind": kind, "change": tag,
                        "size": os.path.getsize(lp(p))})
        except Exception as exc:
            errors.append({"name": rel, "error": str(exc)})
    return out


def _from_manifest(manifest, prior_dir, fixed_dir, workdir, progress=None):
    """Stage 0 from acquire's member-diff manifest: only examine the byte-changed set (identical
    files were pruned). The ELF exec-section refinement still runs on changed .so."""
    code_changed, rebuild_only, content_changed, errors = [], [], [], []
    noise_changed, data_changed = [], []
    for rel in manifest.get("changed", []):
        try:
            cls, entry = _classify_changed(rel, os.path.join(prior_dir, rel), os.path.join(fixed_dir, rel))
        except Exception as exc:
            # One unreadable/corrupt file must not abort the whole triage run.
            errors.append({"name": rel, "error": str(exc)})
            continue
        if cls == "code":
            code_changed.append(entry)
        elif cls == "rebuild":
            rebuild_only.append(rel)
        elif cls == "content":
            content_changed.append(entry)
        elif cls == "data":
            data_changed.append(entry)
        elif cls == "noise":
            noise_changed.append(entry)

    def _extra(rels, base_dir, tag):
        out = []
        for rel in rels:
            if not _relevant(rel):
                continue
            k = _kind(rel)
            if k not in ("dependency", "script"):
                continue
            p = os.path.join(base_dir, rel)
            out.append({"name": rel, "pretty": rel, "kind": k, "change": tag,
                        "size": os.path.getsize(lp(p)) if os.path.isfile(lp(p)) else 0,
                        "route": "stage1"})
        return out
    added_e = _extra(manifest.get("added", []), fixed_dir, "added")
    removed_e = _extra(manifest.get("removed", []), prior_dir, "removed")
    content_changed.extend(added_e + removed_e)
    added_all = _one_sided(manifest.get("added", []), fixed_dir, "added", errors)
    removed_all = _one_sided(manifest.get("removed", []), prior_dir, "removed", errors)
    noise_changed += (_noise_one_sided(manifest.get("added", []), fixed_dir, "added")
                      + _noise_one_sided(manifest.get("removed", []), prior_dir, "removed"))
    code_changed.sort(key=lambda e: -e["size"])
    data_changed.sort(key=_data_rank)
    noise_changed.sort(key=lambda e: e["name"])
    result = {
        # "total" = files present on BOTH sides (identical + changed) — added/removed are
        # counted separately, matching the full-walk path's total=len(common).
        "counts": {"identical": manifest.get("identical", 0), "rebuild_only": len(rebuild_only),
                   "code_changed": len(code_changed), "content_changed": len(content_changed),
                   "data_changed": len(data_changed), "noise_changed": len(noise_changed),
                   **_symbol_counts(code_changed),
                   "added": len(added_all), "removed": len(removed_all), "errors": len(errors),
                   "total": manifest.get("identical", 0) + len(manifest.get("changed", []))},
        "code_changed": code_changed, "content_changed": content_changed,
        "added": added_all, "removed": removed_all,      # every one-sided file (incl. ELF)
        "rebuild_only": rebuild_only, "errors": errors,
        "data_changed": data_changed,      # same code, different loaded data (DB2-22)
        "noise_changed": noise_changed,    # JDK/samples/docs: listed, not analyzed (DB2-21)
    }
    out = os.path.join(workdir, "stage0")
    os.makedirs(lp(out), exist_ok=True)
    with open(lp(os.path.join(out, "changed_files.json")), "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    if progress:
        progress(100, "Stage 0 complete (from member-diff manifest)")
    return result


def run(prior_dir, fixed_dir, workdir, progress=None):
    mpath = os.path.join(workdir, "acquire", "manifest.json")
    if os.path.isfile(lp(mpath)):
        try:
            with open(lp(mpath), encoding="utf-8") as fh:
                data = fh.read()
            manifest = json.loads(data)
            # #14: only if it describes exactly these trees as they are now
            # ...and only if neither tree was modified since (#48)
            if (_state.manifest_applies(manifest, prior_dir, fixed_dir)
                    and _state.manifest_snapshot_matches(manifest, prior_dir, fixed_dir)):
                return _from_manifest(manifest, prior_dir, fixed_dir, workdir, progress)
        except Exception:
            pass   # fall back to the full walk on any manifest problem
    if progress:
        progress(2, "Indexing files")
    p_failed, f_failed = [], []
    pri = _rel_files(prior_dir, p_failed)
    fix = _rel_files(fixed_dir, f_failed)

    code_changed, rebuild_only, content_changed, identical, errors = [], [], [], [], []
    noise_changed, data_changed = [], []
    for side, failed in (("prior", p_failed), ("fixed", f_failed)):
        for rel, err in failed:
            errors.append({"name": rel, "error": f"{side} tree could not be indexed: {err}"})
    common = sorted(set(pri) & set(fix))
    # a path missing from a side because THAT side couldn't be listed is not evidence it
    # was added/removed — it's reported in errors above instead (#24)
    p_unknown, f_unknown = [r for r, _e in p_failed], [r for r, _e in f_failed]
    added = sorted(r for r in set(fix) - set(pri) if not _under(r, p_unknown))
    removed = sorted(r for r in set(pri) - set(fix) if not _under(r, f_unknown))
    total = len(common) or 1
    # A pruned acquired tree had its byte-identical files deleted; that's only sound with the
    # manifest it was pruned for, which didn't apply here. Walking it anyway makes every
    # pruned file look added/removed — say so (counts as a partial failure, exit 3) rather
    # than present the comparison as reliable.
    # Trees pruned against EACH OTHER are still sound to walk (identical files are gone from
    # both — "absent on both sides" is "unchanged"): that's the fallback when a manifest
    # doesn't match its trees any more (#48), so it isn't flagged.
    mutual = _state.mutually_pruned(prior_dir, fixed_dir)
    for side, d in (("prior", prior_dir), ("fixed", fixed_dir)):
        if not mutual and _state.pruned_tree_record(d):
            errors.append({"name": d, "error":
                           f"{side} tree was pruned (identical files deleted) against a different "
                           f"partner build; files may wrongly appear added/removed — re-acquire "
                           f"both sides together or supply unpruned trees"})
    for i, rel in enumerate(common):
        try:
            pa, pb = pri[rel], fix[rel]
            entry = {"name": rel, "pretty": rel, "size": os.path.getsize(lp(pb))}
            if not _relevant(rel):
                # DB2-21: listed when changed, not analyzed — and never counted identical
                if (os.path.getsize(lp(pa)) != os.path.getsize(lp(pb))
                        or _sha(pa) != _sha(pb)):
                    noise_changed.append(_noise_entry(rel, pb))
                else:
                    identical.append(rel)
                _tick(progress, i, total)
                continue
            if _elf.is_elf(pa) and _elf.is_elf(pb):
                ca, cb = _elf.exec_section_sigs(pa), _elf.exec_section_sigs(pb)
                if ca is not None and cb is not None:
                    if ca != cb:
                        code_changed.append(_code_entry(entry, pa, pb))
                    # bugs.md #59: same code but different bytes is rebuild_only whether or
                    # not the size changed. A same-size data-only change (.rodata/.data,
                    # string or symbol tables) used to be counted as identical, so the file
                    # left no trace; MSSQL triage already hashes this case. DB2-22: when the
                    # loaded data itself differs it is data_changed, not rebuild noise.
                    elif (os.path.getsize(lp(pa)) != os.path.getsize(lp(pb))
                          or _sha(pa) != _sha(pb)):
                        cls, dentry = _same_code(rel, pa, pb, entry)
                        if cls == "data":
                            data_changed.append(dentry)
                        else:
                            rebuild_only.append(rel)
                    else:
                        identical.append(rel)
                    _tick(progress, i, total)
                    continue
            # non-ELF (or unparseable): size-first, then sha for every same-size file whose
            # change would be surfaced. bugs.md #49: the sha used to be skipped unless the
            # kind was dependency/script/text, so a same-size generic payload (or an ELF
            # whose sections couldn't be parsed) with different bytes counted as identical.
            sizes_differ = os.path.getsize(lp(pa)) != os.path.getsize(lp(pb))
            kind = _kind(rel)
            changed = sizes_differ or _sha(pa) != _sha(pb)
            if changed:
                entry["kind"] = kind
                entry["route"] = "stage1" if kind in ("dependency", "script", "text") else "other"
                content_changed.append(entry)
            else:
                identical.append(rel)
        except Exception as exc:
            # One unreadable/corrupt file must not abort the whole triage run.
            errors.append({"name": rel, "error": str(exc)})
        _tick(progress, i, total)

    # added/removed jars & scripts feed Stage 1 (version bumps = add+remove pair)
    def _extra(rels, src, tag):
        out = []
        for rel in rels:
            if not _relevant(rel):
                continue
            k = _kind(rel)
            if k not in ("dependency", "script"):
                continue
            try:
                size = os.path.getsize(lp(src[rel]))
            except OSError as exc:
                errors.append({"name": rel, "error": str(exc)})
                continue
            out.append({"name": rel, "pretty": rel, "kind": k, "change": tag,
                        "size": size, "route": "stage1"})
        return out

    added_e = _extra(added, fix, "added")
    removed_e = _extra(removed, pri, "removed")
    # surface add/remove alongside changed content so Stage-0 shows the full Stage-1 set
    content_changed.extend(added_e + removed_e)
    added_all = _one_sided(added, fixed_dir, "added", errors)
    removed_all = _one_sided(removed, prior_dir, "removed", errors)
    noise_changed += (_noise_one_sided(added, fixed_dir, "added")
                      + _noise_one_sided(removed, prior_dir, "removed"))

    code_changed.sort(key=lambda e: -e["size"])
    data_changed.sort(key=_data_rank)
    noise_changed.sort(key=lambda e: e["name"])
    result = {
        "counts": {"identical": len(identical), "rebuild_only": len(rebuild_only),
                   "code_changed": len(code_changed), "content_changed": len(content_changed),
                   "data_changed": len(data_changed), "noise_changed": len(noise_changed),
                   **_symbol_counts(code_changed),
                   "added": len(added_all), "removed": len(removed_all), "errors": len(errors),
                   "total": len(common)},
        "code_changed": code_changed,          # ELF code change -> Stage 2
        "added": added_all, "removed": removed_all,   # every one-sided file (incl. ELF)
        "content_changed": content_changed,    # jars/scripts (incl add/remove) -> Stage 1
        "rebuild_only": rebuild_only,
        "data_changed": data_changed,          # same code, different loaded data (DB2-22)
        "noise_changed": noise_changed,        # JDK/samples/docs: listed, not analyzed (DB2-21)
        "errors": errors,
    }
    out = os.path.join(workdir, "stage0")
    os.makedirs(lp(out), exist_ok=True)
    with open(lp(os.path.join(out, "changed_files.json")), "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    if progress:
        progress(100, "Stage 0 complete")
    return result


def _tick(progress, i, total):
    if progress and (i % 200 == 0 or i + 1 == total):
        progress(min(99, int(100 * (i + 1) / total)), f"Comparing files ({i + 1}/{total})")