"""Stage 1 — readable diff for DB2 (bundled dependencies + scripts), fully offline.

DB2 ships no product source (the engine fix is compiled C -> Stage 2). The readable
surfaces that DO carry fixes are:
  * bundled third-party libraries — a security fix is a version bump, and the version
    lives in the JAR filename (or its MANIFEST). A bump is an add+remove pair on
    different filenames, so we pair JARs by artifact stem across the two builds. This
    directly catches e.g. commons-configuration2 2.10.1 -> 2.15.0.
  * product scripts (.py / .sh) — script-class fixes (command injection, temp files,
    privilege) diff as plain text.

Output: <workdir>/stage1/modules_diff.json (+ per-item .diff/.pair.json) — the same
shape the detail template + /split renderer consume (readable_files[]).
"""
import difflib
import filecmp
import hashlib
import json
import os
import re
import zipfile

from ._paths import lp, safe_name

_SKIP = ("samples/", "java/jdk64/", "java/jre/", "infopop/", "doc/")
_SCRIPT_EXT = (".py", ".sh", ".pl", ".ksh")
_VER_RE = re.compile(r"^(?P<stem>.+?)-(?P<ver>\d[0-9A-Za-z.]*(?:[._-][0-9A-Za-z]+)*)\.jar$")


def _safe(name):
    return safe_name(name, 120)


def _relevant(rel):
    return not any(rel.startswith(p) for p in _SKIP)


def _walk(root, pred):
    out = {}
    for dp, _dn, fn in os.walk(lp(root)):
        for f in fn:
            # walk root is lp()-prefixed; relpath `start` must match or it raises
            # ValueError on Windows (mount mismatch). lp() is idempotent / POSIX no-op.
            rel = os.path.relpath(os.path.join(dp, f), lp(root)).replace("\\", "/")
            if _relevant(rel) and pred(rel):
                out[rel] = os.path.join(dp, f)
    return out


def _manifest_version(jar_path):
    """Implementation-Version / Bundle-Version from a JAR's MANIFEST, else None."""
    try:
        with zipfile.ZipFile(lp(jar_path)) as z:
            data = z.read("META-INF/MANIFEST.MF").decode("latin-1", "replace")
        for key in ("Implementation-Version", "Bundle-Version", "Specification-Version"):
            m = re.search(rf"(?im)^{key}:\s*(.+)$", data)
            if m:
                return m.group(1).strip()
    except Exception:
        pass
    return None


def _artifact(rel, full):
    """(stem, version) for a jar: version from filename, else MANIFEST, else None."""
    base = os.path.basename(rel)
    m = _VER_RE.match(base)
    if m:
        return m.group("stem"), m.group("ver")
    return base[:-4], _manifest_version(full)


def _jar_index(root):
    """[(stem, version, rel, full)] for every jar under root."""
    return [(*_artifact(rel, full), rel, full)
            for rel, full in sorted(_walk(root, lambda r: r.lower().endswith(".jar")).items())]


def _pair_jars(pj, fj):
    """Pair jars across builds: same directory + same artifact stem first, then stem alone
    for what's left (a jar that moved directory in a version bump still pairs as a bump).
    The old index kept only the FIRST jar per stem, so a second copy of an artifact (the same
    library bundled in two places) was never compared at all (bugs.md #16 follow-up).
    Returns [(prior_entry or None, fixed_entry or None)]."""
    def key(e):
        return (os.path.dirname(e[2]), e[0])
    pairs, used_p, used_f = [], set(), set()
    fmap = {}
    for j, e in enumerate(fj):
        fmap.setdefault(key(e), []).append(j)
    for i, e in enumerate(pj):
        cands = [j for j in fmap.get(key(e), []) if j not in used_f]
        if cands:
            used_p.add(i)
            used_f.add(cands[0])
            pairs.append((e, fj[cands[0]]))
    by_stem = {}
    for j, e in enumerate(fj):
        if j not in used_f:
            by_stem.setdefault(e[0], []).append(j)
    for i, e in enumerate(pj):
        if i in used_p:
            continue
        cands = by_stem.get(e[0], [])
        if cands:
            j = cands.pop(0)
            used_p.add(i)
            used_f.add(j)
            pairs.append((e, fj[j]))
    pairs += [(e, None) for i, e in enumerate(pj) if i not in used_p]
    pairs += [(None, e) for j, e in enumerate(fj) if j not in used_f]
    return sorted(pairs, key=lambda pf: ((pf[0] or pf[1])[0], (pf[0] or pf[1])[2]))


_SIG_RE = re.compile(r"(?i)^META-INF/(MANIFEST\.MF|[^/]+\.(SF|RSA|DSA|EC))$")


def _jar_content(full):
    """{entry: (size, sha256)} for a jar's entries, excluding the manifest and signature
    files (build dates/signatures churn on every rebuild). None if the jar can't be read.

    bugs.md #33: the identity used to be the zip directory's (CRC-32, size), which a
    different payload can share — CRC-32 is not collision-resistant, and a crafted package
    can match it deliberately — so such a change was reported as "no change". Entries are
    now hashed from their actual bytes (reading them also makes zipfile verify the CRC, so
    a corrupt entry is a read error, not a silent match). The caller skips byte-identical
    jars before getting here, so only genuinely differing jars are decompressed."""
    try:
        out = {}
        with zipfile.ZipFile(lp(full)) as z:
            for i in z.infolist():
                if i.is_dir() or _SIG_RE.match(i.filename):
                    continue
                h = hashlib.sha256()
                with z.open(i) as fh:
                    for blk in iter(lambda: fh.read(1 << 20), b""):
                        h.update(blk)
                out[i.filename] = (i.file_size, h.hexdigest())
        return out
    except Exception:
        return None


_MAX_CLASSES_PER_JAR = 200      # changed outer classes decompiled per jar (DB2-23)


def _outer_class(entry):
    """'a/b/Foo$Bar.class' -> 'a/b/Foo': a nested class belongs to its outer class's
    source file, which is what CFR writes and what a reader compares."""
    stem = entry[:-len(".class")]
    d, _, base = stem.rpartition("/")
    base = base.split("$", 1)[0]
    return f"{d}/{base}" if d else base


def _is_class(z, name):
    with z.open(name) as fh:
        return fh.read(4) == b"\xca\xfe\xba\xbe"


def _decompile_classes(jar, outers, out_dir, tmp):
    """{outer: source} for the classes of `outers` (and their nested classes) in `jar`,
    decompiled by CFR (javap when CFR is absent) from a jar holding only them, so the cost
    follows the changed classes, not the jar's size. Raises DecompileFailed."""
    from ..oracle import java_decompile as jd
    mini = os.path.join(tmp, os.path.basename(out_dir) + ".jar")
    n = 0
    with zipfile.ZipFile(lp(jar)) as z, zipfile.ZipFile(lp(mini), "w") as m:
        for i in z.infolist():
            if i.filename.endswith(".class") and _outer_class(i.filename) in outers:
                m.writestr(i.filename, z.read(i))
                n += 1
    if not n:
        return {}
    jd.decompile_jar(mini, out_dir)
    out = {}
    for outer in outers:
        p = os.path.join(out_dir, *outer.split("/")) + ".java"
        if os.path.isfile(lp(p)):
            with open(lp(p), encoding="utf-8", errors="replace") as fh:
                out[outer] = fh.read()
    return out


def _class_cards(out, stem, rel, pfull, ffull, pc, fc, used_bases):
    """db2_bugs.md DB2-23: the source-level diff of the classes that changed inside a jar
    whose version string did not (an IBM jar fixed in place). Returns (cards, capped,
    error). The entry-name card for the jar is written by the caller either way."""
    import tempfile
    from ..oracle import java_decompile as jd
    changed = [k for k in sorted(pc.keys() | fc.keys())
               if k.endswith(".class") and pc.get(k) != fc.get(k)]
    # only real class files (magic CAFEBABE): anything else named .class can't be
    # decompiled and stays in the jar's entry list
    classes = []
    if changed:
        try:
            with zipfile.ZipFile(lp(pfull)) as pz, zipfile.ZipFile(lp(ffull)) as fz:
                have = (set(pz.namelist()), set(fz.namelist()))
                for k in changed:
                    if any(k in names and _is_class(z, k) for z, names in zip((pz, fz), have)):
                        classes.append(k)
        except (OSError, zipfile.BadZipFile) as exc:
            return [], 0, f"could not read the jar: {exc}"
    outers = sorted({_outer_class(k) for k in classes})
    capped = max(0, len(outers) - _MAX_CLASSES_PER_JAR)
    outers = set(outers[:_MAX_CLASSES_PER_JAR])
    if not outers:
        return [], 0, None
    try:
        with tempfile.TemporaryDirectory(prefix="pdff_jar_") as tmp:
            src = {side: _decompile_classes(jar, outers, os.path.join(tmp, side), tmp)
                   for side, jar in (("prior", pfull), ("fixed", ffull))}
    except jd.DecompileFailed as exc:
        return [], capped, str(exc)
    cards = []
    for outer in sorted(outers):
        ptxt, ftxt = src["prior"].get(outer, ""), src["fixed"].get(outer, "")
        if ptxt == ftxt:
            continue            # e.g. only a timestamp or debug attribute changed
        change = "modified" if ptxt and ftxt else ("added" if ftxt else "removed")
        obj = f"{stem}: {outer.replace('/', '.')}"
        base = "jcls__" + _safe(f"{stem}_{outer}")
        if base in used_bases:
            base = "jcls__" + _safe(f"{rel}_{outer}".replace("/", "_"))
        used_bases.add(base)
        _write_pair(out, base, obj, ptxt, ftxt, n=3)
        cards.append({"object": obj, "file": base + ".diff", "pair": base + ".pair.json",
                      "src": rel, "kind": "java-class", "change": change})
    return cards, capped, None


def _same_bytes(a, b):
    """True if files `a` and `b` have identical content (False if either can't be read)."""
    try:
        return (os.path.getsize(lp(a)) == os.path.getsize(lp(b))
                and filecmp.cmp(lp(a), lp(b), shallow=False))
    except OSError:
        return False


def _write_pair(out, base, obj, prior_txt, fixed_txt, n):
    diff = "".join(difflib.unified_diff(
        prior_txt.splitlines(keepends=True), fixed_txt.splitlines(keepends=True),
        fromfile=f"{obj} (prior)", tofile=f"{obj} (fixed)", n=n))
    with open(lp(os.path.join(out, base + ".diff")), "w", encoding="utf-8") as f:
        f.write(diff)
    with open(lp(os.path.join(out, base + ".pair.json")), "w", encoding="utf-8") as f:
        json.dump({"object": obj, "prior": prior_txt, "fixed": fixed_txt, "truncated": False}, f)


def run(prior_dir, fixed_dir, workdir, stage0=None, progress=None):
    out = os.path.join(workdir, "stage1")
    os.makedirs(lp(out), exist_ok=True)
    readable, errors = [], []

    # ---- bundled dependency version diff ----
    if progress:
        progress(15, "Diffing bundled dependencies")
    used_bases = set()
    class_cards, classes_capped = [], 0       # source diffs of changed classes (DB2-23)
    class_failures = []                       # jars whose changed classes CFR couldn't do
    pj, fj = _jar_index(prior_dir), _jar_index(fixed_dir)
    for pe, fe in _pair_jars(pj, fj):
        stem = (pe or fe)[0]
        _ps, pv, prel, pfull = pe or (None, None, None, None)
        _fs, fv, frel, ffull = fe or (None, None, None, None)
        if pe and fe:
            if (pv or "") == (fv or ""):
                # bugs.md #16: equal (or both absent) version strings used to mean "no
                # change" unconditionally, so a fix shipped without a version bump was
                # dropped. Compare entry contents; only identical contents are skipped.
                if _same_bytes(pfull, ffull):
                    continue
                pc, fc = _jar_content(pfull), _jar_content(ffull)
                if pc is not None and pc == fc:
                    continue
                if pc is None or fc is None:
                    errors.append({"name": frel, "error": "could not read jar to compare "
                                   "contents (same version string on both sides)"})
                    continue
                mod = sorted(k for k in pc.keys() & fc.keys() if pc[k] != fc[k])
                add = sorted(fc.keys() - pc.keys())
                rem = sorted(pc.keys() - fc.keys())
                obj = f"{stem}: {pv or 'unversioned'} (contents changed)"
                prior_txt = (f"{os.path.basename(prel)}\nversion: {pv or 'unknown'}\n"
                             + "".join(f"  {k}\n" for k in mod + rem))
                fixed_txt = (f"{os.path.basename(frel)}\nversion: {fv or 'unknown'}\n"
                             + "".join(f"  {k}\n" for k in mod + add))
                change = "content-changed"
                cards, capped, err = _class_cards(out, stem, frel, pfull, ffull, pc, fc,
                                                  used_bases)
                class_cards.extend(cards)
                classes_capped += capped
                if err:
                    # like failed pseudo-C: the add-on is missing, the jar's entry-list
                    # card (the evidence) is not, so this is reported, not a failed run
                    class_failures.append({"name": frel, "error": err})
            else:
                obj = f"{stem}: {pv or '?'} → {fv or '?'}"
                prior_txt = f"{os.path.basename(prel)}\nversion: {pv or 'unknown'}\n"
                fixed_txt = f"{os.path.basename(frel)}\nversion: {fv or 'unknown'}\n"
                change = "bumped"
        elif fe:
            obj, prior_txt, fixed_txt, change = f"{stem}: (added {fv or ''})".strip(), "", \
                f"{os.path.basename(frel)}\nversion: {fv or 'unknown'}\n", "added"
        else:
            obj, prior_txt, fixed_txt, change = f"{stem}: (removed {pv or ''})".strip(), \
                f"{os.path.basename(prel)}\nversion: {pv or 'unknown'}\n", "", "removed"
        base = "dep__" + _safe(stem)
        if base in used_bases:                # same stem in two dirs -> distinct card files
            base = "dep__" + _safe((frel or prel).replace("/", "_"))
        used_bases.add(base)
        _write_pair(out, base, obj, prior_txt, fixed_txt, n=3)
        readable.append({"object": obj, "file": base + ".diff", "pair": base + ".pair.json",
                         "src": frel or prel, "kind": "dependency", "change": change})
    readable.extend(class_cards)

    # ---- product script text diff ----
    if progress:
        progress(60, "Diffing scripts")
    ps = _walk(prior_dir, lambda r: r.lower().endswith(_SCRIPT_EXT))
    fs = _walk(fixed_dir, lambda r: r.lower().endswith(_SCRIPT_EXT))
    # Union, not intersection (bugs.md #3): an added script (e.g. a new hardening wrapper) or
    # a removed one is as much a readable change as an edited one — it used to be dropped.
    for rel in sorted(set(ps) | set(fs)):
        try:
            ta = tb = ""
            if rel in ps:
                with open(lp(ps[rel]), encoding="latin-1") as fh:
                    ta = fh.read()
            if rel in fs:
                with open(lp(fs[rel]), encoding="latin-1") as fh:
                    tb = fh.read()
            change = "modified" if (rel in ps and rel in fs) else ("added" if rel in fs else "removed")
            if change == "modified" and ta == tb:
                continue
            base = "script__" + _safe(rel)
            _write_pair(out, base, rel, ta, tb, n=3)
            readable.append({"object": rel, "file": base + ".diff", "pair": base + ".pair.json",
                             "src": rel, "kind": "script", "change": change})
        except Exception as exc:
            # One unreadable/vanished script must not abort the whole Stage 1 run — record
            # it and keep going (the same per-item isolation Stage 0 already applies).
            errors.append({"name": rel, "error": str(exc)})

    if progress:
        progress(95, "Writing Stage 1 result")
    dep_n = sum(1 for r in readable if r["kind"] == "dependency")
    cls_n = sum(1 for r in readable if r["kind"] == "java-class")
    result = {
        "available": True,
        "counts": {"prior": len(pj), "fixed": len(fj), "changed": 0, "added": 0, "removed": 0,
                   "truncated": 0, "readable_changed": len(readable),
                   "dependencies": dep_n, "java_classes": cls_n,
                   "java_classes_capped": classes_capped,
                   "java_classes_failed": len(class_failures),
                   "scripts": sum(1 for r in readable if r["kind"] == "script"),
                   "errors": len(errors)},
        "changed": [], "added": [], "removed": [],
        "files": [],                              # no readable system-objects for DB2
        "readable_files": readable, "errors": errors,
        "class_decompile_failures": class_failures,
    }
    with open(lp(os.path.join(out, "modules_diff.json")), "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    if progress:
        progress(100, "Stage 1 complete")
    return result