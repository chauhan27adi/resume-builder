// Headless BinExport v2 exporter for patch_differ_cli Track 1 (bugs.md #54).
//
// The extension's own BinExport.java asks for TWO script arguments: an output file
// (askFile) and an IDA-compatibility option list (askChoices). Headless Ghidra cannot answer
// "no options": GhidraScript.parseChoices() throws when no listed choice matches, and an
// empty answer fails in getValues(). The empty "" the pipeline used to pass never even
// arrived — analyzeHeadless.bat stops reading its arguments at the first empty one (and so
// also dropped the -noanalysis after it). This script takes ONLY the output path and builds
// the export exactly as BinExport.java does with no options selected: Ghidra's own
// addresses (no image-base subtraction), Ghidra mnemonics, no namespace prefixes — the
// address scheme the Stage 2 backends map BinDiff matches back with.
//
// Invoked by patch_differ_cli/_bindiff.py:
//   analyzeHeadless <proj> bindiff_proj -process <program> -scriptPath <this dir>
//       -postScript PdffBinExport.java <out.BinExport> -noanalysis
//
// Any failure throws, so HeadlessAnalyzer logs "REPORT SCRIPT ERROR" — the caller checks
// for that (Ghidra itself can still exit 0) and for a non-empty output file.
import com.google.security.binexport.BinExport2Builder;
import com.google.security.zynamics.BinExport.BinExport2;
import ghidra.app.script.GhidraScript;
import java.io.File;
import java.io.FileOutputStream;

public class PdffBinExport extends GhidraScript {
    @Override
    public void run() throws Exception {
        String[] args = getScriptArgs();
        if (args.length != 1 || args[0].isEmpty()) {
            throw new IllegalArgumentException("usage: PdffBinExport <output.BinExport>");
        }
        if (currentProgram == null) {
            throw new IllegalStateException("no program is open");
        }
        File out = new File(args[0]);
        BinExport2 proto = new BinExport2Builder(currentProgram, currentProgram.getMemory()).build();
        try (FileOutputStream os = new FileOutputStream(out)) {
            proto.writeTo(os);
        }
        println("PdffBinExport wrote " + out + " (" + out.length() + " bytes)");
    }
}
