// Shared headless single-function decompiler for the patch-differ "Decompile to C"
// (MSSQL / DB2 / Oracle Stage 2 — bug.md MSSQL-T2-2). It lives under db2/ghidra/ for
// historical reasons; it is NOT DB2-specific and is driven by the backend-neutral
// patch_differ_cli._decompile (decompile_pair), not by db2/decompile.py (which is dead —
// bug.md DB2-T1-4).
//
// Each imported program is a TINY raw blob = the exact bytes of ONE changed function,
// loaded at a fixed base. Each backend supplies the carved blob: MSSQL carves PE
// .pdata/PDB hot+cold chunks into one blob at their true offsets with int3-filled gaps
// (mssql/stage2.py::_extract_func_bytes, bugs.md #25); DB2/Oracle pass one contiguous
// ELF blob per function. We disassemble + create the function at the base, run Ghidra's
// decompiler, and, ONLY on success, write the C to <outDir>/<programName>.c.
// On any failure, no .c file is written at all (just a log line) — the caller
// (patch_differ_cli._decompile) already treats a missing file as "no output
// for this side", so a failure must never be written as if it were real,
// successful output. Invoked by patch_differ_cli/_decompile.py::decompile_pair:
//   analyzeHeadless <proj> <name> -import <dir with programs "prior" and/or "fixed">
//       -processor x86:LE:64:default -loader BinaryLoader -loader-baseAddr 0x100000
//       -scriptPath <this dir> -postScript DecompileFunc.java <outDir> [<ctxDir>]
//       -noanalysis -deleteProject
// (the programs have no extension, so Ghidra's program name is exactly "prior"/"fixed".)
//
// The postScript runs once per imported program (prior, fixed), so a single
// analyzeHeadless invocation decompiles both sides (one JVM startup).
//
// Optional context (db2_bugs.md DB2-16 / DB2-17): <ctxDir>/<programName>.ctx, lines
//   base <hex>                  the function's real address: the code block is moved there,
//                               so relative calls and RIP-relative data land where they
//                               really point (the fixed 0x100000 base made them bogus)
//   block <hexaddr> <hexbytes>  read-only data the function references (e.g. .rodata jump
//                               tables, strings), loaded read-only at its real address so
//                               the decompiler can resolve a switch and show constants
// A context line that can't be applied is logged and skipped: the decompile goes on
// without it, exactly as it would have without a context file.
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import ghidra.app.cmd.function.CreateFunctionCmd;
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.mem.MemoryBlock;

public class DecompileFunc extends GhidraScript {
    @Override
    public void run() throws Exception {
        String[] args = getScriptArgs();
        if (args.length < 1) {
            throw new IllegalArgumentException("usage: DecompileFunc <outDir> [<ctxDir>]");
        }
        String outDir = args[0];
        String name = currentProgram.getName();       // e.g. "prior" / "fixed"
        int dot = name.lastIndexOf('.');              // strip any extension for the .c name
        String outName = (dot > 0) ? name.substring(0, dot) : name;

        // Entry = start of the loaded blob. Raw Binary blocks aren't marked
        // executable, which blocks disassembly — grant r-x first.
        Address base = currentProgram.getMinAddress();
        MemoryBlock blk = currentProgram.getMemory().getBlock(base);
        if (blk != null) { blk.setRead(true); blk.setExecute(true); }

        if (args.length >= 2 && blk != null) {
            base = applyContext(Paths.get(args[1], outName + ".ctx"), blk, base);
        }

        disassemble(base);
        Function f = getFunctionAt(base);
        if (f == null) {
            CreateFunctionCmd cmd = new CreateFunctionCmd(base);
            cmd.applyTo(currentProgram, monitor);
            f = getFunctionAt(base);
        }
        if (f == null) {
            f = createFunction(base, outName);
        }

        // c stays null on ANY failure. The caller (patch_differ_cli._decompile) treats a
        // missing <outName>.c exactly like an empty decompile — never write one here on
        // failure, or the caller would mistake an error note for real decompiled output
        // (and, worse, two different failure reasons on the prior/fixed sides could look
        // like a genuine code difference to anything that diffs them).
        String c = null;
        String failReason = null;
        if (f == null) {
            failReason = "could not create a function at " + base;
        } else {
            DecompInterface d = new DecompInterface();
            try {
                d.openProgram(currentProgram);
                DecompileResults res = d.decompileFunction(f, 90, monitor);
                if (res != null && res.decompileCompleted()
                        && res.getDecompiledFunction() != null) {
                    c = res.getDecompiledFunction().getC();
                } else {
                    failReason = (res != null) ? res.getErrorMessage() : "no results";
                }
            } finally {
                d.dispose();
            }
        }

        if (c != null) {
            Files.write(Paths.get(outDir, outName + ".c"), c.getBytes("UTF-8"));
            println("DecompileFunc wrote " + outName + ".c (" + c.length() + " chars)");
        } else {
            println("DecompileFunc: " + outName + " decompilation failed: " + failReason);
        }
    }

    /** Apply the optional context file; returns the (possibly moved) code start. */
    private Address applyContext(Path ctx, MemoryBlock code, Address base) {
        if (!Files.isRegularFile(ctx)) {
            return base;
        }
        List<String> lines;
        try {
            lines = Files.readAllLines(ctx, StandardCharsets.US_ASCII);
        } catch (Exception e) {
            println("DecompileFunc: context not read (" + e.getMessage() + ")");
            return base;
        }
        for (String line : lines) {                    // the code first: blocks need its place
            String[] f = line.trim().split("\\s+");
            if (f.length == 2 && f[0].equals("base")) {
                try {
                    Address want = toAddr(Long.parseUnsignedLong(f[1], 16));
                    if (!want.equals(base)) {
                        currentProgram.getMemory().moveBlock(code, want, monitor);
                    }
                    base = code.getStart();
                } catch (Exception e) {
                    println("DecompileFunc: code not moved to " + f[1] + " (" + e.getMessage()
                            + "); decompiling at " + base);
                }
            }
        }
        int n = 0;
        for (String line : lines) {
            String[] f = line.trim().split("\\s+");
            if (f.length != 3 || !f[0].equals("block")) {
                continue;
            }
            try {
                Address at = toAddr(Long.parseUnsignedLong(f[1], 16));
                MemoryBlock b = createMemoryBlock("pdff_data_" + n, at, hex(f[2]), false);
                b.setRead(true);
                b.setWrite(false);                     // read-only: the decompiler may use it
                b.setExecute(false);
                n++;
            } catch (Exception e) {
                println("DecompileFunc: data block at " + f[1] + " skipped (" + e.getMessage()
                        + ")");
            }
        }
        println("DecompileFunc: context applied (code at " + base + ", " + n
                + " data block(s))");
        return base;
    }

    private static byte[] hex(String s) {
        if (s.length() % 2 != 0) {
            throw new IllegalArgumentException("odd hex length");
        }
        byte[] out = new byte[s.length() / 2];
        for (int i = 0; i < out.length; i++) {
            out[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2), 16);
        }
        return out;
    }
}
