"""Minimal, dependency-free ELF reader for Stage 0 code-section triage.

DB2's engine ships as Linux ELF shared objects (amd64). We only need the hashes of
the *executable* sections (`.text` + anything flagged SHF_EXECINSTR) so a rebuild's
version/rodata churn doesn't read as a real code change — the ELF analog of the
MSSQL PE `.text` compare in ``mssql/triage.py``. Written with raw ``struct`` (like the
resource-DB carve in ``mssql/stage1.py``) to avoid a new dependency.

Supports ELFCLASS32 and ELFCLASS64, little- and big-endian. Executable-section data
is read in chunks via seek — never the whole file — so hashing a 458 MB libdb2e stays
cheap on memory.
"""
import hashlib
import os
import struct

from ._paths import lp

_MAGIC = b"\x7fELF"
_SHF_ALLOC = 0x2
_SHF_EXECINSTR = 0x4
_SHT_PROGBITS = 1
_SHT_NOBITS = 8
_CHUNK = 1 << 20


def is_elf(path):
    try:
        with open(lp(path), "rb") as f:
            return f.read(4) == _MAGIC
    except OSError:
        return False


ET_REL, ET_EXEC, ET_DYN = 1, 2, 3


def elf_type(path):
    """ELF e_type (ET_REL / ET_EXEC / ET_DYN, ...) or None if unreadable / not ELF."""
    try:
        with open(lp(path), "rb") as f:
            h = f.read(18)
    except OSError:
        return None
    if len(h) < 18 or h[:4] != _MAGIC:
        return None
    return int.from_bytes(h[16:18], "little" if h[5] == 1 else "big")


class ElfParseError(Exception):
    """A file with the ELF magic that can't be parsed or is truncated."""


def exec_section_sigs(path):
    """Return {section_key: sha256_hex} for executable sections, or None if the file is
    not an ELF (no ELF magic / unsupported class). Raises ElfParseError for a file that
    has the ELF magic but is corrupt or truncated. Two ELFs with identical exec-section sigs have the same code even if
    their whole-file hashes differ (rebuild noise)."""
    magic_ok = False
    try:
        with open(lp(path), "rb") as f:
            ident = f.read(16)
            if ident[:4] != _MAGIC:
                return None
            magic_ok = True
            ei_class, ei_data = ident[4], ident[5]
            if ei_class not in (1, 2) or ei_data not in (1, 2):
                return None
            en = "<" if ei_data == 1 else ">"
            is64 = ei_class == 2

            # ELF header: pull section-header table offset/entsize/count/strtab-index.
            f.seek(0)
            hdr = f.read(64)
            if is64:
                e_shoff = struct.unpack_from(en + "Q", hdr, 0x28)[0]
                e_shentsize = struct.unpack_from(en + "H", hdr, 0x3A)[0]
                e_shnum = struct.unpack_from(en + "H", hdr, 0x3C)[0]
                e_shstrndx = struct.unpack_from(en + "H", hdr, 0x3E)[0]
            else:
                e_shoff = struct.unpack_from(en + "I", hdr, 0x20)[0]
                e_shentsize = struct.unpack_from(en + "H", hdr, 0x2E)[0]
                e_shnum = struct.unpack_from(en + "H", hdr, 0x30)[0]
                e_shstrndx = struct.unpack_from(en + "H", hdr, 0x32)[0]
            if not e_shoff or not e_shnum or not e_shentsize:
                raise ElfParseError("ELF has no section header table")

            # Read the whole section-header table.
            f.seek(e_shoff)
            sh_tab = f.read(e_shentsize * e_shnum)

            def sh(i):
                base = i * e_shentsize
                if is64:
                    name = struct.unpack_from(en + "I", sh_tab, base + 0)[0]
                    typ = struct.unpack_from(en + "I", sh_tab, base + 4)[0]
                    flags = struct.unpack_from(en + "Q", sh_tab, base + 8)[0]
                    off = struct.unpack_from(en + "Q", sh_tab, base + 24)[0]
                    size = struct.unpack_from(en + "Q", sh_tab, base + 32)[0]
                else:
                    name = struct.unpack_from(en + "I", sh_tab, base + 0)[0]
                    typ = struct.unpack_from(en + "I", sh_tab, base + 4)[0]
                    flags = struct.unpack_from(en + "I", sh_tab, base + 8)[0]
                    off = struct.unpack_from(en + "I", sh_tab, base + 16)[0]
                    size = struct.unpack_from(en + "I", sh_tab, base + 20)[0]
                return name, typ, flags, off, size

            # Section-name string table.
            if e_shstrndx >= e_shnum:
                raise ElfParseError("ELF section-name table index out of range")
            _, _, _, str_off, str_size = sh(e_shstrndx)
            f.seek(str_off)
            strtab = f.read(str_size)

            def name_at(n):
                end = strtab.find(b"\x00", n)
                return strtab[n:end].decode("latin-1", "replace") if end >= 0 else ""

            # Key by name + occurrence ("<name>", "<name>#2", ...), not name alone (bugs.md
            # #13: a later same-named exec section overwrote the earlier one's hash, so a
            # change confined to the first was invisible) — and NOT by section index, which
            # would shift whenever an unrelated non-code section is added/removed and turn
            # pure rebuild noise into a "code changed".
            sigs, seen = {}, {}
            file_size = os.fstat(f.fileno()).st_size
            for i in range(e_shnum):
                nm_off, typ, flags, off, size = sh(i)
                nm = name_at(nm_off)
                if typ == _SHT_NOBITS or not size:
                    continue
                if not ((flags & _SHF_EXECINSTR) or nm == ".text"):
                    continue
                if off + size > file_size:
                    # used to hash whatever was there and stop silently — a truncated
                    # (partially downloaded/extracted) library then looked changed or
                    # rebuild-only instead of being reported (same class as bugs.md #6)
                    raise ElfParseError(f"truncated: section {nm or i!r} extends past end "
                                        f"of file ({off + size} > {file_size} bytes)")
                h = hashlib.sha256()
                f.seek(off)
                remaining = size
                while remaining > 0:
                    blk = f.read(min(_CHUNK, remaining))
                    if not blk:
                        raise ElfParseError(f"short read in section {nm or i!r}")
                    h.update(blk)
                    remaining -= len(blk)
                key = nm or "<unnamed>"
                seen[key] = seen.get(key, 0) + 1
                sigs[key if seen[key] == 1 else f"{key}#{seen[key]}"] = h.hexdigest()
            return sigs or None
    except ElfParseError:
        raise
    except Exception as exc:
        if magic_ok:
            # It IS an ELF (magic matched) but can't be parsed: report it, don't let it be
            # mistaken for ordinary non-ELF content (mirrors mssql/triage._code_sig).
            raise ElfParseError(f"ELF could not be parsed: {exc}") from exc
        return None                               # couldn't even read the magic: not ELF


# --------------------------------------------------------------------------- data sections
def _section_list(f):
    """[(name, sh_type, sh_flags, offset, size, addr)] of every section of the open ELF `f`.
    Raises ElfParseError for an unreadable table."""
    ident = f.read(16)
    if ident[:4] != _MAGIC or ident[4] not in (1, 2) or ident[5] not in (1, 2):
        raise ElfParseError("not a supported ELF")
    en, is64 = ("<" if ident[5] == 1 else ">"), ident[4] == 2
    f.seek(0)
    hdr = f.read(64)
    if is64:
        shoff, = struct.unpack_from(en + "Q", hdr, 0x28)
        shentsize, shnum, shstrndx = struct.unpack_from(en + "HHH", hdr, 0x3A)
    else:
        shoff, = struct.unpack_from(en + "I", hdr, 0x20)
        shentsize, shnum, shstrndx = struct.unpack_from(en + "HHH", hdr, 0x2E)
    if not shoff or not shnum or not shentsize or shstrndx >= shnum:
        raise ElfParseError("ELF has no usable section header table")
    f.seek(shoff)
    tab = f.read(shentsize * shnum)
    if len(tab) < shentsize * shnum:
        raise ElfParseError("truncated section header table")

    def sh(i):
        b = i * shentsize
        if is64:
            name, typ, flags, addr = struct.unpack_from(en + "IIQQ", tab, b)
            off, size = struct.unpack_from(en + "QQ", tab, b + 24)
        else:
            name, typ, flags, addr = struct.unpack_from(en + "IIII", tab, b)
            off, size = struct.unpack_from(en + "II", tab, b + 16)
        return name, typ, flags, off, size, addr

    _n, _t, _fl, str_off, str_size, _a = sh(shstrndx)
    f.seek(str_off)
    strtab = f.read(str_size)
    out = []
    for i in range(shnum):
        nm_off, typ, flags, off, size, addr = sh(i)
        end = strtab.find(b"\x00", nm_off)
        nm = (strtab[nm_off:end] if end >= 0 else b"").decode("latin-1", "replace")
        out.append((nm, typ, flags, off, size, addr))
    return out


def _data_sections(f):
    """{key: (offset, size)} of every loaded, non-executable PROGBITS section (.rodata, .data,
    .data.rel.ro, .got, .eh_frame, ...), keyed by name + occurrence like exec_section_sigs().
    Not .bss (no bytes), notes (the build id), symbol/string/relocation tables or debug info:
    those are not the program's data. Raises ElfParseError for an unreadable table."""
    out, seen = {}, {}
    for nm, typ, flags, off, size, _addr in _section_list(f):
        if typ != _SHT_PROGBITS or not size or not flags & _SHF_ALLOC or flags & _SHF_EXECINSTR:
            continue
        nm = nm or "<unnamed>"
        seen[nm] = seen.get(nm, 0) + 1
        out[nm if seen[nm] == 1 else f"{nm}#{seen[nm]}"] = (off, size)
    return out


_SHT_SYMTAB, _SHT_DYNSYM = 2, 11


def symbol_source(path):
    """Which function-symbol table Stage 2 can use for this ELF (db2_bugs.md DB2-2):
    "symtab" (all functions), "dynsym" (exported functions only: stripped), "none", or
    "unsupported" (not 64-bit little-endian, which Stage 2 doesn't diff). Lets triage say
    before the run which changed libraries will be analysed only partly or not at all."""
    try:
        with open(lp(path), "rb") as f:
            ident = f.read(6)
            if ident[:4] != _MAGIC:
                return "none"
            if ident[4] != 2 or ident[5] != 1:
                return "unsupported"
            f.seek(0)
            types = {typ for _n, typ, _fl, _o, size, _a in _section_list(f) if size}
    except (OSError, ElfParseError, struct.error):
        return "none"
    if _SHT_SYMTAB in types:
        return "symtab"
    return "dynsym" if _SHT_DYNSYM in types else "none"


_SHF_WRITE = 0x1


def readonly_data_sections(path):
    """[(addr, size, file_offset)] of the loaded data that is read-only for the whole
    process lifetime: allocated, non-writable, non-executable PROGBITS (.rodata, .eh_frame,
    ...). Not .data.rel.ro: it is writable until relocated, and its file bytes are not the
    pointers the program sees. Used to give the pseudo-C decompiler the jump tables and
    constants a function reads (db2_bugs.md DB2-17). [] if the file can't be read."""
    try:
        with open(lp(path), "rb") as f:
            return [(addr, size, off) for _n, typ, flags, off, size, addr in _section_list(f)
                    if typ == _SHT_PROGBITS and size and addr and flags & _SHF_ALLOC
                    and not flags & (_SHF_WRITE | _SHF_EXECINSTR)]
    except (OSError, ElfParseError, struct.error):
        return []


def _texty(b):
    return b == 0 or 0x20 <= b < 0x7F


def data_section_diff(path_a, path_b):
    """How two ELFs' loaded data differs, or None when it doesn't (db2_bugs.md DB2-22).

    Meant for a pair whose CODE is identical (same exec_section_sigs): before, such a pair
    was "rebuild only" and never looked at, so a fix confined to a constant or table in
    .rodata / .data was invisible. Returns {"data_sections": [{"name", "prior_size",
    "fixed_size", "bytes_changed"}], "data_bytes_changed": n, "strings_only": bool}.
    bytes_changed is only counted for a section of the same size on both sides (None
    otherwise: a size change shifts everything after it). strings_only is True when every
    changed section kept its size and every changed byte is printable text or NUL on both
    sides — the shape of a rebuilt version or date string, not of a changed table."""
    try:
        with open(lp(path_a), "rb") as fa, open(lp(path_b), "rb") as fb:
            sa, sb = _data_sections(fa), _data_sections(fb)
            changed, total, strings_only = [], 0, True
            for key in sorted(set(sa) | set(sb)):
                (oa, za), (ob, zb) = sa.get(key, (0, 0)), sb.get(key, (0, 0))
                if key not in sa or key not in sb or za != zb:
                    changed.append({"name": key, "prior_size": za if key in sa else None,
                                    "fixed_size": zb if key in sb else None,
                                    "bytes_changed": None})
                    strings_only = False
                    continue
                n, pos = 0, 0
                fa.seek(oa)
                fb.seek(ob)
                while pos < za:
                    ca, cb = fa.read(min(_CHUNK, za - pos)), fb.read(min(_CHUNK, za - pos))
                    if len(ca) != len(cb) or not ca:
                        raise ElfParseError(f"short read in section {key!r}")
                    if ca != cb:
                        for o in range(0, len(ca), 4096):      # walk only differing blocks
                            xa, xb = ca[o:o + 4096], cb[o:o + 4096]
                            if xa == xb:
                                continue
                            for x, y in zip(xa, xb):
                                if x != y:
                                    n += 1
                                    if strings_only and not (_texty(x) and _texty(y)):
                                        strings_only = False
                    pos += len(ca)
                if n:
                    changed.append({"name": key, "prior_size": za, "fixed_size": zb,
                                    "bytes_changed": n})
                    total += n
            if not changed:
                return None
            return {"data_sections": changed, "data_bytes_changed": total,
                    "strings_only": strings_only}
    except ElfParseError:
        raise
    except Exception as exc:
        raise ElfParseError(f"ELF data sections could not be compared: {exc}") from exc
