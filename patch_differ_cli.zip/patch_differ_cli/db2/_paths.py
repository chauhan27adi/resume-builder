r"""Windows long-path (MAX_PATH) helper.

The DB2 product tree nests config resources very deep (e.g. cfg/magen/resources/
format_repository/json_formats/.../<long>.json). Extracted under an already-deep patch
workdir (data/patch_differ/db2/KB.../acquire/<side>/root/opt/ibm/db2/V<x>/...), the full
path routinely exceeds the legacy 260-char MAX_PATH limit, and open()/getsize() raise
FileNotFoundError. Wrapping the path with the `\\?\` extended-length prefix lifts the limit
to ~32767 chars. No-op on non-Windows.
"""
import os


def lp(path):
    """Return an extended-length ('\\?\\'-prefixed) absolute path on Windows; unchanged
    elsewhere. Safe to call repeatedly (idempotent)."""
    if os.name != "nt" or not path:
        return path
    p = os.path.abspath(path)          # also normalises / -> \ and resolves . / ..
    if p.startswith("\\\\?\\"):
        return p
    if p.startswith("\\\\"):           # UNC share -> \\?\UNC\server\share\...
        return "\\\\?\\UNC\\" + p[2:]
    return "\\\\?\\" + p

def safe_name(s, limit=120):
    """Filesystem-safe name for `s` that is unique per distinct `s` (bugs.md #12).

    The old pattern — replace disallowed chars with "_" and cut to `limit` — mapped distinct
    inputs to ONE name: "lib/private/api.so" and "lib_private_api.so" (a shared, concurrently
    used BinDiff workspace), any two names sharing their first `limit` chars (long C++/template
    symbols: one function's card overwrote another's), and, on case-insensitive NTFS, names
    differing only in case (GetX vs getX). A short digest of the ORIGINAL string is now always
    appended; the readable prefix is kept for humans."""
    import hashlib
    import re as _re
    base = _re.sub(r"[^A-Za-z0-9._-]", "_", s)
    digest = hashlib.sha1(s.encode("utf-8", "surrogatepass")).hexdigest()[:10]
    return f"{base[:max(1, limit - 11)]}_{digest}"
