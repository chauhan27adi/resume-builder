"""Stage 2 — symbol-based function diff of the DB2 engine ELF (.so), capstone-normalized.

DB2's `libdb2e.so.1` ships a FULL `.symtab` (~160k STT_FUNC symbols with sizes), so we can
diff at *function* granularity by symbol name instead of whole-binary Ghidra analysis — which
is intractable on a ~330 MB / 199 MB-.text library. Two-stage, per the ora-cve-rca approach:

  1. cheap pass  — carve each build's `.text` into per-function byte slices via `.symtab`;
                   set-diff by name → new / removed / size-changed / raw-byte-changed.
  2. disasm pass — only on the raw-changed set, capstone-disassemble both sides and NORMALIZE
                   away recompilation/relink noise: branch/call targets → `L`, RIP-relative
                   displacements → `[rip]`, registers → `R<bits>` (allocation dropped, width
                   kept). What survives is a real logic
                   change. A `__LINE__`-renumber churn filter drops functions whose *only*
                   change is a cluster of small, uniform immediate shifts (embedded line
                   numbers from a rebuild) while preserving lone constant changes (e.g. a
                   buffer-size fix). Because we keep the symbols, every surviving function is
                   NAMED and attributable to a CVE by name (ixf/load/import → 2026-10534;
                   auth/priv → 2026-10543).

Output: `<workdir>/stage2/functions_diff.json` (+ per-function .asm.diff/.detail.json for
function cards — .asm.diff is the normalized-instruction assembly diff, .detail.json the
full prior/fixed text record, plus prior_c/fixed_c pseudo-C when --decompile is used;
data cards keep the older .diff/.pair.json naming, see emit_data()) — same shape the
detail template + /split renderer consume. Permanent per-version copies also land under a
per-build layout (shared with MSSQL, see _layout.py): each build's plain disassembly in
`disassembled_instructions_<build>_<version>/<binary>_<sha8>/<func>.asm` and, with
--decompile, its pseudo-C in `decompiled_c_<build>_<version>/<binary>_<sha8>/<func>.c`,
while the assembly diffs (which compare the two builds) go to
`disassembled_instructions_<vuln>_vs_<fixed>/` — never cleaned up, see `run()`. This
replaces the
earlier Ghidra/BinExport/BinDiff path (kept in git history) which does not scale to the
full engine.
"""
import bisect
import difflib
import hashlib
import json
import os
import re
import struct
import sys
import time
from collections import Counter

from ._paths import lp, safe_name
from . import _elf
from .. import _parallel
from .. import _x86diff as _X
from .. import _attribution as _AT
from .. import _result_state as _rs
from .._decompile import decompile_cached, decompile_allowed
from .._decompile import failure_record as _dc_failure_record
from .. import _layout


def _decompile_allowed(job, stats):
    return decompile_allowed(job.get("decompile_max"), stats)


_CTX_WINDOW = 4096              # bytes of read-only data loaded from each referenced address
_CTX_MAX_BYTES = 256 << 10      # per function and side


def _decompile_context(md, path, vaddr, code, exact_names, ro_sections):
    """What Ghidra needs around one function blob for usable pseudo-C (db2_bugs.md DB2-16
    and DB2-17): its real address (`base`), the read-only data its RIP-relative references
    point into (jump tables, constants, strings: `blocks`, a window of _CTX_WINDOW bytes
    from each referenced address, merged, clipped to its section, _CTX_MAX_BYTES in all),
    and the names of the functions it calls or jumps to directly (`names`, from this
    build's own symbols). Writable data is never loaded: the decompiler would treat its
    file bytes as constants."""
    targets = sorted(_data_refs(md, vaddr, code))
    windows = []
    for t in targets:
        for a, size, off in ro_sections:
            if a <= t < a + size:
                windows.append([t, min(t + _CTX_WINDOW, a + size), a, off])
                break
    merged = []
    for w in windows:                               # sorted by start already
        if merged and w[2] == merged[-1][2] and w[0] <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], w[1])
        else:
            merged.append(w)
    blocks, total = [], 0
    if merged:
        with open(lp(path), "rb") as f:
            for start, end, a, off in merged:
                n = min(end - start, _CTX_MAX_BYTES - total)
                if n <= 0:
                    break
                f.seek(off + (start - a))
                data = f.read(n)
                if data:
                    blocks.append((start, data))
                    total += len(data)
    names, end = {}, vaddr + len(code)
    if vaddr in exact_names:
        names[vaddr] = exact_names[vaddr]         # the function's own header
    for ins in md.disasm(code, vaddr):
        if X86_GRP_CALL not in ins.groups and X86_GRP_JUMP not in ins.groups:
            continue
        ops = ins.operands
        if len(ops) == 1 and ops[0].type == X86_OP_IMM:
            t = ops[0].imm
            if not vaddr <= t < end and t in exact_names:
                names[t] = exact_names[t]
    return {"base": vaddr, "blocks": blocks, "names": names}


_ADDR_MASK = 0xFFFFFFFFFFFFFFFF


def _data_refs(md, vaddr, code):
    """Addresses a function's instructions refer to as data: RIP-relative memory operands
    (PIC code, e.g. a .so), absolute memory operands (non-PIE code, including the table of
    `jmp [rax*8 + table]`), and non-branch immediates (an address loaded into a register).
    Only those inside read-only sections are used, so a coincidental constant costs at most
    one harmless read-only window."""
    out = set()
    for ins in md.disasm(code, vaddr):
        branch = X86_GRP_JUMP in ins.groups or X86_GRP_CALL in ins.groups
        for op in ins.operands:
            if op.type == X86_OP_MEM:
                if op.mem.base == X86_REG_RIP:
                    out.add((ins.address + ins.size + op.mem.disp) & _ADDR_MASK)
                elif op.mem.base == 0:
                    out.add(op.mem.disp & _ADDR_MASK)
            elif op.type == X86_OP_IMM and not branch:
                out.add(op.imm & _ADDR_MASK)
    return out


def _exact_names(fmap):
    """{vaddr: plain symbol name} for named functions (a dedupe qualifier dropped)."""
    out = {}
    for key, (va, _code) in fmap.items():
        name = key.split(" ", 1)[0]
        if name and not name.startswith("sub_"):
            out.setdefault(va, name)
    return out


def _plt_names(md, path):
    """{PLT stub address: imported symbol} (db2_bugs.md DB2-17): a call to libc or another
    library goes through a PLT stub, which Ghidra can only call FUN_<addr>. Each stub is
    `jmp [rip+slot]` (after an endbr64 in .plt.sec); the slot's relocation (.rela.plt
    JUMP_SLOT, or .rela.dyn GLOB_DAT for .plt.got) names the symbol in .dynsym. ELF64 LE
    only; {} if anything is missing."""
    try:
        with open(lp(path), "rb") as f:
            hdr = f.read(64)
            if hdr[:4] != b"\x7fELF" or hdr[4] != 2 or hdr[5] != 1:
                return {}
            shoff, = struct.unpack_from("<Q", hdr, 0x28)
            shentsize, shnum, shstrndx = struct.unpack_from("<HHH", hdr, 0x3A)
            if not shoff or shentsize < 64 or not shnum or shstrndx >= shnum:
                return {}
            f.seek(shoff)
            tab = f.read(shentsize * shnum)
            secs = []
            for i in range(shnum):
                b = i * shentsize
                name, typ, flags, addr, off, size, link = struct.unpack_from("<IIQQQQI", tab, b)
                secs.append({"name": name, "type": typ, "addr": addr, "off": off,
                             "size": size, "link": link})

            def data(s):
                f.seek(s["off"])
                return f.read(s["size"])

            shstr = data(secs[shstrndx])
            nm = lambda b, n: b[n:b.find(b"\0", n)].decode("latin-1")
            slots = {}                                  # GOT slot -> symbol name
            for s in secs:
                if s["type"] != 4 or s["link"] >= shnum:          # SHT_RELA
                    continue
                sym = secs[s["link"]]
                if sym["type"] != _SHT_DYNSYM or sym["link"] >= shnum:
                    continue
                syms, strs, rel = data(sym), data(secs[sym["link"]]), data(s)
                for k in range(len(rel) // 24):
                    r_off, r_info = struct.unpack_from("<QQ", rel, 24 * k)
                    si, rtype = r_info >> 32, r_info & 0xFFFFFFFF
                    if rtype not in (6, 7) or not si or 24 * si + 24 > len(syms):  # GLOB_DAT, JUMP_SLOT
                        continue
                    n = nm(strs, struct.unpack_from("<I", syms, 24 * si)[0])
                    if n:
                        slots[r_off] = n
            out = {}
            for s in secs:
                if not nm(shstr, s["name"]).startswith(".plt") or not s["size"]:
                    continue
                prev = None
                for ins in md.disasm(data(s), s["addr"]):
                    if (ins.mnemonic.endswith("jmp") and len(ins.operands) == 1
                            and ins.operands[0].type == X86_OP_MEM
                            and ins.operands[0].mem.base == X86_REG_RIP):
                        slot = ins.address + ins.size + ins.operands[0].mem.disp
                        if slot in slots:
                            out[ins.address] = slots[slot]
                            if prev is not None and prev.mnemonic == "endbr64":
                                out[prev.address] = slots[slot]
                    prev = ins
            return out
    except (OSError, struct.error, IndexError):
        return {}

try:
    import capstone
    from capstone import Cs, CS_ARCH_X86, CS_MODE_64
    from capstone.x86 import (X86_OP_IMM, X86_OP_MEM, X86_OP_REG,
                              X86_REG_RIP, X86_GRP_JUMP, X86_GRP_CALL)
    _CAP = True
except Exception:
    _CAP = False

_EMIT_CAP = 500                    # max per-function diff cards written (full count still reported)
_MAX_FUNC_BYTES = 300_000         # skip pathologically large "functions" (jump tables etc.)
# compiler-generated clones/outlines: their presence/shape differs mostly from recompilation
# (inlining/outlining decisions), not the fix — rank them below real in-place logic changes.
_ARTIFACT = re.compile(r"\.(cold|constprop|localalias|part|isra|clone|lto_priv)\b")
# Ghidra loads PIE ELF files at this base address by default. BinDiff records VAs
# (st_value + _GHIDRA_ELF_PIE_BASE); _func_map() stores raw st_value (relative to 0).
# Verify this constant against a live Ghidra ELF analysis before shipping.
_GHIDRA_ELF_PIE_BASE = 0x100000


def _rank(r):
    """Sort key: ASSERTED (corroborated) CVE first, then candidate (name-matched, uncorroborated),
    then the most fix-shaped changes (added guard/bounds check/validation call), then real
    in-place changes, then new/removed, then compiler clones; most-changed first. The final
    element (object name) is a deterministic tie-breaker — list.sort() is stable, so without
    it, two equally-ranked functions would keep whatever order the worker pool happened to
    finish them in, which varies run to run."""
    return (r.get("cve") is None,
            r.get("cve_candidate") is None,
            -r.get("fix_score", 0),
            bool(_ARTIFACT.search(r.get("object", ""))),
            r.get("change") in ("added", "removed"),
            r.get("similarity", 1.0),
            r.get("object", ""))


def available():
    return _CAP


# --------------------------------------------------------------------------- ELF / symbols
class FuncMap(dict):
    """{key: (vaddr, code_bytes)} plus `src` = {key: source file (STT_FILE) or None}, which
    reconcile_dup_names() uses to line a duplicated name up across the two builds."""

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.src = {}
        self.oversized = {}       # {name: [(size, sha256)]} skipped as > _MAX_FUNC_BYTES (#28)
        self.symbol_source = None  # "symtab", or "dynsym" (exported functions only, DB2-18)


def _oversized_entry(oversized, name, code):
    """Record a function _func_map() skips as over _MAX_FUNC_BYTES — see
    _results.skipped_oversized() (bugs.md #28)."""
    oversized.setdefault(name, []).append((len(code), hashlib.sha256(code).hexdigest()))


def _dedupe_func_names(entries):
    """FuncMap from [(name, ident, vaddr, code, src_file)] symbol entries (bugs.md #27).

    A name is not unique in a linked ELF: two TUs can each define a `static` function of
    the same name. The map used to be keyed by the bare name, so the later symbol silently
    overwrote the earlier one and a change to the overwritten function was never diffed.
    Entries sharing a name AND location (`ident`) are aliases of one function (LOCAL+GLOBAL
    or weak twins) and collapse to one. A name left with several distinct functions gets
    every one of them qualified as "name [file.c]" (plus " #k" in address order when one
    file defines it more than once, or "?" when there's no STT_FILE context) — a key that's
    stable across builds, where an ordinal alone would shift when one copy is removed.
    Unique names keep their bare key, so nothing changes for the common case."""
    groups = {}
    for name, ident, val, code, src in entries:
        g = groups.setdefault(name, [])
        if any(e[0] == ident for e in g):
            continue
        g.append((ident, val, code, src))
    out = FuncMap()
    for name, g in groups.items():
        if len(g) == 1:
            _ident, val, code, src = g[0]
            out[name] = (val, code)
            out.src[name] = src
            continue
        per_src = Counter(e[3] for e in g)
        nth = Counter()
        for _ident, val, code, src in sorted(g, key=lambda e: e[0]):
            label = src or "?"
            if per_src[src] > 1:
                nth[src] += 1
                label = f"{label} #{nth[src]}"
            key = _AT.qualify_func_name(name, label)
            out[key] = (val, code)
            out.src[key] = src
    return out


def reconcile_dup_names(P, F):
    """Re-key in place a bare name on one side whose other side qualified it (bugs.md #27).

    _dedupe_func_names() qualifies a name only when IT is duplicated on that side, so a
    build that drops one of two same-named statics leaves "f" on one side but "f [a.c]" /
    "f [b.c]" on the other — every copy would read as added/removed and the surviving
    function's own change would not be diffed. When the bare-keyed function's source file
    qualifies it to a key the other side has, rename it to that key."""
    for a, b in ((P, F), (F, P)):
        src = getattr(a, "src", None) or {}
        qualified = {_AT.base_func_name(k) for k in b} - set(b)
        for k in [k for k in a if k in qualified and k not in b]:
            if not src.get(k):
                continue
            q = _AT.qualify_func_name(k, src[k])
            if q in b and q not in a:
                a[q] = a.pop(k)
                src[q] = src.pop(k)


_SHT_PROGBITS, _SHT_SYMTAB, _SHT_DYNSYM = 1, 2, 11
_SHF_EXECINSTR = 0x4
_STT_FUNC, _STT_FILE, _STT_GNU_IFUNC = 2, 4, 10
_SHN_XINDEX = 0xFFFF


def _func_map(path, use_symtab=True):
    """{name: (vaddr, code_bytes)} for every function symbol (STT_FUNC or STT_GNU_IFUNC)
    with a nonzero size inside an executable section. Pure struct parse (ELF64 LE) — no
    pyelftools dependency. A symbol with no name (st_name == 0) gets a synthetic
    sub_<vaddr> key instead of being dropped — see the call site below for why that's only
    trusted for same-address changed-function detection, not for new/removed matching.
    Same-named distinct functions get qualified keys — see _dedupe_func_names().

    db2_bugs.md DB2-18: symbols come from the SHT_SYMTAB section (string table = its
    sh_link); a library stripped of it falls back to SHT_DYNSYM, its exported functions,
    and the map's `symbol_source` says which ("symtab" / "dynsym"; use_symtab=False asks
    for the .dynsym view directly). Every SHF_EXECINSTR section counts as code, not only
    .text, and extended section numbering (e_shnum = 0 / e_shstrndx = SHN_XINDEX, values
    held in section header 0) is read rather than failing the binary."""
    with open(lp(path), "rb") as f:
        hdr = f.read(64)
        if len(hdr) < 64 or hdr[:4] != b"\x7fELF" or hdr[4] != 2:
            return {}
        e_shoff = struct.unpack_from("<Q", hdr, 0x28)[0]
        e_shentsize = struct.unpack_from("<H", hdr, 0x3A)[0]
        e_shnum = struct.unpack_from("<H", hdr, 0x3C)[0]
        e_shstrndx = struct.unpack_from("<H", hdr, 0x3E)[0]
        if not e_shoff or e_shentsize < 64:
            return {}
        f.seek(e_shoff)
        sh0 = f.read(e_shentsize)
        if len(sh0) < 64:
            return {}
        if e_shnum == 0:
            e_shnum = struct.unpack_from("<Q", sh0, 32)[0]
        if e_shstrndx == _SHN_XINDEX:
            e_shstrndx = struct.unpack_from("<I", sh0, 40)[0]
        f.seek(e_shoff)
        sh = f.read(e_shentsize * e_shnum)
        if not e_shnum or len(sh) < e_shentsize * e_shnum or e_shstrndx >= e_shnum:
            return {}

        def rec(i):
            b = i * e_shentsize
            return {"name": struct.unpack_from("<I", sh, b)[0],
                    "type": struct.unpack_from("<I", sh, b + 4)[0],
                    "flags": struct.unpack_from("<Q", sh, b + 8)[0],
                    "addr": struct.unpack_from("<Q", sh, b + 16)[0],
                    "off": struct.unpack_from("<Q", sh, b + 24)[0],
                    "size": struct.unpack_from("<Q", sh, b + 32)[0],
                    "link": struct.unpack_from("<I", sh, b + 40)[0]}

        secs = [rec(i) for i in range(e_shnum)]
        ss = secs[e_shstrndx]
        f.seek(ss["off"]); shstr = f.read(ss["size"])
        for s in secs:
            n = s["name"]
            s["sname"] = shstr[n:shstr.find(b"\0", n)].decode("latin-1") if n < len(shstr) else ""

        def table(typ, name):
            return next((s for s in secs if s["type"] == typ), None) or next(
                (s for s in secs if s["sname"] == name), None)

        sym, source = (table(_SHT_SYMTAB, ".symtab"), "symtab") if use_symtab else (None, None)
        if sym is None:
            sym, source = table(_SHT_DYNSYM, ".dynsym"), "dynsym"
        if sym is None:
            return {}
        strname = ".strtab" if source == "symtab" else ".dynstr"
        strt = (secs[sym["link"]] if 0 < sym["link"] < e_shnum
                else next((s for s in secs if s["sname"] == strname), None))
        if strt is None:
            return {}
        # code: .text by name (as exec_section_sigs() does), and any other executable section
        code_index = {i: s for i, s in enumerate(secs)
                      if s["size"] and s["type"] != 8                    # SHT_NOBITS
                      and (s["sname"] == ".text"
                           or (s["type"] == _SHT_PROGBITS and s["flags"] & _SHF_EXECINSTR))}
        code = list(code_index.values())
        if not code:
            return {}
        f.seek(strt["off"]); st = f.read(strt["size"])
        nm = lambda n: st[n:st.find(b"\0", n)].decode("latin-1")
        f.seek(sym["off"]); data = f.read(sym["size"])
        blobs = {}

        def section_of(val, shndx):
            """(section, its bytes) for a function at `val`, else (None, None). The symbol's
            own section (st_shndx) when that is a code section: in a relocatable object
            every .text.<fn> section starts at address 0, so an address alone would give a
            function another one's bytes. Else, as before, the code section holding `val`."""
            s = code_index.get(shndx)
            if s is None or not s["addr"] <= val < s["addr"] + s["size"]:
                s = next((c for c in code if c["addr"] <= val < c["addr"] + c["size"]), None)
            if s is None:
                return None, None
            k = id(s)
            if k not in blobs:
                f.seek(s["off"]); blobs[k] = f.read(s["size"])
            return s, blobs[k]

        entries, big = [], {}
        from .. import _results
        limit = _results.max_func_bytes(_MAX_FUNC_BYTES)       # DB2-2: configurable
        src = None                  # current STT_FILE: a TU's LOCAL symbols follow its entry
        for i in range(len(data) // 24):
            b = i * 24
            info = data[b + 4]
            if (info & 0xf) == _STT_FILE:
                src = nm(struct.unpack_from("<I", data, b)[0]) or None
                continue
            if (info & 0xf) not in (_STT_FUNC, _STT_GNU_IFUNC):
                continue
            val = struct.unpack_from("<Q", data, b + 8)[0]
            sz = struct.unpack_from("<Q", data, b + 16)[0]
            if sz == 0:
                continue
            sec, tb = section_of(val, struct.unpack_from("<H", data, b + 6)[0])
            if sec is None:
                continue
            tv = sec["addr"]
            name = nm(struct.unpack_from("<I", data, b)[0])
            if not name:
                # CRIT-NT-2: an STT_FUNC symbol with no name (st_name == 0) used to be
                # dropped entirely here, so it could never be detected as changed, added,
                # or removed, with zero diagnostic. Give it a synthetic placeholder key
                # instead (mirrors mssql/stage2.py's sub_<rva> scheme) — see that module's
                # docstring for why this is only a reliable signal for same-address
                # byte-changed detection, never for new/removed matching. The name-mode
                # and BinDiff-mode new/removed derivations below both filter sub_-prefixed
                # keys out for exactly that reason.
                name = "sub_%x" % val
            if sz > limit:
                _oversized_entry(big, name, tb[val - tv:val - tv + sz])
                continue
            # the file context only applies to LOCAL (STB_LOCAL == 0) symbols — globals
            # follow every TU's locals and belong to none of them
            entries.append((name, val, val, tb[val - tv:val - tv + sz],
                            src if (info >> 4) == 0 else None))
        fm = _dedupe_func_names(entries)
        fm.oversized = big
        fm.symbol_source = source
        return fm


def _elf64_le(path):
    try:
        with open(lp(path), "rb") as f:
            h = f.read(6)
    except OSError:
        return False
    return h[:4] == b"\x7fELF" and h[4] == 2 and h[5] == 1


def _ghidra_elf_default_offset(path):
    """Where Ghidra places an ELF's symbols, relative to their st_value, when it can't be
    measured (bugs.md #60): ET_EXEC keeps its absolute addresses; ET_DYN / ET_REL go to
    the default image base (live-verified for both)."""
    return 0 if _elf.elf_type(path) == _elf.ET_EXEC else _GHIDRA_ELF_PIE_BASE


def _make_name_at(func_map):
    """Build a name_at(addr) -> name|None resolver from a {name: (vaddr, code)} map (one
    per side — prior and fixed each get their own, since their vaddrs don't correspond).
    Mirrors mssql/symbols.py's Symbolizer.name_at(): exact match first, else the greatest
    vaddr <= addr (a call landing mid-function — e.g. an EH funclet or tail continuation —
    still resolves to its owning function). Used to feed X.call_targets() so newly-added
    calls to security intrinsics (__stack_chk_fail, __memcpy_chk, …) can be detected."""
    names = {v: n for n, (v, _c) in func_map.items()}
    vaddrs = sorted(names)

    def name_at(addr):
        n = names.get(addr)
        if n:
            return n
        i = bisect.bisect_right(vaddrs, addr) - 1
        return names.get(vaddrs[i]) if i >= 0 else None

    return name_at


# --------------------------------------------------------------------------- data sections
# Lever 3 (scoped data-section diff) is OFF by default and EXPERIMENTAL. Validation on real
# DB2 builds (SU87984) showed cross-build data churn dominates: `_norm` intentionally erases
# the RIP-relative displacement (`[rip+disp]` -> `[rip]`), so two instructions that reference
# *different* data normalize as "equal" — instruction-aligned pairing then compares unrelated
# targets, and relocated string pools / offset tables move every rebuild. The NUL-string and
# reloc-table filters below cut the obvious noise but cannot make it reliable; doing this
# correctly needs content-based data correlation (match data by its VALUE across builds), not
# address/site alignment. There is also no known data-only fix the code-diff currently misses.
# Kept as a foundation (the `rip_data_targets` primitive + filters); set PATCHDIFF_DATA_DIFF=1
# only to experiment. When on, it only considers data an UNCHANGED code site references.
_DATA_DIFF = os.environ.get("PATCHDIFF_DATA_DIFF") == "1"
_DATA_WIN = 48                     # bytes compared at each referenced data address


def _data_reader(path):
    """(read(vaddr,n)->bytes|None, lo, hi) over allocatable DATA sections (.rodata*/.data*).
    lo/hi bound the image's allocatable vaddr range, used to spot relocated pointers. A no-op
    reader if the file is unreadable / not ELF64."""
    try:
        with open(lp(path), "rb") as f:
            hdr = f.read(64)
            if hdr[:4] != b"\x7fELF" or hdr[4] != 2:
                return (lambda a, n: None), 0, 0
            e_shoff = struct.unpack_from("<Q", hdr, 0x28)[0]
            e_shentsize = struct.unpack_from("<H", hdr, 0x3A)[0]
            e_shnum = struct.unpack_from("<H", hdr, 0x3C)[0]
            e_shstrndx = struct.unpack_from("<H", hdr, 0x3E)[0]
            f.seek(e_shoff); sh = f.read(e_shentsize * e_shnum)

            def rec(i):
                b = i * e_shentsize
                return (struct.unpack_from("<I", sh, b)[0],        # name
                        struct.unpack_from("<I", sh, b + 4)[0],    # type
                        struct.unpack_from("<Q", sh, b + 8)[0],    # flags
                        struct.unpack_from("<Q", sh, b + 16)[0],   # addr
                        struct.unpack_from("<Q", sh, b + 24)[0],   # off
                        struct.unpack_from("<Q", sh, b + 32)[0])   # size

            _n, _t, _fl, ssaddr, ssoff, sssize = rec(e_shstrndx)
            f.seek(ssoff); shstr = f.read(sssize)
            snm = lambda n: shstr[n:shstr.find(b"\0", n)].decode("latin-1")
            SHF_ALLOC, SHT_NOBITS = 0x2, 8
            segs, lo, hi = [], 0, 0
            for i in range(e_shnum):
                nmn, typ, flags, addr, off, size = rec(i)
                if not (flags & SHF_ALLOC) or addr == 0:
                    continue
                if lo == 0 or addr < lo:
                    lo = addr
                if addr + size > hi:
                    hi = addr + size
                if typ == SHT_NOBITS:
                    continue
                nm = snm(nmn)
                if nm.startswith(".rodata") or nm == ".data" or nm.startswith(".data."):
                    f.seek(off); segs.append((addr, size, f.read(size)))

            def read(vaddr, n):
                for a, sz, b in segs:
                    if a <= vaddr < a + sz:
                        o = vaddr - a
                        return b[o:o + n]
                return None
            return read, lo, hi
    except Exception:
        return (lambda a, n: None), 0, 0


def _looks_pointer(buf, lo, hi):
    """True if any 8-byte word in `buf` is a plausible in-image address — i.e. a relocated
    pointer (vtable/GOT/RVA-table entry) that moves between builds without a real change."""
    for o in range(0, (len(buf) // 8) * 8, 8):
        w = int.from_bytes(buf[o:o + 8], "little")
        if lo <= w < hi:
            return True
    return False


def _is_reloc_table(pb, fb):
    """A window of int32 words that ALL shifted by a dominant uniform delta = a relocated
    offset/RVA table (e.g. a switch jump table), which churns on every rebuild without a real
    change. (Data analogue of the __LINE__-renumber churn filter in _classify.)"""
    n = min(len(pb), len(fb)) // 4
    if n < 2:
        return False
    pw = struct.unpack_from("<%di" % n, pb, 0)
    fw = struct.unpack_from("<%di" % n, fb, 0)
    deltas = [f - p for p, f in zip(pw, fw) if f != p]
    if len(deltas) < n:                  # some entries unchanged -> a targeted edit, not a shift
        return False
    top = Counter(deltas).most_common(1)[0][1]
    return top / len(deltas) >= 0.6


def _real_data_change(pb, fb, lo1, hi1, lo2, hi2):
    """True only if a data window is a genuine CONTENT change, not cross-build churn. Strings
    are compared to their NUL terminator (the 48-byte window otherwise bleeds into an adjacent,
    reordered string-pool entry); binary windows skip relocated pointer/offset tables."""
    z1, z2 = pb.find(0), fb.find(0)
    if z1 != -1 or z2 != -1:
        ps = pb[:z1] if z1 != -1 else pb
        fs = fb[:z2] if z2 != -1 else fb
        texty = lambda b: bool(b) and sum(32 <= c < 127 for c in b) >= 0.8 * len(b)
        # bugs.md #40: ANY NUL used to make the window "string-ish", so binary data with an
        # early NUL (b"\x00AAAA" vs b"\x00BBBB") compared equal on its empty prefixes and a
        # real change was dropped. Only a window that actually starts with a C-string gets
        # string semantics; anything else is binary and falls through to the checks below
        # (which still discount relocated pointers/offset tables — NUL-rich by nature).
        if texty(ps) or texty(fs):       # a C-string window
            return ps != fs              # same string -> the diff is pool churn past the NUL
    if _looks_pointer(pb, lo1, hi1) or _looks_pointer(fb, lo2, hi2):
        # bug.md DB2-NT-2: a relocated 64-bit pointer is present. Void the window ONLY if the
        # ONLY differences are those pointers — mask every aligned word that is pointer-like
        # on either side and compare the rest, so a genuine change elsewhere in the same
        # window (a changed string/constant beside a pointer) is no longer dropped with it.
        mp, mf = bytearray(pb), bytearray(fb)
        for o in range(0, min(len(pb), len(fb)) // 8 * 8, 8):
            wp = int.from_bytes(pb[o:o + 8], "little")
            wf = int.from_bytes(fb[o:o + 8], "little")
            if lo1 <= wp < hi1 or lo2 <= wf < hi2:
                mp[o:o + 8] = mf[o:o + 8] = b"\x00" * 8
        if bytes(mp) == bytes(mf):
            return False                 # every difference was a relocated pointer
    if _is_reloc_table(pb, fb):
        return False                     # relocated 32-bit offset table
    return True


def _data_changes(pL, fL, ptg, ftg, pread, phi_lo, phi_hi, fread, fhi_lo, fhi_hi):
    """Data referenced by UNCHANGED code that genuinely changed content. Aligns the two
    normalized instruction streams (SequenceMatcher 'equal' blocks map prior i -> fixed j
    1:1), and at each aligned pair where both instructions have a RIP-relative data target,
    compares the pointed-to bytes. Skips relocated-pointer windows. Returns [(pt,ft,pb,fb)]."""
    out = []
    sm = difflib.SequenceMatcher(a=pL, b=fL, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag != "equal":
            continue
        for d in range(i2 - i1):
            pi, fj = i1 + d, j1 + d
            if pi >= len(ptg) or fj >= len(ftg):
                continue
            pt, ft = ptg[pi], ftg[fj]
            if pt is None or ft is None:
                continue
            pb, fb = pread(pt, _DATA_WIN), fread(ft, _DATA_WIN)
            if pb is None or fb is None or pb == fb:
                continue
            if not _real_data_change(pb, fb, phi_lo, phi_hi, fhi_lo, fhi_hi):
                continue                              # cross-build churn, not a real change
            out.append((pt, ft, pb, fb))
    return out


# --------------------------------------------------------------------------- entry
def _safe(s):
    return safe_name(s, 120)


# Per-version output layout, shared with MSSQL (see _layout.py). DB2 binaries are ELF, so
# a function is one contiguous blob and addresses are virtual addresses (VA), not RVAs.
_version_token = _layout.version_token
_version_dirs = _layout.version_dirs


def _binary_folder(base, rel, path, side_info, digest=None):
    """This ELF's folder in one build's output (_layout.binary_folder); the display name in
    binary.json is the binary's base name. digest reuses an already-computed sha256."""
    return _layout.binary_folder(base, rel, path, side_info, os.path.basename(rel), digest)


def _listing(md, binary_name, name, entry):
    """Plain disassembly of one ELF function — a single contiguous blob — with virtual
    addresses (VA)."""
    vaddr, code = entry
    return _layout.listing(md, name, binary_name, vaddr, [(vaddr, code)], "VA")


def _process_file(job, report=None):
    """Diff ONE changed ELF (.so), both sides. Module-level + picklable args so it runs in
    a ProcessPoolExecutor child (see `.._parallel`). Writes its own uniquely-named
    fn__*.asm.diff/.detail.json (function cards) and dt__*.diff/.pair.json (data cards,
    see emit_data()), and returns its cards + stats. `report(rel, pct, phase)` streams
    0..100 local progress (optional)."""
    prior_dir, fixed_dir, rel, out = job["prior_dir"], job["fixed_dir"], job["rel"], job["out"]
    attrib = job.get("attrib") or []
    p_path = os.path.join(prior_dir, rel)
    f_path = os.path.join(fixed_dir, rel)
    folders = {}                 # (kind, side) -> this ELF's folder in that build's output
    side_digest = {}             # side -> sha256 of its ELF (asm and c share one hash)

    def version_folder(kind, side):
        """This ELF's folder in one build's per-version output ("asm" or "c"), created on
        first use; None for a job without per-version folders (written the old way)."""
        info = (job.get("version_dirs") or {}).get(side)
        if not info:
            return None
        if (kind, side) not in folders:
            path = p_path if side == "prior" else f_path
            if side not in side_digest:
                side_digest[side] = _layout.file_sha256(path)
            folders[(kind, side)] = _binary_folder(info[kind], rel, path, info,
                                                   side_digest[side])
        return folders[(kind, side)]

    def rep(pct, phase):
        if report:
            report(rel, pct, phase)

    # bugs.md #3: an ELF present on only ONE side ("added" / "removed") gets a one-sided
    # function inventory (every function becomes an added/removed card) instead of no
    # function-level analysis at all. The absent side is simply an empty function map.
    one_sided = job.get("one_sided")
    rep(2, f"{rel}: reading symbols")
    md = _X.md()
    P = {} if one_sided == "added" else _func_map(os.path.join(prior_dir, rel))
    F = {} if one_sided == "removed" else _func_map(os.path.join(fixed_dir, rel))
    # DB2-18: a side read from .dynsym knows only the exported functions. Compared against
    # the other side's full .symtab, every static function would look added or removed, so
    # that side is read through its .dynsym too.
    srcs = {getattr(P, "symbol_source", None), getattr(F, "symbol_source", None)} - {None}
    if srcs == {"symtab", "dynsym"}:
        side, d = ("prior", prior_dir) if P.symbol_source == "symtab" else ("fixed", fixed_dir)
        alt = _func_map(os.path.join(d, rel), use_symtab=False)
        if alt:
            if side == "prior":
                P = alt
            else:
                F = alt
    dynsym_sides = [s for s, m in (("prior", P), ("fixed", F))
                    if getattr(m, "symbol_source", None) == "dynsym"]
    dynsym_only = {"rel": rel, "sides": dynsym_sides} if dynsym_sides else None
    reconcile_dup_names(P, F)
    from .. import _results
    skipped = [{"rel": rel, **s} for s in _results.skipped_oversized(P, F, one_sided)]
    expected = {"added": (("fixed", F),), "removed": (("prior", P),)}.get(
        one_sided, (("prior", P), ("fixed", F)))
    if any(not m and not getattr(m, "oversized", None) for _s, m in expected):
        # CRIT-NT-9: this binary is on triage's code_changed list, so an empty function map
        # (typically a stripped .so — no .symtab) means real code changes went unanalyzed.
        # Report WHY so run() records it as a failed binary instead of it silently vanishing
        # from a result that would otherwise look clean (and exit 0). (A side whose only
        # functions are oversized isn't symbol-less — those are reported in `skipped`.)
        sides = [s for s, m in expected if not m]
        why = "no .symtab or .dynsym functions"
        unsupported = [s for s in sides if not _elf64_le(
            os.path.join(prior_dir if s == "prior" else fixed_dir, rel))]
        if unsupported:
            # DB2-2: _func_map() reads x86-64 (ELF64 little-endian) only; say so instead of
            # blaming the symbols
            why = "not a 64-bit little-endian ELF; only x86-64 code is diffed"
        return {"rel": rel, "readable": [], "funcs_total": 0, "ok": False,
                "error": f"no function symbols on {' and '.join(sides)} side{'s' if len(sides) > 1 else ''} "
                         f"({why}) — changed code could not be analyzed",
                "decompile_attempted": 0, "decompile_failed": 0}
    name_at_P, name_at_F = _make_name_at(P), _make_name_at(F)

    rep(5, f"{rel}: comparing functions")

    readable = []
    # See mssql/stage2.py's _process_dll for why this exists: distinguishes "nothing
    # warranted decompiling" from "decompile was tried and failed every time" (e.g. a
    # stale Ghidra script cache) — previously both looked identical in the result.
    decompile_stats = {"attempted": 0, "failed": 0, "skipped": 0}
    decompile_failures = []      # {"object", "reason"} per failed pseudo-C (DB2-14)
    ctx_parts = {}               # side -> (exact names, read-only sections), built lazily

    def side_context(side, entry):
        """This side's decompile context (DB2-16/17), or None — then the blob is decompiled
        as before, without one. Never raises: a context is an improvement, not a need."""
        try:
            path = os.path.join(prior_dir if side == "prior" else fixed_dir, rel)
            if side not in ctx_parts:
                names = _plt_names(md, path)              # imports first: own names win
                names.update(_exact_names(P if side == "prior" else F))
                ctx_parts[side] = (names, _elf.readonly_data_sections(path))
            names, ro = ctx_parts[side]
            return _decompile_context(md, path, entry[0], entry[1], names, ro)
        except Exception as exc:
            print(f"WARNING: no decompile context for {rel} ({side}): {exc}", file=sys.stderr)
            return None

    def emit(prior_name, fixed_name, kind, sim, prior_txt, fixed_txt,
             bd_sim=None, bd_conf=None):
        """Write one function diff card. prior_name/fixed_name may differ (renamed) or one
        may be None (added/removed). bd_sim/bd_conf are present only in BinDiff mode."""
        key = prior_name if prior_name else fixed_name
        cve, why, name_conf = attr_cache[key]
        # For BinDiff-mode renames: prefer whichever side carries a CVE attribution.
        if cve is None and fixed_name and fixed_name != key:
            cve_f, why_f, nc_f = attr_cache.get(fixed_name, (None, None, None))
            if cve_f is not None:
                cve, why, name_conf = cve_f, why_f, nc_f
        # Resolve direct-call targets both sides and flag calls to security intrinsics
        # (__stack_chk_fail, __memcpy_chk, …) newly introduced by the fix — the strongest,
        # most self-evident fix signal, mirroring mssql/stage2.py. DB2 functions are a
        # single contiguous blob (no hot/cold chunks like MSSQL's PE functions), so
        # call_targets() is called directly rather than through a chunk-iterating wrapper.
        added_intr = None
        if kind not in ("added", "removed") and prior_name in P and fixed_name in F:
            pv, pc = P[prior_name]
            fv, fc = F[fixed_name]
            pcalls = Counter(_X.call_targets(md, pv, pc, name_at_P))
            fcalls = Counter(_X.call_targets(md, fv, fc, name_at_F))
            gained = list((fcalls - pcalls).elements())
            added_intr = [c for c in gained if _X.is_security_intrinsic(c)]
        fscore, freasons = (_X.fix_signature(prior_txt, fixed_txt, added_intrinsics=added_intr)
                            if kind not in ("added", "removed") else (0, []))
        display_name = prior_name or fixed_name
        if prior_name and fixed_name and prior_name != fixed_name:
            display_name = f"{prior_name} → {fixed_name}"
        obj = f"{rel} :: {display_name}"
        fbase = "fn__" + _safe(f"{rel}_{prior_name or fixed_name}")
        pname_label = prior_name or "(absent)"
        fname_label = fixed_name or "(absent)"
        diff = "".join(difflib.unified_diff(
            [l + "\n" for l in prior_txt], [l + "\n" for l in fixed_txt],
            fromfile=f"{pname_label} (prior, normalized)",
            tofile=f"{fname_label} (fixed, normalized)", n=3))
        diff_text = diff or "(no normalized-instruction differences)\n"
        with open(lp(os.path.join(out, fbase + ".asm.diff")), "w", encoding="utf-8") as fh:
            fh.write(diff_text)
        # Permanent, version+timestamp-tagged copy for later reference — mirrors
        # MSSQL's stage2.py; runs unconditionally since assembly diffing is always-on.
        asm_prefix = f"{job['vuln_label']}_{job['fixed_label']}_{job['run_ts']}__{fbase}"
        with open(lp(os.path.join(job["disassembled_dir"], asm_prefix + ".asm.diff")),
                  "w", encoding="utf-8") as fh:
            fh.write(diff_text)
        # Each build's own copy of the function's plain disassembly, in that build's folder,
        # named by that build's function name (a renamed function is filed under each side's
        # own name), so one build's listings can be reused on their own. Skipped for a job
        # without per-version folders (written the old way, e.g. test fakes).
        for side, fname, fmap in (("prior", prior_name, P), ("fixed", fixed_name, F)):
            if fname and fname in fmap:
                folder = version_folder("asm", side)
                if folder:
                    with open(lp(os.path.join(folder, _layout.function_file(fname, ".asm"))),
                              "w", encoding="utf-8") as fh:
                        fh.write(_listing(md, os.path.basename(rel), fname, fmap[fname]))
        # Pseudo-C decompilation (opt-in via --decompile, best-effort, scoped to
        # fix-shaped or CVE-attributed functions only to keep runtime reasonable).
        # Mirrors mssql/stage2.py; ELF function maps already store one contiguous
        # code blob per function, so no chunk-concatenation step is needed here.
        prior_c, fixed_c = "", ""
        if (job.get("decompile")
                and kind not in ("added", "removed")
                and prior_name in P and fixed_name in F
                and (fscore > 0 or cve is not None)
                and _decompile_allowed(job, decompile_stats)):
            _, pb = P[prior_name]
            _, fb = F[fixed_name]
            pctx = side_context("prior", P[prior_name])
            fctx = side_context("fixed", F[fixed_name])
            # DB2-T2-1: decompile BOTH sides under the same assumptions. If one side's context
            # could not be built (a one-sided ELF/I/O failure), drop BOTH — otherwise the
            # context-less side keeps FUN_/DAT_ placeholders at the fixed base while the other
            # gets real callee/data names at its true base, and an UNCHANGED function would show
            # a spurious prior-vs-fixed pseudo-C difference. Both-with or both-without only.
            if pctx is None or fctx is None:
                pctx = fctx = None
            prior_c, fixed_c, attempted = decompile_cached(
                pb, fb, job["decompile_cache"], pctx, fctx)
            if attempted:
                decompile_stats["attempted"] += 1
                # bugs.md #7: one-sided output is a (partial) failure too
                if not (prior_c and fixed_c):
                    decompile_stats["failed"] += 1
                    decompile_failures.append(_dc_failure_record(obj))     # DB2-14
            if (prior_c or fixed_c) and job.get("version_dirs"):
                # Each build's pseudo-C in that build's own folder, by its own function
                # name; the same build and function always give the same file, so a later
                # run refreshes it instead of adding a copy. prior_name/fixed_name are both
                # present here (the gate above requires them in P and F).
                for side, fname, text in (("prior", prior_name, prior_c),
                                          ("fixed", fixed_name, fixed_c)):
                    if text:
                        with open(lp(os.path.join(version_folder("c", side),
                                                  _layout.function_file(fname, ".c"))),
                                  "w", encoding="utf-8") as cf:
                            cf.write(text)
            elif (prior_c or fixed_c) and job.get("decompiled_c_dir"):
                # a job built without per-version folders: one shared folder, as before
                c_prefix = (f"{job['vuln_label']}_{job['fixed_label']}_"
                            f"{job['run_ts']}__{fbase}")
                c_dir = job["decompiled_c_dir"]
                if prior_c:
                    with open(lp(os.path.join(c_dir, c_prefix + ".prior.c")),
                              "w", encoding="utf-8") as cf:
                        cf.write(prior_c)
                if fixed_c:
                    with open(lp(os.path.join(c_dir, c_prefix + ".fixed.c")),
                              "w", encoding="utf-8") as cf:
                        cf.write(fixed_c)
        with open(lp(os.path.join(out, fbase + ".detail.json")), "w", encoding="utf-8") as fh:
            json.dump({"object": obj, "prior": "\n".join(prior_txt),
                       "fixed": "\n".join(fixed_txt),
                       "prior_c": prior_c, "fixed_c": fixed_c, "truncated": False}, fh)
        # cve/confidence are finalised in run() once corroboration (intrinsic/fix/cross-binary)
        # is known
        record = {"object": obj, "file": fbase + ".asm.diff", "pair": fbase + ".detail.json",
                  "src": rel, "kind": "function", "cve": cve, "why": why,
                  "name_conf": name_conf, "change": kind, "similarity": sim,
                  "intrinsic": bool(added_intr),
                  "fix_score": fscore, "fix_why": "; ".join(freasons)}
        if one_sided:
            record["binary_change"] = one_sided       # the whole library is added/removed
        if bd_sim is not None:
            record["bindiff_similarity"] = bd_sim
            record["bindiff_confidence"] = bd_conf
            record["match_algorithm"] = "bindiff"
        else:
            record["match_algorithm"] = "name"
        readable.append(record)

    def emit_data(name, dc):
        """A data card: the constant/table data an UNCHANGED code site in `name` references
        changed content (lever 3). Flows through the same readable list / run() finalisation."""
        cve, why, name_conf = _AT.attribute(name, attrib)
        obj = f"{rel} :: {name}  [data]"
        fbase = "dt__" + _safe(f"{rel}_{name}")
        asc = lambda b: "".join(chr(c) if 32 <= c < 127 else "." for c in b)
        lines = []
        for pt, ft, pb, fb in dc[:20]:
            lines += [f"@ data ref  prior 0x{pt:x}  /  fixed 0x{ft:x}",
                      f"- {pb.hex(' ')}   |{asc(pb)}|",
                      f"+ {fb.hex(' ')}   |{asc(fb)}|", ""]
        text = "\n".join(lines) or "(no data differences)\n"
        with open(lp(os.path.join(out, fbase + ".diff")), "w", encoding="utf-8") as fh:
            fh.write(text)
        with open(lp(os.path.join(out, fbase + ".pair.json")), "w", encoding="utf-8") as fh:
            json.dump({"object": obj, "prior": text, "fixed": text, "truncated": False}, fh)
        readable.append({"object": obj, "file": fbase + ".diff", "pair": fbase + ".pair.json",
                         "src": rel, "kind": "data", "cve": cve, "why": why,
                         "name_conf": name_conf, "change": "data", "similarity": 0.0,
                         "fix_score": 4, "fix_why": f"data referenced by {name} changed "
                                                    f"({len(dc)} site(s))"})

    bd_failed_reason = None
    use_bd = job.get("use_bindiff") and not one_sided   # BinDiff needs both builds
    if use_bd:
        try:
            from patch_differ_cli._bindiff import diff_pair as _bd_diff_pair
            prior_path = os.path.join(prior_dir, rel)
            fixed_path = os.path.join(fixed_dir, rel)
            # Per-ELF subdirectory isolates the Ghidra project from concurrent workers.
            # bug.md DB2-T1-3: these intermediates (a full Ghidra project — GBs for
            # libdb2e.so.1 — plus the .BinExport files and logs) go to a sibling of stage2/,
            # not inside it, so they neither bloat nor clutter the per-version result tree.
            # Fallback to `out` keeps jobs built without "bindiff_dir" (test fakes) working.
            bd_workdir = os.path.join(job.get("bindiff_dir") or out, _safe(rel))

            rep(8, f"{rel}: running BinDiff")
            matches = _bd_diff_pair(prior_path, fixed_path, bd_workdir,
                                    progress=lambda p, m: rep(8 + int(72 * p / 100), m))
            # bugs.md #60: BinDiff reports Ghidra's addresses. Ghidra loads an ET_DYN (.so)
            # at +_GHIDRA_ELF_PIE_BASE but an ET_EXEC at its own absolute addresses, so the
            # fixed +0x100000 used for every ELF mis-mapped each non-PIE executable (all its
            # functions came out as phantom added/removed). The offset is measured from
            # BinDiff's names; the per-type value is only the default (map_matches()).
            from patch_differ_cli._bindiff import map_matches as _bd_map
            addr_to_name_P, addr_to_name_F = _bd_map(
                matches, P, F, _ghidra_elf_default_offset(prior_path),
                _ghidra_elf_default_offset(fixed_path))
        except Exception as exc:
            # A BinDiff/Ghidra hiccup on THIS ONE binary (timeout, misconfiguration, a
            # transient resource issue) must not lose the whole binary's result set —
            # fall back to plain name-based matching for it instead, same as when
            # --use-bindiff isn't passed at all. Other binaries in the run are unaffected
            # either way (each is already its own isolated job via _parallel.py).
            bd_failed_reason = str(exc) or type(exc).__name__
            print(f"WARNING: BinDiff failed for {rel} ({bd_failed_reason}); "
                 f"falling back to name-based matching for this binary.", file=sys.stderr)

    if use_bd and bd_failed_reason is None:
        matched_p_vas, matched_f_vas = set(), set()
        raw_bd = []
        for va1, m in matches.items():
            name_p = addr_to_name_P.get(va1)
            name_f = addr_to_name_F.get(m.addr2)
            if name_p is not None and name_f is not None:
                # Only mark BOTH sides "matched" when BOTH resolve to a known function.
                # A one-sided resolution means BinDiff correctly CFG-matched this pair,
                # but our own symtab-derived function map couldn't place one side (e.g.
                # the fixed-side function grew past _MAX_FUNC_BYTES, a real security fix
                # can easily do that). If the resolved side were marked matched anyway,
                # it would ALSO be excluded from the new/removed derivation below — the
                # function would then be reported nowhere at all: not changed, not added,
                # not removed. Leaving it unmatched here lets it fall through to
                # new/removed instead, same as the default name-based mode would report it.
                matched_p_vas.add(va1)
                matched_f_vas.add(m.addr2)
            if name_p is None or name_f is None:
                continue  # address outside _func_map range
            # bugs.md #53: a BinDiff similarity of 1.0 used to be skipped outright as
            # "CFG-identical". BinDiff scores graph structure and mnemonics, NOT operands,
            # so a changed bounds constant / register width / struct offset scored 1.0 and
            # was never diffed (live-verified: cmp edi,0x100 -> 0xff, zero cards). Only
            # byte-identical functions are skipped; everything else goes through the same
            # norm()/classify() as name mode, which discards relocation-only churn.
            if m.similarity >= 1.0 and P[name_p][1] == F[name_f][1]:
                continue  # truly identical bytes
            # bugs.md #62: a pair of UNNAMED functions (sub_<addr>: no PDB / no symbol) used
            # to be dropped here as "unattributable" — so for a stripped or unsymbolized
            # binary, the very case BinDiff's structural matching is for, Track 1 reported
            # nothing. They go through classify() like any pair; only the added/removed
            # derivation below still excludes sub_ keys (no identity across builds there).
            raw_bd.append((name_p, name_f, m.similarity, m.confidence))

        # Derive new/removed from unmatched address sets.
        # Filter compiler-generated artifacts (.cold, .constprop, .part, etc.): BinDiff
        # frequently fails to match these across builds because inlining/outlining decisions
        # change their structure entirely between compiler runs.  They appear as phantom
        # added/removed pairs with no attribution value; the _ARTIFACT regex matches them
        # the same way the name-mode sort key de-prioritises them.
        removed = sorted(
            name for va, name in addr_to_name_P.items()
            if va not in matched_p_vas and not name.startswith("sub_")
            and not _ARTIFACT.search(name)
        )
        new = sorted(
            name for va, name in addr_to_name_F.items()
            if va not in matched_f_vas and not name.startswith("sub_")
            and not _ARTIFACT.search(name)
        )

        # bugs.md #63: BinDiff leaves a function unmatched when the fix restructures it
        # (added guards/branches) or when several functions look alike — and for MSSQL,
        # Ghidra sees the PE without its PDB, so BinDiff can't fall back on names. Such a
        # function was reported as BOTH removed and added and never diffed (and a pure
        # reorder made phantom cards). Pair what's still unmatched on both sides under
        # the same (non-sub_) name, by name, as name mode does; byte-identical pairs are
        # unchanged. Only names left over are added/removed.
        _unp = {n for va, n in addr_to_name_P.items()
                if va not in matched_p_vas and not n.startswith("sub_")}
        _unf = {n for va, n in addr_to_name_F.items()
                if va not in matched_f_vas and not n.startswith("sub_")}
        _by_name = _unp & _unf
        for name in sorted(_by_name):
            if P[name][1] != F[name][1]:
                raw_bd.append((name, name, None, None))   # no BinDiff sim: name-paired
        removed = [n for n in removed if n not in _by_name]
        new = [n for n in new if n not in _by_name]

        # attr_cache must cover BOTH sides of each renamed pair so sort key never KeyErrors.
        attr_cache = {}
        for pn, fn, _, _ in raw_bd:
            for k in (pn, fn):
                if k not in attr_cache:
                    attr_cache[k] = _AT.attribute(k, attrib)
        for k in new + removed:
            if k not in attr_cache:
                attr_cache[k] = _AT.attribute(k, attrib)

        # bug.md DB2-T1-1: lever 3 (opt-in) in BinDiff mode too — a changed function whose
        # referenced .rodata/.data content also changed gets a data card, exactly as in name
        # mode (below). Only over the same code-changed pairs name mode diffs; a byte-
        # identical pair is skipped by both (it never reaches raw_bd).
        use_data = _DATA_DIFF and not one_sided
        pdr = _data_reader(os.path.join(prior_dir, rel)) if use_data else None
        fdr = _data_reader(os.path.join(fixed_dir, rel)) if use_data else None
        data_hits = {}       # fixed_name -> [(prior_addr, fixed_addr, prior_bytes, fixed_bytes)]
        hits = []
        for prior_name, fixed_name, bd_sim, bd_conf in raw_bd:
            pv, pc = P[prior_name]; fv, fc = F[fixed_name]
            pL, pS, pI = _X.norm(md, pv, pc)
            fL, fS, fI = _X.norm(md, fv, fc)
            cls = _X.classify(pL, pS, pI, fL, fS, fI)
            if cls in ("same", "churn"):
                continue
            sm = difflib.SequenceMatcher(a=pL, b=fL, autojunk=False)
            sim = sm.ratio()
            fpre = _X.fix_signature(pL, fL, opcodes=sm.get_opcodes())[0]
            hits.append((prior_name, fixed_name, "size" if len(pc) != len(fc) else cls,
                         round(sim, 4), pL, fL, fpre, bd_sim, bd_conf))
            if use_data:
                dc = _data_changes(pL, fL, _X.rip_data_targets(md, pv, pc),
                                   _X.rip_data_targets(md, fv, fc),
                                   pdr[0], pdr[1], pdr[2], fdr[0], fdr[1], fdr[2])
                if dc:
                    data_hits[fixed_name] = dc

        funcs_total = len(hits) + len(new) + len(removed)
        # BinDiff hits: h[0]=prior_name, h[1]=fixed_name, h[6]=fpre, h[3]=simr.
        # A renamed function's CVE may sit on either name; sort attributed entries
        # (either name matches) before unattributed ones. Final (prior, fixed) name
        # tie-breakers (bugs.md #4): the pre-sort order comes from BinDiff's SQLite rows,
        # which have no guaranteed order, so exact ties could otherwise swap between runs
        # of the same input and change which functions survive the _EMIT_CAP truncation.
        hits.sort(key=lambda h: (attr_cache[h[0]][0] is None and attr_cache[h[1]][0] is None,
                                 -h[6], h[3], h[0], h[1]))

        rep(82, f"{rel}: writing diffs")
        rel_cards = capped = 0
        for name in new:
            if not (attr_cache[name][0] or rel_cards < _EMIT_CAP):
                capped += 1
                continue
            fv2, fc2 = F[name]
            fL, _s, _i = _X.norm(md, fv2, fc2)
            emit(None, name, "added", 0.0, [], fL); rel_cards += 1
        for name in removed:
            if not (attr_cache[name][0] or rel_cards < _EMIT_CAP):
                capped += 1
                continue
            pv2, pc2 = P[name]
            pL, _s, _i = _X.norm(md, pv2, pc2)
            emit(name, None, "removed", 0.0, pL, []); rel_cards += 1
        for prior_name, fixed_name, kind, sim, pL, fL, fpre, bd_sim, bd_conf in hits:
            # Check attribution on BOTH sides: a rename may carry the CVE token on the
            # new name (fixed_name) while the old name (prior_name) has no match.
            if attr_cache[prior_name][0] or attr_cache[fixed_name][0] or fpre > 0 or rel_cards < _EMIT_CAP:
                emit(prior_name, fixed_name, kind, sim, pL, fL,
                     bd_sim=bd_sim, bd_conf=bd_conf); rel_cards += 1
                # bug.md DB2-NT-1: the data card (opt-in) rides with its function card, so it
                # is bounded by the same _EMIT_CAP and never emitted for a capped function.
                if fixed_name in data_hits:
                    emit_data(fixed_name, data_hits[fixed_name])
            else:
                capped += 1

    else:
        common = P.keys() & F.keys()
        # sub_-prefixed keys (no ELF symbol name, see _func_map()) are excluded from
        # new/removed: an address present on only one side is an unreliable signal for
        # an unnamed function specifically — any unrelated layout shift elsewhere in the
        # binary changes every downstream address, which would manufacture phantom
        # added/removed entries rather than catch a real one. `raw` below has no such
        # filter: a shared address IS a reliable "same function slot" signal.
        # (a one-sided binary has no cross-build address ambiguity: every function there,
        # named or not, genuinely is added/removed — bugs.md #3)
        new = sorted(k for k in F.keys() - P.keys() if one_sided or not k.startswith("sub_"))
        removed = sorted(k for k in P.keys() - F.keys() if one_sided or not k.startswith("sub_"))

        # lever 3 (opt-in): data-section readers for the pointed-to data an unchanged code site refs
        # (none for a one-sided binary: no common functions, and one side doesn't exist)
        use_data = _DATA_DIFF and not one_sided
        pdr = _data_reader(os.path.join(prior_dir, rel)) if use_data else None
        fdr = _data_reader(os.path.join(fixed_dir, rel)) if use_data else None
        data_hits = {}       # name -> [(prior_addr, fixed_addr, prior_bytes, fixed_bytes)]

        # cheap pass: only names whose raw bytes differ go to the disasm pass
        raw = [k for k in common if P[k][1] != F[k][1]]
        hits = []
        for j, k in enumerate(raw):
            if j % 2000 == 0:
                rep(5 + int(85 * j / max(1, len(raw))),
                    f"{rel}: analyzing {j}/{len(raw)} changed")
            pv, pc = P[k]; fv, fc = F[k]
            pL, pS, pI = _X.norm(md, pv, pc)
            fL, fS, fI = _X.norm(md, fv, fc)
            cls = _X.classify(pL, pS, pI, fL, fS, fI)
            if cls in ("same", "churn"):
                continue
            sm = difflib.SequenceMatcher(a=pL, b=fL, autojunk=False)
            sim = sm.ratio()
            # pre-score fix-shapedness (reusing the matcher) so a small fix-shaped change is
            # NEVER dropped at the emit cap just because its similarity is high / it's unattributed.
            fpre = _X.fix_signature(pL, fL, opcodes=sm.get_opcodes())[0]
            hits.append((k, "size" if len(pc) != len(fc) else cls, round(sim, 4), pL, fL, fpre))
            if _DATA_DIFF:
                dc = _data_changes(pL, fL, _X.rip_data_targets(md, pv, pc),
                                   _X.rip_data_targets(md, fv, fc),
                                   pdr[0], pdr[1], pdr[2], fdr[0], fdr[1], fdr[2])
                if dc:
                    data_hits[k] = dc

        funcs_total = len(hits) + len(new) + len(removed)
        # Pre-compute attribution once to avoid O(N log N) redundant calls in the sort key
        # and O(N) redundant calls in the cap-bypass checks below.
        attr_cache = {**{h[0]: _AT.attribute(h[0], attrib) for h in hits},
                         **{n: _AT.attribute(n, attrib) for n in new + removed}}
        # Name-mode hits: h[0]=name, h[5]=fpre, h[2]=simr. Final tie-breaker (h[0], the
        # name itself) makes which functions survive the _EMIT_CAP truncation below
        # deterministic across runs — without it, `common` (a dict_keys & dict_keys set
        # intersection) iterates in a hash-seed-dependent order, so two exactly-tied
        # candidates could swap places between runs of the SAME input, silently changing
        # which ~N of a large tied group get truncated away by the cap.
        hits.sort(key=lambda h: (attr_cache[h[0]][0] is None, -h[5], h[2], h[0]))

        rep(92, f"{rel}: writing diffs")
        # new / removed functions (strongest signal: an added guard/check). Disasm only the
        # ones we'll actually emit (attributed, or until the per-lib card cap).
        rel_cards = capped = 0
        for name in new:
            if not (attr_cache[name][0] or rel_cards < _EMIT_CAP):
                capped += 1
                continue
            fL, _s, _i = _X.norm(md, *F[name])
            emit(None, name, "added", 0.0, [], fL); rel_cards += 1
        for name in removed:
            if not (attr_cache[name][0] or rel_cards < _EMIT_CAP):
                capped += 1
                continue
            pL, _s, _i = _X.norm(md, *P[name])
            emit(name, None, "removed", 0.0, pL, []); rel_cards += 1
        # a fix-shaped change (fpre>0) is ALWAYS emitted, even unattributed and past the cap;
        # the cap only bounds the remaining recompilation churn.
        for name, kind, sim, pL, fL, fpre in hits:
            if attr_cache[name][0] or fpre > 0 or rel_cards < _EMIT_CAP:
                emit(name, name, kind, sim, pL, fL); rel_cards += 1
                # bug.md DB2-NT-1: the data card (opt-in) rides with its function card, so it
                # is bounded by the same _EMIT_CAP and never emitted for a capped function.
                if name in data_hits:
                    emit_data(name, data_hits[name])
            else:
                capped += 1

    rep(100, f"{rel}: done")
    return {"rel": rel, "readable": readable, "funcs_total": funcs_total, "ok": True,
            "skipped_functions": skipped,
            # DB2-4: ordinary changed functions not written because this library reached
            # _EMIT_CAP cards (attributed and fix-shaped ones are always written)
            "functions_capped": capped,
            "dynsym_only": dynsym_only,              # DB2-18: exported functions only
            # bugs.md #57: a requested BinDiff run that fell back used to be only a
            # stderr print; it's now part of the result (counted, exit 3)
            "bindiff_fallback": ({"rel": rel, "reason": bd_failed_reason}
                                 if bd_failed_reason else None),
            "decompile_attempted": decompile_stats["attempted"],
            "decompile_failed": decompile_stats["failed"],
            "decompile_skipped": decompile_stats["skipped"],
            "decompile_failures": decompile_failures}


def run(prior_dir, fixed_dir, workdir, stage0=None, progress=None, use_bindiff=False,
        decompile=False, vuln_label=None, fixed_label=None, bindiff_only=None,
        decompile_max=None):
    """bindiff_only: glob patterns; only matching binaries get BinDiff (DB2-12).
    decompile_max: at most this many pseudo-C decompiles per binary (DB2-12)."""
    out = os.path.join(workdir, "stage2")
    os.makedirs(lp(out), exist_ok=True)
    if not _CAP:
        raise RuntimeError("Stage 2 needs capstone (pip install capstone)")

    # which ELFs: Stage-0 code_changed that exist both sides (fallback: the engine lib).
    if stage0 is None:
        # bugs.md #43: only a Stage 0 result produced by triage of THESE inputs is used. Any
        # changed_files.json found here used to be trusted — one written for another input
        # pair was analyzed as current (an empty one meant "nothing changed"); a missing,
        # stale or foreign one now raises instead.
        stage0 = _rs.bound_stage0(workdir, prior_dir, fixed_dir)

    # bugs.md #3: route every listed binary instead of filtering. Present on both sides ->
    # two-sided diff; on one side only -> one-sided inventory; on neither -> a recorded
    # failure. (A code_changed entry that exists on one side only — e.g. a changed_files.json
    # from an older triage reused by a Stage-2-only run — used to be dropped silently here.)
    changed, one_sided, missing = [], {}, []
    for c in [e["name"] for e in (stage0 or {}).get("code_changed", [])]:
        in_p = os.path.isfile(lp(os.path.join(prior_dir, c)))
        in_f = os.path.isfile(lp(os.path.join(fixed_dir, c)))
        if in_p and in_f:
            changed.append(c)
        elif in_p or in_f:
            one_sided[c] = "added" if in_f else "removed"
        else:
            missing.append(c)
    # ELF binaries triage found on only one side -> one-sided inventory jobs
    for tag, root in (("added", fixed_dir), ("removed", prior_dir)):
        for e in (stage0 or {}).get(tag, []) or []:
            name = e.get("name") if isinstance(e, dict) else None
            if (name and e.get("kind") == "native" and name not in changed
                    and os.path.isfile(lp(os.path.join(root, name)))):
                one_sided[name] = tag
    if not changed and not one_sided and not missing:
        cand = "lib64/libdb2e.so.1"
        if (os.path.isfile(lp(os.path.join(prior_dir, cand)))
                and os.path.isfile(lp(os.path.join(fixed_dir, cand)))):
            changed = [cand]
    if not changed and not one_sided and not missing:
        result = {"available": True,
                  "counts": {"libs": 0, "changed_functions": 0, "readable_changed": 0,
                             "attributed": 0, "candidates": 0, "failed": 0,
                             "decompile_attempted": 0, "decompile_failed": 0},
                  "libs": [], "failed_binaries": [], "files": [], "readable_files": []}
        with open(lp(os.path.join(out, "functions_diff.json")), "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2)
        if progress:
            progress(100, "Stage 2 complete — no changed binaries")
        return result

    # weight progress by file size (libdb2e.so.1 dwarfs the rest — a count-weighted bar
    # would barely move through it).
    weights = {}
    for rel in changed + list(one_sided):
        root = prior_dir if one_sided.get(rel) == "removed" else fixed_dir
        try:
            weights[rel] = max(1, os.path.getsize(lp(os.path.join(root, rel))))
        except OSError:
            weights[rel] = 1
    attrib = _AT.load_attrib(workdir)             # patch's tracked CVEs -> name/CWE tokens
    # Per-version output, mirroring mssql/stage2.py: each build gets its own folders
    # (disassembled_instructions_<build>_<version>/, decompiled_c_<build>_<version>/, one
    # <binary>_<sha8>/ subfolder per ELF), so one build's results can be reused on their
    # own. The assembly DIFFS compare the two builds, so they keep one folder per pair
    # (disassembled_instructions_<vuln>_vs_<fixed>/), with permanent per-run copies named
    # <vuln>_<fixed>_<run_ts>__fn__<bin>_<func>.asm.diff — one timestamp per run. Assembly
    # diffing is always on; the pseudo-C folders are created only with --decompile.
    decompile_cache = os.path.join(out, "decompile_cache")
    run_ts = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    vver, fver = _version_token(vuln_label), _version_token(fixed_label)
    vlabel = vver if vuln_label else "vuln"
    flabel = fver if fixed_label else "fixed"
    version_dirs = _version_dirs(out, vver, fver)
    disassembled_dir = _layout.pair_diff_dir(out, vver, fver)
    os.makedirs(lp(disassembled_dir), exist_ok=True)
    # the per-version folders are created by the first file written into them
    # (_binary_folder), so a run with nothing to write leaves no empty folder
    if decompile:
        os.makedirs(lp(decompile_cache), exist_ok=True)
    # bug.md DB2-T1-3: BinDiff working data (Ghidra project + .BinExport + logs) lives beside
    # stage2/, not inside it, so the result tree stays clean and a re-run still finds the cache.
    bindiff_dir = os.path.join(workdir, "bindiff_work")
    from .._bindiff import bindiff_selected
    jobs_list = [{"prior_dir": prior_dir, "fixed_dir": fixed_dir, "rel": rel, "out": out,
                  "attrib": attrib,
                  "use_bindiff": use_bindiff and bindiff_selected(rel, bindiff_only),
                  "decompile": decompile, "decompile_max": decompile_max,
                  "decompile_cache": decompile_cache, "bindiff_dir": bindiff_dir,
                  "disassembled_dir": disassembled_dir,
                  "version_dirs": version_dirs,
                  "run_ts": run_ts, "vuln_label": vlabel, "fixed_label": flabel,
                  "one_sided": one_sided.get(rel)}
                 for rel in changed + sorted(one_sided)]
    # DB2-12: two-sided binaries --bindiff-only left to name matching (by choice, not a
    # fallback)
    not_selected = sorted(j["rel"] for j in jobs_list
                          if use_bindiff and not j["use_bindiff"] and not j["one_sided"])

    readable, funcs_total, libs_done, failed = [], 0, [], []
    failed += [{"rel": c, "error": "listed as changed by triage but present on neither "
                "side — could not be analyzed"} for c in missing]
    decompile_attempted = decompile_failed = decompile_skipped = 0
    skipped = []                 # changed functions too large to diff (#28)
    bd_fallbacks = []            # binaries --use-bindiff fell back to name matching (#57)
    capped_libs = []             # libraries that reached the card cap (DB2-4)
    dynsym_libs = []             # libraries diffed from .dynsym only (DB2-18)

    dc_failures = []             # per-function pseudo-C failure reasons (DB2-14)

    def absorb(r):
        nonlocal funcs_total, decompile_attempted, decompile_failed, decompile_skipped
        decompile_skipped += r.get("decompile_skipped", 0)
        dc_failures.extend(dict(f, rel=r["rel"]) for f in r.get("decompile_failures") or ())
        if r.get("ok"):
            libs_done.append(r["rel"])
        else:
            failed.append({"rel": r["rel"], "error": r.get("error") or "binary could not be analyzed"})
        readable.extend(r["readable"])
        skipped.extend(r.get("skipped_functions") or [])
        if r.get("bindiff_fallback"):
            bd_fallbacks.append(r["bindiff_fallback"])
        if r.get("functions_capped"):
            capped_libs.append({"rel": r["rel"], "count": r["functions_capped"]})
        if r.get("dynsym_only"):
            dynsym_libs.append(r["dynsym_only"])
        funcs_total += r["funcs_total"]
        decompile_attempted += r.get("decompile_attempted", 0)
        decompile_failed += r.get("decompile_failed", 0)

    def on_error(rel, exc):
        # A binary whose worker raised (anything NOT already caught/handled inside
        # _process_file, e.g. an ELF-parse or capstone failure unrelated to BinDiff) must
        # not just vanish — record it so the result can't be mistaken for a clean
        # "this binary had no real changes".
        failed.append({"rel": rel, "error": str(exc)[:300]})

    # Each changed .so is diffed in its own process (host-friendly cap + below-normal
    # priority live in _parallel). Deterministic — output is sorted below.
    _parallel.run_jobs(jobs_list, _process_file, weights, progress=progress,
                       on_result=absorb, on_error=on_error)

    from .. import _results
    _results.mark_cross_binary(readable)          # client+server / shared-code fix signal
    # Finalise attribution via _AT.resolve(): a 'high' name/CWE match (a specific-subsystem
    # hit) stands alone as an ASSERTED CVE, corroboration by an independent change signal
    # (added security intrinsic, fix-shaped diff, or cross-binary) only raising its
    # confidence med->high; a weaker ('med'/'low') match is ASSERTED ONLY with
    # corroboration, else downgraded to a low-confidence 'candidate' (kept, but not a CVE
    # claim). Fixes cumulative-patch over-attribution (name-substring gave 408 CVE labels;
    # ~35 are corroborated).
    for r in readable:
        corrob = (bool(r.get("intrinsic")) or (r.get("fix_score") or 0) > 0
                  or bool(r.get("cross_binary")))
        conf, asserted = _AT.resolve(r.pop("name_conf", None), corrob)
        r["confidence"] = conf
        if not asserted and r.get("cve"):
            r["cve_candidate"] = r.pop("cve")     # matched but uncorroborated
            r["cve"] = None
    readable.sort(key=_rank)
    result = {
        "available": True,
        "counts": {"libs": len(libs_done), "changed_functions": funcs_total,
                   "readable_changed": len(readable),
                   "attributed": sum(1 for r in readable if r.get("cve")),
                   "candidates": sum(1 for r in readable if r.get("cve_candidate")),
                   "failed": len(failed),
                   "functions_skipped": len(skipped),
                   "bindiff_fallbacks": len(bd_fallbacks),
                   "functions_capped": sum(c["count"] for c in capped_libs),
                   "dynsym_only": len(dynsym_libs),
                   "decompile_attempted": decompile_attempted,
                   "decompile_failed": decompile_failed,
                   "decompile_skipped": decompile_skipped},
        "bindiff_not_selected": not_selected,
        "decompile_failures": sorted(dc_failures, key=lambda f: (f["rel"], f["object"])),
        "libs": libs_done,
        "failed_binaries": failed,
        "skipped_functions": sorted(skipped, key=lambda s: (s["rel"], s["name"])),
        "bindiff_fallbacks": sorted(bd_fallbacks, key=lambda b: b["rel"]),
        "capped_functions": sorted(capped_libs, key=lambda c: c["rel"]),
        "dynsym_only": sorted(dynsym_libs, key=lambda d: d["rel"]),
        "files": [], "readable_files": readable,
    }
    with open(lp(os.path.join(out, "functions_diff.json")), "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    if progress:
        progress(100, "Stage 2 complete")
    return result