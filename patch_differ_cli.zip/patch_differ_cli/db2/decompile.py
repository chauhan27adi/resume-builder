"""DEPRECATED / SUPERSEDED — not imported by any module (bug.md DB2-T1-4).

DB2 Stage 2 now decompiles through the shared, backend-neutral ``patch_differ_cli._decompile``
(``decompile_cached`` / ``decompile_cached_per_side``, see ``db2/stage2.py``'s import of it).
This module is the original DB2-only per-function decompiler; it is retained for reference
only and is wired to nothing. Do NOT import it in new code — use ``.._decompile`` instead.
If it is confirmed unneeded it can be removed outright (its history lives in the review and
in ``docs/old_bugs_fixed.md``).

----------------------------------------------------------------------------------------------
On-demand, cached C decompilation of a SINGLE changed DB2 function (Stage 2).

The Stage-2 assembly diff stays the canonical result; this is an additive,
best-effort readable-C view. Instead of importing the ~330 MB `libdb2e.so.1`
into Ghidra (intractable), we carve the ONE function's exact bytes into a tiny
raw blob and decompile just that via Ghidra headless (see ghidra/DecompileFunc.java).

Flow (per function, cached):
  _one_func()  -> (vaddr, bytes) for the symbol on the prior & fixed .so
  carve both  -> prior.bin / fixed.bin (a temp dir)
  analyzeHeadless -import <dir> -postScript DecompileFunc.java <outDir>  (one JVM run, both sides)
  read prior.c / fixed.c -> light-normalize (mask synthetic FUN_/DAT_ address churn only) ->
  write <out_dir>/<fnbase>.decomp.pair.json  (same {object,prior,fixed} shape /split consumes)

Cost is Ghidra JVM startup, not analysis; cached so re-opens are instant.
"""
import json
import os
import struct

from ._paths import lp
from .stage2 import _safe            # reuse the exact fn__<safe> naming used by Stage 2
from .. import _decompile as _dc     # shared Ghidra blob-decompile engine


# --------------------------------------------------------------------------- ELF single symbol
def _one_func(so_path, name):
    """(vaddr, code_bytes) for one STT_FUNC by name — reads only the section headers,
    symtab and strtab (not the ~199 MB .text), then seeks the function's bytes.
    Returns (None, None) if not found. ELF64 LE, pure struct parse."""
    with open(lp(so_path), "rb") as f:
        hdr = f.read(64)
        if hdr[:4] != b"\x7fELF" or hdr[4] != 2:
            return None, None
        e_shoff = struct.unpack_from("<Q", hdr, 0x28)[0]
        e_shentsize = struct.unpack_from("<H", hdr, 0x3A)[0]
        e_shnum = struct.unpack_from("<H", hdr, 0x3C)[0]
        e_shstrndx = struct.unpack_from("<H", hdr, 0x3E)[0]
        f.seek(e_shoff)
        sh = f.read(e_shentsize * e_shnum)

        def rec(i):
            b = i * e_shentsize
            return {"name": struct.unpack_from("<I", sh, b)[0],
                    "addr": struct.unpack_from("<Q", sh, b + 16)[0],
                    "off": struct.unpack_from("<Q", sh, b + 24)[0],
                    "size": struct.unpack_from("<Q", sh, b + 32)[0]}

        ss = rec(e_shstrndx)
        f.seek(ss["off"]); shstr = f.read(ss["size"])
        snm = lambda n: shstr[n:shstr.find(b"\0", n)].decode("latin-1")
        secs = {snm(rec(i)["name"]): rec(i) for i in range(e_shnum)}
        if ".text" not in secs or ".symtab" not in secs or ".strtab" not in secs:
            return None, None
        text, sym, strt = secs[".text"], secs[".symtab"], secs[".strtab"]
        f.seek(strt["off"]); st = f.read(strt["size"])
        nm = lambda n: st[n:st.find(b"\0", n)].decode("latin-1")
        f.seek(sym["off"]); data = f.read(sym["size"])
        tv, thi = text["addr"], text["addr"] + text["size"]
        for i in range(len(data) // 24):
            b = i * 24
            if (data[b + 4] & 0xf) != 2:                    # STT_FUNC
                continue
            if nm(struct.unpack_from("<I", data, b)[0]) != name:
                continue
            val = struct.unpack_from("<Q", data, b + 8)[0]
            sz = struct.unpack_from("<Q", data, b + 16)[0]
            if sz == 0 or not (tv <= val < thi):
                return None, None
            f.seek(text["off"] + (val - tv))
            return val, f.read(sz)
    return None, None


# --------------------------------------------------------------------------- entry
GhidraNotConfigured = _dc.GhidraNotConfigured


def available():
    return _dc.available()


def cache_name(rel, name):
    return "fn__" + _safe(f"{rel}_{name}") + ".decomp.pair.json"


def decompile_function(prior_dir, fixed_dir, rel, name, out_dir, progress=None):
    """Decompile `name` from `rel` on both sides to C, write a cached .decomp.pair.json
    under out_dir, and return its path. No-op (returns the path) if already cached."""
    os.makedirs(lp(out_dir), exist_ok=True)
    cache = os.path.join(out_dir, cache_name(rel, name))
    if os.path.isfile(lp(cache)):
        return cache
    if progress:
        progress(5, "Carving function bytes")
    _pv, pb = _one_func(os.path.join(prior_dir, rel), name)
    _fv, fb = _one_func(os.path.join(fixed_dir, rel), name)
    if not pb and not fb:
        raise RuntimeError(f"symbol not found on either side: {name} in {rel}")
    if progress:
        progress(20, "Running Ghidra decompiler")
    prior_c, fixed_c = _dc.decompile_pair(pb, fb)
    payload = {
        "object": f"{rel} :: {name}",
        "prior": _dc.norm_c(prior_c) if pb else "// (function absent in prior build)\n",
        "fixed": _dc.norm_c(fixed_c) if fb else "// (function absent in fixed build)\n",
        "truncated": False,
    }
    with open(lp(cache), "w", encoding="utf-8") as fh:
        json.dump(payload, fh)
    if progress:
        progress(100, "Done")
    return cache