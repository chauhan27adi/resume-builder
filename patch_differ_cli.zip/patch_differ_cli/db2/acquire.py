"""Acquire + extract the two DB2 build trees to diff — the only online part.

Per-side pluggable source (encoded in the patch's dl_url / vuln_dl_url):
  container:<ref>   e.g. container:icr.io/db2_community/db2:12.1.5.0
                    anonymous Docker registry v2 pull (no IBM ID); free GA builds.
  manual:<label>    a Fix Central special-build universal fixpack (.tar.gz) the user
                    drops in <workdir>/acquire/<side>/drop/ (IBM ID download, no SSO
                    automation). Used for the FIXED side of special-build-only CVEs.
  fixcentral:<id>   reserved — authenticated Fix Central automation (not built yet).

Returns {"vuln": <db2 version dir>, "fixed": <db2 version dir>} where the version dir
is the `.../opt/ibm/db2/V<x>` root that triage/stage1/stage2 walk. Idempotent: skips a
side whose tree finished extracting from the SAME requested source (see _acquire_state);
anything else is re-extracted into a staging dir and swapped in. Layer blobs are cached
(shared, by digest) so a re-run or the other side reuses them.

TLS: this must work behind a corporate MITM proxy. It honours REQUESTS_CA_BUNDLE (point
at the corporate CA); set PATCHDIFF_INSECURE_TLS=1 only for local spikes.
"""
import gzip
import hashlib
import io
import json
import logging
import os
import posixpath
import re
import shutil
import struct
import subprocess
import tarfile

import requests

from ._paths import lp
from .. import _acquire_state as _state
from .. import tool_paths as tp


def _source_identity(spec, kind, side_dir):
    """What a side's tree is extracted FROM. For a manual drop the label alone isn't enough
    — a different fixpack can be dropped under the same label — so include the archive's
    fingerprint when one is present."""
    ident = {"spec": spec}
    if kind == "manual":
        tar = _manual_drop(side_dir)
        ident["drop"] = _state.file_fingerprint(tar) if tar else None
    return ident


def _source_matches(recorded, requested):
    """Same spec, and the same drop archive — unless the drop has since been removed (users
    delete the multi-GB archive after extracting), in which case the label is all we have."""
    if not isinstance(recorded, dict) or recorded.get("spec") != requested.get("spec"):
        return False
    if requested.get("drop") is None:
        return True
    return recorded.get("drop") == requested.get("drop")


def _invalidate_manifest(workdir):
    try:
        os.remove(lp(os.path.join(workdir, "acquire", "manifest.json")))
    except OSError:
        pass


class UnwritableMember(OSError):
    """The destination file for an archive member can't be created on this filesystem (a
    name Windows rejects such as `a?b` or a file/dir clash). Only the output side — a read
    error on the archive itself stays a plain exception."""


_log = logging.getLogger(__name__)


def _makedirs(path):
    try:
        os.makedirs(lp(path), exist_ok=True)
    except OSError as e:
        raise UnwritableMember(f"cannot create directory {path!r}: {e}") from e


def _copy_hash(src, out_path, hashes, key):
    """Copy a stream to disk while SHA-256'ing it in the same pass (hashing during extract
    is free and lets Stage 0 skip a second read+hash). Records hashes[key] = sha."""
    h = hashlib.sha256()
    try:
        w = open(lp(out_path), "wb")
    except OSError as e:
        raise UnwritableMember(f"cannot create {out_path!r}: {e}") from e
    with w:
        while True:
            b = src.read(1 << 20)
            if not b:
                break
            w.write(b)
            h.update(b)
    if hashes is not None:
        hashes[key] = h.hexdigest()

_DEFAULT_REG = "icr.io"
_ACCEPT = ",".join([
    "application/vnd.docker.distribution.manifest.v2+json",
    "application/vnd.oci.image.manifest.v1+json",
    "application/vnd.docker.distribution.manifest.list.v2+json",
    "application/vnd.oci.image.index.v1+json",
])
_SUBTREE = "opt/ibm/db2/"          # only extract the DB2 product tree (not the whole rootfs)


# --------------------------------------------------------------------------- TLS / http
def _verify():
    if os.environ.get("PATCHDIFF_INSECURE_TLS") == "1":
        import urllib3
        urllib3.disable_warnings()
        return False
    return os.environ.get("REQUESTS_CA_BUNDLE") or True


def _session():
    s = requests.Session()
    s.verify = _verify()
    s.headers["User-Agent"] = "cve-patch-differ/db2"
    return s


# --------------------------------------------------------------------------- registry
def _parse_ref(ref):
    """'icr.io/db2_community/db2:12.1.5.0' -> (registry, repo, tag)."""
    host, rest = ref.split("/", 1)
    if ":" in rest.rsplit("/", 1)[-1]:
        repo, tag = rest.rsplit(":", 1)
    else:
        repo, tag = rest, "latest"
    return host, repo, tag


def _token(s, reg, repo):
    r = s.get(f"https://{reg}/v2/", timeout=30)
    m = re.search(r'realm="([^"]+)".*?service="([^"]+)"', r.headers.get("WWW-Authenticate", ""))
    if not m:
        return None
    realm, svc = m.group(1), m.group(2)
    tr = s.get(realm, params={"service": svc, "scope": f"repository:{repo}:pull"}, timeout=30)
    return tr.json().get("token") or tr.json().get("access_token")


def list_tags(reg=_DEFAULT_REG, repo="db2_community/db2"):
    """All tags for a repo (anonymous). Used by patches.py to build GA-boundary pairs."""
    s = _session()
    tok = _token(s, reg, repo)
    h = {"Authorization": f"Bearer {tok}"} if tok else {}
    r = s.get(f"https://{reg}/v2/{repo}/tags/list", headers=h, timeout=60)
    r.raise_for_status()
    return r.json().get("tags", [])


def _amd64_layers(s, reg, repo, tag, tok):
    h = {"Authorization": f"Bearer {tok}", "Accept": _ACCEPT} if tok else {"Accept": _ACCEPT}
    mani = s.get(f"https://{reg}/v2/{repo}/manifests/{tag}", headers=h, timeout=60).json()
    if "manifests" in mani:                       # multi-arch index -> pick amd64
        cand = [x for x in mani["manifests"]
                if x.get("platform", {}).get("architecture") == "amd64"]
        if not cand:
            raise RuntimeError(f"no amd64 manifest for {repo}:{tag}")
        mani = s.get(f"https://{reg}/v2/{repo}/manifests/{cand[0]['digest']}",
                     headers=h, timeout=60).json()
    return mani.get("layers", [])


_LAYER_CACHE = None   # set by pipeline.py before calling acquire(); otherwise ~/.patch-differ/layers


def _cache_dir():
    base = _LAYER_CACHE or os.path.join(os.path.expanduser("~"), ".patch-differ", "layers")
    os.makedirs(lp(base), exist_ok=True)
    return base


def _digest_hex(digest):
    """The hex of a "sha256:<64 hex>" OCI digest; anything else can't be verified."""
    algo, _, hexd = (digest or "").partition(":")
    if algo != "sha256" or not re.fullmatch(r"[0-9a-f]{64}", hexd):
        raise RuntimeError(f"unsupported layer digest {digest!r} (expected sha256:<64 hex>)")
    return hexd


def _sha256_into(h, path):
    with open(lp(path), "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h


def _layer_ok(dest, digest):
    """True if the cached layer `dest` matches `digest` (bugs.md #21); one that doesn't is
    deleted so it gets downloaded again.

    Verified by hashing the bytes EVERY time a cached layer is about to be used. An earlier
    version of this fix trusted a `.verified` stamp of digest + size + mtime after the first
    check — but a layer replaced with different bytes of the same size, with its timestamp
    restored, matched the stamp and was extracted as the build. Layers are only read here
    when a tree is being (re)extracted, which reads every layer in full anyway, so the extra
    sequential pass is small next to the extraction it guards."""
    hexd = _digest_hex(digest)
    try:
        os.remove(lp(dest + ".verified"))          # stamp left by that earlier version
    except OSError:
        pass
    if not os.path.isfile(lp(dest)):
        return False
    if _sha256_into(hashlib.sha256(), dest).hexdigest() == hexd:
        return True
    try:
        os.remove(lp(dest))
    except OSError:
        pass
    return False


def _download_blob(s, reg, repo, digest, tok, dest, progress=None, base=0, span=0):
    """Download one layer blob to `dest`, resuming a leftover `<dest>.part`.

    bugs.md #21: the bytes were never checked against the digest they were requested by,
    so a truncated, corrupted or wrong blob (and a stale .part resumed onto) was cached
    for good and analyzed as the build. The blob is now SHA-256'd while it streams (a
    resumed .part's prefix first) and promoted to `dest` only on an exact digest match.
    bugs.md #41: a .part already holding the whole blob (interrupted between the transfer
    and the rename) made the resumed range request fail with HTTP 416 on every retry. On
    416 a .part that matches the digest is promoted; otherwise it's discarded and the
    download restarts. A mismatch after a resume also restarts from scratch once."""
    hexd = _digest_hex(digest)
    if _layer_ok(dest, digest):
        return dest
    tmp = dest + ".part"
    for attempt in (1, 2):
        have = os.path.getsize(lp(tmp)) if os.path.exists(lp(tmp)) else 0
        sha = _sha256_into(hashlib.sha256(), tmp) if have else hashlib.sha256()
        h = {"Authorization": f"Bearer {tok}"} if tok else {}
        if have:
            h["Range"] = f"bytes={have}-"
        with s.get(f"https://{reg}/v2/{repo}/blobs/{digest}", headers=h, stream=True,
                   timeout=900) as r:
            if r.status_code == 416 and have:
                complete = sha.hexdigest() == hexd
            else:
                r.raise_for_status()
                mode = "ab" if have and r.status_code == 206 else "wb"
                if mode == "wb":
                    sha, have = hashlib.sha256(), 0      # whole body from byte 0
                total = int(r.headers.get("Content-Length", 0)) + have
                done = have
                with open(lp(tmp), mode) as f:
                    for chunk in r.iter_content(1 << 20):
                        f.write(chunk)
                        sha.update(chunk)
                        done += len(chunk)
                        if progress and total and span:
                            progress(base + int(span * min(done, total) / total), None)
                complete = sha.hexdigest() == hexd
        if complete:
            os.replace(lp(tmp), lp(dest))
            return dest
        resumed = bool(have)
        os.remove(lp(tmp))                     # never resume onto bytes that don't verify
        if not resumed or attempt == 2:
            raise RuntimeError(f"layer {digest[:19]}…: downloaded bytes do not match the "
                               f"digest (truncated or corrupted transfer) — not cached")
    raise AssertionError("unreachable")


# --------------------------------------------------------------------------- extraction
class UnsafeArchiveMember(RuntimeError):
    """An archive member path would resolve outside the extraction directory."""


_DRIVE_RE = re.compile(r"^[A-Za-z]:")


def _member_rel(name):
    """A tar member name as a safe, normalized relative POSIX path (bugs.md #1).

    Members used to be joined straight onto the destination after `.lstrip("./")`, so a name
    with a `..` component (or an absolute / drive-qualified one) escaped the extraction dir
    and could write or overwrite any file the user can — tarfile's own extraction filters
    don't apply because we never call extractall(). A crafted or compromised registry layer
    or Fix Central drop is not something to silently skip around, so this RAISES.

    Also fixes `.lstrip("./")` eating ANY leading dots: `.metadata/x` became `metadata/x`
    (so the component extractor's ".metadata/" skip never matched) and dotfiles lost their
    dot. Only literal "." and empty components are dropped now."""
    n = name.replace("\\", "/")
    if n.startswith("/") or _DRIVE_RE.match(n):
        raise UnsafeArchiveMember(f"absolute archive member path: {name!r}")
    parts = []
    for part in n.split("/"):
        if part in ("", "."):
            continue
        # Windows strips trailing dots/spaces when resolving, so ".. " or "..." act like ".."
        if part.rstrip(". ") == "" or (os.name == "nt" and ":" in part):   # ':' -> NTFS ADS
            raise UnsafeArchiveMember(f"unsafe archive member path: {name!r}")
        parts.append(part)
    return "/".join(parts)


def _safe_out(dest, rel):
    """dest/rel, verified to stay inside dest even after OS path normalization."""
    out = os.path.join(dest, *rel.split("/")) if rel else dest
    root = os.path.normcase(os.path.abspath(dest))
    full = os.path.normcase(os.path.abspath(out))
    if os.path.commonpath([root, full]) != root or full == root:
        raise UnsafeArchiveMember(f"archive member escapes extraction dir: {rel!r}")
    return out


def _symlink_target_rel(member_name, linkname):
    """bug.md DB2-T1-6: the archive-root-relative POSIX path a SYMLINK member points to,
    resolved relative to the symlink's own directory (POSIX symlink semantics), or None when
    the target is empty, absolute, or escapes the archive root. None means "not an in-tree
    file" — the caller then records the symlink as skipped rather than guessing.

    The returned path is only ever used to look a member up in `written` / under the (already
    escape-checked) extraction dir, so a crafted target can read nothing outside the tree."""
    link = (linkname or "").replace("\\", "/")
    if not link or link.startswith("/"):
        return None                                   # empty or absolute: not an in-tree file
    base_dir = posixpath.dirname((member_name or "").replace("\\", "/"))
    joined = posixpath.normpath(posixpath.join(base_dir, link))
    if joined == ".." or joined.startswith("../") or joined.startswith("/") or joined == ".":
        return None                                   # escapes the archive root
    return joined


def _is_whiteout(base):
    return base.startswith(".wh.")


# bugs.md #51: a hard-link member (tar LNKTYPE — how tar stores every further name of a
# multiply-linked inode, e.g. a versioned shared-library name) used to be skipped because
# only isfile() members were written, so that path silently vanished from the extracted
# tree. Its bytes are the earlier member `linkname` of the SAME archive; each extractor
# remembers what it wrote from the current archive and copies the link from that file.
def _copy_file_hash(src_path, out_path, hashes, key):
    with open(lp(src_path), "rb") as fh:
        _copy_hash(fh, out_path, hashes, key)


def _resolve_layer_links(layer_path, pending, hashes):
    """Second pass over one layer for hard links whose target this layer didn't write (it
    was hidden, outside the subtree, or overridden by a newer layer — the link still gets
    THIS layer's bytes). `pending` = {target name: [(out path, link name)]}."""
    with gzip.open(lp(layer_path), "rb") as gz, tarfile.open(fileobj=gz, mode="r|") as tar:
        for m in tar:
            if not pending:
                break
            if not m.isfile():
                continue
            links = pending.pop(_member_rel(m.name), None)
            src = tar.extractfile(m) if links else None
            if src is None:
                continue
            first_out, first_name = links[0]
            _copy_hash(src, first_out, hashes, first_name)
            for out, name in links[1:]:
                _copy_file_hash(first_out, out, hashes, name)
    if pending:
        raise RuntimeError(f"{os.path.basename(layer_path)}: hard link(s) to member(s) not "
                           f"in the layer: " + ", ".join(sorted(pending))[:300])


def _resolve_symlinks(dest, symlinks, hashes):
    """bug.md DB2-T1-7: materialise each recorded in-tree symlink as a real copy of its
    target's bytes, so the container/OCI path yields the same tree the manual-fixpack path
    does. Runs once over the FULLY-built tree because the OCI layers are read as one-pass `r|`
    streams (tarfile can't follow a link mid-stream) and a symlink may point into another
    layer. `symlinks` = {name: raw linkname}, with newest-layer-wins already applied by the
    caller. Resolved in passes so a chain (a -> b -> real file) settles; a target that is
    absolute, escapes the tree, or never resolves to a regular file is left out and logged
    (it is not an analysable file). Never raises."""
    remaining = dict(symlinks)
    while remaining:
        progressed = False
        for name, linkname in list(remaining.items()):
            try:
                out = _safe_out(dest, name)
                if os.path.exists(lp(out)):          # a real file already claims this path
                    remaining.pop(name)
                    continue
                target_rel = _symlink_target_rel(name, linkname)
                src = _safe_out(dest, target_rel) if target_rel else None
            except UnsafeArchiveMember:
                src = None
            if src is None:
                remaining.pop(name)
                _log.warning("db2 extract: skipped symlink %s -> %s (outside the tree)",
                             name, linkname)
                continue
            if os.path.isfile(lp(src)):
                try:
                    os.makedirs(lp(os.path.dirname(out)), exist_ok=True)
                    _copy_file_hash(src, out, hashes, name)
                except OSError as exc:
                    _log.warning("db2 extract: could not materialise symlink %s (%s)",
                                 name, exc)
                remaining.pop(name)
                progressed = True
        if not progressed:
            break                                    # the rest point at non-files / cycles
    for name, linkname in remaining.items():
        _log.warning("db2 extract: skipped symlink %s -> %s (target is not a regular file)",
                     name, linkname)


def _extract_layers(layer_paths, dest, subtree, hashes=None):
    """Overlay layers (later wins), honouring OCI whiteouts, extracting REGULAR files, hard
    links (written as copies — #51) and in-tree symlinks (materialised as copies of their
    target — bug.md DB2-T1-7) under `subtree`. Other special files are skipped. Hashes each
    written file into `hashes` if given."""
    os.makedirs(lp(dest), exist_ok=True)
    # bugs.md #2 — OCI whiteout semantics, applied to LOWER layers only:
    #   .wh.<name>      hides <name> AND everything beneath it (it may be a directory);
    #   .wh..wh..opq    in dir D hides all of D's lower-layer contents (the opaque layer's
    #                   own files in D stay).
    # Previously a whiteout matched one exact file path only (a deleted directory's files
    # survived) and opaque markers were ignored, so files deleted by a later layer leaked
    # into the reconstructed tree. A layer's whiteouts are also collected and applied only
    # once that layer is finished, so they never hide that same layer's own entries.
    hidden = set()                        # whited-out paths: the path itself and below
    opaque = set()                        # opaque dirs: everything below (not the dir)
    symlinks = {}                         # name -> raw linkname; newest layer wins, resolved
                                          # against the finished tree (bug.md DB2-T1-7)

    def _is_hidden(name):
        parts = name.split("/")
        for i in range(1, len(parts) + 1):
            pre = "/".join(parts[:i])
            if pre in hidden or (i < len(parts) and pre in opaque):
                return True
        return False

    # Walk layers newest->oldest so a later whiteout/override wins and we write each path once.
    for lf in reversed(layer_paths):
        layer_hidden, layer_opaque = set(), set()
        written, pending = {}, {}             # hard links (#51): this layer's files / waiting
        with gzip.open(lp(lf), "rb") as gz, tarfile.open(fileobj=gz, mode="r|") as tar:
            for m in tar:
                name = _member_rel(m.name)
                base = os.path.basename(name)
                parent = os.path.dirname(name)
                if base == ".wh..wh..opq":
                    layer_opaque.add(parent)
                    continue
                if _is_whiteout(base):
                    layer_hidden.add(f"{parent}/{base[4:]}" if parent else base[4:])
                    continue
                if not name.startswith(subtree) or not (m.isfile() or m.islnk()
                                                        or m.issym()):
                    continue
                if _is_hidden(name) or name in symlinks:
                    # name in symlinks: a NEWER layer put a symlink here, so it wins over this
                    # lower entry (regular, hard link, or symlink) at the same path.
                    continue
                out = _safe_out(dest, name)
                if os.path.exists(lp(out)):   # a real file from a newer layer already won
                    continue
                if m.issym():
                    # Record now (first/newest wins), materialise after the whole tree exists:
                    # a symlink may target a file in a lower layer not yet extracted.
                    symlinks[name] = m.linkname
                    continue
                os.makedirs(lp(os.path.dirname(out)), exist_ok=True)
                if m.islnk():
                    target = _member_rel(m.linkname)
                    if target in written:
                        _copy_file_hash(written[target], out, hashes, name)
                    else:
                        pending.setdefault(target, []).append((out, name))
                    continue
                src = tar.extractfile(m)
                if src is None:
                    continue
                _copy_hash(src, out, hashes, name)
                written[name] = out
        if pending:
            _resolve_layer_links(lf, pending, hashes)
        hidden |= layer_hidden                # now in effect for every LOWER layer
        opaque |= layer_opaque
    # every layer is extracted and its hard links resolved, so every symlink target that
    # exists anywhere in the tree is now on disk (bug.md DB2-T1-7)
    _resolve_symlinks(dest, symlinks, hashes)


def _extract_tar(tar_path, dest, hashes=None, skipped=None):
    """Extract every REGULAR file, hard link (#51) and in-tree symlink (bug.md DB2-T1-6) from
    a (possibly nested) tar/tar.gz to `dest`. A member this filesystem can't create, or a
    link whose target is not in the archive, is recorded in `skipped` and logged (never
    aborts the extraction)."""
    os.makedirs(lp(dest), exist_ok=True)
    mode = "r:gz" if tar_path.endswith((".gz", ".tgz")) else "r:*"
    written = {}
    skipped = skipped if skipped is not None else []
    with tarfile.open(lp(tar_path), mode) as tar:
        for m in tar:
            # bug.md DB2-T1-6: symlinks used to be dropped silently, so the tarfile path and
            # the 7-Zip path produced different trees. This tar is random-access, so tarfile
            # resolves BOTH hard links and symlinks to their target member's bytes via
            # extractfile() — a symlinked library now lands as a real file, same as 7-Zip.
            if not (m.isfile() or m.islnk() or m.issym()):
                continue
            name = _member_rel(m.name)
            if not name:
                continue
            out = _safe_out(dest, name)
            try:
                _makedirs(os.path.dirname(out))
                if m.islnk():
                    target = _member_rel(m.linkname)
                    if target in written and written[target] != out:
                        _copy_file_hash(written[target], out, hashes, name)
                        written[name] = out
                        continue
                    # not written from this archive: let tarfile find the target member (a
                    # random-access open, so this works — just slower on a .gz)
                try:
                    src = tar.extractfile(m)
                except KeyError:
                    # a hard/symlink whose target is not in the archive (dangling or external):
                    # record and move on rather than aborting the whole side (mirrors #7).
                    tgt = m.linkname
                    skipped.append(f"{name}: link target {tgt!r} not in archive")
                    _log.warning("db2 extract: skipped %s (link target %r not in archive)",
                                 name, tgt)
                    continue
                if src is None:
                    continue
                _copy_hash(src, out, hashes, name)
                written[name] = out
            except UnwritableMember as e:
                skipped.append(f"{name}: {e}")
                _log.warning("db2 extract: skipped %s (%s)", name, e)


def _find_version_dir(root_dir):
    """Locate the `.../opt/ibm/db2/V<x>` version dir under an extracted tree; fall back to
    the parent-of-parent of libdb2e.so.1 (handles fixpack payloads with a different top)."""
    _db2_parent = os.path.join(root_dir, "opt", "ibm", "db2")
    try:
        # sorted() so the pick is deterministic if several V<x> dirs ever coexist
        # (os.listdir order is arbitrary); normally there is exactly one.
        _vdirs = sorted(e for e in os.listdir(lp(_db2_parent)) if e.startswith("V"))
    except OSError:
        _vdirs = []
    if _vdirs:
        return os.path.join(_db2_parent, _vdirs[0])
    # db2_bugs.md DB2-8: this used to take the first libdb2e.so.1 os.walk() reached, so with
    # several copies the chosen root depended on directory order. The copy closest to the
    # root wins (then the smallest path), and a tie is logged.
    found = []
    for dirpath, dirs, files in os.walk(lp(root_dir)):
        dirs.sort()
        depth = dirpath.count(os.sep)
        if found and depth > min(d for d, _p in found):
            dirs[:] = []                                  # nothing deeper can win
            continue
        if "libdb2e.so.1" in files:                       # <vdir>/lib64/libdb2e.so.1
            found.append((depth, dirpath))
    if not found:
        return None
    best = min(found)
    ties = [p for d, p in found if d == best[0] and p != best[1]]
    if ties:
        _log.warning("db2: libdb2e.so.1 found at the same depth in %d places under %s; "
                     "using the DB2 root %s", len(ties) + 1, root_dir,
                     os.path.dirname(best[1]))
    return os.path.dirname(best[1])


# --------------------------------------------------------------------------- per-side
def _acquire_container(ref, side_dir, online, progress, base, span, hashes=None, root_dir=None):
    reg, repo, tag = _parse_ref(ref)
    s = _session()
    tok = _token(s, reg, repo)
    layers = _amd64_layers(s, reg, repo, tag, tok)
    if not layers:
        raise RuntimeError(f"no layers for {ref}")
    cache = _cache_dir()
    paths, n = [], len(layers)
    for i, l in enumerate(layers):
        dg = l["digest"]
        dest = os.path.join(cache, dg.replace(":", "_") + ".tar.gz")
        if not _layer_ok(dest, dg):        # #21: a cached layer is used only once verified
            if not online:
                raise RuntimeError(f"offline: layer {dg[:19]} not cached (need internet)")
            _download_blob(s, reg, repo, dg, tok, dest, progress,
                           base + int(span * i / n), max(1, span // n))
        paths.append(dest)
    if progress:
        progress(base + int(span * 0.9), f"Extracting {tag} DB2 tree")
    root_dir = root_dir or os.path.join(side_dir, "root")
    _extract_layers(paths, root_dir, _SUBTREE, hashes=hashes)
    return root_dir


# A Fix Central universal fixpack is an *installer image*: the product tree is not laid out
# flat — it lives inside nested per-component archives under `.../FILES/<COMPONENT>_<ver>_
# <arch>.tar.gz`, each holding install-root-relative paths (lib64/libdb2e.so.1, bin/, adm/,
# java/, …). We reconstruct the product tree by overlaying the non-noise component archives.
_FILES_RE = re.compile(r"(^|/)FILES/[^/]+\.tar\.gz$")
# Component name tokens whose payload is docs/locale/samples — no ELF/jars worth diffing.
_NOISE_COMPONENTS = ("PRODUCT_MESSAGES", "_HELP_", "HELP_EN", "SAMPLE", "JAVA_HELP",
                     "CONTROL_CENTER_HELP", "_DOC_", "FIRST_STEPS")


def _is_component(name):
    return bool(_FILES_RE.search(name.replace("\\", "/")))


def _keep_component(name):
    base = os.path.basename(name).upper()
    return not any(tok in base for tok in _NOISE_COMPONENTS)


# A member name that looks like product code rather than documentation (db2_bugs.md DB2-9).
_CODE_MEMBER = re.compile(r"(\.so(\.\d+)*|\.jar|\.class)$|(^|/)(bin|adm|lib(32|64)?)/[^/]+$",
                          re.IGNORECASE)
SKIPPED_COMPONENTS = "skipped_components.json"


def _noise_component_record(name, size, fileobj):
    """What a component skipped by _keep_component() holds: its name, size and any member
    that looks like code. Only the member NAMES are read (the component is decompressed,
    not extracted), so skipping stays cheap but can no longer hide a library or jar."""
    code, n = [], 0
    try:
        with gzip.GzipFile(fileobj=fileobj) as gz, tarfile.open(fileobj=gz, mode="r|") as t:
            for m in t:
                if m.isfile() and _CODE_MEMBER.search(m.name):
                    n += 1
                    if len(code) < 5:
                        code.append(m.name)
    except Exception as exc:
        # Only a report: a component that is skipped anyway must never fail the extraction,
        # whatever the decompressor or tar reader raises for it.
        return {"name": name, "size": size, "code_members": None,
                "error": f"{type(exc).__name__}: {exc}"}
    return {"name": name, "size": size, "code_members": n, "examples": code}


def _extract_component_stream(fileobj, dest, hashes=None, skipped=None):
    """Extract regular files from a gzipped-tar component stream into `dest`, overlaying
    (a path already written by an earlier component wins). Skips install control metadata.
    A hard link (#51) or in-tree symlink (bug.md DB2-T1-6) is copied from its target as
    written from THIS component, else from the same path already on disk (an earlier
    component — the overlay winner); a target that is in neither place can't be re-read from
    the one-pass stream (tarfile cannot seek back in a `r|` stream to follow a link, so
    unlike _extract_tar this resolves links by hand). A member this filesystem can't create,
    or an unresolvable link, is recorded in `skipped` and logged instead of aborting the
    whole fixpack; an unsafe member name still raises."""
    written = {}
    skipped = skipped if skipped is not None else []

    def _skip(name, why):
        skipped.append(f"{name}: {why}")
        _log.warning("db2 extract: skipped %s (%s)", name, why)

    with gzip.GzipFile(fileobj=fileobj) as gz, tarfile.open(fileobj=gz, mode="r|") as tar:
        for m in tar:
            if not (m.isfile() or m.islnk() or m.issym()):
                continue
            name = _member_rel(m.name)
            if not name or name.startswith(".metadata/"):
                continue
            out = _safe_out(dest, name)
            if os.path.exists(lp(out)):
                written[name] = out          # a later link may name it; overlay winner stays
                continue
            try:
                _makedirs(os.path.dirname(out))
            except UnwritableMember as e:
                _skip(name, str(e))
                continue
            try:
                if m.islnk() or m.issym():
                    # hard link target = an archive-relative member name; symlink target =
                    # resolved relative to the symlink's own dir (None if it escapes the tree).
                    target = (_member_rel(m.linkname) if m.islnk()
                              else _symlink_target_rel(m.name, m.linkname))
                    kind = "hard link" if m.islnk() else "symlink"
                    if target and target in written:
                        _copy_file_hash(written[target], out, hashes, name)
                        written[name] = out
                    elif target and os.path.isfile(lp(_safe_out(dest, target))):
                        _copy_file_hash(_safe_out(dest, target), out, hashes, name)
                        written[name] = out
                    else:
                        _skip(name, f"{kind} target {m.linkname!r} not available")
                    continue
                src = tar.extractfile(m)
                if src is None:
                    continue
                _copy_hash(src, out, hashes, name)
                written[name] = out
            except UnwritableMember as e:
                _skip(name, str(e))


def _manual_drop(side_dir):
    """The fixpack archive _acquire_manual() would use for this side, or None.

    db2_bugs.md DB2-6: with several archives in the drop folder the largest used to be
    taken, which could be a stale or wrong fixpack. Which build is diffed must never be a
    guess, so several archives now stop the acquisition with their names."""
    drop = os.path.join(side_dir, "drop")
    try:
        _entries = [os.path.join(drop, f) for f in sorted(os.listdir(lp(drop)))]
    except OSError:
        return None
    tars = [f for f in _entries if f.lower().endswith((".tar.gz", ".tgz", ".tar"))
            and os.path.isfile(lp(f))]
    if len(tars) > 1:
        raise RuntimeError(
            f"{drop} holds {len(tars)} fixpack archives "
            f"({', '.join(os.path.basename(t) for t in tars)}); keep exactly the one to "
            f"diff and run again.")
    return tars[0] if tars else None


def _7z_extract_archive(archive, dest, overwrite, exclude_metadata):
    """Extract a tar / tar.gz / tgz with the bundled 7-Zip. A gzip is streamed into 7-Zip's
    tar reader through a pipe so no intermediate .tar lands on disk. `overwrite` is the -ao
    mode: 'a' overwrite, 's' skip existing (the first component wins, as in the tarfile path).
    7-Zip rc 1 (warning) and 2 (some entries not created — e.g. symlinks without privilege)
    are tolerated and logged; the caller validates the resulting tree."""
    exe = tp.sevenzip()
    os.makedirs(lp(dest), exist_ok=True)
    tail = ["-y", "-ao" + overwrite, "-o" + os.path.abspath(dest)]
    if exclude_metadata:
        tail.append("-xr!.metadata")
    if archive.lower().endswith(".tar"):
        p2 = subprocess.run([exe, "x", archive] + tail, stdout=subprocess.DEVNULL,
                            stderr=subprocess.PIPE, timeout=7200)
        rc1, rc2, err = 0, p2.returncode, p2.stderr
    else:
        p1 = subprocess.Popen([exe, "x", archive, "-so"], stdout=subprocess.PIPE,
                              stderr=subprocess.DEVNULL)
        p2 = subprocess.Popen([exe, "x", "-si", "-ttar"] + tail, stdin=p1.stdout,
                              stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        p1.stdout.close()
        try:
            _out, err = p2.communicate(timeout=7200)
            rc1 = p1.wait(timeout=60)
        except subprocess.TimeoutExpired:
            p1.kill()
            p2.kill()
            raise
        rc2 = p2.returncode
    if rc1 > 1 or rc2 > 2:
        raise RuntimeError(f"7-Zip failed (rc={rc1}/{rc2}) extracting "
                           f"{os.path.basename(archive)}:\n"
                           f"{(err or b'').decode('utf-8', 'replace')[-1000:]}")
    if rc2:
        _log.warning("7-Zip rc=%s extracting %s (some entries skipped): %s", rc2,
                     os.path.basename(archive), (err or b"").decode("utf-8", "replace")[-300:])


def _hash_tree(root_dir, hashes):
    """Fill hashes[root-relative posix name] = sha256 for a tree 7-Zip extracted (the tarfile
    path hashes while writing; the manifest needs the same data)."""
    if hashes is None:
        return
    for dirpath, _dirs, files in os.walk(lp(root_dir)):
        for f in files:
            full = os.path.join(dirpath, f)
            h = hashlib.sha256()
            with open(full, "rb") as fh:
                for b in iter(lambda: fh.read(1 << 20), b""):
                    h.update(b)
            hashes[os.path.relpath(full, lp(root_dir)).replace("\\", "/")] = h.hexdigest()


def _acquire_manual_7z(src_tar, side_dir, root_dir, hashes, noise=None):
    """Fallback extractor: outer archive -> temp dir, then each kept FILES/* component
    (or the whole tree, if there are none) -> root_dir. Components skipped as noise are
    described in `noise` (DB2-9)."""
    tmp = os.path.join(side_dir, "_7z_outer")
    shutil.rmtree(lp(tmp), ignore_errors=True)
    try:
        _7z_extract_archive(src_tar, tmp, "a", False)
        comps = []
        for dirpath, _dirs, files in os.walk(lp(tmp)):
            for f in sorted(files):
                full = os.path.join(dirpath, f)
                rel = os.path.relpath(full, lp(tmp)).replace("\\", "/")
                if not _is_component(rel):
                    continue
                if _keep_component(rel):
                    comps.append(full)
                elif noise is not None:
                    with open(full, "rb") as fh:
                        noise.append(_noise_component_record(rel, os.path.getsize(full), fh))
        os.makedirs(lp(root_dir), exist_ok=True)
        if comps:
            for c in sorted(comps):
                _7z_extract_archive(c, root_dir, "s", True)
        else:
            for e in os.listdir(lp(tmp)):
                shutil.move(os.path.join(lp(tmp), e), os.path.join(lp(root_dir), e))
    finally:
        shutil.rmtree(lp(tmp), ignore_errors=True)
    _hash_tree(root_dir, hashes)


def _acquire_manual(side, side_dir, label, hashes=None, root_dir=None):
    drop = os.path.join(side_dir, "drop")
    os.makedirs(lp(drop), exist_ok=True)
    src_tar = _manual_drop(side_dir)
    if not src_tar:
        raise RuntimeError(
            f"{side} build '{label}': drop the Fix Central universal fixpack (.tar.gz) into "
            f"{drop} and run again. (This is the fixed special build; download it with your "
            f"IBM ID — it is not available as a free container image.)")
    root_dir = root_dir or os.path.join(side_dir, "root")
    skipped, noise = [], []
    try:
        _acquire_manual_tarfile(src_tar, root_dir, hashes, skipped, noise)
    except UnsafeArchiveMember:
        raise                                       # a hostile archive is never retried
    except Exception as e:
        if not os.path.isfile(lp(tp.sevenzip())):
            raise
        _log.warning("%s: Python tarfile extraction failed (%s: %s); retrying with 7-Zip",
                     side, type(e).__name__, e)
        shutil.rmtree(lp(root_dir), ignore_errors=True)
        os.makedirs(lp(root_dir), exist_ok=True)
        if hashes is not None:
            hashes.clear()
        skipped, noise = [], []
        try:
            _acquire_manual_7z(src_tar, side_dir, root_dir, hashes, noise)
        except Exception as e2:
            raise RuntimeError(f"{side}: extraction failed with tarfile ({e}) and with "
                               f"7-Zip ({e2})") from e2
    if noise:
        try:
            with open(lp(os.path.join(side_dir, SKIPPED_COMPONENTS)), "w",
                      encoding="utf-8") as fh:
                json.dump(sorted(noise, key=lambda c: c["name"]), fh, indent=1)
        except OSError:
            pass
    if skipped:
        try:
            with open(lp(os.path.join(side_dir, "skipped_members.txt")), "w",
                      encoding="utf-8") as fh:
                fh.write("\n".join(skipped) + "\n")
        except OSError:
            pass
    return root_dir


def _acquire_manual_tarfile(src_tar, root_dir, hashes, skipped, noise=None):
    # One forward pass over the outer tar: extract each kept FILES/* component inline (stream
    # mode keeps memory flat on the ~2 GB image). If we find no components, the drop is a
    # pre-extracted product tree — fall back to a flat extract. A component skipped as noise
    # is described in `noise` (DB2-9).
    mode = "r|gz" if src_tar.endswith((".gz", ".tgz")) else "r|*"
    n_components = 0
    with tarfile.open(lp(src_tar), mode) as outer:
        for m in outer:
            if not (m.isfile() and _is_component(m.name)):
                continue
            if not _keep_component(m.name):
                if noise is not None:
                    f = outer.extractfile(m)
                    if f is not None:
                        noise.append(_noise_component_record(m.name, m.size, f))
                continue
            f = outer.extractfile(m)
            if f is None:
                continue
            _extract_component_stream(f, root_dir, hashes=hashes, skipped=skipped)
            n_components += 1
    if n_components == 0:
        _extract_tar(src_tar, root_dir, hashes=hashes, skipped=skipped)


def acquire(patch, workdir, progress=None, online=True, sides=("vuln", "fixed")):
    """Pull/extract the requested build(s) (default: both). Returns a dict with only the
    key(s) for the requested `sides`, e.g. {'vuln': dir} or {'fixed': dir, 'vuln': dir}."""
    def rep(p, ph):
        if progress:
            progress(max(0, min(100, p)), ph)

    sides_out = {}
    ext_ids = {}                         # side -> extraction id of a tree extracted in THIS call
    hashes = {}                          # side -> {root-relative name: sha} for freshly-extracted sides
    plan_all = [("vuln",  patch.get("vuln_dl_url"), 0, 45),
                ("fixed", patch.get("dl_url"),      45, 45)]
    # Pass 1 — which sides can be reused? #8/#11: only a tree that finished extracting AND
    # came from this exact source. A tree that was PRUNED against a partner (identical files
    # deleted, see _write_manifest_and_prune) is only complete together with that same
    # partner, so it's reusable only if the partner is reused too with the matching id.
    reusable = {}
    for side, spec, _b, _s in plan_all:
        if side not in sides or not spec:
            continue
        side_dir = os.path.join(workdir, "acquire", side)
        root = os.path.join(side_dir, "root")
        source = _source_identity(spec, spec.partition(":")[0], side_dir)
        if _state.is_complete(root, source, match=_source_matches) and _find_version_dir(root):
            reusable[side] = _state.read(root)
    changed = True
    while changed:                           # dropping one side can invalidate the other
        changed = False
        for side in list(reusable):
            partner_id = reusable[side].get("pruned_with")
            if partner_id is None:
                continue
            orec = reusable.get("fixed" if side == "vuln" else "vuln")
            if not orec or orec.get("extraction_id") != partner_id:
                del reusable[side]
                changed = True
    # Pass 2 — reuse or (re)extract.
    for side, spec, base, span in plan_all:
        if side not in sides:
            continue
        side_dir = os.path.join(workdir, "acquire", side)
        os.makedirs(lp(side_dir), exist_ok=True)
        root = os.path.join(side_dir, "root")
        if not spec:
            raise RuntimeError(f"{side} build has no source spec (dl_url/vuln_dl_url)")
        kind, _, arg = spec.partition(":")
        source = _source_identity(spec, kind, side_dir)
        if side in reusable:
            sides_out[side] = _find_version_dir(root)
            rep(base + span, f"{side} build already extracted")
            continue
        if kind not in ("container", "manual"):
            if kind == "fixcentral":
                raise RuntimeError("fixcentral acquisition is not implemented yet — use manual: drop")
            raise RuntimeError(f"unknown source spec '{spec}'")
        # A fresh extraction makes any existing member-diff manifest stale (it described the
        # previous trees); drop it so Stage 0 can never apply it to the new ones (#14).
        _invalidate_manifest(workdir)
        # The previous tree's lists of skipped members / components describe that tree, not
        # the one about to be extracted: a clean re-extraction must not keep reporting them
        # (DB2-7, DB2-9).
        for _stale in ("skipped_members.txt", SKIPPED_COMPONENTS):
            try:
                os.remove(lp(os.path.join(side_dir, _stale)))
            except OSError:
                pass
        rep(base, f"Acquiring {side} build ({arg})")
        sh = hashes[side] = {}
        partial = _state.begin(root)
        try:
            if kind == "container":
                _acquire_container(arg, side_dir, online, progress and rep, base, span, sh,
                                   root_dir=partial)
            else:
                _acquire_manual(side, side_dir, arg, sh, root_dir=partial)
            if not _find_version_dir(partial):
                raise RuntimeError(f"{side}: no DB2 version dir (opt/ibm/db2/V*) found after extract")
        except BaseException:
            _state.abandon(partial)
            hashes.pop(side, None)
            raise
        ext_ids[side] = _state.commit(root, partial, source)
        sides_out[side] = _find_version_dir(root)
        rep(base + span, f"{side} build extracted")

    # If BOTH sides were freshly extracted IN THIS CALL we have their in-extract hashes:
    # write a member-diff manifest (version-dir-relative) so Stage 0 skips re-hashing, and
    # prune byte-identical files from disk (they're never diffed). Only fires when both
    # sides were actually requested and freshly pulled here — a single-side call (the other
    # side already supplied/extracted) correctly skips this cross-side optimization. gzip
    # streaming means we can't skip the decompression, but this removes the second
    # read+hash pass and the identical-file footprint. Best-effort.
    if len(hashes) == 2:
        try:
            _write_manifest_and_prune(workdir, sides_out, hashes, ext_ids)
        except Exception:
            pass
    rep(100, "Acquire complete")
    return sides_out


def _vdir_rel(hashes_side, root, vdir):
    """Re-key {root-relative name: sha} to {version-dir-relative: sha}."""
    # vdir may arrive \\?\-prefixed (os.walk fallback) while root is bare; wrap both so
    # relpath sees a matching prefix (idempotent / POSIX no-op) instead of raising.
    prefix = os.path.relpath(lp(vdir), lp(root)).replace("\\", "/")
    prefix = "" if prefix in (".", "") else prefix + "/"
    out = {}
    for name, sha in hashes_side.items():
        n = name.replace("\\", "/")
        if not prefix or n.startswith(prefix):
            out[n[len(prefix):]] = sha
    return out


def _write_manifest_and_prune(workdir, sides, hashes, ext_ids):
    roots = {s: os.path.join(workdir, "acquire", s, "root") for s in ("vuln", "fixed")}
    vh = _vdir_rel(hashes["vuln"],  roots["vuln"],  sides["vuln"])
    fh = _vdir_rel(hashes["fixed"], roots["fixed"], sides["fixed"])
    common = vh.keys() & fh.keys()
    changed = sorted(k for k in common if vh[k] != fh[k])
    added = sorted(fh.keys() - vh.keys())
    removed = sorted(vh.keys() - fh.keys())
    identical = [k for k in common if vh[k] == fh[k]]
    # #14: bind the manifest to the exact trees it describes, so Stage 0 can refuse to apply
    # it to anything else (manually supplied dirs, a re-acquired side, ...).
    manifest = {"changed": changed, "added": added, "removed": removed, "identical": len(identical),
                "trees": {s: {"root": roots[s], "vdir": sides[s], "extraction_id": ext_ids[s]}
                          for s in ("vuln", "fixed")}}
    with open(lp(os.path.join(workdir, "acquire", "manifest.json")), "w", encoding="utf-8") as fh_:
        json.dump(manifest, fh_)
    # The trees are about to lose their identical files, so each is now only complete
    # together with THIS partner — record that before pruning (acquire() checks it on reuse).
    _state.annotate(roots["vuln"], pruned_with=ext_ids["fixed"])
    _state.annotate(roots["fixed"], pruned_with=ext_ids["vuln"])
    # prune byte-identical files from both version dirs — never diffed, pure footprint.
    for rel in identical:
        for s in ("vuln", "fixed"):
            p = os.path.join(sides[s], rel)
            try:
                os.remove(lp(p))
            except OSError:
                pass
    # bugs.md #48: record exactly what remains of each tree, so Stage 0 can tell that a tree
    # was modified after acquisition (the change list above would then be stale) and fall
    # back to a full walk instead of trusting it.
    manifest["snapshot"] = {s: _state.tree_snapshot(sides[s]) for s in ("vuln", "fixed")}
    mpath = os.path.join(workdir, "acquire", "manifest.json")
    with open(lp(mpath + ".tmp"), "w", encoding="utf-8") as fh_:
        json.dump(manifest, fh_)
    os.replace(lp(mpath + ".tmp"), lp(mpath))