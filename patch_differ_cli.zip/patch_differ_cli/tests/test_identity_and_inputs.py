"""Regression tests for bugs.md #22, #26, #29, #33, #34, #39, #40, #43, #48, #52 — caches
keyed too weakly to notice a changed tool or source, inputs reused after they changed, an
API stage selection that ran nothing, a data diff that ignored binary changes, and a helper
that always crashed.

No network, Ghidra, CFR or 7-Zip runs; tools and subprocesses are faked. Scratch files live
in TemporaryDirectory()s only."""
import contextlib
import io
import json
import os
import random
import tempfile
import unittest
import zipfile
import zlib
from unittest import mock

import patch_differ_cli._acquire_state as state
import patch_differ_cli._bindiff as bd
import patch_differ_cli._decompile as D
import patch_differ_cli.db2.stage1 as ds1
import patch_differ_cli.db2.stage2 as d2
import patch_differ_cli.db2.triage as dtri
import patch_differ_cli.mssql.acquire as macq
import patch_differ_cli.mssql.decompile as mdec
import patch_differ_cli.oracle.java_decompile as jd
import patch_differ_cli.oracle.stage1 as o1
import patch_differ_cli.pipeline as pl
import patch_differ_cli.tool_paths as tp
from patch_differ_cli.tests.test_triage_manifest_binding import _Db2Base


def _write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    return path


def _replace_keep_stat(path, data):
    """Overwrite `path` with same-size different bytes and restore its timestamps."""
    st = os.stat(path)
    assert len(data) == st.st_size
    with open(path, "wb") as fh:
        fh.write(data)
    os.utime(path, ns=(st.st_atime_ns, st.st_mtime_ns))


class _Tmp(unittest.TestCase):
    def setUp(self):
        td = tempfile.TemporaryDirectory()
        self.addCleanup(td.cleanup)
        self.d = td.name


# --------------------------------------------------------------------------- #22
class SourceFingerprintTests(_Tmp):
    def test_same_size_same_mtime_replacement_changes_the_fingerprint(self):
        p = _write(os.path.join(self.d, "patch.exe"), b"build-A-bytes")
        a = state.file_fingerprint(p)
        _replace_keep_stat(p, b"build-B-bytes")
        b = state.file_fingerprint(p)
        self.assertEqual((a["name"], a["size"]), (b["name"], b["size"]))
        self.assertNotEqual(a, b)

    def test_touched_but_unchanged_file_keeps_its_fingerprint(self):
        p = _write(os.path.join(self.d, "patch.exe"), b"same")
        a = state.file_fingerprint(p)
        os.utime(p, ns=(1, 1))
        self.assertEqual(a, state.file_fingerprint(p))

    def test_manual_installer_replaced_in_place_is_reextracted(self):
        exe = _write(os.path.join(self.d, "patch.exe"), b"build-A")
        out, cabs = os.path.join(self.d, "engine"), os.path.join(self.d, "cabs")
        seen = []

        def into(exe_path, out_dir, cab_dir, msp_stage):
            with open(exe_path, "rb") as fh:
                seen.append(fh.read())
            _write(os.path.join(out_dir, "ENG_x_dll_64"), seen[-1])

        with mock.patch.object(macq, "_extract_engine_into", into):
            macq.extract_engine(exe, out, cabs)
            _replace_keep_stat(exe, b"build-B")
            macq.extract_engine(exe, out, cabs)
        self.assertEqual(seen, [b"build-A", b"build-B"])


# --------------------------------------------------------------------------- #26
class _Proc:
    def __init__(self, rc=0, out=b""):
        self.returncode, self.stdout = rc, out


class BinExportToolIdentityTests(_Tmp):
    def setUp(self):
        super().setUp()
        self.binary = _write(os.path.join(self.d, "x.so"), b"\x7fELF same binary")
        self.out = os.path.join(self.d, "exp", "x.BinExport")
        self.calls = 0
        self.tool = "tool-v1"
        for target, value in (("analyze_headless", "analyzeHeadless"),
                              ("locate_binexport_script", os.path.join(self.d, "BinExport.java")),
                              ("clear_stale_ghidra_script_cache", None), ("child_env", {})):
            p = mock.patch.object(bd.tp, target, return_value=value)
            p.start()
            self.addCleanup(p.stop)
        for target, fn in (("binexport_identity", lambda gh=None: self.tool),
                           ("_run_tool", self._run)):
            p = mock.patch.object(bd.tp if target == "binexport_identity" else bd,
                                  target, fn)
            p.start()
            self.addCleanup(p.stop)

    def _run(self, cmd, **kw):
        self.calls += 1
        if "-postScript" in cmd:
            _write(self.out, f"EXPORT by {self.tool}".encode())
        return _Proc(0)

    def _export(self):
        return bd.ghidra_binexport(self.binary, os.path.join(self.d, "proj"), self.out)

    def test_tool_update_invalidates_the_cached_export(self):
        self._export()
        self.calls = 0
        self._export()
        self.assertEqual(self.calls, 0, "same binary + same tool -> reused")
        self.tool = "tool-v2"
        self._export()
        self.assertEqual(self.calls, 2, "updated tool -> re-imported and re-exported")
        with open(self.out, "rb") as fh:
            self.assertEqual(fh.read(), b"EXPORT by tool-v2")

    def test_sidecar_from_an_older_version_is_not_trusted(self):
        self._export()
        with open(self.out + ".sha256", "w", encoding="ascii") as fh:
            fh.write(bd._sha256(self.binary))           # the old binary-hash-only sidecar
        self.calls = 0
        self._export()
        self.assertEqual(self.calls, 2)


class ToolIdentityTests(_Tmp):
    def _ghidra(self, parent, version):
        home = os.path.join(self.d, parent, "ghidra")
        _write(os.path.join(home, "Ghidra", "application.properties"),
               f"application.version={version}\n".encode())
        _write(os.path.join(home, "Ghidra", "Features", "Decompiler", "os", "win_x86_64",
                            "decompile.exe"), f"native-{version}".encode())
        _write(os.path.join(home, "Ghidra", "Extensions", "BinExport", "lib", "BinExport.jar"),
               f"jar-{version}".encode())
        return home

    def test_same_basename_different_install_has_a_different_identity(self):     # #29
        a, b = self._ghidra("one", "11.0.3"), self._ghidra("two", "11.1")
        with mock.patch.object(tp, "ghidra_home", lambda: a):
            ia = tp.decompiler_identity()
        with mock.patch.object(tp, "ghidra_home", lambda: b):
            ib = tp.decompiler_identity()
        self.assertNotEqual(ia, ib)
        self.assertNotEqual(tp.binexport_identity(a), tp.binexport_identity(b))

    def test_in_place_upgrade_changes_the_identity(self):
        home = self._ghidra("one", "11.0.3")
        before = tp.binexport_identity(home)
        _write(os.path.join(home, "Ghidra", "Extensions", "BinExport", "lib", "BinExport.jar"),
               b"jar-11.0.4-longer")
        self.assertNotEqual(before, tp.binexport_identity(home))

    def test_decompile_cache_misses_after_a_ghidra_replacement(self):
        a, b = self._ghidra("one", "11.0.3"), self._ghidra("two", "11.1")
        calls = []

        def fake(p, f):
            calls.append(1)
            return ("int f(void);", "int f(int);", True)
        cache = os.path.join(self.d, "dc")
        self.addCleanup(lambda: setattr(D, "_IDENTITY", None))
        with mock.patch.object(D, "_try_decompile", fake):
            for home in (a, a, b):
                D._IDENTITY = None
                with mock.patch.object(D.tp, "ghidra_home", lambda h=home: h):
                    D.decompile_cached(b"p", b"f", cache)
        self.assertEqual(len(calls), 2)


# --------------------------------------------------------------------------- #39
class CfrIdentityTests(_Tmp):
    def test_same_size_cfr_replacement_changes_the_identity(self):
        cfr = _write(os.path.join(self.d, "cfr-0.152.jar"), b"CFR-build-A")
        with mock.patch.object(jd, "_cfr_jar", lambda: cfr):
            a = jd.identity()
            _replace_keep_stat(cfr, b"CFR-build-B")
            b = jd.identity()
        self.assertEqual(a["tool"], "cfr")
        self.assertNotEqual(a, b)

    def test_java_runtime_is_part_of_the_identity(self):
        j1 = _write(os.path.join(self.d, "j1", "bin", "java.exe"), b"jdk17")
        j2 = _write(os.path.join(self.d, "j2", "bin", "java.exe"), b"jdk21")
        with mock.patch.object(jd, "_cfr_jar", lambda: None):
            with mock.patch.object(tp, "java_home", lambda: os.path.join(self.d, "j1")):
                a = jd.identity()
            with mock.patch.object(tp, "java_home", lambda: os.path.join(self.d, "j2")):
                b = jd.identity()
        self.assertNotEqual(a, b)


# --------------------------------------------------------------------------- #33
def _crc_collision():
    """Two different 8-byte payloads with the same CRC-32 (birthday search, seeded)."""
    rnd, seen = random.Random(33), {}
    while True:
        b = rnd.getrandbits(64).to_bytes(8, "little")
        c = zlib.crc32(b)
        if c in seen and seen[c] != b:
            return seen[c], b
        seen[c] = b


class JarCrcCollisionTests(_Tmp):
    def _jar(self, path, payload):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with zipfile.ZipFile(path, "w") as z:
            z.writestr(zipfile.ZipInfo("META-INF/MANIFEST.MF", (2020, 1, 1, 0, 0, 0)), "x")
            z.writestr(zipfile.ZipInfo("pkg/Entry.class", (2020, 1, 1, 0, 0, 0)), payload)

    def test_same_crc_and_size_different_bytes_is_reported(self):
        a, b = _crc_collision()
        self.assertEqual((zlib.crc32(a), len(a)), (zlib.crc32(b), len(b)))
        p, f = os.path.join(self.d, "p"), os.path.join(self.d, "f")
        self._jar(os.path.join(p, "java", "dependency.jar"), a)
        self._jar(os.path.join(f, "java", "dependency.jar"), b)
        r = ds1.run(p, f, self.d)
        deps = [c for c in r["readable_files"] if c["kind"] == "dependency"]
        self.assertEqual([c["change"] for c in deps], ["content-changed"])
        self.assertEqual(r["errors"], [])

    def test_byte_identical_jars_are_skipped(self):
        p, f = os.path.join(self.d, "p"), os.path.join(self.d, "f")
        self._jar(os.path.join(p, "java", "dependency.jar"), b"same")
        with open(os.path.join(p, "java", "dependency.jar"), "rb") as fh:
            _write(os.path.join(f, "java", "dependency.jar"), fh.read())
        with mock.patch.object(ds1, "_jar_content", side_effect=AssertionError("decompressed")):
            r = ds1.run(p, f, self.d)
        self.assertEqual([c for c in r["readable_files"] if c["kind"] == "dependency"], [])


# --------------------------------------------------------------------------- #40
class DataDiffNulTests(unittest.TestCase):
    def test_binary_change_after_a_leading_nul_is_a_change(self):
        pb, fb = b"\x00AAAA" + b"\x11" * 43, b"\x00BBBB" + b"\x11" * 43
        self.assertTrue(d2._real_data_change(pb, fb, 0, 0, 0, 0))

    def test_c_string_pool_churn_is_still_ignored(self):
        pb, fb = b"permission denied\x00old-neighbour", b"permission denied\x00new-neighbour"
        self.assertFalse(d2._real_data_change(pb, fb, 0, 0, 0, 0))

    def test_changed_c_string_is_still_a_change(self):
        self.assertTrue(d2._real_data_change(b"access denied\x00", b"access granted\x00",
                                             0, 0, 0, 0))

    def test_relocated_pointer_with_nul_bytes_is_still_ignored(self):
        lo, hi = 0x400000, 0x500000
        pb = (0x401000).to_bytes(8, "little") * 6
        fb = (0x401010).to_bytes(8, "little") * 6
        with mock.patch.object(d2, "_looks_pointer", return_value=True):
            self.assertFalse(d2._real_data_change(pb, fb, lo, hi, lo, hi))

    def test_real_change_beside_a_relocated_pointer_is_detected(self):   # bug.md DB2-NT-2
        lo, hi = 0x400000, 0x500000
        # window = one relocated 8-byte pointer, then a genuinely changed 8-byte constant
        pb = (0x401000).to_bytes(8, "little") + b"SIZE=016"
        fb = (0x401010).to_bytes(8, "little") + b"SIZE=255"   # pointer moved AND constant changed
        self.assertTrue(d2._real_data_change(pb, fb, lo, hi, lo, hi),
                        "a real change beside a relocated pointer must not be voided with it")
        # a window whose ONLY difference is the relocated pointer is still churn
        pb2 = (0x401000).to_bytes(8, "little") + b"SIZE=016"
        fb2 = (0x401010).to_bytes(8, "little") + b"SIZE=016"
        self.assertFalse(d2._real_data_change(pb2, fb2, lo, hi, lo, hi))


# --------------------------------------------------------------------------- #34, #43
class StageSelectionAndBindingTests(_Tmp):
    def setUp(self):
        super().setUp()
        self.p, self.f, self.w = (os.path.join(self.d, x) for x in ("p", "f", "w"))
        self._sql(self.p, "select 1 from dual;")
        self._sql(self.f, "select 2 from dual;")

    def _sql(self, root, text):
        _write(os.path.join(root, "rdbms", "admin", "demo.sql"), text.encode())

    def _run(self, stages):
        with contextlib.redirect_stdout(io.StringIO()):
            return pl.run_pipeline("oracle", self.p, self.f, self.w, stages=stages,
                                   verbose=False)

    def test_one_shot_iterator_runs_the_requested_stage(self):                  # #34
        r = self._run(iter(["triage"]))
        self.assertEqual(sorted(r), ["triage"])
        self.assertEqual(sorted(self._run(s for s in ("triage", "stage1"))),
                         ["stage1", "triage"])

    def test_plain_string_is_one_stage_and_unknown_names_are_rejected(self):
        self.assertEqual(sorted(self._run("triage")), ["triage"])
        with self.assertRaises(ValueError):
            self._run(("triage", "stage3"))

    def test_later_stage_alone_runs_triage_when_stage0_is_foreign(self):        # #43
        self._run(("triage",))
        p0 = os.path.join(self.w, "stage0", "changed_files.json")
        with open(p0, encoding="utf-8") as fh:
            s0 = json.load(fh)
        s0["content_changed"] = []                       # the bugs.md reproduction
        with open(p0, "w", encoding="utf-8") as fh:
            json.dump(s0, fh)
        r = self._run(("stage1",))
        self.assertIn("triage", r, "an unbound Stage 0 must be refreshed, not trusted")
        self.assertEqual(r["stage1"]["counts"]["readable_changed"], 1)

    def test_later_stage_alone_reuses_a_current_stage0(self):
        self._run(("triage",))
        r = self._run(("stage1",))
        self.assertNotIn("triage", r)
        self.assertEqual(r["stage1"]["counts"]["readable_changed"], 1)

    def test_changed_inputs_make_the_stage0_stale(self):
        self._run(("triage",))
        self._sql(self.f, "select 3 from dual;")         # same length: names/sizes unchanged
        r = self._run(("stage1",))
        self.assertIn("triage", r)

    def test_backend_called_directly_rejects_a_foreign_or_missing_stage0(self):
        with self.assertRaises(RuntimeError):            # no Stage 0 at all
            o1.run(self.p, self.f, self.w)
        self._run(("triage",))
        other = os.path.join(self.d, "other")
        self._sql(other, "select 9 from dual;")
        with self.assertRaises(RuntimeError):            # Stage 0 of a different pair
            o1.run(self.p, other, self.w)
        r = o1.run(self.p, self.f, self.w)               # bound -> used
        self.assertEqual(r["counts"]["readable_changed"], 1)


# --------------------------------------------------------------------------- #48
class ManifestSnapshotTests(_Db2Base):
    def test_file_added_after_acquisition_is_not_hidden_by_the_manifest(self):
        out = self._acquire("1", "2")
        _write(os.path.join(out["fixed"], "cfg", "new.sql"), b"SELECT 1;")
        with mock.patch.object(dtri, "_from_manifest") as spy:
            r = dtri.run(out["vuln"], out["fixed"], self.work)
        spy.assert_not_called()
        self.assertIn("lib64/libdb2e.so.1",
                      [e["name"] for e in r["content_changed"] + r["code_changed"]])
        self.assertEqual([e["name"] for e in r["added"]], ["cfg/new.sql"])
        self.assertEqual(r["errors"], [], "mutually pruned trees are a sound full walk")

    def test_same_length_edit_after_acquisition_is_detected(self):
        out = self._acquire("1", "2")
        p = os.path.join(out["fixed"], "lib64", "libdb2e.so.1")
        with open(p, "rb") as fh:
            self.assertEqual(fh.read(), b"two")
        with open(p, "wb") as fh:
            fh.write(b"one")                             # now identical to the prior side
        r = dtri.run(out["vuln"], out["fixed"], self.work)
        names = [e["name"] for e in r["content_changed"] + r["code_changed"]]
        self.assertNotIn("lib64/libdb2e.so.1", names, "the manifest's stale 'changed' list "
                                                     "must not be trusted after an edit")
        self.assertEqual(r["errors"], [])

    def test_manifest_without_snapshot_falls_back_to_the_full_walk(self):
        out = self._acquire("1", "2")
        mp = os.path.join(self.work, "acquire", "manifest.json")
        with open(mp, encoding="utf-8") as fh:
            m = json.load(fh)
        m.pop("snapshot")
        with open(mp, "w", encoding="utf-8") as fh:
            json.dump(m, fh)
        with mock.patch.object(dtri, "_from_manifest") as spy:
            r = dtri.run(out["vuln"], out["fixed"], self.work)
        spy.assert_not_called()
        self.assertEqual([e["name"] for e in r["code_changed"] + r["content_changed"]],
                         ["lib64/libdb2e.so.1"])


# --------------------------------------------------------------------------- #52
class MssqlDecompileFunctionTests(_Tmp):
    def test_decompile_function_lays_out_chunks_and_uses_the_shared_pdb_cache(self):
        seen = {}

        class Sym:
            def __init__(self, *a):
                pass

            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

        def fetch(dll, cache, online=True):
            seen.setdefault("pdb_cache", cache)
            return None

        def pair(pb, fb):
            seen["blobs"] = (pb, fb)
            return "int f(void) { return 0; }", "int f(void) { return 1; }"

        fm = {"f": (0x1000, [(0x1010, b"\xc3"), (0x1000, b"\xeb\x0e")])}
        with mock.patch.object(mdec.sym, "fetch_pdb", fetch), \
                mock.patch.object(mdec.sym, "Symbolizer", Sym), \
                mock.patch.object(mdec, "_func_map", lambda path, s: fm), \
                mock.patch.object(mdec._dc, "decompile_pair", pair):
            path = mdec.decompile_function(self.d, self.d, "ENG_RE_x_dll_64", "f",
                                           os.path.join(self.d, "out"))
        self.assertEqual(seen["pdb_cache"], str(mdec._GLOBAL_PDB_CACHE))
        self.assertEqual(seen["blobs"][0], b"\xeb\x0e" + b"\xcc" * 14 + b"\xc3")
        with open(path, encoding="utf-8") as fh:
            payload = json.load(fh)
        self.assertIn("return 1", payload["fixed"])
        self.assertIn("return 0", payload["prior"])


if __name__ == "__main__":
    unittest.main()
