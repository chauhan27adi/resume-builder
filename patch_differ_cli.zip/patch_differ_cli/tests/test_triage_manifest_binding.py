"""Regression tests for bugs.md #14: Stage 0 applied any acquire/manifest.json it found and
walked neither input tree — so a stale manifest (an earlier acquisition, a side re-acquired
since, manually supplied --vuln/--fixed dirs, or for Oracle a DB2 run's manifest in a reused
output dir) made genuinely different trees report zero changes. A manifest now applies only
when it is bound to exactly these trees and their extraction ids are still current."""
import json
import os
import tempfile
import unittest
from unittest import mock

import patch_differ_cli.db2.acquire as dacq
import patch_differ_cli.db2.triage as dtri
import patch_differ_cli.oracle.triage as otri
from patch_differ_cli.tests.test_acquire_reuse import _fake_tree


def _write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)


def _changes(r):
    c = r["counts"]
    return c.get("code_changed", 0) + c.get("content_changed", 0)


class _Db2Base(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory(prefix="pdff_man_")
        self.work = self._td.name

    def tearDown(self):
        self._td.cleanup()

    def _manual_trees(self):
        p, f = os.path.join(self.work, "p"), os.path.join(self.work, "f")
        _write(os.path.join(p, "java", "dep.jar"), b"old")
        _write(os.path.join(f, "java", "dep.jar"), b"new-content")
        return p, f

    def _stale_manifest(self, obj):
        _write(os.path.join(self.work, "acquire", "manifest.json"), json.dumps(obj).encode())

    def _acquire(self, vuln_tag, fixed_tag):
        payload = {"1": {"lib64/libdb2e.so.1": b"one", "bin/same": b"s"},
                   "2": {"lib64/libdb2e.so.1": b"two", "bin/same": b"s"},
                   "3": {"lib64/libdb2e.so.1": b"three", "bin/same": b"s"}}

        def container(ref, side_dir, online, progress, base, span, hashes=None, root_dir=None):
            _fake_tree(root_dir, payload[ref.rsplit(":", 1)[-1]], hashes)
            return root_dir
        with mock.patch.object(dacq, "_acquire_container", container):
            return dacq.acquire({"vuln_dl_url": f"container:r/d:{vuln_tag}",
                                 "dl_url": f"container:r/d:{fixed_tag}"}, self.work)


class TestDb2(_Db2Base):
    def test_baseline_full_walk_sees_the_change(self):
        p, f = self._manual_trees()
        self.assertGreater(_changes(dtri.run(p, f, self.work)), 0)

    def test_stale_unbound_manifest_is_ignored(self):
        p, f = self._manual_trees()
        self._stale_manifest({"changed": [], "added": [], "removed": [], "identical": 0})
        self.assertGreater(_changes(dtri.run(p, f, self.work)), 0)

    def test_bound_manifest_for_other_trees_is_ignored(self):
        p, f = self._manual_trees()
        self._stale_manifest({"changed": [], "added": [], "removed": [], "identical": 0,
                              "trees": {s: {"root": "x", "vdir": "y", "extraction_id": "z"}
                                        for s in ("vuln", "fixed")}})
        self.assertGreater(_changes(dtri.run(p, f, self.work)), 0)

    def test_valid_bound_manifest_still_takes_the_fast_path(self):
        out = self._acquire("1", "2")
        with mock.patch.object(dtri, "_from_manifest", wraps=dtri._from_manifest) as spy:
            r = dtri.run(out["vuln"], out["fixed"], self.work)
        self.assertEqual(spy.call_count, 1)
        self.assertEqual([e["name"] for e in r["code_changed"] + r["content_changed"]],
                         ["lib64/libdb2e.so.1"])

    def test_bound_manifest_does_not_apply_to_manually_supplied_dirs(self):
        self._acquire("1", "2")
        p, f = self._manual_trees()
        with mock.patch.object(dtri, "_from_manifest") as spy:
            r = dtri.run(p, f, self.work)
        spy.assert_not_called()
        self.assertGreater(_changes(r), 0)

    def test_manifest_stale_after_reacquire_never_applies(self):
        out = self._acquire("1", "2")
        old = json.load(open(os.path.join(self.work, "acquire", "manifest.json")))
        out2 = self._acquire("1", "3")                         # both re-extracted (pruned pair)
        # simulate an older version leaving the previous manifest in place
        self._stale_manifest(old)
        with mock.patch.object(dtri, "_from_manifest") as spy:
            dtri.run(out2["vuln"], out2["fixed"], self.work)
        spy.assert_not_called()


class TestPrunedTreeWithoutManifest(_Db2Base):
    def test_pruned_acquired_tree_with_manual_partner_is_flagged(self):
        out = self._acquire("1", "2")
        p, f = self._manual_trees()
        r = dtri.run(out["vuln"], f, self.work)
        self.assertTrue(any("pruned" in e["error"] for e in r["errors"]))
        self.assertGreater(r["counts"]["errors"], 0)

    def test_unpruned_trees_are_not_flagged(self):
        p, f = self._manual_trees()
        self.assertEqual(dtri.run(p, f, self.work)["errors"], [])

    def test_valid_manifest_pair_is_not_flagged(self):
        out = self._acquire("1", "2")
        self.assertEqual(dtri.run(out["vuln"], out["fixed"], self.work)["errors"], [])


class TestOracle(unittest.TestCase):
    def test_db2_manifest_in_reused_output_dir_is_not_applied(self):
        with tempfile.TemporaryDirectory(prefix="pdff_man_ora_") as d:
            p, f = os.path.join(d, "p"), os.path.join(d, "f")
            _write(os.path.join(p, "lib", "x.jar"), b"old")
            _write(os.path.join(f, "lib", "x.jar"), b"new-content")
            baseline = _changes(otri.run(p, f, d))
            _write(os.path.join(d, "acquire", "manifest.json"),
                   json.dumps({"changed": [], "added": [], "removed": [],
                               "identical": 0}).encode())
            self.assertGreater(baseline, 0)
            self.assertEqual(_changes(otri.run(p, f, d)), baseline)


if __name__ == "__main__":
    unittest.main()
