"""Regression tests for bugs.md #1: DB2 acquisition joined tar member names straight onto
the destination (after `.lstrip("./")`), so a member with a `..` component, or an absolute /
drive-qualified name, wrote outside the extraction dir. All three extractors
(_extract_layers, _extract_tar, _extract_component_stream) now validate every member and
RAISE on an unsafe one. Also covers the `.lstrip("./")` side effect fixed alongside it:
leading dots were eaten, so `.metadata/` was never skipped and dotfiles lost their dot."""
import gzip
import io
import os
import tarfile
import tempfile
import unittest

import patch_differ_cli.db2.acquire as A

UNSAFE = [
    "opt/ibm/db2/V1/../../../../../ESCAPE.txt",
    "opt/ibm/db2/../../../ESCAPE.txt",
    "/abs/ESCAPE.txt",
    "C:/ESCAPE.txt",
    "opt/ibm/db2/V1/.. /.. /.. /.. /ESCAPE.txt",
]


def _tar_bytes(members, gz=False):
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w") as tf:
        for name, data in members:
            ti = tarfile.TarInfo(name)
            ti.size = len(data)
            tf.addfile(ti, io.BytesIO(data))
    raw = buf.getvalue()
    return gzip.compress(raw) if gz else raw


class _Harness(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory(prefix="pdff_trav_")
        self.base = self._td.name
        self.dest = os.path.join(self.base, "a", "b", "c", "d", "dest")
        os.makedirs(self.dest)

    def tearDown(self):
        self._td.cleanup()

    def _escaped(self):
        hits = []
        for dp, _dn, files in os.walk(self.base):
            for f in files:
                p = os.path.join(dp, f)
                if f == "ESCAPE.txt" or (not os.path.abspath(p).startswith(
                        os.path.abspath(self.dest)) and f.endswith(".txt")):
                    hits.append(p)
        return hits

    def _file(self, name, data):
        p = os.path.join(self.base, name)
        with open(p, "wb") as fh:
            fh.write(data)
        return p


class TestExtractTar(_Harness):
    def test_unsafe_members_raise_and_write_nothing_outside(self):
        for name in UNSAFE:
            with self.subTest(name=name):
                t = self._file("x.tar", _tar_bytes([(name, b"pwn")]))
                with self.assertRaises(A.UnsafeArchiveMember):
                    A._extract_tar(t, self.dest)
                self.assertEqual(self._escaped(), [])

    def test_legit_members_still_extract_and_keep_dotfiles(self):
        t = self._file("ok.tar", _tar_bytes([("./opt/ibm/db2/V1/lib64/x.so", b"elf"),
                                             ("opt/ibm/db2/V1/.profile", b"dot")]))
        hashes = {}
        A._extract_tar(t, self.dest, hashes=hashes)
        self.assertTrue(os.path.isfile(os.path.join(self.dest, "opt/ibm/db2/V1/lib64/x.so")))
        self.assertTrue(os.path.isfile(os.path.join(self.dest, "opt/ibm/db2/V1/.profile")))
        self.assertEqual(sorted(hashes), ["opt/ibm/db2/V1/.profile", "opt/ibm/db2/V1/lib64/x.so"])


class TestExtractLayers(_Harness):
    def test_unsafe_members_raise_and_write_nothing_outside(self):
        for name in UNSAFE:
            with self.subTest(name=name):
                layer = self._file("l.tar.gz", _tar_bytes([(name, b"pwn")], gz=True))
                with self.assertRaises(A.UnsafeArchiveMember):
                    A._extract_layers([layer], self.dest, A._SUBTREE)
                self.assertEqual(self._escaped(), [])

    def test_legit_layer_still_extracts(self):
        layer = self._file("ok.tar.gz", _tar_bytes([("./opt/ibm/db2/V1/lib64/x.so", b"e")],
                                                   gz=True))
        A._extract_layers([layer], self.dest, A._SUBTREE)
        self.assertTrue(os.path.isfile(os.path.join(self.dest, "opt/ibm/db2/V1/lib64/x.so")))


class TestExtractComponentStream(_Harness):
    def test_unsafe_members_raise_and_write_nothing_outside(self):
        for name in UNSAFE:
            with self.subTest(name=name):
                blob = io.BytesIO(_tar_bytes([(name, b"pwn")], gz=True))
                with self.assertRaises(A.UnsafeArchiveMember):
                    A._extract_component_stream(blob, self.dest)
                self.assertEqual(self._escaped(), [])

    def test_metadata_is_skipped_now_that_leading_dot_is_kept(self):
        blob = io.BytesIO(_tar_bytes([(".metadata/control.xml", b"m"),
                                      ("lib64/libdb2e.so.1", b"e")], gz=True))
        A._extract_component_stream(blob, self.dest)
        self.assertTrue(os.path.isfile(os.path.join(self.dest, "lib64", "libdb2e.so.1")))
        self.assertFalse(os.path.exists(os.path.join(self.dest, "metadata")))
        self.assertFalse(os.path.exists(os.path.join(self.dest, ".metadata")))


class TestMemberRel(unittest.TestCase):
    def test_normalization(self):
        self.assertEqual(A._member_rel("./opt//ibm/./db2/x"), "opt/ibm/db2/x")
        self.assertEqual(A._member_rel(".wh.foo"), ".wh.foo")
        self.assertEqual(A._member_rel("dir/.wh..wh..opq"), "dir/.wh..wh..opq")
        self.assertEqual(A._member_rel("./"), "")


class TestAcquireAbortsCleanly(unittest.TestCase):
    """End to end through acquire(): an unsafe member aborts the side, leaves no partial
    tree marked complete, and writes nothing outside."""

    def test_manual_drop_with_traversal_member(self):
        with tempfile.TemporaryDirectory(prefix="pdff_trav_e2e_") as work:
            drop = os.path.join(work, "acquire", "fixed", "drop")
            os.makedirs(drop)
            with open(os.path.join(drop, "fp.tar"), "wb") as fh:
                fh.write(_tar_bytes([("opt/ibm/db2/V1/../../../../../../ESCAPE.txt", b"pwn")]))
            with self.assertRaises(A.UnsafeArchiveMember):
                A.acquire({"dl_url": "manual:fp"}, work, sides=("fixed",))
            side = os.path.join(work, "acquire", "fixed")
            self.assertFalse(os.path.exists(os.path.join(side, "root.partial")))
            self.assertFalse(os.path.exists(os.path.join(side, "root.source.json")))
            for dp, _dn, files in os.walk(work):
                self.assertNotIn("ESCAPE.txt", files)


if __name__ == "__main__":
    unittest.main()
