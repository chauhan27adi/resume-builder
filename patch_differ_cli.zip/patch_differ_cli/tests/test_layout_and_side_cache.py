"""The shared per-version output layout (_layout.py) and MSSQL's pseudo-C cache kept per
function and build (_decompile.decompile_cached_per_side). Ghidra is faked; scratch files
live in TemporaryDirectory()s only."""
import json
import os
import tempfile
import time
import unittest
from unittest import mock

from patch_differ_cli import _decompile as dc
from patch_differ_cli import _layout
from patch_differ_cli import _x86diff as X


def _write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    return path


class LayoutModuleTests(unittest.TestCase):
    def test_names_and_folders(self):
        self.assertEqual(_layout.version_token("KB5122771"), "KB5122771")
        self.assertEqual(_layout.version_token(""), "unversioned")
        dirs = _layout.version_dirs("S", "KB1", "KB2")
        self.assertEqual(dirs["prior"]["asm"], os.path.join("S", "disassembled_instructions_vuln_KB1"))
        self.assertEqual(dirs["fixed"]["c"], os.path.join("S", "decompiled_c_fixed_KB2"))
        self.assertEqual((dirs["prior"]["build"], dirs["fixed"]["label"]), ("vuln", "KB2"))
        self.assertEqual(_layout.pair_diff_dir("S", "KB1", "KB2"),
                         os.path.join("S", "disassembled_instructions_KB1_vs_KB2"))
        self.assertNotEqual(_layout.function_file("GetX", ".c"), _layout.function_file("getX", ".c"))

    def test_binary_folder(self):
        with tempfile.TemporaryDirectory() as d:
            p = _write(os.path.join(d, "x.dll"), b"payload")
            f = _layout.binary_folder(os.path.join(d, "out"), "ENG_RE_x_64", p,
                                      {"label": "KB1", "build": "vuln"}, "x.dll")
            with open(os.path.join(f, "binary.json"), encoding="utf-8") as fh:
                meta = json.load(fh)
        self.assertEqual(meta["name"], "x.dll")
        import hashlib
        self.assertEqual(meta["sha256"], hashlib.sha256(b"payload").hexdigest())
        self.assertEqual((meta["version"], meta["build"]), ("KB1", "vuln"))
        self.assertTrue(os.path.basename(f).endswith(meta["sha256"][:8]))

    def test_listing(self):
        text = _layout.listing(X.md(), "f", "x.dll", 0x1000,
                               [(0x1000, b"\x31\xc0\xc3"), (0x2000, b"\xc3")])
        self.assertIn("; x.dll, primary RVA 0x1000, 4 bytes in 2 chunk(s)", text)
        self.assertIn("00001000  31c0", text)
        self.assertIn("; chunk at RVA 0x2000 (1 bytes)", text)

    def test_mssql_uses_the_shared_helpers(self):
        from patch_differ_cli.mssql import stage2 as ms2
        self.assertIs(ms2._version_token, _layout.version_token)
        self.assertIs(ms2._version_dirs, _layout.version_dirs)


class SideCacheTests(unittest.TestCase):
    def setUp(self):
        td = tempfile.TemporaryDirectory()
        self.addCleanup(td.cleanup)
        self.cache = td.name
        self.calls = []
        for target, value in (("available", True),):
            p = mock.patch.object(dc, target, return_value=value)
            p.start()
            self.addCleanup(p.stop)
        self.result = {b"A": "int a;", b"B": "int b;", b"C": "int c;"}
        p = mock.patch.object(dc, "_try_decompile", self._fake)
        p.start()
        self.addCleanup(p.stop)

    def _fake(self, pb, fb, *ctx):
        self.calls.append((pb, fb))
        return self.result.get(pb, "") if pb else "", self.result.get(fb, "") if fb else "", True

    def test_reused_in_any_pairing(self):
        self.assertEqual(dc.decompile_cached_per_side(b"A", b"B", self.cache),
                         ("int a;", "int b;", True))
        self.assertEqual(dc.decompile_cached_per_side(b"B", b"A", self.cache),
                         ("int b;", "int a;", True), "the swapped pairing is a full hit")
        self.assertEqual(dc.decompile_cached_per_side(b"B", b"C", self.cache)[:2],
                         ("int b;", "int c;"))
        self.assertEqual(self.calls, [(b"A", b"B"), (b"", b"C")],
                         "only the side not seen before is decompiled")

    def test_a_failed_side_is_retried_the_good_one_is_kept(self):
        self.result.pop(b"B")
        pc, fc, attempted = dc.decompile_cached_per_side(b"A", b"B", self.cache)
        self.assertEqual((pc, fc, attempted), ("int a;", "", True))
        self.assertEqual(dc.last_failure_reason(), "no pseudo-C for the fixed side")
        self.result[b"B"] = "int b;"
        self.assertEqual(dc.decompile_cached_per_side(b"A", b"B", self.cache)[:2],
                         ("int a;", "int b;"))
        self.assertEqual(self.calls[-1], (b"", b"B"))
        self.assertIsNone(dc.last_failure_reason())

    def test_the_old_pair_cache_is_used(self):
        old = dc._pair_cache_file(self.cache, b"A", b"B")
        _write(old, json.dumps({"prior_c": "int old_a;", "fixed_c": "int old_b;"}).encode())
        self.assertEqual(dc.decompile_cached_per_side(b"A", b"B", self.cache)[:2],
                         ("int old_a;", "int old_b;"))
        self.assertEqual(self.calls, [])
        self.assertEqual(dc.decompile_cached_per_side(b"B", b"A", self.cache)[:2],
                         ("int old_b;", "int old_a;"), "and moved into the per-side cache")
        self.assertEqual(self.calls, [])

    def test_without_ghidra(self):
        with mock.patch.object(dc, "available", return_value=False):
            self.assertEqual(dc.decompile_cached_per_side(b"A", b"B", self.cache),
                             ("", "", False))
        self.assertEqual(self.calls, [])

    def test_a_decompiler_change_misses(self):
        dc.decompile_cached_per_side(b"A", b"B", self.cache)
        with mock.patch.object(dc, "_decompiler_identity", return_value="other00"):
            dc.decompile_cached_per_side(b"A", b"B", self.cache)
        self.assertEqual(len(self.calls), 2)

    def test_stale_tmp_files_are_swept_fresh_ones_kept(self):
        pf = os.path.join(self.cache, dc._PER_FUNCTION_DIR)
        os.makedirs(pf, exist_ok=True)
        stale = _write(os.path.join(pf, "deadbeef.json.9999.tmp"), b"{}")
        fresh = _write(os.path.join(pf, "cafef00d.json.8888.tmp"), b"{}")
        old = time.time() - dc._TMP_STALE_SECS - 10
        os.utime(stale, (old, old))
        dc._TMP_SWEPT.discard(pf)            # force the once-per-process sweep to run here
        dc.decompile_cached_per_side(b"A", b"B", self.cache)
        self.assertFalse(os.path.exists(stale), "a crashed process's old .tmp is removed")
        self.assertTrue(os.path.exists(fresh),
                        "a recent .tmp is kept — it may be a live worker's in-progress write")

    def test_corrupt_entry_is_recomputed(self):
        dc.decompile_cached_per_side(b"A", b"B", self.cache)
        with open(dc._side_cache_file(self.cache, b"A"), "w") as fh:
            fh.write("{not json")
        dc.decompile_cached_per_side(b"A", b"B", self.cache)
        self.assertEqual(self.calls[-1], (b"A", b""))


class WiringTests(unittest.TestCase):
    def test_mssql_caches_per_side_db2_and_oracle_per_pair(self):
        from patch_differ_cli.db2 import stage2 as d2
        from patch_differ_cli.mssql import stage2 as ms2
        from patch_differ_cli.oracle import stage2 as os2
        self.assertIs(ms2.decompile_cached, dc.decompile_cached_per_side)
        self.assertIs(d2.decompile_cached, dc.decompile_cached)
        self.assertIs(os2.decompile_cached, dc.decompile_cached)


if __name__ == "__main__":
    unittest.main()
