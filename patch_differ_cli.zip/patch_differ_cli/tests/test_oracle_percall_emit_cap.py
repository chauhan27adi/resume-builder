"""Regression tests for CRIT-NT-5: oracle/stage2.py's run() creates a SINGLE `readable`
list and threads it into every _diff_o() call across the whole patch (one per changed
object file, and one per .a archive member) — unlike mssql/db2, where each binary is its
own job with its OWN fresh _EMIT_CAP budget (see mssql/stage2.py's _process_dll / db2/
stage2.py's _process_file). _diff_o()'s cap check used to read `len(readable)` against
that GLOBAL, run-wide accumulator, so one early, noisy object file could exhaust the
entire run's cap — silently suppressing every LATER file's own, otherwise-unrelated,
well-under-cap diffs, with no error and no indication anything was dropped.

The fix: _diff_o() now shadows its `readable` parameter with a fresh local list for the
duration of one call, applies _EMIT_CAP against that local list only, and merges it into
the caller's accumulator once at the very end — giving every object file (or archive
member) the same fresh per-call budget mssql/db2 already give each binary.

These tests drive the REAL _diff_o() and run() functions end-to-end against hand-built,
byte-exact ELF64 ET_REL (.o) images — no real toolchain-produced object file needed."""
import os
import struct
import tempfile
import unittest

import patch_differ_cli.oracle.stage2 as o2


def _sym(name_off, value, size):
    return struct.pack("<IBBHQQ", name_off, 0x02, 0, 1, value, size)


def _shdr(name_off, sh_type, addr, offset, size, link=0):
    return struct.pack("<IIQQQQIIQQ", name_off, sh_type, 0, addr, offset, size, link, 0, 1, 0)


def _build_elf(symbols):
    """symbols: [(name, value, size, code), ...], increasing non-overlapping addresses."""
    base = symbols[0][1]
    text_data = b""
    for _name, value, _size, code in symbols:
        pad = value - (base + len(text_data))
        text_data += b"\x00" * pad + code

    names = [n for n, *_ in symbols]
    strtab = b"\x00" + b"\x00".join(n.encode() for n in names) + b"\x00"
    name_offsets, pos = {}, 1
    for n in names:
        name_offsets[n] = pos
        pos += len(n) + 1

    symtab_data = _sym(0, 0, 0)
    for name, value, size, _code in symbols:
        symtab_data += _sym(name_offsets[name], value, size)

    shstrtab = b"\x00.text\x00.symtab\x00.strtab\x00.shstrtab\x00"
    HDR = 64
    text_off = HDR
    symtab_off = text_off + len(text_data)
    strtab_off = symtab_off + len(symtab_data)
    shstrtab_off = strtab_off + len(strtab)
    shdr_off = shstrtab_off + len(shstrtab)
    sections = [
        _shdr(0, 0, 0, 0, 0),
        _shdr(1, 1, base, text_off, len(text_data)),
        _shdr(7, 2, 0, symtab_off, len(symtab_data), link=3),
        _shdr(15, 3, 0, strtab_off, len(strtab)),
        _shdr(23, 3, 0, shstrtab_off, len(shstrtab)),
    ]
    ehdr = bytearray(64)
    ehdr[0:4] = b"\x7fELF"
    ehdr[4], ehdr[5], ehdr[6] = 2, 1, 1
    struct.pack_into("<H", ehdr, 0x10, 1)   # ET_REL
    struct.pack_into("<H", ehdr, 0x12, 0x3E)
    struct.pack_into("<I", ehdr, 0x14, 1)
    struct.pack_into("<Q", ehdr, 0x28, shdr_off)
    struct.pack_into("<H", ehdr, 0x34, 64)
    struct.pack_into("<H", ehdr, 0x3A, 64)
    struct.pack_into("<H", ehdr, 0x3C, len(sections))
    struct.pack_into("<H", ehdr, 0x3E, 4)
    return bytes(ehdr) + text_data + symtab_data + strtab + shstrtab + b"".join(sections)


def _tied_prior(n, prefix, stride=0x10):
    return [(f"{prefix}{i:04d}", 0x1000 + i * stride, 2, b"\x90\xc3") for i in range(n)]


def _tied_fixed(n, prefix, stride=0x10):
    return [(f"{prefix}{i:04d}", 0x1000 + i * stride, 3, b"\x90\x90\xc3") for i in range(n)]


class DiffOPerCallCapTests(unittest.TestCase):
    """Drives _diff_o() directly, mirroring exactly how run()'s loop calls it."""

    def test_noisy_object_does_not_starve_a_later_unrelated_object(self):
        P1 = {name: (v, c) for name, v, _s, c in _tied_prior(650, "zzFunc")}
        F1 = {name: (v, c) for name, v, _s, c in _tied_fixed(650, "zzFunc")}
        P2 = {name: (v, c) for name, v, _s, c in _tied_prior(20, "wwOther")}
        F2 = {name: (v, c) for name, v, _s, c in _tied_fixed(20, "wwOther")}

        orig_func_map = o2._func_map
        o2._func_map = lambda path: dict(
            {"P1": P1, "F1": F1, "P2": P2, "F2": F2}[path])
        try:
            with tempfile.TemporaryDirectory(prefix="pdff_crit_nt5_") as out:
                readable = []
                o2._diff_o("object1", "object1.o", "P1", "F1", out, readable, attrib=[])
                o2._diff_o("object2", "object2.o", "P2", "F2", out, readable, attrib=[])
        finally:
            o2._func_map = orig_func_map

        obj1_count = sum(1 for r in readable if r["object"].startswith("object1"))
        obj2_count = sum(1 for r in readable if r["object"].startswith("object2"))
        self.assertEqual(obj1_count, o2._EMIT_CAP,
                          "the noisy object should still itself be capped")
        self.assertEqual(obj2_count, 20,
                          "the later, unrelated, well-under-cap object must not be "
                          "starved by the earlier object exhausting a shared budget")

    def test_processing_order_does_not_matter(self):
        # The fix must not depend on which object happens to run first.
        P1 = {name: (v, c) for name, v, _s, c in _tied_prior(650, "zzFunc")}
        F1 = {name: (v, c) for name, v, _s, c in _tied_fixed(650, "zzFunc")}
        P2 = {name: (v, c) for name, v, _s, c in _tied_prior(20, "wwOther")}
        F2 = {name: (v, c) for name, v, _s, c in _tied_fixed(20, "wwOther")}

        orig_func_map = o2._func_map
        o2._func_map = lambda path: dict(
            {"P1": P1, "F1": F1, "P2": P2, "F2": F2}[path])
        try:
            with tempfile.TemporaryDirectory(prefix="pdff_crit_nt5_order_") as out:
                readable = []
                o2._diff_o("object2", "object2.o", "P2", "F2", out, readable, attrib=[])
                o2._diff_o("object1", "object1.o", "P1", "F1", out, readable, attrib=[])
        finally:
            o2._func_map = orig_func_map

        obj1_count = sum(1 for r in readable if r["object"].startswith("object1"))
        obj2_count = sum(1 for r in readable if r["object"].startswith("object2"))
        self.assertEqual(obj1_count, o2._EMIT_CAP)
        self.assertEqual(obj2_count, 20)


class RunPerCallCapEndToEndTests(unittest.TestCase):
    """Drives the REAL oracle.stage2.run() end-to-end against hand-built ELF .o files."""

    def test_full_pipeline_does_not_starve_later_object(self):
        with tempfile.TemporaryDirectory(prefix="pdff_crit_nt5_e2e_") as d:
            prior_dir = os.path.join(d, "prior")
            fixed_dir = os.path.join(d, "fixed")
            os.makedirs(prior_dir); os.makedirs(fixed_dir)
            rel1, rel2 = "object1.o", "object2.o"
            with open(os.path.join(prior_dir, rel1), "wb") as f:
                f.write(_build_elf(_tied_prior(650, "zzFunc")))
            with open(os.path.join(fixed_dir, rel1), "wb") as f:
                f.write(_build_elf(_tied_fixed(650, "zzFunc")))
            with open(os.path.join(prior_dir, rel2), "wb") as f:
                f.write(_build_elf(_tied_prior(20, "wwOther")))
            with open(os.path.join(fixed_dir, rel2), "wb") as f:
                f.write(_build_elf(_tied_fixed(20, "wwOther")))

            stage0 = {"code_changed": [
                {"name": rel1, "kind": "native", "change": "modified", "size": 1000},
                {"name": rel2, "kind": "native", "change": "modified", "size": 1000},
            ]}
            result = o2.run(prior_dir, fixed_dir, d, stage0=stage0)

        readable = result["readable_files"]
        obj1_count = sum(1 for r in readable if r["object"].startswith(o2._pretty(rel1)))
        obj2_count = sum(1 for r in readable if r["object"].startswith(o2._pretty(rel2)))
        self.assertEqual(obj1_count, o2._EMIT_CAP)
        self.assertEqual(obj2_count, 20,
                          "object2's legitimate diffs must survive the full run() "
                          "pipeline even though object1 alone exceeds the cap")


if __name__ == "__main__":
    unittest.main()
