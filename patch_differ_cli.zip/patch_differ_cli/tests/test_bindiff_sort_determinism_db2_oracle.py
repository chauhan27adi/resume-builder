"""Regression test for bugs.md #4: DB2's and Oracle's BinDiff-mode (Track-1) hit sorts had
no final name tie-breaker. Their pre-sort order comes from BinDiff's SQLite rows (no ORDER
BY), so with many exactly-tied hits and the emit cap reached, the row order decided which
functions were reported. Same shape as the MSSQL fix in test_bindiff_emit_cap_determinism.
Drives the real per-binary workers with only the function map and BinDiff mocked."""
import os
import random
import tempfile
import unittest
from unittest import mock

import patch_differ_cli.db2.stage2 as d2
import patch_differ_cli.oracle.stage2 as o2
from patch_differ_cli import _bindiff as bd_mod

N = 700   # above both caps (DB2 500, Oracle 600)


class _Match:
    def __init__(self, addr2):
        self.addr2, self.similarity, self.confidence = addr2, 0.5, 0.9


def _maps():
    P = {f"zzFunc{i:04d}": (0x1000 + i * 0x10, b"\x90\xc3") for i in range(N)}
    F = {f"zzFunc{i:04d}": (0x1000 + i * 0x10, b"\x90\x90\xc3") for i in range(N)}
    return P, F


def _matches(base, seed):
    items = [(0x1000 + i * 0x10 + base, _Match(0x1000 + i * 0x10 + base)) for i in range(N)]
    random.Random(seed).shuffle(items)
    return dict(items)


class TestDb2(unittest.TestCase):
    def _run(self, seed):
        P, F = _maps()
        m = _matches(d2._GHIDRA_ELF_PIE_BASE, seed)
        with tempfile.TemporaryDirectory(prefix="pdff_bd4_") as d:
            pd, fd, out = (os.path.join(d, x) for x in ("prior", "fixed", "out"))
            for x in (pd, fd, out):
                os.makedirs(x)
            for x in (pd, fd):
                open(os.path.join(x, "r.so"), "wb").write(b"\0")
            job = {"prior_dir": pd, "fixed_dir": fd, "rel": "r.so", "out": out, "attrib": [],
                   "use_bindiff": True, "decompile": False, "disassembled_dir": out,
                   "vuln_label": "v", "fixed_label": "f", "run_ts": "t",
                   "decompile_cache": os.path.join(out, "c"), "decompiled_c_dir": out}
            with mock.patch.object(d2, "_func_map", lambda p: dict(P if "prior" in p else F)), \
                    mock.patch.object(bd_mod, "diff_pair", lambda *a, **k: dict(m)):
                r = d2._process_file(job)
        return sorted(c["object"] for c in r["readable"])

    def test_emission_independent_of_match_row_order(self):
        a, b, c = self._run(1), self._run(2), self._run(3)
        self.assertEqual(len(a), d2._EMIT_CAP)
        self.assertEqual(a, b)
        self.assertEqual(a, c)


class TestOracle(unittest.TestCase):
    def _run(self, seed):
        P, F = _maps()
        m = _matches(o2._GHIDRA_ELF_REL_BASE, seed)
        with tempfile.TemporaryDirectory(prefix="pdff_bd4o_") as d:
            readable = []
            with mock.patch.object(o2, "_func_map", lambda p: dict(P if p == "PRIOR" else F)), \
                    mock.patch.object(bd_mod, "diff_pair", lambda *a, **k: dict(m)):
                o2._diff_o("k.o", "k.o", "PRIOR", "FIXED", d, readable, attrib=[],
                           use_bindiff=True)
        self.assertTrue(all(r["match_algorithm"] == "bindiff" for r in readable))
        return sorted(r["object"] for r in readable)

    def test_emission_independent_of_match_row_order(self):
        a, b, c = self._run(1), self._run(2), self._run(3)
        self.assertEqual(len(a), o2._EMIT_CAP)
        self.assertEqual(a, b)
        self.assertEqual(a, c)


if __name__ == "__main__":
    unittest.main()
