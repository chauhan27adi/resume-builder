"""Regression tests for bugs.md #6: mssql triage's _code_sig() returned None both for "not a
PE" and for "a PE that failed to parse", so a damaged or partially-downloaded DLL was filed as
ordinary content (never reaching Stage 2, never counted as an error), and a DLL truncated
after its code section hashed identically to the good build and was discarded as
rebuild-only. Uses this interpreter's own python3*.dll as a real PE fixture."""
import glob
import os
import shutil
import sys
import tempfile
import unittest

import pefile

from patch_differ_cli.mssql import triage as T


def _real_pe():
    for pat in ("python3*.dll", "python*.dll"):
        hits = sorted(glob.glob(os.path.join(sys.base_prefix, pat)))
        if hits:
            return hits[-1]
    return None


PE = _real_pe()


@unittest.skipUnless(PE, "needs a real PE file (python3*.dll) as a fixture")
class TestPeErrors(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory(prefix="pdff_pe_")
        self.d = self._td.name
        self.p, self.f = os.path.join(self.d, "p"), os.path.join(self.d, "f")
        os.makedirs(self.p)
        os.makedirs(self.f)
        self.name = "ENG_RE_sqlmin_dll_64"
        shutil.copy(PE, os.path.join(self.p, self.name))

    def tearDown(self):
        self._td.cleanup()

    def _fixed(self, data):
        with open(os.path.join(self.f, self.name), "wb") as fh:
            fh.write(data)

    def _good(self):
        with open(PE, "rb") as fh:
            return fh.read()

    def _run(self):
        return T.run(self.p, self.f, os.path.join(self.d, "out"))

    def _assert_error_not_discarded(self, r):
        self.assertEqual(r["counts"]["errors"], 1, r)
        self.assertNotIn(self.name, r["rebuild_only"])
        self.assertFalse(any(e["name"] == self.name for e in r["content_changed"]))

    def test_truncated_after_code_section_is_an_error_not_rebuild_only(self):
        pe = pefile.PE(PE, fast_load=True)
        ex = [s for s in pe.sections if s.Characteristics & 0x20000000]
        cut = max(s.PointerToRawData + s.SizeOfRawData for s in ex)
        pe.close()
        data = self._good()
        self.assertLess(cut, len(data), "fixture must have data after its code section")
        self._fixed(data[:cut])
        self._assert_error_not_discarded(self._run())

    def test_tiny_mz_copy_is_an_error_not_content(self):
        self._fixed(self._good()[:300])
        self._assert_error_not_discarded(self._run())

    def test_mz_plus_junk_is_an_error(self):
        self._fixed(b"MZ" + b"\x00junk" * 50)
        self._assert_error_not_discarded(self._run())

    def test_intact_copy_is_still_identical(self):
        self._fixed(self._good())
        r = self._run()
        self.assertEqual(r["counts"]["errors"], 0)
        self.assertEqual(r["counts"]["identical"], 1)

    def test_genuine_non_pe_content_is_still_content(self):
        for side, data in ((self.p, b"old text"), (self.f, b"new text")):
            with open(os.path.join(side, "readme_sql_64"), "w") as fh:
                fh.write(data.decode())
        self._fixed(self._good())
        r = self._run()
        self.assertEqual(r["counts"]["errors"], 0)
        self.assertEqual([e["name"] for e in r["content_changed"]], ["readme_sql_64"])

    def test_damaged_one_sided_dll_is_listed_and_errored(self):
        with open(os.path.join(self.f, "ENG_RE_new_dll_64"), "wb") as fh:
            fh.write(self._good()[:300])
        self._fixed(self._good())
        r = self._run()
        self.assertEqual([e["name"] for e in r["added"]], ["ENG_RE_new_dll_64"])
        self.assertEqual(r["counts"]["errors"], 1)


if __name__ == "__main__":
    unittest.main()
