"""Regression tests for bugs.md #12: every backend's _safe() replaced disallowed characters
with "_" and truncated to a fixed length, so distinct names mapped to one filename — two long
C++ names sharing a prefix overwrote each other's diff card (both cards then showed the
second function), "lib/private/api.so" and "lib_private_api.so" shared a concurrent BinDiff
workspace, and on NTFS names differing only in case collided too."""
import json
import os
import tempfile
import unittest

from patch_differ_cli.db2._paths import safe_name
import patch_differ_cli.db2.stage2 as d2
import patch_differ_cli.mssql.stage2 as m2
import patch_differ_cli.oracle.stage2 as o2
import patch_differ_cli.db2.stage1 as d1
import patch_differ_cli.mssql.stage1 as m1
import patch_differ_cli.oracle.stage1 as o1
from patch_differ_cli.tests.test_oracle_percall_emit_cap import _build_elf

LONG = "N" * 130


class TestSafeName(unittest.TestCase):
    def test_sanitization_collisions_are_distinct(self):
        self.assertNotEqual(safe_name("lib/private/api.so"), safe_name("lib_private_api.so"))

    def test_long_shared_prefix_is_distinct(self):
        self.assertNotEqual(safe_name(LONG + "::A"), safe_name(LONG + "::B"))

    def test_case_only_difference_is_distinct_case_insensitively(self):
        self.assertNotEqual(safe_name("GetX").lower(), safe_name("getX").lower())

    def test_bounded_deterministic_and_filesystem_safe(self):
        for s in ("CAlterLogin::CheckAuthorization", LONG * 3, "a b/c\d:e*?", "é名"):
            n = safe_name(s, 120)
            self.assertLessEqual(len(n), 120)
            self.assertEqual(n, safe_name(s, 120))
            self.assertRegex(n, r"^[A-Za-z0-9._-]+$")

    def test_every_backend_helper_uses_it(self):
        for mod in (d2, m2, o2, d1, m1, o1):
            with self.subTest(mod=mod.__name__):
                self.assertNotEqual(mod._safe(LONG + "A"), mod._safe(LONG + "B"))


class TestCardFilesDoNotCollide(unittest.TestCase):
    def test_two_long_names_get_their_own_card_contents(self):
        names = [LONG + "_FuncAlpha", LONG + "_FuncBeta"]
        with tempfile.TemporaryDirectory(prefix="pdff_safe_") as d:
            pd, fd, out = (os.path.join(d, x) for x in ("p", "f", "o"))
            for x in (pd, fd, out):
                os.makedirs(x)
            pc, fc = bytes.fromhex("83f805c3"), bytes.fromhex("83f80a7300e800000000c3")
            with open(os.path.join(pd, "r.so"), "wb") as fh:
                fh.write(_build_elf([(names[0], 0x1000, len(pc), pc), (names[1], 0x1040, len(pc), pc)]))
            with open(os.path.join(fd, "r.so"), "wb") as fh:
                fh.write(_build_elf([(names[0], 0x1000, len(fc), fc), (names[1], 0x1040, len(fc), fc)]))
            job = {"prior_dir": pd, "fixed_dir": fd, "rel": "r.so", "out": out, "attrib": [],
                   "use_bindiff": False, "decompile": False, "disassembled_dir": out,
                   "vuln_label": "v", "fixed_label": "f", "run_ts": "t"}
            cards = d2._process_file(job)["readable"]
            self.assertEqual(len(cards), 2)
            self.assertEqual(len({c["pair"] for c in cards}), 2)
            for c in cards:
                with open(os.path.join(out, c["pair"]), encoding="utf-8") as fh:
                    self.assertEqual(json.load(fh)["object"], c["object"])


if __name__ == "__main__":
    unittest.main()
