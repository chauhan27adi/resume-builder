"""Unit tests for _srcfix.py — the source-level (PL/SQL / Java) fix-shape scorer used by
Oracle's Stage 1. Pure logic, no external tools required."""
import unittest

from patch_differ_cli import _srcfix as S


class TestFixSignaturePlsql(unittest.TestCase):
    def test_no_fixed_lines_scores_zero(self):
        self.assertEqual(S.fix_signature(["a"], []), (0, []))

    def test_identical_lines_score_zero(self):
        lines = ["procedure foo is", "begin", "null;", "end;"]
        self.assertEqual(S.fix_signature(lines, list(lines)), (0, []))

    def test_added_dbms_assert_scores_and_is_named(self):
        prior = ["procedure foo(p in varchar2) is", "begin", "null;", "end;"]
        fixed = ["procedure foo(p in varchar2) is", "begin",
                 "dbms_assert.simple_sql_name(p);", "null;", "end;"]
        score, reasons = S.fix_signature(prior, fixed, lang="plsql")
        self.assertGreaterEqual(score, 8)
        self.assertTrue(any("DBMS_ASSERT" in r for r in reasons))

    def test_added_privilege_check_scores(self):
        prior = ["begin", "null;", "end;"]
        fixed = ["begin", "if not has_privilege(user) then",
                 "raise_application_error(-20001, 'denied');", "end if;", "null;", "end;"]
        score, reasons = S.fix_signature(prior, fixed, lang="plsql")
        self.assertGreater(score, 0)
        self.assertTrue(any("privilege" in r for r in reasons))

    def test_large_regenerated_file_caps_score_and_tags_reason(self):
        # Localised = (any prior lines) and frac <= 0.6. Make almost the whole fixed
        # file "changed" relative to a short prior, so frac is large and the file is
        # treated as regenerated rather than a surgical edit.
        prior = ["-- old file", "null;"]
        fixed = (["dbms_assert.simple_sql_name(x);"] * 2
                 + [f"-- regenerated line {i}" for i in range(50)])
        score, reasons = S.fix_signature(prior, fixed, lang="plsql")
        self.assertLessEqual(score, 4)
        self.assertTrue(any(r.startswith("large/regenerated file") for r in reasons))

    def test_small_surgical_change_gets_bonus(self):
        prior = ["begin", "null;", "end;"]
        fixed = ["begin", "if p is null then", "raise_application_error(-20001,'x');",
                 "end if;", "null;", "end;"]
        score, reasons = S.fix_signature(prior, fixed, lang="plsql")
        self.assertTrue(any("small surgical change" in r for r in reasons))


class TestFixSignatureJava(unittest.TestCase):
    def test_added_permission_check_scores(self):
        prior = ["void run() {", "doWork();", "}"]
        fixed = ["void run() {", "AccessController.checkPermission(perm);",
                 "doWork();", "}"]
        score, reasons = S.fix_signature(prior, fixed, lang="java")
        self.assertGreaterEqual(score, 8)
        self.assertTrue(any("permission" in r for r in reasons))

    def test_plsql_patterns_do_not_leak_into_java_scoring(self):
        # A line that would score under PL/SQL's dbms_assert pattern must not score under
        # the Java pattern set — lang selects a disjoint rule set.
        prior = ["void run() {", "}"]
        fixed = ["void run() {", "dbms_assert.simple_sql_name(x);", "}"]
        score, reasons = S.fix_signature(prior, fixed, lang="java")
        self.assertEqual((score, reasons), (0, []))


if __name__ == "__main__":
    unittest.main()
