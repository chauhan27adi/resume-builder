"""Regression tests for bug.md DB2-T2-1 and DB2-T2-2.

DB2-T2-1: the two decompile contexts must be SYMMETRIC — if one side's context can't be built
(a one-sided ELF/I/O failure), BOTH sides must be decompiled without context, or an unchanged
function shows a spurious pseudo-C diff (FUN_/DAT_ placeholders vs real names).

DB2-T2-2: the shared per-pair decompile cache must be written atomically (tmp + os.replace), so
a crash or a concurrent worker in the DB2 process pool can never leave a torn cache_file.

No Ghidra: the decompile is faked throughout."""
import contextlib
import glob
import io
import json
import os
import tempfile
import time
import unittest
from unittest import mock

import patch_differ_cli._decompile as D
import patch_differ_cli.db2.stage2 as d2
from patch_differ_cli import _x86diff as _X
from patch_differ_cli.tests.test_db2_major_fixes import GLOBAL, _lib, _mov, _write


class SymmetricContext(unittest.TestCase):
    """DB2-T2-1 — a one-sided context failure must drop BOTH contexts."""

    def setUp(self):
        self._old = os.environ.get("CVE_PATCHDIFF_WORKERS")
        os.environ["CVE_PATCHDIFF_WORKERS"] = "1"        # in-process so the mocks apply
        self.addCleanup(self._restore)

    def _restore(self):
        if self._old is None:
            os.environ.pop("CVE_PATCHDIFF_WORKERS", None)
        else:
            os.environ["CVE_PATCHDIFF_WORKERS"] = self._old

    def _run_capturing_ctx(self, break_side):
        """Run the real DB2 stage2 with --decompile; return the (prior_ctx, fixed_ctx) tuple the
        emit path passed to decompile_cached. `break_side` ("p"/"f") is the build whose context
        build raises, leaving that side's side_context() == None."""
        rel = "lib/libx.so"
        captured = []

        def fake_dc(pb, fb, cache, *ctx):
            captured.append(ctx)
            return ("int prior_c;", "int fixed_c;", True)

        with tempfile.TemporaryDirectory() as d:
            _write(os.path.join(d, "p", rel), _lib([("api", GLOBAL, _mov(1))]))
            _write(os.path.join(d, "f", rel), _lib([("api", GLOBAL, _mov(2))]))
            break_path = os.path.normpath(os.path.join(d, break_side, rel))
            real_ctx = d2._decompile_context

            def ctx(md, path, *a, **k):
                if os.path.normpath(path) == break_path:
                    raise RuntimeError("context unavailable on one side")
                return real_ctx(md, path, *a, **k)

            with mock.patch.object(_X, "fix_signature", return_value=(1, ["guard"])), \
                    mock.patch.object(d2, "_decompile_context", ctx), \
                    mock.patch.object(d2, "decompile_cached", fake_dc), \
                    contextlib.redirect_stderr(io.StringIO()):     # expected one-side warning
                res = d2.run(os.path.join(d, "p"), os.path.join(d, "f"), os.path.join(d, "w"),
                             stage0={"code_changed": [{"name": rel}]}, decompile=True,
                             vuln_label="v1", fixed_label="v2")
        return captured, res

    def test_prior_context_failure_drops_both_contexts(self):
        captured, res = self._run_capturing_ctx("p")
        self.assertEqual(len(captured), 1, "the one changed function was decompiled once")
        self.assertEqual(captured[0], (None, None),
                         "a failed prior context must also drop the (good) fixed context")
        self.assertEqual(res["counts"]["failed"], 0)

    def test_fixed_context_failure_drops_both_contexts(self):
        captured, _res = self._run_capturing_ctx("f")
        self.assertEqual(captured[0], (None, None))

    def test_both_contexts_survive_when_neither_side_fails(self):
        # Control: with no induced failure both contexts are real (truthy), so the fix does not
        # needlessly discard a usable context.
        rel = "lib/libx.so"
        captured = []
        with tempfile.TemporaryDirectory() as d:
            _write(os.path.join(d, "p", rel), _lib([("api", GLOBAL, _mov(1))]))
            _write(os.path.join(d, "f", rel), _lib([("api", GLOBAL, _mov(2))]))
            with mock.patch.object(_X, "fix_signature", return_value=(1, ["guard"])), \
                    mock.patch.object(d2, "decompile_cached",
                                      lambda pb, fb, cache, *c: captured.append(c)
                                      or ("int p;", "int f;", True)):
                d2.run(os.path.join(d, "p"), os.path.join(d, "f"), os.path.join(d, "w"),
                       stage0={"code_changed": [{"name": rel}]}, decompile=True,
                       vuln_label="v1", fixed_label="v2")
        self.assertEqual(len(captured), 1)
        pctx, fctx = captured[0]
        self.assertIsNotNone(pctx)
        self.assertIsNotNone(fctx)
        self.assertIn("names", pctx)      # both are real context dicts, not dropped to None
        self.assertIn("names", fctx)


class AtomicPairCacheWrite(unittest.TestCase):
    """DB2-T2-2 — the per-pair cache is staged to a tmp and os.replace()d."""

    def _dc(self, cache_dir, pb, fb):
        with mock.patch.object(D, "_try_decompile", return_value=("int p;", "int f;", True)):
            return D.decompile_cached(pb, fb, cache_dir)

    def test_replace_failure_leaves_no_torn_cache_file(self):
        with tempfile.TemporaryDirectory() as cache_dir:
            with mock.patch.object(D.os, "replace", side_effect=OSError("boom")):
                out = self._dc(cache_dir, b"AAA", b"BBB")
            self.assertEqual(out, ("int p;", "int f;", True), "result still returned")
            cache_file = D._pair_cache_file(cache_dir, b"AAA", b"BBB")
            self.assertFalse(os.path.exists(D.lp(cache_file)),
                             "a failed replace must never leave an in-place (torn) cache_file")

    def test_success_writes_valid_entry_and_leaves_no_tmp(self):
        with tempfile.TemporaryDirectory() as cache_dir:
            self._dc(cache_dir, b"CCC", b"DDD")
            cache_file = D._pair_cache_file(cache_dir, b"CCC", b"DDD")
            self.assertTrue(os.path.exists(D.lp(cache_file)))
            with open(D.lp(cache_file), encoding="utf-8") as fh:
                self.assertEqual(json.load(fh), {"prior_c": "int p;", "fixed_c": "int f;"})
            self.assertEqual(glob.glob(os.path.join(cache_dir, "*.tmp")), [],
                             "no staging tmp is left behind")
            # a second call is served from the cache (hit), proving the entry is well-formed
            with mock.patch.object(D, "_try_decompile",
                                   side_effect=AssertionError("should not re-decompile")):
                self.assertEqual(D.decompile_cached(b"CCC", b"DDD", cache_dir),
                                 ("int p;", "int f;", True))

    def test_stale_pair_tmp_is_swept_but_a_fresh_one_is_kept(self):
        with tempfile.TemporaryDirectory() as cache_dir:     # fresh dir -> sweep runs this call
            stale = os.path.join(cache_dir, "deadbeef.pair.tmp")
            fresh = os.path.join(cache_dir, "livedata.pair.tmp")
            for p in (stale, fresh):
                with open(p, "w") as fh:
                    fh.write("x")
            old = time.time() - 2 * D._TMP_STALE_SECS
            os.utime(stale, (old, old))
            self._dc(cache_dir, b"EEE", b"FFF")
            self.assertFalse(os.path.exists(stale), "a long-stale pair .tmp is swept")
            self.assertTrue(os.path.exists(fresh), "a recent .tmp (maybe a live write) is kept")


if __name__ == "__main__":
    unittest.main()
