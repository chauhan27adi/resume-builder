"""Regression tests for CRIT-NT-2: an ELF STT_FUNC symbol with no name (st_name == 0)
used to be silently dropped by db2/stage2.py::_func_map() and oracle/stage2.py's primary
pyelftools-based _func_map() alike -- so it could never be detected as changed, added, or
removed, with zero diagnostic. This is the ELF-side counterpart of CRIT-NT-1 (MSSQL's
functions with no public PDB symbol).

The fix: give such a symbol a synthetic "sub_<hex>" placeholder key instead of dropping it
(mirrors mssql/stage2.py's existing sub_<rva> scheme). As with CRIT-NT-1, this key is only
trusted for same-address byte-changed detection (`raw`/`common`): new/removed derivations in
both backends, and both name-mode and BinDiff-mode, deliberately keep excluding "sub_"-prefixed
keys, since an address present on only one side is an unreliable signal for an unnamed function
-- any unrelated layout shift elsewhere in the binary changes every downstream address, which
would manufacture phantom added/removed entries rather than catch a real one.

These tests drive the REAL production _func_map() parsers end-to-end against hand-built,
byte-exact ELF64 images -- no real toolchain-produced .so/.o needed."""
import os
import struct
import tempfile
import unittest

import patch_differ_cli.db2.stage2 as db2s2
import patch_differ_cli.oracle.stage2 as oras2


def _sym(name_off, value, size, info=0x02):
    # Elf64_Sym: st_name(4) st_info(1) st_other(1) st_shndx(2) st_value(8) st_size(8)
    return struct.pack("<IBBHQQ", name_off, info, 0, 1, value, size)


def _shdr(name_off, sh_type, addr, offset, size, link=0):
    # Elf64_Shdr: name(4) type(4) flags(8) addr(8) offset(8) size(8) link(4) info(4) align(8) entsize(8)
    return struct.pack("<IIQQQQIIQQ", name_off, sh_type, 0, addr, offset, size, link, 0, 1, 0)


def build_elf(symbols, et_rel=False):
    """symbols: list of (name_or_None, value, size, code_bytes). All code bytes are laid
    out back-to-back in .text starting at the first symbol's value; callers must keep
    `value` offsets consistent with that layout (as the helpers below do)."""
    text_chunks = []
    base = symbols[0][1]
    text_data = b""
    for _name, value, size, code in symbols:
        pad = value - (base + len(text_data))
        assert pad >= 0, "symbols must be laid out in increasing, non-overlapping order"
        text_data += b"\x00" * pad + code

    names = [n for n, *_ in symbols if n]
    strtab = b"\x00" + b"\x00".join(n.encode() for n in names) + (b"\x00" if names else b"")
    name_offsets = {}
    pos = 1
    for n in names:
        name_offsets[n] = pos
        pos += len(n) + 1

    symtab_data = _sym(0, 0, 0)   # mandatory null symbol
    for name, value, size, _code in symbols:
        symtab_data += _sym(name_offsets[name] if name else 0, value, size)

    shstrtab = b"\x00.text\x00.symtab\x00.strtab\x00.shstrtab\x00"
    off_text_nm, off_symtab_nm, off_strtab_nm, off_shstrtab_nm = 1, 7, 15, 23

    HDR = 64
    text_off = HDR
    symtab_off = text_off + len(text_data)
    strtab_off = symtab_off + len(symtab_data)
    shstrtab_off = strtab_off + len(strtab)
    shdr_off = shstrtab_off + len(shstrtab)

    sh_null = _shdr(0, 0, 0, 0, 0)
    sh_text = _shdr(off_text_nm, 1, base, text_off, len(text_data))
    sh_symtab = _shdr(off_symtab_nm, 2, 0, symtab_off, len(symtab_data), link=3)
    sh_strtab = _shdr(off_strtab_nm, 3, 0, strtab_off, len(strtab))
    sh_shstrtab = _shdr(off_shstrtab_nm, 3, 0, shstrtab_off, len(shstrtab))
    sections = [sh_null, sh_text, sh_symtab, sh_strtab, sh_shstrtab]

    ehdr = bytearray(64)
    ehdr[0:4] = b"\x7fELF"
    ehdr[4] = 2   # ELFCLASS64
    ehdr[5] = 1   # ELFDATA2LSB
    ehdr[6] = 1   # EI_VERSION
    struct.pack_into("<H", ehdr, 0x10, 1 if et_rel else 2)   # e_type: ET_REL or ET_EXEC
    struct.pack_into("<H", ehdr, 0x12, 0x3E)                  # e_machine: EM_X86_64
    struct.pack_into("<I", ehdr, 0x14, 1)                     # e_version
    struct.pack_into("<Q", ehdr, 0x28, shdr_off)              # e_shoff
    struct.pack_into("<H", ehdr, 0x34, 64)                    # e_ehsize
    struct.pack_into("<H", ehdr, 0x3A, 64)                    # e_shentsize
    struct.pack_into("<H", ehdr, 0x3C, len(sections))         # e_shnum
    struct.pack_into("<H", ehdr, 0x3E, 4)                     # e_shstrndx

    return bytes(ehdr) + text_data + symtab_data + strtab + shstrtab + b"".join(sections)


def _write_elf(d, filename, symbols, et_rel=False):
    p = os.path.join(d, filename)
    with open(p, "wb") as f:
        f.write(build_elf(symbols, et_rel=et_rel))
    return p


class DB2UnnamedFunctionTests(unittest.TestCase):
    """db2/stage2.py::_func_map() -- pure struct ELF64 parser (also Oracle's fallback path,
    imported there as _elf_func_map_text)."""

    def test_unnamed_function_is_no_longer_dropped(self):
        with tempfile.TemporaryDirectory(prefix="pdff_crit_nt2_db2_") as d:
            p = _write_elf(d, "test.so", [
                ("NamedHelper", 0x1000, 2, b"\x90\xc3"),
                (None, 0x1002, 3, b"\x90\x90\xc3"),
            ])
            result = db2s2._func_map(p)
        self.assertIn("NamedHelper", result)
        self.assertIn("sub_1002", result,
                       f"empty-named STT_FUNC must get a sub_<hex> placeholder, got: {list(result)}")
        self.assertEqual(result["sub_1002"], (0x1002, b"\x90\x90\xc3"))

    def test_unnamed_function_same_address_changed_bytes_is_reported(self):
        with tempfile.TemporaryDirectory(prefix="pdff_crit_nt2_db2_") as d:
            prior_p = _write_elf(d, "prior.so", [(None, 0x2000, 2, b"\x90\xc3")])
            fixed_p = _write_elf(d, "fixed.so", [(None, 0x2000, 3, b"\x90\x90\xc3")])
            P, F = db2s2._func_map(prior_p), db2s2._func_map(fixed_p)
        common = P.keys() & F.keys()
        raw = [k for k in common if P[k][1] != F[k][1]]
        self.assertIn("sub_2000", raw, "a byte-changed unnamed function at a shared "
                                        "address must survive into the changed-function set")

    def test_unnamed_function_only_in_fixed_is_excluded_from_new(self):
        with tempfile.TemporaryDirectory(prefix="pdff_crit_nt2_db2_") as d:
            prior_p = _write_elf(d, "prior.so", [("Keep", 0x1000, 2, b"\x90\xc3")])
            fixed_p = _write_elf(d, "fixed.so", [
                ("Keep", 0x1000, 2, b"\x90\xc3"),
                (None, 0x1002, 3, b"\x90\x90\xc3"),
            ])
            P, F = db2s2._func_map(prior_p), db2s2._func_map(fixed_p)
        new = sorted(k for k in F.keys() - P.keys() if not k.startswith("sub_"))
        self.assertEqual(new, [], "an unnamed-only-on-one-side function must not be "
                                   "reported as added")

    def test_unnamed_function_only_in_prior_is_excluded_from_removed(self):
        with tempfile.TemporaryDirectory(prefix="pdff_crit_nt2_db2_") as d:
            prior_p = _write_elf(d, "prior.so", [
                ("Keep", 0x1000, 2, b"\x90\xc3"),
                (None, 0x1002, 3, b"\x90\x90\xc3"),
            ])
            fixed_p = _write_elf(d, "fixed.so", [("Keep", 0x1000, 2, b"\x90\xc3")])
            P, F = db2s2._func_map(prior_p), db2s2._func_map(fixed_p)
        removed = sorted(k for k in P.keys() - F.keys() if not k.startswith("sub_"))
        self.assertEqual(removed, [], "an unnamed-only-on-one-side function must not be "
                                       "reported as removed")

    def test_named_function_behavior_is_unaffected(self):
        with tempfile.TemporaryDirectory(prefix="pdff_crit_nt2_db2_") as d:
            p = _write_elf(d, "test.so", [("DoRiskyThing", 0x3000, 2, b"\x90\xc3")])
            result = db2s2._func_map(p)
        self.assertEqual(set(result), {"DoRiskyThing"})
        self.assertEqual(result["DoRiskyThing"], (0x3000, b"\x90\xc3"))


class OraclePyelftoolsUnnamedFunctionTests(unittest.TestCase):
    """oracle/stage2.py's primary (pyelftools-based) _func_map()."""

    def test_unnamed_function_is_no_longer_dropped(self):
        with tempfile.TemporaryDirectory(prefix="pdff_crit_nt2_ora_") as d:
            p = _write_elf(d, "test.o", [
                ("NamedHelper", 0x1000, 2, b"\x90\xc3"),
                (None, 0x1002, 3, b"\x90\x90\xc3"),
            ], et_rel=True)
            result = oras2._func_map(p)
        self.assertIn("NamedHelper", result)
        self.assertIn("sub_1002", result,
                       f"empty-named STT_FUNC must get a sub_<hex> placeholder, got: {list(result)}")
        self.assertEqual(result["sub_1002"], (0x1002, b"\x90\x90\xc3"))

    def test_unnamed_function_same_address_changed_bytes_is_reported(self):
        with tempfile.TemporaryDirectory(prefix="pdff_crit_nt2_ora_") as d:
            prior_p = _write_elf(d, "prior.o", [(None, 0x2000, 2, b"\x90\xc3")], et_rel=True)
            fixed_p = _write_elf(d, "fixed.o", [(None, 0x2000, 3, b"\x90\x90\xc3")], et_rel=True)
            P, F = oras2._func_map(prior_p), oras2._func_map(fixed_p)
        common = P.keys() & F.keys()
        self.assertIn("sub_2000", common)
        self.assertNotEqual(P["sub_2000"][1], F["sub_2000"][1])

    def test_named_function_behavior_is_unaffected(self):
        with tempfile.TemporaryDirectory(prefix="pdff_crit_nt2_ora_") as d:
            p = _write_elf(d, "test.o", [("DoRiskyThing", 0x3000, 2, b"\x90\xc3")], et_rel=True)
            result = oras2._func_map(p)
        self.assertEqual(set(result), {"DoRiskyThing"})
        self.assertEqual(result["DoRiskyThing"], (0x3000, b"\x90\xc3"))


if __name__ == "__main__":
    unittest.main()
