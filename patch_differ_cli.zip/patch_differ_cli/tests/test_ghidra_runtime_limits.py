"""db2_bugs.md DB2-11 / DB2-13 / DB2-15 / DB2-7 and bugs.md MSSQL-1 / MSSQL-2 / MSSQL-4.

* run_tool() kills the whole process tree on timeout or interrupt and never blocks on a
  descendant that still holds the output (real child + grandchild processes here);
* timeouts count awake time only;
* the Ghidra heap and the step timeouts scale with the input and can be overridden;
* concurrent Ghidra jobs are capped by memory;
* ghidra_binexport() reports an out-of-memory run and re-exports from a finished analysis
  instead of importing again;
* skipped DB2 fixpack members are reported, and a stale list is not.
No Ghidra or BinDiff runs: those steps are faked."""
import contextlib
import io
import os
import subprocess
import sys
import tarfile
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

from patch_differ_cli import _bindiff as bd
from patch_differ_cli import _parallel
from patch_differ_cli import pipeline as pl
from patch_differ_cli import tool_paths as tp
from patch_differ_cli.db2 import acquire as db2acq

GIB, MIB = 1 << 30, 1 << 20

# A child that starts a grandchild holding the inherited stdout, prints the grandchild's
# pid, then sleeps. A plain Popen.kill() of the child leaves the grandchild running.
_PARENT = (
    "import subprocess, sys, time\n"
    "g = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(30)'])\n"
    "print('GRANDCHILD', g.pid, flush=True)\n"
    "time.sleep(30)\n")


def _bytes(path):
    with open(path, "rb") as fh:
        return fh.read()


def _alive(pid):
    if os.name != "nt":
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False
    import ctypes
    k32 = ctypes.windll.kernel32
    h = k32.OpenProcess(0x1000, False, pid)          # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return False
    try:
        code = ctypes.c_ulong()
        return bool(k32.GetExitCodeProcess(h, ctypes.byref(code))) and code.value == 259
    finally:
        k32.CloseHandle(h)


def _grandchild(output):
    for line in (output or b"").decode().splitlines():
        if line.startswith("GRANDCHILD"):
            return int(line.split()[1])
    return None


def _wait_started(log_path, timeout=20):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        if os.path.exists(log_path) and b"GRANDCHILD" in _bytes(log_path):
            return
        time.sleep(0.1)


class RunToolTests(unittest.TestCase):
    def test_timeout_kills_the_whole_tree_and_returns_promptly(self):
        t0 = time.monotonic()
        with self.assertRaises(subprocess.TimeoutExpired) as cm:
            tp.run_tool([sys.executable, "-c", _PARENT], timeout=3)
        elapsed = time.monotonic() - t0
        self.assertLess(elapsed, 20, "must not wait for the grandchild holding the output")
        pid = _grandchild(cm.exception.output)
        self.assertIsNotNone(pid, cm.exception.output)
        time.sleep(1)
        self.assertFalse(_alive(pid), "the grandchild must be killed with its parent")

    def test_interrupt_kills_the_whole_tree(self):
        with tempfile.TemporaryDirectory() as d:
            log = os.path.join(d, "tool.log")
            real = tp._awake_seconds

            def awake():
                _wait_started(log)
                if os.path.exists(log) and b"GRANDCHILD" in _bytes(log):
                    raise KeyboardInterrupt
                return real()

            with mock.patch.object(tp, "_awake_seconds", awake):
                with self.assertRaises(KeyboardInterrupt):
                    tp.run_tool([sys.executable, "-c", _PARENT], timeout=60, log_path=log)
            pid = _grandchild(_bytes(log))
            self.assertIsNotNone(pid)
            time.sleep(1)
            self.assertFalse(_alive(pid))

    def test_completed_run_returns_output_rc_and_keeps_the_log(self):
        with tempfile.TemporaryDirectory() as d:
            log = os.path.join(d, "sub", "tool.log")
            p = tp.run_tool([sys.executable, "-c",
                             "import sys; print('out'); print('err', file=sys.stderr); "
                             "sys.exit(3)"], timeout=60, log_path=log)
            self.assertEqual(p.returncode, 3)
            self.assertIn(b"out", p.stdout)
            self.assertIn(b"err", p.stdout)
            self.assertEqual(_bytes(log), p.stdout)

    def test_a_huge_kept_log_is_trimmed_but_the_caller_gets_everything(self):
        with tempfile.TemporaryDirectory() as d:
            log = os.path.join(d, "tool.log")
            src = ("import sys; w = sys.stdout.buffer.write; w(b'HEAD' + b'h' * 100); "
                   "w(b'.' * (7 << 20)); w(b'OutOfMemoryError'); w(b't' * 100 + b'TAIL')")
            p = tp.run_tool([sys.executable, "-c", src], timeout=60, log_path=log)
            self.assertGreater(len(p.stdout), 7 << 20)
            self.assertIn(b"OutOfMemoryError", p.stdout)
            kept = _bytes(log)
            self.assertLess(len(kept), (5 << 20) + 200)
            self.assertTrue(kept.startswith(b"HEAD"))
            self.assertTrue(kept.endswith(b"TAIL"))
            self.assertIn(b"bytes of output omitted", kept)

    def test_stdin_is_closed_so_a_prompt_cannot_hang(self):
        p = tp.run_tool([sys.executable, "-c", "import sys; print(repr(sys.stdin.read()))"],
                        timeout=30)
        self.assertIn(b"''", p.stdout)

    def test_time_asleep_does_not_count(self):
        # the awake clock stands still (the machine is "asleep") while the tool runs 3 s
        with mock.patch.object(tp, "_awake_seconds", return_value=1000.0):
            p = tp.run_tool([sys.executable, "-c", "import time; time.sleep(3)"], timeout=1)
        self.assertEqual(p.returncode, 0)

    def test_awake_time_does_count(self):
        clock = iter(range(0, 10 ** 6, 100))           # 100 awake seconds per reading
        with mock.patch.object(tp, "_awake_seconds", lambda: float(next(clock))):
            with self.assertRaises(subprocess.TimeoutExpired):
                tp.run_tool([sys.executable, "-c", "import time; time.sleep(30)"], timeout=150)

    def test_no_limit(self):
        p = tp.run_tool([sys.executable, "-c", "print(1)"], timeout=None)
        self.assertEqual(p.returncode, 0)

    @unittest.skipUnless(os.name == "nt", "Windows clock")
    def test_awake_clock_is_readable(self):
        a = tp._awake_seconds()
        time.sleep(0.2)
        self.assertGreater(tp._awake_seconds(), a)


class HeapTests(unittest.TestCase):
    def setUp(self):
        p = mock.patch.dict(os.environ, {}, clear=False)
        p.start()
        self.addCleanup(p.stop)
        os.environ.pop(tp.HEAP_ENV, None)
        os.environ.pop("_JAVA_OPTIONS", None)

    def test_default_and_scaled(self):
        with mock.patch.object(tp, "physical_memory", return_value=64 * GIB):
            self.assertEqual(tp.ghidra_heap(), 2 * GIB)
            self.assertEqual(tp.ghidra_heap(50 * MIB), 2 * GIB)       # sqlmin-sized
            self.assertEqual(tp.ghidra_heap(150 * MIB), 6 * GIB)
            self.assertEqual(tp.ghidra_heap(10 * GIB), 32 * GIB)      # half the RAM

    def test_capped_by_ram_but_never_below_the_default(self):
        with mock.patch.object(tp, "physical_memory", return_value=8 * GIB):
            self.assertEqual(tp.ghidra_heap(150 * MIB), 4 * GIB)
        with mock.patch.object(tp, "physical_memory", return_value=2 * GIB):
            self.assertEqual(tp.ghidra_heap(150 * MIB), 2 * GIB)
        with mock.patch.object(tp, "physical_memory", return_value=None):
            self.assertEqual(tp.ghidra_heap(150 * MIB), 6 * GIB)

    def test_override(self):
        for text, want in (("8G", 8 * GIB), ("6144m", 6 * GIB), (" 3g ", 3 * GIB)):
            os.environ[tp.HEAP_ENV] = text
            self.assertEqual(tp.ghidra_heap(1), want, text)
        for bad in ("8", "abc", "100M", "0G", "-4G", "8GB"):
            os.environ[tp.HEAP_ENV] = bad
            with self.assertRaises(ValueError, msg=bad):
                tp.ghidra_heap()

    def test_env_only_set_when_not_the_scripts_default(self):
        with mock.patch.object(tp, "child_env", return_value={}), \
                mock.patch.object(tp, "physical_memory", return_value=64 * GIB):
            self.assertNotIn("_JAVA_OPTIONS", tp.ghidra_env(1))
            self.assertEqual(tp.ghidra_env(150 * MIB)["_JAVA_OPTIONS"], "-Xmx6144m")
        with mock.patch.object(tp, "child_env", return_value={"_JAVA_OPTIONS": "-Dmine=1"}):
            os.environ[tp.HEAP_ENV] = "3G"
            self.assertEqual(tp.ghidra_env()["_JAVA_OPTIONS"], "-Dmine=1 -Xmx3072m")

    def test_physical_memory_is_readable(self):
        ram = tp.physical_memory()
        self.assertTrue(ram is None or ram > 256 * MIB)


class StepTimeoutTests(unittest.TestCase):
    def setUp(self):
        p = mock.patch.dict(os.environ, {}, clear=False)
        p.start()
        self.addCleanup(p.stop)
        for _f, _p, name in bd._STEPS.values():
            os.environ.pop(name, None)

    def test_floors_and_scaling(self):
        self.assertEqual(bd.step_timeout("import", 0), 3600)
        self.assertEqual(bd.step_timeout("export", 1 * MIB), 600)
        self.assertEqual(bd.step_timeout("differ", 1 * MIB), 300)
        # sqlmin.dll: 49.8 MiB analysed in up to 8,121 s, which the old 3,600 s cut off
        self.assertGreater(bd.step_timeout("import", int(49.8 * MIB)), 8121 * 1.4)
        self.assertEqual(bd.step_timeout("export", 100 * MIB), 6000)
        self.assertEqual(bd.step_timeout("differ", 100 * MIB), 3000)

    def test_override(self):
        os.environ["PATCHDIFF_GHIDRA_IMPORT_TIMEOUT"] = "20000"
        self.assertEqual(bd.step_timeout("import", 1), 20000)
        os.environ["PATCHDIFF_BINEXPORT_TIMEOUT"] = "0"
        self.assertIsNone(bd.step_timeout("export", 1))
        for bad in ("1h", "-5", "2.5", "²"):
            os.environ["PATCHDIFF_BINDIFF_TIMEOUT"] = bad
            with self.assertRaises(ValueError, msg=bad):
                bd.step_timeout("differ", 1)

    def test_bad_settings_are_refused_before_the_run(self):
        os.environ["PATCHDIFF_BINDIFF_TIMEOUT"] = "soon"
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(pl, "_acquire_db2", side_effect=AssertionError("ran")):
            with self.assertRaises(ValueError):
                pl.run_pipeline("db2", vuln_dir=d, fixed_dir=d, out_dir=os.path.join(d, "o"),
                                stages=(), verbose=False, use_bindiff=True)


class WorkerCapTests(unittest.TestCase):
    def setUp(self):
        p = mock.patch.dict(os.environ, {}, clear=False)
        p.start()
        self.addCleanup(p.stop)
        os.environ.pop("CVE_PATCHDIFF_WORKERS", None)
        for target, value in (("cpu_count", 8),):
            p = mock.patch.object(_parallel.os, target, return_value=value)
            p.start()
            self.addCleanup(p.stop)
        p = mock.patch.object(tp, "physical_memory", return_value=16 * GIB)
        p.start()
        self.addCleanup(p.stop)

    def test_default_heaps_keep_the_cpu_based_count(self):
        self.assertEqual(_parallel.worker_count(10, [2 * GIB] * 10), 4)
        self.assertEqual(_parallel.worker_count(10), 4)

    def test_large_heaps_lower_the_count(self):
        self.assertEqual(_parallel.worker_count(4, [6 * GIB, 6 * GIB, 2 * GIB, 2 * GIB]), 2)
        self.assertEqual(_parallel.worker_count(3, [16 * GIB] * 3), 1)

    def test_explicit_override_wins(self):
        os.environ["CVE_PATCHDIFF_WORKERS"] = "4"
        self.assertEqual(_parallel.worker_count(4, [16 * GIB] * 4), 4)

    def test_only_bindiff_jobs_count(self):
        jobs = [{"rel": "a", "use_bindiff": False}, {"rel": "b", "use_bindiff": False}]
        self.assertEqual(_parallel._ghidra_heaps(jobs, {"a": 10 * GIB, "b": 10 * GIB}), ())
        jobs[0]["use_bindiff"] = True
        with mock.patch.object(tp, "physical_memory", return_value=64 * GIB):
            self.assertEqual(_parallel._ghidra_heaps(jobs, {"a": 150 * MIB}), [6 * GIB])


class _Proc:
    def __init__(self, rc=0, out=b""):
        self.returncode, self.stdout = rc, out


class BinExportRuntimeTests(unittest.TestCase):
    def setUp(self):
        td = tempfile.TemporaryDirectory()
        self.addCleanup(td.cleanup)
        self.d = td.name
        self.binary = os.path.join(self.d, "x.so")
        with open(self.binary, "wb") as fh:
            fh.write(b"\x7fELF bin")
        self.proj = os.path.join(self.d, "proj")
        self.out = os.path.join(self.d, "exp", "x.BinExport")
        self.calls = []
        self.import_result = lambda: _Proc(0)
        self.export_result = lambda: _Proc(0)
        for target, value in (("analyze_headless", "analyzeHeadless.bat"),
                              ("locate_binexport_script", os.path.join(self.d, "BinExport.java")),
                              ("clear_stale_ghidra_script_cache", None), ("child_env", {}),
                              ("binexport_identity", "tool"), ("protobuf_conflict", [])):
            p = mock.patch.object(bd.tp, target, return_value=value)
            p.start()
            self.addCleanup(p.stop)
        p = mock.patch.object(bd, "_run_tool", self._run)
        p.start()
        self.addCleanup(p.stop)
        p = mock.patch.dict(os.environ, {}, clear=False)
        p.start()
        self.addCleanup(p.stop)
        os.environ.pop(tp.HEAP_ENV, None)

    def _run(self, cmd, **kw):
        step = "export" if "-postScript" in cmd else "import"
        self.calls.append((step, kw))
        if step == "import":
            return self.import_result()
        r = self.export_result()
        if r.returncode == 0 and bd._OOM_MARKER not in r.stdout:
            os.makedirs(os.path.dirname(self.out), exist_ok=True)
            with open(self.out, "wb") as fh:
                fh.write(b"EXPORT")
        return r

    def _export(self):
        return bd.ghidra_binexport(self.binary, self.proj, self.out)

    def _steps(self):
        return [s for s, _ in self.calls]

    def test_out_of_memory_import_is_a_failure_with_the_fix_named(self):
        self.import_result = lambda: _Proc(0, b"java.lang.OutOfMemoryError: Java heap space")
        with self.assertRaises(RuntimeError) as cm:
            self._export()
        self.assertIn(tp.HEAP_ENV, str(cm.exception))
        self.assertEqual(self._steps(), ["import"], "no export from a starved analysis")
        self.assertEqual(bd._project_imports(self.proj), {})

    def test_out_of_memory_export_is_a_failure(self):
        self.export_result = lambda: _Proc(0, b"Exception java.lang.OutOfMemoryError")
        with self.assertRaises(RuntimeError) as cm:
            self._export()
        self.assertIn(tp.HEAP_ENV, str(cm.exception))
        self.assertFalse(os.path.exists(self.out + ".sha256"))

    def test_export_timeout_keeps_the_analysis_for_the_next_run(self):
        def slow():
            raise subprocess.TimeoutExpired("export", 600)
        self.export_result = slow
        with self.assertRaises(subprocess.TimeoutExpired):
            self._export()
        self.assertEqual(self._steps(), ["import", "export"])
        self.calls.clear()
        self.export_result = lambda: _Proc(0)
        self._export()
        self.assertEqual(self._steps(), ["export"], "the finished analysis is reused")
        self.calls.clear()
        self._export()
        self.assertEqual(self._steps(), [], "and the export is then a cache hit")

    def test_import_timeout_is_not_reused(self):
        def slow():
            raise subprocess.TimeoutExpired("import", 3600)
        self.import_result = slow
        with self.assertRaises(subprocess.TimeoutExpired):
            self._export()
        self.calls.clear()
        self.import_result = lambda: _Proc(0)
        self._export()
        self.assertEqual(self._steps(), ["import", "export"])

    def test_failed_export_analyses_again(self):
        self.export_result = lambda: _Proc(2, b"boom")
        with self.assertRaises(RuntimeError):
            self._export()
        self.calls.clear()
        self.export_result = lambda: _Proc(0)
        self._export()
        self.assertEqual(self._steps(), ["import", "export"])

    def test_other_input_in_the_project_is_not_reused(self):
        self._export()
        os.remove(self.out)
        os.remove(self.out + ".sha256")
        with open(self.binary, "wb") as fh:
            fh.write(b"\x7fELF other build")
        self.calls.clear()
        self._export()
        self.assertEqual(self._steps(), ["import", "export"])

    def test_limits_and_heap_reach_the_tool(self):
        os.environ[tp.HEAP_ENV] = "4G"
        self._export()
        (_, imp), (_, exp) = self.calls
        self.assertEqual(imp["timeout"], bd.step_timeout("import", os.path.getsize(self.binary)))
        self.assertEqual(exp["timeout"], bd.step_timeout("export", os.path.getsize(self.binary)))
        self.assertEqual(imp["env"]["_JAVA_OPTIONS"], "-Xmx4096m")
        self.assertTrue(imp["log_path"].endswith(".import.log"))
        self.assertTrue(exp["log_path"].endswith(".export.log"))


class RunDifferTests(unittest.TestCase):
    def setUp(self):
        td = tempfile.TemporaryDirectory()
        self.addCleanup(td.cleanup)
        self.d = td.name
        self.p = os.path.join(self.d, "p.BinExport")
        self.f = os.path.join(self.d, "f.BinExport")
        for x in (self.p, self.f):
            with open(x, "wb") as fh:
                fh.write(b"x" * 10)
        p = mock.patch.object(bd.tp, "locate_differ", return_value="bindiff.exe")
        p.start()
        self.addCleanup(p.stop)

    def test_timeout_names_the_limit(self):
        def slow(cmd, **kw):
            raise subprocess.TimeoutExpired(cmd, kw["timeout"])
        with mock.patch.object(bd, "_run_tool", slow):
            with self.assertRaises(RuntimeError) as cm:
                bd.run_differ(self.p, self.f, os.path.join(self.d, "o"))
        self.assertIn(f"after {bd._TIMEOUT_DIFFER}s", str(cm.exception))

    def test_failure_exit_code(self):
        with mock.patch.object(bd, "_run_tool", lambda cmd, **kw: _Proc(4, b"bad input")):
            with self.assertRaises(RuntimeError) as cm:
                bd.run_differ(self.p, self.f, os.path.join(self.d, "o"))
        self.assertIn("rc=4", str(cm.exception))
        self.assertIn("bad input", str(cm.exception))


LIB = "opt/ibm/db2/V11.5/lib64/libdb2x.so.1"


def _tar(path, members):
    with tarfile.open(path, "w") as t:
        for name, data in members:
            info = tarfile.TarInfo(name)
            info.size = len(data)
            t.addfile(info, io.BytesIO(data))


class SkippedMembersTests(unittest.TestCase):
    def _acquire(self, d, out, archive):
        pl._stage_db2_archive(archive, out, "vuln")
        err = io.StringIO()
        with contextlib.redirect_stderr(err), \
                mock.patch.object(db2acq, "_LAYER_CACHE", db2acq._LAYER_CACHE):
            pl._acquire_db2(out, "manual:v11.5.9-1", None, False, sides=("vuln",))
        return err.getvalue()

    def test_skipped_member_is_reported_and_cleared_by_a_clean_extraction(self):
        with tempfile.TemporaryDirectory() as d:
            out = Path(d) / "out"
            src = Path(d) / "vuln"
            src.mkdir()
            a = src / "update_1_v11.5.9_x.tar"
            # "a" as a file and then as a directory: the second cannot be created
            _tar(a, [(LIB, b"lib"), ("opt/ibm/db2/V11.5/a", b"f"),
                     ("opt/ibm/db2/V11.5/a/b", b"g")])
            err = self._acquire(d, out, a)
            self.assertIn("WARNING: DB2 vuln build: 1 fixpack member(s)", err)
            self.assertIn("skipped_members.txt", err)
            # reused tree: still reported
            self.assertIn("1 fixpack member(s)", self._acquire(d, out, a))
            os.remove(a)
            _tar(a, [(LIB, b"lib2")])                # a clean, different archive
            err = self._acquire(d, out, a)
            self.assertNotIn("WARNING: DB2", err)
            self.assertFalse((out / "acquire" / "vuln" / "skipped_members.txt").exists())

    def test_no_list_no_warning(self):
        with tempfile.TemporaryDirectory() as d:
            err = io.StringIO()
            with contextlib.redirect_stderr(err):
                pl._warn_db2_skipped_members(Path(d), "fixed")
            self.assertEqual(err.getvalue(), "")


if __name__ == "__main__":
    unittest.main()
