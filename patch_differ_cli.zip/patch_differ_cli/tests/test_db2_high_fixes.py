"""db2_bugs.md remaining High items: DB2-2 (symbols checked before the run, configurable
function-size limit, unsupported ELF named), DB2-3 (an over-long input path no longer stops
BinDiff) and DB2-12 (--bindiff-only, --decompile-max, an up-front BinDiff estimate). Ghidra,
BinDiff and decompilation are faked; scratch files live in TemporaryDirectory()s only."""
import contextlib
import io
import os
import struct
import tempfile
import unittest
from unittest import mock

from patch_differ_cli import _bindiff as bd
from patch_differ_cli import _decompile
from patch_differ_cli import _parallel
from patch_differ_cli import _results
from patch_differ_cli import _x86diff
from patch_differ_cli import cli
from patch_differ_cli import pipeline as pl
from patch_differ_cli.db2 import _elf
from patch_differ_cli.db2 import stage2 as d2
from patch_differ_cli.db2 import triage as dt
from patch_differ_cli.db2._paths import lp
from patch_differ_cli.mssql import stage2 as ms2
from patch_differ_cli.tests.test_db2_major_fixes import (GLOBAL, _elf64, _job, _lib, _mov,
                                                          _write)


def _read(path):
    with open(path, "rb") as fh:
        return fh.read()


def _env(**kw):
    """os.environ patched with `kw` and the variables this file tests removed."""
    p = mock.patch.dict(os.environ, {}, clear=False)
    p.start()
    for k in (_results.MAX_FUNC_BYTES_ENV,):
        os.environ.pop(k, None)
    os.environ.update(kw)
    return p


# --------------------------------------------------------------------------- DB2-12
class BindiffSelectionTests(unittest.TestCase):
    def test_glob_matching(self):
        self.assertTrue(bd.bindiff_selected("lib64/libdb2e.so.1", None))
        self.assertTrue(bd.bindiff_selected("lib64/libdb2e.so.1", ["libdb2e.so*"]))
        self.assertTrue(bd.bindiff_selected("lib64/libdb2e.so.1", ["LIB64/*"]))
        self.assertTrue(bd.bindiff_selected("lib64\\libDB2E.so.1", ["libdb2e*"]))
        self.assertFalse(bd.bindiff_selected("lib64/libdb2.so.1", ["libdb2e*"]))

    def test_db2_only_selected_binaries_use_bindiff(self):
        calls = []

        def fake_diff_pair(prior, fixed, workdir, progress=None):
            calls.append(os.path.basename(prior))
            raise RuntimeError("fake BinDiff")                 # -> recorded fallback

        # in-process workers: a pool child would not see the fake and would launch Ghidra
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.dict(os.environ, {"CVE_PATCHDIFF_WORKERS": "1"}), \
                mock.patch.object(bd, "diff_pair", fake_diff_pair):
            for name in ("liba.so", "libb.so"):
                for side, k in (("p", 1), ("f", 2)):
                    _write(os.path.join(d, side, "lib", name), _lib([("f", GLOBAL, _mov(k))]))
            err = io.StringIO()
            with contextlib.redirect_stderr(err):
                r = d2.run(os.path.join(d, "p"), os.path.join(d, "f"), os.path.join(d, "w"),
                           stage0={"code_changed": [{"name": "lib/liba.so"},
                                                    {"name": "lib/libb.so"}]},
                           use_bindiff=True, bindiff_only=["liba*"])
        self.assertEqual(calls, ["liba.so"])
        self.assertEqual(r["bindiff_not_selected"], ["lib/libb.so"])
        self.assertEqual([f["rel"] for f in r["bindiff_fallbacks"]], ["lib/liba.so"],
                         "a non-selected binary is not a fallback")
        self.assertIn("NOTE: BinDiff will analyse 1 binary(ies)", err.getvalue())

    def test_mssql_matches_the_dll_name_too(self):
        seen = {}

        def fake_run_jobs(jobs, process, weights, **kw):
            seen.update({j["rel"]: (j["use_bindiff"], j["decompile_max"]) for j in jobs})

        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(_parallel, "run_jobs", fake_run_jobs):
            for side in ("p", "f"):
                for n in ("ENG_RE_sqlmin_64", "ENG_RE_qds_64"):
                    _write(os.path.join(d, side, n), b"MZ")
            r = ms2.run(os.path.join(d, "p"), os.path.join(d, "f"), os.path.join(d, "w"),
                        stage0={"code_changed": [{"name": "ENG_RE_sqlmin_64"},
                                                 {"name": "ENG_RE_qds_64"}]},
                        use_bindiff=True, bindiff_only=["sqlmin.dll"], decompile=True,
                        decompile_max=3)
        self.assertEqual(seen, {"ENG_RE_sqlmin_64": (True, 3), "ENG_RE_qds_64": (False, 3)})
        self.assertEqual(r["bindiff_not_selected"], ["ENG_RE_qds_64"])

    def test_options_are_validated_before_the_run(self):
        ok = pl._check_budget_options
        self.assertEqual(ok(True, False, ["a*,  b*", "c"], None), (["a*", "b*", "c"], None))
        self.assertEqual(ok(False, True, None, 4), (None, 4))
        self.assertEqual(ok(False, False, None, None), (None, None))
        for args in ((False, False, ["a*"], None),       # --bindiff-only without --use-bindiff
                     (True, False, [" , "], None),        # no pattern
                     (False, False, None, 3),             # --decompile-max without --decompile
                     (False, True, None, 0), (False, True, None, -2), (False, True, None, "x"),
                     (False, True, None, True)):
            with self.assertRaises(ValueError, msg=args):
                ok(*args)
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(pl, "_acquire_db2", side_effect=AssertionError("ran")):
            with self.assertRaises(ValueError):
                pl.run_pipeline("db2", vuln_dir=d, fixed_dir=d, out_dir=os.path.join(d, "o"),
                                stages=(), verbose=False, bindiff_only=["x*"])

    def test_cli_passes_the_options_through(self):
        seen = {}

        def fake_run_pipeline(**kw):
            seen.update(kw)
            return {}

        with mock.patch("patch_differ_cli.pipeline.run_pipeline", fake_run_pipeline), \
                tempfile.TemporaryDirectory() as d, contextlib.redirect_stdout(io.StringIO()):
            cli.main(["run", "--db", "db2", "--out", d, "--use-bindiff", "--bindiff-only", "libdb2e*",
                      "--bindiff-only", "libdb2.so*", "--decompile", "--decompile-max", "5",
                      "--quiet"])
        self.assertEqual(seen["bindiff_only"], ["libdb2e*", "libdb2.so*"])
        self.assertEqual(seen["decompile_max"], 5)


class DecompileCapTests(unittest.TestCase):
    def test_gate(self):
        st = {"attempted": 0, "failed": 0}
        self.assertTrue(_decompile.decompile_allowed(None, {"attempted": 10 ** 6}))
        self.assertTrue(_decompile.decompile_allowed(1, st))
        st["attempted"] = 1
        self.assertFalse(_decompile.decompile_allowed(1, st))
        self.assertEqual(st["skipped"], 1)

    def test_db2_decompiles_at_most_n_per_binary_most_important_first(self):
        rel = "lib/libx.so"
        calls = []

        def fake_decompile(pb, fb, cache, *contexts):
            calls.append(pb)
            return "int f(){}", "int f(){}", True

        def score(prior, fixed, **kw):          # fix-shaped: f2 most, then f1, then f0
            return (int(prior[0][-1]) + 1 if prior and prior[0][-1].isdigit() else 1, ["x"])

        funcs = lambda k: [(f"f{i}", GLOBAL, _mov(i + k)) for i in range(3)]
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(d2, "decompile_cached", fake_decompile), \
                mock.patch.object(_x86diff, "fix_signature", return_value=(1, ["guard"])):
            _write(os.path.join(d, "p", rel), _lib(funcs(0)))
            _write(os.path.join(d, "f", rel), _lib(funcs(100)))
            job = _job(d, rel)
            job.update(decompile=True, decompile_max=1, decompile_cache=d,
                       decompiled_c_dir=os.path.join(d, "c"))
            os.makedirs(job["decompiled_c_dir"])
            r = d2._process_file(job)
        self.assertEqual(len(calls), 1)
        self.assertEqual((r["decompile_attempted"], r["decompile_skipped"]), (1, 2))
        self.assertEqual(len(r["readable"]), 3, "the cards are all still written")

    def test_mssql_gate_is_applied(self):
        from patch_differ_cli.tests.test_fallback_and_symbol_reporting import _mssql_run
        real = ms2._process_dll

        def with_decompile(job):
            job.update(decompile=True, decompile_max=0)
            return real(job)

        with mock.patch.object(ms2, "_process_dll", with_decompile), \
                mock.patch.object(ms2, "decompile_cached",
                                  side_effect=AssertionError("Ghidra called")), \
                mock.patch.object(_x86diff, "fix_signature", return_value=(1, ["guard"])):
            r = _mssql_run(symbolized=("prior", "fixed"))
        self.assertEqual((r["decompile_attempted"], r["decompile_skipped"]), (0, 1))

    def test_oracle_counts_per_object_and_keeps_the_callers_dict_shape(self):
        import patch_differ_cli.oracle.stage2 as os2
        from patch_differ_cli import _attribution as _AT
        P = {f"DoRangeCheck{i}": (0x1000 + 16 * i, bytes.fromhex("b82a000000c3"))
             for i in range(3)}
        F = {k: (v[0], bytes.fromhex("b8ffffffffc3")) for k, v in P.items()}
        attrib = _AT.build_attrib([("CVE-2024-9999", "a buffer overflow issue", "Engine", "",
                                    "CWE-787")])
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(os2, "_func_map",
                                  lambda path: dict(P if path == "PRIOR" else F)), \
                mock.patch.object(os2, "decompile_cached",
                                  return_value=("int f(){}", "int f(){}", True)):
            out = os.path.join(d, "out")
            for sub in ("", "dc", "c"):
                os.makedirs(os.path.join(out, sub), exist_ok=True)
            kw = dict(attrib=attrib, decompile=True, decompile_cache=os.path.join(out, "dc"),
                      decompiled_c_dir=os.path.join(out, "c"), disassembled_dir=out,
                      run_ts="t")
            st = {"attempted": 0, "failed": 0}
            os2._diff_o("a.o", "a.o", "PRIOR", "FIXED", out, [], decompile_stats=st, **kw)
            self.assertEqual(st, {"attempted": 3, "failed": 0}, "no cap: dict shape unchanged")
            st = {"attempted": 0, "failed": 0}
            for obj in ("a.o", "b.o"):
                os2._diff_o(obj, obj, "PRIOR", "FIXED", out, [], decompile_stats=st,
                            decompile_max=1, **kw)
        self.assertEqual(st, {"attempted": 2, "failed": 0, "skipped": 4},
                         "1 per object, 2 skipped in each")


class BindiffEstimateTests(unittest.TestCase):
    def test_note(self):
        mib = 1 << 20
        jobs = [{"rel": "lib/big.so", "use_bindiff": True},
                {"rel": "lib/small.so", "use_bindiff": True},
                {"rel": "lib/new.so", "use_bindiff": True, "one_sided": "added"},
                {"rel": "lib/name.so", "use_bindiff": False}]
        note = _parallel.bindiff_plan_note(jobs, {"lib/big.so": 45 * mib,
                                                  "lib/small.so": 5 * mib}, 2)
        self.assertIn("2 binary(ies)", note)
        self.assertIn("50 MiB per build", note)
        self.assertIn("largest lib/big.so, 45.0 MiB", note)
        self.assertIn("up to about 4.4 h", note)          # 2 x 50 MiB x 160 s
        self.assertIn("2 at a time", note)
        self.assertIsNone(_parallel.bindiff_plan_note(jobs[3:], {}, 1))

    def test_cli_notes(self):
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            cli._warn_decompile_shortfalls({"stage2": {
                "counts": {"decompile_skipped": 4}, "bindiff_not_selected": ["a", "b"]}})
        self.assertIn("4 decompile(s) not run: --decompile-max reached", err.getvalue())
        self.assertIn("2 binary(ies) matched by name, not BinDiff", err.getvalue())


# --------------------------------------------------------------------------- DB2-2
def _elf32():
    eh = bytearray(52)
    eh[0:4], eh[4], eh[5], eh[6] = b"\x7fELF", 1, 1, 1
    return bytes(eh)


class SymbolsAndSizeLimitTests(unittest.TestCase):
    def test_symbol_source(self):
        with tempfile.TemporaryDirectory() as d:
            cases = {"symtab": _lib([("f", GLOBAL, _mov(1))]),
                     "dynsym": _lib([("f", GLOBAL, _mov(1))], kind="dynsym"),
                     "none": _lib([("f", GLOBAL, _mov(1))], kind=None),
                     "unsupported": _elf32()}
            for want, data in cases.items():
                self.assertEqual(_elf.symbol_source(_write(os.path.join(d, want), data)), want)
            self.assertEqual(_elf.symbol_source(_write(os.path.join(d, "txt"), b"hello")),
                             "none")

    def test_triage_records_symbols_and_the_pipeline_warns_before_stage2(self):
        with tempfile.TemporaryDirectory() as d:
            p, f = os.path.join(d, "p"), os.path.join(d, "f")
            for name, kind in (("full.so", "symtab"), ("stripped.so", "dynsym"),
                               ("bare.so", None)):
                _write(os.path.join(p, "lib", name), _lib([("f", GLOBAL, _mov(1))], kind=kind))
                _write(os.path.join(f, "lib", name), _lib([("f", GLOBAL, _mov(2))], kind=kind))
            r = dt.run(p, f, os.path.join(d, "w"))
            err = io.StringIO()
            with contextlib.redirect_stderr(err):
                pl._warn_unsymbolized(r)
        got = {e["name"]: e["symbols"] for e in r["code_changed"]}
        self.assertEqual(got, {"lib/full.so": "symtab", "lib/stripped.so": "dynsym",
                               "lib/bare.so": "none"})
        self.assertEqual((r["counts"]["code_changed_exported_symbols_only"],
                          r["counts"]["code_changed_without_symbols"]), (1, 1))
        self.assertIn("1 code-changed binary(ies) have exported function symbols only",
                      err.getvalue())
        self.assertIn("lib/bare.so", err.getvalue())

    def test_weaker_side_wins(self):
        with tempfile.TemporaryDirectory() as d:
            a = _write(os.path.join(d, "a"), _lib([("f", GLOBAL, _mov(1))]))
            b = _write(os.path.join(d, "b"), _lib([("f", GLOBAL, _mov(2))], kind="dynsym"))
            self.assertEqual(dt._code_entry({}, a, b)["symbols"], "dynsym")

    def test_size_limit_is_configurable(self):
        p = _env()
        self.addCleanup(p.stop)
        self.assertEqual(_results.max_func_bytes(300_000), 300_000)
        with tempfile.TemporaryDirectory() as d:
            path = _write(os.path.join(d, "x.so"), _lib([("big", GLOBAL, b"\x90" * 40 + b"\xc3"),
                                                         ("small", GLOBAL, _mov(1))]))
            self.assertEqual(sorted(d2._func_map(path)), ["big", "small"])
            os.environ[_results.MAX_FUNC_BYTES_ENV] = "20"
            m = d2._func_map(path)
            self.assertEqual(sorted(m), ["small"])
            self.assertIn("big", m.oversized, "over the limit: reported, not dropped")
        for bad in ("0", "-1", "1e6", "big"):
            os.environ[_results.MAX_FUNC_BYTES_ENV] = bad
            with self.assertRaises(ValueError, msg=bad):
                _results.max_func_bytes(1)

    def test_unsupported_elf_is_named_in_the_failure(self):
        rel = "lib/lib32.so"
        with tempfile.TemporaryDirectory() as d:
            _write(os.path.join(d, "p", rel), _elf32())
            _write(os.path.join(d, "f", rel), _elf32())
            r = d2._process_file(_job(d, rel))
        self.assertFalse(r["ok"])
        self.assertIn("not a 64-bit little-endian ELF", r["error"])


# --------------------------------------------------------------------------- DB2-3
@unittest.skipUnless(os.name == "nt", "Windows path limit")
class LongInputPathTests(unittest.TestCase):
    def _long_binary(self, d, data=b"\x7fELF binary"):
        deep = os.path.join(d, *(["x" * 40] * 7))
        self.assertGreater(len(deep), bd._MAX_WINDOWS_PATH)
        os.makedirs(lp(deep), exist_ok=True)
        path = os.path.join(deep, "libdeep.so")
        with open(lp(path), "wb") as fh:
            fh.write(data)
        return path

    def test_alias_keeps_the_name_and_follows_the_source(self):
        with tempfile.TemporaryDirectory() as d:
            src = self._long_binary(d)
            proj = os.path.join(d, "bd", "ghidra_proj")
            os.makedirs(proj)
            alias = bd._short_input(src, proj)
            self.assertLessEqual(len(os.path.abspath(alias)), bd._MAX_WINDOWS_PATH)
            self.assertEqual(os.path.basename(alias), "libdeep.so")
            self.assertEqual(_read(alias), b"\x7fELF binary")
            self.assertEqual(bd._short_input(src, proj), alias, "reused")
            os.remove(lp(src))
            with open(lp(src), "wb") as fh:
                fh.write(b"\x7fELF rebuilt")
            self.assertEqual(_read(bd._short_input(src, proj)), b"\x7fELF rebuilt")
            short = os.path.join(d, "short.so")
            _write(short, b"x")
            self.assertEqual(bd._short_input(short, proj), short)

    def test_binexport_runs_on_the_alias(self):
        cmds = []

        def fake_run(cmd, **kw):
            cmds.append(cmd)
            if "-postScript" in cmd:
                out = cmd[cmd.index("-postScript") + 2]
                os.makedirs(os.path.dirname(out), exist_ok=True)
                with open(out, "wb") as fh:
                    fh.write(b"EXPORT")
            return type("P", (), {"returncode": 0, "stdout": b""})()

        with tempfile.TemporaryDirectory() as d, contextlib.ExitStack() as st:
            for target, value in (("analyze_headless", "analyzeHeadless.bat"),
                                  ("locate_binexport_script", os.path.join(d, "BinExport.java")),
                                  ("clear_stale_ghidra_script_cache", None), ("child_env", {}),
                                  ("binexport_identity", "tool"), ("protobuf_conflict", [])):
                st.enter_context(mock.patch.object(bd.tp, target, return_value=value))
            st.enter_context(mock.patch.object(bd, "_run_tool", fake_run))
            src = self._long_binary(d)
            out = os.path.join(d, "bd", "prior_libdeep.BinExport")
            bd.ghidra_binexport(src, os.path.join(d, "bd", "ghidra_proj"), out)
            imported = cmds[0][cmds[0].index("-import") + 1]
            self.assertNotEqual(imported, src)
            self.assertEqual(os.path.basename(imported), "libdeep.so")
            self.assertEqual(cmds[1][cmds[1].index("-process") + 1], "libdeep.so")
            self.assertEqual(_read(out), b"EXPORT")

    def test_an_alias_that_is_still_too_long_is_refused_clearly(self):
        with tempfile.TemporaryDirectory() as d:
            src = self._long_binary(d)
            proj = os.path.join(d, *(["y" * 40] * 6), "ghidra_proj")
            self.assertIsNone(bd._short_input(src, proj))


if __name__ == "__main__":
    unittest.main()
