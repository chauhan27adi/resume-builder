"""MSSQL Stage 1 without the resource DB on one or both sides. That used to make the WHOLE
stage return "unavailable", skipping the loose readable scripts and embedded T-SQL too, even
though only the system-object diff needs the resource DB. Now only that part is marked
unavailable (logged, and still flagged by the CLI as a partial failure -> exit 3) and the
other passes run. Drives the real run(); only resource-DB discovery/carving is mocked."""
import contextlib
import io
import os
import tempfile
import unittest
from unittest import mock

import patch_differ_cli.mssql.stage1 as ms1
from patch_differ_cli import cli, pipeline


def _w(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data if isinstance(data, bytes) else data.encode())


class _Dirs(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory(prefix="pdff_nordb_")
        self.d = self._td.name
        self.p, self.f = os.path.join(self.d, "p"), os.path.join(self.d, "f")
        os.makedirs(self.p)
        os.makedirs(self.f)
        _w(os.path.join(self.p, "MPT_msdb_upgrade_sql_64"), "EXEC('x' + @n);\n")
        _w(os.path.join(self.f, "MPT_msdb_upgrade_sql_64"), "EXEC('x' + QUOTENAME(@n));\n")
        sql = b"EXEC(@cmd) -- SELECT name FROM sys.objects WHERE QUOTENAME(name) IS NOT NULL"
        _w(os.path.join(self.f, "ENG_RE_sqlscriptupgrade_dll_64"), b"MZ" + b"\x00" * 64 + sql)
        _w(os.path.join(self.p, "ENG_RE_sqlscriptupgrade_dll_64"), b"MZ" + b"\x00" * 64 + b"SELECT 1 FROM x")

    def tearDown(self):
        self._td.cleanup()

    def _run(self, has_prior, has_fixed):
        carve = mock.Mock(return_value={"sys.sp_x": ("CREATE PROC sys.sp_x AS 1", False)})

        def find(d):
            side_ok = has_prior if os.path.normcase(d) == os.path.normcase(self.p) else has_fixed
            return os.path.join(d, "mssqlsystemresource.mdf") if side_ok else None
        err = io.StringIO()
        with mock.patch.object(ms1, "_find_resource_mdf", find), \
                mock.patch.object(ms1, "_carve", carve), \
                mock.patch.object(ms1._AT, "load_attrib", lambda wd: []), \
                contextlib.redirect_stderr(err):
            r = ms1.run(self.p, self.f, self.d)
        return r, carve, err.getvalue()


class TestPartialStage1(_Dirs):
    def test_missing_on_fixed_side_still_diffs_readable_files(self):
        r, carve, err = self._run(True, False)
        self.assertTrue(r["available"])
        kinds = sorted(c.get("kind", "file") for c in r["readable_files"])
        self.assertEqual(kinds, ["file", "tsql"], "loose script AND embedded T-SQL are diffed")
        self.assertEqual(r["unavailable_parts"],
                         [{"part": "system objects", "reason":
                           "resource DB (mssqlsystemresource.mdf) not found on the fixed side"}])
        carve.assert_not_called()
        self.assertEqual((r["files"], r["added"], r["removed"]), ([], [], []),
                         "no fake all-added system objects from the side that has the DB")
        self.assertIn("WARNING: resource DB", err)
        self.assertIn("loose readable files and embedded T-SQL are still diffed", err)

    def test_missing_on_both_sides(self):
        r, _carve, _err = self._run(False, False)
        self.assertIn("prior and fixed sides", r["unavailable_parts"][0]["reason"])
        self.assertEqual(len(r["readable_files"]), 2)

    def test_present_on_both_sides_is_unchanged_and_silent(self):
        r, carve, err = self._run(True, True)
        self.assertEqual(r["unavailable_parts"], [])
        self.assertEqual(carve.call_count, 2)
        self.assertEqual(err, "")
        self.assertEqual(len(r["readable_files"]), 2)


class TestCliAndPipelineReporting(_Dirs):
    def test_cli_flags_unavailable_part_as_partial_failure(self):
        r, _c, _e = self._run(True, False)
        problems = cli._summarize_partial_failures({"stage1": r})
        self.assertEqual(len(problems), 1)
        stage, label, n = problems[0]
        self.assertEqual((stage, n), ("stage1", 1))
        self.assertIn("system objects unavailable", label)
        self.assertIn("fixed side", label)

    def test_cli_no_problem_when_everything_ran(self):
        r, _c, _e = self._run(True, True)
        self.assertEqual(cli._summarize_partial_failures({"stage1": r}), [])

    def test_pipeline_logs_partial_line(self):
        out = io.StringIO()
        find = lambda d: None                                   # no resource DB anywhere
        with mock.patch.object(ms1, "_find_resource_mdf", find), \
                mock.patch.object(ms1._AT, "load_attrib", lambda wd: []), \
                contextlib.redirect_stdout(out), contextlib.redirect_stderr(io.StringIO()):
            res = pipeline.run_pipeline("mssql", self.p, self.f, os.path.join(self.d, "out"),
                                        stages=("stage1",), verbose=True)
        self.assertTrue(res["stage1"]["available"])
        self.assertIn("PARTIAL: system objects not diffed", out.getvalue())
        self.assertNotIn("UNAVAILABLE", out.getvalue())


if __name__ == "__main__":
    unittest.main()
