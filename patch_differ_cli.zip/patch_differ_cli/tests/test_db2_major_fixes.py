"""db2_bugs.md Medium reliability fixes: DB2-4 (cap-dropped functions reported), DB2-8
(version-dir fallback deterministic, roots checked), DB2-9 (skipped noise components
reported and inspected for code), DB2-10 (OneDrive output warned), DB2-18 (.dynsym
fallback, every code section, extended numbering), DB2-19 (Ghidra script cache checked once,
before the workers), DB2-21 (bundled JDK/samples/docs listed, not analyzed) and DB2-22
(data-only ELF changes reported). Scratch files live in TemporaryDirectory()s only; no Ghidra
runs."""
import contextlib
import io
import json
import logging
import os
import struct
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from patch_differ_cli import _x86diff
from patch_differ_cli import cli
from patch_differ_cli import pipeline as pl
from patch_differ_cli import tool_paths as tp
from patch_differ_cli.db2 import _elf
from patch_differ_cli.db2 import acquire as A
from patch_differ_cli.db2 import stage2 as d2
from patch_differ_cli.db2 import triage as dt
from patch_differ_cli.tests.test_fallback_and_symbol_reporting import _mssql_run
from patch_differ_cli.tests.test_silent_loss_fixes import _tar_bytes

GLOBAL, LOCAL, IFUNC, OBJECT = 0x12, 0x02, 0x1A, 0x11
TEXT = (".text", 1, 0x6)                      # name, SHT_PROGBITS, SHF_ALLOC|SHF_EXECINSTR


def _mov(imm):
    return b"\xb8" + imm.to_bytes(4, "little") + b"\xc3"          # mov eax, imm; ret


def _elf64(sections, tables=(), extended=False, et=3):
    """ELF64 LE. sections: [(name, sh_type, flags, addr, data)]. tables: [(kind, symbols)]
    with kind "symtab" or "dynsym" and symbols [(name, info, section name | index, value,
    size)]; each table gets its own linked string table."""
    secs = [dict(name=n, type=t, flags=fl, addr=a, data=d, link=0, entsize=0)
            for n, t, fl, a, d in sections]
    for kind, syms in tables:
        sname, strname, typ = ((".symtab", ".strtab", 2) if kind == "symtab"
                               else (".dynsym", ".dynstr", 11))
        strtab, offs = b"\x00", {}
        for n, *_ in syms:
            if n not in offs:
                offs[n] = len(strtab)
                strtab += n.encode() + b"\x00"
        body = bytes(24)
        for n, info, sec, val, size in syms:
            shndx = ([s["name"] for s in secs].index(sec) + 1) if isinstance(sec, str) else sec
            body += struct.pack("<IBBHQQ", offs[n], info, 0, shndx, val, size)
        secs.append(dict(name=sname, type=typ, flags=0, addr=0, data=body,
                         link=len(secs) + 2, entsize=24))
        secs.append(dict(name=strname, type=3, flags=0, addr=0, data=strtab, link=0,
                         entsize=0))
    secs.append(dict(name=".shstrtab", type=3, flags=0, addr=0, data=b"", link=0, entsize=0))
    shstr = b"\x00"
    for s in secs:
        s["noff"] = len(shstr)
        shstr += s["name"].encode() + b"\x00"
    secs[-1]["data"] = shstr
    blob, off = b"", 64
    for s in secs:
        s["off"] = off + len(blob)
        blob += s["data"]
    shoff = 64 + len(blob)
    n_all, shstrndx = len(secs) + 1, len(secs)
    hdrs = struct.pack("<IIQQQQIIQQ", 0, 0, 0, 0, 0, n_all if extended else 0,
                       shstrndx if extended else 0, 0, 0, 0)
    for s in secs:
        hdrs += struct.pack("<IIQQQQIIQQ", s["noff"], s["type"], s["flags"], s["addr"],
                            s["off"], len(s["data"]), s["link"], 0, 1, s["entsize"])
    eh = bytearray(64)
    eh[0:4], eh[4], eh[5], eh[6] = b"\x7fELF", 2, 1, 1
    struct.pack_into("<HHI", eh, 0x10, et, 0x3E, 1)
    struct.pack_into("<Q", eh, 0x28, shoff)
    struct.pack_into("<HHHHHH", eh, 0x34, 64, 0, 0, 64,
                     0 if extended else n_all, 0xFFFF if extended else shstrndx)
    return bytes(eh) + blob + hdrs


def _write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    return path


def _lib(funcs, kind="symtab", extra=(), addr=0x1000, rodata=None, comment=None):
    """A .so with `funcs` [(name, info, code)] laid out in .text from `addr`."""
    text, syms = b"", []
    for name, info, code in funcs:
        syms.append((name, info, ".text", addr + len(text), len(code)))
        text += code
    sections = [(*TEXT, addr, text)]
    if rodata is not None:
        sections.append((".rodata", 1, 0x2, addr + 0x10000, rodata))
    if comment is not None:
        sections.append((".comment", 1, 0x0, 0, comment))
    tables = [(kind, syms)] if kind else []
    return _elf64(sections, tables + list(extra))


def _job(d, rel, use_bindiff=False):
    os.makedirs(os.path.join(d, "out"), exist_ok=True)
    return {"prior_dir": os.path.join(d, "p"), "fixed_dir": os.path.join(d, "f"), "rel": rel,
            "out": os.path.join(d, "out"), "attrib": [], "use_bindiff": use_bindiff,
            "decompile": False, "disassembled_dir": os.path.join(d, "out"),
            "vuln_label": "v", "fixed_label": "f", "run_ts": "t", "one_sided": None}


def _cards(r):
    return sorted((c["object"].split(" :: ")[-1], c["change"]) for c in r["readable"])


# --------------------------------------------------------------------------- DB2-18
class FuncMapSymbolsAndSectionsTests(unittest.TestCase):
    def _map(self, data, **kw):
        with tempfile.TemporaryDirectory() as d:
            return d2._func_map(_write(os.path.join(d, "x.so"), data), **kw)

    def test_stripped_library_falls_back_to_dynsym(self):
        m = self._map(_lib([("api", GLOBAL, _mov(1))], kind="dynsym"))
        self.assertEqual(dict(m), {"api": (0x1000, _mov(1))})
        self.assertEqual(m.symbol_source, "dynsym")

    def test_symtab_wins_over_dynsym(self):
        data = _lib([("api", GLOBAL, _mov(1)), ("helper", LOCAL, _mov(2))],
                    extra=[("dynsym", [("api", GLOBAL, ".text", 0x1000, 6)])])
        m = self._map(data)
        self.assertEqual(sorted(m), ["api", "helper"])
        self.assertEqual(m.symbol_source, "symtab")
        dyn = self._map(data, use_symtab=False)
        self.assertEqual(sorted(dyn), ["api"])
        self.assertEqual(dyn.symbol_source, "dynsym")

    def test_no_symbols_at_all_is_still_empty(self):
        self.assertEqual(dict(self._map(_lib([("api", GLOBAL, _mov(1))], kind=None))), {})

    def test_functions_outside_text_are_mapped(self):
        data = _elf64([(*TEXT, 0x1000, _mov(1)), (".text.hot", 1, 0x6, 0x2000, _mov(7)),
                       (".init", 1, 0x6, 0x3000, _mov(9))],
                      [("symtab", [("a", GLOBAL, ".text", 0x1000, 6),
                                   ("hot", GLOBAL, ".text.hot", 0x2000, 6),
                                   ("_init", GLOBAL, ".init", 0x3000, 6)])])
        m = self._map(data)
        self.assertEqual(m["hot"], (0x2000, _mov(7)))
        self.assertEqual(m["_init"], (0x3000, _mov(9)))

    def test_relocatable_sections_at_address_zero_keep_their_own_bytes(self):
        data = _elf64([(".text.a", 1, 0x6, 0, _mov(1)), (".text.b", 1, 0x6, 0, _mov(2))],
                      [("symtab", [("a", GLOBAL, ".text.a", 0, 6),
                                   ("b", GLOBAL, ".text.b", 0, 6)])], et=1)
        m = self._map(data)
        self.assertEqual(m["a"][1], _mov(1))
        self.assertEqual(m["b"][1], _mov(2), "not the first section's bytes")

    def test_ifunc_and_non_functions(self):
        data = _lib([("resolver", IFUNC, _mov(3)), ("table", OBJECT, b"\x00" * 8),
                     ("f", GLOBAL, _mov(4))])
        self.assertEqual(sorted(self._map(data)), ["f", "resolver"])

    def test_extended_section_numbering(self):
        data = _elf64([(*TEXT, 0x1000, _mov(5))],
                      [("symtab", [("f", GLOBAL, ".text", 0x1000, 6)])], extended=True)
        self.assertEqual(dict(self._map(data)), {"f": (0x1000, _mov(5))})

    def test_text_without_flags_still_counts(self):
        # some writers leave .text's flags unset; the old parser found it by name
        data = _elf64([(".text", 1, 0, 0x1000, _mov(6))],
                      [("symtab", [("f", GLOBAL, ".text", 0x1000, 6)])])
        self.assertEqual(dict(self._map(data)), {"f": (0x1000, _mov(6))})


class DynsymOnlyDiffTests(unittest.TestCase):
    def test_symtab_side_is_read_through_dynsym_when_the_other_side_is_stripped(self):
        rel = "lib/libx.so"
        prior = _lib([("api", GLOBAL, _mov(1)), ("helper", LOCAL, _mov(2))],
                     extra=[("dynsym", [("api", GLOBAL, ".text", 0x1000, 6)])])
        # stripped: no .symtab, and its .dynsym holds the exported function only
        fixed = _lib([("api", GLOBAL, _mov(3)), ("helper", LOCAL, _mov(2))], kind=None,
                     extra=[("dynsym", [("api", GLOBAL, ".text", 0x1000, 6)])])
        with tempfile.TemporaryDirectory() as d:
            _write(os.path.join(d, "p", rel), prior)
            _write(os.path.join(d, "f", rel), fixed)
            r = d2._process_file(_job(d, rel))
        self.assertTrue(r["ok"])
        self.assertEqual(_cards(r), [("api", "const")],
                         "helper is static: invisible on the stripped side, not 'removed'")
        self.assertEqual(r["dynsym_only"], {"rel": rel, "sides": ["prior", "fixed"]})

    def test_run_counts_and_reports_it_as_partial(self):
        rel = "lib/libx.so"
        with tempfile.TemporaryDirectory() as d:
            _write(os.path.join(d, "p", rel), _lib([("api", GLOBAL, _mov(1))], kind="dynsym"))
            _write(os.path.join(d, "f", rel), _lib([("api", GLOBAL, _mov(2))], kind="dynsym"))
            res = d2.run(os.path.join(d, "p"), os.path.join(d, "f"), os.path.join(d, "w"),
                         stage0={"code_changed": [{"name": rel}]})
        self.assertEqual(res["counts"]["dynsym_only"], 1)
        self.assertEqual(res["counts"]["failed"], 0, "analysed, not failed any more")
        problems = cli._summarize_partial_failures({"stage2": res})
        self.assertTrue(any("exported functions only" in w for _s, w, _n in problems))


# --------------------------------------------------------------------------- DB2-4
class CappedFunctionTests(unittest.TestCase):
    def _patches(self, module, cap):
        return [mock.patch.object(module, "_EMIT_CAP", cap),
                mock.patch.object(_x86diff, "fix_signature", return_value=(0, []))]

    def test_db2_counts_what_the_cap_drops(self):
        rel = "lib/libx.so"
        funcs = lambda k: [(f"f{i}", GLOBAL, _mov(i + k)) for i in range(4)]
        with tempfile.TemporaryDirectory() as d, contextlib.ExitStack() as st:
            for p in self._patches(d2, 1):
                st.enter_context(p)
            _write(os.path.join(d, "p", rel), _lib(funcs(0)))
            _write(os.path.join(d, "f", rel), _lib(funcs(100)))
            r = d2._process_file(_job(d, rel))
            self.assertEqual((len(r["readable"]), r["functions_capped"], r["funcs_total"]),
                             (1, 3, 4))
            res = d2.run(os.path.join(d, "p"), os.path.join(d, "f"), os.path.join(d, "w"),
                         stage0={"code_changed": [{"name": rel}]})
        self.assertEqual(res["counts"]["functions_capped"], 3)
        self.assertEqual(res["capped_functions"], [{"rel": rel, "count": 3}])

    def test_db2_nothing_capped_reports_zero(self):
        rel = "lib/libx.so"
        with tempfile.TemporaryDirectory() as d:
            _write(os.path.join(d, "p", rel), _lib([("f", GLOBAL, _mov(1))]))
            _write(os.path.join(d, "f", rel), _lib([("f", GLOBAL, _mov(2))]))
            r = d2._process_file(_job(d, rel))
        self.assertEqual(r["functions_capped"], 0)

    def test_mssql_counts_what_the_cap_drops(self):
        from patch_differ_cli.mssql import stage2 as ms2
        with contextlib.ExitStack() as st:
            for p in self._patches(ms2, 0):
                st.enter_context(p)
            r = _mssql_run(symbolized=("prior", "fixed"))
        self.assertEqual((r["readable"], r["functions_capped"]), ([], 1))

    def test_cli_warns_but_it_is_not_a_failure(self):
        res = {"stage2": {"counts": {"functions_capped": 7},
                          "capped_functions": [{"rel": "a", "count": 7}]}}
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            cli._warn_decompile_shortfalls(res)
        self.assertIn("7 ordinary changed function(s) in 1 binary(ies) were not written",
                      err.getvalue())
        self.assertEqual(cli._summarize_partial_failures(res), [])


# --------------------------------------------------------------------------- DB2-21 / 22
class TriageNoiseAndDataTests(unittest.TestCase):
    def _trees(self, d):
        p, f = os.path.join(d, "p"), os.path.join(d, "f")
        code = lambda k: _lib([("f", GLOBAL, _mov(k))])
        # bundled JDK: a changed native lib, a changed jar, an unchanged file, one added
        _write(os.path.join(p, "java/jdk64/lib/libjvm.so"), code(1))
        _write(os.path.join(f, "java/jdk64/lib/libjvm.so"), code(2))
        _write(os.path.join(p, "java/jre/lib/rt.jar"), b"jar-1")
        _write(os.path.join(f, "java/jre/lib/rt.jar"), b"jar-2")
        _write(os.path.join(p, "samples/same.txt"), b"s")
        _write(os.path.join(f, "samples/same.txt"), b"s")
        _write(os.path.join(f, "doc/new.html"), b"n")
        # real product code: code change, data-table change, version string, rebuild only
        _write(os.path.join(p, "lib64/libcode.so"), code(1))
        _write(os.path.join(f, "lib64/libcode.so"), code(2))
        _write(os.path.join(p, "lib64/libtab.so"), _lib([("f", GLOBAL, _mov(1))],
                                                        rodata=b"\x10\x00\x00\x00ok"))
        _write(os.path.join(f, "lib64/libtab.so"), _lib([("f", GLOBAL, _mov(1))],
                                                        rodata=b"\x20\x00\x00\x00ok"))
        _write(os.path.join(p, "lib64/libver.so"), _lib([("f", GLOBAL, _mov(1))],
                                                        rodata=b"v11.5.9.0\x00"))
        _write(os.path.join(f, "lib64/libver.so"), _lib([("f", GLOBAL, _mov(1))],
                                                        rodata=b"v11.5.9.1\x00"))
        _write(os.path.join(p, "lib64/libreb.so"), _lib([("f", GLOBAL, _mov(1))],
                                                        comment=b"GCC 8"))
        _write(os.path.join(f, "lib64/libreb.so"), _lib([("f", GLOBAL, _mov(1))],
                                                        comment=b"GCC 9"))
        return p, f

    def _check(self, r):
        self.assertEqual([e["name"] for e in r["code_changed"]], ["lib64/libcode.so"],
                         "the JDK's libjvm.so is not sent to Stage 2")
        noise = {e["name"]: (e["kind"], e["change"]) for e in r["noise_changed"]}
        self.assertEqual(noise, {"java/jdk64/lib/libjvm.so": ("native", "changed"),
                                 "java/jre/lib/rt.jar": ("dependency", "changed"),
                                 "doc/new.html": ("content", "added")})
        data = [(e["name"], e["strings_only"], e["data_bytes_changed"])
                for e in r["data_changed"]]
        self.assertEqual(data, [("lib64/libtab.so", False, 1), ("lib64/libver.so", True, 1)],
                         "a table change ranks before a version string")
        self.assertEqual(r["rebuild_only"], ["lib64/libreb.so"], ".comment is not data")
        self.assertEqual((r["counts"]["noise_changed"], r["counts"]["data_changed"]), (3, 2))
        self.assertNotIn("java/jre/lib/rt.jar", [e["name"] for e in r["content_changed"]])

    def test_full_walk(self):
        with tempfile.TemporaryDirectory() as d:
            p, f = self._trees(d)
            r = dt.run(p, f, os.path.join(d, "w"))
        self._check(r)
        self.assertEqual(r["counts"]["identical"], 1)            # samples/same.txt

    def test_manifest_path(self):
        with tempfile.TemporaryDirectory() as d:
            p, f = self._trees(d)
            manifest = {"identical": 1, "added": ["doc/new.html"], "removed": [],
                        "changed": ["java/jdk64/lib/libjvm.so", "java/jre/lib/rt.jar",
                                    "lib64/libcode.so", "lib64/libtab.so", "lib64/libver.so",
                                    "lib64/libreb.so"]}
            os.makedirs(os.path.join(d, "w"))
            r = dt._from_manifest(manifest, p, f, os.path.join(d, "w"))
        self._check(r)

    def test_cli_notes(self):
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            cli._warn_decompile_shortfalls({"triage": {"counts": {"noise_changed": 3,
                                                                  "data_changed": 2}}})
        self.assertIn("NOTE: [triage] 3 changed file(s) under the bundled JDK", err.getvalue())
        self.assertIn("NOTE: [triage] 2 ELF file(s) changed only in their data", err.getvalue())


class DataSectionDiffTests(unittest.TestCase):
    def _diff(self, a, b):
        with tempfile.TemporaryDirectory() as d:
            return _elf.data_section_diff(_write(os.path.join(d, "a"), a),
                                          _write(os.path.join(d, "b"), b))

    def test_size_change_is_not_strings_only(self):
        r = self._diff(_lib([("f", GLOBAL, _mov(1))], rodata=b"abc\x00"),
                       _lib([("f", GLOBAL, _mov(1))], rodata=b"abcd\x00"))
        self.assertFalse(r["strings_only"])
        self.assertEqual(r["data_sections"][0]["bytes_changed"], None)

    def test_section_added(self):
        r = self._diff(_lib([("f", GLOBAL, _mov(1))]),
                       _lib([("f", GLOBAL, _mov(1))], rodata=b"x"))
        self.assertEqual(r["data_sections"], [{"name": ".rodata", "prior_size": None,
                                               "fixed_size": 1, "bytes_changed": None}])

    def test_identical_data(self):
        self.assertIsNone(self._diff(_lib([("f", GLOBAL, _mov(1))], rodata=b"x"),
                                     _lib([("f", GLOBAL, _mov(1))], rodata=b"x")))

    def test_large_section_with_scattered_changes(self):
        big = bytearray(3 << 20)
        other = bytearray(big)
        other[5] = other[(2 << 20) + 7] = 0x41                    # 'A' over NUL: text-like
        r = self._diff(_lib([("f", GLOBAL, _mov(1))], rodata=bytes(big)),
                       _lib([("f", GLOBAL, _mov(1))], rodata=bytes(other)))
        self.assertEqual((r["data_bytes_changed"], r["strings_only"]), (2, True))


# --------------------------------------------------------------------------- DB2-8
class VersionDirTests(unittest.TestCase):
    def test_shallowest_libdb2e_wins_whatever_the_names(self):
        with tempfile.TemporaryDirectory() as d:
            _write(os.path.join(d, "aaa", "deep", "x", "lib64", "libdb2e.so.1"), b"1")
            _write(os.path.join(d, "zzz", "lib64", "libdb2e.so.1"), b"1")
            got = A._find_version_dir(d)
        self.assertTrue(got.endswith("zzz"), got)

    def test_tie_is_deterministic_and_logged(self):
        with tempfile.TemporaryDirectory() as d:
            for top in ("b", "a"):
                _write(os.path.join(d, top, "lib64", "libdb2e.so.1"), b"1")
            with self.assertLogs(A._log.name, logging.WARNING) as cm:
                got = A._find_version_dir(d)
        self.assertTrue(got.endswith(os.sep + "a"), got)
        self.assertIn("same depth in 2 places", cm.output[0])

    def test_primary_layout_still_wins(self):
        with tempfile.TemporaryDirectory() as d:
            os.makedirs(os.path.join(d, "opt", "ibm", "db2", "V11.5"))
            _write(os.path.join(d, "lib64", "libdb2e.so.1"), b"1")
            self.assertTrue(A._find_version_dir(d).endswith("V11.5"))

    def test_roots_with_little_in_common_are_warned(self):
        with tempfile.TemporaryDirectory() as d:
            v, f = os.path.join(d, "v"), os.path.join(d, "f")
            for x in ("bin", "lib64", "adm", "cfg"):
                os.makedirs(os.path.join(v, x))
            for x in ("libdb2e.so.1", "libdb2.so.1"):
                _write(os.path.join(f, x), b"1")
            logs, err = [], io.StringIO()
            with contextlib.redirect_stderr(err):
                pl._check_db2_roots(v, f, logs.append)
            self.assertIn("little in common", err.getvalue())
            self.assertIn(v, logs[0])
            err = io.StringIO()
            with contextlib.redirect_stderr(err):
                pl._check_db2_roots(v, v, logs.append)
            self.assertEqual(err.getvalue(), "")


# --------------------------------------------------------------------------- DB2-9
def _component(members):
    return _tar_bytes(members, gz=True)


def _fixpack(noise=True):
    m = [("ESE/FILES/DB2_ESE_SERVER_11.5.9_linuxx64.tar.gz",
          _component([("lib64/libdb2e.so.1", b"E"), ("bin/db2", b"B")]))]
    if noise:
        m += [("ESE/FILES/DB2_SAMPLES_11.5.9_linuxx64.tar.gz",
               _component([("samples/c/x.c", b"c"), ("lib64/libsample.so", b"S")])),
              ("ESE/FILES/DB2_PRODUCT_MESSAGES_EN_11.5.9_linuxx64.tar.gz",
               _component([("msg/en_US/db2.mo", b"m")]))]
    return _tar_bytes(m, gz=True)


class SkippedComponentTests(unittest.TestCase):
    def _acquire(self, out, archive):
        drop = Path(out) / "acquire" / "vuln" / "drop"
        drop.mkdir(parents=True, exist_ok=True)
        for old in drop.iterdir():
            old.unlink()
        (drop / "fp.tar.gz").write_bytes(archive)
        err = io.StringIO()
        with contextlib.redirect_stderr(err), \
                mock.patch.object(A, "_LAYER_CACHE", A._LAYER_CACHE):
            got = pl._acquire_db2(Path(out), "manual:v11.5.9-1", None, False,
                                  sides=("vuln",))
        return got["vuln"], err.getvalue()

    def test_reported_with_code_found_and_cleared_by_a_clean_extraction(self):
        with tempfile.TemporaryDirectory() as d:
            root, err = self._acquire(d, _fixpack())
            self.assertTrue(os.path.isfile(os.path.join(root, "lib64", "libdb2e.so.1")))
            self.assertFalse(os.path.exists(os.path.join(root, "lib64", "libsample.so")))
            rec = json.loads((Path(d) / "acquire" / "vuln" / A.SKIPPED_COMPONENTS)
                             .read_text(encoding="utf-8"))
            self.assertEqual([(c["name"].rsplit("/", 1)[-1], c["code_members"]) for c in rec],
                             [("DB2_PRODUCT_MESSAGES_EN_11.5.9_linuxx64.tar.gz", 0),
                              ("DB2_SAMPLES_11.5.9_linuxx64.tar.gz", 1)])
            self.assertIn("NOTE: DB2 vuln build: 2 install component(s) skipped", err)
            self.assertIn("WARNING: DB2 vuln build: 1 skipped component(s) contain code-like",
                          err)
            self.assertIn("lib64/libsample.so", err)
            _root, err = self._acquire(d, _fixpack(noise=False))
            self.assertNotIn("skipped", err)
            self.assertFalse((Path(d) / "acquire" / "vuln" / A.SKIPPED_COMPONENTS).exists())

    def test_corrupt_skipped_component_does_not_fail_the_extraction(self):
        good = _component([("lib64/libdb2e.so.1", b"E")])
        bad = _component([("x", b"y" * 4096)])
        bad = bad[:20] + bytes(b ^ 0xFF for b in bad[20:60]) + bad[60:]   # corrupt deflate data
        archive = _tar_bytes([("ESE/FILES/DB2_ESE_SERVER_11.5.9_linuxx64.tar.gz", good),
                              ("ESE/FILES/DB2_SAMPLES_11.5.9_linuxx64.tar.gz", bad)], gz=True)
        with tempfile.TemporaryDirectory() as d:
            root, err = self._acquire(d, archive)
            self.assertTrue(os.path.isfile(os.path.join(root, "lib64", "libdb2e.so.1")))
        self.assertIn("1 skipped component(s) could not be inspected", err)

    @unittest.skipUnless(os.path.isfile(tp.sevenzip() or ""), "bundled 7-Zip not present")
    def test_seven_zip_path_records_them_too(self):
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(A, "_acquire_manual_tarfile", side_effect=OSError("boom")), \
                self.assertLogs(A._log.name, logging.WARNING):
            _root, err = self._acquire(d, _fixpack())
        self.assertIn("1 skipped component(s) contain code-like", err)


# --------------------------------------------------------------------------- DB2-10
class OneDriveTests(unittest.TestCase):
    def test_output_inside_onedrive_is_warned(self):
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.dict(os.environ, {"OneDrive": d, "OneDriveConsumer": "",
                                             "OneDriveCommercial": ""}):
            self.assertEqual(pl._synced_folder(os.path.join(d, "runs", "db2")), d)
            self.assertEqual(pl._synced_folder(d), d)
            self.assertIsNone(pl._synced_folder(d + "x"))
            err = io.StringIO()
            with contextlib.redirect_stderr(err):
                pl._warn_if_synced(os.path.join(d, "runs"))
            self.assertIn("is inside OneDrive", err.getvalue())

    def test_no_onedrive(self):
        with mock.patch.dict(os.environ, {"OneDrive": "", "OneDriveConsumer": "",
                                          "OneDriveCommercial": ""}):
            self.assertIsNone(pl._synced_folder(r"C:\pdiff\run"))


# --------------------------------------------------------------------------- DB2-19
class ScriptCacheOnceTests(unittest.TestCase):
    def setUp(self):
        td = tempfile.TemporaryDirectory()
        self.addCleanup(td.cleanup)
        self.settings = os.path.join(td.name, ".ghidra_x")
        self.osgi = os.path.join(self.settings, "osgi")
        _write(os.path.join(self.settings, "java_home.save"), b"C:\\old-jdk")
        _write(os.path.join(self.osgi, "bundle"), b"stale")
        for target, value in (("_ghidra_user_settings_dir", self.settings),
                              ("java_home", os.path.join(td.name, "new-jdk"))):
            p = mock.patch.object(tp, target, return_value=value)
            p.start()
            self.addCleanup(p.stop)
        p = mock.patch.dict(os.environ, {}, clear=False)
        p.start()
        self.addCleanup(p.stop)
        os.environ.pop(tp._CACHE_CHECKED_ENV, None)

    def test_cleared_once_and_never_by_a_worker(self):
        with contextlib.redirect_stderr(io.StringIO()):
            with tp.ghidra_script_cache_checked(True):
                self.assertFalse(os.path.exists(self.osgi), "cleared before the workers")
                self.assertEqual(os.environ[tp._CACHE_CHECKED_ENV], tp.java_home())
                _write(os.path.join(self.osgi, "bundle"), b"being compiled by a worker")
                tp.clear_stale_ghidra_script_cache()               # what each worker calls
                self.assertTrue(os.path.exists(self.osgi), "a worker must not delete it")
            self.assertNotIn(tp._CACHE_CHECKED_ENV, os.environ)
            tp.clear_stale_ghidra_script_cache()                   # outside a run: as before
        self.assertFalse(os.path.exists(self.osgi))

    def test_disabled_does_nothing(self):
        with tp.ghidra_script_cache_checked(False):
            self.assertTrue(os.path.exists(self.osgi))
            self.assertNotIn(tp._CACHE_CHECKED_ENV, os.environ)

    def test_another_jdk_is_still_checked(self):
        os.environ[tp._CACHE_CHECKED_ENV] = "C:\\some-other-jdk"
        with contextlib.redirect_stderr(io.StringIO()):
            tp.clear_stale_ghidra_script_cache()
        self.assertFalse(os.path.exists(self.osgi))

    def test_pipeline_runs_stage2_inside_the_check(self):
        seen, calls = {}, []

        class FakeStage2:
            @staticmethod
            def run(*a, **k):
                seen["marker"] = os.environ.get(tp._CACHE_CHECKED_ENV)
                return {"counts": {}, "readable_files": []}

        real = pl._import
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(pl, "_import",
                                  lambda n: FakeStage2 if n.endswith("stage2") else real(n)), \
                mock.patch.object(tp, "clear_stale_ghidra_script_cache",
                                  lambda: calls.append(1)):
            for s in ("v", "f"):
                _write(os.path.join(d, s, "lib64", "libdb2e.so.1"), b"1")
            pl.run_pipeline("db2", vuln_dir=os.path.join(d, "v"), fixed_dir=os.path.join(d, "f"),
                            out_dir=os.path.join(d, "out"), stages={"stage2"}, verbose=False,
                            use_bindiff=True)
        self.assertEqual(seen["marker"], tp.java_home())
        self.assertEqual(calls, [1])
        self.assertNotIn(tp._CACHE_CHECKED_ENV, os.environ)


if __name__ == "__main__":
    unittest.main()
