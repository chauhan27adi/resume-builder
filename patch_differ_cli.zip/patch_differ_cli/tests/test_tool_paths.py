"""Unit tests for tool_paths.py — the single source of truth for every bundled
third-party tool path (see that module's docstring). Guards two properties that must
hold for every tool: (1) an explicit env var always wins, and (2) there is NO OS-wide
fallback any more — a missing bundled copy must resolve to None/a not-found signal,
never to a guessed system path."""
import os
import unittest
from unittest import mock

from patch_differ_cli import tool_paths as tp


class TestEnvVarOverridesWin(unittest.TestCase):
    def test_java_home_prefers_the_tool_specific_override(self):
        env = {"PATCHDIFF_JAVA_HOME": r"C:\explicit\jdk", "JAVA_HOME": r"C:\system\jdk-26"}
        with mock.patch.dict(os.environ, env, clear=False):
            self.assertEqual(tp.java_home(), r"C:\explicit\jdk")

    def test_java_exe_uses_overridden_java_home(self):
        with mock.patch.dict(os.environ, {"PATCHDIFF_JAVA_HOME": r"C:\explicit\jdk"},
                             clear=False):
            self.assertEqual(tp.java_exe(),
                             os.path.join(r"C:\explicit\jdk", "bin", "java.exe"))

    def test_system_java_home_does_not_override_the_bundled_jdk(self):        # bugs.md #56
        with mock.patch.dict(os.environ, {"JAVA_HOME": r"C:\system\jdk-26",
                                          "PATCHDIFF_JAVA_HOME": ""}, clear=False), \
                mock.patch.object(tp, "_jdk_present", lambda home: home == tp.JDK_DIR):
            self.assertEqual(tp.java_home(), tp.JDK_DIR)

    def test_system_java_home_is_the_fallback_without_a_bundled_jdk(self):
        with mock.patch.dict(os.environ, {"JAVA_HOME": r"C:\system\jdk",
                                          "PATCHDIFF_JAVA_HOME": ""}, clear=False), \
                mock.patch.object(tp, "_jdk_present", lambda home: False):
            self.assertEqual(tp.java_home(), r"C:\system\jdk")

    def test_ghidra_home_prefers_env_var(self):
        with mock.patch.dict(os.environ, {"GHIDRA_HOME": r"C:\explicit\ghidra"}, clear=False):
            self.assertEqual(tp.ghidra_home(), r"C:\explicit\ghidra")

    def test_sevenzip_prefers_env_var(self):
        with mock.patch.dict(os.environ, {"SEVENZIP": r"C:\explicit\7z.exe"}, clear=False):
            self.assertEqual(tp.sevenzip(), r"C:\explicit\7z.exe")

    def test_bindiff_path_env_var_wins_when_file_exists(self):
        import tempfile
        with tempfile.NamedTemporaryFile(suffix=".exe", delete=False) as f:
            fake_exe = f.name
        try:
            with mock.patch.dict(os.environ, {"BINDIFF_PATH": fake_exe}, clear=False):
                self.assertEqual(tp.locate_differ(), fake_exe)
        finally:
            os.remove(fake_exe)

    def test_cfr_jar_env_var_wins_when_file_exists(self):
        import tempfile
        with tempfile.NamedTemporaryFile(suffix=".jar", delete=False) as f:
            fake_jar = f.name
        try:
            with mock.patch.dict(os.environ, {"CVE_PATCHDIFF_CFR": fake_jar}, clear=False):
                self.assertEqual(tp.cfr_jar(), fake_jar)
        finally:
            os.remove(fake_jar)


class TestNoOsWideFallback(unittest.TestCase):
    """Regression guard: these resolvers must return None (or a plain non-existent path,
    for the two "home directory" getters that have no downstream existence check of
    their own) when neither the env var nor the bundled copy exists — never silently
    fall back to a guessed C:\\Program Files\\... / C:\\Tools\\... location. This is the
    exact bug class fixed earlier in this project; these tests keep it from regressing."""

    def _clear_relevant_env(self):
        return mock.patch.dict(os.environ, {
            "JAVA_HOME": "", "GHIDRA_HOME": "", "BINDIFF_PATH": "",
            "SEVENZIP": "", "CVE_PATCHDIFF_CFR": "",
        }, clear=False)

    def test_locate_differ_returns_none_when_bundled_and_path_both_absent(self):
        nonexistent = os.path.join(tp.TOOLS_DIR, "__does_not_exist__", "bin")
        with self._clear_relevant_env(), \
             mock.patch.object(tp, "BINDIFF_BIN", nonexistent), \
             mock.patch("shutil.which", return_value=None):
            self.assertIsNone(tp.locate_differ())

    def test_cfr_jar_returns_none_when_bundled_jar_absent(self):
        nonexistent = os.path.join(tp.TOOLS_DIR, "__does_not_exist__.jar")
        with self._clear_relevant_env(), mock.patch.object(tp, "CFR_JAR", nonexistent):
            self.assertIsNone(tp.cfr_jar())

    def test_analyze_headless_returns_none_when_bundled_ghidra_absent(self):
        nonexistent = os.path.join(tp.TOOLS_DIR, "__does_not_exist_ghidra__")
        with self._clear_relevant_env(), mock.patch.object(tp, "GHIDRA_DIR", nonexistent):
            self.assertIsNone(tp.analyze_headless())

    def test_locate_binexport_script_returns_none_when_ghidra_absent(self):
        nonexistent = os.path.join(tp.TOOLS_DIR, "__does_not_exist_ghidra__")
        with self._clear_relevant_env(), mock.patch.object(tp, "GHIDRA_DIR", nonexistent):
            self.assertIsNone(tp.locate_binexport_script())

    def test_locate_binexport_accepts_jar_only_install(self):      # bug.md DB2-T1-8
        import tempfile

        def _mk(home, rel):
            p = os.path.join(home, "Ghidra", "Extensions", "BinExport", *rel)
            os.makedirs(os.path.dirname(p), exist_ok=True)
            open(p, "wb").write(b"x")
            return p

        with self._clear_relevant_env():
            # sample script present -> returns it (unchanged behaviour)
            with tempfile.TemporaryDirectory() as d:
                s = _mk(d, ("ghidra_scripts", "BinExport.java"))
                self.assertEqual(tp.locate_binexport_script(d), s)
            # JAR-only install (no sample script) -> accepted via the BinExport lib jar
            with tempfile.TemporaryDirectory() as d:
                j = _mk(d, ("lib", "BinExport.jar"))
                self.assertEqual(tp.locate_binexport_script(d), j)
            # a lib with only an unrelated jar (no BinExport classes) -> still not installed
            with tempfile.TemporaryDirectory() as d:
                _mk(d, ("lib", "protobuf-java-3.25.1.jar"))
                self.assertIsNone(tp.locate_binexport_script(d))


class TestBundledPathsPointInsideToolsDir(unittest.TestCase):
    """Sanity check that every constant is actually namespaced under TOOLS_DIR, not some
    path outside the project (a basic typo/regression guard for the constants table)."""

    def test_all_bundled_constants_are_under_tools_dir(self):
        for value in (tp.JDK_DIR, tp.GHIDRA_DIR, tp.BINDIFF_BIN, tp.SEVENZIP_EXE, tp.CFR_JAR):
            self.assertTrue(
                os.path.normpath(value).startswith(os.path.normpath(tp.TOOLS_DIR)),
                f"{value} is not under TOOLS_DIR ({tp.TOOLS_DIR})")


class TestGhidraNotConfiguredIsShared(unittest.TestCase):
    def test_bindiff_and_decompile_use_the_identical_class(self):
        from patch_differ_cli import _bindiff as bd
        from patch_differ_cli import _decompile as dc
        self.assertIs(bd.GhidraNotConfigured, tp.GhidraNotConfigured)
        self.assertIs(dc.GhidraNotConfigured, tp.GhidraNotConfigured)


if __name__ == "__main__":
    unittest.main()
