"""Unit tests for _attribution.py — the shared CVE name/CWE attribution + confidence
resolution used by all three backends' Stage 2. Pure logic, no external tools required."""
import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path

from patch_differ_cli import _attribution as A


class TestBuildAttribAndAttribute(unittest.TestCase):
    def test_no_attrib_returns_none(self):
        self.assertEqual(A.attribute("anything", []), (None, None, None))

    def test_unrelated_name_does_not_match(self):
        attrib = A.build_attrib([("CVE-2024-0001", "a buffer overflow issue", "Engine",
                                  "", "CWE-787")])
        self.assertEqual(A.attribute("DoUnrelatedThing", attrib), (None, None, None))

    def test_single_primitive_hit_is_medium_confidence(self):
        # CWE-787 primitives include "boundscheck" — ONE primitive hit alone scores 3,
        # which is below the "high" threshold (needs nspec>=2, a second primitive, or
        # two independent generic-word overlaps — CRIT-NT-7), so it lands
        # at 'med' via the nprim>=1 fallback, not 'high'.
        attrib = A.build_attrib([("CVE-2024-0001", "a buffer overflow issue", "Engine",
                                  "", "CWE-787")])
        cve, why, conf = A.attribute("DoBoundsCheckOnRow", attrib)
        self.assertEqual(cve, "CVE-2024-0001")
        self.assertEqual(conf, "med")

    def test_two_primitive_hits_are_high_confidence(self):
        # "StackBufOverflowCheck" hits BOTH "stackbuf" and "overflow" from CWE-121's
        # primitive set -> two non-broad primitives -> nspec>=2 -> 'high'.
        attrib = A.build_attrib([("CVE-2024-0002", "a stack buffer overflow", "Engine",
                                  "", "CWE-121")])
        cve, why, conf = A.attribute("StackBufOverflowCheck", attrib)
        self.assertEqual(cve, "CVE-2024-0002")
        self.assertEqual(conf, "high")

    def test_broad_family_only_hit_is_low_confidence(self):
        # CWE-269's family set includes "auth" — a bare family hit with no primitive
        # and no generic token match is the weakest signal: 'low'.
        attrib = A.build_attrib([("CVE-2024-0003", "an elevation of privilege issue",
                                  "Engine", "", "CWE-269")])
        cve, why, conf = A.attribute("SomeAuthRelatedHelper", attrib)
        self.assertEqual(cve, "CVE-2024-0003")
        self.assertEqual(conf, "low")

    def test_stop_words_alone_never_match(self):
        # Every token in the description is a generic _STOP word, so nothing should be
        # picked up as a "generic" token hit.
        attrib = A.build_attrib([("CVE-2024-0004",
                                  "could allow remote code execution", "Server",
                                  "", "")])
        self.assertEqual(A.attribute("AnyOrdinaryFunction", attrib), (None, None, None))

    def test_thirdparty_cve_never_attributes_to_native_symbols(self):
        attrib = A.build_attrib([("CVE-2024-0005", "a log4j deserialization issue",
                                  "bundled", "log4j-core", "CWE-502")])
        # Even a name that would otherwise hit CWE-502's "deserial" primitive must be
        # excluded — Stage-1 dep-diff owns third-party component CVEs, not native symbols.
        self.assertEqual(A.attribute("DeserializeObject", attrib), (None, None, None))

    def test_tie_break_is_stable_by_cve_id(self):
        # Two equally-scoring CVEs on the same name must always resolve to the
        # lexicographically-smaller CVE id, regardless of list order.
        rows = [("CVE-2024-0099", "an authorization issue", "Engine", "", "CWE-285"),
                ("CVE-2024-0010", "an authorization issue", "Engine", "", "CWE-285")]
        attrib_a = A.build_attrib(rows)
        attrib_b = A.build_attrib(list(reversed(rows)))
        cve_a, _, _ = A.attribute("CheckAuthorizForUser", attrib_a)
        cve_b, _, _ = A.attribute("CheckAuthorizForUser", attrib_b)
        self.assertEqual(cve_a, "CVE-2024-0010")
        self.assertEqual(cve_b, "CVE-2024-0010")


class TestHighConfidenceNeedsIndependentCorroboration(unittest.TestCase):
    """CRIT-NT-7: 'high' is asserted as a CVE claim by resolve() with NO independent
    corroboration, yet one specific primitive plus ONE incidental generic word shared between
    the advisory text and an unrelated function name used to pool to score 4 and reach it —
    the same single-primitive evidence test_single_primitive_hit_is_medium_confidence rates
    only 'med'."""

    def _attr(self, desc, cwe, name):
        attrib = A.build_attrib([("CVE-2024-0002", desc, "Engine", "", cwe)])
        return A.attribute(name, attrib)

    def test_lone_primitive_baseline_is_med(self):
        self.assertEqual(self._attr("a buffer overflow issue", "CWE-787",
                                    "DoBoundsCheckOnRow")[2], "med")

    def test_one_incidental_generic_word_does_not_promote_to_high(self):
        cve, why, conf = self._attr("a memory corruption issue", "CWE-787",
                                    "DoBoundsCheckMemoryScan")
        self.assertEqual(cve, "CVE-2024-0002")
        self.assertIn("memory", why)           # the incidental word really did match
        self.assertEqual(conf, "med")

    def test_incidental_overlap_is_not_asserted_without_corroboration(self):
        _, _, conf = self._attr("a memory corruption issue", "CWE-787",
                                "DoBoundsCheckMemoryScan")
        self.assertEqual(A.resolve(conf, False), ("low", False))

    def test_two_independent_generic_overlaps_do_promote(self):
        _, why, conf = self._attr("a memory corruption issue", "CWE-787",
                                  "DoBoundsCheckMemoryCorruptionScan")
        self.assertIn("memory", why)
        self.assertIn("corruption", why)
        self.assertEqual(conf, "high")

    def test_specific_plus_broad_primitive_is_still_high(self):
        # CWE-285: "transferown" is specific, "authoriz" is a broad stem — two CWE-derived
        # primitives in the name is independent corroboration and must stay 'high'.
        self.assertEqual(self._attr("an authorization issue", "CWE-285",
                                    "AuthorizeTransferOwnership")[2], "high")

    def test_component_label_match_is_strong_corroboration(self):
        # The caller's explicit component ("Linked Server") is a curated subsystem label,
        # not free-text prose: a specific primitive + a function-name match on it stays 'high'.
        attrib = A.build_attrib([("CVE-2026-32167", "elevation of privilege via linked server",
                                  "Linked Server", "", "CWE-269")])
        self.assertEqual(A.attribute("LinkedOpenRowsetSetup", attrib)[2], "high")

    def test_description_only_word_is_not_treated_as_component_label(self):
        # Same advisory text but "linked" appears only in the description, not the component.
        attrib = A.build_attrib([("CVE-2026-32167", "elevation of privilege via linked server",
                                  "Engine", "", "CWE-269")])
        self.assertEqual(A.attribute("LinkedOpenRowsetSetup", attrib)[2], "med")

    def test_attrib_rows_without_comp_tokens_still_work(self):
        # Rows pickled/built before comp_tokens existed must not KeyError.
        attrib = A.build_attrib([("CVE-2024-0002", "a memory corruption issue", "Engine",
                                  "", "CWE-787")])
        for a in attrib:
            a.pop("comp_tokens", None)
        self.assertEqual(A.attribute("DoBoundsCheckMemoryScan", attrib)[2], "med")

    def test_two_specific_primitives_are_still_high(self):
        self.assertEqual(self._attr("a stack buffer overflow", "CWE-121",
                                    "StackBufOverflowCheck")[2], "high")


class TestResolve(unittest.TestCase):
    def test_no_name_match_is_unattributed(self):
        self.assertEqual(A.resolve(None, True), (None, False))
        self.assertEqual(A.resolve(None, False), (None, False))

    def test_high_confidence_always_attributed(self):
        self.assertEqual(A.resolve("high", True), ("high", True))
        self.assertEqual(A.resolve("high", False), ("med", True))

    def test_med_confidence_needs_corroboration_to_attribute(self):
        self.assertEqual(A.resolve("med", True), ("med", True))
        self.assertEqual(A.resolve("med", False), ("low", False))

    def test_low_confidence_needs_corroboration_to_attribute(self):
        self.assertEqual(A.resolve("low", True), ("med", True))
        self.assertEqual(A.resolve("low", False), ("low", False))


class TestLoadAttrib(unittest.TestCase):
    def test_missing_workdir_files_return_empty_list(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(A.load_attrib(d), [])

    def test_cves_json_takes_priority_over_meta_json(self):
        import json
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as d:
            wd = Path(d)
            (wd / "cves.json").write_text(json.dumps([
                {"cve_id": "CVE-2024-9999", "cve_desc": "a buffer overflow",
                 "component": "Engine", "cwe_id": "CWE-787"}]), encoding="utf-8")
            (wd / "meta.json").write_text(json.dumps(
                {"tracked_cves": "CVE-2024-0000"}), encoding="utf-8")
            attrib = A.load_attrib(d)
            self.assertEqual([a["cve"] for a in attrib], ["CVE-2024-9999"])


class TestBareCveIdFallback(unittest.TestCase):
    """Regression tests for CRIT-NT-4: bare CVE IDs from meta.json's tracked_cves (no
    cves.json, no CWE/description) have no text to derive primitives/families/generic
    tokens from, so build_attrib() can never produce a usable attrib row for them —
    attribute() always returns (None, None, None) regardless of how obviously a function
    name matches the vulnerability's subsystem, with the ENTIRE attribution subsystem
    silently doing nothing for that run. The fix keeps this (unavoidable, given zero
    textual signal) no-op behavior but makes it loud: build_attrib() now prints a WARNING
    to stderr naming the affected CVE IDs instead of silently dropping them with no
    indication anything was skipped. See TestBuildAttribStarvationWarning below for the
    generalized case (this same silent drop is also reachable via a sparse --cves.json
    record, not just meta.json's bare-ID tier)."""

    def test_bare_cve_id_produces_no_attribution_signal_but_warns(self):
        with tempfile.TemporaryDirectory() as d:
            wd = Path(d)
            (wd / "meta.json").write_text(
                json.dumps({"tracked_cves": "CVE-2024-99999"}), encoding="utf-8")
            buf = io.StringIO()
            with contextlib.redirect_stderr(buf):
                attrib = A.load_attrib(d)
        self.assertEqual(attrib, [], "a bare CVE ID genuinely has no signal to score — "
                                      "this is correct, not the bug")
        self.assertIn("CVE-2024-99999", buf.getvalue(),
                      "load_attrib() must warn, naming the CVE ID, instead of silently "
                      "returning [] with no indication anything was skipped")
        for name in ("CTransferOwnershipVerify", "CDeserializerReadExternal",
                     "CheckPermSysAdmin"):
            self.assertEqual(A.attribute(name, attrib), (None, None, None))

    def test_no_tracked_cves_at_all_does_not_warn(self):
        # An empty/missing tracked_cves list is a deliberate no-op (nothing tracked), not
        # data starvation — must stay silent, unlike the bare-ID case above.
        with tempfile.TemporaryDirectory() as d:
            wd = Path(d)
            (wd / "meta.json").write_text(
                json.dumps({"tracked_cves": []}), encoding="utf-8")
            buf = io.StringIO()
            with contextlib.redirect_stderr(buf):
                attrib = A.load_attrib(d)
        self.assertEqual(attrib, [])
        self.assertEqual(buf.getvalue(), "")

    def test_cves_json_success_does_not_warn(self):
        # When cves.json supplies real signal, no bare-ID warning should ever fire.
        with tempfile.TemporaryDirectory() as d:
            wd = Path(d)
            (wd / "cves.json").write_text(json.dumps([
                {"cve_id": "CVE-2024-9999", "cve_desc": "a buffer overflow",
                 "component": "Engine", "cwe_id": "CWE-787"}]), encoding="utf-8")
            buf = io.StringIO()
            with contextlib.redirect_stderr(buf):
                attrib = A.load_attrib(d)
        self.assertEqual([a["cve"] for a in attrib], ["CVE-2024-9999"])
        self.assertEqual(buf.getvalue(), "")


class TestBuildAttribStarvationWarning(unittest.TestCase):
    """CRIT-NT-4, generalized (found in further review of the first fix): the silent-drop
    bug is not specific to meta.json's bare-CVE-ID tier — build_attrib() silently drops
    ANY row with no derivable signal, including a user-supplied --cves.json record whose
    cve_desc is blank/all-stopwords and whose cwe_id is missing or unmapped. The warning
    was moved from load_attrib()'s meta.json branch into build_attrib() itself so it fires
    for either caller, by CVE ID, exactly once per dropped row — and does not double-fire
    when load_attrib() calls it."""

    def test_sparse_cves_json_record_warns(self):
        attrib = []
        buf = io.StringIO()
        with contextlib.redirect_stderr(buf):
            attrib = A.build_attrib([("CVE-2024-8888", "", "", "", "")])
        self.assertEqual(attrib, [])
        self.assertIn("CVE-2024-8888", buf.getvalue())

    def test_mixed_batch_warns_only_for_the_starved_row(self):
        buf = io.StringIO()
        with contextlib.redirect_stderr(buf):
            attrib = A.build_attrib([
                ("CVE-2024-9999", "a buffer overflow", "Engine", "", "CWE-787"),
                ("CVE-2024-8888", "", "", "", ""),
            ])
        self.assertEqual([a["cve"] for a in attrib], ["CVE-2024-9999"])
        self.assertIn("CVE-2024-8888", buf.getvalue())
        self.assertNotIn("CVE-2024-9999", buf.getvalue())

    def test_load_attrib_does_not_double_warn_for_bare_meta_json_id(self):
        with tempfile.TemporaryDirectory() as d:
            wd = Path(d)
            (wd / "meta.json").write_text(
                json.dumps({"tracked_cves": "CVE-2024-99999"}), encoding="utf-8")
            buf = io.StringIO()
            with contextlib.redirect_stderr(buf):
                A.load_attrib(d)
        self.assertEqual(buf.getvalue().count("WARNING"), 1)


if __name__ == "__main__":
    unittest.main()
