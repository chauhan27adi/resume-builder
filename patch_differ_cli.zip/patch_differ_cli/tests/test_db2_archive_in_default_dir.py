"""A DB2 Fix Central archive placed directly in patches/db2/{vuln,fixed} must be extracted via
the manual: acquisition path instead of being diffed as a plain file."""
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from patch_differ_cli import pipeline as pl

VULN = "update_90467_v11.5.9_linuxx64_universal_fixpack.tar.gz"
FIXED = "update_94236_v11.5.9_linuxx64_universal_fixpack.tar.gz"


class TestArchiveDetection(unittest.TestCase):
    def test_single_archive_is_detected(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / VULN).write_bytes(b"x")
            self.assertEqual(pl._db2_archive_only(d).name, VULN)

    def test_extracted_tree_or_empty_dir_is_not_an_archive_drop(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertIsNone(pl._db2_archive_only(d))
            (Path(d) / "lib64").mkdir()
            (Path(d) / "lib64" / "libdb2e.so.1").write_bytes(b"x")
            (Path(d) / VULN).write_bytes(b"x")
            self.assertIsNone(pl._db2_archive_only(d))

    def test_several_archives_are_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / VULN).write_bytes(b"x")
            (Path(d) / FIXED).write_bytes(b"y")
            with self.assertRaises(ValueError):
                pl._db2_archive_only(d)

    def test_label_from_ibm_file_name(self):
        self.assertEqual(pl._db2_archive_label(Path(VULN)), "v11.5.9-90467")
        self.assertEqual(pl._db2_archive_label(Path(FIXED)), "v11.5.9-94236")


class TestStaging(unittest.TestCase):
    def test_archive_is_staged_into_drop_and_original_kept(self):
        with tempfile.TemporaryDirectory() as d:
            src = Path(d) / VULN
            src.write_bytes(b"payload")
            out = Path(d) / "out"
            pl._stage_db2_archive(src, out, "vuln")
            staged = out / "acquire" / "vuln" / "drop" / VULN
            self.assertEqual(staged.read_bytes(), b"payload")
            self.assertTrue(src.exists())
            pl._stage_db2_archive(src, out, "vuln")      # idempotent

    def test_a_different_archive_already_in_drop_is_refused(self):
        with tempfile.TemporaryDirectory() as d:
            out = Path(d) / "out"
            drop = out / "acquire" / "vuln" / "drop"
            drop.mkdir(parents=True)
            (drop / "old.tar.gz").write_bytes(b"old")
            src = Path(d) / VULN
            src.write_bytes(b"new")
            with self.assertRaises(ValueError):
                pl._stage_db2_archive(src, out, "vuln")


class TestRunPipelineUsesManualAcquire(unittest.TestCase):
    def test_default_dirs_holding_archives_trigger_manual_acquire(self):
        with tempfile.TemporaryDirectory() as d:
            vdir, fdir, out = (Path(d) / "vuln", Path(d) / "fixed", Path(d) / "out")
            vdir.mkdir(); fdir.mkdir()
            (vdir / VULN).write_bytes(b"v")
            (fdir / FIXED).write_bytes(b"f")
            seen = {}

            def fake_acquire(out_dir, vuln_url, fixed_url, verbose, sides):
                seen.update(vuln_url=vuln_url, fixed_url=fixed_url, sides=sides)
                return {"vuln": str(Path(d) / "xv"), "fixed": str(Path(d) / "xf")}

            with mock.patch.object(pl, "_acquire_db2", side_effect=fake_acquire):
                pl.run_pipeline("db2", vuln_dir=vdir, fixed_dir=fdir, out_dir=out,
                                stages=(), verbose=False)
            self.assertEqual(seen["vuln_url"], "manual:v11.5.9-90467")
            self.assertEqual(seen["fixed_url"], "manual:v11.5.9-94236")
            self.assertEqual(set(seen["sides"]), {"vuln", "fixed"})
            self.assertTrue((out / "acquire" / "vuln" / "drop" / VULN).is_file())
            self.assertTrue((out / "acquire" / "fixed" / "drop" / FIXED).is_file())


if __name__ == "__main__":
    unittest.main()
