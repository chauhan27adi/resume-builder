"""db2_bugs.md remaining Medium items: DB2-5 (--decompile without Ghidra is announced),
DB2-16 (pseudo-C decompiled at the function's real address; address-bearing names
normalised, switch case values kept), DB2-17 (read-only data and callee names given to the
decompiler, PLT imports named) and DB2-23 (classes changed inside a same-version jar are
decompiled and diffed). Ghidra is faked here; a CFR test runs only when the bundled JDK and
CFR are present. Scratch files live in TemporaryDirectory()s only."""
import contextlib
import io
import os
import shutil
import struct
import subprocess
import tempfile
import unittest
import zipfile
from unittest import mock

from patch_differ_cli import _decompile as dc
from patch_differ_cli import _x86diff as X
from patch_differ_cli import pipeline as pl
from patch_differ_cli import tool_paths as tp
from patch_differ_cli.db2 import _elf
from patch_differ_cli.db2 import stage1 as s1
from patch_differ_cli.db2 import stage2 as d2
from patch_differ_cli.tests.test_db2_major_fixes import GLOBAL, _job, _lib, _mov, _write


def _elf_sections(sections, et=3):
    """ELF64 LE from [(name, sh_type, flags, addr, data, link, entsize)]; links are
    section indexes (1-based: the null section is 0)."""
    shstr, noff = b"\x00", []
    for s in sections:
        noff.append(len(shstr))
        shstr += s[0].encode() + b"\x00"
    noff.append(len(shstr))
    shstr += b".shstrtab\x00"
    blob, offs = b"", []
    for s in sections + [(".shstrtab", 3, 0, 0, shstr, 0, 0)]:
        offs.append(64 + len(blob))
        blob += s[4]
    hdrs = bytes(64)
    for i, s in enumerate(sections + [(".shstrtab", 3, 0, 0, shstr, 0, 0)]):
        hdrs += struct.pack("<IIQQQQIIQQ", noff[i], s[1], s[2], s[3], offs[i], len(s[4]),
                            s[5], 0, 1, s[6])
    eh = bytearray(64)
    eh[0:4], eh[4], eh[5], eh[6] = b"\x7fELF", 2, 1, 1
    struct.pack_into("<HHI", eh, 0x10, et, 0x3E, 1)
    struct.pack_into("<Q", eh, 0x28, 64 + len(blob))
    n = len(sections) + 2
    struct.pack_into("<HHHHHH", eh, 0x34, 64, 0, 0, 64, n, n - 1)
    return bytes(eh) + blob + hdrs


def _symtab(entries):
    """(.symtab-like bytes, strtab bytes) from [(name, info, shndx, value, size)]."""
    strtab, body = b"\x00", bytes(24)
    for name, info, shndx, val, size in entries:
        off = len(strtab)
        strtab += name.encode() + b"\x00"
        body += struct.pack("<IBBHQQ", off, info, 0, shndx, val, size)
    return body, strtab


# --------------------------------------------------------------------------- DB2-16
class NormTests(unittest.TestCase):
    def test_address_names_collapse_and_constants_stay(self):
        c = ("void FUN_00401000(void) { func_0x0040a3b4(_DAT_00419000, PTR_FUN_00418020,\n"
             "  s_bad_length_004150a0, DAT_00419008, 0x100);\n"
             "  switchD_00401234::caseD_1a: return;\n}")
        n = dc.norm_c(c)
        for gone in ("00401000", "0040a3b4", "00419000", "00418020", "004150a0", "00419008",
                     "00401234"):
            self.assertNotIn(gone, n)
        for kept in ("0x100", "caseD_1a", "s_bad_length_", "_DAT_", "PTR_FUN_", "func_0x"):
            self.assertIn(kept, n)

    def test_name_targets_runs_before_norm(self):
        names = {0x40A3B4: "check_len", 0x401000: "parse"}
        c = "void FUN_00401000(void) { func_0x0040a3b4(); FUN_00402000(); }"
        named = dc.name_targets(c, names)
        self.assertEqual(named, "void parse(void) { check_len(); FUN_00402000(); }")
        self.assertEqual(dc.norm_c(named), "void parse(void) { check_len(); FUN_(); }")
        self.assertEqual(dc.name_targets(c, None), c)

    def test_context_is_part_of_the_cache_key(self):
        calls = []

        def fake(pb, fb, pctx=None, fctx=None):
            calls.append(pctx)
            return "int a;", "int b;", True

        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(dc, "_try_decompile", fake):
            dc.decompile_cached(b"p", b"f", d)
            dc.decompile_cached(b"p", b"f", d)                  # cache hit
            ctx = {"base": 0x401000, "blocks": [(0x419000, b"\x01")], "names": {1: "x"}}
            dc.decompile_cached(b"p", b"f", d, ctx, ctx)
            dc.decompile_cached(b"p", b"f", d, ctx, ctx)        # hit
            other = dict(ctx, base=0x402000)
            dc.decompile_cached(b"p", b"f", d, other, other)
        self.assertEqual(calls, [None, ctx, other])
        self.assertEqual(dc._ctx_digest(None, None), "")

    def test_context_files_reach_the_script(self):
        seen = {}

        def fake_run(cmd, **kw):
            i = cmd.index("DecompileFunc.java")
            outc, ctxd = cmd[i + 1], cmd[i + 2]
            seen["args"] = cmd[i + 1:i + 3]
            with open(os.path.join(ctxd, "prior.ctx"), encoding="ascii") as fh:
                seen["prior"] = fh.read()
            seen["fixed"] = os.path.exists(os.path.join(ctxd, "fixed.ctx"))
            for side in ("prior", "fixed"):
                with open(os.path.join(outc, side + ".c"), "w") as fh:
                    fh.write("int f(void){return 0;}")
            return type("P", (), {"returncode": 0, "stdout": b""})()

        with mock.patch.object(dc, "analyze_headless", return_value="h.bat"), \
                mock.patch.object(dc.tp, "clear_stale_ghidra_script_cache"), \
                mock.patch.object(dc, "_run_tool", fake_run):
            dc.decompile_pair(b"\x90", b"\x90",
                              {"base": 0x401000, "blocks": [(0x419000, b"\xab\xcd")]}, None)
        self.assertEqual(seen["prior"], "base 401000\nblock 419000 abcd\n")
        self.assertFalse(seen["fixed"], "no context: no file, decompiled as before")

    def test_without_context_the_command_is_unchanged(self):
        seen = {}

        def fake_run(cmd, **kw):
            seen["tail"] = cmd[cmd.index("DecompileFunc.java"):]
            outc = cmd[cmd.index("DecompileFunc.java") + 1]
            with open(os.path.join(outc, "prior.c"), "w") as fh:
                fh.write("int f;")
            return type("P", (), {"returncode": 0, "stdout": b""})()

        with mock.patch.object(dc, "analyze_headless", return_value="h.bat"), \
                mock.patch.object(dc.tp, "clear_stale_ghidra_script_cache"), \
                mock.patch.object(dc, "_run_tool", fake_run):
            dc.decompile_pair(b"\x90", b"")
        self.assertEqual(len(seen["tail"]), 4, seen["tail"])   # script, outDir, flags
        self.assertEqual(seen["tail"][2:], ["-noanalysis", "-deleteProject"])


# --------------------------------------------------------------------------- DB2-17
def _ctx_elf():
    """.text at 0x401000 with: lea rsi,[rip+X] -> .rodata; mov edi,<abs .rodata>;
    jmp [rax*8 + abs table]; call helper; ret. A writable .data is never loaded."""
    text_addr, rodata_addr, data_addr = 0x401000, 0x419000, 0x420000
    helper = 0x401100
    code = bytearray()
    lea = text_addr + 7                                     # end of the lea
    code += b"\x48\x8d\x35" + struct.pack("<i", rodata_addr + 0x10 - lea)   # lea rsi,[rip+d]
    code += b"\xbf" + struct.pack("<I", rodata_addr + 0x2000)              # mov edi, imm32
    code += b"\xff\x24\xc5" + struct.pack("<I", rodata_addr + 0x40)        # jmp [rax*8+tbl]
    code += b"\x8b\x0c\x25" + struct.pack("<I", data_addr)                 # mov ecx,[abs .data]
    call_at = text_addr + len(code)
    code += b"\xe8" + struct.pack("<i", helper - (call_at + 5))            # call helper
    code += b"\xc3"
    text = bytes(code) + b"\x90" * (0x100 - len(code)) + _mov(7)
    rodata = bytes(range(256)) * 48                                       # 12 KiB
    syms, strs = _symtab([("parse", GLOBAL, 1, text_addr, len(code)),
                          ("helper", GLOBAL, 1, helper, 6)])
    data = _elf_sections([(".text", 1, 0x6, text_addr, text, 0, 0),
                          (".rodata", 1, 0x2, rodata_addr, rodata, 0, 0),
                          (".data", 1, 0x3, data_addr, b"\x55" * 64, 0, 0),
                          (".symtab", 2, 0, 0, syms, 5, 24),
                          (".strtab", 3, 0, 0, strs, 0, 0)])
    return data, text_addr, bytes(code), rodata_addr, rodata


class ContextTests(unittest.TestCase):
    def test_readonly_sections_only(self):
        with tempfile.TemporaryDirectory() as d:
            path = _write(os.path.join(d, "x.so"), _ctx_elf()[0])
            self.assertEqual([(a, s) for a, s, _o in _elf.readonly_data_sections(path)],
                             [(0x419000, 12288)])

    def test_context_has_real_base_data_windows_and_callee_names(self):
        data, va, code, ro_addr, rodata = _ctx_elf()
        with tempfile.TemporaryDirectory() as d:
            path = _write(os.path.join(d, "x.so"), data)
            fm = d2._func_map(path)
            ctx = d2._decompile_context(X.md(), path, va, code, d2._exact_names(fm),
                                        _elf.readonly_data_sections(path))
        self.assertEqual(ctx["base"], va)
        self.assertEqual(ctx["names"], {0x401100: "helper", va: "parse"})
        blocks = dict(ctx["blocks"])
        self.assertEqual(sorted(blocks), [ro_addr + 0x10, ro_addr + 0x2000],
                         "RIP-relative, absolute table and immediate references; the "
                         "lea and table windows merge; .data is not loaded")
        self.assertEqual(blocks[ro_addr + 0x10], rodata[0x10:0x10 + 0x30 + d2._CTX_WINDOW])
        self.assertEqual(blocks[ro_addr + 0x2000], rodata[0x2000:0x3000])

    def test_total_size_is_bounded(self):
        data, va, code, _ro, _r = _ctx_elf()
        with tempfile.TemporaryDirectory() as d, mock.patch.object(d2, "_CTX_MAX_BYTES", 100):
            path = _write(os.path.join(d, "x.so"), data)
            ctx = d2._decompile_context(X.md(), path, va, code, {},
                                        _elf.readonly_data_sections(path))
        self.assertEqual(sum(len(b) for _a, b in ctx["blocks"]), 100)

    def test_plt_imports_are_named(self):
        plt_addr, got = 0x401020, 0x404018
        # .plt.sec-style stub: endbr64; bnd jmp [rip+slot]; then a lazy .plt-style one
        stub1 = b"\xf3\x0f\x1e\xfa" + b"\xf2\xff\x25" + struct.pack(
            "<i", got - (plt_addr + 4 + 7)) + b"\x0f\x1f\x44\x00\x00"
        stub2 = b"\xff\x25" + struct.pack("<i", got + 8 - (plt_addr + 16 + 6)) + b"\x90" * 10
        dyn, dstr = _symtab([("memcpy", GLOBAL, 0, 0, 0), ("strncpy", GLOBAL, 0, 0, 0)])
        rela = (struct.pack("<QQq", got, (1 << 32) | 7, 0)
                + struct.pack("<QQq", got + 8, (2 << 32) | 7, 0))
        data = _elf_sections([(".plt.sec", 1, 0x6, plt_addr, stub1 + stub2, 0, 0),
                              (".dynsym", 11, 0x2, 0x400300, dyn, 3, 24),
                              (".dynstr", 3, 0x2, 0x400400, dstr, 0, 0),
                              (".rela.plt", 4, 0x2, 0x400500, rela, 2, 24)])
        with tempfile.TemporaryDirectory() as d:
            got_names = d2._plt_names(X.md(), _write(os.path.join(d, "x.so"), data))
        self.assertEqual(got_names, {plt_addr: "memcpy", plt_addr + 4: "memcpy",
                                     plt_addr + 16: "strncpy"})

    def test_process_file_passes_each_sides_context(self):
        seen = []

        def fake_cached(pb, fb, cache, pctx=None, fctx=None):
            seen.append((pctx, fctx))
            return "int a;", "int b;", True

        rel = "lib/libx.so"
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(d2, "decompile_cached", fake_cached), \
                mock.patch.object(X, "fix_signature", return_value=(1, ["guard"])):
            _write(os.path.join(d, "p", rel), _lib([("f", GLOBAL, _mov(1))], addr=0x1000))
            _write(os.path.join(d, "f", rel), _lib([("f", GLOBAL, _mov(2))], addr=0x2000))
            job = _job(d, rel)
            job.update(decompile=True, decompile_cache=d, decompiled_c_dir=d)
            d2._process_file(job)
        (pctx, fctx), = seen
        self.assertEqual((pctx["base"], fctx["base"]), (0x1000, 0x2000))
        self.assertEqual((pctx["names"], fctx["names"]), ({0x1000: "f"}, {0x2000: "f"}))

    def test_a_context_failure_falls_back_to_no_context(self):
        seen = []
        rel = "lib/libx.so"
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(d2, "decompile_cached",
                                  lambda pb, fb, c, p=None, f=None: seen.append((p, f))
                                  or ("int a;", "int b;", True)), \
                mock.patch.object(d2, "_decompile_context", side_effect=OSError("boom")), \
                mock.patch.object(X, "fix_signature", return_value=(1, ["guard"])):
            _write(os.path.join(d, "p", rel), _lib([("f", GLOBAL, _mov(1))]))
            _write(os.path.join(d, "f", rel), _lib([("f", GLOBAL, _mov(2))]))
            job = _job(d, rel)
            job.update(decompile=True, decompile_cache=d, decompiled_c_dir=d)
            err = io.StringIO()
            with contextlib.redirect_stderr(err):
                r = d2._process_file(job)
        self.assertEqual(seen, [(None, None)])
        self.assertEqual(r["decompile_attempted"], 1)
        self.assertIn("no decompile context", err.getvalue())


# --------------------------------------------------------------------------- DB2-5
class DecompileWithoutGhidraTests(unittest.TestCase):
    def test_announced_up_front(self):
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(tp, "analyze_headless", return_value=None):
            err = io.StringIO()
            # empty input folders then fail acquisition; the warning comes before that
            with contextlib.redirect_stderr(err), self.assertRaises(ValueError):
                pl.run_pipeline("db2", vuln_dir=d, fixed_dir=d, out_dir=os.path.join(d, "o"),
                                stages=(), verbose=False, decompile=True)
        self.assertIn("--decompile was given but Ghidra was not found", err.getvalue())


# --------------------------------------------------------------------------- bug.md DB2-T1-2
class UseBindiffWithoutGhidraTests(unittest.TestCase):
    def test_announced_up_front(self):
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(tp, "analyze_headless", return_value=None):
            err = io.StringIO()
            # empty input folders then fail acquisition; the warning comes before that
            with contextlib.redirect_stderr(err), self.assertRaises(ValueError):
                pl.run_pipeline("db2", vuln_dir=d, fixed_dir=d, out_dir=os.path.join(d, "o"),
                                stages=(), verbose=False, use_bindiff=True)
        self.assertIn("--use-bindiff was given but Ghidra was not found", err.getvalue())


# --------------------------------------------------------------------------- DB2-23
K = b"\xca\xfe\xba\xbe"          # class-file magic


def _jar(path, classes, manifest="Manifest-Version: 1.0\n"):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("META-INF/MANIFEST.MF", manifest)
        for name, data in classes.items():
            z.writestr(name, data)


class JarClassTests(unittest.TestCase):
    def test_outer_class(self):
        self.assertEqual(s1._outer_class("a/b/Foo$Bar$1.class"), "a/b/Foo")
        self.assertEqual(s1._outer_class("Foo.class"), "Foo")

    def _run(self, prior, fixed, sources):
        """Stage 1 with the decompiler faked: `sources` = {jar side: {outer: text}}."""
        def fake(jar, outers, out_dir, tmp):
            side = "prior" if os.sep + "p" + os.sep in jar else "fixed"
            return {o: t for o, t in sources[side].items() if o in outers}

        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(s1, "_decompile_classes", fake):
            _jar(os.path.join(d, "p", "java", "db2jcc4.jar"), prior)
            _jar(os.path.join(d, "f", "java", "db2jcc4.jar"), fixed)
            return s1.run(os.path.join(d, "p"), os.path.join(d, "f"), os.path.join(d, "w"))

    def test_changed_added_and_removed_classes_get_cards(self):
        prior = {"a/Login.class": K + b"1", "a/Login$H.class": K + b"h", "a/Gone.class": K,
                 "a/Same.class": K + b"s", "a/Touched.class": K + b"t1"}
        fixed = {"a/Login.class": K + b"1", "a/Login$H.class": K + b"h2", "a/New.class": K,
                 "a/Same.class": K + b"s", "a/Touched.class": K + b"t2"}
        src = {"prior": {"a/Login": "class Login { int x = 256; }", "a/Gone": "class Gone {}",
                         "a/Touched": "class Touched {}"},
               "fixed": {"a/Login": "class Login { int x = 128; }", "a/New": "class New {}",
                         "a/Touched": "class Touched {}"}}
        r = self._run(prior, fixed, src)
        cards = {c["object"]: c["change"] for c in r["readable_files"]
                 if c["kind"] == "java-class"}
        self.assertEqual(cards, {"db2jcc4: a.Login": "modified", "db2jcc4: a.New": "added",
                                 "db2jcc4: a.Gone": "removed"},
                         "a nested-class change shows on its outer class; same source "
                         "(only the bytes differ) gets no card")
        self.assertEqual(r["counts"]["java_classes"], 3)
        self.assertEqual(r["counts"]["dependencies"], 1, "the jar's entry card is kept")
        self.assertEqual(r["counts"]["scripts"], 0)

    def test_cap(self):
        prior = {f"a/C{i}.class": K + b"1" for i in range(5)}
        fixed = {f"a/C{i}.class": K + b"2" for i in range(5)}
        src = {"prior": {f"a/C{i}": f"class C{i} {{ int v = 1; }}" for i in range(5)},
               "fixed": {f"a/C{i}": f"class C{i} {{ int v = 2; }}" for i in range(5)}}
        with mock.patch.object(s1, "_MAX_CLASSES_PER_JAR", 2):
            r = self._run(prior, fixed, src)
        self.assertEqual((r["counts"]["java_classes"], r["counts"]["java_classes_capped"]),
                         (2, 3))

    def test_decompile_failure_is_reported_and_the_jar_card_stays(self):
        from patch_differ_cli.oracle import java_decompile as jd
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(s1, "_decompile_classes",
                                  side_effect=jd.DecompileFailed("CFR exited 1")):
            _jar(os.path.join(d, "p", "java", "x.jar"), {"a/A.class": K + b"1"})
            _jar(os.path.join(d, "f", "java", "x.jar"), {"a/A.class": K + b"2"})
            r = s1.run(os.path.join(d, "p"), os.path.join(d, "f"), os.path.join(d, "w"))
        self.assertEqual(r["counts"]["errors"], 0, "an add-on missing, not a failed run")
        self.assertEqual(r["counts"]["java_classes_failed"], 1)
        self.assertIn("CFR exited 1", r["class_decompile_failures"][0]["error"])
        self.assertEqual(r["counts"]["dependencies"], 1)
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            from patch_differ_cli import cli
            cli._warn_decompile_shortfalls({"stage1": r})
        self.assertIn("1 jar(s): the changed classes could not be decompiled", err.getvalue())

    def test_non_class_bytes_are_not_decompiled(self):
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(s1, "_decompile_classes",
                                  side_effect=AssertionError("decompiler called")):
            _jar(os.path.join(d, "p", "java", "x.jar"), {"a/A.class": b"not a class 1"})
            _jar(os.path.join(d, "f", "java", "x.jar"), {"a/A.class": b"not a class 2"})
            r = s1.run(os.path.join(d, "p"), os.path.join(d, "f"), os.path.join(d, "w"))
        self.assertEqual((r["counts"]["java_classes"], r["counts"]["errors"]), (0, 0))
        self.assertEqual(r["counts"]["dependencies"], 1)

    @unittest.skipUnless(tp.cfr_jar() and os.path.isfile(
        os.path.join(tp.java_home(), "bin", "javac.exe" if os.name == "nt" else "javac")),
        "bundled JDK + CFR not present")
    def test_real_cfr_source_diff(self):
        javac = os.path.join(tp.java_home(), "bin", "javac.exe" if os.name == "nt" else "javac")
        with tempfile.TemporaryDirectory() as d:
            for side, bound in (("p", 256), ("f", 128)):
                src = os.path.join(d, "src", side, "a")
                os.makedirs(src)
                with open(os.path.join(src, "Login.java"), "w") as fh:
                    fh.write("package a; public class Login { public static boolean ok(int n)"
                             " { return n <= %d; } }" % bound)
                cls = os.path.join(d, "cls", side)
                subprocess.run([javac, "-g:none", "-d", cls, os.path.join(src, "Login.java")],
                               check=True, capture_output=True)
                with open(os.path.join(cls, "a", "Login.class"), "rb") as fh:
                    _jar(os.path.join(d, side, "java", "x.jar"), {"a/Login.class": fh.read()})
            r = s1.run(os.path.join(d, "p"), os.path.join(d, "f"), os.path.join(d, "w"))
            card = [c for c in r["readable_files"] if c["kind"] == "java-class"]
            self.assertEqual(len(card), 1, r)
            with open(os.path.join(d, "w", "stage1", card[0]["file"]), encoding="utf-8") as fh:
                diff = fh.read()
        self.assertIn("-        return n <= 256;", diff)
        self.assertIn("+        return n <= 128;", diff)


if __name__ == "__main__":
    unittest.main()
