"""Regression tests for the preserved-stat follow-ups to bugs.md #21, #37 and #43: a file
replaced by different bytes of the SAME size with its original timestamp restored. Every
earlier check that trusted size + mtime accepted such a replacement:

  #21  a cached DB2 layer passed _layer_ok() via its `.verified` stamp;
  #37  load_result() still showed the prior Stage 1/2 results as current;
  #43  stage0_is_current() was True, so bound_stage0() returned the old change list.

All are now checked by content. Scratch files live in TemporaryDirectory()s only."""
import contextlib
import hashlib
import io
import os
import tempfile
import unittest

import patch_differ_cli._result_state as rs
import patch_differ_cli.db2.acquire as dacq
import patch_differ_cli.oracle.stage1 as o1
import patch_differ_cli.pipeline as pl


def _write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    return path


def _replace_preserving_stat(path, data):
    """Different bytes, same size, original atime/mtime restored."""
    st = os.stat(path)
    assert len(data) == st.st_size
    with open(path, "wb") as fh:
        fh.write(data)
    os.utime(path, ns=(st.st_atime_ns, st.st_mtime_ns))
    after = os.stat(path)
    assert (after.st_size, after.st_mtime_ns) == (st.st_size, st.st_mtime_ns)


class LayerCacheTests(unittest.TestCase):                                     # #21
    def test_preserved_stat_replacement_of_a_cached_layer_is_rejected(self):
        blob = b"layer-bytes " * 64
        digest = "sha256:" + hashlib.sha256(blob).hexdigest()
        with tempfile.TemporaryDirectory() as d:
            dest = _write(os.path.join(d, digest.replace(":", "_") + ".tar.gz"), blob)
            self.assertTrue(dacq._layer_ok(dest, digest))      # verified (and was stamped)
            self.assertTrue(dacq._layer_ok(dest, digest))      # still fine when unchanged
            _replace_preserving_stat(dest, blob[:-6] + b"EVIL!!")
            self.assertFalse(dacq._layer_ok(dest, digest))
            self.assertFalse(os.path.exists(dest), "a mismatching layer is removed")


class _Pair(unittest.TestCase):
    def setUp(self):
        td = tempfile.TemporaryDirectory()
        self.addCleanup(td.cleanup)
        d = td.name
        self.p, self.f, self.w = (os.path.join(d, x) for x in ("p", "f", "w"))
        _write(os.path.join(self.p, "rdbms", "admin", "x.sql"), b"select 1 from dual;")
        self.fx = _write(os.path.join(self.f, "rdbms", "admin", "x.sql"), b"select 2 from dual;")

    def _run(self, stages):
        with contextlib.redirect_stdout(io.StringIO()):
            return pl.run_pipeline("oracle", self.p, self.f, self.w, stages=stages,
                                   verbose=False)

    def _edit_fixed_preserving_stat(self):
        _replace_preserving_stat(self.fx, b"select 3 from dual;")


class StaleResultsTests(_Pair):                                               # #37
    def test_preserved_stat_edit_marks_older_stage_results_stale(self):
        self._run(("triage", "stage1", "stage2"))
        self._edit_fixed_preserving_stat()
        self._run(("triage",))
        stale = []
        loaded = pl.load_result(self.w, stale=stale)
        self.assertEqual(sorted(loaded), ["triage"])
        self.assertEqual(sorted(s for s, _r in stale), ["stage1", "stage2"])

    def test_untouched_inputs_keep_separate_stage_runs_current(self):
        self._run(("triage", "stage1"))
        self._run(("triage", "stage2"))
        stale = []
        self.assertEqual(sorted(pl.load_result(self.w, stale=stale)),
                         ["stage1", "stage2", "triage"])
        self.assertEqual(stale, [])


class StaleStage0Tests(_Pair):                                                # #43
    def test_preserved_stat_edit_makes_stage0_stale(self):
        self._run(("triage",))
        self.assertTrue(rs.stage0_is_current(self.w, self.p, self.f))
        self._edit_fixed_preserving_stat()
        self.assertFalse(rs.stage0_is_current(self.w, self.p, self.f))
        with self.assertRaises(RuntimeError):
            rs.bound_stage0(self.w, self.p, self.f)
        with self.assertRaises(RuntimeError):
            o1.run(self.p, self.f, self.w)

    def test_pipeline_reruns_triage_after_a_preserved_stat_edit(self):
        self._run(("triage",))
        self._edit_fixed_preserving_stat()
        r = self._run(("stage1",))
        self.assertIn("triage", r)
        with open(os.path.join(self.w, "stage1", r["stage1"]["readable_files"][0]["pair"]),
                  encoding="utf-8") as fh:
            self.assertIn("select 3", fh.read(), "Stage 1 must diff the CURRENT input")

    def test_output_dir_inside_an_input_tree_does_not_change_the_identity(self):
        nested = os.path.join(self.f, "out")
        with contextlib.redirect_stdout(io.StringIO()):
            pl.run_pipeline("oracle", self.p, self.f, nested, stages=("triage",),
                            verbose=False)
        self.assertTrue(rs.stage0_is_current(nested, self.p, self.f))


if __name__ == "__main__":
    unittest.main()
