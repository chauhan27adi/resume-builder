"""Regression tests for bugs.md #19, #21, #31, #32, #41, #44, #46, #47 — acquisition and
cache paths that crashed, looped forever, or kept an incomplete/wrong artifact as if it
were valid (so later runs reused it).

No network, Ghidra or 7-Zip: HTTP servers, subprocesses and the registry are faked.
Scratch files live in TemporaryDirectory()s only."""
import contextlib
import hashlib
import io
import json
import os
import struct
import tempfile
import unittest
from unittest import mock

import patch_differ_cli._attribution as AT
import patch_differ_cli._bindiff as bd
import patch_differ_cli.db2.acquire as dacq
import patch_differ_cli.mssql.acquire as macq
import patch_differ_cli.mssql.symbols as sym


def _write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    return path


def _read(path):
    with open(path, "rb") as fh:
        return fh.read()


# --------------------------------------------------------------------------- #19
class MetaJsonShapeTests(unittest.TestCase):
    def _load(self, content):
        with tempfile.TemporaryDirectory() as d:
            if content is not None:
                with open(os.path.join(d, "meta.json"), "w", encoding="utf-8") as fh:
                    fh.write(content)
            err = io.StringIO()
            with mock.patch.object(AT, "build_attrib", lambda rows: rows), \
                    contextlib.redirect_stderr(err):
                return AT.load_attrib(d), err.getvalue()

    def test_wrong_shapes_no_longer_crash(self):
        for content in ("[1, 2]", '{"tracked_cves": 5}', '"text"', "null",
                        '{"tracked_cves": {"a": 1}}'):
            rows, err = self._load(content)
            self.assertEqual(rows, [], content)
            self.assertIn("WARNING", err, content)

    def test_non_string_items_are_dropped_with_a_warning(self):
        rows, err = self._load('{"tracked_cves": ["CVE-2026-0001", 3, null, " "]}')
        self.assertEqual(rows, [("CVE-2026-0001", "", "", "", "")])
        self.assertIn("non-string", err)

    def test_valid_shapes_still_work(self):
        rows, err = self._load('{"tracked_cves": "CVE-2026-0001, CVE-2026-0002"}')
        self.assertEqual([r[0] for r in rows], ["CVE-2026-0001", "CVE-2026-0002"])
        self.assertEqual(err, "")
        self.assertEqual(self._load('{"other": 1}'), ([], ""))      # no CVEs: silent

    def test_invalid_json_warns_and_missing_file_is_silent(self):
        rows, err = self._load("{not json")
        self.assertEqual(rows, [])
        self.assertIn("unreadable", err)
        self.assertEqual(self._load(None), ([], ""))


# --------------------------------------------------------------------------- #46
class _Proc:
    def __init__(self, rc=0, out=b""):
        self.returncode, self.stdout = rc, out


class BinExportCacheTests(unittest.TestCase):
    def setUp(self):
        td = tempfile.TemporaryDirectory()
        self.addCleanup(td.cleanup)
        self.d = td.name
        self.binary = _write(os.path.join(self.d, "x.so"), b"\x7fELF binary v1")
        self.out = os.path.join(self.d, "exp", "x.BinExport")
        self.export = (0, b"", b"VALID-EXPORT")       # rc, stdout, bytes written
        self.calls = 0
        for target, value in (("analyze_headless", "analyzeHeadless"),
                              ("locate_binexport_script", os.path.join(self.d, "BinExport.java")),
                              ("clear_stale_ghidra_script_cache", None), ("child_env", {})):
            p = mock.patch.object(bd.tp, target, return_value=value)
            p.start()
            self.addCleanup(p.stop)
        p = mock.patch.object(bd, "_run_tool", self._run)
        p.start()
        self.addCleanup(p.stop)

    def _run(self, cmd, **kw):
        self.calls += 1
        if "-postScript" not in cmd:
            return _Proc(0)                           # import
        rc, out, data = self.export
        with open(self.out, "wb") as fh:
            fh.write(data)
        return _Proc(rc, out)

    def _export(self):
        return bd.ghidra_binexport(self.binary, os.path.join(self.d, "proj"), self.out)

    def test_failed_export_with_partial_output_is_not_cached(self):
        self.export = (2, b"java.lang.Exception: boom", b"PARTIAL")
        with self.assertRaises(RuntimeError) as ctx:
            self._export()
        self.assertIn("rc=2", str(ctx.exception))
        self.assertFalse(os.path.exists(self.out))
        self.assertFalse(os.path.exists(self.out + ".sha256"))
        self.export = (0, b"", b"VALID-EXPORT")
        self.calls = 0
        self._export()
        self.assertEqual(self.calls, 2, "the failed export must not be reused")
        self.assertEqual(_read(self.out), b"VALID-EXPORT")

    def test_script_error_with_exit_0_is_a_failure(self):
        self.export = (0, b"ERROR REPORT SCRIPT ERROR: BinExport.java : NPE", b"PARTIAL")
        with self.assertRaises(RuntimeError) as ctx:
            self._export()
        self.assertIn("REPORT SCRIPT ERROR", str(ctx.exception))
        self.assertFalse(os.path.exists(self.out + ".sha256"))

    def test_success_is_cached_and_reused(self):
        self._export()
        self.calls = 0
        self._export()
        self.assertEqual(self.calls, 0)

    def test_failed_reexport_after_binary_change_leaves_no_stale_cache(self):
        self._export()
        _write(self.binary, b"\x7fELF binary v2 (changed)")
        self.export = (2, b"", b"PARTIAL")
        with self.assertRaises(RuntimeError):
            self._export()
        self.assertFalse(os.path.exists(self.out + ".sha256"))
        self.assertFalse(os.path.exists(self.out))

    def test_timeout_removes_the_partial_export(self):
        def boom(cmd, **kw):
            if "-postScript" in cmd:
                with open(self.out, "wb") as fh:
                    fh.write(b"PARTIAL")
                raise bd.subprocess.TimeoutExpired(cmd, 1)
            return _Proc(0)
        with mock.patch.object(bd, "_run_tool", boom):
            with self.assertRaises(bd.subprocess.TimeoutExpired):
                self._export()
        self.assertFalse(os.path.exists(self.out))


# --------------------------------------------------------------------------- #31
def _cab(tag):
    body = b"MSCF" + b"\0" * 4 + struct.pack("<I", 48) + b"\0" * 12 + bytes([3, 1])
    return body + tag.ljust(48 - len(body), b".")


class CabinetCarveTests(unittest.TestCase):
    def setUp(self):
        td = tempfile.TemporaryDirectory()
        self.addCleanup(td.cleanup)
        self.d = td.name
        self.exe = os.path.join(self.d, "KB1.exe")
        self.cabs = os.path.join(self.d, "cabs")

    def _cab_bytes(self):
        return _read(os.path.join(self.cabs, "0000.cab"))

    def test_cabs_from_a_different_installer_are_not_reused(self):
        _write(self.exe, b"MZ stub " + _cab(b"BUILD-A"))
        macq._carve_cabs(self.exe, self.cabs)
        self.assertIn(b"BUILD-A", self._cab_bytes())
        _write(self.exe, b"MZ longer stub " + _cab(b"BUILD-B"))      # replaced installer
        macq._carve_cabs(self.exe, self.cabs)
        self.assertIn(b"BUILD-B", self._cab_bytes())

    def test_same_installer_resumes_without_recarving(self):
        _write(self.exe, b"MZ " + _cab(b"BUILD-A"))
        self.assertEqual(macq._carve_cabs(self.exe, self.cabs), 1)
        os.remove(os.path.join(self.cabs, "0000.cab"))        # a resume must not touch cabs
        self.assertEqual(macq._carve_cabs(self.exe, self.cabs), 1)
        self.assertFalse(os.path.exists(os.path.join(self.cabs, "0000.cab")))

    def test_older_sentinel_format_triggers_a_recarve(self):
        _write(self.exe, b"MZ " + _cab(b"BUILD-B"))
        _write(os.path.join(self.cabs, "0000.cab"), _cab(b"BUILD-A"))
        _write(os.path.join(self.cabs, macq._CARVE_DONE), b"1")
        macq._carve_cabs(self.exe, self.cabs)
        self.assertIn(b"BUILD-B", self._cab_bytes())

    def test_stale_msp_from_an_earlier_extraction_is_not_used(self):
        _write(self.exe, b"MZ " + _cab(b"BUILD-B"))
        stage = os.path.join(self.d, "engine_msp")
        _write(os.path.join(stage, macq._ENGINE_MSP), b"MSP OF ANOTHER INSTALLER")
        with mock.patch.object(macq, "_7z_extract", lambda archive, out: None):
            with self.assertRaises(RuntimeError) as ctx:
                macq._extract_engine_into(self.exe, os.path.join(self.d, "engine"),
                                          self.cabs, stage)
        self.assertIn("not found", str(ctx.exception))


# --------------------------------------------------------------------------- #32
def _msf(nblocks=64, block=512, truncate=0):
    # 32 KiB: each half of the fake transfer exceeds Python's 8 KiB write buffer, so a
    # direct-to-dest writer really exposes partial bytes on disk (as 1 MiB blocks do)
    hdr = b"Microsoft C/C++ MSF 7.00\r\n\x1aDS\0\0\0" + struct.pack("<IIII", block, 1, nblocks, 0)
    data = hdr + b"\x11" * (block * nblocks - len(hdr))
    return data[:len(data) - truncate] if truncate else data


class _PdbResp:
    def __init__(self, data, length=None, during=None):
        self.status_code, self._data, self._during = 200, data, during
        self.headers = {"Content-Length": str(length if length is not None else len(data))}

    def iter_content(self, n):
        half = len(self._data) // 2
        yield self._data[:half]
        if self._during:
            self._during()
        yield self._data[half:]

    def close(self):
        pass


class PdbCacheTests(unittest.TestCase):
    def setUp(self):
        td = tempfile.TemporaryDirectory()
        self.addCleanup(td.cleanup)
        self.cache = td.name
        for target, value in (("debug_pdb", ("sqlmin.pdb", "GUID", 1)),
                              ("symbol_key", "KEY1")):
            p = mock.patch.object(sym, target, return_value=value)
            p.start()
            self.addCleanup(p.stop)
        self.dest = os.path.join(self.cache, "sqlmin.pdb_KEY1", "sqlmin.pdb")

    def _fetch(self, resp, online=True):
        with mock.patch.object(sym.requests, "get", return_value=resp):
            return sym.fetch_pdb("x.dll", self.cache, online=online)

    def _leftovers(self):
        d = os.path.dirname(self.dest)
        return [f for f in os.listdir(d) if f.endswith(".part")] if os.path.isdir(d) else []

    def test_concurrent_reader_never_sees_a_partial_pdb(self):
        seen = []
        resp = _PdbResp(_msf(), during=lambda: seen.append(
            sym.fetch_pdb("x.dll", self.cache, online=False)))
        self.assertEqual(self._fetch(resp), self.dest)
        self.assertEqual(seen, [None], "a reader mid-download must not get the partial file")
        self.assertEqual(_read(self.dest), _msf())
        self.assertEqual(self._leftovers(), [])

    def test_short_transfer_is_not_installed(self):
        self.assertIsNone(self._fetch(_PdbResp(_msf()[:1000], length=len(_msf()))))
        self.assertFalse(os.path.exists(self.dest))
        self.assertEqual(self._leftovers(), [])

    def test_truncated_msf_without_content_length_is_not_installed(self):
        resp = _PdbResp(_msf(truncate=100))
        resp.headers = {}
        self.assertIsNone(self._fetch(resp))
        self.assertFalse(os.path.exists(self.dest))

    def test_truncated_cache_entry_from_an_older_version_is_replaced(self):
        _write(self.dest, _msf(truncate=700))
        self.assertIsNone(sym.fetch_pdb("x.dll", self.cache, online=False))
        self.assertFalse(os.path.exists(self.dest))
        _write(self.dest, _msf(truncate=700))
        self.assertEqual(self._fetch(_PdbResp(_msf())), self.dest)
        self.assertEqual(_read(self.dest), _msf())

    def test_complete_cache_entry_and_non_msf_entry_are_reused(self):
        _write(self.dest, _msf())
        self.assertEqual(sym.fetch_pdb("x.dll", self.cache, online=False), self.dest)
        _write(self.dest, b"Microsoft C/C++ program database 2.00\r\n\x1aJG\0\0 legacy")
        self.assertEqual(sym.fetch_pdb("x.dll", self.cache, online=False), self.dest)


# --------------------------------------------------------------------------- #21, #41
class _BlobResp:
    def __init__(self, status, body=b"", headers=None):
        self.status_code, self._body = status, body
        self.headers = headers or {"Content-Length": str(len(body))}

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def raise_for_status(self):
        if self.status_code >= 400:
            raise dacq.requests.HTTPError(f"HTTP {self.status_code}")

    def iter_content(self, n):
        for i in range(0, len(self._body), 7):
            yield self._body[i:i + 7]


class _Registry:
    """Serves one blob; `mode` shapes the reply to a ranged request."""
    def __init__(self, blob, mode="ok"):
        self.blob, self.mode, self.ranges = blob, mode, []

    def get(self, url, headers=None, **kw):
        rng = (headers or {}).get("Range")
        self.ranges.append(rng)
        if rng:
            start = int(rng.split("=")[1].rstrip("-"))
            if start >= len(self.blob) or self.mode == "416":
                return _BlobResp(416)
            return _BlobResp(206, self.blob[start:])
        return _BlobResp(200, self.blob if self.mode != "corrupt" else b"X" + self.blob[1:])


BLOB = b"layer-bytes " * 50
DIGEST = "sha256:" + hashlib.sha256(BLOB).hexdigest()


class LayerDownloadTests(unittest.TestCase):
    def setUp(self):
        td = tempfile.TemporaryDirectory()
        self.addCleanup(td.cleanup)
        self.dest = os.path.join(td.name, DIGEST.replace(":", "_") + ".tar.gz")

    def _dl(self, reg):
        return dacq._download_blob(reg, "icr.io", "db2", DIGEST, None, self.dest)

    def test_fresh_download_is_verified_and_stamped(self):
        self.assertEqual(self._dl(_Registry(BLOB)), self.dest)
        self.assertEqual(_read(self.dest), BLOB)
        self.assertTrue(dacq._layer_ok(self.dest, DIGEST))

    def test_corrupted_transfer_is_not_cached(self):
        with self.assertRaises(RuntimeError) as ctx:
            self._dl(_Registry(BLOB, "corrupt"))
        self.assertIn("do not match the digest", str(ctx.exception))
        self.assertFalse(os.path.exists(self.dest))
        self.assertFalse(os.path.exists(self.dest + ".part"))

    def test_resume_appends_and_verifies(self):
        _write(self.dest + ".part", BLOB[:100])
        reg = _Registry(BLOB)
        self._dl(reg)
        self.assertEqual(reg.ranges, ["bytes=100-"])
        self.assertEqual(_read(self.dest), BLOB)

    def test_resume_onto_a_corrupt_prefix_restarts_from_scratch(self):
        _write(self.dest + ".part", b"Y" * 100)
        reg = _Registry(BLOB)
        self._dl(reg)
        self.assertEqual(reg.ranges, ["bytes=100-", None])
        self.assertEqual(_read(self.dest), BLOB)

    def test_complete_part_and_416_is_promoted(self):                 # #41
        _write(self.dest + ".part", BLOB)
        reg = _Registry(BLOB)
        self._dl(reg)
        self.assertEqual(reg.ranges, [f"bytes={len(BLOB)}-"])
        self.assertEqual(_read(self.dest), BLOB)
        self.assertFalse(os.path.exists(self.dest + ".part"))

    def test_incomplete_part_and_416_restarts(self):
        _write(self.dest + ".part", BLOB[:50])
        reg = _Registry(BLOB, "416")
        self._dl(reg)
        self.assertEqual(reg.ranges, ["bytes=50-", None])
        self.assertEqual(_read(self.dest), BLOB)

    def test_cached_layer_is_verified_by_content_every_time(self):
        _write(self.dest, BLOB)                         # cached by an older version
        _write(self.dest + ".verified", b"stamp from an earlier version")
        self.assertTrue(dacq._layer_ok(self.dest, DIGEST))
        self.assertFalse(os.path.exists(self.dest + ".verified"), "legacy stamp is dropped")
        # same size, timestamp restored: only the content differs
        st = os.stat(self.dest)
        _write(self.dest, BLOB[:-1] + b"!")
        os.utime(self.dest, ns=(st.st_atime_ns, st.st_mtime_ns))
        self.assertFalse(dacq._layer_ok(self.dest, DIGEST))
        self.assertFalse(os.path.exists(self.dest))

    def test_unsupported_digest_is_refused(self):
        with self.assertRaises(RuntimeError):
            dacq._download_blob(_Registry(BLOB), "r", "db2", "md5:abc", None, self.dest)


# --------------------------------------------------------------------------- #44, #47
class _HttpResp:
    def __init__(self, status, body=b"", headers=None):
        self.status_code, self._body, self.headers = status, body, headers or {}

    def iter_content(self, n):
        for i in range(0, len(self._body), n):
            yield self._body[i:i + n]

    def close(self):
        pass


class _Server:
    """A range-capable download server. probe_size: whether the 1-byte probe advertises
    the size; range_size: whether 206/416 replies carry it; empty_206: reply 206 with no
    body; refuse: reply 416 (no size) to every ranged request after the probe."""
    def __init__(self, data, probe_size=True, range_size=True, empty_206=False, refuse=False):
        self.data, self.probe_size, self.range_size = data, probe_size, range_size
        self.empty_206, self.refuse, self.requests = empty_206, refuse, []

    def get(self, url, headers=None, **kw):
        rng = headers["Range"]
        self.requests.append(rng)
        if len(self.requests) > 50:
            raise AssertionError("download loop did not terminate")
        a, b = (int(x) for x in rng.split("=")[1].split("-"))
        n = len(self.data)
        if rng == "bytes=0-0":
            return _HttpResp(206, self.data[:1],
                             {"Content-Range": f"bytes 0-0/{n}"} if self.probe_size else {})
        if self.refuse or a >= n:
            return _HttpResp(416, b"", {"Content-Range": f"bytes */{n}"} if self.range_size else {})
        body = b"" if self.empty_206 else self.data[a:b + 1]
        hdr = {"Content-Range": f"bytes {a}-{a + len(body) - 1}/{n}"} if self.range_size else {}
        return _HttpResp(206, body, hdr)


class MssqlDownloadTests(unittest.TestCase):
    DATA = bytes(range(256)) * 40

    def setUp(self):
        td = tempfile.TemporaryDirectory()
        self.addCleanup(td.cleanup)
        self.dest = os.path.join(td.name, "KB1.exe")

    def _dl(self, server):
        with mock.patch.object(macq.requests, "get", server.get):
            return macq.download("https://x/KB1.exe", self.dest)

    def test_plain_download(self):
        self._dl(_Server(self.DATA))
        self.assertEqual(_read(self.dest), self.DATA)

    def test_empty_partial_response_fails_instead_of_looping(self):             # #47
        srv = _Server(self.DATA, empty_206=True)
        with self.assertRaises(RuntimeError) as ctx:
            self._dl(srv)
        self.assertIn("no data", str(ctx.exception))
        self.assertLessEqual(len(srv.requests), 3)
        self.assertFalse(os.path.exists(self.dest))

    def test_416_on_an_incomplete_part_restarts_instead_of_promoting(self):    # #44
        # the bugs.md scenario: no size from the probe, and the resumed range of an
        # INCOMPLETE .part is answered 416 (no size either) — this used to rename the
        # 100-byte .part into place as the installer
        _write(self.dest + ".part", self.DATA[:100])
        srv = _Server(self.DATA, probe_size=False, range_size=False, refuse=True)
        real_get = srv.get

        def refuse_once(url, headers=None, **kw):
            if srv.refuse and headers["Range"] != "bytes=0-0":
                srv.refuse = False
                srv.requests.append(headers["Range"])
                return _HttpResp(416)
            return real_get(url, headers=headers, **kw)
        srv.get = refuse_once
        self._dl(srv)
        self.assertEqual(_read(self.dest), self.DATA)
        self.assertEqual(srv.requests[1:3], ["bytes=100-16777315", "bytes=0-16777215"])

    def test_416_without_any_size_on_resume_restarts_and_then_fails_cleanly(self):
        _write(self.dest + ".part", self.DATA[:100])
        srv = _Server(self.DATA, probe_size=False, range_size=False, refuse=True)
        with self.assertRaises(RuntimeError):
            self._dl(srv)
        self.assertFalse(os.path.exists(self.dest))

    def test_416_for_a_complete_part_is_completion(self):
        _write(self.dest + ".part", self.DATA)
        self._dl(_Server(self.DATA, probe_size=False))
        self.assertEqual(_read(self.dest), self.DATA)

    def test_part_longer_than_the_file_is_discarded(self):
        _write(self.dest + ".part", self.DATA + b"extra")
        self._dl(_Server(self.DATA))
        self.assertEqual(_read(self.dest), self.DATA)

    def test_size_only_learned_from_range_replies(self):
        self._dl(_Server(self.DATA, probe_size=False))
        self.assertEqual(_read(self.dest), self.DATA)

    def test_eof_on_a_chunk_boundary_with_no_size_anywhere(self):
        data = b"\xab" * (16 * 1024 * 1024)
        srv = _Server(data, probe_size=False, range_size=False)
        self._dl(srv)
        self.assertEqual(os.path.getsize(self.dest), len(data))
        self.assertEqual(srv.requests[-1], f"bytes={len(data)}-{2 * len(data) - 1}")


if __name__ == "__main__":
    unittest.main()
