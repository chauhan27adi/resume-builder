"""Regression tests for the remaining part of bugs.md #3: a binary present on only ONE side
(added or removed by the patch) was recorded by triage but never got function-level analysis
in Stage 2 — MSSQL/DB2 filtered their job lists to files on both sides, and Oracle only gave
an added .o a file-level verdict, ignored the removed list, and merely listed one-sided
archive members. Each now gets a one-sided function inventory: every function becomes an
added/removed card (disassembly, CVE name attribution, per-binary cap), marked with
binary_change. Drives each backend's real run()."""
import os
import tempfile
import unittest
from unittest import mock

os.environ["CVE_PATCHDIFF_WORKERS"] = "1"          # in-process, so mocks apply

import patch_differ_cli.mssql.stage2 as ms2
import patch_differ_cli.db2.stage2 as d2
import patch_differ_cli.oracle.stage2 as o2
from patch_differ_cli import _bindiff as bd_mod
from patch_differ_cli import _attribution as A
from patch_differ_cli import _results as R
from patch_differ_cli.tests.test_oracle_percall_emit_cap import _build_elf
from patch_differ_cli.tests.test_symbolless_binary_failure import _stripped_elf

CODE = b"\x90\x90\xc3"


def _w(path, data=b"\0"):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)


class _FakeSym:
    def __init__(self, *a, **k):
        self.ok = True

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def name_at(self, rva):
        return None


class _Dirs(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory(prefix="pdff_inv_")
        self.d = self._td.name
        self.p, self.f = os.path.join(self.d, "p"), os.path.join(self.d, "f")
        os.makedirs(self.p)
        os.makedirs(self.f)

    def tearDown(self):
        self._td.cleanup()


class TestMssql(_Dirs):
    def _run(self, funcs_by_path, stage0, attrib=None, use_bindiff=False):
        def func_map(path, symbolizer):
            return dict(funcs_by_path.get(os.path.normcase(path), {}))
        with mock.patch.object(ms2, "_func_map", func_map), \
                mock.patch.object(ms2.sym, "fetch_pdb", lambda *a, **k: None), \
                mock.patch.object(ms2.sym, "Symbolizer", _FakeSym), \
                mock.patch.object(ms2.sym, "server_reachable", lambda *a, **k: False), \
                mock.patch.object(ms2._AT, "load_attrib", lambda wd: attrib or []), \
                mock.patch.object(bd_mod, "diff_pair",
                                  mock.Mock(side_effect=AssertionError("no BinDiff for one-sided"))):
            return ms2.run(self.p, self.f, self.d, stage0=stage0, use_bindiff=use_bindiff)

    def test_added_dll_gets_function_cards(self):
        _w(os.path.join(self.f, "ENG_RE_new_dll_64"))
        funcs = {os.path.normcase(os.path.join(self.f, "ENG_RE_new_dll_64")): {
            "CNewGuard::CheckAuthorization": (0x1000, [(0x1000, CODE)]),
            "sub_2000": (0x2000, [(0x2000, CODE)])}}
        r = self._run(funcs, {"added": [{"name": "ENG_RE_new_dll_64", "kind": "pe"}]},
                      use_bindiff=True)
        cards = {c["object"].split(" :: ")[1]: c for c in r["readable_files"]}
        self.assertEqual(set(cards), {"CNewGuard::CheckAuthorization", "sub_2000"},
                         "unnamed functions count too in a one-sided inventory")
        for c in cards.values():
            self.assertEqual((c["change"], c["binary_change"]), ("added", "added"))
        self.assertEqual(r["counts"]["changed_functions"], 2)
        self.assertEqual(r["counts"]["failed"], 0)

    def test_removed_dll_gets_function_cards(self):
        _w(os.path.join(self.p, "ENG_RE_gone_dll_64"))
        funcs = {os.path.normcase(os.path.join(self.p, "ENG_RE_gone_dll_64")): {
            "COldThing::Run": (0x1000, [(0x1000, CODE)])}}
        r = self._run(funcs, {"removed": [{"name": "ENG_RE_gone_dll_64", "kind": "pe"}]})
        (c,) = r["readable_files"]
        self.assertEqual((c["change"], c["binary_change"]), ("removed", "removed"))

    def test_attribution_applies_to_added_functions(self):
        _w(os.path.join(self.f, "ENG_RE_new_dll_64"))
        funcs = {os.path.normcase(os.path.join(self.f, "ENG_RE_new_dll_64")): {
            "CTransferOwnershipAuthorize": (0x1000, [(0x1000, CODE)])}}
        attrib = A.build_attrib([("CVE-2025-1", "an authorization issue", "Engine", "",
                                  "CWE-285")])
        r = self._run(funcs, {"added": [{"name": "ENG_RE_new_dll_64", "kind": "pe"}]}, attrib)
        (c,) = r["readable_files"]
        self.assertEqual(c.get("cve") or c.get("cve_candidate"), "CVE-2025-1")

    def test_cap_applies(self):
        _w(os.path.join(self.f, "ENG_RE_big_dll_64"))
        funcs = {os.path.normcase(os.path.join(self.f, "ENG_RE_big_dll_64")): {
            f"F{i:04d}": (0x1000 + i * 16, [(0x1000 + i * 16, CODE)]) for i in range(ms2._EMIT_CAP + 50)}}
        r = self._run(funcs, {"added": [{"name": "ENG_RE_big_dll_64", "kind": "pe"}]})
        self.assertEqual(len(r["readable_files"]), ms2._EMIT_CAP)
        self.assertEqual(r["counts"]["changed_functions"], ms2._EMIT_CAP + 50)

    def test_added_dll_without_functions_is_a_failure(self):
        _w(os.path.join(self.f, "ENG_RE_new_dll_64"))
        r = self._run({}, {"added": [{"name": "ENG_RE_new_dll_64", "kind": "pe"}]})
        self.assertEqual(r["counts"]["failed"], 1)
        self.assertIn("fixed side", r["failed_binaries"][0]["error"])

    def test_non_pe_one_sided_files_are_not_inventoried(self):
        _w(os.path.join(self.f, "readme_sql_64"))
        r = self._run({}, {"added": [{"name": "readme_sql_64", "kind": "content"}]})
        self.assertEqual((r["readable_files"], r["counts"]["failed"]), ([], 0))


class TestDb2(_Dirs):
    def test_added_and_removed_libraries_get_function_cards(self):
        _w(os.path.join(self.f, "lib64", "libnew.so"), _build_elf([("newGuard", 0x1000, 3, CODE)]))
        _w(os.path.join(self.p, "lib64", "libgone.so"), _build_elf([("oldThing", 0x1000, 3, CODE)]))
        r = d2.run(self.p, self.f, self.d, stage0={
            "added": [{"name": "lib64/libnew.so", "kind": "native"}],
            "removed": [{"name": "lib64/libgone.so", "kind": "native"}]})
        got = {c["object"]: (c["change"], c["binary_change"]) for c in r["readable_files"]}
        self.assertEqual(got, {"lib64/libnew.so :: newGuard": ("added", "added"),
                               "lib64/libgone.so :: oldThing": ("removed", "removed")})
        self.assertEqual(r["counts"]["failed"], 0)

    def test_stripped_added_library_is_a_failure(self):
        _w(os.path.join(self.f, "lib64", "libnew.so"), _stripped_elf(CODE))
        r = d2.run(self.p, self.f, self.d, stage0={
            "added": [{"name": "lib64/libnew.so", "kind": "native"}]})
        self.assertEqual(r["counts"]["failed"], 1)

    def test_libdb2e_fallback_not_triggered_by_one_sided_only_runs(self):
        _w(os.path.join(self.f, "lib64", "libnew.so"), _build_elf([("g", 0x1000, 3, CODE)]))
        with mock.patch.object(d2, "_process_file", wraps=d2._process_file) as spy:
            d2.run(self.p, self.f, self.d, stage0={
                "added": [{"name": "lib64/libnew.so", "kind": "native"}]})
        self.assertEqual([c.args[0]["rel"] for c in spy.call_args_list], ["lib64/libnew.so"])


class TestOracle(_Dirs):
    def _run(self, stage0, members=None):
        ctx = (mock.patch.object(o2._ar, "extract_o", members) if members
               else mock.patch.object(o2, "_EMIT_CAP", o2._EMIT_CAP))
        with ctx:
            return o2.run(self.p, self.f, self.d, stage0=stage0)

    def test_added_object_gets_cards_and_file_verdict(self):
        _w(os.path.join(self.f, "lib", "new.o"), _build_elf([("newGuard", 0, 3, CODE)]))
        r = self._run({"code_changed": [{"name": "lib/new.o", "kind": "native",
                                         "change": "added", "size": 1}]})
        (c,) = r["readable_files"]
        self.assertEqual((c["change"], c["binary_change"]), ("added", "added"))
        self.assertIn("added", [b["verdict"] for b in r["binaries"]])

    def test_removed_object_from_code_removed_list(self):
        _w(os.path.join(self.p, "lib", "gone.o"), _build_elf([("oldThing", 0, 3, CODE)]))
        r = self._run({"code_removed": [{"name": "lib/gone.o", "kind": "native",
                                         "change": "removed", "size": 1}]})
        (c,) = r["readable_files"]
        self.assertEqual((c["change"], c["binary_change"]), ("removed", "removed"))
        self.assertIn("removed", [b["verdict"] for b in r["binaries"]])

    def test_one_sided_archive_members_and_whole_archives(self):
        elf_old = _build_elf([("common_fn", 0, 2, b"\x90\xc3")])
        elf_new = _build_elf([("common_fn", 0, 3, CODE)])
        files = {}
        for side, mem in (("p", {"common.o": elf_old, "gone.o": _build_elf([("goneFn", 0, 3, CODE)])}),
                          ("f", {"common.o": elf_new, "new.o": _build_elf([("newFn", 0, 3, CODE)])})):
            files[side] = {}
            for n, data in mem.items():
                path = os.path.join(self.d, side + "m", n)
                _w(path, data)
                files[side][n] = path
        _w(os.path.join(self.p, "lib", "libserver.a"), b"!<arch>\n")
        _w(os.path.join(self.f, "lib", "libserver.a"), b"!<arch>\n")
        _w(os.path.join(self.f, "lib", "libadded.a"), b"!<arch>\n")
        _w(os.path.join(self.p, "lib", "libgone.a"), b"!<arch>\n")

        def extract(path, dest):
            base = os.path.basename(path)
            side = "p" if os.sep + "p" + os.sep in path else "f"
            if base == "libserver.a":
                return files[side]
            if base == "libadded.a":
                return {"onlynew.o": files["f"]["new.o"]}
            return {"onlygone.o": files["p"]["gone.o"]}
        r = self._run({"code_changed": [
            {"name": "lib/libserver.a", "kind": "archive", "size": 1},
            {"name": "lib/libadded.a", "kind": "archive", "change": "added", "size": 1}],
            "code_removed": [{"name": "lib/libgone.a", "kind": "archive",
                              "change": "removed", "size": 1}]}, extract)
        got = {c["object"]: (c["change"], c.get("binary_change")) for c in r["readable_files"]}
        self.assertEqual(got, {
            "libserver.a!common.o :: common_fn": ("code", None),
            "libserver.a!new.o :: newFn": ("added", "added"),
            "libserver.a!gone.o :: goneFn": ("removed", "removed"),
            "libadded.a!onlynew.o :: newFn": ("added", "added"),
            "libgone.a!onlygone.o :: goneFn": ("removed", "removed")})
        self.assertEqual(r["counts"]["failed"], 0)

    def test_data_only_one_sided_member_is_not_an_error(self):
        _w(os.path.join(self.f, "lib", "data.o"), _stripped_elf(b"", e_type=1))
        r = self._run({"code_changed": [{"name": "lib/data.o", "kind": "native",
                                         "change": "added", "size": 1}]})
        self.assertEqual(r["counts"]["failed"], 0)


class TestCrossBinaryIgnoresInventories(unittest.TestCase):
    def test_added_library_copy_does_not_corroborate_a_change_elsewhere(self):
        rows = [{"object": "a.dll :: Helper", "group": "a.dll", "fix_score": 0, "change": "code"},
                {"object": "new.dll :: Helper", "group": "new.dll", "fix_score": 0,
                 "change": "added", "binary_change": "added"}]
        R.mark_cross_binary(rows)
        self.assertFalse(any(r.get("cross_binary") for r in rows))


if __name__ == "__main__":
    unittest.main()


class TestTriageToStage2EndToEnd(_Dirs):
    """The triage -> Stage 2 handoff itself: the one-sided lists triage writes are what
    Stage 2 consumes (no hand-made stage0)."""

    def test_db2(self):
        import patch_differ_cli.db2.triage as dtri
        _w(os.path.join(self.p, "lib64", "libcommon.so"), _build_elf([("c", 0x1000, 3, CODE)]))
        _w(os.path.join(self.f, "lib64", "libcommon.so"), _build_elf([("c", 0x1000, 3, CODE)]))
        _w(os.path.join(self.f, "lib64", "libnew.so"), _build_elf([("newGuard", 0x1000, 3, CODE)]))
        _w(os.path.join(self.p, "lib64", "libgone.so"), _build_elf([("oldThing", 0x1000, 3, CODE)]))
        s0 = dtri.run(self.p, self.f, self.d)
        r = d2.run(self.p, self.f, self.d, stage0=s0)
        self.assertEqual(sorted(c["object"] for c in r["readable_files"]),
                         ["lib64/libgone.so :: oldThing", "lib64/libnew.so :: newGuard"])

    def test_oracle(self):
        import patch_differ_cli.oracle.triage as otri
        _w(os.path.join(self.f, "lib", "new.o"), _build_elf([("newGuard", 0, 3, CODE)]))
        _w(os.path.join(self.p, "lib", "gone.o"), _build_elf([("oldThing", 0, 3, CODE)]))
        s0 = otri.run(self.p, self.f, self.d)
        self.assertEqual([e["name"] for e in s0["code_removed"]], ["lib/gone.o"])
        r = o2.run(self.p, self.f, self.d, stage0=s0)
        self.assertEqual(sorted(c["object"] for c in r["readable_files"]),
                         ["gone.o :: oldThing", "new.o :: newGuard"])

    def test_oracle_removed_binaries_are_not_capped_at_2000(self):
        import patch_differ_cli.oracle.triage as otri
        removed = [f"lib/r{i:04d}.o" for i in range(2100)]
        self.assertEqual(len(otri._code_removed(removed)), 2100)

    def test_mssql(self):
        import glob
        import sys
        import patch_differ_cli.mssql.triage as mtri
        pes = sorted(glob.glob(os.path.join(sys.base_prefix, "python3*.dll")))
        if not pes:
            self.skipTest("needs a real PE fixture")
        with open(pes[-1], "rb") as fh:
            _w(os.path.join(self.f, "ENG_RE_new_dll_64"), fh.read())
        s0 = mtri.run(self.p, self.f, self.d)
        self.assertEqual([(e["name"], e["kind"]) for e in s0["added"]],
                         [("ENG_RE_new_dll_64", "pe")])
        with mock.patch.object(ms2, "_func_map", lambda p, s: {"CNew::Fn": (0x1000, [(0x1000, CODE)])}), \
                mock.patch.object(ms2.sym, "fetch_pdb", lambda *a, **k: None), \
                mock.patch.object(ms2.sym, "Symbolizer", _FakeSym), \
                mock.patch.object(ms2.sym, "server_reachable", lambda *a, **k: False):
            r = ms2.run(self.p, self.f, self.d, stage0=s0)
        self.assertEqual([c["object"] for c in r["readable_files"]], ["new.dll :: CNew::Fn"])


class TestCodeChangedEntriesAreRoutedNotFiltered(_Dirs):
    """A code_changed entry present on only ONE side (e.g. a changed_files.json written by an
    older triage, reused by a Stage-2-only run) used to be dropped silently by the both-sides
    filter. It is now routed to a one-sided inventory; one present on neither side is a
    recorded failure, never a silent omission."""

    def test_db2_one_sided_code_changed_entry_is_inventoried(self):
        _w(os.path.join(self.f, "lib64", "libnew.so"), _build_elf([("newGuard", 0x1000, 3, CODE)]))
        _w(os.path.join(self.p, "lib64", "libgone.so"), _build_elf([("oldThing", 0x1000, 3, CODE)]))
        r = d2.run(self.p, self.f, self.d, stage0={"code_changed": [
            {"name": "lib64/libnew.so", "kind": "native"},
            {"name": "lib64/libgone.so", "kind": "native"}]})
        got = {c["object"]: c["binary_change"] for c in r["readable_files"]}
        self.assertEqual(got, {"lib64/libnew.so :: newGuard": "added",
                               "lib64/libgone.so :: oldThing": "removed"})

    def test_db2_entry_on_neither_side_is_a_failure(self):
        r = d2.run(self.p, self.f, self.d, stage0={"code_changed": [
            {"name": "lib64/vanished.so", "kind": "native"}]})
        self.assertEqual(r["counts"]["failed"], 1)
        self.assertEqual(r["failed_binaries"][0]["rel"], "lib64/vanished.so")

    def test_mssql_one_sided_code_changed_entry_is_inventoried(self):
        _w(os.path.join(self.f, "ENG_RE_new_dll_64"))
        with mock.patch.object(ms2, "_func_map", lambda p, s: {"CNew::Fn": (0x1000, [(0x1000, CODE)])}), \
                mock.patch.object(ms2.sym, "fetch_pdb", lambda *a, **k: None), \
                mock.patch.object(ms2.sym, "Symbolizer", _FakeSym), \
                mock.patch.object(ms2.sym, "server_reachable", lambda *a, **k: False):
            r = ms2.run(self.p, self.f, self.d,
                        stage0={"code_changed": [{"name": "ENG_RE_new_dll_64"}]})
        (c,) = r["readable_files"]
        self.assertEqual(c["binary_change"], "added")

    def test_mssql_entry_on_neither_side_is_a_failure(self):
        with mock.patch.object(ms2.sym, "server_reachable", lambda *a, **k: False):
            r = ms2.run(self.p, self.f, self.d,
                        stage0={"code_changed": [{"name": "ENG_RE_vanished_dll_64"}]})
        self.assertEqual(r["counts"]["failed"], 1)
        self.assertEqual(r["failed_binaries"][0]["rel"], "ENG_RE_vanished_dll_64")
