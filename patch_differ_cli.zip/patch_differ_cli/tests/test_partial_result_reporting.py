"""Regression tests for bugs.md #24, #28, #35, #36, #37, #38 — inputs that couldn't be
indexed, functions too large to diff, an embedded-SQL read failure, results left over from
an earlier run, and a malformed KB argument. Each used to produce a clean-looking result (or
a wrong lookup) instead of saying the analysis was incomplete.

All inputs are hand-built in TemporaryDirectory()s; no network, Ghidra or 7-Zip."""
import contextlib
import io
import json
import os
import tempfile
import unittest
from unittest import mock

import patch_differ_cli._results as R
import patch_differ_cli.cli as cli
import patch_differ_cli.db2.stage2 as d2
import patch_differ_cli.db2.triage as dt
import patch_differ_cli.mssql.acquire as macq
import patch_differ_cli.mssql.stage1 as ms1
import patch_differ_cli.mssql.stage2 as ms2
import patch_differ_cli.oracle.stage2 as o2
import patch_differ_cli.oracle.triage as ot
import patch_differ_cli.pipeline as pl
from patch_differ_cli.tests.test_silent_loss_fixes import _GLOBAL_FUNC, _elf, _write

_real_walk = os.walk


def _walk_denying(name, only_under):
    """os.walk() that reports a PermissionError for directory `name` under `only_under`
    (via onerror, as the real walk does) and doesn't descend into it."""
    def walk(top, onerror=None, **kw):
        for dp, dn, fn in _real_walk(top, **kw):
            if name in dn and os.path.abspath(only_under) in os.path.abspath(dp):
                dn.remove(name)
                err = PermissionError(13, "Access is denied", os.path.join(dp, name))
                if onerror:
                    onerror(err)
            yield dp, dn, fn
    return walk


class _Trees(unittest.TestCase):
    def setUp(self):
        td = tempfile.TemporaryDirectory()
        self.addCleanup(td.cleanup)
        self.d = td.name
        self.p, self.f, self.w = (os.path.join(self.d, x) for x in ("p", "f", "w"))
        for x in (self.p, self.f, self.w):
            os.makedirs(x, exist_ok=True)


# --------------------------------------------------------------------------- #24, #36
class OracleIndexingTests(_Trees):
    def _seed(self):
        _write(os.path.join(self.p, "rdbms", "secret", "a.sql"), b"select 1 from dual;")
        _write(os.path.join(self.f, "rdbms", "secret", "a.sql"), b"select 2 from dual;")
        _write(os.path.join(self.p, "rdbms", "ok.sql"), b"x")
        _write(os.path.join(self.f, "rdbms", "ok.sql"), b"x")

    def test_unlistable_directory_is_an_error_not_an_addition(self):
        self._seed()
        with mock.patch.object(ot.os, "walk", _walk_denying("secret", self.p)):
            r = ot.run(self.p, self.f, self.w)
        self.assertEqual([e["name"] for e in r["errors"]], ["rdbms/secret"])
        self.assertIn("prior tree could not be indexed", r["errors"][0]["error"])
        self.assertEqual(r["counts"]["added"], 0)
        self.assertEqual([e["name"] for e in r["content_changed"]], [])
        self.assertEqual(r["counts"]["identical"], 1)

    def test_missing_root_is_an_error(self):
        _write(os.path.join(self.f, "x.sql"), b"x")
        r = ot.run(os.path.join(self.d, "nope"), self.f, self.w)
        self.assertEqual([e["name"] for e in r["errors"]], ["."])
        self.assertEqual(r["counts"]["added"], 0)

    def test_stat_failure_on_one_side_is_not_an_addition(self):           # #36
        self._seed()
        real = ot.os.path.getsize
        denied = os.path.join(self.p, "rdbms", "ok.sql")

        def getsize(path):
            if os.path.normcase(os.path.abspath(path)).endswith(os.path.normcase(denied)):
                raise PermissionError(13, "Access is denied", path)
            return real(path)
        with mock.patch.object(ot.os.path, "getsize", getsize):
            r = ot.run(self.p, self.f, self.w)
        self.assertEqual([e["name"] for e in r["errors"]], ["rdbms/ok.sql"])
        self.assertEqual(r["counts"]["added"], 0)
        self.assertNotIn("rdbms/ok.sql", [e["name"] for e in r["content_changed"]])
        self.assertEqual([e["name"] for e in r["content_changed"]], ["rdbms/secret/a.sql"])

    def test_excluded_directory_failure_is_not_reported(self):
        self._seed()
        _write(os.path.join(self.p, "sqlpatch", "secret", "x.sql"), b"x")
        with mock.patch.object(ot.os, "walk",
                               _walk_denying("secret", os.path.join(self.p, "sqlpatch"))):
            r = ot.run(self.p, self.f, self.w)
        self.assertEqual(r["errors"], [])

    def test_clean_trees_unchanged(self):
        self._seed()
        _write(os.path.join(self.f, "rdbms", "new.sql"), b"new")
        r = ot.run(self.p, self.f, self.w)
        self.assertEqual((r["errors"], r["counts"]["added"]), ([], 1))


class Db2IndexingTests(_Trees):
    def test_unlistable_directory_is_an_error_not_a_removal(self):
        _write(os.path.join(self.p, "lib", "secret", "a.sh"), b"echo 1")
        _write(os.path.join(self.f, "lib", "secret", "a.sh"), b"echo 2")
        _write(os.path.join(self.f, "lib", "other.sh"), b"x")
        _write(os.path.join(self.p, "lib", "other.sh"), b"x")
        with mock.patch.object(dt.os, "walk", _walk_denying("secret", self.f)):
            r = dt.run(self.p, self.f, self.w)
        self.assertEqual([e["name"] for e in r["errors"]], ["lib/secret"])
        self.assertIn("fixed tree could not be indexed", r["errors"][0]["error"])
        self.assertEqual(r["counts"]["removed"], 0)
        self.assertEqual(r["counts"]["identical"], 1)

    def test_noise_directory_failure_is_not_reported(self):
        _write(os.path.join(self.p, "samples", "secret", "a.sh"), b"x")
        _write(os.path.join(self.f, "lib", "a.sh"), b"x")
        _write(os.path.join(self.p, "lib", "a.sh"), b"x")
        with mock.patch.object(dt.os, "walk",
                               _walk_denying("secret", os.path.join(self.p, "samples"))):
            r = dt.run(self.p, self.f, self.w)
        self.assertEqual(r["errors"], [])


# --------------------------------------------------------------------------- #28
_BIG = 300_001


def _big(fill):
    return bytes([fill]) * (_BIG - 1) + b"\xc3"


class OversizedFunctionTests(_Trees):
    def _cards(self, prior_syms, fixed_syms, rel="lib/libx.so"):
        _write(os.path.join(self.p, rel), _elf(prior_syms))
        _write(os.path.join(self.f, rel), _elf(fixed_syms))
        job = {"prior_dir": self.p, "fixed_dir": self.f, "rel": rel, "out": self.w,
               "attrib": [], "use_bindiff": False, "decompile": False,
               "disassembled_dir": self.w, "vuln_label": "v", "fixed_label": "f",
               "run_ts": "20260101T000000Z"}
        return d2._process_file(job)

    def test_changed_oversized_function_is_reported(self):
        small = ("small", _GLOBAL_FUNC, 0, b"\x90\xc3")
        r = self._cards([small, ("huge", _GLOBAL_FUNC, 0x10, _big(0x90))],
                        [small, ("huge", _GLOBAL_FUNC, 0x10, _big(0xcc))])
        self.assertTrue(r["ok"])
        self.assertEqual(r["skipped_functions"],
                         [{"rel": "lib/libx.so", "name": "huge", "prior_size": _BIG,
                           "fixed_size": _BIG}])

    def test_unchanged_oversized_function_stays_quiet(self):
        r = self._cards([("small", _GLOBAL_FUNC, 0, b"\x90\xc3"),
                         ("huge", _GLOBAL_FUNC, 0x10, _big(0x90))],
                        [("small", _GLOBAL_FUNC, 0, b"\x90\x90\xc3"),
                         ("huge", _GLOBAL_FUNC, 0x10, _big(0x90))])
        self.assertEqual(r["skipped_functions"], [])
        self.assertEqual(len(r["readable"]), 1)

    def test_function_crossing_the_limit_is_skipped_not_added_or_removed(self):
        r = self._cards([("small", _GLOBAL_FUNC, 0, b"\x90\xc3"),
                         ("grows", _GLOBAL_FUNC, 0x10, b"\x90\xc3")],
                        [("small", _GLOBAL_FUNC, 0, b"\x90\xc3"),
                         ("grows", _GLOBAL_FUNC, 0x10, _big(0x90))])
        self.assertEqual([(s["name"], s["prior_size"], s["fixed_size"])
                          for s in r["skipped_functions"]], [("grows", None, _BIG)])
        self.assertEqual([c["change"] for c in r["readable"]], [])

    def test_side_with_only_oversized_functions_is_not_called_symbol_less(self):
        r = self._cards([("huge", _GLOBAL_FUNC, 0, _big(0x90))],
                        [("huge", _GLOBAL_FUNC, 0, _big(0xcc))])
        self.assertTrue(r["ok"], r.get("error"))
        self.assertEqual([s["name"] for s in r["skipped_functions"]], ["huge"])

    def test_db2_run_counts_skipped_functions_and_cli_flags_them(self):
        rel = "lib/libx.so"
        small = ("small", _GLOBAL_FUNC, 0, b"\x90\xc3")
        _write(os.path.join(self.p, rel), _elf([small, ("huge", _GLOBAL_FUNC, 0x10, _big(1))]))
        _write(os.path.join(self.f, rel), _elf([small, ("huge", _GLOBAL_FUNC, 0x10, _big(2))]))
        res = d2.run(self.p, self.f, self.w,
                     stage0={"code_changed": [{"name": rel, "size": 1, "route": "stage2"}]})
        self.assertEqual(res["counts"]["functions_skipped"], 1)
        self.assertEqual(res["skipped_functions"][0]["name"], "huge")
        self.assertEqual(cli._summarize_partial_failures({"stage2": res}),
                         [("stage2", "changed function(s) too large to diff "
                                     "(see skipped_functions)", 1)])

    def test_oracle_diff_o_reports_skipped_functions(self):
        _write(os.path.join(self.p, "a.o"), _elf([("small", _GLOBAL_FUNC, 0, b"\x90\xc3"),
                                                ("huge", _GLOBAL_FUNC, 0x10, _big(1))],
                                               et_rel=True))
        _write(os.path.join(self.f, "a.o"), _elf([("small", _GLOBAL_FUNC, 0, b"\x90\xc3"),
                                                ("huge", _GLOBAL_FUNC, 0x10, _big(2))],
                                               et_rel=True))
        skipped = []
        o2._diff_o("a.o", "a.o", os.path.join(self.p, "a.o"), os.path.join(self.f, "a.o"),
                   self.w, [], attrib=[], disassembled_dir=self.w, run_ts="t", skipped=skipped)
        self.assertEqual([(s["object"], s["name"]) for s in skipped], [("a.o", "huge")])

    def test_mssql_func_map_records_oversized_functions(self):
        class Img:
            groups = {0x1000: [(0x1000, 0x1002)], 0x2000: [(0x2000, 0x2000 + _BIG)]}

            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

            def bytes_at(self, rva, n):
                return b"\x90" * n

        with mock.patch.object(ms2, "FuncImage", lambda path: Img()):
            m = ms2._func_map("x.dll", None)
        self.assertEqual(sorted(m), ["sub_1000"])
        self.assertEqual([s for s, _d in m.oversized["sub_2000"]], [_BIG])

    def test_unnamed_one_sided_oversized_is_layout_noise(self):
        P, F = ms2._FuncMap(), ms2._FuncMap()
        F.oversized = {"sub_2000": [(_BIG, "d1")]}
        self.assertEqual(R.skipped_oversized(P, F), [])
        self.assertEqual(len(R.skipped_oversized(P, F, one_sided="added")), 1)


# --------------------------------------------------------------------------- #35
class EmbeddedSqlErrorTests(_Trees):
    def test_extraction_read_failure_is_recorded(self):
        for side in (self.p, self.f):
            _write(os.path.join(side, "sqlscriptupgrade.dll"),
                   b"MZ" + b"\0" * 62 + "SELECT name FROM sys.objects".encode("utf-16-le"))
        real = ms1._extract_strings

        def extract(path, *a, **k):
            if path.startswith(self.f):
                raise PermissionError(13, "Access is denied", path)
            return real(path, *a, **k)
        errors = []
        with mock.patch.object(ms1, "_extract_strings", extract):
            cards = ms1._embedded_sql(self.p, self.f, self.w, [], errors)
        self.assertEqual(cards, [])
        self.assertEqual([e["name"] for e in errors], ["sqlscriptupgrade.dll"])
        self.assertIn("embedded T-SQL not extracted", errors[0]["error"])

    def test_default_errors_argument_still_works(self):
        self.assertEqual(ms1._embedded_sql(self.p, self.f, self.w, []), [])


# --------------------------------------------------------------------------- #37
class StaleResultTests(_Trees):
    def _tree(self, root, text):
        _write(os.path.join(root, "rdbms", "admin", "x.sql"), text.encode())

    def _run(self, stages):
        with contextlib.redirect_stdout(io.StringIO()):
            return pl.run_pipeline("oracle", self.p, self.f, self.w, stages=stages,
                                   verbose=False)

    def _plant_stage2(self, marker="OLD_BUILD :: old_function"):
        p = os.path.join(self.w, "stage2", "functions_diff.json")
        with open(p, encoding="utf-8") as fh:
            r = json.load(fh)
        r["readable_files"] = [{"object": marker}]
        with open(p, "w", encoding="utf-8") as fh:
            json.dump(r, fh)

    def test_stage_limited_run_hides_the_older_later_stage(self):
        self._tree(self.p, "select 1 from dual;")
        self._tree(self.f, "select 2 from dual;")
        self._run(("triage", "stage1", "stage2"))
        self._plant_stage2()
        self._tree(self.f, "select 3 from dual; -- a different fixed build")
        self._run(("triage", "stage1"))
        stale = []
        loaded = pl.load_result(self.w, stale=stale)
        self.assertEqual(sorted(loaded), ["stage1", "triage"])
        self.assertEqual([s for s, _r in stale], ["stage2"])

    def test_separate_stage_runs_on_the_same_inputs_are_both_current(self):
        self._tree(self.p, "select 1 from dual;")
        self._tree(self.f, "select 2 from dual;")
        self._run(("triage", "stage1"))
        self._run(("triage", "stage2"))
        stale = []
        self.assertEqual(sorted(pl.load_result(self.w, stale=stale)),
                         ["stage1", "stage2", "triage"])
        self.assertEqual(stale, [])

    def test_failed_stage_does_not_leave_its_old_result_current(self):
        self._tree(self.p, "select 1 from dual;")
        self._tree(self.f, "select 2 from dual;")
        self._run(("triage", "stage1", "stage2"))
        with mock.patch.object(o2, "run", side_effect=RuntimeError("boom")):
            with self.assertRaises(RuntimeError):
                self._run(("triage", "stage2"))
        self.assertNotIn("stage2", pl.load_result(self.w))

    def test_output_dir_from_an_older_version_is_read_as_is(self):
        for st, fn in (("stage0", "changed_files.json"), ("stage2", "functions_diff.json")):
            _write(os.path.join(self.w, st, fn), b'{"counts": {}}')
        self.assertEqual(sorted(pl.load_result(self.w)), ["stage2", "triage"])

    def test_show_notes_the_hidden_stale_stage(self):
        self._tree(self.p, "select 1 from dual;")
        self._tree(self.f, "select 2 from dual;")
        self._run(("triage", "stage1", "stage2"))
        self._tree(self.f, "select 3 from dual;")
        self._run(("triage",))
        err = io.StringIO()
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(err):
            try:
                cli.main(["show", "--out", self.w])
            except SystemExit as e:
                self.assertIn(e.code, (0, None))
        self.assertIn("NOTE: stage1 result", err.getvalue())
        self.assertIn("NOTE: stage2 result", err.getvalue())

    def test_triage_output_is_deterministic_for_the_same_inputs(self):
        for backend in ("oracle", "db2"):
            self._tree(self.p, "select 1 from dual;")
            self._tree(self.f, "select 2 from dual;")
            with contextlib.redirect_stdout(io.StringIO()):
                pl.run_pipeline(backend, self.p, self.f, self.w, stages=("triage",),
                                verbose=False)
                a = pl._stage0_digest(self.w)
                pl.run_pipeline(backend, self.p, self.f, self.w, stages=("triage",),
                                verbose=False)
            self.assertEqual(a, pl._stage0_digest(self.w), backend)


# --------------------------------------------------------------------------- #38
class KbNormalizationTests(unittest.TestCase):
    def test_accepted_forms(self):
        for kb in ("KB5084815", "kb5084815", " KB5084815 ", "5084815", 5084815, "KB 5084815"):
            self.assertEqual(macq.normalize_kb(kb), "5084815", kb)
            self.assertEqual(pl._normalize_kb(kb), "5084815", kb)

    def test_absent(self):
        for kb in (None, "", "   "):
            self.assertIsNone(pl._normalize_kb(kb))

    def test_malformed_is_rejected(self):
        for kb in ("KBKB5084815", "BK5084815", "KB50848a5", "5084815x", "KB", "５０８４"):
            with self.assertRaises(ValueError, msg=kb):
                pl._normalize_kb(kb)


if __name__ == "__main__":
    unittest.main()
