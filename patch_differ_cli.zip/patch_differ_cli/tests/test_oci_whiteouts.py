"""Regression tests for bugs.md #2: DB2 _extract_layers() matched a whiteout only against one
exact file path, so a DIRECTORY whiteout left that directory's lower-layer files in place,
and opaque-directory markers (.wh..wh..opq) were ignored entirely — files deleted by a later
layer leaked into the reconstructed tree. Layers are listed oldest -> newest."""
import gzip
import io
import os
import tarfile
import tempfile
import unittest

import patch_differ_cli.db2.acquire as A

V = "opt/ibm/db2/V11.5/"


def _layer(d, idx, members):
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w") as tf:
        for name, data in members:
            ti = tarfile.TarInfo(name)
            ti.size = len(data)
            tf.addfile(ti, io.BytesIO(data))
    p = os.path.join(d, f"layer{idx}.tar.gz")
    with open(p, "wb") as fh:
        fh.write(gzip.compress(buf.getvalue()))
    return p


class TestWhiteouts(unittest.TestCase):
    def _extract(self, layers):
        with tempfile.TemporaryDirectory(prefix="pdff_oci_") as d:
            paths = [_layer(d, i, m) for i, m in enumerate(layers)]
            dest = os.path.join(d, "root")
            A._extract_layers(paths, dest, A._SUBTREE)
            out = {}
            for dp, _dn, files in os.walk(dest):
                for f in files:
                    p = os.path.join(dp, f)
                    rel = os.path.relpath(p, os.path.join(dest, V)).replace("\\", "/")
                    with open(p, "rb") as fh:
                        out[rel] = fh.read()
            return out

    def test_file_whiteout(self):
        got = self._extract([[(V + "a.txt", b"1"), (V + "keep.txt", b"k")],
                             [(V + ".wh.a.txt", b"")]])
        self.assertEqual(got, {"keep.txt": b"k"})

    def test_directory_whiteout_hides_everything_beneath(self):
        got = self._extract([[(V + "deldir/a.txt", b"1"), (V + "deldir/sub/b.txt", b"2"),
                              (V + "keep.txt", b"k")],
                             [(V + ".wh.deldir", b"")]])
        self.assertEqual(got, {"keep.txt": b"k"})

    def test_directory_whiteout_does_not_hide_similarly_named_siblings(self):
        got = self._extract([[(V + "deldir/a.txt", b"1"), (V + "deldir2/x.txt", b"2")],
                             [(V + ".wh.deldir", b"")]])
        self.assertEqual(got, {"deldir2/x.txt": b"2"})

    def test_opaque_dir_hides_lower_contents_keeps_its_own(self):
        got = self._extract([[(V + "opqdir/old.txt", b"old"), (V + "keep.txt", b"k")],
                             [(V + "opqdir/.wh..wh..opq", b""), (V + "opqdir/new.txt", b"new")]])
        self.assertEqual(got, {"keep.txt": b"k", "opqdir/new.txt": b"new"})

    def test_whiteout_never_hides_its_own_layer(self):
        # marker listed BEFORE the same layer's file in the tar stream
        got = self._extract([[(V + "d/old.txt", b"old")],
                             [(V + "d/.wh..wh..opq", b""), (V + "d/new.txt", b"new"),
                              (V + ".wh.gone", b""), (V + "gone", b"recreated")]])
        self.assertEqual(got, {"d/new.txt": b"new", "gone": b"recreated"})

    def test_newer_layer_readds_after_lower_whiteout(self):
        got = self._extract([[(V + "f.txt", b"v1")],
                             [(V + ".wh.f.txt", b"")],
                             [(V + "f.txt", b"v3")]])
        self.assertEqual(got, {"f.txt": b"v3"})

    def test_parent_of_subtree_whiteout_hides_all(self):
        got = self._extract([[(V + "a.txt", b"1")], [("opt/ibm/.wh.db2", b"")]])
        self.assertEqual(got, {})


if __name__ == "__main__":
    unittest.main()
