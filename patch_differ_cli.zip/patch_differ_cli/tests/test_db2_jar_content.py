"""Regression tests for bugs.md #16: DB2 Stage 1 compared bundled jars by version string only
and skipped any pair whose versions matched (including both absent), so a library code change
shipped without a version bump was omitted. Also covers the follow-up: the jar index kept
only the FIRST jar per artifact stem, so a second copy of a library was never compared."""
import os
import tempfile
import time
import unittest
import zipfile

import patch_differ_cli.db2.stage1 as S


def _jar(path, classes, manifest="Manifest-Version: 1.0\n", date=(2020, 1, 1, 0, 0, 0)):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with zipfile.ZipFile(path, "w") as z:
        z.writestr(zipfile.ZipInfo("META-INF/MANIFEST.MF", date), manifest)
        for name, data in classes.items():
            z.writestr(zipfile.ZipInfo(name, date), data)


class _Harness(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory(prefix="pdff_jar_")
        self.d = self._td.name
        self.p, self.f = os.path.join(self.d, "p"), os.path.join(self.d, "f")

    def tearDown(self):
        self._td.cleanup()

    def run_s1(self):
        r = S.run(self.p, self.f, self.d)
        return [c for c in r["readable_files"] if c["kind"] == "dependency"], r


class TestJarContent(_Harness):
    def test_same_unversioned_name_different_classes_is_reported(self):
        _jar(os.path.join(self.p, "java", "dependency.jar"), {"Example.class": b"AAAA"})
        _jar(os.path.join(self.f, "java", "dependency.jar"), {"Example.class": b"BBBB"})
        deps, _ = self.run_s1()
        self.assertEqual(len(deps), 1)
        self.assertEqual(deps[0]["change"], "content-changed")
        with open(os.path.join(self.d, "stage1", deps[0]["pair"]), encoding="utf-8") as fh:
            self.assertIn("Example.class", fh.read())

    def test_same_version_in_manifest_different_classes_is_reported(self):
        man = "Manifest-Version: 1.0\nImplementation-Version: 1.2\n"
        _jar(os.path.join(self.p, "java", "lib.jar"), {"A.class": b"1"}, man)
        _jar(os.path.join(self.f, "java", "lib.jar"), {"A.class": b"2"}, man)
        deps, _ = self.run_s1()
        self.assertEqual([d["change"] for d in deps], ["content-changed"])

    def test_rebuild_only_noise_is_not_reported(self):
        # same class bytes; different timestamps and a manifest build-date line
        _jar(os.path.join(self.p, "java", "lib.jar"), {"A.class": b"same"},
             "Manifest-Version: 1.0\nBuilt-Date: 2020\n", (2020, 1, 1, 0, 0, 0))
        _jar(os.path.join(self.f, "java", "lib.jar"), {"A.class": b"same"},
             "Manifest-Version: 1.0\nBuilt-Date: 2026\n", (2026, 5, 5, 5, 5, 6))
        deps, _ = self.run_s1()
        self.assertEqual(deps, [])

    def test_version_bump_still_reported_as_bump(self):
        _jar(os.path.join(self.p, "java", "commons-x-2.10.1.jar"), {"A.class": b"1"})
        _jar(os.path.join(self.f, "java", "commons-x-2.15.0.jar"), {"A.class": b"2"})
        deps, _ = self.run_s1()
        self.assertEqual([d["change"] for d in deps], ["bumped"])


class TestDuplicateStems(_Harness):
    def test_second_copy_of_an_artifact_is_compared_too(self):
        for sub in ("java", "tools/lib"):
            _jar(os.path.join(self.p, sub, "dep.jar"), {"A.class": b"old"})
        _jar(os.path.join(self.f, "java", "dep.jar"), {"A.class": b"old"})      # unchanged
        _jar(os.path.join(self.f, "tools/lib", "dep.jar"), {"A.class": b"new"})  # changed
        deps, _ = self.run_s1()
        self.assertEqual(len(deps), 1)
        self.assertEqual(deps[0]["src"], "tools/lib/dep.jar")

    def test_both_copies_changed_get_distinct_card_files(self):
        for sub in ("java", "tools/lib"):
            _jar(os.path.join(self.p, sub, "dep.jar"), {"A.class": b"old"})
            _jar(os.path.join(self.f, sub, "dep.jar"), {"A.class": b"new-" + sub.encode()})
        deps, _ = self.run_s1()
        self.assertEqual(len(deps), 2)
        self.assertEqual(len({d["pair"] for d in deps}), 2)

    def test_jar_moved_directory_in_a_bump_still_pairs(self):
        _jar(os.path.join(self.p, "java", "commons-x-2.10.1.jar"), {"A.class": b"1"})
        _jar(os.path.join(self.f, "java/ext", "commons-x-2.15.0.jar"), {"A.class": b"2"})
        deps, _ = self.run_s1()
        self.assertEqual([d["change"] for d in deps], ["bumped"])


if __name__ == "__main__":
    unittest.main()
