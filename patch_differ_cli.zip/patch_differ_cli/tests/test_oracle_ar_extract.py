"""Regression tests for bugs.md #9: oracle/_ar.extract_o() flattened member names
("/" -> "_") for its output files, so "a/b.o" and "a_b.o" — and duplicate member names, which
`ar q` allows — overwrote each other: the later member's bytes were analyzed under both
names and the earlier member vanished. Also covers BSD "#1/<len>" long names, which used to
be skipped without a trace."""
import os
import tempfile
import unittest

from patch_differ_cli.oracle import _ar


def _hdr(name_field, size):
    return (name_field.ljust(16) + "0".ljust(12) + "0".ljust(6) + "0".ljust(6)
            + "644".ljust(8) + str(size).ljust(10) + "`\n").encode("latin-1")


def _gnu_archive(members):
    """GNU ar: names > 15 chars or containing '/' go through the '//' long-name table."""
    table, entries = b"", []
    for name, body in members:
        if len(name) > 15 or "/" in name:
            off = len(table)
            table += name.encode() + b"/\n"
            entries.append((f"/{off}", body))
        else:
            entries.append((name + "/", body))
    out = b"!<arch>\n"
    if table:
        out += _hdr("//", len(table)) + table + (b"\n" if len(table) & 1 else b"")
    for field, body in entries:
        out += _hdr(field, len(body)) + body + (b"\n" if len(body) & 1 else b"")
    return out


def _bsd_archive(members):
    out = b"!<arch>\n"
    for name, body in members:
        nb = name.encode()
        payload = nb + body
        out += _hdr(f"#1/{len(nb)}", len(payload)) + payload + (b"\n" if len(payload) & 1 else b"")
    return out


class TestExtractO(unittest.TestCase):
    def _extract(self, blob):
        d = tempfile.mkdtemp(prefix="pdff_ar_")
        self.addCleanup(lambda: __import__("shutil").rmtree(d, ignore_errors=True))
        a = os.path.join(d, "lib.a")
        with open(a, "wb") as fh:
            fh.write(blob)
        m = _ar.extract_o(a, os.path.join(d, "out"))
        return {k: open(v, "rb").read() for k, v in m.items()}, m

    def test_flattened_name_collision_keeps_both_members(self):
        got, m = self._extract(_gnu_archive([("a/b.o", b"FIRST"), ("a_b.o", b"SECOND")]))
        self.assertEqual(got, {"a/b.o": b"FIRST", "a_b.o": b"SECOND"})
        self.assertEqual(len(set(m.values())), 2)

    def test_duplicate_member_names_are_both_kept_in_order(self):
        got, _m = self._extract(_gnu_archive([("util.o", b"ONE"), ("util.o", b"TWO")]))
        self.assertEqual(got, {"util.o": b"ONE", "util.o#2": b"TWO"})

    def test_case_only_difference_does_not_collide(self):
        got, m = self._extract(_gnu_archive([("Foo.o", b"UPPER"), ("foo.o", b"lower")]))
        self.assertEqual(got, {"Foo.o": b"UPPER", "foo.o": b"lower"})
        self.assertEqual(len(set(m.values())), 2)

    def test_bsd_long_names_are_decoded(self):
        got, _m = self._extract(_bsd_archive([("__.SYMDEF SORTED", b"symtab"),
                                              ("a_rather_long_member_name.o", b"BODY")]))
        self.assertEqual(got, {"a_rather_long_member_name.o": b"BODY"})

    def test_plain_archive_unchanged(self):
        got, _m = self._extract(_gnu_archive([("kkz.o", b"K"), ("kkzd.o", b"D")]))
        self.assertEqual(got, {"kkz.o": b"K", "kkzd.o": b"D"})


if __name__ == "__main__":
    unittest.main()
