"""Regression tests for bugs.md #57, #58, #59:

  #57  a --use-bindiff run that fell back to name matching was only a stderr print;
  #58  MSSQL with a PDB for one build only reported every function as "removed" and never
       diffed the real change, in a result marked ok;
  #59  DB2 triage counted an ELF with a same-size, data-only change as identical.

BinDiff, PDBs and PE parsing are faked. Scratch files live in TemporaryDirectory()s only."""
import os
import tempfile
import unittest
from unittest import mock

import patch_differ_cli._bindiff as bd
import patch_differ_cli.cli as cli
import patch_differ_cli.db2.stage2 as d2
import patch_differ_cli.db2.triage as dt
import patch_differ_cli.mssql.stage2 as ms2
import patch_differ_cli.oracle.stage2 as o2
from patch_differ_cli.tests.test_silent_loss_fixes import _GLOBAL_FUNC, _elf, _write


def _boom(*a, **k):
    raise RuntimeError("Ghidra BinExport failed (REPORT SCRIPT ERROR)")


def _db2_job(d, use_bindiff=True):
    rel = "lib/libx.so"
    p, f, out = (os.path.join(d, x) for x in ("p", "f", "out"))
    _write(os.path.join(p, rel), _elf([("fn", _GLOBAL_FUNC, 0, b"\x90\xc3")]))
    _write(os.path.join(f, rel), _elf([("fn", _GLOBAL_FUNC, 0, b"\x90\x90\xc3")]))
    os.makedirs(out, exist_ok=True)
    return {"prior_dir": p, "fixed_dir": f, "rel": rel, "out": out, "attrib": [],
            "use_bindiff": use_bindiff, "decompile": False, "disassembled_dir": out,
            "vuln_label": "v", "fixed_label": "f", "run_ts": "t"}


# --------------------------------------------------------------------------- #57
class BindiffFallbackReportingTests(unittest.TestCase):
    def test_db2_worker_and_run_record_the_fallback(self):
        with tempfile.TemporaryDirectory() as d, mock.patch.object(bd, "diff_pair", _boom):
            job = _db2_job(d)
            r = d2._process_file(job)
            self.assertEqual(r["bindiff_fallback"]["rel"], "lib/libx.so")
            self.assertIn("REPORT SCRIPT ERROR", r["bindiff_fallback"]["reason"])
            self.assertEqual([c["match_algorithm"] for c in r["readable"]], ["name"])
            with mock.patch.dict(os.environ, {"CVE_PATCHDIFF_WORKERS": "1"}):
                res = d2.run(job["prior_dir"], job["fixed_dir"], os.path.join(d, "w"),
                             stage0={"code_changed": [{"name": "lib/libx.so", "size": 1}]},
                             use_bindiff=True)
        self.assertEqual(res["counts"]["bindiff_fallbacks"], 1)
        self.assertEqual([b["rel"] for b in res["bindiff_fallbacks"]], ["lib/libx.so"])
        problems = cli._summarize_partial_failures({"stage2": res})
        self.assertTrue(any("fell back to name matching" in label for _s, label, _n in problems))

    def test_no_fallback_recorded_when_bindiff_was_not_requested_or_worked(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertIsNone(d2._process_file(_db2_job(d, use_bindiff=False))["bindiff_fallback"])
        base = d2._GHIDRA_ELF_PIE_BASE        # _elf() builds ET_DYN images
        worked = {base: bd.FuncMatch(base, base, 0.9, 0.9, "fn", "fn")}
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(bd, "diff_pair", lambda *a, **k: worked):
            r = d2._process_file(_db2_job(d))
        self.assertIsNone(r["bindiff_fallback"])
        self.assertEqual([c["match_algorithm"] for c in r["readable"]], ["bindiff"])

    def test_zero_matches_for_functions_on_both_sides_is_a_fallback(self):
        # (#60/#61) an empty or unresolvable match set would make every function a phantom
        # added/removed card — it's a BinDiff failure, recorded, and name matching is used
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(bd, "diff_pair", lambda *a, **k: {}):
            r = d2._process_file(_db2_job(d))
        self.assertIn("resolved to a known function", r["bindiff_fallback"]["reason"])
        self.assertEqual([c["match_algorithm"] for c in r["readable"]], ["name"])

    def test_mssql_worker_records_the_fallback(self):
        r = _mssql_run(symbolized=("prior", "fixed"), use_bindiff=True, diff_pair=_boom)
        self.assertTrue(r["ok"])
        self.assertIn("REPORT SCRIPT ERROR", r["bindiff_fallback"]["reason"])

    def test_oracle_records_the_fallback_including_a_refused_mapping(self):
        P = {"fn": (0x0, b"\x90\xc3")}
        F = {"fn": (0x0, b"\x90\x90\xc3")}
        with tempfile.TemporaryDirectory() as out, \
                mock.patch.object(o2, "_func_map", lambda path: dict(P if path == "PRIOR" else F)), \
                mock.patch.object(o2, "_func_sections", lambda path: {".text", ".text.unlikely"}):
            fallbacks = []
            o2._diff_o("x.o", "lib/x.a", "PRIOR", "FIXED", out, [], attrib=[],
                       use_bindiff=True, disassembled_dir=out, run_ts="t",
                       bindiff_fallbacks=fallbacks)
        self.assertEqual([(b["object"], b["src"]) for b in fallbacks], [("x.o", "lib/x.a")])
        self.assertIn("multiple .text", fallbacks[0]["reason"])


# --------------------------------------------------------------------------- #58
CODE = {0x1000: b"\x90\xc3", 0x1010: b"\x81\xff\x00\x01\x00\x00\x73\x03\x31\xc0\xc3",
        0x1030: b"\x31\xc0\xc3"}
FIXED = {**CODE, 0x1010: b"\x81\xff\xff\x00\x00\x00\x73\x03\x31\xc0\xc3"}
NAMES = {0x1000: "Init", 0x1010: "CheckLength", 0x1030: "Release"}


def _mssql_run(symbolized, use_bindiff=False, diff_pair=None):
    class Sym:
        def __init__(self, path, pdb):
            self.ok = ("prior" if "prior" in path else "fixed") in symbolized

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def exact_name(self, rva):
            return NAMES.get(rva) if self.ok else None

        def name_at(self, rva):
            return NAMES.get(rva) if self.ok else None

    class PE:
        class OPTIONAL_HEADER:
            ImageBase = 0

        def __init__(self, *a, **k):
            pass

        def close(self):
            pass

    def func_map(path, s):
        m = ms2._FuncMap()
        for rva, c in (CODE if "prior" in path else FIXED).items():
            nm = s.exact_name(rva) if (s and s.ok) else None
            m[nm or "sub_%x" % rva] = (rva, [(rva, c)])
        return m

    with tempfile.TemporaryDirectory() as d:
        for side in ("prior", "fixed"):
            _write(os.path.join(d, side, "ENG_RE_sqlmin_dll_64"), b"MZ")
        out = os.path.join(d, "out")
        os.makedirs(out)
        job = {"prior_dir": os.path.join(d, "prior"), "fixed_dir": os.path.join(d, "fixed"),
               "rel": "ENG_RE_sqlmin_dll_64", "out": out, "attrib": [], "online": False,
               "pdb_cache": d, "use_bindiff": use_bindiff, "decompile": False,
               "decompile_cache": d, "decompiled_c_dir": d, "disassembled_dir": out,
               "run_ts": "t", "vuln_label": "v", "fixed_label": "f", "one_sided": None}
        patches = [mock.patch.object(ms2.sym, "fetch_pdb", lambda *a, **k: None),
                   mock.patch.object(ms2.sym, "Symbolizer", Sym),
                   mock.patch.object(ms2, "_func_map", func_map),
                   mock.patch.object(ms2._pefile, "PE", PE)]
        if diff_pair is not None:
            patches.append(mock.patch.object(bd, "diff_pair", diff_pair))
        for p in patches:
            p.start()
        try:
            return ms2._process_dll(job)
        finally:
            for p in patches:
                p.stop()


class OneSidedPdbTests(unittest.TestCase):
    def _cards(self, r):
        return [(c["object"], c["change"]) for c in r["readable"]]

    def test_pdb_for_the_prior_build_only(self):
        r = _mssql_run(symbolized=("prior",))
        self.assertEqual(self._cards(r), [("sqlmin.dll :: sub_1010", "const")],
                         "the real change must be diffed, nothing reported as removed")
        self.assertFalse(r["ok"])
        self.assertIn("prior build only", r["error"])
        self.assertFalse(r["symbolized"])

    def test_pdb_for_the_fixed_build_only(self):
        r = _mssql_run(symbolized=("fixed",))
        self.assertEqual(self._cards(r), [("sqlmin.dll :: sub_1010", "const")])
        self.assertIn("fixed build only", r["error"])

    def test_both_sides_symbolized_is_unchanged(self):
        r = _mssql_run(symbolized=("prior", "fixed"))
        self.assertEqual(self._cards(r), [("sqlmin.dll :: CheckLength", "const")])
        self.assertTrue(r["ok"])
        self.assertTrue(r["symbolized"])

    def test_neither_side_symbolized_is_unchanged(self):
        r = _mssql_run(symbolized=())
        self.assertEqual(self._cards(r), [("sqlmin.dll :: sub_1010", "const")])
        self.assertTrue(r["ok"])


# --------------------------------------------------------------------------- #59
class Db2DataOnlyElfChangeTests(unittest.TestCase):
    def test_same_size_data_only_change_is_rebuild_only_not_identical(self):
        with tempfile.TemporaryDirectory() as d:
            p, f, w = (os.path.join(d, x) for x in "pfw")
            os.makedirs(w)
            _write(os.path.join(p, "lib", "libx.so"), _elf([("check_admin", _GLOBAL_FUNC, 0, b"\x90\xc3")]))
            _write(os.path.join(f, "lib", "libx.so"), _elf([("check_guest", _GLOBAL_FUNC, 0, b"\x90\xc3")]))
            _write(os.path.join(p, "lib", "same.so"), _elf([("f", _GLOBAL_FUNC, 0, b"\x90\xc3")]))
            _write(os.path.join(f, "lib", "same.so"), _elf([("f", _GLOBAL_FUNC, 0, b"\x90\xc3")]))
            r = dt.run(p, f, w)
        self.assertEqual(r["rebuild_only"], ["lib/libx.so"])
        self.assertEqual(r["counts"]["identical"], 1, "byte-identical ELF stays identical")
        self.assertEqual(r["counts"]["code_changed"], 0)

    def test_code_change_is_still_code_changed(self):
        with tempfile.TemporaryDirectory() as d:
            p, f, w = (os.path.join(d, x) for x in "pfw")
            os.makedirs(w)
            _write(os.path.join(p, "lib", "libx.so"), _elf([("f", _GLOBAL_FUNC, 0, b"\x90\xc3")]))
            _write(os.path.join(f, "lib", "libx.so"), _elf([("f", _GLOBAL_FUNC, 0, b"\xcc\xc3")]))
            r = dt.run(p, f, w)
        self.assertEqual([e["name"] for e in r["code_changed"]], ["lib/libx.so"])


if __name__ == "__main__":
    unittest.main()
