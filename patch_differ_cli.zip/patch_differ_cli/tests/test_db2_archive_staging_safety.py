"""db2_bugs.md DB2-1 / DB2-25: a Fix Central archive placed in patches/db2/{vuln,fixed} must
be extracted, never diffed as a plain file, even with placeholder files beside it; and the
staged copy must always be the user's current archive (a stale same-size copy made the
acquire cache reuse the previous build's tree)."""
import gzip
import io
import os
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from patch_differ_cli import pipeline as pl
from patch_differ_cli.db2 import acquire as db2acq

VULN = "update_90467_v11.5.9_linuxx64_universal_fixpack.tar.gz"
FIXED = "update_94236_v11.5.9_linuxx64_universal_fixpack.tar.gz"
LIB = "opt/ibm/db2/V11.5/lib64/libdb2x.so.1"


def _write_tar(path, payload, mtime=1700000000):
    """An uncompressed fixpack-like tar: same-length payloads give same-size archives."""
    tmp = str(path) + ".new"
    with tarfile.open(tmp, "w") as t:
        info = tarfile.TarInfo(LIB)
        info.size = len(payload)
        info.mtime = mtime
        t.addfile(info, io.BytesIO(payload))
    os.replace(tmp, path)               # a new file (new inode), as a re-download would be
    os.utime(path, (mtime, mtime))


class TestSidecarsDoNotHideTheArchive(unittest.TestCase):
    def test_archive_beside_placeholders_is_detected(self):
        for sidecars in (["desktop.ini"], ["Desktop.ini", "Thumbs.db", ".gitkeep"]):
            with tempfile.TemporaryDirectory() as d:
                (Path(d) / VULN).write_bytes(b"x")
                for s in sidecars:
                    (Path(d) / s).write_bytes(b"[.ShellClassInfo]")
                self.assertEqual(pl._db2_archive_only(d).name, VULN, sidecars)

    def test_flat_drop_with_stray_files_is_refused(self):
        for stray in ("README.txt", VULN + ".tmp", "notes.docx"):
            with tempfile.TemporaryDirectory() as d:
                (Path(d) / VULN).write_bytes(b"x")
                (Path(d) / stray).write_bytes(b"y")
                with self.assertRaises(ValueError) as cm:
                    pl._db2_archive_only(d)
                self.assertIn(stray, str(cm.exception))

    def test_extracted_tree_is_still_used_as_is(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / "lib64").mkdir()
            (Path(d) / "lib64" / "libdb2e.so.1").write_bytes(b"x")
            (Path(d) / "desktop.ini").write_bytes(b"x")
            self.assertIsNone(pl._db2_archive_only(d))
            self.assertFalse(pl._db2_only_sidecars(d))
            (Path(d) / VULN).write_bytes(b"x")         # a tree that also holds an archive
            self.assertIsNone(pl._db2_archive_only(d))

    def test_several_archives_with_a_placeholder_are_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / VULN).write_bytes(b"x")
            (Path(d) / FIXED).write_bytes(b"y")
            (Path(d) / "desktop.ini").write_bytes(b"z")
            with self.assertRaises(ValueError):
                pl._db2_archive_only(d)

    def test_placeholder_only_folder_counts_as_empty(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertFalse(pl._db2_only_sidecars(d))          # truly empty: not this case
            (Path(d) / "desktop.ini").write_bytes(b"x")
            self.assertTrue(pl._db2_only_sidecars(d))
            self.assertIsNone(pl._db2_archive_only(d))
            self.assertFalse(pl._db2_only_sidecars(Path(d) / "missing"))


class TestRunPipelineWithPlaceholders(unittest.TestCase):
    def _run(self, d, vuln_url=None, fixed_url=None):
        seen = {}

        def fake_acquire(out_dir, vuln_url, fixed_url, verbose, sides):
            seen.update(vuln_url=vuln_url, fixed_url=fixed_url, sides=set(sides))
            return {s: str(Path(d) / ("x" + s)) for s in sides}

        with mock.patch.object(pl, "_acquire_db2", side_effect=fake_acquire):
            pl.run_pipeline("db2", vuln_dir=Path(d) / "vuln", fixed_dir=Path(d) / "fixed",
                            out_dir=Path(d) / "out", stages=(), verbose=False,
                            vuln_url=vuln_url, fixed_url=fixed_url)
        return seen

    def _dirs(self, d):
        for s in ("vuln", "fixed"):
            (Path(d) / s).mkdir()
            (Path(d) / s / "desktop.ini").write_bytes(b"[.ShellClassInfo]")

    def test_onedrive_desktop_ini_beside_both_archives(self):
        with tempfile.TemporaryDirectory() as d:
            self._dirs(d)
            (Path(d) / "vuln" / VULN).write_bytes(b"v")
            (Path(d) / "fixed" / FIXED).write_bytes(b"f")
            seen = self._run(d)
            self.assertEqual(seen["vuln_url"], "manual:v11.5.9-90467")
            self.assertEqual(seen["fixed_url"], "manual:v11.5.9-94236")
            self.assertEqual(seen["sides"], {"vuln", "fixed"})
            out = Path(d) / "out" / "acquire"
            self.assertEqual((out / "vuln" / "drop" / VULN).read_bytes(), b"v")
            self.assertEqual((out / "fixed" / "drop" / FIXED).read_bytes(), b"f")
            self.assertFalse((out / "vuln" / "drop" / "desktop.ini").exists())

    def test_placeholder_only_side_is_acquired_not_diffed(self):
        with tempfile.TemporaryDirectory() as d:
            self._dirs(d)
            (Path(d) / "fixed" / FIXED).write_bytes(b"f")
            seen = self._run(d, vuln_url="manual:v11.5.9-90467")
            self.assertEqual(seen["sides"], {"vuln", "fixed"})
            self.assertEqual(seen["vuln_url"], "manual:v11.5.9-90467")

    def test_placeholder_only_side_without_url_fails_clearly(self):
        with tempfile.TemporaryDirectory() as d:
            self._dirs(d)
            (Path(d) / "fixed" / FIXED).write_bytes(b"f")
            with self.assertRaises(ValueError) as cm:
                pl.run_pipeline("db2", vuln_dir=Path(d) / "vuln", fixed_dir=Path(d) / "fixed",
                                out_dir=Path(d) / "out", stages=(), verbose=False)
            self.assertIn("--vuln-url", str(cm.exception))

    def test_explicit_container_url_ignores_the_archive(self):
        with tempfile.TemporaryDirectory() as d:
            self._dirs(d)
            (Path(d) / "vuln" / VULN).write_bytes(b"v")
            (Path(d) / "fixed" / FIXED).write_bytes(b"f")
            seen = self._run(d, vuln_url="container:icr.io/db2_community/db2:11.5.9.0")
            self.assertEqual(seen["vuln_url"], "container:icr.io/db2_community/db2:11.5.9.0")
            self.assertFalse((Path(d) / "out" / "acquire" / "vuln" / "drop").exists())


class TestStagingKeepsTheCurrentArchive(unittest.TestCase):
    def test_same_size_stale_copy_is_replaced(self):
        with tempfile.TemporaryDirectory() as d:
            src = Path(d) / VULN
            src.write_bytes(b"NEW!")
            drop = Path(d) / "out" / "acquire" / "vuln" / "drop"
            drop.mkdir(parents=True)
            (drop / VULN).write_bytes(b"OLD!")                    # same size, other content
            pl._stage_db2_archive(src, Path(d) / "out", "vuln")
            self.assertEqual((drop / VULN).read_bytes(), b"NEW!")

    def test_identical_copy_is_not_copied_again(self):
        with tempfile.TemporaryDirectory() as d:
            src = Path(d) / VULN
            src.write_bytes(b"same")
            out = Path(d) / "out"
            with mock.patch.object(pl.os, "link", side_effect=OSError("cross-device")):
                pl._stage_db2_archive(src, out, "vuln")
                with mock.patch.object(pl.shutil, "copyfile",
                                       side_effect=AssertionError("copied again")):
                    pl._stage_db2_archive(src, out, "vuln")
            self.assertEqual((out / "acquire" / "vuln" / "drop" / VULN).read_bytes(), b"same")

    def test_copy_fallback_is_complete_and_leaves_no_partial(self):
        with tempfile.TemporaryDirectory() as d:
            src = Path(d) / VULN
            src.write_bytes(b"payload")
            out = Path(d) / "out"
            with mock.patch.object(pl.os, "link", side_effect=OSError("cross-device")):
                pl._stage_db2_archive(src, out, "vuln")
            drop = out / "acquire" / "vuln" / "drop"
            self.assertEqual((drop / VULN).read_bytes(), b"payload")
            self.assertEqual(sorted(p.name for p in drop.iterdir()), [VULN])

    def test_read_only_source_gives_a_replaceable_copy(self):
        with tempfile.TemporaryDirectory() as d:
            src = Path(d) / VULN
            src.write_bytes(b"one!")
            os.chmod(src, 0o444)
            out = Path(d) / "out"
            try:
                with mock.patch.object(pl.os, "link", side_effect=OSError("cross-device")):
                    pl._stage_db2_archive(src, out, "vuln")
                    os.chmod(src, 0o644)
                    src.write_bytes(b"two!")                    # same size, new content
                    pl._stage_db2_archive(src, out, "vuln")
                self.assertEqual((out / "acquire" / "vuln" / "drop" / VULN).read_bytes(),
                                 b"two!")
            finally:
                os.chmod(src, 0o644)

    def test_interrupted_copy_leaves_no_archive_under_the_real_name(self):
        with tempfile.TemporaryDirectory() as d:
            src = Path(d) / VULN
            src.write_bytes(b"payload")
            out = Path(d) / "out"

            def broken_copy(a, b):
                Path(b).write_bytes(b"pay")                  # half written, then the failure
                raise OSError("disk full")

            with mock.patch.object(pl.os, "link", side_effect=OSError("cross-device")), \
                    mock.patch.object(pl.shutil, "copyfile", side_effect=broken_copy):
                with self.assertRaises(OSError):
                    pl._stage_db2_archive(src, out, "vuln")
            drop = out / "acquire" / "vuln" / "drop"
            self.assertEqual(list(drop.iterdir()), [])
            self.assertIsNone(db2acq._manual_drop(str(drop.parent)))
            self.assertEqual(src.read_bytes(), b"payload")

    def test_replaced_archive_is_extracted_not_the_cached_previous_build(self):
        """Real manual acquisition (no mocks): the cache must not hand back the old tree after
        the archive was replaced by a same-size, same-mtime one with different content."""
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(db2acq, "_LAYER_CACHE", db2acq._LAYER_CACHE):
            out = Path(d) / "out"
            (Path(d) / "vuln").mkdir()
            src = Path(d) / "vuln" / VULN.replace(".tar.gz", ".tar")

            def extract():
                pl._stage_db2_archive(src, out, "vuln")
                vdir = pl._acquire_db2(out, "manual:v11.5.9-90467", None, False,
                                       sides=("vuln",))["vuln"]
                return (Path(vdir) / "lib64" / "libdb2x.so.1").read_bytes()

            _write_tar(src, b"AAAA")
            self.assertEqual(extract(), b"AAAA")
            first_size = src.stat().st_size
            _write_tar(src, b"BBBB")
            self.assertEqual(src.stat().st_size, first_size)
            self.assertEqual(extract(), b"BBBB")
            self.assertEqual(extract(), b"BBBB")              # and is then reused, unchanged


# ------------------------------------------------------------------ bug.md DB2-T1-6
def _add_reg(t, name, payload):
    info = tarfile.TarInfo(name)
    info.size = len(payload)
    t.addfile(info, io.BytesIO(payload))


def _add_sym(t, name, linkname):
    info = tarfile.TarInfo(name)
    info.type = tarfile.SYMTYPE
    info.linkname = linkname
    t.addfile(info)


class TestSymlinkExtraction(unittest.TestCase):
    """A symlinked member used to be dropped silently, so the tarfile path and the 7-Zip path
    produced different trees. An in-tree symlink is now materialised as a real file; a
    dangling one is recorded in `skipped`, not aborted."""

    def _tar(self, d):
        p = os.path.join(d, "a.tar")
        with tarfile.open(p, "w") as t:
            _add_reg(t, "lib64/libdb2e.so.1", b"ENGINE-BYTES")
            _add_sym(t, "lib64/libdb2e.so", "libdb2e.so.1")       # in-tree, relative
            _add_sym(t, "lib64/dangling.so", "nowhere.so.1")      # target absent
            _add_sym(t, "lib64/escape.so", "../../../../etc/passwd")  # escapes the tree
        return p

    def test_in_tree_symlink_becomes_a_real_file(self):
        with tempfile.TemporaryDirectory() as d:
            dest = os.path.join(d, "out")
            skipped = []
            db2acq._extract_tar(self._tar(d), dest, skipped=skipped)
            self.assertEqual((Path(dest) / "lib64" / "libdb2e.so.1").read_bytes(),
                             b"ENGINE-BYTES")
            # the symlink alias now holds the TARGET's bytes (same tree 7-Zip would produce)
            self.assertEqual((Path(dest) / "lib64" / "libdb2e.so").read_bytes(),
                             b"ENGINE-BYTES")

    def test_dangling_and_escaping_symlinks_are_recorded_not_fatal(self):
        with tempfile.TemporaryDirectory() as d:
            dest = os.path.join(d, "out")
            skipped = []
            db2acq._extract_tar(self._tar(d), dest, skipped=skipped)   # must not raise
            self.assertFalse((Path(dest) / "lib64" / "dangling.so").exists())
            self.assertFalse((Path(dest) / "lib64" / "escape.so").exists())
            joined = " ".join(skipped)
            self.assertIn("dangling.so", joined)
            self.assertIn("escape.so", joined)
            # nothing escaped the extraction dir
            self.assertFalse((Path(d) / "etc" / "passwd").exists())

    def test_symlink_target_rel_rejects_escapes(self):
        self.assertEqual(db2acq._symlink_target_rel("lib64/a.so", "b.so.1"), "lib64/b.so.1")
        self.assertEqual(db2acq._symlink_target_rel("lib64/a.so", "../bin/x"), "bin/x")
        self.assertIsNone(db2acq._symlink_target_rel("lib64/a.so", "/abs/path"))
        self.assertIsNone(db2acq._symlink_target_rel("a.so", "../../etc/passwd"))


# ------------------------------------------------------------------ bug.md DB2-T1-7
_SUB = "opt/ibm/db2/"


def _layer(d, name, members):
    """A gzipped OCI layer tar. members: ('reg', path, bytes) | ('sym', path, target) |
    ('wh', dir, basename) — all paths are under the DB2 subtree."""
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode="w") as t:
        for kind, path, val in members:
            if kind == "wh":
                ti = tarfile.TarInfo(_SUB + path + ".wh." + val); ti.size = 0
                t.addfile(ti, io.BytesIO(b"")); continue
            ti = tarfile.TarInfo(_SUB + path)
            if kind == "reg":
                ti.size = len(val); t.addfile(ti, io.BytesIO(val))
            else:
                ti.type = tarfile.SYMTYPE; ti.linkname = val; t.addfile(ti)
    p = os.path.join(d, name)
    with gzip.open(p, "wb") as g:
        g.write(raw.getvalue())
    return p


class TestContainerLayerSymlinks(unittest.TestCase):
    """bug.md DB2-T1-7: the container/OCI path (_extract_layers) used to drop symlinks, so a
    symlinked analysed binary vanished and an upper symlink couldn't shadow a lower regular.
    Now an in-tree symlink is materialised as a copy of its target, with newest-layer-wins."""

    def _extract(self, layers_members):
        d = tempfile.mkdtemp()
        paths = [_layer(d, f"l{i}.tar.gz", m) for i, m in enumerate(layers_members)]
        dest = os.path.join(d, "root")
        h = {}
        db2acq._extract_layers(paths, dest, _SUB, hashes=h)

        def content(rel):
            p = os.path.join(dest, _SUB + rel)
            if not os.path.isfile(p):
                return None
            with open(p, "rb") as fh:
                return fh.read()
        return content, dest, h

    def test_symlinked_binary_is_materialised(self):
        content, _d, h = self._extract([[("reg", "V11.5/lib64/libdb2e.so.1.0", b"ENGINE"),
                                         ("sym", "V11.5/lib64/libdb2e.so.1", "libdb2e.so.1.0")]])
        self.assertEqual(content("V11.5/lib64/libdb2e.so.1"), b"ENGINE")
        self.assertIn("V11.5/lib64/libdb2e.so.1", [k[len(_SUB):] for k in h])  # in the manifest

    def test_symlink_chain_resolves(self):
        content, _d, _h = self._extract([[("reg", "lib/real", b"R"),
                                         ("sym", "lib/b", "real"), ("sym", "lib/a", "b")]])
        self.assertEqual((content("lib/a"), content("lib/b")), (b"R", b"R"))

    def test_newer_symlink_shadows_lower_regular(self):
        # list order is older-first; the function walks newest-first
        content, _d, _h = self._extract([[("reg", "lib/x", b"OLD")],
                                         [("reg", "lib/t", b"NEW"), ("sym", "lib/x", "t")]])
        self.assertEqual(content("lib/x"), b"NEW")      # the stale lower regular does NOT win

    def test_newer_regular_shadows_lower_symlink(self):
        content, _d, _h = self._extract([[("reg", "lib/tgt", b"T"), ("sym", "lib/y", "tgt")],
                                         [("reg", "lib/y", b"NEWREG")]])
        self.assertEqual(content("lib/y"), b"NEWREG")

    def test_escaping_and_out_of_subtree_targets_are_refused(self):
        content, dest, _h = self._extract([[("reg", "lib/ok", b"OK"),
                                           ("sym", "lib/esc", "../../../../etc/passwd")]])
        self.assertIsNone(content("lib/esc"))
        self.assertFalse(os.path.exists(os.path.join(dest, "etc", "passwd")))

    def test_whiteout_hides_a_lower_symlink(self):
        content, _d, _h = self._extract([[("reg", "lib/z_t", b"ZT"), ("sym", "lib/z", "z_t")],
                                         [("wh", "lib/", "z")]])
        self.assertIsNone(content("lib/z"))


if __name__ == "__main__":
    unittest.main()
