"""Regression test for the MSSQL BinDiff-mode (Track-1) counterpart of IMP-NT-1: the
`hits.sort()` call in mssql/stage2.py's use_bindiff branch (the "BinDiff hits" sort) had no
final tie-breaker, same shape as the bug fixed for the three name-mode sorts (IMP-NT-1,
see test_emit_cap_determinism.py).

Unlike IMP-NT-1, this path's non-determinism is NOT reproducible via PYTHONHASHSEED: the
pre-sort order of `hits` here inherits from `raw_bd`, which inherits from `matches.items()`
-- a plain dict built by _bindiff.py's parse_matches() from `SELECT ... FROM function` rows
(no ORDER BY), so its order is governed by SQLite's row storage, not by Python's string-hash
randomization. The real axis of non-determinism this fix guards against is `matches`' row/
insertion order itself, which parse_matches() gives no stability guarantee for. This test
exercises exactly that axis directly (shuffling insertion order into a mocked `matches`
dict), rather than PYTHONHASHSEED, since the latter would not actually move the needle here
-- confirmed by hand before writing this test.

Drives the REAL production mssql.stage2._process_dll() BinDiff-mode path end-to-end, with
only the symbol/PDB/PE/BinDiff layers mocked (same technique as test_bindiff_matching.py)."""
import os
import random
import tempfile
import unittest

import patch_differ_cli.mssql.stage2 as ms2
from patch_differ_cli import _bindiff as bd_mod

_N = 700   # exceeds mssql's _EMIT_CAP (500), so truncation always bites into the tied group


class _FakeSymbolizer:
    def __init__(self, *a, **kw):
        self.ok = True

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def name_at(self, rva):
        return None


class _FakePE:
    class _OptHdr:
        ImageBase = 0

    def __init__(self, *a, **kw):
        self.OPTIONAL_HEADER = self._OptHdr()

    def close(self):
        pass


class _FakeMatch:
    def __init__(self, addr2, similarity, confidence):
        self.addr2 = addr2
        self.similarity = similarity
        self.confidence = confidence


class BinDiffEmitCapDeterminismTests(unittest.TestCase):
    def _run_once(self, shuffle_seed):
        """Builds _N exactly-tied BinDiff-matched function pairs (identical byte-change
        shape, so kind/simr/fpre tie exactly), shuffles the insertion order of the mocked
        `matches` dict by `shuffle_seed`, runs the real pipeline, and returns the sorted
        set of emitted card names."""
        P_fake, F_fake = {}, {}
        items = []
        for i in range(_N):
            name = f"zzFunc{i:04d}"
            rva = 0x10000 + i * 0x10
            P_fake[name] = (rva, [(rva, b"\x90\xc3")])
            F_fake[name] = (rva, [(rva, b"\x90\x90\xc3")])
            items.append((rva, _FakeMatch(rva, 0.5, 0.9)))   # ImageBase=0, tied sim/conf

        random.Random(shuffle_seed).shuffle(items)
        matches = dict(items)

        orig_func_map = ms2._func_map
        orig_fetch_pdb = ms2.sym.fetch_pdb
        orig_symbolizer = ms2.sym.Symbolizer
        orig_pe = ms2._pefile.PE
        orig_diff_pair = bd_mod.diff_pair

        ms2._func_map = lambda path, symbolizer: dict(P_fake if "prior" in path else F_fake)
        ms2.sym.fetch_pdb = lambda *a, **kw: None
        ms2.sym.Symbolizer = _FakeSymbolizer
        ms2._pefile.PE = _FakePE
        bd_mod.diff_pair = lambda pa, fa, workdir, progress=None: dict(matches)

        try:
            with tempfile.TemporaryDirectory(prefix="pdff_bd_order_") as d:
                prior_dir = os.path.join(d, "prior")
                fixed_dir = os.path.join(d, "fixed")
                out = os.path.join(d, "out")
                os.makedirs(prior_dir); os.makedirs(fixed_dir); os.makedirs(out)
                rel = "risky.dll"
                with open(os.path.join(prior_dir, rel), "wb") as f:
                    f.write(b"\x00")
                with open(os.path.join(fixed_dir, rel), "wb") as f:
                    f.write(b"\x00")
                job = {
                    "prior_dir": prior_dir, "fixed_dir": fixed_dir, "rel": rel, "out": out,
                    "attrib": [], "online": False,
                    "pdb_cache": os.path.join(d, "pdbcache"),
                    "use_bindiff": True, "decompile": False,
                    "decompile_cache": os.path.join(out, "decompile_cache"),
                    "decompiled_c_dir": os.path.join(out, "decompiled_c"),
                    "disassembled_dir": os.path.join(out, "disassembled_instructions"),
                    "run_ts": "20260101T000000Z", "vuln_label": "vuln", "fixed_label": "fixed",
                }
                os.makedirs(job["disassembled_dir"])
                result = ms2._process_dll(job)
        finally:
            ms2._func_map = orig_func_map
            ms2.sym.fetch_pdb = orig_fetch_pdb
            ms2.sym.Symbolizer = orig_symbolizer
            ms2._pefile.PE = orig_pe
            bd_mod.diff_pair = orig_diff_pair

        return sorted(r["object"] for r in result["readable"])

    def test_emission_is_independent_of_matches_insertion_order(self):
        run1 = self._run_once(1)
        run2 = self._run_once(2)
        run3 = self._run_once(3)
        self.assertTrue(run1, "expected at least some emitted cards")
        self.assertEqual(run1, run2,
                          "BinDiff-mode emitted a different card set depending on matches' "
                          "insertion order (run1 vs run2)")
        self.assertEqual(run1, run3,
                          "BinDiff-mode emitted a different card set depending on matches' "
                          "insertion order (run1 vs run3)")


if __name__ == "__main__":
    unittest.main()
