"""Regression tests for bugs.md #18, #20, #23, #25, #27, #30, #42, #45, #49, #50, #51 —
each a path where a real change (or an unreadable input) used to vanish from the result
without an error, so an incomplete comparison looked clean.

All inputs are hand-built (ELF64 images, ar archives, tars, jars, wrapped PL/SQL); no
Ghidra, CFR or network is used. Scratch files live in TemporaryDirectory()s only."""
import gzip
import io
import os
import struct
import tarfile
import tempfile
import unittest
import zipfile
from unittest import mock

import patch_differ_cli._attribution as AT
import patch_differ_cli._x86diff as X
import patch_differ_cli.db2.acquire as A
import patch_differ_cli.db2.stage2 as d2
import patch_differ_cli.db2.triage as dt
import patch_differ_cli.mssql.stage2 as ms2
import patch_differ_cli.oracle._ar as ar
import patch_differ_cli.oracle.stage1 as o1
import patch_differ_cli.oracle.stage2 as o2
import patch_differ_cli.oracle.unwrap as uw

_LOCAL_FUNC, _GLOBAL_FUNC, _FILE = 0x02, 0x12, 0x04


# --------------------------------------------------------------------------- helpers
def _elf(symbols, et_rel=False):
    """symbols: [(name, info, value, code)] in symtab order. info=_FILE entries carry no
    code (value/code ignored); function code is laid out in .text at `value`, which
    starts at 0 (so the same image is valid as a linked image or a single-.text ET_REL)."""
    funcs = sorted({(v, c) for _n, i, v, c in symbols if i != _FILE})   # aliases share bytes
    text = b""
    for v, c in funcs:
        assert v >= len(text), "functions must not overlap"
        text += b"\x00" * (v - len(text)) + c
    strtab, offs = b"\x00", {}
    for n, *_ in symbols:
        if n not in offs:
            offs[n] = len(strtab)
            strtab += n.encode() + b"\x00"
    symtab = struct.pack("<IBBHQQ", 0, 0, 0, 0, 0, 0)
    for n, info, v, c in symbols:
        shndx = 0xFFF1 if info == _FILE else 1
        symtab += struct.pack("<IBBHQQ", offs[n], info, 0, shndx,
                              0 if info == _FILE else v, 0 if info == _FILE else len(c))
    shstr = b"\x00.text\x00.symtab\x00.strtab\x00.shstrtab\x00"
    t_off = 64
    s_off = t_off + len(text)
    st_off = s_off + len(symtab)
    sh_off = st_off + len(strtab)
    hdr_off = sh_off + len(shstr)

    def shdr(nm, typ, off, size, link=0, flags=0):
        return struct.pack("<IIQQQQIIQQ", nm, typ, flags, 0, off, size, link, 0, 1, 0)

    secs = [shdr(0, 0, 0, 0), shdr(1, 1, t_off, len(text), flags=0x6),
            shdr(7, 2, s_off, len(symtab), link=3), shdr(15, 3, st_off, len(strtab)),
            shdr(23, 3, sh_off, len(shstr))]
    eh = bytearray(64)
    eh[0:4] = b"\x7fELF"
    eh[4], eh[5], eh[6] = 2, 1, 1
    struct.pack_into("<H", eh, 0x10, 1 if et_rel else 3)
    struct.pack_into("<H", eh, 0x12, 0x3E)
    struct.pack_into("<I", eh, 0x14, 1)
    struct.pack_into("<Q", eh, 0x28, hdr_off)
    struct.pack_into("<H", eh, 0x34, 64)
    struct.pack_into("<H", eh, 0x3A, 64)
    struct.pack_into("<H", eh, 0x3C, len(secs))
    struct.pack_into("<H", eh, 0x3E, 4)
    return bytes(eh) + text + symtab + strtab + shstr + b"".join(secs)


def _write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    return path


def _db2_cards(d, prior_blob, fixed_blob, rel="lib/libx.so"):
    prior, fixed, out = (os.path.join(d, x) for x in ("prior", "fixed", "out"))
    _write(os.path.join(prior, rel), prior_blob)
    _write(os.path.join(fixed, rel), fixed_blob)
    os.makedirs(out, exist_ok=True)
    job = {"prior_dir": prior, "fixed_dir": fixed, "rel": rel, "out": out, "attrib": [],
           "use_bindiff": False, "decompile": False, "disassembled_dir": out,
           "vuln_label": "vuln", "fixed_label": "fixed", "run_ts": "20260101T000000Z"}
    return d2._process_file(job)["readable"]


# "dup" twice: a.c's copy changes (nop;ret -> nop;nop;ret), b.c's copy doesn't
_DUP_PRIOR = [("a.c", _FILE, 0, b""), ("dup", _LOCAL_FUNC, 0x00, b"\x90\xc3"),
              ("b.c", _FILE, 0, b""), ("dup", _LOCAL_FUNC, 0x10, b"\x31\xc0\xc3")]
_DUP_FIXED = [("a.c", _FILE, 0, b""), ("dup", _LOCAL_FUNC, 0x00, b"\x90\x90\xc3"),
              ("b.c", _FILE, 0, b""), ("dup", _LOCAL_FUNC, 0x10, b"\x31\xc0\xc3")]


# --------------------------------------------------------------------------- #27
class DuplicateFunctionNameTests(unittest.TestCase):
    def test_same_named_statics_are_both_kept_and_qualified_by_source_file(self):
        with tempfile.TemporaryDirectory() as d:
            p = _write(os.path.join(d, "x.so"), _elf(_DUP_PRIOR))
            m = d2._func_map(p)
        self.assertEqual(sorted(m), ["dup [a.c]", "dup [b.c]"])
        self.assertEqual(m["dup [a.c]"], (0x00, b"\x90\xc3"))
        self.assertEqual(m["dup [b.c]"], (0x10, b"\x31\xc0\xc3"))

    def test_change_to_the_overwritten_copy_is_reported(self):
        # the regression: the bare-name map kept only b.c's (unchanged) copy, so a.c's change
        # produced no card at all
        with tempfile.TemporaryDirectory() as d:
            cards = _db2_cards(d, _elf(_DUP_PRIOR), _elf(_DUP_FIXED))
        objs = [c["object"] for c in cards]
        self.assertEqual(len(objs), 1, objs)
        self.assertIn("dup [a.c]", objs[0])

    def test_unique_names_and_aliases_keep_their_bare_key(self):
        syms = [("a.c", _FILE, 0, b""), ("f", _LOCAL_FUNC, 0x00, b"\x90\xc3"),
                ("f", _GLOBAL_FUNC, 0x00, b"\x90\xc3"),          # alias: same address
                ("g", _GLOBAL_FUNC, 0x10, b"\xc3")]
        with tempfile.TemporaryDirectory() as d:
            m = d2._func_map(_write(os.path.join(d, "x.so"), _elf(syms)))
        self.assertEqual(sorted(m), ["f", "g"])

    def test_no_file_context_and_same_file_twice_get_ordinals(self):
        syms = [("dup", _LOCAL_FUNC, 0x10, b"\xc3"), ("dup", _LOCAL_FUNC, 0x00, b"\x90\xc3")]
        with tempfile.TemporaryDirectory() as d:
            m = d2._func_map(_write(os.path.join(d, "x.so"), _elf(syms)))
        self.assertEqual(m["dup [? #1]"][0], 0x00)      # ordinal follows address order
        self.assertEqual(m["dup [? #2]"][0], 0x10)

    def test_global_symbol_after_locals_is_not_given_their_file(self):
        syms = [("a.c", _FILE, 0, b""), ("dup", _LOCAL_FUNC, 0x00, b"\x90\xc3"),
                ("dup", _GLOBAL_FUNC, 0x10, b"\xc3")]
        with tempfile.TemporaryDirectory() as d:
            m = d2._func_map(_write(os.path.join(d, "x.so"), _elf(syms)))
        self.assertEqual(sorted(m), ["dup [?]", "dup [a.c]"])

    def test_one_side_dropping_a_copy_still_diffs_the_survivor(self):
        # prior: dup in a.c and b.c; fixed: only b.c's, and it changed. Without
        # reconcile_dup_names() fixed's bare "dup" matched neither qualified prior key.
        fixed = [("b.c", _FILE, 0, b""), ("dup", _LOCAL_FUNC, 0x10, b"\x31\xc0\x90\xc3")]
        with tempfile.TemporaryDirectory() as d:
            cards = _db2_cards(d, _elf(_DUP_PRIOR), _elf(fixed))
        by_change = {c["change"]: c["object"] for c in cards}
        self.assertIn("dup [a.c]", by_change.get("removed", ""))
        changed = [c["object"] for c in cards if c["change"] not in ("added", "removed")]
        self.assertEqual(len(changed), 1, cards)
        self.assertIn("dup [b.c]", changed[0])
        self.assertNotIn("added", by_change)

    def test_oracle_section_aware_parser_keeps_both_copies(self):
        with tempfile.TemporaryDirectory() as d:
            m = o2._func_map(_write(os.path.join(d, "x.o"), _elf(_DUP_PRIOR, et_rel=True)))
        self.assertEqual(sorted(m), ["dup [a.c]", "dup [b.c]"])

    def test_attribution_ignores_the_qualifier(self):
        attrib = [{"cve": "CVE-2026-0001", "tokens": {"auth"}, "primitives": {"auth"},
                   "families": set()}]
        self.assertEqual(AT.attribute("dup [auth.c]", attrib), (None, None, None))
        self.assertEqual(AT.attribute("checkauth [x.c #2]", attrib),
                         AT.attribute("checkauth", attrib))
        self.assertEqual(AT.base_func_name("foo@@VERS_1"), "foo@@VERS_1")


# --------------------------------------------------------------------------- #30
class OperandWidthAndSegmentTests(unittest.TestCase):
    def _cls(self, a, b):
        m = X.md()
        return X.classify(*X.norm(m, 0x1000, bytes.fromhex(a)),
                          *X.norm(m, 0x1000, bytes.fromhex(b)))

    def test_register_width_change_is_a_code_change(self):
        self.assertEqual(self._cls("39d8", "4839d8"), "code")       # cmp eax,ebx -> rax,rbx

    def test_fs_segment_override_is_a_code_change(self):
        self.assertEqual(self._cls("8b03", "648b03"), "code")       # [rbx] -> fs:[rbx]

    def test_memory_access_width_change_is_a_code_change(self):
        self.assertEqual(self._cls("0fb603", "0fb703"), "code")     # movzx byte -> word

    def test_register_allocation_alone_is_still_noise(self):
        self.assertEqual(self._cls("39d8", "39ca"), "same")         # cmp eax,ebx / edx,ecx

    def test_a_no_op_ds_override_is_still_noise(self):
        self.assertEqual(self._cls("8b03", "3e8b03"), "same")

    def test_db2_stage2_reports_a_width_only_change(self):
        prior = [("widen", _GLOBAL_FUNC, 0, bytes.fromhex("39d8c3"))]
        fixed = [("widen", _GLOBAL_FUNC, 0, bytes.fromhex("4839d8c3"))]
        with tempfile.TemporaryDirectory() as d:
            cards = _db2_cards(d, _elf(prior), _elf(fixed))
        self.assertEqual([c["object"].split(" :: ")[-1] for c in cards], ["widen"])


# --------------------------------------------------------------------------- #25
class MssqlDecompileChunkLayoutTests(unittest.TestCase):
    def test_cold_chunk_is_placed_at_its_true_offset(self):
        # hot: jmp 0x1010 (eb 0e) ; cold at 0x1010: ret. Concatenated, the jmp pointed past
        # the end of the 3-byte blob; laid out, it lands exactly on the cold chunk.
        blob, omitted = ms2._extract_func_bytes([(0x1010, b"\xc3"), (0x1000, b"\xeb\x0e")],
                                                0x1000)
        self.assertEqual(omitted, 0)
        self.assertEqual(blob, b"\xeb\x0e" + b"\xcc" * 14 + b"\xc3")
        jmp = next(X.md().disasm(blob, 0x100000))
        self.assertEqual(jmp.operands[0].imm, 0x100010)
        self.assertEqual(blob[jmp.operands[0].imm - 0x100000], 0xC3)

    def test_single_chunk_is_unchanged(self):
        self.assertEqual(ms2._extract_func_bytes([(0x2000, b"\x90\xc3")], 0x2000),
                         (b"\x90\xc3", 0))

    def test_chunk_below_primary_is_omitted_and_counted(self):
        blob, omitted = ms2._extract_func_bytes([(0x0f00, b"\xc3"), (0x1000, b"\x90\xc3")],
                                                0x1000)
        self.assertEqual((blob, omitted), (b"\x90\xc3", 1))

    def test_too_distant_cold_chunk_keeps_primary_only(self):
        far = 0x1000 + ms2._MAX_DECOMP_SPAN + 1
        blob, omitted = ms2._extract_func_bytes([(0x1000, b"\x90\xc3"), (far, b"\xc3")], 0x1000)
        self.assertEqual((blob, omitted), (b"\x90\xc3", 1))

    def test_missing_primary_chunk_yields_nothing_to_decompile(self):
        self.assertEqual(ms2._extract_func_bytes([(0x1010, b"\xc3")], 0x1000), (b"", 1))

    def test_partial_note(self):
        self.assertEqual(ms2._partial_c_note(0, "int f(){}"), "int f(){}")
        self.assertEqual(ms2._partial_c_note(2, ""), "")
        self.assertTrue(ms2._partial_c_note(1, "int f(){}").startswith("// NOTE: 1 cold"))


# --------------------------------------------------------------------------- #49
class Db2TriageSameSizeTests(unittest.TestCase):
    def test_same_size_generic_file_change_is_detected(self):
        with tempfile.TemporaryDirectory() as d:
            p, f, w = (os.path.join(d, x) for x in ("p", "f", "w"))
            _write(os.path.join(p, "opt", "payload.bin"), b"AAAA")
            _write(os.path.join(f, "opt", "payload.bin"), b"BBBB")
            _write(os.path.join(p, "opt", "same.bin"), b"CCCC")
            _write(os.path.join(f, "opt", "same.bin"), b"CCCC")
            os.makedirs(w)
            r = dt.run(p, f, w)
        self.assertEqual([e["name"] for e in r["content_changed"]], ["opt/payload.bin"])
        self.assertEqual(r["counts"]["identical"], 1)
        self.assertEqual(r["errors"], [])


# --------------------------------------------------------------------------- Oracle Stage 1
def _wrapped(payload):
    """A wrapped unit whose base64 lump doesn't decode to a valid wrapped body."""
    return ("CREATE OR REPLACE PACKAGE BODY sec_pkg wrapped\n"
            "a000000\n1\nabcd\n" + payload + "\n/\n")


def _real_wrapped(source, tail=""):
    """A genuinely decodable wrapped unit (the unwrap algorithm run in reverse)."""
    import base64
    import hashlib
    import zlib
    inv = bytearray(256)
    for i, c in enumerate(uw._CHARMAP):
        inv[c] = i
    comp = zlib.compress(source.encode("latin-1"))
    raw = hashlib.sha1(comp).digest() + comp.translate(bytes(inv))
    b64 = base64.b64encode(raw).decode()
    lump = "\n".join(b64[k:k + 64] for k in range(0, len(b64), 64))
    return ("CREATE OR REPLACE PACKAGE BODY sec_pkg wrapped\na000000\n1\nabcd\n"
            + lump + "\n/\n" + tail)


def _jar(path, entries):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with zipfile.ZipFile(path, "w") as zf:
        for n, b in entries.items():
            zf.writestr(n, b)
    return path


def _fake_decompile(jd, jar, out_dir):
    """Stand-in for CFR: one .java per .class entry, containing the class bytes."""
    os.makedirs(out_dir, exist_ok=True)
    with zipfile.ZipFile(jar) as zf:
        classes = [n for n in zf.namelist() if n.endswith(".class")]
        if not classes:
            raise jd.DecompileFailed("decompiler produced no source")
        for n in classes:
            dst = os.path.join(out_dir, n[:-len(".class")] + ".java")
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            with open(dst, "w", encoding="utf-8") as fh:
                fh.write(zf.read(n).decode())


class OracleStage1Tests(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        d = self._td.name
        self.p, self.f, self.w = (os.path.join(d, x) for x in ("p", "f", "w"))
        for x in (self.p, self.f, self.w):
            os.makedirs(x)

    def _run(self, entries):
        with mock.patch.object(o1, "_decompile_cached", _fake_decompile):
            return o1.run(self.p, self.f, self.w, stage0={"content_changed": entries})

    def _text(self, side, rel, text):
        _write(os.path.join(side, rel), text.encode("latin-1"))

    # #50
    def test_unwrap_marker_carries_the_payload_digest(self):
        fa, fb = [], []
        a = uw.unwrap_text(_wrapped("QUFBQUFBQUE="), fa)
        b = uw.unwrap_text(_wrapped("QkJCQkJCQkI="), fb)
        self.assertNotEqual(a, b)
        self.assertEqual((len(fa), len(fb)), (1, 1))
        self.assertIn("unwrap failed", a)
        self.assertEqual(uw.unwrap_text(_wrapped("QUFBQUFBQUE=")), a)   # deterministic

    def test_decodable_unit_still_unwraps_and_keeps_text_after_its_terminator(self):
        src = "PACKAGE BODY sec_pkg IS\n  PROCEDURE p IS BEGIN NULL; END;\nEND sec_pkg;"
        fails = []
        out = uw.unwrap_text(_real_wrapped(src, "GRANT EXECUTE ON sec_pkg TO PUBLIC;\n"), fails)
        self.assertEqual(fails, [])
        self.assertIn("PROCEDURE p IS BEGIN NULL; END;", out)
        self.assertIn("GRANT EXECUTE ON sec_pkg TO PUBLIC;", out)

    def test_changed_grant_after_a_wrapped_unit_is_reported(self):
        rel = "rdbms/admin/prvtsec.plb"
        src = "PACKAGE BODY sec_pkg IS\n  PROCEDURE p IS BEGIN NULL; END;\nEND sec_pkg;"
        self._text(self.p, rel, _real_wrapped(src, "GRANT EXECUTE ON sec_pkg TO PUBLIC;\n"))
        self._text(self.f, rel, _real_wrapped(src, "GRANT EXECUTE ON sec_pkg TO DBA;\n"))
        r = self._run([{"name": rel, "route": "stage1", "kind": "plsql", "change": "code"}])
        self.assertEqual((r["counts"]["readable_changed"], r["counts"]["errors"]), (1, 0))

    def test_two_different_undecodable_payloads_are_a_reported_change(self):
        rel = "rdbms/admin/prvtsec.plb"
        self._text(self.p, rel, _wrapped("QUFBQUFBQUE="))
        self._text(self.f, rel, _wrapped("QkJCQkJCQkI="))
        r = self._run([{"name": rel, "route": "stage1", "kind": "plsql", "change": "code"}])
        self.assertEqual(r["counts"]["readable_changed"], 1)
        self.assertEqual(r["counts"]["errors"], 1)
        self.assertIn("could not be unwrapped", r["errors"][0]["error"])

    def test_identical_undecodable_unit_is_not_an_error(self):
        rel = "rdbms/admin/prvtsec.plb"
        self._text(self.p, rel, _wrapped("QUFBQUFBQUE=") + "-- v1\n")
        self._text(self.f, rel, _wrapped("QUFBQUFBQUE=") + "-- v2\n")
        r = self._run([{"name": rel, "route": "stage1", "kind": "plsql", "change": "code"}])
        self.assertEqual(r["counts"]["errors"], 0)
        self.assertEqual(r["counts"]["readable_changed"], 1)

    # #23
    def test_oversized_readable_file_is_an_error_not_a_silent_skip(self):
        rel = "rdbms/admin/big.sql"
        self._text(self.p, rel, "select 1 from dual;\n" * 10)
        self._text(self.f, rel, "select 2 from dual;\n" * 10)
        with mock.patch.object(o1, "_MAX_BYTES", 50):
            r = self._run([{"name": rel, "route": "stage1", "kind": "sql", "change": "code"}])
        self.assertEqual(r["counts"]["readable_changed"], 0)
        self.assertEqual(r["counts"]["errors"], 1)
        self.assertIn("readable-diff limit", r["errors"][0]["error"])

    # #18
    def test_corrupt_jar_is_an_error(self):
        rel = "javavm/lib/sec.jar"
        _jar(os.path.join(self.p, rel), {"pkg/A.class": "class A {}"})
        _write(os.path.join(self.f, rel), b"PK\x03\x04 not really a zip")
        r = self._run([{"name": rel, "route": "stage1", "kind": "jar", "change": "code"}])
        self.assertEqual(r["counts"]["errors"], 1)
        self.assertIn("unreadable jar", r["errors"][0]["error"])

    def test_class_free_jar_on_both_sides_is_still_skipped_quietly(self):
        rel = "javavm/lib/res.jar"
        _jar(os.path.join(self.p, rel), {"README": "a"})
        _jar(os.path.join(self.f, rel), {"README": "b"})
        r = self._run([{"name": rel, "route": "stage1", "kind": "jar", "change": "code"}])
        self.assertEqual((r["counts"]["errors"], r["readable_files"]), (0, []))

    # #20
    def test_classes_removed_from_a_still_valid_jar_are_reported(self):
        rel = "javavm/lib/sec.jar"
        _jar(os.path.join(self.p, rel), {"pkg/A.class": "class A {}"})
        _jar(os.path.join(self.f, rel), {"README": "now empty"})
        r = self._run([{"name": rel, "route": "stage1", "kind": "jar", "change": "code"}])
        self.assertEqual(r["counts"]["errors"], 0)
        self.assertEqual([(c["object"], c["change"]) for c in r["readable_files"]],
                         [("sec.jar :: pkg/A.java", "removed")])

    # #42
    def test_jar_gaining_its_first_class_is_reported(self):
        rel = "javavm/lib/sec.jar"
        _jar(os.path.join(self.p, rel), {"README.txt": "x"})
        _jar(os.path.join(self.f, rel), {"pkg/Foo.class": "class Foo {}"})
        r = self._run([{"name": rel, "route": "stage1", "kind": "jar", "change": "code"}])
        self.assertEqual(r["counts"]["errors"], 0)
        self.assertEqual([(c["object"], c["change"]) for c in r["readable_files"]],
                         [("sec.jar :: pkg/Foo.java", "added")])


# --------------------------------------------------------------------------- #45
def _ar_hdr(name, size):
    return (name.ljust(16) + "0".ljust(12) + "0".ljust(6) + "0".ljust(6) + "644".ljust(8)
            + str(size).ljust(10) + "`\n").encode("latin-1")


def _ar(members):
    out = b"!<arch>\n"
    for name, body in members:
        out += _ar_hdr(name + "/", len(body)) + body + (b"\n" if len(body) & 1 else b"")
    return out


class TruncatedArchiveTests(unittest.TestCase):
    GOOD = _ar([("common.o", b"C" * 10), ("victim.o", b"V" * 10)])

    def _members(self, blob):
        return list(ar.ar_members(blob))

    def test_valid_archive_parses(self):
        self.assertEqual([n for n, _ in self._members(self.GOOD)], ["common.o", "victim.o"])

    def test_truncated_header_raises(self):
        cut = self.GOOD.index(b"victim.o") + 20
        with self.assertRaises(ar.MalformedArchive):
            self._members(self.GOOD[:cut])

    def test_short_body_raises(self):
        with self.assertRaises(ar.MalformedArchive):
            self._members(self.GOOD[:-3])

    def test_misaligned_header_raises(self):
        odd = _ar([("a.o", b"ODD")])[:-1] + _ar_hdr("b.o/", 2) + b"BB"   # alignment byte lost
        with self.assertRaises(ar.MalformedArchive):
            self._members(odd)

    def test_missing_final_alignment_byte_is_tolerated(self):
        blob = _ar([("a.o", b"ODD")])
        self.assertEqual(self._members(blob[:-1]), [("a.o", b"ODD")])

    def test_bad_magic_raises(self):
        with self.assertRaises(ar.MalformedArchive):
            self._members(b"!<thin>\n")

    def test_stage2_reports_truncated_archive_as_failed(self):
        rel = "lib/libserver.a"
        with tempfile.TemporaryDirectory() as d:
            p, f, w = (os.path.join(d, x) for x in ("p", "f", "w"))
            _write(os.path.join(p, rel), self.GOOD)
            _write(os.path.join(f, rel), self.GOOD[:self.GOOD.index(b"victim.o") + 20])
            os.makedirs(w)
            r = o2.run(p, f, w, stage0={"code_changed": [
                {"name": rel, "kind": "archive", "size": 100}]})
        self.assertEqual(r["counts"]["failed"], 1)
        self.assertEqual([b["verdict"] for b in r["binaries"]], ["error"])


# --------------------------------------------------------------------------- #51
def _tar_bytes(members, gz=False):
    """members: [(name, bytes)] regular files, or (name, "->target") hard links."""
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w") as t:
        for name, body in members:
            ti = tarfile.TarInfo(name)
            if isinstance(body, str):
                ti.type, ti.linkname = tarfile.LNKTYPE, body[2:]
                t.addfile(ti)
            else:
                ti.size = len(body)
                t.addfile(ti, io.BytesIO(body))
    return gzip.compress(buf.getvalue()) if gz else buf.getvalue()


def _tree(root):
    out = {}
    for dp, _dn, files in os.walk(root):
        for fn in files:
            p = os.path.join(dp, fn)
            with open(p, "rb") as fh:
                out[os.path.relpath(p, root).replace("\\", "/")] = fh.read()
    return out


class HardLinkExtractionTests(unittest.TestCase):
    LIB = "opt/ibm/db2/lib/"

    def test_extract_tar_writes_hard_links(self):
        with tempfile.TemporaryDirectory() as d:
            t = _write(os.path.join(d, "x.tar"), _tar_bytes(
                [("lib/libdb2.so.1", b"ELFDATA"), ("lib/libdb2.so", "->lib/libdb2.so.1")]))
            hashes = {}
            A._extract_tar(t, os.path.join(d, "out"), hashes=hashes)
            tree = _tree(os.path.join(d, "out"))
        self.assertEqual(tree, {"lib/libdb2.so.1": b"ELFDATA", "lib/libdb2.so": b"ELFDATA"})
        self.assertEqual(hashes["lib/libdb2.so"], hashes["lib/libdb2.so.1"])

    def test_layer_link_whose_target_a_newer_layer_overrides_keeps_its_own_bytes(self):
        lower = _tar_bytes([(self.LIB + "libx.so.1", b"OLD"),
                            (self.LIB + "libx.so", "->" + self.LIB + "libx.so.1")], gz=True)
        upper = _tar_bytes([(self.LIB + "libx.so.1", b"NEW")], gz=True)
        with tempfile.TemporaryDirectory() as d:
            paths = [_write(os.path.join(d, "l0.tar.gz"), lower),
                     _write(os.path.join(d, "l1.tar.gz"), upper)]
            A._extract_layers(paths, os.path.join(d, "out"), A._SUBTREE)
            tree = _tree(os.path.join(d, "out"))
        self.assertEqual(tree, {self.LIB + "libx.so.1": b"NEW", self.LIB + "libx.so": b"OLD"})

    def test_layer_link_to_member_outside_the_layer_raises(self):
        layer = _tar_bytes([(self.LIB + "libx.so", "->" + self.LIB + "missing")], gz=True)
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(RuntimeError):
                A._extract_layers([_write(os.path.join(d, "l.tar.gz"), layer)],
                                  os.path.join(d, "out"), A._SUBTREE)

    def test_component_stream_writes_hard_links(self):
        blob = _tar_bytes([("lib/a.so.1", b"AAA"), ("lib/a.so", "->lib/a.so.1")], gz=True)
        with tempfile.TemporaryDirectory() as d:
            A._extract_component_stream(io.BytesIO(blob), os.path.join(d, "out"))
            tree = _tree(os.path.join(d, "out"))
        self.assertEqual(tree, {"lib/a.so.1": b"AAA", "lib/a.so": b"AAA"})

    def test_component_link_to_target_from_an_earlier_component_resolves_from_disk(self):
        with tempfile.TemporaryDirectory() as d:
            out = os.path.join(d, "out")
            A._extract_component_stream(io.BytesIO(_tar_bytes([("lib/a.so.1", b"X")], gz=True)),
                                        out)
            blob = _tar_bytes([("lib/a.so.1", b"Y"), ("lib/a.so", "->lib/a.so.1")], gz=True)
            A._extract_component_stream(io.BytesIO(blob), out)
            tree = _tree(out)
        self.assertEqual(tree, {"lib/a.so.1": b"X", "lib/a.so": b"X"})

    def test_component_link_with_no_available_target_is_skipped_not_fatal(self):
        blob = _tar_bytes([("lib/ok", b"1"), ("lib/a.so", "->lib/missing")], gz=True)
        skipped = []
        with tempfile.TemporaryDirectory() as d:
            A._extract_component_stream(io.BytesIO(blob), os.path.join(d, "out"), skipped=skipped)
            tree = _tree(os.path.join(d, "out"))
        self.assertEqual(tree, {"lib/ok": b"1"})
        self.assertEqual(len(skipped), 1)

    def test_component_unwritable_member_is_skipped_not_fatal(self):
        # "lib/a" is a file, so "lib/a/b" can't be created
        blob = _tar_bytes([("lib/a", b"1"), ("lib/a/b", b"2"), ("lib/c", b"3")], gz=True)
        skipped = []
        with tempfile.TemporaryDirectory() as d:
            A._extract_component_stream(io.BytesIO(blob), os.path.join(d, "out"), skipped=skipped)
            tree = _tree(os.path.join(d, "out"))
        self.assertEqual(tree, {"lib/a": b"1", "lib/c": b"3"})
        self.assertEqual(len(skipped), 1)

    def test_flat_extract_unwritable_member_is_skipped_not_fatal(self):
        skipped = []
        with tempfile.TemporaryDirectory() as d:
            t = _write(os.path.join(d, "x.tar"), _tar_bytes(
                [("lib/a", b"1"), ("lib/a/b", b"2"), ("lib/c", b"3")]))
            A._extract_tar(t, os.path.join(d, "out"), skipped=skipped)
            tree = _tree(os.path.join(d, "out"))
        self.assertEqual(tree, {"lib/a": b"1", "lib/c": b"3"})
        self.assertEqual(len(skipped), 1)

    def test_manual_falls_back_to_7zip_when_tarfile_fails(self):
        from unittest import mock
        if not os.path.isfile(A.tp.sevenzip()):
            self.skipTest("7-Zip not available")
        comp = _tar_bytes([("lib64/libdb2e.so.1", b"E"), ("lib64/x.so", b"X"),
                           ("lib64/x2.so", "->lib64/x.so"), (".metadata/c.xml", b"m")], gz=True)
        outer = _tar_bytes([("ESE/FILES/DB2_ESE_SERVER_11.5.9_linuxx64.tar.gz", comp)], gz=True)
        with tempfile.TemporaryDirectory() as d:
            side = os.path.join(d, "vuln")
            os.makedirs(os.path.join(side, "drop"))
            _write(os.path.join(side, "drop", "fp.tar.gz"), outer)
            root = os.path.join(side, "root")
            hashes = {}
            with mock.patch.object(A, "_acquire_manual_tarfile", side_effect=OSError("boom")):
                A._acquire_manual("vuln", side, "L", hashes=hashes, root_dir=root)
            tree = _tree(root)
            self.assertFalse(os.path.exists(os.path.join(side, "_7z_outer")))
        self.assertEqual(tree.get("lib64/libdb2e.so.1"), b"E")
        self.assertEqual(tree.get("lib64/x.so"), b"X")
        self.assertNotIn(".metadata/c.xml", tree)
        self.assertIn("lib64/libdb2e.so.1", hashes)

    def test_manual_unsafe_member_is_not_retried_with_7zip(self):
        from unittest import mock
        with tempfile.TemporaryDirectory() as d:
            side = os.path.join(d, "vuln")
            os.makedirs(os.path.join(side, "drop"))
            _write(os.path.join(side, "drop", "fp.tar"), _tar_bytes([("x", b"1")]))
            with mock.patch.object(A, "_acquire_manual_tarfile",
                                   side_effect=A.UnsafeArchiveMember("bad")), \
                 mock.patch.object(A, "_acquire_manual_7z") as m7:
                with self.assertRaises(A.UnsafeArchiveMember):
                    A._acquire_manual("vuln", side, "L", root_dir=os.path.join(side, "root"))
                m7.assert_not_called()

    def test_unsafe_link_name_is_still_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            t = _write(os.path.join(d, "x.tar"), _tar_bytes(
                [("lib/a", b"A"), ("../escape", "->lib/a")]))
            with self.assertRaises(A.UnsafeArchiveMember):
                A._extract_tar(t, os.path.join(d, "out"))
            self.assertFalse(os.path.exists(os.path.join(d, "escape")))


if __name__ == "__main__":
    unittest.main()
