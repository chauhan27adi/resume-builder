"""MSSQL Stage 2 per-version output: each build's disassembly and pseudo-C go to their own
folders (disassembled_instructions_{vuln,fixed}_<version>/, decompiled_c_{vuln,fixed}_
<version>/, one <binary>_<sha8>/ subfolder per binary), the assembly diffs to one folder per
pair, and the version is named from --*-kb, the installer's file name or the engine version.
Ghidra is faked; scratch files live in TemporaryDirectory()s only."""
import json
import os
import tempfile
import unittest
from unittest import mock

from patch_differ_cli import _x86diff as X
from patch_differ_cli import pipeline as pl
from patch_differ_cli.mssql import stage2 as ms2
from patch_differ_cli.tests.test_fallback_and_symbol_reporting import _mssql_run
from patch_differ_cli.tests.test_silent_loss_fixes import _write

ENGINE = r"C:\pdiff\mssql_track1\acquire\vuln\engine"


def _read(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


class LabelTests(unittest.TestCase):
    def test_version_token(self):
        self.assertEqual(ms2._version_token("KB5122771"), "KB5122771")
        self.assertEqual(ms2._version_token("2022.160.1200.5"), "2022.160.1200.5")
        self.assertEqual(ms2._version_token(None), "unversioned")
        self.assertEqual(ms2._version_token("a/b c"), "a_b_c")

    def test_kb_from_the_installer_name(self):
        with tempfile.TemporaryDirectory() as d:
            _write(os.path.join(d, "SQLServer2022-KB5122771-x64.exe"), b"MZ")
            self.assertEqual(pl._mssql_version_label(d, d), "KB5122771")

    def test_two_kbs_or_none_fall_back_to_the_engine_version(self):
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(pl, "_mssql_engine_version", return_value="2022.160.1.2"):
            _write(os.path.join(d, "SQLServer2022-KB5122771-x64.exe"), b"MZ")
            _write(os.path.join(d, "SQLServer2022-KB5128493-x64.exe"), b"MZ")
            self.assertEqual(pl._mssql_version_label(d, d), "2022.160.1.2")
            self.assertEqual(pl._mssql_version_label(None, d), "2022.160.1.2")

    def test_label_is_the_largest_installers_kb(self):
        # The largest .exe is the one _prepare_mssql_dir extracts, so its KB names the build
        # even when a smaller, KB-less helper .exe sits beside it.
        with tempfile.TemporaryDirectory() as d:
            _write(os.path.join(d, "SQLServer2022-KB5122771-x64.exe"), b"MZ" + b"\x00" * 500)
            _write(os.path.join(d, "vcredist_x64.exe"), b"MZ")
            self.assertEqual(pl._mssql_version_label(d, d), "KB5122771")

    def test_label_does_not_take_a_smaller_helpers_kb(self):
        # Regression: the extracted build is the large KB-less installer; a small KB-named
        # helper must not mislabel it. Falls back to the authoritative engine version.
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(pl, "_mssql_engine_version", return_value="2022.160.1.2"):
            _write(os.path.join(d, "CumulativeUpdate-x64.exe"), b"MZ" + b"\x00" * 500)
            _write(os.path.join(d, "SsmsSetup-KB1234567.exe"), b"MZ")
            self.assertEqual(pl._mssql_version_label(d, d), "2022.160.1.2")

    def test_a_config_sibling_does_not_hide_the_engine_binary(self):
        # Regression: a sqlservr*.config / non-PE sibling sharing the "sqlservr" token must
        # not be chosen over (or crash the read of) the real engine binary.
        import pefile

        class _FI:
            FileVersionMS = (2022 << 16) | 160
            FileVersionLS = (1200 << 16) | 5

        class _PE:
            def __init__(self, path, **k):
                if "config" in str(path).lower():
                    raise ValueError("not a PE")
                self.VS_FIXEDFILEINFO = [_FI]

            def parse_data_directories(self, **k):
                pass

            def close(self):
                pass

        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(pefile, "PE", _PE):
            _write(os.path.join(d, "ENG_RE_sqlservr_exe_config_64"), b"<configuration/>")
            _write(os.path.join(d, "ENG_RE_sqlservr_exe_64"), b"MZreal")
            self.assertEqual(pl._mssql_engine_version(d), "2022.160.1200.5")

    def test_engine_version_of_a_non_pe_is_none(self):
        with tempfile.TemporaryDirectory() as d:
            _write(os.path.join(d, "ENG_RE_sqlservr_exe_64"), b"not a PE")
            self.assertIsNone(pl._mssql_engine_version(d))
            self.assertIsNone(pl._mssql_engine_version(os.path.join(d, "missing")))

    @unittest.skipUnless(os.path.isdir(ENGINE), "extracted MSSQL engine not on this machine")
    def test_engine_version_of_the_real_build(self):
        self.assertEqual(pl._mssql_engine_version(ENGINE), "2022.160.1200.5")

    def test_pipeline_passes_the_derived_labels(self):
        seen = {}

        class Stage:
            @staticmethod
            def run(*a, **k):
                seen.update(k)
                return {"counts": {}, "readable_files": []}

        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(pl, "_prepare_mssql_dir", lambda p, *a: str(p)), \
                mock.patch.object(pl, "_import", lambda name: Stage):
            for side, kb in (("v", "5122771"), ("f", "5128493")):
                _write(os.path.join(d, side, f"SQLServer2022-KB{kb}-x64.exe"), b"MZ")
            pl.run_pipeline("mssql", vuln_dir=os.path.join(d, "v"),
                            fixed_dir=os.path.join(d, "f"), out_dir=os.path.join(d, "o"),
                            stages={"triage", "stage2"}, verbose=False)
        self.assertEqual((seen["vuln_label"], seen["fixed_label"]), ("KB5122771", "KB5128493"))

    def test_kb_arguments_still_win(self):
        seen = {}

        class Stage:
            @staticmethod
            def run(*a, **k):
                seen.update(k)
                return {"counts": {}, "readable_files": []}

        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(pl, "_prepare_mssql_dir", lambda p, *a: str(p)), \
                mock.patch.object(pl, "_import", lambda name: Stage):
            for side in ("v", "f"):
                _write(os.path.join(d, side, "SQLServer2022-KB1111111-x64.exe"), b"MZ")
            pl.run_pipeline("mssql", vuln_dir=os.path.join(d, "v"),
                            fixed_dir=os.path.join(d, "f"), out_dir=os.path.join(d, "o"),
                            stages={"triage", "stage2"}, verbose=False,
                            vuln_kb="5000001", fixed_kb="KB5000002")
        self.assertEqual((seen["vuln_label"], seen["fixed_label"]), ("KB5000001", "KB5000002"))


class LayoutTests(unittest.TestCase):
    def _run(self, version_dirs, decompile=True):
        real = ms2._process_dll

        def with_layout(job):
            job.update(decompile=decompile, decompile_max=None)
            if version_dirs:
                job["version_dirs"] = version_dirs(job)
            return real(job)

        with mock.patch.object(ms2, "_process_dll", with_layout), \
                mock.patch.object(ms2, "decompile_cached",
                                  lambda pb, fb, cache, *c: ("int prior_c;", "int fixed_c;", True)), \
                mock.patch.object(X, "fix_signature", return_value=(1, ["guard"])):
            return _mssql_run(symbolized=("prior", "fixed"))

    def test_each_build_gets_its_own_files(self):
        td = tempfile.TemporaryDirectory()          # outlives _mssql_run's own scratch dir
        self.addCleanup(td.cleanup)
        out = td.name
        r = self._run(lambda job: ms2._version_dirs(out, "KB1", "KB2"))
        self.assertTrue(r["ok"])
        for build, ver, c_text in (("vuln", "KB1", "int prior_c;"), ("fixed", "KB2", "int fixed_c;")):
            (sub,) = os.listdir(os.path.join(out, f"disassembled_instructions_{build}_{ver}"))
            self.assertTrue(sub.startswith("ENG_RE_sqlmin_dll_64_"))
            asm_dir = os.path.join(out, f"disassembled_instructions_{build}_{ver}", sub)
            meta = json.loads(_read(os.path.join(asm_dir, "binary.json")))
            self.assertEqual((meta["version"], meta["build"], meta["name"]),
                             (ver, build, "sqlmin.dll"))
            self.assertTrue(sub.endswith(meta["sha256"][:8]))
            listing = _read(os.path.join(asm_dir, ms2._safe("CheckLength") + ".asm"))
            self.assertIn("; CheckLength", listing)
            self.assertIn("00001010  81ff", listing, "RVA and instruction bytes")
            self.assertIn("cmp edi,", listing)
            c_file = os.path.join(out, f"decompiled_c_{build}_{ver}", sub,
                                  ms2._safe("CheckLength") + ".c")
            self.assertEqual(_read(c_file), c_text, "each side's own pseudo-C")
        self.assertFalse(os.path.exists(os.path.join(out, "decompiled_c")))

    def test_a_job_without_version_folders_writes_the_old_way(self):
        r = self._run(None)
        self.assertTrue(r["ok"])
        # _mssql_run's legacy job puts decompiled_c_dir at its tempdir: the files are named
        # <vuln>_<fixed>_<ts>__fn__... there (no exception, no per-version folder needed)

    def test_run_creates_no_empty_version_folders(self):
        from patch_differ_cli import _parallel
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(_parallel, "run_jobs", lambda *a, **k: None):
            for side in ("p", "f"):
                _write(os.path.join(d, side, "ENG_RE_qds_64"), b"MZ")
            ms2.run(os.path.join(d, "p"), os.path.join(d, "f"), os.path.join(d, "w"),
                    stage0={"code_changed": [{"name": "ENG_RE_qds_64"}]}, decompile=True,
                    vuln_label="KB1", fixed_label="KB2")
            made = sorted(os.listdir(os.path.join(d, "w", "stage2")))
        self.assertIn("disassembled_instructions_KB1_vs_KB2", made)
        self.assertFalse([m for m in made if m.startswith(("decompiled_c_", "disassembled_"
                                                           "instructions_vuln", "disassembled_"
                                                           "instructions_fixed"))], made)

    def test_run_sets_bindiff_dir_beside_stage2(self):
        # bug.md DB2-T1-3 (ported to MSSQL for parity): BinDiff working data goes to
        # <workdir>/bindiff_work/, not inside stage2/.
        from patch_differ_cli import _parallel
        captured = {}
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(_parallel, "run_jobs",
                                  lambda jobs, *a, **k: captured.update(jobs=list(jobs))):
            for side in ("p", "f"):
                _write(os.path.join(d, side, "ENG_RE_qds_64"), b"MZ")
            ms2.run(os.path.join(d, "p"), os.path.join(d, "f"), os.path.join(d, "w"),
                    stage0={"code_changed": [{"name": "ENG_RE_qds_64"}]},
                    use_bindiff=True, vuln_label="KB1", fixed_label="KB2")
            job = captured["jobs"][0]
            self.assertEqual(job["bindiff_dir"], os.path.join(d, "w", "bindiff_work"))
            self.assertNotIn(os.path.join("w", "stage2"), job["bindiff_dir"])

    def test_two_builds_never_share_a_binary_folder(self):
        with tempfile.TemporaryDirectory() as d:
            a = _write(os.path.join(d, "a", "x.dll"), b"build one")
            b = _write(os.path.join(d, "b", "x.dll"), b"build two")
            info = {"label": "unversioned", "build": "vuln"}
            fa = ms2._binary_folder(os.path.join(d, "out"), "x.dll", a, info)
            fb = ms2._binary_folder(os.path.join(d, "out"), "x.dll", b, info)
            self.assertNotEqual(fa, fb)
            self.assertEqual(ms2._binary_folder(os.path.join(d, "out"), "x.dll", a, info), fa)


class _FakeImg:
    def __init__(self, groups, byrva):
        self.groups, self._b = groups, byrva

    def bytes_at(self, rva, size):
        return self._b.get(rva, b"\x90" * size)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class _FakeSym:
    ok = True

    def __init__(self, names):
        self._n = names

    def exact_name(self, rva):
        return self._n.get(rva)


class MssqlDedupAndChunkTests(unittest.TestCase):
    def test_distinct_same_named_functions_are_both_kept(self):      # bug.md MSSQL-NT-1
        groups = {0x1000: [(0x1000, 0x1010)], 0x2000: [(0x2000, 0x2020)]}
        byrva = {0x1000: b"\xAA" * 16, 0x2000: b"\xBB" * 32}          # distinct code, 0x2000 larger
        with mock.patch.object(ms2, "FuncImage", lambda p: _FakeImg(groups, byrva)):
            fm = ms2._func_map("x", _FakeSym({0x1000: "Foo", 0x2000: "Foo"}))
        self.assertEqual(sorted(fm), ["Foo", "Foo [#2]"], "both distinct copies kept")
        self.assertEqual(fm["Foo"][0], 0x2000, "the largest keeps the bare key (no regression)")
        self.assertEqual(fm["Foo [#2]"][0], 0x1000)

    def test_identical_comdat_copies_fold_to_one(self):              # bug.md MSSQL-NT-1
        groups = {0x1000: [(0x1000, 0x1010)], 0x2000: [(0x2000, 0x2010)]}
        byrva = {0x1000: b"\xCC" * 16, 0x2000: b"\xCC" * 16}          # byte-identical (true COMDAT)
        with mock.patch.object(ms2, "FuncImage", lambda p: _FakeImg(groups, byrva)):
            fm = ms2._func_map("x", _FakeSym({0x1000: "Bar", 0x2000: "Bar"}))
        self.assertEqual(sorted(fm), ["Bar"], "identical copies fold to a single card")

    def test_unnamed_and_unique_names_are_unchanged(self):
        groups = {0x1000: [(0x1000, 0x1008)], 0x2000: [(0x2000, 0x2008)]}
        byrva = {0x1000: b"\x90" * 8, 0x2000: b"\xC3" * 8}
        with mock.patch.object(ms2, "FuncImage", lambda p: _FakeImg(groups, byrva)):
            fm = ms2._func_map("x", _FakeSym({0x1000: "Uniq"}))       # 0x2000 has no name
        self.assertEqual(sorted(fm), ["Uniq", "sub_2000"])           # bare + sub_, no qualifiers

    def test_norm_chunk_pair_pairs_hot_chunks_by_role(self):         # bug.md MSSQL-NT-2
        md = X.md()
        hot = b"\x90\x90\xc3"                                        # identical on both sides
        cold_p, cold_f = b"\xb8\x01\x00\x00\x00\xc3", b"\xb8\x02\x00\x00\x00\xc3"
        # fixed's cold fragment sits BELOW the hot entry; sorted-position pairing would mis-pair
        pL, _fL, pL_sc, _fsc, _cls = ms2._norm_chunk_pair(
            md, [(0x1000, hot), (0x5000, cold_p)], [(0x800, cold_f), (0x1000, hot)], 0x1000, 0x1000)
        self.assertLess(len(pL_sc), len(pL),
                        "the identical hot chunk is paired by role and excluded from scoring")


if __name__ == "__main__":
    unittest.main()
