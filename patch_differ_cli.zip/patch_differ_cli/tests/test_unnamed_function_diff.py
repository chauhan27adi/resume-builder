"""Regression tests for CRIT-NT-1: an MSSQL function with no public PDB symbol (keyed
"sub_<rva>" by _func_map()) used to be unconditionally excluded from Stage 2's name-mode
diff whenever its RVA was unchanged between the prior and fixed build — even when its
bytes genuinely changed. This contradicted mssql/stage2.py's own module docstring
("the function is still diffed but labelled by RVA... Stage 2 degrades, never fails")
and was a silent false-negative for exactly the kind of internal/static helper function
(no public PDB entry) that a security fix is likely to touch.

The fix (mssql/stage2.py's name-mode `raw` derivation): stop excluding "sub_"-prefixed
keys from `raw` (the byte-changed-at-a-shared-RVA set — a reliable signal, since a shared
RVA key already means "the same code slot in both builds"). `new`/`removed` deliberately
keep excluding unnamed functions: an RVA present on only one side is a much weaker
signal for a nameless function, since any unrelated layout shift elsewhere in the module
changes every downstream RVA, which would manufacture phantom added/removed entries
rather than catch a real one.

These tests drive the REAL production function mssql.stage2._process_dll() end-to-end,
with only the PDB/symbolizer layer mocked (no real PE/PDB/symbol-server access needed) —
the exact harness used to live-reproduce the original defect."""
import os
import tempfile
import unittest

import patch_differ_cli.mssql.stage2 as ms2


class _FakeSymbolizer:
    """A Symbolizer that resolves no public PDB names at all — the exact condition that
    forces _func_map() to fall back to its "sub_<rva>" placeholder key."""
    def __init__(self, *a, **kw):
        self.ok = True

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def name_at(self, rva):
        return None


class _Harness(unittest.TestCase):
    def _run(self, prior_funcs, fixed_funcs):
        """prior_funcs/fixed_funcs: {name: (rva, [(addr, bytes), ...])}"""
        orig_func_map = ms2._func_map
        orig_fetch_pdb = ms2.sym.fetch_pdb
        orig_symbolizer = ms2.sym.Symbolizer
        ms2._func_map = lambda path, symbolizer: dict(
            prior_funcs if "prior" in path else fixed_funcs)
        ms2.sym.fetch_pdb = lambda *a, **kw: None
        ms2.sym.Symbolizer = _FakeSymbolizer
        try:
            with tempfile.TemporaryDirectory(prefix="pdff_crit_nt1_") as d:
                prior_dir = os.path.join(d, "prior")
                fixed_dir = os.path.join(d, "fixed")
                out = os.path.join(d, "out")
                os.makedirs(prior_dir); os.makedirs(fixed_dir); os.makedirs(out)
                rel = "risky.dll"
                with open(os.path.join(prior_dir, rel), "wb") as f:
                    f.write(b"\x00")
                with open(os.path.join(fixed_dir, rel), "wb") as f:
                    f.write(b"\x00")
                job = {
                    "prior_dir": prior_dir, "fixed_dir": fixed_dir, "rel": rel, "out": out,
                    "attrib": [], "online": False,
                    "pdb_cache": os.path.join(d, "pdbcache"),
                    "use_bindiff": False, "decompile": False,
                    "decompile_cache": os.path.join(out, "decompile_cache"),
                    "decompiled_c_dir": os.path.join(out, "decompiled_c"),
                    "disassembled_dir": os.path.join(out, "disassembled_instructions"),
                    "run_ts": "20260101T000000Z", "vuln_label": "vuln", "fixed_label": "fixed",
                }
                os.makedirs(job["disassembled_dir"])
                return ms2._process_dll(job)
        finally:
            ms2._func_map = orig_func_map
            ms2.sym.fetch_pdb = orig_fetch_pdb
            ms2.sym.Symbolizer = orig_symbolizer


class TestUnnamedFunctionWithRealChangeIsNoLongerDropped(_Harness):
    def test_unnamed_function_same_rva_changed_bytes_is_reported(self):
        prior = {"sub_1000": (0x1000, [(0x1000, b"\x90\xc3")])}            # nop; ret
        fixed = {"sub_1000": (0x1000, [(0x1000, b"\x90\x90\xc3")])}        # nop; nop; ret
        result = self._run(prior, fixed)
        self.assertEqual(result["funcs_total"], 1,
                        "the unnamed, byte-changed function must now be counted")
        objects = [r["object"] for r in result["readable"]]
        self.assertTrue(any("sub_1000" in o for o in objects),
                       f"expected sub_1000 in the output, got: {objects}")


class TestUnnamedFunctionControls(_Harness):
    """Confirms the fix is precisely scoped — no new false positives, and new/removed
    deliberately keep excluding unnamed functions."""

    def test_unnamed_function_identical_bytes_is_not_reported(self):
        same = b"\x90\xc3"
        result = self._run({"sub_2000": (0x2000, [(0x2000, same)])},
                           {"sub_2000": (0x2000, [(0x2000, same)])})
        self.assertEqual(result["funcs_total"], 0)
        self.assertEqual(result["readable"], [])

    def test_unnamed_function_only_in_fixed_is_not_reported_as_added(self):
        result = self._run({}, {"sub_3000": (0x3000, [(0x3000, b"\x90\xc3")])})
        self.assertEqual(result["funcs_total"], 0)
        self.assertEqual(result["readable"], [])

    def test_unnamed_function_only_in_prior_is_not_reported_as_removed(self):
        result = self._run({"sub_4000": (0x4000, [(0x4000, b"\x90\xc3")])}, {})
        self.assertEqual(result["funcs_total"], 0)
        self.assertEqual(result["readable"], [])

    def test_named_function_behavior_is_unaffected(self):
        prior = {"DoRiskyThing": (0x1000, [(0x1000, b"\x90\xc3")])}
        fixed = {"DoRiskyThing": (0x1000, [(0x1000, b"\x90\x90\xc3")])}
        result = self._run(prior, fixed)
        self.assertEqual(result["funcs_total"], 1)
        objects = [r["object"] for r in result["readable"]]
        self.assertTrue(any("DoRiskyThing" in o for o in objects))


if __name__ == "__main__":
    unittest.main()
