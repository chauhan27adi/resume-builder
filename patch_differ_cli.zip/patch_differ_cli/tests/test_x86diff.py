"""Unit tests for _x86diff.py — the shared Capstone-based normalization/scoring core used
by all three backends' Stage 2. Pure logic, no external tools required (capstone is an
always-installed core dependency per pyproject.toml)."""
import unittest

from patch_differ_cli import _x86diff as X


class TestIsSecurityIntrinsic(unittest.TestCase):
    def test_hard_intrinsic_matches(self):
        self.assertTrue(X.is_security_intrinsic("__report_rangecheckfailure"))
        self.assertTrue(X.is_security_intrinsic("__stack_chk_fail"))

    def test_soft_intrinsic_matches(self):
        self.assertTrue(X.is_security_intrinsic("memcpy_s"))
        self.assertTrue(X.is_security_intrinsic("__wassert"))

    def test_unrelated_name_does_not_match(self):
        self.assertFalse(X.is_security_intrinsic("DoSomethingUnrelated"))
        self.assertFalse(X.is_security_intrinsic(""))
        self.assertFalse(X.is_security_intrinsic(None))


class TestNorm(unittest.TestCase):
    """norm() against real Capstone disassembly of tiny, fixed byte sequences."""

    def test_disassembles_simple_bytes(self):
        m = X.md()
        # nop; ret
        lines, shape, imms = X.norm(m, 0x1000, b"\x90\xc3")
        self.assertEqual(lines, ["nop ", "ret "])
        self.assertEqual(shape, lines)  # no operands -> shape == lines
        self.assertEqual(imms, [])

    def test_immediate_is_kept_in_lines_but_blanked_in_shape(self):
        m = X.md()
        # mov eax, 0x2a ; ret
        lines, shape, imms = X.norm(m, 0x1000, b"\xb8\x2a\x00\x00\x00\xc3")
        self.assertIn("i2a", lines[0])
        self.assertNotIn("i2a", shape[0])
        self.assertEqual(imms, [("i", 0x2a)])

    def test_branch_immediate_becomes_L_not_a_kept_immediate(self):
        m = X.md()
        # je +2 ; nop; nop ; ret  (conditional branch target must map to 'L', not an imm)
        lines, shape, imms = X.norm(m, 0x1000, b"\x74\x02\x90\x90\xc3")
        self.assertIn("L", lines[0])
        self.assertEqual(imms, [])  # branch targets are never counted as "real" immediates

    def test_small_mem_displacement_is_kept_in_lines_but_blanked_in_shape(self):
        # CRIT-NT-3: mov eax, [rbx+0x10] — a small struct-offset displacement must be kept
        # in lines (as documented) but blanked in shape, and fed into imms tagged "d", so
        # a struct-layout shift can be told apart from a real structural change.
        m = X.md()
        lines, shape, imms = X.norm(m, 0x1000, b"\x8b\x43\x10")
        self.assertIn("d10", lines[0])
        self.assertNotIn("d10", shape[0])
        self.assertEqual(imms, [("d", 0x10)])

    def test_large_mem_displacement_is_blanked_in_both_lines_and_shape(self):
        # mov eax, [rbx+0x3000] — a displacement past the 0x2000 threshold (more likely an
        # absolute/relocated address than a struct offset) is already blanked in lines too
        # (pre-existing behavior, unchanged by this fix) and must stay out of imms.
        m = X.md()
        lines, shape, imms = X.norm(m, 0x1000, b"\x8b\x83\x00\x30\x00\x00")
        self.assertNotIn("3000", lines[0])
        self.assertEqual(lines, shape)
        self.assertEqual(imms, [])


class TestClassify(unittest.TestCase):
    def test_identical_lines_are_same(self):
        self.assertEqual(X.classify(["a"], ["a"], [1], ["a"], ["a"], [1]), "same")

    def test_structural_change_is_code(self):
        self.assertEqual(
            X.classify(["mov R, i1"], ["mov R"], [1], ["push R"], ["push R"], [1]),
            "code")

    def test_uniform_small_immediate_shift_is_churn(self):
        # pL != fL (the immediate token differs) but pS == fS (shape blanks immediates) —
        # the only way classify() reaches the immediate-delta analysis at all. Deltas are
        # a dominant uniform small shift (e.g. a __LINE__ renumber) -> churn, not a real
        # change.
        pL, fL = ["mov R, i64"], ["mov R, i65"]
        pS = fS = ["mov R, i"]
        pI = [("i", 100), ("i", 200), ("i", 300), ("i", 400)]
        fI = [("i", 101), ("i", 201), ("i", 301), ("i", 500)]  # 3 of 4 deltas are +1 (dominant >= 60%)
        self.assertEqual(X.classify(pL, pS, pI, fL, fS, fI), "churn")

    def test_non_uniform_immediate_change_is_const(self):
        pL, fL = ["mov R, i64"], ["mov R, i65"]
        pS = fS = ["mov R, i"]
        pI = [("i", 100), ("i", 5)]
        fI = [("i", 999), ("i", 5000)]  # large, non-uniform deltas -> a real constant change
        self.assertEqual(X.classify(pL, pS, pI, fL, fS, fI), "const")

    def test_uniform_mem_disp_shift_is_churn(self):
        # CRIT-NT-3: a uniform struct-offset shift (ordinary recompile noise whenever an
        # unrelated field moves elsewhere in a shared struct) must be "churn", the same as
        # the __LINE__-renumber immediate-shift case above.
        pL, fL = ["mov R [R+R*1+d10]"], ["mov R [R+R*1+d18]"]
        pS = fS = ["mov R [R+R*1+D]"]
        pI = [("d", 0x10), ("d", 0x20), ("d", 0x30), ("d", 0x40)]
        fI = [("d", 0x18), ("d", 0x28), ("d", 0x38), ("d", 0x48)]  # uniform +8 shift
        self.assertEqual(X.classify(pL, pS, pI, fL, fS, fI), "churn")

    def test_standalone_immediate_change_amid_mem_disp_churn_is_not_swallowed(self):
        # CRIT-NT-3 follow-up: a genuine, isolated "i"-kind change (e.g. an off-by-one
        # constant fix) riding alongside an unrelated, dominant "d"-kind (struct-offset)
        # shift in the same function must NOT be laundered into "churn" — each kind's
        # deltas must independently look like a dominant shift. Here "d" is a clean
        # dominant shift but "i" has only one delta (len < 3), so the whole thing must
        # fall through to "const", not "churn".
        pL = ["a", "b", "c", "d", "cmp R i5"]
        fL = ["a2", "b2", "c2", "d2", "cmp R i6"]
        pS = fS = ["sA", "sB", "sC", "sD", "cmp R i"]
        pI = [("d", 0x10), ("d", 0x20), ("d", 0x30), ("d", 0x40), ("i", 5)]
        fI = [("d", 0x18), ("d", 0x28), ("d", 0x38), ("d", 0x48), ("i", 6)]
        self.assertEqual(X.classify(pL, pS, pI, fL, fS, fI), "const")

    def test_mixed_kind_that_are_both_dominant_shifts_is_still_churn(self):
        # When BOTH kinds present independently qualify as dominant uniform shifts, the
        # whole thing is still churn (e.g. a struct shift plus an unrelated __LINE__-style
        # renumber cluster, co-occurring by coincidence).
        pL = ["a", "b", "c", "e", "f", "g"]
        fL = ["a2", "b2", "c2", "e2", "f2", "g2"]
        pS = fS = ["sA", "sB", "sC", "sE", "sF", "sG"]
        pI = [("d", 0x10), ("d", 0x20), ("d", 0x30), ("i", 100), ("i", 200), ("i", 300)]
        fI = [("d", 0x18), ("d", 0x28), ("d", 0x38), ("i", 101), ("i", 201), ("i", 301)]
        self.assertEqual(X.classify(pL, pS, pI, fL, fS, fI), "churn")


class TestFixSignatureRelocation(unittest.TestCase):
    """CRIT-NT-6: difflib reports a block that merely MOVED (compiler basic-block reordering,
    hot/cold splitting, PGO) as delete-at-old-position + insert-at-new-position. Scoring that
    insert as new code manufactured a false fix-signature, which then bypasses _EMIT_CAP in
    every backend. Driven with real Capstone disassembly of hand-built byte sequences."""

    SETUP = bytes.fromhex("b801000000" "b802000000" "b803000000")
    GUARD = bytes.fromhex("83f810" "7300" "e800000000")      # cmp eax,0x10 ; jae ; call
    TAIL = bytes.fromhex("b804000000" "b805000000" "c3")
    EXTRA = bytes.fromhex("b809000000")

    def _score(self, prior, fixed):
        import difflib
        m = X.md()
        pL, _pS, _pI = X.norm(m, 0x1000, prior)
        fL, _fS, _fI = X.norm(m, 0x1000, fixed)
        ops = difflib.SequenceMatcher(a=pL, b=fL, autojunk=False).get_opcodes()
        return X.fix_signature(pL, fL, opcodes=ops)[0]

    def test_relocated_guard_is_not_a_fix(self):
        s, g, t = self.SETUP, self.GUARD, self.TAIL
        self.assertEqual(self._score(s + g + t, g + s + t), 0)

    def test_genuinely_added_guard_still_scores(self):
        s, g, t = self.SETUP, self.GUARD, self.TAIL
        self.assertGreater(self._score(s + t, s + g + t), 0)

    def test_new_copy_of_a_guard_that_still_exists_unchanged_still_scores(self):
        s, g, t = self.SETUP, self.GUARD, self.TAIL
        self.assertGreater(self._score(g + s + t, g + s + g + t), 0)

    def test_relocated_guard_sharing_an_insert_run_with_unrelated_lines_is_not_a_fix(self):
        s, g, t, e = self.SETUP, self.GUARD, self.TAIL, self.EXTRA
        self.assertEqual(self._score(s + e + g + t, g + e + s + t), 0)
        self.assertEqual(self._score(s + g + t, e + g + s + t), 0)

    def test_relocated_guard_does_not_hide_a_genuinely_new_guard_next_to_it(self):
        # prior has guard G at the end; fixed moves G to the front AND adds a brand-new
        # (different) constant check right beside it — the new check must still score.
        s, g, t = self.SETUP, self.GUARD, self.TAIL
        new_guard = bytes.fromhex("83f820" "7300" "e800000000")   # cmp eax,0x20 ; jae ; call
        self.assertGreater(self._score(s + t + g, new_guard + g + s + t), 0)

    def test_single_line_collisions_are_not_discounted(self):
        # A lone "call L" inserted while another "call L" is deleted elsewhere is too
        # ambiguous to call a move; stay conservative (keep scoring it) rather than risk
        # hiding a real added validation call.
        import difflib
        a = ["mov R", "call L", "add R", "sub R", "xor R"]
        b = ["mov R", "add R", "sub R", "xor R", "call L"]
        tags = [o[0] for o in difflib.SequenceMatcher(a=a, b=b, autojunk=False).get_opcodes()]
        self.assertIn("delete", tags)       # guard the test's own premise
        self.assertIn("insert", tags)
        score, _ = X.fix_signature(a, b)
        self.assertGreater(score, 0)

    def test_added_null_check_not_hidden_by_unrelated_replaced_code(self):
        # IMP-NT-2: a NEW `test rdi,rdi ; je` at the top, while an unrelated region that
        # happened to contain `test rbx,rbx ; je` was rewritten in place (difflib 'replace').
        # Normalized, both read "test R R / je L"; a replaced run is not evidence of a move.
        s1 = bytes.fromhex("b801000000" "b802000000")
        s2 = bytes.fromhex("b804000000" "c3")
        prior = s1 + bytes.fromhex("4885db" "7400" "b803000000") + s2
        fixed = bytes.fromhex("4885ff" "7400") + s1 + bytes.fromhex("31c9" "83c101" "b803000000") + s2
        self.assertGreater(self._score(prior, fixed), 0)

    def test_one_deleted_check_explains_at_most_one_inserted_copy(self):
        # One deleted "test R R / je L" may account for ONE relocated copy, never all of the
        # genuinely added copies too.
        prior = ["mov R i1", "test R R", "je L", "mov R i2", "mov R i3", "ret"]
        fixed = ["mov R i1", "mov R i2", "test R R", "je L", "mov R i3",
                 "test R R", "je L", "test R R", "je L", "ret"]
        ops = [("equal", 0, 1, 0, 1), ("delete", 1, 3, 1, 1), ("equal", 3, 4, 1, 2),
               ("insert", 4, 4, 2, 4), ("equal", 4, 5, 4, 5), ("insert", 5, 5, 5, 9),
               ("equal", 5, 6, 9, 10)]
        score, reasons = X.fix_signature(prior, fixed, opcodes=ops)
        self.assertGreater(score, 0)
        self.assertIn("inserted 2 guard(s) (compare+branch)", reasons)

    def test_work_budget_exhaustion_falls_back_to_conservative_scoring(self):
        from unittest import mock
        s, g, t = self.SETUP, self.GUARD, self.TAIL
        with mock.patch.object(X, "_RELOCATION_WORK_BUDGET", 0):
            self.assertGreater(self._score(s + g + t, g + s + t), 0)


class TestFixSignature(unittest.TestCase):
    def test_no_fixed_lines_scores_zero(self):
        self.assertEqual(X.fix_signature(["a"], []), (0, []))

    def test_pure_replace_with_no_intrinsics_scores_zero(self):
        # Pure replace (mov R->mov R2) is recompilation churn, not an insertion.
        score, reasons = X.fix_signature(["mov R, i1"], ["mov R2, i1"])
        self.assertEqual((score, reasons), (0, []))

    def test_inserted_guard_scores_above_zero(self):
        prior = ["push R", "ret "]
        fixed = ["push R", "cmp R, i10", "je L", "ret "]
        score, reasons = X.fix_signature(prior, fixed)
        self.assertGreater(score, 0)
        self.assertTrue(any("guard" in r for r in reasons))

    def test_added_hard_intrinsic_dominates_score_and_is_named_in_reasons(self):
        score, reasons = X.fix_signature(
            ["ret "], ["call i1", "ret "],
            added_intrinsics=["__report_rangecheckfailure"])
        self.assertGreaterEqual(score, 8)
        self.assertTrue(any("__report_rangecheckfailure" in r for r in reasons))

    def test_large_insertion_is_penalized_relative_to_small_one(self):
        small_prior = ["ret "]
        small_fixed = ["cmp R, i1", "je L", "ret "]
        small_score, _ = X.fix_signature(small_prior, small_fixed)

        huge_fixed = ["cmp R, i1", "je L"] + [f"nop {i}" for i in range(150)] + ["ret "]
        huge_score, _ = X.fix_signature(small_prior, huge_fixed)

        self.assertGreater(small_score, huge_score)


if __name__ == "__main__":
    unittest.main()
