"""Regression tests for IMP-NT-3: MSSQL triage only examined names present in BOTH engine
dirs and recorded nothing about the rest, so a DLL added or removed by a patch was invisible
in the report (DB2/Oracle triage already record theirs). Name matching was also
case-sensitive, so on Windows a name differing only in case dropped the file from both sides."""
import os
import tempfile
import unittest
from unittest import mock

from patch_differ_cli.mssql import triage as T


def _dirs(d, prior, fixed):
    p, f = os.path.join(d, "prior"), os.path.join(d, "fixed")
    for root, files in ((p, prior), (f, fixed)):
        os.makedirs(root)
        for name, data in files.items():
            with open(os.path.join(root, name), "wb") as fh:
                fh.write(data)
    return p, f


class TestOneSided(unittest.TestCase):
    def test_added_and_removed_are_recorded(self):
        with tempfile.TemporaryDirectory(prefix="pdff_imp3_") as d:
            p, f = _dirs(d, {"ENG_RE_common_dll_64": b"x", "ENG_RE_removed_dll_64": b"r"},
                         {"ENG_RE_common_dll_64": b"x", "ENG_RE_newhardening_dll_64": b"n"})
            os.makedirs(os.path.join(f, "subdir_only_in_fixed"))     # dirs are not files
            r = T.run(p, f, os.path.join(d, "out"))
        self.assertEqual(r["counts"]["total"], 1)
        self.assertEqual([e["name"] for e in r["added"]], ["ENG_RE_newhardening_dll_64"])
        self.assertEqual([e["name"] for e in r["removed"]], ["ENG_RE_removed_dll_64"])
        self.assertEqual(r["counts"]["added"], 1)
        self.assertEqual(r["counts"]["removed"], 1)
        self.assertEqual(r["added"][0]["pretty"], "newhardening.dll")
        self.assertEqual(r["added"][0]["kind"], "content")   # not a PE

    def test_no_one_sided_files_gives_empty_lists(self):
        with tempfile.TemporaryDirectory(prefix="pdff_imp3b_") as d:
            p, f = _dirs(d, {"a": b"1"}, {"a": b"2"})
            r = T.run(p, f, os.path.join(d, "out"))
        self.assertEqual((r["added"], r["removed"]), ([], []))
        self.assertEqual(r["counts"]["content_changed"], 1)


class TestCaseMatching(unittest.TestCase):
    def test_case_only_difference_pairs_on_windows(self):
        with tempfile.TemporaryDirectory(prefix="pdff_imp3c_") as d:
            p, f = _dirs(d, {"ENG_RE_sqlmin_dll_64": b"1"}, {"ENG_RE_SQLMIN_dll_64": b"2"})
            with mock.patch.object(T.os, "name", "nt"):
                common, added, removed = T._pair_names(p, f)
        self.assertEqual(common, [("ENG_RE_sqlmin_dll_64", "ENG_RE_SQLMIN_dll_64")])
        self.assertEqual((added, removed), ([], []))

    def test_case_sensitive_platform_keeps_names_distinct(self):
        with tempfile.TemporaryDirectory(prefix="pdff_imp3d_") as d:
            p, f = _dirs(d, {"Lib_dll_64": b"1"}, {"LIB_dll_64": b"2"})
            with mock.patch.object(T.os, "name", "posix"):
                common, added, removed = T._pair_names(p, f)
        self.assertEqual(common, [])
        self.assertEqual((added, removed), (["LIB_dll_64"], ["Lib_dll_64"]))

    def test_fold_collision_falls_back_to_exact_matching(self):
        listing = {"P": ["a_dll_64", "A_dll_64"], "F": ["a_dll_64"]}
        with mock.patch.object(T.os, "name", "nt"), \
                mock.patch.object(T.os, "listdir", lambda path: listing[path[-1]]):
            common, added, removed = T._pair_names("P", "F")
        self.assertEqual(common, [("a_dll_64", "a_dll_64")])
        self.assertEqual(removed, ["A_dll_64"])

    @unittest.skipUnless(os.name == "nt", "needs a case-insensitive filesystem")
    def test_case_mismatch_end_to_end_on_windows(self):
        with tempfile.TemporaryDirectory(prefix="pdff_imp3e_") as d:
            p, f = _dirs(d, {"ENG_RE_sqlmin_dll_64": b"1"}, {"ENG_RE_SQLMIN_dll_64": b"2"})
            r = T.run(p, f, os.path.join(d, "out"))
        self.assertEqual(r["counts"]["total"], 1)
        self.assertEqual(r["counts"]["content_changed"], 1)
        self.assertEqual((r["added"], r["removed"]), ([], []))


if __name__ == "__main__":
    unittest.main()
