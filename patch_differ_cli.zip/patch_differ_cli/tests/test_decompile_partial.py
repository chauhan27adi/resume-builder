"""Regression tests for bugs.md #7 (Track-2): a decompile where only ONE side produced
pseudo-C counted as a success — and was cached, so the incomplete pair was served from cache
on every later run — and the CLI never mentioned decompile failures at all."""
import contextlib
import io
import json
import os
import tempfile
import unittest
from unittest import mock

from patch_differ_cli import _decompile as D
from patch_differ_cli import cli
import patch_differ_cli.oracle.stage2 as o2


class TestDecompileCached(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory(prefix="pdff_dec7_")
        self.cache = self._td.name
        self.calls = 0

    def tearDown(self):
        self._td.cleanup()

    def _with(self, result):
        def fake(pb, fb):
            self.calls += 1
            return result
        return mock.patch.object(D, "_try_decompile", fake)

    def test_one_sided_output_is_returned_but_not_cached(self):
        err = io.StringIO()
        with self._with(("int f(){}", "", True)), contextlib.redirect_stderr(err):
            r1 = D.decompile_cached(b"p", b"f", self.cache)
            r2 = D.decompile_cached(b"p", b"f", self.cache)
        self.assertEqual(r1, ("int f(){}", "", True))
        self.assertEqual(self.calls, 2, "a one-sided result must be retried, not cached")
        self.assertIn("fixed side", err.getvalue())
        self.assertEqual(os.listdir(self.cache), [])

    def test_complete_output_is_cached(self):
        with self._with(("a", "b", True)):
            D.decompile_cached(b"p", b"f", self.cache)
            r = D.decompile_cached(b"p", b"f", self.cache)
        self.assertEqual(r, ("a", "b", True))
        self.assertEqual(self.calls, 1)

    def test_legacy_one_sided_cache_entry_is_not_a_hit(self):
        with self._with(("a", "b", True)):
            D.decompile_cached(b"p", b"f", self.cache)           # writes a full entry
        (entry,) = os.listdir(self.cache)
        with open(os.path.join(self.cache, entry), "w", encoding="utf-8") as fh:
            json.dump({"prior_c": "a", "fixed_c": ""}, fh)      # what an old version stored
        self.calls = 0
        with self._with(("a", "b2", True)):
            r = D.decompile_cached(b"p", b"f", self.cache)
        self.assertEqual(self.calls, 1)
        self.assertEqual(r[1], "b2")


class TestCacheKeyIncludesDecompiler(unittest.TestCase):
    """Found reviewing #7: the pseudo-C cache was keyed by function bytes only, so after a
    Ghidra upgrade (or a DecompileFunc.java change) old output kept being served."""

    def tearDown(self):
        D._IDENTITY = None

    def test_ghidra_change_invalidates_cache(self):
        calls = []

        def fake(p, f):
            calls.append(1)
            return ("a", "b", True)
        with tempfile.TemporaryDirectory(prefix="pdff_dec7k_") as d, \
                mock.patch.object(D, "_try_decompile", fake):
            D._IDENTITY = None
            with mock.patch.object(D.tp, "ghidra_home", lambda: r"C:\g\ghidra_11.0.3_PUBLIC"):
                D.decompile_cached(b"p", b"f", d)
                D.decompile_cached(b"p", b"f", d)
            D._IDENTITY = None
            with mock.patch.object(D.tp, "ghidra_home", lambda: r"C:\g\ghidra_12.0_PUBLIC"):
                D.decompile_cached(b"p", b"f", d)
        self.assertEqual(len(calls), 2, "same Ghidra -> hit; new Ghidra -> recompute")


class TestBackendCountsOneSidedAsFailed(unittest.TestCase):
    def test_oracle_counts_partial_decompile_as_failed(self):
        P = {"fn": (0x1000, b"\x90\xc3")}
        F = {"fn": (0x1000, b"\x90\x90\x90\x90\x83\xf8\x10\x73\x00\xe8\x00\x00\x00\x00\xc3")}
        stats = {"attempted": 0, "failed": 0}
        with tempfile.TemporaryDirectory(prefix="pdff_dec7o_") as d, \
                mock.patch.object(o2, "_func_map", lambda p: dict(P if p == "P" else F)), \
                mock.patch.object(o2, "decompile_cached", lambda pb, fb, c: ("int f(){}", "", True)):
            readable = []
            o2._diff_o("k.o", "k.o", "P", "F", d, readable, attrib=[], decompile=True,
                       decompile_cache=os.path.join(d, "c"), decompiled_c_dir=d,
                       decompile_stats=stats)
        self.assertEqual(readable[0]["fix_score"] > 0, True, "fixture must trigger decompile")
        self.assertEqual(stats, {"attempted": 1, "failed": 1})


class TestCliReporting(unittest.TestCase):
    def test_shortfall_is_warned_but_not_a_partial_failure_exit(self):
        results = {"stage2": {"counts": {"decompile_attempted": 5, "decompile_failed": 2,
                                         "failed": 0}}}
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            cli._warn_decompile_shortfalls(results)
        self.assertIn("2 of 5 decompile(s)", err.getvalue())
        self.assertEqual(cli._summarize_partial_failures(results), [])

    def test_no_warning_when_all_decompiles_succeeded(self):
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            cli._warn_decompile_shortfalls({"stage2": {"counts": {"decompile_attempted": 3,
                                                                  "decompile_failed": 0}}})
        self.assertEqual(err.getvalue(), "")


if __name__ == "__main__":
    unittest.main()
