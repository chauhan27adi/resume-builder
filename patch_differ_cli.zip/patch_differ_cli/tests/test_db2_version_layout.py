"""DB2 Stage 2 per-version output, brought in line with MSSQL (see _layout.py): each build's
plain disassembly and pseudo-C go to their own folders (disassembled_instructions_{vuln,fixed}
_<version>/, decompiled_c_{vuln,fixed}_<version>/, one <binary>_<sha8>/ subfolder per ELF with
a binary.json), and the assembly diffs to one disassembled_instructions_<vuln>_vs_<fixed>/
folder. Ghidra is faked; scratch files live in TemporaryDirectory()s only; workers forced to 1
so the fakes apply in-process."""
import json
import os
import tempfile
import unittest
from unittest import mock

from patch_differ_cli.db2 import stage2 as d2
from patch_differ_cli import _x86diff as _X
from patch_differ_cli.tests.test_db2_major_fixes import GLOBAL, _job, _lib, _mov, _write


def _read(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


class Db2VersionLayoutTests(unittest.TestCase):
    def setUp(self):
        self._old_workers = os.environ.get("CVE_PATCHDIFF_WORKERS")
        os.environ["CVE_PATCHDIFF_WORKERS"] = "1"       # sequential, in-process: fakes apply
        self.addCleanup(self._restore_workers)

    def _restore_workers(self):
        if self._old_workers is None:
            os.environ.pop("CVE_PATCHDIFF_WORKERS", None)
        else:
            os.environ["CVE_PATCHDIFF_WORKERS"] = self._old_workers

    def _run(self, d, decompile=False, vuln_label="v1", fixed_label="v2"):
        rel = "lib/libx.so"
        _write(os.path.join(d, "p", rel), _lib([("api", GLOBAL, _mov(1))]))
        _write(os.path.join(d, "f", rel), _lib([("api", GLOBAL, _mov(2))]))
        with mock.patch.object(_X, "fix_signature", return_value=(1, ["guard"])), \
                mock.patch.object(d2, "decompile_cached",
                                  lambda pb, fb, cache, *c: ("int prior_c;", "int fixed_c;", True)):
            res = d2.run(os.path.join(d, "p"), os.path.join(d, "f"), os.path.join(d, "w"),
                         stage0={"code_changed": [{"name": rel}]}, decompile=decompile,
                         vuln_label=vuln_label, fixed_label=fixed_label)
        return rel, res, os.path.join(d, "w", "stage2")

    def test_each_build_gets_its_own_files(self):
        with tempfile.TemporaryDirectory() as d:
            rel, res, s2 = self._run(d, decompile=True)
            self.assertEqual(res["counts"]["failed"], 0)
            folders = {}
            for build, ver, c_text in (("vuln", "v1", "int prior_c;"),
                                       ("fixed", "v2", "int fixed_c;")):
                adir = os.path.join(s2, f"disassembled_instructions_{build}_{ver}")
                (sub,) = os.listdir(adir)
                self.assertTrue(sub.startswith("lib_libx.so_"), sub)
                folders[build] = sub
                meta = json.loads(_read(os.path.join(adir, sub, "binary.json")))
                self.assertEqual((meta["version"], meta["build"], meta["name"]),
                                 (ver, build, "libx.so"))
                self.assertTrue(sub.endswith(meta["sha256"][:8]))
                listing = _read(os.path.join(adir, sub, d2._safe("api") + ".asm"))
                self.assertIn("; api", listing)
                self.assertIn("; libx.so, primary VA 0x1000", listing, "ELF VA, not RVA")
                c_file = os.path.join(s2, f"decompiled_c_{build}_{ver}", sub,
                                      d2._safe("api") + ".c")
                self.assertEqual(_read(c_file), c_text, "each side's own pseudo-C")
            # the two builds differ in bytes, so their binary subfolders never collide
            self.assertNotEqual(folders["vuln"], folders["fixed"])
            # the diff compares the two builds: one pair folder, one labelled copy
            pair = os.path.join(s2, "disassembled_instructions_v1_vs_v2")
            (diff,) = [f for f in os.listdir(pair) if f.endswith(".asm.diff")]
            self.assertTrue(diff.startswith("v1_v2_"), diff)
            self.assertFalse(os.path.exists(os.path.join(s2, "decompiled_c")))
            self.assertFalse(os.path.exists(os.path.join(s2, "disassembled_instructions")))

    def test_no_version_folders_are_empty_without_decompile(self):
        with tempfile.TemporaryDirectory() as d:
            rel, res, s2 = self._run(d, decompile=False)
            made = sorted(os.listdir(s2))
            self.assertIn("disassembled_instructions_v1_vs_v2", made)
            self.assertIn("disassembled_instructions_vuln_v1", made)
            self.assertIn("disassembled_instructions_fixed_v2", made)
            # no pseudo-C folders at all when --decompile was not given
            self.assertFalse([m for m in made if m.startswith("decompiled_c")], made)

    def test_unlabelled_run_falls_back_to_vuln_fixed_unversioned(self):
        with tempfile.TemporaryDirectory() as d:
            rel, res, s2 = self._run(d, vuln_label=None, fixed_label=None)
            made = sorted(os.listdir(s2))
            self.assertIn("disassembled_instructions_vuln_unversioned", made)
            self.assertIn("disassembled_instructions_fixed_unversioned", made)
            self.assertIn("disassembled_instructions_unversioned_vs_unversioned", made)

    def test_bindiff_intermediates_live_beside_stage2_not_inside(self):
        # bug.md DB2-T1-3: the Ghidra project + .BinExport go to <workdir>/bindiff_work/,
        # not into the stage2/ result tree.
        import patch_differ_cli._bindiff as bd
        seen = {}

        def fake_diff_pair(prior, fixed, workdir, progress=None):
            seen["workdir"] = workdir.replace("\\", "/")
            raise RuntimeError("stub: no Ghidra")      # -> per-binary fallback to name mode

        rel = "lib/libx.so"
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(bd, "diff_pair", fake_diff_pair), \
                mock.patch.object(_X, "fix_signature", return_value=(0, [])):
            _write(os.path.join(d, "p", rel), _lib([("api", GLOBAL, _mov(1))]))
            _write(os.path.join(d, "f", rel), _lib([("api", GLOBAL, _mov(2))]))
            d2.run(os.path.join(d, "p"), os.path.join(d, "f"), os.path.join(d, "w"),
                   stage0={"code_changed": [{"name": rel}]}, use_bindiff=True,
                   vuln_label="v1", fixed_label="v2")
        self.assertIn("/bindiff_work/", seen["workdir"])
        self.assertNotIn("/stage2/", seen["workdir"])

    def test_data_cards_are_emitted_in_bindiff_mode(self):
        # bug.md DB2-T1-1: with PATCHDIFF_DATA_DIFF enabled, the BinDiff branch emits a data
        # card for a matched changed function whose referenced data changed (as name mode does).
        import patch_differ_cli._bindiff as bd
        rel = "lib/libx.so"

        def fake_diff_pair(prior, fixed, workdir, progress=None):
            return {0x1000: bd.FuncMatch(addr1=0x1000, addr2=0x1000, similarity=0.9,
                                         confidence=0.9, name1="api", name2="api")}

        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(bd, "diff_pair", fake_diff_pair), \
                mock.patch.object(bd, "map_matches",
                                  lambda matches, P, F, dp, df: ({0x1000: "api"}, {0x1000: "api"})), \
                mock.patch.object(d2, "_DATA_DIFF", True), \
                mock.patch.object(d2, "_data_changes",
                                  lambda *a, **k: [(0x2000, 0x2000, b"OLD", b"NEW")]), \
                mock.patch.object(_X, "fix_signature", return_value=(0, [])):
            _write(os.path.join(d, "p", rel), _lib([("api", GLOBAL, _mov(1))]))
            _write(os.path.join(d, "f", rel), _lib([("api", GLOBAL, _mov(2))]))
            d2.run(os.path.join(d, "p"), os.path.join(d, "f"), os.path.join(d, "w"),
                   stage0={"code_changed": [{"name": rel}]}, use_bindiff=True,
                   vuln_label="v1", fixed_label="v2")
            s2 = os.path.join(d, "w", "stage2")
            data_cards = [f for f in os.listdir(s2) if f.startswith("dt__") and f.endswith(".diff")]
        self.assertTrue(data_cards, "a data card was written in BinDiff mode")


class Db2DataCardCapTests(unittest.TestCase):
    """bug.md DB2-NT-1: lever-3 data cards must respect the per-binary _EMIT_CAP — a data card
    is emitted only alongside its (emitted) function card, not for a capped function."""

    def test_data_cards_do_not_bypass_the_emit_cap(self):
        rel = "lib/libx.so"
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(d2, "_EMIT_CAP", 1), \
                mock.patch.object(d2, "_DATA_DIFF", True), \
                mock.patch.object(d2, "_data_changes",
                                  lambda *a, **k: [(0x2000, 0x2000, b"OLD", b"NEW")]), \
                mock.patch.object(_X, "fix_signature", return_value=(0, [])):
            # 3 changed, unattributed, non-fix-shaped functions, each with a data change
            _write(os.path.join(d, "p", rel), _lib([(f"f{i}", GLOBAL, _mov(i)) for i in range(3)]))
            _write(os.path.join(d, "f", rel), _lib([(f"f{i}", GLOBAL, _mov(i + 100)) for i in range(3)]))
            r = d2._process_file(_job(d, rel))
        fn = [c for c in r["readable"] if c["kind"] == "function"]
        dt = [c for c in r["readable"] if c["kind"] == "data"]
        self.assertEqual(len(fn), 1, "function cards capped at _EMIT_CAP")
        self.assertEqual(len(dt), 1, "data cards bounded by the emitted function cards, not all 3")
        # every data card corresponds to an emitted function card (same object name stem)
        fn_objs = {c["object"] for c in fn}
        for c in dt:
            self.assertIn(c["object"].split("  [data]")[0], fn_objs)


if __name__ == "__main__":
    unittest.main()
