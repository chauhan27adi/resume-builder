"""Regression tests for bugs.md #15: Oracle Stage 1 cached decompiled Java under a directory
keyed only by the jar's relative path and reused it whenever it was non-empty, so a rerun in
the same work dir after the jar changed silently diffed the OLD build's source. The cache is
now keyed by jar content hash + decompiler identity; a failed decompile clears the stale
cache instead of falling back to it. Drives the REAL oracle.stage1.run() with only the
CFR/javap subprocess mocked."""
import os
import tempfile
import unittest
import zipfile
from unittest import mock

import patch_differ_cli.oracle.stage1 as s1
from patch_differ_cli.oracle import java_decompile as jd

REL = "javavm/lib/aurora.zip"
STAGE0 = {"content_changed": [{"name": REL, "kind": "jar", "route": "stage1",
                               "change": "code"}]}


def _jar(path, payload):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with zipfile.ZipFile(path, "w") as zf:
        zf.writestr("oracle/aurora/Foo.class", payload)


class _Harness(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory(prefix="pdff_decomp_")
        self.d = self._td.name
        self.p, self.f = os.path.join(self.d, "p"), os.path.join(self.d, "f")
        self.calls = 0
        self.fail = False

    def tearDown(self):
        self._td.cleanup()

    def _decompile(self, jar_path, out_dir, progress=None):
        self.calls += 1
        if self.fail:
            raise jd.DecompileFailed("CFR exited 17")
        with zipfile.ZipFile(jar_path) as zf:
            body = zf.read("oracle/aurora/Foo.class").decode()
        dst = os.path.join(out_dir, "oracle", "aurora", "Foo.java")
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        with open(dst, "w") as fh:
            fh.write(f"class Foo {{ /* {body} */ }}\n")
        return 1

    def run_stage1(self, prior_payload, fixed_payload):
        _jar(os.path.join(self.p, REL), prior_payload)
        _jar(os.path.join(self.f, REL), fixed_payload)
        with mock.patch.object(jd, "decompile_jar", self._decompile):
            r = s1.run(self.p, self.f, self.d, stage0=STAGE0)
        text = []
        for c in r["readable_files"]:
            pair = os.path.join(self.d, "stage1", c["pair"]) if c.get("pair") else None
            if pair and os.path.isfile(pair):
                with open(pair, encoding="utf-8") as fh:
                    text.append(fh.read())
        return r, "\n".join(text)


class TestDecompileCacheIsContentKeyed(_Harness):
    def test_changed_jars_are_redecompiled_on_rerun(self):
        _r, t1 = self.run_stage1("v1A", "v1B")
        self.assertIn("v1B", t1)
        _r, t2 = self.run_stage1("v2A", "v2B")
        self.assertEqual(self.calls, 4, "each side must be decompiled again after it changed")
        self.assertIn("v2B", t2)
        self.assertNotIn("v1B", t2)

    def test_unchanged_jars_reuse_the_cache(self):
        self.run_stage1("v1A", "v1B")
        self.run_stage1("v1A", "v1B")
        self.assertEqual(self.calls, 2)

    def test_decompiler_change_invalidates_cache(self):
        self.run_stage1("v1A", "v1B")
        with mock.patch.object(jd, "identity", lambda: {"tool": "javap"}):
            self.run_stage1("v1A", "v1B")
        self.assertEqual(self.calls, 4)

    def test_failed_decompile_does_not_fall_back_to_stale_output(self):
        self.run_stage1("v1A", "v1B")
        self.fail = True
        r, t2 = self.run_stage1("v2A", "v2B")
        self.assertNotIn("v1", t2, "stale v1 source must not be diffed for the v2 jars")
        self.assertEqual(r["readable_files"], [])
        self.assertEqual(r["counts"]["errors"], 1)
        # whatever v1 output is still on disk can never be reused for the v2 jar
        self.fail = False
        _r, t3 = self.run_stage1("v2A", "v2B")
        self.assertIn("v2B", t3)
        self.assertNotIn("v1", t3)



class TestDecompileFailureIsReported(_Harness):
    """bugs.md #10: a failed decompile used to be silent — Stage 1 said available, 0 cards,
    0 errors for a changed jar."""

    def test_failure_is_an_error_not_silence(self):
        self.fail = True
        r, _t = self.run_stage1("v1A", "v1B")
        self.assertEqual(r["counts"]["errors"], 1)
        self.assertIn("CFR exited 17", r["errors"][0]["error"])
        self.assertEqual(r["readable_files"], [])

    def test_one_side_failing_skips_the_jar_instead_of_inventing_changes(self):
        real = self._decompile

        def prior_fails(jar_path, out_dir, progress=None):
            if os.sep + "p" + os.sep in jar_path:
                raise jd.DecompileFailed("prior side failed")
            return real(jar_path, out_dir)
        _jar(os.path.join(self.p, REL), "v1A")
        _jar(os.path.join(self.f, REL), "v1B")
        with mock.patch.object(jd, "decompile_jar", prior_fails):
            r = s1.run(self.p, self.f, self.d, stage0=STAGE0)
        self.assertEqual(r["readable_files"], [], "no fake 'added' classes")
        self.assertEqual(r["counts"]["errors"], 1)

    def test_zero_output_without_exception_is_not_cached(self):
        with mock.patch.object(jd, "decompile_jar", lambda j, o, progress=None: 0):
            _jar(os.path.join(self.p, REL), "v1A")
            _jar(os.path.join(self.f, REL), "v1B")
            r = s1.run(self.p, self.f, self.d, stage0=STAGE0)
        self.assertEqual(r["counts"]["errors"], 1)
        cache = os.path.join(self.d, "stage1", "decomp", "fixed", s1._safe(REL))
        self.assertFalse(os.path.exists(cache + ".source.json"))


class TestPartialCfrOutputIsNeverCached(_Harness):
    """The gap left by the #15 cache fix: CFR writing SOME .java files and then failing
    used to be cached as a complete decompile. With #10, decompile_jar() raises on any
    non-zero exit regardless of what it wrote, so the partial output is neither cached nor
    diffed. Uses the REAL decompile_jar() with only the CFR process mocked."""

    def test_partial_output_then_nonzero_exit(self):
        import subprocess

        def cfr(cmd, **kw):
            out = cmd[cmd.index("--outputdir") + 1]
            dst = os.path.join(out, "oracle", "aurora", "Half.java")
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            with open(dst, "w") as fh:
                fh.write("class Half {}")
            return subprocess.CompletedProcess(cmd, 17, b"", b"OutOfMemoryError")
        _jar(os.path.join(self.p, REL), "v1A")
        _jar(os.path.join(self.f, REL), "v1B")
        with mock.patch.object(jd, "_cfr_jar", lambda: "cfr.jar"),                 mock.patch.object(jd, "_java", lambda: "java"),                 mock.patch.object(jd.subprocess, "run", cfr):
            r = s1.run(self.p, self.f, self.d, stage0=STAGE0)
        self.assertEqual(r["readable_files"], [], "partial output must not be diffed")
        self.assertEqual(r["counts"]["errors"], 1)
        self.assertIn("exited 17", r["errors"][0]["error"])
        for side in ("prior", "fixed"):
            cache = os.path.join(self.d, "stage1", "decomp", side, s1._safe(REL))
            self.assertFalse(os.path.exists(cache + ".source.json"), f"{side} cached")
            self.assertFalse(os.path.exists(cache), f"{side} partial output left in cache")


class TestDecompileJarReportsToolFailure(unittest.TestCase):
    """The real decompile_jar() against mocked subprocesses."""

    def _jarfile(self, d):
        p = os.path.join(d, "x.jar")
        _jar(p, "c")
        return p

    def test_cfr_nonzero_exit_raises(self):
        import subprocess
        with tempfile.TemporaryDirectory(prefix="pdff_cfr_") as d:
            jar = self._jarfile(d)
            with mock.patch.object(jd, "_cfr_jar", lambda: "cfr.jar"), \
                    mock.patch.object(jd.subprocess, "run",
                                      lambda *a, **k: subprocess.CompletedProcess(a, 17, b"", b"boom")):
                with self.assertRaises(jd.DecompileFailed) as cm:
                    jd.decompile_jar(jar, os.path.join(d, "out"))
            self.assertIn("exited 17", str(cm.exception))

    def test_cfr_success_with_no_output_raises(self):
        import subprocess
        with tempfile.TemporaryDirectory(prefix="pdff_cfr2_") as d:
            jar = self._jarfile(d)
            with mock.patch.object(jd, "_cfr_jar", lambda: "cfr.jar"), \
                    mock.patch.object(jd.subprocess, "run",
                                      lambda *a, **k: subprocess.CompletedProcess(a, 0, b"", b"")):
                with self.assertRaises(jd.DecompileFailed):
                    jd.decompile_jar(jar, os.path.join(d, "out"))

    def test_javap_failure_raises_and_writes_no_empty_listing(self):
        import subprocess
        with tempfile.TemporaryDirectory(prefix="pdff_javap_") as d:
            jar = self._jarfile(d)
            out = os.path.join(d, "out")
            with mock.patch.object(jd, "_cfr_jar", lambda: None), \
                    mock.patch.object(jd.subprocess, "run",
                                      lambda *a, **k: subprocess.CompletedProcess(a, 1, b"", b"")):
                with self.assertRaises(jd.DecompileFailed):
                    jd.decompile_jar(jar, out)
            javas = [f for _dp, _dn, fs in os.walk(out) for f in fs if f.endswith(".java")]
            self.assertEqual(javas, [])

    def test_timeout_raises(self):
        import subprocess
        def boom(*a, **k):
            raise subprocess.TimeoutExpired("java", 1)
        with tempfile.TemporaryDirectory(prefix="pdff_cfr3_") as d:
            jar = self._jarfile(d)
            with mock.patch.object(jd, "_cfr_jar", lambda: "cfr.jar"), \
                    mock.patch.object(jd.subprocess, "run", boom):
                with self.assertRaises(jd.DecompileFailed):
                    jd.decompile_jar(jar, os.path.join(d, "out"))


if __name__ == "__main__":
    unittest.main()
