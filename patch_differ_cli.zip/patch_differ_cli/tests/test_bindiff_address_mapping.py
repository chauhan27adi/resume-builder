"""Regression tests for bugs.md #60, #61, #62 — Track 1 mapping of BinDiff matches back to
the backends' functions:

  #60  DB2 added Ghidra's PIE base (0x100000) to every ELF, but an ET_EXEC keeps its own
       absolute addresses — every non-PIE executable mapped to nothing;
  #61  Oracle assumed 0x10000000 for ET_REL objects; Ghidra uses 0x100000;
  #62  BinDiff pairs of UNNAMED functions were dropped, so stripped / unsymbolized binaries
       reported nothing under --use-bindiff.

The base values were live-verified against Ghidra 11.0.3 + BinExport + BinDiff 8 (see
bugs.md); here BinDiff is mocked. Scratch files live in TemporaryDirectory()s only."""
import os
import struct
import tempfile
import unittest
from unittest import mock

import patch_differ_cli._bindiff as bd
import patch_differ_cli.db2._elf as elfmod
import patch_differ_cli.db2.stage2 as d2
import patch_differ_cli.oracle.stage2 as o2
from patch_differ_cli.tests.test_fallback_and_symbol_reporting import _mssql_run
from patch_differ_cli.tests.test_silent_loss_fixes import _GLOBAL_FUNC, _elf, _write


def M(a1, a2, sim=0.9, n1=None, n2=None):
    return bd.FuncMatch(a1, a2, sim, 0.9, n1, n2)


def _chk(imm):
    return (bytes.fromhex("81ff") + imm.to_bytes(4, "little") + bytes.fromhex("7303")
            + bytes.fromhex("31c0c3") + bytes.fromhex("b801000000c3"))


class MapMatchesTests(unittest.TestCase):
    P = {"chk_len": (0x401000, b""), "helper": (0x401020, b""), "sub_401040": (0x401040, b"")}
    F = dict(P)

    def test_measured_offset_wins_over_a_wrong_default(self):
        # ET_EXEC: Ghidra keeps absolute addresses (offset 0); the default here is wrong
        m = {0x401000: M(0x401000, 0x401000, n1="chk_len", n2="chk_len"),
             0x401020: M(0x401020, 0x401020, n1="helper", n2="helper")}
        a_p, a_f = bd.map_matches(m, self.P, self.F, 0x100000, 0x100000)
        self.assertEqual(a_p[0x401000], "chk_len")
        self.assertEqual(a_f[0x401040], "sub_401040")

    def test_default_is_used_when_no_name_lines_up(self):
        m = {0x501000: M(0x501000, 0x501000, n1="FUN_00501000", n2="FUN_00501000")}
        a_p, _a_f = bd.map_matches(m, self.P, self.F, 0x100000, 0x100000)
        self.assertEqual(a_p[0x501000], "chk_len")

    def test_a_minority_of_mismatched_names_is_outvoted(self):
        m = {0x401000: M(0x401000, 0x401000, n1="chk_len", n2="chk_len"),
             0x401020: M(0x401020, 0x401020, n1="helper", n2="helper"),
             0x999999: M(0x999999, 0x999999, n1="helper", n2="helper")}   # a stray thunk
        a_p, _ = bd.map_matches(m, self.P, self.F, 0x100000, 0x100000)
        self.assertEqual(a_p.get(0x401000), "chk_len")

    def test_nothing_resolving_raises_instead_of_phantom_cards(self):
        m = {0x10000000: M(0x10000000, 0x10000000)}
        with self.assertRaises(RuntimeError) as ctx:
            bd.map_matches(m, self.P, self.F, 0x100000, 0x100000)
        self.assertIn("resolved to a known function", str(ctx.exception))
        with self.assertRaises(RuntimeError):
            bd.map_matches({}, self.P, self.F, 0, 0)          # no matches at all

    def test_matches_without_name_attributes_still_map(self):
        class Bare:                                           # older match objects
            def __init__(self, addr2):
                self.addr2, self.similarity, self.confidence = addr2, 0.5, 0.5
        a_p, _ = bd.map_matches({0x401000: Bare(0x401000)}, self.P, self.F, 0, 0)
        self.assertEqual(a_p[0x401000], "chk_len")


class ElfDefaultOffsetTests(unittest.TestCase):
    def _typed(self, d, etype):
        p = _write(os.path.join(d, f"t{etype}"), _elf([("f", _GLOBAL_FUNC, 0, b"\xc3")]))
        data = bytearray(open(p, "rb").read())
        struct.pack_into("<H", data, 16, etype)
        open(p, "wb").write(bytes(data))
        return p

    def test_defaults_follow_the_elf_type(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(d2._ghidra_elf_default_offset(self._typed(d, elfmod.ET_EXEC)), 0)
            self.assertEqual(d2._ghidra_elf_default_offset(self._typed(d, elfmod.ET_DYN)),
                             d2._GHIDRA_ELF_PIE_BASE)
            self.assertEqual(elfmod.elf_type(self._typed(d, elfmod.ET_REL)), elfmod.ET_REL)
            self.assertIsNone(elfmod.elf_type(_write(os.path.join(d, "x.txt"), b"not elf")))

    def test_oracle_relocatable_default_is_ghidras_base(self):
        self.assertEqual(o2._GHIDRA_ELF_REL_BASE, 0x100000)


class EndToEndMappingTests(unittest.TestCase):
    def test_db2_exec_reports_the_real_change_not_phantom_cards(self):          # #60
        prior = [("chk_len", _GLOBAL_FUNC, 0x0, _chk(0x100)), ("helper", _GLOBAL_FUNC, 0x20, b"\x90\xc3")]
        fixed = [("chk_len", _GLOBAL_FUNC, 0x0, _chk(0xFF)), ("helper", _GLOBAL_FUNC, 0x20, b"\x90\xc3")]
        with tempfile.TemporaryDirectory() as d:
            rel = "bin/db2sysc"
            for side, syms in (("p", prior), ("f", fixed)):
                data = bytearray(_elf(syms))
                struct.pack_into("<H", data, 16, elfmod.ET_EXEC)     # non-PIE executable
                _write(os.path.join(d, side, rel), bytes(data))
            os.makedirs(os.path.join(d, "out"))
            # Ghidra keeps ET_EXEC symbols at their own addresses: BinDiff VA == st_value
            m = {0x0: M(0x0, 0x0, 1.0, "chk_len", "chk_len"),
                 0x20: M(0x20, 0x20, 1.0, "helper", "helper")}
            job = {"prior_dir": os.path.join(d, "p"), "fixed_dir": os.path.join(d, "f"),
                   "rel": rel, "out": os.path.join(d, "out"), "attrib": [],
                   "use_bindiff": True, "decompile": False,
                   "disassembled_dir": os.path.join(d, "out"), "vuln_label": "v",
                   "fixed_label": "f", "run_ts": "t"}
            with mock.patch.object(bd, "diff_pair", lambda *a, **k: m):
                r = d2._process_file(job)
        self.assertEqual([(c["object"], c["change"], c["match_algorithm"]) for c in r["readable"]],
                         [("bin/db2sysc :: chk_len", "const", "bindiff")])
        self.assertIsNone(r["bindiff_fallback"])

    def test_oracle_object_reports_the_real_change_not_phantom_cards(self):     # #61
        P = {"chk_len": (0x0, _chk(0x100)), "helper": (0x20, b"\x90\xc3")}
        F = {"chk_len": (0x0, _chk(0xFF)), "helper": (0x20, b"\x90\xc3")}
        base = 0x100000                                    # where Ghidra put it (live)
        m = {base: M(base, base, 1.0, "chk_len", "chk_len"),
             base + 0x20: M(base + 0x20, base + 0x20, 1.0, "helper", "helper")}
        with tempfile.TemporaryDirectory() as out, \
                mock.patch.object(o2, "_func_map", lambda path: dict(P if path == "PRIOR" else F)), \
                mock.patch.object(o2, "_func_sections", lambda path: {".text"}), \
                mock.patch.object(bd, "diff_pair", lambda *a, **k: m):
            readable, fb = [], []
            o2._diff_o("kzx.o", "kzx.o", "PRIOR", "FIXED", out, readable, attrib=[],
                       use_bindiff=True, disassembled_dir=out, run_ts="t", bindiff_fallbacks=fb)
        self.assertEqual([(c["object"], c["match_algorithm"]) for c in readable],
                         [("kzx.o :: chk_len", "bindiff")])
        self.assertEqual(fb, [])

    def test_unmappable_result_falls_back_and_is_recorded(self):
        P = {"chk_len": (0x0, _chk(0x100))}
        F = {"chk_len": (0x0, _chk(0xFF))}
        m = {0x10000000: M(0x10000000, 0x10000000)}        # the old, wrong base
        with tempfile.TemporaryDirectory() as out, \
                mock.patch.object(o2, "_func_map", lambda path: dict(P if path == "PRIOR" else F)), \
                mock.patch.object(o2, "_func_sections", lambda path: {".text"}), \
                mock.patch.object(bd, "diff_pair", lambda *a, **k: m):
            readable, fb = [], []
            o2._diff_o("kzx.o", "kzx.o", "PRIOR", "FIXED", out, readable, attrib=[],
                       use_bindiff=True, disassembled_dir=out, run_ts="t", bindiff_fallbacks=fb)
        self.assertEqual([c["change"] for c in readable], ["code"], "name matching, no phantoms")
        self.assertEqual(len(fb), 1)


class UnnamedPairTests(unittest.TestCase):                                   # #62
    MATCHES = {rva: bd.FuncMatch(rva, rva, sim, 0.99)
               for rva, sim in ((0x1000, 1.0), (0x1010, 0.95), (0x1030, 1.0))}

    def _cards(self, symbolized):
        r = _mssql_run(symbolized=symbolized, use_bindiff=True,
                       diff_pair=lambda *a, **k: self.MATCHES)
        return [(c["object"], c["change"], c["match_algorithm"]) for c in r["readable"]], r

    def test_unsymbolized_mssql_dll_reports_the_change_via_bindiff(self):
        cards, r = self._cards(())
        self.assertEqual(cards, [("sqlmin.dll :: sub_1010", "const", "bindiff")])
        self.assertTrue(r["ok"])

    def test_one_side_pdb_path_reports_the_change_via_bindiff(self):
        cards, r = self._cards(("prior",))
        self.assertEqual(cards, [("sqlmin.dll :: sub_1010", "const", "bindiff")])
        self.assertFalse(r["ok"], "still flagged as partially analyzed (#58)")

    def test_symbolized_dll_is_unchanged(self):
        cards, _r = self._cards(("prior", "fixed"))
        self.assertEqual(cards, [("sqlmin.dll :: CheckLength", "const", "bindiff")])

    def test_db2_unnamed_pair_reports_the_change(self):
        prior = [(None, 0x0, _chk(0x100)), (None, 0x20, b"\x90\xc3")]
        fixed = [(None, 0x0, _chk(0xFF)), (None, 0x20, b"\x90\xc3")]
        from patch_differ_cli.tests.test_unnamed_elf_function_diff import build_elf
        # build_elf() writes ET_EXEC images: Ghidra keeps their addresses (offset 0), and
        # no Ghidra name (FUN_...) lines up with an unnamed symbol -> the per-type default
        m = {0x0: M(0x0, 0x0, 0.95, "FUN_00000000", "FUN_00000000")}
        with tempfile.TemporaryDirectory() as d:
            rel = "lib/libanon.so"
            _write(os.path.join(d, "p", rel), build_elf([(n, v, len(c), c) for n, v, c in prior]))
            _write(os.path.join(d, "f", rel), build_elf([(n, v, len(c), c) for n, v, c in fixed]))
            os.makedirs(os.path.join(d, "out"))
            job = {"prior_dir": os.path.join(d, "p"), "fixed_dir": os.path.join(d, "f"),
                   "rel": rel, "out": os.path.join(d, "out"), "attrib": [],
                   "use_bindiff": True, "decompile": False,
                   "disassembled_dir": os.path.join(d, "out"), "vuln_label": "v",
                   "fixed_label": "f", "run_ts": "t"}
            with mock.patch.object(bd, "diff_pair", lambda *a, **k: m):
                r = d2._process_file(job)
        self.assertEqual([(c["object"], c["match_algorithm"]) for c in r["readable"]],
                         [("lib/libanon.so :: sub_0", "bindiff")])


if __name__ == "__main__":
    unittest.main()
