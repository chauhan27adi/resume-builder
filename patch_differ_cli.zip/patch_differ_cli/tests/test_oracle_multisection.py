"""Regression tests for bugs.md #5 (Track-1): Oracle's BinDiff address map was
st_value + one fixed base, but ET_REL st_value is relative to each function's OWN section —
with functions in .text and .text.unlikely, two functions collided on one address (one
silently dropped) and later sections didn't line up with Ghidra's placement, so BinDiff
matches attached to the wrong functions. Such objects now fall back to name matching.

Also covers the related fallback found during the bugs.md review: when pyelftools can't
parse an object, _func_map fell back to DB2's single-.text parser, which ignores st_shndx and
read a .text.unlikely function's bytes out of .text for ET_REL objects."""
import contextlib
import io
import os
import struct
import tempfile
import unittest
from unittest import mock

import patch_differ_cli.oracle.stage2 as o2
from patch_differ_cli import _bindiff as bd_mod
from patch_differ_cli.tests.test_oracle_percall_emit_cap import _build_elf

HOT, COLD = b"\x90\x90\xc3", b"\xcc\xcc\xc3"


def _two_section_rel(hot, cold):
    """ET_REL with hot_fn @ .text+0 and cold_fn @ .text.unlikely+0 (both st_value 0)."""
    shstr = b"\0.text\0.text.unlikely\0.symtab\0.strtab\0.shstrtab\0"
    n_text, n_unl, n_sym, n_str, n_shs = 1, 7, 22, 30, 38
    strtab = b"\0hot_fn\0cold_fn\0"
    sym = lambda name, shndx, size: struct.pack("<IBBHQQ", name, 0x12, 0, shndx, 0, size)
    symtab = bytes(24) + sym(1, 1, len(hot)) + sym(8, 2, len(cold))
    body = hot + cold + symtab + strtab + shstr
    off_hot = 64
    off_cold = off_hot + len(hot)
    off_sym = off_cold + len(cold)
    off_str = off_sym + len(symtab)
    off_shs = off_str + len(strtab)
    shoff = off_shs + len(shstr)
    sh = lambda n, t, fl, o, s, link=0, info=0, ent=0: struct.pack(
        "<IIQQQQIIQQ", n, t, fl, 0, o, s, link, info, 1, ent)
    secs = [bytes(64), sh(n_text, 1, 6, off_hot, len(hot)), sh(n_unl, 1, 6, off_cold, len(cold)),
            sh(n_sym, 2, 0, off_sym, len(symtab), link=4, info=1, ent=24),
            sh(n_str, 3, 0, off_str, len(strtab)), sh(n_shs, 3, 0, off_shs, len(shstr))]
    e = bytearray(64)
    e[0:4] = b"\x7fELF"
    e[4], e[5], e[6] = 2, 1, 1
    struct.pack_into("<HHI", e, 0x10, 1, 0x3E, 1)
    struct.pack_into("<Q", e, 0x28, shoff)
    struct.pack_into("<HHHHHH", e, 0x34, 64, 0, 0, 64, len(secs), 5)
    return bytes(e) + body + b"".join(secs)


class _FakeMatch:
    def __init__(self, addr2):
        self.addr2, self.similarity, self.confidence = addr2, 0.5, 0.9


class TestFuncMapSectionAware(unittest.TestCase):
    def test_primary_parser_reads_each_section(self):
        with tempfile.TemporaryDirectory(prefix="pdff_ms_") as d:
            p = os.path.join(d, "kkz.o")
            open(p, "wb").write(_two_section_rel(HOT, COLD))
            m = o2._func_map(p)
            self.assertEqual(m["hot_fn"][1], HOT)
            self.assertEqual(m["cold_fn"][1], COLD)
            self.assertEqual(len(o2._func_sections(p)), 2)

    def test_parse_failure_on_et_rel_does_not_return_wrong_bytes(self):
        with tempfile.TemporaryDirectory(prefix="pdff_ms2_") as d:
            p = os.path.join(d, "kkz.o")
            open(p, "wb").write(_two_section_rel(HOT, COLD))
            with mock.patch("elftools.elf.elffile.ELFFile", side_effect=ValueError("bad")):
                m = o2._func_map(p)
            self.assertNotIn(("cold_fn", HOT), [(k, v[1]) for k, v in m.items()])
            self.assertEqual(m, {})

    def test_parse_failure_on_single_text_et_rel_still_uses_flat_parser(self):
        # one .text section: section-relative offsets ARE .text offsets, so it's safe
        with tempfile.TemporaryDirectory(prefix="pdff_ms5_") as d:
            p = os.path.join(d, "one.o")
            open(p, "wb").write(_build_elf([("fn", 0, 2, b"\x90\xc3")]))
            with mock.patch("elftools.elf.elffile.ELFFile", side_effect=ValueError("bad")):
                m = o2._func_map(p)
            self.assertEqual(m["fn"][1], b"\x90\xc3")

    def test_parse_failure_on_linked_image_still_uses_flat_parser(self):
        with tempfile.TemporaryDirectory(prefix="pdff_ms3_") as d:
            p = os.path.join(d, "lib.so")
            blob = bytearray(_build_elf([("fn", 0x1000, 2, b"\x90\xc3")]))
            struct.pack_into("<H", blob, 0x10, 3)       # ET_DYN (linked)
            open(p, "wb").write(bytes(blob))
            with mock.patch("elftools.elf.elffile.ELFFile", side_effect=ValueError("bad")):
                m = o2._func_map(p)
            self.assertEqual(m["fn"][1], b"\x90\xc3")


class TestBinDiffFallbackForMultiSection(unittest.TestCase):
    def _run(self, prior, fixed):
        calls = []

        def diff_pair(pa, fa, workdir, progress=None):
            calls.append(pa)
            base = o2._GHIDRA_ELF_REL_BASE
            return {base: _FakeMatch(base)}
        with tempfile.TemporaryDirectory(prefix="pdff_ms4_") as d:
            pa, fa = os.path.join(d, "p.o"), os.path.join(d, "f.o")
            open(pa, "wb").write(prior)
            open(fa, "wb").write(fixed)
            readable, err = [], io.StringIO()
            with mock.patch.object(bd_mod, "diff_pair", diff_pair), contextlib.redirect_stderr(err):
                o2._diff_o("kkz.o", "kkz.o", pa, fa, d, readable, attrib=[], use_bindiff=True)
        return readable, calls, err.getvalue()

    def test_multi_section_object_uses_name_matching(self):
        readable, calls, err = self._run(_two_section_rel(HOT, COLD),
                                         _two_section_rel(b"\x90\x90\x90\xc3", b"\xcc\x90\xc3"))
        self.assertEqual(calls, [], "BinDiff must not be trusted for this object")
        self.assertIn("multiple .text* sections", err)
        got = {r["object"]: r["match_algorithm"] for r in readable}
        self.assertEqual(got, {"kkz.o :: hot_fn": "name", "kkz.o :: cold_fn": "name"})

    def test_single_section_object_still_uses_bindiff(self):
        p = _build_elf([("fn", 0, 2, b"\x90\xc3")])            # this helper emits ET_REL
        f = _build_elf([("fn", 0, 3, b"\x90\x90\xc3")])
        _readable, calls, _err = self._run(p, f)
        self.assertEqual(len(calls), 1)


if __name__ == "__main__":
    unittest.main()
