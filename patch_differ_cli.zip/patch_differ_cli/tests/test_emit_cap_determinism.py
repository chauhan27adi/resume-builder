"""Regression tests for IMP-NT-1: in name-mode Stage 2, `common` (the set of functions
present in both the prior and fixed build) is a `dict_keys & dict_keys` intersection, which
iterates in a hash-seed-dependent order. When many functions tie exactly on every sort key
(attribution, fix-score, similarity) -- plausible for a release with a large churn of
boilerplate-shaped changes -- the pre-fix `hits.sort()`/`name_hits.sort()` calls in
mssql/db2/oracle's stage2.py had no final tie-breaker, so two perfectly-tied candidates could
swap places between two runs of the identical input. Combined with the `_EMIT_CAP`
truncation, this made it non-deterministic WHICH ~500/600 of a large tied group actually got
reported -- the exact same patch pair could emit a different report on every run.

The fix: each sort key gained a final tie-breaker on the function's own name (`h[0]`), which
is already unique within one `common` set, making the sort (and therefore the emitted/
truncated set) deterministic regardless of hash seed.

Each test here constructs real production inputs with hundreds of exactly-tied functions
(same byte-level change shape everywhere, so sim/fix-score/attribution tie identically) and
re-invokes the REAL end-to-end per-file diff entry point in a FRESH subprocess under three
different PYTHONHASHSEED values, then asserts the emitted card list is byte-for-byte
identical across all three. This is the same technique used to demonstrate the original
defect live; run against the reverted (pre-fix) sort key, this reproduction fails."""
import os
import struct
import subprocess
import sys
import tempfile
import textwrap
import unittest

_N = 700   # exceeds every backend's _EMIT_CAP (500/500/600), so truncation always bites
_SEEDS = ["0", "12345", "999999"]


def _sym(name_off, value, size):
    return struct.pack("<IBBHQQ", name_off, 0x02, 0, 1, value, size)


def _shdr(name_off, sh_type, addr, offset, size, link=0):
    return struct.pack("<IIQQQQIIQQ", name_off, sh_type, 0, addr, offset, size, link, 0, 1, 0)


def _build_elf(symbols, et_rel=False):
    base = symbols[0][1]
    text_data = b""
    for _name, value, size, code in symbols:
        pad = value - (base + len(text_data))
        assert pad >= 0
        text_data += b"\x00" * pad + code
    names = [n for n, *_ in symbols if n]
    strtab = b"\x00" + b"\x00".join(n.encode() for n in names) + (b"\x00" if names else b"")
    name_offsets, pos = {}, 1
    for n in names:
        name_offsets[n] = pos
        pos += len(n) + 1
    symtab_data = _sym(0, 0, 0)
    for name, value, size, _code in symbols:
        symtab_data += _sym(name_offsets[name] if name else 0, value, size)
    shstrtab = b"\x00.text\x00.symtab\x00.strtab\x00.shstrtab\x00"
    HDR = 64
    text_off = HDR
    symtab_off = text_off + len(text_data)
    strtab_off = symtab_off + len(symtab_data)
    shstrtab_off = strtab_off + len(strtab)
    shdr_off = shstrtab_off + len(shstrtab)
    sections = [
        _shdr(0, 0, 0, 0, 0),
        _shdr(1, 1, base, text_off, len(text_data)),
        _shdr(7, 2, 0, symtab_off, len(symtab_data), link=3),
        _shdr(15, 3, 0, strtab_off, len(strtab)),
        _shdr(23, 3, 0, shstrtab_off, len(shstrtab)),
    ]
    ehdr = bytearray(64)
    ehdr[0:4] = b"\x7fELF"
    ehdr[4], ehdr[5], ehdr[6] = 2, 1, 1
    struct.pack_into("<H", ehdr, 0x10, 1 if et_rel else 2)
    struct.pack_into("<H", ehdr, 0x12, 0x3E)
    struct.pack_into("<I", ehdr, 0x14, 1)
    struct.pack_into("<Q", ehdr, 0x28, shdr_off)
    struct.pack_into("<H", ehdr, 0x34, 64)
    struct.pack_into("<H", ehdr, 0x3A, 64)
    struct.pack_into("<H", ehdr, 0x3C, len(sections))
    struct.pack_into("<H", ehdr, 0x3E, 4)
    return bytes(ehdr) + text_data + symtab_data + strtab + shstrtab + b"".join(sections)


def _build_tied_elf_symbols(byte_before, byte_after, n=_N, stride=0x10, base=0x10000):
    prior, fixed = [], []
    for i in range(n):
        name = f"zzFunc{i:04d}"
        addr = base + i * stride
        prior.append((name, addr, len(byte_before), byte_before))
        fixed.append((name, addr, len(byte_after), byte_after))
    return prior, fixed


_ELF_CHILD = textwrap.dedent("""
    import os, sys, tempfile
    sys.path.insert(0, {repo!r})
    backend = sys.argv[1]
    prior_blob, fixed_blob, rel = sys.argv[2], sys.argv[3], sys.argv[4]
    with tempfile.TemporaryDirectory(prefix="pdff_imp_nt1_") as d:
        prior_dir = os.path.join(d, "prior"); fixed_dir = os.path.join(d, "fixed"); out = os.path.join(d, "out")
        os.makedirs(prior_dir); os.makedirs(fixed_dir); os.makedirs(out)
        with open(os.path.join(prior_dir, rel), "wb") as f:
            f.write(open(prior_blob, "rb").read())
        with open(os.path.join(fixed_dir, rel), "wb") as f:
            f.write(open(fixed_blob, "rb").read())
        if backend == "db2":
            import patch_differ_cli.db2.stage2 as d2
            job = {{"prior_dir": prior_dir, "fixed_dir": fixed_dir, "rel": rel, "out": out,
                    "attrib": [], "use_bindiff": False, "decompile": False,
                    "disassembled_dir": out, "vuln_label": "vuln", "fixed_label": "fixed",
                    "run_ts": "20260101T000000Z"}}
            result = d2._process_file(job)
            objects = sorted(r["object"] for r in result["readable"])
        else:
            import patch_differ_cli.oracle.stage2 as o2
            readable = []
            o2._diff_o(rel, rel, os.path.join(prior_dir, rel), os.path.join(fixed_dir, rel),
                       out, readable, attrib=[], disassembled_dir=out, run_ts="20260101T000000Z")
            objects = sorted(r["object"] for r in readable)
    for o in objects:
        print(o)
    """)

_MSSQL_CHILD = textwrap.dedent("""
    import os, sys, tempfile
    sys.path.insert(0, {repo!r})
    import patch_differ_cli.mssql.stage2 as ms2

    class _FakeSymbolizer:
        def __init__(self, *a, **kw): self.ok = True
        def __enter__(self): return self
        def __exit__(self, *a): return False
        def name_at(self, rva): return None

    n = {n}
    prior_funcs, fixed_funcs = {{}}, {{}}
    for i in range(n):
        name = f"zzFunc{{i:04d}}"
        rva = 0x10000 + i * 0x10
        prior_funcs[name] = (rva, [(rva, b"\\x90\\xc3")])
        fixed_funcs[name] = (rva, [(rva, b"\\x90\\x90\\xc3")])

    ms2._func_map = lambda path, symbolizer: dict(prior_funcs if "prior" in path else fixed_funcs)
    ms2.sym.fetch_pdb = lambda *a, **kw: None
    ms2.sym.Symbolizer = _FakeSymbolizer

    with tempfile.TemporaryDirectory(prefix="pdff_imp_nt1_mssql_") as d:
        prior_dir = os.path.join(d, "prior"); fixed_dir = os.path.join(d, "fixed"); out = os.path.join(d, "out")
        os.makedirs(prior_dir); os.makedirs(fixed_dir); os.makedirs(out)
        rel = "risky.dll"
        open(os.path.join(prior_dir, rel), "wb").write(b"\\x00")
        open(os.path.join(fixed_dir, rel), "wb").write(b"\\x00")
        job = {{"prior_dir": prior_dir, "fixed_dir": fixed_dir, "rel": rel, "out": out,
                "attrib": [], "online": False, "pdb_cache": os.path.join(d, "pdbcache"),
                "use_bindiff": False, "decompile": False,
                "decompile_cache": os.path.join(out, "decompile_cache"),
                "decompiled_c_dir": os.path.join(out, "decompiled_c"),
                "disassembled_dir": os.path.join(out, "disassembled_instructions"),
                "run_ts": "20260101T000000Z", "vuln_label": "vuln", "fixed_label": "fixed"}}
        os.makedirs(job["disassembled_dir"])
        result = ms2._process_dll(job)
    for o in sorted(r["object"] for r in result["readable"]):
        print(o)
    """)


def _run_child(script_src, args, seed):
    env = dict(os.environ)
    env["PYTHONHASHSEED"] = seed
    proc = subprocess.run([sys.executable, "-c", script_src] + args,
                          cwd=_REPO_ROOT, capture_output=True, text=True, env=env, timeout=120)
    assert proc.returncode == 0, f"child failed (seed={seed}):\\n{proc.stderr}"
    return proc.stdout


_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


class EmitCapDeterminismTests(unittest.TestCase):
    """Drives the REAL end-to-end per-file diff entry points of all three backends, in a
    fresh subprocess per hash seed (hash randomization is fixed at interpreter start, so it
    cannot be varied within one process)."""

    def test_mssql_name_mode_emission_is_hash_seed_independent(self):
        script = _MSSQL_CHILD.format(repo=_REPO_ROOT, n=_N)
        outputs = {seed: _run_child(script, [], seed) for seed in _SEEDS}
        first = outputs[_SEEDS[0]]
        self.assertTrue(first.strip(), "expected at least some emitted cards")
        for seed in _SEEDS[1:]:
            self.assertEqual(first, outputs[seed],
                              f"mssql emitted a different card set under PYTHONHASHSEED={seed} "
                              f"than under PYTHONHASHSEED={_SEEDS[0]}")

    def test_db2_name_mode_emission_is_hash_seed_independent(self):
        prior_syms, fixed_syms = _build_tied_elf_symbols(b"\x90\xc3", b"\x90\x90\xc3")
        with tempfile.TemporaryDirectory(prefix="pdff_imp_nt1_db2_blobs_") as d:
            prior_p = os.path.join(d, "prior.so")
            fixed_p = os.path.join(d, "fixed.so")
            with open(prior_p, "wb") as f:
                f.write(_build_elf(prior_syms))
            with open(fixed_p, "wb") as f:
                f.write(_build_elf(fixed_syms))
            script = _ELF_CHILD.format(repo=_REPO_ROOT)
            outputs = {seed: _run_child(script, ["db2", prior_p, fixed_p, "risky.so"], seed)
                       for seed in _SEEDS}
        first = outputs[_SEEDS[0]]
        self.assertTrue(first.strip(), "expected at least some emitted cards")
        for seed in _SEEDS[1:]:
            self.assertEqual(first, outputs[seed],
                              f"db2 emitted a different card set under PYTHONHASHSEED={seed} "
                              f"than under PYTHONHASHSEED={_SEEDS[0]}")

    def test_oracle_name_mode_emission_is_hash_seed_independent(self):
        prior_syms, fixed_syms = _build_tied_elf_symbols(b"\x90\xc3", b"\x90\x90\xc3")
        with tempfile.TemporaryDirectory(prefix="pdff_imp_nt1_oracle_blobs_") as d:
            prior_p = os.path.join(d, "prior.o")
            fixed_p = os.path.join(d, "fixed.o")
            with open(prior_p, "wb") as f:
                f.write(_build_elf(prior_syms, et_rel=True))
            with open(fixed_p, "wb") as f:
                f.write(_build_elf(fixed_syms, et_rel=True))
            script = _ELF_CHILD.format(repo=_REPO_ROOT)
            outputs = {seed: _run_child(script, ["oracle", prior_p, fixed_p, "risky.o"], seed)
                       for seed in _SEEDS}
        first = outputs[_SEEDS[0]]
        self.assertTrue(first.strip(), "expected at least some emitted cards")
        for seed in _SEEDS[1:]:
            self.assertEqual(first, outputs[seed],
                              f"oracle emitted a different card set under PYTHONHASHSEED={seed} "
                              f"than under PYTHONHASHSEED={_SEEDS[0]}")


if __name__ == "__main__":
    unittest.main()
