"""Regression tests for CRIT-T1-1: a BinDiff-matched function pair must never vanish
from the Stage 2 report entirely (reported as neither changed, added, nor removed).

Root cause (fixed in mssql/stage2.py, db2/stage2.py, oracle/stage2.py): the matched-set-
building loop used to mark BOTH a BinDiff match's addresses as "matched" even when only
ONE side resolved to a name in the backend's own symbol/PDB-derived function map (e.g.
the fixed-side function grew past _MAX_FUNC_BYTES after a real security fix and was
dropped from that map, even though BinDiff — working from raw disassembly, not the
capped map — still correctly CFG-matched it by address). Marking the resolved side
"matched" anyway suppressed it from the new/removed derivation too, so the function
was reported nowhere. The fix only marks an address pair "matched" when BOTH sides
resolve to a name, letting a one-sided resolution fall through to new/removed instead —
the same outcome the default name-based mode already gives for the identical input.

These tests drive the REAL per-binary worker functions (_diff_o / _process_dll /
_process_file), with only the symbol/PDB/PE layers mocked out (BinDiff itself is also
mocked, returning a synthetic match — no real Ghidra/BinDiff/BinExport involved)."""
import os
import tempfile
import unittest

from patch_differ_cli import _bindiff as bd_mod


class _FakeMatch:
    def __init__(self, addr2, similarity, confidence):
        self.addr2 = addr2
        self.similarity = similarity
        self.confidence = confidence


class TestOracleOneSidedBinDiffMatch(unittest.TestCase):
    def test_one_sided_resolution_falls_through_to_removed(self):
        import patch_differ_cli.oracle.stage2 as os2

        # 'DoRiskyThing' exists in the prior build; the fix grows it past the fixed-side
        # function map's size cap, so it's absent from F even though it still exists.
        # 'OtherFunc' is present on both sides, untouched by the patch, to keep the
        # function maps non-empty (required by _diff_o's own "if not P or not F: return
        # 0" guard) without BinDiff reporting a match for it.
        P_fake = {"DoRiskyThing": (0x1000, b"\x90\xc3"), "OtherFunc": (0x3000, b"\xc3")}
        F_fake = {"OtherFunc": (0x3000, b"\xc3")}
        orig_func_map = os2._func_map
        os2._func_map = lambda path: dict(P_fake if path == "PRIOR" else F_fake)

        base = os2._GHIDRA_ELF_REL_BASE
        prior_va = 0x1000 + base
        fixed_va = 0x2000 + base   # a VA with NO entry in addr_to_name_F

        orig_diff_pair = bd_mod.diff_pair
        bd_mod.diff_pair = lambda pa, fa, workdir, progress=None: {
            prior_va: _FakeMatch(fixed_va, 0.4, 0.9)}

        try:
            readable = []
            os2._diff_o("risky.o", "risky.o", "PRIOR", "FIXED", ".", readable,
                       attrib=[], use_bindiff=True)
        finally:
            os2._func_map = orig_func_map
            bd_mod.diff_pair = orig_diff_pair

        objects_by_change = {r["object"]: r.get("change") for r in readable}
        self.assertIn("risky.o :: DoRiskyThing", objects_by_change,
                     "DoRiskyThing vanished from the report entirely (CRIT-T1-1 regressed)")
        self.assertEqual(objects_by_change["risky.o :: DoRiskyThing"], "removed")


class TestDb2OneSidedBinDiffMatch(unittest.TestCase):
    def test_one_sided_resolution_falls_through_to_removed(self):
        import patch_differ_cli.db2.stage2 as ds2

        P_fake = {"DoRiskyThing": (0x1000, b"\x90\xc3"), "OtherFunc": (0x3000, b"\xc3")}
        F_fake = {"OtherFunc": (0x3000, b"\xc3")}
        orig_func_map = ds2._func_map
        ds2._func_map = lambda path: dict(P_fake if "prior" in path else F_fake)

        base = ds2._GHIDRA_ELF_PIE_BASE
        prior_va = 0x1000 + base
        fixed_va = 0x2000 + base

        orig_diff_pair = bd_mod.diff_pair
        bd_mod.diff_pair = lambda pa, fa, workdir, progress=None: {
            prior_va: _FakeMatch(fixed_va, 0.4, 0.9)}

        with tempfile.TemporaryDirectory(prefix="pdff_db2_bd_") as d:
            prior_dir = os.path.join(d, "prior"); fixed_dir = os.path.join(d, "fixed")
            out = os.path.join(d, "out")
            os.makedirs(prior_dir); os.makedirs(fixed_dir); os.makedirs(out)
            rel = "lib64/risky.so"
            os.makedirs(os.path.join(prior_dir, "lib64"))
            os.makedirs(os.path.join(fixed_dir, "lib64"))
            with open(os.path.join(prior_dir, rel), "wb") as f:
                f.write(b"\x00")
            with open(os.path.join(fixed_dir, rel), "wb") as f:
                f.write(b"\x00")
            job = {"prior_dir": prior_dir, "fixed_dir": fixed_dir, "rel": rel, "out": out,
                  "attrib": [], "use_bindiff": True, "decompile": False,
                  "decompile_cache": os.path.join(out, "decompile_cache"),
                  "decompiled_c_dir": os.path.join(out, "decompiled_c"),
                  "disassembled_dir": os.path.join(out, "disassembled_instructions"),
                  "run_ts": "20260101T000000Z", "vuln_label": "vuln", "fixed_label": "fixed"}
            os.makedirs(job["disassembled_dir"])
            try:
                result = ds2._process_file(job)
            finally:
                ds2._func_map = orig_func_map
                bd_mod.diff_pair = orig_diff_pair

        objects_by_change = {r["object"]: r.get("change") for r in result["readable"]}
        key = f"{rel} :: DoRiskyThing"
        self.assertIn(key, objects_by_change,
                     "DoRiskyThing vanished from the report entirely (CRIT-T1-1 regressed)")
        self.assertEqual(objects_by_change[key], "removed")


class TestMssqlOneSidedBinDiffMatch(unittest.TestCase):
    def test_one_sided_resolution_falls_through_to_removed(self):
        import patch_differ_cli.mssql.stage2 as ms2

        class _FakeSymbolizer:
            def __init__(self, *a, **kw):
                self.ok = True
            def __enter__(self):
                return self
            def __exit__(self, *a):
                return False

        class _FakePE:
            class _OptHdr:
                ImageBase = 0
            def __init__(self, *a, **kw):
                self.OPTIONAL_HEADER = self._OptHdr()
            def close(self):
                pass

        # chunks = [(addr, code_bytes), ...] — mssql's hot/cold-fragment shape.
        P_fake = {"DoRiskyThing": (0x1000, [(0x1000, b"\x90\xc3")]),
                 "OtherFunc": (0x3000, [(0x3000, b"\xc3")])}
        F_fake = {"OtherFunc": (0x3000, [(0x3000, b"\xc3")])}

        orig_func_map = ms2._func_map
        orig_fetch_pdb = ms2.sym.fetch_pdb
        orig_symbolizer = ms2.sym.Symbolizer
        orig_pe = ms2._pefile.PE
        orig_diff_pair = bd_mod.diff_pair

        ms2._func_map = lambda path, symbolizer: dict(P_fake if "prior" in path else F_fake)
        ms2.sym.fetch_pdb = lambda *a, **kw: None
        ms2.sym.Symbolizer = _FakeSymbolizer
        ms2._pefile.PE = _FakePE

        prior_va, fixed_va = 0x1000, 0x2000   # ImageBase=0, so VA == RVA here
        bd_mod.diff_pair = lambda pa, fa, workdir, progress=None: {
            prior_va: _FakeMatch(fixed_va, 0.4, 0.9)}

        try:
            with tempfile.TemporaryDirectory(prefix="pdff_mssql_bd_") as d:
                prior_dir = os.path.join(d, "prior"); fixed_dir = os.path.join(d, "fixed")
                out = os.path.join(d, "out")
                os.makedirs(prior_dir); os.makedirs(fixed_dir); os.makedirs(out)
                rel = "risky.dll"
                with open(os.path.join(prior_dir, rel), "wb") as f:
                    f.write(b"\x00")
                with open(os.path.join(fixed_dir, rel), "wb") as f:
                    f.write(b"\x00")
                job = {"prior_dir": prior_dir, "fixed_dir": fixed_dir, "rel": rel, "out": out,
                      "attrib": [], "online": False, "pdb_cache": os.path.join(d, "pdbcache"),
                      "use_bindiff": True, "decompile": False,
                      "decompile_cache": os.path.join(out, "decompile_cache"),
                      "decompiled_c_dir": os.path.join(out, "decompiled_c"),
                      "disassembled_dir": os.path.join(out, "disassembled_instructions"),
                      "run_ts": "20260101T000000Z", "vuln_label": "vuln", "fixed_label": "fixed"}
                os.makedirs(job["disassembled_dir"])
                result = ms2._process_dll(job)
        finally:
            ms2._func_map = orig_func_map
            ms2.sym.fetch_pdb = orig_fetch_pdb
            ms2.sym.Symbolizer = orig_symbolizer
            ms2._pefile.PE = orig_pe
            bd_mod.diff_pair = orig_diff_pair

        objects_by_change = {r["object"]: r.get("change") for r in result["readable"]}
        self.assertIn("risky.dll :: DoRiskyThing", objects_by_change,
                     "DoRiskyThing vanished from the report entirely (CRIT-T1-1 regressed)")
        self.assertEqual(objects_by_change["risky.dll :: DoRiskyThing"], "removed")


if __name__ == "__main__":
    unittest.main()
