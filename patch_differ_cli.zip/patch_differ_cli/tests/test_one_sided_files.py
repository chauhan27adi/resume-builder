"""Regression tests for bugs.md #3 (the parts not already covered by IMP-NT-3's MSSQL
triage fix): DB2 triage recorded only added/removed jars and scripts, so an added or removed
.so vanished without a trace; DB2 Stage 1 diffed only scripts present on both sides; Oracle
Stage 2 looked only at archive members common to both builds."""
import os
import tempfile
import unittest
from unittest import mock

import patch_differ_cli.db2.triage as dtri
import patch_differ_cli.db2.stage1 as ds1
import patch_differ_cli.oracle.stage2 as os2
from patch_differ_cli.tests.test_oracle_percall_emit_cap import _build_elf


def _w(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)


class _Trees(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory(prefix="pdff_1side_")
        self.d = self._td.name
        self.p, self.f = os.path.join(self.d, "p"), os.path.join(self.d, "f")

    def tearDown(self):
        self._td.cleanup()


class TestDb2Triage(_Trees):
    def _build(self):
        elf = _build_elf([("fn", 0x1000, 1, b"\xc3")])
        _w(os.path.join(self.p, "lib64", "libcommon.so"), elf)
        _w(os.path.join(self.f, "lib64", "libcommon.so"), elf)
        _w(os.path.join(self.f, "lib64", "libnewsec.so"), elf)
        _w(os.path.join(self.p, "lib64", "libgone.so"), elf)

    def test_full_walk_records_one_sided_binaries(self):
        self._build()
        r = dtri.run(self.p, self.f, self.d)
        self.assertEqual([(e["name"], e["kind"]) for e in r["added"]],
                         [("lib64/libnewsec.so", "native")])
        self.assertEqual([e["name"] for e in r["removed"]], ["lib64/libgone.so"])
        self.assertEqual((r["counts"]["added"], r["counts"]["removed"]), (1, 1))

    def test_manifest_path_records_one_sided_binaries(self):
        self._build()
        manifest = {"changed": [], "added": ["lib64/libnewsec.so"],
                    "removed": ["lib64/libgone.so"], "identical": 1}
        r = dtri._from_manifest(manifest, self.p, self.f, self.d)
        self.assertEqual([e["name"] for e in r["added"]], ["lib64/libnewsec.so"])
        self.assertEqual([e["name"] for e in r["removed"]], ["lib64/libgone.so"])


class TestDb2Stage1Scripts(_Trees):
    def test_added_and_removed_scripts_get_cards(self):
        _w(os.path.join(self.p, "bin", "same.sh"), b"echo hi\n")
        _w(os.path.join(self.f, "bin", "same.sh"), b"echo hi\n")
        _w(os.path.join(self.f, "bin", "new_hardening.sh"), b"umask 077\n")
        _w(os.path.join(self.p, "bin", "old_insecure.sh"), b"chmod 777 /tmp/x\n")
        r = ds1.run(self.p, self.f, self.d)
        got = {c["object"]: c["change"] for c in r["readable_files"] if c["kind"] == "script"}
        self.assertEqual(got, {"bin/new_hardening.sh": "added", "bin/old_insecure.sh": "removed"})


class TestOracleArchiveMembers(_Trees):
    def test_added_and_removed_members_are_recorded(self):
        elf = _build_elf([("fn", 0x1000, 1, b"\xc3")])
        files = {}
        for side, names in (("p", ["common.o", "gone.o"]), ("f", ["common.o", "new.o"])):
            files[side] = {}
            for n in names:
                path = os.path.join(self.d, side + "m", n)
                _w(path, elf)
                files[side][n] = path
        _w(os.path.join(self.p, "lib", "libserver.a"), b"!<arch>\n")
        _w(os.path.join(self.f, "lib", "libserver.a"), b"!<arch>\n")
        with mock.patch.object(os2._ar, "extract_o",
                               lambda path, dest: files["p" if os.sep + "p" + os.sep in path else "f"]):
            r = os2.run(self.p, self.f, self.d, stage0={"code_changed": [
                {"name": "lib/libserver.a", "kind": "archive", "size": 1}]})
        got = {b["object"].split("!")[1]: b["verdict"] for b in r["binaries"]}
        self.assertEqual(got, {"new.o": "added", "gone.o": "removed"})
        self.assertEqual(r["counts"]["failed"], 0)


if __name__ == "__main__":
    unittest.main()
