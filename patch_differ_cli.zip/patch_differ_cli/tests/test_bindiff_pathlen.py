"""Regression tests for IMP-T1-1: _bindiff.py used to hand Ghidra/BinDiff a bare,
over-length path with no warning, while this module's own file I/O was already
long-path-safe via lp(). Blindly lp()-wrapping the subprocess arguments too was
rejected as the fix: lp() unconditionally adds Windows' `\\?\\` prefix to EVERY path
(not just long ones), and Java's file APIs do not reliably support that prefix across
JDK versions — applying it to every Ghidra/BinDiff invocation risked turning a rare,
unverified long-path edge case into every-invocation breakage. The actual fix is a
fail-fast length check: raise a clear RuntimeError before the external tool ever runs,
instead of silently handing it a path that may or may not work.

These tests exercise the REAL _check_subprocess_path() and its real call sites in
ghidra_binexport()/run_differ() against this session's real bundled tool_paths.py
resolvers (no Ghidra/BinDiff actually invoked — subprocess.run is asserted never
called for the long-path cases, and real tool resolution only needs to succeed, which
it does in this environment)."""
import os
import tempfile
import unittest
from unittest import mock

from patch_differ_cli import _bindiff as bd
from patch_differ_cli import tool_paths as tp


class TestCheckSubprocessPath(unittest.TestCase):
    def test_short_path_is_a_no_op(self):
        bd._check_subprocess_path(r"C:\short\path\out.BinExport", "test path")  # no raise

    def test_long_path_raises_with_a_clear_message(self):
        long_dir = "C:\\" + ("a" * 300)
        with self.assertRaises(RuntimeError) as ctx:
            bd._check_subprocess_path(long_dir, "test path")
        msg = str(ctx.exception)
        self.assertIn("test path", msg)
        self.assertIn("259", msg)  # mentions the MAX_PATH-style limit by name

    def test_non_windows_is_never_checked(self):
        with mock.patch("os.name", "posix"):
            bd._check_subprocess_path("C:\\" + ("a" * 300), "test path")  # no raise


class TestGhidraBinexportFailsFastOnLongPath(unittest.TestCase):
    """Requires the real bundled Ghidra + BinExport script to resolve (both are present
    in this session's tools/ checkout) so the test reaches the NEW length check rather
    than stopping earlier at GhidraNotConfigured/BinExportNotInstalled."""

    def setUp(self):
        if not tp.analyze_headless() or not tp.locate_binexport_script():
            self.skipTest("bundled Ghidra/BinExport not present in this checkout")

    def test_long_project_dir_raises_before_any_subprocess_call(self):
        long_project_dir = "C:\\" + ("a" * 300)
        with tempfile.TemporaryDirectory() as d:
            binary_path = os.path.join(d, "x.dll")
            out_path = os.path.join(d, "x.BinExport")
            open(binary_path, "wb").close()
            with mock.patch("patch_differ_cli._bindiff._run_tool") as mock_run:
                with self.assertRaises(RuntimeError) as ctx:
                    bd.ghidra_binexport(binary_path, long_project_dir, out_path)
                mock_run.assert_not_called()
        self.assertIn("Ghidra project directory", str(ctx.exception))

    def test_long_binary_path_raises_before_any_subprocess_call(self):
        with tempfile.TemporaryDirectory() as d:
            project_dir = os.path.join(d, "proj")
            out_path = os.path.join(d, "x.BinExport")
            long_binary_path = os.path.join(d, "a" * 300 + ".dll")
            with mock.patch("patch_differ_cli._bindiff._run_tool") as mock_run:
                with self.assertRaises(RuntimeError) as ctx:
                    bd.ghidra_binexport(long_binary_path, project_dir, out_path)
                mock_run.assert_not_called()
        self.assertIn("input binary", str(ctx.exception))


class TestRunDifferFailsFastOnLongPath(unittest.TestCase):
    def setUp(self):
        if not tp.locate_differ():
            self.skipTest("bundled BinDiff not present in this checkout")

    def test_long_out_dir_raises_before_any_subprocess_call(self):
        with tempfile.TemporaryDirectory() as d:
            primary = os.path.join(d, "prior.BinExport")
            secondary = os.path.join(d, "fixed.BinExport")
            long_out_dir = "C:\\" + ("a" * 300)
            open(primary, "wb").close()
            open(secondary, "wb").close()
            with mock.patch("patch_differ_cli._bindiff._run_tool") as mock_run:
                with self.assertRaises(RuntimeError) as ctx:
                    bd.run_differ(primary, secondary, long_out_dir)
                mock_run.assert_not_called()
        self.assertIn("BinDiff output directory", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
