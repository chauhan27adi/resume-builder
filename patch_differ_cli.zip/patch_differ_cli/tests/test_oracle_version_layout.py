"""Oracle Stage 2 per-version output + per-object BinDiff workdir (bug.md ORA-T1-1 and the
MSSQL/DB2 layout parity): each build's disassembly/pseudo-C go to their own
disassembled_instructions_{vuln,fixed}_<ver>/ and decompiled_c_{vuln,fixed}_<ver>/ folders
(one <object>_<sha8>/ subfolder with a binary.json), the diffs to one _vs_ folder, and BinDiff
working data to <workdir>/bindiff_work/<object>/ — never inside stage2/. Ghidra is faked."""
import json
import os
import tempfile
import unittest
from unittest import mock

from patch_differ_cli import _bindiff as bd
from patch_differ_cli import _x86diff as X
from patch_differ_cli import pipeline as pl
from patch_differ_cli.oracle import stage2 as o2

REL = "oracle/lib/kdz.o"
P = {"chk": (0x0, b"\x81\xff\x00\x01\x00\x00\xc3")}   # cmp edi,0x100; ret
F = {"chk": (0x0, b"\x81\xff\xff\x00\x00\x00\xc3")}   # cmp edi,0xff ; ret
_BASE = o2._GHIDRA_ELF_REL_BASE


def _read(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def _touch(path, data=b"x"):
    with open(path, "wb") as fh:
        fh.write(data)


class OracleVersionLayoutTests(unittest.TestCase):
    def _run(self, d, decompile=False, vuln_label="RU-19.20", fixed_label="RU-19.21",
             captured=None):
        def fake_diff_pair(pa, fa, workdir, progress=None):
            if captured is not None:
                captured.append(workdir.replace("\\", "/"))
            return {_BASE: bd.FuncMatch(_BASE, _BASE, 0.9, 0.9, "chk", "chk")}

        p, f, w = (os.path.join(d, x) for x in ("p", "f", "w"))
        for root, body in ((p, b"PRIOR-OBJ-BYTES"), (f, b"FIXED-OBJ-BYTES")):
            os.makedirs(os.path.dirname(os.path.join(root, REL)), exist_ok=True)
            open(os.path.join(root, REL), "wb").write(body)
        with mock.patch.object(o2, "_func_map",
                               lambda path: dict(P if "/p/" in path.replace("\\", "/") else F)), \
                mock.patch.object(o2, "_func_sections", lambda path: {1}), \
                mock.patch.object(X, "fix_signature", return_value=(1, ["guard"])), \
                mock.patch.object(o2, "decompile_cached",
                                  lambda pb, fb, cache: ("int prior_c;", "int fixed_c;", True)), \
                mock.patch.object(bd, "diff_pair", fake_diff_pair):
            r = o2.run(p, f, w,
                       stage0={"code_changed": [{"name": REL, "kind": "native", "size": 15}]},
                       use_bindiff=True, decompile=decompile,
                       vuln_label=vuln_label, fixed_label=fixed_label)
        return r, os.path.join(w, "stage2")

    def test_each_build_gets_its_own_files(self):
        with tempfile.TemporaryDirectory() as d:
            r, s2 = self._run(d, decompile=True)
            self.assertEqual([(c["object"], c["match_algorithm"]) for c in r["readable_files"]],
                             [("kdz.o :: chk", "bindiff")])
            subs = {}
            for build, ver, c_text in (("vuln", "RU-19.20", "int prior_c;"),
                                       ("fixed", "RU-19.21", "int fixed_c;")):
                adir = os.path.join(s2, f"disassembled_instructions_{build}_{ver}")
                (sub,) = os.listdir(adir)
                self.assertTrue(sub.startswith("kdz.o_"), sub)   # folder keyed by object name
                subs[build] = sub
                meta = json.loads(_read(os.path.join(adir, sub, "binary.json")))
                self.assertEqual((meta["version"], meta["build"]), (ver, build))
                self.assertTrue(sub.endswith(meta["sha256"][:8]))
                listing = _read(os.path.join(adir, sub, o2._safe("chk") + ".asm"))
                self.assertIn("; chk", listing)
                self.assertIn("offset 0x0", listing, "ET_REL section-relative offset, not RVA")
                c_file = os.path.join(s2, f"decompiled_c_{build}_{ver}", sub, o2._safe("chk") + ".c")
                self.assertEqual(_read(c_file), c_text, "each side's own pseudo-C")
            # distinct content -> distinct per-binary subfolders
            self.assertNotEqual(subs["vuln"], subs["fixed"])
            (diff,) = [x for x in os.listdir(os.path.join(s2, "disassembled_instructions_"
                                                          "RU-19.20_vs_RU-19.21"))
                       if x.endswith(".asm.diff")]
            self.assertTrue(diff.startswith("RU-19.20_RU-19.21_"), diff)
            self.assertFalse(os.path.exists(os.path.join(s2, "decompiled_c")))
            self.assertFalse(os.path.exists(os.path.join(s2, "disassembled_instructions")))

    def test_bindiff_intermediates_live_beside_stage2_not_inside(self):
        # bug.md ORA-T1-1: per-object workdir under <workdir>/bindiff_work/, never stage2/.
        with tempfile.TemporaryDirectory() as d:
            captured = []
            self._run(d, captured=captured)
            self.assertTrue(captured)
            for wd in captured:
                self.assertIn("/bindiff_work/", wd)
                self.assertNotIn("/stage2/", wd)

    def test_no_pseudo_c_folders_without_decompile(self):
        with tempfile.TemporaryDirectory() as d:
            _r, s2 = self._run(d, decompile=False)
            made = sorted(os.listdir(s2))
            self.assertIn("disassembled_instructions_vuln_RU-19.20", made)
            self.assertFalse([m for m in made if m.startswith("decompiled_c")], made)

    def test_unlabelled_run_falls_back_to_unversioned(self):
        with tempfile.TemporaryDirectory() as d:
            _r, s2 = self._run(d, vuln_label=None, fixed_label=None)
            made = sorted(os.listdir(s2))
            self.assertIn("disassembled_instructions_vuln_unversioned", made)
            self.assertIn("disassembled_instructions_unversioned_vs_unversioned", made)


class OracleRebuildOnlyTests(unittest.TestCase):
    """bug.md ORA-NT-1/NT-2: a changed native object/archive whose executable code did not
    change is recorded as a rebuild-only verdict, not left traceless; a real code change
    still produces a function card and no rebuild-only entry."""

    REL = "oracle/lib/kdz.o"

    def _run(self, rel, prior_obj, fixed_obj, kind="native"):
        d = tempfile.mkdtemp()
        p, f, w = (os.path.join(d, x) for x in ("p", "f", "w"))
        for root, body in ((p, prior_obj), (f, fixed_obj)):
            os.makedirs(os.path.dirname(os.path.join(root, rel)), exist_ok=True)
            _touch(os.path.join(root, rel), body)
        return o2.run(p, f, w, stage0={"code_changed":
                      [{"name": rel, "kind": kind, "size": len(fixed_obj)}]})

    def test_rebuild_only_object_is_recorded_not_traceless(self):
        from patch_differ_cli.tests.test_unnamed_elf_function_diff import build_elf
        base = build_elf([("f", 0x0, 2, b"\x90\xc3")], et_rel=True)   # nop; ret
        r = self._run(self.REL, base, base + b"\x00")                 # identical code, +1 byte
        self.assertEqual(r["readable_files"], [])
        self.assertEqual([(b["object"], b["verdict"]) for b in r["binaries"]],
                         [("kdz.o", "rebuild-only")])

    def test_real_code_change_emits_a_card_and_no_rebuild_only(self):
        from patch_differ_cli.tests.test_unnamed_elf_function_diff import build_elf
        pri = build_elf([("f", 0x0, 7, b"\x81\xff\x00\x01\x00\x00\xc3")], et_rel=True)
        fix = build_elf([("f", 0x0, 7, b"\x81\xff\xff\x00\x00\x00\xc3")], et_rel=True)
        r = self._run(self.REL, pri, fix)
        self.assertEqual([(c["object"], c["change"]) for c in r["readable_files"]],
                         [("kdz.o :: f", "code")])
        self.assertFalse([b for b in r["binaries"] if b["verdict"] == "rebuild-only"])

    def test_all_rebuild_archive_gets_one_verdict_not_per_member_flood(self):
        from patch_differ_cli.tests.test_unnamed_elf_function_diff import build_elf
        from patch_differ_cli.tests.test_silent_loss_fixes import _ar
        base = build_elf([("f", 0x0, 2, b"\x90\xc3")], et_rel=True)
        rel = "oracle/lib/libserver.a"
        pa = _ar([("m1.o", base), ("m2.o", base)])
        fa = _ar([("m1.o", base + b"\x00"), ("m2.o", base + b"\x00")])   # both members rebuilt
        r = self._run(rel, pa, fa, kind="archive")
        rebuilds = [b for b in r["binaries"] if b["verdict"] == "rebuild-only"]
        self.assertEqual([b["object"] for b in rebuilds], ["libserver.a"], "one, not per-member")
        self.assertEqual(r["readable_files"], [])


class OracleLabelTests(unittest.TestCase):
    """bug.md ORA-T1-2: the Oracle per-version label comes from the RU patch zip's file name,
    and an explicit --vuln-label / --fixed-label overrides it."""

    def test_zip_label_helper(self):
        with tempfile.TemporaryDirectory() as d:
            _touch(os.path.join(d, "p35643107_190000_Linux-x86-64.zip"))
            self.assertEqual(pl._oracle_zip_label(d), "p35643107")
        with tempfile.TemporaryDirectory() as d:       # no zip -> None (-> unversioned)
            os.makedirs(os.path.join(d, "contents"))
            self.assertIsNone(pl._oracle_zip_label(d))
        with tempfile.TemporaryDirectory() as d:       # several zips -> ambiguous -> None
            for n in ("a.zip", "b.zip"):
                _touch(os.path.join(d, n))
            self.assertIsNone(pl._oracle_zip_label(d))
        with tempfile.TemporaryDirectory() as d:       # non-p name -> file stem
            _touch(os.path.join(d, "ru_2024_q3.zip"))
            self.assertEqual(pl._oracle_zip_label(d), "ru_2024_q3")

    def _run_capturing_labels(self, d, **kw):
        seen = {}

        class Stage:
            @staticmethod
            def run(*a, **k):
                seen.update(k)
                return {"counts": {}, "readable_files": []}

        for side, zipname in (("v", "p35643107_190000_Linux-x86-64.zip"),
                              ("f", "p36199232_190000_Linux-x86-64.zip")):
            os.makedirs(os.path.join(d, side))
            _touch(os.path.join(d, side, zipname))
        with mock.patch.object(pl, "_import", lambda name: Stage):
            pl.run_pipeline("oracle", vuln_dir=os.path.join(d, "v"),
                            fixed_dir=os.path.join(d, "f"), out_dir=os.path.join(d, "o"),
                            stages={"triage", "stage2"}, verbose=False, **kw)
        return seen

    def test_pipeline_derives_label_from_ru_zip(self):
        with tempfile.TemporaryDirectory() as d:
            seen = self._run_capturing_labels(d)
            self.assertEqual((seen["vuln_label"], seen["fixed_label"]),
                             ("p35643107", "p36199232"))

    def test_cli_label_overrides_the_zip_name(self):
        with tempfile.TemporaryDirectory() as d:
            seen = self._run_capturing_labels(d, vuln_label="19.20", fixed_label="19.21")
            self.assertEqual((seen["vuln_label"], seen["fixed_label"]), ("19.20", "19.21"))


if __name__ == "__main__":
    unittest.main()
