"""Regression tests for bugs.md #11 (a different requested source reused the previously
extracted build) and #8 (an interrupted extraction was reused as a complete build), plus the
pruned-partner interaction found while fixing them: _write_manifest_and_prune deletes
byte-identical files from BOTH DB2 trees, so a pruned tree is only complete together with
the partner it was pruned against.

These drive the REAL db2/mssql acquire() with only the network/extraction I/O mocked."""
import hashlib
import json
import os
import tempfile
import unittest
from unittest import mock

import patch_differ_cli.db2.acquire as dacq
import patch_differ_cli.mssql.acquire as macq
from patch_differ_cli import _acquire_state as state


def _fake_tree(root, files, hashes=None):
    for rel, data in files.items():
        name = f"opt/ibm/db2/V11.5/{rel}"
        p = os.path.join(root, name)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "wb") as fh:
            fh.write(data)
        if hashes is not None:
            hashes[name] = hashlib.sha256(data).hexdigest()


class _Db2Harness(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory(prefix="pdff_acq_")
        self.work = self._td.name
        self.calls = []
        self.payload = {}          # tag -> files
        self.fail_tags = {"boom"}

    def tearDown(self):
        self._td.cleanup()

    def _container(self, ref, side_dir, online, progress, base, span, hashes=None, root_dir=None):
        self.calls.append(ref)
        tag = ref.rsplit(":", 1)[-1]
        if tag in self.fail_tags:
            _fake_tree(root_dir, {"lib64/half.so": b"half"})
            raise RuntimeError("network died mid-extract")
        _fake_tree(root_dir, self.payload.get(tag, {"lib64/libdb2e.so.1": tag.encode()}), hashes)
        return root_dir

    def acquire(self, vuln, fixed, sides=("vuln", "fixed")):
        with mock.patch.object(dacq, "_acquire_container", self._container):
            return dacq.acquire({"vuln_dl_url": vuln, "dl_url": fixed}, self.work, sides=sides)


class TestDb2SourceAwareReuse(_Db2Harness):
    def test_same_source_is_reused(self):
        self.acquire("container:r/db2:1", "container:r/db2:2")
        self.acquire("container:r/db2:1", "container:r/db2:2")
        self.assertEqual(self.calls, ["r/db2:1", "r/db2:2"])

    def test_different_requested_source_is_reacquired(self):
        self.acquire("container:r/db2:1", "container:r/db2:2", sides=("fixed",))
        out = self.acquire("container:r/db2:1", "container:r/db2:3", sides=("fixed",))
        self.assertEqual(self.calls, ["r/db2:2", "r/db2:3"])
        with open(os.path.join(out["fixed"], "lib64", "libdb2e.so.1"), "rb") as fh:
            self.assertEqual(fh.read(), b"3")
        stale = [d for d in os.listdir(os.path.join(self.work, "acquire", "fixed"))
                 if d.startswith("root.stale-") and not d.endswith(".json")]
        self.assertEqual(len(stale), 1, "the replaced tree is moved aside, never deleted")

    def test_tree_without_completion_marker_is_not_reused(self):
        # A partial/legacy tree: a V* dir exists but no sidecar was ever written.
        _fake_tree(os.path.join(self.work, "acquire", "fixed", "root"), {"lib64/half.so": b"x"})
        self.acquire(None, "container:r/db2:2", sides=("fixed",))
        self.assertEqual(self.calls, ["r/db2:2"])

    def test_interrupted_extraction_leaves_existing_tree_intact_and_unmarked_partial(self):
        good = self.acquire(None, "container:r/db2:2", sides=("fixed",))["fixed"]
        with self.assertRaises(RuntimeError):
            self.acquire(None, "container:r/db2:boom", sides=("fixed",))
        side = os.path.join(self.work, "acquire", "fixed")
        self.assertFalse(os.path.exists(os.path.join(side, "root.partial")))
        self.assertTrue(os.path.isfile(os.path.join(good, "lib64", "libdb2e.so.1")),
                        "a failed re-acquire must not destroy the working tree")
        # the failed source was never recorded, so it's retried next time
        self.calls.clear()
        self.fail_tags.clear()
        self.acquire(None, "container:r/db2:boom", sides=("fixed",))
        self.assertEqual(self.calls, ["r/db2:boom"])


class TestDb2ManualDrop(_Db2Harness):
    def _drop(self, side, name, data):
        d = os.path.join(self.work, "acquire", side, "drop")
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, name)
        with open(p, "wb") as fh:
            fh.write(data)
        return p

    def _manual(self, side, side_dir, label, hashes=None, root_dir=None):
        self.calls.append(label)
        with open(dacq._manual_drop(side_dir), "rb") as fh:
            _fake_tree(root_dir, {"lib64/libdb2e.so.1": fh.read()})
        return root_dir

    def acquire_manual(self):
        with mock.patch.object(dacq, "_acquire_manual", self._manual):
            return dacq.acquire({"dl_url": "manual:v1-fp1"}, self.work, sides=("fixed",))

    def test_different_drop_under_same_label_is_reacquired(self):
        p = self._drop("fixed", "fp.tar.gz", b"build-A")
        self.acquire_manual()
        os.remove(p)
        self._drop("fixed", "fp.tar.gz", b"build-B-longer")
        out = self.acquire_manual()
        self.assertEqual(self.calls, ["v1-fp1", "v1-fp1"])
        with open(os.path.join(out["fixed"], "lib64", "libdb2e.so.1"), "rb") as fh:
            self.assertEqual(fh.read(), b"build-B-longer")

    def test_drop_removed_after_extract_still_reuses(self):
        p = self._drop("fixed", "fp.tar.gz", b"build-A")
        self.acquire_manual()
        os.remove(p)                          # users delete the multi-GB archive
        self.acquire_manual()
        self.assertEqual(self.calls, ["v1-fp1"])


class TestDb2PrunedPartner(_Db2Harness):
    def setUp(self):
        super().setUp()
        common = {"bin/same": b"identical"}
        self.payload = {"1": {**common, "lib64/libdb2e.so.1": b"one"},
                        "2": {**common, "lib64/libdb2e.so.1": b"two"},
                        "3": {**common, "lib64/libdb2e.so.1": b"three"}}

    def test_manifest_is_bound_to_trees_and_pruned_side_not_reused_alone(self):
        out = self.acquire("container:r/db2:1", "container:r/db2:2")
        mpath = os.path.join(self.work, "acquire", "manifest.json")
        with open(mpath, encoding="utf-8") as fh:
            man = json.load(fh)
        self.assertEqual(man["changed"], ["lib64/libdb2e.so.1"])
        self.assertEqual(set(man["trees"]), {"vuln", "fixed"})
        self.assertFalse(os.path.exists(os.path.join(out["vuln"], "bin", "same")),
                         "identical file pruned")
        # Change ONLY the fixed source: vuln was pruned against the old fixed tree, so it
        # must be re-extracted too, and the stale manifest must be gone.
        self.calls.clear()
        out = self.acquire("container:r/db2:1", "container:r/db2:3")
        self.assertEqual(sorted(self.calls), ["r/db2:1", "r/db2:3"])
        # both fresh again -> a NEW manifest bound to the new trees
        with open(mpath, encoding="utf-8") as fh:
            man2 = json.load(fh)
        self.assertNotEqual(man2["trees"]["fixed"]["extraction_id"],
                            man["trees"]["fixed"]["extraction_id"])

    def test_single_side_request_never_reuses_a_pruned_tree(self):
        self.acquire("container:r/db2:1", "container:r/db2:2")
        self.calls.clear()
        self.acquire("container:r/db2:1", None, sides=("vuln",))
        self.assertEqual(self.calls, ["r/db2:1"])


class TestMssqlKbAwareReuse(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory(prefix="pdff_macq_")
        self.work = self._td.name
        self.extracted = []

    def tearDown(self):
        self._td.cleanup()

    def _download(self, url, dest, **kw):
        with open(dest, "wb") as fh:
            fh.write(url.encode())
        return dest

    def _extract_into(self, exe, out_dir, cab_dir, msp_stage):
        self.extracted.append(os.path.basename(exe))
        with open(exe, "rb") as fh:
            data = fh.read()
        if data.endswith(b"boom"):
            raise RuntimeError("7z failed")
        with open(os.path.join(out_dir, "ENG_RE_sqlmin_dll_64"), "wb") as fh:
            fh.write(data)

    def acquire(self, kb):
        patch = {"kb": kb, "fixed_build": f"KB{kb}", "dl_url": None}
        with mock.patch.object(macq, "resolve_exe_url", lambda kb, page=None: f"https://x/{kb}"), \
                mock.patch.object(macq, "download", self._download), \
                mock.patch.object(macq, "_extract_engine_into", self._extract_into):
            return macq.acquire(patch, self.work, sides=("fixed",))

    def test_different_kb_is_reacquired(self):
        self.acquire("1111111")
        out = self.acquire("2222222")
        self.assertEqual(self.extracted, ["KB1111111.exe", "KB2222222.exe"])
        with open(os.path.join(out["fixed"], "ENG_RE_sqlmin_dll_64"), "rb") as fh:
            self.assertEqual(fh.read(), b"https://x/2222222")

    def test_same_kb_is_reused(self):
        self.acquire("1111111")
        self.acquire("1111111")
        self.assertEqual(self.extracted, ["KB1111111.exe"])

    def test_engine_without_marker_is_not_reused(self):
        eng = os.path.join(self.work, "acquire", "fixed", "engine")
        os.makedirs(eng)
        open(os.path.join(eng, "ENG_old_dll_64"), "wb").close()      # legacy/partial
        self.acquire("1111111")
        self.assertEqual(self.extracted, ["KB1111111.exe"])

    def test_failed_extraction_is_not_recorded(self):
        with self.assertRaises(RuntimeError):
            self.acquire("boom")
        self.assertFalse(state.is_complete(os.path.join(self.work, "acquire", "fixed", "engine"),
                                           {"kb": "boom"}))


class TestManualInstallerExtract(unittest.TestCase):
    """pipeline._prepare_mssql_dir extracts a user-supplied .exe into the SAME acquire dir;
    a different installer must not get the previous one's engine."""

    def test_different_installer_is_reextracted(self):
        with tempfile.TemporaryDirectory(prefix="pdff_mexe_") as d:
            exe = os.path.join(d, "patch.exe")
            out, cabs = os.path.join(d, "engine"), os.path.join(d, "cabs")
            seen = []

            def write(path, data):
                with open(path, "wb") as fh:
                    fh.write(data)

            def into(exe_path, out_dir, cab_dir, msp_stage):
                with open(exe_path, "rb") as fh:
                    seen.append(fh.read())
                write(os.path.join(out_dir, "ENG_x_dll_64"), seen[-1])

            with mock.patch.object(macq, "_extract_engine_into", into):
                write(exe, b"A")
                macq.extract_engine(exe, out, cabs)
                macq.extract_engine(exe, out, cabs)            # same installer -> reused
                write(exe, b"BB")                              # different installer
                macq.extract_engine(exe, out, cabs)
            self.assertEqual(seen, [b"A", b"BB"])
            with open(os.path.join(out, "ENG_x_dll_64"), "rb") as fh:
                self.assertEqual(fh.read(), b"BB")


if __name__ == "__main__":
    unittest.main()
