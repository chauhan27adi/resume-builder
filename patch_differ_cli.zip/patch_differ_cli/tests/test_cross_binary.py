"""Regression tests for CRIT-NT-8: _results.mark_cross_binary() grouped cards by the LAST
"::" segment of the function name, so unrelated methods that merely shared a name in
different binaries (CAlterLogin::CheckAuthorization vs CBackupJob::CheckAuthorization), and
unnamed sub_<addr> placeholders at the same address, were flagged cross_binary=True. That
flag is a corroboration input to _attribution.resolve(), so it asserted CVE claims nothing
supported. Also covers refresh_cross_binary(), used by --reattribute so a functions_diff.json
saved by the old version doesn't keep its stale flags/boosts."""
import json
import tempfile
import unittest
from pathlib import Path

from patch_differ_cli import _results as R


def _card(lib, name, fix_score=0, fix_why=""):
    return {"object": f"{lib} :: {name}", "group": lib, "fix_score": fix_score,
            "fix_why": fix_why}


class TestFuncKey(unittest.TestCase):
    def test_keeps_full_qualified_name(self):
        self.assertEqual(R._func_key("sqlmin.dll :: CAlterLogin::CheckAuthorization"),
                         "CAlterLogin::CheckAuthorization")

    def test_unnamed_placeholder_has_no_identity(self):
        self.assertIsNone(R._func_key("sqlmin.dll :: sub_1000"))

    def test_archive_member_prefix(self):
        self.assertEqual(R._func_key("libserver.a!kkz.o :: kkzdrphidcol"), "kkzdrphidcol")


class TestMarkCrossBinary(unittest.TestCase):
    def test_different_classes_sharing_a_method_name_do_not_corroborate(self):
        rows = [_card("sqlmin.dll", "CAlterLogin::CheckAuthorization"),
                _card("sqllang.dll", "CBackupJob::CheckAuthorization")]
        R.mark_cross_binary(rows)
        self.assertFalse(any(r.get("cross_binary") for r in rows))

    def test_unnamed_placeholders_at_same_address_do_not_corroborate(self):
        rows = [_card("sqlmin.dll", "sub_1000", 15, "inserted 1 guard(s)"),
                _card("sqllang.dll", "sub_1000", 15, "inserted 1 guard(s)")]
        R.mark_cross_binary(rows)
        self.assertFalse(any(r.get("cross_binary") for r in rows))
        self.assertEqual([r["fix_score"] for r in rows], [15, 15])

    def test_same_function_in_two_libs_still_corroborates_and_boosts(self):
        rows = [_card("libdb2.so", "sqloAuthCheck", 6, "inserted 1 guard(s)"),
                _card("libdb2e.so", "sqloAuthCheck", 6, "inserted 1 guard(s)")]
        R.mark_cross_binary(rows)
        for r in rows:
            self.assertTrue(r["cross_binary"])
            self.assertEqual(r["multi_lib"], 2)
            self.assertEqual(r["fix_score"], 8)
            self.assertTrue(r["fix_why"].endswith("also changed in 2 libs"))


class TestRefreshCrossBinary(unittest.TestCase):
    def _stale(self):
        # What the OLD grouping wrote: two different classes flagged + boosted.
        rows = [_card("sqlmin.dll", "CAlterLogin::CheckAuthorization", 8,
                      "inserted 1 guard(s); also changed in 2 libs"),
                _card("sqllang.dll", "CBackupJob::CheckAuthorization", 0, "")]
        rows[0].update(cross_binary=True, multi_lib=2)
        rows[1].update(cross_binary=True, multi_lib=2)   # fix_score 0 -> no boost applied
        return rows

    def test_stale_false_flags_and_boost_are_removed(self):
        rows = self._stale()
        R.refresh_cross_binary(rows)
        self.assertFalse(any("cross_binary" in r or "multi_lib" in r for r in rows))
        self.assertEqual(rows[0]["fix_score"], 6)
        self.assertEqual(rows[0]["fix_why"], "inserted 1 guard(s)")
        self.assertEqual(rows[1]["fix_score"], 0)

    def test_refresh_is_idempotent_on_correct_results(self):
        rows = [_card("libdb2.so", "sqloAuthCheck", 6, "inserted 1 guard(s)"),
                _card("libdb2e.so", "sqloAuthCheck", 6, "inserted 1 guard(s)")]
        R.mark_cross_binary(rows)
        snapshot = json.dumps(rows, sort_keys=True)
        R.refresh_cross_binary(rows)
        R.refresh_cross_binary(rows)
        self.assertEqual(json.dumps(rows, sort_keys=True), snapshot)

    def test_suffix_only_fix_why_is_cleared(self):
        rows = [_card("a.dll", "X::Y", 4, "also changed in 2 libs"),
                _card("b.dll", "Z::Y", 0, "")]
        for r in rows:
            r.update(cross_binary=True, multi_lib=2)
        R.refresh_cross_binary(rows)
        self.assertEqual(rows[0]["fix_why"], "")
        self.assertEqual(rows[0]["fix_score"], 2)


class TestReattributeEndToEnd(unittest.TestCase):
    """--reattribute on a stale functions_diff.json must not keep the false CVE assertion."""

    def test_stale_result_no_longer_asserts(self):
        from patch_differ_cli import pipeline
        with tempfile.TemporaryDirectory(prefix="pdff_crit_nt8_") as d:
            out = Path(d)
            (out / "stage2").mkdir()
            rows = [
                {"object": "sqlmin.dll :: CAlterLogin::CheckAuthorization", "group": "sqlmin.dll",
                 "fix_score": 0, "fix_why": "", "cross_binary": True, "multi_lib": 2,
                 "similarity": 0.9, "change": "code"},
                {"object": "sqllang.dll :: CBackupJob::CheckAuthorization", "group": "sqllang.dll",
                 "fix_score": 0, "fix_why": "", "cross_binary": True, "multi_lib": 2,
                 "similarity": 0.9, "change": "code"},
            ]
            (out / "stage2" / "functions_diff.json").write_text(
                json.dumps({"readable_files": rows, "counts": {}}), encoding="utf-8")
            (out / "cves.json").write_text(json.dumps([
                {"cve_id": "CVE-2025-1111", "cve_desc": "an authorization issue",
                 "component": "Engine", "cwe_id": "CWE-285"}]), encoding="utf-8")
            res = pipeline._reattribute_stage2("mssql", out, None, verbose=False)["stage2"]
        self.assertEqual(res["counts"]["attributed"], 0)
        self.assertEqual(res["counts"]["candidates"], 2)
        self.assertFalse(any(r.get("cross_binary") for r in res["readable_files"]))


if __name__ == "__main__":
    unittest.main()
