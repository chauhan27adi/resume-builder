"""Regression tests for bugs.md #63: a function BinDiff left unmatched on BOTH sides under
the same name was reported as removed + added and never diffed (live-verified on MSSQL PE
DLLs: a rewritten ParseLogin, and phantom cards for a pure reorder). Such functions are now
paired by name after BinDiff matching. BinDiff is mocked here. Scratch files live in
TemporaryDirectory()s only."""
import os
import tempfile
import unittest
from unittest import mock

import patch_differ_cli._bindiff as bd
import patch_differ_cli.db2.stage2 as d2
import patch_differ_cli.oracle.stage2 as o2
from patch_differ_cli.tests.test_fallback_and_symbol_reporting import _mssql_run
from patch_differ_cli.tests.test_silent_loss_fixes import _GLOBAL_FUNC, _elf, _write


def _chk(imm):
    return (bytes.fromhex("81ff") + imm.to_bytes(4, "little") + bytes.fromhex("7303")
            + bytes.fromhex("31c0c3") + bytes.fromhex("b801000000c3"))


def M(a1, a2, sim=1.0):
    return bd.FuncMatch(a1, a2, sim, 0.99)


def _cards(readable):
    return sorted((c["object"].split(" :: ")[-1], c["change"], c["match_algorithm"])
                  for c in readable)


class MssqlTests(unittest.TestCase):
    """_mssql_run: Init@0x1000, CheckLength@0x1010 (changed), Release@0x1030, PDB both sides,
    ImageBase 0 -> BinDiff VA == RVA."""

    def test_unmatched_changed_function_is_paired_by_name_and_diffed(self):
        matches = {0x1000: M(0x1000, 0x1000), 0x1030: M(0x1030, 0x1030)}   # CheckLength unmatched
        r = _mssql_run(symbolized=("prior", "fixed"), use_bindiff=True,
                       diff_pair=lambda *a, **k: matches)
        self.assertEqual(_cards(r["readable"]), [("CheckLength", "const", "name")],
                         "not removed + added: diffed, labelled as name-paired")
        self.assertIsNone(r["bindiff_fallback"])

    def test_nothing_matched_but_nothing_changed_gives_no_cards(self):
        matches = {0x1010: M(0x1010, 0x1010, 0.9)}            # only the changed one matched
        r = _mssql_run(symbolized=("prior", "fixed"), use_bindiff=True,
                       diff_pair=lambda *a, **k: matches)
        self.assertEqual(_cards(r["readable"]), [("CheckLength", "const", "bindiff")],
                         "Init/Release unmatched but byte-identical: no phantom cards")


class Db2Tests(unittest.TestCase):
    def _run(self, prior, fixed, matches):
        with tempfile.TemporaryDirectory() as d:
            rel = "lib/libx.so"
            _write(os.path.join(d, "p", rel), _elf(prior))
            _write(os.path.join(d, "f", rel), _elf(fixed))
            os.makedirs(os.path.join(d, "out"))
            job = {"prior_dir": os.path.join(d, "p"), "fixed_dir": os.path.join(d, "f"),
                   "rel": rel, "out": os.path.join(d, "out"), "attrib": [],
                   "use_bindiff": True, "decompile": False,
                   "disassembled_dir": os.path.join(d, "out"), "vuln_label": "v",
                   "fixed_label": "f", "run_ts": "t"}
            with mock.patch.object(bd, "diff_pair", lambda *a, **k: matches):
                return d2._process_file(job)

    def test_unmatched_changed_function_is_paired_by_name(self):
        base = d2._GHIDRA_ELF_PIE_BASE                      # _elf() builds ET_DYN
        prior = [("parse", _GLOBAL_FUNC, 0x0, _chk(0x100)), ("helper", _GLOBAL_FUNC, 0x20, b"\x90\xc3")]
        fixed = [("parse", _GLOBAL_FUNC, 0x0, _chk(0xFF)), ("helper", _GLOBAL_FUNC, 0x20, b"\x90\xc3")]
        r = self._run(prior, fixed, {base + 0x20: M(base + 0x20, base + 0x20)})
        self.assertEqual(_cards(r["readable"]), [("parse", "const", "name")])

    def test_function_on_one_side_only_is_still_added_or_removed(self):
        base = d2._GHIDRA_ELF_PIE_BASE
        prior = [("old_fn", _GLOBAL_FUNC, 0x0, _chk(0x100)), ("helper", _GLOBAL_FUNC, 0x20, b"\x90\xc3")]
        fixed = [("new_fn", _GLOBAL_FUNC, 0x0, _chk(0x100)), ("helper", _GLOBAL_FUNC, 0x20, b"\x90\xc3")]
        r = self._run(prior, fixed, {base + 0x20: M(base + 0x20, base + 0x20)})
        self.assertEqual([c[:2] for c in _cards(r["readable"])],
                         [("new_fn", "added"), ("old_fn", "removed")])

    def test_a_rename_bindiff_matched_is_not_overridden(self):
        base = d2._GHIDRA_ELF_PIE_BASE
        prior = [("old_name", _GLOBAL_FUNC, 0x0, _chk(0x100)), ("helper", _GLOBAL_FUNC, 0x20, b"\x90\xc3")]
        fixed = [("new_name", _GLOBAL_FUNC, 0x0, _chk(0xFF)), ("helper", _GLOBAL_FUNC, 0x20, b"\x90\xc3")]
        r = self._run(prior, fixed, {base: M(base, base, 0.95), base + 0x20: M(base + 0x20, base + 0x20)})
        cards = [(c["object"], c["match_algorithm"]) for c in r["readable"]]
        self.assertEqual(len(cards), 1)
        self.assertIn("old_name", cards[0][0])
        self.assertIn("new_name", cards[0][0])
        self.assertEqual(cards[0][1], "bindiff")


class OracleTests(unittest.TestCase):
    def test_unmatched_changed_function_is_paired_by_name(self):
        P = {"kzx_parse": (0x0, _chk(0x100)), "helper": (0x20, b"\x90\xc3")}
        F = {"kzx_parse": (0x0, _chk(0xFF)), "helper": (0x20, b"\x90\xc3")}
        base = o2._GHIDRA_ELF_REL_BASE
        m = {base + 0x20: M(base + 0x20, base + 0x20)}
        with tempfile.TemporaryDirectory() as out, \
                mock.patch.object(o2, "_func_map", lambda path: dict(P if path == "PRIOR" else F)), \
                mock.patch.object(o2, "_func_sections", lambda path: {".text"}), \
                mock.patch.object(bd, "diff_pair", lambda *a, **k: m):
            readable, fb = [], []
            o2._diff_o("kzx.o", "kzx.o", "PRIOR", "FIXED", out, readable, attrib=[],
                       use_bindiff=True, disassembled_dir=out, run_ts="t", bindiff_fallbacks=fb)
        self.assertEqual(_cards(readable), [("kzx_parse", "code", "name")])
        self.assertEqual(fb, [])


if __name__ == "__main__":
    unittest.main()
