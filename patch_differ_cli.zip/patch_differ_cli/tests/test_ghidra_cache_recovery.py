"""Regression tests for IMP-T2-1 (stale Ghidra OSGi script-bundle cache detection and
recovery) and MIN-T2-1 (Ghidra's own subprocess return code is now checked as an extra
diagnostic signal in _decompile.py::decompile_pair()).

IMP-T2-1 background: both Track 1's BinExport.java and Track 2's DecompileFunc.java are
custom GhidraScripts that Ghidra dynamically compiles into a per-user OSGi bundle cache,
implicitly keyed to whichever JDK Ghidra last ran under (recorded in
~/.ghidra/.ghidra_<version>_<release>/java_home.save). A JDK switch leaves that cache
stale, failing with an opaque BundleException while Ghidra's own process still exits 0 —
this was live-reproduced as CRIT-T2-1's root cause in this engagement's own dev
environment. tool_paths.clear_stale_ghidra_script_cache() detects the mismatch and
clears ONLY the regenerable osgi/ subdirectory, never anything else.

These tests use a fully isolated fake Ghidra install + fake home directory (tempfile),
never touching this machine's real ~/.ghidra, so they stay deterministic regardless of
this environment's actual JDK/cache state."""
import io
import os
import tempfile
import unittest
from contextlib import redirect_stderr
from unittest import mock

from patch_differ_cli import tool_paths as tp


def _make_fake_ghidra_install(root, version="11.0.3", release="PUBLIC"):
    ghidra_dir = os.path.join(root, "Ghidra")
    os.makedirs(ghidra_dir)
    with open(os.path.join(ghidra_dir, "application.properties"), "w") as f:
        f.write(f"application.name=Ghidra\n"
               f"application.version={version}\n"
               f"application.release.name={release}\n")
    return root


def _make_fake_settings_dir(fake_home, version="11.0.3", release="PUBLIC",
                            java_home_save=None, with_osgi=True):
    settings_dir = os.path.join(fake_home, ".ghidra", f".ghidra_{version}_{release}")
    os.makedirs(settings_dir)
    if java_home_save is not None:
        with open(os.path.join(settings_dir, "java_home.save"), "w") as f:
            f.write(java_home_save)
    if with_osgi:
        osgi_dir = os.path.join(settings_dir, "osgi")
        os.makedirs(osgi_dir)
        with open(os.path.join(osgi_dir, "some_compiled.bundle"), "w") as f:
            f.write("fake compiled bundle content")
    return settings_dir


class TestClearStaleGhidraScriptCache(unittest.TestCase):
    def test_matching_jdk_leaves_cache_untouched(self):
        with tempfile.TemporaryDirectory() as ghidra_root, \
             tempfile.TemporaryDirectory() as fake_home:
            _make_fake_ghidra_install(ghidra_root)
            settings_dir = _make_fake_settings_dir(fake_home, java_home_save=r"C:\jdk-17")
            with mock.patch.object(tp, "ghidra_home", return_value=ghidra_root), \
                 mock.patch.object(tp, "java_home", return_value=r"C:\jdk-17"), \
                 mock.patch("os.path.expanduser", return_value=fake_home):
                err = io.StringIO()
                with redirect_stderr(err):
                    tp.clear_stale_ghidra_script_cache()
            self.assertTrue(os.path.isdir(os.path.join(settings_dir, "osgi")),
                           "cache must NOT be cleared when the JDK matches")
            self.assertEqual(err.getvalue(), "")

    def test_mismatched_jdk_clears_only_the_osgi_subdir(self):
        with tempfile.TemporaryDirectory() as ghidra_root, \
             tempfile.TemporaryDirectory() as fake_home:
            _make_fake_ghidra_install(ghidra_root)
            settings_dir = _make_fake_settings_dir(fake_home, java_home_save=r"C:\jdk-26")
            # a sibling file that must survive untouched
            with open(os.path.join(settings_dir, "preferences"), "w") as f:
                f.write("some real user preferences")
            with mock.patch.object(tp, "ghidra_home", return_value=ghidra_root), \
                 mock.patch.object(tp, "java_home", return_value=r"C:\jdk-17"), \
                 mock.patch("os.path.expanduser", return_value=fake_home):
                err = io.StringIO()
                with redirect_stderr(err):
                    tp.clear_stale_ghidra_script_cache()
            self.assertFalse(os.path.isdir(os.path.join(settings_dir, "osgi")),
                            "the stale osgi/ cache must be cleared on a JDK mismatch")
            self.assertTrue(os.path.isfile(os.path.join(settings_dir, "preferences")),
                           "unrelated settings-dir files must never be touched")
            self.assertIn("cleared Ghidra's compiled-script cache", err.getvalue())
            self.assertIn(r"C:\jdk-26", err.getvalue())
            self.assertIn(r"C:\jdk-17", err.getvalue())

    def test_no_java_home_save_yet_is_a_safe_no_op(self):
        with tempfile.TemporaryDirectory() as ghidra_root, \
             tempfile.TemporaryDirectory() as fake_home:
            _make_fake_ghidra_install(ghidra_root)
            settings_dir = _make_fake_settings_dir(fake_home, java_home_save=None)
            with mock.patch.object(tp, "ghidra_home", return_value=ghidra_root), \
                 mock.patch.object(tp, "java_home", return_value=r"C:\jdk-17"), \
                 mock.patch("os.path.expanduser", return_value=fake_home):
                tp.clear_stale_ghidra_script_cache()  # must not raise
            self.assertTrue(os.path.isdir(os.path.join(settings_dir, "osgi")))

    def test_mismatch_but_no_osgi_dir_is_a_safe_no_op(self):
        with tempfile.TemporaryDirectory() as ghidra_root, \
             tempfile.TemporaryDirectory() as fake_home:
            _make_fake_ghidra_install(ghidra_root)
            _make_fake_settings_dir(fake_home, java_home_save=r"C:\jdk-26", with_osgi=False)
            with mock.patch.object(tp, "ghidra_home", return_value=ghidra_root), \
                 mock.patch.object(tp, "java_home", return_value=r"C:\jdk-17"), \
                 mock.patch("os.path.expanduser", return_value=fake_home):
                tp.clear_stale_ghidra_script_cache()  # must not raise

    def test_unreadable_application_properties_is_a_safe_no_op(self):
        with tempfile.TemporaryDirectory() as fake_home:
            with mock.patch.object(tp, "ghidra_home", return_value=r"C:\does\not\exist"), \
                 mock.patch("os.path.expanduser", return_value=fake_home):
                tp.clear_stale_ghidra_script_cache()  # must not raise

    def test_settings_dir_name_derives_from_application_properties_not_hardcoded(self):
        # A different version/release must map to a correspondingly different dir name —
        # proves this isn't hardcoded to "11.0.3_PUBLIC".
        with tempfile.TemporaryDirectory() as ghidra_root:
            _make_fake_ghidra_install(ghidra_root, version="12.1.0", release="BETA")
            with mock.patch.object(tp, "ghidra_home", return_value=ghidra_root):
                settings_dir = tp._ghidra_user_settings_dir()
        self.assertTrue(settings_dir.endswith(os.path.join(".ghidra", ".ghidra_12.1.0_BETA")))


class TestDecompilePairReturnCodeCheck(unittest.TestCase):
    """MIN-T2-1: an unexpected Ghidra exit code now logs a diagnostic warning. Verified
    via the module-level functions decompile_pair() actually calls, fully mocked so no
    real Ghidra/subprocess runs."""

    def test_unexpected_returncode_with_output_logs_warning_but_does_not_raise(self):
        from patch_differ_cli import _decompile as dc

        fake_proc = mock.Mock(returncode=137, stdout=b"some crash trace")

        def fake_run(cmd, **kw):
            # Simulate the output files existing despite the odd exit code.
            outc = cmd[cmd.index("-postScript") + 2]
            with open(os.path.join(outc, "prior.c"), "w") as f:
                f.write("int FUN_00100000(void){return 1;}")
            return fake_proc

        with mock.patch.object(dc, "analyze_headless", return_value="fake_headless"), \
             mock.patch.object(dc.tp, "clear_stale_ghidra_script_cache"), \
             mock.patch.object(dc, "_run_tool", side_effect=fake_run):
            err = io.StringIO()
            with redirect_stderr(err):
                prior_c, fixed_c = dc.decompile_pair(b"x", b"y")
        self.assertIn("FUN_", prior_c)
        self.assertIn("WARNING: Ghidra decompile exited with unexpected code 137", err.getvalue())

    def test_normal_returncode_logs_nothing(self):
        from patch_differ_cli import _decompile as dc

        fake_proc = mock.Mock(returncode=1, stdout=b"")  # 1 = Ghidra warning, tolerated

        def fake_run(cmd, **kw):
            outc = cmd[cmd.index("-postScript") + 2]
            with open(os.path.join(outc, "prior.c"), "w") as f:
                f.write("int FUN_00100000(void){return 1;}")
            return fake_proc

        with mock.patch.object(dc, "analyze_headless", return_value="fake_headless"), \
             mock.patch.object(dc.tp, "clear_stale_ghidra_script_cache"), \
             mock.patch.object(dc, "_run_tool", side_effect=fake_run):
            err = io.StringIO()
            with redirect_stderr(err):
                dc.decompile_pair(b"x", b"y")
        self.assertEqual(err.getvalue(), "")


if __name__ == "__main__":
    unittest.main()
