"""db2_bugs.md Low items: DB2-6 (several archives in a drop folder are refused), DB2-14
(why a pseudo-C decompile failed is recorded per function), DB2-20 (heartbeat and moving
progress during long Ghidra steps), DB2-24 (no crash on a console that can't encode a
character) and DB2-26 (a full copy of a staged fixpack is announced). Ghidra is faked;
real child processes drive the heartbeat and console tests. Scratch files live in
TemporaryDirectory()s only."""
import contextlib
import io
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from patch_differ_cli import _bindiff as bd
from patch_differ_cli import _decompile as dc
from patch_differ_cli import _x86diff as X
from patch_differ_cli import cli
from patch_differ_cli import pipeline as pl
from patch_differ_cli import tool_paths as tp
from patch_differ_cli.db2 import acquire as A
from patch_differ_cli.db2 import stage2 as d2
from patch_differ_cli.tests.test_db2_major_fixes import GLOBAL, _job, _lib, _mov, _write

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# --------------------------------------------------------------------------- DB2-6
class ManualDropTests(unittest.TestCase):
    def test_one_archive(self):
        with tempfile.TemporaryDirectory() as d:
            a = _write(os.path.join(d, "drop", "fp.tar.gz"), b"x")
            _write(os.path.join(d, "drop", "fp.tar.gz.partial"), b"half")    # a copy in flight
            os.makedirs(os.path.join(d, "drop", "notes.tar"))               # a directory
            self.assertEqual(A._manual_drop(d), a)
            self.assertIsNone(A._manual_drop(os.path.join(d, "missing")))

    def test_several_archives_are_refused_not_guessed(self):
        with tempfile.TemporaryDirectory() as d:
            _write(os.path.join(d, "drop", "old.tar.gz"), b"x" * 10)
            _write(os.path.join(d, "drop", "new.tgz"), b"y")
            with self.assertRaises(RuntimeError) as cm:
                A._manual_drop(d)
        self.assertIn("2 fixpack archives", str(cm.exception))
        self.assertIn("new.tgz", str(cm.exception))
        self.assertIn("old.tar.gz", str(cm.exception))


# --------------------------------------------------------------------------- DB2-14
class DecompileFailureReasonTests(unittest.TestCase):
    def test_reason_of_the_last_call(self):
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(dc, "available", return_value=True):
            with mock.patch.object(dc, "decompile_pair",
                                   side_effect=RuntimeError("Ghidra decompile timed out "
                                                            "after 360s\nmore")):
                self.assertEqual(dc.decompile_cached(b"a", b"b", d)[:2], ("", ""))
            self.assertEqual(dc.last_failure_reason(), "Ghidra decompile timed out after 360s")
            with mock.patch.object(dc, "decompile_pair", return_value=("int a;", "")):
                dc.decompile_cached(b"c", b"d", d)
            self.assertEqual(dc.last_failure_reason(), "no pseudo-C for the fixed side")
            with mock.patch.object(dc, "decompile_pair", return_value=("int a;", "int b;")):
                dc.decompile_cached(b"e", b"f", d)
            self.assertIsNone(dc.last_failure_reason(), "reset by every call")

    def _fake(self, reason):
        def fake(*a, **k):
            dc._LAST_FAILURE = reason
            return "", "", True
        return fake

    def test_db2_records_it_per_function(self):
        rel = "lib/libx.so"
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.dict(os.environ, {"CVE_PATCHDIFF_WORKERS": "1"}), \
                mock.patch.object(d2, "decompile_cached", self._fake("timed out after 360s")), \
                mock.patch.object(X, "fix_signature", return_value=(1, ["guard"])):
            _write(os.path.join(d, "p", rel), _lib([("f", GLOBAL, _mov(1))]))
            _write(os.path.join(d, "f", rel), _lib([("f", GLOBAL, _mov(2))]))
            r = d2.run(os.path.join(d, "p"), os.path.join(d, "f"), os.path.join(d, "w"),
                       stage0={"code_changed": [{"name": rel}]}, decompile=True)
        self.assertEqual(r["decompile_failures"],
                         [{"object": "lib/libx.so :: f", "reason": "timed out after 360s",
                           "rel": rel}])
        self.assertEqual(r["counts"]["decompile_failed"], 1)

    def test_mssql_records_it_per_function(self):
        from patch_differ_cli.mssql import stage2 as ms2
        from patch_differ_cli.tests.test_fallback_and_symbol_reporting import _mssql_run
        real = ms2._process_dll

        def with_decompile(job):
            job.update(decompile=True)
            return real(job)

        with mock.patch.object(ms2, "_process_dll", with_decompile), \
                mock.patch.object(ms2, "decompile_cached", self._fake("no pseudo-C for the "
                                                                      "prior side")), \
                mock.patch.object(X, "fix_signature", return_value=(1, ["guard"])):
            r = _mssql_run(symbolized=("prior", "fixed"))
        self.assertEqual([f["reason"] for f in r["decompile_failures"]],
                         ["no pseudo-C for the prior side"])

    def test_oracle_records_it_per_function(self):
        import patch_differ_cli.oracle.stage2 as os2
        from patch_differ_cli import _attribution as _AT
        P = {"DoRangeCheck": (0x1000, bytes.fromhex("b82a000000c3"))}
        F = {"DoRangeCheck": (0x1000, bytes.fromhex("b8ffffffffc3"))}
        attrib = _AT.build_attrib([("CVE-2024-9999", "a buffer overflow issue", "Engine", "",
                                    "CWE-787")])
        failures = []
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(os2, "_func_map",
                                  lambda path: dict(P if path == "PRIOR" else F)), \
                mock.patch.object(os2, "decompile_cached", self._fake("boom")):
            for sub in ("dc", "c"):
                os.makedirs(os.path.join(d, sub))
            os2._diff_o("a.o", "a.o", "PRIOR", "FIXED", d, [], attrib=attrib, decompile=True,
                        decompile_cache=os.path.join(d, "dc"),
                        decompiled_c_dir=os.path.join(d, "c"), disassembled_dir=d,
                        run_ts="t", decompile_failures=failures)
        self.assertEqual(failures, [{"object": "a.o :: DoRangeCheck", "reason": "boom"}])

    def test_cli_points_at_the_reasons(self):
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            cli._warn_decompile_shortfalls({"stage2": {"counts": {"decompile_failed": 2,
                                                                  "decompile_attempted": 5}}})
        self.assertIn("see decompile_failures", err.getvalue())


# --------------------------------------------------------------------------- DB2-20
_CHATTY_THEN_QUIET = ("import sys, time\n"
                      "for i in range(6):\n"
                      "    print('x' * 100, flush=True); time.sleep(0.3)\n"
                      "time.sleep(2.5)\n")


class HeartbeatTests(unittest.TestCase):
    def test_run_tool_reports_elapsed_output_and_quiet_time(self):
        beats = []
        p = tp.run_tool([sys.executable, "-c", _CHATTY_THEN_QUIET], timeout=60,
                        heartbeat=lambda e, size, idle: beats.append((e, size, idle)))
        self.assertEqual(p.returncode, 0)
        self.assertGreaterEqual(len(beats), 3)
        self.assertEqual([b[0] for b in beats], sorted(b[0] for b in beats))
        self.assertGreater(beats[-1][1], 0, "the output size is seen while it runs")
        self.assertGreater(beats[-1][2], 1.0, "and how long it has been quiet")

    def test_a_failing_heartbeat_does_not_break_the_run(self):
        def boom(*a):
            raise ValueError("bad callback")
        p = tp.run_tool([sys.executable, "-c", "import time; time.sleep(2.2)"], timeout=60,
                        heartbeat=boom)
        self.assertEqual(p.returncode, 0)

    def test_progress_messages(self):
        got = []
        beat = bd._heartbeat(lambda pct, m: got.append((pct, m)), "analysing", "x.so",
                             10 << 20, 5, 55)                  # expected ~1600 s
        beat(0, 0, 0)
        beat(5, 100, 0)                                         # throttled
        beat(800, 4 << 10, 0)
        beat(10 ** 6, 3 << 20, 400)
        self.assertEqual(got[0], (5, "Ghidra: analysing x.so — 0 min, log 0 KiB"))
        self.assertEqual(got[1], (30, "Ghidra: analysing x.so — 13 min, log 4 KiB"))
        self.assertEqual(got[2][0], 52, "never reaches the step's end before it ends")
        self.assertIn("log 3.0 MiB, no output for 6 min", got[2][1])
        self.assertEqual(len(got), 3)
        self.assertIsNone(bd._heartbeat(None, "a", "b", 1, 0, 1))

    def test_binexport_passes_a_heartbeat(self):
        seen = []

        def fake(cmd, **kw):
            seen.append(kw.get("heartbeat"))
            if "-postScript" in cmd:
                out = cmd[cmd.index("-postScript") + 2]
                with open(out, "wb") as fh:
                    fh.write(b"E")
            return type("P", (), {"returncode": 0, "stdout": b""})()

        with tempfile.TemporaryDirectory() as d, contextlib.ExitStack() as st:
            for target, value in (("analyze_headless", "a.bat"),
                                  ("locate_binexport_script", os.path.join(d, "B.java")),
                                  ("clear_stale_ghidra_script_cache", None), ("child_env", {}),
                                  ("binexport_identity", "t"), ("protobuf_conflict", [])):
                st.enter_context(mock.patch.object(bd.tp, target, return_value=value))
            st.enter_context(mock.patch.object(bd, "_run_tool", fake))
            b = _write(os.path.join(d, "x.so"), b"\x7fELF")
            bd.ghidra_binexport(b, os.path.join(d, "proj"), os.path.join(d, "x.BinExport"),
                                progress=lambda *a: None)
        self.assertEqual(len(seen), 2)
        self.assertTrue(all(callable(h) for h in seen))


# --------------------------------------------------------------------------- DB2-24
class ConsoleTests(unittest.TestCase):
    def test_streams_replace_instead_of_raising(self):
        for errors in ("strict", "surrogateescape"):
            buf = io.BytesIO()
            stream = io.TextIOWrapper(buf, encoding="cp1252", errors=errors)
            with mock.patch.object(sys, "stdout", stream), \
                    mock.patch.object(sys, "stderr", io.StringIO()), \
                    mock.patch.dict(os.environ, {}, clear=False):
                cli._safe_console()
                print("a → b")
                stream.flush()
            self.assertEqual(buf.getvalue(), b"a ? b" + os.linesep.encode(), errors)

    def test_tolerant_streams_and_a_users_setting_are_kept(self):
        stream = io.TextIOWrapper(io.BytesIO(), encoding="utf-8", errors="backslashreplace")
        with mock.patch.object(sys, "stdout", stream), \
                mock.patch.dict(os.environ, {"PYTHONIOENCODING": "utf-8"}):
            cli._safe_console()
            self.assertEqual(stream.errors, "backslashreplace")
            self.assertEqual(os.environ["PYTHONIOENCODING"], "utf-8")

    def test_main_does_it_first(self):
        with mock.patch.object(cli, "_safe_console", side_effect=SystemExit(7)) as m:
            with self.assertRaises(SystemExit):
                cli.main(["--help"])
        m.assert_called_once()

    def test_real_child_process_with_a_cp1252_pipe(self):
        env = {k: v for k, v in os.environ.items() if k not in ("PYTHONIOENCODING",
                                                                 "PYTHONUTF8")}
        env.update(PYTHONUTF8="0", PYTHONIOENCODING="cp1252")       # a cp1252 redirect
        code = ("import patch_differ_cli.cli as c; c._safe_console(); "
                "print('lib :: old \\u2192 new')")
        crash = subprocess.run([sys.executable, "-c", "print('lib :: old \\u2192 new')"],
                               env=env, capture_output=True, cwd=ROOT)
        fixed = subprocess.run([sys.executable, "-c", code], env=env, capture_output=True,
                               cwd=ROOT)
        self.assertNotEqual(crash.returncode, 0, "the problem is real without the fix")
        self.assertEqual(fixed.returncode, 0, fixed.stderr)
        self.assertEqual(fixed.stdout.strip(), b"lib :: old ? new")


# --------------------------------------------------------------------------- DB2-26
class StagingCopyNoteTests(unittest.TestCase):
    def test_a_full_copy_is_announced(self):
        with tempfile.TemporaryDirectory() as d:
            src = Path(_write(os.path.join(d, "update_1_v11.5.9_x.tar.gz"), b"z" * 2048))
            err = io.StringIO()
            with contextlib.redirect_stderr(err), \
                    mock.patch.object(pl.os, "link",
                                      side_effect=OSError(18, "Not same device")):
                pl._stage_db2_archive(src, Path(d) / "out", "vuln")
            self.assertTrue((Path(d) / "out" / "acquire" / "vuln" / "drop" / src.name).is_file())
        self.assertIn("NOTE: copying update_1_v11.5.9_x.tar.gz", err.getvalue())
        self.assertIn("Not same device", err.getvalue())

    def test_a_hard_link_is_quiet(self):
        with tempfile.TemporaryDirectory() as d:
            src = Path(_write(os.path.join(d, "fp.tar.gz"), b"z"))
            err = io.StringIO()
            with contextlib.redirect_stderr(err):
                pl._stage_db2_archive(src, Path(d) / "out", "vuln")
        self.assertEqual(err.getvalue(), "")


if __name__ == "__main__":
    unittest.main()
