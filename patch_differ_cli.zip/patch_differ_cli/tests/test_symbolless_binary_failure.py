"""Regression tests for CRIT-NT-9: a binary on triage's code_changed list that yields NO
function symbols (a stripped .so/.o, or a DLL with no usable function table) used to vanish
from Stage 2 entirely — no card, no failed_binaries entry, counts.failed 0 — so the run
looked clean and the CLI exited 0, the exact "looks clean but isn't" case exit code 3 exists
for. Now each backend records it as a failed binary with a reason.

Oracle needs care: run() diffs EVERY common archive member, changed or not, so an empty
function map alone isn't a failure (a data-only member legitimately has none). Oracle flags
it only when the executable sections actually differ, and records it per member so the
archive's other members are still diffed."""
import os
import struct
import tempfile
import unittest

from patch_differ_cli.cli import _summarize_partial_failures
from patch_differ_cli.tests.test_oracle_percall_emit_cap import _build_elf

os.environ.setdefault("CVE_PATCHDIFF_WORKERS", "1")


def _shdr(n, t, flags, a, o, s, link=0):
    return struct.pack("<IIQQQQIIQQ", n, t, flags, a, o, s, link, 0, 1, 0)


def _stripped_elf(code, e_type=3, text_flags=6):
    """.text + .shstrtab only (no .symtab) — what `strip` leaves behind."""
    sh = b"\0.text\0.shstrtab\0"
    to, so = 64, 64 + len(code)
    ho = so + len(sh)
    secs = [_shdr(0, 0, 0, 0, 0, 0), _shdr(1, 1, text_flags, 0x1000, to, len(code)),
            _shdr(7, 3, 0, 0, so, len(sh))]
    e = bytearray(64)
    e[0:4] = b"\x7fELF"
    e[4], e[5], e[6] = 2, 1, 1
    struct.pack_into("<HHI", e, 0x10, e_type, 0x3E, 1)
    struct.pack_into("<Q", e, 0x28, ho)
    struct.pack_into("<HHHH", e, 0x34, 64, 0, 0, 64)
    struct.pack_into("<HH", e, 0x3C, len(secs), 2)
    return bytes(e) + code + sh + b"".join(secs)


OLD, NEW = bytes.fromhex("83f805c3"), bytes.fromhex("83f80a7300e800000000c3")


def _tree(d, rel, prior_blob, fixed_blob):
    p, f = os.path.join(d, "p"), os.path.join(d, "f")
    for root, blob in ((p, prior_blob), (f, fixed_blob)):
        path = os.path.join(root, rel)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as fh:
            fh.write(blob)
    return p, f


class TestDb2(unittest.TestCase):
    def test_stripped_changed_so_is_a_failed_binary(self):
        import patch_differ_cli.db2.stage2 as d2
        with tempfile.TemporaryDirectory(prefix="pdff_nt9_db2_") as d:
            rel = "lib64/libdb2e.so"
            p, f = _tree(d, rel, _stripped_elf(OLD), _stripped_elf(NEW))
            r = d2.run(p, f, d, stage0={"code_changed": [{"name": rel, "kind": "native",
                                                          "size": 100}]})
        self.assertEqual(r["counts"]["failed"], 1)
        self.assertEqual(r["failed_binaries"][0]["rel"], rel)
        self.assertIn("no function symbols on prior and fixed sides",
                      r["failed_binaries"][0]["error"])
        self.assertTrue(_summarize_partial_failures({"stage2": r}))

    def test_one_side_stripped_names_that_side(self):
        import patch_differ_cli.db2.stage2 as d2
        with tempfile.TemporaryDirectory(prefix="pdff_nt9_db2b_") as d:
            rel = "lib64/libdb2e.so"
            p, f = _tree(d, rel, _build_elf([("Fn", 0x1000, len(OLD), OLD)]),
                         _stripped_elf(NEW))
            r = d2.run(p, f, d, stage0={"code_changed": [{"name": rel, "kind": "native",
                                                          "size": 100}]})
        self.assertEqual(r["counts"]["failed"], 1)
        self.assertIn("on fixed side ", r["failed_binaries"][0]["error"])

    def test_symbolized_binary_is_not_flagged(self):
        import patch_differ_cli.db2.stage2 as d2
        with tempfile.TemporaryDirectory(prefix="pdff_nt9_db2c_") as d:
            rel = "lib64/libdb2e.so"
            p, f = _tree(d, rel, _build_elf([("Fn", 0x1000, len(OLD), OLD)]),
                         _build_elf([("Fn", 0x1000, len(NEW), NEW)]))
            r = d2.run(p, f, d, stage0={"code_changed": [{"name": rel, "kind": "native",
                                                          "size": 100}]})
        self.assertEqual(r["counts"]["failed"], 0)
        self.assertEqual(r["counts"]["libs"], 1)


class _FakeSym:
    def __init__(self, *a, **k):
        self.ok = True

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def name_at(self, rva):
        return None


class TestMssql(unittest.TestCase):
    def test_dll_with_no_recovered_functions_is_a_failed_binary(self):
        import patch_differ_cli.mssql.stage2 as ms2
        saved = (ms2._func_map, ms2.sym.fetch_pdb, ms2.sym.Symbolizer, ms2.sym.server_reachable)
        ms2._func_map = lambda path, s: {}
        ms2.sym.fetch_pdb = lambda *a, **k: None
        ms2.sym.Symbolizer = _FakeSym
        ms2.sym.server_reachable = lambda *a, **k: False
        try:
            with tempfile.TemporaryDirectory(prefix="pdff_nt9_ms_") as d:
                p, f = _tree(d, "sqlmin.dll", b"\0", b"\1")
                r = ms2.run(p, f, d, stage0={"code_changed": [{"name": "sqlmin.dll"}]})
        finally:
            (ms2._func_map, ms2.sym.fetch_pdb, ms2.sym.Symbolizer,
             ms2.sym.server_reachable) = saved
        self.assertEqual(r["counts"]["failed"], 1)
        self.assertEqual(r["failed_binaries"][0]["pretty"], ms2._pretty("sqlmin.dll"))
        self.assertIn("no functions recovered", r["failed_binaries"][0]["error"])


class TestOracle(unittest.TestCase):
    def _run(self, rel, prior, fixed, kind="native"):
        import patch_differ_cli.oracle.stage2 as o2
        with tempfile.TemporaryDirectory(prefix="pdff_nt9_ora_") as d:
            p, f = _tree(d, rel, prior, fixed)
            return o2.run(p, f, d, stage0={"code_changed": [{"name": rel, "kind": kind,
                                                             "size": 100}]})

    def test_stripped_changed_object_is_an_error(self):
        r = self._run("lib/kkz.o", _stripped_elf(OLD, e_type=1), _stripped_elf(NEW, e_type=1))
        self.assertEqual(r["counts"]["failed"], 1)
        self.assertTrue(_summarize_partial_failures({"stage2": r}))

    def test_stripped_but_code_unchanged_object_is_not_an_error(self):
        r = self._run("lib/kkz.o", _stripped_elf(OLD, e_type=1), _stripped_elf(OLD, e_type=1))
        self.assertEqual(r["counts"]["failed"], 0)

    def test_text_without_exec_flag_still_counts_as_code(self):
        r = self._run("lib/kkz.o", _stripped_elf(OLD, e_type=1, text_flags=0),
                      _stripped_elf(NEW, e_type=1, text_flags=0))
        self.assertEqual(r["counts"]["failed"], 1)

    def test_archive_member_failure_does_not_stop_other_members(self):
        import patch_differ_cli.oracle.stage2 as o2
        with tempfile.TemporaryDirectory(prefix="pdff_nt9_ar_") as d:
            files = {}
            for side, code in (("p", OLD), ("f", NEW)):
                os.makedirs(os.path.join(d, side + "m"))
                strip_path = os.path.join(d, side + "m", "a_stripped.o")
                good_path = os.path.join(d, side + "m", "b_good.o")
                with open(strip_path, "wb") as fh:
                    fh.write(_stripped_elf(code, e_type=1))
                with open(good_path, "wb") as fh:
                    fh.write(_build_elf([("GoodFn", 0x1000, len(code), code)]))
                files[side] = {"a_stripped.o": strip_path, "b_good.o": good_path}
            p, f = _tree(d, "lib/libserver.a", b"!<arch>\n", b"!<arch>\n")
            saved = o2._ar.extract_o
            o2._ar.extract_o = lambda path, dest: files["p" if os.sep + "p" + os.sep in path else "f"]
            try:
                r = o2.run(p, f, d, stage0={"code_changed": [
                    {"name": "lib/libserver.a", "kind": "archive", "size": 100}]})
            finally:
                o2._ar.extract_o = saved
        errs = [b for b in r["binaries"] if b["verdict"] == "error"]
        self.assertEqual(len(errs), 1)
        self.assertTrue(errs[0]["object"].endswith("!a_stripped.o"))
        self.assertTrue(any(c["object"].endswith(":: GoodFn") for c in r["readable_files"]),
                        "the archive's other member must still be diffed")


if __name__ == "__main__":
    unittest.main()
