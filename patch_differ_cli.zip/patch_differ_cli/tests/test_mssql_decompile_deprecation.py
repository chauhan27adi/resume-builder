"""Regression tests for bug.md MSSQL-T2-1 / MSSQL-T2-2.

MSSQL-T2-1: `mssql/decompile.py` is a dead, on-demand single-function decompiler that no
production code path reaches (the pipeline only loads `mssql.{triage,stage1,stage2}`, which
decompile through the shared `_decompile.decompile_cached_per_side`). It is kept only for
reference, carries a SUPERSEDED banner, and must never be wired back into a production module
by accident (where its raise-on-failure / separate-cache divergences would bite).

MSSQL-T2-2: `db2/ghidra/DecompileFunc.java` is the SHARED Track-2 Ghidra script (MSSQL depends
on it); its header must describe the backend-neutral `_decompile.py` driver and all three
backends, not claim it is DB2-only / invoked by the dead `db2/decompile.py`.

Pure source/metadata assertions — no Ghidra, network, or subprocess."""
import os
import re
import unittest

import patch_differ_cli._decompile as D
import patch_differ_cli.cli as cli
import patch_differ_cli.mssql.decompile as mdec
import patch_differ_cli.mssql.stage1 as m1
import patch_differ_cli.mssql.stage2 as m2
import patch_differ_cli.mssql.triage as mtri
import patch_differ_cli.pipeline as pl


def _src(mod):
    with open(mod.__file__, encoding="utf-8") as fh:
        return fh.read()


# An import that would wire the dead `mssql/decompile.py` submodule back in. Crafted NOT to
# match the legitimate, shared `from .._decompile import ...` (that is `.._decompile`, a
# different module): `\bmssql\.decompile\b` and a bare `decompile` submodule have a word
# boundary the underscored `_decompile` never does.
_FORBIDDEN = [
    re.compile(r"\bmssql\.decompile\b"),              # patch_differ_cli.mssql.decompile
    re.compile(r"from\s+\.\s*decompile\s+import\b"),  # from .decompile import ...
    re.compile(r"from\s+\.\s+import\s+[^#\n]*\bdecompile\b"),  # from . import decompile
]
# The modules the pipeline actually loads for an MSSQL run, plus the entry points.
_PRODUCTION = [pl, cli, mtri, m1, m2]


class MssqlDecompileIsDeadCode(unittest.TestCase):
    def test_banner_marks_module_superseded_and_points_at_the_shared_engine(self):
        doc = mdec.__doc__ or ""
        self.assertIn("DEPRECATED", doc)
        self.assertIn("MSSQL-T2-1", doc)
        self.assertIn("_decompile", doc, "banner must point callers at the shared engine")

    def test_no_production_module_wires_the_dead_submodule(self):
        # Guards MSSQL-T2-1's core risk: if something imports it by mistake it runs a second,
        # divergent decompile path. The shared `from .._decompile import ...` is allowed.
        for mod in _PRODUCTION:
            src = _src(mod)
            for pat in _FORBIDDEN:
                self.assertIsNone(
                    pat.search(src),
                    f"{os.path.basename(mod.__file__)} wires in the dead mssql.decompile "
                    f"(matched {pat.pattern!r}) — use .._decompile instead (MSSQL-T2-1)")

    def test_the_shared_engine_import_is_not_falsely_flagged(self):
        # Sanity: the real Stage-2 import line must still be present AND must not trip the
        # forbidden patterns, or the guard above would be worthless.
        src = _src(m2)
        self.assertIn("from .._decompile import decompile_cached_per_side", src)
        for pat in _FORBIDDEN:
            self.assertIsNone(pat.search(src))


class DecompileFuncJavaHeaderIsShared(unittest.TestCase):
    def _header(self):
        path = os.path.join(D._SCRIPT_DIR, "DecompileFunc.java")
        with open(path, encoding="utf-8") as fh:
            text = fh.read()
        # the leading comment block, up to the first import
        return text.split("\nimport ", 1)[0]

    def test_header_describes_the_shared_driver_not_db2_only(self):
        head = self._header()
        self.assertIn("_decompile", head, "must name the backend-neutral driver")
        self.assertIn("MSSQL", head, "must say MSSQL (and the other backends) use it")
        self.assertIn("_extract_func_bytes", head, "must point at MSSQL's PE carve")

    def test_header_no_longer_claims_db2_decompile_invokes_it(self):
        head = self._header()
        self.assertNotIn("Invoked by db2/decompile.py", head)
        self.assertNotIn("carved by db2/decompile.py", head)


if __name__ == "__main__":
    unittest.main()
