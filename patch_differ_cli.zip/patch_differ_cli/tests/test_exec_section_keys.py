"""Regression tests for bugs.md #13: Stage 0's executable-section hashes were keyed by
section NAME only (mssql/triage._code_sig, db2/_elf.exec_section_sigs), so with two exec
sections of the same name the later one overwrote the earlier hash and a code change
confined to the first was missed. Keys are now name + occurrence — deliberately not section
index, which would shift whenever an unrelated section is added and fake a code change.

Also covers the related issue found while fixing it: exec_section_sigs() hashed a TRUNCATED
section's partial bytes without complaint (and returned None — "not an ELF" — for other
corrupt ELFs), so a damaged library was misclassified instead of reported."""
import os
import struct
import tempfile
import unittest
from unittest import mock

from patch_differ_cli.db2 import _elf
import patch_differ_cli.db2.triage as dtri
from patch_differ_cli.mssql import triage as mtri


def _elf_with(sections, truncate=0):
    """sections: [(name, sh_type, sh_flags, data)] -> ELF64 LE bytes."""
    names = b"\0" + b"".join(n.encode() + b"\0" for n, *_ in sections) + b".shstrtab\0"
    offs, pos, body = [], 64, b""
    for _n, _t, _f, data in sections:
        offs.append(pos)
        body += data
        pos += len(data)
    str_off = pos
    body += names
    shoff = str_off + len(names)
    sh = [bytes(64)]
    noff = 1
    for (n, t, fl, data), off in zip(sections, offs):
        sh.append(struct.pack("<IIQQQQIIQQ", noff, t, fl, 0, off, len(data), 0, 0, 1, 0))
        noff += len(n) + 1
    sh.append(struct.pack("<IIQQQQIIQQ", noff, 3, 0, 0, str_off, len(names), 0, 0, 1, 0))
    e = bytearray(64)
    e[0:4] = b"\x7fELF"
    e[4], e[5], e[6] = 2, 1, 1
    struct.pack_into("<HHI", e, 0x10, 3, 0x3E, 1)
    struct.pack_into("<Q", e, 0x28, shoff)
    struct.pack_into("<HHHHHH", e, 0x34, 64, 0, 0, 64, len(sh), len(sh) - 1)
    blob = bytes(e) + body + b"".join(sh)
    return blob


AX, PROGBITS = 6, 1


def _truncate_first_section(blob):
    """Claim section 1 is far bigger than the file (sh_size of header 1, at e_shoff)."""
    b = bytearray(blob)
    shoff = struct.unpack_from("<Q", b, 0x28)[0]
    struct.pack_into("<Q", b, shoff + 64 * 1 + 32, 10_000)
    return bytes(b)


class TestElfKeys(unittest.TestCase):
    def _sigs(self, blob):
        with tempfile.TemporaryDirectory(prefix="pdff_elf13_") as d:
            p = os.path.join(d, "x.so")
            with open(p, "wb") as fh:
                fh.write(blob)
            return _elf.exec_section_sigs(p)

    def test_change_in_first_of_two_same_named_sections_is_seen(self):
        a = self._sigs(_elf_with([(".text", PROGBITS, AX, b"AAAA"), (".text", PROGBITS, AX, b"ZZ")]))
        b = self._sigs(_elf_with([(".text", PROGBITS, AX, b"BBBB"), (".text", PROGBITS, AX, b"ZZ")]))
        self.assertNotEqual(a, b)
        self.assertEqual(set(a), {".text", ".text#2"})

    def test_added_non_code_section_does_not_fake_a_code_change(self):
        a = self._sigs(_elf_with([(".text", PROGBITS, AX, b"CODE")]))
        b = self._sigs(_elf_with([(".comment", PROGBITS, 0, b"gcc"), (".text", PROGBITS, AX, b"CODE")]))
        self.assertEqual(a, b)

    def test_truncated_section_raises(self):
        blob = _truncate_first_section(_elf_with([(".text", PROGBITS, AX, b"CODE")]))
        with self.assertRaises(_elf.ElfParseError):
            self._sigs(blob)

    def test_non_elf_still_returns_none(self):
        self.assertIsNone(self._sigs(b"just text"))


class TestDb2TriageReportsBrokenElf(unittest.TestCase):
    def test_truncated_library_is_a_triage_error(self):
        good = _elf_with([(".text", PROGBITS, AX, b"CODE")])
        bad = _truncate_first_section(good)
        with tempfile.TemporaryDirectory(prefix="pdff_elf13t_") as d:
            p, f = os.path.join(d, "p", "lib64"), os.path.join(d, "f", "lib64")
            os.makedirs(p)
            os.makedirs(f)
            open(os.path.join(p, "libdb2e.so"), "wb").write(good)
            open(os.path.join(f, "libdb2e.so"), "wb").write(bad)
            r = dtri.run(os.path.dirname(p), os.path.dirname(f), d)
        self.assertEqual(r["counts"]["errors"], 1)
        self.assertEqual(r["counts"]["code_changed"] + r["counts"]["content_changed"], 0)


class _Sec:
    def __init__(self, name, data, exec_=True, ptr=0):
        self.Name = name.encode().ljust(8, b"\0")
        self.Characteristics = 0x20000000 if exec_ else 0
        self._data = data
        self.SizeOfRawData = len(data)
        self.PointerToRawData = ptr

    def get_data(self):
        return self._data


class _FakePE:
    def __init__(self, sections):
        self.sections = sections
        self.__data__ = b"\0" * 4096

    def close(self):
        pass


class TestPeKeys(unittest.TestCase):
    def _sig(self, sections):
        with tempfile.TemporaryDirectory(prefix="pdff_pe13_") as d:
            p = os.path.join(d, "x.dll")
            open(p, "wb").write(b"MZ" + b"\0" * 100)
            with mock.patch.object(mtri.pefile, "PE", lambda *a, **k: _FakePE(sections)):
                return mtri._code_sig(p)

    def test_change_in_first_of_two_same_named_sections_is_seen(self):
        a = self._sig([_Sec(".text", b"AAAA"), _Sec(".text", b"ZZ")])
        b = self._sig([_Sec(".text", b"BBBB"), _Sec(".text", b"ZZ")])
        self.assertNotEqual(a, b)

    def test_added_non_code_section_does_not_fake_a_code_change(self):
        a = self._sig([_Sec(".text", b"CODE")])
        b = self._sig([_Sec(".rsrc", b"r", exec_=False), _Sec(".text", b"CODE")])
        self.assertEqual(a, b)


if __name__ == "__main__":
    unittest.main()
