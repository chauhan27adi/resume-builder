"""Regression tests for bugs.md #3, Stage 1 (readable) side: added/removed readable files got
no detailed diff.
  * MSSQL Stage 1 compared loose readable files, embedded T-SQL in script DLLs, and resource-DB
    system objects only where they existed on BOTH sides (added/removed objects were listed
    by name only, with no definition).
  * Oracle Stage 1 never saw removed readable files (triage listed them only in a capped,
    display-only list), and its 800-card cap applied in FILE order — every readable change
    past the 800th was dropped silently, fix-shaped / CVE-matched ones included.
Drives the real run() functions; only the resource-DB carving (MSSQL) and the decompiler
(Oracle jars) are mocked."""
import json
import os
import tempfile
import unittest
import zipfile
from unittest import mock

import patch_differ_cli.mssql.stage1 as ms1
import patch_differ_cli.oracle.stage1 as os1
import patch_differ_cli.oracle.triage as otri
from patch_differ_cli.oracle import java_decompile as jd


def _w(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data if isinstance(data, bytes) else data.encode())


class _Dirs(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory(prefix="pdff_s1os_")
        self.d = self._td.name
        self.p, self.f = os.path.join(self.d, "p"), os.path.join(self.d, "f")
        os.makedirs(self.p)
        os.makedirs(self.f)

    def tearDown(self):
        self._td.cleanup()

    def _pair(self, card):
        with open(os.path.join(self.d, "stage1", card["pair"]), encoding="utf-8") as fh:
            return json.load(fh)


class TestMssqlStage1(_Dirs):
    def _run(self, A=None, B=None):
        A = A if A is not None else {"sys.sp_same": ("CREATE PROC sys.sp_same AS 1", False)}
        B = B if B is not None else dict(A)
        with mock.patch.object(ms1, "_find_resource_mdf", lambda d: os.path.join(d, "mdf")), \
                mock.patch.object(ms1, "_carve", lambda p: A if os.sep + "p" + os.sep in p else B), \
                mock.patch.object(ms1._AT, "load_attrib", lambda wd: []):
            return ms1.run(self.p, self.f, self.d)

    def test_added_and_removed_loose_files_get_diffs(self):
        _w(os.path.join(self.f, "MPT_new_hardening_sql_64"), "DENY EXECUTE ON x TO public;\n")
        _w(os.path.join(self.p, "MPT_old_insecure_sql_64"), "GRANT EXECUTE ON x TO public;\n")
        _w(os.path.join(self.p, "MPT_same_sql_64"), "SELECT 1;\n")
        _w(os.path.join(self.f, "MPT_same_sql_64"), "SELECT 1;\n")
        r = self._run()
        got = {c["src"]: c["change"] for c in r["readable_files"]}
        self.assertEqual(got, {"MPT_new_hardening_sql_64": "added",
                               "MPT_old_insecure_sql_64": "removed"})
        added = next(c for c in r["readable_files"] if c["change"] == "added")
        self.assertEqual(self._pair(added)["prior"], "")
        self.assertIn("DENY EXECUTE", self._pair(added)["fixed"])

    def test_case_only_difference_is_a_modification_on_windows(self):
        if os.name != "nt":
            self.skipTest("case-insensitive pairing is Windows-only")
        _w(os.path.join(self.p, "MPT_msdb_upgrade_sql_64"), "SELECT 1;\n")
        _w(os.path.join(self.f, "MPT_MSDB_UPGRADE_sql_64"), "SELECT 2;\n")
        r = self._run()
        self.assertEqual([c["change"] for c in r["readable_files"]], ["modified"])

    def test_added_and_removed_system_objects_get_definitions(self):
        A = {"sys.sp_keep": ("CREATE PROC sys.sp_keep AS 1", False),
             "sys.sp_gone": ("CREATE PROC sys.sp_gone AS RAISERROR", False)}
        B = {"sys.sp_keep": ("CREATE PROC sys.sp_keep AS 1", False),
             "sys.sp_new_check": ("CREATE PROC sys.sp_new_check AS IF IS_SRVROLEMEMBER", False)}
        r = self._run(A, B)
        self.assertEqual((r["added"], r["removed"]), (["sys.sp_new_check"], ["sys.sp_gone"]))
        files = {f["object"]: f for f in r["files"]}
        self.assertEqual(files["sys.sp_new_check"]["change"], "added")
        self.assertIn("IS_SRVROLEMEMBER", self._pair(files["sys.sp_new_check"])["fixed"])
        self.assertEqual(files["sys.sp_gone"]["change"], "removed")
        self.assertEqual(self._pair(files["sys.sp_gone"])["fixed"], "")

    def test_added_script_dll_embedded_tsql_is_shown(self):
        sql = b"EXEC(@cmd) -- SELECT name FROM sys.objects WHERE QUOTENAME(name) IS NOT NULL"
        _w(os.path.join(self.f, "ENG_RE_sqlscriptupgrade_new_dll_64"), b"MZ" + b"\x00" * 64 + sql)
        r = self._run()
        cards = [c for c in r["readable_files"] if c.get("kind") == "tsql"]
        self.assertEqual(len(cards), 1)
        self.assertIn("QUOTENAME", self._pair(cards[0])["fixed"])


class TestOracleStage1(_Dirs):
    def test_removed_readable_file_is_diffed(self):
        _w(os.path.join(self.p, "rdbms", "admin", "prvtold.sql"), "GRANT EXECUTE ON pkg TO PUBLIC;\n")
        r = os1.run(self.p, self.f, self.d, stage0={"content_removed": [
            {"name": "rdbms/admin/prvtold.sql", "route": "stage1", "kind": "sql",
             "change": "removed"}]})
        (c,) = r["readable_files"]
        self.assertEqual(c["change"], "removed")
        self.assertIn("GRANT EXECUTE", self._pair(c)["prior"])
        self.assertEqual(self._pair(c)["fixed"], "")

    def test_removed_jar_decompiles_prior_side_only(self):
        jar = os.path.join(self.p, "javavm", "lib", "old.jar")
        os.makedirs(os.path.dirname(jar))
        with zipfile.ZipFile(jar, "w") as zf:
            zf.writestr("x/Old.class", b"cafe")
        sides = []

        def decompile(jar_path, out_dir, progress=None):
            sides.append("p" if os.sep + "p" + os.sep in jar_path else "f")
            dst = os.path.join(out_dir, "x", "Old.java")
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            with open(dst, "w") as fh:
                fh.write("class Old { void unsafe() {} }\n")
            return 1
        with mock.patch.object(jd, "decompile_jar", decompile):
            r = os1.run(self.p, self.f, self.d, stage0={"content_removed": [
                {"name": "javavm/lib/old.jar", "route": "stage1", "kind": "jar",
                 "change": "removed"}]})
        self.assertEqual(sides, ["p"])
        (c,) = r["readable_files"]
        self.assertEqual(c["change"], "removed")
        self.assertIn("unsafe", self._pair(c)["prior"])

    def test_triage_to_stage1_end_to_end(self):
        _w(os.path.join(self.p, "rdbms", "admin", "prvtold.sql"), "SELECT 1;\n")
        s0 = otri.run(self.p, self.f, self.d)
        self.assertEqual([e["name"] for e in s0["content_removed"]], ["rdbms/admin/prvtold.sql"])
        r = os1.run(self.p, self.f, self.d, stage0=s0)
        self.assertEqual([c["change"] for c in r["readable_files"]], ["removed"])

    def test_cap_ranks_before_truncating_and_reports_drops(self):
        entries = []
        for i in range(os1._EMIT_CAP + 20):
            rel = f"rdbms/admin/f{i:04d}.sql"
            _w(os.path.join(self.p, rel), f"SELECT {i};\n")
            _w(os.path.join(self.f, rel), f"SELECT {i} + 1;\n")
            entries.append({"name": rel, "route": "stage1", "kind": "sql"})
        # the fix-shaped change comes LAST in file order — it used to be the one dropped
        rel = "rdbms/admin/zzz_fix.sql"
        _w(os.path.join(self.p, rel), "BEGIN\n  do_work(p);\nEND;\n")
        _w(os.path.join(self.f, rel), "BEGIN\n  IF p IS NULL THEN\n    RAISE_APPLICATION_ERROR(-20001, 'x');\n"
                                      "  END IF;\n  do_work(p);\nEND;\n")
        entries.append({"name": rel, "route": "stage1", "kind": "sql"})
        r = os1.run(self.p, self.f, self.d, stage0={"content_changed": entries})
        objs = [c["object"] for c in r["readable_files"]]
        fixcard = next((c for c in r["readable_files"] if c["object"] == rel), None)
        self.assertIsNotNone(fixcard, "a fix-shaped change must survive the cap")
        self.assertGreater(fixcard["fix_score"], 0)
        # priority-first: the fix card + (cap - 1) plain cards; the other 21 plain are dropped
        self.assertEqual(len(objs), os1._EMIT_CAP)
        self.assertEqual(r["counts"]["readable_truncated"], 21)
        on_disk = {f for f in os.listdir(os.path.join(self.d, "stage1")) if f.endswith(".pair.json")}
        self.assertEqual(on_disk, {c["pair"] for c in r["readable_files"]},
                         "dropped cards' files are removed")


if __name__ == "__main__":
    unittest.main()
