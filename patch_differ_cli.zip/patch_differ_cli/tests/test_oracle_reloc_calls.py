"""Regression tests for bug.md ORA-T2-1 / ORA-T2-2.

Oracle's `.o` inputs are ET_REL (unlinked): every inter-unit call's target lives in a
.rela.text* relocation, not in the instruction bytes. So the Track-2 pseudo-C never showed a
changed callee (ORA-T2-1) and the fix-shaped signal (`added_intr`) could not see an added
hardening call (ORA-T2-2). oracle/stage2.py now parses .rela.text* into `fm.calls` and uses it
(a) to annotate each side's pseudo-C with its relocated function refs and (b) to feed
`_added_security_intrinsics`. These tests build byte-exact ET_REL objects WITH relocations.

No Ghidra/toolchain: `decompile_cached` is faked for the end-to-end test; the rest is pure."""
import glob
import json
import os
import struct
import tempfile
import unittest
from unittest import mock

import patch_differ_cli.oracle.stage2 as o2
from patch_differ_cli import _x86diff as X


# --- byte-exact ET_REL (.o) builder with a .rela.text ---------------------------------------
# Section order: 0 null, 1 .text, 2 .rela.text, 3 .symtab, 4 .strtab, 5 .shstrtab.
_R_X86_64_PLT32 = 4
_SHSTR = b"\0.text\0.rela.text\0.symtab\0.strtab\0.shstrtab\0"
_O = {".text": 1, ".rela.text": 7, ".symtab": 18, ".strtab": 26, ".shstrtab": 34}


def _rel_o(funcs):
    """funcs: [(name, code, [callee_name, ...])], laid out back-to-back in one .text at base 0.
    Each callee becomes an UNDEF STT_FUNC symbol and a R_X86_64_PLT32 reloc inside the caller."""
    text, offs = b"", {}
    for name, code, _callees in funcs:
        offs[name] = len(text)
        text += code

    names = [n for n, *_ in funcs]
    callees = sorted({c for _n, _c, cs in funcs for c in cs})
    strtab, pos, name_off = b"\0", 1, {}
    for n in names + callees:
        name_off[n] = pos
        strtab += n.encode() + b"\0"
        pos += len(n) + 1

    sym = lambda no, shndx, val, sz: struct.pack("<IBBHQQ", no, 0x12, 0, shndx, val, sz)
    symtab = bytes(24)                                   # index 0: null
    idx, sym_idx = 1, {}
    for name, code, _cs in funcs:                        # defined funcs -> shndx 1 (.text)
        symtab += sym(name_off[name], 1, offs[name], len(code)); idx += 1
    for c in callees:                                    # undef callees -> shndx 0 (SHN_UNDEF)
        sym_idx[c] = idx
        symtab += sym(name_off[c], 0, 0, 0); idx += 1

    rela = b""
    for name, code, cs in funcs:
        for j, c in enumerate(cs):
            r_off = offs[name] + min(1 + j, max(len(code) - 1, 0))   # inside [off, off+size)
            r_info = (sym_idx[c] << 32) | _R_X86_64_PLT32
            rela += struct.pack("<QQq", r_off, r_info, -4)

    HDR = 64
    text_off = HDR
    rela_off = text_off + len(text)
    sym_off = rela_off + len(rela)
    str_off = sym_off + len(symtab)
    shstr_off = str_off + len(strtab)
    shoff = shstr_off + len(_SHSTR)
    sh = lambda n, t, fl, off, sz, link=0, info=0, ent=0: struct.pack(
        "<IIQQQQIIQQ", n, t, fl, 0, off, sz, link, info, 1, ent)
    secs = [
        bytes(64),
        sh(_O[".text"], 1, 6, text_off, len(text)),
        sh(_O[".rela.text"], 4, 0, rela_off, len(rela), link=3, info=1, ent=24),
        sh(_O[".symtab"], 2, 0, sym_off, len(symtab), link=4, info=1, ent=24),
        sh(_O[".strtab"], 3, 0, str_off, len(strtab)),
        sh(_O[".shstrtab"], 3, 0, shstr_off, len(_SHSTR)),
    ]
    e = bytearray(64)
    e[0:4] = b"\x7fELF"
    e[4], e[5], e[6] = 2, 1, 1
    struct.pack_into("<HHI", e, 0x10, 1, 0x3E, 1)        # ET_REL, x86-64
    struct.pack_into("<Q", e, 0x28, shoff)
    struct.pack_into("<HHHHHH", e, 0x34, 64, 0, 0, 64, len(secs), 5)
    return bytes(e) + text + rela + symtab + strtab + _SHSTR + b"".join(secs)


def _write(d, name, data):
    p = os.path.join(d, name)
    with open(p, "wb") as fh:
        fh.write(data)
    return p


class RelocCallParse(unittest.TestCase):
    def test_fm_calls_lists_relocated_callees_keyed_like_fm(self):
        with tempfile.TemporaryDirectory(prefix="pdff_rc_") as d:
            p = _write(d, "k.o", _rel_o([("foo", b"\x31\xc0\xc3", ["__stack_chk_fail", "memcpy"]),
                                         ("bar", b"\x90\xc3", [])]))
            fm = o2._func_map(p)
            self.assertEqual(fm["foo"][1], b"\x31\xc0\xc3")
            self.assertEqual(fm.calls["foo"], ["__stack_chk_fail", "memcpy"])
            self.assertEqual(fm.calls["bar"], [])                 # no relocs -> empty, not missing
            self.assertEqual(set(fm.calls), set(fm), "fm.calls is keyed exactly like fm")

    def test_object_without_relocations_degrades_to_empty_calls(self):
        with tempfile.TemporaryDirectory(prefix="pdff_rc2_") as d:
            p = _write(d, "n.o", _rel_o([("foo", b"\x31\xc0\xc3", [])]))
            fm = o2._func_map(p)
            self.assertEqual(fm.calls["foo"], [])

    def test_reloc_parse_failure_leaves_core_map_intact(self):
        with tempfile.TemporaryDirectory(prefix="pdff_rc3_") as d:
            p = _write(d, "k.o", _rel_o([("foo", b"\x31\xc0\xc3", ["__stack_chk_fail"])]))
            with mock.patch.object(o2, "_reloc_func_refs_by_shndx", side_effect=ValueError("x")):
                fm = o2._func_map(p)
            self.assertEqual(fm["foo"][1], b"\x31\xc0\xc3")       # functions still parsed
            self.assertEqual(fm.calls, {})                        # calls degrade to empty


class HelperUnits(unittest.TestCase):
    def test_reloc_refs_note_prepends_only_when_both_present(self):
        self.assertEqual(o2._reloc_refs_note([], "int a;"), "int a;")
        self.assertEqual(o2._reloc_refs_note(["memcpy"], ""), "")
        noted = o2._reloc_refs_note(["__stack_chk_fail"], "int a;\n")
        self.assertIn("relocated function refs (1)", noted)
        self.assertIn("__stack_chk_fail", noted)
        self.assertTrue(noted.endswith("int a;\n"))

    def test_added_security_intrinsics_sees_reloc_added_callee(self):
        # name_at None -> call_targets returns [] (no baked-in targets), so ONLY the relocation
        # source contributes: the added hardening call is detected, a plain call is ignored.
        got = o2._added_security_intrinsics(
            None, 0, b"", 0, b"", None, None,
            prior_refs=["kkziop"], fixed_refs=["kkziop", "__stack_chk_fail", "plain_helper"])
        self.assertEqual(got, ["__stack_chk_fail"])

    def test_added_security_intrinsics_empty_when_nothing_added(self):
        got = o2._added_security_intrinsics(None, 0, b"", 0, b"", None, None,
                                            ["__stack_chk_fail"], ["__stack_chk_fail"])
        self.assertEqual(got, [])


class EndToEnd(unittest.TestCase):
    """Drive the real _diff_o: a fix adds a `call __stack_chk_fail` (a new reloc) to `foo`."""

    def _run(self):
        prior = _rel_o([("foo", b"\x31\xc0\xc3", [])])                         # xor eax,eax; ret
        fixed = _rel_o([("foo", b"\x31\xc0\xe8\x00\x00\x00\x00\xc3",           # + call rel32
                         ["__stack_chk_fail"])])
        with tempfile.TemporaryDirectory(prefix="pdff_rc_e2e_") as d:
            pa, fa = _write(d, "p.o", prior), _write(d, "f.o", fixed)
            out = os.path.join(d, "out"); os.makedirs(out)
            cache = os.path.join(d, "cache"); os.makedirs(cache)
            dc = os.path.join(d, "dc"); os.makedirs(dc)
            readable = []
            with mock.patch.object(o2, "decompile_cached",
                                   lambda pb, fb, cdir: ("int prior_body;\n", "int fixed_body;\n",
                                                         True)):
                o2._diff_o("kkz.o", "kkz.o", pa, fa, out, readable, attrib=[],
                           decompile=True, decompile_cache=cache, decompiled_c_dir=dc)
            detail = glob.glob(os.path.join(out, "*.detail.json"))
            data = {}
            if detail:
                with open(detail[0], encoding="utf-8") as fh:
                    data = json.loads(fh.read())
            return readable, data

    def test_added_reloc_intrinsic_makes_the_fix_shaped_and_annotates_the_c(self):
        readable, data = self._run()
        cards = [r for r in readable if r["object"].endswith(":: foo")]
        self.assertEqual(len(cards), 1)
        card = cards[0]
        # ORA-T2-2: the relocation-only added __stack_chk_fail is now a fix signal
        self.assertTrue(card["intrinsic"], "added hardening call via relocation detected")
        self.assertGreater(card["fix_score"], 0)
        # ORA-T2-1: the changed callee set is visible in the pseudo-C — fixed names the callee,
        # prior does not, so the before/after diff shows it.
        self.assertIn("__stack_chk_fail", data["fixed_c"])
        self.assertNotIn("__stack_chk_fail", data["prior_c"])
        self.assertIn("relocated function refs", data["fixed_c"])
        self.assertTrue(data["fixed_c"].endswith("int fixed_body;\n"))


if __name__ == "__main__":
    unittest.main()
