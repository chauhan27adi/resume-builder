"""Unit tests for cli.py's partial-failure detection and exit-code contract.

This covers the gap flagged in review: none of the project's other tests touch
"errors" / "failed_binaries" / "counts.failed" / "available" at all, even though those
fields exist specifically so a caller can tell a verified-empty result apart from an
incomplete one. _summarize_partial_failures() is the single place that distinction is
computed for the CLI layer, so it is the right place to lock the behavior down."""
import contextlib
import io
import json
import os
import sys
import tempfile
import unittest
from unittest import mock

from patch_differ_cli import cli


class TestSummarizePartialFailures(unittest.TestCase):
    def test_empty_or_none_results_report_nothing(self):
        self.assertEqual(cli._summarize_partial_failures(None), [])
        self.assertEqual(cli._summarize_partial_failures({}), [])

    def test_clean_result_reports_nothing(self):
        results = {
            "triage": {"counts": {"code_changed": 1, "errors": 0}},
            "stage1": {"available": True, "counts": {"errors": 0}},
            "stage2": {"available": True, "counts": {"failed": 0}},
        }
        self.assertEqual(cli._summarize_partial_failures(results), [])

    def test_nonzero_errors_is_detected(self):
        results = {"triage": {"counts": {"errors": 2}}}
        problems = cli._summarize_partial_failures(results)
        self.assertEqual(problems, [("triage", "file(s) could not be analyzed", 2)])

    def test_nonzero_failed_is_detected(self):
        results = {"stage2": {"counts": {"failed": 1}}}
        problems = cli._summarize_partial_failures(results)
        self.assertEqual(problems, [("stage2", "binary(ies) could not be analyzed", 1)])

    def test_available_false_is_detected_even_with_empty_counts(self):
        # A whole-stage-unavailable result (the shape older mssql/stage1.py versions saved
        # when the resource DB was missing — still read back by `show`): readable_files is
        # empty and counts is {} — indistinguishable from a verified empty result unless
        # "available" itself is checked.
        results = {"stage1": {"available": False, "reason": "resource DB not in payload",
                              "counts": {}}}
        problems = cli._summarize_partial_failures(results)
        self.assertEqual(len(problems), 1)
        stage, label, n = problems[0]
        self.assertEqual(stage, "stage1")
        self.assertIn("unavailable", label)
        self.assertIn("resource DB not in payload", label)
        self.assertEqual(n, 1)

    def test_available_false_without_a_reason_does_not_crash(self):
        results = {"stage1": {"available": False}}
        problems = cli._summarize_partial_failures(results)
        self.assertEqual(len(problems), 1)
        self.assertIn("no reason given", problems[0][1])

    def test_available_true_is_never_flagged(self):
        results = {"stage1": {"available": True, "counts": {}}}
        self.assertEqual(cli._summarize_partial_failures(results), [])

    def test_available_false_and_errors_are_both_reported_independently(self):
        results = {"stage1": {"available": False, "reason": "x", "counts": {"errors": 1}}}
        problems = cli._summarize_partial_failures(results)
        self.assertEqual(len(problems), 2)
        labels = [p[1] for p in problems]
        self.assertTrue(any("unavailable" in l for l in labels))
        self.assertTrue(any("could not be analyzed" in l for l in labels))

    def test_missing_counts_key_entirely_does_not_crash(self):
        # A pre-fix persisted functions_diff.json from before "errors"/"failed" existed.
        results = {"stage2": {"readable_files": []}}
        self.assertEqual(cli._summarize_partial_failures(results), [])

    def test_none_stage_data_does_not_crash(self):
        results = {"stage1": None}
        self.assertEqual(cli._summarize_partial_failures(results), [])


class TestExitCodes(unittest.TestCase):
    """Exercise cli.main() end-to-end (argument parsing through to sys.exit), with
    pipeline.run_pipeline() monkeypatched so no real analysis runs."""

    def _run(self, argv):
        out_buf, err_buf = io.StringIO(), io.StringIO()
        code = 0
        with contextlib.redirect_stdout(out_buf), contextlib.redirect_stderr(err_buf):
            try:
                cli.main(argv)
            except SystemExit as e:
                code = e.code or 0
        return code, out_buf.getvalue(), err_buf.getvalue()

    def test_argparse_usage_errors_exit_2_not_the_partial_failure_code(self):
        # Missing required --db, invalid --db choice, and an unknown subcommand all go
        # through argparse itself and must stay on exit 2 — distinct from
        # _EXIT_PARTIAL_FAILURE (3), which means "it ran, but incompletely".
        for argv in (["run"], ["run", "--db", "postgres"], ["bogus-subcommand"]):
            code, _out, _err = self._run(argv)
            self.assertEqual(code, 2, f"{argv} should be an argparse usage error (exit 2)")

    def test_clean_run_exits_0_with_no_warning(self):
        clean = {
            "triage": {"counts": {"errors": 0}},
            "stage1": {"available": True, "counts": {"errors": 0}},
            "stage2": {"available": True, "counts": {"failed": 0}},
        }
        with tempfile.TemporaryDirectory() as d:
            with mock.patch("patch_differ_cli.pipeline.run_pipeline", return_value=clean):
                code, _out, err = self._run(
                    ["run", "--db", "mssql", "--vuln", d, "--fixed", d, "--out", d, "--quiet"])
        self.assertEqual(code, 0)
        self.assertEqual(err, "")

    def test_errors_or_failed_counts_exit_partial_failure_code(self):
        partial = {
            "triage": {"counts": {"errors": 2}},
            "stage1": {"available": True, "counts": {"errors": 0}},
            "stage2": {"available": True, "counts": {"failed": 1}},
        }
        with tempfile.TemporaryDirectory() as d:
            with mock.patch("patch_differ_cli.pipeline.run_pipeline", return_value=partial):
                code, _out, err = self._run(
                    ["run", "--db", "mssql", "--vuln", d, "--fixed", d, "--out", d, "--quiet"])
        self.assertEqual(code, cli._EXIT_PARTIAL_FAILURE)
        self.assertIn("WARNING", err)

    def test_available_false_also_exits_partial_failure_code(self):
        # The regression this fix closes: a stage reporting itself unavailable (zero
        # readable items, empty counts) must NOT look like a clean exit-0 run.
        partial = {
            "stage1": {"available": False, "reason": "resource DB not in payload",
                       "counts": {}},
        }
        with tempfile.TemporaryDirectory() as d:
            with mock.patch("patch_differ_cli.pipeline.run_pipeline", return_value=partial):
                code, _out, err = self._run(
                    ["stage1", "--db", "mssql", "--vuln", d, "--fixed", d, "--out", d,
                     "--quiet"])
        self.assertEqual(code, cli._EXIT_PARTIAL_FAILURE)
        self.assertIn("unavailable", err)
        self.assertIn("resource DB not in payload", err)

    def test_cmd_show_detects_available_false_from_persisted_json(self):
        with tempfile.TemporaryDirectory() as d:
            os.makedirs(os.path.join(d, "stage1"))
            with open(os.path.join(d, "stage1", "modules_diff.json"), "w") as f:
                json.dump({"available": False, "reason": "resource DB not in payload",
                          "readable_files": [], "counts": {}}, f)
            code, _out, err = self._run(["show", "--out", d])
        self.assertEqual(code, cli._EXIT_PARTIAL_FAILURE)
        self.assertIn("unavailable", err)

    def test_unavailable_part_exits_partial_failure_code(self):
        # mssql Stage 1 without the resource DB: the stage RAN (available) and diffed the
        # readable files, but skipped system objects — must still be exit 3, not 0.
        partial = {
            "stage1": {"available": True, "counts": {"errors": 0}, "readable_files": [],
                       "unavailable_parts": [{"part": "system objects",
                                              "reason": "resource DB not found on the fixed side"}]},
        }
        with tempfile.TemporaryDirectory() as d:
            with mock.patch("patch_differ_cli.pipeline.run_pipeline", return_value=partial):
                code, _out, err = self._run(
                    ["stage1", "--db", "mssql", "--vuln", d, "--fixed", d, "--out", d,
                     "--quiet"])
        self.assertEqual(code, cli._EXIT_PARTIAL_FAILURE)
        self.assertIn("system objects unavailable", err)
        self.assertIn("fixed side", err)

    def test_cmd_show_detects_unavailable_part_from_persisted_json(self):
        with tempfile.TemporaryDirectory() as d:
            os.makedirs(os.path.join(d, "stage1"))
            with open(os.path.join(d, "stage1", "modules_diff.json"), "w") as f:
                json.dump({"available": True, "readable_files": [], "counts": {},
                           "unavailable_parts": [{"part": "system objects",
                                                  "reason": "resource DB not found"}]}, f)
            code, _out, err = self._run(["show", "--out", d])
        self.assertEqual(code, cli._EXIT_PARTIAL_FAILURE)
        self.assertIn("system objects unavailable", err)

    def test_cmd_show_no_results_still_exits_1(self):
        with tempfile.TemporaryDirectory() as d:
            code, _out, err = self._run(["show", "--out", d])
        self.assertEqual(code, 1)


if __name__ == "__main__":
    unittest.main()
