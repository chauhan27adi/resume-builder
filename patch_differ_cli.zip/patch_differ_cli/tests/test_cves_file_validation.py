"""Regression tests for bugs.md #17: a malformed or wrongly-shaped cves.json was swallowed by
`except Exception: pass` in load_attrib(), silently producing zero CVE attribution —
indistinguishable from a run whose CVEs simply matched nothing. One bad record also
discarded every good record in the file. Now: per-record validation, a stderr warning naming
the problem, and run_pipeline refuses an unusable --cves file before any analysis runs."""
import contextlib
import io
import json
import os
import tempfile
import unittest

from patch_differ_cli import _attribution as A
from patch_differ_cli import pipeline

GOOD = {"cve_id": "CVE-2024-9999", "cve_desc": "a buffer overflow", "component": "Engine",
        "cwe_id": "CWE-787"}


def _load(content):
    with tempfile.TemporaryDirectory(prefix="pdff_cves_") as d:
        with open(os.path.join(d, "cves.json"), "w", encoding="utf-8") as fh:
            fh.write(content)
        buf = io.StringIO()
        with contextlib.redirect_stderr(buf):
            attrib = A.load_attrib(d)
    return attrib, buf.getvalue()


class TestLoadAttrib(unittest.TestCase):
    def test_invalid_json_warns(self):
        attrib, err = _load("{not json")
        self.assertEqual(attrib, [])
        self.assertIn("cannot read/parse as JSON", err)

    def test_wrong_top_level_shape_warns(self):
        _attrib, err = _load(json.dumps({"cve_id": "CVE-1"}))
        self.assertIn("expected a JSON list", err)

    def test_bad_record_does_not_discard_good_ones(self):
        attrib, err = _load(json.dumps([{"cve": "CVE-2024-1"}, GOOD, "junk"]))
        self.assertEqual([a["cve"] for a in attrib], ["CVE-2024-9999"])
        self.assertIn("record 0: missing/invalid 'cve_id'", err)
        self.assertIn("record 2: not an object", err)

    def test_null_and_numeric_fields_do_not_crash(self):
        attrib, _err = _load(json.dumps([{"cve_id": "CVE-2024-1", "cve_desc": None,
                                          "component": 42, "cwe_id": "CWE-787"}]))
        self.assertEqual([a["cve"] for a in attrib], ["CVE-2024-1"])

    def test_valid_file_is_silent(self):
        attrib, err = _load(json.dumps([GOOD]))
        self.assertEqual([a["cve"] for a in attrib], ["CVE-2024-9999"])
        self.assertEqual(err, "")


class TestPipelineValidatesUpFront(unittest.TestCase):
    def _file(self, d, content):
        p = os.path.join(d, "c.json")
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(content)
        return p

    def test_unusable_cves_file_is_refused(self):
        with tempfile.TemporaryDirectory(prefix="pdff_cvesv_") as d:
            with self.assertRaises(ValueError):
                pipeline._validate_cves_file(self._file(d, "{not json"))
            with self.assertRaises(ValueError):
                pipeline._validate_cves_file(self._file(d, json.dumps([{"cve": "x"}])))

    def test_partially_bad_file_is_accepted_with_warning(self):
        with tempfile.TemporaryDirectory(prefix="pdff_cvesv2_") as d:
            buf = io.StringIO()
            with contextlib.redirect_stderr(buf):
                pipeline._validate_cves_file(self._file(d, json.dumps([GOOD, {"x": 1}])))
            self.assertIn("record 1", buf.getvalue())


if __name__ == "__main__":
    unittest.main()
