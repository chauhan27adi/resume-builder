"""Regression tests for CRIT-T2-1: a total, silent decompile failure (e.g. a stale
Ghidra OSGi script-bundle cache — a real, live-reproduced failure mode, not a
theoretical one: this exact condition was found already present in this engagement's
own dev environment) used to be completely invisible. _try_decompile() swallowed the
exception with a bare `except Exception: return "", ""`, and no backend tracked whether
a decompile was ever actually attempted — so "nothing was fix-shaped/CVE-attributed
enough to decompile" (a legitimate empty result) and "decompile was tried and failed
for every single function" (a total, silent failure) produced byte-identical output:
zero .c files, no field anywhere saying so.

The fix: _try_decompile()/decompile_cached() now return a third value, `attempted`
(True whenever Ghidra was configured and a real attempt was made, regardless of
success), and log the swallowed exception to stderr instead of discarding it. All
three backends now track counts.decompile_attempted / counts.decompile_failed.

These tests use mocking (not the real, currently-broken Ghidra install in this
environment) so they stay deterministic regardless of whether that real environmental
issue is ever fixed independently."""
import io
import os
import tempfile
import unittest
from contextlib import redirect_stderr
from unittest import mock

from patch_differ_cli import _decompile as dc
from patch_differ_cli import _attribution as _AT


class TestTryDecompile(unittest.TestCase):
    def test_ghidra_unavailable_is_not_attempted_and_logs_nothing(self):
        with mock.patch.object(dc, "available", return_value=False):
            err = io.StringIO()
            with redirect_stderr(err):
                prior_c, fixed_c, attempted = dc._try_decompile(b"x", b"y")
        self.assertEqual((prior_c, fixed_c, attempted), ("", "", False))
        self.assertEqual(err.getvalue(), "")

    def test_a_real_failure_is_attempted_and_logged_not_swallowed(self):
        with mock.patch.object(dc, "available", return_value=True), \
             mock.patch.object(dc, "decompile_pair",
                               side_effect=RuntimeError("Ghidra produced no C output.")):
            err = io.StringIO()
            with redirect_stderr(err):
                prior_c, fixed_c, attempted = dc._try_decompile(b"x", b"y")
        self.assertEqual((prior_c, fixed_c), ("", ""))
        self.assertTrue(attempted, "a real failure must still report attempted=True")
        self.assertIn("WARNING", err.getvalue())
        self.assertIn("decompile failed", err.getvalue())

    def test_success_is_attempted_and_normalized(self):
        with mock.patch.object(dc, "available", return_value=True), \
             mock.patch.object(dc, "decompile_pair",
                               return_value=("int FUN_00100000(void){}", "")):
            prior_c, fixed_c, attempted = dc._try_decompile(b"x", b"y")
        self.assertTrue(attempted)
        self.assertIn("FUN_", prior_c)   # norm_c() still applied
        self.assertEqual(fixed_c, "")


class TestDecompileCached(unittest.TestCase):
    def test_cache_hit_is_always_attempted_true(self):
        with tempfile.TemporaryDirectory() as d:
            # both sides present: a one-sided result is deliberately NOT cached (bugs.md #7)
            with mock.patch.object(dc, "_try_decompile",
                                   return_value=("real C", "real C2", True)) as m:
                dc.decompile_cached(b"prior", b"fixed", d)   # populate cache
                self.assertEqual(m.call_count, 1)
                _pc, _fc, attempted = dc.decompile_cached(b"prior", b"fixed", d)  # cache hit
                self.assertEqual(m.call_count, 1, "cache hit must not re-invoke Ghidra")
                self.assertTrue(attempted)

    def test_a_failed_attempt_is_never_cached_and_reports_attempted_true(self):
        with tempfile.TemporaryDirectory() as d:
            with mock.patch.object(dc, "_try_decompile", return_value=("", "", True)):
                prior_c, fixed_c, attempted = dc.decompile_cached(b"prior", b"fixed", d)
            self.assertEqual((prior_c, fixed_c), ("", ""))
            self.assertTrue(attempted)
            self.assertEqual(os.listdir(d), [], "a failed result must not be cached")

    def test_ghidra_unavailable_is_attempted_false_and_not_cached(self):
        with tempfile.TemporaryDirectory() as d:
            with mock.patch.object(dc, "_try_decompile", return_value=("", "", False)):
                prior_c, fixed_c, attempted = dc.decompile_cached(b"prior", b"fixed", d)
            self.assertFalse(attempted)
            self.assertEqual(os.listdir(d), [])


class TestOracleStage2DecompileStats(unittest.TestCase):
    """End-to-end through the real production function _diff_o(), not a reimplemented
    copy of its logic — only decompile_cached() is mocked."""

    def test_failed_decompile_is_counted_as_attempted_and_failed(self):
        import patch_differ_cli.oracle.stage2 as os2

        prior = bytes.fromhex("b82a000000c3")
        fixed = bytes.fromhex("b8ffffffffc3")
        P_fake = {"DoRangeCheckThing": (0x1000, prior)}
        F_fake = {"DoRangeCheckThing": (0x1000, fixed)}
        orig_func_map = os2._func_map
        os2._func_map = lambda path: dict(P_fake if path == "PRIOR" else F_fake)

        # "rangecheck" is a CWE-787 primitive -> guaranteed CVE attribution regardless of
        # the assembly fix-score, reliably opening the decompile gate.
        attrib = _AT.build_attrib([("CVE-2024-9999", "a buffer overflow issue", "Engine",
                                    "", "CWE-787")])

        with tempfile.TemporaryDirectory() as d:
            out = os.path.join(d, "out")
            decompile_cache = os.path.join(out, "decompile_cache")
            decompiled_c_dir = os.path.join(out, "decompiled_c")
            os.makedirs(out); os.makedirs(decompile_cache); os.makedirs(decompiled_c_dir)

            readable = []
            decompile_stats = {"attempted": 0, "failed": 0}
            try:
                with mock.patch("patch_differ_cli.oracle.stage2.decompile_cached",
                                return_value=("", "", True)):
                    hits = os2._diff_o("risky.o", "risky.o", "PRIOR", "FIXED", out, readable,
                                       attrib=attrib, use_bindiff=False, decompile=True,
                                       decompile_cache=decompile_cache,
                                       decompiled_c_dir=decompiled_c_dir,
                                       decompile_stats=decompile_stats)
            finally:
                os2._func_map = orig_func_map

        self.assertEqual(hits, 1)
        self.assertEqual(readable[0]["cve"], "CVE-2024-9999")
        self.assertEqual(decompile_stats, {"attempted": 1, "failed": 1},
                         "a decompile failure on an attributed function must be counted "
                         "as both attempted and failed, not silently 0/0")


if __name__ == "__main__":
    unittest.main()
