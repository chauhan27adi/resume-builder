"""Regression tests for bugs.md #53-#56 — Track 1 (BinDiff) and Track 2 (decompile) were
non-functional or lossy with the bundled toolchain:

  #53  a BinDiff match with similarity 1.0 was skipped although its operands changed;
  #54  the BinExport export passed an empty argument that analyzeHeadless.bat drops;
  #55  mixed protobuf-java versions in the Ghidra install crashed every export;
  #56  a system JAVA_HOME (e.g. JDK 26) overrode the bundled JDK 17.

Ghidra/BinDiff are mocked here (the live runs are recorded in bugs.md). Scratch files live
in TemporaryDirectory()s only."""
import contextlib
import io
import os
import tempfile
import unittest
from unittest import mock

import patch_differ_cli._bindiff as bd
import patch_differ_cli.db2.stage2 as d2
import patch_differ_cli.mssql.stage2 as ms2
import patch_differ_cli.oracle.stage2 as o2
import patch_differ_cli.tool_paths as tp
from patch_differ_cli.tests.test_silent_loss_fixes import _GLOBAL_FUNC, _elf, _write


def _chk(imm):          # cmp edi, imm ; jae +3 ; xor eax,eax ; ret ; mov eax,1 ; ret
    return (bytes.fromhex("81ff") + imm.to_bytes(4, "little") + bytes.fromhex("7303")
            + bytes.fromhex("31c0c3") + bytes.fromhex("b801000000c3"))


HELPER = bytes.fromhex("554889e5b8070000005dc3")


def _match(addr2, similarity=1.0):
    return bd.FuncMatch(addr1=0, addr2=addr2, similarity=similarity, confidence=0.99)


# --------------------------------------------------------------------------- #53
class SimilarityOneIsNotSkippedTests(unittest.TestCase):
    """BinDiff scores structure + mnemonics, not operands: a bounds-constant change scores
    1.0 (live-verified). Only byte-identical functions may be skipped."""

    def test_db2_reports_an_operand_only_change_bindiff_scored_identical(self):
        base = d2._GHIDRA_ELF_PIE_BASE
        prior = [("chk_len", _GLOBAL_FUNC, 0x0, _chk(0x100)), ("helper", _GLOBAL_FUNC, 0x20, HELPER)]
        fixed = [("chk_len", _GLOBAL_FUNC, 0x0, _chk(0xFF)), ("helper", _GLOBAL_FUNC, 0x20, HELPER)]
        matches = {base + 0x0: _match(base + 0x0), base + 0x20: _match(base + 0x20)}
        with tempfile.TemporaryDirectory() as d:
            rel = "lib/libx.so"
            p, f, out = (os.path.join(d, x) for x in ("p", "f", "out"))
            _write(os.path.join(p, rel), _elf(prior))
            _write(os.path.join(f, rel), _elf(fixed))
            os.makedirs(out)
            job = {"prior_dir": p, "fixed_dir": f, "rel": rel, "out": out, "attrib": [],
                   "use_bindiff": True, "decompile": False, "disassembled_dir": out,
                   "vuln_label": "v", "fixed_label": "f", "run_ts": "t"}
            with mock.patch.object(bd, "diff_pair", lambda *a, **k: matches):
                r = d2._process_file(job)
        cards = [(c["object"], c["change"], c["match_algorithm"]) for c in r["readable"]]
        self.assertEqual(cards, [("lib/libx.so :: chk_len", "const", "bindiff")],
                         "chk_len changed; helper is byte-identical and must stay skipped")

    def test_oracle_reports_an_operand_only_change_bindiff_scored_identical(self):
        base = o2._GHIDRA_ELF_REL_BASE
        P = {"chk_len": (0x0, _chk(0x100)), "helper": (0x20, HELPER)}
        F = {"chk_len": (0x0, _chk(0xFF)), "helper": (0x20, HELPER)}
        matches = {base + 0x0: _match(base + 0x0), base + 0x20: _match(base + 0x20)}
        with tempfile.TemporaryDirectory() as out, \
                mock.patch.object(o2, "_func_map", lambda path: dict(P if path == "PRIOR" else F)), \
                mock.patch.object(o2, "_func_sections", lambda path: {".text"}), \
                mock.patch.object(bd, "diff_pair", lambda *a, **k: matches):
            readable = []
            o2._diff_o("x.o", "x.o", "PRIOR", "FIXED", out, readable, attrib=[],
                       use_bindiff=True, disassembled_dir=out, run_ts="t")
        self.assertEqual([(c["object"], c["match_algorithm"]) for c in readable],
                         [("x.o :: chk_len", "bindiff")])

    def test_mssql_reports_an_operand_only_change_bindiff_scored_identical(self):
        class Sym:
            ok = True

            def __init__(self, *a, **k):
                pass

            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

            def name_at(self, addr):
                return None

        class PE:
            class OPTIONAL_HEADER:
                ImageBase = 0

            def __init__(self, *a, **k):
                pass

            def close(self):
                pass

        P = {"chk_len": (0x1000, [(0x1000, _chk(0x100))]), "helper": (0x1020, [(0x1020, HELPER)])}
        F = {"chk_len": (0x1000, [(0x1000, _chk(0xFF))]), "helper": (0x1020, [(0x1020, HELPER)])}
        matches = {0x1000: _match(0x1000), 0x1020: _match(0x1020)}
        with tempfile.TemporaryDirectory() as d:
            prior, fixed, out = (os.path.join(d, x) for x in ("prior", "fixed", "out"))
            for x in (prior, fixed):
                _write(os.path.join(x, "x.dll"), b"\x00")
            os.makedirs(os.path.join(out, "dis"))
            job = {"prior_dir": prior, "fixed_dir": fixed, "rel": "x.dll", "out": out,
                   "attrib": [], "online": False, "pdb_cache": d, "use_bindiff": True,
                   "decompile": False, "decompile_cache": d, "decompiled_c_dir": d,
                   "disassembled_dir": os.path.join(out, "dis"), "run_ts": "t",
                   "vuln_label": "v", "fixed_label": "f"}
            with mock.patch.object(ms2, "_func_map",
                                   lambda path, s: dict(P if "prior" in path else F)), \
                    mock.patch.object(ms2.sym, "fetch_pdb", lambda *a, **k: None), \
                    mock.patch.object(ms2.sym, "Symbolizer", Sym), \
                    mock.patch.object(ms2._pefile, "PE", PE), \
                    mock.patch.object(bd, "diff_pair", lambda *a, **k: matches):
                r = ms2._process_dll(job)
        self.assertEqual([(c["object"], c["match_algorithm"]) for c in r["readable"]],
                         [("x.dll :: chk_len", "bindiff")])


# --------------------------------------------------------------------------- #54, #55
class _Proc:
    def __init__(self, rc=0, out=b""):
        self.returncode, self.stdout = rc, out


class ExportCommandTests(unittest.TestCase):
    def setUp(self):
        td = tempfile.TemporaryDirectory()
        self.addCleanup(td.cleanup)
        self.d = td.name
        self.binary = _write(os.path.join(self.d, "x.so"), b"\x7fELF bin")
        self.out = os.path.join(self.d, "exp", "x.BinExport")
        self.cmds = []
        for target, value in (("analyze_headless", "analyzeHeadless.bat"),
                              ("locate_binexport_script", os.path.join(self.d, "BinExport.java")),
                              ("clear_stale_ghidra_script_cache", None), ("child_env", {}),
                              ("binexport_identity", "tool"), ("protobuf_conflict", [])):
            p = mock.patch.object(bd.tp, target, return_value=value)
            p.start()
            self.addCleanup(p.stop)

    def _run(self, cmd, **kw):
        self.cmds.append(cmd)
        if "-postScript" in cmd:                 # the export step writes the file
            _write(self.out, b"EXPORT")
        return _Proc(0)

    def test_export_uses_our_script_with_no_empty_argument(self):                # #54
        with mock.patch.object(bd, "_run_tool", self._run):
            bd.ghidra_binexport(self.binary, os.path.join(self.d, "proj"), self.out)
        export = [c for c in self.cmds if "-postScript" in c][0]
        self.assertTrue(all(export), f"empty argument in {export}")
        i = export.index("-postScript")
        self.assertEqual(export[i + 1:i + 3], ["PdffBinExport.java", self.out])
        self.assertEqual(export[export.index("-scriptPath") + 1], bd._EXPORT_SCRIPT_DIR)
        self.assertIn("-noanalysis", export)
        self.assertTrue(os.path.isfile(os.path.join(bd._EXPORT_SCRIPT_DIR, "PdffBinExport.java")))

    def test_script_change_invalidates_cached_exports(self):
        with mock.patch.object(bd, "_run_tool", self._run):
            bd.ghidra_binexport(self.binary, os.path.join(self.d, "proj"), self.out)
            self.cmds.clear()
            with mock.patch.object(bd.tp, "content_identity", return_value="edited-script"):
                bd.ghidra_binexport(self.binary, os.path.join(self.d, "proj"), self.out)
        self.assertEqual(len(self.cmds), 2, "an edited export script must re-export")

    def test_protobuf_conflict_fails_fast_with_the_jars_named(self):              # #55
        with mock.patch.object(bd.tp, "protobuf_conflict",
                               return_value=[("3.21.8", "a.jar"), ("3.25.1", "b.jar")]), \
                mock.patch.object(bd, "_run_tool", self._run):
            with self.assertRaises(bd.BinExportNotInstalled) as ctx:
                bd.ghidra_binexport(self.binary, os.path.join(self.d, "proj"), self.out)
        self.assertIn("3.21.8: a.jar", str(ctx.exception))
        self.assertEqual(self.cmds, [], "nothing may be launched")


class ProtobufConflictDetectionTests(unittest.TestCase):
    def _ghidra(self, d, jars):
        for rel in jars:
            _write(os.path.join(d, "Ghidra", *rel.split("/")), b"jar")
        return d

    def test_mixed_versions_are_reported(self):
        with tempfile.TemporaryDirectory() as d:
            gh = self._ghidra(d, ["Debug/Framework-AsyncComm/lib/protobuf-java-3.21.8.jar",
                                  "Extensions/BinExport/lib/protobuf-java-3.25.1.jar"])
            self.assertEqual([v for v, _p in tp.protobuf_conflict(gh)], ["3.21.8", "3.25.1"])

    def test_one_version_is_fine(self):
        with tempfile.TemporaryDirectory() as d:
            gh = self._ghidra(d, ["Debug/Framework-AsyncComm/lib/protobuf-java-3.25.1.jar",
                                  "Extensions/BinExport/lib/protobuf-java-3.25.1.jar"])
            self.assertEqual(tp.protobuf_conflict(gh), [])

    def test_bundled_install_is_aligned(self):
        if not os.path.isdir(tp.GHIDRA_DIR):
            self.skipTest("bundled Ghidra not present")
        self.assertEqual(tp.protobuf_conflict(tp.GHIDRA_DIR), [])


# --------------------------------------------------------------------------- #56
class JdkSelectionTests(unittest.TestCase):
    def _jdk(self, d, version):
        _write(os.path.join(d, "bin", "java.exe" if os.name == "nt" else "java"), b"")
        _write(os.path.join(d, "release"), f'JAVA_VERSION="{version}"\n'.encode())
        return d

    def test_java_major_parses_release_files(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(tp.java_major(self._jdk(os.path.join(d, "a"), "26")), 26)
            self.assertEqual(tp.java_major(self._jdk(os.path.join(d, "b"), "17.0.12")), 17)
            self.assertEqual(tp.java_major(self._jdk(os.path.join(d, "c"), "1.8.0_402")), 8)
            self.assertIsNone(tp.java_major(os.path.join(d, "missing")))

    def test_unsupported_jdk_is_flagged_and_warned_once(self):
        with tempfile.TemporaryDirectory() as d:
            jdk = self._jdk(os.path.join(d, "jdk-26"), "26")
            tp._JAVA_WARNED.clear()
            err = io.StringIO()
            with mock.patch.dict(os.environ, {"PATCHDIFF_JAVA_HOME": jdk}), \
                    contextlib.redirect_stderr(err):
                self.assertIn("JDK 26", tp.ghidra_java_problem())
                tp.warn_if_unsupported_java()
                tp.warn_if_unsupported_java()
            self.assertEqual(err.getvalue().count("WARNING"), 1)

    def test_bundled_jdk_is_supported(self):
        if not os.path.isfile(os.path.join(tp.JDK_DIR, "release")):
            self.skipTest("bundled JDK not present")
        with mock.patch.dict(os.environ, {"PATCHDIFF_JAVA_HOME": "",
                                          "JAVA_HOME": r"C:\Program Files\Java\jdk-26"}):
            self.assertEqual(tp.java_home(), tp.JDK_DIR)
            self.assertIsNone(tp.ghidra_java_problem())

    def test_child_env_carries_the_chosen_jdk(self):
        with mock.patch.dict(os.environ, {"PATCHDIFF_JAVA_HOME": "",
                                          "JAVA_HOME": r"C:\Program Files\Java\jdk-26"}), \
                mock.patch.object(tp, "_jdk_present", lambda home: home == tp.JDK_DIR):
            env = tp.child_env()
        self.assertEqual(env["JAVA_HOME"], tp.JDK_DIR)
        self.assertTrue(env["PATH"].startswith(os.path.join(tp.JDK_DIR, "bin")))


if __name__ == "__main__":
    unittest.main()
