"""patch-differ CLI — standalone terminal entry point.

Usage
-----
Run all three stages with pre-extracted directories:

    patch-differ run --db mssql --vuln /path/vuln --fixed /path/fixed --out /path/out

Auto-acquire MSSQL patch binaries (downloads from Microsoft Update Catalog):

    patch-differ run --db mssql --fixed-kb 5084815 --vuln-kb 5029395 --out /path/out

Auto-acquire DB2 container images (anonymous registry v2 pull):

    patch-differ run --db db2 \\
        --vuln-url container:icr.io/db2_community/db2:12.1.5.0 \\
        --fixed-url container:icr.io/db2_community/db2:12.1.5.1 \\
        --out /path/out

DB2 Fix Central fixpack (drop the .tar.gz into <out>/acquire/{vuln,fixed}/drop/ first):

    patch-differ run --db db2 \\
        --vuln-url manual:v12.1.5.0 \\
        --fixed-url manual:v12.1.5.1-fp1 \\
        --out /path/out

Run a single stage:

    patch-differ triage  --db mssql --vuln ... --fixed ... --out ...
    patch-differ stage1  --db mssql --vuln ... --fixed ... --out ...
    patch-differ stage2  --db mssql --vuln ... --fixed ... --out ...

Supply CVE attribution data (optional):

    patch-differ run ... --cves cves.json

Show results from a previous run:

    patch-differ show --out /path/out

Auto-acquire notes
------------------
* --vuln / --fixed are OPTIONAL when acquisition args are supplied.
  If the directories already exist and contain files, acquisition is skipped.
* MSSQL: requires 7-Zip — bundled at patch_differ_cli/tools/7-Zip-installed/7z.exe,
  or override the location with the SEVENZIP env var.
* DB2 container: requires internet access; no Docker daemon needed (uses registry v2 API).
* DB2 manual: requires the user to drop the Fix Central universal fixpack (.tar.gz)
  into <out>/acquire/vuln/drop/ and/or <out>/acquire/fixed/drop/ before running.
* Oracle: cannot be automated (login-gated). Place extracted RU contents manually.

CVE JSON format (for --cves):

    [
      {
        "cve_id":    "CVE-2026-32167",
        "cve_desc":  "elevation of privilege via linked server",
        "component": "Linked Server",
        "cwe_id":    "CWE-269"
      }
    ]

Exit codes
----------
* 0   — success; every item was fully analyzed.
* 1   — hard failure: an unhandled exception, or (for `show`) no results found in --out.
* 2   — command-line usage error (argparse's own: missing/invalid arguments, unknown
         subcommand) — the analysis never started.
* 3   — the analysis COMPLETED, but one or more files/binaries — or a whole part of a
         stage — could not be checked (see each stage's "errors" / "failed_binaries" /
         "unavailable_parts" fields in --out); a result with this exit code is a PARTIAL
         result, not a verified "no changes found".
* 130 — interrupted (Ctrl-C).

2 and 3 are deliberately distinct: a script checking $? must be able to tell "you typed
the command wrong" (2, nothing ran) apart from "it ran, but not everything could be
checked" (3, a real result exists but may be incomplete) — collapsing them onto the same
code would make the latter case impossible to detect from the exit code alone.
"""
import argparse
import json
import os
import sys
from pathlib import Path

# Exit codes. Kept distinct from argparse's OWN exit codes (0 success, 2 usage error —
# e.g. a missing/invalid --db) so a script checking $? can tell "you typed the command
# wrong" apart from "the command ran fine but some items couldn't be checked". See the
# module docstring's "Exit codes" section for the full, documented contract.
_EXIT_PARTIAL_FAILURE = 3


def _add_common(p):
    p.add_argument("--db", required=True, choices=["mssql", "db2", "oracle"],
                   help="Database family to analyse")
    p.add_argument("--vuln", default=None, metavar="DIR",
                   help="Vulnerable (unpatched) build / extract directory. "
                        "Defaults to patch_differ_cli/patches/<db>/vuln/")
    p.add_argument("--fixed", default=None, metavar="DIR",
                   help="Fixed (patched) build / extract directory. "
                        "Defaults to patch_differ_cli/patches/<db>/fixed/")
    p.add_argument("--out", default=None, metavar="DIR",
                   help="Output directory (created if absent). "
                        "Defaults to patch_differ_cli/runs/<db>/. "
                        "Auto-acquired binaries are placed under <out>/acquire/.")
    p.add_argument("--cves", metavar="FILE",
                   help="JSON file with CVE records for attribution (optional)")
    p.add_argument("--quiet", action="store_true", help="Suppress progress output")
    p.add_argument("--reattribute", action="store_true",
                   help="Re-run CVE attribution only on an existing stage2 result. "
                        "Skips all binary analysis. Combine with --cves to apply updated "
                        "CVE data. Requires a completed run in --out.")
    p.add_argument("--use-bindiff", action="store_true", dest="use_bindiff",
                   help="Use BinDiff (CFG-based) for function matching instead of "
                        "name-based LCS. More accurate for renamed/stripped functions. "
                        "Requires Ghidra (with the BinExport extension) and BinDiff — "
                        "bundled under patch_differ_cli/tools/, or override via "
                        "GHIDRA_HOME / PATCHDIFF_JAVA_HOME / BINDIFF_PATH. Significantly slower "
                        "than default mode.")
    p.add_argument("--bindiff-only", action="append", dest="bindiff_only", metavar="GLOB",
                   help="With --use-bindiff: use BinDiff only for binaries whose path or file "
                        "name matches GLOB (case-insensitive; repeat the option or separate "
                        "with commas, e.g. 'libdb2e.so*,sqlmin*'). The others are matched by "
                        "name. Ghidra analyses every BinDiff binary twice and a large one "
                        "can take hours, so this bounds the run.")
    p.add_argument("--decompile-max", type=int, dest="decompile_max", metavar="N",
                   help="With --decompile: at most N pseudo-C decompiles per binary (per "
                        "object for Oracle), most important functions first. Each starts "
                        "Ghidra once. Default: no limit.")
    p.add_argument("--decompile", action="store_true", dest="decompile",
                   help="Decompile changed functions to pseudo-C via Ghidra headless. "
                        "Requires Ghidra + a JDK — bundled under patch_differ_cli/tools/, "
                        "or override via GHIDRA_HOME / PATCHDIFF_JAVA_HOME. "
                        "Only decompiles fix-scored or CVE-attributed functions. "
                        "Oracle: native OJVM .o functions only (its file-level DBRU PE "
                        "path has no function names to decompile). "
                        "Results stored as prior_c/fixed_c in each fn__*.detail.json, and "
                        "permanently as standalone .c files, one folder per build: "
                        "stage2/decompiled_c_{vuln,fixed}_<version>/<binary>_<sha8>/ "
                        "(all backends). "
                        "Best-effort: silently skipped if Ghidra is absent.")

    # Acquisition fallback args (used when --vuln/--fixed are absent or empty)
    acq = p.add_argument_group(
        "auto-acquisition (fallback when --vuln/--fixed dirs are empty)")
    acq.add_argument("--fixed-kb", dest="fixed_kb", metavar="KB",
                     help="MSSQL: KB number of the fixed build (e.g. 5084815)")
    acq.add_argument("--vuln-kb", dest="vuln_kb", metavar="KB",
                     help="MSSQL: KB number of the vulnerable build (e.g. 5029395)")
    acq.add_argument("--vuln-url", dest="vuln_url", metavar="URL",
                     help="DB2: acquisition URL for vulnerable build "
                          "(container:<ref> or manual:<label>)")
    acq.add_argument("--fixed-url", dest="fixed_url", metavar="URL",
                     help="DB2: acquisition URL for fixed build "
                          "(container:<ref> or manual:<label>)")
    acq.add_argument("--vuln-label", dest="vuln_label", metavar="LABEL",
                     help="Version label for the vulnerable build, naming its per-version "
                          "output folders. Overrides the auto-derived label (MSSQL KB/engine "
                          "version, DB2 URL tag, Oracle RU-zip filename) when given.")
    acq.add_argument("--fixed-label", dest="fixed_label", metavar="LABEL",
                     help="Version label for the fixed build (see --vuln-label).")


def _summarize_partial_failures(results):
    """Return [(stage, what, count), ...] for every nonzero errors/failed count, and for
    any stage that reported itself unavailable, across all stages in a run_pipeline()
    result. Empty list means nothing to report.

    This is what lets a caller tell "verified zero changes" apart from "some files or
    binaries could not be checked" — a stage can finish without raising (so the process
    would otherwise exit 0 and print nothing unusual) while still having skipped items
    that are recorded, per-item, in that stage's own JSON (triage/stage1: "errors";
    stage2: "failed" — mssql/db2/oracle all expose this the same way via counts), OR
    while reporting "available": False (a whole stage that couldn't run; also results
    saved by older versions of mssql/stage1.py when the resource DB was missing), OR
    while listing "unavailable_parts" (a stage that ran but skipped part of its work —
    e.g. mssql/stage1.py diffs readable files but not system objects without the resource
    DB). A stage or part silently producing zero items is the same "looks like a clean
    empty result but isn't" risk as a per-item failure, so it gets the same treatment."""
    problems = []
    for stage, data in (results or {}).items():
        data = data or {}
        if data.get("available") is False:
            reason = data.get("reason") or "no reason given"
            problems.append((stage, f"stage reported unavailable ({reason})", 1))
        # A stage that ran but couldn't do PART of its work (e.g. mssql Stage 1 without the
        # resource DB still diffs readable files, but not system objects) is a partial
        # failure too — same "looks complete but isn't" risk, just for one part.
        for part in data.get("unavailable_parts") or []:
            reason = part.get("reason") or "no reason given"
            problems.append((stage, f"{part.get('part', 'part of stage')} unavailable "
                                    f"({reason})", 1))
        counts = data.get("counts", {}) or {}
        for field, label in (("errors", "file(s) could not be analyzed"),
                             ("failed", "binary(ies) could not be analyzed"),
                             # bugs.md #28: a changed function over Stage 2's size limit
                             ("functions_skipped",
                              "changed function(s) too large to diff (see skipped_functions)"),
                             # bugs.md #57: --use-bindiff wasn't applied to these binaries
                             ("bindiff_fallbacks",
                              "binary(ies) not matched with BinDiff — fell back to name "
                              "matching (see bindiff_fallbacks)"),
                             # db2_bugs.md DB2-18: stripped of .symtab, diffed from .dynsym
                             ("dynsym_only",
                              "binary(ies) compared on exported functions only (no .symtab; "
                              "static functions not compared — see dynsym_only)")):
            n = counts.get(field, 0)
            if n:
                problems.append((stage, label, n))
    return problems


def _decompile_shortfalls(results):
    """[(stage, failed, attempted)] where --decompile produced missing or one-sided
    pseudo-C (bugs.md #7). Reported as a warning, deliberately NOT a partial-failure exit:
    decompilation is an opt-in, best-effort add-on — the binary diff itself completed."""
    out = []
    for stage, data in (results or {}).items():
        counts = (data or {}).get("counts", {}) or {}
        failed = counts.get("decompile_failed", 0)
        if failed:
            out.append((stage, failed, counts.get("decompile_attempted", 0)))
    return out


def _warn_decompile_shortfalls(results):
    for stage, failed, attempted in _decompile_shortfalls(results):
        print(f"WARNING: [{stage}] {failed} of {attempted} decompile(s) produced missing or "
              f"one-sided pseudo-C — see decompile_failures in the stage's result for which "
              f"functions and why.", file=sys.stderr)
    _warn_capped_functions(results)
    _note_unanalyzed_triage(results)
    _note_budget_limits(results)


def _note_budget_limits(results):
    """db2_bugs.md DB2-12: what --bindiff-only / --decompile-max left out, by choice."""
    for stage, data in (results or {}).items():
        data = data or {}
        skipped = (data.get("counts", {}) or {}).get("decompile_skipped", 0)
        if skipped:
            print(f"NOTE: [{stage}] {skipped} decompile(s) not run: --decompile-max reached.",
                  file=sys.stderr)
        failed_jars = data.get("class_decompile_failures") or []
        if failed_jars:
            print(f"WARNING: [{stage}] {len(failed_jars)} jar(s): the changed classes could "
                  f"not be decompiled, only their entry names are shown — see "
                  f"class_decompile_failures.", file=sys.stderr)
        names = data.get("bindiff_not_selected") or []
        if names:
            print(f"NOTE: [{stage}] {len(names)} binary(ies) matched by name, not BinDiff "
                  f"(not selected by --bindiff-only) — see bindiff_not_selected.",
                  file=sys.stderr)


def _warn_capped_functions(results):
    """db2_bugs.md DB2-4: each binary writes at most a fixed number of function cards. CVE-
    attributed and fix-shaped changes are always written; the cap drops ordinary changes
    only, which is by design (not a failed run) but must not be invisible."""
    for stage, data in (results or {}).items():
        n = ((data or {}).get("counts", {}) or {}).get("functions_capped", 0)
        if n:
            libs = (data or {}).get("capped_functions") or []
            print(f"WARNING: [{stage}] {n} ordinary changed function(s) in {len(libs)} "
                  f"binary(ies) were not written: each binary keeps at most its card limit "
                  f"(CVE-attributed and fix-shaped changes are always kept) — see "
                  f"capped_functions.", file=sys.stderr)


def _note_unanalyzed_triage(results):
    """db2_bugs.md DB2-21 / DB2-22: changed files triage reports but does not analyze."""
    counts = ((results or {}).get("triage") or {}).get("counts", {}) or {}
    for field, what in (("noise_changed", "changed file(s) under the bundled JDK, samples "
                                          "or docs were not analyzed (see noise_changed)"),
                        ("data_changed", "ELF file(s) changed only in their data sections, "
                                         "not in code; listed, not analyzed (see "
                                         "data_changed)")):
        if counts.get(field):
            print(f"NOTE: [triage] {counts[field]} {what}.", file=sys.stderr)


def _run_stages(args, stages):
    from patch_differ_cli.pipeline import run_pipeline, default_out_dir
    vuln  = str(Path(args.vuln).resolve()) if args.vuln else None
    fixed = str(Path(args.fixed).resolve()) if args.fixed else None
    out   = str(Path(args.out).resolve()) if args.out else str(default_out_dir(args.db))
    results = run_pipeline(
        db=args.db,
        vuln_dir=vuln,
        fixed_dir=fixed,
        out_dir=out,
        stages=stages,
        cves_path=args.cves,
        verbose=not args.quiet,
        fixed_kb=getattr(args, "fixed_kb", None),
        vuln_kb=getattr(args, "vuln_kb", None),
        vuln_url=getattr(args, "vuln_url", None),
        fixed_url=getattr(args, "fixed_url", None),
        vuln_label=getattr(args, "vuln_label", None),
        fixed_label=getattr(args, "fixed_label", None),
        reattribute=getattr(args, "reattribute", False),
        use_bindiff=getattr(args, "use_bindiff", False),
        decompile=getattr(args, "decompile", False),
        bindiff_only=getattr(args, "bindiff_only", None),
        decompile_max=getattr(args, "decompile_max", None),
    )
    if not args.quiet:
        print(f"\nResults written to: {out}")
    _warn_decompile_shortfalls(results)
    problems = _summarize_partial_failures(results)
    if problems:
        # Printed to stderr regardless of --quiet: this is a correctness signal, not
        # progress noise. A clean exit code must never be the only thing distinguishing
        # "verified no changes" from "some items couldn't be checked".
        print("\nWARNING: analysis completed with partial failures — some items could "
              "not be checked. This is NOT the same as \"no changes found\":",
              file=sys.stderr)
        for stage, label, n in problems:
            print(f"  [{stage}] {n} {label}", file=sys.stderr)
        print(f"  See {out}/<stage>/*.json — \"errors\" / \"failed_binaries\" fields "
              "for which item(s) and why.", file=sys.stderr)
    return results, bool(problems)


def cmd_run(args):
    _, had_problems = _run_stages(args, ("triage", "stage1", "stage2"))
    if had_problems:
        sys.exit(_EXIT_PARTIAL_FAILURE)


def cmd_triage(args):
    _, had_problems = _run_stages(args, ("triage",))
    if had_problems:
        sys.exit(_EXIT_PARTIAL_FAILURE)


def cmd_stage1(args):
    _, had_problems = _run_stages(args, ("triage", "stage1"))
    if had_problems:
        sys.exit(_EXIT_PARTIAL_FAILURE)


def cmd_stage2(args):
    _, had_problems = _run_stages(args, ("triage", "stage2"))
    if had_problems:
        sys.exit(_EXIT_PARTIAL_FAILURE)


def cmd_show(args):
    from patch_differ_cli.pipeline import load_result
    out = Path(args.out).resolve()
    stale = []
    result = load_result(str(out), stale=stale)
    # bugs.md #37: an older later-stage result no longer shows as if it were current
    for stage, reason in stale:
        print(f"NOTE: {stage} result in {out} not shown — {reason}; re-run {stage} "
              f"to refresh it.", file=sys.stderr)
    if not result:
        print(f"No results found in {out}", file=sys.stderr)
        sys.exit(1)

    for stage, data in result.items():
        files = data.get("readable_files", [])
        counts = data.get("counts", {})
        print(f"\n=== {stage} ===")
        if counts:
            print("  counts:", json.dumps(counts, indent=None))
        for r in files:
            cve    = r.get("cve") or r.get("cve_candidate") or ""
            score  = r.get("fix_score", 0)
            label  = f"[CVE:{cve}]" if cve else f"[score:{score}]"
            obj    = r.get("object", r.get("name", "?"))
            print(f"  {label:30s}  {obj}")

    _warn_decompile_shortfalls(result)
    problems = _summarize_partial_failures(result)
    if problems:
        print("\nWARNING: this run has partial failures — some items could not be "
              "checked. This is NOT the same as \"no changes found\":", file=sys.stderr)
        for stage, label, n in problems:
            print(f"  [{stage}] {n} {label}", file=sys.stderr)
        sys.exit(_EXIT_PARTIAL_FAILURE)


def _safe_console():
    """db2_bugs.md DB2-24: on a default Windows console (cp1252) printing a character it
    can't encode (the → in a renamed-function label, the help text) raised
    UnicodeEncodeError and turned a finished run into "Error:" (exit 1). The console
    streams now replace such characters instead, and the worker processes Stage 2 spawns
    do the same (they read PYTHONIOENCODING at start; a value the user set is kept)."""
    tolerant = ("replace", "backslashreplace", "namereplace", "xmlcharrefreplace", "ignore")
    for stream in (sys.stdout, sys.stderr):
        try:
            # strict and surrogateescape (what Python picks for a redirected stream) both
            # raise on a character the encoding lacks
            if stream is not None and getattr(stream, "errors", None) not in tolerant:
                stream.reconfigure(errors="replace")
        except (AttributeError, ValueError, OSError):
            pass
    os.environ.setdefault("PYTHONIOENCODING", ":replace")


def main(argv=None):
    _safe_console()
    parser = argparse.ArgumentParser(
        prog="patch-differ",
        description="Standalone patch differ — triage → source diff → binary function diff",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # patch-differ run
    p_run = sub.add_parser("run", help="Run all three stages (triage + stage1 + stage2)",
                           formatter_class=argparse.RawDescriptionHelpFormatter)
    _add_common(p_run)
    p_run.set_defaults(func=cmd_run)

    # patch-differ triage
    p_triage = sub.add_parser("triage", help="Run Stage 0 (file triage) only",
                              formatter_class=argparse.RawDescriptionHelpFormatter)
    _add_common(p_triage)
    p_triage.set_defaults(func=cmd_triage)

    # patch-differ stage1
    p_s1 = sub.add_parser("stage1", help="Run Stage 0 + Stage 1 (readable source diff)",
                           formatter_class=argparse.RawDescriptionHelpFormatter)
    _add_common(p_s1)
    p_s1.set_defaults(func=cmd_stage1)

    # patch-differ stage2
    p_s2 = sub.add_parser("stage2", help="Run Stage 0 + Stage 2 (binary function diff)",
                           formatter_class=argparse.RawDescriptionHelpFormatter)
    _add_common(p_s2)
    p_s2.set_defaults(func=cmd_stage2)

    # patch-differ show
    p_show = sub.add_parser("show", help="Print results from a previous run")
    p_show.add_argument("--out", required=True, metavar="DIR",
                        help="Output directory of a completed run")
    p_show.set_defaults(func=cmd_show)

    args = parser.parse_args(argv)
    try:
        args.func(args)
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        sys.exit(130)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()