"""Shared parallel execution + resource governance for Stage-2 backends.

Stage 2 (per-binary function diff) is embarrassingly parallel and deterministic, so each
changed binary runs in its own process. This is centralised so BOTH the MSSQL (PE/PDB)
and DB2 (ELF/.symtab) backends get identical host-friendly behaviour:

  * conservative worker cap — the tool typically shares a host with the live app, so a
    run uses only ~half the cores (capped), never all of them;
  * below-normal worker priority — even while all diff workers are busy, the OS keeps the
    host and the live app responsive (the diff yields rather than competes);
  * size-weighted live progress — the bar tracks real work (big binaries dominate), not
    the number of binaries.

Override the cap with CVE_PATCHDIFF_WORKERS (=1 forces sequential, in-process).

Windows uses the 'spawn' start method (no fork); the per-binary `process` function must be
module-level/picklable and take (job, report).
"""
import concurrent.futures as cf
import multiprocessing
import os
import queue

_MAX_DEFAULT_WORKERS = 6
_PROG_Q = None   # set in each pool child by the initializer


def lower_priority():
    """Drop this (worker) process to below-normal CPU priority — best-effort, no deps."""
    try:
        if os.name == "nt":
            import ctypes
            BELOW_NORMAL_PRIORITY_CLASS = 0x00004000
            k32 = ctypes.windll.kernel32
            k32.SetPriorityClass(k32.GetCurrentProcess(), BELOW_NORMAL_PRIORITY_CLASS)
        else:
            os.nice(10)
    except Exception:
        pass


def _init_worker(q):
    global _PROG_Q
    _PROG_Q = q
    lower_priority()


def emit(rel, pct, phase):
    """Worker-side: stream a per-binary progress tick back to the parent."""
    if _PROG_Q is not None:
        try:
            _PROG_Q.put_nowait((rel, pct, phase))
        except Exception:
            pass


_MEMORY_SHARE = 0.75      # of physical RAM that concurrent Ghidra heaps may reserve


def worker_count(n, heaps=()):
    """Binaries to diff in parallel. Conservative so a run leaves the host (and the live
    app) responsive: ~half the cores, capped, never more than the number of binaries.
    CVE_PATCHDIFF_WORKERS overrides (=1 -> sequential in-process).

    `heaps` are the Java heaps (bytes) of the jobs that run Ghidra. Without an override the
    count is lowered until the largest such heaps running at once fit in 75% of physical
    RAM (db2_bugs.md DB2-11), so big binaries are not analysed side by side into swapping."""
    env = os.environ.get("CVE_PATCHDIFF_WORKERS")
    if env:
        try:
            w = int(env)
            if w >= 1:
                return min(w, n)
        except ValueError:
            pass
    cpu = os.cpu_count() or 4
    w = max(1, min(n, cpu // 2, _MAX_DEFAULT_WORKERS))
    if heaps:
        from . import tool_paths as tp
        ram = tp.physical_memory()
        if ram:
            biggest = sorted(heaps, reverse=True)
            while w > 1 and sum(biggest[:w]) > ram * _MEMORY_SHARE:
                w -= 1
    return w


# Measured Ghidra import+analysis rate on large binaries (live MSSQL run: sqlmin.dll 49.8 MiB
# in 7,284-8,121 s, sqllang.dll 46.2 MiB in 5,594-6,378 s). Smaller binaries are faster
# (sqltses.dll 9 MiB: ~42 s/MiB), so an estimate from it is an upper end.
_GHIDRA_SECONDS_PER_MIB = 160


def bindiff_plan_note(jobs, weights, workers):
    """db2_bugs.md DB2-12: before any Ghidra work starts, say how much of it there is —
    how many binaries, their total size, the largest, and a rough time — so a run of
    hundreds of libraries isn't discovered hours in. Returns the note (None if no job uses
    BinDiff)."""
    bd = [j for j in jobs if j.get("use_bindiff") and not j.get("one_sided")]
    if not bd:
        return None
    mib = 1 << 20
    sizes = sorted(((max(1, weights.get(j["rel"], 1)), j["rel"]) for j in bd), reverse=True)
    total = sum(s for s, _ in sizes)
    hours = 2 * total / mib * _GHIDRA_SECONDS_PER_MIB / 3600        # prior + fixed
    return (f"NOTE: BinDiff will analyse {len(bd)} binary(ies) with Ghidra, both builds of "
            f"each ({total / mib:.0f} MiB per build; largest {sizes[0][1]}, "
            f"{sizes[0][0] / mib:.1f} MiB). Rough estimate: up to about {hours:.1f} h of "
            f"Ghidra analysis, {workers} at a time. --bindiff-only GLOB limits which "
            f"binaries use BinDiff.")


def _ghidra_heaps(jobs, weights):
    """Java heap of every job that runs BinDiff's Ghidra analysis (weights = input bytes)."""
    if not any(j.get("use_bindiff") for j in jobs):
        return ()
    from . import tool_paths as tp
    return [tp.ghidra_heap(weights.get(j["rel"], 0)) for j in jobs if j.get("use_bindiff")]


def _pool_call(process, job):
    """Pool-child entry: run one binary's diff, streaming progress via the shared queue."""
    return process(job, emit)


def run_jobs(jobs, process, weights, progress=None, on_result=None, on_error=None):
    """Run `process(job, report)` for every job, in a process pool (or in-process when the
    worker cap is 1). Aggregation is the caller's job via `on_result`.

      jobs      list of picklable dicts, each with a 'rel' key (its binary path/id)
      process   module-level picklable fn(job, report) -> result dict (must carry 'rel');
                `report(rel, pct, phase)` reports 0..100 local progress (optional to call)
      weights   {rel: positive number} for size-weighted global progress
      progress  global callback(pct, phase)
      on_result callback(result) invoked once per completed job (completion order)
      on_error  callback(rel, exc) invoked once per job whose `process()` call raised.
                Without this, a failed job is only ever logged to stderr and otherwise
                vanishes — the caller has no way to tell "nothing changed" apart from
                "this binary couldn't be analyzed." Optional, so existing callers that
                don't pass it keep today's behavior exactly.

    Results are order-independent (callers sort), so pool scheduling never changes output.
    """
    local = {j["rel"]: 0.0 for j in jobs}
    total_w = sum(max(1, weights.get(j["rel"], 1)) for j in jobs) or 1
    state = {"phase": "Starting binary diff"}

    def push():
        if progress:
            gp = 3 + int(94 * sum(max(1, weights.get(r, 1)) * local[r]
                                  for r in local) / (100.0 * total_w))
            progress(min(99, gp), state["phase"])

    def note(rel, pct, phase):
        local[rel] = pct
        state["phase"] = phase

    workers = worker_count(len(jobs), _ghidra_heaps(jobs, weights))
    plan = bindiff_plan_note(jobs, weights, workers)
    if plan:
        import sys
        print(plan, file=sys.stderr)
    if workers <= 1:
        for job in jobs:
            def rep(rel, pct, phase):
                note(rel, pct, phase); push()
            try:
                r = process(job, rep)
                local[job["rel"]] = 100.0
                if on_result:
                    on_result(r)
            except Exception as _exc:
                import sys
                print(f"[patch-differ] worker failed for {job['rel']}: {_exc}",
                      file=sys.stderr)
                local[job["rel"]] = 100.0   # a binary failed — skip it, keep going
                if on_error:
                    on_error(job["rel"], _exc)
            push()
        return

    ctx = multiprocessing.get_context("spawn")
    mgr = ctx.Manager()
    q = mgr.Queue()
    try:
        with cf.ProcessPoolExecutor(max_workers=workers, mp_context=ctx,
                                    initializer=_init_worker, initargs=(q,)) as ex:
            futs = {ex.submit(_pool_call, process, job): job["rel"] for job in jobs}
            pending = set(futs)
            while pending:
                drained = 0
                try:
                    while drained < 200:
                        rel, pct, phase = q.get(timeout=0.2)
                        note(rel, pct, phase); drained += 1
                except queue.Empty:
                    pass
                if drained:
                    push()
                for f in list(pending):
                    if f.done():
                        pending.discard(f)
                        try:
                            r = f.result()
                            local[futs[f]] = 100.0
                            if on_result:
                                on_result(r)
                        except Exception as _exc:
                            import sys
                            print(f"[patch-differ] worker failed for {futs[f]}: {_exc}",
                                  file=sys.stderr)
                            local[futs[f]] = 100.0   # a binary failed — skip it, keep going
                            if on_error:
                                on_error(futs[f], _exc)
                        push()
    finally:
        mgr.shutdown()