"""Dev scratch script — not part of the pipeline, not imported by any package code.
Exercises mssql/acquire.py's extraction steps directly against whatever installer .exe
is already sitting in patches/mssql/vuln/, using the package's own default layout so it
works on any checkout without a hardcoded, machine-specific path."""
import sys, os, traceback
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

_ROOT = Path(__file__).parent

try:
    from patch_differ_cli.mssql.acquire import extract_engine, sevenzip, _carve_cabs, _7z_extract
    print("7zip path:", sevenzip())

    vuln_dir = _ROOT / "patches" / "mssql" / "vuln"
    vuln_exe = next(os.path.join(vuln_dir, f) for f in os.listdir(vuln_dir) if f.endswith(".exe"))
    print("exe path :", vuln_exe)
    print("exe exists:", os.path.isfile(vuln_exe))

    cab_dir = _ROOT / "runs" / "mssql" / "acquire" / "vuln" / "cabs"
    eng_dir = _ROOT / "runs" / "mssql" / "acquire" / "vuln" / "engine"

    print("\n--- Carving CABs ---")
    _carve_cabs(vuln_exe, cab_dir)
    cabs = [f for f in os.listdir(cab_dir) if f.endswith(".cab")]
    print(f"Found {len(cabs)} CABs: {cabs[:5]}")

    if cabs:
        biggest = sorted(
            [os.path.join(cab_dir, f) for f in cabs],
            key=lambda p: os.path.getsize(p), reverse=True
        )[0]
        print(f"\n--- Extracting biggest CAB: {biggest} ---")
        msp_stage = str(eng_dir) + "_msp"
        _7z_extract(biggest, msp_stage)
        print("CAB extraction SUCCESS")

    print("\n--- Full extract_engine ---")
    extract_engine(vuln_exe, eng_dir, cab_dir)
    print("extract_engine SUCCESS")

except Exception:
    traceback.print_exc()
