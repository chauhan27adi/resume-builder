# Patch Differ CLI: Simple Project Guide

## What this project does

`patch_differ_cli` compares two versions of a database product:

- the older, vulnerable version
- the newer, patched version

It looks for files and program functions that changed. It can also compare those changes
with CVE information that you provide. Its main purpose is to help a person investigate a
security patch.

It does **not** prove that a product is safe, or prove that a change fixes a particular
CVE. Review the results before drawing a security conclusion.

## How the project is organized

- `cli.py` reads commands such as `run` and `show`.
- `pipeline.py` prepares the input folders and runs the requested analysis stages.
- `mssql/`, `db2/`, and `oracle/` contain the steps that understand each database's files.
- Files whose names start with `_` at the project root contain shared work, such as
  function matching, disassembly, result formatting, and CVE matching.
- `tests/` contains automated tests for important behavior.
- `docs/PREREQUISITES.md` has the detailed tool and setup requirements.

## The analysis workflow

The complete `run` command follows these stages:

1. **Triage (Stage 0):** Look through the two input versions and decide which files changed.
   It tries to separate code changes from rebuild noise and ordinary content changes.
2. **Readable diff (Stage 1):** Compare changed items that can be read as source, scripts,
   SQL, or Java. The exact items depend on the database.
3. **Binary diff (Stage 2):** Compare changed program files and, where symbols are available,
   report changes at the function level. The normal matcher uses function names. The
   optional `--use-bindiff` mode uses Ghidra and BinDiff to match functions by their
   structure instead.
4. **CVE matching (optional):** If you supply a CVE JSON file, the project compares CVE
   information with changed function names and other change signals. A result may be shown
   as an asserted CVE or as a candidate; both need human review.

The three database backends use different file formats:

- **MSSQL:** Looks at executable parts of Windows program files. It also compares readable
  SQL: system objects (procedures, views, functions) from the resource database, loose
  script files, and T-SQL embedded in script DLLs, including files added or removed by the
  patch. If the resource database is missing on either side, only the system-object part
  is skipped — it is listed under `unavailable_parts` and reported as a partial result —
  while the scripts and embedded T-SQL are still compared. Symbol lookup uses public PDB
  information when available.
- **DB2:** Looks at executable parts of Linux program files, as well as changed libraries,
  scripts, and text files.
- **Oracle:** Compares extracted patch files, reads supported PL/SQL files, and can compare
  native object files. Some Windows binary results are file-level only.

## A practical workflow

### 1. Set up Python

Python 3.11 or newer is required. From the folder containing `patch_differ_cli`, install
the project and its required Python packages:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -e .\patch_differ_cli
```

For the optional Ghidra-based modes, see `PREREQUISITES.md`. MSSQL patch acquisition also
needs 7-Zip. Oracle patch files must be downloaded and extracted by the user.

### 2. Prepare the two versions

Use one folder for the vulnerable version and another for the fixed version. You can pass
their paths directly. If you do not pass paths, the defaults are
`patch_differ_cli/patches/<database>/vuln/` and
`patch_differ_cli/patches/<database>/fixed/`.

Some downloads can be automated:

- **MSSQL:** Provide the vulnerable and fixed KB numbers with `--vuln-kb` and `--fixed-kb`.
- **DB2:** Provide both versions with `--vuln-url` and `--fixed-url`. Container downloads
  use the registry directly; manual Fix Central archives must be placed in the requested
  output acquisition folders.
- **Oracle:** Place the extracted vulnerable and fixed patch contents in their input
  folders. Automatic download is not supported.

### 3. Run the comparison

Example using folders you already prepared:

```powershell
patch-differ run --db mssql `
  --vuln "C:\patches\old" `
  --fixed "C:\patches\new" `
  --out "C:\patches\results"
```

Change `mssql` to `db2` or `oracle` for those backends. To do only part of the work, use
`triage`, `stage1`, or `stage2` instead of `run`. The `stage1` and `stage2` commands also
run triage first.

Optional switches:

- `--cves FILE` supplies CVE records in JSON format.
- `--use-bindiff` asks for structure-based function matching; it needs Ghidra with
  BinExport and BinDiff.
- `--decompile` asks Ghidra to produce readable pseudo-C for selected changed functions.
- `--reattribute` updates CVE matches in an existing Stage 2 result without repeating the
  binary analysis.

### 4. Read the results

The output folder contains:

- `stage0/changed_files.json` — the file-change list and triage counts.
- `stage1/modules_diff.json` — readable-source results, any errors, and any parts of the
  stage that could not run (`unavailable_parts`).
- `stage2/functions_diff.json` — function-level results, CVE matches, and any failures.

The stages can also save individual diff and detail files beside these JSON summaries.
Use this command to print a short summary from a previous run:

```powershell
patch-differ show --out "C:\patches\results"
```

`show` displays only results that belong to the latest comparison. A Stage 1 or
Stage 2 result left over from an earlier run (triage was re-run, or the inputs
changed, without that stage) is not shown, and a note says so.

Pay attention to `errors`, `failed`, `skipped_functions` (changed functions too
large to diff), `bindiff_fallbacks` (binaries `--use-bindiff` couldn't match with
BinDiff), `unavailable_parts`, or an `available: false` result.
They mean that some part of the input could not be checked, so an empty-looking result is
not necessarily a verified finding of “no changes.”

The CLI uses these important exit codes:

- `0`: analysis completed without reported partial failures.
- `1`: a hard error occurred, or `show` found no results.
- `2`: the command or its arguments were invalid; analysis did not start.
- `3`: analysis ran, but one or more items could not be checked. Treat this as an
  incomplete result.
- `130`: the run was interrupted.

## What the tagged test checks

`tests/test_bindiff_matching.py` checks a specific reporting bug across MSSQL, DB2, and
Oracle. Sometimes BinDiff can match a function by its address even though only one version
has a usable function name. The test makes sure that this function still appears in the
report as removed instead of disappearing completely.

The test uses made-up matches and mocked file/symbol handling. It checks the program's
reporting logic; it does not run Ghidra or BinDiff on real database binaries.

## Tests and limits

The test suite was run from the workspace with:

```powershell
python -m unittest discover -s .\patch_differ_cli\tests -v
```

Result: **636 tests passed**.

Tests help catch known mistakes, but they cannot guarantee that every patch format or
database build will be analyzed correctly. Check the error and availability fields, inspect
the relevant diffs, and confirm important findings independently.
