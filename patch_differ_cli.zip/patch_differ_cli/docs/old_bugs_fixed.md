# Code Review Findings

This file lists bugs and risks found during the end-to-end review of `patch_differ_cli`.
The test suite passed, but the issues below can still cause unsafe extraction or
incomplete/misleading analysis results.

## High severity

1. **DB2 tar extraction can write files outside the extraction folder**
   - **Location:** `db2/acquire.py` — `_extract_layers()`, `_extract_tar()`, and
     `_extract_component_stream()`.
   - **Problem:** Archive member paths are joined to the destination without checking
     that the final path stays inside it. A path containing `..` can escape the
     extraction folder.
   - **Impact:** A crafted or compromised archive could write or overwrite files
     elsewhere that the current user can access.
   - **Evidence:** A synthetic tar archive was extracted in a temporary test folder and
     wrote a file outside the requested destination.
   - **Suggested fix:** Normalize and resolve each target path, reject paths outside
     the extraction root, and apply the same check to all three extraction functions.

## Medium severity

2. **DB2 OCI whiteouts do not fully remove lower-layer files**
   - **Location:** `db2/acquire.py` — `_extract_layers()`.
   - **Problem:** A whiteout is matched only against an exact file path. A directory
     whiteout does not suppress files beneath that directory, and opaque-directory
     whiteouts are not handled.
   - **Impact:** The reconstructed DB2 image may retain files deleted by later layers.
     Those stale files can distort the comparison.
   - **Evidence:** A synthetic two-layer image with a directory whiteout still had the
     deleted lower-layer file after extraction.
   - **Suggested fix:** Implement OCI semantics for file whiteouts, directory
     whiteouts, and opaque-directory whiteouts, with tests for each case.

3. **Added and removed files are not consistently sent through analysis**
   - **Locations:** `mssql/triage.py`, `db2/stage1.py`, `db2/stage2.py`,
     `oracle/triage.py`, and `oracle/stage2.py`.
   - **Problem:** Some stages compare only files present on both sides. MSSQL triage
     considers only the directory intersection. DB2 Stage 1 omits added/removed scripts,
     and DB2 Stage 2 filters out binaries missing on either side. Oracle records removed
     files separately, but Stage 2 does not analyze that list; Oracle archive analysis
     also considers only common members.
   - **Impact:** Changes that add or remove a binary, script, or archive member can be
     missing from detailed results.
   - **Suggested fix:** Route additions and removals explicitly to the right stage and
     produce a result for them instead of filtering them out.

4. **Track 1 result selection can vary between runs for DB2 and Oracle**
   - **Locations:** `db2/stage2.py` — BinDiff hit sorting; `oracle/stage2.py` —
     BinDiff hit sorting.
   - **Problem:** The sorts do not include a stable function-name tie-breaker.
     BinDiff match rows are read without a guaranteed order. If many results tie and
     the output cap is reached, the input order can affect which results are retained.
   - **Impact:** Identical inputs may produce different subsets of detailed function
     results across runs.
   - **Suggested fix:** Add stable function-name tie-breakers and tests that shuffle
     match order with more results than each backend's output cap.

5. **Track 1 Oracle address mapping does not account for separate ELF sections**
   - **Location:** `oracle/stage2.py` — Oracle function mapping and BinDiff address
     lookup.
   - **Problem:** Oracle function maps can include functions from multiple `.text*`
     sections, but BinDiff addresses are calculated using a single base plus
     section-relative `st_value`. The section's actual placement is not included.
   - **Impact:** Functions in multi-section object files may map to the wrong address
     or collide, leading to incorrect matches or added/removed classifications.
   - **Suggested fix:** Keep section identity and use each section's actual Ghidra
     placement when resolving BinDiff addresses. Otherwise, explicitly limit or flag
     this mode for multi-section objects.

6. **MSSQL PE parse failures can be treated as ordinary content**
   - **Location:** `mssql/triage.py` — `_code_sig()` and `run()`.
   - **Problem:** `_code_sig()` returns `None` when PE parsing fails. Triage also uses
     `None` to represent a non-PE file, so a damaged or unreadable DLL/EXE may be
     treated as content instead of a failed code analysis.
   - **Impact:** A binary may miss Stage 2 without increasing the partial-failure
     count, making the run appear more complete than it is.
   - **Suggested fix:** Distinguish expected non-PE files from expected PE files that
     fail parsing, and record the latter as analysis errors.

## Low severity

7. **Track 2 may count partial pseudo-C output as a successful decompile**
   - **Locations:** `_decompile.py` — `decompile_pair()`; the backend Stage 2 result
     counters; `cli.py` — partial-failure detection.
   - **Problem:** The decompiler reports failure only when both sides produce no output.
     If only one side produces pseudo-C, it is returned as a successful attempt. Also,
     the CLI does not include `decompile_failed` in its partial-failure checks.
   - **Impact:** A requested before/after decompilation may be incomplete without
     changing the command's exit status to indicate partial results.
   - **Suggested fix:** Track success separately for each side, report one-sided output
     as partial, and decide whether decompile failures should trigger a warning or a
     partial-failure exit when `--decompile` is used.

## Additional findings from the follow-up review

These findings were checked against the seven items above and describe separate failure
modes.

### Medium severity

8. **DB2 acquisition can mistake an interrupted extraction for a complete build**
   - **Location:** `db2/acquire.py` — `_find_version_dir()` and `acquire()`.
   - **Problem:** On a later run, any directory whose name starts with `V` under
     `opt/ibm/db2` is accepted as an existing build. The check does not confirm that
     extraction finished or that required files are present. If a run stops after
     creating the version directory, the next run skips acquisition and analyzes the
     partial tree.
   - **Impact:** Files missing from the incomplete extraction can be omitted from
     comparison while acquisition reports that the build was already extracted.
   - **Evidence:** A temporary tree containing only a partial `V11.5` directory was
     returned by `_find_version_dir()` as a valid version directory.
   - **Suggested fix:** Mark extraction complete only after successful extraction and
     validation, and require that completion marker (or validated required files)
     before reusing an existing tree.

9. **Different Oracle archive members can overwrite each other's extracted object**
   - **Location:** `oracle/_ar.py` — `extract_o()`.
   - **Problem:** Member names are flattened by replacing `/` and `\\` with `_` for the
     output filename. Distinct names such as `a/b.o` and `a_b.o` therefore map to the
     same destination. The later member overwrites the earlier one, while the returned
     mapping still contains both names pointing to that single file.
   - **Impact:** Oracle Track 1 can analyze the later member's bytes under both member
     names, producing missing, duplicated, or incorrect function comparisons.
   - **Evidence:** A synthetic `.a` archive with those two members caused both mapping
     entries to point to one path, whose contents were only the second member's bytes.
   - **Suggested fix:** Preserve member-path uniqueness in the extracted filenames
     (for example, use a collision-resistant encoding or unique per-member path) and
     add a regression test for colliding flattened names.

10. **Oracle Java decompilation failures can silently remove changed classes from results**
    - **Locations:** `oracle/java_decompile.py` — `decompile_jar()`; `oracle/stage1.py` —
      changed-jar processing.
    - **Problem:** The CFR subprocess return code is ignored, and its output is
      suppressed. If it fails without producing Java files, `decompile_jar()` returns
      zero; Stage 1 ignores that return value and indexes an empty output directory.
      The run can therefore finish without reporting an error or any results for the
      changed jar. The `javap` fallback likewise does not check subprocess return codes.
    - **Impact:** Changed OJVM Java classes can be absent from the analysis while the
      Stage 1 result still reports itself as available.
    - **Evidence:** With the CFR subprocess mocked to return exit code 17 and produce no
      files, `decompile_jar()` returned zero; the Stage 1 caller has no check of that
      result and builds its class indexes from the empty directory.
    - **Suggested fix:** Check the tool's exit status and expected output, return
      explicit failure details, and add that failure to the Stage 1 `errors` list
      instead of silently continuing with an empty class set.

11. **Acquisition can reuse a previous build even when a different source is requested**
    - **Locations:** `db2/acquire.py` — `acquire()` and `_find_version_dir()`; and
      `mssql/acquire.py` — `acquire()`.
    - **Problem:** DB2 acquisition treats any existing `opt/ibm/db2/V*` directory as
      reusable, without comparing the requested container reference or manual label.
      MSSQL acquisition similarly accepts an existing `engine/` directory containing
      any `ENG_*` file without comparing its KB to the requested KB. Re-running with a
      different source can therefore return the old extracted tree without acquiring
      the requested build.
    - **Impact:** The comparison may analyze the wrong DB2 or MSSQL builds and produce
      a plausible but invalid patch result. This differs from finding 8: the reused
      tree can be fully extracted; it is simply for a different requested source.
    - **Evidence:** With an existing temporary `V11.5` directory and
      `container:registry.example/db2:new-tag` as the requested source, DB2 `acquire()`
      returned the existing directory and did not call the acquisition function. With
      an existing MSSQL `engine/ENG_old.dll` and KB `9999999` requested, MSSQL
      `acquire()` likewise returned the existing engine without resolving the KB.
    - **Suggested fix:** Store the source reference alongside the extracted tree and
      reuse it only when the requested reference matches; otherwise acquire into a
      separate keyed directory or clearly require explicit cleanup.

12. **Sanitized Stage 2 paths can collide and share concurrent BinDiff workspaces**
    - **Locations:** `db2/stage2.py` and `mssql/stage2.py` — `_safe()` and BinDiff
      workspace construction; shared `_parallel.py` job execution.
    - **Problem:** Binary-relative paths are converted to workspace names by replacing
      disallowed characters with underscores and truncating to 120 characters. Distinct
      paths such as `lib/private/api.so` and `lib_private_api.so` then resolve to the
      same BinDiff work directory. Stage 2 may process those binaries concurrently, so
      both jobs can modify the same Ghidra project and BinDiff output directory.
      Sanitized function-card filenames can collide for the same reason, overwriting
      one function's diff/detail files with another's.
    - **Impact:** With `--use-bindiff`, one binary's export or match output can be
      overwritten or removed by the other worker, causing incorrect matching or a
      per-binary fallback. Card filename collisions can also make result entries point
      to another function's contents.
    - **Evidence:** The two distinct example paths produce the same `_safe()` value,
      and DB2 uses that value directly as its per-binary BinDiff workspace. The shared
      parallel runner can execute changed binaries in separate workers.
    - **Suggested fix:** Use a collision-resistant encoding or append a digest of the
      original path/name to generated workspace and artifact identifiers; add a
      concurrent regression test with colliding sanitized paths.

### Low severity

13. **Executable-section hashes discard earlier sections with duplicate names**
    - **Locations:** `mssql/triage.py` — `_code_sig()`; `db2/_elf.py` —
      `exec_section_sigs()`.
    - **Problem:** Both triage helpers store section hashes in a dictionary keyed only
      by section name. If an executable file contains multiple executable sections
      with the same name, each later section overwrites the earlier hash.
    - **Impact:** A code change confined to an earlier duplicate-named section can be
      missed by Stage 0 when the last section's hash is unchanged, so Stage 2 is never
      given that file to analyze.
    - **Evidence:** A focused mocked PE with two executable `.text` sections, where
      only the first section differed between builds, produced identical `_code_sig()`
      results because the second section overwrote the first.
    - **Suggested fix:** Include a stable section index (or another unique section
      identity) in the hash-map key, and add PE and ELF tests with duplicate executable
      section names.

## Findings from the deeper follow-up review

The following are additional to findings 1–13. These were investigated against the
current implementation; reproduction details below use temporary directories and
mocked tools, not production inputs.

### Critical

14. **DB2 triage can trust a stale acquisition manifest for different input trees**
    - **Confidence:** Confirmed.
    - **Location:** `db2/triage.py` — `run()` (lines 139–145).
    - **Trigger:** The output directory contains `acquire/manifest.json` from an earlier
      acquisition, and the user runs triage with new or manually supplied input trees
      but reuses that output directory.
    - **Failure scenario and observed behavior:** The existing manifest is loaded and
      `_from_manifest()` is returned before either input tree is walked. A temporary
      prior/fixed pair with different `config.bin` contents and a stale empty manifest
      produced zero changed files (`code_changed=0`, `content_changed=0`). A stale
      manifest that omits a changed library can likewise prevent that library from
      reaching Stage 2.
    - **Impact:** Real changes in the current builds can be missed and the run can
      present an empty, successful-looking triage result.
    - **Existing tests:** The repository's test suite has no test that reuses a manifest
      against different input directories. The existing full suite passing does not
      cover this state.
    - **Fix recommendation:** Bind the manifest to canonical input identities (source
      references plus tree/build hashes), and only use it when those identities match.
      Otherwise remove or ignore it and perform a fresh walk/hash.

15. **Oracle Stage 1 can compare stale decompiled Java after the JAR changes**
    - **Confidence:** Confirmed.
    - **Locations:** `oracle/stage1.py` — changed-JAR processing (lines 149–165);
      `oracle/java_decompile.py` — `decompile_jar()`.
    - **Trigger:** Stage 1 is rerun with the same work directory and JAR member path
      after either input JAR has changed.
    - **Failure scenario and observed behavior:** The decompilation directories are
      keyed only by the relative JAR path. If a directory already contains any files,
      Stage 1 skips decompilation without checking the current JAR content or a cache
      key. A two-run temporary reproduction changed both JARs from v1 payloads to v2;
      on the second run the decompiler was called only twice total (rather than once
      per side per run), and the new pair still contained v1 text and no v2 text.
    - **Impact:** Track 2 can display and diff source from an older build instead of
      the current JARs, causing false changes or missed security fixes while the stage
      appears to have completed.
    - **Existing tests:** No current test covers changed JAR content with a reused
      `stage1/decomp` directory.
    - **Fix recommendation:** Key the decompilation cache by the JAR content hash and
      relevant decompiler identity/options, or clear/rebuild the per-run output before
      processing. Write a regression test that mutates a JAR between two runs using
      the same work directory.

### Important

16. **DB2 Stage 1 ignores changed JAR contents when the reported version is unchanged**
    - **Confidence:** Confirmed.
    - **Location:** `db2/stage1.py` — dependency comparison (lines 98–105).
    - **Trigger:** A JAR has the same filename/artifact stem and the same manifest
      version (including both versions being absent), but its class contents differ.
    - **Failure scenario and observed behavior:** Two temporary JARs named
      `dependency.jar` contained different same-length `Example.class` payloads and no
      manifest version. Stage 1 returned zero readable dependency changes because it
      compares only the version values and skips when those match.
    - **Impact:** A real library code change, including a security fix shipped without
      a version-string change, is omitted from the readable results.
    - **Existing tests:** No test covers differing JAR bytes with equal or absent
      manifest versions.
    - **Fix recommendation:** Treat equal versions as a no-change result only when
      the JAR content hashes also match; otherwise emit a changed-content result or
      diff the class contents.

17. **Malformed CVE JSON is silently downgraded to no attribution**
    - **Confidence:** Confirmed.
    - **Location:** `_attribution.py` — `load_attrib()` (lines 240–259).
    - **Trigger:** `cves.json` exists in the work directory but is malformed or has an
      unexpected shape, and no usable `meta.json` fallback is present.
    - **Failure scenario and observed behavior:** A temporary work directory with
      invalid JSON returned an empty attribution list without raising or emitting a
      diagnostic.
    - **Impact:** Analysis can complete with missing CVE attribution, indistinguishable
      from a valid run that simply had no matching CVEs.
    - **Existing tests:** `tests/test_attribution.py` covers valid CVE JSON, precedence,
      and records with no usable attribution signal, but not malformed JSON or invalid
      record shapes.
    - **Fix recommendation:** Report the parse/validation failure explicitly; only
      fall back to `meta.json` when that fallback is intentional and record it in the
      result diagnostics.

## Validation performed

- Baseline full test suite: **154 tests passed** with
  `python -m unittest discover -s .\patch_differ_cli\tests -v`.
- The DB2 tar path-traversal and directory-whiteout findings were reproduced using
  synthetic archives in temporary folders.
- Follow-up checks reproduced the DB2 partial-extraction acceptance, Oracle archive
  member filename collision, and ignored CFR failure return code using temporary
  inputs/mocks.
- This review reproduced DB2 reuse across a changed requested source, a DB2 sanitized
  BinDiff-workspace collision, and a missed changed PE executable section with a
  duplicate section name.
- The deeper follow-up reproduced stale DB2 manifest use, stale Oracle JAR
  decompilation reuse, unchanged-version JAR omission, malformed CVE JSON returning
  no attribution, and MSSQL acquisition reuse across requested KBs. These were
  focused temporary-input/mock checks; no new regression tests were added because
  production changes were not requested.
- Passing tests do not rule out the findings above; current tests do not cover these
  specific cases.
