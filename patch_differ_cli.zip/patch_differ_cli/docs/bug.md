# DB2 Track-1 (BinDiff) — end-to-end code review

**Scope:** the DB2 database path, end-to-end, with emphasis on **Track 1** (the opt-in
`--use-bindiff` Ghidra + BinExport + BinDiff flow). Reviewed: `pipeline.py` (DB2
orchestration), `db2/acquire.py` (staging), `db2/triage.py` (Stage 0), `db2/stage1.py`
(readable diff), `db2/stage2.py` (Stage 2 — name mode **and** BinDiff mode), `db2/_elf.py`,
`db2/_paths.py`, `_bindiff.py` (Track-1 engine), `_decompile.py`, `_parallel.py`,
`_x86diff.py`, and the newly-added per-version output layout (`_layout.py`).

**Method:** read-only review; no production code changed. Reasoning is given so each finding
can be confirmed independently. Severities: **Medium** = can cause a real but bounded wrong
or missing result under a supported configuration; **Low** = correctness unaffected, but a
usability / hygiene / efficiency gap worth fixing.

The DB2 path is mature and heavily hardened (see `old_bugs_fixed.md` /
`olde_bugs_fixed_2.md`, DB2-1..26 and bugs.md #1..63). The findings below are the issues
that survived that history or were introduced by the recent output-layout work.

---

## DB2-T1-1 — `--use-bindiff` (success path) skips lever-3 data-section diffing  —  **Medium**

**Where:** `db2/stage2.py`, `_process_file()`. The BinDiff branch
(`if use_bd and bd_failed_reason is None:`, ~L958–L1085) never calls `_data_changes()`.
Only the name-mode `else` branch (~L1100–L1131) builds `data_hits` and emits data cards.

**What:** lever 3 (`PATCHDIFF_DATA_DIFF=1`, `_DATA_DIFF`) detects a function whose **code is
unchanged** but whose referenced `.rodata`/`.data` content changed (a constant, table, or
bounds value — exactly the shape of a data-only security fix). In the BinDiff branch such a
function scores similarity `1.0` with byte-identical code and is **skipped** at L984
(`m.similarity >= 1.0 and P[name_p][1] == F[name_f][1]`), and no data pass runs — so it is
reported nowhere. In the default (name-mode) path the same function is caught by the data
diff.

**Impact:** with `--use-bindiff` **and** `PATCHDIFF_DATA_DIFF=1` together, a data-only fix
that the default path surfaces is silently missed. Note both features are opt-in, and
`PATCHDIFF_DATA_DIFF` is off by default ("kept as a foundation", L516–L518), which bounds
real-world exposure — but the two options are not documented as mutually exclusive, so the
combination looks supported and silently loses coverage.

**Suggested fix:** run the lever-3 data pass over BinDiff-matched same-slot pairs in the
BinDiff branch too (reuse `_data_reader` / `_data_changes` as the `else` branch does), or, at
minimum, emit a one-line warning when `_DATA_DIFF and use_bindiff` that data cards are not
produced in BinDiff mode.

---

## DB2-T1-2 — no upfront warning when `--use-bindiff` is given without Ghidra  —  **Low**

**Where:** `pipeline.py`, ~L738–L749. The pre-flight only warns for `--decompile`
(`if decompile and not _tp.analyze_headless():`, the DB2-5 fix). There is no equivalent
`if use_bindiff and not _tp.analyze_headless():` check.

**What:** when `--use-bindiff` is requested but Ghidra is absent, each binary runs
`diff_pair()` → `ghidra_binexport()` → raises `GhidraNotConfigured`, which Stage 2 catches
per binary and falls back to name matching (recorded as a bindiff fallback, exit 3). The run
is correct, but the user gets no early, clear message — only a per-binary fallback after the
(potentially long) extraction, exactly the surprise DB2-5 removed for `--decompile`.

**Impact:** poor UX / wasted time; the user may believe BinDiff ran when every binary quietly
fell back. No wrong results.

**Suggested fix:** mirror the DB2-5 warning: when `use_bindiff and not analyze_headless()`,
print one upfront WARNING that BinDiff needs Ghidra and that the run will fall back to
name-based matching.

---

## DB2-T1-3 — BinDiff intermediates written into the Stage 2 output directory, never cleaned  —  **Low**

**Where:** `db2/stage2.py`, `_process_file()` ~L934: `bd_workdir = os.path.join(out, _safe(rel))`
(`out` is the `stage2/` dir). `diff_pair()` then creates `<bd_workdir>/bindiff/ghidra_proj/`
(a full Ghidra project — hundreds of MB to several GB for `libdb2e.so.1`), the two
`.BinExport` files, `_short_input` hard-link aliases, and `*.import.log` / `*.export.log` /
`differ.log`. Nothing removes any of it. (MSSQL does the same, so this is shared behaviour,
but it is squarely on the DB2 Track-1 run.)

**What / impact:** a Track-1 DB2 run leaves large Ghidra projects and exports **inside** the
result directory, intermixed with the clean per-version folders this layout just introduced —
e.g. an intermediates folder `stage2/lib_libdb2e.so.1/` sits right next to the result folder
`stage2/disassembled_instructions_vuln_<v>/lib_libdb2e.so.1_<sha8>/`. The output dir balloons
and the structure is harder to read; a second run re-uses the cached exports (good) but the
clutter persists.

**Suggested fix:** place BinDiff working data under a sibling of `stage2/` (e.g.
`<workdir>/bindiff_work/<safe_rel>/`) rather than inside `out`, and/or prune the Ghidra
project after a successful export (the `.BinExport` + `.sha256` sidecar is the cache; the
project itself is only needed for the export-reuse-after-failure optimisation).

---

## Areas reviewed and found sound (no action)

- **Address mapping (`map_matches` / `_measured_offset`, `_bindiff.py` L599–L638):** the
  per-side offset is measured from BinDiff's own `(address, name)` pairs with a per-ELF-type
  default (ET_EXEC→0, ET_DYN/ET_REL→`0x100000`), and raises to force a name-mode fallback
  when no match resolves. Handles PIE/non-PIE, missing names, and dynsym-only sides correctly.
- **BinExport caching & failure handling (`ghidra_binexport`):** sidecar written only after a
  known-good non-empty export; OOM detected even on exit 0 (DB2-11); project-import record
  cleared before import and on export failure so a killed run never looks reusable; timeouts
  scale with input size (DB2-15).
- **Stale `.BinDiff` cleanup and single-result enforcement (`run_differ`).**
- **Identical/renamed/unnamed handling in BinDiff mode (bugs.md #53/#60/#62/#63):** sim 1.0
  is only skipped on byte-identical code; `sub_` pairs are diffed but excluded from
  new/removed; unmatched-both-sides names are re-paired by name.
- **Stage 0 triage (`triage.py`):** exec-section-hash code vs rebuild vs data classification,
  one-sided inventory (bugs.md #3), unindexable-dir handling (#24), pruned-tree detection
  (#48), and noise-folder skipping (DB2-21) all handled; keyed by name+occurrence not index
  (#13).
- **ELF parsing (`_elf.py`):** truncation raises `ElfParseError` instead of silently hashing
  partial data; 32/64-bit and endianness detected; non-x86-64 reported, not crashed.
- **New per-version layout (`_layout.py` + `db2/stage2.py`):** per-build / per-binary folders
  with `binary.json`, deterministic digest-suffixed function filenames (collision-safe via
  `safe_name`), VA addresses for ELF, lazy folder creation (no empty dirs), single hash per
  side, and the old-way fallback for jobs built without `version_dirs`. Covered by
  `tests/test_db2_version_layout.py`.
- **Concurrency:** each binary is an isolated `_parallel` job with its own `bd_workdir`;
  per-version parent dirs are created with `exist_ok=True`.

---
---

# DB2 Track-1 — second review pass

A deeper second pass over the layers the first pass only skimmed: `_parallel.py` (worker
pool), `_x86diff.py` (the normaliser/classifier both DB2 modes depend on), `db2/acquire.py`
(download + tar/fixpack extraction + member-diff manifest + pruning), `tool_paths.run_tool`
(the one place Track-1 launches Ghidra/BinDiff), and `db2/decompile.py`. Three new findings.

## DB2-T1-4 — `db2/decompile.py` is dead code (superseded, still Ghidra-invoking)  —  **Low**

**Where:** `db2/decompile.py` (whole 112-line module).

**What:** DB2's Stage 2 decompiles via the shared `_decompile.py` (`from .._decompile import
decompile_cached`, `db2/stage2.py:47`). `db2/decompile.py` — the *old* DB2-specific
per-function Ghidra decompiler (carve one function → `DecompileFunc.java`) — is imported by
**no** module and **no** test (verified: the `DecompileFunc.java` references elsewhere are to
the Ghidra *script* that the shared `_decompile.py` drives; `test_identity_and_inputs.py`
imports `mssql.decompile`, a different module — but that one is **also production-dead**, live
only to that test, see **MSSQL-T2-1**, not "still-live" as this note originally said). So the
DB2 copy is orphaned.

**Impact:** no runtime effect, but it is a maintenance / confusion trap: a reader sees two DB2
decompile implementations, and the dead one still describes a Ghidra `-postScript`
invocation, so it looks live. If something is ever wired to it by mistake it would run a
second, divergent decompile path. (Note the asymmetry: `mssql/decompile.py` is still
referenced by a test, `db2/decompile.py` is not.)

**Suggested fix:** delete `db2/decompile.py` (git history keeps it), or, if it is kept
deliberately, add a module-level docstring note that it is superseded by `_decompile.py` and
retained only for reference.

## DB2-T1-5 — large memory displacements are blanked, so an offset-only change is invisible  —  **Low**

**Where:** `_x86diff.py`, `norm()` L91–L97. A memory operand displacement with
`abs(d) <= 0x2000` is kept in `lines` (as `d<hex>`) and recorded in `imms`; a **larger**
displacement is rendered `[R+R*scale+D]` in **both** `lines` and `shape` with the value
discarded and **no** `imms` entry.

**What:** two functions that differ *only* in a displacement `> 0x2000` produce identical
`lines`, identical `shape`, and identical `imms`, so `classify()` returns `"same"` (name mode
skips it; BinDiff mode also hits `if cls in ("same","churn"): continue`). No diff card is
written even though the raw bytes differ (and triage's exec-section hash correctly routed the
binary to Stage 2). Shared with MSSQL, but it is on the DB2 Track-1 path too.

**Impact:** a genuine change to a large fixed offset (a field past ~8 KiB in a large struct, a
large stack-frame slot) is dropped silently. The exposure is narrow and largely *by design* —
large displacements are overwhelmingly addresses/relocations, which is exactly why they are
blanked, and real security constants are almost always small immediates (kept in full) or
small offsets `≤ 0x2000` (kept and delta-tracked). Flagged as a known blind spot, not a
regression.

**Suggested fix:** if worth closing, record large displacements in `imms` under a third kind
(e.g. `"D"`) so `classify()`'s per-kind dominant-shift test decides churn-vs-real for them the
same way it does for `"i"`/`"d"`, instead of discarding them unconditionally.

## DB2-T1-6 — tar extraction silently drops symlink members; 7-Zip path keeps them  —  **Low**

**Where:** `db2/acquire.py`: `_extract_tar()` L428 (`if not (m.isfile() or m.islnk()): continue`)
and `_extract_component_stream()` L578 — both skip a symlink member (`m.issym()`) with no
entry in `skipped` and no log line. The 7-Zip extraction path (`_7z_extract_archive`) does
create symlinks (and only tolerates/logs the ones it cannot, rc=2).

**What / impact:** the two extraction backends produce **different trees** for the same
fixpack when it contains symlinks. On the tar/tarfile path a member delivered as a symlink is
simply absent; if an *analysed* artifact (an engine `.so.1`, a bundled `.jar`) is ever shipped
as a symlink, it vanishes from that side's tree and Stage 0/Stage 2 would read it as
one-sided/missing rather than diff it — and the result would then depend on which extractor
ran. DB2 fixpacks normally ship the engine libraries as real files, so real-world exposure is
low, but the silent, unrecorded skip and the tar-vs-7z divergence are real.

**Suggested fix:** at minimum, record skipped symlinks in `skipped` (so they are surfaced as a
partial-extraction note rather than vanishing); better, resolve an intra-archive symlink to
its target's bytes the same way hard links (`#51`) are already copied, so both extractor paths
yield the same tree.

## Second pass — additionally reviewed and found sound

- **`run_tool` output capture (`tool_paths.py` L295–L352):** `proc.stdout` is the *full*
  combined output; `_trim_log` trims only the on-disk log, so `_oom_failure` /
  `_export_failure` scan the complete output — OOM/abort detection is not defeated by logging
  to a file.
- **Worker pool (`_parallel.py`):** `CVE_PATCHDIFF_WORKERS=1` runs in-process (mocks/fakes
  apply); heap-aware worker count keeps concurrent Ghidra heaps within 75% of RAM (DB2-11); a
  crashed worker is reported via `on_error`, not swallowed.
- **Member-diff manifest + pruning (`_write_manifest_and_prune`):** changed/added/removed are
  computed from version-dir-relative hashes; identical files are pruned from *both* sides and
  the trees are annotated `pruned_with` so Stage 0 only trusts the manifest for the exact pair
  (bugs.md #14/#48); a full-walk fallback over mutually-pruned trees cannot manufacture false
  added/removed.
- **Archive safety (`_member_rel` / `_safe_out`):** absolute, drive-qualified, `..`, and
  trailing-dot/space member names are rejected before any write (bugs.md #1); hard links are
  copied from the already-written target (#51).

---
---

# Resolution (fixed 2026-10-31)

Five of the six findings are fixed; **DB2-T1-5** is a deliberate keep-as-is with the rationale
below. Full suite green afterwards (671 tests); the DB2 decompile path in the new tests is
faked, so no real Ghidra runs.

- **DB2-T1-1 — Fixed.** The BinDiff branch of `db2/stage2.py:_process_file()` now builds the
  lever-3 data readers and, per matched code-changed pair, computes `_data_changes()` and
  emits a data card — the same machinery name mode uses. Regression:
  `tests/test_db2_version_layout.py::test_data_cards_are_emitted_in_bindiff_mode`.
- **DB2-T1-2 — Fixed.** `pipeline.py` now prints an upfront WARNING when `--use-bindiff` is
  given without Ghidra (parallel to the DB2-5 `--decompile` warning). Regression:
  `tests/test_db2_medium_pseudoc_jar.py::UseBindiffWithoutGhidraTests`.
- **DB2-T1-3 — Fixed.** BinDiff working data now goes to `<workdir>/bindiff_work/<rel>/`
  (a sibling of `stage2/`), not inside the result tree. `run()` passes `bindiff_dir` in each
  job; `_process_file` uses it, falling back to `out` only for jobs built without it (test
  fakes). Regression:
  `tests/test_db2_version_layout.py::test_bindiff_intermediates_live_beside_stage2_not_inside`.
  **Ported to MSSQL for parity (2026-10-31):** `mssql/stage2.py` now does the same — `run()`
  sets `bindiff_dir = <workdir>/bindiff_work`, `_process_dll` uses `job.get("bindiff_dir") or
  out`, so a Track-1 MSSQL run no longer writes Ghidra projects/`.BinExport` into `stage2/`.
  Regression: `tests/test_mssql_version_layout.py::test_run_sets_bindiff_dir_beside_stage2`.
- **DB2-T1-4 — Fixed (annotated, not deleted).** `db2/decompile.py` now carries a prominent
  DEPRECATED/SUPERSEDED banner pointing at `_decompile.py`. It was annotated rather than
  deleted because this working tree is not a git repo, so a delete would be unrecoverable;
  removing the file outright is safe whenever desired (nothing imports it).
- **DB2-T1-5 — Keep as-is (by design).** Tracking large (`> 0x2000`) memory displacements so
  `classify()` could surface an offset-only change was evaluated and rejected: large non-RIP
  displacements are overwhelmingly relocation targets and large stack-frame slots that shift
  between builds as ordinary recompile noise, and `classify()`'s churn test only treats
  shifts `≤ 256` as churn. Surfacing them would reintroduce exactly the relocation/frame-
  layout noise the blanking exists to remove — a net regression in the core classifier shared
  by all three backends, for a blind spot that is both narrow (small immediates and small
  offsets are already kept in full) and rare in practice. Left unchanged deliberately.
- **DB2-T1-6 — Fixed.** Both tar extractors now materialise an in-tree symlink as a real file
  (the random-access `_extract_tar` via tarfile's own link resolution; the streaming
  `_extract_component_stream` via the escape-checked `_symlink_target_rel` + written/on-disk
  lookup, mirroring hard links), so the tarfile and 7-Zip paths yield the same tree. A
  dangling/escaping symlink is recorded in `skipped` and never aborts. Regression:
  `tests/test_db2_archive_staging_safety.py::TestSymlinkExtraction` (3 tests).

---
---

# DB2 Track-1 — third pass: full-pipeline trace, high-risk reproduction

**No new defects found.** This pass began from repository discovery and a baseline run, then
traced the Track-1 pipeline end-to-end and reproduced the high-risk branches with faked
Ghidra. Every path behaved correctly. No bug is added; this records what was exercised so the
coverage is on file.

**Baseline.** Full suite green — 671 tests, Ghidra faked throughout (no real tool launched).
Entry points: `cli.py` (`run`/`stage2` subcommands) → `pipeline.run_pipeline("db2", …)` →
`db2/{triage,stage1,stage2}.py`; Track-1 engine `_bindiff.py`; pool `_parallel.py`.

**Pipeline trace (synthetic DB2 tree, faked BinDiff).** `triage.run` classified a changed
`…/lib64/libdb2e.so.1` as `code_changed` (symbols=symtab); `stage2.run(use_bindiff=True)`
consumed that Stage-0 result, ran the BinDiff branch, wrote the per-version layout
(`disassembled_instructions_{vuln,fixed}_<ver>/`, `…_<vuln>_vs_<fixed>/`), emitted one
`match_algorithm=bindiff` card for the changed function and correctly skipped the
byte-identical one. `functions_diff.json` counts, `failed_binaries`, and `bindiff_fallbacks`
were all consistent.

**Exit-code mapping.** `counts["bindiff_fallbacks"]` (plural) matches
`cli._summarize_partial_failures`, so a `--use-bindiff` run that falls back (e.g. no Ghidra)
correctly reports a partial failure (exit 3) rather than a clean exit.

**High-risk branches reproduced — all correct:**
- *One-sided address resolution* (BinDiff matches a pair but one side's address doesn't map
  to a known function): the function is **not** lost — the bugs.md #63 name re-pairing
  reports it as a changed card, not a phantom added/removed.
- *Operand-only change scored similarity 1.0 with differing bytes* (bugs.md #53): still diffed
  (card emitted), not skipped as "identical".
- *Rename* (prior name ≠ fixed name): a single `old → new` card, `changed_functions == 1`,
  both sides excluded from new/removed.
- *DB2-T1-1 data diff with real `_data_reader`* (not mocked): no crash; supplements the
  function card as in name mode.
- *`parse_matches` error handling*: a non-SQLite file and a SQLite file lacking the `function`
  table each raise a clear `RuntimeError`; a valid `function` table parses to `{addr1: FuncMatch}`.
- *Truly symbol-less ELF* (`kind=None`, no `.symtab`/`.dynsym`) routed to Stage 2 under
  `--use-bindiff`: reported as a failed binary with "no function symbols…", and Ghidra is
  **not** launched (the early symbol check fires before the BinDiff branch). (A `.dynsym`-only
  ELF does proceed — DB2-18 exported-functions path — which is correct.)
- *Shared Ghidra project for a same-basename prior/fixed pair* (the common patch case): prior
  is exported before the fixed import overwrites the project, so both `.BinExport` files are
  correct; cache reuse and the DB2-15 reuse-after-failed-export path remain sound (verified by
  tracing the import/record/sidecar sequence).
- *Console encoding*: the `→` in a rename label does not crash the CLI — `cli._safe_console()`
  (DB2-24) reconfigures stdout/stderr to `errors="replace"` before any output.

**Conclusion.** The DB2 Track-1 pipeline is sound across the traced and reproduced paths. The
earlier findings DB2-T1-1…T1-4 and T1-6 remain fixed; T1-5 remains a documented by-design
keep-as-is. Nothing new to fix.

---
---

# DB2 Track-1 — fourth pass: acquisition + tool-discovery deep review

This pass reviewed the Track-1 machinery the earlier passes touched least: the acquisition
layer (`db2/acquire.py` container/OCI path), tool discovery and identity (`tool_paths.py`),
and the custom export script (`db2/ghidra/PdffBinExport.java`). One new Medium finding
(reproduced) and one Low finding.

## DB2-T1-7 — container/OCI layer extraction silently drops symlink members  —  **Medium**

**Where:** `db2/acquire.py`, `_extract_layers()` L412: `if not name.startswith(subtree) or
not (m.isfile() or m.islnk()): continue`. A symlink member (`m.issym()`) is dropped with no
record. This is the **container acquisition path** (`_acquire_container` → `_extract_layers`),
used for `--vuln-url container:icr.io/db2_community/db2:<tag>` — the primary Track-1
auto-acquire route. It is the same class as DB2-T1-6 but in a code path that fix did **not**
touch (T1-6 fixed only the manual-fixpack extractors `_extract_tar` /
`_extract_component_stream`).

**Reproduced:** a one-layer image with a real `…/lib64/libdb2e.so.1.0` and a symlink
`…/lib64/libdb2e.so.1 → libdb2e.so.1.0` extracts only the real target; the symlinked
`libdb2e.so.1` — the exact name Stage 2 looks for (and the `lib64/libdb2e.so.1` fallback in
`db2/stage2.run()`) — is absent, and the member-diff manifest's hashes omit it entirely.

**Impact:**
1. *A symlinked analysed binary is silently missing.* If the engine SONAME (or any changed
   `.so`/`.jar`) is delivered as a symlink in the image — common for Linux shared libraries
   and OCI layers — it never lands in the reconstructed tree on either side, so Stage 2 can't
   diff it (and the `lib64/libdb2e.so.1` fallback would fail to find the engine). Whether the
   specific `libdb2e.so.1` is a symlink in the live `db2_community` image is unconfirmed here
   (the image can't be pulled offline), but the mechanism is proven and the engine's SONAME
   being a symlink is plausible.
2. *Stale content can win on a rebuild.* Layers overlay newest→oldest, write-once. If an upper
   (newer) layer replaces a regular file with a symlink, the symlink is skipped, so the
   **older** layer's regular file at that path is written instead — Track-1 would then diff
   the pre-change bytes and miss the change. Unlike the fixpack `_extract_tar`, this path is
   streaming (`tarfile` mode `r|`), so symlinks can't be resolved via `extractfile()`; an
   image symlink may also point into a different layer or to an absolute path.

**Suggested fix:** resolve an in-tree symlink to its target's bytes using the same
escape-checked `_symlink_target_rel` + `written`/on-disk lookup added for
`_extract_component_stream` in T1-6 (symlink targets can point into lower layers, so a
pending/second-pass resolution like the hard-link `_resolve_layer_links` path may be needed),
and at minimum stop dropping them silently — record what can't be resolved. Also handle the
upper-replaces-with-symlink case so an older layer's file cannot win.

**Status: Fixed (2026-10-31).** `_extract_layers` now records symlinks during the
newest→oldest walk — with `name in symlinks` making a newer symlink shadow a lower regular
file (the stale-wins case), while a newer regular still shadows a lower symlink via the
existing `os.path.exists` write-once check — then materialises them in a final multi-pass
`_resolve_symlinks()` over the fully-built tree (so a target in any layer, and symlink chains
`a → b → file`, resolve). Targets that are absolute, escape the tree (`_symlink_target_rel`
escape-check), or are not regular files are left out and logged, never dropped silently; the
materialised copy is hashed into the member-diff manifest like any other file. Verified: the
original repro now materialises the symlinked `libdb2e.so.1`; chains, newer-sym-over-lower-reg,
newer-reg-over-lower-sym, escaping/out-of-subtree targets (no filesystem escape), and
whiteout-hides-lower-symlink all behave correctly. Regression:
`tests/test_db2_archive_staging_safety.py::TestContainerLayerSymlinks` (6 tests). Full suite
green (677). A symlink-free image extracts exactly as before (`_resolve_symlinks` is a no-op
on an empty set).

## DB2-T1-8 — "BinExport installed" gate keys on the sample script, not the classes it needs  —  **Low**

**Where:** `tool_paths.py`, `locate_binexport_script()` checks only for
`Ghidra/Extensions/BinExport/ghidra_scripts/BinExport.java`; `_bindiff.ghidra_binexport()`
raises `BinExportNotInstalled` when it is absent. But Track-1 never runs that script — it runs
our own `PdffBinExport.java`, which needs the extension's **compiled classes**
(`BinExport2Builder`, `BinExport2`) from the extension JARs. The presence of the sample
`.java` is only a proxy for "the extension is installed."

**Impact:** a BinExport install that provides the JARs but not the sample
`ghidra_scripts/BinExport.java` (e.g. a selective/JAR-only install) is wrongly rejected as not
installed, even though Track-1 would work; conversely the script's presence doesn't guarantee
the JARs are loadable. Low in practice — the official extension ships the script — but the
gate checks the wrong artifact. Suggested: gate on the extension's JAR(s) / `Module.manifest`
(what `binexport_identity()` already enumerates), or additionally accept them.

**Status: Fixed (2026-10-31).** `tool_paths.locate_binexport_script()` now returns the sample
`ghidra_scripts/BinExport.java` when present (the usual full install), and otherwise accepts
the extension's BinExport **lib JAR** (`lib/*binexport*.jar`, the one carrying
`BinExport2Builder`) as proof the extension is installed — so a JAR-only install is no longer
wrongly rejected. The return value remains a pure installed/not-installed gate (the exporter
always runs `PdffBinExport.java`); an unrelated jar (e.g. `protobuf-java-*.jar`) or a missing
extension still yields `None`. The `BinExportNotInstalled` message now names the extension and
its `lib/` jar rather than only the script. Verified across install shapes (script-only,
JAR-only, protobuf-only→rejected, absent→None, bundled→accepted). Regression:
`tests/test_tool_paths.py::…::test_locate_binexport_accepts_jar_only_install`. Full suite green
(678).

## Fourth pass — additionally reviewed and found sound

- **Heap/env (`ghidra_heap`/`ghidra_env`):** `-Xmx` is injected via `_JAVA_OPTIONS` (overrides
  analyzeHeadless.bat's `MAXMEM=2G`), scales with input, caps at half physical RAM; left at
  the 2 GiB default (no `_JAVA_OPTIONS`) when nothing requires more.
- **Stale script-cache clearing (`clear_stale_ghidra_script_cache` / `ghidra_script_cache_checked`):**
  the `PATCHDIFF_GHIDRA_CACHE_CHECKED` env marker makes the parent clear the OSGi cache once
  and parallel workers skip it (DB2-19); only a directory literally named `osgi` under the
  resolved settings dir is ever removed.
- **Tool identity (`content_identity`/`binexport_identity`/`decompiler_identity`):** cache keys
  bind input + tool content (JARs/scripts/natives) + Java runtime by content, not by stat, so
  an in-place tool swap invalidates the cache (bugs.md #26/#29/#39).
- **`protobuf_conflict`:** detects mixed protobuf-java versions across module `lib/` dirs
  (bugs.md #55).
- **`PdffBinExport.java`:** validates exactly one non-empty arg, requires an open program,
  writes via try-with-resources; any failure throws → `REPORT SCRIPT ERROR`, which
  `_export_failure` detects even when Ghidra exits 0, and the partial output is discarded.
- **`run_tool` (revisited):** returns the full combined output in `proc.stdout` while trimming
  only the on-disk log, so OOM/abort detection is intact.

---
---

# Oracle Track-1 (Ghidra+BinExport+BinDiff) — end-to-end review

Reviewed the Oracle path end-to-end with emphasis on Track-1 (`--use-bindiff`):
`oracle/stage2.py` (`_diff_o` BinDiff branch, `_func_map`/`_func_sections`, the multi-section
BinDiff-safety guard, the sequential `run()` loop), `oracle/_ar.py` (static-archive member
extraction), `oracle/_extract.py` (RU zip extraction), and the shared `_bindiff` engine. One
new finding.

## ORA-T1-1 — Oracle shares one BinDiff workdir (`bd_workdir = out`) across all objects, inside stage2/  —  **Medium**

**Where:** `oracle/stage2.py`, `_diff_o()` L402: `bd_workdir = out`. Every object's
`diff_pair(pa, fa, bd_workdir)` therefore uses the **same** directory — the `stage2/` output
dir — so all BinDiff intermediates land in one shared `out/bindiff/` (a single Ghidra project
`bindiff_proj` plus `prior_<stem>.BinExport` / `fixed_<stem>.BinExport` per object). This is
the DB2-T1-3 issue, never fixed for Oracle: DB2 uses `<workdir>/bindiff_work/<rel>/` and MSSQL
was ported to match, but Oracle still points at `out`. Reproduced: three `_diff_o` calls all
received the identical workdir, equal to the stage2 out dir.

**Why Oracle is different from DB2/MSSQL.** DB2 and MSSQL isolate BinDiff per binary
specifically because they run binaries **in parallel** (a shared Ghidra project has no
locking and would corrupt). Oracle's `run()` is a **sequential** for-loop over objects, so the
shared workdir does not cause concurrent corruption, and results are correct (verified: the
BinExport cache is content-keyed, so same-named members from different archives never serve
the wrong export). The problems are:

1. **Footprint / clutter.** An Oracle RU (OJVM `libjavavm19.a`, `libserver19.a`) holds many
   `.o` objects, so `out/bindiff/` accumulates a Ghidra project with one program per object
   and `2 × N` `.BinExport` files, all inside the result tree, never cleaned — exactly what
   DB2-T1-3/MSSQL moved out of `stage2/`.
2. **Crash cascade (the reason this is Medium, not Low).** `run_tool` force-kills the Ghidra
   process tree (`taskkill /F /T`) on a step timeout. A force-killed `analyzeHeadless` can
   leave a stale lock in the **shared** `bindiff_proj`; because every subsequent object reuses
   that same project, one object's Ghidra timeout/crash can break BinExport for **every later
   object in the run** — whereas DB2/MSSQL isolate per-binary, so a crash only affects the one
   binary (which already fell back). It degrades gracefully (each affected object is recorded
   as a `bindiff_fallback` and name-matched, exit 3), so it is not a wrong-answer bug, but a
   single slow `.o` can silently disable Track-1 for the rest of an Oracle run.

**Suggested fix:** give each object its own `bd_workdir` under a sibling of `stage2/`, e.g.
`os.path.join(workdir, "bindiff_work", _safe(obj_name))`, mirroring the DB2/MSSQL fix — which
both removes the clutter and stops a crashed object's project lock from cascading. (`_diff_o`
would need `workdir`/a `bindiff_dir` passed in from `run()`.)

**Status: Fixed (2026-10-31).** `run()` now passes `bindiff_dir = <workdir>/bindiff_work` and
`_diff_o` uses `bd_workdir = os.path.join(bindiff_dir or out, _safe(obj_name))` — so every
object gets its own isolated Ghidra project outside `stage2/`. This removes the clutter, stops
one object's force-killed Ghidra from leaving a project lock that breaks every later object,
and incidentally fixes the cross-archive cache collision (two archives' same-named `member.o`
now use distinct per-object workdirs). The `or out` fallback keeps direct `_diff_o` callers
(test fakes) working. Regression:
`tests/test_oracle_version_layout.py::test_bindiff_intermediates_live_beside_stage2_not_inside`.

## Oracle per-version / binary.json layout (parity with MSSQL & DB2) — applied 2026-10-31

Oracle Stage 2 was migrated off the old flat `disassembled_instructions/` + `decompiled_c/`
onto the shared `_layout` scheme, matching MSSQL and DB2:

- Each build gets `disassembled_instructions_{vuln,fixed}_<version>/<object>_<sha8>/<func>.asm`
  (plain per-side disassembly, addresses shown as section-relative **offset** for ET_REL) and,
  with `--decompile`, `decompiled_c_{vuln,fixed}_<version>/<object>_<sha8>/<func>.c`, each with
  a `binary.json` (`{binary, name, sha256, version, build}`). Function files are
  digest-suffixed (`_layout.function_file`), so distinct names never collide.
- The assembly diffs (which compare the two builds) go to one
  `disassembled_instructions_<vuln>_vs_<fixed>/` folder, with the permanent per-run labelled
  copies as before.
- Folders are created lazily by the first write, so a run with nothing to emit leaves none;
  the old flat layout is kept as a fallback for direct `_diff_o` callers built without
  `version_dirs` (test fakes), so their behaviour is unchanged.
- Implemented with minimal churn: a `version_folder(kind, side)` closure + a single
  `_emit_side_listings(prior, fixed)` helper called at each of the six emit sites, and a
  per-version branch in `_decompile_pair`. The flat `fn__*.asm.diff` / `fn__*.detail.json`
  working records and the `functions_diff.json` result are unchanged.

Verified end-to-end (faked Ghidra): per-build folders + `binary.json`, offset listings, the
`_vs_` pair folder, `decompiled_c_*` only with `--decompile`, BinDiff intermediates under
`bindiff_work/`, distinct `<sha8>` per build, and the unversioned fallback. Regression:
`tests/test_oracle_version_layout.py` (4 tests). Full suite green (683).

## Oracle Track-1 — post-implementation review (no new defects)

After the two changes above, re-reviewed the Oracle Track-1 path end-to-end and found it
sound; nothing new to fix.

- **One-sided objects / absent sides:** `version_folder` returns `None` when a side's file is
  absent (`pa`/`fa` is `None`) or when there are no `version_dirs`, so `_emit_side_listings`
  writes only the present side and never raises; added/removed objects behave correctly.
- **Emit cap:** per-side listings and per-version `.c` are written inside the emit block, so a
  function dropped at `_EMIT_CAP` gets neither — consistent with its card not being written.
- **Archive members:** per-object `bd_workdir` (keyed by the full `archive!member` name)
  isolates each member's Ghidra project; the per-binary `<sha8>` is the member's content hash,
  taken while its temp file still exists during `_diff_o`.
- **Triage routing:** `.a`→(stage2, archive), `.o`/`.asm`→(stage2, native), plus
  `code_removed` for one-sided inventory — exactly what `run()` consumes.
- **Multi-section safety (bugs.md #5)** and the ET_REL offset mapping are unchanged and still
  hold; the DBRU PE path remains file-level only (no symbols), as designed.

## Oracle Track-1 — additionally reviewed and found sound

- **ET_REL address mapping (`_GHIDRA_ELF_REL_BASE` = `0x100000`, bugs.md #61):** the offset is
  measured from BinDiff's names with the per-type base as default; nothing resolving raises →
  recorded name-matching fallback, not phantom added/removed.
- **Multi-section safety (bugs.md #5), not bypassable:** `_diff_o` refuses BinDiff and
  name-matches when functions span more than one `.text*` section or their section-relative
  `st_value`s collide (the single-base mapping would mis-attach matches). A multi-section
  ET_REL without pyelftools yields an empty func map → caught by the symbol-less check
  (CRIT-NT-9) before the BinDiff branch, so it can't slip through with a bad mapping.
- **`_func_map` / `_func_sections`:** section-aware carve across `.text`/`.text.hot`/
  `.text.unlikely` (bugs.md fix for kkz.o), STT_FILE scoping (#27), oversized recording (#28),
  unnamed `sub_` placeholders (CRIT-NT-2); flat fallback returns `{}` for a multi-`.text`
  ET_REL rather than wrong bytes.
- **Per-call emit cap (CRIT-NT-5):** each object gets its own `_EMIT_CAP` budget; a noisy
  object can't suppress later objects' diffs.
- **Static-archive reader (`_ar.py`):** malformed/truncated detection (#45), GNU/BSD long
  names, duplicate-member keying (#9), member-name sanitisation (no path traversal).
- **RU zip extraction (`_extract.py`):** zip-slip, zip-bomb ratio, disk-space budget, and
  long-path handling all guarded.
- **BinDiff-match consumption:** mirrors DB2/MSSQL — sim-1.0-with-differing-bytes still diffed
  (#53), `sub_` excluded from new/removed, unmatched-both-sides re-paired by name (#63),
  deterministic sort before the cap (#4).

---
---

# Oracle Track-1 — review after the layout migration

A fresh pass over the newly-migrated Oracle per-version layout and the pipeline that feeds it.
Two new findings, both Low; no correctness defects.

## ORA-T1-2 — Oracle's per-version layout is always "unversioned" (no label derivation in the pipeline)  —  **Low**

**Where:** `pipeline.py`, `run_pipeline()` L871–L884 sets `vuln_label`/`fixed_label` for
`mssql` (KB / engine version) and `db2` (acquisition URL tag) but has **no `elif db ==
"oracle"` branch**, so Oracle keeps `vuln_label = fixed_label = None`. `oracle/stage2.run()`
then does `_version_token(None)` → `"unversioned"` for both sides.

**What:** the per-version layout just applied to Oracle therefore always produces
`disassembled_instructions_{vuln,fixed}_unversioned/`, `decompiled_c_{vuln,fixed}_unversioned/`
and `disassembled_instructions_unversioned_vs_unversioned/` — the "version" component is inert.
Confirmed by code reading (the end-to-end verification only showed real labels because the
test passed `vuln_label`/`fixed_label` explicitly to `run()`; the CLI path passes `None`).

**Impact:** not a correctness bug — the per-binary `<object>_<sha8>` subfolder still keeps the
two builds distinct, and the layout is still strictly more structured than the old flat one.
But the main benefit of the version-named layout (reuse/identify a build by its version, keep
successive comparisons in one `--out` apart) is unrealised for Oracle, and two different RU
comparisons into the same `--out` share the `*_unversioned` parent folders (distinguished only
by the content hash). MSSQL and DB2 both derive a real label; Oracle is the odd one out.

**Suggested fix:** add an `elif db == "oracle"` label branch to `run_pipeline()` deriving a
version from the RU patch (e.g. the RU number / quarter via `oracle/_version.py`, or the RU
zip file name), so the folders carry a meaningful version like the other two backends.

**Status: Fixed (2026-10-31).** `run_pipeline()` now has an `elif db == "oracle"` branch that
derives the label from the RU patch zip in the input dir via `_oracle_zip_label()` — the Oracle
patch id (`p\d+`) from a name like `p35643107_190000_Linux-x86-64.zip`, else the file stem,
else `None` (no/multiple zips → "unversioned"). New `--vuln-label`/`--fixed-label` CLI options
(generic, wired through `run_pipeline`) override the auto-derived label for any backend. Both
MSSQL and DB2 also gain the override for free. Regression:
`tests/test_oracle_version_layout.py::OracleLabelTests` (zip→patch-id, stem fallback,
no/multiple→None, pipeline derivation, and CLI override).

## ORA-DOC-1 — stale output-layout docs for DB2/Oracle after the per-version migrations  —  **Low**

**Where:** three doc strings still describe the OLD flat per-pair layout that DB2 (migrated
earlier) and Oracle (migrated now) no longer produce:
- `pipeline.py` `run_pipeline()` docstring L723–L726: "DB2/Oracle:
  `stage2/decompiled_c/<vuln_label>_<fixed_label>_<run_ts>__fn__<name>.{prior,fixed}.c`".
- `cli.py` `--decompile` help L141: "DB2/Oracle under `stage2/decompiled_c/`".
- `oracle/stage2.py` module docstring L14–L15: copies land in `disassembled_instructions/`
  and `decompiled_c/`.

**What / impact:** documentation only — no runtime effect — but all three now describe output
that is never written (both backends use
`decompiled_c_{vuln,fixed}_<version>/<binary>_<sha8>/<func>.c` and the `_vs_` diff folder).
Misleads anyone reading `--help` or the source for where results land. (This slipped in when
DB2 was migrated; the Oracle migration widened it.)

**Suggested fix:** update the three strings to the per-version layout (as `db2/stage2.py`'s
module docstring and `mssql`'s already read), or point them at a single canonical description.

**Status: Fixed (2026-10-31).** All three strings now describe the per-version layout
(`decompiled_c_{vuln,fixed}_<version>/<binary>_<sha8>/<func>.c` + the `_vs_` diff folder) used
by all backends, and the `pipeline.py` docstring names the per-backend label sources including
the new `--*-label` override and Oracle's RU-zip name.

## Oracle layout migration — re-verified sound

- One-sided objects (added/removed) write only the present side's listing; `version_folder`
  returns `None` for an absent `pa`/`fa` and never raises.
- Per-side listings and per-version `.c` are written inside the emit block, so a card dropped
  at `_EMIT_CAP` produces neither (consistent with its card not being written).
- Archive members get a per-object `bindiff_work/<archive!member>/` and a content-hashed
  per-binary subfolder; the hash is taken while the member's temp file still exists.
- The flat `fn__*` working records, `functions_diff.json`, triage routing, multi-section
  BinDiff guard (#5), and ET_REL offset mapping (#61) are unchanged and still hold.

---
---

# Oracle Normal Track (default capstone name-matching, no BinDiff) — end-to-end review

Reviewed the default Oracle Stage 2 path end-to-end: `oracle/triage.py` (routing that feeds
Stage 2), the name-mode branch of `oracle/stage2._diff_o` (common-key capstone diff +
new/removed derivation), the objdump `.o.asm` and file-level PE paths, `_ar`/`_extract`, and
the result/counts assembly. Two new findings.

## ORA-NT-1 — Oracle triage never classifies rebuild-only objects  —  **Low**

**Where:** `oracle/triage.py` — both `run()` (full walk, L191–L199) and `_from_manifest()`
(L119–L131) route a changed file purely by extension via `_route()`, and hardcode
`"rebuild_only": 0` / `"rebuild_only": []`. Any byte-changed `.o`/`.a` becomes `code_changed`
(→ Stage 2). There is no executable-section comparison, unlike DB2 (`exec_section_sigs`) and
MSSQL (PE `.text` hash) triage, even though Oracle already has the `_exec_bytes()` primitive.

**Reproduced:** a `.o` whose executable code is byte-identical but whose whole-file bytes
differ (one trailing byte) is reported as `code_changed` with `rebuild_only == 0`, while
`_exec_bytes(prior) == _exec_bytes(fixed)` confirms the code did not change.

**Impact:** (1) the `code_changed` count is inflated — it counts recompiled-but-identical-code
objects as code changes; a user can't tell real changes from rebuild noise at the Stage 0
level (DB2/MSSQL report `rebuild_only` separately). (2) Wasted Stage 2 work — every such `.o`
is disassembled (Normal Track) or, under `--use-bindiff`, sent to a full Ghidra/BinDiff run
(expensive) unless `--bindiff-only` excludes it. Not a wrong-cards bug: Stage 2 correctly
emits no card for a rebuild-only object (its functions are byte-identical / classify as churn).

**Suggested fix:** in triage, for a changed `.o`/`.a`, compare `_exec_bytes()` (or per-section
exec hashes) of the two sides; equal → `rebuild_only`, differ → `code_changed` — mirroring
DB2's `exec_section_sigs` refinement.

**Status: Fixed (2026-10-31) at Stage 2, not triage — deliberately.** A triage-level
exec-section *filter* was evaluated and rejected as unsafe for Oracle ET_REL: an unlinked
`.o` carries call/data targets as relocations, not resolved `.text` bytes, so a `.text`-equal
filter could skip a real relocation/rename change (and would diverge from Stage 2, which also
compares `.text` only). Instead Stage 2 now **records** the outcome: a changed native `.o`
whose executable code did not change (0 cards, not an error) gets a single `rebuild-only`
verdict in `binaries[]` (`_rebuild_only_entry`), and an archive whose members all rebuilt gets
one archive-level `rebuild-only` verdict (not one per member). So a rebuild-only object is now
visible and distinguishable from a real change — no analysis is skipped, nothing is lost.
Regression: `tests/test_oracle_version_layout.py::OracleRebuildOnlyTests` (object, real-change,
and all-rebuild-archive cases).

## ORA-NT-2 — a data-only native change is diffed nowhere (no data-section diff, and no per-object trace)  —  **Medium**

**Where:** Oracle has **no** data-section diff at all — `grep` finds zero of
`_data_changes` / `data_section_diff` / `rip_data_targets` / `data_changed` in
`oracle/stage2.py` and `oracle/triage.py` (DB2 has them in both: the triage `data_changed`
bucket from `_same_code`→`data_section_diff`, DB2-22, and the stage2 lever-3 `_data_changes`).

**What:** for a native `.o` whose executable code is unchanged but whose referenced
`.rodata`/`.data` content changed (a constant/table/bounds value — a data-only fix), the
name-mode diff skips every function at `if pc == fc: continue` (the function's `.text` is
identical), so it emits no card; Oracle has no data pass to catch the changed data. Worse,
the native `.o` path in `run()` does `_inventory(...)` then `if not added: continue` **without
appending a `binaries[]` verdict**, so a changed `.o` that yields zero function cards (data-
only *or* rebuild-only) leaves **no record in the Stage 2 result at all** — no card and no
per-object verdict. The only signal that anything changed is triage's inflated `code_changed`
count (see ORA-NT-1).

**Impact:** a data-only Oracle native fix is effectively invisible in the Stage 2 result. DB2
surfaces the same case as a `data_changed` triage entry and/or a lever-3 data card. Oracle
native data-only fixes are uncommon (security fixes usually change code), which bounds the
exposure, but it is a genuine coverage gap and the "no per-object trace" part also hides the
benign rebuild-only case (one can't tell "analysed, nothing changed" from "not analysed").

**Suggested fix:** (a) record a per-object outcome for every changed native `.o`/archive
member even when it yields zero cards (an analysed/`rebuild-only`/`no-change` verdict in
`binaries[]`), so the result is complete; and (b) optionally port a data-section diff (triage
`data_changed`, or the stage2 lever-3 pass) to Oracle for data-only fixes.

**Status: (a) Fixed (2026-10-31); (b) won't-fix (unsound for ET_REL).** Part (a) — the "no
per-object trace" hole — is closed by the same `rebuild-only` verdict as ORA-NT-1: a changed
native `.o` or all-rebuild archive now always leaves a record, so the result is complete and a
data-only (or rebuild-only) object is no longer silently absent. Part (b) — porting the
data-section diff — is **not** done because it is unsound for Oracle's unlinked ET_REL objects:
DB2's lever-3 `rip_data_targets` resolves a RIP-relative data reference to an absolute vaddr,
but in an ET_REL `.o` that reference is a *relocation* with a placeholder displacement, so the
resolved target would be wrong. A correct Oracle data diff would need `.rela.*`-aware analysis
(a sizeable feature); the `rebuild-only` verdict makes the object visible in the meantime, with
a note that byte/data changes are not diffed. Exposure is bounded (Oracle native data-only
fixes are uncommon).

## Oracle Normal Track — reviewed and found sound

- **Name-mode matching:** common functions paired by (reconciled, dedup'd) symbol name;
  byte-identical skipped; `classify()` drops `same`/`churn`; `sub_` excluded from new/removed
  for two-sided objects (kept for one-sided, #3); `_ARTIFACT` compiler clones filtered.
- **Determinism / cap:** name_hits sorted (attributed → fix-shaped → most-changed → name) and
  the per-call `_EMIT_CAP` (CRIT-NT-5) is local to each object.
- **objdump `.o.asm` path:** `_norm_asm()` masks address churn and distinguishes
  `rebuild-only` from `native-changed` at the file level (the one place Oracle *does*
  recognise rebuild-only — but only for pre-processed objdump text, not raw `.o`).
- **One-sided objects / archive members / removed bins:** handled (added/removed inventory,
  per-member diffs, truncated-archive → error).
- **Result/counts assembly:** `counts.failed`/`functions_skipped`/`bindiff_fallbacks` line up
  with `cli._summarize_partial_failures`; attribution corroboration (`_AT.resolve`, low→
  candidate-only) is applied.

---
---

# DB2 Normal Track (default capstone name-matching, no BinDiff) — end-to-end review

Reviewed the default DB2 Stage 2 path end-to-end: `db2/triage.py` (routing/rebuild-only/data
classification), the name-mode branch of `db2/stage2._process_file` (common-key capstone diff,
new/removed, the per-binary `_EMIT_CAP`), the DB2-specific **lever-3 data-section diff**
(`_data_changes` / `_data_reader` / `_real_data_change` / `_looks_pointer` /
`_is_reloc_table`), `emit`/`emit_data`, and the result assembly. Two new findings (both Low).

## DB2-NT-1 — lever-3 data cards bypass the per-binary `_EMIT_CAP`  —  **Low**

**Where:** `db2/stage2._process_file`. Function cards are emitted under the cap
(`if attr_cache[name][0] or fpre > 0 or rel_cards < _EMIT_CAP:` then `rel_cards += 1`), but the
data-card loop that follows — `for name, dc in data_hits.items(): emit_data(name, dc)` (name
mode ~L1191, and the same loop in the BinDiff branch ~L1105) — has **no cap check and never
increments `rel_cards`**. `emit_data` appends to `readable` unconditionally.

**Reproduced:** with `_EMIT_CAP` forced to 1 and `PATCHDIFF_DATA_DIFF=1`, three changed,
unattributed, non-fix-shaped functions each with a data change produced **1** function card
(2 correctly capped) but **3** data cards — the data cards ignored the cap.

**Impact:** the cap exists to bound per-binary output (DB2-4). With `PATCHDIFF_DATA_DIFF=1` on a
large rebuilt binary, the data-card count is unbounded, so a run can emit far more `dt__` cards
than the cap allows for `fn__` cards — and a function whose *code* card was capped still gets
its *data* card, so the result can show a data card with no matching function card. Bounded in
practice because lever-3 is opt-in (off by default), but it defeats the cap when enabled.

**Suggested fix:** gate `emit_data` on the same cap (count data cards toward `rel_cards`, or
give data cards their own bounded budget), and/or only emit a data card for a function whose
code card was actually emitted.

**Status: Fixed (2026-10-31).** The separate uncapped `for name, dc in data_hits.items():
emit_data(...)` loop was removed from both the name-mode and BinDiff branches; a data card is
now emitted **inside** the function-card emit block, only when that function's card is
emitted. So data cards ride with their function card, are bounded by the same `_EMIT_CAP`
(never emitted for a capped function), and a data card can no longer appear without its
function card. Regression:
`tests/test_db2_version_layout.py::Db2DataCardCapTests` (with `_EMIT_CAP=1`, 3 changed
functions each with a data change → 1 function card + 1 data card, not 3).

## DB2-NT-2 — `_looks_pointer` suppresses a whole data window on one address-like word  —  **Low**

**Where:** `db2/stage2._real_data_change` → `_looks_pointer(buf, lo, hi)` returns True if *any*
8-byte-aligned word in the `_DATA_WIN`-byte window falls in the image's allocatable vaddr
range `[lo, hi)`, and `_real_data_change` then discards the **entire** window as a relocated
pointer.

**What:** this is a deliberate heuristic to drop vtable/GOT/pointer churn, but it
over-suppresses: (1) a legitimate integer/bounds constant whose value happens to land in the
image's vaddr range (e.g. a size/offset near a section address) is treated as a relocated
pointer; (2) because one pointer-like word voids the whole window, a *genuine* content change
elsewhere in the same `_DATA_WIN` window (a changed string or constant a few bytes away from a
real pointer) is dropped with it.

**Impact:** a data-only fix can be missed by lever-3 when its window also contains a
pointer-valued word. Narrow and opt-in (lever-3 off by default), and it is a conscious
precision-for-recall trade-off, but worth recording as a known detection gap. Possible
refinement: compare the window word-by-word and only skip the individual pointer-valued words,
rather than voiding the whole window.

**Status: Fixed (2026-10-31).** `_real_data_change` still uses `_looks_pointer` as the fast
entry gate (so a pointer-free window is unaffected and the existing mock-based test keeps
working), but inside it now **masks** every aligned 8-byte word that is pointer-like on either
side and voids the window only if the masked remainders are then equal — i.e. only when the
*sole* differences were relocated pointers. A genuine change beside a pointer in the same
window now surfaces. Pure relocated-pointer / all-pointer windows are still ignored (every
word masked → equal → churn). Regression:
`tests/test_identity_and_inputs.py::DataDiffNulTests::test_real_change_beside_a_relocated_pointer_is_detected`
(real-change-beside-pointer detected; pointer-only still ignored), and the pre-existing
`test_relocated_pointer_with_nul_bytes_is_still_ignored` still passes.

## DB2 Normal Track — reviewed and found sound

- **Triage (unlike Oracle, cf. ORA-NT-1/2):** DB2 triage DOES refine changed ELFs by
  executable-section hash (`exec_section_sigs`) into code-changed vs `rebuild_only`, and
  classifies same-code-different-data as `data_changed` (DB2-22) — so rebuild-only objects are
  not routed to Stage 2 and are reported separately.
- **Name-mode diff:** common functions paired by reconciled/dedup'd symbol name; byte-identical
  skipped (`raw`); `classify()` drops `same`/`churn`; `sub_` excluded from new/removed for
  two-sided binaries; deterministic sort (attributed → fix-shaped → most-changed → name) and a
  per-binary `_EMIT_CAP` (fix-shaped/attributed always emitted).
- **Lever-3 alignment:** `_data_changes` maps prior→fixed instructions via SequenceMatcher
  `equal` blocks and `rip_data_targets` is 1:1 with `norm()`'s lines; the string-terminator
  handling (#40) and reloc-table filter (`_is_reloc_table`) are correct, and the whole thing is
  sound for DB2's *linked* `.so` (real vaddrs — unlike Oracle ET_REL, cf. ORA-NT-2).
- **`_func_map`:** symtab→dynsym fallback (DB2-18), oversized recording (#28), dup-name
  qualification (#27), `st_shndx` section bytes; graceful empty map → failed-binary (CRIT-NT-9).
- **Per-version output / emit:** each build's `.asm` listing + (with `--decompile`) `.c` in its
  `<binary>_<sha8>/` folder, diffs in the `_vs_` folder — unchanged by this review.

---
---

# MSSQL Normal Track (default capstone name-matching, no BinDiff) — end-to-end review

Reviewed the default MSSQL Stage 2 path end-to-end: `mssql/_pe.py` (.pdata/CHAININFO function
recovery), `mssql/symbols.py` (public-PDB fetch + RVA→name), `mssql/stage2._func_map`
(chunk reassembly, naming), the hot/cold-chunk normalisation (`_norm_chunks` /
`_norm_chunk_pair` / `_extract_func_bytes`), and the name-mode branch of `_process_dll`. Two
new findings.

## MSSQL-NT-1 — same-named `.pdata` functions are collapsed to the largest, dropping the rest  —  **Low/Medium**

**Where:** `mssql/stage2._func_map` L224–L226: `if key not in out or _blob_len(chunks) >
_blob_len(out[key][1]): out[key] = (primary, chunks)`. When two distinct `.pdata` primaries
resolve (via `symbolizer.exact_name`) to the **same** PDB name, only the one with the larger
blob is kept; the other is silently dropped from the function map. The comment assumes "same
name ⟹ identical-COMDAT folding," but `Symbolizer._enum` builds `names` as an RVA→name dict
whose *values* are not unique, so two different addresses can carry the same public name
without being identical code (ICF-adjacent thunks, or genuinely distinct same-named publics).

**What / impact:** MSSQL is the only backend that does this. DB2 and DB2-derived Oracle run
`_dedupe_func_names` / `reconcile_dup_names` (bugs.md **#27** — "same-named functions no longer
overwrite each other"), qualifying duplicate names so *each* is diffed. MSSQL has **no** such
dedup (grep: 0 vs DB2 7 / Oracle 4), so a real byte-level change in a dropped same-named
function is reported nowhere — not changed, not added, not removed — in a result that looks
clean. It is the exact overwrite class #27 fixed for DB2, still present for MSSQL. Bounded
because duplicate *public* names at distinct addresses are uncommon in MSSQL public PDBs, but
it is a genuine silent-miss and a cross-backend inconsistency.

**Suggested fix:** qualify duplicate names in `_func_map` (append the RVA or an ordinal, as
`_dedupe_func_names` does) instead of keep-largest, so two distinct same-named functions both
get a key and are both diffed; keep the fold only for byte-identical (true COMDAT) chunks.

**Status: Fixed (2026-10-31).** `_func_map` now groups entries by name, folds byte-identical
COMDAT/ICF copies, and — for a name with genuinely-distinct copies — keeps the **largest**
under the bare key (exactly the previous keep-largest, so the primary pairing never regresses)
while surfacing every OTHER distinct copy under a qualified `name [#k]` key (address order),
via `_AT.qualify_func_name`. A distinct same-named function is therefore no longer dropped;
attribution still matches because the bracketed qualifier tokenises away. Unique names and
always-unique `sub_<rva>` keys are untouched. Regression:
`tests/test_mssql_version_layout.py::MssqlDedupAndChunkTests` (distinct kept, identical folded,
unnamed/unique unchanged). The fix is purely additive over the old behaviour (the bare key is
unchanged), so a bare name on one side still pairs with the other side's largest.

## MSSQL-NT-2 — `_norm_chunk_pair` pairs hot/cold chunks by position when counts match  —  **Low**

**Where:** `mssql/stage2._norm_chunk_pair` L275 `for (pa, pc), (fa, fc) in zip(sp, sf):` pairs
the i-th prior chunk (RVA-sorted) with the i-th fixed chunk. If the two sides have the same
chunk *count* but a fragment was reordered or substituted (so the RVA sort puts a hot fragment
opposite a cold one), the per-chunk classification compares unrelated fragments.

**What / impact:** low — this only affects the **scored** subset used for the similarity ratio
and fix-pre-score (ranking/cap ordering); the **diff output** uses the full concatenation
(`pL_all`/`fL_all`), and the count-mismatch case already falls back to full concatenation. So a
mis-pair can mis-rank a function (wrong similarity, possibly a wrong cap decision) but does not
corrupt a card's content. Narrow (cold fragments are normally placed after hot, preserving the
sort order). Worth noting; a fix would pair chunks by role (hot = the one containing `primary`)
rather than by sorted position.

**Status: Fixed (2026-10-31).** `_norm_chunk_pair` now takes each side's `primary` RVA and
pairs by ROLE: the primary (hot) chunk of each side first, then the cold fragments by address,
instead of raw sorted position. Both callers (name-mode and BinDiff) pass the primaries. In
the common case (hot is the lowest-RVA chunk) this is identical to the old pairing; when a cold
fragment is reordered below the hot entry on one side only, hot now pairs with hot. Regression:
`tests/test_mssql_version_layout.py::MssqlDedupAndChunkTests::test_norm_chunk_pair_pairs_hot_chunks_by_role`.

## MSSQL Normal Track — reviewed and found sound

- **.pdata/CHAININFO recovery (`_pe.FuncImage`):** fragments folded under their primary via
  UNWIND_INFO CHAININFO (bounded chain walk), NOT the old abut-merge heuristic that ran diffs
  past a `ret` into the next function; `_primary_of` byte math matches the x64 unwind spec.
- **PDB fetch (`symbols.fetch_pdb`):** atomic private-temp download + rename (bugs.md #32),
  MSF-superblock truncation check (`_pdb_complete`), Content-Length check, concurrency-safe
  over the shared cache.
- **Naming:** `exact_name` for KEYING (never bisect-fold, which the ISECManager false positive
  showed fabricates diffs), `name_at` (bisect) only for call-target resolution.
- **One-sided-PDB (bugs.md #58):** when only one build has symbols, BOTH sides are re-keyed by
  address so same-slot changes still diff, and the binary is reported `ok=False` (exit 3).
- **Hot/cold handling:** `_extract_func_bytes` lays each chunk at its true offset (int3-filled
  gap, bugs.md #25) so inter-fragment branches resolve; per-chunk classification stops an
  identical hot path from masking a cold-path fix.
- **Name-mode diff:** `sub_<rva>` shared-address slots diffed but excluded from new/removed
  (CRIT-NT-1); deterministic sort + per-binary `_EMIT_CAP` with fix-shaped/attributed always
  emitted; `symbolized`/`functions_capped`/`failed` line up with `_summarize_partial_failures`.
- **No data-diff:** MSSQL has no lever-3, so the DB2-NT-1/NT-2 data-card issues do not apply.

---
---

# MSSQL Track-2 — pseudo-C (`--decompile`) review

End-to-end review of the MSSQL `--decompile` path: the gate inside `mssql/stage2.emit()`
(L527–567), `_extract_func_bytes`/`_partial_c_note` (the PE hot/cold → one-blob carve),
the shared engine `_decompile.decompile_cached_per_side` (MSSQL's per-function/per-build
cache), `decompile_pair`/`_try_decompile`/`decompile_allowed`, the Ghidra script
`db2/ghidra/DecompileFunc.java`, and the standalone `mssql/decompile.py`. Two findings, both
**Low** (one dead-code/maintenance, one documentation); the core decompile flow is sound (see
the "reviewed and found sound" list below).

## MSSQL-T2-1 — `mssql/decompile.py` is production-dead — an orphaned second decompile path  —  **Low**

**Where:** `mssql/decompile.py` (whole module: `decompile_function`, `_one_func_pe`,
`cache_name`, `available`).

**What:** the MSSQL Track-2 pseudo-C that the pipeline actually produces is written entirely
inside `mssql/stage2.py` (the `emit()` decompile block → `_extract_func_bytes` →
`_decompile.decompile_cached_per_side`). `mssql/decompile.py` — an *on-demand, single-function*
decompiler ("Cached → instant re-open", writes its own `fn__….decomp.pair.json`) — is imported
by **no** production module. Verified: `pipeline.py` loads only `mssql.{triage,stage1,stage2}`
(L40–42); the only importer anywhere is `tests/test_identity_and_inputs.py:26`
(`import …mssql.decompile as mdec`). This is the exact dead-code class as **DB2-T1-4**
(`db2/decompile.py`). The DB2-T1-4 writeup (L139/L145) explicitly contrasts the two, calling
`mssql.decompile` a *"different, still-live module"* — that is misleading: it is live only to a
test, not to any production code path.

**Impact:** no runtime effect today (nothing calls it), but a worse maintenance/confusion trap
than DB2-T1-4 because it duplicates Track-2 machinery *divergently*, so if it is ever wired to
a caller (its docstring reads like it was meant for an interactive viewer) it runs a second,
inconsistent decompile path:
- `_one_func_pe` re-implements the carve (a fresh `fetch_pdb`/`_func_map` per call, then
  `_extract_func_bytes`) instead of reusing Stage 2's already-built function map.
- `decompile_function` calls `_dc.decompile_pair(pb, fb)` **directly**, which *raises*
  (`GhidraNotConfigured` on no Ghidra, `RuntimeError` on timeout / no C output). The Stage-2
  path goes through `_try_decompile`, which never raises (best-effort). So a caller of
  `decompile_function` gets an unhandled exception on any decompile failure or timeout — the
  opposite of the Stage-2 contract.
- it does **not** consult the shared `decompile_cache/per_function/` that the Stage-2 run
  populates (`_side_cache_file`, keyed by each side's exact bytes), so it re-runs a Ghidra JVM
  for a function whose pseudo-C is already cached; its own `.decomp.pair.json` cache is a third,
  separate store.

**Suggested fix (mirror DB2-T1-4):** delete the module, or — if it is deliberately retained for
a future on-demand/viewer feature — add a module-level banner that it is **not wired into
production and is superseded by `_decompile.decompile_cached_per_side`**, and correct the
DB2-T1-4 note that still calls it "still-live".

**Status: Fixed (2026-10-31).** `mssql/decompile.py` now carries a SUPERSEDED banner (mirroring
`db2/decompile.py`/DB2-T1-4) stating it is wired to nothing, that MSSQL Stage 2 decompiles
through `_decompile.decompile_cached_per_side`, and spelling out the two divergences that make
it unsafe to revive as-is (direct `decompile_pair` raises on failure/timeout; no shared
`per_function/` cache). The DB2-T1-4 note that called it "still-live" is corrected above. The
module is kept (not deleted — no VCS here) so the existing
`test_identity_and_inputs.py::MssqlDecompileFunctionTests` still exercises the #52 fix.
Regression: `tests/test_mssql_decompile_deprecation.py::MssqlDecompileIsDeadCode` asserts the
banner is present and that **no** pipeline/entry module (`pipeline`, `cli`, `mssql.triage`,
`mssql.stage1`, `mssql.stage2`) imports the dead submodule, while the legitimate shared
`from .._decompile import …` line is not falsely flagged.

## MSSQL-T2-2 — `DecompileFunc.java` header is stale/DB2-specific though it is the shared Track-2 script  —  **Low (doc)**

**Where:** `db2/ghidra/DecompileFunc.java`, header comment L1–L17.

**What:** this GhidraScript is the **shared** single-function decompiler driven by
`_decompile.decompile_pair` for all three backends, and MSSQL Track-2 depends on it. Its header
still describes a DB2-only world: *"for the DB2 patch-differ"*, blob *"carved by
db2/decompile.py from libdb2e.so.1"*, *"Invoked by db2/decompile.py"*, import dir with
*"prior.bin + fixed.bin"*. In reality it is invoked by `_decompile.decompile_pair` (programs
named `prior`/`fixed`, no `.bin`); for MSSQL the blob is carved by
`mssql/stage2._extract_func_bytes` from PE `.pdata`/PDB chunks laid out at true offsets with
int3 gaps (bugs.md #25), and `db2/decompile.py` is itself dead (DB2-T1-4). The script body is
correct — only the comment misdescribes who drives it and where the bytes come from.

**Impact:** no behavioral effect; a maintenance/debugging trap for anyone tracing the MSSQL (or
Oracle) Track-2 path from the script, and it compounds the two dead `*/decompile.py` modules in
making the decompiler's call graph look DB2-only.

**Suggested fix:** retitle the header to "shared headless single-function decompiler (MSSQL /
DB2 / Oracle Stage 2)", note it is invoked by `patch_differ_cli/_decompile.py::decompile_pair`,
and that each backend supplies the carved blob (MSSQL: PE `.pdata`+PDB via
`mssql/stage2._extract_func_bytes`; DB2/Oracle: one contiguous ELF blob per function).

**Status: Fixed (2026-10-31).** `DecompileFunc.java`'s header now opens "Shared headless
single-function decompiler for the patch-differ … (MSSQL / DB2 / Oracle Stage 2)", states it
is driven by the backend-neutral `_decompile.py` (`decompile_pair`) and **not** by the dead
`db2/decompile.py`, names MSSQL's `_extract_func_bytes` int3-gap carve and the DB2/Oracle
contiguous blob, and corrects the `-import` line (programs `prior`/`fixed`, no `.bin`). The
`run()`/`applyContext()` code is unchanged — comment-only. Regression:
`tests/test_mssql_decompile_deprecation.py::DecompileFuncJavaHeaderIsShared`.

## MSSQL Track-2 — reviewed and found sound

- **Carve (`_extract_func_bytes`):** chunks placed at true offset-from-primary with int3-filled
  gaps so inter-fragment PC-relative branches resolve (bugs.md #25); requires a chunk exactly at
  `primary` (else `(b"", n)` — nothing unsound decompiled); `_MAX_DECOMP_SPAN` (16 MiB) keeps
  only the primary chunk on a pathological span; both omissions counted and surfaced by
  `_partial_c_note`. The note is applied in the caller from freshly-computed omit counts, so it
  never pollutes the (raw-C) cache and stays deterministic.
- **Per-side cache (`decompile_cached_per_side`):** keyed by each side's exact bytes +
  decompiler identity + `n2` norm version — correct for MSSQL because it passes **no** context,
  so a side's pseudo-C depends only on its blob; byte-identical functions across DLLs correctly
  share an entry. Atomic `os.replace` writes + `_sweep_stale_tmp` make the shared
  `per_function/` dir safe under the per-DLL ProcessPool. Falls back to a complete old per-pair
  entry; decompiles only the missing side(s); one cached + one freshly-decompiled is handled.
- **One-sided / failure accounting:** a one-sided or total failure is **not** cached and is
  counted (`decompile_failed`), with `last_failure_reason()` → `failure_record` recording why;
  `attempted=False` only when Ghidra is absent (never counted as a failure). Matches bugs.md #7
  and the DB2 path.
- **Gate & cap:** decompile lives inside `emit()`, so it runs only for **emitted** cards (capped
  functions `continue` before `emit`), never consuming budget for dropped churn; scoped to
  `fscore>0 or cve is not None`; `decompile_allowed`/`decompile_max` is a deterministic
  per-binary cap consumed in card order (attributed/fix-shaped first), identical in shape to the
  DB2 gate.
- **Ghidra driver (`decompile_pair` + `DecompileFunc.java`):** tolerates exit 1 (warnings),
  detects total failure by "no C output" regardless of exit code (CRIT-T2-1), clears the stale
  OSGi script-bundle cache and warns on an unsupported JDK (IMP-T2-1 / bugs.md #56), kills the
  process tree on timeout; `norm_c` collapses address-bearing labels while keeping real
  constants. MSSQL passes no context, so `name_targets`/data-block resolution (DB2-16/17) is
  simply not applied — lower fidelity than DB2 but sound (callee/data labels collapse
  identically on both sides, so no false diff).
- **Per-version output:** each build's `.c` goes to its own `decompiled_c_<build>_<version>/…`
  folder (created on first write via `_binary_folder`), filed under that side's function name
  (`_layout.function_file`, sha1-suffixed → no collisions); prior/fixed never collide (separate
  side folders); old flat `.prior.c/.fixed.c` fallback retained for jobs without per-version
  dirs.

---
---

# Oracle Track-2 — pseudo-C (`--decompile`) review

End-to-end review of Oracle's `--decompile` pseudo-C path. Scope note: "Track-2" here is the
**native ELF `.o` / archive** pseudo-C (`oracle/stage2.py::_decompile_pair` →
`_decompile.decompile_cached` → `DecompileFunc.java`). Oracle's Java/CFR decompilation of
`.jar` members is a *stage-1* readable-diff feature (always-on, `oracle/java_decompile.py`), not
this `--decompile` path, so it is out of scope here. Reviewed: `_func_map` (section-aware ET_REL
carve), `_diff_o`'s decompile gate/cap/cache/write at both call sites (BinDiff L611, name-mode
L720), the shared engine, the archive/one-sided dispatch in `run()`, and the per-version `.c`
layout. Two findings, both **Low** and both rooted in the ET_REL (unlinked, relocatable) object
model — neither is a correctness/false-positive bug; the detection path and output layout are
sound (see the "reviewed and found sound" list).

## ORA-T2-1 — ET_REL pseudo-C is decompiled with no context, so changed callees/data never appear  —  **Low (completeness)**

**Where:** `oracle/stage2.py::_decompile_pair` L419 — `decompile_cached(pb, fb, decompile_cache)`
is called with **no** `prior_ctx`/`fixed_ctx`.

**What:** DB2 passes `side_context(...)` to the same engine — the function's real `base`, the
read-only data `blocks` it references, and a `names` map — so `DecompileFunc.java` can relocate
the code, resolve switch/jump tables, and `name_targets` can rewrite `FUN_<addr>`/`func_0x<addr>`
to the real callee name (db2_bugs.md DB2-16/17). Oracle passes nothing. Because Oracle's inputs
are **ET_REL** `.o` objects, the carved function bytes (`_func_map`: `code =
section.data()[val:val+sz]`) still hold the **unrelocated** operands — every inter-unit `call`,
every RIP-relative data reference and every absolute address is a placeholder (0 / −4 / addend),
with the real target living in `.rela.text`, which is never consulted. So the pseudo-C shows
unresolved `func_0x…`/`DAT_…`/unresolved switches.

**Impact:** a **completeness** gap, not a correctness bug. The placeholders are identical on both
sides, and `norm_c` collapses the synthetic labels, so there is **no false difference** — but a
fix that only changes *which* function is called, or *which* datum is referenced (a relocation
target), is invisible in the Oracle pseudo-C (both sides read identically). It is also an
inconsistency with DB2's richer, context-driven pseudo-C. The canonical assembly diff has the
same ET_REL blind spot and stays the authoritative result, so the pseudo-C is never *more* wrong
than the assembly card it accompanies — it is just less informative.

**Suggested fix (enhancement):** build a `names`/`blocks` context from the object's `.rela.text*`
relocation entries (reloc offset → target symbol name, and referenced `.rodata` slices) and pass
it to `decompile_cached`, exactly as DB2's `side_context` does. This would let `name_targets`
resolve callees (and could reveal a changed-callee fix) and let the decompiler resolve jump
tables. Non-trivial (ET_REL section/relocation modelling); until then, document that Oracle
pseudo-C cannot show relocation-target changes.

**Status: Fixed (2026-10-31).** `oracle/stage2.py` now parses `.rela.text*` into
`fm.calls[name] -> [callee symbol names]` (`_reloc_func_refs_by_shndx` + `_reloc_calls_for`),
and `_decompile_pair` prepends each side's pseudo-C with a `_reloc_refs_note` listing those
relocated function refs — so a **changed callee set is now visible in the prior-vs-fixed C
diff** even though the inline calls stay placeholders. Deliberately conservative, for safety:
the pseudo-C is annotated, not rewritten (no blob re-linking / byte patching), the Ghidra engine
and the decompile cache are untouched (the note is applied post-cache, like MSSQL's
`_partial_c_note`), and the names are stable symbols, so the note can never manufacture a
difference that is not a real callee change. `fm.calls` is built as a fully-isolated,
try/guarded post-step keyed identically to `fm` (it reuses `_dedupe_func_names` on a parallel
list), so any failure degrades to the previous relocation-blind behaviour and can never perturb
the core function map. Remaining, documented limitation: data-symbol references (STT_OBJECT) and
a pure relocation-only retarget with zero `.text` change are still not surfaced (the latter is
invisible to the canonical assembly diff too). Regression:
`tests/test_oracle_reloc_calls.py` (`RelocCallParse`, `HelperUnits`, `EndToEnd`).

## ORA-T2-2 — the decompile gate inherits the ET_REL `call_targets` under-detection  —  **Low**

**Where:** the decompile gate `if (fscore > 0 or cve is not None)` (L611–612 / L720–721) feeding
`_decompile_pair`, where `fscore`/`added_intr` come from `X.call_targets(md, …, name_at_P/F)` over
the **raw** ET_REL bytes (`name_at_P, name_at_F = _make_name_at(P), _make_name_at(F)`, L364; the
limitation is spelled out in the L357–363 comment).

**What:** `added_intr` — the "fix added a security-intrinsic / validation call" signal, the
strongest fix-shape cue the other backends rely on — is computed by resolving each `call`'s target
in the raw bytes. For ET_REL those targets are relocation placeholders, so a call to an external
validation/guard routine resolves to nothing (or to the containing function) and is **silently
skipped** (the code notes this "under-detects, never mis-detects"). The knock-on effect specific
to **Track-2**: a fix whose only shape is "added an external guard/validation call" (a very common
pattern) can score `fscore == 0`; if it is also not CVE-attributed, the gate is false and **no
pseudo-C is produced for it** (and, past `_EMIT_CAP`, its assembly card can be dropped too).

**Impact:** Low. The root limitation is already documented in code (L357–363); this entry records
its *Track-2 consequence* — reduced pseudo-C coverage for add-a-call fixes on Oracle — so it is
not re-discovered. No incorrect output; purely reduced coverage. Attributed functions and
byte-change-shaped fixes are unaffected.

**Suggested fix:** same relocation-aware resolution as ORA-T2-1 — resolving `.rela.text` call
targets would feed `is_security_intrinsic`/`call_targets` real callee names, restoring the
added-intrinsic fix signal for ET_REL (and simultaneously improving the pseudo-C). Until then,
consider also gating decompile on the raw similarity/opcode delta (not only `fscore`/`cve`) so a
high-churn unattributed fix still gets pseudo-C.

**Status: Fixed (2026-10-31).** Both `added_intr` sites (BinDiff L611-area and name-mode) now go
through `_added_security_intrinsics`, which **unions** the directly-resolvable rel32 targets
(`X.call_targets`, as before) with the relocation-derived callees from `fm.calls` (ORA-T2-1's
parse). So an added hardening call that lives behind a relocation — every inter-unit call in an
unlinked `.o` — is now counted toward the fix signal, making an "added `__stack_chk_fail` /
`__memcpy_chk` / …" fix register as fix-shaped (so it is emitted past the cap AND decompiled).
Safe by construction: the predicate is the same narrow `X.is_security_intrinsic` set the other
backends use, over **stable symbol names** — it can only ADD a true-positive signal, never
mis-detect, and it is detection-only (the assembly/pseudo-C content is unchanged). Regression:
`tests/test_oracle_reloc_calls.py::HelperUnits` (reloc-added intrinsic detected, plain call
ignored, nothing-added → empty) and `::EndToEnd` (a fix that only adds `call __stack_chk_fail`
via a new relocation now scores `fix_score > 0` / `intrinsic: True`).

## Oracle Track-2 — reviewed and found sound

- **Gate parity:** decompile is scoped to `fscore > 0 or cve is not None` at BOTH call sites
  (BinDiff and name mode), identical to MSSQL/DB2; it runs **inside** the emit path, so only
  emitted cards decompile and capped churn never consumes the budget.
- **Matched-pairs only:** `_decompile_pair` is called only for two-sided matched functions
  (`common`/`bd_hits`/`name_hits`); added/removed functions and one-sided objects (`P` or `F`
  empty) are never decompiled — no before/after to compare, no `None`-path (`version_folder`
  guards `path is None`, L373).
- **Per-object cap:** `decompile_max` is enforced per `_diff_o` call via `obj_decompiles` — i.e.
  per `.o` and per **archive member** (each member is its own `_inventory`→`_diff_o` call), and
  `skipped` is counted once into the run aggregate.
- **Cache correctness under no-context:** the per-pair cache keys on `sha256(pb)+sha256(fb)+
  decompiler-identity+n2+ctx-digest`; with no ctx the output depends only on the bytes, so two
  ET_REL pairs with byte-identical (but differently-relocated) blobs correctly share an entry —
  the shared pseudo-C is exactly what either would compute. Oracle Stage 2 is a **sequential**
  for-loop (not a ProcessPool), so the non-atomic per-pair cache write is race-free here.
- **No false positives from relocations:** unrelocated operands are identical on both sides and
  `norm_c` collapses address-bearing labels, so relocation churn never manufactures a pseudo-C
  diff; the assembly diff stays canonical.
- **Carve soundness:** `_func_map` carves each STT_FUNC from its own section (`.text`/`.text.hot`/
  `.text.unlikely`), so GCC hot/cold split functions are each complete single-symbol blobs (no
  MSSQL-style chunk reassembly, hence no `_partial_c_note` needed); oversized functions
  (`_MAX_FUNC_BYTES`) are recorded out-of-band and never reach the decompiler; a non-single-`.text`
  ET_REL that pyelftools can't parse returns `{}` rather than wrong bytes.
- **Failure accounting:** one-sided/empty pseudo-C is counted `failed` and recorded in
  `dc_failures` with `failure_record` (bugs.md #7 / DB2-14); `attempted=False` (Ghidra absent) is
  never counted as a failure. Shared engine safeguards (CRIT-T2-1 no-output detection, IMP-T2-1
  stale-bundle clear, timeout tree-kill) apply.

---
---

# DB2 Track-2 — pseudo-C (`--decompile`) review

End-to-end review of DB2's `--decompile` path — the richest of the three, since `libdb2e.so` is
a linked image (absolute addresses, resolvable callees and read-only data). Reviewed:
`db2/stage2.py`'s decompile gate and `side_context`/`_decompile_context`/`_data_refs`/
`_exact_names`/`_plt_names` (DB2-16/17 context builders), `_elf.readonly_data_sections`, the
shared `_decompile.decompile_cached` (per-pair, context-aware) + `DecompileFunc.java` context
application, and the ProcessPool concurrency model (`_parallel.run_jobs` → `_process_file`). Two
findings; the context machinery is otherwise sound (see the "reviewed and found sound" list).

## DB2-T2-1 — asymmetric decompile context can manufacture a spurious pseudo-C difference  —  **Low–Medium**

**Where:** `db2/stage2.py` L859-861 — `decompile_cached(pb, fb, cache, side_context("prior", …),
side_context("fixed", …))`. `side_context` (L775-788) returns `None` on ANY exception (ELF parse
/ file read), independently per side.

**What:** the two `side_context(...)` calls are independent, so one can succeed while the other
returns `None` (e.g. a truncated, locked, or malformed `.so` on exactly ONE side, or an I/O error
reading one build's `.rodata` in `_decompile_context`). The engine then decompiles the two sides
under **different assumptions**: the `None` side at the fixed blob base (`_decompile._BASE`) with
no data blocks and no `names` map (so `name_targets` is skipped and every callee stays `FUN_…`
→ collapsed by `norm_c`), while the populated side is relocated to its real `base`, given its
read-only data, and has its callees renamed to real symbols (`__memcpy_chk`, `printf`, …).

**Impact:** for a function that did NOT actually change, the prior-vs-fixed pseudo-C now differs —
`FUN_()` / `DAT_` placeholders on the context-less side versus real callee/data names on the
other, plus different address bases — so the unified `.c` diff shows **spurious changed lines**.
It is a false difference in the additive pseudo-C view only (the assembly diff stays canonical and
is unaffected), and it is gated behind a one-sided ELF/I/O failure, so it is uncommon — but it is a
genuine correctness issue in the readable view, and the whole point of DB2-16/17's context is to
REMOVE exactly this class of address/name churn. The cache keys the two situations separately
(`_ctx_digest`), so the bad result is served only while the asymmetry persists, but it is cached
and re-served meanwhile.

**Suggested fix:** make the context symmetric — if EITHER side's `side_context` is `None`, pass
`None` for BOTH, so the two sides are always decompiled under identical assumptions (both with
context, or both without). Both-`None` is already safe today (both collapse identically, no false
diff); only the mixed case is the problem. A one-line guard at the call site, plus a regression
test driving an asymmetric context.

**Status: Fixed (2026-10-31).** `db2/stage2.py` now computes `pctx`/`fctx` from `side_context`
and, if EITHER is `None`, sets BOTH to `None` before calling `decompile_cached` — so the two sides
are always decompiled under identical assumptions (both with context or both without), and a
one-sided ELF/I/O failure can no longer produce a spurious `FUN_/DAT_`-vs-real-name diff. Both-with
and both-without were already correct; only the mixed case is removed. Regression:
`tests/test_db2_track2_context.py::SymmetricContext` (prior-fails and fixed-fails each drop both
contexts; the no-failure control keeps both real contexts).

## DB2-T2-2 — per-pair decompile cache is written non-atomically under the worker pool  —  **Low**

**Where:** `_decompile.decompile_cached` L419-424 (the per-pair cache the DB2/Oracle path uses):
`with open(lp(cache_file), "w") … json.dump(...)` — a plain truncate-and-write, no temp-file +
`os.replace`.

**What:** DB2 Stage 2 runs one `_process_file` per changed binary in a `ProcessPoolExecutor`
(`_parallel.run_jobs`, L1368), all sharing one `decompile_cache/` directory. Two workers that
decompile a function pair with identical prior+fixed bytes AND identical context (the same
statically-linked function present in two changed `.so` files) resolve to the **same** cache file
and can write it concurrently, interleaving into a torn/corrupt JSON. (Contrast MSSQL's per-side
cache, which writes `<entry>.<pid>.tmp` then `os.replace`s it precisely to avoid this —
`_write_side_cache`, and sweeps stale `.tmp` via `_sweep_stale_tmp`.)

**Impact:** Low — `_read_pair_cache` catches a corrupt entry and recomputes, so the result is
correct; the cost is a wasted re-decompile (and a lingering corrupt file until overwritten). Still
a real atomicity gap on a shared, concurrent cache, already solved on the per-side path.

**Suggested fix:** write the per-pair entry the same way `_write_side_cache` does —
`json.dump` to `<cache_file>.<pid>.tmp`, then `os.replace(tmp, cache_file)` — and (optionally)
extend the existing `_sweep_stale_tmp` to the per-pair directory. One small change in the shared
engine; it also benefits Oracle (whose sequential loop makes the race impossible today, but the
atomic write is still strictly safer).

**Status: Fixed (2026-10-31).** `_decompile.decompile_cached` now stages the entry to
`<cache_file>.<pid>.tmp` and `os.replace()`s it into place — the same atomic scheme as
`_write_side_cache`, so a concurrent pool worker or an interrupted write can never leave a torn
`cache_file`. `_sweep_stale_tmp` was generalized with a `subdir` argument and `decompile_cached`
now sweeps the per-pair directory's long-stale `*.tmp` (mirroring the per-side sweep), so a tmp
left by a killed worker is cleaned on a later run. Only files older than `_TMP_STALE_SECS` (1h)
are swept, so a live write is never raced. Applies to both DB2 and Oracle (the per-pair path).
Regression: `tests/test_db2_track2_context.py::AtomicPairCacheWrite` (a failed `os.replace` leaves
no in-place cache_file; a success writes a valid entry with no leftover tmp and is served on the
next call; a long-stale pair `.tmp` is swept while a recent one is kept).

## DB2 Track-2 — reviewed and found sound

- **Context base + data (DB2-16):** `_decompile_context` moves the blob to its real `base` and
  supplies the read-only data it references (`_data_refs` → `readonly_data_sections` windows,
  merged, clipped per-section, bounded by `_CTX_MAX_BYTES`); `readonly_data_sections` excludes
  writable AND executable sections, so a data block can never overlap the moved code block (and a
  jump table living in `.text` is simply not loaded), and `DecompileFunc.java` skips any block it
  cannot place.
- **Callee naming (DB2-17):** `names` unions `_plt_names` (PLT stub → imported symbol via
  `.rela.plt`/`.rela.dyn`) with `_exact_names` (this build's own symbols), covering direct
  call/jump targets outside the function; because each side resolves callees from its OWN build's
  symbols and `name_targets` runs before `norm_c`, an address shift or function reorder reads the
  same name on both builds (no false churn) — the intended DB2-17 behaviour.
- **Cache correctness:** the pair key includes `_ctx_digest(prior_ctx, fixed_ctx)` (base + block
  bytes + sorted names), so a changed constant/table/callee produces a distinct entry; a one-sided
  or empty decompile is never cached (bugs.md #7); a cache hit means both sides previously
  succeeded.
- **Gate & cap:** decompile is scoped to `fscore > 0 or cve is not None` and bounded by
  `decompile_max` per binary (`_decompile_allowed`), runs inside `emit()` so only emitted cards
  decompile, and is matched-pairs-only (added/removed never decompiled) — identical in shape to
  MSSQL/Oracle.
- **Context failure is non-fatal:** `side_context` never raises (returns `None`), and `None`/`None`
  decompiles without context exactly as before — only the *mixed* case is DB2-T2-1.
- **Per-version output:** each build's `.c` is written under its own `decompiled_c_<build>_<ver>/`
  folder by its own function name (sha1-suffixed `function_file`), with the old flat
  `.prior.c`/`.fixed.c` fallback retained for context-less jobs.
