# patch_differ_cli — Prerequisites

## Always required (core)

| Component | Version | Why |
|---|---|---|
| Python | **≥ 3.11** | `pyproject.toml: requires-python` |
| `capstone` | ≥ 4.0 | x86-64 disassembly for Stage 2 |
| `pefile` | ≥ 2023.2.7 | MSSQL PE parsing |
| `pyelftools` | ≥ 0.31 | DB2 / Oracle ELF parsing |
| `requests` | ≥ 2.31 | patch acquisition over HTTP |

Install with:

```
pip install -e .
```

or install the four packages directly from `requirements.txt.txt`.

**OS: Windows, effectively required for full functionality.** DB2/Oracle triage and Stage 1
are OS-agnostic, but MSSQL symbol resolution calls `dbghelp.dll` directly via `ctypes`
(`mssql/symbols.py`) with no non-Windows fallback beyond going nameless, and MSSQL
acquisition assumes a Windows installer (`.exe` / CAB / MSP). Running only the DB2 or Oracle
backends on Linux/macOS is plausible; the MSSQL backend is not.

## Per-backend, needed for acquisition

- **MSSQL** — **7-Zip** (`7z.exe`). Resolved in this order: `SEVENZIP` env var → bundled at
  `patch_differ_cli/tools/7-Zip-installed/7z.exe`. No other fallback location is checked. No
  specific version is pinned in code.
- **DB2** — no extra tool; pulls container layers directly over the registry v2 API.
  `PATCHDIFF_INSECURE_TLS=1` / `REQUESTS_CA_BUNDLE` env vars exist if TLS verification needs
  adjusting.
- **Oracle** — no extra tool for acquisition; you supply the patch zip directly.

## Optional — only needed for `--decompile` or `--use-bindiff`

**Current decision: one shared Ghidra/JDK install covers both `--decompile` (Track 2) and
`--use-bindiff` (Track 1)** — no need for two separate Ghidra/JDK pairs. See
`tools/tracks.md`, `tools/track-1/ABOUT.md`, `tools/track-2/ABOUT.md` for the track
breakdown.

| Component | Version in use | Bundled path (checked when the env var isn't set) |
|---|---|---|
| **JDK** | **17** (17.0.12) | `tools/jdk-17.0.12/` — the only location checked; no OS-wide fallback |
| **Ghidra** | **11.0.3 PUBLIC** | `tools/ghidra_11.0.3_PUBLIC_20240410/` — the only location checked; no OS-wide fallback |
| **BinExport** (Ghidra extension) | **v12** (`v12-20240417-ghidra_11.0.3`) | The *active* script is the copy installed inside the Ghidra install above, at `Ghidra/Extensions/BinExport/ghidra_scripts/BinExport.java`. The raw extracted release package is also kept, for reference, at `tools/ghidra_11.0.3_PUBLIC_20240417_BinExport/` — the code does not read from that copy directly |
| **BinDiff** | **8** | `tools/bindiff8-installed/bin/` — the only location checked; no OS-wide fallback (PATH is still checked as a last resort) |
| **CFR** (decompiler jar) | **0.152** | `tools/cfr-0.152.jar` — the only location checked; falls back to `javap` if absent |

JDK 17 is Ghidra 11.0.3's own declared minimum *and* its exact build/compiler target
(`application.java.compiler=17`) — the precise combination it was actually tested against,
not just a forward-compatible allowance. A newer JDK (e.g. 21) would likely also run it
fine, but there's no benefit to that tradeoff here, so this project pins JDK 17 exactly.

`patch_differ_cli/tools/` currently holds all five: JDK, Ghidra (with BinExport installed
inside it), BinDiff, 7-Zip, and the CFR jar — each under its own installer/extraction folder
name (`jdk-17.0.12/`, `ghidra_11.0.3_PUBLIC_20240410/`, `bindiff8-installed/`,
`7-Zip-installed/`, `cfr-0.152.jar`). The code's bundled paths are matched to these exact
names, so none of `PATCHDIFF_JAVA_HOME`/`GHIDRA_HOME`/`BINDIFF_PATH`/`SEVENZIP`/`CVE_PATCHDIFF_CFR` need
to be set — they're only needed to override these locations. **There is no OS-wide fallback
location for JDK, Ghidra, 7-Zip, or CFR any more** — if the bundled folder is missing and the
env var isn't set, the tool is simply reported as not configured, rather than silently
pointing at a `C:\Program Files\...` / `C:\Tools\...` path that doesn't exist on this machine.
BinDiff keeps one extra, non-path fallback: a `bindiff`/`differ` executable found on `PATH`.

**All five of these paths are defined in exactly one place:** `patch_differ_cli/tool_paths.py`.
Every other module (`_bindiff.py`, `_decompile.py`, `mssql/acquire.py`,
`oracle/java_decompile.py`) imports and calls that module instead of hardcoding a
`tools/<folder-name>` string or an env var name itself. To upgrade a tool's bundled version,
change the matching `JDK_DIR` / `GHIDRA_DIR` / `BINDIFF_BIN` / `SEVENZIP_EXE` / `CFR_JAR`
constant at the top of `tool_paths.py` — nothing else needs to change.

## Ghidra, JDK and BinExport compatibility notes

- **JDK:** Ghidra 11.0.3 runs its scripts (BinExport for Track 1, `DecompileFunc.java` for
  Track 2) only on JDK 17-21. Under a newer JDK, such as a system `JAVA_HOME` of JDK 26, its
  OSGi framework reports `osgi.ee=UNKNOWN` and no script loads. The tool therefore uses the
  bundled JDK 17 unless `PATCHDIFF_JAVA_HOME` says otherwise, and it warns before launching
  Ghidra on a JDK outside that range.
- **protobuf:** Ghidra 11.0.3 ships `protobuf-java-3.21.8.jar` in
  `Ghidra/Debug/Framework-AsyncComm/lib/`, while the BinExport v12 extension ships
  `protobuf-java-3.25.1.jar`. Both load into one class loader, so every export crashed with
  `IllegalAccessError` (`LazyStringArrayList.emptyList`). In the bundled install, the
  Debugger module's jar has been replaced with a copy of the extension's 3.25.1. The
  original is kept in `tools/_replaced_by_patch_differ/`, with a README explaining how to
  restore it. If you use your own Ghidra (`GHIDRA_HOME`), make its protobuf-java jars one
  version: Track 1 refuses to run, with a message naming the jars, while they differ.
- **Export script:** Track 1 exports through `db2/ghidra/PdffBinExport.java`. It takes only
  the output path and needs the BinExport extension installed. The extension's own
  `BinExport.java` can't run headless here: it also asks for an IDA-compatibility option
  list that headless Ghidra can't answer with "none", and `analyzeHeadless.bat` drops an
  empty argument together with everything after it.

## Long Ghidra runs

- Time limits count only the time the machine is awake: a laptop that sleeps during a run no
  longer uses up (or "negatively" exceeds) a limit, but the run is paused while it sleeps.
- On a timeout or Ctrl+C the whole Ghidra process tree is stopped (the `.bat` wrapper and its
  `java.exe`), so no JVM keeps analysing in the background.
- Each binary's Ghidra output is kept next to its export, in
  `<out>\stage2\<binary>_<id>\bindiff\{prior,fixed}_<name>.BinExport.{import,export}.log` and
  `differ.log`.
  Open one to follow progress during a long analysis. A log over 5 MiB is cut to its first 1 MiB
  and last 4 MiB when its run ends.
- If an export fails or times out after the analysis finished, the next run exports from that
  finished analysis instead of importing the binary again.
- A run that hits Java's heap limit stops with an out-of-memory error that names
  `PATCHDIFF_GHIDRA_MAXMEM`.

## Bounding a long run

- `--bindiff-only GLOB` (with `--use-bindiff`; repeat it or separate globs with commas): only binaries whose path or file name matches get Ghidra + BinDiff, e.g. `--bindiff-only 'libdb2e.so*'`. The rest are matched by name and listed in `bindiff_not_selected`.
- `--decompile-max N` (with `--decompile`): at most N pseudo-C decompiles per binary, most important functions first.
- Before BinDiff starts, a NOTE gives the number of binaries, their size and a rough time estimate; triage warns which code-changed binaries lack function symbols.

## Environment variable overrides

| Variable | Purpose |
|---|---|
| `GHIDRA_HOME` | Path to a Ghidra install (expects `support/analyzeHeadless`) |
| `PATCHDIFF_JAVA_HOME` | Path to a JDK install for Ghidra and CFR. When it is unset, the bundled JDK 17 is used. A system-wide `JAVA_HOME` is used only if no JDK is bundled, because it often points at a JDK this Ghidra can't run under (see below) |
| `BINDIFF_PATH` | Path to the BinDiff `bindiff`/`differ` executable |
| `SEVENZIP` | Path to `7z.exe` |
| `CVE_PATCHDIFF_CFR` | Path to the CFR decompiler jar |
| `CVE_PATCHDIFF_WORKERS` | Caps/overrides Stage 2 worker count (`=1` forces sequential). Without it, `--use-bindiff` runs also lower the count until the Ghidra heaps running at once fit in 75% of RAM |
| `PATCHDIFF_GHIDRA_MAXMEM` | Ghidra's maximum Java heap, e.g. `8G` or `6144M` (at least `256M`). When unset: Ghidra's own 2 GB, raised to 40x the binary's size for large binaries, but at most half the RAM. Passed to Java through `_JAVA_OPTIONS`, because `analyzeHeadless.bat` hard-codes 2 GB |
| `PATCHDIFF_GHIDRA_IMPORT_TIMEOUT` | Seconds allowed for Ghidra's import and full analysis of one binary; `0` = no limit. When unset: 240 s per MiB of the binary, at least 3600 s |
| `PATCHDIFF_BINEXPORT_TIMEOUT` | Seconds allowed for the BinExport export of one analysed binary; `0` = no limit. When unset: 60 s per MiB, at least 600 s |
| `PATCHDIFF_BINDIFF_TIMEOUT` | Seconds allowed for BinDiff's matching of one pair; `0` = no limit. When unset: 30 s per MiB of the two `.BinExport` files, at least 300 s |
| `PATCHDIFF_MAX_FUNC_BYTES` | Stage 2 per-function size limit in bytes (default 300000). A larger function is not diffed but reported in `skipped_functions`; raising it costs time on very large functions |
| `PATCHDIFF_INSECURE_TLS` | Set to `1` to skip TLS verification for DB2 registry pulls |
| `REQUESTS_CA_BUNDLE` | Custom CA bundle for DB2 registry pulls |
